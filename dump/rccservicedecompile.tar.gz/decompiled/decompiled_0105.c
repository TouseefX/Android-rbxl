/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 26250 ; VA 0x00bc7710 ; FUN_00bc7710 */

int __fastcall FUN_00bc7710(int param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar3 = *(uint *)(param_1 + 0x120);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar3 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x128,param_1 + 0x128,2);
      }
    }
    *(undefined4 *)(param_1 + 0x120) = 0;
  }
  iVar5 = FUN_00bc7880();
  piVar4 = *(int **)(param_1 + 4);
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar1 = piVar4 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 26251 ; VA 0x00bc77b0 ; FUN_00bc77b0 */

int __fastcall FUN_00bc77b0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_00bc7880();
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x00bc77cf. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar4 = (**(code **)(*piVar3 + 4))();
      return iVar4;
    }
  }
  return iVar4;
}



/* FUNCTION 26252 ; VA 0x00bc77e0 ; FUN_00bc77e0 */

int __fastcall FUN_00bc77e0(int param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar3 = *(uint *)(param_1 + 0x128);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar3 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x130,param_1 + 0x130,2);
      }
    }
    *(undefined4 *)(param_1 + 0x128) = 0;
  }
  iVar5 = FUN_00bc7880();
  piVar4 = *(int **)(param_1 + 4);
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar1 = piVar4 + 2;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)(*piVar4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 26253 ; VA 0x00bc7860 ; thunk_FUN_00bc7880 */

void __fastcall thunk_FUN_00bc7880(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0xf8);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x100,param_1 + 0x100,2);
      }
    }
    *(undefined4 *)(param_1 + 0xf8) = 0;
  }
  uVar1 = *(uint *)(param_1 + 0xd8);
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0xe0,param_1 + 0xe0,2);
      }
    }
    *(undefined4 *)(param_1 + 0xd8) = 0;
  }
  uVar1 = *(uint *)(param_1 + 0xcc);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0xb8);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00bc7a66;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 200) = 0;
  *(undefined4 *)(param_1 + 0xcc) = 0xf;
  *(undefined *)(param_1 + 0xb8) = 0;
  uVar1 = *(uint *)(param_1 + 0xb0);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x9c);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00bc7a66;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0xac) = 0;
  *(undefined4 *)(param_1 + 0xb0) = 0xf;
  *(undefined *)(param_1 + 0x9c) = 0;
  uVar1 = *(uint *)(param_1 + 0x98);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x84);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00bc7a66;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x94) = 0;
  *(undefined4 *)(param_1 + 0x98) = 0xf;
  *(undefined *)(param_1 + 0x84) = 0;
  uVar1 = *(uint *)(param_1 + 0x80);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x6c);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00bc7a66:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x7c) = 0;
  *(undefined4 *)(param_1 + 0x80) = 0xf;
  *(undefined *)(param_1 + 0x6c) = 0;
  FUN_0056db40();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26254 ; VA 0x00bc7870 ; thunk_FUN_00bc8030 */

void __fastcall thunk_FUN_00bc8030(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_00bc7880();
        iVar2 = iVar2 + 0x118;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x118) * 0x118;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 26255 ; VA 0x00bc7880 ; FUN_00bc7880 */

void __fastcall FUN_00bc7880(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0xf8);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x100,param_1 + 0x100,2);
      }
    }
    *(undefined4 *)(param_1 + 0xf8) = 0;
  }
  uVar1 = *(uint *)(param_1 + 0xd8);
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0xe0,param_1 + 0xe0,2);
      }
    }
    *(undefined4 *)(param_1 + 0xd8) = 0;
  }
  uVar1 = *(uint *)(param_1 + 0xcc);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0xb8);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00bc7a66;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 200) = 0;
  *(undefined4 *)(param_1 + 0xcc) = 0xf;
  *(undefined *)(param_1 + 0xb8) = 0;
  uVar1 = *(uint *)(param_1 + 0xb0);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x9c);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00bc7a66;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0xac) = 0;
  *(undefined4 *)(param_1 + 0xb0) = 0xf;
  *(undefined *)(param_1 + 0x9c) = 0;
  uVar1 = *(uint *)(param_1 + 0x98);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x84);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00bc7a66;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x94) = 0;
  *(undefined4 *)(param_1 + 0x98) = 0xf;
  *(undefined *)(param_1 + 0x84) = 0;
  uVar1 = *(uint *)(param_1 + 0x80);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x6c);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00bc7a66:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x7c) = 0;
  *(undefined4 *)(param_1 + 0x80) = 0xf;
  *(undefined *)(param_1 + 0x6c) = 0;
  FUN_0056db40();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26256 ; VA 0x00bc7a70 ; FUN_00bc7a70 */

void __fastcall FUN_00bc7a70(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a950;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::HttpRbxApiService::vftable;
  piVar2 = (int *)param_1[0x48];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8 = 0;
  FUN_01679490();
  iVar4 = param_1[0x41];
  if (iVar4 != 0) {
    piVar2 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar4 = param_1[0x40];
  if (iVar4 != 0) {
    piVar2 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 2;
  FUN_01679490();
  iVar4 = param_1[0x3f];
  if (iVar4 != 0) {
    piVar2 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uVar3 = param_1[0x3d];
  uStack_8 = 0xffffffff;
  if (0xf < uVar3) {
    iVar4 = param_1[0x38];
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x3c] = 0;
  piVar2 = param_1 + 0x36;
  param_1[0x3d] = 0xf;
  *(undefined *)(param_1 + 0x38) = 0;
  iVar4 = *piVar2;
  uStack_8 = 3;
  FUN_00576720(*(undefined4 *)(iVar4 + 4));
  *(int *)(*piVar2 + 4) = iVar4;
  *(int *)*piVar2 = iVar4;
  *(int *)(*piVar2 + 8) = iVar4;
  param_1[0x37] = 0;
  FUN_01674ea0(*piVar2,0x28);
  iVar4 = param_1[0x34];
  piVar2 = param_1 + 0x34;
  uStack_8 = 4;
  FUN_00576720(*(undefined4 *)(iVar4 + 4));
  *(int *)(*piVar2 + 4) = iVar4;
  *(int *)*piVar2 = iVar4;
  *(int *)(*piVar2 + 8) = iVar4;
  param_1[0x35] = 0;
  FUN_01674ea0(*piVar2,0x28);
  piVar2 = (int *)param_1[0x33];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00bc8030();
  FUN_00bc8030();
  FUN_00bc8030();
  FUN_00bc8030();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26257 ; VA 0x00bc7cb0 ; FUN_00bc7cb0 */

undefined4 * __thiscall FUN_00bc7cb0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  *(undefined *)(param_1 + 4) = *(undefined *)(param_2 + 4);
  *(undefined *)((int)param_1 + 0x11) = *(undefined *)((int)param_2 + 0x11);
  *(undefined *)((int)param_1 + 0x12) = *(undefined *)((int)param_2 + 0x12);
  param_1[5] = param_2[5];
  piVar1 = param_2 + 6;
  if (param_1 + 6 != piVar1) {
    if (0xf < (uint)param_2[0xb]) {
      piVar1 = (int *)*piVar1;
    }
    FUN_005542c0(piVar1,param_2[10]);
  }
  *(undefined *)(param_1 + 0xc) = *(undefined *)(param_2 + 0xc);
  if (param_1 + 0xd != param_2 + 0xd) {
    FUN_00657e90(param_2 + 0xd,param_2);
  }
  piVar1 = param_2 + 0x13;
  if (param_1 + 0x13 != piVar1) {
    if (0xf < (uint)param_2[0x18]) {
      piVar1 = (int *)*piVar1;
    }
    FUN_005542c0(piVar1,param_2[0x17]);
  }
  *(undefined *)(param_1 + 0x19) = *(undefined *)(param_2 + 0x19);
  return param_1;
}



/* FUNCTION 26258 ; VA 0x00bc7d50 ; FUN_00bc7d50 */

int __thiscall FUN_00bc7d50(int param_1,int param_2)

{
  int *piVar1;
  
  FUN_00bc7cb0(param_2);
  *(undefined *)(param_1 + 0x68) = *(undefined *)(param_2 + 0x68);
  piVar1 = (int *)(param_2 + 0x6c);
  if ((int *)(param_1 + 0x6c) != piVar1) {
    if (0xf < *(uint *)(param_2 + 0x80)) {
      piVar1 = (int *)*piVar1;
    }
    FUN_005542c0(piVar1,*(undefined4 *)(param_2 + 0x7c));
  }
  piVar1 = (int *)(param_2 + 0x84);
  if ((int *)(param_1 + 0x84) != piVar1) {
    if (0xf < *(uint *)(param_2 + 0x98)) {
      piVar1 = (int *)*piVar1;
    }
    FUN_005542c0(piVar1,*(undefined4 *)(param_2 + 0x94));
  }
  piVar1 = (int *)(param_2 + 0x9c);
  if ((int *)(param_1 + 0x9c) != piVar1) {
    if (0xf < *(uint *)(param_2 + 0xb0)) {
      piVar1 = (int *)*piVar1;
    }
    FUN_005542c0(piVar1,*(undefined4 *)(param_2 + 0xac));
  }
  *(undefined *)(param_1 + 0xb4) = *(undefined *)(param_2 + 0xb4);
  piVar1 = (int *)(param_2 + 0xb8);
  if ((int *)(param_1 + 0xb8) != piVar1) {
    if (0xf < *(uint *)(param_2 + 0xcc)) {
      piVar1 = (int *)*piVar1;
    }
    FUN_005542c0(piVar1,*(undefined4 *)(param_2 + 200));
  }
  *(undefined4 *)(param_1 + 0xd0) = *(undefined4 *)(param_2 + 0xd0);
  *(undefined4 *)(param_1 + 0xd4) = *(undefined4 *)(param_2 + 0xd4);
  FUN_008c4480(param_2 + 0xd8);
  FUN_008c4480(param_2 + 0xf8);
  return param_1;
}



/* FUNCTION 26259 ; VA 0x00bc7e40 ; FUN_00bc7e40 */

int __thiscall FUN_00bc7e40(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x50) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x50),4);
  }
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  FUN_005c4ac0();
  FUN_005c4ac0();
  FUN_009cb8d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 26260 ; VA 0x00bc7eb0 ; FUN_00bc7eb0 */

int __thiscall FUN_00bc7eb0(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  FUN_005c4ac0();
  FUN_009cb8d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 26261 ; VA 0x00bc7f10 ; FUN_00bc7f10 */

undefined4 __thiscall FUN_00bc7f10(undefined4 param_1,byte param_2)

{
  FUN_00bc73f0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 26262 ; VA 0x00bc7f40 ; FUN_00bc7f40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00bc7f40(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::ThrottlingPriority>::vftable;
  _DAT_01ef5d38 = _DAT_01ef5d38 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 26263 ; VA 0x00bc7f70 ; FUN_00bc7f70 */

undefined4 * __thiscall FUN_00bc7f70(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::HttpRbxApiService::HttpRequestExecutionPolicy::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 26264 ; VA 0x00bc7fa0 ; FUN_00bc7fa0 */

int __thiscall FUN_00bc7fa0(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 300);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x140);
  }
  return param_1;
}



/* FUNCTION 26265 ; VA 0x00bc8000 ; FUN_00bc8000 */

undefined4 __thiscall FUN_00bc8000(undefined4 param_1,byte param_2)

{
  FUN_00bc7a70();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x128);
  }
  return param_1;
}



/* FUNCTION 26266 ; VA 0x00bc8030 ; FUN_00bc8030 */

void __fastcall FUN_00bc8030(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_00bc7880();
        iVar2 = iVar2 + 0x118;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x118) * 0x118;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 26267 ; VA 0x00bc80c0 ; FUN_00bc80c0 */

void FUN_00bc80c0(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 *param_5,undefined4 *param_6,uint *param_7,uint *param_8)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  undefined8 uStack_a0;
  undefined4 uStack_98;
  undefined auStack_94 [4];
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_58;
  uint *puStack_54;
  uint *puStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fec00;
  pvStack_10 = ExceptionList;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ef5a95);
  uVar1 = *param_6;
  uVar2 = *param_5;
  uStack_48 = 0;
  uVar3 = *param_8;
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    uStack_48 = uVar3;
    if ((uVar3 & 1) == 0) {
      puStack_50 = &uStack_40;
      uStack_4c = 0;
      puStack_54 = param_8 + 2;
      uStack_58 = 0xbc814a;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    else {
      uStack_40 = param_8[2];
      uStack_3c = param_8[3];
      uStack_38 = param_8[4];
      uStack_34 = param_8[5];
      uStack_30 = *(undefined8 *)(param_8 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uStack_6c = 0;
  uStack_98 = param_1;
  uVar3 = *param_7;
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(param_7 + 2,&uStack_b0,0);
    }
    else {
      uStack_b0 = param_7[2];
      uStack_ac = param_7[3];
      uStack_a8 = param_7[4];
      uStack_a4 = param_7[5];
      uStack_a0 = *(undefined8 *)(param_7 + 6);
    }
  }
  FUN_008bfbf0(auStack_94,FUN_00bc5610);
  uStack_98 = 0xbc81c1;
  FUN_008dc050();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_8c = param_4;
  uStack_90 = 0xbc81d8;
  uStack_70 = uVar2;
  uStack_6c = uVar1;
  FUN_0054ef60();
  uStack_8 = 0xffffffff;
  uStack_8c = 0xbc81e5;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26268 ; VA 0x00bc8200 ; FUN_00bc8200 */

void FUN_00bc8200(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 undefined4 *param_5,undefined4 *param_6,undefined4 *param_7,uint *param_8,
                 uint *param_9)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  undefined8 uStack_a0;
  undefined4 uStack_98;
  undefined auStack_94 [20];
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_58;
  uint *puStack_54;
  uint *puStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cef48;
  pvStack_10 = ExceptionList;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ef5a95);
  uVar2 = *param_7;
  uVar3 = *param_6;
  uVar4 = *param_5;
  uStack_48 = 0;
  uVar5 = *param_9;
  ExceptionList = &pvStack_10;
  if (uVar5 != 0) {
    uStack_48 = uVar5;
    if ((uVar5 & 1) == 0) {
      puStack_50 = &uStack_40;
      uStack_4c = 0;
      puStack_54 = param_9 + 2;
      uStack_58 = 0xbc8292;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar5 & 0xfffffffe))();
    }
    else {
      uStack_40 = param_9[2];
      uStack_3c = param_9[3];
      uStack_38 = param_9[4];
      uStack_34 = param_9[5];
      uStack_30 = *(undefined8 *)(param_9 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uStack_6c = 0;
  uStack_98 = param_1;
  uVar5 = *param_8;
  if (uVar5 != 0) {
    if ((uVar5 & 1) == 0) {
      (**(code **)(uVar5 & 0xfffffffe))(param_8 + 2,&uStack_b0,0);
    }
    else {
      uStack_b0 = param_8[2];
      uStack_ac = param_8[3];
      uStack_a8 = param_8[4];
      uStack_a4 = param_8[5];
      uStack_a0 = *(undefined8 *)(param_8 + 6);
    }
  }
  FUN_008bfbf0(auStack_94,FUN_00bc5610);
  uStack_98 = 0xbc8306;
  FUN_008dc050();
  if (param_4[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_7c = *param_4;
  uStack_78 = param_4[1];
  uStack_8 = 0xffffffff;
  uStack_80 = 0xbc8346;
  uStack_74 = uVar4;
  uStack_70 = uVar3;
  uStack_6c = uVar2;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26269 ; VA 0x00bc8360 ; FUN_00bc8360 */

void FUN_00bc8360(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 *param_6,undefined4 *param_7,undefined4 *param_8,
                 uint *param_9,uint *param_10)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  undefined8 uStack_a0;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_58;
  uint *puStack_54;
  uint *puStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fec28;
  pvStack_10 = ExceptionList;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ef5a95);
  uVar1 = *param_8;
  uVar2 = *param_7;
  uVar3 = *param_6;
  uStack_48 = 0;
  uVar4 = *param_10;
  ExceptionList = &pvStack_10;
  if (uVar4 != 0) {
    uStack_48 = uVar4;
    if ((uVar4 & 1) == 0) {
      puStack_50 = &uStack_40;
      uStack_4c = 0;
      puStack_54 = param_10 + 2;
      uStack_58 = 0xbc83f2;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar4 & 0xfffffffe))();
    }
    else {
      uStack_40 = param_10[2];
      uStack_3c = param_10[3];
      uStack_38 = param_10[4];
      uStack_34 = param_10[5];
      uStack_30 = *(undefined8 *)(param_10 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uStack_6c = 0;
  uStack_98 = param_1;
  uVar4 = *param_9;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      (**(code **)(uVar4 & 0xfffffffe))(param_9 + 2,&uStack_b0,0);
    }
    else {
      uStack_b0 = param_9[2];
      uStack_ac = param_9[3];
      uStack_a8 = param_9[4];
      uStack_a4 = param_9[5];
      uStack_a0 = *(undefined8 *)(param_9 + 6);
    }
  }
  FUN_008bfbf0(&uStack_94,FUN_00bc5610);
  uStack_98 = 0xbc8469;
  FUN_008dc050();
  uStack_8._0_1_ = 1;
  uStack_90 = param_5;
  uStack_94 = 0xbc8486;
  uStack_74 = uVar3;
  uStack_70 = uVar2;
  uStack_6c = uVar1;
  FUN_0054ef60();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uStack_a8 = param_4;
  uStack_ac = 0xbc8497;
  FUN_0054ef60();
  uStack_8 = 0xffffffff;
  uStack_a8 = 0xbc84a4;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26270 ; VA 0x00bc84c0 ; FUN_00bc84c0 */

void __thiscall FUN_00bc84c0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 ***pppuVar3;
  undefined4 **appuStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799c39;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00bcc980(param_3);
  if (cVar1 != '\0') {
    if (*(char *)(param_1 + 0x118) != '\0') {
      uStack_8 = 0;
      uStack_1c = 0;
      uStack_18 = 0xf;
      appuStack_2c[0] = (undefined4 **)((uint)appuStack_2c[0] & 0xffffff00);
      uStack_14 = 1;
      FUN_0058a190(param_3[4] + 0x23);
      FUN_00554150("postAsyncUrlPathContainsDomain for ",0x23);
      puVar2 = param_3;
      if (0xf < (uint)param_3[5]) {
        puVar2 = (undefined4 *)*param_3;
      }
      FUN_00554150(puVar2,param_3[4]);
      pppuVar3 = appuStack_2c;
      if (0xf < uStack_18) {
        pppuVar3 = (undefined4 ***)appuStack_2c[0];
      }
      FUN_0087c450(&DAT_018c5f98,"HttpRbxApiService",pppuVar3,0,0,0);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
    }
    if (param_2 != param_3) {
      puVar2 = param_3 + 4;
      if (0xf < (uint)param_3[5]) {
        param_3 = (undefined4 *)*param_3;
      }
      FUN_005542c0(param_3,*puVar2);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26271 ; VA 0x00bc85c0 ; FUN_00bc85c0 */

void __thiscall FUN_00bc85c0(int param_1,undefined4 param_2)

{
  char cVar1;
  float fVar2;
  float fVar3;
  
  if (*(char *)(param_1 + 0xf8) == '\0') {
    cVar1 = FUN_008b9b00(param_2);
    if (cVar1 != '\0') {
      FUN_01679490();
      FUN_01679490();
      fVar2 = (float)DAT_01d67cd4;
      fVar3 = *(float *)(param_1 + 0x58) + fVar2;
      if (fVar3 <= fVar2) {
        fVar2 = fVar3;
      }
      *(float *)(param_1 + 0x58) = fVar2;
      fVar2 = (float)DAT_01d67cd4;
      fVar3 = fVar2 + *(float *)(param_1 + 0x5c);
      if (fVar3 <= fVar2) {
        fVar2 = fVar3;
      }
      *(float *)(param_1 + 0x5c) = fVar2;
      fVar2 = (float)DAT_01d67cec;
      fVar3 = *(float *)(param_1 + 100) + fVar2;
      if (fVar3 <= fVar2) {
        fVar2 = fVar3;
      }
      *(float *)(param_1 + 100) = fVar2;
      *(undefined *)(param_1 + 0xf8) = 1;
    }
  }
  if (*(char *)(param_1 + 0xf9) == '\0') {
    cVar1 = FUN_008b0260(param_2);
    if (cVar1 != '\0') {
      FUN_01679490();
      FUN_01679490();
      fVar2 = (float)DAT_01d67cc4;
      fVar3 = fVar2 + *(float *)(param_1 + 0x60);
      if (fVar3 <= fVar2) {
        fVar2 = fVar3;
      }
      *(float *)(param_1 + 0x60) = fVar2;
      fVar2 = (float)DAT_01d67cec;
      fVar3 = *(float *)(param_1 + 100) + fVar2;
      if (fVar3 <= fVar2) {
        fVar2 = fVar3;
      }
      *(float *)(param_1 + 100) = fVar2;
      *(undefined *)(param_1 + 0xf9) = 1;
    }
  }
  return;
}



/* FUNCTION 26272 ; VA 0x00bc86e0 ; FUN_00bc86e0 */

void FUN_00bc86e0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00bd30e0();
    *param_2 = uVar3;
    iVar4 = FUN_00bd3190();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 26273 ; VA 0x00bc8740 ; FUN_00bc8740 */

void FUN_00bc8740(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00bd30e0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 26274 ; VA 0x00bc8780 ; FUN_00bc8780 */

undefined4 * FUN_00bc8780(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_008e28e0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 26275 ; VA 0x00bc87f0 ; FUN_00bc87f0 */

void __thiscall
FUN_00bc87f0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cf757;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088cb40();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puVar4 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x48);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    uStack_ec = FUN_00bd30e0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar4;
    iStack_e8 = FUN_00bd3190();
    puVar4 = &uStack_ec;
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_00bd30e0();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 0x10) != 0) {
    uVar5 = uVar5 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 0xd;
    uVar5 = uVar5 | 0x80;
  }
  else {
    uStack_ec = thunk_FUN_009eb4b0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar4;
    iStack_e8 = FUN_009eb560();
    puVar4 = &uStack_ec;
    uStack_8 = 0xc;
    uVar5 = uVar5 | 0x40;
  }
  uStack_14 = uVar5;
  uVar2 = thunk_FUN_009eb4b0();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((char)uVar5 < '\0') {
    uVar5 = uVar5 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 0x40) != 0) {
    uVar5 = uVar5 & 0xffffffbf;
    uStack_8 = 0xf;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x50);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 0x11;
    uVar5 = uVar5 | 0x200;
  }
  else {
    uStack_28c = FUN_0090c030();
    iStack_288 = 0;
    auStack_284[0] = *puVar4;
    iStack_288 = FUN_0090c4c0();
    puVar4 = &uStack_28c;
    uStack_8 = 0x10;
    uVar5 = uVar5 | 0x100;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0090c030();
  uVar3 = FUN_0086e3d0(param_6);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 0x200) != 0) {
    uVar5 = uVar5 & 0xfffffdff;
    uStack_8 = 0x12;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 0x100) != 0) && (uStack_8 = 0x13, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26276 ; VA 0x00bc8d00 ; FUN_00bc8d00 */

void __thiscall FUN_00bc8d00(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798aa8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088cb40();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = FUN_00bd30e0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar4;
    iStack_e8 = FUN_00bd3190();
    puVar4 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_00bd30e0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x48);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    uStack_28c = FUN_0090c030();
    iStack_288 = 0;
    auStack_284[0] = *puVar4;
    iStack_288 = FUN_0090c4c0();
    puVar4 = &uStack_28c;
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0090c030();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 0x10) != 0) && (uStack_8 = 0xb, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26277 ; VA 0x00bc9010 ; FUN_00bc9010 */

void __thiscall
FUN_00bc9010(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  int iStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ba5;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  puStack_18 = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_0088cb40();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  puVar5 = *(undefined4 **)(param_1 + 0x40);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 1;
    uVar6 = 2;
  }
  else {
    uStack_ec = FUN_008881d0();
    puStack_e8 = (undefined4 *)0x0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8a9c)
       && (FUN_016f3809(&DAT_01ea8a9c), DAT_01ea8a9c == -1)) {
      DAT_01ea8a90 = FUN_0057bbb0;
      DAT_01ea8a94 = FUN_005880a0;
      DAT_01ea8a98 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ea8a9c);
    }
    puStack_e8 = &DAT_01ea8a90;
    puVar5 = &uStack_ec;
    uStack_8 = 0;
    uVar6 = 1;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_008881d0();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 1) != 0) {
    uVar6 = uVar6 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  iVar2 = iStack_1c;
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(iStack_1c + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 5;
    uVar6 = uVar6 | 8;
  }
  else {
    uStack_ec = FUN_00bd30e0();
    puStack_e8 = (undefined4 *)0x0;
    uStack_e4 = *puVar5;
    puStack_e8 = (undefined4 *)FUN_00bd3190();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar6 = uVar6 | 4;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_00bd30e0();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 8) != 0) {
    uVar6 = uVar6 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 4) != 0) {
    uVar6 = uVar6 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(iVar2 + 0x48);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 9;
    uVar6 = uVar6 | 0x20;
  }
  else {
    uStack_ec = thunk_FUN_009eb4b0();
    puStack_e8 = (undefined4 *)0x0;
    uStack_e4 = *puVar5;
    puStack_e8 = (undefined4 *)FUN_009eb560();
    puVar5 = &uStack_ec;
    uStack_8 = 8;
    uVar6 = uVar6 | 0x10;
  }
  uStack_14 = uVar6;
  uVar3 = thunk_FUN_009eb4b0();
  uVar4 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 0x20) != 0) {
    uVar6 = uVar6 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 0x10) != 0) {
    uVar6 = uVar6 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(iVar2 + 0x4c);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 0xd;
    uVar6 = uVar6 | 0x80;
  }
  else {
    uStack_28c = FUN_0090c030();
    iStack_288 = 0;
    auStack_284[0] = *puVar5;
    iStack_288 = FUN_0090c4c0();
    puVar5 = &uStack_28c;
    uStack_8 = 0xc;
    uVar6 = uVar6 | 0x40;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0090c030();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((char)uVar6 < '\0') {
    uVar6 = uVar6 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar6;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar6 & 0x40) != 0) && (uStack_8 = 0xf, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26278 ; VA 0x00bc94b0 ; FUN_00bc94b0 */

void __thiscall FUN_00bc94b0(undefined4 param_1,uint param_2)

{
  uint *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  uint *in_stack_00000020;
  uint in_stack_00000024;
  uint in_stack_00000044;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined8 in_stack_0000005c;
  uint auStack_1b4 [2];
  undefined4 uStack_1ac;
  undefined4 uStack_1a8;
  undefined4 uStack_1a4;
  undefined4 *puStack_1a0;
  undefined8 uStack_19c;
  undefined auStack_190 [104];
  undefined auStack_128 [48];
  undefined uStack_f8;
  undefined4 uStack_58;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fec6e;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_19c = CONCAT44(param_1,0xbc94de);
  ExceptionList = &pvStack_10;
  FUN_008f7870();
  uStack_19c = CONCAT44(0xbc94e8,(undefined4)uStack_19c);
  uVar2 = FUN_008f7f00();
  uStack_19c = CONCAT44(uVar2,in_stack_00000020);
  puStack_1a0 = &param_2;
  uStack_1a4 = 0xbc94fb;
  FUN_014cc090();
  uStack_8._0_1_ = 3;
  uStack_19c = CONCAT44(0xbc950a,(undefined4)uStack_19c);
  FUN_00bc6ff0();
  uStack_19c = 0x60195d6a0;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  puStack_1a0 = (undefined4 *)0xbc9520;
  FUN_005542c0();
  uStack_19c = CONCAT44(&stack0x00000024,0xbc952c);
  FUN_008c4480();
  uStack_19c = CONCAT44(&stack0x00000044,0xbc9538);
  FUN_008c4480();
  uStack_58 = in_stack_0000001c;
  puVar3 = &DAT_01d79fc8;
  if (0xf < DAT_01d79fdc) {
    puVar3 = DAT_01d79fc8;
  }
  uStack_19c = CONCAT44(DAT_01d79fd8,puVar3);
  puStack_1a0 = (undefined4 *)0xbc9563;
  FUN_005542c0();
  uStack_19c = CONCAT44(auStack_190,0xbc9575);
  FUN_00bc7cb0();
  in_stack_00000020 = auStack_1b4;
  uStack_f8 = 0;
  auStack_1b4[0] = 0;
  puVar1 = auStack_1b4;
  if (in_stack_00000044 != 0) {
    auStack_1b4[0] = in_stack_00000044;
    if ((in_stack_00000044 & 1) == 0) {
      (**(code **)(in_stack_00000044 & 0xfffffffe))(&stack0x0000004c,&uStack_1ac,0);
      puVar1 = in_stack_00000020;
    }
    else {
      uStack_1ac = in_stack_0000004c;
      uStack_1a8 = in_stack_00000050;
      uStack_1a4 = in_stack_00000054;
      puStack_1a0 = (undefined4 *)in_stack_00000058;
      uStack_19c = in_stack_0000005c;
      puVar1 = auStack_1b4;
    }
  }
  in_stack_00000020 = puVar1;
  FUN_00bca580(auStack_128,&stack0x0000001c);
  uStack_19c = CONCAT44(0xbc95dd,(undefined4)uStack_19c);
  FUN_00bc7880();
  uStack_19c = CONCAT44(0xbc95e8,(undefined4)uStack_19c);
  FUN_0056db40();
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    uVar5 = in_stack_00000018 + 1;
    uVar4 = param_2;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(param_2 - 4);
      uVar5 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - uVar4) - 4) {
        uStack_19c = CONCAT44(&UNK_00bc9696,(undefined4)uStack_19c);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_19c = CONCAT44(uVar5,uVar4);
    puStack_1a0 = (undefined4 *)0xbc9619;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (in_stack_00000024 != 0) {
    if (((in_stack_00000024 & 1) == 0) &&
       (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
      puStack_1a0 = (undefined4 *)&stack0x0000002c;
      uStack_19c = CONCAT44(2,puStack_1a0);
      uStack_1a4 = 0xbc964f;
      (**(code **)(in_stack_00000024 & 0xfffffffe))();
    }
    in_stack_00000024 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) &&
     (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
    puStack_1a0 = &stack0x0000004c;
    uStack_19c = CONCAT44(2,puStack_1a0);
    uStack_1a4 = 0xbc967d;
    (**(code **)(in_stack_00000044 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26279 ; VA 0x00bc96a0 ; FUN_00bc96a0 */

void FUN_00bc96a0(undefined4 param_1,int *param_2,uint param_3)

{
  code *pcVar1;
  int *piVar2;
  undefined uVar3;
  char cVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  int iVar8;
  uint uVar9;
  int *piVar10;
  uint in_stack_0000002c;
  undefined4 uStack_138;
  int iStack_134;
  undefined auStack_130 [200];
  int aiStack_68 [5];
  uint uStack_54;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  int *piStack_38;
  int *piStack_34;
  int *piStack_30;
  undefined uStack_2c;
  undefined auStack_20 [4];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_2;
  puStack_c = &LAB_017fecd4;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  uVar5 = (**(code **)*param_2)();
  if (uVar5 < 5) {
LAB_00bc977f:
    if (*(undefined4 **)(iStack_14 + 0x50) == (undefined4 *)0x0) {
      uVar6 = 5;
      goto LAB_00bc9b30;
    }
    piVar10 = (int *)**(undefined4 **)(iStack_14 + 0x50);
  }
  else {
    pcVar1 = *(code **)(*piVar2 + 0x38);
    uVar6 = FUN_0090c030();
    cVar4 = (*pcVar1)(5,uVar6,&param_2);
    piVar10 = param_2;
    if (cVar4 == '\0') {
      uStack_138 = FUN_00888530();
      iStack_134 = 0;
      uStack_8._0_1_ = 2;
      cVar4 = (**(code **)(*piVar2 + 4))(5,&uStack_138);
      if (cVar4 == '\0') {
        uStack_8._0_1_ = 4;
        if (iStack_134 != 0) {
          (**(code **)(iStack_134 + 8))(auStack_130);
        }
        uStack_8._0_1_ = 1;
        goto LAB_00bc977f;
      }
      puVar7 = (undefined4 *)FUN_00bc51f0();
      piVar10 = (int *)*puVar7;
      uStack_8._0_1_ = 3;
      if (iStack_134 != 0) {
        (**(code **)(iStack_134 + 8))(auStack_130);
      }
      uStack_8._0_1_ = 1;
    }
  }
  piStack_34 = piVar10;
  uVar5 = (**(code **)*piVar2)();
  if (uVar5 < 4) {
LAB_00bc9844:
    if (*(undefined4 **)(iStack_14 + 0x4c) == (undefined4 *)0x0) {
      uVar6 = 4;
      goto LAB_00bc9b30;
    }
    piVar10 = (int *)**(undefined4 **)(iStack_14 + 0x4c);
  }
  else {
    pcVar1 = *(code **)(*piVar2 + 0x38);
    uVar6 = FUN_009eb4b0();
    cVar4 = (*pcVar1)(4,uVar6,&param_2);
    piVar10 = param_2;
    if (cVar4 == '\0') {
      uStack_138 = FUN_00888530();
      iStack_134 = 0;
      uStack_8._0_1_ = 5;
      cVar4 = (**(code **)(*piVar2 + 4))(4,&uStack_138);
      if (cVar4 == '\0') {
        uStack_8._0_1_ = 7;
        if (iStack_134 != 0) {
          (**(code **)(iStack_134 + 8))(auStack_130);
        }
        uStack_8._0_1_ = 1;
        goto LAB_00bc9844;
      }
      puVar7 = (undefined4 *)FUN_009e22f0();
      piVar10 = (int *)*puVar7;
      uStack_8._0_1_ = 6;
      if (iStack_134 != 0) {
        (**(code **)(iStack_134 + 8))(auStack_130);
      }
      uStack_8._0_1_ = 1;
    }
  }
  piStack_38 = piVar10;
  uVar5 = (**(code **)*piVar2)();
  if (uVar5 < 3) {
LAB_00bc9915:
    if (*(undefined4 **)(iStack_14 + 0x48) == (undefined4 *)0x0) {
      uVar6 = 3;
      goto LAB_00bc9b30;
    }
    param_2 = (int *)**(undefined4 **)(iStack_14 + 0x48);
  }
  else {
    pcVar1 = *(code **)(*piVar2 + 0x38);
    uVar6 = FUN_00bd30e0();
    cVar4 = (*pcVar1)(3,uVar6,&param_2);
    if (cVar4 == '\0') {
      uStack_138 = FUN_00888530();
      iStack_134 = 0;
      uStack_8._0_1_ = 8;
      cVar4 = (**(code **)(*piVar2 + 4))(3,&uStack_138);
      if (cVar4 == '\0') {
        uStack_8._0_1_ = 10;
        if (iStack_134 != 0) {
          (**(code **)(iStack_134 + 8))(auStack_130);
        }
        uStack_8._0_1_ = 1;
        goto LAB_00bc9915;
      }
      puVar7 = (undefined4 *)FUN_00bc52c0();
      piStack_30 = (int *)*puVar7;
      uStack_8._0_1_ = 9;
      if (iStack_134 != 0) {
        (**(code **)(iStack_134 + 8))(auStack_130);
      }
      uStack_8._0_1_ = 1;
      param_2 = piStack_30;
    }
  }
  uVar5 = (**(code **)*piVar2)();
  if (1 < uVar5) {
    uStack_1c = 0;
    uStack_18 = 0xf;
    uStack_2c = 0;
    uStack_8._0_1_ = 0xb;
    uStack_138 = FUN_00888530();
    iStack_134 = 0;
    uStack_8._0_1_ = 0xc;
    cVar4 = (**(code **)(*piVar2 + 4))(2,&uStack_138);
    if (cVar4 != '\0') {
      uVar6 = FUN_008898b0();
      FUN_0054ef60(uVar6);
      uStack_8._0_1_ = 0xd;
      if (iStack_134 != 0) {
        (**(code **)(iStack_134 + 8))(auStack_130);
      }
      FUN_005507b0();
      goto LAB_00bc99f6;
    }
    uStack_8._0_1_ = 0xe;
    if (iStack_134 != 0) {
      (**(code **)(iStack_134 + 8))(auStack_130);
    }
    uStack_8._0_1_ = 1;
    FUN_005507b0();
  }
  if (*(int *)(iStack_14 + 0x44) == 0) {
    uVar6 = 2;
LAB_00bc9b30:
    FUN_016756b0(auStack_20,"Argument %d missing or nil",uVar6);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_20,&DAT_01c17198);
  }
  FUN_0054ef60(*(int *)(iStack_14 + 0x44));
LAB_00bc99f6:
  uStack_8._0_1_ = 0xf;
  uVar6 = FUN_008cca80(auStack_50,piVar2,iStack_14 + 0x40);
  uStack_8._0_1_ = 0x10;
  FUN_00bc8360(param_1,*(undefined4 *)(iStack_14 + 0x38),*(undefined4 *)(iStack_14 + 0x3c),uVar6,
               aiStack_68,&param_2,&piStack_38,&piStack_34,&param_3,&stack0x0000002c);
  uStack_8._0_1_ = 0xf;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xf;
  if (0xf < uStack_3c) {
    uVar9 = uStack_3c + 1;
    uVar5 = auStack_50[0];
    if (0xfff < uVar9) {
      uVar5 = *(uint *)(auStack_50[0] - 4);
      uVar9 = uStack_3c + 0x24;
      if (0x1f < (auStack_50[0] - uVar5) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar9);
  }
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  uStack_8._0_1_ = 1;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_54) {
    uVar5 = uStack_54 + 1;
    iVar8 = aiStack_68[0];
    if (0xfff < uVar5) {
      iVar8 = *(int *)(aiStack_68[0] + -4);
      uVar5 = uStack_54 + 0x24;
      if (0x1f < (aiStack_68[0] - iVar8) - 4U) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar5);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_3 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_3 = 0;
  }
  uStack_8 = 0x12;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26280 ; VA 0x00bc9b50 ; FUN_00bc9b50 */

void FUN_00bc9b50(undefined4 param_1,int *param_2,uint param_3)

{
  int iVar1;
  code *pcVar2;
  int *piVar3;
  int iVar4;
  undefined uVar5;
  char cVar6;
  uint uVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  int iVar10;
  uint uVar11;
  uint in_stack_0000002c;
  undefined4 uStack_10c;
  int iStack_108;
  undefined auStack_104 [200];
  undefined auStack_3c [12];
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar3 = param_2;
  puStack_c = &LAB_017c3d23;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  uVar7 = (**(code **)*param_2)();
  if (2 < uVar7) {
    pcVar2 = *(code **)(*piVar3 + 0x38);
    uVar8 = FUN_0090c030();
    cVar6 = (*pcVar2)(3,uVar8,&param_2);
    piStack_18 = param_2;
    if (cVar6 != '\0') goto LAB_00bc9c3f;
    uStack_10c = FUN_00888530();
    iStack_108 = 0;
    uStack_8._0_1_ = 2;
    cVar6 = (**(code **)(*piVar3 + 4))(3,&uStack_10c);
    if (cVar6 != '\0') {
      puVar9 = (undefined4 *)FUN_00bc51f0();
      piStack_18 = (int *)*puVar9;
      uStack_8._0_1_ = 3;
      if (iStack_108 != 0) {
        (**(code **)(iStack_108 + 8))(auStack_104);
      }
      uStack_8._0_1_ = 1;
      goto LAB_00bc9c3f;
    }
    uStack_8._0_1_ = 4;
    if (iStack_108 != 0) {
      (**(code **)(iStack_108 + 8))(auStack_104);
    }
    uStack_8._0_1_ = 1;
  }
  if (*(undefined4 **)(iStack_14 + 0x48) == (undefined4 *)0x0) {
    FUN_016756b0(auStack_3c,"Argument %d missing or nil",3);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_3c,&DAT_01c17198);
  }
  piStack_18 = (int *)**(undefined4 **)(iStack_14 + 0x48);
LAB_00bc9c3f:
  iVar4 = iStack_14;
  iVar10 = FUN_00bcb0a0(piVar3,iStack_14 + 0x44);
  iVar1 = iStack_14 + 0x40;
  iStack_14 = iVar10;
  uVar8 = FUN_008cca80(auStack_30,piVar3,iVar1);
  uStack_8._0_1_ = 5;
  FUN_00bc80c0(param_1,*(undefined4 *)(iVar4 + 0x38),*(undefined4 *)(iVar4 + 0x3c),uVar8,&iStack_14,
               &piStack_18,&param_3,&stack0x0000002c);
  uStack_8._0_1_ = 1;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_1c) {
    uVar11 = uStack_1c + 1;
    uVar7 = auStack_30[0];
    if (0xfff < uVar11) {
      uVar7 = *(uint *)(auStack_30[0] - 4);
      uVar11 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar7) - 4) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar11);
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_3 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_3 = 0;
  }
  uStack_8 = 7;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26281 ; VA 0x00bc9d60 ; FUN_00bc9d60 */

void FUN_00bc9d60(undefined4 param_1,int *param_2,uint param_3)

{
  code *pcVar1;
  int iVar2;
  char cVar3;
  uint uVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 *puVar7;
  int *piVar8;
  int *piVar9;
  uint in_stack_0000002c;
  undefined4 uStack_100;
  int iStack_fc;
  undefined auStack_f8 [200];
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined auStack_20 [4];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar9 = param_2;
  puStack_c = &LAB_017fed21;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  uVar4 = (**(code **)*param_2)();
  if (uVar4 < 4) {
LAB_00bc9e3f:
    if (*(undefined4 **)(iStack_14 + 0x4c) == (undefined4 *)0x0) {
      uVar5 = 4;
      goto LAB_00bca0d1;
    }
    piVar8 = (int *)**(undefined4 **)(iStack_14 + 0x4c);
  }
  else {
    pcVar1 = *(code **)(*piVar9 + 0x38);
    uVar5 = FUN_0090c030();
    cVar3 = (*pcVar1)(4,uVar5,&param_2);
    piVar8 = param_2;
    if (cVar3 == '\0') {
      uStack_100 = FUN_00888530();
      iStack_fc = 0;
      uStack_8._0_1_ = 2;
      cVar3 = (**(code **)(*piVar9 + 4))(4,&uStack_100);
      if (cVar3 == '\0') {
        uStack_8._0_1_ = 4;
        if (iStack_fc != 0) {
          (**(code **)(iStack_fc + 8))(auStack_f8);
        }
        uStack_8._0_1_ = 1;
        goto LAB_00bc9e3f;
      }
      puVar7 = (undefined4 *)FUN_00bc51f0();
      piVar8 = (int *)*puVar7;
      uStack_8._0_1_ = 3;
      if (iStack_fc != 0) {
        (**(code **)(iStack_fc + 8))(auStack_f8);
      }
      uStack_8._0_1_ = 1;
    }
  }
  piStack_2c = piVar8;
  uVar4 = (**(code **)*piVar9)();
  if (uVar4 < 3) {
LAB_00bc9f04:
    if (*(undefined4 **)(iStack_14 + 0x48) == (undefined4 *)0x0) {
      uVar5 = 3;
      goto LAB_00bca0d1;
    }
    param_2 = (int *)**(undefined4 **)(iStack_14 + 0x48);
  }
  else {
    pcVar1 = *(code **)(*piVar9 + 0x38);
    uVar5 = FUN_009eb4b0();
    cVar3 = (*pcVar1)(3,uVar5,&param_2);
    if (cVar3 == '\0') {
      uStack_100 = FUN_00888530();
      iStack_fc = 0;
      uStack_8._0_1_ = 5;
      cVar3 = (**(code **)(*piVar9 + 4))(3,&uStack_100);
      if (cVar3 == '\0') {
        uStack_8._0_1_ = 7;
        if (iStack_fc != 0) {
          (**(code **)(iStack_fc + 8))(auStack_f8);
        }
        uStack_8._0_1_ = 1;
        goto LAB_00bc9f04;
      }
      puVar7 = (undefined4 *)FUN_009e22f0();
      piVar8 = (int *)*puVar7;
      uStack_8._0_1_ = 6;
      if (iStack_fc != 0) {
        (**(code **)(iStack_fc + 8))(auStack_f8);
      }
      uStack_8._0_1_ = 1;
      param_2 = piVar8;
    }
  }
  iVar2 = iStack_14;
  uStack_30 = FUN_00bcb0a0(piVar9,iStack_14 + 0x44);
  iVar6 = (**(code **)*piVar9)();
  if (iVar6 != 0) {
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_8._0_1_ = 8;
    uStack_100 = FUN_00888530();
    iStack_fc = 0;
    uStack_8._0_1_ = 9;
    cVar3 = (**(code **)(*piVar9 + 4))(1,&uStack_100);
    if (cVar3 != '\0') {
      puVar7 = (undefined4 *)FUN_00887bf0();
      piVar9 = (int *)puVar7[1];
      if (piVar9 != (int *)0x0) {
        LOCK();
        piVar9[1] = piVar9[1] + 1;
        UNLOCK();
        piVar9 = (int *)puVar7[1];
      }
      uStack_28 = *puVar7;
      uStack_8._0_1_ = 10;
      piStack_24 = piVar9;
      if (iStack_fc != 0) {
        (**(code **)(iStack_fc + 8))(auStack_f8);
      }
      FUN_00550b30();
      goto LAB_00bca00e;
    }
    uStack_8._0_1_ = 0xb;
    if (iStack_fc != 0) {
      (**(code **)(iStack_fc + 8))(auStack_f8);
    }
    uStack_8._0_1_ = 1;
    FUN_00550b30();
  }
  puVar7 = *(undefined4 **)(iVar2 + 0x40);
  if (puVar7 == (undefined4 *)0x0) {
    uVar5 = 1;
LAB_00bca0d1:
    FUN_016756b0(auStack_20,"Argument %d missing or nil",uVar5);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_20,&DAT_01c17198);
  }
  piVar9 = (int *)puVar7[1];
  if (piVar9 != (int *)0x0) {
    LOCK();
    piVar9[1] = piVar9[1] + 1;
    UNLOCK();
    piVar9 = (int *)puVar7[1];
  }
  uStack_28 = *puVar7;
  piStack_24 = piVar9;
LAB_00bca00e:
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  FUN_00bc8200(param_1,*(undefined4 *)(iStack_14 + 0x38),*(undefined4 *)(iStack_14 + 0x3c),
               &uStack_28,&uStack_30,&param_2,&piStack_2c,&param_3,&stack0x0000002c);
  if (piVar9 != (int *)0x0) {
    LOCK();
    iVar2 = piVar9[1] + -1;
    piVar9[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar9)();
      LOCK();
      piVar8 = piVar9 + 2;
      iVar2 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar9 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_3 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_3 = 0;
  }
  uStack_8 = 0xe;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26282 ; VA 0x00bca100 ; FUN_00bca100 */

void __thiscall FUN_00bca100(int param_1,int param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  uint uVar3;
  char cVar4;
  undefined auStack_37c [8];
  undefined4 uStack_374;
  int iStack_370;
  undefined4 uStack_260;
  int iStack_25c;
  undefined4 *puStack_258;
  int iStack_254;
  uint uStack_250;
  undefined4 uStack_248;
  undefined4 uStack_244;
  undefined4 uStack_240;
  int iStack_23c;
  undefined8 uStack_238;
  uint uStack_230;
  undefined4 uStack_228;
  undefined4 uStack_224;
  undefined4 uStack_220;
  undefined4 uStack_21c;
  undefined8 uStack_218;
  undefined auStack_210 [348];
  undefined4 uStack_b4;
  int iStack_b0;
  int iStack_ac;
  int iStack_a8;
  int iStack_a4;
  int iStack_a0;
  undefined4 uStack_8c;
  int iStack_88;
  int iStack_84;
  undefined1 *puStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fed80;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(char *)(param_2 + 0x118) != '\0') {
    ExceptionList = &pvStack_10;
    *(int *)(param_2 + 0x108) = *(int *)(param_2 + 0x108) + 1;
  }
  iStack_88 = param_1 + 0x6c;
  if (0xf < *(uint *)(param_1 + 0x80)) {
    iStack_88 = *(int *)(param_1 + 0x6c);
  }
  uStack_7c = 0;
  puStack_80 = &DAT_018bc9b8;
  iStack_84 = *(undefined4 *)(param_1 + 0x7c);
  uStack_8c = 0xbca157;
  cVar4 = FUN_0055c360();
  uStack_7c = 0;
  iStack_370 = param_1;
  if (cVar4 == '\0') {
    iStack_a0 = 0;
    pcVar1 = *(code **)(**(int **)(param_2 + 0x11c) + 0x14);
    uVar2 = *(undefined4 *)(param_1 + 0xd0);
    uStack_18 = CONCAT31((int3)((uint)param_1 >> 8),DAT_01ef5a96);
    uStack_1c = CONCAT31(uStack_1c._1_3_,DAT_01ef5a95);
    uStack_230 = 0;
    uVar3 = *(uint *)(param_1 + 0xf8);
    if (uVar3 != 0) {
      uStack_230 = uVar3;
      if ((uVar3 & 1) == 0) {
        uStack_238 = ZEXT48(&uStack_228);
        iStack_23c = param_1 + 0x100;
        uStack_240 = 0xbca1ef;
        (**(code **)(uVar3 & 0xfffffffe))();
      }
      else {
        uStack_228 = *(undefined4 *)(param_1 + 0x100);
        uStack_224 = *(undefined4 *)(param_1 + 0x104);
        uStack_220 = *(undefined4 *)(param_1 + 0x108);
        uStack_21c = *(undefined4 *)(param_1 + 0x10c);
        uStack_218 = *(undefined8 *)(param_1 + 0x110);
      }
    }
    uStack_8 = 0;
    uStack_250 = 0;
    uVar3 = *(uint *)(param_1 + 0xd8);
    if (uVar3 != 0) {
      uStack_250 = uVar3;
      if ((uVar3 & 1) == 0) {
        puStack_258 = &uStack_248;
        iStack_254 = 0;
        iStack_25c = param_1 + 0xe0;
        uStack_260 = 0xbca249;
        (**(code **)(uVar3 & 0xfffffffe))();
      }
      else {
        uStack_248 = *(undefined4 *)(param_1 + 0xe0);
        uStack_244 = *(undefined4 *)(param_1 + 0xe4);
        uStack_240 = *(undefined4 *)(param_1 + 0xe8);
        iStack_23c = *(int *)(param_1 + 0xec);
        uStack_238 = *(ulonglong *)(param_1 + 0xf0);
      }
    }
    uStack_8._0_1_ = 1;
    uStack_374 = 0xbca264;
    iStack_254 = uVar2;
    FUN_00bc6e60();
    iStack_370 = uStack_18;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_374 = uStack_1c;
    FUN_0060e0c0(auStack_37c,param_2);
    uStack_8 = 0xffffffff;
    FUN_00bc4fe0(auStack_210,FUN_00bcbed0);
    uStack_218 = CONCAT44(0xbca29f,(undefined4)uStack_218);
    FUN_00bc4210();
    iStack_a4 = param_1 + 0x9c;
    iStack_a0 = 0;
    iStack_a8 = param_1 + 0x84;
    iStack_ac = param_1 + 0x6c;
    uStack_b4 = 0xbca2ba;
    iStack_b0 = param_1;
    (*pcVar1)();
    ExceptionList = pvStack_10;
    return;
  }
  if (*(char *)(param_1 + 0x68) != '\0') {
    uVar2 = *(undefined4 *)(param_1 + 0xd0);
    iStack_a0 = 0;
    pcVar1 = *(code **)(**(int **)(param_2 + 0x11c) + 4);
    uStack_2c = CONCAT31(uStack_2c._1_3_,DAT_01ef5a96);
    uStack_28 = CONCAT31(uStack_28._1_3_,DAT_01ef5a95);
    uStack_238 = CONCAT44(param_1 + 0xf8,0xbca324);
    FUN_0054f510();
    iStack_254 = param_1 + 0xd8;
    uStack_8 = 3;
    puStack_258 = (undefined4 *)0xbca341;
    FUN_0054f510();
    uStack_8._0_1_ = 4;
    uStack_374 = 0xbca35a;
    iStack_254 = uVar2;
    FUN_00bc6e60();
    iStack_370 = uStack_2c;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    uStack_374 = uStack_28;
    FUN_0060e0c0(auStack_37c,param_2);
    uStack_8 = 0xffffffff;
    FUN_00bc4fe0(auStack_210,FUN_00bcbed0);
    uStack_218 = CONCAT44(0xbca395,(undefined4)uStack_218);
    FUN_00bc4210();
    iStack_a4 = param_1 + 0x9c;
    iStack_a0 = 0;
    iStack_a8 = param_1 + 0x84;
    iStack_b0 = 0xbca3ac;
    iStack_ac = param_1;
    (*pcVar1)();
    ExceptionList = pvStack_10;
    return;
  }
  if (*(char *)(param_1 + 0xb4) == '\0') {
    puStack_80 = (undefined1 *)0x0;
    uStack_8 = 6;
    iStack_84 = param_1 + 0xb8;
    uStack_8c = 0xbca3e6;
    iStack_88 = param_1;
    (**(code **)(**(int **)(param_2 + 0x11c) + 0x10))();
    ExceptionList = pvStack_10;
    return;
  }
  uVar2 = *(undefined4 *)(param_1 + 0xd0);
  iStack_a0 = 0;
  pcVar1 = *(code **)(**(int **)(param_2 + 0x11c) + 8);
  uStack_2c = CONCAT31(uStack_2c._1_3_,DAT_01ef5a96);
  uStack_28 = CONCAT31(uStack_28._1_3_,DAT_01ef5a95);
  uStack_238 = CONCAT44(param_1 + 0xf8,0xbca494);
  FUN_0054f510();
  iStack_254 = param_1 + 0xd8;
  uStack_8 = 9;
  puStack_258 = (undefined4 *)0xbca4b1;
  FUN_0054f510();
  uStack_8._0_1_ = 10;
  uStack_374 = 0xbca4ca;
  iStack_254 = uVar2;
  FUN_00bc6e60();
  iStack_370 = uStack_2c;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  uStack_374 = uStack_28;
  FUN_0060e0c0(auStack_37c,param_2);
  uStack_8 = 0xffffffff;
  FUN_00bc4fe0(auStack_210,FUN_00bcbed0);
  uStack_218 = CONCAT44(0xbca505,(undefined4)uStack_218);
  FUN_00bc4210();
  iStack_a4 = 0xbca50c;
  iStack_a0 = param_1;
  (*pcVar1)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26283 ; VA 0x00bca3f9 ; Catch@00bca3f9 */

undefined4 Catch_00bca3f9(void)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int unaff_EBP;
  
  iVar1 = *(int *)(unaff_EBP + -0x14);
  uVar3 = *(undefined4 *)(unaff_EBP + -0x38);
  *(undefined *)(unaff_EBP + -0x28) = *(undefined *)(*(int *)(unaff_EBP + 8) + 0x118);
  cVar2 = FUN_00bd3010(uVar3,iVar1,*(undefined4 *)(unaff_EBP + -0x28));
  if (cVar2 == '\0') {
    FUN_0054fe90(uVar3);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(unaff_EBP + -0x50,&DAT_01c243ac);
  }
  cVar2 = FUN_00bd2c80(*(int *)(unaff_EBP + 8) + 0x11c,iVar1,iVar1 + 0xb8);
  if (cVar2 != '\0') {
    return 0xbca50c;
  }
  uVar3 = FUN_005543f0();
  FUN_01675640(unaff_EBP + -0x68,
               "Could not get a valid response for %s after retrying synchronous get.",uVar3);
  *(undefined *)(unaff_EBP + -4) = 8;
  uVar3 = FUN_005543f0();
  FUN_00550130(uVar3);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(unaff_EBP + -0x44,&DAT_01c17198);
}



/* FUNCTION 26284 ; VA 0x00bca580 ; FUN_00bca580 */

undefined __thiscall
FUN_00bca580(int param_1,undefined4 param_2,int *param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined8 param_10)

{
  int iVar1;
  char cVar2;
  uint uVar3;
  uint uVar4;
  undefined4 in_stack_ffffff28;
  undefined4 in_stack_ffffff2c;
  undefined auStack_98 [16];
  int iStack_88;
  uint uStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  uint auStack_28 [4];
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017fedc3;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_009e2820(param_2);
  FUN_0056db40();
  if (iStack_88 == 0) {
    iStack_18 = iStack_88;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("Empty URL",9);
    iStack_8._0_1_ = 1;
    uStack_48 = 0;
    if (param_4 != 0) {
      uStack_48 = param_4;
      if ((param_4 & 1) == 0) {
        (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_40,0);
      }
      else {
        uStack_40 = param_6;
        uStack_3c = param_7;
        uStack_38 = param_8;
        uStack_34 = param_9;
        uStack_30 = param_10;
      }
    }
    iStack_8._0_1_ = 2;
    if (uStack_48 != 0) {
      FUN_0054ef60(auStack_28);
      FUN_005e65e0();
    }
    iStack_8._0_1_ = 3;
    if (uStack_48 != 0) {
      if (((uStack_48 & 1) == 0) && (*(code **)(uStack_48 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_48 & 0xfffffffe))(&uStack_40,&uStack_40,2);
      }
      uStack_48 = 0;
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_14) {
      uVar4 = uStack_14 + 1;
      uVar3 = auStack_28[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_28[0] - 4);
        uVar4 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
      param_2._3_1_ = 0;
      goto LAB_00bca866;
    }
LAB_00bca93b:
    param_2._3_1_ = 0;
  }
  else {
    FUN_009e2820(param_2);
    iStack_8._0_1_ = 4;
    cVar2 = FUN_00bcc980(auStack_98);
    iStack_8._0_1_ = 0;
    FUN_0056db40();
    if (cVar2 == '\0') {
      iStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = (uint)auStack_28[0]._1_3_ << 8;
      FUN_005542c0("Non-trusted BaseURL used. HttpRbxApiService is only for Roblox API calls.",0x49)
      ;
      iStack_8 = CONCAT31(iStack_8._1_3_,5);
      FUN_0054f510(&param_4);
      FUN_00bd2de0(auStack_28,in_stack_ffffff28,in_stack_ffffff2c);
      FUN_005507b0();
      param_2._3_1_ = 0;
      goto LAB_00bca866;
    }
    iVar1 = *param_3;
    if (iVar1 == 0) {
      if (*(char *)(param_1 + 0xfa) != '\0') {
        FUN_0054f510(&param_4);
        cVar2 = FUN_00bd3480(param_2,param_1 + 0x58,param_1 + 0x68,in_stack_ffffff28,
                             in_stack_ffffff2c);
        if (cVar2 != '\0') goto LAB_00bca93b;
      }
      cVar2 = FUN_0098c5a0(param_1,1);
      if (cVar2 != '\0') {
        FUN_0054f510(&param_4);
        cVar2 = FUN_00bd3480(param_2,param_1 + 0x58,param_1 + 0x68,in_stack_ffffff28,
                             in_stack_ffffff2c);
        if (cVar2 != '\0') goto LAB_00bca93b;
      }
      cVar2 = FUN_00973950(param_1,1);
      if (cVar2 != '\0') {
        FUN_0054f510(&param_4);
        cVar2 = FUN_00bd3480(param_2,param_1 + 0x60,param_1 + 0x98,in_stack_ffffff28,
                             in_stack_ffffff2c);
joined_r0x00bca935:
        if (cVar2 != '\0') goto LAB_00bca93b;
      }
    }
    else if (iVar1 == 1) {
      if (*(char *)(param_1 + 0xfa) != '\0') {
        FUN_0054f510(&param_4);
        cVar2 = FUN_00bd3480(param_2,param_1 + 0x5c,param_1 + 0x80,in_stack_ffffff28,
                             in_stack_ffffff2c);
        if (cVar2 != '\0') goto LAB_00bca93b;
      }
      cVar2 = FUN_0098c5a0(param_1,1);
      if (cVar2 != '\0') {
        FUN_0054f510(&param_4);
        cVar2 = FUN_00bd3480(param_2,param_1 + 0x5c,param_1 + 0x80,in_stack_ffffff28,
                             in_stack_ffffff2c);
        if (cVar2 != '\0') goto LAB_00bca93b;
      }
      cVar2 = FUN_00973950(param_1,1);
      if (cVar2 != '\0') {
        FUN_0054f510(&param_4);
        cVar2 = FUN_00bd3480(param_2,param_1 + 0x60,param_1 + 0x98,in_stack_ffffff28,
                             in_stack_ffffff2c);
        goto joined_r0x00bca935;
      }
    }
    else if (iVar1 != 2) {
      iStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = (uint)auStack_28[0]._1_3_ << 8;
      FUN_005542c0("No priority set for API proxy request, please set a priority.",0x3d);
      iStack_8 = CONCAT31(iStack_8._1_3_,6);
      FUN_0054f510(&param_4);
      FUN_00bd2de0(auStack_28,in_stack_ffffff28,in_stack_ffffff2c);
      FUN_005507b0();
      param_2._3_1_ = 0;
      goto LAB_00bca866;
    }
    FUN_00bca100(param_1);
    param_2._3_1_ = 1;
  }
LAB_00bca866:
  iStack_8 = 7;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_4 & 0xfffffffe))(&param_6,&param_6,2);
  }
  ExceptionList = pvStack_10;
  return param_2._3_1_;
}



/* FUNCTION 26285 ; VA 0x00bca950 ; FUN_00bca950 */

void __fastcall FUN_00bca950(int param_1)

{
  int iVar1;
  uint *puVar2;
  void **ppvVar3;
  uint uStack_150;
  undefined4 uStack_14c;
  uint uStack_148;
  char *pcStack_144;
  float fStack_140;
  undefined4 uStack_13c;
  undefined8 uStack_138;
  undefined auStack_12c [48];
  undefined uStack_fc;
  undefined uStack_c4;
  undefined uStack_c0;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined uStack_a8;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined uStack_90;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined uStack_78;
  undefined uStack_74;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  uint uStack_34;
  uint uStack_2c;
  char *pcStack_28;
  float fStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fee1f;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0xb4);
  if (iVar1 != 0) {
    ppvVar3 = &pvStack_10;
    if (DAT_01ef5a94 != 0) {
      uStack_13c = *(undefined4 *)(param_1 + 100);
      uStack_138 = 0;
      uStack_148 = (uint)DAT_01ef5a94;
      fStack_140 = (float)((double)iVar1 + (double)(&DAT_018c0d90)[-(iVar1 >> 0x1f)]);
      pcStack_144 = "Executing retry requests, size: %f, budget: %f";
      uStack_14c = 0xbca9d2;
      ExceptionList = &pvStack_10;
      FUN_016774d0();
      iVar1 = *(int *)(param_1 + 0xb4);
      ppvVar3 = (void **)ExceptionList;
    }
    while ((ExceptionList = ppvVar3, iVar1 != 0 && (0.0 <= *(float *)(param_1 + 100)))) {
      *(float *)(param_1 + 100) = *(float *)(param_1 + 100) - DAT_018ce2f8;
      uStack_138 = 0;
      uStack_13c = 0xbcaa1a;
      FUN_014cc1b0();
      uStack_b0 = 0;
      uStack_ac = 0xf;
      uStack_c0 = 0;
      uStack_98 = 0;
      uStack_94 = 0xf;
      uStack_a8 = 0;
      uStack_80 = 0;
      uStack_7c = 0xf;
      uStack_90 = 0;
      uStack_64 = 0;
      uStack_60 = 0xf;
      uStack_74 = 0;
      uStack_54 = 0;
      uStack_34 = 0;
      uStack_138 = 0x18bc9b8;
      uStack_8 = 6;
      uStack_58 = 0;
      uStack_13c = 0xbcaaa9;
      FUN_005542c0();
      uStack_138 = 0x18bc9b8;
      uStack_13c = 0xbcaabb;
      FUN_005542c0();
      uStack_138 = 0x18bc9b8;
      uStack_13c = 0xbcaacd;
      FUN_005542c0();
      uStack_138 = 0x18bc9b8;
      uStack_78 = 1;
      uStack_c4 = 0;
      uStack_13c = 0xbcaae7;
      FUN_005542c0();
      uStack_5c = 0;
      uStack_fc = 0;
      uStack_8 = 7;
      uStack_138 = CONCAT44(*(int *)(param_1 + 0xb0) * 0x118 + *(int *)(param_1 + 0xb8),0xbcab18);
      FUN_00bc7d50();
      puStack_14 = (undefined *)&uStack_150;
      *(int *)(param_1 + 0xb4) = *(int *)(param_1 + 0xb4) + -1;
      *(uint *)(param_1 + 0xb0) = *(uint *)(param_1 + 0xc4) & *(int *)(param_1 + 0xb0) + 1U;
      uStack_150 = 0;
      puVar2 = &uStack_150;
      if (uStack_34 != 0) {
        uStack_150 = uStack_34;
        if ((uStack_34 & 1) == 0) {
          (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_148,0);
          puVar2 = (uint *)puStack_14;
        }
        else {
          uStack_148 = uStack_2c;
          pcStack_144 = pcStack_28;
          fStack_140 = fStack_24;
          uStack_13c = uStack_20;
          uStack_138 = uStack_1c;
          puVar2 = &uStack_150;
        }
      }
      puStack_14 = (undefined *)puVar2;
      FUN_00bca580(auStack_12c,&uStack_5c);
      uStack_8 = 0xffffffff;
      uStack_138 = CONCAT44(0xbcab9d,(undefined4)uStack_138);
      FUN_00bc7880();
      iVar1 = *(int *)(param_1 + 0xb4);
      ppvVar3 = (void **)ExceptionList;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26286 ; VA 0x00bcabc0 ; FUN_00bcabc0 */

void __thiscall FUN_00bcabc0(undefined4 param_1,uint *param_2,float *param_3)

{
  uint uVar1;
  void **ppvVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fee7f;
  pvStack_10 = ExceptionList;
  uVar1 = param_2[1];
  if (uVar1 != 0) {
    ppvVar2 = &pvStack_10;
    if (DAT_01ef5a94 != '\0') {
      ExceptionList = &pvStack_10;
      FUN_016774d0(DAT_01ef5a94,"Executing throttled requests, size: %f, budget: %f",
                   (float)((double)(int)uVar1 + (double)(&DAT_018c0d90)[-((int)uVar1 >> 0x1f)]),
                   *param_3,0,0);
      uVar1 = param_2[1];
      ppvVar2 = (void **)ExceptionList;
    }
    while ((ExceptionList = ppvVar2, uVar1 != 0 && (0.0 <= *param_3))) {
      *param_3 = *param_3 - DAT_018ce2f8;
      FUN_014cc1b0(0,0);
      uStack_8 = 6;
      FUN_005542c0(&DAT_018bc9b8,0);
      FUN_005542c0(&DAT_018bc9b8,0);
      FUN_005542c0(&DAT_018bc9b8,0);
      FUN_005542c0(&DAT_018bc9b8,0);
      uStack_8 = 7;
      FUN_00bc7d50(*param_2 * 0x118 + param_2[2]);
      param_2[1] = param_2[1] - 1;
      *param_2 = *param_2 + 1 & param_2[5];
      FUN_00bca100(param_1);
      uStack_8 = 0xffffffff;
      FUN_00bc7880();
      uVar1 = param_2[1];
      ppvVar2 = (void **)ExceptionList;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26287 ; VA 0x00bcadd0 ; FUN_00bcadd0 */

void FUN_00bcadd0(undefined4 param_1,uint param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined8 param_8,
                 uint *param_9)

{
  uint *puVar1;
  uint auStack_34 [2];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fee98;
  pvStack_10 = ExceptionList;
  uStack_14 = param_9;
  uStack_8 = 0;
  param_9 = auStack_34;
  auStack_34[0] = 0;
  ExceptionList = &pvStack_10;
  puVar1 = auStack_34;
  if (param_2 != 0) {
    auStack_34[0] = param_2;
    if ((param_2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_2c,0);
      puVar1 = param_9;
    }
    else {
      uStack_2c = param_4;
      uStack_28 = param_5;
      uStack_24 = param_6;
      uStack_20 = param_7;
      uStack_1c = param_8;
      ExceptionList = &pvStack_10;
      puVar1 = auStack_34;
    }
  }
  param_9 = puVar1;
  FUN_014ccc70();
  uStack_8 = 1;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    uStack_14 = 2;
    uStack_1c = CONCAT44(&param_4,&param_4);
    uStack_20 = 0xbcae62;
    (**(code **)(param_2 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26288 ; VA 0x00bcae80 ; FUN_00bcae80 */

void FUN_00bcae80(undefined4 param_1,undefined4 param_2,undefined4 ***param_3)

{
  undefined4 ***pppuVar1;
  undefined auStack_128 [48];
  undefined uStack_f8;
  undefined uStack_74;
  undefined4 **appuStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  undefined4 uStack_58;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017feebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00bc6ff0();
  uStack_8 = 0;
  uStack_74 = 0;
  uStack_58 = param_2;
  FUN_00bc7cb0(param_1);
  uStack_f8 = 0;
  FUN_00bca580(auStack_128,&param_2,0);
  if (param_3 != appuStack_70) {
    pppuVar1 = appuStack_70;
    if (0xf < uStack_5c) {
      pppuVar1 = (undefined4 ***)appuStack_70[0];
    }
    FUN_005542c0(pppuVar1,uStack_60);
  }
  FUN_00bc7880();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26289 ; VA 0x00bcaf30 ; FUN_00bcaf30 */

void __thiscall
FUN_00bcaf30(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined auStack_a8 [104];
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017feeeb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005f3cd0(auStack_40,&DAT_01d67e08,param_1 + 0xe0);
  uStack_8 = 0;
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  piVar2 = (int *)FUN_00554150(param_2,*puVar1);
  iStack_28 = *piVar2;
  iStack_24 = piVar2[1];
  iStack_20 = piVar2[2];
  iStack_1c = piVar2[3];
  uStack_18 = *(undefined8 *)(piVar2 + 4);
  piVar2[4] = 0;
  piVar2[5] = 0xf;
  *(undefined *)piVar2 = 0;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_2c) {
    uVar5 = uStack_2c + 1;
    uVar6 = auStack_40[0];
    if (0xfff < uVar5) {
      uVar6 = *(uint *)(auStack_40[0] - 4);
      uVar5 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar5);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_008f7870(param_1);
  uVar3 = FUN_008f7f00();
  FUN_014cc090(&iStack_28,param_5,uVar3);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00bcae80(auStack_a8,param_3,param_4);
  FUN_0056db40();
  if (0xf < uStack_18._4_4_) {
    uVar6 = uStack_18._4_4_ + 1;
    iVar4 = iStack_28;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iStack_28 + -4);
      uVar6 = uStack_18._4_4_ + 0x24;
      if (0x1f < (iStack_28 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26290 ; VA 0x00bcb0a0 ; FUN_00bcb0a0 */

int * FUN_00bcb0a0(int *param_1,int *param_2)

{
  code *pcVar1;
  int *piVar2;
  char cVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = (**(code **)*param_1)();
  if (1 < uVar4) {
    pcVar1 = *(code **)(*piVar2 + 0x38);
    uVar5 = FUN_00bd30e0();
    cVar3 = (*pcVar1)(2,uVar5,&param_1);
    if (cVar3 != '\0') {
      ExceptionList = pvStack_10;
      return param_1;
    }
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8 = 0;
    cVar3 = (**(code **)(*piVar2 + 4))(2,&uStack_ec);
    if (cVar3 != '\0') {
      puVar6 = (undefined4 *)FUN_00bc52c0();
      piVar2 = (int *)*puVar6;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return piVar2;
    }
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8 = 0xffffffff;
  }
  if ((undefined4 *)*param_2 != (undefined4 *)0x0) {
    ExceptionList = pvStack_10;
    return *(int **)*param_2;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 26291 ; VA 0x00bcb1e0 ; FUN_00bcb1e0 */

void __thiscall
FUN_00bcb1e0(int param_1,int param_2,undefined4 param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 *param_9,
            ulonglong param_10,uint param_11,undefined4 param_12,undefined1 *param_13,char *param_14
            ,undefined4 ***param_15,undefined4 param_16,undefined8 param_17)

{
  uint *puVar1;
  char cVar2;
  undefined4 *puVar3;
  uint auStack_78 [2];
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 *puStack_64;
  ulonglong uStack_60;
  uint auStack_58 [2];
  undefined1 *puStack_50;
  char *pcStack_4c;
  undefined4 **ppuStack_48;
  undefined4 *puStack_44;
  undefined8 uStack_40;
  undefined4 **appuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fef31;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined *)0x0;
  puVar3 = (undefined4 *)(param_2 + 0x18);
  uStack_8 = 1;
  uStack_40 = CONCAT44(puVar3,0xbcb219);
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00bcc980();
  if ((cVar2 == '\0') && (*(char *)(param_1 + 0x118) != '\0')) {
    appuStack_30[0] = (undefined4 **)((uint)appuStack_30[0] & 0xffffff00);
    uStack_8._0_1_ = 2;
    uStack_20 = 0;
    uStack_1c = 0xf;
    puStack_14 = (undefined *)0x1;
    uStack_40 = CONCAT44(*(int *)(param_2 + 0x28) + 0x17,0xbcb254);
    FUN_0058a190();
    uStack_40 = 0x170195d5c0;
    puStack_44 = (undefined4 *)0xbcb263;
    FUN_00554150();
    if (0xf < *(uint *)(param_2 + 0x2c)) {
      puVar3 = (undefined4 *)*puVar3;
    }
    uStack_40 = CONCAT44(*(undefined4 *)(param_2 + 0x28),puVar3);
    puStack_44 = (undefined4 *)0xbcb278;
    FUN_00554150();
    ppuStack_48 = appuStack_30;
    if (0xf < uStack_1c) {
      ppuStack_48 = appuStack_30[0];
    }
    uStack_40 = 0;
    puStack_44 = (undefined4 *)0x0;
    pcStack_4c = "HttpRbxApiService";
    puStack_50 = &DAT_018c5f98;
    auStack_58[1] = 0xbcb299;
    FUN_0087c450();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    uStack_40 = CONCAT44(0xbcb2a8,(undefined4)uStack_40);
    FUN_005507b0();
  }
  puStack_14 = (undefined *)auStack_58;
  puStack_18 = (undefined *)auStack_58;
  auStack_58[0] = 0;
  puVar1 = auStack_58;
  if (param_11 != 0) {
    auStack_58[0] = param_11;
    if ((param_11 & 1) == 0) {
      uStack_60 = ZEXT48(&puStack_50);
      puStack_64 = &param_13;
      uStack_68 = 0xbcb2ec;
      (**(code **)(param_11 & 0xfffffffe))();
      puVar1 = (uint *)puStack_14;
    }
    else {
      puStack_50 = param_13;
      pcStack_4c = param_14;
      ppuStack_48 = param_15;
      puStack_44 = (undefined4 *)param_16;
      uStack_40 = param_17;
      puVar1 = auStack_58;
    }
  }
  puStack_14 = (undefined *)puVar1;
  puStack_18 = (undefined *)auStack_78;
  uStack_8._0_1_ = 3;
  auStack_78[0] = 0;
  puVar1 = auStack_78;
  if (param_4 != 0) {
    auStack_78[0] = param_4;
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_70,0);
      puVar1 = (uint *)puStack_18;
    }
    else {
      uStack_70 = param_6;
      uStack_6c = param_7;
      uStack_68 = param_8;
      puStack_64 = param_9;
      uStack_60 = param_10;
      puVar1 = auStack_78;
    }
  }
  puStack_18 = (undefined *)puVar1;
  uStack_8._0_1_ = 1;
  FUN_00bcb9b0(param_2,&param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      puStack_44 = &param_6;
      uStack_40 = CONCAT44(2,puStack_44);
      ppuStack_48 = (undefined4 **)0xbcb36a;
      (**(code **)(param_4 & 0xfffffffe))();
    }
    param_4 = 0;
  }
  uStack_8 = 5;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_44 = &param_13;
    uStack_40 = CONCAT44(2,puStack_44);
    ppuStack_48 = (undefined4 **)0xbcb398;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26292 ; VA 0x00bcb3b0 ; FUN_00bcb3b0 */

void __thiscall FUN_00bcb3b0(int param_1,undefined4 *param_2)

{
  undefined uVar1;
  uint *puVar2;
  uint *puVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  uint uVar8;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 *in_stack_00000038;
  ulonglong in_stack_0000003c;
  uint in_stack_00000044;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined8 in_stack_0000005c;
  uint auStack_90 [2];
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 *puStack_7c;
  ulonglong uStack_78;
  uint auStack_70 [2];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  uint *puStack_5c;
  undefined8 uStack_58;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  undefined8 uStack_3c;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fef78;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  puStack_5c = auStack_34;
  uStack_58 = CONCAT44(param_1 + 0xe0,&DAT_01d67e08);
  uStack_60 = 0xbcb3ea;
  ExceptionList = &pvStack_10;
  FUN_005f3cd0();
  puVar6 = &param_2;
  if (0xf < in_stack_00000018) {
    puVar6 = param_2;
  }
  uStack_58 = CONCAT44(in_stack_00000014,puVar6);
  uStack_8._0_1_ = 3;
  puStack_5c = (uint *)0xbcb407;
  piVar4 = (int *)FUN_00554150();
  iStack_4c = *piVar4;
  iStack_48 = piVar4[1];
  iStack_44 = piVar4[2];
  iStack_40 = piVar4[3];
  uStack_3c = *(undefined8 *)(piVar4 + 4);
  piVar4[4] = 0;
  piVar4[5] = 0xf;
  *(undefined *)piVar4 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (0xf < uStack_20) {
    uVar7 = uStack_20 + 1;
    uVar8 = auStack_34[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_34[0] - 4);
      uVar7 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar8) - 4) {
        uStack_58 = CONCAT44(0xbcb612,(undefined4)uStack_58);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_58 = CONCAT44(uVar7,uVar8);
    puStack_5c = (uint *)0xbcb45e;
    FUN_01674ea0();
  }
  puStack_18 = (undefined *)auStack_70;
  puStack_14 = (undefined *)auStack_70;
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  auStack_70[0] = 0;
  puVar2 = auStack_70;
  if (in_stack_00000044 != 0) {
    auStack_70[0] = in_stack_00000044;
    if ((in_stack_00000044 & 1) == 0) {
      uStack_78 = ZEXT48(&uStack_68);
      puStack_7c = &stack0x0000004c;
      uStack_80 = 0xbcb4b7;
      (**(code **)(in_stack_00000044 & 0xfffffffe))();
      puVar2 = (uint *)puStack_14;
    }
    else {
      uStack_68 = in_stack_0000004c;
      uStack_64 = in_stack_00000050;
      uStack_60 = in_stack_00000054;
      puStack_5c = (uint *)in_stack_00000058;
      uStack_58 = in_stack_0000005c;
      puVar2 = auStack_70;
    }
  }
  puStack_14 = (undefined *)puVar2;
  puStack_18 = (undefined *)auStack_90;
  puStack_1c = (undefined *)auStack_90;
  uStack_8._0_1_ = 6;
  auStack_90[0] = 0;
  puVar2 = auStack_90;
  puVar3 = auStack_90;
  if (in_stack_00000024 != 0) {
    auStack_90[0] = in_stack_00000024;
    if ((in_stack_00000024 & 1) == 0) {
      (**(code **)(in_stack_00000024 & 0xfffffffe))(&stack0x0000002c,&uStack_88,0);
      puVar2 = (uint *)puStack_1c;
      puVar3 = (uint *)puStack_18;
    }
    else {
      uStack_88 = in_stack_0000002c;
      uStack_84 = in_stack_00000030;
      uStack_80 = in_stack_00000034;
      puStack_7c = in_stack_00000038;
      uStack_78 = in_stack_0000003c;
      puVar2 = auStack_90;
      puVar3 = auStack_90;
    }
  }
  puStack_18 = (undefined *)puVar3;
  puStack_1c = (undefined *)puVar2;
  uStack_8._0_1_ = 7;
  FUN_0054ef60(&iStack_4c);
  uStack_8._0_1_ = 5;
  FUN_00bcb620();
  uStack_8._0_1_ = 2;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_3c._4_4_) {
    uVar8 = uStack_3c._4_4_ + 1;
    iVar5 = iStack_4c;
    if (0xfff < uVar8) {
      iVar5 = *(int *)(iStack_4c + -4);
      uVar8 = uStack_3c._4_4_ + 0x24;
      if (0x1f < (iStack_4c - iVar5) - 4U) {
        uStack_58 = CONCAT44(0xbcb617,(undefined4)uStack_58);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_58 = CONCAT44(uVar8,iVar5);
    puStack_5c = (uint *)0xbcb55d;
    FUN_01674ea0();
  }
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    uVar8 = in_stack_00000018 + 1;
    puVar6 = param_2;
    if (0xfff < uVar8) {
      puVar6 = (undefined4 *)param_2[-1];
      uVar8 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar6))) {
        uStack_58 = CONCAT44(&UNK_00bcb61c,(undefined4)uStack_58);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_58 = CONCAT44(uVar8,puVar6);
    puStack_5c = (uint *)0xbcb595;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = (undefined4 *)((uint)param_2 & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (in_stack_00000024 != 0) {
    if (((in_stack_00000024 & 1) == 0) &&
       (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
      puStack_5c = &stack0x0000002c;
      uStack_58 = CONCAT44(2,puStack_5c);
      uStack_60 = 0xbcb5cb;
      (**(code **)(in_stack_00000024 & 0xfffffffe))();
    }
    in_stack_00000024 = 0;
  }
  uStack_8 = 9;
  if (((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) &&
     (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
    puStack_5c = &stack0x0000004c;
    uStack_58 = CONCAT44(2,puStack_5c);
    uStack_60 = 0xbcb5f9;
    (**(code **)(in_stack_00000044 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26293 ; VA 0x00bcb620 ; FUN_00bcb620 */

void __thiscall FUN_00bcb620(undefined4 param_1,uint param_2)

{
  undefined uVar1;
  uint *puVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint *in_stack_00000020;
  uint in_stack_00000024;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 *in_stack_00000038;
  ulonglong in_stack_0000003c;
  uint in_stack_00000044;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 *in_stack_00000058;
  undefined8 in_stack_0000005c;
  uint auStack_c0 [2];
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 *puStack_ac;
  ulonglong uStack_a8;
  uint auStack_a0 [2];
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 *puStack_8c;
  undefined8 uStack_88;
  undefined auStack_7c [104];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fefb8;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_88 = CONCAT44(param_1,0xbcb64b);
  ExceptionList = &pvStack_10;
  FUN_008f7870();
  uStack_88 = CONCAT44(0xbcb655,(undefined4)uStack_88);
  uVar3 = FUN_008f7f00();
  uStack_88 = CONCAT44(uVar3,in_stack_00000020);
  puStack_8c = &param_2;
  uStack_90 = 0xbcb665;
  FUN_014cc090();
  in_stack_00000020 = auStack_a0;
  puStack_14 = (undefined *)auStack_a0;
  uStack_8._0_1_ = 3;
  auStack_a0[0] = 0;
  puVar2 = auStack_a0;
  if (in_stack_00000044 != 0) {
    auStack_a0[0] = in_stack_00000044;
    if ((in_stack_00000044 & 1) == 0) {
      uStack_a8 = ZEXT48(&uStack_98);
      puStack_ac = &stack0x0000004c;
      uStack_b0 = 0xbcb6ad;
      (**(code **)(in_stack_00000044 & 0xfffffffe))();
      puVar2 = in_stack_00000020;
    }
    else {
      uStack_98 = in_stack_0000004c;
      uStack_94 = in_stack_00000050;
      uStack_90 = in_stack_00000054;
      puStack_8c = in_stack_00000058;
      uStack_88 = in_stack_0000005c;
      puVar2 = auStack_a0;
    }
  }
  in_stack_00000020 = puVar2;
  puStack_14 = (undefined *)auStack_c0;
  uStack_8._0_1_ = 4;
  auStack_c0[0] = 0;
  puVar2 = auStack_c0;
  if (in_stack_00000024 != 0) {
    auStack_c0[0] = in_stack_00000024;
    if ((in_stack_00000024 & 1) == 0) {
      (**(code **)(in_stack_00000024 & 0xfffffffe))(&stack0x0000002c,&uStack_b8,0);
      puVar2 = (uint *)puStack_14;
    }
    else {
      uStack_b8 = in_stack_0000002c;
      uStack_b4 = in_stack_00000030;
      uStack_b0 = in_stack_00000034;
      puStack_ac = in_stack_00000038;
      uStack_a8 = in_stack_0000003c;
      puVar2 = auStack_c0;
    }
  }
  puStack_14 = (undefined *)puVar2;
  uStack_8._0_1_ = 3;
  FUN_00bcb9b0(auStack_7c,&stack0x0000001c);
  uStack_88 = CONCAT44(0xbcb713,(undefined4)uStack_88);
  FUN_0056db40();
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    uVar5 = in_stack_00000018 + 1;
    uVar4 = param_2;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(param_2 - 4);
      uVar5 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - uVar4) - 4) {
        uStack_88 = CONCAT44(&UNK_00bcb7c1,(undefined4)uStack_88);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_88 = CONCAT44(uVar5,uVar4);
    puStack_8c = (undefined4 *)0xbcb744;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (in_stack_00000024 != 0) {
    if (((in_stack_00000024 & 1) == 0) &&
       (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
      puStack_8c = &stack0x0000002c;
      uStack_88 = CONCAT44(2,puStack_8c);
      uStack_90 = 0xbcb77a;
      (**(code **)(in_stack_00000024 & 0xfffffffe))();
    }
    in_stack_00000024 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) &&
     (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
    puStack_8c = &stack0x0000004c;
    uStack_88 = CONCAT44(2,puStack_8c);
    uStack_90 = 0xbcb7a8;
    (**(code **)(in_stack_00000044 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26294 ; VA 0x00bcb7d0 ; FUN_00bcb7d0 */

void FUN_00bcb7d0(uint param_1)

{
  int iVar1;
  undefined uVar2;
  uint *puVar3;
  uint *puVar4;
  char cVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 *in_stack_00000038;
  ulonglong in_stack_0000003c;
  uint in_stack_00000044;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined8 in_stack_0000005c;
  uint auStack_74 [2];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 *puStack_60;
  ulonglong uStack_5c;
  uint auStack_54 [2];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 *puStack_40;
  undefined8 uStack_3c;
  undefined auStack_2c [12];
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar1 = DAT_02131f70;
  puStack_c = &LAB_017feff8;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_3c = CONCAT44(0xbcb802,(undefined4)uStack_3c);
  ExceptionList = &pvStack_10;
  uVar6 = FUN_01255560();
  uStack_3c = CONCAT44(5,uVar6);
  puStack_40 = (undefined4 *)0xbcb80c;
  cVar5 = FUN_01255580();
  if (cVar5 == '\0') {
    uStack_3c = 5;
    puStack_40 = (undefined4 *)0xbcb81e;
    FUN_01255600();
  }
  if (iVar1 == 5) {
    puStack_18 = (undefined *)auStack_54;
    puStack_1c = (undefined *)auStack_54;
    auStack_54[0] = 0;
    puVar3 = auStack_54;
    if (in_stack_00000044 != 0) {
      auStack_54[0] = in_stack_00000044;
      if ((in_stack_00000044 & 1) == 0) {
        uStack_5c = ZEXT48(&uStack_4c);
        puStack_60 = &stack0x0000004c;
        uStack_64 = 0xbcb86b;
        (**(code **)(in_stack_00000044 & 0xfffffffe))();
        puVar3 = (uint *)puStack_18;
      }
      else {
        uStack_4c = in_stack_0000004c;
        uStack_48 = in_stack_00000050;
        uStack_44 = in_stack_00000054;
        puStack_40 = (undefined4 *)in_stack_00000058;
        uStack_3c = in_stack_0000005c;
        puVar3 = auStack_54;
      }
    }
    puStack_18 = (undefined *)puVar3;
    puStack_1c = (undefined *)auStack_74;
    puStack_20 = (undefined *)auStack_74;
    uStack_8._0_1_ = 3;
    auStack_74[0] = 0;
    puVar3 = auStack_74;
    puVar4 = auStack_74;
    if (in_stack_00000024 != 0) {
      auStack_74[0] = in_stack_00000024;
      if ((in_stack_00000024 & 1) == 0) {
        (**(code **)(in_stack_00000024 & 0xfffffffe))(&stack0x0000002c,&uStack_6c,0);
        puVar3 = (uint *)puStack_20;
        puVar4 = (uint *)puStack_1c;
      }
      else {
        uStack_6c = in_stack_0000002c;
        uStack_68 = in_stack_00000030;
        uStack_64 = in_stack_00000034;
        puStack_60 = in_stack_00000038;
        uStack_5c = in_stack_0000003c;
        puVar3 = auStack_74;
        puVar4 = auStack_74;
      }
    }
    puStack_1c = (undefined *)puVar4;
    puStack_20 = (undefined *)puVar3;
    uStack_8._0_1_ = 4;
    FUN_0054ef60(&param_1);
    uStack_8._0_1_ = 2;
    FUN_00bcb620();
    uStack_8._0_1_ = 1;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (0xf < in_stack_00000018) {
      uVar8 = in_stack_00000018 + 1;
      uVar7 = param_1;
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(param_1 - 4);
        uVar8 = in_stack_00000018 + 0x24;
        if (0x1f < (param_1 - uVar7) - 4) {
          uStack_3c = CONCAT44(&UNK_00bcb9ab,(undefined4)uStack_3c);
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_3c = CONCAT44(uVar8,uVar7);
      puStack_40 = (undefined4 *)0xbcb912;
      FUN_01674ea0();
    }
    in_stack_00000014 = 0;
    in_stack_00000018 = 0xf;
    param_1 = param_1 & 0xffffff00;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (in_stack_00000024 != 0) {
      if (((in_stack_00000024 & 1) == 0) &&
         (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
        puStack_40 = &stack0x0000002c;
        uStack_3c = CONCAT44(2,puStack_40);
        uStack_44 = 0xbcb948;
        (**(code **)(in_stack_00000024 & 0xfffffffe))();
      }
      in_stack_00000024 = 0;
    }
    uStack_8 = 6;
    if (((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) &&
       (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
      puStack_40 = &stack0x0000004c;
      uStack_3c = CONCAT44(2,puStack_40);
      uStack_44 = 0xbcb976;
      (**(code **)(in_stack_00000044 & 0xfffffffe))();
    }
    ExceptionList = pvStack_10;
    return;
  }
  uStack_3c = 0x18bc9b800bcb998;
  FUN_00550130();
  uStack_3c = CONCAT44(&DAT_01c17198,auStack_2c);
                    /* WARNING: Subroutine does not return */
  puStack_40 = (undefined4 *)0xbcb9a6;
  FUN_0170c2a8();
}



/* FUNCTION 26295 ; VA 0x00bcb9b0 ; FUN_00bcb9b0 */

void FUN_00bcb9b0(undefined4 param_1,undefined4 *param_2,uint param_3)

{
  uint in_stack_0000002c;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined4 in_stack_0000003c;
  undefined4 in_stack_00000040;
  undefined8 in_stack_00000044;
  undefined4 uStack_148;
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined4 *puStack_13c;
  undefined8 uStack_138;
  undefined auStack_128 [48];
  undefined uStack_f8;
  undefined4 uStack_58;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ff02b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_138 = CONCAT44(0xbcb9e4,(undefined4)uStack_138);
  ExceptionList = &pvStack_10;
  FUN_00bc6ff0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uStack_58 = *param_2;
  uStack_138 = CONCAT44(&param_3,0xbcb9fc);
  FUN_008c4480();
  uStack_138 = CONCAT44(&stack0x0000002c,0xbcba08);
  FUN_008c4480();
  uStack_138 = CONCAT44(param_1,0xbcba16);
  FUN_00bc7cb0();
  uStack_f8 = 0;
  if (in_stack_0000002c != 0) {
    if ((in_stack_0000002c & 1) == 0) {
      (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&uStack_148,0);
    }
    else {
      uStack_148 = in_stack_00000034;
      uStack_144 = in_stack_00000038;
      uStack_140 = in_stack_0000003c;
      puStack_13c = (undefined4 *)in_stack_00000040;
      uStack_138 = in_stack_00000044;
    }
  }
  FUN_00bca580(auStack_128,param_2);
  uStack_138 = CONCAT44(0xbcba7b,(undefined4)uStack_138);
  FUN_00bc7880();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      puStack_13c = (undefined4 *)&stack0x00000014;
      uStack_138 = CONCAT44(2,puStack_13c);
      uStack_140 = 0xbcba9c;
      (**(code **)(param_3 & 0xfffffffe))();
    }
    param_3 = 0;
  }
  uStack_8 = 4;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    puStack_13c = &stack0x00000034;
    uStack_138 = CONCAT44(2,puStack_13c);
    uStack_140 = 0xbcbaca;
    (**(code **)(in_stack_0000002c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26296 ; VA 0x00bcbae0 ; FUN_00bcbae0 */

void __thiscall FUN_00bcbae0(int param_1,undefined4 *param_2)

{
  undefined uVar1;
  uint *puVar2;
  uint *puVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  uint uVar8;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 *in_stack_00000038;
  ulonglong in_stack_0000003c;
  uint in_stack_00000044;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined8 in_stack_0000005c;
  uint auStack_90 [2];
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 *puStack_7c;
  ulonglong uStack_78;
  uint auStack_70 [2];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  uint *puStack_5c;
  undefined8 uStack_58;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  undefined8 uStack_3c;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fef78;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  puStack_5c = auStack_34;
  uStack_58 = CONCAT44(param_1 + 0xe0,&DAT_01d67e08);
  uStack_60 = 0xbcbb1a;
  ExceptionList = &pvStack_10;
  FUN_005f3cd0();
  puVar6 = &param_2;
  if (0xf < in_stack_00000018) {
    puVar6 = param_2;
  }
  uStack_58 = CONCAT44(in_stack_00000014,puVar6);
  uStack_8._0_1_ = 3;
  puStack_5c = (uint *)0xbcbb37;
  piVar4 = (int *)FUN_00554150();
  iStack_4c = *piVar4;
  iStack_48 = piVar4[1];
  iStack_44 = piVar4[2];
  iStack_40 = piVar4[3];
  uStack_3c = *(undefined8 *)(piVar4 + 4);
  piVar4[4] = 0;
  piVar4[5] = 0xf;
  *(undefined *)piVar4 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (0xf < uStack_20) {
    uVar7 = uStack_20 + 1;
    uVar8 = auStack_34[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_34[0] - 4);
      uVar7 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar8) - 4) {
        uStack_58 = CONCAT44(0xbcbd42,(undefined4)uStack_58);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_58 = CONCAT44(uVar7,uVar8);
    puStack_5c = (uint *)0xbcbb8e;
    FUN_01674ea0();
  }
  puStack_18 = (undefined *)auStack_70;
  puStack_14 = (undefined *)auStack_70;
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  auStack_70[0] = 0;
  puVar2 = auStack_70;
  if (in_stack_00000044 != 0) {
    auStack_70[0] = in_stack_00000044;
    if ((in_stack_00000044 & 1) == 0) {
      uStack_78 = ZEXT48(&uStack_68);
      puStack_7c = &stack0x0000004c;
      uStack_80 = 0xbcbbe7;
      (**(code **)(in_stack_00000044 & 0xfffffffe))();
      puVar2 = (uint *)puStack_14;
    }
    else {
      uStack_68 = in_stack_0000004c;
      uStack_64 = in_stack_00000050;
      uStack_60 = in_stack_00000054;
      puStack_5c = (uint *)in_stack_00000058;
      uStack_58 = in_stack_0000005c;
      puVar2 = auStack_70;
    }
  }
  puStack_14 = (undefined *)puVar2;
  puStack_18 = (undefined *)auStack_90;
  puStack_1c = (undefined *)auStack_90;
  uStack_8._0_1_ = 6;
  auStack_90[0] = 0;
  puVar2 = auStack_90;
  puVar3 = auStack_90;
  if (in_stack_00000024 != 0) {
    auStack_90[0] = in_stack_00000024;
    if ((in_stack_00000024 & 1) == 0) {
      (**(code **)(in_stack_00000024 & 0xfffffffe))(&stack0x0000002c,&uStack_88,0);
      puVar2 = (uint *)puStack_1c;
      puVar3 = (uint *)puStack_18;
    }
    else {
      uStack_88 = in_stack_0000002c;
      uStack_84 = in_stack_00000030;
      uStack_80 = in_stack_00000034;
      puStack_7c = in_stack_00000038;
      uStack_78 = in_stack_0000003c;
      puVar2 = auStack_90;
      puVar3 = auStack_90;
    }
  }
  puStack_18 = (undefined *)puVar3;
  puStack_1c = (undefined *)puVar2;
  uStack_8._0_1_ = 7;
  FUN_0054ef60(&iStack_4c);
  uStack_8._0_1_ = 5;
  FUN_00bcb7d0();
  uStack_8._0_1_ = 2;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_3c._4_4_) {
    uVar8 = uStack_3c._4_4_ + 1;
    iVar5 = iStack_4c;
    if (0xfff < uVar8) {
      iVar5 = *(int *)(iStack_4c + -4);
      uVar8 = uStack_3c._4_4_ + 0x24;
      if (0x1f < (iStack_4c - iVar5) - 4U) {
        uStack_58 = CONCAT44(0xbcbd47,(undefined4)uStack_58);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_58 = CONCAT44(uVar8,iVar5);
    puStack_5c = (uint *)0xbcbc8d;
    FUN_01674ea0();
  }
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    uVar8 = in_stack_00000018 + 1;
    puVar6 = param_2;
    if (0xfff < uVar8) {
      puVar6 = (undefined4 *)param_2[-1];
      uVar8 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar6))) {
        uStack_58 = CONCAT44(&UNK_00bcbd4c,(undefined4)uStack_58);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_58 = CONCAT44(uVar8,puVar6);
    puStack_5c = (uint *)0xbcbcc5;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = (undefined4 *)((uint)param_2 & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (in_stack_00000024 != 0) {
    if (((in_stack_00000024 & 1) == 0) &&
       (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
      puStack_5c = &stack0x0000002c;
      uStack_58 = CONCAT44(2,puStack_5c);
      uStack_60 = 0xbcbcfb;
      (**(code **)(in_stack_00000024 & 0xfffffffe))();
    }
    in_stack_00000024 = 0;
  }
  uStack_8 = 9;
  if (((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) &&
     (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
    puStack_5c = &stack0x0000004c;
    uStack_58 = CONCAT44(2,puStack_5c);
    uStack_60 = 0xbcbd29;
    (**(code **)(in_stack_00000044 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26297 ; VA 0x00bcbd50 ; FUN_00bcbd50 */

undefined4 FUN_00bcbd50(undefined4 param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_010755b0(param_1,&param_2);
  if (0xf < in_stack_0000001c) {
    uVar2 = in_stack_0000001c + 1;
    iVar1 = param_2;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_2 + -4);
      uVar2 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26298 ; VA 0x00bcbdd0 ; FUN_00bcbdd0 */

void __thiscall
FUN_00bcbdd0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  undefined auStack_78 [104];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ff048;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008f7870(param_1);
  uVar1 = FUN_008f7f00();
  FUN_014cc090(param_2,param_5,uVar1);
  uStack_8 = 0;
  FUN_00bcae80(auStack_78,param_3,param_4);
  FUN_0056db40();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26299 ; VA 0x00bcbe40 ; FUN_00bcbe40 */

int __fastcall FUN_00bcbe40(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0x34);
    if ((iVar2 != 0) && (param_1 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar2 = *(int *)(param_1 + 0xc), iVar1 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
       (uint)*(ushort *)(iVar1 + 0x1da))) {
      iVar2 = FUN_005cf750();
      if (iVar2 == 0) {
        return 0;
      }
      return (*(int **)(iVar2 + 0xb8))[1] - **(int **)(iVar2 + 0xb8) >> 3;
    }
  }
  return 0;
}



/* FUNCTION 26300 ; VA 0x00bcbeb0 ; FUN_00bcbeb0 */

void FUN_00bcbeb0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_014cd0a0(param_2,param_3,param_4);
  return;
}



/* FUNCTION 26301 ; VA 0x00bcbed0 ; FUN_00bcbed0 */

void FUN_00bcbed0(int param_1,int *param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  undefined3 uVar4;
  char cVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined **ppuVar8;
  uint in_stack_00000130;
  uint in_stack_00000150;
  undefined auStack_9c4 [24];
  undefined4 uStack_9ac;
  undefined4 *puStack_9a8;
  undefined auStack_9a4 [28];
  undefined4 uStack_988;
  undefined auStack_984 [32];
  undefined4 uStack_964;
  undefined4 *puStack_960;
  code *pcStack_95c;
  int iStack_958;
  int *piStack_954;
  undefined4 uStack_840;
  undefined4 *puStack_83c;
  undefined4 auStack_838 [4];
  undefined4 uStack_828;
  undefined4 *puStack_824;
  undefined4 uStack_820;
  undefined4 *puStack_81c;
  undefined4 auStack_818 [4];
  undefined4 uStack_808;
  undefined *puStack_804;
  undefined *puStack_800;
  int iStack_7fc;
  undefined4 auStack_7ec [2];
  undefined auStack_7e4 [320];
  undefined4 uStack_6a4;
  undefined auStack_69c [320];
  undefined4 uStack_55c;
  undefined auStack_554 [320];
  undefined4 uStack_414;
  undefined auStack_40c [320];
  undefined4 uStack_2cc;
  undefined auStack_2c4 [320];
  undefined4 auStack_184 [2];
  undefined auStack_17c [320];
  undefined *puStack_3c;
  undefined *puStack_38;
  undefined *puStack_30;
  int iStack_2c;
  int *piStack_28;
  undefined *puStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ff0fa;
  pvStack_10 = ExceptionList;
  iStack_2c = 0;
  piStack_28 = (int *)0x0;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    piVar1 = param_2 + 1;
    iVar2 = param_2[1];
    ExceptionList = &pvStack_10;
    while (iVar2 != 0) {
      LOCK();
      iVar6 = *piVar1;
      if (iVar2 == iVar6) {
        *piVar1 = iVar2 + 1;
        iVar6 = iVar2;
      }
      UNLOCK();
      if (iVar6 == iVar2) {
        iStack_2c = param_1;
        piStack_28 = param_2;
        break;
      }
      iVar2 = *piVar1;
    }
  }
  piVar1 = piStack_28;
  iVar2 = iStack_2c;
  uStack_8._0_1_ = 4;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  uVar4 = 0;
  if (iStack_2c != 0) {
    iStack_7fc._0_1_ = *(undefined *)(iStack_2c + 0x118);
    puStack_800 = &stack0x00000014;
    iStack_7fc._1_3_ = puStack_1c._1_3_;
    puStack_804 = (undefined *)param_4;
    uStack_808 = 0xbcbf55;
    puStack_1c._0_1_ = (undefined)iStack_7fc;
    cVar5 = FUN_00bd3010();
    iStack_7fc = iVar2;
    if (cVar5 == '\0') {
      puStack_20 = (undefined4 *)CONCAT31(puStack_20._1_3_,DAT_01ef5a96);
      puStack_1c = (undefined4 *)CONCAT31(puStack_1c._1_3_,DAT_01ef5a95);
      puStack_800 = (undefined *)0xbcc17a;
      puStack_18 = (undefined4 *)FUN_008f7870();
      puStack_24 = (undefined *)auStack_818;
      puStack_9a8 = &stack0x00000150;
      puStack_81c = (undefined4 *)0x0;
      puStack_30 = auStack_984;
      puStack_38 = auStack_9a4;
      uStack_9ac = 0xbcc1a2;
      FUN_0054f510();
      puStack_3c = auStack_9c4;
      uStack_8._0_1_ = 0xd;
      FUN_0054f510(&stack0x00000130);
      uStack_8._0_1_ = 0xe;
      FUN_00bc6e60(&stack0x00000014);
      if (piVar1 != (int *)0x0) {
        LOCK();
        piVar1[1] = piVar1[1] + 1;
        UNLOCK();
      }
      uStack_8._0_1_ = 4;
      FUN_00bc4dc0(puStack_30,FUN_00bcc2e0,iVar2,piVar1,puStack_1c,puStack_20);
      uStack_988 = 0xbcc213;
      FUN_00bc4090();
      puStack_824 = puStack_18;
    }
    else {
      puStack_800 = (undefined *)0xbcbf66;
      puStack_20 = (undefined4 *)FUN_008f7870();
      puStack_1c = auStack_818;
      puStack_83c = &stack0x00000150;
      puStack_18 = auStack_838;
      uStack_840 = 0xbcbf83;
      FUN_0054f510();
      uStack_8._0_1_ = 5;
      piStack_954 = (int *)&stack0x00000014;
      iStack_958 = 0xbcbf98;
      FUN_00bc6e60();
      if (piVar1 != (int *)0x0) {
        LOCK();
        piVar1[1] = piVar1[1] + 1;
        UNLOCK();
      }
      puStack_960 = auStack_7ec;
      pcStack_95c = FUN_00bcc4b0;
      uStack_8._0_1_ = 4;
      uStack_964 = 0xbcbfcc;
      iStack_958 = iVar2;
      piStack_954 = piVar1;
      FUN_00bc4c60();
      uStack_6a4 = auStack_7ec[0];
      puStack_81c = (undefined4 *)auStack_7e4;
      uStack_8._0_1_ = 6;
      uStack_820 = 0xbcbff4;
      FUN_00bc5ba0();
      puVar7 = puStack_1c;
      uStack_55c = uStack_6a4;
      puStack_81c = (undefined4 *)auStack_69c;
      uStack_8._0_1_ = 7;
      *puStack_1c = 0;
      uStack_820 = 0xbcc01f;
      FUN_00bc5ba0();
      uStack_414 = uStack_55c;
      puStack_81c = (undefined4 *)auStack_554;
      uStack_8._0_1_ = 8;
      uStack_820 = 0xbcc041;
      FUN_00bc5ba0();
      auStack_184[0] = uStack_414;
      puStack_81c = (undefined4 *)auStack_40c;
      uStack_8._0_1_ = 9;
      uStack_820 = 0xbcc063;
      FUN_00bc5ba0();
      puStack_81c = auStack_184;
      uStack_8._0_1_ = 10;
      uStack_820 = 0xbcc073;
      cVar5 = FUN_00585a40();
      if (cVar5 == '\0') {
        uStack_2cc = auStack_184[0];
        puStack_81c = (undefined4 *)auStack_17c;
        uStack_820 = 0xbcc09c;
        FUN_00bc5ba0();
        puStack_81c = (undefined4 *)0x148;
        uStack_8._0_1_ = 0xb;
        uStack_820 = 0xbcc0aa;
        puVar7 = (undefined4 *)FUN_01674e20();
        uStack_8._0_1_ = 0xc;
        puStack_18 = puVar7;
        if (puVar7 == (undefined4 *)0x0) {
          puVar7 = (undefined4 *)0x0;
        }
        else {
          puStack_81c = (undefined4 *)auStack_2c4;
          *puVar7 = uStack_2cc;
          uStack_820 = 0xbcc0d1;
          FUN_00bc5ba0();
        }
        puStack_1c[2] = puVar7;
        puStack_81c = (undefined4 *)0xbcc0f7;
        FUN_00bc7710();
        puStack_81c = (undefined4 *)0xbcc102;
        FUN_00bc7710();
        cStack_11 = '\x01';
        puVar7 = puStack_1c;
      }
      else {
        puStack_81c = (undefined4 *)0xbcc116;
        FUN_00bc7710();
        cStack_11 = '\0';
      }
      puStack_81c = (undefined4 *)0xbcc125;
      FUN_00bc7710();
      ppuVar8 = &PTR_FUN_0195d974;
      if (cStack_11 == '\0') {
        ppuVar8 = (undefined **)0x0;
      }
      *puVar7 = ppuVar8;
      puStack_81c = (undefined4 *)0xbcc13f;
      FUN_00bc7710();
      puStack_81c = (undefined4 *)0xbcc14a;
      FUN_00bc7710();
      uStack_8._0_1_ = 4;
      puStack_81c = (undefined4 *)0xbcc159;
      FUN_00bc7710();
      puStack_824 = puStack_20;
    }
    puStack_81c = (undefined4 *)param_4;
    uStack_820 = param_3;
    uStack_828 = 0xbcc21f;
    FUN_008ed3f0();
    uVar3 = (undefined)uStack_8;
    uVar4 = uStack_8._1_3_;
  }
  uStack_8._1_3_ = uVar4;
  uStack_8._0_1_ = uVar3;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[1] + -1;
    piVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      iStack_7fc = 0xbcc238;
      (**(code **)*piVar1)();
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        iStack_7fc = 0xbcc248;
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      iStack_7fc = 0xbcc25c;
      (**(code **)(*param_2 + 4))();
    }
  }
  iStack_7fc = 0xbcc264;
  FUN_00bc7880();
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  if (in_stack_00000130 != 0) {
    if (((in_stack_00000130 & 1) == 0) &&
       (*(code **)(in_stack_00000130 & 0xfffffffe) != (code *)0x0)) {
      puStack_804 = &stack0x00000138;
      iStack_7fc = 2;
      uStack_808 = 0xbcc28b;
      puStack_800 = puStack_804;
      (**(code **)(in_stack_00000130 & 0xfffffffe))();
    }
    in_stack_00000130 = 0;
  }
  uStack_8 = 0x10;
  if (((in_stack_00000150 != 0) && ((in_stack_00000150 & 1) == 0)) &&
     (*(code **)(in_stack_00000150 & 0xfffffffe) != (code *)0x0)) {
    puStack_804 = &stack0x00000158;
    iStack_7fc = 2;
    uStack_808 = 0xbcc2c2;
    puStack_800 = puStack_804;
    (**(code **)(in_stack_00000150 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26302 ; VA 0x00bcc2e0 ; FUN_00bcc2e0 */

void FUN_00bcc2e0(int param_1,int *param_2,int param_3,int *param_4,int *param_5,int *param_6)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  char *pcVar4;
  char *pcVar5;
  int in_stack_000000f0;
  uint in_stack_00000134;
  uint in_stack_00000154;
  undefined1 *in_stack_ffffffcc;
  char *in_stack_ffffffd0;
  char *in_stack_ffffffd4;
  undefined4 in_stack_ffffffd8;
  undefined4 in_stack_ffffffdc;
  undefined4 in_stack_ffffffe0;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ff146;
  pvStack_10 = ExceptionList;
  uStack_8 = 5;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    if ((*(char *)(param_1 + 0x118) != '\0') && (ExceptionList = &pvStack_10, 0 < in_stack_000000f0)
       ) {
      in_stack_ffffffd8 = 0;
      in_stack_ffffffd4 = "RetryRequestFailed";
      in_stack_ffffffd0 = "HttpRbxApiService";
      in_stack_ffffffcc = &DAT_018c5f98;
      ExceptionList = &pvStack_10;
      FUN_0087c450(&DAT_018c5f98,"HttpRbxApiService","RetryRequestFailed",0,0,0);
    }
    pcVar4 = (char *)(**(code **)(*param_5 + 4))();
    in_stack_ffffffdc = 0;
    in_stack_ffffffe0 = 0xf;
    in_stack_ffffffcc = (undefined1 *)((uint)in_stack_ffffffcc & 0xffffff00);
    pcVar5 = pcVar4;
    do {
      cVar2 = *pcVar5;
      pcVar5 = pcVar5 + 1;
    } while (cVar2 != '\0');
    FUN_005542c0(pcVar4,(int)pcVar5 - (int)(pcVar4 + 1));
  }
  else {
    ExceptionList = &pvStack_10;
    if ((*(char *)(param_1 + 0x118) != '\0') && (ExceptionList = &pvStack_10, 0 < in_stack_000000f0)
       ) {
      in_stack_ffffffe0 = 0;
      in_stack_ffffffdc = 0;
      in_stack_ffffffd8 = 0;
      in_stack_ffffffd4 = "RetryRequestSucceeded";
      in_stack_ffffffd0 = "HttpRbxApiService";
      in_stack_ffffffcc = &DAT_018c5f98;
      ExceptionList = &pvStack_10;
      FUN_0087c450(&DAT_018c5f98,"HttpRbxApiService","RetryRequestSucceeded",0,0,0);
    }
    FUN_0054ef60(param_3);
  }
  FUN_005e65e0(in_stack_ffffffcc,in_stack_ffffffd0,in_stack_ffffffd4,in_stack_ffffffd8,
               in_stack_ffffffdc,in_stack_ffffffe0);
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar3 = param_2[1] + -1;
    param_2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar3 = param_2[2] + -1;
      param_2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar3 = param_4[1] + -1;
    param_4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar3 = param_4[2] + -1;
      param_4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar3 = param_6[1] + -1;
    param_6[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  FUN_00bc7880();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (((in_stack_00000134 != 0) && ((in_stack_00000134 & 1) == 0)) &&
     (*(code **)(in_stack_00000134 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000134 & 0xfffffffe))(&stack0x0000013c,&stack0x0000013c,2);
  }
  uStack_8 = 7;
  if (((in_stack_00000154 != 0) && ((in_stack_00000154 & 1) == 0)) &&
     (*(code **)(in_stack_00000154 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000154 & 0xfffffffe))(&stack0x0000015c,&stack0x0000015c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26303 ; VA 0x00bcc4b0 ; FUN_00bcc4b0 */

void FUN_00bcc4b0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  uint in_stack_00000124;
  undefined uVar3;
  undefined auStack_12c [284];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ff176;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  FUN_00bc6e60(&stack0x0000000c);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (*(uint *)(param_1 + 0xb4) < DAT_01d67cfc) {
    FUN_00bd1d00(auStack_12c);
    FUN_00bc7880();
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00bc7880();
    uVar3 = 0;
    FUN_005542c0("Request failed, but could not retry due to too many current retry requests.",0x4b)
    ;
    FUN_005e65e0(uVar3);
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  FUN_00bc7880();
  uStack_8 = 4;
  if (((in_stack_00000124 != 0) && ((in_stack_00000124 & 1) == 0)) &&
     (*(code **)(in_stack_00000124 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000124 & 0xfffffffe))(&stack0x0000012c,&stack0x0000012c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26304 ; VA 0x00bcc5d0 ; FUN_00bcc5d0 */

int FUN_00bcc5d0(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  code *pcVar4;
  uint uVar5;
  int iVar6;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ff198;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  puVar3 = (undefined4 *)*param_1;
  pcVar4 = (code *)*puVar3;
  uVar5 = puVar3[0x4a];
  ExceptionList = &pvStack_10;
  if (uVar5 != 0) {
    if ((uVar5 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar5 & 0xfffffffe))(puVar3 + 0x4c,&uStack_34,0);
    }
    else {
      uStack_34 = puVar3[0x4c];
      uStack_30 = puVar3[0x4d];
      uStack_2c = puVar3[0x4e];
      uStack_28 = puVar3[0x4f];
      uStack_24 = *(undefined8 *)(puVar3 + 0x50);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  FUN_00bc6e60(puVar3 + 4);
  if (puVar3[3] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar6 = (*pcVar4)(puVar3[2],puVar3[3]);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      uStack_24 = CONCAT44(0xbcc6ae,(undefined4)uStack_24);
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        uStack_24 = CONCAT44(0xbcc6be,(undefined4)uStack_24);
        iVar6 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      uStack_24 = CONCAT44(0xbcc6d4,(undefined4)uStack_24);
      iVar6 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_24 = CONCAT44(0xbcc6e3,(undefined4)uStack_24);
        iVar6 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 26305 ; VA 0x00bcc700 ; FUN_00bcc700 */

int FUN_00bcc700(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5
                )

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c47e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  puStack_18 = (undefined *)&param_2;
  puStack_14 = (undefined *)&param_4;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00bc43e0(param_1,*param_1,&puStack_18,0);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_5)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 26306 ; VA 0x00bcc7b0 ; FUN_00bcc7b0 */

void FUN_00bcc7b0(undefined4 *param_1)

{
  undefined *puStack_c;
  undefined *puStack_8;
  
  puStack_c = &stack0x00000008;
  puStack_8 = &stack0x0000000c;
  FUN_00bc4570(param_1,*param_1,&puStack_c,0);
  return;
}



/* FUNCTION 26307 ; VA 0x00bcc7e0 ; FUN_00bcc7e0 */

undefined4 FUN_00bcc7e0(undefined *param_1)

{
  undefined4 ****ppppuVar1;
  undefined4 ***pppuVar2;
  undefined **ppuVar3;
  int *piVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined4 ****ppppuVar7;
  undefined *puStack_64;
  undefined4 ***pppuStack_60;
  undefined4 ***pppuStack_5c;
  undefined *puStack_58;
  undefined *puStack_54;
  undefined4 ***pppuStack_50;
  undefined *puStack_4c;
  undefined4 ***pppuStack_48;
  undefined4 ***pppuStack_38;
  undefined4 ***pppuStack_34;
  undefined4 uStack_30;
  undefined4 ***pppuStack_2c;
  undefined auStack_28 [4];
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ff1c8;
  pvStack_10 = ExceptionList;
  if (DAT_01d67d80 != 0) {
    pppuStack_38 = (undefined4 ****)0x0;
    pppuStack_34 = (undefined4 ****)0x0;
    uStack_30 = 0;
    pppuStack_48 = (undefined4 ***)0x1;
    pppuStack_50 = &pppuStack_2c;
    uStack_8 = 0;
    puStack_4c = &DAT_0191c424;
    pppuStack_2c = (undefined4 ****)0x0;
    uStack_24 = 1;
    puStack_54 = (undefined *)0xbcc845;
    ExceptionList = &pvStack_10;
    FUN_0170cc70();
    puStack_54 = param_1;
    pppuStack_5c = (undefined4 ***)(auStack_28 + (uStack_24 - 4));
    pppuStack_60 = &pppuStack_2c;
    puStack_58 = (undefined *)((int)pppuStack_5c - (int)pppuStack_60);
    puStack_64 = (undefined *)0xbcc85f;
    FUN_0063e660();
    uStack_8._0_1_ = 1;
    puStack_58 = (undefined *)0x0;
    ppuVar3 = &puStack_64;
    pppuStack_5c = (undefined4 ***)uStack_24;
    puStack_64 = (undefined *)0x0;
    if (uStack_24 < 9) {
      ppppuVar7 = &pppuStack_2c;
    }
    else {
      ppuVar3 = (undefined **)FUN_01674e20(uStack_24);
      ppppuVar7 = (undefined4 ****)pppuStack_2c;
      puStack_64 = (undefined *)ppuVar3;
    }
    FUN_0170c6f0(ppuVar3,ppppuVar7,pppuStack_5c);
    FUN_0063fec0(&puStack_54);
    pppuStack_5c = &pppuStack_38;
    puStack_58 = param_1;
    pppuStack_60 = (undefined4 ***)0xbcc8b8;
    FUN_0064f4f0();
    uStack_8._0_1_ = 0;
    ppppuVar7 = (undefined4 ****)pppuStack_38;
    ppppuVar1 = (undefined4 ****)pppuStack_34;
    if ((8 < uStack_24) && ((undefined4 ****)pppuStack_2c != (undefined4 ****)0x0)) {
      pppuStack_48 = pppuStack_2c;
      puStack_4c = (undefined *)0xbcc8d2;
      FUN_01674ea0();
      ppppuVar7 = (undefined4 ****)pppuStack_38;
      ppppuVar1 = (undefined4 ****)pppuStack_34;
    }
    for (; pppuVar2 = pppuStack_34, ppppuVar7 != (undefined4 ****)pppuStack_34;
        ppppuVar7 = ppppuVar7 + 6) {
      pppuStack_48 = (undefined4 ***)0x1;
      uStack_8._0_1_ = 2;
      puStack_4c = (undefined *)0xbcc8eb;
      pppuStack_34 = ppppuVar1;
      piVar4 = (int *)FUN_016de181();
      puStack_4c = auStack_20;
      uStack_8._0_1_ = 3;
      puStack_54 = param_1;
      puStack_58 = auStack_28;
      pppuStack_5c = (undefined4 ****)0xbcc905;
      pppuStack_50 = ppppuVar7;
      piStack_1c = piVar4;
      piVar5 = (int *)FUN_00bc5490();
      iStack_18 = *piVar5;
      iStack_14 = piVar5[1];
      uStack_8._0_1_ = 4;
      if (piVar4 != (int *)0x0) {
        pppuStack_48 = (undefined4 ***)0xbcc922;
        puVar6 = (undefined4 *)(**(code **)(*piVar4 + 8))();
        if (puVar6 != (undefined4 *)0x0) {
          pppuStack_48 = (undefined4 ***)0x1;
          puStack_4c = (undefined *)0xbcc930;
          (**(code **)*puVar6)();
        }
      }
      uStack_8._0_1_ = 0;
      if (iStack_18 != iStack_14) {
        pppuStack_48 = (undefined4 ***)0xbcc968;
        FUN_00577a40();
        ExceptionList = pvStack_10;
        return 1;
      }
      ppppuVar1 = (undefined4 ****)pppuStack_34;
      pppuStack_34 = pppuVar2;
    }
    pppuStack_48 = (undefined4 ***)0xbcc94b;
    pppuStack_34 = ppppuVar1;
    FUN_00577a40();
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 26308 ; VA 0x00bcc980 ; FUN_00bcc980 */

uint __thiscall FUN_00bcc980(int param_1,undefined4 *param_2)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  code *pcVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int *piVar7;
  int iVar8;
  uint uVar9;
  int *piVar10;
  
  puVar6 = (undefined4 *)FUN_00bcc7e0(param_2);
  if ((char)puVar6 == '\0') {
    puVar2 = *(undefined4 **)(param_1 + 0xd8);
    puVar3 = (undefined4 *)*puVar2;
    while (puVar3 != puVar2) {
      uVar9 = puVar3[8];
      piVar7 = puVar3 + 4;
      if (uVar9 <= uVar9 - 1) {
        FUN_00554050();
        pcVar4 = (code *)swi(3);
        uVar9 = (*pcVar4)();
        return uVar9;
      }
      piVar10 = piVar7;
      if (0xf < (uint)puVar3[9]) {
        piVar10 = (int *)*piVar7;
      }
      if (((*(char *)((int)piVar10 + (uVar9 - 1)) == '/') && (uVar9 != 0)) &&
         (uVar9 <= (uint)param_2[4])) {
        puVar6 = param_2;
        if (0xf < (uint)param_2[5]) {
          puVar6 = (undefined4 *)*param_2;
        }
        if (0xf < (uint)puVar3[9]) {
          piVar7 = (int *)*piVar7;
        }
        iVar8 = FUN_01723e00(piVar7,puVar6,uVar9);
        if (iVar8 == 0) {
          return 1;
        }
      }
      puVar6 = (undefined4 *)puVar3[2];
      if (*(char *)((int)puVar6 + 0xd) == '\0') {
        cVar1 = *(char *)((int)*puVar6 + 0xd);
        puVar3 = puVar6;
        puVar5 = (undefined4 *)*puVar6;
        while (cVar1 == '\0') {
          puVar6 = (undefined4 *)*puVar5;
          puVar3 = puVar5;
          puVar5 = puVar6;
          cVar1 = *(char *)((int)puVar6 + 0xd);
        }
      }
      else {
        cVar1 = *(char *)((int)puVar3[1] + 0xd);
        puVar6 = (undefined4 *)puVar3[1];
        puVar5 = puVar3;
        while ((puVar3 = puVar6, puVar6 = puVar3, cVar1 == '\0' &&
               (puVar5 == (undefined4 *)puVar3[2]))) {
          cVar1 = *(char *)((int)puVar3[1] + 0xd);
          puVar6 = (undefined4 *)puVar3[1];
          puVar5 = puVar3;
        }
      }
    }
  }
  return (uint)puVar6 & 0xffffff00;
}



/* FUNCTION 26309 ; VA 0x00bcca60 ; FUN_00bcca60 */

uint FUN_00bcca60(void)

{
  int iVar1;
  
  iVar1 = FUN_00bc46d0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 26310 ; VA 0x00bcca80 ; FUN_00bcca80 */

uint FUN_00bcca80(void)

{
  int iVar1;
  
  iVar1 = FUN_00bc46d0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 26311 ; VA 0x00bccaa0 ; FUN_00bccaa0 */

void FUN_00bccaa0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00bd30e0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 26312 ; VA 0x00bccae0 ; FUN_00bccae0 */

undefined4 * FUN_00bccae0(undefined4 *param_1)

{
  undefined uVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  undefined auStack_10c [120];
  undefined4 uStack_94;
  undefined auStack_90 [8];
  uint auStack_88 [4];
  undefined4 uStack_78;
  uint uStack_74;
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017ff81d;
  pvStack_10 = ExceptionList;
  uStack_94 = 0;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  uVar2 = FUN_00575b30();
  *param_1 = uVar2;
  iStack_8 = 0;
  uStack_94 = 1;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 1;
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 2;
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 3;
  uVar2 = FUN_0151ed10(auStack_58);
  iStack_8._0_1_ = 4;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_70,auStack_88,auStack_28);
  iStack_8._0_1_ = 5;
  uVar2 = FUN_0151bb70(auStack_40);
  iStack_8._0_1_ = 6;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  iStack_8._0_1_ = 5;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 5;
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    uVar3 = auStack_40[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_40[0] - 4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_0056d9d0();
  iStack_8._0_1_ = 3;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 3;
  if (0xf < uStack_44) {
    uVar4 = uStack_44 + 1;
    uVar3 = auStack_58[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_58[0] - 4);
      uVar4 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  iStack_8._0_1_ = 2;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 2;
  if (0xf < uStack_5c) {
    uVar4 = uStack_5c + 1;
    uVar3 = auStack_70[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_70[0] - 4);
      uVar4 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  iStack_8._0_1_ = 1;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 1;
  if (0xf < uStack_74) {
    uVar4 = uStack_74 + 1;
    uVar3 = auStack_88[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_88[0] - 4);
      uVar4 = uStack_74 + 0x24;
      if (0x1f < (auStack_88[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    uVar3 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 7;
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 8;
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 9;
  uVar2 = FUN_0151ed70(auStack_40);
  iStack_8._0_1_ = 10;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_88,auStack_70,auStack_28);
  iStack_8._0_1_ = 0xb;
  uVar2 = FUN_0151bb70(auStack_58);
  iStack_8._0_1_ = 0xc;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  iStack_8._0_1_ = 0xb;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 0xb;
  if (0xf < uStack_44) {
    uVar4 = uStack_44 + 1;
    uVar3 = auStack_58[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_58[0] - 4);
      uVar4 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_0056d9d0();
  iStack_8._0_1_ = 9;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 9;
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    uVar3 = auStack_40[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_40[0] - 4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  iStack_8._0_1_ = 8;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 8;
  if (0xf < uStack_74) {
    uVar4 = uStack_74 + 1;
    uVar3 = auStack_88[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_88[0] - 4);
      uVar4 = uStack_74 + 0x24;
      if (0x1f < (auStack_88[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  iStack_8._0_1_ = 7;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 7;
  if (0xf < uStack_5c) {
    uVar4 = uStack_5c + 1;
    uVar3 = auStack_70[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_70[0] - 4);
      uVar4 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    uVar3 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0xd;
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0xe;
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0xf;
  uVar2 = FUN_0151ec50(auStack_40);
  iStack_8._0_1_ = 0x10;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_88,auStack_70,auStack_28);
  iStack_8._0_1_ = 0x11;
  uVar2 = FUN_0151bb70(auStack_58);
  iStack_8._0_1_ = 0x12;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  iStack_8._0_1_ = 0x11;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 0x11;
  if (0xf < uStack_44) {
    uVar4 = uStack_44 + 1;
    uVar3 = auStack_58[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_58[0] - 4);
      uVar4 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_0056d9d0();
  iStack_8._0_1_ = 0xf;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 0xf;
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    uVar3 = auStack_40[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_40[0] - 4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  iStack_8._0_1_ = 0xe;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 0xe;
  if (0xf < uStack_74) {
    uVar4 = uStack_74 + 1;
    uVar3 = auStack_88[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_88[0] - 4);
      uVar4 = uStack_74 + 0x24;
      if (0x1f < (auStack_88[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  iStack_8._0_1_ = 0xd;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 0xd;
  if (0xf < uStack_5c) {
    uVar4 = uStack_5c + 1;
    uVar3 = auStack_70[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_70[0] - 4);
      uVar4 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    uVar3 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x13;
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x14;
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x15;
  uVar2 = FUN_0151ed30(auStack_40);
  iStack_8._0_1_ = 0x16;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_88,auStack_70,auStack_28);
  iStack_8._0_1_ = 0x17;
  uVar2 = FUN_0151bb70(auStack_58);
  iStack_8._0_1_ = 0x18;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  iStack_8._0_1_ = 0x17;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 0x17;
  if (0xf < uStack_44) {
    uVar4 = uStack_44 + 1;
    uVar3 = auStack_58[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_58[0] - 4);
      uVar4 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_0056d9d0();
  iStack_8._0_1_ = 0x15;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 0x15;
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    uVar3 = auStack_40[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_40[0] - 4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  iStack_8._0_1_ = 0x14;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 0x14;
  if (0xf < uStack_74) {
    uVar4 = uStack_74 + 1;
    uVar3 = auStack_88[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_88[0] - 4);
      uVar4 = uStack_74 + 0x24;
      if (0x1f < (auStack_88[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  iStack_8._0_1_ = 0x13;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 0x13;
  if (0xf < uStack_5c) {
    uVar4 = uStack_5c + 1;
    uVar3 = auStack_70[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_70[0] - 4);
      uVar4 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    uVar3 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x19;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x1a;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x1b;
  uVar2 = FUN_0151eef0(auStack_70);
  iStack_8._0_1_ = 0x1c;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
  iStack_8._0_1_ = 0x1d;
  uVar2 = FUN_0151bb70(auStack_88);
  iStack_8._0_1_ = 0x1e;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  FUN_005507b0();
  FUN_0056d9d0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x1f;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x20;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x21;
  uVar2 = FUN_0151f030(auStack_70);
  iStack_8._0_1_ = 0x22;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
  iStack_8._0_1_ = 0x23;
  uVar2 = FUN_0151bb70(auStack_88);
  iStack_8._0_1_ = 0x24;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  FUN_005507b0();
  FUN_0056d9d0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x25;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x26;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x27;
  uVar2 = FUN_0151ee50(auStack_70);
  iStack_8._0_1_ = 0x28;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
  iStack_8._0_1_ = 0x29;
  uVar2 = FUN_0151bb70(auStack_88);
  iStack_8._0_1_ = 0x2a;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  FUN_005507b0();
  FUN_0056d9d0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x2b;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x2c;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x2d;
  uVar2 = FUN_0151ecd0(auStack_70);
  iStack_8._0_1_ = 0x2e;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
  iStack_8._0_1_ = 0x2f;
  uVar2 = FUN_0151bb70(auStack_88);
  iStack_8._0_1_ = 0x30;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  FUN_005507b0();
  FUN_0056d9d0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x31;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x32;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x33;
  uVar2 = FUN_0151efd0(auStack_70);
  iStack_8._0_1_ = 0x34;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
  iStack_8._0_1_ = 0x35;
  uVar2 = FUN_0151bb70(auStack_88);
  iStack_8._0_1_ = 0x36;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  FUN_005507b0();
  FUN_0056d9d0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x37;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x38;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x39;
  uVar2 = FUN_0151ee70(auStack_70);
  iStack_8._0_1_ = 0x3a;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
  iStack_8._0_1_ = 0x3b;
  uVar2 = FUN_0151bb70(auStack_88);
  iStack_8._0_1_ = 0x3c;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  FUN_005507b0();
  FUN_0056d9d0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x3d;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x3e;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x3f;
  uVar2 = FUN_0151ef90(auStack_70);
  iStack_8._0_1_ = 0x40;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
  iStack_8._0_1_ = 0x41;
  uVar2 = FUN_0151bb70(auStack_88);
  iStack_8._0_1_ = 0x42;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  FUN_005507b0();
  FUN_0056d9d0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  if (DAT_01d67db8 != '\0') {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    iStack_8 = 0x43;
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    iStack_8._0_1_ = 0x44;
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = auStack_58[0] & 0xffffff00;
    FUN_005542c0(&DAT_018c36fc,1);
    iStack_8._0_1_ = 0x45;
    uVar2 = FUN_0151ed50(auStack_70);
    iStack_8._0_1_ = 0x46;
    FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
    iStack_8._0_1_ = 0x47;
    uVar2 = FUN_0151bb70(auStack_88);
    iStack_8._0_1_ = 0x48;
    FUN_0055b250(auStack_90,0,uVar2,param_1);
    FUN_005507b0();
    FUN_0056d9d0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_005507b0();
  }
  if (DAT_01d67d90 != '\0') {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    iStack_8 = 0x49;
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    iStack_8._0_1_ = 0x4a;
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = auStack_58[0] & 0xffffff00;
    FUN_005542c0(&DAT_018c36fc,1);
    iStack_8._0_1_ = 0x4b;
    uVar2 = FUN_0151ee30(auStack_70);
    iStack_8._0_1_ = 0x4c;
    FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
    iStack_8._0_1_ = 0x4d;
    uVar2 = FUN_0151bb70(auStack_88);
    iStack_8._0_1_ = 0x4e;
    FUN_0055b250(auStack_90,0,uVar2,param_1);
    FUN_005507b0();
    FUN_0056d9d0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_005507b0();
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    iStack_8 = 0x4f;
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    iStack_8._0_1_ = 0x50;
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = auStack_58[0] & 0xffffff00;
    FUN_005542c0(&DAT_018c36fc,1);
    iStack_8._0_1_ = 0x51;
    uVar2 = FUN_0151ecf0(auStack_70);
    iStack_8._0_1_ = 0x52;
    FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
    iStack_8._0_1_ = 0x53;
    uVar2 = FUN_0151bb70(auStack_88);
    iStack_8._0_1_ = 0x54;
    FUN_0055b250(auStack_90,0,uVar2,param_1);
    FUN_005507b0();
    FUN_0056d9d0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_005507b0();
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x55;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x56;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x57;
  uVar2 = FUN_0151eff0(auStack_70);
  iStack_8._0_1_ = 0x58;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
  iStack_8._0_1_ = 0x59;
  uVar2 = FUN_0151bb70(auStack_88);
  iStack_8._0_1_ = 0x5a;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  FUN_005507b0();
  FUN_0056d9d0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  if (DAT_01d67d98 != '\0') {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    iStack_8 = 0x5b;
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    iStack_8._0_1_ = 0x5c;
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = auStack_58[0] & 0xffffff00;
    FUN_005542c0(&DAT_018c36fc,1);
    iStack_8._0_1_ = 0x5d;
    uVar2 = FUN_0151f1a0(auStack_70);
    iStack_8._0_1_ = 0x5e;
    FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
    iStack_8._0_1_ = 0x5f;
    uVar2 = FUN_0151bb70(auStack_88);
    iStack_8._0_1_ = 0x60;
    FUN_0055b250(auStack_90,0,uVar2,param_1);
    FUN_005507b0();
    FUN_0056d9d0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_005507b0();
  }
  if (DAT_01d67da0 != '\0') {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    iStack_8 = 0x61;
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    iStack_8._0_1_ = 0x62;
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = auStack_58[0] & 0xffffff00;
    FUN_005542c0(&DAT_018c36fc,1);
    iStack_8._0_1_ = 99;
    uVar2 = FUN_0151eed0(auStack_70);
    iStack_8._0_1_ = 100;
    FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
    iStack_8._0_1_ = 0x65;
    uVar2 = FUN_0151bb70(auStack_88);
    iStack_8._0_1_ = 0x66;
    FUN_0055b250(auStack_90,0,uVar2,param_1);
    FUN_005507b0();
    FUN_0056d9d0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_005507b0();
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x67;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x68;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x69;
  uVar2 = FUN_0151ec30(auStack_70);
  iStack_8._0_1_ = 0x6a;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
  iStack_8._0_1_ = 0x6b;
  uVar2 = FUN_0151bb70(auStack_88);
  iStack_8._0_1_ = 0x6c;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  FUN_005507b0();
  FUN_0056d9d0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x6d;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x6e;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x6f;
  uVar2 = FUN_0151ef10(auStack_70);
  iStack_8._0_1_ = 0x70;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
  iStack_8._0_1_ = 0x71;
  uVar2 = FUN_0151bb70(auStack_88);
  iStack_8._0_1_ = 0x72;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  FUN_005507b0();
  FUN_0056d9d0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x73;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x74;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x75;
  uVar2 = FUN_0151edf0(auStack_70);
  iStack_8._0_1_ = 0x76;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
  iStack_8._0_1_ = 0x77;
  uVar2 = FUN_0151bb70(auStack_88);
  iStack_8._0_1_ = 0x78;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  FUN_005507b0();
  FUN_0056d9d0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x79;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x7a;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x7b;
  uVar2 = FUN_0151ef50(auStack_70);
  iStack_8._0_1_ = 0x7c;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
  iStack_8._0_1_ = 0x7d;
  uVar2 = FUN_0151bb70(auStack_88);
  iStack_8._0_1_ = 0x7e;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  FUN_005507b0();
  FUN_0056d9d0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x7f;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x80;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x81;
  uVar2 = FUN_0151f050(auStack_70);
  iStack_8._0_1_ = 0x82;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
  iStack_8._0_1_ = 0x83;
  uVar2 = FUN_0151bb70(auStack_88);
  iStack_8._0_1_ = 0x84;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  FUN_005507b0();
  FUN_0056d9d0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  if (DAT_01d67db0 != '\0') {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    iStack_8 = 0x85;
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    iStack_8._0_1_ = 0x86;
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = auStack_58[0] & 0xffffff00;
    FUN_005542c0(&DAT_018c36fc,1);
    iStack_8._0_1_ = 0x87;
    uVar2 = FUN_0151edb0(auStack_70);
    iStack_8._0_1_ = 0x88;
    FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
    iStack_8._0_1_ = 0x89;
    uVar2 = FUN_0151bb70(auStack_88);
    iStack_8._0_1_ = 0x8a;
    FUN_0055b250(auStack_90,0,uVar2,param_1);
    FUN_005507b0();
    FUN_0056d9d0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_005507b0();
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x8b;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x8c;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x8d;
  uVar2 = FUN_0151f1e0(auStack_70);
  iStack_8._0_1_ = 0x8e;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
  iStack_8._0_1_ = 0x8f;
  uVar2 = FUN_0151bb70(auStack_88);
  iStack_8._0_1_ = 0x90;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  FUN_005507b0();
  FUN_0056d9d0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  if ((DAT_01d63cb0 != '\0') || (DAT_01d67df8 != '\0')) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    iStack_8 = 0x91;
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    iStack_8._0_1_ = 0x92;
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = auStack_58[0] & 0xffffff00;
    FUN_005542c0(&DAT_018c36fc,1);
    iStack_8._0_1_ = 0x93;
    uVar2 = FUN_0151ec70(auStack_70);
    iStack_8._0_1_ = 0x94;
    FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
    iStack_8._0_1_ = 0x95;
    uVar2 = FUN_0151bb70(auStack_88);
    iStack_8._0_1_ = 0x96;
    FUN_0055b250(auStack_90,0,uVar2,param_1);
    FUN_005507b0();
    FUN_0056d9d0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_005507b0();
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x97;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x98;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x99;
  uVar2 = FUN_0151f010(auStack_70);
  iStack_8._0_1_ = 0x9a;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
  iStack_8._0_1_ = 0x9b;
  uVar2 = FUN_0151bb70(auStack_88);
  iStack_8._0_1_ = 0x9c;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  FUN_005507b0();
  FUN_0056d9d0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x9d;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x9e;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x9f;
  uVar2 = FUN_0151ef30(auStack_70);
  iStack_8._0_1_ = 0xa0;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
  iStack_8._0_1_ = 0xa1;
  uVar2 = FUN_0151bb70(auStack_88);
  iStack_8._0_1_ = 0xa2;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  FUN_005507b0();
  FUN_0056d9d0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0xa3;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0xa4;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0xa5;
  uVar2 = FUN_0151ee70(auStack_70);
  iStack_8._0_1_ = 0xa6;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
  iStack_8._0_1_ = 0xa7;
  uVar2 = FUN_0151bb70(auStack_88);
  iStack_8._0_1_ = 0xa8;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  FUN_005507b0();
  FUN_0056d9d0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  if (DAT_01d67da8 != '\0') {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    iStack_8 = 0xa9;
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    iStack_8._0_1_ = 0xaa;
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = auStack_58[0] & 0xffffff00;
    FUN_00551260(&DAT_018c36fc);
    iStack_8._0_1_ = 0xab;
    uVar2 = FUN_0151edd0(auStack_70);
    iStack_8._0_1_ = 0xac;
    FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
    iStack_8._0_1_ = 0xad;
    uVar2 = FUN_0151bb70(auStack_88);
    iStack_8 = CONCAT31(iStack_8._1_3_,0xae);
    FUN_00563ca0(auStack_90,uVar2);
    FUN_005507b0();
    FUN_0056d9d0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26313 ; VA 0x00bcee80 ; FUN_00bcee80 */

undefined4 * FUN_00bcee80(undefined4 *param_1)

{
  undefined uVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  undefined auStack_10c [120];
  undefined4 uStack_94;
  undefined auStack_90 [8];
  uint auStack_88 [4];
  undefined4 uStack_78;
  uint uStack_74;
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017ffaa1;
  pvStack_10 = ExceptionList;
  uStack_94 = 0;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  uVar2 = FUN_00575b30();
  *param_1 = uVar2;
  iStack_8 = 0;
  uStack_94 = 1;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 1;
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 2;
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 3;
  uVar2 = FUN_0151ec50(auStack_58);
  iStack_8._0_1_ = 4;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_88,auStack_70,auStack_28);
  iStack_8._0_1_ = 5;
  uVar2 = FUN_0151bb70(auStack_40);
  iStack_8._0_1_ = 6;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  iStack_8._0_1_ = 5;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 5;
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    uVar3 = auStack_40[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_40[0] - 4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_0056d9d0();
  iStack_8._0_1_ = 3;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 3;
  if (0xf < uStack_44) {
    uVar4 = uStack_44 + 1;
    uVar3 = auStack_58[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_58[0] - 4);
      uVar4 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  iStack_8._0_1_ = 2;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 2;
  if (0xf < uStack_74) {
    uVar4 = uStack_74 + 1;
    uVar3 = auStack_88[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_88[0] - 4);
      uVar4 = uStack_74 + 0x24;
      if (0x1f < (auStack_88[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  iStack_8._0_1_ = 1;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 1;
  if (0xf < uStack_5c) {
    uVar4 = uStack_5c + 1;
    uVar3 = auStack_70[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_70[0] - 4);
      uVar4 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    uVar3 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 7;
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 8;
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 9;
  uVar2 = FUN_0151ecd0(auStack_40);
  iStack_8._0_1_ = 10;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_70,auStack_88,auStack_28);
  iStack_8._0_1_ = 0xb;
  uVar2 = FUN_0151bb70(auStack_58);
  iStack_8._0_1_ = 0xc;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  iStack_8._0_1_ = 0xb;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 0xb;
  if (0xf < uStack_44) {
    uVar4 = uStack_44 + 1;
    uVar3 = auStack_58[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_58[0] - 4);
      uVar4 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_0056d9d0();
  iStack_8._0_1_ = 9;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 9;
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    uVar3 = auStack_40[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_40[0] - 4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  iStack_8._0_1_ = 8;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 8;
  if (0xf < uStack_5c) {
    uVar4 = uStack_5c + 1;
    uVar3 = auStack_70[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_70[0] - 4);
      uVar4 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  iStack_8._0_1_ = 7;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 7;
  if (0xf < uStack_74) {
    uVar4 = uStack_74 + 1;
    uVar3 = auStack_88[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_88[0] - 4);
      uVar4 = uStack_74 + 0x24;
      if (0x1f < (auStack_88[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    uVar3 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0xd;
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0xe;
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0xf;
  uVar2 = FUN_0151ee50(auStack_40);
  iStack_8._0_1_ = 0x10;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_70,auStack_88,auStack_28);
  iStack_8._0_1_ = 0x11;
  uVar2 = FUN_0151bb70(auStack_58);
  iStack_8._0_1_ = 0x12;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  iStack_8._0_1_ = 0x11;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 0x11;
  if (0xf < uStack_44) {
    uVar4 = uStack_44 + 1;
    uVar3 = auStack_58[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_58[0] - 4);
      uVar4 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_0056d9d0();
  iStack_8._0_1_ = 0xf;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 0xf;
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    uVar3 = auStack_40[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_40[0] - 4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  iStack_8._0_1_ = 0xe;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 0xe;
  if (0xf < uStack_5c) {
    uVar4 = uStack_5c + 1;
    uVar3 = auStack_70[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_70[0] - 4);
      uVar4 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  iStack_8._0_1_ = 0xd;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 0xd;
  if (0xf < uStack_74) {
    uVar4 = uStack_74 + 1;
    uVar3 = auStack_88[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_88[0] - 4);
      uVar4 = uStack_74 + 0x24;
      if (0x1f < (auStack_88[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    uVar3 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x13;
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x14;
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x15;
  uVar2 = FUN_0151ee70(auStack_40);
  iStack_8._0_1_ = 0x16;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_70,auStack_88,auStack_28);
  iStack_8._0_1_ = 0x17;
  uVar2 = FUN_0151bb70(auStack_58);
  iStack_8._0_1_ = 0x18;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  iStack_8._0_1_ = 0x17;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 0x17;
  if (0xf < uStack_44) {
    uVar4 = uStack_44 + 1;
    uVar3 = auStack_58[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_58[0] - 4);
      uVar4 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_0056d9d0();
  iStack_8._0_1_ = 0x15;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 0x15;
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    uVar3 = auStack_40[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_40[0] - 4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  iStack_8._0_1_ = 0x14;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 0x14;
  if (0xf < uStack_5c) {
    uVar4 = uStack_5c + 1;
    uVar3 = auStack_70[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_70[0] - 4);
      uVar4 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  iStack_8._0_1_ = 0x13;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 0x13;
  if (0xf < uStack_74) {
    uVar4 = uStack_74 + 1;
    uVar3 = auStack_88[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_88[0] - 4);
      uVar4 = uStack_74 + 0x24;
      if (0x1f < (auStack_88[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    uVar3 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x19;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x1a;
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x1b;
  uVar2 = FUN_0151f1c0(auStack_40);
  iStack_8._0_1_ = 0x1c;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_70,auStack_28,auStack_88);
  iStack_8._0_1_ = 0x1d;
  uVar2 = FUN_0151bb70(auStack_58);
  iStack_8._0_1_ = 0x1e;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  iStack_8._0_1_ = 0x1d;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 0x1d;
  if (0xf < uStack_44) {
    uVar4 = uStack_44 + 1;
    uVar3 = auStack_58[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_58[0] - 4);
      uVar4 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_0056d9d0();
  iStack_8._0_1_ = 0x1b;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 0x1b;
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    uVar3 = auStack_40[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_40[0] - 4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  iStack_8._0_1_ = 0x1a;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 0x1a;
  if (0xf < uStack_5c) {
    uVar4 = uStack_5c + 1;
    uVar3 = auStack_70[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_70[0] - 4);
      uVar4 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar3) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  FUN_005507b0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x1f;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x20;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x21;
  uVar2 = FUN_0151eff0(auStack_88);
  iStack_8._0_1_ = 0x22;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
  iStack_8._0_1_ = 0x23;
  uVar2 = FUN_0151bb70(auStack_70);
  iStack_8._0_1_ = 0x24;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  FUN_005507b0();
  FUN_0056d9d0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x25;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x26;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x27;
  uVar2 = FUN_0151ef10(auStack_88);
  iStack_8._0_1_ = 0x28;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
  iStack_8._0_1_ = 0x29;
  uVar2 = FUN_0151bb70(auStack_70);
  iStack_8._0_1_ = 0x2a;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  FUN_005507b0();
  FUN_0056d9d0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x2b;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x2c;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x2d;
  uVar2 = FUN_0151edf0(auStack_88);
  iStack_8._0_1_ = 0x2e;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
  iStack_8._0_1_ = 0x2f;
  uVar2 = FUN_0151bb70(auStack_70);
  iStack_8._0_1_ = 0x30;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  FUN_005507b0();
  FUN_0056d9d0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  if (DAT_01d63cb0 != '\0') {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    iStack_8 = 0x31;
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    iStack_8._0_1_ = 0x32;
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = auStack_58[0] & 0xffffff00;
    FUN_005542c0(&DAT_018c36fc,1);
    iStack_8._0_1_ = 0x33;
    uVar2 = FUN_0151ec70(auStack_88);
    iStack_8._0_1_ = 0x34;
    FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
    iStack_8._0_1_ = 0x35;
    uVar2 = FUN_0151bb70(auStack_70);
    iStack_8._0_1_ = 0x36;
    FUN_0055b250(auStack_90,0,uVar2,param_1);
    FUN_005507b0();
    FUN_0056d9d0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_005507b0();
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x37;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x38;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x39;
  uVar2 = FUN_0151ef30(auStack_88);
  iStack_8._0_1_ = 0x3a;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
  iStack_8._0_1_ = 0x3b;
  uVar2 = FUN_0151bb70(auStack_70);
  iStack_8._0_1_ = 0x3c;
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  FUN_005507b0();
  FUN_0056d9d0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8 = 0x3d;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  iStack_8._0_1_ = 0x3e;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c36fc,1);
  iStack_8._0_1_ = 0x3f;
  uVar2 = FUN_0151f1e0(auStack_88);
  iStack_8._0_1_ = 0x40;
  FUN_0151bcc0(auStack_10c,&DAT_01d67e08,uVar2,auStack_58,auStack_40,auStack_28);
  iStack_8._0_1_ = 0x41;
  uVar2 = FUN_0151bb70(auStack_70);
  iStack_8 = CONCAT31(iStack_8._1_3_,0x42);
  FUN_0055b250(auStack_90,0,uVar2,param_1);
  FUN_005507b0();
  FUN_0056d9d0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26314 ; VA 0x00bd0060 ; FUN_00bd0060 */

void FUN_00bd0060(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ffac2;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x148);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        FUN_00bc5ba0(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00bc7710();
        FUN_01674ea0(iVar3,0x148);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1df3dd4);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::shared_ptr<class_RBX::HttpRbxApiService>,struct_RBX::HttpRbxApiService::HttpApiRequest,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>),class_boost::_bi::list3<class_boost::_bi::value<class_std::shared_ptr<class_RBX::HttpRbxApiService>_>,class_boost::_bi::value<struct_RBX::HttpRbxApiService::HttpApiRequest>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26315 ; VA 0x00bd01c0 ; FUN_00bd01c0 */

void FUN_00bd01c0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ffae2;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_01674e20(0x168);
      uStack_8 = 0;
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = *puVar1;
        FUN_00bc5dc0(puVar1 + 2);
        *param_2 = (int)puVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        uVar2 = *(uint *)(iVar4 + 0x148);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(iVar4 + 0x150,iVar4 + 0x150,2);
            }
          }
          *(undefined4 *)(iVar4 + 0x148) = 0;
        }
        FUN_00bc7710();
        FUN_01674ea0(iVar4,0x168);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1df3b7c);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::shared_ptr<class_RBX::HttpRbxApiService>,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::shared_ptr<class_std::exception>,struct_RBX::HttpRbxApiService::HttpApiRequest,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>),class_boost::_bi::list6<class_boost::_bi::value<class_std::shared_ptr<class_RBX::HttpRbxApiService>_>,struct_boost::arg<1>,struct_boost::arg<2>,class_boost::_bi::value<struct_RBX::HttpRbxApiService::HttpApiRequest>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26316 ; VA 0x00bd0360 ; FUN_00bd0360 */

void FUN_00bd0360(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ffb02;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_01674e20(0x170);
      uStack_8 = 0;
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = *puVar1;
        FUN_00bc60d0(puVar1 + 2);
        *param_2 = (int)puVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        uVar2 = *(uint *)(iVar4 + 0x150);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(iVar4 + 0x158,iVar4 + 0x158,2);
            }
          }
          *(undefined4 *)(iVar4 + 0x150) = 0;
        }
        FUN_00bc77e0();
        FUN_01674ea0(iVar4,0x170);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1df390c);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::HttpRbxApiService>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>*,class_std::exception*,struct_RBX::HttpRbxApiService::HttpApiRequest,enum_RBX::ThrottlingPriority,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>),class_boost::_bi::list7<class_boost::_bi::value<class_std::weak_ptr<class_RBX::HttpRbxApiService>_>,struct_boost::arg<1>,struct_boost::arg<2>,class_boost::_bi::value<struct_RBX::HttpRbxApiService::HttpApiRequest>,class_boost::_bi::value<enum_RBX::ThrottlingPriority>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26317 ; VA 0x00bd0500 ; FUN_00bd0500 */

int __thiscall FUN_00bd0500(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ffb20;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_01ef5a9c);
  uStack_8._0_1_ = 1;
  FUN_00bc85c0(param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  iVar4 = FUN_01675290(uVar3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 26318 ; VA 0x00bd0590 ; FUN_00bd0590 */

void __thiscall FUN_00bd0590(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  char cVar2;
  double *pdVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int *piVar7;
  int iVar8;
  undefined4 *puVar9;
  char *pcVar10;
  undefined4 uStack_54;
  int *piStack_50;
  code **ppcStack_4c;
  int aiStack_40 [2];
  code *pcStack_38;
  int iStack_34;
  int iStack_30;
  uint uStack_2c;
  code *pcStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ffb8b;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 == (int *)0x0) goto LAB_00bd0811;
  ExceptionList = &pvStack_10;
  if (*(char *)(param_1 + 0x118) != '\0') {
    if (*(char *)(param_1 + 0xfa) == '\0') {
      if (*(char *)(param_1 + 0xf8) == '\0') {
        ExceptionList = &pvStack_10;
        if (*(char *)(param_1 + 0xf9) == '\0') goto LAB_00bd071e;
        ppcStack_4c = (code **)0x0;
        piStack_50 = (int *)0x0;
        uStack_54 = *(undefined4 *)(param_1 + 0x108);
        ExceptionList = &pvStack_10;
        FUN_0087c450(&DAT_018c5f98,"HttpRbxApiService","TotalHttpApiCallsInClient");
        pdVar3 = (double *)FUN_01682800(&iStack_20);
        iVar4 = (int)(((double)*(int *)(param_1 + 0x108) +
                      (double)(&DAT_018c0d90)[-(*(int *)(param_1 + 0x108) >> 0x1f)]) /
                     (*pdVar3 - *(double *)(param_1 + 0x110)));
        iVar8 = iVar4 >> 0x1f;
        pcVar10 = "AvgHttpApiCallsPerSecInClient";
      }
      else {
        ppcStack_4c = (code **)0x0;
        piStack_50 = (int *)0x0;
        uStack_54 = *(undefined4 *)(param_1 + 0x108);
        ExceptionList = &pvStack_10;
        FUN_0087c450(&DAT_018c5f98,"HttpRbxApiService","TotalHttpApiCallsInServer");
        pdVar3 = (double *)FUN_01682800(&iStack_20);
        iVar4 = (int)(((double)*(int *)(param_1 + 0x108) +
                      (double)(&DAT_018c0d90)[-(*(int *)(param_1 + 0x108) >> 0x1f)]) /
                     (*pdVar3 - *(double *)(param_1 + 0x110)));
        iVar8 = iVar4 >> 0x1f;
        pcVar10 = "AvgHttpApiCallsPerSecInServer";
      }
    }
    else {
      ppcStack_4c = (code **)0x0;
      piStack_50 = (int *)0x0;
      uStack_54 = *(undefined4 *)(param_1 + 0x108);
      ExceptionList = &pvStack_10;
      FUN_0087c450(&DAT_018c5f98,"HttpRbxApiService","TotalHttpApiCallsInPlaySolo");
      pdVar3 = (double *)FUN_01682800(&iStack_20);
      iVar4 = (int)(((double)*(int *)(param_1 + 0x108) +
                    (double)(&DAT_018c0d90)[-(*(int *)(param_1 + 0x108) >> 0x1f)]) /
                   (*pdVar3 - *(double *)(param_1 + 0x110)));
      iVar8 = iVar4 >> 0x1f;
      pcVar10 = "AvgHttpApiCallsPerSecInPlaySolo";
    }
    FUN_0087c450(&DAT_018c5f98,"HttpRbxApiService",pcVar10,iVar4,iVar8,0);
  }
LAB_00bd071e:
  ppcStack_4c = (code **)0xbd0729;
  FUN_01679490();
  ppcStack_4c = (code **)0xbd0734;
  FUN_01679490();
  *(undefined2 *)(param_1 + 0xf8) = 0;
  *(undefined *)(param_1 + 0xfa) = 0;
  piVar7 = *(int **)(param_1 + 0xcc);
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar7[1] = piVar7[1] + 1;
    UNLOCK();
    piVar7 = *(int **)(param_1 + 0xcc);
  }
  iStack_20 = *(int *)(param_1 + 200);
  uStack_8 = 0;
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar7[1] = piVar7[1] + 1;
    UNLOCK();
  }
  piStack_1c = piVar7;
  FUN_0151dac0(iStack_20,piVar7,1,0);
  uStack_8 = 0xffffffff;
  if (piVar7 != (int *)0x0) {
    LOCK();
    iVar4 = piVar7[1] + -1;
    piVar7[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      ppcStack_4c = (code **)0xbd07be;
      (**(code **)*piVar7)();
      LOCK();
      iVar4 = piVar7[2] + -1;
      piVar7[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        ppcStack_4c = (code **)0xbd07cf;
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  *(undefined4 *)(param_1 + 200) = 0;
  piStack_14 = *(int **)(param_1 + 0xcc);
  *(undefined4 *)(param_1 + 0xcc) = 0;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_14[1] + -1;
    piStack_14[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      ppcStack_4c = (code **)0xbd0800;
      (**(code **)*piStack_14)();
      LOCK();
      iVar4 = piStack_14[2] + -1;
      piStack_14[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        ppcStack_4c = (code **)0xbd0811;
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
LAB_00bd0811:
  piVar7 = param_3;
  ppcStack_4c = (code **)param_3;
  piStack_50 = param_2;
  uStack_54 = 0xbd081f;
  FUN_008a4210();
  if (piVar7 != (int *)0x0) {
    ppcStack_4c = (code **)0xbd082e;
    FUN_005c2760();
    ppcStack_4c = (code **)aiStack_40;
    piStack_50 = (undefined4 *)0xbd0839;
    puVar5 = (undefined4 *)FUN_008cc950();
    puVar9 = (undefined4 *)(param_1 + 0xe0);
    uStack_8 = 1;
    if (puVar9 != puVar5) {
      ppcStack_4c = (code **)puVar5[4];
      if (0xf < (uint)puVar5[5]) {
        puVar5 = (undefined4 *)*puVar5;
      }
      uStack_54 = 0xbd085e;
      piStack_50 = puVar5;
      FUN_005542c0();
    }
    uStack_8 = 0xffffffff;
    if (0xf < uStack_2c) {
      ppcStack_4c = (code **)(uStack_2c + 1);
      iVar4 = aiStack_40[0];
      if (0xfff < ppcStack_4c) {
        iVar4 = *(int *)(aiStack_40[0] + -4);
        ppcStack_4c = (code **)(uStack_2c + 0x24);
        if (0x1f < (aiStack_40[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          ppcStack_4c = (code **)&UNK_00bd0c8b;
          FUN_017167a3();
        }
      }
      uStack_54 = 0xbd0896;
      piStack_50 = (int *)iVar4;
      FUN_01674ea0();
    }
    ppcStack_4c = (code **)&iStack_20;
    piStack_50 = (int *)0xbd08a2;
    FUN_01682800();
    piVar7 = param_3;
    *(int *)(param_1 + 0x110) = iStack_20;
    *(int **)(param_1 + 0x114) = piStack_1c;
    if (*(int *)(param_1 + 0xf0) == 0) {
      ppcStack_4c = (code **)0xbd0a30;
      FUN_005c4070();
      pcStack_28 = FUN_00bd2e60;
      uStack_24 = 0;
      ppcStack_4c = &pcStack_28;
      piStack_50 = (int *)&param_2;
      uStack_54 = 0xbd0a53;
      iStack_20 = param_1;
      param_3 = (int *)FUN_00836450();
      uStack_8 = 2;
      piStack_50 = (int *)0xbd0a6b;
      ppcStack_4c = (code **)param_3;
      cVar2 = FUN_01679300();
      if (cVar2 != '\0') {
        ppcStack_4c = (code **)0xbd0a7a;
        FUN_01679490();
        ppcStack_4c = (code **)param_3;
        piStack_50 = (int *)0xbd0a88;
        FUN_016791c0();
      }
      uStack_8 = 0xffffffff;
      if (param_2 != (int *)0x0) {
        piVar1 = param_2 + 1;
        LOCK();
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          ppcStack_4c = (code **)param_2;
          piStack_50 = (int *)0xbd0ab5;
          FUN_01674ea0();
        }
      }
    }
    else {
      ppcStack_4c = (code **)0x0;
      piStack_50 = (int *)&DAT_01d67e08;
      uStack_54 = 0xbd08cf;
      uVar6 = FUN_0058ee60();
      ppcStack_4c = (code **)0x0;
      piStack_50 = (int *)&DAT_018bc9b8;
      uStack_54 = DAT_01d67e18;
      FUN_00591430(uVar6);
      piVar7 = param_3;
      if (puVar9 != (undefined4 *)&DAT_01d67d58) {
        ppcStack_4c = *(code ***)(param_1 + 0xf0);
        if (0xf < *(uint *)(param_1 + 0xf4)) {
          puVar9 = (undefined4 *)*puVar9;
        }
        uStack_54 = 0xbd0903;
        piStack_50 = puVar9;
        FUN_005542c0();
        piVar7 = param_3;
      }
    }
    piStack_50 = (int *)0xbd090e;
    ppcStack_4c = (code **)piVar7;
    FUN_00bc85c0();
    if ((*(char *)(param_1 + 0xf8) == '\0') && (*(char *)(param_1 + 0xf9) == '\0')) {
      ppcStack_4c = (code **)0xbd092f;
      iVar4 = FUN_005cf750();
      if (iVar4 != 0) {
        pcStack_28 = FUN_00bd0c90;
        ppcStack_4c = &pcStack_28;
        uStack_24 = 0;
        piStack_50 = (int *)&param_2;
        uStack_54 = 0xbd0954;
        iStack_20 = param_1;
        param_3 = (int *)FUN_00836450();
        uStack_8 = 3;
        piStack_50 = (int *)0xbd096c;
        ppcStack_4c = (code **)param_3;
        cVar2 = FUN_01679300();
        if (cVar2 != '\0') {
          ppcStack_4c = (code **)0xbd097b;
          FUN_01679490();
          ppcStack_4c = (code **)param_3;
          piStack_50 = (int *)0xbd0989;
          FUN_016791c0();
        }
        if (param_2 != (int *)0x0) {
          piVar1 = param_2 + 1;
          LOCK();
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            ppcStack_4c = (code **)param_2;
            piStack_50 = (int *)0xbd09a7;
            FUN_01674ea0();
          }
        }
      }
      param_2 = piVar7 + 0x1c;
      pcStack_38 = FUN_00bd0500;
      iStack_34 = 0;
      ppcStack_4c = (code **)DAT_02110da8;
      uStack_8 = 4;
      piStack_50 = (int *)0xbd09d3;
      iStack_30 = param_1;
      piVar7 = (int *)FUN_01675290();
      piStack_50 = (int *)0x28;
      uStack_8._0_1_ = 5;
      uStack_54 = 0xbd09e3;
      piStack_1c = piVar7;
      piStack_14 = (int *)FUN_01674e20();
      if (piStack_14 == (int *)0x0) {
        piStack_14 = (int *)0x0;
      }
      else {
        *piStack_14 = 0;
        piStack_14[1] = 1;
        piStack_14[2] = (int)FUN_00923570;
        piStack_14[3] = (int)_guard_check_icall;
        piStack_14[4] = 0;
        piStack_14[5] = (int)param_2;
        piStack_14[6] = (int)pcStack_38;
        piStack_14[7] = iStack_34;
        piStack_14[8] = iStack_30;
        piStack_14[9] = uStack_2c;
      }
      piStack_50 = (int *)0xbd0ac8;
      ppcStack_4c = (code **)piStack_14;
      FUN_016797d0();
      param_3 = piStack_14;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        piStack_14[1] = piStack_14[1] + 1;
        UNLOCK();
      }
      uStack_18 = 1;
      uStack_8._0_1_ = 6;
      piStack_50 = (int *)0xbd0aef;
      ppcStack_4c = (code **)piVar7;
      FUN_01675290();
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      ppcStack_4c = (code **)&param_3;
      piStack_50 = (int *)0xbd0b05;
      cVar2 = FUN_01679300();
      if (cVar2 != '\0') {
        ppcStack_4c = (code **)0xbd0b14;
        FUN_01679490();
        ppcStack_4c = (code **)&param_3;
        piStack_50 = (int *)0xbd0b23;
        FUN_016791c0();
      }
      uStack_8 = 0xffffffff;
      if (param_3 != (int *)0x0) {
        piVar7 = param_3 + 1;
        LOCK();
        iVar4 = *piVar7;
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          ppcStack_4c = (code **)param_3;
          piStack_50 = (int *)0xbd0b48;
          FUN_01674ea0();
        }
      }
    }
    ppcStack_4c = (code **)0x140;
    piStack_50 = (int *)0xbd0b55;
    param_3 = (int *)FUN_01674e20();
    uStack_8 = 7;
    if (param_3 == (undefined4 *)0x0) {
      puVar9 = (undefined4 *)0x0;
    }
    else {
      ppcStack_4c = (code **)0xb;
      uVar6 = FUN_008f7870(param_1);
      FUN_005c4330(&uStack_54,uVar6);
      puVar9 = param_3;
      FUN_00a360a0("HttpRbxApiJob",1,0);
      piStack_50 = puVar9 + 0x4a;
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      *puVar9 = RBX::HttpRbxApiJob::vftable;
      uStack_54 = 0xbd0ba7;
      ppcStack_4c = (code **)param_1;
      FUN_0060dcd0();
      *(double *)(puVar9 + 0x4e) = (double)(DAT_018ce2f8 / (float)DAT_01d67d50);
      puVar9[0x4c] = DAT_01d67d50;
    }
    ppcStack_4c = (code **)param_3;
    uStack_8 = 0xffffffff;
    iStack_20 = 0;
    piStack_1c = (int *)0x0;
    uStack_54 = 0xbd0bfc;
    piStack_50 = puVar9;
    FUN_00bc47f0();
    *(int *)(param_1 + 200) = iStack_20;
    param_3 = *(int **)(param_1 + 0xcc);
    *(int **)(param_1 + 0xcc) = piStack_1c;
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar4 = param_3[1] + -1;
      param_3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        ppcStack_4c = (code **)0xbd0c2b;
        (**(code **)*param_3)();
        LOCK();
        piVar7 = param_3 + 2;
        iVar4 = *piVar7;
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          ppcStack_4c = (code **)0xbd0c3b;
          (**(code **)(*param_3 + 4))();
        }
      }
    }
    if (*(int *)(param_1 + 0xcc) != 0) {
      LOCK();
      piVar7 = (int *)(*(int *)(param_1 + 0xcc) + 4);
      *piVar7 = *piVar7 + 1;
      UNLOCK();
    }
    piStack_50 = *(int **)(param_1 + 200);
    ppcStack_4c = *(code ***)(param_1 + 0xcc);
    uStack_54 = 0xbd0c71;
    FUN_0151d950();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26319 ; VA 0x00bd0c90 ; FUN_00bd0c90 */

void __thiscall FUN_00bd0c90(int param_1,undefined *param_2)

{
  float fVar1;
  float fVar2;
  
  if (((*(char *)(param_1 + 0xf8) == '\0') && (*(char *)(param_1 + 0xf9) == '\0')) &&
     (param_2 == PTR_DAT_02120610)) {
    FUN_01679490();
    FUN_01679490();
    *(undefined *)(param_1 + 0xfa) = 1;
    fVar1 = (float)DAT_01d67cd4;
    fVar2 = *(float *)(param_1 + 0x58) + fVar1;
    if (fVar2 <= fVar1) {
      fVar1 = fVar2;
    }
    *(float *)(param_1 + 0x58) = fVar1;
    fVar1 = (float)DAT_01d67cd4;
    fVar2 = *(float *)(param_1 + 0x5c) + fVar1;
    if (fVar2 <= fVar1) {
      fVar1 = fVar2;
    }
    *(float *)(param_1 + 0x5c) = fVar1;
    fVar1 = (float)DAT_01d67cc4;
    fVar2 = fVar1 + *(float *)(param_1 + 0x60);
    if (fVar2 <= fVar1) {
      fVar1 = fVar2;
    }
    *(float *)(param_1 + 0x60) = fVar1;
    fVar1 = (float)DAT_01d67cec;
    fVar2 = *(float *)(param_1 + 100) + fVar1;
    if (fVar2 <= fVar1) {
      fVar1 = fVar2;
    }
    *(float *)(param_1 + 100) = fVar1;
  }
  return;
}



/* FUNCTION 26320 ; VA 0x00bd0d70 ; FUN_00bd0d70 */

void FUN_00bd0d70(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 uint param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10,undefined8 param_11,uint *param_12)

{
  uint *puVar1;
  uint auStack_34 [2];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ffba8;
  pvStack_10 = ExceptionList;
  uStack_14 = param_12;
  uStack_8 = 0;
  param_12 = auStack_34;
  auStack_34[0] = 0;
  ExceptionList = &pvStack_10;
  puVar1 = auStack_34;
  if (param_5 != 0) {
    auStack_34[0] = param_5;
    if ((param_5 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_2c,0);
      puVar1 = param_12;
    }
    else {
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = param_10;
      uStack_1c = param_11;
      ExceptionList = &pvStack_10;
      puVar1 = auStack_34;
    }
  }
  param_12 = puVar1;
  FUN_014cd990(param_2,param_3,param_4);
  uStack_8 = 1;
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    uStack_14 = 2;
    uStack_1c = CONCAT44(&param_7,&param_7);
    uStack_20 = 0xbd0e0b;
    (**(code **)(param_5 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26321 ; VA 0x00bd0e20 ; FUN_00bd0e20 */

void __thiscall
FUN_00bd0e20(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 *param_11,ulonglong param_12,uint param_13,
            undefined4 param_14,undefined1 *param_15,char *param_16,undefined4 ***param_17,
            undefined4 param_18,undefined8 param_19)

{
  uint *puVar1;
  char cVar2;
  undefined4 *puVar3;
  uint auStack_78 [2];
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 *puStack_64;
  ulonglong uStack_60;
  uint auStack_58 [2];
  undefined1 *puStack_50;
  char *pcStack_4c;
  undefined4 **ppuStack_48;
  undefined4 *puStack_44;
  undefined8 uStack_40;
  undefined4 **appuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ffbf1;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined *)0x0;
  puVar3 = (undefined4 *)(param_2 + 0x18);
  uStack_8 = 1;
  uStack_40 = CONCAT44(puVar3,0xbd0e59);
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00bcc980();
  if ((cVar2 == '\0') && (*(char *)(param_1 + 0x118) != '\0')) {
    appuStack_30[0] = (undefined4 **)((uint)appuStack_30[0] & 0xffffff00);
    uStack_8._0_1_ = 2;
    uStack_20 = 0;
    uStack_1c = 0xf;
    puStack_14 = (undefined *)0x1;
    uStack_40 = CONCAT44(*(int *)(param_2 + 0x28) + 0x1b,0xbd0e94);
    FUN_0058a190();
    uStack_40 = 0x1b0195d580;
    puStack_44 = (undefined4 *)0xbd0ea3;
    FUN_00554150();
    if (0xf < *(uint *)(param_2 + 0x2c)) {
      puVar3 = (undefined4 *)*puVar3;
    }
    uStack_40 = CONCAT44(*(undefined4 *)(param_2 + 0x28),puVar3);
    puStack_44 = (undefined4 *)0xbd0eb8;
    FUN_00554150();
    ppuStack_48 = appuStack_30;
    if (0xf < uStack_1c) {
      ppuStack_48 = appuStack_30[0];
    }
    uStack_40 = 0;
    puStack_44 = (undefined4 *)0x0;
    pcStack_4c = "HttpRbxApiService";
    puStack_50 = &DAT_018c5f98;
    auStack_58[1] = 0xbd0ed9;
    FUN_0087c450();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    uStack_40 = CONCAT44(0xbd0ee8,(undefined4)uStack_40);
    FUN_005507b0();
  }
  puStack_14 = (undefined *)auStack_58;
  puStack_18 = (undefined *)auStack_58;
  auStack_58[0] = 0;
  puVar1 = auStack_58;
  if (param_13 != 0) {
    auStack_58[0] = param_13;
    if ((param_13 & 1) == 0) {
      uStack_60 = ZEXT48(&puStack_50);
      puStack_64 = &param_15;
      uStack_68 = 0xbd0f2c;
      (**(code **)(param_13 & 0xfffffffe))();
      puVar1 = (uint *)puStack_14;
    }
    else {
      puStack_50 = param_15;
      pcStack_4c = param_16;
      ppuStack_48 = param_17;
      puStack_44 = (undefined4 *)param_18;
      uStack_40 = param_19;
      puVar1 = auStack_58;
    }
  }
  puStack_14 = (undefined *)puVar1;
  puStack_18 = (undefined *)auStack_78;
  uStack_8._0_1_ = 3;
  auStack_78[0] = 0;
  puVar1 = auStack_78;
  if (param_6 != 0) {
    auStack_78[0] = param_6;
    if ((param_6 & 1) == 0) {
      (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_70,0);
      puVar1 = (uint *)puStack_18;
    }
    else {
      uStack_70 = param_8;
      uStack_6c = param_9;
      uStack_68 = param_10;
      puStack_64 = param_11;
      uStack_60 = param_12;
      puVar1 = auStack_78;
    }
  }
  puStack_18 = (undefined *)puVar1;
  uStack_8._0_1_ = 1;
  FUN_00bd1750(param_2,param_3,&param_5,&param_4);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (param_6 != 0) {
    if (((param_6 & 1) == 0) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0)) {
      puStack_44 = &param_8;
      uStack_40 = CONCAT44(2,puStack_44);
      ppuStack_48 = (undefined4 **)0xbd0fb1;
      (**(code **)(param_6 & 0xfffffffe))();
    }
    param_6 = 0;
  }
  uStack_8 = 5;
  if (((param_13 != 0) && ((param_13 & 1) == 0)) &&
     (*(code **)(param_13 & 0xfffffffe) != (code *)0x0)) {
    puStack_44 = &param_15;
    uStack_40 = CONCAT44(2,puStack_44);
    ppuStack_48 = (undefined4 **)0xbd0fdf;
    (**(code **)(param_13 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26322 ; VA 0x00bd1000 ; FUN_00bd1000 */

void __thiscall FUN_00bd1000(int param_1,undefined4 *param_2)

{
  undefined uVar1;
  uint *puVar2;
  uint *puVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  uint uVar8;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_0000002c;
  uint in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined *in_stack_0000003c;
  uint in_stack_00000040;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 *in_stack_00000054;
  ulonglong in_stack_00000058;
  uint in_stack_00000060;
  undefined4 in_stack_00000068;
  undefined4 in_stack_0000006c;
  undefined4 in_stack_00000070;
  undefined4 in_stack_00000074;
  undefined8 in_stack_00000078;
  undefined auStack_b4 [20];
  undefined4 uStack_a0;
  undefined4 *puStack_9c;
  undefined4 *puStack_98;
  undefined4 uStack_94;
  uint auStack_90 [2];
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 *puStack_7c;
  ulonglong uStack_78;
  uint auStack_70 [2];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  uint *puStack_5c;
  undefined8 uStack_58;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  undefined8 uStack_3c;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ffc48;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  puStack_5c = auStack_34;
  uStack_58 = CONCAT44(param_1 + 0xe0,&DAT_01d67e08);
  uStack_60 = 0xbd103a;
  ExceptionList = &pvStack_10;
  FUN_005f3cd0();
  puVar6 = &param_2;
  if (0xf < in_stack_00000018) {
    puVar6 = param_2;
  }
  uStack_58 = CONCAT44(in_stack_00000014,puVar6);
  uStack_8._0_1_ = 4;
  puStack_5c = (uint *)0xbd1057;
  piVar4 = (int *)FUN_00554150();
  iStack_4c = *piVar4;
  iStack_48 = piVar4[1];
  iStack_44 = piVar4[2];
  iStack_40 = piVar4[3];
  uStack_3c = *(undefined8 *)(piVar4 + 4);
  piVar4[4] = 0;
  piVar4[5] = 0xf;
  *(undefined *)piVar4 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (0xf < uStack_20) {
    uVar7 = uStack_20 + 1;
    uVar8 = auStack_34[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_34[0] - 4);
      uVar7 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar8) - 4) {
        uStack_58 = CONCAT44(0xbd12d3,(undefined4)uStack_58);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_58 = CONCAT44(uVar7,uVar8);
    puStack_5c = (uint *)0xbd10ae;
    FUN_01674ea0();
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_58 = CONCAT44(&param_2,&iStack_4c);
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  puStack_5c = (uint *)0xbd10d2;
  FUN_00bc84c0();
  puStack_14 = (undefined *)auStack_70;
  puStack_18 = (undefined *)auStack_70;
  auStack_70[0] = 0;
  puVar2 = auStack_70;
  if (in_stack_00000060 != 0) {
    auStack_70[0] = in_stack_00000060;
    if ((in_stack_00000060 & 1) == 0) {
      uStack_78 = ZEXT48(&uStack_68);
      puStack_7c = &stack0x00000068;
      uStack_80 = 0xbd1116;
      (**(code **)(in_stack_00000060 & 0xfffffffe))();
      puVar2 = (uint *)puStack_14;
    }
    else {
      uStack_68 = in_stack_00000068;
      uStack_64 = in_stack_0000006c;
      uStack_60 = in_stack_00000070;
      puStack_5c = (uint *)in_stack_00000074;
      uStack_58 = in_stack_00000078;
      puVar2 = auStack_70;
    }
  }
  puStack_14 = (undefined *)puVar2;
  puStack_18 = (undefined *)auStack_90;
  puStack_1c = (undefined *)auStack_90;
  uStack_8._0_1_ = 7;
  auStack_90[0] = 0;
  puVar2 = auStack_90;
  puVar3 = auStack_90;
  if (in_stack_00000040 != 0) {
    auStack_90[0] = in_stack_00000040;
    if ((in_stack_00000040 & 1) == 0) {
      puStack_98 = &uStack_88;
      uStack_94 = 0;
      puStack_9c = &stack0x00000048;
      uStack_a0 = 0xbd1161;
      (**(code **)(in_stack_00000040 & 0xfffffffe))();
      puVar2 = (uint *)puStack_1c;
      puVar3 = (uint *)puStack_18;
    }
    else {
      uStack_88 = in_stack_00000048;
      uStack_84 = in_stack_0000004c;
      uStack_80 = in_stack_00000050;
      puStack_7c = in_stack_00000054;
      uStack_78 = in_stack_00000058;
      puVar2 = auStack_90;
      puVar3 = auStack_90;
    }
  }
  puStack_18 = (undefined *)puVar3;
  puStack_1c = (undefined *)puVar2;
  uStack_94 = in_stack_0000003c;
  uStack_8._0_1_ = 8;
  puStack_98 = (undefined4 *)in_stack_00000038;
  puStack_9c = (undefined4 *)in_stack_00000034;
  in_stack_0000003c = auStack_b4;
  FUN_0054ef60(&stack0x0000001c);
  uStack_8._0_1_ = 9;
  FUN_0054ef60(&iStack_4c);
  uStack_8._0_1_ = 6;
  FUN_00bd12f0();
  uStack_8._0_1_ = 3;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_3c._4_4_) {
    uVar8 = uStack_3c._4_4_ + 1;
    iVar5 = iStack_4c;
    if (0xfff < uVar8) {
      iVar5 = *(int *)(iStack_4c + -4);
      uVar8 = uStack_3c._4_4_ + 0x24;
      if (0x1f < (iStack_4c - iVar5) - 4U) {
        uStack_58 = CONCAT44(0xbd12d8,(undefined4)uStack_58);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_58 = CONCAT44(uVar8,iVar5);
    puStack_5c = (uint *)0xbd11d4;
    FUN_01674ea0();
  }
  uStack_8._0_1_ = 2;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < in_stack_00000018) {
    uVar8 = in_stack_00000018 + 1;
    puVar6 = param_2;
    if (0xfff < uVar8) {
      puVar6 = (undefined4 *)param_2[-1];
      uVar8 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar6))) {
        uStack_58 = CONCAT44(0xbd12dd,(undefined4)uStack_58);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_58 = CONCAT44(uVar8,puVar6);
    puStack_5c = (uint *)0xbd120c;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = (undefined4 *)((uint)param_2 & 0xffffff00);
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000030) {
    uVar7 = in_stack_00000030 + 1;
    uVar8 = in_stack_0000001c;
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(in_stack_0000001c - 4);
      uVar7 = in_stack_00000030 + 0x24;
      if (0x1f < (in_stack_0000001c - uVar8) - 4) {
        uStack_58 = CONCAT44(&UNK_00bd12e2,(undefined4)uStack_58);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_58 = CONCAT44(uVar7,uVar8);
    puStack_5c = (uint *)0xbd1256;
    FUN_01674ea0();
  }
  in_stack_0000002c = 0;
  in_stack_00000030 = 0xf;
  in_stack_0000001c = in_stack_0000001c & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  if (in_stack_00000040 != 0) {
    if (((in_stack_00000040 & 1) == 0) &&
       (*(code **)(in_stack_00000040 & 0xfffffffe) != (code *)0x0)) {
      puStack_5c = &stack0x00000048;
      uStack_58 = CONCAT44(2,puStack_5c);
      uStack_60 = 0xbd128c;
      (**(code **)(in_stack_00000040 & 0xfffffffe))();
    }
    in_stack_00000040 = 0;
  }
  uStack_8 = 0xb;
  if (((in_stack_00000060 != 0) && ((in_stack_00000060 & 1) == 0)) &&
     (*(code **)(in_stack_00000060 & 0xfffffffe) != (code *)0x0)) {
    puStack_5c = &stack0x00000068;
    uStack_58 = CONCAT44(2,puStack_5c);
    uStack_60 = 0xbd12ba;
    (**(code **)(in_stack_00000060 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26323 ; VA 0x00bd12f0 ; FUN_00bd12f0 */

void __thiscall FUN_00bd12f0(undefined4 param_1,uint param_2)

{
  undefined uVar1;
  uint *puVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_0000002c;
  uint in_stack_00000030;
  uint *in_stack_0000003c;
  uint in_stack_00000040;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 *in_stack_00000054;
  ulonglong in_stack_00000058;
  uint in_stack_00000060;
  undefined4 in_stack_00000068;
  undefined4 in_stack_0000006c;
  undefined4 in_stack_00000070;
  undefined4 *in_stack_00000074;
  undefined8 in_stack_00000078;
  uint auStack_c0 [2];
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 *puStack_ac;
  ulonglong uStack_a8;
  uint auStack_a0 [2];
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 *puStack_8c;
  undefined8 uStack_88;
  undefined auStack_7c [104];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ffc90;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  uStack_88 = CONCAT44(param_1,0xbd131b);
  ExceptionList = &pvStack_10;
  FUN_008f7870();
  uStack_88 = CONCAT44(0xbd1325,(undefined4)uStack_88);
  uVar3 = FUN_008f7f00();
  uStack_88 = CONCAT44(uVar3,in_stack_0000003c);
  puStack_8c = &param_2;
  uStack_90 = 0xbd1335;
  FUN_014cc090();
  in_stack_0000003c = auStack_a0;
  puStack_14 = (undefined *)auStack_a0;
  uStack_8._0_1_ = 4;
  auStack_a0[0] = 0;
  puVar2 = auStack_a0;
  if (in_stack_00000060 != 0) {
    auStack_a0[0] = in_stack_00000060;
    if ((in_stack_00000060 & 1) == 0) {
      uStack_a8 = ZEXT48(&uStack_98);
      puStack_ac = &stack0x00000068;
      uStack_b0 = 0xbd137d;
      (**(code **)(in_stack_00000060 & 0xfffffffe))();
      puVar2 = in_stack_0000003c;
    }
    else {
      uStack_98 = in_stack_00000068;
      uStack_94 = in_stack_0000006c;
      uStack_90 = in_stack_00000070;
      puStack_8c = in_stack_00000074;
      uStack_88 = in_stack_00000078;
      puVar2 = auStack_a0;
    }
  }
  in_stack_0000003c = puVar2;
  puStack_14 = (undefined *)auStack_c0;
  uStack_8._0_1_ = 5;
  auStack_c0[0] = 0;
  puVar2 = auStack_c0;
  if (in_stack_00000040 != 0) {
    auStack_c0[0] = in_stack_00000040;
    if ((in_stack_00000040 & 1) == 0) {
      (**(code **)(in_stack_00000040 & 0xfffffffe))(&stack0x00000048,&uStack_b8,0);
      puVar2 = (uint *)puStack_14;
    }
    else {
      uStack_b8 = in_stack_00000048;
      uStack_b4 = in_stack_0000004c;
      uStack_b0 = in_stack_00000050;
      puStack_ac = in_stack_00000054;
      uStack_a8 = in_stack_00000058;
      puVar2 = auStack_c0;
    }
  }
  puStack_14 = (undefined *)puVar2;
  uStack_8._0_1_ = 4;
  FUN_00bd1750(auStack_7c,&stack0x0000001c,&stack0x00000038,&stack0x00000034);
  uStack_88 = CONCAT44(0xbd13eb,(undefined4)uStack_88);
  FUN_0056db40();
  uStack_8._0_1_ = 2;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < in_stack_00000018) {
    uVar5 = in_stack_00000018 + 1;
    uVar4 = param_2;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(param_2 - 4);
      uVar5 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - uVar4) - 4) {
        uStack_88 = CONCAT44(0xbd14e7,(undefined4)uStack_88);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_88 = CONCAT44(uVar5,uVar4);
    puStack_8c = (undefined4 *)0xbd1420;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000030) {
    uVar5 = in_stack_00000030 + 1;
    uVar4 = in_stack_0000001c;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(in_stack_0000001c - 4);
      uVar5 = in_stack_00000030 + 0x24;
      if (0x1f < (in_stack_0000001c - uVar4) - 4) {
        uStack_88 = CONCAT44(&UNK_00bd14ec,(undefined4)uStack_88);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_88 = CONCAT44(uVar5,uVar4);
    puStack_8c = (undefined4 *)0xbd146a;
    FUN_01674ea0();
  }
  in_stack_0000002c = 0;
  in_stack_00000030 = 0xf;
  in_stack_0000001c = in_stack_0000001c & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (in_stack_00000040 != 0) {
    if (((in_stack_00000040 & 1) == 0) &&
       (*(code **)(in_stack_00000040 & 0xfffffffe) != (code *)0x0)) {
      puStack_8c = &stack0x00000048;
      uStack_88 = CONCAT44(2,puStack_8c);
      uStack_90 = 0xbd14a0;
      (**(code **)(in_stack_00000040 & 0xfffffffe))();
    }
    in_stack_00000040 = 0;
  }
  uStack_8 = 7;
  if (((in_stack_00000060 != 0) && ((in_stack_00000060 & 1) == 0)) &&
     (*(code **)(in_stack_00000060 & 0xfffffffe) != (code *)0x0)) {
    puStack_8c = &stack0x00000068;
    uStack_88 = CONCAT44(2,puStack_8c);
    uStack_90 = 0xbd14ce;
    (**(code **)(in_stack_00000060 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26324 ; VA 0x00bd14f0 ; FUN_00bd14f0 */

void __thiscall FUN_00bd14f0(undefined4 param_1,uint param_2)

{
  int iVar1;
  undefined uVar2;
  uint *puVar3;
  char cVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_0000002c;
  uint in_stack_00000030;
  uint *in_stack_0000003c;
  uint in_stack_00000040;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 *in_stack_00000054;
  ulonglong in_stack_00000058;
  uint in_stack_00000060;
  undefined4 in_stack_00000068;
  undefined4 in_stack_0000006c;
  undefined4 in_stack_00000070;
  undefined4 in_stack_00000074;
  undefined8 in_stack_00000078;
  uint auStack_d4 [2];
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 *puStack_c0;
  ulonglong uStack_bc;
  uint auStack_b4 [2];
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 *puStack_a0;
  undefined8 uStack_9c;
  undefined auStack_8c [104];
  undefined auStack_24 [12];
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ffcd3;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  uStack_9c = CONCAT44(param_1,0xbd151f);
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  FUN_008f7870();
  uStack_9c = CONCAT44(0xbd1529,(undefined4)uStack_9c);
  uVar5 = FUN_008f7f00();
  uStack_9c = CONCAT44(uVar5,in_stack_0000003c);
  puStack_a0 = &param_2;
  uStack_a4 = 0xbd153c;
  FUN_014cc090();
  iVar1 = DAT_02131fc0;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  uStack_9c = CONCAT44(0xbd154b,(undefined4)uStack_9c);
  uVar5 = FUN_01255560();
  uStack_9c = CONCAT44(5,uVar5);
  puStack_a0 = (undefined4 *)0xbd1555;
  cVar4 = FUN_01255580();
  if (cVar4 == '\0') {
    uStack_9c = 5;
    puStack_a0 = (undefined4 *)0xbd1567;
    FUN_01255600();
  }
  if (iVar1 == 5) {
    in_stack_0000003c = auStack_b4;
    puStack_18 = (undefined *)auStack_b4;
    auStack_b4[0] = 0;
    puVar3 = auStack_b4;
    if (in_stack_00000060 != 0) {
      auStack_b4[0] = in_stack_00000060;
      if ((in_stack_00000060 & 1) == 0) {
        uStack_bc = ZEXT48(&uStack_ac);
        puStack_c0 = &stack0x00000068;
        uStack_c4 = 0xbd15b4;
        (**(code **)(in_stack_00000060 & 0xfffffffe))();
        puVar3 = in_stack_0000003c;
      }
      else {
        uStack_ac = in_stack_00000068;
        uStack_a8 = in_stack_0000006c;
        uStack_a4 = in_stack_00000070;
        puStack_a0 = (undefined4 *)in_stack_00000074;
        uStack_9c = in_stack_00000078;
        puVar3 = auStack_b4;
      }
    }
    in_stack_0000003c = puVar3;
    puStack_18 = (undefined *)auStack_d4;
    uStack_8._0_1_ = 5;
    auStack_d4[0] = 0;
    puVar3 = auStack_d4;
    if (in_stack_00000040 != 0) {
      auStack_d4[0] = in_stack_00000040;
      if ((in_stack_00000040 & 1) == 0) {
        (**(code **)(in_stack_00000040 & 0xfffffffe))(&stack0x00000048,&uStack_cc,0);
        puVar3 = (uint *)puStack_18;
      }
      else {
        uStack_cc = in_stack_00000048;
        uStack_c8 = in_stack_0000004c;
        uStack_c4 = in_stack_00000050;
        puStack_c0 = in_stack_00000054;
        uStack_bc = in_stack_00000058;
        puVar3 = auStack_d4;
      }
    }
    puStack_18 = (undefined *)puVar3;
    uStack_8._0_1_ = 4;
    FUN_00bd1750(auStack_8c,&stack0x0000001c,&stack0x00000038,&stack0x00000034);
    uStack_9c = CONCAT44(0xbd1629,(undefined4)uStack_9c);
    FUN_0056db40();
    uStack_8._0_1_ = 2;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 2;
    if (0xf < in_stack_00000018) {
      uVar7 = in_stack_00000018 + 1;
      uVar6 = param_2;
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(param_2 - 4);
        uVar7 = in_stack_00000018 + 0x24;
        if (0x1f < (param_2 - uVar6) - 4) {
          uStack_9c = CONCAT44(0xbd1741,(undefined4)uStack_9c);
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_9c = CONCAT44(uVar7,uVar6);
      puStack_a0 = (undefined4 *)0xbd165e;
      FUN_01674ea0();
    }
    in_stack_00000014 = 0;
    in_stack_00000018 = 0xf;
    param_2 = param_2 & 0xffffff00;
    uStack_8._0_1_ = 1;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (0xf < in_stack_00000030) {
      uVar7 = in_stack_00000030 + 1;
      uVar6 = in_stack_0000001c;
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(in_stack_0000001c - 4);
        uVar7 = in_stack_00000030 + 0x24;
        if (0x1f < (in_stack_0000001c - uVar6) - 4) {
          uStack_9c = CONCAT44(&UNK_00bd1746,(undefined4)uStack_9c);
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_9c = CONCAT44(uVar7,uVar6);
      puStack_a0 = (undefined4 *)0xbd16a8;
      FUN_01674ea0();
    }
    in_stack_0000002c = 0;
    in_stack_00000030 = 0xf;
    in_stack_0000001c = in_stack_0000001c & 0xffffff00;
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (in_stack_00000040 != 0) {
      if (((in_stack_00000040 & 1) == 0) &&
         (*(code **)(in_stack_00000040 & 0xfffffffe) != (code *)0x0)) {
        puStack_a0 = &stack0x00000048;
        uStack_9c = CONCAT44(2,puStack_a0);
        uStack_a4 = 0xbd16de;
        (**(code **)(in_stack_00000040 & 0xfffffffe))();
      }
      in_stack_00000040 = 0;
    }
    uStack_8 = 7;
    if (((in_stack_00000060 != 0) && ((in_stack_00000060 & 1) == 0)) &&
       (*(code **)(in_stack_00000060 & 0xfffffffe) != (code *)0x0)) {
      puStack_a0 = &stack0x00000068;
      uStack_9c = CONCAT44(2,puStack_a0);
      uStack_a4 = 0xbd170c;
      (**(code **)(in_stack_00000060 & 0xfffffffe))();
    }
    ExceptionList = pvStack_10;
    return;
  }
  uStack_9c = 0x18bc9b800bd172e;
  FUN_00550130();
  uStack_9c = CONCAT44(&DAT_01c17198,auStack_24);
                    /* WARNING: Subroutine does not return */
  puStack_a0 = (undefined4 *)0xbd173c;
  FUN_0170c2a8();
}



/* FUNCTION 26325 ; VA 0x00bd1750 ; FUN_00bd1750 */

void FUN_00bd1750(undefined4 param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4,
                 uint param_5)

{
  undefined4 *puVar1;
  undefined4 ***pppuVar2;
  uint in_stack_00000034;
  uint in_stack_0000003c;
  undefined4 in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined8 in_stack_0000004c;
  uint uStack_160;
  undefined4 uStack_15c;
  undefined4 uStack_158;
  undefined4 *puStack_154;
  undefined8 uStack_150;
  undefined auStack_140 [48];
  undefined uStack_110;
  undefined uStack_d8;
  undefined4 auStack_bc [19];
  undefined4 uStack_70;
  undefined4 **appuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ffd03;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  appuStack_28[0] = (undefined4 **)((uint)appuStack_28[0] & 0xffffff00);
  uStack_8 = 2;
  switch(*param_3) {
  case 0:
    puVar1 = &DAT_01d79f98;
    uStack_150._4_4_ = DAT_01d79fa8;
    if (0xf < DAT_01d79fac) {
      puVar1 = DAT_01d79f98;
    }
    break;
  case 1:
    puVar1 = &DAT_01d79fb0;
    uStack_150._4_4_ = DAT_01d79fc0;
    if (0xf < DAT_01d79fc4) {
      puVar1 = DAT_01d79fb0;
    }
    break;
  case 2:
    puVar1 = &DAT_01d79f80;
    uStack_150._4_4_ = DAT_01d79f90;
    if (0xf < DAT_01d79f94) {
      puVar1 = DAT_01d79f80;
    }
    break;
  case 3:
    puVar1 = &DAT_01d79fc8;
    uStack_150._4_4_ = DAT_01d79fd8;
    if (0xf < DAT_01d79fdc) {
      puVar1 = DAT_01d79fc8;
    }
    break;
  case 4:
    uStack_150._4_4_ = DAT_01d79ff0;
    puVar1 = &DAT_01d79fe0;
    if (0xf < DAT_01d79ff4) {
      puVar1 = DAT_01d79fe0;
    }
    break;
  default:
    uStack_150 = 0xf00000000;
    uStack_160 = uStack_160 & 0xffffff00;
    ExceptionList = &pvStack_10;
    FUN_005542c0();
    FUN_005e65e0();
    goto LAB_00bd1962;
  }
  uStack_150 = CONCAT44(uStack_150._4_4_,puVar1);
  puStack_154 = (undefined4 *)0xbd1832;
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  if (param_2[4] == 0) {
    uStack_150 = 0x1018c0cc8;
    puStack_154 = (undefined4 *)0xbd1849;
    FUN_005542c0();
  }
  uStack_150 = CONCAT44(0xbd1854,(undefined4)uStack_150);
  FUN_00bc6ff0();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_d8 = 1;
  if (auStack_bc != param_2) {
    puVar1 = param_2 + 4;
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    uStack_150 = CONCAT44(*puVar1,param_2);
    puStack_154 = (undefined4 *)0xbd1881;
    FUN_005542c0();
  }
  pppuVar2 = appuStack_28;
  if (0xf < uStack_14) {
    pppuVar2 = (undefined4 ***)appuStack_28[0];
  }
  uStack_150 = CONCAT44(uStack_18,pppuVar2);
  puStack_154 = (undefined4 *)0xbd189b;
  FUN_005542c0();
  uStack_150 = CONCAT44(&param_5,0xbd18a7);
  FUN_008c4480();
  uStack_150 = CONCAT44(&stack0x00000034,0xbd18b3);
  FUN_008c4480();
  uStack_70 = *param_4;
  uStack_150 = CONCAT44(param_1,0xbd18c9);
  FUN_00bc7cb0();
  uStack_110 = 0;
  if (in_stack_00000034 != 0) {
    if ((in_stack_00000034 & 1) == 0) {
      (**(code **)(in_stack_00000034 & 0xfffffffe))(&stack0x0000003c,&uStack_160,0);
    }
    else {
      uStack_160 = in_stack_0000003c;
      uStack_15c = in_stack_00000040;
      uStack_158 = in_stack_00000044;
      puStack_154 = (undefined4 *)in_stack_00000048;
      uStack_150 = in_stack_0000004c;
    }
  }
  FUN_00bca580(auStack_140,param_4);
  uStack_150 = CONCAT44(0xbd192e,(undefined4)uStack_150);
  FUN_00bc7880();
  uStack_150 = CONCAT44(0xbd1936,(undefined4)uStack_150);
  FUN_005507b0();
LAB_00bd1962:
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (param_5 != 0) {
    if (((param_5 & 1) == 0) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0)) {
      puStack_154 = (undefined4 *)&stack0x0000001c;
      uStack_150 = CONCAT44(2,puStack_154);
      uStack_158 = 0xbd1983;
      (**(code **)(param_5 & 0xfffffffe))();
    }
    param_5 = 0;
  }
  uStack_8 = 5;
  if (((in_stack_00000034 != 0) && ((in_stack_00000034 & 1) == 0)) &&
     (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
    puStack_154 = &stack0x0000003c;
    uStack_150 = CONCAT44(2,puStack_154);
    uStack_158 = 0xbd19b1;
    (**(code **)(in_stack_00000034 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26326 ; VA 0x00bd19e0 ; FUN_00bd19e0 */

void __thiscall FUN_00bd19e0(int param_1,undefined4 *param_2)

{
  undefined uVar1;
  uint *puVar2;
  uint *puVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  uint uVar8;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_0000002c;
  uint in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined *in_stack_0000003c;
  uint in_stack_00000040;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 *in_stack_00000054;
  ulonglong in_stack_00000058;
  uint in_stack_00000060;
  undefined4 in_stack_00000068;
  undefined4 in_stack_0000006c;
  undefined4 in_stack_00000070;
  undefined4 in_stack_00000074;
  undefined8 in_stack_00000078;
  undefined auStack_b4 [20];
  undefined4 uStack_a0;
  undefined4 *puStack_9c;
  undefined4 *puStack_98;
  undefined4 uStack_94;
  uint auStack_90 [2];
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 *puStack_7c;
  ulonglong uStack_78;
  uint auStack_70 [2];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  uint *puStack_5c;
  undefined8 uStack_58;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  undefined8 uStack_3c;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ffc48;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  puStack_5c = auStack_34;
  uStack_58 = CONCAT44(param_1 + 0xe0,&DAT_01d67e08);
  uStack_60 = 0xbd1a1a;
  ExceptionList = &pvStack_10;
  FUN_005f3cd0();
  puVar6 = &param_2;
  if (0xf < in_stack_00000018) {
    puVar6 = param_2;
  }
  uStack_58 = CONCAT44(in_stack_00000014,puVar6);
  uStack_8._0_1_ = 4;
  puStack_5c = (uint *)0xbd1a37;
  piVar4 = (int *)FUN_00554150();
  iStack_4c = *piVar4;
  iStack_48 = piVar4[1];
  iStack_44 = piVar4[2];
  iStack_40 = piVar4[3];
  uStack_3c = *(undefined8 *)(piVar4 + 4);
  piVar4[4] = 0;
  piVar4[5] = 0xf;
  *(undefined *)piVar4 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (0xf < uStack_20) {
    uVar7 = uStack_20 + 1;
    uVar8 = auStack_34[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_34[0] - 4);
      uVar7 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar8) - 4) {
        uStack_58 = CONCAT44(0xbd1cb3,(undefined4)uStack_58);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_58 = CONCAT44(uVar7,uVar8);
    puStack_5c = (uint *)0xbd1a8e;
    FUN_01674ea0();
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_58 = CONCAT44(&param_2,&iStack_4c);
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  puStack_5c = (uint *)0xbd1ab2;
  FUN_00bc84c0();
  puStack_14 = (undefined *)auStack_70;
  puStack_18 = (undefined *)auStack_70;
  auStack_70[0] = 0;
  puVar2 = auStack_70;
  if (in_stack_00000060 != 0) {
    auStack_70[0] = in_stack_00000060;
    if ((in_stack_00000060 & 1) == 0) {
      uStack_78 = ZEXT48(&uStack_68);
      puStack_7c = &stack0x00000068;
      uStack_80 = 0xbd1af6;
      (**(code **)(in_stack_00000060 & 0xfffffffe))();
      puVar2 = (uint *)puStack_14;
    }
    else {
      uStack_68 = in_stack_00000068;
      uStack_64 = in_stack_0000006c;
      uStack_60 = in_stack_00000070;
      puStack_5c = (uint *)in_stack_00000074;
      uStack_58 = in_stack_00000078;
      puVar2 = auStack_70;
    }
  }
  puStack_14 = (undefined *)puVar2;
  puStack_18 = (undefined *)auStack_90;
  puStack_1c = (undefined *)auStack_90;
  uStack_8._0_1_ = 7;
  auStack_90[0] = 0;
  puVar2 = auStack_90;
  puVar3 = auStack_90;
  if (in_stack_00000040 != 0) {
    auStack_90[0] = in_stack_00000040;
    if ((in_stack_00000040 & 1) == 0) {
      puStack_98 = &uStack_88;
      uStack_94 = 0;
      puStack_9c = &stack0x00000048;
      uStack_a0 = 0xbd1b41;
      (**(code **)(in_stack_00000040 & 0xfffffffe))();
      puVar2 = (uint *)puStack_1c;
      puVar3 = (uint *)puStack_18;
    }
    else {
      uStack_88 = in_stack_00000048;
      uStack_84 = in_stack_0000004c;
      uStack_80 = in_stack_00000050;
      puStack_7c = in_stack_00000054;
      uStack_78 = in_stack_00000058;
      puVar2 = auStack_90;
      puVar3 = auStack_90;
    }
  }
  puStack_18 = (undefined *)puVar3;
  puStack_1c = (undefined *)puVar2;
  uStack_94 = in_stack_0000003c;
  uStack_8._0_1_ = 8;
  puStack_98 = (undefined4 *)in_stack_00000038;
  puStack_9c = (undefined4 *)in_stack_00000034;
  in_stack_0000003c = auStack_b4;
  FUN_0054ef60(&stack0x0000001c);
  uStack_8._0_1_ = 9;
  FUN_0054ef60(&iStack_4c);
  uStack_8._0_1_ = 6;
  FUN_00bd14f0();
  uStack_8._0_1_ = 3;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_3c._4_4_) {
    uVar8 = uStack_3c._4_4_ + 1;
    iVar5 = iStack_4c;
    if (0xfff < uVar8) {
      iVar5 = *(int *)(iStack_4c + -4);
      uVar8 = uStack_3c._4_4_ + 0x24;
      if (0x1f < (iStack_4c - iVar5) - 4U) {
        uStack_58 = CONCAT44(0xbd1cb8,(undefined4)uStack_58);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_58 = CONCAT44(uVar8,iVar5);
    puStack_5c = (uint *)0xbd1bb4;
    FUN_01674ea0();
  }
  uStack_8._0_1_ = 2;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < in_stack_00000018) {
    uVar8 = in_stack_00000018 + 1;
    puVar6 = param_2;
    if (0xfff < uVar8) {
      puVar6 = (undefined4 *)param_2[-1];
      uVar8 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar6))) {
        uStack_58 = CONCAT44(0xbd1cbd,(undefined4)uStack_58);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_58 = CONCAT44(uVar8,puVar6);
    puStack_5c = (uint *)0xbd1bec;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = (undefined4 *)((uint)param_2 & 0xffffff00);
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000030) {
    uVar7 = in_stack_00000030 + 1;
    uVar8 = in_stack_0000001c;
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(in_stack_0000001c - 4);
      uVar7 = in_stack_00000030 + 0x24;
      if (0x1f < (in_stack_0000001c - uVar8) - 4) {
        uStack_58 = CONCAT44(&UNK_00bd1cc2,(undefined4)uStack_58);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_58 = CONCAT44(uVar7,uVar8);
    puStack_5c = (uint *)0xbd1c36;
    FUN_01674ea0();
  }
  in_stack_0000002c = 0;
  in_stack_00000030 = 0xf;
  in_stack_0000001c = in_stack_0000001c & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  if (in_stack_00000040 != 0) {
    if (((in_stack_00000040 & 1) == 0) &&
       (*(code **)(in_stack_00000040 & 0xfffffffe) != (code *)0x0)) {
      puStack_5c = &stack0x00000048;
      uStack_58 = CONCAT44(2,puStack_5c);
      uStack_60 = 0xbd1c6c;
      (**(code **)(in_stack_00000040 & 0xfffffffe))();
    }
    in_stack_00000040 = 0;
  }
  uStack_8 = 0xb;
  if (((in_stack_00000060 != 0) && ((in_stack_00000060 & 1) == 0)) &&
     (*(code **)(in_stack_00000060 & 0xfffffffe) != (code *)0x0)) {
    puStack_5c = &stack0x00000068;
    uStack_58 = CONCAT44(2,puStack_5c);
    uStack_60 = 0xbd1c9a;
    (**(code **)(in_stack_00000060 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26327 ; VA 0x00bd1cd0 ; FUN_00bd1cd0 */

void FUN_00bd1cd0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  FUN_014cdc70(param_2,param_3,param_4,param_5,param_6,param_7);
  return;
}



/* FUNCTION 26328 ; VA 0x00bd1d00 ; FUN_00bd1d00 */

undefined4 __thiscall FUN_00bd1d00(int *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int *piVar7;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ffd18;
  pvStack_10 = ExceptionList;
  piVar1 = param_1 + 2;
  piVar7 = param_1;
  ExceptionList = &pvStack_10;
  piStack_18 = param_1;
  if (param_1[1] == (param_1[3] - *piVar1) / 0x118) {
    uVar4 = param_1[1] * 2;
    uVar5 = 0x20;
    if (0x20 < uVar4) {
      uVar5 = uVar4;
    }
    ExceptionList = &pvStack_10;
    FUN_00bc6d50(uVar5,&uStack_11);
    uStack_8 = 0;
    iVar3 = (param_1[3] - *piVar1) / 0x118;
    if (iVar3 != 0) {
      iVar2 = param_1[1];
      iVar6 = iVar3 - *param_1;
      FUN_00bc5390(*param_1 * 0x118 + *piVar1,iVar3 * 0x118 + *piVar1,iStack_24);
      FUN_00bc5390(*piVar1,(iVar2 - iVar6) * 0x118 + *piVar1,iVar6 * 0x118 + iStack_24);
      piVar7 = piStack_18;
    }
    *piVar7 = 0;
    if (piVar1 != &iStack_24) {
      iVar3 = *piVar1;
      *piVar1 = iStack_24;
      iVar2 = param_1[3];
      param_1[3] = iStack_20;
      iVar6 = param_1[4];
      param_1[4] = iStack_1c;
      iStack_24 = iVar3;
      iStack_20 = iVar2;
      iStack_1c = iVar6;
    }
    uStack_8 = 0xffffffff;
    piVar7[5] = (param_1[3] - *piVar1) / 0x118 + -1;
    FUN_00bc8030();
  }
  FUN_00bc7d50(param_2);
  piVar7[1] = piVar7[1] + 1;
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 26329 ; VA 0x00bd1e60 ; FUN_00bd1e60 */

void FUN_00bd1e60(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,uint param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined8 param_12,
                 uint *param_13)

{
  uint *puVar1;
  uint auStack_34 [2];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ffd38;
  pvStack_10 = ExceptionList;
  uStack_14 = param_13;
  uStack_8 = 0;
  param_13 = auStack_34;
  auStack_34[0] = 0;
  ExceptionList = &pvStack_10;
  puVar1 = auStack_34;
  if (param_6 != 0) {
    auStack_34[0] = param_6;
    if ((param_6 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_2c,0);
      puVar1 = param_13;
    }
    else {
      uStack_2c = param_8;
      uStack_28 = param_9;
      uStack_24 = param_10;
      uStack_20 = param_11;
      uStack_1c = param_12;
      ExceptionList = &pvStack_10;
      puVar1 = auStack_34;
    }
  }
  param_13 = puVar1;
  FUN_014cdd60(param_2,param_3,param_4,param_5);
  uStack_8 = 1;
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    uStack_14 = 2;
    uStack_1c = CONCAT44(&param_8,&param_8);
    uStack_20 = 0xbd1efe;
    (**(code **)(param_6 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26330 ; VA 0x00bd1f20 ; FUN_00bd1f20 */

void FUN_00bd1f20(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,uint param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  uint in_stack_00000038;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ffd70;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if (DAT_01d67dc0 == '\0') {
    ExceptionList = &pvStack_10;
    FUN_005542c0();
    FUN_005e65e0();
  }
  else {
    ExceptionList = &pvStack_10;
    cVar3 = FUN_008f7bd0();
    if (cVar3 == '\0') {
      FUN_005542c0();
      FUN_005e65e0();
    }
    else {
      FUN_0054f510(&stack0x00000038);
      uStack_8._0_1_ = 3;
      FUN_0054f510(&param_6);
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[1] = param_2[1] + 1;
        UNLOCK();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_00bd2280(param_1,param_2,param_3,param_4,param_5,0);
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (param_6 != 0) {
    if (((param_6 & 1) == 0) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_6 & 0xfffffffe))();
    }
    param_6 = 0;
  }
  uStack_8 = 5;
  if (((in_stack_00000038 != 0) && ((in_stack_00000038 & 1) == 0)) &&
     (*(code **)(in_stack_00000038 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000038 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26331 ; VA 0x00bd20b0 ; FUN_00bd20b0 */

void FUN_00bd20b0(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,uint param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10,undefined4 *param_11,ulonglong param_12,
                 uint param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
                 undefined4 param_17,undefined4 param_18,undefined8 param_19)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  char cVar4;
  undefined4 uVar5;
  uint auStack_70 [2];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 *puStack_5c;
  ulonglong uStack_58;
  uint auStack_50 [2];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 *puStack_3c;
  undefined8 uStack_38;
  undefined auStack_28 [12];
  undefined *puStack_1c;
  undefined *puStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar2 = DAT_021320c0;
  puStack_c = &LAB_017ffda0;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_38 = CONCAT44(0xbd20e2,(undefined4)uStack_38);
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01255560();
  uStack_38 = CONCAT44(5,uVar5);
  puStack_3c = (undefined4 *)0xbd20ec;
  cVar4 = FUN_01255580();
  if (cVar4 == '\0') {
    uStack_38 = 5;
    puStack_3c = (undefined4 *)0xbd20fe;
    FUN_01255600();
  }
  if (iVar2 != 5) {
    uStack_38 = 0x18bc9b800bd226e;
    FUN_00550130();
    uStack_38 = CONCAT44(&DAT_01c17198,auStack_28);
                    /* WARNING: Subroutine does not return */
    puStack_3c = (undefined4 *)&UNK_00bd227c;
    FUN_0170c2a8();
  }
  puStack_18 = (undefined *)auStack_50;
  puStack_1c = (undefined *)auStack_50;
  auStack_50[0] = 0;
  puVar3 = auStack_50;
  if (param_13 != 0) {
    auStack_50[0] = param_13;
    if ((param_13 & 1) == 0) {
      uStack_58 = ZEXT48(&uStack_48);
      puStack_5c = &param_15;
      uStack_60 = 0xbd214b;
      (**(code **)(param_13 & 0xfffffffe))();
      puVar3 = (uint *)puStack_18;
    }
    else {
      uStack_48 = param_15;
      uStack_44 = param_16;
      uStack_40 = param_17;
      puStack_3c = (undefined4 *)param_18;
      uStack_38 = param_19;
      puVar3 = auStack_50;
    }
  }
  puStack_18 = (undefined *)puVar3;
  puStack_1c = (undefined *)auStack_70;
  uStack_8._0_1_ = 3;
  auStack_70[0] = 0;
  puVar3 = auStack_70;
  if (param_6 != 0) {
    auStack_70[0] = param_6;
    if ((param_6 & 1) == 0) {
      (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_68,0);
      puVar3 = (uint *)puStack_1c;
    }
    else {
      uStack_68 = param_8;
      uStack_64 = param_9;
      uStack_60 = param_10;
      puStack_5c = param_11;
      uStack_58 = param_12;
      puVar3 = auStack_70;
    }
  }
  puStack_1c = (undefined *)puVar3;
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00bd2280(param_1,param_2,param_3,param_4,param_5,1);
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_38 = CONCAT44(0xbd21ee,(undefined4)uStack_38);
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_38 = CONCAT44(0xbd21fd,(undefined4)uStack_38);
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    puStack_3c = &param_8;
    uStack_38 = CONCAT44(2,puStack_3c);
    uStack_40 = 0xbd221e;
    (**(code **)(param_6 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_13 != 0) && ((param_13 & 1) == 0)) &&
     (*(code **)(param_13 & 0xfffffffe) != (code *)0x0)) {
    puStack_3c = &param_15;
    uStack_38 = CONCAT44(2,puStack_3c);
    uStack_40 = 0xbd224c;
    (**(code **)(param_13 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26332 ; VA 0x00bd2280 ; FUN_00bd2280 */

void FUN_00bd2280(int param_1,int *param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
                 undefined4 **param_6,uint param_7)

{
  char *pcVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 **ppuVar5;
  char cVar6;
  int iVar7;
  int *piVar8;
  int ****ppppiVar9;
  int iVar10;
  int iVar11;
  undefined4 ****ppppuVar12;
  undefined4 *puVar13;
  undefined4 *in_stack_0000003c;
  int ***in_stack_00000044;
  undefined4 **in_stack_00000048;
  undefined *in_stack_0000004c;
  int ****in_stack_00000050;
  ulonglong in_stack_00000054;
  undefined4 *puStack_2bc;
  char *pcStack_2b8;
  int ***pppiStack_2b4;
  undefined4 **ppuStack_2b0;
  undefined *puStack_2ac;
  int ***pppiStack_2a8;
  undefined8 uStack_2a4;
  undefined4 ***pppuStack_29c;
  undefined auStack_290 [48];
  undefined uStack_260;
  undefined4 uStack_1c0;
  undefined auStack_178 [104];
  undefined auStack_110 [24];
  int ***apppiStack_f8 [4];
  uint uStack_e8;
  uint uStack_e4;
  undefined auStack_98 [24];
  undefined4 ***apppuStack_80 [4];
  undefined4 uStack_70;
  uint uStack_6c;
  int iStack_68;
  int ***apppiStack_64 [4];
  uint uStack_54;
  uint uStack_50;
  undefined4 uStack_4c;
  undefined4 ***apppuStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined4 ***apppuStack_30 [3];
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  uint uStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ffe2c;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  pppuStack_29c = (undefined4 ***)0xbd22b5;
  ExceptionList = &pvStack_10;
  FUN_00bc6ff0();
  uStack_8._0_1_ = 3;
  iStack_68 = param_1;
  if ((param_1 == 0) || (*(int *)(param_1 + 8) == 0)) {
    pppiStack_2b4 = (int ***)0x17;
    pcStack_2b8 = "Invalid request options";
LAB_00bd2b9a:
    uStack_2a4 = uStack_2a4 & 0xffffffff;
    pppuStack_29c = (undefined4 ***)0xf;
    ppuStack_2b0 = (undefined4 **)((uint)ppuStack_2b0 & 0xffffff00);
    puStack_2bc = (undefined4 *)0xbd2bb0;
    FUN_005542c0();
LAB_00bd2bb0:
    pppiStack_2b4 = (int ***)0xbd2bb8;
    FUN_005e65e0();
    goto LAB_00bd2bb8;
  }
  for (puVar13 = *(undefined4 **)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar13 != (undefined4 *)0x0; puVar13 = (undefined4 *)*puVar13) {
    ppppiVar9 = (int ****)(puVar13 + 2);
    pppiStack_2a8 = (int ***)ppppiVar9;
    if (0xf < (uint)puVar13[7]) {
      pppiStack_2a8 = *ppppiVar9;
    }
    pppuStack_29c = (undefined4 ***)0x6;
    uStack_2a4 = CONCAT44(&DAT_0193bd64,puVar13[6]);
    puStack_2ac = (undefined *)0xbd22ff;
    cVar6 = FUN_0055c360();
    if (cVar6 == '\0') {
      pppiStack_2a8 = (int ***)ppppiVar9;
      if (0xf < (uint)puVar13[7]) {
        pppiStack_2a8 = *ppppiVar9;
      }
      pppuStack_29c = (undefined4 ***)0x3;
      uStack_2a4 = CONCAT44(&DAT_018c8720,puVar13[6]);
      puStack_2ac = (undefined *)0xbd2320;
      cVar6 = FUN_0055c360();
      if (cVar6 == '\0') {
        pppiStack_2a8 = (int ***)ppppiVar9;
        if (0xf < (uint)puVar13[7]) {
          pppiStack_2a8 = *ppppiVar9;
        }
        pppuStack_29c = (undefined4 ***)0x4;
        uStack_2a4 = CONCAT44(&DAT_018c3bf4,puVar13[6]);
        puStack_2ac = (undefined *)0xbd2341;
        cVar6 = FUN_0055c360();
        if (cVar6 == '\0') {
          pppiStack_2a8 = (int ***)ppppiVar9;
          if (0xf < (uint)puVar13[7]) {
            pppiStack_2a8 = *ppppiVar9;
          }
          pppuStack_29c = (undefined4 ***)0x7;
          uStack_2a4 = CONCAT44("Headers",puVar13[6]);
          puStack_2ac = (undefined *)0xbd2362;
          cVar6 = FUN_0055c360();
          if (cVar6 == '\0') {
            puStack_2bc = &ppuStack_2b0;
            pcStack_2b8 = "Unrecognized request option ";
            pppiStack_2b4 = (int ***)ppppiVar9;
            FUN_00558df0();
            goto LAB_00bd2bb0;
          }
        }
      }
    }
  }
  pppuStack_29c = (undefined4 ***)0x3;
  uStack_38 = 0;
  uStack_34 = 0xf;
  apppuStack_48[0] = (undefined4 ***)((uint)apppuStack_48[0] & 0xffffff00);
  uStack_2a4 = 0x18c872000bd2394;
  FUN_005542c0();
  pppuStack_29c = apppuStack_48;
  uStack_2a4 = CONCAT44(&piStack_14,0xbd23a4);
  FUN_00580040();
  if (0xf < uStack_34) {
    pppuStack_29c = (undefined4 ***)(uStack_34 + 1);
    ppppuVar12 = (undefined4 ****)apppuStack_48[0];
    if (0xfff < pppuStack_29c) {
      ppppuVar12 = (undefined4 ****)apppuStack_48[0][-1];
      pppuStack_29c = (undefined4 ***)(uStack_34 + 0x24);
      if (0x1f < (uint)((int)apppuStack_48[0] + (-4 - (int)ppppuVar12))) {
                    /* WARNING: Subroutine does not return */
        pppuStack_29c = (undefined4 ***)0xbd2c54;
        FUN_017167a3();
      }
    }
    uStack_2a4 = CONCAT44(ppppuVar12,0xbd23f0);
    FUN_01674ea0();
  }
  if (piStack_14 == (int *)0x0) {
    pppiStack_2b4 = (int ***)0x25;
    pcStack_2b8 = "Invalid request options, Url is empty";
    goto LAB_00bd2b9a;
  }
  iVar11 = piStack_14[8];
  pppuStack_29c = (undefined4 ***)0xbd2413;
  iVar7 = FUN_0088cb40();
  if (iVar11 != iVar7) {
    pppiStack_2b4 = (int ***)0x2f;
    pcStack_2b8 = "Invalid request options, Url should be a string";
    goto LAB_00bd2b9a;
  }
  pppuStack_29c = apppuStack_80;
  uStack_2a4 = CONCAT44(0xbd2434,(uint)uStack_2a4);
  FUN_00563690();
  pppuStack_29c = (undefined4 ***)uStack_4c;
  uStack_8._0_1_ = 4;
  uStack_2a4 = CONCAT44(0xbd2440,(uint)uStack_2a4);
  FUN_008f7870();
  pppuStack_29c = (undefined4 ***)0xbd244a;
  pppuStack_29c = (undefined4 ***)FUN_008f7f00();
  uStack_2a4 = ZEXT48(apppuStack_80);
  pppiStack_2a8 = (int ***)0xbd245c;
  FUN_014cc090();
  pppuStack_29c = (undefined4 ***)0x6;
  uStack_8._0_1_ = 5;
  uStack_38 = 0;
  uStack_34 = 0xf;
  apppuStack_48[0] = (undefined4 ***)((uint)apppuStack_48[0] & 0xffffff00);
  uStack_2a4 = 0x193bd6400bd2484;
  FUN_005542c0();
  pppuStack_29c = apppuStack_48;
  uStack_2a4 = CONCAT44(&piStack_14,0xbd2493);
  piVar8 = (int *)FUN_00580040();
  iVar11 = *piVar8;
  pppuStack_29c = (undefined4 ***)0xbd249d;
  FUN_005507b0();
  pppuStack_29c = (undefined4 ***)0x3;
  uStack_54 = 0;
  uStack_50 = 0xf;
  apppiStack_64[0] = (int ***)((uint)apppiStack_64[0] & 0xffffff00);
  uStack_2a4 = 0x18c3c9400bd24be;
  FUN_005542c0();
  uStack_8._0_1_ = 6;
  if (iVar11 != 0) {
    iVar11 = *(int *)(iVar11 + 0x20);
    pppuStack_29c = (undefined4 ***)0xbd24ce;
    iVar7 = FUN_0088cb40();
    if (iVar11 != iVar7) {
      pppiStack_2b4 = (int ***)0x32;
      uStack_2a4 = uStack_2a4 & 0xffffffff;
      pppuStack_29c = (undefined4 ***)0xf;
      pcStack_2b8 = "Invalid request options, Method should be a string";
      ppuStack_2b0 = (undefined4 **)((uint)ppuStack_2b0 & 0xffffff00);
      puStack_2bc = (undefined4 *)0xbd24f4;
      FUN_005542c0();
      pppiStack_2b4 = (int ***)0xbd24fc;
      FUN_005e65e0();
      goto LAB_00bd2b71;
    }
    pppuStack_29c = apppuStack_48;
    uStack_2a4 = CONCAT44(0xbd250d,(uint)uStack_2a4);
    pppuStack_29c = (undefined4 ***)FUN_00563690();
    uStack_2a4 = CONCAT44(0xbd2516,(uint)uStack_2a4);
    FUN_005511f0();
    pppuStack_29c = (undefined4 ***)0xbd251e;
    FUN_005507b0();
  }
  pppuStack_29c = (undefined4 ***)uStack_54;
  ppppiVar9 = apppiStack_64;
  if (0xf < uStack_50) {
    ppppiVar9 = (int ****)apppiStack_64[0];
  }
  uStack_2a4 = CONCAT44(ppppiVar9,0xbd2538);
  FUN_005542c0();
  if ((DAT_01d67dc0 != '\0') && (param_6 == (undefined4 **)0x0)) {
    ppppuVar12 = apppuStack_80;
    if (0xf < uStack_6c) {
      ppppuVar12 = (undefined4 ****)apppuStack_80[0];
    }
    uStack_2a4 = CONCAT44(ppppuVar12,auStack_110);
    pppuStack_29c = (undefined4 ***)uStack_70;
    pppiStack_2a8 = (int ***)0xbd2576;
    FUN_0151bda0();
    puStack_24 = (undefined4 *)0x0;
    puStack_20 = (undefined4 *)0x0;
    uStack_1c = 0;
    pppuStack_29c = (undefined4 ***)0x1;
    piStack_14 = (int *)&pppiStack_2a8;
    pppiStack_2b4 = (int ***)&pppiStack_2a8;
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    puStack_2ac = (undefined *)0x1;
    ppuStack_2b0 = (undefined4 **)&DAT_018d1b9c;
    pppiStack_2a8 = (int ***)0x0;
    uStack_2a4._4_4_ = (undefined4 *)0x1;
    pcStack_2b8 = (char *)0xbd25b6;
    FUN_0170cc70();
    pcStack_2b8 = (char *)param_6;
    puStack_2bc = uStack_2a4._4_4_;
    FUN_0063e660(&pppiStack_2a8,(int)&pppiStack_2a8 + (int)uStack_2a4._4_4_);
    ppuStack_2b0 = &puStack_24;
    puStack_2ac = &DAT_01d67dc8;
    pppiStack_2b4 = (int ***)0xbd25d8;
    FUN_0063fd80();
    puVar4 = puStack_20;
    for (puVar13 = puStack_24; puVar13 != puVar4; puVar13 = puVar13 + 6) {
      uStack_2a4._4_4_ = puVar13;
      if (0xf < (uint)puVar13[5]) {
        uStack_2a4._4_4_ = (undefined4 *)*puVar13;
      }
      pppuStack_29c = (undefined4 ***)puVar13[4];
      pppiStack_2a8 = (int ***)apppiStack_f8;
      if (0xf < uStack_e4) {
        pppiStack_2a8 = apppiStack_f8[0];
      }
      puStack_2ac = (undefined *)0xbd2613;
      uStack_2a4._0_4_ = uStack_e8;
      cVar6 = FUN_0055c360();
      if (cVar6 != '\0') {
        pppuStack_29c = (undefined4 ***)0xbd266f;
        FUN_00577a40();
        pppuStack_29c = (undefined4 ***)0xbd267a;
        FUN_0056d9d0();
        puStack_24 = (undefined4 *)0x0;
        puStack_20 = (undefined4 *)0x0;
        uStack_1c = 0;
        pppuStack_29c = (undefined4 ***)0x1;
        piStack_14 = (int *)&pppiStack_2a8;
        pppiStack_2b4 = (int ***)&pppiStack_2a8;
        uStack_8 = CONCAT31(uStack_8._1_3_,9);
        puStack_2ac = (undefined *)0x1;
        ppuStack_2b0 = (undefined4 **)&DAT_018d1b9c;
        pppiStack_2a8 = (int ***)0x0;
        uStack_2a4._4_4_ = (undefined4 *)0x1;
        pcStack_2b8 = (char *)0xbd26b7;
        FUN_0170cc70();
        pcStack_2b8 = (char *)param_6;
        puStack_2bc = uStack_2a4._4_4_;
        FUN_0063e660(&pppiStack_2a8,(int)uStack_2a4._4_4_ + (int)&pppiStack_2a8);
        ppuStack_2b0 = &puStack_24;
        puStack_2ac = &DAT_01d67de0;
        pppiStack_2b4 = (int ***)0xbd26d9;
        FUN_0063fd80();
        puVar4 = puStack_20;
        puVar13 = puStack_24;
        goto joined_r0x00bd26e4;
      }
    }
    pppuStack_29c = (undefined4 ***)0xbd2629;
    FUN_00577a40();
    uStack_8._0_1_ = 6;
    pppuStack_29c = (undefined4 ***)0xbd2638;
    FUN_0056d9d0();
    pppiStack_2b4 = (int ***)0x27;
    uStack_2a4 = (ulonglong)(uint)uStack_2a4;
    pppuStack_29c = (undefined4 ***)0xf;
    pcStack_2b8 = "Invalid host for low permission request";
    ppuStack_2b0 = (undefined4 **)((uint)ppuStack_2b0 & 0xffffff00);
    puStack_2bc = (undefined4 *)0xbd265a;
    FUN_005542c0();
    pppiStack_2b4 = (int ***)0xbd2662;
    FUN_005e65e0();
    goto LAB_00bd2b71;
  }
LAB_00bd2760:
  uVar3 = uStack_50;
  pppuStack_29c = (undefined4 ***)0x4;
  uStack_38 = 0;
  uStack_34 = 0xf;
  apppuStack_48[0] = (undefined4 ***)((uint)apppuStack_48[0] & 0xffffff00);
  uStack_2a4 = 0x18c3bf400bd2784;
  FUN_005542c0();
  pppuStack_29c = apppuStack_48;
  uStack_2a4 = CONCAT44(&piStack_14,0xbd2793);
  piVar8 = (int *)FUN_00580040();
  iVar11 = *piVar8;
  pppuStack_29c = (undefined4 ***)0xbd279d;
  FUN_005507b0();
  uStack_38 = 0;
  uStack_34 = 0xf;
  apppuStack_48[0] = (undefined4 ***)((uint)apppuStack_48[0] & 0xffffff00);
  uStack_8._0_1_ = 10;
  if (iVar11 == 0) {
LAB_00bd2859:
    ppppuVar12 = apppuStack_48;
    if (0xf < uStack_34) {
      ppppuVar12 = (undefined4 ****)apppuStack_48[0];
    }
    uStack_2a4 = CONCAT44(ppppuVar12,0xbd2870);
    pppuStack_29c = (undefined4 ***)uStack_38;
    FUN_005542c0();
    pppuStack_29c = (undefined4 ***)0x7;
    puStack_20 = (undefined4 *)0x0;
    uStack_1c = 0xf;
    apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
    uStack_2a4 = 0x193be9000bd2894;
    FUN_005542c0();
    pppuStack_29c = apppuStack_30;
    uStack_2a4 = CONCAT44(&piStack_14,0xbd28a3);
    piVar8 = (int *)FUN_00580040();
    iVar11 = *piVar8;
    pppuStack_29c = (undefined4 ***)0xbd28ad;
    FUN_005507b0();
    if (iVar11 != 0) {
      iVar7 = *(int *)(iVar11 + 0x20);
      pppuStack_29c = (undefined4 ***)0xbd28bd;
      iVar10 = FUN_008881d0();
      if (iVar7 == iVar10) {
        iVar7 = *(int *)(iVar11 + 0x20);
        pppuStack_29c = (undefined4 ***)0xbd2927;
        iVar10 = FUN_008881d0();
        if (iVar7 != iVar10) {
          pppuStack_29c = (undefined4 ***)0x18c072c;
          uStack_2a4 = CONCAT44(&UNK_00bd2c5e,(uint)uStack_2a4);
                    /* WARNING: Subroutine does not return */
          FUN_016757c0();
        }
        pppuStack_29c = (undefined4 ***)(iVar11 + 0x28);
        if (*(int *)(iVar11 + 0x24) == 0) {
          pppuStack_29c = (undefined4 ***)0x0;
        }
        uStack_2a4 = CONCAT44(0xbd2943,(uint)uStack_2a4);
        FUN_00557fc0();
        uStack_8._0_1_ = 0xb;
        if ((DAT_01d67dc0 == '\0') || (param_6 != (undefined4 **)0x0)) {
LAB_00bd2a0b:
          pppuStack_29c = &param_6;
          uStack_2a4 = CONCAT44(0xbd2a17,(uint)uStack_2a4);
          FUN_00618a80();
          for (pcVar1 = (char *)param_6; pcVar1 != (char *)0x0; pcVar1 = *(char **)pcVar1) {
            pppuStack_29c = (undefined4 ***)auStack_98;
            uStack_2a4 = CONCAT44(0xbd2a32,(uint)uStack_2a4);
            pppuStack_29c = (undefined4 ***)FUN_00563690();
            uStack_8._0_1_ = 0xc;
            uStack_2a4 = CONCAT44(pcVar1 + 8,0xbd2a43);
            FUN_005d15d0();
            uStack_2a4 = CONCAT44(0xbd2a4b,(uint)uStack_2a4);
            FUN_005511f0();
            uStack_8._0_1_ = 0xb;
            pppuStack_29c = (undefined4 ***)0xbd2a5a;
            FUN_005507b0();
          }
          pppuStack_29c = (undefined4 ***)0xbd2a68;
          FUN_00550b30();
          goto LAB_00bd2a68;
        }
        pppuStack_29c = (undefined4 ***)uStack_4c;
        uStack_2a4 = CONCAT44(0xbd2966,(uint)uStack_2a4);
        iVar11 = FUN_008f7870();
        if (iVar11 == 0) {
          pppiStack_2b4 = (int ***)0x24;
          uStack_2a4 = uStack_2a4 & 0xffffffff;
          pppuStack_29c = (undefined4 ***)0xf;
          pcStack_2b8 = "DataModel not found for header check";
          ppuStack_2b0 = (undefined4 **)((uint)ppuStack_2b0 & 0xffffff00);
          puStack_2bc = (undefined4 *)0xbd298a;
          FUN_005542c0();
          pppiStack_2b4 = (int ***)0xbd2992;
          FUN_005e65e0();
          pppuStack_29c = (undefined4 ***)0xbd299a;
          FUN_00550b30();
        }
        else {
          pppuStack_29c = (undefined4 ***)0xbd29a7;
          FUN_005c2a10();
          pppuStack_29c = (undefined4 ***)0x1;
          param_6 = &puStack_2bc;
          puStack_2bc = (undefined4 *)0x0;
          ppuVar5 = &puStack_2bc;
          if (in_stack_0000003c != (undefined4 *)0x0) {
            puStack_2bc = in_stack_0000003c;
            if (((uint)in_stack_0000003c & 1) == 0) {
              (**(code **)((uint)in_stack_0000003c & 0xfffffffe))(&stack0x00000044,&pppiStack_2b4,0)
              ;
              ppuVar5 = param_6;
            }
            else {
              pppiStack_2b4 = in_stack_00000044;
              ppuStack_2b0 = in_stack_00000048;
              puStack_2ac = in_stack_0000004c;
              pppiStack_2a8 = (int ***)in_stack_00000050;
              uStack_2a4 = in_stack_00000054;
              ppuVar5 = &puStack_2bc;
            }
          }
          param_6 = ppuVar5;
          cVar6 = FUN_009e5ea0(auStack_18);
          if (cVar6 != '\0') goto LAB_00bd2a0b;
          pppuStack_29c = (undefined4 ***)0xbd2a06;
          FUN_00550b30();
        }
      }
      else {
        pppiStack_2b4 = (int ***)0x32;
        uStack_2a4 = uStack_2a4 & 0xffffffff;
        pppuStack_29c = (undefined4 ***)0xf;
        pcStack_2b8 = "Invalid request options, Headers should be a table";
        ppuStack_2b0 = (undefined4 **)((uint)ppuStack_2b0 & 0xffffff00);
        puStack_2bc = (undefined4 *)0xbd28e3;
        FUN_005542c0();
        pppiStack_2b4 = (int ***)0xbd28eb;
        FUN_005e65e0();
      }
      goto LAB_00bd2b69;
    }
LAB_00bd2a68:
    puStack_20 = (undefined4 *)0x0;
    uStack_1c = 0xf;
    apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
    uStack_8._0_1_ = 0xd;
    switch(param_4) {
    case 0:
      pppuStack_29c = (undefined4 ***)&DAT_01d79f98;
      break;
    case 1:
      pppuStack_29c = (undefined4 ***)&DAT_01d79fb0;
      break;
    case 2:
      pppuStack_29c = (undefined4 ***)&DAT_01d79f80;
      break;
    case 3:
      pppuStack_29c = (undefined4 ***)&DAT_01d79fc8;
      break;
    case 4:
      pppuStack_29c = (undefined4 ***)&DAT_01d79fe0;
      break;
    default:
      pppiStack_2b4 = (int ***)0x18;
      uStack_2a4 = uStack_2a4 & 0xffffffff;
      pppuStack_29c = (undefined4 ***)0xf;
      pcStack_2b8 = "Unsupported content type";
      ppuStack_2b0 = (undefined4 **)((uint)ppuStack_2b0 & 0xffffff00);
      puStack_2bc = (undefined4 *)0xbd2b59;
      FUN_005542c0();
      pppiStack_2b4 = (int ***)0xbd2b61;
      FUN_005e65e0();
      goto LAB_00bd2b61;
    }
    uStack_2a4 = CONCAT44(0xbd2aba,(uint)uStack_2a4);
    FUN_00551230();
    pppuStack_29c = (undefined4 ***)puStack_20;
    ppppuVar12 = apppuStack_30;
    if (0xf < uStack_1c) {
      ppppuVar12 = (undefined4 ****)apppuStack_30[0];
    }
    uStack_2a4 = CONCAT44(ppppuVar12,0xbd2ad4);
    FUN_005542c0();
    uStack_1c0 = param_3;
    pppuStack_29c = (undefined4 ***)&param_7;
    uStack_2a4 = CONCAT44(0xbd2aec,(uint)uStack_2a4);
    FUN_008c4480();
    pppuStack_29c = (undefined4 ***)&stack0x0000003c;
    uStack_2a4 = CONCAT44(0xbd2afb,(uint)uStack_2a4);
    FUN_008c4480();
    pppuStack_29c = (undefined4 ***)auStack_178;
    uStack_2a4 = CONCAT44(0xbd2b0d,(uint)uStack_2a4);
    FUN_00bc7cb0();
    uStack_260 = 0;
    puStack_2bc = &stack0x0000003c;
    FUN_0054f510();
    puStack_2bc = &param_3;
    FUN_00bca580(auStack_290);
LAB_00bd2b61:
    pppuStack_29c = (undefined4 ***)0xbd2b69;
    FUN_005507b0();
  }
  else {
    piStack_14 = (int *)(iVar11 + 0x20);
    iVar11 = *piStack_14;
    pppuStack_29c = (undefined4 ***)0xbd27c6;
    iVar7 = FUN_0088cb40();
    uVar2 = uStack_54;
    if (iVar11 == iVar7) {
      pppuStack_29c = (undefined4 ***)0x3;
      pppiStack_2a8 = (int ***)apppiStack_64;
      if (0xf < uVar3) {
        pppiStack_2a8 = apppiStack_64[0];
      }
      uStack_2a4 = CONCAT44(&DAT_018c3c94,uStack_54);
      puStack_2ac = (undefined *)0xbd2814;
      cVar6 = FUN_0055c360();
      if (cVar6 == '\0') {
        pppuStack_29c = (undefined4 ***)0x4;
        pppiStack_2a8 = (int ***)apppiStack_64;
        if (0xf < uVar3) {
          pppiStack_2a8 = apppiStack_64[0];
        }
        uStack_2a4 = CONCAT44(&DAT_0193c538,uVar2);
        puStack_2ac = (undefined *)0xbd2837;
        cVar6 = FUN_0055c360();
        if (cVar6 == '\0') {
          pppuStack_29c = (undefined4 ***)0xbd284a;
          pppuStack_29c = (undefined4 ***)FUN_0055d610();
          uStack_2a4 = CONCAT44(0xbd2853,(uint)uStack_2a4);
          FUN_00551230();
          goto LAB_00bd2859;
        }
      }
      pppiStack_2b4 = (int ***)0x48;
      uStack_2a4 = uStack_2a4 & 0xffffffff;
      pppuStack_29c = (undefined4 ***)0xf;
      pcStack_2b8 = "Invalid request options, Body should be empty for \'GET\' or \'HEAD\' method";
      ppuStack_2b0 = (undefined4 **)((uint)ppuStack_2b0 & 0xffffff00);
      puStack_2bc = (undefined4 *)0xbd2912;
      FUN_005542c0();
      pppiStack_2b4 = (int ***)0xbd291a;
      FUN_005e65e0();
    }
    else {
      pppiStack_2b4 = (int ***)0x30;
      uStack_2a4 = uStack_2a4 & 0xffffffff;
      pppuStack_29c = (undefined4 ***)0xf;
      pcStack_2b8 = "Invalid request options, Body should be a string";
      ppuStack_2b0 = (undefined4 **)((uint)ppuStack_2b0 & 0xffffff00);
      puStack_2bc = (undefined4 *)0xbd27ec;
      FUN_005542c0();
      pppiStack_2b4 = (int ***)0xbd27f4;
      FUN_005e65e0();
    }
  }
LAB_00bd2b69:
  pppuStack_29c = (undefined4 ***)0xbd2b71;
  FUN_005507b0();
LAB_00bd2b71:
  pppuStack_29c = (undefined4 ***)0xbd2b79;
  FUN_005507b0();
  pppuStack_29c = (undefined4 ***)0xbd2b84;
  FUN_0056db40();
  pppuStack_29c = (undefined4 ***)0xbd2b8c;
  FUN_005507b0();
LAB_00bd2bb8:
  pppuStack_29c = (undefined4 ***)0xbd2bc3;
  FUN_00bc7880();
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar11 = param_2[1] + -1;
    param_2[1] = iVar11;
    UNLOCK();
    if (iVar11 == 0) {
      pppuStack_29c = (undefined4 ***)0xbd2bdc;
      (**(code **)*param_2)();
      LOCK();
      piVar8 = param_2 + 2;
      iVar11 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar11 == 1) {
        pppuStack_29c = (undefined4 ***)0xbd2beb;
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  if (param_7 != 0) {
    if (((param_7 & 1) == 0) && (*(code **)(param_7 & 0xfffffffe) != (code *)0x0)) {
      pppuStack_29c = (undefined4 ***)0x2;
      uStack_2a4 = CONCAT44(&stack0x00000024,&stack0x00000024);
      pppiStack_2a8 = (int ***)0xbd2c0c;
      (**(code **)(param_7 & 0xfffffffe))();
    }
    param_7 = 0;
  }
  uStack_8 = 0xf;
  if (((in_stack_0000003c != (undefined4 *)0x0) && (((uint)in_stack_0000003c & 1) == 0)) &&
     (*(code **)((uint)in_stack_0000003c & 0xfffffffe) != (code *)0x0)) {
    pppuStack_29c = (undefined4 ***)0x2;
    uStack_2a4 = CONCAT44(&stack0x00000044,&stack0x00000044);
    pppiStack_2a8 = (int ***)0xbd2c3a;
    (**(code **)((uint)in_stack_0000003c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
joined_r0x00bd26e4:
  if (puVar13 == puVar4) goto LAB_00bd2716;
  uStack_2a4._4_4_ = puVar13;
  if (0xf < (uint)puVar13[5]) {
    uStack_2a4._4_4_ = (undefined4 *)*puVar13;
  }
  pppuStack_29c = (undefined4 ***)puVar13[4];
  pppiStack_2a8 = (int ***)apppiStack_64;
  if (0xf < uStack_50) {
    pppiStack_2a8 = apppiStack_64[0];
  }
  puStack_2ac = (undefined *)0xbd2708;
  uStack_2a4._0_4_ = uStack_54;
  cVar6 = FUN_0055c360();
  if (cVar6 != '\0') {
    uStack_8._0_1_ = 6;
    pppuStack_29c = (undefined4 ***)0xbd275d;
    FUN_00577a40();
    goto LAB_00bd2760;
  }
  puVar13 = puVar13 + 6;
  goto joined_r0x00bd26e4;
LAB_00bd2716:
  uStack_8._1_3_ = (undefined3)((uint)uStack_8 >> 8);
  uStack_8._0_1_ = 6;
  pppuStack_29c = (undefined4 ***)0xbd2722;
  FUN_00577a40();
  pppiStack_2b4 = (int ***)0x29;
  uStack_2a4 = (ulonglong)(uint)uStack_2a4;
  pppuStack_29c = (undefined4 ***)0xf;
  pcStack_2b8 = "Invalid method for low permission request";
  ppuStack_2b0 = (undefined4 **)((uint)ppuStack_2b0 & 0xffffff00);
  puStack_2bc = (undefined4 *)0xbd2744;
  FUN_005542c0();
  pppiStack_2b4 = (int ***)0xbd274c;
  FUN_005e65e0();
  goto LAB_00bd2b71;
}



/* FUNCTION 26333 ; VA 0x00bd2c80 ; FUN_00bd2c80 */

undefined4 FUN_00bd2c80(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  undefined8 uVar3;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int iStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ffe40;
  pvStack_10 = ExceptionList;
  if (0 < DAT_01d67d04) {
    iStack_1c = DAT_01d67d0c >> 0x1f;
    iVar2 = DAT_01d67d0c;
    if ((-1 < DAT_01d67d0c || iStack_1c < 0) && (iStack_1c < 0)) {
      iStack_1c = 0;
      iVar2 = 0;
    }
    ExceptionList = &pvStack_10;
    if (DAT_01ea94c0 == (code *)0x0) {
      ExceptionList = &pvStack_10;
      uVar1 = GetModuleHandleA("KERNEL32.DLL","GetTickCount64");
      DAT_01ea94c0 = (code *)GetProcAddress(uVar1);
      if (DAT_01ea94c0 == (code *)0x0) {
        DAT_01ea94c0 = FUN_005efd30;
      }
    }
    uVar3 = (*DAT_01ea94c0)();
    FUN_005f0a90(&uStack_34,FUN_005f1e70,uVar3,iVar2,iStack_1c,1);
    FUN_01689e80(0xffffffff);
    uStack_8 = 0;
    uStack_30 = 0;
    uStack_34 = 0;
    (**(code **)(*(int *)*param_1 + 0x10))(param_2,param_3);
    ExceptionList = pvStack_10;
    return 1;
  }
  return 0;
}



/* FUNCTION 26334 ; VA 0x00bd2d6e ; Catch@00bd2d6e */

undefined * Catch_00bd2d6e(void)

{
  return &DAT_00bd2d74;
}



/* FUNCTION 26335 ; VA 0x00bd2de0 ; FUN_00bd2de0 */

void __thiscall FUN_00bd2de0(undefined4 param_1,undefined4 param_2,uint param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ffe58;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    FUN_0054ef60(param_2);
    FUN_005e65e0();
  }
  uStack_8 = 1;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&stack0x00000010,&stack0x00000010,2,param_1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26336 ; VA 0x00bd2e60 ; FUN_00bd2e60 */

void __thiscall FUN_00bd2e60(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ffe80;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uVar2 = FUN_01675290(DAT_01ef5a9c);
  iStack_8 = 0;
  uStack_18 = uVar2;
  if (param_2 == &DAT_0211bd28) {
    FUN_01679490();
    if (param_1 != 0) {
      iVar6 = *(int *)(param_1 + 0x34);
      if ((iVar6 != 0) && (param_1 = iVar6, *(int *)(iVar6 + 0x34) != 0)) {
        param_1 = FUN_005c8ac0();
      }
      if ((param_1 != 0) &&
         (iVar6 = *(int *)(param_1 + 0xc), iVar3 = FUN_008a8c30(),
         (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
         (uint)*(ushort *)(iVar3 + 0x1da))) {
        FUN_005c2760();
      }
    }
    puVar4 = (undefined4 *)FUN_008cc950(auStack_30);
    iVar6 = iStack_14;
    iStack_8._0_1_ = 1;
    puVar9 = (undefined4 *)(iStack_14 + 0xe0);
    if (puVar9 != puVar4) {
      puVar1 = puVar4 + 4;
      if (0xf < (uint)puVar4[5]) {
        puVar4 = (undefined4 *)*puVar4;
      }
      FUN_005542c0(puVar4,*puVar1);
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_1c) {
      uVar8 = uStack_1c + 1;
      uVar7 = auStack_30[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_30[0] - 4);
        uVar8 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    if (*(int *)(iVar6 + 0xf0) != 0) {
      uVar5 = FUN_0058ee60(&DAT_01d67e08,0);
      FUN_00591430(uVar5,DAT_01d67e18,&DAT_018bc9b8,0);
      if (puVar9 != (undefined4 *)&DAT_01d67d58) {
        if (0xf < *(uint *)(iVar6 + 0xf4)) {
          puVar9 = (undefined4 *)*puVar9;
        }
        FUN_005542c0(puVar9,*(undefined4 *)(iVar6 + 0xf0));
      }
      iVar6 = FUN_008f7870(iVar6);
      if (iVar6 != 0) {
        FUN_0090a7f0(1);
      }
    }
  }
  iStack_8 = 2;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26337 ; VA 0x00bd3010 ; FUN_00bd3010 */

uint FUN_00bd3010(int param_1,int param_2,char param_3)

{
  int iVar1;
  int iVar2;
  bool bVar3;
  
  if (param_1 == 0) {
    return 0;
  }
  iVar2 = -1;
  iVar1 = FUN_0170d75d(param_1,0,&std::exception::RTTI_Type_Descriptor,
                       &RBX::http_status_error::RTTI_Type_Descriptor,0);
  if (iVar1 != 0) {
    iVar2 = *(int *)(iVar1 + 0x24);
  }
  iVar1 = *(int *)(param_2 + 0xd4);
  if ((iVar1 == 0) && (param_3 != '\0')) {
    FUN_0087c450(&DAT_018c5f98,"HttpRbxApiService","RetryRequestStarted",0,0,0);
    iVar1 = *(int *)(param_2 + 0xd4);
  }
  if (DAT_01d67e00 == '\0') {
    if ((iVar2 != 0x1f7) && (iVar2 != 0x1ad)) goto LAB_00bd30bc;
    bVar3 = true;
  }
  else {
    bVar3 = iVar2 == 0x1f7;
  }
  if ((bVar3) && (iVar1 < DAT_01d67cf4)) {
    *(int *)(param_2 + 0xd4) = iVar1 + 1;
    return CONCAT31((int3)((uint)(iVar1 + 1) >> 8),1);
  }
LAB_00bd30bc:
  *(uint *)(param_2 + 0xd4) = iVar1 + 1U;
  return iVar1 + 1U & 0xffffff00;
}



/* FUNCTION 26338 ; VA 0x00bd30e0 ; FUN_00bd30e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00bd30e0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ffea6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef5dac) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef5dac);
    if (DAT_01ef5dac == -1) {
      uStack_8 = 0;
      FUN_009ca470("ThrottlingPriority");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef5d48 = RBX::Reflection::EnumDesc<enum_RBX::ThrottlingPriority>::vftable;
      FUN_009caf20(&DAT_01d67e20,3);
      FUN_016f3654(&LAB_01892130);
      FUN_016f37bf(&DAT_01ef5dac);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef5d48;
}



/* FUNCTION 26339 ; VA 0x00bd3190 ; FUN_00bd3190 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00bd3190(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef5dbc) {
    FUN_016f3809(&DAT_01ef5dbc);
    if (DAT_01ef5dbc == -1) {
      _DAT_01ef5db0 = FUN_005c65e0;
      _DAT_01ef5db4 = FUN_005c65e0;
      _DAT_01ef5db8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef5dbc);
    }
  }
  return &DAT_01ef5db0;
}



/* FUNCTION 26340 ; VA 0x00bd3200 ; FUN_00bd3200 */

undefined4 __thiscall FUN_00bd3200(int param_1,int param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  float10 fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  
  fVar4 = (float10)FUN_00a36320(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x138),
                                0x3f800000,0x3f800000);
  if (DAT_018c0d60 <= (double)fVar4) {
    if (DAT_01d67d50 != *(int *)(param_1 + 0x130)) {
      *(double *)(param_1 + 0x138) = (double)(DAT_018ce2f8 / (float)DAT_01d67d50);
      *(int *)(param_1 + 0x130) = DAT_01d67d50;
    }
    iVar1 = *(int *)(param_1 + 0x128);
    fVar5 = (float)DAT_01d67d50 / DAT_018c0ff0;
    cVar2 = FUN_0098c5a0();
    if ((cVar2 != '\0') || (*(char *)(iVar1 + 0xfa) != '\0')) {
      iVar3 = FUN_00bcbe40();
      fVar6 = (float)(iVar3 * DAT_01d67cdc + DAT_01d67cd4);
      fVar8 = fVar6 * fVar5;
      fVar7 = fVar8 + *(float *)(iVar1 + 0x58);
      if (fVar6 < fVar7) {
        fVar7 = fVar6;
      }
      *(float *)(iVar1 + 0x58) = fVar7;
      fVar7 = fVar8 + *(float *)(iVar1 + 0x5c);
      if (fVar7 <= fVar6) {
        fVar6 = fVar7;
      }
      *(float *)(iVar1 + 0x5c) = fVar6;
      if (DAT_01ef5a94 != '\0') {
        FUN_016774d0(DAT_01ef5a94,
                     "Adding budget %f, default budget is at: %f, elevated budget is at: %f",fVar8,
                     *(undefined4 *)(iVar1 + 0x58),fVar6,0);
      }
    }
    cVar2 = FUN_00973950();
    if ((cVar2 != '\0') || (*(char *)(iVar1 + 0xfa) != '\0')) {
      fVar8 = (float)DAT_01d67cc4;
      fVar6 = fVar8 * fVar5 + *(float *)(iVar1 + 0x60);
      fVar7 = (float)(DAT_01d67ccc * DAT_01d67cc4);
      if (fVar6 <= (float)(DAT_01d67ccc * DAT_01d67cc4)) {
        fVar7 = fVar6;
      }
      *(float *)(iVar1 + 0x60) = fVar7;
      if (DAT_01ef5a94 != '\0') {
        FUN_016774d0(DAT_01ef5a94,"Adding budget %f, client budget is at: %f",fVar8 * fVar5,fVar7,0,
                     0);
      }
    }
    fVar7 = (float)DAT_01d67cec;
    fVar5 = fVar7 * fVar5 + *(float *)(iVar1 + 100);
    if (fVar5 <= fVar7) {
      fVar7 = fVar5;
    }
    *(float *)(iVar1 + 100) = fVar7;
    iVar1 = *(int *)(param_1 + 0x128);
    cVar2 = FUN_0098c5a0();
    if ((cVar2 != '\0') || (*(char *)(iVar1 + 0xfa) != '\0')) {
      FUN_00bcabc0();
      FUN_00bcabc0();
    }
    cVar2 = FUN_00973950();
    if ((cVar2 != '\0') || (*(char *)(iVar1 + 0xfa) != '\0')) {
      FUN_00bcabc0();
    }
    FUN_00bca950();
  }
  return 1;
}



/* FUNCTION 26341 ; VA 0x00bd3480 ; FUN_00bd3480 */

undefined __thiscall
FUN_00bd3480(int param_1,undefined4 param_2,float *param_3,int param_4,uint param_5)

{
  float fVar1;
  undefined4 uVar2;
  int iVar3;
  undefined uVar4;
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ffec0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  fVar1 = *param_3;
  if (0.0 <= fVar1) {
    uVar4 = 0;
    ExceptionList = &pvStack_10;
    *param_3 = fVar1 - DAT_018ce2f8;
  }
  else {
    ExceptionList = &pvStack_10;
    if (DAT_01ef5a94 != '\0') {
      ExceptionList = &pvStack_10;
      FUN_016774d0(DAT_01ef5a94,"Throttling, budget: %f",fVar1,0,0,0);
    }
    if (*(char *)(param_1 + 0x118) != '\0') {
      FUN_005789c0(&DAT_01ef5b08,&LAB_00bd2da0);
    }
    if (*(uint *)(param_4 + 4) < DAT_01d67ce4) {
      FUN_00bd1d00(param_2);
      uVar4 = 1;
    }
    else {
      if (*(char *)(param_1 + 0x118) != '\0') {
        FUN_005789c0(&DAT_01ef5b10,&LAB_00bd2dc0);
      }
      uVar2 = DAT_01d67cc4;
      iVar3 = FUN_00bcbe40();
      FUN_01675640(auStack_28,
                   "number of API requests/minute exceeded limit for HTTP API throttle. Please don\'t issue more than %i API requests/minute with server scripts and no more than %i API requests/minute with local scripts."
                   ,iVar3 * DAT_01d67cdc + DAT_01d67cd4,uVar2);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_0054f510(&param_5);
      FUN_00bd2de0(auStack_28);
      FUN_005507b0();
      uVar4 = 1;
    }
  }
  uStack_8 = 2;
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_5 & 0xfffffffe))(&stack0x00000018,&stack0x00000018,2);
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 26342 ; VA 0x00bd35f0 ; FUN_00bd35f0 */

int * __thiscall
FUN_00bd35f0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c0d8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00bd37d0();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::HopperBin,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              SetImpl<void_(__thiscall_RBX::HopperBin::*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&)>
              ::vftable;
    puVar3[2] = param_5;
    puVar3[3] = param_6;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_7,param_8,param_9,param_10,param_11,param_11,0);
  *param_1 = (int)RBX::Reflection::
                  TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                  ::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::HopperBin,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                    ::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::HopperBin,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                    ::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26343 ; VA 0x00bd36f0 ; FUN_00bd36f0 */

undefined * FUN_00bd36f0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ffedc;
  pvStack_10 = ExceptionList;
  if (DAT_01ef6410 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef6620) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef6620);
      if (DAT_01ef6620 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"BackpackItem",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_018922c0);
        FUN_016f37bf(&DAT_01ef6620);
      }
    }
    DAT_01ef6410 = &DAT_01ef6418;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef6410;
}



/* FUNCTION 26344 ; VA 0x00bd37d0 ; FUN_00bd37d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00bd37d0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fff10;
  pvStack_10 = ExceptionList;
  if (DAT_01ef6628 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef6840) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef6840);
      if (DAT_01ef6840 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00bd36f0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"HopperBin",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01ef6838 = RBX::Creator<class_RBX::HopperBin>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef6630,&DAT_01ef6838);
        FUN_016f3654(FUN_018922d0);
        FUN_016f37bf(&DAT_01ef6840);
      }
    }
    DAT_01ef6628 = &DAT_01ef6630;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef6628;
}



/* FUNCTION 26345 ; VA 0x00bd38d0 ; FUN_00bd38d0 */

undefined * FUN_00bd38d0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fff2c;
  pvStack_10 = ExceptionList;
  if (DAT_01ef5dcc == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef5fd8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef5fd8);
      if (DAT_01ef5fd8 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Hopper",1,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_01892330);
        FUN_016f37bf(&DAT_01ef5fd8);
      }
    }
    DAT_01ef5dcc = &DAT_01ef5dd0;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef5dcc;
}



/* FUNCTION 26346 ; VA 0x00bd39b0 ; FUN_00bd39b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00bd39b0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fff60;
  pvStack_10 = ExceptionList;
  if (DAT_01ef61f0 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef6408) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef6408);
      if (DAT_01ef6408 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"StarterGear",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01ef6400 = RBX::Creator<class_RBX::StarterGear>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef61f8,&DAT_01ef6400);
        FUN_016f3654(FUN_01892340);
        FUN_016f37bf(&DAT_01ef6408);
      }
    }
    DAT_01ef61f0 = &DAT_01ef61f8;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef61f0;
}



/* FUNCTION 26347 ; VA 0x00bd3ab0 ; FUN_00bd3ab0 */

undefined * FUN_00bd3ab0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fff7c;
  pvStack_10 = ExceptionList;
  if (DAT_01ef5fdc == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef61e8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef61e8);
      if (DAT_01ef61e8 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"StarterPack",1,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_018923a0);
        FUN_016f37bf(&DAT_01ef61e8);
      }
    }
    DAT_01ef5fdc = &DAT_01ef5fe0;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef5fdc;
}



/* FUNCTION 26348 ; VA 0x00bd3b90 ; FUN_00bd3b90 */

void FUN_00bd3b90(void)

{
  int iVar1;
  
  if (DAT_01ef61ec == 0) {
    iVar1 = FUN_00bd3ab0();
    DAT_01ef61ec = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 26349 ; VA 0x00bd3bb0 ; FUN_00bd3bb0 */

int __thiscall FUN_00bd3bb0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fff90;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::HopperBin*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 26350 ; VA 0x00bd3c82 ; Catch_All@00bd3c82 */

void Catch_All_00bd3c82(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 26351 ; VA 0x00bd3ca0 ; FUN_00bd3ca0 */

int __thiscall FUN_00bd3ca0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fffa0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ScriptMouseCommand*,class_RBX::Creatable<class_RBX::MouseCommand>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0x20) == 0 || (*(int *)(*(int *)(param_2 + 0x20) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 0x1c) = param_2;
    piVar3 = *(int **)(param_2 + 0x20);
    *(int **)(param_2 + 0x20) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 26352 ; VA 0x00bd3d72 ; Catch_All@00bd3d72 */

void Catch_All_00bd3d72(void)

{
  int unaff_EBP;
  
  FUN_008af4d0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 26353 ; VA 0x00bd3d90 ; FUN_00bd3d90 */

undefined4 * FUN_00bd3d90(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fffe3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00bd37d0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x118);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00bd3ee0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00bd3bb0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26354 ; VA 0x00bd3e50 ; FUN_00bd3e50 */

undefined4 * FUN_00bd3e50(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_01800018;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01674e20(0x4c);
  uStack_8 = 1;
  if (iVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_01075670(*param_2);
  }
  uStack_8 = uStack_8 & 0xffffff00;
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00bd3ca0(uVar2,param_1);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26355 ; VA 0x00bd3ee0 ; FUN_00bd3ee0 */

undefined4 * __fastcall FUN_00bd3ee0(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01800088;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0170d1f0(param_1,0,0xf4);
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::BackpackItem,class_RBX::Instance>::vftable;
  uVar1 = FUN_00bd36f0();
  param_1[3] = uVar1;
  param_1[0x19] = 0;
  param_1[0x1a] = 0xf;
  *(undefined *)(param_1 + 0x15) = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0xf;
  *(undefined *)(param_1 + 0x1b) = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x25] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0xf;
  *(undefined *)(param_1 + 0x26) = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0xf;
  *(undefined *)(param_1 + 0x2c) = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0xf;
  *(undefined *)(param_1 + 0x32) = 0;
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0;
  uStack_8 = 1;
  *param_1 = RBX::DescribedCreatable<class_RBX::HopperBin,class_RBX::BackpackItem>::vftable;
  uVar1 = FUN_00bd37d0();
  param_1[3] = uVar1;
  *param_1 = RBX::HopperBin::vftable;
  *(undefined *)(param_1 + 0x3d) = 0;
  param_1[0x3e] = 0;
  *(undefined *)(param_1 + 0x3f) = 0;
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  param_1[0x42] = 0;
  param_1[0x43] = 0;
  param_1[0x44] = 0;
  param_1[0x45] = 0;
  uStack_8._0_1_ = 6;
  uStack_8._1_3_ = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("HopperBin",9);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26356 ; VA 0x00bd4100 ; FUN_00bd4100 */

undefined4 * __fastcall FUN_00bd4100(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018000b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::StarterGear,class_RBX::Instance>::vftable;
  uVar1 = FUN_00bd39b0();
  param_1[3] = uVar1;
  uStack_8 = 1;
  *param_1 = RBX::StarterGear::vftable;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("StarterGear",0xb);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26357 ; VA 0x00bd41c0 ; FUN_00bd41c0 */

undefined4 * __fastcall FUN_00bd41c0(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018000e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::StarterPackService,class_RBX::Instance>::vftable;
  uVar1 = FUN_00bd3ab0();
  param_1[3] = uVar1;
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 1;
  *param_1 = RBX::StarterPackService::vftable;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("StarterPack",0xb);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26358 ; VA 0x00bd4290 ; FUN_00bd4290 */

void __fastcall FUN_00bd4290(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::HopperBin>::vftable;
  uVar1 = FUN_00bd37d0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26359 ; VA 0x00bd42d0 ; FUN_00bd42d0 */

void __fastcall FUN_00bd42d0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::StarterGear>::vftable;
  uVar1 = FUN_00bd39b0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26360 ; VA 0x00bd4310 ; thunk_FUN_00bd4320 */

void __fastcall thunk_FUN_00bd4320(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  FUN_0091a630();
  uVar1 = *(uint *)(param_1 + 0xac);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x98);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0xa8) = 0;
  *(undefined4 *)(param_1 + 0xac) = 0xf;
  *(undefined *)(param_1 + 0x98) = 0;
  FUN_0091a630();
  FUN_0089b230();
  return;
}



/* FUNCTION 26361 ; VA 0x00bd4320 ; FUN_00bd4320 */

void __fastcall FUN_00bd4320(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  FUN_0091a630();
  uVar1 = *(uint *)(param_1 + 0xac);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x98);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0xa8) = 0;
  *(undefined4 *)(param_1 + 0xac) = 0xf;
  *(undefined *)(param_1 + 0x98) = 0;
  FUN_0091a630();
  FUN_0089b230();
  return;
}



/* FUNCTION 26362 ; VA 0x00bd43a0 ; FUN_00bd43a0 */

undefined4 __thiscall FUN_00bd43a0(undefined4 param_1,byte param_2)

{
  FUN_00bd4320();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xf4);
  }
  return param_1;
}



/* FUNCTION 26363 ; VA 0x00bd43d0 ; FUN_00bd43d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00bd43d0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::HopperBin::BinType>::vftable;
  _DAT_01ef6848 = _DAT_01ef6848 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 26364 ; VA 0x00bd4400 ; FUN_00bd4400 */

undefined4 * __thiscall FUN_00bd4400(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::HopperBin::BinType>::GetSet::vftable
  ;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 26365 ; VA 0x00bd4430 ; FUN_00bd4430 */

undefined4 * __thiscall FUN_00bd4430(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::HopperBin::BinType>::GetSet::vftable
  ;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 26366 ; VA 0x00bd4460 ; FUN_00bd4460 */

int __thiscall FUN_00bd4460(int param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  iVar3 = *(int *)(param_1 + 0x100);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_00bd4320();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x118);
  }
  return param_1;
}



/* FUNCTION 26367 ; VA 0x00bd44f0 ; thunk_FUN_00bd5640 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00bd5640(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01800306;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef68b4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef68b4);
    if (DAT_01ef68b4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("BinType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef6850 = RBX::Reflection::EnumDesc<enum_RBX::HopperBin::BinType>::vftable;
      FUN_009caf20(&DAT_01d67e48,5);
      FUN_009cab70(5,"Slingshot",0);
      FUN_009cab70(6,"Rocket",0);
      FUN_009cab70(7,"Laser",0);
      FUN_016f3654(&LAB_018922a0);
      FUN_016f37bf(&DAT_01ef68b4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef6850;
}



/* FUNCTION 26368 ; VA 0x00bd4500 ; FUN_00bd4500 */

bool FUN_00bd4500(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00bd36f0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) goto LAB_00bd4532;
  }
  param_1 = 0;
LAB_00bd4532:
  return param_1 != 0;
}



/* FUNCTION 26369 ; VA 0x00bd4540 ; FUN_00bd4540 */

void FUN_00bd4540(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00bd5640();
    *param_2 = uVar3;
    iVar4 = FUN_00bd5730();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 26370 ; VA 0x00bd45a0 ; FUN_00bd45a0 */

void FUN_00bd45a0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00bd5640();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 26371 ; VA 0x00bd45e0 ; FUN_00bd45e0 */

undefined4 * FUN_00bd45e0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00bd3d90(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 26372 ; VA 0x00bd4650 ; FUN_00bd4650 */

undefined4 * FUN_00bd4650(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00966060(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 26373 ; VA 0x00bd46c0 ; FUN_00bd46c0 */

void __fastcall FUN_00bd46c0(int param_1)

{
  int iVar1;
  
  if (*(char *)(param_1 + 0xf4) != '\0') {
    if (*(int *)(param_1 + 0xf8) == 0) {
      FUN_006eccd0();
    }
    *(undefined *)(param_1 + 0xf4) = 0;
    FUN_008a4940(&DAT_02132270);
    iVar1 = FUN_008b2e60(param_1);
    if (iVar1 != 0) {
      FUN_008ba310();
      return;
    }
  }
  return;
}



/* FUNCTION 26374 ; VA 0x00bd4710 ; FUN_00bd4710 */

int FUN_00bd4710(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_01800200;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_8 = 1;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x18) + 8))(&DAT_021322e0,&uStack_24,&uStack_18);
  _uStack_8 = CONCAT31(uStack_7,2);
  iVar3 = FUN_00577b20();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 26375 ; VA 0x00bd47c0 ; FUN_00bd47c0 */

void FUN_00bd47c0(void)

{
  FUN_00bd5110();
  return;
}



/* FUNCTION 26376 ; VA 0x00bd47d0 ; FUN_00bd47d0 */

void FUN_00bd47d0(void)

{
  int iVar1;
  
  if (DAT_01ef6624 == 0) {
    iVar1 = FUN_00bd36f0();
    DAT_01ef6624 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 26377 ; VA 0x00bd47f0 ; FUN_00bd47f0 */

void FUN_00bd47f0(void)

{
  int iVar1;
  
  if (DAT_01ef6844 == 0) {
    iVar1 = FUN_00bd37d0();
    DAT_01ef6844 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 26378 ; VA 0x00bd4810 ; FUN_00bd4810 */

void FUN_00bd4810(void)

{
  int iVar1;
  
  if (DAT_01ef640c == 0) {
    iVar1 = FUN_00bd39b0();
    DAT_01ef640c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 26379 ; VA 0x00bd4830 ; FUN_00bd4830 */

undefined4 __thiscall FUN_00bd4830(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x98);
  return param_2;
}



/* FUNCTION 26380 ; VA 0x00bd4850 ; FUN_00bd4850 */

undefined4 __thiscall FUN_00bd4850(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e26d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = (**(code **)(param_1 + 8))(aiStack_28);
  uStack_8 = 0;
  FUN_0054ef60(uVar1);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 26381 ; VA 0x00bd48e0 ; FUN_00bd48e0 */

void __thiscall FUN_00bd48e0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_00bd5640();
  *param_3 = uVar3;
  iVar4 = FUN_00bd5730();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 26382 ; VA 0x00bd4940 ; FUN_00bd4940 */

undefined4 FUN_00bd4940(undefined4 ****param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 ****ppppuVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 ***apppuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar1 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  if (param_1[4] == (undefined4 ***)0x0) {
    return 0;
  }
  ExceptionList = &pvStack_10;
  FUN_00995490(&iStack_14,&param_1);
  if (iStack_14 != 0) {
    ExceptionList = pvStack_10;
    return *(undefined4 *)(iStack_14 + 0xc);
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
  uStack_8 = 0;
  FUN_00578160(0x1e,0x20);
  param_1 = apppuStack_30;
  if (0xf < uStack_1c) {
    param_1 = (undefined4 ****)apppuStack_30[0];
  }
  uVar5 = 0;
  do {
    puVar6 = puVar1;
    if (0xf < (uint)puVar1[5]) {
      puVar6 = (undefined4 *)*puVar1;
    }
    *(byte *)((int)param_1 + uVar5) =
         (*(char *)(uVar5 % (uint)puVar1[4] + (int)puVar6) - ((char)uVar5 * -0x25 & 0x7fU)) + '\x1e'
    ;
    uVar5 = uVar5 + 1;
  } while (uVar5 < 0x1e);
  uVar2 = FUN_0086e830(apppuStack_30);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_1c) {
    uVar5 = uStack_1c + 1;
    ppppuVar4 = (undefined4 ****)apppuStack_30[0];
    if (0xfff < uVar5) {
      ppppuVar4 = (undefined4 ****)apppuStack_30[0][-1];
      uVar5 = uStack_1c + 0x24;
      if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar4,uVar5);
  }
  param_1 = (undefined4 ****)uVar2;
  piVar3 = (int *)FUN_00995490(&iStack_14,&param_1);
  if (*piVar3 != 0) {
    ExceptionList = pvStack_10;
    return *(undefined4 *)(*piVar3 + 0xc);
  }
  if (*(int *)(iStack_18 + 0x34) != 0) {
    uVar2 = FUN_00bd4940(puVar1);
    ExceptionList = pvStack_10;
    return uVar2;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 26383 ; VA 0x00bd4ad0 ; FUN_00bd4ad0 */

uint FUN_00bd4ad0(void)

{
  int iVar1;
  
  iVar1 = FUN_00bd37d0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 26384 ; VA 0x00bd4af0 ; FUN_00bd4af0 */

uint FUN_00bd4af0(void)

{
  int iVar1;
  
  iVar1 = FUN_00bd39b0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 26385 ; VA 0x00bd4b10 ; FUN_00bd4b10 */

uint FUN_00bd4b10(void)

{
  int iVar1;
  
  iVar1 = FUN_00bd37d0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 26386 ; VA 0x00bd4b30 ; FUN_00bd4b30 */

uint FUN_00bd4b30(void)

{
  int iVar1;
  
  iVar1 = FUN_00bd39b0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 26387 ; VA 0x00bd4b50 ; FUN_00bd4b50 */

void FUN_00bd4b50(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00bd5640();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 26388 ; VA 0x00bd4b90 ; FUN_00bd4b90 */

void __thiscall FUN_00bd4b90(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01800252;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_2 + 8);
  ExceptionList = &pvStack_10;
  if (iVar4 != 0) {
    iVar2 = *(int *)(iVar4 + 0x34);
    ExceptionList = &pvStack_10;
    if ((iVar2 != 0) && (iVar4 = iVar2, ExceptionList = &pvStack_10, *(int *)(iVar2 + 0x34) != 0)) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_005c8ac0();
    }
    if ((iVar4 != 0) &&
       (iVar2 = *(int *)(iVar4 + 0xc), iVar5 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
       (uint)*(ushort *)(iVar5 + 0x1da))) goto LAB_00bd4bff;
  }
  iVar4 = 0;
LAB_00bd4bff:
  FUN_008a3ee0(param_2);
  if (iVar4 != 0) {
    cVar3 = FUN_008b9b00(param_1);
    if (cVar3 == '\0') {
      if (*(char *)(param_1 + 0xfc) != '\0') {
        ExceptionList = pvStack_10;
        return;
      }
      FUN_006eccd0();
      uStack_8 = 3;
      uVar6 = FUN_01675290(DAT_02110da8);
      uStack_8 = 4;
      puVar7 = (undefined4 *)FUN_01674e20(0x1c);
      if (puVar7 == (undefined4 *)0x0) {
        puVar7 = (undefined4 *)0x0;
      }
      else {
        *puVar7 = 0;
        puVar7[1] = 1;
        puVar7[2] = FUN_00bd4710;
        puVar7[3] = _guard_check_icall;
        puVar7[4] = 0;
        puVar7[5] = param_1 + 0x10c;
        puVar7[6] = param_1;
      }
      FUN_016797d0(puVar7);
      if (puVar7 != (undefined4 *)0x0) {
        LOCK();
        puVar7[1] = puVar7[1] + 1;
        UNLOCK();
      }
      uStack_8 = 5;
    }
    else {
      if (*(char *)(param_1 + 0xfc) != '\0') {
        ExceptionList = pvStack_10;
        return;
      }
      FUN_006eccd0();
      uStack_8 = 0;
      uVar6 = FUN_01675290(DAT_02110da8);
      uStack_8 = 1;
      puVar7 = (undefined4 *)FUN_01674e20(0x1c);
      if (puVar7 == (undefined4 *)0x0) {
        puVar7 = (undefined4 *)0x0;
      }
      else {
        *puVar7 = 0;
        puVar7[1] = 1;
        puVar7[2] = FUN_00bd47c0;
        puVar7[3] = _guard_check_icall;
        puVar7[4] = 0;
        puVar7[5] = param_1 + 0x104;
        puVar7[6] = param_1;
      }
      FUN_016797d0(puVar7);
      if (puVar7 != (undefined4 *)0x0) {
        LOCK();
        puVar7[1] = puVar7[1] + 1;
        UNLOCK();
      }
      uStack_8 = 2;
    }
    FUN_01675290(uVar6);
    iVar4 = *(int *)(param_1 + 0x100);
    *(undefined4 **)(param_1 + 0x100) = puVar7;
    if (iVar4 != 0) {
      piVar1 = (int *)(iVar4 + 4);
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_01674ea0(iVar4);
      }
    }
    *(undefined *)(param_1 + 0xfc) = 1;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26389 ; VA 0x00bd4dc0 ; FUN_00bd4dc0 */

uint __fastcall FUN_00bd4dc0(int *param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  uint in_EAX;
  int iVar4;
  uint uVar5;
  undefined4 unaff_ESI;
  int iVar6;
  undefined4 unaff_EDI;
  int iStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined4 *puStack_c;
  
  if (param_1[0xd] != 0) {
    iVar6 = *(int *)(param_1[0xd] + 0xc);
    puStack_c = (undefined4 *)0xbd4dd3;
    iVar4 = FUN_00c91ca0();
    in_EAX = (uint)*(ushort *)(iVar4 + 0x1da);
    if ((uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <= in_EAX) {
      if (*(char *)(param_1 + 0x3d) != '\0') {
                    /* WARNING: Could not recover jumptable at 0x00bd4e24. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        uVar5 = (**(code **)(*param_1 + 0xb0))();
        return uVar5;
      }
      puStack_c = &DAT_02132270;
      *(undefined *)(param_1 + 0x3d) = 1;
      pvStack_10 = (void *)0xbd4e0a;
      FUN_008a4940();
      if (param_1[0x3e] != 0) {
        uVar5 = FUN_00bd4e30();
        return uVar5;
      }
      puStack_c = (undefined4 *)&LAB_018002a0;
      pvStack_10 = ExceptionList;
      ExceptionList = &pvStack_10;
      uVar5 = FUN_008b2e60(param_1,unaff_EDI,unaff_ESI);
      if (uVar5 != 0) {
        uStack_14 = uVar5;
        FUN_00bd3e50(&iStack_24,&uStack_14);
        if (piStack_20 != (int *)0x0) {
          LOCK();
          piStack_20[1] = piStack_20[1] + 1;
          UNLOCK();
        }
        FUN_008bac40(iStack_24,piStack_20,0);
        iVar6 = *(int *)(iStack_24 + 0x48);
        if (iVar6 != 0) {
          LOCK();
          *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
          UNLOCK();
          iVar6 = *(int *)(iStack_24 + 0x48);
        }
        uStack_1c = 0;
        uStack_18 = 0;
        uVar5 = FUN_0089be10(*(undefined4 *)(iStack_24 + 0x44),iVar6);
        if (piStack_20 != (int *)0x0) {
          LOCK();
          puVar1 = (uint *)(piStack_20 + 1);
          uVar3 = *puVar1;
          uVar5 = *puVar1;
          *puVar1 = uVar3 - 1;
          UNLOCK();
          if (uVar3 - 1 == 0) {
            uVar5 = (**(code **)*piStack_20)();
            LOCK();
            piVar2 = piStack_20 + 2;
            iVar6 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar6 == 1) {
              uVar5 = (**(code **)(*piStack_20 + 4))();
            }
          }
        }
      }
      ExceptionList = pvStack_10;
      return uVar5;
    }
  }
  return in_EAX;
}



/* FUNCTION 26390 ; VA 0x00bd4e30 ; FUN_00bd4e30 */

void __fastcall FUN_00bd4e30(int param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  undefined4 ****ppppuVar4;
  undefined4 *puVar5;
  undefined4 ***pppuVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  undefined4 *puVar10;
  uint auStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  undefined4 ***pppuStack_54;
  int iStack_50;
  int iStack_4c;
  int iStack_48;
  undefined8 uStack_44;
  undefined4 ***apppuStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  int iStack_24;
  undefined4 ***pppuStack_20;
  uint uStack_1c;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01800278;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  if (*(int *)(param_1 + 0x34) != 0) {
    ExceptionList = &pvStack_10;
    param_1 = FUN_005c8ac0();
  }
  if (param_1 == 0) {
LAB_00bd4e8c:
    param_1 = 0;
  }
  else {
    iVar7 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_008dcf60();
    if ((uint)*(ushort *)(iVar2 + 0x1da) <
        (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) goto LAB_00bd4e8c;
    param_1 = param_1 + -0xc;
  }
  FUN_00bd5640();
  FUN_009cb090(auStack_6c,*(undefined4 *)(iStack_18 + 0xf8));
  uStack_8 = 0;
  piVar3 = (int *)FUN_00554150(&DAT_0195e060,4);
  pppuStack_54 = (undefined4 ***)*piVar3;
  iStack_50 = piVar3[1];
  iStack_4c = piVar3[2];
  iStack_48 = piVar3[3];
  uStack_44 = *(undefined8 *)(piVar3 + 4);
  piVar3[4] = 0;
  piVar3[5] = 0xf;
  *(undefined *)piVar3 = 0;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_58) {
    uVar8 = uStack_58 + 1;
    uVar9 = auStack_6c[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_6c[0] - 4);
      uVar8 = uStack_58 + 0x24;
      if (0x1f < (auStack_6c[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  uStack_5c = 0;
  uStack_58 = 0xf;
  auStack_6c[0] = auStack_6c[0] & 0xffffff00;
  if (param_1 != 0) {
    iStack_24 = *(int *)(param_1 + 0x1c8);
    ppppuVar4 = &pppuStack_54;
    if (0xf < uStack_44._4_4_) {
      ppppuVar4 = (undefined4 ****)pppuStack_54;
    }
    puVar5 = (undefined4 *)FUN_0086e3d0(ppppuVar4);
    if (puVar5[4] != 0) {
      puStack_14 = puVar5;
      FUN_00995490(&uStack_1c,&puStack_14);
      if (uStack_1c != 0) {
        piVar3 = *(int **)(uStack_1c + 0xc);
        goto LAB_00bd5085;
      }
      uStack_2c = 0;
      uStack_28 = 0xf;
      apppuStack_3c[0] = (undefined4 ***)((uint)apppuStack_3c[0] & 0xffffff00);
      uStack_8._0_1_ = 3;
      FUN_00578160(0x1e,0x20);
      pppuStack_20 = apppuStack_3c;
      if (0xf < uStack_28) {
        pppuStack_20 = apppuStack_3c[0];
      }
      puStack_14 = (undefined4 *)0x0;
      do {
        uStack_1c = puVar5[4];
        puVar10 = puVar5;
        if (0xf < (uint)puVar5[5]) {
          puVar10 = (undefined4 *)*puVar5;
        }
        *(byte *)((int)pppuStack_20 + (int)puStack_14) =
             (*(char *)((uint)puStack_14 % uStack_1c + (int)puVar10) -
             ((char)puStack_14 * -0x25 & 0x7fU)) + '\x1e';
        puStack_14 = (undefined4 *)((int)puStack_14 + 1);
      } while (puStack_14 < (undefined4 *)0x1e);
      pppuVar6 = (undefined4 ***)FUN_0086e830(apppuStack_3c);
      uStack_8._0_1_ = 2;
      if (0xf < uStack_28) {
        uVar9 = uStack_28 + 1;
        ppppuVar4 = (undefined4 ****)apppuStack_3c[0];
        if (0xfff < uVar9) {
          ppppuVar4 = (undefined4 ****)apppuStack_3c[0][-1];
          uVar9 = uStack_28 + 0x24;
          if (0x1f < (uint)((int)apppuStack_3c[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar4,uVar9);
      }
      iVar7 = iStack_24;
      uStack_2c = 0;
      uStack_28 = 0xf;
      apppuStack_3c[0] = (undefined4 ***)((uint)apppuStack_3c[0] & 0xffffff00);
      pppuStack_20 = pppuVar6;
      piVar3 = (int *)FUN_00995490(&uStack_1c,&pppuStack_20);
      if (*piVar3 != 0) {
        piVar3 = *(int **)(*piVar3 + 0xc);
        goto LAB_00bd5085;
      }
      if (*(int *)(iVar7 + 0x34) != 0) {
        piVar3 = (int *)FUN_00bd4940(puVar5);
        goto LAB_00bd5085;
      }
    }
  }
  piVar3 = (int *)0x0;
LAB_00bd5085:
  if (piVar3 != (int *)0x0) {
    cVar1 = (**(code **)(*piVar3 + 4))();
    if (cVar1 != '\0') {
      iVar7 = FUN_008b2e60(iStack_18);
      if (iVar7 != 0) {
        (**(code **)(*piVar3 + 0x14))(*(undefined4 *)(iVar7 + 0x248));
      }
    }
  }
  if (0xf < uStack_44._4_4_) {
    uVar9 = uStack_44._4_4_ + 1;
    ppppuVar4 = (undefined4 ****)pppuStack_54;
    if (0xfff < uVar9) {
      ppppuVar4 = (undefined4 ****)pppuStack_54[-1];
      uVar9 = uStack_44._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppuStack_54 + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar4,uVar9);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26391 ; VA 0x00bd5110 ; FUN_00bd5110 */

int __fastcall FUN_00bd5110(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018002a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_008b2e60(param_1);
  if (iVar3 != 0) {
    iStack_14 = iVar3;
    FUN_00bd3e50(&iStack_24,&iStack_14);
    uStack_8 = 0;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piStack_20[1] = piStack_20[1] + 1;
      UNLOCK();
    }
    FUN_008bac40(iStack_24,piStack_20,0);
    iVar3 = *(int *)(iStack_24 + 0x48);
    if (iVar3 != 0) {
      LOCK();
      *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
      UNLOCK();
      iVar3 = *(int *)(iStack_24 + 0x48);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    uStack_1c = 0;
    uStack_18 = 0;
    iVar3 = FUN_0089be10(*(undefined4 *)(iStack_24 + 0x44),iVar3);
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_20 + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piStack_20 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar3 = (**(code **)(*piStack_20 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 26392 ; VA 0x00bd5200 ; FUN_00bd5200 */

void __thiscall FUN_00bd5200(int param_1,int param_2)

{
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  if (param_2 != *(int *)(param_1 + 0xf8)) {
    ExceptionList = &pvStack_10;
    *(int *)(param_1 + 0xf8) = param_2;
    FUN_008a4940(&DAT_02132230);
    if (*(int *)(param_1 + 0xf8) != 0) {
      FUN_00bd5640();
      FUN_009cb090(auStack_28,*(undefined4 *)(param_1 + 0xf8));
      uStack_8 = 0;
      FUN_00bd5340(auStack_28);
      FUN_005507b0();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26393 ; VA 0x00bd5290 ; FUN_00bd5290 */

void __thiscall FUN_00bd5290(int param_1,undefined4 *param_2)

{
  char cVar1;
  undefined auStack_2c [24];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00bd5640();
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  cVar1 = FUN_009cb180(param_2,&iStack_14);
  if (cVar1 == '\0') {
    iStack_14 = 0;
  }
  if (iStack_14 != *(int *)(param_1 + 0xf8)) {
    *(int *)(param_1 + 0xf8) = iStack_14;
    FUN_008a4940(&DAT_02132230);
    if (*(int *)(param_1 + 0xf8) != 0) {
      FUN_00bd5640();
      FUN_009cb090(auStack_2c,*(undefined4 *)(param_1 + 0xf8));
      uStack_8 = 0;
      FUN_00bd5340(auStack_2c);
      FUN_005507b0();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26394 ; VA 0x00bd5340 ; FUN_00bd5340 */

void __thiscall FUN_00bd5340(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  char cVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 ****ppppuVar5;
  uint uVar6;
  uint uVar7;
  uint auStack_74 [4];
  undefined4 uStack_64;
  uint uStack_60;
  undefined4 ***pppuStack_5c;
  int iStack_58;
  int iStack_54;
  int iStack_50;
  undefined8 uStack_4c;
  undefined4 ***apppuStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018002e1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_14 = 1;
  ExceptionList = &pvStack_10;
  FUN_0058a190(param_2[4] + 9);
  FUN_00554150("Textures/",9);
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_00554150(param_2,*puVar1);
  piVar3 = (int *)FUN_00554150(&DAT_01958000,4);
  pppuStack_5c = (undefined4 ***)*piVar3;
  iStack_58 = piVar3[1];
  iStack_54 = piVar3[2];
  iStack_50 = piVar3[3];
  uStack_4c = *(undefined8 *)(piVar3 + 4);
  piVar3[4] = 0;
  piVar3[5] = 0xf;
  *(undefined *)piVar3 = 0;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_18) {
    uVar6 = uStack_18 + 1;
    uVar7 = uStack_2c;
    if (0xfff < uVar6) {
      uVar7 = *(uint *)(uStack_2c - 4);
      uVar6 = uStack_18 + 0x24;
      if (0x1f < (uStack_2c - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar6);
  }
  uStack_1c = 0;
  ppppuVar5 = &pppuStack_5c;
  if (0xf < uStack_4c._4_4_) {
    ppppuVar5 = (undefined4 ****)pppuStack_5c;
  }
  uStack_18 = 0xf;
  uStack_2c = uStack_2c & 0xffffff00;
  uVar4 = FUN_009cc450(auStack_74,ppppuVar5);
  uStack_8._0_1_ = 3;
  FUN_0054ef60(uVar4);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (0xf < uStack_60) {
    uVar6 = uStack_60 + 1;
    uVar7 = auStack_74[0];
    if (0xfff < uVar6) {
      uVar7 = *(uint *)(auStack_74[0] - 4);
      uVar6 = uStack_60 + 0x24;
      if (0x1f < (auStack_74[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar6);
  }
  uStack_64 = 0;
  uStack_60 = 0xf;
  auStack_74[0] = auStack_74[0] & 0xffffff00;
  cVar2 = FUN_00684460(apppuStack_44,(undefined4 ****)(param_1 + 0x98));
  if (cVar2 != '\0') {
    if ((undefined4 ****)(param_1 + 0x98) != apppuStack_44) {
      ppppuVar5 = apppuStack_44;
      if (0xf < uStack_30) {
        ppppuVar5 = (undefined4 ****)apppuStack_44[0];
      }
      FUN_005542c0(ppppuVar5,uStack_34);
    }
    FUN_008a4940(&DAT_021321f8);
  }
  if (0xf < uStack_30) {
    uVar7 = uStack_30 + 1;
    ppppuVar5 = (undefined4 ****)apppuStack_44[0];
    if (0xfff < uVar7) {
      ppppuVar5 = (undefined4 ****)apppuStack_44[0][-1];
      uVar7 = uStack_30 + 0x24;
      if (0x1f < (uint)((int)apppuStack_44[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar5,uVar7);
  }
  uStack_34 = 0;
  uStack_30 = 0xf;
  apppuStack_44[0] = (undefined4 ***)((uint)apppuStack_44[0] & 0xffffff00);
  if (0xf < uStack_4c._4_4_) {
    uVar7 = uStack_4c._4_4_ + 1;
    ppppuVar5 = (undefined4 ****)pppuStack_5c;
    if (0xfff < uVar7) {
      ppppuVar5 = (undefined4 ****)pppuStack_5c[-1];
      uVar7 = uStack_4c._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppuStack_5c + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar5,uVar7);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26395 ; VA 0x00bd5590 ; FUN_00bd5590 */

void FUN_00bd5590(void)

{
  FUN_008a6520();
  return;
}



/* FUNCTION 26396 ; VA 0x00bd55a0 ; FUN_00bd55a0 */

void __thiscall FUN_00bd55a0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  char cVar2;
  
  cVar2 = FUN_00684460(param_2,(undefined4 *)(param_1 + 0x98));
  if (cVar2 != '\0') {
    if ((undefined4 *)(param_1 + 0x98) != param_2) {
      puVar1 = param_2 + 4;
      if (0xf < (uint)param_2[5]) {
        param_2 = (undefined4 *)*param_2;
      }
      FUN_005542c0(param_2,*puVar1);
    }
    FUN_008a4940(&DAT_021321f8);
  }
  return;
}



/* FUNCTION 26397 ; VA 0x00bd55f0 ; FUN_00bd55f0 */

void __thiscall FUN_00bd55f0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_00bd5640();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 26398 ; VA 0x00bd5640 ; FUN_00bd5640 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00bd5640(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01800306;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef68b4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef68b4);
    if (DAT_01ef68b4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("BinType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef6850 = RBX::Reflection::EnumDesc<enum_RBX::HopperBin::BinType>::vftable;
      FUN_009caf20(&DAT_01d67e48,5);
      FUN_009cab70(5,"Slingshot",0);
      FUN_009cab70(6,"Rocket",0);
      FUN_009cab70(7,"Laser",0);
      FUN_016f3654(&LAB_018922a0);
      FUN_016f37bf(&DAT_01ef68b4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef6850;
}



/* FUNCTION 26399 ; VA 0x00bd5730 ; FUN_00bd5730 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00bd5730(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef68c4) {
    FUN_016f3809(&DAT_01ef68c4);
    if (DAT_01ef68c4 == -1) {
      _DAT_01ef68b8 = FUN_005c65e0;
      _DAT_01ef68bc = FUN_005c65e0;
      _DAT_01ef68c0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef68c4);
    }
  }
  return &DAT_01ef68b8;
}



/* FUNCTION 26400 ; VA 0x00bd57a0 ; FUN_00bd57a0 */

undefined4 * __thiscall FUN_00bd57a0(undefined4 *param_1,undefined4 *param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01800323;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::
             _Func_impl_no_alloc<class_<lambda_e4e29e8e84969e026d0d37436cf32e32>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[2] = *param_2;
  param_1[3] = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[4] = param_2[2];
  param_1[5] = param_2[3];
  param_2[2] = 0;
  param_2[3] = 0;
  uStack_8 = 1;
  param_1[6] = 0;
  FUN_005880d0(param_2 + 4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26401 ; VA 0x00bd5850 ; FUN_00bd5850 */

undefined4 * __thiscall
FUN_00bd5850(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  int *in_stack_00000030;
  undefined4 auStack_b0 [9];
  undefined4 uStack_8c;
  undefined *puStack_88;
  undefined *puStack_84;
  uint *puStack_80;
  uint auStack_6c [2];
  undefined auStack_64 [28];
  int *piStack_48;
  undefined4 uStack_44;
  uint auStack_3c [2];
  undefined auStack_34 [28];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01800348;
  pvStack_10 = ExceptionList;
  puStack_80 = &param_4;
  uStack_8 = 0;
  puStack_84 = (undefined *)0xbd588b;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00967510();
  uStack_44 = param_2;
  puStack_80 = auStack_6c;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  puStack_84 = (undefined *)0xbd58a7;
  FUN_00967510();
  puStack_80 = param_1 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_14 = auStack_b0;
  auStack_b0[0] = uStack_44;
  FUN_00967510(auStack_3c);
  ppuVar4 = &PTR_FUN_0195e780;
  cVar3 = FUN_00bd6410();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[2] + -1;
    piStack_18[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_80 = (uint *)0xbd58f5;
      (**(code **)(*piStack_18 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (auStack_3c[0] != 0) {
    if (((auStack_3c[0] & 1) == 0) && (*(code **)(auStack_3c[0] & 0xfffffffe) != (code *)0x0)) {
      puStack_88 = auStack_34;
      puStack_80 = (uint *)0x2;
      uStack_8c = 0xbd5916;
      puStack_84 = puStack_88;
      (**(code **)(auStack_3c[0] & 0xfffffffe))();
    }
    auStack_3c[0] = 0;
  }
  if (piStack_48 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_48[2] + -1;
    piStack_48[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_80 = (uint *)0xbd5935;
      (**(code **)(*piStack_48 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (auStack_6c[0] != 0) {
    if (((auStack_6c[0] & 1) == 0) && (*(code **)(auStack_6c[0] & 0xfffffffe) != (code *)0x0)) {
      puStack_88 = auStack_64;
      puStack_80 = (uint *)0x2;
      uStack_8c = 0xbd5956;
      puStack_84 = puStack_88;
      (**(code **)(auStack_6c[0] & 0xfffffffe))();
    }
    auStack_6c[0] = 0;
  }
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000030 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_80 = (uint *)0xbd5974;
      (**(code **)(*in_stack_00000030 + 4))();
    }
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_88 = &stack0x00000014;
    puStack_80 = (uint *)0x2;
    uStack_8c = 0xbd5998;
    puStack_84 = puStack_88;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26402 ; VA 0x00bd59b0 ; FUN_00bd59b0 */

undefined4 * __thiscall
FUN_00bd59b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[2] = param_6[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[2] = param_6[2] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[2] = param_6[2] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_0195e788;
  cVar3 = FUN_00bd6780(param_2,param_3,param_4,param_5,param_6,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[2] + -1;
    param_6[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_6 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[2] + -1;
    param_6[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_6 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[2] + -1;
    param_6[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_6 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 26403 ; VA 0x00bd5af0 ; FUN_00bd5af0 */

int FUN_00bd5af0(undefined4 param_1,undefined4 *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  code *pcVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  int aiStack_34 [5];
  uint uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbe30;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_3[1]);
  puVar3 = (undefined4 *)*param_3;
  piVar8 = (int *)puVar3[1];
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
    piVar8 = (int *)puVar3[1];
  }
  uVar4 = *puVar3;
  uStack_8 = 1;
  pcVar5 = (code *)*param_2;
  uStack_1c = uVar4;
  piStack_18 = piVar8;
  FUN_0054ef60(aiStack_34);
  piVar1 = piVar8 + 1;
  if (piVar8 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar6 = (*pcVar5)(uVar4,piVar8);
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*piVar8)();
      LOCK();
      piVar1 = piVar8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar8 + 4))();
      }
    }
  }
  if (0xf < uStack_20) {
    uVar7 = uStack_20 + 1;
    iVar6 = aiStack_34[0];
    if (0xfff < uVar7) {
      iVar6 = *(int *)(aiStack_34[0] + -4);
      uVar7 = uStack_20 + 0x24;
      if (0x1f < (aiStack_34[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar6 = FUN_01674ea0(iVar6,uVar7);
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 26404 ; VA 0x00bd5c00 ; FUN_00bd5c00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00bd5c00(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01800380;
  pvStack_10 = ExceptionList;
  if (DAT_01ef6900 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef6b18) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef6b18);
      if (DAT_01ef6b18 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"LogService",1,uStack_20,0,0,3,0,0);
        _DAT_01ef6b10 = RBX::Creator<class_RBX::LogService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef6908,&DAT_01ef6b10);
        FUN_016f3654(FUN_01892530);
        FUN_016f37bf(&DAT_01ef6b18);
      }
    }
    DAT_01ef6900 = &DAT_01ef6908;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef6900;
}



/* FUNCTION 26405 ; VA 0x00bd5d00 ; FUN_00bd5d00 */

void FUN_00bd5d00(void)

{
  int iVar1;
  
  if (DAT_01ef6b1c == 0) {
    iVar1 = FUN_00bd5c00();
    DAT_01ef6b1c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 26406 ; VA 0x00bd5d20 ; FUN_00bd5d20 */

int * __thiscall FUN_00bd5d20(int *param_1,undefined4 param_2)

{
  undefined *puVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  undefined4 *puVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  undefined4 uVar9;
  undefined auStack_48 [12];
  int *piStack_3c;
  int *piStack_38;
  char cStack_34;
  int *piStack_28;
  uint uStack_24;
  int *piStack_20;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018003c7;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff78;
  uStack_24 = 0;
  piVar6 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  ExceptionList = &pvStack_10;
  piStack_38 = param_1;
  piStack_20 = param_1;
  puVar1 = &stack0xffffff78;
  if (piVar6 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*piVar6 + 4))();
    puVar1 = puStack_14;
  }
  puStack_14 = puVar1;
  uVar9 = 0;
  uStack_8 = 0;
  cStack_34 = FUN_00593b40(0);
  if (cStack_34 == '\0') goto LAB_00bd5f19;
  piVar6 = *(int **)(*(int *)(*(int *)(*param_1 + 4) + 0x30 + (int)param_1) + 4);
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  piStack_3c = piVar6;
  (**(code **)(*piVar6 + 4))();
  uStack_8._0_1_ = 4;
  FUN_016dda75(0);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  piStack_28 = DAT_01eeae50;
  uStack_18 = DAT_01eeae4c;
  if (DAT_01eeae4c == 0) {
    FUN_016dda75(0);
    if (DAT_01eeae4c == 0) {
      DAT_01eeae4c = DAT_021130c8 + 1;
      DAT_021130c8 = DAT_01eeae4c;
    }
    FUN_016ddacd();
  }
  uStack_18 = DAT_01eeae4c;
  if (DAT_01eeae4c < (uint)piVar6[3]) {
    piVar3 = *(int **)(piVar6[2] + DAT_01eeae4c * 4);
    if (piVar3 == (int *)0x0) goto LAB_00bd5e0f;
  }
  else {
    piVar3 = (int *)0x0;
LAB_00bd5e0f:
    if (*(char *)(piVar6 + 5) == '\0') {
LAB_00bd5e28:
      if (piVar3 != (int *)0x0) goto LAB_00bd5e97;
    }
    else {
      iVar2 = FUN_016de17b();
      if (uStack_18 < *(uint *)(iVar2 + 0xc)) {
        piVar3 = *(int **)(*(int *)(iVar2 + 8) + uStack_18 * 4);
        goto LAB_00bd5e28;
      }
    }
    piVar3 = piStack_28;
    if (piStack_28 == (int *)0x0) {
      piVar3 = (int *)FUN_01674e20(8);
      uStack_8._0_1_ = 6;
      if (piVar3 == (int *)0x0) {
        piVar3 = (int *)0x0;
      }
      else {
        piVar4 = (int *)piVar6[6];
        if (piVar4 == (int *)0x0) {
          piVar4 = piVar6 + 7;
        }
        piStack_28 = piVar3;
        FUN_0054f870(piVar4);
        piVar3[1] = 0;
        *piVar3 = (int)std::
                       num_get<char,class_std::istreambuf_iterator<char,struct_std::char_traits<char>_>_>
                       ::vftable;
        FUN_00550e70();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      piStack_28 = piVar3;
      FUN_016de14f(piVar3);
      (**(code **)(*piVar3 + 4))();
      DAT_01eeae50 = piVar3;
    }
  }
LAB_00bd5e97:
  uStack_8._0_1_ = 4;
  FUN_016ddacd();
  piStack_28 = (int *)CONCAT22(piStack_28._2_2_,1);
  iVar2 = *(int *)(*param_1 + 4) + (int)param_1;
  uStack_18 = CONCAT31((int3)(uStack_18 >> 8),*(int *)(iVar2 + 0x38) == 0) & 0xffff00ff;
  (**(code **)(*piVar3 + 0x20))
            (auStack_48,*(undefined4 *)(iVar2 + 0x38),uStack_18,0,piStack_28,iVar2,&uStack_24,
             param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  puVar5 = (undefined4 *)(**(code **)(*piVar6 + 8))();
  if (puVar5 != (undefined4 *)0x0) {
    (**(code **)*puVar5)(1);
    piVar6 = (int *)FUN_00bd5f12(uVar9);
    return piVar6;
  }
LAB_00bd5f19:
  uStack_8 = 1;
  uVar8 = *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc) | uStack_24;
  uVar7 = uVar8 | 4;
  if (*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) != 0) {
    uVar7 = uVar8;
  }
  FUN_00554460(uVar7,0);
  uStack_8 = 10;
  piVar6 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  if (piVar6 != (int *)0x0) {
    (**(code **)(*piVar6 + 8))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26407 ; VA 0x00bd5ef6 ; Catch_All@00bd5ef6 */

undefined * Catch_All_00bd5ef6(void)

{
  FUN_005565b0(4,1);
  return &DAT_00bd5f0f;
}



/* FUNCTION 26408 ; VA 0x00bd5f12 ; FUN_00bd5f12 */

void FUN_00bd5f12(void)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  uint uVar4;
  int unaff_EBP;
  int *unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  uVar4 = *(uint *)((int)unaff_EDI + *(int *)(*unaff_EDI + 4) + 0xc) | *(uint *)(unaff_EBP + -0x20);
  uVar3 = uVar4 | 4;
  if (*(int *)((int)unaff_EDI + *(int *)(*unaff_EDI + 4) + 0x38) != 0) {
    uVar3 = uVar4;
  }
  FUN_00554460(uVar3,0);
  iVar1 = *unaff_EDI;
  *(undefined4 *)(unaff_EBP + -4) = 10;
  piVar2 = *(int **)(*(int *)(iVar1 + 4) + 0x38 + (int)unaff_EDI);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 8))();
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 26409 ; VA 0x00bd5f70 ; FUN_00bd5f70 */

undefined4 * FUN_00bd5f70(undefined4 *param_1)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018003f3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar6 = (undefined4 *)FUN_01674e20(0x38);
  *puVar6 = std::
            _Func_impl_no_alloc<class_<lambda_e4e29e8e84969e026d0d37436cf32e32>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
            ::vftable;
  puVar6[2] = 0;
  puVar6[3] = 0;
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puVar6[2] = *param_1;
  puVar6[3] = param_1[1];
  puVar6[4] = 0;
  puVar6[5] = 0;
  if (param_1[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puVar6[4] = param_1[2];
  puVar6[5] = param_1[3];
  puVar6[6] = 0;
  uVar2 = param_1[4];
  uStack_8 = 2;
  if (uVar2 != 0) {
    puVar6[6] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_1 + 6,puVar6 + 8,0);
      ExceptionList = pvStack_10;
      return puVar6;
    }
    uVar3 = param_1[7];
    uVar4 = param_1[8];
    uVar5 = param_1[9];
    puVar6[8] = param_1[6];
    puVar6[9] = uVar3;
    puVar6[10] = uVar4;
    puVar6[0xb] = uVar5;
    *(undefined8 *)(puVar6 + 0xc) = *(undefined8 *)(param_1 + 10);
  }
  ExceptionList = pvStack_10;
  return puVar6;
}



/* FUNCTION 26410 ; VA 0x00bd6063 ; Catch_All@00bd6063 */

void Catch_All_00bd6063(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x38);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 26411 ; VA 0x00bd6080 ; FUN_00bd6080 */

undefined4 FUN_00bd6080(undefined4 param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01800400;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01674e20(0x38);
  uStack_8 = 0;
  FUN_00bd57a0(param_1);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 26412 ; VA 0x00bd60d4 ; Catch_All@00bd60d4 */

void Catch_All_00bd60d4(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x38);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 26413 ; VA 0x00bd60f0 ; FUN_00bd60f0 */

void __thiscall FUN_00bd60f0(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined **ppuVar6;
  int *in_stack_00000058;
  undefined auStack_114 [76];
  int *piStack_c8;
  undefined4 uStack_c4;
  undefined auStack_bc [76];
  int *piStack_70;
  undefined4 auStack_6c [2];
  undefined auStack_64 [76];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01800445;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00bd70d0(&stack0x0000000c);
  auStack_6c[0] = param_2;
  uStack_8._0_1_ = 1;
  FUN_00bd70d0(auStack_114);
  uStack_8._0_1_ = 2;
  cVar4 = FUN_00585a40(auStack_6c);
  if (cVar4 == '\0') {
    uStack_c4 = auStack_6c[0];
    FUN_00bd70d0(auStack_64);
    uStack_8._0_1_ = 3;
    puVar5 = (undefined4 *)FUN_01674e20(0x58);
    uStack_8._0_1_ = 4;
    puStack_14 = puVar5;
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      *puVar5 = uStack_c4;
      FUN_00bd70d0(auStack_bc);
    }
    param_1[2] = puVar5;
    if (piStack_70 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_70[2] + -1;
      piStack_70[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_70 + 4))();
      }
    }
    FUN_00bd8160();
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    FUN_00bd8160();
    bVar3 = true;
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    FUN_00bd8160();
    bVar3 = false;
  }
  if (piStack_c8 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c8[2] + -1;
    piStack_c8[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c8 + 4))();
    }
  }
  FUN_00bd8160();
  ppuVar6 = &PTR_FUN_0195e778;
  if (!bVar3) {
    ppuVar6 = (undefined **)0x0;
  }
  *param_1 = ppuVar6;
  if (in_stack_00000058 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000058 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*in_stack_00000058 + 4))();
    }
  }
  FUN_00bd8160();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26414 ; VA 0x00bd6280 ; FUN_00bd6280 */

void __thiscall FUN_00bd6280(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined **ppuVar6;
  int *in_stack_00000058;
  undefined auStack_114 [76];
  int *piStack_c8;
  undefined4 uStack_c4;
  undefined auStack_bc [76];
  int *piStack_70;
  undefined4 auStack_6c [2];
  undefined auStack_64 [76];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01800485;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00bd7310(&stack0x0000000c);
  auStack_6c[0] = param_2;
  uStack_8._0_1_ = 1;
  FUN_00bd7310(auStack_114);
  uStack_8._0_1_ = 2;
  cVar4 = FUN_00585a40(auStack_6c);
  if (cVar4 == '\0') {
    uStack_c4 = auStack_6c[0];
    FUN_00bd7310(auStack_64);
    uStack_8._0_1_ = 3;
    puVar5 = (undefined4 *)FUN_01674e20(0x58);
    uStack_8._0_1_ = 4;
    puStack_14 = puVar5;
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      *puVar5 = uStack_c4;
      FUN_00bd7310(auStack_bc);
    }
    param_1[2] = puVar5;
    if (piStack_70 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_70[2] + -1;
      piStack_70[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_70 + 4))();
      }
    }
    FUN_00651cc0();
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    FUN_00651cc0();
    bVar3 = true;
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    FUN_00651cc0();
    bVar3 = false;
  }
  if (piStack_c8 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c8[2] + -1;
    piStack_c8[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c8 + 4))();
    }
  }
  FUN_00651cc0();
  ppuVar6 = &PTR_FUN_0195e770;
  if (!bVar3) {
    ppuVar6 = (undefined **)0x0;
  }
  *param_1 = ppuVar6;
  if (in_stack_00000058 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000058 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*in_stack_00000058 + 4))();
    }
  }
  FUN_00651cc0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26415 ; VA 0x00bd6410 ; FUN_00bd6410 */

undefined FUN_00bd6410(undefined4 param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined uVar6;
  int *in_stack_00000030;
  int *in_stack_00000034;
  uint auStack_6c [2];
  undefined auStack_64 [28];
  int *piStack_48;
  undefined4 auStack_44 [2];
  uint auStack_3c [2];
  undefined auStack_34 [28];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018004b7;
  pvStack_10 = ExceptionList;
  auStack_44[0] = param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00967510(&param_3);
  uStack_8._0_1_ = 1;
  cVar4 = FUN_00585a40(auStack_44);
  uVar3 = auStack_44[0];
  if (cVar4 == '\0') {
    FUN_00967510(auStack_3c);
    uStack_8._0_1_ = 2;
    puVar5 = (undefined4 *)FUN_01674e20(0x30);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    puStack_14 = puVar5;
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      *puVar5 = uVar3;
      FUN_00967510(auStack_6c);
    }
    *in_stack_00000034 = (int)puVar5;
    if (piStack_48 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_48[2] + -1;
      piStack_48[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_48 + 4))();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (auStack_6c[0] != 0) {
      if (((auStack_6c[0] & 1) == 0) && (*(code **)(auStack_6c[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_6c[0] & 0xfffffffe))(auStack_64,auStack_64,2);
      }
      auStack_6c[0] = 0;
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (auStack_3c[0] != 0) {
      if (((auStack_3c[0] & 1) == 0) && (*(code **)(auStack_3c[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_3c[0] & 0xfffffffe))(auStack_34,auStack_34,2);
      }
      auStack_3c[0] = 0;
    }
    uVar6 = 1;
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (auStack_3c[0] != 0) {
      if (((auStack_3c[0] & 1) == 0) && (*(code **)(auStack_3c[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_3c[0] & 0xfffffffe))(auStack_34,auStack_34,2);
      }
      auStack_3c[0] = 0;
    }
    uVar6 = 0;
  }
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000030 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*in_stack_00000030 + 4))();
    }
  }
  uStack_8 = 7;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 26416 ; VA 0x00bd65c0 ; FUN_00bd65c0 */

void __thiscall FUN_00bd65c0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined4 uStack_80;
  int iStack_7c;
  undefined auStack_78 [24];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  int iStack_58;
  undefined auStack_54 [24];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int iStack_34;
  undefined auStack_30 [24];
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_0180051f;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_80;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_4 + 8) = *(int *)(param_4 + 8) + 1;
    UNLOCK();
  }
  uStack_80 = param_3;
  iStack_7c = param_4;
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_0054ef60(&stack0x00000010);
  uStack_3c = param_2;
  puStack_14 = &uStack_38;
  if (iStack_7c != 0) {
    LOCK();
    *(int *)(iStack_7c + 8) = *(int *)(iStack_7c + 8) + 1;
    UNLOCK();
  }
  uStack_38 = uStack_80;
  iStack_34 = iStack_7c;
  uStack_8 = 3;
  FUN_0054ef60(auStack_78);
  uStack_8 = 4;
  cVar2 = FUN_00585a40(&uStack_3c);
  if (cVar2 == '\0') {
    uStack_60 = uStack_3c;
    puStack_14 = &uStack_5c;
    if (iStack_34 != 0) {
      LOCK();
      *(int *)(iStack_34 + 8) = *(int *)(iStack_34 + 8) + 1;
      UNLOCK();
    }
    uStack_5c = uStack_38;
    iStack_58 = iStack_34;
    uStack_8 = 5;
    FUN_0054ef60(auStack_30);
    uStack_8 = 6;
    puVar3 = (undefined4 *)FUN_01674e20(0x24);
    uStack_8 = 7;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uStack_60;
      puStack_18 = puVar3 + 1;
      *puStack_18 = 0;
      puVar3[2] = 0;
      if (iStack_58 != 0) {
        LOCK();
        *(int *)(iStack_58 + 8) = *(int *)(iStack_58 + 8) + 1;
        UNLOCK();
      }
      *puStack_18 = uStack_5c;
      puVar3[2] = iStack_58;
      uStack_8 = 8;
      FUN_0054ef60(auStack_54);
    }
    param_1[2] = puVar3;
    FUN_005d11a0();
    FUN_005d11a0();
    bVar1 = true;
  }
  else {
    FUN_005d11a0();
    bVar1 = false;
  }
  FUN_005d11a0();
  ppuVar4 = &PTR_FUN_0195e790;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_005d11a0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26417 ; VA 0x00bd6780 ; FUN_00bd6780 */

undefined FUN_00bd6780(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
                      int *param_5,undefined4 *param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined uVar4;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  int *piStack_10;
  undefined4 uStack_c;
  int *piStack_8;
  
  uStack_18 = param_1;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  uStack_c = param_4;
  piStack_8 = param_5;
  cVar3 = FUN_00585a40(&uStack_18);
  if (cVar3 == '\0') {
    FUN_00bd7070(&uStack_18);
    *param_6 = uStack_2c;
    param_6[1] = 0;
    param_6[2] = 0;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[2] = piStack_24[2] + 1;
      UNLOCK();
    }
    param_6[1] = uStack_28;
    param_6[2] = piStack_24;
    param_6[3] = 0;
    param_6[4] = 0;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[2] = piStack_1c[2] + 1;
      UNLOCK();
    }
    param_6[3] = uStack_20;
    param_6[4] = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[2] + -1;
      piStack_24[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_8[2] + -1;
      piStack_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    uVar4 = 1;
  }
  else {
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_8[2] + -1;
      piStack_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    uVar4 = 0;
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return uVar4;
}



/* FUNCTION 26418 ; VA 0x00bd68f0 ; FUN_00bd68f0 */

undefined4 *
FUN_00bd68f0(undefined4 *param_1,undefined4 param_2,uint param_3,undefined4 param_4,int param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined8 param_9,
            undefined4 param_10,int *param_11,int *param_12,undefined4 param_13)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  uint *puVar4;
  undefined4 *puVar5;
  uint auStack_a0 [2];
  int iStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined8 uStack_88;
  undefined4 uStack_80;
  int *piStack_7c;
  int *piStack_78;
  uint *puStack_74;
  uint auStack_68 [2];
  int aiStack_60 [7];
  int *piStack_44;
  uint uStack_40;
  int iStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  piVar1 = param_11;
  uVar3 = param_10;
  puStack_c = &LAB_01800568;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_11 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_11[2] = param_11[2] + 1;
    UNLOCK();
  }
  uStack_20 = param_10;
  piStack_1c = param_11;
  uStack_8 = 2;
  uStack_7 = 0;
  uStack_40 = 0;
  if (param_3 != 0) {
    uStack_40 = param_3;
    if ((param_3 & 1) == 0) {
      piStack_78 = &iStack_38;
      puStack_74 = (uint *)0x0;
      piStack_7c = &param_5;
      uStack_80 = 0xbd6969;
      (**(code **)(param_3 & 0xfffffffe))();
    }
    else {
      iStack_38 = param_5;
      uStack_34 = param_6;
      uStack_30 = param_7;
      uStack_2c = param_8;
      uStack_28 = param_9;
    }
  }
  puStack_74 = (uint *)param_13;
  piStack_78 = param_12;
  puStack_14 = (undefined *)&uStack_80;
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar1[2] = piVar1[2] + 1;
    UNLOCK();
  }
  uStack_80 = uVar3;
  piStack_7c = piVar1;
  puStack_18 = (undefined *)auStack_a0;
  uStack_8 = 5;
  auStack_a0[0] = 0;
  puVar4 = auStack_a0;
  puVar5 = &uStack_80;
  if (uStack_40 != 0) {
    auStack_a0[0] = uStack_40;
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&iStack_38,&iStack_98,0);
      puVar4 = (uint *)puStack_18;
      puVar5 = (undefined4 *)puStack_14;
    }
    else {
      iStack_98 = iStack_38;
      uStack_94 = uStack_34;
      uStack_90 = uStack_30;
      uStack_8c = uStack_2c;
      uStack_88 = uStack_28;
      puVar4 = auStack_a0;
      puVar5 = &uStack_80;
    }
  }
  puStack_14 = (undefined *)puVar5;
  puStack_18 = (undefined *)puVar4;
  uStack_8 = 4;
  FUN_00bd7810();
  _uStack_8 = CONCAT31(uStack_7,6);
  if (uStack_40 != 0) {
    if (((uStack_40 & 1) == 0) && (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
      piStack_7c = &iStack_38;
      puStack_74 = (uint *)0x2;
      uStack_80 = 0xbd6a0d;
      piStack_78 = piStack_7c;
      (**(code **)(uStack_40 & 0xfffffffe))();
    }
    uStack_40 = 0;
  }
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_74 = (uint *)0xbd6a2e;
      (**(code **)(*piVar1 + 4))();
    }
  }
  _uStack_8 = CONCAT31(uStack_7,7);
  *param_1 = param_2;
  puStack_74 = auStack_68;
  piStack_78 = (int *)0xbd6a46;
  FUN_00967510();
  if (piStack_44 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_44[2] + -1;
    piStack_44[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_74 = (uint *)0xbd6a5b;
      (**(code **)(*piStack_44 + 4))();
    }
  }
  uStack_8 = 8;
  if (auStack_68[0] != 0) {
    if (((auStack_68[0] & 1) == 0) && (*(code **)(auStack_68[0] & 0xfffffffe) != (code *)0x0)) {
      piStack_7c = aiStack_60;
      puStack_74 = (uint *)0x2;
      uStack_80 = 0xbd6a7c;
      piStack_78 = piStack_7c;
      (**(code **)(auStack_68[0] & 0xfffffffe))();
    }
    auStack_68[0] = 0;
  }
  _uStack_8 = CONCAT31(uStack_7,9);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    piStack_7c = &param_5;
    puStack_74 = (uint *)0x2;
    uStack_80 = 0xbd6aa7;
    piStack_78 = piStack_7c;
    (**(code **)(param_3 & 0xfffffffe))();
  }
  if (param_11 != (int *)0x0) {
    LOCK();
    piVar1 = param_11 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_74 = (uint *)0xbd6ac5;
      (**(code **)(*param_11 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26419 ; VA 0x00bd6ae0 ; FUN_00bd6ae0 */

undefined4 *
FUN_00bd6ae0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[2] = param_6[2] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  piVar1 = param_6 + 2;
  if (param_6 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    piVar2 = param_4 + 2;
    LOCK();
    *piVar2 = *piVar2 + 1;
    UNLOCK();
    LOCK();
    *piVar2 = *piVar2 + 1;
    UNLOCK();
    LOCK();
    *piVar2 = *piVar2 + 1;
    UNLOCK();
    LOCK();
    iVar3 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[2] = param_6[2] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar3 = param_4[2] + -1;
    param_4[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)(*param_6 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar3 = param_4[2] + -1;
    param_4[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)(*param_6 + 4))();
    }
  }
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  piVar1 = param_6 + 2;
  param_1[1] = param_3;
  param_1[2] = param_4;
  param_1[3] = 0;
  param_1[4] = 0;
  if (param_6 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[3] = param_5;
  param_1[4] = param_6;
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)(*param_6 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar3 = param_4[2] + -1;
    param_4[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar3 = param_4[2] + -1;
    param_4[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*param_6 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 26420 ; VA 0x00bd6c50 ; FUN_00bd6c50 */

undefined4 * __thiscall FUN_00bd6c50(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c62e1;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006eccd0();
  uStack_8 = 0;
  uVar2 = FUN_01675290(DAT_02110da8);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x24);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = 0;
    puVar3[1] = 1;
    puVar3[2] = FUN_00ae4280;
    puVar3[3] = FUN_0057e090;
    puVar3[4] = 0;
    puVar3[5] = param_1;
    puVar3[6] = *param_3;
    puVar3[7] = 0;
    puVar3[8] = 0;
    if (param_3[2] != 0) {
      LOCK();
      piVar1 = (int *)(param_3[2] + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    puVar3[7] = param_3[1];
    puVar3[8] = param_3[2];
  }
  FUN_016797d0(puVar3);
  *param_2 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    LOCK();
    puVar3[1] = puVar3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 26421 ; VA 0x00bd6d50 ; FUN_00bd6d50 */

void FUN_00bd6d50(undefined4 *param_1,int *param_2,int *param_3,code *param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  char cVar5;
  
  if (param_2 != param_3) {
    do {
      if (param_2[3] != 0) {
        LOCK();
        piVar1 = (int *)(param_2[3] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      cVar5 = (*param_4)(param_2[2],param_2[3]);
    } while ((cVar5 == '\0') && (param_2 = (int *)*param_2, param_2 != param_3));
    if (param_2 != param_3) {
      for (piVar1 = (int *)*param_2; piVar1 != param_3; piVar1 = (int *)*piVar1) {
        if (piVar1[3] != 0) {
          LOCK();
          piVar2 = (int *)(piVar1[3] + 8);
          *piVar2 = *piVar2 + 1;
          UNLOCK();
        }
        cVar5 = (*param_4)(piVar1[2],piVar1[3]);
        if (cVar5 == '\0') {
          iVar3 = piVar1[2];
          iVar4 = piVar1[3];
          piVar1[2] = 0;
          piVar1[3] = 0;
          param_2[2] = iVar3;
          piVar2 = (int *)param_2[3];
          param_2[3] = iVar4;
          if (piVar2 != (int *)0x0) {
            LOCK();
            iVar3 = piVar2[2] + -1;
            piVar2[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
          param_2 = (int *)*param_2;
        }
      }
    }
  }
  *param_1 = param_2;
  return;
}



/* FUNCTION 26422 ; VA 0x00bd6e30 ; FUN_00bd6e30 */

undefined4 * __fastcall FUN_00bd6e30(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("MessageType");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::MessageType>::vftable;
  FUN_009caf20(&DAT_01d67f50,4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26423 ; VA 0x00bd6e90 ; FUN_00bd6e90 */

undefined4 * __thiscall
FUN_00bd6e90(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 uVar1;
  undefined auStack_110 [216];
  undefined8 uStack_38;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_018005a1;
  pvStack_1c = ExceptionList;
  uStack_38 = param_6;
  ExceptionList = &pvStack_1c;
  puStack_30 = param_1;
  uVar1 = FUN_00bd5c00();
  FUN_009cb970(uVar1,param_3,param_5,uStack_38,param_7);
  param_1[0xd] = param_2;
  iStack_14 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::LogService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::LogService::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_14._0_1_ = 1;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00687810(auStack_110,&uStack_38,puStack_30);
  iStack_14._0_1_ = 2;
  if (param_1 + 10 != &uStack_2c) {
    FUN_0068a760();
    param_1[10] = uStack_2c;
    param_1[0xb] = uStack_28;
    param_1[0xc] = uStack_24;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
  }
  iStack_14._0_1_ = 3;
  FUN_0068a760();
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  FUN_016f32d1(auStack_110,0xd8,1,FUN_00688b10);
  param_1[0xe] = param_9;
  param_1[0xf] = param_8;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::LogService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::LogService::*>
             ::vftable;
  ExceptionList = pvStack_1c;
  return param_1;
}



/* FUNCTION 26424 ; VA 0x00bd6ff0 ; FUN_00bd6ff0 */

undefined4 * __thiscall FUN_00bd6ff0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018005b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26425 ; VA 0x00bd7070 ; FUN_00bd7070 */

undefined4 * __thiscall FUN_00bd7070(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = 0;
  param_1[4] = 0;
  if (param_2[4] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[4] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  return param_1;
}



/* FUNCTION 26426 ; VA 0x00bd70d0 ; FUN_00bd70d0 */

undefined * __thiscall FUN_00bd70d0(undefined *param_1,undefined *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018005db;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  *(undefined4 *)(param_1 + 4) = *(undefined4 *)(param_2 + 4);
  *(undefined4 *)(param_1 + 8) = *(undefined4 *)(param_2 + 8);
  *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
  FUN_0054ef60(param_2 + 0x18);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0x30);
  *(undefined4 *)(param_1 + 0x48) = 0;
  *(undefined4 *)(param_1 + 0x4c) = 0;
  if (*(int *)(param_2 + 0x4c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_2 + 0x4c) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x48) = *(undefined4 *)(param_2 + 0x48);
  *(undefined4 *)(param_1 + 0x4c) = *(undefined4 *)(param_2 + 0x4c);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26427 ; VA 0x00bd7170 ; FUN_00bd7170 */

undefined * __thiscall
FUN_00bd7170(undefined *param_1,undefined param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 in_stack_0000004c;
  int *in_stack_00000050;
  undefined auStack_ac [4];
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined8 uStack_9c;
  undefined auStack_94 [24];
  undefined auStack_7c [24];
  undefined auStack_64 [4];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_54;
  undefined auStack_4c [24];
  undefined auStack_34 [24];
  undefined4 uStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  piVar1 = in_stack_00000050;
  uVar3 = in_stack_0000004c;
  puStack_c = &LAB_01800644;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000050 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000050[2] = in_stack_00000050[2] + 1;
    UNLOCK();
  }
  uStack_1c = in_stack_0000004c;
  piStack_18 = in_stack_00000050;
  puStack_14 = auStack_ac;
  auStack_ac[0] = param_2;
  uStack_a8 = param_3;
  uStack_a4 = param_4;
  uStack_8 = 2;
  uStack_7 = 0;
  uStack_9c = param_6;
  FUN_0054ef60(&stack0x0000001c);
  uStack_8 = 3;
  FUN_0054ef60(&stack0x00000034);
  puStack_14 = auStack_64;
  auStack_64[0] = auStack_ac[0];
  uStack_60 = uStack_a8;
  uStack_5c = uStack_a4;
  uStack_8 = 5;
  uStack_54 = uStack_9c;
  FUN_0054ef60(auStack_94);
  uStack_8 = 6;
  FUN_0054ef60(auStack_7c);
  *param_1 = auStack_64[0];
  *(undefined4 *)(param_1 + 4) = uStack_60;
  *(undefined4 *)(param_1 + 8) = uStack_5c;
  uStack_8 = 7;
  *(undefined8 *)(param_1 + 0x10) = uStack_54;
  puStack_14 = param_1;
  FUN_0054ef60(auStack_4c);
  _uStack_8 = CONCAT31(uStack_7,8);
  FUN_0054ef60(auStack_34);
  FUN_00bd8160();
  *(undefined4 *)(param_1 + 0x48) = 0;
  *(undefined4 *)(param_1 + 0x4c) = 0;
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar1[2] = piVar1[2] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x48) = uVar3;
  *(int **)(param_1 + 0x4c) = piVar1;
  FUN_00bd8160();
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_00bd8160();
  if (in_stack_00000050 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000050 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*in_stack_00000050 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26428 ; VA 0x00bd7310 ; FUN_00bd7310 */

undefined4 * __thiscall FUN_00bd7310(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180065b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  FUN_0054ef60(param_2 + 2);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 8);
  param_1[0xe] = param_2[0xe];
  param_1[0xf] = param_2[0xf];
  param_1[0x10] = param_2[0x10];
  param_1[0x11] = param_2[0x11];
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  if (param_2[0x13] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0x13] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x12] = param_2[0x12];
  param_1[0x13] = param_2[0x13];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26429 ; VA 0x00bd73b0 ; FUN_00bd73b0 */

undefined4 * __thiscall FUN_00bd73b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 in_stack_0000003c;
  undefined4 in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  int *in_stack_00000050;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined auStack_9c [24];
  undefined auStack_84 [24];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined auStack_54 [24];
  undefined auStack_3c [24];
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  piVar1 = in_stack_00000050;
  uVar3 = in_stack_0000004c;
  puStack_c = &LAB_018006ca;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000050 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000050[2] = in_stack_00000050[2] + 1;
    UNLOCK();
  }
  puStack_14 = &uStack_a4;
  uStack_8 = 2;
  uStack_7 = 0;
  uStack_a4 = param_2;
  uStack_a0 = param_3;
  FUN_0054ef60(&stack0x0000000c);
  uStack_8 = 3;
  FUN_0054ef60(&stack0x00000024);
  uStack_6c = in_stack_0000003c;
  uStack_68 = in_stack_00000040;
  uStack_64 = in_stack_00000044;
  uStack_60 = in_stack_00000048;
  puStack_14 = &uStack_5c;
  uStack_8 = 5;
  uStack_5c = uStack_a4;
  uStack_58 = uStack_a0;
  FUN_0054ef60(auStack_9c);
  uStack_8 = 6;
  FUN_0054ef60(auStack_84);
  uStack_24 = uStack_6c;
  uStack_20 = uStack_68;
  uStack_1c = uStack_64;
  uStack_18 = uStack_60;
  *param_1 = uStack_5c;
  param_1[1] = uStack_58;
  uStack_8 = 7;
  puStack_14 = param_1;
  FUN_0054ef60(auStack_54);
  _uStack_8 = CONCAT31(uStack_7,8);
  FUN_0054ef60(auStack_3c);
  param_1[0xe] = uStack_24;
  param_1[0xf] = uStack_20;
  param_1[0x10] = uStack_1c;
  param_1[0x11] = uStack_18;
  FUN_00651cc0();
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar1[2] = piVar1[2] + 1;
    UNLOCK();
  }
  param_1[0x12] = uVar3;
  param_1[0x13] = piVar1;
  FUN_00651cc0();
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_00651cc0();
  if (in_stack_00000050 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000050 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*in_stack_00000050 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26430 ; VA 0x00bd7560 ; FUN_00bd7560 */

undefined4 * __thiscall
FUN_00bd7560(undefined4 *param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000020;
  int aiStack_34 [5];
  uint uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01800708;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60(&param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_1c = param_2;
  piStack_18 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 2;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_0054ef60(aiStack_34);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (0xf < uStack_20) {
    uVar3 = uStack_20 + 1;
    iVar2 = aiStack_34[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_34[0] + -4);
      uVar3 = uStack_20 + 0x24;
      if (0x1f < (aiStack_34[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    uVar3 = in_stack_00000020 + 1;
    iVar2 = param_4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_4 + -4);
      uVar3 = in_stack_00000020 + 0x24;
      if (0x1f < (param_4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26431 ; VA 0x00bd76b0 ; FUN_00bd76b0 */

uint * __thiscall
FUN_00bd76b0(uint *param_1,uint param_2,undefined4 param_3,uint param_4,uint param_5,uint param_6,
            uint param_7,undefined8 param_8,uint param_9,int *param_10)

{
  int iVar1;
  uint uStack_34;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined8 uStack_1c;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01800738;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_34 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_2 != 0) {
    uStack_34 = param_2;
    if ((param_2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_2c,0);
    }
    else {
      uStack_2c = param_4;
      uStack_28 = param_5;
      uStack_24 = param_6;
      uStack_20 = param_7;
      uStack_1c = param_8;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  *param_1 = 0;
  if (uStack_34 != 0) {
    *param_1 = uStack_34;
    if ((uStack_34 & 1) == 0) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,param_1 + 2,0);
    }
    else {
      param_1[2] = uStack_2c;
      param_1[3] = uStack_28;
      param_1[4] = uStack_24;
      param_1[5] = uStack_20;
      *(undefined8 *)(param_1 + 6) = uStack_1c;
    }
  }
  uStack_8._0_1_ = 3;
  if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
     (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
  }
  param_1[8] = 0;
  param_1[9] = 0;
  if (param_10 != (int *)0x0) {
    LOCK();
    param_10[2] = param_10[2] + 1;
    UNLOCK();
  }
  param_1[8] = param_9;
  param_1[9] = (uint)param_10;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&param_4,&param_4,2);
  }
  if (param_10 != (int *)0x0) {
    LOCK();
    iVar1 = param_10[2] + -1;
    param_10[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*param_10 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26432 ; VA 0x00bd7810 ; FUN_00bd7810 */

undefined4 __thiscall
FUN_00bd7810(undefined4 param_1,uint param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined8 param_8,
            undefined4 *param_9,int *param_10)

{
  int iVar1;
  int *piVar2;
  undefined4 **ppuVar3;
  uint *puVar4;
  uint auStack_70 [2];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined4 *puStack_50;
  int *piStack_4c;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  undefined4 *puStack_20;
  int *piStack_1c;
  undefined *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  piVar2 = param_10;
  puStack_c = &LAB_01800780;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_10 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_10[2] = param_10[2] + 1;
    UNLOCK();
  }
  puStack_14 = param_9;
  puStack_20 = param_9;
  piStack_1c = param_10;
  uStack_8 = 2;
  uStack_7 = 0;
  uStack_40 = 0;
  puStack_50 = param_9;
  if (param_2 != 0) {
    uStack_40 = param_2;
    if ((param_2 & 1) == 0) {
      puStack_50 = &uStack_38;
      piStack_4c = (int *)0x0;
      uStack_58 = CONCAT44(&param_4,0xbd7891);
      (**(code **)(param_2 & 0xfffffffe))();
      puStack_50 = puStack_14;
    }
    else {
      uStack_38 = param_4;
      uStack_34 = param_5;
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
    }
  }
  puStack_18 = (undefined *)&puStack_50;
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar2[2] = piVar2[2] + 1;
    UNLOCK();
  }
  piStack_4c = piVar2;
  puStack_14 = auStack_70;
  uStack_8 = 5;
  auStack_70[0] = 0;
  ppuVar3 = &puStack_50;
  puVar4 = auStack_70;
  if (uStack_40 != 0) {
    auStack_70[0] = uStack_40;
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_68,0);
      ppuVar3 = (undefined4 **)puStack_18;
      puVar4 = puStack_14;
    }
    else {
      uStack_68 = uStack_38;
      uStack_64 = uStack_34;
      uStack_60 = uStack_30;
      uStack_5c = uStack_2c;
      uStack_58 = uStack_28;
      ppuVar3 = &puStack_50;
      puVar4 = auStack_70;
    }
  }
  puStack_14 = puVar4;
  puStack_18 = (undefined *)ppuVar3;
  uStack_8 = 4;
  FUN_00bd76b0();
  _uStack_8 = CONCAT31(uStack_7,6);
  if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
     (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
    puStack_50 = &uStack_38;
    piStack_4c = (int *)0x2;
    uStack_58 = CONCAT44(puStack_50,0xbd7931);
    (**(code **)(uStack_40 & 0xfffffffe))();
  }
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar1 = piVar2[2] + -1;
    piVar2[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      piStack_4c = (int *)0xbd7950;
      (**(code **)(*piVar2 + 4))();
    }
  }
  _uStack_8 = CONCAT31(uStack_7,7);
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    puStack_50 = &param_4;
    piStack_4c = (int *)0x2;
    uStack_58 = CONCAT44(puStack_50,0xbd7971);
    (**(code **)(param_2 & 0xfffffffe))();
  }
  if (param_10 != (int *)0x0) {
    LOCK();
    iVar1 = param_10[2] + -1;
    param_10[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      piStack_4c = (int *)0xbd7991;
      (**(code **)(*param_10 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26433 ; VA 0x00bd79b0 ; FUN_00bd79b0 */

undefined4 * __fastcall FUN_00bd79b0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined uVar5;
  char cVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  uint uVar9;
  uint uVar10;
  undefined4 *puVar11;
  uint auStack_44 [2];
  code *pcStack_3c;
  undefined4 uStack_38;
  undefined4 *puStack_34;
  uint uStack_30;
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01800914;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::LogService,class_RBX::ServiceInstance>::vftable;
  uVar7 = FUN_00bd5c00();
  param_1[3] = uVar7;
  *param_1 = RBX::LogService::vftable;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  puStack_20 = param_1 + 0x27;
  *(undefined *)(param_1 + 0x26) = 0;
  *puStack_20 = 0;
  puStack_24 = param_1 + 0x28;
  *puStack_24 = 0;
  uVar7 = DAT_01d67e70;
  uStack_8._0_1_ = 0xc;
  uStack_8._1_3_ = 0;
  param_1[0x2d] = 0;
  uVar8 = FUN_00bd8a90(0);
  puVar3 = puStack_14;
  param_1[0x29] = uVar8;
  param_1[0x2a] = uVar8;
  param_1[0x2c] = uVar8;
  param_1[0x2b] = uVar8;
  param_1[0x2f] = uVar7;
  param_1[0x30] = 0;
  puStack_14[0x31] = 0;
  puStack_14[0x32] = 0;
  puStack_14[0x33] = 0;
  puVar11 = puStack_14 + 0x34;
  uStack_8._0_1_ = 0xf;
  *puVar11 = 0;
  puStack_14[0x35] = 0;
  puStack_18 = puVar11;
  uVar7 = FUN_005e9aa0(0,0);
  *puVar11 = uVar7;
  uVar7 = DAT_01d67e90;
  uStack_8._0_1_ = 0x10;
  puVar3[0x3a] = 0;
  uVar8 = FUN_00bd8b60(0);
  puVar4 = puStack_14;
  puVar3[0x36] = uVar8;
  puVar3[0x37] = uVar8;
  puVar3[0x39] = uVar8;
  puVar3[0x38] = uVar8;
  puVar3[0x3c] = uVar7;
  puVar3[0x3d] = 0;
  puVar11 = puStack_14 + 0x3e;
  uStack_8._0_1_ = 0x11;
  *puVar11 = 0;
  puStack_14[0x3f] = 0;
  puStack_18 = puVar11;
  uVar7 = FUN_005e9aa0(0,0);
  *puVar11 = uVar7;
  puVar4[0x40] = 0;
  puVar4[0x41] = 0;
  puVar4[0x42] = 0;
  puVar11 = puVar4 + 0x43;
  uStack_8._0_1_ = 0x15;
  *puVar11 = 0;
  puVar4[0x44] = 0;
  puVar4[0x45] = 0;
  puStack_18 = puVar11;
  uVar7 = FUN_005e9aa0(0,0);
  puVar4[0x44] = uVar7;
  puVar4[0x46] = 0;
  puVar4[0x47] = 0;
  puVar4[0x48] = 0;
  uStack_8._0_1_ = 0x17;
  *puVar11 = 0x3f800000;
  FUN_005cb500(8);
  puVar11 = puStack_14;
  uStack_8._0_1_ = 0x18;
  *(undefined *)(puStack_14 + 0x4b) = 0;
  puStack_34 = (undefined4 *)0x0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  FUN_005542c0("LogService",10);
  uStack_8._0_1_ = 0x19;
  FUN_008a6520(auStack_44);
  uStack_8._0_1_ = 0x18;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x18;
  if (0xf < uStack_30) {
    uVar10 = uStack_30 + 1;
    uVar9 = auStack_44[0];
    if (0xfff < uVar10) {
      uVar9 = *(uint *)(auStack_44[0] - 4);
      uVar10 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar9) - 4) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar10);
  }
  pcStack_3c = FUN_00bdda80;
  uStack_38 = 0;
  puStack_34 = puVar11;
  uStack_8._0_1_ = 0x1a;
  uVar7 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 0x1b;
  puStack_28 = (undefined4 *)uVar7;
  puStack_2c = (undefined4 *)FUN_01674e20(0x28);
  if (puStack_2c == (undefined4 *)0x0) {
    puVar11 = (undefined4 *)0x0;
  }
  else {
    *puStack_2c = 0;
    puStack_2c[1] = 1;
    puStack_2c[2] = FUN_00838650;
    puStack_2c[3] = _guard_check_icall;
    puStack_2c[4] = 0;
    puStack_2c[5] = &DAT_01ede3d4;
    puStack_2c[6] = pcStack_3c;
    puStack_2c[7] = uStack_38;
    puStack_2c[8] = puStack_34;
    puStack_2c[9] = uStack_30;
    puVar11 = puStack_2c;
  }
  FUN_016797d0(puVar11);
  if (puVar11 != (undefined4 *)0x0) {
    LOCK();
    puVar11[1] = puVar11[1] + 1;
    UNLOCK();
  }
  uStack_1c = 1;
  uStack_8._0_1_ = 0x1c;
  puStack_18 = puVar11;
  FUN_01675290(uVar7);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x1a);
  cVar6 = FUN_01679300(&puStack_18);
  if (cVar6 != '\0') {
    FUN_01679490();
    FUN_016791c0(&puStack_18);
  }
  uStack_1c = 0;
  uStack_8._0_1_ = 0x18;
  if (puStack_18 != (undefined4 *)0x0) {
    piVar1 = puStack_18 + 1;
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(puStack_18);
    }
  }
  puStack_20 = (undefined4 *)thunk_FUN_014d3f00();
  pcStack_3c = FUN_00bdd7c0;
  uStack_38 = 0;
  puStack_34 = puStack_14;
  uStack_8._0_1_ = 0x1d;
  uVar7 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 0x1e;
  puStack_2c = (undefined4 *)uVar7;
  puStack_28 = (undefined4 *)FUN_01674e20(0x28);
  if (puStack_28 == (undefined4 *)0x0) {
    puVar11 = (undefined4 *)0x0;
  }
  else {
    *puStack_28 = 0;
    puStack_28[1] = 1;
    puStack_28[2] = FUN_00838650;
    puStack_28[3] = _guard_check_icall;
    puStack_28[4] = 0;
    puStack_28[5] = puStack_20;
    puStack_28[6] = pcStack_3c;
    puStack_28[7] = uStack_38;
    puStack_28[8] = puStack_34;
    puStack_28[9] = uStack_30;
    puVar11 = puStack_28;
  }
  FUN_016797d0(puVar11);
  if (puVar11 != (undefined4 *)0x0) {
    LOCK();
    puVar11[1] = puVar11[1] + 1;
    UNLOCK();
  }
  uStack_1c = 2;
  uStack_8._0_1_ = 0x1f;
  puStack_18 = puVar11;
  FUN_01675290(uVar7);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x1d);
  cVar6 = FUN_01679300(&puStack_18);
  if (cVar6 != '\0') {
    FUN_01679490();
    FUN_016791c0(&puStack_18);
  }
  if (puStack_18 != (undefined4 *)0x0) {
    piVar1 = puStack_18 + 1;
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(puStack_18);
    }
  }
  ExceptionList = pvStack_10;
  return puStack_14;
}



/* FUNCTION 26434 ; VA 0x00bd7e80 ; FUN_00bd7e80 */

undefined4 * __thiscall FUN_00bd7e80(undefined4 *param_1,undefined4 *param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180065b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  FUN_0054ef60(param_2 + 2);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 8);
  param_1[0xe] = param_2[0xe];
  param_1[0xf] = param_2[0xf];
  param_1[0x10] = param_2[0x10];
  param_1[0x11] = param_2[0x11];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26435 ; VA 0x00bd7f00 ; FUN_00bd7f00 */

code * __fastcall FUN_00bd7f00(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  code *pcVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  pcVar6 = *(code **)(param_1 + 0x10);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (pcVar6 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      ExceptionList = &pvStack_10;
      if (pcVar6 != (code *)0x0) {
        ExceptionList = &pvStack_10;
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x18,param_1 + 0x18,2);
      }
    }
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  piVar5 = *(int **)(param_1 + 0xc);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 2);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
    }
  }
  piVar5 = *(int **)(param_1 + 4);
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar2 = piVar5 + 2;
    iVar4 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 26436 ; VA 0x00bd7f90 ; FUN_00bd7f90 */

void __fastcall FUN_00bd7f90(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::LogService>::vftable;
  uVar1 = FUN_00bd5c00(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26437 ; VA 0x00bd7fd0 ; FUN_00bd7fd0 */

void __fastcall FUN_00bd7fd0(int param_1)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 0x54);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_00bd8160();
  return;
}



/* FUNCTION 26438 ; VA 0x00bd8000 ; FUN_00bd8000 */

void __fastcall FUN_00bd8000(int param_1)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 0x54);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_00651cc0();
  return;
}



/* FUNCTION 26439 ; VA 0x00bd8030 ; FUN_00bd8030 */

void __fastcall FUN_00bd8030(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(param_1 + 0x2c);
  ExceptionList = &pvStack_10;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[2] + -1;
    ExceptionList = &pvStack_10;
    piVar1[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  uVar2 = *(uint *)(param_1 + 8);
  uStack_8 = 0;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x10,param_1 + 0x10,2);
      }
    }
    *(undefined4 *)(param_1 + 8) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26440 ; VA 0x00bd80a0 ; thunk_FUN_00bd96e0 */

void __fastcall thunk_FUN_00bd96e0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  uVar2 = 0;
  if (param_1[4] != 0) {
    do {
      FUN_00651cc0();
      iVar1 = param_1[2];
      uVar2 = uVar2 + 1;
      param_1[2] = iVar1 + 0x48;
      if (iVar1 + 0x48 == param_1[1]) {
        param_1[2] = *param_1;
      }
    } while (uVar2 < (uint)param_1[4]);
  }
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[1] - iVar1) / 0x48) * 0x48;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  return;
}



/* FUNCTION 26441 ; VA 0x00bd80b0 ; thunk_FUN_00bd9760 */

void __fastcall thunk_FUN_00bd9760(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar4 = 0;
  if (param_1[4] != 0) {
    iVar2 = param_1[2];
    do {
      piVar1 = *(int **)(iVar2 + 4);
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      uVar4 = uVar4 + 1;
      iVar2 = param_1[2] + 8;
      param_1[2] = iVar2;
      if (iVar2 == param_1[1]) {
        iVar2 = *param_1;
        param_1[2] = iVar2;
      }
    } while (uVar4 < (uint)param_1[4]);
  }
  iVar2 = *param_1;
  if (iVar2 != 0) {
    uVar4 = param_1[1] - iVar2 & 0xfffffff8;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  return;
}



/* FUNCTION 26442 ; VA 0x00bd80c0 ; FUN_00bd80c0 */

void __fastcall FUN_00bd80c0(int param_1)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 0x4c);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_00bd8160();
  return;
}



/* FUNCTION 26443 ; VA 0x00bd80f0 ; FUN_00bd80f0 */

void __fastcall FUN_00bd80f0(int param_1)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 0x4c);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_00651cc0();
  return;
}



/* FUNCTION 26444 ; VA 0x00bd8120 ; FUN_00bd8120 */

void __fastcall FUN_00bd8120(undefined4 *param_1)

{
  FUN_00bd8c30();
  FUN_01674ea0(*param_1,0x10);
  return;
}



/* FUNCTION 26445 ; VA 0x00bd8140 ; thunk_FUN_00bd8160 */

void __fastcall thunk_FUN_00bd8160(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x44);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x30);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00bd81e9;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined4 *)(param_1 + 0x44) = 0xf;
  *(undefined *)(param_1 + 0x30) = 0;
  uVar1 = *(uint *)(param_1 + 0x2c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x18);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00bd81e9:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0xf;
  *(undefined *)(param_1 + 0x18) = 0;
  return;
}



/* FUNCTION 26446 ; VA 0x00bd8150 ; thunk_FUN_00651cc0 */

void __fastcall thunk_FUN_00651cc0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x34);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x20);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00651d49;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0xf;
  *(undefined *)(param_1 + 0x20) = 0;
  uVar1 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00651d49:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  return;
}



/* FUNCTION 26447 ; VA 0x00bd8160 ; FUN_00bd8160 */

void __fastcall FUN_00bd8160(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x44);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x30);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00bd81e9;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined4 *)(param_1 + 0x44) = 0xf;
  *(undefined *)(param_1 + 0x30) = 0;
  uVar1 = *(uint *)(param_1 + 0x2c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x18);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00bd81e9:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0xf;
  *(undefined *)(param_1 + 0x18) = 0;
  return;
}



/* FUNCTION 26448 ; VA 0x00bd81f0 ; FUN_00bd81f0 */

void __fastcall FUN_00bd81f0(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd050;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005e61c0();
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x108);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x104);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 2;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x100);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_00bd8c30();
  FUN_01674ea0(*(undefined4 *)(param_1 + 0xf8),0x10);
  FUN_00bd9760();
  FUN_00bd8c30();
  FUN_01674ea0(*(undefined4 *)(param_1 + 0xd0),0x10);
  piVar1 = *(int **)(param_1 + 0xcc);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[2] + -1;
    piVar1[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  uStack_8 = 3;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0xc4);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_00bd96e0();
  uStack_8 = 4;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0xa0);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 5;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x9c);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26449 ; VA 0x00bd8470 ; FUN_00bd8470 */

int __thiscall FUN_00bd8470(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  byte ***pppbVar4;
  int iVar5;
  int iVar6;
  char *pcVar7;
  byte *****pppppbVar8;
  byte *pbVar9;
  undefined auStack_b8 [28];
  undefined4 uStack_9c;
  int *piStack_98;
  undefined4 uStack_94;
  int iStack_90;
  undefined4 uStack_7c;
  undefined4 *puStack_78;
  undefined4 uStack_74;
  byte ****ppppbStack_70;
  byte ****ppppbStack_6c;
  byte ****appppbStack_5c [4];
  undefined4 uStack_4c;
  uint uStack_48;
  byte ****appppbStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  byte ***pppbStack_24;
  int *piStack_20;
  int aiStack_1c [2];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01800940;
  pvStack_10 = ExceptionList;
  ppppbStack_6c = (byte ****)&uStack_2c;
  ppppbStack_70 = (byte ****)0xbd8499;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  pppbStack_24 = (byte ***)0x0;
  piStack_20 = (int *)0x0;
  uStack_4c = 0;
  uStack_48 = 0xf;
  appppbStack_5c[0] = (byte ****)((uint)appppbStack_5c[0] & 0xffffff00);
  ppppbStack_6c = (byte ****)appppbStack_5c;
  uStack_8 = 2;
  ppppbStack_70 = &pppbStack_24;
  puStack_78 = (undefined4 *)(param_3 + 0x40);
  uStack_74 = 0;
  uStack_7c = 0xbd84da;
  iVar5 = FUN_00e57b80();
  pppbVar4 = pppbStack_24;
  if ((char)iVar5 != '\0') {
    ppppbStack_6c = (byte ****)0x1e;
    ppppbStack_70 = (byte ****)0x195e698;
    uStack_34 = 0;
    uStack_30 = 0xf;
    appppbStack_44[0] = (byte ****)((uint)appppbStack_44[0] & 0xffffff00);
    uStack_74 = 0xbd8509;
    FUN_005542c0();
    pbVar9 = (byte *)((int)pppbVar4 + *(byte *)pppbVar4 + 1);
    ppppbStack_6c = (byte ****)appppbStack_44;
    uStack_74 = 0xbd851b;
    ppppbStack_70 = (byte ****)pbVar9;
    uStack_74 = FUN_0055c740();
    ppppbStack_70 = (byte ****)appppbStack_44;
    ppppbStack_6c = (byte ****)(-(uint)(pbVar9 != (byte *)0x0) & (uint)(pbVar9 + 1));
    puStack_78 = &param_3;
    uStack_7c = 0xbd8538;
    iVar5 = FUN_00562fc0();
    if (0xf < uStack_30) {
      ppppbStack_6c = (byte ****)(uStack_30 + 1);
      pppppbVar8 = (byte *****)appppbStack_44[0];
      if (0xfff < ppppbStack_6c) {
        pppppbVar8 = (byte *****)appppbStack_44[0][-1];
        ppppbStack_6c = (byte ****)(uStack_30 + 0x24);
        if (0x1f < (uint)((int)appppbStack_44[0] + (-4 - (int)pppppbVar8))) {
                    /* WARNING: Subroutine does not return */
          ppppbStack_6c = (byte ****)0xbd8705;
          FUN_017167a3();
        }
      }
      uStack_74 = 0xbd8569;
      ppppbStack_70 = (byte ****)pppppbVar8;
      iVar5 = FUN_01674ea0();
    }
    iVar3 = param_3;
    uStack_34 = 0;
    uStack_30 = 0xf;
    appppbStack_44[0] = (byte ****)((uint)appppbStack_44[0] & 0xffffff00);
    if (param_3 != 0) {
      iVar6 = *(int *)(param_3 + 0x20);
      ppppbStack_6c = (byte ****)0xbd8591;
      iVar5 = FUN_0088daf0();
      if (iVar6 == iVar5) {
        iVar5 = *(int *)(iVar3 + 0x20);
        ppppbStack_6c = (byte ****)0xbd85a1;
        iVar6 = FUN_0088daf0();
        if (iVar5 != iVar6) {
          ppppbStack_6c = (byte ****)0x18c072c;
                    /* WARNING: Subroutine does not return */
          ppppbStack_70 = (byte ****)0xbd870f;
          FUN_016757c0();
        }
        pcVar7 = (char *)(iVar3 + 0x28);
        if (*(int *)(iVar3 + 0x24) == 0) {
          pcVar7 = (char *)0x0;
        }
        if (*pcVar7 == '\0') {
          ppppbStack_6c = (byte ****)aiStack_1c;
          ppppbStack_70 = (byte ****)0xbd8621;
          FUN_00587490();
          uStack_8 = CONCAT31(uStack_8._1_3_,3);
          if (aiStack_1c[0] != 0) {
            ppppbStack_6c = (byte ****)0x0;
            iStack_90 = param_1 + 0x10;
            uStack_94 = 0xbd863b;
            FUN_0054f510();
            piStack_98 = aiStack_1c;
            uStack_9c = 0xbd8649;
            FUN_00557fc0();
            piStack_98 = (int *)0xbd8651;
            FUN_00bdf0f0();
          }
          ppppbStack_6c = (byte ****)0xbd8659;
          iVar5 = FUN_00550b30();
        }
        else {
          ppppbStack_6c = (byte ****)uStack_2c;
          ppppbStack_70 = (byte ****)0xbd85c0;
          iVar5 = FUN_008f7870();
          iStack_14 = iVar5;
          if (iVar5 != 0) {
            ppppbStack_6c = (byte ****)0x1;
            param_3 = CONCAT31(param_3._1_3_,DAT_01ef68fc);
            iStack_90 = 0;
            FUN_0054f510(param_1 + 0x10);
            FUN_00ae2be0(auStack_b8,FUN_00ae6a70,param_3);
            FUN_00ae2040();
            iStack_90 = 0xbd8613;
            iVar5 = FUN_0090ca30();
          }
        }
      }
    }
  }
  if (0xf < uStack_48) {
    ppppbStack_6c = (byte ****)(uStack_48 + 1);
    pppppbVar8 = (byte *****)appppbStack_5c[0];
    if (0xfff < ppppbStack_6c) {
      pppppbVar8 = (byte *****)appppbStack_5c[0][-1];
      ppppbStack_6c = (byte ****)(uStack_48 + 0x24);
      if (0x1f < (uint)((int)appppbStack_5c[0] + (-4 - (int)pppppbVar8))) {
                    /* WARNING: Subroutine does not return */
        ppppbStack_6c = (byte ****)&UNK_00bd8714;
        FUN_017167a3();
      }
    }
    uStack_74 = 0xbd868a;
    ppppbStack_70 = (byte ****)pppppbVar8;
    iVar5 = FUN_01674ea0();
  }
  piVar2 = piStack_20;
  uStack_4c = 0;
  uStack_48 = 0xf;
  appppbStack_5c[0] = (byte ****)((uint)appppbStack_5c[0] & 0xffffff00);
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_20 + 1;
    iVar3 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      ppppbStack_6c = (byte ****)0xbd86b8;
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        ppppbStack_6c = (byte ****)0xbd86c8;
        iVar5 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_28 + 1;
    iVar3 = *piVar2;
    iVar5 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      ppppbStack_6c = (byte ****)0xbd86de;
      iVar5 = (**(code **)*piStack_28)();
      LOCK();
      piVar2 = piStack_28 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        ppppbStack_6c = (byte ****)0xbd86ed;
        iVar5 = (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 26450 ; VA 0x00bd8720 ; FUN_00bd8720 */

/* WARNING: Removing unreachable block (ram,0x00bd87be) */
/* WARNING: Removing unreachable block (ram,0x00bd87ce) */
/* WARNING: Removing unreachable block (ram,0x00bd87d4) */

void __thiscall FUN_00bd8720(int *param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01800968;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_01675290(uVar1);
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
        ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26451 ; VA 0x00bd8825 ; Catch@00bd8825 */

undefined * Catch_00bd8825(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00bd8836;
}



/* FUNCTION 26452 ; VA 0x00bd8850 ; FUN_00bd8850 */

int * __thiscall FUN_00bd8850(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  if (param_2 < 1) {
    if (param_2 < 0) {
      iVar5 = -param_2;
      if (iVar5 != 0 && 0 >= param_2) {
        iVar4 = param_1[1];
        if (iVar4 == 0) {
          iVar4 = ((int *)*param_1)[3];
        }
        iVar2 = *(int *)*param_1;
        iVar3 = (iVar4 - iVar2) / 0x48;
        if (-iVar3 != param_2 && iVar3 <= iVar5) {
          iVar5 = iVar5 - (*(int *)(*param_1 + 4) - iVar2) / 0x48;
        }
        param_1[1] = iVar4 + iVar5 * -0x48;
        return param_1;
      }
      if (0 < param_2) {
        FUN_00bd8850(param_2);
      }
    }
  }
  else {
    piVar1 = (int *)*param_1;
    if ((piVar1[1] - param_1[1]) / 0x48 <= param_2) {
      param_2 = param_2 - (piVar1[1] - *piVar1) / 0x48;
    }
    iVar5 = param_1[1] + param_2 * 0x48;
    param_1[1] = iVar5;
    if (iVar5 == piVar1[3]) {
      param_1[1] = 0;
      return param_1;
    }
  }
  return param_1;
}



/* FUNCTION 26453 ; VA 0x00bd8930 ; FUN_00bd8930 */

int * __thiscall FUN_00bd8930(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  if (param_2 < 1) {
    if (param_2 < 0) {
      iVar4 = -param_2;
      if (iVar4 != 0 && 0 >= param_2) {
        iVar3 = param_1[1];
        piVar1 = (int *)*param_1;
        if (iVar3 == 0) {
          iVar3 = piVar1[3];
        }
        iVar2 = iVar3 - *piVar1 >> 3;
        if (-iVar2 != param_2 && iVar2 <= iVar4) {
          iVar4 = iVar4 - (piVar1[1] - *piVar1 >> 3);
        }
        param_1[1] = iVar3 + iVar4 * -8;
        return param_1;
      }
      if (0 < param_2) {
        FUN_00bd8930(param_2);
      }
    }
  }
  else {
    piVar1 = (int *)*param_1;
    if (piVar1[1] - param_1[1] >> 3 <= param_2) {
      param_2 = param_2 - (piVar1[1] - *piVar1 >> 3);
    }
    iVar4 = param_1[1] + param_2 * 8;
    param_1[1] = iVar4;
    if (iVar4 == piVar1[3]) {
      param_1[1] = 0;
      return param_1;
    }
  }
  return param_1;
}



/* FUNCTION 26454 ; VA 0x00bd89d0 ; FUN_00bd89d0 */

undefined4 __thiscall FUN_00bd89d0(undefined4 param_1,byte param_2)

{
  FUN_00bd81f0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x130);
  }
  return param_1;
}



/* FUNCTION 26455 ; VA 0x00bd8a00 ; FUN_00bd8a00 */

void __fastcall FUN_00bd8a00(int param_1)

{
  FUN_00bd5f70(param_1 + 8);
  return;
}



/* FUNCTION 26456 ; VA 0x00bd8a10 ; FUN_00bd8a10 */

void __thiscall FUN_00bd8a10(undefined4 param_1,char param_2)

{
  FUN_00bd7f00();
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0x38);
  }
  return;
}



/* FUNCTION 26457 ; VA 0x00bd8a40 ; FUN_00bd8a40 */

void FUN_00bd8a40(undefined4 *param_1,undefined4 param_2)

{
  FUN_00bd8470(*param_1,param_2);
  return;
}



/* FUNCTION 26458 ; VA 0x00bd8a60 ; FUN_00bd8a60 */

void __fastcall FUN_00bd8a60(int param_1)

{
  FUN_00bd57a0(param_1 + 8);
  return;
}



/* FUNCTION 26459 ; VA 0x00bd8a80 ; FUN_00bd8a80 */

TypeDescriptor * FUN_00bd8a80(void)

{
  return &<lambda_e4e29e8e84969e026d0d37436cf32e32>::RTTI_Type_Descriptor;
}



/* FUNCTION 26460 ; VA 0x00bd8a90 ; FUN_00bd8a90 */

uint FUN_00bd8a90(uint param_1)

{
  uint uVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01800c18;
  pvStack_10 = ExceptionList;
  if (param_1 < 0x38e38e4) {
    if (param_1 == 0) {
      return 0;
    }
    uVar4 = param_1 * 0x48;
    if (param_1 < 0x38e38e4) {
      if (uVar4 < 0x1000) {
        if (uVar4 == 0) {
          return 0;
        }
        ExceptionList = &pvStack_10;
        uVar4 = FUN_01674e20(uVar4);
        ExceptionList = pvStack_10;
        return uVar4;
      }
    }
    else {
      uVar4 = 0xffffffff;
    }
    uVar1 = uVar4 + 0x23;
    if (uVar1 <= uVar4) {
      uVar1 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar2 = FUN_01674e20(uVar1);
    if (iVar2 != 0) {
      uVar4 = iVar2 + 0x23U & 0xffffffe0;
      *(int *)(uVar4 - 4) = iVar2;
      ExceptionList = pvStack_10;
      return uVar4;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_005e07c0("circular_buffer");
    uStack_8 = 0;
    FUN_005dffd0(uVar3);
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 26461 ; VA 0x00bd8b60 ; FUN_00bd8b60 */

uint FUN_00bd8b60(uint param_1)

{
  uint uVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01800c18;
  pvStack_10 = ExceptionList;
  if (param_1 < 0x20000000) {
    if (param_1 == 0) {
      return 0;
    }
    uVar4 = param_1 * 8;
    if (param_1 < 0x20000000) {
      if (uVar4 < 0x1000) {
        if (uVar4 == 0) {
          return 0;
        }
        ExceptionList = &pvStack_10;
        uVar4 = FUN_01674e20(uVar4);
        ExceptionList = pvStack_10;
        return uVar4;
      }
    }
    else {
      uVar4 = 0xffffffff;
    }
    uVar1 = uVar4 + 0x23;
    if (uVar1 <= uVar4) {
      uVar1 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar2 = FUN_01674e20(uVar1);
    if (iVar2 != 0) {
      uVar4 = iVar2 + 0x23U & 0xffffffe0;
      *(int *)(uVar4 - 4) = iVar2;
      ExceptionList = pvStack_10;
      return uVar4;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_005e07c0("circular_buffer");
    uStack_8 = 0;
    FUN_005dffd0(uVar3);
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 26462 ; VA 0x00bd8c30 ; FUN_00bd8c30 */

void __fastcall FUN_00bd8c30(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  
  piVar1 = (int *)*param_1;
  piVar4 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar4 != (int *)*param_1) {
    do {
      piVar1 = (int *)piVar4[3];
      piVar2 = (int *)*piVar4;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar3 = piVar1[2] + -1;
        piVar1[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
      FUN_01674ea0(piVar4,0x10);
      piVar4 = piVar2;
    } while (piVar2 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 26463 ; VA 0x00bd8c80 ; FUN_00bd8c80 */

undefined4 * __thiscall
FUN_00bd8c80(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01800c61;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00bda790;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 26464 ; VA 0x00bd8e20 ; FUN_00bd8e20 */

undefined4 * __thiscall
FUN_00bd8e20(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01800ca1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00bda600;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 26465 ; VA 0x00bd8fd0 ; FUN_00bd8fd0 */

undefined4 * FUN_00bd8fd0(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  int iStack_30;
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01800cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_00587490(&iStack_30);
  iVar2 = iStack_30;
  uStack_8._0_1_ = 2;
  if (iStack_30 != 0) {
    puVar3 = (undefined4 *)FUN_00587490(&iStack_28);
    uStack_8._0_1_ = 3;
    if (iStack_28 != 0) {
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piStack_24[2] = piStack_24[2] + 1;
        UNLOCK();
      }
      iStack_20 = iStack_28;
      piStack_1c = piStack_24;
      iStack_14 = *(int *)(iVar2 + 0xf8);
      uStack_8._0_1_ = 4;
      puStack_18 = *(undefined4 **)(iStack_14 + 4);
      uVar4 = FUN_009ef7a0(iStack_14,puStack_18,&iStack_20);
      if (*(int *)(iStack_30 + 0xfc) == 0xffffffe) {
                    /* WARNING: Subroutine does not return */
        FUN_016ddcd9("list<T> too long");
      }
      *(int *)(iStack_30 + 0xfc) = *(int *)(iStack_30 + 0xfc) + 1;
      uStack_8._0_1_ = 3;
      *(undefined4 *)(iStack_14 + 4) = uVar4;
      *puStack_18 = uVar4;
      puVar3 = puStack_18;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piVar1 = piStack_1c + 2;
        iVar2 = *piVar1;
        puVar3 = (undefined4 *)*piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          puVar3 = (undefined4 *)(**(code **)(*piStack_1c + 4))();
        }
      }
      uVar6 = 0;
      if (*(int *)(iStack_30 + 0xe8) != 0) {
        do {
          if (piStack_24 != (int *)0x0) {
            LOCK();
            piStack_24[1] = piStack_24[1] + 1;
            UNLOCK();
          }
          uVar5 = uVar6;
          if (*(int *)(iStack_30 + 0xdc) - *(int *)(iStack_30 + 0xe0) >> 3 <= (int)uVar6) {
            uVar5 = uVar6 - (*(int *)(iStack_30 + 0xdc) - *(int *)(iStack_30 + 0xd8) >> 3);
          }
          puVar3 = (undefined4 *)(*(int *)(iStack_30 + 0xe0) + uVar5 * 8);
          if (puVar3[1] != 0) {
            LOCK();
            piVar1 = (int *)(puVar3[1] + 4);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
          }
          puVar3 = (undefined4 *)FUN_00bde650(*puVar3,puVar3[1],iStack_28,piStack_24);
          uVar6 = uVar6 + 1;
        } while (uVar6 < *(uint *)(iStack_30 + 0xe8));
      }
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_24 + 1;
      iVar2 = *piVar1;
      puVar3 = (undefined4 *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piStack_24 + 2;
        iVar2 = *piVar1;
        puVar3 = (undefined4 *)*piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          puVar3 = (undefined4 *)(**(code **)(*piStack_24 + 4))();
        }
      }
    }
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_2c + 1;
    iVar2 = *piVar1;
    puVar3 = (undefined4 *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piStack_2c + 2;
      iVar2 = *piVar1;
      puVar3 = (undefined4 *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        puVar3 = (undefined4 *)(**(code **)(*piStack_2c + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    puVar3 = (undefined4 *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puVar3 = (undefined4 *)(**(code **)(*param_2 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puVar3 = (undefined4 *)(**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return puVar3;
}



/* FUNCTION 26466 ; VA 0x00bd91d0 ; FUN_00bd91d0 */

int FUN_00bd91d0(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined uVar4;
  int iVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  uint uVar9;
  uint uVar10;
  int *piVar11;
  undefined8 uVar12;
  longlong lVar13;
  int aiStack_70 [5];
  uint uStack_5c;
  int aiStack_58 [5];
  uint uStack_44;
  int iStack_40;
  int *piStack_3c;
  int iStack_38;
  int *piStack_34;
  int iStack_30;
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined auStack_20 [4];
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01800d30;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00587490(&iStack_30);
  iVar6 = iStack_30;
  uStack_8._0_1_ = 2;
  piVar11 = piStack_2c;
  if (iStack_30 != 0) {
    iVar5 = FUN_00587490(&iStack_38);
    uStack_8._0_1_ = 3;
    piVar11 = piStack_2c;
    if (iStack_38 != 0) {
      puVar7 = *(undefined4 **)(iVar6 + 0xd0);
      piStack_14 = (int *)(iVar6 + 0xd0);
      puVar2 = (undefined4 *)*puVar7;
      uVar12 = FUN_00928340();
      while( true ) {
        uStack_18 = (undefined4)uVar12;
        puStack_1c = (undefined4 *)((ulonglong)uVar12 >> 0x20);
        if (puVar2 == puVar7) break;
        iVar5 = puVar2[3];
        iStack_28 = 0;
        piStack_24 = (int *)0x0;
        if (iVar5 != 0) {
          piVar11 = (int *)(iVar5 + 4);
          iVar5 = *(int *)(iVar5 + 4);
          while (iVar5 != 0) {
            LOCK();
            iVar6 = *piVar11;
            if (iVar5 == iVar6) {
              *piVar11 = iVar5 + 1;
              iVar6 = iVar5;
            }
            UNLOCK();
            if (iVar6 == iVar5) {
              iStack_28 = puVar2[2];
              piStack_24 = (int *)puVar2[3];
              break;
            }
            iVar5 = *piVar11;
          }
        }
        piVar3 = piStack_24;
        uStack_8._0_1_ = 4;
        if (iStack_28 != 0) {
          lVar13 = FUN_00928340();
          uVar12 = CONCAT44(puStack_1c,uStack_18);
          iVar5 = (int)lVar13;
          if (lVar13 == CONCAT44(puStack_1c,uStack_18)) {
            piVar11 = piStack_2c;
            if (piVar3 != (int *)0x0) {
              LOCK();
              piVar1 = piVar3 + 1;
              iVar6 = *piVar1;
              iVar5 = *piVar1;
              *piVar1 = iVar6 + -1;
              UNLOCK();
              if (iVar6 + -1 == 0) {
                (**(code **)*piVar3)();
                LOCK();
                piVar11 = piVar3 + 2;
                iVar6 = *piVar11;
                iVar5 = *piVar11;
                *piVar11 = iVar6 + -1;
                UNLOCK();
                piVar11 = piStack_2c;
                if (iVar6 + -1 == 0) {
                  iVar5 = (**(code **)(*piVar3 + 4))();
                  piVar11 = piStack_2c;
                }
              }
            }
            goto LAB_00bd939d;
          }
        }
        puStack_1c = (undefined4 *)((ulonglong)uVar12 >> 0x20);
        uStack_18 = (undefined4)uVar12;
        uStack_8._0_1_ = 3;
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar5 = piVar3[1] + -1;
          piVar3[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piVar3)();
            uVar12 = CONCAT44(puStack_1c,uStack_18);
            LOCK();
            iVar5 = piVar3[2] + -1;
            piVar3[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar3 + 4))();
              uVar12 = CONCAT44(puStack_1c,uStack_18);
            }
          }
        }
        puVar2 = (undefined4 *)*puVar2;
        iVar6 = iStack_30;
      }
      iVar5 = FUN_008f7870(iVar6);
      piVar11 = *(int **)(iVar5 + 0x43c);
      puVar7 = (undefined4 *)
               FUN_01675640(aiStack_58,&DAT_018bed48,*piVar11 - (int)piVar11,
                            piVar11[1] - (int)piVar11);
      uStack_8._0_1_ = 5;
      if (0xf < (uint)puVar7[5]) {
        puVar7 = (undefined4 *)*puVar7;
      }
      FUN_0087c450(&DAT_018c5f98,"SendingServerLogHistory",puVar7,0,0,0);
      uStack_8._0_1_ = 3;
      uVar4 = (undefined)uStack_8;
      uStack_8._0_1_ = 3;
      if (0xf < uStack_44) {
        uVar10 = uStack_44 + 1;
        iVar5 = aiStack_58[0];
        if (0xfff < uVar10) {
          iVar5 = *(int *)(aiStack_58[0] + -4);
          uVar10 = uStack_44 + 0x24;
          if (0x1f < (aiStack_58[0] - iVar5) - 4U) {
            uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar5,uVar10);
      }
      uVar12 = FUN_00928340();
      puVar7 = (undefined4 *)FUN_01675640(aiStack_70,&DAT_018bed48,uVar12);
      uStack_8._0_1_ = 6;
      if (0xf < (uint)puVar7[5]) {
        puVar7 = (undefined4 *)*puVar7;
      }
      FUN_0087c450(&DAT_018c5f98,"CreatorReadingServerLogs",puVar7,0,0,0);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      if (0xf < uStack_5c) {
        uVar10 = uStack_5c + 1;
        iVar5 = aiStack_70[0];
        if (0xfff < uVar10) {
          iVar5 = *(int *)(aiStack_70[0] + -4);
          uVar10 = uStack_5c + 0x24;
          if (0x1f < (aiStack_70[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar5,uVar10);
      }
      piVar11 = piStack_34;
      if (piStack_34 != (int *)0x0) {
        LOCK();
        piStack_34[2] = piStack_34[2] + 1;
        UNLOCK();
      }
      *(int *)(iVar6 + 200) = iStack_38;
      piVar3 = *(int **)(iVar6 + 0xcc);
      *(int **)(iVar6 + 0xcc) = piStack_34;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar5 = piVar3[2] + -1;
        piVar3[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
      if (piVar11 != (int *)0x0) {
        LOCK();
        piVar11[2] = piVar11[2] + 1;
        UNLOCK();
      }
      iStack_40 = iStack_38;
      piStack_3c = piVar11;
      uStack_8._0_1_ = 7;
      iVar5 = *piStack_14;
      puStack_1c = *(undefined4 **)(iVar5 + 4);
      uVar8 = FUN_009ef7a0(iVar5,puStack_1c,&iStack_40);
      if (piStack_14[1] == 0xffffffe) {
                    /* WARNING: Subroutine does not return */
        FUN_016ddcd9("list<T> too long");
      }
      uStack_8._0_1_ = 3;
      piStack_14[1] = piStack_14[1] + 1;
      *(undefined4 *)(iVar5 + 4) = uVar8;
      *puStack_1c = uVar8;
      if (piStack_3c != (int *)0x0) {
        LOCK();
        iVar5 = piStack_3c[2] + -1;
        piStack_3c[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_3c + 4))();
        }
      }
      iVar5 = FUN_00927d30(auStack_20);
      uVar10 = 0;
      piVar11 = piStack_2c;
      if (*(int *)(iVar6 + 0xb4) != 0) {
        do {
          uVar9 = uVar10;
          if ((*(int *)(iVar6 + 0xa8) - *(int *)(iVar6 + 0xac)) / 0x48 <= (int)uVar10) {
            uVar9 = uVar10 - (*(int *)(iVar6 + 0xa8) - *(int *)(iVar6 + 0xa4)) / 0x48;
          }
          iVar5 = *(int *)(iVar6 + 0xac);
          if (piStack_2c != (int *)0x0) {
            LOCK();
            piStack_2c[1] = piStack_2c[1] + 1;
            UNLOCK();
          }
          iVar5 = FUN_00bde880(iVar6,piStack_2c,iVar5 + uVar9 * 0x48,auStack_20);
          uVar10 = uVar10 + 1;
        } while (uVar10 < *(uint *)(iVar6 + 0xb4));
      }
    }
LAB_00bd939d:
    if (piStack_34 != (int *)0x0) {
      LOCK();
      piVar3 = piStack_34 + 1;
      iVar6 = *piVar3;
      iVar5 = *piVar3;
      *piVar3 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        piVar3 = piStack_34 + 2;
        iVar6 = *piVar3;
        iVar5 = *piVar3;
        *piVar3 = iVar6 + -1;
        UNLOCK();
        if (iVar6 + -1 == 0) {
          iVar5 = (**(code **)(*piStack_34 + 4))();
        }
      }
    }
  }
  if (piVar11 != (int *)0x0) {
    LOCK();
    piVar3 = piVar11 + 1;
    iVar6 = *piVar3;
    iVar5 = *piVar3;
    *piVar3 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      (**(code **)*piVar11)();
      LOCK();
      piVar3 = piVar11 + 2;
      iVar6 = *piVar3;
      iVar5 = *piVar3;
      *piVar3 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        iVar5 = (**(code **)(*piVar11 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar11 = param_2 + 2;
    iVar6 = *piVar11;
    iVar5 = *piVar11;
    *piVar11 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      iVar5 = (**(code **)(*param_2 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar11 = param_4 + 2;
    iVar6 = *piVar11;
    *piVar11 = *piVar11 + -1;
    UNLOCK();
    if (iVar6 == 1) {
      iVar5 = (**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 26467 ; VA 0x00bd9620 ; FUN_00bd9620 */

undefined4 * FUN_00bd9620(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00671d40(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 26468 ; VA 0x00bd9690 ; FUN_00bd9690 */

void FUN_00bd9690(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  if (param_1 != 0) {
    uVar2 = param_2 * 0x48;
    iVar1 = param_1;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  return;
}



/* FUNCTION 26469 ; VA 0x00bd96e0 ; FUN_00bd96e0 */

void __fastcall FUN_00bd96e0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  uVar2 = 0;
  if (param_1[4] != 0) {
    do {
      FUN_00651cc0();
      iVar1 = param_1[2];
      uVar2 = uVar2 + 1;
      param_1[2] = iVar1 + 0x48;
      if (iVar1 + 0x48 == param_1[1]) {
        param_1[2] = *param_1;
      }
    } while (uVar2 < (uint)param_1[4]);
  }
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[1] - iVar1) / 0x48) * 0x48;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  return;
}



/* FUNCTION 26470 ; VA 0x00bd9760 ; FUN_00bd9760 */

void __fastcall FUN_00bd9760(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar4 = 0;
  if (param_1[4] != 0) {
    iVar2 = param_1[2];
    do {
      piVar1 = *(int **)(iVar2 + 4);
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      uVar4 = uVar4 + 1;
      iVar2 = param_1[2] + 8;
      param_1[2] = iVar2;
      if (iVar2 == param_1[1]) {
        iVar2 = *param_1;
        param_1[2] = iVar2;
      }
    } while (uVar4 < (uint)param_1[4]);
  }
  iVar2 = *param_1;
  if (iVar2 != 0) {
    uVar4 = param_1[1] - iVar2 & 0xfffffff8;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  return;
}



/* FUNCTION 26471 ; VA 0x00bd97f0 ; FUN_00bd97f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00bd97f0(undefined4 param_1,undefined4 param_2,char *param_3)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  char *pcVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  int iVar8;
  char *pcVar9;
  int *piVar10;
  uint uVar11;
  uint uVar12;
  int *piVar13;
  uint in_stack_00000020;
  int *in_stack_00000050;
  undefined uVar14;
  undefined4 in_stack_ffffff3c;
  undefined4 in_stack_ffffff40;
  undefined4 in_stack_ffffff44;
  undefined4 uVar15;
  undefined4 uVar16;
  undefined4 uVar17;
  undefined auStack_68 [8];
  undefined auStack_60 [16];
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined auStack_48 [4];
  undefined auStack_44 [4];
  undefined *puStack_40;
  undefined uStack_3c;
  int *piStack_38;
  int *piStack_34;
  undefined auStack_30 [4];
  undefined *puStack_2c;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01800d7b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_20);
  iVar3 = iStack_20;
  uStack_8._0_1_ = 2;
  piVar10 = piStack_1c;
  if (iStack_20 != 0) {
    uStack_3c = *(undefined *)(iStack_20 + 0x98);
    puStack_40 = (undefined *)(iStack_20 + 0x98);
    *puStack_40 = 1;
    uStack_8._0_1_ = 3;
    puStack_2c = puStack_40;
    uStack_11 = uStack_3c;
    uVar4 = FUN_00bdb3d0(&param_3);
    if ((_DAT_01ef68cc & uVar4) != 0) {
      FUN_0151f6f0(0xffffffff,0,0);
      uStack_8._0_1_ = 4;
      pcVar5 = (char *)&param_3;
      if (0xf < in_stack_00000020) {
        pcVar5 = param_3;
      }
      FUN_0151f850(&DAT_018d4690,pcVar5);
      FUN_0151f9c0(&DAT_0195e5bc,uVar4);
      uVar15 = DAT_01ef68c8;
      uStack_50 = 0;
      uStack_4c = 0xf;
      auStack_60[0] = 0;
      FUN_005542c0("BadLog",6);
      uStack_8._0_1_ = 5;
      in_stack_ffffff44 = 0xbd98ee;
      FUN_01520d20(auStack_60,uVar15,0);
      FUN_005507b0();
      uStack_8._0_1_ = 3;
      FUN_0151f7f0();
    }
    pcVar5 = (char *)&param_3;
    if (0xf < in_stack_00000020) {
      pcVar5 = param_3;
    }
    uVar15 = 0;
    uVar16 = 0xf;
    uVar14 = 0;
    pcVar9 = pcVar5;
    do {
      cVar1 = *pcVar9;
      pcVar9 = pcVar9 + 1;
    } while (cVar1 != '\0');
    uVar17 = param_1;
    FUN_005542c0(pcVar5,(int)pcVar9 - (int)(pcVar5 + 1));
    FUN_00bdb6e0(iVar3,uVar14,in_stack_ffffff3c,in_stack_ffffff40,in_stack_ffffff44,uVar15,uVar16,
                 uVar17);
    uVar4 = DAT_01d67e70;
    if (DAT_01d67e70 != *(uint *)(iVar3 + 0xbc)) {
      uVar11 = *(uint *)(iVar3 + 0xb4);
      piVar10 = (int *)(iVar3 + 0xa4);
      *(uint *)(iVar3 + 0xbc) = DAT_01d67e70;
      *(undefined4 *)(iVar3 + 0xc0) = 0;
      if (uVar4 < uVar11) {
        if (uVar11 == 0) {
          piStack_34 = (int *)0x0;
        }
        else {
          piStack_34 = *(int **)(iVar3 + 0xac);
        }
        piStack_38 = piVar10;
        piStack_18 = piStack_34;
        puVar6 = (undefined4 *)FUN_00bd8850(uVar11 - uVar4);
        FUN_00bdec60(auStack_68,piVar10,piStack_18,*puVar6,puVar6[1]);
      }
      uVar4 = *(uint *)(iVar3 + 0xc0);
      uVar11 = (*(int *)(iVar3 + 0xa8) - *piVar10) / 0x48;
      if (uVar4 <= uVar11) {
        uVar12 = uVar11;
        if (*(uint *)(iVar3 + 0xb4) <= uVar11 / 3) {
          do {
            uVar11 = uVar11 >> 1;
            uVar12 = uVar4;
            if (uVar11 <= uVar4) break;
            uVar12 = uVar11;
          } while (*(uint *)(iVar3 + 0xb4) <= uVar11 / 3);
        }
        uVar11 = uVar12 * 2;
        if (uVar12 / 5 + *(int *)(iVar3 + 0xb4) < uVar12) {
          uVar11 = uVar12;
        }
        uVar4 = *(uint *)(iVar3 + 0xbc);
        if (uVar11 <= *(uint *)(iVar3 + 0xbc)) {
          uVar4 = uVar11;
        }
      }
      FUN_00bdf270(uVar4);
    }
    FUN_00bde4f0(&param_1);
    puVar6 = *(undefined4 **)(iVar3 + 0xd0);
    piStack_18 = (int *)(iVar3 + 0xd0);
    puVar7 = (undefined4 *)FUN_00bd6d50(auStack_44,*puVar6,puVar6,FUN_00bde340);
    FUN_00bda9f0(auStack_30,*puVar7,puVar6);
    piVar2 = *(int **)(iVar3 + 0xd0);
    piVar13 = (int *)*piVar2;
    piVar10 = piStack_1c;
    if (piVar13 == piVar2) {
      *puStack_2c = uStack_11;
    }
    else {
      do {
        iVar3 = piVar13[3];
        iStack_28 = 0;
        piStack_24 = (int *)0x0;
        if (iVar3 != 0) {
          piVar2 = (int *)(iVar3 + 4);
          iVar3 = *(int *)(iVar3 + 4);
          while (piVar10 = piStack_1c, iVar3 != 0) {
            LOCK();
            iVar8 = *piVar2;
            if (iVar3 == iVar8) {
              *piVar2 = iVar3 + 1;
              iVar8 = iVar3;
            }
            UNLOCK();
            if (iVar8 == iVar3) {
              iStack_28 = piVar13[2];
              piStack_24 = (int *)piVar13[3];
              break;
            }
            iVar3 = *piVar2;
          }
        }
        piVar2 = piStack_24;
        uStack_8._0_1_ = 6;
        if (iStack_28 != 0) {
          uVar15 = FUN_00927d30(auStack_48);
          if (piVar10 != (int *)0x0) {
            LOCK();
            piVar10[1] = piVar10[1] + 1;
            UNLOCK();
          }
          FUN_00bde880(iStack_20,piVar10,&param_1,uVar15);
        }
        uStack_8._0_1_ = 3;
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = piVar2[1] + -1;
          piVar2[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            iVar3 = piVar2[2] + -1;
            piVar2[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        piVar13 = (int *)*piVar13;
      } while (piVar13 != (int *)*piStack_18);
      *puStack_2c = uStack_3c;
    }
  }
  if (piVar10 != (int *)0x0) {
    LOCK();
    iVar3 = piVar10[1] + -1;
    piVar10[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar10)();
      LOCK();
      iVar3 = piVar10[2] + -1;
      piVar10[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar10 + 4))();
      }
    }
  }
  FUN_00651cc0();
  if (in_stack_00000050 != (int *)0x0) {
    LOCK();
    piVar10 = in_stack_00000050 + 2;
    iVar3 = *piVar10;
    *piVar10 = *piVar10 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*in_stack_00000050 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26472 ; VA 0x00bd9bc0 ; FUN_00bd9bc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00bd9bc0(char param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined8 param_5)

{
  int iVar1;
  void *pvVar2;
  undefined4 uVar3;
  undefined uVar4;
  char cVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  int iVar9;
  undefined4 *puVar10;
  char *pcVar11;
  uint uVar12;
  uint uVar13;
  int *piVar14;
  undefined *puVar15;
  int *piVar16;
  uint uVar17;
  int *piVar18;
  int *in_stack_00000050;
  undefined auStack_128 [8];
  uint auStack_120 [4];
  undefined4 uStack_110;
  uint uStack_10c;
  undefined auStack_108 [16];
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined auStack_f0 [16];
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined auStack_d8 [4];
  uint auStack_d4 [4];
  undefined4 uStack_c4;
  uint uStack_c0;
  uint auStack_bc [4];
  undefined4 uStack_ac;
  uint uStack_a8;
  int iStack_a4;
  undefined *puStack_a0;
  uint auStack_9c [4];
  undefined4 uStack_8c;
  uint uStack_88;
  uint auStack_84 [4];
  undefined4 uStack_74;
  uint uStack_70;
  uint auStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  uint auStack_54 [4];
  undefined4 uStack_44;
  uint uStack_40;
  int aiStack_3c [2];
  int iStack_34;
  int *piStack_30;
  undefined auStack_2c [4];
  int iStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01800e34;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_34);
  iVar1 = iStack_34;
  uStack_8._0_1_ = 2;
  if (iStack_34 != 0) {
    FUN_00888650(&uStack_20);
    uStack_8._0_1_ = 3;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (param_1 == '\0') {
      uStack_e0 = 0;
      uStack_dc = 0xf;
      auStack_f0[0] = 0;
      uStack_8._0_1_ = uVar4;
      FUN_005542c0(&DAT_018c3c94,3);
      puVar15 = auStack_f0;
      uStack_8 = 5;
      piStack_18 = (int *)0x2;
    }
    else {
      uStack_f8 = 0;
      uStack_f4 = 0xf;
      auStack_108[0] = 0;
      FUN_005542c0(&DAT_018c3c98,4);
      puVar15 = auStack_108;
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      piStack_18 = (int *)0x1;
    }
    uStack_44 = 0;
    uStack_40 = 0xf;
    auStack_54[0] = auStack_54[0] & 0xffffff00;
    pcVar11 = PTR_DAT_01d67ed4;
    do {
      cVar5 = *pcVar11;
      pcVar11 = pcVar11 + 1;
    } while (cVar5 != '\0');
    piStack_14 = piStack_18;
    FUN_005542c0(PTR_DAT_01d67ed4,(int)pcVar11 - (int)(PTR_DAT_01d67ed4 + 1));
    uVar3 = uStack_20;
    uStack_8 = 6;
    FUN_005c4c00(auStack_54);
    FUN_00632ce0(puVar15);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (0xf < uStack_40) {
      uVar13 = uStack_40 + 1;
      uVar17 = auStack_54[0];
      if (0xfff < uVar13) {
        uVar17 = *(uint *)(auStack_54[0] - 4);
        uVar13 = uStack_40 + 0x24;
        if (0x1f < (auStack_54[0] - uVar17) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar17,uVar13);
    }
    uStack_44 = 0;
    uStack_40 = 0xf;
    auStack_54[0] = auStack_54[0] & 0xffffff00;
    if (((uint)piStack_14 & 2) != 0) {
      piStack_14 = (int *)((uint)piStack_14 & 0xfffffffd);
      FUN_005507b0();
    }
    uStack_8 = 3;
    if (((uint)piStack_14 & 1) != 0) {
      FUN_005507b0();
    }
    uStack_ac = 0;
    uStack_a8 = 0xf;
    auStack_bc[0] = auStack_bc[0] & 0xffffff00;
    pcVar11 = PTR_DAT_01d67f38;
    do {
      cVar5 = *pcVar11;
      pcVar11 = pcVar11 + 1;
    } while (cVar5 != '\0');
    FUN_005542c0(PTR_DAT_01d67f38,(int)pcVar11 - (int)(PTR_DAT_01d67f38 + 1));
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    iVar6 = FUN_005c4c00(auStack_bc);
    uVar7 = FUN_0088c8c0();
    *(undefined4 *)(iVar6 + 0x18) = uVar7;
    piStack_18 = (int *)FUN_005c9cc0();
    iVar9 = *(int *)(iVar6 + 0x1c);
    if ((int *)iVar9 == piStack_18) {
      *(undefined4 *)(iVar6 + 0x20) = param_2;
    }
    else {
      if (iVar9 != 0) {
        (**(code **)(iVar9 + 8))(iVar6 + 0x20);
        *(undefined4 *)(iVar6 + 0x1c) = 0;
      }
      *(undefined4 *)(iVar6 + 0x20) = param_2;
      *(int **)(iVar6 + 0x1c) = piStack_18;
    }
    uStack_8._0_1_ = 3;
    if (0xf < uStack_a8) {
      uVar13 = uStack_a8 + 1;
      uVar17 = auStack_bc[0];
      if (0xfff < uVar13) {
        uVar17 = *(uint *)(auStack_bc[0] - 4);
        uVar13 = uStack_a8 + 0x24;
        if (0x1f < (auStack_bc[0] - uVar17) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar17,uVar13);
    }
    uVar7 = FUN_00bdc2c0(auStack_120,param_3);
    uStack_8._0_1_ = 8;
    uStack_5c = 0;
    uStack_58 = 0xf;
    piStack_18 = (int *)(PTR_DAT_01d67f3c + 1);
    auStack_6c[0] = auStack_6c[0] & 0xffffff00;
    pcVar11 = PTR_DAT_01d67f3c;
    do {
      cVar5 = *pcVar11;
      pcVar11 = pcVar11 + 1;
    } while (cVar5 != '\0');
    FUN_005542c0(PTR_DAT_01d67f3c,(int)pcVar11 - (int)piStack_18);
    uStack_8._0_1_ = 9;
    FUN_005c4c00(auStack_6c);
    FUN_00632ce0(uVar7);
    uStack_8._0_1_ = 8;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (0xf < uStack_58) {
      uVar13 = uStack_58 + 1;
      uVar17 = auStack_6c[0];
      if (0xfff < uVar13) {
        uVar17 = *(uint *)(auStack_6c[0] - 4);
        uVar13 = uStack_58 + 0x24;
        if (0x1f < (auStack_6c[0] - uVar17) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar17,uVar13);
    }
    uStack_5c = 0;
    uStack_58 = 0xf;
    auStack_6c[0] = auStack_6c[0] & 0xffffff00;
    uStack_8._0_1_ = 3;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_10c) {
      uVar13 = uStack_10c + 1;
      uVar17 = auStack_120[0];
      if (0xfff < uVar13) {
        uVar17 = *(uint *)(auStack_120[0] - 4);
        uVar13 = uStack_10c + 0x24;
        if (0x1f < (auStack_120[0] - uVar17) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar17,uVar13);
    }
    uStack_110 = 0;
    uStack_10c = 0xf;
    auStack_120[0] = auStack_120[0] & 0xffffff00;
    uStack_74 = 0;
    uStack_70 = 0xf;
    auStack_84[0] = auStack_84[0] & 0xffffff00;
    pcVar11 = PTR_DAT_01d67f40;
    do {
      cVar5 = *pcVar11;
      pcVar11 = pcVar11 + 1;
    } while (cVar5 != '\0');
    FUN_005542c0(PTR_DAT_01d67f40,(int)pcVar11 - (int)(PTR_DAT_01d67f40 + 1));
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    iVar6 = FUN_005c4c00(auStack_84);
    uVar7 = FUN_0088ca00();
    pvVar2 = ThreadLocalStoragePointer;
    iVar9 = _tls_index;
    *(undefined4 *)(iVar6 + 0x18) = uVar7;
    if ((*(int *)(*(int *)((int)pvVar2 + iVar9 * 4) + 0x34) < DAT_01ead488) &&
       (FUN_016f3809(&DAT_01ead488), DAT_01ead488 == -1)) {
      _DAT_01ead47c = FUN_00619e80;
      _DAT_01ead480 = FUN_00619e80;
      DAT_01ead484 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead488);
    }
    puVar15 = *(undefined **)(iVar6 + 0x1c);
    if (puVar15 == &DAT_01ead47c) {
      *(undefined8 *)(iVar6 + 0x20) = param_5;
    }
    else {
      if (puVar15 != (undefined *)0x0) {
        (**(code **)(puVar15 + 8))(iVar6 + 0x20);
        *(undefined4 *)(iVar6 + 0x1c) = 0;
      }
      *(undefined8 *)(iVar6 + 0x20) = param_5;
      *(undefined **)(iVar6 + 0x1c) = &DAT_01ead47c;
    }
    uStack_8._0_1_ = 3;
    if (0xf < uStack_70) {
      uVar13 = uStack_70 + 1;
      uVar17 = auStack_84[0];
      if (0xfff < uVar13) {
        uVar17 = *(uint *)(auStack_84[0] - 4);
        uVar13 = uStack_70 + 0x24;
        if (0x1f < (auStack_84[0] - uVar17) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar17,uVar13);
    }
    uStack_74 = 0;
    uStack_70 = 0xf;
    auStack_84[0] = auStack_84[0] & 0xffffff00;
    uStack_8c = 0;
    uStack_88 = 0xf;
    auStack_9c[0] = auStack_9c[0] & 0xffffff00;
    pcVar11 = PTR_DAT_01d67f44;
    do {
      cVar5 = *pcVar11;
      pcVar11 = pcVar11 + 1;
    } while (cVar5 != '\0');
    FUN_005542c0(PTR_DAT_01d67f44,(int)pcVar11 - (int)(PTR_DAT_01d67f44 + 1));
    puVar15 = &stack0x0000001c;
    uStack_8._0_1_ = 0xb;
    FUN_005c4c00(auStack_9c);
    FUN_005c16d0(puVar15);
    uStack_8._0_1_ = 3;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_88) {
      uVar13 = uStack_88 + 1;
      uVar17 = auStack_9c[0];
      if (0xfff < uVar13) {
        uVar17 = *(uint *)(auStack_9c[0] - 4);
        uVar13 = uStack_88 + 0x24;
        if (0x1f < (auStack_9c[0] - uVar17) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar17,uVar13);
    }
    uStack_8c = 0;
    uStack_88 = 0xf;
    auStack_9c[0] = auStack_9c[0] & 0xffffff00;
    uStack_c4 = 0;
    uStack_c0 = 0xf;
    auStack_d4[0] = auStack_d4[0] & 0xffffff00;
    pcVar11 = PTR_DAT_01d67f48;
    do {
      cVar5 = *pcVar11;
      pcVar11 = pcVar11 + 1;
    } while (cVar5 != '\0');
    FUN_005542c0(PTR_DAT_01d67f48,(int)pcVar11 - (int)(PTR_DAT_01d67f48 + 1));
    puVar15 = &stack0x00000034;
    uStack_8._0_1_ = 0xc;
    FUN_005c4c00(auStack_d4);
    FUN_005c16d0(puVar15);
    uStack_8._0_1_ = 3;
    if (0xf < uStack_c0) {
      uVar13 = uStack_c0 + 1;
      uVar17 = auStack_d4[0];
      if (0xfff < uVar13) {
        uVar17 = *(uint *)(auStack_d4[0] - 4);
        uVar13 = uStack_c0 + 0x24;
        if (0x1f < (auStack_d4[0] - uVar17) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar17,uVar13);
    }
    piVar14 = DAT_01d67e90;
    if (DAT_01d67e70 != *(int *)(iVar1 + 0xf0)) {
      piVar16 = *(int **)(iVar1 + 0xe8);
      piStack_14 = DAT_01d67e90;
      *(int **)(iVar1 + 0xf0) = DAT_01d67e90;
      *(undefined4 *)(iVar1 + 0xf4) = 0;
      if (piVar14 < piVar16) {
        if (piVar16 == (int *)0x0) {
          puStack_a0 = (undefined *)0x0;
        }
        else {
          puStack_a0 = *(undefined **)(iVar1 + 0xe0);
        }
        iStack_a4 = iVar1 + 0xd8;
        piStack_18 = (int *)puStack_a0;
        puVar8 = (undefined4 *)FUN_00bd8930((int)piVar16 - (int)piVar14);
        FUN_00bded70(auStack_128,iVar1 + 0xd8,piStack_18,*puVar8,puVar8[1]);
      }
      uVar17 = *(uint *)(iVar1 + 0xf4);
      uVar13 = *(int *)(iVar1 + 0xdc) - *(int *)(iVar1 + 0xd8) >> 3;
      if (uVar17 <= uVar13) {
        piStack_14 = *(int **)(iVar1 + 0xe8);
        do {
          uVar12 = uVar13;
          if ((int *)(uVar13 / 3) < piStack_14) break;
          uVar13 = uVar13 >> 1;
          uVar12 = uVar17;
        } while (uVar17 < uVar13);
        uVar13 = uVar12 * 2;
        if (uVar12 / 5 + (int)piStack_14 < uVar12) {
          uVar13 = uVar12;
        }
        uVar17 = *(uint *)(iVar1 + 0xf0);
        if (uVar13 <= *(uint *)(iVar1 + 0xf0)) {
          uVar17 = uVar13;
        }
      }
      FUN_00bdf430(uVar17);
    }
    cVar5 = FUN_0098c5a0(iVar1,1);
    if (cVar5 == '\0') {
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piStack_1c[1] = piStack_1c[1] + 1;
        UNLOCK();
      }
      FUN_00bdaf30(aiStack_3c,0xffffffff,0xffffffff,uVar3,piStack_1c);
      if (aiStack_3c[0] == 0) {
        FUN_00550b30();
        FUN_00550b30();
        FUN_00550b30();
        goto LAB_00bda546;
      }
      FUN_0056ecd0(aiStack_3c);
      FUN_00550b30();
    }
    piVar14 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
    }
    FUN_00b25370(iVar1,uStack_20,piStack_1c);
    piVar16 = (int *)(iVar1 + 0xd8);
    uVar13 = *(int *)(iVar1 + 0xe8) + 1;
    uVar17 = *(int *)(iVar1 + 0xdc) - *piVar16 >> 3;
    if (uVar17 < uVar13) {
      if (uVar17 == 0) {
        uVar17 = 1;
      }
      for (; uVar17 < uVar13; uVar17 = uVar17 * 2) {
      }
      uVar12 = uVar17 * 2;
      if (uVar17 / 5 + uVar13 < uVar17) {
        uVar12 = uVar17;
      }
      uVar17 = *(uint *)(iVar1 + 0xf0);
      if (uVar12 <= *(uint *)(iVar1 + 0xf0)) {
        uVar17 = uVar12;
      }
      FUN_00bdf430(uVar17);
    }
    if (*(int *)(iVar1 + 0xdc) - *piVar16 >> 3 == *(int *)(iVar1 + 0xe8)) {
      if (*(int *)(iVar1 + 0xe8) != 0) {
        FUN_00bdead0(*(undefined4 *)(iVar1 + 0xe4),&uStack_20);
        iVar9 = *(int *)(iVar1 + 0xe4) + 8;
        *(int *)(iVar1 + 0xe4) = iVar9;
        if (iVar9 == *(int *)(iVar1 + 0xdc)) {
          iVar9 = *piVar16;
          *(int *)(iVar1 + 0xe4) = iVar9;
        }
        *(int *)(iVar1 + 0xe0) = iVar9;
      }
    }
    else {
      puVar8 = *(undefined4 **)(iVar1 + 0xe4);
      if (puVar8 != (undefined4 *)0x0) {
        *puVar8 = 0;
        puVar8[1] = 0;
        if (piVar14 != (int *)0x0) {
          LOCK();
          piVar14[1] = piVar14[1] + 1;
          UNLOCK();
        }
        *puVar8 = uStack_20;
        puVar8[1] = piVar14;
      }
      *(int *)(iVar1 + 0xe4) = *(int *)(iVar1 + 0xe4) + 8;
      if (*(int *)(iVar1 + 0xe4) == *(int *)(iVar1 + 0xdc)) {
        *(int *)(iVar1 + 0xe4) = *piVar16;
      }
      *(int *)(iVar1 + 0xe8) = *(int *)(iVar1 + 0xe8) + 1;
    }
    piVar18 = (int *)(iStack_34 + 0xf8);
    puVar8 = (undefined4 *)*piVar18;
    piStack_14 = piVar18;
    puVar10 = (undefined4 *)FUN_00bd6d50(auStack_d8,*puVar8,puVar8,FUN_00bde340);
    FUN_00bda9f0(auStack_2c,*puVar10,puVar8);
    piVar16 = *(int **)*piVar18;
    if (piVar16 != (int *)*piVar18) {
      do {
        iVar1 = piVar16[3];
        iStack_28 = 0;
        piStack_24 = (int *)0x0;
        if (iVar1 != 0) {
          piVar18 = (int *)(iVar1 + 4);
          iVar1 = *(int *)(iVar1 + 4);
          while (piVar14 = piStack_1c, iVar1 != 0) {
            LOCK();
            iVar9 = *piVar18;
            if (iVar1 == iVar9) {
              *piVar18 = iVar1 + 1;
              iVar9 = iVar1;
            }
            UNLOCK();
            if (iVar9 == iVar1) {
              iStack_28 = piVar16[2];
              piStack_24 = (int *)piVar16[3];
              break;
            }
            iVar1 = *piVar18;
          }
        }
        piVar18 = piStack_24;
        uStack_8._0_1_ = 0xd;
        if (iStack_28 != 0) {
          if (piStack_24 != (int *)0x0) {
            LOCK();
            piStack_24[1] = piStack_24[1] + 1;
            UNLOCK();
          }
          if (piVar14 != (int *)0x0) {
            LOCK();
            piVar14[1] = piVar14[1] + 1;
            UNLOCK();
          }
          FUN_00bde650(uStack_20,piVar14,iStack_28,piStack_24);
        }
        uStack_8._0_1_ = 3;
        if (piVar18 != (int *)0x0) {
          LOCK();
          iVar1 = piVar18[1] + -1;
          piVar18[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar18)();
            LOCK();
            iVar1 = piVar18[2] + -1;
            piVar18[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar18 + 4))();
            }
          }
        }
        piVar16 = (int *)*piVar16;
      } while (piVar16 != (int *)*piStack_14);
    }
    if (piVar14 != (int *)0x0) {
      LOCK();
      iVar1 = piVar14[1] + -1;
      piVar14[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar14)();
        LOCK();
        iVar1 = piVar14[2] + -1;
        piVar14[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar14 + 4))();
        }
      }
    }
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_30[1] + -1;
    piStack_30[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      iVar1 = piStack_30[2] + -1;
      piStack_30[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
LAB_00bda546:
  FUN_00bd8160();
  if (in_stack_00000050 != (int *)0x0) {
    LOCK();
    piVar14 = in_stack_00000050 + 2;
    iVar1 = *piVar14;
    *piVar14 = *piVar14 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      (**(code **)(*in_stack_00000050 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26473 ; VA 0x00bda600 ; FUN_00bda600 */

void FUN_00bda600(int param_1,int param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e0ff7;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_290 = FUN_0088cb40();
  uStack_28c = 0;
  FUN_0054ef60(&param_2);
  uStack_28c = FUN_005c9d30();
  uStack_8._0_1_ = 2;
  uStack_1c0 = thunk_FUN_0086f380();
  uStack_1bc = 0;
  uStack_1b8 = in_stack_00000020;
  uStack_1bc = FUN_0086f410();
  uStack_8._0_1_ = 3;
  uStack_f0 = FUN_0088c8c0();
  uStack_ec = 0;
  uStack_e8 = in_stack_00000024;
  uStack_ec = FUN_005c9cc0();
  uStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_290,&uStack_20,piVar1);
  uStack_8._0_1_ = 5;
  (*pcVar2)(&uStack_1c);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_01675290(uVar3);
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    iVar4 = param_2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_2 + -4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26474 ; VA 0x00bda790 ; FUN_00bda790 */

void FUN_00bda790(int param_1,int param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c83dc;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_1c0 = FUN_0088cb40();
  uStack_1bc = 0;
  FUN_0054ef60(&param_2);
  uStack_1bc = FUN_005c9d30();
  uStack_8._0_1_ = 2;
  uStack_f0 = thunk_FUN_0086f380();
  uStack_ec = 0;
  uStack_e8 = in_stack_00000020;
  uStack_ec = FUN_0086f410();
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,piVar1);
  uStack_8._0_1_ = 4;
  (*pcVar2)(&uStack_1c);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_01675290(uVar3);
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    iVar4 = param_2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_2 + -4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26475 ; VA 0x00bda8f0 ; FUN_00bda8f0 */

void FUN_00bda8f0(int param_1,undefined4 param_2)

{
  int *piVar1;
  code *pcVar2;
  
  pcVar2 = *(code **)(param_1 + 0x18);
  if (*(int *)(param_1 + 0x20) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x20) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar2)(*(undefined4 *)(param_1 + 0x1c),*(undefined4 *)(param_1 + 0x20),param_2);
  return;
}



/* FUNCTION 26476 ; VA 0x00bda930 ; FUN_00bda930 */

int FUN_00bda930(int param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_00000024;
  undefined *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5030;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined *)&param_2;
  puStack_14 = &param_4;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00bd5af0(param_1,param_1 + 0x18,&puStack_18,0);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000024) {
    uVar5 = in_stack_00000024 + 1;
    iVar4 = param_4;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_4 + -4);
      uVar5 = in_stack_00000024 + 0x24;
      if (0x1f < (param_4 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 26477 ; VA 0x00bda9f0 ; FUN_00bda9f0 */

undefined4 * __thiscall
FUN_00bda9f0(undefined4 *param_1,undefined4 *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  if ((param_3 == *(int **)*param_1) && (param_4 == (int *)*param_1)) {
    FUN_00bd8c30();
    *param_2 = *param_1;
    return param_2;
  }
  if (param_3 != param_4) {
    do {
      piVar1 = (int *)*param_3;
      *(int **)param_3[1] = piVar1;
      *(int *)(*param_3 + 4) = param_3[1];
      param_1[1] = param_1[1] + -1;
      piVar2 = (int *)param_3[3];
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
      FUN_01674ea0(param_3,0x10);
      param_3 = piVar1;
    } while (piVar1 != param_4);
  }
  *param_2 = param_4;
  return param_2;
}



/* FUNCTION 26478 ; VA 0x00bdaa70 ; FUN_00bdaa70 */

int __thiscall FUN_00bdaa70(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  uint uVar8;
  uint in_stack_00000018;
  undefined4 uStack_1f4;
  undefined4 uStack_1f0;
  undefined4 uStack_1ec;
  undefined4 uStack_1e8;
  undefined4 uStack_124;
  undefined4 uStack_120;
  uint uStack_11c;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined auStack_54 [4];
  int *piStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  uint uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  code *pcStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01800e94;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  iVar5 = FUN_00973950(param_1,1);
  if ((char)iVar5 != '\0') {
    iVar5 = FUN_0097bfc0(param_1);
    if (iVar5 != 0) {
      uStack_4c = 0;
      uStack_48 = 0;
      FUN_0054ef60(&param_2);
      uStack_8._0_1_ = 1;
      puVar6 = (undefined4 *)FUN_0060dcd0(auStack_54,iVar5);
      uVar3 = *puVar6;
      uVar4 = puVar6[1];
      *puVar6 = 0;
      puVar6[1] = 0;
      uStack_8._0_1_ = 5;
      pcStack_18 = *(code **)(*piStack_14 + 8);
      uStack_20 = uVar3;
      uStack_1c = uVar4;
      uStack_1f4 = FUN_0088cdc0();
      uStack_1f0 = 0;
      uStack_20 = 0;
      uStack_1c = 0;
      uStack_1ec = uVar3;
      uStack_1e8 = uVar4;
      uStack_1f0 = FUN_006309e0();
      uStack_8._0_1_ = 6;
      uStack_124 = FUN_0088cb40();
      uStack_120 = 0;
      uStack_11c = uStack_44;
      uStack_118 = uStack_40;
      uStack_114 = uStack_3c;
      uStack_110 = uStack_38;
      uStack_44 = uStack_44 & 0xffffff00;
      uStack_34 = 0;
      uStack_30 = 0xf;
      uStack_120 = FUN_005c9d30();
      uStack_8._0_1_ = 7;
      uStack_2c = 0;
      uStack_28 = 0;
      uStack_24 = 0;
      FUN_00687980(&uStack_1f4,auStack_54,in_stack_00000018);
      uStack_8._0_1_ = 8;
      (*pcStack_18)(&DAT_02132700,&uStack_2c,&uStack_4c);
      uStack_8._0_1_ = 9;
      FUN_00577b20();
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      iVar5 = FUN_016f32d1(&uStack_1f4,0xd0,2,FUN_0056e5b0);
      if (0xf < uStack_30) {
        uVar7 = uStack_30 + 1;
        uVar8 = uStack_44;
        if (0xfff < uVar7) {
          uVar8 = *(uint *)(uStack_44 - 4);
          uVar7 = uStack_30 + 0x24;
          if (0x1f < (uStack_44 - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        iVar5 = FUN_01674ea0(uVar8,uVar7);
      }
      uStack_34 = 0;
      uStack_30 = 0xf;
      uStack_44 = uStack_44 & 0xffffff00;
      if (piStack_50 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_50 + 1;
        iVar2 = *piVar1;
        iVar5 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar5 = (**(code **)*piStack_50)();
          LOCK();
          piVar1 = piStack_50 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            iVar5 = (**(code **)(*piStack_50 + 4))();
          }
        }
      }
    }
  }
  if (0xf < in_stack_00000018) {
    uVar8 = in_stack_00000018 + 1;
    iVar5 = param_2;
    if (0xfff < uVar8) {
      iVar5 = *(int *)(param_2 + -4);
      uVar8 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar5 = FUN_01674ea0(iVar5,uVar8);
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 26479 ; VA 0x00bdacd0 ; FUN_00bdacd0 */

void * FUN_00bdacd0(undefined4 param_1,int *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  undefined *puVar3;
  void *pvVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  void *pvVar8;
  uint in_stack_00000020;
  undefined auStack_4c [24];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  void *pvStack_28;
  int *piStack_24;
  undefined auStack_20 [12];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_01800ed0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffa8;
  uStack_8 = 1;
  uStack_7 = 0;
  if (DAT_01d67ea4 == '\0') {
    ExceptionList = &pvStack_10;
    FUN_00587490(&pvStack_28);
    uStack_8 = 2;
    if (pvStack_28 != (void *)0x0) {
      pvVar4 = *(void **)((int)pvStack_28 + 0x34);
      pvVar8 = pvStack_28;
      if ((pvVar4 != (void *)0x0) && (pvVar8 = pvVar4, *(int *)((int)pvVar4 + 0x34) != 0)) {
        pvStack_28 = (void *)FUN_005c8ac0();
        pvVar8 = pvStack_28;
      }
      if (pvVar8 != (void *)0x0) {
        iVar2 = *(int *)((int)pvVar8 + 0xc);
        iVar5 = FUN_008a8c30();
        pvStack_28 = (void *)(uint)*(ushort *)(iVar5 + 0x1da);
        if (((void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) <=
             pvStack_28) && (pvStack_28 = (void *)FUN_0055ea10(), pvStack_28 != (void *)0x0)) {
          puVar7 = &param_3;
          if (0xf < in_stack_00000020) {
            puVar7 = param_3;
          }
          FUN_0086f2f0(0,&DAT_0195e6ec,puVar7);
          uStack_8 = 3;
          if (DAT_01d64500 == '\0') {
            uVar6 = FUN_00886c00(auStack_20,&param_3);
            uStack_8 = 7;
            FUN_01255470(2,0,0,0);
            FUN_0094ee10(auStack_4c,uVar6,"console");
            FUN_0056e380();
            pvStack_28 = (void *)FUN_0056e380();
          }
          else {
            uStack_34 = 0;
            uStack_30 = 0;
            uStack_2c = 0;
            uStack_8 = 4;
            uVar6 = FUN_00886c00(auStack_20,&param_3);
            uStack_8 = 5;
            FUN_01255470(2,0,0,0);
            FUN_00951870(auStack_4c,uVar6,"console",&uStack_34);
            FUN_0056e380();
            FUN_0056e380();
            uStack_8 = 6;
            pvStack_28 = (void *)FUN_00577b20();
          }
        }
      }
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_24 + 1;
      iVar2 = *piVar1;
      pvStack_28 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piStack_24 + 2;
        iVar2 = *piVar1;
        pvStack_28 = (void *)*piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          pvStack_28 = (void *)(**(code **)(*piStack_24 + 4))();
        }
      }
    }
    if (param_2 == (int *)0x0) goto LAB_00bdad17;
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    puVar3 = puStack_14;
    if (iVar2 != 1) goto LAB_00bdad17;
  }
  else {
    pvStack_28 = ExceptionList;
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffa8;
    if (param_2 == (int *)0x0) goto LAB_00bdad17;
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    pvStack_28 = (void *)*piVar1;
    ExceptionList = &pvStack_10;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    puStack_14 = &stack0xffffffa8;
    puVar3 = &stack0xffffffa8;
    if (iVar2 + -1 != 0) goto LAB_00bdad17;
  }
  puStack_14 = puVar3;
  pvStack_28 = (void *)(**(code **)(*param_2 + 4))();
LAB_00bdad17:
  if (0xf < in_stack_00000020) {
    if (0xfff < in_stack_00000020 + 1) {
      if (0x1f < (uint)((int)param_3 + (-4 - param_3[-1]))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      pvVar4 = (void *)FUN_00bdaf09();
      return pvVar4;
    }
    pvStack_28 = (void *)FUN_01674ea0(param_3,in_stack_00000020 + 1);
  }
  ExceptionList = pvStack_10;
  return pvStack_28;
}



/* FUNCTION 26480 ; VA 0x00bdaeeb ; Catch@00bdaeeb */

undefined4 Catch_00bdaeeb(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x14) + 4))();
  FUN_0086f2f0(3,&DAT_018bd25c,uVar1);
  return 0xbdae5a;
}



/* FUNCTION 26481 ; VA 0x00bdaf09 ; FUN_00bdaf09 */

void __fastcall FUN_00bdaf09(undefined4 param_1,undefined4 param_2)

{
  int unaff_EBP;
  
  FUN_01674ea0(param_1,param_2);
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 26482 ; VA 0x00bdaf30 ; FUN_00bdaf30 */

int * __thiscall
FUN_00bdaf30(int param_1,int *param_2,undefined4 param_3,undefined *param_4,int param_5,int *param_6
            )

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined uVar3;
  char cVar4;
  int *piVar5;
  int iVar6;
  int iVar7;
  undefined4 ****ppppuVar8;
  undefined4 *puVar9;
  int *piVar10;
  int iVar11;
  undefined4 uVar12;
  char *pcVar13;
  uint uVar14;
  uint uVar15;
  undefined4 *puVar16;
  undefined4 ***apppuStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  int iStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01800f21;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_18 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar5 = (int *)FUN_00a15ae0(&iStack_1c,&param_3);
  if (*piVar5 != *(int *)(param_1 + 0x110)) {
    *param_2 = param_5;
    param_2[1] = (int)param_6;
    ExceptionList = pvStack_10;
    return param_2;
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  FUN_005542c0(&DAT_0193beb0,0xb);
  uStack_8._0_1_ = 1;
  iVar6 = FUN_005c4c00(auStack_38);
  iVar11 = *(int *)(iVar6 + 0x18);
  iVar7 = FUN_0088cb40();
  if ((iVar11 == iVar7) && (*(int *)(iVar6 + 0x1c) != 0)) {
    puVar16 = (undefined4 *)(iVar6 + 0x20);
  }
  else {
    puVar16 = (undefined4 *)0x0;
  }
  uStack_8._0_1_ = 0;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_24) {
    uVar14 = uStack_24 + 1;
    uVar15 = auStack_38[0];
    if (0xfff < uVar14) {
      uVar15 = *(uint *)(auStack_38[0] - 4);
      uVar14 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar15) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar15,uVar14);
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  if (puVar16 == (undefined4 *)0x0) {
    *param_2 = 0;
    param_2[1] = 0;
    goto LAB_00bdb386;
  }
  cVar4 = FUN_0098c5a0(param_1,1);
  if (cVar4 == '\0') {
    if (*(char *)(param_1 + 300) == '\0') {
      puVar9 = (undefined4 *)FUN_00bdc2c0(apppuStack_50,0);
      uStack_14 = 2;
      puVar1 = puVar9 + 4;
      if (0xf < (uint)puVar9[5]) {
        puVar9 = (undefined4 *)*puVar9;
      }
      puVar2 = puVar16 + 4;
      if (0xf < (uint)puVar16[5]) {
        puVar16 = (undefined4 *)*puVar16;
      }
      cVar4 = FUN_0055c360(puVar16,*puVar2,puVar9,*puVar1);
      if (cVar4 == '\0') goto LAB_00bdb0ff;
      cVar4 = '\0';
    }
    else {
LAB_00bdb0ff:
      cVar4 = '\x01';
    }
    if ((uStack_14 & 2) != 0) goto LAB_00bdb107;
  }
  else {
    uStack_8._0_1_ = 2;
    uStack_40 = 0;
    uStack_3c = 0xf;
    apppuStack_50[0] = (undefined4 ***)((uint)apppuStack_50[0] & 0xffffff00);
    FUN_005542c0("Unknown",7);
    uStack_18 = 4;
    FUN_005542c0("HttpService",0xb);
    puVar1 = puVar16 + 4;
    ppppuVar8 = apppuStack_50;
    if (0xf < uStack_3c) {
      ppppuVar8 = (undefined4 ****)apppuStack_50[0];
    }
    if (0xf < (uint)puVar16[5]) {
      puVar16 = (undefined4 *)*puVar16;
    }
    cVar4 = FUN_0055c360(puVar16,*puVar1,ppppuVar8,uStack_40);
    uStack_8._0_1_ = 0;
LAB_00bdb107:
    FUN_005507b0();
  }
  iVar11 = param_5;
  if (cVar4 != '\0') {
    param_5 = 0;
    *param_2 = iVar11;
    param_2[1] = (int)param_6;
    param_6 = (int *)0x0;
    FUN_00550b30();
    ExceptionList = pvStack_10;
    return param_2;
  }
  FUN_00888650(&iStack_20);
  uStack_8._0_1_ = 3;
  if (*(int *)(param_5 + 8) == 0) {
    puVar16 = (undefined4 *)0x0;
  }
  else {
    puVar16 = *(undefined4 **)(*(int *)(param_5 + 0x14) + *(int *)(param_5 + 4) * 4);
  }
  for (; puVar16 != (undefined4 *)0x0; puVar16 = (undefined4 *)*puVar16) {
    piVar5 = puVar16 + 2;
    pcVar13 = PTR_DAT_01d67ed4;
    do {
      cVar4 = *pcVar13;
      pcVar13 = pcVar13 + 1;
    } while (cVar4 != '\0');
    uVar12 = puVar16[6];
    piVar10 = piVar5;
    if (0xf < (uint)puVar16[7]) {
      piVar10 = (int *)*piVar5;
    }
    cVar4 = FUN_0055c360(piVar10,uVar12,PTR_DAT_01d67ed4,(int)pcVar13 - (int)(PTR_DAT_01d67ed4 + 1))
    ;
    if (cVar4 == '\0') {
      param_4 = PTR_DAT_01d67f3c + 1;
      pcVar13 = PTR_DAT_01d67f3c;
      do {
        cVar4 = *pcVar13;
        pcVar13 = pcVar13 + 1;
      } while (cVar4 != '\0');
      piVar10 = piVar5;
      if (0xf < (uint)puVar16[7]) {
        piVar10 = (int *)*piVar5;
      }
      cVar4 = FUN_0055c360(piVar10,uVar12,PTR_DAT_01d67f3c,(int)pcVar13 - (int)param_4);
      if (cVar4 != '\0') goto LAB_00bdb27e;
      param_4 = PTR_DAT_01d67f38 + 1;
      pcVar13 = PTR_DAT_01d67f38;
      do {
        cVar4 = *pcVar13;
        pcVar13 = pcVar13 + 1;
      } while (cVar4 != '\0');
      piVar10 = piVar5;
      if (0xf < (uint)puVar16[7]) {
        piVar10 = (int *)*piVar5;
      }
      cVar4 = FUN_0055c360(piVar10,uVar12,PTR_DAT_01d67f38,(int)pcVar13 - (int)param_4);
      if ((cVar4 != '\0') || (cVar4 = FUN_00558b60(piVar5,PTR_DAT_01d67f40), cVar4 != '\0'))
      goto LAB_00bdb27e;
      uStack_40 = 0;
      uStack_3c = 0xf;
      apppuStack_50[0] = (undefined4 ***)((uint)apppuStack_50[0] & 0xffffff00);
      FUN_005542c0(&DAT_018bc9b8,0);
      ppppuVar8 = apppuStack_50;
      uStack_8._0_1_ = 4;
      FUN_005c4c00(piVar5);
      FUN_00632ce0(ppppuVar8);
      uStack_8._0_1_ = 3;
      FUN_005507b0();
    }
    else {
LAB_00bdb27e:
      iVar11 = FUN_005c4c00(piVar5);
      piVar5 = puVar16 + 9;
      piVar10 = (int *)(iVar11 + 0x1c);
      *(undefined4 *)(iVar11 + 0x18) = puVar16[8];
      if (piVar5 != piVar10) {
        if (*piVar10 != 0) {
          (**(code **)(*piVar10 + 8))(iVar11 + 0x20);
          *piVar10 = 0;
        }
        if ((undefined4 *)*piVar5 != (undefined4 *)0x0) {
          (**(code **)*piVar5)(puVar16 + 10,iVar11 + 0x20);
          *piVar10 = *piVar5;
        }
      }
    }
  }
  uStack_40 = 0;
  uStack_3c = 0xf;
  apppuStack_50[0] = (undefined4 ***)((uint)apppuStack_50[0] & 0xffffff00);
  pcVar13 = PTR_DAT_01d67f4c;
  do {
    cVar4 = *pcVar13;
    pcVar13 = pcVar13 + 1;
  } while (cVar4 != '\0');
  FUN_005542c0(PTR_DAT_01d67f4c,(int)pcVar13 - (int)(PTR_DAT_01d67f4c + 1));
  uStack_8._0_1_ = 5;
  iVar6 = FUN_005c4c00(apppuStack_50);
  uVar12 = FUN_0088daf0();
  *(undefined4 *)(iVar6 + 0x18) = uVar12;
  iVar7 = FUN_005c9ef0();
  iVar11 = *(int *)(iVar6 + 0x1c);
  if (iVar11 == iVar7) {
    *(undefined *)(iVar6 + 0x20) = 1;
  }
  else {
    if (iVar11 != 0) {
      (**(code **)(iVar11 + 8))(iVar6 + 0x20);
    }
    *(undefined *)(iVar6 + 0x20) = 1;
    *(int *)(iVar6 + 0x1c) = iVar7;
  }
  if (0xf < uStack_3c) {
    uVar15 = uStack_3c + 1;
    ppppuVar8 = (undefined4 ****)apppuStack_50[0];
    if (0xfff < uVar15) {
      ppppuVar8 = (undefined4 ****)apppuStack_50[0][-1];
      uVar15 = uStack_3c + 0x24;
      if (0x1f < (uint)((int)apppuStack_50[0] + (-4 - (int)ppppuVar8))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar8,uVar15);
  }
  *param_2 = iStack_20;
  param_2[1] = iStack_1c;
LAB_00bdb386:
  piVar5 = param_6;
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar11 = param_6[1] + -1;
    param_6[1] = iVar11;
    UNLOCK();
    if (iVar11 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar10 = piVar5 + 2;
      iVar11 = *piVar10;
      *piVar10 = *piVar10 + -1;
      UNLOCK();
      if (iVar11 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 26483 ; VA 0x00bdb3d0 ; FUN_00bdb3d0 */

uint FUN_00bdb3d0(undefined4 *param_1)

{
  undefined4 ****ppppuVar1;
  undefined uVar2;
  int iVar3;
  undefined *puVar4;
  undefined4 *****pppppuVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined *puVar8;
  uint uVar9;
  undefined *puVar10;
  undefined4 *puVar11;
  undefined4 ****appppuStack_54 [4];
  undefined *puStack_44;
  uint uStack_40;
  uint auStack_3c [4];
  uint *puStack_2c;
  undefined4 *puStack_28;
  undefined *puStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af408;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_1);
  puVar10 = (undefined *)0x0;
  uStack_8 = 0;
  if (puStack_44 != (undefined *)0x0) {
    do {
      pppppuVar5 = appppuStack_54;
      if (0xf < uStack_40) {
        pppppuVar5 = (undefined4 *****)appppuStack_54[0];
      }
      iVar3 = FUN_0171dc5a(*(undefined *)((int)pppppuVar5 + (int)puVar10));
      if (iVar3 != 0) {
        pppppuVar5 = appppuStack_54;
        if (0xf < uStack_40) {
          pppppuVar5 = (undefined4 *****)appppuStack_54[0];
        }
        uVar2 = FUN_01725677(*(undefined *)((int)pppppuVar5 + (int)puVar10));
        pppppuVar5 = appppuStack_54;
        if (0xf < uStack_40) {
          pppppuVar5 = (undefined4 *****)appppuStack_54[0];
        }
        *(undefined *)((int)pppppuVar5 + (int)puVar10) = uVar2;
      }
      puVar10 = puVar10 + 1;
    } while (puVar10 < puStack_44);
  }
  uVar7 = uStack_40;
  ppppuVar1 = appppuStack_54[0];
  pppppuVar5 = appppuStack_54;
  if (0xf < uStack_40) {
    pppppuVar5 = (undefined4 *****)appppuStack_54[0];
  }
  puStack_28 = (undefined4 *)FUN_0058d4d0(pppppuVar5,puStack_44,0,&DAT_018c71bc,4);
  if (puStack_28 == (undefined4 *)0xffffffff) {
LAB_00bdb688:
    uStack_14 = 0;
    uVar7 = uStack_14;
    appppuStack_54[0] = ppppuVar1;
  }
  else {
    pppppuVar5 = appppuStack_54;
    if (0xf < uVar7) {
      pppppuVar5 = (undefined4 *****)ppppuVar1;
    }
    puVar10 = (undefined *)FUN_0058d4d0(pppppuVar5,puStack_44,puStack_28,"roblox",6);
    if (puVar10 == (undefined *)0xffffffff) {
      pppppuVar5 = appppuStack_54;
      if (0xf < uStack_40) {
        pppppuVar5 = (undefined4 *****)ppppuVar1;
      }
      puVar10 = (undefined *)FUN_0058d4d0(pppppuVar5,puStack_44,puStack_28,"rbxcdn",6);
      if (puVar10 == (undefined *)0xffffffff) goto LAB_00bdb688;
    }
    puStack_20 = (undefined *)0x0;
    auStack_3c[0] = 0;
    auStack_3c[1] = 0;
    auStack_3c[2] = 0;
    auStack_3c[3] = 0;
    if (puVar10 < puStack_44) {
      do {
        puVar8 = (undefined *)0xffffffff;
        puStack_28 = (undefined4 *)&DAT_00000004;
        puStack_18 = (undefined *)0xffffffff;
        puStack_1c = (undefined *)0x0;
        puStack_24 = (undefined *)0x0;
        puVar11 = &DAT_01d67ed8;
        do {
          puStack_2c = auStack_3c + (int)puStack_24;
          puVar4 = (undefined *)auStack_3c[(int)puStack_24];
          if ((puVar4 < puVar10) && (puVar4 != (undefined *)0xffffffff)) {
            puVar6 = puVar11;
            if (0xf < (uint)puVar11[5]) {
              puVar6 = (undefined4 *)*puVar11;
            }
            pppppuVar5 = appppuStack_54;
            if (0xf < uStack_40) {
              pppppuVar5 = (undefined4 *****)appppuStack_54[0];
            }
            puVar4 = (undefined *)FUN_0058d4d0(pppppuVar5,puStack_44,puVar10,puVar6,puVar11[4]);
            puVar8 = puStack_18;
            *puStack_2c = (uint)puVar4;
          }
          if ((puVar8 == (undefined *)0xffffffff) ||
             ((puVar4 < puVar8 && (puVar4 != (undefined *)0xffffffff)))) {
            puStack_18 = puVar4;
            puStack_1c = puStack_24;
            puVar8 = puVar4;
          }
          puVar11 = puVar11 + 6;
          puStack_28 = (undefined4 *)((int)puStack_28 + -1);
          puStack_24 = puStack_24 + 1;
        } while (puStack_28 != (undefined4 *)0x0);
        uVar7 = uStack_14;
        if (puVar8 == (undefined *)0xffffffff) break;
        puStack_24 = puVar8 + (&DAT_01d67ee8)[(int)puStack_1c * 6];
        puVar10 = puStack_24;
        if (puStack_24 < puStack_44) {
          while( true ) {
            pppppuVar5 = appppuStack_54;
            if (0xf < uStack_40) {
              pppppuVar5 = (undefined4 *****)appppuStack_54[0];
            }
            if (*(char *)((int)pppppuVar5 + (int)puVar10) == '&') break;
            pppppuVar5 = appppuStack_54;
            if (0xf < uStack_40) {
              pppppuVar5 = (undefined4 *****)appppuStack_54[0];
            }
            if (*(char *)((int)pppppuVar5 + (int)puVar10) == ' ') break;
            pppppuVar5 = appppuStack_54;
            if (0xf < uStack_40) {
              pppppuVar5 = (undefined4 *****)appppuStack_54[0];
            }
            if ((*(char *)((int)pppppuVar5 + (int)puVar10) == ':') ||
               (puVar10 = puVar10 + 1, puStack_44 <= puVar10)) break;
          }
        }
        puStack_2c = (uint *)param_1[5];
        puVar11 = param_1;
        if (&DAT_0000000f < puStack_2c) {
          puVar11 = (undefined4 *)*param_1;
        }
        puStack_18 = (undefined *)((int)puVar11 + ((int)puVar10 - (int)puStack_20));
        puVar11 = param_1;
        if (&DAT_0000000f < puStack_2c) {
          puVar11 = (undefined4 *)*param_1;
        }
        puStack_28 = param_1;
        iVar3 = (int)puVar11 + ((int)puStack_24 - (int)puStack_20);
        if (&DAT_0000000f < puStack_2c) {
          puStack_28 = (undefined4 *)*param_1;
        }
        uVar7 = param_1[4];
        uVar9 = iVar3 - (int)puStack_28;
        if (uVar7 < uVar9) {
          FUN_00554050();
          goto LAB_00bdb6d6;
        }
        puStack_18 = puStack_18 + -iVar3;
        if ((undefined *)(uVar7 - uVar9) < puStack_18) {
          puStack_18 = (undefined *)(uVar7 - uVar9);
        }
        puVar11 = param_1;
        if (&DAT_0000000f < puStack_2c) {
          puVar11 = (undefined4 *)*param_1;
        }
        param_1[4] = uVar7 - (int)puStack_18;
        FUN_0170cc70((int)puVar11 + uVar9,puStack_18 + (int)puVar11 + uVar9,
                     ((uVar7 - (int)puStack_18) - uVar9) + 1);
        puStack_20 = puVar10 + ((int)puStack_20 - (int)puStack_24);
        uVar7 = uStack_14 | 1 << ((uint)puStack_1c & 0x1f);
        uStack_14 = uVar7;
      } while (puVar10 < puStack_44);
    }
    else {
      uVar7 = 0;
      appppuStack_54[0] = ppppuVar1;
    }
  }
  if (0xf < uStack_40) {
    uVar7 = uStack_40 + 1;
    pppppuVar5 = (undefined4 *****)appppuStack_54[0];
    if (0xfff < uVar7) {
      pppppuVar5 = (undefined4 *****)((undefined4 *****)appppuStack_54[0])[-1];
      uVar7 = uStack_40 + 0x24;
      if (0x1f < (uint)((int)appppuStack_54[0] + (-4 - (int)pppppuVar5))) {
LAB_00bdb6d6:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar5,uVar7);
    uVar7 = uStack_14;
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 26484 ; VA 0x00bdb6e0 ; FUN_00bdb6e0 */

/* WARNING: Removing unreachable block (ram,0x00bdb74b) */
/* WARNING: Removing unreachable block (ram,0x00bdb759) */
/* WARNING: Removing unreachable block (ram,0x00bdb783) */
/* WARNING: Removing unreachable block (ram,0x00bdb769) */

void FUN_00bdb6e0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_009f1b60(param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6),param_8);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26485 ; VA 0x00bdb790 ; FUN_00bdb790 */

void FUN_00bdb790(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piVar5;
  
  iVar1 = *param_2;
  iVar4 = *(int *)(iVar1 + 0xd0);
  iVar2 = thunk_FUN_0086f380();
  if (iVar4 == iVar2) {
    puVar3 = (undefined4 *)(iVar1 + 0xd8);
    param_2 = (int *)*param_2;
    if (*(int *)(iVar1 + 0xd4) == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    iVar1 = *param_2;
    iVar4 = FUN_0088cb40(*puVar3);
    if (iVar1 == iVar4) {
      piVar5 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar5 = (int *)0x0;
      }
      FUN_0054ef60(piVar5);
      FUN_00bdb6e0(param_1);
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 26486 ; VA 0x00bdb810 ; FUN_00bdb810 */

/* WARNING: Removing unreachable block (ram,0x00bdb90d) */
/* WARNING: Removing unreachable block (ram,0x00bdb91b) */
/* WARNING: Removing unreachable block (ram,0x00bdb965) */
/* WARNING: Removing unreachable block (ram,0x00bdb92b) */

void FUN_00bdb810(undefined4 param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  int *piVar7;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795d48;
  pvStack_10 = ExceptionList;
  iVar1 = *param_2;
  iVar6 = *(int *)(iVar1 + 0x1a0);
  ExceptionList = &pvStack_10;
  iVar4 = FUN_0088c8c0();
  if (iVar6 != iVar4) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar5 = (undefined4 *)(iVar1 + 0x1a8);
  if (*(int *)(iVar1 + 0x1a4) == 0) {
    puVar5 = (undefined4 *)0x0;
  }
  uVar2 = *puVar5;
  iVar1 = *param_2;
  iVar6 = *(int *)(iVar1 + 0xd0);
  iVar4 = thunk_FUN_0086f380();
  if (iVar6 != iVar4) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar5 = (undefined4 *)(iVar1 + 0xd8);
  if (*(int *)(iVar1 + 0xd4) == 0) {
    puVar5 = (undefined4 *)0x0;
  }
  uVar3 = *puVar5;
  param_2 = (int *)*param_2;
  iVar1 = *param_2;
  iVar6 = FUN_0088cb40();
  if (iVar1 != iVar6) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  piVar7 = param_2 + 2;
  if (param_2[1] == 0) {
    piVar7 = (int *)0x0;
  }
  FUN_0054ef60(piVar7);
  uStack_8 = 0;
  FUN_00bd8720(uStack_34,uStack_30,uStack_2c,uStack_28,CONCAT44(uStack_20,uStack_24),uVar3,uVar2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26487 ; VA 0x00bdb970 ; FUN_00bdb970 */

void __thiscall FUN_00bdb970(int param_1,int *param_2)

{
  undefined4 uVar1;
  int iVar2;
  int *piVar3;
  undefined **ppuVar4;
  undefined **ppuVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  undefined4 uStack_100;
  int iStack_fc;
  undefined4 uStack_f8;
  int iStack_f4;
  int *piStack_30;
  int *piStack_2c;
  int iStack_28;
  int iStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01800f53;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_005cac50(&iStack_28);
  uVar6 = 0;
  iStack_8 = 0;
  iVar8 = iStack_28;
  if (*(int *)(param_1 + 0xe8) != 0) {
    do {
      piVar3 = (int *)FUN_01674e20(0x24);
      if (piVar3 == (int *)0x0) {
        piVar3 = (int *)0x0;
      }
      else {
        piVar3[1] = 1;
        piVar3[2] = 1;
        *piVar3 = (int)std::
                       _Ref_count_obj<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>
                       ::vftable;
        *(undefined *)(piVar3 + 3) = 0;
        iStack_14 = 0xb;
        ppuVar4 = (undefined **)
                  FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&iStack_14);
        ppuVar5 = (undefined **)&DAT_018be194;
        if (ppuVar4 != &boost::lock_error::vftable_meta_ptr) {
          ppuVar5 = ppuVar4;
        }
        piVar3[4] = (int)*ppuVar5;
        piVar3[5] = 0;
        piVar3[6] = 0x3f800000;
        piVar3[7] = 0;
        piVar3[8] = 0;
      }
      piStack_30 = piVar3 + 3;
      iVar8 = *(int *)(param_1 + 0xe0);
      uVar7 = uVar6;
      if (*(int *)(param_1 + 0xdc) - iVar8 >> 3 <= (int)uVar6) {
        uVar7 = uVar6 - (*(int *)(param_1 + 0xdc) - *(int *)(param_1 + 0xd8) >> 3);
      }
      iStack_1c = *(int *)(iVar8 + 4 + uVar7 * 8);
      if (iStack_1c != 0) {
        LOCK();
        *(int *)(iStack_1c + 4) = *(int *)(iStack_1c + 4) + 1;
        UNLOCK();
        iStack_1c = *(int *)(iVar8 + 4 + uVar7 * 8);
      }
      uVar1 = *(undefined4 *)(iVar8 + uVar7 * 8);
      iStack_8._0_1_ = 2;
      piStack_2c = piVar3;
      uStack_20 = uVar1;
      iStack_14 = iStack_1c;
      uStack_100 = FUN_008881d0();
      iStack_fc = 0;
      iStack_f4 = iStack_14;
      uStack_20 = 0;
      iStack_1c = 0;
      uStack_f8 = uVar1;
      iStack_fc = FUN_0058c000();
      iVar8 = iStack_28;
      iStack_8 = CONCAT31(iStack_8._1_3_,3);
      if (*(int *)(iStack_28 + 8) == *(int *)(iStack_28 + 4)) {
        FUN_005ca4f0(*(int *)(iStack_28 + 4),&uStack_100);
      }
      else {
        FUN_005caaf0(iStack_28);
        *(int *)(iVar8 + 4) = *(int *)(iVar8 + 4) + 0xd0;
      }
      iStack_8._0_1_ = 4;
      if (iStack_fc != 0) {
        (**(code **)(iStack_fc + 8))(&uStack_f8);
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[1] + -1;
        piVar3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar2 = piVar3[2] + -1;
          piVar3[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      uVar6 = uVar6 + 1;
      param_1 = iStack_18;
    } while (uVar6 < *(uint *)(iStack_18 + 0xe8));
  }
  *param_2 = iVar8;
  param_2[1] = iStack_24;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26488 ; VA 0x00bdbb80 ; FUN_00bdbb80 */

void __thiscall FUN_00bdbb80(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined **ppuVar3;
  int iVar4;
  undefined4 uVar5;
  undefined **ppuVar6;
  uint uVar7;
  undefined4 *puVar8;
  uint uVar9;
  uint uVar10;
  int *piVar11;
  undefined4 uStack_120;
  int iStack_11c;
  int *piStack_118;
  int *piStack_114;
  int *piStack_50;
  int *piStack_4c;
  int iStack_48;
  int iStack_44;
  int *piStack_40;
  int *piStack_3c;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  int *piStack_20;
  int iStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01800f9b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  FUN_005cac50(&iStack_48);
  uVar10 = 0;
  iStack_8 = 0;
  if (*(int *)(param_1 + 0xb4) != 0) {
    do {
      piVar2 = (int *)FUN_01674e20(0x24);
      piStack_20 = piVar2;
      if (piVar2 == (int *)0x0) {
        piVar2 = (int *)0x0;
      }
      else {
        piVar2[1] = 1;
        piVar2[2] = 1;
        *piVar2 = (int)std::
                       _Ref_count_obj<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>
                       ::vftable;
        *(undefined *)(piVar2 + 3) = 0;
        puStack_14 = (undefined4 *)0xb;
        ppuVar3 = (undefined **)
                  FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_14);
        ppuVar6 = (undefined **)&DAT_018be194;
        if (ppuVar3 != &boost::lock_error::vftable_meta_ptr) {
          ppuVar6 = ppuVar3;
        }
        piVar2[4] = (int)*ppuVar6;
        piVar2[5] = 0;
        piVar2[6] = 0x3f800000;
        piVar2[7] = 0;
        piVar2[8] = 0;
      }
      piStack_50 = piVar2 + 3;
      puStack_14 = *(undefined4 **)(param_1 + 0xac);
      iStack_8._0_1_ = 1;
      uVar7 = uVar10;
      if ((*(int *)(param_1 + 0xa8) - (int)puStack_14) / 0x48 <= (int)uVar10) {
        uVar7 = uVar10 - (*(int *)(param_1 + 0xa8) - *(int *)(iStack_1c + 0xa4)) / 0x48;
      }
      puStack_18 = (undefined4 *)puStack_14[uVar7 * 0x12 + 0x10];
      uStack_28 = 0;
      uStack_24 = 0xf;
      auStack_38[0] = auStack_38[0] & 0xffffff00;
      piStack_4c = piVar2;
      FUN_005542c0("timestamp",9);
      iStack_8 = CONCAT31(iStack_8._1_3_,2);
      iVar4 = FUN_005c4c00(auStack_38);
      uVar5 = FUN_0088c8c0();
      *(undefined4 *)(iVar4 + 0x18) = uVar5;
      puStack_14 = (undefined4 *)FUN_005c9cc0();
      puVar8 = *(undefined4 **)(iVar4 + 0x1c);
      if (puVar8 == puStack_14) {
        *(undefined4 **)(iVar4 + 0x20) = puStack_18;
      }
      else {
        if (puVar8 != (undefined4 *)0x0) {
          (*(code *)puVar8[2])(iVar4 + 0x20);
        }
        *(undefined4 **)(iVar4 + 0x20) = puStack_18;
        *(undefined4 **)(iVar4 + 0x1c) = puStack_14;
      }
      iStack_8._0_1_ = 1;
      if (0xf < uStack_24) {
        uVar9 = uStack_24 + 1;
        uVar7 = auStack_38[0];
        if (0xfff < uVar9) {
          uVar7 = *(uint *)(auStack_38[0] - 4);
          uVar9 = uStack_24 + 0x24;
          if (0x1f < (auStack_38[0] - uVar7) - 4) goto LAB_00bdc06e;
        }
        FUN_01674ea0(uVar7,uVar9);
      }
      puStack_14 = *(undefined4 **)(iStack_1c + 0xac);
      uVar7 = uVar10;
      if ((*(int *)(iStack_1c + 0xa8) - (int)puStack_14) / 0x48 <= (int)uVar10) {
        uVar7 = uVar10 - (*(int *)(iStack_1c + 0xa8) - *(int *)(iStack_1c + 0xa4)) / 0x48;
      }
      uStack_28 = 0;
      uStack_24 = 0xf;
      piVar11 = puStack_14 + (uVar7 * 9 + 1) * 2;
      auStack_38[0] = auStack_38[0] & 0xffffff00;
      FUN_005542c0("message",7);
      iStack_8 = CONCAT31(iStack_8._1_3_,3);
      iVar4 = FUN_005c4c00(auStack_38);
      puStack_18 = (undefined4 *)(iVar4 + 0x18);
      uVar5 = FUN_0088cb40();
      *puStack_18 = uVar5;
      piStack_20 = (int *)FUN_005c9d30();
      piVar1 = (int *)puStack_18[1];
      puVar8 = puStack_18 + 2;
      if (piVar1 == piStack_20) {
        if (puVar8 != piVar11) {
          piVar1 = piVar11 + 4;
          if (0xf < (uint)piVar11[5]) {
            piVar11 = (int *)*piVar11;
          }
          FUN_005542c0(piVar11,*piVar1);
        }
      }
      else {
        if (piVar1 != (int *)0x0) {
          puStack_14 = puVar8;
          (*(code *)piVar1[2])(puVar8);
          puStack_18[1] = 0;
        }
        FUN_0054ef60(piVar11);
        puStack_18[1] = piStack_20;
      }
      iStack_8._0_1_ = 1;
      if (0xf < uStack_24) {
        uVar9 = uStack_24 + 1;
        uVar7 = auStack_38[0];
        if (0xfff < uVar9) {
          uVar7 = *(uint *)(auStack_38[0] - 4);
          uVar9 = uStack_24 + 0x24;
          if (0x1f < (auStack_38[0] - uVar7) - 4) goto LAB_00bdc06e;
        }
        FUN_01674ea0(uVar7,uVar9);
      }
      puStack_18 = *(undefined4 **)(iStack_1c + 0xac);
      uVar7 = uVar10;
      if ((*(int *)(iStack_1c + 0xa8) - (int)puStack_18) / 0x48 <= (int)uVar10) {
        uVar7 = uVar10 - (*(int *)(iStack_1c + 0xa8) - *(int *)(iStack_1c + 0xa4)) / 0x48;
      }
      puStack_14 = (undefined4 *)(uVar7 * 9);
      uStack_28 = 0;
      uStack_24 = 0xf;
      auStack_38[0] = auStack_38[0] & 0xffffff00;
      FUN_005542c0("messageType",0xb);
      iStack_8 = CONCAT31(iStack_8._1_3_,4);
      iVar4 = FUN_005c4c00(auStack_38);
      uVar5 = thunk_FUN_0086f380();
      *(undefined4 *)(iVar4 + 0x18) = uVar5;
      piStack_20 = (int *)FUN_0086f410();
      piVar11 = *(int **)(iVar4 + 0x1c);
      if (piVar11 == piStack_20) {
        *(undefined4 *)(iVar4 + 0x20) = puStack_18[(int)puStack_14 * 2];
      }
      else {
        if (piVar11 != (int *)0x0) {
          (*(code *)piVar11[2])(iVar4 + 0x20);
          *(undefined4 *)(iVar4 + 0x1c) = 0;
        }
        *(undefined4 *)(iVar4 + 0x20) = puStack_18[(int)puStack_14 * 2];
        *(int **)(iVar4 + 0x1c) = piStack_20;
      }
      iStack_8._0_1_ = 1;
      if (0xf < uStack_24) {
        uVar9 = uStack_24 + 1;
        uVar7 = auStack_38[0];
        if (0xfff < uVar9) {
          uVar7 = *(uint *)(auStack_38[0] - 4);
          uVar9 = uStack_24 + 0x24;
          if (0x1f < (auStack_38[0] - uVar7) - 4) {
LAB_00bdc06e:
            iStack_8._0_1_ = 1;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar7,uVar9);
      }
      if (piVar2 != (int *)0x0) {
        LOCK();
        piVar2[1] = piVar2[1] + 1;
        UNLOCK();
      }
      iStack_8._0_1_ = 5;
      piStack_40 = piVar2 + 3;
      piStack_3c = piVar2;
      uStack_120 = FUN_008881d0();
      iStack_11c = 0;
      piStack_40 = (int *)0x0;
      piStack_3c = (int *)0x0;
      piStack_118 = piVar2 + 3;
      piStack_114 = piVar2;
      iStack_11c = FUN_0058c000();
      iVar4 = iStack_48;
      iStack_8 = CONCAT31(iStack_8._1_3_,6);
      if (*(int *)(iStack_48 + 8) == *(int *)(iStack_48 + 4)) {
        FUN_005ca4f0(*(int *)(iStack_48 + 4),&uStack_120);
      }
      else {
        FUN_005caaf0(iStack_48);
        *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 0xd0;
      }
      iStack_8._0_1_ = 7;
      if (iStack_11c != 0) {
        (**(code **)(iStack_11c + 8))(&piStack_118);
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar4 = piVar2[1] + -1;
        piVar2[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar4 = piVar2[2] + -1;
          piVar2[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      uVar10 = uVar10 + 1;
      param_1 = iStack_1c;
    } while (uVar10 < *(uint *)(iStack_1c + 0xb4));
  }
  *param_2 = iStack_48;
  param_2[1] = iStack_44;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26489 ; VA 0x00bdc080 ; FUN_00bdc080 */

void FUN_00bdc080(uint param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  char *pcVar6;
  byte **ppbVar7;
  byte *pbVar8;
  int *in_stack_00000028;
  int *in_stack_0000002c;
  byte **in_stack_00000030;
  undefined auStack_b8 [40];
  undefined4 uStack_90;
  undefined4 uStack_7c;
  int *piStack_78;
  byte **ppbStack_74;
  byte **ppbStack_70;
  byte ***pppbStack_6c;
  byte *apbStack_5c [4];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  byte **appbStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  int iStack_2c;
  int *piStack_28;
  byte *pbStack_24;
  int *piStack_20;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01800fd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pppbStack_6c = (byte ***)&iStack_2c;
  ppbStack_70 = (byte **)0xbdc0b1;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  if (iStack_2c != 0) {
    pbStack_24 = (byte *)0x0;
    piStack_20 = (int *)0x0;
    uStack_34 = 0;
    uStack_30 = 0xf;
    appbStack_44[0] = (byte **)((uint)appbStack_44[0] & 0xffffff00);
    pppbStack_6c = appbStack_44;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    ppbStack_70 = &pbStack_24;
    ppbStack_74 = in_stack_00000030;
    piStack_78 = in_stack_0000002c;
    uStack_7c = 0xbdc0f5;
    cVar4 = FUN_00e57b80();
    pbVar8 = pbStack_24;
    if (cVar4 != '\0') {
      pppbStack_6c = (byte ***)0x9;
      ppbStack_70 = (byte **)0x192cdac;
      uStack_4c = 0;
      uStack_48 = 0xf;
      apbStack_5c[0]._0_1_ = 0;
      ppbStack_74 = (byte **)0xbdc124;
      FUN_005542c0();
      pbVar8 = pbVar8 + *pbVar8 + 1;
      pppbStack_6c = (byte ***)apbStack_5c;
      ppbStack_74 = (byte **)0xbdc136;
      ppbStack_70 = (byte **)pbVar8;
      ppbStack_74 = (byte **)FUN_0055c740();
      ppbStack_70 = apbStack_5c;
      pppbStack_6c = (byte ***)(-(uint)(pbVar8 != (byte *)0x0) & (uint)(pbVar8 + 1));
      piStack_78 = &iStack_14;
      uStack_7c = 0xbdc153;
      FUN_00562fc0();
      pppbStack_6c = (byte ***)0xbdc15b;
      FUN_005507b0();
      if (iStack_14 != 0) {
        iVar3 = *(int *)(iStack_14 + 0x20);
        pppbStack_6c = (byte ***)0xbdc16d;
        iVar5 = FUN_0088daf0();
        if (iVar3 == iVar5) {
          pppbStack_6c = (byte ***)0xbdc178;
          pcVar6 = (char *)FUN_00605c60();
          if (*pcVar6 != '\0') {
            pppbStack_6c = (byte ***)iStack_2c;
            ppbStack_70 = (byte **)0xbdc185;
            iStack_18 = FUN_008f7870();
            if (iStack_18 != 0) {
              pppbStack_6c = (byte ***)0x1;
              iStack_14 = CONCAT31(iStack_14._1_3_,DAT_01ef68fc);
              uStack_90 = 0;
              FUN_0054f510(&param_1);
              FUN_00ae2be0(auStack_b8,FUN_00ae6a70,iStack_14);
              FUN_00ae2040();
              uStack_90 = 0xbdc1d4;
              FUN_0090ca30();
            }
          }
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (0xf < uStack_30) {
      pppbStack_6c = (byte ***)(uStack_30 + 1);
      ppbVar7 = appbStack_44[0];
      if (0xfff < pppbStack_6c) {
        ppbVar7 = (byte **)appbStack_44[0][-1];
        pppbStack_6c = (byte ***)(uStack_30 + 0x24);
        if (0x1f < (uint)((int)appbStack_44[0] + (-4 - (int)ppbVar7))) {
                    /* WARNING: Subroutine does not return */
          pppbStack_6c = (byte ***)&UNK_00bdc2bf;
          FUN_017167a3();
        }
      }
      ppbStack_74 = (byte **)0xbdc209;
      ppbStack_70 = ppbVar7;
      FUN_01674ea0();
    }
    piVar2 = piStack_20;
    uStack_34 = 0;
    uStack_30 = 0xf;
    appbStack_44[0] = (byte **)((uint)appbStack_44[0] & 0xffffff00);
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_20[1] + -1;
      piStack_20[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        pppbStack_6c = (byte ***)0xbdc234;
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          pppbStack_6c = (byte ***)0xbdc244;
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_28[1] + -1;
    piStack_28[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      pppbStack_6c = (byte ***)0xbdc25a;
      (**(code **)*piStack_28)();
      LOCK();
      iVar3 = piStack_28[2] + -1;
      piStack_28[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        pppbStack_6c = (byte ***)0xbdc26a;
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (param_1 != 0) {
    if (((param_1 & 1) == 0) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0)) {
      ppbStack_74 = (byte **)&stack0x0000000c;
      pppbStack_6c = (byte ***)0x2;
      piStack_78 = (int *)0xbdc28b;
      ppbStack_70 = ppbStack_74;
      (**(code **)(param_1 & 0xfffffffe))();
    }
    param_1 = 0;
  }
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    piVar2 = in_stack_00000028 + 2;
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      pppbStack_6c = (byte ***)0xbdc2a9;
      (**(code **)(*in_stack_00000028 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26490 ; VA 0x00bdc2c0 ; FUN_00bdc2c0 */

undefined * FUN_00bdc2c0(undefined *param_1,undefined4 param_2)

{
  char *pcVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792429;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_005542c0("Unknown",7);
  uStack_8 = 0;
  switch(param_2) {
  case 0:
    uVar2 = 7;
    pcVar1 = "Default";
    break;
  case 1:
    uVar2 = 9;
    pcVar1 = "DataStore";
    break;
  case 2:
    uVar2 = 0x12;
    pcVar1 = "MarketplaceService";
    break;
  case 3:
    uVar2 = 0xb;
    pcVar1 = "HttpService";
    break;
  case 4:
    uVar2 = 0xf;
    pcVar1 = "ContentProvider";
    break;
  case 5:
    uVar2 = 0xf;
    pcVar1 = "GamePassService";
    break;
  case 6:
    uVar2 = 0xd;
    pcVar1 = "InsertService";
    break;
  case 7:
    uVar2 = 7;
    pcVar1 = "Players";
    break;
  case 8:
    uVar2 = 0xc;
    pcVar1 = "AssetService";
    break;
  case 9:
    uVar2 = 9;
    pcVar1 = "AdService";
    break;
  case 10:
    uVar2 = 0xc;
    pcVar1 = "GroupService";
    break;
  case 0xb:
    uVar2 = 0xd;
    pcVar1 = "PointsService";
    break;
  case 0xc:
    uVar2 = 0xf;
    pcVar1 = "TeleportService";
    break;
  case 0xd:
    uVar2 = 0xc;
    pcVar1 = "BadgeService";
    break;
  case 0xe:
    uVar2 = 0xc;
    pcVar1 = "SoundService";
    break;
  case 0xf:
    uVar2 = 4;
    pcVar1 = "Chat";
    break;
  case 0x10:
    uVar2 = 6;
    pcVar1 = "Avatar";
    break;
  case 0x11:
    uVar2 = 0xc;
    pcVar1 = "AvatarEditor";
    break;
  case 0x12:
    uVar2 = 0xd;
    pcVar1 = "ScriptContext";
    break;
  case 0x13:
    uVar2 = 0xd;
    pcVar1 = "FriendService";
    break;
  case 0x14:
    uVar2 = 8;
    pcVar1 = "Presence";
    break;
  case 0x15:
    uVar2 = 5;
    pcVar1 = "Games";
    break;
  case 0x16:
    uVar2 = 6;
    pcVar1 = "ChatV2";
    break;
  case 0x17:
    uVar2 = 9;
    pcVar1 = "Analytics";
    break;
  case 0x18:
    uVar2 = 0xd;
    pcVar1 = "SocialService";
    break;
  case 0x19:
    uVar2 = 0xc;
    pcVar1 = "Localization";
    break;
  case 0x1a:
    uVar2 = 0x10;
    pcVar1 = "AnalyticsService";
    break;
  case 0x1b:
    uVar2 = 9;
    pcVar1 = "WebSocket";
    break;
  case 0x1c:
    uVar2 = 0xb;
    pcVar1 = "UserService";
    break;
  default:
    goto switchD_00bdc324_caseD_1d;
  }
  FUN_005542c0(pcVar1,uVar2);
switchD_00bdc324_caseD_1d:
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26491 ; VA 0x00bdc4f0 ; FUN_00bdc4f0 */

void FUN_00bdc4f0(undefined4 *param_1)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  pcVar2 = (code *)*param_1;
  if (param_1[4] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[4] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar3 = param_1[3];
  uVar4 = param_1[4];
  if (param_1[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar2)(param_1[1],param_1[2],uVar3,uVar4);
  return;
}



/* FUNCTION 26492 ; VA 0x00bdc560 ; FUN_00bdc560 */

void FUN_00bdc560(int *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  code *pcVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801003;
  pvStack_10 = ExceptionList;
  puVar2 = (undefined4 *)*param_1;
  pcVar3 = (code *)*puVar2;
  ExceptionList = &pvStack_10;
  if (puVar2[0x15] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[0x15] + 8);
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0;
  FUN_0054ef60(puVar2 + 8);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(puVar2 + 0xe);
  uStack_8 = 0xffffffff;
  (*pcVar3)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26493 ; VA 0x00bdc620 ; FUN_00bdc620 */

void FUN_00bdc620(int *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  code *pcVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801023;
  pvStack_10 = ExceptionList;
  puVar2 = (undefined4 *)*param_1;
  pcVar3 = (code *)*puVar2;
  ExceptionList = &pvStack_10;
  if (puVar2[0x15] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[0x15] + 8);
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0;
  FUN_0054ef60(puVar2 + 4);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(puVar2 + 10);
  uStack_8 = 0xffffffff;
  (*pcVar3)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26494 ; VA 0x00bdc6e0 ; FUN_00bdc6e0 */

void FUN_00bdc6e0(int *param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  code *pcVar3;
  uint uVar4;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801038;
  pvStack_10 = ExceptionList;
  uStack_1c = param_3;
  uStack_20 = param_2;
  puVar2 = (undefined4 *)*param_1;
  pcVar3 = (code *)*puVar2;
  ExceptionList = &pvStack_10;
  if (puVar2[0xb] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[0xb] + 8);
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_28 = puVar2[10];
  uStack_24 = puVar2[0xb];
  uStack_8 = 0;
  uVar4 = puVar2[2];
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      (**(code **)(uVar4 & 0xfffffffe))(puVar2 + 4,&uStack_40,0);
    }
    else {
      uStack_40 = puVar2[4];
      uStack_3c = puVar2[5];
      uStack_38 = puVar2[6];
      uStack_34 = puVar2[7];
      uStack_30 = *(undefined8 *)(puVar2 + 8);
    }
  }
  uStack_8 = 0xffffffff;
  (*pcVar3)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26495 ; VA 0x00bdc7a0 ; FUN_00bdc7a0 */

uint FUN_00bdc7a0(void)

{
  int iVar1;
  
  iVar1 = FUN_00bd5c00();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 26496 ; VA 0x00bdc7c0 ; FUN_00bdc7c0 */

uint FUN_00bdc7c0(void)

{
  int iVar1;
  
  iVar1 = FUN_00bd5c00();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 26497 ; VA 0x00bdc7e0 ; FUN_00bdc7e0 */

void FUN_00bdc7e0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c005f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar4 = (undefined4 *)FUN_01674e20(0x58);
      uStack_8 = 0;
      if (puVar4 != (undefined4 *)0x0) {
        *puVar4 = *puVar1;
        FUN_00bd70d0(puVar1 + 2);
        *param_2 = (int)puVar4;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar5 = *param_2;
      if (iVar5 != 0) {
        piVar2 = *(int **)(iVar5 + 0x54);
        ExceptionList = &pvStack_10;
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = piVar2[2] + -1;
          ExceptionList = &pvStack_10;
          piVar2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
        FUN_00bd8160();
        FUN_01674ea0(iVar5,0x58);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar5 = FUN_0170d8dd(*param_2 + 4,0x1df55bc);
      if (iVar5 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(struct_RBX::HttpResult,class_std::weak_ptr<class_RBX::LogService>),class_boost::_bi::list2<class_boost::_bi::value<struct_RBX::HttpResult>,class_boost::_bi::value<class_std::weak_ptr<class_RBX::LogService>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26498 ; VA 0x00bdc950 ; FUN_00bdc950 */

void FUN_00bdc950(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c005f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar4 = (undefined4 *)FUN_01674e20(0x58);
      uStack_8 = 0;
      if (puVar4 != (undefined4 *)0x0) {
        *puVar4 = *puVar1;
        FUN_00bd7310(puVar1 + 2);
        *param_2 = (int)puVar4;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar5 = *param_2;
      if (iVar5 != 0) {
        piVar2 = *(int **)(iVar5 + 0x54);
        ExceptionList = &pvStack_10;
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = piVar2[2] + -1;
          ExceptionList = &pvStack_10;
          piVar2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
        FUN_00651cc0();
        FUN_01674ea0(iVar5,0x58);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar5 = FUN_0170d8dd(*param_2 + 4,0x1df5684);
      if (iVar5 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(struct_RBX::StandardOutMessage,class_std::weak_ptr<class_RBX::LogService>),class_boost::_bi::list2<class_boost::_bi::value<struct_RBX::StandardOutMessage>,class_boost::_bi::value<class_std::weak_ptr<class_RBX::LogService>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26499 ; VA 0x00bdcac0 ; FUN_00bdcac0 */

void FUN_00bdcac0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c49af;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar5 = (undefined4 *)FUN_01674e20(0x30);
      uStack_8 = 0;
      if (puVar5 != (undefined4 *)0x0) {
        *puVar5 = *puVar1;
        FUN_00967510(puVar1 + 2);
        *param_2 = (int)puVar5;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar6 = *param_2;
      if (iVar6 != 0) {
        piVar2 = *(int **)(iVar6 + 0x2c);
        ExceptionList = &pvStack_10;
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar4 = piVar2[2] + -1;
          ExceptionList = &pvStack_10;
          piVar2[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
        uVar3 = *(uint *)(iVar6 + 8);
        uStack_8 = 1;
        if (uVar3 != 0) {
          if ((uVar3 & 1) == 0) {
            if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
              (**(code **)(uVar3 & 0xfffffffe))(iVar6 + 0x10,iVar6 + 0x10,2);
            }
          }
          *(undefined4 *)(iVar6 + 8) = 0;
        }
        FUN_01674ea0(iVar6,0x30);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar6 = FUN_0170d8dd(*param_2 + 4,0x1df547c);
      if (iVar6 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_boost::function<void___cdecl(void)>,class_std::weak_ptr<class_RBX::LogService>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>*,class_std::exception*),class_boost::_bi::list4<class_boost::_bi::value<class_boost::function<void___cdecl(void)>_>,class_boost::_bi::value<class_std::weak_ptr<class_RBX::LogService>_>,struct_boost::arg<1>,struct_boost::arg<2>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}


