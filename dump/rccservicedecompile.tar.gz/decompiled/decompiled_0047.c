/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 11750 ; VA 0x007c25d0 ; FUN_007c25d0 */

void __fastcall FUN_007c25d0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_007c62b0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 11751 ; VA 0x007c25e0 ; FUN_007c25e0 */

void __fastcall FUN_007c25e0(int param_1)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0xc);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (iVar1 != 0) {
    iVar2 = *(int *)(param_1 + 0x14) - iVar1 >> 2;
    if (iVar2 == 1) {
      ExceptionList = &pvStack_10;
      FUN_0061e220(iVar1);
    }
    else {
      ExceptionList = &pvStack_10;
      FUN_0061e2d0(iVar1,iVar2);
    }
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_007c20b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11752 ; VA 0x007c2660 ; FUN_007c2660 */

void __fastcall FUN_007c2660(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      puVar2 = *(undefined4 **)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      ExceptionList = &pvStack_10;
      do {
        *puVar1 = *puVar2;
        FUN_007c7240(puVar2);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar2 = (undefined4 *)*puVar1;
      } while (puVar2 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar3 = *(int *)(param_1 + 4) + 1;
    if (iVar3 == 1) {
      FUN_0061e220(iVar4);
    }
    else {
      FUN_0061e2d0(iVar4,iVar3);
    }
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11753 ; VA 0x007c2670 ; FUN_007c2670 */

void __fastcall FUN_007c2670(int *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  iVar4 = *param_1;
  if (iVar4 != 0) {
    iVar5 = param_1[1];
    if (iVar4 != iVar5) {
      do {
        piVar1 = *(int **)(iVar4 + 4);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[1] + -1;
          piVar1[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar2 = piVar1[2] + -1;
            piVar1[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        iVar4 = iVar4 + 0x44;
      } while (iVar4 != iVar5);
      iVar4 = *param_1;
    }
    uVar3 = ((param_1[2] - iVar4) / 0x44) * 0x44;
    iVar5 = iVar4;
    if (0xfff < uVar3) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 11754 ; VA 0x007c2730 ; thunk_FUN_007c4590 */

void __fastcall thunk_FUN_007c4590(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_007be6b0(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x1c) * 0x1c;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 11755 ; VA 0x007c2740 ; FUN_007c2740 */

void __fastcall FUN_007c2740(int *param_1)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  if (iVar1 != 0) {
    iVar2 = param_1[2] - iVar1 >> 2;
    if (iVar2 == 1) {
      ExceptionList = &pvStack_10;
      FUN_0061e220(iVar1);
    }
    else {
      ExceptionList = &pvStack_10;
      FUN_0061e2d0(iVar1,iVar2);
    }
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11756 ; VA 0x007c27b0 ; FUN_007c27b0 */

void __fastcall FUN_007c27b0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x30) * 0x30;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 11757 ; VA 0x007c2820 ; FUN_007c2820 */

void __fastcall FUN_007c2820(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3160;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::SceneUpdater::vftable;
  puStack_14 = param_1;
  if (param_1[0x53] == 0) {
    puVar7 = (undefined4 *)0x0;
  }
  else {
    puVar7 = *(undefined4 **)(param_1[0x56] + param_1[0x52] * 4);
  }
  for (; puVar7 != (undefined4 *)0x0; puVar7 = (undefined4 *)*puVar7) {
    iVar5 = puVar7[2];
    FUN_0085dc10();
    if (iVar5 != 0) {
      FUN_007c2fc0();
      FUN_01674ea0(iVar5,100);
    }
  }
  iVar5 = param_1[0xba];
  if (iVar5 != 0) {
    uVar6 = (param_1[0xbc] - iVar5 >> 2) * 4;
    iVar8 = iVar5;
    if (0xfff < uVar6) {
      iVar8 = *(int *)(iVar5 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar5 - iVar8) - 4U) goto LAB_007c2fb0;
    }
    FUN_01674ea0(iVar8,uVar6);
    param_1[0xba] = 0;
    param_1[0xbb] = 0;
    param_1[0xbc] = 0;
  }
  iVar5 = param_1[0xb7];
  if (iVar5 != 0) {
    uVar6 = (param_1[0xb9] - iVar5 >> 2) * 4;
    iVar8 = iVar5;
    if (0xfff < uVar6) {
      iVar8 = *(int *)(iVar5 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar5 - iVar8) - 4U) goto LAB_007c2fb0;
    }
    FUN_01674ea0(iVar8,uVar6);
    param_1[0xb7] = 0;
    param_1[0xb8] = 0;
    param_1[0xb9] = 0;
  }
  piVar2 = (int *)param_1[0xb6];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar5 = piVar2[1] + -1;
    piVar2[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar5 = piVar2[2] + -1;
      piVar2[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_016f32d1(param_1 + 0xa3,0xc,6,FUN_007c2040);
  iVar5 = param_1[0x9a];
  if (iVar5 != 0) {
    uVar6 = (param_1[0x9c] - iVar5 >> 2) * 4;
    iVar8 = iVar5;
    if (0xfff < uVar6) {
      iVar8 = *(int *)(iVar5 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar5 - iVar8) - 4U) goto LAB_007c2fb0;
    }
    FUN_01674ea0(iVar8,uVar6);
    param_1[0x9a] = 0;
    param_1[0x9b] = 0;
    param_1[0x9c] = 0;
  }
  FUN_007c2350();
  iVar5 = param_1[0x91];
  if (iVar5 != 0) {
    uVar6 = (param_1[0x93] - iVar5 >> 2) * 4;
    iVar8 = iVar5;
    if (0xfff < uVar6) {
      iVar8 = *(int *)(iVar5 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar5 - iVar8) - 4U) goto LAB_007c2fb0;
    }
    FUN_01674ea0(iVar8,uVar6);
    param_1[0x91] = 0;
    param_1[0x92] = 0;
    param_1[0x93] = 0;
  }
  iVar5 = param_1[0x8e];
  if (iVar5 != 0) {
    uVar6 = (param_1[0x90] - iVar5 >> 2) * 4;
    iVar8 = iVar5;
    if (0xfff < uVar6) {
      iVar8 = *(int *)(iVar5 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar5 - iVar8) - 4U) goto LAB_007c2fb0;
    }
    FUN_01674ea0(iVar8,uVar6);
    param_1[0x8e] = 0;
    param_1[0x8f] = 0;
    param_1[0x90] = 0;
  }
  iVar5 = param_1[0x8b];
  if (iVar5 != 0) {
    uVar6 = (param_1[0x8d] - iVar5 >> 2) * 4;
    iVar8 = iVar5;
    if (0xfff < uVar6) {
      iVar8 = *(int *)(iVar5 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar5 - iVar8) - 4U) goto LAB_007c2fb0;
    }
    FUN_01674ea0(iVar8,uVar6);
    param_1[0x8b] = 0;
    param_1[0x8c] = 0;
    param_1[0x8d] = 0;
  }
  iVar5 = param_1[0x88];
  if (iVar5 != 0) {
    uVar6 = (param_1[0x8a] - iVar5 >> 2) * 4;
    iVar8 = iVar5;
    if (0xfff < uVar6) {
      iVar8 = *(int *)(iVar5 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar5 - iVar8) - 4U) goto LAB_007c2fb0;
    }
    FUN_01674ea0(iVar8,uVar6);
    param_1[0x88] = 0;
    param_1[0x89] = 0;
    param_1[0x8a] = 0;
  }
  FUN_00641040();
  iVar5 = param_1[0x7d];
  iVar8 = param_1[0x80];
  iVar3 = param_1[0x7c];
  if (iVar5 - param_1[0x7e] >> 3 <= iVar8) {
    iVar8 = iVar8 - (iVar5 - iVar3 >> 3);
  }
  param_1[0x7e] = param_1[0x7e] + iVar8 * 8;
  if (iVar3 != 0) {
    uVar6 = iVar5 - iVar3 & 0xfffffff8;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_007c2fb0;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  iVar5 = param_1[0x79];
  if (iVar5 != 0) {
    uVar6 = (param_1[0x7b] - iVar5 >> 3) * 8;
    iVar8 = iVar5;
    if (0xfff < uVar6) {
      iVar8 = *(int *)(iVar5 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar5 - iVar8) - 4U) {
LAB_007c2fb0:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar6);
    param_1[0x79] = 0;
    param_1[0x7a] = 0;
    param_1[0x7b] = 0;
  }
  iVar5 = param_1[0x74];
  uStack_8 = 0;
  if (iVar5 != 0) {
    iVar8 = param_1[0x76] - iVar5 >> 2;
    if (iVar8 == 1) {
      FUN_0061e220(iVar5);
    }
    else {
      FUN_0061e2d0(iVar5,iVar8);
    }
    param_1[0x74] = 0;
    param_1[0x75] = 0;
    param_1[0x76] = 0;
  }
  FUN_007c20b0();
  if (param_1[0x6f] != 0) {
    FUN_007c3ff0(param_1[0x6f]);
  }
  if (param_1[0x6e] != 0) {
    FUN_007c3ff0(param_1[0x6e]);
  }
  if (param_1[0x6d] != 0) {
    FUN_007c3ff0(param_1[0x6d]);
  }
  FUN_005e61c0();
  FUN_007c61e0();
  FUN_007c2500();
  FUN_007c2500();
  uStack_8 = 1;
  FUN_007c6cb0(&puStack_14,*(undefined4 *)param_1[0x4f],(undefined4 *)param_1[0x4f]);
  FUN_01674ea0(param_1[0x4f],0x30);
  FUN_007c6140();
  iVar5 = param_1[0x44];
  uStack_8 = 2;
  if (iVar5 != 0) {
    iVar8 = param_1[0x46] - iVar5 >> 2;
    if (iVar8 == 1) {
      FUN_0061e220(iVar5);
    }
    else {
      FUN_0061e2d0(iVar5,iVar8);
    }
    param_1[0x44] = 0;
    param_1[0x45] = 0;
    param_1[0x46] = 0;
  }
  FUN_007c20b0();
  FUN_007c61e0();
  FUN_007c61e0();
  iVar5 = param_1[0x30];
  uStack_8 = 3;
  if (iVar5 != 0) {
    iVar8 = param_1[0x32] - iVar5 >> 2;
    if (iVar8 == 1) {
      FUN_0061e220(iVar5);
    }
    else {
      FUN_0061e2d0(iVar5,iVar8);
    }
    param_1[0x30] = 0;
    param_1[0x31] = 0;
    param_1[0x32] = 0;
  }
  FUN_007c20b0();
  FUN_007c23d0();
  puVar7 = (undefined4 *)param_1[0x25];
  while (puVar7 != param_1 + 0x25) {
    puVar4 = (undefined4 *)*puVar7;
    *puVar7 = 0;
    puVar7[1] = 0;
    puVar7 = puVar4;
  }
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  iVar5 = param_1[0x20];
  uStack_8 = 4;
  if (iVar5 != 0) {
    iVar8 = param_1[0x22] - iVar5 >> 2;
    if (iVar8 == 1) {
      FUN_0061e220(iVar5);
    }
    else {
      FUN_0061e2d0(iVar5,iVar8);
    }
    param_1[0x20] = 0;
    param_1[0x21] = 0;
    param_1[0x22] = 0;
  }
  FUN_007c20b0();
  FUN_007c25e0();
  FUN_007c25e0();
  uStack_8 = 5;
  FUN_01679490();
  iVar5 = param_1[0xc];
  if (iVar5 != 0) {
    piVar2 = (int *)(iVar5 + 4);
    LOCK();
    iVar8 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar8 == 1) {
      FUN_01674ea0(iVar5);
    }
  }
  uStack_8 = 6;
  FUN_01679490();
  iVar5 = param_1[0xb];
  if (iVar5 != 0) {
    piVar2 = (int *)(iVar5 + 4);
    LOCK();
    iVar8 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar8 == 1) {
      FUN_01674ea0(iVar5);
    }
  }
  uStack_8 = 7;
  FUN_01679490();
  iVar5 = param_1[10];
  if (iVar5 != 0) {
    piVar2 = (int *)(iVar5 + 4);
    LOCK();
    iVar8 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar8 == 1) {
      FUN_01674ea0(iVar5);
    }
  }
  piVar2 = (int *)param_1[6];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar5 = piVar2[1] + -1;
    piVar2[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_006378f0();
  *param_1 = RBX::Voxel2::GridListener::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11758 ; VA 0x007c2fc0 ; FUN_007c2fc0 */

void __fastcall FUN_007c2fc0(int param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  piVar1 = *(int **)(param_1 + 0x5c);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar5 = piVar1[2] + -1;
    piVar1[2] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  iVar5 = *(int *)(param_1 + 0x3c);
  if (iVar5 != 0) {
    uVar3 = ((*(int *)(param_1 + 0x44) - iVar5) / 0xc) * 0xc;
    iVar4 = iVar5;
    if (0xfff < uVar3) {
      iVar4 = *(int *)(iVar5 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar5 - iVar4) - 4U) goto LAB_007c3161;
    }
    FUN_01674ea0(iVar4,uVar3);
    *(undefined4 *)(param_1 + 0x3c) = 0;
    *(undefined4 *)(param_1 + 0x40) = 0;
    *(undefined4 *)(param_1 + 0x44) = 0;
  }
  FUN_006378f0();
  FUN_006378f0();
  iVar5 = *(int *)(param_1 + 0x18);
  if (iVar5 != 0) {
    uVar3 = ((*(int *)(param_1 + 0x20) - iVar5) / 0x30) * 0x30;
    iVar4 = iVar5;
    if (0xfff < uVar3) {
      iVar4 = *(int *)(iVar5 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar5 - iVar4) - 4U) goto LAB_007c3161;
    }
    FUN_01674ea0(iVar4,uVar3);
    *(undefined4 *)(param_1 + 0x18) = 0;
    *(undefined4 *)(param_1 + 0x1c) = 0;
    *(undefined4 *)(param_1 + 0x20) = 0;
  }
  iVar5 = *(int *)(param_1 + 0xc);
  if (iVar5 != 0) {
    iVar4 = *(int *)(param_1 + 0x10);
    if (iVar5 != iVar4) {
      do {
        piVar1 = *(int **)(iVar5 + 4);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[1] + -1;
          piVar1[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar2 = piVar1[2] + -1;
            piVar1[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        iVar5 = iVar5 + 0x44;
      } while (iVar5 != iVar4);
      iVar5 = *(int *)(param_1 + 0xc);
    }
    uVar3 = ((*(int *)(param_1 + 0x14) - iVar5) / 0x44) * 0x44;
    iVar4 = iVar5;
    if (0xfff < uVar3) {
      iVar4 = *(int *)(iVar5 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar5 - iVar4) - 4U) {
LAB_007c3161:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00641040();
  return;
}



/* FUNCTION 11759 ; VA 0x007c3170 ; FUN_007c3170 */

void __fastcall FUN_007c3170(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  uVar2 = param_1[1] - iVar1;
  iVar3 = param_1[4];
  if (param_1[1] - param_1[2] >> 3 <= iVar3) {
    iVar3 = iVar3 - ((int)uVar2 >> 3);
  }
  param_1[2] = param_1[2] + iVar3 * 8;
  if (iVar1 != 0) {
    uVar2 = uVar2 & 0xfffffff8;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  return;
}



/* FUNCTION 11760 ; VA 0x007c31d0 ; FUN_007c31d0 */

undefined4 * __thiscall FUN_007c31d0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  puVar1 = param_2 + 1;
  *param_1 = *param_2;
  if (param_1 + 1 != puVar1) {
    FUN_005507b0();
    uVar2 = param_2[2];
    uVar3 = param_2[3];
    uVar4 = param_2[4];
    param_1[1] = *puVar1;
    param_1[2] = uVar2;
    param_1[3] = uVar3;
    param_1[4] = uVar4;
    *(undefined8 *)(param_1 + 5) = *(undefined8 *)(param_2 + 5);
    param_2[5] = 0;
    param_2[6] = 0xf;
    *(undefined *)puVar1 = 0;
  }
  return param_1;
}



/* FUNCTION 11761 ; VA 0x007c3220 ; FUN_007c3220 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_007c3220(int param_1,uint *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b3178;
  pvStack_10 = ExceptionList;
  uVar3 = *param_2;
  uVar8 = (uVar3 >> 3) + uVar3;
  uVar7 = uVar8 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar5 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      puVar5 = (undefined4 *)*puVar5;
    }
    for (; puVar5 != (undefined4 *)0x0; puVar5 = (undefined4 *)*puVar5) {
      if (uVar8 == puVar5[1]) {
        if (uVar3 == puVar5[2]) {
          if (puVar5 != (undefined4 *)0x0) {
            return puVar5 + 2;
          }
          break;
        }
      }
      else if ((uint)puVar5[1] % *(uint *)(param_1 + 4) != uVar7) break;
    }
  }
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_007c5c80();
  _DAT_0000000c = 0;
  _DAT_00000010 = 0;
  uVar1 = *(uint *)(param_1 + 8);
  uVar7 = uVar1 + 1;
  _DAT_00000008 = uVar3;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar3 = FUN_005d6bb0(uVar7);
    if (uVar3 <= *(uint *)(param_1 + 4)) {
      uVar3 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar3);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    uVar3 = uVar1 >> 1;
    if ((uVar1 >> 1) + uVar1 <= uVar7) {
      uVar3 = 1;
    }
    iVar4 = FUN_005d6bb0(uVar3 + uVar1);
    if (iVar4 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar4);
      puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar2 = (undefined4 *)*puVar5;
      while (puVar2 != (undefined4 *)0x0) {
        uVar3 = (uint)puVar2[1] % *(uint *)(param_1 + 4);
        piVar6 = (int *)(*(int *)(param_1 + 0x14) + uVar3 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar3 * 4) == 0) {
          *piVar6 = (int)puVar5;
          puVar5 = puVar2;
        }
        else {
          *puVar5 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar6;
          *(undefined4 **)*piVar6 = puVar2;
        }
        puVar2 = (undefined4 *)*puVar5;
      }
    }
  }
  uVar3 = uVar8 % *(uint *)(param_1 + 4);
  piVar6 = *(int **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
  puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar3 * 4);
  _DAT_00000004 = uVar8;
  if (piVar6 == (int *)0x0) {
    piVar6 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar6 != 0) {
      *(undefined4 *)
       (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar6 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
    }
    *puVar5 = piVar6;
    _DAT_00000000 = *piVar6;
  }
  else {
    _DAT_00000000 = *piVar6;
    piVar6 = (int *)*puVar5;
  }
  *piVar6 = 0;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return (undefined4 *)&DAT_00000008;
}



/* FUNCTION 11762 ; VA 0x007c33f0 ; FUN_007c33f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_007c33f0(int param_1,uint *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b3198;
  pvStack_10 = ExceptionList;
  uVar3 = *param_2;
  uVar8 = (uVar3 >> 3) + uVar3;
  uVar7 = uVar8 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar5 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      puVar5 = (undefined4 *)*puVar5;
    }
    for (; puVar5 != (undefined4 *)0x0; puVar5 = (undefined4 *)*puVar5) {
      if (uVar8 == puVar5[1]) {
        if (uVar3 == puVar5[2]) {
          if (puVar5 != (undefined4 *)0x0) {
            return puVar5 + 2;
          }
          break;
        }
      }
      else if ((uint)puVar5[1] % *(uint *)(param_1 + 4) != uVar7) break;
    }
  }
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_007c5c80();
  _DAT_0000000c = 0;
  _DAT_00000010 = 0;
  uVar1 = *(uint *)(param_1 + 8);
  uVar7 = uVar1 + 1;
  _DAT_00000008 = uVar3;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar3 = FUN_005d6bb0(uVar7);
    if (uVar3 <= *(uint *)(param_1 + 4)) {
      uVar3 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar3);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    uVar3 = uVar1 >> 1;
    if ((uVar1 >> 1) + uVar1 <= uVar7) {
      uVar3 = 1;
    }
    iVar4 = FUN_005d6bb0(uVar3 + uVar1);
    if (iVar4 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar4);
      puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar2 = (undefined4 *)*puVar5;
      while (puVar2 != (undefined4 *)0x0) {
        uVar3 = (uint)puVar2[1] % *(uint *)(param_1 + 4);
        piVar6 = (int *)(*(int *)(param_1 + 0x14) + uVar3 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar3 * 4) == 0) {
          *piVar6 = (int)puVar5;
          puVar5 = puVar2;
        }
        else {
          *puVar5 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar6;
          *(undefined4 **)*piVar6 = puVar2;
        }
        puVar2 = (undefined4 *)*puVar5;
      }
    }
  }
  uVar3 = uVar8 % *(uint *)(param_1 + 4);
  piVar6 = *(int **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
  puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar3 * 4);
  _DAT_00000004 = uVar8;
  if (piVar6 == (int *)0x0) {
    piVar6 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar6 != 0) {
      *(undefined4 *)
       (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar6 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
    }
    *puVar5 = piVar6;
    _DAT_00000000 = *piVar6;
  }
  else {
    _DAT_00000000 = *piVar6;
    piVar6 = (int *)*puVar5;
  }
  *piVar6 = 0;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return (undefined4 *)&DAT_00000008;
}



/* FUNCTION 11763 ; VA 0x007c35c0 ; FUN_007c35c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint * __thiscall FUN_007c35c0(byte *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  undefined4 *puVar3;
  uint uVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  undefined4 *puVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b31b8;
  pvStack_10 = ExceptionList;
  uVar4 = *param_2;
  uVar7 = (uVar4 >> 3) + uVar4;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&param_2,uVar7,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (uint *)0x0) {
    uStack_8 = 0;
    FUN_00619db0();
    _DAT_0000000c = 0;
    _DAT_00000010 = 0;
    uVar2 = *(uint *)(param_1 + 8);
    uVar1 = uVar2 + 1;
    _DAT_00000008 = uVar4;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar4 = FUN_005d6bb0(uVar1);
      if (uVar4 <= *(uint *)(param_1 + 4)) {
        uVar4 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar4);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar1) {
      param_2 = (uint *)0x1;
      uVar4 = uVar2 >> 1;
      if ((uVar2 >> 1) + uVar2 <= uVar1) {
        uVar4 = 1;
      }
      iVar5 = FUN_005d6bb0(uVar4 + uVar2);
      if (iVar5 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar5);
        puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar3 = (undefined4 *)*puVar8;
        while (puVar3 != (undefined4 *)0x0) {
          piVar6 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar6 = (int)puVar8;
            puVar8 = puVar3;
          }
          else {
            *puVar8 = *puVar3;
            *puVar3 = *(undefined4 *)*piVar6;
            *(undefined4 **)*piVar6 = puVar3;
          }
          puVar3 = (undefined4 *)*puVar8;
        }
      }
    }
    uVar4 = uVar7 % *(uint *)(param_1 + 4);
    piVar6 = *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
    puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
    _DAT_00000004 = uVar7;
    if (piVar6 == (int *)0x0) {
      piVar6 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar6 != 0) {
        *(undefined4 *)
         (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar6 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
      }
      *puVar8 = piVar6;
      _DAT_00000000 = *piVar6;
    }
    else {
      _DAT_00000000 = *piVar6;
      piVar6 = (int *)*puVar8;
    }
    *piVar6 = 0;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return (uint *)&DAT_00000008;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 11764 ; VA 0x007c3770 ; FUN_007c3770 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint * __thiscall FUN_007c3770(byte *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  undefined4 *puVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b31d8;
  pvStack_10 = ExceptionList;
  uVar5 = *param_2;
  uVar7 = (uVar5 >> 3) + uVar5;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&param_2,uVar7,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (uint *)0x0) {
    uStack_8 = 0;
    FUN_007c5e10();
    _DAT_0000000c = 0;
    _DAT_00000010 = 0;
    _DAT_00000014 = 0;
    uVar2 = *(uint *)(param_1 + 8);
    uVar1 = uVar2 + 1;
    _DAT_00000008 = uVar5;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar5 = FUN_005d6bb0(uVar1);
      if (uVar5 <= *(uint *)(param_1 + 4)) {
        uVar5 = *(uint *)(param_1 + 4);
      }
      FUN_007c5e70(uVar5);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar1) {
      param_2 = (uint *)0x1;
      uVar5 = uVar2 >> 1;
      if ((uVar2 >> 1) + uVar2 <= uVar1) {
        uVar5 = 1;
      }
      iVar6 = FUN_005d6bb0(uVar5 + uVar2);
      if (iVar6 != *(int *)(param_1 + 4)) {
        FUN_007c5e70(iVar6);
        puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar3 = (undefined4 *)*puVar8;
        while (puVar3 != (undefined4 *)0x0) {
          piVar4 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar4 = (int)puVar8;
            puVar8 = puVar3;
          }
          else {
            *puVar8 = *puVar3;
            *puVar3 = *(undefined4 *)*piVar4;
            *(undefined4 **)*piVar4 = puVar3;
          }
          puVar3 = (undefined4 *)*puVar8;
        }
      }
    }
    uVar5 = uVar7 % *(uint *)(param_1 + 4);
    piVar4 = *(int **)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    _DAT_00000004 = uVar7;
    if (piVar4 == (int *)0x0) {
      piVar4 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar4 != 0) {
        *(undefined4 *)
         (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar4 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
      }
      *puVar8 = piVar4;
      _DAT_00000000 = *piVar4;
      *piVar4 = 0;
    }
    else {
      _DAT_00000000 = *piVar4;
      *(undefined4 *)*puVar8 = 0;
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    FUN_007c2260();
    ExceptionList = pvStack_10;
    return (uint *)&DAT_00000008;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 11765 ; VA 0x007c3930 ; FUN_007c3930 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

short * __thiscall FUN_007c3930(int param_1,short *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  uint uVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b31f8;
  pvStack_10 = ExceptionList;
  uVar10 = (int)*param_2 + 0x9e3779b9;
  uVar10 = uVar10 ^ (uVar10 >> 2) + 0x9e3779b9 + uVar10 * 0x40 + (int)param_2[1];
  uVar10 = uVar10 ^ (uVar10 >> 2) + 0x9e3779b9 + uVar10 * 0x40 + (int)param_2[2];
  uVar10 = uVar10 * 0x40 + (uint)(ushort)param_2[3] + (uVar10 >> 2) + 0x9e3779b9 ^ uVar10;
  uVar9 = uVar10 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar6 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      puVar6 = (undefined4 *)*puVar6;
    }
    for (; puVar6 != (undefined4 *)0x0; puVar6 = (undefined4 *)*puVar6) {
      if (uVar10 == puVar6[1]) {
        if ((((*param_2 == *(short *)(puVar6 + 2)) && (param_2[1] == *(short *)((int)puVar6 + 10)))
            && (param_2[2] == *(short *)(puVar6 + 3))) &&
           (param_2[3] == *(short *)((int)puVar6 + 0xe))) {
          return (short *)(puVar6 + 2);
        }
      }
      else if ((uint)puVar6[1] % *(uint *)(param_1 + 4) != uVar9) break;
    }
  }
  uStack_8 = 0;
  uVar1 = *(undefined4 *)param_2;
  uVar2 = *(undefined4 *)(param_2 + 2);
  ExceptionList = &pvStack_10;
  FUN_007c5d70();
  _DAT_00000010 = 0;
  uVar3 = *(uint *)(param_1 + 8);
  uVar9 = uVar3 + 1;
  _DAT_00000008 = uVar1;
  _DAT_0000000c = uVar2;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar9 = FUN_005d6bb0(uVar9);
    if (uVar9 <= *(uint *)(param_1 + 4)) {
      uVar9 = *(uint *)(param_1 + 4);
    }
    FUN_007c5f90(uVar9);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar9) {
    uVar7 = uVar3 >> 1;
    if (uVar3 + uVar7 <= uVar9) {
      uVar7 = 1;
    }
    iVar5 = FUN_005d6bb0(uVar7 + uVar3);
    if (iVar5 != *(int *)(param_1 + 4)) {
      FUN_007c5f90(iVar5);
      puVar6 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar4 = (undefined4 *)*puVar6;
      while (puVar4 != (undefined4 *)0x0) {
        uVar9 = (uint)puVar4[1] % *(uint *)(param_1 + 4);
        piVar8 = (int *)(*(int *)(param_1 + 0x14) + uVar9 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar9 * 4) == 0) {
          *piVar8 = (int)puVar6;
          puVar6 = puVar4;
        }
        else {
          *puVar6 = *puVar4;
          *puVar4 = *(undefined4 *)*piVar8;
          *(undefined4 **)*piVar8 = puVar4;
        }
        puVar4 = (undefined4 *)*puVar6;
      }
    }
  }
  uVar9 = uVar10 % *(uint *)(param_1 + 4);
  piVar8 = *(int **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
  puVar6 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar9 * 4);
  _DAT_00000004 = uVar10;
  if (piVar8 == (int *)0x0) {
    piVar8 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar8 != 0) {
      *(undefined4 *)
       (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar8 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
    }
    *puVar6 = piVar8;
    _DAT_00000000 = *piVar8;
  }
  else {
    _DAT_00000000 = *piVar8;
    piVar8 = (int *)*puVar6;
  }
  *piVar8 = 0;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return (short *)&DAT_00000008;
}



/* FUNCTION 11766 ; VA 0x007c3b70 ; FUN_007c3b70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

short * __thiscall FUN_007c3b70(int param_1,short *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  uint uVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b3218;
  pvStack_10 = ExceptionList;
  uVar10 = (int)*param_2 + 0x9e3779b9;
  uVar10 = uVar10 ^ (uVar10 >> 2) + 0x9e3779b9 + uVar10 * 0x40 + (int)param_2[1];
  uVar10 = uVar10 ^ (uVar10 >> 2) + 0x9e3779b9 + uVar10 * 0x40 + (int)param_2[2];
  uVar10 = uVar10 * 0x40 + (uint)(ushort)param_2[3] + (uVar10 >> 2) + 0x9e3779b9 ^ uVar10;
  uVar9 = uVar10 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar6 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      puVar6 = (undefined4 *)*puVar6;
    }
    for (; puVar6 != (undefined4 *)0x0; puVar6 = (undefined4 *)*puVar6) {
      if (uVar10 == puVar6[1]) {
        if ((((*param_2 == *(short *)(puVar6 + 2)) && (param_2[1] == *(short *)((int)puVar6 + 10)))
            && (param_2[2] == *(short *)(puVar6 + 3))) &&
           (param_2[3] == *(short *)((int)puVar6 + 0xe))) {
          return (short *)(puVar6 + 2);
        }
      }
      else if ((uint)puVar6[1] % *(uint *)(param_1 + 4) != uVar9) break;
    }
  }
  uStack_8 = 0;
  uVar1 = *(undefined4 *)param_2;
  uVar2 = *(undefined4 *)(param_2 + 2);
  ExceptionList = &pvStack_10;
  FUN_007c5d70();
  _DAT_00000010 = 0;
  uVar3 = *(uint *)(param_1 + 8);
  uVar9 = uVar3 + 1;
  _DAT_00000008 = uVar1;
  _DAT_0000000c = uVar2;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar9 = FUN_005d6bb0(uVar9);
    if (uVar9 <= *(uint *)(param_1 + 4)) {
      uVar9 = *(uint *)(param_1 + 4);
    }
    FUN_007c5f90(uVar9);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar9) {
    uVar7 = uVar3 >> 1;
    if (uVar3 + uVar7 <= uVar9) {
      uVar7 = 1;
    }
    iVar5 = FUN_005d6bb0(uVar7 + uVar3);
    if (iVar5 != *(int *)(param_1 + 4)) {
      FUN_007c5f90(iVar5);
      puVar6 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar4 = (undefined4 *)*puVar6;
      while (puVar4 != (undefined4 *)0x0) {
        uVar9 = (uint)puVar4[1] % *(uint *)(param_1 + 4);
        piVar8 = (int *)(*(int *)(param_1 + 0x14) + uVar9 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar9 * 4) == 0) {
          *piVar8 = (int)puVar6;
          puVar6 = puVar4;
        }
        else {
          *puVar6 = *puVar4;
          *puVar4 = *(undefined4 *)*piVar8;
          *(undefined4 **)*piVar8 = puVar4;
        }
        puVar4 = (undefined4 *)*puVar6;
      }
    }
  }
  uVar9 = uVar10 % *(uint *)(param_1 + 4);
  piVar8 = *(int **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
  puVar6 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar9 * 4);
  _DAT_00000004 = uVar10;
  if (piVar8 == (int *)0x0) {
    piVar8 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar8 != 0) {
      *(undefined4 *)
       (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar8 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
    }
    *puVar6 = piVar8;
    _DAT_00000000 = *piVar8;
  }
  else {
    _DAT_00000000 = *piVar8;
    piVar8 = (int *)*puVar6;
  }
  *piVar8 = 0;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return (short *)&DAT_00000008;
}



/* FUNCTION 11767 ; VA 0x007c3db0 ; FUN_007c3db0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

short * __thiscall FUN_007c3db0(int param_1,short *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  uint uVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b3238;
  pvStack_10 = ExceptionList;
  uVar10 = (int)*param_2 + 0x9e3779b9;
  uVar10 = uVar10 ^ (uVar10 >> 2) + 0x9e3779b9 + uVar10 * 0x40 + (int)param_2[1];
  uVar10 = uVar10 ^ (uVar10 >> 2) + 0x9e3779b9 + uVar10 * 0x40 + (int)param_2[2];
  uVar10 = uVar10 * 0x40 + (uint)(ushort)param_2[3] + (uVar10 >> 2) + 0x9e3779b9 ^ uVar10;
  uVar9 = uVar10 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar6 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      puVar6 = (undefined4 *)*puVar6;
    }
    for (; puVar6 != (undefined4 *)0x0; puVar6 = (undefined4 *)*puVar6) {
      if (uVar10 == puVar6[1]) {
        if ((((*param_2 == *(short *)(puVar6 + 2)) && (param_2[1] == *(short *)((int)puVar6 + 10)))
            && (param_2[2] == *(short *)(puVar6 + 3))) &&
           (param_2[3] == *(short *)((int)puVar6 + 0xe))) {
          return (short *)(puVar6 + 2);
        }
      }
      else if ((uint)puVar6[1] % *(uint *)(param_1 + 4) != uVar9) break;
    }
  }
  uStack_8 = 0;
  uVar1 = *(undefined4 *)param_2;
  uVar2 = *(undefined4 *)(param_2 + 2);
  ExceptionList = &pvStack_10;
  FUN_007c5d70();
  _DAT_00000010 = 0;
  uVar3 = *(uint *)(param_1 + 8);
  uVar9 = uVar3 + 1;
  _DAT_00000008 = uVar1;
  _DAT_0000000c = uVar2;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar9 = FUN_005d6bb0(uVar9);
    if (uVar9 <= *(uint *)(param_1 + 4)) {
      uVar9 = *(uint *)(param_1 + 4);
    }
    FUN_007c5f90(uVar9);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar9) {
    uVar7 = uVar3 >> 1;
    if (uVar3 + uVar7 <= uVar9) {
      uVar7 = 1;
    }
    iVar5 = FUN_005d6bb0(uVar7 + uVar3);
    if (iVar5 != *(int *)(param_1 + 4)) {
      FUN_007c5f90(iVar5);
      puVar6 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar4 = (undefined4 *)*puVar6;
      while (puVar4 != (undefined4 *)0x0) {
        uVar9 = (uint)puVar4[1] % *(uint *)(param_1 + 4);
        piVar8 = (int *)(*(int *)(param_1 + 0x14) + uVar9 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar9 * 4) == 0) {
          *piVar8 = (int)puVar6;
          puVar6 = puVar4;
        }
        else {
          *puVar6 = *puVar4;
          *puVar4 = *(undefined4 *)*piVar8;
          *(undefined4 **)*piVar8 = puVar4;
        }
        puVar4 = (undefined4 *)*puVar6;
      }
    }
  }
  uVar9 = uVar10 % *(uint *)(param_1 + 4);
  piVar8 = *(int **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
  puVar6 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar9 * 4);
  _DAT_00000004 = uVar10;
  if (piVar8 == (int *)0x0) {
    piVar8 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar8 != 0) {
      *(undefined4 *)
       (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar8 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
    }
    *puVar6 = piVar8;
    _DAT_00000000 = *piVar8;
  }
  else {
    _DAT_00000000 = *piVar8;
    piVar8 = (int *)*puVar6;
  }
  *piVar8 = 0;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return (short *)&DAT_00000008;
}



/* FUNCTION 11768 ; VA 0x007c3ff0 ; FUN_007c3ff0 */

void FUN_007c3ff0(int param_1)

{
  undefined4 *puVar1;
  
  if (param_1 != 0) {
    if (*(int *)(param_1 + 8) == 0) {
      puVar1 = (undefined4 *)0x0;
    }
    else {
      puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
    }
    for (; puVar1 != (undefined4 *)0x0; puVar1 = (undefined4 *)*puVar1) {
      if ((undefined4 *)puVar1[4] != (undefined4 *)0x0) {
        (*(code *)**(undefined4 **)puVar1[4])(1);
      }
    }
    FUN_007c2460();
    FUN_01674ea0(param_1,0x30);
  }
  return;
}



/* FUNCTION 11769 ; VA 0x007c4040 ; FUN_007c4040 */

undefined4 __thiscall FUN_007c4040(undefined4 param_1,byte param_2)

{
  FUN_007c2820();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2f4);
  }
  return param_1;
}



/* FUNCTION 11770 ; VA 0x007c4070 ; FUN_007c4070 */

void FUN_007c4070(int *param_1,int *param_2)

{
  code *pcVar1;
  int *piVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3258;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar2 = (int *)FUN_007c7780();
  if (piVar2 == (int *)0x0) {
    uVar3 = FUN_0054fbc0();
    uStack_8 = 0;
    FUN_005648a0(uVar3);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
  }
  if (param_1 == (int *)0x0) {
    param_1 = piVar2;
    param_2 = piVar2;
  }
  *piVar2 = (int)param_1;
  piVar2[1] = (int)param_2;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11771 ; VA 0x007c40d0 ; FUN_007c40d0 */

void __fastcall FUN_007c40d0(float *param_1)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  undefined auStack_c [8];
  
  fVar2 = param_1[7];
  fVar3 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
          (float)((double)(int)fVar2 + (double)(&DAT_018c0d90)[-((int)fVar2 >> 0x1f)]);
  if (*param_1 <= fVar3 && fVar3 != *param_1) {
    if ((uint)fVar2 < 0x200) {
      fVar2 = (float)((int)fVar2 << 3);
    }
    else if ((uint)fVar2 < 0x3fffffff) {
      fVar2 = (float)((int)fVar2 * 2);
    }
    FUN_007c43a0(fVar2);
    pfVar1 = (float *)param_1[1];
    if ((float *)*pfVar1 != pfVar1) {
      fVar2 = pfVar1[1];
      do {
        fVar3 = *(float *)param_1[1];
        FUN_007be9f0(auStack_c,(int)fVar3 + 8,fVar3);
      } while (fVar3 != fVar2);
    }
  }
  return;
}



/* FUNCTION 11772 ; VA 0x007c4170 ; FUN_007c4170 */

void __thiscall FUN_007c4170(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined *puVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined4 *puVar7;
  undefined auStack_24 [8];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar3 = param_2;
  puStack_c = &LAB_017b3270;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  piVar1 = param_1 + 1;
  ExceptionList = &pvStack_10;
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  piVar2 = (int *)*piVar1;
  piVar6 = (int *)*piVar2;
  *piVar2 = (int)piVar2;
  *(int *)(*piVar1 + 4) = *piVar1;
  param_1[2] = 0;
  puStack_18 = param_1;
  puVar4 = &stack0xffffffd0;
  if (piVar6 != (int *)*piVar1) {
    do {
      piVar2 = (int *)*piVar6;
      uStack_8 = 0;
      FUN_007c7240(piVar6);
      piVar6 = piVar2;
      puVar4 = puStack_14;
    } while (piVar2 != (int *)*piVar1);
  }
  puStack_14 = puVar4;
  *puStack_18 = *puVar3;
  param_2 = (undefined4 *)*piVar1;
  uStack_8 = 1;
  FUN_007c53e0((int)(puVar3[4] - puVar3[3]) >> 2,&param_2);
  puVar3 = (undefined4 *)puVar3[1];
  puVar7 = (undefined4 *)*puVar3;
  while( true ) {
    if (puVar7 == puVar3) {
      ExceptionList = pvStack_10;
      return;
    }
    param_2 = *(undefined4 **)*piVar1;
    puStack_1c = *(undefined4 **)((int)param_2 + 4);
    uVar5 = FUN_007be5e0(param_2,puStack_1c,puVar7 + 2);
    if (param_1[2] == -2) break;
    param_1[2] = param_1[2] + 1;
    *(undefined4 *)((int)param_2 + 4) = uVar5;
    *puStack_1c = uVar5;
    FUN_007be9f0(auStack_24,*(int *)*piVar1 + 8,*(int *)*piVar1);
    puVar7 = (undefined4 *)*puVar7;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("list<T> too long");
}



/* FUNCTION 11773 ; VA 0x007c427a ; Catch_All@007c427a */

void Catch_All_007c427a(void)

{
  FUN_007c5880();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11774 ; VA 0x007c4290 ; FUN_007c4290 */

void __thiscall FUN_007c4290(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_007be6b0(param_2,param_3,param_1);
  return;
}



/* FUNCTION 11775 ; VA 0x007c42b0 ; FUN_007c42b0 */

void FUN_007c42b0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x2c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x18);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0xf;
  *(undefined *)(param_1 + 0x18) = 0;
  FUN_01674ea0(param_1,0x30);
  return;
}



/* FUNCTION 11776 ; VA 0x007c4310 ; FUN_007c4310 */

void FUN_007c4310(int *param_1)

{
  char cVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  do {
    if (cVar1 != '\0') {
      return;
    }
    FUN_007c4310(param_1[2]);
    uVar2 = param_1[0xb];
    piVar3 = (int *)*param_1;
    if (0xf < uVar2) {
      iVar4 = param_1[6];
      uVar6 = uVar2 + 1;
      iVar5 = iVar4;
      if (0xfff < uVar6) {
        iVar5 = *(int *)(iVar4 + -4);
        uVar6 = uVar2 + 0x24;
        if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar6);
    }
    param_1[10] = 0;
    param_1[0xb] = 0xf;
    *(undefined *)(param_1 + 6) = 0;
    FUN_01674ea0(param_1,0x30);
    cVar1 = *(char *)((int)piVar3 + 0xd);
    param_1 = piVar3;
  } while( true );
}



/* FUNCTION 11777 ; VA 0x007c43a0 ; FUN_007c43a0 */

void __thiscall FUN_007c43a0(int param_1,int param_2)

{
  uint uVar1;
  int iStack_8;
  
  uVar1 = param_2 * 2;
  if ((uint)(*(int *)(param_1 + 0x14) - *(int *)(param_1 + 0xc) >> 2) < uVar1) {
    iStack_8 = param_1;
    if (0x7fffffff < uVar1) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_007c44a0(uVar1);
  }
  iStack_8 = *(int *)(param_1 + 4);
  FUN_007c53e0(uVar1,&iStack_8);
  *(int *)(param_1 + 0x1c) = param_2;
  *(int *)(param_1 + 0x18) = param_2 + -1;
  return;
}



/* FUNCTION 11778 ; VA 0x007c4400 ; FUN_007c4400 */

void __thiscall FUN_007c4400(int *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int iVar7;
  
  iVar1 = param_1[1];
  iVar2 = *param_1;
  iVar3 = FUN_00578020(param_2);
  puVar5 = (undefined4 *)*param_1;
  puVar6 = (undefined4 *)param_1[1];
  if (puVar5 != puVar6) {
    iVar7 = iVar3 - (int)puVar5;
    do {
      *(undefined4 *)(iVar7 + (int)puVar5) = *puVar5;
      *(undefined4 *)(iVar7 + 4 + (int)puVar5) = puVar5[1];
      puVar5 = puVar5 + 2;
    } while (puVar5 != puVar6);
    puVar5 = (undefined4 *)*param_1;
  }
  if (puVar5 != (undefined4 *)0x0) {
    uVar4 = param_1[2] - (int)puVar5 & 0xfffffff8;
    puVar6 = puVar5;
    if (0xfff < uVar4) {
      puVar6 = (undefined4 *)puVar5[-1];
      uVar4 = uVar4 + 0x23;
      if (0x1f < (uint)((int)puVar5 + (-4 - (int)puVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar6,uVar4);
  }
  *param_1 = iVar3;
  param_1[1] = iVar3 + (iVar1 - iVar2 >> 3) * 8;
  param_1[2] = iVar3 + param_2 * 8;
  return;
}



/* FUNCTION 11779 ; VA 0x007c44a0 ; FUN_007c44a0 */

void __thiscall FUN_007c44a0(uint *param_1,int param_2)

{
  uint uVar1;
  uint uVar2;
  code *pcVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3288;
  pvStack_10 = ExceptionList;
  uVar1 = param_1[1];
  uVar2 = *param_1;
  if (param_2 == 1) {
    ExceptionList = &pvStack_10;
    uVar4 = FUN_00621c90();
  }
  else {
    ExceptionList = &pvStack_10;
    uVar4 = FUN_006242e0(param_2);
  }
  if (uVar4 != 0) {
    puVar5 = (undefined4 *)*param_1;
    uVar8 = 0;
    uVar9 = (param_1[1] - (int)puVar5) + 3 >> 2;
    if ((undefined4 *)param_1[1] < puVar5) {
      uVar9 = 0;
    }
    if (uVar9 != 0) {
      iVar7 = uVar4 - (int)puVar5;
      do {
        uVar6 = *puVar5;
        puVar5 = puVar5 + 1;
        uVar8 = uVar8 + 1;
        *(undefined4 *)(iVar7 + -4 + (int)puVar5) = uVar6;
      } while (uVar8 != uVar9);
      puVar5 = (undefined4 *)*param_1;
    }
    uStack_8 = 0xffffffff;
    if (puVar5 != (undefined4 *)0x0) {
      iVar7 = (int)(param_1[2] - (int)puVar5) >> 2;
      if (iVar7 == 1) {
        FUN_0061e220(puVar5);
      }
      else {
        FUN_0061e2d0(puVar5,iVar7);
      }
    }
    *param_1 = uVar4;
    param_1[1] = uVar4 + ((int)(uVar1 - uVar2) >> 2) * 4;
    param_1[2] = uVar4 + param_2 * 4;
    ExceptionList = pvStack_10;
    return;
  }
  uVar6 = FUN_0054fbc0();
  uStack_8 = 0;
  FUN_005648a0(uVar6);
  pcVar3 = (code *)swi(3);
  (*pcVar3)();
  return;
}



/* FUNCTION 11780 ; VA 0x007c4590 ; FUN_007c4590 */

void __fastcall FUN_007c4590(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_007be6b0(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x1c) * 0x1c;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 11781 ; VA 0x007c4610 ; FUN_007c4610 */

int __thiscall FUN_007c4610(int param_1,int *param_2)

{
  int *piVar1;
  undefined uVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  undefined auStack_40 [4];
  int *piStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3356;
  pvStack_10 = ExceptionList;
  iStack_20 = *param_2;
  ExceptionList = &pvStack_10;
  if ((iStack_20 == 0) ||
     (iVar4 = *(int *)(iStack_20 + 0xc), ExceptionList = &pvStack_10, iVar3 = FUN_00d3f900(),
     (uint)*(ushort *)(iVar3 + 0x1da) <
     (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    iStack_20 = 0;
    param_2 = *(int **)(*piVar1 + 0x34);
    if ((param_2 == (int *)0x0) ||
       (iVar4 = *(int *)((int)param_2 + 0xc), iVar3 = FUN_00aff8c0(),
       (uint)*(ushort *)(iVar3 + 0x1da) <
       (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
      param_2 = (int *)0x0;
    }
  }
  else {
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = auStack_58[0] & 0xffffff00;
    FUN_005542c0("Humanoid",8);
    uStack_8 = 0;
    param_2 = (int *)FUN_0063a700(&uStack_38,auStack_58,0);
    param_2 = (int *)*param_2;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if ((param_2 == (int *)0x0) ||
       (iVar4 = *(int *)((int)param_2 + 0xc), iVar3 = FUN_0099be20(),
       (uint)*(ushort *)(iVar3 + 0x1da) <
       (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
      param_2 = (int *)0x0;
    }
    piStack_14 = piStack_34;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_34[1] + -1;
      piStack_34[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        iVar4 = piStack_14[2] + -1;
        piStack_14[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    uStack_8 = 0xffffffff;
    if (0xf < uStack_44) {
      uVar8 = uStack_44 + 1;
      uVar6 = auStack_58[0];
      if (0xfff < uVar8) {
        uVar6 = *(uint *)(auStack_58[0] - 4);
        uVar8 = uStack_44 + 0x24;
        if (0x1f < (auStack_58[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar8);
    }
    uStack_48 = 0;
    uStack_44 = 0xf;
    uVar6 = auStack_58[0] >> 8;
    auStack_58[0] = uVar6 << 8;
    if (param_2 == (int *)0x0) {
      uStack_48 = 0;
      uStack_44 = 0xf;
      auStack_58[0] = uVar6 << 8;
      FUN_005542c0("Torso",5);
      uStack_8 = 2;
      param_2 = (int *)FUN_0063a700(auStack_40,auStack_58,0);
      param_2 = (int *)*param_2;
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      if ((param_2 == (int *)0x0) ||
         (iVar4 = *(int *)((int)param_2 + 0xc), iVar3 = FUN_00aff8c0(),
         (uint)*(ushort *)(iVar3 + 0x1da) <
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
        param_2 = (int *)0x0;
      }
      piStack_14 = piStack_3c;
      if (piStack_3c != (int *)0x0) {
        LOCK();
        iVar4 = piStack_3c[1] + -1;
        piStack_3c[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_3c)();
          LOCK();
          iVar4 = piStack_14[2] + -1;
          piStack_14[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piStack_14 + 4))();
          }
        }
      }
      uStack_8 = 0xffffffff;
      FUN_005507b0();
    }
    else {
      param_2 = (int *)FUN_009b77e0();
    }
  }
  if (((*(char *)(param_1 + 0x1c0) != '\0') &&
      (piStack_14 = (int *)*piVar1, piStack_14 != (int *)0x0)) &&
     (iVar4 = piStack_14[3], iVar3 = FUN_00b63e30(), piVar7 = piStack_14,
     (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
     (uint)*(ushort *)(iVar3 + 0x1da))) {
    iVar4 = *(int *)(param_1 + 0x1bc);
    iVar3 = FUN_00b65b40();
    fVar11 = *(float *)(iVar4 + 0x20) * *(float *)(iVar3 + 0x2c);
    fVar12 = *(float *)(iVar3 + 0x24) * *(float *)(iVar4 + 0x18);
    fVar10 = *(float *)(iVar4 + 0x1c) * *(float *)(iVar3 + 0x28);
    if (fVar11 < 0.0) {
      fVar11 = fVar11 - DAT_018fee54;
    }
    if (fVar10 < 0.0) {
      fVar10 = fVar10 - DAT_018fee54;
    }
    if (fVar12 < 0.0) {
      fVar12 = fVar12 - DAT_018fee54;
    }
    iStack_20 = CONCAT22((short)(int)fVar10,(short)(int)fVar12);
    piStack_14 = (int *)((int)fVar11 & 0xffff);
    uStack_18 = iStack_20;
    iVar4 = FUN_007c3b70(&uStack_18);
    if (*(int *)(iVar4 + 8) == 0) {
      param_2 = (int *)FUN_01674e20(0xd8);
      uStack_8 = 4;
      if (param_2 == (int *)0x0) {
        uVar5 = 0;
      }
      else {
        uVar5 = FUN_008595b0(*(undefined4 *)(param_1 + 0x18c),&uStack_18);
      }
      uStack_8 = 0xffffffff;
      *(undefined4 *)(iVar4 + 8) = uVar5;
    }
    iVar4 = FUN_0085a0e0(piVar7);
    ExceptionList = pvStack_10;
    return iVar4;
  }
  iVar4 = FUN_0170d75d(*piVar1,0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::Effect::RTTI_Type_Descriptor,0);
  if (iVar4 == 0) {
    ExceptionList = pvStack_10;
    return 0;
  }
  if ((*piVar1 == 0) ||
     (iVar4 = *(int *)(*piVar1 + 0xc), iVar3 = FUN_00d41250(),
     (uint)*(ushort *)(iVar3 + 0x1da) <
     (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    piStack_2c = (int *)0x0;
    puVar9 = &uStack_30;
    piVar7 = (int *)&DAT_00000006;
    iStack_28 = 0;
  }
  else {
    piStack_34 = (int *)piVar1[1];
    iStack_28 = *piVar1;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      piStack_34[1] = piStack_34[1] + 1;
      UNLOCK();
      piStack_34 = (int *)piVar1[1];
    }
    puVar9 = &uStack_38;
    piVar7 = (int *)&DAT_00000005;
  }
  piStack_24 = (int *)puVar9[1];
  *puVar9 = 0;
  puVar9[1] = 0;
  if ((((uint)piVar7 & 2) != 0) &&
     (piStack_14 = (int *)((uint)piVar7 & 0xfffffffd), piVar7 = piStack_14, piStack_2c != (int *)0x0
     )) {
    LOCK();
    iVar4 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      iVar4 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar4;
      UNLOCK();
      piVar7 = piStack_14;
      if (iVar4 == 0) {
        (**(code **)(*piStack_2c + 4))();
        piVar7 = piStack_14;
      }
    }
  }
  if ((((uint)piVar7 & 1) != 0) && (piStack_34 != (int *)0x0)) {
    LOCK();
    iVar4 = piStack_34[1] + -1;
    piStack_34[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      iVar4 = piStack_34[2] + -1;
      piStack_34[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  uStack_8 = 5;
  if (iStack_28 == 0) {
    iVar4 = *(int *)(*piVar1 + 0xc);
    iVar3 = FUN_00d3dc90();
    if ((uint)*(ushort *)(iVar3 + 0x1da) <
        (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
      iVar4 = *(int *)(*piVar1 + 0xc);
      iVar3 = FUN_00d3a1d0();
      if ((uint)*(ushort *)(iVar3 + 0x1da) <
          (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
        iVar4 = *(int *)(*piVar1 + 0xc);
        iVar3 = FUN_00d3cec0();
        if ((uint)*(ushort *)(iVar3 + 0x1da) <
            (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
          iVar4 = *(int *)(*piVar1 + 0xc);
          iVar3 = FUN_00d3bb40();
          if ((uint)*(ushort *)(iVar3 + 0x1da) <
              (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
            piStack_14 = (int *)FUN_01674e20(0x198);
            uStack_8._0_1_ = 0xc;
            if (piStack_14 == (int *)0x0) {
              iVar4 = 0;
            }
            else {
              iVar4 = FUN_0084e6d0(*(undefined4 *)(param_1 + 0x18c));
            }
            uStack_8._0_1_ = 5;
            uVar2 = (undefined)uStack_8;
            uStack_8._0_1_ = 5;
            if (iStack_20 == 0) {
              uStack_8._0_1_ = uVar2;
              FUN_00851c70(piVar1);
            }
            else {
              uVar5 = FUN_0060dcd0(&uStack_38,param_2);
              uStack_8._0_1_ = 0xd;
              FUN_00851920(uVar5,piVar1);
              uStack_8._0_1_ = 5;
              FUN_00550b30();
            }
            if (iVar4 != 0) {
              param_2 = (int *)(iVar4 + 0x74);
              goto LAB_007c4d48;
            }
          }
          else {
            param_2 = (int *)FUN_01674e20(0x3a8);
            uStack_8._0_1_ = 0xb;
            if (param_2 == (int *)0x0) {
              iVar4 = 0;
            }
            else {
              iVar4 = FUN_00854800(*(undefined4 *)(param_1 + 0x18c));
            }
            uStack_8._0_1_ = 5;
            FUN_00855a30(piVar1);
            if (iVar4 != 0) {
              param_2 = (int *)(iVar4 + 0x74);
              goto LAB_007c4d48;
            }
          }
        }
        else {
          param_2 = (int *)FUN_01674e20(0x3e0);
          uStack_8._0_1_ = 10;
          if (param_2 == (int *)0x0) {
            iVar4 = 0;
          }
          else {
            iVar4 = FUN_00830190(*(undefined4 *)(param_1 + 0x18c));
          }
          uStack_8._0_1_ = 5;
          FUN_00831a60(piVar1);
          if (iVar4 != 0) {
            param_2 = (int *)(iVar4 + 0x74);
            goto LAB_007c4d48;
          }
        }
      }
      else {
        param_2 = (int *)FUN_01674e20(0xfc);
        uStack_8._0_1_ = 9;
        if (param_2 == (int *)0x0) {
          iVar4 = 0;
        }
        else {
          iVar4 = FUN_00857a30(*(undefined4 *)(param_1 + 0x18c));
        }
        uStack_8._0_1_ = 5;
        FUN_00858a90(piVar1);
        if (iVar4 != 0) {
          param_2 = (int *)(iVar4 + 0x74);
          goto LAB_007c4d48;
        }
      }
    }
    else {
      iStack_20 = FUN_01674e20(0x100);
      uStack_8._0_1_ = 7;
      if (iStack_20 == 0) {
        iVar4 = 0;
      }
      else {
        iVar4 = FUN_00852680(*(undefined4 *)(param_1 + 0x18c));
      }
      uStack_8._0_1_ = 5;
      uVar5 = FUN_0060dcd0(&uStack_38,param_2);
      uStack_8._0_1_ = 8;
      FUN_00853f80(uVar5,piVar1);
      uStack_8._0_1_ = 5;
      FUN_00550b30();
      if (iVar4 != 0) {
        param_2 = (int *)(iVar4 + 0x74);
        goto LAB_007c4d48;
      }
    }
  }
  else {
    param_2 = (int *)FUN_01674e20(0xfc);
    uStack_8._0_1_ = 6;
    if (param_2 == (int *)0x0) {
      iVar4 = 0;
    }
    else {
      iVar4 = FUN_008365b0(*(undefined4 *)(param_1 + 0x18c));
    }
    uStack_8._0_1_ = 5;
    FUN_00836d10(&iStack_28);
    if (iVar4 != 0) {
      param_2 = (int *)(iVar4 + 0x38);
      goto LAB_007c4d48;
    }
  }
  param_2 = (int *)0x0;
LAB_007c4d48:
  iVar4 = FUN_007beb80(auStack_40,&param_2,param_2);
  piVar1 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar7 = piStack_24 + 1;
    iVar3 = *piVar7;
    iVar4 = *piVar7;
    *piVar7 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar4 = (**(code **)*piStack_24)();
      LOCK();
      piVar7 = piVar1 + 2;
      iVar3 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar4 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 11782 ; VA 0x007c4da0 ; FUN_007c4da0 */

void __thiscall FUN_007c4da0(int param_1,int *param_2,int param_3,uint *param_4)

{
  char cVar1;
  ushort uVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  int iVar6;
  int iVar7;
  undefined4 uVar8;
  int *piVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  int *piStack_30;
  undefined4 *puStack_2c;
  uint uStack_28;
  int *piStack_24;
  uint uStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3389;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  uVar3 = FUN_01675290(DAT_01eb2f54);
  iStack_8 = 0;
  uStack_18 = uVar3;
  if ((*(byte *)(*param_2 + 0xb4) & 2) == 0) {
    uStack_14 = 0;
  }
  else {
    uStack_14 = FUN_00b05fc0();
  }
  iVar6 = iStack_1c;
  puStack_2c = (undefined4 *)(uStack_14 >> 0x18);
  uStack_28 = uStack_14 >> 0x10;
  uStack_20 = uStack_14 >> 8;
  if (uStack_14 == 0) {
    iVar6 = FUN_007b5ed0(*param_2);
    if (iVar6 == 0) {
      puStack_2c = *(undefined4 **)(param_1 + 0x1b4);
      iVar6 = *(int *)(*param_2 + 0xa8);
      iVar7 = FUN_00c157b0();
      iVar6 = *(int *)(iVar6 + 0x1ac);
      fVar12 = *(float *)((int)puStack_2c + 0x20) * *(float *)(iVar7 + 0x2c);
      fVar10 = *(float *)((int)puStack_2c + 0x18) * *(float *)(iVar7 + 0x24);
      fVar11 = *(float *)((int)puStack_2c + 0x1c) * *(float *)(iVar7 + 0x28);
      if (fVar12 < 0.0) {
        fVar12 = fVar12 - DAT_018fee54;
      }
      if (fVar11 < 0.0) {
        fVar11 = fVar11 - DAT_018fee54;
      }
      if (fVar10 < 0.0) {
        fVar10 = fVar10 - DAT_018fee54;
      }
      piStack_30 = (int *)CONCAT22((short)(int)fVar11,(short)(int)fVar10);
      if (((*(float *)((int)puStack_2c + 0x24) <= *(float *)(iVar6 + 4)) ||
          (*(float *)((int)puStack_2c + 0x28) <= *(float *)(iVar6 + 8))) ||
         (*(float *)((int)puStack_2c + 0x2c) <= *(float *)(iVar6 + 0xc))) {
        uVar2 = 1;
      }
      else {
        uVar2 = 0;
      }
      uVar2 = ((ushort)param_3 & 0xff) * 2 | uVar2;
      uStack_20 = CONCAT22(uVar2,(short)(int)fVar12);
      puStack_2c = (undefined4 *)(CONCAT31(puStack_2c._1_3_,(char)uVar2) & 0xffffff01);
      piStack_24 = piStack_30;
      iVar6 = FUN_007c3db0(&piStack_24);
      if (*(int *)(iVar6 + 8) == 0) {
        uStack_28 = FUN_01674e20(0x28);
        iStack_8._0_1_ = 3;
        if (uStack_28 == 0) {
          uVar8 = 0;
        }
        else {
          uVar8 = FUN_0084ded0(*(undefined4 *)(param_1 + 0x18c),*(undefined4 *)(param_1 + 0x1b4),
                               &piStack_24,param_3,puStack_2c);
        }
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        *(undefined4 *)(iVar6 + 8) = uVar8;
      }
      FUN_0084dff0(param_2,param_4);
    }
    else {
      FUN_007b4400(&piStack_30,*param_2,0);
      iVar6 = FUN_007c3930(&piStack_30);
      if (*(int *)(iVar6 + 8) == 0) {
        param_3 = FUN_01674e20(0xec);
        iStack_8._0_1_ = 2;
        if (param_3 == 0) {
          iVar7 = 0;
        }
        else {
          iVar7 = FUN_007b1f30(*(undefined4 *)(param_1 + 0x18c),*(undefined4 *)(param_1 + 0x1b8),
                               &piStack_30);
        }
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        *(int *)(iVar6 + 8) = iVar7;
      }
      FUN_007b4da0(param_2);
    }
  }
  else {
    iVar7 = *(int *)(*param_2 + 0xb0);
    if (iVar7 == 0) {
      param_3 = param_1 + 400;
      param_4 = (uint *)(*(uint *)(param_1 + 0x1a8) &
                        ((((uStack_14 & 0xff ^ 0x811c9dc5) * 0x1000193 ^ uStack_20 & 0xff) *
                          0x1000193 ^ uStack_28 & 0xff) * 0x1000193 ^ (uint)puStack_2c) * 0x1000193)
      ;
      piVar9 = *(int **)(*(int *)(param_1 + 0x19c) + (int)param_4 * 8);
      piVar5 = *(int **)(param_1 + 0x194);
      while( true ) {
        piVar4 = piVar5;
        if (*(int **)(*(int *)(param_1 + 0x19c) + (int)param_4 * 8) != piVar5) {
          piVar4 = (int *)**(undefined4 **)(*(int *)(param_1 + 0x19c) + 4 + (int)param_4 * 8);
        }
        if (piVar9 == piVar4) goto LAB_007c4edb;
        if (piVar9[2] == uStack_14) break;
        piVar9 = (int *)*piVar9;
      }
      if (piVar9 == piVar5) {
LAB_007c4edb:
        iVar7 = *piVar5;
        param_4 = &uStack_14;
        puStack_2c = *(undefined4 **)(iVar7 + 4);
        uVar3 = FUN_007086b0(iVar7,puStack_2c,&DAT_018bdeda,&param_4,(int)&param_3 + 3);
        if (*(int *)(iVar6 + 0x198) == 0xffffffe) {
                    /* WARNING: Subroutine does not return */
          FUN_016ddcd9("list<T> too long");
        }
        *(int *)(iVar6 + 0x198) = *(int *)(iVar6 + 0x198) + 1;
        *(undefined4 *)(iVar7 + 4) = uVar3;
        *puStack_2c = uVar3;
        FUN_00708c90(&piStack_30,**(int **)(iVar6 + 0x194) + 8,**(int **)(iVar6 + 0x194));
        piVar9 = piStack_30;
      }
      uVar3 = uStack_18;
      if (piVar9[3] == 0) {
        piVar5 = (int *)FUN_008486e0(*(undefined4 *)(iVar6 + 0x18c),uStack_14,0,0,0);
        piVar9[3] = (int)piVar5;
        if (((DAT_01d622b0 != '\0') && (cVar1 = (**(code **)(*piVar5 + 0x30))(), cVar1 != '\0')) &&
           ((*(int *)(iVar6 + 0x1b0) = piVar9[3], *(int *)(iVar6 + 0x14) != 0 &&
            (DAT_01d5a308 != '\0')))) {
          FUN_009b0820();
          FUN_009020b0(uStack_14);
        }
      }
      (**(code **)(*(int *)piVar9[3] + 0x14))(param_2);
      (**(code **)(*(int *)(piVar9[3] + 0x74) + 8))();
    }
    else if (DAT_01ee4200 != '\0') {
      FUN_01677520(DAT_01ee4200,
                   "Part %p already has a binding %p; skipping add - it will hopefully be requeued by instanced cluster"
                   ,*param_2,iVar7);
    }
  }
  iStack_8 = 4;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11783 ; VA 0x007c51a0 ; FUN_007c51a0 */

void FUN_007c51a0(void)

{
  undefined auStack_c [8];
  
  FUN_007c0ac0(auStack_c,&stack0x00000004,&stack0x00000004);
  return;
}



/* FUNCTION 11784 ; VA 0x007c51c0 ; FUN_007c51c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_007c51c0(int param_1)

{
  code *pcVar1;
  uint uVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179dc58;
  pvStack_10 = ExceptionList;
  if (param_1 == 1) {
    if (DAT_01ead1f1 == '\0') {
      DAT_01ead1f1 = '\x01';
      DAT_01ead1cc = 0;
      uRam01ead1d0 = 0;
      DAT_01ead1d4 = (undefined4 *)0x0;
      DAT_01ead1d8 = 0;
      _DAT_01ead1ec = 0;
      DAT_01ead1dc = _DAT_018ce350;
      _DAT_01ead1e0 = _UNK_018ce354;
      _DAT_01ead1e4 = _UNK_018ce358;
      _DAT_01ead1e8 = _UNK_018ce35c;
    }
    ExceptionList = &pvStack_10;
    FUN_005874f0();
    if (DAT_01ead1d4 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)FUN_00621e70();
    }
    else {
      puVar5 = DAT_01ead1d4;
      DAT_01ead1d4 = (undefined4 *)*DAT_01ead1d4;
    }
    uStack_8 = 0;
  }
  else {
    if (DAT_01ead1f1 == '\0') {
      DAT_01ead1f1 = '\x01';
      DAT_01ead1cc = 0;
      uRam01ead1d0 = 0;
      DAT_01ead1d4 = (undefined4 *)0x0;
      DAT_01ead1d8 = 0;
      _DAT_01ead1ec = 0;
      DAT_01ead1dc = _DAT_018ce350;
      _DAT_01ead1e0 = _UNK_018ce354;
      _DAT_01ead1e4 = _UNK_018ce358;
      _DAT_01ead1e8 = _UNK_018ce35c;
    }
    ExceptionList = &pvStack_10;
    FUN_005874f0();
    puVar5 = (undefined4 *)FUN_00624080(param_1);
    uStack_8 = 1;
  }
  LOCK();
  uVar2 = DAT_01ead1cc + 0x80000000;
  UNLOCK();
  uVar3 = uVar2;
  if (((DAT_01ead1cc & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead1cc)) {
    LOCK();
    DAT_01ead1cc = uVar2 | 0x40000000;
    UNLOCK();
    uVar3 = DAT_01ead1cc;
    if ((uVar2 >> 0x1e & 1) == 0) {
      uVar4 = FUN_00554e40();
      SetEvent(uVar4);
      uVar3 = DAT_01ead1cc;
    }
  }
  DAT_01ead1cc = uVar3;
  uStack_8 = 0xffffffff;
  if (puVar5 != (undefined4 *)0x0) {
    ExceptionList = pvStack_10;
    return puVar5;
  }
  uVar4 = FUN_0054fbc0();
  uStack_8 = 2;
  FUN_005648a0(uVar4);
  pcVar1 = (code *)swi(3);
  puVar5 = (undefined4 *)(*pcVar1)();
  return puVar5;
}



/* FUNCTION 11785 ; VA 0x007c5300 ; FUN_007c5300 */

void FUN_007c5300(int param_1)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794ef8;
  pvStack_10 = ExceptionList;
  if (param_1 == 1) {
    ExceptionList = &pvStack_10;
    iVar2 = FUN_00621c90();
  }
  else {
    ExceptionList = &pvStack_10;
    iVar2 = FUN_006242e0(param_1);
  }
  if (iVar2 != 0) {
    ExceptionList = pvStack_10;
    return;
  }
  uVar3 = FUN_0054fbc0();
  uStack_8 = 0;
  FUN_005648a0(uVar3);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 11786 ; VA 0x007c5360 ; FUN_007c5360 */

void __thiscall FUN_007c5360(int *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  
  puVar2 = param_2;
  iVar1 = param_1[1];
  if (iVar1 < param_1[2]) {
    *(undefined4 *)(*param_1 + iVar1 * 4) = *param_2;
    param_1[1] = param_1[1] + 1;
    return;
  }
  if (((undefined4 *)*param_1 <= param_2) && (param_2 < (undefined4 *)*param_1 + iVar1)) {
    param_2 = (undefined4 *)*param_2;
    FUN_007c5360(&param_2);
    return;
  }
  FUN_0078c900(iVar1 + 1,0);
  *(undefined4 *)(*param_1 + -4 + param_1[1] * 4) = *puVar2;
  return;
}



/* FUNCTION 11787 ; VA 0x007c53d0 ; FUN_007c53d0 */

bool __fastcall FUN_007c53d0(int param_1)

{
  return *(int *)(param_1 + 0x140) != 0;
}



/* FUNCTION 11788 ; VA 0x007c53e0 ; FUN_007c53e0 */

void __thiscall FUN_007c53e0(int *param_1,uint param_2,undefined4 *param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  
  iVar3 = *param_1;
  uVar5 = param_1[2] - iVar3 >> 2;
  uVar2 = param_1[1] - iVar3 >> 2;
  if (uVar5 < param_2) {
    if (0x7fffffff < param_2) {
LAB_007c54f8:
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar2 = param_2;
    if ((uVar5 <= 0x7fffffff - (uVar5 >> 1)) && (uVar2 = (uVar5 >> 1) + uVar5, uVar2 < param_2)) {
      uVar2 = param_2;
    }
    if (iVar3 != 0) {
      if (uVar5 == 1) {
        FUN_0061e220(iVar3);
      }
      else {
        FUN_0061e2d0(iVar3,uVar5);
      }
    }
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    if (uVar2 != 0) {
      if (0x7fffffff < uVar2) goto LAB_007c54f8;
      iVar3 = FUN_007c5300(uVar2);
      *param_1 = iVar3;
      param_1[1] = iVar3;
      param_1[2] = *param_1 + uVar2 * 4;
    }
    puVar4 = (undefined4 *)*param_1;
    if (param_2 != 0) {
      do {
        *puVar4 = *param_3;
        puVar4 = puVar4 + 1;
        param_2 = param_2 - 1;
      } while (param_2 != 0);
      param_1[1] = (int)puVar4;
      return;
    }
  }
  else {
    if (param_2 <= uVar2) {
      iVar1 = iVar3 + param_2 * 4;
      FUN_005ca6d0(iVar3,iVar1,param_3);
      param_1[1] = iVar1;
      return;
    }
    FUN_005ca6d0(iVar3,param_1[1],param_3);
    puVar4 = (undefined4 *)param_1[1];
    for (iVar3 = param_2 - uVar2; iVar3 != 0; iVar3 = iVar3 + -1) {
      *puVar4 = *param_3;
      puVar4 = puVar4 + 1;
    }
  }
  param_1[1] = (int)puVar4;
  return;
}



/* FUNCTION 11789 ; VA 0x007c5500 ; FUN_007c5500 */

undefined4 __thiscall FUN_007c5500(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  char cVar2;
  
  cVar2 = FUN_007c9320(param_2);
  if (cVar2 == '\0') {
    puVar1 = *(undefined4 **)(param_1 + 0x1e8);
    if (3 < (uint)((int)puVar1 - *(int *)(param_1 + 0x1e4) >> 3)) {
      return 0;
    }
    if (*(undefined4 **)(param_1 + 0x1ec) == puVar1) {
      FUN_007be720(puVar1,param_2);
      return 1;
    }
    *puVar1 = *param_2;
    puVar1[1] = param_2[1];
    *(int *)(param_1 + 0x1e8) = *(int *)(param_1 + 0x1e8) + 8;
  }
  return 1;
}



/* FUNCTION 11790 ; VA 0x007c5560 ; FUN_007c5560 */

void __fastcall FUN_007c5560(int param_1)

{
  short *psVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  short sVar5;
  uint uVar6;
  short *psVar7;
  short *psVar8;
  int *piVar9;
  int iVar10;
  int *piVar11;
  int *piVar12;
  undefined8 uVar13;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b33b4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb3068) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb3068);
    if (DAT_01eb3068 == -1) {
      uStack_8 = 0;
      uVar13 = FUN_0152dab0("Render","checkFastClusters",0xffffffff);
      DAT_01eb3064 = (undefined4)((ulonglong)uVar13 >> 0x20);
      DAT_01eb3060 = (undefined4)uVar13;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb3068);
    }
  }
  uVar3 = DAT_01eb3064;
  uVar2 = DAT_01eb3060;
  uVar13 = FUN_0152d930(DAT_01eb3060,DAT_01eb3064);
  uStack_8 = 1;
  FUN_007c0180(0,param_1 + 0x1e4);
  if (((*(int *)(param_1 + 0x3c) != 0) || (*(int *)(param_1 + 0x5c) != 0)) && (DAT_01d6517a != '\0')
     ) {
    FUN_01677490(DAT_01d6517a,"Fast clusters to check for break: %u, fw: %u",
                 *(int *)(param_1 + 0x3c),*(undefined4 *)(param_1 + 0x5c),0);
  }
  do {
    if ((*(int *)(param_1 + 0x3c) == 0) && (*(int *)(param_1 + 0x5c) == 0)) goto LAB_007c57f8;
    if (*(int *)(param_1 + 0x5c) == 0) {
      iVar10 = *(int *)(**(int **)(param_1 + 0x38) + 8);
      if (iVar10 == 0) {
        piVar12 = (int *)0x0;
      }
      else {
        piVar12 = (int *)(iVar10 + -0x74);
      }
    }
    else {
      iVar10 = *(int *)(**(int **)(param_1 + 0x58) + 8);
      piVar12 = (int *)(-(uint)(iVar10 != 0) & iVar10 - 0x74U);
    }
    uVar6 = *(int *)(param_1 + 0x1e8) - *(int *)(param_1 + 0x1e4) >> 3;
    if (3 < uVar6) goto LAB_007c57f8;
    if (2 < uVar6) {
      psVar7 = (short *)(**(code **)(*piVar12 + 0x28))();
      psVar1 = *(short **)(param_1 + 0x1e8);
      psVar8 = *(short **)(param_1 + 0x1e4);
      if (psVar8 == psVar1) {
LAB_007c57f8:
        uStack_8 = 4;
        FUN_0152dda0(uVar2,uVar3,uVar13);
        ExceptionList = pvStack_10;
        return;
      }
      sVar5 = *psVar7;
      do {
        if (*psVar8 == sVar5) {
          if (((psVar8[1] == psVar7[1]) && (psVar8[2] == psVar7[2])) && (psVar8[3] == psVar7[3]))
          break;
          sVar5 = *psVar7;
        }
        psVar8 = psVar8 + 4;
      } while (psVar8 != psVar1);
      if (psVar8 == psVar1) goto LAB_007c57f8;
    }
    cVar4 = (**(code **)(*piVar12 + 0x20))();
    if (cVar4 == '\0') {
      piVar9 = (int *)**(undefined4 **)(param_1 + 0x38);
      iVar10 = (*(uint *)(param_1 + 0x4c) &
               ((((*(byte *)(piVar9 + 2) ^ 0x811c9dc5) * 0x1000193 ^
                 (uint)*(byte *)((int)piVar9 + 9)) * 0x1000193 ^ (uint)*(byte *)((int)piVar9 + 10))
                * 0x1000193 ^ (uint)*(byte *)((int)piVar9 + 0xb)) * 0x1000193) * 8;
      piVar11 = (int *)(iVar10 + *(int *)(param_1 + 0x40));
      if ((int *)piVar11[1] == piVar9) {
        if ((int *)*piVar11 == piVar9) {
          *piVar11 = (int)*(undefined4 **)(param_1 + 0x38);
          *(undefined4 *)(*(int *)(param_1 + 0x40) + 4 + iVar10) = *(undefined4 *)(param_1 + 0x38);
        }
        else {
          piVar11[1] = piVar9[1];
        }
      }
      else if ((int *)*piVar11 == piVar9) {
        *piVar11 = *piVar9;
      }
      *(int *)piVar9[1] = *piVar9;
      *(int *)(*piVar9 + 4) = piVar9[1];
      *(int *)(param_1 + 0x3c) = *(int *)(param_1 + 0x3c) + -1;
      uStack_8._0_1_ = 3;
    }
    else {
      piVar9 = (int *)**(int **)(param_1 + 0x58);
      iVar10 = (*(uint *)(param_1 + 0x6c) &
               ((((*(byte *)(piVar9 + 2) ^ 0x811c9dc5) * 0x1000193 ^
                 (uint)*(byte *)((int)piVar9 + 9)) * 0x1000193 ^ (uint)*(byte *)((int)piVar9 + 10))
                * 0x1000193 ^ (uint)*(byte *)((int)piVar9 + 0xb)) * 0x1000193) * 8;
      piVar11 = (int *)(iVar10 + *(int *)(param_1 + 0x60));
      if ((int *)piVar11[1] == piVar9) {
        if ((int *)*piVar11 == piVar9) {
          *piVar11 = (int)*(int **)(param_1 + 0x58);
          *(undefined4 *)(*(int *)(param_1 + 0x60) + 4 + iVar10) = *(undefined4 *)(param_1 + 0x58);
        }
        else {
          piVar11[1] = piVar9[1];
        }
      }
      else if ((int *)*piVar11 == piVar9) {
        *piVar11 = *piVar9;
      }
      *(int *)piVar9[1] = *piVar9;
      *(int *)(*piVar9 + 4) = piVar9[1];
      *(int *)(param_1 + 0x5c) = *(int *)(param_1 + 0x5c) + -1;
      uStack_8._0_1_ = 2;
    }
    FUN_007c7240(piVar9);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    (**(code **)(*piVar12 + 0x2c))();
  } while( true );
}



/* FUNCTION 11791 ; VA 0x007c5880 ; FUN_007c5880 */

void __fastcall FUN_007c5880(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar2 = (int *)param_1[1];
  piVar3 = (int *)*piVar2;
  ExceptionList = &pvStack_10;
  *piVar2 = (int)piVar2;
  *(int *)(param_1[1] + 4) = param_1[1];
  param_1[2] = 0;
  piVar2 = (int *)param_1[1];
  piStack_14 = param_1;
  if (piVar3 != piVar2) {
    do {
      piVar1 = (int *)*piVar3;
      uStack_8 = 0;
      FUN_007c7240(piVar3);
      piVar2 = (int *)param_1[1];
      piVar3 = piVar1;
    } while (piVar1 != piVar2);
  }
  uStack_8 = 0xffffffff;
  if ((uint)(param_1[5] - param_1[3] >> 2) < 0x10) {
    FUN_007c44a0(0x10);
    piVar2 = (int *)param_1[1];
  }
  piStack_14 = piVar2;
  FUN_007c53e0(0x10,&piStack_14);
  param_1[6] = 7;
  param_1[7] = 8;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11792 ; VA 0x007c5930 ; FUN_007c5930 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_007c5930(int param_1)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  char cVar7;
  int iVar8;
  int iVar9;
  double dVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  undefined8 uVar14;
  float fStack_3c;
  float fStack_38;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017b33d4;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb3048) {
    ExceptionList = &pvStack_1c;
    FUN_016f3809(&DAT_01eb3048);
    if (DAT_01eb3048 == -1) {
      uStack_14 = 0;
      uVar14 = FUN_0152dab0("Render","computeLightingPrepare",0xffffffff);
      DAT_01eb3044 = (undefined4)((ulonglong)uVar14 >> 0x20);
      DAT_01eb3040 = (undefined4)uVar14;
      uStack_14 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb3048);
    }
  }
  uVar6 = DAT_01eb3044;
  uVar5 = DAT_01eb3040;
  uVar14 = FUN_0152d930(DAT_01eb3040,DAT_01eb3044);
  uVar4 = _UNK_018f99ac;
  uVar3 = _UNK_018f99a8;
  uVar2 = _UNK_018f99a4;
  uStack_14 = 1;
  iVar8 = *(int *)(*(int *)(param_1 + 0x18c) + 0x4f8);
  *(undefined4 *)(iVar8 + 0x154) = _DAT_018f99a0;
  *(undefined4 *)(iVar8 + 0x158) = uVar2;
  *(undefined4 *)(iVar8 + 0x15c) = uVar3;
  *(undefined4 *)(iVar8 + 0x160) = uVar4;
  *(undefined4 *)(iVar8 + 0x164) = 0;
  *(undefined4 *)(iVar8 + 0x168) = 0;
  *(undefined4 *)(iVar8 + 0x16c) = 0;
  *(undefined4 *)(iVar8 + 0x170) = 0;
  *(undefined4 *)(iVar8 + 0x174) = 0;
  *(undefined4 *)(iVar8 + 0x178) = 0;
  *(undefined4 *)(iVar8 + 0x17c) = 0;
  *(undefined4 *)(iVar8 + 0x180) = 0;
  uVar4 = _UNK_018fdeac;
  uVar3 = _UNK_018fdea8;
  uVar2 = _UNK_018fdea4;
  *(undefined4 *)(iVar8 + 0x184) = _DAT_018fdea0;
  *(undefined4 *)(iVar8 + 0x188) = uVar2;
  *(undefined4 *)(iVar8 + 0x18c) = uVar3;
  *(undefined4 *)(iVar8 + 400) = uVar4;
  if (*(char *)(param_1 + 0x210) != '\0') {
    piVar1 = *(int **)(*(int *)(param_1 + 0x18c) + 0x52c);
    if (piVar1 != (int *)0x0) {
      iVar8 = (**(code **)(*(int *)(*(int *)(*(int *)(param_1 + 0x14) + 0x1b8) + 0x144) + 4))();
      iVar9 = FUN_00d215f0();
      if (iVar9 == 0) {
        iVar9 = *(int *)(*(int *)(param_1 + 0x18c) + 0x4f8);
        fVar13 = *(float *)(iVar9 + 0x10);
        if ((NAN(fVar13) || NAN(DAT_018c45c4)) == (fVar13 == DAT_018c45c4)) {
          dVar10 = (double)fVar13;
          FUN_017267a0();
          fVar13 = (float)dVar10;
        }
        else {
          fVar13 = 0.0;
        }
        fStack_3c = (float)*(undefined8 *)(iVar9 + 4);
        fVar12 = (*(float *)(iVar8 + 0x88) * 0.0 + *(float *)(iVar8 + 0x84) * 0.0) -
                 *(float *)(iVar8 + 0x8c) * DAT_018ce2f8;
        fVar11 = (*(float *)(iVar8 + 0x70) * 0.0 + *(float *)(iVar8 + 0x6c) * 0.0) -
                 *(float *)(iVar8 + 0x74) * DAT_018ce2f8;
        fStack_38 = (float)((ulonglong)*(undefined8 *)(iVar9 + 4) >> 0x20);
        fVar12 = *(float *)(iVar9 + 0xc) + fVar13 * fVar12 + fVar12 * DAT_018fabe8 * DAT_018e3f8c;
        *(ulonglong *)(param_1 + 0x274) =
             CONCAT44(fStack_38 +
                      fVar13 * ((*(float *)(iVar8 + 0x7c) * 0.0 + *(float *)(iVar8 + 0x78) * 0.0) -
                               *(float *)(iVar8 + 0x80) * DAT_018ce2f8) + 0.0,
                      fVar11 * DAT_018fabe8 * DAT_018e3f8c + fStack_3c + fVar13 * fVar11);
      }
      else {
        *(undefined8 *)(param_1 + 0x274) = *(undefined8 *)(iVar8 + 0xc0);
        fVar12 = *(float *)(iVar8 + 200);
      }
      *(float *)(param_1 + 0x27c) = fVar12;
      (**(code **)(*piVar1 + 0x1c))(*(undefined4 *)(param_1 + 0x14),param_1 + 0x274);
    }
    cVar7 = FUN_0078bd20();
    if ((cVar7 != '\0') &&
       (piVar1 = *(int **)(*(int *)(param_1 + 0x18c) + 0x574), piVar1 != (int *)0x0)) {
      (**(code **)(*piVar1 + 4))(*(undefined4 *)(param_1 + 0x14));
    }
    piVar1 = *(int **)(*(int *)(param_1 + 0x18c) + 0x578);
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x10))(*(undefined4 *)(param_1 + 0x14));
    }
  }
  uStack_14 = 3;
  FUN_0152dda0(uVar5,uVar6,uVar14);
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 11793 ; VA 0x007c5c80 ; FUN_007c5c80 */

void __fastcall FUN_007c5c80(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  
  if (*(int *)(param_1 + 4) == 0) {
    *(undefined2 *)(param_1 + 8) = 0;
    puVar3 = (undefined4 *)FUN_01674e20(0x14);
    *(undefined4 **)(param_1 + 4) = puVar3;
    *puVar3 = 0;
    puVar3[1] = 0;
    *(undefined8 *)(puVar3 + 2) = 0;
    puVar3[4] = 0;
    *(undefined *)(param_1 + 8) = 1;
    return;
  }
  if (*(char *)(param_1 + 9) != '\0') {
    piVar1 = *(int **)(*(int *)(param_1 + 4) + 0x10);
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    *(undefined *)(param_1 + 9) = 0;
  }
  return;
}



/* FUNCTION 11794 ; VA 0x007c5ce0 ; FUN_007c5ce0 */

void __fastcall FUN_007c5ce0(int param_1)

{
  code *pcVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794ef8;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 4) != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      *(undefined *)(param_1 + 9) = 0;
    }
    return;
  }
  ExceptionList = &pvStack_10;
  *(undefined2 *)(param_1 + 8) = 0;
  puVar2 = (undefined4 *)FUN_007c7780();
  if (puVar2 != (undefined4 *)0x0) {
    *(undefined4 **)(param_1 + 4) = puVar2;
    *puVar2 = 0;
    puVar2[1] = 0;
    puVar2[2] = 0;
    *(undefined *)(param_1 + 8) = 1;
    ExceptionList = pvStack_10;
    return;
  }
  uVar3 = FUN_0054fbc0();
  uStack_8 = 0;
  FUN_005648a0(uVar3);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 11795 ; VA 0x007c5d70 ; FUN_007c5d70 */

void __fastcall FUN_007c5d70(int param_1)

{
  code *pcVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794ef8;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 4) != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      *(undefined *)(param_1 + 9) = 0;
    }
    return;
  }
  ExceptionList = &pvStack_10;
  *(undefined2 *)(param_1 + 8) = 0;
  puVar2 = (undefined4 *)FUN_007c76c0();
  if (puVar2 != (undefined4 *)0x0) {
    *(undefined4 **)(param_1 + 4) = puVar2;
    *puVar2 = 0;
    puVar2[1] = 0;
    *(undefined8 *)(puVar2 + 2) = 0;
    puVar2[4] = 0;
    *(undefined *)(param_1 + 8) = 1;
    ExceptionList = pvStack_10;
    return;
  }
  uVar3 = FUN_0054fbc0();
  uStack_8 = 0;
  FUN_005648a0(uVar3);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 11796 ; VA 0x007c5e10 ; FUN_007c5e10 */

void __fastcall FUN_007c5e10(int param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 == 0) {
    *(undefined2 *)(param_1 + 8) = 0;
    puVar4 = (undefined4 *)FUN_007c51c0(1);
    *(undefined4 **)(param_1 + 4) = puVar4;
    *puVar4 = 0;
    puVar4[1] = 0;
    puVar4[2] = 0;
    puVar4[3] = 0;
    puVar4[4] = 0;
    puVar4[5] = 0;
    *(undefined *)(param_1 + 8) = 1;
    return;
  }
  if (*(char *)(param_1 + 9) != '\0') {
    iVar2 = *(int *)(iVar1 + 0xc);
    if (iVar2 != 0) {
      piVar3 = *(int **)(iVar1 + 0x10);
      *piVar3 = iVar2;
      *(int **)(iVar2 + 4) = piVar3;
      *(undefined4 *)(iVar1 + 0xc) = 0;
      *(undefined4 *)(iVar1 + 0x10) = 0;
    }
    *(undefined *)(param_1 + 9) = 0;
  }
  return;
}



/* FUNCTION 11797 ; VA 0x007c5e70 ; FUN_007c5e70 */

/* WARNING: Removing unreachable block (ram,0x007c5f0a) */
/* WARNING: Removing unreachable block (ram,0x007c5f56) */
/* WARNING: Removing unreachable block (ram,0x007c5f51) */
/* WARNING: Removing unreachable block (ram,0x007c5f5b) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_007c5e70(int param_1,int param_2)

{
  int iVar1;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b33e8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_18 = (ulonglong)(uint)uStack_18;
  ExceptionList = &pvStack_10;
  FUN_00605c90((int)&uStack_18 + 4,param_2 + 1);
  if (*(int *)(param_1 + 0x14) != 0) {
    *(undefined4 *)(param_2 * 4) =
         *(undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
    iVar1 = *(int *)(param_1 + 4) + 1;
    if (iVar1 == 1) {
      FUN_0061e220();
    }
    else {
      FUN_0061e2d0(*(undefined4 *)(param_1 + 0x14),iVar1);
    }
  }
  *(int *)(param_1 + 4) = param_2;
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11798 ; VA 0x007c5f90 ; FUN_007c5f90 */

/* WARNING: Removing unreachable block (ram,0x007c602a) */
/* WARNING: Removing unreachable block (ram,0x007c6076) */
/* WARNING: Removing unreachable block (ram,0x007c6071) */
/* WARNING: Removing unreachable block (ram,0x007c607b) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_007c5f90(int param_1,int param_2)

{
  int iVar1;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b3408;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_18 = (ulonglong)(uint)uStack_18;
  ExceptionList = &pvStack_10;
  FUN_00605c90((int)&uStack_18 + 4,param_2 + 1);
  if (*(int *)(param_1 + 0x14) != 0) {
    *(undefined4 *)(param_2 * 4) =
         *(undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
    iVar1 = *(int *)(param_1 + 4) + 1;
    if (iVar1 == 1) {
      FUN_0061e220();
    }
    else {
      FUN_0061e2d0(*(undefined4 *)(param_1 + 0x14),iVar1);
    }
  }
  *(int *)(param_1 + 4) = param_2;
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11799 ; VA 0x007c60b0 ; FUN_007c60b0 */

void FUN_007c60b0(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0x1c;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 11800 ; VA 0x007c6100 ; FUN_007c6100 */

void FUN_007c6100(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0x30;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 11801 ; VA 0x007c6140 ; FUN_007c6140 */

void __fastcall FUN_007c6140(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar7 = *(undefined4 **)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar7;
        piVar3 = (int *)puVar7[4];
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[2] + -1;
          piVar3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
        FUN_01674ea0(puVar7,0x14);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 11802 ; VA 0x007c61e0 ; FUN_007c61e0 */

void __fastcall FUN_007c61e0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_007c6260(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 11803 ; VA 0x007c6260 ; FUN_007c6260 */

int __thiscall FUN_007c6260(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  
  iVar4 = 0;
  puVar3 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar3;
    piVar1 = (int *)puVar3[4];
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    FUN_01674ea0(puVar3,0x14);
    iVar4 = iVar4 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar3 = (undefined4 *)*param_2;
  } while (puVar3 != param_3);
  return iVar4;
}



/* FUNCTION 11804 ; VA 0x007c62b0 ; FUN_007c62b0 */

int __thiscall FUN_007c62b0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  
  iVar3 = 0;
  puVar4 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar4;
    piVar1 = (int *)puVar4[4];
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[1] + -1;
      piVar1[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    FUN_01674ea0(puVar4,0x14);
    iVar3 = iVar3 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar4 = (undefined4 *)*param_2;
  } while (puVar4 != param_3);
  return iVar3;
}



/* FUNCTION 11805 ; VA 0x007c6320 ; FUN_007c6320 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __thiscall FUN_007c6320(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  int iVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  iVar7 = 0;
  puVar6 = (undefined4 *)*param_2;
  ExceptionList = &pvStack_10;
  do {
    uStack_8 = 0xffffffff;
    *param_2 = *puVar6;
    iVar1 = puVar6[3];
    if (iVar1 != 0) {
      piVar2 = (int *)puVar6[4];
      *piVar2 = iVar1;
      *(int **)(iVar1 + 4) = piVar2;
      puVar6[3] = 0;
      puVar6[4] = 0;
    }
    if (DAT_01ead1f1 == '\0') {
      DAT_01ead1f1 = '\x01';
      DAT_01ead1cc = 0;
      uRam01ead1d0 = 0;
      DAT_01ead1d4 = (undefined4 *)0x0;
      DAT_01ead1d8 = 0;
      DAT_01ead1dc = 0;
      _DAT_01ead1e0 = 0x18;
      _DAT_01ead1e4 = 0x20;
      _DAT_01ead1e8 = 0x20;
      _DAT_01ead1ec = 0;
    }
    FUN_005874f0();
    *puVar6 = DAT_01ead1d4;
    uStack_8 = 0;
    LOCK();
    uVar3 = DAT_01ead1cc + 0x80000000;
    UNLOCK();
    uVar4 = uVar3;
    DAT_01ead1d4 = puVar6;
    if (((DAT_01ead1cc & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead1cc)) {
      LOCK();
      DAT_01ead1cc = uVar3 | 0x40000000;
      UNLOCK();
      uVar4 = DAT_01ead1cc;
      if ((uVar3 >> 0x1e & 1) == 0) {
        uVar5 = FUN_00554e40();
        SetEvent(uVar5);
        uVar4 = DAT_01ead1cc;
      }
    }
    DAT_01ead1cc = uVar4;
    iVar7 = iVar7 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar6 = (undefined4 *)*param_2;
  } while (puVar6 != param_3);
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 11806 ; VA 0x007c6430 ; FUN_007c6430 */

int __thiscall FUN_007c6430(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_007c7190(puVar1);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar1 = (undefined4 *)*param_2;
    iVar2 = iVar2 + 1;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 11807 ; VA 0x007c6470 ; FUN_007c6470 */

int __thiscall FUN_007c6470(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_007c7240(puVar1);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar1 = (undefined4 *)*param_2;
    iVar2 = iVar2 + 1;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 11808 ; VA 0x007c64b0 ; FUN_007c64b0 */

void FUN_007c64b0(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  FUN_007c6a90(&param_1);
  if (param_1 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*param_1;
    param_1 = (undefined4 *)0x1;
                    /* WARNING: Could not recover jumptable at 0x007c64d3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)*puVar1)();
    return;
  }
  return;
}



/* FUNCTION 11809 ; VA 0x007c64e0 ; FUN_007c64e0 */

void __thiscall FUN_007c64e0(int param_1,int *param_2)

{
  int *piVar1;
  
  piVar1 = param_2;
  param_2 = (int *)(**(code **)(*param_2 + 0x1c))();
  if (param_2 != (int *)0x0) {
    FUN_007c67f0(&param_2);
    if ((DAT_01d622b0 != '\0') && (*(int **)(param_1 + 0x1b0) == piVar1)) {
      *(undefined4 *)(param_1 + 0x1b0) = 0;
    }
    (**(code **)*piVar1)(1);
  }
  return;
}



/* FUNCTION 11810 ; VA 0x007c6530 ; FUN_007c6530 */

void FUN_007c6530(int param_1)

{
  int iVar1;
  
  FUN_007c70b0(&param_1);
  FUN_007c70b0(&param_1);
  iVar1 = param_1;
  FUN_0085dc10();
  if (iVar1 != 0) {
    FUN_007c2fc0();
    FUN_01674ea0(iVar1,100);
  }
  return;
}



/* FUNCTION 11811 ; VA 0x007c6580 ; FUN_007c6580 */

void __thiscall FUN_007c6580(int param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  short *psVar3;
  uint uVar4;
  undefined4 *puVar5;
  int *piVar6;
  uint uVar7;
  int *piVar8;
  
  iVar1 = *(int *)(param_1 + 0x1b4);
  psVar3 = (short *)(**(code **)(*param_2 + 4))(1);
  if (*(int *)(iVar1 + 8) != 0) {
    uVar4 = FUN_007c73c0(psVar3);
    uVar7 = uVar4 % *(uint *)(iVar1 + 4);
    piVar8 = *(int **)(uVar7 * 4 + *(int *)(iVar1 + 0x14));
    if ((piVar8 != (int *)0x0) && (piVar2 = (int *)*piVar8, (int *)*piVar8 != (int *)0x0)) {
      while (piVar6 = piVar2, (uint)piVar6[1] % *(uint *)(iVar1 + 4) == uVar7) {
        if ((((piVar6[1] == uVar4) && (*psVar3 == *(short *)(piVar6 + 2))) &&
            (psVar3[1] == *(short *)((int)piVar6 + 10))) &&
           ((psVar3[2] == *(short *)(piVar6 + 3) && (psVar3[3] == *(short *)((int)piVar6 + 0xe)))))
        {
          FUN_007c6430(piVar8,*piVar6);
          if (*piVar8 != 0) {
            uVar4 = *(uint *)(*piVar8 + 4) % *(uint *)(iVar1 + 4);
            if (uVar7 == uVar4) break;
            *(int **)(*(int *)(iVar1 + 0x14) + uVar4 * 4) = piVar8;
          }
          puVar5 = (undefined4 *)(*(int *)(iVar1 + 0x14) + uVar7 * 4);
          if ((int *)*puVar5 == piVar8) {
            *puVar5 = 0;
          }
          break;
        }
        piVar2 = (int *)*piVar6;
        piVar8 = piVar6;
        if ((int *)*piVar6 == (int *)0x0) {
          (**(code **)*param_2)(1);
          return;
        }
      }
    }
  }
  (**(code **)*param_2)(1);
  return;
}



/* FUNCTION 11812 ; VA 0x007c6690 ; FUN_007c6690 */

void FUN_007c6690(int param_1)

{
  *(undefined *)(*(int *)(param_1 + 0x18) + 0x211) = 1;
  return;
}



/* FUNCTION 11813 ; VA 0x007c66b0 ; FUN_007c66b0 */

void FUN_007c66b0(undefined4 param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint in_stack_0000001c;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b3430;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00770dd0(aiStack_28);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    iVar1 = aiStack_28[0];
    if (0xfff < uVar2) {
      iVar1 = *(int *)(aiStack_28[0] + -4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  if (0xf < in_stack_0000001c) {
    uVar2 = in_stack_0000001c + 1;
    iVar1 = param_2;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_2 + -4);
      uVar2 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11814 ; VA 0x007c6780 ; FUN_007c6780 */

int FUN_007c6780(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar4 = (**(code **)(param_1 + 0x18))(&param_2);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 11815 ; VA 0x007c67f0 ; FUN_007c67f0 */

int __thiscall FUN_007c67f0(int param_1,byte *param_2)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  uint uVar4;
  undefined4 *puVar5;
  int *piVar6;
  int *piVar7;
  int iVar8;
  int *piVar9;
  
  piVar2 = *(int **)(param_1 + 4);
  uVar4 = ((((*param_2 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_2[1]) * 0x1000193 ^ (uint)param_2[2])
           * 0x1000193 ^ (uint)param_2[3]) * 0x1000193 & *(uint *)(param_1 + 0x18);
  piVar3 = *(int **)(*(int *)(param_1 + 0xc) + uVar4 * 8);
  puVar5 = (undefined4 *)(uVar4 * 8 + 4 + *(int *)(param_1 + 0xc));
  piVar9 = piVar3;
  while( true ) {
    piVar6 = piVar2;
    if (piVar3 != piVar2) {
      piVar6 = *(int **)*puVar5;
    }
    if (piVar9 == piVar6) goto LAB_007c68aa;
    piVar6 = piVar9;
    if (piVar9[2] == *(int *)param_2) break;
    piVar9 = (int *)*piVar9;
  }
  while( true ) {
    piVar7 = piVar2;
    if (piVar3 != piVar2) {
      piVar7 = *(int **)*puVar5;
    }
    if ((piVar6 == piVar7) || (*(int *)param_2 != piVar6[2])) break;
    piVar6 = (int *)*piVar6;
  }
  if (piVar9 == piVar6) {
LAB_007c68aa:
    piVar6 = piVar2;
    piVar9 = piVar2;
  }
  iVar8 = 0;
  for (piVar3 = piVar9; piVar3 != piVar6; piVar3 = (int *)*piVar3) {
    iVar8 = iVar8 + 1;
  }
  if ((piVar9 == (int *)*piVar2) && (piVar6 == piVar2)) {
    FUN_005e9e90();
    return iVar8;
  }
  if (piVar9 != piVar6) {
    do {
      piVar2 = (int *)*piVar9;
      iVar1 = (((((*(byte *)(piVar9 + 2) ^ 0x811c9dc5) * 0x1000193 ^
                 (uint)*(byte *)((int)piVar9 + 9)) * 0x1000193 ^ (uint)*(byte *)((int)piVar9 + 10))
                * 0x1000193 ^ (uint)*(byte *)((int)piVar9 + 0xb)) * 0x1000193 &
              *(uint *)(param_1 + 0x18)) * 8;
      puVar5 = (undefined4 *)(iVar1 + *(int *)(param_1 + 0xc));
      if ((int *)puVar5[1] == piVar9) {
        if ((int *)*puVar5 == piVar9) {
          *puVar5 = *(undefined4 *)(param_1 + 4);
          *(undefined4 *)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
        }
        else {
          puVar5[1] = piVar9[1];
        }
      }
      else if ((int *)*puVar5 == piVar9) {
        *puVar5 = piVar2;
      }
      *(int *)piVar9[1] = *piVar9;
      *(int *)(*piVar9 + 4) = piVar9[1];
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
      FUN_01674ea0(piVar9,0x10);
      piVar9 = piVar2;
    } while (piVar2 != piVar6);
    return iVar8;
  }
  return iVar8;
}



/* FUNCTION 11816 ; VA 0x007c69c0 ; FUN_007c69c0 */

void __thiscall FUN_007c69c0(int param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar1 = (*(uint *)(param_1 + 0x18) &
          ((((*(byte *)(param_3 + 2) ^ 0x811c9dc5) * 0x1000193 ^ (uint)*(byte *)((int)param_3 + 9))
            * 0x1000193 ^ (uint)*(byte *)((int)param_3 + 10)) * 0x1000193 ^
          (uint)*(byte *)((int)param_3 + 0xb)) * 0x1000193) * 8;
  piVar2 = (int *)(*(int *)(param_1 + 0xc) + iVar1);
  if ((int *)piVar2[1] == param_3) {
    if ((int *)*piVar2 == param_3) {
      ExceptionList = &pvStack_10;
      *piVar2 = *(int *)(param_1 + 4);
      *(undefined4 *)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
    }
    else {
      ExceptionList = &pvStack_10;
      piVar2[1] = param_3[1];
    }
  }
  else {
    ExceptionList = &pvStack_10;
    if ((int *)*piVar2 == param_3) {
      ExceptionList = &pvStack_10;
      *piVar2 = *param_3;
    }
  }
  iVar1 = *param_3;
  *(int *)param_3[1] = iVar1;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  uStack_8 = 0;
  FUN_007c7240(param_3);
  *param_2 = iVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11817 ; VA 0x007c6a90 ; FUN_007c6a90 */

int __thiscall FUN_007c6a90(int param_1,byte *param_2)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  void **ppvVar5;
  uint uVar6;
  int *piVar7;
  int *piVar8;
  int iVar9;
  int *piVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0xc);
  piVar2 = *(int **)(param_1 + 4);
  uVar6 = ((((*param_2 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_2[1]) * 0x1000193 ^ (uint)param_2[2])
           * 0x1000193 ^ (uint)param_2[3]) * 0x1000193 & *(uint *)(param_1 + 0x18);
  piVar3 = *(int **)(iVar1 + uVar6 * 8);
  iVar9 = uVar6 * 8 + 4;
  piVar10 = piVar3;
  while( true ) {
    piVar7 = piVar2;
    if (piVar3 != piVar2) {
      piVar7 = (int *)**(undefined4 **)(iVar9 + iVar1);
    }
    if (piVar10 == piVar7) goto LAB_007c6b72;
    piVar7 = piVar10;
    if (piVar10[2] == *(int *)param_2) break;
    piVar10 = (int *)*piVar10;
  }
  while( true ) {
    piVar8 = piVar2;
    if (piVar3 != piVar2) {
      piVar8 = (int *)**(undefined4 **)(iVar9 + iVar1);
    }
    if ((piVar7 == piVar8) || (*(int *)param_2 != piVar7[2])) break;
    piVar7 = (int *)*piVar7;
  }
  if (piVar10 == piVar7) {
LAB_007c6b72:
    piVar7 = piVar2;
    piVar10 = piVar2;
  }
  iVar9 = 0;
  for (piVar3 = piVar10; piVar3 != piVar7; piVar3 = (int *)*piVar3) {
    iVar9 = iVar9 + 1;
  }
  if ((piVar10 == (int *)*piVar2) && (piVar7 == piVar2)) {
    ExceptionList = &pvStack_10;
    FUN_007c5880();
    ExceptionList = pvStack_10;
    return iVar9;
  }
  ppvVar5 = &pvStack_10;
  if (piVar10 != piVar7) {
    do {
      ExceptionList = ppvVar5;
      piVar2 = (int *)*piVar10;
      iVar1 = (((((*(byte *)(piVar10 + 2) ^ 0x811c9dc5) * 0x1000193 ^
                 (uint)*(byte *)((int)piVar10 + 9)) * 0x1000193 ^ (uint)*(byte *)((int)piVar10 + 10)
                ) * 0x1000193 ^ (uint)*(byte *)((int)piVar10 + 0xb)) * 0x1000193 &
              *(uint *)(param_1 + 0x18)) * 8;
      iVar4 = *(int *)(param_1 + 0xc);
      if (*(int **)(iVar1 + 4 + iVar4) == piVar10) {
        if (*(int **)(iVar1 + iVar4) == piVar10) {
          *(undefined4 *)(iVar1 + iVar4) = *(undefined4 *)(param_1 + 4);
          *(undefined4 *)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
        }
        else {
          *(int *)(iVar1 + 4 + iVar4) = piVar10[1];
        }
      }
      else if (*(int **)(iVar1 + iVar4) == piVar10) {
        *(int **)(iVar1 + iVar4) = piVar2;
      }
      *(int *)piVar10[1] = *piVar10;
      *(int *)(*piVar10 + 4) = piVar10[1];
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
      uStack_8 = 0;
      FUN_007c7240(piVar10);
      piVar10 = piVar2;
      ppvVar5 = (void **)ExceptionList;
    } while (piVar2 != piVar7);
    ExceptionList = pvStack_10;
    return iVar9;
  }
  return iVar9;
}



/* FUNCTION 11818 ; VA 0x007c6cb0 ; FUN_007c6cb0 */

void __thiscall FUN_007c6cb0(int *param_1,undefined4 *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  void **ppvVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  ppvVar4 = &pvStack_10;
  if ((param_3 == (int *)*piVar1) && (ppvVar4 = &pvStack_10, param_4 == piVar1)) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_007c4310(piVar1[1]);
    *(int **)(*param_1 + 4) = piVar1;
    *(int **)*param_1 = piVar1;
    *(int **)(*param_1 + 8) = piVar1;
    param_1[1] = 0;
    *param_2 = *(undefined4 *)*param_1;
    ExceptionList = pvStack_10;
    return;
  }
  do {
    ExceptionList = ppvVar4;
    if (param_3 == param_4) {
      *param_2 = param_3;
      ExceptionList = pvStack_10;
      return;
    }
    FUN_00551320();
    FUN_00551320();
    iVar5 = FUN_00553830(param_3);
    uVar2 = *(uint *)(iVar5 + 0x2c);
    if (0xf < uVar2) {
      iVar3 = *(int *)(iVar5 + 0x18);
      uVar7 = uVar2 + 1;
      iVar6 = iVar3;
      if (0xfff < uVar7) {
        iVar6 = *(int *)(iVar3 + -4);
        uVar7 = uVar2 + 0x24;
        if (0x1f < (iVar3 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar6,uVar7);
    }
    *(undefined4 *)(iVar5 + 0x28) = 0;
    *(undefined4 *)(iVar5 + 0x2c) = 0xf;
    *(undefined *)(iVar5 + 0x18) = 0;
    FUN_01674ea0(iVar5,0x30);
    ppvVar4 = (void **)ExceptionList;
  } while( true );
}



/* FUNCTION 11819 ; VA 0x007c6dc0 ; FUN_007c6dc0 */

int __thiscall FUN_007c6dc0(int *param_1,uint *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int iVar6;
  
  puVar4 = (undefined4 *)*param_1;
  puVar1 = (undefined4 *)puVar4[1];
  puVar5 = puVar4;
  if (*(char *)((int)puVar1 + 0xd) == '\0') {
    puVar2 = puVar1;
    do {
      if ((uint)puVar2[4] < *param_2) {
        puVar3 = (undefined4 *)puVar2[2];
      }
      else {
        if ((*(char *)((int)puVar5 + 0xd) != '\0') && (*param_2 < (uint)puVar2[4])) {
          puVar5 = puVar2;
        }
        puVar3 = (undefined4 *)*puVar2;
        puVar4 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((int)puVar3 + 0xd) == '\0');
  }
  if (*(char *)((int)puVar5 + 0xd) == '\0') {
    puVar1 = (undefined4 *)*puVar5;
  }
  if (*(char *)((int)puVar1 + 0xd) == '\0') {
    do {
      if (*param_2 < (uint)puVar1[4]) {
        puVar2 = (undefined4 *)*puVar1;
        puVar5 = puVar1;
      }
      else {
        puVar2 = (undefined4 *)puVar1[2];
      }
      puVar1 = puVar2;
    } while (*(char *)((int)puVar2 + 0xd) == '\0');
  }
  iVar6 = 0;
  param_2 = puVar4;
  while (param_2 != puVar5) {
    iVar6 = iVar6 + 1;
    FUN_00551320();
  }
  FUN_007c6cb0(&param_2,puVar4,puVar5);
  return iVar6;
}



/* FUNCTION 11820 ; VA 0x007c6e60 ; FUN_007c6e60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __thiscall FUN_007c6e60(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  undefined4 uVar6;
  uint uVar7;
  int *piVar8;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_3;
  ExceptionList = &pvStack_10;
  *param_2 = (int)piVar1;
  uStack_14 = (uint)param_3[1] % *(uint *)(param_1 + 4);
  piVar2 = *(int **)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
  for (piVar8 = (int *)*piVar2; piVar8 != param_3; piVar8 = (int *)*piVar8) {
    piVar2 = piVar8;
  }
  do {
    uStack_8 = 0xffffffff;
    *piVar2 = *piVar8;
    iVar3 = piVar8[3];
    if (iVar3 != 0) {
      piVar4 = (int *)piVar8[4];
      *piVar4 = iVar3;
      *(int **)(iVar3 + 4) = piVar4;
      piVar8[3] = 0;
      piVar8[4] = 0;
    }
    if (DAT_01ead1f1 == '\0') {
      DAT_01ead1f1 = '\x01';
      DAT_01ead1cc = 0;
      uRam01ead1d0 = 0;
      DAT_01ead1d4 = (int *)0x0;
      DAT_01ead1d8 = 0;
      DAT_01ead1dc = 0;
      _DAT_01ead1e0 = 0x18;
      _DAT_01ead1e4 = 0x20;
      _DAT_01ead1e8 = 0x20;
      _DAT_01ead1ec = 0;
    }
    FUN_005874f0();
    *piVar8 = (int)DAT_01ead1d4;
    uStack_8 = 0;
    LOCK();
    uVar7 = DAT_01ead1cc + 0x80000000;
    UNLOCK();
    uVar5 = uVar7;
    DAT_01ead1d4 = piVar8;
    if (((DAT_01ead1cc & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead1cc)) {
      LOCK();
      DAT_01ead1cc = uVar7 | 0x40000000;
      UNLOCK();
      uVar5 = DAT_01ead1cc;
      if ((uVar7 >> 0x1e & 1) == 0) {
        uVar6 = FUN_00554e40();
        SetEvent(uVar6);
        uVar5 = DAT_01ead1cc;
      }
    }
    DAT_01ead1cc = uVar5;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    uVar7 = uStack_14;
    if (*piVar2 == 0) {
LAB_007c6f91:
      if (*(int **)(*(int *)(param_1 + 0x14) + uStack_14 * 4) == piVar2) {
        *(undefined4 *)(*(int *)(param_1 + 0x14) + uStack_14 * 4) = 0;
      }
    }
    else {
      uVar7 = *(uint *)(*piVar2 + 4) % *(uint *)(param_1 + 4);
      if (uStack_14 != uVar7) {
        *(int **)(*(int *)(param_1 + 0x14) + uVar7 * 4) = piVar2;
        goto LAB_007c6f91;
      }
    }
    piVar8 = (int *)*piVar2;
    uStack_14 = uVar7;
    if (piVar8 == piVar1) {
      ExceptionList = pvStack_10;
      return param_2;
    }
  } while( true );
}



/* FUNCTION 11821 ; VA 0x007c6fd0 ; FUN_007c6fd0 */

undefined4 __thiscall FUN_007c6fd0(int param_1,uint *param_2)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  
  if (*(int *)(param_1 + 8) == 0) {
    return 0;
  }
  uVar7 = *param_2;
  uVar3 = (uVar7 >> 3) + uVar7;
  uVar6 = uVar3 % *(uint *)(param_1 + 4);
  piVar1 = *(int **)(uVar6 * 4 + *(int *)(param_1 + 0x14));
  if (piVar1 != (int *)0x0) {
    piVar2 = (int *)*piVar1;
    while( true ) {
      if ((piVar2 == (int *)0x0) || ((uint)piVar2[1] % *(uint *)(param_1 + 4) != uVar6)) {
        return 0;
      }
      if ((piVar2[1] == uVar3) && (uVar7 == piVar2[2])) break;
      piVar1 = piVar2;
      piVar2 = (int *)*piVar2;
    }
    uVar4 = FUN_007c6320(piVar1,*piVar2);
    if (*piVar1 != 0) {
      uVar7 = *(uint *)(*piVar1 + 4) % *(uint *)(param_1 + 4);
      if (uVar6 == uVar7) {
        return uVar4;
      }
      *(int **)(*(int *)(param_1 + 0x14) + uVar7 * 4) = piVar1;
    }
    puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    if ((int *)*puVar5 == piVar1) {
      *puVar5 = 0;
    }
    return uVar4;
  }
  return 0;
}



/* FUNCTION 11822 ; VA 0x007c70b0 ; FUN_007c70b0 */

undefined4 __thiscall FUN_007c70b0(int param_1,uint *param_2)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  
  if (*(int *)(param_1 + 8) == 0) {
    return 0;
  }
  uVar7 = *param_2;
  uVar3 = (uVar7 >> 3) + uVar7;
  uVar6 = uVar3 % *(uint *)(param_1 + 4);
  piVar1 = *(int **)(uVar6 * 4 + *(int *)(param_1 + 0x14));
  if (piVar1 != (int *)0x0) {
    piVar2 = (int *)*piVar1;
    while( true ) {
      if ((piVar2 == (int *)0x0) || ((uint)piVar2[1] % *(uint *)(param_1 + 4) != uVar6)) {
        return 0;
      }
      if ((piVar2[1] == uVar3) && (uVar7 == piVar2[2])) break;
      piVar1 = piVar2;
      piVar2 = (int *)*piVar2;
    }
    uVar4 = FUN_007c6470(piVar1,*piVar2);
    if (*piVar1 != 0) {
      uVar7 = *(uint *)(*piVar1 + 4) % *(uint *)(param_1 + 4);
      if (uVar6 == uVar7) {
        return uVar4;
      }
      *(int **)(*(int *)(param_1 + 0x14) + uVar7 * 4) = piVar1;
    }
    puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    if ((int *)*puVar5 == piVar1) {
      *puVar5 = 0;
    }
    return uVar4;
  }
  return 0;
}



/* FUNCTION 11823 ; VA 0x007c7190 ; FUN_007c7190 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007c7190(undefined4 *param_1)

{
  uint uVar1;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (DAT_01eb3219 == '\0') {
    DAT_01eb3219 = '\x01';
    DAT_01eb31f4 = 0;
    uRam01eb31f8 = 0;
    DAT_01eb31fc = (undefined4 *)0x0;
    DAT_01eb3200 = 0;
    _DAT_01eb3214 = 0;
    DAT_01eb3204 = _DAT_018ffae0;
    uRam01eb3208 = _UNK_018ffae4;
    uRam01eb320c = _UNK_018ffae8;
    uRam01eb3210 = _UNK_018ffaec;
  }
  ExceptionList = &pvStack_10;
  FUN_005874f0();
  *param_1 = DAT_01eb31fc;
  DAT_01eb31fc = param_1;
  uStack_8 = 0;
  LOCK();
  uVar1 = DAT_01eb31f4 + 0x80000000;
  UNLOCK();
  uVar2 = uVar1;
  if (((DAT_01eb31f4 & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01eb31f4)) {
    LOCK();
    DAT_01eb31f4 = uVar1 | 0x40000000;
    UNLOCK();
    uVar2 = DAT_01eb31f4;
    if ((uVar1 >> 0x1e & 1) == 0) {
      uVar3 = FUN_00554e40();
      SetEvent(uVar3);
      uVar2 = DAT_01eb31f4;
    }
  }
  DAT_01eb31f4 = uVar2;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11824 ; VA 0x007c7240 ; FUN_007c7240 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007c7240(undefined4 *param_1)

{
  uint uVar1;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (DAT_01eb31f1 == '\0') {
    DAT_01eb31f1 = '\x01';
    DAT_01eb31cc = 0;
    uRam01eb31d0 = 0;
    DAT_01eb31d4 = (undefined4 *)0x0;
    DAT_01eb31d8 = 0;
    _DAT_01eb31ec = 0;
    DAT_01eb31dc = _DAT_018ffac0;
    uRam01eb31e0 = _UNK_018ffac4;
    uRam01eb31e4 = _UNK_018ffac8;
    uRam01eb31e8 = _UNK_018ffacc;
  }
  ExceptionList = &pvStack_10;
  FUN_005874f0();
  *param_1 = DAT_01eb31d4;
  DAT_01eb31d4 = param_1;
  uStack_8 = 0;
  LOCK();
  uVar1 = DAT_01eb31cc + 0x80000000;
  UNLOCK();
  uVar2 = uVar1;
  if (((DAT_01eb31cc & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01eb31cc)) {
    LOCK();
    DAT_01eb31cc = uVar1 | 0x40000000;
    UNLOCK();
    uVar2 = DAT_01eb31cc;
    if ((uVar1 >> 0x1e & 1) == 0) {
      uVar3 = FUN_00554e40();
      SetEvent(uVar3);
      uVar2 = DAT_01eb31cc;
    }
  }
  DAT_01eb31cc = uVar2;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11825 ; VA 0x007c72f0 ; FUN_007c72f0 */

undefined4 * __thiscall FUN_007c72f0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017b3459;
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  uStack_8 = 0;
  if (*(int *)(param_1 + 8) == 0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    puVar2 = *(undefined4 **)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
  }
  for (; puVar2 != (undefined4 *)0x0; puVar2 = (undefined4 *)*puVar2) {
    puVar1 = (undefined4 *)param_2[1];
    if ((undefined4 *)param_2[2] == puVar1) {
      FUN_006030d0(puVar1,puVar2 + 4);
    }
    else {
      *puVar1 = puVar2[4];
      param_2[1] = param_2[1] + 4;
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 11826 ; VA 0x007c7390 ; FUN_007c7390 */

undefined4 FUN_007c7390(int param_1)

{
  undefined4 uVar1;
  
  if ((*(byte *)(param_1 + 0xb4) & 2) != 0) {
    uVar1 = FUN_00b05fc0();
    return uVar1;
  }
  return 0;
}



/* FUNCTION 11827 ; VA 0x007c73b0 ; FUN_007c73b0 */

int __fastcall FUN_007c73b0(int param_1)

{
  return *(int *)(param_1 + 0xbc) + *(int *)(param_1 + 0xa4);
}



/* FUNCTION 11828 ; VA 0x007c73c0 ; FUN_007c73c0 */

uint FUN_007c73c0(short *param_1)

{
  uint uVar1;
  
  uVar1 = (int)*param_1 + 0x9e3779b9;
  uVar1 = uVar1 ^ (uVar1 >> 2) + (int)param_1[1] + *param_1 * 0x40 + 0x2c15e7f9;
  uVar1 = uVar1 ^ (uVar1 >> 2) + (int)param_1[2] + uVar1 * 0x40 + -0x61c88647;
  return (uVar1 >> 2) + 0x9e3779b9 + (uint)(ushort)param_1[3] + uVar1 * 0x40 ^ uVar1;
}



/* FUNCTION 11829 ; VA 0x007c7420 ; FUN_007c7420 */

bool FUN_007c7420(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  bool bVar4;
  
  if (DAT_01d6c7c4 == '\0') {
    if (DAT_01d6866c != '\0') {
      return *(int *)(param_1 + 0x6c) == -1;
    }
    return *(int *)(param_1 + 0x70) == 0;
  }
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_00cfb1a0();
  iVar3 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar3 = param_1;
  }
  if ((iVar3 == 0) || (*(char *)(iVar3 + 0x191) == '\0')) {
    if (DAT_01d6866c == '\0') {
      bVar4 = *(int *)(param_1 + 0x70) == 0;
    }
    else {
      bVar4 = *(int *)(param_1 + 0x6c) == -1;
    }
    if (bVar4) {
      return true;
    }
  }
  return false;
}



/* FUNCTION 11830 ; VA 0x007c74b0 ; FUN_007c74b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

bool FUN_007c74b0(uint param_1)

{
  uint uVar1;
  undefined4 uVar2;
  uint uVar3;
  int iVar4;
  bool bVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (DAT_01eb3219 == '\0') {
    DAT_01eb3219 = '\x01';
    DAT_01eb31f4 = 0;
    uRam01eb31f8 = 0;
    DAT_01eb31fc = 0;
    DAT_01eb3200 = 0;
    _DAT_01eb3214 = 0;
    DAT_01eb3204 = _DAT_018ffae0;
    uRam01eb3208 = _UNK_018ffae4;
    uRam01eb320c = _UNK_018ffae8;
    uRam01eb3210 = _UNK_018ffaec;
  }
  ExceptionList = &pvStack_10;
  FUN_005874f0();
  bVar5 = DAT_01eb3200 == 0;
  uVar3 = DAT_01eb3200;
  iVar4 = DAT_01eb3204;
  if (!bVar5) {
    do {
      if ((uVar3 <= param_1) && (param_1 < (uVar3 - 8) + iVar4)) break;
      iVar4 = iVar4 + uVar3;
      uVar3 = *(uint *)(iVar4 + -8);
      iVar4 = *(int *)(iVar4 + -4);
    } while (uVar3 != 0);
    bVar5 = uVar3 == 0;
  }
  uStack_8 = 0;
  LOCK();
  uVar3 = DAT_01eb31f4 + 0x80000000;
  UNLOCK();
  uVar1 = uVar3;
  if (((DAT_01eb31f4 & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01eb31f4)) {
    LOCK();
    DAT_01eb31f4 = uVar3 | 0x40000000;
    UNLOCK();
    uVar1 = DAT_01eb31f4;
    if ((uVar3 >> 0x1e & 1) == 0) {
      uVar2 = FUN_00554e40();
      SetEvent(uVar2);
      uVar1 = DAT_01eb31f4;
    }
  }
  DAT_01eb31f4 = uVar1;
  ExceptionList = pvStack_10;
  return !bVar5;
}



/* FUNCTION 11831 ; VA 0x007c7590 ; FUN_007c7590 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

bool FUN_007c7590(uint param_1)

{
  uint uVar1;
  undefined4 uVar2;
  uint uVar3;
  int iVar4;
  bool bVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (DAT_01eb31f1 == '\0') {
    DAT_01eb31f1 = '\x01';
    DAT_01eb31cc = 0;
    uRam01eb31d0 = 0;
    DAT_01eb31d4 = 0;
    DAT_01eb31d8 = 0;
    _DAT_01eb31ec = 0;
    DAT_01eb31dc = _DAT_018ffac0;
    uRam01eb31e0 = _UNK_018ffac4;
    uRam01eb31e4 = _UNK_018ffac8;
    uRam01eb31e8 = _UNK_018ffacc;
  }
  ExceptionList = &pvStack_10;
  FUN_005874f0();
  bVar5 = DAT_01eb31d8 == 0;
  uVar3 = DAT_01eb31d8;
  iVar4 = DAT_01eb31dc;
  if (!bVar5) {
    do {
      if ((uVar3 <= param_1) && (param_1 < (uVar3 - 8) + iVar4)) break;
      iVar4 = iVar4 + uVar3;
      uVar3 = *(uint *)(iVar4 + -8);
      iVar4 = *(int *)(iVar4 + -4);
    } while (uVar3 != 0);
    bVar5 = uVar3 == 0;
  }
  uStack_8 = 0;
  LOCK();
  uVar3 = DAT_01eb31cc + 0x80000000;
  UNLOCK();
  uVar1 = uVar3;
  if (((DAT_01eb31cc & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01eb31cc)) {
    LOCK();
    DAT_01eb31cc = uVar3 | 0x40000000;
    UNLOCK();
    uVar1 = DAT_01eb31cc;
    if ((uVar3 >> 0x1e & 1) == 0) {
      uVar2 = FUN_00554e40();
      SetEvent(uVar2);
      uVar1 = DAT_01eb31cc;
    }
  }
  DAT_01eb31cc = uVar1;
  ExceptionList = pvStack_10;
  return !bVar5;
}



/* FUNCTION 11832 ; VA 0x007c7670 ; FUN_007c7670 */

void __fastcall FUN_007c7670(int param_1)

{
  int *piVar1;
  
  piVar1 = *(int **)(*(int *)(param_1 + 0x18c) + 0x52c);
  if (piVar1 != (int *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x007c7686. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*piVar1 + 0x18))();
    return;
  }
  return;
}



/* FUNCTION 11833 ; VA 0x007c7690 ; FUN_007c7690 */

void __fastcall FUN_007c7690(int param_1)

{
  int *piVar1;
  
  piVar1 = *(int **)(*(int *)(param_1 + 0x18c) + 0x52c);
  if (piVar1 != (int *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x007c76b1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*piVar1 + 0x14))();
    return;
  }
  return;
}



/* FUNCTION 11834 ; VA 0x007c76c0 ; FUN_007c76c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_007c76c0(void)

{
  uint uVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (DAT_01eb3219 == '\0') {
    DAT_01eb3219 = '\x01';
    DAT_01eb31f4 = 0;
    uRam01eb31f8 = 0;
    DAT_01eb31fc = (undefined4 *)0x0;
    DAT_01eb3200 = 0;
    _DAT_01eb3214 = 0;
    DAT_01eb3204 = _DAT_018ffae0;
    uRam01eb3208 = _UNK_018ffae4;
    uRam01eb320c = _UNK_018ffae8;
    uRam01eb3210 = _UNK_018ffaec;
  }
  ExceptionList = &pvStack_10;
  FUN_005874f0();
  if (DAT_01eb31fc == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)FUN_00621e70();
  }
  else {
    puVar3 = DAT_01eb31fc;
    DAT_01eb31fc = (undefined4 *)*DAT_01eb31fc;
  }
  uStack_8 = 0;
  LOCK();
  uVar1 = DAT_01eb31f4 + 0x80000000;
  UNLOCK();
  uVar2 = uVar1;
  if (((DAT_01eb31f4 & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01eb31f4)) {
    LOCK();
    DAT_01eb31f4 = uVar1 | 0x40000000;
    UNLOCK();
    uVar2 = DAT_01eb31f4;
    if ((uVar1 >> 0x1e & 1) == 0) {
      uVar4 = FUN_00554e40();
      SetEvent(uVar4);
      uVar2 = DAT_01eb31f4;
    }
  }
  DAT_01eb31f4 = uVar2;
  ExceptionList = pvStack_10;
  return puVar3;
}



/* FUNCTION 11835 ; VA 0x007c7780 ; FUN_007c7780 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_007c7780(void)

{
  uint uVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (DAT_01eb31f1 == '\0') {
    DAT_01eb31f1 = '\x01';
    DAT_01eb31cc = 0;
    uRam01eb31d0 = 0;
    DAT_01eb31d4 = (undefined4 *)0x0;
    DAT_01eb31d8 = 0;
    _DAT_01eb31ec = 0;
    DAT_01eb31dc = _DAT_018ffac0;
    uRam01eb31e0 = _UNK_018ffac4;
    uRam01eb31e4 = _UNK_018ffac8;
    uRam01eb31e8 = _UNK_018ffacc;
  }
  ExceptionList = &pvStack_10;
  FUN_005874f0();
  if (DAT_01eb31d4 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)FUN_00621e70();
  }
  else {
    puVar3 = DAT_01eb31d4;
    DAT_01eb31d4 = (undefined4 *)*DAT_01eb31d4;
  }
  uStack_8 = 0;
  LOCK();
  uVar1 = DAT_01eb31cc + 0x80000000;
  UNLOCK();
  uVar2 = uVar1;
  if (((DAT_01eb31cc & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01eb31cc)) {
    LOCK();
    DAT_01eb31cc = uVar1 | 0x40000000;
    UNLOCK();
    uVar2 = DAT_01eb31cc;
    if ((uVar1 >> 0x1e & 1) == 0) {
      uVar4 = FUN_00554e40();
      SetEvent(uVar4);
      uVar2 = DAT_01eb31cc;
    }
  }
  DAT_01eb31cc = uVar2;
  ExceptionList = pvStack_10;
  return puVar3;
}



/* FUNCTION 11836 ; VA 0x007c7840 ; FUN_007c7840 */

void __thiscall FUN_007c7840(int param_1,int param_2,int param_3)

{
  int iVar1;
  
  iVar1 = param_2;
  if (DAT_01ee4200 != '\0') {
    FUN_016774b0(DAT_01ee4200,"notifyAwake, adding cluster %p to dynamic nodes",param_2);
  }
  if (*(int *)(iVar1 + 0x18) < 0) {
    *(undefined4 *)(iVar1 + 0x18) = *(undefined4 *)(param_1 + (param_3 * 3 + 0xa3) * 4 + 4);
    param_2 = iVar1;
    FUN_007c5360(&param_2);
  }
  return;
}



/* FUNCTION 11837 ; VA 0x007c78a0 ; FUN_007c78a0 */

void __thiscall FUN_007c78a0(int param_1,uint param_2,undefined4 *param_3)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int iVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  int iVar11;
  
  FUN_007c6a90(&param_2);
  FUN_007c6dc0(&param_2);
  uVar4 = param_2;
  if ((-1 < (int)param_3) && (iVar11 = *(int *)(param_2 + 0x18), -1 < iVar11)) {
    iVar7 = (int)param_3 * 3 + 0xa3;
    iVar1 = *(int *)(param_1 + iVar7 * 4);
    iVar7 = param_1 + iVar7 * 4;
    iVar2 = *(int *)(iVar1 + -4 + *(int *)(iVar7 + 4) * 4);
    *(int *)(iVar1 + iVar11 * 4) = iVar2;
    *(int *)(iVar2 + 0x18) = iVar11;
    FUN_0078c900(*(int *)(iVar7 + 4) + -1,0);
    *(undefined4 *)(uVar4 + 0x18) = 0xffffffff;
  }
  FUN_007c6a90(&param_2);
  FUN_007c6a90(&param_2);
  FUN_007c6a90(&param_2);
  FUN_007c6fd0(&param_2);
  puVar3 = *(undefined4 **)(param_1 + 0x108);
  uVar8 = *(uint *)(param_1 + 0x11c) &
          ((((uVar4 & 0xff ^ 0x811c9dc5) * 0x1000193 ^ uVar4 >> 8 & 0xff) * 0x1000193 ^
           param_2 >> 0x10 & 0xff) * 0x1000193 ^ param_2 >> 0x18) * 0x1000193;
  param_3 = *(undefined4 **)(*(int *)(param_1 + 0x110) + uVar8 * 8);
  puVar9 = (undefined4 *)(*(int *)(param_1 + 0x110) + uVar8 * 8 + 4);
  puVar5 = param_3;
  while( true ) {
    puVar6 = puVar3;
    if (param_3 != puVar3) {
      puVar6 = *(undefined4 **)*puVar9;
    }
    if (puVar5 == puVar6) goto LAB_007c79e6;
    puVar6 = puVar5;
    if (puVar5[2] == uVar4) break;
    puVar5 = (undefined4 *)*puVar5;
  }
  while( true ) {
    puVar10 = puVar3;
    if (param_3 != puVar3) {
      puVar10 = *(undefined4 **)*puVar9;
    }
    if ((puVar6 == puVar10) || (uVar4 != puVar6[2])) break;
    puVar6 = (undefined4 *)*puVar6;
  }
  if (puVar5 == puVar6) {
LAB_007c79e6:
    puVar6 = puVar3;
    puVar5 = puVar3;
  }
  iVar11 = 0;
  if (puVar5 != puVar6) {
    do {
      puVar5 = (undefined4 *)*puVar5;
      iVar11 = iVar11 + 1;
    } while (puVar5 != puVar6);
    if (iVar11 != 0) {
      FUN_007c6a90(&param_2);
      if ((*(int *)(uVar4 + 4) != 0) &&
         (iVar11 = *(int *)(*(int *)(uVar4 + 4) + 0xc), iVar7 = FUN_00af0010(),
         (uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
         (uint)*(ushort *)(iVar7 + 0x1da))) {
        FUN_00a6f530(param_1);
      }
    }
  }
  return;
}



/* FUNCTION 11838 ; VA 0x007c7a50 ; FUN_007c7a50 */

void __thiscall FUN_007c7a50(int param_1,int param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  iVar1 = *(int *)(param_2 + 0x18);
  if (-1 < iVar1) {
    param_1 = param_1 + param_3 * 0xc;
    iVar2 = *(int *)(*(int *)(param_1 + 0x28c) + -4 + *(int *)(param_1 + 0x290) * 4);
    *(int *)(*(int *)(param_1 + 0x28c) + iVar1 * 4) = iVar2;
    *(int *)(iVar2 + 0x18) = iVar1;
    FUN_0078c900(*(int *)(param_1 + 0x290) + -1,0);
    *(undefined4 *)(param_2 + 0x18) = 0xffffffff;
  }
  return;
}



/* FUNCTION 11839 ; VA 0x007c7aa0 ; FUN_007c7aa0 */

void FUN_007c7aa0(undefined4 param_1,int *param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  int *piVar8;
  int *piVar9;
  int *piVar10;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  int iStack_48;
  uint uStack_34;
  int *piStack_30;
  int *piStack_2c;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3480;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_007c11a0(param_2);
  iStack_8 = 0;
  FUN_007c04c0(piStack_30,piStack_2c,((int)piStack_2c - (int)piStack_30) / 0x1c,param_1);
  piStack_1c = piStack_2c;
  piStack_18 = piStack_2c;
  piVar6 = piStack_2c;
  if ((piStack_30 != piStack_2c) &&
     (piStack_14 = piStack_30, piVar8 = piStack_30 + 7, piStack_30 + 7 != piStack_2c)) {
    do {
      if (*piStack_14 == *piVar8) {
        piVar10 = piStack_14 + 1;
        piStack_1c = piVar8;
        cVar2 = FUN_009cbaa0(piVar10,piVar8 + 1);
        piVar6 = piStack_18;
        if (cVar2 != '\0') {
          piVar8 = piVar8 + 7;
          if (piVar8 == piStack_18) goto LAB_007c7c1c;
          piStack_1c = piStack_1c + 8;
          goto LAB_007c7b70;
        }
      }
      piVar10 = piVar8 + 7;
      piStack_14 = piVar8;
      piVar8 = piVar10;
    } while (piVar10 != piVar6);
    piStack_1c = piStack_2c;
    piStack_2c = piVar6;
  }
  goto LAB_007c7c34;
LAB_007c7b70:
  do {
    if ((*piStack_14 != *piVar8) ||
       (cVar2 = FUN_009cbaa0(piVar10,piStack_1c), piVar6 = piVar10, cVar2 == '\0')) {
      piStack_14 = piStack_14 + 7;
      piVar6 = piVar10 + 7;
      *piStack_14 = *piVar8;
      if (piVar6 != piStack_1c) {
        uVar5 = piVar10[0xc];
        if (0xf < uVar5) {
          iVar4 = *piVar6;
          uVar7 = uVar5 + 1;
          iVar3 = iVar4;
          if (0xfff < uVar7) {
            iVar3 = *(int *)(iVar4 + -4);
            uVar7 = uVar5 + 0x24;
            if (0x1f < (iVar4 - iVar3) - 4U) goto LAB_007c7e44;
          }
          FUN_01674ea0(iVar3,uVar7);
        }
        piVar10[0xb] = 0;
        piVar10[0xc] = 0xf;
        *(undefined *)piVar6 = 0;
        iVar4 = piStack_1c[1];
        iVar3 = piStack_1c[2];
        iVar1 = piStack_1c[3];
        *piVar6 = *piStack_1c;
        piVar10[8] = iVar4;
        piVar10[9] = iVar3;
        piVar10[10] = iVar1;
        iVar4 = piStack_1c[5];
        piVar10[0xb] = piStack_1c[4];
        piVar10[0xc] = iVar4;
        piStack_1c[4] = 0;
        piStack_1c[5] = 0xf;
        *(undefined *)piStack_1c = 0;
      }
    }
    piVar8 = piVar8 + 7;
    piStack_1c = piStack_1c + 7;
    piVar10 = piVar6;
  } while (piVar8 != piStack_18);
LAB_007c7c1c:
  piStack_1c = piStack_2c;
  piStack_2c = piStack_14 + 7;
  piVar6 = piStack_18;
LAB_007c7c34:
  piVar8 = piStack_1c;
  piStack_14 = piStack_2c;
  if (piStack_2c != piVar6) {
    piVar8 = piStack_1c;
    if (piVar6 != piStack_1c) {
      piVar10 = piVar6 + 1;
      piVar9 = piStack_2c + 1;
      piStack_2c = piStack_1c;
      do {
        *piStack_14 = *piVar6;
        if (piVar9 != piVar10) {
          if (0xf < (uint)piVar9[5]) {
            iVar4 = *piVar9;
            uVar5 = piVar9[5] + 1;
            iVar3 = iVar4;
            if (0xfff < uVar5) {
              iVar3 = *(int *)(iVar4 + -4);
              uVar5 = piVar9[5] + 0x24;
              if (0x1f < (iVar4 - iVar3) - 4U) goto LAB_007c7e44;
            }
            FUN_01674ea0(iVar3,uVar5);
            piVar6 = piStack_18;
          }
          piVar9[4] = 0;
          piVar9[5] = 0xf;
          *(undefined *)piVar9 = 0;
          iVar4 = piVar10[1];
          iVar3 = piVar10[2];
          iVar1 = piVar10[3];
          *piVar9 = *piVar10;
          piVar9[1] = iVar4;
          piVar9[2] = iVar3;
          piVar9[3] = iVar1;
          iVar4 = piVar10[5];
          piVar9[4] = piVar10[4];
          piVar9[5] = iVar4;
          piVar10[4] = 0;
          piVar10[5] = 0xf;
          *(undefined *)piVar10 = 0;
        }
        piVar6 = piVar6 + 7;
        piStack_14 = piStack_14 + 7;
        piVar9 = piVar9 + 7;
        piVar10 = piVar10 + 7;
        piVar8 = piStack_2c;
        piStack_18 = piVar6;
      } while (piVar6 != piStack_1c);
    }
    FUN_007be6b0(piStack_14,piVar8,&piStack_30);
    piStack_2c = piStack_14;
    piVar8 = piStack_2c;
  }
  piStack_2c = piVar8;
  if (DAT_01ee4200 != '\0') {
    FUN_01677490(DAT_01ee4200,"Cluster %p: notify waiting for %d assets (%d unique)",param_1,
                 (param_2[1] - *param_2) / 0x1c,((int)piStack_2c - (int)piStack_30) / 0x1c);
  }
  FUN_007c6dc0(&param_1);
  uVar5 = 0;
  iVar4 = (int)piStack_2c - (int)piStack_30 >> 0x1f;
  if (((int)piStack_2c - (int)piStack_30) / 0x1c + iVar4 != iVar4) {
    param_2 = (int *)0x0;
    do {
      uStack_50 = param_1;
      uStack_4c = *(undefined4 *)((int)param_2 + (int)piStack_30);
      FUN_0054ef60((undefined *)((int)(piStack_30 + 1) + (int)param_2));
      iStack_8._0_1_ = 1;
      iVar4 = FUN_007be600(&uStack_50);
      FUN_007beea0(auStack_20,0,iVar4 + 0x10,iVar4);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (0xf < uStack_34) {
        uVar7 = uStack_34 + 1;
        iVar4 = iStack_48;
        if (0xfff < uVar7) {
          iVar4 = *(int *)(iStack_48 + -4);
          uVar7 = uStack_34 + 0x24;
          if (0x1f < (iStack_48 - iVar4) - 4U) {
LAB_007c7e44:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar7);
      }
      uVar5 = uVar5 + 1;
      param_2 = param_2 + 7;
    } while (uVar5 < (uint)(((int)piStack_2c - (int)piStack_30) / 0x1c));
  }
  FUN_007c4590();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11840 ; VA 0x007c7e50 ; FUN_007c7e50 */

void __thiscall FUN_007c7e50(int param_1,int *param_2)

{
  int *piVar1;
  undefined8 uStack_34;
  float fStack_2c;
  undefined8 uStack_28;
  float fStack_20;
  float fStack_14;
  float fStack_8;
  
  piVar1 = *(int **)(*(int *)(param_1 + 0x18c) + 0x52c);
  if (piVar1 != (int *)0x0) {
    fStack_2c = (float)param_2[2] * DAT_018e3f8c;
    fStack_20 = (float)param_2[5] * DAT_018e3f8c;
    uStack_34 = CONCAT44((float)param_2[1] * DAT_018e3f8c,(float)*param_2 * DAT_018e3f8c);
    uStack_28 = CONCAT44((float)param_2[4] * DAT_018e3f8c,(float)param_2[3] * DAT_018e3f8c);
    fStack_14 = fStack_20;
    fStack_8 = fStack_2c;
    (**(code **)(*piVar1 + 0x14))(&uStack_34,0);
  }
  return;
}



/* FUNCTION 11841 ; VA 0x007c7f00 ; FUN_007c7f00 */

int __thiscall FUN_007c7f00(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abb78;
  pvStack_10 = ExceptionList;
  iVar4 = *param_2;
  ExceptionList = &pvStack_10;
  if ((iVar4 == 0) ||
     (iVar5 = *(int *)(iVar4 + 0xc), ExceptionList = &pvStack_10, iVar2 = FUN_00aff8c0(),
     (uint)*(ushort *)(iVar2 + 0x1da) <
     (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))) {
    if ((((*(char *)(param_1 + 0x1c0) == '\0') || (*param_2 == 0)) ||
        (iVar4 = *(int *)(*param_2 + 0xc), iVar5 = FUN_00b63e30(),
        (uint)*(ushort *)(iVar5 + 0x1da) <
        (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) &&
       (iVar4 = FUN_0170d75d(*param_2,0,&RBX::Instance::RTTI_Type_Descriptor,
                             &RBX::Effect::RTTI_Type_Descriptor,0), iVar4 == 0)) {
      ExceptionList = pvStack_10;
      return 0;
    }
    iVar4 = FUN_007c8af0(param_2);
    ExceptionList = pvStack_10;
    return iVar4;
  }
  uVar3 = FUN_0060dcd0(auStack_18,iVar4);
  uStack_8 = 0;
  iVar4 = FUN_007c8e00(uVar3);
  if (piStack_14 == (int *)0x0) {
    ExceptionList = pvStack_10;
    return iVar4;
  }
  LOCK();
  piVar1 = piStack_14 + 1;
  iVar4 = *piVar1;
  iVar5 = *piVar1;
  *piVar1 = iVar4 + -1;
  UNLOCK();
  if (iVar4 + -1 != 0) {
    ExceptionList = pvStack_10;
    return iVar5;
  }
  iVar5 = (**(code **)*piStack_14)();
  LOCK();
  piVar1 = piStack_14 + 2;
  iVar4 = *piVar1;
  *piVar1 = *piVar1 + -1;
  UNLOCK();
  if (iVar4 != 1) {
    ExceptionList = pvStack_10;
    return iVar5;
  }
  iVar4 = (**(code **)(*piStack_14 + 4))();
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 11842 ; VA 0x007c8020 ; FUN_007c8020 */

void __fastcall FUN_007c8020(int param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined4 uVar4;
  int iVar5;
  byte *pbVar6;
  undefined4 *puVar7;
  int *piVar8;
  undefined8 uVar9;
  undefined auStack_6c [4];
  uint uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined auStack_54 [4];
  uint uStack_50;
  int iStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  int iStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  undefined8 uStack_34;
  int iStack_2c;
  int *piStack_28;
  int iStack_24;
  uint uStack_20;
  int iStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b34c6;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2f68) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb2f68), DAT_01eb2f68 == -1)) {
    uStack_8 = 0;
    uVar9 = FUN_0152dab0("Render","processPendingAttachments",0xffffffff);
    DAT_01eb2f64 = (int)((ulonglong)uVar9 >> 0x20);
    DAT_01eb2f60 = (undefined4)uVar9;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb2f68);
  }
  uVar4 = DAT_01eb2f60;
  uStack_3c = DAT_01eb2f60;
  iStack_24 = DAT_01eb2f64;
  iStack_38 = DAT_01eb2f64;
  uStack_34 = FUN_0152d930(DAT_01eb2f60,DAT_01eb2f64);
  uStack_8 = 1;
  auStack_54[0] = 0;
  uStack_68 = FUN_00588320(0xb);
  uStack_48 = 0x3f800000;
  auStack_6c[0] = 0;
  uStack_64 = 0;
  uStack_60 = 0x3f800000;
  uStack_5c = 0;
  uStack_58 = 0;
  iStack_40 = 0;
  iStack_4c = 0;
  uStack_44 = 0;
  iStack_1c = 0;
  uStack_20 = uStack_68;
  uStack_18 = uStack_68;
  if (auStack_54 != (undefined *)(param_1 + 0x124)) {
    uStack_50 = uStack_68;
    FUN_007c6140();
    uStack_44 = *(undefined4 *)(param_1 + 0x134);
    iStack_1c = *(int *)(param_1 + 0x138);
    uStack_48 = *(undefined4 *)(param_1 + 0x130);
    iStack_4c = *(int *)(param_1 + 300);
    uStack_18 = *(uint *)(param_1 + 0x128);
    *(undefined4 *)(param_1 + 0x138) = 0;
    *(undefined4 *)(param_1 + 300) = 0;
    *(undefined4 *)(param_1 + 0x134) = 0;
  }
  iVar5 = iStack_4c;
  uStack_50 = uStack_18;
  iStack_40 = iStack_1c;
  if ((undefined *)(param_1 + 0x124) != auStack_6c) {
    FUN_007c6140();
    *(undefined4 *)(param_1 + 0x130) = 0x3f800000;
    *(undefined4 *)(param_1 + 0x134) = 0;
    *(undefined4 *)(param_1 + 0x138) = 0;
    *(uint *)(param_1 + 0x128) = uStack_20;
    *(undefined4 *)(param_1 + 300) = 0;
  }
  FUN_007c6140();
  iVar2 = iStack_24;
  if (iVar5 == 0) {
    puVar7 = (undefined4 *)0x0;
  }
  else {
    puVar7 = *(undefined4 **)(iStack_1c + uStack_18 * 4);
  }
  do {
    if (puVar7 == (undefined4 *)0x0) {
      FUN_007c6140();
      uStack_8 = 5;
      FUN_0152dda0(uVar4,iVar2,uStack_34);
      ExceptionList = pvStack_10;
      return;
    }
    iVar5 = puVar7[4];
    iStack_2c = 0;
    piStack_28 = (int *)0x0;
    if (iVar5 != 0) {
      piVar8 = (int *)(iVar5 + 4);
      iVar5 = *(int *)(iVar5 + 4);
      while (iVar5 != 0) {
        LOCK();
        iVar2 = *piVar8;
        if (iVar5 == iVar2) {
          *piVar8 = iVar5 + 1;
          iVar2 = iVar5;
        }
        UNLOCK();
        if (iVar2 == iVar5) {
          iStack_2c = puVar7[3];
          piStack_28 = (int *)puVar7[4];
          break;
        }
        iVar5 = *piVar8;
      }
    }
    uStack_8._1_3_ = (undefined3)((uint)uStack_8 >> 8);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (iStack_2c != 0) {
      uVar3 = *(uint *)(iStack_2c + 0x34);
      if (uVar3 != 0) {
        iVar5 = *(int *)(uVar3 + 0xc);
        iVar2 = FUN_00d400b0();
        if ((uint)*(ushort *)(iVar2 + 0x1da) <
            (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) {
          uVar3 = FUN_007c0ce0();
        }
        if (uVar3 != 0) {
          pbVar6 = (byte *)(iStack_14 + 0x250) + *(byte *)(iStack_14 + 0x250) + 1;
          uStack_20 = uVar3;
          FUN_00606ea0(&iStack_1c,(uVar3 >> 3) + uVar3,&uStack_20,
                       -(uint)(pbVar6 != (byte *)0x0) & (uint)(pbVar6 + 1));
          if (iStack_1c == 0) {
            uStack_18 = uVar3;
            FUN_007c35c0(&uStack_18);
            iStack_24 = FUN_01674e20(0x318);
            uStack_8._0_1_ = 4;
            if (iStack_24 == 0) {
              uStack_8 = CONCAT31(uStack_8._1_3_,3);
              FUN_007c0e00(0);
            }
            else {
              uVar4 = FUN_008181e0(*(undefined4 *)(iStack_14 + 0x18c),uVar3);
              uStack_8 = CONCAT31(uStack_8._1_3_,3);
              FUN_007c0e00(uVar4);
            }
          }
          goto LAB_007c82c9;
        }
      }
      iVar5 = FUN_008b3380(iStack_2c);
      if (iVar5 != 0) {
        FUN_007c4610(&iStack_2c);
      }
    }
LAB_007c82c9:
    piVar8 = piStack_28;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_28[1] + -1;
      piStack_28[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        piVar1 = piVar8 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    puVar7 = (undefined4 *)*puVar7;
    uVar4 = uStack_3c;
    iVar2 = iStack_38;
  } while( true );
}



/* FUNCTION 11843 ; VA 0x007c8390 ; FUN_007c8390 */

void __fastcall FUN_007c8390(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined8 uVar6;
  undefined auStack_70 [4];
  int *piStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined auStack_58 [4];
  int *piStack_54;
  int iStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  int iStack_44;
  int *piStack_40;
  int iStack_3c;
  undefined8 uStack_38;
  int iStack_30;
  int iStack_2c;
  int *piStack_28;
  int iStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined auStack_18 [4];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b350e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb3018) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb3018), DAT_01eb3018 == -1)) {
    uStack_8 = 0;
    uVar6 = FUN_0152dab0("Render","processPendingClusters",0xffffffff);
    DAT_01eb3014 = (int)((ulonglong)uVar6 >> 0x20);
    DAT_01eb3010 = (int *)uVar6;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb3018);
  }
  piStack_28 = DAT_01eb3010;
  piStack_40 = DAT_01eb3010;
  iStack_30 = DAT_01eb3014;
  iStack_3c = DAT_01eb3014;
  uStack_38 = FUN_0152d930(DAT_01eb3010,DAT_01eb3014);
  uStack_8 = 1;
  if ((*(int *)(param_1 + 0xf4) != 0) && (DAT_01d6517a != '\0')) {
    FUN_016774b0(DAT_01d6517a,"Processing %u new MegaClusters",*(int *)(param_1 + 0xf4));
  }
  auStack_58[0] = 0;
  piVar3 = (int *)FUN_00588320(0xb);
  uStack_4c = 0x3f800000;
  auStack_70[0] = 0;
  uStack_68 = 0;
  uStack_64 = 0x3f800000;
  uStack_60 = 0;
  uStack_5c = 0;
  iStack_44 = 0;
  iStack_50 = 0;
  uStack_48 = 0;
  iStack_14 = 0;
  iStack_24 = 0;
  piStack_6c = piVar3;
  piStack_1c = piVar3;
  if (auStack_58 != (undefined *)(param_1 + 0xec)) {
    piStack_54 = piVar3;
    FUN_007c61e0();
    uStack_48 = *(undefined4 *)(param_1 + 0xfc);
    iStack_24 = *(int *)(param_1 + 0x100);
    uStack_4c = *(undefined4 *)(param_1 + 0xf8);
    piStack_1c = *(int **)(param_1 + 0xf0);
    iStack_14 = *(int *)(param_1 + 0xf4);
    *(undefined4 *)(param_1 + 0x100) = 0;
    *(undefined4 *)(param_1 + 0xf4) = 0;
    *(undefined4 *)(param_1 + 0xfc) = 0;
  }
  piStack_54 = piStack_1c;
  iStack_50 = iStack_14;
  iStack_44 = iStack_24;
  if ((undefined *)(param_1 + 0xec) != auStack_70) {
    FUN_007c61e0();
    *(undefined4 *)(param_1 + 0xf8) = 0x3f800000;
    *(undefined4 *)(param_1 + 0xfc) = 0;
    *(undefined4 *)(param_1 + 0x100) = 0;
    *(int **)(param_1 + 0xf0) = piVar3;
    *(undefined4 *)(param_1 + 0xf4) = 0;
  }
  FUN_007c61e0();
  iVar2 = iStack_30;
  piVar3 = piStack_28;
  if (iStack_14 == 0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    puVar5 = *(undefined4 **)(iStack_24 + (int)piStack_1c * 4);
  }
  do {
    if (puVar5 == (undefined4 *)0x0) {
      FUN_007c61e0();
      uStack_8 = 6;
      FUN_0152dda0(piVar3,iVar2,uStack_38);
      ExceptionList = pvStack_10;
      return;
    }
    iVar2 = puVar5[4];
    iStack_20 = 0;
    piStack_1c = (int *)0x0;
    if (iVar2 != 0) {
      piVar3 = (int *)(iVar2 + 4);
      iVar2 = *(int *)(iVar2 + 4);
      while (iVar2 != 0) {
        LOCK();
        iVar4 = *piVar3;
        if (iVar2 == iVar4) {
          *piVar3 = iVar2 + 1;
          iVar4 = iVar2;
        }
        UNLOCK();
        if (iVar4 == iVar2) {
          iStack_20 = puVar5[3];
          piStack_1c = (int *)puVar5[4];
          break;
        }
        iVar2 = *piVar3;
      }
    }
    piVar3 = piStack_1c;
    if (iStack_20 != 0) {
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piStack_1c[1] = piStack_1c[1] + 1;
        UNLOCK();
      }
      uStack_8._1_3_ = (undefined3)((uint)uStack_8 >> 8);
      uStack_8._0_1_ = 4;
      iStack_2c = iStack_20;
      piStack_28 = piStack_1c;
      FUN_00a6e300(param_1);
      iStack_30 = FUN_01674e20(600);
      uStack_8._0_1_ = 5;
      if (iStack_30 == 0) {
        iStack_24 = 0;
      }
      else {
        iStack_24 = FUN_00807300(*(undefined4 *)(param_1 + 0x18c),&iStack_20);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      FUN_007beb80(auStack_18,&iStack_24,iStack_30);
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[1] + -1;
        piVar3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar2 = piVar3[2] + -1;
          piVar3[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
    }
    piVar3 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1 + -1;
        *piVar1 = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    puVar5 = (undefined4 *)*puVar5;
    iVar2 = iStack_3c;
    piVar3 = piStack_40;
  } while( true );
}



/* FUNCTION 11844 ; VA 0x007c86e0 ; FUN_007c86e0 */

void __thiscall FUN_007c86e0(int param_1,uint param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  undefined4 *puVar9;
  int *piVar10;
  bool bVar11;
  undefined8 uVar12;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  int iStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3556;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb3028) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb3028), DAT_01eb3028 == -1)) {
    uStack_8 = 0;
    uVar12 = FUN_0152dab0("Render","processPendingParts",0xffffffff);
    DAT_01eb3024 = (int)((ulonglong)uVar12 >> 0x20);
    DAT_01eb3020 = (undefined4)uVar12;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb3028);
  }
  iVar3 = DAT_01eb3024;
  uVar2 = DAT_01eb3020;
  iStack_1c = DAT_01eb3024;
  uVar12 = FUN_0152d930(DAT_01eb3020,DAT_01eb3024);
  uStack_8 = 1;
  uVar4 = FUN_00588320(0xb);
  iVar6 = *(int *)(param_1 + 0xe8);
  *(undefined4 *)(param_1 + 0xe8) = 0;
  uStack_18 = *(uint *)(param_1 + 0xd8);
  *(undefined4 *)(param_1 + 0xd8) = uVar4;
  iVar7 = *(int *)(param_1 + 0xdc);
  *(undefined4 *)(param_1 + 0xdc) = 0;
  *(undefined4 *)(param_1 + 0xe0) = 0x3f800000;
  uStack_8._0_1_ = 2;
  *(undefined4 *)(param_1 + 0xe4) = 0;
  if (iVar7 == 0) {
    puVar9 = (undefined4 *)0x0;
    iVar6 = iStack_1c;
  }
  else {
    if (DAT_01d6517a != '\0') {
      FUN_01677490(DAT_01d6517a,"Added parts to process: %u, priority: %u",iVar7,param_2 & 0xff,0);
    }
    puVar9 = *(undefined4 **)(iVar6 + uStack_18 * 4);
    iVar6 = iStack_1c;
  }
  do {
    if (puVar9 == (undefined4 *)0x0) {
      FUN_007c61e0();
      uStack_8 = 5;
      FUN_0152dda0(uVar2,iVar6,uVar12);
      ExceptionList = pvStack_10;
      return;
    }
    iVar6 = puVar9[4];
    iStack_28 = 0;
    piStack_24 = (int *)0x0;
    if (iVar6 != 0) {
      piVar10 = (int *)(iVar6 + 4);
      iVar6 = *(int *)(iVar6 + 4);
      while (iVar6 != 0) {
        LOCK();
        iVar7 = *piVar10;
        if (iVar6 == iVar7) {
          *piVar10 = iVar6 + 1;
          iVar7 = iVar6;
        }
        UNLOCK();
        if (iVar7 == iVar6) {
          iStack_28 = puVar9[3];
          piStack_24 = (int *)puVar9[4];
          break;
        }
        iVar6 = *piVar10;
      }
    }
    uStack_8._0_1_ = 3;
    if (iStack_28 == 0) {
      if (DAT_01ee4200 != '\0') {
        FUN_016774b0(DAT_01ee4200,"Part %p died before we could process it",puVar9[2]);
      }
    }
    else if (*(int *)(iStack_28 + 0xb0) == 0) {
      iVar6 = *(int *)(iStack_28 + 0x34);
      if (iVar6 != 0) {
        iVar7 = *(int *)(iVar6 + 0xc);
        iVar5 = FUN_00d400b0();
        if ((uint)*(ushort *)(iVar5 + 0x1da) <
            (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) {
          iVar6 = FUN_007c0ce0();
        }
        if (iVar6 != 0) {
          iStack_1c = iVar6;
          iVar7 = FUN_007c35c0(&iStack_1c);
          iStack_1c = iVar7 + 4;
          if (*(int *)(iVar7 + 4) == 0) {
            iStack_20 = FUN_01674e20(0x318);
            uStack_8._0_1_ = 4;
            if (iStack_20 == 0) {
              uVar4 = 0;
            }
            else {
              uVar4 = FUN_008181e0(*(undefined4 *)(iStack_14 + 0x18c),iVar6);
            }
            uStack_8._0_1_ = 3;
            FUN_007c0e00(uVar4);
          }
          iVar6 = iStack_28;
          uVar4 = FUN_00d00f70(iStack_28);
          *(undefined4 *)(iVar6 + 0xb4) = uVar4;
          FUN_00818b80(&iStack_28);
          goto LAB_007c8a24;
        }
      }
      iVar7 = FUN_008b3380(iStack_28);
      iVar6 = iStack_28;
      if (iVar7 == 0) {
        if (DAT_01ee4200 != '\0') {
          FUN_016774b0(DAT_01ee4200,"Part %p removed from workspace before we could process it",
                       puVar9[2]);
        }
      }
      else {
        uVar4 = FUN_00d00f70(iStack_28);
        iVar7 = iStack_28;
        *(undefined4 *)(iVar6 + 0xb4) = uVar4;
        if (DAT_01d6c7c4 == '\0') {
          if (DAT_01d6866c == '\0') {
            uStack_18 = CONCAT31(uStack_18._1_3_,*(int *)(iStack_28 + 0x70) == 0);
          }
          else {
            uStack_18 = CONCAT31(uStack_18._1_3_,*(int *)(iStack_28 + 0x6c) == -1);
          }
        }
        else {
          iVar6 = *(int *)(iStack_28 + 0xc);
          iVar8 = FUN_00cfb1a0();
          iVar5 = 0;
          if ((uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8) <=
              (uint)*(ushort *)(iVar8 + 0x1da)) {
            iVar5 = iVar7;
          }
          if ((iVar5 == 0) || (*(char *)(iVar5 + 0x191) == '\0')) {
            if (DAT_01d6866c == '\0') {
              bVar11 = *(int *)(iVar7 + 0x70) == 0;
            }
            else {
              bVar11 = *(int *)(iVar7 + 0x6c) == -1;
            }
            uStack_18 = CONCAT31(uStack_18._1_3_,1);
            if (bVar11) goto LAB_007c89ee;
          }
          uStack_18 = uStack_18 & 0xffffff00;
        }
LAB_007c89ee:
        FUN_007c4da0(&iStack_28,uStack_18,param_2);
      }
    }
    else {
      FUN_007c8e00(&iStack_28);
    }
LAB_007c8a24:
    piVar10 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_24[1] + -1;
      piStack_24[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar10 + 2;
        iVar6 = *piVar1 + -1;
        *piVar1 = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar10 + 4))();
        }
      }
    }
    puVar9 = (undefined4 *)*puVar9;
    iVar6 = iVar3;
  } while( true );
}



/* FUNCTION 11845 ; VA 0x007c8af0 ; FUN_007c8af0 */

int FUN_007c8af0(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  piVar2 = param_1;
  param_1 = (int *)*param_1;
  iVar3 = FUN_007c3220(&param_1);
  iVar5 = piVar2[1];
  if (iVar5 != 0) {
    LOCK();
    *(int *)(iVar5 + 8) = *(int *)(iVar5 + 8) + 1;
    UNLOCK();
    iVar5 = piVar2[1];
  }
  iVar4 = *piVar2;
  *(int *)(iVar3 + 4) = iVar4;
  piVar2 = *(int **)(iVar3 + 8);
  *(int *)(iVar3 + 8) = iVar5;
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar5 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      iVar4 = (**(code **)(*piVar2 + 4))();
    }
  }
  return iVar4;
}



/* FUNCTION 11846 ; VA 0x007c8b40 ; FUN_007c8b40 */

void FUN_007c8b40(undefined4 param_1,uint param_2)

{
  undefined auStack_c [8];
  
  if (DAT_01ee4200 != '\0') {
    FUN_01677490(DAT_01ee4200,"Fast Cluster queued to check - %p, isFW - %u",param_1,param_2 & 0xff,
                 0);
  }
  FUN_007beb80(auStack_c,&param_1,param_2);
  return;
}



/* FUNCTION 11847 ; VA 0x007c8ba0 ; FUN_007c8ba0 */

void __thiscall FUN_007c8ba0(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 0x23c);
  if (*(undefined4 **)(param_1 + 0x240) != puVar1) {
    *puVar1 = param_2;
    *(int *)(param_1 + 0x23c) = *(int *)(param_1 + 0x23c) + 4;
    return;
  }
  FUN_006030d0(puVar1,&param_2);
  return;
}



/* FUNCTION 11848 ; VA 0x007c8bd0 ; FUN_007c8bd0 */

void __thiscall FUN_007c8bd0(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 0x224);
  if (*(undefined4 **)(param_1 + 0x228) != puVar1) {
    *puVar1 = param_2;
    *(int *)(param_1 + 0x224) = *(int *)(param_1 + 0x224) + 4;
    return;
  }
  FUN_006030d0(puVar1,&param_2);
  return;
}



/* FUNCTION 11849 ; VA 0x007c8c00 ; FUN_007c8c00 */

void __thiscall FUN_007c8c00(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 0x230);
  if (*(undefined4 **)(param_1 + 0x234) != puVar1) {
    *puVar1 = param_2;
    *(int *)(param_1 + 0x230) = *(int *)(param_1 + 0x230) + 4;
    return;
  }
  FUN_006030d0(puVar1,&param_2);
  return;
}



/* FUNCTION 11850 ; VA 0x007c8c30 ; FUN_007c8c30 */

void __thiscall FUN_007c8c30(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  
  puVar2 = *(undefined4 **)(param_1 + 0x218);
  if (*(undefined4 **)(param_1 + 0x21c) != puVar2) {
    *puVar2 = 0;
    puVar2[1] = 0;
    if (param_2[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *puVar2 = *param_2;
    puVar2[1] = param_2[1];
    *(int *)(param_1 + 0x218) = *(int *)(param_1 + 0x218) + 8;
    return;
  }
  FUN_005c1970(puVar2,param_2);
  return;
}



/* FUNCTION 11851 ; VA 0x007c8c80 ; FUN_007c8c80 */

void __thiscall FUN_007c8c80(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  
  uVar4 = param_2;
  if (DAT_01ee4200 != '\0') {
    FUN_01677490(DAT_01ee4200,"Frame %u: Queue invalidate fast cluster: %p",
                 *(undefined4 *)(param_1 + 0x24),param_2,0);
  }
  iVar5 = FUN_007c3770(&param_2);
  piVar1 = (int *)(iVar5 + 4);
  if (*(int *)(iVar5 + 0xc) == 0) {
    *(undefined4 *)(iVar5 + 0xc) = uVar4;
    iVar2 = *(int *)(param_1 + 0x94);
    piVar3 = *(int **)(iVar2 + 4);
    *(int **)(iVar5 + 8) = piVar3;
    *piVar1 = iVar2;
    *(int **)(iVar2 + 4) = piVar1;
    *piVar3 = (int)piVar1;
  }
  return;
}



/* FUNCTION 11852 ; VA 0x007c8ce0 ; FUN_007c8ce0 */

void __thiscall FUN_007c8ce0(int param_1,undefined4 param_2)

{
  undefined auStack_c [8];
  
  if (DAT_01ee4200 != '\0') {
    FUN_01677490(DAT_01ee4200,"Frame %u: Queue invalidate part: %p",*(undefined4 *)(param_1 + 0x24),
                 param_2,0);
  }
  FUN_007beb80(auStack_c,&param_2,param_2);
  return;
}



/* FUNCTION 11853 ; VA 0x007c8d30 ; FUN_007c8d30 */

void __thiscall FUN_007c8d30(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 0x26c);
  if (*(undefined4 **)(param_1 + 0x270) != puVar1) {
    *puVar1 = param_2;
    *(int *)(param_1 + 0x26c) = *(int *)(param_1 + 0x26c) + 4;
    return;
  }
  FUN_006030d0(puVar1,&param_2);
  return;
}



/* FUNCTION 11854 ; VA 0x007c8d60 ; FUN_007c8d60 */

int FUN_007c8d60(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3568;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar6 = (undefined4 *)FUN_0060e0c0(auStack_18,param_1);
  uStack_8 = 0;
  iVar7 = FUN_007c33f0(&param_1);
  uVar3 = *puVar6;
  uVar4 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  *(undefined4 *)(iVar7 + 4) = uVar3;
  piVar5 = *(int **)(iVar7 + 8);
  *(undefined4 *)(iVar7 + 8) = uVar4;
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar1 = piVar5 + 2;
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar7 = (**(code **)(*piVar5 + 4))();
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar5 = piStack_14 + 2;
    iVar2 = *piVar5;
    *piVar5 = *piVar5 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      iVar7 = (**(code **)(*piStack_14 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 11855 ; VA 0x007c8e00 ; FUN_007c8e00 */

int __thiscall FUN_007c8e00(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  piVar2 = param_2;
  iVar3 = (**(code **)(*(int *)*param_2 + 0xb4))();
  if (iVar3 == 10) {
    if (DAT_01ee4200 != '\0') {
      FUN_01677490(DAT_01ee4200,"Frame %u: Adding Megacluster to queue - %p",
                   *(undefined4 *)(param_1 + 0x24),*piVar2,0);
    }
  }
  else if (DAT_01ee4200 != '\0') {
    FUN_01677490(DAT_01ee4200,"Frame %u: Adding part to queue - %p",*(undefined4 *)(param_1 + 0x24),
                 *piVar2,0);
  }
  param_2 = (int *)*piVar2;
  iVar4 = FUN_007c33f0(&param_2);
  iVar3 = piVar2[1];
  if (iVar3 != 0) {
    LOCK();
    *(int *)(iVar3 + 8) = *(int *)(iVar3 + 8) + 1;
    UNLOCK();
    iVar3 = piVar2[1];
  }
  iVar5 = *piVar2;
  *(int *)(iVar4 + 4) = iVar5;
  piVar2 = *(int **)(iVar4 + 8);
  *(int *)(iVar4 + 8) = iVar3;
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar5 = (**(code **)(*piVar2 + 4))();
    }
  }
  return iVar5;
}



/* FUNCTION 11856 ; VA 0x007c8eb0 ; FUN_007c8eb0 */

void __thiscall FUN_007c8eb0(int param_1,undefined4 param_2)

{
  undefined auStack_c [8];
  
  if (DAT_01ee4200 != '\0') {
    FUN_01677490(DAT_01ee4200,"Frame %u: Queue priority invalidate fast cluster: %p",
                 *(undefined4 *)(param_1 + 0x24),param_2,0);
  }
  FUN_007beb80(auStack_c,&param_2,param_2);
  return;
}



/* FUNCTION 11857 ; VA 0x007c8f00 ; FUN_007c8f00 */

int __thiscall FUN_007c8f00(int param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar1 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3592;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_007c35c0(&param_2);
  if (*(int *)(iVar2 + 4) == 0) {
    param_2 = uVar1;
    FUN_007c35c0(&param_2);
    param_2 = FUN_01674e20(0x318);
    uStack_8 = 0;
    if (param_2 == 0) {
      uVar3 = 0;
    }
    else {
      uVar3 = FUN_008181e0(*(undefined4 *)(param_1 + 0x18c),uVar1);
    }
    uStack_8 = 0xffffffff;
    FUN_007c0e00(uVar3);
  }
  param_2 = uVar1;
  iVar2 = FUN_007c35c0(&param_2);
  ExceptionList = pvStack_10;
  return *(int *)(iVar2 + 4) + 0x30c;
}



/* FUNCTION 11858 ; VA 0x007c8fc0 ; FUN_007c8fc0 */

void FUN_007c8fc0(void)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  int *piVar7;
  int *piVar8;
  uint uVar9;
  int *piVar10;
  uint uStack_4c;
  uint uStack_48;
  int iStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  uint uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b35df;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  uStack_40 = 0x43000000;
  uStack_3c = 0x42800000;
  uStack_38 = 0x43000000;
  ExceptionList = &pvStack_10;
  FUN_007c72f0(&uStack_4c);
  uVar9 = 0;
  iStack_8 = 0;
  uVar5 = (uStack_48 - uStack_4c) + 3 >> 2;
  if (uStack_48 < uStack_4c) {
    uVar5 = 0;
  }
  if (uVar5 != 0) {
    do {
      FUN_0084e0d0();
      uVar9 = uVar9 + 1;
    } while (uVar9 != uVar5);
  }
  iVar4 = iStack_14;
  if (DAT_01d60bc0 != '\0') {
    puVar6 = *(undefined4 **)(iStack_14 + 0x194);
    for (puVar1 = (undefined4 *)*puVar6; puVar1 != puVar6; puVar1 = (undefined4 *)*puVar1) {
      (**(code **)(*(int *)puVar1[3] + 0xc))();
      if ((undefined4 *)puVar1[3] != (undefined4 *)0x0) {
        (*(code *)**(undefined4 **)puVar1[3])(1);
      }
    }
    piVar10 = *(int **)(iVar4 + 0x194);
    iStack_8._1_3_ = (uint3)((uint)iStack_8 >> 8);
    iStack_8._0_1_ = 1;
    piVar7 = (int *)*piVar10;
    *piVar10 = (int)piVar10;
    *(int *)(*(int *)(iVar4 + 0x194) + 4) = *(int *)(iVar4 + 0x194);
    *(undefined4 *)(iVar4 + 0x198) = 0;
    if (piVar7 != *(int **)(iVar4 + 0x194)) {
      do {
        piVar10 = (int *)*piVar7;
        FUN_01674ea0(piVar7,0x10);
        piVar7 = piVar10;
      } while (piVar10 != (int *)*(int *)(iVar4 + 0x194));
    }
    FUN_005cb500(8);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
  }
  iVar4 = iStack_14;
  if (*(int *)(iStack_14 + 600) == 0) {
    puVar6 = (undefined4 *)0x0;
  }
  else {
    puVar6 = *(undefined4 **)(*(int *)(iStack_14 + 0x264) + *(int *)(iStack_14 + 0x254) * 4);
  }
  for (; puVar6 != (undefined4 *)0x0; puVar6 = (undefined4 *)*puVar6) {
    FUN_00819280();
  }
  iVar3 = *(int *)(iVar4 + 0x1b4);
  piVar10 = (int *)(iVar4 + 0x1b4);
  *piVar10 = 0;
  if (iVar3 != 0) {
    FUN_007c3ff0(iVar3);
  }
  uStack_28 = FUN_01674e20(0x30);
  iStack_8._0_1_ = 2;
  if (uStack_28 == 0) {
    iVar3 = 0;
  }
  else {
    iVar3 = FUN_007c0f50(&uStack_40,0x3fc00000);
  }
  iVar2 = *piVar10;
  iStack_8._0_1_ = 0;
  *piVar10 = iVar3;
  if (iVar2 != 0) {
    FUN_007c3ff0(iVar2);
  }
  iVar3 = *(int *)(iVar4 + 0x1b8);
  if (iVar3 != 0) {
    iStack_8 = CONCAT31(iStack_8._1_3_,3);
    piStack_1c = (int *)0x0;
    piVar10 = (int *)0x0;
    piStack_34 = (int *)0x0;
    piStack_30 = (int *)0x0;
    piStack_18 = (int *)0x0;
    piStack_2c = (int *)0x0;
    uStack_20 = 1;
    if (*(int *)(iVar3 + 8) == 0) {
      piVar7 = (int *)0x0;
    }
    else {
      piVar7 = *(int **)(*(int *)(iVar3 + 0x14) + *(int *)(iVar3 + 4) * 4);
    }
    if (piVar7 != (int *)0x0) {
      do {
        if (piVar10 == piStack_30) {
          FUN_006030d0(piStack_30,piVar7 + 4);
          piVar10 = piStack_2c;
        }
        else {
          *piStack_30 = piVar7[4];
          piStack_30 = piStack_30 + 1;
        }
        piVar7 = (int *)*piVar7;
      } while (piVar7 != (int *)0x0);
      piStack_1c = piStack_34;
      piStack_18 = piVar10;
    }
    uVar9 = 0;
    uVar5 = (uint)((int)piStack_30 + (3 - (int)piStack_1c)) >> 2;
    if (piStack_30 < piStack_1c) {
      uVar5 = 0;
    }
    piStack_34 = piStack_1c;
    uStack_28 = uVar5;
    piStack_24 = piStack_1c;
    if (uVar5 != 0) {
      do {
        FUN_007b3d90();
        uVar9 = uVar9 + 1;
      } while (uVar9 != uVar5);
    }
    piVar7 = piStack_18;
    piVar10 = piStack_1c;
    piVar8 = (int *)(iStack_14 + 0x1b8);
    iVar4 = *piVar8;
    *piVar8 = 0;
    if (iVar4 != 0) {
      FUN_007c3ff0(iVar4);
    }
    uStack_28 = FUN_01674e20(0x30);
    iStack_8._0_1_ = 4;
    if (uStack_28 == 0) {
      iVar4 = 0;
    }
    else {
      iVar4 = FUN_007c0f50(&uStack_40,0x3fc00000);
    }
    iVar3 = *piVar8;
    *piVar8 = iVar4;
    if (iVar3 != 0) {
      FUN_007c3ff0(iVar3);
    }
    iVar4 = iStack_14;
    if (piVar10 != (int *)0x0) {
      uVar5 = (int)piVar7 - (int)piVar10 & 0xfffffffc;
      piVar7 = piVar10;
      if (0xfff < uVar5) {
        piVar7 = (int *)piVar10[-1];
        uVar5 = uVar5 + 0x23;
        if (0x1f < (uint)((int)piVar10 + (-4 - (int)piVar7))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(piVar7,uVar5);
      iVar4 = iStack_14;
    }
  }
  puVar6 = (undefined4 *)(iVar4 + 0x214);
  *(undefined4 *)(iVar4 + 0x1e8) = *(undefined4 *)(iVar4 + 0x1e4);
  FUN_005596d0(*puVar6,*(undefined4 *)(iVar4 + 0x218),puVar6);
  *(undefined4 *)(iVar4 + 0x218) = *puVar6;
  *(undefined4 *)(iVar4 + 0x230) = *(undefined4 *)(iVar4 + 0x22c);
  *(undefined4 *)(iVar4 + 0x23c) = *(undefined4 *)(iVar4 + 0x238);
  if (uStack_4c != 0) {
    uVar9 = iStack_44 - uStack_4c & 0xfffffffc;
    uVar5 = uStack_4c;
    if (0xfff < uVar9) {
      uVar5 = *(uint *)(uStack_4c - 4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (uStack_4c - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar9);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11859 ; VA 0x007c9320 ; FUN_007c9320 */

undefined4 __thiscall FUN_007c9320(int param_1,short *param_2)

{
  short *psVar1;
  short *psVar2;
  bool bVar3;
  
  psVar2 = *(short **)(param_1 + 0x1e4);
  psVar1 = *(short **)(param_1 + 0x1e8);
  bVar3 = psVar2 == psVar1;
  if (!bVar3) {
    do {
      if ((((*psVar2 == *param_2) && (psVar2[1] == param_2[1])) && (psVar2[2] == param_2[2])) &&
         (psVar2[3] == param_2[3])) break;
      psVar2 = psVar2 + 4;
    } while (psVar2 != psVar1);
    bVar3 = psVar2 == psVar1;
  }
  return CONCAT31((int3)((uint)psVar2 >> 8),!bVar3);
}



/* FUNCTION 11860 ; VA 0x007c9380 ; FUN_007c9380 */

void __thiscall FUN_007c9380(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0x210) = param_2;
  return;
}



/* FUNCTION 11861 ; VA 0x007c9390 ; FUN_007c9390 */

/* WARNING: Removing unreachable block (ram,0x007c961f) */
/* WARNING: Removing unreachable block (ram,0x007c9637) */
/* WARNING: Removing unreachable block (ram,0x007c962c) */
/* WARNING: Removing unreachable block (ram,0x007c9641) */

void __fastcall FUN_007c9390(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3600;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01d65107 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01d65107,"SceneUpdater unbind - start",0);
  }
  iVar3 = *(int *)(param_1 + 0xc);
  iVar5 = *(int *)(param_1 + 8);
  uVar6 = 0;
  if (iVar3 - iVar5 >> 2 != 0) {
    do {
      FUN_01679490();
      iVar3 = *(int *)(param_1 + 0xc);
      uVar6 = uVar6 + 1;
      iVar5 = *(int *)(param_1 + 8);
    } while (uVar6 < (uint)(iVar3 - iVar5 >> 2));
  }
  FUN_00638410(iVar5,iVar3);
  *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)(param_1 + 8);
  if (DAT_01d65107 != '\0') {
    FUN_016774b0(DAT_01d65107,"SceneUpdater unbind - end",0);
  }
  piVar7 = (int *)**(int **)(param_1 + 0x1c8);
  if (piVar7 != *(int **)(param_1 + 0x1c8)) {
    do {
      if ((undefined4 *)piVar7[2] != (undefined4 *)0x0) {
        (*(code *)**(undefined4 **)piVar7[2])(1);
      }
      piVar7 = (int *)*piVar7;
    } while (piVar7 != (int *)*(int *)(param_1 + 0x1c8));
  }
  piVar7 = (int *)**(int **)(param_1 + 0x194);
  if (piVar7 != *(int **)(param_1 + 0x194)) {
    do {
      if ((undefined4 *)piVar7[3] != (undefined4 *)0x0) {
        (*(code *)**(undefined4 **)piVar7[3])(1);
      }
      piVar7 = (int *)*piVar7;
    } while (piVar7 != (int *)*(int *)(param_1 + 0x194));
  }
  FUN_00621160(0);
  FUN_007c7590(0);
  puVar2 = (undefined4 *)FUN_007c4070(0,0);
  uStack_8 = 0;
  FUN_00621160(0);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_007c4170(param_1 + 0x104);
  for (puVar1 = (undefined4 *)*puVar2; puVar1 != puVar2; puVar1 = (undefined4 *)*puVar1) {
    if ((undefined4 *)puVar1[2] != (undefined4 *)0x0) {
      (*(code *)**(undefined4 **)puVar1[2])(1);
    }
  }
  FUN_007c5880();
  piVar7 = *(int **)(param_1 + 0x194);
  uStack_8 = 2;
  piVar4 = (int *)*piVar7;
  *piVar7 = (int)piVar7;
  *(int *)(*(int *)(param_1 + 0x194) + 4) = *(int *)(param_1 + 0x194);
  *(undefined4 *)(param_1 + 0x198) = 0;
  if (piVar4 != *(int **)(param_1 + 0x194)) {
    do {
      piVar7 = (int *)*piVar4;
      FUN_01674ea0(piVar4,0x10);
      piVar4 = piVar7;
    } while (piVar7 != (int *)*(int *)(param_1 + 0x194));
  }
  FUN_005cb500(8);
  *(undefined4 *)(param_1 + 0x1b0) = 0;
  FUN_007c5880();
  iVar3 = *(int *)(param_1 + 0x1b4);
  *(undefined4 *)(param_1 + 0x1b4) = 0;
  if (iVar3 != 0) {
    FUN_007c3ff0(iVar3);
  }
  iVar3 = *(int *)(param_1 + 0x1b8);
  *(undefined4 *)(param_1 + 0x1b8) = 0;
  if (iVar3 != 0) {
    FUN_007c3ff0(iVar3);
  }
  if (*(int *)(param_1 + 600) != 0) {
    FUN_007c62b0(*(int *)(param_1 + 0x264) + *(int *)(param_1 + 0x254) * 4,0);
    puVar2 = *(undefined4 **)(param_1 + 0x264);
    puVar1 = puVar2 + *(int *)(param_1 + 0x254);
    for (; puVar2 != puVar1; puVar2 = puVar2 + 1) {
      *puVar2 = 0;
    }
  }
  if (*(char *)(param_1 + 0x1c0) != '\0') {
    iVar3 = *(int *)(param_1 + 0x1bc);
    *(undefined4 *)(param_1 + 0x1bc) = 0;
    if (iVar3 != 0) {
      FUN_007c3ff0(iVar3);
    }
    *(undefined4 *)(param_1 + 0x26c) = *(undefined4 *)(param_1 + 0x268);
  }
  uStack_8 = 3;
  FUN_007c20b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11862 ; VA 0x007c9670 ; FUN_007c9670 */

void __thiscall FUN_007c9670(int param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  double *pdVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  int *piVar11;
  undefined4 *puVar12;
  int iVar13;
  undefined8 uVar14;
  undefined auStack_40 [8];
  double dStack_38;
  undefined auStack_30 [4];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3624;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2f78) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb2f78), DAT_01eb2f78 == -1)) {
    uStack_8 = 0;
    uVar14 = FUN_0152dab0("Render","updateInvalidParts",0xffffffff);
    DAT_01eb2f74 = (undefined4)((ulonglong)uVar14 >> 0x20);
    DAT_01eb2f70 = (undefined4)uVar14;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb2f78);
  }
  uStack_2c = DAT_01eb2f70;
  uStack_28 = DAT_01eb2f74;
  uVar14 = FUN_0152d930(DAT_01eb2f70,DAT_01eb2f74);
  piVar11 = (int *)(param_1 + 0x244);
  iStack_24 = param_1 + 0x74;
  *(undefined4 *)(param_1 + 0x248) = *(undefined4 *)(param_1 + 0x244);
  puStack_18 = (undefined4 *)(param_1 + 0x78);
  uStack_8 = 1;
  FUN_007bef60(*piVar11,**(undefined4 **)(param_1 + 0x78),*(undefined4 **)(param_1 + 0x78),param_2);
  FUN_007c5880();
  FUN_016827e0(&dStack_38);
  uStack_20 = 0;
  if (*(int *)(param_1 + 0x248) - *piVar11 >> 2 != 0) {
    do {
      iVar13 = iStack_14;
      uVar5 = uStack_20;
      if (((0x3f < uStack_20) && ((char)param_2 == '\0')) &&
         (pdVar6 = (double *)FUN_016827e0(auStack_40),
         (double)DAT_01d61d64 < (*pdVar6 - dStack_38) * DAT_018c0d70)) {
        if (DAT_01d6517a != '\0') {
          FUN_016774b0(DAT_01d6517a,"Invalidated entities: %u",uVar5);
        }
        iVar2 = *(int *)(iVar13 + 0x248);
        puVar12 = puStack_18;
        for (iVar13 = *piVar11 + uVar5 * 4; iVar13 != iVar2; iVar13 = iVar13 + 4) {
          iVar3 = *(int *)*puVar12;
          puVar9 = *(undefined4 **)(iVar3 + 4);
          uVar8 = FUN_007be5e0(iVar3,puVar9,iVar13);
          puVar12 = puStack_18;
          if (*(int *)(iStack_24 + 8) == -2) {
                    /* WARNING: Subroutine does not return */
            FUN_016ddcd9("list<T> too long");
          }
          *(int *)(iStack_24 + 8) = *(int *)(iStack_24 + 8) + 1;
          *(undefined4 *)(iVar3 + 4) = uVar8;
          *puVar9 = uVar8;
          FUN_007be9f0(auStack_40,*(int *)*puStack_18 + 8,*(int *)*puStack_18);
        }
        break;
      }
      piVar11 = *(int **)(*piVar11 + uVar5 * 4);
      puVar12 = *(undefined4 **)(iStack_14 + 0x13c);
      puVar9 = (undefined4 *)puVar12[1];
      cVar1 = *(char *)((int)puVar9 + 0xd);
      puVar4 = puVar12;
      puVar10 = puVar9;
      while (cVar1 == '\0') {
        if ((int *)puVar10[4] < piVar11) {
          puVar7 = (undefined4 *)puVar10[2];
          puVar10 = puVar4;
        }
        else {
          if ((*(char *)((int)puVar12 + 0xd) != '\0') && (piVar11 < (int *)puVar10[4])) {
            puVar12 = puVar10;
          }
          puVar7 = (undefined4 *)*puVar10;
        }
        puVar4 = puVar10;
        puVar10 = puVar7;
        cVar1 = *(char *)((int)puVar7 + 0xd);
      }
      if (*(char *)((int)puVar12 + 0xd) == '\0') {
        puVar9 = (undefined4 *)*puVar12;
      }
      cVar1 = *(char *)((int)puVar9 + 0xd);
      while (puStack_1c = puVar4, cVar1 == '\0') {
        if (piVar11 < (int *)puVar9[4]) {
          puVar10 = (undefined4 *)*puVar9;
          puVar12 = puVar9;
        }
        else {
          puVar10 = (undefined4 *)puVar9[2];
        }
        puVar9 = puVar10;
        cVar1 = *(char *)((int)puVar10 + 0xd);
      }
      while (puStack_1c != puVar12) {
        FUN_00551320();
      }
      FUN_007c6cb0(auStack_30,puVar4,puVar12);
      if (DAT_01ee4200 != '\0') {
        FUN_016774b0(DAT_01ee4200,"Updating entity on part cluster: %p",piVar11);
      }
      (**(code **)(*piVar11 + 0xc))(0);
      piVar11 = (int *)(iStack_14 + 0x244);
      uStack_20 = uStack_20 + 1;
    } while (uStack_20 < (uint)(*(int *)(iStack_14 + 0x248) - *piVar11 >> 2));
  }
  uStack_8 = 2;
  FUN_0152dda0(uStack_2c,uStack_28,uVar14);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11863 ; VA 0x007c9970 ; FUN_007c9970 */

void __fastcall FUN_007c9970(int param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  char *pcVar7;
  int iVar8;
  uint uVar9;
  undefined4 *puVar10;
  uint uVar11;
  undefined8 uVar12;
  undefined8 uVar13;
  undefined8 uVar14;
  undefined8 uVar15;
  int iStack_28;
  int iStack_20;
  int iStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3664;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  if ((*(int *)(iVar2 + 0x34) < DAT_01eb2fa8) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb2fa8), cVar4 = DAT_01d7ad48,
     DAT_01eb2fa8 == -1)) {
    uStack_8 = 0;
    uVar12 = FUN_0152dab0("Render","updateDynamicParts",0xffffffff);
    if ((cVar4 != '\0') && (DAT_01d7ad40 != '\0')) {
      FUN_01532a30(uVar12);
    }
    uStack_8 = 0xffffffff;
    DAT_01eb2fa0 = (int)uVar12;
    DAT_01eb2fa4 = (int)((ulonglong)uVar12 >> 0x20);
    FUN_016f37bf(&DAT_01eb2fa8);
  }
  uVar6 = DAT_01eb2fa4;
  uVar5 = DAT_01eb2fa0;
  cVar4 = DAT_01d7ad48;
  uVar12 = FUN_01532c80(DAT_01eb2fa0,DAT_01eb2fa4);
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  iStack_1c = 0;
  iStack_28 = 0;
  do {
    if (iStack_28 == 2) {
      FUN_007c9d00();
    }
    else {
      iVar1 = param_1 + iStack_28 * 0xc;
      if (0 < *(int *)(iVar1 + 0x290)) {
        pcVar7 = "Unknown";
        switch(iStack_28) {
        case 0:
          pcVar7 = "Beams";
          break;
        case 1:
          pcVar7 = "Emitters";
          break;
        case 2:
          pcVar7 = "FastClusters";
          break;
        case 3:
          pcVar7 = "InstancedClusters";
          break;
        case 4:
          pcVar7 = "LightObjects";
          break;
        case 5:
          pcVar7 = "Trails";
        }
        uVar15 = FUN_0152dab0("Render",pcVar7,0xffffffff);
        uVar13 = FUN_0152d930(uVar15);
        puVar10 = *(undefined4 **)(iVar1 + 0x28c);
        uStack_8._0_1_ = 2;
        iStack_20 = 0;
        uVar9 = *(int *)(iVar1 + 0x290) * 4 + 3U >> 2;
        if (puVar10 + *(int *)(iVar1 + 0x290) < puVar10) {
          uVar9 = 0;
        }
        if (uVar9 != 0) {
          uVar11 = 0;
          do {
            piVar3 = (int *)*puVar10;
            (**(code **)(*piVar3 + 0x44))();
            iVar8 = (**(code **)(*piVar3 + 0x58))();
            puVar10 = puVar10 + 1;
            iStack_20 = iStack_20 + iVar8;
            uVar11 = uVar11 + 1;
          } while (uVar11 != uVar9);
        }
        iStack_1c = iStack_1c + iStack_20;
        if ((*(int *)(iVar2 + 0x34) < DAT_01eb2fb8) &&
           (FUN_016f3809(&DAT_01eb2fb8), DAT_01eb2fb8 == -1)) {
          uStack_8._0_1_ = 3;
          uVar14 = FUN_0152da50("Render");
          DAT_01eb2fb4 = (undefined4)((ulonglong)uVar14 >> 0x20);
          DAT_01eb2fb0 = (undefined4)uVar14;
          uStack_8._0_1_ = 2;
          FUN_016f37bf(&DAT_01eb2fb8);
        }
        FUN_0152d760(DAT_01eb2fb0,DAT_01eb2fb4,"Num:%u PartCount:%u",*(undefined4 *)(iVar1 + 0x290),
                     iStack_20);
        uStack_8._0_1_ = 4;
        FUN_0152dda0(uVar15,uVar13);
        uStack_8._0_1_ = 1;
      }
    }
    iStack_28 = iStack_28 + 1;
  } while (iStack_28 < 6);
  if ((*(int *)(iVar2 + 0x34) < DAT_01eb2fc8) && (FUN_016f3809(&DAT_01eb2fc8), DAT_01eb2fc8 == -1))
  {
    uStack_8._0_1_ = 5;
    uVar15 = FUN_0152da50("Render");
    DAT_01eb2fc4 = (undefined4)((ulonglong)uVar15 >> 0x20);
    DAT_01eb2fc0 = (undefined4)uVar15;
    uStack_8._0_1_ = 1;
    FUN_016f37bf(&DAT_01eb2fc8);
  }
  FUN_0152d760(DAT_01eb2fc0,DAT_01eb2fc4,"Total parts: %u",iStack_1c);
  uStack_8 = 6;
  FUN_0152dda0(uVar5,uVar6,uVar12);
  if ((cVar4 != '\0') && (DAT_01d7ad40 != '\0')) {
    FUN_01532d10(uVar5,uVar6,uVar12);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11864 ; VA 0x007c9d00 ; FUN_007c9d00 */

void __fastcall FUN_007c9d00(int param_1)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined8 uVar6;
  undefined4 in_stack_ffffff94;
  undefined4 in_stack_ffffff98;
  undefined4 uVar7;
  undefined4 uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b36b8;
  pvStack_10 = ExceptionList;
  if (0 < *(int *)(param_1 + 0x2a8)) {
    iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    if (DAT_01d61d7c < *(int *)(param_1 + 0x2a8)) {
      ExceptionList = &pvStack_10;
      if ((*(int *)(iVar1 + 0x34) < DAT_01eb2fd8) &&
         (ExceptionList = &pvStack_10, FUN_016f3809(), DAT_01eb2fd8 == -1)) {
        uStack_8 = 0;
        uVar6 = FUN_0152dab0();
        DAT_01eb2fd4 = (undefined4)((ulonglong)uVar6 >> 0x20);
        DAT_01eb2fd0 = (undefined4)uVar6;
        uStack_8 = 0xffffffff;
        FUN_016f37bf();
      }
      uVar8 = DAT_01eb2fd4;
      uVar7 = DAT_01eb2fd0;
      FUN_0152d930();
      uStack_8._1_3_ = 0;
      uStack_8._0_1_ = 1;
      FUN_01539550((uint *)(param_1 + 0x2a4),in_stack_ffffff94,in_stack_ffffff98,&DAT_01d61d9a);
      FUN_0153a600();
      if ((*(int *)(iVar1 + 0x34) < DAT_01eb2fe8) && (FUN_016f3809(), DAT_01eb2fe8 == -1)) {
        uStack_8._0_1_ = 3;
        uVar6 = FUN_0152da50();
        DAT_01eb2fe4 = (undefined4)((ulonglong)uVar6 >> 0x20);
        DAT_01eb2fe0 = (undefined4)uVar6;
        uStack_8._0_1_ = 1;
        FUN_016f37bf();
      }
      FUN_0152d760();
      uStack_8 = 4;
    }
    else {
      ExceptionList = &pvStack_10;
      if ((*(int *)(iVar1 + 0x34) < DAT_01eb2ff8) &&
         (ExceptionList = &pvStack_10, FUN_016f3809(), DAT_01eb2ff8 == -1)) {
        uStack_8 = 5;
        uVar6 = FUN_0152dab0();
        DAT_01eb2ff4 = (undefined4)((ulonglong)uVar6 >> 0x20);
        DAT_01eb2ff0 = (undefined4)uVar6;
        uStack_8 = 0xffffffff;
        FUN_016f37bf();
      }
      uVar8 = DAT_01eb2ff4;
      uVar7 = DAT_01eb2ff0;
      FUN_0152d930();
      puVar5 = *(undefined4 **)(param_1 + 0x2a4);
      uVar4 = 0;
      uStack_8 = 6;
      uVar3 = *(int *)(param_1 + 0x2a8) * 4 + 3U >> 2;
      if (puVar5 + *(int *)(param_1 + 0x2a8) < puVar5) {
        uVar3 = 0;
      }
      if (uVar3 != 0) {
        do {
          piVar2 = (int *)*puVar5;
          (**(code **)(*piVar2 + 0x50))();
          (**(code **)(*piVar2 + 0x54))();
          (**(code **)(*piVar2 + 0x58))();
          puVar5 = puVar5 + 1;
          uVar4 = uVar4 + 1;
        } while (uVar4 != uVar3);
      }
      if ((*(int *)(iVar1 + 0x34) < DAT_01eb3008) && (FUN_016f3809(), DAT_01eb3008 == -1)) {
        uStack_8._0_1_ = 7;
        uVar6 = FUN_0152da50();
        DAT_01eb3004 = (undefined4)((ulonglong)uVar6 >> 0x20);
        DAT_01eb3000 = (undefined4)uVar6;
        uStack_8 = CONCAT31(uStack_8._1_3_,6);
        FUN_016f37bf();
      }
      FUN_0152d760();
      uStack_8 = 8;
    }
    FUN_0152dda0(uVar7,uVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11865 ; VA 0x007ca080 ; FUN_007ca080 */

void __fastcall FUN_007ca080(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined uVar4;
  char cVar5;
  undefined4 uVar6;
  int **ppiVar7;
  uint uVar8;
  uint uVar9;
  int *piVar10;
  int iVar11;
  undefined4 *puVar12;
  int iVar13;
  undefined2 uVar14;
  uint *puVar15;
  int *piVar16;
  int *piVar17;
  uint uVar18;
  int iVar19;
  int *piVar20;
  float fVar21;
  float fVar22;
  float fVar23;
  undefined8 uVar24;
  undefined8 uVar25;
  uint uStack_7c;
  uint uStack_78;
  int iStack_74;
  undefined4 *puStack_70;
  undefined4 uStack_6c;
  int iStack_68;
  int *piStack_60;
  int *piStack_5c;
  undefined4 uStack_58;
  int *piStack_54;
  uint uStack_50;
  char cStack_49;
  int iStack_48;
  int *piStack_44;
  int *piStack_40;
  int iStack_3c;
  int iStack_38;
  undefined4 uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b37e5;
  pvStack_10 = ExceptionList;
  iStack_38 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  iStack_48 = param_1;
  if ((*(int *)(iStack_38 + 0x34) < DAT_01eb3078) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb3078), cVar5 = DAT_01d7ad48,
     DAT_01eb3078 == -1)) {
    uStack_8 = 0;
    uVar24 = FUN_0152dab0("Render","updateInstancedClusters",0xffffffff);
    if ((cVar5 != '\0') && (DAT_01d7ad40 != '\0')) {
      FUN_01532a30(uVar24);
    }
    uStack_8 = 0xffffffff;
    DAT_01eb3070 = (int)uVar24;
    DAT_01eb3074 = (int)((ulonglong)uVar24 >> 0x20);
    FUN_016f37bf(&DAT_01eb3078);
  }
  uVar3 = DAT_01eb3074;
  uVar2 = DAT_01eb3070;
  cStack_49 = DAT_01d7ad48;
  uVar24 = FUN_01532c80(DAT_01eb3070,DAT_01eb3074);
  uStack_8 = 1;
  uVar6 = FUN_01675290(DAT_01eb2f54);
  uStack_6c = 0;
  piStack_44 = (int *)0x0;
  iStack_3c = 0;
  ppiVar7 = (int **)(iStack_48 + 0x22c);
  uStack_8._0_1_ = 3;
  piStack_14 = (int *)0x0;
  if (&piStack_44 != ppiVar7) {
    piStack_44 = *ppiVar7;
    *ppiVar7 = (int *)0x0;
    piStack_14 = *(int **)(iStack_48 + 0x230);
    *(undefined4 *)(iStack_48 + 0x230) = 0;
    iStack_3c = *(int *)(iStack_48 + 0x234);
    *(undefined4 *)(iStack_48 + 0x234) = 0;
  }
  piVar20 = piStack_14;
  piVar10 = piStack_44;
  piStack_40 = piStack_14;
  uStack_34 = uVar6;
  if ((*(int *)(iStack_38 + 0x34) < DAT_01eb3088) &&
     (FUN_016f3809(&DAT_01eb3088), DAT_01eb3088 == -1)) {
    uStack_8._0_1_ = 4;
    uVar25 = FUN_0152da50("Render");
    DAT_01eb3084 = (undefined4)((ulonglong)uVar25 >> 0x20);
    DAT_01eb3080 = (undefined4)uVar25;
    uStack_8._0_1_ = 3;
    FUN_016f37bf(&DAT_01eb3088);
  }
  piStack_18 = (int *)((int)piVar20 - (int)piVar10);
  FUN_0152d760(DAT_01eb3080,DAT_01eb3084,"clusters: %u",(int)piStack_18 >> 2);
  if ((*(int *)(iStack_38 + 0x34) < DAT_01eb3098) &&
     (FUN_016f3809(&DAT_01eb3098), DAT_01eb3098 == -1)) {
    uStack_8._0_1_ = 5;
    uVar25 = FUN_0152dab0("Render","update0_parts",0xffffffff);
    DAT_01eb3094 = (undefined4)((ulonglong)uVar25 >> 0x20);
    DAT_01eb3090 = (undefined4)uVar25;
    uStack_8._0_1_ = 3;
    FUN_016f37bf(&DAT_01eb3098);
  }
  piStack_1c = (int *)DAT_01eb3090;
  uStack_2c = DAT_01eb3090;
  uStack_30 = DAT_01eb3094;
  uStack_28 = DAT_01eb3094;
  uStack_24 = FUN_0152d930(DAT_01eb3090,DAT_01eb3094);
  uStack_8._0_1_ = 6;
  uVar8 = (int)piStack_18 + 3U >> 2;
  uVar18 = 0;
  if (piStack_14 < piVar10) {
    uVar8 = 0;
  }
  piStack_18 = (int *)uVar8;
  if (uVar8 != 0) {
    do {
      FUN_007b6300(&uStack_6c);
      uVar18 = uVar18 + 1;
      uVar6 = uStack_34;
    } while (uVar18 != uVar8);
  }
  uStack_8._0_1_ = 7;
  FUN_0152dda0(piStack_1c,uStack_30,uStack_24);
  uStack_8._0_1_ = 3;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (*(int *)(iStack_38 + 0x34) < DAT_01eb30a8) {
    uStack_8._0_1_ = uVar4;
    FUN_016f3809(&DAT_01eb30a8);
    if (DAT_01eb30a8 == -1) {
      uStack_8._0_1_ = 8;
      uVar25 = FUN_0152dab0("Render","update1_invalidated",0xffffffff);
      DAT_01eb30a4 = (undefined4)((ulonglong)uVar25 >> 0x20);
      DAT_01eb30a0 = (undefined4)uVar25;
      uStack_8._0_1_ = 3;
      FUN_016f37bf(&DAT_01eb30a8);
    }
  }
  piStack_1c = (int *)DAT_01eb30a0;
  uStack_2c = DAT_01eb30a0;
  piStack_14 = (int *)DAT_01eb30a4;
  uStack_28 = DAT_01eb30a4;
  uVar25 = FUN_0152d930(DAT_01eb30a0,DAT_01eb30a4);
  uVar18 = 0;
  uStack_8._0_1_ = 9;
  uVar8 = (uint)((int)piStack_40 + (3 - (int)piStack_44)) >> 2;
  if (piStack_40 < piStack_44) {
    uVar8 = 0;
  }
  uStack_30 = uVar8;
  uStack_24 = uVar25;
  if (uVar8 != 0) {
    do {
      uStack_24 = uVar25;
      FUN_007b6340();
      uVar18 = uVar18 + 1;
      uVar6 = uStack_34;
      uVar25 = uStack_24;
    } while (uVar18 != uVar8);
  }
  uStack_8._0_1_ = 10;
  FUN_0152dda0(piStack_1c,piStack_14,uStack_24);
  uStack_8._0_1_ = 3;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (*(int *)(iStack_38 + 0x34) < DAT_01eb30b8) {
    uStack_8._0_1_ = uVar4;
    FUN_016f3809(&DAT_01eb30b8);
    if (DAT_01eb30b8 == -1) {
      uStack_8._0_1_ = 0xb;
      uVar25 = FUN_0152dab0("Render","update2_transferred",0xffffffff);
      DAT_01eb30b4 = (undefined4)((ulonglong)uVar25 >> 0x20);
      DAT_01eb30b0 = (undefined4)uVar25;
      uStack_8._0_1_ = 3;
      FUN_016f37bf(&DAT_01eb30b8);
    }
  }
  piStack_1c = (int *)DAT_01eb30b0;
  uStack_2c = DAT_01eb30b0;
  piStack_14 = (int *)DAT_01eb30b4;
  uStack_28 = DAT_01eb30b4;
  uVar25 = FUN_0152d930(DAT_01eb30b0,DAT_01eb30b4);
  uVar18 = 0;
  uStack_8._0_1_ = 0xc;
  uStack_24 = uVar25;
  if (uVar8 != 0) {
    do {
      uStack_24 = uVar25;
      FUN_007b6380();
      uVar18 = uVar18 + 1;
      uVar6 = uStack_34;
      uVar25 = uStack_24;
    } while (uVar18 != uVar8);
  }
  uStack_8._0_1_ = 0xd;
  FUN_0152dda0(piStack_1c,piStack_14,uStack_24);
  uStack_8._0_1_ = 3;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (*(int *)(iStack_38 + 0x34) < DAT_01eb30c8) {
    uStack_8._0_1_ = uVar4;
    FUN_016f3809(&DAT_01eb30c8);
    if (DAT_01eb30c8 == -1) {
      uStack_8._0_1_ = 0xe;
      uVar25 = FUN_0152dab0("Render","update3_removed",0xffffffff);
      DAT_01eb30c4 = (undefined4)((ulonglong)uVar25 >> 0x20);
      DAT_01eb30c0 = (undefined4)uVar25;
      uStack_8._0_1_ = 3;
      FUN_016f37bf(&DAT_01eb30c8);
    }
  }
  piStack_1c = (int *)DAT_01eb30c0;
  uStack_2c = DAT_01eb30c0;
  piStack_14 = (int *)DAT_01eb30c4;
  uStack_28 = DAT_01eb30c4;
  uVar25 = FUN_0152d930(DAT_01eb30c0,DAT_01eb30c4);
  uVar18 = 0;
  uStack_8._0_1_ = 0xf;
  uStack_24 = uVar25;
  if (uVar8 != 0) {
    do {
      uStack_24 = uVar25;
      FUN_007b6530();
      uVar18 = uVar18 + 1;
      uVar6 = uStack_34;
      uVar25 = uStack_24;
    } while (uVar18 != uVar8);
  }
  uStack_8._0_1_ = 0x10;
  FUN_0152dda0(piStack_1c,piStack_14,uStack_24);
  uStack_8._0_1_ = 3;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (*(int *)(iStack_38 + 0x34) < DAT_01eb30d8) {
    uStack_8._0_1_ = uVar4;
    FUN_016f3809(&DAT_01eb30d8);
    if (DAT_01eb30d8 == -1) {
      uStack_8._0_1_ = 0x11;
      uVar25 = FUN_0152dab0("Render","update4_added",0xffffffff);
      DAT_01eb30d4 = (undefined4)((ulonglong)uVar25 >> 0x20);
      DAT_01eb30d0 = (undefined4)uVar25;
      uStack_8._0_1_ = 3;
      FUN_016f37bf(&DAT_01eb30d8);
    }
  }
  piStack_1c = (int *)DAT_01eb30d0;
  uStack_2c = DAT_01eb30d0;
  piStack_14 = (int *)DAT_01eb30d4;
  uStack_28 = DAT_01eb30d4;
  uVar25 = FUN_0152d930(DAT_01eb30d0,DAT_01eb30d4);
  uVar18 = 0;
  uStack_8._0_1_ = 0x12;
  uStack_24 = uVar25;
  if (uVar8 != 0) {
    do {
      uStack_24 = uVar25;
      FUN_007b6720();
      uVar18 = uVar18 + 1;
      uVar6 = uStack_34;
      uVar25 = uStack_24;
    } while (uVar18 != uVar8);
  }
  uStack_8._0_1_ = 0x13;
  FUN_0152dda0(piStack_1c,piStack_14,uStack_24);
  uStack_8._0_1_ = 3;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (*(int *)(iStack_38 + 0x34) < DAT_01eb30e8) {
    uStack_8._0_1_ = uVar4;
    FUN_016f3809(&DAT_01eb30e8);
    if (DAT_01eb30e8 == -1) {
      uStack_8._0_1_ = 0x14;
      uVar25 = FUN_0152dab0("Render","update5_entities",0xffffffff);
      DAT_01eb30e4 = (undefined4)((ulonglong)uVar25 >> 0x20);
      DAT_01eb30e0 = (undefined4)uVar25;
      uStack_8._0_1_ = 3;
      FUN_016f37bf(&DAT_01eb30e8);
    }
  }
  piStack_1c = (int *)DAT_01eb30e0;
  uStack_2c = DAT_01eb30e0;
  piStack_14 = (int *)DAT_01eb30e4;
  uStack_28 = DAT_01eb30e4;
  uVar25 = FUN_0152d930(DAT_01eb30e0,DAT_01eb30e4);
  piVar10 = piStack_40;
  iVar19 = iStack_48;
  uStack_8._0_1_ = 0x15;
  uStack_24 = uVar25;
  if (DAT_01d60fc0 == '\0') {
    uVar18 = 0;
    if (uVar8 != 0) {
      do {
        uStack_24 = uVar25;
        FUN_007b68c0();
        uVar18 = uVar18 + 1;
        uVar6 = uStack_34;
        uVar25 = uStack_24;
      } while (uVar18 != uVar8);
    }
  }
  else {
    *(undefined4 *)(iStack_48 + 0x2e0) = *(undefined4 *)(iStack_48 + 0x2dc);
    for (piVar20 = piStack_44; piVar20 != piVar10; piVar20 = piVar20 + 1) {
      cVar5 = FUN_007b68c0();
      if (cVar5 != '\0') {
        piVar17 = *(int **)(iVar19 + 0x2e0);
        if (*(int **)(iVar19 + 0x2e4) == piVar17) {
          FUN_006030d0(piVar17,piVar20);
        }
        else {
          *piVar17 = *piVar20;
          *(int *)(iVar19 + 0x2e0) = *(int *)(iVar19 + 0x2e0) + 4;
        }
      }
      uVar6 = uStack_34;
      uVar8 = uStack_30;
    }
  }
  uStack_8._0_1_ = 0x16;
  FUN_0152dda0(piStack_1c,piStack_14,uStack_24);
  uStack_8._0_1_ = 3;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (*(int *)(iStack_38 + 0x34) < DAT_01eb30f8) {
    uStack_8._0_1_ = uVar4;
    FUN_016f3809(&DAT_01eb30f8);
    if (DAT_01eb30f8 == -1) {
      uStack_8._0_1_ = 0x17;
      uVar25 = FUN_0152dab0("Render","update5a_sync",0xffffffff);
      DAT_01eb30f4 = (undefined4)((ulonglong)uVar25 >> 0x20);
      DAT_01eb30f0 = (undefined4)uVar25;
      uStack_8._0_1_ = 3;
      FUN_016f37bf(&DAT_01eb30f8);
    }
  }
  piStack_1c = (int *)DAT_01eb30f0;
  uStack_2c = DAT_01eb30f0;
  piStack_14 = (int *)DAT_01eb30f4;
  uStack_28 = DAT_01eb30f4;
  uVar25 = FUN_0152d930(DAT_01eb30f0,DAT_01eb30f4);
  uStack_8._0_1_ = 0x18;
  uStack_24 = uVar25;
  if ((DAT_01d60fc0 == '\0') && (uVar18 = 0, uVar8 != 0)) {
    do {
      uStack_24 = uVar25;
      FUN_007b6ae0();
      uVar18 = uVar18 + 1;
      uVar6 = uStack_34;
      uVar25 = uStack_24;
    } while (uVar18 != uVar8);
  }
  uStack_8._0_1_ = 0x19;
  FUN_0152dda0(piStack_1c,piStack_14,uStack_24);
  uStack_7c = 0;
  iStack_74 = 0;
  puVar15 = (uint *)(iStack_48 + 0x220);
  uStack_8._0_1_ = 0x1a;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x1a;
  piStack_14 = (int *)0x0;
  if (&uStack_7c != puVar15) {
    uStack_7c = *puVar15;
    *puVar15 = 0;
    piStack_14 = *(int **)(iStack_48 + 0x224);
    *(undefined4 *)(iStack_48 + 0x224) = 0;
    iStack_74 = *(int *)(iStack_48 + 0x228);
    *(undefined4 *)(iStack_48 + 0x228) = 0;
  }
  uVar18 = uStack_7c;
  uStack_78 = (uint)piStack_14;
  if (*(int *)(iStack_38 + 0x34) < DAT_01eb3108) {
    uStack_8._0_1_ = uVar4;
    FUN_016f3809(&DAT_01eb3108);
    if (DAT_01eb3108 == -1) {
      uStack_8._0_1_ = 0x1b;
      uVar25 = FUN_0152dab0("Render","update5a_sync extra",0xffffffff);
      DAT_01eb3104 = (uint)((ulonglong)uVar25 >> 0x20);
      DAT_01eb3100 = (uint)uVar25;
      uStack_8._0_1_ = 0x1a;
      FUN_016f37bf(&DAT_01eb3108);
    }
  }
  uStack_50 = DAT_01eb3100;
  uStack_2c = DAT_01eb3100;
  piStack_1c = (int *)DAT_01eb3104;
  uStack_28 = DAT_01eb3104;
  uVar25 = FUN_0152d930(DAT_01eb3100,DAT_01eb3104);
  uStack_8._0_1_ = 0x1c;
  uVar9 = ((int)piStack_14 - uVar18) + 3 >> 2;
  if (piStack_14 < uVar18) {
    uVar9 = 0;
  }
  piStack_18 = (int *)uVar9;
  uStack_24 = uVar25;
  if (uVar9 != 0) {
    uVar18 = 0;
    do {
      FUN_007b6ae0();
      uVar18 = uVar18 + 1;
      uVar6 = uStack_34;
      uVar8 = uStack_30;
    } while (uVar18 != uVar9);
  }
  uStack_8._0_1_ = 0x1d;
  FUN_0152dda0(uStack_50,piStack_1c,uStack_24);
  uStack_8._0_1_ = 3;
  if (uStack_7c != 0) {
    uVar18 = ((int)(iStack_74 - uStack_7c) >> 2) * 4;
    uVar9 = uStack_7c;
    if (0xfff < uVar18) {
      uVar9 = *(uint *)(uStack_7c - 4);
      uVar18 = uVar18 + 0x23;
      if (0x1f < (uStack_7c - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar18);
  }
  piVar10 = piStack_40;
  iVar19 = iStack_48;
  if (DAT_01d60fc8 == '\0') {
    if (*(int *)(iStack_38 + 0x34) < DAT_01eb3118) {
      FUN_016f3809(&DAT_01eb3118);
      if (DAT_01eb3118 == -1) {
        uStack_8._0_1_ = 0x1e;
        uVar25 = FUN_0152dab0("Render","update6_bbox",0xffffffff);
        DAT_01eb3114 = (uint)((ulonglong)uVar25 >> 0x20);
        DAT_01eb3110 = (uint)uVar25;
        uStack_8._0_1_ = 3;
        FUN_016f37bf(&DAT_01eb3118);
      }
    }
    piStack_14 = (int *)DAT_01eb3110;
    uStack_2c = DAT_01eb3110;
    piStack_18 = (int *)DAT_01eb3114;
    uStack_28 = DAT_01eb3114;
    uVar25 = FUN_0152d930(DAT_01eb3110,DAT_01eb3114);
    uVar18 = 0;
    uStack_8._0_1_ = 0x1f;
    uStack_24 = uVar25;
    if (uVar8 != 0) {
      do {
        uStack_24 = uVar25;
        FUN_007b6b30();
        uVar18 = uVar18 + 1;
        uVar6 = uStack_34;
        uVar25 = uStack_24;
      } while (uVar18 != uVar8);
    }
    uStack_8._0_1_ = 0x20;
    FUN_0152dda0(piStack_14,piStack_18,uStack_24);
    uStack_8._0_1_ = 3;
  }
  else {
    *(undefined4 *)(iStack_48 + 0x2ec) = *(undefined4 *)(iStack_48 + 0x2e8);
    for (piVar20 = piStack_44; piVar20 != piVar10; piVar20 = piVar20 + 1) {
      cVar5 = FUN_007b6e30();
      if (cVar5 != '\0') {
        piVar17 = *(int **)(iVar19 + 0x2ec);
        if (*(int **)(iVar19 + 0x2f0) == piVar17) {
          FUN_006030d0(piVar17,piVar20);
        }
        else {
          *piVar17 = *piVar20;
          *(int *)(iVar19 + 0x2ec) = *(int *)(iVar19 + 0x2ec) + 4;
        }
      }
      uVar6 = uStack_34;
    }
  }
  ppiVar7 = (int **)(iStack_48 + 0x238);
  piStack_40 = piStack_44;
  if (&piStack_44 != ppiVar7) {
    piVar10 = *ppiVar7;
    *ppiVar7 = piStack_44;
    piStack_40 = *(int **)(iStack_48 + 0x23c);
    *(int **)(iStack_48 + 0x23c) = piStack_44;
    iVar19 = *(int *)(iStack_48 + 0x240);
    *(int *)(iStack_48 + 0x240) = iStack_3c;
    piStack_44 = piVar10;
    iStack_3c = iVar19;
  }
  uStack_30 = 0;
  piVar10 = (int *)((uint)((int)piStack_40 + (3 - (int)piStack_44)) >> 2);
  if (piStack_40 < piStack_44) {
    piVar10 = (int *)0x0;
  }
  piStack_1c = piStack_44;
  piStack_14 = piVar10;
  if (piVar10 != (int *)0x0) {
    do {
      puStack_70 = (undefined4 *)*piStack_1c;
      iVar19 = *(int *)(iStack_48 + 0x1b8);
      uStack_24._4_4_ = iVar19;
      if (*(int *)(iVar19 + 8) != 0) {
        uVar8 = (int)*(short *)(puStack_70 + 0x24) + 0x9e3779b9;
        uVar8 = uVar8 ^ (uVar8 >> 2) +
                        uVar8 * 0x40 + *(short *)((int)puStack_70 + 0x92) + -0x61c88647;
        uStack_50 = *(uint *)(iVar19 + 4);
        uVar8 = uVar8 ^ (uVar8 >> 2) + uVar8 * 0x40 + *(short *)(puStack_70 + 0x25) + -0x61c88647;
        piStack_54 = (int *)(uint)*(ushort *)((int)puStack_70 + 0x96);
        uVar8 = (int)piStack_54 + (uVar8 >> 2) + 0x9e3779b9 + uVar8 * 0x40 ^ uVar8;
        piStack_18 = (int *)(uVar8 % uStack_50);
        iStack_68 = (int)piStack_18 * 4;
        piVar20 = *(int **)(iStack_68 + *(int *)(iVar19 + 0x14));
        piVar10 = piStack_14;
        if ((piVar20 != (int *)0x0) && (piVar17 = (int *)*piVar20, (int *)*piVar20 != (int *)0x0)) {
LAB_007ca8b5:
          piVar16 = piVar17;
          if ((int *)((uint)piVar16[1] % uStack_50) == piStack_18) {
            if ((((piVar16[1] != uVar8) ||
                 (*(short *)(puStack_70 + 0x24) != *(short *)(piVar16 + 2))) ||
                (*(short *)((int)puStack_70 + 0x92) != *(short *)((int)piVar16 + 10))) ||
               ((*(short *)(puStack_70 + 0x25) != *(short *)(piVar16 + 3) ||
                (*(ushort *)((int)puStack_70 + 0x96) != *(ushort *)((int)piVar16 + 0xe)))))
            goto LAB_007ca8f3;
            piVar16 = (int *)*piVar16;
            piVar17 = (int *)*piVar20;
            piStack_54 = piVar16;
            do {
              *piVar20 = *piVar17;
              FUN_007c7190(piVar17);
              *(int *)(iVar19 + 8) = *(int *)(iVar19 + 8) + -1;
              piVar17 = (int *)*piVar20;
            } while (piVar17 != piVar16);
            piVar10 = piStack_14;
            if (piVar17 == (int *)0x0) {
LAB_007caa75:
              puVar12 = (undefined4 *)(*(int *)(iVar19 + 0x14) + iStack_68);
              if ((int *)*puVar12 == piVar20) {
                *puVar12 = 0;
              }
            }
            else {
              uVar8 = (uint)piVar17[1] % *(uint *)(iVar19 + 4);
              if (piStack_18 != (int *)uVar8) {
                *(int **)(*(int *)(iVar19 + 0x14) + uVar8 * 4) = piVar20;
                goto LAB_007caa75;
              }
            }
          }
        }
      }
LAB_007ca906:
      piVar20 = piStack_1c;
      if (puStack_70 != (undefined4 *)0x0) {
        (**(code **)*puStack_70)(1);
        piVar10 = piStack_14;
      }
      uStack_30 = uStack_30 + 1;
      piStack_1c = piVar20 + 1;
      uVar6 = uStack_34;
    } while ((int *)uStack_30 != piVar10);
  }
  piStack_40 = piStack_44;
  uStack_58 = 0;
  uStack_8._0_1_ = 0x21;
  piStack_18 = (int *)0x0;
  piStack_14 = (int *)0x0;
  ppiVar7 = (int **)(iStack_48 + 0x214);
  if (&piStack_60 != ppiVar7) {
    piStack_18 = *ppiVar7;
    *ppiVar7 = (int *)0x0;
    piStack_14 = *(int **)(iStack_48 + 0x218);
    *(undefined4 *)(iStack_48 + 0x218) = 0;
    uStack_58 = *(undefined4 *)(iStack_48 + 0x21c);
    *(undefined4 *)(iStack_48 + 0x21c) = 0;
  }
  iVar19 = iStack_48;
  piVar10 = piStack_18;
  piStack_60 = piStack_18;
  piStack_5c = piStack_14;
  if (piStack_18 != piStack_14) {
    do {
      iVar13 = *(int *)(iVar19 + 0x1b8);
      iVar1 = *(int *)(*piVar10 + 0xa8);
      iVar11 = FUN_00c157b0();
      iVar19 = iStack_48;
      fVar22 = *(float *)(iVar13 + 0x20) * *(float *)(iVar11 + 0x2c);
      iVar1 = *(int *)(iVar1 + 0x1ac);
      fVar23 = *(float *)(iVar13 + 0x18) * *(float *)(iVar11 + 0x24);
      fVar21 = *(float *)(iVar13 + 0x1c) * *(float *)(iVar11 + 0x28);
      if (fVar22 < 0.0) {
        fVar22 = fVar22 - DAT_018fee54;
      }
      if (fVar21 < 0.0) {
        fVar21 = fVar21 - DAT_018fee54;
      }
      if (fVar23 < 0.0) {
        fVar23 = fVar23 - DAT_018fee54;
      }
      iStack_68 = CONCAT22((short)(int)fVar21,(short)(int)fVar23);
      if (((*(float *)(iVar13 + 0x24) <= *(float *)(iVar1 + 4)) ||
          (*(float *)(iVar13 + 0x28) <= *(float *)(iVar1 + 8))) ||
         (*(float *)(iVar13 + 0x2c) <= *(float *)(iVar1 + 0xc))) {
        uVar14 = 1;
      }
      else {
        uVar14 = 0;
      }
      uStack_24._4_4_ = CONCAT22(uVar14,(short)(int)fVar22);
      uStack_24._0_4_ = iStack_68;
      iVar13 = FUN_007c3930(&uStack_24);
      if (*(int *)(iVar13 + 8) == 0) {
        puStack_70 = (undefined4 *)FUN_01674e20(0xec);
        uStack_8._0_1_ = 0x22;
        if (puStack_70 == (undefined4 *)0x0) {
          uVar6 = 0;
        }
        else {
          uVar6 = FUN_007b1f30(*(undefined4 *)(iVar19 + 0x18c),*(undefined4 *)(iVar19 + 0x1b8),
                               &uStack_24);
        }
        uStack_8._0_1_ = 0x21;
        *(undefined4 *)(iVar13 + 8) = uVar6;
      }
      FUN_007b5010(piVar10);
      piVar10 = piVar10 + 2;
      uVar6 = uStack_34;
    } while (piVar10 != piStack_14);
  }
  piVar10 = piStack_60;
  FUN_005596d0(piStack_60,piStack_5c,&piStack_60);
  piStack_5c = piVar10;
  if (*(int *)(iStack_38 + 0x34) < DAT_01eb3128) {
    FUN_016f3809(&DAT_01eb3128);
    if (DAT_01eb3128 == -1) {
      uStack_8._0_1_ = 0x23;
      uVar25 = FUN_0152da50("Render");
      DAT_01eb3124 = (undefined4)((ulonglong)uVar25 >> 0x20);
      DAT_01eb3120 = (undefined4)uVar25;
      uStack_8._0_1_ = 0x21;
      FUN_016f37bf(&DAT_01eb3128);
    }
  }
  FUN_0152d760(DAT_01eb3120,DAT_01eb3124,"instances: %u",uStack_6c);
  FUN_00641040();
  uStack_8._0_1_ = 2;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (piStack_44 != (int *)0x0) {
    uVar8 = (iStack_3c - (int)piStack_44 >> 2) * 4;
    piVar10 = piStack_44;
    if (0xfff < uVar8) {
      piVar10 = (int *)piStack_44[-1];
      uVar8 = uVar8 + 0x23;
      if (0x1f < (uint)((int)piStack_44 + (-4 - (int)piVar10))) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar10,uVar8);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x24);
  FUN_01675290(uVar6);
  uStack_8 = 0x25;
  FUN_0152dda0(uVar2,uVar3,uVar24);
  if ((cStack_49 != '\0') && (DAT_01d7ad40 != '\0')) {
    FUN_01532d10(uVar2,uVar3,uVar24);
  }
  ExceptionList = pvStack_10;
  return;
LAB_007ca8f3:
  piVar17 = (int *)*piVar16;
  piVar20 = piVar16;
  if ((int *)*piVar16 == (int *)0x0) goto LAB_007ca906;
  goto LAB_007ca8b5;
}



/* FUNCTION 11866 ; VA 0x007cb000 ; FUN_007cb000 */

void __thiscall FUN_007cb000(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  undefined4 uVar4;
  double *pdVar5;
  int iVar6;
  uint uVar7;
  undefined8 uVar8;
  double dStack_30;
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int iStack_1c;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3804;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2f98) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb2f98), cVar3 = DAT_01d7ad48,
     DAT_01eb2f98 == -1)) {
    uStack_8 = 0;
    uVar8 = FUN_0152dab0("Render","updateInvalidatedFastClusters",0xffffffff);
    uStack_18 = (uint)((ulonglong)uVar8 >> 0x20);
    if ((cVar3 != '\0') && (DAT_01d7ad40 != '\0')) {
      FUN_01532a30(uVar8);
    }
    uStack_8 = 0xffffffff;
    DAT_01eb2f90 = (int)uVar8;
    DAT_01eb2f94 = uStack_18;
    FUN_016f37bf(&DAT_01eb2f98);
  }
  cStack_11 = DAT_01d7ad48;
  uStack_28 = DAT_01eb2f90;
  uStack_24 = DAT_01eb2f94;
  uVar8 = FUN_01532c80(DAT_01eb2f90,DAT_01eb2f94);
  uStack_8 = 1;
  *(undefined4 *)(*(int *)(param_1 + 0x1c) + 0x98) = 0;
  *(undefined4 *)(*(int *)(param_1 + 0x1c) + 0x9c) = 0;
  FUN_016827e0(&dStack_30);
  if ((DAT_01d6517a != '\0') && ((*(int *)(param_1 + 0xbc) != 0 || (*(int *)(param_1 + 0xa4) != 0)))
     ) {
    FUN_01677490(DAT_01d6517a,
                 "Invalidating Fast Clusters, PriorityInvalidatedClusters: %u, InvalidatedClusters: %u"
                 ,*(int *)(param_1 + 0xbc),*(undefined4 *)(param_1 + 0xa4),0);
  }
  if ((DAT_01d622b0 != '\0') && (*(int *)(param_1 + 0x1b0) != 0)) {
    uStack_18 = *(int *)(param_1 + 0x1b0) + 0x74;
    iVar6 = param_1 + 0x9d + (uint)*(byte *)(param_1 + 0x9c);
    FUN_00606ea0(&iStack_1c,(uStack_18 >> 3) + uStack_18,&uStack_18,-(uint)(iVar6 != 0) & iVar6 + 1U
                );
    if (iStack_1c != 0) {
      piVar2 = *(int **)(iStack_1c + 8);
      FUN_007c6e60(&iStack_1c,iStack_1c);
      if (piVar2 != (int *)0x0) {
        if (DAT_01d6517a != '\0') {
          FUN_016774b0(DAT_01d6517a,"Updating invalidated local cluster %p",piVar2);
        }
        piVar1 = (int *)(*(int *)(param_1 + 0x1c) + 0x98);
        *piVar1 = *piVar1 + 1;
        iVar6 = (**(code **)(*piVar2 + 0x58))();
        piVar1 = (int *)(*(int *)(param_1 + 0x1c) + 0x9c);
        *piVar1 = *piVar1 + iVar6;
        (**(code **)(*piVar2 + 0xc))(0);
      }
    }
  }
  iVar6 = *(int *)(param_1 + 0xbc);
  while (iVar6 != 0) {
    piVar2 = (int *)**(int **)(param_1 + 0xb8);
    piVar1 = (int *)piVar2[2];
    iVar6 = *(int *)(param_1 + 0xc0);
    uVar7 = *(uint *)(param_1 + 0xcc) &
            (((((uint)piVar1 & 0xff ^ 0x811c9dc5) * 0x1000193 ^ (uint)*(byte *)((int)piVar2 + 9)) *
              0x1000193 ^ (uint)*(byte *)((int)piVar2 + 10)) * 0x1000193 ^
            (uint)*(byte *)((int)piVar2 + 0xb)) * 0x1000193;
    if (*(int **)(iVar6 + 4 + uVar7 * 8) == piVar2) {
      if (*(int **)(iVar6 + uVar7 * 8) == piVar2) {
        *(undefined4 *)(iVar6 + uVar7 * 8) = *(undefined4 *)(param_1 + 0xb8);
        *(undefined4 *)(*(int *)(param_1 + 0xc0) + 4 + uVar7 * 8) = *(undefined4 *)(param_1 + 0xb8);
      }
      else {
        *(int *)(iVar6 + 4 + uVar7 * 8) = piVar2[1];
      }
    }
    else if (*(int **)(iVar6 + uVar7 * 8) == piVar2) {
      *(int *)(iVar6 + uVar7 * 8) = *piVar2;
    }
    *(int *)piVar2[1] = *piVar2;
    *(int *)(*piVar2 + 4) = piVar2[1];
    *(int *)(param_1 + 0xbc) = *(int *)(param_1 + 0xbc) + -1;
    uStack_8._1_3_ = (undefined3)((uint)uStack_8 >> 8);
    uStack_8._0_1_ = 2;
    FUN_007c7240(piVar2);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (DAT_01d6517a != '\0') {
      FUN_01677490(DAT_01d6517a,"Updating invalidated priority cluster %p (remaining: %u)",piVar1,
                   *(undefined4 *)(param_1 + 0xbc),0);
    }
    piVar2 = (int *)(*(int *)(param_1 + 0x1c) + 0x98);
    *piVar2 = *piVar2 + 1;
    iVar6 = (**(code **)(*piVar1 + 0x58))();
    piVar2 = (int *)(*(int *)(param_1 + 0x1c) + 0x9c);
    *piVar2 = *piVar2 + iVar6;
    (**(code **)(*piVar1 + 0xc))(0);
    iVar6 = *(int *)(param_1 + 0xbc);
  }
  cVar3 = (char)param_2;
  while ((cVar3 != '\0' ||
         (pdVar5 = (double *)FUN_016827e0(auStack_20),
         (*pdVar5 - dStack_30) * DAT_018c0d70 <= DAT_018cf100))) {
    if ((*(int *)(param_1 + 0x94) == 0) || (*(int *)(param_1 + 0x94) == param_1 + 0x94)) break;
    piVar1 = *(int **)(*(int *)(param_1 + 0x98) + 8);
    param_2 = piVar1;
    FUN_007c6fd0(&param_2);
    piVar2 = (int *)(*(int *)(param_1 + 0x1c) + 0x98);
    *piVar2 = *piVar2 + 1;
    iVar6 = (**(code **)(*piVar1 + 0x58))();
    piVar2 = (int *)(*(int *)(param_1 + 0x1c) + 0x9c);
    *piVar2 = *piVar2 + iVar6;
    (**(code **)(*piVar1 + 0xc))(0);
  }
  uVar7 = uStack_24;
  uVar4 = uStack_28;
  uStack_8 = 3;
  FUN_0152dda0(uStack_28,uStack_24,uVar8);
  if ((cStack_11 != '\0') && (DAT_01d7ad40 != '\0')) {
    FUN_01532d10(uVar4,uVar7,uVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11867 ; VA 0x007cb3f0 ; FUN_007cb3f0 */

void __fastcall FUN_007cb3f0(int param_1)

{
  int **ppiVar1;
  ushort uVar2;
  ushort uVar3;
  ushort uVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  undefined uVar8;
  undefined4 *puVar9;
  int *piVar10;
  int *piVar11;
  int *piVar12;
  int *piVar13;
  uint uVar14;
  undefined8 uVar15;
  int *piStack_4c;
  int *piStack_48;
  int iStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int iStack_34;
  int *piStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  int iStack_20;
  uint uStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3834;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_20 = param_1;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb3138) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb3138), DAT_01eb3138 == -1)) {
    uStack_8 = 0;
    uVar15 = FUN_0152dab0("Render","updateModelClusters",0xffffffff);
    DAT_01eb3134 = (undefined4)((ulonglong)uVar15 >> 0x20);
    DAT_01eb3130 = (undefined4)uVar15;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb3138);
  }
  uStack_40 = DAT_01eb3130;
  uStack_3c = DAT_01eb3134;
  uVar15 = FUN_0152d930(DAT_01eb3130,DAT_01eb3134);
  uStack_8 = 1;
  uStack_38 = FUN_01675290(DAT_01eb2f54);
  iStack_44 = 0;
  ppiVar1 = (int **)(param_1 + 0x268);
  uStack_8._0_1_ = 3;
  piStack_18 = (int *)0x0;
  piStack_14 = (int *)0x0;
  if (&piStack_4c != ppiVar1) {
    piStack_18 = *ppiVar1;
    *ppiVar1 = (int *)0x0;
    piStack_14 = *(int **)(param_1 + 0x26c);
    *(undefined4 *)(param_1 + 0x26c) = 0;
    iStack_44 = *(int *)(param_1 + 0x270);
    *(undefined4 *)(param_1 + 0x270) = 0;
  }
  piVar12 = piStack_14;
  piStack_4c = piStack_18;
  piStack_48 = piStack_14;
  if (piStack_18 != piStack_14) {
    do {
      piVar13 = piStack_18;
      FUN_0085a9c0();
      iVar5 = *piVar13;
      if (*(int *)(iVar5 + 0x74) == *(int *)(iVar5 + 0x78)) {
        iVar6 = *(int *)(iStack_20 + 0x1bc);
        if (*(int *)(iVar6 + 8) != 0) {
          uVar2 = *(ushort *)(iVar5 + 0xcc);
          uStack_24 = (uint)uVar2;
          uVar14 = (int)(short)uVar2 + 0x9e3779b9;
          uVar3 = *(ushort *)(iVar5 + 0xce);
          uStack_28 = (uint)uVar3;
          uVar14 = uVar14 ^ (uVar14 >> 2) + uVar14 * 0x40 + (short)uVar3 + -0x61c88647;
          uVar4 = *(ushort *)(iVar5 + 0xd0);
          uStack_2c = (uint)uVar4;
          uVar14 = uVar14 ^ (uVar14 >> 2) + uVar14 * 0x40 + (short)uVar4 + -0x61c88647;
          piStack_30 = (int *)(uint)*(ushort *)(iVar5 + 0xd2);
          uVar14 = (int)piStack_30 + (uVar14 >> 2) + 0x9e3779b9 + uVar14 * 0x40 ^ uVar14;
          uStack_1c = uVar14 % *(uint *)(iVar6 + 4);
          iStack_34 = uStack_1c * 4;
          piVar13 = *(int **)(iStack_34 + *(int *)(iVar6 + 0x14));
          piVar12 = piStack_14;
          if ((piVar13 != (int *)0x0) && (piVar11 = (int *)*piVar13, (int *)*piVar13 != (int *)0x0))
          {
LAB_007cb590:
            piVar10 = piVar11;
            if ((uint)piVar10[1] % *(uint *)(iVar6 + 4) == uStack_1c) {
              if ((((piVar10[1] != uVar14) || (uVar2 != *(ushort *)(piVar10 + 2))) ||
                  (uVar3 != *(ushort *)((int)piVar10 + 10))) ||
                 ((uVar4 != *(ushort *)(piVar10 + 3) ||
                  (*(ushort *)(iVar5 + 0xd2) != *(ushort *)((int)piVar10 + 0xe)))))
              goto LAB_007cb5c6;
              piVar10 = (int *)*piVar10;
              piVar11 = (int *)*piVar13;
              piStack_30 = piVar10;
              do {
                *piVar13 = *piVar11;
                FUN_007c7190(piVar11);
                *(int *)(iVar6 + 8) = *(int *)(iVar6 + 8) + -1;
                piVar11 = (int *)*piVar13;
              } while (piVar11 != piVar10);
              piVar12 = piStack_14;
              if (piVar11 == (int *)0x0) {
LAB_007cb671:
                puVar9 = (undefined4 *)(*(int *)(iVar6 + 0x14) + iStack_34);
                if ((int *)*puVar9 == piVar13) {
                  *puVar9 = 0;
                }
              }
              else {
                uVar14 = (uint)piVar11[1] % *(uint *)(iVar6 + 4);
                if (uStack_1c != uVar14) {
                  *(int **)(*(int *)(iVar6 + 0x14) + uVar14 * 4) = piVar13;
                  goto LAB_007cb671;
                }
              }
            }
          }
        }
LAB_007cb5d3:
        piVar13 = piStack_18;
        if ((undefined4 *)*piStack_18 != (undefined4 *)0x0) {
          (*(code *)**(undefined4 **)*piStack_18)(1);
        }
      }
      piStack_18 = piVar13 + 1;
    } while (piStack_18 != piVar12);
  }
  uVar7 = uStack_38;
  uStack_8._0_1_ = 2;
  uVar8 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (piStack_4c != (int *)0x0) {
    uVar14 = (iStack_44 - (int)piStack_4c >> 2) * 4;
    piVar12 = piStack_4c;
    if (0xfff < uVar14) {
      piVar12 = (int *)piStack_4c[-1];
      uVar14 = uVar14 + 0x23;
      if (0x1f < (uint)((int)piStack_4c + (-4 - (int)piVar12))) {
        uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar12,uVar14);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_01675290(uVar7);
  uStack_8 = 5;
  FUN_0152dda0(uStack_40,uStack_3c,uVar15);
  ExceptionList = pvStack_10;
  return;
LAB_007cb5c6:
  piVar11 = (int *)*piVar10;
  piVar13 = piVar10;
  if ((int *)*piVar10 == (int *)0x0) goto LAB_007cb5d3;
  goto LAB_007cb590;
}



/* FUNCTION 11868 ; VA 0x007cb730 ; FUN_007cb730 */

void __fastcall FUN_007cb730(int param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void **ppvVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  uint uVar8;
  undefined8 uVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b387c;
  puVar7 = *(undefined4 **)(param_1 + 0x108);
  ppvVar4 = &pvStack_10;
  pvStack_10 = ExceptionList;
  for (puVar1 = (undefined4 *)*puVar7; ExceptionList = ppvVar4, puVar1 != puVar7;
      puVar1 = (undefined4 *)*puVar1) {
    iVar5 = FUN_0170d75d(puVar1[2],0,&RBX::GfxPart::RTTI_Type_Descriptor,
                         &RBX::Graphics::SmoothCluster::RTTI_Type_Descriptor,0);
    if (iVar5 != 0) {
      FUN_0080ef80();
    }
    ppvVar4 = (void **)ExceptionList;
  }
  iVar5 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  if ((*(int *)(iVar5 + 0x34) < DAT_01eb3158) && (FUN_016f3809(&DAT_01eb3158), DAT_01eb3158 == -1))
  {
    uStack_8 = 0;
    uVar9 = FUN_0152dab0("Render","performUpdateCoordinateFrame",0xffffffff);
    DAT_01eb3154 = (undefined4)((ulonglong)uVar9 >> 0x20);
    DAT_01eb3150 = (undefined4)uVar9;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb3158);
  }
  uVar3 = DAT_01eb3154;
  uVar2 = DAT_01eb3150;
  uVar9 = FUN_0152d930(DAT_01eb3150,DAT_01eb3154);
  puVar7 = *(undefined4 **)(param_1 + 0x2a4);
  uVar8 = 0;
  uStack_8 = 1;
  uVar6 = *(int *)(param_1 + 0x2a8) * 4 + 3U >> 2;
  if (puVar7 + *(int *)(param_1 + 0x2a8) < puVar7) {
    uVar6 = 0;
  }
  if (uVar6 != 0) {
    do {
      (**(code **)(*(int *)*puVar7 + 0x4c))();
      uVar8 = uVar8 + 1;
      puVar7 = puVar7 + 1;
    } while (uVar8 != uVar6);
  }
  uStack_8 = 2;
  FUN_0152dda0(uVar2,uVar3,uVar9);
  uStack_8 = 0xffffffff;
  if (DAT_01d60fc0 != '\0') {
    if ((*(int *)(iVar5 + 0x34) < DAT_01eb3168) && (FUN_016f3809(&DAT_01eb3168), DAT_01eb3168 == -1)
       ) {
      uStack_8 = 3;
      uVar9 = FUN_0152dab0("Render","update5a_sync",0xffffffff);
      DAT_01eb3164 = (undefined4)((ulonglong)uVar9 >> 0x20);
      DAT_01eb3160 = (undefined4)uVar9;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb3168);
    }
    uVar3 = DAT_01eb3164;
    uVar2 = DAT_01eb3160;
    uVar9 = FUN_0152d930(DAT_01eb3160,DAT_01eb3164);
    uVar8 = 0;
    uStack_8 = 4;
    uVar6 = (*(uint *)(param_1 + 0x2e0) - *(uint *)(param_1 + 0x2dc)) + 3 >> 2;
    if (*(uint *)(param_1 + 0x2e0) < *(uint *)(param_1 + 0x2dc)) {
      uVar6 = 0;
    }
    if (uVar6 != 0) {
      do {
        FUN_007b6ae0();
        uVar8 = uVar8 + 1;
      } while (uVar8 != uVar6);
    }
    uStack_8 = 5;
    FUN_0152dda0(uVar2,uVar3,uVar9);
  }
  uStack_8 = 0xffffffff;
  if (DAT_01d60fc8 != '\0') {
    if ((*(int *)(iVar5 + 0x34) < DAT_01eb3178) && (FUN_016f3809(&DAT_01eb3178), DAT_01eb3178 == -1)
       ) {
      uStack_8 = 6;
      uVar9 = FUN_0152dab0("Render","update6_bbox",0xffffffff);
      DAT_01eb3174 = (undefined4)((ulonglong)uVar9 >> 0x20);
      DAT_01eb3170 = (undefined4)uVar9;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb3178);
    }
    uVar3 = DAT_01eb3174;
    uVar2 = DAT_01eb3170;
    uVar9 = FUN_0152d930(DAT_01eb3170,DAT_01eb3174);
    uVar8 = 0;
    uStack_8 = 7;
    uVar6 = (*(uint *)(param_1 + 0x2ec) - *(uint *)(param_1 + 0x2e8)) + 3 >> 2;
    if (*(uint *)(param_1 + 0x2ec) < *(uint *)(param_1 + 0x2e8)) {
      uVar6 = 0;
    }
    if (uVar6 != 0) {
      do {
        FUN_007b6cd0(*(undefined4 *)(param_1 + 0x24));
        uVar8 = uVar8 + 1;
      } while (uVar8 != uVar6);
    }
    uStack_8 = 8;
    FUN_0152dda0(uVar2,uVar3,uVar9);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11869 ; VA 0x007cbaa0 ; FUN_007cbaa0 */

void __thiscall FUN_007cbaa0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  int iVar6;
  undefined8 uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b38a4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb3058) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb3058);
    cVar2 = DAT_01d7ad48;
    if (DAT_01eb3058 == -1) {
      uStack_8 = 0;
      uVar7 = FUN_0152dab0("Render","computeLightingPerform",0xffffffff);
      if ((cVar2 != '\0') && (DAT_01d7ad40 != '\0')) {
        FUN_01532a30(uVar7);
      }
      uStack_8 = 0xffffffff;
      DAT_01eb3050 = (int)uVar7;
      DAT_01eb3054 = (int)((ulonglong)uVar7 >> 0x20);
      FUN_016f37bf(&DAT_01eb3058);
    }
  }
  uVar4 = DAT_01eb3054;
  uVar3 = DAT_01eb3050;
  cVar2 = DAT_01d7ad48;
  uVar7 = FUN_01532c80(DAT_01eb3050,DAT_01eb3054);
  uStack_8 = 1;
  iVar6 = *(int *)(*(int *)(param_1 + 0x18c) + 0x4f8) + 0x54;
  cVar5 = FUN_0078bd20();
  if ((cVar5 != '\0') &&
     (piVar1 = *(int **)(*(int *)(param_1 + 0x18c) + 0x574), piVar1 != (int *)0x0)) {
    (**(code **)(*piVar1 + 8))(param_2,iVar6,param_3,param_4);
  }
  piVar1 = *(int **)(*(int *)(param_1 + 0x18c) + 0x52c);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x20))(param_2,iVar6,param_1 + 0x274,param_4);
  }
  uStack_8 = 2;
  FUN_0152dda0(uVar3,uVar4,uVar7);
  if ((cVar2 != '\0') && (DAT_01d7ad40 != '\0')) {
    FUN_01532d10(uVar3,uVar4,uVar7);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11870 ; VA 0x007cbc50 ; FUN_007cbc50 */

void __thiscall FUN_007cbc50(int param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  char cVar8;
  int iVar9;
  uint uVar10;
  int *piVar11;
  undefined8 uVar12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b38c4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb3038) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb3038), DAT_01eb3038 == -1)) {
    uStack_8 = 0;
    uVar12 = FUN_0152dab0("Render","UpdatePrepare",0xffffffff);
    DAT_01eb3034 = (undefined4)((ulonglong)uVar12 >> 0x20);
    DAT_01eb3030 = (undefined4)uVar12;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb3038);
  }
  uVar7 = DAT_01eb3034;
  uVar6 = DAT_01eb3030;
  uVar12 = FUN_0152d930(DAT_01eb3030,DAT_01eb3034);
  uStack_8 = 1;
  *(uint *)(param_1 + 0x24) = param_2;
  if (*(char *)(param_1 + 0x211) != '\0') {
    *(undefined *)(param_1 + 0x211) = 0;
    if (DAT_01d6517a != '\0') {
      FUN_01677520(DAT_01d6517a,"Scene updater %p - resetting all clusters",param_1);
    }
    FUN_007c8fc0();
  }
  if (DAT_01d6517a != '\0') {
    FUN_01677490(DAT_01d6517a,"Scene updater %p update cycle, current frame num: %u",param_1,param_2
                 ,0);
  }
  FUN_007c86e0(0);
  FUN_007c8390();
  FUN_007c8020();
  if (DAT_01d6c7c4 == '\0') {
    if (*(int *)(param_1 + 0x14c) == 0) goto LAB_007cbd6a;
    for (puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x158) + *(int *)(param_1 + 0x148) * 4);
        puVar1 != (undefined4 *)0x0; puVar1 = (undefined4 *)*puVar1) {
      FUN_0085ed40();
    }
  }
  FUN_007cbfc0(0);
LAB_007cbd6a:
  puVar1 = *(undefined4 **)(param_1 + 0x108);
  for (puVar2 = (undefined4 *)*puVar1; puVar2 != puVar1; puVar2 = (undefined4 *)*puVar2) {
    iVar9 = FUN_0170d75d(puVar2[2],0,&RBX::GfxPart::RTTI_Type_Descriptor,
                         &RBX::Graphics::SmoothCluster::RTTI_Type_Descriptor,0);
    if (iVar9 != 0) {
      FUN_0080f700();
    }
  }
  FUN_007c9670(*(undefined *)(*(int *)(param_1 + 4) + 0x2c));
  FUN_007cc5f0(*(undefined *)(*(int *)(param_1 + 4) + 0x2c));
  FUN_007c5560();
  FUN_007c86e0(1);
  FUN_007cb000(*(undefined *)(*(int *)(param_1 + 4) + 0x2c));
  FUN_007c9970();
  if (*(char *)(param_1 + 0x1c0) != '\0') {
    FUN_007cb3f0();
  }
  FUN_007ca080();
  if (*(int *)(param_1 + 600) == 0) {
    piVar5 = (int *)0x0;
  }
  else {
    piVar5 = *(int **)(*(int *)(param_1 + 0x264) + *(int *)(param_1 + 0x254) * 4);
  }
  do {
    while( true ) {
      if (piVar5 == (int *)0x0) {
        FUN_007c5930();
        if (DAT_01d6517a != '\0') {
          FUN_016774b0(DAT_01d6517a,"Scene updater finish",0);
        }
        uStack_8 = 2;
        FUN_0152dda0(uVar6,uVar7,uVar12);
        ExceptionList = pvStack_10;
        return;
      }
      cVar8 = FUN_008194a0();
      if (cVar8 == '\0') break;
      piVar5 = (int *)*piVar5;
    }
    param_2 = (uint)piVar5[1] % *(uint *)(param_1 + 0x254);
    piVar3 = (int *)*piVar5;
    piVar4 = *(int **)(*(int *)(param_1 + 0x264) + param_2 * 4);
    for (piVar11 = (int *)*piVar4; piVar11 != piVar5; piVar11 = (int *)*piVar11) {
      piVar4 = piVar11;
    }
    do {
      *piVar4 = *piVar11;
      piVar5 = (int *)piVar11[4];
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar9 = piVar5[1] + -1;
        piVar5[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar9 = piVar5[2] + -1;
          piVar5[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      FUN_01674ea0(piVar11,0x14);
      *(int *)(param_1 + 600) = *(int *)(param_1 + 600) + -1;
      uVar10 = param_2;
      if (*piVar4 == 0) {
LAB_007cbee6:
        if (*(int **)(*(int *)(param_1 + 0x264) + param_2 * 4) == piVar4) {
          *(undefined4 *)(*(int *)(param_1 + 0x264) + param_2 * 4) = 0;
        }
      }
      else {
        uVar10 = *(uint *)(*piVar4 + 4) % *(uint *)(param_1 + 0x254);
        if (param_2 != uVar10) {
          *(int **)(*(int *)(param_1 + 0x264) + uVar10 * 4) = piVar4;
          goto LAB_007cbee6;
        }
      }
      piVar11 = (int *)*piVar4;
      param_2 = uVar10;
      piVar5 = piVar3;
    } while (piVar11 != piVar3);
  } while( true );
}



/* FUNCTION 11871 ; VA 0x007cbfc0 ; FUN_007cbfc0 */

/* WARNING: Removing unreachable block (ram,0x007cc3b1) */

void __thiscall FUN_007cbfc0(int param_1,undefined4 param_2)

{
  int iVar1;
  int **ppiVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  undefined4 *puVar6;
  int iVar7;
  int *piVar8;
  uint uVar9;
  undefined4 *puVar10;
  int *piVar11;
  uint uVar12;
  undefined8 uVar13;
  int iStack_78;
  int iStack_74;
  int iStack_70;
  int *piStack_4c;
  undefined auStack_44 [4];
  int *piStack_40;
  int *piStack_3c;
  int *piStack_38;
  int iStack_34;
  int iStack_30;
  int *piStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b38fc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb3148) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb3148), DAT_01eb3148 == -1)) {
    uStack_8 = 0;
    uVar13 = FUN_0152dab0("Render","updateSkinningIslands",0xffffffff);
    DAT_01eb3144 = (int *)((ulonglong)uVar13 >> 0x20);
    DAT_01eb3140 = (int)uVar13;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb3148);
  }
  piVar5 = DAT_01eb3144;
  iVar7 = DAT_01eb3140;
  iStack_34 = DAT_01eb3140;
  piStack_2c = DAT_01eb3144;
  uVar13 = FUN_0152d930(DAT_01eb3140,DAT_01eb3144);
  uStack_8 = 1;
  iStack_28 = 0;
  FUN_0060e810(0,&iStack_28,&uStack_11);
  uStack_8._0_1_ = 2;
  if (*(int *)(param_1 + 0x17c) == 0) {
    puVar10 = (undefined4 *)0x0;
  }
  else {
    puVar10 = *(undefined4 **)(*(int *)(param_1 + 0x188) + *(int *)(param_1 + 0x178) * 4);
  }
  for (; puVar10 != (undefined4 *)0x0; puVar10 = (undefined4 *)*puVar10) {
    if ((puVar10[4] != 0) && (*(int *)(puVar10[4] + 4) != 0)) {
      piStack_38 = (int *)puVar10[2];
      if (piStack_38[0x2b] == 0) {
        piVar11 = (int *)piStack_38[0xd];
        if (piVar11 != (int *)0x0) {
          iVar1 = piVar11[3];
          iVar3 = FUN_00b63e30();
          if ((uint)*(ushort *)(iVar3 + 0x1da) <
              (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
            piVar11 = (int *)FUN_007c0ca0();
          }
          if (piVar11 != (int *)0x0) {
            iVar1 = piVar11[3];
            iVar3 = FUN_008aa870();
            if ((uint)*(ushort *)(iVar3 + 0x1da) <
                (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
              piStack_38 = piVar11;
              if ((uint)((iStack_74 - iStack_78 >> 2) * 3) >> 2 == 0) {
                FUN_006286d0();
              }
              ppiVar2 = &piStack_38;
            }
            else {
              piStack_3c = piStack_38;
              if ((uint)((iStack_74 - iStack_78 >> 2) * 3) >> 2 == 0) {
                FUN_006286d0();
              }
              ppiVar2 = &piStack_3c;
            }
            FUN_00620c30(ppiVar2);
          }
        }
      }
      else {
        *(undefined *)(piStack_38[0x2b] + 0x60) = 0;
      }
    }
    param_1 = iStack_1c;
  }
  iStack_28 = 0;
  piStack_4c = (int *)0x0;
  iStack_24 = param_1 + 0x144;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (*(int *)(param_1 + 0x14c) == 0) {
    piVar11 = (int *)0x0;
  }
  else {
    piVar11 = *(int **)(*(int *)(param_1 + 0x158) + *(int *)(param_1 + 0x148) * 4);
  }
  piVar8 = (int *)0x0;
  if (piVar11 != (int *)0x0) {
    do {
      piStack_18 = (int *)piVar11[2];
      if (*(char *)((int)piStack_18 + 0x61) == '\0') {
        if (piStack_4c == (int *)0x0) {
          FUN_006030d0(0,&piStack_18);
        }
        else {
          *piStack_4c = (int)piStack_18;
          piStack_4c = piStack_4c + 1;
        }
        FUN_00587490(&iStack_30);
        uStack_8._0_1_ = 4;
        iStack_20 = iStack_30;
        piVar8 = piStack_2c;
        if (iStack_30 != 0) {
          iVar1 = *(int *)(iStack_30 + 0xc);
          iVar3 = FUN_00aff8c0();
          piVar8 = piStack_2c;
          if (((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
               (uint)*(ushort *)(iVar3 + 0x1da)) &&
             (piStack_18 = *(int **)(iStack_20 + 0x34), piStack_18 != (int *)0x0)) {
            iVar1 = piStack_18[3];
            iVar3 = FUN_00b63e30();
            if ((uint)*(ushort *)(iVar3 + 0x1da) <
                (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
              piStack_18 = (int *)FUN_007c0ca0();
            }
            piVar8 = piStack_2c;
            if ((piStack_18 != (int *)0x0) &&
               (iVar1 = piStack_18[3], iVar3 = FUN_008aa870(), piVar8 = piStack_2c,
               (uint)*(ushort *)(iVar3 + 0x1da) <
               (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
              piVar4 = (int *)FUN_0060dcd0(auStack_44,piStack_18);
              iStack_30 = *piVar4;
              piVar8 = (int *)piVar4[1];
              *piVar4 = 0;
              piVar4[1] = 0;
              piStack_3c = piStack_2c;
              piVar4 = piVar8;
              iStack_20 = iStack_30;
              if (piStack_2c != (int *)0x0) {
                LOCK();
                iVar1 = piStack_2c[1] + -1;
                piStack_2c[1] = iVar1;
                UNLOCK();
                if (iVar1 == 0) {
                  puVar10 = (undefined4 *)*piStack_2c;
                  piStack_2c = piVar8;
                  (*(code *)*puVar10)();
                  LOCK();
                  iVar1 = piStack_3c[2] + -1;
                  piStack_3c[2] = iVar1;
                  UNLOCK();
                  piVar4 = piStack_2c;
                  if (iVar1 == 0) {
                    (**(code **)(*piStack_3c + 4))();
                    piVar4 = piStack_2c;
                  }
                }
              }
              piStack_2c = piVar4;
              piStack_3c = piStack_40;
              if (piStack_40 != (int *)0x0) {
                LOCK();
                iVar1 = piStack_40[1] + -1;
                piStack_40[1] = iVar1;
                UNLOCK();
                if (iVar1 == 0) {
                  (**(code **)*piStack_40)();
                  LOCK();
                  iVar1 = piStack_3c[2] + -1;
                  piStack_3c[2] = iVar1;
                  UNLOCK();
                  if (iVar1 == 0) {
                    (**(code **)(*piStack_3c + 4))();
                  }
                }
              }
            }
          }
          iStack_34 = iStack_20;
          if ((uint)((iStack_74 - iStack_78 >> 2) * 3) >> 2 == 0) {
            FUN_006286d0();
          }
          FUN_00620c30(&iStack_34);
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        if (piVar8 != (int *)0x0) {
          LOCK();
          iVar1 = piVar8[1] + -1;
          piVar8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar8)();
            LOCK();
            iVar1 = piVar8[2] + -1;
            piVar8[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar8 + 4))();
            }
          }
        }
      }
      piVar11 = (int *)*piVar11;
    } while (piVar11 != (int *)0x0);
    piStack_2c = piVar5;
    iStack_34 = iVar7;
    piVar8 = piStack_4c;
  }
  iStack_28 = 0;
  piStack_18 = (int *)0x0;
  piVar11 = (int *)0x0;
  piVar5 = (int *)((int)piVar8 + 3U >> 2);
  piStack_3c = piVar5;
  if (piVar5 != (int *)0x0) {
    do {
      iVar7 = *piStack_18;
      iStack_20 = iVar7;
      FUN_007c70b0(&iStack_20);
      FUN_007c70b0(&iStack_20);
      FUN_0085dc10();
      if (iVar7 != 0) {
        FUN_007c2fc0();
        FUN_01674ea0(iVar7,100);
      }
      piVar11 = (int *)((int)piVar11 + 1);
      piStack_18 = piStack_18 + 1;
    } while (piVar11 != piVar5);
  }
  uVar9 = 0;
  uVar12 = iStack_74 - iStack_78 >> 2;
  if (uVar12 != 0) {
    do {
      if (*(int *)(iStack_78 + uVar9 * 4) != 0) break;
      uVar9 = uVar9 + 1;
    } while (uVar9 < uVar12);
  }
  do {
    iVar7 = iStack_1c;
    if (uVar9 == uVar12) {
      if (*(int *)(iStack_1c + 0x17c) != 0) {
        FUN_007c6260(*(int *)(iStack_1c + 0x188) + *(int *)(iStack_1c + 0x178) * 4,0);
        puVar6 = *(undefined4 **)(iVar7 + 0x188);
        puVar10 = puVar6 + *(int *)(iVar7 + 0x178);
        for (; puVar6 != puVar10; puVar6 = puVar6 + 1) {
          *puVar6 = 0;
        }
      }
      if (*(int *)(iVar7 + 0x14c) == 0) {
        puVar10 = (undefined4 *)0x0;
      }
      else {
        puVar10 = *(undefined4 **)(*(int *)(iVar7 + 0x158) + *(int *)(iVar7 + 0x148) * 4);
      }
      for (; puVar10 != (undefined4 *)0x0; puVar10 = (undefined4 *)*puVar10) {
        FUN_0085ed50(param_2);
        FUN_0085fa50();
      }
      uStack_8._1_3_ = (undefined3)((uint)uStack_8 >> 8);
      uStack_8._0_1_ = 2;
      if (iStack_28 != 0) {
        uVar9 = (-iStack_28 >> 2) * 4;
        iVar7 = iStack_28;
        if (0xfff < uVar9) {
          iVar7 = *(int *)(iStack_28 + -4);
          uVar9 = uVar9 + 0x23;
          if (0x1f < (iStack_28 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar7,uVar9);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (iStack_78 != 0) {
        uVar9 = (iStack_70 - iStack_78 >> 2) * 4;
        iVar7 = iStack_78;
        if (0xfff < uVar9) {
          iVar7 = *(int *)(iStack_78 + -4);
          uVar9 = uVar9 + 0x23;
          if (0x1f < (iStack_78 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar7,uVar9);
      }
      uStack_8 = 5;
      FUN_0152dda0(iStack_34,piStack_2c,uVar13);
      ExceptionList = pvStack_10;
      return;
    }
    FUN_0085c480(iStack_1c,*(undefined4 *)(iStack_78 + uVar9 * 4),param_2);
    do {
      uVar9 = uVar9 + 1;
      if (uVar12 <= uVar9) break;
    } while (*(int *)(iStack_78 + uVar9 * 4) == 0);
  } while( true );
}



/* FUNCTION 11872 ; VA 0x007cc5f0 ; FUN_007cc5f0 */

void __thiscall FUN_007cc5f0(uint *param_1,undefined4 param_2)

{
  char cVar1;
  float *pfVar2;
  uint *puVar3;
  double *pdVar4;
  uint *puVar5;
  uint uVar6;
  uint *puVar7;
  uint *puVar8;
  undefined8 uVar9;
  uint *puStack_60;
  uint *puStack_5c;
  float fStack_58;
  uint uStack_54;
  uint *puStack_50;
  uint *puStack_4c;
  uint *puStack_48;
  undefined auStack_44 [4];
  undefined auStack_40 [8];
  double dStack_38;
  undefined auStack_30 [4];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  uint *puStack_24;
  uint *puStack_20;
  uint *puStack_1c;
  uint *puStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b392c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2f88) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb2f88), DAT_01eb2f88 == -1)) {
    uStack_8 = 0;
    uVar9 = FUN_0152dab0("Render","updateWaitingParts",0xffffffff);
    DAT_01eb2f84 = (undefined4)((ulonglong)uVar9 >> 0x20);
    DAT_01eb2f80 = (undefined4)uVar9;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb2f88);
  }
  uStack_2c = DAT_01eb2f80;
  uStack_28 = DAT_01eb2f84;
  uVar9 = FUN_0152d930(DAT_01eb2f80,DAT_01eb2f84);
  uStack_8 = 1;
  if ((param_1[0x50] != 0) && (DAT_01d6517a != '\0')) {
    FUN_016774b0(DAT_01d6517a,"Waiting parts, pass begin: %u",param_1[0x50]);
  }
  if ((-(uint)(param_1[5] != 0) & param_1[5] + 0xc) != 0) {
    FUN_005c2760();
  }
  puStack_24 = (uint *)0x0;
  puStack_50 = (uint *)0x0;
  puStack_4c = (uint *)0x0;
  puStack_1c = (uint *)0x0;
  puStack_48 = (uint *)0x0;
  puStack_18 = param_1 + 0x4f;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puVar8 = *(uint **)*puStack_18;
  puStack_14 = puVar8;
  if (puVar8 != (uint *)*puStack_18) {
    do {
      pfVar2 = (float *)(**(code **)(*(int *)puVar8[4] + 100))(auStack_44);
      uStack_54 = 0;
      puStack_60 = (uint *)puVar8[4];
      puVar7 = (uint *)param_1[0x4f];
      fStack_58 = (pfVar2[1] - (float)param_1[0xa1]) * (pfVar2[1] - (float)param_1[0xa1]) +
                  (*pfVar2 - (float)param_1[0xa0]) * (*pfVar2 - (float)param_1[0xa0]) +
                  (pfVar2[2] - (float)param_1[0xa2]) * (pfVar2[2] - (float)param_1[0xa2]);
      puStack_24 = puStack_60;
      puStack_5c = puVar8;
      while ((puVar8 != puVar7 && ((uint *)puVar8[4] == puStack_24))) {
        FUN_00551320();
        uStack_54 = uStack_54 + 1;
        puVar8 = puStack_14;
      }
      if (puStack_1c == puStack_4c) {
        FUN_006038a0(puStack_4c,&puStack_60);
        puStack_1c = puStack_48;
      }
      else {
        *puStack_4c = (uint)puStack_60;
        puStack_4c[1] = (uint)puStack_5c;
        puStack_4c[2] = (uint)fStack_58;
        puStack_4c[3] = uStack_54;
        puStack_4c = puStack_4c + 4;
      }
      param_1 = puStack_20;
    } while (puVar8 != (uint *)*puStack_18);
    puStack_24 = puStack_50;
  }
  puVar8 = puStack_24;
  puStack_50 = puStack_24;
  FUN_007c06e0(puStack_24,puStack_4c,(int)puStack_4c - (int)puStack_24 >> 4,param_2);
  FUN_016827e0(&dStack_38);
  puVar7 = puVar8;
  if (puVar8 != puStack_4c) {
    do {
      puStack_14 = (uint *)puVar8[1];
      uVar6 = 0;
      if (puVar8[3] != 0) {
LAB_007cc7d1:
        cVar1 = FUN_01153f80(puStack_14 + 5);
        if (cVar1 == '\0') goto code_r0x007cc7e1;
        puVar7 = (uint *)*puStack_18;
        puVar5 = (uint *)puVar7[1];
        cVar1 = *(char *)((int)puVar5 + 0xd);
        puStack_20 = puVar7;
        puStack_14 = puVar5;
        while (cVar1 == '\0') {
          if (puStack_14[4] < *puVar8) {
            puVar3 = (uint *)puStack_14[2];
            puStack_14 = puStack_20;
          }
          else {
            if ((*(char *)((int)puVar7 + 0xd) != '\0') && (*puVar8 < puStack_14[4])) {
              puVar7 = puStack_14;
            }
            puVar3 = (uint *)*puStack_14;
          }
          puStack_20 = puStack_14;
          puStack_14 = puVar3;
          cVar1 = *(char *)((int)puVar3 + 0xd);
        }
        if (*(char *)((int)puVar7 + 0xd) == '\0') {
          puVar5 = (uint *)*puVar7;
        }
        puStack_14 = puStack_20;
        if (*(char *)((int)puVar5 + 0xd) == '\0') {
          do {
            if (*puVar8 < puVar5[4]) {
              puVar3 = (uint *)*puVar5;
              puVar7 = puVar5;
            }
            else {
              puVar3 = (uint *)puVar5[2];
            }
            puVar5 = puVar3;
          } while (*(char *)((int)puVar3 + 0xd) == '\0');
        }
        while (puStack_20 != puVar7) {
          FUN_00551320();
        }
        FUN_007c6cb0(auStack_30,puStack_14,puVar7);
        (**(code **)(*(int *)*puVar8 + 0xc))(1);
        if (((char)param_2 == '\0') &&
           (pdVar4 = (double *)FUN_016827e0(auStack_40), puVar7 = puStack_24,
           (double)DAT_01d61d74 < (*pdVar4 - dStack_38) * DAT_018c0d70)) break;
      }
LAB_007cc8be:
      puVar8 = puVar8 + 4;
      puVar7 = puStack_24;
    } while (puVar8 != puStack_4c);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (puVar7 != (uint *)0x0) {
    uVar6 = (int)puStack_1c - (int)puVar7 & 0xfffffff0;
    puVar8 = puVar7;
    if (0xfff < uVar6) {
      puVar8 = (uint *)puVar7[-1];
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uint)((int)puVar7 + (-4 - (int)puVar8))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar8,uVar6);
  }
  uStack_8 = 3;
  FUN_0152dda0(uStack_2c,uStack_28,uVar9);
  ExceptionList = pvStack_10;
  return;
code_r0x007cc7e1:
  FUN_00551320();
  uVar6 = uVar6 + 1;
  if (puVar8[3] <= uVar6) goto LAB_007cc8be;
  goto LAB_007cc7d1;
}



/* FUNCTION 11873 ; VA 0x007cc990 ; FUN_007cc990 */

undefined4 * __fastcall FUN_007cc990(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  return param_1;
}



/* FUNCTION 11874 ; VA 0x007cc9d0 ; FUN_007cc9d0 */

undefined4 * __fastcall FUN_007cc9d0(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  FUN_01165ab0();
  FUN_01165ab0();
  puVar4 = (undefined4 *)FUN_01165df0();
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  param_1[0x27] = *puVar4;
  param_1[0x28] = uVar1;
  param_1[0x29] = uVar2;
  param_1[0x2a] = uVar3;
  uVar1 = puVar4[5];
  uVar2 = puVar4[6];
  uVar3 = puVar4[7];
  param_1[0x2b] = puVar4[4];
  param_1[0x2c] = uVar1;
  param_1[0x2d] = uVar2;
  param_1[0x2e] = uVar3;
  uVar1 = puVar4[9];
  uVar2 = puVar4[10];
  uVar3 = puVar4[0xb];
  param_1[0x2f] = puVar4[8];
  param_1[0x30] = uVar1;
  param_1[0x31] = uVar2;
  param_1[0x32] = uVar3;
  uVar1 = puVar4[0xd];
  uVar2 = puVar4[0xe];
  uVar3 = puVar4[0xf];
  param_1[0x33] = puVar4[0xc];
  param_1[0x34] = uVar1;
  param_1[0x35] = uVar2;
  param_1[0x36] = uVar3;
  FUN_01165ab0();
  iVar5 = 6;
  do {
    FUN_007cc990();
    iVar5 = iVar5 + -1;
  } while (iVar5 != 0);
  iVar5 = 8;
  do {
    FUN_0060f2c0();
    iVar5 = iVar5 + -1;
  } while (iVar5 != 0);
  return param_1;
}



/* FUNCTION 11875 ; VA 0x007ccaa0 ; FUN_007ccaa0 */

int __thiscall FUN_007ccaa0(int param_1,int param_2)

{
  return param_2 * 0x10 + param_1 + 0x1c4;
}



/* FUNCTION 11876 ; VA 0x007ccac0 ; FUN_007ccac0 */

int __thiscall FUN_007ccac0(int param_1,int param_2)

{
  return param_1 + 0x11c + param_2 * 0x1c;
}



/* FUNCTION 11877 ; VA 0x007ccae0 ; FUN_007ccae0 */

undefined4 __thiscall FUN_007ccae0(int param_1,float *param_2)

{
  undefined4 uVar1;
  float *pfVar2;
  int iVar3;
  float fVar4;
  float fVar5;
  
  iVar3 = 0;
  pfVar2 = (float *)(param_1 + 0x134);
  uVar1 = 2;
  do {
    fVar4 = pfVar2[-5] * (param_2[1] + param_2[4]) * DAT_018ce2f4 +
            pfVar2[-6] * (*param_2 + param_2[3]) * DAT_018ce2f4 +
            pfVar2[-4] * (param_2[2] + param_2[5]) * DAT_018ce2f4 + pfVar2[-3];
    fVar5 = pfVar2[-1] * (param_2[4] - param_2[1]) * DAT_018ce2f4 +
            pfVar2[-2] * (param_2[3] - *param_2) * DAT_018ce2f4 +
            *pfVar2 * (param_2[5] - param_2[2]) * DAT_018ce2f4;
    if (fVar5 + fVar4 < 0.0) {
      return 0;
    }
    if (fVar4 - fVar5 < 0.0) {
      uVar1 = 1;
    }
    iVar3 = iVar3 + 1;
    pfVar2 = pfVar2 + 7;
  } while (iVar3 < 6);
  return uVar1;
}



/* FUNCTION 11878 ; VA 0x007ccbf0 ; FUN_007ccbf0 */

uint __thiscall FUN_007ccbf0(int param_1,int param_2)

{
  float *pfVar1;
  int iVar2;
  int iVar3;
  float *pfVar4;
  int iVar5;
  
  iVar5 = 0;
  pfVar4 = (float *)(param_1 + 0x124);
  do {
    iVar3 = 0;
    iVar2 = 0;
    pfVar1 = (float *)(param_2 + 0x1cc);
    do {
      if (0.0 <= pfVar1[-2] * pfVar4[-2] + pfVar1[-1] * pfVar4[-1] + *pfVar4 * *pfVar1 +
                 pfVar1[1] * pfVar4[1]) break;
      iVar2 = iVar2 + 1;
      iVar3 = iVar3 + 1;
      pfVar1 = pfVar1 + 4;
    } while (iVar2 < 8);
    if (iVar3 == 8) goto LAB_007ccd06;
    iVar5 = iVar5 + 1;
    pfVar4 = pfVar4 + 7;
  } while (iVar5 < 6);
  iVar5 = 0;
  pfVar4 = (float *)(param_2 + 0x124);
  do {
    pfVar1 = (float *)(param_1 + 0x1cc);
    iVar3 = 0;
    iVar2 = 0;
    do {
      if (0.0 <= pfVar1[-2] * pfVar4[-2] + pfVar1[-1] * pfVar4[-1] + *pfVar4 * *pfVar1 +
                 pfVar1[1] * pfVar4[1]) break;
      iVar2 = iVar2 + 1;
      iVar3 = iVar3 + 1;
      pfVar1 = pfVar1 + 4;
    } while (iVar2 < 8);
    if (iVar3 == 8) {
LAB_007ccd06:
      return (uint)pfVar1 & 0xffffff00;
    }
    iVar5 = iVar5 + 1;
    pfVar4 = pfVar4 + 7;
    if (5 < iVar5) {
      return CONCAT31((int3)((uint)pfVar1 >> 8),1);
    }
  } while( true );
}



/* FUNCTION 11879 ; VA 0x007ccd20 ; FUN_007ccd20 */

uint __thiscall FUN_007ccd20(int param_1,float *param_2)

{
  uint uVar1;
  float *pfVar2;
  
  uVar1 = 0;
  pfVar2 = (float *)(param_1 + 0x134);
  do {
    if (pfVar2[-5] * (param_2[1] + param_2[4]) * DAT_018ce2f4 +
        pfVar2[-6] * (*param_2 + param_2[3]) * DAT_018ce2f4 +
        pfVar2[-4] * (param_2[2] + param_2[5]) * DAT_018ce2f4 + pfVar2[-3] +
        pfVar2[-1] * (param_2[4] - param_2[1]) * DAT_018ce2f4 +
        pfVar2[-2] * (param_2[3] - *param_2) * DAT_018ce2f4 +
        *pfVar2 * (param_2[5] - param_2[2]) * DAT_018ce2f4 < 0.0) {
      return uVar1 & 0xffffff00;
    }
    uVar1 = uVar1 + 1;
    pfVar2 = pfVar2 + 7;
  } while ((int)uVar1 < 6);
  return CONCAT31((int3)(uVar1 >> 8),1);
}



/* FUNCTION 11880 ; VA 0x007cce20 ; FUN_007cce20 */

uint __thiscall FUN_007cce20(int param_1,undefined4 param_2,undefined4 param_3)

{
  float *pfVar1;
  uint uVar2;
  float *pfVar3;
  undefined auStack_20 [28];
  
  pfVar1 = (float *)FUN_00c9f550(auStack_20,param_3);
  uVar2 = 0;
  pfVar3 = (float *)(param_1 + 0x134);
  do {
    if (pfVar3[-5] * (pfVar1[1] + pfVar1[4]) * DAT_018ce2f4 +
        pfVar3[-6] * (*pfVar1 + pfVar1[3]) * DAT_018ce2f4 +
        pfVar3[-4] * (pfVar1[2] + pfVar1[5]) * DAT_018ce2f4 + pfVar3[-3] +
        pfVar3[-1] * (pfVar1[4] - pfVar1[1]) * DAT_018ce2f4 +
        pfVar3[-2] * (pfVar1[3] - *pfVar1) * DAT_018ce2f4 +
        (pfVar1[5] - pfVar1[2]) * DAT_018ce2f4 * *pfVar3 < 0.0) {
      return uVar2 & 0xffffff00;
    }
    uVar2 = uVar2 + 1;
    pfVar3 = pfVar3 + 7;
  } while ((int)uVar2 < 6);
  return CONCAT31((int3)(uVar2 >> 8),1);
}



/* FUNCTION 11881 ; VA 0x007ccf30 ; FUN_007ccf30 */

uint __thiscall FUN_007ccf30(int param_1,float *param_2)

{
  uint uVar1;
  float *pfVar2;
  
  uVar1 = 0;
  pfVar2 = (float *)(param_1 + 0x124);
  do {
    if (pfVar2[-2] * *param_2 + pfVar2[-1] * param_2[1] + param_2[2] * *pfVar2 + pfVar2[1] +
        param_2[3] < 0.0) {
      return uVar1 & 0xffffff00;
    }
    uVar1 = uVar1 + 1;
    pfVar2 = pfVar2 + 7;
  } while ((int)uVar1 < 6);
  return CONCAT31((int3)(uVar1 >> 8),1);
}



/* FUNCTION 11882 ; VA 0x007ccfb0 ; FUN_007ccfb0 */

uint FUN_007ccfb0(void)

{
  float fVar1;
  float *pfVar2;
  int iVar3;
  int iVar4;
  float *pfVar5;
  int iVar6;
  float fVar7;
  float fVar8;
  float afStack_13c [32];
  float afStack_bc [5];
  uint uStack_a8;
  uint uStack_a4;
  float fStack_a0;
  float fStack_9c;
  float fStack_98;
  float fStack_94;
  float fStack_90;
  float fStack_8c;
  uint uStack_88;
  uint uStack_84;
  float fStack_80;
  float fStack_7c;
  float fStack_78;
  float fStack_74;
  float fStack_70;
  float fStack_6c;
  uint uStack_68;
  uint uStack_64;
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  float fStack_50;
  undefined auStack_4c [12];
  int iStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  iVar6 = 8;
  do {
    FUN_0060f2c0();
    iVar6 = iVar6 + -1;
  } while (iVar6 != 0);
  iVar6 = 0;
  pfVar5 = afStack_13c;
  do {
    pfVar2 = (float *)FUN_00c9f1c0(auStack_4c,iVar6);
    fStack_14 = *pfVar2;
    fStack_10 = pfVar2[1];
    fStack_c = pfVar2[2];
    fStack_8 = 1.0;
    FUN_01165b90(&fStack_5c,&fStack_14);
    fVar1 = fStack_50;
    fVar8 = fStack_54;
    fVar7 = fStack_58;
    iVar6 = iVar6 + 1;
    *pfVar5 = fStack_5c;
    pfVar5[1] = fVar7;
    pfVar5[2] = fVar8;
    pfVar5[3] = fVar1;
    pfVar5 = pfVar5 + 4;
  } while (iVar6 < 8);
  iVar6 = 0;
  pfVar5 = (float *)(iStack_40 + 0x124);
  do {
    pfVar2 = afStack_13c + 2;
    iVar4 = 0;
    iVar3 = 0;
    do {
      if (0.0 <= pfVar2[-2] * pfVar5[-2] + pfVar2[-1] * pfVar5[-1] + *pfVar2 * *pfVar5 +
                 pfVar2[1] * pfVar5[1]) break;
      iVar3 = iVar3 + 1;
      iVar4 = iVar4 + 1;
      pfVar2 = pfVar2 + 4;
    } while (iVar3 < 8);
    if (iVar4 == 8) goto LAB_007cd4a8;
    iVar6 = iVar6 + 1;
    pfVar5 = pfVar5 + 7;
  } while (iVar6 < 6);
  FUN_01165d60(&fStack_5c,0);
  FUN_011658d0(&fStack_24);
  FUN_01165d60(&fStack_5c,1);
  FUN_011658d0(&fStack_30);
  FUN_01165d60(&fStack_5c,2);
  FUN_011658d0(&fStack_3c);
  iVar6 = 6;
  do {
    FUN_0060f2c0();
    iVar6 = iVar6 + -1;
  } while (iVar6 != 0);
  fVar7 = (float)((uint)fStack_24 ^ DAT_018c4ea0);
  fVar8 = (float)((uint)fStack_20 ^ DAT_018c4ea0);
  fStack_18 = (float)((uint)fStack_1c ^ DAT_018c4ea0);
  pfVar5 = (float *)FUN_011658d0(auStack_4c);
  fStack_14 = fStack_24;
  fStack_10 = fStack_20;
  fStack_c = fStack_1c;
  afStack_bc[3] = pfVar5[1] * fVar8 + fVar7 * *pfVar5 + pfVar5[2] * fStack_18;
  afStack_bc[0] = fStack_24;
  afStack_bc[1] = fStack_20;
  afStack_bc[2] = fStack_1c;
  fStack_8 = afStack_bc[3];
  pfVar5 = (float *)FUN_011658d0(auStack_4c);
  afStack_bc[4] = (float)((uint)fStack_24 ^ DAT_018c4ea0);
  uStack_a8 = (uint)fStack_20 ^ DAT_018c4ea0;
  uStack_a4 = (uint)fStack_1c ^ DAT_018c4ea0;
  fStack_a0 = pfVar5[1] * fStack_20 + *pfVar5 * fStack_24 + pfVar5[2] * fStack_1c;
  fVar7 = (float)((uint)fStack_30 ^ DAT_018c4ea0);
  fVar8 = (float)((uint)fStack_2c ^ DAT_018c4ea0);
  fStack_18 = (float)((uint)fStack_28 ^ DAT_018c4ea0);
  fStack_14 = afStack_bc[4];
  fStack_10 = (float)uStack_a8;
  fStack_c = (float)uStack_a4;
  fStack_8 = fStack_a0;
  pfVar5 = (float *)FUN_011658d0(auStack_4c);
  fStack_14 = fStack_30;
  fStack_10 = fStack_2c;
  fStack_c = fStack_28;
  fStack_90 = pfVar5[1] * fVar8 + fVar7 * *pfVar5 + pfVar5[2] * fStack_18;
  fStack_9c = fStack_30;
  fStack_98 = fStack_2c;
  fStack_94 = fStack_28;
  fStack_8 = fStack_90;
  pfVar5 = (float *)FUN_011658d0(auStack_4c);
  fStack_8c = (float)((uint)fStack_30 ^ DAT_018c4ea0);
  uStack_88 = (uint)fStack_2c ^ DAT_018c4ea0;
  uStack_84 = (uint)fStack_28 ^ DAT_018c4ea0;
  fStack_80 = pfVar5[1] * fStack_2c + *pfVar5 * fStack_30 + pfVar5[2] * fStack_28;
  fVar7 = (float)((uint)fStack_3c ^ DAT_018c4ea0);
  fVar8 = (float)((uint)fStack_38 ^ DAT_018c4ea0);
  fStack_18 = (float)((uint)fStack_34 ^ DAT_018c4ea0);
  fStack_14 = fStack_8c;
  fStack_10 = (float)uStack_88;
  fStack_c = (float)uStack_84;
  fStack_8 = fStack_80;
  pfVar5 = (float *)FUN_011658d0(auStack_4c);
  fStack_14 = fStack_3c;
  fStack_10 = fStack_38;
  fStack_c = fStack_34;
  fStack_70 = pfVar5[1] * fVar8 + fVar7 * *pfVar5 + pfVar5[2] * fStack_18;
  fStack_7c = fStack_3c;
  fStack_78 = fStack_38;
  fStack_74 = fStack_34;
  fStack_8 = fStack_70;
  pfVar5 = (float *)FUN_011658d0(auStack_4c);
  fStack_14 = (float)((uint)fStack_3c ^ DAT_018c4ea0);
  fStack_10 = (float)((uint)fStack_38 ^ DAT_018c4ea0);
  fStack_c = (float)((uint)fStack_34 ^ DAT_018c4ea0);
  fStack_8 = pfVar5[1] * fStack_38 + *pfVar5 * fStack_3c + pfVar5[2] * fStack_34;
  pfVar5 = afStack_bc + 2;
  fStack_6c = (float)((uint)fStack_3c ^ DAT_018c4ea0);
  uStack_68 = (uint)fStack_38 ^ DAT_018c4ea0;
  uStack_64 = (uint)fStack_34 ^ DAT_018c4ea0;
  fStack_60 = fStack_8;
  iVar6 = 0;
  do {
    iVar4 = 0;
    iVar3 = 0;
    pfVar2 = (float *)(iStack_40 + 0x1cc);
    do {
      if (0.0 <= pfVar2[-2] * pfVar5[-2] + pfVar2[-1] * pfVar5[-1] + *pfVar5 * *pfVar2 +
                 pfVar2[1] * pfVar5[1]) break;
      iVar3 = iVar3 + 1;
      iVar4 = iVar4 + 1;
      pfVar2 = pfVar2 + 4;
    } while (iVar3 < 8);
    if (iVar4 == 8) {
LAB_007cd4a8:
      return (uint)pfVar2 & 0xffffff00;
    }
    iVar6 = iVar6 + 1;
    pfVar5 = pfVar5 + 4;
    if (5 < iVar6) {
      return CONCAT31((int3)((uint)(iStack_40 + 0x1cc) >> 8),1);
    }
  } while( true );
}



/* FUNCTION 11883 ; VA 0x007cd4c0 ; FUN_007cd4c0 */

undefined4 * FUN_007cd4c0(undefined4 *param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  puVar4 = (undefined4 *)FUN_01165df0();
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *param_1 = *puVar4;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  uVar1 = puVar4[5];
  uVar2 = puVar4[6];
  uVar3 = puVar4[7];
  param_1[4] = puVar4[4];
  param_1[5] = uVar1;
  param_1[6] = uVar2;
  param_1[7] = uVar3;
  uVar1 = puVar4[9];
  uVar2 = puVar4[10];
  uVar3 = puVar4[0xb];
  param_1[8] = puVar4[8];
  param_1[9] = uVar1;
  param_1[10] = uVar2;
  param_1[0xb] = uVar3;
  uVar1 = puVar4[0xd];
  uVar2 = puVar4[0xe];
  uVar3 = puVar4[0xf];
  param_1[0xc] = puVar4[0xc];
  param_1[0xd] = uVar1;
  param_1[0xe] = uVar2;
  param_1[0xf] = uVar3;
  if (param_2 == 1) {
    param_1[1] = 0x3f800000;
    param_1[4] = &DAT_bf800000;
    param_1[5] = 0;
    *param_1 = 0;
    return param_1;
  }
  if (param_2 == 2) {
    *param_1 = &DAT_bf800000;
    param_1[1] = 0;
    param_1[4] = 0;
    param_1[5] = &DAT_bf800000;
    return param_1;
  }
  if (param_2 == 3) {
    param_1[1] = &DAT_bf800000;
    param_1[4] = 0x3f800000;
    param_1[5] = 0;
    *param_1 = 0;
  }
  return param_1;
}



/* FUNCTION 11884 ; VA 0x007cd560 ; FUN_007cd560 */

void __thiscall FUN_007cd560(int param_1,int param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined auStack_84 [64];
  undefined auStack_44 [64];
  
  FUN_007cd4c0(auStack_44,param_3);
  puVar4 = (undefined4 *)FUN_01165af0(auStack_84,param_2);
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *(undefined4 *)(param_1 + 0x5c) = *puVar4;
  *(undefined4 *)(param_1 + 0x60) = uVar1;
  *(undefined4 *)(param_1 + 100) = uVar2;
  *(undefined4 *)(param_1 + 0x68) = uVar3;
  uVar1 = puVar4[5];
  uVar2 = puVar4[6];
  uVar3 = puVar4[7];
  *(undefined4 *)(param_1 + 0x6c) = puVar4[4];
  *(undefined4 *)(param_1 + 0x70) = uVar1;
  *(undefined4 *)(param_1 + 0x74) = uVar2;
  *(undefined4 *)(param_1 + 0x78) = uVar3;
  uVar1 = puVar4[9];
  uVar2 = puVar4[10];
  uVar3 = puVar4[0xb];
  *(undefined4 *)(param_1 + 0x7c) = puVar4[8];
  *(undefined4 *)(param_1 + 0x80) = uVar1;
  *(undefined4 *)(param_1 + 0x84) = uVar2;
  *(undefined4 *)(param_1 + 0x88) = uVar3;
  uVar1 = puVar4[0xd];
  uVar2 = puVar4[0xe];
  uVar3 = puVar4[0xf];
  *(undefined4 *)(param_1 + 0x8c) = puVar4[0xc];
  *(undefined4 *)(param_1 + 0x90) = uVar1;
  *(undefined4 *)(param_1 + 0x94) = uVar2;
  *(undefined4 *)(param_1 + 0x98) = uVar3;
  FUN_007cdc60();
  *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0x14);
  return;
}



/* FUNCTION 11885 ; VA 0x007cd5d0 ; FUN_007cd5d0 */

void __thiscall
FUN_007cd5d0(int param_1,float param_2,float param_3,float param_4,float param_5,char param_6,
            undefined4 param_7)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  undefined auStack_c4 [64];
  undefined auStack_84 [64];
  undefined auStack_44 [64];
  
  FUN_007cd4c0(auStack_84,param_7);
  fVar6 = 0.0;
  fVar7 = DAT_018ce2f8 / (param_5 - param_4);
  fVar5 = 0.0;
  if (param_6 != '\0') {
    fVar6 = DAT_018ce2f8 / param_2;
    fVar5 = DAT_018ce2f8 / param_3;
  }
  FUN_01165a00(DAT_018daf58 / param_2,0,0,DAT_018f7864 - fVar6,0,DAT_018daf58 / param_3,0,
               fVar5 - DAT_018ce2f8,0,0,fVar7,(uint)(fVar7 * param_4) ^ DAT_018c4ea0,0,0,0,
               0x3f800000);
  puVar4 = (undefined4 *)FUN_01165af0(auStack_c4,auStack_44);
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *(undefined4 *)(param_1 + 0x5c) = *puVar4;
  *(undefined4 *)(param_1 + 0x60) = uVar1;
  *(undefined4 *)(param_1 + 100) = uVar2;
  *(undefined4 *)(param_1 + 0x68) = uVar3;
  uVar1 = puVar4[5];
  uVar2 = puVar4[6];
  uVar3 = puVar4[7];
  *(undefined4 *)(param_1 + 0x6c) = puVar4[4];
  *(undefined4 *)(param_1 + 0x70) = uVar1;
  *(undefined4 *)(param_1 + 0x74) = uVar2;
  *(undefined4 *)(param_1 + 0x78) = uVar3;
  uVar1 = puVar4[9];
  uVar2 = puVar4[10];
  uVar3 = puVar4[0xb];
  *(undefined4 *)(param_1 + 0x7c) = puVar4[8];
  *(undefined4 *)(param_1 + 0x80) = uVar1;
  *(undefined4 *)(param_1 + 0x84) = uVar2;
  *(undefined4 *)(param_1 + 0x88) = uVar3;
  uVar1 = puVar4[0xd];
  uVar2 = puVar4[0xe];
  uVar3 = puVar4[0xf];
  *(undefined4 *)(param_1 + 0x8c) = puVar4[0xc];
  *(undefined4 *)(param_1 + 0x90) = uVar1;
  *(undefined4 *)(param_1 + 0x94) = uVar2;
  *(undefined4 *)(param_1 + 0x98) = uVar3;
  FUN_007cdc60();
  return;
}



/* FUNCTION 11886 ; VA 0x007cd720 ; FUN_007cd720 */

void __thiscall
FUN_007cd720(int param_1,float param_2,float param_3,float param_4,float param_5,float param_6,
            float param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  float fVar5;
  float fVar6;
  undefined auStack_c4 [64];
  undefined auStack_84 [64];
  undefined auStack_44 [64];
  
  FUN_007cd4c0(auStack_84,param_8);
  fVar5 = DAT_018daf58 / (param_2 + param_3);
  fVar6 = (float)((uint)(param_7 / (param_7 - param_6)) ^ DAT_018c4ea0);
  FUN_01165a00(DAT_018daf58 / (param_4 + param_5),0,(param_5 - param_4) / (param_4 + param_5),0,0,
               fVar5,(param_2 - param_3) / (param_2 + param_3),0,0,0,fVar6,fVar6 * param_6,0,0,
               &DAT_bf800000,0);
  puVar4 = (undefined4 *)FUN_01165af0(auStack_c4,auStack_44);
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *(undefined4 *)(param_1 + 0x5c) = *puVar4;
  *(undefined4 *)(param_1 + 0x60) = uVar1;
  *(undefined4 *)(param_1 + 100) = uVar2;
  *(undefined4 *)(param_1 + 0x68) = uVar3;
  uVar1 = puVar4[5];
  uVar2 = puVar4[6];
  uVar3 = puVar4[7];
  *(undefined4 *)(param_1 + 0x6c) = puVar4[4];
  *(undefined4 *)(param_1 + 0x70) = uVar1;
  *(undefined4 *)(param_1 + 0x74) = uVar2;
  *(undefined4 *)(param_1 + 0x78) = uVar3;
  uVar1 = puVar4[9];
  uVar2 = puVar4[10];
  uVar3 = puVar4[0xb];
  *(undefined4 *)(param_1 + 0x7c) = puVar4[8];
  *(undefined4 *)(param_1 + 0x80) = uVar1;
  *(undefined4 *)(param_1 + 0x84) = uVar2;
  *(undefined4 *)(param_1 + 0x88) = uVar3;
  uVar1 = puVar4[0xd];
  uVar2 = puVar4[0xe];
  uVar3 = puVar4[0xf];
  *(undefined4 *)(param_1 + 0x8c) = puVar4[0xc];
  *(undefined4 *)(param_1 + 0x90) = uVar1;
  *(undefined4 *)(param_1 + 0x94) = uVar2;
  *(undefined4 *)(param_1 + 0x98) = uVar3;
  FUN_007cdc60();
  *(float *)(param_1 + 0xc) = fVar5;
  return;
}



/* FUNCTION 11887 ; VA 0x007cd880 ; FUN_007cd880 */

void __thiscall
FUN_007cd880(int param_1,float param_2,float param_3,float param_4,float param_5,undefined4 param_6)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  double dVar5;
  float fVar6;
  float fVar7;
  undefined auStack_c4 [64];
  undefined auStack_84 [64];
  undefined auStack_44 [64];
  
  FUN_007cd4c0(auStack_84,param_6);
  dVar5 = (double)(param_2 * DAT_018ce2f4);
  FUN_01728120();
  fVar7 = DAT_018ce2f8 / (float)dVar5;
  fVar6 = (float)((uint)(param_5 / (param_5 - param_4)) ^ DAT_018c4ea0);
  FUN_01165a00(fVar7 / param_3,0,0,0,0,fVar7,0,0,0,0,fVar6,fVar6 * param_4,0,0,&DAT_bf800000,0);
  puVar4 = (undefined4 *)FUN_01165af0(auStack_c4,auStack_44);
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *(undefined4 *)(param_1 + 0x5c) = *puVar4;
  *(undefined4 *)(param_1 + 0x60) = uVar1;
  *(undefined4 *)(param_1 + 100) = uVar2;
  *(undefined4 *)(param_1 + 0x68) = uVar3;
  uVar1 = puVar4[5];
  uVar2 = puVar4[6];
  uVar3 = puVar4[7];
  *(undefined4 *)(param_1 + 0x6c) = puVar4[4];
  *(undefined4 *)(param_1 + 0x70) = uVar1;
  *(undefined4 *)(param_1 + 0x74) = uVar2;
  *(undefined4 *)(param_1 + 0x78) = uVar3;
  uVar1 = puVar4[9];
  uVar2 = puVar4[10];
  uVar3 = puVar4[0xb];
  *(undefined4 *)(param_1 + 0x7c) = puVar4[8];
  *(undefined4 *)(param_1 + 0x80) = uVar1;
  *(undefined4 *)(param_1 + 0x84) = uVar2;
  *(undefined4 *)(param_1 + 0x88) = uVar3;
  uVar1 = puVar4[0xd];
  uVar2 = puVar4[0xe];
  uVar3 = puVar4[0xf];
  *(undefined4 *)(param_1 + 0x8c) = puVar4[0xc];
  *(undefined4 *)(param_1 + 0x90) = uVar1;
  *(undefined4 *)(param_1 + 0x94) = uVar2;
  *(undefined4 *)(param_1 + 0x98) = uVar3;
  FUN_007cdc60();
  *(float *)(param_1 + 0xc) = fVar7;
  return;
}



/* FUNCTION 11888 ; VA 0x007cd9c0 ; FUN_007cd9c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_007cd9c0(undefined8 *param_1,int param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  uint *puVar7;
  undefined4 *puVar8;
  float *pfVar9;
  undefined auStack_c8 [64];
  undefined auStack_88 [36];
  undefined auStack_64 [36];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  float fStack_14;
  undefined auStack_10 [8];
  float fStack_8;
  
  *param_1 = *(undefined8 *)(param_2 + 0x24);
  *(undefined4 *)(param_1 + 1) = *(undefined4 *)(param_2 + 0x2c);
  puVar7 = (uint *)FUN_011612d0(auStack_10,2);
  uStack_24 = _UNK_018e3fbc;
  uStack_28 = _UNK_018e3fb8;
  uStack_2c = _UNK_018e3fb4;
  uStack_30 = _DAT_018e3fb0;
  fStack_8 = (float)(puVar7[2] ^ DAT_018c4ea0);
  uStack_40 = _DAT_018e3fb0;
  uStack_3c = _UNK_018e3fb4;
  uStack_38 = _UNK_018e3fb8;
  uStack_34 = _UNK_018e3fbc;
  param_1[2] = CONCAT44(puVar7[1] ^ DAT_018c4ea0,*puVar7 ^ DAT_018c4ea0);
  *(float *)(param_1 + 3) = fStack_8;
  uStack_20 = _DAT_018e3fb0;
  uStack_1c = CONCAT44(_UNK_018e3fb8,_UNK_018e3fb4);
  fStack_14 = (float)_UNK_018e3fbc;
  puVar8 = (undefined4 *)FUN_011630b0(auStack_64);
  uStack_40 = *puVar8;
  uStack_3c = puVar8[1];
  uStack_38 = puVar8[2];
  uStack_34 = puVar8[3];
  uStack_30 = puVar8[4];
  uStack_2c = puVar8[5];
  uStack_28 = puVar8[6];
  uStack_24 = puVar8[7];
  uStack_20 = puVar8[8];
  pfVar9 = (float *)FUN_01160de0(auStack_88);
  fVar1 = *(float *)(param_2 + 0x28);
  fVar2 = *(float *)(param_2 + 0x24);
  fVar3 = *(float *)(param_2 + 0x2c);
  uStack_1c = CONCAT44(pfVar9[3] * fVar2 + pfVar9[4] * fVar1 + pfVar9[5] * fVar3,
                       pfVar9[1] * fVar1 + *pfVar9 * fVar2 + pfVar9[2] * fVar3);
  fStack_14 = pfVar9[6] * fVar2 + pfVar9[7] * fVar1 + pfVar9[8] * fVar3;
  fStack_8 = fStack_14;
  puVar8 = (undefined4 *)FUN_011640a0(auStack_c8);
  uVar4 = puVar8[1];
  uVar5 = puVar8[2];
  uVar6 = puVar8[3];
  *(undefined4 *)((int)param_1 + 0x1c) = *puVar8;
  *(undefined4 *)(param_1 + 4) = uVar4;
  *(undefined4 *)((int)param_1 + 0x24) = uVar5;
  *(undefined4 *)(param_1 + 5) = uVar6;
  uVar4 = puVar8[5];
  uVar5 = puVar8[6];
  uVar6 = puVar8[7];
  *(undefined4 *)((int)param_1 + 0x2c) = puVar8[4];
  *(undefined4 *)(param_1 + 6) = uVar4;
  *(undefined4 *)((int)param_1 + 0x34) = uVar5;
  *(undefined4 *)(param_1 + 7) = uVar6;
  uVar4 = puVar8[9];
  uVar5 = puVar8[10];
  uVar6 = puVar8[0xb];
  *(undefined4 *)((int)param_1 + 0x3c) = puVar8[8];
  *(undefined4 *)(param_1 + 8) = uVar4;
  *(undefined4 *)((int)param_1 + 0x44) = uVar5;
  *(undefined4 *)(param_1 + 9) = uVar6;
  uVar4 = puVar8[0xd];
  uVar5 = puVar8[0xe];
  uVar6 = puVar8[0xf];
  *(undefined4 *)((int)param_1 + 0x4c) = puVar8[0xc];
  *(undefined4 *)(param_1 + 10) = uVar4;
  *(undefined4 *)((int)param_1 + 0x54) = uVar5;
  *(undefined4 *)(param_1 + 0xb) = uVar6;
  FUN_007cdc60();
  return;
}



/* FUNCTION 11889 ; VA 0x007cdb40 ; FUN_007cdb40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_007cdb40(undefined8 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined8 *puVar4;
  undefined auStack_70 [64];
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined auStack_10 [12];
  
  FUN_01165e00(auStack_70);
  uStack_20 = _DAT_018f99a0;
  uStack_1c = _UNK_018f99a4;
  uStack_18 = _UNK_018f99a8;
  uStack_14 = _UNK_018f99ac;
  FUN_01165b90(auStack_30,&uStack_20);
  puVar4 = (undefined8 *)FUN_011658d0(auStack_10);
  *param_1 = *puVar4;
  *(undefined4 *)(param_1 + 1) = *(undefined4 *)(puVar4 + 1);
  FUN_01165e00(auStack_70);
  uStack_20 = _DAT_018ffaf0;
  uStack_1c = _UNK_018ffaf4;
  uStack_18 = _UNK_018ffaf8;
  uStack_14 = _UNK_018ffafc;
  FUN_01165b90(auStack_30,&uStack_20);
  puVar4 = (undefined8 *)FUN_011658d0(auStack_10);
  param_1[2] = *puVar4;
  *(undefined4 *)(param_1 + 3) = *(undefined4 *)(puVar4 + 1);
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  *(undefined4 *)((int)param_1 + 0x1c) = *param_2;
  *(undefined4 *)(param_1 + 4) = uVar1;
  *(undefined4 *)((int)param_1 + 0x24) = uVar2;
  *(undefined4 *)(param_1 + 5) = uVar3;
  uVar1 = param_2[5];
  uVar2 = param_2[6];
  uVar3 = param_2[7];
  *(undefined4 *)((int)param_1 + 0x2c) = param_2[4];
  *(undefined4 *)(param_1 + 6) = uVar1;
  *(undefined4 *)((int)param_1 + 0x34) = uVar2;
  *(undefined4 *)(param_1 + 7) = uVar3;
  uVar1 = param_2[9];
  uVar2 = param_2[10];
  uVar3 = param_2[0xb];
  *(undefined4 *)((int)param_1 + 0x3c) = param_2[8];
  *(undefined4 *)(param_1 + 8) = uVar1;
  *(undefined4 *)((int)param_1 + 0x44) = uVar2;
  *(undefined4 *)(param_1 + 9) = uVar3;
  uVar1 = param_2[0xd];
  uVar2 = param_2[0xe];
  uVar3 = param_2[0xf];
  *(undefined4 *)((int)param_1 + 0x4c) = param_2[0xc];
  *(undefined4 *)(param_1 + 10) = uVar1;
  *(undefined4 *)((int)param_1 + 0x54) = uVar2;
  *(undefined4 *)(param_1 + 0xb) = uVar3;
  FUN_007cdc60();
  return;
}



/* FUNCTION 11890 ; VA 0x007cdc00 ; FUN_007cdc00 */

void __thiscall FUN_007cdc00(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  *(undefined4 *)(param_1 + 0x1c) = *param_2;
  *(undefined4 *)(param_1 + 0x20) = uVar1;
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  *(undefined4 *)(param_1 + 0x28) = uVar3;
  uVar1 = param_2[5];
  uVar2 = param_2[6];
  uVar3 = param_2[7];
  *(undefined4 *)(param_1 + 0x2c) = param_2[4];
  *(undefined4 *)(param_1 + 0x30) = uVar1;
  *(undefined4 *)(param_1 + 0x34) = uVar2;
  *(undefined4 *)(param_1 + 0x38) = uVar3;
  uVar1 = param_2[9];
  uVar2 = param_2[10];
  uVar3 = param_2[0xb];
  *(undefined4 *)(param_1 + 0x3c) = param_2[8];
  *(undefined4 *)(param_1 + 0x40) = uVar1;
  *(undefined4 *)(param_1 + 0x44) = uVar2;
  *(undefined4 *)(param_1 + 0x48) = uVar3;
  uVar1 = param_2[0xd];
  uVar2 = param_2[0xe];
  uVar3 = param_2[0xf];
  *(undefined4 *)(param_1 + 0x4c) = param_2[0xc];
  *(undefined4 *)(param_1 + 0x50) = uVar1;
  *(undefined4 *)(param_1 + 0x54) = uVar2;
  *(undefined4 *)(param_1 + 0x58) = uVar3;
  uVar1 = param_3[1];
  uVar2 = param_3[2];
  uVar3 = param_3[3];
  *(undefined4 *)(param_1 + 0x5c) = *param_3;
  *(undefined4 *)(param_1 + 0x60) = uVar1;
  *(undefined4 *)(param_1 + 100) = uVar2;
  *(undefined4 *)(param_1 + 0x68) = uVar3;
  uVar1 = param_3[5];
  uVar2 = param_3[6];
  uVar3 = param_3[7];
  *(undefined4 *)(param_1 + 0x6c) = param_3[4];
  *(undefined4 *)(param_1 + 0x70) = uVar1;
  *(undefined4 *)(param_1 + 0x74) = uVar2;
  *(undefined4 *)(param_1 + 0x78) = uVar3;
  uVar1 = param_3[9];
  uVar2 = param_3[10];
  uVar3 = param_3[0xb];
  *(undefined4 *)(param_1 + 0x7c) = param_3[8];
  *(undefined4 *)(param_1 + 0x80) = uVar1;
  *(undefined4 *)(param_1 + 0x84) = uVar2;
  *(undefined4 *)(param_1 + 0x88) = uVar3;
  uVar1 = param_3[0xd];
  uVar2 = param_3[0xe];
  uVar3 = param_3[0xf];
  *(undefined4 *)(param_1 + 0x8c) = param_3[0xc];
  *(undefined4 *)(param_1 + 0x90) = uVar1;
  *(undefined4 *)(param_1 + 0x94) = uVar2;
  *(undefined4 *)(param_1 + 0x98) = uVar3;
  FUN_007cdc60();
  return;
}



/* FUNCTION 11891 ; VA 0x007cdc60 ; FUN_007cdc60 */

void __fastcall FUN_007cdc60(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  float *pfVar6;
  float *pfVar7;
  int iVar8;
  double dVar9;
  uint uVar10;
  uint uVar11;
  float fStack_114;
  float fStack_110;
  float fStack_10c;
  float fStack_108;
  float fStack_104;
  float fStack_100;
  float fStack_fc;
  float fStack_f8;
  int iStack_f4;
  float fStack_f0;
  float fStack_ec;
  float fStack_e8;
  float fStack_e4;
  float fStack_d8;
  undefined auStack_c4 [8];
  undefined4 uStack_bc;
  float fStack_b8;
  float fStack_b4;
  float fStack_b0;
  float fStack_ac;
  undefined8 uStack_a8;
  undefined4 uStack_a0;
  undefined8 uStack_9c;
  undefined4 uStack_94;
  undefined auStack_90 [64];
  undefined auStack_50 [76];
  
  iStack_f4 = param_1;
  puVar5 = (undefined4 *)FUN_01165af0(auStack_50,param_1 + 0x1c);
  uVar1 = puVar5[1];
  uVar2 = puVar5[2];
  uVar3 = puVar5[3];
  *(undefined4 *)(param_1 + 0xdc) = *puVar5;
  *(undefined4 *)(param_1 + 0xe0) = uVar1;
  *(undefined4 *)(param_1 + 0xe4) = uVar2;
  *(undefined4 *)(param_1 + 0xe8) = uVar3;
  uVar1 = puVar5[5];
  uVar2 = puVar5[6];
  uVar3 = puVar5[7];
  *(undefined4 *)(param_1 + 0xec) = puVar5[4];
  *(undefined4 *)(param_1 + 0xf0) = uVar1;
  *(undefined4 *)(param_1 + 0xf4) = uVar2;
  *(undefined4 *)(param_1 + 0xf8) = uVar3;
  uVar1 = puVar5[9];
  uVar2 = puVar5[10];
  uVar3 = puVar5[0xb];
  *(undefined4 *)(param_1 + 0xfc) = puVar5[8];
  *(undefined4 *)(param_1 + 0x100) = uVar1;
  *(undefined4 *)(param_1 + 0x104) = uVar2;
  *(undefined4 *)(param_1 + 0x108) = uVar3;
  uVar1 = puVar5[0xd];
  uVar2 = puVar5[0xe];
  uVar3 = puVar5[0xf];
  *(undefined4 *)(param_1 + 0x10c) = puVar5[0xc];
  *(undefined4 *)(param_1 + 0x110) = uVar1;
  *(undefined4 *)(param_1 + 0x114) = uVar2;
  *(undefined4 *)(param_1 + 0x118) = uVar3;
  FUN_01165f10(2);
  pfVar6 = (float *)FUN_011658d0(auStack_c4);
  dVar9 = (double)(*pfVar6 * *pfVar6 + pfVar6[1] * pfVar6[1] + pfVar6[2] * pfVar6[2]);
  FUN_017267a0();
  FUN_01165820(&fStack_114,(float)dVar9);
  fStack_e4 = fStack_108;
  fStack_f0 = fStack_114;
  uVar10 = (uint)DAT_018c0da0;
  uVar11 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  fStack_ec = fStack_110;
  fStack_e8 = fStack_10c;
  fStack_d8 = (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_10c >> 0x20) & uVar11,
                                      SUB84((double)fStack_10c,0) & uVar10);
  *(float *)(iStack_f4 + 0x11c) = fStack_114;
  *(float *)(iStack_f4 + 0x120) = fStack_110;
  *(float *)(iStack_f4 + 0x124) = fStack_10c;
  *(float *)(iStack_f4 + 0x128) = fStack_108;
  *(ulonglong *)(iStack_f4 + 300) =
       CONCAT44((float)(double)CONCAT44((uint)((ulonglong)(double)fStack_110 >> 0x20) & uVar11,
                                        SUB84((double)fStack_110,0) & uVar10),
                (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_114 >> 0x20) & uVar11,
                                        SUB84((double)fStack_114,0) & uVar10));
  *(float *)(iStack_f4 + 0x134) = fStack_d8;
  pfVar6 = (float *)FUN_01165f10(3);
  pfVar7 = (float *)FUN_01165f10(2);
  fStack_110 = pfVar6[1] - pfVar7[1];
  fStack_10c = pfVar6[2] - pfVar7[2];
  fStack_108 = pfVar6[3] - pfVar7[3];
  fStack_114 = *pfVar6 - *pfVar7;
  pfVar6 = (float *)FUN_011658d0(auStack_c4);
  dVar9 = (double)(*pfVar6 * *pfVar6 + pfVar6[1] * pfVar6[1] + pfVar6[2] * pfVar6[2]);
  FUN_017267a0();
  FUN_01165820(&fStack_104,(float)dVar9);
  fStack_e4 = fStack_f8;
  fStack_f0 = fStack_104;
  uVar10 = (uint)DAT_018c0da0;
  uVar11 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  fStack_ec = fStack_100;
  fStack_e8 = fStack_fc;
  fStack_d8 = (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_fc >> 0x20) & uVar11,
                                      SUB84((double)fStack_fc,0) & uVar10);
  *(float *)(iStack_f4 + 0x138) = fStack_104;
  *(float *)(iStack_f4 + 0x13c) = fStack_100;
  *(float *)(iStack_f4 + 0x140) = fStack_fc;
  *(float *)(iStack_f4 + 0x144) = fStack_f8;
  *(ulonglong *)(iStack_f4 + 0x148) =
       CONCAT44((float)(double)CONCAT44((uint)((ulonglong)(double)fStack_100 >> 0x20) & uVar11,
                                        SUB84((double)fStack_100,0) & uVar10),
                (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_104 >> 0x20) & uVar11,
                                        SUB84((double)fStack_104,0) & uVar10));
  *(float *)(iStack_f4 + 0x150) = fStack_d8;
  pfVar6 = (float *)FUN_01165f10(3);
  pfVar7 = (float *)FUN_01165f10(0);
  fStack_110 = pfVar6[1] + pfVar7[1];
  fStack_10c = pfVar6[2] + pfVar7[2];
  fStack_108 = pfVar6[3] + pfVar7[3];
  fStack_114 = *pfVar7 + *pfVar6;
  pfVar6 = (float *)FUN_011658d0(auStack_c4);
  dVar9 = (double)(*pfVar6 * *pfVar6 + pfVar6[1] * pfVar6[1] + pfVar6[2] * pfVar6[2]);
  FUN_017267a0();
  FUN_01165820(&fStack_104,(float)dVar9);
  fStack_e4 = fStack_f8;
  fStack_f0 = fStack_104;
  uVar10 = (uint)DAT_018c0da0;
  uVar11 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  fStack_ec = fStack_100;
  fStack_e8 = fStack_fc;
  fStack_d8 = (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_fc >> 0x20) & uVar11,
                                      SUB84((double)fStack_fc,0) & uVar10);
  *(float *)(iStack_f4 + 0x154) = fStack_104;
  *(float *)(iStack_f4 + 0x158) = fStack_100;
  *(float *)(iStack_f4 + 0x15c) = fStack_fc;
  *(float *)(iStack_f4 + 0x160) = fStack_f8;
  *(ulonglong *)(iStack_f4 + 0x164) =
       CONCAT44((float)(double)CONCAT44((uint)((ulonglong)(double)fStack_100 >> 0x20) & uVar11,
                                        SUB84((double)fStack_100,0) & uVar10),
                (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_104 >> 0x20) & uVar11,
                                        SUB84((double)fStack_104,0) & uVar10));
  *(float *)(iStack_f4 + 0x16c) = fStack_d8;
  pfVar6 = (float *)FUN_01165f10(3);
  pfVar7 = (float *)FUN_01165f10(0);
  fStack_110 = pfVar6[1] - pfVar7[1];
  fStack_10c = pfVar6[2] - pfVar7[2];
  fStack_108 = pfVar6[3] - pfVar7[3];
  fStack_114 = *pfVar6 - *pfVar7;
  pfVar6 = (float *)FUN_011658d0(auStack_c4);
  dVar9 = (double)(*pfVar6 * *pfVar6 + pfVar6[1] * pfVar6[1] + pfVar6[2] * pfVar6[2]);
  FUN_017267a0();
  FUN_01165820(&fStack_104,(float)dVar9);
  fStack_e4 = fStack_f8;
  fStack_f0 = fStack_104;
  uVar10 = (uint)DAT_018c0da0;
  uVar11 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  fStack_ec = fStack_100;
  fStack_e8 = fStack_fc;
  fStack_d8 = (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_fc >> 0x20) & uVar11,
                                      SUB84((double)fStack_fc,0) & uVar10);
  *(float *)(iStack_f4 + 0x170) = fStack_104;
  *(float *)(iStack_f4 + 0x174) = fStack_100;
  *(float *)(iStack_f4 + 0x178) = fStack_fc;
  *(float *)(iStack_f4 + 0x17c) = fStack_f8;
  *(ulonglong *)(iStack_f4 + 0x180) =
       CONCAT44((float)(double)CONCAT44((uint)((ulonglong)(double)fStack_100 >> 0x20) & uVar11,
                                        SUB84((double)fStack_100,0) & uVar10),
                (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_104 >> 0x20) & uVar11,
                                        SUB84((double)fStack_104,0) & uVar10));
  *(float *)(iStack_f4 + 0x188) = fStack_d8;
  pfVar6 = (float *)FUN_01165f10(3);
  pfVar7 = (float *)FUN_01165f10(1);
  fStack_110 = pfVar6[1] + pfVar7[1];
  fStack_10c = pfVar6[2] + pfVar7[2];
  fStack_108 = pfVar6[3] + pfVar7[3];
  fStack_114 = *pfVar7 + *pfVar6;
  pfVar6 = (float *)FUN_011658d0(auStack_c4);
  dVar9 = (double)(*pfVar6 * *pfVar6 + pfVar6[1] * pfVar6[1] + pfVar6[2] * pfVar6[2]);
  FUN_017267a0();
  FUN_01165820(&fStack_104,(float)dVar9);
  fStack_e4 = fStack_f8;
  fStack_f0 = fStack_104;
  uVar10 = (uint)DAT_018c0da0;
  uVar11 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  fStack_ec = fStack_100;
  fStack_e8 = fStack_fc;
  fStack_d8 = (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_fc >> 0x20) & uVar11,
                                      SUB84((double)fStack_fc,0) & uVar10);
  *(float *)(iStack_f4 + 0x18c) = fStack_104;
  *(float *)(iStack_f4 + 400) = fStack_100;
  *(float *)(iStack_f4 + 0x194) = fStack_fc;
  *(float *)(iStack_f4 + 0x198) = fStack_f8;
  *(ulonglong *)(iStack_f4 + 0x19c) =
       CONCAT44((float)(double)CONCAT44((uint)((ulonglong)(double)fStack_100 >> 0x20) & uVar11,
                                        SUB84((double)fStack_100,0) & uVar10),
                (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_104 >> 0x20) & uVar11,
                                        SUB84((double)fStack_104,0) & uVar10));
  *(float *)(iStack_f4 + 0x1a4) = fStack_d8;
  pfVar6 = (float *)FUN_01165f10(3);
  pfVar7 = (float *)FUN_01165f10(1);
  fStack_110 = pfVar6[1] - pfVar7[1];
  fStack_10c = pfVar6[2] - pfVar7[2];
  fStack_108 = pfVar6[3] - pfVar7[3];
  fStack_114 = *pfVar6 - *pfVar7;
  pfVar6 = (float *)FUN_011658d0(auStack_c4);
  dVar9 = (double)(*pfVar6 * *pfVar6 + pfVar6[1] * pfVar6[1] + pfVar6[2] * pfVar6[2]);
  FUN_017267a0();
  FUN_01165820(&fStack_104,(float)dVar9);
  iVar4 = iStack_f4;
  fStack_e4 = fStack_f8;
  fStack_f0 = fStack_104;
  uVar10 = (uint)DAT_018c0da0;
  uVar11 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  fStack_ec = fStack_100;
  fStack_e8 = fStack_fc;
  fStack_d8 = (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_fc >> 0x20) & uVar11,
                                      SUB84((double)fStack_fc,0) & uVar10);
  *(float *)(iStack_f4 + 0x1a8) = fStack_104;
  *(float *)(iStack_f4 + 0x1ac) = fStack_100;
  *(float *)(iStack_f4 + 0x1b0) = fStack_fc;
  *(float *)(iStack_f4 + 0x1b4) = fStack_f8;
  *(ulonglong *)(iStack_f4 + 0x1b8) =
       CONCAT44((float)(double)CONCAT44((uint)((ulonglong)(double)fStack_100 >> 0x20) & uVar11,
                                        SUB84((double)fStack_100,0) & uVar10),
                (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_104 >> 0x20) & uVar11,
                                        SUB84((double)fStack_104,0) & uVar10));
  *(float *)(iStack_f4 + 0x1c0) = fStack_d8;
  FUN_01165e00(auStack_90);
  uStack_bc = 0x3f800000;
  iVar8 = 0;
  uStack_a8 = CONCAT44(DAT_018f7864,DAT_018f7864);
  fStack_10c = 0.0;
  uStack_a0 = 0;
  uStack_9c = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  uStack_94 = 0x3f800000;
  fStack_ac = 1.0;
  pfVar6 = (float *)(iVar4 + 0x1c4);
  do {
    pfVar7 = (float *)FUN_00c9f1c0(auStack_c4,iVar8);
    fStack_104 = *pfVar7;
    fStack_100 = pfVar7[1];
    fStack_fc = pfVar7[2];
    fStack_f8 = 1.0;
    FUN_01165b90(&fStack_f0,&fStack_104);
    pfVar7 = (float *)FUN_011658d0(&fStack_114);
    fStack_b0 = DAT_018ce2f8 / fStack_e4;
    iVar8 = iVar8 + 1;
    fStack_b8 = fStack_b0 * *pfVar7;
    fStack_b4 = pfVar7[1] * fStack_b0;
    fStack_b0 = pfVar7[2] * fStack_b0;
    *pfVar6 = fStack_b8;
    pfVar6[1] = fStack_b4;
    pfVar6[2] = fStack_b0;
    pfVar6[3] = fStack_ac;
    pfVar6 = pfVar6 + 4;
  } while (iVar8 < 8);
  return;
}



/* FUNCTION 11892 ; VA 0x007ce460 ; FUN_007ce460 */

void __thiscall FUN_007ce460(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined auStack_68 [36];
  undefined auStack_44 [36];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined auStack_10 [12];
  
  FUN_01165f80(auStack_68);
  FUN_011630b0(auStack_44);
  uVar1 = param_2[0x38];
  uVar2 = param_2[0x39];
  uVar3 = param_2[0x3a];
  *param_1 = param_2[0x37];
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  uVar1 = param_2[0x3c];
  uVar2 = param_2[0x3d];
  uVar3 = param_2[0x3e];
  param_1[4] = param_2[0x3b];
  param_1[5] = uVar1;
  param_1[6] = uVar2;
  param_1[7] = uVar3;
  uVar1 = param_2[0x40];
  uVar2 = param_2[0x41];
  uVar3 = param_2[0x42];
  param_1[8] = param_2[0x3f];
  param_1[9] = uVar1;
  param_1[10] = uVar2;
  param_1[0xb] = uVar3;
  uVar1 = param_2[0x44];
  uVar2 = param_2[0x45];
  uVar3 = param_2[0x46];
  param_1[0xc] = param_2[0x43];
  param_1[0xd] = uVar1;
  param_1[0xe] = uVar2;
  param_1[0xf] = uVar3;
  puVar4 = (undefined4 *)FUN_011612d0(auStack_10,0);
  uStack_14 = 0;
  uStack_20 = *puVar4;
  uStack_1c = puVar4[1];
  uStack_18 = puVar4[2];
  param_1[0x10] = uStack_20;
  param_1[0x11] = uStack_1c;
  param_1[0x12] = uStack_18;
  param_1[0x13] = 0;
  puVar4 = (undefined4 *)FUN_011612d0(auStack_10,1);
  uStack_14 = 0;
  uStack_20 = *puVar4;
  uStack_1c = puVar4[1];
  uStack_18 = puVar4[2];
  param_1[0x14] = uStack_20;
  param_1[0x15] = uStack_1c;
  param_1[0x16] = uStack_18;
  param_1[0x17] = 0;
  puVar4 = (undefined4 *)FUN_011612d0(auStack_10,2);
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  param_1[0x18] = *puVar4;
  param_1[0x19] = uVar1;
  param_1[0x1a] = uVar2;
  param_1[0x1b] = 0;
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  param_1[0x1c] = *param_2;
  param_1[0x1d] = uVar1;
  param_1[0x1e] = uVar2;
  param_1[0x1f] = 0x3f800000;
  return;
}



/* FUNCTION 11893 ; VA 0x007ce5a0 ; FUN_007ce5a0 */

undefined4 * __thiscall FUN_007ce5a0(undefined4 *param_1,undefined4 param_2)

{
  *param_1 = 0;
  param_1[1] = 0;
  FUN_007ce650(param_2,param_2);
  return param_1;
}



/* FUNCTION 11894 ; VA 0x007ce5d0 ; FUN_007ce5d0 */

int * __thiscall FUN_007ce5d0(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  int iVar5;
  
  puVar4 = (undefined4 *)0x0;
  iVar2 = *param_2;
  iVar5 = 0;
  if (iVar2 != 0) {
    puVar4 = (undefined4 *)FUN_01674e20(0x10);
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      puVar4[1] = 1;
      puVar4[2] = 1;
      *puVar4 = std::
                _Ref_count_resource<struct_RBX::Graphics::ColorBlock*,struct_std::default_delete<struct_RBX::Graphics::ColorBlock>_>
                ::vftable;
      puVar4[3] = iVar2;
    }
    *param_2 = 0;
    iVar5 = iVar2;
  }
  *param_1 = iVar5;
  piVar3 = (int *)param_1[1];
  param_1[1] = (int)puVar4;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 11895 ; VA 0x007ce650 ; FUN_007ce650 */

void __thiscall FUN_007ce650(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b3940;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Graphics::Image>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11896 ; VA 0x007ce6be ; Catch_All@007ce6be */

void Catch_All_007ce6be(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_007cf6c0(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11897 ; VA 0x007ce6e0 ; FUN_007ce6e0 */

undefined4 * __thiscall FUN_007ce6e0(undefined4 *param_1,int param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795d48;
  pvStack_10 = ExceptionList;
  puVar1 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar1 = (undefined4 *)*param_1;
  }
  iStack_18 = param_1[4];
  iStack_1c = (int)puVar1 + iStack_18;
  puStack_14 = param_1;
  if (0xf < (uint)param_1[5]) {
    puStack_14 = (undefined4 *)*param_1;
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  apppuStack_34[0] = (undefined4 ***)((uint)apppuStack_34[0] & 0xffffff00);
  ExceptionList = &pvStack_10;
  FUN_0058a190(param_3 - param_2);
  FUN_0064be90(param_2,param_3,param_3);
  uStack_8 = 0;
  puVar1 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar1 = (undefined4 *)*param_1;
  }
  ppppuVar2 = apppuStack_34;
  if (0xf < uStack_20) {
    ppppuVar2 = (undefined4 ****)apppuStack_34[0];
  }
  FUN_00591430((iStack_18 + (int)puStack_14) - (int)puVar1,iStack_1c - (iStack_18 + (int)puStack_14)
               ,ppppuVar2,uStack_24);
  if (0xf < uStack_20) {
    uVar3 = uStack_20 + 1;
    ppppuVar2 = (undefined4 ****)apppuStack_34[0];
    if (0xfff < uVar3) {
      ppppuVar2 = (undefined4 ****)apppuStack_34[0][-1];
      uVar3 = uStack_20 + 0x24;
      if (0x1f < (uint)((int)apppuStack_34[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11898 ; VA 0x007ce7e0 ; FUN_007ce7e0 */

undefined4 * FUN_007ce7e0(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b397c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[10] = &DAT_01900424;
  param_1[0xc] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::_System_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = std::ios_base::failure::vftable;
  puVar1 = param_1 + 5;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x18);
  param_1[6] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  param_1[8] = *(undefined4 *)(param_2 + 0x20);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_std::ios_base::failure>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<struct_boost::exception_detail::error_info_injector<class_std::ios_base::failure>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_std::ios_base::failure>_>
       ::vftable;
  *(int *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = *(int *)(param_1[10] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0x14);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11899 ; VA 0x007ce8e0 ; FUN_007ce8e0 */

undefined4 * FUN_007ce8e0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::_System_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  param_1[5] = boost::exception::vftable;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0xffffffff;
  *param_1 = boost::exception_detail::error_info_injector<class_std::ios_base::failure>::vftable;
  param_1[5] = boost::exception_detail::error_info_injector<class_std::ios_base::failure>::vftable;
  return param_1;
}



/* FUNCTION 11900 ; VA 0x007ce950 ; FUN_007ce950 */

undefined4 FUN_007ce950(int *param_1,int param_2,int *param_3,int param_4)

{
  uint uVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b3990;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if ((param_2 == 1) && (ExceptionList = &pvStack_10, (param_1[0xe] & 2U) == 0)) {
    ExceptionList = &pvStack_10;
    param_1[0xe] = param_1[0xe] | 2;
    (**(code **)(*param_1 + 0x40))(1);
  }
  if ((param_2 == 2) && ((param_1[0xe] & 4U) == 0)) {
    param_1[0xe] = param_1[0xe] | 4;
    (**(code **)(*param_1 + 0x40))(2);
  }
  uStack_8 = 0xffffffff;
  if (param_4 == 1) {
    if ((param_3[0xe] & 2U) != 0) {
      ExceptionList = pvStack_10;
      return 0;
    }
    uVar1 = param_3[0xe] | 2;
    uVar2 = 1;
  }
  else {
    if (param_4 != 2) {
      ExceptionList = pvStack_10;
      return 0;
    }
    if ((param_3[0xe] & 4U) != 0) {
      ExceptionList = pvStack_10;
      return 0;
    }
    uVar1 = param_3[0xe] | 4;
    uVar2 = 2;
  }
  param_3[0xe] = uVar1;
  (**(code **)(*param_3 + 0x40))(uVar2);
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 11901 ; VA 0x007ce9d0 ; Catch_All@007ce9d0 */

undefined4 Catch_All_007ce9d0(void)

{
  return 0x7cea11;
}



/* FUNCTION 11902 ; VA 0x007cea02 ; Catch_All@007cea02 */

void Catch_All_007cea02(void)

{
  int unaff_EBP;
  
  *(BADSPACEBASE **)(unaff_EBP + -0x10) = register0x00000010;
  *(undefined *)(unaff_EBP + -4) = 2;
  FUN_007cf3e0();
  *(undefined4 *)(unaff_EBP + -4) = 1;
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11903 ; VA 0x007cea30 ; FUN_007cea30 */

void FUN_007cea30(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 int param_5)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b39a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_007ce950(param_1,param_2,param_3,param_4);
  if (*(char *)(param_5 + 8) != '\0') {
    *(undefined *)(param_5 + 8) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11904 ; VA 0x007cea88 ; Catch_All@007cea88 */

void Catch_All_007cea88(void)

{
  int unaff_EBP;
  
  *(BADSPACEBASE **)(unaff_EBP + -0x10) = register0x00000010;
  FUN_007cf420();
  *(undefined4 *)(unaff_EBP + -4) = 1;
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11905 ; VA 0x007ceab0 ; FUN_007ceab0 */

void FUN_007ceab0(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_6c [52];
  undefined auStack_38 [40];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b39b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_007ce8e0(auStack_38,param_1);
  uStack_8 = 0;
  FUN_007ce7e0(auStack_6c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_6c,&DAT_01c46e90);
}



/* FUNCTION 11906 ; VA 0x007ceb00 ; FUN_007ceb00 */

undefined4 * __thiscall FUN_007ceb00(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793fb4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[10] = &DAT_01900424;
    param_1[0xc] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::_System_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = std::ios_base::failure::vftable;
  param_1[5] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x18);
  uStack_8 = 1;
  param_1[6] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  param_1[8] = *(undefined4 *)(param_2 + 0x20);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_std::ios_base::failure>_>
             ::vftable;
  param_1[5] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_std::ios_base::failure>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_std::ios_base::failure>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11907 ; VA 0x007cebf0 ; FUN_007cebf0 */

undefined4 * __thiscall FUN_007cebf0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794218;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::_System_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = std::ios_base::failure::vftable;
  param_1[5] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x18);
  uStack_8 = 0;
  param_1[6] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  param_1[8] = *(undefined4 *)(param_2 + 0x20);
  param_1[9] = *(undefined4 *)(param_2 + 0x24);
  *param_1 = boost::exception_detail::error_info_injector<class_std::ios_base::failure>::vftable;
  param_1[5] = boost::exception_detail::error_info_injector<class_std::ios_base::failure>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11908 ; VA 0x007ceca0 ; FUN_007ceca0 */

undefined4 * __thiscall FUN_007ceca0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  undefined uVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  int *piVar7;
  undefined4 *puVar8;
  bool bVar9;
  undefined auStack_24 [4];
  int *piStack_20;
  int *piStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b39fc;
  pvStack_10 = ExceptionList;
  bVar9 = param_2 != 0;
  ExceptionList = &pvStack_10;
  if (bVar9) {
    ExceptionList = &pvStack_10;
    param_1[0x18] = &PTR_0190039c;
    param_1[0x1e] = std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
    uStack_8 = 0;
  }
  uStack_14 = (uint)bVar9;
  *param_1 = std::basic_streambuf<char,struct_std::char_traits<char>_>::vftable;
  puStack_18 = param_1;
  iVar4 = FUN_01674e20(8);
  if (iVar4 == 0) {
    iVar4 = 0;
  }
  else {
    uStack_8 = 1;
    uVar5 = FUN_016de181(1);
    *(undefined4 *)(iVar4 + 4) = uVar5;
  }
  param_1[0xd] = iVar4;
  param_1[3] = param_1 + 1;
  param_1[4] = param_1 + 2;
  param_1[7] = param_1 + 5;
  param_1[8] = param_1 + 6;
  param_1[0xb] = param_1 + 9;
  param_1[0xc] = param_1 + 10;
  param_1[2] = 0;
  *(undefined4 *)param_1[8] = 0;
  *(undefined4 *)param_1[0xc] = 0;
  *(undefined4 *)param_1[3] = 0;
  *(undefined4 *)param_1[7] = 0;
  *(undefined4 *)param_1[0xb] = 0;
  param_1[0xe] = 0;
  *(undefined *)(param_1 + 0x11) = 0;
  param_1[0xe] = param_1[0xe] | 1;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  *(undefined *)(param_1 + 0x16) = 1;
  *param_1 = boost::iostreams::
             stream_buffer<struct_boost::iostreams::basic_array_source<char>,struct_std::char_traits<char>,class_std::allocator<char>,struct_boost::iostreams::input_seekable>
             ::vftable;
  piVar1 = param_1 + 0x18;
  uStack_8 = 2;
  *(undefined ***)((int)piVar1 + *(int *)(param_1[0x18] + 4)) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*piVar1 + 4) + -4 + (int)piVar1) = *(int *)(*piVar1 + 4) + -0x18;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  iVar4 = *(int *)(*piVar1 + 4);
  *(undefined4 *)((int)piVar1 + iVar4 + 0x30) = 0;
  *(undefined4 *)((int)piVar1 + iVar4 + 8) = 0;
  *(undefined4 *)((int)piVar1 + iVar4 + 0x10) = 0;
  *(undefined4 *)((int)piVar1 + iVar4 + 0x14) = 0x201;
  *(undefined4 *)((int)piVar1 + iVar4 + 0x18) = 6;
  *(undefined4 *)((int)piVar1 + iVar4 + 0x1c) = 0;
  *(undefined4 *)((int)piVar1 + iVar4 + 0x20) = 0;
  *(undefined4 *)((int)piVar1 + iVar4 + 0x24) = 0;
  *(undefined4 *)((int)piVar1 + iVar4 + 0x28) = 0;
  *(undefined4 *)((int)piVar1 + iVar4 + 0x2c) = 0;
  *(undefined4 *)((int)piVar1 + iVar4 + 0xc) = 0;
  piStack_1c = piVar1;
  iVar6 = FUN_01674e20(8);
  if (iVar6 == 0) {
    iVar6 = 0;
  }
  else {
    uStack_8 = 4;
    uVar5 = FUN_016de181(1);
    *(undefined4 *)(iVar6 + 4) = uVar5;
  }
  *(int *)((int)piVar1 + iVar4 + 0x30) = iVar6;
  *(undefined4 **)((int)piVar1 + iVar4 + 0x38) = param_1;
  *(undefined4 *)((int)piVar1 + iVar4 + 0x3c) = 0;
  piVar2 = *(int **)(iVar6 + 4);
  uStack_8 = 5;
  piStack_20 = piVar2;
  (**(code **)(*piVar2 + 4))();
  uStack_14 = bVar9 | 4;
  uStack_8 = 6;
  piVar7 = (int *)FUN_0054e7d0(auStack_24);
  uVar3 = (**(code **)(*piVar7 + 0x20))(0x20);
  uStack_8 = 7;
  if (piVar2 != (int *)0x0) {
    puVar8 = (undefined4 *)(**(code **)(*piVar2 + 8))();
    if (puVar8 != (undefined4 *)0x0) {
      (**(code **)*puVar8)(1);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  *(undefined *)((int)piVar1 + iVar4 + 0x40) = uVar3;
  if (*(int *)((int)piVar1 + iVar4 + 0x38) == 0) {
    FUN_00554460(*(uint *)((int)piVar1 + iVar4 + 0xc) | 4,0);
  }
  *(undefined ***)(*(int *)(param_1[0x18] + 4) + 0x60 + (int)param_1) =
       boost::iostreams::detail::
       stream_base<struct_boost::iostreams::basic_array_source<char>,struct_std::char_traits<char>,class_std::allocator<char>,class_std::basic_istream<char,struct_std::char_traits<char>_>_>
       ::vftable;
  *(int *)(*(int *)(param_1[0x18] + 4) + 0x5c + (int)param_1) = *(int *)(param_1[0x18] + 4) + -0x18;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11909 ; VA 0x007cef10 ; FUN_007cef10 */

int * __thiscall
FUN_007cef10(int *param_1,uint param_2,int param_3,int param_4,int param_5,int param_6,uint param_7,
            int param_8)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b3a26;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[1] = param_3;
  param_1[2] = param_4;
  param_1[3] = param_5;
  param_1[4] = param_6;
  param_1[5] = param_7;
  *param_1 = param_2;
  param_1[6] = param_8;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  uStack_8 = 1;
  iVar9 = 1;
  if (param_2 == 2) {
    iVar9 = 6;
  }
  iVar9 = iVar9 * param_8;
  uVar2 = param_1[9] - param_1[7] >> 2;
  uVar7 = iVar9 * param_7;
  if (uVar2 <= uVar7 && uVar7 - uVar2 != 0) {
    if (0x3fffffff < uVar7) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_007cfd20(uVar7);
  }
  iVar8 = 0;
  param_8 = 0;
  for (; iVar9 != 0; iVar9 = iVar9 + -1) {
    param_2 = 0;
    if (param_7 != 0) {
      do {
        piVar1 = (int *)param_1[8];
        if ((int *)param_1[9] == piVar1) {
          FUN_00595d30(piVar1,&param_8);
          iVar8 = param_8;
        }
        else {
          *piVar1 = iVar8;
          param_1[8] = param_1[8] + 4;
        }
        uVar3 = FUN_0147d110(param_5,param_2);
        uVar4 = FUN_0147d110(param_4,param_2);
        iVar5 = FUN_0147d000(param_3,uVar4,uVar3);
        iVar6 = FUN_0147d110(param_6,param_2);
        iVar8 = iVar8 + iVar5 * iVar6;
        param_2 = param_2 + 1;
        param_8 = iVar8;
      } while (param_2 < param_7);
    }
  }
  iVar5 = FUN_01674e20(iVar8);
  iVar9 = param_1[10];
  param_1[10] = iVar5;
  FUN_01674ea0(iVar9);
  param_1[0xb] = iVar8;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11910 ; VA 0x007cf090 ; FUN_007cf090 */

undefined4 * __thiscall FUN_007cf090(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = *param_3;
  param_1[3] = param_3[1];
  param_1[4] = param_3[2];
  *(undefined *)(param_1 + 5) = *(undefined *)(param_3 + 3);
  param_1[6] = 0;
  param_1[7] = 0;
  if (param_3[5] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[5] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[6] = param_3[4];
  param_1[7] = param_3[5];
  return param_1;
}



/* FUNCTION 11911 ; VA 0x007cf110 ; thunk_FUN_007cf230 */

void __fastcall thunk_FUN_007cf230(undefined4 *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b3a38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::iostreams::
             stream_buffer<struct_boost::iostreams::basic_array_source<char>,struct_std::char_traits<char>,class_std::allocator<char>,struct_boost::iostreams::input_seekable>
             ::vftable;
  uStack_8 = 1;
  if (((param_1[0x12] != 0) || (param_1[0x14] != 0)) && (*(char *)(param_1 + 0x16) != '\0')) {
    FUN_007cea30(param_1,1,param_1,2,param_1 + 0xf);
    FUN_007cf296();
    return;
  }
  if (*(char *)(param_1 + 0x11) != '\0') {
    *(undefined *)(param_1 + 0x11) = 0;
  }
  *param_1 = std::basic_streambuf<char,struct_std::char_traits<char>_>::vftable;
  iVar1 = param_1[0xd];
  if (iVar1 != 0) {
    uStack_8 = 3;
    if (*(int **)(iVar1 + 4) != (int *)0x0) {
      puVar2 = (undefined4 *)(**(code **)(**(int **)(iVar1 + 4) + 8))();
      if (puVar2 != (undefined4 *)0x0) {
        (**(code **)*puVar2)(1);
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11912 ; VA 0x007cf120 ; FUN_007cf120 */

void __fastcall FUN_007cf120(undefined4 *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(char *)(param_1 + 0x11) != '\0') {
    ExceptionList = &pvStack_10;
    *(undefined *)(param_1 + 0x11) = 0;
  }
  iVar1 = param_1[0xd];
  *param_1 = std::basic_streambuf<char,struct_std::char_traits<char>_>::vftable;
  if (iVar1 != 0) {
    uStack_8 = 0;
    if (*(int **)(iVar1 + 4) != (int *)0x0) {
      puVar2 = (undefined4 *)(**(code **)(**(int **)(iVar1 + 4) + 8))();
      if (puVar2 != (undefined4 *)0x0) {
        (**(code **)*puVar2)(1);
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11913 ; VA 0x007cf190 ; FUN_007cf190 */

void __fastcall FUN_007cf190(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_std::ios_base::failure>::vftable;
  param_1[5] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[6] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[6] + 0x10))();
    if (cVar1 != '\0') {
      param_1[6] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11914 ; VA 0x007cf200 ; FUN_007cf200 */

void __fastcall FUN_007cf200(int param_1)

{
  int iVar1;
  
  *(undefined ***)(*(int *)(*(int *)(param_1 + -0x18) + 4) + -0x18 + param_1) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  iVar1 = *(int *)(*(int *)(param_1 + -0x18) + 4);
  *(int *)(iVar1 + -0x1c + param_1) = iVar1 + -0x18;
  FUN_007cf230();
  return;
}



/* FUNCTION 11915 ; VA 0x007cf230 ; FUN_007cf230 */

void __fastcall FUN_007cf230(undefined4 *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b3a38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::iostreams::
             stream_buffer<struct_boost::iostreams::basic_array_source<char>,struct_std::char_traits<char>,class_std::allocator<char>,struct_boost::iostreams::input_seekable>
             ::vftable;
  uStack_8 = 1;
  if (((param_1[0x12] != 0) || (param_1[0x14] != 0)) && (*(char *)(param_1 + 0x16) != '\0')) {
    FUN_007cea30(param_1,1,param_1,2,param_1 + 0xf);
    FUN_007cf296();
    return;
  }
  if (*(char *)(param_1 + 0x11) != '\0') {
    *(undefined *)(param_1 + 0x11) = 0;
  }
  *param_1 = std::basic_streambuf<char,struct_std::char_traits<char>_>::vftable;
  iVar1 = param_1[0xd];
  if (iVar1 != 0) {
    uStack_8 = 3;
    if (*(int **)(iVar1 + 4) != (int *)0x0) {
      puVar2 = (undefined4 *)(**(code **)(**(int **)(iVar1 + 4) + 8))();
      if (puVar2 != (undefined4 *)0x0) {
        (**(code **)*puVar2)(1);
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11916 ; VA 0x007cf28d ; Catch_All@007cf28d */

undefined * Catch_All_007cf28d(void)

{
  return &DAT_007cf293;
}



/* FUNCTION 11917 ; VA 0x007cf296 ; FUN_007cf296 */

void FUN_007cf296(void)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  int unaff_EBP;
  undefined4 *unaff_ESI;
  
  cVar1 = *(char *)(unaff_ESI + 0x11);
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  if (cVar1 != '\0') {
    *(undefined *)(unaff_ESI + 0x11) = 0;
  }
  *unaff_ESI = std::basic_streambuf<char,struct_std::char_traits<char>_>::vftable;
  iVar2 = unaff_ESI[0xd];
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    *(undefined4 *)(unaff_EBP + -4) = 3;
    if (piVar3 != (int *)0x0) {
      puVar4 = (undefined4 *)(**(code **)(*piVar3 + 8))();
      if (puVar4 != (undefined4 *)0x0) {
        (**(code **)*puVar4)(1);
      }
    }
    FUN_01674ea0(iVar2,8);
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 11918 ; VA 0x007cf300 ; FUN_007cf300 */

void __fastcall FUN_007cf300(int *param_1)

{
  if (*param_1 != 0) {
    FUN_01674ea0(*param_1,0x48);
  }
  return;
}



/* FUNCTION 11919 ; VA 0x007cf320 ; FUN_007cf320 */

undefined4 * __thiscall FUN_007cf320(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  
  uVar2 = *param_2;
  uVar3 = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  *param_1 = uVar2;
  piVar4 = (int *)param_1[1];
  param_1[1] = uVar3;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar5 = piVar4[1] + -1;
    piVar4[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar5 = piVar4[2] + -1;
      piVar4[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  *(undefined *)(param_1 + 5) = *(undefined *)(param_2 + 5);
  uVar2 = param_2[6];
  uVar3 = param_2[7];
  param_2[6] = 0;
  param_2[7] = 0;
  param_1[6] = uVar2;
  piVar4 = (int *)param_1[7];
  param_1[7] = uVar3;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar5 = piVar4[1] + -1;
    piVar4[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 11920 ; VA 0x007cf3e0 ; FUN_007cf3e0 */

void __fastcall FUN_007cf3e0(int *param_1)

{
  int *piVar1;
  
  piVar1 = (int *)*param_1;
  if (param_1[1] == 1) {
    if ((piVar1[0xe] & 2U) == 0) {
      piVar1[0xe] = piVar1[0xe] | 2;
      (**(code **)(*piVar1 + 0x40))(1);
      return;
    }
  }
  else if ((param_1[1] == 2) && ((piVar1[0xe] & 4U) == 0)) {
    piVar1[0xe] = piVar1[0xe] | 4;
    (**(code **)(*piVar1 + 0x40))(2);
  }
  return;
}



/* FUNCTION 11921 ; VA 0x007cf420 ; FUN_007cf420 */

void __fastcall FUN_007cf420(int *param_1)

{
  if (*(char *)(*param_1 + 8) != '\0') {
    *(undefined *)(*param_1 + 8) = 0;
  }
  return;
}



/* FUNCTION 11922 ; VA 0x007cf430 ; FUN_007cf430 */

void __fastcall FUN_007cf430(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_std::ios_base::failure>_>
             ::vftable;
  param_1[5] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_std::ios_base::failure>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_std::ios_base::failure>_>
       ::vftable;
  *(int *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = *(int *)(param_1[10] + 4) + -8;
  *param_1 = boost::exception_detail::error_info_injector<class_std::ios_base::failure>::vftable;
  param_1[5] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[6] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[6] + 0x10))();
    if (cVar1 != '\0') {
      param_1[6] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[0xc] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11923 ; VA 0x007cf4d0 ; FUN_007cf4d0 */

void __fastcall FUN_007cf4d0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  puVar1 = (undefined4 *)(param_1 + 0x78);
  ExceptionList = &pvStack_10;
  *(undefined ***)(*(int *)(*(int *)(param_1 + 0x60) + 4) + -0x18 + (int)puVar1) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  iVar2 = *(int *)(*(int *)(param_1 + 0x60) + 4);
  *(int *)(iVar2 + -0x1c + (int)puVar1) = iVar2 + -0x18;
  FUN_007cf230();
  uStack_8 = 0;
  *puVar1 = std::ios_base::vftable;
  FUN_016de551(puVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11924 ; VA 0x007cf531 ; FUN_007cf531 */

void FUN_007cf531(void)

{
  FUN_007cf560();
  return;
}



/* FUNCTION 11925 ; VA 0x007cf53c ; FUN_007cf53c */

void FUN_007cf53c(void)

{
  FUN_007cf560();
  return;
}



/* FUNCTION 11926 ; VA 0x007cf544 ; FUN_007cf544 */

void FUN_007cf544(void)

{
  FUN_007cf590();
  return;
}



/* FUNCTION 11927 ; VA 0x007cf54c ; FUN_007cf54c */

void FUN_007cf54c(void)

{
  FUN_007cf610();
  return;
}



/* FUNCTION 11928 ; VA 0x007cf560 ; FUN_007cf560 */

undefined4 __thiscall FUN_007cf560(undefined4 param_1,byte param_2)

{
  FUN_007cf430();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x34);
  }
  return param_1;
}



/* FUNCTION 11929 ; VA 0x007cf590 ; FUN_007cf590 */

undefined4 * __thiscall FUN_007cf590(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_std::ios_base::failure>::vftable;
  param_1[5] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[6] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[6] + 0x10))();
    if (cVar1 != '\0') {
      param_1[6] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11930 ; VA 0x007cf610 ; FUN_007cf610 */

undefined4 * __thiscall FUN_007cf610(undefined4 *param_1,byte param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined ***)(*(int *)(param_1[-6] + 4) + -0x18 + (int)param_1) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(param_1[-6] + 4) + -0x1c + (int)param_1) = *(int *)(param_1[-6] + 4) + -0x18;
  FUN_007cf230();
  uStack_8 = 0;
  *param_1 = std::ios_base::vftable;
  FUN_016de551(param_1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1 + -0x1e,0xc0);
  }
  ExceptionList = pvStack_10;
  return param_1 + -0x1e;
}



/* FUNCTION 11931 ; VA 0x007cf690 ; FUN_007cf690 */

undefined4 __thiscall FUN_007cf690(undefined4 param_1,byte param_2)

{
  FUN_007cf230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x5c);
  }
  return param_1;
}



/* FUNCTION 11932 ; VA 0x007cf6c0 ; FUN_007cf6c0 */

int __thiscall FUN_007cf6c0(int param_1,byte param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x28));
  iVar1 = *(int *)(param_1 + 0x1c);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x24) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x1c) = 0;
    *(undefined4 *)(param_1 + 0x20) = 0;
    *(undefined4 *)(param_1 + 0x24) = 0;
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x30);
  }
  return param_1;
}



/* FUNCTION 11933 ; VA 0x007cf740 ; FUN_007cf740 */

void FUN_007cf740(int param_1,byte *param_2)

{
  byte bVar1;
  
  bVar1 = *param_2;
  *(byte *)(param_1 + 3) = (bVar1 & 0xf) << 4 | bVar1 & 0xf;
  *(byte *)(param_1 + 7) = bVar1 >> 4 | bVar1 & 0xf0;
  bVar1 = param_2[1];
  *(byte *)(param_1 + 0xb) = (bVar1 & 0xf) << 4 | bVar1 & 0xf;
  *(byte *)(param_1 + 0xf) = bVar1 >> 4 | bVar1 & 0xf0;
  bVar1 = param_2[2];
  *(byte *)(param_1 + 0x13) = (bVar1 & 0xf) << 4 | bVar1 & 0xf;
  *(byte *)(param_1 + 0x17) = bVar1 >> 4 | bVar1 & 0xf0;
  bVar1 = param_2[3];
  *(byte *)(param_1 + 0x1b) = (bVar1 & 0xf) << 4 | bVar1 & 0xf;
  *(byte *)(param_1 + 0x1f) = bVar1 >> 4 | bVar1 & 0xf0;
  bVar1 = param_2[4];
  *(byte *)(param_1 + 0x23) = (bVar1 & 0xf) << 4 | bVar1 & 0xf;
  *(byte *)(param_1 + 0x27) = bVar1 >> 4 | bVar1 & 0xf0;
  bVar1 = param_2[5];
  *(byte *)(param_1 + 0x2b) = (bVar1 & 0xf) << 4 | bVar1 & 0xf;
  *(byte *)(param_1 + 0x2f) = bVar1 >> 4 | bVar1 & 0xf0;
  bVar1 = param_2[6];
  *(byte *)(param_1 + 0x33) = (bVar1 & 0xf) << 4 | bVar1 & 0xf;
  *(byte *)(param_1 + 0x37) = bVar1 >> 4 | bVar1 & 0xf0;
  bVar1 = param_2[7];
  *(byte *)(param_1 + 0x3b) = (bVar1 & 0xf) << 4 | bVar1 & 0xf;
  *(byte *)(param_1 + 0x3f) = bVar1 >> 4 | bVar1 & 0xf0;
  return;
}



/* FUNCTION 11934 ; VA 0x007cf850 ; FUN_007cf850 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007cf850(int param_1,byte *param_2)

{
  byte bVar1;
  short sVar2;
  short sVar3;
  short sVar4;
  short sVar5;
  uint3 uVar6;
  byte *pbVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  int iVar12;
  uint3 *puVar13;
  longlong lVar14;
  undefined auVar15 [16];
  int iVar21;
  int iVar22;
  undefined auVar16 [16];
  undefined auVar17 [16];
  undefined auVar18 [16];
  undefined auVar19 [16];
  undefined auVar20 [16];
  uint uVar23;
  uint uVar27;
  uint uVar28;
  undefined auVar25 [16];
  undefined auVar26 [16];
  uint uVar29;
  byte abStack_24 [18];
  undefined4 uStack_12;
  undefined2 uStack_e;
  uint uStack_c;
  uint uStack_8;
  undefined auVar24 [16];
  
  abStack_24[0x10] = *param_2;
  abStack_24[0x11] = param_2[1];
  uStack_8 = CONCAT31(0,abStack_24[0x10]);
  uStack_c = CONCAT31(0,abStack_24[0x11]);
  auVar15[4] = abStack_24[0x10];
  auVar15._0_4_ = uStack_8;
  auVar15._5_3_ = 0;
  auVar15[8] = abStack_24[0x10];
  auVar15._9_3_ = 0;
  auVar15[0xc] = abStack_24[0x10];
  auVar15._13_3_ = 0;
  if (uStack_c < uStack_8) {
    uVar23 = uStack_c + uStack_8 * 6;
    uVar8 = uVar23 / 7;
    uVar27 = uStack_8 * 5 + uStack_c * 2;
    uVar9 = uVar27 / 7;
    uVar28 = uStack_c * 3 + uStack_8 * 4;
    uVar10 = uVar28 / 7;
    uVar29 = uStack_8 * 3 + uStack_c * 4;
    uVar11 = uVar29 / 7;
    uStack_12 = CONCAT13((char)((uVar29 - uVar11 >> 1) + uVar11 >> 2),
                         CONCAT12((char)((uVar28 - uVar10 >> 1) + uVar10 >> 2),
                                  CONCAT11((char)((uVar27 - uVar9 >> 1) + uVar9 >> 2),
                                           (char)((uVar23 - uVar8 >> 1) + uVar8 >> 2))));
    uVar23 = uStack_c * 5 + uStack_8 * 2;
    uVar27 = uVar23 / 7;
    uStack_8 = uStack_8 + uStack_c * 6;
    uVar28 = uStack_8 / 7;
    uStack_e = CONCAT11((char)((uStack_8 - uVar28 >> 1) + uVar28 >> 2),
                        (char)((uVar23 - uVar27 >> 1) + uVar27 >> 2));
  }
  else {
    iVar12 = 1;
    if (DAT_021137e0 < 2) {
      iVar21 = uStack_8 << 2;
      uVar23 = uStack_c;
      do {
        iVar22 = iVar21 + uVar23;
        iVar21 = iVar21 - uStack_8;
        uVar23 = uVar23 + uStack_c;
        abStack_24[iVar12 + 0x11] =
             ((char)(iVar22 / 5) + (char)(iVar22 >> 0x1f)) -
             (char)((longlong)iVar22 * 0x66666667 >> 0x3f);
        iVar12 = iVar12 + 1;
      } while (iVar12 < 5);
      uStack_e = 0xff00;
    }
    else {
      auVar26._0_4_ = _DAT_018e0030 + (int)DAT_01900430;
      auVar26._4_4_ = _UNK_018e0034 + DAT_01900430._4_4_;
      auVar26._8_4_ = _UNK_018e0038 + _UNK_01900438;
      auVar26._12_4_ = _UNK_018e003c + _UNK_0190043c;
      auVar16._0_4_ = _DAT_01900440 - auVar26._0_4_;
      auVar16._4_4_ = _UNK_01900444 - auVar26._4_4_;
      auVar16._8_4_ = _UNK_01900448 - auVar26._8_4_;
      auVar16._12_4_ = _UNK_0190044c - auVar26._12_4_;
      uStack_e = 0xff00;
      auVar17 = pmulld(auVar16,auVar15);
      auVar19[4] = abStack_24[0x11];
      auVar19._0_4_ = uStack_c;
      auVar19._5_3_ = 0;
      auVar19[8] = abStack_24[0x11];
      auVar19._9_3_ = 0;
      auVar19[0xc] = abStack_24[0x11];
      auVar19._13_3_ = 0;
      auVar15 = pmulld(auVar26,auVar19);
      iVar12 = auVar17._0_4_ + auVar15._0_4_;
      iVar21 = auVar17._4_4_ + auVar15._4_4_;
      auVar25._4_4_ = iVar21;
      auVar25._0_4_ = iVar12;
      iVar22 = auVar17._8_4_ + auVar15._8_4_;
      auVar18._12_4_ = auVar17._12_4_ + auVar15._12_4_;
      auVar15 = ZEXT416(1);
      auVar25._8_4_ = iVar21;
      auVar25._12_4_ = iVar21;
      auVar24._8_8_ = auVar25._8_8_;
      auVar24._4_4_ = iVar12;
      auVar24._0_4_ = iVar12;
      auVar26 = pmuldq(auVar24,s_gfffgfffgfffgfffBufferPool_01900460._0_16_);
      auVar18._4_4_ = iVar22;
      auVar18._0_4_ = iVar22;
      auVar18._8_4_ = auVar18._12_4_;
      auVar19 = pmuldq(auVar18,s_gfffgfffgfffgfffBufferPool_01900460._0_16_);
      uVar23 = auVar26._4_4_ >> auVar15;
      uVar27 = auVar26._12_4_ >> auVar15;
      uVar28 = auVar19._4_4_ >> auVar15;
      uVar29 = auVar19._12_4_ >> auVar15;
      lVar14 = SUB168(ZEXT416(0x1f),0);
      auVar20._0_4_ = (uVar23 >> lVar14) + uVar23;
      auVar20._4_4_ = (uVar27 >> lVar14) + uVar27;
      auVar20._8_4_ = (uVar28 >> lVar14) + uVar28;
      auVar20._12_4_ = (uVar29 >> lVar14) + uVar29;
      auVar15 = pshuflw(ZEXT416(0x1f),auVar20,0xd8);
      auVar15 = pshufhw(auVar15,auVar15,0xd8);
      auVar17._0_4_ = auVar15._0_4_;
      auVar17._12_4_ = auVar15._12_4_;
      auVar17._4_4_ = auVar15._8_4_;
      auVar17._8_4_ = auVar15._4_4_;
      auVar17 = auVar17 & _DAT_01900450;
      sVar2 = auVar17._0_2_;
      sVar3 = auVar17._2_2_;
      sVar4 = auVar17._4_2_;
      sVar5 = auVar17._6_2_;
      uStack_12 = CONCAT13((0 < sVar5) * (sVar5 < 0x100) * auVar17[6] - (0xff < sVar5),
                           CONCAT12((0 < sVar4) * (sVar4 < 0x100) * auVar17[4] - (0xff < sVar4),
                                    CONCAT11((0 < sVar3) * (sVar3 < 0x100) * auVar17[2] -
                                             (0xff < sVar3),
                                             (0 < sVar2) * (sVar2 < 0x100) * auVar17[0] -
                                             (0xff < sVar2))));
    }
  }
  iVar12 = 2;
  pbVar7 = abStack_24;
  puVar13 = (uint3 *)(param_2 + 2);
  do {
    bVar1 = *(byte *)((int)puVar13 + 2);
    uVar6 = *puVar13;
    *pbVar7 = (byte)*(undefined2 *)puVar13 & 7;
    pbVar7[1] = (byte)(uVar6 >> 3) & 7;
    pbVar7[2] = (byte)(uVar6 >> 6) & 7;
    pbVar7[3] = (byte)(uVar6 >> 9) & 7;
    pbVar7[4] = (byte)(uVar6 >> 0xc) & 7;
    pbVar7[5] = (byte)(uVar6 >> 0xf) & 7;
    pbVar7[6] = bVar1 >> 2 & 7;
    pbVar7[7] = bVar1 >> 5;
    iVar12 = iVar12 + -1;
    pbVar7 = pbVar7 + 8;
    puVar13 = (uint3 *)((int)puVar13 + 3);
  } while (iVar12 != 0);
  iVar12 = 0;
  pbVar7 = (byte *)(param_1 + 7);
  do {
    pbVar7[-4] = abStack_24[abStack_24[iVar12] + 0x10];
    *pbVar7 = abStack_24[abStack_24[iVar12 + 1] + 0x10];
    pbVar7[4] = abStack_24[abStack_24[iVar12 + 2] + 0x10];
    iVar21 = iVar12 + 3;
    iVar12 = iVar12 + 4;
    pbVar7[8] = abStack_24[abStack_24[iVar21] + 0x10];
    pbVar7 = pbVar7 + 0x10;
  } while (iVar12 < 0x10);
  return;
}



/* FUNCTION 11935 ; VA 0x007cfae0 ; FUN_007cfae0 */

void FUN_007cfae0(int param_1,ushort *param_2,char param_3)

{
  byte *pbVar1;
  longlong lVar2;
  ushort uVar3;
  byte *pbVar4;
  byte bVar5;
  byte bVar6;
  byte bVar7;
  int iVar8;
  uint uVar9;
  byte abStack_30 [16];
  byte abStack_20 [16];
  uint uStack_10;
  uint uStack_c;
  uint uStack_8;
  
  abStack_20[3] = 0xff;
  abStack_20[7] = 0xff;
  uVar3 = *param_2;
  uStack_8 = (uint)uVar3;
  bVar6 = (byte)(uVar3 >> 8);
  bVar5 = (byte)(uVar3 >> 5) & 0x3f;
  bVar7 = (byte)uVar3 & 0x1f;
  abStack_20[0] = bVar6 >> 5 | bVar6 & 0xf8;
  abStack_20[1] = bVar5 >> 4 | bVar5 << 2;
  abStack_20[2] = bVar7 >> 2 | bVar7 << 3;
  uVar3 = param_2[1];
  uStack_c = (uint)uVar3;
  bVar6 = (byte)(uVar3 >> 5) & 0x3f;
  bVar5 = *(byte *)(param_2 + 1) & 0x1f;
  abStack_20[4] = *(byte *)((int)param_2 + 3) >> 5 | *(byte *)((int)param_2 + 3) & 0xf8;
  abStack_20[5] = bVar6 >> 4 | bVar6 << 2;
  iVar8 = 0;
  abStack_20[6] = bVar5 >> 2 | bVar5 << 3;
  do {
    uStack_10 = (uint)abStack_20[iVar8 + 4];
    uVar9 = (uint)abStack_20[iVar8];
    if ((param_3 == '\0') || (uStack_c < uStack_8)) {
      bVar6 = (byte)((uVar9 + uStack_10 * 2) / 3);
      lVar2 = (ulonglong)(uStack_10 + uVar9 * 2) * 0xaaaaaaab;
    }
    else {
      bVar6 = 0;
      lVar2 = CONCAT44(uStack_10 + uVar9,uStack_10);
    }
    abStack_20[iVar8 + 8] = (byte)(uint)((ulonglong)lVar2 >> 0x21);
    abStack_20[iVar8 + 0xc] = bVar6;
    iVar8 = iVar8 + 1;
  } while (iVar8 < 3);
  abStack_20[0xb] = 0xff;
  if ((param_3 == '\0') || (uStack_c < uStack_8)) {
    abStack_20[0xf] = 0xff;
  }
  else {
    abStack_20[0xf] = 0;
  }
  iVar8 = 0;
  bVar6 = *(byte *)(param_2 + 2);
  abStack_30[0] = bVar6 & 3;
  abStack_30[1] = bVar6 >> 2 & 3;
  abStack_30[2] = bVar6 >> 4 & 3;
  abStack_30[3] = bVar6 >> 6;
  bVar6 = *(byte *)((int)param_2 + 5);
  abStack_30[4] = bVar6 & 3;
  abStack_30[5] = bVar6 >> 2 & 3;
  abStack_30[6] = bVar6 >> 4 & 3;
  abStack_30[7] = bVar6 >> 6;
  bVar6 = *(byte *)(param_2 + 3);
  abStack_30[8] = bVar6 & 3;
  abStack_30[9] = bVar6 >> 2 & 3;
  abStack_30[10] = bVar6 >> 4 & 3;
  abStack_30[0xb] = bVar6 >> 6;
  bVar6 = *(byte *)((int)param_2 + 7);
  abStack_30[0xc] = bVar6 & 3;
  abStack_30[0xd] = bVar6 >> 2 & 3;
  abStack_30[0xe] = bVar6 >> 4 & 3;
  abStack_30[0xf] = bVar6 >> 6;
  pbVar4 = (byte *)(param_1 + 2);
  do {
    pbVar1 = abStack_30 + iVar8;
    iVar8 = iVar8 + 1;
    uVar9 = (uint)(byte)(*pbVar1 << 2);
    pbVar4[-2] = abStack_20[uVar9];
    pbVar4[-1] = abStack_20[uVar9 + 1];
    *pbVar4 = abStack_20[uVar9 + 2];
    pbVar4[1] = abStack_20[uVar9 + 3];
    pbVar4 = pbVar4 + 4;
  } while (iVar8 < 0x10);
  return;
}



/* FUNCTION 11936 ; VA 0x007cfcd0 ; FUN_007cfcd0 */

void __fastcall FUN_007cfcd0(int param_1)

{
  if (*(int *)(param_1 + 0xc) != 0) {
    FUN_007cf6c0(1);
  }
  return;
}



/* FUNCTION 11937 ; VA 0x007cfce0 ; FUN_007cfce0 */

void __fastcall FUN_007cfce0(int param_1)

{
  FUN_01674ea0(*(undefined4 *)(param_1 + 0xc),0x48);
  return;
}



/* FUNCTION 11938 ; VA 0x007cfcf0 ; FUN_007cfcf0 */

int __thiscall FUN_007cfcf0(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = FUN_0170d8dd(param_2 + 4,0x1da07b8);
  if (iVar1 == 0) {
    return param_1 + 0xc;
  }
  return 0;
}



/* FUNCTION 11939 ; VA 0x007cfd20 ; FUN_007cfd20 */

void __thiscall FUN_007cfd20(int *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined auStack_10 [4];
  int iStack_c;
  undefined uStack_5;
  
  iStack_c = param_1[1] - *param_1 >> 2;
  iVar2 = FUN_00577ed0(param_2);
  FUN_0055b6b0(&uStack_5,auStack_10,auStack_10);
  FUN_0170cc70(iVar2,*param_1,param_1[1] - *param_1);
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar4 = param_1[2] - iVar1 & 0xfffffffc;
    iVar3 = iVar1;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *param_1 = iVar2;
  param_1[1] = iVar2 + iStack_c * 4;
  param_1[2] = iVar2 + param_2 * 4;
  return;
}



/* FUNCTION 11940 ; VA 0x007cfdc0 ; FUN_007cfdc0 */

int FUN_007cfdc0(int param_1,byte param_2)

{
  uint uVar1;
  
  if ((param_2 & 2) != 0) {
    uVar1 = param_1 - 1U | param_1 - 1U >> 0x10;
    uVar1 = uVar1 | uVar1 >> 8;
    uVar1 = uVar1 | uVar1 >> 4;
    uVar1 = uVar1 | uVar1 >> 2;
    return (uVar1 >> 1 | uVar1) + 1;
  }
  return param_1;
}



/* FUNCTION 11941 ; VA 0x007cfe00 ; FUN_007cfe00 */

uint FUN_007cfe00(uint param_1,uint param_2,byte param_3)

{
  uint uVar1;
  
  if ((param_3 & 2) != 0) {
    uVar1 = param_1 - 1 | param_1 - 1 >> 0x10;
    uVar1 = uVar1 | uVar1 >> 8;
    uVar1 = uVar1 | uVar1 >> 4;
    uVar1 = uVar1 | uVar1 >> 2;
    uVar1 = (uVar1 >> 1 | uVar1) + 1;
    if (param_2 < uVar1) {
      uVar1 = param_2;
    }
    return uVar1;
  }
  if (param_2 < param_1) {
    param_1 = param_2;
  }
  return param_1;
}



/* FUNCTION 11942 ; VA 0x007cfe50 ; FUN_007cfe50 */

undefined __fastcall FUN_007cfe50(int param_1)

{
  return *(undefined *)(param_1 + 0x58);
}



/* FUNCTION 11943 ; VA 0x007cfe60 ; FUN_007cfe60 */

undefined4 FUN_007cfe60(undefined4 param_1)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uStack_c;
  undefined *puStack_8;
  
  iVar2 = FUN_016de3db(&DAT_01e90d14,FUN_0054dbd0,&DAT_01e90d18);
  if (iVar2 != 0) {
    uStack_c = 1;
    puStack_8 = &DAT_01e90d18;
    FUN_0054ff80("putback buffer full",&uStack_c);
    return param_1;
  }
  FUN_0171d16a();
  pcVar1 = (code *)swi(3);
  uVar3 = (*pcVar1)();
  return uVar3;
}



/* FUNCTION 11944 ; VA 0x007cfeb0 ; FUN_007cfeb0 */

undefined4 FUN_007cfeb0(undefined4 param_1)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uStack_c;
  undefined *puStack_8;
  
  iVar2 = FUN_016de3db(&DAT_01e90d14,FUN_0054dbd0,&DAT_01e90d18);
  if (iVar2 != 0) {
    uStack_c = 1;
    puStack_8 = &DAT_01e90d18;
    FUN_0054ff80("bad seek",&uStack_c);
    return param_1;
  }
  FUN_0171d16a();
  pcVar1 = (code *)swi(3);
  uVar3 = (*pcVar1)();
  return uVar3;
}



/* FUNCTION 11945 ; VA 0x007cff00 ; FUN_007cff00 */

void FUN_007cff00(byte param_1,byte *param_2,undefined *param_3)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  byte abStack_c [8];
  
  abStack_c[0] = 3;
  abStack_c[1] = 6;
  abStack_c[2] = 0xb;
  abStack_c[3] = 0x10;
  abStack_c[4] = 0x17;
  abStack_c[5] = 0x20;
  abStack_c[6] = 0x29;
  abStack_c[7] = 0x40;
  uVar3 = (uint)abStack_c[param_1];
  iVar1 = param_2[3] - uVar3;
  if (iVar1 < 0) {
    iVar1 = 0;
  }
  else if (0xff < iVar1) {
    iVar1 = 0xff;
  }
  param_3[9] = (char)iVar1;
  iVar1 = param_2[4] - uVar3;
  if (iVar1 < 0) {
    iVar1 = 0;
  }
  else if (0xff < iVar1) {
    iVar1 = 0xff;
  }
  param_3[10] = (char)iVar1;
  iVar1 = param_2[5] - uVar3;
  if (iVar1 < 0) {
    iVar1 = 0;
  }
  else if (0xff < iVar1) {
    iVar1 = 0xff;
  }
  param_3[0xb] = (char)iVar1;
  uVar2 = *param_2 + uVar3;
  if (0xff < uVar2) {
    uVar2 = 0xff;
  }
  *param_3 = (char)uVar2;
  uVar2 = param_2[1] + uVar3;
  if (0xff < uVar2) {
    uVar2 = 0xff;
  }
  param_3[1] = (char)uVar2;
  uVar2 = param_2[2] + uVar3;
  if (0xff < uVar2) {
    uVar2 = 0xff;
  }
  param_3[2] = (char)uVar2;
  iVar1 = *param_2 - uVar3;
  if (iVar1 < 0) {
    iVar1 = 0;
  }
  else if (0xff < iVar1) {
    iVar1 = 0xff;
  }
  param_3[3] = (char)iVar1;
  iVar1 = param_2[1] - uVar3;
  if (iVar1 < 0) {
    iVar1 = 0;
  }
  else if (0xff < iVar1) {
    iVar1 = 0xff;
  }
  param_3[4] = (char)iVar1;
  iVar1 = param_2[2] - uVar3;
  if (iVar1 < 0) {
    iVar1 = 0;
  }
  else if (0xff < iVar1) {
    iVar1 = 0xff;
  }
  param_3[5] = (char)iVar1;
  uVar2 = param_2[3] + uVar3;
  if (0xff < uVar2) {
    uVar2 = 0xff;
  }
  param_3[6] = (char)uVar2;
  uVar2 = param_2[4] + uVar3;
  if (0xff < uVar2) {
    uVar2 = 0xff;
  }
  param_3[7] = (char)uVar2;
  uVar3 = param_2[5] + uVar3;
  if (0xff < uVar3) {
    uVar3 = 0xff;
  }
  param_3[8] = (char)uVar3;
  return;
}



/* FUNCTION 11946 ; VA 0x007d0020 ; FUN_007d0020 */

undefined4 FUN_007d0020(undefined4 param_1)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uStack_c;
  undefined *puStack_8;
  
  iVar2 = FUN_016de3db(&DAT_01e90d14,FUN_0054dbd0,&DAT_01e90d18);
  if (iVar2 != 0) {
    uStack_c = 1;
    puStack_8 = &DAT_01e90d18;
    FUN_0054ff80("no read access",&uStack_c);
    return param_1;
  }
  FUN_0171d16a();
  pcVar1 = (code *)swi(3);
  uVar3 = (*pcVar1)();
  return uVar3;
}



/* FUNCTION 11947 ; VA 0x007d006d ; FUN_007d006d */

void FUN_007d006d(void)

{
  FUN_007d0080();
  return;
}



/* FUNCTION 11948 ; VA 0x007d0080 ; FUN_007d0080 */

int __fastcall FUN_007d0080(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3a8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x34);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[10] = &DAT_01900424;
    puVar3[0xc] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x2c,puVar3 + 1);
    *puVar3 = std::_System_error::vftable;
    puVar3[3] = *(undefined4 *)(param_1 + -0x24);
    puVar3[4] = *(undefined4 *)(param_1 + -0x20);
    *puVar3 = std::ios_base::failure::vftable;
    puVar1 = puVar3 + 5;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[6] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[7] = *(undefined4 *)(param_1 + -0x14);
    puVar3[8] = *(undefined4 *)(param_1 + -0x10);
    puVar3[9] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_std::ios_base::failure>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_std::ios_base::failure>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[10] + 4) + 0x28 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<class_std::ios_base::failure>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[10] + 4) + 0x24 + (int)puVar3) = *(int *)(puVar3[10] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[10] + 4) + 0x28 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 11949 ; VA 0x007d01b0 ; FUN_007d01b0 */

void __thiscall FUN_007d01b0(int *param_1,int param_2)

{
  if (param_2 == 1) {
    if (param_1[0x12] != 0) {
      *(undefined4 *)param_1[3] = 0;
      *(undefined4 *)param_1[7] = 0;
      *(undefined4 *)param_1[0xb] = 0;
      param_1[0x13] = 0;
      param_1[0x12] = 0;
      return;
    }
  }
  else if (param_2 == 2) {
    if (param_1[0x14] != 0) {
      (**(code **)(*param_1 + 0x34))();
      *(undefined4 *)param_1[4] = 0;
      *(undefined4 *)param_1[8] = 0;
      *(undefined4 *)param_1[0xc] = 0;
      param_1[0x15] = 0;
      param_1[0x14] = 0;
      return;
    }
  }
  else if (param_2 == 3) {
    _guard_check_icall(param_1 + 0xf);
  }
  return;
}



/* FUNCTION 11950 ; VA 0x007d0250 ; FUN_007d0250 */

int __fastcall FUN_007d0250(int param_1)

{
  return param_1 + 0x3c;
}



/* FUNCTION 11951 ; VA 0x007d0260 ; FUN_007d0260 */

TypeDescriptor * FUN_007d0260(void)

{
  return &boost::iostreams::basic_array_source<char>::RTTI_Type_Descriptor;
}



/* FUNCTION 11952 ; VA 0x007d0270 ; FUN_007d0270 */

uint FUN_007d0270(ushort param_1)

{
  return ((param_1 >> 1 & 0x1c) + (uint)(param_1 >> 1) * 0x20) * 0x4000 |
         ((param_1 >> 6 & 0x1f) * 0x20 + (param_1 >> 6 & 0x1c)) * 0x40 |
         (uint)(param_1 >> 0xd) + (uint)(param_1 >> 0xb) * 8 | 0xff000000;
}



/* FUNCTION 11953 ; VA 0x007d02c0 ; FUN_007d02c0 */

void FUN_007d02c0(int param_1,int param_2,uint param_3,uint param_4,int param_5,int param_6)

{
  undefined *puVar1;
  int iVar2;
  undefined *puVar3;
  uint uVar4;
  uint uVar5;
  undefined auStack_68 [64];
  int iStack_28;
  int iStack_24;
  int iStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  int iStack_14;
  int iStack_10;
  uint uStack_c;
  undefined *puStack_8;
  
  iStack_20 = FUN_0147d000(param_6,4,4);
  if (param_5 != 0) {
    puStack_18 = (undefined *)(param_1 + 2);
    iStack_28 = param_3 * param_4 * 4;
    puStack_1c = puStack_18;
    do {
      uStack_c = 0;
      puStack_1c = puStack_18;
      if (param_4 != 0) {
        iVar2 = param_3 << 4;
        iStack_14 = iVar2;
        do {
          if (param_3 != 0) {
            puStack_8 = puStack_18;
            iStack_24 = param_3 * 4;
            uVar5 = 2;
            do {
              if (param_6 == 0xe) {
                FUN_007cfae0(auStack_68,param_2,1);
              }
              else if (param_6 == 0xf) {
                FUN_007cfae0(auStack_68,param_2 + 8,0);
                FUN_007cf740(auStack_68,param_2);
              }
              else if (param_6 == 0x10) {
                FUN_007cfae0(auStack_68,param_2 + 8,0);
                FUN_007cf850(auStack_68,param_2);
              }
              puVar3 = auStack_68 + 1;
              param_2 = param_2 + iStack_20;
              iStack_10 = 4;
              puVar1 = puStack_8;
              uVar4 = uStack_c;
              do {
                if ((uVar5 - 2 < param_3) && (uVar4 < param_4)) {
                  puVar1[-2] = puVar3[-1];
                  puVar1[-1] = *puVar3;
                  *puVar1 = puVar3[1];
                  puVar1[1] = puVar3[2];
                }
                if ((uVar5 - 1 < param_3) && (uVar4 < param_4)) {
                  puVar1[2] = puVar3[3];
                  puVar1[3] = puVar3[4];
                  puVar1[4] = puVar3[5];
                  puVar1[5] = puVar3[6];
                }
                if ((uVar5 < param_3) && (uVar4 < param_4)) {
                  puVar1[6] = puVar3[7];
                  puVar1[7] = puVar3[8];
                  puVar1[8] = puVar3[9];
                  puVar1[9] = puVar3[10];
                }
                if ((uVar5 + 1 < param_3) && (uVar4 < param_4)) {
                  puVar1[10] = puVar3[0xb];
                  puVar1[0xb] = puVar3[0xc];
                  puVar1[0xc] = puVar3[0xd];
                  puVar1[0xd] = puVar3[0xe];
                }
                puVar1 = puVar1 + iStack_24;
                puVar3 = puVar3 + 0x10;
                uVar4 = uVar4 + 1;
                iStack_10 = iStack_10 + -1;
              } while (iStack_10 != 0);
              puStack_8 = puStack_8 + 0x10;
              uVar4 = uVar5 + 2;
              iVar2 = iStack_14;
              uVar5 = uVar5 + 4;
            } while (uVar4 < param_3);
          }
          uStack_c = uStack_c + 4;
          puStack_18 = puStack_18 + iVar2;
        } while (uStack_c < param_4);
      }
      puStack_18 = puStack_1c + iStack_28;
      param_5 = param_5 + -1;
      puStack_1c = puStack_18;
    } while (param_5 != 0);
  }
  return;
}



/* FUNCTION 11954 ; VA 0x007d04c0 ; FUN_007d04c0 */

void FUN_007d04c0(int param_1,undefined *param_2,uint param_3,uint param_4,undefined4 param_5)

{
  int iVar1;
  uint uVar2;
  ushort uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  byte abStack_5c [64];
  ushort *puStack_1c;
  int iStack_18;
  uint uStack_14;
  int iStack_10;
  int iStack_c;
  uint uStack_8;
  
  iStack_18 = FUN_0147d000(param_5,4,4);
  uStack_8 = 0;
  if (param_4 != 0) {
    iStack_c = 0;
    do {
      uStack_14 = 0;
      if (param_3 != 0) {
        do {
          uVar2 = uStack_14;
          FUN_007d15a0(CONCAT31(CONCAT21(CONCAT11(*param_2,param_2[1]),param_2[2]),param_2[3]),
                       CONCAT31(CONCAT21(CONCAT11(param_2[4],param_2[5]),param_2[6]),param_2[7]),
                       abStack_5c,4,4,0,0,4);
          param_2 = param_2 + iStack_18;
          uVar7 = 0;
          iStack_10 = iStack_c + uVar2;
          do {
            uVar5 = 0;
            do {
              if ((uVar5 + uVar2 < param_3) && (uStack_8 + uVar7 < param_4)) {
                puStack_1c = (ushort *)(param_1 + (iStack_10 + uVar5) * 2);
                iVar1 = uVar5 + uVar7 * 4;
                uVar2 = abStack_5c[iVar1 * 4] + 4 >> 3;
                if (0x1f < uVar2) {
                  uVar2 = 0x1f;
                }
                uVar4 = abStack_5c[iVar1 * 4 + 1] + 4 >> 3;
                uVar6 = 0x1f;
                if (uVar4 < 0x20) {
                  uVar6 = uVar4;
                }
                uVar4 = abStack_5c[iVar1 * 4 + 2] + 4 >> 3;
                if (uVar4 < 0x20) {
                  uVar3 = (ushort)uVar4;
                }
                else {
                  uVar3 = 0x1f;
                }
                *puStack_1c = ((ushort)((uVar2 << 5 | uVar6) << 5) | uVar3) * 2 | 1;
                uVar2 = uStack_14;
              }
              uVar5 = uVar5 + 1;
            } while (uVar5 < 4);
            uVar7 = uVar7 + 1;
            iStack_10 = iStack_10 + param_3;
          } while (uVar7 < 4);
          uStack_14 = uVar2 + 4;
        } while (uStack_14 < param_3);
      }
      uStack_8 = uStack_8 + 4;
      iStack_c = iStack_c + param_3 * 4;
    } while (uStack_8 < param_4);
  }
  return;
}



/* FUNCTION 11955 ; VA 0x007d0660 ; FUN_007d0660 */

void FUN_007d0660(int param_1,undefined *param_2,uint param_3,uint param_4,int param_5)

{
  int iVar1;
  undefined *puVar2;
  undefined *puVar3;
  uint uVar4;
  uint uVar5;
  undefined auStack_5c [64];
  int iStack_1c;
  undefined *puStack_18;
  int iStack_14;
  int iStack_10;
  uint uStack_c;
  undefined *puStack_8;
  
  iStack_1c = FUN_0147d000(param_5,4,4);
  uStack_c = 0;
  if (param_4 != 0) {
    iVar1 = param_3 << 4;
    puStack_18 = (undefined *)(param_1 + 2);
    iStack_14 = iVar1;
    do {
      if (param_3 != 0) {
        puStack_8 = puStack_18;
        uVar5 = 2;
        do {
          if (param_5 == 0x14) {
            FUN_007d15a0(CONCAT31(CONCAT21(CONCAT11(*param_2,param_2[1]),param_2[2]),param_2[3]),
                         CONCAT31(CONCAT21(CONCAT11(param_2[4],param_2[5]),param_2[6]),param_2[7]),
                         auStack_5c,4,4,0,0,4);
            iVar1 = 0;
            do {
              auStack_5c[iVar1 * 4 + 3] = 0xff;
              iVar1 = iVar1 + 1;
            } while (iVar1 < 0x10);
          }
          else if (param_5 == 0x15) {
            FUN_007d0a80(param_2,auStack_5c + 3,4,4,0,0,4);
            FUN_007d15a0(CONCAT31(CONCAT21(CONCAT11(param_2[8],param_2[9]),param_2[10]),param_2[0xb]
                                 ),
                         CONCAT31(CONCAT21(CONCAT11(param_2[0xc],param_2[0xd]),param_2[0xe]),
                                  param_2[0xf]),auStack_5c,4,4,0,0,4);
          }
          param_2 = param_2 + iStack_1c;
          puVar3 = auStack_5c + 1;
          iStack_10 = 4;
          puVar2 = puStack_8;
          uVar4 = uStack_c;
          do {
            if ((uVar5 - 2 < param_3) && (uVar4 < param_4)) {
              puVar2[-2] = puVar3[-1];
              puVar2[-1] = *puVar3;
              *puVar2 = puVar3[1];
              puVar2[1] = puVar3[2];
            }
            if ((uVar5 - 1 < param_3) && (uVar4 < param_4)) {
              puVar2[2] = puVar3[3];
              puVar2[3] = puVar3[4];
              puVar2[4] = puVar3[5];
              puVar2[5] = puVar3[6];
            }
            if ((uVar5 < param_3) && (uVar4 < param_4)) {
              puVar2[6] = puVar3[7];
              puVar2[7] = puVar3[8];
              puVar2[8] = puVar3[9];
              puVar2[9] = puVar3[10];
            }
            if ((uVar5 + 1 < param_3) && (uVar4 < param_4)) {
              puVar2[10] = puVar3[0xb];
              puVar2[0xb] = puVar3[0xc];
              puVar2[0xc] = puVar3[0xd];
              puVar2[0xd] = puVar3[0xe];
            }
            puVar3 = puVar3 + 0x10;
            puVar2 = puVar2 + param_3 * 4;
            uVar4 = uVar4 + 1;
            iStack_10 = iStack_10 + -1;
          } while (iStack_10 != 0);
          puStack_8 = puStack_8 + 0x10;
          uVar4 = uVar5 + 2;
          iVar1 = iStack_14;
          uVar5 = uVar5 + 4;
        } while (uVar4 < param_3);
      }
      uStack_c = uStack_c + 4;
      puStack_18 = puStack_18 + iVar1;
    } while (uStack_c < param_4);
  }
  return;
}



/* FUNCTION 11956 ; VA 0x007d08a0 ; FUN_007d08a0 */

void FUN_007d08a0(undefined4 param_1,undefined4 param_2,int *param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint *puVar5;
  undefined4 uVar6;
  int iVar7;
  undefined auStack_b0 [128];
  undefined auStack_30 [28];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3ab3;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff44;
  ExceptionList = &pvStack_10;
  FUN_005956d0(0,0,2);
  puVar5 = (uint *)FUN_005957d0();
  uVar1 = puVar5[2];
  uVar2 = *puVar5;
  iVar7 = uVar1 + *puVar5;
  uVar3 = puVar5[3];
  uVar4 = puVar5[1];
  FUN_007d4c20(0,0,0,0,0);
  if (((*(byte *)(*(int *)(*param_3 + 4) + 0xc + (int)param_3) & 6) == 0) &&
     (-1 < (int)(uVar3 + uVar4 + (uint)CARRY4(uVar1,uVar2)))) {
    uVar6 = FUN_01674e20();
    uStack_8 = 0;
    FUN_007d3f40(param_3,uVar6,iVar7);
    FUN_0115eea0(uVar6,iVar7,0,1,0,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_0115ffa0(auStack_b0,param_2);
    FUN_0115f010();
    FUN_01674ea0();
    ExceptionList = pvStack_10;
    return;
  }
  FUN_016756b0(auStack_30,"Input stream is not seekable");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c17198);
}



/* FUNCTION 11957 ; VA 0x007d09bb ; Catch@007d09bb */

void Catch_007d09bb(void)

{
  int unaff_EBP;
  
  FUN_005500e0(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(unaff_EBP + -0x20,&DAT_01c17198);
}



/* FUNCTION 11958 ; VA 0x007d09e0 ; FUN_007d09e0 */

void FUN_007d09e0(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined auStack_8c [120];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b3acb;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff68;
  puVar1 = param_3 + 4;
  uStack_8 = 0;
  if (0xf < (uint)param_3[5]) {
    param_3 = (undefined4 *)*param_3;
  }
  ExceptionList = &pvStack_10;
  FUN_0115eea0(param_3,*puVar1,0,1,0,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0115ffa0(auStack_8c,param_2);
  FUN_0115f010();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11959 ; VA 0x007d0a5d ; Catch@007d0a5d */

void Catch_007d0a5d(void)

{
  int unaff_EBP;
  
  FUN_005500e0(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(unaff_EBP + -0x20,&DAT_01c17198);
}



/* FUNCTION 11960 ; VA 0x007d0a80 ; FUN_007d0a80 */

void FUN_007d0a80(byte *param_1,int param_2,int param_3,undefined4 param_4,int param_5,int param_6,
                 int param_7)

{
  byte bVar1;
  byte bVar2;
  undefined *puVar3;
  uint uVar4;
  byte bVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  int iVar11;
  int iStack_10;
  int iStack_c;
  undefined *puStack_8;
  
  iVar7 = 0;
  iStack_10 = 4;
  bVar1 = *param_1;
  bVar2 = param_1[1];
  iVar6 = 2;
  puVar3 = (undefined *)((param_3 * param_6 + param_5) * param_7 + param_2);
  do {
    iStack_c = 4;
    puStack_8 = puVar3;
    do {
      iVar8 = -iVar7 + 7;
      bVar5 = (byte)iVar8;
      uVar4 = (uint)param_1[iVar6] & 1 << (bVar5 & 0x1f);
      if (iVar8 < 3) {
        uVar4 = uVar4 << (2 - bVar5 & 0x1f);
      }
      else {
        uVar4 = (int)uVar4 >> ((char)-iVar7 + 5U & 0x1f);
      }
      iVar7 = iVar7 + 1;
      iVar8 = iVar6 + 1;
      if (iVar7 < 8) {
        iVar8 = iVar6;
      }
      iVar6 = 0;
      if (iVar7 < 8) {
        iVar6 = iVar7;
      }
      iVar7 = -iVar6 + 7;
      bVar5 = (byte)iVar7;
      uVar9 = (uint)param_1[iVar8] & 1 << (bVar5 & 0x1f);
      if (iVar7 < 2) {
        uVar9 = uVar9 << (1 - bVar5 & 0x1f);
      }
      else {
        uVar9 = (int)uVar9 >> ((char)-iVar6 + 6U & 0x1f);
      }
      iVar6 = iVar6 + 1;
      iVar11 = iVar8 + 1;
      if (iVar6 < 8) {
        iVar11 = iVar8;
      }
      iVar8 = 0;
      if (iVar6 < 8) {
        iVar8 = iVar6;
      }
      bVar5 = (byte)(7 - iVar8);
      uVar10 = (uint)param_1[iVar11] & 1 << (bVar5 & 0x1f);
      if (7 - iVar8 < 1) {
        uVar10 = uVar10 << (-bVar5 & 0x1f);
      }
      else {
        uVar10 = (int)uVar10 >> (bVar5 & 0x1f);
      }
      iVar8 = iVar8 + 1;
      iVar7 = 0;
      if (iVar8 < 8) {
        iVar7 = iVar8;
      }
      iVar6 = iVar11 + 1;
      if (iVar8 < 8) {
        iVar6 = iVar11;
      }
      iVar8 = *(int *)(&DAT_018ffb00 + ((uVar4 | uVar9 | uVar10) + (bVar2 & 0xf) * 8) * 4) *
              (uint)(bVar2 >> 4) + (uint)bVar1;
      if (iVar8 < 0) {
        iVar8 = 0;
      }
      else if (0xff < iVar8) {
        iVar8 = 0xff;
      }
      *puStack_8 = (char)iVar8;
      puStack_8 = puStack_8 + param_3 * param_7;
      iStack_c = iStack_c + -1;
    } while (iStack_c != 0);
    puVar3 = puVar3 + param_7;
    iStack_10 = iStack_10 + -1;
  } while (iStack_10 != 0);
  return;
}



/* FUNCTION 11961 ; VA 0x007d0c00 ; FUN_007d0c00 */

void FUN_007d0c00(uint param_1,uint param_2,int param_3,int param_4,undefined4 param_5,int param_6,
                 int param_7,int param_8)

{
  byte bVar1;
  byte bVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  byte bVar7;
  byte bVar8;
  byte bVar9;
  byte bVar10;
  byte bVar11;
  uint uVar12;
  byte bVar13;
  byte bVar14;
  byte bVar15;
  byte bVar16;
  int iVar17;
  uint uVar18;
  undefined *puVar19;
  byte bStack_48;
  int iStack_2c;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  
  uVar18 = param_1 & 1;
  bVar14 = (byte)(param_1 >> 8);
  bVar8 = (byte)(param_1 >> 0x10);
  bVar16 = (byte)(param_1 >> 0x18);
  if ((param_1 & 2) == 0) {
    bVar7 = (byte)(param_1 >> 0x14) & 0xf;
    bVar15 = bVar16 & 0xf0 | bVar16 >> 4;
    bVar13 = (byte)(param_1 >> 0xc) & 0xf;
    bVar7 = bVar7 << 4 | bVar7;
    bVar13 = bVar13 << 4 | bVar13;
    uVar3 = param_1 >> 5 & 7;
    uVar12 = param_2 >> 0x10;
    param_2 = param_2 & 0xffff;
    iStack_1c = param_6;
    if (uVar18 == 0) {
      bVar9 = 0;
      iStack_14 = param_6;
      if (param_6 < param_6 + 2) {
        do {
          if (param_7 < param_7 + 4) {
            puVar19 = (undefined *)(param_3 + 2 + (param_4 * param_7 + iStack_14) * param_8);
            iVar17 = (param_7 + 4) - param_7;
            do {
              bVar10 = bVar9 & 0x1f;
              bVar11 = bVar9 & 0x1f;
              bVar9 = bVar9 + 1;
              iVar5 = *(int *)(&DAT_018ffd88 +
                              (*(int *)(&DAT_018ffd74 +
                                       ((uVar12 >> bVar10 & 1) * 2 | param_2 >> bVar11 & 1) * 4) +
                              uVar3 * 8) * 4);
              iVar4 = (uint)bVar15 + iVar5;
              if (iVar4 < 0) {
                iVar4 = 0;
              }
              else if (0xff < iVar4) {
                iVar4 = 0xff;
              }
              puVar19[-2] = (char)iVar4;
              iVar4 = (uint)bVar7 + iVar5;
              if (iVar4 < 0) {
                iVar4 = 0;
              }
              else if (0xff < iVar4) {
                iVar4 = 0xff;
              }
              puVar19[-1] = (char)iVar4;
              iVar5 = (uint)bVar13 + iVar5;
              if (iVar5 < 0) {
                iVar5 = 0;
              }
              else if (0xff < iVar5) {
                iVar5 = 0xff;
              }
              *puVar19 = (char)iVar5;
              puVar19 = puVar19 + param_4 * param_8;
              iVar17 = iVar17 + -1;
            } while (iVar17 != 0);
          }
          iStack_14 = iStack_14 + 1;
        } while (iStack_14 < param_6 + 2);
      }
    }
    else {
      bVar9 = 0;
      iStack_14 = param_6;
      if (param_6 < param_6 + 4) {
        do {
          if (param_7 < param_7 + 2) {
            puVar19 = (undefined *)(param_3 + 2 + (param_4 * param_7 + iStack_14) * param_8);
            iStack_18 = (param_7 + 2) - param_7;
            bVar10 = bVar9;
            do {
              bVar9 = bVar10 + 1;
              iVar17 = *(int *)(&DAT_018ffd88 +
                               (*(int *)(&DAT_018ffd74 +
                                        ((uVar12 >> (bVar10 & 0x1f) & 1) * 2 |
                                        param_2 >> (bVar10 & 0x1f) & 1) * 4) + uVar3 * 8) * 4);
              iVar5 = (uint)bVar15 + iVar17;
              if (iVar5 < 0) {
                iVar5 = 0;
              }
              else if (0xff < iVar5) {
                iVar5 = 0xff;
              }
              puVar19[-2] = (char)iVar5;
              iVar5 = (uint)bVar7 + iVar17;
              if (iVar5 < 0) {
                iVar5 = 0;
              }
              else if (0xff < iVar5) {
                iVar5 = 0xff;
              }
              puVar19[-1] = (char)iVar5;
              iVar17 = (uint)bVar13 + iVar17;
              if (iVar17 < 0) {
                iVar17 = 0;
              }
              else if (0xff < iVar17) {
                iVar17 = 0xff;
              }
              *puVar19 = (char)iVar17;
              puVar19 = puVar19 + param_4 * param_8;
              iStack_18 = iStack_18 + -1;
              bVar10 = bVar9;
            } while (iStack_18 != 0);
          }
          iStack_14 = iStack_14 + 1;
          bVar9 = bVar9 + 2;
        } while (iStack_14 < param_6 + 4);
      }
    }
    bVar8 = bVar8 & 0xf;
    bVar16 = (bVar16 & 0xf) << 4 | bVar16 & 0xf;
    bVar14 = bVar14 & 0xf;
    bVar8 = bVar8 << 4 | bVar8;
    bVar14 = bVar14 << 4 | bVar14;
    uVar3 = param_1 >> 2 & 7;
    iVar17 = param_6 + 4;
    if (uVar18 == 0) {
      param_6 = param_6 + 2;
      bVar7 = 8;
      if (param_6 < iVar17) {
        do {
          if (param_7 < param_7 + 4) {
            puVar19 = (undefined *)(param_3 + 2 + (param_4 * param_7 + param_6) * param_8);
            iVar5 = (param_7 + 4) - param_7;
            do {
              bVar13 = bVar7 & 0x1f;
              bVar15 = bVar7 & 0x1f;
              bVar7 = bVar7 + 1;
              iVar4 = *(int *)(&DAT_018ffd88 +
                              (*(int *)(&DAT_018ffd74 +
                                       ((uVar12 >> bVar13 & 1) * 2 | param_2 >> bVar15 & 1) * 4) +
                              uVar3 * 8) * 4);
              iVar6 = (uint)bVar16 + iVar4;
              if (iVar6 < 0) {
                iVar6 = 0;
              }
              else if (0xff < iVar6) {
                iVar6 = 0xff;
              }
              puVar19[-2] = (char)iVar6;
              iVar6 = (uint)bVar8 + iVar4;
              if (iVar6 < 0) {
                iVar6 = 0;
              }
              else if (0xff < iVar6) {
                iVar6 = 0xff;
              }
              puVar19[-1] = (char)iVar6;
              iVar4 = (uint)bVar14 + iVar4;
              if (iVar4 < 0) {
                iVar4 = 0;
              }
              else if (0xff < iVar4) {
                iVar4 = 0xff;
              }
              *puVar19 = (char)iVar4;
              puVar19 = puVar19 + param_4 * param_8;
              iVar5 = iVar5 + -1;
            } while (iVar5 != 0);
          }
          param_6 = param_6 + 1;
        } while (param_6 < iVar17);
        return;
      }
    }
    else {
      bVar7 = 2;
      if (param_6 < iVar17) {
        do {
          if (param_7 + 2 < param_7 + 4) {
            iStack_20 = 2;
            puVar19 = (undefined *)(param_3 + 2 + ((param_7 + 2) * param_4 + iStack_1c) * param_8);
            bVar13 = bVar7;
            do {
              bVar7 = bVar13 + 1;
              iVar5 = *(int *)(&DAT_018ffd88 +
                              (*(int *)(&DAT_018ffd74 +
                                       ((uVar12 >> (bVar13 & 0x1f) & 1) * 2 |
                                       param_2 >> (bVar13 & 0x1f) & 1) * 4) + uVar3 * 8) * 4);
              iVar4 = (uint)bVar16 + iVar5;
              if (iVar4 < 0) {
                iVar4 = 0;
              }
              else if (0xff < iVar4) {
                iVar4 = 0xff;
              }
              puVar19[-2] = (char)iVar4;
              iVar4 = (uint)bVar8 + iVar5;
              if (iVar4 < 0) {
                iVar4 = 0;
              }
              else if (0xff < iVar4) {
                iVar4 = 0xff;
              }
              puVar19[-1] = (char)iVar4;
              iVar5 = (uint)bVar14 + iVar5;
              if (iVar5 < 0) {
                iVar5 = 0;
              }
              else if (0xff < iVar5) {
                iVar5 = 0xff;
              }
              *puVar19 = (char)iVar5;
              puVar19 = puVar19 + param_4 * param_8;
              iStack_20 = iStack_20 + -1;
              bVar13 = bVar7;
            } while (iStack_20 != 0);
          }
          iStack_1c = iStack_1c + 1;
          bVar7 = bVar7 + 2;
        } while (iStack_1c < iVar17);
        return;
      }
    }
  }
  else {
    bVar13 = (byte)(param_1 >> 0xb) & 0x1f;
    bVar7 = (byte)(param_1 >> 0x13);
    bVar15 = bVar16 >> 5 | bVar16 & 0xf8;
    bVar9 = (bVar7 & 0x1f) >> 2 | bVar7 << 3;
    bVar10 = bVar13 >> 2 | bVar13 << 3;
    uVar3 = param_1 >> 5 & 7;
    uVar12 = param_2 >> 0x10;
    bVar11 = 0;
    param_2 = param_2 & 0xffff;
    iStack_14 = param_6;
    iStack_1c = param_6;
    if (uVar18 == 0) {
      if (param_6 < param_6 + 2) {
        do {
          if (param_7 < param_7 + 4) {
            puVar19 = (undefined *)(param_3 + 2 + (param_4 * param_7 + iStack_1c) * param_8);
            iVar17 = (param_7 + 4) - param_7;
            do {
              bVar1 = bVar11 & 0x1f;
              bVar2 = bVar11 & 0x1f;
              bVar11 = bVar11 + 1;
              iVar5 = *(int *)(&DAT_018ffd88 +
                              (*(int *)(&DAT_018ffd74 +
                                       ((uVar12 >> bVar1 & 1) * 2 | param_2 >> bVar2 & 1) * 4) +
                              uVar3 * 8) * 4);
              iVar4 = (uint)bVar15 + iVar5;
              if (iVar4 < 0) {
                iVar4 = 0;
              }
              else if (0xff < iVar4) {
                iVar4 = 0xff;
              }
              puVar19[-2] = (char)iVar4;
              iVar4 = (uint)bVar9 + iVar5;
              if (iVar4 < 0) {
                iVar4 = 0;
              }
              else if (0xff < iVar4) {
                iVar4 = 0xff;
              }
              puVar19[-1] = (char)iVar4;
              iVar5 = (uint)bVar10 + iVar5;
              if (iVar5 < 0) {
                iVar5 = 0;
              }
              else if (0xff < iVar5) {
                iVar5 = 0xff;
              }
              *puVar19 = (char)iVar5;
              puVar19 = puVar19 + param_4 * param_8;
              iVar17 = iVar17 + -1;
            } while (iVar17 != 0);
          }
          iStack_1c = iStack_1c + 1;
        } while (iStack_1c < param_6 + 2);
      }
    }
    else if (param_6 < param_6 + 4) {
      do {
        if (param_7 < param_7 + 2) {
          puVar19 = (undefined *)(param_3 + 2 + (param_4 * param_7 + iStack_1c) * param_8);
          iVar17 = (param_7 + 2) - param_7;
          do {
            bVar1 = bVar11 & 0x1f;
            bVar2 = bVar11 & 0x1f;
            bVar11 = bVar11 + 1;
            iVar5 = *(int *)(&DAT_018ffd88 +
                            (*(int *)(&DAT_018ffd74 +
                                     ((uVar12 >> bVar1 & 1) * 2 | param_2 >> bVar2 & 1) * 4) +
                            uVar3 * 8) * 4);
            iVar4 = (uint)bVar15 + iVar5;
            if (iVar4 < 0) {
              iVar4 = 0;
            }
            else if (0xff < iVar4) {
              iVar4 = 0xff;
            }
            puVar19[-2] = (char)iVar4;
            iVar4 = (uint)bVar9 + iVar5;
            if (iVar4 < 0) {
              iVar4 = 0;
            }
            else if (0xff < iVar4) {
              iVar4 = 0xff;
            }
            puVar19[-1] = (char)iVar4;
            iVar5 = (uint)bVar10 + iVar5;
            if (iVar5 < 0) {
              iVar5 = 0;
            }
            else if (0xff < iVar5) {
              iVar5 = 0xff;
            }
            *puVar19 = (char)iVar5;
            puVar19 = puVar19 + param_4 * param_8;
            iVar17 = iVar17 + -1;
          } while (iVar17 != 0);
        }
        iStack_1c = iStack_1c + 1;
        bVar11 = bVar11 + 2;
      } while (iStack_1c < param_6 + 4);
    }
    bStack_48 = bVar16 >> 3;
    bStack_48 = ((char)(bVar16 << 5) >> 5) + bStack_48;
    bVar16 = ((char)(bVar8 << 5) >> 5) + (bVar7 & 0x1f);
    bVar7 = bStack_48 >> 2 | bStack_48 * '\b';
    bVar13 = ((char)(bVar14 << 5) >> 5) + bVar13;
    bVar16 = bVar16 >> 2 | bVar16 * '\b';
    bVar8 = bVar13 >> 2 | bVar13 * '\b';
    uVar3 = param_1 >> 2 & 7;
    iVar17 = param_6 + 4;
    if (uVar18 == 0) {
      param_6 = param_6 + 2;
      bVar14 = 8;
      if (param_6 < iVar17) {
        do {
          if (param_7 < param_7 + 4) {
            puVar19 = (undefined *)(param_3 + 2 + (param_4 * param_7 + param_6) * param_8);
            iVar5 = (param_7 + 4) - param_7;
            do {
              bVar13 = bVar14 & 0x1f;
              bVar15 = bVar14 & 0x1f;
              bVar14 = bVar14 + 1;
              iVar4 = *(int *)(&DAT_018ffd88 +
                              (*(int *)(&DAT_018ffd74 +
                                       ((uVar12 >> bVar13 & 1) * 2 | param_2 >> bVar15 & 1) * 4) +
                              uVar3 * 8) * 4);
              iVar6 = (uint)bVar7 + iVar4;
              if (iVar6 < 0) {
                iVar6 = 0;
              }
              else if (0xff < iVar6) {
                iVar6 = 0xff;
              }
              puVar19[-2] = (char)iVar6;
              iVar6 = (uint)bVar16 + iVar4;
              if (iVar6 < 0) {
                iVar6 = 0;
              }
              else if (0xff < iVar6) {
                iVar6 = 0xff;
              }
              puVar19[-1] = (char)iVar6;
              iVar4 = (uint)bVar8 + iVar4;
              if (iVar4 < 0) {
                iVar4 = 0;
              }
              else if (0xff < iVar4) {
                iVar4 = 0xff;
              }
              *puVar19 = (char)iVar4;
              puVar19 = puVar19 + param_4 * param_8;
              iVar5 = iVar5 + -1;
            } while (iVar5 != 0);
          }
          param_6 = param_6 + 1;
        } while (param_6 < iVar17);
        return;
      }
    }
    else {
      bVar14 = 2;
      if (param_6 < iVar17) {
        do {
          if (param_7 + 2 < param_7 + 4) {
            iStack_2c = 2;
            puVar19 = (undefined *)(param_3 + 2 + ((param_7 + 2) * param_4 + iStack_14) * param_8);
            bVar13 = bVar14;
            do {
              bVar14 = bVar13 + 1;
              iVar5 = *(int *)(&DAT_018ffd88 +
                              (*(int *)(&DAT_018ffd74 +
                                       ((uVar12 >> (bVar13 & 0x1f) & 1) * 2 |
                                       param_2 >> (bVar13 & 0x1f) & 1) * 4) + uVar3 * 8) * 4);
              iVar4 = (uint)bVar7 + iVar5;
              if (iVar4 < 0) {
                iVar4 = 0;
              }
              else if (0xff < iVar4) {
                iVar4 = 0xff;
              }
              puVar19[-2] = (char)iVar4;
              iVar4 = (uint)bVar16 + iVar5;
              if (iVar4 < 0) {
                iVar4 = 0;
              }
              else if (0xff < iVar4) {
                iVar4 = 0xff;
              }
              puVar19[-1] = (char)iVar4;
              iVar5 = (uint)bVar8 + iVar5;
              if (iVar5 < 0) {
                iVar5 = 0;
              }
              else if (0xff < iVar5) {
                iVar5 = 0xff;
              }
              *puVar19 = (char)iVar5;
              puVar19 = puVar19 + param_4 * param_8;
              iStack_2c = iStack_2c + -1;
              bVar13 = bVar14;
            } while (iStack_2c != 0);
          }
          iStack_14 = iStack_14 + 1;
          bVar14 = bVar14 + 2;
        } while (iStack_14 < iVar17);
      }
    }
  }
  return;
}



/* FUNCTION 11962 ; VA 0x007d15a0 ; FUN_007d15a0 */

void FUN_007d15a0(uint param_1,uint param_2,int param_3,int param_4,undefined4 param_5,int param_6,
                 int param_7,int param_8)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  byte *pbVar4;
  byte bVar5;
  byte bVar6;
  uint uVar7;
  uint uVar8;
  byte bVar9;
  char cVar10;
  int iVar11;
  byte abStack_20 [6];
  byte bStack_1a;
  byte bStack_19;
  undefined4 uStack_18;
  uint uStack_14;
  int aiStack_10 [2];
  byte *pbStack_8;
  
  uVar2 = param_1;
  uStack_18 = param_1 >> 1;
  if ((uStack_18 & 1) != 0) {
    pbStack_8 = (byte *)(param_1 >> 0xb);
    uVar3 = param_1 >> 0x18;
    uStack_14 = param_1 >> 0x10;
    uVar8 = param_1 >> 0x13 & 0xffffff1f;
    bVar9 = (char)uVar8 + ((char)((char)(param_1 >> 0x10) << 5) >> 5);
    aiStack_10[0] = CONCAT31((int3)(uVar8 >> 8),bVar9);
    uVar7 = param_1 >> 0x1b;
    uVar8 = param_1 >> 8;
    param_1._0_1_ = (byte)(param_1 >> 0x18);
    if (0x1f < (byte)(((char)((byte)param_1 << 5) >> 5) + ((byte)param_1 >> 3))) {
      FUN_007d1aa0((uVar7 & 3) << 0x19 | uStack_18 & 0x1fffffe | uVar2 & 1,param_2,param_3,param_4,
                   param_5,param_6,param_7,param_8);
      return;
    }
    if (0x1f < bVar9) {
      uVar8 = uVar2 >> 3 & 0xfe00000;
      uVar3 = uVar8 | uVar2 & 0x180000;
      uVar7 = uVar3 >> 1 | uVar2 & 0x3fffc;
      abStack_20[4] = (byte)(uVar8 >> 0x18);
      abStack_20[5] = (byte)(uVar3 >> 0x14) & 0xf;
      uStack_14 = uVar7 >> 0xf;
      bStack_1a = (byte)uStack_14 & 0xf;
      bStack_19 = (byte)(uVar7 >> 0xb) & 0xf;
      bVar9 = ((byte)(uVar7 >> 1) & 3 | (byte)uVar2 & 1) * '\x02';
      uStack_18._1_3_ = (uint3)(uVar2 >> 9);
      uStack_18 = CONCAT31(uStack_18._1_3_,(char)(uVar7 >> 7)) & 0xffffff0f;
      uStack_18 = CONCAT22(uStack_18._2_2_,CONCAT11((char)(uVar7 >> 3),(undefined)uStack_18)) &
                  0xffff0fff;
      FUN_007d1c60(4,4,4,abStack_20 + 4,aiStack_10);
      bVar5 = bVar9 | 1;
      if (uStack_14 < (uVar2 & 0x7ff8) >> 3) {
        bVar5 = bVar9;
      }
      FUN_007cff00(bVar5,aiStack_10,abStack_20);
      cVar10 = '\0';
      aiStack_10[0] = 4;
      uStack_14 = param_4 * param_8;
      pbStack_8 = (byte *)(param_3 + 2 + (param_4 * param_7 + param_6) * param_8);
      do {
        bVar9 = cVar10 * '\x04';
        iVar11 = 4;
        pbVar4 = pbStack_8;
        do {
          bVar6 = bVar9 + 0x10;
          bVar5 = bVar9 & 0x1f;
          bVar9 = bVar9 + 1;
          iVar1 = (uint)(byte)(((byte)(param_2 >> (bVar6 & 0x1f)) & 1) * '\x02' |
                              (byte)(param_2 >> bVar5) & 1) * 3;
          pbVar4[-2] = abStack_20[iVar1];
          pbVar4[-1] = abStack_20[iVar1 + 1];
          *pbVar4 = abStack_20[iVar1 + 2];
          pbVar4 = pbVar4 + param_4 * param_8;
          iVar11 = iVar11 + -1;
        } while (iVar11 != 0);
        cVar10 = cVar10 + '\x01';
        pbStack_8 = pbStack_8 + param_8;
        aiStack_10[0] = aiStack_10[0] + -1;
      } while (aiStack_10[0] != 0);
      return;
    }
    if (0x1f < (byte)(((char)((char)uVar8 << 5) >> 5) + ((byte)pbStack_8 & 0x1f))) {
      FUN_007d1890((((((((uVar2 >> 0x11 & 0x3f | (uVar3 & 1) << 6) * 2 | uStack_14 & 1) << 2 |
                       (uint)pbStack_8 & 3) << 3 | uVar2 >> 7 & 7) << 5 | uVar2 >> 2 & 0x1f) * 2 |
                    uVar2 & 1) << 6 | uVar2 & 0xfe000000) * 2 | param_2 >> 0x19,
                   (((param_2 >> 0xd & 0x3f | (param_2 >> 0x13 & 0xff) << 6) << 7 |
                    param_2 >> 6 & 0x7f) << 6 | param_2 & 0x3f) << 7);
      return;
    }
  }
  FUN_007d0c00(uVar2,param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  return;
}



/* FUNCTION 11963 ; VA 0x007d1890 ; FUN_007d1890 */

void FUN_007d1890(uint param_1,uint param_2,int param_3,int param_4,undefined4 param_5,int param_6,
                 int param_7,int param_8)

{
  uint uVar1;
  byte bVar2;
  uint uVar3;
  byte bVar4;
  byte bVar5;
  byte bVar6;
  byte bVar7;
  int iVar8;
  int iVar9;
  byte bVar10;
  byte bVar11;
  int iVar12;
  int iVar13;
  byte bVar16;
  int iVar14;
  int iVar15;
  int iVar17;
  uint uVar18;
  int iVar19;
  int iVar20;
  undefined4 uStack_18;
  undefined4 uStack_8;
  
  bVar4 = (byte)(param_1 >> 0x13) & 0x7f;
  bVar2 = (byte)(param_1 >> 0x18);
  bVar5 = (byte)(param_1 >> 0xd) & 0x3f;
  bVar16 = bVar4 >> 6 | bVar4 * '\x02';
  bVar10 = (byte)param_1 & 0x7f;
  bVar4 = (byte)(param_1 >> 7) & 0x3f;
  bVar6 = (byte)(param_2 >> 0x14) & 0x3f;
  bVar7 = (byte)(param_2 >> 0xd) & 0x7f;
  bVar11 = (byte)(param_2 >> 7) & 0x3f;
  uVar3 = (uint)(byte)(bVar2 >> 6 | bVar2 & 0xfc);
  bVar2 = (byte)(param_2 >> 0x18);
  uVar18 = CONCAT11(bVar16,bVar5 >> 4 | bVar5 << 2) & 0xff;
  uVar1 = (uint)bVar16;
  iVar9 = uVar3 * 4 + 2;
  param_6 = param_6 * param_8;
  uStack_18 = 4;
  iVar13 = uVar1 * 4 + 2;
  iVar15 = uVar18 * 4 + 2;
  do {
    uStack_8 = 4;
    iVar14 = iVar9;
    iVar17 = iVar13;
    iVar19 = iVar15;
    iVar20 = param_7;
    do {
      iVar8 = iVar14 >> 2;
      if (iVar8 < 0) {
        iVar8 = 0;
      }
      else if (0xff < iVar8) {
        iVar8 = 0xff;
      }
      iVar12 = param_4 * param_8 * iVar20 + param_6;
      *(char *)(iVar12 + param_3) = (char)iVar8;
      iVar8 = iVar17 >> 2;
      if (iVar8 < 0) {
        iVar8 = 0;
      }
      else if (0xff < iVar8) {
        iVar8 = 0xff;
      }
      *(char *)(iVar12 + 1 + param_3) = (char)iVar8;
      iVar8 = iVar19 >> 2;
      if (iVar8 < 0) {
        iVar8 = 0;
      }
      else if (0xff < iVar8) {
        iVar8 = 0xff;
      }
      iVar17 = iVar17 + ((byte)(bVar7 >> 6 | bVar7 * '\x02') - uVar1);
      iVar20 = iVar20 + 1;
      iVar19 = iVar19 + ((byte)(bVar11 >> 4 | bVar11 << 2) - uVar18);
      *(char *)(iVar12 + 2 + param_3) = (char)iVar8;
      iVar14 = iVar14 + ((byte)(bVar6 >> 4 | bVar6 << 2) - uVar3);
      uStack_8 = uStack_8 + -1;
    } while (uStack_8 != 0);
    param_6 = param_6 + param_8;
    iVar15 = iVar15 + ((byte)(bVar2 >> 6 | bVar2 & 0xfc) - uVar18);
    iVar13 = iVar13 + ((byte)(bVar10 >> 6 | bVar10 * '\x02') - uVar1);
    iVar9 = iVar9 + ((byte)(bVar4 >> 4 | bVar4 << 2) - uVar3);
    uStack_18 = uStack_18 + -1;
  } while (uStack_18 != 0);
  return;
}



/* FUNCTION 11964 ; VA 0x007d1aa0 ; FUN_007d1aa0 */

void FUN_007d1aa0(uint param_1,uint param_2,int param_3,int param_4,undefined4 param_5,int param_6,
                 int param_7,int param_8)

{
  byte bVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined *puVar5;
  byte bVar6;
  uint uVar7;
  char cVar8;
  byte bVar9;
  undefined auStack_24 [6];
  byte bStack_1e;
  byte bStack_1d;
  byte bStack_1c;
  undefined uStack_1b;
  undefined uStack_1a;
  undefined uStack_19;
  uint uStack_18;
  undefined4 uStack_14;
  int iStack_10;
  undefined4 uStack_c;
  byte bStack_8;
  byte bStack_7;
  
  uStack_18 = CONCAT13((char)(param_1 >> 0xb),
                       CONCAT12((char)(param_1 >> 0xf),
                                CONCAT11((char)(param_1 >> 0x13),(char)(param_1 >> 0x17)))) &
              0xf0f0f0f;
  uStack_14 = CONCAT31(uStack_14._1_3_,(char)(param_1 >> 7)) & 0xffffff0f;
  uStack_14 = CONCAT22(uStack_14._2_2_,CONCAT11((char)(param_1 >> 3),(undefined)uStack_14)) &
              0xffff0fff;
  FUN_007d1c60(4,4,4,&uStack_18,&uStack_c);
  uStack_18 = 0x100b0603;
  uStack_14 = 0x40292017;
  uVar7 = (uint)*(byte *)((int)&uStack_18 + (param_1 & 7));
  iVar3 = uStack_c._3_1_ - uVar7;
  if (iVar3 < 0) {
    iVar3 = 0;
  }
  else if (0xff < iVar3) {
    iVar3 = 0xff;
  }
  uStack_1b = (char)iVar3;
  iVar3 = bStack_8 - uVar7;
  if (iVar3 < 0) {
    iVar3 = 0;
  }
  else if (0xff < iVar3) {
    iVar3 = 0xff;
  }
  uStack_1a = (char)iVar3;
  iVar3 = bStack_7 - uVar7;
  if (iVar3 < 0) {
    iVar3 = 0;
  }
  else if (0xff < iVar3) {
    iVar3 = 0xff;
  }
  uStack_19 = (char)iVar3;
  auStack_24[0] = (undefined)uStack_c;
  auStack_24[1] = uStack_c._1_1_;
  auStack_24[2] = uStack_c._2_1_;
  uVar4 = uStack_c._3_1_ + uVar7;
  bStack_1c = bStack_7;
  bStack_1e = uStack_c._3_1_;
  bStack_1d = bStack_8;
  if (0xff < uVar4) {
    uVar4 = 0xff;
  }
  auStack_24[3] = (char)uVar4;
  uVar4 = bStack_8 + uVar7;
  iStack_10 = 4;
  if (0xff < uVar4) {
    uVar4 = 0xff;
  }
  auStack_24[4] = (char)uVar4;
  uVar7 = bStack_7 + uVar7;
  if (0xff < uVar7) {
    uVar7 = 0xff;
  }
  cVar8 = '\0';
  auStack_24[5] = (char)uVar7;
  uStack_14 = param_4 * param_8;
  uStack_c = (undefined *)(param_3 + 2 + (param_4 * param_7 + param_6) * param_8);
  do {
    bVar9 = cVar8 * '\x04';
    iVar3 = 4;
    puVar5 = uStack_c;
    do {
      bVar6 = bVar9 + 0x10;
      bVar1 = bVar9 & 0x1f;
      bVar9 = bVar9 + 1;
      iVar2 = (uint)(byte)(((byte)(param_2 >> (bVar6 & 0x1f)) & 1) * '\x02' |
                          (byte)(param_2 >> bVar1) & 1) * 3;
      puVar5[-2] = auStack_24[iVar2];
      puVar5[-1] = auStack_24[iVar2 + 1];
      *puVar5 = auStack_24[iVar2 + 2];
      puVar5 = puVar5 + param_4 * param_8;
      iVar3 = iVar3 + -1;
    } while (iVar3 != 0);
    cVar8 = cVar8 + '\x01';
    uStack_c = uStack_c + param_8;
    iStack_10 = iStack_10 + -1;
  } while (iStack_10 != 0);
  return;
}



/* FUNCTION 11965 ; VA 0x007d1c60 ; FUN_007d1c60 */

void FUN_007d1c60(char param_1,char param_2,char param_3,byte *param_4,byte *param_5)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  
  bVar1 = param_1 * '\x02' - 8;
  *param_5 = *param_4 >> (bVar1 & 0x1f) | *param_4 << (8U - param_1 & 0x1f);
  bVar2 = param_2 * '\x02' - 8;
  param_5[1] = param_4[1] >> (bVar2 & 0x1f) | param_4[1] << (8U - param_2 & 0x1f);
  bVar3 = param_3 * '\x02' - 8;
  param_5[2] = param_4[2] >> (bVar3 & 0x1f) | param_4[2] << (8U - param_3 & 0x1f);
  param_5[3] = param_4[3] >> (bVar1 & 0x1f) | param_4[3] << (8U - param_1 & 0x1f);
  param_5[4] = param_4[4] >> (bVar2 & 0x1f) | param_4[4] << (8U - param_2 & 0x1f);
  param_5[5] = param_4[5] >> (bVar3 & 0x1f) | param_4[5] << (8U - param_3 & 0x1f);
  return;
}



/* FUNCTION 11966 ; VA 0x007d1d30 ; FUN_007d1d30 */

void FUN_007d1d30(int param_1,int param_2,int param_3,int param_4)

{
  undefined uVar1;
  uint uVar2;
  uint uVar3;
  
  uVar3 = 0;
  uVar2 = param_2 * param_3 * param_4;
  if (uVar2 != 0) {
    do {
      uVar1 = *(undefined *)(param_1 + uVar3 * 4);
      *(undefined *)(param_1 + uVar3 * 4) = *(undefined *)(param_1 + 2 + uVar3 * 4);
      *(undefined *)(param_1 + 2 + uVar3 * 4) = uVar1;
      uVar3 = uVar3 + 1;
    } while (uVar3 < uVar2);
  }
  return;
}



/* FUNCTION 11967 ; VA 0x007d1d70 ; FUN_007d1d70 */

void FUN_007d1d70(int *param_1,int *param_2,byte param_3)

{
  int iVar1;
  undefined4 uVar2;
  uint *puVar3;
  uint uVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  undefined *puVar8;
  uint uVar9;
  undefined4 auStack_6c [16];
  undefined4 auStack_2c [8];
  uint uStack_c;
  uint uStack_8;
  
  if (*param_2 != 0) {
    *param_1 = 0;
    return;
  }
  uVar4 = param_2[2];
  uVar9 = param_2[5];
  uVar6 = param_2[3];
  for (uVar7 = 0; ((4 < uVar4 || (4 < uVar6)) && (uVar7 < uVar9)); uVar7 = uVar7 + 1) {
    uVar4 = uVar4 >> 1;
    if (uVar4 == 0) {
      uVar4 = 1;
    }
    uVar6 = uVar6 >> 1;
    if (uVar6 == 0) {
      uVar6 = 1;
    }
  }
  uStack_c = uVar6;
  if (uVar7 < uVar9) {
    iVar1 = param_2[1];
    puVar8 = (undefined *)(*(int *)(param_2[7] + uVar7 * 4) + param_2[10]);
    uVar9 = uVar6 * uVar4;
    uStack_8 = uVar9;
    switch(iVar1) {
    case 2:
      uVar7 = 0;
      if (uVar9 != 0) {
        do {
          uVar2 = FUN_007d0270(*(undefined2 *)(puVar8 + uVar7 * 2));
          auStack_6c[uVar7] = uVar2;
          uVar7 = uVar7 + 1;
          uVar6 = uStack_c;
        } while (uVar7 < uVar9);
      }
      break;
    case 3:
      if ((param_3 & 4) == 0) {
        FUN_0170c6f0(auStack_6c,puVar8,uVar9 * 4);
      }
      else {
        uVar7 = 0;
        if (uVar9 != 0) {
          do {
            auStack_6c[uVar7] = CONCAT31(CONCAT21(CONCAT11(puVar8[3],*puVar8),puVar8[1]),puVar8[2]);
            uVar7 = uVar7 + 1;
            puVar8 = puVar8 + 4;
          } while (uVar7 < uVar9);
        }
      }
      break;
    default:
      *param_1 = 0;
      return;
    case 0xe:
    case 0xf:
    case 0x10:
      FUN_007d02c0(auStack_6c,puVar8,uVar4,uVar6,1,iVar1);
      break;
    case 0x13:
      FUN_007d04c0(auStack_2c,puVar8,uVar4,uVar6,iVar1);
      uVar7 = 0;
      if (uVar9 != 0) {
        do {
          uVar2 = FUN_007d0270(*(undefined2 *)((int)auStack_2c + uVar7 * 2));
          auStack_6c[uVar7] = uVar2;
          uVar7 = uVar7 + 1;
        } while (uVar7 < uVar9);
      }
      break;
    case 0x14:
    case 0x15:
      FUN_007d0660(auStack_6c,puVar8,uVar4,uVar6,iVar1);
    }
  }
  else {
    uVar4 = 1;
    uVar6 = 1;
    iVar1 = param_2[1];
    puVar5 = (undefined4 *)(*(int *)(param_2[7] + -4 + uVar9 * 4) + param_2[10]);
    uVar2 = 0;
    switch(iVar1) {
    case 2:
      auStack_6c[0] = FUN_007d0270(*(undefined2 *)puVar5);
      break;
    case 3:
      if ((param_3 & 4) == 0) {
        auStack_6c[0] = *puVar5;
      }
      else {
        auStack_6c[0] =
             CONCAT31(CONCAT21(CONCAT11(*(undefined *)((int)puVar5 + 3),*(undefined *)puVar5),
                               *(undefined *)((int)puVar5 + 1)),*(undefined *)((int)puVar5 + 2));
      }
      break;
    case 0xe:
    case 0xf:
    case 0x10:
      FUN_007d02c0(auStack_6c,puVar5,4,4,1,iVar1);
      break;
    case 0x13:
      FUN_007d04c0(auStack_2c,puVar5,4,4,iVar1);
      auStack_6c[0] = FUN_007d0270(auStack_2c[0]);
      break;
    case 0x14:
    case 0x15:
      FUN_007d0660(auStack_6c,puVar5,4,4,iVar1);
      uVar2 = auStack_6c[0];
    default:
      auStack_6c[0] = uVar2;
    }
  }
  puVar3 = (uint *)FUN_01674e20(0x48);
  *puVar3 = uVar4;
  puVar3[1] = uVar6;
  FUN_0170c6f0(puVar3 + 2,auStack_6c,uVar6 * uVar4 * 4);
  *param_1 = (int)puVar3;
  return;
}



/* FUNCTION 11968 ; VA 0x007d2060 ; FUN_007d2060 */

int FUN_007d2060(uint param_1,uint param_2,uint param_3,uint param_4)

{
  int iVar1;
  
  iVar1 = 0;
  for (; ((param_4 < param_1 || (param_4 < param_2)) || (param_4 < param_3)); param_3 = param_3 >> 1
      ) {
    iVar1 = iVar1 + 1;
    param_1 = param_1 >> 1;
    param_2 = param_2 >> 1;
  }
  return iVar1;
}



/* FUNCTION 11969 ; VA 0x007d2090 ; FUN_007d2090 */

int __thiscall FUN_007d2090(int param_1,int param_2,int param_3)

{
  return *(int *)(*(int *)(param_1 + 0x1c) + (*(int *)(param_1 + 0x14) * param_2 + param_3) * 4) +
         *(int *)(param_1 + 0x28);
}



/* FUNCTION 11970 ; VA 0x007d20b0 ; FUN_007d20b0 */

void __fastcall FUN_007d20b0(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar2 = *(int *)(param_1 + 0x48);
  iVar1 = *(int *)(param_1 + 0x4c);
  **(int **)(param_1 + 0xc) = iVar2;
  **(int **)(param_1 + 0x1c) = iVar2;
  **(int **)(param_1 + 0x2c) = iVar1 - iVar2;
  if ((((*(int *)(param_1 + 0x48) != 0) && (iVar2 = *(int *)(param_1 + 0x50), iVar2 != 0)) &&
      (*(int *)(param_1 + 0x48) == iVar2)) && (**(int **)(param_1 + 0x20) != 0)) {
    iVar2 = **(int **)(param_1 + 0x20) - iVar2;
    **(int **)(param_1 + 0x2c) = **(int **)(param_1 + 0x2c) - iVar2;
    **(int **)(param_1 + 0x1c) = **(int **)(param_1 + 0x1c) + iVar2;
    **(undefined4 **)(param_1 + 0x10) = 0;
    **(undefined4 **)(param_1 + 0x20) = 0;
    **(undefined4 **)(param_1 + 0x30) = 0;
  }
  return;
}



/* FUNCTION 11971 ; VA 0x007d2110 ; FUN_007d2110 */

undefined4 * FUN_007d2110(undefined4 *param_1,int *param_2,undefined4 *param_3,undefined4 param_4)

{
  int *piVar1;
  undefined4 uVar2;
  code *pcVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  undefined auStack_94 [64];
  undefined auStack_54 [32];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017b3b09;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_0170d1f0(auStack_94,0,0x40);
  piVar5 = param_2;
  FUN_005af630(auStack_94,0x40,0);
  iStack_18 = piVar5[3];
  param_2 = (int *)FUN_011602a0(auStack_94,piVar5[2],5);
  if (param_2 != (int *)0x6) {
    uVar7 = 4;
    if (*(int *)((int)piVar5 + *(int *)(*piVar5 + 4) + 0x38) != 0) {
      uVar7 = 0;
    }
    FUN_00554460(uVar7,0);
    FUN_007d4c20(0,0,0,0,0);
    uStack_34 = 0;
    uStack_30 = 0;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
    piStack_20 = (int *)0x0;
    uStack_1c = 0;
    iStack_18 = 0;
    FUN_007cf090(&uStack_1c,&uStack_34);
    piVar6 = piStack_20;
    uStack_8 = 0;
    uStack_14 = 1;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_20[1] + -1;
      piStack_20[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    uVar7 = param_4;
    iVar4 = (int)param_2;
    if (param_2 == (int *)0x3) {
      FUN_007d26f0(auStack_54,piVar5,*param_3,param_4);
    }
    else if (param_2 == (int *)0x4) {
      FUN_007d2f00(auStack_54,piVar5,*param_3,param_4);
    }
    else {
      uVar2 = param_3[1];
      FUN_0115f610(0,0,3);
      uStack_8 = 1;
      FUN_007d08a0(&uStack_30,iVar4,piVar5);
      uVar7 = param_4;
      FUN_007d3560(auStack_54,&uStack_30,uVar2,param_4);
      uStack_14 = 3;
      uStack_8 = uStack_8 & 0xffffff00;
      FUN_0115f820();
    }
    FUN_007cf320();
    FUN_0077f500();
    if ((char)uVar7 < '\0') {
      FUN_007d1d70(&param_2,*param_1,uVar7);
      uStack_8 = 2;
      FUN_007ce5d0();
      if (param_2 != (int *)0x0) {
        FUN_01674ea0(param_2,0x48);
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_007d4d90(auStack_94,0x40);
  pcVar3 = (code *)swi(3);
  puVar8 = (undefined4 *)(*pcVar3)();
  return puVar8;
}



/* FUNCTION 11972 ; VA 0x007d2350 ; FUN_007d2350 */

undefined4 *
FUN_007d2350(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  uint uVar8;
  undefined4 *puStack_108;
  undefined4 *puStack_104;
  undefined4 *puStack_f8;
  undefined4 *puStack_f4;
  undefined4 *puStack_e8;
  undefined4 *puStack_e4;
  int iStack_cc;
  int iStack_c4;
  int iStack_b8;
  undefined **appuStack_b4 [6];
  undefined **appuStack_9c [8];
  int aiStack_7c [10];
  undefined auStack_54 [32];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puVar4 = param_2;
  puStack_c = &LAB_017b3b83;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  puVar7 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar7 = (undefined4 *)*param_2;
  }
  uVar8 = param_2[4];
  if (0x40 < uVar8) {
    uVar8 = 0x40;
  }
  ExceptionList = &pvStack_10;
  param_2 = (undefined4 *)FUN_011602a0(puVar7,uVar8,5);
  if (param_2 == (undefined4 *)0x6) {
LAB_007d26de:
    FUN_007d4d90(puVar7,uVar8);
    pcVar2 = (code *)swi(3);
    puVar7 = (undefined4 *)(*pcVar2)();
    return puVar7;
  }
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  uStack_34 = 0;
  uStack_30 = 0;
  FUN_007cf090(&uStack_34,&uStack_2c);
  piVar5 = piStack_18;
  uStack_8 = 0;
  uStack_14 = 1;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  uVar8 = (uint)param_2;
  if ((param_2 != (undefined4 *)0x3) && (param_2 != (undefined4 *)0x4)) {
    uVar6 = param_3[1];
    FUN_0115f610(0,0,3);
    uStack_8 = 6;
    FUN_007d09e0(&uStack_28,param_2,puVar4);
    FUN_007d3560(auStack_54,&uStack_28,uVar6,param_4);
    uStack_14 = 5;
    uStack_8 = uStack_8 & 0xffffff00;
    FUN_0115f820();
    FUN_007cf320(auStack_54);
    FUN_0077f500();
    goto LAB_007d266d;
  }
  param_2 = (undefined4 *)puVar4[4];
  appuStack_b4[0] = &PTR_019003ac;
  appuStack_9c[0] = std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
  uStack_8 = 1;
  uStack_14 = 3;
  FUN_007ceca0(0);
  uStack_8 = 2;
  *(undefined ***)((int)appuStack_b4 + (int)appuStack_b4[0][1]) =
       boost::iostreams::
       stream<struct_boost::iostreams::basic_array_source<char>,struct_std::char_traits<char>,class_std::allocator<char>_>
       ::vftable;
  *(undefined **)((int)&iStack_b8 + (int)appuStack_b4[0][1]) = appuStack_b4[0][1] + -0x18;
  uVar6 = 4;
  if (*(int *)((int)aiStack_7c + (int)appuStack_b4[0][1]) != 0) {
    uVar6 = 0;
  }
  FUN_00554460(uVar6,0);
  if ((iStack_cc != 0) || (iStack_c4 != 0)) {
    uVar6 = FUN_00555250(&uStack_34,1);
    uVar6 = FUN_0054ff80("already open",uVar6);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_007ceab0(uVar6);
    puVar7 = param_1;
    goto LAB_007d26de;
  }
  *puStack_108 = 0;
  *puStack_f8 = 0;
  *puStack_e8 = 0;
  *puStack_104 = 0;
  *puStack_f4 = 0;
  *puStack_e4 = 0;
  uStack_8 = 4;
  if (uVar8 == 3) {
    uVar6 = FUN_007d26f0(auStack_54,appuStack_b4,*param_3,param_4);
LAB_007d2604:
    FUN_007cf320(uVar6);
    FUN_0077f500();
  }
  else if (uVar8 == 4) {
    uVar6 = FUN_007d2f00(auStack_54,appuStack_b4,*param_3,param_4);
    goto LAB_007d2604;
  }
  *(undefined ***)((int)appuStack_b4 + (int)appuStack_b4[0][1]) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)((int)&iStack_b8 + (int)appuStack_b4[0][1]) = appuStack_b4[0][1] + -0x18;
  FUN_007cf230();
  uStack_8 = 5;
  appuStack_9c[0] = std::ios_base::vftable;
  FUN_016de551(appuStack_9c);
  uStack_8 = uStack_8 & 0xffffff00;
LAB_007d266d:
  if ((char)param_4 < '\0') {
    uVar6 = FUN_007d1d70(&param_2,*param_1,param_4);
    uStack_8 = 7;
    FUN_007ce5d0(uVar6);
    if (param_2 != (undefined4 *)0x0) {
      FUN_01674ea0(param_2,0x48);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11973 ; VA 0x007d26f0 ; FUN_007d26f0 */

undefined4 FUN_007d26f0(undefined4 param_1,int param_2,undefined4 param_3,uint param_4)

{
  int *piVar1;
  char cVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  uint uVar7;
  int iVar8;
  undefined4 *puVar9;
  int iVar10;
  uint uVar11;
  int *piStack_e8;
  undefined4 auStack_e4 [2];
  byte abStack_dc [12];
  undefined auStack_d0 [8];
  uint uStack_c8;
  uint uStack_c4;
  uint uStack_bc;
  uint uStack_b8;
  int iStack_80;
  int iStack_7c;
  int iStack_78;
  int iStack_74;
  int iStack_70;
  int iStack_6c;
  uint uStack_64;
  undefined4 uStack_54;
  int iStack_50;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  int iStack_40;
  uint uStack_3c;
  uint uStack_38;
  undefined4 uStack_34;
  int iStack_30;
  uint uStack_2c;
  char cStack_25;
  undefined auStack_24 [4];
  int iStack_20;
  int *piStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3baf;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005af630(&iStack_50,4,0);
  if ((*(int *)(param_2 + 8) != 4) || (*(int *)(param_2 + 0xc) != 0)) {
    uVar4 = 4;
LAB_007d2d14:
    FUN_016756b0(auStack_24,"Unexpected end of file while reading %d bytes",uVar4);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_24,&DAT_01c17198);
  }
  FUN_005af630(auStack_d0,0x7c,0);
  if ((*(int *)(param_2 + 8) != 0x7c) || (*(int *)(param_2 + 0xc) != 0)) {
    uVar4 = 0x7c;
    goto LAB_007d2d14;
  }
  puVar9 = (undefined4 *)0x0;
  if (iStack_80 == 0x30315844) {
    FUN_005af630(auStack_e4,0x14,0);
    if ((*(int *)(param_2 + 8) != 0x14) || (*(int *)(param_2 + 0xc) != 0)) {
      uVar4 = 0x14;
      goto LAB_007d2d14;
    }
    puVar9 = auStack_e4;
  }
  if (iStack_50 != 0x20534444) {
    FUN_016756b0(auStack_24,"Invalid DDS header");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_24,&DAT_01c17198);
  }
  if ((uStack_c4 == 0) || (uStack_c8 == 0)) {
    FUN_016756b0(auStack_24,"Invalid DDS header: width/height is zero");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_24,&DAT_01c17198);
  }
  if (puVar9 == (undefined4 *)0x0) {
    if ((uStack_64 & 0x200000) == 0) {
      if ((uStack_64 & 0x200) == 0) {
        uStack_18 = 0;
      }
      else {
        if ((uStack_64 & 0xfc00) != 0xfc00) {
          FUN_016756b0(auStack_24,"Unsupported DDS: not all cubemap faces are present");
                    /* WARNING: Subroutine does not return */
          FUN_0170c2a8(auStack_24,&DAT_01c17198);
        }
        uStack_18 = 2;
      }
    }
    else {
      if (uStack_bc == 0) {
        FUN_016756b0(auStack_24,"Invalid DDS header: depth is zero");
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_24,&DAT_01c17198);
      }
      uStack_18 = 1;
    }
    if (iStack_80 != 0) {
      if (iStack_80 == 0x71) {
        iVar8 = 8;
        goto LAB_007d293b;
      }
      if (iStack_80 != 0x31545844) {
        if (iStack_80 != 0x33545844) {
          if (iStack_80 != 0x35545844) {
            if (iStack_80 == 0x30315844) {
              FUN_016756b0(auStack_24,"Unsupported DDS: DX10 FourCC");
                    /* WARNING: Subroutine does not return */
              FUN_0170c2a8(auStack_24,&DAT_01c17198);
            }
            FUN_016756b0(auStack_24,"Unsupported DDS: unknown FourCC %d",iStack_80);
                    /* WARNING: Subroutine does not return */
            FUN_0170c2a8(auStack_24,&DAT_01c17198);
          }
          goto switchD_007d2823_caseD_4d;
        }
        goto switchD_007d2823_caseD_4a;
      }
      goto switchD_007d2823_caseD_47;
    }
    if (iStack_7c == 8) {
      if ((((iStack_78 != 0xff) || (iStack_74 != 0)) || (iStack_70 != 0)) || (iStack_6c != 0))
      goto LAB_007d2dd1;
      goto switchD_007d2823_caseD_3d;
    }
    if (iStack_7c == 0x10) {
      if (((iStack_78 != 0xff) || (iStack_74 != 0)) || ((iStack_70 != 0 || (iStack_6c != 0xff00))))
      goto LAB_007d2dd1;
      goto switchD_007d2823_caseD_31;
    }
    if (iStack_7c != 0x20) {
LAB_007d2dd1:
      FUN_016756b0(auStack_24,"Unsupported DDS: custom non-compressed %d-bit format",iStack_7c);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_24,&DAT_01c17198);
    }
switchD_007d2823_caseD_1c:
    iVar8 = 3;
  }
  else {
    iVar8 = puVar9[1];
    if (iVar8 == 2) {
      uStack_18 = 0;
    }
    else if (iVar8 == 3) {
      if ((*(byte *)(puVar9 + 2) & 4) == 0) {
        uStack_18 = -(uint)(1 < (uint)puVar9[3]) & 3;
      }
      else {
        if (puVar9[3] != 1) {
          FUN_016756b0(auStack_24,"Invalid DDS header: Cube array size (%d), only 1 supported",
                       puVar9[3]);
                    /* WARNING: Subroutine does not return */
          FUN_0170c2a8(auStack_24,&DAT_01c17198);
        }
        uStack_18 = 2;
      }
    }
    else {
      if (iVar8 != 4) {
        FUN_016756b0(auStack_24,"Invalid DDS header: unrecognized resource dimension (%d)",iVar8);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_24,&DAT_01c17198);
      }
      uStack_18 = 1;
    }
    switch(*puVar9) {
    case 10:
      iVar8 = 8;
      break;
    default:
      FUN_016756b0(auStack_24,"Unsupported DDS: unknown DX10 format (%d)",*puVar9);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_24,&DAT_01c17198);
    case 0x1c:
      goto switchD_007d2823_caseD_1c;
    case 0x22:
      iVar8 = 7;
      break;
    case 0x31:
switchD_007d2823_caseD_31:
      iVar8 = 1;
      break;
    case 0x3d:
switchD_007d2823_caseD_3d:
      iVar8 = 0;
      break;
    case 0x47:
switchD_007d2823_caseD_47:
      iVar8 = 0xe;
      break;
    case 0x4a:
switchD_007d2823_caseD_4a:
      iVar8 = 0xf;
      break;
    case 0x4d:
switchD_007d2823_caseD_4d:
      iVar8 = 0x10;
    }
  }
LAB_007d293b:
  iStack_14 = iVar8;
  cVar2 = FUN_0147d280(iVar8);
  uVar7 = uStack_18;
  if ((cVar2 == '\0') || (iStack_30 = 3, (param_4 & 1) == 0)) {
    iStack_30 = iVar8;
  }
  iStack_40 = 1;
  if (uStack_18 == 2) {
    iStack_40 = 6;
  }
  if (uStack_18 == 3) {
    uStack_3c = puVar9[3];
  }
  else {
    uStack_3c = 1;
  }
  uVar3 = 1;
  if (uStack_18 == 1) {
    uVar3 = uStack_bc;
  }
  uStack_4c = uVar3;
  uStack_38 = FUN_0147d0e0(uStack_c4,uStack_c8,uVar3);
  if (uStack_b8 == 0) {
    uStack_38 = 1;
  }
  else if (((param_4 >> 3 & 1) == 0) || (uStack_b8 == 1)) {
    uStack_38 = uStack_b8;
  }
  uVar11 = uStack_38;
  if (((param_4 & 2) != 0) &&
     ((((-uStack_c4 & uStack_c4) != uStack_c4 || ((-uStack_c8 & uStack_c8) != uStack_c8)) ||
      ((-uVar3 & uVar3) != uVar3)))) {
    FUN_016756b0(auStack_24,"Unsupported DDS: non-power-of-two image needs to be resized");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_24,&DAT_01c17198);
  }
  uVar3 = FUN_007d2060(uStack_c4,uStack_c8,uVar3,param_3);
  uStack_44 = uVar3;
  if (uVar3 < uVar11) {
    uStack_2c = FUN_01674e20(0x30);
    uStack_8 = 0;
    if (uStack_2c == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_0147d110(uStack_4c,uVar3);
      uVar5 = FUN_0147d110(uStack_c8,uVar3);
      uVar6 = FUN_0147d110(uStack_c4,uStack_44);
      uVar4 = FUN_007cef10(uVar7,iStack_30,uVar6,uVar5,uVar4,uStack_38 - uStack_44,uStack_3c);
      uVar11 = uStack_38;
    }
    uStack_8 = 0xffffffff;
    FUN_007ce5a0(uVar4);
    uVar7 = uStack_3c * iStack_40;
    uStack_8 = 1;
    uStack_48 = 0;
    uStack_3c = uVar7;
    if (uVar7 != 0) {
      do {
        uStack_2c = 0;
        if (uVar11 != 0) {
          do {
            uVar7 = uStack_2c;
            iVar8 = FUN_0147d110(uStack_c4,uStack_2c);
            iStack_40 = iVar8;
            uVar4 = FUN_0147d110(uStack_c8,uVar7);
            uStack_34 = uVar4;
            uStack_18 = FUN_0147d110(uStack_4c,uVar7);
            iVar8 = FUN_0147d000(iStack_14,iVar8,uVar4);
            iVar8 = iVar8 * uStack_18;
            if (uVar7 < uStack_44) {
              FUN_005956d0(iVar8,0,1);
            }
            else {
              iVar10 = *(int *)(*(int *)(iStack_20 + 0x1c) +
                               ((*(int *)(iStack_20 + 0x14) * uStack_48 - uStack_44) + uVar7) * 4) +
                       *(int *)(iStack_20 + 0x28);
              if (iStack_30 == iStack_14) {
                FUN_007d3f40(param_2,iVar10);
                iVar8 = iStack_40;
                if (iStack_30 == 3) {
                  cStack_25 = iStack_70 == 0xff;
                  uStack_2c = param_4 >> 2 & 0xffffff01;
                  if (DAT_01d61dc0 != '\0') {
                    FUN_007d4e80(iVar10,3,iStack_40,uStack_34,uStack_18);
                  }
                  if (cStack_25 != (char)uStack_2c) {
                    FUN_007d1d30(iVar10,iVar8,uStack_34,uStack_18);
                  }
                }
              }
              else {
                uVar4 = FUN_01674e20(iVar8);
                uStack_8 = CONCAT31(uStack_8._1_3_,2);
                uStack_54 = uVar4;
                FUN_007d3f40(param_2,uVar4,iVar8);
                iVar8 = iStack_40;
                FUN_007d02c0(iVar10,uVar4,iStack_40,uStack_34,uStack_18,iStack_14);
                if (DAT_01d61dc0 != '\0') {
                  FUN_007d4e80(iVar10,iStack_30,iVar8,uStack_34,uStack_18);
                }
                if ((param_4 & 4) != 0) {
                  FUN_007d1d30(iVar10,iVar8,uStack_34,uStack_18);
                }
                uStack_8 = CONCAT31(uStack_8._1_3_,1);
                FUN_01674ea0(uVar4);
                uVar7 = uStack_2c;
              }
            }
            uStack_2c = uVar7 + 1;
            uVar7 = uStack_3c;
            uVar11 = uStack_38;
          } while (uStack_2c < uStack_38);
        }
        uStack_48 = uStack_48 + 1;
      } while (uStack_48 < uVar7);
    }
    uVar4 = FUN_00773510(uStack_c4,uStack_c8,1,0,0,0);
    FUN_007cf090(&iStack_20,uVar4);
    if (piStack_e8 != (int *)0x0) {
      LOCK();
      iVar8 = piStack_e8[1] + -1;
      piStack_e8[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_e8)();
        LOCK();
        iVar8 = piStack_e8[2] + -1;
        piStack_e8[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piStack_e8 + 4))();
        }
      }
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar8 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piStack_1c + 2;
        iVar8 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar8 == 1) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_24,"Unsupported DDS: %d out of %d mipmap levels need to be skipped",uVar3,
               uVar11);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_24,&DAT_01c17198);
}



/* FUNCTION 11974 ; VA 0x007d2f00 ; FUN_007d2f00 */

undefined4 FUN_007d2f00(undefined4 param_1,int param_2,uint param_3,uint param_4)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  char cVar8;
  uint uVar9;
  uint uVar10;
  int iVar11;
  uint uVar12;
  int iVar13;
  int *piStack_94;
  int iStack_90;
  int iStack_8c;
  int iStack_88;
  int iStack_78;
  int iStack_74;
  uint uStack_6c;
  uint uStack_68;
  uint uStack_58;
  int iStack_54;
  uint uStack_50;
  int iStack_4c;
  uint uStack_48;
  uint uStack_44;
  int iStack_40;
  int iStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined4 uStack_30;
  undefined auStack_2c [4];
  int iStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  uint uStack_18;
  char cStack_13;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3bdf;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005af630(&iStack_90,0x40,0);
  if ((*(int *)(param_2 + 8) != 0x40) || (*(int *)(param_2 + 0xc) != 0)) {
    FUN_016756b0(auStack_2c,"Unexpected end of file while reading %d bytes",0x40);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_2c,&DAT_01c17198);
  }
  if (((iStack_90 != DAT_018ffd00) || (iStack_8c != DAT_018ffd04)) || (iStack_88 != DAT_018ffd08)) {
    FUN_016756b0(auStack_2c,"Invalid KTX header");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_2c,&DAT_01c17198);
  }
  if ((uStack_6c == 0) || (uStack_68 == 0)) {
    FUN_016756b0(auStack_2c,"Invalid KTX header: width/height is zero");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_2c,&DAT_01c17198);
  }
  if (((param_4 & 2) != 0) &&
     (((-uStack_6c & uStack_6c) != uStack_6c || ((-uStack_68 & uStack_68) != uStack_68)))) {
    FUN_016756b0(auStack_2c,"Unsupported KTX: non-power-of-two image needs to be resized");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_2c,&DAT_01c17198);
  }
  uStack_48 = uStack_6c;
  uStack_44 = uStack_68;
  if (iStack_54 != 0) {
    FUN_007d3a80(param_2,&iStack_90,&uStack_48,&uStack_44);
  }
  if (iStack_78 != 0) goto LAB_007d34db;
  if (iStack_74 == 0x8d64) {
    iVar11 = 0x13;
    if ((param_4 & 0x10) == 0) goto LAB_007d309b;
    cStack_11 = '\x01';
LAB_007d30a2:
    cStack_12 = '\0';
  }
  else {
    if (iStack_74 == 0x9274) {
      iVar11 = 0x14;
LAB_007d309b:
      cStack_11 = '\0';
      goto LAB_007d30a2;
    }
    if (iStack_74 != 0x9278) {
      if (iStack_74 == 0x8c03) {
        iVar11 = 0x11;
      }
      else if (iStack_74 == 0x8c02) {
        iVar11 = 0x12;
      }
      else {
        iStack_78 = iStack_74;
        if (DAT_01d61db8 == '\0') {
LAB_007d34db:
          FUN_016756b0(auStack_2c,"Unsupported KTX: unknown format %x",iStack_78);
                    /* WARNING: Subroutine does not return */
          FUN_0170c2a8(auStack_2c,&DAT_01c17198);
        }
        if ((iStack_74 == 0x83f0) || (iStack_74 == 0x83f1)) {
          iVar11 = 0xe;
        }
        else if (iStack_74 == 0x83f2) {
          iVar11 = 0xf;
        }
        else {
          if (iStack_74 != 0x83f3) goto LAB_007d34db;
          iVar11 = 0x10;
        }
      }
      goto LAB_007d309b;
    }
    iVar11 = 0x15;
    cStack_11 = '\0';
    if ((param_4 & 0x20) == 0) goto LAB_007d30a2;
    cStack_12 = '\x01';
    cStack_11 = '\0';
  }
  if ((DAT_01d61dd0 == '\0') || (iVar11 != 0x14)) {
    if (((iVar11 != 0xe) && ((iVar11 != 0xf && (iVar11 != 0x10)))) || ((param_4 & 1) == 0))
    goto LAB_007d30bc;
    cStack_13 = '\x01';
  }
  else {
    if ((param_4 & 0x20) != 0) {
      cStack_12 = '\x01';
    }
LAB_007d30bc:
    cStack_13 = '\0';
  }
  if (cStack_11 == '\0') {
    if ((cStack_12 != '\0') || (iStack_1c = iVar11, cStack_13 != '\0')) {
      iStack_1c = 3;
    }
  }
  else {
    iStack_1c = 2;
  }
  uStack_34 = FUN_0147d0e0(uStack_6c,uStack_68,1);
  if (((param_4 >> 3 & 1) == 0) || (uStack_58 == 1)) {
    uStack_34 = uStack_58;
  }
  uStack_18 = 0;
  uVar9 = 1;
  uVar10 = uStack_68;
  uVar12 = uStack_6c;
  while (((param_3 < uVar12 || (param_3 < uVar10)) || (param_3 < uVar9))) {
    uStack_18 = uStack_18 + 1;
    uVar12 = uVar12 >> 1;
    uVar10 = uVar10 >> 1;
    uVar9 = 0;
  }
  cVar8 = cStack_13;
  cVar3 = cStack_12;
  if (uStack_58 < uStack_34) {
    if (iVar11 != 0x13) {
      if ((iVar11 == 0x14) || (iVar11 == 0x15)) {
        cVar3 = '\x01';
      }
      else if ((iVar11 == 0xe) || ((iVar11 == 0xf || (iVar11 == 0x10)))) {
        cVar8 = '\x01';
      }
      goto LAB_007d3181;
    }
  }
  else {
LAB_007d3181:
    if (((cStack_11 == '\0') && (cVar3 == '\0')) && (cVar8 == '\0')) goto LAB_007d319f;
  }
  if ((uStack_6c != 1) && (uStack_68 != 1)) {
    uStack_18 = uStack_18 + 1;
  }
LAB_007d319f:
  if (uStack_18 < uStack_34) {
    uStack_50 = FUN_01674e20(0x30);
    uStack_8 = 0;
    if (uStack_50 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_0147d110(uStack_68,uStack_18);
      uVar5 = FUN_0147d110(uStack_6c,uStack_18);
      uVar4 = FUN_007cef10(0,iStack_1c,uVar5,uVar4,1,uStack_34 - uStack_18,1);
    }
    uStack_8 = 0xffffffff;
    iStack_28 = 0;
    piStack_24 = (int *)0x0;
    FUN_007ce650(uVar4,param_2);
    uStack_8 = 1;
    uStack_38 = 0;
    if (uStack_34 != 0) {
      iStack_3c = uStack_18 * -4;
      do {
        uVar9 = uStack_38;
        uStack_30 = FUN_0147d110(uStack_6c,uStack_38);
        uStack_20 = FUN_0147d110(uStack_68,uVar9);
        iStack_40 = 0;
        if (uVar9 < uStack_58) {
          FUN_007d3f40(param_2,&iStack_40,4);
        }
        uStack_50 = iStack_40 + 3U & 0xfffffffc;
        if (uVar9 < uStack_18) {
          FUN_005956d0(uStack_50,0,1);
        }
        else {
          iVar13 = *(int *)(*(int *)(iStack_28 + 0x1c) + iStack_3c) + *(int *)(iStack_28 + 0x28);
          iStack_4c = iVar13;
          if (iStack_1c == iVar11) {
            FUN_007d3f40(param_2,iVar13,uStack_50);
            if (DAT_01d61dc0 != '\0') {
              FUN_007d4e80(iVar13,iStack_1c,uStack_30,uStack_20,1);
            }
          }
          else {
            if (uVar9 < uStack_58) {
              iVar7 = FUN_01674e20(uStack_50);
              uStack_8 = CONCAT31(uStack_8._1_3_,2);
              iStack_4c = iVar7;
              FUN_007d3f40(param_2,iVar7,uStack_50);
              if (iVar11 == 0x13) {
                FUN_007d04c0(iVar13,iVar7,uStack_30,uStack_20,0x13);
              }
              else if ((iVar11 == 0x14) || (iVar11 == 0x15)) {
                FUN_007d0660(iVar13,iVar7,uStack_30,uStack_20,iVar11);
              }
              else if (((iVar11 == 0xe) || (iVar11 == 0xf)) || (iVar11 == 0x10)) {
                FUN_007d02c0(iVar13,iVar7,uStack_30,uStack_20,1,iVar11);
              }
              uStack_8 = CONCAT31(uStack_8._1_3_,1);
              FUN_01674ea0(iVar7);
              uVar4 = uStack_30;
            }
            else {
              uVar5 = FUN_0147d110(uStack_6c,uVar9 - 1);
              uVar6 = FUN_0147d110(uStack_68,uVar9 - 1);
              uVar4 = uStack_30;
              iVar13 = iStack_4c;
              FUN_007d42b0(iStack_4c,uStack_30,uStack_20,
                           *(int *)(*(int *)(iStack_28 + 0x1c) + -4 + iStack_3c) +
                           *(int *)(iStack_28 + 0x28),uVar5,uVar6,iStack_1c);
            }
            if (DAT_01d61dc0 != '\0') {
              FUN_007d4e80(iVar13,iStack_1c,uVar4,uStack_20,1);
            }
            uVar9 = uStack_38;
            if ((DAT_01d61db8 != '\0') && ((param_4 & 4) != 0)) {
              FUN_007d1d30(iVar13,uVar4,uStack_20,1);
              uVar9 = uStack_38;
            }
          }
        }
        iStack_3c = iStack_3c + 4;
        uStack_38 = uVar9 + 1;
      } while (uStack_38 < uStack_34);
    }
    uVar4 = FUN_00773510(uStack_48,uStack_44,1,0,0,0);
    FUN_007cf090(&iStack_28,uVar4);
    if (piStack_94 != (int *)0x0) {
      LOCK();
      iVar11 = piStack_94[1] + -1;
      piStack_94[1] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        (**(code **)*piStack_94)();
        LOCK();
        iVar11 = piStack_94[2] + -1;
        piStack_94[2] = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          (**(code **)(*piStack_94 + 4))();
        }
      }
    }
    piVar2 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar11 = piStack_24[1] + -1;
      piStack_24[1] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar11 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar11 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_2c,"Unsupported KTX: %d out of %d mipmap levels need to be skipped",uStack_18
               ,uStack_34);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_2c,&DAT_01c17198);
}



/* FUNCTION 11975 ; VA 0x007d3560 ; FUN_007d3560 */

int * FUN_007d3560(int *param_1,int param_2,uint param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int *piVar8;
  uint uVar9;
  undefined8 uVar10;
  int *piStack_44;
  undefined auStack_40 [4];
  int iStack_3c;
  int *piStack_38;
  int iStack_34;
  int iStack_30;
  uint uStack_2c;
  int iStack_28;
  uint uStack_24;
  int iStack_20;
  int iStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3c07;
  pvStack_10 = ExceptionList;
  if ((*(int *)(param_2 + 0xc) < 1) || (*(int *)(param_2 + 0x10) < 1)) {
    ExceptionList = &pvStack_10;
    FUN_016756b0(auStack_40,"Invalid image: width/height is zero");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_40,&DAT_01c17198);
  }
  iVar2 = *(int *)(param_2 + 8);
  if ((iVar2 == 2) || (iVar2 == 4)) {
    uVar9 = iVar2 * *(int *)(param_2 + 0x10) * *(int *)(param_2 + 0xc);
    uVar5 = 0;
    if (uVar9 != 0) {
      do {
        if (*(char *)((uVar5 - 1) + iVar2 + *(int *)(param_2 + 4)) != -1) {
          iStack_28 = CONCAT31(iStack_28._1_3_,1);
          goto LAB_007d35c9;
        }
        uVar5 = uVar5 + iVar2;
      } while (uVar5 < uVar9);
    }
  }
  iStack_28 = (uint)iStack_28._1_3_ << 8;
LAB_007d35c9:
  if (iVar2 < 1) {
LAB_007d391e:
    ExceptionList = &pvStack_10;
    uVar6 = FUN_00615960();
    FUN_016756b0(auStack_40,"Unsupported image: can\'t decode image with %d channels",uVar6);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_40,&DAT_01c17198);
  }
  if (iVar2 < 4) {
    ExceptionList = &pvStack_10;
    cVar4 = FUN_0115fe50();
    if (cVar4 == '\0') {
      uVar6 = FUN_005565f0();
      uVar7 = FUN_005817e0();
      FUN_016756b0(auStack_40,"Out of memory while doing RGBA conversion for %dx%d image",uVar7,
                   uVar6);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_40,&DAT_01c17198);
    }
  }
  else {
    ExceptionList = &pvStack_10;
    if (iVar2 != 4) goto LAB_007d391e;
  }
  if ((param_4 & 4) != 0) {
    FUN_007d1d30(*(undefined4 *)(param_2 + 4),*(undefined4 *)(param_2 + 0xc),
                 *(undefined4 *)(param_2 + 0x10),1);
  }
  if (DAT_01d61dc8 == '\0') {
    uVar10 = FUN_007cfe00(*(undefined4 *)(param_2 + 0xc),param_3,param_4);
    uVar9 = (uint)uVar10;
    uStack_2c = uVar9;
    uVar5 = FUN_007cfe00(*(undefined4 *)(param_2 + 0x10),(int)((ulonglong)uVar10 >> 0x20),param_4);
  }
  else {
    uVar10 = FUN_007cfdc0(*(undefined4 *)(param_2 + 0xc));
    uVar9 = (uint)uVar10;
    for (uVar5 = FUN_007cfdc0(*(undefined4 *)(param_2 + 0x10),(int)((ulonglong)uVar10 >> 0x20));
        (param_3 < uVar9 || (param_3 < uVar5)); uVar5 = uVar5 >> 1) {
      uVar9 = uVar9 >> 1;
    }
    if (uVar9 == 0) {
      uVar9 = 1;
    }
    uStack_2c = uVar9;
    if (uVar5 == 0) {
      uVar5 = 1;
    }
  }
  uStack_18 = uVar5;
  uStack_24 = FUN_0147d0e0(uVar9,uVar5,1);
  iStack_34 = FUN_01674e20(0x30);
  uStack_8 = 0;
  if (iStack_34 == 0) {
    uVar6 = 0;
  }
  else {
    uVar6 = FUN_007cef10(0,3,uVar9,uVar5,1,uStack_24,1);
  }
  uStack_8 = 0xffffffff;
  iStack_3c = 0;
  piStack_38 = (int *)0x0;
  FUN_007ce650(uVar6,param_2);
  uStack_8 = 1;
  uStack_14 = 0;
  if (uStack_24 != 0) {
    do {
      iStack_1c = FUN_0147d110(uVar9,uStack_14);
      iStack_30 = FUN_0147d110(uVar5,uStack_14);
      iStack_34 = uStack_14 * 4;
      iStack_20 = *(int *)(*(int *)(iStack_3c + 0x1c) + uStack_14 * 4) + *(int *)(iStack_3c + 0x28);
      if (uStack_14 == 0) {
        if ((iStack_1c == *(int *)(param_2 + 0xc)) && (iStack_30 == *(int *)(param_2 + 0x10))) {
          uVar6 = *(undefined4 *)(param_2 + 4);
          uVar7 = FUN_0147d000(3,iStack_1c,iStack_30);
          FUN_0170c6f0(iStack_20,uVar6,uVar7);
          uVar5 = uStack_18;
        }
        else {
          FUN_007d42b0(iStack_20,iStack_1c,iStack_30,*(undefined4 *)(param_2 + 4),
                       *(undefined4 *)(param_2 + 0xc),*(undefined4 *)(param_2 + 0x10),3);
        }
      }
      else {
        iVar2 = uStack_14 - 1;
        uVar6 = FUN_0147d110(uVar9,iVar2);
        uVar5 = uStack_18;
        uVar7 = FUN_0147d110(uStack_18,iVar2);
        FUN_007d42b0(iStack_20,iStack_1c,iStack_30,
                     *(int *)(iStack_34 + -4 + *(int *)(iStack_3c + 0x1c)) +
                     *(int *)(iStack_3c + 0x28),uVar6,uVar7,3);
        uVar9 = uStack_2c;
      }
      if (DAT_01d61dc0 != '\0') {
        FUN_007d4e80(iStack_20,3,iStack_1c,iStack_30,1);
      }
      uStack_14 = uStack_14 + 1;
    } while (uStack_14 < uStack_24);
  }
  piVar8 = (int *)FUN_00773510(*(undefined4 *)(param_2 + 0xc),*(undefined4 *)(param_2 + 0x10),
                               iStack_28,0,0,0);
  piVar3 = piStack_38;
  *param_1 = 0;
  param_1[1] = 0;
  if (piStack_38 != (int *)0x0) {
    LOCK();
    piStack_38[1] = piStack_38[1] + 1;
    UNLOCK();
  }
  *param_1 = iStack_3c;
  param_1[1] = (int)piStack_38;
  param_1[2] = *piVar8;
  param_1[3] = piVar8[1];
  param_1[4] = piVar8[2];
  *(undefined *)(param_1 + 5) = *(undefined *)(piVar8 + 3);
  param_1[6] = 0;
  param_1[7] = 0;
  if (piVar8[5] != 0) {
    LOCK();
    piVar1 = (int *)(piVar8[5] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[6] = piVar8[4];
  param_1[7] = piVar8[5];
  if (piStack_44 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_44[1] + -1;
    piStack_44[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_44)();
      LOCK();
      iVar2 = piStack_44[2] + -1;
      piStack_44[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_44 + 4))();
      }
    }
  }
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar8 = piVar3 + 2;
      iVar2 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11976 ; VA 0x007d3950 ; FUN_007d3950 */

int __thiscall FUN_007d3950(int param_1,int param_2)

{
  int iVar1;
  code *pcVar2;
  void *pvVar3;
  undefined4 uVar4;
  int iVar5;
  undefined auStack_20 [8];
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar3 = ExceptionList;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3c30;
  pvStack_10 = ExceptionList;
  iVar5 = *(int *)(param_1 + 0x50);
  if (iVar5 == 0) {
    ExceptionList = &pvStack_10;
    uVar4 = FUN_00555250(auStack_18,1);
    uVar4 = FUN_0054ff80("no write access",uVar4);
    uStack_8 = 0;
    FUN_007ceab0(uVar4);
  }
  else {
    ExceptionList = &pvStack_10;
    if (**(int **)(param_1 + 0x20) == 0) {
      iVar1 = *(int *)(param_1 + 0x54);
      ExceptionList = &pvStack_10;
      **(int **)(param_1 + 0x10) = iVar5;
      **(int **)(param_1 + 0x20) = iVar5;
      **(int **)(param_1 + 0x30) = iVar1 - iVar5;
      iVar5 = *(int *)(param_1 + 0x48);
      if ((((iVar5 != 0) && (*(int *)(param_1 + 0x50) != 0)) && (iVar5 == *(int *)(param_1 + 0x50)))
         && (**(int **)(param_1 + 0x1c) != 0)) {
        iVar5 = **(int **)(param_1 + 0x1c) - iVar5;
        **(int **)(param_1 + 0x30) = **(int **)(param_1 + 0x30) - iVar5;
        **(int **)(param_1 + 0x20) = **(int **)(param_1 + 0x20) + iVar5;
        **(undefined4 **)(param_1 + 0xc) = 0;
        **(undefined4 **)(param_1 + 0x1c) = 0;
        **(undefined4 **)(param_1 + 0x2c) = 0;
      }
    }
    if (param_2 == -1) {
      ExceptionList = pvVar3;
      return 0;
    }
    if ((undefined *)**(int **)(param_1 + 0x20) != *(undefined **)(param_1 + 0x54)) {
      *(undefined *)**(int **)(param_1 + 0x20) = (char)param_2;
      **(int **)(param_1 + 0x30) = **(int **)(param_1 + 0x30) + -1;
      **(int **)(param_1 + 0x20) = **(int **)(param_1 + 0x20) + 1;
      ExceptionList = pvVar3;
      return param_2;
    }
  }
  uVar4 = FUN_00555250(auStack_20,1);
  uVar4 = FUN_0054ff80("write area exhausted",uVar4);
  uStack_8 = 1;
  FUN_007ceab0(uVar4);
  pcVar2 = (code *)swi(3);
  iVar5 = (*pcVar2)();
  return iVar5;
}



/* FUNCTION 11977 ; VA 0x007d3a80 ; FUN_007d3a80 */

void FUN_007d3a80(int *param_1,int param_2,undefined4 *param_3,undefined4 *param_4)

{
  byte bVar1;
  int *piVar2;
  int iVar3;
  byte ****ppppbVar4;
  undefined4 uVar5;
  uint uVar6;
  byte ****ppppbVar7;
  undefined4 *puVar8;
  uint uVar9;
  bool bVar10;
  int *piVar11;
  uint uStack_9c;
  int iStack_98;
  uint uStack_94;
  int iStack_90;
  int *piStack_84;
  undefined uStack_80;
  byte ***apppbStack_7c [4];
  int iStack_6c;
  uint uStack_68;
  byte ***apppbStack_64 [4];
  int iStack_54;
  uint uStack_50;
  undefined auStack_4c [4];
  int *piStack_48;
  undefined uStack_44;
  uint uStack_40;
  int iStack_3c;
  uint uStack_38;
  int iStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  byte ***apppbStack_28 [4];
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3c78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054eff0("RobloxOriginalWidth");
  uStack_8 = 0;
  FUN_0054eff0("RobloxOriginalHeight");
  piVar2 = param_1;
  piStack_18 = (int *)0x0;
  uStack_14 = 0xf;
  apppbStack_28[0] = (byte ***)((uint)apppbStack_28[0] & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_005957d0(&uStack_9c);
  while( true ) {
    piStack_84 = piVar2;
    piVar11 = *(int **)(*(int *)(*piVar2 + 4) + 0x38 + (int)piVar2);
    if (piVar11 != (int *)0x0) {
      (**(code **)(*piVar11 + 4))();
    }
    uStack_8._0_1_ = 3;
    uStack_80 = FUN_00593b40(1);
    iVar3 = *piVar2;
    uStack_8._0_1_ = 4;
    if ((*(byte *)((int)piVar2 + *(int *)(iVar3 + 4) + 0xc) & 6) == 0) {
      (**(code **)(**(int **)(*(int *)(iVar3 + 4) + 0x38 + (int)piVar2) + 0x28))(&uStack_40,0,0,1,1)
      ;
      iVar3 = *piVar2;
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
    }
    else {
      uStack_40 = 0xffffffff;
      iStack_3c = -1;
      uStack_38 = 0;
      iStack_34 = 0;
      uStack_30 = 0;
      uStack_2c = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
    }
    piVar11 = *(int **)(*(int *)(iVar3 + 4) + 0x38 + (int)piVar2);
    if (piVar11 != (int *)0x0) {
      (**(code **)(*piVar11 + 8))();
    }
    uVar6 = (uStack_38 - uStack_9c) - uStack_94;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    iVar3 = ((((iStack_34 - iStack_98) - (uint)(uStack_38 < uStack_9c)) - iStack_90) -
            (uint)(uStack_38 - uStack_9c < uStack_94)) + iStack_3c + (uint)CARRY4(uVar6,uStack_40);
    if ((0 < iVar3) || ((-1 < iVar3 && (*(uint *)(param_2 + 0x3c) <= uVar6 + uStack_40)))) {
      if (0xf < uStack_14) {
        uVar6 = uStack_14 + 1;
        ppppbVar4 = (byte ****)apppbStack_28[0];
        if (0xfff < uVar6) {
          ppppbVar4 = (byte ****)apppbStack_28[0][-1];
          uVar6 = uStack_14 + 0x24;
          if ((byte *)0x1f < (byte *)((int)apppbStack_28[0] + (-4 - (int)ppppbVar4))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppbVar4,uVar6);
      }
      piStack_18 = (int *)0x0;
      uStack_14 = 0xf;
      apppbStack_28[0] = (byte ***)((uint)apppbStack_28[0] & 0xffffff00);
      if (0xf < uStack_50) {
        uVar6 = uStack_50 + 1;
        ppppbVar4 = (byte ****)apppbStack_64[0];
        if (0xfff < uVar6) {
          ppppbVar4 = (byte ****)apppbStack_64[0][-1];
          uVar6 = uStack_50 + 0x24;
          if ((byte *)0x1f < (byte *)((int)apppbStack_64[0] + (-4 - (int)ppppbVar4))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppbVar4,uVar6);
      }
      if (0xf < uStack_68) {
        uVar6 = uStack_68 + 1;
        ppppbVar4 = (byte ****)apppbStack_7c[0];
        if (0xfff < uVar6) {
          ppppbVar4 = (byte ****)apppbStack_7c[0][-1];
          uVar6 = uStack_68 + 0x24;
          if ((byte *)0x1f < (byte *)((int)apppbStack_7c[0] + (-4 - (int)ppppbVar4))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppbVar4,uVar6);
      }
      ExceptionList = pvStack_10;
      return;
    }
    FUN_005af630(&param_1,4,0);
    if ((piVar2[2] != 4) || (piVar2[3] != 0)) break;
    if (piStack_18 < param_1) {
      FUN_00578160((int)param_1 - (int)piStack_18,0);
    }
    else {
      piStack_18 = param_1;
      ppppbVar4 = apppbStack_28;
      if (0xf < uStack_14) {
        ppppbVar4 = (byte ****)apppbStack_28[0];
      }
      *(byte *)((int)ppppbVar4 + (int)param_1) = 0;
    }
    piVar11 = param_1;
    ppppbVar4 = apppbStack_28;
    if (0xf < uStack_14) {
      ppppbVar4 = (byte ****)apppbStack_28[0];
    }
    FUN_005af630(ppppbVar4,param_1,0);
    if (((int *)piVar2[2] != piVar11) || (piVar2[3] != 0)) goto LAB_007d3e6c;
    ppppbVar4 = apppbStack_7c;
    if (0xf < uStack_68) {
      ppppbVar4 = (byte ****)apppbStack_7c[0];
    }
    ppppbVar7 = apppbStack_28;
    if (0xf < uStack_14) {
      ppppbVar7 = (byte ****)apppbStack_28[0];
    }
    do {
      bVar1 = *(byte *)ppppbVar7;
      bVar10 = bVar1 < *(byte *)ppppbVar4;
      if (bVar1 != *(byte *)ppppbVar4) {
LAB_007d3c53:
        uVar6 = -(uint)bVar10 | 1;
        goto LAB_007d3c58;
      }
      if (bVar1 == 0) break;
      bVar1 = *(byte *)((int)ppppbVar7 + 1);
      bVar10 = bVar1 < *(byte *)((int)ppppbVar4 + 1);
      if (bVar1 != *(byte *)((int)ppppbVar4 + 1)) goto LAB_007d3c53;
      ppppbVar7 = (byte ****)((int)ppppbVar7 + 2);
      ppppbVar4 = (byte ****)((int)ppppbVar4 + 2);
    } while (bVar1 != 0);
    uVar6 = 0;
LAB_007d3c58:
    if (uVar6 == 0) {
      ppppbVar4 = apppbStack_28;
      if (0xf < uStack_14) {
        ppppbVar4 = (byte ****)apppbStack_28[0];
      }
      uVar5 = FUN_01717832((byte *)((int)ppppbVar4 + iStack_6c + 1));
      puVar8 = param_3;
LAB_007d3cd2:
      *puVar8 = uVar5;
    }
    else {
      ppppbVar4 = apppbStack_64;
      if (0xf < uStack_50) {
        ppppbVar4 = (byte ****)apppbStack_64[0];
      }
      ppppbVar7 = apppbStack_28;
      if (0xf < uStack_14) {
        ppppbVar7 = (byte ****)apppbStack_28[0];
      }
      do {
        bVar1 = *(byte *)ppppbVar7;
        bVar10 = bVar1 < *(byte *)ppppbVar4;
        if (bVar1 != *(byte *)ppppbVar4) {
LAB_007d3cb0:
          uVar6 = -(uint)bVar10 | 1;
          goto LAB_007d3cb5;
        }
        if (bVar1 == 0) break;
        bVar1 = *(byte *)((int)ppppbVar7 + 1);
        bVar10 = bVar1 < *(byte *)((int)ppppbVar4 + 1);
        if (bVar1 != *(byte *)((int)ppppbVar4 + 1)) goto LAB_007d3cb0;
        ppppbVar7 = (byte ****)((int)ppppbVar7 + 2);
        ppppbVar4 = (byte ****)((int)ppppbVar4 + 2);
      } while (bVar1 != 0);
      uVar6 = 0;
LAB_007d3cb5:
      if (uVar6 == 0) {
        ppppbVar4 = apppbStack_28;
        if (0xf < uStack_14) {
          ppppbVar4 = (byte ****)apppbStack_28[0];
        }
        uVar5 = FUN_01717832((byte *)((int)ppppbVar4 + iStack_54 + 1));
        puVar8 = param_4;
        goto LAB_007d3cd2;
      }
    }
    iVar3 = 3 - ((uint)((int)param_1 + -1) & 3);
    if (iVar3 != 0) {
      uVar9 = *(uint *)(*(int *)(*piVar2 + 4) + 0xc + (int)piVar2) & 0xfffffffe;
      uVar6 = uVar9 | 4;
      if (*(int *)((int)piVar2 + *(int *)(*piVar2 + 4) + 0x38) != 0) {
        uVar6 = uVar9;
      }
      FUN_00554460(uVar6,0);
      piStack_48 = piVar2;
      piVar11 = *(int **)(*(int *)(*piVar2 + 4) + 0x38 + (int)piVar2);
      if (piVar11 != (int *)0x0) {
        (**(code **)(*piVar11 + 4))();
      }
      uStack_8._0_1_ = 7;
      uStack_44 = FUN_00593b40(1);
      uStack_8._0_1_ = 8;
      if (((*(byte *)(*(int *)(*piVar2 + 4) + 0xc + (int)piVar2) & 6) == 0) &&
         ((**(code **)(**(int **)(*(int *)(*piVar2 + 4) + 0x38 + (int)piVar2) + 0x28))
                    (&uStack_40,iVar3,0,1,1),
         (uStack_40 + uStack_38 & iStack_3c + iStack_34 + (uint)CARRY4(uStack_40,uStack_38)) ==
         0xffffffff)) {
        FUN_00554460((uint)(*(int *)((int)piVar2 + *(int *)(*piVar2 + 4) + 0x38) == 0) * 4 + 2 |
                     *(uint *)((int)piVar2 + *(int *)(*piVar2 + 4) + 0xc),0);
      }
      uStack_8._0_1_ = 9;
      piVar11 = *(int **)(*(int *)(*piVar2 + 4) + 0x38 + (int)piVar2);
      if (piVar11 != (int *)0x0) {
        (**(code **)(*piVar11 + 8))();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
    }
  }
  piVar11 = (int *)&DAT_00000004;
LAB_007d3e6c:
  FUN_016756b0(auStack_4c,"Unexpected end of file while reading %d bytes",piVar11);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_4c,&DAT_01c17198);
}



/* FUNCTION 11978 ; VA 0x007d3ea0 ; FUN_007d3ea0 */

int __thiscall FUN_007d3ea0(int param_1,int param_2)

{
  code *pcVar1;
  void **ppvVar2;
  undefined4 uVar3;
  int iVar4;
  undefined auStack_38 [20];
  undefined auStack_24 [20];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3ca0;
  pvStack_10 = ExceptionList;
  ppvVar2 = &pvStack_10;
  if (*(int *)(param_1 + 0x48) != 0) {
    if ((**(int **)(param_1 + 0x1c) != 0) &&
       (**(int **)(param_1 + 0x1c) != *(int *)(param_1 + 0x48))) {
      **(int **)(param_1 + 0x2c) = **(int **)(param_1 + 0x2c) + 1;
      **(int **)(param_1 + 0x1c) = **(int **)(param_1 + 0x1c) + -1;
      if (param_2 == -1) {
        param_2 = 0;
      }
      else {
        *(char *)**(undefined4 **)(param_1 + 0x1c) = (char)param_2;
      }
      return param_2;
    }
    ExceptionList = &pvStack_10;
    uVar3 = FUN_007cfe60(auStack_38);
    uStack_8 = 1;
    FUN_007ceab0(uVar3);
    ppvVar2 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar2;
  uVar3 = FUN_007d0020(auStack_24);
  uStack_8 = 0;
  FUN_007ceab0(uVar3);
  pcVar1 = (code *)swi(3);
  iVar4 = (*pcVar1)();
  return iVar4;
}



/* FUNCTION 11979 ; VA 0x007d3f40 ; FUN_007d3f40 */

void FUN_007d3f40(int param_1,undefined4 param_2,int param_3)

{
  undefined auStack_10 [12];
  
  FUN_005af630(param_2,param_3,0);
  if ((*(int *)(param_1 + 8) == param_3) && (*(int *)(param_1 + 0xc) == 0)) {
    return;
  }
  FUN_016756b0(auStack_10,"Unexpected end of file while reading %d bytes",param_3);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 11980 ; VA 0x007d3f90 ; FUN_007d3f90 */

void __thiscall FUN_007d3f90(int *param_1,uint param_2)

{
  if (param_2 <= (uint)(param_1[2] - *param_1 >> 2)) {
    return;
  }
  if (param_2 < 0x40000000) {
    FUN_007cfd20();
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 11981 ; VA 0x007d3fbd ; FUN_007d3fbd */

void FUN_007d3fbd(void)

{
  FUN_007d3fd0();
  return;
}



/* FUNCTION 11982 ; VA 0x007d3fd0 ; FUN_007d3fd0 */

void __fastcall FUN_007d3fd0(int param_1)

{
  undefined auStack_38 [52];
  
  FUN_007ceb00(param_1 + -0x30,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_38,&DAT_01c46e90);
}



/* FUNCTION 11983 ; VA 0x007d4000 ; FUN_007d4000 */

void FUN_007d4000(char *param_1,uint param_2,int param_3,byte *param_4,uint param_5,uint param_6)

{
  longlong lVar1;
  longlong lVar2;
  byte *pbVar3;
  byte bVar7;
  uint uVar4;
  uint uVar5;
  int iVar6;
  byte bVar9;
  uint uVar8;
  uint uVar10;
  uint uVar11;
  byte *pbVar12;
  int iVar13;
  char *pcVar14;
  ulonglong uVar15;
  ulonglong uVar16;
  int iStack_28;
  char *pcStack_14;
  char *pcStack_c;
  byte *pbStack_8;
  
  if ((param_2 * 2 == param_5) && (param_3 * 2 == param_6)) {
    uVar8 = param_5 >> 1;
    param_6 = param_6 >> 1;
    pbStack_8 = param_4;
    pcStack_c = param_1;
    if (param_6 != 0) {
      do {
        if (uVar8 != 0) {
          pbVar3 = pbStack_8 + param_5;
          pbVar12 = pbStack_8;
          pcVar14 = pcStack_c;
          param_2 = uVar8;
          do {
            bVar7 = (pbVar3[1 - param_5] | *pbVar12) - ((pbVar3[1 - param_5] ^ *pbVar12) >> 1);
            bVar9 = (pbVar3[1] | *pbVar3) - ((pbVar3[1] ^ *pbVar3) >> 1);
            param_2 = param_2 - 1;
            *pcVar14 = (bVar9 | bVar7) - ((bVar9 ^ bVar7) >> 1);
            pbVar3 = pbVar3 + 2;
            pbVar12 = pbVar12 + 2;
            pcVar14 = pcVar14 + 1;
          } while (param_2 != 0);
        }
        pbStack_8 = pbStack_8 + param_5 * 2;
        pcStack_c = pcStack_c + uVar8;
        param_6 = param_6 - 1;
      } while (param_6 != 0);
      return;
    }
  }
  else {
    pcStack_14 = param_1;
    uVar15 = FUN_016f3c60(0,param_5 << 0x10,param_2,0);
    uVar16 = FUN_016f3c60(0,param_6 << 0x10,param_3,0);
    lVar1 = (uVar16 >> 1) - 1;
    if (param_3 != 0) {
      do {
        uVar8 = (uint)((ulonglong)lVar1 >> 0x24);
        uVar4 = -(uint)(0x800 < uVar8) & uVar8 - 0x800;
        uVar5 = uVar4 >> 0xc;
        uVar4 = uVar4 & 0xfff;
        uVar8 = uVar5 + 1;
        iVar6 = uVar5 * param_5;
        uVar5 = param_6 - 1;
        if (uVar8 <= param_6 - 1) {
          uVar5 = uVar8;
        }
        if (param_2 != 0) {
          iStack_28 = param_2;
          lVar2 = (uVar15 >> 1) - 1;
          do {
            uVar8 = (uint)((ulonglong)lVar2 >> 0x24);
            uVar10 = -(uint)(0x800 < uVar8) & uVar8 - 0x800;
            uVar11 = uVar10 >> 0xc;
            uVar10 = uVar10 & 0xfff;
            uVar8 = param_5 - 1;
            if (uVar11 + 1 <= param_5 - 1) {
              uVar8 = uVar11 + 1;
            }
            iVar13 = uVar10 * uVar4;
            *pcStack_14 = (char)((uint)param_4[uVar5 * param_5 + uVar8] * iVar13 +
                                 (iVar13 + uVar10 * -0x1000 + uVar4 * -0x1000 + 0x1000000) *
                                 (uint)param_4[iVar6 + uVar11] +
                                 (uint)param_4[iVar6 + uVar8] * (uVar10 * 0x1000 - iVar13) +
                                 (uint)param_4[uVar5 * param_5 + uVar11] * (uVar4 * 0x1000 - iVar13)
                                 + 0x800000 >> 0x18);
            pcStack_14 = pcStack_14 + 1;
            lVar2 = lVar2 + uVar15;
            iStack_28 = iStack_28 + -1;
          } while (iStack_28 != 0);
        }
        lVar1 = lVar1 + uVar16;
        param_3 = param_3 + -1;
      } while (param_3 != 0);
    }
  }
  return;
}



/* FUNCTION 11984 ; VA 0x007d42b0 ; FUN_007d42b0 */

void FUN_007d42b0(int *param_1,int param_2,int param_3,uint *param_4,uint param_5,uint param_6,
                 int param_7)

{
  ushort uVar1;
  ushort uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  undefined auStack_24 [20];
  uint *puStack_10;
  uint *puStack_c;
  
  if (param_7 == 0) {
    FUN_007d4000(param_1,param_2,param_3,param_4,param_5,param_6);
    return;
  }
  if (param_7 == 1) {
    if ((param_2 * 2 != param_5) || (param_3 * 2 != param_6)) {
      FUN_007d4510(param_1,param_2,param_3,param_4,param_5,param_6);
      return;
    }
    uVar4 = param_5 >> 1;
    param_6 = param_6 >> 1;
    puStack_10 = param_4;
    puStack_c = (uint *)param_1;
    uVar3 = uVar4;
    if (param_6 != 0) {
      do {
        for (; uVar3 != 0; uVar3 = uVar3 - 1) {
          uVar1 = *(ushort *)((int)param_4 + param_5 * 2);
          uVar2 = *(ushort *)((int)param_4 + param_5 * 2 + 2);
          uVar5 = (uint)(*(ushort *)((int)param_4 + 2) | *(ushort *)param_4) -
                  ((ushort)((*(ushort *)((int)param_4 + 2) ^ *(ushort *)param_4) >> 1) & 0x7f7f);
          uVar6 = (uint)(uVar2 | uVar1) - ((ushort)((uVar2 ^ uVar1) >> 1) & 0x7f7f);
          *(ushort *)param_1 =
               ((ushort)uVar6 | (ushort)uVar5) -
               ((ushort)((uVar6 & 0xffff ^ uVar5 & 0xffff) >> 1) & 0x7f7f);
          param_1 = (int *)((int)param_1 + 2);
          param_4 = param_4 + 1;
        }
        param_4 = puStack_10 + param_5;
        param_1 = (int *)((int)puStack_c + uVar4 * 2);
        param_6 = param_6 - 1;
        uVar3 = uVar4;
        puStack_c = (uint *)param_1;
        puStack_10 = param_4;
      } while (param_6 != 0);
      return;
    }
  }
  else {
    if (param_7 != 3) {
      FUN_016756b0(auStack_24,"Unsupported image: can\'t scale image with format %d",param_7);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_24,&DAT_01c17198);
    }
    if ((param_2 * 2 == param_5) && (param_3 * 2 == param_6)) {
      uVar4 = param_5 >> 1;
      param_6 = param_6 >> 1;
      puStack_c = param_4;
      puStack_10 = (uint *)param_1;
      uVar3 = uVar4;
      if (param_6 != 0) {
        do {
          for (; uVar3 != 0; uVar3 = uVar3 - 1) {
            uVar5 = (param_4[1] | *param_4) - ((param_4[1] ^ *param_4) >> 1 & 0x7f7f7f7f);
            uVar6 = (param_4[param_5 + 1] | param_4[param_5]) -
                    ((param_4[param_5 + 1] ^ param_4[param_5]) >> 1 & 0x7f7f7f7f);
            *param_1 = (uVar6 | uVar5) - ((uVar6 ^ uVar5) >> 1 & 0x7f7f7f7f);
            param_1 = param_1 + 1;
            param_4 = param_4 + 2;
          }
          param_4 = puStack_c + param_5 * 2;
          param_1 = (int *)(puStack_10 + uVar4);
          param_6 = param_6 - 1;
          uVar3 = uVar4;
          puStack_c = param_4;
          puStack_10 = (uint *)param_1;
        } while (param_6 != 0);
        return;
      }
    }
    else {
      FUN_007d4740(param_1,param_2,param_3,param_4,param_5,param_6);
    }
  }
  return;
}



/* FUNCTION 11985 ; VA 0x007d4510 ; FUN_007d4510 */

void FUN_007d4510(undefined *param_1,int param_2,int param_3,int param_4,int param_5,int param_6)

{
  int iVar1;
  byte *pbVar2;
  byte *pbVar3;
  byte *pbVar4;
  byte *pbVar5;
  longlong lVar6;
  longlong lVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  int iVar14;
  uint uVar15;
  uint uVar16;
  ulonglong uVar17;
  ulonglong uVar18;
  int iStack_28;
  
  uVar17 = FUN_016f3c60(0,param_5 << 0x10,param_2,0);
  uVar18 = FUN_016f3c60(0,param_6 << 0x10,param_3,0);
  lVar6 = (uVar18 >> 1) - 1;
  if (param_3 != 0) {
    do {
      uVar8 = (uint)((ulonglong)lVar6 >> 0x24);
      uVar9 = -(uint)(0x800 < uVar8) & uVar8 - 0x800;
      uVar10 = uVar9 >> 0xc;
      uVar9 = uVar9 & 0xfff;
      uVar8 = uVar10 + 1;
      iVar11 = uVar10 * param_5;
      uVar10 = param_6 - 1U;
      if (uVar8 <= param_6 - 1U) {
        uVar10 = uVar8;
      }
      if (param_2 != 0) {
        iStack_28 = param_2;
        lVar7 = (uVar17 >> 1) - 1;
        do {
          uVar8 = (uint)((ulonglong)lVar7 >> 0x24);
          uVar15 = -(uint)(0x800 < uVar8) & uVar8 - 0x800;
          uVar16 = uVar15 >> 0xc;
          uVar15 = uVar15 & 0xfff;
          uVar8 = param_5 - 1U;
          if (uVar16 + 1 <= param_5 - 1U) {
            uVar8 = uVar16 + 1;
          }
          iVar13 = uVar15 * uVar9;
          iVar1 = iVar13 + uVar15 * -0x1000 + uVar9 * -0x1000 + 0x1000000;
          pbVar2 = (byte *)(param_4 + (uVar16 + iVar11) * 2);
          pbVar3 = (byte *)(param_4 + (uVar8 + iVar11) * 2);
          iVar12 = uVar15 * 0x1000 - iVar13;
          iVar14 = uVar9 * 0x1000 - iVar13;
          pbVar4 = (byte *)(param_4 + (uVar16 + uVar10 * param_5) * 2);
          pbVar5 = (byte *)(param_4 + (uVar8 + uVar10 * param_5) * 2);
          *param_1 = (char)((uint)*pbVar3 * iVar12 + 0x800000 +
                            (uint)*pbVar4 * iVar14 + (uint)*pbVar5 * iVar13 + (uint)*pbVar2 * iVar1
                           >> 0x18);
          param_1[1] = (char)((uint)pbVar2[1] * iVar1 + 0x800000 +
                              (uint)pbVar5[1] * iVar13 + (uint)pbVar4[1] * iVar14 +
                              (uint)pbVar3[1] * iVar12 >> 0x18);
          param_1 = param_1 + 2;
          lVar7 = lVar7 + uVar17;
          iStack_28 = iStack_28 + -1;
        } while (iStack_28 != 0);
      }
      lVar6 = lVar6 + uVar18;
      param_3 = param_3 + -1;
    } while (param_3 != 0);
  }
  return;
}



/* FUNCTION 11986 ; VA 0x007d4740 ; FUN_007d4740 */

void FUN_007d4740(undefined *param_1,int param_2,int param_3,int param_4,int param_5,int param_6)

{
  int iVar1;
  byte *pbVar2;
  byte *pbVar3;
  byte *pbVar4;
  byte *pbVar5;
  longlong lVar6;
  longlong lVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  int iVar14;
  uint uVar15;
  uint uVar16;
  ulonglong uVar17;
  ulonglong uVar18;
  int iStack_28;
  
  uVar17 = FUN_016f3c60(0,param_5 << 0x10,param_2,0);
  uVar18 = FUN_016f3c60(0,param_6 << 0x10,param_3,0);
  lVar6 = (uVar18 >> 1) - 1;
  if (param_3 != 0) {
    do {
      uVar8 = (uint)((ulonglong)lVar6 >> 0x24);
      uVar9 = -(uint)(0x800 < uVar8) & uVar8 - 0x800;
      uVar10 = uVar9 >> 0xc;
      uVar9 = uVar9 & 0xfff;
      uVar8 = uVar10 + 1;
      iVar11 = uVar10 * param_5;
      uVar10 = param_6 - 1U;
      if (uVar8 <= param_6 - 1U) {
        uVar10 = uVar8;
      }
      if (param_2 != 0) {
        iStack_28 = param_2;
        lVar7 = (uVar17 >> 1) - 1;
        do {
          uVar8 = (uint)((ulonglong)lVar7 >> 0x24);
          uVar15 = -(uint)(0x800 < uVar8) & uVar8 - 0x800;
          uVar16 = uVar15 >> 0xc;
          uVar15 = uVar15 & 0xfff;
          uVar8 = param_5 - 1U;
          if (uVar16 + 1 <= param_5 - 1U) {
            uVar8 = uVar16 + 1;
          }
          iVar13 = uVar15 * uVar9;
          iVar1 = iVar13 + uVar15 * -0x1000 + uVar9 * -0x1000 + 0x1000000;
          pbVar2 = (byte *)(param_4 + (uVar16 + iVar11) * 4);
          pbVar3 = (byte *)(param_4 + (uVar8 + iVar11) * 4);
          iVar12 = uVar15 * 0x1000 - iVar13;
          pbVar4 = (byte *)(param_4 + (uVar16 + uVar10 * param_5) * 4);
          iVar14 = uVar9 * 0x1000 - iVar13;
          pbVar5 = (byte *)(param_4 + (uVar8 + uVar10 * param_5) * 4);
          *param_1 = (char)((uint)*pbVar3 * iVar12 + 0x800000 +
                            (uint)*pbVar4 * iVar14 + (uint)*pbVar5 * iVar13 + (uint)*pbVar2 * iVar1
                           >> 0x18);
          param_1[1] = (char)((uint)pbVar5[1] * iVar13 +
                              (uint)pbVar4[1] * iVar14 + (uint)pbVar3[1] * iVar12 +
                              (uint)pbVar2[1] * iVar1 + 0x800000 >> 0x18);
          param_1[2] = (char)((uint)pbVar5[2] * iVar13 +
                              (uint)pbVar4[2] * iVar14 + (uint)pbVar3[2] * iVar12 +
                              (uint)pbVar2[2] * iVar1 + 0x800000 >> 0x18);
          param_1[3] = (char)((uint)pbVar5[3] * iVar13 +
                              (uint)pbVar4[3] * iVar14 + (uint)pbVar3[3] * iVar12 +
                              (uint)pbVar2[3] * iVar1 + 0x800000 >> 0x18);
          param_1 = param_1 + 4;
          lVar7 = lVar7 + uVar17;
          iStack_28 = iStack_28 + -1;
        } while (iStack_28 != 0);
      }
      lVar6 = lVar6 + uVar18;
      param_3 = param_3 + -1;
    } while (param_3 != 0);
  }
  return;
}



/* FUNCTION 11987 ; VA 0x007d49e0 ; FUN_007d49e0 */

void __thiscall
FUN_007d49e0(int param_1,int *param_2,int param_3,undefined4 param_4,int param_5,byte param_6)

{
  code *pcVar1;
  bool bVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  undefined auStack_40 [20];
  undefined auStack_2c [20];
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3cc8;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x48);
  if ((((iVar4 == 0) || (*(int *)(param_1 + 0x50) == 0)) || (iVar4 == *(int *)(param_1 + 0x50))) ||
     (ExceptionList = &pvStack_10, (param_6 & 3) != 3)) {
    iStack_14 = -1;
    if (((iVar4 == 0) || (*(int *)(param_1 + 0x50) == 0)) || (iVar4 != *(int *)(param_1 + 0x50))) {
      bVar2 = false;
      if (((param_6 & 1) != 0) && (ExceptionList = &pvStack_10, iVar4 != 0)) goto LAB_007d4a70;
      iVar4 = -1;
      ExceptionList = &pvStack_10;
    }
    else {
      bVar2 = true;
      if ((**(int **)(param_1 + 0x20) != 0) ||
         (ExceptionList = &pvStack_10, **(int **)(param_1 + 0x1c) == 0)) {
        ExceptionList = &pvStack_10;
        FUN_007d20b0();
      }
LAB_007d4a70:
      if (**(int **)(param_1 + 0x1c) == 0) {
        iVar4 = *(int *)(param_1 + 0x4c);
        iVar5 = *(int *)(param_1 + 0x48);
        **(int **)(param_1 + 0xc) = iVar5;
        **(int **)(param_1 + 0x1c) = iVar5;
        **(int **)(param_1 + 0x2c) = iVar4 - iVar5;
      }
      iVar4 = param_3;
      if (param_5 == 0) {
LAB_007d4abc:
        if (iVar4 < 0) goto LAB_007d4bf9;
      }
      else {
        if (param_5 == 1) {
          iVar4 = (param_3 - *(int *)(param_1 + 0x48)) + **(int **)(param_1 + 0x1c);
          goto LAB_007d4abc;
        }
        iVar4 = 0;
        if (param_5 == 2) {
          iVar4 = (*(int *)(param_1 + 0x4c) - *(int *)(param_1 + 0x48)) + param_3;
          goto LAB_007d4abc;
        }
      }
      iStack_18 = *(int *)(param_1 + 0x4c);
      if (iStack_18 - *(int *)(param_1 + 0x48) < iVar4) goto LAB_007d4bf9;
      iVar5 = *(int *)(param_1 + 0x48) + iVar4;
      **(undefined4 **)(param_1 + 0xc) = *(undefined4 *)(param_1 + 0x48);
      **(int **)(param_1 + 0x1c) = iVar5;
      **(int **)(param_1 + 0x2c) = iStack_18 - iVar5;
      iStack_14 = iVar4 >> 0x1f;
      if (bVar2) goto LAB_007d4b87;
    }
    if (((param_6 & 2) == 0) || (iVar5 = *(int *)(param_1 + 0x50), iVar5 == 0)) goto LAB_007d4b87;
    if (**(int **)(param_1 + 0x20) == 0) {
      iVar4 = *(int *)(param_1 + 0x54);
      **(int **)(param_1 + 0x10) = iVar5;
      **(int **)(param_1 + 0x20) = iVar5;
      **(int **)(param_1 + 0x30) = iVar4 - iVar5;
    }
    if (param_5 == 0) {
LAB_007d4b5e:
      iVar4 = param_3;
      if (-1 < param_3) goto LAB_007d4b62;
    }
    else {
      if (param_5 == 1) {
        param_3 = (param_3 - *(int *)(param_1 + 0x50)) + **(int **)(param_1 + 0x20);
        goto LAB_007d4b5e;
      }
      iVar4 = 0;
      if (param_5 == 2) {
        param_3 = (*(int *)(param_1 + 0x54) - *(int *)(param_1 + 0x50)) + param_3;
        goto LAB_007d4b5e;
      }
LAB_007d4b62:
      if (iVar4 <= *(int *)(param_1 + 0x54) - *(int *)(param_1 + 0x50)) {
        iVar5 = (*(int *)(param_1 + 0x50) - **(int **)(param_1 + 0x20)) + iVar4;
        iStack_14 = iVar4 >> 0x1f;
        **(int **)(param_1 + 0x30) = **(int **)(param_1 + 0x30) - iVar5;
        **(int **)(param_1 + 0x20) = **(int **)(param_1 + 0x20) + iVar5;
LAB_007d4b87:
        *param_2 = iVar4;
        param_2[1] = iStack_14;
        param_2[4] = 0;
        param_2[5] = 0;
        param_2[2] = 0;
        param_2[3] = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
    uVar3 = FUN_007cfeb0(auStack_40);
    uStack_8 = 2;
    FUN_007ceab0(uVar3);
  }
  uVar3 = FUN_007cfeb0(auStack_2c);
  uStack_8 = 0;
  FUN_007ceab0(uVar3);
LAB_007d4bf9:
  uVar3 = FUN_007cfeb0(auStack_2c);
  uStack_8 = 1;
  FUN_007ceab0(uVar3);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 11988 ; VA 0x007d4c20 ; FUN_007d4c20 */

int * __thiscall
FUN_007d4c20(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  uint uStack_30;
  int iStack_2c;
  uint uStack_28;
  int iStack_24;
  int *piStack_18;
  undefined uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797b80;
  pvStack_10 = ExceptionList;
  uVar3 = *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc) & 0xfffffffe;
  uVar2 = uVar3 | 4;
  if (*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) != 0) {
    uVar2 = uVar3;
  }
  ExceptionList = &pvStack_10;
  FUN_00554460(uVar2,0);
  piVar1 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  piStack_18 = param_1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 4))();
  }
  uStack_8 = 0;
  uStack_14 = FUN_00593b40(1);
  uStack_8 = 1;
  if ((*(byte *)(*(int *)(*param_1 + 4) + 0xc + (int)param_1) & 6) == 0) {
    (**(code **)(**(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1) + 0x2c))
              (&uStack_30,param_2,param_3,param_4,param_5,param_6,1);
    if ((uStack_30 + uStack_28 & iStack_2c + iStack_24 + (uint)CARRY4(uStack_30,uStack_28)) ==
        0xffffffff) {
      FUN_00554460();
    }
  }
  uStack_8 = 2;
  piVar1 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 8))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11989 ; VA 0x007d4d30 ; FUN_007d4d30 */

undefined4
FUN_007d4d30(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  FUN_007d49e0(param_1,param_2,param_3,param_4,param_5);
  return param_1;
}



/* FUNCTION 11990 ; VA 0x007d4d50 ; FUN_007d4d50 */

undefined4
FUN_007d4d50(undefined4 param_1,uint param_2,int param_3,uint param_4,int param_5,undefined4 param_6
            ,undefined4 param_7,undefined4 param_8)

{
  FUN_007d49e0(param_1,param_4 + param_2,param_5 + param_3 + (uint)CARRY4(param_4,param_2),0,param_8
              );
  return param_1;
}



/* FUNCTION 11991 ; VA 0x007d4d80 ; FUN_007d4d80 */

void __thiscall FUN_007d4d80(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0x58) = param_2;
  return;
}



/* FUNCTION 11992 ; VA 0x007d4d90 ; FUN_007d4d90 */

void FUN_007d4d90(undefined4 param_1,uint param_2)

{
  uint uVar1;
  undefined *puVar2;
  undefined auStack_138 [196];
  byte abStack_74 [64];
  undefined auStack_34 [12];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0170d1f0(abStack_74,0,0x40);
  uVar1 = 0x40;
  if (param_2 < 0x41) {
    uVar1 = param_2;
  }
  FUN_0170c6f0(abStack_74,param_1,uVar1);
  puVar2 = auStack_138;
  uVar1 = 0;
  do {
    FUN_005bde90(puVar2,"%02x ",abStack_74[uVar1]);
    if (abStack_74[uVar1] < 0x20) {
      abStack_74[uVar1] = 0x2e;
    }
    uVar1 = uVar1 + 1;
    puVar2 = puVar2 + 3;
  } while (uVar1 < 0x40);
  FUN_0054f030();
  uStack_8 = 0;
  FUN_0058a190(0x141);
  FUN_00551620("Failed to resolve texture format | ");
  FUN_00551620(auStack_138);
  FUN_00551620(&DAT_01900330);
  FUN_007ce6e0(abStack_74,auStack_34);
  FUN_005500e0(auStack_28);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_34,&DAT_01c17198);
}



/* FUNCTION 11993 ; VA 0x007d4e80 ; FUN_007d4e80 */

void FUN_007d4e80(int param_1,int param_2,int param_3,int param_4,int param_5)

{
  ushort *puVar1;
  char cVar2;
  uint uVar3;
  uint uVar4;
  
  cVar2 = FUN_0147d280(param_2);
  if (cVar2 == '\0') {
    uVar4 = param_3 * param_4 * param_5;
    if (param_2 == 2) {
      uVar3 = 0;
      if (uVar4 != 0) {
        do {
          puVar1 = (ushort *)(param_1 + uVar3 * 2);
          *puVar1 = *puVar1 & 0xf801;
          uVar3 = uVar3 + 1;
        } while (uVar3 < uVar4);
        return;
      }
    }
    else if ((param_2 == 3) && (uVar4 != 0)) {
      param_1 = param_1 + 2;
      do {
        *(undefined2 *)(param_1 + -1) = 0;
        param_1 = param_1 + 4;
        uVar4 = uVar4 - 1;
      } while (uVar4 != 0);
    }
  }
  return;
}



/* FUNCTION 11994 ; VA 0x007d4ef0 ; FUN_007d4ef0 */

uint __fastcall FUN_007d4ef0(int param_1)

{
  code *pcVar1;
  byte *pbVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined auStack_24 [20];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3ce8;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x48) == 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_007d0020(auStack_24);
    uStack_8 = 0;
    FUN_007ceab0(uVar3);
    pcVar1 = (code *)swi(3);
    uVar4 = (*pcVar1)();
    return uVar4;
  }
  pbVar2 = (byte *)**(undefined4 **)(param_1 + 0x1c);
  if (pbVar2 == (byte *)0x0) {
    ExceptionList = &pvStack_10;
    FUN_007d20b0();
    pbVar2 = (byte *)**(undefined4 **)(param_1 + 0x1c);
  }
  if (pbVar2 != *(byte **)(param_1 + 0x4c)) {
    ExceptionList = pvStack_10;
    return (uint)*pbVar2;
  }
  ExceptionList = pvStack_10;
  return 0xffffffff;
}



/* FUNCTION 11995 ; VA 0x007d4f70 ; FUN_007d4f70 */

int __thiscall FUN_007d4f70(int *param_1,int param_2,undefined4 *param_3)

{
  uint uVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  undefined4 *puVar8;
  uint uVar9;
  int iVar10;
  undefined4 *puVar11;
  
  iVar7 = *param_1;
  iVar10 = param_2 - iVar7 >> 4;
  iVar4 = param_1[1] - iVar7 >> 4;
  if (iVar4 == 0xfffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar4 + 1;
  uVar9 = param_1[2] - iVar7 >> 4;
  uVar5 = uVar1;
  if ((uVar9 <= 0xfffffff - (uVar9 >> 1)) && (uVar5 = (uVar9 >> 1) + uVar9, uVar5 < uVar1)) {
    uVar5 = uVar1;
  }
  uVar9 = uVar5 * 0x10;
  if (uVar5 < 0x10000000) {
    if (0xfff < uVar9) goto LAB_007d4fdd;
    if (uVar9 == 0) {
      puVar11 = (undefined4 *)0x0;
    }
    else {
      puVar11 = (undefined4 *)FUN_01674e20(uVar9);
    }
  }
  else {
    uVar9 = 0xffffffff;
LAB_007d4fdd:
    uVar6 = uVar9 + 0x23;
    if (uVar6 <= uVar9) {
      uVar6 = 0xffffffff;
    }
    iVar7 = FUN_01674e20(uVar6);
    if (iVar7 == 0) goto LAB_007d50ef;
    puVar11 = (undefined4 *)(iVar7 + 0x23U & 0xffffffe0);
    puVar11[-1] = iVar7;
  }
  puVar3 = puVar11 + iVar10 * 4;
  *puVar3 = 0;
  puVar3[1] = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar2 = (int *)(param_3[1] + 4);
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  *puVar3 = *param_3;
  puVar3[1] = param_3[1];
  puVar3[2] = param_3[2];
  puVar3[3] = param_3[3];
  iVar4 = param_1[1];
  iVar7 = *param_1;
  puVar8 = puVar11;
  if (param_2 != iVar4) {
    FUN_007d5da0(iVar7,param_2,puVar11,param_1);
    iVar4 = param_1[1];
    puVar8 = puVar3 + 4;
    iVar7 = param_2;
  }
  FUN_007d5da0(iVar7,iVar4,puVar8,param_1);
  if (*param_1 != 0) {
    FUN_00786f80(*param_1,param_1[1],param_1);
    iVar7 = *param_1;
    uVar9 = param_1[2] - iVar7 & 0xfffffff0;
    iVar4 = iVar7;
    if (0xfff < uVar9) {
      iVar4 = *(int *)(iVar7 + -4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (iVar7 - iVar4) - 4U) {
LAB_007d50ef:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar9);
  }
  *param_1 = (int)puVar11;
  param_1[1] = (int)(puVar11 + uVar1 * 4);
  param_1[2] = (int)(puVar11 + uVar5 * 4);
  return *param_1 + iVar10 * 0x10;
}



/* FUNCTION 11996 ; VA 0x007d5100 ; FUN_007d5100 */

void FUN_007d5100(int param_1,int param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  iVar1 = param_3 - param_1 >> 4;
  if (iVar1 < 0x29) {
    uVar2 = *(uint *)(param_2 + 8);
    if (uVar2 < *(uint *)(param_1 + 8)) {
      FUN_007d5e20(param_2,param_1);
      uVar2 = *(uint *)(param_2 + 8);
    }
    if (*(uint *)(param_3 + 8) < uVar2) {
      FUN_007d5e20(param_3,param_2);
      if (*(uint *)(param_2 + 8) < *(uint *)(param_1 + 8)) {
        FUN_007d5e20(param_2,param_1);
      }
    }
  }
  else {
    iVar4 = iVar1 + 1 >> 3;
    iVar1 = iVar4 * 0x10 + param_1;
    iVar3 = iVar4 * 0x20 + param_1;
    uVar2 = *(uint *)(iVar1 + 8);
    if (uVar2 < *(uint *)(param_1 + 8)) {
      FUN_007d5e20(iVar1,param_1);
      uVar2 = *(uint *)(iVar1 + 8);
    }
    if (*(uint *)(iVar3 + 8) < uVar2) {
      FUN_007d5e20(iVar3,iVar1);
      if (*(uint *)(iVar1 + 8) < *(uint *)(param_1 + 8)) {
        FUN_007d5e20(iVar1,param_1);
      }
    }
    uVar2 = *(uint *)(param_2 + 8);
    iVar3 = iVar4 * 0x10 + param_2;
    iVar5 = param_2 + iVar4 * -0x10;
    if (uVar2 < *(uint *)(iVar5 + 8)) {
      FUN_007d5e20(param_2,iVar5);
      uVar2 = *(uint *)(param_2 + 8);
    }
    if (*(uint *)(iVar3 + 8) < uVar2) {
      FUN_007d5e20(iVar3,param_2);
      if (*(uint *)(param_2 + 8) < *(uint *)(iVar5 + 8)) {
        FUN_007d5e20(param_2,iVar5);
      }
    }
    iVar5 = param_3 + iVar4 * -0x10;
    iVar3 = param_3 + iVar4 * -0x20;
    uVar2 = *(uint *)(iVar5 + 8);
    if (uVar2 < *(uint *)(iVar3 + 8)) {
      FUN_007d5e20(iVar5,iVar3);
      uVar2 = *(uint *)(iVar5 + 8);
    }
    if (*(uint *)(param_3 + 8) < uVar2) {
      FUN_007d5e20(param_3,iVar5);
      if (*(uint *)(iVar5 + 8) < *(uint *)(iVar3 + 8)) {
        FUN_007d5e20(iVar5,iVar3);
      }
    }
    uVar2 = *(uint *)(param_2 + 8);
    if (uVar2 < *(uint *)(iVar1 + 8)) {
      FUN_007d5e20(param_2,iVar1);
      uVar2 = *(uint *)(param_2 + 8);
    }
    if (*(uint *)(iVar5 + 8) < uVar2) {
      FUN_007d5e20(iVar5,param_2);
      if (*(uint *)(param_2 + 8) < *(uint *)(iVar1 + 8)) {
        FUN_007d5e20(param_2,iVar1);
        return;
      }
    }
  }
  return;
}



/* FUNCTION 11997 ; VA 0x007d5290 ; FUN_007d5290 */

undefined4 * FUN_007d5290(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int *piVar9;
  int iVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  undefined4 *puVar13;
  
  if (param_1 == param_2) {
    return param_2;
  }
  puVar13 = param_1 + 4;
  if (puVar13 != param_2) {
    do {
      uVar3 = *puVar13;
      uVar4 = puVar13[1];
      *puVar13 = 0;
      puVar13[1] = 0;
      uVar5 = puVar13[3];
      uVar6 = puVar13[2];
      if (uVar6 < (uint)param_1[2]) {
        if (puVar13 != param_1) {
          puVar11 = puVar13 + 4;
          puVar12 = puVar13 + -3;
          do {
            uVar7 = puVar12[-1];
            uVar8 = *puVar12;
            puVar12[-1] = 0;
            *puVar12 = 0;
            puVar11[-4] = uVar7;
            piVar9 = (int *)puVar11[-3];
            puVar11[-3] = uVar8;
            if (piVar9 != (int *)0x0) {
              LOCK();
              iVar10 = piVar9[1] + -1;
              piVar9[1] = iVar10;
              UNLOCK();
              if (iVar10 == 0) {
                (**(code **)*piVar9)();
                LOCK();
                iVar10 = piVar9[2] + -1;
                piVar9[2] = iVar10;
                UNLOCK();
                if (iVar10 == 0) {
                  (**(code **)(*piVar9 + 4))();
                }
              }
            }
            puVar11[-2] = puVar12[1];
            puVar11[-1] = puVar12[2];
            puVar1 = puVar12 + -1;
            puVar11 = puVar11 + -4;
            puVar12 = puVar12 + -4;
          } while (puVar1 != param_1);
        }
        *param_1 = uVar3;
        piVar9 = (int *)param_1[1];
        param_1[1] = uVar4;
        if (piVar9 != (int *)0x0) {
          LOCK();
          iVar10 = piVar9[1] + -1;
          piVar9[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piVar9)();
            LOCK();
            iVar10 = piVar9[2] + -1;
            piVar9[2] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar9 + 4))();
            }
          }
        }
        param_1[2] = uVar6;
        param_1[3] = uVar5;
      }
      else {
        uVar2 = puVar13[-2];
        puVar11 = puVar13;
        while (uVar6 < uVar2) {
          puVar12 = puVar11 + -4;
          uVar7 = *puVar12;
          uVar8 = puVar11[-3];
          *puVar12 = 0;
          puVar11[-3] = 0;
          *puVar11 = uVar7;
          piVar9 = (int *)puVar11[1];
          puVar11[1] = uVar8;
          if (piVar9 != (int *)0x0) {
            LOCK();
            iVar10 = piVar9[1] + -1;
            piVar9[1] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)*piVar9)();
              LOCK();
              iVar10 = piVar9[2] + -1;
              piVar9[2] = iVar10;
              UNLOCK();
              if (iVar10 == 0) {
                (**(code **)(*piVar9 + 4))();
              }
            }
          }
          puVar11[2] = puVar11[-2];
          puVar11[3] = puVar11[-1];
          uVar2 = puVar11[-6];
          puVar11 = puVar12;
        }
        *puVar11 = uVar3;
        piVar9 = (int *)puVar11[1];
        puVar11[1] = uVar4;
        if (piVar9 != (int *)0x0) {
          LOCK();
          iVar10 = piVar9[1] + -1;
          piVar9[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piVar9)();
            LOCK();
            iVar10 = piVar9[2] + -1;
            piVar9[2] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar9 + 4))();
            }
          }
        }
        puVar11[2] = uVar6;
        puVar11[3] = uVar5;
      }
      puVar13 = puVar13 + 4;
    } while (puVar13 != param_2);
    return param_2;
  }
  return param_2;
}



/* FUNCTION 11998 ; VA 0x007d5470 ; FUN_007d5470 */

uint FUN_007d5470(int param_1,int param_2)

{
  uint *puVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  undefined4 uStack_2c;
  int *piStack_28;
  uint uStack_24;
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  undefined4 *puStack_10;
  undefined4 *puStack_c;
  undefined4 *puStack_8;
  
  uVar7 = param_2 - param_1 >> 4;
  puStack_8 = (undefined4 *)(param_2 - param_1 >> 5);
  uVar8 = uVar7;
  if (0 < (int)puStack_8) {
    puStack_14 = (undefined4 *)(uVar7 - 1);
    puStack_10 = (undefined4 *)((int)puStack_14 >> 1);
    puStack_1c = (undefined4 *)(param_1 + 4 + (int)puStack_8 * 0x10);
    do {
      uStack_2c = puStack_1c[-5];
      puVar11 = puStack_1c + -4;
      puVar9 = (undefined4 *)((int)puStack_8 + -1);
      piStack_28 = (int *)*puVar11;
      puStack_1c[-5] = 0;
      *puVar11 = 0;
      uStack_24 = puStack_1c[-3];
      uStack_20 = puStack_1c[-2];
      puVar10 = puVar9;
      puStack_1c = puVar11;
      uStack_18 = uStack_24;
      puStack_8 = puVar9;
      if ((int)puVar9 < (int)puStack_10) {
        do {
          puVar9 = (undefined4 *)
                   (((int)puVar10 * 2 + 2) -
                   (uint)(*(uint *)(param_1 + 0x28 + (int)puVar10 * 0x20) <
                         *(uint *)(param_1 + 0x18 + (int)puVar10 * 0x20)));
          puVar10 = (undefined4 *)((int)puVar10 * 0x10 + param_1);
          puStack_c = (undefined4 *)((int)puVar9 * 0x10 + param_1);
          uVar3 = *puStack_c;
          uVar4 = puStack_c[1];
          *puStack_c = 0;
          puStack_c[1] = 0;
          *puVar10 = uVar3;
          piVar5 = (int *)puVar10[1];
          puVar10[1] = uVar4;
          if (piVar5 != (int *)0x0) {
            LOCK();
            iVar6 = piVar5[1] + -1;
            piVar5[1] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)*piVar5)();
              LOCK();
              iVar6 = piVar5[2] + -1;
              piVar5[2] = iVar6;
              UNLOCK();
              if (iVar6 == 0) {
                (**(code **)(*piVar5 + 4))();
              }
            }
          }
          puVar10[2] = puStack_c[2];
          puVar10[3] = puStack_c[3];
          puVar10 = puVar9;
        } while ((int)puVar9 < (int)puStack_10);
      }
      if ((puVar9 == puStack_10) && ((uVar7 & 1) == 0)) {
        FUN_007d5ef0(uVar7 * 0x10 + -0x10 + param_1);
        puVar9 = puStack_14;
      }
      puStack_c = puVar9;
      puVar10 = (undefined4 *)((int)puStack_c + -1 >> 1);
      if ((int)puStack_8 < (int)puStack_c) {
        do {
          puVar9 = (undefined4 *)(param_1 + (int)puVar10 * 0x10);
          if (uStack_18 <= (uint)puVar9[2]) break;
          uVar3 = *puVar9;
          uVar4 = puVar9[1];
          puVar11 = (undefined4 *)((int)puStack_c * 0x10 + param_1);
          *puVar9 = 0;
          puVar9[1] = 0;
          *puVar11 = uVar3;
          piVar5 = (int *)puVar11[1];
          puVar11[1] = uVar4;
          puStack_c = puVar10;
          if (piVar5 != (int *)0x0) {
            LOCK();
            iVar6 = piVar5[1] + -1;
            piVar5[1] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)*piVar5)();
              LOCK();
              iVar6 = piVar5[2] + -1;
              piVar5[2] = iVar6;
              UNLOCK();
              if (iVar6 == 0) {
                (**(code **)(*piVar5 + 4))();
              }
            }
          }
          puVar11[2] = puVar9[2];
          puVar11[3] = puVar9[3];
          puVar10 = (undefined4 *)((int)puStack_c + -1 >> 1);
        } while ((int)puStack_8 < (int)puStack_c);
      }
      puStack_c = puVar10;
      uVar8 = FUN_007d5ef0(&uStack_2c);
      piVar5 = piStack_28;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        puVar1 = (uint *)(piStack_28 + 1);
        uVar2 = *puVar1;
        uVar8 = *puVar1;
        *puVar1 = uVar2 - 1;
        UNLOCK();
        if (uVar2 - 1 == 0) {
          (**(code **)*piStack_28)();
          LOCK();
          puVar1 = (uint *)(piVar5 + 2);
          uVar2 = *puVar1;
          uVar8 = *puVar1;
          *puVar1 = uVar2 - 1;
          UNLOCK();
          if (uVar2 - 1 == 0) {
            uVar8 = (**(code **)(*piVar5 + 4))();
          }
        }
      }
    } while (0 < (int)puStack_8);
  }
  return uVar8;
}



/* FUNCTION 11999 ; VA 0x007d5650 ; FUN_007d5650 */

undefined4 * FUN_007d5650(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  
  puVar5 = param_3;
  puVar6 = param_1;
  if (param_1 != param_2) {
    do {
      uVar1 = *puVar6;
      uVar2 = *(undefined4 *)((int)param_1 + (4 - (int)param_3) + (int)puVar5);
      *puVar6 = 0;
      *(undefined4 *)((int)param_1 + (4 - (int)param_3) + (int)puVar5) = 0;
      *puVar5 = uVar1;
      piVar3 = (int *)puVar5[1];
      puVar5[1] = uVar2;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar4 = piVar3[1] + -1;
        piVar3[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar4 = piVar3[2] + -1;
          piVar3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      puVar5[2] = puVar6[2];
      puVar7 = puVar6 + 4;
      puVar5[3] = puVar6[3];
      puVar5 = puVar5 + 4;
      puVar6 = puVar7;
    } while (puVar7 != param_2);
  }
  return puVar5;
}


