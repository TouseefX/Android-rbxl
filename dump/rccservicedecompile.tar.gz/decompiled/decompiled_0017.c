/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 4250 ; VA 0x00593b40 ; FUN_00593b40 */

uint __thiscall FUN_00593b40(int *param_1,char param_2)

{
  int *piVar1;
  undefined *puVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017978a8;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd4;
  iVar3 = *param_1;
  ExceptionList = &pvStack_10;
  piStack_18 = param_1;
  puVar2 = &stack0xffffffd4;
  if (*(int *)(*(int *)(iVar3 + 4) + 0xc + (int)param_1) == 0) {
    ExceptionList = &pvStack_10;
    puVar2 = &stack0xffffffd4;
    if (*(int *)(*(int *)(iVar3 + 4) + 0x3c + (int)param_1) != 0) {
      ExceptionList = &pvStack_10;
      FUN_00581480();
      iVar3 = *param_1;
      puVar2 = puStack_14;
    }
    puStack_14 = puVar2;
    if ((param_2 == '\0') && ((*(byte *)(*(int *)(iVar3 + 4) + 0x14 + (int)param_1) & 1) != 0)) {
      piVar1 = *(int **)(*(int *)(*(int *)(iVar3 + 4) + 0x30 + (int)param_1) + 4);
      uStack_8 = 0;
      piStack_1c = piVar1;
      (**(code **)(*piVar1 + 4))();
      uStack_8 = 1;
      iVar3 = FUN_0054e7d0(auStack_20);
      uStack_8 = 2;
      if (piVar1 != (int *)0x0) {
        puVar4 = (undefined4 *)(**(code **)(*piVar1 + 8))();
        if (puVar4 != (undefined4 *)0x0) {
          (**(code **)*puVar4)(1);
        }
      }
      uStack_8 = 3;
      piVar1 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
      if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
        uVar5 = (**(code **)(*piVar1 + 0x18))();
      }
      else {
        uVar5 = (uint)**(byte **)piVar1[7];
      }
      while( true ) {
        if (uVar5 == 0xffffffff) {
          FUN_00554460((uint)(*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) == 0) * 4 + 1 |
                       *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc),0);
          uVar5 = FUN_00593c77();
          return uVar5;
        }
        if ((*(byte *)(*(int *)(iVar3 + 0xc) + (uVar5 & 0xff) * 2) & 0x48) == 0) break;
        uVar5 = FUN_0058c090();
      }
      uStack_8 = 0xffffffff;
    }
    iVar3 = *param_1;
    puVar2 = puStack_14;
    if (*(int *)(*(int *)(iVar3 + 4) + 0xc + (int)param_1) == 0) {
      ExceptionList = pvStack_10;
      return CONCAT31((int3)((uint)*(int *)(iVar3 + 4) >> 8),1);
    }
  }
  puStack_14 = puVar2;
  uVar5 = FUN_00554460((uint)(*(int *)((int)param_1 + *(int *)(iVar3 + 4) + 0x38) == 0) * 4 + 2 |
                       *(uint *)((int)param_1 + *(int *)(iVar3 + 4) + 0xc),0);
  ExceptionList = pvStack_10;
  return uVar5 & 0xffffff00;
}



/* FUNCTION 4251 ; VA 0x00593c5b ; Catch_All@00593c5b */

undefined * Catch_All_00593c5b(void)

{
  FUN_005565b0(4,1);
  return &DAT_00593c74;
}



/* FUNCTION 4252 ; VA 0x00593c77 ; FUN_00593c77 */

uint FUN_00593c77(void)

{
  int iVar1;
  uint uVar2;
  int unaff_EBP;
  int *unaff_ESI;
  
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  iVar1 = *(int *)(*unaff_ESI + 4);
  if (*(int *)(iVar1 + 0xc + (int)unaff_ESI) == 0) {
    ExceptionList = *(void **)(unaff_EBP + -0xc);
    return CONCAT31((int3)((uint)iVar1 >> 8),1);
  }
  iVar1 = *(int *)(*unaff_ESI + 4);
  uVar2 = FUN_00554460((uint)(*(int *)((int)unaff_ESI + iVar1 + 0x38) == 0) * 4 + 2 |
                       *(uint *)((int)unaff_ESI + iVar1 + 0xc),0);
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return uVar2 & 0xffffff00;
}



/* FUNCTION 4253 ; VA 0x00593ce0 ; FUN_00593ce0 */

void FUN_00593ce0(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("deque<T> too long");
}



/* FUNCTION 4254 ; VA 0x00593cf0 ; FUN_00593cf0 */

void FUN_00593cf0(undefined4 param_1,char param_2,undefined4 param_3)

{
  undefined uVar1;
  undefined4 uVar2;
  undefined4 ****ppppuVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  undefined auStack_dc [24];
  int aiStack_c4 [5];
  uint uStack_b0;
  uint uStack_ac;
  undefined4 uStack_9c;
  uint uStack_98;
  uint uStack_94;
  undefined4 uStack_84;
  uint uStack_80;
  uint auStack_7c [4];
  undefined4 uStack_6c;
  uint uStack_68;
  int iStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  uint uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_3c;
  uint uStack_38;
  undefined4 uStack_34;
  undefined4 ***apppuStack_30 [4];
  int iStack_20;
  uint uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179792f;
  pvStack_10 = ExceptionList;
  iStack_18 = 0;
  ExceptionList = &pvStack_10;
  piStack_14 = (int *)FUN_01685730();
  uStack_34 = FUN_01686c70();
  uStack_3c = 0;
  uStack_38 = 7;
  uStack_4c = (uint)uStack_4c._2_2_ << 0x10;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  iStack_20 = 0;
  uStack_1c = 0xf;
  apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
  FUN_005542c0("archive",7);
  uStack_8._0_1_ = 2;
  if (iStack_20 != 0) {
    ppppuVar3 = apppuStack_30;
    if (0xf < uStack_1c) {
      ppppuVar3 = (undefined4 ****)apppuStack_30[0];
    }
    iVar6 = (int)ppppuVar3 + iStack_20;
    ppppuVar3 = apppuStack_30;
    if (0xf < uStack_1c) {
      ppppuVar3 = (undefined4 ****)apppuStack_30[0];
    }
    uVar2 = FUN_01686580();
    FUN_01685950(ppppuVar3,iVar6,&uStack_4c,uVar2);
  }
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_1c) {
    uVar5 = uStack_1c + 1;
    ppppuVar3 = (undefined4 ****)apppuStack_30[0];
    if (0xfff < uVar5) {
      ppppuVar3 = (undefined4 ****)apppuStack_30[0][-1];
      uVar5 = uStack_1c + 0x24;
      if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar3))) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar3,uVar5);
  }
  iStack_20 = 0;
  uStack_1c = 0xf;
  apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
  uStack_8._0_1_ = 3;
  uVar2 = FUN_01688660();
  uStack_8._0_1_ = 4;
  uVar2 = FUN_005514a0(auStack_7c,uVar2,&uStack_4c);
  uStack_8._0_1_ = 5;
  FUN_005514a0(aiStack_c4,uVar2,uStack_34);
  uStack_8._0_1_ = 7;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 7;
  if (7 < uStack_68) {
    uVar5 = uStack_68 * 2 + 2;
    uVar4 = auStack_7c[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_7c[0] - 4);
      uVar5 = uStack_68 * 2 + 0x25;
      if (0x1f < (auStack_7c[0] - uVar4) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  uStack_6c = 0;
  uStack_68 = 7;
  auStack_7c[0] = auStack_7c[0] & 0xffff0000;
  uStack_8._0_1_ = 8;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  if (7 < uStack_80) {
    uVar5 = uStack_80 * 2 + 2;
    uVar4 = uStack_94;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(uStack_94 - 4);
      uVar5 = uStack_80 * 2 + 0x25;
      if (0x1f < (uStack_94 - uVar4) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  uStack_84 = 0;
  uStack_80 = 7;
  uStack_94 = uStack_94 & 0xffff0000;
  uStack_8._0_1_ = 9;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 9;
  if (7 < uStack_38) {
    uVar5 = uStack_38 * 2 + 2;
    uVar4 = uStack_4c;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(uStack_4c - 4);
      uVar5 = uStack_38 * 2 + 0x25;
      if (0x1f < (uStack_4c - uVar4) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  uStack_3c = 0;
  uStack_38 = 7;
  uStack_4c = uStack_4c & 0xffff0000;
  uStack_8._0_1_ = 10;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 10;
  if (7 < uStack_98) {
    uVar5 = uStack_98 * 2 + 2;
    uVar4 = uStack_ac;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(uStack_ac - 4);
      uVar5 = uStack_98 * 2 + 0x25;
      if (0x1f < (uStack_ac - uVar4) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  uStack_9c = 0;
  uStack_ac = uStack_ac & 0xffff0000;
  uStack_98 = 7;
  uVar2 = FUN_01688660();
  uStack_8._0_1_ = 0xb;
  FUN_0168be30(uVar2,&iStack_18);
  uStack_8._0_1_ = 10;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 10;
  if (7 < uStack_50) {
    uVar5 = uStack_50 * 2 + 2;
    iVar6 = iStack_64;
    if (0xfff < uVar5) {
      iVar6 = *(int *)(iStack_64 + -4);
      uVar5 = uStack_50 * 2 + 0x25;
      if (0x1f < (iStack_64 - iVar6) - 4U) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar5);
  }
  FUN_0168df40(param_1,aiStack_c4,&iStack_18);
  if (iStack_18 != 0) {
    if (param_2 != '\0') {
      (**(code **)(*piStack_14 + 8))(&iStack_64,iStack_18);
      uStack_8._0_1_ = 0xc;
      FUN_01675640(auStack_dc,"Failed to archive dump file: %s",iStack_64,uStack_60,uStack_5c,
                   uStack_58,CONCAT44(uStack_50,uStack_54));
      uStack_8._0_1_ = 0xe;
      FUN_005507b0();
      uVar2 = FUN_005569d0();
      uStack_8._0_1_ = 0xf;
      iStack_20 = 0;
      uStack_1c = 0xf;
      apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
      FUN_005542c0("FailedToArchiveDumpFile",0x17);
      uStack_8._0_1_ = 0x10;
      FUN_00594330(apppuStack_30,auStack_dc,uVar2,param_3);
      FUN_005507b0();
      FUN_005507b0();
      uStack_8._0_1_ = 10;
      FUN_005507b0();
    }
    FUN_0168da40(param_1,&iStack_18);
  }
  if (7 < uStack_b0) {
    uVar5 = uStack_b0 * 2 + 2;
    iVar6 = aiStack_c4[0];
    if (0xfff < uVar5) {
      iVar6 = *(int *)(aiStack_c4[0] + -4);
      uVar5 = uStack_b0 * 2 + 0x25;
      if (0x1f < (aiStack_c4[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4255 ; VA 0x00594150 ; FUN_00594150 */

undefined4 * __thiscall FUN_00594150(undefined4 *param_1,uint param_2)

{
  code *pcVar1;
  undefined4 *puVar2;
  
  if (param_2 <= (uint)param_1[4]) {
    puVar2 = param_1;
    if (0xf < (uint)param_1[5]) {
      puVar2 = (undefined4 *)*param_1;
    }
    param_1[4] = param_2;
    *(undefined *)((int)puVar2 + param_2) = 0;
    return param_1;
  }
  FUN_00554050();
  pcVar1 = (code *)swi(3);
  puVar2 = (undefined4 *)(*pcVar1)();
  return puVar2;
}



/* FUNCTION 4256 ; VA 0x00594180 ; FUN_00594180 */

void FUN_00594180(undefined4 *param_1)

{
  int *piVar1;
  code *pcVar2;
  
  pcVar2 = (code *)*param_1;
  if (param_1[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar2)(param_1[1],param_1[2]);
  return;
}



/* FUNCTION 4257 ; VA 0x005941c0 ; FUN_005941c0 */

int * FUN_005941c0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = 0;
      param_2[2] = 0;
      if (param_1[2] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[2] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[1] = param_1[1];
      piVar3 = (int *)param_1[2];
      param_2[2] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[2];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x005942a2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[2];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00594216. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1d929d4);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<enum_RBX::worker_thread::work_result,enum_RBX::worker_thread::work_result_(__cdecl*)(class_std::shared_ptr<struct_ErrorUploader::data>),class_boost::_bi::list1<class_boost::_bi::value<class_std::shared_ptr<struct_ErrorUploader::data>_>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 4258 ; VA 0x005942c0 ; FUN_005942c0 */

void __fastcall FUN_005942c0(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  piVar1 = *(int **)(*(int *)(param_1 + 4) +
                    (*(int *)(param_1 + 0xc) + *(int *)(param_1 + 0x10) + -1 &
                    *(int *)(param_1 + 8) - 1U) * 4);
  uVar2 = piVar1[5];
  if (0xf < uVar2) {
    iVar3 = *piVar1;
    uVar5 = uVar2 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  piVar1[4] = 0;
  piVar1[5] = 0xf;
  *(undefined *)piVar1 = 0;
  piVar1 = (int *)(param_1 + 0x10);
  *piVar1 = *piVar1 + -1;
  if (*piVar1 == 0) {
    *(undefined4 *)(param_1 + 0xc) = 0;
  }
  return;
}



/* FUNCTION 4259 ; VA 0x00594330 ; FUN_00594330 */

void FUN_00594330(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined uVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797958;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0151f6f0(0xffffffff,0,0);
  uStack_8 = 0;
  FUN_0151f950();
  FUN_0151f950();
  FUN_0151f950();
  FUN_0151f9c0();
  FUN_0151f850();
  FUN_0151f850();
  uVar2 = DAT_01d5940c;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0();
  uStack_8._0_1_ = 1;
  FUN_01520d20(auStack_28,uVar2,0);
  uStack_8._0_1_ = 0;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_14) {
    if (0xfff < uStack_14 + 1) {
      if (0x1f < (auStack_28[0] - *(int *)(auStack_28[0] - 4)) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  uVar2 = FUN_01675640(auStack_28,"Win32-CrashUploadError-%s",param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00878cf0(uVar2,(double)param_4,0);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    uVar3 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  FUN_0151f7f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4260 ; VA 0x005944d0 ; FUN_005944d0 */

/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_005944d0(int param_1,int *param_2)

{
  uint *puVar1;
  uint uVar2;
  undefined uVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 *******pppppppuVar6;
  byte *pbVar7;
  uint uVar8;
  int *piVar9;
  undefined4 *puVar10;
  int *piVar11;
  undefined4 *puVar12;
  undefined4 *******pppppppuVar13;
  byte *pbVar14;
  byte *pbVar15;
  uint uVar16;
  int iVar17;
  uint uVar18;
  int iVar19;
  bool bVar20;
  float10 fVar21;
  undefined8 uVar22;
  undefined8 uVar23;
  undefined auStack_240 [24];
  undefined auStack_228 [8];
  undefined auStack_220 [24];
  undefined auStack_208 [20];
  int iStack_1f4;
  undefined **appuStack_1f0 [2];
  undefined8 uStack_1e8;
  undefined **ppuStack_1e0;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  undefined4 *puStack_1d4;
  undefined4 *puStack_1d0;
  undefined4 uStack_1cc;
  undefined4 uStack_1c8;
  undefined4 *puStack_1c4;
  undefined4 *apuStack_1c0 [2];
  int iStack_1b8;
  undefined4 **ppuStack_1b4;
  int *piStack_1b0;
  undefined4 uStack_1a8;
  undefined uStack_1a3;
  undefined4 uStack_1a0;
  undefined4 uStack_19c;
  undefined uStack_198;
  int iStack_194;
  undefined4 uStack_184;
  undefined **ppuStack_180;
  uint auStack_134 [4];
  undefined4 uStack_124;
  uint uStack_120;
  undefined auStack_114 [24];
  undefined auStack_fc [24];
  undefined4 *******apppppppuStack_e4 [4];
  undefined4 uStack_d4;
  uint uStack_d0;
  undefined4 *******apppppppuStack_cc [4];
  int iStack_bc;
  uint uStack_b8;
  undefined4 *******apppppppuStack_b4 [4];
  undefined4 uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  uint uStack_98;
  undefined4 uStack_94;
  int aiStack_90 [5];
  uint uStack_7c;
  undefined4 *******apppppppuStack_78 [3];
  undefined auStack_6c [4];
  undefined4 uStack_68;
  uint uStack_64;
  undefined4 *******apppppppuStack_60 [4];
  uint uStack_50;
  uint uStack_4c;
  undefined8 uStack_48;
  undefined4 *******apppppppuStack_40 [4];
  uint uStack_30;
  uint uStack_2c;
  int *piStack_28;
  int *piStack_24;
  char cStack_1e;
  char cStack_1d;
  uint uStack_1c;
  char cStack_15;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01797b5b;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffdb4;
  uStack_1c = 0;
  iStack_bc = 0;
  uStack_b8 = 7;
  apppppppuStack_cc[0] = (undefined4 *******)((uint)apppppppuStack_cc[0] & 0xffff0000);
  uStack_a4 = 0;
  uStack_a0 = 7;
  apppppppuStack_b4[0] = (undefined4 *******)((uint)apppppppuStack_b4[0] & 0xffff0000);
  uStack_9c = 0;
  uStack_98 = 0;
  uStack_94 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  FUN_00591e70(param_1 + 0x28);
  uStack_8._0_1_ = 2;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (*(int *)(param_1 + 0x24) == 0) {
    if (*(int *)(param_1 + 0x58) != 0) {
      CloseHandle(*(int *)(param_1 + 0x58));
      *(undefined4 *)(param_1 + 0x58) = 0;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (((char)piStack_24 != '\0') && (*piStack_28 = *piStack_28 + -1, *piStack_28 == 0)) {
      LOCK();
      piStack_28[1] = 0;
      UNLOCK();
      puVar1 = (uint *)(piStack_28 + 2);
      LOCK();
      uVar8 = *puVar1;
      *puVar1 = *puVar1 + 0x80000000;
      UNLOCK();
      if (((uVar8 & 0x40000000) == 0) && (-0x80000000 < (int)uVar8)) {
        LOCK();
        uVar8 = *puVar1;
        *puVar1 = *puVar1 | 0x40000000;
        UNLOCK();
        if ((uVar8 >> 0x1e & 1) == 0) {
          uVar5 = FUN_00554e40();
          SetEvent(uVar5);
        }
      }
    }
    FUN_0058dbf0();
    if (param_2 != (int *)0x0) {
      LOCK();
      iVar17 = param_2[1] + -1;
      param_2[1] = iVar17;
      UNLOCK();
      if (iVar17 == 0) {
        (**(code **)*param_2)();
        LOCK();
        piVar11 = param_2 + 2;
        iVar17 = *piVar11;
        *piVar11 = *piVar11 + -1;
        UNLOCK();
        if (iVar17 == 1) {
          (**(code **)(*param_2 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return 0;
  }
  if (((int *)(param_1 + 0x14) == (int *)0x0) ||
     (piVar11 = *(int **)(param_1 + 0x14), piVar11 == (int *)0x0)) {
    iVar17 = 0;
  }
  else {
    iVar17 = *piVar11;
  }
  pppppppuVar13 =
       *(undefined4 ********)
        (*(int *)(iVar17 + 4) + (*(int *)(iVar17 + 8) - 1U & *(uint *)(param_1 + 0x20)) * 4);
  uStack_8._0_1_ = uVar3;
  if (apppppppuStack_cc != (undefined4 ********)pppppppuVar13) {
    pppppppuVar6 = pppppppuVar13;
    if ((undefined4 ******)0x7 < pppppppuVar13[5]) {
      pppppppuVar6 = (undefined4 *******)*pppppppuVar13;
    }
    FUN_0058ed10(pppppppuVar6,pppppppuVar13[4]);
  }
  pppppppuVar6 = pppppppuVar13 + 6;
  if (apppppppuStack_b4 != (undefined4 ********)pppppppuVar6) {
    if ((undefined4 ******)0x7 < pppppppuVar13[0xb]) {
      pppppppuVar6 = (undefined4 *******)*pppppppuVar6;
    }
    FUN_0058ed10(pppppppuVar6,pppppppuVar13[10]);
  }
  FUN_00592480(pppppppuVar13 + 0xc);
  uStack_8._0_1_ = 4;
  if (((char)piStack_24 != '\0') && (*piStack_28 = *piStack_28 + -1, *piStack_28 == 0)) {
    LOCK();
    piStack_28[1] = 0;
    UNLOCK();
    puVar1 = (uint *)(piStack_28 + 2);
    LOCK();
    uVar8 = *puVar1;
    *puVar1 = *puVar1 + 0x80000000;
    UNLOCK();
    if (((uVar8 & 0x40000000) == 0) && (-0x80000000 < (int)uVar8)) {
      LOCK();
      uVar8 = *puVar1;
      *puVar1 = *puVar1 | 0x40000000;
      UNLOCK();
      if ((uVar8 >> 0x1e & 1) == 0) {
        uVar5 = FUN_00554e40();
        SetEvent(uVar5);
      }
    }
  }
  cStack_1e = '\0';
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  uStack_30 = 0;
  uStack_2c = 0xf;
  apppppppuStack_40[0] = (undefined4 *******)((uint)apppppppuStack_40[0] & 0xffffff00);
  uStack_1c = 1;
  if (iStack_bc != 0) {
    pppppppuVar13 = apppppppuStack_cc;
    if (7 < uStack_b8) {
      pppppppuVar13 = apppppppuStack_cc[0];
    }
    iVar17 = iStack_bc * 2;
    uVar5 = FUN_01686580();
    FUN_01685a20(pppppppuVar13,(int)pppppppuVar13 + iVar17,apppppppuStack_40,uVar5);
  }
  iVar17 = iStack_bc;
  pppppppuVar13 = apppppppuStack_40;
  if (0xf < uStack_2c) {
    pppppppuVar13 = apppppppuStack_40[0];
  }
  uStack_48 = (double)CONCAT44(pppppppuVar13,(undefined4)uStack_48);
  if (5 < uStack_30) {
    uStack_1c = (uStack_30 - 5) + (int)pppppppuVar13;
    pbVar7 = (byte *)FUN_0170db20(pppppppuVar13,0x2e,uStack_1c - (int)pppppppuVar13);
    uVar22 = uStack_48;
    while (uStack_48 = (double)uVar22, pbVar7 != (byte *)0x0) {
      pbVar15 = &DAT_018c1378;
      iVar19 = 2;
      pbVar14 = pbVar7;
      if (*(int *)pbVar7 == _DAT_018c1378) {
        pbVar14 = pbVar7 + 4;
        iVar19 = -2;
        pbVar15 = &DAT_018c137c;
      }
      bVar20 = *pbVar14 < *pbVar15;
      if (((*pbVar14 == *pbVar15) && (bVar20 = pbVar14[1] < pbVar15[1], pbVar14[1] == pbVar15[1]))
         && ((iVar19 == -2 ||
             ((bVar20 = pbVar14[2] < pbVar15[2], pbVar14[2] == pbVar15[2] &&
              (bVar20 = pbVar14[3] < pbVar15[3], pbVar14[3] == pbVar15[3])))))) {
        uVar8 = 0;
      }
      else {
        uVar8 = -(uint)bVar20 | 1;
      }
      if (uVar8 == 0) {
        uStack_48._4_4_ = (int)((ulonglong)uVar22 >> 0x20);
        iVar19 = (int)pbVar7 - uStack_48._4_4_;
        goto LAB_005947de;
      }
      pbVar7 = (byte *)FUN_0170db20(pbVar7 + 1,0x2e,uStack_1c - (int)(pbVar7 + 1));
      uVar22 = uStack_48;
    }
  }
  iVar19 = -1;
LAB_005947de:
  uStack_8._0_1_ = 5;
  if (0xf < uStack_2c) {
    uVar8 = uStack_2c + 1;
    pppppppuVar13 = apppppppuStack_40[0];
    if (0xfff < uVar8) {
      pppppppuVar13 = (undefined4 *******)apppppppuStack_40[0][-1];
      uVar8 = uStack_2c + 0x24;
      if (0x1f < (uint)((int)apppppppuStack_40[0] + (-4 - (int)pppppppuVar13))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppppuVar13,uVar8);
    iVar17 = iStack_bc;
  }
  cStack_15 = '\0';
  if ((iVar19 != -1) && (DAT_01d59478 == '\0')) {
    if (DAT_01d84e8e != '\0') {
      uStack_8._0_1_ = 7;
      uStack_30 = 0;
      uStack_2c = 0xf;
      apppppppuStack_40[0] = (undefined4 *******)((uint)apppppppuStack_40[0] & 0xffffff00);
      uStack_1c = 2;
      if (iVar17 != 0) {
        pppppppuVar13 = apppppppuStack_cc;
        if (7 < uStack_b8) {
          pppppppuVar13 = apppppppuStack_cc[0];
        }
        uVar5 = FUN_01686580();
        FUN_01685a20(pppppppuVar13,(int)pppppppuVar13 + iVar17 * 2,apppppppuStack_40,uVar5);
      }
      pppppppuVar13 = apppppppuStack_40;
      if (0xf < uStack_2c) {
        pppppppuVar13 = apppppppuStack_40[0];
      }
      FUN_01677520(DAT_01d84e8e,"Not uploading %s because it is a full dump",pppppppuVar13);
      uStack_8._0_1_ = 5;
      if (0xf < uStack_2c) {
        uVar8 = uStack_2c + 1;
        pppppppuVar13 = apppppppuStack_40[0];
        if (0xfff < uVar8) {
          pppppppuVar13 = (undefined4 *******)apppppppuStack_40[0][-1];
          uVar8 = uStack_2c + 0x24;
          if (0x1f < (uint)((int)apppppppuStack_40[0] + (-4 - (int)pppppppuVar13))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(pppppppuVar13,uVar8);
      }
    }
    goto LAB_005952d5;
  }
  uVar5 = FUN_005569d0(aiStack_90);
  uStack_8._0_1_ = 9;
  FUN_0086dbc0(auStack_fc,uVar5);
  uStack_8._0_1_ = 0xb;
  FUN_005507b0();
  FUN_0054ef60(auStack_fc);
  cStack_1d = '\0';
  pppppppuVar13 = apppppppuStack_b4;
  if (7 < uStack_a0) {
    pppppppuVar13 = apppppppuStack_b4[0];
  }
  appuStack_1f0[0] = &PTR_018bd138;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  ppuStack_180 = std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  uStack_184 = 0x58;
  uStack_1c = 8;
  uStack_1e8 = 0;
  FUN_00554f20(&ppuStack_1e0,0);
  uStack_8 = 0xf;
  *(undefined ***)((int)appuStack_1f0 + (int)appuStack_1f0[0][1]) =
       std::basic_ifstream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)((int)&iStack_1f4 + (int)appuStack_1f0[0][1]) = appuStack_1f0[0][1] + -0x70;
  FUN_0054ee60();
  puStack_1d4 = &uStack_1dc;
  ppuStack_1e0 = std::basic_filebuf<char,struct_std::char_traits<char>_>::vftable;
  puStack_1d0 = &uStack_1d8;
  puStack_1c4 = &uStack_1cc;
  apuStack_1c0[0] = &uStack_1c8;
  ppuStack_1b4 = apuStack_1c0 + 1;
  piStack_1b0 = &iStack_1b8;
  uStack_1a0 = DAT_01e90d08;
  uStack_198 = 0;
  uStack_1a3 = 0;
  uStack_1d8 = 0;
  uStack_1c8 = 0;
  iStack_1b8 = 0;
  uStack_1dc = 0;
  uStack_1cc = 0;
  apuStack_1c0[1] = (undefined4 *)0x0;
  iStack_194 = 0;
  uStack_19c = DAT_01e90d0c;
  uStack_1a8 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
  iVar17 = FUN_005553b0(pppppppuVar13,1,0x40);
  if (iVar17 == 0) {
    FUN_00554460((uint)(*(int *)((int)&iStack_1b8 + (int)appuStack_1f0[0][1]) == 0) * 4 + 2 |
                 *(uint *)((int)&uStack_1e8 + (int)(appuStack_1f0[0][1] + 4)),0);
  }
  uStack_8._0_1_ = 0x11;
  if (iStack_194 != 0) {
    uStack_50 = 0;
    uStack_4c = 0xf;
    apppppppuStack_60[0] = (undefined4 *******)((uint)apppppppuStack_60[0] & 0xffffff00);
    uVar8 = 8;
    while( true ) {
      piVar11 = *(int **)(*(int *)((int)apuStack_1c0 + (int)appuStack_1f0[0][1]) + 4);
      uStack_8._0_1_ = 0x13;
      piStack_24 = piVar11;
      (**(code **)(*piVar11 + 4))();
      uStack_1c = uVar8 | 0x20;
      uStack_8._0_1_ = 0x14;
      piVar9 = (int *)FUN_0054e7d0(&piStack_28);
      uVar3 = (**(code **)(*piVar9 + 0x20))(10);
      uStack_48._0_5_ = CONCAT14(uVar3,(undefined4)uStack_48);
      uStack_8._0_1_ = 0x15;
      if ((piVar11 != (int *)0x0) &&
         (puVar10 = (undefined4 *)(**(code **)(*piVar11 + 8))(), puVar10 != (undefined4 *)0x0)) {
        (**(code **)*puVar10)(1);
      }
      uStack_8._0_1_ = 0x12;
      piVar11 = (int *)FUN_00591ab0(appuStack_1f0,apppppppuStack_60,uStack_48._4_4_);
      uVar18 = uStack_50;
      if ((*(byte *)(*(int *)(*piVar11 + 4) + 0xc + (int)piVar11) & 6) != 0) break;
      pppppppuVar13 = apppppppuStack_60;
      if (0xf < uStack_4c) {
        pppppppuVar13 = apppppppuStack_60[0];
      }
      if ((uStack_50 == 0) || (iVar17 = FUN_0170db20(pppppppuVar13,0x3d,uStack_50), iVar17 == 0)) {
        uVar16 = 0xffffffff;
      }
      else {
        uVar16 = iVar17 - (int)pppppppuVar13;
      }
      uVar2 = uStack_1c;
      uVar8 = uStack_1c;
      if (uVar16 != 0xffffffff) {
        uStack_30 = 0;
        uStack_2c = 0xf;
        uVar8 = uVar16;
        if (uVar18 < uVar16) {
          uVar8 = uVar18;
        }
        apppppppuStack_40[0] = (undefined4 *******)((uint)apppppppuStack_40[0] & 0xffffff00);
        pppppppuVar13 = apppppppuStack_60;
        if (0xf < uStack_4c) {
          pppppppuVar13 = apppppppuStack_60[0];
        }
        FUN_005542c0(pppppppuVar13,uVar8);
        uVar16 = uVar16 + 1;
        uStack_8._0_1_ = 0x16;
        uVar3 = (undefined)uStack_8;
        uStack_8._0_1_ = 0x16;
        uStack_68 = 0;
        uStack_64 = 0xf;
        apppppppuStack_78[0] = (undefined4 *******)((uint)apppppppuStack_78[0] & 0xffffff00);
        if (uStack_50 < uVar16) {
          uStack_8._0_1_ = uVar3;
          FUN_00554050();
LAB_005956a4:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
        iVar17 = -1;
        if (uStack_50 - uVar16 != -1) {
          iVar17 = uStack_50 - uVar16;
        }
        pppppppuVar13 = apppppppuStack_60;
        if (0xf < uStack_4c) {
          pppppppuVar13 = apppppppuStack_60[0];
        }
        FUN_005542c0((int)pppppppuVar13 + uVar16,iVar17);
        uStack_8._0_1_ = 0x17;
        pppppppuVar13 = apppppppuStack_78;
        if (0xf < uStack_64) {
          pppppppuVar13 = apppppppuStack_78[0];
        }
        puVar10 = (undefined4 *)FUN_0151d700(aiStack_90,pppppppuVar13,uStack_68);
        uStack_8._0_1_ = 0x18;
        if (0xf < (uint)puVar10[5]) {
          puVar10 = (undefined4 *)*puVar10;
        }
        pppppppuVar13 = apppppppuStack_40;
        if (0xf < uStack_2c) {
          pppppppuVar13 = apppppppuStack_40[0];
        }
        puVar12 = (undefined4 *)FUN_0151d700(apppppppuStack_e4,pppppppuVar13,uStack_30);
        uStack_8._0_1_ = 0x19;
        if (0xf < (uint)puVar12[5]) {
          puVar12 = (undefined4 *)*puVar12;
        }
        puVar12 = (undefined4 *)FUN_01675640(auStack_134,"&%s=%s",puVar12,puVar10);
        puVar10 = puVar12 + 4;
        uStack_8._0_1_ = 0x1a;
        if (0xf < (uint)puVar12[5]) {
          puVar12 = (undefined4 *)*puVar12;
        }
        FUN_00554150(puVar12,*puVar10);
        uStack_8._0_1_ = 0x19;
        if (0xf < uStack_120) {
          uVar18 = uStack_120 + 1;
          uVar8 = auStack_134[0];
          if (0xfff < uVar18) {
            uVar8 = *(uint *)(auStack_134[0] - 4);
            uVar18 = uStack_120 + 0x24;
            if (0x1f < (auStack_134[0] - uVar8) - 4) goto LAB_005956a4;
          }
          FUN_01674ea0(uVar8,uVar18);
        }
        uStack_124 = 0;
        uStack_120 = 0xf;
        auStack_134[0] = auStack_134[0] & 0xffffff00;
        uStack_8._0_1_ = 0x18;
        uVar3 = (undefined)uStack_8;
        uStack_8._0_1_ = 0x18;
        if (0xf < uStack_d0) {
          uVar8 = uStack_d0 + 1;
          pppppppuVar13 = apppppppuStack_e4[0];
          if (0xfff < uVar8) {
            pppppppuVar13 = (undefined4 *******)apppppppuStack_e4[0][-1];
            uVar8 = uStack_d0 + 0x24;
            if (0x1f < (uint)((int)apppppppuStack_e4[0] + (-4 - (int)pppppppuVar13))) {
              uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(pppppppuVar13,uVar8);
        }
        uStack_d4 = 0;
        uStack_d0 = 0xf;
        apppppppuStack_e4[0] = (undefined4 *******)((uint)apppppppuStack_e4[0] & 0xffffff00);
        uStack_8._0_1_ = 0x17;
        uVar3 = (undefined)uStack_8;
        uStack_8._0_1_ = 0x17;
        if (0xf < uStack_7c) {
          uVar8 = uStack_7c + 1;
          iVar17 = aiStack_90[0];
          if (0xfff < uVar8) {
            iVar17 = *(int *)(aiStack_90[0] + -4);
            uVar8 = uStack_7c + 0x24;
            if (0x1f < (aiStack_90[0] - iVar17) - 4U) {
              uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar17,uVar8);
        }
        if (DAT_01d7a648 != '\0') {
          pppppppuVar13 = apppppppuStack_40;
          if (0xf < uStack_2c) {
            pppppppuVar13 = apppppppuStack_40[0];
          }
          cVar4 = FUN_0055c360(pppppppuVar13,uStack_30,"isNotResponding",0xf);
          if (cVar4 != '\0') {
            pppppppuVar13 = apppppppuStack_78;
            if (0xf < uStack_64) {
              pppppppuVar13 = apppppppuStack_78[0];
            }
            cVar4 = FUN_0055c360(pppppppuVar13,uStack_68,&DAT_018bdf50,4);
            if (cVar4 != '\0') {
              cStack_1d = '\x01';
              uStack_d4 = 0;
              uStack_d0 = 0xf;
              apppppppuStack_e4[0] = (undefined4 *******)((uint)apppppppuStack_e4[0] & 0xffffff00);
              FUN_005542c0("StudioProfiler_True_Hang",0x18);
              uStack_8._0_1_ = 0x1b;
              FUN_008783f0(apppppppuStack_e4,1,0);
              FUN_005507b0();
            }
          }
        }
        uStack_8._0_1_ = 0x16;
        uVar3 = (undefined)uStack_8;
        uStack_8._0_1_ = 0x16;
        if (0xf < uStack_64) {
          uVar8 = uStack_64 + 1;
          pppppppuVar13 = apppppppuStack_78[0];
          if (0xfff < uVar8) {
            pppppppuVar13 = (undefined4 *******)apppppppuStack_78[0][-1];
            uVar8 = uStack_64 + 0x24;
            if (0x1f < (uint)((int)apppppppuStack_78[0] + (-4 - (int)pppppppuVar13))) {
              uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(pppppppuVar13,uVar8);
        }
        uStack_68 = 0;
        uStack_64 = 0xf;
        apppppppuStack_78[0] = (undefined4 *******)((uint)apppppppuStack_78[0] & 0xffffff00);
        uStack_8._0_1_ = 0x12;
        uVar8 = uVar2 | 0xc0;
        if (0xf < uStack_2c) {
          uVar18 = uStack_2c + 1;
          pppppppuVar13 = apppppppuStack_40[0];
          if (0xfff < uVar18) {
            pppppppuVar13 = (undefined4 *******)apppppppuStack_40[0][-1];
            uVar18 = uStack_2c + 0x24;
            if (0x1f < (uint)((int)apppppppuStack_40[0] + (-4 - (int)pppppppuVar13))) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(pppppppuVar13,uVar18);
        }
      }
    }
    uStack_8._0_1_ = 0x11;
    FUN_005507b0();
  }
  if (DAT_01d7a648 == '\0') {
LAB_00594f8a:
    FUN_00595900(aiStack_90,auStack_208,apppppppuStack_cc,1,*(undefined4 *)(param_1 + 0x38));
    uStack_8._0_1_ = 0x1c;
    FUN_016819e0(auStack_6c,aiStack_90);
    uStack_8._0_1_ = 0x1d;
    FUN_0167eea0(&piStack_28,"_rxid");
    cVar4 = FUN_0167e580();
    if (cVar4 != '\0') {
      FUN_0167eea0(auStack_228,"_rxid");
      uStack_30 = 0;
      uStack_2c = 0xf;
      apppppppuStack_40[0] = (undefined4 *******)((uint)apppppppuStack_40[0] & 0xffffff00);
      uStack_8._0_1_ = 0x1e;
      FUN_01681330(apppppppuStack_60,apppppppuStack_40);
      uStack_8._0_1_ = 0x1d;
      uVar3 = (undefined)uStack_8;
      uStack_8._0_1_ = 0x1d;
      if (0xf < uStack_2c) {
        uVar8 = uStack_2c + 1;
        pppppppuVar13 = apppppppuStack_40[0];
        if (0xfff < uVar8) {
          pppppppuVar13 = (undefined4 *******)apppppppuStack_40[0][-1];
          uVar8 = uStack_2c + 0x24;
          if (0x1f < (uint)((int)apppppppuStack_40[0] + (-4 - (int)pppppppuVar13))) {
            uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(pppppppuVar13,uVar8);
      }
      uStack_30 = 0;
      uStack_2c = 0xf;
      apppppppuStack_40[0] = (undefined4 *******)((uint)apppppppuStack_40[0] & 0xffffff00);
      uStack_8._0_1_ = 0x1f;
      if (DAT_01d84e8d != '\0') {
        pppppppuVar13 = apppppppuStack_60;
        if (0xf < uStack_4c) {
          pppppppuVar13 = apppppppuStack_60[0];
        }
        FUN_01677520(DAT_01d84e8d,"Crash id: %s",pppppppuVar13);
      }
      uVar8 = uStack_9c;
      uStack_48 = (double)CONCAT44(uStack_98,(undefined4)uStack_48);
      uStack_1c = uStack_9c;
      if (uStack_9c != uStack_98) {
        FUN_0054ef60(auStack_fc);
        uStack_8._0_1_ = 0x20;
        FUN_01686c70(auStack_240);
        uStack_8._0_1_ = 0x21;
        FUN_005569d0(apppppppuStack_e4);
        uStack_8._0_1_ = 0x23;
        FUN_00550800();
        pppppppuVar13 = apppppppuStack_60;
        if (0xf < uStack_4c) {
          pppppppuVar13 = apppppppuStack_60[0];
        }
        puVar10 = (undefined4 *)FUN_0151d700(auStack_114,pppppppuVar13,uStack_50);
        uStack_8._0_1_ = 0x24;
        if (0xf < (uint)puVar10[5]) {
          puVar10 = (undefined4 *)*puVar10;
        }
        puVar12 = (undefined4 *)FUN_01675640(auStack_220,"&object=%s",puVar10);
        puVar10 = puVar12 + 4;
        uStack_8._0_1_ = 0x25;
        if (0xf < (uint)puVar12[5]) {
          puVar12 = (undefined4 *)*puVar12;
        }
        FUN_00554150(puVar12,*puVar10);
        FUN_005507b0();
        uStack_8._0_1_ = 0x23;
        FUN_005507b0();
        pppppppuVar13 = apppppppuStack_e4;
        if (0xf < uStack_d0) {
          pppppppuVar13 = apppppppuStack_e4[0];
        }
        puVar10 = (undefined4 *)FUN_0151d700(auStack_220,pppppppuVar13,uStack_d4);
        uStack_8._0_1_ = 0x26;
        if (0xf < (uint)puVar10[5]) {
          puVar10 = (undefined4 *)*puVar10;
        }
        puVar12 = (undefined4 *)FUN_01675640(auStack_114,"&attachment_name=%s",puVar10);
        puVar10 = puVar12 + 4;
        uStack_8._0_1_ = 0x27;
        if (0xf < (uint)puVar12[5]) {
          puVar12 = (undefined4 *)*puVar12;
        }
        FUN_00554150(puVar12,*puVar10);
        FUN_005507b0();
        FUN_005507b0();
        uStack_8 = CONCAT31(uStack_8._1_3_,0x28);
        FUN_00595900(auStack_114,auStack_134,uVar8,0,*(undefined4 *)(param_1 + 0x38));
        FUN_005507b0();
        uVar5 = FUN_00595270();
        return uVar5;
      }
      FUN_005507b0();
    }
    FUN_0167ec40();
    FUN_005507b0();
  }
  else {
    if (cStack_1d != '\0') {
      pppppppuVar13 = apppppppuStack_cc;
      if (7 < uStack_b8) {
        pppppppuVar13 = apppppppuStack_cc[0];
      }
      iVar17 = CreateFileW(pppppppuVar13,0x80000000,0,0,3,0x80,0);
      if (iVar17 == -1) {
        cStack_15 = '\x01';
      }
      else {
        CloseHandle(iVar17);
      }
    }
    if ((DAT_01d7a648 == '\0') || (cStack_15 == '\0')) goto LAB_00594f8a;
  }
  FUN_00551650();
  FUN_005507b0();
  FUN_005507b0();
LAB_005952d5:
  if ((DAT_01d7a648 == '\0') || (cStack_15 == '\0')) {
    cStack_1e = 1;
    uVar5 = FUN_0059549f();
    return uVar5;
  }
  iVar17 = 0;
  uStack_8 = 0x34;
  piStack_28 = (int *)0x0;
  piStack_24 = (int *)FUN_01685730();
  uVar22 = FUN_0168cf30(apppppppuStack_cc,&piStack_28);
  uStack_48 = (double)CONCAT44((int)uVar22,(undefined4)uStack_48);
  if (piStack_28 == (int *)0x0) {
    uVar23 = FUN_0171e1b0(0);
    fVar21 = (float10)FUN_0171e0e4(uVar23,uStack_48._4_4_,(int)((ulonglong)uVar22 >> 0x20));
    uStack_48 = (double)fVar21;
    iVar17 = (int)fVar21;
  }
  if ((cStack_1e == '\0') && (iVar17 < DAT_01d59424)) {
    uStack_8 = 1;
    FUN_00591e70(param_1 + 0x28);
    FUN_0058dbf0();
    piVar11 = (int *)(param_1 + 0x24);
    *piVar11 = *piVar11 + -1;
    if (*piVar11 == 0) {
      *(undefined4 *)(param_1 + 0x20) = 0;
    }
    else {
      *(int *)(param_1 + 0x20) = *(int *)(param_1 + 0x20) + 1;
    }
    FUN_005923a0();
    FUN_0058dbf0();
    if (param_2 != (int *)0x0) {
      LOCK();
      iVar17 = param_2[1] + -1;
      param_2[1] = iVar17;
      UNLOCK();
      if (iVar17 == 0) {
        (**(code **)*param_2)();
        LOCK();
        piVar11 = param_2 + 2;
        iVar17 = *piVar11;
        *piVar11 = *piVar11 + -1;
        UNLOCK();
        if (iVar17 == 1) {
          (**(code **)(*param_2 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_00593cf0(apppppppuStack_cc,1,*(undefined4 *)(param_1 + 0x38));
  uVar8 = uStack_98;
  for (uVar18 = uStack_9c; uVar18 != uVar8; uVar18 = uVar18 + 0x18) {
    FUN_00593cf0(uVar18,0,*(undefined4 *)(param_1 + 0x38));
  }
  FUN_00593cf0(apppppppuStack_b4,0,*(undefined4 *)(param_1 + 0x38));
  uVar5 = FUN_0059560a();
  return uVar5;
}



/* FUNCTION 4261 ; VA 0x00595237 ; Catch@00595237 */

undefined * Catch_00595237(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  if (DAT_01d84e8e != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x134) + 4))();
    FUN_01677520(DAT_01d84e8e,"Exception when uploading log files(s): %s",uVar1);
  }
  return &DAT_00595267;
}



/* FUNCTION 4262 ; VA 0x00595270 ; FUN_00595270 */

undefined4 FUN_00595270(void)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 uVar6;
  int unaff_EBX;
  int unaff_EBP;
  int unaff_ESI;
  int iVar7;
  int unaff_EDI;
  float10 fVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  
  *(undefined4 *)(unaff_EBP + -4) = 0x23;
  FUN_005507b0();
  *(undefined *)(unaff_EBP + -4) = 0x1f;
  FUN_005507b0();
  iVar7 = unaff_ESI + 0x18;
  *(int *)(unaff_EBP + -0x18) = iVar7;
  if (iVar7 != unaff_EDI) {
    FUN_0054ef60(unaff_EBP + -0xf8);
    *(undefined *)(unaff_EBP + -4) = 0x20;
    FUN_01686c70(unaff_EBP + -0x23c);
    *(undefined *)(unaff_EBP + -4) = 0x21;
    FUN_005569d0(unaff_EBP + -0xe0);
    *(undefined *)(unaff_EBP + -4) = 0x23;
    FUN_00550800();
    iVar5 = unaff_EBP + -0x5c;
    if (0xf < *(uint *)(unaff_EBP + -0x48)) {
      iVar5 = *(int *)(unaff_EBP + -0x5c);
    }
    puVar4 = (undefined4 *)FUN_0151d700(unaff_EBP + -0x110,iVar5,*(undefined4 *)(unaff_EBP + -0x4c))
    ;
    uVar3 = puVar4[5];
    *(undefined *)(unaff_EBP + -4) = 0x24;
    if (0xf < uVar3) {
      puVar4 = (undefined4 *)*puVar4;
    }
    puVar4 = (undefined4 *)FUN_01675640(unaff_EBP + -0x21c,"&object=%s",puVar4);
    uVar3 = puVar4[5];
    uVar6 = puVar4[4];
    *(undefined *)(unaff_EBP + -4) = 0x25;
    if (0xf < uVar3) {
      puVar4 = (undefined4 *)*puVar4;
    }
    FUN_00554150(puVar4,uVar6);
    FUN_005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x23;
    FUN_005507b0();
    iVar5 = unaff_EBP + -0xe0;
    if (0xf < *(uint *)(unaff_EBP + -0xcc)) {
      iVar5 = *(int *)(unaff_EBP + -0xe0);
    }
    puVar4 = (undefined4 *)FUN_0151d700(unaff_EBP + -0x21c,iVar5,*(undefined4 *)(unaff_EBP + -0xd0))
    ;
    uVar3 = puVar4[5];
    *(undefined *)(unaff_EBP + -4) = 0x26;
    if (0xf < uVar3) {
      puVar4 = (undefined4 *)*puVar4;
    }
    puVar4 = (undefined4 *)FUN_01675640(unaff_EBP + -0x110,"&attachment_name=%s",puVar4);
    uVar3 = puVar4[5];
    uVar6 = puVar4[4];
    *(undefined *)(unaff_EBP + -4) = 0x27;
    if (0xf < uVar3) {
      puVar4 = (undefined4 *)*puVar4;
    }
    FUN_00554150(puVar4,uVar6);
    FUN_005507b0();
    FUN_005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x28;
    FUN_00595900(unaff_EBP + -0x110,unaff_EBP + -0x130,iVar7,0,
                 *(undefined4 *)(*(int *)(unaff_EBP + 8) + 0x38));
    FUN_005507b0();
    uVar6 = FUN_00595270();
    return uVar6;
  }
  FUN_005507b0();
  FUN_0167ec40();
  FUN_005507b0();
  FUN_00551650();
  FUN_005507b0();
  FUN_005507b0();
  if ((DAT_01d7a648 != '\0') && (*(char *)(unaff_EBP + -0x11) != '\0')) {
    *(undefined4 *)(unaff_EBP + -4) = 1;
    iVar7 = 0;
    *(undefined *)(unaff_EBP + -4) = 0x34;
    *(undefined4 *)(unaff_EBP + -0x24) = 0;
    uVar6 = FUN_01685730();
    *(undefined4 *)(unaff_EBP + -0x20) = uVar6;
    uVar9 = FUN_0168cf30(unaff_EBP + -200,unaff_EBP + -0x24);
    *(int *)(unaff_EBP + -0x40) = (int)uVar9;
    if (*(int *)(unaff_EBP + -0x24) == 0) {
      uVar10 = FUN_0171e1b0(0);
      fVar8 = (float10)FUN_0171e0e4(uVar10,*(undefined4 *)(unaff_EBP + -0x40),
                                    (int)((ulonglong)uVar9 >> 0x20));
      *(double *)(unaff_EBP + -0x44) = (double)fVar8;
      iVar7 = (int)*(double *)(unaff_EBP + -0x44);
    }
    if ((*(char *)(unaff_EBP + -0x1a) == '\0') && (iVar7 < DAT_01d59424)) {
      *(undefined4 *)(unaff_EBP + -4) = 1;
      FUN_00591e70(*(int *)(unaff_EBP + 8) + 0x28);
      iVar7 = *(int *)(unaff_EBP + 8);
      FUN_0058dbf0();
      piVar1 = (int *)(iVar7 + 0x24);
      *piVar1 = *piVar1 + -1;
      if (*piVar1 == 0) {
        *(undefined4 *)(iVar7 + 0x20) = 0;
      }
      else {
        *(int *)(iVar7 + 0x20) = *(int *)(iVar7 + 0x20) + 1;
      }
      FUN_005923a0();
      FUN_0058dbf0();
      piVar1 = *(int **)(unaff_EBP + 0xc);
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar7 = piVar1[1] + unaff_EBX;
        piVar1[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          piVar2 = piVar1 + 2;
          iVar7 = *piVar2;
          *piVar2 = *piVar2 + unaff_EBX;
          UNLOCK();
          if (iVar7 == 1) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      ExceptionList = *(void **)(unaff_EBP + -0xc);
      return 1;
    }
    FUN_00593cf0(unaff_EBP + -200,1,*(undefined4 *)(*(int *)(unaff_EBP + 8) + 0x38));
    iVar7 = *(int *)(unaff_EBP + -0x98);
    iVar5 = *(int *)(unaff_EBP + -0x94);
    while( true ) {
      uVar6 = *(undefined4 *)(*(int *)(unaff_EBP + 8) + 0x38);
      if (iVar7 == iVar5) break;
      FUN_00593cf0(iVar7,0,uVar6);
      iVar7 = iVar7 + 0x18;
    }
    FUN_00593cf0(unaff_EBP + -0xb0,0,uVar6);
    uVar6 = FUN_0059560a();
    return uVar6;
  }
  *(undefined *)(unaff_EBP + -0x1a) = 1;
  uVar6 = FUN_0059549f();
  return uVar6;
}



/* FUNCTION 4263 ; VA 0x005952f1 ; Catch@005952f1 */

undefined * Catch_005952f1(void)

{
  byte bVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  byte *pbVar5;
  uint uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int unaff_EBP;
  byte *pbVar9;
  bool bVar10;
  
  piVar2 = *(int **)(unaff_EBP + -0x114);
  if (DAT_01d84e8e != '\0') {
    uVar4 = (**(code **)(*piVar2 + 4))();
    FUN_01677520(DAT_01d84e8e,"Exception when uploading dump(s): %s",uVar4);
  }
  pbVar9 = &DAT_018c146c;
  pbVar5 = (byte *)(**(code **)(*piVar2 + 4))();
  do {
    bVar1 = *pbVar5;
    bVar10 = bVar1 < *pbVar9;
    if (bVar1 != *pbVar9) {
LAB_00595350:
      uVar6 = -(uint)bVar10 | 1;
      goto LAB_00595355;
    }
    if (bVar1 == 0) break;
    bVar1 = pbVar5[1];
    bVar10 = bVar1 < pbVar9[1];
    if (bVar1 != pbVar9[1]) goto LAB_00595350;
    pbVar5 = pbVar5 + 2;
    pbVar9 = pbVar9 + 2;
  } while (bVar1 != 0);
  uVar6 = 0;
LAB_00595355:
  if (uVar6 == 0) {
    uVar4 = *(undefined4 *)(*(int *)(unaff_EBP + 8) + 0x38);
    uVar7 = FUN_005569d0(unaff_EBP + -0x110);
    iVar3 = *piVar2;
    *(undefined *)(unaff_EBP + -4) = 0x2b;
    uVar8 = (**(code **)(iVar3 + 4))();
    FUN_0054eff0(uVar8);
    *(undefined *)(unaff_EBP + -4) = 0x2c;
    FUN_0054eff0("Timeout");
    *(undefined *)(unaff_EBP + -4) = 0x2d;
  }
  else {
    pbVar9 = &DAT_018c14b0;
    pbVar5 = (byte *)(**(code **)(*piVar2 + 4))();
    do {
      bVar1 = *pbVar5;
      bVar10 = bVar1 < *pbVar9;
      if (bVar1 != *pbVar9) {
LAB_005953d3:
        uVar6 = -(uint)bVar10 | 1;
        goto LAB_005953d8;
      }
      if (bVar1 == 0) break;
      bVar1 = pbVar5[1];
      bVar10 = bVar1 < pbVar9[1];
      if (bVar1 != pbVar9[1]) goto LAB_005953d3;
      pbVar5 = pbVar5 + 2;
      pbVar9 = pbVar9 + 2;
    } while (bVar1 != 0);
    uVar6 = 0;
LAB_005953d8:
    uVar4 = *(undefined4 *)(*(int *)(unaff_EBP + 8) + 0x38);
    if (uVar6 == 0) {
      uVar7 = FUN_005569d0(unaff_EBP + -0x110);
      iVar3 = *piVar2;
      *(undefined *)(unaff_EBP + -4) = 0x2e;
      uVar8 = (**(code **)(iVar3 + 4))();
      FUN_0054eff0(uVar8);
      *(undefined *)(unaff_EBP + -4) = 0x2f;
      FUN_0054eff0("SSLFailure");
      *(undefined *)(unaff_EBP + -4) = 0x30;
    }
    else {
      uVar7 = FUN_005569d0(unaff_EBP + -0x110);
      iVar3 = *piVar2;
      *(undefined *)(unaff_EBP + -4) = 0x31;
      uVar8 = (**(code **)(iVar3 + 4))();
      FUN_0054eff0(uVar8);
      *(undefined *)(unaff_EBP + -4) = 0x32;
      FUN_0054eff0("Exception");
      *(undefined *)(unaff_EBP + -4) = 0x33;
    }
  }
  FUN_00594330(unaff_EBP + -0x8c,unaff_EBP + -0xf8,uVar7,uVar4);
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  return &DAT_0059549c;
}



/* FUNCTION 4264 ; VA 0x0059549f ; FUN_0059549f */

undefined4 FUN_0059549f(void)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int unaff_EBX;
  int unaff_EBP;
  int iVar5;
  float10 fVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  iVar5 = 0;
  *(undefined *)(unaff_EBP + -4) = 0x34;
  *(undefined4 *)(unaff_EBP + -0x24) = 0;
  uVar4 = FUN_01685730();
  *(undefined4 *)(unaff_EBP + -0x20) = uVar4;
  uVar7 = FUN_0168cf30(unaff_EBP + -200,unaff_EBP + -0x24);
  *(int *)(unaff_EBP + -0x40) = (int)uVar7;
  if (*(int *)(unaff_EBP + -0x24) == 0) {
    uVar8 = FUN_0171e1b0(0);
    fVar6 = (float10)FUN_0171e0e4(uVar8,*(undefined4 *)(unaff_EBP + -0x40),
                                  (int)((ulonglong)uVar7 >> 0x20));
    *(double *)(unaff_EBP + -0x44) = (double)fVar6;
    iVar5 = (int)*(double *)(unaff_EBP + -0x44);
  }
  if ((*(char *)(unaff_EBP + -0x1a) == '\0') && (iVar5 < DAT_01d59424)) {
    *(undefined4 *)(unaff_EBP + -4) = 1;
    FUN_00591e70(*(int *)(unaff_EBP + 8) + 0x28);
    iVar5 = *(int *)(unaff_EBP + 8);
    FUN_0058dbf0();
    piVar1 = (int *)(iVar5 + 0x24);
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      *(undefined4 *)(iVar5 + 0x20) = 0;
    }
    else {
      *(int *)(iVar5 + 0x20) = *(int *)(iVar5 + 0x20) + 1;
    }
    FUN_005923a0();
    FUN_0058dbf0();
    piVar1 = *(int **)(unaff_EBP + 0xc);
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar5 = piVar1[1] + unaff_EBX;
      piVar1[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        piVar2 = piVar1 + 2;
        iVar5 = *piVar2;
        *piVar2 = *piVar2 + unaff_EBX;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    ExceptionList = *(void **)(unaff_EBP + -0xc);
    return 1;
  }
  FUN_00593cf0(unaff_EBP + -200,1,*(undefined4 *)(*(int *)(unaff_EBP + 8) + 0x38));
  iVar5 = *(int *)(unaff_EBP + -0x98);
  iVar3 = *(int *)(unaff_EBP + -0x94);
  while( true ) {
    uVar4 = *(undefined4 *)(*(int *)(unaff_EBP + 8) + 0x38);
    if (iVar5 == iVar3) break;
    FUN_00593cf0(iVar5,0,uVar4);
    iVar5 = iVar5 + 0x18;
  }
  FUN_00593cf0(unaff_EBP + -0xb0,0,uVar4);
  uVar4 = FUN_0059560a();
  return uVar4;
}



/* FUNCTION 4265 ; VA 0x00595553 ; Catch@00595553 */

undefined * Catch_00595553(void)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int unaff_EBP;
  
  piVar1 = *(int **)(unaff_EBP + -0x118);
  if (DAT_01d84e8e != '\0') {
    uVar3 = (**(code **)(*piVar1 + 4))();
    FUN_01677520(DAT_01d84e8e,"Exception when archiving dump(s): %s",uVar3);
  }
  uVar3 = *(undefined4 *)(*(int *)(unaff_EBP + 8) + 0x38);
  uVar4 = FUN_005569d0(unaff_EBP + -0x110);
  iVar2 = *piVar1;
  *(undefined *)(unaff_EBP + -4) = 0x36;
  uVar5 = (**(code **)(iVar2 + 4))();
  FUN_0054eff0(uVar5);
  *(undefined *)(unaff_EBP + -4) = 0x37;
  FUN_0054eff0("Exception");
  *(undefined *)(unaff_EBP + -4) = 0x38;
  FUN_00594330(unaff_EBP + -0x8c,unaff_EBP + -0xf8,uVar4,uVar3);
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  return &DAT_00595607;
}



/* FUNCTION 4266 ; VA 0x0059560a ; FUN_0059560a */

undefined4 FUN_0059560a(void)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int unaff_EBX;
  int unaff_EBP;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  FUN_00591e70(*(int *)(unaff_EBP + 8) + 0x28);
  iVar3 = *(int *)(unaff_EBP + 8);
  FUN_0058dbf0();
  piVar1 = (int *)(iVar3 + 0x24);
  *piVar1 = *piVar1 + -1;
  if (*piVar1 == 0) {
    *(undefined4 *)(iVar3 + 0x20) = 0;
  }
  else {
    *(int *)(iVar3 + 0x20) = *(int *)(iVar3 + 0x20) + 1;
  }
  FUN_005923a0();
  FUN_0058dbf0();
  piVar1 = *(int **)(unaff_EBP + 0xc);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + unaff_EBX;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + unaff_EBX;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return 1;
}



/* FUNCTION 4267 ; VA 0x005956d0 ; FUN_005956d0 */

int * __thiscall FUN_005956d0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  uint uStack_30;
  int iStack_2c;
  uint uStack_28;
  int iStack_24;
  int *piStack_18;
  undefined uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797b80;
  pvStack_10 = ExceptionList;
  uVar3 = *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc) & 0xfffffffe;
  uVar2 = uVar3 | 4;
  if (*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) != 0) {
    uVar2 = uVar3;
  }
  ExceptionList = &pvStack_10;
  FUN_00554460(uVar2,0);
  piVar1 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  piStack_18 = param_1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 4))();
  }
  uStack_8 = 0;
  uStack_14 = FUN_00593b40(1);
  uStack_8 = 1;
  if ((*(byte *)(*(int *)(*param_1 + 4) + 0xc + (int)param_1) & 6) == 0) {
    (**(code **)(**(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1) + 0x28))
              (&uStack_30,param_2,param_3,param_4,1);
    if ((uStack_30 + uStack_28 & iStack_2c + iStack_24 + (uint)CARRY4(uStack_30,uStack_28)) ==
        0xffffffff) {
      FUN_00554460((uint)(*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) == 0) * 4 + 2 |
                   *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc),0);
    }
  }
  uStack_8 = 2;
  piVar1 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 8))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4268 ; VA 0x005957d0 ; FUN_005957d0 */

undefined4 * __thiscall FUN_005957d0(int *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797ba0;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  ExceptionList = &pvStack_10;
  if (piVar1 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*piVar1 + 4))();
  }
  uStack_8 = 0;
  FUN_00593b40(1);
  uStack_8 = 1;
  if ((*(byte *)(*(int *)(*param_1 + 4) + 0xc + (int)param_1) & 6) == 0) {
    (**(code **)(**(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1) + 0x28))(param_2,0,0,1,1);
    uStack_8 = 2;
  }
  else {
    *param_2 = 0xffffffff;
    param_2[1] = 0xffffffff;
    param_2[2] = 0;
    param_2[3] = 0;
    *(undefined8 *)(param_2 + 4) = 0;
    uStack_8 = 3;
  }
  piVar1 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 8))();
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 4269 ; VA 0x005958a0 ; FUN_005958a0 */

undefined * FUN_005958a0(undefined *param_1,int param_2)

{
  int iVar1;
  undefined *puVar2;
  undefined auStack_7 [3];
  
  if (param_2 < 0) {
    iVar1 = FUN_00591870(auStack_7,-param_2);
    *(undefined *)(iVar1 + -1) = 0x2d;
    puVar2 = (undefined *)(iVar1 + -1);
  }
  else {
    puVar2 = (undefined *)FUN_00591870(auStack_7,param_2);
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  if (puVar2 != auStack_7) {
    FUN_005542c0(puVar2,(int)auStack_7 - (int)puVar2);
  }
  return param_1;
}



/* FUNCTION 4270 ; VA 0x00595900 ; FUN_00595900 */

undefined *
FUN_00595900(undefined *param_1,undefined4 *param_2,undefined4 *param_3,char param_4,
            undefined4 param_5)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 ****ppppuVar3;
  uint *puVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  int aiStack_134 [3];
  byte abStack_128 [180];
  undefined auStack_74 [24];
  int iStack_5c;
  undefined4 uStack_58;
  undefined auStack_54 [4];
  uint uStack_50;
  undefined4 *puStack_4c;
  undefined auStack_48 [16];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 ***apppuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_01797c59;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_8 = 0;
  iStack_5c = 0;
  ExceptionList = &pvStack_10;
  uStack_58 = FUN_01685730();
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  uStack_8 = 0;
  if (DAT_01d84e8d != '\0') {
    puStack_4c = param_2;
    if (0xf < (uint)param_2[5]) {
      puStack_4c = (undefined4 *)*param_2;
    }
    uStack_8 = 1;
    uStack_20 = 0;
    uStack_1c = 0xf;
    apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
    uStack_18 = 5;
    if (param_3[4] != 0) {
      puVar1 = param_3;
      if (7 < (uint)param_3[5]) {
        puVar1 = (undefined4 *)*param_3;
      }
      uStack_50 = (int)puVar1 + param_3[4] * 2;
      puVar1 = param_3;
      if (7 < (uint)param_3[5]) {
        puVar1 = (undefined4 *)*param_3;
      }
      uVar2 = FUN_01686580();
      FUN_01685a20(puVar1,uStack_50,apppuStack_30,uVar2);
    }
    ppppuVar3 = apppuStack_30;
    if (0xf < uStack_1c) {
      ppppuVar3 = (undefined4 ****)apppuStack_30[0];
    }
    FUN_01677520(DAT_01d84e8d,"Uploading %s to %s",ppppuVar3,puStack_4c);
    uStack_8 = uStack_8 & 0xffffff00;
    if (0xf < uStack_1c) {
      uVar7 = uStack_1c + 1;
      ppppuVar3 = (undefined4 ****)apppuStack_30[0];
      if (0xfff < uVar7) {
        ppppuVar3 = (undefined4 ****)apppuStack_30[0][-1];
        uVar7 = uStack_1c + 0x24;
        if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar3,uVar7);
    }
  }
  uStack_18 = 1;
  puVar1 = param_3;
  if (7 < (uint)param_3[5]) {
    puVar1 = (undefined4 *)*param_3;
  }
  FUN_00591c60(puVar1,0x21,0x40,1);
  uStack_8 = 3;
  puVar4 = (uint *)FUN_005957d0(auStack_74);
  uStack_50 = puVar4[2] + *puVar4;
  iVar8 = puVar4[3] + puVar4[1] + (uint)CARRY4(puVar4[2],*puVar4);
  FUN_005956d0(0,0,2);
  puVar4 = (uint *)FUN_005957d0(auStack_74);
  iVar6 = puVar4[3] + puVar4[1] + (uint)CARRY4(puVar4[2],*puVar4);
  if ((iVar6 < iVar8) || ((iVar6 <= iVar8 && (puVar4[2] + *puVar4 <= uStack_50)))) {
    if ((abStack_128[*(int *)(aiStack_134[0] + 4)] & 6) == 0) {
      if (param_4 == '\0') goto LAB_00595cfd;
      uVar2 = FUN_005569d0(auStack_74);
      uStack_8._0_1_ = 5;
      uStack_38 = 0;
      uStack_34 = 0xf;
      auStack_48[0] = 0;
      FUN_005542c0("Empty dump file",0xf);
      uStack_8._0_1_ = 6;
      uStack_20 = 0;
      uStack_1c = 0xf;
      apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
      FUN_005542c0("EmptyDumpFile",0xd);
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      FUN_00594330(apppuStack_30,auStack_48,uVar2,param_5);
      FUN_005507b0();
    }
    else {
      if (param_4 == '\0') goto LAB_00595cfd;
      if (7 < (uint)param_3[5]) {
        param_3 = (undefined4 *)*param_3;
      }
      FUN_00592180(param_3);
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      uStack_18 = 3;
      piVar5 = (int *)FUN_0168e1c0(auStack_54,auStack_48,&iStack_5c);
      if (((*piVar5 == 0) || (*piVar5 == 1)) || (cStack_11 = '\x01', iStack_5c != 0)) {
        cStack_11 = '\0';
      }
      uStack_8 = 3;
      uStack_18 = 1;
      FUN_00550800();
      uVar2 = FUN_005569d0(auStack_74);
      if (cStack_11 == '\0') {
        uStack_8._0_1_ = 0xc;
        uStack_20 = 0;
        uStack_1c = 0xf;
        apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0]._1_3_ << 8);
        FUN_005542c0("Missing dump file",0x11);
        uStack_8._0_1_ = 0xd;
        uStack_38 = 0;
        uStack_34 = 0xf;
        auStack_48[0] = 0;
        FUN_005542c0("MissingDumpFile",0xf);
        uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
      }
      else {
        uStack_8._0_1_ = 9;
        uStack_20 = 0;
        uStack_1c = 0xf;
        apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0]._1_3_ << 8);
        FUN_005542c0("Unreadable dump file",0x14);
        uStack_8._0_1_ = 10;
        uStack_38 = 0;
        uStack_34 = 0xf;
        auStack_48[0] = 0;
        FUN_005542c0("UnreadableDumpFile",0x12);
        uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
      }
      FUN_00594330(auStack_48,apppuStack_30,uVar2,param_5);
      FUN_005507b0();
    }
    FUN_005507b0();
    FUN_005507b0();
  }
  else {
    FUN_005956d0(0,0,0);
    FUN_014cc090(param_2,0,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_014cdc70(aiStack_134,&DAT_01d79f68,1,param_1,1,1);
    FUN_0056db40();
  }
LAB_00595cfd:
  FUN_00592780();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4271 ; VA 0x00595d30 ; FUN_00595d30 */

int __thiscall FUN_00595d30(int *param_1,int param_2,undefined4 *param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  
  iVar2 = *param_1;
  iVar7 = param_2 - iVar2;
  iVar3 = param_1[1] - iVar2 >> 2;
  if (iVar3 == 0x3fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar3 + 1;
  uVar5 = param_1[2] - iVar2 >> 2;
  uVar6 = uVar1;
  if ((uVar5 <= 0x3fffffff - (uVar5 >> 1)) && (uVar6 = (uVar5 >> 1) + uVar5, uVar6 < uVar1)) {
    uVar6 = uVar1;
  }
  iVar3 = FUN_00577ed0(uVar6);
  iVar2 = (iVar7 >> 2) * 4;
  *(undefined4 *)(iVar2 + iVar3) = *param_3;
  if (param_2 == param_1[1]) {
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    FUN_0170cc70(iVar3,*param_1,param_1[1] - *param_1);
  }
  else {
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(iVar3,*param_1,param_2 - *param_1);
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(iVar3 + iVar2 + 4,param_2,param_1[1] - param_2);
  }
  iVar7 = *param_1;
  if (iVar7 != 0) {
    uVar5 = param_1[2] - iVar7 & 0xfffffffc;
    iVar4 = iVar7;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar7 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar7 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *param_1 = iVar3;
  param_1[1] = iVar3 + uVar1 * 4;
  param_1[2] = iVar3 + uVar6 * 4;
  return *param_1 + iVar2;
}



/* FUNCTION 4272 ; VA 0x00595f20 ; FUN_00595f20 */

undefined4 * __fastcall FUN_00595f20(undefined4 *param_1)

{
  *param_1 = _ns1__CloseJob::vftable;
  param_1[5] = 0;
  param_1[6] = 0xf;
  *(undefined *)(param_1 + 1) = 0;
  param_1[7] = 0;
  return param_1;
}



/* FUNCTION 4273 ; VA 0x00595fc0 ; FUN_00595fc0 */

undefined4 * __fastcall FUN_00595fc0(undefined4 *param_1)

{
  *param_1 = _ns1__DiagResponse::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  return param_1;
}



/* FUNCTION 4274 ; VA 0x00595ff0 ; FUN_00595ff0 */

undefined4 * __fastcall FUN_00595ff0(undefined4 *param_1)

{
  *param_1 = _ns1__Execute::vftable;
  param_1[5] = 0;
  param_1[6] = 0xf;
  *(undefined *)(param_1 + 1) = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  return param_1;
}



/* FUNCTION 4275 ; VA 0x00596030 ; FUN_00596030 */

undefined4 * __fastcall FUN_00596030(undefined4 *param_1)

{
  *param_1 = _ns1__ExecuteEx::vftable;
  param_1[5] = 0;
  param_1[6] = 0xf;
  *(undefined *)(param_1 + 1) = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  return param_1;
}



/* FUNCTION 4276 ; VA 0x00596090 ; FUN_00596090 */

undefined4 * __fastcall FUN_00596090(undefined4 *param_1)

{
  *param_1 = _ns1__ExecuteResponse::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  return param_1;
}



/* FUNCTION 4277 ; VA 0x00596100 ; FUN_00596100 */

undefined4 * __fastcall FUN_00596100(undefined4 *param_1)

{
  *param_1 = _ns1__GetAllJobsResponse::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  return param_1;
}



/* FUNCTION 4278 ; VA 0x00596130 ; FUN_00596130 */

undefined4 * __fastcall FUN_00596130(undefined4 *param_1)

{
  *param_1 = _ns1__GetExpiration::vftable;
  param_1[5] = 0;
  param_1[6] = 0xf;
  *(undefined *)(param_1 + 1) = 0;
  param_1[7] = 0;
  return param_1;
}



/* FUNCTION 4279 ; VA 0x005961c0 ; FUN_005961c0 */

undefined4 * __fastcall FUN_005961c0(undefined4 *param_1)

{
  *param_1 = _ns1__GetVersionResponse::vftable;
  param_1[5] = 0;
  param_1[6] = 0xf;
  *(undefined *)(param_1 + 1) = 0;
  param_1[7] = 0;
  return param_1;
}



/* FUNCTION 4280 ; VA 0x00596260 ; FUN_00596260 */

undefined4 * __fastcall FUN_00596260(undefined4 *param_1)

{
  *param_1 = _ns1__RenewLease::vftable;
  param_1[6] = 0;
  param_1[7] = 0xf;
  *(undefined *)(param_1 + 2) = 0;
  *(undefined8 *)(param_1 + 8) = 0;
  param_1[10] = 0;
  return param_1;
}



/* FUNCTION 4281 ; VA 0x005962c0 ; FUN_005962c0 */

undefined4 * __fastcall FUN_005962c0(undefined4 *param_1)

{
  *param_1 = ns1__ArrayOfJob::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  return param_1;
}



/* FUNCTION 4282 ; VA 0x005962f0 ; FUN_005962f0 */

undefined4 * __fastcall FUN_005962f0(undefined4 *param_1)

{
  *param_1 = ns1__ArrayOfLuaValue::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  return param_1;
}



/* FUNCTION 4283 ; VA 0x00596380 ; FUN_00596380 */

void __fastcall FUN_00596380(undefined4 *param_1)

{
  *param_1 = _ns1__BatchJobExResponse::vftable;
  return;
}



/* FUNCTION 4284 ; VA 0x005963a0 ; FUN_005963a0 */

void __fastcall FUN_005963a0(undefined4 *param_1)

{
  *param_1 = _ns1__CloseAllJobsResponse::vftable;
  return;
}



/* FUNCTION 4285 ; VA 0x005963c0 ; FUN_005963c0 */

void __fastcall FUN_005963c0(undefined4 *param_1)

{
  *param_1 = _ns1__CloseExpiredJobsResponse::vftable;
  return;
}



/* FUNCTION 4286 ; VA 0x005963d0 ; FUN_005963d0 */

void __fastcall FUN_005963d0(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = _ns1__CloseJob::vftable;
  uVar1 = param_1[6];
  if (0xf < uVar1) {
    iVar2 = param_1[1];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[5] = 0;
  param_1[6] = 0xf;
  *(undefined *)(param_1 + 1) = 0;
  return;
}



/* FUNCTION 4287 ; VA 0x00596430 ; FUN_00596430 */

void __fastcall FUN_00596430(undefined4 *param_1)

{
  *param_1 = _ns1__CloseJobResponse::vftable;
  return;
}



/* FUNCTION 4288 ; VA 0x00596460 ; FUN_00596460 */

void __fastcall FUN_00596460(undefined4 *param_1)

{
  *param_1 = _ns1__DiagExResponse::vftable;
  return;
}



/* FUNCTION 4289 ; VA 0x00596470 ; FUN_00596470 */

void __fastcall FUN_00596470(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  *param_1 = _ns1__DiagResponse::vftable;
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    uVar3 = param_1[3] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
  }
  return;
}



/* FUNCTION 4290 ; VA 0x005964d0 ; FUN_005964d0 */

void __fastcall FUN_005964d0(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = _ns1__Execute::vftable;
  uVar1 = param_1[6];
  if (0xf < uVar1) {
    iVar2 = param_1[1];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[5] = 0;
  param_1[6] = 0xf;
  *(undefined *)(param_1 + 1) = 0;
  return;
}



/* FUNCTION 4291 ; VA 0x00596530 ; FUN_00596530 */

void __fastcall FUN_00596530(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = _ns1__ExecuteEx::vftable;
  uVar1 = param_1[6];
  if (0xf < uVar1) {
    iVar2 = param_1[1];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[5] = 0;
  param_1[6] = 0xf;
  *(undefined *)(param_1 + 1) = 0;
  return;
}



/* FUNCTION 4292 ; VA 0x00596590 ; FUN_00596590 */

void __fastcall FUN_00596590(undefined4 *param_1)

{
  *param_1 = _ns1__ExecuteExResponse::vftable;
  return;
}



/* FUNCTION 4293 ; VA 0x005965a0 ; FUN_005965a0 */

void __fastcall FUN_005965a0(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  *param_1 = _ns1__ExecuteResponse::vftable;
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    uVar3 = param_1[3] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
  }
  return;
}



/* FUNCTION 4294 ; VA 0x00596620 ; FUN_00596620 */

void __fastcall FUN_00596620(undefined4 *param_1)

{
  *param_1 = _ns1__GetAllJobsExResponse::vftable;
  return;
}



/* FUNCTION 4295 ; VA 0x00596630 ; FUN_00596630 */

void __fastcall FUN_00596630(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  *param_1 = _ns1__GetAllJobsResponse::vftable;
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    uVar3 = param_1[3] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
  }
  return;
}



/* FUNCTION 4296 ; VA 0x00596690 ; FUN_00596690 */

void __fastcall FUN_00596690(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = _ns1__GetExpiration::vftable;
  uVar1 = param_1[6];
  if (0xf < uVar1) {
    iVar2 = param_1[1];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[5] = 0;
  param_1[6] = 0xf;
  *(undefined *)(param_1 + 1) = 0;
  return;
}



/* FUNCTION 4297 ; VA 0x005966f0 ; FUN_005966f0 */

void __fastcall FUN_005966f0(undefined4 *param_1)

{
  *param_1 = _ns1__GetExpirationResponse::vftable;
  return;
}



/* FUNCTION 4298 ; VA 0x00596710 ; FUN_00596710 */

void __fastcall FUN_00596710(undefined4 *param_1)

{
  *param_1 = _ns1__GetStatusResponse::vftable;
  return;
}



/* FUNCTION 4299 ; VA 0x00596730 ; FUN_00596730 */

void __fastcall FUN_00596730(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = _ns1__GetVersionResponse::vftable;
  uVar1 = param_1[6];
  if (0xf < uVar1) {
    iVar2 = param_1[1];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[5] = 0;
  param_1[6] = 0xf;
  *(undefined *)(param_1 + 1) = 0;
  return;
}



/* FUNCTION 4300 ; VA 0x005967a0 ; FUN_005967a0 */

void __fastcall FUN_005967a0(undefined4 *param_1)

{
  *param_1 = _ns1__HelloWorldResponse::vftable;
  return;
}



/* FUNCTION 4301 ; VA 0x005967c0 ; FUN_005967c0 */

void __fastcall FUN_005967c0(undefined4 *param_1)

{
  *param_1 = _ns1__OpenJobExResponse::vftable;
  return;
}



/* FUNCTION 4302 ; VA 0x005967d0 ; FUN_005967d0 */

void __fastcall FUN_005967d0(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = _ns1__RenewLease::vftable;
  uVar1 = param_1[7];
  if (0xf < uVar1) {
    iVar2 = param_1[2];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[6] = 0;
  param_1[7] = 0xf;
  *(undefined *)(param_1 + 2) = 0;
  return;
}



/* FUNCTION 4303 ; VA 0x00596830 ; FUN_00596830 */

void __fastcall FUN_00596830(undefined4 *param_1)

{
  *param_1 = _ns1__RenewLeaseResponse::vftable;
  return;
}



/* FUNCTION 4304 ; VA 0x00596840 ; FUN_00596840 */

void __fastcall FUN_00596840(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  *param_1 = ns1__ArrayOfJob::vftable;
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    uVar3 = param_1[3] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
  }
  return;
}



/* FUNCTION 4305 ; VA 0x005968a0 ; FUN_005968a0 */

void __fastcall FUN_005968a0(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  *param_1 = ns1__ArrayOfLuaValue::vftable;
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    uVar3 = param_1[3] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
  }
  return;
}



/* FUNCTION 4306 ; VA 0x00596920 ; FUN_00596920 */

uint * __thiscall FUN_00596920(uint *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  
  if (param_1 != param_2) {
    uVar6 = param_2[1];
    uVar1 = *param_2;
    param_2 = (uint *)*param_1;
    iVar7 = uVar6 - uVar1;
    uVar5 = iVar7 >> 2;
    uVar4 = (int)(param_1[2] - (int)param_2) >> 2;
    uVar2 = (int)(param_1[1] - (int)param_2) >> 2;
    if (uVar4 < uVar5) {
      if (0x3fffffff < uVar5) {
LAB_00596a78:
                    /* WARNING: Subroutine does not return */
        FUN_00577c30();
      }
      uVar2 = uVar4 >> 1;
      uVar6 = uVar5;
      if ((uVar4 <= 0x3fffffff - uVar2) && (uVar6 = uVar2 + uVar4, uVar2 + uVar4 < uVar5)) {
        uVar6 = uVar5;
      }
      if (param_2 != (uint *)0x0) {
        uVar5 = (uint)param_2;
        param_2 = (uint *)uVar2;
        FUN_0057d270(uVar5,uVar4);
        uVar2 = (uint)param_2;
      }
      param_2 = (uint *)uVar2;
      *param_1 = 0;
      param_1[1] = 0;
      param_1[2] = 0;
      if (uVar6 != 0) {
        if (0x3fffffff < uVar6) goto LAB_00596a78;
        uVar2 = FUN_00577ed0(uVar6);
        *param_1 = uVar2;
        param_1[1] = uVar2;
        param_1[2] = *param_1 + uVar6 * 4;
      }
      uVar6 = *param_1;
      FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
      FUN_0170cc70(uVar6,uVar1,iVar7);
      param_1[1] = uVar6 + iVar7;
      return param_1;
    }
    if (uVar2 < uVar5) {
      iVar3 = uVar2 * 4;
      iVar7 = iVar3 + uVar1;
      FUN_0170cc70(param_2,uVar1,iVar3);
      uVar1 = param_1[1];
      FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
      iVar3 = uVar6 - iVar7;
      FUN_0170cc70(uVar1,iVar7,iVar3);
      param_1[1] = iVar3 + uVar1;
      return param_1;
    }
    FUN_0170cc70(param_2,uVar1,iVar7);
    param_1[1] = (int)param_2 + uVar5 * 4;
  }
  return param_1;
}



/* FUNCTION 4307 ; VA 0x00596a80 ; FUN_00596a80 */

int * __thiscall FUN_00596a80(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x10,param_1[-1],FUN_0056e630);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x10 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__BatchJob::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4308 ; VA 0x00596b10 ; FUN_00596b10 */

int * __thiscall FUN_00596b10(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x10,param_1[-1],&LAB_00596370);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x10 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__BatchJobEx::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4309 ; VA 0x00596ba0 ; FUN_00596ba0 */

int * __thiscall FUN_00596ba0(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0xc,param_1[-1],FUN_00596380);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0xc + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__BatchJobExResponse::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4310 ; VA 0x00596c40 ; FUN_00596c40 */

int * __thiscall FUN_00596c40(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x14,param_1[-1],FUN_0056e640);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x14 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  FUN_0056e640();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4311 ; VA 0x00596ce0 ; FUN_00596ce0 */

int * __thiscall FUN_00596ce0(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,8,param_1[-1],&LAB_00596390);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 8 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__CloseAllJobs::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,8);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4312 ; VA 0x00596d70 ; FUN_00596d70 */

int * __thiscall FUN_00596d70(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0xc,param_1[-1],FUN_005963a0);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0xc + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__CloseAllJobsResponse::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4313 ; VA 0x00596e10 ; FUN_00596e10 */

int * __thiscall FUN_00596e10(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,8,param_1[-1],&LAB_005963b0);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 8 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__CloseExpiredJobs::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,8);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4314 ; VA 0x00596ea0 ; FUN_00596ea0 */

int * __thiscall FUN_00596ea0(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0xc,param_1[-1],FUN_005963c0);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0xc + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__CloseExpiredJobsResponse::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4315 ; VA 0x00596f40 ; FUN_00596f40 */

int * __thiscall FUN_00596f40(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x20,param_1[-1],FUN_005963d0);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x20 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  FUN_005963d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4316 ; VA 0x00596fd0 ; FUN_00596fd0 */

int * __thiscall FUN_00596fd0(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,8,param_1[-1],FUN_00596430);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 8 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__CloseJobResponse::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,8);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4317 ; VA 0x00597060 ; FUN_00597060 */

int * __thiscall FUN_00597060(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x10,param_1[-1],&LAB_00596440);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x10 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__Diag::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4318 ; VA 0x005970f0 ; FUN_005970f0 */

int * __thiscall FUN_005970f0(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x10,param_1[-1],&LAB_00596450);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x10 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__DiagEx::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4319 ; VA 0x00597180 ; FUN_00597180 */

int * __thiscall FUN_00597180(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0xc,param_1[-1],FUN_00596460);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0xc + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__DiagExResponse::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4320 ; VA 0x00597220 ; FUN_00597220 */

int * __thiscall FUN_00597220(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x14,param_1[-1],FUN_00596470);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x14 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  FUN_00596470();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4321 ; VA 0x005972c0 ; FUN_005972c0 */

int * __thiscall FUN_005972c0(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x24,param_1[-1],FUN_005964d0);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x24 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  FUN_005964d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x24);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4322 ; VA 0x00597360 ; FUN_00597360 */

int * __thiscall FUN_00597360(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x24,param_1[-1],FUN_00596530);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x24 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  FUN_00596530();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x24);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4323 ; VA 0x00597400 ; FUN_00597400 */

int * __thiscall FUN_00597400(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0xc,param_1[-1],FUN_00596590);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0xc + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__ExecuteExResponse::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4324 ; VA 0x005974a0 ; FUN_005974a0 */

int * __thiscall FUN_005974a0(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x14,param_1[-1],FUN_005965a0);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x14 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  FUN_005965a0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4325 ; VA 0x00597540 ; FUN_00597540 */

int * __thiscall FUN_00597540(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,8,param_1[-1],&LAB_00596600);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 8 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__GetAllJobs::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,8);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4326 ; VA 0x005975d0 ; FUN_005975d0 */

int * __thiscall FUN_005975d0(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,8,param_1[-1],&LAB_00596610);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 8 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__GetAllJobsEx::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,8);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4327 ; VA 0x00597660 ; FUN_00597660 */

int * __thiscall FUN_00597660(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0xc,param_1[-1],FUN_00596620);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0xc + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__GetAllJobsExResponse::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4328 ; VA 0x00597700 ; FUN_00597700 */

int * __thiscall FUN_00597700(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x14,param_1[-1],FUN_00596630);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x14 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  FUN_00596630();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4329 ; VA 0x005977a0 ; FUN_005977a0 */

int * __thiscall FUN_005977a0(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x20,param_1[-1],FUN_00596690);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x20 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  FUN_00596690();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4330 ; VA 0x00597830 ; FUN_00597830 */

int * __thiscall FUN_00597830(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x18,param_1[-1],FUN_005966f0);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x18 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__GetExpirationResponse::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4331 ; VA 0x005978d0 ; FUN_005978d0 */

int * __thiscall FUN_005978d0(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,8,param_1[-1],&LAB_00596700);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 8 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__GetStatus::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,8);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4332 ; VA 0x00597960 ; FUN_00597960 */

int * __thiscall FUN_00597960(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0xc,param_1[-1],FUN_00596710);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0xc + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__GetStatusResponse::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4333 ; VA 0x00597a00 ; FUN_00597a00 */

int * __thiscall FUN_00597a00(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,8,param_1[-1],&LAB_00596720);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 8 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__GetVersion::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,8);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4334 ; VA 0x00597a90 ; FUN_00597a90 */

int * __thiscall FUN_00597a90(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x20,param_1[-1],FUN_00596730);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x20 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  FUN_00596730();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4335 ; VA 0x00597b20 ; FUN_00597b20 */

int * __thiscall FUN_00597b20(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,8,param_1[-1],&LAB_00596790);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 8 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__HelloWorld::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,8);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4336 ; VA 0x00597bb0 ; FUN_00597bb0 */

int * __thiscall FUN_00597bb0(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0xc,param_1[-1],FUN_005967a0);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0xc + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__HelloWorldResponse::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4337 ; VA 0x00597c50 ; FUN_00597c50 */

int * __thiscall FUN_00597c50(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x10,param_1[-1],FUN_0056e6a0);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x10 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__OpenJob::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4338 ; VA 0x00597ce0 ; FUN_00597ce0 */

int * __thiscall FUN_00597ce0(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x10,param_1[-1],&LAB_005967b0);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x10 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__OpenJobEx::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4339 ; VA 0x00597d70 ; FUN_00597d70 */

int * __thiscall FUN_00597d70(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0xc,param_1[-1],FUN_005967c0);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0xc + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__OpenJobExResponse::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4340 ; VA 0x00597e10 ; FUN_00597e10 */

int * __thiscall FUN_00597e10(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x14,param_1[-1],FUN_0056e6b0);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x14 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  FUN_0056e6b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4341 ; VA 0x00597eb0 ; FUN_00597eb0 */

int * __thiscall FUN_00597eb0(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x30,param_1[-1],FUN_005967d0);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x30 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  FUN_005967d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x30);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4342 ; VA 0x00597f50 ; FUN_00597f50 */

int * __thiscall FUN_00597f50(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x18,param_1[-1],FUN_00596830);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x18 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)_ns1__RenewLeaseResponse::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4343 ; VA 0x00597ff0 ; FUN_00597ff0 */

int * __thiscall FUN_00597ff0(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x14,param_1[-1],FUN_00596840);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x14 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  FUN_00596840();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4344 ; VA 0x00598090 ; FUN_00598090 */

int * __thiscall FUN_00598090(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x14,param_1[-1],FUN_005968a0);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x14 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  FUN_005968a0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4345 ; VA 0x00598130 ; FUN_00598130 */

int * __thiscall FUN_00598130(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x40,param_1[-1],FUN_0056e940);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x40 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  FUN_0056e940();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x40);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4346 ; VA 0x005981c0 ; FUN_005981c0 */

int * __thiscall FUN_005981c0(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x14,param_1[-1],&LAB_00596900);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x14 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)ns1__LuaValue::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4347 ; VA 0x00598260 ; FUN_00598260 */

int * __thiscall FUN_00598260(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x14,param_1[-1],FUN_0056e9a0);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x14 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)ns1__ScriptExecution::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4348 ; VA 0x00598300 ; FUN_00598300 */

int * __thiscall FUN_00598300(int *param_1,uint param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((param_2 & 2) != 0) {
    piVar1 = param_1 + -1;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1,0x10,param_1[-1],&LAB_00596910);
    if ((param_2 & 1) != 0) {
      FUN_01674ea0(piVar1,*piVar1 * 0x10 + 4);
    }
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = &pvStack_10;
  *param_1 = (int)ns1__Status::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4349 ; VA 0x00598390 ; FUN_00598390 */

void FUN_00598390(undefined4 param_1,undefined4 param_2,int param_3,int *param_4,int param_5,
                 undefined4 *param_6)

{
  if ((param_3 == 0x39) || (param_3 == 0x3b)) {
    *(undefined4 *)(*param_4 + param_5 * 4) = *param_6;
  }
  return;
}



/* FUNCTION 4350 ; VA 0x005983c0 ; FUN_005983c0 */

void FUN_005983c0(void)

{
  int in_stack_00000010;
  int in_stack_00000018;
  
  *(undefined4 *)(in_stack_00000010 + 4) = *(undefined4 *)(in_stack_00000018 + 4);
  *(undefined4 *)(in_stack_00000010 + 8) = *(undefined4 *)(in_stack_00000018 + 8);
  *(undefined4 *)(in_stack_00000010 + 0xc) = *(undefined4 *)(in_stack_00000018 + 0xc);
  return;
}



/* FUNCTION 4351 ; VA 0x005983e0 ; FUN_005983e0 */

void FUN_005983e0(void)

{
  int in_stack_00000010;
  int in_stack_00000018;
  
  *(undefined4 *)(in_stack_00000010 + 4) = *(undefined4 *)(in_stack_00000018 + 4);
  *(undefined4 *)(in_stack_00000010 + 8) = *(undefined4 *)(in_stack_00000018 + 8);
  return;
}



/* FUNCTION 4352 ; VA 0x00598400 ; FUN_00598400 */

void FUN_00598400(void)

{
  int in_stack_00000010;
  int in_stack_00000018;
  
  FUN_00596920(in_stack_00000018 + 4);
  *(undefined4 *)(in_stack_00000010 + 0x10) = *(undefined4 *)(in_stack_00000018 + 0x10);
  return;
}



/* FUNCTION 4353 ; VA 0x00598430 ; FUN_00598430 */

void FUN_00598430(void)

{
  int in_stack_00000010;
  int in_stack_00000018;
  
  *(undefined4 *)(in_stack_00000010 + 4) = *(undefined4 *)(in_stack_00000018 + 4);
  return;
}



/* FUNCTION 4354 ; VA 0x00598450 ; FUN_00598450 */

void FUN_00598450(void)

{
  int *piVar1;
  int in_stack_00000010;
  int in_stack_00000018;
  
  piVar1 = (int *)(in_stack_00000018 + 4);
  if ((int *)(in_stack_00000010 + 4) != piVar1) {
    if (0xf < *(uint *)(in_stack_00000018 + 0x18)) {
      piVar1 = (int *)*piVar1;
    }
    FUN_005542c0(piVar1,*(undefined4 *)(in_stack_00000018 + 0x14));
  }
  *(undefined4 *)(in_stack_00000010 + 0x1c) = *(undefined4 *)(in_stack_00000018 + 0x1c);
  return;
}



/* FUNCTION 4355 ; VA 0x00598490 ; FUN_00598490 */

void FUN_00598490(void)

{
  int *piVar1;
  int in_stack_00000010;
  int in_stack_00000018;
  
  piVar1 = (int *)(in_stack_00000018 + 4);
  if ((int *)(in_stack_00000010 + 4) != piVar1) {
    if (0xf < *(uint *)(in_stack_00000018 + 0x18)) {
      piVar1 = (int *)*piVar1;
    }
    FUN_005542c0(piVar1,*(undefined4 *)(in_stack_00000018 + 0x14));
  }
  *(undefined4 *)(in_stack_00000010 + 0x1c) = *(undefined4 *)(in_stack_00000018 + 0x1c);
  *(undefined4 *)(in_stack_00000010 + 0x20) = *(undefined4 *)(in_stack_00000018 + 0x20);
  return;
}



/* FUNCTION 4356 ; VA 0x005984d0 ; FUN_005984d0 */

void FUN_005984d0(void)

{
  int in_stack_00000010;
  int in_stack_00000018;
  
  *(undefined8 *)(in_stack_00000010 + 8) = *(undefined8 *)(in_stack_00000018 + 8);
  *(undefined4 *)(in_stack_00000010 + 0x10) = *(undefined4 *)(in_stack_00000018 + 0x10);
  return;
}



/* FUNCTION 4357 ; VA 0x005984f0 ; FUN_005984f0 */

void FUN_005984f0(void)

{
  int *piVar1;
  int in_stack_00000010;
  int in_stack_00000018;
  
  piVar1 = (int *)(in_stack_00000018 + 8);
  if ((int *)(in_stack_00000010 + 8) != piVar1) {
    if (0xf < *(uint *)(in_stack_00000018 + 0x1c)) {
      piVar1 = (int *)*piVar1;
    }
    FUN_005542c0(piVar1,*(undefined4 *)(in_stack_00000018 + 0x18));
  }
  *(undefined8 *)(in_stack_00000010 + 0x20) = *(undefined8 *)(in_stack_00000018 + 0x20);
  *(undefined4 *)(in_stack_00000010 + 0x28) = *(undefined4 *)(in_stack_00000018 + 0x28);
  return;
}



/* FUNCTION 4358 ; VA 0x00598530 ; FUN_00598530 */

void FUN_00598530(void)

{
  int *piVar1;
  int in_stack_00000010;
  int in_stack_00000018;
  
  piVar1 = (int *)(in_stack_00000018 + 8);
  if ((int *)(in_stack_00000010 + 8) != piVar1) {
    if (0xf < *(uint *)(in_stack_00000018 + 0x1c)) {
      piVar1 = (int *)*piVar1;
    }
    FUN_005542c0(piVar1,*(undefined4 *)(in_stack_00000018 + 0x18));
  }
  *(undefined8 *)(in_stack_00000010 + 0x20) = *(undefined8 *)(in_stack_00000018 + 0x20);
  *(undefined4 *)(in_stack_00000010 + 0x28) = *(undefined4 *)(in_stack_00000018 + 0x28);
  *(undefined8 *)(in_stack_00000010 + 0x30) = *(undefined8 *)(in_stack_00000018 + 0x30);
  *(undefined4 *)(in_stack_00000010 + 0x38) = *(undefined4 *)(in_stack_00000018 + 0x38);
  return;
}



/* FUNCTION 4359 ; VA 0x00598580 ; FUN_00598580 */

void FUN_00598580(void)

{
  int in_stack_00000010;
  int in_stack_00000018;
  
  *(undefined4 *)(in_stack_00000010 + 4) = *(undefined4 *)(in_stack_00000018 + 4);
  *(undefined4 *)(in_stack_00000010 + 8) = *(undefined4 *)(in_stack_00000018 + 8);
  *(undefined4 *)(in_stack_00000010 + 0xc) = *(undefined4 *)(in_stack_00000018 + 0xc);
  *(undefined4 *)(in_stack_00000010 + 0x10) = *(undefined4 *)(in_stack_00000018 + 0x10);
  return;
}



/* FUNCTION 4360 ; VA 0x005985b0 ; FUN_005985b0 */

void FUN_005985b0(void)

{
  undefined4 *puVar1;
  undefined4 *in_stack_00000010;
  undefined4 *in_stack_00000018;
  
  if (in_stack_00000010 != in_stack_00000018) {
    puVar1 = in_stack_00000018 + 4;
    if (0xf < (uint)in_stack_00000018[5]) {
      in_stack_00000018 = (undefined4 *)*in_stack_00000018;
    }
    FUN_005542c0(in_stack_00000018,*puVar1);
  }
  return;
}



/* FUNCTION 4361 ; VA 0x005985e0 ; FUN_005985e0 */

void __thiscall FUN_005985e0(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0xc) = param_2;
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  return;
}



/* FUNCTION 4362 ; VA 0x00598600 ; FUN_00598600 */

void __thiscall FUN_00598600(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 8) = param_2;
  *(undefined4 *)(param_1 + 4) = 0;
  return;
}



/* FUNCTION 4363 ; VA 0x00598620 ; FUN_00598620 */

void __thiscall FUN_00598620(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x10) = param_2;
  *(undefined4 *)(param_1 + 8) = *(undefined4 *)(param_1 + 4);
  return;
}



/* FUNCTION 4364 ; VA 0x00598640 ; FUN_00598640 */

void __thiscall FUN_00598640(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 4) = param_2;
  return;
}



/* FUNCTION 4365 ; VA 0x00598650 ; FUN_00598650 */

void __thiscall FUN_00598650(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x1c) = param_2;
  *(undefined4 *)(param_1 + 0x14) = 0;
  if (0xf < *(uint *)(param_1 + 0x18)) {
    **(undefined **)(param_1 + 4) = 0;
    return;
  }
  *(undefined *)(param_1 + 4) = 0;
  return;
}



/* FUNCTION 4366 ; VA 0x00598680 ; FUN_00598680 */

void __thiscall FUN_00598680(int param_1,undefined4 param_2)

{
  undefined *puVar1;
  
  puVar1 = (undefined *)(param_1 + 4);
  *(undefined4 *)(param_1 + 0x20) = param_2;
  if (0xf < *(uint *)(param_1 + 0x18)) {
    puVar1 = *(undefined **)(param_1 + 4);
  }
  *(undefined4 *)(param_1 + 0x14) = 0;
  *puVar1 = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  return;
}



/* FUNCTION 4367 ; VA 0x005986b0 ; FUN_005986b0 */

void __thiscall FUN_005986b0(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x10) = param_2;
  *(undefined8 *)(param_1 + 8) = 0;
  return;
}



/* FUNCTION 4368 ; VA 0x005986d0 ; FUN_005986d0 */

void __thiscall FUN_005986d0(int param_1,undefined4 param_2)

{
  undefined *puVar1;
  
  puVar1 = (undefined *)(param_1 + 8);
  *(undefined4 *)(param_1 + 0x28) = param_2;
  if (0xf < *(uint *)(param_1 + 0x1c)) {
    puVar1 = *(undefined **)(param_1 + 8);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *puVar1 = 0;
  *(undefined8 *)(param_1 + 0x20) = 0;
  return;
}



/* FUNCTION 4369 ; VA 0x00598700 ; FUN_00598700 */

void __thiscall FUN_00598700(int param_1,undefined4 param_2)

{
  undefined *puVar1;
  
  puVar1 = (undefined *)(param_1 + 8);
  *(undefined4 *)(param_1 + 0x38) = param_2;
  if (0xf < *(uint *)(param_1 + 0x1c)) {
    puVar1 = *(undefined **)(param_1 + 8);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *puVar1 = 0;
  *(undefined8 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined8 *)(param_1 + 0x30) = 0;
  return;
}



/* FUNCTION 4370 ; VA 0x00598740 ; FUN_00598740 */

void __thiscall FUN_00598740(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x10) = param_2;
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  return;
}



/* FUNCTION 4371 ; VA 0x00598770 ; FUN_00598770 */

void FUN_00598770(undefined4 param_1,undefined4 *param_2)

{
  *param_2 = 0;
  return;
}



/* FUNCTION 4372 ; VA 0x00598780 ; FUN_00598780 */

undefined4 FUN_00598780(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797c70;
  pvStack_10 = ExceptionList;
  switch(*(undefined4 *)(param_1 + 8)) {
  case 8:
  case 9:
  case 10:
  case 0xb:
  case 0xc:
  case 0xd:
  case 0xe:
  case 0xf:
  case 0x10:
  case 0x11:
  case 0x12:
  case 0x13:
  case 0x14:
  case 0x15:
  case 0x16:
  case 0x17:
  case 0x18:
  case 0x19:
  case 0x1a:
  case 0x1b:
  case 0x1c:
  case 0x1d:
  case 0x1e:
  case 0x1f:
  case 0x20:
  case 0x21:
  case 0x22:
  case 0x23:
  case 0x24:
  case 0x25:
  case 0x26:
  case 0x27:
  case 0x28:
  case 0x29:
  case 0x2a:
  case 0x2b:
  case 0x2c:
  case 0x2d:
  case 0x2e:
  case 0x2f:
  case 0x30:
  case 0x31:
    piVar1 = *(int **)(param_1 + 4);
    if (*(int *)(param_1 + 0xc) < 0) {
      if (piVar1 == (int *)0x0) {
        return 0;
      }
      ExceptionList = &pvStack_10;
      (**(code **)(*piVar1 + 0x1c))(1);
      ExceptionList = pvStack_10;
      return 0;
    }
    if (piVar1 == (int *)0x0) {
      return 0;
    }
    piVar6 = piVar1 + -1;
    if (piVar1[-1] != 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(*piVar1 + 0x1c))(3);
      ExceptionList = pvStack_10;
      return 0;
    }
    goto LAB_005988cb;
  default:
    return 0xffffffff;
  case 0x33:
    if (-1 < *(int *)(param_1 + 0xc)) {
      iVar3 = *(int *)(param_1 + 4);
      if (iVar3 == 0) {
        return 0;
      }
      uStack_8 = 0;
      ExceptionList = &pvStack_10;
      FUN_016f32d1(iVar3,0x18,*(undefined4 *)(iVar3 + -4),FUN_005507b0);
      FUN_01674ea0((int *)(iVar3 + -4),*(int *)(iVar3 + -4) * 0x18 + 4);
      ExceptionList = pvStack_10;
      return 0;
    }
    piVar6 = *(int **)(param_1 + 4);
    if (piVar6 == (int *)0x0) {
      return 0;
    }
    uVar5 = piVar6[5];
    ExceptionList = &pvStack_10;
    if (0xf < uVar5) {
      iVar3 = *piVar6;
      uVar4 = uVar5 + 1;
      iVar2 = iVar3;
      if (0xfff < uVar4) {
        iVar2 = *(int *)(iVar3 + -4);
        uVar4 = uVar5 + 0x24;
        if (0x1f < (iVar3 - iVar2) - 4U) goto LAB_00598a8d;
      }
      ExceptionList = &pvStack_10;
      FUN_01674ea0(iVar2,uVar4);
    }
    piVar6[4] = 0;
    piVar6[5] = 0xf;
    *(undefined *)piVar6 = 0;
    FUN_01674ea0(piVar6,0x18);
    ExceptionList = pvStack_10;
    return 0;
  case 0x39:
    if (-1 < *(int *)(param_1 + 0xc)) {
      iVar3 = *(int *)(param_1 + 4);
      if (iVar3 == 0) {
        return 0;
      }
      uStack_8 = 2;
LAB_00598a46:
      ExceptionList = &pvStack_10;
      FUN_016f32d1(iVar3,0xc,*(undefined4 *)(iVar3 + -4),FUN_0056d320);
      FUN_01674ea0((int *)(iVar3 + -4),*(int *)(iVar3 + -4) * 0xc + 4);
      ExceptionList = pvStack_10;
      return 0;
    }
    goto LAB_005989a3;
  case 0x3b:
    if (-1 < *(int *)(param_1 + 0xc)) {
      iVar3 = *(int *)(param_1 + 4);
      if (iVar3 == 0) {
        return 0;
      }
      uStack_8 = 1;
      goto LAB_00598a46;
    }
LAB_005989a3:
    piVar6 = *(int **)(param_1 + 4);
    if (piVar6 == (int *)0x0) {
      return 0;
    }
    iVar3 = *piVar6;
    ExceptionList = &pvStack_10;
    if (iVar3 != 0) {
      uVar5 = piVar6[2] - iVar3 & 0xfffffffc;
      iVar2 = iVar3;
      if (0xfff < uVar5) {
        iVar2 = *(int *)(iVar3 + -4);
        uVar5 = uVar5 + 0x23;
        if (0x1f < (iVar3 - iVar2) - 4U) {
LAB_00598a8d:
          ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      ExceptionList = &pvStack_10;
      FUN_01674ea0(iVar2,uVar5);
      *piVar6 = 0;
      piVar6[1] = 0;
      piVar6[2] = 0;
    }
    FUN_01674ea0(piVar6,0xc);
    ExceptionList = pvStack_10;
    return 0;
  case 0x42:
  case 0x46:
  case 0x4a:
  case 0x4e:
  case 0x52:
  case 0x56:
  case 0x5a:
  case 0x5e:
  case 0x62:
  case 0x66:
  case 0x6a:
  case 0x6e:
  case 0x72:
  case 0x76:
  case 0x7a:
  case 0x7e:
  case 0x82:
  case 0x86:
  case 0x88:
  case 0x8a:
  case 0x8c:
  case 0x8e:
  case 0x90:
  case 0x92:
  case 0x94:
  case 0x96:
  case 0x98:
  case 0x9a:
  case 0x9c:
  case 0x9e:
  case 0xa0:
  case 0xa2:
  case 0xa4:
  case 0xa6:
  case 0xa8:
  case 0xaa:
  case 0xb1:
    if (*(int *)(param_1 + 0xc) < 0) {
      ExceptionList = &pvStack_10;
      FUN_01674ea0(*(undefined4 *)(param_1 + 4),4);
      ExceptionList = pvStack_10;
      return 0;
    }
    break;
  case 0xab:
    if (*(int *)(param_1 + 0xc) < 0) {
      ExceptionList = &pvStack_10;
      FUN_01674ea0(*(undefined4 *)(param_1 + 4),1);
      ExceptionList = pvStack_10;
      return 0;
    }
    break;
  case 0xac:
    if (*(int *)(param_1 + 0xc) < 0) {
      ExceptionList = &pvStack_10;
      FUN_01674ea0(*(undefined4 *)(param_1 + 4),8);
      ExceptionList = pvStack_10;
      return 0;
    }
    break;
  case 0xae:
    if (*(int *)(param_1 + 0xc) < 0) {
      ExceptionList = &pvStack_10;
      FUN_01674ea0(*(undefined4 *)(param_1 + 4),0xc);
      ExceptionList = pvStack_10;
      return 0;
    }
    break;
  case 0xb2:
    if (*(int *)(param_1 + 0xc) < 0) {
      ExceptionList = &pvStack_10;
      FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x24);
      ExceptionList = pvStack_10;
      return 0;
    }
  }
  piVar6 = *(int **)(param_1 + 4);
LAB_005988cb:
  ExceptionList = &pvStack_10;
  FUN_01674ea0(piVar6);
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 4373 ; VA 0x00598b70 ; FUN_00598b70 */

int __thiscall
FUN_00598b70(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059e4d0(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4374 ; VA 0x00598bb0 ; FUN_00598bb0 */

int __thiscall
FUN_00598bb0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059e6a0(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4375 ; VA 0x00598bf0 ; FUN_00598bf0 */

int __thiscall
FUN_00598bf0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059e870(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4376 ; VA 0x00598c30 ; FUN_00598c30 */

int __thiscall
FUN_00598c30(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059ea10(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4377 ; VA 0x00598c70 ; FUN_00598c70 */

int __thiscall
FUN_00598c70(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059eb70(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4378 ; VA 0x00598cb0 ; FUN_00598cb0 */

int __thiscall
FUN_00598cb0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059eca0(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4379 ; VA 0x00598cf0 ; FUN_00598cf0 */

int __thiscall
FUN_00598cf0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059ee40(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4380 ; VA 0x00598d30 ; FUN_00598d30 */

int __thiscall
FUN_00598d30(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059ef70(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4381 ; VA 0x00598d70 ; FUN_00598d70 */

int __thiscall
FUN_00598d70(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059f110(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4382 ; VA 0x00598db0 ; FUN_00598db0 */

int __thiscall
FUN_00598db0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059f2b0(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4383 ; VA 0x00598df0 ; FUN_00598df0 */

int __thiscall
FUN_00598df0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059f3e0(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4384 ; VA 0x00598e30 ; FUN_00598e30 */

int __thiscall
FUN_00598e30(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059f5c0(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4385 ; VA 0x00598e70 ; FUN_00598e70 */

int __thiscall
FUN_00598e70(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059f7a0(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4386 ; VA 0x00598eb0 ; FUN_00598eb0 */

int __thiscall
FUN_00598eb0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059f940(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4387 ; VA 0x00598ef0 ; FUN_00598ef0 */

int __thiscall
FUN_00598ef0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059faa0(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4388 ; VA 0x00598f30 ; FUN_00598f30 */

int __thiscall
FUN_00598f30(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059fc70(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4389 ; VA 0x00598f70 ; FUN_00598f70 */

int __thiscall
FUN_00598f70(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059fe40(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4390 ; VA 0x00598fb0 ; FUN_00598fb0 */

int __thiscall
FUN_00598fb0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059ffe0(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4391 ; VA 0x00598ff0 ; FUN_00598ff0 */

int __thiscall
FUN_00598ff0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a0140(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4392 ; VA 0x00599030 ; FUN_00599030 */

int __thiscall
FUN_00599030(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a0270(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4393 ; VA 0x00599070 ; FUN_00599070 */

int __thiscall
FUN_00599070(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a03a0(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4394 ; VA 0x005990b0 ; FUN_005990b0 */

int __thiscall
FUN_005990b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a0540(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4395 ; VA 0x005990f0 ; FUN_005990f0 */

int __thiscall
FUN_005990f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a06a0(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4396 ; VA 0x00599130 ; FUN_00599130 */

int __thiscall
FUN_00599130(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a0840(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4397 ; VA 0x00599170 ; FUN_00599170 */

int __thiscall
FUN_00599170(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a09e0(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4398 ; VA 0x005991b0 ; FUN_005991b0 */

int __thiscall
FUN_005991b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a0b10(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4399 ; VA 0x005991f0 ; FUN_005991f0 */

int __thiscall
FUN_005991f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a0cb0(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4400 ; VA 0x00599230 ; FUN_00599230 */

int __thiscall
FUN_00599230(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a0de0(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4401 ; VA 0x00599270 ; FUN_00599270 */

int __thiscall
FUN_00599270(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a0f80(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4402 ; VA 0x005992b0 ; FUN_005992b0 */

int __thiscall
FUN_005992b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a10b0(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4403 ; VA 0x005992f0 ; FUN_005992f0 */

int __thiscall
FUN_005992f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a1230(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4404 ; VA 0x00599330 ; FUN_00599330 */

int __thiscall
FUN_00599330(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a1400(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4405 ; VA 0x00599370 ; FUN_00599370 */

int __thiscall
FUN_00599370(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a15d0(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4406 ; VA 0x005993b0 ; FUN_005993b0 */

int __thiscall
FUN_005993b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a1770(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4407 ; VA 0x005993f0 ; FUN_005993f0 */

int __thiscall
FUN_005993f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a18d0(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4408 ; VA 0x00599430 ; FUN_00599430 */

int __thiscall
FUN_00599430(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a1ab0(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4409 ; VA 0x00599470 ; FUN_00599470 */

int __thiscall
FUN_00599470(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a1c50(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4410 ; VA 0x005994b0 ; FUN_005994b0 */

int __thiscall
FUN_005994b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a1da0(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4411 ; VA 0x005994f0 ; FUN_005994f0 */

int __thiscall
FUN_005994f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a1ef0(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4412 ; VA 0x00599530 ; FUN_00599530 */

int __thiscall
FUN_00599530(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a2280(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4413 ; VA 0x00599570 ; FUN_00599570 */

int __thiscall
FUN_00599570(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a2490(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4414 ; VA 0x005995b0 ; FUN_005995b0 */

int __thiscall
FUN_005995b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005a26a0(param_2,param_3,param_1,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_2);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4415 ; VA 0x005995f0 ; FUN_005995f0 */

int FUN_005995f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059cee0(param_1,param_3,param_2,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_1);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4416 ; VA 0x00599630 ; FUN_00599630 */

int FUN_00599630(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059d0a0(param_1,param_3,param_2,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_1);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4417 ; VA 0x00599670 ; FUN_00599670 */

int FUN_00599670(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059d260(param_1,param_3,param_2,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_1);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4418 ; VA 0x005996b0 ; FUN_005996b0 */

int FUN_005996b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059d400(param_1,param_3,param_2,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_1);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4419 ; VA 0x005996f0 ; FUN_005996f0 */

undefined4 * FUN_005996f0(int param_1,undefined4 param_2)

{
  bool bVar1;
  undefined4 *puVar2;
  int iVar3;
  short sVar4;
  
  sVar4 = 1;
  puVar2 = (undefined4 *)FUN_005b6e40(param_1,&DAT_018bc9b8,param_2,0x62,4,0,0,0,0);
  if (puVar2 != (undefined4 *)0x0) {
    *puVar2 = 0;
    bVar1 = false;
    while (*(undefined4 *)(param_1 + 0x1615c) = 3, sVar4 != 0) {
      iVar3 = FUN_0059ac20(param_1,"ns1:CloseJob",puVar2,&DAT_018bc9b8);
      if (iVar3 == 0) {
        iVar3 = *(int *)(param_1 + 0x1615c);
        if (iVar3 == 3) break;
        if (iVar3 == 6) goto LAB_00599788;
        if (iVar3 != 0) {
          return (undefined4 *)0x0;
        }
        bVar1 = true;
      }
      else {
        sVar4 = sVar4 + -1;
        bVar1 = true;
      }
    }
    if (bVar1) {
      *(undefined4 *)(param_1 + 0x1615c) = 0;
LAB_00599788:
      iVar3 = FUN_00599cf0(param_1);
      if (iVar3 != 0) {
        return (undefined4 *)0x0;
      }
      return puVar2;
    }
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 4420 ; VA 0x005997b0 ; FUN_005997b0 */

int FUN_005997b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059d5a0(param_1,param_3,param_2,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_1);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4421 ; VA 0x005997f0 ; FUN_005997f0 */

int FUN_005997f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059d760(param_1,param_3,param_2,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_1);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4422 ; VA 0x00599830 ; FUN_00599830 */

undefined4 * FUN_00599830(int param_1,undefined4 param_2)

{
  bool bVar1;
  undefined4 *puVar2;
  int iVar3;
  short sVar4;
  
  sVar4 = 1;
  puVar2 = (undefined4 *)FUN_005b6e40(param_1,&DAT_018bc9b8,param_2,0x5a,4,0,0,0,0);
  if (puVar2 != (undefined4 *)0x0) {
    *puVar2 = 0;
    bVar1 = false;
    while (*(undefined4 *)(param_1 + 0x1615c) = 3, sVar4 != 0) {
      iVar3 = FUN_0059b230(param_1,"ns1:Execute",puVar2,&DAT_018bc9b8);
      if (iVar3 == 0) {
        iVar3 = *(int *)(param_1 + 0x1615c);
        if (iVar3 == 3) break;
        if (iVar3 == 6) goto LAB_005998c8;
        if (iVar3 != 0) {
          return (undefined4 *)0x0;
        }
        bVar1 = true;
      }
      else {
        sVar4 = sVar4 + -1;
        bVar1 = true;
      }
    }
    if (bVar1) {
      *(undefined4 *)(param_1 + 0x1615c) = 0;
LAB_005998c8:
      iVar3 = FUN_00599cf0(param_1);
      if (iVar3 != 0) {
        return (undefined4 *)0x0;
      }
      return puVar2;
    }
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 4423 ; VA 0x005998f0 ; FUN_005998f0 */

undefined4 * FUN_005998f0(int param_1,undefined4 param_2)

{
  bool bVar1;
  undefined4 *puVar2;
  int iVar3;
  short sVar4;
  
  sVar4 = 1;
  puVar2 = (undefined4 *)FUN_005b6e40(param_1,&DAT_018bc9b8,param_2,0x5e,4,0,0,0,0);
  if (puVar2 != (undefined4 *)0x0) {
    *puVar2 = 0;
    bVar1 = false;
    while (*(undefined4 *)(param_1 + 0x1615c) = 3, sVar4 != 0) {
      iVar3 = FUN_0059b300(param_1,"ns1:ExecuteEx",puVar2,&DAT_018bc9b8);
      if (iVar3 == 0) {
        iVar3 = *(int *)(param_1 + 0x1615c);
        if (iVar3 == 3) break;
        if (iVar3 == 6) goto LAB_00599988;
        if (iVar3 != 0) {
          return (undefined4 *)0x0;
        }
        bVar1 = true;
      }
      else {
        sVar4 = sVar4 + -1;
        bVar1 = true;
      }
    }
    if (bVar1) {
      *(undefined4 *)(param_1 + 0x1615c) = 0;
LAB_00599988:
      iVar3 = FUN_00599cf0(param_1);
      if (iVar3 != 0) {
        return (undefined4 *)0x0;
      }
      return puVar2;
    }
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 4424 ; VA 0x005999b0 ; FUN_005999b0 */

int FUN_005999b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059d920(param_1,param_3,param_2,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_1);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4425 ; VA 0x005999f0 ; FUN_005999f0 */

int FUN_005999f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059dac0(param_1,param_3,param_2,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_1);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4426 ; VA 0x00599a30 ; FUN_00599a30 */

undefined4 * FUN_00599a30(int param_1,undefined4 param_2)

{
  bool bVar1;
  undefined4 *puVar2;
  int iVar3;
  short sVar4;
  
  sVar4 = 1;
  puVar2 = (undefined4 *)FUN_005b6e40(param_1,&DAT_018bc9b8,param_2,0x6e,4,0,0,0,0);
  if (puVar2 != (undefined4 *)0x0) {
    *puVar2 = 0;
    bVar1 = false;
    while (*(undefined4 *)(param_1 + 0x1615c) = 3, sVar4 != 0) {
      iVar3 = FUN_0059b9d0(param_1,"ns1:GetExpiration",puVar2,&DAT_018bc9b8);
      if (iVar3 == 0) {
        iVar3 = *(int *)(param_1 + 0x1615c);
        if (iVar3 == 3) break;
        if (iVar3 == 6) goto LAB_00599ac8;
        if (iVar3 != 0) {
          return (undefined4 *)0x0;
        }
        bVar1 = true;
      }
      else {
        sVar4 = sVar4 + -1;
        bVar1 = true;
      }
    }
    if (bVar1) {
      *(undefined4 *)(param_1 + 0x1615c) = 0;
LAB_00599ac8:
      iVar3 = FUN_00599cf0(param_1);
      if (iVar3 != 0) {
        return (undefined4 *)0x0;
      }
      return puVar2;
    }
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 4427 ; VA 0x00599af0 ; FUN_00599af0 */

int FUN_00599af0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059dc60(param_1,param_3,param_2,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_1);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4428 ; VA 0x00599b30 ; FUN_00599b30 */

int FUN_00599b30(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059de00(param_1,param_3,param_2,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_1);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4429 ; VA 0x00599b70 ; FUN_00599b70 */

int FUN_00599b70(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059dfb0(param_1,param_3,param_2,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_1);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4430 ; VA 0x00599bb0 ; FUN_00599bb0 */

int FUN_00599bb0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059e150(param_1,param_3,param_2,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_1);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4431 ; VA 0x00599bf0 ; FUN_00599bf0 */

int FUN_00599bf0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0059e310(param_1,param_3,param_2,param_4);
  if (iVar1 != 0) {
    iVar2 = FUN_00599cf0(param_1);
    if (iVar2 != 0) {
      return 0;
    }
  }
  return iVar1;
}



/* FUNCTION 4432 ; VA 0x00599c30 ; FUN_00599c30 */

undefined4 * FUN_00599c30(int param_1,undefined4 param_2)

{
  bool bVar1;
  undefined4 *puVar2;
  int iVar3;
  short sVar4;
  
  sVar4 = 1;
  puVar2 = (undefined4 *)FUN_005b6e40(param_1,&DAT_018bc9b8,param_2,0x56,4,0,0,0,0);
  if (puVar2 != (undefined4 *)0x0) {
    *puVar2 = 0;
    bVar1 = false;
    while (*(undefined4 *)(param_1 + 0x1615c) = 3, sVar4 != 0) {
      iVar3 = FUN_0059c630(param_1,"ns1:RenewLease",puVar2,&DAT_018bc9b8);
      if (iVar3 == 0) {
        iVar3 = *(int *)(param_1 + 0x1615c);
        if (iVar3 == 3) break;
        if (iVar3 == 6) goto LAB_00599cc8;
        if (iVar3 != 0) {
          return (undefined4 *)0x0;
        }
        bVar1 = true;
      }
      else {
        sVar4 = sVar4 + -1;
        bVar1 = true;
      }
    }
    if (bVar1) {
      *(undefined4 *)(param_1 + 0x1615c) = 0;
LAB_00599cc8:
      iVar3 = FUN_00599cf0(param_1);
      if (iVar3 != 0) {
        return (undefined4 *)0x0;
      }
      return puVar2;
    }
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 4433 ; VA 0x00599cf0 ; FUN_00599cf0 */

int FUN_00599cf0(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_1;
  do {
    do {
      iVar2 = FUN_005acf00(iVar1,&param_1);
    } while (iVar2 != 0);
    iVar2 = *(int *)(iVar1 + 0x1615c);
    if (iVar2 != 0) goto LAB_00599d25;
    iVar2 = FUN_00599d40(iVar1);
  } while (iVar2 == 0);
  iVar2 = *(int *)(iVar1 + 0x1615c);
LAB_00599d25:
  if ((iVar2 == 6) || (iVar2 == -1)) {
    *(undefined4 *)(iVar1 + 0x1615c) = 0;
    iVar2 = 0;
  }
  return iVar2;
}



/* FUNCTION 4434 ; VA 0x00599d40 ; FUN_00599d40 */

undefined4 FUN_00599d40(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined auStack_8 [4];
  
  iVar1 = FUN_005b8900(param_1);
  if (iVar1 != 0) {
LAB_00599e3a:
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  if ((*(short *)(param_1 + 0x15502) != 0) && (*(short *)(param_1 + 0x154b4) == 0)) {
    *(undefined4 *)(param_1 + 0x1615c) = 8;
    return 8;
  }
  if (((*(uint *)(param_1 + 8) & 0x1000) == 0) || (*(short *)(param_1 + 0x15508) == 3)) {
    iVar1 = FUN_005b8220(param_1,param_1 + 0x138b4,"SOAP-ENV:");
    if (iVar1 != 0) {
      if (*(char *)(param_1 + 0x13cb4) != '\0') {
        iVar1 = FUN_005acf00(param_1,auStack_8);
        if (iVar1 != 0) goto LAB_00599e3a;
      }
      *(undefined2 *)(param_1 + 0x1550c) = 0;
      if (*(code **)(param_1 + 0x3024) == (code *)0x0) {
        iVar1 = 0;
      }
      else {
        iVar1 = (**(code **)(param_1 + 0x3024))(param_1,param_1 + 0x138b4);
      }
      *(int *)(param_1 + 0x1615c) = iVar1;
      if ((iVar1 == 0) && (*(short *)(param_1 + 0x309a) != 0)) {
        *(int *)(param_1 + 0x309c) = *(int *)(param_1 + 0x309c) + 1;
        do {
          iVar1 = FUN_00599d40(param_1);
        } while (iVar1 == 0);
        if (*(int *)(param_1 + 0x1615c) == 6) {
          uVar2 = FUN_005b3cc0(param_1,0);
          *(undefined4 *)(param_1 + 0x1615c) = uVar2;
        }
      }
      goto LAB_00599e3a;
    }
  }
  *(undefined4 *)(param_1 + 0x1615c) = 3;
  return 3;
}



/* FUNCTION 4435 ; VA 0x00599e50 ; FUN_00599e50 */

void __thiscall
FUN_00599e50(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0059e4d0(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4436 ; VA 0x00599e70 ; FUN_00599e70 */

void __thiscall
FUN_00599e70(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0059e6a0(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4437 ; VA 0x00599e90 ; FUN_00599e90 */

void __thiscall
FUN_00599e90(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0059e870(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4438 ; VA 0x00599eb0 ; FUN_00599eb0 */

void __thiscall
FUN_00599eb0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0059ea10(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4439 ; VA 0x00599ed0 ; FUN_00599ed0 */

void __thiscall
FUN_00599ed0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0059eb70(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4440 ; VA 0x00599ef0 ; FUN_00599ef0 */

void __thiscall
FUN_00599ef0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0059eca0(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4441 ; VA 0x00599f10 ; FUN_00599f10 */

void __thiscall
FUN_00599f10(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0059ee40(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4442 ; VA 0x00599f30 ; FUN_00599f30 */

void __thiscall
FUN_00599f30(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0059ef70(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4443 ; VA 0x00599f50 ; FUN_00599f50 */

void __thiscall
FUN_00599f50(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0059f110(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4444 ; VA 0x00599f70 ; FUN_00599f70 */

void __thiscall
FUN_00599f70(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0059f2b0(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4445 ; VA 0x00599f90 ; FUN_00599f90 */

void __thiscall
FUN_00599f90(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0059f3e0(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4446 ; VA 0x00599fb0 ; FUN_00599fb0 */

void __thiscall
FUN_00599fb0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0059f5c0(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4447 ; VA 0x00599fd0 ; FUN_00599fd0 */

void __thiscall
FUN_00599fd0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0059f7a0(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4448 ; VA 0x00599ff0 ; FUN_00599ff0 */

void __thiscall
FUN_00599ff0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0059f940(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4449 ; VA 0x0059a010 ; FUN_0059a010 */

void __thiscall
FUN_0059a010(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0059faa0(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4450 ; VA 0x0059a030 ; FUN_0059a030 */

void __thiscall
FUN_0059a030(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0059fc70(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4451 ; VA 0x0059a050 ; FUN_0059a050 */

void __thiscall
FUN_0059a050(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0059fe40(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4452 ; VA 0x0059a070 ; FUN_0059a070 */

void __thiscall
FUN_0059a070(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0059ffe0(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4453 ; VA 0x0059a090 ; FUN_0059a090 */

void __thiscall
FUN_0059a090(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a0140(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4454 ; VA 0x0059a0b0 ; FUN_0059a0b0 */

void __thiscall
FUN_0059a0b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a0270(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4455 ; VA 0x0059a0d0 ; FUN_0059a0d0 */

void __thiscall
FUN_0059a0d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a03a0(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4456 ; VA 0x0059a0f0 ; FUN_0059a0f0 */

void __thiscall
FUN_0059a0f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a0540(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4457 ; VA 0x0059a110 ; FUN_0059a110 */

void __thiscall
FUN_0059a110(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a06a0(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4458 ; VA 0x0059a130 ; FUN_0059a130 */

void __thiscall
FUN_0059a130(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a0840(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4459 ; VA 0x0059a150 ; FUN_0059a150 */

void __thiscall
FUN_0059a150(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a09e0(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4460 ; VA 0x0059a170 ; FUN_0059a170 */

void __thiscall
FUN_0059a170(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a0b10(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4461 ; VA 0x0059a190 ; FUN_0059a190 */

void __thiscall
FUN_0059a190(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a0cb0(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4462 ; VA 0x0059a1b0 ; FUN_0059a1b0 */

void __thiscall
FUN_0059a1b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a0de0(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4463 ; VA 0x0059a1d0 ; FUN_0059a1d0 */

void __thiscall
FUN_0059a1d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a0f80(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4464 ; VA 0x0059a1f0 ; FUN_0059a1f0 */

void __thiscall
FUN_0059a1f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a10b0(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4465 ; VA 0x0059a210 ; FUN_0059a210 */

void __thiscall
FUN_0059a210(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a1230(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4466 ; VA 0x0059a230 ; FUN_0059a230 */

void __thiscall
FUN_0059a230(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a1400(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4467 ; VA 0x0059a250 ; FUN_0059a250 */

void __thiscall
FUN_0059a250(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a15d0(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4468 ; VA 0x0059a270 ; FUN_0059a270 */

void __thiscall
FUN_0059a270(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a1770(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4469 ; VA 0x0059a290 ; FUN_0059a290 */

void __thiscall
FUN_0059a290(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a18d0(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4470 ; VA 0x0059a2b0 ; FUN_0059a2b0 */

void __thiscall
FUN_0059a2b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a1ab0(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4471 ; VA 0x0059a2d0 ; FUN_0059a2d0 */

void __thiscall
FUN_0059a2d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a1c50(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4472 ; VA 0x0059a2f0 ; FUN_0059a2f0 */

void __thiscall
FUN_0059a2f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a1da0(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4473 ; VA 0x0059a310 ; FUN_0059a310 */

void __thiscall
FUN_0059a310(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a1ef0(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4474 ; VA 0x0059a330 ; FUN_0059a330 */

void __thiscall
FUN_0059a330(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a2280(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4475 ; VA 0x0059a350 ; FUN_0059a350 */

void __thiscall
FUN_0059a350(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a2490(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4476 ; VA 0x0059a370 ; FUN_0059a370 */

void __thiscall
FUN_0059a370(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005a26a0(param_2,param_3,param_1,param_4);
  return;
}



/* FUNCTION 4477 ; VA 0x0059a390 ; FUN_0059a390 */

int * FUN_0059a390(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x20,0x10,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0x20,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(0x10);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__BatchJob::vftable;
        puVar2[1] = 0;
        puVar2[2] = 0;
        puVar2[3] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[3] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4478 ; VA 0x0059a4b0 ; FUN_0059a4b0 */

int * FUN_0059a4b0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x22,0x10,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0x22,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(0x10);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__BatchJobEx::vftable;
        puVar2[1] = 0;
        puVar2[2] = 0;
        puVar2[3] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[3] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4479 ; VA 0x0059a5d0 ; FUN_0059a5d0 */

int * FUN_0059a5d0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x23,0xc,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0x23,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(0xc);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__BatchJobExResponse::vftable;
        puVar2[1] = 0;
        puVar2[2] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[2] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4480 ; VA 0x0059a6f0 ; FUN_0059a6f0 */

undefined4 * FUN_0059a6f0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if ((iVar1 == 0) &&
     ((param_3 != (undefined4 *)0x0 ||
      (param_3 = (undefined4 *)FUN_005b7fc0(param_1,4), param_3 != (undefined4 *)0x0)))) {
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
      FUN_005bb7f0(param_1);
      piVar2 = (int *)FUN_005a50c0(param_1,0xffffffff,param_1 + 0x144b4,param_1 + 0x148b4,0);
      *param_3 = piVar2;
      if (piVar2 == (int *)0x0) {
        return (undefined4 *)0x0;
      }
      (**(code **)(*piVar2 + 4))(param_1);
      iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
    }
    else {
      param_3 = (undefined4 *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x21,0x14,0);
      if (*(short *)(param_1 + 0x309a) == 0) {
        return param_3;
      }
      iVar1 = FUN_005b3cc0(param_1,param_2);
    }
    if (iVar1 == 0) {
      return param_3;
    }
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 4481 ; VA 0x0059a7c0 ; FUN_0059a7c0 */

int * FUN_0059a7c0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x2c,8,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0x2c,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(8);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__CloseAllJobs::vftable;
        puVar2[1] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[1] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4482 ; VA 0x0059a8d0 ; FUN_0059a8d0 */

int * FUN_0059a8d0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x2d,0xc,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0x2d,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(0xc);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__CloseAllJobsResponse::vftable;
        puVar2[1] = 0;
        puVar2[2] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[2] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4483 ; VA 0x0059a9f0 ; FUN_0059a9f0 */

int * FUN_0059a9f0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x2a,8,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0x2a,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(8);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__CloseExpiredJobs::vftable;
        puVar2[1] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[1] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4484 ; VA 0x0059ab00 ; FUN_0059ab00 */

int * FUN_0059ab00(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x2b,0xc,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0x2b,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(0xc);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__CloseExpiredJobsResponse::vftable;
        puVar2[1] = 0;
        puVar2[2] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[2] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4485 ; VA 0x0059ac20 ; FUN_0059ac20 */

undefined4 * FUN_0059ac20(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if ((iVar1 == 0) &&
     ((param_3 != (undefined4 *)0x0 ||
      (param_3 = (undefined4 *)FUN_005b7fc0(param_1,4), param_3 != (undefined4 *)0x0)))) {
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
      FUN_005bb7f0(param_1);
      piVar2 = (int *)FUN_005a5760(param_1,0xffffffff,param_1 + 0x144b4,param_1 + 0x148b4,0);
      *param_3 = piVar2;
      if (piVar2 == (int *)0x0) {
        return (undefined4 *)0x0;
      }
      (**(code **)(*piVar2 + 4))(param_1);
      iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
    }
    else {
      param_3 = (undefined4 *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x1e,0x20,0);
      if (*(short *)(param_1 + 0x309a) == 0) {
        return param_3;
      }
      iVar1 = FUN_005b3cc0(param_1,param_2);
    }
    if (iVar1 == 0) {
      return param_3;
    }
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 4486 ; VA 0x0059acf0 ; FUN_0059acf0 */

int * FUN_0059acf0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x1f,8,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0x1f,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(8);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__CloseJobResponse::vftable;
        puVar2[1] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[1] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4487 ; VA 0x0059ae00 ; FUN_0059ae00 */

int * FUN_0059ae00(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x2e,0x10,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0x2e,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(0x10);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__Diag::vftable;
        puVar2[1] = 0;
        puVar2[2] = 0;
        puVar2[3] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[3] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4488 ; VA 0x0059af20 ; FUN_0059af20 */

int * FUN_0059af20(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x30,0x10,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0x30,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(0x10);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__DiagEx::vftable;
        puVar2[1] = 0;
        puVar2[2] = 0;
        puVar2[3] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[3] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4489 ; VA 0x0059b040 ; FUN_0059b040 */

int * FUN_0059b040(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x31,0xc,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0x31,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(0xc);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__DiagExResponse::vftable;
        puVar2[1] = 0;
        puVar2[2] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[2] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4490 ; VA 0x0059b160 ; FUN_0059b160 */

undefined4 * FUN_0059b160(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if ((iVar1 == 0) &&
     ((param_3 != (undefined4 *)0x0 ||
      (param_3 = (undefined4 *)FUN_005b7fc0(param_1,4), param_3 != (undefined4 *)0x0)))) {
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
      FUN_005bb7f0(param_1);
      piVar2 = (int *)FUN_005a5e00(param_1,0xffffffff,param_1 + 0x144b4,param_1 + 0x148b4,0);
      *param_3 = piVar2;
      if (piVar2 == (int *)0x0) {
        return (undefined4 *)0x0;
      }
      (**(code **)(*piVar2 + 4))(param_1);
      iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
    }
    else {
      param_3 = (undefined4 *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x2f,0x14,0);
      if (*(short *)(param_1 + 0x309a) == 0) {
        return param_3;
      }
      iVar1 = FUN_005b3cc0(param_1,param_2);
    }
    if (iVar1 == 0) {
      return param_3;
    }
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 4491 ; VA 0x0059b230 ; FUN_0059b230 */

undefined4 * FUN_0059b230(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if ((iVar1 == 0) &&
     ((param_3 != (undefined4 *)0x0 ||
      (param_3 = (undefined4 *)FUN_005b7fc0(param_1,4), param_3 != (undefined4 *)0x0)))) {
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
      FUN_005bb7f0(param_1);
      piVar2 = (int *)FUN_005a5f60(param_1,0xffffffff,param_1 + 0x144b4,param_1 + 0x148b4,0);
      *param_3 = piVar2;
      if (piVar2 == (int *)0x0) {
        return (undefined4 *)0x0;
      }
      (**(code **)(*piVar2 + 4))(param_1);
      iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
    }
    else {
      param_3 = (undefined4 *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x1a,0x24,0);
      if (*(short *)(param_1 + 0x309a) == 0) {
        return param_3;
      }
      iVar1 = FUN_005b3cc0(param_1,param_2);
    }
    if (iVar1 == 0) {
      return param_3;
    }
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 4492 ; VA 0x0059b300 ; FUN_0059b300 */

undefined4 * FUN_0059b300(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if ((iVar1 == 0) &&
     ((param_3 != (undefined4 *)0x0 ||
      (param_3 = (undefined4 *)FUN_005b7fc0(param_1,4), param_3 != (undefined4 *)0x0)))) {
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
      FUN_005bb7f0(param_1);
      piVar2 = (int *)FUN_005a60c0(param_1,0xffffffff,param_1 + 0x144b4,param_1 + 0x148b4,0);
      *param_3 = piVar2;
      if (piVar2 == (int *)0x0) {
        return (undefined4 *)0x0;
      }
      (**(code **)(*piVar2 + 4))(param_1);
      iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
    }
    else {
      param_3 = (undefined4 *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x1c,0x24,0);
      if (*(short *)(param_1 + 0x309a) == 0) {
        return param_3;
      }
      iVar1 = FUN_005b3cc0(param_1,param_2);
    }
    if (iVar1 == 0) {
      return param_3;
    }
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 4493 ; VA 0x0059b3d0 ; FUN_0059b3d0 */

int * FUN_0059b3d0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x1d,0xc,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0x1d,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(0xc);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__ExecuteExResponse::vftable;
        puVar2[1] = 0;
        puVar2[2] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[2] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4494 ; VA 0x0059b4f0 ; FUN_0059b4f0 */

undefined4 * FUN_0059b4f0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if ((iVar1 == 0) &&
     ((param_3 != (undefined4 *)0x0 ||
      (param_3 = (undefined4 *)FUN_005b7fc0(param_1,4), param_3 != (undefined4 *)0x0)))) {
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
      FUN_005bb7f0(param_1);
      piVar2 = (int *)FUN_005a6370(param_1,0xffffffff,param_1 + 0x144b4,param_1 + 0x148b4,0);
      *param_3 = piVar2;
      if (piVar2 == (int *)0x0) {
        return (undefined4 *)0x0;
      }
      (**(code **)(*piVar2 + 4))(param_1);
      iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
    }
    else {
      param_3 = (undefined4 *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x1b,0x14,0);
      if (*(short *)(param_1 + 0x309a) == 0) {
        return param_3;
      }
      iVar1 = FUN_005b3cc0(param_1,param_2);
    }
    if (iVar1 == 0) {
      return param_3;
    }
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 4495 ; VA 0x0059b5c0 ; FUN_0059b5c0 */

int * FUN_0059b5c0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x26,8,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0x26,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(8);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__GetAllJobs::vftable;
        puVar2[1] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[1] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4496 ; VA 0x0059b6d0 ; FUN_0059b6d0 */

int * FUN_0059b6d0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x28,8,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0x28,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(8);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__GetAllJobsEx::vftable;
        puVar2[1] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[1] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4497 ; VA 0x0059b7e0 ; FUN_0059b7e0 */

int * FUN_0059b7e0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x29,0xc,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0x29,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(0xc);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__GetAllJobsExResponse::vftable;
        puVar2[1] = 0;
        puVar2[2] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[2] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4498 ; VA 0x0059b900 ; FUN_0059b900 */

undefined4 * FUN_0059b900(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if ((iVar1 == 0) &&
     ((param_3 != (undefined4 *)0x0 ||
      (param_3 = (undefined4 *)FUN_005b7fc0(param_1,4), param_3 != (undefined4 *)0x0)))) {
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
      FUN_005bb7f0(param_1);
      piVar2 = (int *)FUN_005a68c0(param_1,0xffffffff,param_1 + 0x144b4,param_1 + 0x148b4,0);
      *param_3 = piVar2;
      if (piVar2 == (int *)0x0) {
        return (undefined4 *)0x0;
      }
      (**(code **)(*piVar2 + 4))(param_1);
      iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
    }
    else {
      param_3 = (undefined4 *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x27,0x14,0);
      if (*(short *)(param_1 + 0x309a) == 0) {
        return param_3;
      }
      iVar1 = FUN_005b3cc0(param_1,param_2);
    }
    if (iVar1 == 0) {
      return param_3;
    }
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 4499 ; VA 0x0059b9d0 ; FUN_0059b9d0 */

undefined4 * FUN_0059b9d0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if ((iVar1 == 0) &&
     ((param_3 != (undefined4 *)0x0 ||
      (param_3 = (undefined4 *)FUN_005b7fc0(param_1,4), param_3 != (undefined4 *)0x0)))) {
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
      FUN_005bb7f0(param_1);
      piVar2 = (int *)FUN_005a6a20(param_1,0xffffffff,param_1 + 0x144b4,param_1 + 0x148b4,0);
      *param_3 = piVar2;
      if (piVar2 == (int *)0x0) {
        return (undefined4 *)0x0;
      }
      (**(code **)(*piVar2 + 4))(param_1);
      iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
    }
    else {
      param_3 = (undefined4 *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x24,0x20,0);
      if (*(short *)(param_1 + 0x309a) == 0) {
        return param_3;
      }
      iVar1 = FUN_005b3cc0(param_1,param_2);
    }
    if (iVar1 == 0) {
      return param_3;
    }
  }
  return (undefined4 *)0x0;
}


