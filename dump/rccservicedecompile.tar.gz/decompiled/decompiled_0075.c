/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 18750 ; VA 0x009bf650 ; FUN_009bf650 */

void __fastcall FUN_009bf650(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  int *piVar6;
  uint uVar7;
  int *piVar8;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  uint uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d52a0;
  pvStack_10 = ExceptionList;
  if (((param_1 != 0) && (iStack_14 = *(int *)(param_1 + 0x34), iStack_14 != 0)) &&
     (iVar2 = *(int *)(iStack_14 + 0xc), ExceptionList = &pvStack_10, iVar1 = FUN_00b63e30(),
     (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
     (uint)*(ushort *)(iVar1 + 0x1da))) {
    piVar8 = (int *)0x0;
    piStack_30 = (int *)0x0;
    piStack_2c = (int *)0x0;
    piStack_18 = (int *)0x0;
    piStack_28 = (int *)0x0;
    uVar7 = 0;
    iStack_8 = 0;
    uStack_1c = 0;
    iVar2 = FUN_005d6c30();
    piVar6 = (int *)0x0;
    piVar5 = (int *)0x0;
    if (iVar2 != 0) {
      do {
        iVar2 = *(int *)(**(int **)(iStack_14 + 0x2c) + uVar7 * 8);
        if ((iVar2 == 0) ||
           (iVar1 = *(int *)(iVar2 + 0xc), iVar3 = FUN_00c8dce0(),
           (uint)*(ushort *)(iVar3 + 0x1da) <
           (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
          iVar2 = 0;
        }
        FUN_0060dcd0(&iStack_24,iVar2);
        iStack_8._0_1_ = 1;
        if (iStack_24 != 0) {
          if (piStack_18 == piVar8) {
            FUN_005c1970(piVar8,&iStack_24);
            piStack_18 = piStack_28;
            piVar8 = piStack_2c;
          }
          else {
            *piVar8 = 0;
            piVar8[1] = 0;
            if (piStack_20 != (int *)0x0) {
              LOCK();
              piStack_20[1] = piStack_20[1] + 1;
              UNLOCK();
            }
            *piVar8 = iStack_24;
            piVar8[1] = (int)piStack_20;
            piStack_2c = piVar8 + 2;
            piVar8 = piStack_2c;
          }
        }
        piVar6 = piStack_20;
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        if (piStack_20 != (int *)0x0) {
          LOCK();
          iVar2 = piStack_20[1] + -1;
          piStack_20[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_20)();
            LOCK();
            piVar5 = piVar6 + 2;
            iVar2 = *piVar5 + -1;
            *piVar5 = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
        uVar7 = uStack_1c + 1;
        uStack_1c = uVar7;
        uVar4 = FUN_005d6c30();
        piVar6 = piStack_30;
        piVar5 = piStack_30;
      } while (uVar7 < uVar4);
    }
    for (; piVar6 != piVar8; piVar6 = piVar6 + 2) {
      (**(code **)(*(int *)*piVar6 + 0x2c))();
    }
    if (piVar5 != (int *)0x0) {
      FUN_005596d0(piVar5,piVar8,&piStack_30);
      uVar7 = (int)piStack_18 - (int)piVar5 & 0xfffffff8;
      piVar6 = piVar5;
      if (0xfff < uVar7) {
        piVar6 = (int *)piVar5[-1];
        uVar7 = uVar7 + 0x23;
        if (0x1f < (uint)((int)piVar5 + (-4 - (int)piVar6))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(piVar6,uVar7);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18751 ; VA 0x009bf820 ; FUN_009bf820 */

undefined FUN_009bf820(int param_1)

{
  int iVar1;
  uint uVar2;
  undefined uVar3;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009b6f20();
  if (iVar1 != 0) {
    iVar1 = FUN_008a1240(&param_1);
    if (iVar1 != 0) {
      FUN_008a65e0(0,0);
      uVar3 = 1;
      goto LAB_009bf869;
    }
  }
  uVar3 = 0;
LAB_009bf869:
  if (0xf < in_stack_00000018) {
    uVar2 = in_stack_00000018 + 1;
    iVar1 = param_1;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_1 + -4);
      uVar2 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 18752 ; VA 0x009bf8c0 ; FUN_009bf8c0 */

void FUN_009bf8c0(undefined4 param_1)

{
  undefined auStack_24 [20];
  undefined4 uStack_10;
  
  uStack_10 = 0x9bf8cc;
  FUN_009c68d0();
  FUN_009cb090(auStack_24,param_1);
  FUN_009bf820();
  return;
}



/* FUNCTION 18753 ; VA 0x009bf8f0 ; FUN_009bf8f0 */

int __thiscall FUN_009bf8f0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  char cVar4;
  undefined **ppuVar5;
  int iVar6;
  undefined **ppuVar7;
  undefined4 *puVar8;
  undefined8 uVar9;
  undefined auStack_64 [4];
  undefined *puStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined auStack_4c [4];
  undefined *puStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined auStack_34 [4];
  undefined *puStack_30;
  int iStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d52d0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009b49f0(auStack_1c,param_1);
  uStack_8 = 0;
  auStack_64[0] = 0;
  uStack_14 = 0xb;
  ppuVar5 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_14);
  uVar3 = param_4;
  ppuVar7 = ppuVar5 + -1;
  if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar5;
  }
  puStack_60 = *ppuVar7;
  uStack_5c = 0;
  uStack_58 = 0x3f800000;
  uStack_54 = 0;
  uStack_50 = 0;
  uStack_8._0_1_ = 1;
  FUN_00e2e7d0(auStack_1c,param_4,auStack_64);
  auStack_34[0] = 0;
  uStack_14 = 0xb;
  ppuVar5 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_14);
  ppuVar7 = ppuVar5 + -1;
  if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar5;
  }
  puStack_30 = *ppuVar7;
  iStack_2c = 0;
  uStack_28 = 0x3f800000;
  uStack_24 = 0;
  iStack_20 = 0;
  uStack_8._0_1_ = 2;
  FUN_009aa9c0(param_2,param_3,auStack_64,*(int *)(param_1 + 0x228) != 0,auStack_34,uVar3);
  if (iStack_2c != 0) {
    FUN_0086f2f0(2,"Humanoid::ApplyDescription() Some requested assets were not available");
    auStack_4c[0] = 0;
    param_3 = 0xb;
    ppuVar5 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_3);
    ppuVar7 = ppuVar5 + -1;
    if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar7 = ppuVar5;
    }
    puStack_48 = *ppuVar7;
    uStack_44 = 0;
    uStack_40 = 0x3f800000;
    uStack_3c = 0;
    uStack_38 = 0;
    uStack_8._0_1_ = 3;
    FUN_00e30f30(auStack_4c);
    if (iStack_2c == 0) {
      puVar8 = (undefined4 *)0x0;
    }
    else {
      puVar8 = *(undefined4 **)(iStack_20 + (int)puStack_30 * 4);
    }
    for (; puVar8 != (undefined4 *)0x0; puVar8 = (undefined4 *)*puVar8) {
      iVar6 = FUN_009a51d0(puVar8 + 2);
      uVar3 = *(undefined4 *)(iVar6 + 8);
      cVar4 = FUN_00e31330(uVar3);
      if (cVar4 == '\0') {
        uVar9 = FUN_005565e0();
        FUN_00e33b40(uVar3,uVar9);
      }
      else {
        FUN_00e31760(uVar3,puVar8[2],puVar8[3]);
      }
    }
    FUN_0056d250();
  }
  FUN_00612320();
  iVar6 = FUN_00612320();
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 18754 ; VA 0x009bfb20 ; FUN_009bfb20 */

void __thiscall FUN_009bfb20(int param_1,undefined4 *param_2)

{
  int *piVar1;
  float fVar2;
  undefined4 *puVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined auStack_90 [48];
  undefined auStack_60 [48];
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  float fStack_1c;
  int *piStack_18;
  float fStack_14;
  int iStack_10;
  int *piStack_c;
  int *piStack_8;
  
  puVar3 = param_2;
  if (*(int *)(param_1 + 0x5e0) != 0) {
    FUN_00dc4520(param_2);
  }
  if ((DAT_01edfb02 != '\0') && (*(int *)(param_1 + 0x5f0) != 0)) {
    FUN_00aedf20(param_2);
  }
  param_2._3_1_ = '\x01';
  if ((DAT_01d64ad8 != '\0') && ((int *)(param_1 + -0x118) != (int *)0x0)) {
    piStack_c = *(int **)(param_1 + -0xe4);
    piVar4 = (int *)(param_1 + -0x118);
    if ((piStack_c != (int *)0x0) && (piVar4 = piStack_c, piStack_c[0xd] != 0)) {
      piVar4 = (int *)FUN_005c8ac0();
    }
    piStack_c = piVar4;
    if ((piStack_c != (int *)0x0) &&
       (iVar8 = piStack_c[3], iVar5 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
       (uint)*(ushort *)(iVar5 + 0x1da))) {
      FUN_005789c0(&DAT_01ead5f8,&LAB_006340d0);
      uVar6 = FUN_006352d0();
      piStack_c = (int *)FUN_008aa140(uVar6);
      if (*piStack_c == 0) {
        uVar6 = FUN_00b8c410();
        piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar6);
        iVar8 = *piVar4;
        iVar5 = piVar4[1];
        *piVar4 = 0;
        piVar4[1] = 0;
        *piStack_c = iVar8;
        piStack_8 = (int *)piStack_c[1];
        piStack_c[1] = iVar5;
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar8 = piStack_8[1] + -1;
          piStack_8[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            iVar8 = piStack_8[2] + -1;
            piStack_8[2] = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
        piStack_8 = piStack_20;
        if (piStack_20 != (int *)0x0) {
          LOCK();
          iVar8 = piStack_20[1] + -1;
          piStack_20[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piStack_20)();
            LOCK();
            iVar8 = piStack_8[2] + -1;
            piStack_8[2] = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      if (*piStack_c != 0) {
        param_2._3_1_ = *(char *)(*piStack_c + 0xe6);
        goto LAB_009bfc92;
      }
    }
    param_2._3_1_ = '\x01';
  }
LAB_009bfc92:
  if ((*(char *)(param_1 + 0x10b) < '\x01') && (param_2._3_1_ != '\0')) {
    piStack_20 = (int *)(param_1 + -0x118);
    if (*(int *)(param_1 + 0x110) == 0) {
      iVar8 = *(int *)(param_1 + 0x230);
    }
    else {
      iVar8 = *(int *)(param_1 + 0x260);
    }
    if (iVar8 != 0) {
      piVar4 = (int *)(param_1 + 0x530);
      if (*piVar4 == 0) {
        piStack_8 = (int *)FUN_01674e20(0x80);
        if (piStack_8 == (undefined4 *)0x0) {
          puVar7 = (undefined4 *)0x0;
        }
        else {
          *piStack_8 = 0x3f800000;
          piStack_8[1] = 0;
          piStack_8[2] = 0;
          piStack_8[3] = 0;
          piStack_8[4] = 0x3f800000;
          piStack_8[5] = 0;
          piStack_8[6] = 0;
          piStack_8[7] = 0;
          piStack_8[8] = 0x3f800000;
          piStack_8[9] = 0;
          piStack_8[10] = 0;
          piStack_8[0xb] = 0;
          piStack_8[0xc] = 0;
          piStack_8[0xd] = 0;
          piStack_8[0xe] = 0;
          piStack_8[0xf] = 0;
          piStack_8[0x10] = 0;
          piStack_8[0x11] = 0;
          piStack_8[0x12] = 0;
          piStack_8[0x13] = 0;
          *(undefined2 *)(piStack_8 + 0x14) = 0;
          *(undefined *)((int)piStack_8 + 0x52) = 0;
          piStack_8[0x15] = 0;
          piStack_8[0x16] = 0;
          *(undefined *)((int)piStack_8 + 0x5d) = 1;
          piStack_8[0x18] = 0;
          piStack_8[0x19] = 0;
          piStack_8[0x1a] = 0;
          piStack_8[0x1b] = 0;
          piStack_8[0x1c] = 0;
          piStack_8[0x1d] = 0;
          piStack_8[0x1e] = 0;
          piStack_8[0x1f] = 0;
          puVar7 = piStack_8;
        }
        iStack_10 = 0;
        piStack_c = (int *)0x0;
        FUN_0099c9f0(puVar7,iVar8);
        *piVar4 = iStack_10;
        piStack_8 = *(int **)(param_1 + 0x534);
        *(int **)(param_1 + 0x534) = piStack_c;
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar8 = piStack_8[1] + -1;
          piStack_8[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar1 = piStack_8 + 2;
            iVar8 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar8 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      *(undefined4 *)(*piVar4 + 0x4c) = 0;
      *(undefined *)(*piVar4 + 0x50) = 1;
      uVar6 = (**(code **)*puVar3)();
      if (*(char *)(puVar3 + 5) == '\0') {
        iVar8 = FUN_00b077e0();
        fStack_14 = *(float *)(iVar8 + 0x2c);
        piStack_18 = (int *)((ulonglong)*(undefined8 *)(iVar8 + 0x24) >> 0x20);
        fStack_1c = (float)*(undefined8 *)(iVar8 + 0x24);
        _fStack_1c = CONCAT44((float)piStack_18 + DAT_018df57c,fStack_1c);
        FUN_009b3f30(auStack_60,&fStack_1c,uVar6);
      }
      else {
        iVar8 = FUN_00b077e0();
        fStack_14 = *(float *)(iVar8 + 0x2c);
        piStack_18 = (int *)((ulonglong)*(undefined8 *)(iVar8 + 0x24) >> 0x20);
        piStack_8 = (int *)((float)piStack_18 + DAT_018df57c);
        fStack_1c = (float)*(undefined8 *)(iVar8 + 0x24);
        _fStack_1c = CONCAT44(piStack_8,fStack_1c);
        iVar8 = FUN_00d226b0(auStack_90);
        fVar2 = *(float *)(iVar8 + 0x24);
        piStack_c = *(int **)(iVar8 + 0x2c);
        FUN_00709da0(&fStack_1c);
        fStack_30 = fStack_1c - (fVar2 - fStack_1c);
        fStack_2c = (float)piStack_8 - 0.0;
        fStack_28 = fStack_14 - ((float)piStack_c - fStack_14);
        FUN_01163c40(&fStack_30);
        FUN_01161050(0x3d638e39);
      }
      FUN_01159c70(auStack_60);
      FUN_0114e3d0(piVar4);
      FUN_009bff70(puVar3,uVar6);
      FUN_0114e5f0();
      FUN_0114e5a0(piVar4);
    }
  }
  return;
}



/* FUNCTION 18755 ; VA 0x009bff70 ; FUN_009bff70 */

void __thiscall FUN_009bff70(int *param_1,int param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  float *pfVar7;
  undefined8 *puVar8;
  float10 fVar9;
  float fVar10;
  double dVar11;
  float fVar12;
  float fVar13;
  undefined8 uVar14;
  undefined *puVar15;
  undefined auStack_a8 [48];
  undefined auStack_78 [12];
  undefined auStack_6c [12];
  undefined auStack_60 [8];
  float fStack_58;
  undefined8 uStack_54;
  int *piStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  undefined8 uStack_30;
  float fStack_28;
  float fStack_24;
  int *piStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d52e8;
  pvStack_10 = ExceptionList;
  if (param_1[0x96] == 2) {
    return;
  }
  if (param_1[0x8a] == 0) {
    iVar3 = param_1[0xd2];
  }
  else {
    iVar3 = param_1[0xde];
  }
  if (iVar3 == 0) {
    return;
  }
  if (DAT_018fde78 < *(float *)(iVar3 + 0xcc)) {
    return;
  }
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00b077e0();
  fStack_40 = (float)((ulonglong)*(undefined8 *)(iVar3 + 0x24) >> 0x20);
  fStack_3c = *(float *)(iVar3 + 0x2c);
  fStack_40 = fStack_40 + DAT_018df57c;
  fStack_44 = (float)*(undefined8 *)(iVar3 + 0x24);
  iVar3 = FUN_00d226b0(auStack_a8);
  fVar13 = *(float *)(iVar3 + 0x28) - fStack_40;
  fVar12 = *(float *)(iVar3 + 0x24) - fStack_44;
  fVar10 = *(float *)(iVar3 + 0x2c) - fStack_3c;
  dVar11 = (double)(fVar13 * fVar13 + fVar12 * fVar12 + fVar10 * fVar10);
  FUN_017267a0();
  fStack_48 = (float)dVar11;
  iVar3 = FUN_0097bf90(param_1);
  if (iVar3 == 0) {
    iVar3 = 0;
  }
  else {
    iVar3 = FUN_009ba890(iVar3);
  }
  piStack_20 = (int *)param_1[0xd];
  piVar4 = param_1;
  if ((piStack_20 != (int *)0x0) && (piVar4 = piStack_20, piStack_20[0xd] != 0)) {
    piVar4 = (int *)FUN_005c8ac0();
  }
  piStack_20 = piVar4;
  piStack_18 = piStack_20;
  if (piStack_20 == (int *)0x0) {
LAB_009c016b:
    fStack_24 = 0.0;
  }
  else {
    iVar1 = piStack_20[3];
    iVar5 = FUN_008a8c30();
    piStack_18 = (int *)(uint)*(ushort *)(iVar5 + 0x1da);
    if (piStack_18 < (int *)((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)))
    goto LAB_009c016b;
    FUN_005789c0(&DAT_01eadd5c,&LAB_00670d60);
    uVar6 = FUN_006763b0();
    piStack_18 = (int *)FUN_008aa140(uVar6);
    if (*piStack_18 == 0) {
      uVar6 = FUN_00bdf940();
      piVar4 = (int *)FUN_008a9ba0((int)&uStack_54 + 4,uVar6);
      iVar1 = *piVar4;
      iVar5 = piVar4[1];
      *piVar4 = 0;
      piVar4[1] = 0;
      *piStack_18 = iVar1;
      piVar4 = (int *)piStack_18[1];
      piStack_18[1] = iVar5;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar1 = piVar4[1] + -1;
        piVar4[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar1 = piVar4[2] + -1;
          piVar4[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      if (piStack_4c != (int *)0x0) {
        LOCK();
        iVar1 = piStack_4c[1] + -1;
        piStack_4c[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_4c)();
          LOCK();
          piVar4 = piStack_4c + 2;
          iVar1 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_4c + 4))();
          }
        }
      }
    }
    fStack_24 = (float)*piStack_18;
  }
  piStack_18 = (int *)((uint)piStack_18 & 0xffffff00);
  fStack_38 = fStack_48;
  fStack_28 = DAT_018ce320;
  piStack_20 = (int *)DAT_018ce320;
  if (param_1[0x96] == 1) {
    fStack_28 = (float)param_1[0x98];
    piStack_20 = (int *)param_1[0x99];
LAB_009c01ce:
    if (iVar3 != 0) {
      if (*(int *)(iVar3 + 0x254) == 2) {
        piStack_18._1_3_ = (undefined3)((uint)piStack_18 >> 8);
        piStack_18 = (int *)CONCAT31(piStack_18._1_3_,1);
      }
      else if (*(int *)(iVar3 + 0x254) == 1) {
        if (fStack_24 != 0.0) {
          uStack_30._4_4_ = (float *)FUN_00bdfdb0(auStack_78,param_1);
          pfVar7 = (float *)FUN_00bdfdb0(auStack_6c,iVar3);
          if ((((NAN(*uStack_30._4_4_) || NAN(*pfVar7)) == (*uStack_30._4_4_ == *pfVar7)) ||
              ((NAN(uStack_30._4_4_[1]) || NAN(pfVar7[1])) == (uStack_30._4_4_[1] == pfVar7[1]))) ||
             ((NAN(uStack_30._4_4_[2]) || NAN(pfVar7[2])) == (uStack_30._4_4_[2] == pfVar7[2]))) {
            piStack_18 = (int *)CONCAT31(piStack_18._1_3_,1);
            goto LAB_009c024a;
          }
        }
        piStack_18 = (int *)((uint)piStack_18 & 0xffffff00);
      }
LAB_009c024a:
      if (*(int *)(iVar3 + 0x228) == 0) {
        iVar3 = *(int *)(iVar3 + 0x348);
      }
      else {
        iVar3 = *(int *)(iVar3 + 0x378);
      }
      if (iVar3 != 0) {
        iVar3 = FUN_00b077e0();
        uStack_30._4_4_ = *(float **)(iVar3 + 0x2c);
        fStack_34 = (float)*(undefined8 *)(iVar3 + 0x24);
        uStack_30._0_4_ = (float)((ulonglong)*(undefined8 *)(iVar3 + 0x24) >> 0x20);
        dVar11 = (double)(((float)uStack_30 - fStack_40) * ((float)uStack_30 - fStack_40) +
                          (fStack_34 - fStack_44) * (fStack_34 - fStack_44) +
                         ((float)uStack_30._4_4_ - fStack_3c) * ((float)uStack_30._4_4_ - fStack_3c)
                         );
        FUN_017267a0();
        fStack_38 = (float)dVar11;
      }
      goto LAB_009c02de;
    }
  }
  else if (iVar3 != 0) {
    fStack_28 = *(float *)(iVar3 + 0x260);
    piStack_20 = *(int **)(iVar3 + 0x264);
    goto LAB_009c01ce;
  }
  piStack_18 = (int *)(uint)(param_1[0x95] == 2);
LAB_009c02de:
  if ((fStack_38 < fStack_28) || (fStack_38 < (float)piStack_20)) {
    uStack_30 = (double)CONCAT44(uStack_30._4_4_,(float)uStack_30);
    if (((char)piStack_18 != '\0') &&
       (uStack_30 = (double)CONCAT44(uStack_30._4_4_,(float)uStack_30), param_1[0x1bd] != 0)) {
      cStack_11 = '\0';
      iVar3 = FUN_008f7870(param_1);
      if (iVar3 != 0) {
        fVar9 = (float10)FUN_008f7ed0();
        uStack_30 = (double)fVar9;
        cVar2 = FUN_00bbec00(uStack_30,param_1,&cStack_11);
        if (cVar2 == '\0') {
          puVar15 = auStack_1c;
          piVar4 = param_1;
          FUN_0060dcd0(puVar15,param_1);
          uStack_8 = 0;
          FUN_005587b0();
          FUN_00bc0070(puVar15,piVar4);
          uStack_8 = 0xffffffff;
          FUN_00550b30();
        }
      }
      if (cStack_11 == '\0') {
        ExceptionList = pvStack_10;
        return;
      }
    }
    if (param_1[99] == 0) {
      piVar4 = *(int **)(param_1[0xd] + 0x28);
    }
    else {
      piVar4 = param_1 + 0x5f;
    }
    cVar2 = FUN_00684460(param_1 + 0x9e,piVar4);
    if (cVar2 != '\0') {
      FUN_00551230(piVar4);
      cVar2 = FUN_00fa0fb0();
      *(bool *)(param_1 + 0xa4) = cVar2 == '\0';
    }
    if (fStack_24 == 0.0) {
      puVar8 = (undefined8 *)FUN_0115ee70();
      uStack_30._4_4_ = (float *)*(undefined4 *)(puVar8 + 1);
      pfVar7 = &fStack_34;
      fStack_34 = (float)*puVar8;
      uStack_30._0_4_ = (float)((ulonglong)*puVar8 >> 0x20);
      uStack_30 = (double)CONCAT44(*(undefined4 *)(puVar8 + 1),(float)uStack_30);
    }
    else {
      pfVar7 = (float *)FUN_00bdfdb0(auStack_6c,param_1);
    }
    uStack_54 = *(undefined8 *)pfVar7;
    piStack_4c = (int *)pfVar7[2];
    fStack_24 = DAT_018ce2f8;
    piStack_18 = (int *)DAT_018ce2f8;
    if ((fStack_28 * DAT_0190193c < fStack_38) &&
       (fStack_24 = (fStack_28 - fStack_38) / (fStack_28 * DAT_018e452c), fStack_24 < 0.0)) {
      fStack_24 = 0.0;
    }
    if (((float)piStack_20 * DAT_0190193c < fStack_38) &&
       (piStack_18 = (int *)(((float)piStack_20 - fStack_38) / ((float)piStack_20 * DAT_018e452c)),
       (float)piStack_18 < 0.0)) {
      piStack_18 = (int *)0x0;
    }
    if (*(char *)(param_2 + 0x14) == '\0') {
      FUN_00d23e50(auStack_60,&fStack_44);
      if ((NAN(fStack_58) || NAN(DAT_018e0028)) != (fStack_58 == DAT_018e0028)) {
        ExceptionList = pvStack_10;
        return;
      }
      uVar6 = DAT_01919034;
      if ((DAT_019011dc <= fStack_48) && (uVar6 = DAT_019399c0, fStack_48 < DAT_01901d9c)) {
        uVar6 = DAT_018fabec;
      }
      uVar14 = CONCAT44(&uStack_54,uVar6);
    }
    else {
      uVar14 = CONCAT44(&uStack_54,0x41900000);
    }
    FUN_009c0560(param_2,uVar14,fStack_24,piStack_18);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18756 ; VA 0x009c0560 ; FUN_009c0560 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall
FUN_009c0560(int param_1,undefined4 param_2,float param_3,float *param_4,float param_5,float param_6
            )

{
  char cVar1;
  int iVar2;
  uint *puVar3;
  float *pfVar4;
  uint uVar5;
  float *pfVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  double dVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  undefined4 uStack_150;
  float *pfStack_14c;
  float *pfStack_148;
  float *pfStack_144;
  float *pfStack_140;
  float *pfStack_13c;
  undefined auStack_130 [8];
  float fStack_128;
  float fStack_124;
  float fStack_120;
  float fStack_11c;
  float fStack_118;
  undefined *puStack_114;
  float afStack_110 [5];
  undefined4 uStack_fc;
  float fStack_f8;
  undefined4 uStack_f4;
  float fStack_f0;
  undefined4 uStack_ec;
  float fStack_e8;
  undefined4 uStack_e4;
  float fStack_e0;
  undefined4 uStack_dc;
  float afStack_d8 [7];
  undefined4 uStack_bc;
  float fStack_b8;
  undefined4 uStack_b4;
  float fStack_b0;
  undefined4 uStack_ac;
  float afStack_a8 [3];
  undefined4 uStack_9c;
  float afStack_98 [3];
  undefined4 uStack_8c;
  uint uStack_88;
  uint uStack_84;
  uint uStack_80;
  uint uStack_7c;
  undefined8 uStack_78;
  float fStack_70;
  float fStack_6c;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  float afStack_50 [16];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d530b;
  pvStack_10 = ExceptionList;
  afStack_50[3] = param_3 * DAT_018e3f8c;
  ExceptionList = &pvStack_10;
  if (0.0 < param_5) {
    dVar10 = (double)(param_4[1] * _DAT_01d64ed0 + *param_4 * _DAT_01d64ecc +
                     param_4[2] * _DAT_01d64ed4);
    pfStack_13c = (float *)0x9c05e6;
    ExceptionList = &pvStack_10;
    FUN_01726ab0();
    afStack_50[0xf] = DAT_01d64ec8 * param_5;
    if (((float)dVar10 * _DAT_019399c8 - DAT_018fabe8) / DAT_018ce320 < _DAT_01d64ed8) {
      afStack_50[0xc] = 0.8901961;
      afStack_50[0xd] = 0.8901961;
      afStack_50[0xe] = 0.8901961;
    }
    else {
      afStack_50[0xc] = 0.19215687;
      afStack_50[0xd] = 0.19215687;
      afStack_50[0xe] = 0.19215687;
    }
    afStack_50[10] = 0.0;
    afStack_50[0xb] = -2.0;
    if (*(char *)(param_1 + 0x290) != '\0') {
      pfStack_13c = (float *)0x1;
      pfStack_144 = (float *)(param_1 + 0x278);
      pfStack_148 = (float *)0x9c066f;
      pfStack_140 = (float *)param_1;
      cVar1 = FUN_00fa0fb0();
      *(bool *)(param_1 + 0x290) = cVar1 == '\0';
    }
    uStack_78 = 0xf00000000;
    uStack_88 = uStack_88 & 0xffffff00;
    uStack_8 = 0;
    pfStack_140 = (float *)0x9c069f;
    pfStack_13c = (float *)param_1;
    iVar2 = FUN_009171d0();
    if (iVar2 != 0) {
      if (DAT_01d6fe28 == '\0') {
        pfStack_13c = (float *)auStack_130;
        pfStack_140 = (float *)0x9c06d9;
        puVar3 = (uint *)FUN_00a433e0();
      }
      else {
        FUN_00a433e0(&uStack_150);
        puVar3 = (uint *)FUN_00a42d50(auStack_130);
      }
      if (&uStack_88 != puVar3) {
        pfStack_13c = (float *)0x9c06ec;
        FUN_005507b0();
        uStack_88 = *puVar3;
        uStack_84 = puVar3[1];
        uStack_80 = puVar3[2];
        uStack_7c = puVar3[3];
        uStack_78 = *(undefined8 *)(puVar3 + 4);
        puVar3[4] = 0;
        puVar3[5] = 0xf;
        *(undefined *)puVar3 = 0;
      }
      pfStack_13c = (float *)0x9c071c;
      FUN_005507b0();
    }
    pfStack_13c = (float *)(param_1 + 0x278);
    pfStack_140 = (float *)0x9c0730;
    FUN_00d7fae0();
    pfStack_13c = (float *)afStack_50[0xb];
    pfStack_140 = (float *)afStack_50[10];
    pfStack_144 = (float *)0x9c073d;
    FUN_00d7f8a0();
    pfStack_13c = (float *)param_3;
    pfStack_140 = (float *)0x9c074f;
    FUN_00d7f630();
    pfStack_148 = (float *)*param_4;
    pfStack_144 = (float *)param_4[1];
    pfStack_140 = (float *)param_4[2];
    afStack_50[7] = param_5;
    pfStack_13c = (float *)param_5;
    pfStack_14c = (float *)0x9c078c;
    afStack_50[4] = (float)pfStack_148;
    afStack_50[5] = (float)pfStack_144;
    afStack_50[6] = (float)pfStack_140;
    FUN_00d7f550();
    pfStack_148 = (float *)afStack_50[0xc];
    pfStack_144 = (float *)afStack_50[0xd];
    pfStack_140 = (float *)afStack_50[0xe];
    pfStack_13c = (float *)afStack_50[0xf];
    pfStack_14c = (float *)0x9c079f;
    FUN_00d7f780();
    pfStack_13c = (float *)0x3;
    pfStack_140 = (float *)0x9c07a8;
    FUN_00d7f610();
    pfStack_13c = (float *)0x2;
    pfStack_140 = (float *)0x9c07b1;
    FUN_00d7fbb0();
    pfStack_13c = (float *)0x2;
    pfStack_140 = (float *)0x9c07ba;
    FUN_00d7fbd0();
    pfStack_13c = (float *)&uStack_88;
    pfStack_140 = (float *)0x9c07c8;
    FUN_00d7f6d0();
    pfStack_140 = afStack_50 + 6;
    pfStack_144 = (float *)0x9c07d5;
    pfStack_13c = (float *)(param_1 + 0x400);
    FUN_0114e580();
    uStack_8 = 0xffffffff;
    if (0xf < uStack_78._4_4_) {
      pfStack_13c = (float *)(uStack_78._4_4_ + 1);
      uVar5 = uStack_88;
      if (0xfff < pfStack_13c) {
        uVar5 = *(uint *)(uStack_88 - 4);
        pfStack_13c = (float *)(uStack_78._4_4_ + 0x24);
        if (0x1f < (uStack_88 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          pfStack_13c = (float *)&UNK_009c0e72;
          FUN_017167a3();
        }
      }
      pfStack_144 = (float *)0x9c0810;
      pfStack_140 = (float *)uVar5;
      FUN_01674ea0();
    }
  }
  fVar7 = (float)(**(int **)(param_1 + 0x200) + (int)*(int **)(param_1 + 0x200));
  if ((NAN(fVar7) == (fVar7 == 0.0)) && (0.0 < param_6)) {
    if (*(int *)(param_1 + 0x25c) == 0) {
      puVar3 = *(uint **)(param_1 + 0x1fc);
      if (fVar7 <= (float)(*puVar3 ^ (uint)puVar3)) {
        ExceptionList = pvStack_10;
        return;
      }
    }
    else {
      if (*(int *)(param_1 + 0x25c) != 1) {
        ExceptionList = pvStack_10;
        return;
      }
      puVar3 = *(uint **)(param_1 + 0x1fc);
    }
    fVar7 = (float)(*puVar3 ^ (uint)puVar3) / fVar7;
    afStack_d8[1] = 0.0;
    afStack_d8[3] = 6.0;
    afStack_d8[5] = 1.0;
    uStack_bc = 0x40a00000;
    uStack_b4 = 0x3f800000;
    uStack_ac = 0x40a00000;
    puStack_114 = &DAT_bf800000;
    afStack_110[1] = 0.0;
    afStack_110[3] = 6.0;
    uStack_fc = 0x40e00000;
    uStack_f4 = 0;
    uStack_ec = 0x40c00000;
    uStack_e4 = 0;
    uStack_dc = 0x40c00000;
    fVar8 = 0.0;
    if (0.0 <= fVar7) {
      fVar8 = fVar7;
    }
    fVar7 = DAT_018ce2f8;
    if (fVar8 <= DAT_018ce2f8) {
      fVar7 = fVar8;
    }
    fVar11 = afStack_50[3] * DAT_018f7860;
    afStack_d8[2] = fVar11 + afStack_50[3];
    fVar8 = fVar7 * afStack_50[3] + fVar11;
    afStack_d8[0] = fVar11 + 0.0;
    fStack_b8 = afStack_d8[2];
    afStack_d8[6] = afStack_d8[0];
    fStack_118 = afStack_d8[0];
    afStack_110[0] = afStack_d8[2];
    afStack_d8[4] = fVar11 - DAT_018daf58;
    afStack_110[2] = afStack_d8[0];
    afStack_110[4] = afStack_d8[2];
    fStack_f0 = afStack_d8[0];
    fStack_e8 = afStack_d8[2];
    fStack_b0 = afStack_50[3] + DAT_018daf58 + fVar11;
    fStack_f8 = fVar11 - DAT_018df580;
    fStack_e0 = afStack_50[3] + DAT_018df580 + fVar11;
    if (DAT_018e452c < fVar7) {
      if (fVar7 < DAT_018f994c) {
        fVar12 = 0.0;
        param_3 = 0.0;
        fVar13 = 0.0;
        fVar14 = 0.0;
        iVar2 = 0;
        pfVar6 = &DAT_01d64ee0;
        do {
          fVar9 = (float)(double)CONCAT44((uint)((ulonglong)
                                                 (double)(fVar7 - (float)(&DAT_01d64f00)[iVar2]) >>
                                                0x20) & DAT_018c0da0._4_4_,
                                          SUB84((double)(fVar7 - (float)(&DAT_01d64f00)[iVar2]),0) &
                                          (uint)DAT_018c0da0);
          if (fVar9 <= 0.0) {
            afStack_50[0xc] = (&DAT_01d64edc)[iVar2 * 3];
            afStack_50[0xd] = (&DAT_01d64ee0)[iVar2 * 3];
            afStack_50[0xe] = (&DAT_01d64ee4)[iVar2 * 3];
            goto LAB_009c0b58;
          }
          iVar2 = iVar2 + 1;
          fVar9 = DAT_018ce2f8 / (fVar9 * fVar9);
          fVar12 = fVar12 + pfVar6[-1] * fVar9;
          fVar13 = fVar13 + fVar9 * *pfVar6;
          pfVar4 = pfVar6 + 1;
          pfVar6 = pfVar6 + 3;
          param_3 = fVar9 + param_3;
          fVar14 = fVar14 + *pfVar4 * fVar9;
        } while (iVar2 < 3);
        param_3 = DAT_018ce2f8 / param_3;
        afStack_50[0xc] = param_3 * fVar12;
        afStack_50[0xd] = param_3 * fVar13;
        afStack_50[0xe] = param_3 * fVar14;
      }
      else {
        afStack_50[0xc] = DAT_01d64ef4;
        afStack_50[0xd] = DAT_01d64ef8;
        afStack_50[0xe] = DAT_01d64efc;
      }
    }
    else {
      afStack_50[0xc] = DAT_01d64edc;
      afStack_50[0xd] = DAT_01d64ee0;
      afStack_50[0xe] = DAT_01d64ee4;
    }
LAB_009c0b58:
    afStack_50[0xf] = param_6;
    pfVar6 = &fStack_118;
    afStack_50[4] = 0.39607844;
    iVar2 = 4;
    afStack_50[5] = 0.39215687;
    afStack_50[6] = 0.39215687;
    afStack_50[7] = param_6 * DAT_018ce2f4;
    afStack_50[0] = 0.39215687;
    afStack_50[1] = 0.39215687;
    afStack_50[2] = 0.39215687;
    afStack_50[3] = param_6;
    do {
      fStack_64 = pfVar6[1];
      fVar7 = pfVar6[3];
      fStack_5c = fVar7;
      if (fStack_64 < fVar7) {
        fStack_5c = fStack_64;
      }
      fVar12 = *pfVar6;
      fVar13 = pfVar6[2];
      fStack_60 = fVar13;
      if (fVar12 < fVar13) {
        fStack_60 = fVar12;
      }
      fStack_54 = fVar7;
      if (fVar7 < fStack_64) {
        fStack_54 = fStack_64;
      }
      fStack_58 = fVar13;
      if (fVar13 < fVar12) {
        fStack_58 = fVar12;
      }
      afStack_50[10] = 1.0;
      afStack_50[0xb] = 1.0;
      afStack_50[8] = 1.0;
      afStack_50[9] = 1.0;
      fStack_6c = fVar7;
      if (fStack_64 < fVar7) {
        fStack_6c = fStack_64;
      }
      fStack_70 = fVar13;
      if (fVar12 < fVar13) {
        fStack_70 = fVar12;
      }
      if (fStack_64 <= fVar7) {
        fStack_64 = fVar7;
      }
      pfVar4 = pfVar6;
      if (fVar12 <= fVar13) {
        pfVar4 = pfVar6 + 2;
      }
      fStack_68 = *pfVar4;
      pfStack_13c = &fStack_60;
      pfStack_140 = afStack_50 + 0xc;
      pfStack_144 = afStack_50 + 10;
      pfStack_148 = afStack_50 + 8;
      pfStack_14c = &fStack_70;
      uStack_150 = 0x9c0c87;
      FUN_0114e9e0();
      pfVar6 = pfVar6 + 4;
      iVar2 = iVar2 + -1;
    } while (iVar2 != 0);
    pfVar6 = afStack_d8;
    iVar2 = 0;
    do {
      fStack_54 = pfVar6[1];
      pfVar4 = afStack_50 + 4;
      if (iVar2 != 0) {
        pfVar4 = afStack_50;
      }
      fStack_128 = *pfVar4;
      fStack_124 = pfVar4[1];
      fStack_120 = pfVar4[2];
      fStack_11c = pfVar4[3];
      fVar7 = pfVar6[3];
      fStack_6c = fVar7;
      if (fStack_54 < fVar7) {
        fStack_6c = fStack_54;
      }
      fVar12 = *pfVar6;
      fVar13 = pfVar6[2];
      fStack_70 = fVar13;
      if (fVar12 < fVar13) {
        fStack_70 = fVar12;
      }
      fStack_64 = fVar7;
      if (fVar7 < fStack_54) {
        fStack_64 = fStack_54;
      }
      fStack_68 = fVar13;
      if (fVar13 < fVar12) {
        fStack_68 = fVar12;
      }
      afStack_50[10] = 1.0;
      afStack_50[0xb] = 1.0;
      afStack_50[8] = 1.0;
      afStack_50[9] = 1.0;
      fStack_5c = fVar7;
      if (fStack_54 < fVar7) {
        fStack_5c = fStack_54;
      }
      fStack_60 = fVar13;
      if (fVar12 < fVar13) {
        fStack_60 = fVar12;
      }
      if (fStack_54 <= fVar7) {
        fStack_54 = fVar7;
      }
      pfVar4 = pfVar6;
      if (fVar12 <= fVar13) {
        pfVar4 = pfVar6 + 2;
      }
      fStack_58 = *pfVar4;
      pfStack_13c = &fStack_70;
      pfStack_140 = &fStack_128;
      pfStack_144 = afStack_50 + 10;
      pfStack_148 = afStack_50 + 8;
      pfStack_14c = &fStack_60;
      uStack_150 = 0x9c0d8f;
      FUN_0114e9e0();
      iVar2 = iVar2 + 1;
      pfVar6 = pfVar6 + 4;
    } while (iVar2 < 3);
    afStack_98[0] = fVar8;
    if (fVar11 < fVar8) {
      afStack_98[0] = fVar11;
    }
    afStack_98[1] = 2.0;
    afStack_98[2] = fVar8;
    if (fVar8 < fVar11) {
      afStack_98[2] = fVar11;
    }
    uStack_8c = 0x40800000;
    afStack_50[2] = 1.0;
    afStack_50[3] = 1.0;
    afStack_50[6] = 1.0;
    afStack_50[7] = 1.0;
    afStack_a8[0] = fVar8;
    if (fVar11 < fVar8) {
      afStack_a8[0] = fVar11;
    }
    afStack_a8[1] = 2.0;
    afStack_a8[2] = fVar11;
    if (fVar11 <= fVar8) {
      afStack_a8[2] = fVar8;
    }
    pfStack_13c = afStack_98;
    pfStack_140 = afStack_50 + 0xc;
    pfStack_144 = afStack_50 + 2;
    uStack_9c = 0x40800000;
    pfStack_148 = afStack_50 + 6;
    pfStack_14c = afStack_a8;
    uStack_150 = 0x9c0e5b;
    FUN_0114e9e0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18757 ; VA 0x009c0e80 ; FUN_009c0e80 */

undefined4 __thiscall FUN_009c0e80(int param_1,uint param_2,int param_3)

{
  char cVar1;
  int iVar2;
  uint *puVar3;
  int *piVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  uint *puVar8;
  int iVar9;
  uint auStack_38 [4];
  int iStack_28;
  uint uStack_24;
  undefined auStack_20 [12];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017d5330;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    iVar9 = *(int *)(param_3 + 0xc);
    ExceptionList = &pvStack_10;
    iVar2 = FUN_00aff8c0();
    if ((uint)*(ushort *)(iVar9 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      if (param_1 != 0) {
        iStack_14 = *(int *)(param_1 + 0x34);
        if (iStack_14 != 0) {
          iVar9 = *(int *)(iStack_14 + 0xc);
          iVar2 = FUN_00b63e30();
          if ((uint)*(ushort *)(iVar9 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
              (uint)*(ushort *)(iVar2 + 0x1da)) {
            iStack_28 = 0;
            uStack_24 = 0xf;
            auStack_38[0] = auStack_38[0] & 0xffffff00;
            puVar8 = &DAT_01d64c64;
            uStack_8 = CONCAT31(uStack_8._1_3_,1);
            iVar9 = 0x10;
            do {
              if ((puVar8[-1] == param_2) && (auStack_38 != puVar8)) {
                puVar3 = puVar8;
                if (0xf < puVar8[5]) {
                  puVar3 = (uint *)*puVar8;
                }
                FUN_005542c0(puVar3,puVar8[4]);
              }
              puVar8 = puVar8 + 7;
              iVar9 = iVar9 + -1;
            } while (iVar9 != 0);
            if (iStack_28 == 0) {
              if (0xf < uStack_24) {
                uVar7 = uStack_24 + 1;
                uVar6 = auStack_38[0];
                if (0xfff < uVar7) {
                  uVar6 = *(uint *)(auStack_38[0] - 4);
                  uVar7 = uStack_24 + 0x24;
                  if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
                    FUN_017167a3();
                  }
                }
                FUN_01674ea0(uVar6,uVar7);
              }
            }
            else {
              piVar4 = (int *)FUN_008a1240(auStack_38);
              uStack_8 = uStack_8 & 0xffffff00;
              if (0xf < uStack_24) {
                uVar7 = uStack_24 + 1;
                uVar6 = auStack_38[0];
                if (0xfff < uVar7) {
                  uVar6 = *(uint *)(auStack_38[0] - 4);
                  uVar7 = uStack_24 + 0x24;
                  if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
                    FUN_017167a3();
                  }
                }
                FUN_01674ea0(uVar6,uVar7);
              }
              iStack_28 = 0;
              uStack_24 = 0xf;
              auStack_38[0] = auStack_38[0] & 0xffffff00;
              if (piVar4 != (int *)0x0) {
                if (((DAT_01d64ac8 != '\0') && (*(int *)(param_1 + 0x228) != 0)) && (param_2 == 0))
                {
                  cVar1 = FUN_008bc690(param_1);
                  if (cVar1 != '\0') {
                    if (*(int *)(param_1 + 0x228) == 0) {
                      iVar9 = *(int *)(param_1 + 0x348);
                    }
                    else {
                      iVar9 = *(int *)(param_1 + 0x378);
                    }
                    if (iVar9 != 0) {
                      iVar9 = FUN_0099fb90();
                      if (iVar9 != 0) {
                        piVar5 = (int *)FUN_0099fb90();
                        if (piVar5 != (int *)0x0) {
                          (**(code **)(*piVar5 + 0x2c))();
                          FUN_008a65e0(param_3,0);
                        }
                      }
                    }
                  }
                }
                FUN_008a65e0(piVar4[0xd],0);
                (**(code **)(*piVar4 + 0x2c))();
                FUN_009aa270();
                FUN_00550b30();
                ExceptionList = pvStack_10;
                return 1;
              }
            }
          }
        }
      }
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return 0;
    }
  }
  FUN_00550130("ReplaceBodyPartR15 must be passed a non-nil BasePart.");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_20,&DAT_01c17198);
}



/* FUNCTION 18758 ; VA 0x009c10f0 ; FUN_009c10f0 */

/* WARNING: Removing unreachable block (ram,0x009c11d2) */
/* WARNING: Removing unreachable block (ram,0x009c11de) */
/* WARNING: Removing unreachable block (ram,0x009c11ec) */

undefined4 FUN_009c10f0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017d5369;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  pcVar1 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_f0 = FUN_0088cdc0();
  uStack_e8 = param_2;
  uStack_ec = 0;
  uStack_e4 = param_3;
  uStack_ec = FUN_006309e0();
  iStack_8._0_1_ = 1;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,param_1);
  iStack_8._0_1_ = 2;
  (*pcVar1)(uStack_14,&uStack_20,param_4);
  iStack_8._0_1_ = 3;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  uVar2 = FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 18759 ; VA 0x009c1210 ; FUN_009c1210 */

void FUN_009c1210(int *param_1,undefined4 param_2)

{
  code *pcVar1;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined uStack_f0;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d53a1;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  uStack_24 = 0;
  pcVar1 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_f8 = FUN_0088daf0();
  uStack_f4 = 0;
  uStack_f0 = (undefined)param_2;
  uStack_f4 = FUN_005c9ef0();
  uStack_8 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_f8,&uStack_28,param_2);
  uStack_8._0_1_ = 1;
  (*pcVar1)(uStack_14,&uStack_20,&uStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00577b20();
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_f8,0xd0,1,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18760 ; VA 0x009c1300 ; FUN_009c1300 */

void FUN_009c1300(float *param_1,float *param_2)

{
  double dVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  
  fVar4 = *param_1;
  if (DAT_018f76ac < fVar4 * fVar4 + param_1[1] * param_1[1] + param_1[2] * param_1[2]) {
    fVar2 = *param_2 * *param_2 + param_2[1] * param_2[1] + param_2[2] * param_2[2];
    if (DAT_018f76ac < fVar2) {
      dVar1 = (double)fVar2;
      FUN_017267a0();
      fVar3 = (float)dVar1;
      fVar2 = DAT_018ce2f8 / fVar3;
      fVar6 = param_2[1] * fVar2 * 0.0;
      fVar5 = *param_2 * fVar2 - fVar6;
      fVar6 = fVar6 - param_2[2] * fVar2;
      fVar2 = param_2[2] * fVar2 * 0.0 - *param_2 * fVar2 * 0.0;
      fVar7 = fVar5 * param_1[1] - fVar2 * param_1[2];
      fVar5 = fVar6 * param_1[2] - fVar5 * fVar4;
      fVar2 = fVar2 * fVar4 - fVar6 * param_1[1];
      fVar4 = fVar5 * fVar5 + fVar7 * fVar7 + fVar2 * fVar2;
      if (DAT_018f76ac < fVar4) {
        dVar1 = (double)fVar4;
        FUN_017267a0();
        fVar4 = DAT_018ce2f8 / (float)dVar1;
        *(ulonglong *)param_2 = CONCAT44(fVar4 * fVar5 * fVar3,fVar4 * fVar7 * fVar3);
        param_2[2] = fVar4 * fVar2 * fVar3;
      }
    }
  }
  return;
}



/* FUNCTION 18761 ; VA 0x009c14b0 ; FUN_009c14b0 */

void __thiscall FUN_009c14b0(int *param_1,uint param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  uint uVar4;
  
  if ((((uint)param_1[2] < param_2) && (param_2 << 2 != 0)) &&
     (puVar2 = (undefined4 *)FUN_01674fa0(param_2 << 2,param_1[4]), puVar2 != (undefined4 *)0x0)) {
    uVar4 = param_1[1];
    iVar1 = *param_1;
    if (*(char *)(param_1 + 3) == '\0') {
      if (uVar4 < 0x11) {
        if (uVar4 != 0) {
          puVar3 = puVar2;
          do {
            *puVar3 = *(undefined4 *)((iVar1 - (int)puVar2) + (int)puVar3);
            uVar4 = uVar4 - 1;
            puVar3 = puVar3 + 1;
          } while (uVar4 != 0);
        }
      }
      else {
        FUN_0170c6f0(puVar2,iVar1,uVar4 * 4);
      }
    }
    else {
      FUN_0099eb00(puVar2,iVar1,uVar4);
    }
    if (param_1[2] != 0) {
      FUN_01674ee0(*param_1);
    }
    *param_1 = (int)puVar2;
    param_1[2] = param_2;
  }
  return;
}



/* FUNCTION 18762 ; VA 0x009c1540 ; FUN_009c1540 */

void __thiscall FUN_009c1540(int *param_1,uint param_2)

{
  int iVar1;
  
  if ((((uint)param_1[2] < param_2) && (param_2 * 4 != 0)) &&
     (iVar1 = FUN_01674fa0(param_2 * 4,param_1[4]), iVar1 != 0)) {
    FUN_0099eb50(iVar1,*param_1,param_1[1]);
    if (param_1[2] != 0) {
      FUN_01674ee0(*param_1);
    }
    *param_1 = iVar1;
    param_1[2] = param_2;
  }
  return;
}



/* FUNCTION 18763 ; VA 0x009c15a0 ; FUN_009c15a0 */

void FUN_009c15a0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  
  uVar5 = 0;
  iVar2 = FUN_005d6c30();
  if (iVar2 != 0) {
    do {
      iVar2 = *(int *)(**(int **)(param_1 + 0x2c) + uVar5 * 8);
      if ((iVar2 != 0) &&
         (iVar1 = *(int *)(iVar2 + 0xc), iVar3 = FUN_00c8dce0(),
         (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
         (uint)*(ushort *)(iVar3 + 0x1da))) {
        FUN_009c1620(iVar2,param_2,param_3);
      }
      uVar5 = uVar5 + 1;
      uVar4 = FUN_005d6c30();
    } while (uVar5 < uVar4);
  }
  return;
}



/* FUNCTION 18764 ; VA 0x009c1620 ; FUN_009c1620 */

void FUN_009c1620(int *param_1,int *param_2,undefined8 *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  undefined4 *******pppppppuVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined8 *puVar11;
  float *pfVar12;
  uint uVar13;
  undefined4 *******pppppppuVar14;
  undefined1 *puVar15;
  undefined4 ******appppppuStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  undefined8 uStack_54;
  float fStack_4c;
  int *piStack_48;
  float fStack_44;
  float fStack_40;
  int *piStack_3c;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined8 uStack_30;
  int *piStack_28;
  undefined auStack_24 [4];
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d53d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_18 = (int *)thunk_FUN_00c48580();
  if (piStack_18 == (int *)0x0) {
    ExceptionList = pvStack_10;
    return;
  }
  iVar5 = thunk_FUN_00c48580();
  if (iVar5 == 0) {
    puVar15 = &DAT_018bc9b8;
    uVar10 = 0;
LAB_009c16d3:
    uStack_5c = 0;
    uStack_58 = 0xf;
    appppppuStack_6c[0] = (undefined4 ******)((uint)appppppuStack_6c[0] & 0xffffff00);
    FUN_005542c0(puVar15,uVar10);
  }
  else if (*(int *)((int)param_1 + 0x78) == 0) {
LAB_009c169c:
    iVar5 = FUN_0099fa70();
    if (((iVar5 == 0) ||
        (iVar5 = FUN_00c8fca0(*(undefined4 *)((int)param_1 + 0x34),*(undefined4 *)(iVar5 + 0x28)),
        iVar5 == 0)) || (*(int *)(iVar5 + 0x34) == 0)) {
      uVar10 = 4;
      puVar15 = &DAT_018db5cc;
      goto LAB_009c16d3;
    }
    FUN_0054ef60(*(undefined4 *)(*(int *)(iVar5 + 0x34) + 0x28));
  }
  else {
    iVar7 = FUN_00c3c010();
    if (iVar7 == iVar5) {
      iVar5 = FUN_00c3c020();
    }
    else {
      iVar5 = FUN_00c3c010();
    }
    if (iVar5 == 0) goto LAB_009c169c;
    FUN_0054ef60(*(undefined4 *)(iVar5 + 0x28));
  }
  pppppppuVar14 = (undefined4 *******)appppppuStack_6c[0];
  pppppppuVar6 = appppppuStack_6c;
  if (0xf < uStack_58) {
    pppppppuVar6 = (undefined4 *******)appppppuStack_6c[0];
  }
  iStack_8 = 0;
  cVar4 = FUN_0055c360(pppppppuVar6,uStack_5c,&DAT_018db5cc,4);
  if (cVar4 != '\0') {
    param_2 = (int *)param_3;
  }
  uStack_54 = *(undefined8 *)param_2;
  fStack_4c = *(float *)((int)param_2 + 8);
  iVar5 = thunk_FUN_00c48580();
  if (iVar5 != 0) {
    if (*(int *)((int)param_1 + 0x78) == 0) {
      iVar5 = FUN_0099fa70();
      if ((iVar5 == 0) ||
         (iVar5 = FUN_00c8fca0(*(undefined4 *)((int)param_1 + 0x34),*(undefined4 *)(iVar5 + 0x28)),
         iVar5 == 0)) goto LAB_009c1a87;
      param_3 = (undefined8 *)FUN_006e16a0(*(undefined4 *)(iVar5 + 0x34));
    }
    else {
      iVar7 = FUN_00c3c010();
      if (iVar7 == iVar5) {
        param_3 = (undefined8 *)FUN_00c3c020();
      }
      else {
        param_3 = (undefined8 *)FUN_00c3c010();
      }
    }
    if (param_3 != (undefined8 *)0x0) {
      piStack_34 = DAT_018ce2f8;
      piStack_3c = DAT_018ce2f8;
      piStack_48 = DAT_018ce2f8;
      param_1 = (int *)0x0;
      piStack_1c = (int *)0x0;
      param_2 = (int *)0x0;
      piStack_28 = (int *)0x0;
      iVar5 = FUN_009ba890(*(undefined4 *)((int)param_3 + 0x34));
      if (iVar5 != 0) {
        FUN_009b3a80(&piStack_1c,&piStack_28);
        param_1 = piStack_1c;
        param_2 = piStack_28;
      }
      puVar8 = (undefined4 *)FUN_0060dcd0(auStack_20,piStack_18);
      iStack_8._0_1_ = 1;
      uVar10 = *puVar8;
      uVar2 = puVar8[1];
      *puVar8 = 0;
      puVar8[1] = 0;
      piStack_28 = (int *)FUN_009b6320(uVar10,uVar2);
      piVar3 = piStack_1c;
      iStack_8._0_1_ = 0;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar5 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar5 = *piVar1 + -1;
          *piVar1 = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      if (piStack_28 != (int *)0x0) {
        puVar8 = (undefined4 *)FUN_0060dcd0(auStack_38,piStack_18);
        iStack_8._0_1_ = 2;
        uVar10 = *puVar8;
        uVar2 = puVar8[1];
        *puVar8 = 0;
        puVar8[1] = 0;
        uVar9 = FUN_009b6320(uVar10,uVar2);
        puVar8 = (undefined4 *)FUN_0060dcd0(&fStack_40,piStack_18);
        iStack_8._0_1_ = 3;
        uVar10 = *puVar8;
        uVar2 = puVar8[1];
        *puVar8 = 0;
        puVar8[1] = 0;
        uVar10 = FUN_009b6320(uVar10,uVar2);
        puVar11 = (undefined8 *)FUN_009b6520(auStack_24,param_3,0,0,uVar10,uVar9);
        uStack_30 = *puVar11;
        piStack_28 = *(int **)(puVar11 + 1);
        FUN_00550b30();
        iStack_8._0_1_ = 0;
        FUN_00550b30();
        piStack_48 = piStack_28;
        piStack_3c = uStack_30._4_4_;
        piStack_34 = (int *)uStack_30;
      }
      puVar8 = (undefined4 *)FUN_0060dcd0((int)&uStack_30 + 4,param_3);
      iStack_8._0_1_ = 4;
      uVar10 = *puVar8;
      uVar2 = puVar8[1];
      *puVar8 = 0;
      puVar8[1] = 0;
      iVar5 = FUN_009b6320(uVar10,uVar2);
      piVar3 = piStack_28;
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar7 = piStack_28[1] + -1;
        piStack_28[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piStack_28)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar7 = *piVar1 + -1;
          *piVar1 = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      if ((DAT_01d64a78 != '\0') && (*(int *)(iStack_14 + 0x228) == 0)) {
        if (iVar5 == 0) {
          param_1 = (int *)0x0;
          param_2 = (int *)0x0;
        }
        else if (iVar5 == 1) {
          param_2 = (int *)0x0;
          param_1 = DAT_018ce2f8;
        }
        else if (iVar5 == 2) {
          param_2 = DAT_018ce2f8;
          param_1 = DAT_018ce2f8;
        }
      }
      pfVar12 = (float *)FUN_009b6520(&uStack_30,param_3,param_2,param_1,iVar5,0);
      param_1 = (int *)(*pfVar12 * (float)piStack_34 * (float)uStack_54);
      param_2 = (int *)(pfVar12[1] * (float)piStack_3c * uStack_54._4_4_);
      param_3 = (undefined8 *)(pfVar12[2] * (float)piStack_48 * fStack_4c);
      pppppppuVar14 = (undefined4 *******)appppppuStack_6c[0];
      goto LAB_009c1aa5;
    }
  }
LAB_009c1a87:
  param_3 = (undefined8 *)fStack_4c;
  param_2 = (int *)uStack_54._4_4_;
  param_1 = (int *)(float)uStack_54;
LAB_009c1aa5:
  piVar3 = piStack_18;
  FUN_009b5ee0(&uStack_54,piStack_18);
  pfVar12 = (float *)FUN_00b08320();
  fStack_44 = (float)param_1 / (*pfVar12 / (float)uStack_54);
  fStack_40 = (float)param_2 / (pfVar12[1] / uStack_54._4_4_);
  piStack_3c = (int *)((float)param_3 / (pfVar12[2] / fStack_4c));
  FUN_009c2a90(piVar3,&fStack_44);
  fStack_44 = (float)uStack_54 * (float)param_1;
  fStack_40 = uStack_54._4_4_ * (float)param_2;
  piStack_3c = (int *)(fStack_4c * (float)param_3);
  (**(code **)(*piVar3 + 0xe8))(&fStack_44);
  FUN_00c90900();
  if (0xf < uStack_58) {
    uVar13 = uStack_58 + 1;
    pppppppuVar6 = pppppppuVar14;
    if (0xfff < uVar13) {
      pppppppuVar6 = (undefined4 *******)pppppppuVar14[-1];
      uVar13 = uStack_58 + 0x24;
      if (0x1f < (uint)((int)pppppppuVar14 + (-4 - (int)pppppppuVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppppuVar6,uVar13);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18765 ; VA 0x009c1ba0 ; FUN_009c1ba0 */

void __thiscall FUN_009c1ba0(float param_1,int *param_2,int *param_3,int *param_4,int *param_5)

{
  int *piVar1;
  float fVar2;
  undefined8 uVar3;
  int iVar4;
  int *piVar5;
  char cVar6;
  int iVar7;
  int iVar8;
  int *piVar9;
  float *pfVar10;
  uint uVar11;
  uint uVar12;
  undefined4 *puVar13;
  int in_stack_ffffff54;
  int **ppiVar14;
  float fStack_94;
  float fStack_90;
  float fStack_8c;
  float fStack_88;
  float fStack_84;
  float fStack_80;
  uint auStack_7c [4];
  undefined4 uStack_6c;
  uint uStack_68;
  int *piStack_64;
  int *piStack_60;
  int *piStack_5c;
  int *piStack_58;
  int *piStack_54;
  int *piStack_50;
  undefined8 uStack_4c;
  float fStack_44;
  int *piStack_40;
  int *piStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  int iStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5408;
  pvStack_10 = ExceptionList;
  fStack_14 = param_1;
  if (*(int *)((int)param_1 + 0x228) == 1) {
    if (**(char **)((int)param_1 + 0x230) != (char)*(char **)((int)param_1 + 0x230)) {
      puStack_2c = (undefined4 *)0x0;
      puStack_28 = (undefined4 *)0x0;
      iStack_24 = 0;
      uStack_8._0_1_ = 0;
      uStack_8._1_3_ = 0;
      ppiVar14 = (int **)0x9c1c17;
      ExceptionList = &pvStack_10;
      FUN_009b45c0(&puStack_2c);
      piStack_5c = param_4;
      if ((float)param_4 <= (float)DAT_018daf54) {
        piStack_5c = DAT_018daf54;
      }
      piStack_60 = param_3;
      if ((float)param_3 <= (float)DAT_018daf54) {
        piStack_60 = DAT_018daf54;
      }
      piStack_64 = param_2;
      if ((float)param_2 <= (float)DAT_018daf54) {
        piStack_64 = DAT_018daf54;
      }
      piStack_58 = DAT_018daf54;
      if ((float)DAT_018daf54 <= (float)param_5) {
        piStack_58 = param_5;
      }
      puVar13 = puStack_2c;
      piStack_54 = piStack_58;
      piStack_50 = piStack_58;
      if (puStack_2c != puStack_28) {
        do {
          ppiVar14 = &piStack_40;
          in_stack_ffffff54 = 0x9c1c80;
          FUN_0060dcd0(ppiVar14,*puVar13);
          uStack_8._0_1_ = 1;
          if (piStack_40 != (int *)0x0) {
            fStack_18 = DAT_018ce2f8;
            fStack_1c = DAT_018ce2f8;
            fStack_20 = DAT_018ce2f8;
            uStack_6c = 0;
            uStack_68 = 0xf;
            auStack_7c[0] = auStack_7c[0] & 0xffffff00;
            FUN_005542c0("DefaultScale",0xc);
            uStack_8 = CONCAT31(uStack_8._1_3_,2);
            iVar7 = FUN_008a1240(auStack_7c);
            if ((iVar7 == 0) ||
               (iVar4 = *(int *)(iVar7 + 0xc), iVar8 = FUN_00dafce0(),
               (uint)*(ushort *)(iVar8 + 0x1da) <
               (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8))) {
              iVar7 = 0;
            }
            uStack_8._0_1_ = 1;
            if (0xf < uStack_68) {
              uVar12 = uStack_68 + 1;
              uVar11 = auStack_7c[0];
              if (0xfff < uVar12) {
                uVar11 = *(uint *)(auStack_7c[0] - 4);
                uVar12 = uStack_68 + 0x24;
                if (0x1f < (auStack_7c[0] - uVar11) - 4) goto LAB_009c2004;
              }
              FUN_01674ea0(uVar11,uVar12);
            }
            piVar5 = piStack_40;
            uStack_6c = 0;
            uStack_68 = 0xf;
            auStack_7c[0] = auStack_7c[0] & 0xffffff00;
            if (iVar7 != 0) {
              uVar3 = *(undefined8 *)(iVar7 + 0x54);
              fStack_44 = *(float *)(iVar7 + 0x5c);
              uStack_4c._4_4_ = (float)((ulonglong)uVar3 >> 0x20);
              fStack_1c = uStack_4c._4_4_;
              uStack_4c._0_4_ = (float)uVar3;
              fStack_18 = (float)uStack_4c;
              uStack_4c = uVar3;
              fStack_20 = fStack_44;
            }
            FUN_009b5ee0(&fStack_38,piStack_40);
            piVar9 = (int *)piVar5[10];
            piVar1 = piVar9 + 4;
            if (0xf < (uint)piVar9[5]) {
              piVar9 = (int *)*piVar9;
            }
            cVar6 = FUN_0055c360(piVar9,*piVar1,&DAT_018db5cc,4);
            ppiVar14 = &piStack_58;
            if (cVar6 == '\0') {
              ppiVar14 = &piStack_64;
            }
            pfVar10 = (float *)FUN_00b08320();
            fStack_88 = (float)*ppiVar14 / (fStack_18 * (*pfVar10 / fStack_38));
            fStack_84 = (float)ppiVar14[1] / (fStack_1c * (pfVar10[1] / fStack_34));
            fStack_80 = (float)ppiVar14[2] / (fStack_20 * (pfVar10[2] / fStack_30));
            in_stack_ffffff54 = 0x9c1e32;
            FUN_009c2a90(piVar5,&fStack_88);
            fStack_94 = fStack_38 * ((float)*ppiVar14 / fStack_18);
            fStack_90 = fStack_34 * ((float)ppiVar14[1] / fStack_1c);
            fStack_8c = fStack_30 * ((float)ppiVar14[2] / fStack_20);
            ppiVar14 = (int **)0x9c1e96;
            (**(code **)(*piVar5 + 0xe8))(&fStack_94);
          }
          piVar5 = piStack_3c;
          uStack_8._0_1_ = 0;
          if (piStack_3c != (int *)0x0) {
            LOCK();
            iVar7 = piStack_3c[1] + -1;
            piStack_3c[1] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)*piStack_3c)();
              LOCK();
              piVar1 = piVar5 + 2;
              iVar7 = *piVar1 + -1;
              *piVar1 = iVar7;
              UNLOCK();
              if (iVar7 == 0) {
                (**(code **)(*piVar5 + 4))();
              }
            }
          }
          puVar13 = puVar13 + 1;
          param_1 = fStack_14;
        } while (puVar13 != puStack_28);
      }
      iVar7 = *(int *)((int)param_1 + 0x34);
      if ((iVar7 != 0) &&
         (iVar4 = *(int *)(iVar7 + 0xc), iVar8 = FUN_00b63e30(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8) <=
         (uint)*(ushort *)(iVar8 + 0x1da))) {
        ppiVar14 = &piStack_64;
        FUN_009c15a0(iVar7,ppiVar14,&piStack_58);
        in_stack_ffffff54 = iVar7;
      }
      fVar2 = *(float *)((int)param_1 + 0x334);
      if (((NAN(fVar2) || NAN(DAT_018ce2f0)) != (fVar2 == DAT_018ce2f0)) &&
         (fStack_14 = (float)(**(uint **)((int)param_1 + 0x218) ^
                             (uint)*(uint **)((int)param_1 + 0x218)),
         (NAN(fVar2) || NAN(fStack_14)) == (fVar2 == fStack_14))) {
        *(float *)((int)param_1 + 0x334) = fStack_14;
        cVar6 = FUN_00f94320();
        if (cVar6 == '\0') {
          FUN_008a4940(&DAT_02122390);
        }
        else {
          FUN_009b1bb0(&DAT_02122390,in_stack_ffffff54,ppiVar14,&DAT_01d6505a);
        }
      }
      FUN_009c3910(*(float *)((int)param_1 + 0x334) * (float)param_3);
      *(ulonglong *)((int)param_1 + 0x324) = CONCAT44(param_3,param_2);
      *(int **)((int)param_1 + 0x32c) = param_4;
      *(int **)((int)param_1 + 0x330) = param_5;
      FUN_009a8c40();
      if (puStack_2c != (undefined4 *)0x0) {
        uVar11 = iStack_24 - (int)puStack_2c & 0xfffffffc;
        puVar13 = puStack_2c;
        if (0xfff < uVar11) {
          puVar13 = (undefined4 *)puStack_2c[-1];
          uVar11 = uVar11 + 0x23;
          if (0x1f < (uint)((int)puStack_2c + (-4 - (int)puVar13))) {
LAB_009c2004:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(puVar13,uVar11);
      }
    }
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_0086f2f0(2,"Scaling is only supported for R15 characters");
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18766 ; VA 0x009c2010 ; FUN_009c2010 */

void __thiscall
FUN_009c2010(int param_1,float param_2,float param_3,float param_4,float param_5,undefined4 param_6,
            undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  int iStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5430;
  pvStack_10 = ExceptionList;
  if ((DAT_01d64a78 == '\0') && (*(int *)(param_1 + 0x228) != 1)) {
    ExceptionList = &pvStack_10;
    FUN_0086f2f0(2,"Scaling is only supported for R15 characters");
    ExceptionList = pvStack_10;
    return;
  }
  if (**(char **)(param_1 + 0x230) != (char)*(char **)(param_1 + 0x230)) {
    if (param_4 <= DAT_018daf54) {
      param_4 = DAT_018daf54;
    }
    if (param_3 <= DAT_018daf54) {
      param_3 = DAT_018daf54;
    }
    if (param_2 <= DAT_018daf54) {
      param_2 = DAT_018daf54;
    }
    fStack_3c = DAT_018daf54;
    if (DAT_018daf54 <= param_5) {
      fStack_3c = param_5;
    }
    fStack_38 = fStack_3c;
    fStack_34 = fStack_3c;
    fStack_30 = param_2;
    fStack_2c = param_3;
    fStack_28 = param_4;
    if ((DAT_01d64a78 == '\0') || (ExceptionList = &pvStack_10, *(int *)(param_1 + 0x228) == 1)) {
      puStack_24 = (undefined4 *)0x0;
      puStack_20 = (undefined4 *)0x0;
      iStack_1c = 0;
      iStack_8 = 0;
      ExceptionList = &pvStack_10;
      FUN_009b45c0(&puStack_24);
      puVar7 = puStack_24;
      if (puStack_24 != puStack_20) {
        do {
          FUN_0060dcd0(&iStack_18,*puVar7);
          iStack_8._0_1_ = 1;
          if (iStack_18 != 0) {
            FUN_009c2250(iStack_18,&fStack_30,&fStack_3c,param_6,param_7);
          }
          piVar4 = piStack_14;
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          if (piStack_14 != (int *)0x0) {
            LOCK();
            iVar3 = piStack_14[1] + -1;
            piStack_14[1] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)*piStack_14)();
              LOCK();
              piVar1 = piVar4 + 2;
              iVar3 = *piVar1 + -1;
              *piVar1 = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                (**(code **)(*piVar4 + 4))();
              }
            }
          }
          puVar7 = puVar7 + 1;
        } while (puVar7 != puStack_20);
      }
      iStack_8 = 0xffffffff;
      if (puStack_24 != (undefined4 *)0x0) {
        uVar6 = iStack_1c - (int)puStack_24 & 0xfffffffc;
        puVar7 = puStack_24;
        if (0xfff < uVar6) {
          puVar7 = (undefined4 *)puStack_24[-1];
          uVar6 = uVar6 + 0x23;
          if (0x1f < (uint)((int)puStack_24 + (-4 - (int)puVar7))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(puVar7,uVar6);
        puStack_24 = (undefined4 *)0x0;
        puStack_20 = (undefined4 *)0x0;
        iStack_1c = 0;
      }
    }
    iVar3 = *(int *)(param_1 + 0x34);
    if ((iVar3 != 0) &&
       (iVar2 = *(int *)(iVar3 + 0xc), iVar5 = FUN_00b63e30(),
       (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
       (uint)*(ushort *)(iVar5 + 0x1da))) {
      FUN_009c15a0(iVar3,&fStack_30,&fStack_3c);
    }
    *(ulonglong *)(param_1 + 0x324) = CONCAT44(fStack_2c,fStack_30);
    *(float *)(param_1 + 0x32c) = fStack_28;
    *(float *)(param_1 + 0x330) = fStack_3c;
    FUN_009a8c40();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18767 ; VA 0x009c2250 ; FUN_009c2250 */

void FUN_009c2250(int *param_1,float *param_2,float *param_3,undefined4 param_4,int param_5)

{
  undefined4 uVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined8 *puVar8;
  undefined4 ****ppppuVar9;
  int *piVar10;
  float *pfVar11;
  int iVar12;
  int iVar13;
  uint uVar14;
  char *pcVar15;
  undefined4 **appuStack_f4 [4];
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined uStack_dc;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined uStack_c4;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined uStack_ac;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined uStack_94;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 ***apppuStack_7c [4];
  undefined4 uStack_6c;
  uint uStack_68;
  undefined8 uStack_64;
  float fStack_5c;
  undefined8 uStack_58;
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  char acStack_3c [12];
  undefined auStack_30 [4];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  int *piStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d54c2;
  pvStack_10 = ExceptionList;
  piVar10 = (int *)param_1[10];
  piVar3 = piVar10;
  if (0xf < (uint)piVar10[5]) {
    piVar3 = (int *)*piVar10;
  }
  ExceptionList = &pvStack_10;
  cVar2 = FUN_0055c360(piVar3,piVar10[4],&DAT_018db5cc,4);
  if (cVar2 != '\0') {
    param_2 = param_3;
  }
  FUN_0054ef60(piVar10);
  uStack_8 = 0;
  FUN_009b5ee0(&fStack_4c,param_1);
  ppppuVar9 = apppuStack_7c;
  if (0xf < uStack_68) {
    ppppuVar9 = (undefined4 ****)apppuStack_7c[0];
  }
  cVar2 = FUN_0055c360(ppppuVar9,uStack_6c,&DAT_018db5cc,4);
  if ((cVar2 == '\0') ||
     (iVar5 = param_1[3], iVar4 = FUN_00aff8c0(),
     (uint)*(ushort *)(iVar4 + 0x1da) <
     (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) goto LAB_009c246c;
  iVar5 = FUN_0099fbf0();
  if (iVar5 == 0) {
    cVar2 = FUN_00938fa0(param_1);
    if (cVar2 == '\0') {
      uStack_2c = 0;
      uStack_28 = 0xf;
      acStack_3c[0] = cVar2;
      FUN_005542c0("AvatarPartScaleType",0x13);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      uVar6 = FUN_008a1240(acStack_3c);
      piVar10 = (int *)FUN_0099f8e0(uVar6);
      if (piVar10 != (int *)0x0) {
        (**(code **)(*piVar10 + 0x2c))();
      }
      uStack_8 = uStack_8 & 0xffffff00;
      FUN_005507b0();
    }
    goto LAB_009c246c;
  }
  uStack_2c = 0;
  uStack_28 = 0xf;
  acStack_3c[0] = '\0';
  FUN_005542c0("AvatarPartScaleType",0x13);
  uStack_8._0_1_ = 1;
  uVar6 = FUN_008a1240(acStack_3c);
  iVar5 = FUN_0099f8e0(uVar6);
  if (iVar5 == 0) {
    cVar2 = FUN_00938fa0(param_1);
    if (cVar2 == '\0') {
      uVar6 = FUN_008a1240(acStack_3c);
      piVar10 = (int *)FUN_0099f8e0(uVar6);
      if (piVar10 != (int *)0x0) {
        (**(code **)(*piVar10 + 0x2c))();
      }
    }
LAB_009c23ff:
    uStack_8 = (uint)uStack_8._1_3_ << 8;
    FUN_005507b0();
  }
  else {
    uVar6 = FUN_008a1240(acStack_3c);
    iVar4 = FUN_0099f8e0(uVar6);
    if (iVar4 == 0) {
      FUN_0099f500(&piStack_24);
      piVar10 = piStack_24;
      uStack_8._0_1_ = 2;
      if (piStack_24 != (int *)0x0) {
        (**(code **)(*piStack_24 + 0x38))(acStack_3c);
        FUN_008a65e0(param_1,0);
      }
      uStack_8._0_1_ = 1;
      FUN_00550b30();
      if (piVar10 == (int *)0x0) goto LAB_009c23ff;
    }
    FUN_00db5950(iVar5 + 0x54);
    uStack_8 = (uint)uStack_8._1_3_ << 8;
    FUN_005507b0();
  }
LAB_009c246c:
  puVar7 = (undefined4 *)FUN_0060dcd0(&piStack_24,param_1);
  uStack_8._0_1_ = 4;
  uVar6 = *puVar7;
  uVar1 = puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  uVar6 = FUN_009b6320(uVar6,uVar1);
  piVar10 = piStack_20;
  uStack_8 = (uint)uStack_8._1_3_ << 8;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_20[1] + -1;
    piStack_20[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar3 = piVar10 + 2;
      iVar5 = *piVar3 + -1;
      *piVar3 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar10 + 4))();
      }
    }
  }
  puVar8 = (undefined8 *)FUN_009b6520(&fStack_1c,param_1,param_5,param_4,uVar6,uVar6);
  uStack_58 = *puVar8;
  fStack_50 = *(float *)(puVar8 + 1);
  ppppuVar9 = apppuStack_7c;
  if (0xf < uStack_68) {
    ppppuVar9 = (undefined4 ****)apppuStack_7c[0];
  }
  cVar2 = FUN_0055c360(ppppuVar9,uStack_6c,&DAT_018db5cc,4);
  if (((cVar2 != '\0') &&
      (iVar5 = param_1[3], iVar4 = FUN_00aff8c0(),
      (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
      (uint)*(ushort *)(iVar4 + 0x1da))) &&
     (piVar10 = (int *)FUN_0099fbf0(), piStack_20 = piVar10, piVar10 != (int *)0x0)) {
    uStack_64 = *(undefined8 *)param_2;
    fStack_5c = param_2[2];
    if (piVar10[0x2c] == 0) {
      fStack_14 = 1.0;
      uStack_64 = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
      fStack_5c = 1.0;
    }
    pfVar11 = (float *)FUN_009b5ac0(auStack_30,piVar10);
    fStack_1c = *pfVar11;
    fStack_18 = pfVar11[1];
    fStack_14 = pfVar11[2];
    if (piVar10[0x2c] != 0) {
      fStack_1c = (float)uStack_64 * fStack_1c * (float)uStack_58;
      fStack_18 = uStack_64._4_4_ * fStack_18 * uStack_58._4_4_;
      fStack_14 = fStack_5c * fStack_14 * fStack_50;
      FUN_00dba0f0(&fStack_1c);
    }
    uStack_e4 = 0;
    uStack_e0 = 0xf;
    appuStack_f4[0]._0_1_ = 0;
    FUN_005542c0("FaceCenterAttachment",0x14);
    uStack_8._0_1_ = 5;
    uStack_cc = 0;
    uStack_c8 = 0xf;
    uStack_dc = 0;
    FUN_005542c0("FaceFrontAttachment",0x13);
    uStack_8._0_1_ = 6;
    uStack_b4 = 0;
    uStack_b0 = 0xf;
    uStack_c4 = 0;
    FUN_005542c0("HairAttachment",0xe);
    uStack_8._0_1_ = 7;
    uStack_9c = 0;
    uStack_98 = 0xf;
    uStack_ac = 0;
    FUN_005542c0("HatAttachment",0xd);
    uStack_8._0_1_ = 8;
    uStack_84 = 0;
    uStack_80 = 0xf;
    uStack_94 = 0;
    FUN_005542c0("NeckRigAttachment",0x11);
    uStack_8._0_1_ = 9;
    ppppuVar9 = (undefined4 ****)appuStack_f4;
    do {
      iVar5 = FUN_008a1240(ppppuVar9);
      if ((iVar5 == 0) ||
         (iVar4 = *(int *)(iVar5 + 0xc), iVar12 = FUN_00dafce0(),
         (uint)*(ushort *)(iVar12 + 0x1da) <
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar12 + 0x1d8))) {
        uVar6 = FUN_008a1240(ppppuVar9);
        iVar5 = FUN_009ab420(uVar6);
        if (iVar5 != 0) {
          uStack_2c = 0;
          uStack_28 = 0xf;
          acStack_3c[0] = '\0';
          pcVar15 = PTR_DAT_01d64a08;
          do {
            cVar2 = *pcVar15;
            pcVar15 = pcVar15 + 1;
          } while (cVar2 != '\0');
          FUN_005542c0(PTR_DAT_01d64a08,(int)pcVar15 - (int)(PTR_DAT_01d64a08 + 1));
          uStack_8._0_1_ = 0xb;
          uVar6 = FUN_008a1240(acStack_3c);
          iVar5 = FUN_0099f830(uVar6);
          uStack_8._0_1_ = 9;
          FUN_005507b0();
          if ((iVar5 != 0) && (FUN_0097be30(&param_5,ppppuVar9), param_5 != DAT_01ee383c)) {
            iVar5 = param_5 + 0x20;
            goto LAB_009c287c;
          }
        }
      }
      else {
        uVar6 = FUN_008a1240(ppppuVar9);
        iVar4 = FUN_009ab420(uVar6);
        if (iVar4 != 0) {
          uStack_2c = 0;
          uStack_28 = 0xf;
          acStack_3c[0] = '\0';
          pcVar15 = PTR_DAT_01d64a08;
          do {
            cVar2 = *pcVar15;
            pcVar15 = pcVar15 + 1;
          } while (cVar2 != '\0');
          FUN_005542c0(PTR_DAT_01d64a08,(int)pcVar15 - (int)(PTR_DAT_01d64a08 + 1));
          uStack_8._0_1_ = 10;
          uVar6 = FUN_008a1240(acStack_3c);
          iVar4 = FUN_0099f830(uVar6);
          uStack_8._0_1_ = 9;
          FUN_005507b0();
          if (iVar4 != 0) {
            iVar5 = iVar5 + 0x54;
LAB_009c287c:
            FUN_00db5810(iVar5);
          }
        }
      }
      ppppuVar9 = ppppuVar9 + 6;
    } while (ppppuVar9 != apppuStack_7c);
    uStack_8 = (uint)uStack_8._1_3_ << 8;
    FUN_016f32d1(appuStack_f4,0x18,5,FUN_005507b0);
  }
  fStack_4c = *param_2 * fStack_4c * (float)uStack_58;
  fStack_44 = fStack_44 * fStack_50 * param_2[2];
  fStack_48 = param_2[1] * fStack_48 * uStack_58._4_4_;
  (**(code **)(*param_1 + 0xe8))(&fStack_4c);
  param_3 = (float *)0x0;
  iVar5 = FUN_005d6c30();
  if (iVar5 != 0) {
    do {
      iVar5 = *(int *)(*(int *)param_1[0xb] + (int)param_3 * 8);
      if ((iVar5 == 0) ||
         (iVar4 = *(int *)(iVar5 + 0xc), iVar13 = FUN_00d6bbd0(), iVar12 = iVar5,
         (uint)*(ushort *)(iVar13 + 0x1da) <
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar13 + 0x1d8))) {
        iVar12 = 0;
      }
      if ((iVar5 == 0) ||
         (iVar4 = *(int *)(iVar5 + 0xc), iVar13 = FUN_00d77b00(),
         (uint)*(ushort *)(iVar13 + 0x1da) <
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar13 + 0x1d8))) {
        iVar5 = 0;
      }
      if (iVar5 != 0) {
        iVar12 = 0;
      }
      FUN_0060dcd0(&piStack_24,iVar12);
      uStack_8._0_1_ = 0xc;
      if (piStack_24 != (int *)0x0) {
        FUN_009b5570(&fStack_4c,piStack_24,param_2);
        fStack_1c = *param_2 * fStack_4c * (float)uStack_58;
        fStack_14 = fStack_44 * fStack_50 * param_2[2];
        fStack_18 = param_2[1] * fStack_48 * uStack_58._4_4_;
        FUN_00d6dad0(&fStack_1c);
      }
      piVar10 = piStack_20;
      uStack_8 = (uint)uStack_8._1_3_ << 8;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_20[1] + -1;
        piStack_20[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar3 = piVar10 + 2;
          iVar5 = *piVar3 + -1;
          *piVar3 = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar10 + 4))();
          }
        }
      }
      param_3 = (float *)((int)param_3 + 1);
      uVar14 = FUN_005d6c30();
    } while (param_3 < uVar14);
  }
  if (0xf < uStack_68) {
    uVar14 = uStack_68 + 1;
    ppppuVar9 = (undefined4 ****)apppuStack_7c[0];
    if (0xfff < uVar14) {
      ppppuVar9 = (undefined4 ****)apppuStack_7c[0][-1];
      uVar14 = uStack_68 + 0x24;
      if (0x1f < (uint)((int)apppuStack_7c[0] + (-4 - (int)ppppuVar9))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar9,uVar14);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18768 ; VA 0x009c2a90 ; FUN_009c2a90 */

void FUN_009c2a90(int param_1,float *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  int iStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d54e0;
  pvStack_10 = ExceptionList;
  uVar8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_005d6c30();
  if (iVar4 != 0) {
    do {
      iVar4 = *(int *)(**(int **)(param_1 + 0x2c) + uVar8 * 8);
      if ((iVar4 == 0) ||
         (iVar2 = *(int *)(iVar4 + 0xc), iVar5 = FUN_00d6bbd0(), iVar9 = iVar4,
         (uint)*(ushort *)(iVar5 + 0x1da) <
         (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
        iVar9 = 0;
      }
      if ((iVar4 == 0) ||
         (iVar2 = *(int *)(iVar4 + 0xc), iVar6 = FUN_00d77b00(), iVar5 = iVar4,
         (uint)*(ushort *)(iVar6 + 0x1da) <
         (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
        iVar5 = 0;
      }
      if (iVar5 != 0) {
        iVar9 = 0;
      }
      FUN_0060dcd0(&iStack_24,iVar9);
      uStack_8 = 0;
      if (iStack_24 == 0) {
        if ((iVar4 == 0) ||
           (iVar2 = *(int *)(iVar4 + 0xc), iVar9 = FUN_00d0f2a0(),
           (uint)*(ushort *)(iVar9 + 0x1da) <
           (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar9 + 0x1d8))) {
          iVar4 = 0;
        }
        FUN_0060dcd0(&iStack_1c,iVar4);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        if ((iStack_1c != 0) && (*(int *)(iStack_1c + 0xb0) != 0)) {
          fStack_48 = *(float *)(iStack_1c + 0x54) * *param_2;
          fStack_44 = *(float *)(iStack_1c + 0x58) * param_2[1];
          fStack_40 = *(float *)(iStack_1c + 0x5c) * param_2[2];
          FUN_00dba0f0(&fStack_48);
        }
        piVar3 = piStack_18;
        if (piStack_18 != (int *)0x0) {
          LOCK();
          iVar4 = piStack_18[1] + -1;
          piStack_18[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piStack_18)();
            LOCK();
            piVar1 = piVar3 + 2;
            iVar4 = *piVar1 + -1;
            *piVar1 = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
      }
      else {
        FUN_00a6bd00(&fStack_30);
        fStack_3c = fStack_30 * *param_2;
        fStack_38 = param_2[1] * fStack_2c;
        fStack_34 = param_2[2] * fStack_28;
        FUN_00d6dad0(&fStack_3c);
      }
      piVar3 = piStack_20;
      uStack_8 = 0xffffffff;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_20[1] + -1;
        piStack_20[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar4 = *piVar1 + -1;
          *piVar1 = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      uVar8 = uStack_14 + 1;
      uStack_14 = uVar8;
      uVar7 = FUN_005d6c30();
    } while (uVar8 < uVar7);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18769 ; VA 0x009c2ca0 ; FUN_009c2ca0 */

void __thiscall FUN_009c2ca0(int param_1,char param_2)

{
  int iVar1;
  
  *(char *)(param_1 + 0x2e6) = param_2;
  if ((param_2 == '\0') && (iVar1 = *(int *)(param_1 + 0x228), iVar1 != 0)) {
    if ((DAT_01d64a90 != '\0') && (DAT_01d64af0 == '\0')) {
      FUN_009c4910(0);
      iVar1 = *(int *)(param_1 + 0x228);
    }
    if (iVar1 != 0) {
      FUN_009aa070(*(undefined4 *)(param_1 + 0x3f0));
      return;
    }
    FUN_009aa070(*(undefined4 *)(param_1 + 0x340));
  }
  return;
}



/* FUNCTION 18770 ; VA 0x009c2d10 ; FUN_009c2d10 */

void __thiscall FUN_009c2d10(int param_1,char param_2)

{
  byte bVar1;
  byte bVar2;
  
  if ('\0' < *(char *)(param_1 + 0x21e) != (bool)param_2) {
    bVar1 = FUN_01679ce0();
    bVar1 = bVar1 & 0x7f;
    if (param_2 != '\0') {
      bVar2 = 1;
      if (bVar1 != 0) {
        bVar2 = bVar1;
      }
      *(byte *)(param_1 + 0x21e) = bVar2;
      return;
    }
    bVar2 = 1;
    if (bVar1 != 0) {
      bVar2 = bVar1;
    }
    *(byte *)(param_1 + 0x21e) = -bVar2;
  }
  return;
}



/* FUNCTION 18771 ; VA 0x009c2d70 ; FUN_009c2d70 */

void __thiscall FUN_009c2d70(int param_1,char param_2)

{
  char cVar1;
  
  if (*(char *)(param_1 + 0x238) != param_2) {
    *(char *)(param_1 + 0x238) = param_2;
    cVar1 = FUN_00f94320();
    if (cVar1 != '\0') {
      FUN_009b1bb0(&DAT_021221d0);
      return;
    }
    FUN_008a4940(&DAT_021221d0);
  }
  return;
}



/* FUNCTION 18772 ; VA 0x009c2dd0 ; FUN_009c2dd0 */

void __thiscall FUN_009c2dd0(int param_1,char param_2)

{
  byte bVar1;
  char cVar2;
  byte bVar3;
  
  if ('\0' < *(char *)(param_1 + 0x225) != (bool)param_2) {
    bVar1 = FUN_01679ce0();
    bVar1 = bVar1 & 0x7f;
    if (param_2 == '\0') {
      bVar3 = 1;
      if (bVar1 != 0) {
        bVar3 = bVar1;
      }
      bVar3 = -bVar3;
    }
    else {
      bVar3 = 1;
      if (bVar1 != 0) {
        bVar3 = bVar1;
      }
    }
    *(byte *)(param_1 + 0x225) = bVar3;
    cVar2 = FUN_00f94320();
    if (cVar2 != '\0') {
      FUN_009b1bb0(&DAT_021226c8);
      return;
    }
    FUN_008a4940(&DAT_021226c8);
  }
  return;
}



/* FUNCTION 18773 ; VA 0x009c2e60 ; FUN_009c2e60 */

void __thiscall FUN_009c2e60(int param_1,int param_2)

{
  char *pcVar1;
  char cVar2;
  
  pcVar1 = *(char **)(param_1 + 0x230);
  if ((char)param_2 != (char)(*pcVar1 - (char)pcVar1)) {
    *(char **)pcVar1 = pcVar1 + param_2;
    cVar2 = FUN_00f94320();
    if (cVar2 == '\0') {
      FUN_008a4940(&DAT_02122320);
    }
    else {
      FUN_009b1bb0(&DAT_02122320);
    }
    if (**(char **)(param_1 + 0x230) != (char)*(char **)(param_1 + 0x230)) {
      FUN_009c4910(DAT_01d641b4);
    }
  }
  return;
}



/* FUNCTION 18774 ; VA 0x009c2ee0 ; FUN_009c2ee0 */

void __thiscall FUN_009c2ee0(int param_1,undefined8 param_2,undefined4 param_3)

{
  *(undefined8 *)(param_1 + 0x324) = param_2;
  *(undefined4 *)(param_1 + 0x32c) = param_3;
  return;
}



/* FUNCTION 18775 ; VA 0x009c2f00 ; FUN_009c2f00 */

void __thiscall FUN_009c2f00(int param_1,char param_2)

{
  char cVar1;
  
  if (param_2 != *(char *)(param_1 + 0x239)) {
    *(char *)(param_1 + 0x239) = param_2;
    cVar1 = FUN_00f94320();
    if (cVar1 != '\0') {
      FUN_009b1bb0(&DAT_02122700);
      return;
    }
    FUN_008a4940(&DAT_02122700);
  }
  return;
}



/* FUNCTION 18776 ; VA 0x009c2f60 ; FUN_009c2f60 */

void __thiscall FUN_009c2f60(int param_1,int param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_10 [4];
  int *piStack_c;
  int iStack_8;
  
  iStack_8 = param_1;
  puVar5 = (undefined4 *)FUN_0060dcd0(auStack_10,param_3);
  param_1 = param_1 + param_2 * 8;
  uVar1 = *puVar5;
  uVar2 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0x340) = uVar1;
  piVar3 = *(int **)(param_1 + 0x344);
  *(undefined4 *)(param_1 + 0x344) = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_c[1] + -1;
    piStack_c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar3 = piStack_c + 2;
      iVar4 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_c + 4))();
      }
    }
  }
  FUN_009c7e00();
  return;
}



/* FUNCTION 18777 ; VA 0x009c3010 ; FUN_009c3010 */

void __thiscall FUN_009c3010(int param_1,float *param_2)

{
  if ((((NAN(*param_2) || NAN(*(float *)(param_1 + 0x268))) ==
        (*param_2 == *(float *)(param_1 + 0x268))) ||
      ((NAN(param_2[1]) || NAN(*(float *)(param_1 + 0x26c))) ==
       (param_2[1] == *(float *)(param_1 + 0x26c)))) ||
     ((NAN(param_2[2]) || NAN(*(float *)(param_1 + 0x270))) ==
      (param_2[2] == *(float *)(param_1 + 0x270)))) {
    *(undefined8 *)(param_1 + 0x268) = *(undefined8 *)param_2;
    *(float *)(param_1 + 0x270) = param_2[2];
  }
  return;
}



/* FUNCTION 18778 ; VA 0x009c3070 ; FUN_009c3070 */

void __thiscall FUN_009c3070(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0x2a8) = param_2;
  return;
}



/* FUNCTION 18779 ; VA 0x009c3080 ; FUN_009c3080 */

void __thiscall FUN_009c3080(int param_1,int param_2)

{
  char cVar1;
  
  if (param_2 != *(int *)(param_1 + 0x234)) {
    *(int *)(param_1 + 0x234) = param_2;
    FUN_009ab540();
    cVar1 = FUN_00f94320();
    if (cVar1 != '\0') {
      FUN_009b1bb0(&DAT_021229f8);
      return;
    }
    FUN_008a4940(&DAT_021229f8);
  }
  return;
}



/* FUNCTION 18780 ; VA 0x009c30e0 ; FUN_009c30e0 */

void __thiscall FUN_009c30e0(int param_1,int param_2)

{
  char cVar1;
  
  if (param_2 != *(int *)(param_1 + 600)) {
    *(int *)(param_1 + 600) = param_2;
    cVar1 = FUN_00f94320();
    if (cVar1 != '\0') {
      FUN_009b1bb0(&DAT_02123408);
      return;
    }
    FUN_008a4940(&DAT_02123408);
  }
  return;
}



/* FUNCTION 18781 ; VA 0x009c3140 ; FUN_009c3140 */

void __thiscall FUN_009c3140(int param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar6 = in_stack_00000018;
  piVar4 = param_2;
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  piVar5 = (int *)(param_1 + 0x17c);
  uStack_8 = 0;
  piVar2 = (int *)&param_2;
  if (0xf < in_stack_00000018) {
    piVar2 = param_2;
  }
  piVar3 = piVar5;
  if (0xf < *(uint *)(param_1 + 400)) {
    piVar3 = (int *)*piVar5;
  }
  uVar8 = *(undefined4 *)(param_1 + 0x18c);
  ExceptionList = &pvStack_10;
  cVar1 = FUN_0055c360(piVar3,uVar8,piVar2,in_stack_00000014);
  if (cVar1 == '\0') {
    if ((int **)piVar5 != &param_2) {
      piVar2 = (int *)&param_2;
      if (0xf < uVar6) {
        piVar2 = piVar4;
      }
      uVar8 = 0x9c31b5;
      FUN_005542c0(piVar2,in_stack_00000014);
    }
    cVar1 = FUN_00f94320();
    if (cVar1 == '\0') {
      FUN_008a4940(&DAT_02122358);
      piVar4 = param_2;
      uVar6 = in_stack_00000018;
    }
    else {
      FUN_009b1bb0(&DAT_02122358,uVar8,piVar2,&DAT_01d6505a);
      piVar4 = param_2;
      uVar6 = in_stack_00000018;
    }
  }
  if (0xf < uVar6) {
    uVar7 = uVar6 + 1;
    piVar5 = piVar4;
    if (0xfff < uVar7) {
      piVar5 = (int *)piVar4[-1];
      uVar7 = uVar6 + 0x24;
      if (0x1f < (uint)((int)piVar4 + (-4 - (int)piVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar5,uVar7);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18782 ; VA 0x009c3240 ; FUN_009c3240 */

void __thiscall FUN_009c3240(int param_1,float *param_2,char param_3)

{
  float fVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  float *pfVar6;
  undefined4 *puVar7;
  float10 fVar8;
  float fVar9;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  float fStack_30;
  undefined auStack_2c [12];
  float fStack_20;
  undefined8 uStack_1c;
  undefined8 uStack_10;
  int iStack_8;
  
  if (((param_3 == '\0') || (*(char *)(param_1 + 0xf1) < '\x01')) ||
     ('\0' < *(char *)(param_1 + 0xeb))) {
    if (NAN(*(float *)(param_1 + 0xb8)) == (*(float *)(param_1 + 0xb8) == 0.0)) {
      *(undefined4 *)(param_1 + 0xb8) = 0;
      return;
    }
  }
  else {
    iVar3 = param_1 + -0x134;
    iStack_8 = FUN_009b7250();
    if (iStack_8 != 0) {
      uStack_1c._4_4_ = param_2[2];
      fStack_20 = (float)*(undefined8 *)param_2;
      uStack_1c._0_4_ = (float)((ulonglong)*(undefined8 *)param_2 >> 0x20);
      if (iVar3 != 0) {
        iVar4 = *(int *)(param_1 + -0x100);
        if ((iVar4 != 0) && (iVar3 = iVar4, *(int *)(iVar4 + 0x34) != 0)) {
          iVar3 = FUN_005c8ac0();
        }
        if (((iVar3 != 0) &&
            (iVar3 = *(int *)(iVar3 + 0xc), iVar4 = FUN_008a8c30(),
            (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
            (uint)*(ushort *)(iVar4 + 0x1da))) &&
           ((piVar5 = (int *)FUN_00636c60(), *piVar5 != 0 && (cVar2 = FUN_00b837e0(), cVar2 != '\0')
            ))) {
          pfVar6 = (float *)FUN_00b83750();
          fStack_30 = pfVar6[8];
          fVar9 = *param_2;
          fVar1 = param_2[2];
          fStack_20 = param_2[1] * pfVar6[1] + fVar9 * *pfVar6 + fVar1 * pfVar6[2];
          uStack_1c._0_4_ = param_2[1] * pfVar6[4] + fVar9 * pfVar6[3] + fVar1 * pfVar6[5];
          uStack_1c._4_4_ = param_2[1] * pfVar6[7] + fVar9 * pfVar6[6] + fVar1 * fStack_30;
          uStack_10 = (double)CONCAT44(uStack_1c._4_4_,(undefined4)uStack_10);
        }
      }
      FUN_00b077e0();
      iVar3 = FUN_011612d0(auStack_2c,2);
      uStack_10 = (double)(float)((uint)uStack_1c._4_4_ ^ DAT_018c4ea0);
      fVar8 = (float10)FUN_01728580();
      uStack_1c = (double)fVar8;
      uStack_10 = (double)*(float *)(iVar3 + 8);
      fVar8 = (float10)FUN_01728580();
      uStack_10 = (double)fVar8;
      fVar8 = (float10)FUN_009bf200((double)((float)uStack_1c - (float)fVar8));
      fVar9 = (float)fVar8;
      if (*(int **)(param_1 + 0x5c4) != (int *)0x0) {
        iVar3 = (**(code **)(**(int **)(param_1 + 0x5c4) + 0x3c))();
        if (iVar3 != 4) {
          puVar7 = (undefined4 *)FUN_00b077e0();
          uStack_5c = *puVar7;
          uStack_58 = puVar7[1];
          uStack_54 = puVar7[2];
          uStack_50 = puVar7[3];
          uStack_4c = puVar7[4];
          uStack_48 = puVar7[5];
          uStack_44 = puVar7[6];
          uStack_40 = puVar7[7];
          uStack_3c = puVar7[8];
          uStack_38 = puVar7[9];
          uStack_34 = puVar7[10];
          fStack_30 = (float)puVar7[0xb];
          FUN_00c94d90(&uStack_5c,fVar9);
          if ('\0' < *(char *)(param_1 + 0xf1)) {
            FUN_00b0e9d0();
          }
        }
      }
      if ((float)(double)CONCAT44((uint)((ulonglong)(double)fVar9 >> 0x20) & DAT_018c0da0._4_4_,
                                  SUB84((double)fVar9,0) & (uint)DAT_018c0da0) < DAT_018e452c) {
        fVar9 = 0.0;
      }
      if ((NAN(*(float *)(param_1 + 0xb8)) || NAN(fVar9)) == (*(float *)(param_1 + 0xb8) == fVar9))
      {
        *(float *)(param_1 + 0xb8) = fVar9;
      }
    }
  }
  return;
}



/* FUNCTION 18783 ; VA 0x009c3540 ; FUN_009c3540 */

void __thiscall FUN_009c3540(int param_1,int param_2)

{
  char cVar1;
  
  if (*(int *)(param_1 + 0x2e0) != param_2) {
    *(int *)(param_1 + 0x2e0) = param_2;
    cVar1 = FUN_00f94320();
    if (cVar1 == '\0') {
      FUN_008a4940(&DAT_02122770);
    }
    else {
      FUN_009b1bb0(&DAT_02122770);
    }
    cVar1 = FUN_00f94320();
    if (cVar1 != '\0') {
      FUN_009b1bb0(&DAT_021227b0);
      return;
    }
    FUN_008a4940(&DAT_021227b0);
  }
  return;
}



/* FUNCTION 18784 ; VA 0x009c35d0 ; FUN_009c35d0 */

void __thiscall FUN_009c35d0(int param_1,int param_2)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x228) == 0) {
    iVar1 = *(int *)(param_1 + 0x348);
  }
  else {
    iVar1 = *(int *)(param_1 + 0x378);
  }
  if (iVar1 != 0) {
    iVar1 = FUN_0099fb90();
    if (iVar1 != 0) {
      FUN_008a5010();
    }
  }
  if (param_2 != 0) {
    if (*(int *)(param_1 + 0x228) == 0) {
      iVar1 = *(int *)(param_1 + 0x348);
    }
    else {
      iVar1 = *(int *)(param_1 + 0x378);
    }
    if (iVar1 != 0) {
      FUN_008a65e0(iVar1,0);
    }
  }
  return;
}



/* FUNCTION 18785 ; VA 0x009c3630 ; FUN_009c3630 */

void __fastcall FUN_009c3630(int param_1)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x228) == 0) {
    iVar1 = *(int *)(param_1 + 0x348);
  }
  else {
    iVar1 = *(int *)(param_1 + 0x378);
  }
  if (iVar1 != 0) {
    iVar1 = FUN_0099fb30();
    if (iVar1 != 0) {
      FUN_008a5010();
    }
  }
  if (*(int *)(param_1 + 0x228) == 0) {
    iVar1 = *(int *)(param_1 + 0x348);
  }
  else {
    iVar1 = *(int *)(param_1 + 0x378);
  }
  if (iVar1 != 0) {
    FUN_008a65e0(iVar1,0);
  }
  return;
}



/* FUNCTION 18786 ; VA 0x009c3690 ; FUN_009c3690 */

void __thiscall FUN_009c3690(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x330) = param_2;
  return;
}



/* FUNCTION 18787 ; VA 0x009c36b0 ; FUN_009c36b0 */

void __thiscall FUN_009c36b0(int param_1,float param_2)

{
  uint *puVar1;
  undefined uVar2;
  char cVar3;
  
  puVar1 = *(uint **)(param_1 + 0x1fc);
  if ((NAN((float)(*puVar1 ^ (uint)puVar1)) || NAN(param_2)) ==
      ((float)(*puVar1 ^ (uint)puVar1) == param_2)) {
    *puVar1 = (uint)param_2 ^ (uint)puVar1;
    if ((*(char *)(param_1 + 0x2e5) != '\0') ||
       (DAT_018ce2f0 < (float)(**(uint **)(param_1 + 0x1fc) ^ (uint)*(uint **)(param_1 + 0x1fc)))) {
      uVar2 = 1;
    }
    else {
      uVar2 = 0;
    }
    *(undefined *)(param_1 + 0x2e5) = uVar2;
    cVar3 = FUN_00f94320();
    if (cVar3 == '\0') {
      FUN_008a4940(&DAT_021220f0);
    }
    else {
      FUN_009b1bb0(&DAT_021220f0);
    }
    cVar3 = FUN_00f94320();
    if (cVar3 == '\0') {
      FUN_008a4940(&DAT_021220b8);
    }
    else {
      FUN_009b1bb0(&DAT_021220b8);
    }
    cVar3 = FUN_00f94320();
    if (cVar3 != '\0') {
      FUN_009b1bb0(param_2);
      return;
    }
    FUN_0091b810(param_2);
  }
  return;
}



/* FUNCTION 18788 ; VA 0x009c37e0 ; FUN_009c37e0 */

void __thiscall FUN_009c37e0(int param_1,float param_2)

{
  char cVar1;
  float fVar2;
  
  fVar2 = 0.0;
  if (0.0 <= param_2) {
    fVar2 = param_2;
  }
  if ((NAN(*(float *)(param_1 + 0x264)) || NAN(fVar2)) == (*(float *)(param_1 + 0x264) == fVar2)) {
    *(float *)(param_1 + 0x264) = fVar2;
    cVar1 = FUN_00f94320();
    if (cVar1 != '\0') {
      FUN_009b1bb0(&DAT_021234c0);
      return;
    }
    FUN_008a4940(&DAT_021234c0);
  }
  return;
}



/* FUNCTION 18789 ; VA 0x009c3850 ; FUN_009c3850 */

void __thiscall FUN_009c3850(int param_1,int param_2)

{
  char cVar1;
  
  if (param_2 != *(int *)(param_1 + 0x25c)) {
    *(int *)(param_1 + 0x25c) = param_2;
    cVar1 = FUN_00f94320();
    if (cVar1 != '\0') {
      FUN_009b1bb0(&DAT_02123448);
      return;
    }
    FUN_008a4940(&DAT_02123448);
  }
  return;
}



/* FUNCTION 18790 ; VA 0x009c38b0 ; FUN_009c38b0 */

void __thiscall FUN_009c38b0(int param_1,float param_2)

{
  float fVar1;
  float fVar2;
  
  fVar1 = 0.0;
  if (0.0 <= param_2) {
    fVar1 = param_2;
  }
  fVar2 = (float)(**(int **)(param_1 + 0x200) + (int)*(int **)(param_1 + 0x200));
  if (fVar1 <= fVar2) {
    fVar2 = fVar1;
  }
  fVar1 = (float)(**(uint **)(param_1 + 0x1fc) ^ (uint)*(uint **)(param_1 + 0x1fc));
  if ((NAN(fVar1) || NAN(fVar2)) == (fVar1 == fVar2)) {
    FUN_009c36b0(fVar2);
  }
  return;
}



/* FUNCTION 18791 ; VA 0x009c3910 ; FUN_009c3910 */

void __thiscall FUN_009c3910(int param_1,float param_2)

{
  uint *puVar1;
  float fVar2;
  float fVar3;
  char cVar4;
  
  cVar4 = FUN_00c94350(param_2);
  if (cVar4 == '\0') {
    puVar1 = *(uint **)(param_1 + 0x218);
    fVar2 = (float)-DAT_01d649cc;
    if ((float)-DAT_01d649cc <= param_2) {
      fVar2 = param_2;
    }
    fVar3 = (float)DAT_01d649cc;
    if (fVar2 <= (float)DAT_01d649cc) {
      fVar3 = fVar2;
    }
    if ((NAN(fVar3) || NAN((float)(*puVar1 ^ (uint)puVar1))) ==
        (fVar3 == (float)(*puVar1 ^ (uint)puVar1))) {
      *puVar1 = (uint)fVar3 ^ (uint)puVar1;
      cVar4 = FUN_00f94320();
      if (cVar4 != '\0') {
        FUN_009b1bb0(&DAT_021222e8);
        return;
      }
      FUN_008a4940(&DAT_021222e8);
    }
  }
  return;
}



/* FUNCTION 18792 ; VA 0x009c39b0 ; FUN_009c39b0 */

void __thiscall FUN_009c39b0(int param_1,char param_2)

{
  byte bVar1;
  char cVar2;
  int iVar3;
  byte bVar4;
  uint in_stack_ffffffe4;
  char *pcVar5;
  
  pcVar5 = (char *)0x9c39be;
  iVar3 = FUN_009169f0(param_1);
  if ((((iVar3 != 0) && ('\0' < *(char *)(param_1 + 0x223))) &&
      ('\0' < *(char *)(param_1 + 0x21d) != (bool)param_2)) && (param_2 != '\0')) {
    FUN_006eccd0();
  }
  if ('\0' < *(char *)(param_1 + 0x21d) != (bool)param_2) {
    if (DAT_01ee41ed != 0) {
      in_stack_ffffffe4 = (uint)DAT_01ee41ed;
      pcVar5 = "Humanoid jump set: %u";
      FUN_016774b0(in_stack_ffffffe4,"Humanoid jump set: %u",param_2);
    }
    bVar1 = FUN_01679ce0();
    bVar1 = bVar1 & 0x7f;
    if (param_2 == '\0') {
      bVar4 = 1;
      if (bVar1 != 0) {
        bVar4 = bVar1;
      }
      bVar4 = -bVar4;
    }
    else {
      bVar4 = 1;
      if (bVar1 != 0) {
        bVar4 = bVar1;
      }
    }
    *(byte *)(param_1 + 0x21d) = bVar4;
    cVar2 = FUN_00f94320();
    if (cVar2 == '\0') {
      pcVar5 = (char *)0x9c3a8a;
      FUN_008a4940(&DAT_021225e8);
    }
    else {
      FUN_009b1bb0(&DAT_021225e8,in_stack_ffffffe4,pcVar5,&DAT_01d6505a);
    }
    cVar2 = FUN_00f94320();
    if (cVar2 != '\0') {
      FUN_009b1bb0(&DAT_02122620,in_stack_ffffffe4,pcVar5,&DAT_01d6505a);
      return;
    }
    FUN_008a4940(&DAT_02122620);
  }
  return;
}



/* FUNCTION 18793 ; VA 0x009c3ad0 ; FUN_009c3ad0 */

void __thiscall FUN_009c3ad0(int param_1,float param_2)

{
  int *piVar1;
  char cVar2;
  float fVar3;
  
  fVar3 = 0.0;
  if (0.0 <= param_2) {
    fVar3 = param_2;
  }
  piVar1 = *(int **)(param_1 + 0x210);
  if ((NAN(fVar3) || NAN((float)(*piVar1 + (int)piVar1))) ==
      (fVar3 == (float)(*piVar1 + (int)piVar1))) {
    *piVar1 = (int)fVar3 - (int)piVar1;
    cVar2 = FUN_00f94320();
    if (cVar2 != '\0') {
      FUN_009b1bb0(&DAT_02122278);
      return;
    }
    FUN_008a4940(&DAT_02122278);
  }
  return;
}



/* FUNCTION 18794 ; VA 0x009c3b40 ; FUN_009c3b40 */

void __thiscall FUN_009c3b40(int param_1,float param_2)

{
  uint *puVar1;
  char cVar2;
  float fVar3;
  float fVar4;
  
  fVar3 = 0.0;
  if (0.0 <= param_2) {
    fVar3 = param_2;
  }
  fVar4 = DAT_018ce324;
  if (fVar3 <= DAT_018ce324) {
    fVar4 = fVar3;
  }
  puVar1 = *(uint **)(param_1 + 0x208);
  if ((NAN(fVar4) || NAN((float)(*puVar1 ^ (uint)puVar1))) ==
      (fVar4 == (float)(*puVar1 ^ (uint)puVar1))) {
    *puVar1 = (uint)fVar4 ^ (uint)puVar1;
    cVar2 = FUN_00f94320();
    if (cVar2 != '\0') {
      FUN_009b1bb0(&DAT_02122208);
      return;
    }
    FUN_008a4940(&DAT_02122208);
  }
  return;
}



/* FUNCTION 18795 ; VA 0x009c3bc0 ; FUN_009c3bc0 */

undefined4 * __thiscall FUN_009c3bc0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (*(int *)(param_1 + 0x2c8) != 0) {
    *(undefined4 *)(param_1 + 0x2c8) = 0;
    piVar2 = *(int **)(param_1 + 0x2cc);
    *(undefined4 *)(param_1 + 0x2cc) = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar5 = piVar2[1] + -1;
      piVar2[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar5 = piVar2[2] + -1;
        piVar2[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  puVar6 = (undefined4 *)FUN_0060dcd0(auStack_c,param_2);
  uVar3 = *puVar6;
  uVar4 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  *(undefined4 *)(param_1 + 0x2c8) = uVar3;
  piVar2 = *(int **)(param_1 + 0x2cc);
  *(undefined4 *)(param_1 + 0x2cc) = uVar4;
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar5 = *piVar1;
    puVar6 = (undefined4 *)*piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1;
      puVar6 = (undefined4 *)*piVar1;
      *piVar1 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        puVar6 = (undefined4 *)(**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_8 + 1;
    iVar5 = *piVar2;
    puVar6 = (undefined4 *)*piVar2;
    *piVar2 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      puVar6 = (undefined4 *)(**(code **)*piStack_8)();
      LOCK();
      piVar2 = piStack_8 + 2;
      iVar5 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        puVar6 = (undefined4 *)(**(code **)(*piStack_8 + 4))();
      }
    }
  }
  return puVar6;
}



/* FUNCTION 18796 ; VA 0x009c3ca0 ; FUN_009c3ca0 */

undefined4 * __thiscall FUN_009c3ca0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (*(int *)(param_1 + 0x2d0) != 0) {
    *(undefined4 *)(param_1 + 0x2d0) = 0;
    piVar2 = *(int **)(param_1 + 0x2d4);
    *(undefined4 *)(param_1 + 0x2d4) = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar5 = piVar2[1] + -1;
      piVar2[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar5 = piVar2[2] + -1;
        piVar2[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  puVar6 = (undefined4 *)FUN_0060dcd0(auStack_c,param_2);
  uVar3 = *puVar6;
  uVar4 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  *(undefined4 *)(param_1 + 0x2d0) = uVar3;
  piVar2 = *(int **)(param_1 + 0x2d4);
  *(undefined4 *)(param_1 + 0x2d4) = uVar4;
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar5 = *piVar1;
    puVar6 = (undefined4 *)*piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1;
      puVar6 = (undefined4 *)*piVar1;
      *piVar1 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        puVar6 = (undefined4 *)(**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_8 + 1;
    iVar5 = *piVar2;
    puVar6 = (undefined4 *)*piVar2;
    *piVar2 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      puVar6 = (undefined4 *)(**(code **)*piStack_8)();
      LOCK();
      piVar2 = piStack_8 + 2;
      iVar5 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        puVar6 = (undefined4 *)(**(code **)(*piStack_8 + 4))();
      }
    }
  }
  return puVar6;
}



/* FUNCTION 18797 ; VA 0x009c3d80 ; FUN_009c3d80 */

void * FUN_009c3d80(int param_1,int *param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0xc);
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00aff8c0();
    pvVar4 = (void *)(uint)*(ushort *)(iVar3 + 0x1da);
    if (pvVar4 < (void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
      if (param_1 != 0) {
        iVar2 = *(int *)(param_1 + 0xc);
        iVar3 = FUN_00cffc50();
        pvVar4 = (void *)(uint)*(ushort *)(iVar3 + 0x1da);
        if ((void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) <= pvVar4)
        {
          if (DAT_01d64af8 == '\0') {
            pvVar4 = (void *)FUN_00d00e20(param_3);
          }
          else {
            pvVar4 = (void *)FUN_00d00b00(param_3);
          }
        }
      }
    }
    else {
      if (*(int *)(param_1 + 0x34) != 0) {
        iVar2 = *(int *)(*(int *)(param_1 + 0x34) + 0xc);
        iVar3 = FUN_00c46280();
        pvVar4 = (void *)(uint)*(ushort *)(iVar3 + 0x1da);
        if ((void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) <= pvVar4)
        goto LAB_009c3e59;
      }
      pvVar4 = (void *)FUN_00b0dcd0(param_3);
    }
  }
LAB_009c3e59:
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 18798 ; VA 0x009c3ea0 ; FUN_009c3ea0 */

void __thiscall FUN_009c3ea0(int param_1,undefined8 *param_2)

{
  undefined8 uVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  float10 fVar5;
  double dVar6;
  uint uVar7;
  uint uVar9;
  double dVar8;
  float fVar10;
  double dVar11;
  float in_stack_ffffffa4;
  float in_stack_ffffffa8;
  float fStack_20;
  undefined8 uStack_14;
  
  uVar1 = *param_2;
  fStack_20 = *(float *)(param_2 + 1);
  uStack_14._0_4_ = (float)uVar1;
  uStack_14._4_4_ = (float)((ulonglong)uVar1 >> 0x20);
  dVar11 = (double)((float)uStack_14 * (float)uStack_14 + uStack_14._4_4_ * uStack_14._4_4_ +
                   fStack_20 * fStack_20);
  if (NAN(dVar11) == (dVar11 == 0.0)) {
    uVar7 = SUB84(dVar11 - 0.0,0) & (uint)DAT_018c0da0;
    uVar9 = (uint)((ulonglong)(dVar11 - 0.0) >> 0x20) & DAT_018c0da0._4_4_;
    dVar8 = (double)CONCAT44((uint)((ulonglong)dVar11 >> 0x20) & DAT_018c0da0._4_4_,
                             SUB84(dVar11,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
    fVar5 = (float10)FUN_01160810();
    dVar6 = DAT_018f76b0;
    if ((NAN(dVar8) || NAN((double)fVar5)) == (dVar8 == (double)fVar5)) {
      dVar6 = dVar8 * DAT_018f76b0;
    }
    if (dVar6 < (double)CONCAT44(uVar9,uVar7)) {
      FUN_017267a0();
      if (DAT_018ce2f8 < (float)dVar11) {
        fVar10 = DAT_018ce2f8 / (float)dVar11;
        fStack_20 = fVar10 * fStack_20;
        uVar1 = CONCAT44(fVar10 * uStack_14._4_4_,fVar10 * (float)uStack_14);
      }
      goto LAB_009c3fdc;
    }
  }
  fStack_20 = 0.0;
  uStack_14 = 0;
  uVar1 = uStack_14;
LAB_009c3fdc:
  uStack_14 = uVar1;
  if (DAT_01ee41ed != '\0') {
    in_stack_ffffffa4 = uStack_14._4_4_;
    in_stack_ffffffa8 = fStack_20;
    FUN_016774d0(DAT_01ee41ed,"Setting lua move direction: %f %f %f",(float)uStack_14,
                 uStack_14._4_4_,fStack_20,0);
  }
  if ((((NAN(*(float *)(param_1 + 0x1bc)) || NAN((float)uStack_14)) ==
        (*(float *)(param_1 + 0x1bc) == (float)uStack_14)) ||
      ((NAN(*(float *)(param_1 + 0x1c0)) || NAN(uStack_14._4_4_)) ==
       (*(float *)(param_1 + 0x1c0) == uStack_14._4_4_))) ||
     ((NAN(*(float *)(param_1 + 0x1c4)) || NAN(fStack_20)) ==
      (*(float *)(param_1 + 0x1c4) == fStack_20))) {
    *(undefined8 *)(param_1 + 0x1bc) = uStack_14;
    *(float *)(param_1 + 0x1c4) = fStack_20;
    if (((NAN(*(float *)(param_1 + 0x1bc)) == (*(float *)(param_1 + 0x1bc) == 0.0)) ||
        (NAN(*(float *)(param_1 + 0x1c0)) == (*(float *)(param_1 + 0x1c0) == 0.0))) ||
       (NAN(*(float *)(param_1 + 0x1c4)) == (*(float *)(param_1 + 0x1c4) == 0.0))) {
      *(undefined *)(param_1 + 0x292) = 0;
      *(undefined8 *)(param_1 + 0x298) = 0;
      *(undefined4 *)(param_1 + 0x2a0) = 0;
      piVar2 = *(int **)(param_1 + 0x2a4);
      *(undefined4 *)(param_1 + 0x2a4) = 0;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar3 = piVar2[1] + -1;
        piVar2[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar3 = piVar2[2] + -1;
          piVar2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
    }
    cVar4 = FUN_00f94320();
    if (cVar4 == '\0') {
      in_stack_ffffffa8 = 1.4349729e-38;
      FUN_008a4940(&DAT_02122504);
    }
    else {
      FUN_009b1bb0(&DAT_02122504,in_stack_ffffffa4,in_stack_ffffffa8,&DAT_01d6505a);
    }
    cVar4 = FUN_00f94320();
    if (cVar4 != '\0') {
      FUN_009b1bb0(&DAT_02122828,in_stack_ffffffa4,in_stack_ffffffa8,&DAT_01d6505a);
      return;
    }
    FUN_008a4940(&DAT_02122828);
  }
  return;
}



/* FUNCTION 18799 ; VA 0x009c4170 ; FUN_009c4170 */

void __thiscall FUN_009c4170(int param_1,float param_2)

{
  int *piVar1;
  uint *puVar2;
  char cVar3;
  float fVar4;
  
  fVar4 = 0.0;
  if (0.0 <= param_2) {
    fVar4 = param_2;
  }
  piVar1 = *(int **)(param_1 + 0x200);
  if ((NAN((float)(*piVar1 + (int)piVar1)) || NAN(fVar4)) ==
      ((float)(*piVar1 + (int)piVar1) == fVar4)) {
    *piVar1 = (int)fVar4 - (int)piVar1;
    cVar3 = FUN_00f94320();
    if (cVar3 == '\0') {
      FUN_008a4940(&DAT_02122128);
    }
    else {
      FUN_009b1bb0(&DAT_02122128);
    }
    cVar3 = FUN_00f94320();
    puVar2 = *(uint **)(param_1 + 0x1fc);
    if (cVar3 != '\0') {
      FUN_009b1bb0(*puVar2 ^ (uint)puVar2);
      return;
    }
    FUN_0091b810(*puVar2 ^ (uint)puVar2);
  }
  return;
}



/* FUNCTION 18800 ; VA 0x009c4240 ; FUN_009c4240 */

void __thiscall FUN_009c4240(int param_1,float param_2)

{
  uint *puVar1;
  char cVar2;
  float fVar3;
  float fVar4;
  
  fVar3 = 0.0;
  if (0.0 <= param_2) {
    fVar3 = param_2;
  }
  fVar4 = DAT_019399c4;
  if (fVar3 <= DAT_019399c4) {
    fVar4 = fVar3;
  }
  puVar1 = *(uint **)(param_1 + 0x214);
  if ((NAN(fVar4) || NAN((float)(*puVar1 ^ (uint)puVar1))) ==
      (fVar4 == (float)(*puVar1 ^ (uint)puVar1))) {
    *puVar1 = (uint)fVar4 ^ (uint)puVar1;
    cVar2 = FUN_00f94320();
    if (cVar2 != '\0') {
      FUN_009b1bb0(&DAT_021222b0);
      return;
    }
    FUN_008a4940(&DAT_021222b0);
  }
  return;
}



/* FUNCTION 18801 ; VA 0x009c42c0 ; FUN_009c42c0 */

void __thiscall FUN_009c42c0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  char cVar2;
  int *piVar3;
  undefined4 *puVar4;
  
  piVar3 = *(int **)(param_1 + 0x28);
  puVar4 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar4 = (undefined4 *)*param_2;
  }
  piVar1 = piVar3 + 4;
  if (0xf < (uint)piVar3[5]) {
    piVar3 = (int *)*piVar3;
  }
  cVar2 = FUN_0055c360(piVar3,*piVar1,puVar4,param_2[4]);
  FUN_008a6520(param_2);
  if (cVar2 == '\0') {
    cVar2 = FUN_00fa0fb0(*(undefined4 *)(param_1 + 0x28),param_1,0);
    *(bool *)(param_1 + 0x290) = cVar2 == '\0';
  }
  return;
}



/* FUNCTION 18802 ; VA 0x009c4320 ; FUN_009c4320 */

void __thiscall FUN_009c4320(int param_1,float param_2)

{
  char cVar1;
  float fVar2;
  
  fVar2 = 0.0;
  if (0.0 <= param_2) {
    fVar2 = param_2;
  }
  if ((NAN(*(float *)(param_1 + 0x260)) || NAN(fVar2)) == (*(float *)(param_1 + 0x260) == fVar2)) {
    *(float *)(param_1 + 0x260) = fVar2;
    cVar1 = FUN_00f94320();
    if (cVar1 != '\0') {
      FUN_009b1bb0(&DAT_02123488);
      return;
    }
    FUN_008a4940(&DAT_02123488);
  }
  return;
}



/* FUNCTION 18803 ; VA 0x009c4390 ; FUN_009c4390 */

void __thiscall FUN_009c4390(int param_1,int param_2)

{
  char cVar1;
  
  if (param_2 != *(int *)(param_1 + 0x254)) {
    *(int *)(param_1 + 0x254) = param_2;
    cVar1 = FUN_00f94320();
    if (cVar1 != '\0') {
      FUN_009b1bb0(&DAT_021233c8);
      return;
    }
    FUN_008a4940(&DAT_021233c8);
  }
  return;
}



/* FUNCTION 18804 ; VA 0x009c43f0 ; FUN_009c43f0 */

void __thiscall FUN_009c43f0(int param_1,int param_2)

{
  char cVar1;
  
  if ((DAT_01ee37b0 != '\0') && (*(int *)(param_1 + 0x704) != param_2)) {
    *(int *)(param_1 + 0x704) = param_2;
    cVar1 = FUN_00f94320();
    if (cVar1 != '\0') {
      FUN_009b1bb0(&DAT_02122438);
      return;
    }
    FUN_008a4940(&DAT_02122438);
  }
  return;
}



/* FUNCTION 18805 ; VA 0x009c4450 ; FUN_009c4450 */

void __thiscall FUN_009c4450(int param_1,float param_2)

{
  char cVar1;
  
  if ((NAN(*(float *)(param_1 + 0x334)) || NAN(param_2)) == (*(float *)(param_1 + 0x334) == param_2)
     ) {
    *(float *)(param_1 + 0x334) = param_2;
    cVar1 = FUN_00f94320();
    if (cVar1 != '\0') {
      FUN_009b1bb0(&DAT_02122390);
      return;
    }
    FUN_008a4940(&DAT_02122390);
  }
  return;
}



/* FUNCTION 18806 ; VA 0x009c44c0 ; FUN_009c44c0 */

void __thiscall FUN_009c44c0(int param_1,int param_2)

{
  char *pcVar1;
  char cVar2;
  
  pcVar1 = *(char **)(param_1 + 0x22c);
  if ((char)(*pcVar1 - (char)pcVar1) != (char)param_2) {
    *(char **)pcVar1 = pcVar1 + param_2;
    cVar2 = FUN_00f94320();
    if (cVar2 != '\0') {
      FUN_009b1bb0(&DAT_02122690);
      return;
    }
    FUN_008a4940(&DAT_02122690);
  }
  return;
}



/* FUNCTION 18807 ; VA 0x009c4520 ; FUN_009c4520 */

void __thiscall FUN_009c4520(int param_1,int param_2)

{
  if (param_2 != *(int *)(param_1 + 0x700)) {
    *(int *)(param_1 + 0x700) = param_2;
  }
  return;
}



/* FUNCTION 18808 ; VA 0x009c4540 ; FUN_009c4540 */

void __thiscall FUN_009c4540(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  
  piVar2 = param_3;
  if ((param_3 != (int *)0x0) &&
     (iVar1 = param_3[3], iVar3 = FUN_00aff8c0(),
     (uint)*(ushort *)(iVar3 + 0x1da) <
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    piVar6 = (int *)param_1[1];
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    if (param_2 == (int *)0x0) {
      param_2 = (int *)&DAT_018e3e8c;
    }
    else {
      (**(code **)(*param_2 + 0x10))();
      param_2 = (int *)FUN_005543f0();
    }
    (**(code **)(*piVar2 + 0x10))();
    uVar4 = FUN_005543f0();
    (**(code **)(*param_1 + 0x4c))();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Expected %s got %s for %s:%s.",uVar5,uVar4,param_2,piVar6);
  }
  param_3 = piVar2;
  (**(code **)(*(int *)param_1[0xe] + 0x10))(param_2,&param_3);
  return;
}



/* FUNCTION 18809 ; VA 0x009c45f0 ; FUN_009c45f0 */

void __thiscall FUN_009c45f0(int param_1,char param_2)

{
  char cVar1;
  
  if ((param_2 != *(char *)(param_1 + 0x23a)) &&
     (*(char *)(param_1 + 0x23a) = param_2, DAT_01d64a68 != '\0')) {
    if (param_2 == '\0') {
      *(undefined *)(param_1 + 0x2e4) = 0;
    }
    cVar1 = FUN_00f94320();
    if (cVar1 != '\0') {
      FUN_009b1bb0(&DAT_02122738);
      return;
    }
    FUN_008a4940(&DAT_02122738);
  }
  return;
}



/* FUNCTION 18810 ; VA 0x009c4660 ; FUN_009c4660 */

void __thiscall FUN_009c4660(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 in_stack_ffffffb4;
  undefined4 in_stack_ffffffb8;
  code *pcStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  uint uStack_2c;
  int iStack_28;
  uint uStack_24;
  uint uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5500;
  pvStack_10 = ExceptionList;
  if (param_2 != *(int *)(param_1 + 0x228)) {
    ExceptionList = &pvStack_10;
    *(int *)(param_1 + 0x228) = param_2;
    cVar3 = FUN_00f94320();
    if (cVar3 == '\0') {
      FUN_008a4940(&DAT_021228d0);
    }
    else {
      FUN_009b1bb0(&DAT_021228d0,in_stack_ffffffb4,in_stack_ffffffb8,&DAT_01d6505a);
    }
    if (*(int *)(param_1 + 0x34) != 0) {
      FUN_009bf2f0();
      FUN_008a4100();
      uStack_2c = uStack_24;
      uStack_1c = CONCAT31(uStack_1c._1_3_,1);
      uStack_24 = uStack_1c;
      pcStack_38 = FUN_009bc830;
      uStack_34 = 0xfffffecc;
      uStack_30 = 0;
      iStack_28 = param_1;
      uVar4 = FUN_0099e690(&iStack_14,&pcStack_38);
      uStack_8 = 0;
      cVar3 = FUN_01679300(uVar4);
      if (cVar3 != '\0') {
        FUN_01679490();
        FUN_016791c0(uVar4);
      }
      uStack_8 = 0xffffffff;
      if (iStack_14 != 0) {
        piVar1 = (int *)(iStack_14 + 4);
        LOCK();
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          FUN_01674ea0(iStack_14);
        }
      }
      FUN_008a4100();
      uStack_2c = uStack_24;
      uStack_1c = uStack_1c & 0xffffff00;
      uStack_24 = uStack_1c;
      pcStack_38 = FUN_009bc830;
      uStack_34 = 0xfffffecc;
      uStack_30 = 0;
      iStack_28 = param_1;
      uVar4 = FUN_0099e690(&iStack_18,&pcStack_38);
      uStack_8 = 1;
      cVar3 = FUN_01679300(uVar4);
      if (cVar3 != '\0') {
        FUN_01679490();
        FUN_016791c0(uVar4);
      }
      if (iStack_18 != 0) {
        piVar1 = (int *)(iStack_18 + 4);
        LOCK();
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          FUN_01674ea0(iStack_18);
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18811 ; VA 0x009c4830 ; FUN_009c4830 */

undefined4 * __thiscall FUN_009c4830(int param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (*(int *)(param_1 + 0x2d8) != 0) {
    *(undefined4 *)(param_1 + 0x2d8) = 0;
    piVar2 = *(int **)(param_1 + 0x2dc);
    *(undefined4 *)(param_1 + 0x2dc) = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar5 = piVar2[1] + -1;
      piVar2[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar5 = piVar2[2] + -1;
        piVar2[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  puVar6 = (undefined4 *)FUN_0060dcd0(auStack_c,param_2);
  uVar3 = *puVar6;
  uVar4 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  *(undefined4 *)(param_1 + 0x2d8) = uVar3;
  piVar2 = *(int **)(param_1 + 0x2dc);
  *(undefined4 *)(param_1 + 0x2dc) = uVar4;
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar5 = *piVar1;
    puVar6 = (undefined4 *)*piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1;
      puVar6 = (undefined4 *)*piVar1;
      *piVar1 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        puVar6 = (undefined4 *)(**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_8 + 1;
    iVar5 = *piVar2;
    puVar6 = (undefined4 *)*piVar2;
    *piVar2 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      puVar6 = (undefined4 *)(**(code **)*piStack_8)();
      LOCK();
      piVar2 = piStack_8 + 2;
      iVar5 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        puVar6 = (undefined4 *)(**(code **)(*piStack_8 + 4))();
      }
    }
  }
  return puVar6;
}



/* FUNCTION 18812 ; VA 0x009c4910 ; FUN_009c4910 */

void __thiscall FUN_009c4910(int param_1,char param_2)

{
  float fVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  float10 fVar8;
  uint auStack_50 [4];
  undefined4 uStack_40;
  float fStack_3c;
  ulonglong uStack_38;
  undefined8 uStack_30;
  undefined4 uStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5530;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 0x338) != '\0') {
    uStack_38 = (ulonglong)(uint)DAT_018ce2f8;
    cStack_11 = '\0';
    auStack_50[0] = auStack_50[0] & 0xffffff00;
    fStack_24 = DAT_018ce2f8;
    fStack_1c = DAT_018ce2f8;
    fStack_20 = DAT_018ce2f8;
    uStack_40 = 0;
    fStack_3c = 2.10195e-44;
    ExceptionList = &pvStack_10;
    iStack_18 = param_1;
    FUN_005542c0("BodyHeightScale",0xf);
    uStack_8 = 0;
    iVar4 = FUN_008a1240(auStack_50);
    if ((iVar4 == 0) ||
       (iVar2 = *(int *)(iVar4 + 0xc), iVar5 = FUN_00daf5e0(),
       (uint)*(ushort *)(iVar5 + 0x1da) <
       (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
      iVar4 = 0;
    }
    uStack_8 = 0xffffffff;
    if (0xf < (uint)fStack_3c) {
      uVar7 = (int)fStack_3c + 1;
      uVar6 = auStack_50[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_50[0] - 4);
        uVar7 = (int)fStack_3c + 0x24;
        if (0x1f < (auStack_50[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uStack_40 = 0;
    fStack_3c = 2.10195e-44;
    auStack_50[0] = auStack_50[0] & 0xffffff00;
    if (iVar4 != 0) {
      fVar8 = (float10)FUN_00cc2960();
      fStack_24 = (float)fVar8;
      uStack_30 = CONCAT44(fStack_24,(undefined4)uStack_30);
      if (fStack_24 < DAT_018daf54) {
        fStack_24 = DAT_018daf54;
        uStack_30 = DAT_01939930;
        FUN_00db5760(&uStack_30);
      }
      cStack_11 = '\x01';
    }
    uStack_40 = 0;
    fStack_3c = 2.10195e-44;
    auStack_50[0] = auStack_50[0] & 0xffffff00;
    FUN_005542c0("BodyWidthScale",0xe);
    uStack_8 = 1;
    iVar4 = FUN_008a1240(auStack_50);
    if ((iVar4 == 0) ||
       (iVar2 = *(int *)(iVar4 + 0xc), iVar5 = FUN_00daf5e0(),
       (uint)*(ushort *)(iVar5 + 0x1da) <
       (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
      iVar4 = 0;
    }
    uStack_8 = 0xffffffff;
    if (0xf < (uint)fStack_3c) {
      uVar7 = (int)fStack_3c + 1;
      uVar6 = auStack_50[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_50[0] - 4);
        uVar7 = (int)fStack_3c + 0x24;
        if (0x1f < (auStack_50[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uStack_40 = 0;
    fStack_3c = 2.10195e-44;
    auStack_50[0] = auStack_50[0] & 0xffffff00;
    if (iVar4 != 0) {
      fVar8 = (float10)FUN_00cc2960();
      fVar1 = (float)fVar8;
      uStack_30 = CONCAT44(fVar1,(undefined4)uStack_30);
      uStack_38 = (ulonglong)(uint)fVar1;
      if (fVar1 < DAT_018daf54) {
        uStack_38 = (ulonglong)(uint)DAT_018daf54;
        uStack_30 = DAT_01939930;
        FUN_00db5760(&uStack_30);
      }
      cStack_11 = '\x01';
    }
    uStack_40 = 0;
    fStack_3c = 2.10195e-44;
    auStack_50[0] = auStack_50[0] & 0xffffff00;
    FUN_005542c0("BodyDepthScale",0xe);
    uStack_8 = 2;
    iVar4 = FUN_008a1240(auStack_50);
    if ((iVar4 == 0) ||
       (iVar2 = *(int *)(iVar4 + 0xc), iVar5 = FUN_00daf5e0(),
       (uint)*(ushort *)(iVar5 + 0x1da) <
       (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
      iVar4 = 0;
    }
    uStack_8 = 0xffffffff;
    if (0xf < (uint)fStack_3c) {
      uVar7 = (int)fStack_3c + 1;
      uVar6 = auStack_50[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_50[0] - 4);
        uVar7 = (int)fStack_3c + 0x24;
        if (0x1f < (auStack_50[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uStack_40 = 0;
    fStack_3c = 2.10195e-44;
    auStack_50[0] = auStack_50[0] & 0xffffff00;
    if (iVar4 != 0) {
      fVar8 = (float10)FUN_00cc2960();
      fStack_1c = (float)fVar8;
      uStack_30 = CONCAT44(fStack_1c,(undefined4)uStack_30);
      if (fStack_1c < DAT_018daf54) {
        fStack_1c = DAT_018daf54;
        uStack_30 = DAT_01939930;
        FUN_00db5760(&uStack_30);
      }
      cStack_11 = '\x01';
    }
    uStack_40 = 0;
    fStack_3c = 2.10195e-44;
    auStack_50[0] = auStack_50[0] & 0xffffff00;
    FUN_005542c0("HeadScale",9);
    uStack_8 = 3;
    iVar4 = FUN_008a1240(auStack_50);
    if ((iVar4 == 0) ||
       (iVar2 = *(int *)(iVar4 + 0xc), iVar5 = FUN_00daf5e0(),
       (uint)*(ushort *)(iVar5 + 0x1da) <
       (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
      iVar4 = 0;
    }
    uStack_8 = 0xffffffff;
    if (0xf < (uint)fStack_3c) {
      uVar7 = (int)fStack_3c + 1;
      uVar6 = auStack_50[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_50[0] - 4);
        uVar7 = (int)fStack_3c + 0x24;
        if (0x1f < (auStack_50[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uStack_40 = 0;
    fStack_3c = 2.10195e-44;
    auStack_50[0] = auStack_50[0] & 0xffffff00;
    if (iVar4 != 0) {
      fVar8 = (float10)FUN_00cc2960();
      fStack_20 = (float)fVar8;
      uStack_30 = CONCAT44(fStack_20,(undefined4)uStack_30);
      if (fStack_20 < DAT_018daf54) {
        fStack_20 = DAT_018daf54;
        uStack_30 = DAT_01939930;
        FUN_00db5760(&uStack_30);
      }
      cStack_11 = '\x01';
    }
    if (DAT_01d641ec == '\0') {
      if ((param_2 != '\0') || (cStack_11 != '\0')) {
        fStack_3c = fStack_1c;
        FUN_009c1ba0(CONCAT44(fStack_24,(int)uStack_38),fStack_1c,fStack_20);
      }
    }
    else {
      uStack_30 = uStack_30 & 0xffffffff;
      uStack_28 = 0;
      cVar3 = FUN_009b3a80((int)&uStack_30 + 4,&uStack_28);
      if ((param_2 != '\0') || (cStack_11 != '\0' || cVar3 != '\0')) {
        fStack_3c = fStack_1c;
        FUN_009c2010(CONCAT44(fStack_24,(int)uStack_38),fStack_1c,fStack_20,uStack_30._4_4_,
                     uStack_28);
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18813 ; VA 0x009c4e40 ; FUN_009c4e40 */

void __thiscall FUN_009c4e40(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  char cVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  undefined *puVar8;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (*(int *)(param_1 + 0x194) != param_2) {
    puVar8 = auStack_c;
    uVar7 = 0x9c4e64;
    puVar6 = (undefined4 *)FUN_0060dcd0(puVar8,param_2);
    uVar1 = *puVar6;
    uVar2 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x194) = uVar1;
    piVar3 = *(int **)(param_1 + 0x198);
    *(undefined4 *)(param_1 + 0x198) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_8[1] + -1;
      piStack_8[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar3 = piStack_8 + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    cVar5 = FUN_00f94320();
    if (cVar5 != '\0') {
      FUN_009b1bb0(&DAT_021224c8,uVar7,puVar8,&DAT_01d6505a);
      return;
    }
    FUN_008a4940(&DAT_021224c8);
  }
  return;
}



/* FUNCTION 18814 ; VA 0x009c4f20 ; FUN_009c4f20 */

void __thiscall FUN_009c4f20(int param_1,char param_2)

{
  byte bVar1;
  char cVar2;
  byte bVar3;
  
  if ('\0' < *(char *)(param_1 + 0x21f) != (bool)param_2) {
    bVar1 = FUN_01679ce0();
    bVar1 = bVar1 & 0x7f;
    if (param_2 == '\0') {
      bVar3 = 1;
      if (bVar1 != 0) {
        bVar3 = bVar1;
      }
      bVar3 = -bVar3;
    }
    else {
      bVar3 = 1;
      if (bVar1 != 0) {
        bVar3 = bVar1;
      }
    }
    *(byte *)(param_1 + 0x21f) = bVar3;
    cVar2 = FUN_00f94320();
    if (cVar2 != '\0') {
      FUN_009b1bb0(&DAT_02122658);
      return;
    }
    FUN_008a4940(&DAT_02122658);
  }
  return;
}



/* FUNCTION 18815 ; VA 0x009c4fb0 ; FUN_009c4fb0 */

void __thiscall FUN_009c4fb0(int param_1,uint param_2,uint param_3)

{
  char cVar1;
  undefined4 in_stack_ffffffe0;
  uint uStack_8;
  
  if (0x10 < param_2) {
    FUN_0086f2f0(3,"Invalid state passed to SetStateEnabled.");
    return;
  }
  *(char *)(param_2 + 0x2a9 + param_1) = (char)param_3;
  cVar1 = FUN_00f94320();
  if (cVar1 != '\0') {
    uStack_8 = param_3 & 0xff;
    FUN_009b1bb0(param_2,uStack_8,in_stack_ffffffe0,&DAT_01d650ea);
    return;
  }
  FUN_005e66b0(param_2,param_3);
  return;
}



/* FUNCTION 18816 ; VA 0x009c5040 ; FUN_009c5040 */

void __thiscall FUN_009c5040(int param_1,char param_2)

{
  byte bVar1;
  char cVar2;
  byte bVar3;
  
  if ('\0' < *(char *)(param_1 + 0x221) != (bool)param_2) {
    bVar1 = FUN_01679ce0();
    bVar1 = bVar1 & 0x7f;
    if (param_2 == '\0') {
      bVar3 = 1;
      if (bVar1 != 0) {
        bVar3 = bVar1;
      }
      bVar3 = -bVar3;
    }
    else {
      bVar3 = 1;
      if (bVar1 != 0) {
        bVar3 = bVar1;
      }
    }
    *(byte *)(param_1 + 0x221) = bVar3;
    cVar2 = FUN_00f94320();
    if (cVar2 != '\0') {
      FUN_009b1bb0(&DAT_02122898);
      return;
    }
    FUN_008a4940(&DAT_02122898);
  }
  return;
}



/* FUNCTION 18817 ; VA 0x009c50d0 ; FUN_009c50d0 */

void __thiscall FUN_009c50d0(int param_1,float *param_2)

{
  char cVar1;
  int iVar2;
  double dVar3;
  double dVar4;
  double dVar5;
  float fVar6;
  float fVar7;
  uint uVar8;
  uint uVar9;
  float fVar10;
  float fVar11;
  
  if (*(int *)(param_1 + 0x228) == 0) {
    iVar2 = *(int *)(param_1 + 0x340);
  }
  else {
    iVar2 = *(int *)(param_1 + 0x3f0);
  }
  if (iVar2 == 0) {
    if (*(int *)(param_1 + 0x228) == 0) {
      iVar2 = *(int *)(param_1 + 0x370);
    }
    else {
      iVar2 = *(int *)(param_1 + 0x380);
    }
    if (iVar2 == 0) {
      fVar10 = *param_2;
      fVar6 = param_2[1];
      fVar11 = param_2[2];
      fVar7 = DAT_018ce2f8;
      goto LAB_009c51a0;
    }
  }
  iVar2 = FUN_00b077e0();
  fVar6 = param_2[1];
  fVar10 = *param_2;
  fVar11 = param_2[2];
  dVar3 = (double)(*(float *)(iVar2 + 0x28) - fVar6);
  uVar8 = (uint)DAT_018c0da0;
  uVar9 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  dVar4 = (double)(*(float *)(iVar2 + 0x24) - fVar10);
  dVar5 = (double)(*(float *)(iVar2 + 0x2c) - fVar11);
  fVar7 = (float)(double)CONCAT44((uint)((ulonglong)dVar3 >> 0x20) & uVar9,SUB84(dVar3,0) & uVar8) +
          (float)(double)CONCAT44((uint)((ulonglong)dVar4 >> 0x20) & uVar9,SUB84(dVar4,0) & uVar8) +
          (float)(double)CONCAT44((uint)((ulonglong)dVar5 >> 0x20) & uVar9,SUB84(dVar5,0) & uVar8);
  if (fVar7 <= DAT_018daf58) {
    fVar7 = DAT_018daf58;
  }
  fVar7 = fVar7 / DAT_018ce320;
LAB_009c51a0:
  dVar3 = (double)(fVar6 - *(float *)(param_1 + 0x1e4));
  uVar8 = (uint)DAT_018c0da0;
  uVar9 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  dVar4 = (double)(fVar10 - *(float *)(param_1 + 0x1e0));
  dVar5 = (double)(fVar11 - *(float *)(param_1 + 0x1e8));
  if (fVar7 < (float)(double)CONCAT44((uint)((ulonglong)dVar3 >> 0x20) & uVar9,
                                      SUB84(dVar3,0) & uVar8) +
              (float)(double)CONCAT44((uint)((ulonglong)dVar4 >> 0x20) & uVar9,
                                      SUB84(dVar4,0) & uVar8) +
              (float)(double)CONCAT44((uint)((ulonglong)dVar5 >> 0x20) & uVar9,
                                      SUB84(dVar5,0) & uVar8)) {
    *(undefined8 *)(param_1 + 0x1d4) = *(undefined8 *)param_2;
    *(float *)(param_1 + 0x1dc) = param_2[2];
    *(undefined8 *)(param_1 + 0x1e0) = *(undefined8 *)param_2;
    *(float *)(param_1 + 0x1e8) = param_2[2];
    cVar1 = FUN_00f94320();
    if (cVar1 != '\0') {
      FUN_009b1bb0(&DAT_021225b0);
      return;
    }
    FUN_008a4940(&DAT_021225b0);
  }
  return;
}



/* FUNCTION 18818 ; VA 0x009c5250 ; FUN_009c5250 */

void __thiscall FUN_009c5250(int param_1,float *param_2)

{
  int iVar1;
  double dVar2;
  double dVar3;
  double dVar4;
  float fVar5;
  float fVar6;
  uint uVar7;
  uint uVar8;
  float fVar9;
  float fVar10;
  
  if (*(int *)(param_1 + 0x228) == 0) {
    iVar1 = *(int *)(param_1 + 0x340);
  }
  else {
    iVar1 = *(int *)(param_1 + 0x3f0);
  }
  if (iVar1 == 0) {
    if (*(int *)(param_1 + 0x228) == 0) {
      iVar1 = *(int *)(param_1 + 0x370);
    }
    else {
      iVar1 = *(int *)(param_1 + 0x380);
    }
    if (iVar1 == 0) {
      fVar9 = *param_2;
      fVar5 = param_2[1];
      fVar10 = param_2[2];
      fVar6 = DAT_018ce2f8;
      goto LAB_009c5320;
    }
  }
  iVar1 = FUN_00b077e0();
  fVar5 = param_2[1];
  fVar9 = *param_2;
  fVar10 = param_2[2];
  dVar2 = (double)(*(float *)(iVar1 + 0x28) - fVar5);
  uVar7 = (uint)DAT_018c0da0;
  uVar8 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  dVar3 = (double)(*(float *)(iVar1 + 0x24) - fVar9);
  dVar4 = (double)(*(float *)(iVar1 + 0x2c) - fVar10);
  fVar6 = (float)(double)CONCAT44((uint)((ulonglong)dVar2 >> 0x20) & uVar8,SUB84(dVar2,0) & uVar7) +
          (float)(double)CONCAT44((uint)((ulonglong)dVar3 >> 0x20) & uVar8,SUB84(dVar3,0) & uVar7) +
          (float)(double)CONCAT44((uint)((ulonglong)dVar4 >> 0x20) & uVar8,SUB84(dVar4,0) & uVar7);
  if (fVar6 <= DAT_018daf58) {
    fVar6 = DAT_018daf58;
  }
  fVar6 = fVar6 / DAT_018ce320;
LAB_009c5320:
  dVar2 = (double)(fVar5 - *(float *)(param_1 + 0x1d8));
  uVar7 = (uint)DAT_018c0da0;
  uVar8 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  dVar3 = (double)(fVar9 - *(float *)(param_1 + 0x1d4));
  dVar4 = (double)(fVar10 - *(float *)(param_1 + 0x1dc));
  if (fVar6 < (float)(double)CONCAT44((uint)((ulonglong)dVar2 >> 0x20) & uVar8,
                                      SUB84(dVar2,0) & uVar7) +
              (float)(double)CONCAT44((uint)((ulonglong)dVar3 >> 0x20) & uVar8,
                                      SUB84(dVar3,0) & uVar7) +
              (float)(double)CONCAT44((uint)((ulonglong)dVar4 >> 0x20) & uVar8,
                                      SUB84(dVar4,0) & uVar7)) {
    *(undefined8 *)(param_1 + 0x1d4) = *(undefined8 *)param_2;
    *(float *)(param_1 + 0x1dc) = param_2[2];
  }
  return;
}



/* FUNCTION 18819 ; VA 0x009c5380 ; FUN_009c5380 */

void __thiscall FUN_009c5380(int param_1,char param_2)

{
  char cVar1;
  
  if (param_2 != *(char *)(param_1 + 0x20c)) {
    *(char *)(param_1 + 0x20c) = param_2;
    cVar1 = FUN_00f94320();
    if (cVar1 != '\0') {
      FUN_009b1bb0(&DAT_02122240);
      return;
    }
    FUN_008a4940(&DAT_02122240);
  }
  return;
}



/* FUNCTION 18820 ; VA 0x009c53e0 ; FUN_009c53e0 */

void __thiscall FUN_009c53e0(int param_1,undefined4 param_2,undefined4 param_3)

{
  code *pcVar1;
  
  pcVar1 = *(code **)(param_1 + 0x18);
  FUN_0054ef60(param_3);
  (*pcVar1)();
  return;
}



/* FUNCTION 18821 ; VA 0x009c5420 ; FUN_009c5420 */

void __thiscall FUN_009c5420(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(param_1 + 0x18))(param_3);
  return;
}



/* FUNCTION 18822 ; VA 0x009c5450 ; FUN_009c5450 */

void __thiscall FUN_009c5450(int param_1,undefined4 param_2,undefined8 *param_3)

{
  (**(code **)(param_1 + 0x18))(*param_3,*(undefined4 *)(param_3 + 1));
  return;
}



/* FUNCTION 18823 ; VA 0x009c5490 ; FUN_009c5490 */

void __thiscall FUN_009c5490(int param_1,undefined4 param_2,undefined4 *param_3)

{
  (**(code **)(param_1 + 0x18))(*param_3);
  return;
}



/* FUNCTION 18824 ; VA 0x009c54d0 ; FUN_009c54d0 */

void __thiscall FUN_009c54d0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  (**(code **)(param_1 + 0x18))(*param_3);
  return;
}



/* FUNCTION 18825 ; VA 0x009c5510 ; FUN_009c5510 */

void __thiscall FUN_009c5510(int param_1,undefined4 param_2,undefined *param_3)

{
  (**(code **)(param_1 + 0x18))(*param_3);
  return;
}



/* FUNCTION 18826 ; VA 0x009c5550 ; FUN_009c5550 */

void __thiscall FUN_009c5550(int param_1,undefined4 param_2,undefined4 *param_3)

{
  (**(code **)(param_1 + 0x18))(*param_3);
  return;
}



/* FUNCTION 18827 ; VA 0x009c5590 ; FUN_009c5590 */

void __thiscall FUN_009c5590(int param_1,undefined4 param_2,undefined4 *param_3)

{
  (**(code **)(param_1 + 0x18))(*param_3);
  return;
}



/* FUNCTION 18828 ; VA 0x009c55d0 ; FUN_009c55d0 */

void __thiscall FUN_009c55d0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_009c63c0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18829 ; VA 0x009c5620 ; FUN_009c5620 */

void __thiscall FUN_009c5620(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_009c6470();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18830 ; VA 0x009c5670 ; FUN_009c5670 */

void __thiscall FUN_009c5670(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_009c6520();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18831 ; VA 0x009c56c0 ; FUN_009c56c0 */

void __thiscall FUN_009c56c0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_0098d050();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18832 ; VA 0x009c5710 ; FUN_009c5710 */

void __thiscall FUN_009c5710(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_009c6680();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18833 ; VA 0x009c5760 ; FUN_009c5760 */

void __thiscall FUN_009c5760(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_00896e70();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18834 ; VA 0x009c57b0 ; FUN_009c57b0 */

void __thiscall FUN_009c57b0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_009c67e0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18835 ; VA 0x009c5800 ; FUN_009c5800 */

void __thiscall FUN_009c5800(int param_1,float *param_2)

{
  float fVar1;
  
  fVar1 = *param_2;
  if ((NAN(*(float *)(param_1 + 0x1ec)) || NAN(fVar1)) == (*(float *)(param_1 + 0x1ec) == fVar1)) {
    *(float *)(param_1 + 0x1ec) = fVar1;
  }
  return;
}



/* FUNCTION 18836 ; VA 0x009c5830 ; FUN_009c5830 */

void __thiscall FUN_009c5830(int param_1,float *param_2)

{
  char cVar1;
  undefined8 *puVar2;
  float fVar3;
  double dVar4;
  uint uVar5;
  float in_stack_ffffffdc;
  undefined4 *in_stack_ffffffe0;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  fVar3 = *param_2;
  dVar4 = (double)(fVar3 - *(float *)(param_1 + 0x1b0));
  uVar5 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  if ((DAT_018f76ac <
       (float)(double)CONCAT44((uint)((ulonglong)dVar4 >> 0x20) & uVar5,
                               SUB84(dVar4,0) & (uint)DAT_018c0da0)) ||
     (dVar4 = (double)(param_2[2] - *(float *)(param_1 + 0x1b8)),
     DAT_018f76ac <
     (float)(double)CONCAT44((uint)((ulonglong)dVar4 >> 0x20) & uVar5,
                             SUB84(dVar4,0) & (uint)DAT_018c0da0))) {
    if (DAT_01ee41ed != '\0') {
      in_stack_ffffffe0 = (undefined4 *)param_2[2];
      in_stack_ffffffdc = param_2[1];
      FUN_016774d0(DAT_01ee41ed,"Setting walking direction: %f %f %f",fVar3,in_stack_ffffffdc,
                   in_stack_ffffffe0,0);
      fVar3 = *param_2;
    }
    if (((NAN(fVar3) == (fVar3 == 0.0)) || (NAN(param_2[1]) == (param_2[1] == 0.0))) ||
       (NAN(param_2[2]) == (param_2[2] == 0.0))) {
      if (fVar3 * fVar3 + param_2[1] * param_2[1] + param_2[2] * param_2[2] <= DAT_018ce2f8) {
        *(undefined8 *)(param_1 + 0x1b0) = *(undefined8 *)param_2;
        fVar3 = param_2[2];
      }
      else {
        in_stack_ffffffe0 = &uStack_10;
        in_stack_ffffffdc = 1.4358349e-38;
        puVar2 = (undefined8 *)FUN_00c94eb0(in_stack_ffffffe0,param_2);
        *(undefined8 *)(param_1 + 0x1b0) = *puVar2;
        fVar3 = *(float *)(puVar2 + 1);
      }
      *(undefined *)(param_1 + 0x292) = 0;
    }
    else {
      *(undefined8 *)(param_1 + 0x1b0) = *(undefined8 *)param_2;
      fVar3 = param_2[2];
    }
    *(float *)(param_1 + 0x1b8) = fVar3;
    cVar1 = FUN_00f94320();
    if (cVar1 == '\0') {
      FUN_008a4940(&DAT_021227f0);
    }
    else {
      FUN_009b1bb0(&DAT_021227f0,in_stack_ffffffdc,in_stack_ffffffe0,&DAT_01d6505a);
    }
  }
  if (((NAN(*(float *)(param_1 + 0x1b0)) == (*(float *)(param_1 + 0x1b0) == 0.0)) ||
      (NAN(*(float *)(param_1 + 0x1b4)) == (*(float *)(param_1 + 0x1b4) == 0.0))) ||
     (NAN(*(float *)(param_1 + 0x1b8)) == (*(float *)(param_1 + 0x1b8) == 0.0))) {
    uStack_10 = 0;
    uStack_c = 0;
    uStack_8 = 0;
    FUN_009c3ea0(&uStack_10);
  }
  return;
}



/* FUNCTION 18837 ; VA 0x009c5a10 ; FUN_009c5a10 */

uint __thiscall FUN_009c5a10(int param_1,byte param_2)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  undefined8 uVar7;
  
  uVar6 = (uint)param_2;
  uVar7 = DAT_019399b8;
  if (param_2 == 0) {
    uVar7 = 0;
  }
  *(undefined8 *)(param_1 + 0x298) = uVar7;
  *(byte *)(param_1 + 0x292) = param_2;
  if (param_2 == 0) {
    *(undefined4 *)(param_1 + 0x2a0) = 0;
    piVar5 = *(int **)(param_1 + 0x2a4);
    *(undefined4 *)(param_1 + 0x2a4) = 0;
    if (piVar5 != (int *)0x0) {
      LOCK();
      puVar1 = (uint *)(piVar5 + 1);
      uVar3 = *puVar1;
      uVar6 = *puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        uVar6 = (**(code **)*piVar5)();
        LOCK();
        piVar2 = piVar5 + 2;
        iVar4 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          uVar6 = (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  return uVar6;
}



/* FUNCTION 18838 ; VA 0x009c5a80 ; FUN_009c5a80 */

void __thiscall FUN_009c5a80(int param_1,float param_2)

{
  int *piVar1;
  char cVar2;
  float fVar3;
  
  fVar3 = 0.0;
  if (0.0 <= param_2) {
    fVar3 = param_2;
  }
  piVar1 = *(int **)(param_1 + 0x1f0);
  if ((NAN(fVar3) || NAN((float)(*piVar1 + (int)piVar1))) ==
      (fVar3 == (float)(*piVar1 + (int)piVar1))) {
    *piVar1 = (int)fVar3 - (int)piVar1;
    **(uint **)(param_1 + 500) = (uint)fVar3 ^ (uint)*(uint **)(param_1 + 500);
    cVar2 = FUN_00f94320();
    if (cVar2 != '\0') {
      FUN_009b1bb0(&DAT_02122198);
      return;
    }
    FUN_008a4940(&DAT_02122198);
  }
  return;
}



/* FUNCTION 18839 ; VA 0x009c5b10 ; FUN_009c5b10 */

void __thiscall FUN_009c5b10(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  char cVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  undefined *puVar8;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (*(int *)(param_1 + 0x19c) != param_2) {
    puVar8 = auStack_c;
    uVar7 = 0x9c5b34;
    puVar6 = (undefined4 *)FUN_0060dcd0(puVar8,param_2);
    uVar1 = *puVar6;
    uVar2 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x19c) = uVar1;
    piVar3 = *(int **)(param_1 + 0x1a0);
    *(undefined4 *)(param_1 + 0x1a0) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_8[1] + -1;
      piStack_8[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar3 = piStack_8 + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    cVar5 = FUN_00f94320();
    if (cVar5 == '\0') {
      FUN_008a4940(&DAT_0212253c);
    }
    else {
      FUN_009b1bb0(&DAT_0212253c,uVar7,puVar8,&DAT_01d6505a);
    }
  }
  FUN_009c5a10(*(undefined *)(param_1 + 0x292));
  return;
}



/* FUNCTION 18840 ; VA 0x009c5c00 ; FUN_009c5c00 */

void __thiscall FUN_009c5c00(int param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  char cVar3;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  fVar1 = *(float *)(param_1 + 0x1a4);
  fVar2 = *param_2;
  if (DAT_01d64aa0 == '\0') {
    if ((((NAN(fVar1) || NAN(fVar2)) != (fVar1 == fVar2)) &&
        ((NAN(*(float *)(param_1 + 0x1a8)) || NAN(param_2[1])) !=
         (*(float *)(param_1 + 0x1a8) == param_2[1]))) &&
       ((NAN(*(float *)(param_1 + 0x1ac)) || NAN(param_2[2])) !=
        (*(float *)(param_1 + 0x1ac) == param_2[2]))) goto LAB_009c5ccd;
  }
  else if ((((NAN(fVar1) || NAN(fVar2)) != (fVar1 == fVar2)) &&
           ((NAN(*(float *)(param_1 + 0x1a8)) || NAN(param_2[1])) !=
            (*(float *)(param_1 + 0x1a8) == param_2[1]))) &&
          ((NAN(*(float *)(param_1 + 0x1ac)) || NAN(param_2[2])) !=
           (*(float *)(param_1 + 0x1ac) == param_2[2]))) {
    return;
  }
  *(undefined8 *)(param_1 + 0x1a4) = *(undefined8 *)param_2;
  *(float *)(param_1 + 0x1ac) = param_2[2];
  cVar3 = FUN_00f94320();
  if (cVar3 == '\0') {
    FUN_008a4940(&DAT_02122578);
  }
  else {
    FUN_009b1bb0(&DAT_02122578);
  }
LAB_009c5ccd:
  *(undefined8 *)(param_1 + 0x298) = DAT_019399b8;
  *(undefined *)(param_1 + 0x292) = 1;
  uStack_10 = 0;
  uStack_c = 0;
  uStack_8 = 0;
  FUN_009c3ea0(&uStack_10);
  return;
}



/* FUNCTION 18841 ; VA 0x009c5d10 ; FUN_009c5d10 */

int * __fastcall FUN_009c5d10(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  undefined4 uVar7;
  undefined auStack_10 [4];
  int *piStack_c;
  int iStack_8;
  
  piVar6 = *(int **)(param_1 + 0x708);
  piVar2 = (int *)(param_1 + 0x708);
  iStack_8 = param_1;
  if ((((piVar6 != (int *)0x0) && (piVar6[0xd] == 0)) && (*(char *)((int)piVar6 + 0x22) != '\0')) &&
     (piVar6 = (int *)FUN_0099fa10(), piVar6 != (int *)0x0)) {
    uVar7 = FUN_0060dcd0(auStack_10,piVar6);
    FUN_005587e0(uVar7);
    piVar6 = (int *)FUN_00550b30();
  }
  if (*piVar2 == 0) {
    uVar7 = FUN_0099fa10();
    piVar6 = (int *)FUN_0060dcd0(auStack_10,uVar7);
    iVar3 = *piVar6;
    iVar4 = piVar6[1];
    *piVar6 = 0;
    piVar6[1] = 0;
    *piVar2 = iVar3;
    piVar5 = *(int **)(param_1 + 0x70c);
    *(int *)(param_1 + 0x70c) = iVar4;
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar1 = piVar5 + 1;
      iVar3 = *piVar1;
      piVar6 = (int *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar3 = *piVar1;
        piVar6 = (int *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          piVar6 = (int *)(**(code **)(*piVar5 + 4))();
        }
      }
    }
    piVar5 = piStack_c;
    if (piStack_c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_c + 1;
      iVar3 = *piVar1;
      piVar6 = (int *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar3 = *piVar1;
        piVar6 = (int *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          piVar6 = (int *)(**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (*piVar2 == 0) {
      uVar7 = FUN_0099efd0(auStack_10);
      FUN_005587e0(uVar7);
      if (piStack_c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_c[1] + -1;
        piStack_c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_c)();
          LOCK();
          piVar2 = piStack_c + 2;
          iVar3 = *piVar2;
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piStack_c + 4))();
          }
        }
      }
      piVar6 = (int *)FUN_008a65e0(iStack_8,0);
    }
  }
  return piVar6;
}



/* FUNCTION 18842 ; VA 0x009c5e40 ; FUN_009c5e40 */

undefined __thiscall
FUN_009c5e40(int param_1,undefined4 param_2,int *param_3,int param_4,int *param_5,char param_6,
            char *param_7,int *param_8,uint param_9)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  char *pcVar6;
  undefined4 uVar7;
  undefined uVar8;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d5550;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  iVar4 = param_4;
  ExceptionList = &pvStack_10;
  if (param_4 == 0) {
    ExceptionList = &pvStack_10;
    iVar4 = FUN_008f7870(param_1);
  }
  *param_5 = iVar4;
  if (iVar4 == 0) {
    uVar7 = 0x38;
    pcVar6 = "Humanoid::ApplyDescription() DataModel was not available";
  }
  else {
    if ((*(int *)(iVar4 + 0x4a0) == 2) || (*(int *)(iVar4 + 0x4a0) == 3)) {
      cVar3 = '\x01';
    }
    else {
      cVar3 = '\0';
    }
    *param_7 = cVar3;
    if ((param_6 == '\0') || (cVar3 != '\0')) {
      piVar5 = (int *)FUN_00917080(auStack_18,&param_2);
      iVar4 = *piVar5;
      iVar2 = piVar5[1];
      *piVar5 = 0;
      piVar5[1] = 0;
      *param_8 = iVar4;
      piVar5 = (int *)param_8[1];
      param_8[1] = iVar2;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar4 = piVar5[1] + -1;
        piVar5[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar4 = piVar5[2] + -1;
          piVar5[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_14[1] + -1;
        piStack_14[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_14)();
          LOCK();
          iVar4 = piStack_14[2] + -1;
          piStack_14[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piStack_14 + 4))();
          }
        }
      }
      if (*param_8 == 0) {
        uVar7 = 0x38;
        pcVar6 = "Humanoid::ApplyDescription() got nil humanoidDescription";
      }
      else {
        cVar3 = FUN_00e2ea50();
        if (cVar3 == '\0') {
          if ((-(uint)(*param_5 != 0) & *param_5 + 0xcU) != 0) {
            FUN_0063f510();
          }
          cVar3 = FUN_00bb4380(param_1);
          if (cVar3 == '\0') {
            FUN_00bb37f0(*(int *)(param_1 + 0x228) != 0);
          }
          uVar8 = 1;
          goto LAB_009c5fcc;
        }
        uVar7 = 0x62;
        pcVar6 = 
        "Humanoid::ApplyDescription() HumanoidDescription has the same asset used in more than one property"
        ;
      }
    }
    else {
      uVar7 = 0x45;
      pcVar6 = "Humanoid::ApplyDescription() can only be called by the backend server";
    }
  }
  uVar8 = 0;
  FUN_005542c0(pcVar6,uVar7);
  FUN_005e65e0(uVar8);
  uVar8 = 0;
LAB_009c5fcc:
  piVar5 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar4 = param_3[1] + -1;
    param_3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  uStack_8 = 2;
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_9 & 0xfffffffe))(&stack0x00000028,&stack0x00000028,2);
  }
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 18843 ; VA 0x009c6030 ; FUN_009c6030 */

int * __thiscall FUN_009c6030(int *param_1,int param_2)

{
  undefined4 **ppuVar1;
  int iVar2;
  undefined4 **ppuVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  int iStack_20;
  code *pcStack_1c;
  undefined4 **ppuStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d5568;
  pvStack_10 = ExceptionList;
  puStack_28 = (undefined4 *)0x0;
  puStack_24 = (undefined4 *)0x0;
  iStack_20 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  if ((param_1 != (int *)0x0) && (ExceptionList = &pvStack_10, param_1[0xd] != 0)) {
    iVar2 = *(int *)(param_1[0xd] + 0xc);
    ExceptionList = &pvStack_10;
    iVar4 = FUN_00b63e30();
    param_1 = (int *)(uint)*(ushort *)(iVar4 + 0x1da);
    if ((int *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) <= param_1) {
      ppuStack_18 = &puStack_28;
      pcStack_1c = FUN_009abd70;
      param_1 = (int *)FUN_00917910(&pcStack_1c);
    }
  }
  if ((param_2 != 0) && (param_1 = (int *)FUN_005cf750(), param_1 != (int *)0x0)) {
    param_1 = (int *)FUN_00980300(&pcStack_1c);
    ppuVar3 = ppuStack_18;
    iVar2 = *param_1;
    if (ppuStack_18 != (undefined4 **)0x0) {
      LOCK();
      ppuVar1 = ppuStack_18 + 1;
      puVar6 = *ppuVar1;
      param_1 = *ppuVar1;
      *ppuVar1 = (undefined4 *)((int)puVar6 + -1);
      UNLOCK();
      if ((undefined4 *)((int)puVar6 + -1) == (undefined4 *)0x0) {
        param_1 = (int *)(*(code *)**ppuVar3)();
        LOCK();
        ppuVar1 = ppuVar3 + 2;
        puVar6 = *ppuVar1;
        *ppuVar1 = (undefined4 *)((int)*ppuVar1 + -1);
        UNLOCK();
        if (puVar6 == (undefined4 *)0x1) {
          param_1 = (int *)(*(code *)(*ppuVar3)[1])();
        }
      }
    }
    if (iVar2 != 0) {
      uVar7 = 0;
      uVar5 = (uint)((int)puStack_24 + (3 - (int)puStack_28)) >> 2;
      if (puStack_24 < puStack_28) {
        uVar5 = 0;
      }
      puVar6 = puStack_28;
      if (uVar5 != 0) {
        do {
          param_1 = (int *)FUN_009c8840(*puVar6,iVar2);
          puVar6 = puVar6 + 1;
          uVar7 = uVar7 + 1;
        } while (uVar7 != uVar5);
      }
    }
  }
  if (puStack_28 != (undefined4 *)0x0) {
    uVar5 = iStack_20 - (int)puStack_28 & 0xfffffffc;
    puVar6 = puStack_28;
    if (0xfff < uVar5) {
      puVar6 = (undefined4 *)puStack_28[-1];
      uVar5 = uVar5 + 0x23;
      if (0x1f < (uint)((int)puStack_28 + (-4 - (int)puVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    param_1 = (int *)FUN_01674ea0(puVar6,uVar5);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18844 ; VA 0x009c6180 ; FUN_009c6180 */

undefined __fastcall FUN_009c6180(int param_1)

{
  if (((*(char *)(param_1 + 0x239) != '\0') && (*(char *)(param_1 + 0x2e4) != '\0')) &&
     (*(char *)(param_1 + 0x2e5) != '\0')) {
    return 1;
  }
  return 0;
}



/* FUNCTION 18845 ; VA 0x009c61b0 ; FUN_009c61b0 */

undefined4 __thiscall FUN_009c61b0(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  undefined *puVar6;
  int *piVar7;
  float10 fVar8;
  float10 extraout_ST0;
  float10 extraout_ST0_00;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar3 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af1f8;
  pvStack_10 = ExceptionList;
  if (param_2 == 0) {
    return 0;
  }
  ExceptionList = &pvStack_10;
  iVar5 = (**(code **)(*(int *)(param_1 + 0x54) + 0x44))();
  if (((param_2 != -0x50) && (iVar5 != 0)) && (iVar2 = *(int *)(param_2 + 0x70), iVar2 != 0)) {
    cVar4 = FUN_00f94350();
    if (cVar4 == '\0') {
      if (*(char *)(iVar2 + 0x3d) == '\0') {
        fVar8 = (float10)FUN_009b46f0();
        FUN_009b46f0();
        if ((float)fVar8 < (float)extraout_ST0_00) {
          ExceptionList = pvStack_10;
          return 1;
        }
      }
    }
    else if (*(char *)(iVar2 + 0x3d) == '\0') {
      fVar8 = (float10)FUN_009b4200(iVar2);
      FUN_009b4200(iVar5);
      if ((float)fVar8 < (float)extraout_ST0) {
        ExceptionList = pvStack_10;
        return 1;
      }
    }
  }
  iVar5 = FUN_00c155c0();
  if (iVar5 == 0) {
    ExceptionList = pvStack_10;
    return 0;
  }
  if (*(int *)(param_2 + 0x1a8) == 0) {
    ExceptionList = pvStack_10;
    return 0;
  }
  piVar7 = *(int **)(param_1 + 0x2cc);
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar7[1] = piVar7[1] + 1;
    UNLOCK();
    piVar7 = *(int **)(param_1 + 0x2cc);
  }
  uStack_8 = 0;
  param_2 = 0;
  if ((*(int *)(param_1 + 0x2c8) != 0) && (*(int *)(*(int *)(param_1 + 0x2c8) + 0xa8) != 0)) {
    param_2 = FUN_00c155c0();
  }
  iVar5 = FUN_00c155c0();
  if (((param_2 != 0) && (iVar5 != 0)) &&
     ((iVar5 = FUN_00ca1550(), iVar5 != 0 && (iVar5 = FUN_00ca1550(), iVar5 != 0)))) {
    uStack_8 = 0xffffffff;
    FUN_00550b30();
    if (*(int *)(param_1 + 0x2c8) != 0) {
      if ((*(int *)(param_1 + 0x2d8) == 0) || (iVar5 = FUN_00c155c0(), iVar5 == 0)) {
        iVar5 = FUN_00c155c0();
        if (iVar5 == 0) {
          puVar6 = &DAT_0000000c;
        }
        else {
          puVar6 = *(undefined **)(iVar5 + 0x3c);
        }
      }
      else {
        puVar6 = *(undefined **)(iVar5 + 0x3c);
      }
      if ((int)puVar6 < 5) {
        ExceptionList = pvStack_10;
        return 0;
      }
    }
    if (*(char *)(iVar3 + 0x223) != '\0') {
      ExceptionList = pvStack_10;
      return 0;
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  if (piVar7 != (int *)0x0) {
    LOCK();
    iVar3 = piVar7[1] + -1;
    piVar7[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar7)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 18846 ; VA 0x009c63c0 ; FUN_009c63c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009c63c0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5596;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee407c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee407c);
    if (DAT_01ee407c == -1) {
      uStack_8 = 0;
      FUN_009ca470("HumanoidCollisionType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee4018 = RBX::Reflection::EnumDesc<enum_RBX::Humanoid::CollisionType>::vftable;
      FUN_009caf20(&DAT_01d64f64,2);
      FUN_016f3654(&LAB_01886cb0);
      FUN_016f37bf(&DAT_01ee407c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee4018;
}



/* FUNCTION 18847 ; VA 0x009c6470 ; FUN_009c6470 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009c6470(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d55b6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee3fac) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee3fac);
    if (DAT_01ee3fac == -1) {
      uStack_8 = 0;
      FUN_009ca470("HumanoidDisplayDistanceType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee3f48 =
           RBX::Reflection::EnumDesc<enum_RBX::Humanoid::HumanoidDisplayDistanceType>::vftable;
      FUN_009caf20(&DAT_01d64f24,3);
      FUN_016f3654(&LAB_01886cd0);
      FUN_016f37bf(&DAT_01ee3fac);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee3f48;
}



/* FUNCTION 18848 ; VA 0x009c6520 ; FUN_009c6520 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009c6520(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d55d6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee3f44) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee3f44);
    if (DAT_01ee3f44 == -1) {
      uStack_8 = 0;
      FUN_009ca470("HumanoidHealthDisplayType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee3ee0 =
           RBX::Reflection::EnumDesc<enum_RBX::Humanoid::HumanoidHealthDisplayType>::vftable;
      FUN_009caf20(&DAT_01d64f3c,3);
      FUN_016f3654(&LAB_01886cf0);
      FUN_016f37bf(&DAT_01ee3f44);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee3ee0;
}



/* FUNCTION 18849 ; VA 0x009c65d0 ; FUN_009c65d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009c65d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d55f6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee3e74) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee3e74);
    if (DAT_01ee3e74 == -1) {
      uStack_8 = 0;
      FUN_009ca470(&DAT_01938ba4);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee3e10 = RBX::Reflection::EnumDesc<enum_RBX::Humanoid::Limb>::vftable;
      FUN_009caf20(&DAT_01d64f74,7);
      FUN_016f3654(&LAB_01886d10);
      FUN_016f37bf(&DAT_01ee3e74);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee3e10;
}



/* FUNCTION 18850 ; VA 0x009c6680 ; FUN_009c6680 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009c6680(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5616;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee4014) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee4014);
    if (DAT_01ee4014 == -1) {
      uStack_8 = 0;
      FUN_009ca470("NameOcclusion");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee3fb0 = RBX::Reflection::EnumDesc<enum_RBX::Humanoid::NameOcclusion>::vftable;
      FUN_009caf20(&DAT_01d64f0c,3);
      FUN_016f3654(&LAB_01886d30);
      FUN_016f37bf(&DAT_01ee4014);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee3fb0;
}



/* FUNCTION 18851 ; VA 0x009c6730 ; FUN_009c6730 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009c6730(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5636;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee3e0c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee3e0c);
    if (DAT_01ee3e0c == -1) {
      uStack_8 = 0;
      FUN_009ca470("BodyPartR15");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee3da8 = RBX::Reflection::EnumDesc<enum_RBX::Humanoid::R15PartType>::vftable;
      FUN_009caf20(&DAT_01d64fb0,0x11);
      FUN_016f3654(&LAB_01886d50);
      FUN_016f37bf(&DAT_01ee3e0c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee3da8;
}



/* FUNCTION 18852 ; VA 0x009c67e0 ; FUN_009c67e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * __fastcall FUN_009c67e0(undefined4 param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5656;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee40e4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee40e4,param_1);
    if (DAT_01ee40e4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("HumanoidStateType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      puVar4 = &DAT_019386a0;
      _DAT_01ee4080 = RBX::Reflection::EnumDesc<enum_RBX::HUMAN::StateType>::vftable;
      iVar3 = 0;
      iVar5 = 0x10;
      do {
        uVar1 = *puVar4;
        uVar2 = FUN_00dc3b10(uVar1);
        FUN_009cada0(uVar1,uVar2);
        iVar3 = iVar3 + 1;
        puVar4 = puVar4 + 1;
      } while (iVar3 != iVar5);
      FUN_009cada0(0x12,&DAT_0192ff80);
      FUN_016f3654(&LAB_01886d70);
      FUN_016f37bf(&DAT_01ee40e4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee4080;
}



/* FUNCTION 18853 ; VA 0x009c68d0 ; FUN_009c68d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009c68d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5676;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee3edc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee3edc);
    if (DAT_01ee3edc == -1) {
      uStack_8 = 0;
      FUN_009ca470(&DAT_018c3d40);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee3e78 = RBX::Reflection::EnumDesc<enum_RBX::Humanoid::Status>::vftable;
      FUN_009caf20(&DAT_01d65038,2);
      FUN_016f3654(&LAB_01886d90);
      FUN_016f37bf(&DAT_01ee3edc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee3e78;
}



/* FUNCTION 18854 ; VA 0x009c6980 ; FUN_009c6980 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009c6980(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d568c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee410c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee410c);
    if (DAT_01ee410c == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01ee40e8 = RBX::Reflection::RefType<class_RBX::PartInstance*>::vftable;
      FUN_016f3654(&LAB_01887330);
      FUN_016f37bf(&DAT_01ee410c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee40e8;
}



/* FUNCTION 18855 ; VA 0x009c6a30 ; FUN_009c6a30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009c6a30(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee411c) {
    FUN_016f3809(&DAT_01ee411c);
    if (DAT_01ee411c == -1) {
      _DAT_01ee4110 = FUN_005c65e0;
      _DAT_01ee4114 = FUN_005c65e0;
      _DAT_01ee4118 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee411c);
    }
  }
  return &DAT_01ee4110;
}



/* FUNCTION 18856 ; VA 0x009c6aa0 ; FUN_009c6aa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009c6aa0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee412c) {
    FUN_016f3809(&DAT_01ee412c);
    if (DAT_01ee412c == -1) {
      _DAT_01ee4120 = FUN_005c65e0;
      _DAT_01ee4124 = FUN_005c65e0;
      _DAT_01ee4128 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee412c);
    }
  }
  return &DAT_01ee4120;
}



/* FUNCTION 18857 ; VA 0x009c6b10 ; FUN_009c6b10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009c6b10(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee413c) {
    FUN_016f3809(&DAT_01ee413c);
    if (DAT_01ee413c == -1) {
      _DAT_01ee4130 = FUN_005c65e0;
      _DAT_01ee4134 = FUN_005c65e0;
      _DAT_01ee4138 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee413c);
    }
  }
  return &DAT_01ee4130;
}



/* FUNCTION 18858 ; VA 0x009c6b80 ; FUN_009c6b80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009c6b80(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee416c) {
    FUN_016f3809(&DAT_01ee416c);
    if (DAT_01ee416c == -1) {
      _DAT_01ee4160 = FUN_005c65e0;
      _DAT_01ee4164 = FUN_005c65e0;
      _DAT_01ee4168 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee416c);
    }
  }
  return &DAT_01ee4160;
}



/* FUNCTION 18859 ; VA 0x009c6bf0 ; FUN_009c6bf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009c6bf0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee418c) {
    FUN_016f3809(&DAT_01ee418c);
    if (DAT_01ee418c == -1) {
      _DAT_01ee4180 = FUN_005c65e0;
      _DAT_01ee4184 = FUN_005c65e0;
      _DAT_01ee4188 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee418c);
    }
  }
  return &DAT_01ee4180;
}



/* FUNCTION 18860 ; VA 0x009c6c60 ; FUN_009c6c60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009c6c60(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee417c) {
    FUN_016f3809(&DAT_01ee417c);
    if (DAT_01ee417c == -1) {
      _DAT_01ee4170 = FUN_005c65e0;
      _DAT_01ee4174 = FUN_005c65e0;
      _DAT_01ee4178 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee417c);
    }
  }
  return &DAT_01ee4170;
}



/* FUNCTION 18861 ; VA 0x009c6cd0 ; FUN_009c6cd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009c6cd0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee414c) {
    FUN_016f3809(&DAT_01ee414c);
    if (DAT_01ee414c == -1) {
      _DAT_01ee4140 = FUN_005c65e0;
      _DAT_01ee4144 = FUN_005c65e0;
      _DAT_01ee4148 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee414c);
    }
  }
  return &DAT_01ee4140;
}



/* FUNCTION 18862 ; VA 0x009c6d40 ; FUN_009c6d40 */

undefined * FUN_009c6d40(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d56ac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee3b30) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee3b30);
    if (DAT_01ee3b30 == -1) {
      uStack_8 = 0;
      FUN_009a2f90();
      FUN_016f37bf(&DAT_01ee3b30);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee3920;
}



/* FUNCTION 18863 ; VA 0x009c6dc0 ; FUN_009c6dc0 */

void __thiscall FUN_009c6dc0(int param_1,undefined8 param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  double dVar5;
  undefined auStack_10 [12];
  
  if ((*(char *)(param_1 + 0x292) != '\0') && (cVar4 = FUN_009ab310(), cVar4 != '\0')) {
    dVar5 = *(double *)(param_1 + 0x298) - (double)CONCAT17(param_2._7_1_,(undefined7)param_2);
    *(double *)(param_1 + 0x298) = dVar5;
    if (dVar5 <= 0.0) {
      *(undefined8 *)(param_1 + 0x298) = 0;
      *(undefined *)(param_1 + 0x292) = 0;
      *(undefined4 *)(param_1 + 0x2a0) = 0;
      piVar2 = *(int **)(param_1 + 0x2a4);
      *(undefined4 *)(param_1 + 0x2a4) = 0;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar3 = piVar2[1] + -1;
        piVar2[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      cVar4 = FUN_00f94320();
      if (cVar4 == '\0') {
        FUN_005e6780(0);
        return;
      }
LAB_009c6ef2:
      FUN_009b1bb0();
      return;
    }
    FUN_009b7850((int)&param_2 + 7,auStack_10);
    if (param_2._7_1_ != '\0') {
      *(undefined *)(param_1 + 0x292) = 0;
      *(undefined8 *)(param_1 + 0x298) = 0;
      *(undefined4 *)(param_1 + 0x2a0) = 0;
      piVar2 = *(int **)(param_1 + 0x2a4);
      *(undefined4 *)(param_1 + 0x2a4) = 0;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar3 = piVar2[1] + -1;
        piVar2[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      cVar4 = FUN_00f94320();
      if (cVar4 != '\0') goto LAB_009c6ef2;
      FUN_005e6780(1);
    }
  }
  return;
}



/* FUNCTION 18864 ; VA 0x009c6f30 ; FUN_009c6f30 */

void __fastcall FUN_009c6f30(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int aiStack_24 [2];
  
  if (*(int *)(param_1 + 0x6c8) != 0) {
    aiStack_24[1] = 0;
    aiStack_24[0] = *(int *)(param_1 + 0x6d4) + *(int *)(param_1 + 0x6c4) * 4;
    FUN_009af930();
    puVar4 = *(undefined4 **)(param_1 + 0x6d4);
    puVar1 = puVar4 + *(int *)(param_1 + 0x6c4);
    for (; puVar4 != puVar1; puVar4 = puVar4 + 1) {
      *puVar4 = 0;
    }
  }
  iVar2 = *(int *)(param_1 + 0x34);
  if (iVar2 != 0) {
    uVar8 = 0;
    aiStack_24[1] = 0x9c6f90;
    iVar5 = FUN_005d6c30();
    if (iVar5 != 0) {
      do {
        iVar5 = *(int *)(**(int **)(iVar2 + 0x2c) + uVar8 * 8);
        if (iVar5 != 0) {
          iVar3 = *(int *)(iVar5 + 0xc);
          aiStack_24[1] = 0x9c6fa8;
          iVar6 = FUN_00aff8c0();
          if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
              (uint)*(ushort *)(iVar6 + 0x1da)) {
            FUN_0060dcd0(aiStack_24,iVar5);
            FUN_009c8c80();
          }
        }
        uVar8 = uVar8 + 1;
        aiStack_24[1] = 0x9c6fe5;
        uVar7 = FUN_005d6c30();
      } while (uVar8 < uVar7);
    }
  }
  return;
}



/* FUNCTION 18865 ; VA 0x009c6ff0 ; FUN_009c6ff0 */

void __thiscall FUN_009c6ff0(int param_1,float param_2)

{
  char cVar1;
  int iVar2;
  
  if (*(int *)(param_1 + 0x228) == 0) {
    iVar2 = *(int *)(param_1 + 0x340);
  }
  else {
    iVar2 = *(int *)(param_1 + 0x3f0);
  }
  if (iVar2 == 0) {
    if (*(int *)(param_1 + 0x228) == 0) {
      iVar2 = *(int *)(param_1 + 0x370);
    }
    else {
      iVar2 = *(int *)(param_1 + 0x380);
    }
    if (iVar2 == 0) goto LAB_009c7036;
  }
  cVar1 = FUN_00d3fe80(iVar2);
  if (cVar1 != '\0') {
    return;
  }
LAB_009c7036:
  FUN_009c36b0((float)(**(uint **)(param_1 + 0x1fc) ^ (uint)*(uint **)(param_1 + 0x1fc)) - param_2);
  return;
}



/* FUNCTION 18866 ; VA 0x009c7070 ; FUN_009c7070 */

uint __thiscall FUN_009c7070(int param_1,uint param_2,int *param_3,uint param_4,int *param_5)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  code *pcStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d47f0;
  pvStack_10 = ExceptionList;
  uVar6 = param_1 - 0x134;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if ((((uVar6 == param_2) && (ExceptionList = &pvStack_10, uVar6 != param_4)) &&
      (ExceptionList = &pvStack_10, param_1 != 0x134)) &&
     (ExceptionList = &pvStack_10, *(int *)(param_1 + -0x100) != 0)) {
    iVar4 = *(int *)(*(int *)(param_1 + -0x100) + 0xc);
    ExceptionList = &pvStack_10;
    iVar5 = FUN_00b63e30();
    uVar6 = (uint)*(ushort *)(iVar5 + 0x1da);
    if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <= uVar6) {
      uStack_14 = 0;
      uStack_18 = 0;
      pcStack_1c = FUN_009c3d80;
      uVar6 = FUN_009a02b0(&pcStack_1c);
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_3 + 1);
    uVar3 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      puVar1 = (uint *)(param_3 + 2);
      uVar3 = *puVar1;
      uVar6 = *puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        uVar6 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_5 + 1);
    uVar3 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar6 = (**(code **)*param_5)();
      LOCK();
      piVar2 = param_5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uVar6 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 18867 ; VA 0x009c7160 ; FUN_009c7160 */

void FUN_009c7160(void)

{
  int iVar1;
  
  iVar1 = FUN_00dc39c0();
  if (iVar1 != 0) {
    FUN_00bc1c10(iVar1,0);
  }
  return;
}



/* FUNCTION 18868 ; VA 0x009c7190 ; FUN_009c7190 */

void __thiscall FUN_009c7190(int param_1,int param_2)

{
  if (((DAT_01d5a308 != '\0') && (*(int *)(param_2 + 0x10) != 0)) &&
     (*(int *)(param_1 + 0x7d4) != 0)) {
    FUN_008da850(param_2,1);
  }
  return;
}



/* FUNCTION 18869 ; VA 0x009c71c0 ; FUN_009c71c0 */

void __thiscall FUN_009c71c0(int param_1,int param_2)

{
  if (((DAT_01d5a308 != '\0') && (*(int *)(param_2 + 0x10) != 0)) &&
     (*(int *)(param_1 + 0x7d4) != 0)) {
    FUN_008da850(param_2,2);
  }
  return;
}



/* FUNCTION 18870 ; VA 0x009c71f0 ; FUN_009c71f0 */

void FUN_009c71f0(int *param_1,undefined4 *param_2,int *param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  int *piVar7;
  undefined4 *puVar8;
  undefined auStack_58 [24];
  undefined auStack_40 [24];
  int *piStack_28;
  int *piStack_24;
  undefined4 *puStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d56d8;
  pvStack_10 = ExceptionList;
  if (param_1 != (int *)0x0) {
    puVar8 = (undefined4 *)*param_3;
    puVar3 = (undefined4 *)puVar8[1];
    puVar6 = puVar8;
    if (*(char *)((int)puVar3 + 0xd) == '\0') {
      do {
        if ((int *)puVar3[4] < param_1) {
          puVar4 = (undefined4 *)puVar3[2];
        }
        else {
          puVar4 = (undefined4 *)*puVar3;
          puVar6 = puVar3;
        }
        puVar3 = puVar4;
      } while (*(char *)((int)puVar4 + 0xd) == '\0');
      if ((puVar6 != puVar8) && ((int *)puVar6[4] <= param_1)) {
        return;
      }
    }
    ExceptionList = &pvStack_10;
    FUN_00898570(&piStack_28,0,&param_1,param_1);
    piVar7 = param_1;
    (**(code **)(*param_1 + 0x40))(&piStack_28);
    iStack_8 = 0;
    if (piStack_28 != (int *)0x0) {
      puStack_20 = (undefined4 *)piStack_28[1];
      puVar8 = (undefined4 *)*piStack_28;
      if (puVar8 != puStack_20) {
        do {
          iStack_18 = FUN_009ab420(*puVar8);
          if (iStack_18 != 0) {
            FUN_0054ef60(*(undefined4 *)(iStack_18 + 0x28));
            iStack_8._0_1_ = 1;
            iVar5 = FUN_0058eea0("RigAttachment",0);
            if (iVar5 == -1) {
              iStack_8 = (uint)iStack_8._1_3_ << 8;
              FUN_005507b0();
            }
            else {
              FUN_0058c540(auStack_58,0,iVar5);
              iStack_8._0_1_ = 2;
              iVar5 = FUN_008a0cb0(auStack_58);
              if (iVar5 == 0) {
                puVar3 = (undefined4 *)*param_2;
                puVar6 = param_2;
                piVar7 = param_1;
                if (puVar3 != (undefined4 *)param_2[1]) {
                  do {
                    piVar1 = (int *)*puVar3;
                    if (((piVar1 != piVar7) &&
                        (iVar5 = FUN_008a1240(auStack_40), puVar6 = param_2, piVar7 = param_1,
                        iVar5 != 0)) &&
                       (iStack_14 = FUN_009ab420(iVar5), puVar6 = param_2, piVar7 = param_1,
                       iStack_14 != 0)) {
                      iVar5 = iStack_18;
                      if ((**(char **)(iStack_1c + 0x230) != (char)*(char **)(iStack_1c + 0x230)) &&
                         (cVar2 = FUN_00558b60(auStack_58,PTR_DAT_01d64a3c), iVar5 = iStack_18,
                         cVar2 != '\0')) {
                        FUN_009a7390(param_1,piVar1,iStack_18,iStack_14);
                      }
                      if ((char)param_4 != '\0') {
                        FUN_009ae640(auStack_58,iVar5,iStack_14);
                      }
                      FUN_009c71f0(piVar1,param_2,param_3,param_4,param_5,param_6,param_7,param_8);
                      break;
                    }
                    puVar3 = puVar3 + 1;
                  } while (puVar3 != (undefined4 *)puVar6[1]);
                }
                FUN_005507b0();
                iStack_8 = (uint)iStack_8._1_3_ << 8;
                FUN_005507b0();
                piVar7 = param_1;
              }
              else {
                FUN_005507b0();
                iStack_8 = (uint)iStack_8._1_3_ << 8;
                FUN_005507b0();
              }
            }
          }
          puVar8 = puVar8 + 2;
        } while (puVar8 != puStack_20);
      }
    }
    iStack_8 = 0xffffffff;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_24[1] + -1;
      piStack_24[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piStack_24 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    if (**(char **)(iStack_1c + 0x230) != (char)*(char **)(iStack_1c + 0x230)) {
      FUN_009c7f10(piVar7,param_5,param_6,param_7,param_8);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18871 ; VA 0x009c7460 ; FUN_009c7460 */

void __thiscall FUN_009c7460(int param_1,undefined4 param_2,float *param_3,float *param_4)

{
  int iVar1;
  char cVar2;
  float *pfVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  double dVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  ulonglong uStack_64;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  
  if ((*(int *)(param_1 + 0x3f8) != 0) &&
     (iVar1 = *(int *)(*(int *)(param_1 + 0x3f8) + 0xa8), iVar1 != 0)) {
    fVar4 = param_3[1] - param_4[1];
    fVar8 = *param_3 - *param_4;
    fVar11 = param_3[2] - param_4[2];
    fVar12 = fVar4 * fVar4 + fVar8 * fVar8 + fVar11 * fVar11;
    if (DAT_018ce2f0 < fVar12) {
      fStack_4c = fVar8;
      fStack_48 = fVar4;
      fStack_44 = fVar11;
      pfVar3 = (float *)FUN_00c157b0();
      fStack_40 = pfVar3[4];
      fStack_3c = pfVar3[5];
      fStack_38 = pfVar3[6];
      fStack_34 = pfVar3[7];
      fStack_30 = *pfVar3;
      fStack_2c = pfVar3[1];
      fStack_28 = pfVar3[2];
      fStack_24 = pfVar3[3];
      fStack_20 = pfVar3[8];
      fStack_1c = pfVar3[9];
      fStack_18 = pfVar3[10];
      fStack_14 = pfVar3[0xb];
      FUN_00b06640(iVar1);
      fStack_18 = param_3[1] - fStack_18;
      fStack_1c = *param_3 - fStack_1c;
      fStack_14 = param_3[2] - fStack_14;
      fVar13 = fStack_20 * fStack_14;
      fVar15 = fStack_30 * fStack_1c + fStack_24 * fStack_18 + fStack_38 * fStack_14;
      fStack_20 = fStack_2c * fStack_1c + fStack_40 * fStack_18 + fStack_34 * fStack_14;
      fStack_30 = fStack_28 * fStack_1c + fStack_3c * fStack_18 + fVar13;
      fStack_1c = fStack_2c;
      fStack_18 = fStack_2c;
      fStack_14 = fStack_2c;
      fStack_2c = fStack_28;
      fStack_24 = fStack_28;
      pfVar3 = (float *)FUN_00b082f0(&fStack_40);
      fVar14 = fStack_20 * 0.0;
      fVar9 = pfVar3[2] * DAT_018ce2f4;
      fVar5 = *pfVar3 * DAT_018ce2f4;
      uStack_64 = 0;
      fStack_5c = 0.0;
      fVar10 = fVar15 * fVar5 + fVar14;
      fVar6 = fStack_30 * fVar9 + fVar10;
      fVar13 = 0.0;
      if (fVar15 * 0.0 + fVar14 + fStack_30 * 0.0 < fVar6) {
        uStack_64 = (ulonglong)(uint)fVar5;
        fVar13 = fVar5;
        fStack_5c = fVar9;
      }
      fVar16 = pfVar3[2] * DAT_018f7864 * DAT_018ce2f4;
      if (fVar15 * fVar13 + fStack_20 * 0.0 + fStack_30 * fStack_5c < fStack_30 * fVar16 + fVar10) {
        uStack_64 = (ulonglong)(uint)fVar5;
        fVar13 = fVar5;
        fStack_5c = fVar16;
      }
      if (fVar15 * fVar13 + fStack_20 * 0.0 + fStack_30 * fStack_5c < fVar6) {
        uStack_64 = (ulonglong)(uint)fVar5;
        fVar13 = fVar5;
        fStack_5c = fVar9;
      }
      fVar5 = *pfVar3 * DAT_018f7864 * DAT_018ce2f4;
      if (fVar15 * fVar13 + fStack_20 * 0.0 + fStack_30 * fStack_5c <
          fVar15 * fVar5 + fVar14 + fStack_30 * fVar16) {
        uStack_64 = (ulonglong)(uint)fVar5;
        fStack_5c = fVar16;
      }
      fStack_58 = 0.0;
      fStack_54 = 0.0;
      fStack_50 = 0.0;
      cVar2 = FUN_009b32f0(param_2,param_1,&fStack_4c,&uStack_64,&fStack_58);
      if (cVar2 != '\0') {
        dVar7 = (double)fVar12;
        FUN_017267a0();
        fVar13 = DAT_018ce2f8 / (float)dVar7;
        dVar7 = (double)(fStack_54 * fStack_54 + fStack_58 * fStack_58 + fStack_50 * fStack_50);
        FUN_017267a0();
        fVar12 = (float)dVar7;
        fStack_44 = fVar11 * fVar13 * fVar12 + param_4[2];
        *(ulonglong *)param_3 =
             CONCAT44(fVar4 * fVar13 * fVar12 + param_4[1],fVar8 * fVar13 * fVar12 + *param_4);
        param_3[2] = fStack_44;
        if (DAT_01f2dcd0 != '\0') {
          FUN_016774d0(DAT_01f2dcd0,"Obstacle Found, Moving to: %4.4f, %4.4f, %4.4f",*param_3,
                       param_3[1],param_3[2],0);
        }
      }
    }
  }
  return;
}



/* FUNCTION 18872 ; VA 0x009c7940 ; FUN_009c7940 */

/* WARNING: Removing unreachable block (ram,0x009c7d2c) */
/* WARNING: Removing unreachable block (ram,0x009c7d35) */
/* WARNING: Removing unreachable block (ram,0x009c7d3c) */
/* WARNING: Removing unreachable block (ram,0x009c7d45) */
/* WARNING: Removing unreachable block (ram,0x009c7d4a) */
/* WARNING: Removing unreachable block (ram,0x009c7d51) */
/* WARNING: Removing unreachable block (ram,0x009c7d54) */
/* WARNING: Removing unreachable block (ram,0x009c7d66) */
/* WARNING: Removing unreachable block (ram,0x009c7db7) */
/* WARNING: Removing unreachable block (ram,0x009c7d76) */
/* WARNING: Removing unreachable block (ram,0x009c7d88) */

void __fastcall FUN_009c7940(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  int *piStack_68;
  undefined auStack_60 [4];
  int *piStack_5c;
  int iStack_58;
  int *piStack_54;
  undefined auStack_50 [4];
  int *piStack_4c;
  undefined4 uStack_48;
  int *piStack_44;
  undefined4 uStack_40;
  int *piStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  int iStack_30;
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  int *piStack_20;
  int iStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5718;
  pvStack_10 = ExceptionList;
  piStack_14 = (int *)0x0;
  if ((((param_1 != 0) && (iVar2 = *(int *)(param_1 + 0x34), iVar2 != 0)) &&
      (iVar3 = *(int *)(iVar2 + 0xc), ExceptionList = &pvStack_10, iStack_18 = iVar2,
      iVar1 = FUN_00b63e30(),
      (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
      (uint)*(ushort *)(iVar1 + 0x1da))) && (*(int *)(iVar2 + 0x2c) != 0)) {
    uStack_38 = 0;
    piStack_20 = (int *)0x0;
    piStack_34 = (int *)0x0;
    iStack_1c = 0;
    piStack_68 = (int *)0x0;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    iVar2 = FUN_00980070(iStack_18);
    piVar5 = (int *)0;
    if (iVar2 != 0) {
      puVar4 = *(undefined4 **)(iVar2 + 0x2c);
      if (puVar4 != (undefined4 *)0x0) {
        piVar5 = (int *)puVar4[1];
        for (piVar6 = (int *)*puVar4; piVar6 != piVar5; piVar6 = piVar6 + 2) {
          piStack_20 = (int *)*piVar6;
          if ((piStack_20 != (int *)0x0) &&
             (iVar2 = piStack_20[3], iVar3 = FUN_00c91ca0(), piVar7 = piStack_20,
             (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
             (uint)*(ushort *)(iVar3 + 0x1da))) {
            if (piStack_20 != (int *)0x0) {
              iVar2 = piStack_20[3];
              iVar3 = thunk_FUN_00897b90();
              if ((uint)*(ushort *)(iVar3 + 0x1da) <
                  (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
                piVar7 = (int *)0x0;
              }
              puVar4 = (undefined4 *)FUN_0060e0c0(auStack_50,piVar7);
              uStack_38 = *puVar4;
              piStack_34 = (int *)puVar4[1];
              *puVar4 = 0;
              puVar4[1] = 0;
              piVar5 = piStack_14;
              piStack_20 = piStack_34;
              if (piStack_4c != (int *)0x0) {
                LOCK();
                iVar2 = piStack_4c[2] + -1;
                piStack_4c[2] = iVar2;
                UNLOCK();
                if (iVar2 == 0) {
                  (**(code **)(*piStack_4c + 4))();
                  piVar5 = piStack_14;
                }
              }
              goto LAB_009c7ab6;
            }
            break;
          }
        }
      }
      FUN_0086f2f0(2,"UnequipTools could not find Player backpack!");
      ExceptionList = pvStack_10;
      return;
    }
LAB_009c7ab6:
    piStack_14 = (int *)**(int **)(iStack_18 + 0x2c);
    piStack_24 = (int *)(*(int **)(iStack_18 + 0x2c))[1];
    if (piStack_14 != piStack_24) {
      do {
        if ((*piStack_14 == 0) ||
           (iVar2 = *(int *)(*piStack_14 + 0xc), iVar3 = FUN_00c46280(),
           (uint)*(ushort *)(iVar3 + 0x1da) <
           (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
          piVar5 = (int *)((uint)piVar5 | 2);
          piStack_3c = (int *)0x0;
          puVar4 = &uStack_40;
          iStack_1c = 0;
        }
        else {
          piStack_44 = (int *)piStack_14[1];
          iStack_1c = *piStack_14;
          if (piStack_44 != (int *)0x0) {
            LOCK();
            piStack_44[1] = piStack_44[1] + 1;
            UNLOCK();
            piStack_44 = (int *)piStack_14[1];
          }
          puVar4 = &uStack_48;
          piVar5 = (int *)((uint)piVar5 | 1);
        }
        piVar6 = (int *)puVar4[1];
        *puVar4 = 0;
        puVar4[1] = 0;
        iStack_58 = iStack_1c;
        piStack_54 = piVar6;
        if ((((uint)piVar5 & 2) != 0) &&
           (piVar5 = (int *)((uint)piVar5 & 0xfffffffd), piStack_3c != (int *)0x0)) {
          LOCK();
          iVar2 = piStack_3c[1] + -1;
          piStack_3c[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_3c)();
            LOCK();
            iVar2 = piStack_3c[2] + -1;
            piStack_3c[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piStack_3c + 4))();
            }
          }
        }
        if ((((uint)piVar5 & 1) != 0) &&
           (piVar5 = (int *)((uint)piVar5 & 0xfffffffe), piStack_44 != (int *)0x0)) {
          LOCK();
          iVar2 = piStack_44[1] + -1;
          piStack_44[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_44)();
            LOCK();
            iVar2 = piStack_44[2] + -1;
            piStack_44[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piStack_44 + 4))();
            }
          }
        }
        if (iStack_1c != 0) {
          if (piVar6 != (int *)0x0) {
            LOCK();
            piVar6[2] = piVar6[2] + 1;
            UNLOCK();
          }
          iStack_30 = iStack_1c;
          uStack_8._0_1_ = 3;
          if (piStack_68 == (int *)0x0) {
            piStack_2c = piVar6;
            FUN_006ce750(0,&iStack_30);
            if (piStack_2c != (int *)0x0) {
              LOCK();
              iVar2 = piStack_2c[2] + -1;
              piStack_2c[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piStack_2c + 4))();
              }
            }
          }
          else {
            *piStack_68 = iStack_1c;
            piStack_68[1] = (int)piVar6;
            piStack_68 = piStack_68 + 2;
            iStack_30 = 0;
            piStack_2c = (int *)0x0;
          }
        }
        uStack_8._0_1_ = 1;
        if (piVar6 != (int *)0x0) {
          LOCK();
          iVar2 = piVar6[1] + -1;
          piVar6[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar6)();
            LOCK();
            iVar2 = piVar6[2] + -1;
            piVar6[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
        piStack_14 = piStack_14 + 2;
      } while (piStack_14 != piStack_24);
      iStack_1c = 0;
    }
    piVar5 = (int *)0x0;
    puVar4 = (undefined4 *)FUN_00587490(auStack_60);
    piStack_24 = piStack_5c;
    piStack_14 = (int *)*puVar4;
    if (piStack_5c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_5c[1] + -1;
      piStack_5c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_5c)();
        LOCK();
        iVar2 = piStack_24[2] + -1;
        piStack_24[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    if (piStack_68 != (int *)0x0) {
      do {
        iVar2 = piVar5[1];
        iStack_28 = 0;
        piStack_24 = (int *)0x0;
        if (iVar2 != 0) {
          piVar6 = (int *)(iVar2 + 4);
          iVar2 = *(int *)(iVar2 + 4);
          while (iVar2 != 0) {
            LOCK();
            iVar3 = *piVar6;
            if (iVar2 == iVar3) {
              *piVar6 = iVar2 + 1;
              iVar3 = iVar2;
            }
            UNLOCK();
            if (iVar3 == iVar2) {
              iStack_28 = *piVar5;
              piStack_24 = (int *)piVar5[1];
              break;
            }
            iVar2 = *piVar6;
          }
        }
        piVar6 = piStack_24;
        uStack_8._0_1_ = 4;
        if ((iStack_28 != 0) && (*(int *)(iStack_28 + 0x34) == iStack_18)) {
          FUN_008a65e0(piStack_14,0);
        }
        uStack_8._0_1_ = 1;
        if (piVar6 != (int *)0x0) {
          LOCK();
          iVar2 = piVar6[1] + -1;
          piVar6[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar6)();
            LOCK();
            iVar2 = piVar6[2] + -1;
            piVar6[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
        piVar5 = piVar5 + 2;
      } while (piVar5 != piStack_68);
      piStack_20 = piStack_34;
      iStack_1c = 0;
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piVar5 = piStack_20 + 2;
      iVar2 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18873 ; VA 0x009c7dc0 ; FUN_009c7dc0 */

void FUN_009c7dc0(undefined4 *param_1)

{
  *param_1 = 0x3f800000;
  param_1[1] = 0;
  param_1[2] = 0;
  return;
}



/* FUNCTION 18874 ; VA 0x009c7de0 ; FUN_009c7de0 */

void FUN_009c7de0(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0x3f800000;
  param_1[2] = 0;
  return;
}



/* FUNCTION 18875 ; VA 0x009c7e00 ; FUN_009c7e00 */

undefined4 * __fastcall FUN_009c7e00(int param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (((*(int *)(param_1 + 0x3f8) == 0) ||
      (iVar4 = *(int *)(*(int *)(param_1 + 0x3f8) + 0xa8), iVar4 == 0)) || (iVar4 == -0x50)) {
    iVar4 = 0;
  }
  else {
    iVar4 = *(int *)(iVar4 + 0x70);
  }
  if (((iVar4 == 0) ||
      (puVar6 = *(undefined4 **)(*(int *)(iVar4 + 0x20) + 0x2c), puVar6 == (undefined4 *)0x0)) ||
     ((int)puVar6[0x6b] < 1)) {
    iVar4 = *(int *)(param_1 + 0x228);
    if (iVar4 == 0) {
      iVar7 = *(int *)(param_1 + 0x340);
    }
    else {
      iVar7 = *(int *)(param_1 + 0x3f0);
    }
    if (iVar7 == 0) {
      if (iVar4 == 0) {
        uVar5 = *(undefined4 *)(param_1 + 0x370);
      }
      else {
        uVar5 = *(undefined4 *)(param_1 + 0x380);
      }
    }
    else if (iVar4 == 0) {
      uVar5 = *(undefined4 *)(param_1 + 0x340);
    }
    else {
      uVar5 = *(undefined4 *)(param_1 + 0x3f0);
    }
    puVar6 = (undefined4 *)FUN_0060dcd0(auStack_c,uVar5);
    uVar5 = *puVar6;
    uVar2 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x3f8) = uVar5;
    piVar3 = *(int **)(param_1 + 0x3fc);
    *(undefined4 *)(param_1 + 0x3fc) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 1;
      iVar4 = *piVar1;
      puVar6 = (undefined4 *)*piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        puVar6 = (undefined4 *)*piVar1;
        *piVar1 = iVar4 + -1;
        UNLOCK();
        if (iVar4 + -1 == 0) {
          puVar6 = (undefined4 *)(**(code **)(*piVar3 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      piVar3 = piStack_8 + 1;
      iVar4 = *piVar3;
      puVar6 = (undefined4 *)*piVar3;
      *piVar3 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        puVar6 = (undefined4 *)(**(code **)*piStack_8)();
        LOCK();
        piVar3 = piStack_8 + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          puVar6 = (undefined4 *)(**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return puVar6;
}



/* FUNCTION 18876 ; VA 0x009c7f10 ; FUN_009c7f10 */

void __thiscall
FUN_009c7f10(int param_1,int param_2,float *param_3,float *param_4,float *param_5,float *param_6)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 ****ppppuVar4;
  float fVar5;
  undefined auStack_4c [16];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 ***apppuStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d57a8;
  pvStack_10 = ExceptionList;
  if (param_2 == 0) {
    return;
  }
  if (**(char **)(param_1 + 0x230) == (char)*(char **)(param_1 + 0x230)) {
    return;
  }
  ExceptionList = &pvStack_10;
  FUN_0054ef60(*(undefined4 *)(param_2 + 0x28));
  ppppuVar4 = apppuStack_34;
  if (0xf < uStack_20) {
    ppppuVar4 = (undefined4 ****)apppuStack_34[0];
  }
  iStack_8 = 0;
  cVar1 = FUN_0055c360(ppppuVar4,uStack_24,"HumanoidRootPart",0x10);
  if (cVar1 == '\0') {
    ppppuVar4 = apppuStack_34;
    if (0xf < uStack_20) {
      ppppuVar4 = (undefined4 ****)apppuStack_34[0];
    }
    cVar1 = FUN_0055c360(ppppuVar4,uStack_24,"LowerTorso",10);
    if (cVar1 == '\0') {
      ppppuVar4 = apppuStack_34;
      if (0xf < uStack_20) {
        ppppuVar4 = (undefined4 ****)apppuStack_34[0];
      }
      cVar1 = FUN_0055c360(ppppuVar4,uStack_24,"LeftUpperLeg",0xc);
      if (cVar1 == '\0') {
        ppppuVar4 = apppuStack_34;
        if (0xf < uStack_20) {
          ppppuVar4 = (undefined4 ****)apppuStack_34[0];
        }
        cVar1 = FUN_0055c360(ppppuVar4,uStack_24,"LeftLowerLeg",0xc);
        if (cVar1 == '\0') {
          ppppuVar4 = apppuStack_34;
          if (0xf < uStack_20) {
            ppppuVar4 = (undefined4 ****)apppuStack_34[0];
          }
          cVar1 = FUN_0055c360(ppppuVar4,uStack_24,"LeftFoot",8);
          if (cVar1 == '\0') {
            ppppuVar4 = apppuStack_34;
            if (0xf < uStack_20) {
              ppppuVar4 = (undefined4 ****)apppuStack_34[0];
            }
            cVar1 = FUN_0055c360(ppppuVar4,uStack_24,"RightUpperLeg",0xd);
            if (cVar1 == '\0') {
              ppppuVar4 = apppuStack_34;
              if (0xf < uStack_20) {
                ppppuVar4 = (undefined4 ****)apppuStack_34[0];
              }
              cVar1 = FUN_0055c360(ppppuVar4,uStack_24,"RightLowerLeg",0xd);
              if (cVar1 == '\0') {
                ppppuVar4 = apppuStack_34;
                if (0xf < uStack_20) {
                  ppppuVar4 = (undefined4 ****)apppuStack_34[0];
                }
                cVar1 = FUN_0055c360(ppppuVar4,uStack_24,"RightFoot",9);
                if (cVar1 == '\0') goto LAB_009c881a;
                uStack_3c = 0;
                uStack_38 = 0xf;
                auStack_4c[0] = 0;
                FUN_005542c0("RightAnkleRigAttachment",0x17);
                iStack_8._0_1_ = 0xe;
                uVar2 = FUN_008a1240(auStack_4c);
                iVar3 = FUN_009ab420(uVar2);
                iStack_8 = (uint)iStack_8._1_3_ << 8;
                FUN_005507b0();
                if (iVar3 != 0) {
                  iVar3 = FUN_00a6bd00(auStack_1c);
                  *param_4 = *(float *)(iVar3 + 4) + *param_4;
                  iVar3 = FUN_00a6bd00(auStack_1c);
                  *param_6 = *(float *)(iVar3 + 4) + *param_6;
                }
                iVar3 = FUN_00b08320();
                fVar5 = *(float *)(iVar3 + 4) * DAT_018ce2f4 + *param_4;
                param_3 = param_4;
                param_5 = param_6;
                goto LAB_009c87fa;
              }
              uStack_3c = 0;
              uStack_38 = 0xf;
              auStack_4c[0] = 0;
              FUN_005542c0("RightKneeRigAttachment",0x16);
              iStack_8._0_1_ = 0xc;
              uVar2 = FUN_008a1240(auStack_4c);
              iVar3 = FUN_009ab420(uVar2);
              iStack_8 = (uint)iStack_8._1_3_ << 8;
              FUN_005507b0();
              if (iVar3 != 0) {
                iVar3 = FUN_00a6bd00(auStack_1c);
                *param_4 = *(float *)(iVar3 + 4) + *param_4;
                iVar3 = FUN_00a6bd00(auStack_1c);
                *param_6 = *(float *)(iVar3 + 4) + *param_6;
              }
              uStack_3c = 0;
              uStack_38 = 0xf;
              auStack_4c[0] = 0;
              FUN_005542c0("RightAnkleRigAttachment",0x17);
              iStack_8._0_1_ = 0xd;
              uVar2 = FUN_008a1240(auStack_4c);
              iVar3 = FUN_009ab420(uVar2);
              iStack_8 = (uint)iStack_8._1_3_ << 8;
              FUN_005507b0();
              if (iVar3 == 0) goto LAB_009c881a;
              iVar3 = FUN_00a6bd00(auStack_1c);
              *param_4 = *param_4 - *(float *)(iVar3 + 4);
              iVar3 = FUN_00a6bd00(auStack_1c);
              fVar5 = *param_6 - *(float *)(iVar3 + 4);
              param_4 = param_6;
            }
            else {
              uStack_3c = 0;
              uStack_38 = 0xf;
              auStack_4c[0] = 0;
              FUN_005542c0(&DAT_018db914,0x15);
              iStack_8._0_1_ = 10;
              uVar2 = FUN_008a1240(auStack_4c);
              iVar3 = FUN_009ab420(uVar2);
              iStack_8 = (uint)iStack_8._1_3_ << 8;
              FUN_005507b0();
              if (iVar3 != 0) {
                iVar3 = FUN_00a6bd00(auStack_1c);
                *param_4 = *(float *)(iVar3 + 4) + *param_4;
                iVar3 = FUN_00a6bd00(auStack_1c);
                *param_6 = *(float *)(iVar3 + 4) + *param_6;
              }
              uStack_3c = 0;
              uStack_38 = 0xf;
              auStack_4c[0] = 0;
              FUN_005542c0("RightKneeRigAttachment",0x16);
              iStack_8._0_1_ = 0xb;
              uVar2 = FUN_008a1240(auStack_4c);
              iVar3 = FUN_009ab420(uVar2);
              iStack_8 = (uint)iStack_8._1_3_ << 8;
              FUN_005507b0();
              if (iVar3 == 0) goto LAB_009c881a;
              iVar3 = FUN_00a6bd00(auStack_1c);
              *param_4 = *param_4 - *(float *)(iVar3 + 4);
              iVar3 = FUN_00a6bd00(auStack_1c);
              fVar5 = *param_6 - *(float *)(iVar3 + 4);
              param_4 = param_6;
            }
          }
          else {
            uStack_3c = 0;
            uStack_38 = 0xf;
            auStack_4c[0] = 0;
            FUN_005542c0("LeftAnkleRigAttachment",0x16);
            iStack_8._0_1_ = 9;
            uVar2 = FUN_008a1240(auStack_4c);
            iVar3 = FUN_009ab420(uVar2);
            iStack_8 = (uint)iStack_8._1_3_ << 8;
            FUN_005507b0();
            if (iVar3 != 0) {
              iVar3 = FUN_00a6bd00(auStack_1c);
              *param_3 = *param_3 + *(float *)(iVar3 + 4);
              iVar3 = FUN_00a6bd00(auStack_1c);
              *param_5 = *(float *)(iVar3 + 4) + *param_5;
            }
            iVar3 = FUN_00b08320();
            fVar5 = *param_3 + *(float *)(iVar3 + 4) * DAT_018ce2f4;
LAB_009c87fa:
            *param_3 = fVar5;
            iVar3 = FUN_00b08320();
            fVar5 = *(float *)(iVar3 + 4) * DAT_018ce2f4 + *param_5;
            param_4 = param_5;
          }
        }
        else {
          uStack_3c = 0;
          uStack_38 = 0xf;
          auStack_4c[0] = 0;
          FUN_005542c0("LeftKneeRigAttachment",0x15);
          iStack_8._0_1_ = 7;
          uVar2 = FUN_008a1240(auStack_4c);
          iVar3 = FUN_009ab420(uVar2);
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          FUN_005507b0();
          if (iVar3 != 0) {
            iVar3 = FUN_00a6bd00(auStack_1c);
            *param_3 = *(float *)(iVar3 + 4) + *param_3;
            iVar3 = FUN_00a6bd00(auStack_1c);
            *param_5 = *(float *)(iVar3 + 4) + *param_5;
          }
          uStack_3c = 0;
          uStack_38 = 0xf;
          auStack_4c[0] = 0;
          FUN_005542c0("LeftAnkleRigAttachment",0x16);
          iStack_8._0_1_ = 8;
          uVar2 = FUN_008a1240(auStack_4c);
          iVar3 = FUN_009ab420(uVar2);
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          FUN_005507b0();
          if (iVar3 == 0) goto LAB_009c881a;
          iVar3 = FUN_00a6bd00(auStack_1c);
          *param_3 = *param_3 - *(float *)(iVar3 + 4);
          iVar3 = FUN_00a6bd00(auStack_1c);
          fVar5 = *param_5 - *(float *)(iVar3 + 4);
          param_4 = param_5;
        }
      }
      else {
        uStack_3c = 0;
        uStack_38 = 0xf;
        auStack_4c[0] = 0;
        FUN_005542c0(&DAT_018db6ac,0x14);
        iStack_8._0_1_ = 5;
        uVar2 = FUN_008a1240(auStack_4c);
        iVar3 = FUN_009ab420(uVar2);
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_005507b0();
        if (iVar3 != 0) {
          iVar3 = FUN_00a6bd00(auStack_1c);
          *param_3 = *(float *)(iVar3 + 4) + *param_3;
          iVar3 = FUN_00a6bd00(auStack_1c);
          *param_5 = *(float *)(iVar3 + 4) + *param_5;
        }
        uStack_3c = 0;
        uStack_38 = 0xf;
        auStack_4c[0] = 0;
        FUN_005542c0("LeftKneeRigAttachment",0x15);
        iStack_8._0_1_ = 6;
        uVar2 = FUN_008a1240(auStack_4c);
        iVar3 = FUN_009ab420(uVar2);
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_005507b0();
        if (iVar3 == 0) goto LAB_009c881a;
        iVar3 = FUN_00a6bd00(auStack_1c);
        *param_3 = *param_3 - *(float *)(iVar3 + 4);
        iVar3 = FUN_00a6bd00(auStack_1c);
        fVar5 = *param_5 - *(float *)(iVar3 + 4);
        param_4 = param_5;
      }
    }
    else {
      uStack_3c = 0;
      uStack_38 = 0xf;
      auStack_4c[0] = 0;
      FUN_005542c0("RootRigAttachment",0x11);
      iStack_8._0_1_ = 2;
      uVar2 = FUN_008a1240(auStack_4c);
      iVar3 = FUN_009ab420(uVar2);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_005507b0();
      if (iVar3 != 0) {
        iVar3 = FUN_00a6bd00(auStack_1c);
        *param_4 = *(float *)(iVar3 + 4) + *param_4;
        iVar3 = FUN_00a6bd00(auStack_1c);
        *param_3 = *(float *)(iVar3 + 4) + *param_3;
      }
      uStack_3c = 0;
      uStack_38 = 0xf;
      auStack_4c[0] = 0;
      FUN_005542c0(&DAT_018db914,0x15);
      iStack_8._0_1_ = 3;
      uVar2 = FUN_008a1240(auStack_4c);
      iVar3 = FUN_009ab420(uVar2);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_005507b0();
      if (iVar3 != 0) {
        iVar3 = FUN_00a6bd00(auStack_1c);
        *param_4 = *param_4 - *(float *)(iVar3 + 4);
      }
      uStack_3c = 0;
      uStack_38 = 0xf;
      auStack_4c[0] = 0;
      FUN_005542c0(&DAT_018db6ac,0x14);
      iStack_8._0_1_ = 4;
      uVar2 = FUN_008a1240(auStack_4c);
      iVar3 = FUN_009ab420(uVar2);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_005507b0();
      if (iVar3 == 0) goto LAB_009c881a;
      iVar3 = FUN_00a6bd00(auStack_1c);
      fVar5 = *param_3 - *(float *)(iVar3 + 4);
      param_4 = param_3;
    }
  }
  else {
    uStack_3c = 0;
    uStack_38 = 0xf;
    auStack_4c[0] = 0;
    FUN_005542c0("RootRigAttachment",0x11);
    iStack_8._0_1_ = 1;
    uVar2 = FUN_008a1240(auStack_4c);
    iVar3 = FUN_009ab420(uVar2);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_005507b0();
    if (iVar3 != 0) {
      iVar3 = FUN_00a6bd00(auStack_1c);
      *param_4 = *param_4 - *(float *)(iVar3 + 4);
      iVar3 = FUN_00a6bd00(auStack_1c);
      *param_3 = *param_3 - *(float *)(iVar3 + 4);
    }
    iVar3 = FUN_00b08320();
    *param_3 = *param_3 - *(float *)(iVar3 + 4) * DAT_018ce2f4;
    iVar3 = FUN_00b08320();
    fVar5 = *param_4 - *(float *)(iVar3 + 4) * DAT_018ce2f4;
  }
  *param_4 = fVar5;
LAB_009c881a:
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18877 ; VA 0x009c8840 ; FUN_009c8840 */

void FUN_009c8840(int *param_1)

{
  code *pcVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  undefined8 *puVar6;
  undefined4 uVar7;
  int *piVar8;
  uint uVar9;
  int *piVar10;
  uint uVar11;
  int aiStack_4c [5];
  uint uStack_38;
  int aiStack_34 [5];
  uint uStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d57d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_1[10]);
  uStack_8 = 0;
  iVar4 = FUN_008a1240(aiStack_34);
  if ((iVar4 == 0) ||
     (iVar4 = *(int *)(iVar4 + 0xc), iVar5 = FUN_00aff8c0(),
     (uint)*(ushort *)(iVar5 + 0x1da) <
     (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) goto LAB_009c8a5b;
  puVar6 = (undefined8 *)FUN_00b08320();
  pcVar1 = *(code **)(*piVar2 + 0x158);
  fStack_1c = (float)*puVar6;
  fStack_18 = (float)((ulonglong)*puVar6 >> 0x20);
  fStack_14 = *(float *)(puVar6 + 1) * DAT_018ce2f4;
  _fStack_1c = CONCAT44(fStack_18 * DAT_018ce2f4,fStack_1c * DAT_018ce2f4);
  uVar7 = FUN_009ac1a0(aiStack_4c,piVar2,&fStack_1c);
  uStack_8._0_1_ = 1;
  uVar7 = FUN_00a33be0(uVar7);
  uStack_8._0_1_ = 2;
  (*pcVar1)(uVar7);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  LOCK();
  iVar4 = param_1[10] + -1;
  param_1[10] = iVar4;
  UNLOCK();
  if (iVar4 == 0) {
    FUN_00585a90();
    uVar7 = DAT_01ea8518;
    EnterCriticalSection(DAT_01ea8518);
    cVar3 = FUN_00578b90(&param_1);
    piVar2 = param_1;
    if (cVar3 != '\0') {
      piVar8 = (int *)(DAT_01ea8514 + 0x28);
      if (DAT_01ea8514 == -0xc) {
        piVar8 = (int *)0x28;
      }
      *piVar8 = *piVar8 + -1;
      piVar10 = (int *)(-(uint)(param_1 != (int *)0x0) & (uint)(param_1 + 0xc));
      piVar8 = *(int **)(*piVar10 + 4);
      if (piVar8 == piVar10) {
        piVar8 = *(int **)piVar10[1];
        *(undefined4 **)(*piVar10 + 4) = (undefined4 *)piVar10[1];
        if (piVar8 == piVar10) goto LAB_009c89b1;
        piVar8 = *(int **)piVar10[1];
      }
      else if (*(int **)piVar10[1] == piVar10) {
        *piVar8 = (int)piVar10[1];
LAB_009c89b1:
        piVar8 = (int *)piVar10[1];
      }
      else {
        *piVar8 = 0;
        *(int *)(*piVar10 + 4) = piVar10[1];
        piVar8 = *(int **)piVar10[1];
      }
      *piVar8 = *piVar10;
      uVar11 = param_1[9];
      if (0xf < uVar11) {
        iVar4 = param_1[4];
        uVar9 = uVar11 + 1;
        iVar5 = iVar4;
        if (0xfff < uVar9) {
          iVar5 = *(int *)(iVar4 + -4);
          uVar9 = uVar11 + 0x24;
          if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_009c8a9d;
        }
        FUN_01674ea0(iVar5,uVar9);
      }
      piVar2[8] = 0;
      piVar2[9] = 0xf;
      *(undefined *)(piVar2 + 4) = 0;
      FUN_01674ea0(piVar2,0x38);
    }
    LeaveCriticalSection(uVar7);
  }
  if (0xf < uStack_38) {
    uVar11 = uStack_38 + 1;
    iVar4 = aiStack_4c[0];
    if (0xfff < uVar11) {
      iVar4 = *(int *)(aiStack_4c[0] + -4);
      uVar11 = uStack_38 + 0x24;
      if (0x1f < (aiStack_4c[0] - iVar4) - 4U) {
LAB_009c8a9d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar11);
  }
LAB_009c8a5b:
  if (0xf < uStack_20) {
    uVar11 = uStack_20 + 1;
    iVar4 = aiStack_34[0];
    if (0xfff < uVar11) {
      iVar4 = *(int *)(aiStack_34[0] + -4);
      uVar11 = uStack_20 + 0x24;
      if (0x1f < (aiStack_34[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar11);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18878 ; VA 0x009c8ab0 ; FUN_009c8ab0 */

void FUN_009c8ab0(int param_1,undefined4 param_2)

{
  if ((param_1 != 0) && (*(int *)(param_1 + 0x2c) != 0)) {
    FUN_00f9efc0(param_2);
  }
  return;
}



/* FUNCTION 18879 ; VA 0x009c8ad0 ; FUN_009c8ad0 */

void * __thiscall FUN_009c8ad0(int param_1,int param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  void *pvVar5;
  undefined4 uStack_3c;
  undefined4 uStack_2c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d5819;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar5 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    ExceptionList = &pvStack_10;
    FUN_009b11e0(&param_2);
    pvVar5 = *(void **)(param_2 + 0x34);
    if (pvVar5 == *(void **)(param_1 + 0x34)) {
      iVar1 = param_2 + 0x4c;
      uStack_8._0_1_ = 1;
      uVar4 = FUN_01675290(DAT_02110da8);
      uStack_8._0_1_ = 2;
      puStack_14 = (undefined4 *)FUN_01674e20(0x30);
      if (puStack_14 == (undefined4 *)0x0) {
        puStack_14 = (undefined4 *)0x0;
      }
      else {
        *puStack_14 = 0;
        puStack_14[1] = 1;
        puStack_14[2] = FUN_009b0400;
        puStack_14[3] = _guard_check_icall;
        puStack_14[4] = 0;
        puStack_14[6] = FUN_009bd250;
        puStack_14[7] = 0xfffffecc;
        puStack_14[8] = 0;
        puStack_14[9] = uStack_2c;
        puStack_14[5] = iVar1;
        *(ulonglong *)(puStack_14 + 10) = CONCAT44(uStack_3c,param_1);
      }
      FUN_016797d0(puStack_14);
      if (puStack_14 != (undefined4 *)0x0) {
        LOCK();
        puStack_14[1] = puStack_14[1] + 1;
        UNLOCK();
      }
      uStack_8._0_1_ = 3;
      FUN_01675290(uVar4);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_009a4f80(&param_2);
      pvVar5 = (void *)FUN_01679300(&puStack_14);
      if ((char)pvVar5 != '\0') {
        FUN_01679490();
        pvVar5 = (void *)FUN_016791c0(&puStack_14);
      }
      if (puStack_14 != (undefined4 *)0x0) {
        piVar2 = puStack_14 + 1;
        LOCK();
        iVar1 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        pvVar5 = (void *)(iVar1 + -1);
        if (pvVar5 == (void *)0x0) {
          pvVar5 = (void *)FUN_01674ea0(puStack_14);
        }
      }
    }
  }
  piVar2 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar3 = param_3 + 1;
    iVar1 = *piVar3;
    pvVar5 = (void *)*piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      pvVar5 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar3 = piVar2 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        pvVar5 = (void *)(**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 18880 ; VA 0x009c8c80 ; FUN_009c8c80 */

int __thiscall FUN_009c8c80(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined auStack_58 [24];
  undefined4 uStack_40;
  undefined4 *puStack_3c;
  int iStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d5840;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (param_2 != 0) {
    iStack_1c = param_1 + 0x6c0;
    puStack_3c = &param_2;
    uStack_40 = 0x9c8cc9;
    ExceptionList = &pvStack_10;
    FUN_009b11e0();
    param_1 = *(int *)(param_2 + 0x34);
    if (param_1 == *(int *)(iStack_14 + 0x34)) {
      puStack_3c = (undefined4 *)0x9c8ce2;
      FUN_008a40f0();
      puStack_3c = (undefined4 *)0x9c8ce9;
      FUN_008a4100();
      uStack_18 = CONCAT31(uStack_18._1_3_,DAT_01ee37b5);
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      FUN_0099e180(auStack_58,0xfffffecc009b3210,0,iStack_14,uStack_18,param_2,param_3);
      iStack_14 = FUN_0099e4e0(&iStack_20);
      puStack_3c = &param_2;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      uStack_40 = 0x9c8d74;
      FUN_009a4f80();
      puStack_3c = (undefined4 *)iStack_14;
      uStack_40 = 0x9c8d81;
      param_1 = FUN_01679300();
      if ((char)param_1 != '\0') {
        puStack_3c = (undefined4 *)0x9c8d8c;
        FUN_01679490();
        puStack_3c = (undefined4 *)iStack_14;
        uStack_40 = 0x9c8d96;
        param_1 = FUN_016791c0();
      }
      if (iStack_20 != 0) {
        piVar1 = (int *)(iStack_20 + 4);
        LOCK();
        param_1 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        param_1 = param_1 + -1;
        if (param_1 == 0) {
          puStack_3c = (undefined4 *)iStack_20;
          uStack_40 = 0x9c8db3;
          param_1 = FUN_01674ea0();
        }
      }
    }
  }
  piVar1 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 1;
    iVar3 = *piVar2;
    param_1 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      puStack_3c = (undefined4 *)0x9c8dcc;
      param_1 = (**(code **)*param_3)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        puStack_3c = (undefined4 *)0x9c8ddb;
        param_1 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18881 ; VA 0x009c8df0 ; FUN_009c8df0 */

undefined2 * FUN_009c8df0(undefined2 *param_1,float *param_2)

{
  float10 fVar1;
  float fVar2;
  
  fVar1 = (float10)FUN_01725280((double)(*param_2 * DAT_018e1340));
  fVar2 = param_2[1] * DAT_018e1340;
  *param_1 = (short)(int)fVar1;
  fVar1 = (float10)FUN_01725280((double)fVar2);
  fVar2 = param_2[2] * DAT_018e1340;
  param_1[1] = (short)(int)fVar1;
  fVar1 = (float10)FUN_01725280((double)fVar2);
  param_1[2] = (short)(int)fVar1;
  return param_1;
}



/* FUNCTION 18882 ; VA 0x009c8eb0 ; FUN_009c8eb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009c8eb0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d585c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee41cc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee41cc);
    if (DAT_01ee41cc == -1) {
      uStack_8 = 0;
      FUN_00888860("GuidData",0x1a,0,0,0);
      _DAT_01ee41a8 = RBX::Reflection::TType<class_RBX::Guid>::vftable;
      FUN_016f3654(&LAB_018873a0);
      FUN_016f37bf(&DAT_01ee41cc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee41a8;
}



/* FUNCTION 18883 ; VA 0x009c8f50 ; FUN_009c8f50 */

uint __thiscall FUN_009c8f50(uint *param_1,uint *param_2)

{
  uint uVar1;
  
  uVar1 = param_1[1];
  if ((uVar1 == param_2[1]) && (uVar1 = *param_1, uVar1 == *param_2)) {
    return CONCAT31((int3)(uVar1 >> 8),1);
  }
  return uVar1 & 0xffffff00;
}



/* FUNCTION 18884 ; VA 0x009c8f70 ; FUN_009c8f70 */

int __thiscall FUN_009c8f70(int *param_1,int *param_2)

{
  int iVar1;
  uint3 uVar2;
  
  iVar1 = *param_1 - *param_2;
  uVar2 = (uint3)((uint)iVar1 >> 8);
  if (iVar1 < 0) {
    return CONCAT31(uVar2,1);
  }
  if (0 < iVar1) {
    return (uint)uVar2 << 8;
  }
  return CONCAT31((int3)((uint)param_1[1] >> 8),param_1[1] < param_2[1]);
}



/* FUNCTION 18885 ; VA 0x009c8fa0 ; FUN_009c8fa0 */

uint __thiscall FUN_009c8fa0(char *param_1,undefined4 *param_2)

{
  byte bVar1;
  code *pcVar2;
  char cVar3;
  uint in_EAX;
  undefined4 *puVar4;
  uint uVar5;
  char cVar7;
  uint uVar8;
  undefined3 uVar6;
  
  if ((uint)param_2[4] < 0x23) {
    return in_EAX & 0xffffff00;
  }
  uVar8 = 4;
  while (uVar8 - 1 < (uint)param_2[4]) {
    puVar4 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar4 = (undefined4 *)*param_2;
    }
    cVar3 = *(char *)((uVar8 - 1) + (int)puVar4);
    uVar6 = (undefined3)((uint)puVar4 >> 8);
    if (cVar3 < 'A') {
      cVar3 = cVar3 + -0x30;
    }
    else {
      uVar5 = CONCAT31(uVar6,cVar3) & 0xffffffdf;
      uVar6 = (undefined3)(uVar5 >> 8);
      cVar3 = (char)uVar5 + -0x37;
    }
    *param_1 = cVar3 * '\x10';
    if ((uint)param_2[4] <= uVar8) break;
    puVar4 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar4 = (undefined4 *)*param_2;
    }
    bVar1 = *(byte *)(uVar8 + (int)puVar4);
    if ((char)bVar1 < 'A') {
      cVar7 = bVar1 - 0x30;
    }
    else {
      cVar7 = (bVar1 & 0xdf) - 0x37;
    }
    uVar8 = uVar8 + 2;
    *param_1 = cVar3 * '\x10' + cVar7;
    param_1 = param_1 + 1;
    if (0x23 < uVar8) {
      return CONCAT31(uVar6,1);
    }
  }
  FUN_00554050();
  pcVar2 = (code *)swi(3);
  uVar8 = (*pcVar2)();
  return uVar8;
}



/* FUNCTION 18886 ; VA 0x009c9030 ; FUN_009c9030 */

void FUN_009c9030(undefined4 *param_1)

{
  int iVar1;
  
  LOCK();
  UNLOCK();
  iVar1 = DAT_01ee41a4 + 1;
  DAT_01ee41a4 = DAT_01ee41a4 + 1;
  *param_1 = 0;
  param_1[1] = iVar1;
  return;
}



/* FUNCTION 18887 ; VA 0x009c9050 ; FUN_009c9050 */

undefined4 * FUN_009c9050(undefined4 *param_1)

{
  uint uVar1;
  code *pcVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792429;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  uStack_8 = 0;
  uVar5 = 1;
  FUN_01531ce0(param_1);
  if (7 < (uint)param_1[4]) {
    puVar4 = param_1;
    if (0xf < (uint)param_1[5]) {
      puVar4 = (undefined4 *)*param_1;
    }
    param_1[4] = 8;
    *(undefined *)(puVar4 + 2) = 0;
    uVar1 = param_1[4];
    uVar3 = 3;
    if (uVar1 < 3) {
      uVar3 = uVar1;
    }
    puVar4 = param_1;
    if (0xf < (uint)param_1[5]) {
      puVar4 = (undefined4 *)*param_1;
    }
    param_1[4] = uVar1 - uVar3;
    FUN_0170cc70(puVar4,(int)puVar4 + uVar3,(uVar1 - uVar3) + 1);
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_00554050();
  pcVar2 = (code *)swi(3);
  puVar4 = (undefined4 *)(*pcVar2)(uVar5);
  return puVar4;
}



/* FUNCTION 18888 ; VA 0x009c9100 ; FUN_009c9100 */

void FUN_009c9100(undefined4 *param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d587c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee41e8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee41e8);
    if (DAT_01ee41e8 == -1) {
      uStack_8 = 0;
      FUN_009c9050(&DAT_01ee41d0);
      FUN_016f3654(&LAB_01887340);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ee41e8);
    }
  }
  if ((undefined4 **)param_1 != &DAT_01ee41d0) {
    puVar1 = &DAT_01ee41d0;
    if (0xf < DAT_01ee41e4) {
      puVar1 = DAT_01ee41d0;
    }
    FUN_005542c0(puVar1,DAT_01ee41e0);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18889 ; VA 0x009c91c0 ; FUN_009c91c0 */

void FUN_009c91c0(uint *param_1,int *param_2)

{
  uint uVar1;
  
  uVar1 = *param_1;
  *param_1 = *param_2 + -0x61c88647 + uVar1 * 0x40 + (uVar1 >> 2) ^ uVar1;
  return;
}



/* FUNCTION 18890 ; VA 0x009c91f0 ; FUN_009c91f0 */

uint FUN_009c91f0(int *param_1)

{
  uint uVar1;
  
  uVar1 = *param_1 + 0x9e3779b9;
  return param_1[1] + 0x2c15e7f9 + *param_1 * 0x40 + (uVar1 >> 2) ^ uVar1;
}



/* FUNCTION 18891 ; VA 0x009c9220 ; FUN_009c9220 */

undefined4 __thiscall FUN_009c9220(undefined4 param_1,char param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = CONCAT31((int3)((uint)param_1 >> 8),param_2);
  iVar1 = iVar2 + -0x30;
  if ((9 < (byte)iVar1) && (iVar1 = iVar2 + -0x61, 5 < (byte)iVar1)) {
    return CONCAT31((int3)((uint)iVar1 >> 8),(byte)(param_2 + 0xbfU) < 6);
  }
  return CONCAT31((int3)((uint)iVar1 >> 8),1);
}



/* FUNCTION 18892 ; VA 0x009c9250 ; FUN_009c9250 */

uint __fastcall FUN_009c9250(undefined4 param_1,int param_2,char *param_3)

{
  char cVar1;
  uint uVar2;
  char *in_EAX;
  char *pcVar3;
  byte bVar4;
  undefined3 uVar5;
  uint uVar6;
  
  if (*(int *)(param_3 + 0x10) == 0x26) {
    uVar2 = *(uint *)(param_3 + 0x14);
    in_EAX = param_3;
    if (0xf < uVar2) {
      in_EAX = *(char **)param_3;
    }
    if (*in_EAX == '{') {
      pcVar3 = param_3;
      if (0xf < uVar2) {
        pcVar3 = *(char **)param_3;
      }
      uVar6 = 0;
      do {
        cVar1 = pcVar3[uVar6 + 1];
        uVar5 = (undefined3)((uint)param_2 >> 8);
        param_2 = CONCAT31(uVar5,cVar1);
        if (((9 < (byte)(cVar1 - 0x30U)) && (in_EAX = (char *)(param_2 + -0x61), 5 < (byte)in_EAX))
           && (param_2 = CONCAT31(uVar5,cVar1 + 0xbfU), 5 < (byte)(cVar1 + 0xbfU)))
        goto LAB_009c93c7;
        uVar6 = uVar6 + 1;
      } while (uVar6 < 8);
      in_EAX = param_3;
      if (0xf < uVar2) {
        in_EAX = *(char **)param_3;
      }
      if (in_EAX[9] == '-') {
        pcVar3 = param_3;
        if (0xf < uVar2) {
          pcVar3 = *(char **)param_3;
        }
        uVar6 = 0;
        do {
          cVar1 = pcVar3[uVar6 + 10];
          uVar5 = (undefined3)((uint)param_2 >> 8);
          param_2 = CONCAT31(uVar5,cVar1);
          if (((9 < (byte)(cVar1 - 0x30U)) && (in_EAX = (char *)(param_2 + -0x61), 5 < (byte)in_EAX)
              ) && (param_2 = CONCAT31(uVar5,cVar1 + 0xbfU), 5 < (byte)(cVar1 + 0xbfU)))
          goto LAB_009c93c7;
          uVar6 = uVar6 + 1;
        } while (uVar6 < 4);
        in_EAX = param_3;
        if (0xf < uVar2) {
          in_EAX = *(char **)param_3;
        }
        if (in_EAX[0xe] == '-') {
          pcVar3 = param_3;
          if (0xf < uVar2) {
            pcVar3 = *(char **)param_3;
          }
          uVar6 = 0;
          do {
            cVar1 = pcVar3[uVar6 + 0xf];
            uVar5 = (undefined3)((uint)param_2 >> 8);
            param_2 = CONCAT31(uVar5,cVar1);
            if (((9 < (byte)(cVar1 - 0x30U)) &&
                (in_EAX = (char *)(param_2 + -0x61), 5 < (byte)in_EAX)) &&
               (param_2 = CONCAT31(uVar5,cVar1 + 0xbfU), 5 < (byte)(cVar1 + 0xbfU)))
            goto LAB_009c93c7;
            uVar6 = uVar6 + 1;
          } while (uVar6 < 4);
          in_EAX = param_3;
          if (0xf < uVar2) {
            in_EAX = *(char **)param_3;
          }
          if (in_EAX[0x13] == '-') {
            pcVar3 = param_3;
            if (0xf < uVar2) {
              pcVar3 = *(char **)param_3;
            }
            uVar6 = 0;
            do {
              cVar1 = pcVar3[uVar6 + 0x14];
              uVar5 = (undefined3)((uint)param_2 >> 8);
              param_2 = CONCAT31(uVar5,cVar1);
              if (((9 < (byte)(cVar1 - 0x30U)) &&
                  (in_EAX = (char *)(param_2 + -0x61), 5 < (byte)in_EAX)) &&
                 (param_2 = CONCAT31(uVar5,cVar1 + 0xbfU), 5 < (byte)(cVar1 + 0xbfU)))
              goto LAB_009c93c7;
              uVar6 = uVar6 + 1;
            } while (uVar6 < 4);
            in_EAX = param_3;
            if (0xf < uVar2) {
              in_EAX = *(char **)param_3;
            }
            if (in_EAX[0x18] == '-') {
              pcVar3 = param_3;
              if (0xf < uVar2) {
                pcVar3 = *(char **)param_3;
              }
              uVar6 = 0;
              do {
                uVar5 = (undefined3)((uint)param_2 >> 8);
                param_2 = CONCAT31(uVar5,pcVar3[uVar6 + 0x19]);
                in_EAX = (char *)(param_2 + -0x30);
                if (((9 < (byte)in_EAX) && (in_EAX = (char *)(param_2 + -0x61), 5 < (byte)in_EAX))
                   && (bVar4 = pcVar3[uVar6 + 0x19] + 0xbf, param_2 = CONCAT31(uVar5,bVar4),
                      5 < bVar4)) goto LAB_009c93c7;
                uVar6 = uVar6 + 1;
              } while (uVar6 < 0xc);
              if (0xf < uVar2) {
                param_3 = *(char **)param_3;
              }
              if (param_3[0x25] == '}') {
                return CONCAT31((int3)((uint)in_EAX >> 8),1);
              }
            }
          }
        }
      }
    }
  }
LAB_009c93c7:
  return (uint)in_EAX & 0xffffff00;
}



/* FUNCTION 18893 ; VA 0x009c93d0 ; FUN_009c93d0 */

undefined4 * __thiscall FUN_009c93d0(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  bool bVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int aiStack_44 [5];
  uint uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0229;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  bVar1 = 0 < param_3;
  if (bVar1) {
    ExceptionList = &pvStack_10;
    puVar5 = (undefined4 *)FUN_01675640(auStack_2c,"%d_%d",*param_1,param_1[1]);
  }
  else {
    ExceptionList = &pvStack_10;
    puVar5 = (undefined4 *)FUN_01675640(aiStack_44,&DAT_018bed68);
  }
  param_2[4] = 0;
  param_2[5] = 0;
  uVar2 = puVar5[1];
  uVar3 = puVar5[2];
  uVar4 = puVar5[3];
  *param_2 = *puVar5;
  param_2[1] = uVar2;
  param_2[2] = uVar3;
  param_2[3] = uVar4;
  *(undefined8 *)(param_2 + 4) = *(undefined8 *)(puVar5 + 4);
  puVar5[4] = 0;
  puVar5[5] = 0xf;
  *(undefined *)puVar5 = 0;
  if (bVar1) {
    if (0xf < uStack_18) {
      uVar7 = uStack_18 + 1;
      uVar8 = auStack_2c[0];
      if (0xfff < uVar7) {
        uVar8 = *(uint *)(auStack_2c[0] - 4);
        uVar7 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar7);
    }
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  }
  if ((!bVar1) && (0xf < uStack_30)) {
    uVar8 = uStack_30 + 1;
    iVar6 = aiStack_44[0];
    if (0xfff < uVar8) {
      iVar6 = *(int *)(aiStack_44[0] + -4);
      uVar8 = uStack_30 + 0x24;
      if (0x1f < (aiStack_44[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18894 ; VA 0x009c9510 ; FUN_009c9510 */

undefined4 __thiscall FUN_009c9510(undefined4 *param_1,undefined4 param_2)

{
  FUN_01675640(param_2,"%d.%d",*param_1,param_1[1]);
  return param_2;
}



/* FUNCTION 18895 ; VA 0x009c9530 ; FUN_009c9530 */

void __fastcall FUN_009c9530(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = RBX::ClientAppSettings::vftable;
  uVar1 = param_1[0x2b];
  if (0xf < uVar1) {
    iVar2 = param_1[0x26];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_009c966f;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x2a] = 0;
  param_1[0x2b] = 0xf;
  *(undefined *)(param_1 + 0x26) = 0;
  uVar1 = param_1[0x25];
  if (0xf < uVar1) {
    iVar2 = param_1[0x20];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_009c966f;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x24] = 0;
  param_1[0x25] = 0xf;
  *(undefined *)(param_1 + 0x20) = 0;
  uVar1 = param_1[0x1a];
  if (0xf < uVar1) {
    iVar2 = param_1[0x15];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_009c966f;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x19] = 0;
  param_1[0x1a] = 0xf;
  *(undefined *)(param_1 + 0x15) = 0;
  uVar1 = param_1[0x14];
  if (0xf < uVar1) {
    iVar2 = param_1[0xf];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_009c966f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x13] = 0;
  param_1[0x14] = 0xf;
  *(undefined *)(param_1 + 0xf) = 0;
  FUN_0056e4b0();
  return;
}



/* FUNCTION 18896 ; VA 0x009c9680 ; FUN_009c9680 */

undefined4 __thiscall FUN_009c9680(undefined4 param_1,byte param_2)

{
  FUN_009c9530();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xb8);
  }
  return param_1;
}



/* FUNCTION 18897 ; VA 0x009c96b0 ; FUN_009c96b0 */

void __fastcall FUN_009c96b0(int param_1)

{
  undefined4 *puVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5950;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  ExceptionList = &pvStack_10;
  *(undefined *)(param_1 + 0x28) = 0;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("AllowVideoPreRoll",0x11);
  uStack_8 = 0;
  puVar1 = (undefined4 *)FUN_0056f450(auStack_28);
  uStack_8 = 0xffffffff;
  *puVar1 = FUN_009c9f10;
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  *(undefined4 *)(param_1 + 0x2c) = 0x1e;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("VideoPreRollWaitTimeSeconds",0x1b);
  uStack_8 = 1;
  puVar1 = (undefined4 *)FUN_0056f450(auStack_28);
  uStack_8 = 0xffffffff;
  *puVar1 = FUN_009ca2d0;
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("StartPageUrl",0xc);
  uStack_8 = 2;
  puVar1 = (undefined4 *)FUN_0056f450(auStack_28);
  uStack_8 = 0xffffffff;
  *puVar1 = FUN_009ca230;
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  *(undefined *)(param_1 + 0x74) = 1;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("WebDocAddressBarEnabled",0x17);
  uStack_8 = 3;
  puVar1 = (undefined4 *)FUN_0056f450(auStack_28);
  uStack_8 = 0xffffffff;
  *puVar1 = FUN_009ca2f0;
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  *(undefined *)(param_1 + 0x30) = 0;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("CaptureQTStudioCountersEnabled",0x1e);
  uStack_8 = 4;
  puVar1 = (undefined4 *)FUN_0056f450(auStack_28);
  uStack_8 = 0xffffffff;
  *puVar1 = FUN_009c9f70;
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  *(undefined4 *)(param_1 + 0x34) = 5;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("CaptureCountersIntervalInMinutes",0x20);
  uStack_8 = 5;
  puVar1 = (undefined4 *)FUN_0056f450(auStack_28);
  uStack_8 = 0xffffffff;
  *puVar1 = FUN_009c9f50;
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  *(undefined4 *)(param_1 + 0x38) = 300;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("CaptureSlowCountersIntervalInSeconds",0x24);
  uStack_8 = 6;
  puVar1 = (undefined4 *)FUN_0056f450(auStack_28);
  uStack_8 = 0xffffffff;
  *puVar1 = FUN_009c9f90;
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("PublishedProjectsPageUrl",0x18);
  uStack_8 = 7;
  puVar1 = (undefined4 *)FUN_0056f450(auStack_28);
  uStack_8 = 0xffffffff;
  *puVar1 = FUN_009ca170;
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  *(undefined4 *)(param_1 + 0x6c) = 800;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("PublishedProjectsPageWidth",0x1a);
  uStack_8 = 8;
  puVar1 = (undefined4 *)FUN_0056f450(auStack_28);
  uStack_8 = 0xffffffff;
  *puVar1 = FUN_009ca210;
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  *(undefined4 *)(param_1 + 0x70) = 600;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("PublishedProjectsPageHeight",0x1b);
  uStack_8 = 9;
  puVar1 = (undefined4 *)FUN_0056f450(auStack_28);
  uStack_8 = 0xffffffff;
  *puVar1 = FUN_009ca150;
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  *(undefined4 *)(param_1 + 0x78) = 5;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("AxisAdornmentGrabSize",0x15);
  uStack_8 = 10;
  puVar1 = (undefined4 *)FUN_0056f450(auStack_28);
  uStack_8 = 0xffffffff;
  *puVar1 = FUN_009c9f30;
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  *(undefined4 *)(param_1 + 0x7c) = 200;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("MinPartsForOptDragging",0x16);
  uStack_8 = 0xb;
  puVar1 = (undefined4 *)FUN_0056f450(auStack_28);
  uStack_8 = 0xffffffff;
  *puVar1 = FUN_009ca130;
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  FUN_005542c0("UA-43420590-2",0xd);
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("GoogleAnalyticsAccountPropertyID",0x20);
  uStack_8 = 0xc;
  puVar1 = (undefined4 *)FUN_0056f450(auStack_28);
  uStack_8 = 0xffffffff;
  *puVar1 = FUN_009c9fb0;
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  FUN_005542c0("UA-43420590-13",0xe);
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("GoogleAnalyticsAccountPropertyIDPlayer",0x26);
  uStack_8 = 0xd;
  puVar1 = (undefined4 *)FUN_0056f450(auStack_28);
  uStack_8 = 0xffffffff;
  *puVar1 = FUN_009ca050;
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  *(undefined4 *)(param_1 + 0xb0) = 500;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("GoogleAnalyticsThreadPoolMaxScheduleSize",0x28);
  uStack_8 = 0xe;
  puVar1 = (undefined4 *)FUN_0056f450(auStack_28);
  uStack_8 = 0xffffffff;
  *puVar1 = FUN_009ca110;
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  *(undefined4 *)(param_1 + 0xb4) = 1;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0("GoogleAnalyticsLoadPlayer",0x19);
  uStack_8 = 0xf;
  puVar1 = (undefined4 *)FUN_0056f450(auStack_40);
  *puVar1 = FUN_009ca0f0;
  if (0xf < uStack_2c) {
    uVar3 = uStack_2c + 1;
    uVar2 = auStack_40[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_40[0] - 4);
      uVar3 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18898 ; VA 0x009c9f10 ; FUN_009c9f10 */

void FUN_009c9f10(undefined4 param_1)

{
  undefined uVar1;
  
  uVar1 = FUN_01683c60(param_1);
  *(undefined *)(DAT_01ee421c + 0x28) = uVar1;
  return;
}



/* FUNCTION 18899 ; VA 0x009c9f30 ; FUN_009c9f30 */

void FUN_009c9f30(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_01717832(param_1);
  *(undefined4 *)(DAT_01ee421c + 0x78) = uVar1;
  return;
}



/* FUNCTION 18900 ; VA 0x009c9f50 ; FUN_009c9f50 */

void FUN_009c9f50(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_01717832(param_1);
  *(undefined4 *)(DAT_01ee421c + 0x34) = uVar1;
  return;
}



/* FUNCTION 18901 ; VA 0x009c9f70 ; FUN_009c9f70 */

void FUN_009c9f70(undefined4 param_1)

{
  undefined uVar1;
  
  uVar1 = FUN_01683c60(param_1);
  *(undefined *)(DAT_01ee421c + 0x30) = uVar1;
  return;
}



/* FUNCTION 18902 ; VA 0x009c9f90 ; FUN_009c9f90 */

void FUN_009c9f90(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_01717832(param_1);
  *(undefined4 *)(DAT_01ee421c + 0x38) = uVar1;
  return;
}



/* FUNCTION 18903 ; VA 0x009c9fb0 ; FUN_009c9fb0 */

void FUN_009c9fb0(char *param_1)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  uint uVar4;
  uint uVar5;
  uint *puVar6;
  uint uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  uint uStack_8;
  
  uStack_c = 0;
  uStack_8 = 0xf;
  uStack_1c = uStack_1c & 0xffffff00;
  pcVar3 = param_1;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_1,(int)pcVar3 - (int)(param_1 + 1));
  iVar2 = DAT_01ee421c;
  puVar6 = (uint *)(DAT_01ee421c + 0x80);
  if (puVar6 != &uStack_1c) {
    FUN_005507b0();
    *puVar6 = uStack_1c;
    *(undefined4 *)(iVar2 + 0x84) = uStack_18;
    *(undefined4 *)(iVar2 + 0x88) = uStack_14;
    *(undefined4 *)(iVar2 + 0x8c) = uStack_10;
    *(ulonglong *)(iVar2 + 0x90) = CONCAT44(uStack_8,uStack_c);
    return;
  }
  if (0xf < uStack_8) {
    uVar5 = uStack_8 + 1;
    uVar4 = uStack_1c;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(uStack_1c - 4);
      uVar5 = uStack_8 + 0x24;
      if (0x1f < (uStack_1c - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  return;
}



/* FUNCTION 18904 ; VA 0x009ca050 ; FUN_009ca050 */

void FUN_009ca050(char *param_1)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  uint uVar4;
  uint uVar5;
  uint *puVar6;
  uint uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  uint uStack_8;
  
  uStack_c = 0;
  uStack_8 = 0xf;
  uStack_1c = uStack_1c & 0xffffff00;
  pcVar3 = param_1;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_1,(int)pcVar3 - (int)(param_1 + 1));
  iVar2 = DAT_01ee421c;
  puVar6 = (uint *)(DAT_01ee421c + 0x98);
  if (puVar6 != &uStack_1c) {
    FUN_005507b0();
    *puVar6 = uStack_1c;
    *(undefined4 *)(iVar2 + 0x9c) = uStack_18;
    *(undefined4 *)(iVar2 + 0xa0) = uStack_14;
    *(undefined4 *)(iVar2 + 0xa4) = uStack_10;
    *(ulonglong *)(iVar2 + 0xa8) = CONCAT44(uStack_8,uStack_c);
    return;
  }
  if (0xf < uStack_8) {
    uVar5 = uStack_8 + 1;
    uVar4 = uStack_1c;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(uStack_1c - 4);
      uVar5 = uStack_8 + 0x24;
      if (0x1f < (uStack_1c - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  return;
}



/* FUNCTION 18905 ; VA 0x009ca0f0 ; FUN_009ca0f0 */

void FUN_009ca0f0(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_01717832(param_1);
  *(undefined4 *)(DAT_01ee421c + 0xb4) = uVar1;
  return;
}



/* FUNCTION 18906 ; VA 0x009ca110 ; FUN_009ca110 */

void FUN_009ca110(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_01717832(param_1);
  *(undefined4 *)(DAT_01ee421c + 0xb0) = uVar1;
  return;
}



/* FUNCTION 18907 ; VA 0x009ca130 ; FUN_009ca130 */

void FUN_009ca130(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_01717832(param_1);
  *(undefined4 *)(DAT_01ee421c + 0x7c) = uVar1;
  return;
}



/* FUNCTION 18908 ; VA 0x009ca150 ; FUN_009ca150 */

void FUN_009ca150(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_01717832(param_1);
  *(undefined4 *)(DAT_01ee421c + 0x70) = uVar1;
  return;
}



/* FUNCTION 18909 ; VA 0x009ca170 ; FUN_009ca170 */

void FUN_009ca170(char *param_1)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  uint uVar4;
  uint uVar5;
  uint *puVar6;
  uint uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  uint uStack_8;
  
  uStack_c = 0;
  uStack_8 = 0xf;
  uStack_1c = uStack_1c & 0xffffff00;
  pcVar3 = param_1;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_1,(int)pcVar3 - (int)(param_1 + 1));
  iVar2 = DAT_01ee421c;
  puVar6 = (uint *)(DAT_01ee421c + 0x54);
  if (puVar6 != &uStack_1c) {
    FUN_005507b0();
    *puVar6 = uStack_1c;
    *(undefined4 *)(iVar2 + 0x58) = uStack_18;
    *(undefined4 *)(iVar2 + 0x5c) = uStack_14;
    *(undefined4 *)(iVar2 + 0x60) = uStack_10;
    *(ulonglong *)(iVar2 + 100) = CONCAT44(uStack_8,uStack_c);
    return;
  }
  if (0xf < uStack_8) {
    uVar5 = uStack_8 + 1;
    uVar4 = uStack_1c;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(uStack_1c - 4);
      uVar5 = uStack_8 + 0x24;
      if (0x1f < (uStack_1c - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  return;
}



/* FUNCTION 18910 ; VA 0x009ca210 ; FUN_009ca210 */

void FUN_009ca210(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_01717832(param_1);
  *(undefined4 *)(DAT_01ee421c + 0x6c) = uVar1;
  return;
}



/* FUNCTION 18911 ; VA 0x009ca230 ; FUN_009ca230 */

void FUN_009ca230(char *param_1)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  uint uVar4;
  uint uVar5;
  uint *puVar6;
  uint uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  uint uStack_8;
  
  uStack_c = 0;
  uStack_8 = 0xf;
  uStack_1c = uStack_1c & 0xffffff00;
  pcVar3 = param_1;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_1,(int)pcVar3 - (int)(param_1 + 1));
  iVar2 = DAT_01ee421c;
  puVar6 = (uint *)(DAT_01ee421c + 0x3c);
  if (puVar6 != &uStack_1c) {
    FUN_005507b0();
    *puVar6 = uStack_1c;
    *(undefined4 *)(iVar2 + 0x40) = uStack_18;
    *(undefined4 *)(iVar2 + 0x44) = uStack_14;
    *(undefined4 *)(iVar2 + 0x48) = uStack_10;
    *(ulonglong *)(iVar2 + 0x4c) = CONCAT44(uStack_8,uStack_c);
    return;
  }
  if (0xf < uStack_8) {
    uVar5 = uStack_8 + 1;
    uVar4 = uStack_1c;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(uStack_1c - 4);
      uVar5 = uStack_8 + 0x24;
      if (0x1f < (uStack_1c - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  return;
}



/* FUNCTION 18912 ; VA 0x009ca2d0 ; FUN_009ca2d0 */

void FUN_009ca2d0(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_01717832(param_1);
  *(undefined4 *)(DAT_01ee421c + 0x2c) = uVar1;
  return;
}



/* FUNCTION 18913 ; VA 0x009ca2f0 ; FUN_009ca2f0 */

void FUN_009ca2f0(undefined4 param_1)

{
  undefined uVar1;
  
  uVar1 = FUN_01683c60(param_1);
  *(undefined *)(DAT_01ee421c + 0x74) = uVar1;
  return;
}



/* FUNCTION 18914 ; VA 0x009ca310 ; FUN_009ca310 */

undefined ** FUN_009ca310(void)

{
  return &PTR_vftable_01d65268;
}



/* FUNCTION 18915 ; VA 0x009ca320 ; FUN_009ca320 */

void __thiscall FUN_009ca320(int param_1,undefined4 *param_2,uint param_3,undefined4 *param_4)

{
  byte bVar1;
  undefined4 *puVar2;
  byte *pbVar3;
  uint uVar4;
  int *piVar5;
  uint uVar6;
  byte *pbVar7;
  bool bVar8;
  
  uVar6 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar5 = (int *)0x0;
  }
  else {
    puVar2 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    if (puVar2 == (undefined4 *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      piVar5 = (int *)*puVar2;
    }
    if (piVar5 != (int *)0x0) {
      do {
        if (param_3 == piVar5[1]) {
          pbVar3 = (byte *)piVar5[2];
          pbVar7 = (byte *)*param_4;
          do {
            bVar1 = *pbVar7;
            bVar8 = bVar1 < *pbVar3;
            if (bVar1 != *pbVar3) {
LAB_009ca391:
              uVar4 = -(uint)bVar8 | 1;
              goto LAB_009ca396;
            }
            if (bVar1 == 0) break;
            bVar1 = pbVar7[1];
            bVar8 = bVar1 < pbVar3[1];
            if (bVar1 != pbVar3[1]) goto LAB_009ca391;
            pbVar7 = pbVar7 + 2;
            pbVar3 = pbVar3 + 2;
          } while (bVar1 != 0);
          uVar4 = 0;
LAB_009ca396:
          if (uVar4 == 0) break;
        }
        else if ((uint)piVar5[1] % *(uint *)(param_1 + 4) != uVar6) {
          *param_2 = 0;
          return;
        }
        piVar5 = (int *)*piVar5;
        if (piVar5 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar5;
  return;
}



/* FUNCTION 18916 ; VA 0x009ca3d0 ; FUN_009ca3d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009ca3d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d596c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee439c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee439c);
    if (DAT_01ee439c == -1) {
      uStack_8 = 0;
      FUN_00888860("Property",0x21,0,0,0);
      _DAT_01ee4378 =
           RBX::Reflection::TType<class_RBX::Reflection::PropertyDescriptor_const*>::vftable;
      FUN_016f3654(&LAB_01887430);
      FUN_016f37bf(&DAT_01ee439c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee4378;
}



/* FUNCTION 18917 ; VA 0x009ca470 ; FUN_009ca470 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_009ca470(undefined4 *param_1,int *param_2)

{
  undefined4 *puVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  int iVar9;
  undefined4 uStack_20;
  uint *puStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d59b4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_008887b0(param_2,"token",0x20,0,0,1);
  *param_1 = RBX::Reflection::EnumDescriptor::vftable;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  param_1[0xc] = 0;
  uStack_20 = 0;
  puStack_1c = (uint *)0x0;
  FUN_0060e8c0(0,&uStack_20,(int)&param_2 + 3);
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  iVar3 = FUN_009cb400();
  puVar5 = *(undefined4 **)(iVar3 + 0x24);
  puVar6 = *(undefined4 **)(iVar3 + 0x20);
  iVar9 = (int)puVar5 - (int)puVar6 >> 2;
  uStack_18 = iVar3 + 0x20;
  if (0 < iVar9) {
    do {
      iVar3 = iVar9 >> 1;
      param_2 = puVar6 + iVar3;
      cVar2 = FUN_009cb230(puVar6[iVar3],puStack_14);
      if (cVar2 != '\0') {
        puVar6 = param_2 + 1;
        iVar3 = iVar9 + (-1 - iVar3);
      }
      iVar9 = iVar3;
    } while (0 < iVar3);
    puVar5 = *(undefined4 **)(uStack_18 + 4);
  }
  puVar1 = puStack_14;
  param_2 = puStack_14;
  if (*(undefined4 **)(uStack_18 + 8) == puVar5) {
    FUN_0063d9b0(puVar6,&param_2);
  }
  else if (puVar6 == puVar5) {
    *puVar5 = puStack_14;
    *(int *)(uStack_18 + 4) = *(int *)(uStack_18 + 4) + 4;
  }
  else {
    *puVar5 = puVar5[-1];
    *(int *)(uStack_18 + 4) = *(int *)(uStack_18 + 4) + 4;
    iVar9 = (int)puVar5 + (-4 - (int)puVar6);
    FUN_0170cc70((int)puVar5 - iVar9,puVar6,iVar9);
    *puVar6 = puVar1;
  }
  piVar4 = (int *)FUN_009cb400();
  uStack_18 = puVar1[1];
  puVar5 = (undefined4 *)*piVar4;
  puVar6 = (undefined4 *)puVar5[1];
  puVar8 = puVar5;
  if (*(char *)((int)puVar5[1] + 0xd) == '\0') {
    do {
      if ((uint)puVar6[4] < uStack_18) {
        puVar7 = (undefined4 *)puVar6[2];
      }
      else {
        puVar7 = (undefined4 *)*puVar6;
        puVar8 = puVar6;
      }
      puVar6 = puVar7;
    } while (*(char *)((int)puVar7 + 0xd) == '\0');
    if ((puVar8 != puVar5) && ((uint)puVar8[4] <= uStack_18)) goto LAB_009ca630;
  }
  puStack_1c = &uStack_18;
  iVar9 = FUN_005f81a0(&DAT_018bdeda,&puStack_1c,(int)&param_2 + 3);
  FUN_00687600(&param_2,puVar8,iVar9 + 0x10,iVar9);
  puVar8 = param_2;
LAB_009ca630:
  puVar8[5] = puVar1;
  FUN_009cb400();
  param_2 = (int *)puVar1[1];
  if (0xf < (uint)param_2[5]) {
    param_2 = (int *)*param_2;
  }
  iVar9 = FUN_009ca950(&param_2);
  _DAT_01ee4374 = _DAT_01ee4374 + 1;
  *(undefined4 **)(iVar9 + 4) = puVar1;
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 18918 ; VA 0x009ca670 ; FUN_009ca670 */

undefined4 * __thiscall
FUN_009ca670(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,uint param_8,undefined4 param_9
            ,undefined4 param_10,undefined param_11)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d59c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00dab180();
  FUN_00892310(param_2,param_4,param_5,param_6,param_7,param_9,uVar1);
  uStack_8 = 0;
  *param_1 = RBX::Reflection::PropertyDescriptor::vftable;
  param_1[10] = param_3;
  *(undefined *)(param_1 + 0xb) = param_11;
  param_1[9] = ((((((int)param_8 >> 5 & 1U) * 2 | (int)param_8 >> 4 & 1U) * 2 |
                 (int)param_8 >> 3 & 1U) * 2 | (int)param_8 >> 2 & 1U) * 2 | (int)param_8 >> 1 & 1U)
               << 2 | param_1[9] & 0xffffff82 | param_8 & 1 | 2;
  param_1[0xc] = param_10;
  FUN_00892950(param_1);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18919 ; VA 0x009ca750 ; FUN_009ca750 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_009ca750(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Reflection::EnumDescriptor::vftable;
  iVar1 = FUN_009cb400();
  for (piVar5 = *(int **)(iVar1 + 0x20);
      (piVar5 != *(int **)(iVar1 + 0x24) && ((undefined4 *)*piVar5 != param_1)); piVar5 = piVar5 + 1
      ) {
  }
  FUN_0170cc70(piVar5,piVar5 + 1,(int)*(int **)(iVar1 + 0x24) - (int)(piVar5 + 1));
  *(int *)(iVar1 + 0x24) = *(int *)(iVar1 + 0x24) + -4;
  piVar5 = (int *)param_1[9];
  uVar4 = 0;
  _DAT_01ee4374 = _DAT_01ee4374 + -1;
  uVar3 = (param_1[10] - (int)piVar5) + 3U >> 2;
  if ((int *)param_1[10] < piVar5) {
    uVar3 = 0;
  }
  if (uVar3 != 0) {
    do {
      if ((undefined4 *)*piVar5 != (undefined4 *)0x0) {
        (*(code *)**(undefined4 **)*piVar5)(1);
      }
      uVar4 = uVar4 + 1;
      piVar5 = piVar5 + 1;
    } while (uVar4 != uVar3);
  }
  iVar1 = param_1[0x16];
  if (iVar1 != 0) {
    uVar3 = param_1[0x18] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_009ca92b;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[0x16] = 0;
    param_1[0x17] = 0;
    param_1[0x18] = 0;
  }
  iVar1 = param_1[0x13];
  if (iVar1 != 0) {
    uVar3 = param_1[0x15] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_009ca92b;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[0x13] = 0;
    param_1[0x14] = 0;
    param_1[0x15] = 0;
  }
  iVar1 = param_1[0xd];
  if (iVar1 != 0) {
    uVar3 = param_1[0xf] - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_009ca92b;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[0xd] = 0;
    param_1[0xe] = 0;
    param_1[0xf] = 0;
  }
  iVar1 = param_1[9];
  if (iVar1 != 0) {
    uVar3 = param_1[0xb] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_009ca92b:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[9] = 0;
    param_1[10] = 0;
    param_1[0xb] = 0;
  }
  FUN_00888900();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18920 ; VA 0x009ca940 ; FUN_009ca940 */

void __fastcall FUN_009ca940(undefined4 *param_1)

{
  *param_1 = RBX::Reflection::PropertyDescriptor::vftable;
  FUN_008925b0();
  return;
}



/* FUNCTION 18921 ; VA 0x009ca950 ; FUN_009ca950 */

int * __thiscall FUN_009ca950(byte *param_1,int *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  int *piVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d59e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_00888920(*param_2);
  FUN_009ca320(&param_2,uVar4,piVar1,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != (int *)0x0) {
    ExceptionList = pvStack_10;
    return param_2 + 2;
  }
  iVar7 = *piVar1;
  uStack_8 = 0;
  piVar5 = (int *)FUN_01674e20(0x10);
  piVar1 = piVar5 + 2;
  *piVar5 = 0;
  piVar5[1] = 0;
  piVar1[0] = 0;
  piVar1[1] = 0;
  *piVar1 = iVar7;
  if (piVar5 + 3 != (int *)0x0) {
    piVar5[3] = 0;
  }
  uVar3 = *(uint *)(param_1 + 8);
  uVar6 = uVar3 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar6 = FUN_005d6bb0(uVar6);
    if (uVar6 <= *(uint *)(param_1 + 4)) {
      uVar6 = *(uint *)(param_1 + 4);
    }
    FUN_00780ee0(uVar6);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar6) {
    param_2 = (int *)0x1;
    uVar8 = uVar3 >> 1;
    if ((uVar3 >> 1) + uVar3 <= uVar6) {
      uVar8 = 1;
    }
    iVar7 = FUN_005d6bb0(uVar8 + uVar3);
    if (iVar7 != *(int *)(param_1 + 4)) {
      FUN_009cb650(iVar7);
    }
  }
  piVar5[1] = uVar4;
  uVar4 = uVar4 % *(uint *)(param_1 + 4);
  piVar9 = *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  puVar2 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  if (piVar9 == (int *)0x0) {
    piVar9 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar9 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar9 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar5;
    }
    *puVar2 = piVar9;
    *piVar5 = *piVar9;
  }
  else {
    *piVar5 = *piVar9;
    piVar9 = (int *)*puVar2;
  }
  *piVar9 = (int)piVar5;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piVar1;
}



/* FUNCTION 18922 ; VA 0x009caae0 ; FUN_009caae0 */

undefined4 __thiscall FUN_009caae0(undefined4 param_1,byte param_2)

{
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 18923 ; VA 0x009cab10 ; FUN_009cab10 */

undefined4 __thiscall FUN_009cab10(undefined4 param_1,byte param_2)

{
  FUN_00888900();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  return param_1;
}



/* FUNCTION 18924 ; VA 0x009cab40 ; FUN_009cab40 */

undefined4 * __thiscall FUN_009cab40(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::PropertyDescriptor::vftable;
  FUN_008925b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x34);
  }
  return param_1;
}



/* FUNCTION 18925 ; VA 0x009cab70 ; FUN_009cab70 */

void __thiscall FUN_009cab70(int param_1,uint param_2,undefined4 param_3,undefined4 param_4)

{
  uint uVar1;
  int iVar2;
  
  uVar1 = param_2;
  iVar2 = *(int *)(param_1 + 0x58);
  if ((uint)(*(int *)(param_1 + 0x5c) - iVar2 >> 2) <= param_2) {
    param_2 = 0xffffffff;
    FUN_005f87c0(uVar1 + 1,(int *)(param_1 + 0x58),&param_2);
    iVar2 = *(int *)(param_1 + 0x58);
  }
  *(undefined4 *)(iVar2 + uVar1 * 4) = param_4;
  param_2 = FUN_0086e3d0(param_3);
  if ((uint)((*(int *)(param_1 + 0x38) - *(int *)(param_1 + 0x34) >> 3) * 3) >> 2 <=
      *(uint *)(param_1 + 0x40)) {
    FUN_006285a0();
  }
  iVar2 = FUN_00620bc0(&param_2);
  *(undefined4 *)(iVar2 + 4) = param_4;
  return;
}



/* FUNCTION 18926 ; VA 0x009cabf0 ; FUN_009cabf0 */

void __thiscall FUN_009cabf0(int param_1,uint param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  
  iVar3 = param_4;
  if (param_4 != 0) {
    uVar2 = *(undefined4 *)(param_4 + 0x1c);
    piVar1 = (int *)(param_1 + 0x58);
    iVar4 = *piVar1;
    if ((uint)(*(int *)(param_1 + 0x5c) - iVar4 >> 2) <= param_2) {
      param_4 = -1;
      FUN_005f87c0(param_2 + 1,piVar1,&param_4);
      iVar4 = *piVar1;
    }
    *(undefined4 *)(iVar4 + param_2 * 4) = uVar2;
    uVar2 = *(undefined4 *)(iVar3 + 0x1c);
    param_4 = FUN_0086e3d0(param_3);
    if ((uint)((*(int *)(param_1 + 0x38) - *(int *)(param_1 + 0x34) >> 3) * 3) >> 2 <=
        *(uint *)(param_1 + 0x40)) {
      FUN_006285a0();
    }
    iVar3 = FUN_00620bc0(&param_4);
    *(undefined4 *)(iVar3 + 4) = uVar2;
  }
  return;
}



/* FUNCTION 18927 ; VA 0x009cac90 ; FUN_009cac90 */

void __thiscall FUN_009cac90(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  
  param_2 = FUN_0086e3d0(param_2);
  if ((uint)((*(int *)(param_1 + 0x38) - *(int *)(param_1 + 0x34) >> 3) * 3) >> 2 <=
      *(uint *)(param_1 + 0x40)) {
    FUN_006285a0();
  }
  iVar1 = FUN_00620bc0(&param_2);
  *(undefined4 *)(iVar1 + 4) = param_3;
  return;
}



/* FUNCTION 18928 ; VA 0x009cace0 ; FUN_009cace0 */

void __thiscall FUN_009cace0(int param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  int iVar2;
  
  if (param_3 != 0) {
    uVar1 = *(undefined4 *)(param_3 + 0x1c);
    param_3 = FUN_0086e3d0(param_2);
    if ((uint)((*(int *)(param_1 + 0x38) - *(int *)(param_1 + 0x34) >> 3) * 3) >> 2 <=
        *(uint *)(param_1 + 0x40)) {
      FUN_006285a0();
    }
    iVar2 = FUN_00620bc0(&param_3);
    *(undefined4 *)(iVar2 + 4) = uVar1;
  }
  return;
}



/* FUNCTION 18929 ; VA 0x009cad30 ; FUN_009cad30 */

void __thiscall FUN_009cad30(int param_1,int param_2,int param_3)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar2 = param_3;
  iVar4 = 0;
  if (0 < param_3) {
    do {
      uVar1 = *(undefined4 *)(param_2 + iVar4 * 8);
      param_3 = FUN_0086e3d0(*(undefined4 *)(param_2 + 4 + iVar4 * 8));
      if ((uint)((*(int *)(param_1 + 0x38) - *(int *)(param_1 + 0x34) >> 3) * 3) >> 2 <=
          *(uint *)(param_1 + 0x40)) {
        FUN_006285a0();
      }
      iVar3 = FUN_00620bc0(&param_3);
      iVar4 = iVar4 + 1;
      *(undefined4 *)(iVar3 + 4) = uVar1;
    } while (iVar4 < iVar2);
  }
  return;
}



/* FUNCTION 18930 ; VA 0x009cada0 ; FUN_009cada0 */

void FUN_009cada0(undefined4 param_1,undefined4 param_2)

{
  undefined4 uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_009cade0(param_1,param_2,uStack_10,0);
  return;
}



/* FUNCTION 18931 ; VA 0x009cade0 ; FUN_009cade0 */

void __thiscall
FUN_009cade0(int param_1,undefined4 *param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int iVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5a0f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x20);
  uVar2 = (uint)param_2;
  uStack_8 = 0;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    uVar4 = FUN_00dab160();
    FUN_00888700(param_3,param_4,param_5,uVar4);
    *puVar3 = RBX::Reflection::EnumDescriptor::Item::vftable;
    puVar3[6] = param_1;
    puVar3[7] = uVar2;
  }
  puVar1 = *(undefined4 **)(param_1 + 0x28);
  uStack_8 = 0xffffffff;
  param_2 = puVar3;
  if (*(undefined4 **)(param_1 + 0x2c) == puVar1) {
    FUN_0063d9b0(puVar1,&param_2);
  }
  else {
    *puVar1 = puVar3;
    *(int *)(param_1 + 0x28) = *(int *)(param_1 + 0x28) + 4;
  }
  puVar3 = param_2;
  iVar5 = *(int *)(param_1 + 0x58);
  if ((uint)(*(int *)(param_1 + 0x5c) - iVar5 >> 2) <= uVar2) {
    param_2 = (undefined4 *)0xffffffff;
    FUN_005f87c0();
    iVar5 = *(int *)(param_1 + 0x58);
  }
  piVar6 = (int *)(param_1 + 0x4c);
  *(uint *)(iVar5 + uVar2 * 4) = uVar2;
  iVar5 = *piVar6;
  if ((uint)(*(int *)(param_1 + 0x50) - iVar5 >> 2) <= uVar2) {
    FUN_005f86c0(uVar2 + 1,piVar6);
    iVar5 = *piVar6;
  }
  *(undefined4 **)(iVar5 + uVar2 * 4) = puVar3;
  param_2 = (undefined4 *)puVar3[1];
  if ((uint)((*(int *)(param_1 + 0x38) - *(int *)(param_1 + 0x34) >> 3) * 3) >> 2 <=
      *(uint *)(param_1 + 0x40)) {
    FUN_006285a0();
  }
  iVar5 = FUN_00620bc0(&param_2);
  *(uint *)(iVar5 + 4) = uVar2;
  *(int *)(param_1 + 0x30) = *(int *)(param_1 + 0x30) + 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18932 ; VA 0x009caf20 ; FUN_009caf20 */

void __thiscall FUN_009caf20(int param_1,int param_2,uint param_3)

{
  int iVar1;
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  if ((uint)(*(int *)(param_1 + 0x54) - *(int *)(param_1 + 0x4c) >> 2) < param_3) {
    if (0x3fffffff < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_007cfd20(param_3);
  }
  if ((uint)(*(int *)(param_1 + 0x60) - *(int *)(param_1 + 0x58) >> 2) < param_3) {
    if (0x3fffffff < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_007cfd20(param_3);
  }
  iVar1 = 0;
  if (0 < (int)param_3) {
    do {
      FUN_009cade0(*(undefined4 *)(param_2 + iVar1 * 8),*(undefined4 *)(param_2 + 4 + iVar1 * 8),
                   uStack_10,0);
      iVar1 = iVar1 + 1;
    } while (iVar1 < (int)param_3);
  }
  return;
}



/* FUNCTION 18933 ; VA 0x009cafc0 ; FUN_009cafc0 */

void __thiscall
FUN_009cafc0(int param_1,int param_2,uint param_3,undefined8 param_4,undefined4 param_5)

{
  int iVar1;
  
  if ((uint)(*(int *)(param_1 + 0x54) - *(int *)(param_1 + 0x4c) >> 2) < param_3) {
    if (0x3fffffff < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_007cfd20(param_3);
  }
  if ((uint)(*(int *)(param_1 + 0x60) - *(int *)(param_1 + 0x58) >> 2) < param_3) {
    if (0x3fffffff < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_007cfd20(param_3);
  }
  iVar1 = 0;
  if (0 < (int)param_3) {
    do {
      FUN_009cade0(*(undefined4 *)(param_2 + iVar1 * 8),*(undefined4 *)(param_2 + 4 + iVar1 * 8),
                   param_4,param_5);
      iVar1 = iVar1 + 1;
    } while (iVar1 < (int)param_3);
  }
  return;
}



/* FUNCTION 18934 ; VA 0x009cb050 ; FUN_009cb050 */

undefined4 __thiscall FUN_009cb050(int param_1,uint param_2)

{
  int iVar1;
  
  if (((-1 < (int)param_2) &&
      (param_2 < (uint)(*(int *)(param_1 + 0x5c) - *(int *)(param_1 + 0x58) >> 2))) &&
     (iVar1 = *(int *)(*(int *)(param_1 + 0x58) + param_2 * 4), iVar1 != -1)) {
    return *(undefined4 *)(*(int *)(param_1 + 0x4c) + iVar1 * 4);
  }
  return 0;
}



/* FUNCTION 18935 ; VA 0x009cb090 ; FUN_009cb090 */

undefined4 * __thiscall FUN_009cb090(int param_1,undefined4 *param_2,uint param_3)

{
  int iVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  if (((((int)param_3 < 0) ||
       ((uint)(*(int *)(param_1 + 0x5c) - *(int *)(param_1 + 0x58) >> 2) <= param_3)) ||
      (iVar1 = *(int *)(*(int *)(param_1 + 0x58) + param_3 * 4), iVar1 == -1)) ||
     (iVar1 = *(int *)(*(int *)(param_1 + 0x4c) + iVar1 * 4), iVar1 == 0)) {
    param_2[4] = 0;
    param_2[5] = 0xf;
    *(undefined *)param_2 = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    return param_2;
  }
  puVar7 = *(undefined4 **)(iVar1 + 4);
  param_2[4] = 0;
  param_2[5] = 0;
  uVar2 = puVar7[4];
  if (0xf < (uint)puVar7[5]) {
    puVar7 = (undefined4 *)*puVar7;
  }
  if (uVar2 < 0x10) {
    uVar5 = puVar7[1];
    uVar3 = puVar7[2];
    uVar4 = puVar7[3];
    *param_2 = *puVar7;
    param_2[1] = uVar5;
    param_2[2] = uVar3;
    param_2[3] = uVar4;
    param_2[4] = uVar2;
    param_2[5] = 0xf;
    return param_2;
  }
  uVar6 = uVar2 | 0xf;
  if (0x7fffffff < uVar6) {
    uVar6 = 0x7fffffff;
  }
  uVar5 = FUN_00554060(uVar6 + 1);
  *param_2 = uVar5;
  FUN_0170c6f0(uVar5,puVar7,uVar2 + 1);
  param_2[4] = uVar2;
  param_2[5] = uVar6;
  return param_2;
}



/* FUNCTION 18936 ; VA 0x009cb180 ; FUN_009cb180 */

undefined4 FUN_009cb180(undefined4 param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  param_1 = FUN_0086e8f0(param_1);
  puVar1 = (undefined4 *)FUN_0061dc20(&param_1);
  if (puVar1 != (undefined4 *)0x0) {
    *param_2 = *puVar1;
    return 1;
  }
  return 0;
}



/* FUNCTION 18937 ; VA 0x009cb1c0 ; FUN_009cb1c0 */

undefined4 __thiscall FUN_009cb1c0(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = FUN_0086e8f0(param_2);
  iVar2 = FUN_0086e640();
  if (iVar1 != iVar2) {
    param_2 = iVar1;
    piVar3 = (int *)FUN_0061dc20(&param_2);
    if (piVar3 != (int *)0x0) {
      return *(undefined4 *)(*(int *)(param_1 + 0x4c) + *piVar3 * 4);
    }
  }
  return 0;
}



/* FUNCTION 18938 ; VA 0x009cb210 ; FUN_009cb210 */

int FUN_009cb210(void)

{
  int iVar1;
  
  iVar1 = FUN_009cb400();
  return *(int *)(iVar1 + 0x24) - *(int *)(iVar1 + 0x20) >> 2;
}



/* FUNCTION 18939 ; VA 0x009cb230 ; FUN_009cb230 */

uint FUN_009cb230(int param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  byte *pbVar5;
  byte *pbVar6;
  bool bVar7;
  
  pbVar6 = *(byte **)(param_1 + 4);
  pbVar5 = *(byte **)(param_2 + 4);
  if (pbVar6 == pbVar5) {
    return param_2 & 0xffffff00;
  }
  uVar1 = *(uint *)(pbVar5 + 0x10);
  if (0xf < *(uint *)(pbVar5 + 0x14)) {
    pbVar5 = *(byte **)pbVar5;
  }
  uVar2 = *(uint *)(pbVar6 + 0x10);
  if (0xf < *(uint *)(pbVar6 + 0x14)) {
    pbVar6 = *(byte **)pbVar6;
  }
  uVar4 = uVar2;
  if (uVar1 < uVar2) {
    uVar4 = uVar1;
  }
  while (uVar3 = uVar4 - 4, 3 < uVar4) {
    if (*(int *)pbVar6 != *(int *)pbVar5) goto LAB_009cb286;
    pbVar6 = pbVar6 + 4;
    pbVar5 = pbVar5 + 4;
    uVar4 = uVar3;
  }
  if (uVar3 != 0xfffffffc) {
LAB_009cb286:
    bVar7 = *pbVar6 < *pbVar5;
    if ((*pbVar6 != *pbVar5) ||
       ((uVar3 != 0xfffffffd &&
        ((bVar7 = pbVar6[1] < pbVar5[1], pbVar6[1] != pbVar5[1] ||
         ((uVar3 != 0xfffffffe &&
          ((bVar7 = pbVar6[2] < pbVar5[2], pbVar6[2] != pbVar5[2] ||
           ((uVar3 != 0xffffffff && (bVar7 = pbVar6[3] < pbVar5[3], pbVar6[3] != pbVar5[3]))))))))))
       )) {
      uVar4 = -(uint)bVar7 | 1;
      goto LAB_009cb2bc;
    }
  }
  uVar4 = 0;
LAB_009cb2bc:
  if (uVar4 == 0) {
    if (uVar2 < uVar1) {
      return 1;
    }
    uVar4 = 0;
  }
  return uVar4 >> 0x1f;
}



/* FUNCTION 18940 ; VA 0x009cb2e0 ; FUN_009cb2e0 */

bool FUN_009cb2e0(int *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  
  piVar1 = param_2;
  piVar2 = (int *)*param_1;
  piVar3 = (int *)*param_2;
  if (*(char *)((int)piVar2 + 0x22) == '\0') {
    piVar2 = (int *)0x0;
  }
  if (*(char *)((int)piVar3 + 0x22) == '\0') {
    piVar3 = (int *)0x0;
  }
  if (piVar2 != piVar3) {
    return false;
  }
  (**(code **)(*piVar2 + 0xc))(param_1,&param_1);
  (**(code **)(*piVar3 + 0xc))(piVar1,&param_2);
  return param_1 == param_2;
}



/* FUNCTION 18941 ; VA 0x009cb330 ; FUN_009cb330 */

undefined4 __thiscall FUN_009cb330(int param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  
  piVar2 = *(int **)(param_1 + 4);
  if ((int *)param_2 != piVar2) {
    piVar1 = piVar2 + 4;
    if (0xf < (uint)piVar2[5]) {
      piVar2 = (int *)*piVar2;
    }
    FUN_005542c0(piVar2,*piVar1);
  }
  return 1;
}



/* FUNCTION 18942 ; VA 0x009cb360 ; FUN_009cb360 */

undefined4 __thiscall FUN_009cb360(int param_1,undefined4 param_2)

{
  (**(code **)(**(int **)(param_1 + 0x18) + 0x10))(*(undefined4 *)(param_1 + 0x1c),param_2);
  return 1;
}



/* FUNCTION 18943 ; VA 0x009cb380 ; FUN_009cb380 */

void FUN_009cb380(undefined *param_1,undefined4 param_2,undefined4 param_3)

{
  *(undefined4 *)(param_1 + 0xc) = param_3;
  *(undefined4 *)(param_1 + 8) = 0;
  *param_1 = 1;
  *(undefined4 *)(param_1 + 4) = param_2;
  return;
}



/* FUNCTION 18944 ; VA 0x009cb3a0 ; FUN_009cb3a0 */

void FUN_009cb3a0(undefined *param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = param_2;
  *param_1 = 1;
  return;
}



/* FUNCTION 18945 ; VA 0x009cb3c0 ; FUN_009cb3c0 */

void FUN_009cb3c0(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = FUN_009cb400();
  *param_1 = *(undefined4 *)(iVar1 + 0x20);
  return;
}



/* FUNCTION 18946 ; VA 0x009cb3e0 ; FUN_009cb3e0 */

void FUN_009cb3e0(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = FUN_009cb400();
  *param_1 = *(undefined4 *)(iVar1 + 0x24);
  return;
}



/* FUNCTION 18947 ; VA 0x009cb400 ; FUN_009cb400 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009cb400(void)

{
  float10 fVar1;
  double dVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5a4a;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee43cc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee43cc);
    if (DAT_01ee43cc == -1) {
      uStack_8 = 0;
      _DAT_01ee43a0 = FUN_00601dc0();
      DAT_01ee43a8 = 0;
      _DAT_01ee43ac = FUN_00588320();
      _DAT_01ee43b0 = 0;
      _DAT_01ee43b4 = 0x3f800000;
      _DAT_01ee43b8 = 0;
      _DAT_01ee43bc = 0;
      DAT_01ee43c0 = 0;
      _DAT_01ee43c4 = 0;
      DAT_01ee43c8 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      fVar1 = (float10)FUN_01725160(DAT_0193a168);
      dVar2 = (double)fVar1;
      FUN_016f3eb1();
      FUN_00612320();
      _DAT_01ee43ac = FUN_00588320();
      if ((uint)(DAT_01ee43c8 - DAT_01ee43c0 >> 2) < 0x100) {
        FUN_007cfd20(0x100);
      }
      FUN_016f3654(&LAB_018873c0,dVar2);
      FUN_016f37bf();
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee43a0;
}



/* FUNCTION 18948 ; VA 0x009cb550 ; FUN_009cb550 */

undefined4 FUN_009cb550(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  int iStack_8;
  
  iVar1 = FUN_009cb400();
  iVar1 = iVar1 + 9 + (uint)*(byte *)(iVar1 + 8);
  uVar2 = FUN_00888920(param_1);
  FUN_009ca320(&iStack_8,uVar2,&param_1,-(uint)(iVar1 != 0) & iVar1 + 1U);
  if (iStack_8 != 0) {
    return *(undefined4 *)(iStack_8 + 0xc);
  }
  return 0;
}



/* FUNCTION 18949 ; VA 0x009cb5a0 ; FUN_009cb5a0 */

undefined4 __thiscall FUN_009cb5a0(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = FUN_0086e8f0(param_2);
  iVar2 = FUN_0086e640();
  if (iVar1 != iVar2) {
    param_2 = iVar1;
    piVar3 = (int *)FUN_0061dc20(&param_2);
    if (piVar3 != (int *)0x0) {
      return *(undefined4 *)(*(int *)(param_1 + 0x4c) + *piVar3 * 4);
    }
  }
  return 0;
}



/* FUNCTION 18950 ; VA 0x009cb5f0 ; FUN_009cb5f0 */

undefined4 __thiscall FUN_009cb5f0(int param_1,uint param_2,int *param_3)

{
  int iVar1;
  
  if (-1 < (int)param_2) {
    if (param_2 < (uint)(*(int *)(param_1 + 0x5c) - *(int *)(param_1 + 0x58) >> 2)) {
      iVar1 = *(int *)(*(int *)(param_1 + 0x58) + param_2 * 4);
      *param_3 = iVar1;
      if (iVar1 != -1) {
        return 1;
      }
    }
  }
  return 0;
}



/* FUNCTION 18951 ; VA 0x009cb630 ; FUN_009cb630 */

void __fastcall FUN_009cb630(int *param_1)

{
  if (((uint)param_1[9] >> 3 & 1) != 0) {
                    /* WARNING: Could not recover jumptable at 0x009cb640. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*param_1 + 0x40))();
    return;
  }
  return;
}



/* FUNCTION 18952 ; VA 0x009cb650 ; FUN_009cb650 */

void __thiscall FUN_009cb650(int param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  uint uVar3;
  undefined4 *puVar4;
  
  FUN_00780ee0(param_2);
  puVar4 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
  puVar2 = *(undefined4 **)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
  while (puVar2 != (undefined4 *)0x0) {
    uVar3 = (uint)puVar2[1] % *(uint *)(param_1 + 4);
    piVar1 = (int *)(*(int *)(param_1 + 0x14) + uVar3 * 4);
    if (*(int *)(*(int *)(param_1 + 0x14) + uVar3 * 4) == 0) {
      *piVar1 = (int)puVar4;
      puVar4 = puVar2;
    }
    else {
      *puVar4 = *puVar2;
      *puVar2 = *(undefined4 *)*piVar1;
      *(undefined4 **)*piVar1 = puVar2;
    }
    puVar2 = (undefined4 *)*puVar4;
  }
  return;
}



/* FUNCTION 18953 ; VA 0x009cb6b0 ; FUN_009cb6b0 */

undefined4 * __thiscall FUN_009cb6b0(int *param_1,undefined4 param_2,char param_3)

{
  undefined4 uVar1;
  int iVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  
  if (param_3 == '\0') {
    cVar3 = (**(code **)(*param_1 + 8))();
    if ((cVar3 != '\0') || (((uint)param_1[9] >> 4 & 1) == 0)) {
      return (undefined4 *)0x0;
    }
  }
  puVar4 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    uVar1 = *(undefined4 *)(param_1[10] + 0x18);
    *puVar4 = 0;
    puVar4[1] = 0;
    puVar4[2] = 0;
    puVar4[4] = uVar1;
    puVar4[5] = 0;
    puVar4[8] = 0;
    puVar4[9] = 0;
  }
  uVar1 = DAT_01ede5b8;
  iVar2 = param_1[1];
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[2] = uVar1;
    puVar5[3] = 1;
    puVar5[4] = iVar2;
  }
  if ((undefined4 *)puVar4[9] == (undefined4 *)0x0) {
    puVar4[8] = puVar5;
  }
  else {
    *(undefined4 *)puVar4[9] = puVar5;
  }
  puVar4[9] = puVar5;
  (**(code **)(*param_1 + 0x3c))(param_2,puVar4);
  return puVar4;
}



/* FUNCTION 18954 ; VA 0x009cb790 ; FUN_009cb790 */

undefined4 * __thiscall
FUN_009cb790(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined8 param_5,undefined4 param_6)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5a73;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00dab170();
  FUN_00892310(param_2,param_3,"Function",param_5,param_6,param_4,uVar1);
  uStack_8 = 0;
  *param_1 = RBX::Reflection::FunctionDescriptor::vftable;
  FUN_00888780();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  param_1[0xd] = 0;
  FUN_00892950(param_1);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18955 ; VA 0x009cb820 ; FUN_009cb820 */

undefined4 * __thiscall
FUN_009cb820(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined8 param_5,undefined4 param_6)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5a73;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00dab1a0();
  FUN_00892310(param_2,param_3,"YieldFunction",param_5,param_6,param_4,uVar1);
  uStack_8 = 0;
  *param_1 = RBX::Reflection::YieldFunctionDescriptor::vftable;
  FUN_00888780();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00892950(param_1);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18956 ; VA 0x009cb8b0 ; FUN_009cb8b0 */

void __fastcall FUN_009cb8b0(undefined4 *param_1)

{
  *param_1 = RBX::Reflection::FunctionDescriptor::vftable;
  FUN_00888910();
  FUN_008925b0();
  return;
}



/* FUNCTION 18957 ; VA 0x009cb8d0 ; FUN_009cb8d0 */

void __fastcall FUN_009cb8d0(undefined4 *param_1)

{
  *param_1 = RBX::Reflection::YieldFunctionDescriptor::vftable;
  FUN_00888910();
  FUN_008925b0();
  return;
}



/* FUNCTION 18958 ; VA 0x009cb8f0 ; FUN_009cb8f0 */

undefined4 * __thiscall FUN_009cb8f0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::FunctionDescriptor::vftable;
  FUN_00888910();
  FUN_008925b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x38);
  }
  return param_1;
}



/* FUNCTION 18959 ; VA 0x009cb930 ; FUN_009cb930 */

undefined4 * __thiscall FUN_009cb930(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::YieldFunctionDescriptor::vftable;
  FUN_00888910();
  FUN_008925b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x34);
  }
  return param_1;
}



/* FUNCTION 18960 ; VA 0x009cb970 ; FUN_009cb970 */

undefined4 * __thiscall
FUN_009cb970(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined8 param_5,undefined4 param_6)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5a73;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00dab190();
  FUN_00892310(param_2,param_3,"Signals",param_5,param_6,param_4,uVar1);
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EventDescriptor::vftable;
  FUN_00888780();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00892950(param_1);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18961 ; VA 0x009cba00 ; FUN_009cba00 */

void __fastcall FUN_009cba00(undefined4 *param_1)

{
  *param_1 = RBX::Reflection::EventDescriptor::vftable;
  FUN_00888910();
  FUN_008925b0();
  return;
}



/* FUNCTION 18962 ; VA 0x009cba20 ; FUN_009cba20 */

undefined4 * __thiscall FUN_009cba20(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EventDescriptor::vftable;
  FUN_00888910();
  FUN_008925b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x34);
  }
  return param_1;
}



/* FUNCTION 18963 ; VA 0x009cba60 ; FUN_009cba60 */

void FUN_009cba60(undefined *param_1,undefined4 param_2,undefined4 param_3)

{
  *(undefined4 *)(param_1 + 0xc) = param_2;
  *(undefined4 *)(param_1 + 8) = 0;
  *param_1 = 1;
  *(undefined4 *)(param_1 + 4) = param_3;
  return;
}



/* FUNCTION 18964 ; VA 0x009cba80 ; FUN_009cba80 */

void __thiscall FUN_009cba80(undefined4 param_1,int *param_2,undefined4 param_3)

{
  (**(code **)(*param_2 + 0x14))(param_1,param_3);
  return;
}



/* FUNCTION 18965 ; VA 0x009cbaa0 ; FUN_009cbaa0 */

void FUN_009cbaa0(void)

{
  FUN_00558b30();
  return;
}



/* FUNCTION 18966 ; VA 0x009cbab0 ; FUN_009cbab0 */

void FUN_009cbab0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  if (param_1 != 0) {
    uVar6 = *(uint *)(param_1 + 0x2c);
    if (0xf < uVar6) {
      iVar4 = *(int *)(param_1 + 0x18);
      uVar3 = uVar6 + 1;
      iVar2 = iVar4;
      if (0xfff < uVar3) {
        iVar2 = *(int *)(iVar4 + -4);
        uVar3 = uVar6 + 0x24;
        if (0x1f < (iVar4 - iVar2) - 4U) goto LAB_009cbba8;
      }
      FUN_01674ea0(iVar2,uVar3);
    }
    *(undefined4 *)(param_1 + 0x28) = 0;
    *(undefined4 *)(param_1 + 0x2c) = 0xf;
    *(undefined *)(param_1 + 0x18) = 0;
    iVar4 = *(int *)(param_1 + 0x14);
    if (iVar4 != 0) {
      if (*(int *)(param_1 + 8) != 0) {
        puVar7 = *(undefined4 **)(iVar4 + *(int *)(param_1 + 4) * 4);
        puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
        do {
          *puVar1 = *puVar7;
          FUN_00560a10(-(uint)(param_1 != -3) & param_1 + 4U,puVar7 + 2);
          FUN_01674ea0(puVar7,0x38);
          *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
          puVar7 = (undefined4 *)*puVar1;
        } while (puVar7 != (undefined4 *)0x0);
        iVar4 = *(int *)(param_1 + 0x14);
      }
      iVar2 = *(int *)(param_1 + 4) * 4;
      uVar6 = iVar2 + 4;
      iVar5 = iVar4;
      if (0xfff < uVar6) {
        iVar5 = *(int *)(iVar4 + -4);
        uVar6 = iVar2 + 0x27;
        if (0x1f < (iVar4 - iVar5) - 4U) {
LAB_009cbba8:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar6);
      *(undefined4 *)(param_1 + 0x14) = 0;
      *(undefined4 *)(param_1 + 0x10) = 0;
    }
    FUN_01674ea0(param_1,0x30);
  }
  return;
}



/* FUNCTION 18967 ; VA 0x009cbbb0 ; FUN_009cbbb0 */

void FUN_009cbbb0(undefined4 *param_1)

{
  uint uVar1;
  undefined4 *puVar2;
  
  uVar1 = 0;
  if (param_1[4] != 0) {
    do {
      puVar2 = param_1;
      if (0xf < (uint)param_1[5]) {
        puVar2 = (undefined4 *)*param_1;
      }
      if (*(char *)((int)puVar2 + uVar1) == '\\') {
        puVar2 = param_1;
        if (0xf < (uint)param_1[5]) {
          puVar2 = (undefined4 *)*param_1;
        }
        *(undefined *)((int)puVar2 + uVar1) = 0x2f;
      }
      uVar1 = uVar1 + 1;
    } while (uVar1 < (uint)param_1[4]);
  }
  return;
}



/* FUNCTION 18968 ; VA 0x009cbbf0 ; FUN_009cbbf0 */

void __thiscall FUN_009cbbf0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  
  uVar3 = 0xb;
  if ((uint)param_1[4] < 0xb) {
    uVar3 = param_1[4];
  }
  puVar1 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar1 = (undefined4 *)*param_1;
  }
  iVar2 = FUN_0055c2d0(puVar1,uVar3,"rbxasset://",0xb);
  if (iVar2 == 0) {
    FUN_00fb75b0(param_1,param_2);
  }
  return;
}



/* FUNCTION 18969 ; VA 0x009cbc40 ; FUN_009cbc40 */

undefined FUN_009cbc40(void)

{
  char cVar1;
  undefined **ppuVar2;
  
  ppuVar2 = &PTR_s_asset_01d65360;
  do {
    cVar1 = FUN_0151ce60(*ppuVar2);
    if (cVar1 != '\0') {
      return 1;
    }
    ppuVar2 = ppuVar2 + 1;
  } while (ppuVar2 != (undefined **)&DAT_01d653a0);
  return 0;
}



/* FUNCTION 18970 ; VA 0x009cbc80 ; FUN_009cbc80 */

/* WARNING: Type propagation algorithm not settling */

void __thiscall FUN_009cbc80(uint *param_1,undefined4 *param_2,undefined8 param_3)

{
  int *piVar1;
  undefined8 uVar2;
  code *pcVar3;
  char cVar4;
  uint *puVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  uint uVar9;
  char *pcVar10;
  int iVar11;
  uint uVar12;
  int iVar13;
  undefined **appuStack_10c [4];
  undefined *apuStack_fc [2];
  undefined **ppuStack_f4;
  int aiStack_f0 [2];
  int *piStack_e8;
  int *piStack_e4;
  int aiStack_e0 [2];
  int *piStack_d8;
  uint *puStack_d4;
  int aiStack_d0 [2];
  int *piStack_c8;
  int *piStack_c4;
  int iStack_c0;
  uint uStack_bc;
  uint uStack_b8;
  undefined **ppuStack_a4;
  undefined auStack_5c [16];
  int iStack_4c;
  undefined4 uStack_48;
  uint auStack_44 [2];
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined8 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5aeb;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uVar9 = param_1[4];
  uVar12 = 0xd;
  if (uVar9 < 0xd) {
    uVar12 = uVar9;
  }
  puVar5 = param_1;
  if (0xf < param_1[5]) {
    puVar5 = (uint *)*param_1;
  }
  ExceptionList = &pvStack_10;
  uStack_34 = FUN_0055c2d0(puVar5,uVar12,"rbxassetid://",0xd);
  if (uStack_34 == 0) {
    uStack_30 = 0xf;
    auStack_44[0] = auStack_44[0] & 0xffffff00;
    if (0xc < uVar9) {
      iVar11 = -1;
      if (uVar9 - 0xd != -1) {
        iVar11 = uVar9 - 0xd;
      }
      puVar5 = param_1;
      if (0xf < param_1[5]) {
        puVar5 = (uint *)*param_1;
      }
      FUN_005542c0((int)puVar5 + 0xd,iVar11);
      uStack_8 = 0;
      FUN_009cc260(param_1,param_2,auStack_44);
      if (uStack_30 < 0x10) {
        ExceptionList = pvStack_10;
        return;
      }
      uVar12 = uStack_30 + 1;
      uVar9 = auStack_44[0];
      if (0xfff < uVar12) {
        uVar9 = *(uint *)(auStack_44[0] - 4);
        uVar12 = uStack_30 + 0x24;
        if (0x1f < (auStack_44[0] - uVar9) - 4) goto LAB_009cc1a1;
      }
      FUN_01674ea0(uVar9,uVar12);
      ExceptionList = pvStack_10;
      return;
    }
    FUN_00554050();
LAB_009cc1a1:
                    /* WARNING: Subroutine does not return */
    FUN_017167a3();
  }
  uVar12 = 10;
  if (uVar9 < 10) {
    uVar12 = uVar9;
  }
  puVar5 = param_1;
  if (0xf < param_1[5]) {
    puVar5 = (uint *)*param_1;
  }
  iStack_4c = FUN_0055c2d0(puVar5,uVar12,"rbxhttp://",10);
  if (iStack_4c == 0) {
    uStack_48 = 0xf;
    auStack_5c[0] = 0;
    if (uVar9 < 10) {
      FUN_00554050();
      pcVar3 = (code *)swi(3);
      (*pcVar3)();
      return;
    }
    iVar11 = -1;
    if (uVar9 - 10 != -1) {
      iVar11 = uVar9 - 10;
    }
    puVar5 = param_1;
    if (0xf < param_1[5]) {
      puVar5 = (uint *)*param_1;
    }
    FUN_005542c0((int)puVar5 + 10,iVar11);
    uStack_8 = 1;
    puVar7 = param_2 + 4;
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    puVar5 = (uint *)FUN_00585d40(0,param_2,*puVar7);
    uStack_3c = *puVar5;
    uStack_38 = puVar5[1];
    uStack_34 = puVar5[2];
    uStack_30 = puVar5[3];
    uVar2 = *(undefined8 *)(puVar5 + 4);
    puVar5[4] = 0;
    puVar5[5] = 0xf;
    *(undefined *)puVar5 = 0;
    uStack_2c = uStack_3c;
    uStack_28 = uStack_38;
    uStack_24 = uStack_34;
    uStack_20 = uStack_30;
    uStack_1c = uVar2;
    if (param_1 != &uStack_2c) {
      FUN_005507b0();
      uStack_1c = 0xf00000000;
      *param_1 = uStack_3c;
      param_1[1] = uStack_38;
      param_1[2] = uStack_34;
      param_1[3] = uStack_30;
      uStack_2c = uStack_2c & 0xffffff00;
      *(undefined8 *)(param_1 + 4) = uVar2;
    }
    FUN_005507b0();
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  cVar4 = FUN_009cc920();
  if (cVar4 == '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  if (param_2[4] == 0) {
    ExceptionList = pvStack_10;
    return;
  }
  appuStack_10c[0] = &PTR_018bf148;
  apuStack_fc[0] = &DAT_018bf150;
  ppuStack_a4 = std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
  uStack_8 = 2;
  uStack_14 = 8;
  FUN_00564f30(&ppuStack_f4,0);
  uStack_8 = 3;
  *(undefined ***)((int)appuStack_10c + (int)appuStack_10c[0][1]) =
       std::basic_stringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(&stack0xfffffef0 + (int)appuStack_10c[0][1]) = appuStack_10c[0][1] + -0x68;
  ppuStack_f4 = std::basic_streambuf<char,struct_std::char_traits<char>_>::vftable;
  iStack_c0 = FUN_01674e20(8);
  if (iStack_c0 == 0) {
    iStack_c0 = 0;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    uVar6 = FUN_016de181(1);
    *(undefined4 *)(iStack_c0 + 4) = uVar6;
  }
  piStack_e8 = aiStack_f0;
  piStack_e4 = aiStack_f0 + 1;
  piStack_d8 = aiStack_e0;
  puStack_d4 = (uint *)(aiStack_e0 + 1);
  piStack_c8 = aiStack_d0;
  piStack_c4 = aiStack_d0 + 1;
  aiStack_f0[1] = 0;
  aiStack_e0[1] = 0;
  aiStack_d0[1] = 0;
  aiStack_f0[0] = 0;
  aiStack_e0[0] = 0;
  aiStack_d0[0] = 0;
  ppuStack_f4 = std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                ::vftable;
  uStack_bc = 0;
  uStack_b8 = 0;
  uStack_8 = 5;
  puVar7 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar7 = (undefined4 *)*param_2;
  }
  FUN_0055b3b0(apuStack_fc,puVar7,param_2[4]);
  piVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  if (*(char *)((int)param_2 + *piVar1 + -1) != '/') {
    FUN_005ed940(apuStack_fc,0x2f);
  }
  pcVar10 = PTR_DAT_01d65354;
  do {
    cVar4 = *pcVar10;
    pcVar10 = pcVar10 + 1;
  } while (cVar4 != '\0');
  puVar8 = (undefined4 *)
           FUN_0058c540(&uStack_2c,(int)pcVar10 - (int)(PTR_DAT_01d65354 + 1),0xffffffff);
  puVar7 = puVar8 + 4;
  uStack_8._0_1_ = 6;
  if (0xf < (uint)puVar8[5]) {
    puVar8 = (undefined4 *)*puVar8;
  }
  puVar8 = (undefined4 *)FUN_0151d700(auStack_5c,puVar8,*puVar7);
  uStack_8._0_1_ = 7;
  uVar6 = FUN_00558890(apuStack_fc,"asset/","?universeId=");
  FUN_00558890(uVar6);
  uVar6 = FUN_00872bd0((undefined4)param_3,param_3._4_4_,&DAT_0191bfa0);
  uVar6 = FUN_00558890(uVar6);
  uVar6 = FUN_00558890(uVar6,PTR_s_assetName__01d65358);
  puVar7 = puVar8 + 4;
  if (0xf < (uint)puVar8[5]) {
    puVar8 = (undefined4 *)*puVar8;
  }
  uVar6 = FUN_0055b3b0(uVar6,puVar8,*puVar7,"&skipSigningScripts=1");
  FUN_00558890(uVar6);
  FUN_005507b0();
  FUN_005507b0();
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  uStack_1c = 0xf00000000;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_14 = 0x28;
  if (((uStack_b8 & 2) == 0) && (uVar9 = *puStack_d4, uVar9 != 0)) {
    if (uVar9 < uStack_bc) {
      uVar9 = uStack_bc;
    }
    iVar11 = *piStack_e4;
    iVar13 = uVar9 - iVar11;
  }
  else {
    if (((uStack_b8 & 4) != 0) || (*piStack_d8 == 0)) goto LAB_009cc16c;
    iVar11 = *piStack_e8;
    iVar13 = (*piStack_c8 - iVar11) + *piStack_d8;
  }
  FUN_005542c0(iVar11,iVar13);
LAB_009cc16c:
  FUN_005511f0(&uStack_2c);
  FUN_005507b0();
  FUN_005705c0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18971 ; VA 0x009cc1b0 ; FUN_009cc1b0 */

void __thiscall FUN_009cc1b0(char *param_1,undefined4 param_2)

{
  int iVar1;
  char *pcVar2;
  char *pcVar3;
  undefined4 uVar4;
  
  uVar4 = 0xb;
  if (*(uint *)(param_1 + 0x10) < 0xb) {
    uVar4 = *(undefined4 *)(param_1 + 0x10);
  }
  pcVar2 = param_1;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    pcVar2 = *(char **)param_1;
  }
  iVar1 = FUN_0055c2d0(pcVar2,uVar4,"rbxasset://",0xb);
  if (iVar1 == 0) {
    FUN_005789c0(&DAT_01ee43e0,FUN_009cc8b0);
    pcVar2 = (char *)FUN_00fb7660(param_1);
    if (*(int *)(pcVar2 + 0x10) != 0) {
      pcVar3 = pcVar2;
      if (0xf < *(uint *)(pcVar2 + 0x14)) {
        pcVar3 = *(char **)pcVar2;
      }
      iVar1 = FUN_0171db62((int)*pcVar3);
      if (iVar1 != 0) {
        FUN_009cc260(param_1,param_2,pcVar2);
        return;
      }
      if (param_1 != pcVar2) {
        pcVar3 = pcVar2 + 0x10;
        if (0xf < *(uint *)(pcVar2 + 0x14)) {
          pcVar2 = *(char **)pcVar2;
        }
        FUN_005542c0(pcVar2,*(undefined4 *)pcVar3);
      }
    }
  }
  return;
}



/* FUNCTION 18972 ; VA 0x009cc260 ; FUN_009cc260 */

void FUN_009cc260(int *param_1,int *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  
  FUN_0058a190(param_2[4] + param_3[4] + 0x10);
  if (param_1 != param_2) {
    piVar5 = param_2 + 4;
    if (0xf < (uint)param_2[5]) {
      param_2 = (int *)*param_2;
    }
    FUN_005542c0(param_2,*piVar5);
  }
  uVar2 = param_1[4];
  if (uVar2 != 0) {
    piVar5 = param_1;
    if (0xf < (uint)param_1[5]) {
      piVar5 = (int *)*param_1;
    }
    if (*(char *)((int)piVar5 + (uVar2 - 1)) == '/') goto LAB_009cc38a;
  }
  uVar3 = param_1[5];
  if (uVar2 < uVar3) {
    param_1[4] = uVar2 + 1;
    if (0xf < uVar3) {
      param_1 = (int *)*param_1;
    }
    *(undefined2 *)((int)param_1 + uVar2) = 0x2f;
  }
  else {
    if (uVar2 == 0x7fffffff) {
      FUN_00554040();
LAB_009cc3ba:
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    uVar8 = uVar2 + 1 | 0xf;
    if (uVar8 < 0x80000000) {
      if (0x7fffffff - (uVar3 >> 1) < uVar3) {
        uVar8 = 0x7fffffff;
      }
      else {
        uVar6 = (uVar3 >> 1) + uVar3;
        if (uVar8 < uVar6) {
          uVar8 = uVar6;
        }
      }
    }
    else {
      uVar8 = 0x7fffffff;
    }
    iVar7 = FUN_00554060(uVar8 + 1);
    param_1[5] = uVar8;
    param_1[4] = uVar2 + 1;
    if (uVar3 < 0x10) {
      FUN_0170c6f0(iVar7,param_1,uVar2);
      *(undefined2 *)(iVar7 + uVar2) = 0x2f;
    }
    else {
      iVar4 = *param_1;
      FUN_0170c6f0(iVar7,iVar4,uVar2);
      uVar8 = uVar3 + 1;
      *(undefined2 *)(iVar7 + uVar2) = 0x2f;
      iVar9 = iVar4;
      if (0xfff < uVar8) {
        iVar9 = *(int *)(iVar4 + -4);
        uVar8 = uVar3 + 0x24;
        if (0x1f < (iVar4 - iVar9) - 4U) goto LAB_009cc3ba;
      }
      FUN_01674ea0(iVar9,uVar8);
    }
    *param_1 = iVar7;
  }
LAB_009cc38a:
  FUN_00554150("asset/?id=",10);
  puVar1 = param_3 + 4;
  if (0xf < (uint)param_3[5]) {
    param_3 = (undefined4 *)*param_3;
  }
  FUN_00554150(param_3,*puVar1);
  return;
}



/* FUNCTION 18973 ; VA 0x009cc3c0 ; FUN_009cc3c0 */

undefined4 FUN_009cc3c0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675640(aiStack_28,"rbxassetid://%lld",param_2,param_3);
  uStack_8 = 0;
  FUN_005c4600(uVar1);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18974 ; VA 0x009cc450 ; FUN_009cc450 */

undefined4 FUN_009cc450(undefined4 param_1,char *param_2)

{
  char cVar1;
  int iVar2;
  undefined4 ****ppppuVar3;
  char *pcVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 ***apppuStack_2c [4];
  int iStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5b21;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  iStack_1c = 0;
  uStack_18 = 0xf;
  apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
  ExceptionList = &pvStack_10;
  FUN_005542c0("rbxasset://",0xb);
  iVar2 = iStack_1c;
  uStack_8 = 1;
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  uStack_14 = 2;
  pcVar4 = param_2;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  FUN_0058a190(pcVar4 + (iStack_1c - (int)(param_2 + 1)));
  ppppuVar3 = apppuStack_2c;
  if (0xf < uStack_18) {
    ppppuVar3 = (undefined4 ****)apppuStack_2c[0];
  }
  FUN_00554150(ppppuVar3,iVar2);
  pcVar4 = param_2;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  FUN_00554150(param_2,(int)pcVar4 - (int)(param_2 + 1));
  FUN_005c4600(auStack_44);
  if (0xf < uStack_30) {
    uVar5 = uStack_30 + 1;
    uVar6 = auStack_44[0];
    if (0xfff < uVar5) {
      uVar6 = *(uint *)(auStack_44[0] - 4);
      uVar5 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar5);
  }
  if (0xf < uStack_18) {
    uVar6 = uStack_18 + 1;
    ppppuVar3 = (undefined4 ****)apppuStack_2c[0];
    if (0xfff < uVar6) {
      ppppuVar3 = (undefined4 ****)apppuStack_2c[0][-1];
      uVar6 = uStack_18 + 0x24;
      if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar3,uVar6);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18975 ; VA 0x009cc590 ; FUN_009cc590 */

undefined4 FUN_009cc590(undefined4 param_1,undefined4 param_2)

{
  FUN_005c4600(param_2);
  return param_1;
}



/* FUNCTION 18976 ; VA 0x009cc5b0 ; FUN_009cc5b0 */

undefined * __thiscall FUN_009cc5b0(undefined4 *param_1,undefined *param_2)

{
  code *pcVar1;
  char cVar2;
  undefined uVar3;
  int iVar4;
  int iVar5;
  undefined4 ****ppppuVar6;
  uint uVar7;
  undefined *puVar8;
  undefined4 *puVar9;
  uint uVar10;
  uint uVar11;
  undefined1 *puVar12;
  undefined4 ***apppuStack_28 [4];
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uVar11 = param_1[4];
  uVar10 = param_1[5];
  uVar7 = 0xd;
  if (uVar11 < 0xd) {
    uVar7 = uVar11;
  }
  puVar9 = param_1;
  if (0xf < uVar10) {
    puVar9 = (undefined4 *)*param_1;
  }
  ExceptionList = &pvStack_10;
  iVar4 = FUN_0055c2d0(puVar9,uVar7,"rbxassetid://",0xd);
  if (iVar4 == 0) {
    *(undefined4 *)(param_2 + 0x10) = 0;
    *(undefined4 *)(param_2 + 0x14) = 0xf;
    *param_2 = 0;
    if ((uint)param_1[4] < 0xd) {
      FUN_00554050();
      pcVar1 = (code *)swi(3);
      puVar8 = (undefined *)(*pcVar1)();
      return puVar8;
    }
    iVar5 = param_1[4] - 0xd;
    iVar4 = -1;
    if (iVar5 != -1) {
      iVar4 = iVar5;
    }
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    puVar12 = (undefined1 *)((int)param_1 + 0xd);
    goto LAB_009cc7bd;
  }
  uVar7 = 4;
  if (uVar11 < 4) {
    uVar7 = uVar11;
  }
  puVar9 = param_1;
  if (0xf < uVar10) {
    puVar9 = (undefined4 *)*param_1;
  }
  iVar4 = FUN_0055c2d0(puVar9,uVar7,&DAT_018c71bc,4);
  if (iVar4 == 0) {
LAB_009cc6ca:
    FUN_0054ef60(param_1);
    uVar10 = 0;
    uStack_8 = 0;
    uVar11 = uStack_18;
    if (uStack_18 != 0) {
      do {
        ppppuVar6 = apppuStack_28;
        if (0xf < uStack_14) {
          ppppuVar6 = (undefined4 ****)apppuStack_28[0];
        }
        iVar4 = FUN_0171dc5a(*(undefined *)((int)ppppuVar6 + uVar10));
        if (iVar4 != 0) {
          ppppuVar6 = apppuStack_28;
          if (0xf < uStack_14) {
            ppppuVar6 = (undefined4 ****)apppuStack_28[0];
          }
          uVar3 = FUN_01725677(*(undefined *)((int)ppppuVar6 + uVar10));
          ppppuVar6 = apppuStack_28;
          if (0xf < uStack_14) {
            ppppuVar6 = (undefined4 ****)apppuStack_28[0];
          }
          *(undefined *)((int)ppppuVar6 + uVar10) = uVar3;
        }
        uVar10 = uVar10 + 1;
        uVar11 = uStack_18;
      } while (uVar10 < uStack_18);
    }
    iVar4 = FUN_0058eea0(&DAT_0193a3fc,0);
    if (iVar4 != -1) {
      uVar10 = iVar4 + 3;
      ppppuVar6 = apppuStack_28;
      if (0xf < uStack_14) {
        ppppuVar6 = (undefined4 ****)apppuStack_28[0];
      }
      if ((uVar10 < uVar11) &&
         (iVar4 = FUN_0170db20((int)ppppuVar6 + uVar10,0x26,uVar11 - uVar10), iVar4 != 0)) {
        uVar7 = iVar4 - (int)ppppuVar6;
      }
      else {
        uVar7 = 0xffffffff;
      }
      if (uVar7 != 0xffffffff) {
        uVar11 = uVar7;
      }
      FUN_0058c540(param_2,uVar10,uVar11 - uVar10);
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return param_2;
    }
    uStack_8 = 0xffffffff;
    FUN_005507b0();
  }
  else {
    uVar7 = 10;
    if (uVar11 < 10) {
      uVar7 = uVar11;
    }
    puVar9 = param_1;
    if (0xf < uVar10) {
      puVar9 = (undefined4 *)*param_1;
    }
    iVar4 = FUN_0055c2d0(puVar9,uVar7,"rbxhttp://",10);
    if (iVar4 == 0) goto LAB_009cc6ca;
    if ((DAT_01d62f98 != '\0') && (cVar2 = FUN_008d0830(), cVar2 != '\0')) {
      iVar4 = FUN_00591310(0x2f,0x16);
      if (iVar4 == -1) {
        iVar4 = param_1[4];
      }
      FUN_0058c540(param_2,0x16,iVar4 + -0x16);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  iVar4 = 0;
  puVar12 = &DAT_018bc9b8;
  *(undefined4 *)(param_2 + 0x10) = 0;
  *(undefined4 *)(param_2 + 0x14) = 0xf;
  *param_2 = 0;
LAB_009cc7bd:
  FUN_005542c0(puVar12,iVar4);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18977 ; VA 0x009cc7e0 ; FUN_009cc7e0 */

undefined * __thiscall FUN_009cc7e0(undefined4 *param_1,undefined *param_2)

{
  uint uVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  
  uVar4 = param_1[4];
  uVar1 = 0x16;
  if (uVar4 < 0x16) {
    uVar1 = uVar4;
  }
  puVar3 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar3 = (undefined4 *)*param_1;
  }
  iVar2 = FUN_0055c2d0(puVar3,uVar1,"rbxencryptedassetid://",0x16);
  if ((iVar2 != 0) || (DAT_01d62f98 == '\0')) {
    *(undefined4 *)(param_2 + 0x10) = 0;
    *(undefined4 *)(param_2 + 0x14) = 0xf;
    *param_2 = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    return param_2;
  }
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  if (0x16 < uVar4) {
    iVar2 = FUN_0170db20((int)param_1 + 0x16,0x2f,uVar4 - 0x16);
    if (iVar2 != 0) {
      iVar2 = iVar2 - (int)param_1;
      goto LAB_009cc848;
    }
  }
  iVar2 = -1;
LAB_009cc848:
  if (iVar2 != -1) {
    uVar4 = iVar2 + 1;
  }
  FUN_0058c540(param_2,uVar4,0xffffffff);
  return param_2;
}



/* FUNCTION 18978 ; VA 0x009cc8a0 ; FUN_009cc8a0 */

void FUN_009cc8a0(undefined4 param_1)

{
  FUN_005702d0(param_1);
  return;
}



/* FUNCTION 18979 ; VA 0x009cc8b0 ; FUN_009cc8b0 */

void __fastcall FUN_009cc8b0(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  bool bVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179209f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01674e20(0x30,param_1);
  uStack_8 = 0;
  if (iVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_00fae1e0(iVar1);
  }
  iVar1 = DAT_01ee43d8;
  bVar3 = DAT_01ee43d8 != 0;
  DAT_01ee43d8 = uVar2;
  if (bVar3) {
    FUN_009cbab0(iVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18980 ; VA 0x009cc920 ; FUN_009cc920 */

bool __fastcall FUN_009cc920(undefined4 *param_1)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  char *pcVar4;
  uint uVar5;
  
  pcVar4 = PTR_DAT_01d65354;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  pcVar3 = PTR_DAT_01d65354;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  uVar5 = (int)pcVar4 - (int)(PTR_DAT_01d65354 + 1);
  if ((uint)param_1[4] < (uint)((int)pcVar4 - (int)(PTR_DAT_01d65354 + 1))) {
    uVar5 = param_1[4];
  }
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  iVar2 = FUN_0055c2d0(param_1,uVar5,PTR_DAT_01d65354,(int)pcVar3 - (int)(PTR_DAT_01d65354 + 1));
  return iVar2 == 0;
}



/* FUNCTION 18981 ; VA 0x009cc980 ; FUN_009cc980 */

void FUN_009cc980(undefined4 param_1)

{
  FUN_009cce30(param_1,FUN_009cbc40);
  return;
}



/* FUNCTION 18982 ; VA 0x009cc9a0 ; FUN_009cc9a0 */

undefined4 __fastcall FUN_009cc9a0(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *****pppppuVar5;
  int iVar6;
  undefined4 ****ppppuVar7;
  uint uVar8;
  undefined4 ****appppuStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d5bbd;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 0;
  uStack_7 = 0;
  uStack_28 = 0;
  uStack_24 = 0xf;
  appppuStack_38[0] = (undefined4 ****)((uint)appppuStack_38[0] & 0xffffff00);
  if (10 < (uint)param_1[4]) {
    iVar3 = param_1[4] - 0xb;
    iVar6 = -1;
    if (iVar3 != -1) {
      iVar6 = iVar3;
    }
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    ExceptionList = &pvStack_10;
    FUN_005542c0((int)param_1 + 0xb,iVar6);
    uStack_8 = 1;
    FUN_0151cb70(&uStack_20,appppuStack_38);
    uStack_8 = 0;
    uVar2 = uStack_8;
    uStack_8 = 0;
    if (0xf < uStack_24) {
      uVar8 = uStack_24 + 1;
      ppppuVar7 = appppuStack_38[0];
      if (0xfff < uVar8) {
        ppppuVar7 = (undefined4 ****)appppuStack_38[0][-1];
        uVar8 = uStack_24 + 0x24;
        if (0x1f < (uint)((int)appppuStack_38[0] + (-4 - (int)ppppuVar7))) goto LAB_009cce09;
      }
      FUN_01674ea0(ppppuVar7,uVar8);
    }
    FUN_005542c0("rbxthumb://",0xb);
    puVar4 = (undefined4 *)FUN_0151c4b0(&uStack_20,&DAT_018c7ed0);
    uStack_8 = 2;
    uStack_28 = 0;
    uStack_24 = 0xf;
    appppuStack_38[0] = (undefined4 ****)((uint)appppuStack_38[0] & 0xffffff00);
    uStack_14 = 3;
    FUN_0058a190(puVar4[4] + 5);
    FUN_00554150("type=",5);
    puVar1 = puVar4 + 4;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    FUN_00554150(puVar4,*puVar1);
    pppppuVar5 = appppuStack_38;
    if (0xf < uStack_24) {
      pppppuVar5 = (undefined4 *****)appppuStack_38[0];
    }
    FUN_00554150(pppppuVar5,uStack_28);
    uStack_8 = 0;
    uVar2 = uStack_8;
    uStack_8 = 0;
    if (0xf < uStack_24) {
      uVar8 = uStack_24 + 1;
      pppppuVar5 = (undefined4 *****)appppuStack_38[0];
      if (0xfff < uVar8) {
        pppppuVar5 = (undefined4 *****)appppuStack_38[0][-1];
        uVar8 = uStack_24 + 0x24;
        if (0x1f < (uint)((int)appppuStack_38[0] + (-4 - (int)pppppuVar5))) {
          uStack_8 = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar5,uVar8);
    }
    puVar4 = (undefined4 *)FUN_0151c4b0(&uStack_20,&DAT_018c1fd8);
    uStack_8 = 3;
    uStack_28 = 0;
    uStack_24 = 0xf;
    appppuStack_38[0] = (undefined4 ****)((uint)appppuStack_38[0] & 0xffffff00);
    uStack_14 = 5;
    FUN_0058a190(puVar4[4] + 4);
    FUN_00554150(&DAT_0193a3d4,4);
    puVar1 = puVar4 + 4;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    FUN_00554150(puVar4,*puVar1);
    pppppuVar5 = appppuStack_38;
    if (0xf < uStack_24) {
      pppppuVar5 = (undefined4 *****)appppuStack_38[0];
    }
    FUN_00554150(pppppuVar5,uStack_28);
    uStack_8 = 0;
    uVar2 = uStack_8;
    uStack_8 = 0;
    if (0xf < uStack_24) {
      uVar8 = uStack_24 + 1;
      pppppuVar5 = (undefined4 *****)appppuStack_38[0];
      if (0xfff < uVar8) {
        pppppuVar5 = (undefined4 *****)appppuStack_38[0][-1];
        uVar8 = uStack_24 + 0x24;
        if (0x1f < (uint)((int)appppuStack_38[0] + (-4 - (int)pppppuVar5))) {
          uStack_8 = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar5,uVar8);
    }
    puVar4 = (undefined4 *)FUN_0151c4b0(&uStack_20,&DAT_018d506c);
    uStack_8 = 4;
    uStack_28 = 0;
    uStack_24 = 0xf;
    appppuStack_38[0] = (undefined4 ****)((uint)appppuStack_38[0] & 0xffffff00);
    uStack_14 = 9;
    FUN_0058a190(puVar4[4] + 3);
    FUN_00554150(&DAT_0193a3dc,3);
    puVar1 = puVar4 + 4;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    FUN_00554150(puVar4,*puVar1);
    pppppuVar5 = appppuStack_38;
    if (0xf < uStack_24) {
      pppppuVar5 = (undefined4 *****)appppuStack_38[0];
    }
    FUN_00554150(pppppuVar5,uStack_28);
    uStack_8 = 0;
    uVar2 = uStack_8;
    uStack_8 = 0;
    if (0xf < uStack_24) {
      uVar8 = uStack_24 + 1;
      pppppuVar5 = (undefined4 *****)appppuStack_38[0];
      if (0xfff < uVar8) {
        pppppuVar5 = (undefined4 *****)appppuStack_38[0][-1];
        uVar8 = uStack_24 + 0x24;
        if (0x1f < (uint)((int)appppuStack_38[0] + (-4 - (int)pppppuVar5))) {
          uStack_8 = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar5,uVar8);
    }
    puVar4 = (undefined4 *)FUN_0151c4b0(&uStack_20,&DAT_0193a3e0);
    uStack_8 = 5;
    uStack_28 = 0;
    uStack_24 = 0xf;
    appppuStack_38[0] = (undefined4 ****)((uint)appppuStack_38[0] & 0xffffff00);
    uStack_14 = 0x11;
    FUN_0058a190(puVar4[4] + 3);
    FUN_00554150(&DAT_0193a3e4,3);
    puVar1 = puVar4 + 4;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    FUN_00554150(puVar4,*puVar1);
    pppppuVar5 = appppuStack_38;
    if (0xf < uStack_24) {
      pppppuVar5 = (undefined4 *****)appppuStack_38[0];
    }
    FUN_00554150(pppppuVar5,uStack_28);
    uStack_8 = 0;
    uVar2 = uStack_8;
    uStack_8 = 0;
    if (0xf < uStack_24) {
      uVar8 = uStack_24 + 1;
      pppppuVar5 = (undefined4 *****)appppuStack_38[0];
      if (0xfff < uVar8) {
        pppppuVar5 = (undefined4 *****)appppuStack_38[0][-1];
        uVar8 = uStack_24 + 0x24;
        if (0x1f < (uint)((int)appppuStack_38[0] + (-4 - (int)pppppuVar5))) {
          uStack_8 = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar5,uVar8);
    }
    puVar4 = (undefined4 *)FUN_0151c4b0(&uStack_20,"filters");
    _uStack_8 = CONCAT31(uStack_7,6);
    uStack_28 = 0;
    uStack_24 = 0xf;
    appppuStack_38[0] = (undefined4 ****)((uint)appppuStack_38[0] & 0xffffff00);
    uStack_14 = 0x21;
    FUN_0058a190(puVar4[4] + 9);
    FUN_00554150("&filters=",9);
    puVar1 = puVar4 + 4;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    FUN_00554150(puVar4,*puVar1);
    pppppuVar5 = appppuStack_38;
    if (0xf < uStack_24) {
      pppppuVar5 = (undefined4 *****)appppuStack_38[0];
    }
    FUN_00554150(pppppuVar5,uStack_28);
    if (0xf < uStack_24) {
      uVar8 = uStack_24 + 1;
      pppppuVar5 = (undefined4 *****)appppuStack_38[0];
      if (0xfff < uVar8) {
        pppppuVar5 = (undefined4 *****)appppuStack_38[0][-1];
        uVar8 = uStack_24 + 0x24;
        if (0x1f < (uint)((int)appppuStack_38[0] + (-4 - (int)pppppuVar5))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar5,uVar8);
    }
    thunk_FUN_008c7c70();
    ExceptionList = pvStack_10;
    return 1;
  }
  ExceptionList = &pvStack_10;
  FUN_00554050();
  uVar2 = uStack_8;
LAB_009cce09:
  uStack_8 = uVar2;
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 18983 ; VA 0x009cce30 ; FUN_009cce30 */

undefined __thiscall FUN_009cce30(undefined4 *param_1,undefined4 *param_2,code *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  bool bVar3;
  undefined uVar4;
  char cVar5;
  char cVar6;
  char *pcVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  uint uVar10;
  char *pcVar11;
  int iVar12;
  uint uVar13;
  undefined auStack_1fc [120];
  undefined auStack_184 [24];
  undefined auStack_16c [96];
  undefined auStack_10c [24];
  undefined auStack_f4 [24];
  undefined auStack_dc [16];
  uint uStack_cc;
  undefined auStack_c4 [24];
  undefined auStack_ac [24];
  undefined auStack_94 [12];
  undefined auStack_88 [12];
  char *pcStack_7c;
  undefined auStack_78 [24];
  uint auStack_60 [4];
  undefined4 uStack_50;
  uint uStack_4c;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  char *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5c41;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  pcVar7 = (char *)FUN_01674e20(param_1[4] + 1);
  uVar10 = 0;
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  pcStack_14 = pcVar7;
  pcStack_7c = pcVar7;
  if (param_1[4] != 0) {
    do {
      uVar13 = param_1[5];
      puVar9 = param_1;
      if (0xf < uVar13) {
        puVar9 = (undefined4 *)*param_1;
      }
      if (*(char *)((int)puVar9 + uVar10) == '#') {
        param_2._3_1_ = 0;
        goto LAB_009ccf52;
      }
      puVar9 = param_1;
      if (0xf < uVar13) {
        puVar9 = (undefined4 *)*param_1;
      }
      if (*(char *)((int)puVar9 + uVar10) != ' ') {
        puVar9 = param_1;
        if (0xf < uVar13) {
          puVar9 = (undefined4 *)*param_1;
        }
        *pcStack_14 = *(char *)((int)puVar9 + uVar10);
        pcStack_14 = pcStack_14 + 1;
      }
      uVar10 = uVar10 + 1;
    } while (uVar10 < (uint)param_1[4]);
  }
  *pcStack_14 = '\0';
  if (pcVar7 == (char *)0x0) {
    iVar12 = 0;
  }
  else {
    pcStack_14 = pcVar7 + 1;
    pcVar11 = pcVar7;
    do {
      cVar5 = *pcVar11;
      pcVar11 = pcVar11 + 1;
    } while (cVar5 != '\0');
    iVar12 = (int)pcVar11 - (int)pcStack_14;
  }
  FUN_0151bda0(auStack_10c,pcVar7,iVar12);
  uStack_8._0_1_ = 1;
  if (DAT_01d6534c != '\0') {
    FUN_0151cb00(auStack_88);
    uStack_8._0_1_ = 2;
    cVar5 = FUN_0151c310(auStack_88,&DAT_018d2350);
    if (cVar5 == '\0') {
      uStack_8._0_1_ = 1;
      thunk_FUN_008c7c70();
      goto LAB_009ccf79;
    }
    thunk_FUN_008c7c70();
LAB_009ccf43:
    param_2._3_1_ = 0;
    goto LAB_009ccf47;
  }
LAB_009ccf79:
  cVar5 = FUN_0151c1d0();
  if (cVar5 == '\0') {
    param_2._3_1_ = 1;
    goto LAB_009ccf47;
  }
  cVar5 = FUN_0151c7a0();
  if ((cVar5 == '\0') || (uStack_cc < 2)) goto LAB_009ccf43;
  FUN_0054ef60(auStack_10c);
  uStack_8._0_1_ = 3;
  FUN_0054ef60(auStack_f4);
  uStack_8._0_1_ = 4;
  FUN_0054ef60(auStack_dc);
  uStack_8._0_1_ = 5;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 5;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee43e8) &&
     (uStack_8._0_1_ = uVar4, FUN_016f3809(&DAT_01ee43e8), DAT_01ee43e8 == -1)) {
    uStack_8._0_1_ = 6;
    FUN_005542c0("robloxlabs.com",0xe);
    FUN_016f3654(&LAB_01887460);
    uStack_8._0_1_ = 5;
    FUN_016f37bf(&DAT_01ee43e8);
  }
  puVar9 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_0151bda0(auStack_184,param_2,*puVar9);
  uStack_8._0_1_ = 7;
  cVar5 = (*param_3)(auStack_10c);
  if (cVar5 == '\0') {
    param_2._3_1_ = 0;
  }
  else {
    puVar9 = &DAT_01d653a0;
    if (0xf < DAT_01d653b4) {
      puVar9 = DAT_01d653a0;
    }
    cVar5 = FUN_0151c660(puVar9);
    if (cVar5 == '\0') {
LAB_009cd08a:
      bVar3 = false;
    }
    else {
      puVar9 = &DAT_01d653a0;
      if (0xf < DAT_01d653b4) {
        puVar9 = DAT_01d653a0;
      }
      cVar5 = FUN_0151c660(puVar9);
      bVar3 = true;
      if (cVar5 != '\0') goto LAB_009cd08a;
    }
    cVar5 = FUN_0151ce60("asset");
    if ((cVar5 != '\0') || (cVar5 = FUN_0151ce60("asset/"), cVar5 != '\0')) {
      cVar5 = '\x01';
    }
    if (bVar3) {
      if (((cVar5 == '\0') && (cVar5 = FUN_0151ce60("v1/asset"), cVar5 == '\0')) &&
         (cVar5 = FUN_0151ce60("v1/asset/"), cVar5 == '\0')) {
        FUN_00551260(PTR_s_assetgame_roblox_com_01d653bc);
      }
      else {
        FUN_005542c0("v1/asset",8);
        pcVar11 = PTR_DAT_01d653b8;
        do {
          cVar5 = *pcVar11;
          pcVar11 = pcVar11 + 1;
        } while (cVar5 != '\0');
        FUN_005542c0(PTR_DAT_01d653b8,(int)pcVar11 - (int)(PTR_DAT_01d653b8 + 1));
      }
    }
    else {
      uVar8 = FUN_0151b590(auStack_78,auStack_16c,"games");
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      pcStack_14 = (char *)0x1;
      uStack_18 = 1;
      cVar6 = FUN_00558b30(auStack_30,uVar8);
      if (cVar6 == '\0') {
        uVar8 = FUN_0151b590(auStack_94,auStack_16c,"assetdelivery");
        pcStack_14 = (char *)0x3;
        cVar6 = FUN_00558b30(auStack_30,uVar8);
        bVar3 = false;
        if (cVar6 != '\0') goto LAB_009cd1a2;
      }
      else {
LAB_009cd1a2:
        bVar3 = true;
      }
      if (((uint)pcStack_14 & 2) != 0) {
        FUN_005507b0();
      }
      uStack_8._0_1_ = 7;
      uStack_8._1_3_ = 0;
      FUN_005507b0();
      if (!bVar3) {
        if (cVar5 == '\0') {
          pcVar11 = "assetgame";
        }
        else {
          FUN_005542c0("v1/asset",8);
          pcVar11 = "assetdelivery";
        }
        uVar8 = FUN_0151b590(auStack_78,auStack_16c,pcVar11);
        FUN_005511f0(uVar8);
        FUN_005507b0();
      }
    }
    FUN_005542c0("https",5);
    FUN_0151bcc0(auStack_1fc,auStack_60,auStack_30,auStack_48,auStack_c4,auStack_ac);
    uStack_8._0_1_ = 9;
    puVar9 = (undefined4 *)FUN_0151bb70(auStack_78);
    if (param_1 != puVar9) {
      FUN_005507b0();
      uVar8 = puVar9[1];
      uVar1 = puVar9[2];
      uVar2 = puVar9[3];
      *param_1 = *puVar9;
      param_1[1] = uVar8;
      param_1[2] = uVar1;
      param_1[3] = uVar2;
      *(undefined8 *)(param_1 + 4) = *(undefined8 *)(puVar9 + 4);
      puVar9[4] = 0;
      puVar9[5] = 0xf;
      *(undefined *)puVar9 = 0;
    }
    FUN_005507b0();
    param_2._3_1_ = 1;
    FUN_0056d9d0();
  }
  FUN_0056d9d0();
  if (0xf < uStack_34) {
    uVar13 = uStack_34 + 1;
    uVar10 = auStack_48[0];
    if (0xfff < uVar13) {
      uVar10 = *(uint *)(auStack_48[0] - 4);
      uVar13 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar13);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  if (0xf < uStack_1c) {
    uVar13 = uStack_1c + 1;
    uVar10 = auStack_30[0];
    if (0xfff < uVar13) {
      uVar10 = *(uint *)(auStack_30[0] - 4);
      uVar13 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar13);
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  if (0xf < uStack_4c) {
    uVar13 = uStack_4c + 1;
    uVar10 = auStack_60[0];
    if (0xfff < uVar13) {
      uVar10 = *(uint *)(auStack_60[0] - 4);
      uVar13 = uStack_4c + 0x24;
      if (0x1f < (auStack_60[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar13);
  }
  uStack_50 = 0;
  uStack_4c = 0xf;
  auStack_60[0] = auStack_60[0] & 0xffffff00;
LAB_009ccf47:
  FUN_0056d9d0();
LAB_009ccf52:
  FUN_01674ea0(pcVar7);
  ExceptionList = pvStack_10;
  return param_2._3_1_;
}



/* FUNCTION 18984 ; VA 0x009cd3f0 ; FUN_009cd3f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_009cd3f0(undefined4 *param_1,undefined *param_2)

{
  int *piVar1;
  undefined *puVar2;
  int *piVar3;
  undefined4 *puVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5c5b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee4440) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ee4440), DAT_01ee4440 == -1)) {
    _DAT_01ee4434 = FUN_009d0320;
    _DAT_01ee4438 = FUN_009d0320;
    DAT_01ee443c = FUN_009d05a0;
    FUN_016f37bf(&DAT_01ee4440);
  }
  puVar2 = (undefined *)*param_1;
  if (puVar2 == &DAT_01ee4434) {
    *(undefined *)(param_1 + 1) = *param_2;
    param_1[2] = *(undefined4 *)(param_2 + 4);
    iVar5 = *(int *)(param_2 + 0xc);
    if (iVar5 != 0) {
      LOCK();
      *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
      UNLOCK();
      iVar5 = *(int *)(param_2 + 0xc);
    }
    param_1[3] = *(undefined4 *)(param_2 + 8);
    piVar3 = (int *)param_1[4];
    param_1[4] = iVar5;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar5 = piVar3[1] + -1;
      piVar3[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    puVar4 = (undefined4 *)(param_2 + 0x10);
    if (param_1 + 5 != puVar4) {
      if (0xf < *(uint *)(param_2 + 0x24)) {
        puVar4 = (undefined4 *)*puVar4;
      }
      FUN_005542c0(puVar4,*(undefined4 *)(param_2 + 0x20));
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  else {
    if (puVar2 != (undefined *)0x0) {
      (**(code **)(puVar2 + 8))(param_1 + 1);
      *param_1 = 0;
    }
    *(undefined *)(param_1 + 1) = *param_2;
    param_1[2] = *(undefined4 *)(param_2 + 4);
    param_1[3] = 0;
    param_1[4] = 0;
    if (*(int *)(param_2 + 0xc) != 0) {
      LOCK();
      piVar3 = (int *)(*(int *)(param_2 + 0xc) + 4);
      *piVar3 = *piVar3 + 1;
      UNLOCK();
    }
    param_1[3] = *(undefined4 *)(param_2 + 8);
    param_1[4] = *(undefined4 *)(param_2 + 0xc);
    uStack_8 = 0;
    FUN_0054ef60(param_2 + 0x10);
    *param_1 = &DAT_01ee4434;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18985 ; VA 0x009cd590 ; FUN_009cd590 */

void __thiscall FUN_009cd590(int *param_1,uint param_2,uint param_3)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  
  uVar5 = param_2;
  iVar1 = param_3 - param_2;
  iVar6 = *param_1;
  uVar7 = iVar1 >> 2;
  uVar3 = param_1[2] - iVar6 >> 2;
  uVar2 = param_1[1] - iVar6 >> 2;
  if (uVar3 < uVar7) {
    if (0x3fffffff < uVar7) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    param_2 = uVar3 >> 1;
    uVar2 = uVar7;
    if ((uVar3 <= 0x3fffffff - param_2) && (uVar2 = param_2 + uVar3, param_2 + uVar3 < uVar7)) {
      uVar2 = uVar7;
    }
    if (iVar6 != 0) {
      FUN_0057d270(iVar6,uVar3);
    }
    FUN_005d2220(uVar2);
    uVar2 = 0;
    puVar4 = (undefined4 *)*param_1;
    uVar3 = iVar1 + 3U >> 2;
    if (param_3 < uVar5) {
      uVar3 = 0;
    }
    if (uVar3 != 0) {
      iVar6 = uVar5 - (int)puVar4;
      do {
        uVar2 = uVar2 + 1;
        *puVar4 = *(undefined4 *)(iVar6 + (int)puVar4);
        puVar4 = puVar4 + 1;
      } while (uVar2 != uVar3);
      param_1[1] = (int)puVar4;
      return;
    }
  }
  else {
    if (uVar7 <= uVar2) {
      FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
      FUN_0170cc70(iVar6,uVar5,iVar1);
      param_1[1] = iVar6 + uVar7 * 4;
      return;
    }
    uVar2 = param_2 + uVar2 * 4;
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    FUN_0170cc70(iVar6,uVar5,uVar2 - uVar5);
    uVar5 = 0;
    puVar4 = (undefined4 *)param_1[1];
    uVar3 = (param_3 - uVar2) + 3 >> 2;
    if (param_3 < uVar2) {
      uVar3 = 0;
    }
    if (uVar3 != 0) {
      iVar6 = uVar2 - (int)puVar4;
      do {
        uVar5 = uVar5 + 1;
        *puVar4 = *(undefined4 *)(iVar6 + (int)puVar4);
        puVar4 = puVar4 + 1;
      } while (uVar5 != uVar3);
    }
  }
  param_1[1] = (int)puVar4;
  return;
}



/* FUNCTION 18986 ; VA 0x009cd6d0 ; FUN_009cd6d0 */

void __thiscall FUN_009cd6d0(int param_1,int *param_2,byte *param_3,int *param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d5c70;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  iVar6 = *(int *)(param_1 + 4);
  iVar1 = (*(uint *)(param_1 + 0x18) &
          ((((*param_3 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_3[1]) * 0x1000193 ^ (uint)param_3[2])
           * 0x1000193 ^ (uint)param_3[3]) * 0x1000193) * 8;
  iVar2 = *(int *)(*(int *)(param_1 + 0xc) + iVar1);
  if (iVar6 != iVar2) {
    iVar6 = **(int **)(*(int *)(param_1 + 0xc) + 4 + iVar1);
    while (iVar6 != iVar2) {
      iVar6 = *(int *)(iVar6 + 4);
      if (*(int *)param_3 == *(int *)(iVar6 + 8)) {
        ExceptionList = &pvStack_10;
        *(int *)param_4[1] = *param_4;
        *(int *)(*param_4 + 4) = param_4[1];
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        FUN_01674ea0(param_4,0xc);
        *param_2 = iVar6;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  iVar2 = *param_4;
  ExceptionList = &pvStack_10;
  if (iVar6 != iVar2) {
    ExceptionList = &pvStack_10;
    *(int *)param_4[1] = iVar2;
    **(int **)(iVar2 + 4) = iVar6;
    **(undefined4 **)(iVar6 + 4) = param_4;
    iVar3 = *(int *)(iVar6 + 4);
    *(undefined4 *)(iVar6 + 4) = *(undefined4 *)(iVar2 + 4);
    *(int *)(iVar2 + 4) = param_4[1];
    param_4[1] = iVar3;
  }
  piVar5 = (int *)(*(int *)(param_1 + 0xc) + iVar1);
  if (*piVar5 == *(int *)(param_1 + 4)) {
    *piVar5 = (int)param_4;
    *(int **)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = param_4;
  }
  else if (*piVar5 == iVar6) {
    *piVar5 = (int)param_4;
  }
  else {
    piVar4 = *(int **)piVar5[1];
    piVar5[1] = (int)piVar4;
    if (piVar4 != param_4) {
      *(undefined4 *)(*(int *)(param_1 + 0xc) + 4 + iVar1) =
           *(undefined4 *)(*(int *)(*(int *)(param_1 + 0xc) + 4 + iVar1) + 4);
    }
  }
  uStack_8 = 2;
  FUN_009cff20();
  *param_2 = (int)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18987 ; VA 0x009cd831 ; Catch_All@009cd831 */

void Catch_All_009cd831(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_0070cbb0(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18988 ; VA 0x009cd860 ; FUN_009cd860 */

void FUN_009cd860(int param_1,undefined4 *param_2)

{
  *(undefined4 *)(param_1 + 8) = *param_2;
  return;
}



/* FUNCTION 18989 ; VA 0x009cd880 ; FUN_009cd880 */

void __thiscall FUN_009cd880(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined4 uVar4;
  int *piVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d5c80;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piVar6 = (int *)*param_1;
  ExceptionList = &pvStack_10;
  for (; piVar6 = (int *)*piVar6, param_2 != param_3; param_2 = (undefined4 *)*param_2) {
    if (piVar6 == (int *)*param_1) goto LAB_009cd8d5;
    FUN_009cd860(piVar6,param_2 + 2);
  }
LAB_009cd91c:
  piVar3 = (int *)*param_1;
  piVar5 = (int *)*piVar3;
  if (piVar6 == piVar5) {
    *piVar3 = (int)piVar3;
    *(int *)(*param_1 + 4) = *param_1;
    param_1[1] = 0;
    if (piVar5 != (int *)*param_1) {
      do {
        piVar6 = (int *)*piVar5;
        FUN_01674ea0(piVar5,0xc);
        piVar5 = piVar6;
      } while (piVar6 != (int *)*param_1);
      ExceptionList = pvStack_10;
      return;
    }
  }
  else {
    while (piVar6 != piVar3) {
      piVar5 = (int *)*piVar6;
      *(int **)piVar6[1] = piVar5;
      *(int *)(*piVar6 + 4) = piVar6[1];
      param_1[1] = param_1[1] + -1;
      FUN_01674ea0(piVar6,0xc);
      piVar6 = piVar5;
    }
  }
  ExceptionList = pvStack_10;
  return;
LAB_009cd8d5:
  for (; param_2 != param_3; param_2 = (undefined4 *)*param_2) {
    iVar1 = *param_1;
    puVar2 = *(undefined4 **)(iVar1 + 4);
    uVar4 = FUN_00602bf0(iVar1,puVar2,param_2 + 2);
    if (param_1[1] == 0x15555554) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    param_1[1] = param_1[1] + 1;
    *(undefined4 *)(iVar1 + 4) = uVar4;
    *puVar2 = uVar4;
  }
  goto LAB_009cd91c;
}



/* FUNCTION 18990 ; VA 0x009cd9b1 ; Catch_All@009cd9b1 */

void Catch_All_009cd9b1(void)

{
  FUN_0087de00();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18991 ; VA 0x009cd9d0 ; FUN_009cd9d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_009cd9d0(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined *puVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  
  iVar3 = FUN_01257810(param_1,param_2,DAT_01ede6a8);
  if (iVar3 == 0) {
    return 0;
  }
  uVar4 = FUN_0088caa0();
  iVar2 = _tls_index;
  *param_3 = uVar4;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01eded84) {
    FUN_016f3809(&DAT_01eded84);
    if (DAT_01eded84 == -1) {
      _DAT_01eded78 = FUN_0088e340;
      _DAT_01eded7c = FUN_0088ec70;
      _DAT_01eded80 = FUN_0087ef80;
      FUN_016f37bf(&DAT_01eded84);
    }
  }
  puVar1 = (undefined *)param_3[1];
  if (puVar1 == &DAT_01eded78) {
    FUN_0088de30(iVar3);
    return 1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_3 + 2);
    param_3[1] = 0;
  }
  FUN_0088dd80(iVar3);
  param_3[1] = &DAT_01eded78;
  return 1;
}



/* FUNCTION 18992 ; VA 0x009cdab0 ; FUN_009cdab0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_009cdab0(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined *puVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  
  iVar3 = FUN_01257810(param_1,param_2,DAT_01ede6b0);
  if (iVar3 == 0) {
    return 0;
  }
  uVar4 = FUN_00da48e0();
  iVar2 = _tls_index;
  *param_3 = uVar4;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01ee4410) {
    FUN_016f3809(&DAT_01ee4410);
    if (DAT_01ee4410 == -1) {
      _DAT_01ee4404 = FUN_009d02c0;
      _DAT_01ee4408 = FUN_009d02c0;
      DAT_01ee440c = FUN_0087f010;
      FUN_016f37bf(&DAT_01ee4410);
    }
  }
  puVar1 = (undefined *)param_3[1];
  if (puVar1 == &DAT_01ee4404) {
    FUN_009cfbe0(iVar3);
    return 1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_3 + 2);
    param_3[1] = 0;
  }
  FUN_009cf8d0(iVar3);
  param_3[1] = &DAT_01ee4404;
  return 1;
}



/* FUNCTION 18993 ; VA 0x009cdb90 ; FUN_009cdb90 */

undefined4 FUN_009cdb90(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_01257810(param_1,param_2,DAT_01ede698);
  if (iVar1 != 0) {
    uVar2 = FUN_00d89a00();
    *param_3 = uVar2;
    FUN_009cd3f0(iVar1);
    return 1;
  }
  return 0;
}



/* FUNCTION 18994 ; VA 0x009cdbd0 ; FUN_009cdbd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_009cdbd0(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  
  puVar6 = (undefined4 *)FUN_01257810(param_1,param_2,DAT_01ede720);
  if (puVar6 == (undefined4 *)0x0) {
    return 0;
  }
  uVar7 = FUN_00d99d10();
  iVar5 = _tls_index;
  *param_3 = uVar7;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar5 * 4) + 0x34) < DAT_01ee4430) {
    FUN_016f3809(&DAT_01ee4430);
    if (DAT_01ee4430 == -1) {
      _DAT_01ee4424 = FUN_009d03a0;
      _DAT_01ee4428 = FUN_009d03a0;
      _DAT_01ee442c = FUN_0057e0b0;
      FUN_016f37bf(&DAT_01ee4430);
    }
  }
  puVar2 = (undefined *)param_3[1];
  if (puVar2 == &DAT_01ee4424) {
    FUN_009cfd70(puVar6);
    return 1;
  }
  if (puVar2 != (undefined *)0x0) {
    (**(code **)(puVar2 + 8))(param_3 + 2);
    param_3[1] = 0;
  }
  uVar7 = puVar6[1];
  uVar3 = puVar6[2];
  uVar4 = puVar6[3];
  param_3[2] = *puVar6;
  param_3[3] = uVar7;
  param_3[4] = uVar3;
  param_3[5] = uVar4;
  *(undefined8 *)(param_3 + 6) = *(undefined8 *)(puVar6 + 4);
  param_3[8] = puVar6[6];
  param_3[9] = puVar6[7];
  param_3[10] = 0;
  param_3[0xb] = 0;
  if (puVar6[9] != 0) {
    LOCK();
    piVar1 = (int *)(puVar6[9] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_3[10] = puVar6[8];
  param_3[0xb] = puVar6[9];
  param_3[1] = &DAT_01ee4424;
  return 1;
}



/* FUNCTION 18995 ; VA 0x009cdcf0 ; FUN_009cdcf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_009cdcf0(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  
  puVar5 = (undefined4 *)FUN_01257810(param_1,param_2,DAT_01ede71c);
  if (puVar5 == (undefined4 *)0x0) {
    return 0;
  }
  uVar6 = FUN_00aa0140();
  iVar4 = _tls_index;
  *param_3 = uVar6;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar4 * 4) + 0x34) < DAT_01ead308) {
    FUN_016f3809(&DAT_01ead308);
    if (DAT_01ead308 == -1) {
      _DAT_01ead2fc = FUN_00619f80;
      _DAT_01ead300 = FUN_00619f80;
      _DAT_01ead304 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead308);
    }
  }
  puVar1 = (undefined *)param_3[1];
  if (puVar1 == &DAT_01ead2fc) {
    FUN_00aa1570(puVar5);
    return 1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_3 + 2);
    param_3[1] = 0;
  }
  uVar6 = puVar5[1];
  uVar2 = puVar5[2];
  uVar3 = puVar5[3];
  param_3[2] = *puVar5;
  param_3[3] = uVar6;
  param_3[4] = uVar2;
  param_3[5] = uVar3;
  *(undefined8 *)(param_3 + 6) = *(undefined8 *)(puVar5 + 4);
  param_3[1] = &DAT_01ead2fc;
  return 1;
}



/* FUNCTION 18996 ; VA 0x009cddd0 ; FUN_009cddd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_009cddd0(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined *puVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  
  puVar3 = (undefined4 *)FUN_01257810(param_1,param_2,DAT_01ede6f4);
  if (puVar3 == (undefined4 *)0x0) {
    return 0;
  }
  uVar4 = FUN_00da88a0();
  iVar2 = _tls_index;
  *param_3 = uVar4;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01ee4450) {
    FUN_016f3809(&DAT_01ee4450);
    if (DAT_01ee4450 == -1) {
      _DAT_01ee4444 = FUN_005c6620;
      _DAT_01ee4448 = FUN_005c6620;
      _DAT_01ee444c = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee4450);
    }
  }
  puVar1 = (undefined *)param_3[1];
  if (puVar1 == &DAT_01ee4444) {
    param_3[2] = *puVar3;
    uVar4 = puVar3[1];
    param_3[3] = uVar4;
    return CONCAT31((int3)((uint)uVar4 >> 8),1);
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_3 + 2);
    param_3[1] = 0;
  }
  param_3[2] = *puVar3;
  uVar4 = puVar3[1];
  param_3[3] = uVar4;
  param_3[1] = &DAT_01ee4444;
  return CONCAT31((int3)((uint)uVar4 >> 8),1);
}



/* FUNCTION 18997 ; VA 0x009cdeb0 ; FUN_009cdeb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_009cdeb0(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  
  piVar3 = (int *)FUN_01257810(param_1,param_2,DAT_01ede69c);
  if (piVar3 == (int *)0x0) {
    return 0;
  }
  uVar4 = FUN_0088d9b0();
  iVar2 = _tls_index;
  *param_3 = uVar4;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01ee4420) {
    FUN_016f3809(&DAT_01ee4420);
    if (DAT_01ee4420 == -1) {
      DAT_01ee4414 = FUN_009d0420;
      _DAT_01ee4418 = FUN_009d5630;
      DAT_01ee441c = FUN_0087f1c0;
      FUN_016f37bf(&DAT_01ee4420);
    }
  }
  puVar1 = (undefined4 *)param_3[1];
  if ((code **)puVar1 == &DAT_01ee4414) {
    FUN_016791c0(piVar3);
    return 1;
  }
  if (puVar1 != (undefined4 *)0x0) {
    (*(code *)puVar1[2])(param_3 + 2);
    param_3[1] = 0;
  }
  param_3[2] = 0;
  if (((int *)*piVar3 != (int *)0x0) && (*(int *)*piVar3 != 0)) {
    iVar2 = *piVar3;
    param_3[2] = iVar2;
    piVar3 = (int *)(iVar2 + 4);
    LOCK();
    *piVar3 = *piVar3 + 1;
    UNLOCK();
  }
  param_3[1] = &DAT_01ee4414;
  return 1;
}



/* FUNCTION 18998 ; VA 0x009cdfb0 ; FUN_009cdfb0 */

void __thiscall FUN_009cdfb0(undefined4 param_1,int *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x18,param_1);
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count_obj<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>
              ::vftable;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    *param_2 = (int)(puVar1 + 3);
    param_2[1] = (int)puVar1;
    return;
  }
  param_2[1] = 0;
  *param_2 = 0xc;
  return;
}



/* FUNCTION 18999 ; VA 0x009ce010 ; FUN_009ce010 */

int FUN_009ce010(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,
                undefined4 param_5,int *param_6)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d5c98;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0087ddc0(param_1,PTR_s_RBXScriptSignal_01d6d3e0,0x24,DAT_01ede6a8);
  iVar4 = FUN_0088dd80(&param_2);
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 2;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar4 = (**(code **)(*param_6 + 4))();
    }
  }
  piVar1 = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar2 = param_4 + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar4 = (**(code **)*param_4)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar4 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}


