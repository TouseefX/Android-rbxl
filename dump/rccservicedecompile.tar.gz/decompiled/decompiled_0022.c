/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 5500 ; VA 0x005d5bd0 ; FUN_005d5bd0 */

void FUN_005d5bd0(undefined4 *param_1,int *param_2)

{
  undefined4 uVar1;
  
  if ((param_1 != (undefined4 *)0x0) && (DAT_01ea8d1c != '\0')) {
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    FUN_016774b0(DAT_01ea8d1c,"RCCMonitoring HTTP response: %s",param_1);
  }
  if ((param_2 != (int *)0x0) && (DAT_01d596f0 != '\0')) {
    uVar1 = (**(code **)(*param_2 + 4))();
    FUN_016774b0(DAT_01d596f0,"RCCMonitoring HTTP ERROR - %s",uVar1);
  }
  return;
}



/* FUNCTION 5501 ; VA 0x005d5c30 ; FUN_005d5c30 */

uint __fastcall FUN_005d5c30(undefined4 *param_1)

{
  int *piVar1;
  uint *puVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined4 *puVar7;
  int *piVar8;
  int iStack_30;
  int *piStack_2c;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  int iStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a11d;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_30);
  uStack_8 = 0;
  if ((iStack_30 == 0) || (param_1[0x10] == 0)) {
    uVar6 = (uint)DAT_01d596f0;
    if (DAT_01d596f0 != 0) {
      uVar6 = FUN_016774b0(DAT_01d596f0,"ERROR - 1 more initialize dependencies is null.",0);
    }
  }
  else {
    if (DAT_01ea8d1c != 0) {
      FUN_016774b0(DAT_01ea8d1c,"gsmInterval - %d",*(undefined4 *)(param_1[0x10] + 0x78));
    }
    iVar4 = FUN_005cf750();
    iStack_20 = iVar4;
    FUN_0098cb50(*(undefined4 *)(param_1[0x10] + 0x7c));
    FUN_0098cb90(*(undefined4 *)(param_1[0x10] + 0x7c));
    piVar8 = (int *)param_1[1];
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar8[2] = piVar8[2] + 1;
      UNLOCK();
      piVar8 = (int *)param_1[1];
    }
    uStack_18 = *param_1;
    uStack_8._0_1_ = 1;
    if ((*(char *)(param_1 + 0x2a) == '\0') && (*(int *)(param_1[0x10] + 0x10) != 3)) {
      if (DAT_01ea8d1c != 0) {
        FUN_016774b0(DAT_01ea8d1c,"Standard game path - register \'playerAddedSignal\'.",0);
      }
      iStack_1c = iVar4 + 0x2a4;
      if (piVar8 != (int *)0x0) {
        LOCK();
        piVar8[2] = piVar8[2] + 1;
        UNLOCK();
      }
      uStack_8._0_1_ = 0xb;
      uVar5 = FUN_01675290(DAT_02110da8);
      uStack_8._0_1_ = 0xc;
      puStack_24 = (undefined4 *)uVar5;
      puStack_28 = (undefined4 *)FUN_01674e20(0x20);
      if (puStack_28 == (undefined4 *)0x0) {
        puVar7 = (undefined4 *)0x0;
      }
      else {
        *puStack_28 = 0;
        puStack_28[1] = 1;
        puStack_28[2] = FUN_005d3490;
        puStack_28[3] = FUN_005d3660;
        puStack_28[4] = 0;
        puStack_28[5] = iStack_1c;
        puStack_28[6] = 0;
        puStack_28[7] = 0;
        if (piVar8 != (int *)0x0) {
          LOCK();
          piVar8[2] = piVar8[2] + 1;
          UNLOCK();
        }
        puStack_28[6] = uStack_18;
        puStack_28[7] = piVar8;
        puVar7 = puStack_28;
      }
      FUN_016797d0(puVar7);
      if (puVar7 != (undefined4 *)0x0) {
        LOCK();
        puVar7[1] = puVar7[1] + 1;
        UNLOCK();
      }
      uStack_14 = 4;
      uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
      puStack_28 = puVar7;
      FUN_01675290(uVar5);
      uStack_14 = 0;
      if (puVar7 != (undefined4 *)0x0) {
        piVar1 = puVar7 + 1;
        LOCK();
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          FUN_01674ea0(puVar7);
        }
      }
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar4 = piVar8[2] + -1;
        piVar8[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
      iStack_1c = iStack_20 + 0x2b0;
      if (piVar8 != (int *)0x0) {
        LOCK();
        piVar8[2] = piVar8[2] + 1;
        UNLOCK();
      }
      uStack_8._0_1_ = 0xf;
      uVar5 = FUN_01675290(DAT_02110da8);
      uStack_8._0_1_ = 0x10;
      puStack_28 = (undefined4 *)uVar5;
      puStack_24 = (undefined4 *)FUN_01674e20(0x20);
      if (puStack_24 == (undefined4 *)0x0) {
        puVar7 = (undefined4 *)0x0;
      }
      else {
        *puStack_24 = 0;
        puStack_24[1] = 1;
        puStack_24[2] = FUN_005d33b0;
        puStack_24[3] = FUN_005d3660;
        puStack_24[4] = 0;
        puStack_24[5] = iStack_1c;
        puStack_24[6] = 0;
        puStack_24[7] = 0;
        if (piVar8 != (int *)0x0) {
          LOCK();
          piVar8[2] = piVar8[2] + 1;
          UNLOCK();
        }
        puStack_24[6] = uStack_18;
        puStack_24[7] = piVar8;
        puVar7 = puStack_24;
      }
      FUN_016797d0(puVar7);
      if (puVar7 != (undefined4 *)0x0) {
        LOCK();
        puVar7[1] = puVar7[1] + 1;
        UNLOCK();
      }
      uStack_14 = 8;
      uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
    }
    else {
      if (DAT_01ea8d1c != 0) {
        FUN_016774b0(DAT_01ea8d1c,"Cloud Edit path - register \'playerConnectingSignal\'.",0);
      }
      iStack_1c = iVar4 + 0x2c8;
      if (piVar8 != (int *)0x0) {
        LOCK();
        piVar8[2] = piVar8[2] + 1;
        UNLOCK();
      }
      uStack_8._0_1_ = 3;
      uVar5 = FUN_01675290(DAT_02110da8);
      uStack_8._0_1_ = 4;
      puStack_28 = (undefined4 *)uVar5;
      puStack_24 = (undefined4 *)FUN_01674e20(0x20);
      if (puStack_24 == (undefined4 *)0x0) {
        puVar7 = (undefined4 *)0x0;
      }
      else {
        *puStack_24 = 0;
        puStack_24[1] = 1;
        puStack_24[2] = FUN_005d3240;
        puStack_24[3] = FUN_005d3660;
        puStack_24[4] = 0;
        puStack_24[5] = iStack_1c;
        puStack_24[6] = 0;
        puStack_24[7] = 0;
        if (piVar8 != (int *)0x0) {
          LOCK();
          piVar8[2] = piVar8[2] + 1;
          UNLOCK();
        }
        puStack_24[6] = uStack_18;
        puStack_24[7] = piVar8;
        puVar7 = puStack_24;
      }
      FUN_016797d0(puVar7);
      if (puVar7 != (undefined4 *)0x0) {
        LOCK();
        puVar7[1] = puVar7[1] + 1;
        UNLOCK();
      }
      uStack_14 = 1;
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      puStack_24 = puVar7;
      FUN_01675290(uVar5);
      uStack_14 = 0;
      if (puVar7 != (undefined4 *)0x0) {
        piVar1 = puVar7 + 1;
        LOCK();
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          FUN_01674ea0(puVar7);
        }
      }
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar4 = piVar8[2] + -1;
        piVar8[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
      iStack_20 = iStack_20 + 0x2cc;
      if (piVar8 != (int *)0x0) {
        LOCK();
        piVar8[2] = piVar8[2] + 1;
        UNLOCK();
      }
      uStack_8._0_1_ = 7;
      uVar5 = FUN_01675290(DAT_02110da8);
      uStack_8._0_1_ = 8;
      puStack_28 = (undefined4 *)uVar5;
      puStack_24 = (undefined4 *)FUN_01674e20(0x20);
      if (puStack_24 == (undefined4 *)0x0) {
        puVar7 = (undefined4 *)0x0;
      }
      else {
        *puStack_24 = 0;
        puStack_24[1] = 1;
        puStack_24[2] = FUN_005d3560;
        puStack_24[3] = FUN_005d3660;
        puStack_24[4] = 0;
        puStack_24[5] = iStack_20;
        puStack_24[6] = 0;
        puStack_24[7] = 0;
        if (piVar8 != (int *)0x0) {
          LOCK();
          piVar8[2] = piVar8[2] + 1;
          UNLOCK();
        }
        puStack_24[6] = uStack_18;
        puStack_24[7] = piVar8;
        puVar7 = puStack_24;
      }
      FUN_016797d0(puVar7);
      if (puVar7 != (undefined4 *)0x0) {
        LOCK();
        puVar7[1] = puVar7[1] + 1;
        UNLOCK();
      }
      uStack_14 = 2;
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
    }
    puStack_24 = puVar7;
    FUN_01675290(uVar5);
    if (puVar7 != (undefined4 *)0x0) {
      piVar1 = puVar7 + 1;
      LOCK();
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        FUN_01674ea0(puVar7);
      }
    }
    if (piVar8 != (int *)0x0) {
      uStack_14 = 0;
      LOCK();
      iVar4 = piVar8[2] + -1;
      piVar8[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
    uStack_14 = 0;
    iStack_20 = iStack_30 + 0x74;
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar8[2] = piVar8[2] + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 0x13;
    uVar5 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 0x14;
    puStack_28 = (undefined4 *)uVar5;
    puStack_24 = (undefined4 *)FUN_01674e20(0x20);
    if (puStack_24 == (undefined4 *)0x0) {
      puVar7 = (undefined4 *)0x0;
    }
    else {
      *puStack_24 = 0;
      puStack_24[1] = 1;
      puStack_24[2] = FUN_005d3310;
      puStack_24[3] = FUN_005d3660;
      puStack_24[4] = 0;
      puStack_24[5] = iStack_20;
      puStack_24[6] = 0;
      puStack_24[7] = 0;
      if (piVar8 != (int *)0x0) {
        LOCK();
        piVar8[2] = piVar8[2] + 1;
        UNLOCK();
      }
      puStack_24[6] = uStack_18;
      puStack_24[7] = piVar8;
      puVar7 = puStack_24;
    }
    FUN_016797d0(puVar7);
    if (puVar7 != (undefined4 *)0x0) {
      LOCK();
      puVar7[1] = puVar7[1] + 1;
      UNLOCK();
    }
    uStack_14 = 0x10;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
    puStack_24 = puVar7;
    FUN_01675290(uVar5);
    if (puVar7 != (undefined4 *)0x0) {
      piVar1 = puVar7 + 1;
      LOCK();
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        FUN_01674ea0(puVar7);
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    puVar2 = (uint *)(piVar8 + 2);
    if (piVar8 != (int *)0x0) {
      LOCK();
      uVar6 = *puVar2;
      *puVar2 = uVar6 - 1;
      UNLOCK();
      if (uVar6 - 1 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
    uVar6 = (uint)DAT_01ea8d1c;
    if (DAT_01ea8d1c != 0) {
      uVar6 = FUN_016774b0(DAT_01ea8d1c,"RCCMonitoring initialized.",0);
    }
    if (piVar8 != (int *)0x0) {
      LOCK();
      uVar3 = *puVar2;
      uVar6 = *puVar2;
      *puVar2 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        uVar6 = (**(code **)(*piVar8 + 4))();
      }
    }
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    puVar2 = (uint *)(piStack_2c + 1);
    uVar3 = *puVar2;
    uVar6 = *puVar2;
    *puVar2 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar6 = (**(code **)*piStack_2c)();
      LOCK();
      piVar8 = piStack_2c + 2;
      iVar4 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uVar6 = (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 5502 ; VA 0x005d6280 ; FUN_005d6280 */

int * __thiscall FUN_005d6280(byte *param_1,int *param_2,int param_3)

{
  byte bVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  uint uStack_20;
  int iStack_1c;
  undefined2 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar2 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017997e8;
  pvStack_10 = ExceptionList;
  bVar1 = *param_1;
  ExceptionList = &pvStack_10;
  uStack_14 = FUN_005702d0(param_3);
  FUN_00562fc0(&param_3,uStack_14,iVar2,
               -(uint)(param_1 + bVar1 + 1 != (byte *)0x0) & (uint)(param_1 + bVar1 + 1 + 1));
  if (param_3 != 0) {
    *param_2 = param_3;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return param_2;
  }
  iStack_1c = 0;
  uStack_18 = 0;
  uStack_20 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  uStack_8 = 0;
  FUN_005d2a40();
  iVar3 = iStack_1c;
  FUN_0054ef60(iVar2);
  *(undefined4 *)(iVar3 + 0x20) = *(undefined4 *)(iVar2 + 0x18);
  uStack_18._1_1_ = '\x01';
  FUN_005d99d0(*(int *)(param_1 + 8) + 1);
  piVar4 = (int *)FUN_005c5550(&param_3,&uStack_20,uStack_14);
  iVar2 = iStack_1c;
  *param_2 = *piVar4;
  *(undefined *)(param_2 + 1) = 1;
  if (iStack_1c != 0) {
    if (uStack_18._1_1_ != '\0') {
      FUN_005cf430(uStack_20,iStack_1c + 8);
    }
    FUN_01674ea0(iVar2,0x24);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5503 ; VA 0x005d63a0 ; FUN_005d63a0 */

void FUN_005d63a0(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  (*(code *)*param_1)(param_2,param_3);
  return;
}



/* FUNCTION 5504 ; VA 0x005d63c0 ; FUN_005d63c0 */

void FUN_005d63c0(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (**(char **)(iVar1 + 0x28) == '\0') {
    FUN_005d2c20(iVar1,iVar1 + 8,iVar1 + 0x20,iVar1 + 0x28,*(int *)(iVar1 + 0x30) + 1,iVar1 + 0x34,
                 *(undefined4 *)(iVar1 + 0x4c));
  }
  return;
}



/* FUNCTION 5505 ; VA 0x005d6400 ; FUN_005d6400 */

void FUN_005d6400(int *param_1)

{
  char cVar1;
  undefined4 *puVar2;
  char *pcVar3;
  char *pcVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  puVar2 = (undefined4 *)*param_1;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  pcVar3 = (char *)puVar2[9];
  pcVar4 = pcVar3;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(pcVar3,(int)pcVar4 - (int)(pcVar3 + 1));
  uStack_8 = 0;
  (*(code *)*puVar2)(puVar2[2],puVar2 + 3,auStack_28);
  if (0xf < uStack_14) {
    uVar6 = uStack_14 + 1;
    uVar5 = auStack_28[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_28[0] - 4);
      uVar6 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5506 ; VA 0x005d64c0 ; FUN_005d64c0 */

void FUN_005d64c0(undefined4 param_1,undefined4 param_2)

{
  FUN_005d1bd0(param_2);
  return;
}



/* FUNCTION 5507 ; VA 0x005d64e0 ; FUN_005d64e0 */

void FUN_005d64e0(int *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)*param_1;
  (*(code *)*puVar1)(puVar1 + 1,puVar1 + 3,puVar1 + 9,puVar1 + 0xb,puVar1[0xd],puVar1 + 0xe,
                     puVar1[0x14],param_2,param_3);
  return;
}



/* FUNCTION 5508 ; VA 0x005d6520 ; FUN_005d6520 */

void FUN_005d6520(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      *param_2 = *param_1;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d944bc);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&TypeDescriptor_01d944b8;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 5509 ; VA 0x005d65a0 ; FUN_005d65a0 */

void FUN_005d65a0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a13f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x50);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_005cfb40(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_005d0f60();
        FUN_01674ea0(iVar2,0x50);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1d947a8);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_4efc060724f76f70667827b207b7838f>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 5510 ; VA 0x005d66f0 ; FUN_005d66f0 */

void FUN_005d66f0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a13f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x50);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_005cfb40(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_005d0f60();
        FUN_01674ea0(iVar2,0x50);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1d94770);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_526c3ab98cf51a4319424af724c31eaf>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 5511 ; VA 0x005d6840 ; FUN_005d6840 */

void FUN_005d6840(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a15f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x54);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        FUN_005cfc20(puVar1 + 1);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_005d1060();
        FUN_01674ea0(iVar3,0x54);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1d9451c);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::DataModel>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_const&,class_std::shared_ptr<bool>_const&,int,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,int,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>*,class_std::exception*),class_boost::_bi::list9<class_boost::_bi::value<class_std::weak_ptr<class_RBX::DataModel>_>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>,class_boost::_bi::value<class_std::shared_ptr<bool>_>,class_boost::_bi::value<int>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<int>,struct_boost::arg<1>,struct_boost::arg<2>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 5512 ; VA 0x005d6990 ; FUN_005d6990 */

void FUN_005d6990(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d94434);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf0<void,class_RBX::RCCMonitoring>,class_boost::_bi::list1<class_boost::_bi::value<class_RBX::RCCMonitoring*>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 5513 ; VA 0x005d6a00 ; FUN_005d6a00 */

void FUN_005d6a00(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a17f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar4 = (undefined4 *)FUN_01674e20(0x28);
      uStack_8 = 0;
      if (puVar4 == (undefined4 *)0x0) {
        *param_2 = 0;
        ExceptionList = pvStack_10;
        return;
      }
      *puVar4 = *puVar1;
      puVar4[1] = puVar1[1];
      puVar4[2] = puVar1[2];
      FUN_0054ef60(puVar1 + 3);
      puVar4[9] = puVar1[9];
      *param_2 = (int)puVar4;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar6 = *param_2;
      if (iVar6 != 0) {
        uVar2 = *(uint *)(iVar6 + 0x20);
        ExceptionList = &pvStack_10;
        if (0xf < uVar2) {
          iVar3 = *(int *)(iVar6 + 0xc);
          uVar7 = uVar2 + 1;
          iVar5 = iVar3;
          if (0xfff < uVar7) {
            iVar5 = *(int *)(iVar3 + -4);
            uVar7 = uVar2 + 0x24;
            if (0x1f < (iVar3 - iVar5) - 4U) {
              ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          ExceptionList = &pvStack_10;
          FUN_01674ea0(iVar5,uVar7);
        }
        *(undefined4 *)(iVar6 + 0x1c) = 0;
        *(undefined4 *)(iVar6 + 0x20) = 0xf;
        *(undefined *)(iVar6 + 0xc) = 0;
        FUN_01674ea0(iVar6,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar6 = FUN_0170d8dd(*param_2 + 4,0x1d942fc);
      if (iVar6 != 0) {
        *param_2 = 0;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = *param_1;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf3<void,class_RBX::RCCMonitoring,int,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&>,class_boost::_bi::list4<class_boost::_bi::value<class_RBX::RCCMonitoring*>,class_boost::_bi::value<int>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<char_const*>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 5514 ; VA 0x005d6bb0 ; FUN_005d6bb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_005d6bb0(int param_1,int param_2)

{
  float10 fVar1;
  
  fVar1 = (float10)FUN_01725280(((double)param_2 + (double)(&DAT_018c0d90)[-(param_2 >> 0x1f)]) /
                                (double)*(float *)(param_1 + 0xc));
  if (_DAT_018c4e98 <= (double)fVar1 + DAT_018c0d60) {
    FUN_00588320();
    return;
  }
  FUN_016f3eb1();
  FUN_00588320();
  return;
}



/* FUNCTION 5515 ; VA 0x005d6c30 ; FUN_005d6c30 */

int __fastcall FUN_005d6c30(int param_1)

{
  int *piVar1;
  
  piVar1 = *(int **)(param_1 + 0x2c);
  if (piVar1 != (int *)0x0) {
    return piVar1[1] - *piVar1 >> 3;
  }
  return 0;
}



/* FUNCTION 5516 ; VA 0x005d6c50 ; FUN_005d6c50 */

/* WARNING: Type propagation algorithm not settling */

void __fastcall FUN_005d6c50(int param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int *piVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  undefined auStack_248 [220];
  int aiStack_16c [25];
  undefined **appuStack_108 [18];
  int aiStack_c0 [5];
  uint uStack_ac;
  uint auStack_a8 [4];
  undefined4 uStack_98;
  uint uStack_94;
  uint auStack_90 [4];
  undefined4 uStack_80;
  uint uStack_7c;
  uint auStack_78 [4];
  undefined4 uStack_68;
  uint uStack_64;
  uint auStack_60 [4];
  undefined4 uStack_50;
  uint uStack_4c;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a20b;
  pvStack_10 = ExceptionList;
  uStack_30 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01ea8d1c != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ea8d1c,"- onGameShutdown -",0);
  }
  puVar1 = *(undefined4 **)(param_1 + 0x40);
  uStack_2c = *puVar1;
  piVar6 = puVar1 + 0x12;
  if (0xf < (uint)puVar1[0x17]) {
    piVar6 = (int *)*piVar6;
  }
  puVar4 = puVar1 + 0x20;
  if (0xf < (uint)puVar1[0x25]) {
    puVar4 = (undefined4 *)*puVar4;
  }
  FUN_01675640(aiStack_c0,"apiKey=%s&gameId=%s&placeId=%lld&universeId=%lld",puVar4,piVar6,uStack_2c
               ,puVar1[1],puVar1[2],puVar1[3]);
  uStack_8 = 0;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 1;
  uStack_50 = 0;
  uStack_4c = 0xf;
  auStack_60[0] = auStack_60[0] & 0xffffff00;
  FUN_005542c0("/v1/Close/",10);
  uStack_8._0_1_ = 2;
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  FUN_005542c0("https",5);
  uStack_8._0_1_ = 3;
  FUN_0151bcc0(auStack_248,auStack_48,param_1 + 0x60,auStack_60,aiStack_c0,auStack_28);
  uStack_8._0_1_ = 5;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 5;
  if (0xf < uStack_34) {
    uVar8 = uStack_34 + 1;
    uVar9 = auStack_48[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_48[0] - 4);
      uVar8 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar9) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  uStack_8._0_1_ = 6;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 6;
  if (0xf < uStack_4c) {
    uVar8 = uStack_4c + 1;
    uVar9 = auStack_60[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_60[0] - 4);
      uVar8 = uStack_4c + 0x24;
      if (0x1f < (auStack_60[0] - uVar9) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  uStack_50 = 0;
  uStack_4c = 0xf;
  auStack_60[0] = auStack_60[0] & 0xffffff00;
  uStack_8._0_1_ = 7;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 7;
  if (0xf < uStack_14) {
    uVar8 = uStack_14 + 1;
    uVar9 = auStack_28[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_28[0] - 4);
      uVar8 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar9) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  uStack_18 = 0;
  uVar2 = *(undefined4 *)(*(int *)(param_1 + 0x40) + 0x9c);
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  uStack_80 = 0;
  uStack_7c = 0xf;
  auStack_90[0] = auStack_90[0] & 0xffffff00;
  FUN_005542c0("GameInstancesClose",0x12);
  uStack_8._0_1_ = 8;
  uVar5 = FUN_0151bb70(auStack_a8);
  uStack_8._0_1_ = 10;
  FUN_005dabb0(auStack_90,uVar2);
  FUN_014cc090(uVar5,0,0);
  uStack_8._0_1_ = 0xb;
  uStack_68 = 0;
  uStack_64 = 0xf;
  auStack_78[0] = auStack_78[0] & 0xffffff00;
  uStack_30 = 1;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 0xc;
  FUN_00565000(auStack_28,1,1);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  if (0xf < uStack_14) {
    uVar8 = uStack_14 + 1;
    uVar9 = auStack_28[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_28[0] - 4);
      uVar8 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  if (DAT_01d5a4c0 == '\0') {
    FUN_014cdc70(aiStack_16c + 1,&DAT_01d79f68,0,auStack_78,0,0);
  }
  *(undefined ***)((int)aiStack_16c + *(int *)(aiStack_16c[1] + 4) + 4U) =
       std::basic_istringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(int *)((int)aiStack_16c + *(int *)(aiStack_16c[1] + 4)) = *(int *)(aiStack_16c[1] + 4) + -0x60;
  FUN_0056b950();
  *(undefined ***)((int)aiStack_16c + *(int *)(aiStack_16c[1] + 4) + 4U) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)((int)aiStack_16c + *(int *)(aiStack_16c[1] + 4)) = *(int *)(aiStack_16c[1] + 4) + -0x18;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  appuStack_108[0] = std::ios_base::vftable;
  FUN_016de551(appuStack_108);
  FUN_0056db40();
  if (0xf < uStack_64) {
    uVar8 = uStack_64 + 1;
    uVar9 = auStack_78[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_78[0] - 4);
      uVar8 = uStack_64 + 0x24;
      if (0x1f < (auStack_78[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  uStack_68 = 0;
  uStack_64 = 0xf;
  auStack_78[0] = auStack_78[0] & 0xffffff00;
  if (0xf < uStack_94) {
    uVar8 = uStack_94 + 1;
    uVar9 = auStack_a8[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_a8[0] - 4);
      uVar8 = uStack_94 + 0x24;
      if (0x1f < (auStack_a8[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  uStack_98 = 0;
  uStack_94 = 0xf;
  auStack_a8[0] = auStack_a8[0] & 0xffffff00;
  if (0xf < uStack_7c) {
    uVar8 = uStack_7c + 1;
    uVar9 = auStack_90[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_90[0] - 4);
      uVar8 = uStack_7c + 0x24;
      if (0x1f < (auStack_90[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  FUN_0056d9d0();
  if (0xf < uStack_ac) {
    uVar9 = uStack_ac + 1;
    iVar7 = aiStack_c0[0];
    if (0xfff < uVar9) {
      iVar7 = *(int *)(aiStack_c0[0] + -4);
      uVar9 = uStack_ac + 0x24;
      if (0x1f < (aiStack_c0[0] - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar9);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5517 ; VA 0x005d7140 ; FUN_005d7140 */

uint __thiscall FUN_005d7140(int param_1,undefined4 param_2)

{
  uint *puVar1;
  int *piVar2;
  undefined uVar3;
  undefined *puVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  float10 fVar8;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  double dStack_30;
  double dStack_28;
  int iStack_20;
  int *piStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a238;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffac;
  ExceptionList = &pvStack_10;
  puVar4 = &stack0xffffffac;
  if (DAT_01ea8d1c != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ea8d1c,"- onPlayerConnectingReportClientPresence2 -",0);
    puVar4 = puStack_14;
  }
  puStack_14 = puVar4;
  uStack_8 = 0;
  FUN_00562c90(&iStack_20,param_2);
  uStack_8._0_1_ = 1;
  if (iStack_20 == 0) {
    uVar5 = (uint)DAT_01d596f0;
    if (DAT_01d596f0 != 0) {
      uVar5 = FUN_016774b0(DAT_01d596f0,
                           "ERROR - Empty player in onPlayerConnectingReportClientPresence2, returning..."
                           ,0);
    }
  }
  else {
    fVar8 = (float10)FUN_01160660();
    dStack_28 = (double)fVar8;
    dStack_30 = dStack_28 - *(double *)(param_1 + 0x20);
    dStack_28 = (double)FUN_00928340();
    iVar6 = FUN_005d1850(&dStack_28);
    *(double *)(iVar6 + 8) = dStack_30;
    uStack_38 = 0;
    uStack_34 = 0xf;
    auStack_48[0] = auStack_48[0] & 0xffffff00;
    FUN_005542c0("PlayerAdded",0xb);
    uStack_8._0_1_ = 2;
    FUN_005da4c0(auStack_48,&iStack_20);
    uStack_8._0_1_ = 1;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (0xf < uStack_34) {
      uVar7 = uStack_34 + 1;
      uVar5 = auStack_48[0];
      if (0xfff < uVar7) {
        uVar5 = *(uint *)(auStack_48[0] - 4);
        uVar7 = uStack_34 + 0x24;
        if (0x1f < (auStack_48[0] - uVar5) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar7);
    }
    uStack_38 = 0;
    uStack_34 = 0xf;
    auStack_48[0] = auStack_48[0] & 0xffffff00;
    FUN_005542c0("PlayerAdded",0xb);
    uStack_8._0_1_ = 3;
    FUN_005da090(auStack_48,&iStack_20);
    uStack_8._0_1_ = 1;
    if (0xf < uStack_34) {
      uVar7 = uStack_34 + 1;
      uVar5 = auStack_48[0];
      if (0xfff < uVar7) {
        uVar5 = *(uint *)(auStack_48[0] - 4);
        uVar7 = uStack_34 + 0x24;
        if (0x1f < (auStack_48[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar7);
    }
    uVar5 = FUN_005dad40(&iStack_20,0);
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_1c + 1);
    uVar7 = *puVar1;
    uVar5 = *puVar1;
    *puVar1 = uVar7 - 1;
    UNLOCK();
    if (uVar7 - 1 == 0) {
      uVar5 = (**(code **)*piStack_1c)();
      LOCK();
      piVar2 = piStack_1c + 2;
      iVar6 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        uVar5 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 5518 ; VA 0x005d7317 ; Catch@005d7317 */

undefined4 Catch_005d7317(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  if (DAT_01d596f0 != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x14) + 4))();
    FUN_016774b0(DAT_01d596f0,"ERROR - Exception in onPlayerConnectingReportClientPresence2: %s",
                 uVar1);
  }
  return 0x5d71e3;
}



/* FUNCTION 5519 ; VA 0x005d7350 ; FUN_005d7350 */

uint __thiscall FUN_005d7350(int param_1,undefined4 param_2)

{
  uint *puVar1;
  int *piVar2;
  int iVar3;
  undefined uVar4;
  undefined *puVar5;
  uint uVar6;
  undefined4 uVar7;
  uint uVar8;
  undefined8 uVar9;
  undefined auStack_13c [120];
  undefined auStack_c4 [4];
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined uStack_a4;
  undefined auStack_a0 [4];
  int *piStack_9c;
  uint auStack_94 [4];
  undefined4 uStack_84;
  uint uStack_80;
  uint auStack_7c [4];
  undefined4 uStack_6c;
  uint uStack_68;
  uint auStack_64 [4];
  undefined4 uStack_54;
  uint uStack_50;
  uint auStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  int iStack_34;
  int *piStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a2a1;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffeb8;
  ExceptionList = &pvStack_10;
  puVar5 = &stack0xfffffeb8;
  if (DAT_01ea8d1c != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ea8d1c,"- onPlayerConnectingReportClientPresence -",0);
    puVar5 = puStack_14;
  }
  puStack_14 = puVar5;
  uStack_8 = 0;
  FUN_00562c90(&iStack_34,param_2);
  uStack_8._0_1_ = 1;
  if (iStack_34 == 0) {
    uVar6 = (uint)DAT_01d596f0;
    if (DAT_01d596f0 != 0) {
      uVar6 = FUN_016774b0(DAT_01d596f0,
                           "ERROR - Empty player in onPlayerConnectingReportClientPresence, returning..."
                           ,0);
    }
  }
  else {
    uVar9 = FUN_00928340();
    FUN_01675640(auStack_94,"action=connect&PlaceID=%lld&UserID=%lld",
                 **(undefined4 **)(param_1 + 0x40),(*(undefined4 **)(param_1 + 0x40))[1],uVar9);
    uStack_8._0_1_ = 2;
    uStack_6c = 0;
    uStack_68 = 0xf;
    auStack_7c[0] = auStack_7c[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 3;
    uStack_54 = 0;
    uStack_50 = 0xf;
    auStack_64[0] = auStack_64[0] & 0xffffff00;
    FUN_005542c0("/Game/ClientPresence.ashx",0x19);
    uStack_8._0_1_ = 4;
    uStack_3c = 0;
    uStack_38 = 0xf;
    auStack_4c[0] = auStack_4c[0] & 0xffffff00;
    FUN_005542c0("https",5);
    uStack_8._0_1_ = 5;
    FUN_0151bcc0(auStack_13c,auStack_4c,param_1 + 0x78,auStack_64,auStack_94,auStack_7c);
    uStack_8._0_1_ = 7;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 7;
    if (0xf < uStack_38) {
      uVar8 = uStack_38 + 1;
      uVar6 = auStack_4c[0];
      if (0xfff < uVar8) {
        uVar6 = *(uint *)(auStack_4c[0] - 4);
        uVar8 = uStack_38 + 0x24;
        if (0x1f < (auStack_4c[0] - uVar6) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar8);
    }
    uStack_3c = 0;
    uStack_38 = 0xf;
    auStack_4c[0] = auStack_4c[0] & 0xffffff00;
    uStack_8._0_1_ = 8;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (0xf < uStack_50) {
      uVar8 = uStack_50 + 1;
      uVar6 = auStack_64[0];
      if (0xfff < uVar8) {
        uVar6 = *(uint *)(auStack_64[0] - 4);
        uVar8 = uStack_50 + 0x24;
        if (0x1f < (auStack_64[0] - uVar6) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar8);
    }
    uStack_54 = 0;
    uStack_50 = 0xf;
    auStack_64[0] = auStack_64[0] & 0xffffff00;
    uStack_8._0_1_ = 9;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 9;
    if (0xf < uStack_68) {
      uVar8 = uStack_68 + 1;
      uVar6 = auStack_7c[0];
      if (0xfff < uVar8) {
        uVar6 = *(uint *)(auStack_7c[0] - 4);
        uVar8 = uStack_68 + 0x24;
        if (0x1f < (auStack_7c[0] - uVar6) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar8);
    }
    uStack_6c = 0;
    uStack_68 = 0xf;
    auStack_7c[0] = auStack_7c[0] & 0xffffff00;
    auStack_c4[0] = 0;
    uStack_c0 = FUN_00588320(0xb);
    uStack_bc = 0;
    uStack_b8 = 0x3f800000;
    uStack_b4 = 0;
    uStack_b0 = 0;
    uStack_ac = 0;
    uStack_a8 = 0;
    uStack_a4 = 0;
    uStack_8._0_1_ = 10;
    uVar7 = FUN_0151bb70(auStack_2c);
    uStack_8._0_1_ = 0xb;
    FUN_014da330(auStack_a0,uVar7,auStack_c4);
    uStack_8._0_1_ = 0xc;
    if (piStack_9c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_9c[1] + -1;
      piStack_9c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_9c + 4))();
        LOCK();
        iVar3 = piStack_9c[2] + -1;
        piStack_9c[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_9c + 8))();
        }
      }
    }
    uStack_8._0_1_ = 10;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 10;
    if (0xf < uStack_18) {
      uVar8 = uStack_18 + 1;
      uVar6 = auStack_2c[0];
      if (0xfff < uVar8) {
        uVar6 = *(uint *)(auStack_2c[0] - 4);
        uVar8 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar6) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar8);
    }
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    uStack_8._0_1_ = 9;
    FUN_0056cfd0();
    uVar7 = *(undefined4 *)(*(int *)(param_1 + 0x40) + 0x9c);
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("AssetGameClientPresence",0x17);
    uStack_8._0_1_ = 0xd;
    FUN_005dabb0(auStack_2c,uVar7);
    if (0xf < uStack_18) {
      uVar8 = uStack_18 + 1;
      uVar6 = auStack_2c[0];
      if (0xfff < uVar8) {
        uVar6 = *(uint *)(auStack_2c[0] - 4);
        uVar8 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar8);
    }
    uVar6 = FUN_0056d9d0();
    if (0xf < uStack_80) {
      uVar8 = uStack_80 + 1;
      uVar6 = auStack_94[0];
      if (0xfff < uVar8) {
        uVar6 = *(uint *)(auStack_94[0] - 4);
        uVar8 = uStack_80 + 0x24;
        if (0x1f < (auStack_94[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uVar6 = FUN_01674ea0(uVar6,uVar8);
    }
    uStack_84 = 0;
    uStack_80 = 0xf;
    auStack_94[0] = auStack_94[0] & 0xffffff00;
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_30 + 1);
    uVar8 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar8 - 1;
    UNLOCK();
    if (uVar8 - 1 == 0) {
      uVar6 = (**(code **)*piStack_30)();
      LOCK();
      piVar2 = piStack_30 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        uVar6 = (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 5520 ; VA 0x005d7769 ; Catch@005d7769 */

undefined4 Catch_005d7769(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  if (DAT_01d596f0 != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x94) + 4))();
    FUN_016774b0(DAT_01d596f0,"ERROR - Exception in onPlayerConnectingReportClientPresence: %s",
                 uVar1);
  }
  return 0x5d73f6;
}



/* FUNCTION 5521 ; VA 0x005d77c0 ; FUN_005d77c0 */

uint __thiscall FUN_005d77c0(int param_1,undefined4 param_2)

{
  uint *puVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  undefined uVar5;
  undefined *puVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  int *piVar10;
  longlong lVar11;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  int iStack_38;
  int *piStack_34;
  int iStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a2c8;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffa4;
  ExceptionList = &pvStack_10;
  puVar6 = &stack0xffffffa4;
  if (DAT_01ea8d1c != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ea8d1c,"- onPlayerDisconnectingReportClientPresence2 -",0);
    puVar6 = puStack_14;
  }
  puStack_14 = puVar6;
  uStack_8 = 0;
  FUN_00562c90(&iStack_38,param_2);
  uStack_8._0_1_ = 1;
  if (iStack_38 == 0) {
    uVar7 = (uint)DAT_01d596f0;
    if (DAT_01d596f0 != 0) {
      uVar7 = FUN_016774b0(DAT_01d596f0,
                           "ERROR - Empty player in onPlayerDisconnectingReportClientPresence2, returning..."
                           ,0);
    }
    piVar4 = piStack_34;
    lVar11 = CONCAT44(uStack_28,uStack_24);
  }
  else {
    uStack_40 = 0;
    uStack_3c = 0xf;
    auStack_50[0] = auStack_50[0] & 0xffffff00;
    FUN_005542c0("PlayerRemoving",0xe);
    uStack_8._0_1_ = 2;
    FUN_005da4c0(auStack_50,&iStack_38);
    uStack_8._0_1_ = 1;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (0xf < uStack_3c) {
      uVar8 = uStack_3c + 1;
      uVar7 = auStack_50[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_50[0] - 4);
        uVar8 = uStack_3c + 0x24;
        if (0x1f < (auStack_50[0] - uVar7) - 4) {
          uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_40 = 0;
    uStack_3c = 0xf;
    auStack_50[0] = auStack_50[0] & 0xffffff00;
    FUN_005542c0("PlayerRemoving",0xe);
    uStack_8._0_1_ = 3;
    FUN_005da090(auStack_50,&iStack_38);
    uStack_8._0_1_ = 1;
    if (0xf < uStack_3c) {
      uVar8 = uStack_3c + 1;
      uVar7 = auStack_50[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_50[0] - 4);
        uVar8 = uStack_3c + 0x24;
        if (0x1f < (auStack_50[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    FUN_005dad40(&iStack_38,1);
    FUN_005d8cf0(&iStack_38);
    iStack_2c = param_1 + 0x28;
    lVar11 = FUN_00928340();
    iVar2 = iStack_2c;
    uStack_28 = (uint)((ulonglong)lVar11 >> 0x20);
    uStack_24 = (uint)lVar11;
    uVar7 = uStack_24;
    piVar4 = piStack_34;
    if (*(int *)(param_1 + 0x30) != 0) {
      uStack_1c = uStack_28;
      if ((lVar11 < 0x100000000) && (lVar11 < 0)) {
        uStack_1c = -uStack_28 - 1;
      }
      uStack_18 = *(uint *)(param_1 + 0x2c);
      uStack_1c = (uStack_1c >> 2) + uStack_1c * 0x40 + uStack_24 ^ uStack_1c;
      uVar8 = uStack_1c % uStack_18;
      uVar7 = *(uint *)(param_1 + 0x3c);
      piVar3 = *(int **)(uVar7 + uVar8 * 4);
      if (piVar3 != (int *)0x0) {
        do {
          piVar10 = piVar3;
          piVar3 = (int *)*piVar10;
          if (piVar3 == (int *)0x0) goto joined_r0x005d7a40;
          uVar9 = piVar3[1];
          uVar7 = uVar9 / uStack_18;
          if (uVar9 % uStack_18 != uVar8) goto joined_r0x005d7a40;
        } while (((uVar9 != uStack_1c) || (uVar7 = uStack_24, uStack_24 != piVar3[2])) ||
                (uVar7 = uStack_28, uStack_28 != piVar3[3]));
        FUN_0057d5a0(piVar10,*piVar3);
        piVar4 = piStack_34;
        if (*piVar10 != 0) {
          uVar7 = *(uint *)(*piVar10 + 4);
          uVar9 = uVar7 % *(uint *)(iVar2 + 4);
          uVar7 = uVar7 / *(uint *)(iVar2 + 4);
          lVar11 = CONCAT44(uStack_28,uStack_24);
          if (uVar8 == uVar9) goto joined_r0x005d7a40;
          *(int **)(*(int *)(iVar2 + 0x14) + uVar9 * 4) = piVar10;
        }
        uVar7 = *(uint *)(iVar2 + 0x14);
        lVar11 = CONCAT44(uStack_28,uStack_24);
        if (*(int **)(uVar7 + uVar8 * 4) == piVar10) {
          *(undefined4 *)(uVar7 + uVar8 * 4) = 0;
          lVar11 = CONCAT44(uStack_28,uStack_24);
        }
      }
    }
  }
joined_r0x005d7a40:
  if (piVar4 != (int *)0x0) {
    uStack_28 = (uint)((ulonglong)lVar11 >> 0x20);
    uStack_24 = (uint)lVar11;
    LOCK();
    puVar1 = (uint *)(piVar4 + 1);
    uVar8 = *puVar1;
    uVar7 = *puVar1;
    *puVar1 = uVar8 - 1;
    UNLOCK();
    if (uVar8 - 1 == 0) {
      uVar7 = (**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uVar7 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 5522 ; VA 0x005d7a4b ; Catch@005d7a4b */

undefined4 Catch_005d7a4b(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  if (DAT_01d596f0 != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x2c) + 4))();
    FUN_016774b0(DAT_01d596f0,"ERROR - Exception in onPlayerDisconnectingReportClientPresence2: %s",
                 uVar1);
  }
  return 0x5d7863;
}



/* FUNCTION 5523 ; VA 0x005d7a90 ; FUN_005d7a90 */

uint __thiscall FUN_005d7a90(int param_1,undefined4 param_2)

{
  uint *puVar1;
  int *piVar2;
  int iVar3;
  undefined uVar4;
  undefined *puVar5;
  uint uVar6;
  undefined4 uVar7;
  uint uVar8;
  char *pcVar9;
  undefined8 uVar10;
  undefined auStack_13c [120];
  undefined auStack_c4 [4];
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined uStack_a4;
  undefined auStack_a0 [4];
  int *piStack_9c;
  uint auStack_94 [4];
  undefined4 uStack_84;
  uint uStack_80;
  uint auStack_7c [4];
  undefined4 uStack_6c;
  uint uStack_68;
  uint auStack_64 [4];
  undefined4 uStack_54;
  uint uStack_50;
  uint auStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  int iStack_34;
  int *piStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a331;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffeb8;
  ExceptionList = &pvStack_10;
  puVar5 = &stack0xfffffeb8;
  if (DAT_01ea8d1c != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ea8d1c,"- onPlayerDisconnectingReportClientPresence -",0);
    puVar5 = puStack_14;
  }
  puStack_14 = puVar5;
  uStack_8 = 0;
  FUN_00562c90(&iStack_34,param_2);
  uStack_8._0_1_ = 1;
  if (iStack_34 == 0) {
    uVar6 = (uint)DAT_01d596f0;
    if (DAT_01d596f0 != 0) {
      uVar6 = FUN_016774b0(DAT_01d596f0,
                           "ERROR - Empty player in onPlayerDisconnectingReportClientPresence, returning..."
                           ,0);
    }
  }
  else {
    pcVar9 = "True";
    if (*(char *)(iStack_34 + 0x264) == '\0') {
      pcVar9 = "False";
    }
    uVar10 = FUN_00928340();
    FUN_01675640(auStack_94,"action=disconnect&PlaceID=%lld&UserID=%lld&IsTeleport=%s",
                 **(undefined4 **)(param_1 + 0x40),(*(undefined4 **)(param_1 + 0x40))[1],uVar10,
                 pcVar9);
    uStack_8._0_1_ = 2;
    uStack_6c = 0;
    uStack_68 = 0xf;
    auStack_7c[0] = auStack_7c[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 3;
    uStack_54 = 0;
    uStack_50 = 0xf;
    auStack_64[0] = auStack_64[0] & 0xffffff00;
    FUN_005542c0("/Game/ClientPresence.ashx",0x19);
    uStack_8._0_1_ = 4;
    uStack_3c = 0;
    uStack_38 = 0xf;
    auStack_4c[0] = auStack_4c[0] & 0xffffff00;
    FUN_005542c0("https",5);
    uStack_8._0_1_ = 5;
    FUN_0151bcc0(auStack_13c,auStack_4c,param_1 + 0x78,auStack_64,auStack_94,auStack_7c);
    uStack_8._0_1_ = 7;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 7;
    if (0xf < uStack_38) {
      uVar8 = uStack_38 + 1;
      uVar6 = auStack_4c[0];
      if (0xfff < uVar8) {
        uVar6 = *(uint *)(auStack_4c[0] - 4);
        uVar8 = uStack_38 + 0x24;
        if (0x1f < (auStack_4c[0] - uVar6) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar8);
    }
    uStack_3c = 0;
    uStack_38 = 0xf;
    auStack_4c[0] = auStack_4c[0] & 0xffffff00;
    uStack_8._0_1_ = 8;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (0xf < uStack_50) {
      uVar8 = uStack_50 + 1;
      uVar6 = auStack_64[0];
      if (0xfff < uVar8) {
        uVar6 = *(uint *)(auStack_64[0] - 4);
        uVar8 = uStack_50 + 0x24;
        if (0x1f < (auStack_64[0] - uVar6) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar8);
    }
    uStack_54 = 0;
    uStack_50 = 0xf;
    auStack_64[0] = auStack_64[0] & 0xffffff00;
    uStack_8._0_1_ = 9;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 9;
    if (0xf < uStack_68) {
      uVar8 = uStack_68 + 1;
      uVar6 = auStack_7c[0];
      if (0xfff < uVar8) {
        uVar6 = *(uint *)(auStack_7c[0] - 4);
        uVar8 = uStack_68 + 0x24;
        if (0x1f < (auStack_7c[0] - uVar6) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar8);
    }
    uStack_6c = 0;
    uStack_68 = 0xf;
    auStack_7c[0] = auStack_7c[0] & 0xffffff00;
    auStack_c4[0] = 0;
    uStack_c0 = FUN_00588320(0xb);
    uStack_bc = 0;
    uStack_b8 = 0x3f800000;
    uStack_b4 = 0;
    uStack_b0 = 0;
    uStack_ac = 0;
    uStack_a8 = 0;
    uStack_a4 = 0;
    uStack_8._0_1_ = 10;
    uVar7 = FUN_0151bb70(auStack_2c);
    uStack_8._0_1_ = 0xb;
    FUN_014da330(auStack_a0,uVar7,auStack_c4);
    uStack_8._0_1_ = 0xc;
    if (piStack_9c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_9c[1] + -1;
      piStack_9c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_9c + 4))();
        LOCK();
        iVar3 = piStack_9c[2] + -1;
        piStack_9c[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_9c + 8))();
        }
      }
    }
    uStack_8._0_1_ = 10;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 10;
    if (0xf < uStack_18) {
      uVar8 = uStack_18 + 1;
      uVar6 = auStack_2c[0];
      if (0xfff < uVar8) {
        uVar6 = *(uint *)(auStack_2c[0] - 4);
        uVar8 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar6) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar8);
    }
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    uStack_8._0_1_ = 9;
    FUN_0056cfd0();
    uVar7 = *(undefined4 *)(*(int *)(param_1 + 0x40) + 0x9c);
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("AssetGameClientPresence",0x17);
    uStack_8._0_1_ = 0xd;
    FUN_005dabb0(auStack_2c,uVar7);
    if (0xf < uStack_18) {
      uVar8 = uStack_18 + 1;
      uVar6 = auStack_2c[0];
      if (0xfff < uVar8) {
        uVar6 = *(uint *)(auStack_2c[0] - 4);
        uVar8 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar8);
    }
    uVar6 = FUN_0056d9d0();
    if (0xf < uStack_80) {
      uVar8 = uStack_80 + 1;
      uVar6 = auStack_94[0];
      if (0xfff < uVar8) {
        uVar6 = *(uint *)(auStack_94[0] - 4);
        uVar8 = uStack_80 + 0x24;
        if (0x1f < (auStack_94[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uVar6 = FUN_01674ea0(uVar6,uVar8);
    }
    uStack_84 = 0;
    uStack_80 = 0xf;
    auStack_94[0] = auStack_94[0] & 0xffffff00;
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_30 + 1);
    uVar8 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar8 - 1;
    UNLOCK();
    if (uVar8 - 1 == 0) {
      uVar6 = (**(code **)*piStack_30)();
      LOCK();
      piVar2 = piStack_30 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        uVar6 = (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 5524 ; VA 0x005d7ebe ; Catch@005d7ebe */

undefined4 Catch_005d7ebe(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  if (DAT_01d596f0 != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x94) + 4))();
    FUN_016774b0(DAT_01d596f0,"ERROR - Exception in onPlayerDisconnectingReportClientPresence: %s",
                 uVar1);
  }
  return 0x5d7b36;
}



/* FUNCTION 5525 ; VA 0x005d7f10 ; FUN_005d7f10 */

void __thiscall FUN_005d7f10(int param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  uint uVar3;
  undefined4 *puVar4;
  
  FUN_005d2b00(param_2);
  puVar4 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
  puVar2 = *(undefined4 **)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
  while (puVar2 != (undefined4 *)0x0) {
    uVar3 = (uint)puVar2[1] % *(uint *)(param_1 + 4);
    piVar1 = (int *)(*(int *)(param_1 + 0x14) + uVar3 * 4);
    if (*(int *)(*(int *)(param_1 + 0x14) + uVar3 * 4) == 0) {
      *piVar1 = (int)puVar4;
      puVar4 = puVar2;
    }
    else {
      *puVar4 = *puVar2;
      *puVar2 = *(undefined4 *)*piVar1;
      *(undefined4 **)*piVar1 = puVar2;
    }
    puVar2 = (undefined4 *)*puVar4;
  }
  return;
}



/* FUNCTION 5526 ; VA 0x005d7f70 ; FUN_005d7f70 */

int FUN_005d7f70(uint param_1)

{
  int *piVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  char *pcVar7;
  uint uVar8;
  undefined4 ****ppppuVar9;
  undefined4 *puVar10;
  char *pcVar11;
  int iVar12;
  char ****ppppcVar13;
  char ****ppppcVar14;
  uint uVar15;
  uint *puVar16;
  undefined4 *puVar17;
  uint *puVar18;
  char ***apppcStack_130 [4];
  undefined4 uStack_120;
  uint uStack_11c;
  int iStack_118;
  int *piStack_114;
  uint *puStack_110;
  int iStack_104;
  int iStack_f8;
  int *piStack_f4;
  int iStack_f0;
  byte bStack_ec;
  undefined auStack_eb [3];
  int iStack_e8;
  int iStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  int iStack_d8;
  byte bStack_d4;
  undefined auStack_d3 [3];
  int iStack_d0;
  int iStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  int iStack_c0;
  int iStack_bc;
  int *piStack_b8;
  int *piStack_b4;
  uint uStack_b0;
  int iStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  uint uStack_9c;
  uint uStack_98;
  undefined4 *puStack_94;
  int iStack_90;
  undefined2 uStack_8c;
  int iStack_88;
  int iStack_84;
  int iStack_80;
  undefined4 ***apppuStack_7c [4];
  undefined4 uStack_6c;
  uint uStack_68;
  uint *puStack_64;
  byte bStack_60;
  undefined auStack_5f [3];
  undefined4 uStack_5c;
  int iStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  int iStack_48;
  int iStack_44;
  undefined4 *puStack_40;
  undefined4 *puStack_3c;
  undefined2 uStack_38;
  uint uStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a44d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00587490(&iStack_118);
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  if ((iStack_118 != 0) && (iVar4 = FUN_005cf750(), iVar4 != 0)) {
    piStack_b8 = *(int **)(iVar4 + 0xbc);
    if (piStack_b8 != (int *)0x0) {
      LOCK();
      piStack_b8[1] = piStack_b8[1] + 1;
      UNLOCK();
      piStack_b8 = *(int **)(iVar4 + 0xbc);
    }
    piVar5 = *(int **)(iVar4 + 0xb8);
    uStack_8._0_1_ = 1;
    iStack_18 = 0;
    FUN_005d0b80(0xe,&iStack_18,&cStack_11);
    uStack_8._0_1_ = 2;
    iStack_18 = 0;
    FUN_005d0b80(0xe,&iStack_18,&cStack_11);
    uStack_8._0_1_ = 3;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (piVar5 != (int *)0x0) {
      iStack_80 = 0;
      iStack_84 = 0;
      iStack_88 = 0;
      bStack_ec = 0;
      iStack_e8 = FUN_00588320(0xb);
      iStack_e4 = 0;
      uStack_e0 = 0x3f800000;
      uStack_dc = 0;
      iStack_d8 = 0;
      bStack_d4 = 0;
      iStack_d0 = FUN_00588320(0xb);
      iStack_cc = 0;
      uStack_c8 = 0x3f800000;
      uStack_c4 = 0;
      iStack_c0 = 0;
      iStack_18 = *piVar5;
      iStack_44 = piVar5[1];
      uStack_8._0_1_ = 5;
      uVar2 = (undefined)uStack_8;
      uStack_8._0_1_ = 5;
      puStack_64 = puStack_110;
      iVar4 = iStack_104;
      puVar16 = puStack_110;
      if (iStack_18 != iStack_44) {
        do {
          cStack_12 = '\0';
          cStack_11 = '\0';
          FUN_00562c90(&iStack_f8,iStack_18);
          uStack_8._0_1_ = 6;
          if ((iStack_f8 != 0) &&
             (piVar5 = (int *)FUN_0065b150(iStack_f8), piStack_b4 = piVar5, piVar5 != (int *)0x0)) {
            cVar3 = (**(code **)(*piVar5 + 0x22c))(param_1);
            if (cVar3 == '\0') {
              cVar3 = (**(code **)(*piVar5 + 0x230))(param_1);
              if (cVar3 == '\0') {
                iStack_88 = iStack_88 + 1;
              }
              else {
                iStack_84 = iStack_84 + 1;
              }
            }
            else {
              iStack_80 = iStack_80 + 1;
              cStack_11 = '\x01';
            }
            puVar16 = &DAT_018d0a58;
            puVar18 = puStack_110 + -0x634296;
            iStack_f0 = iStack_104 + -0x18d0a58;
            do {
              iVar4 = FUN_0065b090(*puVar16);
              if (iVar4 == 1) {
                *(int *)((int)puVar18 + (int)puVar16) = *(int *)((int)puVar18 + (int)puVar16) + 1;
                cStack_12 = '\x01';
                if ((*puVar16 & param_1) != 0) {
                  *(int *)(iStack_f0 + (int)puVar16) = *(int *)(iStack_f0 + (int)puVar16) + 1;
                }
              }
              puVar16 = puVar16 + 1;
            } while ((int)puVar16 < 0x18d0a90);
            if (cStack_12 != '\0') {
              uVar6 = (**(code **)(*piStack_b4 + 0x214))();
              pcVar7 = (char *)FUN_005f2c00(uVar6);
              uStack_6c = 0;
              uStack_68 = 0xf;
              apppuStack_7c[0] = (undefined4 ***)((uint)apppuStack_7c[0] & 0xffffff00);
              pcVar11 = pcVar7;
              do {
                cVar3 = *pcVar11;
                pcVar11 = pcVar11 + 1;
              } while (cVar3 != '\0');
              FUN_005542c0(pcVar7,(int)pcVar11 - (int)(pcVar7 + 1));
              uVar8 = (uint)bStack_ec;
              uStack_8._0_1_ = 7;
              uVar6 = FUN_005702d0(apppuStack_7c);
              FUN_00562fc0(&iStack_bc,uVar6,apppuStack_7c,
                           -(uint)(auStack_eb + uVar8 != (undefined *)0x0) &
                           (uint)(auStack_eb + uVar8 + 1));
              if (iStack_bc == 0) {
                FUN_0054ef60(apppuStack_7c);
                uStack_b0 = uStack_34;
                iStack_1c = 1;
                uStack_34 = uStack_34 & 0xffffff00;
                uStack_98 = 1;
                iStack_ac = iStack_30;
                uStack_a8 = uStack_2c;
                uStack_a4 = uStack_28;
                uStack_a0 = uStack_24;
                uStack_9c = uStack_20;
                uStack_24 = 0;
                uStack_20 = 0xf;
                uStack_8._0_1_ = 9;
                FUN_005d6280(&iStack_90,&uStack_b0);
                FUN_005507b0();
                uStack_8._0_1_ = 7;
                FUN_005507b0();
              }
              else {
                piVar5 = (int *)FUN_005d1a60(apppuStack_7c);
                *piVar5 = *piVar5 + 1;
              }
              if (cStack_11 != '\0') {
                uVar8 = (uint)bStack_d4;
                uVar6 = FUN_005702d0(apppuStack_7c);
                FUN_00562fc0(&iStack_48,uVar6,apppuStack_7c,
                             -(uint)(auStack_d3 + uVar8 != (undefined *)0x0) &
                             (uint)(auStack_d3 + uVar8 + 1));
                if (iStack_48 == 0) {
                  FUN_0054ef60(apppuStack_7c);
                  iStack_1c = 1;
                  FUN_005ce480(&uStack_34);
                  uStack_8._0_1_ = 0xb;
                  FUN_005d6280(&puStack_3c,&uStack_b0);
                  FUN_005507b0();
                  FUN_005507b0();
                }
                else {
                  piVar5 = (int *)FUN_005d1a60(apppuStack_7c);
                  *piVar5 = *piVar5 + 1;
                }
              }
              FUN_005507b0();
            }
          }
          piVar5 = piStack_f4;
          uStack_8._0_1_ = 5;
          if (piStack_f4 != (int *)0x0) {
            LOCK();
            iVar4 = piStack_f4[1] + -1;
            piStack_f4[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)*piStack_f4)();
              LOCK();
              piVar1 = piVar5 + 2;
              iVar4 = *piVar1 + -1;
              *piVar1 = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)(*piVar5 + 4))();
              }
            }
          }
          iStack_18 = iStack_18 + 8;
          iVar4 = iStack_104;
          puVar16 = puStack_110;
          uVar2 = (undefined)uStack_8;
        } while (iStack_18 != iStack_44);
      }
      uStack_8._0_1_ = uVar2;
      bStack_60 = 0;
      uStack_5c = FUN_00588320(0xb);
      iStack_58 = 0;
      uStack_54 = 0x3f800000;
      uStack_50 = 0;
      uStack_4c = 0;
      uStack_8._0_1_ = 0xc;
      uStack_24 = 0;
      uStack_20 = 0xf;
      uStack_34 = uStack_34 & 0xffffff00;
      FUN_005542c0("RCCBotStatistics_Bot",0x14);
      iStack_1c = iStack_80;
      uStack_8._0_1_ = 0xd;
      FUN_005d6280(&puStack_3c,&uStack_34);
      uStack_8._0_1_ = 0xc;
      if (0xf < uStack_20) {
        uVar15 = uStack_20 + 1;
        uVar8 = uStack_34;
        if (0xfff < uVar15) {
          uVar8 = *(uint *)(uStack_34 - 4);
          uVar15 = uStack_20 + 0x24;
          if (0x1f < (uStack_34 - uVar8) - 4) {
LAB_005d8cd0:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar8,uVar15);
      }
      uStack_24 = 0;
      uStack_20 = 0xf;
      uStack_34 = uStack_34 & 0xffffff00;
      FUN_005542c0("RCCBotStatistics_Human",0x16);
      iStack_1c = iStack_84;
      uStack_8._0_1_ = 0xe;
      FUN_005d6280(&puStack_3c,&uStack_34);
      uStack_8._0_1_ = 0xc;
      uVar2 = (undefined)uStack_8;
      uStack_8._0_1_ = 0xc;
      if (0xf < uStack_20) {
        uVar15 = uStack_20 + 1;
        uVar8 = uStack_34;
        if (0xfff < uVar15) {
          uVar8 = *(uint *)(uStack_34 - 4);
          uVar15 = uStack_20 + 0x24;
          if (0x1f < (uStack_34 - uVar8) - 4) {
            uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar8,uVar15);
      }
      uStack_24 = 0;
      uStack_20 = 0xf;
      uStack_34 = uStack_34 & 0xffffff00;
      FUN_005542c0("RCCBotStatistics_Unknown",0x18);
      iStack_1c = iStack_88;
      uStack_8._0_1_ = 0xf;
      FUN_005d6280(&puStack_3c,&uStack_34);
      uStack_8._0_1_ = 0xc;
      if (0xf < uStack_20) {
        uVar15 = uStack_20 + 1;
        uVar8 = uStack_34;
        if (0xfff < uVar15) {
          uVar8 = *(uint *)(uStack_34 - 4);
          uVar15 = uStack_20 + 0x24;
          if (0x1f < (uStack_34 - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar8,uVar15);
      }
      iVar12 = (int)&DAT_018d0a58 - (int)puVar16;
      param_1 = 0;
      iStack_48 = iVar4 - (int)puVar16;
      iStack_18 = iVar12;
      do {
        if (0 < (int)*puVar16) {
          pcVar7 = (char *)FUN_00658300(*(undefined4 *)(iVar12 + (int)puVar16));
          uStack_6c = 0;
          uStack_68 = 0xf;
          apppuStack_7c[0] = (undefined4 ***)((uint)apppuStack_7c[0] & 0xffffff00);
          pcVar11 = pcVar7;
          do {
            cVar3 = *pcVar11;
            pcVar11 = pcVar11 + 1;
          } while (cVar3 != '\0');
          FUN_005542c0(pcVar7,(int)pcVar11 - (int)(pcVar7 + 1));
          uStack_8._0_1_ = 0x10;
          ppppuVar9 = apppuStack_7c;
          if (0xf < uStack_68) {
            ppppuVar9 = (undefined4 ****)apppuStack_7c[0];
          }
          FUN_01675640(apppcStack_130,"BotCheckSignals-%s",ppppuVar9);
          uVar8 = *puVar16;
          ppppcVar14 = apppcStack_130;
          if (0xf < uStack_11c) {
            ppppcVar14 = (char ****)apppcStack_130[0];
          }
          uStack_8._0_1_ = 0x11;
          uStack_a0 = 0;
          uStack_9c = 0xf;
          uStack_b0 = uStack_b0 & 0xffffff00;
          ppppcVar13 = ppppcVar14;
          do {
            cVar3 = *(char *)ppppcVar13;
            ppppcVar13 = (char ****)((int)ppppcVar13 + 1);
          } while (cVar3 != '\0');
          FUN_005542c0(ppppcVar14,(int)ppppcVar13 - (int)((int)ppppcVar14 + 1));
          uVar15 = (uint)bStack_60;
          uStack_98 = uVar8;
          uVar6 = FUN_005702d0(&uStack_b0);
          FUN_00562fc0(&iStack_44,uVar6,&uStack_b0,
                       -(uint)(auStack_5f + uVar15 != (undefined *)0x0) &
                       (uint)(auStack_5f + uVar15 + 1));
          if (iStack_44 == 0) {
            puStack_94 = &uStack_5c;
            iStack_90 = 0;
            uStack_8c = 0;
            uStack_8._0_1_ = 0x13;
            FUN_005d2a40();
            iVar4 = iStack_90;
            FUN_0054ef60(&uStack_b0);
            *(uint *)(iVar4 + 0x20) = uStack_98;
            uStack_8c = CONCAT11(1,(undefined)uStack_8c);
            FUN_005d99d0(iStack_58 + 1);
            FUN_005c5550(&iStack_bc,&puStack_94,uVar6);
            iVar4 = iStack_90;
            if (iStack_90 != 0) {
              if (uStack_8c._1_1_ != '\0') {
                FUN_005cf430(puStack_94,iStack_90 + 8);
              }
              FUN_01674ea0(iVar4,0x24);
            }
          }
          uStack_8._0_1_ = 0x11;
          if (0xf < uStack_9c) {
            uVar15 = uStack_9c + 1;
            uVar8 = uStack_b0;
            if (0xfff < uVar15) {
              uVar8 = *(uint *)(uStack_b0 - 4);
              uVar15 = uStack_9c + 0x24;
              if (0x1f < (uStack_b0 - uVar8) - 4) goto LAB_005d8cd0;
            }
            FUN_01674ea0(uVar8,uVar15);
          }
          iVar4 = iStack_48;
          puVar16 = puStack_64;
          if (0 < *(int *)(iStack_48 + (int)puStack_64)) {
            ppppuVar9 = apppuStack_7c;
            if (0xf < uStack_68) {
              ppppuVar9 = (undefined4 ****)apppuStack_7c[0];
            }
            pcVar11 = (char *)FUN_01675640(&iStack_ac,"DecisiveBotCheckSignals-%s",ppppuVar9);
            uStack_8._0_1_ = 0x14;
            if (0xf < *(uint *)(pcVar11 + 0x14)) {
              pcVar11 = *(char **)pcVar11;
            }
            iVar4 = *(int *)(iVar4 + (int)puVar16);
            uStack_24 = 0;
            uStack_20 = 0xf;
            uStack_34 = uStack_34 & 0xffffff00;
            pcVar7 = pcVar11;
            do {
              cVar3 = *pcVar7;
              pcVar7 = pcVar7 + 1;
            } while (cVar3 != '\0');
            FUN_005542c0(pcVar11,(int)pcVar7 - (int)(pcVar11 + 1));
            uStack_8._0_1_ = 0x15;
            iStack_1c = iVar4;
            FUN_005d6280(&puStack_3c,&uStack_34);
            uStack_8._0_1_ = 0x14;
            if (0xf < uStack_20) {
              uVar15 = uStack_20 + 1;
              uVar8 = uStack_34;
              if (0xfff < uVar15) {
                uVar8 = *(uint *)(uStack_34 - 4);
                uVar15 = uStack_20 + 0x24;
                if (0x1f < (uStack_34 - uVar8) - 4) goto LAB_005d8cd0;
              }
              FUN_01674ea0(uVar8,uVar15);
            }
            uStack_24 = 0;
            uStack_20 = 0xf;
            uStack_34 = uStack_34 & 0xffffff00;
            uStack_8._0_1_ = 0x11;
            if (0xf < uStack_98) {
              uVar8 = uStack_98 + 1;
              iVar4 = iStack_ac;
              if (0xfff < uVar8) {
                iVar4 = *(int *)(iStack_ac + -4);
                uVar8 = uStack_98 + 0x24;
                if (0x1f < (iStack_ac - iVar4) - 4U) goto LAB_005d8cd0;
              }
              FUN_01674ea0(iVar4,uVar8);
            }
          }
          puVar16 = puStack_64;
          uStack_8._0_1_ = 0x10;
          if (0xf < uStack_11c) {
            uVar8 = uStack_11c + 1;
            ppppcVar14 = (char ****)apppcStack_130[0];
            if (0xfff < uVar8) {
              ppppcVar14 = (char ****)apppcStack_130[0][-1];
              uVar8 = uStack_11c + 0x24;
              if ((char *)0x1f < (char *)((int)apppcStack_130[0] + (-4 - (int)ppppcVar14)))
              goto LAB_005d8cd0;
            }
            FUN_01674ea0(ppppcVar14,uVar8);
          }
          uStack_120 = 0;
          uStack_11c = 0xf;
          apppcStack_130[0] = (char ***)((uint)apppcStack_130[0] & 0xffffff00);
          uStack_8._0_1_ = 0xc;
          iVar12 = iStack_18;
          if (0xf < uStack_68) {
            uVar8 = uStack_68 + 1;
            ppppuVar9 = (undefined4 ****)apppuStack_7c[0];
            if (0xfff < uVar8) {
              ppppuVar9 = (undefined4 ****)apppuStack_7c[0][-1];
              uVar8 = uStack_68 + 0x24;
              if (0x1f < (uint)((int)apppuStack_7c[0] + (-4 - (int)ppppuVar9))) goto LAB_005d8cd0;
            }
            FUN_01674ea0(ppppuVar9,uVar8);
            iVar12 = iStack_18;
          }
        }
        param_1 = param_1 + 1;
        puVar16 = puVar16 + 1;
        puStack_64 = puVar16;
      } while ((int)param_1 < 0xe);
      if (iStack_e4 == 0) {
        puVar17 = (undefined4 *)0x0;
      }
      else {
        puVar17 = *(undefined4 **)(iStack_d8 + iStack_e8 * 4);
      }
      for (; puVar17 != (undefined4 *)0x0; puVar17 = (undefined4 *)*puVar17) {
        piVar5 = puVar17 + 2;
        if (0xf < (uint)puVar17[7]) {
          piVar5 = (int *)*piVar5;
        }
        pcVar11 = (char *)FUN_01675640(&iStack_ac,"BotCheckSignals-%s",piVar5);
        uStack_8._0_1_ = 0x16;
        if (0xf < *(uint *)(pcVar11 + 0x14)) {
          pcVar11 = *(char **)pcVar11;
        }
        iVar4 = puVar17[8];
        uStack_24 = 0;
        uStack_20 = 0xf;
        uStack_34 = uStack_34 & 0xffffff00;
        pcVar7 = pcVar11;
        do {
          cVar3 = *pcVar7;
          pcVar7 = pcVar7 + 1;
        } while (cVar3 != '\0');
        FUN_005542c0(pcVar11,(int)pcVar7 - (int)(pcVar11 + 1));
        uVar8 = (uint)bStack_60;
        iStack_1c = iVar4;
        uVar6 = FUN_005702d0(&uStack_34);
        FUN_00562fc0(&iStack_44,uVar6,&uStack_34,
                     -(uint)(auStack_5f + uVar8 != (undefined *)0x0) &
                     (uint)(auStack_5f + uVar8 + 1));
        if (iStack_44 == 0) {
          puStack_40 = &uStack_5c;
          puStack_3c = (undefined4 *)0x0;
          uStack_8._0_1_ = 0x18;
          uStack_38 = 0;
          puVar10 = (undefined4 *)FUN_01674e20(0x24);
          uStack_38 = CONCAT11(uStack_38._1_1_,1);
          *puVar10 = 0;
          puVar10[1] = 0;
          puVar10[2] = 0;
          puVar10[3] = 0;
          puVar10[4] = 0;
          puVar10[5] = 0;
          *(undefined8 *)(puVar10 + 6) = 0;
          puVar10[8] = 0;
          puStack_3c = puVar10;
          FUN_0054ef60(&uStack_34);
          puVar10[8] = iStack_1c;
          uStack_38 = CONCAT11(1,(undefined)uStack_38);
          FUN_005d99d0(iStack_58 + 1);
          FUN_005c5550(&iStack_48,&puStack_40,uVar6);
          puVar10 = puStack_3c;
          if (puStack_3c != (undefined4 *)0x0) {
            if (uStack_38._1_1_ != '\0') {
              FUN_005cf430(puStack_40,puStack_3c + 2);
            }
            FUN_01674ea0(puVar10,0x24);
          }
        }
        FUN_005507b0();
        uStack_8._0_1_ = 0xc;
        FUN_005507b0();
      }
      if (iStack_cc == 0) {
        puVar17 = (undefined4 *)0x0;
      }
      else {
        puVar17 = *(undefined4 **)(iStack_c0 + iStack_d0 * 4);
      }
      for (; puVar17 != (undefined4 *)0x0; puVar17 = (undefined4 *)*puVar17) {
        piVar5 = puVar17 + 2;
        if (0xf < (uint)puVar17[7]) {
          piVar5 = (int *)*piVar5;
        }
        pcVar11 = (char *)FUN_01675640(&iStack_ac,"DecisiveBotCheckSignals-%s",piVar5);
        uStack_8._0_1_ = 0x19;
        if (0xf < *(uint *)(pcVar11 + 0x14)) {
          pcVar11 = *(char **)pcVar11;
        }
        iVar4 = puVar17[8];
        uStack_24 = 0;
        uStack_20 = 0xf;
        uStack_34 = uStack_34 & 0xffffff00;
        pcVar7 = pcVar11;
        do {
          cVar3 = *pcVar7;
          pcVar7 = pcVar7 + 1;
        } while (cVar3 != '\0');
        FUN_005542c0(pcVar11,(int)pcVar7 - (int)(pcVar11 + 1));
        uVar8 = (uint)bStack_60;
        iStack_1c = iVar4;
        uVar6 = FUN_005702d0(&uStack_34);
        FUN_00562fc0(&iStack_44,uVar6,&uStack_34,
                     -(uint)(auStack_5f + uVar8 != (undefined *)0x0) &
                     (uint)(auStack_5f + uVar8 + 1));
        if (iStack_44 == 0) {
          puStack_40 = &uStack_5c;
          puStack_3c = (undefined4 *)0x0;
          uStack_38 = 0;
          uStack_8._0_1_ = 0x1b;
          FUN_005d2a40();
          puVar10 = puStack_3c;
          FUN_0054ef60(&uStack_34);
          puVar10[8] = iStack_1c;
          uStack_38 = CONCAT11(1,(undefined)uStack_38);
          FUN_005d99d0(iStack_58 + 1);
          FUN_005c5550(&iStack_48,&puStack_40,uVar6);
          puVar10 = puStack_40;
          if (puStack_3c != (undefined4 *)0x0) {
            if (uStack_38._1_1_ != '\0') {
              FUN_005cf430(puStack_40,puStack_3c + 2);
            }
            FUN_005d3170(puVar10,puStack_3c,1);
          }
        }
        FUN_005507b0();
        uStack_8._0_1_ = 0xc;
        FUN_005507b0();
      }
      FUN_008749d0(&bStack_60,0);
      FUN_005d1280();
      FUN_005d1280();
      FUN_005d1280();
      uVar2 = (undefined)uStack_8;
    }
    uStack_8._0_1_ = uVar2;
    FUN_0056d320();
    iVar4 = FUN_0056d320();
    piVar5 = piStack_b8;
    if (piStack_b8 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_b8 + 1;
      iVar12 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar12 + -1;
      UNLOCK();
      if (iVar12 + -1 == 0) {
        (**(code **)*piStack_b8)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar12 = *piVar1;
        iVar4 = *piVar1;
        *piVar1 = iVar12 + -1;
        UNLOCK();
        if (iVar12 + -1 == 0) {
          iVar4 = (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  if (piStack_114 != (int *)0x0) {
    LOCK();
    piVar5 = piStack_114 + 1;
    iVar12 = *piVar5;
    iVar4 = *piVar5;
    *piVar5 = iVar12 + -1;
    UNLOCK();
    if (iVar12 + -1 == 0) {
      iVar4 = (**(code **)*piStack_114)();
      LOCK();
      piVar5 = piStack_114 + 2;
      iVar12 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar12 == 1) {
        iVar4 = (**(code **)(*piStack_114 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 5527 ; VA 0x005d8cf0 ; FUN_005d8cf0 */

/* WARNING: Type propagation algorithm not settling */

int * __thiscall FUN_005d8cf0(int param_1,int *param_2)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *******pppppppuVar6;
  int *piVar7;
  float10 fVar8;
  undefined8 uVar9;
  undefined auStack_a4 [16];
  undefined4 uStack_94;
  undefined4 uStack_90;
  double dStack_8c;
  int iStack_84;
  int *piStack_80;
  double dStack_7c;
  int iStack_74;
  undefined4 *******apppppppuStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  undefined auStack_58 [24];
  undefined auStack_40 [4];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a5f4;
  pvStack_10 = ExceptionList;
  if (*param_2 == 0) {
    return param_2;
  }
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01679ce0();
  if (DAT_01ea8d24 <= (int)(uVar3 % 10000)) {
    ExceptionList = pvStack_10;
    return (int *)(uVar3 / 10000);
  }
  if (DAT_01ea8d1c != '\0') {
    FUN_016774b0();
  }
  FUN_00587490();
  uStack_8 = 0;
  if (iStack_84 == 0) {
    piVar7 = (int *)(uint)DAT_01d596f0;
    if (DAT_01d596f0 == 0) goto LAB_005d998a;
    uVar9 = 0x18c6b88;
  }
  else {
    fVar8 = (float10)FUN_01160660();
    dStack_8c = (double)(fVar8 - (float10)*(double *)(param_1 + 0x20));
    iVar4 = FUN_00562e40();
    iStack_74 = FUN_00562d80();
    if ((iVar4 != 0) && (iStack_74 != 0)) {
      if (DAT_01d597e4 == '\0') {
        fVar8 = (float10)FUN_005d2710();
        dStack_7c = (double)fVar8;
      }
      else {
        dStack_7c = *(double *)(param_1 + 200);
      }
      auStack_40[0] = 0;
      uStack_3c = FUN_00588320();
      uStack_38 = 0;
      uStack_34 = 0x3f800000;
      uStack_30 = 0;
      uStack_2c = 0;
      uStack_8._0_1_ = 1;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("gameId",6);
      uStack_8._0_1_ = 2;
      FUN_005d15d0(auStack_28);
      FUN_00551260();
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      FUN_01675640(auStack_58,&DAT_018bed48,**(undefined4 **)(param_1 + 0x40),
                   (*(undefined4 **)(param_1 + 0x40))[1]);
      uStack_8._0_1_ = 3;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("placeId",7);
      uStack_8._0_1_ = 4;
      FUN_005d15d0(auStack_28);
      FUN_005511f0();
      FUN_005507b0();
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      FUN_01675640(auStack_58,&DAT_018bed68,*(undefined4 *)(*(int *)(param_1 + 0x40) + 0x7c));
      uStack_8._0_1_ = 5;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("gameCapacity",0xc);
      uStack_8._0_1_ = 6;
      FUN_005d15d0(auStack_28);
      FUN_005511f0();
      FUN_005507b0();
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("serverIpAddress",0xf);
      uStack_8._0_1_ = 7;
      FUN_005d15d0(auStack_28);
      FUN_00551260();
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      FUN_01675640(auStack_58,&DAT_018bed68,*(undefined4 *)(iVar4 + 0x104));
      uStack_8._0_1_ = 8;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0(&DAT_018c5e3c,4);
      uStack_8._0_1_ = 9;
      FUN_005d15d0(auStack_28);
      FUN_005511f0();
      FUN_005507b0();
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      fVar8 = (float10)FUN_00999e90();
      FUN_01675640(auStack_58,&DAT_018c6c50,(double)fVar8);
      uStack_8._0_1_ = 10;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0(&DAT_018c5e44,3);
      uStack_8._0_1_ = 0xb;
      FUN_005d15d0(auStack_28);
      FUN_005511f0();
      FUN_005507b0();
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      FUN_01675640(auStack_58,&DAT_018c5880,*(undefined8 *)(param_1 + 0xb0));
      uStack_8._0_1_ = 0xc;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("heartbeatRate",0xd);
      uStack_8._0_1_ = 0xd;
      FUN_005d15d0(auStack_28);
      FUN_005511f0();
      FUN_005507b0();
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      FUN_01675640(auStack_58,&DAT_018c6c50,dStack_7c);
      uStack_8._0_1_ = 0xe;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0(&DAT_018c5e58,4);
      uStack_8._0_1_ = 0xf;
      FUN_005d15d0(auStack_28);
      FUN_005511f0();
      FUN_005507b0();
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      fVar8 = (float10)FUN_00999800();
      FUN_01675640(auStack_58,&DAT_018c5880,(double)fVar8);
      uStack_8._0_1_ = 0x10;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("physicsLoadAverage",0x12);
      uStack_8._0_1_ = 0x11;
      FUN_005d15d0(auStack_28);
      FUN_005511f0();
      FUN_005507b0();
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      fVar8 = (float10)FUN_009997d0();
      FUN_01675640(auStack_58,&DAT_018c5880,(double)fVar8);
      uStack_8._0_1_ = 0x12;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("physicsEnvironmentSpeed",0x17);
      uStack_8._0_1_ = 0x13;
      FUN_005d15d0(auStack_28);
      FUN_005511f0();
      FUN_005507b0();
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      FUN_01675640(auStack_58,&DAT_018c5880);
      uStack_8._0_1_ = 0x14;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("gameTime",8);
      uStack_8._0_1_ = 0x15;
      FUN_005d15d0(auStack_28);
      FUN_005511f0();
      FUN_005507b0();
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      FUN_01675640(auStack_58,&DAT_018bed48,*(undefined4 *)(*(int *)(param_1 + 0x40) + 8),
                   *(undefined4 *)(*(int *)(param_1 + 0x40) + 0xc));
      uStack_8._0_1_ = 0x16;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("universeId",10);
      uStack_8._0_1_ = 0x17;
      FUN_005d15d0(auStack_28);
      FUN_005511f0();
      FUN_005507b0();
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("gameCode",8);
      uStack_8._0_1_ = 0x18;
      FUN_005d15d0(auStack_28);
      FUN_00551260();
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      uVar5 = FUN_006444a0();
      FUN_01675640(auStack_58,&DAT_018bed68,uVar5);
      uStack_8._0_1_ = 0x19;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("clientCount",0xb);
      uStack_8._0_1_ = 0x1a;
      FUN_005d15d0(auStack_28);
      FUN_005511f0();
      FUN_005507b0();
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      FUN_01675640(auStack_58,&DAT_018bed68,*(undefined4 *)(*(int *)(param_1 + 0x40) + 0x98));
      uStack_8._0_1_ = 0x1b;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("preferredPlayerCapacity",0x17);
      uStack_8._0_1_ = 0x1c;
      FUN_005d15d0(auStack_28);
      FUN_005511f0();
      FUN_005507b0();
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("isCloudEdit",0xb);
      uStack_8._0_1_ = 0x1d;
      FUN_005d15d0(auStack_28);
      FUN_00551260();
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      FUN_00912100();
      uStack_8._0_1_ = 0x1e;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("rccVersion",10);
      uStack_8._0_1_ = 0x1f;
      FUN_005d15d0(auStack_28);
      FUN_00551260();
      FUN_005507b0();
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      FUN_01675640(auStack_58,&DAT_018c5880,
                   *(double *)(param_1 + 0xc0) + *(double *)(param_1 + 0xb8));
      uStack_8._0_1_ = 0x20;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("cpuUsage",8);
      uStack_8._0_1_ = 0x21;
      FUN_005d15d0(auStack_28);
      FUN_005511f0();
      FUN_005507b0();
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      uVar9 = FUN_01522960();
      FUN_01675640(auStack_58,&DAT_018c6c58,uVar9);
      uStack_8._0_1_ = 0x22;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("usedMemoryBytes",0xf);
      uStack_8._0_1_ = 0x23;
      FUN_005d15d0(auStack_28);
      FUN_005511f0();
      FUN_005507b0();
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      uVar9 = FUN_00928340();
      dStack_7c = (double)uVar9;
      iVar4 = FUN_005d1850();
      piVar7 = param_2;
      dStack_8c = *(double *)(iVar4 + 8);
      FUN_0054ef60();
      uStack_8._0_1_ = 0x24;
      FUN_01675640(auStack_a4,&DAT_018bed48,uVar9);
      uStack_8._0_1_ = 0x25;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("userId",6);
      uStack_8._0_1_ = 0x26;
      FUN_005d15d0(auStack_28);
      FUN_005511f0();
      FUN_005507b0();
      uStack_8._0_1_ = 0x24;
      FUN_005507b0();
      FUN_0054ef60();
      pppppppuVar6 = apppppppuStack_70;
      if (0xf < uStack_5c) {
        pppppppuVar6 = apppppppuStack_70[0];
      }
      uStack_8._0_1_ = 0x27;
      FUN_0055c360(pppppppuVar6,uStack_60,&DAT_018bc9b8,0);
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0(&DAT_018c5d68,4);
      uStack_8._0_1_ = 0x28;
      FUN_005d15d0(auStack_28);
      FUN_00551260();
      FUN_005507b0();
      uStack_8._0_1_ = 0x24;
      FUN_005507b0();
      FUN_01675640(auStack_a4,&DAT_018c5880,dStack_8c);
      uStack_8._0_1_ = 0x29;
      uStack_60 = 0;
      uStack_5c = 0xf;
      apppppppuStack_70[0] = (undefined4 *******)((uint)apppppppuStack_70[0] & 0xffffff00);
      FUN_005542c0("GameTimeWhenJoined",0x12);
      uStack_8._0_1_ = 0x2a;
      FUN_005d15d0(apppppppuStack_70);
      FUN_005511f0();
      FUN_005507b0();
      uStack_8._0_1_ = 0x24;
      FUN_005507b0();
      uStack_60 = 0;
      uStack_5c = 0xf;
      apppppppuStack_70[0] = (undefined4 *******)((uint)apppppppuStack_70[0] & 0xffffff00);
      FUN_005542c0("GameSessionId",0xd);
      uStack_8._0_1_ = 0x2b;
      FUN_005d15d0(apppppppuStack_70);
      FUN_00551230();
      uStack_8._0_1_ = 0x24;
      FUN_005507b0();
      param_2 = *(int **)(*piVar7 + 0x450);
      FUN_00920c80(auStack_a4,&param_2);
      uStack_8._0_1_ = 0x2c;
      uStack_60 = 0;
      uStack_5c = 0xf;
      apppppppuStack_70[0] = (undefined4 *******)((uint)apppppppuStack_70[0] & 0xffffff00);
      FUN_005542c0("MembershipType",0xe);
      uStack_8._0_1_ = 0x2d;
      FUN_005d15d0(apppppppuStack_70);
      FUN_005511f0();
      FUN_005507b0();
      uStack_8 = CONCAT31(uStack_8._1_3_,0x24);
      FUN_005507b0();
      iVar4 = FUN_0065b150();
      if (iVar4 != 0) {
        FUN_00657b90();
      }
      uStack_94 = 0;
      uStack_90 = 0xf;
      auStack_a4[0] = 0;
      FUN_005542c0("RCCSignal",9);
      uStack_8._0_1_ = 0x2e;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("BotCheckStatus",0xe);
      uStack_8._0_1_ = 0x2f;
      uStack_60 = 0;
      uStack_5c = 0xf;
      apppppppuStack_70[0] = (undefined4 *******)((uint)apppppppuStack_70[0] & 0xffffff00);
      FUN_005542c0("client",6);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x30);
      FUN_008794f0(apppppppuStack_70,auStack_28,auStack_a4,auStack_40);
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_0056cfd0();
      piVar7 = (int *)FUN_00550b30();
      ExceptionList = pvStack_10;
      return piVar7;
    }
    piVar7 = (int *)(uint)DAT_01d596f0;
    if (DAT_01d596f0 == 0) goto LAB_005d998a;
    uVar9 = 0x18c6be0;
  }
  piVar7 = (int *)FUN_016774b0(piVar7,uVar9);
LAB_005d998a:
  if (piStack_80 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_80 + 1);
    uVar3 = *puVar1;
    piVar7 = (int *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      piVar7 = (int *)(**(code **)*piStack_80)();
      LOCK();
      piVar2 = piStack_80 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        piVar7 = (int *)(**(code **)(*piStack_80 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar7;
}



/* FUNCTION 5528 ; VA 0x005d99d0 ; FUN_005d99d0 */

void __thiscall FUN_005d99d0(int param_1,uint param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar3 = FUN_005d6bb0(param_2);
    if (uVar3 <= *(uint *)(param_1 + 4)) {
      uVar3 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar3);
    return;
  }
  if (*(uint *)(param_1 + 0x10) < param_2) {
    uVar3 = (*(uint *)(param_1 + 8) >> 1) + *(int *)(param_1 + 8);
    if (param_2 < uVar3) {
      param_2 = uVar3;
    }
    iVar4 = FUN_005d6bb0(param_2);
    if (iVar4 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar4);
      puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar2 = (undefined4 *)*puVar5;
      while (puVar2 != (undefined4 *)0x0) {
        uVar3 = (uint)puVar2[1] % *(uint *)(param_1 + 4);
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + uVar3 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar3 * 4) == 0) {
          *piVar1 = (int)puVar5;
          puVar5 = puVar2;
        }
        else {
          *puVar5 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar2;
        }
        puVar2 = (undefined4 *)*puVar5;
      }
    }
  }
  return;
}



/* FUNCTION 5529 ; VA 0x005d9a70 ; FUN_005d9a70 */

uint FUN_005d9a70(void)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  undefined **appuStack_ec [9];
  undefined *puStack_c8;
  undefined **appuStack_c4 [9];
  undefined *puStack_a0;
  undefined **appuStack_9c [9];
  undefined *puStack_78;
  undefined **appuStack_74 [6];
  undefined4 uStack_5c;
  code *pcStack_58;
  undefined *puStack_50;
  undefined **appuStack_4c [6];
  undefined4 uStack_34;
  uint uStack_30;
  undefined8 uStack_2c;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a608;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01ea8d1c != 0) {
    uStack_30 = (uint)DAT_01ea8d1c;
    uStack_2c = 1.28350982143249e-316;
    uStack_34 = 0x5d9aa8;
    ExceptionList = &pvStack_10;
    FUN_016774b0();
  }
  uStack_2c = (double)CONCAT44(&iStack_1c,0x5d9ab7);
  FUN_00587490();
  uStack_8 = 0;
  if (iStack_1c == 0) {
    uVar5 = (uint)DAT_01d596f0;
    if (DAT_01d596f0 == 0) goto LAB_005d9c41;
    uStack_2c = 1.2835112048163e-316;
  }
  else {
    uStack_2c = (double)CONCAT44(0x5d9ae7,(undefined4)uStack_2c);
    iVar4 = FUN_00562e40();
    if ((iVar4 != 0) && (*(int *)(iVar4 + 0x104) != 0)) {
      if (DAT_01d7ab04 == '\0') {
        if (DAT_01ea8d20 != 0) {
          uStack_2c = (double)CONCAT44(0x5d9b82,(undefined4)uStack_2c);
          iVar4 = FUN_005cf2a0();
          if (iVar4 != 0) {
            uStack_2c = (double)DAT_01ea8d20;
            puStack_50 = (undefined *)0x0;
            pcStack_58 = FUN_005d41c0;
            uStack_5c = 0x5d9bac;
            FUN_005ce4d0();
            puStack_50 = (undefined *)0x5d9bb3;
            FUN_009eef30();
            uStack_2c = (double)CONCAT44(0x5d9bba,(undefined4)uStack_2c);
            FUN_005d25b0();
            uStack_2c = (double)CONCAT44(0x5d9bc1,(undefined4)uStack_2c);
            uVar5 = FUN_005d5840();
            goto LAB_005d9c41;
          }
          if (DAT_01d596f0 != 0) {
            uStack_30 = (uint)DAT_01d596f0;
            uStack_2c = 1.28351416921017e-316;
            uStack_34 = 0x5d9bdc;
            FUN_016774b0();
          }
        }
        uStack_2c = (double)CONCAT44(0x5d9be6,(undefined4)uStack_2c);
        FUN_005d25b0();
        uStack_2c = (double)CONCAT44(0x5d9bed,(undefined4)uStack_2c);
        uVar5 = FUN_005d5840();
      }
      else {
        uStack_2c = (double)CONCAT44(0x5d9b0a,(undefined4)uStack_2c);
        FUN_0152f4b0();
        puStack_50 = (undefined *)appuStack_74;
        appuStack_4c[0] =
             std::
             _Func_impl_no_alloc<class_<lambda_0039b956a706ce0dfb3654c316d8b63f>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
             ::vftable;
        uStack_2c = (double)CONCAT44(appuStack_4c,(undefined4)uStack_2c);
        puStack_78 = (undefined *)appuStack_9c;
        puStack_a0 = (undefined *)appuStack_c4;
        appuStack_74[0] =
             std::
             _Func_impl_no_alloc<class_<lambda_e488513700340f6127a1ed40ae0ee935>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&>
             ::vftable;
        appuStack_9c[0] =
             std::
             _Func_impl_no_alloc<class_<lambda_5ec7961a904fad14b9b35ea2c27dcfe0>,void,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&>
             ::vftable;
        puStack_c8 = (undefined *)appuStack_ec;
        appuStack_c4[0] =
             std::_Func_impl_no_alloc<class_<lambda_59ca0768fa2655ef42894aca9e59632f>,void>::vftable
        ;
        appuStack_ec[0] =
             std::
             _Func_impl_no_alloc<class_<lambda_02dc363b9a35ab9e2ee86a8d63dfd0fa>,void,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&>
             ::vftable;
        FUN_0152f540();
        uStack_2c = (double)CONCAT44(0x5d9b66,(undefined4)uStack_2c);
        FUN_005d25b0();
        uStack_2c = (double)CONCAT44(0x5d9b6d,(undefined4)uStack_2c);
        uVar5 = FUN_005d5840();
      }
      goto LAB_005d9c41;
    }
    uStack_2c = (double)CONCAT44(0x5d9bf6,(undefined4)uStack_2c);
    iVar4 = FUN_005cf2a0();
    if (iVar4 != 0) {
      uStack_2c = (double)DAT_018c0d60;
      puStack_50 = (undefined *)0x0;
      pcStack_58 = FUN_005d9a70;
      uStack_5c = 0x5d9c1c;
      FUN_005ce4d0();
      puStack_50 = (undefined *)0x5d9c23;
      uVar5 = FUN_009eef30();
      goto LAB_005d9c41;
    }
    uVar5 = (uint)DAT_01d596f0;
    if (DAT_01d596f0 == 0) goto LAB_005d9c41;
    uStack_2c = 1.28351772648282e-316;
  }
  uStack_34 = 0x5d9c3e;
  uStack_30 = uVar5;
  uVar5 = FUN_016774b0();
LAB_005d9c41:
  if (piStack_18 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_18 + 1);
    uVar3 = *puVar1;
    uVar5 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uStack_2c = (double)CONCAT44(0x5d9c5a,(undefined4)uStack_2c);
      uVar5 = (**(code **)*piStack_18)();
      LOCK();
      piVar2 = piStack_18 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uStack_2c = (double)CONCAT44(0x5d9c69,(undefined4)uStack_2c);
        uVar5 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 5530 ; VA 0x005d9c80 ; FUN_005d9c80 */

uint __fastcall FUN_005d9c80(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  undefined4 uVar6;
  float10 fVar7;
  double dVar8;
  undefined auStack_8c [28];
  undefined auStack_70 [28];
  undefined auStack_54 [4];
  undefined auStack_50 [24];
  undefined auStack_38 [4];
  undefined4 uStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a6a9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01ea8d1c != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ea8d1c,"- sendHeartbeatToDiag -",0);
  }
  FUN_00587490(&iStack_20);
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  if (iStack_20 == 0) {
    uVar4 = (uint)DAT_01d596f0;
    if (DAT_01d596f0 != 0) {
      uVar4 = FUN_016774b0(DAT_01d596f0,
                           "ERROR (sendHeartbeatToDiag) - DataModel is unexpectedly null.",0);
    }
  }
  else {
    iVar5 = FUN_00562d80();
    if (iVar5 == 0) {
      uVar4 = (uint)DAT_01d596f0;
      if (DAT_01d596f0 != 0) {
        uVar4 = FUN_016774b0(DAT_01d596f0,
                             "ERROR (sendHeartbeatToDiag) - RunService are unexpectedly null.",0);
      }
    }
    else if (DAT_01d597cc == '\0') {
      uVar4 = (uint)*(double *)(param_1 + 0xb0);
      if ((int)uVar4 < DAT_01d596fc) {
        uStack_28 = 0;
        uStack_24 = 0xf;
        auStack_38[0] = 0;
        FUN_005542c0("GameBelowSlowGameFps",0x14);
        uStack_8._0_1_ = 0xe;
        FUN_008783f0(auStack_38,1,0);
        uStack_8._0_1_ = 0;
        FUN_005507b0();
        uVar6 = FUN_01675640(auStack_50,"GameBelowSlowGameFps_%d",*(undefined4 *)(iStack_20 + 0x44c)
                            );
        uStack_8._0_1_ = 0xf;
        FUN_008783f0(uVar6,1,0);
        uVar4 = FUN_005507b0();
      }
    }
    else {
      auStack_38[0] = 0;
      uStack_34 = FUN_00588320(0xb);
      iStack_30 = 0;
      uStack_2c = 0x3f800000;
      uStack_28 = 0;
      uStack_24 = 0;
      uStack_8._0_1_ = 1;
      if ((int)*(double *)(param_1 + 0xb0) < DAT_01d596fc) {
        uStack_18 = 2.13482951765336e-314;
        FUN_005ce430(&uStack_18);
        uStack_8._0_1_ = 2;
        FUN_005d6280(&uStack_18,auStack_54);
        uStack_8._0_1_ = 1;
        FUN_005507b0();
        uStack_18 = (double)CONCAT44(1,(undefined4)uStack_18);
        uVar6 = FUN_01675640(auStack_50,"GameBelowSlowGameFps_%d",*(undefined4 *)(iStack_20 + 0x44c)
                            );
        uVar6 = FUN_005cf990(auStack_8c,uVar6,(int)&uStack_18 + 4);
        FUN_005ce480(uVar6);
        uStack_8._0_1_ = 5;
        FUN_005d6280(&uStack_18,auStack_70);
        FUN_005507b0();
        FUN_005507b0();
        uStack_8._0_1_ = 1;
        FUN_005507b0();
      }
      fVar7 = (float10)FUN_00999e90();
      uStack_18 = (double)fVar7;
      if ((int)fVar7 < DAT_01d5970c) {
        uStack_18 = 2.13482954136852e-314;
        FUN_005ce430(&uStack_18);
        uStack_8._0_1_ = 6;
        FUN_005d6280(&uStack_18,auStack_70);
        uStack_8._0_1_ = 1;
        FUN_005507b0();
        uStack_18 = (double)CONCAT44(1,(undefined4)uStack_18);
        uVar6 = FUN_01675640(auStack_50,"GameBelowSlowGameSmoothFps_%d",
                             *(undefined4 *)(iStack_20 + 0x44c));
        uVar6 = FUN_005cf990(auStack_8c,uVar6,(int)&uStack_18 + 4);
        FUN_005ce480(uVar6);
        uStack_8._0_1_ = 9;
        FUN_005d6280(&uStack_18,auStack_70);
        FUN_005507b0();
        FUN_005507b0();
        uStack_8._0_1_ = 1;
        FUN_005507b0();
      }
      if (DAT_01d597e4 == '\0') {
        fVar7 = (float10)FUN_005d2710();
        dVar8 = (double)fVar7;
        uStack_18 = dVar8;
      }
      else {
        dVar8 = *(double *)(param_1 + 200);
      }
      if (DAT_01d59714 < (int)dVar8) {
        uStack_18 = 2.13482957101245e-314;
        FUN_005ce430(&uStack_18);
        uStack_8._0_1_ = 10;
        FUN_005d6280(&uStack_18,auStack_70);
        uStack_8._0_1_ = 1;
        FUN_005507b0();
        uStack_18 = (double)CONCAT44(1,(undefined4)uStack_18);
        uVar6 = FUN_01675640(auStack_50,"GameLongAvgPing_%d",*(undefined4 *)(iStack_20 + 0x44c));
        uVar6 = FUN_005cf990(auStack_8c,uVar6,(int)&uStack_18 + 4);
        FUN_005ce480(uVar6);
        uStack_8._0_1_ = 0xd;
        FUN_005d6280(&uStack_18,auStack_70);
        FUN_005507b0();
        FUN_005507b0();
        uStack_8._0_1_ = 1;
        FUN_005507b0();
      }
      if (iStack_30 != 0) {
        FUN_008749d0(auStack_38,0);
      }
      uVar4 = FUN_005d1280();
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_1c + 1);
    uVar3 = *puVar1;
    uVar4 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar4 = (**(code **)*piStack_1c)();
      LOCK();
      piVar2 = piStack_1c + 2;
      iVar5 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        uVar4 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 5531 ; VA 0x005da090 ; FUN_005da090 */

void __thiscall FUN_005da090(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  uint *puVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 ****ppppuVar5;
  int iVar6;
  undefined4 uVar7;
  undefined8 uVar8;
  char *pcVar9;
  undefined auStack_160 [120];
  undefined auStack_e8 [24];
  undefined auStack_d0 [24];
  undefined auStack_b8 [16];
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined auStack_a0 [16];
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined auStack_88 [16];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 uStack_68;
  int iStack_60;
  int *piStack_5c;
  undefined auStack_58 [16];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 ***apppuStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a745;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8dd8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ea8dd8);
    if (DAT_01ea8dd8 == -1) {
      uStack_8 = 0;
      uVar8 = FUN_0152dab0(&DAT_018c5904,"Games Instances Service Reporting",0xffffffff);
      DAT_01ea8dd4 = (undefined4)((ulonglong)uVar8 >> 0x20);
      DAT_01ea8dd0 = (undefined4)uVar8;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ea8dd8);
    }
  }
  uStack_28 = DAT_01ea8dd0;
  uStack_70 = DAT_01ea8dd0;
  uStack_24 = DAT_01ea8dd4;
  uStack_6c = DAT_01ea8dd4;
  uStack_68 = FUN_0152d930(DAT_01ea8dd0,DAT_01ea8dd4);
  uStack_8 = 1;
  if (DAT_01ea8d1c != '\0') {
    FUN_016774b0(DAT_01ea8d1c,"- sendMessageToGameInstancesApi -",0);
  }
  FUN_00587490(&iStack_60);
  uStack_8._0_1_ = 2;
  if (iStack_60 == 0) {
    if (DAT_01d596f0 == '\0') goto LAB_005da410;
    pcVar9 = "ERROR (sendMessageToGameInstancesApi) - DataModel is unexpectedly null.";
  }
  else {
    iStack_20 = FUN_00562e40();
    iStack_14 = FUN_00562d80();
    uVar3 = uStack_1c;
    if ((iStack_20 != 0) && (iStack_14 != 0)) {
      uStack_1c = uStack_1c & 0xffffff00;
      if (*(int *)(iStack_60 + 0x1b8) != 0) {
        uStack_1c = CONCAT31(SUB43(uVar3,1),*(undefined *)(*(int *)(iStack_60 + 0x1b8) + 0x300));
      }
      uStack_30 = 0;
      uStack_2c = 0xf;
      apppuStack_40[0] = (undefined4 ***)((uint)apppuStack_40[0] & 0xffffff00);
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      if (DAT_01d593c8 == '\0') {
        uVar4 = FUN_005d5040(auStack_58);
      }
      else {
        uVar4 = FUN_005d48e0(auStack_58,param_2);
      }
      FUN_005511f0(uVar4);
      FUN_005507b0();
      puVar2 = (uint *)(param_1 + 0xd8);
      uVar3 = *puVar2;
      *puVar2 = *puVar2 + 1;
      *(int *)(param_1 + 0xdc) = *(int *)(param_1 + 0xdc) + (uint)(0xfffffffe < uVar3);
      FUN_005d4400(auStack_d0,iStack_20,iStack_14,param_2,param_3,uStack_1c);
      uStack_8._0_1_ = 6;
      uStack_a8 = 0;
      uStack_a4 = 0xf;
      auStack_b8[0] = 0;
      FUN_005542c0(&DAT_018bc9b8,0);
      uStack_8._0_1_ = 7;
      uStack_90 = 0;
      uStack_8c = 0xf;
      auStack_a0[0] = 0;
      FUN_005542c0("/v2/CreateOrUpdate/",0x13);
      uStack_8._0_1_ = 8;
      uStack_78 = 0;
      uStack_74 = 0xf;
      auStack_88[0] = 0;
      FUN_005542c0("https",5);
      uStack_8._0_1_ = 9;
      FUN_0151bcc0(auStack_160,auStack_88,param_1 + 0x60,auStack_a0,auStack_d0,auStack_b8);
      FUN_005507b0();
      FUN_005507b0();
      uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
      FUN_005507b0();
      if (DAT_01ea8d1c != '\0') {
        ppppuVar5 = apppuStack_40;
        if (0xf < uStack_2c) {
          ppppuVar5 = (undefined4 ****)apppuStack_40[0];
        }
        FUN_016774b0(DAT_01ea8d1c,"sendMessageToGameInstancesApi - postDataJson = %s",ppppuVar5);
      }
      FUN_005d2530(param_1 + 0x10);
      uVar4 = *(undefined4 *)(*(int *)(param_1 + 0x40) + 0x9c);
      uStack_48 = 0;
      uStack_44 = 0xf;
      auStack_58[0] = 0;
      FUN_005542c0("GameInstancesCreateOrUpdate",0x1b);
      uStack_8._0_1_ = 0xe;
      iVar6 = FUN_01674e20(0x18);
      uStack_8._0_1_ = 0xf;
      if (iVar6 == 0) {
        uVar7 = 0;
      }
      else {
        uVar7 = FUN_0054ef60(apppuStack_40);
      }
      uStack_8._0_1_ = 0xe;
      uStack_18 = 0;
      iStack_14 = 0;
      FUN_005ce7a0(uVar7,iVar6);
      uStack_8._0_1_ = 0x10;
      uVar7 = FUN_0151bb70(auStack_e8);
      uStack_8._0_1_ = 0x11;
      FUN_005d2c20(param_1 + 0x18,uVar7,&uStack_18,param_1 + 0x10,0,auStack_58,uVar4);
      FUN_005507b0();
      FUN_00550b30();
      FUN_005507b0();
      FUN_0056d9d0();
      FUN_005507b0();
      FUN_005507b0();
      goto LAB_005da410;
    }
    if (DAT_01d596f0 == '\0') goto LAB_005da410;
    pcVar9 = "ERROR (sendMessageToGameInstancesApi) - Server or RunService are unexpectedly null.";
  }
  FUN_016774b0(DAT_01d596f0,pcVar9,0);
LAB_005da410:
  if (piStack_5c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_5c[1] + -1;
    piStack_5c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_5c)();
      LOCK();
      piVar1 = piStack_5c + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piStack_5c + 4))();
      }
    }
  }
  uStack_8 = 0x12;
  FUN_0152dda0(uStack_28,uStack_24,uStack_68);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5532 ; VA 0x005da4c0 ; FUN_005da4c0 */

void __thiscall FUN_005da4c0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  uint *puVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 ****ppppuVar5;
  int iVar6;
  undefined4 uVar7;
  undefined8 uVar8;
  char *pcVar9;
  undefined auStack_160 [120];
  undefined auStack_e8 [24];
  undefined auStack_d0 [24];
  undefined auStack_b8 [16];
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined auStack_a0 [16];
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined auStack_88 [16];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 uStack_68;
  int iStack_60;
  int *piStack_5c;
  undefined auStack_58 [16];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 ***apppuStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a7d5;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8dc8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ea8dc8);
    if (DAT_01ea8dc8 == -1) {
      uStack_8 = 0;
      uVar8 = FUN_0152dab0(&DAT_018c5904,"Games Service Reporting",0xffffffff);
      DAT_01ea8dc4 = (undefined4)((ulonglong)uVar8 >> 0x20);
      DAT_01ea8dc0 = (undefined4)uVar8;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ea8dc8);
    }
  }
  uStack_28 = DAT_01ea8dc0;
  uStack_70 = DAT_01ea8dc0;
  uStack_24 = DAT_01ea8dc4;
  uStack_6c = DAT_01ea8dc4;
  uStack_68 = FUN_0152d930(DAT_01ea8dc0,DAT_01ea8dc4);
  uStack_8 = 1;
  if (DAT_01ea8d1c != '\0') {
    FUN_016774b0(DAT_01ea8d1c,"- sendMessageToGamesApi -",0);
  }
  FUN_00587490(&iStack_60);
  uStack_8._0_1_ = 2;
  if (iStack_60 == 0) {
    if (DAT_01d596f0 == '\0') goto LAB_005da840;
    pcVar9 = "ERROR (sendMessageToGamesApi) - DataModel is unexpectedly null.";
  }
  else {
    iStack_20 = FUN_00562e40();
    iStack_14 = FUN_00562d80();
    uVar3 = uStack_1c;
    if ((iStack_20 != 0) && (iStack_14 != 0)) {
      uStack_1c = uStack_1c & 0xffffff00;
      if (*(int *)(iStack_60 + 0x1b8) != 0) {
        uStack_1c = CONCAT31(SUB43(uVar3,1),*(undefined *)(*(int *)(iStack_60 + 0x1b8) + 0x300));
      }
      uStack_30 = 0;
      uStack_2c = 0xf;
      apppuStack_40[0] = (undefined4 ***)((uint)apppuStack_40[0] & 0xffffff00);
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      if (DAT_01d593c8 == '\0') {
        uVar4 = FUN_005d5040(auStack_58);
      }
      else {
        uVar4 = FUN_005d48e0(auStack_58,param_2);
      }
      FUN_005511f0(uVar4);
      FUN_005507b0();
      puVar2 = (uint *)(param_1 + 0xd8);
      uVar3 = *puVar2;
      *puVar2 = *puVar2 + 1;
      *(int *)(param_1 + 0xdc) = *(int *)(param_1 + 0xdc) + (uint)(0xfffffffe < uVar3);
      FUN_005d4400(auStack_d0,iStack_20,iStack_14,param_2,param_3,uStack_1c);
      uStack_8._0_1_ = 6;
      uStack_a8 = 0;
      uStack_a4 = 0xf;
      auStack_b8[0] = 0;
      FUN_005542c0(&DAT_018bc9b8,0);
      uStack_8._0_1_ = 7;
      uStack_90 = 0;
      uStack_8c = 0xf;
      auStack_a0[0] = 0;
      FUN_005542c0("/v2.0/Refresh",0xd);
      uStack_8._0_1_ = 8;
      uStack_78 = 0;
      uStack_74 = 0xf;
      auStack_88[0] = 0;
      FUN_005542c0("https",5);
      uStack_8._0_1_ = 9;
      FUN_0151bcc0(auStack_160,auStack_88,param_1 + 0x48,auStack_a0,auStack_d0,auStack_b8);
      FUN_005507b0();
      FUN_005507b0();
      uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
      FUN_005507b0();
      if (DAT_01ea8d1c != '\0') {
        ppppuVar5 = apppuStack_40;
        if (0xf < uStack_2c) {
          ppppuVar5 = (undefined4 ****)apppuStack_40[0];
        }
        FUN_016774b0(DAT_01ea8d1c,"sendMessageToGamesApi - postDataJson = %s",ppppuVar5);
      }
      FUN_005d2530(param_1 + 8);
      uVar4 = *(undefined4 *)(*(int *)(param_1 + 0x40) + 0x9c);
      uStack_48 = 0;
      uStack_44 = 0xf;
      auStack_58[0] = 0;
      FUN_005542c0("GSMRefresh",10);
      uStack_8._0_1_ = 0xe;
      iVar6 = FUN_01674e20(0x18);
      uStack_8._0_1_ = 0xf;
      if (iVar6 == 0) {
        uVar7 = 0;
      }
      else {
        uVar7 = FUN_0054ef60(apppuStack_40);
      }
      uStack_8._0_1_ = 0xe;
      uStack_18 = 0;
      iStack_14 = 0;
      FUN_005ce7a0(uVar7,iVar6);
      uStack_8._0_1_ = 0x10;
      uVar7 = FUN_0151bb70(auStack_e8);
      uStack_8._0_1_ = 0x11;
      FUN_005d2c20(param_1 + 0x18,uVar7,&uStack_18,param_1 + 8,0,auStack_58,uVar4);
      FUN_005507b0();
      FUN_00550b30();
      FUN_005507b0();
      FUN_0056d9d0();
      FUN_005507b0();
      FUN_005507b0();
      goto LAB_005da840;
    }
    if (DAT_01d596f0 == '\0') goto LAB_005da840;
    pcVar9 = "ERROR (sendMessageToGamesApi) - Server or RunService are unexpectedly null.";
  }
  FUN_016774b0(DAT_01d596f0,pcVar9,0);
LAB_005da840:
  if (piStack_5c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_5c[1] + -1;
    piStack_5c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_5c)();
      LOCK();
      piVar1 = piStack_5c + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piStack_5c + 4))();
      }
    }
  }
  uStack_8 = 0x12;
  FUN_0152dda0(uStack_28,uStack_24,uStack_68);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5533 ; VA 0x005da8f0 ; FUN_005da8f0 */

void __fastcall FUN_005da8f0(int param_1)

{
  int *piVar1;
  int iVar2;
  
  *(undefined4 *)(param_1 + 0x18) = 0;
  piVar1 = *(int **)(param_1 + 0x1c);
  *(undefined4 *)(param_1 + 0x1c) = 0;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_005d2530(param_1 + 8);
  FUN_005d2530(param_1 + 0x10);
  return;
}



/* FUNCTION 5534 ; VA 0x005da930 ; FUN_005da930 */

uint FUN_005da930(undefined4 param_1)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  uint uVar8;
  undefined8 uVar9;
  char *pcVar10;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a7f0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01ea8d1c != 0) {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ea8d1c,"RCCMonitoring::teamCreateSaveOnZeroPlayers started.",0);
  }
  FUN_00587490(&iStack_28);
  uStack_8 = 0;
  if (iStack_28 == 0) {
    uVar8 = (uint)DAT_01d596f0;
    if (DAT_01d596f0 == 0) goto LAB_005dab6b;
    pcVar10 = 
    "RCCMonitoring::teamCreateSaveOnZeroPlayers did early return due to invalid DataModel.";
  }
  else {
    iVar5 = FUN_005cf750();
    if (iVar5 == 0) {
      uVar8 = (uint)DAT_01d596f0;
      if (DAT_01d596f0 == 0) goto LAB_005dab6b;
      pcVar10 = 
      "RCCMonitoring::teamCreateSaveOnZeroPlayers did early return due to invalid Players object.";
    }
    else {
      if ((*(int **)(iVar5 + 0xb8))[1] - **(int **)(iVar5 + 0xb8) < 8) {
        if (DAT_01d65a50 != '\0') {
          if (iStack_28 == -0xc) {
            iVar5 = 0;
          }
          else {
            FUN_005789c0(&DAT_01ea8dfc,&LAB_005cf1d0);
            uVar6 = FUN_005cf580();
            piVar7 = (int *)FUN_008aa140(uVar6);
            uStack_18 = CONCAT44(piVar7,(undefined4)uStack_18);
            if (*piVar7 == 0) {
              uVar6 = FUN_009ef740();
              piVar7 = (int *)FUN_008a9ba0(&iStack_20,uVar6);
              iVar5 = *piVar7;
              iVar3 = piVar7[1];
              *piVar7 = 0;
              piVar7[1] = 0;
              *uStack_18._4_4_ = iVar5;
              piVar7 = (int *)uStack_18._4_4_[1];
              uStack_18._4_4_[1] = iVar3;
              if (piVar7 != (int *)0x0) {
                LOCK();
                iVar5 = piVar7[1] + -1;
                piVar7[1] = iVar5;
                UNLOCK();
                if (iVar5 == 0) {
                  (**(code **)*piVar7)();
                  LOCK();
                  iVar5 = piVar7[2] + -1;
                  piVar7[2] = iVar5;
                  UNLOCK();
                  if (iVar5 == 0) {
                    (**(code **)(*piVar7 + 4))();
                  }
                }
              }
              piVar7 = uStack_18._4_4_;
              if (piStack_1c != (int *)0x0) {
                LOCK();
                iVar5 = piStack_1c[1] + -1;
                piStack_1c[1] = iVar5;
                UNLOCK();
                if (iVar5 == 0) {
                  (**(code **)*piStack_1c)();
                  LOCK();
                  iVar5 = piStack_1c[2] + -1;
                  piStack_1c[2] = iVar5;
                  UNLOCK();
                  if (iVar5 == 0) {
                    (**(code **)(*piStack_1c + 4))();
                  }
                }
                piVar7 = uStack_18._4_4_;
              }
            }
            iVar5 = *piVar7;
          }
          if ((9999 < DAT_01ee5c3c) || ((iVar5 != 0 && (*(char *)(iVar5 + 0xee) != '\0')))) {
            FUN_00562c90(&iStack_20,param_1);
            uStack_8 = CONCAT31(uStack_8._1_3_,1);
            if (iStack_20 == 0) {
              uStack_18 = 0;
              uVar9 = 0;
            }
            else {
              uVar9 = FUN_00928340();
            }
            FUN_005ea890(&uStack_18,uVar9);
            if ((uStack_18._4_1_ != '\0') && (DAT_01ea8d1c != 0)) {
              FUN_016774b0(DAT_01ea8d1c,
                           "RCCMonitoring::teamCreateSaveOnZeroPlayers TeamCreate DataModel saved with place version number = %d."
                           ,(undefined4)uStack_18);
            }
            uStack_8 = uStack_8 & 0xffffff00;
            FUN_00550b30();
            goto LAB_005dab4f;
          }
        }
        cVar4 = FUN_005e6850(0,0,0);
        if (cVar4 != '\0') {
          uVar8 = (uint)DAT_01ea8d1c;
          if (DAT_01ea8d1c == 0) goto LAB_005dab6b;
          FUN_016774b0(DAT_01ea8d1c,
                       "RCCMonitoring::teamCreateSaveOnZeroPlayers TeamCreate DataModel saved.",0);
        }
      }
LAB_005dab4f:
      uVar8 = (uint)DAT_01ea8d1c;
      if (DAT_01ea8d1c == 0) goto LAB_005dab6b;
      pcVar10 = "RCCMonitoring::teamCreateSaveOnZeroPlayers finished.";
    }
  }
  uVar8 = FUN_016774b0(uVar8,pcVar10,0);
LAB_005dab6b:
  if (piStack_24 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_24 + 1);
    uVar2 = *puVar1;
    uVar8 = *puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      uVar8 = (**(code **)*piStack_24)();
      LOCK();
      piVar7 = piStack_24 + 2;
      iVar5 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        uVar8 = (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 5535 ; VA 0x005dabb0 ; FUN_005dabb0 */

void FUN_005dabb0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int aiStack_40 [5];
  uint uStack_2c;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a810;
  pvStack_10 = ExceptionList;
  puVar1 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar1 = (undefined4 *)*param_1;
  }
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675640(aiStack_28,"RCCMonitoring_%s",puVar1);
  uStack_8 = 0;
  FUN_008783f0(uVar2,1,0);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    iVar3 = aiStack_28[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_28[0] + -4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  uVar2 = FUN_01675640(aiStack_40,"RCCMonitoring_%s_%d",param_1,param_2);
  uStack_8 = 1;
  FUN_008783f0(uVar2,1,0);
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    iVar3 = aiStack_40[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_40[0] + -4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5536 ; VA 0x005dacb0 ; FUN_005dacb0 */

int * FUN_005dacb0(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a828;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00562c90(&piStack_18,param_1);
  uStack_8 = 0;
  if ((piStack_18 != (int *)0x0) &&
     (piStack_18 = (int *)FUN_0065b150(piStack_18), piStack_18 != (int *)0x0)) {
    piStack_18 = (int *)(**(code **)(*piStack_18 + 0x234))();
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    piStack_18 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_18 = (int *)(**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_18 = (int *)(**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piStack_18;
}



/* FUNCTION 5537 ; VA 0x005dad40 ; FUN_005dad40 */

void __thiscall FUN_005dad40(int param_1,undefined4 param_2,char param_3)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined uVar5;
  char *pcVar6;
  undefined4 ****ppppuVar7;
  undefined4 *****pppppuVar8;
  code *pcStack_1a0;
  undefined4 ***pppuStack_19c;
  undefined4 ****ppppuStack_198;
  undefined4 ****ppppuStack_194;
  undefined4 ****ppppuStack_190;
  undefined8 uStack_18c;
  undefined auStack_178 [120];
  undefined uStack_100;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined uStack_d0;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined uStack_b8;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined uStack_a0;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 ****appppuStack_88 [4];
  undefined4 uStack_78;
  uint uStack_74;
  undefined4 ***apppuStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  undefined4 ***apppuStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  undefined4 ****appppuStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 ****appppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a8b9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01ea8d1c != 0) {
    uStack_18c._4_4_ = (undefined4 *****)0x0;
    ppppuStack_190 = (undefined4 ****)(uint)DAT_01ea8d1c;
    uStack_18c._0_4_ = "- updatePresence -";
    ppppuStack_194 = (undefined4 ****)0x5dad7c;
    ExceptionList = &pvStack_10;
    FUN_016774b0();
  }
  uStack_f0 = 0;
  uStack_ec = 0xf;
  uStack_100 = 0;
  uStack_d8 = 0;
  uStack_d4 = 0xf;
  uStack_e8 = 0;
  uStack_c0 = 0;
  uStack_bc = 0xf;
  uStack_d0 = 0;
  uStack_a8 = 0;
  uStack_a4 = 0xf;
  uStack_b8 = 0;
  uStack_90 = 0;
  uStack_8c = 0xf;
  uStack_a0 = 0;
  uStack_8 = 0;
  uStack_18c._4_4_ = (undefined4 *****)0x5dae17;
  uStack_18c = FUN_00928340();
  ppppuStack_194 = appppuStack_88;
  ppppuStack_190 = (undefined4 ****)0x18c5f7c;
  ppppuStack_198 = (undefined4 ****)0x5dae2a;
  FUN_01675640();
  uStack_8._0_1_ = 1;
  if (param_3 == '\0') {
    iVar2 = *(int *)(*(int *)(param_1 + 0x40) + 0x10);
    if ((iVar2 == 3) || (uStack_18c._0_4_ = "Game", iVar2 == 4)) {
      uStack_18c._0_4_ = "CloudEdit";
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    appppuStack_40[0] = (undefined4 ****)((uint)appppuStack_40[0]._1_3_ << 8);
    pcVar6 = (char *)uStack_18c;
    do {
      cVar1 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar1 != '\0');
    uStack_18c._4_4_ = (undefined4 *****)((int)pcVar6 - (int)((char *)uStack_18c + 1));
    ppppuStack_190 = (undefined4 ****)0x5db003;
    FUN_005542c0();
    puVar3 = *(undefined4 **)(param_1 + 0x40);
    uStack_18c._0_4_ = (char *)(puVar3 + 0x12);
    uStack_8._0_1_ = 5;
    uStack_18c._4_4_ = appppuStack_40;
    if (0xf < uStack_2c) {
      uStack_18c._4_4_ = (undefined4 *****)appppuStack_40[0];
    }
    if (0xf < (uint)puVar3[0x17]) {
      uStack_18c._0_4_ = *(char **)(char *)uStack_18c;
    }
    ppppuStack_190 = (undefined4 ****)puVar3[1];
    pppuStack_19c = apppuStack_70;
    ppppuStack_194 = (undefined4 ****)*puVar3;
    ppppuStack_198 = (undefined4 ****)0x18c5fa0;
    pcStack_1a0 = (code *)0x5db035;
    uStack_18c._0_4_ = (char *)FUN_01675640();
    uStack_18c._4_4_ = *(undefined4 ******)((int)(char *)uStack_18c + 0x10);
    uStack_8._0_1_ = 6;
    if (0xf < *(uint *)((int)(char *)uStack_18c + 0x14)) {
      uStack_18c._0_4_ = *(char **)(char *)uStack_18c;
    }
    ppppuStack_190 = (undefined4 ****)0x5db054;
    FUN_00554150();
    uStack_8._0_1_ = 5;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 5;
    if (0xf < uStack_5c) {
      uStack_18c._4_4_ = (undefined4 *****)(uStack_5c + 1);
      ppppuVar7 = (undefined4 ****)apppuStack_70[0];
      if (0xfff < uStack_18c._4_4_) {
        ppppuVar7 = (undefined4 ****)apppuStack_70[0][-1];
        uStack_18c._4_4_ = (undefined4 *****)(uStack_5c + 0x24);
        if (0x1f < (uint)((int)apppuStack_70[0] + (-4 - (int)ppppuVar7))) {
                    /* WARNING: Subroutine does not return */
          uStack_18c._4_4_ = (undefined4 *****)0x5db44f;
          uStack_8._0_1_ = uVar5;
          FUN_017167a3();
        }
      }
      ppppuStack_190 = (undefined4 ****)0x5db089;
      uStack_18c._0_4_ = (char *)ppppuVar7;
      FUN_01674ea0();
    }
    uStack_18c._4_4_ = (undefined4 *****)0x0;
    uStack_18c._0_4_ = &DAT_018bc9b8;
    uStack_60 = 0;
    uStack_5c = 0xf;
    apppuStack_70[0] = (undefined4 ***)((uint)apppuStack_70[0] & 0xffffff00);
    ppppuStack_190 = (undefined4 ****)0x5db0ad;
    FUN_005542c0();
    uStack_18c._4_4_ = (undefined4 *****)0x20;
    uStack_18c._0_4_ = "/presence/register-game-presence";
    uStack_8._0_1_ = 7;
    uStack_48 = 0;
    uStack_44 = 0xf;
    apppuStack_58[0] = (undefined4 ***)((uint)apppuStack_58[0] & 0xffffff00);
    ppppuStack_190 = (undefined4 ****)0x5db0d2;
    FUN_005542c0();
    uStack_18c._4_4_ = (undefined4 *****)0x5;
    uStack_18c._0_4_ = "https";
    uStack_8._0_1_ = 8;
    uStack_18 = 0;
    uStack_14 = 0xf;
    appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0] & 0xffffff00);
    ppppuStack_190 = (undefined4 ****)0x5db0f7;
    FUN_005542c0();
    uStack_18c._4_4_ = (undefined4 *****)apppuStack_70;
    uStack_8._0_1_ = 9;
    uStack_18c._0_4_ = (char *)appppuStack_88;
    ppppuStack_190 = apppuStack_58;
    ppppuStack_194 = (undefined4 ****)(param_1 + 0x90);
    ppppuStack_198 = appppuStack_28;
    pppuStack_19c = (undefined4 ***)auStack_178;
    pcStack_1a0 = (code *)0x5db121;
    uStack_18c._4_4_ = (undefined4 *****)FUN_0151bcc0();
    uStack_18c._0_4_ = (char *)0x5db130;
    FUN_005d1360();
    uStack_18c._4_4_ = (undefined4 *****)0x5db13b;
    FUN_0056d9d0();
    uStack_8._0_1_ = 8;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (0xf < uStack_14) {
      uStack_18c._4_4_ = (undefined4 *****)(uStack_14 + 1);
      ppppuVar7 = appppuStack_28[0];
      if (0xfff < uStack_18c._4_4_) {
        ppppuVar7 = (undefined4 ****)appppuStack_28[0][-1];
        uStack_18c._4_4_ = (undefined4 *****)(uStack_14 + 0x24);
        if (0x1f < (uint)((int)appppuStack_28[0] + (-4 - (int)ppppuVar7))) {
                    /* WARNING: Subroutine does not return */
          uStack_18c._4_4_ = (undefined4 *****)0x5db454;
          uStack_8._0_1_ = uVar5;
          FUN_017167a3();
        }
      }
      ppppuStack_190 = (undefined4 ****)0x5db170;
      uStack_18c._0_4_ = (char *)ppppuVar7;
      FUN_01674ea0();
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0] & 0xffffff00);
    uStack_8._0_1_ = 7;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 7;
    if (0xf < uStack_44) {
      uStack_18c._4_4_ = (undefined4 *****)(uStack_44 + 1);
      ppppuVar7 = (undefined4 ****)apppuStack_58[0];
      if (0xfff < uStack_18c._4_4_) {
        ppppuVar7 = (undefined4 ****)apppuStack_58[0][-1];
        uStack_18c._4_4_ = (undefined4 *****)(uStack_44 + 0x24);
        if (0x1f < (uint)((int)apppuStack_58[0] + (-4 - (int)ppppuVar7))) {
                    /* WARNING: Subroutine does not return */
          uStack_18c._4_4_ = (undefined4 *****)0x5db459;
          uStack_8._0_1_ = uVar5;
          FUN_017167a3();
        }
      }
      ppppuStack_190 = (undefined4 ****)0x5db1ba;
      uStack_18c._0_4_ = (char *)ppppuVar7;
      FUN_01674ea0();
    }
    uStack_48 = 0;
    uStack_44 = 0xf;
    apppuStack_58[0] = (undefined4 ***)((uint)apppuStack_58[0] & 0xffffff00);
    uStack_8._0_1_ = 5;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 5;
    if (0xf < uStack_5c) {
      uStack_18c._4_4_ = (undefined4 *****)(uStack_5c + 1);
      ppppuVar7 = (undefined4 ****)apppuStack_70[0];
      if (0xfff < uStack_18c._4_4_) {
        ppppuVar7 = (undefined4 ****)apppuStack_70[0][-1];
        uStack_18c._4_4_ = (undefined4 *****)(uStack_5c + 0x24);
        if (0x1f < (uint)((int)apppuStack_70[0] + (-4 - (int)ppppuVar7))) {
                    /* WARNING: Subroutine does not return */
          uStack_18c._4_4_ = (undefined4 *****)0x5db45e;
          uStack_8._0_1_ = uVar5;
          FUN_017167a3();
        }
      }
      ppppuStack_190 = (undefined4 ****)0x5db204;
      uStack_18c._0_4_ = (char *)ppppuVar7;
      FUN_01674ea0();
    }
    uStack_8._0_1_ = 1;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (uStack_2c < 0x10) goto LAB_005db23f;
    uStack_18c._4_4_ = (undefined4 *****)(uStack_2c + 1);
    pppppuVar8 = (undefined4 *****)appppuStack_40[0];
    if (0xfff < uStack_18c._4_4_) {
      pppppuVar8 = (undefined4 *****)appppuStack_40[0][-1];
      uStack_18c._4_4_ = (undefined4 *****)(uStack_2c + 0x24);
      if (0x1f < (uint)((int)appppuStack_40[0] + (-4 - (int)pppppuVar8))) {
                    /* WARNING: Subroutine does not return */
        uStack_18c._4_4_ = (undefined4 *****)0x5db463;
        uStack_8._0_1_ = uVar5;
        FUN_017167a3();
      }
    }
  }
  else {
    uStack_18c._4_4_ = (undefined4 *****)0x0;
    uStack_18c._0_4_ = &DAT_018bc9b8;
    uStack_30 = 0;
    uStack_2c = 0xf;
    appppuStack_40[0] = (undefined4 ****)((uint)appppuStack_40[0]._1_3_ << 8);
    ppppuStack_190 = (undefined4 ****)0x5dae5c;
    FUN_005542c0();
    uStack_18c._4_4_ = (undefined4 *****)0x1a;
    uStack_18c._0_4_ = "/presence/register-absence";
    uStack_8._0_1_ = 2;
    uStack_18 = 0;
    uStack_14 = 0xf;
    appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0] & 0xffffff00);
    ppppuStack_190 = (undefined4 ****)0x5dae81;
    FUN_005542c0();
    uStack_18c._4_4_ = (undefined4 *****)0x5;
    uStack_18c._0_4_ = "https";
    uStack_8._0_1_ = 3;
    uStack_48 = 0;
    uStack_44 = 0xf;
    apppuStack_58[0] = (undefined4 ***)((uint)apppuStack_58[0] & 0xffffff00);
    ppppuStack_190 = (undefined4 ****)0x5daea6;
    FUN_005542c0();
    uStack_18c._4_4_ = appppuStack_40;
    uStack_8._0_1_ = 4;
    uStack_18c._0_4_ = (char *)appppuStack_88;
    ppppuStack_190 = appppuStack_28;
    ppppuStack_194 = (undefined4 ****)(param_1 + 0x90);
    ppppuStack_198 = apppuStack_58;
    pppuStack_19c = (undefined4 ***)auStack_178;
    pcStack_1a0 = (code *)0x5daed0;
    uStack_18c._4_4_ = (undefined4 *****)FUN_0151bcc0();
    uStack_18c._0_4_ = (char *)0x5daedf;
    FUN_005d1360();
    uStack_18c._4_4_ = (undefined4 *****)0x5daeea;
    FUN_0056d9d0();
    uStack_8._0_1_ = 3;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_44) {
      uStack_18c._4_4_ = (undefined4 *****)(uStack_44 + 1);
      ppppuVar7 = (undefined4 ****)apppuStack_58[0];
      if (0xfff < uStack_18c._4_4_) {
        ppppuVar7 = (undefined4 ****)apppuStack_58[0][-1];
        uStack_18c._4_4_ = (undefined4 *****)(uStack_44 + 0x24);
        if (0x1f < (uint)((int)apppuStack_58[0] + (-4 - (int)ppppuVar7))) {
                    /* WARNING: Subroutine does not return */
          uStack_18c._4_4_ = (undefined4 *****)0x5db440;
          uStack_8._0_1_ = uVar5;
          FUN_017167a3();
        }
      }
      ppppuStack_190 = (undefined4 *****)0x5daf1f;
      uStack_18c._0_4_ = (char *)ppppuVar7;
      FUN_01674ea0();
    }
    uStack_48 = 0;
    uStack_44 = 0xf;
    apppuStack_58[0] = (undefined4 ***)((uint)apppuStack_58[0] & 0xffffff00);
    uStack_8._0_1_ = 2;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 2;
    if (0xf < uStack_14) {
      uStack_18c._4_4_ = (undefined4 *****)(uStack_14 + 1);
      ppppuVar7 = appppuStack_28[0];
      if (0xfff < uStack_18c._4_4_) {
        ppppuVar7 = (undefined4 ****)appppuStack_28[0][-1];
        uStack_18c._4_4_ = (undefined4 *****)(uStack_14 + 0x24);
        if (0x1f < (uint)((int)appppuStack_28[0] + (-4 - (int)ppppuVar7))) {
                    /* WARNING: Subroutine does not return */
          uStack_18c._4_4_ = (undefined4 *****)0x5db445;
          uStack_8._0_1_ = uVar5;
          FUN_017167a3();
        }
      }
      ppppuStack_190 = (undefined4 *****)0x5daf69;
      uStack_18c._0_4_ = (char *)ppppuVar7;
      FUN_01674ea0();
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0] & 0xffffff00);
    uStack_8._0_1_ = 1;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (uStack_2c < 0x10) goto LAB_005db23f;
    uStack_18c._4_4_ = (undefined4 *****)(uStack_2c + 1);
    pppppuVar8 = (undefined4 *****)appppuStack_40[0];
    if (0xfff < uStack_18c._4_4_) {
      pppppuVar8 = (undefined4 *****)appppuStack_40[0][-1];
      uStack_18c._4_4_ = (undefined4 *****)(uStack_2c + 0x24);
      if (0x1f < (uint)((int)appppuStack_40[0] + (-4 - (int)pppppuVar8))) {
                    /* WARNING: Subroutine does not return */
        uStack_18c._4_4_ = (undefined4 *****)0x5db44a;
        uStack_8._0_1_ = uVar5;
        FUN_017167a3();
      }
    }
  }
  uStack_8._0_1_ = 1;
  ppppuStack_190 = (undefined4 ****)0x5db23c;
  uStack_18c._0_4_ = (char *)pppppuVar8;
  FUN_01674ea0();
LAB_005db23f:
  uStack_18c._4_4_ = (undefined4 *****)0x10;
  uStack_18c._0_4_ = "ApiProxyPresence";
  uVar4 = *(undefined4 *)(*(int *)(param_1 + 0x40) + 0x9c);
  uStack_30 = 0;
  uStack_2c = 0xf;
  appppuStack_40[0] = (undefined4 ****)((uint)appppuStack_40[0] & 0xffffff00);
  ppppuStack_190 = (undefined4 ****)0x5db269;
  FUN_005542c0();
  uStack_18c._4_4_ = appppuStack_28;
  uStack_8._0_1_ = 10;
  uStack_18c._0_4_ = "j";
  ppppuStack_190 = (undefined4 ****)FUN_0151bb70();
  uStack_18c._4_4_ = (undefined4 *****)0x0;
  uStack_18c._0_4_ = (char *)0x0;
  uStack_8._0_1_ = 0xb;
  ppppuStack_194 = (undefined4 ****)0x5db290;
  FUN_014cc090();
  uStack_8._0_1_ = 0xc;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xc;
  if (DAT_01d5a4c0 == '\0') {
    uStack_18c._4_4_ = (undefined4 *****)0x0;
    uStack_18c._0_4_ = &DAT_018bc9b8;
    uStack_60 = 0;
    uStack_5c = 0xf;
    apppuStack_70[0] = (undefined4 ***)((uint)apppuStack_70[0] & 0xffffff00);
    ppppuStack_190 = (undefined4 ****)0x5db2c2;
    FUN_005542c0();
    uStack_18c._4_4_ = (undefined4 *****)0x0;
    uStack_8._0_1_ = 0xd;
    FUN_005d6520(&pcStack_1a0,&pcStack_1a0,2);
    pcStack_1a0 = FUN_005d5bd0;
    FUN_014cd990(apppuStack_70,&DAT_01d79f68,0);
    uStack_8._0_1_ = 0xc;
    uVar5 = (undefined)uStack_8;
    if (0xf < uStack_5c) {
      uStack_18c._4_4_ = (undefined4 *****)(uStack_5c + 1);
      ppppuVar7 = (undefined4 ****)apppuStack_70[0];
      if (0xfff < uStack_18c._4_4_) {
        ppppuVar7 = (undefined4 ****)apppuStack_70[0][-1];
        uStack_18c._4_4_ = (undefined4 *****)(uStack_5c + 0x24);
        if (0x1f < (uint)((int)apppuStack_70[0] + (-4 - (int)ppppuVar7))) {
                    /* WARNING: Subroutine does not return */
          uStack_18c._4_4_ = (undefined4 *****)0x5db468;
          FUN_017167a3();
        }
      }
      ppppuStack_190 = (undefined4 ****)0x5db340;
      uStack_18c._0_4_ = (char *)ppppuVar7;
      FUN_01674ea0();
      uVar5 = (undefined)uStack_8;
    }
  }
  uStack_8._0_1_ = uVar5;
  uStack_18c._0_4_ = (char *)appppuStack_40;
  ppppuStack_190 = (undefined4 ****)0x5db34d;
  uStack_18c._4_4_ = (undefined4 *****)uVar4;
  FUN_005dabb0();
  uStack_18c._4_4_ = (undefined4 *****)0x5db35b;
  FUN_0056db40();
  if (0xf < uStack_14) {
    uStack_18c._4_4_ = (undefined4 *****)(uStack_14 + 1);
    pppppuVar8 = (undefined4 *****)appppuStack_28[0];
    if (0xfff < uStack_18c._4_4_) {
      pppppuVar8 = (undefined4 *****)appppuStack_28[0][-1];
      uStack_18c._4_4_ = (undefined4 *****)(uStack_14 + 0x24);
      if (0x1f < (uint)((int)appppuStack_28[0] + (-4 - (int)pppppuVar8))) {
                    /* WARNING: Subroutine does not return */
        uStack_18c._4_4_ = (undefined4 *****)0x5db46d;
        FUN_017167a3();
      }
    }
    ppppuStack_190 = (undefined4 ****)0x5db38c;
    uStack_18c._0_4_ = (char *)pppppuVar8;
    FUN_01674ea0();
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0] & 0xffffff00);
  if (0xf < uStack_2c) {
    uStack_18c._4_4_ = (undefined4 *****)(uStack_2c + 1);
    pppppuVar8 = (undefined4 *****)appppuStack_40[0];
    if (0xfff < uStack_18c._4_4_) {
      pppppuVar8 = (undefined4 *****)appppuStack_40[0][-1];
      uStack_18c._4_4_ = (undefined4 *****)(uStack_2c + 0x24);
      if (0x1f < (uint)((int)appppuStack_40[0] + (-4 - (int)pppppuVar8))) {
                    /* WARNING: Subroutine does not return */
        uStack_18c._4_4_ = (undefined4 *****)0x5db472;
        FUN_017167a3();
      }
    }
    ppppuStack_190 = (undefined4 ****)0x5db3d2;
    uStack_18c._0_4_ = (char *)pppppuVar8;
    FUN_01674ea0();
  }
  if (0xf < uStack_74) {
    uStack_18c._4_4_ = (undefined4 *****)(uStack_74 + 1);
    pppppuVar8 = (undefined4 *****)appppuStack_88[0];
    if (0xfff < uStack_18c._4_4_) {
      pppppuVar8 = (undefined4 *****)appppuStack_88[0][-1];
      uStack_18c._4_4_ = (undefined4 *****)(uStack_74 + 0x24);
      if (0x1f < (uint)((int)appppuStack_88[0] + (-4 - (int)pppppuVar8))) {
                    /* WARNING: Subroutine does not return */
        uStack_18c._4_4_ = (undefined4 *****)&UNK_005db477;
        FUN_017167a3();
      }
    }
    ppppuStack_190 = (undefined4 ****)0x5db405;
    uStack_18c._0_4_ = (char *)pppppuVar8;
    FUN_01674ea0();
  }
  uStack_78 = 0;
  uStack_74 = 0xf;
  appppuStack_88[0] = (undefined4 ****)((uint)appppuStack_88[0] & 0xffffff00);
  uStack_18c._4_4_ = (undefined4 *****)0x5db428;
  FUN_0056d9d0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5538 ; VA 0x005db480 ; FUN_005db480 */

int __thiscall FUN_005db480(int *param_1,int param_2,undefined4 param_3,undefined4 *param_4)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a8d0;
  pvStack_10 = ExceptionList;
  iVar3 = *param_1;
  iVar2 = param_1[1] - iVar3 >> 5;
  if (iVar2 == 0x7ffffff) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar2 + 1;
  uVar6 = param_1[2] - iVar3 >> 5;
  uVar7 = uVar1;
  if ((uVar6 <= 0x7ffffff - (uVar6 >> 1)) && (uVar7 = (uVar6 >> 1) + uVar6, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00577f40(uVar7);
  uStack_8 = 0;
  iVar3 = (param_2 - iVar3 >> 5) * 0x20;
  iVar4 = iVar3 + iVar2;
  FUN_0054ef60(param_3);
  *(undefined4 *)(iVar4 + 0x18) = *param_4;
  *(undefined4 *)(iVar4 + 0x1c) = param_4[1];
  if (param_2 == param_1[1]) {
    FUN_005db610(*param_1,param_1[1],iVar2,param_1);
  }
  else {
    FUN_005db610(*param_1,param_2,iVar2,param_1);
    FUN_005db610(param_2,param_1[1],iVar4 + 0x20,param_1);
  }
  if (*param_1 != 0) {
    FUN_00559500(*param_1,param_1[1],param_1);
    iVar4 = *param_1;
    uVar6 = param_1[2] - iVar4 & 0xffffffe0;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *param_1 = iVar2;
  param_1[1] = uVar1 * 0x20 + iVar2;
  param_1[2] = uVar7 * 0x20 + iVar2;
  ExceptionList = pvStack_10;
  return *param_1 + iVar3;
}



/* FUNCTION 5539 ; VA 0x005db5d8 ; Catch_All@005db5d8 */

void Catch_All_005db5d8(void)

{
  int unaff_EBP;
  
  FUN_00576250(*(undefined4 *)(unaff_EBP + -0x1c),*(undefined4 *)(unaff_EBP + -0x1c));
  FUN_0057d2b0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5540 ; VA 0x005db610 ; FUN_005db610 */

undefined4 *
FUN_005db610(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  
  puVar6 = param_3;
  if (param_1 != param_2) {
    puVar5 = param_1 + 5;
    do {
      puVar6[4] = 0;
      *(undefined4 *)((int)param_3 + (-0x20 - (int)param_1) + (int)(puVar5 + 8)) = 0;
      uVar2 = puVar5[-4];
      uVar3 = puVar5[-3];
      uVar4 = puVar5[-2];
      *puVar6 = puVar5[-5];
      puVar6[1] = uVar2;
      puVar6[2] = uVar3;
      puVar6[3] = uVar4;
      *(undefined8 *)(puVar6 + 4) = *(undefined8 *)(puVar5 + -1);
      puVar5[-1] = 0;
      *puVar5 = 0xf;
      *(undefined *)(puVar5 + -5) = 0;
      puVar6[6] = puVar5[1];
      puVar6[7] = puVar5[2];
      puVar1 = puVar5 + 3;
      puVar6 = puVar6 + 8;
      puVar5 = puVar5 + 8;
    } while (puVar1 != param_2);
  }
  FUN_00559500(puVar6,puVar6,param_4);
  return puVar6;
}



/* FUNCTION 5541 ; VA 0x005db690 ; FUN_005db690 */

int * __thiscall FUN_005db690(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a8e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar3 = param_2[1] - *param_2 >> 5;
  if (uVar3 != 0) {
    if (0x7ffffff < uVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar2 = FUN_00577f40(uVar3);
    *param_1 = iVar2;
    param_1[1] = iVar2;
    param_1[2] = uVar3 * 0x20 + *param_1;
    iVar1 = param_2[1];
    iVar4 = *param_2;
    uStack_8 = 1;
    for (; iVar4 != iVar1; iVar4 = iVar4 + 0x20) {
      FUN_0054ef60(iVar4);
      *(undefined4 *)(iVar2 + 0x18) = *(undefined4 *)(iVar4 + 0x18);
      *(undefined4 *)(iVar2 + 0x1c) = *(undefined4 *)(iVar4 + 0x1c);
      iVar2 = iVar2 + 0x20;
    }
    FUN_00559500(iVar2,iVar2,param_1);
    param_1[1] = iVar2;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5542 ; VA 0x005db760 ; Catch_All@005db760 */

void Catch_All_005db760(void)

{
  FUN_0056d440();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5543 ; VA 0x005db780 ; FUN_005db780 */

void __fastcall FUN_005db780(undefined4 *param_1)

{
  FUN_00559500(*param_1,param_1[1],param_1[2]);
  return;
}



/* FUNCTION 5544 ; VA 0x005db7a0 ; FUN_005db7a0 */

/* WARNING: Removing unreachable block (ram,0x005db844) */
/* WARNING: Removing unreachable block (ram,0x005db857) */
/* WARNING: Removing unreachable block (ram,0x005db85e) */
/* WARNING: Removing unreachable block (ram,0x005db865) */

void __thiscall FUN_005db7a0(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  undefined8 uVar3;
  uint in_stack_00000018;
  int in_stack_0000001c;
  int in_stack_00000020;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar3 = CONCAT44(in_stack_00000020,in_stack_0000001c);
  puStack_c = &LAB_0179a910;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (in_stack_0000001c == 0 && in_stack_00000020 == 0) {
    ExceptionList = &pvStack_10;
    FUN_016830f0(&stack0x0000001c);
    uVar3 = FUN_01682de0();
  }
  uStack_18 = uVar3;
  FUN_00587410();
  in_stack_00000020 = *(int *)(param_1 + 0xc);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (*(int *)(param_1 + 0x10) == in_stack_00000020) {
    FUN_005db480(in_stack_00000020,&param_2,&uStack_18);
  }
  else {
    FUN_0054ef60(&param_2);
    *(undefined8 *)(in_stack_00000020 + 0x18) = uVar3;
    *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 0x20;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (0xf < in_stack_00000018) {
    uVar2 = in_stack_00000018 + 1;
    iVar1 = param_2;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_2 + -4);
      uVar2 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5545 ; VA 0x005db8c0 ; FUN_005db8c0 */

void __fastcall FUN_005db8c0(uint *param_1)

{
  uint uVar1;
  uint ***pppuVar2;
  undefined uVar3;
  uint *puVar4;
  uint uVar5;
  undefined4 ***pppuVar6;
  undefined4 ****ppppuVar7;
  undefined4 uVar8;
  uint uVar9;
  uint ****ppppuVar10;
  uint ***apppuStack_74 [4];
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  int iStack_58;
  undefined4 ***pppuStack_54;
  uint **ppuStack_50;
  uint **ppuStack_4c;
  uint **ppuStack_48;
  uint uStack_44;
  uint uStack_40;
  uint *puStack_3c;
  char cStack_38;
  uint *puStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  uint ***pppuStack_28;
  uint uStack_24;
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a938;
  pvStack_10 = ExceptionList;
  cStack_38 = '\0';
  ExceptionList = &pvStack_10;
  puStack_3c = param_1;
  puStack_34 = param_1;
  FUN_00587410();
  uVar9 = param_1[2];
  uStack_30 = param_1[3];
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  uStack_2c = 0;
  pppuStack_28 = (uint ***)0x0;
  uStack_24 = uVar9;
  if (uVar9 != uStack_30) {
    iStack_18 = 0;
    uStack_14 = 0;
    do {
      uStack_24 = uVar9;
      FUN_0054ef60(uVar9);
      uStack_20 = *(uint *)(uVar9 + 0x18);
      iStack_1c = *(int *)(uVar9 + 0x1c);
      uStack_5c = *(uint *)(uVar9 + 0x18);
      iStack_58 = *(int *)(uVar9 + 0x1c);
      uStack_8._0_1_ = 1;
      if (uStack_14 == 0 && iStack_18 == 0) {
        FUN_0086f2f0(1,"--------------------------");
        FUN_0086f2f0(1,"JOB PROFILING MEASUREMENTS");
        if (param_1[9] != 0) {
          puVar4 = param_1 + 5;
          if (0xf < param_1[10]) {
            puVar4 = (uint *)*puVar4;
          }
          FUN_0086f2f0(1,"Job Mode: %s",puVar4);
        }
        uVar9 = uStack_20;
        uStack_14 = uStack_20;
        iStack_18 = iStack_1c;
        if (param_1[0xf] != 0) {
          puVar4 = param_1 + 0xb;
          if (0xf < param_1[0x10]) {
            puVar4 = (uint *)*puVar4;
          }
          FUN_0086f2f0(1,"Job Type: %s",puVar4);
          uStack_14 = uVar9;
          iStack_18 = iStack_1c;
        }
      }
      pppuVar2 = apppuStack_74[0];
      pppuStack_28 = (uint ***)apppuStack_74;
      if (0xf < uStack_60) {
        pppuStack_28 = apppuStack_74[0];
      }
      uStack_44 = 0;
      uStack_40 = 0;
      if (uStack_64 < 0x10) {
        pppuStack_54 = (undefined4 ***)*pppuStack_28;
        ppuStack_50 = (uint **)((uint ****)pppuStack_28)[1];
        ppuStack_4c = (uint **)((uint ****)pppuStack_28)[2];
        ppuStack_48 = (uint **)((uint ****)pppuStack_28)[3];
        uVar9 = 0xf;
      }
      else {
        uVar9 = uStack_64 | 0xf;
        if (0x7fffffff < uVar9) {
          uVar9 = 0x7fffffff;
        }
        uVar1 = uVar9 + 1;
        if (uVar1 < 0x1000) {
          if (uVar1 == 0) {
            pppuStack_54 = (undefined4 ****)0x0;
          }
          else {
            pppuStack_54 = (undefined4 ***)FUN_01674e20(uVar1);
          }
        }
        else {
          uVar5 = uVar9 + 0x24;
          if (uVar5 <= uVar1) {
            uVar5 = 0xffffffff;
          }
          pppuVar6 = (undefined4 ***)FUN_01674e20(uVar5);
          uVar3 = (undefined)uStack_8;
          if (pppuVar6 == (undefined4 ***)0x0) goto LAB_005dbb8b;
          pppuStack_54 = (undefined4 ***)((int)pppuVar6 + 0x23U & 0xffffffe0);
          ((undefined4 ****)pppuStack_54)[-1] = pppuVar6;
        }
        FUN_0170c6f0(pppuStack_54,pppuStack_28,uStack_64 + 1);
      }
      ppppuVar7 = &pppuStack_54;
      if (0xf < uVar9) {
        ppppuVar7 = (undefined4 ****)pppuStack_54;
      }
      uStack_8._0_1_ = 2;
      uStack_44 = uStack_64;
      uStack_40 = uVar9;
      FUN_0086f2f0(1,"%s - %lld ms",ppppuVar7,uStack_20 - uStack_14,
                   (iStack_1c - iStack_18) - (uint)(uStack_20 < uStack_14));
      uStack_8._0_1_ = 1;
      uVar3 = (undefined)uStack_8;
      uStack_8._0_1_ = 1;
      if (0xf < uStack_40) {
        uVar9 = uStack_40 + 1;
        ppppuVar7 = (undefined4 ****)pppuStack_54;
        if (0xfff < uVar9) {
          ppppuVar7 = (undefined4 ****)pppuStack_54[-1];
          uVar9 = uStack_40 + 0x24;
          if (0x1f < (uint)((int)pppuStack_54 + (-4 - (int)ppppuVar7))) goto LAB_005dbb8b;
        }
        FUN_01674ea0(ppppuVar7,uVar9);
      }
      uStack_44 = 0;
      uStack_40 = 0xf;
      pppuStack_54 = (undefined4 ***)((uint)pppuStack_54 & 0xffffff00);
      uStack_8._0_1_ = 0;
      if (0xf < uStack_60) {
        uVar9 = uStack_60 + 1;
        ppppuVar10 = (uint ****)pppuVar2;
        if (0xfff < uVar9) {
          ppppuVar10 = (uint ****)pppuVar2[-1];
          uVar9 = uStack_60 + 0x24;
          uVar3 = (undefined)uStack_8;
          if (0x1f < (uint)((int)pppuVar2 + (-4 - (int)ppppuVar10))) {
LAB_005dbb8b:
            uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar10,uVar9);
      }
      uVar9 = uStack_24 + 0x20;
      param_1 = puStack_34;
    } while (uVar9 != uStack_30);
    uStack_24 = uVar9;
    if (uStack_14 != 0 || iStack_18 != 0) {
      FUN_0086f2f0(1,"--------------------------");
    }
  }
  uStack_8 = 3;
  if (cStack_38 != '\0') {
    LOCK();
    uVar9 = *puStack_3c;
    *puStack_3c = *puStack_3c + 0x80000000;
    UNLOCK();
    if (((uVar9 & 0x40000000) == 0) && (-0x80000000 < (int)uVar9)) {
      LOCK();
      uVar9 = *puStack_3c;
      *puStack_3c = *puStack_3c | 0x40000000;
      UNLOCK();
      if ((uVar9 >> 0x1e & 1) == 0) {
        uVar8 = FUN_00554e40();
        SetEvent(uVar8);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5546 ; VA 0x005dbba0 ; FUN_005dbba0 */

/* WARNING: Removing unreachable block (ram,0x005dbbef) */
/* WARNING: Removing unreachable block (ram,0x005dbc02) */
/* WARNING: Removing unreachable block (ram,0x005dbc09) */
/* WARNING: Removing unreachable block (ram,0x005dbc10) */

undefined4 __thiscall FUN_005dbba0(int param_1,undefined4 param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796168;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uStack_8 = 0;
  FUN_005db690(param_1 + 8);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5547 ; VA 0x005dbc30 ; FUN_005dbc30 */

undefined4 * __thiscall FUN_005dbc30(undefined4 *param_1,int param_2)

{
  param_1[9] = 0;
  if (param_2 != 0) {
    *param_1 = std::
               _Func_impl_no_alloc<int_(__cdecl*)(struct_ExternalAntiCheatUserData*),int,struct_ExternalAntiCheatUserData*>
               ::vftable;
    param_1[1] = param_2;
    param_1[9] = param_1;
  }
  return param_1;
}



/* FUNCTION 5548 ; VA 0x005dbc60 ; FUN_005dbc60 */

undefined4 FUN_005dbc60(undefined4 param_1,undefined4 *param_2)

{
  *param_2 = std::_Future_error_category::vftable;
  param_2[1] = 1;
  return 1;
}



/* FUNCTION 5549 ; VA 0x005dbc80 ; FUN_005dbc80 */

undefined4 FUN_005dbc80(undefined4 param_1,undefined **param_2)

{
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179a950;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_016dfd92(auStack_18);
  uStack_8 = 0xffffffff;
  FUN_016dfd64(auStack_18,&param_2,&DAT_01c243c4);
  uStack_8 = 3;
  FUN_016dfd4d(param_1,auStack_18);
  uStack_8 = 4;
  FUN_016dfdcc(auStack_18);
  param_2 = std::exception::vftable;
  FUN_0170c289(&stack0x0000000c);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5550 ; VA 0x005dbd10 ; FUN_005dbd10 */

undefined4 * __thiscall FUN_005dbd10(undefined4 *param_1,undefined4 param_2)

{
  int iVar1;
  
  *param_1 = param_2;
  *(undefined *)(param_1 + 1) = 0;
  iVar1 = FUN_016dee6d(param_2);
  if (iVar1 != 0) {
    FUN_016df3c9(iVar1);
  }
  *(undefined *)(param_1 + 1) = 1;
  return param_1;
}



/* FUNCTION 5551 ; VA 0x005dbd40 ; FUN_005dbd40 */

undefined4 __thiscall FUN_005dbd40(undefined4 param_1,undefined4 param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016dfd4d(param_1,param_2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5552 ; VA 0x005dbd80 ; FUN_005dbd80 */

undefined4 * __thiscall FUN_005dbd80(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::future_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  return param_1;
}



/* FUNCTION 5553 ; VA 0x005dbdd0 ; FUN_005dbdd0 */

undefined4 * __thiscall FUN_005dbdd0(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &DAT_018bc9b8;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  _uStack_8 = CONCAT31((int3)((uint)param_1 >> 8),1);
  FUN_0170c226(&puStack_c,param_1 + 1);
  param_1[3] = param_2;
  param_1[4] = param_3;
  *param_1 = std::future_error::vftable;
  return param_1;
}



/* FUNCTION 5554 ; VA 0x005dbe20 ; FUN_005dbe20 */

void * __fastcall FUN_005dbe20(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)*param_1;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  if (puVar3 != (undefined4 *)0x0) {
    LOCK();
    piVar1 = puVar3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    ExceptionList = &pvStack_10;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      if ((undefined4 *)puVar3[0x23] != (undefined4 *)0x0) {
        pvVar4 = (void *)(*(code *)**(undefined4 **)puVar3[0x23])(puVar3);
        ExceptionList = pvStack_10;
        return pvVar4;
      }
      pvVar4 = (void *)(**(code **)*puVar3)(1);
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 5555 ; VA 0x005dbe90 ; FUN_005dbe90 */

void * __fastcall FUN_005dbe90(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)*param_1;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  if (puVar3 != (undefined4 *)0x0) {
    LOCK();
    piVar1 = puVar3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    ExceptionList = &pvStack_10;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      if ((undefined4 *)puVar3[0x1e] != (undefined4 *)0x0) {
        pvVar4 = (void *)(*(code *)**(undefined4 **)puVar3[0x1e])(puVar3);
        ExceptionList = pvStack_10;
        return pvVar4;
      }
      pvVar4 = (void *)(**(code **)*puVar3)(1);
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 5556 ; VA 0x005dbef0 ; FUN_005dbef0 */

void * __fastcall FUN_005dbef0(int *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  code *pcVar3;
  void **ppvVar4;
  int iVar5;
  void *pvVar6;
  undefined *puStack_3c;
  code *pcStack_38;
  undefined4 *puStack_34;
  undefined **ppuStack_28;
  undefined auStack_24 [20];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  puStack_34 = (undefined4 *)*param_1;
  pvVar6 = ExceptionList;
  ppvVar4 = &pvStack_10;
  if (((puStack_34 != (undefined4 *)0x0) &&
      (((*(char *)(param_1 + 1) == '\0' ||
        (ppvVar4 = &pvStack_10, *(char *)(puStack_34 + 0x1b) == '\0')) &&
       (ppvVar4 = &pvStack_10, puStack_34[0x1c] == 0)))) &&
     (ppvVar4 = &pvStack_10, *(char *)(puStack_34 + 0x1d) == '\0')) {
    puStack_34 = (undefined4 *)&DAT_01ea8f84;
    pcStack_38 = FUN_005dbc60;
    puStack_3c = &DAT_01ea8f80;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_016de3db();
    if (iVar5 == 0) {
      puStack_34 = (undefined4 *)0x5dbfe7;
      FUN_0171d16a();
      pcVar3 = (code *)swi(3);
      pvVar6 = (void *)(*pcVar3)();
      return pvVar6;
    }
    puStack_34 = (undefined4 *)&DAT_01ea8f84;
    pcStack_38 = (code *)0x1;
    puStack_3c = (undefined *)0x5dbf5f;
    FUN_005dbdd0();
    puStack_34 = (undefined4 *)0x0;
    FUN_005dbd80(&ppuStack_28);
    FUN_005dbc80(&puStack_3c);
    FUN_005dcf20();
    puStack_34 = (undefined4 *)auStack_24;
    ppuStack_28 = std::exception::vftable;
    pcStack_38 = (code *)0x5dbf94;
    pvVar6 = (void *)FUN_0170c289();
    puStack_34 = (undefined4 *)*param_1;
    ppvVar4 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar4;
  uStack_8 = 0;
  if (puStack_34 != (undefined4 *)0x0) {
    LOCK();
    piVar1 = puStack_34 + 1;
    iVar5 = *piVar1;
    pvVar6 = (void *)*piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      if ((undefined4 *)puStack_34[0x1e] != (undefined4 *)0x0) {
        pcStack_38 = (code *)0x5dbfbc;
        pvVar6 = (void *)(*(code *)**(undefined4 **)puStack_34[0x1e])();
        ExceptionList = pvStack_10;
        return pvVar6;
      }
      puVar2 = (undefined4 *)*puStack_34;
      puStack_34 = (undefined4 *)0x1;
      pcStack_38 = (code *)0x5dbfd2;
      pvVar6 = (void *)(*(code *)*puVar2)();
    }
  }
  ExceptionList = pvStack_10;
  return pvVar6;
}



/* FUNCTION 5557 ; VA 0x005dbff0 ; FUN_005dbff0 */

void __fastcall FUN_005dbff0(undefined4 *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 1) != '\0') {
    ExceptionList = &pvStack_10;
    iVar1 = FUN_016deec8(*param_1);
    if (iVar1 != 0) {
      FUN_016df3c9(iVar1);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5558 ; VA 0x005dc040 ; FUN_005dc040 */

void __fastcall FUN_005dc040(undefined4 param_1)

{
  FUN_016df150(param_1);
  return;
}



/* FUNCTION 5559 ; VA 0x005dc050 ; FUN_005dc050 */

void __fastcall FUN_005dc050(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016dfdcc(param_1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5560 ; VA 0x005dc080 ; FUN_005dc080 */

void __fastcall FUN_005dc080(undefined4 param_1)

{
  FUN_016dedfb(param_1);
  return;
}



/* FUNCTION 5561 ; VA 0x005dc090 ; FUN_005dc090 */

int * __thiscall FUN_005dc090(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  
  if (param_1 != param_2) {
    piVar1 = (int *)param_1[9];
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x10))(piVar1 != param_1);
      param_1[9] = 0;
    }
    piVar1 = (int *)param_2[9];
    if (piVar1 != (int *)0x0) {
      if (piVar1 == param_2) {
        iVar2 = (**(code **)(*piVar1 + 4))(param_1);
        param_1[9] = iVar2;
        piVar1 = (int *)param_2[9];
        if (piVar1 != (int *)0x0) {
          (**(code **)(*piVar1 + 0x10))(piVar1 != param_2);
          param_2[9] = 0;
          return param_1;
        }
      }
      else {
        param_1[9] = (int)piVar1;
        param_2[9] = 0;
      }
    }
  }
  return param_1;
}



/* FUNCTION 5562 ; VA 0x005dc110 ; FUN_005dc110 */

void __thiscall FUN_005dc110(int *param_1,int param_2,int param_3)

{
  int *piVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int **ppiStack_60;
  int *piStack_5c;
  undefined auStack_50 [16];
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  int *apiStack_28 [2];
  int *apiStack_20 [2];
  int *piStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a968;
  pvStack_10 = ExceptionList;
  if (param_2 == 0) {
    iVar6 = *(int *)(param_3 + 0xc);
    if ((iVar6 - 200U < 100) && (iVar6 != 0xca)) {
      piVar1 = (int *)(param_3 + 0x40);
      piVar3 = *(int **)*param_1;
      if ((piVar3 == (int *)0x0) ||
         ((cVar2 = *(char *)((int *)*param_1 + 1), cVar2 != '\0' &&
          ((*(char *)(piVar3 + 0x20) != '\0' ||
           ((cVar2 != '\0' && (*(char *)(piVar3 + 0x20) != '\0')))))))) {
        ppiStack_60 = apiStack_20;
        piStack_5c = (int *)0x4;
        ExceptionList = &pvStack_10;
        piStack_5c = (int *)FUN_005deb10();
                    /* WARNING: Subroutine does not return */
        ppiStack_60 = (int **)0x5dc388;
        FUN_016dfe59();
      }
      piStack_5c = piVar3 + 10;
      cStack_14 = 0;
      ppiStack_60 = (int **)0x5dc247;
      ExceptionList = &pvStack_10;
      piStack_18 = piStack_5c;
      piStack_5c = (int *)FUN_016dee6d();
      if (piStack_5c != (int *)0x0) {
        ppiStack_60 = (int **)0x5dc254;
        FUN_016df3c9();
      }
      cStack_14 = '\x01';
      uStack_8 = 0xc;
      if (*(char *)((int)piVar3 + 0x89) == '\0') {
        if (piVar3 + 2 != piVar1) {
          piStack_5c = (int *)0x5dc27d;
          FUN_005507b0();
          iVar6 = *(int *)(param_3 + 0x44);
          iVar4 = *(int *)(param_3 + 0x48);
          iVar5 = *(int *)(param_3 + 0x4c);
          piVar3[2] = *piVar1;
          piVar3[3] = iVar6;
          piVar3[4] = iVar4;
          piVar3[5] = iVar5;
          *(undefined8 *)(piVar3 + 6) = *(undefined8 *)(param_3 + 0x50);
          *(undefined4 *)(param_3 + 0x50) = 0;
          *(undefined4 *)(param_3 + 0x54) = 0xf;
          *(undefined *)piVar1 = 0;
        }
        ppiStack_60 = &piStack_18;
        piStack_5c = (int *)0x0;
        (**(code **)(*piVar3 + 0x14))();
        uStack_8 = 0xd;
        if (cStack_14 == '\0') {
          ExceptionList = pvStack_10;
          return;
        }
        iVar6 = FUN_016deec8(piStack_18);
        if (iVar6 == 0) {
          ExceptionList = pvStack_10;
          return;
        }
        FUN_016df3c9(iVar6);
        ExceptionList = pvStack_10;
        return;
      }
      ppiStack_60 = apiStack_28;
      piStack_5c = (int *)0x3;
      piStack_5c = (int *)FUN_005deb10();
                    /* WARNING: Subroutine does not return */
      ppiStack_60 = (int **)&UNK_005dc39c;
      FUN_016dfe59();
    }
    ExceptionList = &pvStack_10;
    FUN_014cc1e0(iVar6,param_3 + 0x74,param_3 + 0x40);
    uStack_8 = 7;
    FUN_016dfd92(apiStack_20);
    uStack_8._0_1_ = 6;
    FUN_016dfd64(apiStack_20,auStack_50,&DAT_01c24454);
    uStack_8._0_1_ = 10;
    FUN_016dfd4d(&ppiStack_60,apiStack_20);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    FUN_016dfdcc(apiStack_20);
    FUN_0056e860();
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_0054ef60(param_3 + 0x74);
    uStack_8 = 1;
    FUN_016dfd92(apiStack_20);
    uStack_8 = uStack_8 & 0xffffff00;
    FUN_016dfd64(apiStack_20,auStack_40,&DAT_01c24400);
    uStack_8._0_1_ = 4;
    FUN_016dfd4d(&ppiStack_60,apiStack_20);
    uStack_8._0_1_ = 5;
    FUN_016dfdcc(apiStack_20);
    uStack_8 = (uint)uStack_8._1_3_ << 8;
    if (0xf < uStack_2c) {
      uVar8 = uStack_2c + 1;
      uVar7 = auStack_40[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_40[0] - 4);
        uVar8 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
  }
  uStack_8 = 0xffffffff;
  FUN_005df0e0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5563 ; VA 0x005dc3a0 ; FUN_005dc3a0 */

undefined4 * __thiscall FUN_005dc3a0(undefined4 *param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::
             _Associated_state<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
             ::vftable;
  if ((*(char *)((int)param_1 + 0x89) != '\0') && (param_1[0x21] == 0)) {
    FUN_016df30e(param_1 + 10);
  }
  FUN_016df150(param_1 + 0x16);
  FUN_016dedfb(param_1 + 10);
  uStack_8 = 0;
  FUN_016dfdcc(param_1 + 8);
  uVar1 = param_1[7];
  if (0xf < uVar1) {
    iVar2 = param_1[2];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[6] = 0;
  param_1[7] = 0xf;
  *(undefined *)(param_1 + 2) = 0;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x90);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5564 ; VA 0x005dc480 ; FUN_005dc480 */

undefined4 * __thiscall FUN_005dc480(undefined4 *param_1,byte param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::_Associated_state<bool>::vftable;
  if ((*(char *)((int)param_1 + 0x75) != '\0') && (param_1[0x1c] == 0)) {
    FUN_016df30e(param_1 + 5);
  }
  FUN_016df150(param_1 + 0x11);
  FUN_016dedfb(param_1 + 5);
  uStack_8 = 0;
  FUN_016dfdcc(param_1 + 3);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x7c);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5565 ; VA 0x005dc510 ; FUN_005dc510 */

undefined4 __thiscall FUN_005dc510(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 5566 ; VA 0x005dc530 ; FUN_005dc530 */

int FUN_005dc530(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = GetProcAddress(param_1,param_2);
  if ((iVar1 == 0) && (DAT_01d59810 != '\0')) {
    FUN_01677520(DAT_01d59810,
                 "GetProcAddress failed for %s. Failed to find function in external anticheat library."
                 ,param_2);
  }
  return iVar1;
}



/* FUNCTION 5567 ; VA 0x005dc570 ; FUN_005dc570 */

int FUN_005dc570(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_016df117(param_1);
  if (iVar1 != 0) {
    FUN_016df3c9(iVar1);
  }
  return iVar1;
}



/* FUNCTION 5568 ; VA 0x005dc5a0 ; FUN_005dc5a0 */

void __thiscall FUN_005dc5a0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<int_(__cdecl*)(struct_ExternalAntiCheatUserData*),int,struct_ExternalAntiCheatUserData*>
             ::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  return;
}



/* FUNCTION 5569 ; VA 0x005dc5c0 ; FUN_005dc5c0 */

void __thiscall FUN_005dc5c0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<int_(__cdecl*)(struct_ExternalAntiCheatUserData*,unsigned_char_const*,int),int,struct_ExternalAntiCheatUserData*,unsigned_char_const*,int>
             ::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  return;
}



/* FUNCTION 5570 ; VA 0x005dc5e0 ; FUN_005dc5e0 */

void __thiscall FUN_005dc5e0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<int_(__cdecl*)(char_const*,int_(__cdecl*)(unsigned___int64,unsigned_char_const*,int)),int,char_const*,int_(__cdecl*)(unsigned___int64,unsigned_char_const*,int)>
             ::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  return;
}



/* FUNCTION 5571 ; VA 0x005dc600 ; FUN_005dc600 */

void __thiscall FUN_005dc600(int param_1,undefined4 *param_2)

{
  *param_2 = std::_Func_impl_no_alloc<int_(__cdecl*)(void),int>::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  return;
}



/* FUNCTION 5572 ; VA 0x005dc620 ; FUN_005dc620 */

void __thiscall FUN_005dc620(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<int_(__cdecl*)(unsigned___int64,char_const*,char_const*,int),int,unsigned___int64,char_const*,char_const*,int>
             ::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  return;
}



/* FUNCTION 5573 ; VA 0x005dc640 ; FUN_005dc640 */

void __thiscall FUN_005dc640(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<int_(__cdecl*)(unsigned___int64,char_const*,unsigned_long,char_const*,int),int,unsigned___int64,char_const*,unsigned_long,char_const*,int>
             ::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  return;
}



/* FUNCTION 5574 ; VA 0x005dc660 ; FUN_005dc660 */

void __thiscall FUN_005dc660(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<int_(__cdecl*)(unsigned___int64,char_const*,unsigned_char_const*,int,char_const*,int),int,unsigned___int64,char_const*,unsigned_char_const*,int,char_const*,int>
             ::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  return;
}



/* FUNCTION 5575 ; VA 0x005dc680 ; FUN_005dc680 */

void __thiscall FUN_005dc680(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_613320506386d18d191c5d0e696f3da6>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  return;
}



/* FUNCTION 5576 ; VA 0x005dc6c0 ; FUN_005dc6c0 */

undefined4 FUN_005dc6c0(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_016dfd92(param_1);
  uStack_8 = 0xffffffff;
  FUN_016dfda1(param_1);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5577 ; VA 0x005dc710 ; FUN_005dc710 */

void __thiscall FUN_005dc710(int param_1,char param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0xc);
  }
  return;
}



/* FUNCTION 5578 ; VA 0x005dc760 ; FUN_005dc760 */

void * __fastcall FUN_005dc760(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  code *pcVar3;
  void **ppvVar4;
  int iVar5;
  void *pvVar6;
  undefined *puStack_3c;
  code *pcStack_38;
  undefined4 *puStack_34;
  undefined **ppuStack_28;
  undefined auStack_24 [20];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179a980;
  pvStack_10 = ExceptionList;
  iVar5 = *(int *)(param_1 + 0xc);
  uStack_8 = 0;
  pvVar6 = ExceptionList;
  ppvVar4 = &pvStack_10;
  if (((iVar5 != 0) &&
      (((*(char *)(param_1 + 0x10) == '\0' ||
        (ppvVar4 = &pvStack_10, *(char *)(iVar5 + 0x80) == '\0')) &&
       (ppvVar4 = &pvStack_10, *(int *)(iVar5 + 0x84) == 0)))) &&
     (ppvVar4 = &pvStack_10, *(char *)(iVar5 + 0x88) == '\0')) {
    puStack_34 = (undefined4 *)&DAT_01ea8f84;
    pcStack_38 = FUN_005dbc60;
    puStack_3c = &DAT_01ea8f80;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_016de3db();
    if (iVar5 == 0) {
      puStack_34 = (undefined4 *)0x5dc868;
      FUN_0171d16a();
      pcVar3 = (code *)swi(3);
      pvVar6 = (void *)(*pcVar3)();
      return pvVar6;
    }
    puStack_34 = (undefined4 *)&DAT_01ea8f84;
    pcStack_38 = (code *)0x1;
    puStack_3c = (undefined *)0x5dc7e0;
    FUN_005dbdd0();
    puStack_34 = (undefined4 *)0x0;
    FUN_005dbd80(&ppuStack_28);
    FUN_005dbc80(&puStack_3c);
    FUN_005dcdd0();
    puStack_34 = (undefined4 *)auStack_24;
    ppuStack_28 = std::exception::vftable;
    pcStack_38 = (code *)0x5dc815;
    pvVar6 = (void *)FUN_0170c289();
    ppvVar4 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar4;
  puStack_34 = *(undefined4 **)(param_1 + 0xc);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (puStack_34 != (undefined4 *)0x0) {
    LOCK();
    piVar1 = puStack_34 + 1;
    iVar5 = *piVar1;
    pvVar6 = (void *)*piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      if ((undefined4 *)puStack_34[0x23] != (undefined4 *)0x0) {
        pcStack_38 = (code *)0x5dc83d;
        pvVar6 = (void *)(*(code *)**(undefined4 **)puStack_34[0x23])();
        ExceptionList = pvStack_10;
        return pvVar6;
      }
      puVar2 = (undefined4 *)*puStack_34;
      puStack_34 = (undefined4 *)0x1;
      pcStack_38 = (code *)0x5dc853;
      pvVar6 = (void *)(*(code *)*puVar2)();
    }
  }
  ExceptionList = pvStack_10;
  return pvVar6;
}



/* FUNCTION 5579 ; VA 0x005dc870 ; FUN_005dc870 */

void __thiscall FUN_005dc870(int param_1,undefined4 *param_2)

{
  (**(code **)(param_1 + 4))(*param_2);
  return;
}



/* FUNCTION 5580 ; VA 0x005dc890 ; FUN_005dc890 */

void __thiscall
FUN_005dc890(int param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  (**(code **)(param_1 + 4))(*param_2,*param_3,*param_4);
  return;
}



/* FUNCTION 5581 ; VA 0x005dc8c0 ; FUN_005dc8c0 */

void __thiscall FUN_005dc8c0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  (**(code **)(param_1 + 4))(*param_2,*param_3);
  return;
}



/* FUNCTION 5582 ; VA 0x005dc8e0 ; FUN_005dc8e0 */

void __thiscall
FUN_005dc8e0(int param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4,
            undefined4 *param_5)

{
  (**(code **)(param_1 + 4))(*param_2,param_2[1],*param_3,*param_4,*param_5);
  return;
}



/* FUNCTION 5583 ; VA 0x005dc910 ; FUN_005dc910 */

void __thiscall
FUN_005dc910(int param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4,
            undefined4 *param_5,undefined4 *param_6)

{
  (**(code **)(param_1 + 4))(*param_2,param_2[1],*param_3,*param_4,*param_5,*param_6);
  return;
}



/* FUNCTION 5584 ; VA 0x005dc950 ; FUN_005dc950 */

void __thiscall
FUN_005dc950(int param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4,
            undefined4 *param_5,undefined4 *param_6,undefined4 *param_7)

{
  (**(code **)(param_1 + 4))(*param_2,param_2[1],*param_3,*param_4,*param_5,*param_6,*param_7);
  return;
}



/* FUNCTION 5585 ; VA 0x005dc9a0 ; FUN_005dc9a0 */

void FUN_005dc9a0(undefined4 *param_1,undefined4 param_2)

{
  FUN_005dc110(*param_1,param_2);
  return;
}



/* FUNCTION 5586 ; VA 0x005dc9c0 ; FUN_005dc9c0 */

void __thiscall FUN_005dc9c0(int param_1,undefined4 *param_2,char param_3)

{
  undefined4 uVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined *)(param_1 + 0x89) = 1;
  if (param_3 != '\0') {
    uVar1 = *param_2;
    *param_2 = 0;
    *(undefined *)(param_2 + 1) = 0;
    FUN_016df287(param_1 + 0x58,uVar1,param_1 + 0x84);
    ExceptionList = pvStack_10;
    return;
  }
  *(undefined4 *)(param_1 + 0x84) = 1;
  uStack_8 = 0;
  iVar2 = FUN_016df117(param_1 + 0x58);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5587 ; VA 0x005dca60 ; FUN_005dca60 */

void __thiscall FUN_005dca60(int param_1,undefined4 *param_2,char param_3)

{
  undefined4 uVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined *)(param_1 + 0x75) = 1;
  if (param_3 != '\0') {
    uVar1 = *param_2;
    *param_2 = 0;
    *(undefined *)(param_2 + 1) = 0;
    FUN_016df287(param_1 + 0x44,uVar1,param_1 + 0x70);
    ExceptionList = pvStack_10;
    return;
  }
  *(undefined4 *)(param_1 + 0x70) = 1;
  uStack_8 = 0;
  iVar2 = FUN_016df117(param_1 + 0x44);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5588 ; VA 0x005dcaf0 ; FUN_005dcaf0 */

int * __thiscall FUN_005dcaf0(int *param_1,char param_2)

{
  code *pcVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined auStack_20 [8];
  int *piStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a998;
  pvStack_10 = ExceptionList;
  cStack_14 = 0;
  piStack_18 = param_1 + 10;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_016dee6d(piStack_18);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  cStack_14 = '\x01';
  iStack_8 = 0;
  if ((param_2 != '\0') && (*(char *)(param_1 + 0x20) != '\0')) {
    uVar4 = FUN_005deb10(auStack_20,2);
                    /* WARNING: Subroutine does not return */
    FUN_016dfe59(uVar4);
  }
  piVar5 = param_1 + 8;
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  cVar2 = FUN_016dfded(piVar5);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (cVar2 == '\0') {
    *(undefined *)(param_1 + 0x20) = 1;
    if (*(char *)((int)param_1 + 0x8a) == '\0') {
      *(undefined *)((int)param_1 + 0x8a) = 1;
      (**(code **)(*param_1 + 0x10))(&piStack_18);
    }
    if (param_1[0x21] == 0) {
      do {
        iVar3 = FUN_016df1c8(param_1 + 0x16,piStack_18);
        if (iVar3 != 0) {
          FUN_016df3c9(iVar3);
        }
      } while (param_1[0x21] == 0);
    }
    iStack_8._0_1_ = 2;
    cVar2 = FUN_016dfded(piVar5);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (cVar2 == '\0') {
      iStack_8 = 3;
      if (cStack_14 != '\0') {
        iVar3 = FUN_016deec8(piStack_18);
        if (iVar3 != 0) {
          FUN_016df3c9(iVar3);
        }
      }
      ExceptionList = pvStack_10;
      return param_1 + 2;
    }
  }
  else {
    FUN_005dbd40(piVar5);
    FUN_016dfe36();
  }
  FUN_005dbd40(piVar5);
  FUN_016dfe36();
  pcVar1 = (code *)swi(3);
  piVar5 = (int *)(*pcVar1)();
  return piVar5;
}



/* FUNCTION 5589 ; VA 0x005dcc40 ; FUN_005dcc40 */

int * __thiscall FUN_005dcc40(int *param_1,char param_2)

{
  code *pcVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined auStack_20 [8];
  int *piStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a998;
  pvStack_10 = ExceptionList;
  cStack_14 = 0;
  piStack_18 = param_1 + 5;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_016dee6d(piStack_18);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  cStack_14 = '\x01';
  iStack_8 = 0;
  if ((param_2 != '\0') && (*(char *)(param_1 + 0x1b) != '\0')) {
    uVar4 = FUN_005deb10(auStack_20,2);
                    /* WARNING: Subroutine does not return */
    FUN_016dfe59(uVar4);
  }
  piVar5 = param_1 + 3;
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  cVar2 = FUN_016dfded(piVar5);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (cVar2 == '\0') {
    *(undefined *)(param_1 + 0x1b) = 1;
    if (*(char *)((int)param_1 + 0x76) == '\0') {
      *(undefined *)((int)param_1 + 0x76) = 1;
      (**(code **)(*param_1 + 0x10))(&piStack_18);
    }
    if (param_1[0x1c] == 0) {
      do {
        iVar3 = FUN_016df1c8(param_1 + 0x11,piStack_18);
        if (iVar3 != 0) {
          FUN_016df3c9(iVar3);
        }
      } while (param_1[0x1c] == 0);
    }
    iStack_8._0_1_ = 2;
    cVar2 = FUN_016dfded(piVar5);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (cVar2 == '\0') {
      iStack_8 = 3;
      if (cStack_14 != '\0') {
        iVar3 = FUN_016deec8(piStack_18);
        if (iVar3 != 0) {
          FUN_016df3c9(iVar3);
        }
      }
      ExceptionList = pvStack_10;
      return param_1 + 2;
    }
  }
  else {
    FUN_005dbd40(piVar5);
    FUN_016dfe36();
  }
  FUN_005dbd40(piVar5);
  FUN_016dfe36();
  pcVar1 = (code *)swi(3);
  piVar5 = (int *)(*pcVar1)();
  return piVar5;
}



/* FUNCTION 5590 ; VA 0x005dcd90 ; FUN_005dcd90 */

void __thiscall FUN_005dcd90(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_613320506386d18d191c5d0e696f3da6>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  return;
}



/* FUNCTION 5591 ; VA 0x005dcdd0 ; FUN_005dcdd0 */

void __thiscall FUN_005dcdd0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_30 [8];
  undefined auStack_28 [8];
  undefined auStack_20 [8];
  int *piStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179a9d0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  uStack_8 = 0;
  if ((piVar1 == (int *)0x0) ||
     ((*(char *)(param_1 + 1) != '\0' && (*(char *)(piVar1 + 0x20) != '\0')))) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_005deb10(auStack_30,4);
                    /* WARNING: Subroutine does not return */
    FUN_016dfe59(uVar3);
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  FUN_016dfd4d(auStack_28,&param_2);
  piStack_18 = piVar1 + 10;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cStack_14 = 0;
  iVar2 = FUN_016dee6d(piStack_18);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  cStack_14 = '\x01';
  uStack_8._0_1_ = 4;
  FUN_016dfd4d(auStack_20,auStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (*(char *)((int)piVar1 + 0x89) == '\0') {
    uStack_8._0_1_ = 6;
    FUN_016dfd2b(piVar1 + 8,auStack_20);
    uStack_8._0_1_ = 5;
    (**(code **)(*piVar1 + 0x14))(&piStack_18,param_4);
    uStack_8._0_1_ = 7;
    FUN_016dfdcc(auStack_20);
    uStack_8._0_1_ = 8;
    if (cStack_14 != '\0') {
      iVar2 = FUN_016deec8(piStack_18);
      if (iVar2 != 0) {
        FUN_016df3c9(iVar2);
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    FUN_016dfdcc(auStack_28);
    uStack_8 = 10;
    FUN_016dfdcc(&param_2);
    ExceptionList = pvStack_10;
    return;
  }
  uVar3 = FUN_005deb10(auStack_30,3);
                    /* WARNING: Subroutine does not return */
  FUN_016dfe59(uVar3);
}



/* FUNCTION 5592 ; VA 0x005dcf20 ; FUN_005dcf20 */

void __thiscall FUN_005dcf20(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_30 [8];
  undefined auStack_28 [8];
  undefined auStack_20 [8];
  int *piStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179a9d0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  uStack_8 = 0;
  if ((piVar1 == (int *)0x0) ||
     ((*(char *)(param_1 + 1) != '\0' && (*(char *)(piVar1 + 0x1b) != '\0')))) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_005deb10(auStack_30,4);
                    /* WARNING: Subroutine does not return */
    FUN_016dfe59(uVar3);
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  FUN_016dfd4d(auStack_28,&param_2);
  piStack_18 = piVar1 + 5;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cStack_14 = 0;
  iVar2 = FUN_016dee6d(piStack_18);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  cStack_14 = '\x01';
  uStack_8._0_1_ = 4;
  FUN_016dfd4d(auStack_20,auStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (*(char *)((int)piVar1 + 0x75) == '\0') {
    uStack_8._0_1_ = 6;
    FUN_016dfd2b(piVar1 + 3,auStack_20);
    uStack_8._0_1_ = 5;
    (**(code **)(*piVar1 + 0x14))(&piStack_18,param_4);
    uStack_8._0_1_ = 7;
    FUN_016dfdcc(auStack_20);
    uStack_8._0_1_ = 8;
    if (cStack_14 != '\0') {
      iVar2 = FUN_016deec8(piStack_18);
      if (iVar2 != 0) {
        FUN_016df3c9(iVar2);
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    FUN_016dfdcc(auStack_28);
    uStack_8 = 10;
    FUN_016dfdcc(&param_2);
    ExceptionList = pvStack_10;
    return;
  }
  uVar3 = FUN_005deb10(auStack_30,3);
                    /* WARNING: Subroutine does not return */
  FUN_016dfe59(uVar3);
}



/* FUNCTION 5593 ; VA 0x005dd070 ; FUN_005dd070 */

TypeDescriptor * FUN_005dd070(void)

{
  return &TypeDescriptor_01d94df0;
}



/* FUNCTION 5594 ; VA 0x005dd080 ; FUN_005dd080 */

TypeDescriptor * FUN_005dd080(void)

{
  return &TypeDescriptor_01d94dbc;
}



/* FUNCTION 5595 ; VA 0x005dd090 ; FUN_005dd090 */

TypeDescriptor * FUN_005dd090(void)

{
  return &TypeDescriptor_01d94e7c;
}



/* FUNCTION 5596 ; VA 0x005dd0a0 ; FUN_005dd0a0 */

TypeDescriptor * FUN_005dd0a0(void)

{
  return &TypeDescriptor_01d94e20;
}



/* FUNCTION 5597 ; VA 0x005dd0b0 ; FUN_005dd0b0 */

TypeDescriptor * FUN_005dd0b0(void)

{
  return &TypeDescriptor_01d94e4c;
}



/* FUNCTION 5598 ; VA 0x005dd0c0 ; FUN_005dd0c0 */

TypeDescriptor * FUN_005dd0c0(void)

{
  return &TypeDescriptor_01d94e64;
}



/* FUNCTION 5599 ; VA 0x005dd0d0 ; FUN_005dd0d0 */

TypeDescriptor * FUN_005dd0d0(void)

{
  return &TypeDescriptor_01d94e30;
}



/* FUNCTION 5600 ; VA 0x005dd0e0 ; FUN_005dd0e0 */

TypeDescriptor * FUN_005dd0e0(void)

{
  return &<lambda_613320506386d18d191c5d0e696f3da6>::RTTI_Type_Descriptor;
}



/* FUNCTION 5601 ; VA 0x005dd0f0 ; FUN_005dd0f0 */

void __fastcall FUN_005dd0f0(int *param_1)

{
  int iVar1;
  int *piStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a9e8;
  pvStack_10 = ExceptionList;
  cStack_14 = 0;
  piStack_18 = param_1 + 10;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_016dee6d(piStack_18);
  if (iVar1 != 0) {
    FUN_016df3c9(iVar1);
  }
  cStack_14 = '\x01';
  uStack_8 = 0;
  if (*(char *)((int)param_1 + 0x8a) == '\0') {
    *(undefined *)((int)param_1 + 0x8a) = 1;
    (**(code **)(*param_1 + 0x10))(&piStack_18);
  }
  if (param_1[0x21] == 0) {
    do {
      iVar1 = FUN_016df1c8(param_1 + 0x16,piStack_18);
      if (iVar1 != 0) {
        FUN_016df3c9(iVar1);
      }
    } while (param_1[0x21] == 0);
  }
  uStack_8 = 1;
  if ((cStack_14 != '\0') && (iVar1 = FUN_016deec8(piStack_18), iVar1 != 0)) {
    FUN_016df3c9(iVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5602 ; VA 0x005dd1c0 ; FUN_005dd1c0 */

void __fastcall FUN_005dd1c0(int *param_1)

{
  int iVar1;
  int *piStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a9e8;
  pvStack_10 = ExceptionList;
  cStack_14 = 0;
  piStack_18 = param_1 + 5;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_016dee6d(piStack_18);
  if (iVar1 != 0) {
    FUN_016df3c9(iVar1);
  }
  cStack_14 = '\x01';
  uStack_8 = 0;
  if (*(char *)((int)param_1 + 0x76) == '\0') {
    *(undefined *)((int)param_1 + 0x76) = 1;
    (**(code **)(*param_1 + 0x10))(&piStack_18);
  }
  if (param_1[0x1c] == 0) {
    do {
      iVar1 = FUN_016df1c8(param_1 + 0x11,piStack_18);
      if (iVar1 != 0) {
        FUN_016df3c9(iVar1);
      }
    } while (param_1[0x1c] == 0);
  }
  uStack_8 = 1;
  if ((cStack_14 != '\0') && (iVar1 = FUN_016deec8(piStack_18), iVar1 != 0)) {
    FUN_016df3c9(iVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5603 ; VA 0x005dd290 ; FUN_005dd290 */

undefined4 FUN_005dd290(undefined4 param_1)

{
  undefined4 uVar1;
  undefined4 uStack_8;
  
  if (DAT_01ea8e28 == '\0') {
    return 1;
  }
  uStack_8 = param_1;
  if (DAT_01ea8e8c != (int *)0x0) {
    uVar1 = (**(code **)(*DAT_01ea8e8c + 8))(&uStack_8);
    return uVar1;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddc9c();
}



/* FUNCTION 5604 ; VA 0x005dd2d0 ; FUN_005dd2d0 */

undefined4
FUN_005dd2d0(undefined4 *param_1,int *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179aa08;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if ((DAT_01ea8e28 == '\0') || (param_1 == (undefined4 *)0x0)) {
    uVar3 = 1;
    ExceptionList = &pvStack_10;
  }
  else {
    uStack_14 = param_1[6];
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    uStack_1c = param_6;
    uStack_20 = param_5;
    uStack_28 = param_3;
    uStack_24 = param_4;
    puStack_18 = param_1;
    if (DAT_01ea8edc == (int *)0x0) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_016ddc9c();
    }
    ExceptionList = &pvStack_10;
    uVar3 = (**(code **)(*DAT_01ea8edc + 8))
                      (&uStack_28,&uStack_20,&uStack_1c,&puStack_18,&uStack_14);
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 5605 ; VA 0x005dd3a0 ; FUN_005dd3a0 */

void FUN_005dd3a0(int *****param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  int *piVar1;
  uint uVar2;
  undefined uVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int *****pppppiVar7;
  code *pcVar8;
  int ****ppppiVar9;
  int iVar10;
  undefined8 uStack_bc;
  undefined4 uStack_b4;
  undefined4 *puStack_b0;
  int ****ppppiStack_ac;
  int ****ppppiStack_a8;
  int ****ppppiStack_a4;
  undefined4 uStack_94;
  undefined4 uStack_84;
  uint uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_6c;
  uint uStack_68;
  int ****ppppiStack_64;
  undefined **ppuStack_60;
  undefined8 uStack_5c;
  undefined4 uStack_54;
  undefined *puStack_50;
  int ***pppiStack_4c;
  undefined **ppuStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  undefined *puStack_38;
  undefined4 *puStack_34;
  char cStack_30;
  undefined uStack_2c;
  undefined1 *puStack_28;
  undefined uStack_24;
  undefined1 *puStack_20;
  undefined4 *puStack_1c;
  char cStack_15;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179aa9b;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff60;
  ppppiStack_a4 = (int ****)0x7c;
  ppppiStack_a8 = (int ****)0x5dd3cb;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_01674e20();
  puStack_1c = puVar5;
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = std::_Associated_state<bool>::vftable;
    ppppiStack_a4 = (int ****)(puVar5 + 3);
    puVar5[1] = 1;
    uStack_8 = 0;
    ppppiStack_a8 = (int ****)0x5dd3f4;
    FUN_016dfd92();
    ppppiStack_ac = (int ****)(puVar5 + 5);
    ppppiStack_a8 = (int ****)0x2;
    puStack_b0 = (undefined4 *)0x5dd3ff;
    FUN_016dee4c();
    puStack_b0 = puVar5 + 0x11;
    uStack_b4 = 0x5dd408;
    thunk_FUN_016def21();
    *(undefined *)(puVar5 + 0x1b) = 0;
    puVar5[0x1c] = 0;
    *(undefined2 *)(puVar5 + 0x1d) = 0;
    *(undefined *)((int)puVar5 + 0x76) = 0;
    puVar5[0x1e] = 0;
  }
  cStack_30 = '\0';
  uStack_2c = 0;
  uStack_8 = 1;
  puStack_34 = puVar5;
  if (puVar5 == (undefined4 *)0x0) {
    ppppiStack_a8 = (int ****)&puStack_28;
    ppppiStack_a4 = (int ****)0x4;
    ppppiStack_ac = (int ****)0x5dde19;
    ppppiStack_a4 = (int ****)FUN_005deb10();
                    /* WARNING: Subroutine does not return */
    ppppiStack_a8 = (int ****)0x5dde22;
    FUN_016dfe59();
  }
  uStack_2c = 1;
  LOCK();
  puVar5[1] = puVar5[1] + 1;
  ppppiStack_a4 = (int ****)DAT_01ea8e58;
  UNLOCK();
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  if (DAT_01ea8e58 != (undefined4 *)0x0) {
    LOCK();
    iVar10 = DAT_01ea8e58[1] + -1;
    DAT_01ea8e58[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      if (ppppiStack_a4[0x1e] == (int ***)0x0) {
        puVar6 = *ppppiStack_a4;
        ppppiStack_a4 = (int ****)0x1;
      }
      else {
        puVar6 = *ppppiStack_a4[0x1e];
      }
      ppppiStack_a8 = (int ****)0x5dd479;
      (*(code *)*puVar6)();
    }
  }
  DAT_01ea8e5c = 1;
  uStack_84 = 0;
  uStack_80 = 7;
  uStack_94 = (int ****)((uint)uStack_94._2_2_ << 0x10);
  uStack_6c = 0;
  uStack_68 = 7;
  uStack_7c = (code *)((uint)uStack_7c._2_2_ << 0x10);
  ppppiStack_a4 = (int ****)0x18c70f0;
  uStack_8._0_1_ = 5;
  ppppiStack_a8 = (int ****)0x5dd4bc;
  DAT_01ea8e58 = puVar5;
  FUN_00a11cc0();
  if (param_1[4] != (int ****)0x0) {
    ppppiStack_a4 = (int ****)0x1b;
    ppppiStack_a8 = (int ****)0x18c711c;
    uStack_8._0_1_ = 7;
    uStack_54 = 0;
    puStack_50 = (undefined *)0xf;
    ppppiStack_64 = (int ****)((uint)ppppiStack_64 & 0xffffff00);
    ppppiStack_ac = (int ****)0x5dd4ee;
    FUN_005542c0();
    ppppiStack_a4 = (int ****)&ppppiStack_64;
    uStack_8._0_1_ = 8;
    ppppiStack_ac = &pppiStack_4c;
    ppppiStack_a8 = (int ****)param_1;
    puStack_b0 = (undefined4 *)0x5dd500;
    pppppiVar7 = (int *****)FUN_005de250();
    uStack_8._0_1_ = 9;
    if ((int *****)&uStack_94 != pppppiVar7) {
      ppppiStack_a4 = pppppiVar7[4];
      if ((int ****)0x7 < pppppiVar7[5]) {
        pppppiVar7 = (int *****)*pppppiVar7;
      }
      ppppiStack_ac = (int ****)0x5dd529;
      ppppiStack_a8 = (int ****)pppppiVar7;
      FUN_0058ed10();
    }
    ppppiStack_a4 = (int ****)0x5dd531;
    FUN_00550800();
    uStack_8._0_1_ = 7;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 7;
    if ((undefined *)0xf < puStack_50) {
      ppppiStack_a4 = (int ****)(puStack_50 + 1);
      pppppiVar7 = (int *****)ppppiStack_64;
      if ((undefined *)0xfff < ppppiStack_a4) {
        pppppiVar7 = (int *****)ppppiStack_64[-1];
        ppppiStack_a4 = (int ****)(puStack_50 + 0x24);
        if (0x1f < (uint)((int)ppppiStack_64 + (-4 - (int)pppppiVar7))) {
LAB_005dde22:
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          ppppiStack_a4 = (int ****)0x5dde27;
          FUN_017167a3();
        }
      }
      ppppiStack_ac = (int ****)0x5dd566;
      ppppiStack_a8 = (int ****)pppppiVar7;
      FUN_01674ea0();
    }
    if (DAT_01d59810 != 0) {
      if ((int ****)0xf < param_1[5]) {
        param_1 = (int *****)*param_1;
      }
      ppppiStack_ac = (int ****)(uint)DAT_01d59810;
      ppppiStack_a8 = (int ****)0x18c7478;
      puStack_b0 = (undefined4 *)0x5dd589;
      ppppiStack_a4 = (int ****)param_1;
      FUN_01677520();
    }
    ppppiStack_a4 = (int ****)0x2b;
    ppppiStack_a8 = (int ****)0x18c74bc;
    uStack_54 = 0;
    puStack_50 = (undefined *)0xf;
    ppppiStack_64 = (int ****)((uint)ppppiStack_64 & 0xffffff00);
    ppppiStack_ac = (int ****)0x5dd5ad;
    FUN_005542c0();
    ppppiStack_a4 = (int ****)0x0;
    ppppiStack_ac = (int ****)&ppppiStack_64;
    uStack_8._0_1_ = 10;
    ppppiStack_a8 = (int ****)0x1;
    puStack_b0 = (undefined4 *)0x5dd5be;
    FUN_008783f0();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    if ((undefined *)0xf < puStack_50) {
      ppppiStack_a4 = (int ****)(puStack_50 + 1);
      pppppiVar7 = (int *****)ppppiStack_64;
      if ((undefined *)0xfff < ppppiStack_a4) {
        pppppiVar7 = (int *****)ppppiStack_64[-1];
        ppppiStack_a4 = (int ****)(puStack_50 + 0x24);
        if (0x1f < (uint)((int)ppppiStack_64 + (-4 - (int)pppppiVar7))) {
                    /* WARNING: Subroutine does not return */
          ppppiStack_a4 = (int ****)0x5dde2c;
          FUN_017167a3();
        }
      }
      ppppiStack_ac = (int ****)0x5dd5f6;
      ppppiStack_a8 = (int ****)pppppiVar7;
      FUN_01674ea0();
    }
  }
  if ((param_2[4] != 0) && (param_3[4] != 0)) {
    ppppiStack_a4 = (int ****)param_3;
    ppppiStack_ac = (int ****)&ppppiStack_64;
    uStack_8._0_1_ = 0xd;
    uStack_8._1_3_ = 0;
    ppppiStack_a8 = (int ****)param_2;
    puStack_b0 = (undefined4 *)0x5dd629;
    puVar5 = (undefined4 *)FUN_005de250();
    uStack_8._0_1_ = 0xe;
    if (&uStack_7c != puVar5) {
      ppppiStack_a4 = (int ****)puVar5[4];
      if (7 < (uint)puVar5[5]) {
        puVar5 = (undefined4 *)*puVar5;
      }
      ppppiStack_ac = (int ****)0x5dd64c;
      ppppiStack_a8 = (int ****)puVar5;
      FUN_0058ed10();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
    ppppiStack_a4 = (int ****)0x5dd658;
    FUN_00550800();
    if (DAT_01d59810 != 0) {
      if (0xf < (uint)param_2[5]) {
        param_2 = (undefined4 *)*param_2;
      }
      ppppiStack_a8 = (int ****)param_3;
      if (0xf < (uint)param_3[5]) {
        ppppiStack_a8 = (int ****)*param_3;
      }
      puStack_b0 = (undefined4 *)(uint)DAT_01d59810;
      ppppiStack_ac = (int ****)0x18c7578;
      uStack_b4 = 0x5dd684;
      ppppiStack_a4 = (int ****)param_2;
      FUN_01677520();
    }
    ppppiStack_a4 = (int ****)0x2f;
    ppppiStack_a8 = (int ****)0x18c75c8;
    uStack_54 = 0;
    puStack_50 = (undefined *)0xf;
    ppppiStack_64 = (int ****)((uint)ppppiStack_64 & 0xffffff00);
    ppppiStack_ac = (int ****)0x5dd6a8;
    FUN_005542c0();
    ppppiStack_a4 = (int ****)0x0;
    ppppiStack_ac = (int ****)&ppppiStack_64;
    uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
    ppppiStack_a8 = (int ****)0x1;
    puStack_b0 = (undefined4 *)0x5dd6b9;
    FUN_008783f0();
    ppppiStack_a4 = (int ****)0x5dd6c4;
    FUN_005507b0();
  }
  uStack_8._0_1_ = 5;
  uStack_8._1_3_ = 0;
  ppppiStack_a4 = (int ****)0x5dd6d3;
  FUN_00a12030();
  iVar10 = 0;
  if (0 < DAT_01d59818) {
    do {
      if (DAT_01ea8e28 != '\0') {
LAB_005dd9e7:
        if (DAT_01d59810 != 0) {
          if (0xf < (uint)param_3[5]) {
            param_3 = (undefined4 *)*param_3;
          }
          ppppiStack_ac = (int ****)(uint)DAT_01d59810;
          ppppiStack_a8 = (int ****)0x18c7698;
          puStack_b0 = (undefined4 *)0x5dda07;
          ppppiStack_a4 = (int ****)param_3;
          FUN_01677520();
        }
        ppppiStack_a4 = (int ****)0x21;
        ppppiStack_a8 = (int ****)0x18c76e4;
        uStack_54 = 0;
        puStack_50 = (undefined *)0xf;
        ppppiStack_64 = (int ****)((uint)ppppiStack_64 & 0xffffff00);
        ppppiStack_ac = (int ****)0x5dda2b;
        FUN_005542c0();
        ppppiStack_a4 = (int ****)0x0;
        ppppiStack_ac = (int ****)&ppppiStack_64;
        uStack_8._0_1_ = 0x14;
        ppppiStack_a8 = (int ****)0x1;
        puStack_b0 = (undefined4 *)0x5dda3c;
        FUN_008783f0();
        uStack_8._0_1_ = 5;
        uVar3 = (undefined)uStack_8;
        uStack_8._0_1_ = 5;
        if ((undefined *)0xf < puStack_50) {
          ppppiStack_a4 = (int ****)(puStack_50 + 1);
          pppppiVar7 = (int *****)ppppiStack_64;
          if ((undefined *)0xfff < ppppiStack_a4) {
            pppppiVar7 = (int *****)ppppiStack_64[-1];
            ppppiStack_a4 = (int ****)(puStack_50 + 0x24);
            if (0x1f < (uint)((int)ppppiStack_64 + (-4 - (int)pppppiVar7))) {
                    /* WARNING: Subroutine does not return */
              ppppiStack_a4 = (int ****)0x5dde36;
              uStack_8._0_1_ = uVar3;
              FUN_017167a3();
            }
          }
          ppppiStack_ac = (int ****)0x5dda74;
          ppppiStack_a8 = (int ****)pppppiVar7;
          FUN_01674ea0();
        }
        ppppiStack_a4 = (int ****)&cStack_15;
        cStack_15 = '\x01';
        ppppiStack_a8 = (int ****)0x5dda87;
        FUN_005df220();
        uStack_8._0_1_ = 4;
        uVar3 = (undefined)uStack_8;
        uStack_8._0_1_ = 4;
        if (7 < uStack_68) {
          ppppiStack_a4 = (int ****)(uStack_68 * 2 + 2);
          pcVar8 = uStack_7c;
          if (0xfff < ppppiStack_a4) {
            pcVar8 = *(code **)(uStack_7c + -4);
            ppppiStack_a4 = (int ****)(uStack_68 * 2 + 0x25);
            if ((code *)0x1f < uStack_7c + (-4 - (int)pcVar8)) {
                    /* WARNING: Subroutine does not return */
              ppppiStack_a4 = (int ****)0x5dde3b;
              uStack_8._0_1_ = uVar3;
              FUN_017167a3();
            }
          }
          ppppiStack_ac = (int ****)0x5ddac2;
          ppppiStack_a8 = (int ****)pcVar8;
          FUN_01674ea0();
        }
        uStack_6c = 0;
        uStack_68 = 7;
        uStack_7c = (code *)((uint)uStack_7c & 0xffff0000);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        if (7 < uStack_80) {
          ppppiStack_a4 = (int ****)(uStack_80 * 2 + 2);
          ppppiVar9 = uStack_94;
          if (0xfff < ppppiStack_a4) {
            ppppiVar9 = (int ****)uStack_94[-1];
            ppppiStack_a4 = (int ****)(uStack_80 * 2 + 0x25);
            if (0x1f < (uint)((int)uStack_94 + (-4 - (int)ppppiVar9))) {
                    /* WARNING: Subroutine does not return */
              ppppiStack_a4 = (int ****)0x5dde40;
              FUN_017167a3();
            }
          }
          ppppiStack_ac = (int ****)0x5ddb17;
          ppppiStack_a8 = ppppiVar9;
          FUN_01674ea0();
        }
        puVar5 = puStack_34;
        uStack_84 = 0;
        uStack_80 = 7;
        uStack_94 = (int ****)((uint)uStack_94 & 0xffff0000);
        uStack_8 = 0x15;
        if (((puStack_34 != (undefined4 *)0x0) &&
            (((cStack_30 == '\0' || (*(char *)(puStack_34 + 0x1b) == '\0')) &&
             (puStack_34[0x1c] == 0)))) && (*(char *)(puStack_34 + 0x1d) == '\0')) {
          ppppiStack_a4 = (int ****)&DAT_01ea8f84;
          ppppiStack_a8 = (int ****)FUN_005dbc60;
          ppppiStack_ac = (int ****)&DAT_01ea8f80;
          puStack_b0 = (undefined4 *)0x5ddb79;
          iVar10 = FUN_016de3db();
          if (iVar10 == 0) {
            ppppiStack_a4 = (int ****)0x5dde45;
            FUN_0171d16a();
            goto LAB_005dde45;
          }
          ppppiStack_a4 = (int ****)&uStack_44;
          ppuStack_48 = std::exception::vftable;
          ppppiStack_a8 = (int ****)&puStack_28;
          puStack_28 = &DAT_018bc9b8;
          uStack_24 = 1;
          uStack_44 = 0;
          ppppiStack_ac = (int ****)0x5ddbab;
          FUN_0170c226();
          ppuStack_48 = std::future_error::vftable;
          uStack_3c = 1;
          puStack_38 = &DAT_01ea8f84;
          ppppiStack_a4 = (int ****)0x0;
          uStack_bc = 0;
          FUN_0170c226(&uStack_44,&uStack_bc,std::exception::vftable);
          uStack_b4 = uStack_3c;
          puStack_b0 = (undefined4 *)puStack_38;
          FUN_005dbc80(&ppppiStack_ac,std::future_error::vftable);
          puStack_b0 = (undefined4 *)0x5ddc0f;
          FUN_005dcf20();
          ppppiStack_a4 = (int ****)&uStack_44;
          ppuStack_48 = std::exception::vftable;
          ppppiStack_a8 = (int ****)0x5ddc1f;
          FUN_0170c289();
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
        if (puVar5 == (undefined4 *)0x0) {
          ExceptionList = pvStack_10;
          return;
        }
        LOCK();
        piVar1 = puVar5 + 1;
        iVar10 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar10 != 1) {
          ExceptionList = pvStack_10;
          return;
        }
        if ((undefined4 *)puVar5[0x1e] != (undefined4 *)0x0) {
          ppppiStack_a4 = (int ****)puVar5;
          ppppiStack_a8 = (int ****)0x5ddc4d;
          (*(code *)**(undefined4 **)puVar5[0x1e])();
          ExceptionList = pvStack_10;
          return;
        }
        goto LAB_005dddf5;
      }
      ppppiStack_a4 = &pppiStack_4c;
      ppppiStack_a8 = (int ****)0x5dd6fa;
      pppppiVar7 = (int *****)FUN_016871c0();
      ppppiStack_a4 = (int ****)&ppppiStack_64;
      uStack_8._0_1_ = 0x12;
      ppppiStack_a8 = (int ****)0x5dd70f;
      ppppiStack_ac = (int ****)FUN_016871c0();
      ppppiStack_a4 = (int ****)param_4;
      uStack_8._0_1_ = 0x13;
      puStack_b0 = (undefined4 *)0x5dd71d;
      ppppiStack_a8 = (int ****)pppppiVar7;
      cVar4 = FUN_005de5d0();
      cStack_15 = cVar4 == '\0';
      uStack_8._0_1_ = 0x12;
      if ((undefined *)0xf < puStack_50) {
        ppppiStack_a4 = (int ****)(puStack_50 + 1);
        pppppiVar7 = (int *****)ppppiStack_64;
        if ((undefined *)0xfff < ppppiStack_a4) {
          pppppiVar7 = (int *****)ppppiStack_64[-1];
          ppppiStack_a4 = (int ****)(puStack_50 + 0x24);
          uVar3 = (undefined)uStack_8;
          if (0x1f < (uint)((int)ppppiStack_64 + (-4 - (int)pppppiVar7))) goto LAB_005dde22;
        }
        ppppiStack_ac = (int ****)0x5dd75b;
        ppppiStack_a8 = (int ****)pppppiVar7;
        FUN_01674ea0();
      }
      uStack_54 = 0;
      puStack_50 = (undefined *)0xf;
      ppppiStack_64 = (int ****)((uint)ppppiStack_64 & 0xffffff00);
      uStack_8._0_1_ = 5;
      if ((undefined *)0xf < puStack_38) {
        ppppiStack_a4 = (int ****)(puStack_38 + 1);
        ppppiVar9 = (int ****)pppiStack_4c;
        if ((undefined *)0xfff < ppppiStack_a4) {
          ppppiVar9 = (int ****)pppiStack_4c[-1];
          ppppiStack_a4 = (int ****)(puStack_38 + 0x24);
          uVar3 = (undefined)uStack_8;
          if (0x1f < (uint)((int)pppiStack_4c + (-4 - (int)ppppiVar9))) goto LAB_005dde22;
        }
        ppppiStack_ac = (int ****)0x5dd7a5;
        ppppiStack_a8 = ppppiVar9;
        FUN_01674ea0();
      }
      if (cStack_15 == '\0') {
        DAT_01ea8e28 = '\x01';
        goto LAB_005dd9e7;
      }
      if (DAT_01d59810 != 0) {
        ppppiStack_a4 = (int ****)param_3;
        if (0xf < (uint)param_3[5]) {
          ppppiStack_a4 = (int ****)*param_3;
        }
        ppppiStack_ac = (int ****)(uint)DAT_01d59810;
        ppppiStack_a8 = (int ****)0x18c7708;
        puStack_b0 = (undefined4 *)0x5dd7d4;
        FUN_01677520();
      }
      ppppiStack_a4 = (int ****)0x41;
      ppppiStack_a8 = (int ****)0x18c7748;
      uStack_54 = 0;
      puStack_50 = (undefined *)0xf;
      ppppiStack_64 = (int ****)((uint)ppppiStack_64 & 0xffffff00);
      ppppiStack_ac = (int ****)0x5dd7f8;
      FUN_005542c0();
      ppppiStack_a8 = (int ****)&ppppiStack_64;
      uStack_8._0_1_ = 0x17;
      ppppiStack_a4 = (int ****)0x0;
      ppppiStack_ac = (int ****)0x5dd807;
      FUN_00878480();
      uStack_8._0_1_ = 5;
      if ((undefined *)0xf < puStack_50) {
        ppppiStack_a4 = (int ****)(puStack_50 + 1);
        pppppiVar7 = (int *****)ppppiStack_64;
        if ((undefined *)0xfff < ppppiStack_a4) {
          pppppiVar7 = (int *****)ppppiStack_64[-1];
          ppppiStack_a4 = (int ****)(puStack_50 + 0x24);
          uVar3 = (undefined)uStack_8;
          if (0x1f < (uint)((int)ppppiStack_64 + (-4 - (int)pppppiVar7))) goto LAB_005dde22;
        }
        ppppiStack_ac = (int ****)0x5dd83f;
        ppppiStack_a8 = (int ****)pppppiVar7;
        FUN_01674ea0();
      }
      iVar10 = iVar10 + 1;
    } while (iVar10 < DAT_01d59818);
  }
  ppppiStack_a4 = (int ****)&cStack_15;
  cStack_15 = '\0';
  ppppiStack_a8 = (int ****)0x5dd85f;
  FUN_005df220();
  uStack_8._0_1_ = 4;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 4;
  if (7 < uStack_68) {
    uVar2 = uStack_68 * 2 + 2;
    if (0xfff < uVar2) {
      if ((code *)0x1f < uStack_7c + (-4 - *(int *)(uStack_7c + -4))) {
                    /* WARNING: Subroutine does not return */
        ppppiStack_a4 = (int ****)0x5dde31;
        uStack_8._0_1_ = uVar3;
        FUN_017167a3();
      }
      FUN_005ddc5e();
      return;
    }
    ppppiStack_a8 = (int ****)uStack_7c;
    ppppiStack_ac = (int ****)0x5ddc65;
    ppppiStack_a4 = (int ****)uVar2;
    FUN_01674ea0();
  }
  uStack_6c = 0;
  uStack_68 = 7;
  uStack_7c = (code *)((uint)uStack_7c & 0xffff0000);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (7 < uStack_80) {
    ppppiStack_a4 = (int ****)(uStack_80 * 2 + 2);
    ppppiVar9 = uStack_94;
    if (0xfff < ppppiStack_a4) {
      ppppiVar9 = (int ****)uStack_94[-1];
      ppppiStack_a4 = (int ****)(uStack_80 * 2 + 0x25);
      if (0x1f < (uint)((int)uStack_94 + (-4 - (int)ppppiVar9))) {
LAB_005dde45:
                    /* WARNING: Subroutine does not return */
        ppppiStack_a4 = (int ****)0x5dde4a;
        FUN_017167a3();
      }
    }
    ppppiStack_ac = (int ****)0x5ddcba;
    ppppiStack_a8 = ppppiVar9;
    FUN_01674ea0();
  }
  puVar5 = puStack_34;
  uStack_84 = 0;
  uStack_80 = 7;
  uStack_94 = (int ****)((uint)uStack_94 & 0xffff0000);
  uStack_8 = 0x18;
  if (((puStack_34 != (undefined4 *)0x0) &&
      ((cStack_30 == '\0' || (*(char *)(puStack_34 + 0x1b) == '\0')))) &&
     ((puStack_34[0x1c] == 0 && (*(char *)(puStack_34 + 0x1d) == '\0')))) {
    ppppiStack_a4 = (int ****)&DAT_01ea8f84;
    ppppiStack_a8 = (int ****)FUN_005dbc60;
    ppppiStack_ac = (int ****)&DAT_01ea8f80;
    puStack_b0 = (undefined4 *)0x5ddd1c;
    iVar10 = FUN_016de3db();
    if (iVar10 == 0) {
      ppppiStack_a4 = (int ****)0x5dde4f;
      FUN_0171d16a();
      pcVar8 = (code *)swi(3);
      (*pcVar8)();
      return;
    }
    ppppiStack_a4 = (int ****)&uStack_5c;
    ppuStack_60 = std::exception::vftable;
    ppppiStack_a8 = (int ****)&puStack_20;
    puStack_20 = &DAT_018bc9b8;
    puStack_1c = (undefined4 *)CONCAT31(puStack_1c._1_3_,1);
    uStack_5c = 0;
    ppppiStack_ac = (int ****)0x5ddd4e;
    FUN_0170c226();
    ppuStack_60 = std::future_error::vftable;
    uStack_54 = 1;
    puStack_50 = &DAT_01ea8f84;
    ppppiStack_a4 = (int ****)0x0;
    uStack_bc = 0;
    FUN_0170c226(&uStack_5c,&uStack_bc,std::exception::vftable);
    uStack_b4 = uStack_54;
    puStack_b0 = (undefined4 *)puStack_50;
    FUN_005dbc80(&ppppiStack_ac,std::future_error::vftable);
    puStack_b0 = (undefined4 *)0x5dddb2;
    FUN_005dcf20();
    ppppiStack_a4 = (int ****)&uStack_5c;
    ppuStack_60 = std::exception::vftable;
    ppppiStack_a8 = (int ****)0x5dddc2;
    FUN_0170c289();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    piVar1 = puVar5 + 1;
    iVar10 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar10 == 1) {
      if ((undefined4 *)puVar5[0x1e] != (undefined4 *)0x0) {
        ppppiStack_a4 = (int ****)puVar5;
        ppppiStack_a8 = (int ****)0x5ddde4;
        (*(code *)**(undefined4 **)puVar5[0x1e])();
        ExceptionList = pvStack_10;
        return;
      }
LAB_005dddf5:
      ppppiStack_a4 = (int ****)0x1;
      ppppiStack_a8 = (int ****)0x5dddfd;
      (**(code **)*puVar5)();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5606 ; VA 0x005dd8a0 ; Catch_All@005dd8a0 */

undefined * Catch_All_005dd8a0(void)

{
  int unaff_EBP;
  char *pcStack_8;
  int iStack_4;
  
  if (DAT_01d59810 != '\0') {
    iStack_4 = *(undefined4 *)(unaff_EBP + 8);
    if (0xf < *(uint *)(iStack_4 + 0x14)) {
      iStack_4 = *(int *)iStack_4;
    }
    pcStack_8 = "External AntiCheat Module Library failed to download from \'%s\'";
    FUN_01677520(DAT_01d59810);
  }
  iStack_4 = 0x4a;
  pcStack_8 = "ExternalAntiCheat_Errors_All,ExternalAntiCheat_Errors_ModuleDownloadFailed";
  *(undefined4 *)(unaff_EBP + -0x50) = 0;
  *(undefined4 *)(unaff_EBP + -0x4c) = 0xf;
  *(undefined *)(unaff_EBP + -0x60) = 0;
  FUN_005542c0();
  pcStack_8 = (char *)(unaff_EBP + -0x60);
  *(undefined *)(unaff_EBP + -4) = 0xc;
  iStack_4 = 0;
  FUN_00878480();
  *(undefined *)(unaff_EBP + -4) = 0xb;
  iStack_4 = 0x5dd906;
  FUN_005507b0();
  FUN_005de200(&pcStack_8);
  FUN_005df180();
  return &LAB_005dd920;
}



/* FUNCTION 5607 ; VA 0x005dd954 ; Catch_All@005dd954 */

undefined * Catch_All_005dd954(void)

{
  int unaff_EBP;
  char *pcStack_8;
  int iStack_4;
  
  if (DAT_01d59810 != '\0') {
    iStack_4 = *(undefined4 *)(unaff_EBP + 0xc);
    if (0xf < *(uint *)(iStack_4 + 0x14)) {
      iStack_4 = *(int *)iStack_4;
    }
    pcStack_8 = *(char **)(unaff_EBP + 0x10);
    if (0xf < *(uint *)((int)pcStack_8 + 0x14)) {
      pcStack_8 = *(char **)pcStack_8;
    }
    FUN_01677520(DAT_01d59810,
                 "External AntiCheat Dependency Library \'%s\' failed to downloaded from \'%s\'");
  }
  iStack_4 = 0x4e;
  pcStack_8 = "ExternalAntiCheat_Errors_All,ExternalAntiCheat_Errors_DependencyDownloadFailed";
  *(undefined4 *)(unaff_EBP + -0x50) = 0;
  *(undefined4 *)(unaff_EBP + -0x4c) = 0xf;
  *(undefined *)(unaff_EBP + -0x60) = 0;
  FUN_005542c0();
  pcStack_8 = (char *)(unaff_EBP + -0x60);
  *(undefined *)(unaff_EBP + -4) = 0x11;
  iStack_4 = 0;
  FUN_00878480();
  *(undefined *)(unaff_EBP + -4) = 0x10;
  iStack_4 = 0x5dd9c6;
  FUN_005507b0();
  FUN_005de200(&pcStack_8);
  FUN_005df180();
  return &LAB_005dd920;
}



/* FUNCTION 5608 ; VA 0x005ddc5e ; FUN_005ddc5e */

void __fastcall FUN_005ddc5e(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  code *pcVar4;
  int iVar5;
  int unaff_EBP;
  undefined8 uStack_1c;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined *puStack_c;
  code *pcStack_8;
  undefined4 *puStack_4;
  
  puStack_c = (undefined *)0x5ddc65;
  puStack_4 = (undefined4 *)param_2;
  FUN_01674ea0();
  *(undefined4 *)(unaff_EBP + -0x68) = 0;
  *(undefined4 *)(unaff_EBP + -100) = 7;
  *(undefined2 *)(unaff_EBP + -0x78) = 0;
  *(undefined *)(unaff_EBP + -4) = 1;
  if (7 < *(uint *)(unaff_EBP + -0x7c)) {
    iVar2 = *(int *)(unaff_EBP + -0x90);
    iVar5 = *(uint *)(unaff_EBP + -0x7c) * 2;
    puStack_4 = (undefined4 *)(iVar5 + 2);
    pcStack_8 = (code *)iVar2;
    if (0xfff < puStack_4) {
      pcStack_8 = *(code **)(iVar2 + -4);
      puStack_4 = (undefined4 *)(iVar5 + 0x25);
      if (0x1f < (iVar2 - (int)pcStack_8) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_4 = (undefined4 *)0x5dde4a;
        FUN_017167a3();
      }
    }
    puStack_c = (undefined *)0x5ddcba;
    FUN_01674ea0();
  }
  *(undefined4 *)(unaff_EBP + -0x80) = 0;
  *(undefined4 *)(unaff_EBP + -0x7c) = 7;
  *(undefined2 *)(unaff_EBP + -0x90) = 0;
  puVar3 = *(undefined4 **)(unaff_EBP + -0x30);
  *(undefined4 *)(unaff_EBP + -4) = 0x18;
  if (((puVar3 != (undefined4 *)0x0) &&
      (((*(char *)(unaff_EBP + -0x2c) == '\0' || (*(char *)(puVar3 + 0x1b) == '\0')) &&
       (puVar3[0x1c] == 0)))) && (*(char *)(puVar3 + 0x1d) == '\0')) {
    puStack_4 = (undefined4 *)&DAT_01ea8f84;
    pcStack_8 = FUN_005dbc60;
    puStack_c = &DAT_01ea8f80;
    uStack_10 = 0x5ddd1c;
    iVar5 = FUN_016de3db();
    if (iVar5 == 0) {
      puStack_4 = (undefined4 *)0x5dde4f;
      FUN_0171d16a();
      pcVar4 = (code *)swi(3);
      (*pcVar4)();
      return;
    }
    puStack_4 = (undefined4 *)(unaff_EBP + -0x58);
    *(undefined ***)(unaff_EBP + -0x5c) = std::exception::vftable;
    pcStack_8 = (code *)(unaff_EBP + -0x1c);
    *(undefined1 **)(unaff_EBP + -0x1c) = &DAT_018bc9b8;
    *(undefined *)(unaff_EBP + -0x18) = 1;
    *(undefined8 *)(unaff_EBP + -0x58) = 0;
    puStack_c = (undefined *)0x5ddd4e;
    FUN_0170c226();
    *(undefined ***)(unaff_EBP + -0x5c) = std::future_error::vftable;
    *(undefined4 *)(unaff_EBP + -0x50) = 1;
    *(undefined **)(unaff_EBP + -0x4c) = &DAT_01ea8f84;
    puStack_4 = (undefined4 *)0x0;
    uStack_1c = 0;
    FUN_0170c226(unaff_EBP + -0x58,&uStack_1c,std::exception::vftable);
    uStack_14 = *(undefined4 *)(unaff_EBP + -0x50);
    uStack_10 = *(undefined4 *)(unaff_EBP + -0x4c);
    FUN_005dbc80(&puStack_c,std::future_error::vftable);
    uStack_10 = 0x5dddb2;
    FUN_005dcf20();
    puStack_4 = (undefined4 *)(unaff_EBP + -0x58);
    *(undefined ***)(unaff_EBP + -0x5c) = std::exception::vftable;
    pcStack_8 = (code *)0x5dddc2;
    FUN_0170c289();
  }
  *(undefined *)(unaff_EBP + -4) = 0x19;
  if (puVar3 != (undefined4 *)0x0) {
    LOCK();
    piVar1 = puVar3 + 1;
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      if ((undefined4 *)puVar3[0x1e] != (undefined4 *)0x0) {
        pcStack_8 = (code *)0x5ddde4;
        puStack_4 = puVar3;
        (*(code *)**(undefined4 **)puVar3[0x1e])();
        ExceptionList = *(void **)(unaff_EBP + -0xc);
        return;
      }
      puStack_4 = (undefined4 *)0x1;
      pcStack_8 = (code *)0x5dddfd;
      (**(code **)*puVar3)();
    }
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 5609 ; VA 0x005dde50 ; FUN_005dde50 */

undefined FUN_005dde50(void)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined *puVar6;
  undefined4 uVar7;
  undefined auStack_5c [16];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined auStack_3c [8];
  int *piStack_34;
  undefined uStack_30;
  int *piStack_2c;
  undefined uStack_28;
  int iStack_24;
  int iStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = DAT_01ea8e58;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179aac0;
  pvStack_10 = ExceptionList;
  iStack_24 = DAT_01d59820 * DAT_01d59828;
  piStack_18 = DAT_01ea8e58;
  iStack_20 = iStack_24 >> 0x1f;
  if ((DAT_01ea8e58 == (int *)0x0) ||
     ((DAT_01ea8e5c != '\0' && (*(char *)(DAT_01ea8e58 + 0x1b) != '\0')))) {
    ExceptionList = &pvStack_10;
    uVar7 = FUN_005deb10(auStack_3c,4);
                    /* WARNING: Subroutine does not return */
    FUN_016dfe59(uVar7);
  }
  piVar1 = DAT_01ea8e58 + 5;
  ExceptionList = &pvStack_10;
  piStack_2c = piVar1;
  iVar4 = FUN_016dee6d(piVar1);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  uStack_28 = 1;
  uStack_8 = 0;
  cVar3 = (**(code **)(*piVar2 + 0xc))();
  if (cVar3 == '\0') {
    piStack_1c = piVar2 + 0x11;
    puVar5 = (undefined4 *)FUN_0054dbf0(auStack_5c,&iStack_24);
    uStack_4c = *puVar5;
    uStack_48 = puVar5[1];
    uStack_44 = puVar5[2];
    uStack_40 = puVar5[3];
    iVar4 = piVar2[0x1c];
    while (iVar4 == 0) {
      iVar4 = FUN_016dedc0(piVar1);
      if (iVar4 == 0) {
        FUN_016df3f6(4);
      }
      iVar4 = FUN_016df1bf(piStack_1c,piVar1,&uStack_4c);
      if (iVar4 != 0) {
        if (iVar4 != 2) {
          FUN_016df3c9(iVar4);
          goto LAB_005ddf43;
        }
LAB_005ddfe4:
        if (piStack_18[0x1c] == 0) {
          uStack_8 = 3;
          iVar4 = FUN_016deec8(piVar1);
          if (iVar4 != 0) {
            FUN_016df3c9(iVar4);
          }
          uStack_8 = 0xffffffff;
          if (DAT_01d84e8e != '\0') {
            FUN_01677520(DAT_01d84e8e,
                         "ExternalAntiCheatModule::asyncDownloadLibrariesAndInit promise timed out."
                        );
          }
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("ExternalAntiCheatModule::asyncDownloadLibrariesAndInit promise timed out.");
        }
        break;
      }
LAB_005ddf43:
      if (iVar4 == 2) goto LAB_005ddfe4;
      iVar4 = piStack_18[0x1c];
    }
    uStack_8 = 2;
  }
  else {
    uStack_8 = 1;
  }
  iVar4 = FUN_016deec8(piVar1);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  piVar2 = DAT_01ea8e58;
  piStack_34 = DAT_01ea8e58;
  DAT_01ea8e58 = (int *)0x0;
  uStack_30 = 1;
  uStack_8 = 5;
  if ((piVar2 != (int *)0x0) && (*(char *)(piVar2 + 0x1b) == '\0')) {
    puVar6 = (undefined *)(**(code **)(*piVar2 + 8))(1);
    uStack_11 = *puVar6;
    uStack_8 = 6;
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      if ((undefined4 *)piVar2[0x1e] != (undefined4 *)0x0) {
        (*(code *)**(undefined4 **)piVar2[0x1e])(piVar2);
        ExceptionList = pvStack_10;
        return uStack_11;
      }
      (**(code **)*piVar2)(1);
    }
    ExceptionList = pvStack_10;
    return uStack_11;
  }
  uVar7 = FUN_005deb10(&piStack_2c,4);
                    /* WARNING: Subroutine does not return */
  FUN_016dfe59(uVar7);
}



/* FUNCTION 5610 ; VA 0x005de080 ; FUN_005de080 */

undefined4 FUN_005de080(undefined4 param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iStack_58;
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179aaf0;
  pvStack_10 = ExceptionList;
  uStack_30 = 0;
  uStack_2c = 7;
  auStack_40[0] = auStack_40[0] & 0xffff0000;
  uStack_8 = 0;
  iVar3 = param_2[4];
  ExceptionList = &pvStack_10;
  if (iVar3 != 0) {
    puVar2 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar2 = (undefined4 *)*param_2;
    }
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01686580();
    FUN_01685950(param_2,iVar3 + (int)puVar2,auStack_40,uVar1);
  }
  uStack_8 = 1;
  FUN_0168bf40(auStack_28,0);
  uStack_8._0_1_ = 2;
  FUN_0054f050(auStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uVar1 = FUN_01686150(auStack_40);
  FUN_0054f050(uVar1);
  if (7 < uStack_44) {
    uVar5 = uStack_44 * 2 + 2;
    iVar3 = iStack_58;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(iStack_58 + -4);
      uVar5 = uStack_44 * 2 + 0x25;
      if (0x1f < (iStack_58 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  if (7 < uStack_14) {
    uVar5 = uStack_14 * 2 + 2;
    uVar4 = auStack_28[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_28[0] - 4);
      uVar5 = uStack_14 * 2 + 0x25;
      if (0x1f < (auStack_28[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  uStack_18 = 0;
  uStack_14 = 7;
  auStack_28[0] = auStack_28[0] & 0xffff0000;
  if (7 < uStack_2c) {
    uVar5 = uStack_2c * 2 + 2;
    uVar4 = auStack_40[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_40[0] - 4);
      uVar5 = uStack_2c * 2 + 0x25;
      if (0x1f < (auStack_40[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5611 ; VA 0x005de200 ; FUN_005de200 */

undefined4 FUN_005de200(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_0179a980;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_016dfd92(param_1);
  uStack_8 = uStack_8 & 0xffffff00;
  FUN_016dfda1(param_1);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5612 ; VA 0x005de250 ; FUN_005de250 */

undefined4 FUN_005de250(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179ab08;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005df440(param_1,param_2,param_3,DAT_01d59828);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5613 ; VA 0x005de2b2 ; Catch@005de2b2 */

undefined4 Catch_005de2b2(void)

{
  char cVar1;
  int iVar2;
  int unaff_EBP;
  int iVar3;
  
  cVar1 = DAT_01d59810;
  iVar2 = *(int *)(unaff_EBP + -0x14);
  iVar3 = iVar2 + 1;
  *(int *)(unaff_EBP + -0x14) = iVar3;
  if (cVar1 != '\0') {
    FUN_01677520(cVar1,"Failed to download external anticheat library file. Attempt %d...",iVar3);
  }
  *(undefined4 *)(unaff_EBP + -0x34) = 0;
  *(undefined4 *)(unaff_EBP + -0x30) = 0xf;
  *(undefined *)(unaff_EBP + -0x44) = 0;
  FUN_005542c0("ExternalAntiCheat_Errors_All,ExternalAntiCheat_Errors_LibDownloadAttempt",0x48);
  *(undefined *)(unaff_EBP + -4) = 2;
  FUN_00878480(unaff_EBP + -0x44,0);
  *(undefined *)(unaff_EBP + -4) = 1;
  FUN_005507b0();
  if (iVar3 < DAT_01d59820) {
    iVar2 = 2 << ((char)iVar2 + 2U & 0x1f);
    if (DAT_01d59828 < iVar2) {
      iVar2 = DAT_01d59828;
    }
    iVar2 = FUN_01679e20(0,0,iVar2,iVar2 >> 0x1f);
    if (DAT_01d84e8e != '\0') {
      FUN_01677520(DAT_01d84e8e,
                   "ExternalAntiCheatModule::downloadLibrary failed, trying again after %d seconds delay..."
                   ,iVar2);
    }
    *(int *)(unaff_EBP + -0x20) = iVar2;
    *(int *)(unaff_EBP + -0x1c) = iVar2 >> 0x1f;
    FUN_0054e4d0(unaff_EBP + -0x20);
    return 0x5de280;
  }
  FUN_0054fe90(*(undefined4 *)(unaff_EBP + -0x18));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(unaff_EBP + -0x2c,&DAT_01c243ac);
}



/* FUNCTION 5614 ; VA 0x005de3a0 ; FUN_005de3a0 */

undefined8 * FUN_005de3a0(undefined8 *param_1,int *param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  undefined8 uVar4;
  
  uVar4 = FUN_00928340();
  iVar1 = *param_2;
  piVar2 = *(int **)(iVar1 + 0x28);
  *param_1 = uVar4;
  if (0xf < (uint)piVar2[5]) {
    piVar2 = (int *)*piVar2;
  }
  piVar3 = *(int **)(iVar1 + 0x378);
  *(int **)(param_1 + 1) = piVar2;
  *(undefined4 *)((int)param_1 + 0xc) = param_4;
  *(undefined4 *)(param_1 + 2) = param_3;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar3[1] = piVar3[1] + 1;
    UNLOCK();
    piVar3 = *(int **)(iVar1 + 0x378);
  }
  piVar2 = *(int **)(iVar1 + 0x374);
  if (0xf < (uint)piVar2[5]) {
    piVar2 = (int *)*piVar2;
  }
  *(int **)((int)param_1 + 0x14) = piVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar1 = piVar3[1] + -1;
    piVar3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar1 = piVar3[2] + -1;
      piVar3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  iVar1 = *param_2;
  piVar2 = *(int **)(iVar1 + 0x378);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar2[1] = piVar2[1] + 1;
    UNLOCK();
    piVar2 = *(int **)(iVar1 + 0x378);
  }
  *(undefined4 *)(param_1 + 3) = *(undefined4 *)(*(int *)(iVar1 + 0x374) + 0x18);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar1 = piVar2[1] + -1;
    piVar2[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar3 = piVar2 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 5615 ; VA 0x005de470 ; FUN_005de470 */

undefined4 *
FUN_005de470(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  param_1[2] = param_4;
  param_1[3] = param_5;
  param_1[4] = param_6;
  *param_1 = param_2;
  param_1[5] = param_7;
  param_1[1] = param_3;
  param_1[6] = param_8;
  return param_1;
}



/* FUNCTION 5616 ; VA 0x005de4b0 ; FUN_005de4b0 */

undefined8 * FUN_005de4b0(undefined8 *param_1,int *param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  undefined8 uVar6;
  int aiStack_1c [5];
  uint uStack_8;
  
  uVar6 = FUN_00928340();
  piVar1 = *(int **)(*param_2 + 0x28);
  *param_1 = uVar6;
  if (0xf < (uint)piVar1[5]) {
    piVar1 = (int *)*piVar1;
  }
  *(int **)(param_1 + 1) = piVar1;
  puVar2 = (undefined4 *)FUN_00927540(aiStack_1c);
  if (0xf < (uint)puVar2[5]) {
    puVar2 = (undefined4 *)*puVar2;
  }
  *(undefined4 **)((int)param_1 + 0xc) = puVar2;
  if (0xf < uStack_8) {
    uVar5 = uStack_8 + 1;
    iVar4 = aiStack_1c[0];
    if (0xfff < uVar5) {
      iVar4 = *(int *)(aiStack_1c[0] + -4);
      uVar5 = uStack_8 + 0x24;
      if (0x1f < (aiStack_1c[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 2) = param_3;
  iVar4 = *param_2;
  piVar1 = *(int **)(iVar4 + 0x378);
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar1[1] = piVar1[1] + 1;
    UNLOCK();
    piVar1 = *(int **)(iVar4 + 0x378);
  }
  piVar3 = *(int **)(iVar4 + 0x374);
  if (0xf < (uint)piVar3[5]) {
    piVar3 = (int *)*piVar3;
  }
  *(int **)((int)param_1 + 0x14) = piVar3;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  iVar4 = *param_2;
  piVar1 = *(int **)(iVar4 + 0x378);
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar1[1] = piVar1[1] + 1;
    UNLOCK();
    piVar1 = *(int **)(iVar4 + 0x378);
  }
  *(undefined4 *)(param_1 + 3) = *(undefined4 *)(*(int *)(iVar4 + 0x374) + 0x18);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar3 = piVar1 + 2;
      iVar4 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 5617 ; VA 0x005de5d0 ; FUN_005de5d0 */

undefined FUN_005de5d0(char *param_1,undefined4 *param_2,char *param_3)

{
  undefined ***pppuVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined uVar5;
  char *pcVar6;
  undefined **ppuStack_64;
  int iStack_60;
  undefined ***pppuStack_40;
  undefined **ppuStack_3c;
  int iStack_38;
  undefined ***pppuStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ab60;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x10) == 0) {
    pcVar6 = "ExternalAntiCheatModule.dll";
  }
  else {
    pcVar6 = param_1;
    if (0xf < *(uint *)(param_1 + 0x14)) {
      pcVar6 = *(char **)param_1;
    }
  }
  ExceptionList = &pvStack_10;
  iVar2 = LoadLibraryA(pcVar6);
  if (iVar2 == 0) {
    if (DAT_01d59810 != '\0') {
      FUN_01677520(DAT_01d59810,
                   "LoadLibrary failed for %s. Failed to load external anticheat library.",
                   "ExternalAntiCheatModule.dll");
    }
    ExceptionList = pvStack_10;
    return 0;
  }
  iVar3 = GetProcAddress(iVar2,"Initialize");
  if (iVar3 == 0) {
    if (DAT_01d59810 != '\0') {
      FUN_01677520(DAT_01d59810,
                   "GetProcAddress failed for %s. Failed to find function in external anticheat library."
                   ,"Initialize");
    }
    ExceptionList = pvStack_10;
    return 0;
  }
  pppuStack_40 = (undefined ***)0x0;
  if (iVar3 != 0) {
    pppuStack_40 = &ppuStack_64;
    ppuStack_64 = std::
                  _Func_impl_no_alloc<int_(__cdecl*)(char_const*,int_(__cdecl*)(unsigned___int64,unsigned_char_const*,int)),int,char_const*,int_(__cdecl*)(unsigned___int64,unsigned_char_const*,int)>
                  ::vftable;
    iStack_60 = iVar3;
  }
  uStack_8 = 0;
  iVar3 = GetProcAddress(iVar2,"AddUserOpenID");
  if (iVar3 == 0) {
    if (DAT_01d59810 != '\0') {
      FUN_01677520(DAT_01d59810,
                   "GetProcAddress failed for %s. Failed to find function in external anticheat library."
                   ,"AddUserOpenID");
    }
  }
  else {
    pppuStack_18 = (undefined ***)0x0;
    if (iVar3 != 0) {
      ppuStack_3c = std::
                    _Func_impl_no_alloc<int_(__cdecl*)(unsigned___int64,char_const*,unsigned_long,char_const*,int),int,unsigned___int64,char_const*,unsigned_long,char_const*,int>
                    ::vftable;
      iStack_38 = iVar3;
      pppuStack_18 = &ppuStack_3c;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (DAT_01ea8edc != (undefined ***)0x0) {
      (*(code *)(*DAT_01ea8edc)[4])
                (CONCAT31((int3)((uint)*DAT_01ea8edc >> 8),
                          DAT_01ea8edc != (undefined ***)&DAT_01ea8eb8));
      DAT_01ea8edc = (undefined ***)0x0;
    }
    if (pppuStack_18 != (undefined ***)0x0) {
      pppuVar1 = pppuStack_18;
      if (pppuStack_18 == &ppuStack_3c) {
        DAT_01ea8edc = (undefined ***)(*(code *)(*pppuStack_18)[1])(&DAT_01ea8eb8);
        if (pppuStack_18 == (undefined ***)0x0) goto LAB_005de785;
        (*(code *)(*pppuStack_18)[4])
                  (CONCAT31((int3)((uint)&ppuStack_3c >> 8),pppuStack_18 != &ppuStack_3c));
        pppuVar1 = DAT_01ea8edc;
      }
      DAT_01ea8edc = pppuVar1;
      pppuStack_18 = (undefined ***)0x0;
    }
LAB_005de785:
    uStack_8 = uStack_8 & 0xffffff00;
    if (pppuStack_18 != (undefined ***)0x0) {
      (*(code *)(*pppuStack_18)[4])
                (CONCAT31((int3)((uint)&ppuStack_3c >> 8),pppuStack_18 != &ppuStack_3c));
    }
    iVar3 = FUN_005dc530(iVar2,"RemoveUserOpenID");
    if (iVar3 != 0) {
      pppuStack_18 = (undefined ***)0x0;
      if (iVar3 != 0) {
        ppuStack_3c = std::
                      _Func_impl_no_alloc<int_(__cdecl*)(unsigned___int64,char_const*,char_const*,int),int,unsigned___int64,char_const*,char_const*,int>
                      ::vftable;
        iStack_38 = iVar3;
        pppuStack_18 = &ppuStack_3c;
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (DAT_01ea8f04 != (undefined ***)0x0) {
        (*(code *)(*DAT_01ea8f04)[4])
                  (CONCAT31((int3)((uint)*DAT_01ea8f04 >> 8),
                            DAT_01ea8f04 != (undefined ***)&DAT_01ea8ee0));
        DAT_01ea8f04 = (undefined ***)0x0;
      }
      if (pppuStack_18 != (undefined ***)0x0) {
        pppuVar1 = pppuStack_18;
        if (pppuStack_18 == &ppuStack_3c) {
          DAT_01ea8f04 = (undefined ***)(*(code *)(*pppuStack_18)[1])(&DAT_01ea8ee0);
          if (pppuStack_18 == (undefined ***)0x0) goto LAB_005de838;
          (*(code *)(*pppuStack_18)[4])
                    (CONCAT31((int3)((uint)&ppuStack_3c >> 8),pppuStack_18 != &ppuStack_3c));
          pppuVar1 = DAT_01ea8f04;
        }
        DAT_01ea8f04 = pppuVar1;
        pppuStack_18 = (undefined ***)0x0;
      }
LAB_005de838:
      uStack_8 = uStack_8 & 0xffffff00;
      if (pppuStack_18 != (undefined ***)0x0) {
        (*(code *)(*pppuStack_18)[4])
                  (CONCAT31((int3)((uint)&ppuStack_3c >> 8),pppuStack_18 != &ppuStack_3c));
      }
      iVar3 = FUN_005dc530(iVar2,"SendSecurityReportOpenID");
      if (iVar3 != 0) {
        pppuStack_18 = (undefined ***)0x0;
        if (iVar3 != 0) {
          ppuStack_3c = std::
                        _Func_impl_no_alloc<int_(__cdecl*)(unsigned___int64,char_const*,unsigned_char_const*,int,char_const*,int),int,unsigned___int64,char_const*,unsigned_char_const*,int,char_const*,int>
                        ::vftable;
          iStack_38 = iVar3;
          pppuStack_18 = &ppuStack_3c;
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        if (DAT_01ea8e54 != (undefined ***)0x0) {
          (*(code *)(*DAT_01ea8e54)[4])
                    (CONCAT31((int3)((uint)*DAT_01ea8e54 >> 8),
                              DAT_01ea8e54 != (undefined ***)&DAT_01ea8e30));
          DAT_01ea8e54 = (undefined ***)0x0;
        }
        if (pppuStack_18 != (undefined ***)0x0) {
          pppuVar1 = pppuStack_18;
          if (pppuStack_18 == &ppuStack_3c) {
            DAT_01ea8e54 = (undefined ***)(*(code *)(*pppuStack_18)[1])(&DAT_01ea8e30);
            if (pppuStack_18 == (undefined ***)0x0) goto LAB_005de8ed;
            (*(code *)(*pppuStack_18)[4])
                      (CONCAT31((int3)((uint)&ppuStack_3c >> 8),pppuStack_18 != &ppuStack_3c));
            pppuVar1 = DAT_01ea8e54;
          }
          DAT_01ea8e54 = pppuVar1;
          pppuStack_18 = (undefined ***)0x0;
        }
LAB_005de8ed:
        uStack_8 = uStack_8 & 0xffffff00;
        FUN_0056b7d0();
        iVar3 = FUN_005dc530(iVar2,"Shutdown");
        if (iVar3 != 0) {
          pppuStack_18 = (undefined ***)0x0;
          if (iVar3 != 0) {
            ppuStack_3c = std::_Func_impl_no_alloc<int_(__cdecl*)(void),int>::vftable;
            iStack_38 = iVar3;
            pppuStack_18 = &ppuStack_3c;
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          if (DAT_01ea8f7c != (undefined ***)0x0) {
            (*(code *)(*DAT_01ea8f7c)[4])
                      (CONCAT31((int3)((uint)*DAT_01ea8f7c >> 8),
                                DAT_01ea8f7c != (undefined ***)&DAT_01ea8f58));
            DAT_01ea8f7c = (undefined ***)0x0;
          }
          if (pppuStack_18 != (undefined ***)0x0) {
            pppuVar1 = pppuStack_18;
            if (pppuStack_18 == &ppuStack_3c) {
              DAT_01ea8f7c = (undefined ***)(*(code *)(*pppuStack_18)[1])(&DAT_01ea8f58);
              if (pppuStack_18 == (undefined ***)0x0) goto LAB_005de996;
              (*(code *)(*pppuStack_18)[4])
                        (CONCAT31((int3)((uint)&ppuStack_3c >> 8),pppuStack_18 != &ppuStack_3c));
              pppuVar1 = DAT_01ea8f7c;
            }
            DAT_01ea8f7c = pppuVar1;
            pppuStack_18 = (undefined ***)0x0;
          }
LAB_005de996:
          uStack_8 = uStack_8 & 0xffffff00;
          FUN_0056b7d0();
          if (DAT_01d59834 == '\0') {
LAB_005deacc:
            puStack_14 = param_2;
            if (0xf < (uint)param_2[5]) {
              puStack_14 = (undefined4 *)*param_2;
            }
            param_1 = param_3;
            if (pppuStack_40 == (undefined ***)0x0) {
                    /* WARNING: Subroutine does not return */
              FUN_016ddc9c();
            }
            iVar2 = (*(code *)(*pppuStack_40)[2])(&puStack_14,&param_1);
            if (iVar2 == 0) {
              uVar5 = 1;
              goto LAB_005de6d5;
            }
          }
          else {
            iVar3 = FUN_005dc530(iVar2,"AddUser");
            if (iVar3 != 0) {
              uVar4 = FUN_005dbc30(iVar3);
              uStack_8._0_1_ = 5;
              FUN_005dc090(uVar4);
              uStack_8 = (uint)uStack_8._1_3_ << 8;
              FUN_0056b7d0();
              iVar3 = FUN_005dc530(iVar2,"RemoveUser");
              if (iVar3 != 0) {
                uVar4 = FUN_005dbc30(iVar3);
                uStack_8._0_1_ = 6;
                FUN_005dc090(uVar4);
                uStack_8 = (uint)uStack_8._1_3_ << 8;
                FUN_0056b7d0();
                iVar2 = FUN_005dc530(iVar2,"SendSecurityReport");
                if (iVar2 != 0) {
                  pppuStack_18 = (undefined ***)0x0;
                  if (iVar2 != 0) {
                    ppuStack_3c = std::
                                  _Func_impl_no_alloc<int_(__cdecl*)(struct_ExternalAntiCheatUserData*,unsigned_char_const*,int),int,struct_ExternalAntiCheatUserData*,unsigned_char_const*,int>
                                  ::vftable;
                    iStack_38 = iVar2;
                    pppuStack_18 = &ppuStack_3c;
                  }
                  uStack_8 = CONCAT31(uStack_8._1_3_,7);
                  if (DAT_01ea8eb4 != (undefined ***)0x0) {
                    (*(code *)(*DAT_01ea8eb4)[4])
                              (CONCAT31((int3)((uint)*DAT_01ea8eb4 >> 8),
                                        DAT_01ea8eb4 != (undefined ***)&DAT_01ea8e90));
                    DAT_01ea8eb4 = (undefined ***)0x0;
                  }
                  if (pppuStack_18 != (undefined ***)0x0) {
                    pppuVar1 = pppuStack_18;
                    if (pppuStack_18 == &ppuStack_3c) {
                      DAT_01ea8eb4 = (undefined ***)(*(code *)(*pppuStack_18)[1])(&DAT_01ea8e90);
                      if (pppuStack_18 == (undefined ***)0x0) goto LAB_005deac0;
                      (*(code *)(*pppuStack_18)[4])
                                (CONCAT31((int3)((uint)&ppuStack_3c >> 8),
                                          pppuStack_18 != &ppuStack_3c));
                      pppuVar1 = DAT_01ea8eb4;
                    }
                    DAT_01ea8eb4 = pppuVar1;
                    pppuStack_18 = (undefined ***)0x0;
                  }
LAB_005deac0:
                  uStack_8 = uStack_8 & 0xffffff00;
                  FUN_0056b7d0();
                  goto LAB_005deacc;
                }
              }
            }
          }
        }
      }
    }
  }
  uVar5 = 0;
LAB_005de6d5:
  if (pppuStack_40 != (undefined ***)0x0) {
    (*(code *)(*pppuStack_40)[4])(pppuStack_40 != &ppuStack_64);
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 5618 ; VA 0x005deb10 ; FUN_005deb10 */

void FUN_005deb10(undefined4 *param_1,undefined4 param_2)

{
  code *pcVar1;
  int iVar2;
  undefined *puVar3;
  undefined4 uVar4;
  
  iVar2 = FUN_016de3db(&DAT_01ea8f80,FUN_005dbc60,&DAT_01ea8f84);
  if (iVar2 != 0) {
    *param_1 = param_2;
    param_1[1] = &DAT_01ea8f84;
    return;
  }
  uVar4 = 8;
  puVar3 = &DAT_01d51160;
  FUN_016f4b80(&DAT_01d51160,8);
  iVar2 = FUN_01733dcb();
  pcVar1 = *(code **)(iVar2 + 0xc);
  if (pcVar1 != (code *)0x0) {
    (*(code *)PTR__guard_check_icall_018b37b4)(puVar3,0);
    (*pcVar1)();
    uVar4 = 0xfffffffe;
  }
  FUN_0171d6f3(puVar3,uVar4);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 5619 ; VA 0x005deb50 ; FUN_005deb50 */

undefined * FUN_005deb50(undefined *param_1,undefined4 param_2)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  
  switch(param_2) {
  case 1:
    pcVar3 = "broken promise";
    break;
  case 2:
    pcVar3 = "future already retrieved";
    break;
  case 3:
    pcVar3 = "promise already satisfied";
    break;
  case 4:
    pcVar3 = "no state";
    break;
  default:
    pcVar2 = (char *)FUN_016de42b(param_2);
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    pcVar3 = pcVar2;
    do {
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0(pcVar2,(int)pcVar3 - (int)(pcVar2 + 1));
    return param_1;
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  pcVar2 = pcVar3;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar3,(int)pcVar2 - (int)(pcVar3 + 1));
  return param_1;
}



/* FUNCTION 5620 ; VA 0x005dec10 ; FUN_005dec10 */

char * FUN_005dec10(void)

{
  return "future";
}



/* FUNCTION 5621 ; VA 0x005dec20 ; FUN_005dec20 */

undefined4 * FUN_005dec20(undefined4 *param_1,int param_2)

{
  int *piVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined auStack_5c [24];
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  undefined auStack_2c [12];
  undefined auStack_20 [8];
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ab88;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_2 + 0x10) == 0) {
    *param_1 = 0;
    param_1[1] = 0;
    return param_1;
  }
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_01674e20(0x28);
  if (piVar3 == (int *)0x0) {
    piVar3 = (int *)0x0;
  }
  else {
    piVar3[1] = 1;
    piVar3[2] = 1;
    *piVar3 = (int)std::_Ref_count_obj<struct_RBX::Security::ExternalAntiCheatData>::vftable;
    piVar3[3] = 0;
    piVar3[4] = 0;
    piVar3[5] = 0;
    piVar3[6] = 0;
    piVar3[7] = 0;
    piVar3[8] = 0;
    piVar3[9] = 0;
    piVar3[7] = 0;
    piVar3[8] = 0xf;
    *(undefined *)(piVar3 + 3) = 0;
  }
  piStack_18 = piVar3 + 3;
  uStack_8 = 0;
  piStack_14 = piVar3;
  FUN_016819e0(auStack_2c,param_2);
  uStack_8._0_1_ = 1;
  cVar2 = FUN_016819d0();
  if (cVar2 != '\0') {
    cVar2 = FUN_01682670();
    if (cVar2 != '\0') {
      FUN_0167eea0(auStack_20,"entryId");
      cVar2 = FUN_0167e540();
      if (cVar2 != '\0') {
        FUN_0167eea0(auStack_20,"uinStr");
        cVar2 = FUN_0167e580();
        if (cVar2 != '\0') {
          FUN_0167eea0(auStack_20,"uinStr");
          uStack_34 = 0;
          uStack_30 = 0xf;
          auStack_44[0] = auStack_44[0] & 0xffffff00;
          uStack_8._0_1_ = 2;
          FUN_01681330(auStack_5c,auStack_44);
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          if (0xf < uStack_30) {
            uVar6 = uStack_30 + 1;
            uVar5 = auStack_44[0];
            if (0xfff < uVar6) {
              uVar5 = *(uint *)(auStack_44[0] - 4);
              uVar6 = uStack_30 + 0x24;
              if (0x1f < (auStack_44[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(uVar5,uVar6);
          }
          piVar3 = piStack_18;
          FUN_005511f0(auStack_5c);
          FUN_005507b0();
          FUN_0167eea0(auStack_20,"entryId");
          iVar4 = FUN_0167e2d0(0);
          piVar3[6] = iVar4;
          FUN_00557f90(&piStack_18);
          FUN_0167ec40();
          FUN_00550b30();
          ExceptionList = pvStack_10;
          return param_1;
        }
      }
      *param_1 = 0;
      param_1[1] = 0;
      FUN_0167ec40();
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0167ec40();
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5622 ; VA 0x005dee90 ; FUN_005dee90 */

undefined4 FUN_005dee90(undefined4 param_1)

{
  undefined4 uVar1;
  undefined4 uStack_8;
  
  if (DAT_01ea8e28 == '\0') {
    return 1;
  }
  uStack_8 = param_1;
  if (DAT_01ea8f4c != (int *)0x0) {
    uVar1 = (**(code **)(*DAT_01ea8f4c + 8))(&uStack_8);
    return uVar1;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddc9c();
}



/* FUNCTION 5623 ; VA 0x005deed0 ; FUN_005deed0 */

undefined4
FUN_005deed0(undefined4 *param_1,int *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179aa08;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if ((DAT_01ea8e28 == '\0') || (param_1 == (undefined4 *)0x0)) {
    uVar3 = 1;
    ExceptionList = &pvStack_10;
  }
  else {
    uStack_14 = param_1[6];
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    uStack_1c = param_5;
    uStack_24 = param_3;
    uStack_20 = param_4;
    puStack_18 = param_1;
    if (DAT_01ea8f04 == (int *)0x0) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_016ddc9c();
    }
    ExceptionList = &pvStack_10;
    uVar3 = (**(code **)(*DAT_01ea8f04 + 8))(&uStack_24,&uStack_1c,&puStack_18,&uStack_14);
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 5624 ; VA 0x005defa0 ; FUN_005defa0 */

undefined4 FUN_005defa0(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  undefined4 uStack_10;
  int iStack_c;
  int iStack_8;
  
  if (DAT_01ea8e28 == '\0') {
    return 1;
  }
  iStack_c = *param_2;
  iStack_8 = param_2[1] - iStack_c;
  uStack_10 = param_1;
  if (DAT_01ea8eb4 != (int *)0x0) {
    uVar1 = (**(code **)(*DAT_01ea8eb4 + 8))(&uStack_10,&iStack_c,&iStack_8);
    return uVar1;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddc9c();
}



/* FUNCTION 5625 ; VA 0x005df000 ; FUN_005df000 */

undefined4
FUN_005df000(undefined4 *param_1,int *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int iStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179aa08;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if ((DAT_01ea8e28 == '\0') || (param_1 == (undefined4 *)0x0)) {
    uVar3 = 1;
    ExceptionList = &pvStack_10;
  }
  else {
    uStack_14 = param_1[6];
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    iStack_20 = *param_6;
    iStack_1c = param_6[1] - iStack_20;
    uStack_24 = param_5;
    uStack_2c = param_3;
    uStack_28 = param_4;
    puStack_18 = param_1;
    if (DAT_01ea8e54 == (int *)0x0) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_016ddc9c();
    }
    ExceptionList = &pvStack_10;
    uVar3 = (**(code **)(*DAT_01ea8e54 + 8))
                      (&uStack_2c,&uStack_24,&iStack_20,&iStack_1c,&puStack_18,&uStack_14);
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 5626 ; VA 0x005df0e0 ; FUN_005df0e0 */

void __fastcall FUN_005df0e0(int *param_1)

{
  undefined4 uStack_2c;
  undefined *puStack_28;
  undefined *puStack_24;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_0179aba8;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  if ((*param_1 != 0) && ((*(char *)(param_1 + 1) == '\0' || (*(char *)(*param_1 + 0x80) == '\0'))))
  {
    puStack_24 = (undefined *)0x0;
    iStack_8._0_1_ = 1;
    iStack_8._1_3_ = 0;
    ExceptionList = &pvStack_10;
    FUN_016dfd4d(&uStack_2c,&stack0x00000004);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_005dcdd0();
    puStack_24 = &stack0x00000004;
    iStack_8 = 2;
    puStack_28 = (undefined *)0x5df14e;
    FUN_016dfdcc();
    ExceptionList = pvStack_10;
    return;
  }
  puStack_28 = auStack_1c;
  puStack_24 = (undefined *)0x4;
  uStack_2c = 0x5df16d;
  ExceptionList = &pvStack_10;
  puStack_24 = (undefined *)FUN_005deb10();
                    /* WARNING: Subroutine does not return */
  puStack_28 = &UNK_005df176;
  FUN_016dfe59();
}



/* FUNCTION 5627 ; VA 0x005df180 ; FUN_005df180 */

void __fastcall FUN_005df180(int *param_1)

{
  undefined4 uStack_2c;
  undefined *puStack_28;
  undefined *puStack_24;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_0179aba8;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  if ((*param_1 != 0) && ((*(char *)(param_1 + 1) == '\0' || (*(char *)(*param_1 + 0x6c) == '\0'))))
  {
    puStack_24 = (undefined *)0x0;
    iStack_8._0_1_ = 1;
    iStack_8._1_3_ = 0;
    ExceptionList = &pvStack_10;
    FUN_016dfd4d(&uStack_2c,&stack0x00000004);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_005dcf20();
    puStack_24 = &stack0x00000004;
    iStack_8 = 2;
    puStack_28 = (undefined *)0x5df1eb;
    FUN_016dfdcc();
    ExceptionList = pvStack_10;
    return;
  }
  puStack_28 = auStack_1c;
  puStack_24 = (undefined *)0x4;
  uStack_2c = 0x5df20a;
  ExceptionList = &pvStack_10;
  puStack_24 = (undefined *)FUN_005deb10();
                    /* WARNING: Subroutine does not return */
  puStack_28 = &UNK_005df213;
  FUN_016dfe59();
}



/* FUNCTION 5628 ; VA 0x005df220 ; FUN_005df220 */

void __thiscall FUN_005df220(int *param_1,undefined *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_28 [8];
  undefined auStack_20 [8];
  int *piStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a9e8;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  if ((piVar1 == (int *)0x0) ||
     ((*(char *)(param_1 + 1) != '\0' &&
      ((*(char *)(piVar1 + 0x1b) != '\0' ||
       ((*(char *)(param_1 + 1) != '\0' && (*(char *)(piVar1 + 0x1b) != '\0')))))))) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_005deb10(auStack_20,4);
                    /* WARNING: Subroutine does not return */
    FUN_016dfe59(uVar3);
  }
  piStack_18 = piVar1 + 5;
  cStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_016dee6d(piStack_18);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  cStack_14 = '\x01';
  uStack_8 = 0;
  if (*(char *)((int)piVar1 + 0x75) == '\0') {
    *(undefined *)(piVar1 + 2) = *param_2;
    (**(code **)(*piVar1 + 0x14))(&piStack_18,0);
    uStack_8 = 1;
    if (cStack_14 != '\0') {
      iVar2 = FUN_016deec8(piStack_18);
      if (iVar2 != 0) {
        FUN_016df3c9(iVar2);
      }
    }
    ExceptionList = pvStack_10;
    return;
  }
  uVar3 = FUN_005deb10(auStack_28,3);
                    /* WARNING: Subroutine does not return */
  FUN_016dfe59(uVar3);
}



/* FUNCTION 5629 ; VA 0x005df310 ; FUN_005df310 */

int FUN_005df310(char param_1)

{
  uint3 uVar2;
  undefined1 *puVar1;
  uint3 extraout_var;
  uint3 extraout_var_00;
  undefined1 *puVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uVar2 = (uint3)((uint)ExceptionList >> 8);
  if (DAT_01d59350 != param_1) {
    ExceptionList = &pvStack_10;
    if (DAT_01d59810 != '\0') {
      puVar3 = &DAT_018bf8dc;
      puVar1 = &DAT_018bf8dc;
      if (DAT_01d59350 == '\0') {
        puVar1 = &DAT_018c7824;
      }
      if (param_1 == '\0') {
        puVar3 = &DAT_018c7824;
      }
      ExceptionList = &pvStack_10;
      FUN_01677520(DAT_01d59810,
                   "Warning! Misconfigured External Anticheat Module parameters. isLuobu RCC setting is \'%s\' and FFlagLoadExternalAntiCheatModule is \'%s\'. Both flags should be same value."
                   ,puVar3,puVar1);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("ExternalAntiCheat_Errors_All,ExternalAntiCheat_Errors_FlagMisconfig",0x43);
    uStack_8 = 0;
    FUN_00878480(auStack_28,0);
    uVar2 = extraout_var;
    if (0xf < uStack_14) {
      uVar5 = uStack_14 + 1;
      uVar4 = auStack_28[0];
      if (0xfff < uVar5) {
        uVar4 = *(uint *)(auStack_28[0] - 4);
        uVar5 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar4,uVar5);
      uVar2 = extraout_var_00;
    }
  }
  if ((param_1 != '\0') && (DAT_01d59350 != '\0')) {
    ExceptionList = pvStack_10;
    return CONCAT31(uVar2,1);
  }
  ExceptionList = pvStack_10;
  return (uint)uVar2 << 8;
}



/* FUNCTION 5630 ; VA 0x005df410 ; FUN_005df410 */

undefined4 FUN_005df410(void)

{
  int iVar1;
  undefined auStack_10 [12];
  
  if (DAT_01ea8e28 != '\0') {
    if (DAT_01ea8f7c == (int *)0x0) {
      FUN_016ddb1f();
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_10,&DAT_01d4e5ec);
    }
    iVar1 = (**(code **)(*DAT_01ea8f7c + 8))();
    if (iVar1 != 0) {
      return 0;
    }
    DAT_01ea8e28 = '\0';
  }
  return 1;
}



/* FUNCTION 5631 ; VA 0x005df440 ; FUN_005df440 */

/* WARNING: Type propagation algorithm not settling */

undefined2 * FUN_005df440(undefined2 *param_1,undefined4 *param_2,undefined4 param_3,int param_4)

{
  undefined uVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int *piVar7;
  undefined4 *******pppppppuVar8;
  uint uVar9;
  int iVar10;
  int *piVar11;
  int aiStack_190 [3];
  byte abStack_184 [164];
  undefined auStack_e0 [8];
  undefined auStack_d8 [8];
  undefined auStack_d0 [8];
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined **ppuStack_b8;
  int **ppiStack_b4;
  undefined4 *puStack_b0;
  undefined ***pppuStack_94;
  undefined auStack_90 [8];
  int *piStack_88;
  undefined uStack_84;
  int **ppiStack_80;
  undefined4 *puStack_7c;
  int iStack_78;
  int iStack_74;
  undefined auStack_70 [36];
  undefined auStack_4c [4];
  int *piStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  undefined uStack_3c;
  int *piStack_38;
  undefined4 *puStack_34;
  undefined4 *******pppppppuStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  undefined8 uStack_20;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ac8f;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffe64;
  uStack_44 = 0;
  ExceptionList = &pvStack_10;
  uStack_20._0_4_ = FUN_0058ee60(&DAT_01d5983c,0);
  if ((int)uStack_20 == 0) {
    pppppppuStack_30 = (undefined4 *******)((uint)pppppppuStack_30 & 0xffffff00);
    uStack_20._4_4_ = 0xf;
    if ((uint)param_2[4] < DAT_01d5984c) {
      FUN_00554050();
LAB_005dfaf2:
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    iVar3 = param_2[4] - DAT_01d5984c;
    iVar10 = -1;
    if (iVar3 != -1) {
      iVar10 = iVar3;
    }
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_005542c0((int)param_2 + DAT_01d5984c,iVar10);
    *(undefined4 *)(param_1 + 8) = 0;
    *(undefined4 *)(param_1 + 10) = 7;
    *param_1 = 0;
    uStack_8 = 1;
    if ((int)uStack_20 != 0) {
      pppppppuVar8 = &pppppppuStack_30;
      if (0xf < uStack_20._4_4_) {
        pppppppuVar8 = pppppppuStack_30;
      }
      iVar10 = (int)uStack_20 + (int)pppppppuVar8;
      pppppppuVar8 = &pppppppuStack_30;
      if (0xf < uStack_20._4_4_) {
        pppppppuVar8 = pppppppuStack_30;
      }
      uVar4 = FUN_01686580();
      FUN_01685950(pppppppuVar8,iVar10,param_1,uVar4);
    }
    if (uStack_20._4_4_ < 0x10) {
      ExceptionList = pvStack_10;
      return param_1;
    }
    uVar9 = uStack_20._4_4_ + 1;
    pppppppuVar8 = pppppppuStack_30;
    if (0xfff < uVar9) {
      uVar9 = uStack_20._4_4_ + 0x24;
      pppppppuVar8 = (undefined4 *******)pppppppuStack_30[-1];
      if (0x1f < (uint)((int)pppppppuStack_30 + (-4 - (int)pppppppuStack_30[-1])))
      goto LAB_005dfaf2;
    }
  }
  else {
    iVar10 = FUN_0058ee60(&DAT_01d59854,0);
    if (iVar10 == 0) {
      FUN_005de080(auStack_70,param_3);
      uStack_8 = 4;
      FUN_014c9d60(auStack_4c,0);
      uStack_8._0_1_ = 5;
      puVar5 = param_2;
      if (0xf < (uint)param_2[5]) {
        puVar5 = (undefined4 *)*param_2;
      }
      FUN_014cbbc0(puVar5,param_2[4]);
      FUN_014cb890(1);
      puVar5 = (undefined4 *)FUN_01674e20(0x18);
      uStack_8._0_1_ = 6;
      piStack_18 = puVar5;
      if (puVar5 == (undefined4 *)0x0) {
        puStack_b0 = (undefined4 *)0x0;
      }
      else {
        puVar5[1] = 1;
        puVar5[2] = 1;
        *puVar5 = std::
                  _Ref_count_obj<class_std::promise<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>
                  ::vftable;
        puVar6 = (undefined4 *)FUN_01674e20(0x90);
        puStack_b0 = puVar5;
        puStack_34 = puVar6;
        if (puVar6 == (undefined4 *)0x0) {
          *(undefined *)(puVar5 + 4) = 0;
          puVar5[3] = 0;
          *(undefined *)(puVar5 + 5) = 0;
        }
        else {
          *puVar6 = std::
                    _Associated_state<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                    ::vftable;
          puVar6[1] = 1;
          puVar6[6] = 0;
          puVar6[7] = 0xf;
          *(undefined *)(puVar6 + 2) = 0;
          uStack_8._0_1_ = 7;
          FUN_016dfd92(puVar6 + 8);
          FUN_016dee4c(puVar6 + 10,2);
          thunk_FUN_016def21(puVar6 + 0x16);
          *(undefined *)(puVar6 + 0x20) = 0;
          puVar6[0x21] = 0;
          *(undefined2 *)(puVar6 + 0x22) = 0;
          *(undefined *)((int)puVar6 + 0x8a) = 0;
          puVar6[0x23] = 0;
          puVar5[3] = puVar6;
          *(undefined *)(puVar5 + 4) = 0;
          *(undefined *)(puVar5 + 5) = 0;
        }
      }
      ppiStack_b4 = (int **)(puStack_b0 + 3);
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      ppiStack_80 = ppiStack_b4;
      puStack_7c = puStack_b0;
      if ((*ppiStack_b4 == (int *)0x0) ||
         ((*(char *)(puStack_b0 + 4) != '\0' && (*(char *)(*ppiStack_b4 + 0x20) != '\0')))) {
        uVar4 = FUN_005deb10(auStack_e0,4);
                    /* WARNING: Subroutine does not return */
        FUN_016dfe59(uVar4);
      }
      if (*(char *)(puStack_b0 + 5) != '\0') {
        uVar4 = FUN_005deb10(auStack_90,2);
                    /* WARNING: Subroutine does not return */
        FUN_016dfe59(uVar4);
      }
      *(undefined *)(puStack_b0 + 5) = 1;
      piStack_18 = (int *)0x0;
      if ((&piStack_40 != ppiStack_b4) && (piStack_18 = (int *)0x0, *ppiStack_b4 != (int *)0x0)) {
        LOCK();
        piVar11 = *ppiStack_b4 + 1;
        *piVar11 = *piVar11 + 1;
        UNLOCK();
        piStack_18 = *ppiStack_b4;
      }
      piVar11 = piStack_18;
      uStack_3c = 1;
      uStack_44 = 0xc;
      if (puStack_b0 != (undefined4 *)0x0) {
        LOCK();
        puStack_b0[1] = puStack_b0[1] + 1;
        UNLOCK();
      }
      pppuStack_94 = &ppuStack_b8;
      ppuStack_b8 = std::
                    _Func_impl_no_alloc<class_<lambda_613320506386d18d191c5d0e696f3da6>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
                    ::vftable;
      uStack_8._0_1_ = 10;
      piStack_40 = piStack_18;
      FUN_014cb530(pppuStack_94);
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
      if (pppuStack_94 != (undefined ***)0x0) {
        (*(code *)(*pppuStack_94)[4])
                  (CONCAT31((int3)((uint)&ppuStack_b8 >> 8),pppuStack_94 != &ppuStack_b8));
      }
      iStack_74 = param_4 >> 0x1f;
      iStack_78 = param_4;
      if ((piStack_18 == (int *)0x0) || (*(char *)(piVar11 + 0x20) != '\0')) {
        uVar4 = FUN_005deb10(auStack_d8,4);
                    /* WARNING: Subroutine does not return */
        FUN_016dfe59(uVar4);
      }
      piVar7 = piStack_18 + 10;
      piStack_38 = piVar7;
      iVar10 = FUN_016dee6d(piVar7);
      if (iVar10 != 0) {
        FUN_016df3c9(iVar10);
      }
      puStack_34 = (undefined4 *)CONCAT31(puStack_34._1_3_,1);
      uStack_8._0_1_ = 0xb;
      cVar2 = (**(code **)(*piVar11 + 0xc))();
      if (cVar2 == '\0') {
        piStack_18 = piStack_18 + 0x16;
        puVar5 = (undefined4 *)FUN_0054dbf0(&iStack_28,&iStack_78);
        uStack_c8 = *puVar5;
        uStack_c4 = puVar5[1];
        uStack_c0 = puVar5[2];
        uStack_bc = puVar5[3];
        iVar10 = piVar11[0x21];
        while (iVar10 == 0) {
          iVar10 = FUN_016dedc0(piVar7);
          if (iVar10 == 0) {
            FUN_016df3f6(4);
          }
          iVar10 = FUN_016df1bf(piStack_18,piVar7,&uStack_c8);
          if (iVar10 != 0) {
            if (iVar10 != 2) {
              FUN_016df3c9(iVar10);
              goto LAB_005df8d7;
            }
LAB_005df989:
            piVar7 = piStack_38;
            if (piVar11[0x21] == 0) {
              uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
              iVar10 = FUN_016deec8(piStack_38);
              if (iVar10 != 0) {
                FUN_016df3c9(iVar10);
              }
              uStack_8 = CONCAT31(uStack_8._1_3_,9);
              if (DAT_01d84e8e != '\0') {
                if (0xf < (uint)param_2[5]) {
                  param_2 = (undefined4 *)*param_2;
                }
                FUN_01677520(DAT_01d84e8e,
                             "ExternalAntiCheatModule::downloadLibrary request for %s timed out",
                             param_2);
              }
              uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
              FUN_016757c0("ExternalAntiCheatModule::downloadLibrary request for %s timed out",uVar4
                          );
            }
            break;
          }
LAB_005df8d7:
          if (iVar10 == 2) goto LAB_005df989;
          piVar7 = piStack_38;
          iVar10 = piVar11[0x21];
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
      }
      else {
        uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
      }
      iVar10 = FUN_016deec8(piVar7);
      if (iVar10 != 0) {
        FUN_016df3c9(iVar10);
      }
      uStack_8._0_1_ = 9;
      puVar5 = (undefined4 *)FUN_016871c0(auStack_d0);
      uStack_8._0_1_ = 0xf;
      if (0xf < (uint)puVar5[5]) {
        puVar5 = (undefined4 *)*puVar5;
      }
      FUN_00565320(puVar5,0x32,0x40,1);
      *(undefined ***)((int)aiStack_190 + *(int *)(aiStack_190[0] + 4)) =
           std::basic_ofstream<char,struct_std::char_traits<char>_>::vftable;
      *(int *)(abStack_184 + *(int *)(aiStack_190[0] + 4) + -0x10) =
           *(int *)(aiStack_190[0] + 4) + -0x68;
      uStack_8._0_1_ = 0x11;
      FUN_005507b0();
      if ((abStack_184[*(int *)(aiStack_190[0] + 4)] & 6) != 0) {
        if (DAT_01d84e8e != '\0') {
          puVar5 = (undefined4 *)FUN_016871c0(&pppppppuStack_30);
          uStack_8._0_1_ = 0x12;
          if (0xf < (uint)puVar5[5]) {
            puVar5 = (undefined4 *)*puVar5;
          }
          FUN_01677520(DAT_01d84e8e,
                       "ExternalAntiCheatModule::downloadLibrary failed to open file at %s, aborting"
                       ,puVar5);
          uStack_8._0_1_ = 0x11;
          FUN_005507b0();
        }
        FUN_016871c0(&pppppppuStack_30);
        uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
        uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("ExternalAntiCheatModule::downloadLibrary failed to open file at %s, aborting",
                     uVar4);
      }
      piStack_40 = (int *)0x0;
      uStack_84 = 1;
      uStack_8._0_1_ = 0x17;
      uVar1 = (undefined)uStack_8;
      uStack_8._0_1_ = 0x17;
      piStack_88 = piVar11;
      if ((piVar11 != (int *)0x0) && (*(char *)(piVar11 + 0x20) == '\0')) {
        piVar7 = (int *)(**(code **)(*piVar11 + 8))(1);
        uStack_44 = 0x1c;
        pppppppuStack_30 = (undefined4 *******)*piVar7;
        iStack_2c = piVar7[1];
        iStack_28 = piVar7[2];
        iStack_24 = piVar7[3];
        uStack_20 = *(undefined8 *)(piVar7 + 4);
        piVar7[4] = 0;
        piVar7[5] = 0xf;
        *(undefined *)piVar7 = 0;
        uStack_8._0_1_ = 0x18;
        LOCK();
        iVar10 = piVar11[1] + -1;
        piVar11[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          if ((int *)piVar11[0x23] == (int *)0x0) {
            puVar5 = (undefined4 *)*piVar11;
            piVar11 = (int *)0x1;
          }
          else {
            puVar5 = *(undefined4 **)piVar11[0x23];
          }
          (*(code *)*puVar5)(piVar11);
        }
        pppppppuVar8 = &pppppppuStack_30;
        if (0xf < uStack_20._4_4_) {
          pppppppuVar8 = pppppppuStack_30;
        }
        uStack_8._0_1_ = 0x15;
        FUN_0055b3b0(aiStack_190,pppppppuVar8,(int)uStack_20);
        uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
        FUN_005507b0();
        FUN_00581480();
        uStack_8 = 0x11;
        FUN_0054f050(auStack_70);
        FUN_00570460();
        FUN_005dbe20();
        FUN_00550b30();
        if (piStack_48 != (int *)0x0) {
          LOCK();
          iVar10 = piStack_48[1] + -1;
          piStack_48[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piStack_48)();
            LOCK();
            piVar11 = piStack_48 + 2;
            iVar10 = *piVar11;
            *piVar11 = *piVar11 + -1;
            UNLOCK();
            if (iVar10 == 1) {
              (**(code **)(*piStack_48 + 4))();
            }
          }
        }
        FUN_00550800();
        ExceptionList = pvStack_10;
        return param_1;
      }
      uStack_8._0_1_ = uVar1;
      uVar4 = FUN_005deb10(auStack_90,4);
                    /* WARNING: Subroutine does not return */
      FUN_016dfe59(uVar4);
    }
    *(undefined4 *)(param_1 + 8) = 0;
    *(undefined4 *)(param_1 + 10) = 7;
    *param_1 = 0;
    uStack_8 = 2;
    uStack_20._0_4_ = 0;
    uStack_20._4_4_ = 0xf;
    pppppppuStack_30 = (undefined4 *******)((uint)pppppppuStack_30 & 0xffffff00);
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if ((int)uStack_20 != 0) {
      pppppppuVar8 = &pppppppuStack_30;
      if (0xf < uStack_20._4_4_) {
        pppppppuVar8 = pppppppuStack_30;
      }
      iVar10 = (int)uStack_20 + (int)pppppppuVar8;
      pppppppuVar8 = &pppppppuStack_30;
      if (0xf < uStack_20._4_4_) {
        pppppppuVar8 = pppppppuStack_30;
      }
      uVar4 = FUN_01686580();
      FUN_01685950(pppppppuVar8,iVar10,param_1,uVar4);
    }
    if (uStack_20._4_4_ < 0x10) {
      ExceptionList = pvStack_10;
      return param_1;
    }
    uVar9 = uStack_20._4_4_ + 1;
    pppppppuVar8 = pppppppuStack_30;
    if (0xfff < uVar9) {
      pppppppuVar8 = (undefined4 *******)pppppppuStack_30[-1];
      uVar9 = uStack_20._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppppppuStack_30 + (-4 - (int)pppppppuVar8))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  FUN_01674ea0(pppppppuVar8,uVar9);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5632 ; VA 0x005dfbe9 ; Catch@005dfbe9 */

void Catch_005dfbe9(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int unaff_EBP;
  
  piVar1 = *(int **)(unaff_EBP + -0x4c);
  if (DAT_01d84e8e != '\0') {
    uVar2 = (**(code **)(*piVar1 + 4))();
    piVar4 = *(int **)(unaff_EBP + 0x10);
    if (0xf < (uint)piVar4[5]) {
      piVar4 = (int *)*piVar4;
    }
    FUN_01677520(DAT_01d84e8e,
                 "ExternalAntiCheatModule::downloadLibrary Failed to download library %s with http status code %d: %s"
                 ,piVar4,piVar1[9],uVar2);
  }
  uVar2 = (**(code **)(*piVar1 + 4))();
  uVar3 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("ExternalAntiCheatModule::downloadLibrary Failed to download library %s with http status code %d: %s"
               ,uVar3,piVar1[9],uVar2);
}



/* FUNCTION 5633 ; VA 0x005dfc49 ; Catch@005dfc49 */

void Catch_005dfc49(void)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int unaff_EBP;
  
  piVar1 = *(int **)(unaff_EBP + -0x50);
  if (DAT_01d84e8e != '\0') {
    uVar3 = (**(code **)(*piVar1 + 4))();
    puVar4 = (undefined4 *)FUN_016871c0(unaff_EBP + -0x2c);
    uVar2 = puVar4[5];
    *(undefined *)(unaff_EBP + -4) = 0x1a;
    if (0xf < uVar2) {
      puVar4 = (undefined4 *)*puVar4;
    }
    FUN_01677520(DAT_01d84e8e,
                 "ExternalAntiCheatModule::downloadLibrary failed to write file at \'%s\' due to \'%s\', aborting"
                 ,puVar4,uVar3);
    *(undefined *)(unaff_EBP + -4) = 0x19;
    FUN_005507b0();
  }
  uVar3 = (**(code **)(*piVar1 + 4))();
  FUN_016871c0(unaff_EBP + -0x2c);
  *(undefined *)(unaff_EBP + -4) = 0x1b;
  uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("ExternalAntiCheatModule::downloadLibrary failed to write file at \'%s\' due to \'%s\', aborting"
               ,uVar5,uVar3);
}



/* FUNCTION 5634 ; VA 0x005dfcc9 ; Catch@005dfcc9 */

void Catch_005dfcc9(void)

{
  uint uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int unaff_EBP;
  int *piVar5;
  
  piVar5 = *(int **)(unaff_EBP + -0x54);
  if (DAT_01d84e8e != '\0') {
    if (0xf < (uint)piVar5[5]) {
      piVar5 = (int *)*piVar5;
    }
    puVar2 = (undefined4 *)FUN_016871c0(unaff_EBP + -0x2c);
    uVar1 = puVar2[5];
    *(undefined *)(unaff_EBP + -4) = 0x1c;
    if (0xf < uVar1) {
      puVar2 = (undefined4 *)*puVar2;
    }
    FUN_01677520(DAT_01d84e8e,
                 "ExternalAntiCheatModule::downloadLibrary failed to write file at \'%s\' due to \'%s\', aborting"
                 ,puVar2,piVar5);
    *(undefined *)(unaff_EBP + -4) = 0x19;
    FUN_005507b0();
  }
  uVar3 = FUN_005543f0();
  FUN_016871c0(unaff_EBP + -0xa4);
  *(undefined *)(unaff_EBP + -4) = 0x1d;
  uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("ExternalAntiCheatModule::downloadLibrary failed to write file at \'%s\' due to \'%s\', aborting"
               ,uVar4,uVar3);
}



/* FUNCTION 5635 ; VA 0x005dfd70 ; FUN_005dfd70 */

char * __fastcall FUN_005dfd70(int param_1)

{
  switch(*(undefined4 *)(param_1 + 0xc)) {
  case 1:
    return "broken promise";
  case 2:
    return "future already retrieved";
  case 3:
    return "promise already satisfied";
  case 4:
    return "no state";
  default:
    return (char *)0x0;
  }
}



/* FUNCTION 5636 ; VA 0x005dfdb0 ; FUN_005dfdb0 */

/* WARNING: Restarted to delay deadcode elimination for space: stack */

undefined4 *
FUN_005dfdb0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  *param_1 = param_3;
  param_1[1] = param_4;
  return param_1;
}



/* FUNCTION 5637 ; VA 0x005dfe00 ; FUN_005dfe00 */

undefined4 FUN_005dfe00(undefined4 param_1,undefined4 param_2)

{
  FUN_005e02a0(param_2,1);
  return param_1;
}



/* FUNCTION 5638 ; VA 0x005dfe30 ; FUN_005dfe30 */

undefined4 * FUN_005dfe30(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179aca8;
  pvStack_10 = ExceptionList;
  uVar1 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054fe90(param_2);
  *param_1 = std::logic_error::vftable;
  *param_1 = std::length_error::vftable;
  uStack_8 = 0;
  FUN_0054fe20(uVar1);
  *param_1 = boost::exception_detail::error_info_injector<class_std::length_error>::vftable;
  param_1[3] = boost::exception_detail::error_info_injector<class_std::length_error>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5639 ; VA 0x005dfec0 ; FUN_005dfec0 */

void FUN_005dfec0(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179acc0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00578100(0x44);
  uStack_8 = 0;
  puVar2 = (undefined4 *)FUN_005511e0(0x44,uVar1);
  FUN_0056b3c0();
  *puVar2 = boost::detail::
            thread_data<class_boost::_bi::bind_t<void,class_boost::_mfi::mf0<void,class_RBX::CrashReporter>,class_boost::_bi::list1<class_boost::_bi::value<class_RBX::CrashReporter*>_>_>_>
            ::vftable;
  uVar1 = param_1[1];
  puVar2[0xf] = *param_1;
  puVar2[0x10] = uVar1;
  FUN_005dff5f();
  return;
}



/* FUNCTION 5640 ; VA 0x005dff34 ; Catch_All@005dff34 */

void Catch_All_005dff34(void)

{
  int unaff_EBP;
  
  FUN_00581530(*(undefined4 *)(unaff_EBP + -0x18));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5641 ; VA 0x005dff5f ; FUN_005dff5f */

void FUN_005dff5f(void)

{
  int unaff_EBP;
  
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 5642 ; VA 0x005dff70 ; FUN_005dff70 */

int * FUN_005dff70(int *param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  
  uVar2 = 0;
  iVar1 = FUN_005dfec0(param_2);
  *param_1 = iVar1;
  if (*param_1 != 0) {
    FUN_00585f20(*param_1,iVar1,uVar2);
  }
  return param_1;
}



/* FUNCTION 5643 ; VA 0x005dffd0 ; FUN_005dffd0 */

void FUN_005dffd0(undefined4 param_1)

{
  undefined auStack_64 [44];
  undefined auStack_38 [32];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179acd8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  _guard_check_icall(param_1);
  uStack_18 = FUN_005dfe30(auStack_38,param_1);
  uStack_8 = 0;
  uStack_14 = uStack_18;
  FUN_005dfe00(auStack_64,uStack_18);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_64,&DAT_01c24940);
}



/* FUNCTION 5644 ; VA 0x005e0070 ; FUN_005e0070 */

undefined4
FUN_005e0070(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  undefined4 uVar1;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  undefined *puStack_10;
  undefined *puStack_c;
  byte bStack_7;
  
  uStack_18 = (uint)bStack_7;
  uStack_1c = param_6;
  uStack_20 = param_5;
  puStack_c = (undefined *)&uStack_28;
  uStack_28 = param_3;
  uStack_24 = param_4;
  puStack_10 = (undefined *)&uStack_30;
  uStack_30 = param_1;
  uStack_2c = param_2;
  uVar1 = FUN_005e00d0();
  return uVar1;
}



/* FUNCTION 5645 ; VA 0x005e00d0 ; FUN_005e00d0 */

int FUN_005e00d0(undefined4 param_1,int param_2,undefined4 param_3,int param_4,int param_5)

{
  int iVar1;
  undefined4 uStack_14;
  undefined uStack_7;
  
  while (param_2 != param_4) {
    iVar1 = FUN_005511e0(0x18,param_5,uStack_7);
    if (iVar1 == 0) {
      uStack_14 = 0;
    }
    else {
      uStack_14 = FUN_0054ef20(param_2);
    }
    FUN_005e0d00(uStack_14);
    param_5 = param_5 + 0x18;
  }
  return param_5;
}



/* FUNCTION 5646 ; VA 0x005e0190 ; FUN_005e0190 */

undefined4 * __thiscall FUN_005e0190(undefined4 *param_1,int param_2,undefined4 param_3,int param_4)

{
  undefined4 *puStack_20;
  int iStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ad14;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018c80ac;
    param_1[10] = boost::exception_detail::clone_base::vftable;
    uStack_8 = 0;
  }
  FUN_005e0480(param_2);
  uStack_8 = 1;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_std::length_error>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_std::length_error>_>
               ::vftable;
  *(undefined ***)((int)param_1 + *(int *)(param_1[8] + 4) + 0x20) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_std::length_error>_>::
       vftable;
  *(int *)((int)param_1 + *(int *)(param_1[8] + 4) + 0x1c) = *(int *)(param_1[8] + 4) + -8;
  if (param_2 == 0) {
    iStack_1c = 0;
  }
  else {
    iStack_1c = param_2 + 0xc;
  }
  if (param_1 == (undefined4 *)0x0) {
    puStack_20 = (undefined4 *)0x0;
  }
  else {
    puStack_20 = param_1 + 3;
  }
  FUN_00554960(puStack_20,iStack_1c);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5647 ; VA 0x005e02a0 ; FUN_005e02a0 */

undefined4 * __thiscall FUN_005e02a0(undefined4 *param_1,int param_2,int param_3)

{
  undefined4 *puStack_20;
  int iStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ad14;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018c80ac;
    param_1[10] = boost::exception_detail::clone_base::vftable;
    uStack_8 = 0;
  }
  FUN_005e0480(param_2);
  uStack_8 = 1;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_std::length_error>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_std::length_error>_>
               ::vftable;
  *(undefined ***)((int)param_1 + *(int *)(param_1[8] + 4) + 0x20) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_std::length_error>_>::
       vftable;
  *(int *)((int)param_1 + *(int *)(param_1[8] + 4) + 0x1c) = *(int *)(param_1[8] + 4) + -8;
  if (param_2 == 0) {
    iStack_1c = 0;
  }
  else {
    iStack_1c = param_2 + 0xc;
  }
  if (param_1 == (undefined4 *)0x0) {
    puStack_20 = (undefined4 *)0x0;
  }
  else {
    puStack_20 = param_1 + 3;
  }
  FUN_00554960(puStack_20,iStack_1c);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5648 ; VA 0x005e03b0 ; FUN_005e03b0 */

undefined4 * __thiscall FUN_005e03b0(undefined4 *param_1,undefined4 param_2,int param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ad3c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018c80ac;
    param_1[10] = boost::exception_detail::clone_base::vftable;
    uStack_8 = 0;
  }
  FUN_005e0480(param_2);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_std::length_error>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_std::length_error>_>
               ::vftable;
  *(undefined ***)((int)param_1 + *(int *)(param_1[8] + 4) + 0x20) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_std::length_error>_>::
       vftable;
  *(undefined4 *)((int)param_1 + *(int *)(param_1[8] + 4) + 0x1c) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5649 ; VA 0x005e0480 ; FUN_005e0480 */

undefined4 * __thiscall FUN_005e0480(undefined4 *param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794258;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054fe90(param_2);
  *param_1 = std::logic_error::vftable;
  *param_1 = std::length_error::vftable;
  uStack_8 = 0;
  FUN_0054fe50(param_2 + 0xc);
  *param_1 = boost::exception_detail::error_info_injector<class_std::length_error>::vftable;
  param_1[3] = boost::exception_detail::error_info_injector<class_std::length_error>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5650 ; VA 0x005e0510 ; FUN_005e0510 */

undefined4 __thiscall FUN_005e0510(undefined4 param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0x18);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5651 ; VA 0x005e0580 ; FUN_005e0580 */

undefined4 * __fastcall FUN_005e0580(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179add2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::CrashReporter::vftable;
  param_1[2] = 0;
  param_1[3] = 0;
  uStack_8 = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  FUN_0151f360(0);
  uStack_8._0_1_ = 1;
  FUN_0151f360(0);
  uStack_8._0_1_ = 2;
  FUN_00610ca0();
  uStack_8._0_1_ = 3;
  FUN_00610ca0();
  uStack_8._0_1_ = 4;
  *(undefined *)(param_1 + 0xb) = 0;
  FUN_005c4570(1);
  *(undefined *)((int)param_1 + 0x2e) = 1;
  *(undefined *)((int)param_1 + 0x2f) = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  *(undefined *)(param_1 + 0xe) = 0;
  *(undefined *)((int)param_1 + 0x39) = 1;
  uStack_8._0_1_ = 5;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  FUN_00554010();
  uStack_8._0_1_ = 6;
  FUN_00550050();
  uStack_8._0_1_ = 7;
  FUN_00550050();
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  uStack_8._0_1_ = 9;
  FUN_005502b0();
  uStack_8._0_1_ = 10;
  *(undefined *)(param_1 + 0x2e) = 0;
  FUN_005502b0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  param_1[0x32] = 0;
  uVar1 = VirtualAlloc(0,0x3200000,0x2000,1);
  param_1[0xf] = uVar1;
  FUN_005e2920(DAT_01d59870);
  DAT_01ea8f98 = param_1;
  FUN_01675440(FUN_005e21f0);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5652 ; VA 0x005e07c0 ; FUN_005e07c0 */

undefined4 * __thiscall FUN_005e07c0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  uStack_c = param_2;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  _uStack_8 = CONCAT31((int3)((uint)param_1 >> 8),1);
  FUN_0170c226(&uStack_c,param_1 + 1);
  *param_1 = std::length_error::vftable;
  return param_1;
}



/* FUNCTION 5653 ; VA 0x005e0810 ; FUN_005e0810 */

void __fastcall FUN_005e0810(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005e1d10(param_1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5654 ; VA 0x005e0850 ; FUN_005e0850 */

void __fastcall FUN_005e0850(undefined4 *param_1)

{
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_std::length_error>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_std::length_error>_>
               ::vftable;
  *(undefined ***)((int)param_1 + *(int *)(param_1[8] + 4) + 0x20) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_std::length_error>_>::
       vftable;
  *(int *)((int)param_1 + *(int *)(param_1[8] + 4) + 0x1c) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::error_info_injector<class_std::length_error>::vftable;
  param_1[3] = boost::exception_detail::error_info_injector<class_std::length_error>::vftable;
  FUN_00551060();
  FUN_00550f40();
  return;
}



/* FUNCTION 5655 ; VA 0x005e08d0 ; FUN_005e08d0 */

void __fastcall FUN_005e08d0(undefined4 *param_1)

{
  *param_1 = boost::exception_detail::error_info_injector<class_std::length_error>::vftable;
  param_1[3] = boost::exception_detail::error_info_injector<class_std::length_error>::vftable;
  FUN_00551060();
  FUN_00550f40();
  return;
}



/* FUNCTION 5656 ; VA 0x005e0910 ; FUN_005e0910 */

void __fastcall FUN_005e0910(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 4) != 0) {
    ExceptionList = &pvStack_10;
    FUN_005536f0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5657 ; VA 0x005e0950 ; FUN_005e0950 */

void __fastcall FUN_005e0950(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794990;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::CrashReporter::vftable;
  *(undefined *)(param_1 + 0xe) = 1;
  if (param_1[0xf] != 0) {
    VirtualFree(param_1[0xf],0,0x8000);
    param_1[0xf] = 0;
  }
  cVar1 = FUN_0168a370();
  if (cVar1 != '\0') {
    if (DAT_01d7abf8 != '\0') {
      FUN_016774b0(DAT_01d7abf8,"Closing crashreporter thread on destroy",0);
    }
    FUN_0151f3f0();
    FUN_00586350();
  }
  cVar1 = FUN_0168a370();
  if (cVar1 != '\0') {
    if (DAT_01d7abf8 != '\0') {
      FUN_016774b0(DAT_01d7abf8,"Closing softhang thread on destroy",0);
    }
    FUN_0151f3f0();
    FUN_00586350();
  }
  DAT_01ea8f98 = 0;
  FUN_0056e920();
  FUN_0056e920();
  uStack_8 = 0;
  FUN_005e1d10();
  uStack_8 = 0xffffffff;
  FUN_00550990();
  FUN_00550990();
  uStack_8 = 1;
  FUN_005507b0();
  uStack_8 = 0xffffffff;
  FUN_0056ebb0();
  FUN_0056ebb0();
  FUN_0151f390();
  FUN_0151f390();
  uStack_8 = 2;
  if (param_1[3] != 0) {
    FUN_00553740();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5658 ; VA 0x005e0b20 ; FUN_005e0b20 */

void __fastcall FUN_005e0b20(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794990;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005507b0(param_1);
  uStack_8 = 1;
  FUN_005507b0();
  uStack_8 = 2;
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5659 ; VA 0x005e0b90 ; FUN_005e0b90 */

undefined4 FUN_005e0b90(undefined4 param_1)

{
  undefined auStack_3c [32];
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ade8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00550050();
  FUN_005543b0(param_1);
  puStack_1c = auStack_3c;
  uStack_8 = 0;
  puStack_18 = puStack_1c;
  FUN_005e2c00(uStack_14);
  uStack_8 = 0xffffffff;
  FUN_00550990();
  ExceptionList = pvStack_10;
  return uStack_14;
}



/* FUNCTION 5660 ; VA 0x005e0c10 ; FUN_005e0c10 */

/* WARNING: Restarted to delay deadcode elimination for space: stack */

int * __thiscall FUN_005e0c10(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar1 = *param_2;
  ExceptionList = &pvStack_10;
  if (iVar1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_00585f20(iVar1);
  }
  iVar2 = *param_1;
  *param_1 = iVar1;
  uStack_8 = 0;
  if (iVar2 != 0) {
    FUN_00585f30(iVar2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5661 ; VA 0x005e0cb0 ; FUN_005e0cb0 */

undefined4 __thiscall FUN_005e0cb0(undefined4 param_1,undefined4 param_2)

{
  FUN_005e0c10(param_2);
  FUN_005e2840();
  return param_1;
}



/* FUNCTION 5662 ; VA 0x005e0cd0 ; FUN_005e0cd0 */

bool __thiscall FUN_005e0cd0(int *param_1,int *param_2)

{
  return *param_1 != *param_2;
}



/* FUNCTION 5663 ; VA 0x005e0cf0 ; FUN_005e0cf0 */

bool __fastcall FUN_005e0cf0(char *param_1)

{
  return *param_1 != '\0';
}



/* FUNCTION 5664 ; VA 0x005e0d00 ; FUN_005e0d00 */

int * __fastcall FUN_005e0d00(int *param_1)

{
  int *piVar1;
  
  piVar1 = param_1 + 1;
  *piVar1 = *piVar1 + 0x18;
  if (*piVar1 == ((int *)*param_1)[1]) {
    *piVar1 = *(int *)*param_1;
  }
  if (param_1[1] == *(int *)(*param_1 + 0xc)) {
    param_1[1] = 0;
  }
  return param_1;
}



/* FUNCTION 5665 ; VA 0x005e0d60 ; FUN_005e0d60 */

void __fastcall FUN_005e0d60(undefined4 *param_1)

{
  FUN_0054eb90();
  (*(code *)*param_1)(param_1[1]);
  return;
}



/* FUNCTION 5666 ; VA 0x005e0da0 ; FUN_005e0da0 */

int * __thiscall FUN_005e0da0(int *param_1,int param_2)

{
  int *piVar1;
  int iStack_10;
  
  if (param_2 < 1) {
    if (param_2 < 0) {
      FUN_005e0e40(-param_2);
    }
  }
  else {
    piVar1 = (int *)*param_1;
    if (param_2 < (piVar1[1] - param_1[1]) / 0x18) {
      iStack_10 = param_2;
    }
    else {
      iStack_10 = param_2 - (piVar1[1] - *piVar1) / 0x18;
    }
    param_1[1] = iStack_10 * 0x18 + param_1[1];
    if (param_1[1] == *(int *)(*param_1 + 0xc)) {
      param_1[1] = 0;
    }
  }
  return param_1;
}



/* FUNCTION 5667 ; VA 0x005e0e40 ; FUN_005e0e40 */

int * __thiscall FUN_005e0e40(int *param_1,int param_2)

{
  int *piVar1;
  int iStack_18;
  int iStack_14;
  
  if (param_2 < 1) {
    if (param_2 < 0) {
      FUN_005e0da0(-param_2);
    }
  }
  else {
    piVar1 = (int *)*param_1;
    if (param_1[1] == 0) {
      iStack_14 = *(int *)(*param_1 + 0xc);
    }
    else {
      iStack_14 = param_1[1];
    }
    if ((iStack_14 - *piVar1) / 0x18 < param_2) {
      iStack_18 = param_2 - (piVar1[1] - *piVar1) / 0x18;
    }
    else {
      iStack_18 = param_2;
    }
    param_1[1] = iStack_14 + iStack_18 * -0x18;
  }
  return param_1;
}



/* FUNCTION 5668 ; VA 0x005e0ef0 ; FUN_005e0ef0 */

void __fastcall FUN_005e0ef0(undefined4 param_1)

{
  FUN_005e0850(param_1);
  FUN_00551040();
  return;
}



/* FUNCTION 5669 ; VA 0x005e0f0e ; FUN_005e0f0e */

void FUN_005e0f0e(void)

{
  FUN_005e0f30();
  return;
}



/* FUNCTION 5670 ; VA 0x005e0f19 ; FUN_005e0f19 */

void FUN_005e0f19(void)

{
  FUN_005e0f30();
  return;
}



/* FUNCTION 5671 ; VA 0x005e0f21 ; FUN_005e0f21 */

void FUN_005e0f21(void)

{
  FUN_005e0f70();
  return;
}



/* FUNCTION 5672 ; VA 0x005e0f30 ; FUN_005e0f30 */

undefined4 __thiscall FUN_005e0f30(undefined4 param_1,uint param_2)

{
  FUN_005e0850();
  FUN_00551040();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 5673 ; VA 0x005e0f70 ; FUN_005e0f70 */

undefined4 * __thiscall FUN_005e0f70(undefined4 *param_1,uint param_2)

{
  *param_1 = boost::exception_detail::error_info_injector<class_std::length_error>::vftable;
  param_1[3] = boost::exception_detail::error_info_injector<class_std::length_error>::vftable;
  FUN_00551060();
  FUN_00550f40();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  return param_1;
}



/* FUNCTION 5674 ; VA 0x005e0fc0 ; FUN_005e0fc0 */

undefined4 __thiscall FUN_005e0fc0(undefined4 param_1,uint param_2)

{
  FUN_016894b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x44);
  }
  return param_1;
}



/* FUNCTION 5675 ; VA 0x005e0ff0 ; FUN_005e0ff0 */

bool FUN_005e0ff0(void)

{
  bool bVar1;
  
  bVar1 = DAT_01ea9378 != '\0';
  DAT_01ea9378 = 1;
  return bVar1;
}



/* FUNCTION 5676 ; VA 0x005e1050 ; FUN_005e1050 */

int __thiscall FUN_005e1050(int param_1,undefined4 param_2,undefined4 param_3)

{
  char acStack_128 [260];
  uint uStack_24;
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  uint uStack_14;
  char *pcStack_10;
  char cStack_9;
  int iStack_8;
  
  iStack_8 = 0;
  iStack_18 = param_1;
  iStack_8 = FUN_005e19a0(param_2,param_3,param_1 + 0x24c);
  if (-1 < iStack_8) {
    FUN_006841d0(param_2,0,0);
    FUN_00684190(param_2);
    FUN_005e19a0(acStack_128,0x104,iStack_18 + 0xcc);
    pcStack_10 = (char *)(iStack_18 + 0xcc);
    iStack_1c = iStack_18 + 0xcd;
    do {
      cStack_9 = *pcStack_10;
      pcStack_10 = pcStack_10 + 1;
    } while (cStack_9 != '\0');
    uStack_20 = (int)pcStack_10 - (iStack_18 + 0xcd);
    uStack_24 = uStack_20;
    for (uStack_14 = 0; uStack_14 < uStack_24; uStack_14 = uStack_14 + 1) {
      if (acStack_128[uStack_14] == ':') {
        acStack_128[uStack_14] = '.';
      }
    }
    iStack_8 = FUN_005e18f0(param_2,param_3,acStack_128);
    if ((-1 < iStack_8) && (iStack_8 = FUN_005e18f0(param_2,param_3,&DAT_018c0fb8), -1 < iStack_8))
    {
      iStack_8 = 0;
    }
  }
  return iStack_8;
}



/* FUNCTION 5677 ; VA 0x005e1180 ; FUN_005e1180 */

int __thiscall
FUN_005e1180(int param_1,undefined4 param_2,undefined4 param_3,char param_4,char param_5)

{
  char cStack_230;
  undefined auStack_22f [259];
  char acStack_12c [260];
  uint uStack_28;
  uint uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  int iStack_18;
  uint uStack_14;
  char *pcStack_10;
  char cStack_9;
  int iStack_8;
  
  iStack_8 = 0;
  iStack_18 = param_1;
  FUN_005e1a20(&cStack_230,0x104,"%s %s",param_1 + 0xcc,param_1 + 0x14c);
  iStack_8 = FUN_005e19a0(param_2,param_3,iStack_18 + 0x24c);
  if (-1 < iStack_8) {
    FUN_006841d0(param_2,0,0);
    FUN_00684190(param_2);
    FUN_005e19a0(acStack_12c,0x104,&cStack_230);
    pcStack_10 = &cStack_230;
    puStack_20 = auStack_22f;
    do {
      cStack_9 = *pcStack_10;
      pcStack_10 = pcStack_10 + 1;
    } while (cStack_9 != '\0');
    uStack_24 = (int)pcStack_10 - (int)auStack_22f;
    uStack_28 = uStack_24;
    for (uStack_14 = 0; uStack_14 < uStack_28; uStack_14 = uStack_14 + 1) {
      if (acStack_12c[uStack_14] == ':') {
        acStack_12c[uStack_14] = '.';
      }
    }
    iStack_8 = FUN_005e18f0(param_2,param_3,acStack_12c);
    if ((-1 < iStack_8) &&
       ((param_5 == '\0' || (iStack_8 = FUN_005e18f0(param_2,param_3,".Full"), -1 < iStack_8)))) {
      if (param_4 == '\0') {
        puStack_1c = (undefined *)(iStack_18 + 0x350);
      }
      else {
        puStack_1c = &DAT_018c0e60;
      }
      iStack_8 = FUN_005e18f0(param_2,param_3,puStack_1c);
      if (-1 < iStack_8) {
        iStack_8 = 0;
      }
    }
  }
  return iStack_8;
}



/* FUNCTION 5678 ; VA 0x005e1320 ; FUN_005e1320 */

void FUN_005e1320(void)

{
  void *pvStack_14;
  undefined *puStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &DAT_01c24578;
  puStack_10 = &LAB_0170d9e8;
  pvStack_14 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_14;
  RaiseException(0,0,0,0);
  ExceptionList = pvStack_14;
  return;
}



/* FUNCTION 5679 ; VA 0x005e13a0 ; FUN_005e13a0 */

void __fastcall FUN_005e13a0(int param_1)

{
  if (DAT_01f754a0 != '\0') {
    FUN_016774b0(DAT_01f754a0,"Letting watcher thread know we\'re alive",0);
  }
  *(undefined *)(param_1 + 0x2c) = 1;
  *(undefined *)(param_1 + 0x2e) = 1;
  return;
}



/* FUNCTION 5680 ; VA 0x005e13e0 ; FUN_005e13e0 */

undefined4 FUN_005e13e0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined uStack_8c;
  int iStack_8b;
  undefined auStack_28 [8];
  int iStack_20;
  code *pcStack_1c;
  code *pcStack_18;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  int iStack_8;
  
  cVar1 = FUN_005542b0();
  if (cVar1 != '\0') {
    cVar1 = FUN_005512d0();
    if (cVar1 != '\0') {
      iStack_10 = GetModuleHandleA("kernel32.dll");
      goto LAB_005e1424;
    }
  }
  iStack_10 = LoadLibraryA("kernel32.dll");
LAB_005e1424:
  iStack_14 = iStack_10;
  if (iStack_10 == 0) {
    uVar2 = 0;
  }
  else {
    iStack_c = GetProcAddress(iStack_10,"SetUnhandledExceptionFilter");
    if (iStack_c == 0) {
      uVar2 = 0;
    }
    else {
      iStack_8 = iStack_c + 5;
      pcStack_18 = FUN_005e1e60;
      pcStack_1c = FUN_005e1e60;
      iStack_8b = (int)FUN_005e1e60 - iStack_8;
      uStack_8c = 0xe9;
      iStack_20 = iStack_8b;
      uVar2 = GetCurrentProcess(iStack_c,&uStack_8c,5,auStack_28);
      uVar2 = WriteProcessMemory(uVar2);
    }
  }
  return uVar2;
}



/* FUNCTION 5681 ; VA 0x005e14d0 ; FUN_005e14d0 */

char FUN_005e14d0(undefined4 param_1,undefined4 param_2,char param_3,char param_4,int param_5,
                 int param_6)

{
  undefined4 uVar1;
  uint uVar2;
  undefined auStack_134 [260];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined uStack_1f;
  char cStack_1e;
  char cStack_1d;
  undefined *puStack_1c;
  void *pvStack_14;
  undefined *puStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &DAT_01c246d0;
  puStack_10 = &LAB_0170d9e8;
  pvStack_14 = ExceptionList;
  puStack_1c = &stack0xfffffec0;
  cStack_1d = 0;
  if ((param_3 == '\0') || (DAT_01ea8f97 != '\0')) {
    uStack_28 = 0;
  }
  else {
    uStack_28 = 1;
  }
  uVar1 = uStack_28;
  uStack_8 = 0;
  if ((param_5 == 0) || (param_6 == 0)) {
    uStack_2c = 0;
  }
  else {
    uStack_2c = 1;
  }
  cStack_1e = (char)uStack_2c;
  ExceptionList = &pvStack_14;
  FUN_0170d1f0(auStack_134,0,0x104);
  if (cStack_1e == '\0') {
    uVar2 = FUN_01679ce0();
    if ((int)(uVar2 % 100) < DAT_01ea8f90) {
      uStack_30 = 1;
      goto LAB_005e1596;
    }
  }
  uStack_30 = 0;
LAB_005e1596:
  uStack_1f = (undefined)uStack_30;
  FUN_005e2ec0(param_5,param_6);
  cStack_1d = FUN_005e46d0(param_1,param_2,auStack_134,uStack_1f,uVar1,param_5,param_6);
  if ((cStack_1d != '\0') && (param_4 != '\0')) {
    FUN_005e2110();
  }
  if (DAT_01ea8f94 != '\0') {
    FUN_005e2670(auStack_134);
  }
  ExceptionList = pvStack_14;
  return cStack_1d;
}



/* FUNCTION 5682 ; VA 0x005e1640 ; FUN_005e1640 */

uint __thiscall FUN_005e1640(int *param_1,int param_2)

{
  code *pcVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  
  if (DAT_01d7abf8 != '\0') {
    FUN_016774b0(DAT_01d7abf8,"Processing exception in thread",0);
  }
  cVar2 = FUN_0168a370();
  if (cVar2 != '\0') {
    FUN_0151f3f0();
    FUN_00586350();
  }
  cVar2 = FUN_0168a370();
  if (cVar2 == '\0') {
    pcVar1 = *(code **)(*param_1 + 4);
    uVar4 = GetCurrentThreadId();
    uVar5 = (*pcVar1)(param_2,uVar4,0,0,0,0);
    uVar5 = uVar5 & 0xff;
  }
  else {
    param_1[5] = param_2;
    iVar3 = GetCurrentThreadId();
    param_1[6] = iVar3;
    FUN_0151f3f0();
    FUN_00586350();
    uVar5 = param_1[4];
  }
  return uVar5;
}



/* FUNCTION 5683 ; VA 0x005e1720 ; FUN_005e1720 */

void FUN_005e1720(void)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_44 [8];
  undefined auStack_3c [8];
  undefined4 uStack_34;
  undefined *puStack_30;
  undefined4 uStack_2c;
  undefined *puStack_28;
  undefined4 uStack_24;
  undefined auStack_1c [4];
  undefined auStack_18 [4];
  undefined uStack_14;
  undefined uStack_13;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ae20;
  pvStack_10 = ExceptionList;
  uStack_34 = 0;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_005542b0();
  if (cVar1 != '\0') {
    cVar1 = FUN_005512d0();
    if (cVar1 != '\0') {
      cStack_11 = '\x01';
      goto LAB_005e176c;
    }
  }
  cStack_11 = '\0';
LAB_005e176c:
  cStack_12 = cStack_11;
  if (cStack_11 == '\0') {
    SetUnhandledExceptionFilter(FUN_005e2cb0);
    FUN_005e13e0();
  }
  else {
    iVar2 = IsDebuggerPresent();
    if (iVar2 == 0) {
      SetErrorMode(3);
      SetUnhandledExceptionFilter(FUN_005e2cb0);
      FUN_017167f4(FUN_005e20e0);
      FUN_0170c0ba(FUN_005e20e0);
      FUN_0171d14a(FUN_005e2c90);
      FUN_01725aa3(0x16,FUN_005e2ae0);
      FUN_01725aa3(0xf,FUN_005e2b10);
      FUN_0171d6d2(0,0);
      FUN_005e13e0();
    }
  }
  uStack_24 = DAT_01ea8f98;
  uVar3 = FUN_005dfdb0(auStack_3c,uStack_13,FUN_005e2d00,DAT_01ea8f98);
  FUN_005dff70(auStack_18,uVar3);
  uStack_8 = 0;
  FUN_0058c3b0();
  puStack_28 = auStack_18;
  uStack_8 = 1;
  FUN_005e0cb0(puStack_28);
  uStack_8 = 0xffffffff;
  FUN_0056ebb0();
  uStack_2c = DAT_01ea8f98;
  uVar3 = FUN_005dfdb0(auStack_44,uStack_14,FUN_005e2b40,DAT_01ea8f98);
  FUN_005dff70(auStack_1c,uVar3);
  uStack_8 = 2;
  FUN_0058c3b0();
  puStack_30 = auStack_1c;
  uStack_8 = 3;
  FUN_005e0cb0(puStack_30);
  uStack_8 = 0xffffffff;
  FUN_0056ebb0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5684 ; VA 0x005e18f0 ; FUN_005e18f0 */

int FUN_005e18f0(char *param_1,uint param_2,int param_3)

{
  int iVar1;
  char *pcVar2;
  int iVar3;
  uint uVar4;
  
  iVar3 = 0;
  if ((param_2 == 0) || (0x7fffffff < param_2)) {
    iVar3 = -0x7ff8ffa9;
  }
  if (iVar3 < 0) {
    uVar4 = 0;
  }
  else {
    pcVar2 = param_1;
    uVar4 = param_2;
    if (param_2 != 0) {
      do {
        if (*pcVar2 == '\0') break;
        uVar4 = uVar4 - 1;
        pcVar2 = pcVar2 + 1;
      } while (uVar4 != 0);
    }
    iVar3 = -0x7ff8ffa9;
    if (uVar4 != 0) {
      iVar3 = 0;
    }
    uVar4 = -(uint)(uVar4 != 0) & param_2 - uVar4;
  }
  if (iVar3 < 0) {
    return iVar3;
  }
  param_1 = param_1 + uVar4;
  iVar3 = param_2 - uVar4;
  if (iVar3 != 0) {
    iVar1 = (iVar3 - param_2) + uVar4 + 0x7ffffffe;
    param_3 = param_3 - (int)param_1;
    do {
      if ((iVar1 == 0) || (param_1[param_3] == '\0')) break;
      *param_1 = param_1[param_3];
      iVar1 = iVar1 + -1;
      param_1 = param_1 + 1;
      iVar3 = iVar3 + -1;
    } while (iVar3 != 0);
  }
  pcVar2 = param_1 + -1;
  if (iVar3 != 0) {
    pcVar2 = param_1;
  }
  *pcVar2 = '\0';
  iVar1 = -0x7ff8ff86;
  if (iVar3 != 0) {
    iVar1 = 0;
  }
  return iVar1;
}



/* FUNCTION 5685 ; VA 0x005e19a0 ; FUN_005e19a0 */

int FUN_005e19a0(char *param_1,uint param_2,int param_3)

{
  int iVar1;
  char *pcVar2;
  
  iVar1 = 0;
  if ((param_2 == 0) || (0x7fffffff < param_2)) {
    iVar1 = -0x7ff8ffa9;
  }
  if (iVar1 < 0) {
    if (param_2 != 0) {
      *param_1 = '\0';
    }
    return iVar1;
  }
  if (param_2 != 0) {
    iVar1 = 0x7ffffffe - param_2;
    param_3 = param_3 - (int)param_1;
    do {
      if ((iVar1 + param_2 == 0) || (param_1[param_3] == '\0')) break;
      *param_1 = param_1[param_3];
      param_1 = param_1 + 1;
      param_2 = param_2 - 1;
    } while (param_2 != 0);
  }
  pcVar2 = param_1 + -1;
  if (param_2 != 0) {
    pcVar2 = param_1;
  }
  *pcVar2 = '\0';
  iVar1 = -0x7ff8ff86;
  if (param_2 != 0) {
    iVar1 = 0;
  }
  return iVar1;
}



/* FUNCTION 5686 ; VA 0x005e1a20 ; FUN_005e1a20 */

int FUN_005e1a20(undefined *param_1,uint param_2,undefined4 param_3)

{
  int iVar1;
  uint *puVar2;
  uint uVar3;
  
  iVar1 = 0;
  if ((param_2 == 0) || (0x7fffffff < param_2)) {
    iVar1 = -0x7ff8ffa9;
  }
  if (-1 < iVar1) {
    iVar1 = 0;
    param_2 = param_2 - 1;
    puVar2 = (uint *)FUN_005574c0(param_1,param_2,param_3,0,&stack0x00000010);
    uVar3 = FUN_0171d0ba(*puVar2 | 1,puVar2[1]);
    if ((int)uVar3 < 0) {
      uVar3 = 0xffffffff;
    }
    if (((int)uVar3 < 0) || (param_2 < uVar3)) {
      param_1[param_2] = 0;
      iVar1 = -0x7ff8ff86;
    }
    else if (uVar3 == param_2) {
      param_1[param_2] = 0;
      return 0;
    }
    return iVar1;
  }
  if (param_2 != 0) {
    *param_1 = 0;
  }
  return iVar1;
}



/* FUNCTION 5687 ; VA 0x005e1aa0 ; FUN_005e1aa0 */

undefined4 * __thiscall FUN_005e1aa0(undefined4 *param_1,undefined4 *param_2)

{
  *param_2 = *(undefined4 *)*param_1;
  FUN_00553510(0);
  return param_2;
}



/* FUNCTION 5688 ; VA 0x005e1ae0 ; FUN_005e1ae0 */

undefined4 * __thiscall FUN_005e1ae0(undefined4 *param_1,undefined4 *param_2)

{
  *param_2 = *param_1;
  FUN_00553510(0);
  return param_2;
}



/* FUNCTION 5689 ; VA 0x005e1b20 ; FUN_005e1b20 */

undefined4 FUN_005e1b20(uint param_1)

{
  undefined4 uVar1;
  undefined4 uStack_24;
  uint *puStack_20;
  uint uStack_1c;
  uint uStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ae38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_18 = FUN_00555290();
  uStack_11 = 1;
  uStack_1c = 0xaaaaaaa;
  if (uStack_18 < 0xaaaaaaa) {
    puStack_20 = &uStack_18;
  }
  else {
    puStack_20 = &uStack_1c;
  }
  if (*puStack_20 < param_1) {
    uVar1 = FUN_005e07c0("circular_buffer");
    uStack_8 = 0;
    FUN_005dffd0(uVar1);
    uStack_8 = 0xffffffff;
    FUN_00550f40();
  }
  if (param_1 == 0) {
    uStack_24 = 0;
  }
  else {
    uStack_24 = FUN_00577fb0(param_1);
  }
  ExceptionList = pvStack_10;
  return uStack_24;
}



/* FUNCTION 5690 ; VA 0x005e1bf2 ; FUN_005e1bf2 */

void FUN_005e1bf2(void)

{
  FUN_005e1c00();
  return;
}



/* FUNCTION 5691 ; VA 0x005e1c00 ; FUN_005e1c00 */

int __fastcall FUN_005e1c00(int param_1)

{
  int iVar1;
  int iStack_24;
  int iStack_20;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ae5f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01674e20(0x2c,0);
  uStack_8 = 0;
  if (iVar1 == 0) {
    iStack_20 = 0;
  }
  else {
    iStack_20 = FUN_005e0190(param_1 + -0x28,uStack_11,1);
  }
  if (iStack_20 == 0) {
    iStack_24 = 0;
  }
  else {
    iStack_24 = iStack_20 + 0x20 + *(int *)(*(int *)(iStack_20 + 0x20) + 4);
  }
  ExceptionList = pvStack_10;
  return iStack_24;
}



/* FUNCTION 5692 ; VA 0x005e1cb0 ; FUN_005e1cb0 */

void __thiscall FUN_005e1cb0(int param_1,int param_2,int param_3)

{
  int iStack_c;
  uint uStack_8;
  
  if (param_2 != 0) {
    uStack_8 = param_3 * 0x18;
    iStack_c = param_2;
    if (0xfff < uStack_8) {
      FUN_005534e0(&iStack_c,&uStack_8,param_1 + 0x14);
    }
    FUN_01674ea0(iStack_c,uStack_8);
  }
  return;
}



/* FUNCTION 5693 ; VA 0x005e1d10 ; FUN_005e1d10 */

void FUN_005e1d10(void)

{
  int iStack_18;
  int iStack_14;
  uint uStack_10;
  int *piStack_c;
  undefined uStack_5;
  
  FUN_005e1d90(&uStack_5);
  iStack_18 = *piStack_c;
  if (iStack_18 != 0) {
    uStack_10 = ((piStack_c[1] - *piStack_c) / 0x18) * 0x18;
    iStack_14 = iStack_18;
    if (0xfff < uStack_10) {
      FUN_005534e0(&iStack_18,&uStack_10,piStack_c + 5);
    }
    FUN_01674ea0(iStack_18,uStack_10);
  }
  return;
}



/* FUNCTION 5694 ; VA 0x005e1d90 ; FUN_005e1d90 */

/* WARNING: Removing unreachable block (ram,0x005e1e34) */

void __fastcall FUN_005e1d90(int *param_1)

{
  int *piVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  ExceptionList = &pvStack_10;
  while (uStack_20 < (uint)param_1[4]) {
    uStack_8 = 0;
    FUN_005507b0();
    uStack_20 = uStack_20 + 1;
    piVar1 = param_1 + 2;
    *piVar1 = *piVar1 + 0x18;
    if (*piVar1 == param_1[1]) {
      *piVar1 = *param_1;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5695 ; VA 0x005e1e60 ; FUN_005e1e60 */

undefined4 FUN_005e1e60(void)

{
  return 0;
}



/* FUNCTION 5696 ; VA 0x005e1e70 ; FUN_005e1e70 */

bool FUN_005e1e70(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  bool bVar3;
  
  if (param_1 == (undefined4 *)0x0) {
    bVar3 = false;
  }
  else {
    iVar1 = OpenThread(0x4a,0,DAT_01ea8f9c);
    if (iVar1 == 0) {
      bVar3 = false;
    }
    else {
      iVar2 = SuspendThread(iVar1);
      if (iVar2 == -1) {
        bVar3 = false;
      }
      else {
        *param_1 = 0x1003f;
        iVar2 = GetThreadContext(iVar1,param_1);
        bVar3 = iVar2 != 0;
        ResumeThread(iVar1);
        CloseHandle(iVar1);
      }
    }
  }
  return bVar3;
}



/* FUNCTION 5697 ; VA 0x005e1f00 ; FUN_005e1f00 */

void __thiscall FUN_005e1f00(undefined4 param_1,undefined4 param_2)

{
  FUN_005e1f20(param_1,param_2);
  return;
}



/* FUNCTION 5698 ; VA 0x005e1f20 ; FUN_005e1f20 */

void FUN_005e1f20(undefined4 param_1,int param_2)

{
  void *pvStack_14;
  undefined *puStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &DAT_01c24558;
  puStack_10 = &LAB_0170d9e8;
  pvStack_14 = ExceptionList;
  if (param_2 == 0) {
    uStack_8 = 0;
    ExceptionList = &pvStack_14;
    RaiseException(0x80000003,0,0,0);
  }
  else {
    ExceptionList = &pvStack_14;
    FUN_005e1640(param_2);
  }
  ExceptionList = pvStack_14;
  return;
}



/* FUNCTION 5699 ; VA 0x005e1fb0 ; FUN_005e1fb0 */

void __thiscall FUN_005e1fb0(int param_1,int param_2)

{
  char cVar1;
  undefined auStack_1c [4];
  undefined auStack_18 [4];
  undefined4 uStack_14;
  undefined4 uStack_10;
  int iStack_c;
  int iStack_8;
  
  iStack_8 = param_1;
  if (param_2 == 0) {
    FUN_005e1320(param_1);
  }
  else {
    cVar1 = FUN_0168a370();
    if (cVar1 != '\0') {
      FUN_0151f3f0();
      FUN_00586350();
    }
    cVar1 = FUN_0168a370();
    if (cVar1 != '\0') {
      iStack_c = iStack_8 + 0x24;
      uStack_14 = FUN_01689df0(auStack_18);
      uStack_10 = FUN_01689dd0(auStack_1c);
      cVar1 = FUN_005e0cd0(uStack_10);
      if (cVar1 != '\0') {
        if (DAT_01d7abf8 != '\0') {
          FUN_016774b0(DAT_01d7abf8,"Processing exception in watcher thread",0);
        }
        *(int *)(iStack_8 + 0x14) = param_2;
        FUN_0151f3f0();
        FUN_00586350();
        return;
      }
    }
    if (DAT_01d7abf8 != '\0') {
      FUN_016774b0(DAT_01d7abf8,"Processing exception in crashing thread",0);
    }
    FUN_005e2410(param_2);
  }
  return;
}



/* FUNCTION 5700 ; VA 0x005e20d0 ; FUN_005e20d0 */

int __fastcall FUN_005e20d0(int param_1)

{
  return param_1 + 0x18;
}



/* FUNCTION 5701 ; VA 0x005e20e0 ; FUN_005e20e0 */

void FUN_005e20e0(void)

{
  FUN_005e25e0(0);
  return;
}



/* FUNCTION 5702 ; VA 0x005e2100 ; FUN_005e2100 */

undefined FUN_005e2100(void)

{
  return 0;
}



/* FUNCTION 5703 ; VA 0x005e2110 ; FUN_005e2110 */

undefined FUN_005e2110(void)

{
  return 0;
}



/* FUNCTION 5704 ; VA 0x005e2120 ; FUN_005e2120 */

/* WARNING: Removing unreachable block (ram,0x005e21c7) */
/* WARNING: Restarted to delay deadcode elimination for space: stack */

undefined4 * __thiscall FUN_005e2120(undefined4 *param_1,undefined4 *param_2)

{
  char cVar1;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  uStack_1c = 0;
  if ((param_1[1] != 0) && (ExceptionList = &pvStack_10, cVar1 = FUN_00576f40(), cVar1 != '\0')) {
    uStack_20 = *param_1;
    uStack_1c = param_1[1];
  }
  *param_2 = 0;
  param_2[1] = 0;
  *param_2 = uStack_20;
  param_2[1] = uStack_1c;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5705 ; VA 0x005e21f0 ; FUN_005e21f0 */

undefined4 FUN_005e21f0(undefined4 param_1,undefined4 param_2)

{
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ae78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005e4ba0(&DAT_01ea9238,0x40,"RBXCRASH-%s",param_1);
  FUN_005e4ba0(&DAT_01ea9278,0x100,&DAT_018bd25c,param_2);
  FUN_0054eff0(&DAT_01ea9238);
  uStack_8 = 0;
  FUN_008783f0(auStack_28,1,0);
  uStack_8 = 1;
  FUN_005507b0();
  uStack_8 = 0xffffffff;
  FUN_0087b360();
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 5706 ; VA 0x005e2290 ; FUN_005e2290 */

void __fastcall FUN_005e2290(undefined4 param_1)

{
  FUN_005e22b0(param_1);
  return;
}



/* FUNCTION 5707 ; VA 0x005e22b0 ; FUN_005e22b0 */

void FUN_005e22b0(undefined4 *param_1)

{
  char cVar1;
  undefined8 uVar2;
  undefined auStack_54 [8];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  int iStack_44;
  int iStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 *puStack_2c;
  int iStack_28;
  code *pcStack_24;
  undefined uStack_1d;
  undefined *puStack_1c;
  void *pvStack_14;
  undefined *puStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &DAT_01c24568;
  puStack_10 = &LAB_0170d9e8;
  pvStack_14 = ExceptionList;
  puStack_1c = &stack0xffffffa0;
  pcStack_24 = *(code **)*param_1;
  ExceptionList = &pvStack_14;
  (*pcStack_24)("WatcherThread Detected hang.");
  if (DAT_01f754a0 != '\0') {
    FUN_016774b0(DAT_01f754a0,"WatcherThread Detected hang.",0);
  }
  iStack_44 = DAT_01d59878 / 2;
  iStack_40 = iStack_44 >> 0x1f;
  iStack_28 = iStack_44;
  puStack_2c = (undefined4 *)FUN_0054dca0(auStack_54,&iStack_44);
  uStack_4c = *puStack_2c;
  uStack_48 = puStack_2c[1];
  uStack_3c = uStack_4c;
  uStack_38 = uStack_48;
  uVar2 = FUN_0151ab90(&uStack_4c);
  *(undefined8 *)(param_1 + 0xc) = uVar2;
  FUN_0151dab0();
  uStack_1d = 0;
  cVar1 = FUN_005512d0();
  if (cVar1 != '\0') {
    uStack_1d = *(undefined *)((int)param_1 + 0x2f);
  }
  uStack_8 = 0;
  RaiseException(0x80000003,0,0,0);
  ExceptionList = pvStack_14;
  return;
}



/* FUNCTION 5708 ; VA 0x005e2410 ; FUN_005e2410 */

/* WARNING: Removing unreachable block (ram,0x005e25b7) */

void __thiscall FUN_005e2410(int *param_1,undefined4 param_2)

{
  code *pcVar1;
  char cVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ae98;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_005512d0();
  if (cVar2 == '\0') {
    if (*(char *)(param_1 + 0x2e) == '\0') {
      FUN_00587410(param_1 + 0x2f);
      uStack_8 = 0;
      if (*(char *)(param_1 + 0x2e) == '\0') {
        *(undefined *)(param_1 + 0x2e) = 1;
        if (param_1[0xf] != 0) {
          VirtualFree(param_1[0xf],0,0x8000);
          param_1[0xf] = 0;
        }
        cVar2 = FUN_005512d0();
        if ((cVar2 == '\0') || (DAT_01ea8f96 == '\0')) {
          (**(code **)(*param_1 + 8))();
        }
        FUN_005e1f00(param_2);
        FUN_005e4a00();
      }
    }
  }
  else {
    if (DAT_01d7abf8 != '\0') {
      FUN_016774b0(DAT_01d7abf8,"Processing non-hang",0);
    }
    if (param_1[0xf] != 0) {
      VirtualFree(param_1[0xf],0,0x8000);
      param_1[0xf] = 0;
    }
    pcVar1 = *(code **)(*param_1 + 4);
    uVar3 = GetCurrentThreadId();
    (*pcVar1)(param_2,uVar3,0,1,0,0);
    cVar2 = FUN_005512d0();
    if ((cVar2 == '\0') || (DAT_01ea8f96 == '\0')) {
      (**(code **)(*param_1 + 8))();
    }
    FUN_005e4a00();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5709 ; VA 0x005e25e0 ; FUN_005e25e0 */

/* WARNING: Removing unreachable block (ram,0x005e264c) */

void __thiscall FUN_005e25e0(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179aeb8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410(param_1 + 0xbc);
  uStack_8 = 0;
  FUN_005e1fb0(param_2);
  uVar1 = GetCurrentProcess(1);
  TerminateProcess(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5710 ; VA 0x005e2670 ; FUN_005e2670 */

void FUN_005e2670(int param_1)

{
  undefined auStack_44 [24];
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  uint uStack_20;
  int iStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179aee0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0151f6f0(0xffffffff,0,0);
  iStack_8 = 0;
  iStack_1c = 0;
  for (uStack_14 = 0; uStack_14 < 0x104; uStack_14 = uStack_14 + 1) {
    if (*(char *)(param_1 + uStack_14) == '\\') {
      iStack_1c = uStack_14 + 1;
    }
    else if (*(char *)(param_1 + uStack_14) == '\0') break;
  }
  puStack_28 = &DAT_01ea8fac;
  puStack_18 = &DAT_01ea8fac;
  puStack_24 = &DAT_01ea8fac;
  uStack_20 = (uint)(0xf < DAT_01ea8fc0);
  if (0xf < DAT_01ea8fc0) {
    puStack_24 = DAT_01ea8fac;
  }
  puStack_2c = puStack_24;
  FUN_0151f850(&DAT_018c7ed0,puStack_24);
  FUN_0151f850(&DAT_018c7ed8,param_1 + iStack_1c);
  FUN_0054eff0("report");
  iStack_8._0_1_ = 1;
  FUN_01520d20(auStack_44,10000,1);
  iStack_8._0_1_ = 2;
  FUN_005507b0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_0087c6f0("Error","LoggableCrash",param_1 + iStack_1c,0,0,1,3);
  iStack_8 = 0xffffffff;
  FUN_0151f7f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5711 ; VA 0x005e27d0 ; FUN_005e27d0 */

void __thiscall FUN_005e27d0(int *param_1,int param_2,int param_3,int param_4)

{
  int iStack_c;
  
  FUN_005e1d10();
  param_1[4] = (param_3 - param_2) / 0x18;
  *param_1 = param_2;
  param_1[2] = param_2;
  param_1[1] = param_4 * 0x18 + *param_1;
  if (param_3 == param_1[1]) {
    iStack_c = *param_1;
  }
  else {
    iStack_c = param_3;
  }
  param_1[3] = iStack_c;
  return;
}



/* FUNCTION 5712 ; VA 0x005e2840 ; FUN_005e2840 */

/* WARNING: Restarted to delay deadcode elimination for space: stack */

void __fastcall FUN_005e2840(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_8 = 0;
  if (iVar1 != 0) {
    FUN_00585f30(iVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5713 ; VA 0x005e28b9 ; FUN_005e28b9 */

void FUN_005e28b9(void)

{
  FUN_005e28d0();
  return;
}



/* FUNCTION 5714 ; VA 0x005e28d0 ; FUN_005e28d0 */

void __fastcall FUN_005e28d0(int param_1)

{
  undefined auStack_34 [44];
  int iStack_8;
  
  iStack_8 = param_1;
  FUN_005e03b0(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_34,&DAT_01c24940);
}



/* FUNCTION 5715 ; VA 0x005e2900 ; FUN_005e2900 */

void __fastcall FUN_005e2900(undefined4 param_1)

{
  FUN_005e0d60(param_1);
  return;
}



/* FUNCTION 5716 ; VA 0x005e2920 ; FUN_005e2920 */

void __thiscall FUN_005e2920(int *param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179aef0;
  pvStack_10 = ExceptionList;
  if (param_2 != (param_1[1] - *param_1) / 0x18) {
    ExceptionList = &pvStack_10;
    FUN_005e1b20();
    uStack_8 = 0;
    FUN_005e0da0();
    FUN_005e0070();
    FUN_005e27d0();
    FUN_005e2a9f();
    return;
  }
  ExceptionList = &pvStack_10;
  FUN_005e2aaf();
  return;
}



/* FUNCTION 5717 ; VA 0x005e2a80 ; Catch_All@005e2a80 */

void Catch_All_005e2a80(void)

{
  int unaff_EBP;
  
  FUN_005e1cb0(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5718 ; VA 0x005e2a9f ; FUN_005e2a9f */

void FUN_005e2a9f(void)

{
  int unaff_EBP;
  
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  FUN_005e2aaf();
  return;
}



/* FUNCTION 5719 ; VA 0x005e2aaf ; FUN_005e2aaf */

void FUN_005e2aaf(void)

{
  int unaff_EBP;
  
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 5720 ; VA 0x005e2ad0 ; thunk_FUN_0151a220 */

void thunk_FUN_0151a220(undefined4 param_1)

{
  undefined4 uVar1;
  
  if (DAT_01d7a638 != '\0') {
    uVar1 = GetCurrentThreadId(param_1);
    FUN_0151a240(uVar1);
  }
  return;
}



/* FUNCTION 5721 ; VA 0x005e2ae0 ; FUN_005e2ae0 */

void FUN_005e2ae0(void)

{
  FUN_01725aa3(0x16,FUN_005e2ae0);
  FUN_005e25e0(0);
  return;
}



/* FUNCTION 5722 ; VA 0x005e2b10 ; FUN_005e2b10 */

void FUN_005e2b10(void)

{
  FUN_01725aa3(0xf,FUN_005e2b10);
  FUN_005e25e0(0);
  return;
}



/* FUNCTION 5723 ; VA 0x005e2b40 ; FUN_005e2b40 */

void __fastcall FUN_005e2b40(int param_1)

{
  bool bVar1;
  char cVar2;
  int iVar3;
  code *pcStack_10;
  
  thunk_FUN_0151a220("CrashReporter_SoftHangWatcherThreadFunc");
  bVar1 = false;
  while ((!bVar1 && (*(char *)(param_1 + 0x38) == '\0'))) {
    iVar3 = param_1 + 0x20;
    cVar2 = FUN_0151f440(DAT_01d59880);
    if (cVar2 == '\0') {
      cVar2 = FUN_005e0cf0(iVar3);
      if (cVar2 == '\0') {
        cVar2 = FUN_00554d10();
        if (cVar2 == '\0') {
          pcStack_10 = _guard_check_icall;
        }
        else {
          pcStack_10 = (code *)0x0;
        }
        if (pcStack_10 != (code *)0x0) {
          FUN_005515c0();
        }
      }
      else {
        FUN_005c4bf0(0);
      }
    }
    else {
      bVar1 = true;
    }
  }
  return;
}



/* FUNCTION 5724 ; VA 0x005e2c00 ; FUN_005e2c00 */

void __thiscall FUN_005e2c00(int param_1,int param_2)

{
  undefined auStack_34 [32];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179af08;
  pvStack_10 = ExceptionList;
  if (param_2 != param_1) {
    ExceptionList = &pvStack_10;
    iStack_14 = param_1;
    FUN_00550050();
    uStack_8 = 0;
    FUN_005880d0(iStack_14);
    FUN_005880d0(param_2);
    FUN_005880d0(auStack_34);
    uStack_8 = 1;
    FUN_00554430();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5725 ; VA 0x005e2c90 ; FUN_005e2c90 */

void FUN_005e2c90(void)

{
  FUN_0171d14a(FUN_005e2c90);
  FUN_005e25e0(0);
  return;
}



/* FUNCTION 5726 ; VA 0x005e2cb0 ; FUN_005e2cb0 */

undefined4 FUN_005e2cb0(undefined4 param_1)

{
  char cVar1;
  undefined4 uVar2;
  
  cVar1 = FUN_005512d0();
  if (cVar1 == '\0') {
    FUN_005e2410(param_1);
    uVar2 = FUN_01716b1d(1);
  }
  else {
    FUN_005e25e0(param_1);
    uVar2 = 0;
  }
  return uVar2;
}



/* FUNCTION 5727 ; VA 0x005e2d00 ; FUN_005e2d00 */

void __fastcall FUN_005e2d00(int *param_1)

{
  bool bVar1;
  char cVar2;
  undefined4 uVar3;
  uint uVar4;
  char cStack_5;
  
  uVar3 = FUN_01675290(DAT_01ea8ff0);
  thunk_FUN_0151a220("CrashReporter_WatcherThreadFunc",uVar3);
  if (DAT_01d84e8d != '\0') {
    FUN_016774b0(DAT_01d84e8d,"WatcherThread Started",0);
  }
  bVar1 = false;
  while ((!bVar1 && (*(char *)(param_1 + 0xe) == '\0'))) {
    cStack_5 = FUN_0151f440(DAT_01d59878);
    if ((cStack_5 != '\0') && (DAT_01ea9002 != '\0')) {
      cStack_5 = '\0';
      *(undefined *)((int)param_1 + 0x2e) = 0;
      DAT_01ea9002 = '\0';
      *(undefined *)(param_1 + 0xb) = 1;
    }
    if (cStack_5 == '\0') {
      if (*(char *)((int)param_1 + 0x2e) == '\0') {
        if (*(char *)(param_1 + 0xb) != '\0') {
          FUN_005e2290();
          FUN_01716b1d(1);
        }
      }
      else {
        *(undefined *)((int)param_1 + 0x2e) = 0;
      }
    }
    else if (*(char *)(param_1 + 0xe) == '\0') {
      cVar2 = FUN_005512d0();
      if (cVar2 == '\0') {
        if (DAT_01d7abf8 != '\0') {
          FUN_016774b0(DAT_01d7abf8,"Processing non-hang",0);
        }
        uVar4 = (**(code **)(*param_1 + 4))(param_1[5],param_1[6],0,0,0,0);
        param_1[4] = uVar4 & 0xff;
        bVar1 = true;
        FUN_005e2110();
      }
      else {
        bVar1 = true;
        FUN_005e2410(param_1[5]);
      }
    }
  }
  if (*(char *)(param_1 + 0xe) == '\0') {
    (**(code **)*param_1)("WatcherThread Exiting.");
  }
  FUN_01675290(uVar3);
  return;
}



/* FUNCTION 5728 ; VA 0x005e2ec0 ; FUN_005e2ec0 */

/* WARNING: Removing unreachable block (ram,0x005e411d) */

undefined FUN_005e2ec0(void)

{
  bool bVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  char *pcStack_b38;
  undefined4 *puStack_b34;
  char *pcStack_b30;
  char *pcStack_b2c;
  char *pcStack_b28;
  undefined8 uStack_b24;
  char *pcStack_b1c;
  char *pcStack_b18;
  char *pcStack_b14;
  undefined8 uStack_b10;
  int iStack_b08;
  char *pcStack_b04;
  int iStack_b00;
  char *pcStack_afc;
  undefined4 *puStack_af8;
  int iStack_af4;
  char *pcStack_af0;
  int iStack_aec;
  char *pcStack_ae8;
  undefined1 *puStack_ae4;
  int iStack_ae0;
  char *pcStack_adc;
  int iStack_ad8;
  char *pcStack_ad4;
  undefined *puStack_ad0;
  int iStack_acc;
  char *pcStack_ac8;
  int iStack_ac4;
  char *pcStack_ac0;
  undefined4 uStack_abc;
  char *pcStack_ab8;
  char *pcStack_ab4;
  char *pcStack_ab0;
  char *pcStack_aac;
  undefined4 uStack_aa8;
  char *pcStack_aa4;
  char *pcStack_aa0;
  char *pcStack_a9c;
  char *pcStack_a98;
  undefined4 uStack_a94;
  int iStack_a90;
  char *pcStack_a8c;
  int iStack_a88;
  char *pcStack_a84;
  undefined *puStack_a80;
  int iStack_a7c;
  char *pcStack_a78;
  int iStack_a74;
  char *pcStack_a70;
  undefined *puStack_a6c;
  int iStack_a68;
  char *pcStack_a64;
  int iStack_a60;
  char *pcStack_a5c;
  undefined4 *puStack_a58;
  undefined *puStack_a54;
  undefined4 uStack_a50;
  undefined4 uStack_a4c;
  undefined4 uStack_a48;
  undefined *puStack_a44;
  undefined *puStack_a40;
  undefined4 uStack_a3c;
  undefined auStack_a34 [260];
  undefined auStack_930 [256];
  undefined auStack_830 [120];
  undefined auStack_7b8 [24];
  undefined4 *****apppppuStack_7a0 [5];
  uint uStack_78c;
  undefined auStack_740 [24];
  undefined auStack_728 [24];
  char acStack_710 [1024];
  undefined4 *****apppppuStack_310 [5];
  uint uStack_2fc;
  undefined4 *****apppppuStack_2f8 [5];
  uint uStack_2e4;
  undefined *puStack_2d4;
  undefined4 uStack_2d0;
  undefined auStack_2c4 [8];
  undefined8 uStack_2bc;
  undefined4 *puStack_2b4;
  int iStack_2b0;
  char *pcStack_2ac;
  int iStack_2a8;
  char *pcStack_2a4;
  int iStack_2a0;
  char *pcStack_29c;
  int iStack_298;
  char *pcStack_294;
  int iStack_290;
  char *pcStack_28c;
  int iStack_288;
  char *pcStack_284;
  undefined4 *puStack_280;
  undefined4 *puStack_27c;
  undefined4 *puStack_278;
  int iStack_274;
  char *pcStack_270;
  undefined4 *****pppppuStack_26c;
  undefined4 *****pppppuStack_268;
  int iStack_264;
  char *pcStack_260;
  int iStack_25c;
  char *pcStack_258;
  int iStack_254;
  char *pcStack_250;
  int iStack_24c;
  char *pcStack_248;
  int iStack_244;
  char *pcStack_240;
  int iStack_23c;
  char *pcStack_238;
  int iStack_234;
  char *pcStack_230;
  int iStack_22c;
  char *pcStack_228;
  int iStack_224;
  char *pcStack_220;
  undefined *puStack_21c;
  int iStack_218;
  char *pcStack_214;
  int iStack_210;
  char *pcStack_20c;
  int iStack_208;
  char *pcStack_204;
  undefined4 *****pppppuStack_200;
  undefined4 *****pppppuStack_1fc;
  int iStack_1f8;
  int iStack_1f4;
  code *pcStack_1f0;
  undefined4 *puStack_1ec;
  undefined4 *puStack_1e8;
  int iStack_1e4;
  int iStack_1e0;
  char *pcStack_1dc;
  undefined4 *puStack_1d8;
  undefined4 *puStack_1d4;
  undefined4 *puStack_1d0;
  undefined4 uStack_1cc;
  undefined4 uStack_1c8;
  int iStack_1c4;
  char *pcStack_1c0;
  int iStack_1bc;
  char *pcStack_1b8;
  int iStack_1b4;
  char *pcStack_1b0;
  int iStack_1ac;
  char *pcStack_1a8;
  undefined4 *puStack_1a4;
  undefined4 *puStack_1a0;
  undefined4 *puStack_19c;
  int iStack_198;
  char *pcStack_194;
  int iStack_190;
  char *pcStack_18c;
  int iStack_188;
  char *pcStack_184;
  int iStack_180;
  char *pcStack_17c;
  int iStack_178;
  char *pcStack_174;
  int iStack_170;
  char *pcStack_16c;
  int iStack_168;
  char *pcStack_164;
  int iStack_160;
  char *pcStack_15c;
  undefined4 *puStack_158;
  undefined4 *puStack_154;
  undefined4 *puStack_150;
  int iStack_14c;
  undefined4 *puStack_148;
  uint uStack_144;
  undefined4 *****pppppuStack_140;
  uint uStack_13c;
  undefined1 *puStack_138;
  undefined1 *puStack_134;
  int iStack_130;
  undefined4 *****pppppuStack_12c;
  undefined4 *****pppppuStack_128;
  undefined4 *****pppppuStack_124;
  uint uStack_120;
  undefined4 *****pppppuStack_11c;
  uint uStack_118;
  uint uStack_114;
  uint uStack_110;
  undefined *puStack_10c;
  uint uStack_108;
  undefined4 *puStack_104;
  uint uStack_100;
  undefined4 *puStack_fc;
  uint uStack_f8;
  undefined1 *puStack_f4;
  undefined4 *puStack_f0;
  uint uStack_ec;
  undefined4 *puStack_e8;
  undefined4 *****pppppuStack_e4;
  undefined4 *****pppppuStack_e0;
  undefined4 *****pppppuStack_dc;
  int iStack_d8;
  undefined4 *puStack_d4;
  undefined4 *puStack_d0;
  undefined4 *puStack_cc;
  undefined4 *puStack_c8;
  char *pcStack_c4;
  char *pcStack_c0;
  char *pcStack_bc;
  char *pcStack_b8;
  char *pcStack_b4;
  char *pcStack_b0;
  char *pcStack_ac;
  char *pcStack_a8;
  char *pcStack_a4;
  char *pcStack_a0;
  char *pcStack_9c;
  char *pcStack_98;
  char *pcStack_94;
  char *pcStack_90;
  char *pcStack_8c;
  short *psStack_88;
  char *pcStack_84;
  char *pcStack_80;
  char *pcStack_7c;
  int iStack_78;
  char *pcStack_74;
  char *pcStack_70;
  char *pcStack_6c;
  char *pcStack_68;
  char *pcStack_64;
  char *pcStack_60;
  char *pcStack_5c;
  char *pcStack_58;
  char *pcStack_54;
  char *pcStack_50;
  char *pcStack_4c;
  char *pcStack_48;
  char *pcStack_44;
  char *pcStack_40;
  char cStack_3c;
  char cStack_3b;
  undefined uStack_3a;
  char cStack_39;
  char cStack_38;
  char cStack_37;
  char cStack_36;
  char cStack_35;
  char cStack_34;
  char cStack_33;
  char cStack_32;
  char cStack_31;
  char cStack_30;
  char cStack_2f;
  char cStack_2e;
  char cStack_2d;
  char cStack_2c;
  char cStack_2b;
  char cStack_2a;
  char cStack_29;
  undefined uStack_28;
  char cStack_27;
  char cStack_26;
  char cStack_25;
  char cStack_24;
  char cStack_23;
  char cStack_22;
  char cStack_21;
  char cStack_20;
  char cStack_1f;
  char cStack_1e;
  char cStack_1d;
  char cStack_1c;
  char cStack_1b;
  undefined uStack_1a;
  char cStack_19;
  char acStack_18 [4];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179af4c;
  pvStack_10 = ExceptionList;
  uStack_a3c = 0x104;
  puStack_a40 = (undefined *)0x0;
  puStack_a44 = auStack_a34;
  uStack_a48 = 0x5e2ef5;
  ExceptionList = &pvStack_10;
  FUN_0170d1f0();
  uStack_a3c = 0x104;
  puStack_a40 = auStack_a34;
  puStack_a44 = (undefined *)0x5e2f0c;
  iVar3 = FUN_005e1050();
  if (iVar3 < 0) {
    uStack_3a = 0;
  }
  else {
    uStack_a3c = 0;
    puStack_a40 = (undefined *)0x80;
    puStack_a44 = (undefined *)0x4;
    uStack_a48 = 0;
    uStack_a4c = 1;
    uStack_a50 = 0x40000000;
    puStack_a54 = auStack_a34;
    puStack_a58 = (undefined4 *)0x5e2f36;
    iStack_14 = CreateFileA();
    if (iStack_14 == -1) {
      uStack_3a = 0;
    }
    else {
      acStack_18[0] = '\0';
      acStack_18[1] = '\0';
      acStack_18[2] = '\0';
      acStack_18[3] = '\0';
      puStack_a58 = (undefined4 *)auStack_728;
      pcStack_a5c = (char *)0x5e2f59;
      puStack_2b4 = (undefined4 *)FUN_0151b540();
      uStack_ec = (uint)(0xf < (uint)puStack_2b4[5]);
      puStack_f0 = puStack_2b4;
      if (0xf < (uint)puStack_2b4[5]) {
        puStack_f0 = (undefined4 *)*puStack_2b4;
      }
      puStack_158 = puStack_f0;
      puStack_a58 = puStack_f0;
      pcStack_a5c = "RobloxChannel=%s\n";
      iStack_a60 = 0x400;
      pcStack_a64 = acStack_710;
      iStack_a68 = 0x5e2fea;
      puStack_154 = puStack_2b4;
      puStack_c8 = puStack_2b4;
      FUN_005e4ba0();
      uStack_8 = 0;
      puStack_a58 = (undefined4 *)0x5e2fff;
      FUN_005507b0();
      uStack_8 = 0xffffffff;
      pcStack_40 = acStack_710;
      pcStack_15c = acStack_710 + 1;
      do {
        cStack_1b = *pcStack_40;
        pcStack_40 = pcStack_40 + 1;
      } while (cStack_1b != '\0');
      iStack_a60 = (int)pcStack_40 - (int)pcStack_15c;
      puStack_a58 = (undefined4 *)0x0;
      pcStack_a5c = acStack_18;
      pcStack_a64 = acStack_710;
      iStack_a68 = iStack_14;
      puStack_a6c = (undefined *)0x5e305a;
      iStack_160 = iStack_a60;
      WriteFile();
      puStack_a6c = &DAT_01ea9238;
      pcStack_a70 = "RbxCrashReason=%s\n";
      iStack_a74 = 0x400;
      pcStack_a78 = acStack_710;
      iStack_a7c = 0x5e3075;
      FUN_005e4ba0();
      pcStack_44 = acStack_710;
      pcStack_164 = acStack_710 + 1;
      do {
        cStack_1c = *pcStack_44;
        pcStack_44 = pcStack_44 + 1;
      } while (cStack_1c != '\0');
      iStack_a74 = (int)pcStack_44 - (int)pcStack_164;
      puStack_a6c = (undefined *)0x0;
      pcStack_a70 = acStack_18;
      pcStack_a78 = acStack_710;
      iStack_a7c = iStack_14;
      puStack_a80 = (undefined *)0x5e30cc;
      iStack_168 = iStack_a74;
      WriteFile();
      puStack_a80 = &DAT_01ea9278;
      pcStack_a84 = "RbxCrashMessage=%s\n";
      iStack_a88 = 0x400;
      pcStack_a8c = acStack_710;
      iStack_a90 = 0x5e30e7;
      FUN_005e4ba0();
      pcStack_48 = acStack_710;
      pcStack_16c = acStack_710 + 1;
      do {
        cStack_1d = *pcStack_48;
        pcStack_48 = pcStack_48 + 1;
      } while (cStack_1d != '\0');
      iStack_a88 = (int)pcStack_48 - (int)pcStack_16c;
      puStack_a80 = (undefined *)0x0;
      pcStack_a84 = acStack_18;
      pcStack_a8c = acStack_710;
      iStack_a90 = iStack_14;
      uStack_a94 = 0x5e313e;
      iStack_170 = iStack_a88;
      WriteFile();
      uStack_a94 = DAT_01f6e9f4;
      pcStack_a98 = (char *)DAT_01f6e9f0;
      pcStack_a9c = "PlaceId=%llu\n";
      pcStack_aa0 = (char *)0x400;
      pcStack_aa4 = acStack_710;
      uStack_aa8 = 0x5e3162;
      FUN_005e4ba0();
      pcStack_4c = acStack_710;
      pcStack_174 = acStack_710 + 1;
      do {
        cStack_1e = *pcStack_4c;
        pcStack_4c = pcStack_4c + 1;
      } while (cStack_1e != '\0');
      pcStack_a9c = (char *)((int)pcStack_4c - (int)pcStack_174);
      uStack_a94 = 0;
      pcStack_a98 = acStack_18;
      pcStack_aa0 = acStack_710;
      pcStack_aa4 = (char *)iStack_14;
      uStack_aa8 = 0x5e31b9;
      iStack_178 = (int)pcStack_a9c;
      WriteFile();
      uStack_aa8 = DAT_01f6ea1c;
      pcStack_aac = (char *)DAT_01f6ea18;
      pcStack_ab0 = "PlayerId=%llu\n";
      pcStack_ab4 = (char *)0x400;
      pcStack_ab8 = acStack_710;
      uStack_abc = 0x5e31dd;
      FUN_005e4ba0();
      pcStack_50 = acStack_710;
      pcStack_17c = acStack_710 + 1;
      do {
        cStack_1f = *pcStack_50;
        pcStack_50 = pcStack_50 + 1;
      } while (cStack_1f != '\0');
      pcStack_ab0 = (char *)((int)pcStack_50 - (int)pcStack_17c);
      uStack_aa8 = 0;
      pcStack_aac = acStack_18;
      pcStack_ab4 = acStack_710;
      pcStack_ab8 = (char *)iStack_14;
      uStack_abc = 0x5e3234;
      iStack_180 = (int)pcStack_ab0;
      WriteFile();
      uStack_abc = DAT_01f6e9ec;
      pcStack_ac0 = "DatacenterId=%d\n";
      iStack_ac4 = 0x400;
      pcStack_ac8 = acStack_710;
      iStack_acc = 0x5e3251;
      FUN_005e4ba0();
      pcStack_54 = acStack_710;
      pcStack_184 = acStack_710 + 1;
      do {
        cStack_20 = *pcStack_54;
        pcStack_54 = pcStack_54 + 1;
      } while (cStack_20 != '\0');
      iStack_ac4 = (int)pcStack_54 - (int)pcStack_184;
      uStack_abc = 0;
      pcStack_ac0 = acStack_18;
      pcStack_ac8 = acStack_710;
      iStack_acc = iStack_14;
      puStack_ad0 = (undefined *)0x5e32a8;
      iStack_188 = iStack_ac4;
      WriteFile();
      puStack_ad0 = &DAT_01f6e96c;
      pcStack_ad4 = "ServerIp=%s\n";
      iStack_ad8 = 0x400;
      pcStack_adc = acStack_710;
      iStack_ae0 = 0x5e32c3;
      FUN_005e4ba0();
      pcStack_58 = acStack_710;
      pcStack_18c = acStack_710 + 1;
      do {
        cStack_21 = *pcStack_58;
        pcStack_58 = pcStack_58 + 1;
      } while (cStack_21 != '\0');
      iStack_ad8 = (int)pcStack_58 - (int)pcStack_18c;
      puStack_ad0 = (undefined *)0x0;
      pcStack_ad4 = acStack_18;
      pcStack_adc = acStack_710;
      iStack_ae0 = iStack_14;
      puStack_ae4 = (undefined1 *)0x5e331a;
      iStack_190 = iStack_ad8;
      WriteFile();
      if (DAT_01f6ea20 == '\0') {
        puStack_f4 = &DAT_018bdf48;
      }
      else {
        puStack_f4 = &DAT_018bdf50;
      }
      puStack_ae4 = puStack_f4;
      pcStack_ae8 = "IsUniversalApp=%s\n";
      iStack_aec = 0x400;
      pcStack_af0 = acStack_710;
      iStack_af4 = 0x5e3358;
      FUN_005e4ba0();
      pcStack_5c = acStack_710;
      pcStack_194 = acStack_710 + 1;
      do {
        cStack_22 = *pcStack_5c;
        pcStack_5c = pcStack_5c + 1;
      } while (cStack_22 != '\0');
      iStack_aec = (int)pcStack_5c - (int)pcStack_194;
      puStack_ae4 = (undefined1 *)0x0;
      pcStack_ae8 = acStack_18;
      pcStack_af0 = acStack_710;
      iStack_af4 = iStack_14;
      puStack_af8 = (undefined4 *)0x5e33af;
      iStack_198 = iStack_aec;
      WriteFile();
      puStack_af8 = (undefined4 *)0x5e33b9;
      cVar2 = FUN_005512d0();
      if (cVar2 != '\0') {
        puStack_af8 = (undefined4 *)0x5e33c9;
        puStack_1a0 = (undefined4 *)FUN_014cd1a0();
        uStack_f8 = (uint)(0xf < (uint)puStack_1a0[5]);
        puStack_fc = puStack_1a0;
        if (0xf < (uint)puStack_1a0[5]) {
          puStack_fc = (undefined4 *)*puStack_1a0;
        }
        puStack_1a4 = puStack_fc;
        puStack_af8 = puStack_fc;
        pcStack_afc = "UserAgent=%s\n";
        iStack_b00 = 0x400;
        pcStack_b04 = acStack_710;
        iStack_b08 = 0x5e3457;
        puStack_19c = puStack_1a0;
        puStack_cc = puStack_1a0;
        FUN_005e4ba0();
        pcStack_60 = acStack_710;
        pcStack_1a8 = acStack_710 + 1;
        do {
          cStack_23 = *pcStack_60;
          pcStack_60 = pcStack_60 + 1;
        } while (cStack_23 != '\0');
        iStack_b00 = (int)pcStack_60 - (int)pcStack_1a8;
        puStack_af8 = (undefined4 *)0x0;
        pcStack_afc = acStack_18;
        pcStack_b04 = acStack_710;
        iStack_b08 = iStack_14;
        uStack_b10._4_4_ = 0x5e34ae;
        iStack_1ac = iStack_b00;
        WriteFile();
      }
      puStack_af8 = (undefined4 *)(iStack_78 + 0x1cc);
      pcStack_afc = "AppVersion=%s\n";
      iStack_b00 = 0x400;
      pcStack_b04 = acStack_710;
      iStack_b08 = 0x5e34cd;
      FUN_005e4ba0();
      pcStack_64 = acStack_710;
      pcStack_1b0 = acStack_710 + 1;
      do {
        cStack_24 = *pcStack_64;
        pcStack_64 = pcStack_64 + 1;
      } while (cStack_24 != '\0');
      iStack_b00 = (int)pcStack_64 - (int)pcStack_1b0;
      puStack_af8 = (undefined4 *)0x0;
      pcStack_afc = acStack_18;
      pcStack_b04 = acStack_710;
      iStack_b08 = iStack_14;
      uStack_b10._4_4_ = 0x5e3524;
      iStack_1b4 = iStack_b00;
      WriteFile();
      uStack_b10._4_4_ = 0x5e3529;
      FUN_01683110();
      uStack_b10._4_4_ = 0x5e352e;
      uStack_b10 = FUN_016f41c0();
      pcStack_b14 = "PlayTime=%llu\n";
      pcStack_b18 = (char *)0x400;
      pcStack_b1c = acStack_710;
      uStack_b24._4_4_ = 0x5e3546;
      FUN_005e4ba0();
      pcStack_68 = acStack_710;
      pcStack_1b8 = acStack_710 + 1;
      do {
        cStack_25 = *pcStack_68;
        pcStack_68 = pcStack_68 + 1;
      } while (cStack_25 != '\0');
      pcStack_b14 = (char *)((int)pcStack_68 - (int)pcStack_1b8);
      uStack_b10._4_4_ = 0;
      uStack_b10._0_4_ = acStack_18;
      pcStack_b18 = acStack_710;
      pcStack_b1c = (char *)iStack_14;
      uStack_b24._4_4_ = 0x5e359d;
      iStack_1bc = (int)pcStack_b14;
      WriteFile();
      uStack_b24._4_4_ = 0x5e35a2;
      FUN_01255990();
      uStack_b24._4_4_ = 0x5e35a9;
      iVar3 = FUN_0054db20();
      if (iVar3 == -0x550aa3b3) {
        uStack_b24._4_4_ = 0x5e35d8;
        uStack_b24 = FUN_01522960();
        pcStack_b28 = "UsedMemory=%llu\n";
        pcStack_b2c = (char *)0x400;
        pcStack_b30 = acStack_710;
        puStack_b34 = (undefined4 *)0x5e35f0;
        FUN_005e4ba0();
      }
      else {
        uStack_b24._4_4_ = 0x474a005;
        uStack_b24._0_4_ = "UsedMemory=%d\n";
        pcStack_b28 = (char *)0x400;
        pcStack_b2c = acStack_710;
        pcStack_b30 = (char *)0x5e35ce;
        FUN_005e4ba0();
      }
      pcStack_6c = acStack_710;
      pcStack_1c0 = acStack_710 + 1;
      do {
        cStack_26 = *pcStack_6c;
        pcStack_6c = pcStack_6c + 1;
      } while (cStack_26 != '\0');
      pcStack_b28 = (char *)((int)pcStack_6c - (int)pcStack_1c0);
      uStack_b24._4_4_ = 0;
      uStack_b24._0_4_ = acStack_18;
      pcStack_b2c = acStack_710;
      pcStack_b30 = (char *)iStack_14;
      puStack_b34 = (undefined4 *)0x5e3647;
      iStack_1c4 = (int)pcStack_b28;
      WriteFile();
      puStack_2d4 = (undefined *)&pcStack_b38;
      uVar4 = FUN_0151b370();
      FUN_0056a3e0(uVar4);
      uStack_1cc = FUN_0151bda0(auStack_830);
      uStack_8 = 1;
      puStack_b34 = (undefined4 *)0x5e3692;
      uStack_1c8 = uStack_1cc;
      puStack_1d4 = (undefined4 *)FUN_005e20d0();
      uStack_100 = (uint)(0xf < (uint)puStack_1d4[5]);
      puStack_104 = puStack_1d4;
      if (0xf < (uint)puStack_1d4[5]) {
        puStack_104 = (undefined4 *)*puStack_1d4;
      }
      puStack_1d8 = puStack_104;
      puStack_b34 = puStack_104;
      pcStack_b38 = "BaseUrl=%s\n";
      puStack_1d0 = puStack_1d4;
      puStack_d0 = puStack_1d4;
      FUN_005e4ba0(acStack_710,0x400);
      uStack_8 = 0xffffffff;
      puStack_b34 = (undefined4 *)0x5e3735;
      FUN_0056d9d0();
      pcStack_70 = acStack_710;
      pcStack_1dc = acStack_710 + 1;
      do {
        cStack_27 = *pcStack_70;
        pcStack_70 = pcStack_70 + 1;
      } while (cStack_27 != '\0');
      iStack_1e0 = (int)pcStack_70 - (int)pcStack_1dc;
      puStack_b34 = (undefined4 *)0x0;
      pcStack_b38 = acStack_18;
      WriteFile(iStack_14,acStack_710,iStack_1e0);
      iStack_1e4 = iStack_78 + 8;
      FUN_005e2120(&puStack_150);
      uStack_8 = 2;
      puStack_1e8 = puStack_150;
      uStack_28 = puStack_150 != (undefined4 *)0x0;
      uStack_108 = (uint)(byte)uStack_28;
      if ((bool)uStack_28) {
        puStack_1ec = puStack_150;
        puStack_d4 = puStack_150;
        pcStack_1f0 = *(code **)*puStack_150;
        (*pcStack_1f0)(auStack_2c4);
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        puStack_10c = auStack_2c4;
        FUN_005e1aa0(&iStack_d8);
        FUN_005e1ae0(&iStack_1f4);
        while( true ) {
          uStack_110 = (uint)(iStack_d8 == iStack_1f4);
          bVar1 = iStack_d8 != iStack_1f4;
          uStack_114 = (uint)bVar1;
          if (!bVar1) break;
          iStack_1f8 = iStack_d8 + 0x10;
          FUN_005e0510(iStack_1f8);
          pppppuStack_1fc = apppppuStack_2f8;
          uStack_118 = (uint)(0xf < uStack_2e4);
          pppppuStack_11c = pppppuStack_1fc;
          if (0xf < uStack_2e4) {
            pppppuStack_11c = apppppuStack_2f8[0];
          }
          pppppuStack_128 = pppppuStack_11c;
          pppppuStack_200 = apppppuStack_310;
          uStack_120 = (uint)(0xf < uStack_2fc);
          pppppuStack_124 = pppppuStack_200;
          if (0xf < uStack_2fc) {
            pppppuStack_124 = apppppuStack_310[0];
          }
          pppppuStack_12c = pppppuStack_124;
          pppppuStack_e0 = pppppuStack_200;
          pppppuStack_dc = pppppuStack_1fc;
          FUN_005e4ba0(acStack_710,0x400,"%s=%s\n",pppppuStack_124,pppppuStack_11c);
          pcStack_74 = acStack_710;
          pcStack_204 = acStack_710 + 1;
          do {
            cStack_29 = *pcStack_74;
            pcStack_74 = pcStack_74 + 1;
          } while (cStack_29 != '\0');
          iStack_208 = (int)pcStack_74 - (int)pcStack_204;
          WriteFile(iStack_14,acStack_710,iStack_208,acStack_18,0);
          uStack_8._0_1_ = 4;
          FUN_005507b0();
          uStack_8._0_1_ = 5;
          FUN_005507b0();
          uStack_8 = CONCAT31(uStack_8._1_3_,3);
          FUN_00551320();
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_005504e0();
      }
      iStack_130 = iStack_78;
      if (*(int *)(iStack_78 + 0x30) != 0 || *(int *)(iStack_78 + 0x34) != 0) {
        FUN_005e4ba0(acStack_710,0x400,"_mod_faulting_tid=%llu\n",*(undefined4 *)(iStack_78 + 0x30),
                     *(undefined4 *)(iStack_78 + 0x34));
        pcStack_7c = acStack_710;
        pcStack_20c = acStack_710 + 1;
        do {
          cStack_2a = *pcStack_7c;
          pcStack_7c = pcStack_7c + 1;
        } while (cStack_2a != '\0');
        iStack_210 = (int)pcStack_7c - (int)pcStack_20c;
        WriteFile(iStack_14,acStack_710,iStack_210,acStack_18,0);
      }
      cStack_19 = FUN_005e2100();
      if ((cStack_19 == '\0') && (cVar2 = FUN_005512d0(), cVar2 != '\0')) {
        FUN_01255990();
        iVar3 = FUN_0054db20();
        uStack_1a = iVar3 != -0x550aa3b3;
        cStack_19 = uStack_1a;
      }
      if (cStack_19 == '\0') {
        puStack_134 = &DAT_018bdf48;
      }
      else {
        puStack_134 = &DAT_018bdf50;
      }
      FUN_005e4ba0(acStack_710,0x400,"IsTainted=%s\n",puStack_134);
      pcStack_80 = acStack_710;
      pcStack_214 = acStack_710 + 1;
      do {
        cStack_3b = *pcStack_80;
        pcStack_80 = pcStack_80 + 1;
      } while (cStack_3b != '\0');
      iStack_218 = (int)pcStack_80 - (int)pcStack_214;
      WriteFile(iStack_14,acStack_710,iStack_218,acStack_18,0);
      psStack_88 = (short *)PathFindFileNameW(&DAT_01ea9030);
      if ((psStack_88 != (short *)0x0) && (*psStack_88 != 0)) {
        uStack_2d0 = 0x100;
        if ((short *)0x1ea9031 < psStack_88) {
          psStack_88[-1] = 0;
          puStack_21c = &DAT_01ea9030;
          WideCharToMultiByte(0xfde9,0,&DAT_01ea9030,0xffffffff,auStack_930,0x100,0,0);
          FUN_005e4ba0(acStack_710,0x400,"TaintingModuleDirectory=%s",auStack_930);
          pcStack_84 = acStack_710;
          pcStack_220 = acStack_710 + 1;
          do {
            cStack_3c = *pcStack_84;
            pcStack_84 = pcStack_84 + 1;
          } while (cStack_3c != '\0');
          iStack_224 = (int)pcStack_84 - (int)pcStack_220;
          WriteFile(iStack_14,acStack_710,iStack_224,acStack_18,0);
          WriteFile(iStack_14,&DAT_018bcfa8,1,acStack_18,0);
        }
        WideCharToMultiByte(0xfde9,0,psStack_88,0xffffffff,auStack_930,0x100,0,0);
        FUN_005e4ba0(acStack_710,0x400,"TaintingModule=%s",auStack_930);
        pcStack_8c = acStack_710;
        pcStack_228 = acStack_710 + 1;
        do {
          cStack_2b = *pcStack_8c;
          pcStack_8c = pcStack_8c + 1;
        } while (cStack_2b != '\0');
        iStack_22c = (int)pcStack_8c - (int)pcStack_228;
        WriteFile(iStack_14,acStack_710,iStack_22c,acStack_18,0);
        WriteFile(iStack_14,&DAT_018bcfa8,1,acStack_18,0);
      }
      FUN_016799d0();
      uVar5 = FUN_00588090();
      uStack_2bc = FUN_01679e20(0,0,(int)uVar5 + -1,
                                (int)((ulonglong)uVar5 >> 0x20) - (uint)((int)uVar5 == 0));
      FUN_005e4ba0(acStack_710,0x400,"UniqueId=%lld\n",uStack_2bc);
      pcStack_90 = acStack_710;
      pcStack_230 = acStack_710 + 1;
      do {
        cStack_2c = *pcStack_90;
        pcStack_90 = pcStack_90 + 1;
      } while (cStack_2c != '\0');
      iStack_234 = (int)pcStack_90 - (int)pcStack_230;
      WriteFile(iStack_14,acStack_710,iStack_234,acStack_18,0);
      uVar4 = FUN_0151aa10(DAT_01f6e610);
      FUN_005e4ba0(acStack_710,0x400,"ServerType=%s\n",uVar4);
      pcStack_94 = acStack_710;
      pcStack_238 = acStack_710 + 1;
      do {
        cStack_2d = *pcStack_94;
        pcStack_94 = pcStack_94 + 1;
      } while (cStack_2d != '\0');
      iStack_23c = (int)pcStack_94 - (int)pcStack_238;
      WriteFile(iStack_14,acStack_710,iStack_23c,acStack_18,0);
      FUN_005e4ba0(acStack_710,0x400,"LastServerMilestone=%s\n",PTR_DAT_01d7a63c);
      pcStack_98 = acStack_710;
      pcStack_240 = acStack_710 + 1;
      do {
        cStack_2e = *pcStack_98;
        pcStack_98 = pcStack_98 + 1;
      } while (cStack_2e != '\0');
      iStack_244 = (int)pcStack_98 - (int)pcStack_240;
      WriteFile(iStack_14,acStack_710,iStack_244,acStack_18,0);
      FUN_005e4ba0(acStack_710,0x400,"LastServerMode=%s\n",&DAT_01f6e618);
      pcStack_9c = acStack_710;
      pcStack_248 = acStack_710 + 1;
      do {
        cStack_2f = *pcStack_9c;
        pcStack_9c = pcStack_9c + 1;
      } while (cStack_2f != '\0');
      iStack_24c = (int)pcStack_9c - (int)pcStack_248;
      WriteFile(iStack_14,acStack_710,iStack_24c,acStack_18,0);
      FUN_005e4ba0(acStack_710,0x400,"MaxPlayers=%d\n",DAT_01f6e614);
      pcStack_a0 = acStack_710;
      pcStack_250 = acStack_710 + 1;
      do {
        cStack_30 = *pcStack_a0;
        pcStack_a0 = pcStack_a0 + 1;
      } while (cStack_30 != '\0');
      iStack_254 = (int)pcStack_a0 - (int)pcStack_250;
      WriteFile(iStack_14,acStack_710,iStack_254,acStack_18,0);
      FUN_005e4ba0(acStack_710,0x400,"CurrentPlayers=%d\n",DAT_01f6dd34);
      pcStack_a4 = acStack_710;
      pcStack_258 = acStack_710 + 1;
      do {
        cStack_31 = *pcStack_a4;
        pcStack_a4 = pcStack_a4 + 1;
      } while (cStack_31 != '\0');
      iStack_25c = (int)pcStack_a4 - (int)pcStack_258;
      WriteFile(iStack_14,acStack_710,iStack_25c,acStack_18,0);
      puStack_138 = &DAT_018bdf48;
      FUN_005e4ba0(acStack_710,0x400,"Is64Bit=%s\n",&DAT_018bdf48);
      pcStack_a8 = acStack_710;
      pcStack_260 = acStack_710 + 1;
      do {
        cStack_32 = *pcStack_a8;
        pcStack_a8 = pcStack_a8 + 1;
      } while (cStack_32 != '\0');
      iStack_264 = (int)pcStack_a8 - (int)pcStack_260;
      WriteFile(iStack_14,acStack_710,iStack_264,acStack_18,0);
      FUN_01530030(auStack_7b8);
      uStack_8._0_1_ = 6;
      pppppuStack_268 = apppppuStack_7a0;
      uStack_13c = (uint)(0xf < uStack_78c);
      pppppuStack_140 = pppppuStack_268;
      if (0xf < uStack_78c) {
        pppppuStack_140 = apppppuStack_7a0[0];
      }
      pppppuStack_26c = pppppuStack_140;
      pppppuStack_e4 = pppppuStack_268;
      FUN_005e4ba0(acStack_710,0x400,"GPU=%s\n",pppppuStack_140);
      pcStack_ac = acStack_710;
      pcStack_270 = acStack_710 + 1;
      do {
        cStack_33 = *pcStack_ac;
        pcStack_ac = pcStack_ac + 1;
      } while (cStack_33 != '\0');
      iStack_274 = (int)pcStack_ac - (int)pcStack_270;
      WriteFile(iStack_14,acStack_710,iStack_274,acStack_18,0);
      puStack_27c = (undefined4 *)FUN_0152fff0(auStack_740);
      uStack_144 = (uint)(0xf < (uint)puStack_27c[5]);
      puStack_148 = puStack_27c;
      if (0xf < (uint)puStack_27c[5]) {
        puStack_148 = (undefined4 *)*puStack_27c;
      }
      puStack_280 = puStack_148;
      puStack_278 = puStack_27c;
      puStack_e8 = puStack_27c;
      FUN_005e4ba0(acStack_710,0x400,"GPUDriver=%s\n",puStack_148);
      uStack_8._0_1_ = 7;
      FUN_005507b0();
      uStack_8._0_1_ = 6;
      pcStack_b0 = acStack_710;
      pcStack_284 = acStack_710 + 1;
      do {
        cStack_34 = *pcStack_b0;
        pcStack_b0 = pcStack_b0 + 1;
      } while (cStack_34 != '\0');
      iStack_288 = (int)pcStack_b0 - (int)pcStack_284;
      WriteFile(iStack_14,acStack_710,iStack_288,acStack_18,0);
      FUN_005e4ba0(acStack_710,0x400,"AudioDeviceName=%s\n",&DAT_01f6e8dc);
      pcStack_b4 = acStack_710;
      pcStack_28c = acStack_710 + 1;
      do {
        cStack_35 = *pcStack_b4;
        pcStack_b4 = pcStack_b4 + 1;
      } while (cStack_35 != '\0');
      iStack_290 = (int)pcStack_b4 - (int)pcStack_28c;
      WriteFile(iStack_14,acStack_710,iStack_290,acStack_18,0);
      FUN_005e4ba0(acStack_710,0x400,"AudioSystemRate=%d\n",DAT_01f6e95c);
      pcStack_b8 = acStack_710;
      pcStack_294 = acStack_710 + 1;
      do {
        cStack_36 = *pcStack_b8;
        pcStack_b8 = pcStack_b8 + 1;
      } while (cStack_36 != '\0');
      iStack_298 = (int)pcStack_b8 - (int)pcStack_294;
      WriteFile(iStack_14,acStack_710,iStack_298,acStack_18,0);
      FUN_005e4ba0(acStack_710,0x400,"AudioSpeakerMode=%d\n",DAT_01f6e960);
      pcStack_bc = acStack_710;
      pcStack_29c = acStack_710 + 1;
      do {
        cStack_37 = *pcStack_bc;
        pcStack_bc = pcStack_bc + 1;
      } while (cStack_37 != '\0');
      iStack_2a0 = (int)pcStack_bc - (int)pcStack_29c;
      WriteFile(iStack_14,acStack_710,iStack_2a0,acStack_18,0);
      FUN_005e4ba0(acStack_710,0x400,"AudioSpeakerModeChannels=%d\n",DAT_01f6e964);
      pcStack_c0 = acStack_710;
      pcStack_2a4 = acStack_710 + 1;
      do {
        cStack_38 = *pcStack_c0;
        pcStack_c0 = pcStack_c0 + 1;
      } while (cStack_38 != '\0');
      iStack_2a8 = (int)pcStack_c0 - (int)pcStack_2a4;
      WriteFile(iStack_14,acStack_710,iStack_2a8,acStack_18,0);
      FUN_005e4ba0(acStack_710,0x400,"AudioPreferredSoundDeviceIndex=%d\n",DAT_01f6e968);
      pcStack_c4 = acStack_710;
      pcStack_2ac = acStack_710 + 1;
      do {
        cStack_39 = *pcStack_c4;
        pcStack_c4 = pcStack_c4 + 1;
      } while (cStack_39 != '\0');
      iStack_2b0 = (int)pcStack_c4 - (int)pcStack_2ac;
      WriteFile(iStack_14,acStack_710,iStack_2b0,acStack_18,0);
      CloseHandle(iStack_14);
      uStack_3a = 1;
      uStack_8._0_1_ = 8;
      FUN_005507b0();
      uStack_8._0_1_ = 9;
      FUN_005507b0();
      uStack_8 = CONCAT31(uStack_8._1_3_,10);
      FUN_005507b0();
      uStack_8 = 0xb;
      if (iStack_14c != 0) {
        FUN_005536f0();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uStack_3a;
}



/* FUNCTION 5729 ; VA 0x005e46d0 ; FUN_005e46d0 */

/* WARNING: Removing unreachable block (ram,0x005e4850) */

undefined FUN_005e46d0(int *param_1,undefined4 param_2,undefined4 param_3,char param_4,char param_5,
                      int param_6,int param_7)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_3b4 [184];
  undefined4 uStack_2fc;
  char acStack_e8 [128];
  undefined4 uStack_68;
  undefined4 uStack_64;
  int *piStack_60;
  undefined4 uStack_5c;
  int iStack_58;
  undefined4 uStack_54;
  char *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  int iStack_3c;
  int iStack_38;
  undefined4 uStack_34;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  code *pcStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  int iStack_14;
  char *pcStack_10;
  int iStack_c;
  char cStack_6;
  undefined uStack_5;
  
  if ((param_5 == '\0') || (DAT_01ea8f97 != '\0')) {
    uStack_1c = 0;
  }
  else {
    uStack_1c = 1;
  }
  cVar1 = FUN_005512d0();
  if ((cVar1 == '\0') || (DAT_01ea8f96 == '\0')) {
    cVar1 = FUN_00554d10();
    if (cVar1 == '\0') {
      pcStack_20 = _guard_check_icall;
    }
    else {
      pcStack_20 = (code *)0x0;
    }
    if (pcStack_20 != (code *)0x0) {
      FUN_005515c0();
    }
  }
  uStack_68 = 0x1ffff;
  uStack_18 = *(uint *)(iStack_c + 0x390);
  if (param_4 != '\0') {
    uStack_18 = uStack_18 | 2;
  }
  iVar2 = FUN_005e1180(param_3,0x104,0,param_4);
  if (iVar2 < 0) {
    uStack_5 = 0;
  }
  else {
    uVar3 = FUN_00555230(param_3);
    uVar3 = FUN_0054db60(uVar3);
    FUN_005542c0(param_3,uVar3);
    FUN_0170d1f0(auStack_3b4,0,0x2cc);
    cVar1 = FUN_005512d0();
    if ((cVar1 != '\0') && (DAT_01ea8f96 != '\0')) {
      cVar1 = FUN_005e1e70(auStack_3b4);
      if (cVar1 == '\0') {
        if (DAT_01d84e8e != '\0') {
          FUN_01677520(DAT_01d84e8e,"HangDetection: Unable to get main thread context");
        }
      }
      else {
        param_1[1] = (int)auStack_3b4;
        *(undefined4 *)(*param_1 + 0xc) = uStack_2fc;
        param_2 = DAT_01ea8f9c;
      }
    }
    iStack_14 = CreateFileA(param_3,0x40000000,1,0,4,0x80,0);
    if (iStack_14 == -1) {
      uStack_5 = 0;
    }
    else {
      uStack_64 = param_2;
      piStack_60 = param_1;
      uStack_5c = 0;
      uStack_34 = 1;
      puStack_30 = &uStack_40;
      uStack_40 = 0x1ffff;
      iStack_38 = param_6;
      iStack_3c = param_7;
      uStack_5 = 1;
      if ((param_6 == 0) || (param_7 == 0)) {
        puStack_24 = (undefined4 *)0x0;
      }
      else {
        puStack_24 = &uStack_34;
      }
      if (param_1 == (int *)0x0) {
        puStack_28 = (undefined4 *)0x0;
      }
      else {
        puStack_28 = &uStack_64;
      }
      uStack_44 = GetCurrentProcessId();
      uStack_48 = GetCurrentProcess();
      iVar2 = MiniDumpWriteDump(uStack_48,uStack_44,iStack_14,uStack_18,puStack_28,puStack_24,0);
      if (iVar2 == 0) {
        uStack_4c = GetLastError();
        uStack_54 = 0;
        if ((param_1 == (int *)0x0) || (*param_1 == 0)) {
          uStack_2c = 0xffffffff;
        }
        else {
          uStack_2c = *(undefined4 *)*param_1;
        }
        FUN_005e1a20(acStack_e8,0x80,
                     "MiniDumpWriteDump() failed with hr = 0x%08x ExceptionCode = 0x%08x",uStack_4c,
                     uStack_2c);
        pcStack_10 = acStack_e8;
        pcStack_50 = acStack_e8 + 1;
        do {
          cStack_6 = *pcStack_10;
          pcStack_10 = pcStack_10 + 1;
        } while (cStack_6 != '\0');
        iStack_58 = (int)pcStack_10 - (int)pcStack_50;
        WriteFile(iStack_14,acStack_e8,iStack_58,&uStack_54,0);
        uStack_5 = 0;
      }
      CloseHandle(iStack_14);
    }
  }
  return uStack_5;
}



/* FUNCTION 5730 ; VA 0x005e4a00 ; FUN_005e4a00 */

/* WARNING: Removing unreachable block (ram,0x005e4b7f) */
/* WARNING: Heritage AFTER dead removal. Example location: s0xffffffb8 : 0x005e4aae */
/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_005e4a00(void)

{
  int iVar1;
  int *piVar2;
  int aiStack_48 [2];
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  uint uStack_30;
  int *piStack_2c;
  int iStack_28;
  uint uStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined auStack_13 [2];
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179af68;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  iVar1 = iStack_1c;
  uStack_8 = 0;
  piVar2 = (int *)(iStack_1c + 0x98);
  iStack_3c = *(int *)(iStack_1c + 0xa8);
  uStack_24 = (uint)(iStack_3c == 0);
  if (iStack_3c == 0) {
    iStack_28 = 0;
  }
  else {
    iStack_28 = *(int *)(iStack_1c + 0xa0);
  }
  aiStack_48[0] = iStack_28;
  piStack_20 = piVar2;
  while( true ) {
    iStack_40 = iStack_1c + 0x98;
    uStack_30 = (uint)(aiStack_48[0] != 0);
    if (aiStack_48[0] == 0) break;
    if (DAT_01d59898 != '\0') {
      iStack_34 = aiStack_48[0];
      cStack_11 = DAT_01d59898;
      FUN_01677760(DAT_01d59898,&DAT_018bd25c,aiStack_48[0]);
    }
    piStack_18 = aiStack_48;
    aiStack_48[0] = aiStack_48[0] + 0x18;
    if (aiStack_48[0] == *(int *)(iVar1 + 0x9c)) {
      aiStack_48[0] = *piVar2;
    }
    piStack_2c = piVar2;
    if (aiStack_48[0] == *(int *)(iVar1 + 0xa4)) {
      aiStack_48[0] = 0;
    }
  }
  iStack_38 = iStack_1c + 0x98;
  FUN_005e1d90(auStack_13);
  *(undefined4 *)(iStack_38 + 0x10) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5731 ; VA 0x005e4ba0 ; FUN_005e4ba0 */

int FUN_005e4ba0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  uint *puVar1;
  int iVar2;
  
  puVar1 = (uint *)FUN_005574c0(param_1,param_2,param_3,0,&stack0x00000010);
  iVar2 = FUN_0171d0ba(*puVar1 | 2,puVar1[1]);
  if (iVar2 < 0) {
    iVar2 = -1;
  }
  return iVar2;
}



/* FUNCTION 5732 ; VA 0x005e4be0 ; FUN_005e4be0 */

undefined4 FUN_005e4be0(void)

{
  int iVar1;
  undefined4 uStack_98;
  uint auStack_94 [3];
  int iStack_88;
  
  FUN_0170d1f0(auStack_94,0,0x90);
  uStack_98 = 0x94;
  iVar1 = GetVersionExA(&uStack_98);
  if (((iVar1 != 0) && (iStack_88 == 2)) && (5 < auStack_94[0])) {
    return 1;
  }
  return 0;
}



/* FUNCTION 5733 ; VA 0x005e4c40 ; FUN_005e4c40 */

undefined4 * __fastcall FUN_005e4c40(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uStack_60;
  code *pcStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  longlong lStack_40;
  undefined4 uStack_38;
  code *pcStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined8 *puStack_14;
  undefined8 uStack_10;
  undefined4 uStack_8;
  
  *param_1 = 0;
  uVar1 = GetModuleHandleA(0);
  puStack_14 = &uStack_10;
  uStack_10 = DAT_018c80c4;
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_38 = 0;
  pcStack_34 = FUN_005e4d10;
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_60 = 0;
  pcStack_5c = FUN_005e4d10;
  uStack_58 = 0;
  uStack_54 = 0;
  uStack_8 = DAT_018c80cc;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  lStack_40 = ZEXT48(puStack_14) << 0x20;
  uStack_50 = uVar1;
  uStack_28 = uVar1;
  RegisterClassA(&uStack_60);
  uVar1 = CreateWindowExA(0,&uStack_10,&DAT_018bc9b8,0x8000000,0x80000000,0x80000000,1,1,0,0,uVar1,0
                         );
  *param_1 = uVar1;
  return param_1;
}



/* FUNCTION 5734 ; VA 0x005e4d00 ; FUN_005e4d00 */

void __fastcall FUN_005e4d00(undefined4 *param_1)

{
  DestroyWindow(*param_1);
  return;
}



/* FUNCTION 5735 ; VA 0x005e4d10 ; FUN_005e4d10 */

undefined4 FUN_005e4d10(undefined4 param_1,int param_2,int param_3)

{
  undefined4 uVar1;
  
  if (param_2 == 2) {
    PostQuitMessage(0);
  }
  else {
    if (param_2 != 0x83) {
                    /* WARNING: Could not recover jumptable at 0x005e4d28. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar1 = DefWindowProcA();
      return uVar1;
    }
    if (param_3 != 0) {
                    /* WARNING: Could not recover jumptable at 0x005e4d40. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar1 = DefWindowProcA();
      return uVar1;
    }
  }
  return 0;
}



/* FUNCTION 5736 ; VA 0x005e4d60 ; FUN_005e4d60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_005e4d60(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  
  uVar3 = FUN_008881d0();
  *param_1 = uVar3;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = *param_2;
  iVar2 = _tls_index;
  param_1[3] = param_2[1];
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01ea93d0) {
    FUN_016f3809(&DAT_01ea93d0);
    if (DAT_01ea93d0 == -1) {
      _DAT_01ea93c4 = FUN_0057bbb0;
      _DAT_01ea93c8 = FUN_005880a0;
      DAT_01ea93cc = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ea93d0);
    }
  }
  param_1[1] = &DAT_01ea93c4;
  return param_1;
}



/* FUNCTION 5737 ; VA 0x005e4e10 ; FUN_005e4e10 */

undefined4 * __thiscall
FUN_005e4e10(undefined4 *param_1,uint param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined8 param_8)

{
  uint *puVar1;
  char cVar2;
  undefined **ppuVar3;
  uint auStack_80 [2];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 uStack_68;
  undefined4 *puStack_60;
  uint uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179af98;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_34 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_2 != 0) {
    uStack_34 = param_2;
    if ((param_2 & 1) == 0) {
      puStack_60 = (undefined4 *)0x0;
      uStack_68 = CONCAT44(&uStack_2c,&param_4);
      uStack_6c = 0x5e4e74;
      ExceptionList = &pvStack_10;
      (**(code **)(param_2 & 0xfffffffe))();
    }
    else {
      uStack_2c = param_4;
      uStack_28 = param_5;
      uStack_24 = param_6;
      uStack_20 = param_7;
      uStack_1c = param_8;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  uStack_54 = 0;
  if (uStack_34 != 0) {
    uStack_54 = uStack_34;
    if ((uStack_34 & 1) == 0) {
      puStack_60 = (undefined4 *)0x0;
      uStack_68 = CONCAT44(&uStack_4c,&uStack_2c);
      uStack_6c = 0x5e4ebd;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    else {
      uStack_4c = uStack_2c;
      uStack_48 = uStack_28;
      uStack_44 = uStack_24;
      uStack_40 = uStack_20;
      uStack_3c = uStack_1c;
    }
  }
  puStack_60 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = auStack_80;
  auStack_80[0] = 0;
  puVar1 = auStack_80;
  if (uStack_54 != 0) {
    auStack_80[0] = uStack_54;
    if ((uStack_54 & 1) == 0) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,&uStack_78,0);
      puVar1 = puStack_14;
    }
    else {
      uStack_78 = uStack_4c;
      uStack_74 = uStack_48;
      uStack_70 = uStack_44;
      uStack_6c = uStack_40;
      uStack_68 = uStack_3c;
      puVar1 = auStack_80;
    }
  }
  puStack_14 = puVar1;
  ppuVar3 = &PTR_FUN_018c897c;
  cVar2 = FUN_005e5880();
  if (cVar2 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8._0_1_ = 3;
  if (((uStack_54 != 0) && ((uStack_54 & 1) == 0)) &&
     (*(code **)(uStack_54 & 0xfffffffe) != (code *)0x0)) {
    puStack_60 = (undefined4 *)0x2;
    uStack_68 = CONCAT44(&uStack_4c,&uStack_4c);
    uStack_6c = 0x5e4f46;
    (**(code **)(uStack_54 & 0xfffffffe))();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      puStack_60 = (undefined4 *)0x2;
      uStack_68 = CONCAT44(&uStack_2c,&uStack_2c);
      uStack_6c = 0x5e4f75;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  uStack_8 = 5;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    puStack_60 = (undefined4 *)0x2;
    uStack_68 = CONCAT44(&param_4,&param_4);
    uStack_6c = 0x5e4fa3;
    (**(code **)(param_2 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5738 ; VA 0x005e4fc0 ; FUN_005e4fc0 */

undefined4 * __thiscall
FUN_005e4fc0(undefined4 *param_1,uint param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined8 param_8)

{
  char cVar1;
  undefined4 uVar2;
  undefined **ppuVar3;
  undefined auStack_f8 [56];
  uint auStack_c0 [2];
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined8 uStack_a8;
  uint auStack_88 [2];
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 uStack_70;
  undefined auStack_68 [24];
  uint auStack_50 [2];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined auStack_30 [24];
  uint *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179b008;
  pvStack_10 = ExceptionList;
  puStack_18 = auStack_88;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  auStack_88[0] = 0;
  if (param_2 != 0) {
    auStack_88[0] = param_2;
    if ((param_2 & 1) == 0) {
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_80,0);
    }
    else {
      uStack_80 = param_4;
      uStack_7c = param_5;
      uStack_78 = param_6;
      uStack_74 = param_7;
      uStack_70 = param_8;
    }
  }
  uStack_8._0_1_ = 1;
  FUN_0054ef60(&stack0x00000024);
  puStack_18 = auStack_50;
  uStack_8._0_1_ = 2;
  auStack_50[0] = 0;
  if (auStack_88[0] != 0) {
    auStack_50[0] = auStack_88[0];
    if ((auStack_88[0] & 1) == 0) {
      (**(code **)(auStack_88[0] & 0xfffffffe))(&uStack_80,&uStack_48,0);
    }
    else {
      uStack_48 = uStack_80;
      uStack_44 = uStack_7c;
      uStack_40 = uStack_78;
      uStack_3c = uStack_74;
      uStack_38 = uStack_70;
    }
  }
  uStack_8._0_1_ = 3;
  FUN_0054ef60(auStack_68);
  puStack_18 = auStack_c0;
  uStack_8._0_1_ = 4;
  auStack_c0[0] = 0;
  if (auStack_50[0] != 0) {
    auStack_c0[0] = auStack_50[0];
    if ((auStack_50[0] & 1) == 0) {
      (**(code **)(auStack_50[0] & 0xfffffffe))(&uStack_48,&uStack_b8,0);
    }
    else {
      uStack_b8 = uStack_48;
      uStack_b4 = uStack_44;
      uStack_b0 = uStack_40;
      uStack_ac = uStack_3c;
      uStack_a8 = uStack_38;
    }
  }
  uStack_8._0_1_ = 5;
  FUN_0054ef60(auStack_30);
  uStack_8._0_1_ = 6;
  cVar1 = FUN_00585a40(auStack_c0);
  if (cVar1 == '\0') {
    FUN_005e5f60(auStack_c0);
    uStack_8._0_1_ = 7;
    puStack_18 = (uint *)FUN_01674e20(0x38);
    uStack_8._0_1_ = 8;
    if (puStack_18 == (uint *)0x0) {
      uVar2 = 0;
    }
    else {
      uVar2 = FUN_005e5f60(auStack_f8);
    }
    param_1[2] = uVar2;
    FUN_005e6120();
    FUN_005e6120();
    cStack_11 = '\x01';
  }
  else {
    FUN_005e6120();
    cStack_11 = '\0';
  }
  FUN_005e6120();
  ppuVar3 = &PTR_FUN_018c8984;
  if (cStack_11 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  FUN_005e6120();
  FUN_005e6120();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5739 ; VA 0x005e51d0 ; FUN_005e51d0 */

undefined4 * __thiscall FUN_005e51d0(undefined4 *param_1,undefined4 param_2)

{
  *param_1 = 0;
  param_1[1] = 0;
  FUN_005c1af0(param_2,param_2);
  return param_1;
}



/* FUNCTION 5740 ; VA 0x005e5200 ; FUN_005e5200 */

undefined4 * __thiscall FUN_005e5200(undefined4 *param_1,undefined *param_2)

{
  undefined4 *puVar1;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8bf8) {
    FUN_016f3809(&DAT_01ea8bf8);
    if (DAT_01ea8bf8 == -1) {
      DAT_01ea8bec = FUN_005c6640;
      DAT_01ea8bf0 = FUN_005c6640;
      DAT_01ea8bf4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ea8bf8);
    }
  }
  puVar1 = (undefined4 *)*param_1;
  if ((code **)puVar1 == &DAT_01ea8bec) {
    *(undefined *)(param_1 + 1) = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined4 *)0x0) {
    (*(code *)puVar1[2])(param_1 + 1);
    *param_1 = 0;
  }
  *(undefined *)(param_1 + 1) = *param_2;
  *param_1 = &DAT_01ea8bec;
  return param_1;
}



/* FUNCTION 5741 ; VA 0x005e52b0 ; FUN_005e52b0 */

undefined4 * __thiscall FUN_005e52b0(undefined4 *param_1,undefined *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  
  uVar3 = FUN_0088daf0();
  iVar2 = _tls_index;
  *param_1 = uVar3;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01ea8bf8) {
    FUN_016f3809(&DAT_01ea8bf8);
    if (DAT_01ea8bf8 == -1) {
      DAT_01ea8bec = FUN_005c6640;
      DAT_01ea8bf0 = FUN_005c6640;
      DAT_01ea8bf4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ea8bf8);
    }
  }
  puVar1 = (undefined4 *)param_1[1];
  if ((code **)puVar1 == &DAT_01ea8bec) {
    *(undefined *)(param_1 + 2) = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined4 *)0x0) {
    (*(code *)puVar1[2])(param_1 + 2);
    param_1[1] = 0;
  }
  *(undefined *)(param_1 + 2) = *param_2;
  param_1[1] = &DAT_01ea8bec;
  return param_1;
}



/* FUNCTION 5742 ; VA 0x005e5370 ; FUN_005e5370 */

void FUN_005e5370(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  
  iVar1 = FUN_005e9aa0(param_1,param_2);
  *(undefined4 *)(iVar1 + 8) = *param_3;
  *(undefined4 *)(iVar1 + 0xc) = param_3[1];
  return;
}



/* FUNCTION 5743 ; VA 0x005e5390 ; FUN_005e5390 */

undefined4 * FUN_005e5390(uint *param_1)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b028;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_01674e20(0x50);
  uStack_8 = 0;
  *puVar5 = std::
            _Func_impl_no_alloc<class_<lambda_59109c2698aa89ec6a40db0777bffc40>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
            ::vftable;
  puVar5[2] = 0;
  uVar2 = *param_1;
  if (uVar2 != 0) {
    puVar5[2] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_1 + 2,puVar5 + 4,0);
    }
    else {
      uVar2 = param_1[3];
      uVar3 = param_1[4];
      uVar4 = param_1[5];
      puVar5[4] = param_1[2];
      puVar5[5] = uVar2;
      puVar5[6] = uVar3;
      puVar5[7] = uVar4;
      *(undefined8 *)(puVar5 + 8) = *(undefined8 *)(param_1 + 6);
    }
  }
  puVar5[10] = 0;
  uVar2 = param_1[8];
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (uVar2 != 0) {
    puVar5[10] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_1 + 10,puVar5 + 0xc,0);
    }
    else {
      uVar2 = param_1[0xb];
      uVar3 = param_1[0xc];
      uVar4 = param_1[0xd];
      puVar5[0xc] = param_1[10];
      puVar5[0xd] = uVar2;
      puVar5[0xe] = uVar3;
      puVar5[0xf] = uVar4;
      *(undefined8 *)(puVar5 + 0x10) = *(undefined8 *)(param_1 + 0xe);
    }
  }
  puVar5[0x12] = 0;
  puVar5[0x13] = 0;
  if (param_1[0x11] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[0x11] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puVar5[0x12] = param_1[0x10];
  puVar5[0x13] = param_1[0x11];
  ExceptionList = pvStack_10;
  return puVar5;
}



/* FUNCTION 5744 ; VA 0x005e548a ; Catch_All@005e548a */

void Catch_All_005e548a(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x50);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5745 ; VA 0x005e54b0 ; FUN_005e54b0 */

undefined4 * FUN_005e54b0(int param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b048;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x50);
  uStack_8 = 0;
  *puVar1 = std::
            _Func_impl_no_alloc<class_<lambda_59109c2698aa89ec6a40db0777bffc40>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
            ::vftable;
  puVar1[2] = 0;
  FUN_005880d0(param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  puVar1[10] = 0;
  FUN_005880d0(param_1 + 0x20);
  puVar1[0x12] = 0;
  puVar1[0x13] = 0;
  puVar1[0x12] = *(undefined4 *)(param_1 + 0x40);
  puVar1[0x13] = *(undefined4 *)(param_1 + 0x44);
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined4 *)(param_1 + 0x44) = 0;
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 5746 ; VA 0x005e5555 ; Catch_All@005e5555 */

void Catch_All_005e5555(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x50);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5747 ; VA 0x005e5570 ; FUN_005e5570 */

void __thiscall FUN_005e5570(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 uVar6;
  int *piVar7;
  int iVar8;
  undefined4 *puVar9;
  int *piVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179b060;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_005e6570(param_3);
  piVar7 = *(int **)(param_1 + 4);
  iVar8 = (uVar5 & *(uint *)(param_1 + 0x18)) * 8;
  piVar1 = *(int **)(*(int *)(param_1 + 0xc) + iVar8);
  piVar10 = piVar7;
  if (piVar1 != piVar7) {
    piVar10 = (int *)**(undefined4 **)(*(int *)(param_1 + 0xc) + 4 + iVar8);
  }
  do {
    if (piVar10 == piVar1) {
      iVar2 = *piVar7;
      uStack_8 = 0xffffffff;
      puVar3 = *(undefined4 **)(iVar2 + 4);
      uVar6 = FUN_005e5370(iVar2,puVar3,param_3);
      if (*(int *)(param_1 + 8) == 0xffffffe) {
                    /* WARNING: Subroutine does not return */
        FUN_016ddcd9("list<T> too long");
      }
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
      *(undefined4 *)(iVar2 + 4) = uVar6;
      *puVar3 = uVar6;
      piVar7 = *(int **)(param_1 + 4);
      puVar3 = (undefined4 *)*piVar7;
      piVar1 = (int *)*puVar3;
      if (piVar10 != piVar1) {
        *(int **)puVar3[1] = piVar1;
        *(int **)piVar1[1] = piVar10;
        *(undefined4 **)piVar10[1] = puVar3;
        iVar2 = piVar10[1];
        piVar10[1] = piVar1[1];
        piVar1[1] = puVar3[1];
        puVar3[1] = iVar2;
        piVar7 = *(int **)(param_1 + 4);
      }
      puVar9 = (undefined4 *)(iVar8 + *(int *)(param_1 + 0xc));
      if ((int *)*puVar9 == piVar7) {
        *puVar9 = puVar3;
        *(undefined4 **)(iVar8 + 4 + *(int *)(param_1 + 0xc)) = puVar3;
      }
      else if ((int *)*puVar9 == piVar10) {
        *puVar9 = puVar3;
      }
      else {
        puVar4 = *(undefined4 **)puVar9[1];
        puVar9[1] = puVar4;
        if (puVar4 != puVar3) {
          iVar8 = iVar8 + *(int *)(param_1 + 0xc);
          *(undefined4 *)(iVar8 + 4) = *(undefined4 *)(*(int *)(iVar8 + 4) + 4);
        }
      }
      uStack_8 = 2;
      FUN_005e9ad0();
      *param_2 = (int)puVar3;
      *(undefined *)(param_2 + 1) = 1;
      ExceptionList = pvStack_10;
      return;
    }
    piVar10 = (int *)piVar10[1];
  } while ((*param_3 != piVar10[2]) || (param_3[1] != piVar10[3]));
  *param_2 = (int)piVar10;
  *(undefined *)(param_2 + 1) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5748 ; VA 0x005e56dc ; Catch_All@005e56dc */

void Catch_All_005e56dc(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x18));
  FUN_005e9f40(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5749 ; VA 0x005e5710 ; FUN_005e5710 */

void __thiscall FUN_005e5710(int param_1,int *param_2,int *param_3,int *param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  int *piVar6;
  int iVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179b070;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_005e6570(param_3);
  iVar7 = *(int *)(param_1 + 4);
  iVar1 = (uVar5 & *(uint *)(param_1 + 0x18)) * 8;
  iVar2 = *(int *)(*(int *)(param_1 + 0xc) + iVar1);
  if (iVar7 != iVar2) {
    iVar7 = **(int **)(*(int *)(param_1 + 0xc) + 4 + iVar1);
    while (iVar7 != iVar2) {
      iVar7 = *(int *)(iVar7 + 4);
      if ((*param_3 == *(int *)(iVar7 + 8)) && (param_3[1] == *(int *)(iVar7 + 0xc))) {
        *(int *)param_4[1] = *param_4;
        *(int *)(*param_4 + 4) = param_4[1];
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        FUN_01674ea0(param_4,0x10);
        *param_2 = iVar7;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  iVar2 = *param_4;
  if (iVar7 != iVar2) {
    *(int *)param_4[1] = iVar2;
    **(int **)(iVar2 + 4) = iVar7;
    **(undefined4 **)(iVar7 + 4) = param_4;
    iVar3 = *(int *)(iVar7 + 4);
    *(undefined4 *)(iVar7 + 4) = *(undefined4 *)(iVar2 + 4);
    *(int *)(iVar2 + 4) = param_4[1];
    param_4[1] = iVar3;
  }
  piVar6 = (int *)(*(int *)(param_1 + 0xc) + iVar1);
  if (*piVar6 == *(int *)(param_1 + 4)) {
    *piVar6 = (int)param_4;
    *(int **)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = param_4;
  }
  else if (*piVar6 == iVar7) {
    *piVar6 = (int)param_4;
  }
  else {
    piVar4 = *(int **)piVar6[1];
    piVar6[1] = (int)piVar4;
    if (piVar4 != param_4) {
      *(undefined4 *)(*(int *)(param_1 + 0xc) + 4 + iVar1) =
           *(undefined4 *)(*(int *)(*(int *)(param_1 + 0xc) + 4 + iVar1) + 4);
    }
  }
  uStack_8 = 2;
  FUN_005e9ad0();
  *param_2 = (int)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}


