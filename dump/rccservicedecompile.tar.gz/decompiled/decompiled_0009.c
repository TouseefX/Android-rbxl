/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 2250 ; VA 0x00531e00 ; FUN_00531e00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00531e00(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183c722;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ef1440(uVar2,0);
  FUN_009cb790(uVar1,s_SetRBXEventStream_021500bc,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02150258 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::EventIngestService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),4>
       ::vftable;
  _DAT_02150290 = FUN_00ef2150;
  _DAT_02150294 = 0;
  _DAT_02150298 = 0;
  _DAT_0215029c = 0;
  _DAT_021502a0 = 0;
  _DAT_021502a4 = 0;
  uStack_8 = 4;
  FUN_00ef1860(s_target_02127abc,s_eventContext_021500a0,s_eventName_0214b600,
               s_additionalArgs_02150090);
  FUN_016f3654(&LAB_018a8c10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2251 ; VA 0x00531ef0 ; FUN_00531ef0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00531ef0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183c9ac;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ef2360();
  FUN_009cb790(uVar1,s_GetCreatedTimestampUtcMs_02150654,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02150548 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::SessionService,__int64___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),1>
       ::vftable;
  _DAT_02150580 = FUN_00ef30c0;
  _DAT_02150584 = 0;
  DAT_02150588 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0215056c = FUN_0088da50();
  if (DAT_02150588 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_02150588);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(&DAT_02150608);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a8c80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2252 ; VA 0x00532070 ; FUN_00532070 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00532070(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183c9de;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ef2360(uVar2,0);
  FUN_009cb790(uVar1,s_GetMetadata_0215062c,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02150468 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::SessionService,class_RBX::Reflection::Variant___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),2>
       ::vftable;
  _DAT_021504a0 = FUN_00ef30d0;
  _DAT_021504a4 = 0;
  _DAT_021504a8 = 0;
  _DAT_021504ac = 0;
  uStack_8 = 2;
  FUN_00cd2b40();
  FUN_016f3654(&LAB_018a8ca0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2253 ; VA 0x00532130 ; FUN_00532130 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00532130(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183c9fa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ef2360(uVar2,0);
  FUN_009cb790(uVar1,s_GetRootSID_021505d8,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02150348 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::SessionService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(void),0>
       ::vftable;
  _DAT_02150380 = FUN_00ef30f0;
  _DAT_02150384 = 0;
  _DAT_0215036c = FUN_0088cb40();
  FUN_016f3654(&LAB_018a8cc0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2254 ; VA 0x005321d0 ; FUN_005321d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005321d0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183ca2e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ef2360(uVar2,0);
  FUN_009cb790(uVar1,s_RemoveMetadata_02150644,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02150500 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::SessionService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),2>
       ::vftable;
  _DAT_02150538 = FUN_00ef3150;
  _DAT_0215053c = 0;
  _DAT_02150540 = 0;
  _DAT_02150544 = 0;
  uStack_8 = 2;
  FUN_00b94f90();
  FUN_016f3654(&LAB_018a8cd0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2255 ; VA 0x00532290 ; FUN_00532290 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00532290(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183ca8c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ef2360();
  FUN_009cb790(uVar1,s_RemoveSession_0215061c,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02150420 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::SessionService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),1>
       ::vftable;
  _DAT_02150458 = FUN_00ef3160;
  _DAT_0215045c = 0;
  DAT_02150460 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02150444 = FUN_00888530();
  if (DAT_02150460 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_02150460);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(&DAT_02150608);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a8cf0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2256 ; VA 0x00532410 ; FUN_00532410 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00532410(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183cabe;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ef2360(uVar2,0);
  FUN_009cb790(uVar1,s_ReplaceSession_0215060c,5,CONCAT44(uVar3,uVar2),0);
  _DAT_021503d8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::SessionService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),2>
       ::vftable;
  _DAT_02150410 = FUN_00ef3170;
  _DAT_02150414 = 0;
  _DAT_02150418 = 0;
  _DAT_0215041c = 0;
  uStack_8 = 2;
  FUN_00b94f90();
  FUN_016f3654(&LAB_018a8d10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2257 ; VA 0x005324d0 ; FUN_005324d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005324d0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183cb1c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ef2360();
  FUN_009cb790(uVar1,s_SessionExists_02150670,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02150590 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::SessionService,bool___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),1>
       ::vftable;
  _DAT_021505c8 = FUN_00ef3180;
  _DAT_021505cc = 0;
  DAT_021505d0 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_021505b4 = FUN_0088daf0();
  if (DAT_021505d0 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_021505d0);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(&DAT_02150608);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a8d30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2258 ; VA 0x00532650 ; FUN_00532650 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00532650(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183cb58;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ef2360(uVar2,0);
  FUN_009cb790(uVar1,s_SetMetadata_02150638,5,CONCAT44(uVar3,uVar2),0);
  _DAT_021504b0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::SessionService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_RBX::Reflection::Variant_const&),3>
       ::vftable;
  _DAT_021504e8 = FUN_00ef3190;
  _DAT_021504ec = 0;
  _DAT_021504f0 = 0;
  _DAT_021504f4 = 0;
  DAT_021504f8 = 0;
  uStack_8 = 3;
  FUN_00ef28c0(&DAT_02150608,&DAT_0211f870,s_value_0211ab70);
  FUN_016f3654(FUN_018a8d50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2259 ; VA 0x00532720 ; FUN_00532720 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00532720(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183cb98;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ef2360(uVar2,0);
  FUN_009cb790(uVar1,s_SetSession_021505fc,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02150388 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::SessionService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),3>
       ::vftable;
  _DAT_021503c0 = FUN_00ef31a0;
  _DAT_021503c4 = 0;
  _DAT_021503c8 = 0;
  _DAT_021503cc = 0;
  _DAT_021503d0 = 0;
  uStack_8 = 3;
  FUN_00e9f2f0(s_parentSid_021505f0,s_childSid_021505e4,&DAT_02125c60);
  FUN_016f3654(&LAB_018a8dd0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2260 ; VA 0x00532800 ; FUN_00532800 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00532800(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183ccfc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ef31b0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::UIScale,float>::
              GetSetImpl<float_(__thiscall_RBX::UIScale::*)(void)const_,void_(__thiscall_RBX::UIScale::*)(float)>
              ::vftable;
    puVar3[2] = FUN_00855cf0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00ef36a0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,s_Scale_02142260,s_Behavior_0211a8f8,uStack_24,0,0,0x1f,0,0,0);
  DAT_02150680 = RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_021506b4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_021506a4 = _DAT_021506a4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02150680[2])();
    if (cVar1 != '\0') {
      _DAT_021506a4 = _DAT_021506a4 & 0xfffffff3;
    }
  }
  DAT_02150680 = RBX::Reflection::PropDescriptor<class_RBX::UIScale,float>::vftable;
  FUN_016f3654(&LAB_018a8e60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2261 ; VA 0x00532940 ; FUN_00532940 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00532940(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183cedc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ef38d0();
  FUN_009cb820(uVar2,s_GetUserInfosByUserIdsAsync_02150700,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_021506b8 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::UserService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>),1>
       ::vftable;
  _DAT_021506f0 = FUN_00ef4610;
  _DAT_021506f4 = 0;
  DAT_021506f8 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_021506dc = FUN_008882f0();
  puVar4 = DAT_021506f8;
  if (DAT_021506f8 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_008882f0();
    iStack_ec = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    iStack_ec = FUN_005c9da0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_008882f0();
  uVar3 = FUN_0086e3d0(s_userIds_02120178);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_018a8ee0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2262 ; VA 0x00532b80 ; FUN_00532b80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00532b80(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0183d293;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ef5f60();
  FUN_009cb970(uVar1,"ActiveUserSignedOut",5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_01f2b424 = 0x58;
  iStack_8 = 0;
  _DAT_01f2b3f0 =
       RBX::Reflection::
       EventDesc<class_RBX::ThirdPartyUserService,void___cdecl(int),class_rbx::signal<void___cdecl(int)>,class_rbx::signal<void___cdecl(int)>_RBX::ThirdPartyUserService::*>
       ::vftable;
  FUN_0086e3d0("signOutStatus");
  FUN_0088c8c0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_01f2b418 = uStack_1c;
  _DAT_01f2b41c = uStack_18;
  _DAT_01f2b420 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_01f2b3f0 =
       RBX::Reflection::
       EventDesc<class_RBX::ThirdPartyUserService,void___cdecl(int),class_rbx::signal<void___cdecl(int)>,class_rbx::signal<void___cdecl(int)>_RBX::ThirdPartyUserService::*>
       ::vftable;
  FUN_016f3654(&LAB_018a8fb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2263 ; VA 0x00532cd0 ; FUN_00532cd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00532cd0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183d2aa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ef5f60(uVar2,0);
  FUN_009cb790(uVar1,"GetUserPlatformId",5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_01f2b2a8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ThirdPartyUserService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(void),0>
       ::vftable;
  _DAT_01f2b2e0 = FUN_00ef74b0;
  _DAT_01f2b2e4 = 0;
  _DAT_01f2b2cc = FUN_0088cb40();
  FUN_016f3654(&LAB_018a8fc0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2264 ; VA 0x00532d70 ; FUN_00532d70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00532d70(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183d2ca;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ef5f60(uVar2,0);
  FUN_009cb790(uVar1,"GetUserPlatformName",5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_01f2b268 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ThirdPartyUserService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(void),0>
       ::vftable;
  _DAT_01f2b2a0 = FUN_00ef7500;
  _DAT_01f2b2a4 = 0;
  _DAT_01f2b28c = FUN_0088cb40();
  FUN_016f3654(&LAB_018a8fd0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2265 ; VA 0x00532e10 ; FUN_00532e10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00532e10(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183d2ea;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ef5f60(uVar2,0);
  FUN_009cb790(uVar1,"HaveActiveUser",5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_01f2b2e8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ThirdPartyUserService,bool___cdecl(void),0>::
       vftable;
  _DAT_01f2b320 = &LAB_00ef7540;
  _DAT_01f2b324 = 0;
  _DAT_01f2b30c = FUN_0088daf0();
  FUN_016f3654(&LAB_018a8fe0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2266 ; VA 0x00532eb0 ; FUN_00532eb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00532eb0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183d34c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ef5f60();
  FUN_009cb820(uVar1,"RegisterActiveUser",5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_01f2b3a8 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::ThirdPartyUserService,int___cdecl(enum_RBX::InputObject::UserInputType),1>
       ::vftable;
  _DAT_01f2b3e0 = FUN_00ef77f0;
  _DAT_01f2b3e4 = 0;
  DAT_01f2b3e8 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_01f2b3cc = FUN_0088c8c0();
  puVar3 = DAT_01f2b3e8;
  if (DAT_01f2b3e8 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = thunk_FUN_00b84a30();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00b84c10();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = thunk_FUN_00b84a30();
  uVar2 = FUN_0086e3d0("gamepadId");
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018a8ff0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2267 ; VA 0x00533050 ; FUN_00533050 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00533050(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183d36a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ef5f60(uVar2,0);
  FUN_009cb790(uVar1,"ReturnToEngagement",5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_01f2b368 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ThirdPartyUserService,void___cdecl(void),0>::
       vftable;
  _DAT_01f2b3a0 = &LAB_00ef7a60;
  _DAT_01f2b3a4 = 0;
  _DAT_01f2b38c = FUN_00888530();
  FUN_016f3654(&LAB_018a9010);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2268 ; VA 0x005330f0 ; FUN_005330f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005330f0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183d38a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ef5f60(uVar2,0);
  FUN_009cb790(uVar1,"ShowAccountPicker",5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_01f2b328 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ThirdPartyUserService,void___cdecl(void),0>::
       vftable;
  _DAT_01f2b360 = &LAB_00ef7b50;
  _DAT_01f2b364 = 0;
  _DAT_01f2b34c = FUN_00888530();
  FUN_016f3654(&LAB_018a9020);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2269 ; VA 0x005331c0 ; FUN_005331c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005331c0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183d57c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ef7b60();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::Analytics::GoogleAnalyticsConfiguration,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetSetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_(__thiscall_RBX::Analytics::GoogleAnalyticsConfiguration::*)(void)const_,void_(__thiscall_RBX::Analytics::GoogleAnalyticsConfiguration::*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&)>
              ::vftable;
    puVar3[2] = FUN_00991180;
    puVar3[3] = 0;
    puVar3[4] = FUN_00991500;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,&DAT_0213c650,s_Configuration_0211d7bc,uStack_24,0,0,0xc,5,5,0);
  DAT_0215071c = RBX::Reflection::
                 TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02150750 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02150740 = _DAT_02150740 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0215071c[2])();
    if (cVar1 != '\0') {
      _DAT_02150740 = _DAT_02150740 & 0xfffffff3;
    }
  }
  DAT_0215071c = RBX::Reflection::
                 PropDescriptor<class_RBX::Analytics::GoogleAnalyticsConfiguration,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  FUN_016f3654(&LAB_018a9040);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2270 ; VA 0x005332f0 ; FUN_005332f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005332f0(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183e0ae;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00efa710(uVar2,0);
  FUN_009cb790(uVar1,s_OnUpdate_021509ac,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02150888 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::DataStore,class_rbx::signals::connection___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Lua::WeakFunctionRef),2>
       ::vftable;
  _DAT_021508c0 = &LAB_00e88f56;
  _DAT_021508c4 = 0;
  _DAT_021508c8 = 0;
  DAT_021508cc = 0;
  uStack_8 = 2;
  FUN_00f04960();
  FUN_016f3654(&LAB_018a90c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2271 ; VA 0x00533840 ; FUN_00533840 */

void FUN_00533840(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00efd670(&LAB_00a3d6e8,0,s_GetAsync_021251d0,&DAT_0211f870,0,uStack_10,0);
  FUN_016f3654(&LAB_018a91b0);
  return;
}



/* FUNCTION 2272 ; VA 0x005338a0 ; FUN_005338a0 */

/* WARNING: Removing unreachable block (ram,0x00533add) */
/* WARNING: Removing unreachable block (ram,0x00533938) */
/* WARNING: Removing unreachable block (ram,0x00533afd) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005338a0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uStack_1c0;
  undefined4 *puStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183e13f;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00888530();
  uStack_8 = 0;
  uStack_1c0 = FUN_00888530();
  puStack_14 = &uStack_1c0;
  puStack_1bc = (undefined4 *)0x0;
  puStack_ec = (undefined4 *)0x0;
  uStack_8._0_1_ = 3;
  uStack_f0 = uVar1;
  uVar1 = FUN_00efa8d0();
  FUN_009cb820(uVar1,s_GetSortedAsync_021509e8,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_021508d0 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::OrderedDataStore,class_std::shared_ptr<class_RBX::Instance>___cdecl(bool,int,class_RBX::Reflection::Variant,class_RBX::Reflection::Variant),4>
       ::vftable;
  _DAT_02150908 = FUN_00f08a50;
  _DAT_0215090c = 0;
  _DAT_02150910 = 0;
  _DAT_02150914 = 0;
  uStack_8._0_1_ = 6;
  puVar2 = (undefined4 *)FUN_01674e20(0xd0);
  uStack_8._0_1_ = 7;
  puStack_14 = puVar2;
  if (puVar2 == (undefined4 *)0x0) {
    _DAT_02150918 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = uStack_f0;
    puVar2[1] = 0;
    if (puStack_ec != (undefined4 *)0x0) {
      (*(code *)*puStack_ec)();
    }
    puVar2[1] = puStack_ec;
    _DAT_02150918 = puVar2;
  }
  uStack_8._0_1_ = 8;
  puVar2 = (undefined4 *)FUN_01674e20(0xd0);
  uStack_8._0_1_ = 9;
  puStack_14 = puVar2;
  if (puVar2 == (undefined4 *)0x0) {
    _DAT_0215091c = (undefined4 *)0x0;
  }
  else {
    *puVar2 = uStack_1c0;
    puVar2[1] = 0;
    if (puStack_1bc != (undefined4 *)0x0) {
      (*(code *)*puStack_1bc)();
    }
    puVar2[1] = puStack_1bc;
    _DAT_0215091c = puVar2;
  }
  uStack_8._0_1_ = 10;
  FUN_00f05570(s_ascending_021509dc,s_pagesize_021509d0,s_minValue_021509c4,s_maxValue_021509b8);
  uStack_8._0_1_ = 0xb;
  if (puStack_ec != (undefined4 *)0x0) {
    (*(code *)puStack_ec[2])(auStack_e8);
  }
  uStack_8._0_1_ = 0xc;
  if (puStack_1bc != (undefined4 *)0x0) {
    (*(code *)puStack_1bc[2])(auStack_1b8);
  }
  uStack_8 = 0xe;
  FUN_016f3654(&LAB_018a91d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2273 ; VA 0x00533b30 ; FUN_00533b30 */

/* WARNING: Removing unreachable block (ram,0x00533c07) */
/* WARNING: Removing unreachable block (ram,0x00533c48) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00533b30(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0183e18a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00efa710();
  FUN_009cb820(uVar1,s_IncrementAsync_0215099c,0,uStack_1c,0);
  _DAT_02150838 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::DataStore,class_RBX::Reflection::Variant___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,class_std::shared_ptr<class_RBX::Instance>),4>
       ::vftable;
  _DAT_02150870 = &LAB_00c3b2ee;
  _DAT_02150874 = 0;
  _DAT_02150878 = 0;
  uStack_8._0_1_ = 2;
  _DAT_0215087c = (undefined4 *)FUN_01674e20(4);
  if (_DAT_0215087c == (undefined4 *)0x0) {
    _DAT_0215087c = (undefined4 *)0x0;
  }
  else {
    *_DAT_0215087c = 1;
  }
  uStack_8._0_1_ = 3;
  _DAT_02150880 = (undefined4 *)FUN_01674e20(8);
  if (_DAT_02150880 == (undefined4 *)0x0) {
    _DAT_02150880 = (undefined4 *)0x0;
  }
  else {
    *_DAT_02150880 = 0;
    _DAT_02150880[1] = 0;
    *_DAT_02150880 = 0;
    _DAT_02150880[1] = 0;
  }
  uStack_8._0_1_ = 4;
  _DAT_02150884 = (undefined4 *)FUN_01674e20(8);
  if (_DAT_02150884 == (undefined4 *)0x0) {
    _DAT_02150884 = (undefined4 *)0x0;
  }
  else {
    *_DAT_02150884 = 0;
    _DAT_02150884[1] = 0;
    *_DAT_02150884 = 0;
    _DAT_02150884[1] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_00f04d60(&DAT_0211f870,s_delta_0212d324,s_userids_02150968,s_options_02125284);
  FUN_0056b650();
  FUN_016f3654(&LAB_018a91e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2274 ; VA 0x00533cb0 ; FUN_00533cb0 */

void FUN_00533cb0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00efd670(&LAB_00b019a0,0,s_RemoveAsync_021509f8,&DAT_0211f870,0,uStack_10,0);
  FUN_016f3654(&LAB_018a91f0);
  return;
}



/* FUNCTION 2275 ; VA 0x00533d10 ; FUN_00533d10 */

/* WARNING: Removing unreachable block (ram,0x00533dca) */
/* WARNING: Removing unreachable block (ram,0x00533e0b) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00533d10(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0183e1da;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00efa710();
  FUN_009cb820(uVar1,s_SetAsync_02150970,0,uStack_1c,0);
  _DAT_021507a0 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::DataStore,class_RBX::Reflection::Variant___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,class_std::shared_ptr<class_RBX::Instance>),4>
       ::vftable;
  _DAT_021507d8 = &LAB_00c3b2e6;
  _DAT_021507dc = 0;
  _DAT_021507e0 = 0;
  _DAT_021507e4 = 0;
  uStack_8._0_1_ = 3;
  _DAT_021507e8 = (undefined4 *)FUN_01674e20(8);
  if (_DAT_021507e8 == (undefined4 *)0x0) {
    _DAT_021507e8 = (undefined4 *)0x0;
  }
  else {
    *_DAT_021507e8 = 0;
    _DAT_021507e8[1] = 0;
    *_DAT_021507e8 = 0;
    _DAT_021507e8[1] = 0;
  }
  uStack_8._0_1_ = 4;
  _DAT_021507ec = (undefined4 *)FUN_01674e20(8);
  if (_DAT_021507ec == (undefined4 *)0x0) {
    _DAT_021507ec = (undefined4 *)0x0;
  }
  else {
    *_DAT_021507ec = 0;
    _DAT_021507ec[1] = 0;
    *_DAT_021507ec = 0;
    _DAT_021507ec[1] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_00f05150(&DAT_0211f870,s_value_0211ab70,s_userids_02150968,s_options_02125284);
  FUN_0056b650();
  FUN_016f3654(&LAB_018a9210);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2276 ; VA 0x00533e70 ; FUN_00533e70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00533e70(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183e20e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00efa710(uVar2,0);
  FUN_009cb820(uVar1,s_UpdateAsync_02150990,0,CONCAT44(uVar3,uVar2),0);
  _DAT_021507f0 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::DataStore,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Lua::WeakFunctionRef),2>
       ::vftable;
  _DAT_02150828 = &LAB_00c3b2de;
  _DAT_0215082c = 0;
  _DAT_02150830 = 0;
  DAT_02150834 = 0;
  uStack_8 = 2;
  FUN_00f04b60();
  FUN_016f3654(&LAB_018a9220);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2277 ; VA 0x00533f50 ; FUN_00533f50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00533f50(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01840ecc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00f1ca30();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::DataStoreKeyInfo,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_(__thiscall_RBX::DataStoreKeyInfo::*)(void)const_>
              ::vftable;
    puVar3[2] = FUN_00926ad0;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,s_KeyName_02150aa0,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02150a50 = RBX::Reflection::
                 TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02150a84 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02150a74 = _DAT_02150a74 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02150a50[2])();
    if (cVar1 != '\0') {
      _DAT_02150a74 = _DAT_02150a74 & 0xfffffff3;
    }
  }
  DAT_02150a50 = RBX::Reflection::
                 PropDescriptor<class_RBX::DataStoreKeyInfo,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  FUN_016f3654(&LAB_018a9280);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2278 ; VA 0x005340e0 ; FUN_005340e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005340e0(void)

{
  char cVar1;
  undefined4 uVar2;
  char *pcVar3;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01840f15;
  pvStack_10 = ExceptionList;
  pcVar3 = &DAT_0211fa6e;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  uStack_8 = 0;
  uVar2 = FUN_00f1c950();
  FUN_009cb820(uVar2,s_ListKeysAsync_02150a90,0,CONCAT44(uStack_1c,uStack_20),0);
  uStack_8._0_1_ = 1;
  _DAT_02150a08 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::DataStore2,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int),2>
       ::vftable;
  _DAT_02150a40 = FUN_00f1e310;
  _DAT_02150a44 = 0;
  iStack_14 = FUN_01674e20(0x18);
  uStack_8._0_1_ = 2;
  if (iStack_14 == 0) {
    _DAT_02150a48 = 0;
  }
  else {
    _DAT_02150a48 = FUN_0054ef60(auStack_38);
  }
  uStack_8._0_1_ = 3;
  DAT_02150a4c = (undefined4 *)FUN_01674e20(4);
  if (DAT_02150a4c == (undefined4 *)0x0) {
    DAT_02150a4c = (undefined4 *)0x0;
  }
  else {
    *DAT_02150a4c = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00f1d610();
  if (0xf < uStack_24) {
    if (0xfff < uStack_24 + 1) {
      if (0x1f < (auStack_38[0] - *(int *)(auStack_38[0] - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  FUN_016f3654(&LAB_018a92a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2279 ; VA 0x005343c0 ; FUN_005343c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005343c0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184152c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00f1f4e0();
  FUN_009cb820(uVar1,s_GetMeshTriCount_02150ca0,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02150aa8 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::UGCValidationService,int___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_02150ae0 = FUN_00f21f30;
  _DAT_02150ae4 = 0;
  DAT_02150ae8 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02150acc = FUN_0088c8c0();
  if (DAT_02150ae8 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_02150ae8);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_meshId_0211c0a0);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a96c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2280 ; VA 0x00534540 ; FUN_00534540 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00534540(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184158c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00f1f4e0();
  FUN_009cb790(uVar1,s_GetMeshTriCountSync_02150cb0,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02150af0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UGCValidationService,int___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_02150b28 = FUN_00f220c0;
  _DAT_02150b2c = 0;
  DAT_02150b30 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02150b14 = FUN_0088c8c0();
  if (DAT_02150b30 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_02150b30);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_meshId_0211c0a0);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a96e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2281 ; VA 0x005346c0 ; FUN_005346c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005346c0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018415ec;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00f1f4e0();
  FUN_009cb820(uVar1,s_GetMeshVerts_02150cc4,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02150b38 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::UGCValidationService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_02150b70 = FUN_00f222d0;
  _DAT_02150b74 = 0;
  DAT_02150b78 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02150b5c = FUN_008882f0();
  if (DAT_02150b78 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_02150b78);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_meshId_0211c0a0);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a9700);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2282 ; VA 0x00534840 ; FUN_00534840 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00534840(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184164c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00f1f4e0();
  FUN_009cb790(uVar1,s_GetMeshVertsSync_02150cd4,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02150b80 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UGCValidationService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_02150bb8 = FUN_00f22460;
  _DAT_02150bbc = 0;
  DAT_02150bc0 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02150ba4 = FUN_008882f0();
  if (DAT_02150bc0 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_02150bc0);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_meshId_0211c0a0);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a9720);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2283 ; VA 0x005349c0 ; FUN_005349c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005349c0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018416ac;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00f1f4e0();
  FUN_009cb820(uVar1,s_GetTextureSize_02150ce8,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02150bc8 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::UGCValidationService,class_G3D::Vector2___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_02150c00 = FUN_00f22ac0;
  _DAT_02150c04 = 0;
  DAT_02150c08 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02150bec = FUN_0088d730();
  if (DAT_02150c08 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_02150c08);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_textureId_02119224);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a9740);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2284 ; VA 0x00534b40 ; FUN_00534b40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00534b40(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184170c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00f1f4e0();
  FUN_009cb790(uVar1,s_GetTextureSizeSync_02150cf8,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02150c10 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UGCValidationService,class_G3D::Vector2___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_02150c48 = FUN_00f22c50;
  _DAT_02150c4c = 0;
  DAT_02150c50 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02150c34 = FUN_0088d730();
  if (DAT_02150c50 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_02150c50);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_textureId_02119224);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a9760);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2285 ; VA 0x00534cc0 ; FUN_00534cc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00534cc0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184173e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00f1f4e0(uVar2,0);
  FUN_009cb790(uVar1,s_SetMeshIdBlocking_02150d18,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02150c58 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UGCValidationService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_02150c90 = FUN_00f23a90;
  _DAT_02150c94 = 0;
  DAT_02150c98 = 0;
  _DAT_02150c9c = 0;
  uStack_8 = 2;
  FUN_00f21250();
  FUN_016f3654(&LAB_018a9780);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2286 ; VA 0x00535650 ; FUN_00535650 */

void FUN_00535650(void)

{
  undefined4 *puVar1;
  undefined uVar2;
  uint uVar3;
  uint uVar4;
  undefined auStack_600 [384];
  undefined auStack_480 [48];
  undefined auStack_450 [48];
  undefined auStack_420 [24];
  undefined auStack_408 [24];
  undefined auStack_3f0 [16];
  undefined4 uStack_3e0;
  undefined4 uStack_3dc;
  undefined uStack_3d8;
  undefined4 uStack_3c8;
  undefined4 uStack_3c4;
  undefined uStack_3c0;
  undefined4 uStack_3b0;
  undefined4 uStack_3ac;
  undefined uStack_3a8;
  undefined4 uStack_398;
  undefined4 uStack_394;
  undefined uStack_390;
  undefined4 uStack_380;
  undefined4 uStack_37c;
  undefined auStack_378 [16];
  undefined4 uStack_368;
  undefined4 uStack_364;
  undefined uStack_360;
  undefined4 uStack_350;
  undefined4 uStack_34c;
  undefined uStack_348;
  undefined4 uStack_338;
  undefined4 uStack_334;
  undefined uStack_330;
  undefined4 uStack_320;
  undefined4 uStack_31c;
  undefined uStack_318;
  undefined4 uStack_308;
  undefined4 uStack_304;
  undefined auStack_300 [16];
  undefined4 uStack_2f0;
  undefined4 uStack_2ec;
  undefined uStack_2e8;
  undefined4 uStack_2d8;
  undefined4 uStack_2d4;
  undefined uStack_2d0;
  undefined4 uStack_2c0;
  undefined4 uStack_2bc;
  undefined auStack_2b8 [16];
  undefined4 uStack_2a8;
  undefined4 uStack_2a4;
  undefined uStack_2a0;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined uStack_288;
  undefined4 uStack_278;
  undefined4 uStack_274;
  undefined auStack_270 [16];
  undefined4 uStack_260;
  undefined4 uStack_25c;
  undefined uStack_258;
  undefined4 uStack_248;
  undefined4 uStack_244;
  undefined uStack_240;
  undefined4 uStack_230;
  undefined4 uStack_22c;
  undefined auStack_228 [16];
  undefined4 uStack_218;
  undefined4 uStack_214;
  undefined uStack_210;
  undefined4 uStack_200;
  undefined4 uStack_1fc;
  undefined auStack_1f8 [16];
  undefined4 uStack_1e8;
  undefined4 uStack_1e4;
  undefined uStack_1e0;
  undefined4 uStack_1d0;
  undefined4 uStack_1cc;
  undefined auStack_1c8 [16];
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined uStack_1b0;
  undefined4 uStack_1a0;
  undefined4 uStack_19c;
  undefined auStack_198 [16];
  undefined4 uStack_188;
  undefined4 uStack_184;
  undefined auStack_180 [16];
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined auStack_168 [16];
  undefined4 uStack_158;
  undefined4 uStack_154;
  undefined auStack_150 [16];
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined auStack_138 [16];
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined auStack_120 [16];
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined auStack_108 [16];
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined auStack_f0 [16];
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined auStack_d8 [16];
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined auStack_c0 [16];
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined auStack_a8 [8];
  undefined auStack_a0 [8];
  undefined auStack_98 [8];
  undefined auStack_90 [8];
  undefined auStack_88 [8];
  undefined auStack_80 [8];
  undefined auStack_78 [8];
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  undefined4 *puStack_40;
  undefined4 uStack_3c;
  undefined4 *puStack_38;
  undefined4 uStack_34;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  undefined4 uStack_24;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018436e3;
  pvStack_10 = ExceptionList;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("GroupIcon",9);
  uStack_8 = 0;
  uStack_1b8 = 0;
  uStack_1b4 = 0xf;
  auStack_1c8[0] = 0;
  FUN_005542c0("150x150",7);
  uStack_8._0_1_ = 1;
  uStack_1a0 = 0;
  uStack_19c = 0xf;
  uStack_1b0 = 0;
  FUN_005542c0("420x420",7);
  uStack_8._0_1_ = 2;
  FUN_00baabb0(auStack_1c8,auStack_198);
  uStack_8._0_1_ = 3;
  FUN_0054ef60(auStack_58);
  uStack_8._0_1_ = 4;
  FUN_00f45600(&puStack_20,&uStack_11);
  puVar1 = puStack_20;
  uStack_18 = *puStack_20;
  uStack_8._0_1_ = 7;
  FUN_00576720(puStack_20[1]);
  puStack_20[1] = puVar1;
  *puStack_20 = puVar1;
  puStack_20[2] = puVar1;
  uStack_1c = 0;
  FUN_01674ea0(puStack_20,0x28);
  uStack_8._0_1_ = 8;
  FUN_016f32d1(auStack_1c8,0x18,2,FUN_005507b0);
  uStack_8._0_1_ = 9;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 9;
  if (0xf < uStack_44) {
    uVar4 = uStack_44 + 1;
    uVar3 = auStack_58[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_58[0] - 4);
      uVar4 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  FUN_005542c0("AvatarHeadShot",0xe);
  uStack_8._0_1_ = 10;
  uStack_260 = 0;
  uStack_25c = 0xf;
  auStack_270[0] = 0;
  FUN_005542c0("48x48",5);
  uStack_8._0_1_ = 0xb;
  uStack_248 = 0;
  uStack_244 = 0xf;
  uStack_258 = 0;
  FUN_005542c0("60x60",5);
  uStack_8._0_1_ = 0xc;
  uStack_230 = 0;
  uStack_22c = 0xf;
  uStack_240 = 0;
  FUN_005542c0("150x150",7);
  uStack_8._0_1_ = 0xd;
  FUN_00baabb0(auStack_270,auStack_228);
  uStack_8._0_1_ = 0xe;
  FUN_0054ef60(auStack_70);
  uStack_8._0_1_ = 0xf;
  FUN_00f45600(&puStack_28,&uStack_11);
  puVar1 = puStack_28;
  uStack_18 = *puStack_28;
  uStack_8._0_1_ = 0x12;
  FUN_00576720(puStack_28[1]);
  puStack_28[1] = puVar1;
  *puStack_28 = puVar1;
  puStack_28[2] = puVar1;
  uStack_24 = 0;
  FUN_01674ea0(puStack_28,0x28);
  uStack_8._0_1_ = 0x13;
  FUN_016f32d1(auStack_270,0x18,3,FUN_005507b0);
  uStack_8._0_1_ = 0x14;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x14;
  if (0xf < uStack_5c) {
    uVar4 = uStack_5c + 1;
    uVar3 = auStack_70[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_70[0] - 4);
      uVar4 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  uStack_e0 = 0;
  uStack_dc = 0xf;
  auStack_f0[0] = 0;
  FUN_005542c0("Avatar",6);
  uStack_8._0_1_ = 0x15;
  uStack_2a8 = 0;
  uStack_2a4 = 0xf;
  auStack_2b8[0] = 0;
  FUN_005542c0("100x100",7);
  uStack_8._0_1_ = 0x16;
  uStack_290 = 0;
  uStack_28c = 0xf;
  uStack_2a0 = 0;
  FUN_005542c0("352x352",7);
  uStack_8._0_1_ = 0x17;
  uStack_278 = 0;
  uStack_274 = 0xf;
  uStack_288 = 0;
  FUN_005542c0("720x720",7);
  uStack_8._0_1_ = 0x18;
  FUN_00baabb0(auStack_2b8,auStack_270);
  uStack_8._0_1_ = 0x19;
  FUN_0054ef60(auStack_f0);
  uStack_8._0_1_ = 0x1a;
  FUN_00f45600(&puStack_30,&uStack_11);
  puVar1 = puStack_30;
  uStack_18 = *puStack_30;
  uStack_8._0_1_ = 0x1d;
  FUN_00576720(puStack_30[1]);
  puStack_30[1] = puVar1;
  *puStack_30 = puVar1;
  puStack_30[2] = puVar1;
  uStack_2c = 0;
  FUN_01674ea0(puStack_30,0x28);
  uStack_8._0_1_ = 0x1e;
  FUN_016f32d1(auStack_2b8,0x18,3,FUN_005507b0);
  uStack_8._0_1_ = 0x1f;
  FUN_005507b0();
  uStack_f8 = 0;
  uStack_f4 = 0xf;
  auStack_108[0] = 0;
  FUN_005542c0("AvatarBust",10);
  uStack_8._0_1_ = 0x20;
  uStack_2f0 = 0;
  uStack_2ec = 0xf;
  auStack_300[0] = 0;
  FUN_005542c0("50x50",5);
  uStack_8._0_1_ = 0x21;
  uStack_2d8 = 0;
  uStack_2d4 = 0xf;
  uStack_2e8 = 0;
  FUN_005542c0("60x60",5);
  uStack_8._0_1_ = 0x22;
  uStack_2c0 = 0;
  uStack_2bc = 0xf;
  uStack_2d0 = 0;
  FUN_005542c0("75x75",5);
  uStack_8._0_1_ = 0x23;
  FUN_00baabb0(auStack_300,auStack_2b8);
  uStack_8._0_1_ = 0x24;
  FUN_0054ef60(auStack_108);
  uStack_8._0_1_ = 0x25;
  FUN_00f45600(&puStack_38,&uStack_11);
  puVar1 = puStack_38;
  uStack_18 = *puStack_38;
  uStack_8._0_1_ = 0x28;
  FUN_00576720(puStack_38[1]);
  puStack_38[1] = puVar1;
  *puStack_38 = puVar1;
  puStack_38[2] = puVar1;
  uStack_34 = 0;
  FUN_0054db70(puStack_38,0x28);
  uStack_8._0_1_ = 0x29;
  FUN_016f32d1(auStack_300,0x18,3,FUN_005507b0);
  uStack_8._0_1_ = 0x2a;
  FUN_005507b0();
  uStack_110 = 0;
  uStack_10c = 0xf;
  auStack_120[0] = 0;
  FUN_005542c0("GameIcon",8);
  uStack_8._0_1_ = 0x2b;
  uStack_368 = 0;
  uStack_364 = 0xf;
  auStack_378[0] = 0;
  FUN_005542c0("50x50",5);
  uStack_8._0_1_ = 0x2c;
  uStack_350 = 0;
  uStack_34c = 0xf;
  uStack_360 = 0;
  FUN_005542c0("128x128",7);
  uStack_8._0_1_ = 0x2d;
  uStack_338 = 0;
  uStack_334 = 0xf;
  uStack_348 = 0;
  FUN_005542c0("150x150",7);
  uStack_8._0_1_ = 0x2e;
  uStack_320 = 0;
  uStack_31c = 0xf;
  uStack_330 = 0;
  FUN_005542c0("256x256",7);
  uStack_8._0_1_ = 0x2f;
  uStack_308 = 0;
  uStack_304 = 0xf;
  uStack_318 = 0;
  FUN_005542c0("512x512",7);
  uStack_8._0_1_ = 0x30;
  FUN_00baabb0(auStack_378,auStack_300);
  uStack_8._0_1_ = 0x31;
  FUN_0054ef60(auStack_120);
  uStack_8._0_1_ = 0x32;
  FUN_00f45600(&puStack_40,&uStack_11);
  puVar1 = puStack_40;
  uStack_18 = *puStack_40;
  uStack_8._0_1_ = 0x35;
  FUN_00576720(puStack_40[1]);
  puStack_40[1] = puVar1;
  *puStack_40 = puVar1;
  puStack_40[2] = puVar1;
  uStack_3c = 0;
  FUN_0054db70(puStack_40,0x28);
  uStack_8._0_1_ = 0x36;
  FUN_016f32d1(auStack_378,0x18,5,FUN_005507b0);
  uStack_8._0_1_ = 0x37;
  FUN_005507b0();
  uStack_128 = 0;
  uStack_124 = 0xf;
  auStack_138[0] = 0;
  FUN_005542c0("GameThumbnail",0xd);
  uStack_8._0_1_ = 0x38;
  uStack_3e0 = 0;
  uStack_3dc = 0xf;
  auStack_3f0[0] = 0;
  FUN_005542c0("768x432",7);
  uStack_8._0_1_ = 0x39;
  uStack_3c8 = 0;
  uStack_3c4 = 0xf;
  uStack_3d8 = 0;
  FUN_005542c0("576x324",7);
  uStack_8._0_1_ = 0x3a;
  uStack_3b0 = 0;
  uStack_3ac = 0xf;
  uStack_3c0 = 0;
  FUN_005542c0("480x270",7);
  uStack_8._0_1_ = 0x3b;
  uStack_398 = 0;
  uStack_394 = 0xf;
  uStack_3a8 = 0;
  FUN_005542c0("384x216",7);
  uStack_8._0_1_ = 0x3c;
  uStack_380 = 0;
  uStack_37c = 0xf;
  uStack_390 = 0;
  FUN_005542c0("256x144",7);
  uStack_8._0_1_ = 0x3d;
  FUN_00baabb0(auStack_3f0,auStack_378);
  uStack_8._0_1_ = 0x3e;
  FUN_0054ef60(auStack_138);
  uStack_8._0_1_ = 0x3f;
  FUN_00f45600(auStack_78,&uStack_11);
  FUN_0056b800();
  uStack_8._0_1_ = 0x42;
  FUN_016f32d1(auStack_3f0,0x18,5,FUN_005507b0);
  uStack_8._0_1_ = 0x43;
  FUN_005507b0();
  uStack_140 = 0;
  uStack_13c = 0xf;
  auStack_150[0] = 0;
  FUN_005542c0("BadgeIcon",9);
  uStack_8._0_1_ = 0x44;
  uStack_b0 = 0;
  uStack_ac = 0xf;
  auStack_c0[0] = 0;
  FUN_005542c0("150x150",7);
  uStack_8._0_1_ = 0x45;
  FUN_00baabb0(auStack_c0,auStack_a8);
  uStack_8._0_1_ = 0x46;
  FUN_0054ef60(auStack_150);
  uStack_8._0_1_ = 0x47;
  FUN_00f45600(auStack_80,&uStack_11);
  FUN_0056b800();
  uStack_8._0_1_ = 0x4a;
  FUN_016f32d1(auStack_c0,0x18,1,FUN_005507b0);
  uStack_8._0_1_ = 0x4b;
  FUN_005507b0();
  uStack_158 = 0;
  uStack_154 = 0xf;
  auStack_168[0] = 0;
  FUN_005542c0("GamePass",8);
  uStack_8._0_1_ = 0x4c;
  uStack_c8 = 0;
  uStack_c4 = 0xf;
  auStack_d8[0] = 0;
  FUN_005542c0("150x150",7);
  uStack_8._0_1_ = 0x4d;
  FUN_00baabb0(auStack_d8,auStack_c0);
  uStack_8._0_1_ = 0x4e;
  FUN_0054ef60(auStack_168);
  uStack_8._0_1_ = 0x4f;
  FUN_00f45600(auStack_88,&uStack_11);
  FUN_0056b800();
  uStack_8._0_1_ = 0x52;
  FUN_016f32d1(auStack_d8,0x18,1,FUN_005507b0);
  uStack_8._0_1_ = 0x53;
  FUN_005507b0();
  uStack_170 = 0;
  uStack_16c = 0xf;
  auStack_180[0] = 0;
  FUN_005542c0("Asset",5);
  uStack_8._0_1_ = 0x54;
  uStack_1e8 = 0;
  uStack_1e4 = 0xf;
  auStack_1f8[0] = 0;
  FUN_005542c0("150x150",7);
  uStack_8._0_1_ = 0x55;
  uStack_1d0 = 0;
  uStack_1cc = 0xf;
  uStack_1e0 = 0;
  FUN_005542c0("420x420",7);
  uStack_8._0_1_ = 0x56;
  FUN_00baabb0(auStack_1f8,auStack_1c8);
  uStack_8._0_1_ = 0x57;
  FUN_0054ef60(auStack_180);
  uStack_8._0_1_ = 0x58;
  FUN_00f45600(auStack_90,&uStack_11);
  FUN_0056b800();
  uStack_8._0_1_ = 0x5b;
  FUN_016f32d1(auStack_1f8,0x18,2,FUN_005507b0);
  uStack_8._0_1_ = 0x5c;
  FUN_005507b0();
  uStack_188 = 0;
  uStack_184 = 0xf;
  auStack_198[0] = 0;
  FUN_005542c0("BundleThumbnail",0xf);
  uStack_8._0_1_ = 0x5d;
  uStack_218 = 0;
  uStack_214 = 0xf;
  auStack_228[0] = 0;
  FUN_005542c0("150x150",7);
  uStack_8._0_1_ = 0x5e;
  uStack_200 = 0;
  uStack_1fc = 0xf;
  uStack_210 = 0;
  FUN_00551260("420x420");
  uStack_8._0_1_ = 0x5f;
  FUN_00baabb0(auStack_228,auStack_1f8);
  uStack_8._0_1_ = 0x60;
  FUN_00f45500(auStack_198,auStack_98);
  FUN_0056b800();
  uStack_8._0_1_ = 99;
  FUN_016f32d1(auStack_228,0x18,2,FUN_005507b0);
  uStack_8._0_1_ = 100;
  FUN_005507b0();
  FUN_0054eff0("Outfit");
  uStack_8._0_1_ = 0x65;
  FUN_0054eff0("150x150");
  uStack_8._0_1_ = 0x66;
  FUN_0054eff0("420x420");
  uStack_8._0_1_ = 0x67;
  FUN_00baabb0(auStack_450,auStack_420);
  uStack_8._0_1_ = 0x68;
  FUN_00f45500(auStack_408,auStack_a0);
  FUN_0056b800();
  uStack_8._0_1_ = 0x6b;
  FUN_016f32d1(auStack_450,0x18,2,FUN_005507b0);
  uStack_8._0_1_ = 0x6c;
  FUN_005507b0();
  FUN_0054eff0("DeveloperProduct");
  uStack_8._0_1_ = 0x6d;
  FUN_0054eff0("150x150");
  uStack_8._0_1_ = 0x6e;
  FUN_0054eff0("420x420");
  uStack_8._0_1_ = 0x6f;
  FUN_00baabb0(auStack_480,auStack_450);
  uStack_8._0_1_ = 0x70;
  FUN_00f45500(auStack_420,auStack_a8);
  FUN_0056b800();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x73);
  FUN_016f32d1(auStack_480,0x18,2,FUN_005507b0);
  FUN_005507b0();
  uStack_8 = 0x75;
  FUN_00f46bd0(auStack_600,auStack_480);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(auStack_600,0x20,0xc,FUN_00f470c0);
  FUN_016f3654(FUN_018a9850);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2287 ; VA 0x005366b0 ; FUN_005366b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005366b0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184417c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00f50590();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::PluginGui,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetSetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_(__thiscall_RBX::PluginGui::*)(void)const_,void_(__thiscall_RBX::PluginGui::*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&)>
              ::vftable;
    puVar3[2] = FUN_00f510a0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00f51420;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,s_Title_02150f40,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02150d30 = RBX::Reflection::
                 TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02150d64 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02150d54 = _DAT_02150d54 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02150d30[2])();
    if (cVar1 != '\0') {
      _DAT_02150d54 = _DAT_02150d54 & 0xfffffff3;
    }
  }
  DAT_02150d30 = RBX::Reflection::
                 PropDescriptor<class_RBX::PluginGui,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  FUN_016f3654(&LAB_018a9940);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2288 ; VA 0x00536910 ; FUN_00536910 */

void FUN_00536910(void)

{
  undefined auStack_70 [32];
  undefined4 uStack_50;
  undefined8 uStack_4c;
  undefined *puStack_44;
  undefined **ppuStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180de78;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  uStack_4c = (ulonglong)uStack_20;
  uStack_3c = 0;
  uStack_50 = 0;
  puStack_44 = (undefined *)0x0;
  LOCK();
  DAT_01e90cd8 = DAT_01e90cd8 + 1;
  UNLOCK();
  ppuStack_40 = RBX::Lua::WeakFunctionRef::vftable;
  uStack_34 = 0;
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  puStack_14 = auStack_70;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00d88580(&ppuStack_40);
  FUN_00f506c0(FUN_00f50e60,0,s_BindToClose_0211d208,s_function_0211d1fc);
  puStack_44 = (undefined *)0x5369ab;
  FUN_00d88a30();
  puStack_44 = &LAB_018a99c0;
  uStack_4c = CONCAT44(0x5369b5,(undefined4)uStack_4c);
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2289 ; VA 0x005369d0 ; FUN_005369d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005369d0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184419a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00f50590(uVar2,0);
  FUN_009cb790(uVar1,s_GetRelativeMousePosition_02150f48,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02150d68 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PluginGui,class_G3D::Vector2___cdecl(void),0>::
       vftable;
  _DAT_02150da0 = FUN_00f51080;
  _DAT_02150da4 = 0;
  _DAT_02150d8c = FUN_0088d730();
  FUN_016f3654(&LAB_018a99e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2290 ; VA 0x00536be0 ; FUN_00536be0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00536be0(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01844c5e;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00f5a210();
  FUN_009cb970(uVar1,s_ItemWasSet_02151138,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02150fe4 = 0x58;
  iStack_8 = 0;
  _DAT_02150fb0 =
       RBX::Reflection::
       EventDesc<class_RBX::LocalStorageService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::LocalStorageService::*>
       ::vftable;
  FUN_0086e3d0(&DAT_0211f870);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_value_0211ab70);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02150fd8 = uStack_1c;
  _DAT_02150fdc = uStack_18;
  _DAT_02150fe0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_02150fb0 =
       RBX::Reflection::
       EventDesc<class_RBX::LocalStorageService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::LocalStorageService::*>
       ::vftable;
  FUN_016f3654(&LAB_018a9c00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2291 ; VA 0x00536d50 ; FUN_00536d50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00536d50(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd8;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd8 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00f5a210(uVar2,0);
  FUN_009cb970(uVar1,s_StoreWasCleared_02151144,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0215101c = 0x5c;
  _DAT_02150fe8 =
       RBX::Reflection::
       EventDesc<class_RBX::LocalStorageService,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::LocalStorageService::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_02151010 = 0;
  _DAT_02151014 = 0;
  _DAT_02151018 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_02150fe8 =
       RBX::Reflection::
       EventDesc<class_RBX::LocalStorageService,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::LocalStorageService::*>
       ::vftable;
  FUN_016f3654(&LAB_018a9c10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2292 ; VA 0x00536e40 ; FUN_00536e40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00536e40(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01844c7a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00f5a210(uVar2,0);
  FUN_009cb790(uVar1,s_Flush_02151154,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021510b0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::LocalStorageService,void___cdecl(void),0>::vftable;
  _DAT_021510e8 = FUN_00f5b060;
  _DAT_021510ec = 0;
  _DAT_021510d4 = FUN_00888530();
  FUN_016f3654(&LAB_018a9c20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2293 ; VA 0x00536ee0 ; FUN_00536ee0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00536ee0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01844cdc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00f5a210();
  FUN_009cb790(uVar1,s_GetItem_0214d9f0,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02151068 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LocalStorageService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_021510a0 = FUN_00f5b0b0;
  _DAT_021510a4 = 0;
  DAT_021510a8 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0215108c = FUN_0088cb40();
  if (DAT_021510a8 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_021510a8);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(&DAT_0211f870);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a9c30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2294 ; VA 0x00537060 ; FUN_00537060 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00537060(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01844d0e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00f5a210(uVar2,0);
  FUN_009cb790(uVar1,s_SetItem_0214d9e0,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02151020 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LocalStorageService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_02151058 = FUN_00f5b4a0;
  _DAT_0215105c = 0;
  _DAT_02151060 = 0;
  _DAT_02151064 = 0;
  uStack_8 = 2;
  FUN_00b94f90();
  FUN_016f3654(&LAB_018a9c50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2295 ; VA 0x00537120 ; FUN_00537120 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00537120(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined *puStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01844d6c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00f5a210();
  FUN_009cb790(uVar2,s_WhenLoaded_0215115c,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_021510f0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LocalStorageService,void___cdecl(class_RBX::Lua::WeakFunctionRef),1>
       ::vftable;
  _DAT_02151128 = FUN_00f5b5a0;
  _DAT_0215112c = 0;
  DAT_02151130 = 0;
  uStack_8 = 1;
  _DAT_02151114 = FUN_00888530();
  iVar1 = DAT_02151130;
  if (DAT_02151130 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_00d88470();
    puStack_ec = (undefined *)0x0;
    FUN_00d88580(iVar1);
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee047c) {
      FUN_016f3809(&DAT_01ee047c);
      if (DAT_01ee047c == -1) {
        _DAT_01ee0470 = FUN_008c9370;
        _DAT_01ee0474 = FUN_008c9370;
        DAT_01ee0478 = FUN_008ca540;
        FUN_016f37bf(&DAT_01ee047c);
      }
    }
    puStack_ec = &DAT_01ee0470;
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_00d88470();
  uVar3 = FUN_0086e3d0(s_callback_02139198);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_ec != (undefined *)0x0) {
      (**(code **)(puStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018a9c70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2296 ; VA 0x00537710 ; FUN_00537710 */

void FUN_00537710(void)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01849225;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count_obj<class_std::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::AppConfiguration>,struct_std::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_std::shared_ptr<class_RBX::AppConfiguration>_>_>_>_>
              ::vftable;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    uVar2 = FUN_008ed990(0,0);
    puVar1[4] = uVar2;
    puVar1[6] = 0;
    puVar1[7] = 0;
    puVar1[8] = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    puVar1[3] = 0x3f800000;
    FUN_005cb500(8);
  }
  DAT_01f2da64 = puVar1 + 3;
  DAT_01f2da68 = puVar1;
  FUN_016f3654(&LAB_018aa230);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2297 ; VA 0x00537800 ; FUN_00537800 */

void FUN_00537800(void)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 auStack_1a0 [2];
  undefined auStack_198 [48];
  undefined auStack_168 [36];
  undefined4 uStack_144;
  undefined4 uStack_140;
  int aiStack_138 [12];
  undefined auStack_108 [36];
  undefined4 uStack_e4;
  undefined4 auStack_e0 [2];
  undefined auStack_d8 [16];
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined auStack_c0 [16];
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined **appuStack_a8 [9];
  undefined ***pppuStack_84;
  undefined auStack_80 [16];
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined auStack_68 [16];
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined **appuStack_50 [9];
  undefined ***pppuStack_2c;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  int iStack_20;
  undefined4 *puStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018492da;
  pvStack_10 = ExceptionList;
  uStack_70 = 0;
  uStack_6c = 0xf;
  auStack_80[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0("app-policy",10);
  uStack_8 = 0;
  uStack_58 = 0;
  uStack_54 = 0xf;
  auStack_68[0] = 0;
  FUN_005542c0("{     \"ChatConversationHeaderGroupDetails\": true,     \"ChatHeaderSearch\": true,     \"ChatHeaderCreateChatGroup\": true,     \"ChatHeaderHomeButton\": false,     \"ChatHeaderNotifications\": true,     \"ChatPlayTogether\": true,     \"ChatShareGameToChatFromChat\": true,     \"ChatTapConversationThumbnail\": true,     \"GameDetailsMorePage\": true,     \"GameDetailsSubtitle\": true,     \"GameInfoList\": true,     \"GamePlaysAndRatings\": true,     \"Notifications\": true,     \"RecommendedGames\": true,     \"SearchBar\": true,     \"MorePageType\": \"MoreSimplified\",     \"SocialLinks\": false,     \"SiteMessageBanner\": true,     \"UseWidthBasedFormFactorRule\": false,     \"UseHomePageWithAvatarAndPanel\": false,     \"UseBottomBar\": true,     \"AvatarHeaderIcon\": \"LuaApp/icons/ic-back\",     \"AvatarEditorShowBuyRobuxOnTopBar\": true,     \"HomeIcon\": \"LuaApp/icons/ic-roblox-close\",     \"ShowYouTubeAgeAlert\": true }"
               ,0x37b);
  pppuStack_2c = appuStack_50;
  appuStack_50[0] =
       std::
       _Func_impl_no_alloc<class_<lambda_1c00a5b04ed837f55a28e29472c006ad>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
       ::vftable;
  piStack_18 = (int *)auStack_198;
  uStack_8 = 1;
  auStack_1a0[0] = 0;
  FUN_0054ef60(auStack_80);
  uStack_8._0_1_ = 2;
  FUN_0054ef60(auStack_68);
  puStack_14 = auStack_168;
  uStack_144 = 0;
  uStack_8._0_1_ = 4;
  if (pppuStack_2c != (undefined ***)0x0) {
    uStack_144 = (*(code *)**pppuStack_2c)(auStack_168);
  }
  uStack_8._0_1_ = 6;
  FUN_00f8e650();
  uStack_c8 = 0;
  uStack_c4 = 0xf;
  auStack_d8[0] = 0;
  FUN_005542c0("app-patch",9);
  uStack_8._0_1_ = 7;
  uStack_b0 = 0;
  uStack_ac = 0xf;
  auStack_c0[0] = 0;
  FUN_005542c0("{     \"SchemaVersion\": \"1\",     \"CanaryPercentage\": 0.0,     \"CanaryUserIds\": [],     \"CanaryAppInstallationIds\": [],     \"Canary\": {         \"AssetId\": \"0\",         \"AssetVersion\": \"0\",         \"IsForcedUpdate\": false,         \"AppStorageResetId\": \"0\"     },     \"Stable\": {         \"AssetId\": \"0\",         \"AssetVersion\": \"0\",         \"IsForcedUpdate\": false,         \"AppStorageResetId\": \"0\"     } }"
               ,0x192);
  pppuStack_84 = appuStack_a8;
  appuStack_a8[0] =
       std::
       _Func_impl_no_alloc<class_<lambda_20a3506570f7efb079bf278e4f31c7cb>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
       ::vftable;
  piStack_18 = aiStack_138;
  uStack_8._0_1_ = 8;
  uStack_140 = 1;
  FUN_0054ef60(auStack_d8);
  uStack_8._0_1_ = 9;
  FUN_0054ef60(auStack_c0);
  puStack_14 = auStack_108;
  uStack_e4 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  if (pppuStack_84 != (undefined ***)0x0) {
    uStack_e4 = (*(code *)**pppuStack_84)(auStack_108);
  }
  FUN_00f8e650();
  uStack_8 = 0xc;
  puVar2 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8._0_1_ = 0xd;
  puStack_24 = puVar2;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    puStack_28 = puVar2 + 3;
    puVar2[1] = 1;
    puVar1 = puVar2 + 4;
    puVar2[2] = 1;
    *puVar2 = std::
              _Ref_count_obj<class_std::unordered_map<enum_RBX::AppConfigurationType,struct_RBX::AppConfiguration::Definition,struct_std::hash<enum_RBX::AppConfigurationType>,struct_std::equal_to<enum_RBX::AppConfigurationType>,class_std::allocator<struct_std::pair<enum_RBX::AppConfigurationType_const_,struct_RBX::AppConfiguration::Definition>_>_>_>
              ::vftable;
    *puStack_28 = 0;
    *puVar1 = 0;
    puVar2[5] = 0;
    uVar3 = FUN_00f47ac0(0,0);
    *puVar1 = uVar3;
    puVar2[6] = 0;
    puVar2[7] = 0;
    puVar2[8] = 0;
    uStack_8._0_1_ = 0xf;
    puVar2[3] = 0x3f800000;
    FUN_005cb500(8);
    puStack_1c = auStack_1a0;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
    do {
      iStack_20 = *(int *)*puVar1;
      piStack_18 = *(int **)(iStack_20 + 4);
      puStack_14 = (undefined *)FUN_00f8d5f0(iStack_20,piStack_18,puStack_1c);
      if (puVar2[5] == 0x2762761) {
                    /* WARNING: Subroutine does not return */
        FUN_016ddcd9("list<T> too long");
      }
      puVar2[5] = puVar2[5] + 1;
      *(undefined **)(iStack_20 + 4) = puStack_14;
      *piStack_18 = (int)puStack_14;
      FUN_00f8db50(auStack_e0,*(int *)*puVar1 + 8,*(int *)*puVar1);
      puStack_1c = puStack_1c + 0x18;
    } while (puStack_1c != auStack_e0);
  }
  DAT_01f2d9f4 = puVar2 + 3;
  uStack_8 = 0xffffffff;
  DAT_01f2d9f8 = puVar2;
  FUN_016f32d1(auStack_1a0,0x60,2,FUN_00f8e500);
  FUN_016f3654(&LAB_018aa2d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2298 ; VA 0x00537bb0 ; FUN_00537bb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00537bb0(void)

{
  undefined uVar1;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_30;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  uVar1 = 0;
  FUN_005542c0("AppConfiguration",0x10);
  uStack_8 = 0xffffffff;
  _DAT_01f2d9f0 = FUN_0153ec90(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2299 ; VA 0x00537fa0 ; FUN_00537fa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00537fa0(void)

{
  double dVar1;
  
  dVar1 = DAT_018ce308;
  FUN_017267a0();
  _DAT_01f2db1c = (float)dVar1 * DAT_018ce328;
  return;
}



/* FUNCTION 2300 ; VA 0x00538180 ; FUN_00538180 */

void FUN_00538180(void)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a87a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = CreateSemaphoreA(0,0,0x7fffffff,0);
  if (iVar1 == 0) {
    uVar2 = FUN_005503c0();
    uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
    FUN_0054e630(uVar2);
  }
  DAT_01f2dca4 = iVar1;
  DAT_01f2dca8 = CreateSemaphoreA(0,0,0x7fffffff,0);
  if (DAT_01f2dca8 != 0) {
    DAT_01f2dcac = CreateSemaphoreA(0,0,0x7fffffff,0);
    if (DAT_01f2dcac != 0) {
      DAT_01f2dca0 = 0;
      FUN_016f3654(&LAB_018aa8e0);
      ExceptionList = pvStack_10;
      return;
    }
    FUN_006ddd60(DAT_01f2dca4,0x7fffffff);
    FUN_006ddd60(DAT_01f2dca8,0x7fffffff);
    uVar2 = FUN_005503c0();
    uStack_8 = 2;
                    /* WARNING: Subroutine does not return */
    FUN_0054e630(uVar2);
  }
  FUN_006ddd60(DAT_01f2dca4,0x7fffffff);
  uVar2 = FUN_005503c0();
  uStack_8 = 1;
                    /* WARNING: Subroutine does not return */
  FUN_0054e630(uVar2);
}



/* FUNCTION 2301 ; VA 0x005387c0 ; FUN_005387c0 */

void FUN_005387c0(void)

{
  undefined auStack_160 [16];
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined uStack_148;
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined uStack_130;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined uStack_118;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined uStack_100;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined uStack_d0;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined uStack_b8;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined uStack_a0;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined uStack_88;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined uStack_70;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined uStack_58;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined uStack_40;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined uStack_28;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184d43c;
  pvStack_10 = ExceptionList;
  uStack_150 = 0;
  uStack_14c = 0xf;
  auStack_160[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0("zh-cn",5);
  uStack_8 = 0;
  uStack_138 = 0;
  uStack_134 = 0xf;
  uStack_148 = 0;
  FUN_005542c0("zh-hans",7);
  uStack_8 = 1;
  uStack_120 = 0;
  uStack_11c = 0xf;
  uStack_130 = 0;
  FUN_005542c0("zh-sg",5);
  uStack_8._0_1_ = 2;
  uStack_108 = 0;
  uStack_104 = 0xf;
  uStack_118 = 0;
  FUN_005542c0("zh-hans",7);
  uStack_8._0_1_ = 3;
  uStack_f0 = 0;
  uStack_ec = 0xf;
  uStack_100 = 0;
  FUN_005542c0("zh-hk",5);
  uStack_8._0_1_ = 4;
  uStack_d8 = 0;
  uStack_d4 = 0xf;
  uStack_e8 = 0;
  FUN_005542c0("zh-hant",7);
  uStack_8._0_1_ = 5;
  uStack_c0 = 0;
  uStack_bc = 0xf;
  uStack_d0 = 0;
  FUN_005542c0("zh-tw",5);
  uStack_8._0_1_ = 6;
  uStack_a8 = 0;
  uStack_a4 = 0xf;
  uStack_b8 = 0;
  FUN_005542c0("zh-hant",7);
  uStack_8._0_1_ = 7;
  uStack_90 = 0;
  uStack_8c = 0xf;
  uStack_a0 = 0;
  FUN_005542c0("zh-hans",7);
  uStack_8._0_1_ = 8;
  uStack_78 = 0;
  uStack_74 = 0xf;
  uStack_88 = 0;
  FUN_005542c0("zh-hans",7);
  uStack_8._0_1_ = 9;
  uStack_60 = 0;
  uStack_5c = 0xf;
  uStack_70 = 0;
  FUN_005542c0("zh-hant",7);
  uStack_8._0_1_ = 10;
  uStack_48 = 0;
  uStack_44 = 0xf;
  uStack_58 = 0;
  FUN_005542c0("zh-hant",7);
  uStack_8._0_1_ = 0xb;
  uStack_30 = 0;
  uStack_2c = 0xf;
  uStack_40 = 0;
  FUN_005542c0("zh-cjv",6);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  uStack_18 = 0;
  uStack_14 = 0xf;
  uStack_28 = 0;
  FUN_005542c0("zh-cjv",6);
  uStack_8 = 0xd;
  FUN_00fc17b0(auStack_160,&pvStack_10);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(auStack_160,0x30,7,FUN_005509f0);
  FUN_016f3654(&LAB_018aa970);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2302 ; VA 0x00538ab0 ; FUN_00538ab0 */

void FUN_00538ab0(void)

{
  undefined auStack_d0 [16];
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined uStack_b8;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined uStack_a0;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined uStack_88;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined uStack_70;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined uStack_58;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined uStack_40;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined uStack_28;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184d4aa;
  pvStack_10 = ExceptionList;
  uStack_c0 = 0;
  uStack_bc = 0xf;
  auStack_d0[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0("zh-cn",5);
  uStack_8 = 0;
  uStack_a8 = 0;
  uStack_a4 = 0xf;
  uStack_b8 = 0;
  FUN_005542c0("zh-hans",7);
  uStack_8 = 1;
  uStack_90 = 0;
  uStack_8c = 0xf;
  uStack_a0 = 0;
  FUN_005542c0("zh-sg",5);
  uStack_8._0_1_ = 2;
  uStack_78 = 0;
  uStack_74 = 0xf;
  uStack_88 = 0;
  FUN_005542c0("zh-hans",7);
  uStack_8._0_1_ = 3;
  uStack_60 = 0;
  uStack_5c = 0xf;
  uStack_70 = 0;
  FUN_005542c0("zh-hk",5);
  uStack_8._0_1_ = 4;
  uStack_48 = 0;
  uStack_44 = 0xf;
  uStack_58 = 0;
  FUN_005542c0("zh-hant",7);
  uStack_8._0_1_ = 5;
  uStack_30 = 0;
  uStack_2c = 0xf;
  uStack_40 = 0;
  FUN_005542c0("zh-tw",5);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  uStack_18 = 0;
  uStack_14 = 0xf;
  uStack_28 = 0;
  FUN_005542c0("zh-hant",7);
  uStack_8 = 7;
  FUN_00fc17b0(auStack_d0,&pvStack_10);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(auStack_d0,0x30,4,FUN_005509f0);
  FUN_016f3654(&LAB_018aa980);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2303 ; VA 0x00538c80 ; FUN_00538c80 */

void FUN_00538c80(void)

{
  undefined4 uStack_c;
  undefined uStack_5;
  
  uStack_c = 0;
  FUN_00a3ab70(&uStack_c,&uStack_5);
  FUN_016f3654(&LAB_018aa990);
  return;
}



/* FUNCTION 2304 ; VA 0x00538cb0 ; FUN_00538cb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00538cb0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184d4d4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  DAT_01f2df34 = FUN_00fc2a00(0,0);
  _DAT_01f2df3c = 0;
  _DAT_01f2df40 = 0;
  _DAT_01f2df44 = 0;
  uStack_8 = 1;
  _DAT_01f2df30 = 0x3f800000;
  FUN_005cb500(8);
  FUN_016f3654(&LAB_018aa9a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2305 ; VA 0x00538d60 ; FUN_00538d60 */

void FUN_00538d60(void)

{
  undefined auStack_280 [16];
  undefined4 uStack_270;
  undefined4 uStack_26c;
  undefined uStack_268;
  undefined4 uStack_258;
  undefined4 uStack_254;
  undefined uStack_250;
  undefined4 uStack_240;
  undefined4 uStack_23c;
  undefined uStack_238;
  undefined4 uStack_228;
  undefined4 uStack_224;
  undefined uStack_220;
  undefined4 uStack_210;
  undefined4 uStack_20c;
  undefined uStack_208;
  undefined4 uStack_1f8;
  undefined4 uStack_1f4;
  undefined uStack_1f0;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined uStack_1d8;
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined uStack_1c0;
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined uStack_1a8;
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined uStack_190;
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined uStack_178;
  undefined4 uStack_168;
  undefined4 uStack_164;
  undefined uStack_160;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined uStack_148;
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined uStack_130;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined uStack_118;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined uStack_100;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined uStack_d0;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined uStack_b8;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined uStack_a0;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined uStack_88;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined uStack_70;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined uStack_58;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined uStack_40;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined uStack_28;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184d600;
  pvStack_10 = ExceptionList;
  uStack_270 = 0;
  uStack_26c = 0xf;
  auStack_280[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_0197ec68,2);
  uStack_8 = 0;
  uStack_258 = 0;
  uStack_254 = 0xf;
  uStack_268 = 0;
  FUN_005542c0("en-gb",5);
  uStack_8 = 1;
  uStack_240 = 0;
  uStack_23c = 0xf;
  uStack_250 = 0;
  FUN_005542c0(&DAT_019c7ab8,2);
  uStack_8._0_1_ = 2;
  uStack_228 = 0;
  uStack_224 = 0xf;
  uStack_238 = 0;
  FUN_005542c0("de-de",5);
  uStack_8._0_1_ = 3;
  uStack_210 = 0;
  uStack_20c = 0xf;
  uStack_220 = 0;
  FUN_005542c0(&DAT_019c7abc,2);
  uStack_8._0_1_ = 4;
  uStack_1f8 = 0;
  uStack_1f4 = 0xf;
  uStack_208 = 0;
  FUN_005542c0("es-es",5);
  uStack_8._0_1_ = 5;
  uStack_1e0 = 0;
  uStack_1dc = 0xf;
  uStack_1f0 = 0;
  FUN_005542c0(&DAT_019c7ac0,2);
  uStack_8._0_1_ = 6;
  uStack_1c8 = 0;
  uStack_1c4 = 0xf;
  uStack_1d8 = 0;
  FUN_005542c0("fr-fr",5);
  uStack_8._0_1_ = 7;
  uStack_1b0 = 0;
  uStack_1ac = 0xf;
  uStack_1c0 = 0;
  FUN_005542c0(&DAT_019c7ac4,2);
  uStack_8._0_1_ = 8;
  uStack_198 = 0;
  uStack_194 = 0xf;
  uStack_1a8 = 0;
  FUN_005542c0("it-it",5);
  uStack_8._0_1_ = 9;
  uStack_180 = 0;
  uStack_17c = 0xf;
  uStack_190 = 0;
  FUN_005542c0(&DAT_018d3eec,2);
  uStack_8._0_1_ = 10;
  uStack_168 = 0;
  uStack_164 = 0xf;
  uStack_178 = 0;
  FUN_005542c0("pt-br",5);
  uStack_8._0_1_ = 0xb;
  uStack_150 = 0;
  uStack_14c = 0xf;
  uStack_160 = 0;
  FUN_005542c0(&DAT_019c7ac8,2);
  uStack_8._0_1_ = 0xc;
  uStack_138 = 0;
  uStack_134 = 0xf;
  uStack_148 = 0;
  FUN_005542c0("ru-ru",5);
  uStack_8._0_1_ = 0xd;
  uStack_120 = 0;
  uStack_11c = 0xf;
  uStack_130 = 0;
  FUN_005542c0(&DAT_019c7acc,2);
  uStack_8._0_1_ = 0xe;
  uStack_108 = 0;
  uStack_104 = 0xf;
  uStack_118 = 0;
  FUN_005542c0("ja-jp",5);
  uStack_8._0_1_ = 0xf;
  uStack_f0 = 0;
  uStack_ec = 0xf;
  uStack_100 = 0;
  FUN_005542c0(&DAT_019c7ad0,2);
  uStack_8._0_1_ = 0x10;
  uStack_d8 = 0;
  uStack_d4 = 0xf;
  uStack_e8 = 0;
  FUN_005542c0("ko-kr",5);
  uStack_8._0_1_ = 0x11;
  uStack_c0 = 0;
  uStack_bc = 0xf;
  uStack_d0 = 0;
  FUN_005542c0(&DAT_019c7ad4,2);
  uStack_8._0_1_ = 0x12;
  uStack_a8 = 0;
  uStack_a4 = 0xf;
  uStack_b8 = 0;
  FUN_005542c0("zh-cn",5);
  uStack_8._0_1_ = 0x13;
  uStack_90 = 0;
  uStack_8c = 0xf;
  uStack_a0 = 0;
  FUN_005542c0("zh-hans",7);
  uStack_8._0_1_ = 0x14;
  uStack_78 = 0;
  uStack_74 = 0xf;
  uStack_88 = 0;
  FUN_005542c0("zh-cn",5);
  uStack_8._0_1_ = 0x15;
  uStack_60 = 0;
  uStack_5c = 0xf;
  uStack_70 = 0;
  FUN_005542c0("zh-hant",7);
  uStack_8._0_1_ = 0x16;
  uStack_48 = 0;
  uStack_44 = 0xf;
  uStack_58 = 0;
  FUN_005542c0("zh-tw",5);
  uStack_8._0_1_ = 0x17;
  uStack_30 = 0;
  uStack_2c = 0xf;
  uStack_40 = 0;
  FUN_005542c0("zh-cjv",6);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
  uStack_18 = 0;
  uStack_14 = 0xf;
  uStack_28 = 0;
  FUN_005542c0("zh-cn",5);
  uStack_8 = 0x19;
  FUN_00fc17b0(auStack_280,&pvStack_10);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(auStack_280,0x30,0xd,FUN_005509f0);
  FUN_016f3654(&LAB_018aaa10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2306 ; VA 0x005392a0 ; FUN_005392a0 */

void FUN_005392a0(void)

{
  undefined auStack_250 [16];
  undefined4 uStack_240;
  undefined4 uStack_23c;
  undefined uStack_238;
  undefined4 uStack_228;
  undefined4 uStack_224;
  undefined uStack_220;
  undefined4 uStack_210;
  undefined4 uStack_20c;
  undefined uStack_208;
  undefined4 uStack_1f8;
  undefined4 uStack_1f4;
  undefined uStack_1f0;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined uStack_1d8;
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined uStack_1c0;
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined uStack_1a8;
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined uStack_190;
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined uStack_178;
  undefined4 uStack_168;
  undefined4 uStack_164;
  undefined uStack_160;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined uStack_148;
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined uStack_130;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined uStack_118;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined uStack_100;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined uStack_d0;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined uStack_b8;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined uStack_a0;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined uStack_88;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined uStack_70;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined uStack_58;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined uStack_40;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined uStack_28;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184d71a;
  pvStack_10 = ExceptionList;
  uStack_240 = 0;
  uStack_23c = 0xf;
  auStack_250[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_0197ec68,2);
  uStack_8 = 0;
  uStack_228 = 0;
  uStack_224 = 0xf;
  uStack_238 = 0;
  FUN_005542c0("en-us",5);
  uStack_8 = 1;
  uStack_210 = 0;
  uStack_20c = 0xf;
  uStack_220 = 0;
  FUN_005542c0(&DAT_019c7ab8,2);
  uStack_8._0_1_ = 2;
  uStack_1f8 = 0;
  uStack_1f4 = 0xf;
  uStack_208 = 0;
  FUN_005542c0("de-de",5);
  uStack_8._0_1_ = 3;
  uStack_1e0 = 0;
  uStack_1dc = 0xf;
  uStack_1f0 = 0;
  FUN_005542c0(&DAT_019c7abc,2);
  uStack_8._0_1_ = 4;
  uStack_1c8 = 0;
  uStack_1c4 = 0xf;
  uStack_1d8 = 0;
  FUN_005542c0("es-es",5);
  uStack_8._0_1_ = 5;
  uStack_1b0 = 0;
  uStack_1ac = 0xf;
  uStack_1c0 = 0;
  FUN_005542c0(&DAT_019c7ac0,2);
  uStack_8._0_1_ = 6;
  uStack_198 = 0;
  uStack_194 = 0xf;
  uStack_1a8 = 0;
  FUN_005542c0("fr-fr",5);
  uStack_8._0_1_ = 7;
  uStack_180 = 0;
  uStack_17c = 0xf;
  uStack_190 = 0;
  FUN_005542c0(&DAT_019c7ac4,2);
  uStack_8._0_1_ = 8;
  uStack_168 = 0;
  uStack_164 = 0xf;
  uStack_178 = 0;
  FUN_005542c0("it-it",5);
  uStack_8._0_1_ = 9;
  uStack_150 = 0;
  uStack_14c = 0xf;
  uStack_160 = 0;
  FUN_005542c0(&DAT_018d3eec,2);
  uStack_8._0_1_ = 10;
  uStack_138 = 0;
  uStack_134 = 0xf;
  uStack_148 = 0;
  FUN_005542c0("pt-br",5);
  uStack_8._0_1_ = 0xb;
  uStack_120 = 0;
  uStack_11c = 0xf;
  uStack_130 = 0;
  FUN_005542c0(&DAT_019c7ac8,2);
  uStack_8._0_1_ = 0xc;
  uStack_108 = 0;
  uStack_104 = 0xf;
  uStack_118 = 0;
  FUN_005542c0("ru-ru",5);
  uStack_8._0_1_ = 0xd;
  uStack_f0 = 0;
  uStack_ec = 0xf;
  uStack_100 = 0;
  FUN_005542c0(&DAT_019c7acc,2);
  uStack_8._0_1_ = 0xe;
  uStack_d8 = 0;
  uStack_d4 = 0xf;
  uStack_e8 = 0;
  FUN_005542c0("ja-jp",5);
  uStack_8._0_1_ = 0xf;
  uStack_c0 = 0;
  uStack_bc = 0xf;
  uStack_d0 = 0;
  FUN_005542c0(&DAT_019c7ad0,2);
  uStack_8._0_1_ = 0x10;
  uStack_a8 = 0;
  uStack_a4 = 0xf;
  uStack_b8 = 0;
  FUN_005542c0("ko-kr",5);
  uStack_8._0_1_ = 0x11;
  uStack_90 = 0;
  uStack_8c = 0xf;
  uStack_a0 = 0;
  FUN_005542c0(&DAT_019c7ad4,2);
  uStack_8._0_1_ = 0x12;
  uStack_78 = 0;
  uStack_74 = 0xf;
  uStack_88 = 0;
  FUN_005542c0("zh-cn",5);
  uStack_8._0_1_ = 0x13;
  uStack_60 = 0;
  uStack_5c = 0xf;
  uStack_70 = 0;
  FUN_005542c0("zh-hans",7);
  uStack_8._0_1_ = 0x14;
  uStack_48 = 0;
  uStack_44 = 0xf;
  uStack_58 = 0;
  FUN_005542c0("zh-cn",5);
  uStack_8._0_1_ = 0x15;
  uStack_30 = 0;
  uStack_2c = 0xf;
  uStack_40 = 0;
  FUN_005542c0("zh-hant",7);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
  uStack_18 = 0;
  uStack_14 = 0xf;
  uStack_28 = 0;
  FUN_005542c0("zh-tw",5);
  uStack_8 = 0x17;
  FUN_00fc17b0(auStack_250,&pvStack_10);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(auStack_250,0x30,0xc,FUN_005509f0);
  FUN_016f3654(&LAB_018aaa20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2307 ; VA 0x00539780 ; FUN_00539780 */

void __fastcall FUN_00539780(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c2a7f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01674e20(0x1c,param_1);
  uStack_8 = 0;
  if (iVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_00fc2030(0x2c,0x2e);
  }
  uStack_8 = 0xffffffff;
  FUN_00fbfd90(&DAT_01f2de70,uVar2);
  FUN_016f3654(FUN_018aaa30,iVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2308 ; VA 0x00539800 ; FUN_00539800 */

void __fastcall FUN_00539800(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c2a7f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01674e20(0x1c,param_1);
  uStack_8 = 0;
  if (iVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_00fc2030(0x2e,0x2c);
  }
  uStack_8 = 0xffffffff;
  FUN_00fbfd90(&DAT_01f2de70,uVar2);
  FUN_016f3654(FUN_018aaa80,iVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2309 ; VA 0x00539880 ; FUN_00539880 */

void __fastcall FUN_00539880(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c2a7f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01674e20(0x1c,param_1);
  uStack_8 = 0;
  if (iVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_00fc2030(0xffffffa0,0x2c);
  }
  uStack_8 = 0xffffffff;
  FUN_00fbfd90(&DAT_01f2de70,uVar2);
  FUN_016f3654(FUN_018aaad0,iVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2310 ; VA 0x00539900 ; FUN_00539900 */

void FUN_00539900(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  DAT_01f2de74 = FUN_016de181(1);
  FUN_016f3654(FUN_018aab20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2311 ; VA 0x00539970 ; FUN_00539970 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00539970(void)

{
  int iVar1;
  undefined uVar2;
  uint uVar3;
  uint uVar4;
  undefined *puVar5;
  undefined auStack_740 [24];
  char *pcStack_728;
  undefined *puStack_724;
  char *pcStack_720;
  undefined *puStack_71c;
  undefined *puStack_718;
  undefined *puStack_714;
  undefined4 uStack_710;
  undefined4 uStack_70c;
  undefined8 uStack_708;
  char *pcStack_6e8;
  undefined *puStack_6e4;
  char *pcStack_6e0;
  undefined *puStack_6dc;
  undefined1 *puStack_6d8;
  undefined1 *puStack_6d4;
  undefined4 uStack_6d0;
  undefined4 uStack_6cc;
  undefined8 uStack_6c8;
  char *pcStack_6a8;
  undefined *puStack_6a4;
  char *pcStack_6a0;
  undefined *puStack_69c;
  undefined *puStack_698;
  undefined *puStack_694;
  undefined4 uStack_690;
  undefined4 uStack_68c;
  undefined8 uStack_688;
  char *pcStack_668;
  undefined *puStack_664;
  char *pcStack_660;
  undefined *puStack_65c;
  undefined *puStack_658;
  undefined *puStack_654;
  undefined4 uStack_650;
  undefined4 uStack_64c;
  undefined8 uStack_648;
  char *pcStack_628;
  undefined *puStack_624;
  char *pcStack_620;
  undefined *puStack_61c;
  undefined *puStack_618;
  undefined *puStack_614;
  undefined4 uStack_610;
  undefined4 uStack_60c;
  undefined8 uStack_608;
  char *pcStack_5e8;
  undefined *puStack_5e4;
  char *pcStack_5e0;
  undefined *puStack_5dc;
  undefined1 *puStack_5d8;
  undefined1 *puStack_5d4;
  undefined4 uStack_5d0;
  undefined4 uStack_5cc;
  undefined8 uStack_5c8;
  char *pcStack_5a8;
  undefined *puStack_5a4;
  char *pcStack_5a0;
  undefined *puStack_59c;
  undefined1 *puStack_598;
  undefined1 *puStack_594;
  undefined4 uStack_590;
  undefined4 uStack_58c;
  undefined8 uStack_588;
  char *pcStack_568;
  undefined *puStack_564;
  char *pcStack_560;
  undefined *puStack_55c;
  undefined *puStack_558;
  undefined *puStack_554;
  undefined4 uStack_550;
  undefined4 uStack_54c;
  undefined8 uStack_548;
  char *pcStack_528;
  undefined *puStack_524;
  char *pcStack_520;
  undefined *puStack_51c;
  undefined1 *puStack_518;
  undefined1 *puStack_514;
  undefined4 uStack_510;
  undefined4 uStack_50c;
  undefined8 uStack_508;
  char *pcStack_4e8;
  undefined *puStack_4e4;
  char *pcStack_4e0;
  undefined *puStack_4dc;
  undefined1 *puStack_4d8;
  undefined1 *puStack_4d4;
  undefined4 uStack_4d0;
  undefined4 uStack_4cc;
  undefined8 uStack_4c8;
  char *pcStack_4a8;
  undefined *puStack_4a4;
  char *pcStack_4a0;
  undefined *puStack_49c;
  undefined1 *puStack_498;
  undefined1 *puStack_494;
  undefined4 uStack_490;
  undefined4 uStack_48c;
  undefined8 uStack_488;
  char *pcStack_468;
  undefined *puStack_464;
  char *pcStack_460;
  undefined *puStack_45c;
  undefined1 *puStack_458;
  undefined1 *puStack_454;
  undefined4 uStack_450;
  undefined4 uStack_44c;
  undefined8 uStack_448;
  char *pcStack_428;
  undefined *puStack_424;
  char *pcStack_420;
  undefined *puStack_41c;
  undefined1 *puStack_418;
  undefined1 *puStack_414;
  undefined4 uStack_410;
  undefined4 uStack_40c;
  undefined8 uStack_408;
  char *pcStack_3e8;
  undefined *puStack_3e4;
  char *pcStack_3e0;
  undefined *puStack_3dc;
  undefined1 *puStack_3d8;
  undefined1 *puStack_3d4;
  undefined4 uStack_3d0;
  undefined4 uStack_3cc;
  undefined8 uStack_3c8;
  char *pcStack_3a8;
  undefined *puStack_3a4;
  char *pcStack_3a0;
  undefined *puStack_39c;
  undefined1 *puStack_398;
  undefined1 *puStack_394;
  undefined4 uStack_390;
  undefined4 uStack_38c;
  undefined8 uStack_388;
  char *pcStack_368;
  undefined *puStack_364;
  char *pcStack_360;
  undefined *puStack_35c;
  undefined1 *puStack_358;
  undefined1 *puStack_354;
  undefined4 uStack_350;
  undefined4 uStack_34c;
  undefined8 uStack_348;
  char *pcStack_328;
  undefined *puStack_324;
  char *pcStack_320;
  undefined *puStack_31c;
  undefined1 *puStack_318;
  undefined1 *puStack_314;
  undefined4 uStack_310;
  undefined4 uStack_30c;
  undefined8 uStack_308;
  char *pcStack_2e8;
  undefined *puStack_2e4;
  char *pcStack_2e0;
  undefined *puStack_2dc;
  undefined1 *puStack_2d8;
  undefined1 *puStack_2d4;
  undefined4 uStack_2d0;
  undefined4 uStack_2cc;
  undefined8 uStack_2c8;
  char *pcStack_2a8;
  undefined *puStack_2a4;
  char *pcStack_2a0;
  undefined *puStack_29c;
  undefined1 *puStack_298;
  undefined1 *puStack_294;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined8 uStack_288;
  char *pcStack_268;
  undefined *puStack_264;
  char *pcStack_260;
  undefined *puStack_25c;
  undefined1 *puStack_258;
  undefined1 *puStack_254;
  undefined4 uStack_250;
  undefined4 uStack_24c;
  undefined8 uStack_248;
  undefined auStack_240 [8];
  undefined auStack_238 [16];
  undefined4 uStack_228;
  undefined4 uStack_224;
  undefined auStack_220 [16];
  undefined4 uStack_210;
  undefined4 uStack_20c;
  uint auStack_208 [4];
  undefined4 uStack_1f8;
  uint uStack_1f4;
  uint auStack_1f0 [4];
  undefined4 uStack_1e0;
  uint uStack_1dc;
  uint auStack_1d8 [4];
  undefined4 uStack_1c8;
  uint uStack_1c4;
  uint auStack_1c0 [4];
  undefined4 uStack_1b0;
  uint uStack_1ac;
  uint auStack_1a8 [4];
  undefined4 uStack_198;
  uint uStack_194;
  uint auStack_190 [4];
  undefined4 uStack_180;
  uint uStack_17c;
  uint auStack_178 [4];
  undefined4 uStack_168;
  uint uStack_164;
  uint auStack_160 [4];
  undefined4 uStack_150;
  uint uStack_14c;
  uint auStack_148 [4];
  undefined4 uStack_138;
  uint uStack_134;
  uint auStack_130 [4];
  undefined4 uStack_120;
  uint uStack_11c;
  uint auStack_118 [4];
  undefined4 uStack_108;
  uint uStack_104;
  uint auStack_100 [4];
  undefined4 uStack_f0;
  uint uStack_ec;
  uint auStack_e8 [4];
  undefined4 uStack_d8;
  uint uStack_d4;
  uint auStack_d0 [4];
  undefined4 uStack_c0;
  uint uStack_bc;
  uint auStack_b8 [4];
  undefined4 uStack_a8;
  uint uStack_a4;
  uint auStack_a0 [4];
  undefined4 uStack_90;
  uint uStack_8c;
  uint auStack_88 [4];
  undefined4 uStack_78;
  uint uStack_74;
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  undefined4 uStack_58;
  undefined4 *puStack_54;
  undefined *puStack_40;
  undefined *puStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined *puStack_2c;
  char *pcStack_28;
  undefined *puStack_24;
  char *pcStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184d90e;
  pvStack_10 = ExceptionList;
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("en-us",5);
  puStack_18 = &DAT_019c79f8;
  puStack_14 = &DAT_019c79fc;
  puStack_40 = &DAT_019c79f8;
  puStack_3c = &DAT_019c79fc;
  uStack_8 = 0;
  pcStack_28 = "%d/%d/%d";
  puStack_24 = &DAT_019c79e8;
  pcStack_20 = "%d:%02d";
  puStack_1c = &DAT_019c79f4;
  uStack_38 = 0x2c;
  uStack_34 = 0x2e;
  uStack_30 = 0x2f;
  puStack_2c = &DAT_01f2de78;
  FUN_0054ef60(auStack_70);
  pcStack_728 = pcStack_28;
  puStack_724 = puStack_24;
  pcStack_720 = pcStack_20;
  puStack_71c = puStack_1c;
  puStack_718 = puStack_40;
  puStack_714 = puStack_3c;
  uStack_710 = uStack_38;
  uStack_70c = uStack_34;
  uStack_708 = CONCAT44(puStack_2c,uStack_30);
  uStack_8._0_1_ = 2;
  if (0xf < uStack_5c) {
    uVar4 = uStack_5c + 1;
    uVar3 = auStack_70[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_70[0] - 4);
      uVar4 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  FUN_005542c0("en-gb",5);
  puStack_18 = &DAT_018bc9b8;
  puStack_14 = &DAT_018bc9b8;
  puStack_40 = &DAT_018bc9b8;
  puStack_3c = &DAT_018bc9b8;
  uStack_8._0_1_ = 3;
  pcStack_28 = "%02d/%02d/%d";
  puStack_24 = &DAT_019c7a10;
  pcStack_20 = "%02d:%02d";
  puStack_1c = &DAT_019c7570;
  uStack_38 = 0x2c;
  uStack_34 = 0x2e;
  uStack_30 = 0x2f;
  puStack_2c = &DAT_01f2de78;
  FUN_0054ef60(auStack_88);
  pcStack_6e8 = pcStack_28;
  puStack_6e4 = puStack_24;
  pcStack_6e0 = pcStack_20;
  puStack_6dc = puStack_1c;
  puStack_6d8 = puStack_40;
  puStack_6d4 = puStack_3c;
  uStack_6d0 = uStack_38;
  uStack_6cc = uStack_34;
  uStack_6c8 = CONCAT44(puStack_2c,uStack_30);
  uStack_8._0_1_ = 5;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 5;
  if (0xf < uStack_74) {
    uVar4 = uStack_74 + 1;
    uVar3 = auStack_88[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_88[0] - 4);
      uVar4 = uStack_74 + 0x24;
      if (0x1f < (auStack_88[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  uStack_90 = 0;
  uStack_8c = 0xf;
  auStack_a0[0] = auStack_a0[0] & 0xffffff00;
  FUN_005542c0("en-au",5);
  puStack_18 = &DAT_019c79f8;
  puStack_14 = &DAT_019c79fc;
  puStack_40 = &DAT_019c79f8;
  puStack_3c = &DAT_019c79fc;
  uStack_8._0_1_ = 6;
  pcStack_28 = "%02d/%02d/%d";
  puStack_24 = &DAT_019c7a10;
  pcStack_20 = "%d:%02d";
  puStack_1c = &DAT_019c79f4;
  uStack_38 = 0x2c;
  uStack_34 = 0x2e;
  uStack_30 = 0x2f;
  puStack_2c = &DAT_01f2de78;
  FUN_0054ef60(auStack_a0);
  pcStack_6a8 = pcStack_28;
  puStack_6a4 = puStack_24;
  pcStack_6a0 = pcStack_20;
  puStack_69c = puStack_1c;
  puStack_698 = puStack_40;
  puStack_694 = puStack_3c;
  uStack_690 = uStack_38;
  uStack_68c = uStack_34;
  uStack_688 = CONCAT44(puStack_2c,uStack_30);
  uStack_8._0_1_ = 8;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  if (0xf < uStack_8c) {
    uVar4 = uStack_8c + 1;
    uVar3 = auStack_a0[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_a0[0] - 4);
      uVar4 = uStack_8c + 0x24;
      if (0x1f < (auStack_a0[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_90 = 0;
  uStack_8c = 0xf;
  auStack_a0[0] = auStack_a0[0] & 0xffffff00;
  uStack_a8 = 0;
  uStack_a4 = 0xf;
  auStack_b8[0] = auStack_b8[0] & 0xffffff00;
  FUN_005542c0("en-nz",5);
  puStack_18 = &DAT_019c79f8;
  puStack_14 = &DAT_019c79fc;
  puStack_40 = &DAT_019c79f8;
  puStack_3c = &DAT_019c79fc;
  uStack_8._0_1_ = 9;
  pcStack_28 = "%02d/%02d/%d";
  puStack_24 = &DAT_019c7a10;
  pcStack_20 = "%d:%02d";
  puStack_1c = &DAT_019c79f4;
  uStack_38 = 0x2c;
  uStack_34 = 0x2e;
  uStack_30 = 0x2f;
  puStack_2c = &DAT_01f2de78;
  FUN_0054ef60(auStack_b8);
  pcStack_668 = pcStack_28;
  puStack_664 = puStack_24;
  pcStack_660 = pcStack_20;
  puStack_65c = puStack_1c;
  puStack_658 = puStack_40;
  puStack_654 = puStack_3c;
  uStack_650 = uStack_38;
  uStack_64c = uStack_34;
  uStack_648 = CONCAT44(puStack_2c,uStack_30);
  uStack_8._0_1_ = 0xb;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xb;
  if (0xf < uStack_a4) {
    uVar4 = uStack_a4 + 1;
    uVar3 = auStack_b8[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_b8[0] - 4);
      uVar4 = uStack_a4 + 0x24;
      if (0x1f < (auStack_b8[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_a8 = 0;
  uStack_a4 = 0xf;
  auStack_b8[0] = auStack_b8[0] & 0xffffff00;
  uStack_c0 = 0;
  uStack_bc = 0xf;
  auStack_d0[0] = auStack_d0[0] & 0xffffff00;
  FUN_005542c0("en-ca",5);
  puStack_18 = &DAT_019c79f8;
  puStack_14 = &DAT_019c79fc;
  puStack_40 = &DAT_019c79f8;
  puStack_3c = &DAT_019c79fc;
  uStack_8._0_1_ = 0xc;
  pcStack_28 = "%d-%02d-%02d";
  puStack_24 = &DAT_019c7560;
  pcStack_20 = "%d:%02d";
  puStack_1c = &DAT_019c79f4;
  uStack_38 = 0x2c;
  uStack_34 = 0x2e;
  uStack_30 = 0x2d;
  puStack_2c = &DAT_01f2de78;
  FUN_0054ef60(auStack_d0);
  pcStack_628 = pcStack_28;
  puStack_624 = puStack_24;
  pcStack_620 = pcStack_20;
  puStack_61c = puStack_1c;
  puStack_618 = puStack_40;
  puStack_614 = puStack_3c;
  uStack_610 = uStack_38;
  uStack_60c = uStack_34;
  uStack_608 = CONCAT44(puStack_2c,uStack_30);
  uStack_8._0_1_ = 0xe;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xe;
  if (0xf < uStack_bc) {
    uVar4 = uStack_bc + 1;
    uVar3 = auStack_d0[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_d0[0] - 4);
      uVar4 = uStack_bc + 0x24;
      if (0x1f < (auStack_d0[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_c0 = 0;
  uStack_bc = 0xf;
  auStack_d0[0] = auStack_d0[0] & 0xffffff00;
  uStack_d8 = 0;
  uStack_d4 = 0xf;
  auStack_e8[0] = auStack_e8[0] & 0xffffff00;
  FUN_005542c0("de-de",5);
  puStack_18 = &DAT_018bc9b8;
  puStack_14 = &DAT_018bc9b8;
  puStack_40 = &DAT_018bc9b8;
  puStack_3c = &DAT_018bc9b8;
  uStack_8._0_1_ = 0xf;
  pcStack_28 = "%02d.%02d.%d";
  puStack_24 = &DAT_019c7a10;
  pcStack_20 = "%02d:%02d";
  puStack_1c = &DAT_019c7570;
  uStack_38 = 0x2e;
  uStack_34 = 0x2c;
  uStack_30 = 0x2e;
  puStack_2c = &DAT_01f2de80;
  FUN_0054ef60(auStack_e8);
  pcStack_5e8 = pcStack_28;
  puStack_5e4 = puStack_24;
  pcStack_5e0 = pcStack_20;
  puStack_5dc = puStack_1c;
  puStack_5d8 = puStack_40;
  puStack_5d4 = puStack_3c;
  uStack_5d0 = uStack_38;
  uStack_5cc = uStack_34;
  uStack_5c8 = CONCAT44(puStack_2c,uStack_30);
  uStack_8._0_1_ = 0x11;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x11;
  if (0xf < uStack_d4) {
    uVar4 = uStack_d4 + 1;
    uVar3 = auStack_e8[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_e8[0] - 4);
      uVar4 = uStack_d4 + 0x24;
      if (0x1f < (auStack_e8[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_d8 = 0;
  uStack_d4 = 0xf;
  auStack_e8[0] = auStack_e8[0] & 0xffffff00;
  uStack_f0 = 0;
  uStack_ec = 0xf;
  auStack_100[0] = auStack_100[0] & 0xffffff00;
  FUN_005542c0("es-es",5);
  puStack_18 = &DAT_018bc9b8;
  puStack_14 = &DAT_018bc9b8;
  puStack_40 = &DAT_018bc9b8;
  puStack_3c = &DAT_018bc9b8;
  uStack_8._0_1_ = 0x12;
  pcStack_28 = "%02d/%02d/%d";
  puStack_24 = &DAT_019c7a10;
  pcStack_20 = "%02d:%02d";
  puStack_1c = &DAT_019c7570;
  uStack_38 = 0x2e;
  uStack_34 = 0x2c;
  uStack_30 = 0x2f;
  puStack_2c = &DAT_01f2de80;
  FUN_0054ef60(auStack_100);
  pcStack_5a8 = pcStack_28;
  puStack_5a4 = puStack_24;
  pcStack_5a0 = pcStack_20;
  puStack_59c = puStack_1c;
  puStack_598 = puStack_40;
  puStack_594 = puStack_3c;
  uStack_590 = uStack_38;
  uStack_58c = uStack_34;
  uStack_588 = CONCAT44(puStack_2c,uStack_30);
  uStack_8._0_1_ = 0x14;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x14;
  if (0xf < uStack_ec) {
    uVar4 = uStack_ec + 1;
    uVar3 = auStack_100[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_100[0] - 4);
      uVar4 = uStack_ec + 0x24;
      if (0x1f < (auStack_100[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_f0 = 0;
  uStack_ec = 0xf;
  auStack_100[0] = auStack_100[0] & 0xffffff00;
  uStack_108 = 0;
  uStack_104 = 0xf;
  auStack_118[0] = auStack_118[0] & 0xffffff00;
  FUN_005542c0("es-mx",5);
  puStack_18 = &DAT_019c79f8;
  puStack_14 = &DAT_019c79fc;
  puStack_40 = &DAT_019c79f8;
  puStack_3c = &DAT_019c79fc;
  uStack_8._0_1_ = 0x15;
  pcStack_28 = "%02d/%02d/%d";
  puStack_24 = &DAT_019c7a10;
  pcStack_20 = "%d:%02d";
  puStack_1c = &DAT_019c79f4;
  uStack_38 = 0x2c;
  uStack_34 = 0x2e;
  uStack_30 = 0x2f;
  puStack_2c = &DAT_01f2de78;
  FUN_0054ef60(auStack_118);
  pcStack_568 = pcStack_28;
  puStack_564 = puStack_24;
  pcStack_560 = pcStack_20;
  puStack_55c = puStack_1c;
  puStack_558 = puStack_40;
  puStack_554 = puStack_3c;
  uStack_550 = uStack_38;
  uStack_54c = uStack_34;
  uStack_548 = CONCAT44(puStack_2c,uStack_30);
  uStack_8._0_1_ = 0x17;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x17;
  if (0xf < uStack_104) {
    uVar4 = uStack_104 + 1;
    uVar3 = auStack_118[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_118[0] - 4);
      uVar4 = uStack_104 + 0x24;
      if (0x1f < (auStack_118[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_108 = 0;
  uStack_104 = 0xf;
  auStack_118[0] = auStack_118[0] & 0xffffff00;
  uStack_120 = 0;
  uStack_11c = 0xf;
  auStack_130[0] = auStack_130[0] & 0xffffff00;
  FUN_005542c0("fr-fr",5);
  puStack_18 = &DAT_018bc9b8;
  puStack_14 = &DAT_018bc9b8;
  puStack_40 = &DAT_018bc9b8;
  puStack_3c = &DAT_018bc9b8;
  uStack_8._0_1_ = 0x18;
  pcStack_28 = "%02d/%02d/%d";
  puStack_24 = &DAT_019c7a10;
  pcStack_20 = "%02d:%02d";
  puStack_1c = &DAT_019c7570;
  uStack_38 = 0xa0;
  uStack_34 = 0x2c;
  uStack_30 = 0x2f;
  puStack_2c = &DAT_01f2de88;
  FUN_0054ef60(auStack_130);
  pcStack_528 = pcStack_28;
  puStack_524 = puStack_24;
  pcStack_520 = pcStack_20;
  puStack_51c = puStack_1c;
  puStack_518 = puStack_40;
  puStack_514 = puStack_3c;
  uStack_510 = uStack_38;
  uStack_50c = uStack_34;
  uStack_508 = CONCAT44(puStack_2c,uStack_30);
  uStack_8._0_1_ = 0x1a;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x1a;
  if (0xf < uStack_11c) {
    uVar4 = uStack_11c + 1;
    uVar3 = auStack_130[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_130[0] - 4);
      uVar4 = uStack_11c + 0x24;
      if (0x1f < (auStack_130[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_120 = 0;
  uStack_11c = 0xf;
  auStack_130[0] = auStack_130[0] & 0xffffff00;
  uStack_138 = 0;
  uStack_134 = 0xf;
  auStack_148[0] = auStack_148[0] & 0xffffff00;
  FUN_005542c0("fr-ca",5);
  puStack_18 = &DAT_018bc9b8;
  puStack_14 = &DAT_018bc9b8;
  puStack_40 = &DAT_018bc9b8;
  puStack_3c = &DAT_018bc9b8;
  uStack_8._0_1_ = 0x1b;
  pcStack_28 = "%d-%02d-%02d";
  puStack_24 = &DAT_019c7560;
  pcStack_20 = "%02d:%02d";
  puStack_1c = &DAT_019c7570;
  uStack_38 = 0xa0;
  uStack_34 = 0x2c;
  uStack_30 = 0x2d;
  puStack_2c = &DAT_01f2de88;
  FUN_0054ef60(auStack_148);
  pcStack_4e8 = pcStack_28;
  puStack_4e4 = puStack_24;
  pcStack_4e0 = pcStack_20;
  puStack_4dc = puStack_1c;
  puStack_4d8 = puStack_40;
  puStack_4d4 = puStack_3c;
  uStack_4d0 = uStack_38;
  uStack_4cc = uStack_34;
  uStack_4c8 = CONCAT44(puStack_2c,uStack_30);
  uStack_8._0_1_ = 0x1d;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x1d;
  if (0xf < uStack_134) {
    uVar4 = uStack_134 + 1;
    uVar3 = auStack_148[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_148[0] - 4);
      uVar4 = uStack_134 + 0x24;
      if (0x1f < (auStack_148[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_138 = 0;
  uStack_134 = 0xf;
  auStack_148[0] = auStack_148[0] & 0xffffff00;
  uStack_150 = 0;
  uStack_14c = 0xf;
  auStack_160[0] = auStack_160[0] & 0xffffff00;
  FUN_005542c0("it-it",5);
  puStack_18 = &DAT_018bc9b8;
  puStack_14 = &DAT_018bc9b8;
  puStack_40 = &DAT_018bc9b8;
  puStack_3c = &DAT_018bc9b8;
  uStack_8._0_1_ = 0x1e;
  pcStack_28 = "%02d/%02d/%d";
  puStack_24 = &DAT_019c7a10;
  pcStack_20 = "%02d:%02d";
  puStack_1c = &DAT_019c7570;
  uStack_38 = 0x2e;
  uStack_34 = 0x2c;
  uStack_30 = 0x2f;
  puStack_2c = &DAT_01f2de80;
  FUN_0054ef60(auStack_160);
  pcStack_4a8 = pcStack_28;
  puStack_4a4 = puStack_24;
  pcStack_4a0 = pcStack_20;
  puStack_49c = puStack_1c;
  puStack_498 = puStack_40;
  puStack_494 = puStack_3c;
  uStack_490 = uStack_38;
  uStack_48c = uStack_34;
  uStack_488 = CONCAT44(puStack_2c,uStack_30);
  uStack_8._0_1_ = 0x20;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x20;
  if (0xf < uStack_14c) {
    uVar4 = uStack_14c + 1;
    uVar3 = auStack_160[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_160[0] - 4);
      uVar4 = uStack_14c + 0x24;
      if (0x1f < (auStack_160[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_150 = 0;
  uStack_14c = 0xf;
  auStack_160[0] = auStack_160[0] & 0xffffff00;
  uStack_168 = 0;
  uStack_164 = 0xf;
  auStack_178[0] = auStack_178[0] & 0xffffff00;
  FUN_005542c0("pt-pt",5);
  puStack_18 = &DAT_018bc9b8;
  puStack_14 = &DAT_018bc9b8;
  puStack_40 = &DAT_018bc9b8;
  puStack_3c = &DAT_018bc9b8;
  uStack_8._0_1_ = 0x21;
  pcStack_28 = "%02d/%02d/%d";
  puStack_24 = &DAT_019c7a10;
  pcStack_20 = "%02d:%02d";
  puStack_1c = &DAT_019c7570;
  uStack_38 = 0xa0;
  uStack_34 = 0x2c;
  uStack_30 = 0x2f;
  puStack_2c = &DAT_01f2de88;
  FUN_0054ef60(auStack_178);
  pcStack_468 = pcStack_28;
  puStack_464 = puStack_24;
  pcStack_460 = pcStack_20;
  puStack_45c = puStack_1c;
  puStack_458 = puStack_40;
  puStack_454 = puStack_3c;
  uStack_450 = uStack_38;
  uStack_44c = uStack_34;
  uStack_448 = CONCAT44(puStack_2c,uStack_30);
  uStack_8._0_1_ = 0x23;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x23;
  if (0xf < uStack_164) {
    uVar4 = uStack_164 + 1;
    uVar3 = auStack_178[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_178[0] - 4);
      uVar4 = uStack_164 + 0x24;
      if (0x1f < (auStack_178[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_168 = 0;
  uStack_164 = 0xf;
  auStack_178[0] = auStack_178[0] & 0xffffff00;
  uStack_180 = 0;
  uStack_17c = 0xf;
  auStack_190[0] = auStack_190[0] & 0xffffff00;
  FUN_005542c0("pt-br",5);
  puStack_18 = &DAT_018bc9b8;
  puStack_14 = &DAT_018bc9b8;
  puStack_40 = &DAT_018bc9b8;
  puStack_3c = &DAT_018bc9b8;
  uStack_8._0_1_ = 0x24;
  pcStack_28 = "%02d/%02d/%d";
  puStack_24 = &DAT_019c7a10;
  pcStack_20 = "%02d:%02d";
  puStack_1c = &DAT_019c7570;
  uStack_38 = 0x2e;
  uStack_34 = 0x2c;
  uStack_30 = 0x2f;
  puStack_2c = &DAT_01f2de80;
  FUN_0054ef60(auStack_190);
  pcStack_428 = pcStack_28;
  puStack_424 = puStack_24;
  pcStack_420 = pcStack_20;
  puStack_41c = puStack_1c;
  puStack_418 = puStack_40;
  puStack_414 = puStack_3c;
  uStack_410 = uStack_38;
  uStack_40c = uStack_34;
  uStack_408 = CONCAT44(puStack_2c,uStack_30);
  uStack_8._0_1_ = 0x26;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x26;
  if (0xf < uStack_17c) {
    uVar4 = uStack_17c + 1;
    uVar3 = auStack_190[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_190[0] - 4);
      uVar4 = uStack_17c + 0x24;
      if (0x1f < (auStack_190[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_180 = 0;
  uStack_17c = 0xf;
  auStack_190[0] = auStack_190[0] & 0xffffff00;
  uStack_198 = 0;
  uStack_194 = 0xf;
  auStack_1a8[0] = auStack_1a8[0] & 0xffffff00;
  FUN_005542c0("ru-ru",5);
  puStack_18 = &DAT_018bc9b8;
  puStack_14 = &DAT_018bc9b8;
  puStack_40 = &DAT_018bc9b8;
  puStack_3c = &DAT_018bc9b8;
  uStack_8._0_1_ = 0x27;
  pcStack_28 = "%02d.%02d.%d";
  puStack_24 = &DAT_019c7a10;
  pcStack_20 = "%02d:%02d";
  puStack_1c = &DAT_019c7570;
  uStack_38 = 0xa0;
  uStack_34 = 0x2c;
  uStack_30 = 0x2e;
  puStack_2c = &DAT_01f2de88;
  FUN_0054ef60(auStack_1a8);
  pcStack_3e8 = pcStack_28;
  puStack_3e4 = puStack_24;
  pcStack_3e0 = pcStack_20;
  puStack_3dc = puStack_1c;
  puStack_3d8 = puStack_40;
  puStack_3d4 = puStack_3c;
  uStack_3d0 = uStack_38;
  uStack_3cc = uStack_34;
  uStack_3c8 = CONCAT44(puStack_2c,uStack_30);
  uStack_8._0_1_ = 0x29;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x29;
  if (0xf < uStack_194) {
    uVar4 = uStack_194 + 1;
    uVar3 = auStack_1a8[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_1a8[0] - 4);
      uVar4 = uStack_194 + 0x24;
      if (0x1f < (auStack_1a8[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_198 = 0;
  uStack_194 = 0xf;
  auStack_1a8[0] = auStack_1a8[0] & 0xffffff00;
  uStack_1b0 = 0;
  uStack_1ac = 0xf;
  auStack_1c0[0] = auStack_1c0[0] & 0xffffff00;
  FUN_005542c0("ja-jp",5);
  puStack_18 = &DAT_018bc9b8;
  puStack_14 = &DAT_018bc9b8;
  puStack_40 = &DAT_018bc9b8;
  puStack_3c = &DAT_018bc9b8;
  uStack_8._0_1_ = 0x2a;
  pcStack_28 = "%d/%02d/%02d";
  puStack_24 = &DAT_019c7560;
  pcStack_20 = "%02d:%02d";
  puStack_1c = &DAT_019c7570;
  uStack_38 = 0x2c;
  uStack_34 = 0x2e;
  uStack_30 = 0x2f;
  puStack_2c = &DAT_01f2de78;
  FUN_0054ef60(auStack_1c0);
  pcStack_3a8 = pcStack_28;
  puStack_3a4 = puStack_24;
  pcStack_3a0 = pcStack_20;
  puStack_39c = puStack_1c;
  puStack_398 = puStack_40;
  puStack_394 = puStack_3c;
  uStack_390 = uStack_38;
  uStack_38c = uStack_34;
  uStack_388 = CONCAT44(puStack_2c,uStack_30);
  uStack_8._0_1_ = 0x2c;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x2c;
  if (0xf < uStack_1ac) {
    uVar4 = uStack_1ac + 1;
    uVar3 = auStack_1c0[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_1c0[0] - 4);
      uVar4 = uStack_1ac + 0x24;
      if (0x1f < (auStack_1c0[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_1b0 = 0;
  uStack_1ac = 0xf;
  auStack_1c0[0] = auStack_1c0[0] & 0xffffff00;
  uStack_1c8 = 0;
  uStack_1c4 = 0xf;
  auStack_1d8[0] = auStack_1d8[0] & 0xffffff00;
  FUN_005542c0("ko-kr",5);
  puStack_18 = &DAT_018bc9b8;
  puStack_14 = &DAT_018bc9b8;
  puStack_40 = &DAT_018bc9b8;
  puStack_3c = &DAT_018bc9b8;
  uStack_8._0_1_ = 0x2d;
  pcStack_28 = "%d-%02d-%02d";
  puStack_24 = &DAT_019c7560;
  pcStack_20 = "%02d:%02d";
  puStack_1c = &DAT_019c7570;
  uStack_38 = 0x2c;
  uStack_34 = 0x2e;
  uStack_30 = 0x2d;
  puStack_2c = &DAT_01f2de78;
  FUN_0054ef60(auStack_1d8);
  pcStack_368 = pcStack_28;
  puStack_364 = puStack_24;
  pcStack_360 = pcStack_20;
  puStack_35c = puStack_1c;
  puStack_358 = puStack_40;
  puStack_354 = puStack_3c;
  uStack_350 = uStack_38;
  uStack_34c = uStack_34;
  uStack_348 = CONCAT44(puStack_2c,uStack_30);
  uStack_8._0_1_ = 0x2f;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x2f;
  if (0xf < uStack_1c4) {
    uVar4 = uStack_1c4 + 1;
    uVar3 = auStack_1d8[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_1d8[0] - 4);
      uVar4 = uStack_1c4 + 0x24;
      if (0x1f < (auStack_1d8[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_1c8 = 0;
  uStack_1c4 = 0xf;
  auStack_1d8[0] = auStack_1d8[0] & 0xffffff00;
  uStack_1e0 = 0;
  uStack_1dc = 0xf;
  auStack_1f0[0] = auStack_1f0[0] & 0xffffff00;
  FUN_005542c0("zh-cn",5);
  puStack_18 = &DAT_018bc9b8;
  puStack_14 = &DAT_018bc9b8;
  puStack_40 = &DAT_018bc9b8;
  puStack_3c = &DAT_018bc9b8;
  uStack_8._0_1_ = 0x30;
  pcStack_28 = "%d/%d/%d";
  puStack_24 = &DAT_019c7560;
  pcStack_20 = "%02d:%02d";
  puStack_1c = &DAT_019c7570;
  uStack_38 = 0x2c;
  uStack_34 = 0x2e;
  uStack_30 = 0x2f;
  puStack_2c = &DAT_01f2de78;
  FUN_0054ef60(auStack_1f0);
  pcStack_328 = pcStack_28;
  puStack_324 = puStack_24;
  pcStack_320 = pcStack_20;
  puStack_31c = puStack_1c;
  puStack_318 = puStack_40;
  puStack_314 = puStack_3c;
  uStack_310 = uStack_38;
  uStack_30c = uStack_34;
  uStack_308 = CONCAT44(puStack_2c,uStack_30);
  uStack_8._0_1_ = 0x32;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x32;
  if (0xf < uStack_1dc) {
    uVar4 = uStack_1dc + 1;
    uVar3 = auStack_1f0[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_1f0[0] - 4);
      uVar4 = uStack_1dc + 0x24;
      if (0x1f < (auStack_1f0[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_1e0 = 0;
  uStack_1dc = 0xf;
  auStack_1f0[0] = auStack_1f0[0] & 0xffffff00;
  uStack_1f8 = 0;
  uStack_1f4 = 0xf;
  auStack_208[0] = auStack_208[0] & 0xffffff00;
  FUN_005542c0("zh-sg",5);
  puStack_18 = &DAT_018bc9b8;
  puStack_14 = &DAT_018bc9b8;
  puStack_40 = &DAT_018bc9b8;
  puStack_3c = &DAT_018bc9b8;
  uStack_8._0_1_ = 0x33;
  pcStack_28 = "%d/%d/%02d";
  puStack_24 = &DAT_019c7a10;
  pcStack_20 = "%02d:%02d";
  puStack_1c = &DAT_019c7570;
  uStack_38 = 0x2c;
  uStack_34 = 0x2e;
  uStack_30 = 0x2f;
  puStack_2c = &DAT_01f2de78;
  FUN_0054ef60(auStack_208);
  pcStack_2e8 = pcStack_28;
  puStack_2e4 = puStack_24;
  pcStack_2e0 = pcStack_20;
  puStack_2dc = puStack_1c;
  puStack_2d8 = puStack_40;
  puStack_2d4 = puStack_3c;
  uStack_2d0 = uStack_38;
  uStack_2cc = uStack_34;
  uStack_2c8 = CONCAT44(puStack_2c,uStack_30);
  uStack_8._0_1_ = 0x35;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x35;
  if (0xf < uStack_1f4) {
    uVar4 = uStack_1f4 + 1;
    uVar3 = auStack_208[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_208[0] - 4);
      uVar4 = uStack_1f4 + 0x24;
      if (0x1f < (auStack_208[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_1f8 = 0;
  uStack_1f4 = 0xf;
  auStack_208[0] = auStack_208[0] & 0xffffff00;
  uStack_210 = 0;
  uStack_20c = 0xf;
  auStack_220[0] = 0;
  FUN_005542c0("zh-hk",5);
  puStack_18 = &DAT_018bc9b8;
  puStack_14 = &DAT_018bc9b8;
  puStack_40 = &DAT_018bc9b8;
  puStack_3c = &DAT_018bc9b8;
  uStack_8._0_1_ = 0x36;
  pcStack_28 = "%d/%d/%02d";
  puStack_24 = &DAT_019c7a10;
  pcStack_20 = "%02d:%02d";
  puStack_1c = &DAT_019c7570;
  uStack_38 = 0x2c;
  uStack_34 = 0x2e;
  uStack_30 = 0x2f;
  puStack_2c = &DAT_01f2de78;
  FUN_0054ef60(auStack_220);
  pcStack_2a8 = pcStack_28;
  puStack_2a4 = puStack_24;
  pcStack_2a0 = pcStack_20;
  puStack_29c = puStack_1c;
  puStack_298 = puStack_40;
  puStack_294 = puStack_3c;
  uStack_290 = uStack_38;
  uStack_28c = uStack_34;
  uStack_288 = CONCAT44(puStack_2c,uStack_30);
  uStack_8._0_1_ = 0x38;
  FUN_005507b0();
  uStack_228 = 0;
  uStack_224 = 0xf;
  auStack_238[0] = 0;
  FUN_005542c0("zh-tw",5);
  puStack_18 = &DAT_018bc9b8;
  puStack_14 = &DAT_018bc9b8;
  puStack_40 = &DAT_018bc9b8;
  puStack_3c = &DAT_018bc9b8;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x39);
  pcStack_28 = "%d/%d/%d";
  puStack_24 = &DAT_019c7560;
  pcStack_20 = "%02d:%02d";
  puStack_1c = &DAT_019c7570;
  uStack_38 = 0x2c;
  uStack_34 = 0x2e;
  uStack_30 = 0x2f;
  puStack_2c = &DAT_01f2de78;
  FUN_0054ef60(auStack_238);
  pcStack_268 = pcStack_28;
  puStack_264 = puStack_24;
  pcStack_260 = pcStack_20;
  puStack_25c = puStack_1c;
  puStack_258 = puStack_40;
  puStack_254 = puStack_3c;
  uStack_250 = uStack_38;
  uStack_24c = uStack_34;
  uStack_248 = CONCAT44(puStack_2c,uStack_30);
  FUN_005507b0();
  uStack_8 = 0x3a;
  _DAT_01f2de90 = 0;
  DAT_01f2de94 = (int *)0x0;
  DAT_01f2de98 = 0;
  DAT_01f2de94 = (int *)FUN_00fc2a30(0,0);
  _DAT_01f2de9c = 0;
  _DAT_01f2dea0 = 0;
  _DAT_01f2dea4 = 0;
  uStack_8._0_1_ = 0x3c;
  _DAT_01f2de90 = 0x3f800000;
  FUN_005cb500(8);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x3d);
  puVar5 = auStack_740;
  do {
    iVar1 = *DAT_01f2de94;
    puStack_54 = *(undefined4 **)(iVar1 + 4);
    uStack_58 = FUN_00fbffe0(iVar1,puStack_54,puVar5);
    if (DAT_01f2de98 == 0x38e38e2) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    DAT_01f2de98 = DAT_01f2de98 + 1;
    *(undefined4 *)(iVar1 + 4) = uStack_58;
    *puStack_54 = uStack_58;
    FUN_00fc0980(auStack_240,*DAT_01f2de94 + 8,*DAT_01f2de94);
    puVar5 = puVar5 + 0x40;
  } while (puVar5 != auStack_240);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(auStack_740,0x40,0x14,FUN_005507b0);
  FUN_016f3654(&LAB_018aabd0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2312 ; VA 0x0053af80 ; FUN_0053af80 */

void FUN_0053af80(void)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined auStack_138 [8];
  undefined auStack_130 [16];
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined uStack_114;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined uStack_f8;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined uStack_dc;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined uStack_c0;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined uStack_a4;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined uStack_88;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined uStack_6c;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined uStack_50;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined uStack_34;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184d99d;
  pvStack_10 = ExceptionList;
  uStack_120 = 0;
  uStack_11c = 0xf;
  auStack_130[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018d3ef8,2);
  uStack_118 = 0;
  uStack_8 = 0;
  uStack_104 = 0;
  uStack_100 = 0xf;
  uStack_114 = 0;
  FUN_005542c0(&DAT_019c80ac,2);
  uStack_fc = 0;
  uStack_8._0_1_ = 1;
  uStack_e8 = 0;
  uStack_e4 = 0xf;
  uStack_f8 = 0;
  FUN_005542c0(&DAT_019c80b0,4);
  uStack_e0 = 0;
  uStack_8._0_1_ = 2;
  uStack_cc = 0;
  uStack_c8 = 0xf;
  uStack_dc = 0;
  FUN_005542c0(&DAT_019c80b8,4);
  uStack_c4 = 0;
  uStack_8._0_1_ = 3;
  uStack_b0 = 0;
  uStack_ac = 0xf;
  uStack_c0 = 0;
  FUN_005542c0(&DAT_019c80c0,3);
  uStack_a8 = 0;
  uStack_8._0_1_ = 4;
  uStack_94 = 0;
  uStack_90 = 0xf;
  uStack_a4 = 0;
  FUN_005542c0(&DAT_019c80c4,2);
  uStack_8c = 0xc;
  uStack_8._0_1_ = 5;
  uStack_78 = 0;
  uStack_74 = 0xf;
  uStack_88 = 0;
  FUN_005542c0(&DAT_019c80c8,2);
  uStack_70 = 0xc;
  uStack_8._0_1_ = 6;
  uStack_5c = 0;
  uStack_58 = 0xf;
  uStack_6c = 0;
  FUN_005542c0(&DAT_019c80cc,4);
  uStack_54 = 0xc;
  uStack_8._0_1_ = 7;
  uStack_40 = 0;
  uStack_3c = 0xf;
  uStack_50 = 0;
  FUN_005542c0(&DAT_019c80d4,4);
  uStack_38 = 0xc;
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = 0;
  FUN_005542c0(&DAT_019c80dc,3);
  uStack_1c = 0xc;
  uStack_8 = 9;
  uStack_18 = 0;
  FUN_00fc1700(&uStack_18,&uStack_11);
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  puVar4 = (undefined4 *)auStack_130;
  do {
    iVar1 = *DAT_01f2df14;
    puVar2 = *(undefined4 **)(iVar1 + 4);
    uVar3 = FUN_00b35080(iVar1,puVar2,puVar4);
    if (DAT_01f2df18 == 0x71c71c6) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    DAT_01f2df18 = DAT_01f2df18 + 1;
    *(undefined4 *)(iVar1 + 4) = uVar3;
    *puVar2 = uVar3;
    FUN_00b35560(auStack_138,*DAT_01f2df14 + 8,*DAT_01f2df14);
    puVar4 = puVar4 + 7;
  } while (puVar4 != &uStack_18);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(auStack_130,0x1c,10,FUN_005507b0);
  FUN_016f3654(&LAB_018aabe0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2313 ; VA 0x0053b290 ; FUN_0053b290 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0053b290(void)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  void **ppvVar4;
  undefined auStack_168 [8];
  undefined auStack_160 [16];
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined uStack_144;
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined uStack_128;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined uStack_10c;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined uStack_f0;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined uStack_d4;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined uStack_b8;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined uStack_9c;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined uStack_80;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined uStack_64;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined uStack_48;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined uStack_2c;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184da54;
  pvStack_10 = ExceptionList;
  uStack_150 = 0;
  uStack_14c = 0xf;
  auStack_160[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_0191cd9c,3);
  uStack_148 = 1;
  uStack_8 = 0;
  uStack_134 = 0;
  uStack_130 = 0xf;
  uStack_144 = 0;
  FUN_005542c0("fixed",5);
  uStack_12c = 2;
  uStack_8._0_1_ = 1;
  uStack_118 = 0;
  uStack_114 = 0xf;
  uStack_128 = 0;
  FUN_005542c0(&DAT_018d4b24,3);
  uStack_110 = 7;
  uStack_8._0_1_ = 2;
  uStack_fc = 0;
  uStack_f8 = 0xf;
  uStack_10c = 0;
  FUN_005542c0(&DAT_019c75fc,3);
  uStack_f4 = 3;
  uStack_8._0_1_ = 3;
  uStack_e0 = 0;
  uStack_dc = 0xf;
  uStack_f0 = 0;
  FUN_005542c0(&DAT_019c7600,3);
  uStack_d8 = 4;
  uStack_8._0_1_ = 4;
  uStack_c4 = 0;
  uStack_c0 = 0xf;
  uStack_d4 = 0;
  FUN_005542c0("datetime",8);
  uStack_bc = 5;
  uStack_8._0_1_ = 5;
  uStack_a8 = 0;
  uStack_a4 = 0xf;
  uStack_b8 = 0;
  FUN_005542c0("iso8601",7);
  uStack_a0 = 6;
  uStack_8._0_1_ = 6;
  uStack_8c = 0;
  uStack_88 = 0xf;
  uStack_9c = 0;
  FUN_005542c0("shortdate",9);
  uStack_84 = 8;
  uStack_8._0_1_ = 7;
  uStack_70 = 0;
  uStack_6c = 0xf;
  uStack_80 = 0;
  FUN_005542c0("shorttime",9);
  uStack_68 = 9;
  uStack_8._0_1_ = 8;
  uStack_54 = 0;
  uStack_50 = 0xf;
  uStack_64 = 0;
  FUN_005542c0("shortdatetime",0xd);
  uStack_4c = 10;
  uStack_8._0_1_ = 9;
  uStack_38 = 0;
  uStack_34 = 0xf;
  uStack_48 = 0;
  FUN_005542c0("translate",9);
  uStack_30 = 0xb;
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  uStack_1c = 0;
  uStack_18 = 0xf;
  uStack_2c = 0;
  FUN_005542c0("username",8);
  uStack_14 = 0xc;
  uStack_8 = 0xb;
  _DAT_01f2de10 = 0;
  DAT_01f2de14 = (int *)0x0;
  DAT_01f2de18 = 0;
  DAT_01f2de14 = (int *)FUN_00616d10(0,0);
  _DAT_01f2de1c = 0;
  _DAT_01f2de20 = 0;
  _DAT_01f2de24 = 0;
  uStack_8._0_1_ = 0xd;
  _DAT_01f2de10 = 0x3f800000;
  FUN_005cb500(8);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  ppvVar4 = (void **)auStack_160;
  do {
    iVar1 = *DAT_01f2de14;
    puVar2 = *(undefined4 **)(iVar1 + 4);
    uVar3 = FUN_00b35080(iVar1,puVar2,ppvVar4);
    if (DAT_01f2de18 == 0x71c71c6) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    DAT_01f2de18 = DAT_01f2de18 + 1;
    *(undefined4 *)(iVar1 + 4) = uVar3;
    *puVar2 = uVar3;
    FUN_00a12710(auStack_168,*DAT_01f2de14 + 8,*DAT_01f2de14);
    ppvVar4 = ppvVar4 + 7;
  } while (ppvVar4 != &pvStack_10);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(auStack_160,0x1c,0xc,FUN_005507b0);
  FUN_016f3654(&LAB_018aabf0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2314 ; VA 0x0053b8b0 ; FUN_0053b8b0 */

void FUN_0053b8b0(void)

{
  undefined uVar1;
  uint uVar2;
  uint uVar3;
  undefined auStack_83c [540];
  undefined auStack_620 [16];
  undefined4 uStack_610;
  undefined4 uStack_60c;
  undefined uStack_608;
  undefined4 uStack_5f8;
  undefined4 uStack_5f4;
  undefined uStack_5f0;
  undefined4 uStack_5e0;
  undefined4 uStack_5dc;
  undefined uStack_5d8;
  undefined4 uStack_5c8;
  undefined4 uStack_5c4;
  undefined auStack_5c0 [16];
  undefined4 uStack_5b0;
  undefined4 uStack_5ac;
  undefined uStack_5a8;
  undefined4 uStack_598;
  undefined4 uStack_594;
  undefined uStack_590;
  undefined4 uStack_580;
  undefined4 uStack_57c;
  undefined uStack_578;
  undefined4 uStack_568;
  undefined4 uStack_564;
  undefined auStack_560 [16];
  undefined4 uStack_550;
  undefined4 uStack_54c;
  undefined uStack_548;
  undefined4 uStack_538;
  undefined4 uStack_534;
  undefined uStack_530;
  undefined4 uStack_520;
  undefined4 uStack_51c;
  undefined uStack_518;
  undefined4 uStack_508;
  undefined4 uStack_504;
  undefined auStack_500 [16];
  undefined4 uStack_4f0;
  undefined4 uStack_4ec;
  undefined uStack_4e8;
  undefined4 uStack_4d8;
  undefined4 uStack_4d4;
  undefined uStack_4d0;
  undefined4 uStack_4c0;
  undefined4 uStack_4bc;
  undefined uStack_4b8;
  undefined4 uStack_4a8;
  undefined4 uStack_4a4;
  undefined auStack_4a0 [16];
  undefined4 uStack_490;
  undefined4 uStack_48c;
  undefined uStack_488;
  undefined4 uStack_478;
  undefined4 uStack_474;
  undefined uStack_470;
  undefined4 uStack_460;
  undefined4 uStack_45c;
  undefined uStack_458;
  undefined4 uStack_448;
  undefined4 uStack_444;
  undefined auStack_440 [16];
  undefined4 uStack_430;
  undefined4 uStack_42c;
  undefined uStack_428;
  undefined4 uStack_418;
  undefined4 uStack_414;
  undefined uStack_410;
  undefined4 uStack_400;
  undefined4 uStack_3fc;
  undefined uStack_3f8;
  undefined4 uStack_3e8;
  undefined4 uStack_3e4;
  undefined auStack_3e0 [16];
  undefined4 uStack_3d0;
  undefined4 uStack_3cc;
  undefined uStack_3c8;
  undefined4 uStack_3b8;
  undefined4 uStack_3b4;
  undefined uStack_3b0;
  undefined4 uStack_3a0;
  undefined4 uStack_39c;
  undefined uStack_398;
  undefined4 uStack_388;
  undefined4 uStack_384;
  undefined auStack_380 [16];
  undefined4 uStack_370;
  undefined4 uStack_36c;
  undefined uStack_368;
  undefined4 uStack_358;
  undefined4 uStack_354;
  undefined uStack_350;
  undefined4 uStack_340;
  undefined4 uStack_33c;
  undefined uStack_338;
  undefined4 uStack_328;
  undefined4 uStack_324;
  undefined auStack_320 [16];
  undefined4 uStack_310;
  undefined4 uStack_30c;
  undefined uStack_308;
  undefined4 uStack_2f8;
  undefined4 uStack_2f4;
  undefined uStack_2f0;
  undefined4 uStack_2e0;
  undefined4 uStack_2dc;
  undefined uStack_2d8;
  undefined4 uStack_2c8;
  undefined4 uStack_2c4;
  undefined auStack_2c0 [16];
  undefined4 uStack_2b0;
  undefined4 uStack_2ac;
  undefined auStack_2a8 [16];
  undefined4 uStack_298;
  undefined4 uStack_294;
  undefined auStack_290 [16];
  undefined4 uStack_280;
  undefined4 uStack_27c;
  undefined auStack_278 [16];
  undefined4 uStack_268;
  undefined4 uStack_264;
  undefined auStack_260 [16];
  undefined4 uStack_250;
  undefined4 uStack_24c;
  undefined auStack_248 [16];
  undefined4 uStack_238;
  undefined4 uStack_234;
  undefined auStack_230 [16];
  undefined4 uStack_220;
  undefined4 uStack_21c;
  undefined auStack_218 [16];
  undefined4 uStack_208;
  undefined4 uStack_204;
  undefined auStack_200 [16];
  undefined4 uStack_1f0;
  undefined4 uStack_1ec;
  undefined auStack_1e8 [16];
  undefined4 uStack_1d8;
  undefined4 uStack_1d4;
  undefined auStack_1d0 [16];
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined auStack_1b8 [16];
  undefined4 uStack_1a8;
  undefined4 uStack_1a4;
  uint auStack_1a0 [4];
  undefined4 uStack_190;
  uint uStack_18c;
  uint auStack_188 [4];
  undefined4 uStack_178;
  uint uStack_174;
  uint auStack_170 [4];
  undefined4 uStack_160;
  uint uStack_15c;
  uint auStack_158 [4];
  undefined4 uStack_148;
  uint uStack_144;
  uint auStack_140 [4];
  undefined4 uStack_130;
  uint uStack_12c;
  uint auStack_128 [4];
  undefined4 uStack_118;
  uint uStack_114;
  uint auStack_110 [4];
  undefined4 uStack_100;
  uint uStack_fc;
  uint auStack_f8 [4];
  undefined4 uStack_e8;
  uint uStack_e4;
  uint auStack_e0 [4];
  undefined4 uStack_d0;
  uint uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184ee92;
  pvStack_10 = ExceptionList;
  uStack_d0 = 0;
  uStack_cc = 0xf;
  auStack_e0[0] = auStack_e0[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("en-us",5);
  uStack_8 = 0;
  uStack_310 = 0;
  uStack_30c = 0xf;
  auStack_320[0] = 0;
  FUN_005542c0("en-gb",5);
  uStack_8._0_1_ = 1;
  uStack_2f8 = 0;
  uStack_2f4 = 0xf;
  uStack_308 = 0;
  FUN_005542c0("en-au",5);
  uStack_8._0_1_ = 2;
  uStack_2e0 = 0;
  uStack_2dc = 0xf;
  uStack_2f0 = 0;
  FUN_005542c0("en-nz",5);
  uStack_8._0_1_ = 3;
  uStack_2c8 = 0;
  uStack_2c4 = 0xf;
  uStack_2d8 = 0;
  FUN_005542c0("en-ca",5);
  uStack_8._0_1_ = 4;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00604490(auStack_320,auStack_2c0,uStack_14);
  uStack_8._0_1_ = 5;
  FUN_0054ef60(auStack_e0);
  uStack_8._0_1_ = 6;
  FUN_00637260(&uStack_20);
  FUN_00577a40();
  uStack_8._0_1_ = 9;
  FUN_016f32d1(auStack_320,0x18,4,FUN_005507b0);
  uStack_8._0_1_ = 10;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 10;
  if (0xf < uStack_cc) {
    uVar3 = uStack_cc + 1;
    uVar2 = auStack_e0[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_e0[0] - 4);
      uVar3 = uStack_cc + 0x24;
      if (0x1f < (auStack_e0[0] - uVar2) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_d0 = 0;
  uStack_cc = 0xf;
  auStack_e0[0] = auStack_e0[0] & 0xffffff00;
  uStack_e8 = 0;
  uStack_e4 = 0xf;
  auStack_f8[0] = auStack_f8[0] & 0xffffff00;
  FUN_005542c0("en-gb",5);
  uStack_8._0_1_ = 0xb;
  uStack_370 = 0;
  uStack_36c = 0xf;
  auStack_380[0] = 0;
  FUN_005542c0("en-us",5);
  uStack_8._0_1_ = 0xc;
  uStack_358 = 0;
  uStack_354 = 0xf;
  uStack_368 = 0;
  FUN_005542c0("en-au",5);
  uStack_8._0_1_ = 0xd;
  uStack_340 = 0;
  uStack_33c = 0xf;
  uStack_350 = 0;
  FUN_005542c0("en-nz",5);
  uStack_8._0_1_ = 0xe;
  uStack_328 = 0;
  uStack_324 = 0xf;
  uStack_338 = 0;
  FUN_005542c0("en-ca",5);
  uStack_8._0_1_ = 0xf;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00604490(auStack_380,auStack_320,uStack_14);
  uStack_8._0_1_ = 0x10;
  FUN_0054ef60(auStack_f8);
  uStack_8._0_1_ = 0x11;
  FUN_00637260(&uStack_2c);
  FUN_00577a40();
  uStack_8._0_1_ = 0x14;
  FUN_016f32d1(auStack_380,0x18,4,FUN_005507b0);
  uStack_8._0_1_ = 0x15;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x15;
  if (0xf < uStack_e4) {
    uVar3 = uStack_e4 + 1;
    uVar2 = auStack_f8[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_f8[0] - 4);
      uVar3 = uStack_e4 + 0x24;
      if (0x1f < (auStack_f8[0] - uVar2) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_e8 = 0;
  uStack_e4 = 0xf;
  auStack_f8[0] = auStack_f8[0] & 0xffffff00;
  uStack_100 = 0;
  uStack_fc = 0xf;
  auStack_110[0] = auStack_110[0] & 0xffffff00;
  FUN_005542c0("en-au",5);
  uStack_8._0_1_ = 0x16;
  uStack_3d0 = 0;
  uStack_3cc = 0xf;
  auStack_3e0[0] = 0;
  FUN_005542c0("en-us",5);
  uStack_8._0_1_ = 0x17;
  uStack_3b8 = 0;
  uStack_3b4 = 0xf;
  uStack_3c8 = 0;
  FUN_005542c0("en-gb",5);
  uStack_8._0_1_ = 0x18;
  uStack_3a0 = 0;
  uStack_39c = 0xf;
  uStack_3b0 = 0;
  FUN_005542c0("en-nz",5);
  uStack_8._0_1_ = 0x19;
  uStack_388 = 0;
  uStack_384 = 0xf;
  uStack_398 = 0;
  FUN_005542c0("en-ca",5);
  uStack_8._0_1_ = 0x1a;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  FUN_00604490(auStack_3e0,auStack_380,uStack_14);
  uStack_8._0_1_ = 0x1b;
  FUN_0054ef60(auStack_110);
  uStack_8._0_1_ = 0x1c;
  FUN_00637260(&uStack_38);
  FUN_00577a40();
  uStack_8._0_1_ = 0x1f;
  FUN_016f32d1(auStack_3e0,0x18,4,FUN_005507b0);
  uStack_8._0_1_ = 0x20;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x20;
  if (0xf < uStack_fc) {
    uVar3 = uStack_fc + 1;
    uVar2 = auStack_110[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_110[0] - 4);
      uVar3 = uStack_fc + 0x24;
      if (0x1f < (auStack_110[0] - uVar2) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_100 = 0;
  uStack_fc = 0xf;
  auStack_110[0] = auStack_110[0] & 0xffffff00;
  uStack_118 = 0;
  uStack_114 = 0xf;
  auStack_128[0] = auStack_128[0] & 0xffffff00;
  FUN_005542c0("en-nz",5);
  uStack_8._0_1_ = 0x21;
  uStack_430 = 0;
  uStack_42c = 0xf;
  auStack_440[0] = 0;
  FUN_005542c0("en-us",5);
  uStack_8._0_1_ = 0x22;
  uStack_418 = 0;
  uStack_414 = 0xf;
  uStack_428 = 0;
  FUN_005542c0("en-gb",5);
  uStack_8._0_1_ = 0x23;
  uStack_400 = 0;
  uStack_3fc = 0xf;
  uStack_410 = 0;
  FUN_005542c0("en-au",5);
  uStack_8._0_1_ = 0x24;
  uStack_3e8 = 0;
  uStack_3e4 = 0xf;
  uStack_3f8 = 0;
  FUN_005542c0("en-ca",5);
  uStack_8._0_1_ = 0x25;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00604490(auStack_440,auStack_3e0,uStack_14);
  uStack_8._0_1_ = 0x26;
  FUN_0054ef60(auStack_128);
  uStack_8._0_1_ = 0x27;
  FUN_00637260(&uStack_44);
  FUN_00577a40();
  uStack_8._0_1_ = 0x2a;
  FUN_016f32d1(auStack_440,0x18,4,FUN_005507b0);
  uStack_8._0_1_ = 0x2b;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x2b;
  if (0xf < uStack_114) {
    uVar3 = uStack_114 + 1;
    uVar2 = auStack_128[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_128[0] - 4);
      uVar3 = uStack_114 + 0x24;
      if (0x1f < (auStack_128[0] - uVar2) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_118 = 0;
  uStack_114 = 0xf;
  auStack_128[0] = auStack_128[0] & 0xffffff00;
  uStack_130 = 0;
  uStack_12c = 0xf;
  auStack_140[0] = auStack_140[0] & 0xffffff00;
  FUN_005542c0("en-ca",5);
  uStack_8._0_1_ = 0x2c;
  uStack_490 = 0;
  uStack_48c = 0xf;
  auStack_4a0[0] = 0;
  FUN_005542c0("en-us",5);
  uStack_8._0_1_ = 0x2d;
  uStack_478 = 0;
  uStack_474 = 0xf;
  uStack_488 = 0;
  FUN_005542c0("en-gb",5);
  uStack_8._0_1_ = 0x2e;
  uStack_460 = 0;
  uStack_45c = 0xf;
  uStack_470 = 0;
  FUN_005542c0("en-au",5);
  uStack_8._0_1_ = 0x2f;
  uStack_448 = 0;
  uStack_444 = 0xf;
  uStack_458 = 0;
  FUN_005542c0("en-nz",5);
  uStack_8._0_1_ = 0x30;
  uStack_50 = 0;
  uStack_4c = 0;
  uStack_48 = 0;
  FUN_00604490(auStack_4a0,auStack_440,uStack_14);
  uStack_8._0_1_ = 0x31;
  FUN_0054ef60(auStack_140);
  uStack_8._0_1_ = 0x32;
  FUN_00637260(&uStack_50);
  FUN_00577a40();
  uStack_8._0_1_ = 0x35;
  FUN_016f32d1(auStack_4a0,0x18,4,FUN_005507b0);
  uStack_8._0_1_ = 0x36;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x36;
  if (0xf < uStack_12c) {
    uVar3 = uStack_12c + 1;
    uVar2 = auStack_140[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_140[0] - 4);
      uVar3 = uStack_12c + 0x24;
      if (0x1f < (auStack_140[0] - uVar2) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_130 = 0;
  uStack_12c = 0xf;
  auStack_140[0] = auStack_140[0] & 0xffffff00;
  uStack_148 = 0;
  uStack_144 = 0xf;
  auStack_158[0] = auStack_158[0] & 0xffffff00;
  FUN_005542c0("zh-cn",5);
  uStack_8._0_1_ = 0x37;
  uStack_4f0 = 0;
  uStack_4ec = 0xf;
  auStack_500[0] = 0;
  FUN_005542c0("zh-sg",5);
  uStack_8._0_1_ = 0x38;
  uStack_4d8 = 0;
  uStack_4d4 = 0xf;
  uStack_4e8 = 0;
  FUN_005542c0("zh-hant",7);
  uStack_8._0_1_ = 0x39;
  uStack_4c0 = 0;
  uStack_4bc = 0xf;
  uStack_4d0 = 0;
  FUN_005542c0("zh-tw",5);
  uStack_8._0_1_ = 0x3a;
  uStack_4a8 = 0;
  uStack_4a4 = 0xf;
  uStack_4b8 = 0;
  FUN_005542c0("zh-hk",5);
  uStack_8._0_1_ = 0x3b;
  uStack_5c = 0;
  uStack_58 = 0;
  uStack_54 = 0;
  FUN_00604490(auStack_500,auStack_4a0,uStack_14);
  uStack_8._0_1_ = 0x3c;
  FUN_0054ef60(auStack_158);
  uStack_8._0_1_ = 0x3d;
  FUN_00637260(&uStack_5c);
  FUN_00577a40();
  uStack_8._0_1_ = 0x40;
  FUN_016f32d1(auStack_500,0x18,4,FUN_005507b0);
  uStack_8._0_1_ = 0x41;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x41;
  if (0xf < uStack_144) {
    uVar3 = uStack_144 + 1;
    uVar2 = auStack_158[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_158[0] - 4);
      uVar3 = uStack_144 + 0x24;
      if (0x1f < (auStack_158[0] - uVar2) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_148 = 0;
  uStack_144 = 0xf;
  auStack_158[0] = auStack_158[0] & 0xffffff00;
  uStack_160 = 0;
  uStack_15c = 0xf;
  auStack_170[0] = auStack_170[0] & 0xffffff00;
  FUN_005542c0("zh-sg",5);
  uStack_8._0_1_ = 0x42;
  uStack_550 = 0;
  uStack_54c = 0xf;
  auStack_560[0] = 0;
  FUN_005542c0("zh-cn",5);
  uStack_8._0_1_ = 0x43;
  uStack_538 = 0;
  uStack_534 = 0xf;
  uStack_548 = 0;
  FUN_005542c0("zh-hant",7);
  uStack_8._0_1_ = 0x44;
  uStack_520 = 0;
  uStack_51c = 0xf;
  uStack_530 = 0;
  FUN_005542c0("zh-tw",5);
  uStack_8._0_1_ = 0x45;
  uStack_508 = 0;
  uStack_504 = 0xf;
  uStack_518 = 0;
  FUN_005542c0("zh-hk",5);
  uStack_8._0_1_ = 0x46;
  uStack_68 = 0;
  uStack_64 = 0;
  uStack_60 = 0;
  FUN_00604490(auStack_560,auStack_500,uStack_14);
  uStack_8._0_1_ = 0x47;
  FUN_0054ef60(auStack_170);
  uStack_8._0_1_ = 0x48;
  FUN_00637260(&uStack_68);
  FUN_00577a40();
  uStack_8._0_1_ = 0x4b;
  FUN_016f32d1(auStack_560,0x18,4,FUN_005507b0);
  uStack_8._0_1_ = 0x4c;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x4c;
  if (0xf < uStack_15c) {
    uVar3 = uStack_15c + 1;
    uVar2 = auStack_170[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_170[0] - 4);
      uVar3 = uStack_15c + 0x24;
      if (0x1f < (auStack_170[0] - uVar2) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_160 = 0;
  uStack_15c = 0xf;
  auStack_170[0] = auStack_170[0] & 0xffffff00;
  uStack_178 = 0;
  uStack_174 = 0xf;
  auStack_188[0] = auStack_188[0] & 0xffffff00;
  FUN_005542c0("zh-hk",5);
  uStack_8._0_1_ = 0x4d;
  uStack_5b0 = 0;
  uStack_5ac = 0xf;
  auStack_5c0[0] = 0;
  FUN_005542c0("zh-tw",5);
  uStack_8._0_1_ = 0x4e;
  uStack_598 = 0;
  uStack_594 = 0xf;
  uStack_5a8 = 0;
  FUN_005542c0("zh-hans",7);
  uStack_8._0_1_ = 0x4f;
  uStack_580 = 0;
  uStack_57c = 0xf;
  uStack_590 = 0;
  FUN_005542c0("zh-cn",5);
  uStack_8._0_1_ = 0x50;
  uStack_568 = 0;
  uStack_564 = 0xf;
  uStack_578 = 0;
  FUN_005542c0("zh-sg",5);
  uStack_8._0_1_ = 0x51;
  uStack_74 = 0;
  uStack_70 = 0;
  uStack_6c = 0;
  FUN_00604490(auStack_5c0,auStack_560,uStack_14);
  uStack_8._0_1_ = 0x52;
  FUN_0054ef60(auStack_188);
  uStack_8._0_1_ = 0x53;
  FUN_00637260(&uStack_74);
  FUN_00577a40();
  uStack_8._0_1_ = 0x56;
  FUN_016f32d1(auStack_5c0,0x18,4,FUN_005507b0);
  uStack_8._0_1_ = 0x57;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x57;
  if (0xf < uStack_174) {
    uVar3 = uStack_174 + 1;
    uVar2 = auStack_188[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_188[0] - 4);
      uVar3 = uStack_174 + 0x24;
      if (0x1f < (auStack_188[0] - uVar2) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_178 = 0;
  uStack_174 = 0xf;
  auStack_188[0] = auStack_188[0] & 0xffffff00;
  uStack_190 = 0;
  uStack_18c = 0xf;
  auStack_1a0[0] = auStack_1a0[0] & 0xffffff00;
  FUN_005542c0("zh-tw",5);
  uStack_8._0_1_ = 0x58;
  uStack_610 = 0;
  uStack_60c = 0xf;
  auStack_620[0] = 0;
  FUN_005542c0("zh-hk",5);
  uStack_8._0_1_ = 0x59;
  uStack_5f8 = 0;
  uStack_5f4 = 0xf;
  uStack_608 = 0;
  FUN_005542c0("zh-hans",7);
  uStack_8._0_1_ = 0x5a;
  uStack_5e0 = 0;
  uStack_5dc = 0xf;
  uStack_5f0 = 0;
  FUN_005542c0("zh-cn",5);
  uStack_8._0_1_ = 0x5b;
  uStack_5c8 = 0;
  uStack_5c4 = 0xf;
  uStack_5d8 = 0;
  FUN_005542c0("zh-sg",5);
  uStack_8._0_1_ = 0x5c;
  uStack_80 = 0;
  uStack_7c = 0;
  uStack_78 = 0;
  FUN_00604490(auStack_620,auStack_5c0,uStack_14);
  uStack_8._0_1_ = 0x5d;
  FUN_0054ef60(auStack_1a0);
  uStack_8._0_1_ = 0x5e;
  FUN_00637260(&uStack_80);
  FUN_00577a40();
  uStack_8._0_1_ = 0x61;
  FUN_016f32d1(auStack_620,0x18,4,FUN_005507b0);
  uStack_8._0_1_ = 0x62;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x62;
  if (0xf < uStack_18c) {
    uVar3 = uStack_18c + 1;
    uVar2 = auStack_1a0[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_1a0[0] - 4);
      uVar3 = uStack_18c + 0x24;
      if (0x1f < (auStack_1a0[0] - uVar2) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_190 = 0;
  uStack_18c = 0xf;
  auStack_1a0[0] = auStack_1a0[0] & 0xffffff00;
  uStack_238 = 0;
  uStack_234 = 0xf;
  auStack_248[0] = 0;
  FUN_005542c0("pt-br",5);
  uStack_8._0_1_ = 99;
  uStack_1a8 = 0;
  uStack_1a4 = 0xf;
  auStack_1b8[0] = 0;
  FUN_005542c0("pt-pt",5);
  uStack_8._0_1_ = 100;
  uStack_8c = 0;
  uStack_88 = 0;
  uStack_84 = 0;
  FUN_00604490(auStack_1b8,auStack_1a0,uStack_14);
  uStack_8._0_1_ = 0x65;
  FUN_0054ef60(auStack_248);
  uStack_8._0_1_ = 0x66;
  FUN_00637260(&uStack_8c);
  FUN_00577a40();
  uStack_8._0_1_ = 0x69;
  FUN_016f32d1(auStack_1b8,0x18,1,FUN_005507b0);
  uStack_8._0_1_ = 0x6a;
  FUN_005507b0();
  uStack_250 = 0;
  uStack_24c = 0xf;
  auStack_260[0] = 0;
  FUN_005542c0("pt-pt",5);
  uStack_8._0_1_ = 0x6b;
  uStack_1c0 = 0;
  uStack_1bc = 0xf;
  auStack_1d0[0] = 0;
  FUN_005542c0("pt-br",5);
  uStack_8._0_1_ = 0x6c;
  uStack_98 = 0;
  uStack_94 = 0;
  uStack_90 = 0;
  FUN_00604490(auStack_1d0,auStack_1b8,uStack_14);
  uStack_8._0_1_ = 0x6d;
  FUN_0054ef60(auStack_260);
  uStack_8._0_1_ = 0x6e;
  FUN_00637260(&uStack_98);
  FUN_00577a40();
  uStack_8._0_1_ = 0x71;
  FUN_016f32d1(auStack_1d0,0x18,1,FUN_005507b0);
  uStack_8._0_1_ = 0x72;
  FUN_005507b0();
  uStack_268 = 0;
  uStack_264 = 0xf;
  auStack_278[0] = 0;
  FUN_005542c0("es-mx",5);
  uStack_8._0_1_ = 0x73;
  uStack_1d8 = 0;
  uStack_1d4 = 0xf;
  auStack_1e8[0] = 0;
  FUN_005542c0("es-es",5);
  uStack_8._0_1_ = 0x74;
  uStack_a4 = 0;
  uStack_a0 = 0;
  uStack_9c = 0;
  FUN_00604490(auStack_1e8,auStack_1d0,uStack_14);
  uStack_8._0_1_ = 0x75;
  FUN_0054ef60(auStack_278);
  uStack_8._0_1_ = 0x76;
  FUN_00637260(&uStack_a4);
  FUN_00577a40();
  uStack_8._0_1_ = 0x79;
  FUN_016f32d1(auStack_1e8,0x18,1,FUN_005507b0);
  uStack_8._0_1_ = 0x7a;
  FUN_005507b0();
  uStack_280 = 0;
  uStack_27c = 0xf;
  auStack_290[0] = 0;
  FUN_005542c0("es-es",5);
  uStack_8._0_1_ = 0x7b;
  uStack_1f0 = 0;
  uStack_1ec = 0xf;
  auStack_200[0] = 0;
  FUN_005542c0("es-mx",5);
  uStack_8._0_1_ = 0x7c;
  uStack_b0 = 0;
  uStack_ac = 0;
  uStack_a8 = 0;
  FUN_00604490(auStack_200,auStack_1e8,uStack_14);
  uStack_8._0_1_ = 0x7d;
  FUN_0054ef60(auStack_290);
  uStack_8._0_1_ = 0x7e;
  FUN_00637260(&uStack_b0);
  FUN_00577a40();
  uStack_8._0_1_ = 0x81;
  FUN_016f32d1(auStack_200,0x18,1,FUN_005507b0);
  uStack_8._0_1_ = 0x82;
  FUN_005507b0();
  uStack_298 = 0;
  uStack_294 = 0xf;
  auStack_2a8[0] = 0;
  FUN_005542c0("fr-fr",5);
  uStack_8._0_1_ = 0x83;
  uStack_208 = 0;
  uStack_204 = 0xf;
  auStack_218[0] = 0;
  FUN_005542c0("fr-ca",5);
  uStack_8._0_1_ = 0x84;
  uStack_bc = 0;
  uStack_b8 = 0;
  uStack_b4 = 0;
  FUN_00604490(auStack_218,auStack_200,uStack_14);
  uStack_8._0_1_ = 0x85;
  FUN_0054ef60(auStack_2a8);
  uStack_8._0_1_ = 0x86;
  FUN_00637260(&uStack_bc);
  FUN_00577a40();
  uStack_8._0_1_ = 0x89;
  FUN_016f32d1(auStack_218,0x18,1,FUN_005507b0);
  uStack_8._0_1_ = 0x8a;
  FUN_005507b0();
  uStack_2b0 = 0;
  uStack_2ac = 0xf;
  auStack_2c0[0] = 0;
  FUN_005542c0("fr-ca",5);
  uStack_8._0_1_ = 0x8b;
  uStack_220 = 0;
  uStack_21c = 0xf;
  auStack_230[0] = 0;
  FUN_005542c0("fr-fr",5);
  uStack_8._0_1_ = 0x8c;
  uStack_c8 = 0;
  uStack_c4 = 0;
  uStack_c0 = 0;
  FUN_00604490(auStack_230,auStack_218,uStack_14);
  uStack_8._0_1_ = 0x8d;
  FUN_0054ef60(auStack_2c0);
  uStack_8._0_1_ = 0x8e;
  FUN_00637260(&uStack_c8);
  FUN_00577a40();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x91);
  FUN_016f32d1(auStack_230,0x18,1,FUN_005507b0);
  FUN_005507b0();
  uStack_8 = 0x93;
  FUN_00fd3340(auStack_83c,auStack_620);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(auStack_83c,0x24,0xf,FUN_00fd39f0);
  FUN_016f3654(&LAB_018aacb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2315 ; VA 0x0053cf30 ; FUN_0053cf30 */

void FUN_0053cf30(void)

{
  undefined uVar1;
  uint uVar2;
  uint uVar3;
  undefined auStack_914 [576];
  undefined auStack_6d4 [16];
  undefined4 uStack_6c4;
  undefined4 uStack_6c0;
  undefined uStack_6bc;
  undefined4 uStack_6ac;
  undefined4 uStack_6a8;
  undefined uStack_6a4;
  undefined4 uStack_694;
  undefined4 uStack_690;
  undefined uStack_68c;
  undefined4 uStack_67c;
  undefined4 uStack_678;
  undefined uStack_674;
  undefined4 uStack_664;
  undefined4 uStack_660;
  undefined uStack_65c;
  undefined4 uStack_64c;
  undefined4 uStack_648;
  undefined auStack_644 [16];
  undefined4 uStack_634;
  undefined4 uStack_630;
  undefined uStack_62c;
  undefined4 uStack_61c;
  undefined4 uStack_618;
  undefined uStack_614;
  undefined4 uStack_604;
  undefined4 uStack_600;
  undefined uStack_5fc;
  undefined4 uStack_5ec;
  undefined4 uStack_5e8;
  undefined auStack_5e4 [16];
  undefined4 uStack_5d4;
  undefined4 uStack_5d0;
  undefined uStack_5cc;
  undefined4 uStack_5bc;
  undefined4 uStack_5b8;
  undefined uStack_5b4;
  undefined4 uStack_5a4;
  undefined4 uStack_5a0;
  undefined uStack_59c;
  undefined4 uStack_58c;
  undefined4 uStack_588;
  undefined auStack_584 [16];
  undefined4 uStack_574;
  undefined4 uStack_570;
  undefined uStack_56c;
  undefined4 uStack_55c;
  undefined4 uStack_558;
  undefined uStack_554;
  undefined4 uStack_544;
  undefined4 uStack_540;
  undefined uStack_53c;
  undefined4 uStack_52c;
  undefined4 uStack_528;
  undefined auStack_524 [16];
  undefined4 uStack_514;
  undefined4 uStack_510;
  undefined uStack_50c;
  undefined4 uStack_4fc;
  undefined4 uStack_4f8;
  undefined uStack_4f4;
  undefined4 uStack_4e4;
  undefined4 uStack_4e0;
  undefined uStack_4dc;
  undefined4 uStack_4cc;
  undefined4 uStack_4c8;
  undefined auStack_4c4 [16];
  undefined4 uStack_4b4;
  undefined4 uStack_4b0;
  undefined uStack_4ac;
  undefined4 uStack_49c;
  undefined4 uStack_498;
  undefined uStack_494;
  undefined4 uStack_484;
  undefined4 uStack_480;
  undefined uStack_47c;
  undefined4 uStack_46c;
  undefined4 uStack_468;
  undefined auStack_464 [16];
  undefined4 uStack_454;
  undefined4 uStack_450;
  undefined uStack_44c;
  undefined4 uStack_43c;
  undefined4 uStack_438;
  undefined uStack_434;
  undefined4 uStack_424;
  undefined4 uStack_420;
  undefined uStack_41c;
  undefined4 uStack_40c;
  undefined4 uStack_408;
  undefined auStack_404 [16];
  undefined4 uStack_3f4;
  undefined4 uStack_3f0;
  undefined uStack_3ec;
  undefined4 uStack_3dc;
  undefined4 uStack_3d8;
  undefined uStack_3d4;
  undefined4 uStack_3c4;
  undefined4 uStack_3c0;
  undefined uStack_3bc;
  undefined4 uStack_3ac;
  undefined4 uStack_3a8;
  undefined auStack_3a4 [16];
  undefined4 uStack_394;
  undefined4 uStack_390;
  undefined uStack_38c;
  undefined4 uStack_37c;
  undefined4 uStack_378;
  undefined uStack_374;
  undefined4 uStack_364;
  undefined4 uStack_360;
  undefined uStack_35c;
  undefined4 uStack_34c;
  undefined4 uStack_348;
  undefined auStack_344 [16];
  undefined4 uStack_334;
  undefined4 uStack_330;
  undefined uStack_32c;
  undefined4 uStack_31c;
  undefined4 uStack_318;
  undefined uStack_314;
  undefined4 uStack_304;
  undefined4 uStack_300;
  undefined uStack_2fc;
  undefined4 uStack_2ec;
  undefined4 uStack_2e8;
  undefined auStack_2e4 [16];
  undefined4 uStack_2d4;
  undefined4 uStack_2d0;
  undefined auStack_2cc [16];
  undefined4 uStack_2bc;
  undefined4 uStack_2b8;
  undefined auStack_2b4 [16];
  undefined4 uStack_2a4;
  undefined4 uStack_2a0;
  undefined auStack_29c [16];
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined auStack_284 [16];
  undefined4 uStack_274;
  undefined4 uStack_270;
  undefined auStack_26c [16];
  undefined4 uStack_25c;
  undefined4 uStack_258;
  undefined auStack_254 [16];
  undefined4 uStack_244;
  undefined4 uStack_240;
  undefined auStack_23c [16];
  undefined4 uStack_22c;
  undefined4 uStack_228;
  undefined auStack_224 [16];
  undefined4 uStack_214;
  undefined4 uStack_210;
  undefined auStack_20c [16];
  undefined4 uStack_1fc;
  undefined4 uStack_1f8;
  undefined auStack_1f4 [16];
  undefined4 uStack_1e4;
  undefined4 uStack_1e0;
  undefined auStack_1dc [16];
  undefined4 uStack_1cc;
  undefined4 uStack_1c8;
  undefined auStack_1c4 [16];
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  uint auStack_1ac [4];
  undefined4 uStack_19c;
  uint uStack_198;
  uint auStack_194 [4];
  undefined4 uStack_184;
  uint uStack_180;
  uint auStack_17c [4];
  undefined4 uStack_16c;
  uint uStack_168;
  uint auStack_164 [4];
  undefined4 uStack_154;
  uint uStack_150;
  uint auStack_14c [4];
  undefined4 uStack_13c;
  uint uStack_138;
  uint auStack_134 [4];
  undefined4 uStack_124;
  uint uStack_120;
  uint auStack_11c [4];
  undefined4 uStack_10c;
  uint uStack_108;
  uint auStack_104 [4];
  undefined4 uStack_f4;
  uint uStack_f0;
  uint auStack_ec [4];
  undefined4 uStack_dc;
  uint uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184f41b;
  pvStack_10 = ExceptionList;
  uStack_dc = 0;
  uStack_d8 = 0xf;
  auStack_ec[0] = auStack_ec[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("en-us",5);
  uStack_8 = 0;
  uStack_334 = 0;
  uStack_330 = 0xf;
  auStack_344[0] = 0;
  FUN_005542c0("en-gb",5);
  uStack_8._0_1_ = 1;
  uStack_31c = 0;
  uStack_318 = 0xf;
  uStack_32c = 0;
  FUN_005542c0("en-au",5);
  uStack_8._0_1_ = 2;
  uStack_304 = 0;
  uStack_300 = 0xf;
  uStack_314 = 0;
  FUN_005542c0("en-nz",5);
  uStack_8._0_1_ = 3;
  uStack_2ec = 0;
  uStack_2e8 = 0xf;
  uStack_2fc = 0;
  FUN_005542c0("en-ca",5);
  uStack_8._0_1_ = 4;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00604490(auStack_344,auStack_2e4,uStack_14);
  uStack_8._0_1_ = 5;
  FUN_0054ef60(auStack_ec);
  uStack_8._0_1_ = 6;
  FUN_00637260(&uStack_20);
  FUN_00577a40();
  uStack_8._0_1_ = 9;
  FUN_016f32d1(auStack_344,0x18,4,FUN_005507b0);
  uStack_8._0_1_ = 10;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 10;
  if (0xf < uStack_d8) {
    uVar3 = uStack_d8 + 1;
    uVar2 = auStack_ec[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_ec[0] - 4);
      uVar3 = uStack_d8 + 0x24;
      if (0x1f < (auStack_ec[0] - uVar2) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_dc = 0;
  uStack_d8 = 0xf;
  auStack_ec[0] = auStack_ec[0] & 0xffffff00;
  uStack_f4 = 0;
  uStack_f0 = 0xf;
  auStack_104[0] = auStack_104[0] & 0xffffff00;
  FUN_005542c0("en-gb",5);
  uStack_8._0_1_ = 0xb;
  uStack_394 = 0;
  uStack_390 = 0xf;
  auStack_3a4[0] = 0;
  FUN_005542c0("en-us",5);
  uStack_8._0_1_ = 0xc;
  uStack_37c = 0;
  uStack_378 = 0xf;
  uStack_38c = 0;
  FUN_005542c0("en-au",5);
  uStack_8._0_1_ = 0xd;
  uStack_364 = 0;
  uStack_360 = 0xf;
  uStack_374 = 0;
  FUN_005542c0("en-nz",5);
  uStack_8._0_1_ = 0xe;
  uStack_34c = 0;
  uStack_348 = 0xf;
  uStack_35c = 0;
  FUN_005542c0("en-ca",5);
  uStack_8._0_1_ = 0xf;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00604490(auStack_3a4,auStack_344,uStack_14);
  uStack_8._0_1_ = 0x10;
  FUN_0054ef60(auStack_104);
  uStack_8._0_1_ = 0x11;
  FUN_00637260(&uStack_2c);
  FUN_00577a40();
  uStack_8._0_1_ = 0x14;
  FUN_016f32d1(auStack_3a4,0x18,4,FUN_005507b0);
  uStack_8._0_1_ = 0x15;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x15;
  if (0xf < uStack_f0) {
    uVar3 = uStack_f0 + 1;
    uVar2 = auStack_104[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_104[0] - 4);
      uVar3 = uStack_f0 + 0x24;
      if (0x1f < (auStack_104[0] - uVar2) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_f4 = 0;
  uStack_f0 = 0xf;
  auStack_104[0] = auStack_104[0] & 0xffffff00;
  uStack_10c = 0;
  uStack_108 = 0xf;
  auStack_11c[0] = auStack_11c[0] & 0xffffff00;
  FUN_005542c0("en-au",5);
  uStack_8._0_1_ = 0x16;
  uStack_3f4 = 0;
  uStack_3f0 = 0xf;
  auStack_404[0] = 0;
  FUN_005542c0("en-us",5);
  uStack_8._0_1_ = 0x17;
  uStack_3dc = 0;
  uStack_3d8 = 0xf;
  uStack_3ec = 0;
  FUN_005542c0("en-gb",5);
  uStack_8._0_1_ = 0x18;
  uStack_3c4 = 0;
  uStack_3c0 = 0xf;
  uStack_3d4 = 0;
  FUN_005542c0("en-nz",5);
  uStack_8._0_1_ = 0x19;
  uStack_3ac = 0;
  uStack_3a8 = 0xf;
  uStack_3bc = 0;
  FUN_005542c0("en-ca",5);
  uStack_8._0_1_ = 0x1a;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  FUN_00604490(auStack_404,auStack_3a4,uStack_14);
  uStack_8._0_1_ = 0x1b;
  FUN_0054ef60(auStack_11c);
  uStack_8._0_1_ = 0x1c;
  FUN_00637260(&uStack_38);
  FUN_00577a40();
  uStack_8._0_1_ = 0x1f;
  FUN_016f32d1(auStack_404,0x18,4,FUN_005507b0);
  uStack_8._0_1_ = 0x20;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x20;
  if (0xf < uStack_108) {
    uVar3 = uStack_108 + 1;
    uVar2 = auStack_11c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_11c[0] - 4);
      uVar3 = uStack_108 + 0x24;
      if (0x1f < (auStack_11c[0] - uVar2) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_10c = 0;
  uStack_108 = 0xf;
  auStack_11c[0] = auStack_11c[0] & 0xffffff00;
  uStack_124 = 0;
  uStack_120 = 0xf;
  auStack_134[0] = auStack_134[0] & 0xffffff00;
  FUN_005542c0("en-nz",5);
  uStack_8._0_1_ = 0x21;
  uStack_454 = 0;
  uStack_450 = 0xf;
  auStack_464[0] = 0;
  FUN_005542c0("en-us",5);
  uStack_8._0_1_ = 0x22;
  uStack_43c = 0;
  uStack_438 = 0xf;
  uStack_44c = 0;
  FUN_005542c0("en-gb",5);
  uStack_8._0_1_ = 0x23;
  uStack_424 = 0;
  uStack_420 = 0xf;
  uStack_434 = 0;
  FUN_005542c0("en-au",5);
  uStack_8._0_1_ = 0x24;
  uStack_40c = 0;
  uStack_408 = 0xf;
  uStack_41c = 0;
  FUN_005542c0("en-ca",5);
  uStack_8._0_1_ = 0x25;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00604490(auStack_464,auStack_404,uStack_14);
  uStack_8._0_1_ = 0x26;
  FUN_0054ef60(auStack_134);
  uStack_8._0_1_ = 0x27;
  FUN_00637260(&uStack_44);
  FUN_00577a40();
  uStack_8._0_1_ = 0x2a;
  FUN_016f32d1(auStack_464,0x18,4,FUN_005507b0);
  uStack_8._0_1_ = 0x2b;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x2b;
  if (0xf < uStack_120) {
    uVar3 = uStack_120 + 1;
    uVar2 = auStack_134[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_134[0] - 4);
      uVar3 = uStack_120 + 0x24;
      if (0x1f < (auStack_134[0] - uVar2) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_124 = 0;
  uStack_120 = 0xf;
  auStack_134[0] = auStack_134[0] & 0xffffff00;
  uStack_13c = 0;
  uStack_138 = 0xf;
  auStack_14c[0] = auStack_14c[0] & 0xffffff00;
  FUN_005542c0("en-ca",5);
  uStack_8._0_1_ = 0x2c;
  uStack_4b4 = 0;
  uStack_4b0 = 0xf;
  auStack_4c4[0] = 0;
  FUN_005542c0("en-us",5);
  uStack_8._0_1_ = 0x2d;
  uStack_49c = 0;
  uStack_498 = 0xf;
  uStack_4ac = 0;
  FUN_005542c0("en-gb",5);
  uStack_8._0_1_ = 0x2e;
  uStack_484 = 0;
  uStack_480 = 0xf;
  uStack_494 = 0;
  FUN_005542c0("en-au",5);
  uStack_8._0_1_ = 0x2f;
  uStack_46c = 0;
  uStack_468 = 0xf;
  uStack_47c = 0;
  FUN_005542c0("en-nz",5);
  uStack_8._0_1_ = 0x30;
  uStack_50 = 0;
  uStack_4c = 0;
  uStack_48 = 0;
  FUN_00604490(auStack_4c4,auStack_464,uStack_14);
  uStack_8._0_1_ = 0x31;
  FUN_0054ef60(auStack_14c);
  uStack_8._0_1_ = 0x32;
  FUN_00637260(&uStack_50);
  FUN_00577a40();
  uStack_8._0_1_ = 0x35;
  FUN_016f32d1(auStack_4c4,0x18,4,FUN_005507b0);
  uStack_8._0_1_ = 0x36;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x36;
  if (0xf < uStack_138) {
    uVar3 = uStack_138 + 1;
    uVar2 = auStack_14c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_14c[0] - 4);
      uVar3 = uStack_138 + 0x24;
      if (0x1f < (auStack_14c[0] - uVar2) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_13c = 0;
  uStack_138 = 0xf;
  auStack_14c[0] = auStack_14c[0] & 0xffffff00;
  uStack_154 = 0;
  uStack_150 = 0xf;
  auStack_164[0] = auStack_164[0] & 0xffffff00;
  FUN_005542c0("zh-cn",5);
  uStack_8._0_1_ = 0x37;
  uStack_514 = 0;
  uStack_510 = 0xf;
  auStack_524[0] = 0;
  FUN_005542c0("zh-sg",5);
  uStack_8._0_1_ = 0x38;
  uStack_4fc = 0;
  uStack_4f8 = 0xf;
  uStack_50c = 0;
  FUN_005542c0("zh-hant",7);
  uStack_8._0_1_ = 0x39;
  uStack_4e4 = 0;
  uStack_4e0 = 0xf;
  uStack_4f4 = 0;
  FUN_005542c0("zh-tw",5);
  uStack_8._0_1_ = 0x3a;
  uStack_4cc = 0;
  uStack_4c8 = 0xf;
  uStack_4dc = 0;
  FUN_005542c0("zh-hk",5);
  uStack_8._0_1_ = 0x3b;
  uStack_5c = 0;
  uStack_58 = 0;
  uStack_54 = 0;
  FUN_00604490(auStack_524,auStack_4c4,uStack_14);
  uStack_8._0_1_ = 0x3c;
  FUN_0054ef60(auStack_164);
  uStack_8._0_1_ = 0x3d;
  FUN_00637260(&uStack_5c);
  FUN_00577a40();
  uStack_8._0_1_ = 0x40;
  FUN_016f32d1(auStack_524,0x18,4,FUN_005507b0);
  uStack_8._0_1_ = 0x41;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x41;
  if (0xf < uStack_150) {
    uVar3 = uStack_150 + 1;
    uVar2 = auStack_164[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_164[0] - 4);
      uVar3 = uStack_150 + 0x24;
      if (0x1f < (auStack_164[0] - uVar2) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_154 = 0;
  uStack_150 = 0xf;
  auStack_164[0] = auStack_164[0] & 0xffffff00;
  uStack_16c = 0;
  uStack_168 = 0xf;
  auStack_17c[0] = auStack_17c[0] & 0xffffff00;
  FUN_005542c0("zh-sg",5);
  uStack_8._0_1_ = 0x42;
  uStack_574 = 0;
  uStack_570 = 0xf;
  auStack_584[0] = 0;
  FUN_005542c0("zh-cn",5);
  uStack_8._0_1_ = 0x43;
  uStack_55c = 0;
  uStack_558 = 0xf;
  uStack_56c = 0;
  FUN_005542c0("zh-hant",7);
  uStack_8._0_1_ = 0x44;
  uStack_544 = 0;
  uStack_540 = 0xf;
  uStack_554 = 0;
  FUN_005542c0("zh-tw",5);
  uStack_8._0_1_ = 0x45;
  uStack_52c = 0;
  uStack_528 = 0xf;
  uStack_53c = 0;
  FUN_005542c0("zh-hk",5);
  uStack_8._0_1_ = 0x46;
  uStack_68 = 0;
  uStack_64 = 0;
  uStack_60 = 0;
  FUN_00604490(auStack_584,auStack_524,uStack_14);
  uStack_8._0_1_ = 0x47;
  FUN_0054ef60(auStack_17c);
  uStack_8._0_1_ = 0x48;
  FUN_00637260(&uStack_68);
  FUN_00577a40();
  uStack_8._0_1_ = 0x4b;
  FUN_016f32d1(auStack_584,0x18,4,FUN_005507b0);
  uStack_8._0_1_ = 0x4c;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x4c;
  if (0xf < uStack_168) {
    uVar3 = uStack_168 + 1;
    uVar2 = auStack_17c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_17c[0] - 4);
      uVar3 = uStack_168 + 0x24;
      if (0x1f < (auStack_17c[0] - uVar2) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_16c = 0;
  uStack_168 = 0xf;
  auStack_17c[0] = auStack_17c[0] & 0xffffff00;
  uStack_184 = 0;
  uStack_180 = 0xf;
  auStack_194[0] = auStack_194[0] & 0xffffff00;
  FUN_005542c0("zh-hk",5);
  uStack_8._0_1_ = 0x4d;
  uStack_5d4 = 0;
  uStack_5d0 = 0xf;
  auStack_5e4[0] = 0;
  FUN_005542c0("zh-tw",5);
  uStack_8._0_1_ = 0x4e;
  uStack_5bc = 0;
  uStack_5b8 = 0xf;
  uStack_5cc = 0;
  FUN_005542c0("zh-hans",7);
  uStack_8._0_1_ = 0x4f;
  uStack_5a4 = 0;
  uStack_5a0 = 0xf;
  uStack_5b4 = 0;
  FUN_005542c0("zh-cn",5);
  uStack_8._0_1_ = 0x50;
  uStack_58c = 0;
  uStack_588 = 0xf;
  uStack_59c = 0;
  FUN_005542c0("zh-sg",5);
  uStack_8._0_1_ = 0x51;
  uStack_74 = 0;
  uStack_70 = 0;
  uStack_6c = 0;
  FUN_00604490(auStack_5e4,auStack_584,uStack_14);
  uStack_8._0_1_ = 0x52;
  FUN_0054ef60(auStack_194);
  uStack_8._0_1_ = 0x53;
  FUN_00637260(&uStack_74);
  FUN_00577a40();
  uStack_8._0_1_ = 0x56;
  FUN_016f32d1(auStack_5e4,0x18,4,FUN_005507b0);
  uStack_8._0_1_ = 0x57;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x57;
  if (0xf < uStack_180) {
    uVar3 = uStack_180 + 1;
    uVar2 = auStack_194[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_194[0] - 4);
      uVar3 = uStack_180 + 0x24;
      if (0x1f < (auStack_194[0] - uVar2) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_184 = 0;
  uStack_180 = 0xf;
  auStack_194[0] = auStack_194[0] & 0xffffff00;
  uStack_19c = 0;
  uStack_198 = 0xf;
  auStack_1ac[0] = auStack_1ac[0] & 0xffffff00;
  FUN_005542c0("zh-tw",5);
  uStack_8._0_1_ = 0x58;
  uStack_634 = 0;
  uStack_630 = 0xf;
  auStack_644[0] = 0;
  FUN_005542c0("zh-hk",5);
  uStack_8._0_1_ = 0x59;
  uStack_61c = 0;
  uStack_618 = 0xf;
  uStack_62c = 0;
  FUN_005542c0("zh-hans",7);
  uStack_8._0_1_ = 0x5a;
  uStack_604 = 0;
  uStack_600 = 0xf;
  uStack_614 = 0;
  FUN_005542c0("zh-cn",5);
  uStack_8._0_1_ = 0x5b;
  uStack_5ec = 0;
  uStack_5e8 = 0xf;
  uStack_5fc = 0;
  FUN_005542c0("zh-sg",5);
  uStack_8._0_1_ = 0x5c;
  uStack_80 = 0;
  uStack_7c = 0;
  uStack_78 = 0;
  FUN_00604490(auStack_644,auStack_5e4,uStack_14);
  uStack_8._0_1_ = 0x5d;
  FUN_0054ef60(auStack_1ac);
  uStack_8._0_1_ = 0x5e;
  FUN_00637260(&uStack_80);
  FUN_00577a40();
  uStack_8._0_1_ = 0x61;
  FUN_016f32d1(auStack_644,0x18,4,FUN_005507b0);
  uStack_8._0_1_ = 0x62;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x62;
  if (0xf < uStack_198) {
    uVar3 = uStack_198 + 1;
    uVar2 = auStack_1ac[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_1ac[0] - 4);
      uVar3 = uStack_198 + 0x24;
      if (0x1f < (auStack_1ac[0] - uVar2) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_19c = 0;
  uStack_198 = 0xf;
  auStack_1ac[0] = auStack_1ac[0] & 0xffffff00;
  uStack_244 = 0;
  uStack_240 = 0xf;
  auStack_254[0] = 0;
  FUN_005542c0("zh-cjv",6);
  uStack_8._0_1_ = 99;
  uStack_6c4 = 0;
  uStack_6c0 = 0xf;
  auStack_6d4[0] = 0;
  FUN_005542c0("zh-hans",7);
  uStack_8._0_1_ = 100;
  uStack_6ac = 0;
  uStack_6a8 = 0xf;
  uStack_6bc = 0;
  FUN_005542c0("zh-cn",5);
  uStack_8._0_1_ = 0x65;
  uStack_694 = 0;
  uStack_690 = 0xf;
  uStack_6a4 = 0;
  FUN_005542c0("zh-sg",5);
  uStack_8._0_1_ = 0x66;
  uStack_67c = 0;
  uStack_678 = 0xf;
  uStack_68c = 0;
  FUN_005542c0("zh-hant",7);
  uStack_8._0_1_ = 0x67;
  uStack_664 = 0;
  uStack_660 = 0xf;
  uStack_674 = 0;
  FUN_005542c0("zh-tw",5);
  uStack_8._0_1_ = 0x68;
  uStack_64c = 0;
  uStack_648 = 0xf;
  uStack_65c = 0;
  FUN_005542c0("zh-hk",5);
  uStack_8._0_1_ = 0x69;
  uStack_8c = 0;
  uStack_88 = 0;
  uStack_84 = 0;
  FUN_00604490(auStack_6d4,auStack_644,uStack_14);
  uStack_8._0_1_ = 0x6a;
  FUN_0054ef60(auStack_254);
  uStack_8._0_1_ = 0x6b;
  FUN_00637260(&uStack_8c);
  FUN_00577a40();
  uStack_8._0_1_ = 0x6e;
  FUN_016f32d1(auStack_6d4,0x18,6,FUN_005507b0);
  uStack_8._0_1_ = 0x6f;
  FUN_005507b0();
  uStack_25c = 0;
  uStack_258 = 0xf;
  auStack_26c[0] = 0;
  FUN_005542c0("pt-br",5);
  uStack_8._0_1_ = 0x70;
  uStack_1b4 = 0;
  uStack_1b0 = 0xf;
  auStack_1c4[0] = 0;
  FUN_005542c0("pt-pt",5);
  uStack_8._0_1_ = 0x71;
  uStack_98 = 0;
  uStack_94 = 0;
  uStack_90 = 0;
  FUN_00604490(auStack_1c4,auStack_1ac,uStack_14);
  uStack_8._0_1_ = 0x72;
  FUN_0054ef60(auStack_26c);
  uStack_8._0_1_ = 0x73;
  FUN_00637260(&uStack_98);
  FUN_00577a40();
  uStack_8._0_1_ = 0x76;
  FUN_016f32d1(auStack_1c4,0x18,1,FUN_005507b0);
  uStack_8._0_1_ = 0x77;
  FUN_005507b0();
  uStack_274 = 0;
  uStack_270 = 0xf;
  auStack_284[0] = 0;
  FUN_005542c0("pt-pt",5);
  uStack_8._0_1_ = 0x78;
  uStack_1cc = 0;
  uStack_1c8 = 0xf;
  auStack_1dc[0] = 0;
  FUN_005542c0("pt-br",5);
  uStack_8._0_1_ = 0x79;
  uStack_a4 = 0;
  uStack_a0 = 0;
  uStack_9c = 0;
  FUN_00604490(auStack_1dc,auStack_1c4,uStack_14);
  uStack_8._0_1_ = 0x7a;
  FUN_0054ef60(auStack_284);
  uStack_8._0_1_ = 0x7b;
  FUN_00637260(&uStack_a4);
  FUN_00577a40();
  uStack_8._0_1_ = 0x7e;
  FUN_016f32d1(auStack_1dc,0x18,1,FUN_005507b0);
  uStack_8._0_1_ = 0x7f;
  FUN_005507b0();
  uStack_28c = 0;
  uStack_288 = 0xf;
  auStack_29c[0] = 0;
  FUN_005542c0("es-mx",5);
  uStack_8._0_1_ = 0x80;
  uStack_1e4 = 0;
  uStack_1e0 = 0xf;
  auStack_1f4[0] = 0;
  FUN_005542c0("es-es",5);
  uStack_8._0_1_ = 0x81;
  uStack_b0 = 0;
  uStack_ac = 0;
  uStack_a8 = 0;
  FUN_00604490(auStack_1f4,auStack_1dc,uStack_14);
  uStack_8._0_1_ = 0x82;
  FUN_0054ef60(auStack_29c);
  uStack_8._0_1_ = 0x83;
  FUN_00637260(&uStack_b0);
  FUN_00577a40();
  uStack_8._0_1_ = 0x86;
  FUN_016f32d1(auStack_1f4,0x18,1,FUN_005507b0);
  uStack_8._0_1_ = 0x87;
  FUN_005507b0();
  uStack_2a4 = 0;
  uStack_2a0 = 0xf;
  auStack_2b4[0] = 0;
  FUN_005542c0("es-es",5);
  uStack_8._0_1_ = 0x88;
  uStack_1fc = 0;
  uStack_1f8 = 0xf;
  auStack_20c[0] = 0;
  FUN_005542c0("es-mx",5);
  uStack_8._0_1_ = 0x89;
  uStack_bc = 0;
  uStack_b8 = 0;
  uStack_b4 = 0;
  FUN_00604490(auStack_20c,auStack_1f4,uStack_14);
  uStack_8._0_1_ = 0x8a;
  FUN_0054ef60(auStack_2b4);
  uStack_8._0_1_ = 0x8b;
  FUN_00637260(&uStack_bc);
  FUN_00577a40();
  uStack_8._0_1_ = 0x8e;
  FUN_016f32d1(auStack_20c,0x18,1,FUN_005507b0);
  uStack_8._0_1_ = 0x8f;
  FUN_005507b0();
  uStack_2bc = 0;
  uStack_2b8 = 0xf;
  auStack_2cc[0] = 0;
  FUN_005542c0("fr-fr",5);
  uStack_8._0_1_ = 0x90;
  uStack_214 = 0;
  uStack_210 = 0xf;
  auStack_224[0] = 0;
  FUN_005542c0("fr-ca",5);
  uStack_8._0_1_ = 0x91;
  uStack_c8 = 0;
  uStack_c4 = 0;
  uStack_c0 = 0;
  FUN_00604490(auStack_224,auStack_20c,uStack_14);
  uStack_8._0_1_ = 0x92;
  FUN_0054ef60(auStack_2cc);
  uStack_8._0_1_ = 0x93;
  FUN_00637260(&uStack_c8);
  FUN_00577a40();
  uStack_8._0_1_ = 0x96;
  FUN_016f32d1(auStack_224,0x18,1,FUN_005507b0);
  uStack_8._0_1_ = 0x97;
  FUN_005507b0();
  uStack_2d4 = 0;
  uStack_2d0 = 0xf;
  auStack_2e4[0] = 0;
  FUN_005542c0("fr-ca",5);
  uStack_8._0_1_ = 0x98;
  uStack_22c = 0;
  uStack_228 = 0xf;
  auStack_23c[0] = 0;
  FUN_005542c0("fr-fr",5);
  uStack_8._0_1_ = 0x99;
  uStack_d4 = 0;
  uStack_d0 = 0;
  uStack_cc = 0;
  FUN_00604490(auStack_23c,auStack_224,uStack_14);
  uStack_8._0_1_ = 0x9a;
  FUN_0054ef60(auStack_2e4);
  uStack_8._0_1_ = 0x9b;
  FUN_00637260(&uStack_d4);
  FUN_00577a40();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x9e);
  FUN_016f32d1(auStack_23c,0x18,1,FUN_005507b0);
  FUN_005507b0();
  uStack_8 = 0xa0;
  FUN_00fd3340(auStack_914,auStack_6d4);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(auStack_914,0x24,0x10,FUN_00fd39f0);
  FUN_016f3654(&LAB_018aacc0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2316 ; VA 0x0053e7b0 ; FUN_0053e7b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0053e7b0(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184f43a;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_02151218;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00fd0780(uVar2,&DAT_02151218);
  FUN_009cb790(uVar1,s_GetContents_021518f8,0,CONCAT44(puVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02151668 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LocalizationTable,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(void),0>
       ::vftable;
  _DAT_021516a0 = FUN_00fd8f20;
  _DAT_021516a4 = 0;
  _DAT_0215168c = FUN_0088cb40();
  FUN_016f3654(&LAB_018aacd0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2317 ; VA 0x0053e850 ; FUN_0053e850 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0053e850(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184f45a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00fd0780(uVar2,0);
  FUN_009cb790(uVar1,s_GetEntries_021517ac,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02151218 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LocalizationTable,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02151250 = FUN_00fd8f40;
  _DAT_02151254 = 0;
  _DAT_0215123c = FUN_008882f0();
  FUN_016f3654(&LAB_018aace0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2318 ; VA 0x0053e8f0 ; FUN_0053e8f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0053e8f0(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184f48e;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_02151520;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00fd0780(uVar2,&DAT_02151520);
  FUN_009cb790(uVar1,s_GetString_021518a0,0,CONCAT44(puVar3,uVar2),0);
  _DAT_02151568 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LocalizationTable,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),2>
       ::vftable;
  _DAT_021515a0 = FUN_00fd9a80;
  _DAT_021515a4 = 0;
  _DAT_021515a8 = 0;
  _DAT_021515ac = 0;
  uStack_8 = 2;
  FUN_008f20f0();
  FUN_016f3654(&LAB_018aacf0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2319 ; VA 0x0053e9b0 ; FUN_0053e9b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0053e9b0(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184f4ec;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00fd0780();
  FUN_009cb790(uVar2,s_GetTranslator_02151880,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02151520 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LocalizationTable,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),1>
       ::vftable;
  _DAT_02151558 = FUN_00fd9b50;
  _DAT_0215155c = 0;
  DAT_02151560 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02151544 = FUN_0088cdc0();
  iVar1 = DAT_02151560;
  if (DAT_02151560 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_localeId_021517cc);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018aad10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2320 ; VA 0x0053eb60 ; FUN_0053eb60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0053eb60(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184f528;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00fd0780(uVar2,0);
  FUN_009cb790(uVar1,s_RemoveEntry_02151860,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02151488 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LocalizationTable,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),3>
       ::vftable;
  _DAT_021514c0 = FUN_00fda820;
  _DAT_021514c4 = 0;
  _DAT_021514c8 = 0;
  _DAT_021514cc = 0;
  _DAT_021514d0 = 0;
  uStack_8 = 3;
  FUN_00fd6af0(&DAT_0211f870,s_source_02119484,s_context_02126688);
  FUN_016f3654(&LAB_018aad30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2321 ; VA 0x0053ec30 ; FUN_0053ec30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0053ec30(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184f572;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00fd0780(uVar2,0);
  FUN_009cb790(uVar1,s_RemoveEntryValue_0215184c,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02151438 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LocalizationTable,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),4>
       ::vftable;
  _DAT_02151470 = FUN_00fda9e0;
  _DAT_02151474 = 0;
  _DAT_02151478 = 0;
  _DAT_0215147c = 0;
  _DAT_02151480 = 0;
  _DAT_02151484 = 0;
  uStack_8 = 4;
  FUN_00fd66e0(&DAT_0211f870,s_source_02119484,s_context_02126688,s_localeId_021517cc);
  FUN_016f3654(&LAB_018aad60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2322 ; VA 0x0053ed10 ; FUN_0053ed10 */

void FUN_0053ed10(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00fd3090(FUN_00fda8e0,0,s_RemoveKey_02130930,&DAT_0211f870,0,CONCAT44(&DAT_02151488,uStack_10)
               ,0);
  FUN_016f3654(&LAB_018aada0);
  return;
}



/* FUNCTION 2323 ; VA 0x0053ed70 ; FUN_0053ed70 */

void FUN_0053ed70(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00fd3090(FUN_00fdaad0,0,s_RemoveTargetLocale_0215186c,s_localeId_021517cc,0,uStack_10,0);
  FUN_016f3654(&LAB_018aadc0);
  return;
}



/* FUNCTION 2324 ; VA 0x0053edd0 ; FUN_0053edd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0053edd0(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  undefined4 uStack_20;
  undefined *puStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184f5cc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = CONCAT31(uStack_20._1_3_,1);
  puStack_1c = &DAT_02151258;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00fd0780();
  FUN_009cb790(uVar2,s_SetContents_02151910,0,CONCAT44(puStack_1c,uStack_20),0);
  _DAT_021516a8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LocalizationTable,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_021516e0 = FUN_00fdaf20;
  _DAT_021516e4 = 0;
  DAT_021516e8 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_021516cc = FUN_00888530();
  iVar1 = DAT_021516e8;
  if (DAT_021516e8 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_contents_02151904);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018aade0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2325 ; VA 0x0053ef80 ; FUN_0053ef80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0053ef80(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184f62c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00fd0780();
  FUN_009cb790(uVar1,s_SetEntries_021517c0,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02151258 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LocalizationTable,void___cdecl(class_RBX::Reflection::Variant_const&),1>
       ::vftable;
  _DAT_02151290 = FUN_00fdb2a0;
  _DAT_02151294 = 0;
  DAT_02151298 = (undefined4 *)0x0;
  uStack_8 = 1;
  _DAT_0215127c = FUN_00888530();
  puVar4 = DAT_02151298;
  if (DAT_02151298 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = *DAT_02151298;
    puStack_ec = (undefined4 *)0x0;
    puVar2 = (undefined4 *)DAT_02151298[1];
    if (puVar2 != (undefined4 *)0x0) {
      (*(code *)*puVar2)();
      puVar2 = (undefined4 *)puVar4[1];
    }
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
    puStack_ec = puVar2;
  }
  uVar1 = FUN_00888410();
  uVar3 = FUN_0086e3d0(s_entries_021517b8);
  FUN_00888b30(uVar3,uVar1,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_ec != (undefined4 *)0x0) {
      (*(code *)puStack_ec[2])(auStack_e8);
    }
  }
  FUN_016f3654(FUN_018aae00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2326 ; VA 0x0053f130 ; FUN_0053f130 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0053f130(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184f668;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_021512a0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00fd0780(uVar2,&DAT_021512a0);
  FUN_009cb790(uVar1,s_SetEntry_0215191c,0,CONCAT44(puVar3,uVar2),0);
  _DAT_021516f0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LocalizationTable,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),3>
       ::vftable;
  _DAT_02151728 = FUN_00fdbfd0;
  _DAT_0215172c = 0;
  _DAT_02151730 = 0;
  _DAT_02151734 = 0;
  _DAT_02151738 = 0;
  uStack_8 = 3;
  FUN_00fd6af0(&DAT_0211f870,s_targetLocaleId_02151890,&DAT_02126680);
  FUN_016f3654(&LAB_018aae70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2327 ; VA 0x0053f200 ; FUN_0053f200 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0053f200(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184f6b2;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00fd0780(uVar2,0);
  FUN_009cb790(uVar1,s_SetEntryContext_02151824,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02151398 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LocalizationTable,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),4>
       ::vftable;
  _DAT_021513d0 = FUN_00fdc190;
  _DAT_021513d4 = 0;
  _DAT_021513d8 = 0;
  _DAT_021513dc = 0;
  _DAT_021513e0 = 0;
  _DAT_021513e4 = 0;
  uStack_8 = 4;
  FUN_00fd66e0(&DAT_0211f870,s_source_02119484,s_context_02126688,s_newContext_02151818);
  FUN_016f3654(&LAB_018aaea0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2328 ; VA 0x0053f2e0 ; FUN_0053f2e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0053f2e0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184f6f2;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00fd0780(uVar2,0);
  FUN_009cb790(uVar1,s_SetEntryExample_0215183c,0,CONCAT44(uVar3,uVar2),0);
  _DAT_021513e8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LocalizationTable,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),4>
       ::vftable;
  _DAT_02151420 = FUN_00fdc3d0;
  _DAT_02151424 = 0;
  _DAT_02151428 = 0;
  _DAT_0215142c = 0;
  _DAT_02151430 = 0;
  _DAT_02151434 = 0;
  uStack_8 = 4;
  FUN_00fd66e0(&DAT_0211f870,s_source_02119484,s_context_02126688,s_example_02151834);
  FUN_016f3654(&LAB_018aaee0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2329 ; VA 0x0053f3c0 ; FUN_0053f3c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0053f3c0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184f732;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00fd0780(uVar2,0);
  FUN_009cb790(uVar1,s_SetEntryKey_021517f0,0,CONCAT44(uVar3,uVar2),0);
  _DAT_021512f8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LocalizationTable,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),4>
       ::vftable;
  _DAT_02151330 = FUN_00fdc3f0;
  _DAT_02151334 = 0;
  _DAT_02151338 = 0;
  _DAT_0215133c = 0;
  _DAT_02151340 = 0;
  _DAT_02151344 = 0;
  uStack_8 = 4;
  FUN_00fd66e0(&DAT_0211f870,s_source_02119484,s_context_02126688,s_newKey_021517e8);
  FUN_016f3654(&LAB_018aaf20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2330 ; VA 0x0053f4a0 ; FUN_0053f4a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0053f4a0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184f772;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00fd0780(uVar2,0);
  FUN_009cb790(uVar1,s_SetEntrySource_02151808,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02151348 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LocalizationTable,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),4>
       ::vftable;
  _DAT_02151380 = FUN_00fdc630;
  _DAT_02151384 = 0;
  _DAT_02151388 = 0;
  _DAT_0215138c = 0;
  _DAT_02151390 = 0;
  _DAT_02151394 = 0;
  uStack_8 = 4;
  FUN_00fd66e0(&DAT_0211f870,s_source_02119484,s_context_02126688,s_newSource_021517fc);
  FUN_016f3654(&LAB_018aaf60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2331 ; VA 0x0053f580 ; FUN_0053f580 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0053f580(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184f7bc;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00fd0780(uVar2,0);
  FUN_009cb790(uVar1,s_SetEntryValue_021517d8,0,CONCAT44(uVar3,uVar2),0);
  _DAT_021512a0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LocalizationTable,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),5>
       ::vftable;
  _DAT_021512d8 = FUN_00fdc8d0;
  _DAT_021512dc = 0;
  _DAT_021512e0 = 0;
  _DAT_021512e4 = 0;
  _DAT_021512e8 = 0;
  _DAT_021512ec = 0;
  _DAT_021512f0 = 0;
  uStack_8 = 5;
  FUN_00fd61d0(&DAT_0211f870,s_source_02119484,s_context_02126688,s_localeId_021517cc,&DAT_02126680)
  ;
  FUN_016f3654(&LAB_018aafa0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2332 ; VA 0x0053f670 ; FUN_0053f670 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0053f670(void)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184f81c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00fd0780();
  FUN_009cb790(uVar2,s_SetIsExemptFromUGCAnalytics_021518ac,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_021515b0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::LocalizationTable,void___cdecl(bool),1>::vftable;
  _DAT_021515e8 = FUN_00fdd090;
  _DAT_021515ec = 0;
  DAT_021515f0 = (undefined *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_021515d4 = FUN_00888530();
  puVar1 = DAT_021515f0;
  if (DAT_021515f0 == (undefined *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088daf0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar1;
    iStack_ec = FUN_005c9ef0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(s_value_0211ab70);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018aafe0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2333 ; VA 0x0053f990 ; FUN_0053f990 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0053f990(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184f84c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00fd0780();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::LocalizationTable,bool>::
              GetSetImpl<bool_(__thiscall_RBX::LocalizationTable::*)(void)const_,void_(__thiscall_RBX::LocalizationTable::*)(bool)>
              ::vftable;
    puVar3[2] = &LAB_00fd9770;
    puVar3[3] = 0;
    puVar3[4] = FUN_00fdd090;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_IsExemptFromUGCAnalytics_021518c8,s_Localization_021263c8,uStack_24,0,0
               ,2,0,0,0);
  DAT_021515f8 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0215162c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0215161c = _DAT_0215161c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_021515f8[2])();
    if (cVar1 != '\0') {
      _DAT_0215161c = _DAT_0215161c & 0xfffffff3;
    }
  }
  DAT_021515f8 = RBX::Reflection::PropDescriptor<class_RBX::LocalizationTable,bool>::vftable;
  FUN_016f3654(&LAB_018ab040);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2334 ; VA 0x00540460 ; FUN_00540460 */

void __fastcall FUN_00540460(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_00943750();
  DAT_01f2e4f4 = uVar1;
  FUN_0093dc90(uVar1,param_1);
  _guard_check_icall(&DAT_01f2e4f4,uVar1,uVar1);
  FUN_016f3654(FUN_018ab2a0);
  return;
}



/* FUNCTION 2335 ; VA 0x005405c0 ; FUN_005405c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005405c0(void)

{
  undefined uVar1;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_30;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018d0474,1);
  uStack_8 = 0;
  uVar1 = 0;
  FUN_005542c0("AppStorageResetId",0x11);
  uStack_8 = 0xffffffff;
  _DAT_01f2e544 = FUN_0153ec90(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2336 ; VA 0x00540670 ; FUN_00540670 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00540670(void)

{
  undefined uVar1;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_30;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  uVar1 = 0;
  FUN_005542c0("DataModelPatchConfig",0x14);
  uStack_8 = 0xffffffff;
  _DAT_01f2e540 = FUN_0153ec90(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2337 ; VA 0x00541670 ; FUN_00541670 */

void FUN_00541670(void)

{
  double dVar1;
  
  dVar1 = DAT_018ce308;
  FUN_017267a0();
  DAT_01f2ecb4 = (float)dVar1 * DAT_018ce2f4;
  return;
}



/* FUNCTION 2338 ; VA 0x005416a0 ; FUN_005416a0 */

void FUN_005416a0(void)

{
  double dVar1;
  
  dVar1 = DAT_018ce308;
  FUN_017267a0();
  DAT_01f2ecb0 = (float)dVar1 * DAT_018ce328;
  return;
}



/* FUNCTION 2339 ; VA 0x00541710 ; FUN_00541710 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00541710(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("ABTestControllerListener",0x18);
  _DAT_01f2ede8 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 2340 ; VA 0x005417a0 ; FUN_005417a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005417a0(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("AllUsers.Authentication.EmailUpsellAtLogout",0x2b);
  uStack_8 = 0;
  _DAT_01f2ed8c = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 4;
  puStack_20 = &DAT_01f2ed8c;
  puStack_1c = &DAT_01d70f90;
  _DAT_01f2ed90 = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x164) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2341 ; VA 0x00541890 ; FUN_00541890 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00541890(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("AllUsers.GameDetails.PlayWithFriends",0x24);
  uStack_8 = 0;
  _DAT_01f2ed44 = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 4;
  puStack_20 = &DAT_01f2ed44;
  puStack_1c = &DAT_01d70f00;
  _DAT_01f2ed48 = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x164) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2342 ; VA 0x00541980 ; FUN_00541980 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00541980(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("AllUsers.GameDetails.UseAbbreviatedDescription",0x2e);
  uStack_8 = 0;
  _DAT_01f2ed50 = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 4;
  puStack_20 = &DAT_01f2ed50;
  puStack_1c = &DAT_01d70f18;
  _DAT_01f2ed54 = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x164) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2343 ; VA 0x00541a70 ; FUN_00541a70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00541a70(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("AllUsers.GameSearch.Autocomplete",0x20);
  uStack_8 = 0;
  _DAT_01f2ed5c = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 4;
  puStack_20 = &DAT_01f2ed5c;
  puStack_1c = &DAT_01d70f30;
  _DAT_01f2ed60 = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x164) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2344 ; VA 0x00541b60 ; FUN_00541b60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00541b60(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("AllUsers.GameSearch.AutocompleteV2",0x22);
  uStack_8 = 0;
  _DAT_01f2ed68 = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 4;
  puStack_20 = &DAT_01f2ed68;
  puStack_1c = &DAT_01d70f48;
  _DAT_01f2ed6c = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x164) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2345 ; VA 0x00541c50 ; FUN_00541c50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00541c50(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("AllUsers.GameSearch.FeaturedGamePlayButton",0x2a);
  uStack_8 = 0;
  _DAT_01f2ed98 = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 4;
  puStack_20 = &DAT_01f2ed98;
  puStack_1c = &DAT_01d70fa8;
  _DAT_01f2ed9c = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x164) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2346 ; VA 0x00541d40 ; FUN_00541d40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00541d40(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("AllUsers.GameSearch.Q2DRankingEmphasisHideBad",0x2d);
  uStack_8 = 0;
  _DAT_01f2ed38 = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 4;
  puStack_20 = &DAT_01f2ed38;
  puStack_1c = &DAT_01d70ee8;
  _DAT_01f2ed3c = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x164) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2347 ; VA 0x00541e30 ; FUN_00541e30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00541e30(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("AllUsers.LuaApp.FeaturedGameTileInSearch",0x28);
  uStack_8 = 0;
  _DAT_01f2ed2c = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 4;
  puStack_20 = &DAT_01f2ed2c;
  puStack_1c = &DAT_01d70ed0;
  _DAT_01f2ed30 = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x164) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2348 ; VA 0x00541f20 ; FUN_00541f20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00541f20(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("AllUsers.LuaApp.GameDetailsPeekView",0x23);
  uStack_8 = 0;
  _DAT_01f2ed20 = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 4;
  puStack_20 = &DAT_01f2ed20;
  puStack_1c = &DAT_01d70eb8;
  _DAT_01f2ed24 = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x164) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2349 ; VA 0x00542010 ; FUN_00542010 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00542010(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("AllUsers.LuaApp.MorePageLayoutListGrid",0x26);
  uStack_8 = 0;
  _DAT_01f2ede0 = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 4;
  puStack_20 = &DAT_01f2ede0;
  puStack_1c = &DAT_01d71038;
  _DAT_01f2ede4 = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x164) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2350 ; VA 0x00542100 ; FUN_00542100 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00542100(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("AllUsers.LuaChat.PlayTogether",0x1d);
  uStack_8 = 0;
  _DAT_01f2edd4 = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 4;
  puStack_20 = &DAT_01f2edd4;
  puStack_1c = &DAT_01d71020;
  _DAT_01f2edd8 = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x164) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2351 ; VA 0x005421f0 ; FUN_005421f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005421f0(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("AllUsers.LuaChat.ShareGameToChatFromChat",0x28);
  uStack_8 = 0;
  _DAT_01f2edc8 = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 4;
  puStack_20 = &DAT_01f2edc8;
  puStack_1c = &DAT_01d71008;
  _DAT_01f2edcc = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x164) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2352 ; VA 0x005422e0 ; FUN_005422e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005422e0(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("AllUsers.Payments.U13PurchaseCombinedABTest",0x2b);
  uStack_8 = 0;
  _DAT_01f2ed14 = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 4;
  puStack_20 = &DAT_01f2ed14;
  puStack_1c = &DAT_01d70ea0;
  _DAT_01f2ed18 = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x164) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2353 ; VA 0x005423d0 ; FUN_005423d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005423d0(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("Android.Authentication.EmailUpsellLogout",0x28);
  uStack_8 = 0;
  _DAT_01f2ed74 = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 4;
  puStack_20 = &DAT_01f2ed74;
  puStack_1c = &DAT_01d70f60;
  _DAT_01f2ed78 = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x164) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2354 ; VA 0x005424c0 ; FUN_005424c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005424c0(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("Android.Authentication.LuaLoginAndSignup4",0x29);
  uStack_8 = 0;
  _DAT_01f2eccc = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 1;
  puStack_20 = &DAT_01f2eccc;
  puStack_1c = &DAT_01d70e10;
  _DAT_01f2ecd0 = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x138) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2355 ; VA 0x005425b0 ; FUN_005425b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005425b0(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("Avatar.Experience.Landing.Page",0x1e);
  uStack_8 = 0;
  _DAT_01f2ece4 = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 4;
  puStack_20 = &DAT_01f2ece4;
  puStack_1c = &DAT_01d70e40;
  _DAT_01f2ece8 = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x164) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2356 ; VA 0x005426a0 ; FUN_005426a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005426a0(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("Avatar.Experience.RecommendedCategory",0x25);
  uStack_8 = 0;
  _DAT_01f2ecf0 = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 4;
  puStack_20 = &DAT_01f2ecf0;
  puStack_1c = &DAT_01d70e58;
  _DAT_01f2ecf4 = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x164) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2357 ; VA 0x00542790 ; FUN_00542790 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00542790(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("GlobalUsers.GameSorts.GameGrid",0x1e);
  uStack_8 = 0;
  _DAT_01f2ecfc = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 4;
  puStack_20 = &DAT_01f2ecfc;
  puStack_1c = &DAT_01d70e70;
  _DAT_01f2ed00 = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x164) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2358 ; VA 0x00542880 ; FUN_00542880 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00542880(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("GlobalUsers.GameSorts.GameGridV2",0x20);
  uStack_8 = 0;
  _DAT_01f2ed08 = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 4;
  puStack_20 = &DAT_01f2ed08;
  puStack_1c = &DAT_01d70e88;
  _DAT_01f2ed0c = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x164) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2359 ; VA 0x00542970 ; FUN_00542970 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00542970(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("GlobalUsers.LuaApp.HideGameStats",0x20);
  uStack_8 = 0;
  _DAT_01f2eda4 = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 4;
  puStack_20 = &DAT_01f2eda4;
  puStack_1c = &DAT_01d70fc0;
  _DAT_01f2eda8 = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x164) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2360 ; VA 0x00542a60 ; FUN_00542a60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00542a60(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("GlobalUsers.LuaApp.SpotlightTile",0x20);
  uStack_8 = 0;
  _DAT_01f2edb0 = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 4;
  puStack_20 = &DAT_01f2edb0;
  puStack_1c = &DAT_01d70fd8;
  _DAT_01f2edb4 = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x164) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2361 ; VA 0x00542b50 ; FUN_00542b50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00542b50(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("AllUsers.GameExperience.InGameMenu",0x22);
  uStack_8 = 0;
  _DAT_01f2edbc = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 4;
  puStack_20 = &DAT_01f2edbc;
  puStack_1c = &DAT_01d70ff0;
  _DAT_01f2edc0 = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x164) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2362 ; VA 0x00542c40 ; FUN_00542c40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00542c40(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("Ios.Authentication.EmailUpsellLogout",0x24);
  uStack_8 = 0;
  _DAT_01f2ed80 = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 4;
  puStack_20 = &DAT_01f2ed80;
  puStack_1c = &DAT_01d70f78;
  _DAT_01f2ed84 = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x164) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2363 ; VA 0x00543330 ; FUN_00543330 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00543330(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("iOS.Authentication.LuaLoginAndSignup4",0x25);
  uStack_8 = 0;
  _DAT_01f2ecd8 = 0;
  iVar1 = FUN_010d3520();
  uStack_24 = 1;
  puStack_20 = &DAT_01f2ecd8;
  puStack_1c = &DAT_01d70e28;
  _DAT_01f2ecdc = iVar1;
  iVar2 = FUN_010d06f0(auStack_3c,&uStack_24);
  FUN_010d0cf0(auStack_18,0,iVar2 + 0x10,iVar2);
  *(undefined *)(iVar1 + 0x138) = 0;
  if (0xf < uStack_28) {
    uVar4 = uStack_28 + 1;
    uVar3 = auStack_3c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_3c[0] - 4);
      uVar4 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2364 ; VA 0x00543440 ; FUN_00543440 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00543440(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01857264;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  DAT_01f2efd8 = FUN_008ed990(0,0);
  DAT_01f2efe0 = 0;
  _DAT_01f2efe4 = 0;
  _DAT_01f2efe8 = 0;
  uStack_8 = 1;
  _DAT_01f2efd4 = 0x3f800000;
  FUN_005cb500(8);
  FUN_016f3654(&LAB_018ac010);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2365 ; VA 0x00543760 ; FUN_00543760 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00543760(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd8;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd8 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_010e3920(uVar2,0);
  FUN_009cb970(uVar1,s_Triggered_02136f1c,1,CONCAT44(uVar3,uVar2),0);
  _DAT_02151ae4 = 0xe4;
  _DAT_02151ab0 =
       RBX::Reflection::
       EventDesc<class_RBX::PluginAction,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::PluginAction::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_02151ad8 = 0;
  _DAT_02151adc = 0;
  _DAT_02151ae0 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_02151ab0 =
       RBX::Reflection::
       EventDesc<class_RBX::PluginAction,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::PluginAction::*>
       ::vftable;
  FUN_016f3654(&LAB_018ac090);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2366 ; VA 0x00543bc0 ; FUN_00543bc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00543bc0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0185771a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_010e42d0(uVar2,0);
  FUN_009cb790(uVar1,s_Clear_0212a19c,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02151cb8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PluginMenu,void___cdecl(void),0>::vftable;
  _DAT_02151cf0 = FUN_010e50d0;
  _DAT_02151cf4 = 0;
  _DAT_02151cdc = FUN_00888530();
  FUN_016f3654(&LAB_018ac1c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2367 ; VA 0x00543c60 ; FUN_00543c60 */

void FUN_00543c60(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_010e43b0(FUN_010e4790,0,s_AddAction_02151d38,s_action_0211cfc8,1,uStack_10,0);
  FUN_016f3654(&LAB_018ac1d0);
  return;
}



/* FUNCTION 2368 ; VA 0x00543cc0 ; FUN_00543cc0 */

void FUN_00543cc0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_010e43b0(FUN_010e49f0,0,s_AddMenu_02151d5c,&DAT_02151d54,1,uStack_10,0);
  FUN_016f3654(&LAB_018ac220);
  return;
}



/* FUNCTION 2369 ; VA 0x00543d20 ; FUN_00543d20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00543d20(void)

{
  char cVar1;
  undefined4 uVar2;
  char *pcVar3;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0185776f;
  pvStack_10 = ExceptionList;
  pcVar3 = &DAT_0211fa6e;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  uStack_8 = 0;
  uVar2 = FUN_010e42d0();
  FUN_009cb790(uVar2,s_AddNewAction_02151d44,1,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02151be0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::PluginMenu,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),3>
       ::vftable;
  _DAT_02151c18 = FUN_010e4c40;
  _DAT_02151c1c = 0;
  _DAT_02151c20 = 0;
  _DAT_02151c24 = 0;
  uStack_8._0_1_ = 3;
  iStack_14 = FUN_01674e20(0x18);
  uStack_8._0_1_ = 4;
  if (iStack_14 == 0) {
    _DAT_02151c28 = 0;
  }
  else {
    _DAT_02151c28 = FUN_0054ef60(auStack_38);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_010e51a0(s_actionId_0214dac8,&DAT_02126680,&DAT_0214dae8);
  if (0xf < uStack_24) {
    if (0xfff < uStack_24 + 1) {
      if (0x1f < (auStack_38[0] - *(int *)(auStack_38[0] - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  FUN_016f3654(&LAB_018ac270);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2370 ; VA 0x00543e80 ; FUN_00543e80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00543e80(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0185778a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_010e42d0(uVar2,0);
  FUN_009cb790(uVar1,s_AddSeparator_02151d64,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02151c78 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PluginMenu,void___cdecl(void),0>::vftable;
  _DAT_02151cb0 = FUN_010e4e70;
  _DAT_02151cb4 = 0;
  _DAT_02151c9c = FUN_00888530();
  FUN_016f3654(&LAB_018ac2a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2371 ; VA 0x00543f20 ; FUN_00543f20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00543f20(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018577aa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_010e42d0(uVar2,0);
  FUN_009cb820(uVar1,s_ShowAsync_02151d74,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02151cf8 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::PluginMenu,class_std::shared_ptr<class_RBX::Instance>___cdecl(void),0>
       ::vftable;
  _DAT_02151d30 = FUN_010e59a0;
  _DAT_02151d34 = 0;
  _DAT_02151d1c = FUN_0088cdc0();
  FUN_016f3654(&LAB_018ac2b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2372 ; VA 0x00543fd0 ; FUN_00543fd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00543fd0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0185797c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_010e5be0();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::DockWidgetPluginGui,bool>::
              GetImpl<bool_(__thiscall_RBX::DockWidgetPluginGui::*)(void)const_>::vftable;
    puVar3[2] = &LAB_010e5ea0;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_HostWidgetWasRestored_02151db8,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02151d80 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02151db4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02151da4 = _DAT_02151da4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02151d80[2])();
    if (cVar1 != '\0') {
      _DAT_02151da4 = _DAT_02151da4 & 0xfffffff3;
    }
  }
  DAT_02151d80 = RBX::Reflection::PropDescriptor<class_RBX::DockWidgetPluginGui,bool>::vftable;
  FUN_016f3654(&LAB_018ac2d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2373 ; VA 0x00544170 ; FUN_00544170 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00544170(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01857b40;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x15;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf874) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf874,uVar3,0,0,0x15);
    if (DAT_01edf874 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01edf850 = RBX::Reflection::RefType<class_RBX::Instance*>::vftable;
      FUN_016f3654(&LAB_018813c0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01edf874);
    }
  }
  uVar2 = FUN_010e6840();
  FUN_009ca670(uVar2,&DAT_01edf850,s_FocusedDataModelSession_02151e7c,&DAT_021197d4,uVar3,uVar4,
               uVar5,uVar6,5,5,0);
  uStack_8 = 1;
  DAT_02151dd0 = RBX::Reflection::
                 RefPropDescriptor<class_RBX::MultipleDocumentInterfaceInstance,class_RBX::Instance>
                 ::vftable;
  _DAT_02151e04 =
       RBX::Reflection::
       RefPropDescriptor<class_RBX::MultipleDocumentInterfaceInstance,class_RBX::Instance>::vftable;
  DAT_02151e08 = (undefined4 *)FUN_01674e20(0x10);
  if (DAT_02151e08 == (undefined4 *)0x0) {
    DAT_02151e08 = (undefined4 *)0x0;
  }
  else {
    *DAT_02151e08 =
         RBX::Reflection::
         PropDescriptor<class_RBX::MultipleDocumentInterfaceInstance,class_RBX::Instance*>::
         GetImpl<class_RBX::DataModelSession*_(__thiscall_RBX::MultipleDocumentInterfaceInstance::*)(void)const_>
         ::vftable;
    DAT_02151e08[2] = FUN_010e7100;
    DAT_02151e08[3] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_02151dd0[3])();
  if (cVar1 != '\0') {
    _DAT_02151df4 = _DAT_02151df4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02151dd0[2])();
  if (cVar1 != '\0') {
    _DAT_02151df4 = _DAT_02151df4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018ac3d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2374 ; VA 0x00544340 ; FUN_00544340 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00544340(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd8;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd8 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_010e7fc0(uVar2,0);
  FUN_009cb970(uVar1,s_CurrentDataModelTypeChanged_02152088,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02151fbc = 0x88;
  _DAT_02151f88 =
       RBX::Reflection::
       EventDesc<class_RBX::DataModelSession,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::DataModelSession::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_02151fb0 = 0;
  _DAT_02151fb4 = 0;
  _DAT_02151fb8 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_02151f88 =
       RBX::Reflection::
       EventDesc<class_RBX::DataModelSession,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::DataModelSession::*>
       ::vftable;
  FUN_016f3654(&LAB_018ac410);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2375 ; VA 0x00544490 ; FUN_00544490 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00544490(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01857d04;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ec0920();
  uVar3 = FUN_010e7fc0();
  FUN_009ca670(uVar3,uVar2,s_CurrentDataModelType_0215203c,&DAT_021197d4,uStack_24,0,0,0x15,5,5,1);
  uStack_8 = 0;
  DAT_02151f10 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::DataModelSession,enum_RBX::StudioGameStateType>::
                 vftable;
  _DAT_02151f44 = uVar2;
  DAT_02151f48 = (undefined4 *)FUN_01674e20(0x10);
  if (DAT_02151f48 == (undefined4 *)0x0) {
    DAT_02151f48 = (undefined4 *)0x0;
  }
  else {
    *DAT_02151f48 =
         RBX::Reflection::PropDescriptor<class_RBX::DataModelSession,enum_RBX::StudioGameStateType>
         ::GetImpl<enum_RBX::StudioGameStateType_(__thiscall_RBX::DataModelSession::*)(void)const_>
         ::vftable;
    DAT_02151f48[2] = FUN_010e9180;
    DAT_02151f48[3] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02151f4c = FUN_00ec0920();
  cVar1 = (*(code *)DAT_02151f10[3])();
  if (cVar1 != '\0') {
    _DAT_02151f34 = _DAT_02151f34 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02151f10[2])();
  if (cVar1 != '\0') {
    _DAT_02151f34 = _DAT_02151f34 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018ac440);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2376 ; VA 0x005445a0 ; FUN_005445a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005445a0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01857d2c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_010e7fc0();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::DataModelSession,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_(__thiscall_RBX::DataModelSession::*)(void)const_>
              ::vftable;
    puVar3[2] = FUN_00926ad0;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,s_SessionId_02152030,&DAT_021197d4,uStack_24,0,0,0x15,5,5,0);
  DAT_02151ed8 = RBX::Reflection::
                 TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02151f0c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02151efc = _DAT_02151efc & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02151ed8[2])();
    if (cVar1 != '\0') {
      _DAT_02151efc = _DAT_02151efc & 0xfffffff3;
    }
  }
  DAT_02151ed8 = RBX::Reflection::
                 PropDescriptor<class_RBX::DataModelSession,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  FUN_016f3654(&LAB_018ac460);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2377 ; VA 0x00544810 ; FUN_00544810 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00544810(void)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  void **ppvVar4;
  undefined auStack_328 [8];
  void *pvStack_320;
  undefined uStack_31c;
  undefined4 uStack_30c;
  undefined4 uStack_308;
  undefined4 uStack_304;
  undefined uStack_300;
  undefined4 uStack_2f0;
  undefined4 uStack_2ec;
  undefined4 uStack_2e8;
  undefined uStack_2e4;
  undefined4 uStack_2d4;
  undefined4 uStack_2d0;
  undefined4 uStack_2cc;
  undefined uStack_2c8;
  undefined4 uStack_2b8;
  undefined4 uStack_2b4;
  undefined4 uStack_2b0;
  undefined uStack_2ac;
  undefined4 uStack_29c;
  undefined4 uStack_298;
  undefined4 uStack_294;
  undefined uStack_290;
  undefined4 uStack_280;
  undefined4 uStack_27c;
  undefined4 uStack_278;
  undefined uStack_274;
  undefined4 uStack_264;
  undefined4 uStack_260;
  undefined4 uStack_25c;
  undefined uStack_258;
  undefined4 uStack_248;
  undefined4 uStack_244;
  undefined4 uStack_240;
  undefined uStack_23c;
  undefined4 uStack_22c;
  undefined4 uStack_228;
  undefined4 uStack_224;
  undefined uStack_220;
  undefined4 uStack_210;
  undefined4 uStack_20c;
  undefined4 uStack_208;
  undefined uStack_204;
  undefined4 uStack_1f4;
  undefined4 uStack_1f0;
  undefined4 uStack_1ec;
  undefined uStack_1e8;
  undefined4 uStack_1d8;
  undefined4 uStack_1d4;
  undefined4 uStack_1d0;
  undefined uStack_1cc;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined uStack_1b0;
  undefined4 uStack_1a0;
  undefined4 uStack_19c;
  undefined4 uStack_198;
  undefined uStack_194;
  undefined4 uStack_184;
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined uStack_178;
  undefined4 uStack_168;
  undefined4 uStack_164;
  undefined4 uStack_160;
  undefined uStack_15c;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined4 uStack_144;
  undefined uStack_140;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined uStack_124;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined uStack_108;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined uStack_ec;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined uStack_d0;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined uStack_b4;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined uStack_98;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined uStack_7c;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined uStack_60;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined uStack_44;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined uStack_28;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01858524;
  pvStack_10 = ExceptionList;
  pvStack_320 = (void *)0x18;
  uStack_30c = 0;
  uStack_308 = 0xf;
  uStack_31c = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0("Animation",9);
  uStack_8 = 0;
  uStack_304 = 0x37;
  uStack_2f0 = 0;
  uStack_2ec = 0xf;
  uStack_300 = 0;
  FUN_005542c0("WalkAnimation",0xd);
  uStack_8._0_1_ = 1;
  uStack_2e8 = 0x35;
  uStack_2d4 = 0;
  uStack_2d0 = 0xf;
  uStack_2e4 = 0;
  FUN_005542c0("RunAnimation",0xc);
  uStack_8._0_1_ = 2;
  uStack_2cc = 0x32;
  uStack_2b8 = 0;
  uStack_2b4 = 0xf;
  uStack_2c8 = 0;
  FUN_005542c0("FallAnimation",0xd);
  uStack_8._0_1_ = 3;
  uStack_2b0 = 0x34;
  uStack_29c = 0;
  uStack_298 = 0xf;
  uStack_2ac = 0;
  FUN_005542c0("JumpAnimation",0xd);
  uStack_8._0_1_ = 4;
  uStack_294 = 0x36;
  uStack_280 = 0;
  uStack_27c = 0xf;
  uStack_290 = 0;
  FUN_005542c0("SwimAnimation",0xd);
  uStack_8._0_1_ = 5;
  uStack_278 = 0x30;
  uStack_264 = 0;
  uStack_260 = 0xf;
  uStack_274 = 0;
  FUN_005542c0("ClimbAnimation",0xe);
  uStack_8._0_1_ = 6;
  uStack_25c = 0x33;
  uStack_248 = 0;
  uStack_244 = 0xf;
  uStack_258 = 0;
  FUN_005542c0("IdleAnimation",0xd);
  uStack_8._0_1_ = 7;
  uStack_240 = 0x29;
  uStack_22c = 0;
  uStack_228 = 0xf;
  uStack_23c = 0;
  FUN_005542c0("HairAccessory",0xd);
  uStack_8._0_1_ = 8;
  uStack_224 = 0x2a;
  uStack_210 = 0;
  uStack_20c = 0xf;
  uStack_220 = 0;
  FUN_005542c0("FaceAccessory",0xd);
  uStack_8._0_1_ = 9;
  uStack_208 = 0x2b;
  uStack_1f4 = 0;
  uStack_1f0 = 0xf;
  uStack_204 = 0;
  FUN_005542c0("NeckAccessory",0xd);
  uStack_8._0_1_ = 10;
  uStack_1ec = 0x2c;
  uStack_1d8 = 0;
  uStack_1d4 = 0xf;
  uStack_1e8 = 0;
  FUN_005542c0("ShoulderAccessory",0x11);
  uStack_8._0_1_ = 0xb;
  uStack_1d0 = 0x2d;
  uStack_1bc = 0;
  uStack_1b8 = 0xf;
  uStack_1cc = 0;
  FUN_005542c0("FrontAccessory",0xe);
  uStack_8._0_1_ = 0xc;
  uStack_1b4 = 0x2e;
  uStack_1a0 = 0;
  uStack_19c = 0xf;
  uStack_1b0 = 0;
  FUN_005542c0("BackAccessory",0xd);
  uStack_8._0_1_ = 0xd;
  uStack_198 = 0x2f;
  uStack_184 = 0;
  uStack_180 = 0xf;
  uStack_194 = 0;
  FUN_005542c0("WaistAccessory",0xe);
  uStack_8._0_1_ = 0xe;
  uStack_17c = 0x39;
  uStack_168 = 0;
  uStack_164 = 0xf;
  uStack_178 = 0;
  FUN_005542c0("EarAccessory",0xc);
  uStack_8._0_1_ = 0xf;
  uStack_160 = 0x3a;
  uStack_14c = 0;
  uStack_148 = 0xf;
  uStack_15c = 0;
  FUN_005542c0("EyeAccessory",0xc);
  uStack_8._0_1_ = 0x10;
  uStack_144 = 0xb;
  uStack_130 = 0;
  uStack_12c = 0xf;
  uStack_140 = 0;
  FUN_005542c0("Shirt",5);
  uStack_8._0_1_ = 0x11;
  uStack_128 = 0xc;
  uStack_114 = 0;
  uStack_110 = 0xf;
  uStack_124 = 0;
  FUN_005542c0("Pants",5);
  uStack_8._0_1_ = 0x12;
  uStack_10c = 2;
  uStack_f8 = 0;
  uStack_f4 = 0xf;
  uStack_108 = 0;
  FUN_005542c0("TeeShirt",8);
  uStack_8._0_1_ = 0x13;
  uStack_f0 = 0x12;
  uStack_dc = 0;
  uStack_d8 = 0xf;
  uStack_ec = 0;
  FUN_005542c0(&DAT_01981ccc,4);
  uStack_8._0_1_ = 0x14;
  uStack_d4 = 0x13;
  uStack_c0 = 0;
  uStack_bc = 0xf;
  uStack_d0 = 0;
  FUN_005542c0(&DAT_01992af4,4);
  uStack_8._0_1_ = 0x15;
  uStack_b8 = 0x11;
  uStack_a4 = 0;
  uStack_a0 = 0xf;
  uStack_b4 = 0;
  FUN_005542c0(&DAT_018db5cc,4);
  uStack_8._0_1_ = 0x16;
  uStack_9c = 0x1b;
  uStack_88 = 0;
  uStack_84 = 0xf;
  uStack_98 = 0;
  FUN_005542c0("Torso",5);
  uStack_8._0_1_ = 0x17;
  uStack_80 = 0x1c;
  uStack_6c = 0;
  uStack_68 = 0xf;
  uStack_7c = 0;
  FUN_005542c0("RightArm",8);
  uStack_8._0_1_ = 0x18;
  uStack_64 = 0x1d;
  uStack_50 = 0;
  uStack_4c = 0xf;
  uStack_60 = 0;
  FUN_005542c0("LeftArm",7);
  uStack_8._0_1_ = 0x19;
  uStack_48 = 0x1e;
  uStack_34 = 0;
  uStack_30 = 0xf;
  uStack_44 = 0;
  FUN_005542c0("LeftLeg",7);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x1a);
  uStack_2c = 0x1f;
  uStack_18 = 0;
  uStack_14 = 0xf;
  uStack_28 = 0;
  FUN_005542c0("RightLeg",8);
  uStack_8 = 0x1b;
  _DAT_01f2fee0 = 0;
  DAT_01f2fee4 = (int *)0x0;
  DAT_01f2fee8 = 0;
  DAT_01f2fee4 = (int *)FUN_00616d10(0,0);
  DAT_01f2feec = 0;
  _DAT_01f2fef0 = 0;
  _DAT_01f2fef4 = 0;
  uStack_8._0_1_ = 0x1d;
  _DAT_01f2fee0 = 0x3f800000;
  FUN_005cb500(8);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x1e);
  ppvVar4 = &pvStack_320;
  do {
    iVar1 = *DAT_01f2fee4;
    puVar2 = *(undefined4 **)(iVar1 + 4);
    uVar3 = FUN_00a4e720(iVar1,puVar2,ppvVar4);
    if (DAT_01f2fee8 == 0x71c71c6) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    DAT_01f2fee8 = DAT_01f2fee8 + 1;
    *(undefined4 *)(iVar1 + 4) = uVar3;
    *puVar2 = uVar3;
    FUN_010ee7a0(auStack_328,*DAT_01f2fee4 + 8,*DAT_01f2fee4);
    ppvVar4 = ppvVar4 + 7;
  } while (ppvVar4 != &pvStack_10);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&pvStack_320,0x1c,0x1c,FUN_0056c780);
  FUN_016f3654(&LAB_018ac650);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2378 ; VA 0x00545b70 ; FUN_00545b70 */

void FUN_00545b70(void)

{
  undefined auStack_7 [3];
  
  FUN_0115e8a0(auStack_7);
  return;
}



/* FUNCTION 2379 ; VA 0x00545be0 ; FUN_00545be0 */

void FUN_00545be0(void)

{
  undefined auStack_7 [3];
  
  FUN_0115e8a0(auStack_7);
  return;
}



/* FUNCTION 2380 ; VA 0x00545c00 ; FUN_00545c00 */

void FUN_00545c00(void)

{
  undefined auStack_7 [3];
  
  FUN_0115e8a0(auStack_7);
  return;
}



/* FUNCTION 2381 ; VA 0x00545c20 ; FUN_00545c20 */

void __fastcall FUN_00545c20(byte param_1)

{
  undefined auStack_8 [3];
  undefined uStack_5;
  
  _auStack_8 = CONCAT13(0x8b,CONCAT21(0,param_1));
  FUN_0115e8a0(auStack_8 + 1);
  return;
}



/* FUNCTION 2382 ; VA 0x00545c40 ; FUN_00545c40 */

void FUN_00545c40(void)

{
  undefined auStack_7 [3];
  
  FUN_0115e8a0(auStack_7);
  return;
}



/* FUNCTION 2383 ; VA 0x00545c60 ; FUN_00545c60 */

void FUN_00545c60(void)

{
  undefined auStack_7 [3];
  
  FUN_0115e8a0(auStack_7);
  return;
}



/* FUNCTION 2384 ; VA 0x00545c80 ; FUN_00545c80 */

void FUN_00545c80(void)

{
  undefined auStack_7 [3];
  
  FUN_0115e8a0(auStack_7);
  return;
}



/* FUNCTION 2385 ; VA 0x00545ca0 ; FUN_00545ca0 */

void FUN_00545ca0(void)

{
  undefined auStack_7 [3];
  
  FUN_0115e8a0(auStack_7);
  return;
}



/* FUNCTION 2386 ; VA 0x00545cc0 ; FUN_00545cc0 */

void FUN_00545cc0(void)

{
  undefined auStack_7 [3];
  
  FUN_0115e8a0(auStack_7);
  return;
}



/* FUNCTION 2387 ; VA 0x00545ce0 ; FUN_00545ce0 */

void FUN_00545ce0(void)

{
  undefined auStack_7 [3];
  
  FUN_0115e8a0(auStack_7);
  return;
}



/* FUNCTION 2388 ; VA 0x00545d00 ; FUN_00545d00 */

void FUN_00545d00(void)

{
  undefined auStack_7 [3];
  
  FUN_0115e8a0(auStack_7);
  return;
}



/* FUNCTION 2389 ; VA 0x00545d20 ; FUN_00545d20 */

void FUN_00545d20(void)

{
  undefined auStack_7 [3];
  
  FUN_0115e8a0(auStack_7);
  return;
}



/* FUNCTION 2390 ; VA 0x00545d40 ; FUN_00545d40 */

void FUN_00545d40(void)

{
  undefined auStack_7 [3];
  
  FUN_0115e8a0(auStack_7);
  return;
}



/* FUNCTION 2391 ; VA 0x00545d60 ; FUN_00545d60 */

void FUN_00545d60(void)

{
  undefined auStack_7 [3];
  
  FUN_0115e8a0(auStack_7);
  return;
}



/* FUNCTION 2392 ; VA 0x005462a0 ; FUN_005462a0 */

/* WARNING: Removing unreachable block (ram,0x005462cf) */
/* WARNING: Removing unreachable block (ram,0x005462b1) */

void FUN_005462a0(void)

{
  int *piVar1;
  bool bVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  
  piVar1 = (int *)cpuid_basic_info(0);
  if (0 < *piVar1) {
    iVar3 = cpuid_Version_info(1);
    if (((*(uint *)(iVar3 + 8) & 0x6000000) == 0x6000000) && ((*(uint *)(iVar3 + 0xc) & 1) != 0)) {
      bVar2 = true;
      goto LAB_005462fd;
    }
  }
  bVar2 = false;
LAB_005462fd:
  puVar4 = (undefined4 *)&DAT_019ff258;
  if (!bVar2) {
    puVar4 = &DAT_019ff2f8;
  }
  puVar5 = &DAT_01f51460;
  for (iVar3 = 0x28; iVar3 != 0; iVar3 = iVar3 + -1) {
    *puVar5 = *puVar4;
    puVar4 = puVar4 + 1;
    puVar5 = puVar5 + 1;
  }
  return;
}



/* FUNCTION 2393 ; VA 0x00546320 ; FUN_00546320 */

void FUN_00546320(void)

{
  int iVar1;
  undefined4 uStack_18;
  undefined4 uStack_8;
  
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  *(undefined4 *)(iVar1 + 8) = 0;
  *(undefined4 *)(iVar1 + 0xc) = uStack_18;
  *(undefined4 *)(iVar1 + 0x10) = 0;
  *(undefined4 *)(iVar1 + 0x14) = 0;
  *(ulonglong *)(iVar1 + 0x18) = (ulonglong)uStack_8 << 0x20;
  return;
}



/* FUNCTION 2394 ; VA 0x005473e0 ; FUN_005473e0 */

void FUN_005473e0(void)

{
  code *pcVar1;
  int iVar2;
  int iVar3;
  int iStack_c;
  undefined4 uStack_8;
  
  iVar2 = TlsAlloc();
  if (iVar2 == -1) {
    iVar3 = GetLastError();
    uStack_8 = FUN_01685730();
    iStack_c = iVar3;
    if (iVar3 != 0) {
      FUN_013d0850(&iStack_c,&DAT_01a3eddc);
      pcVar1 = (code *)swi(3);
      (*pcVar1)();
      return;
    }
  }
  DAT_01f6d7dc = iVar2;
  FUN_016f3654(&LAB_018af060);
  return;
}



/* FUNCTION 2395 ; VA 0x00547440 ; FUN_00547440 */

void FUN_00547440(void)

{
  code *pcVar1;
  int iVar2;
  int iVar3;
  int iStack_c;
  undefined4 uStack_8;
  
  iVar2 = TlsAlloc();
  if (iVar2 == -1) {
    iVar3 = GetLastError();
    uStack_8 = FUN_01685730();
    iStack_c = iVar3;
    if (iVar3 != 0) {
      FUN_013d0850(&iStack_c,&DAT_01a3eddc);
      pcVar1 = (code *)swi(3);
      (*pcVar1)();
      return;
    }
  }
  DAT_01f6d758 = iVar2;
  FUN_016f3654(&LAB_018af070);
  return;
}



/* FUNCTION 2396 ; VA 0x00547590 ; FUN_00547590 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00547590(void)

{
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_18 = _DAT_01a426d0;
  uStack_14 = _UNK_01a426d4;
  uStack_10 = _UNK_01a426d8;
  uStack_c = _UNK_01a426dc;
  FUN_006b9390(&uStack_18,&uStack_8,uStack_8);
  FUN_016f3654(&LAB_018af260);
  return;
}



/* FUNCTION 2397 ; VA 0x005475d0 ; FUN_005475d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_005475d0(void)

{
  int iVar1;
  int iVar2;
  undefined auStack_194 [400];
  
  FUN_016f3654(&LAB_018aef90);
  LOCK();
  iVar2 = DAT_01f6d75c + 1;
  UNLOCK();
  iVar1 = DAT_01f6d75c + 1;
  DAT_01f6d75c = iVar2;
  if (iVar1 == 1) {
    iVar2 = Ordinal_115(2,auStack_194);
    LOCK();
    UNLOCK();
    iVar1 = DAT_01f6d760;
    DAT_01f6d760 = iVar2;
  }
  _DAT_01f6d710 = &DAT_01f6d739;
  return iVar1;
}



/* FUNCTION 2398 ; VA 0x005476b0 ; FUN_005476b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_005476b0(void)

{
  int iVar1;
  int iVar2;
  undefined auStack_194 [400];
  
  FUN_016f3654(&LAB_018af320);
  LOCK();
  iVar2 = DAT_01f6d75c + 1;
  UNLOCK();
  iVar1 = DAT_01f6d75c + 1;
  DAT_01f6d75c = iVar2;
  if (iVar1 == 1) {
    iVar2 = Ordinal_115(2,auStack_194);
    LOCK();
    UNLOCK();
    iVar1 = DAT_01f6d760;
    DAT_01f6d760 = iVar2;
  }
  _DAT_01f6d960 = &DAT_01f6d988;
  return iVar1;
}



/* FUNCTION 2399 ; VA 0x00547790 ; FUN_00547790 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_00547790(void)

{
  int iVar1;
  int iVar2;
  undefined auStack_194 [400];
  
  FUN_016f3654(&LAB_018af340);
  LOCK();
  iVar2 = DAT_01f6d75c + 1;
  UNLOCK();
  iVar1 = DAT_01f6d75c + 1;
  DAT_01f6d75c = iVar2;
  if (iVar1 == 1) {
    iVar2 = Ordinal_115(2,auStack_194);
    LOCK();
    UNLOCK();
    iVar1 = DAT_01f6d760;
    DAT_01f6d760 = iVar2;
  }
  _DAT_01f6d98c = &DAT_01f6d9b4;
  return iVar1;
}



/* FUNCTION 2400 ; VA 0x00547910 ; FUN_00547910 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00547910(void)

{
  undefined auStack_2c [16];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0186ee03;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0("plugin",6);
  uStack_8 = 0;
  _DAT_01f6db94 = 0;
  _DAT_01f6db98 = 0;
  _DAT_01f6db9c = 0;
  FUN_00604490(auStack_2c,&uStack_14,uStack_14);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(auStack_2c,0x18,1,FUN_005507b0);
  FUN_016f3654(&LAB_018af3c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2401 ; VA 0x00547a00 ; FUN_00547a00 */

void FUN_00547a00(void)

{
  undefined auStack_a4 [132];
  char cStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0186f3d3;
  pvStack_10 = ExceptionList;
  cStack_20 = '\t';
  puStack_1c = &DAT_01d798c8;
  uStack_8 = 1;
  puStack_18 = &DAT_01d798c8;
  ExceptionList = &pvStack_10;
  (*(code *)PTR_FUN_01a60e08)(auStack_a4,&puStack_18);
  DAT_01d79950 = 0;
  uStack_8 = 2;
  if (-1 < cStack_20) {
    uStack_11 = 0;
    (*(code *)(&PTR__guard_check_icall_01a60e14)[cStack_20])(auStack_a4,&uStack_11);
  }
  FUN_016f3654(FUN_018af3d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2402 ; VA 0x00547aa0 ; FUN_00547aa0 */

void FUN_00547aa0(void)

{
  undefined4 *puVar1;
  undefined4 auStack_a8 [33];
  char cStack_24;
  undefined *puStack_20;
  undefined *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0186f3f3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_0147b9b0();
  auStack_a8[0] = *puVar1;
  cStack_24 = '\x03';
  puStack_20 = &DAT_01f6dbb8;
  DAT_01f6dc3c = 0xff;
  uStack_8 = 1;
  puStack_18 = &DAT_01f6dbb8;
  (*(code *)PTR_FUN_01a60df0)(auStack_a8,&puStack_18);
  DAT_01f6dc40 = 0;
  uStack_8 = 2;
  if (-1 < cStack_24) {
    uStack_11 = 0;
    (*(code *)(&PTR__guard_check_icall_01a60e14)[cStack_24])(auStack_a8,&uStack_11);
  }
  FUN_016f3654(FUN_018af430);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2403 ; VA 0x00547b60 ; FUN_00547b60 */

void FUN_00547b60(void)

{
  undefined4 auStack_a4 [33];
  char cStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0186f3d3;
  pvStack_10 = ExceptionList;
  auStack_a4[0] = 0;
  cStack_20 = '\x04';
  puStack_1c = &DAT_01d79718;
  uStack_8 = 1;
  puStack_18 = &DAT_01d79718;
  ExceptionList = &pvStack_10;
  (*(code *)PTR_FUN_01a60df4)(auStack_a4,&puStack_18);
  DAT_01d797a0 = 0;
  uStack_8 = 2;
  if (-1 < cStack_20) {
    uStack_11 = 0;
    (*(code *)(&PTR__guard_check_icall_01a60e14)[cStack_20])(auStack_a4,&uStack_11);
  }
  FUN_016f3654(FUN_018af490);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2404 ; VA 0x00547c10 ; FUN_00547c10 */

void FUN_00547c10(void)

{
  undefined4 auStack_a4 [33];
  char cStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0186f3d3;
  pvStack_10 = ExceptionList;
  auStack_a4[0] = 2;
  cStack_20 = '\x04';
  puStack_1c = &DAT_01d797a8;
  uStack_8 = 1;
  puStack_18 = &DAT_01d797a8;
  ExceptionList = &pvStack_10;
  (*(code *)PTR_FUN_01a60df4)(auStack_a4,&puStack_18);
  DAT_01d79830 = 0;
  uStack_8 = 2;
  if (-1 < cStack_20) {
    uStack_11 = 0;
    (*(code *)(&PTR__guard_check_icall_01a60e14)[cStack_20])(auStack_a4,&uStack_11);
  }
  FUN_016f3654(FUN_018af4f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2405 ; VA 0x00547cc0 ; FUN_00547cc0 */

void FUN_00547cc0(void)

{
  undefined4 auStack_a4 [33];
  char cStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0186f3d3;
  pvStack_10 = ExceptionList;
  auStack_a4[0] = 3;
  cStack_20 = '\x04';
  puStack_1c = &DAT_01d79838;
  uStack_8 = 1;
  puStack_18 = &DAT_01d79838;
  ExceptionList = &pvStack_10;
  (*(code *)PTR_FUN_01a60df4)(auStack_a4,&puStack_18);
  DAT_01d798c0 = 0;
  uStack_8 = 2;
  if (-1 < cStack_20) {
    uStack_11 = 0;
    (*(code *)(&PTR__guard_check_icall_01a60e14)[cStack_20])(auStack_a4,&uStack_11);
  }
  FUN_016f3654(FUN_018af550);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2406 ; VA 0x00547f30 ; FUN_00547f30 */

void FUN_00547f30(void)

{
  undefined auStack_38 [28];
  char cStack_1c;
  undefined *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  cStack_1c = '\x05';
  uStack_8 = 0;
  puStack_18 = &DAT_01d799e8;
  ExceptionList = &pvStack_10;
  (*(code *)PTR_FUN_01a61014)(auStack_38,&puStack_18);
  DAT_01d79a08 = 1;
  uStack_8 = 1;
  if (-1 < cStack_1c) {
    uStack_11 = 0;
    (**(code **)(&UNK_01a60fe8 + cStack_1c * 4))(auStack_38,&uStack_11);
  }
  FUN_016f3654(FUN_018af5c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2407 ; VA 0x00548fa0 ; FUN_00548fa0 */

void __fastcall FUN_00548fa0(undefined4 param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01870412;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01674e20(0x318,param_1);
  uStack_8 = 0;
  if (iVar1 == 0) {
    DAT_01f6deec = 0;
  }
  else {
    DAT_01f6deec = FUN_014d12d0(iVar1);
  }
  FUN_016f3654(&DAT_018b0860);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2408 ; VA 0x00549200 ; FUN_00549200 */

void FUN_00549200(void)

{
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined uStack_c;
  undefined4 uStack_8;
  
  uStack_40 = 0xff000000;
  uStack_3c = 8;
  uStack_44 = 0x7f000000;
  uStack_34 = 0xff000000;
  uStack_30 = 8;
  uStack_38 = 0xa000000;
  uStack_28 = 0xfff00000;
  uStack_24 = 0xc;
  uStack_2c = 0xac100000;
  uStack_1c = 0xffff0000;
  uStack_18 = 0x10;
  uStack_20 = 0xc0a80000;
  uStack_10 = 0xffff0000;
  uStack_c = 0x10;
  uStack_14 = 0xa9fe0000;
  FUN_014db170(&uStack_44,&uStack_8,uStack_8);
  FUN_016f3654(&LAB_018b08d0);
  return;
}



/* FUNCTION 2409 ; VA 0x00549290 ; FUN_00549290 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00549290(void)

{
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined2 uStack_34;
  undefined uStack_32;
  undefined4 uStack_31;
  undefined4 uStack_2d;
  undefined4 uStack_29;
  undefined4 uStack_25;
  undefined2 uStack_21;
  undefined uStack_1f;
  undefined4 uStack_1e;
  undefined4 uStack_1a;
  undefined4 uStack_16;
  undefined4 uStack_12;
  undefined2 uStack_e;
  undefined uStack_c;
  undefined auStack_b [3];
  undefined4 uStack_8;
  
  uStack_44 = _DAT_01a85770;
  uStack_40 = _UNK_01a85774;
  uStack_3c = _UNK_01a85778;
  uStack_38 = _UNK_01a8577c;
  uStack_34 = 0x1080;
  uStack_31 = _DAT_01a85780;
  uStack_2d = _UNK_01a85784;
  uStack_29 = _UNK_01a85788;
  uStack_25 = _UNK_01a8578c;
  uStack_32 = 0xff;
  uStack_21 = 0x107;
  uStack_1f = 0xfe;
  uStack_e = 0x20a;
  uStack_c = 0xc0;
  uStack_1e = _DAT_01a85790;
  uStack_1a = _UNK_01a85794;
  uStack_16 = _UNK_01a85798;
  uStack_12 = _UNK_01a8579c;
  FUN_014db240(&uStack_44,auStack_b,uStack_8);
  FUN_016f3654(&LAB_018b08e0);
  return;
}



/* FUNCTION 2410 ; VA 0x00549300 ; FUN_00549300 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00549300(void)

{
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined2 uStack_44;
  undefined uStack_42;
  undefined4 uStack_41;
  undefined4 uStack_3d;
  undefined4 uStack_39;
  undefined4 uStack_35;
  undefined2 uStack_31;
  undefined uStack_2f;
  undefined4 uStack_2e;
  undefined4 uStack_2a;
  undefined4 uStack_26;
  undefined4 uStack_22;
  undefined2 uStack_1e;
  undefined uStack_1c;
  undefined4 uStack_1b;
  undefined4 uStack_17;
  undefined4 uStack_13;
  undefined4 uStack_f;
  undefined2 uStack_b;
  undefined uStack_9;
  undefined4 uStack_8;
  
  uStack_54 = _DAT_01a857a0;
  uStack_50 = _UNK_01a857a4;
  uStack_4c = _UNK_01a857a8;
  uStack_48 = _UNK_01a857ac;
  uStack_44 = 0xc60;
  uStack_41 = _DAT_01a857b0;
  uStack_3d = _UNK_01a857b4;
  uStack_39 = _UNK_01a857b8;
  uStack_35 = _UNK_01a857bc;
  uStack_42 = 0xff;
  uStack_31 = 0xc60;
  uStack_2f = 0xff;
  uStack_2e = _DAT_01a857c0;
  uStack_2a = _UNK_01a857c4;
  uStack_26 = _UNK_01a857c8;
  uStack_22 = _UNK_01a857cc;
  uStack_1e = 0xc60;
  uStack_1c = 0xff;
  uStack_b = 0xc60;
  uStack_9 = 0xff;
  uStack_1b = _DAT_01a857d0;
  uStack_17 = _UNK_01a857d4;
  uStack_13 = _UNK_01a857d8;
  uStack_f = _UNK_01a857dc;
  FUN_014db240(&uStack_54,&uStack_8,uStack_8);
  FUN_016f3654(&LAB_018b08f0);
  return;
}



/* FUNCTION 2411 ; VA 0x00549c50 ; FUN_00549c50 */

void __fastcall FUN_00549c50(undefined4 param_1)

{
  undefined *puVar1;
  
  puVar1 = (undefined *)FUN_01674e20(0x4c,param_1);
  if (puVar1 != (undefined *)0x0) {
    *(undefined4 *)(puVar1 + 0x10) = 0;
    *(undefined4 *)(puVar1 + 0x14) = 0xf;
    *puVar1 = 0;
    *(undefined4 *)(puVar1 + 0x28) = 0;
    *(undefined4 *)(puVar1 + 0x2c) = 0xf;
    puVar1[0x18] = 0;
    *(undefined4 *)(puVar1 + 0x30) = 0;
    *(undefined4 *)(puVar1 + 0x34) = 0;
    *(undefined4 *)(puVar1 + 0x38) = 0;
    *(undefined4 *)(puVar1 + 0x3c) = 0;
    DAT_01f6f66c = puVar1;
    *(undefined8 *)(puVar1 + 0x40) = 0;
    *(undefined4 *)(puVar1 + 0x48) = 0;
    puVar1[0x30] = 0;
    puVar1[0x48] = 0;
    return;
  }
  DAT_01f6f66c = (undefined *)0x0;
  return;
}



/* FUNCTION 2412 ; VA 0x0054b0b0 ; FUN_0054b0b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0054b0b0(void)

{
  undefined uVar1;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_30;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  uVar1 = 0;
  FUN_005542c0("AppInstallationId",0x11);
  uStack_8 = 0xffffffff;
  _DAT_01f757f4 = FUN_0153ec90(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2413 ; VA 0x0054b160 ; FUN_0054b160 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0054b160(void)

{
  undefined uVar1;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_30;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  uVar1 = 0;
  FUN_005542c0("AppParams",9);
  uStack_8 = 0xffffffff;
  _DAT_01f757d0 = FUN_0153ec90(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2414 ; VA 0x0054b210 ; FUN_0054b210 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0054b210(void)

{
  undefined uVar1;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_30;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0("light",5);
  uStack_8 = 0;
  uVar1 = 0;
  FUN_005542c0("AuthenticatedTheme",0x12);
  uStack_8 = 0xffffffff;
  _DAT_01f757c4 = FUN_0153ec90(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2415 ; VA 0x0054b2c0 ; FUN_0054b2c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0054b2c0(void)

{
  undefined uVar1;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_30;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_01a8e604,2);
  uStack_8 = 0;
  uVar1 = 0;
  FUN_005542c0("BrowserTrackerId",0x10);
  uStack_8 = 0xffffffff;
  _DAT_01f757e0 = FUN_0153ec90(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2416 ; VA 0x0054b370 ; FUN_0054b370 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0054b370(void)

{
  undefined uVar1;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_30;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  uVar1 = 0;
  FUN_005542c0("CountryCode",0xb);
  uStack_8 = 0xffffffff;
  _DAT_01f757e4 = FUN_0153ec90(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2417 ; VA 0x0054b420 ; FUN_0054b420 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0054b420(void)

{
  undefined uVar1;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_30;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  uVar1 = 0;
  FUN_005542c0("CredentialValue",0xf);
  uStack_8 = 0xffffffff;
  _DAT_01f757f8 = FUN_0153ec90(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2418 ; VA 0x0054b4d0 ; FUN_0054b4d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0054b4d0(void)

{
  undefined uVar1;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_30;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  uVar1 = 0;
  FUN_005542c0("DisplayName",0xb);
  uStack_8 = 0xffffffff;
  _DAT_01f757f0 = FUN_0153ec90(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2419 ; VA 0x0054b580 ; FUN_0054b580 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0054b580(void)

{
  undefined uVar1;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_30;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  uVar1 = 0;
  FUN_005542c0("GameLocaleId",0xc);
  uStack_8 = 0xffffffff;
  _DAT_01f757d4 = FUN_0153ec90(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2420 ; VA 0x0054b630 ; FUN_0054b630 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0054b630(void)

{
  undefined uVar1;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_30;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  uVar1 = 0;
  FUN_005542c0("IsUnder13",9);
  uStack_8 = 0xffffffff;
  _DAT_01f757c8 = FUN_0153ec90(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2421 ; VA 0x0054b6e0 ; FUN_0054b6e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0054b6e0(void)

{
  undefined uVar1;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_30;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  uVar1 = 0;
  FUN_005542c0("Membership",10);
  uStack_8 = 0xffffffff;
  _DAT_01f757d8 = FUN_0153ec90(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2422 ; VA 0x0054b790 ; FUN_0054b790 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0054b790(void)

{
  undefined uVar1;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_30;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018d0474,1);
  uStack_8 = 0;
  uVar1 = 0;
  FUN_005542c0("NativeCloseLuaPromptDisplayCount",0x20);
  uStack_8 = 0xffffffff;
  _DAT_01f757dc = FUN_0153ec90(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2423 ; VA 0x0054b840 ; FUN_0054b840 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0054b840(void)

{
  undefined uVar1;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_30;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  uVar1 = 0;
  FUN_005542c0("RobloxLocaleId",0xe);
  uStack_8 = 0xffffffff;
  _DAT_01f75804 = FUN_0153ec90(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2424 ; VA 0x0054b8f0 ; FUN_0054b8f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0054b8f0(void)

{
  undefined uVar1;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_30;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_01a8e604,2);
  uStack_8 = 0;
  uVar1 = 0;
  FUN_005542c0("UserId",6);
  uStack_8 = 0xffffffff;
  _DAT_01f757ec = FUN_0153ec90(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2425 ; VA 0x0054b9a0 ; FUN_0054b9a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0054b9a0(void)

{
  undefined uVar1;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_30;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  uVar1 = 0;
  FUN_005542c0("Username",8);
  uStack_8 = 0xffffffff;
  _DAT_01f757c0 = FUN_0153ec90(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2426 ; VA 0x0054ba50 ; FUN_0054ba50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0054ba50(void)

{
  undefined uVar1;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_30;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018d0474,1);
  uStack_8 = 0;
  uVar1 = 0;
  FUN_005542c0("WebLogin",8);
  uStack_8 = 0xffffffff;
  _DAT_01f75800 = FUN_0153ec90(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2427 ; VA 0x0054bfc0 ; FUN_0054bfc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0054bfc0(void)

{
  undefined4 uStack_808;
  undefined4 uStack_804;
  undefined4 uStack_800;
  undefined4 uStack_7fc;
  undefined4 uStack_7f8;
  undefined4 uStack_7f4;
  undefined4 uStack_7f0;
  undefined4 uStack_7ec;
  undefined4 uStack_7e8;
  undefined4 uStack_7e4;
  undefined4 uStack_7e0;
  undefined4 uStack_7dc;
  undefined4 uStack_7d8;
  undefined4 uStack_7d4;
  undefined4 uStack_7d0;
  undefined4 uStack_7cc;
  undefined4 uStack_7c8;
  undefined4 uStack_7c4;
  undefined4 uStack_7c0;
  undefined4 uStack_7bc;
  undefined4 uStack_7b8;
  undefined4 uStack_7b4;
  undefined4 uStack_7b0;
  undefined4 uStack_7ac;
  undefined4 uStack_7a8;
  undefined4 uStack_7a4;
  undefined4 uStack_7a0;
  undefined4 uStack_79c;
  undefined4 uStack_798;
  undefined4 uStack_794;
  undefined4 uStack_790;
  undefined4 uStack_78c;
  undefined4 uStack_788;
  undefined4 uStack_784;
  undefined4 uStack_780;
  undefined4 uStack_77c;
  undefined4 uStack_778;
  undefined4 uStack_774;
  undefined4 uStack_770;
  undefined4 uStack_76c;
  undefined4 uStack_768;
  undefined4 uStack_764;
  undefined4 uStack_760;
  undefined4 uStack_75c;
  undefined4 uStack_758;
  undefined4 uStack_754;
  undefined4 uStack_750;
  undefined4 uStack_74c;
  undefined4 uStack_748;
  undefined4 uStack_744;
  undefined4 uStack_740;
  undefined4 uStack_73c;
  undefined4 uStack_738;
  undefined4 uStack_734;
  undefined4 uStack_730;
  undefined4 uStack_72c;
  undefined4 uStack_728;
  undefined4 uStack_724;
  undefined4 uStack_720;
  undefined4 uStack_71c;
  undefined4 uStack_718;
  undefined4 uStack_714;
  undefined4 uStack_710;
  undefined4 uStack_70c;
  undefined4 uStack_708;
  undefined4 uStack_704;
  undefined4 uStack_700;
  undefined4 uStack_6fc;
  undefined4 uStack_6f8;
  undefined4 uStack_6f4;
  undefined4 uStack_6f0;
  undefined4 uStack_6ec;
  undefined4 uStack_6e8;
  undefined4 uStack_6e4;
  undefined4 uStack_6e0;
  undefined4 uStack_6dc;
  undefined4 uStack_6d8;
  undefined4 uStack_6d4;
  undefined4 uStack_6d0;
  undefined4 uStack_6cc;
  undefined4 uStack_6c8;
  undefined4 uStack_6c4;
  undefined4 uStack_6c0;
  undefined4 uStack_6bc;
  undefined4 uStack_6b8;
  undefined4 uStack_6b4;
  undefined4 uStack_6b0;
  undefined4 uStack_6ac;
  undefined4 uStack_6a8;
  undefined4 uStack_6a4;
  undefined4 uStack_6a0;
  undefined4 uStack_69c;
  undefined4 uStack_698;
  undefined4 uStack_694;
  undefined4 uStack_690;
  undefined4 uStack_68c;
  undefined4 uStack_688;
  undefined4 uStack_684;
  undefined4 uStack_680;
  undefined4 uStack_67c;
  undefined4 uStack_678;
  undefined4 uStack_674;
  undefined4 uStack_670;
  undefined4 uStack_66c;
  undefined4 uStack_668;
  undefined4 uStack_664;
  undefined4 uStack_660;
  undefined4 uStack_65c;
  undefined4 uStack_658;
  undefined4 uStack_654;
  undefined4 uStack_650;
  undefined4 uStack_64c;
  undefined4 uStack_648;
  undefined4 uStack_644;
  undefined4 uStack_640;
  undefined4 uStack_63c;
  undefined4 uStack_638;
  undefined4 uStack_634;
  undefined4 uStack_630;
  undefined4 uStack_62c;
  undefined4 uStack_628;
  undefined4 uStack_624;
  undefined4 uStack_620;
  undefined4 uStack_61c;
  undefined4 uStack_618;
  undefined4 uStack_614;
  undefined4 uStack_610;
  undefined4 uStack_60c;
  undefined4 uStack_608;
  undefined4 uStack_604;
  undefined4 uStack_600;
  undefined4 uStack_5fc;
  undefined4 uStack_5f8;
  undefined4 uStack_5f4;
  undefined4 uStack_5f0;
  undefined4 uStack_5ec;
  undefined4 uStack_5e8;
  undefined4 uStack_5e4;
  undefined4 uStack_5e0;
  undefined4 uStack_5dc;
  undefined4 uStack_5d8;
  undefined4 uStack_5d4;
  undefined4 uStack_5d0;
  undefined4 uStack_5cc;
  undefined4 uStack_5c8;
  undefined4 uStack_5c4;
  undefined4 uStack_5c0;
  undefined4 uStack_5bc;
  undefined4 uStack_5b8;
  undefined4 uStack_5b4;
  undefined4 uStack_5b0;
  undefined4 uStack_5ac;
  undefined4 uStack_5a8;
  undefined4 uStack_5a4;
  undefined4 uStack_5a0;
  undefined4 uStack_59c;
  undefined4 uStack_598;
  undefined4 uStack_594;
  undefined4 uStack_590;
  undefined4 uStack_58c;
  undefined4 uStack_588;
  undefined4 uStack_584;
  undefined4 uStack_580;
  undefined4 uStack_57c;
  undefined4 uStack_578;
  undefined4 uStack_574;
  undefined4 uStack_570;
  undefined4 uStack_56c;
  undefined4 uStack_568;
  undefined4 uStack_564;
  undefined4 uStack_560;
  undefined4 uStack_55c;
  undefined4 uStack_558;
  undefined4 uStack_554;
  undefined4 uStack_550;
  undefined4 uStack_54c;
  undefined4 uStack_548;
  undefined4 uStack_544;
  undefined4 uStack_540;
  undefined4 uStack_53c;
  undefined4 uStack_538;
  undefined4 uStack_534;
  undefined4 uStack_530;
  undefined4 uStack_52c;
  undefined4 uStack_528;
  undefined4 uStack_524;
  undefined4 uStack_520;
  undefined4 uStack_51c;
  undefined4 uStack_518;
  undefined4 uStack_514;
  undefined4 uStack_510;
  undefined4 uStack_50c;
  undefined4 uStack_508;
  undefined4 uStack_504;
  undefined4 uStack_500;
  undefined4 uStack_4fc;
  undefined4 uStack_4f8;
  undefined4 uStack_4f4;
  undefined4 uStack_4f0;
  undefined4 uStack_4ec;
  undefined4 uStack_4e8;
  undefined4 uStack_4e4;
  undefined4 uStack_4e0;
  undefined4 uStack_4dc;
  undefined4 uStack_4d8;
  undefined4 uStack_4d4;
  undefined4 uStack_4d0;
  undefined4 uStack_4cc;
  undefined4 uStack_4c8;
  undefined4 uStack_4c4;
  undefined4 uStack_4c0;
  undefined4 uStack_4bc;
  undefined4 uStack_4b8;
  undefined4 uStack_4b4;
  undefined4 uStack_4b0;
  undefined4 uStack_4ac;
  undefined4 uStack_4a8;
  undefined4 uStack_4a4;
  undefined4 uStack_4a0;
  undefined4 uStack_49c;
  undefined4 uStack_498;
  undefined4 uStack_494;
  undefined4 uStack_490;
  undefined4 uStack_48c;
  undefined4 uStack_488;
  undefined4 uStack_484;
  undefined4 uStack_480;
  undefined4 uStack_47c;
  undefined4 uStack_478;
  undefined4 uStack_474;
  undefined4 uStack_470;
  undefined4 uStack_46c;
  undefined4 uStack_468;
  undefined4 uStack_464;
  undefined4 uStack_460;
  undefined4 uStack_45c;
  undefined4 uStack_458;
  undefined4 uStack_454;
  undefined4 uStack_450;
  undefined4 uStack_44c;
  undefined4 uStack_448;
  undefined4 uStack_444;
  undefined4 uStack_440;
  undefined4 uStack_43c;
  undefined4 uStack_438;
  undefined4 uStack_434;
  undefined4 uStack_430;
  undefined4 uStack_42c;
  undefined4 uStack_428;
  undefined4 uStack_424;
  undefined4 uStack_420;
  undefined4 uStack_41c;
  undefined4 uStack_418;
  undefined4 uStack_414;
  undefined4 uStack_410;
  undefined4 uStack_40c;
  undefined4 uStack_408;
  undefined4 uStack_404;
  undefined4 uStack_400;
  undefined4 uStack_3fc;
  undefined4 uStack_3f8;
  undefined4 uStack_3f4;
  undefined4 uStack_3f0;
  undefined4 uStack_3ec;
  undefined4 uStack_3e8;
  undefined4 uStack_3e4;
  undefined4 uStack_3e0;
  undefined4 uStack_3dc;
  undefined4 uStack_3d8;
  undefined4 uStack_3d4;
  undefined4 uStack_3d0;
  undefined4 uStack_3cc;
  undefined4 uStack_3c8;
  undefined4 uStack_3c4;
  undefined4 uStack_3c0;
  undefined4 uStack_3bc;
  undefined4 uStack_3b8;
  undefined4 uStack_3b4;
  undefined4 uStack_3b0;
  undefined4 uStack_3ac;
  undefined4 uStack_3a8;
  undefined4 uStack_3a4;
  undefined4 uStack_3a0;
  undefined4 uStack_39c;
  undefined4 uStack_398;
  undefined4 uStack_394;
  undefined4 uStack_390;
  undefined4 uStack_38c;
  undefined4 uStack_388;
  undefined4 uStack_384;
  undefined4 uStack_380;
  undefined4 uStack_37c;
  undefined4 uStack_378;
  undefined4 uStack_374;
  undefined4 uStack_370;
  undefined4 uStack_36c;
  undefined4 uStack_368;
  undefined4 uStack_364;
  undefined4 uStack_360;
  undefined4 uStack_35c;
  undefined4 uStack_358;
  undefined4 uStack_354;
  undefined4 uStack_350;
  undefined4 uStack_34c;
  undefined4 uStack_348;
  undefined4 uStack_344;
  undefined4 uStack_340;
  undefined4 uStack_33c;
  undefined4 uStack_338;
  undefined4 uStack_334;
  undefined4 uStack_330;
  undefined4 uStack_32c;
  undefined4 uStack_328;
  undefined4 uStack_324;
  undefined4 uStack_320;
  undefined4 uStack_31c;
  undefined4 uStack_318;
  undefined4 uStack_314;
  undefined4 uStack_310;
  undefined4 uStack_30c;
  undefined4 uStack_308;
  undefined4 uStack_304;
  undefined4 uStack_300;
  undefined4 uStack_2fc;
  undefined4 uStack_2f8;
  undefined4 uStack_2f4;
  undefined4 uStack_2f0;
  undefined4 uStack_2ec;
  undefined4 uStack_2e8;
  undefined4 uStack_2e4;
  undefined4 uStack_2e0;
  undefined4 uStack_2dc;
  undefined4 uStack_2d8;
  undefined4 uStack_2d4;
  undefined4 uStack_2d0;
  undefined4 uStack_2cc;
  undefined4 uStack_2c8;
  undefined4 uStack_2c4;
  undefined4 uStack_2c0;
  undefined4 uStack_2bc;
  undefined4 uStack_2b8;
  undefined4 uStack_2b4;
  undefined4 uStack_2b0;
  undefined4 uStack_2ac;
  undefined4 uStack_2a8;
  undefined4 uStack_2a4;
  undefined4 uStack_2a0;
  undefined4 uStack_29c;
  undefined4 uStack_298;
  undefined4 uStack_294;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined4 uStack_280;
  undefined4 uStack_27c;
  undefined4 uStack_278;
  undefined4 uStack_274;
  undefined4 uStack_270;
  undefined4 uStack_26c;
  undefined4 uStack_268;
  undefined4 uStack_264;
  undefined4 uStack_260;
  undefined4 uStack_25c;
  undefined4 uStack_258;
  undefined4 uStack_254;
  undefined4 uStack_250;
  undefined4 uStack_24c;
  undefined4 uStack_248;
  undefined4 uStack_244;
  undefined4 uStack_240;
  undefined4 uStack_23c;
  undefined4 uStack_238;
  undefined4 uStack_234;
  undefined4 uStack_230;
  undefined4 uStack_22c;
  undefined4 uStack_228;
  undefined4 uStack_224;
  undefined4 uStack_220;
  undefined4 uStack_21c;
  undefined4 uStack_218;
  undefined4 uStack_214;
  undefined4 uStack_210;
  undefined4 uStack_20c;
  undefined4 uStack_208;
  undefined4 uStack_204;
  undefined4 uStack_200;
  undefined4 uStack_1fc;
  undefined4 uStack_1f8;
  undefined4 uStack_1f4;
  undefined4 uStack_1f0;
  undefined4 uStack_1ec;
  undefined4 uStack_1e8;
  undefined4 uStack_1e4;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  undefined4 uStack_1d4;
  undefined4 uStack_1d0;
  undefined4 uStack_1cc;
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined4 uStack_1a8;
  undefined4 uStack_1a4;
  undefined4 uStack_1a0;
  undefined4 uStack_19c;
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined4 uStack_190;
  undefined4 uStack_18c;
  undefined4 uStack_188;
  undefined4 uStack_184;
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined4 uStack_178;
  undefined4 uStack_174;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined4 uStack_168;
  undefined4 uStack_164;
  undefined4 uStack_160;
  undefined4 uStack_15c;
  undefined4 uStack_158;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_808 = _DAT_01b1b4f0;
  uStack_804 = _UNK_01b1b4f4;
  uStack_800 = _UNK_01b1b4f8;
  uStack_7fc = _UNK_01b1b4fc;
  uStack_7f8 = _DAT_01b1b4e0;
  uStack_7f4 = _UNK_01b1b4e4;
  uStack_7f0 = _UNK_01b1b4e8;
  uStack_7ec = _UNK_01b1b4ec;
  uStack_7e8 = _DAT_01b1b4d0;
  uStack_7e4 = _UNK_01b1b4d4;
  uStack_7e0 = _UNK_01b1b4d8;
  uStack_7dc = _UNK_01b1b4dc;
  uStack_7d8 = _DAT_01b1b4c0;
  uStack_7d4 = _UNK_01b1b4c4;
  uStack_7d0 = _UNK_01b1b4c8;
  uStack_7cc = _UNK_01b1b4cc;
  uStack_7c8 = _DAT_01b1b4b0;
  uStack_7c4 = _UNK_01b1b4b4;
  uStack_7c0 = _UNK_01b1b4b8;
  uStack_7bc = _UNK_01b1b4bc;
  uStack_7b8 = _DAT_01b1b4a0;
  uStack_7b4 = _UNK_01b1b4a4;
  uStack_7b0 = _UNK_01b1b4a8;
  uStack_7ac = _UNK_01b1b4ac;
  uStack_7a8 = _DAT_01b1b490;
  uStack_7a4 = _UNK_01b1b494;
  uStack_7a0 = _UNK_01b1b498;
  uStack_79c = _UNK_01b1b49c;
  uStack_798 = _DAT_01b1b480;
  uStack_794 = _UNK_01b1b484;
  uStack_790 = _UNK_01b1b488;
  uStack_78c = _UNK_01b1b48c;
  uStack_788 = _DAT_01b1b470;
  uStack_784 = _UNK_01b1b474;
  uStack_780 = _UNK_01b1b478;
  uStack_77c = _UNK_01b1b47c;
  uStack_778 = _DAT_01b1b460;
  uStack_774 = _UNK_01b1b464;
  uStack_770 = _UNK_01b1b468;
  uStack_76c = _UNK_01b1b46c;
  uStack_768 = _DAT_01b1b450;
  uStack_764 = _UNK_01b1b454;
  uStack_760 = _UNK_01b1b458;
  uStack_75c = _UNK_01b1b45c;
  uStack_758 = _DAT_01b1b440;
  uStack_754 = _UNK_01b1b444;
  uStack_750 = _UNK_01b1b448;
  uStack_74c = _UNK_01b1b44c;
  uStack_748 = _DAT_01b1b430;
  uStack_744 = _UNK_01b1b434;
  uStack_740 = _UNK_01b1b438;
  uStack_73c = _UNK_01b1b43c;
  uStack_738 = _DAT_01b1b420;
  uStack_734 = _UNK_01b1b424;
  uStack_730 = _UNK_01b1b428;
  uStack_72c = _UNK_01b1b42c;
  uStack_728 = _DAT_01b1b410;
  uStack_724 = _UNK_01b1b414;
  uStack_720 = _UNK_01b1b418;
  uStack_71c = _UNK_01b1b41c;
  uStack_718 = _DAT_01b1b400;
  uStack_714 = _UNK_01b1b404;
  uStack_710 = _UNK_01b1b408;
  uStack_70c = _UNK_01b1b40c;
  uStack_708 = _DAT_01b1b3f0;
  uStack_704 = _UNK_01b1b3f4;
  uStack_700 = _UNK_01b1b3f8;
  uStack_6fc = _UNK_01b1b3fc;
  uStack_6f8 = _DAT_01b1b3e0;
  uStack_6f4 = _UNK_01b1b3e4;
  uStack_6f0 = _UNK_01b1b3e8;
  uStack_6ec = _UNK_01b1b3ec;
  uStack_6e8 = _DAT_01b1b3d0;
  uStack_6e4 = _UNK_01b1b3d4;
  uStack_6e0 = _UNK_01b1b3d8;
  uStack_6dc = _UNK_01b1b3dc;
  uStack_6d8 = _DAT_01b1b3c0;
  uStack_6d4 = _UNK_01b1b3c4;
  uStack_6d0 = _UNK_01b1b3c8;
  uStack_6cc = _UNK_01b1b3cc;
  uStack_6c8 = _DAT_01b1b3b0;
  uStack_6c4 = _UNK_01b1b3b4;
  uStack_6c0 = _UNK_01b1b3b8;
  uStack_6bc = _UNK_01b1b3bc;
  uStack_6b8 = _DAT_01b1b3a0;
  uStack_6b4 = _UNK_01b1b3a4;
  uStack_6b0 = _UNK_01b1b3a8;
  uStack_6ac = _UNK_01b1b3ac;
  uStack_6a8 = _DAT_01b1b390;
  uStack_6a4 = _UNK_01b1b394;
  uStack_6a0 = _UNK_01b1b398;
  uStack_69c = _UNK_01b1b39c;
  uStack_698 = _DAT_01b1b380;
  uStack_694 = _UNK_01b1b384;
  uStack_690 = _UNK_01b1b388;
  uStack_68c = _UNK_01b1b38c;
  uStack_688 = _DAT_01b1b370;
  uStack_684 = _UNK_01b1b374;
  uStack_680 = _UNK_01b1b378;
  uStack_67c = _UNK_01b1b37c;
  uStack_678 = _DAT_01b1b360;
  uStack_674 = _UNK_01b1b364;
  uStack_670 = _UNK_01b1b368;
  uStack_66c = _UNK_01b1b36c;
  uStack_668 = _DAT_01b1b350;
  uStack_664 = _UNK_01b1b354;
  uStack_660 = _UNK_01b1b358;
  uStack_65c = _UNK_01b1b35c;
  uStack_658 = _DAT_01b1b340;
  uStack_654 = _UNK_01b1b344;
  uStack_650 = _UNK_01b1b348;
  uStack_64c = _UNK_01b1b34c;
  uStack_648 = _DAT_01b1b330;
  uStack_644 = _UNK_01b1b334;
  uStack_640 = _UNK_01b1b338;
  uStack_63c = _UNK_01b1b33c;
  uStack_638 = _DAT_01b1b320;
  uStack_634 = _UNK_01b1b324;
  uStack_630 = _UNK_01b1b328;
  uStack_62c = _UNK_01b1b32c;
  uStack_628 = _DAT_01b1b310;
  uStack_624 = _UNK_01b1b314;
  uStack_620 = _UNK_01b1b318;
  uStack_61c = _UNK_01b1b31c;
  uStack_618 = _DAT_01b1b300;
  uStack_614 = _UNK_01b1b304;
  uStack_610 = _UNK_01b1b308;
  uStack_60c = _UNK_01b1b30c;
  uStack_608 = _DAT_01b1b2f0;
  uStack_604 = _UNK_01b1b2f4;
  uStack_600 = _UNK_01b1b2f8;
  uStack_5fc = _UNK_01b1b2fc;
  uStack_5f8 = _DAT_01b1b2e0;
  uStack_5f4 = _UNK_01b1b2e4;
  uStack_5f0 = _UNK_01b1b2e8;
  uStack_5ec = _UNK_01b1b2ec;
  uStack_5e8 = _DAT_01b1b2d0;
  uStack_5e4 = _UNK_01b1b2d4;
  uStack_5e0 = _UNK_01b1b2d8;
  uStack_5dc = _UNK_01b1b2dc;
  uStack_5d8 = _DAT_01b1b2c0;
  uStack_5d4 = _UNK_01b1b2c4;
  uStack_5d0 = _UNK_01b1b2c8;
  uStack_5cc = _UNK_01b1b2cc;
  uStack_5c8 = _DAT_01b1b2b0;
  uStack_5c4 = _UNK_01b1b2b4;
  uStack_5c0 = _UNK_01b1b2b8;
  uStack_5bc = _UNK_01b1b2bc;
  uStack_5b8 = _DAT_01b1b2a0;
  uStack_5b4 = _UNK_01b1b2a4;
  uStack_5b0 = _UNK_01b1b2a8;
  uStack_5ac = _UNK_01b1b2ac;
  uStack_5a8 = _DAT_01b1b290;
  uStack_5a4 = _UNK_01b1b294;
  uStack_5a0 = _UNK_01b1b298;
  uStack_59c = _UNK_01b1b29c;
  uStack_598 = _DAT_01b1b280;
  uStack_594 = _UNK_01b1b284;
  uStack_590 = _UNK_01b1b288;
  uStack_58c = _UNK_01b1b28c;
  uStack_588 = _DAT_01b1b270;
  uStack_584 = _UNK_01b1b274;
  uStack_580 = _UNK_01b1b278;
  uStack_57c = _UNK_01b1b27c;
  uStack_578 = _DAT_01b1b260;
  uStack_574 = _UNK_01b1b264;
  uStack_570 = _UNK_01b1b268;
  uStack_56c = _UNK_01b1b26c;
  uStack_568 = _DAT_01b1b250;
  uStack_564 = _UNK_01b1b254;
  uStack_560 = _UNK_01b1b258;
  uStack_55c = _UNK_01b1b25c;
  uStack_558 = _DAT_01b1b240;
  uStack_554 = _UNK_01b1b244;
  uStack_550 = _UNK_01b1b248;
  uStack_54c = _UNK_01b1b24c;
  uStack_548 = _DAT_01b1b230;
  uStack_544 = _UNK_01b1b234;
  uStack_540 = _UNK_01b1b238;
  uStack_53c = _UNK_01b1b23c;
  uStack_538 = _DAT_01b1b220;
  uStack_534 = _UNK_01b1b224;
  uStack_530 = _UNK_01b1b228;
  uStack_52c = _UNK_01b1b22c;
  uStack_528 = _DAT_01b1b210;
  uStack_524 = _UNK_01b1b214;
  uStack_520 = _UNK_01b1b218;
  uStack_51c = _UNK_01b1b21c;
  uStack_518 = _DAT_01b1b200;
  uStack_514 = _UNK_01b1b204;
  uStack_510 = _UNK_01b1b208;
  uStack_50c = _UNK_01b1b20c;
  uStack_508 = _DAT_01b1b1f0;
  uStack_504 = _UNK_01b1b1f4;
  uStack_500 = _UNK_01b1b1f8;
  uStack_4fc = _UNK_01b1b1fc;
  uStack_4f8 = _DAT_01b1b1e0;
  uStack_4f4 = _UNK_01b1b1e4;
  uStack_4f0 = _UNK_01b1b1e8;
  uStack_4ec = _UNK_01b1b1ec;
  uStack_4e8 = _DAT_01b1b1d0;
  uStack_4e4 = _UNK_01b1b1d4;
  uStack_4e0 = _UNK_01b1b1d8;
  uStack_4dc = _UNK_01b1b1dc;
  uStack_4d8 = _DAT_01b1b1c0;
  uStack_4d4 = _UNK_01b1b1c4;
  uStack_4d0 = _UNK_01b1b1c8;
  uStack_4cc = _UNK_01b1b1cc;
  uStack_4c8 = _DAT_01b1b1b0;
  uStack_4c4 = _UNK_01b1b1b4;
  uStack_4c0 = _UNK_01b1b1b8;
  uStack_4bc = _UNK_01b1b1bc;
  uStack_4b8 = _DAT_01b1b1a0;
  uStack_4b4 = _UNK_01b1b1a4;
  uStack_4b0 = _UNK_01b1b1a8;
  uStack_4ac = _UNK_01b1b1ac;
  uStack_4a8 = _DAT_01b1b190;
  uStack_4a4 = _UNK_01b1b194;
  uStack_4a0 = _UNK_01b1b198;
  uStack_49c = _UNK_01b1b19c;
  uStack_498 = _DAT_01b1b180;
  uStack_494 = _UNK_01b1b184;
  uStack_490 = _UNK_01b1b188;
  uStack_48c = _UNK_01b1b18c;
  uStack_488 = _DAT_01b1b170;
  uStack_484 = _UNK_01b1b174;
  uStack_480 = _UNK_01b1b178;
  uStack_47c = _UNK_01b1b17c;
  uStack_478 = _DAT_01b1b160;
  uStack_474 = _UNK_01b1b164;
  uStack_470 = _UNK_01b1b168;
  uStack_46c = _UNK_01b1b16c;
  uStack_468 = _DAT_01b1b150;
  uStack_464 = _UNK_01b1b154;
  uStack_460 = _UNK_01b1b158;
  uStack_45c = _UNK_01b1b15c;
  uStack_458 = _DAT_01b1b140;
  uStack_454 = _UNK_01b1b144;
  uStack_450 = _UNK_01b1b148;
  uStack_44c = _UNK_01b1b14c;
  uStack_448 = _DAT_01b1b130;
  uStack_444 = _UNK_01b1b134;
  uStack_440 = _UNK_01b1b138;
  uStack_43c = _UNK_01b1b13c;
  uStack_438 = _DAT_01b1b120;
  uStack_434 = _UNK_01b1b124;
  uStack_430 = _UNK_01b1b128;
  uStack_42c = _UNK_01b1b12c;
  uStack_428 = _DAT_01b1b110;
  uStack_424 = _UNK_01b1b114;
  uStack_420 = _UNK_01b1b118;
  uStack_41c = _UNK_01b1b11c;
  uStack_418 = _DAT_01b1b100;
  uStack_414 = _UNK_01b1b104;
  uStack_410 = _UNK_01b1b108;
  uStack_40c = _UNK_01b1b10c;
  uStack_408 = _DAT_01b1b0f0;
  uStack_404 = _UNK_01b1b0f4;
  uStack_400 = _UNK_01b1b0f8;
  uStack_3fc = _UNK_01b1b0fc;
  uStack_3f8 = _DAT_01b1b0e0;
  uStack_3f4 = _UNK_01b1b0e4;
  uStack_3f0 = _UNK_01b1b0e8;
  uStack_3ec = _UNK_01b1b0ec;
  uStack_3e8 = _DAT_01b1b0d0;
  uStack_3e4 = _UNK_01b1b0d4;
  uStack_3e0 = _UNK_01b1b0d8;
  uStack_3dc = _UNK_01b1b0dc;
  uStack_3d8 = _DAT_01b1b0c0;
  uStack_3d4 = _UNK_01b1b0c4;
  uStack_3d0 = _UNK_01b1b0c8;
  uStack_3cc = _UNK_01b1b0cc;
  uStack_3c8 = _DAT_01b1b0b0;
  uStack_3c4 = _UNK_01b1b0b4;
  uStack_3c0 = _UNK_01b1b0b8;
  uStack_3bc = _UNK_01b1b0bc;
  uStack_3b8 = _DAT_01b1b0a0;
  uStack_3b4 = _UNK_01b1b0a4;
  uStack_3b0 = _UNK_01b1b0a8;
  uStack_3ac = _UNK_01b1b0ac;
  uStack_3a8 = _DAT_01b1b090;
  uStack_3a4 = _UNK_01b1b094;
  uStack_3a0 = _UNK_01b1b098;
  uStack_39c = _UNK_01b1b09c;
  uStack_398 = _DAT_01b1b080;
  uStack_394 = _UNK_01b1b084;
  uStack_390 = _UNK_01b1b088;
  uStack_38c = _UNK_01b1b08c;
  uStack_388 = _DAT_01b1b070;
  uStack_384 = _UNK_01b1b074;
  uStack_380 = _UNK_01b1b078;
  uStack_37c = _UNK_01b1b07c;
  uStack_378 = _DAT_01b1b060;
  uStack_374 = _UNK_01b1b064;
  uStack_370 = _UNK_01b1b068;
  uStack_36c = _UNK_01b1b06c;
  uStack_368 = _DAT_01b1b050;
  uStack_364 = _UNK_01b1b054;
  uStack_360 = _UNK_01b1b058;
  uStack_35c = _UNK_01b1b05c;
  uStack_358 = _DAT_01b1b040;
  uStack_354 = _UNK_01b1b044;
  uStack_350 = _UNK_01b1b048;
  uStack_34c = _UNK_01b1b04c;
  uStack_348 = _DAT_01b1b030;
  uStack_344 = _UNK_01b1b034;
  uStack_340 = _UNK_01b1b038;
  uStack_33c = _UNK_01b1b03c;
  uStack_338 = _DAT_01b1b020;
  uStack_334 = _UNK_01b1b024;
  uStack_330 = _UNK_01b1b028;
  uStack_32c = _UNK_01b1b02c;
  uStack_328 = _DAT_01b1b010;
  uStack_324 = _UNK_01b1b014;
  uStack_320 = _UNK_01b1b018;
  uStack_31c = _UNK_01b1b01c;
  uStack_318 = _DAT_01b1b000;
  uStack_314 = _UNK_01b1b004;
  uStack_310 = _UNK_01b1b008;
  uStack_30c = _UNK_01b1b00c;
  uStack_308 = _DAT_01b1aff0;
  uStack_304 = _UNK_01b1aff4;
  uStack_300 = _UNK_01b1aff8;
  uStack_2fc = _UNK_01b1affc;
  uStack_2f8 = _DAT_01b1afe0;
  uStack_2f4 = _UNK_01b1afe4;
  uStack_2f0 = _UNK_01b1afe8;
  uStack_2ec = _UNK_01b1afec;
  uStack_2e8 = _DAT_01b1afd0;
  uStack_2e4 = _UNK_01b1afd4;
  uStack_2e0 = _UNK_01b1afd8;
  uStack_2dc = _UNK_01b1afdc;
  uStack_2d8 = _DAT_01b1afc0;
  uStack_2d4 = _UNK_01b1afc4;
  uStack_2d0 = _UNK_01b1afc8;
  uStack_2cc = _UNK_01b1afcc;
  uStack_2c8 = _DAT_01b1afb0;
  uStack_2c4 = _UNK_01b1afb4;
  uStack_2c0 = _UNK_01b1afb8;
  uStack_2bc = _UNK_01b1afbc;
  uStack_2b8 = _DAT_01b1afa0;
  uStack_2b4 = _UNK_01b1afa4;
  uStack_2b0 = _UNK_01b1afa8;
  uStack_2ac = _UNK_01b1afac;
  uStack_2a8 = _DAT_01b1af90;
  uStack_2a4 = _UNK_01b1af94;
  uStack_2a0 = _UNK_01b1af98;
  uStack_29c = _UNK_01b1af9c;
  uStack_298 = _DAT_01b1af80;
  uStack_294 = _UNK_01b1af84;
  uStack_290 = _UNK_01b1af88;
  uStack_28c = _UNK_01b1af8c;
  uStack_288 = _DAT_01b1af70;
  uStack_284 = _UNK_01b1af74;
  uStack_280 = _UNK_01b1af78;
  uStack_27c = _UNK_01b1af7c;
  uStack_278 = _DAT_01b1af60;
  uStack_274 = _UNK_01b1af64;
  uStack_270 = _UNK_01b1af68;
  uStack_26c = _UNK_01b1af6c;
  uStack_268 = _DAT_01b1af50;
  uStack_264 = _UNK_01b1af54;
  uStack_260 = _UNK_01b1af58;
  uStack_25c = _UNK_01b1af5c;
  uStack_258 = _DAT_01b1af40;
  uStack_254 = _UNK_01b1af44;
  uStack_250 = _UNK_01b1af48;
  uStack_24c = _UNK_01b1af4c;
  uStack_248 = _DAT_01b1af30;
  uStack_244 = _UNK_01b1af34;
  uStack_240 = _UNK_01b1af38;
  uStack_23c = _UNK_01b1af3c;
  uStack_238 = _DAT_01b1af20;
  uStack_234 = _UNK_01b1af24;
  uStack_230 = _UNK_01b1af28;
  uStack_22c = _UNK_01b1af2c;
  uStack_228 = _DAT_01b1af10;
  uStack_224 = _UNK_01b1af14;
  uStack_220 = _UNK_01b1af18;
  uStack_21c = _UNK_01b1af1c;
  uStack_218 = _DAT_01b1af00;
  uStack_214 = _UNK_01b1af04;
  uStack_210 = _UNK_01b1af08;
  uStack_20c = _UNK_01b1af0c;
  uStack_208 = _DAT_01b1aef0;
  uStack_204 = _UNK_01b1aef4;
  uStack_200 = _UNK_01b1aef8;
  uStack_1fc = _UNK_01b1aefc;
  uStack_1f8 = _DAT_01b1aee0;
  uStack_1f4 = _UNK_01b1aee4;
  uStack_1f0 = _UNK_01b1aee8;
  uStack_1ec = _UNK_01b1aeec;
  uStack_1e8 = _DAT_01b1aed0;
  uStack_1e4 = _UNK_01b1aed4;
  uStack_1e0 = _UNK_01b1aed8;
  uStack_1dc = _UNK_01b1aedc;
  uStack_1d8 = _DAT_01b1aec0;
  uStack_1d4 = _UNK_01b1aec4;
  uStack_1d0 = _UNK_01b1aec8;
  uStack_1cc = _UNK_01b1aecc;
  uStack_1c8 = _DAT_01b1aeb0;
  uStack_1c4 = _UNK_01b1aeb4;
  uStack_1c0 = _UNK_01b1aeb8;
  uStack_1bc = _UNK_01b1aebc;
  uStack_1b8 = _DAT_01b1aea0;
  uStack_1b4 = _UNK_01b1aea4;
  uStack_1b0 = _UNK_01b1aea8;
  uStack_1ac = _UNK_01b1aeac;
  uStack_1a8 = _DAT_01b1ae90;
  uStack_1a4 = _UNK_01b1ae94;
  uStack_1a0 = _UNK_01b1ae98;
  uStack_19c = _UNK_01b1ae9c;
  uStack_198 = _DAT_01b1ae80;
  uStack_194 = _UNK_01b1ae84;
  uStack_190 = _UNK_01b1ae88;
  uStack_18c = _UNK_01b1ae8c;
  uStack_188 = _DAT_01b1ae70;
  uStack_184 = _UNK_01b1ae74;
  uStack_180 = _UNK_01b1ae78;
  uStack_17c = _UNK_01b1ae7c;
  uStack_178 = _DAT_01b1ae60;
  uStack_174 = _UNK_01b1ae64;
  uStack_170 = _UNK_01b1ae68;
  uStack_16c = _UNK_01b1ae6c;
  uStack_168 = _DAT_01b1ae50;
  uStack_164 = _UNK_01b1ae54;
  uStack_160 = _UNK_01b1ae58;
  uStack_15c = _UNK_01b1ae5c;
  uStack_158 = _DAT_01b1ae40;
  uStack_154 = _UNK_01b1ae44;
  uStack_150 = _UNK_01b1ae48;
  uStack_14c = _UNK_01b1ae4c;
  uStack_148 = _DAT_01b1ae30;
  uStack_144 = _UNK_01b1ae34;
  uStack_140 = _UNK_01b1ae38;
  uStack_13c = _UNK_01b1ae3c;
  uStack_138 = _DAT_01b1ae20;
  uStack_134 = _UNK_01b1ae24;
  uStack_130 = _UNK_01b1ae28;
  uStack_12c = _UNK_01b1ae2c;
  uStack_128 = _DAT_01b1ae10;
  uStack_124 = _UNK_01b1ae14;
  uStack_120 = _UNK_01b1ae18;
  uStack_11c = _UNK_01b1ae1c;
  uStack_118 = _DAT_01b1ae00;
  uStack_114 = _UNK_01b1ae04;
  uStack_110 = _UNK_01b1ae08;
  uStack_10c = _UNK_01b1ae0c;
  uStack_108 = _DAT_01b1adf0;
  uStack_104 = _UNK_01b1adf4;
  uStack_100 = _UNK_01b1adf8;
  uStack_fc = _UNK_01b1adfc;
  uStack_f8 = _DAT_01b1ade0;
  uStack_f4 = _UNK_01b1ade4;
  uStack_f0 = _UNK_01b1ade8;
  uStack_ec = _UNK_01b1adec;
  uStack_e8 = _DAT_01b1add0;
  uStack_e4 = _UNK_01b1add4;
  uStack_e0 = _UNK_01b1add8;
  uStack_dc = _UNK_01b1addc;
  uStack_d8 = _DAT_01b1adc0;
  uStack_d4 = _UNK_01b1adc4;
  uStack_d0 = _UNK_01b1adc8;
  uStack_cc = _UNK_01b1adcc;
  uStack_c8 = _DAT_01b1adb0;
  uStack_c4 = _UNK_01b1adb4;
  uStack_c0 = _UNK_01b1adb8;
  uStack_bc = _UNK_01b1adbc;
  uStack_b8 = _DAT_01b1ada0;
  uStack_b4 = _UNK_01b1ada4;
  uStack_b0 = _UNK_01b1ada8;
  uStack_ac = _UNK_01b1adac;
  uStack_a8 = _DAT_01b1ad90;
  uStack_a4 = _UNK_01b1ad94;
  uStack_a0 = _UNK_01b1ad98;
  uStack_9c = _UNK_01b1ad9c;
  uStack_98 = _DAT_01b1ad80;
  uStack_94 = _UNK_01b1ad84;
  uStack_90 = _UNK_01b1ad88;
  uStack_8c = _UNK_01b1ad8c;
  uStack_88 = _DAT_01b1ad70;
  uStack_84 = _UNK_01b1ad74;
  uStack_80 = _UNK_01b1ad78;
  uStack_7c = _UNK_01b1ad7c;
  uStack_78 = _DAT_01b1ad60;
  uStack_74 = _UNK_01b1ad64;
  uStack_70 = _UNK_01b1ad68;
  uStack_6c = _UNK_01b1ad6c;
  uStack_68 = _DAT_01b1ad50;
  uStack_64 = _UNK_01b1ad54;
  uStack_60 = _UNK_01b1ad58;
  uStack_5c = _UNK_01b1ad5c;
  uStack_58 = _DAT_01b1ad40;
  uStack_54 = _UNK_01b1ad44;
  uStack_50 = _UNK_01b1ad48;
  uStack_4c = _UNK_01b1ad4c;
  uStack_48 = _DAT_01b1ad30;
  uStack_44 = _UNK_01b1ad34;
  uStack_40 = _UNK_01b1ad38;
  uStack_3c = _UNK_01b1ad3c;
  uStack_38 = _DAT_01b1ad20;
  uStack_34 = _UNK_01b1ad24;
  uStack_30 = _UNK_01b1ad28;
  uStack_2c = _UNK_01b1ad2c;
  uStack_28 = _DAT_01b1ad10;
  uStack_24 = _UNK_01b1ad14;
  uStack_20 = _UNK_01b1ad18;
  uStack_1c = _UNK_01b1ad1c;
  uStack_18 = _DAT_01b1ad00;
  uStack_14 = _UNK_01b1ad04;
  uStack_10 = _UNK_01b1ad08;
  uStack_c = _UNK_01b1ad0c;
  FUN_00f8dfa0(&uStack_808,&uStack_8,uStack_8);
  FUN_016f3654(&LAB_018b1c90);
  return;
}



/* FUNCTION 2428 ; VA 0x0054c8d0 ; FUN_0054c8d0 */

void FUN_0054c8d0(void)

{
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  uStack_c = 0;
  FUN_00f8b390(&uStack_c,&stack0xfffffffc,0);
  FUN_016f3654(&LAB_018b1db0);
  return;
}



/* FUNCTION 2429 ; VA 0x0054ca20 ; FUN_0054ca20 */

void FUN_0054ca20(void)

{
  int iStack_c;
  int iStack_8;
  
  if ((DAT_02110f10 == 0 && DAT_02110f14 == 0) && (DAT_02110ee7 == '\0')) {
    QueryPerformanceCounter(&iStack_c);
    DAT_02110f10 = iStack_c;
    DAT_02110f14 = iStack_8;
    DAT_02110ee7 = '\x01';
  }
  return;
}



/* FUNCTION 2430 ; VA 0x0054cc40 ; FUN_0054cc40 */

void FUN_0054cc40(void)

{
  int iVar1;
  byte abStack_64 [64];
  byte abStack_24 [32];
  
  iVar1 = 0;
  do {
    abStack_24[iVar1] = (byte)(iVar1 >> 2) | (char)iVar1 << 3;
    iVar1 = iVar1 + 1;
  } while (iVar1 < 0x20);
  iVar1 = 0;
  do {
    abStack_64[iVar1] = (byte)(iVar1 >> 4) | (char)iVar1 << 2;
    iVar1 = iVar1 + 1;
  } while (iVar1 < 0x40);
  FUN_016c0de0(&DAT_021127f8,abStack_24,0x20,0);
  FUN_016c0de0(&DAT_021129f8,abStack_64,0x40,0);
  FUN_016c0de0(&DAT_02112bf8,abStack_24,0x20,1);
  FUN_016c0de0(&DAT_02112df8,abStack_64,0x40,1);
  return;
}



/* FUNCTION 2431 ; VA 0x0054d730 ; FUN_0054d730 */

undefined2 * __thiscall FUN_0054d730(undefined2 *param_1,char *param_2)

{
  char cVar1;
  undefined4 uVar2;
  char *pcVar3;
  undefined4 ****ppppuVar4;
  uint uVar5;
  int iVar6;
  undefined4 ***apppuStack_2c [4];
  int iStack_1c;
  uint uStack_18;
  undefined2 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791a70;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 10) = 7;
  *param_1 = 0;
  uStack_8 = 0;
  iStack_1c = 0;
  uStack_18 = 0xf;
  apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
  pcVar3 = param_2;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  puStack_14 = param_1;
  FUN_005542c0(param_2,(int)pcVar3 - (int)(param_2 + 1));
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_1c != 0) {
    ppppuVar4 = apppuStack_2c;
    if (0xf < uStack_18) {
      ppppuVar4 = (undefined4 ****)apppuStack_2c[0];
    }
    iVar6 = (int)ppppuVar4 + iStack_1c;
    ppppuVar4 = apppuStack_2c;
    if (0xf < uStack_18) {
      ppppuVar4 = (undefined4 ****)apppuStack_2c[0];
    }
    uVar2 = FUN_01686580();
    FUN_01685950(ppppuVar4,iVar6,param_1,uVar2);
  }
  if (0xf < uStack_18) {
    uVar5 = uStack_18 + 1;
    ppppuVar4 = (undefined4 ****)apppuStack_2c[0];
    if (0xfff < uVar5) {
      ppppuVar4 = (undefined4 ****)apppuStack_2c[0][-1];
      uVar5 = uStack_18 + 0x24;
      if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2432 ; VA 0x0054d820 ; FUN_0054d820 */

int * __thiscall FUN_0054d820(int *param_1,int *param_2)

{
  int iVar1;
  
  iVar1 = *param_2;
  *param_1 = iVar1;
  param_1[1] = iVar1 >> 0x1f;
  return param_1;
}



/* FUNCTION 2433 ; VA 0x0054d840 ; FUN_0054d840 */

undefined4 * __thiscall FUN_0054d840(undefined4 *param_1,undefined4 param_2)

{
  *param_1 = param_2;
  return param_1;
}



/* FUNCTION 2434 ; VA 0x0054d850 ; FUN_0054d850 */

undefined4 __thiscall FUN_0054d850(undefined4 param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined **ppuStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  char cStack_28;
  undefined4 *puStack_24;
  undefined uStack_20;
  undefined4 uStack_1c;
  undefined uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791aa0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(8);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    *puVar1 = *param_2;
    puVar1[1] = param_2[1];
  }
  uStack_8 = 0;
  iVar2 = FUN_016df16d(&uStack_30);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  uStack_18 = 1;
  uStack_14 = uStack_30;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar2 = FUN_016dee1a(&uStack_2c,1);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  uStack_20 = 1;
  uStack_1c = uStack_2c;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cStack_28 = '\0';
  iVar2 = FUN_016dee6d(uStack_2c);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  ppuStack_34 = std::
                _LaunchPad<class_std::unique_ptr<class_std::tuple<class_<lambda_0d39eabcfddecbafcaeccbcd9133e5ee>_>,struct_std::default_delete<class_std::tuple<class_<lambda_0d39eabcfddecbafcaeccbcd9133e5ee>_>_>_>_>
                ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  puStack_24 = puVar1;
  iVar3 = FUN_016de8aa(param_1,FUN_005535c0,&ppuStack_34);
  iVar2 = 1;
  if (iVar3 != 4) {
    iVar2 = iVar3;
  }
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  while (cStack_28 == '\0') {
    iVar2 = FUN_016df1c8(uStack_30,uStack_2c);
    if (iVar2 != 0) {
      FUN_016df3c9(iVar2);
    }
  }
  if (puStack_24 != (undefined4 *)0x0) {
    FUN_01674ea0(puStack_24,8);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  iVar2 = FUN_016deec8(uStack_2c);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  FUN_016dede1(uStack_2c);
  FUN_016df136(uStack_30);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2435 ; VA 0x0054d9d0 ; FUN_0054d9d0 */

undefined4 * __thiscall FUN_0054d9d0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791ab0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = boost::detail::
              sp_counted_impl_p<class_boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_alloc_>_>
              ::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = puVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2436 ; VA 0x0054da45 ; Catch_All@0054da45 */

void Catch_All_0054da45(void)

{
  int unaff_EBP;
  
  FUN_0054dc80(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2437 ; VA 0x0054da60 ; FUN_0054da60 */

undefined4 * __thiscall FUN_0054da60(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791ac0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = boost::detail::
              sp_counted_impl_p<class_boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_exception_>_>
              ::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = puVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2438 ; VA 0x0054dad5 ; Catch_All@0054dad5 */

void Catch_All_0054dad5(void)

{
  int unaff_EBP;
  
  FUN_0054dc80(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 2439 ; VA 0x0054daf0 ; FUN_0054daf0 */

undefined8 * __thiscall FUN_0054daf0(undefined8 *param_1,undefined4 *param_2)

{
  undefined8 uVar1;
  
  uVar1 = FUN_016f39b0(*param_2,param_2[1],1000000,0);
  *param_1 = uVar1;
  return param_1;
}



/* FUNCTION 2440 ; VA 0x0054db20 ; FUN_0054db20 */

undefined4 __fastcall FUN_0054db20(undefined4 *param_1)

{
  return *param_1;
}



/* FUNCTION 2441 ; VA 0x0054db30 ; FUN_0054db30 */

undefined8 * FUN_0054db30(undefined8 *param_1,undefined4 *param_2,int *param_3)

{
  undefined8 uVar1;
  
  uVar1 = FUN_016f3900(*param_2,param_2[1],*param_3,*param_3 >> 0x1f);
  *param_1 = uVar1;
  return param_1;
}



/* FUNCTION 2442 ; VA 0x0054db60 ; FUN_0054db60 */

undefined4 FUN_0054db60(undefined4 param_1)

{
  return param_1;
}



/* FUNCTION 2443 ; VA 0x0054db70 ; FUN_0054db70 */

void FUN_0054db70(int param_1,uint param_2)

{
  if ((0xfff < param_2) && (0x1f < (param_1 - *(int *)(param_1 + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
    FUN_017167a3();
  }
  FUN_01674ea0();
  return;
}



/* FUNCTION 2444 ; VA 0x0054dbb0 ; FUN_0054dbb0 */

bool FUN_0054dbb0(char param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = FUN_01718701((int)param_1,param_2);
  return iVar1 != -1;
}



/* FUNCTION 2445 ; VA 0x0054dbd0 ; FUN_0054dbd0 */

undefined4 FUN_0054dbd0(undefined4 param_1,undefined4 *param_2)

{
  *param_2 = std::_Iostream_error_category::vftable;
  param_2[1] = 5;
  return 1;
}



/* FUNCTION 2446 ; VA 0x0054dbf0 ; FUN_0054dbf0 */

undefined8 * FUN_0054dbf0(undefined8 *param_1,int *param_2)

{
  longlong lVar1;
  longlong lVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  
  if ((param_2[1] < 1) && ((param_2[1] < 0 || (*param_2 == 0)))) {
    *(undefined4 *)param_1 = 0;
    *(undefined4 *)((int)param_1 + 4) = 0;
    *(undefined4 *)(param_1 + 1) = 0;
    return param_1;
  }
  lVar1 = FUN_016de945();
  lVar2 = FUN_016f39b0(*param_2,param_2[1],10000000,0);
  uVar3 = FUN_016f39b0(lVar1 + lVar2,100,0);
  uVar4 = FUN_016f3900(uVar3,1000000000,0);
  *param_1 = uVar4;
  *(int *)(param_1 + 1) = (int)uVar3 + (int)uVar4 * -1000000000;
  return param_1;
}



/* FUNCTION 2447 ; VA 0x0054dc80 ; FUN_0054dc80 */

void FUN_0054dc80(undefined4 *param_1)

{
  if (param_1 != (undefined4 *)0x0) {
    (**(code **)*param_1)(1);
  }
  return;
}



/* FUNCTION 2448 ; VA 0x0054dca0 ; FUN_0054dca0 */

undefined8 * FUN_0054dca0(undefined8 *param_1,undefined4 *param_2)

{
  undefined8 uVar1;
  
  uVar1 = FUN_016f39b0(*param_2,param_2[1],1000000,0);
  *param_1 = uVar1;
  return param_1;
}



/* FUNCTION 2449 ; VA 0x0054dcd0 ; FUN_0054dcd0 */

undefined4 * FUN_0054dcd0(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791afc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_018bd31c;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::bad_function_call::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_function_call>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_function_call>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_function_call>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2450 ; VA 0x0054ddb0 ; FUN_0054ddb0 */

undefined4 * FUN_0054ddb0(undefined4 *param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791b34;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[0x10] = &DAT_018bd2dc;
  param_1[0x12] = boost::exception_detail::clone_base::vftable;
  uStack_8 = 0;
  FUN_0054f450(param_2);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::thread_resource_error>_>
             ::vftable;
  param_1[0xb] = boost::exception_detail::
                 clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::thread_resource_error>_>
                 ::vftable;
  uStack_8 = 1;
  *(undefined ***)(*(int *)(param_1[0x10] + 4) + 0x40 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::thread_resource_error>_>
       ::vftable;
  *(int *)(*(int *)(param_1[0x10] + 4) + 0x3c + (int)param_1) = *(int *)(param_1[0x10] + 4) + -8;
  FUN_00554960(param_1 + 0xb,-(uint)(param_2 != 0) & param_2 + 0x2cU);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2451 ; VA 0x0054de60 ; FUN_0054de60 */

undefined4 * FUN_0054de60(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  param_1[3] = boost::exception::vftable;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0xffffffff;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::bad_function_call>::vftable;
  param_1[3] = boost::exception_detail::error_info_injector<class_boost::bad_function_call>::vftable
  ;
  return param_1;
}



/* FUNCTION 2452 ; VA 0x0054dec0 ; FUN_0054dec0 */

undefined4 * FUN_0054dec0(undefined4 *param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791b48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::system::system_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0x14);
  param_1[0xb] = boost::exception::vftable;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0xffffffff;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::thread_resource_error>::
             vftable;
  param_1[0xb] = boost::exception_detail::error_info_injector<class_boost::thread_resource_error>::
                 vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2453 ; VA 0x0054df70 ; FUN_0054df70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_0054df70(int *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined **appuStack_6c [2];
  char *pcStack_64;
  char *pcStack_60;
  undefined4 uStack_5c;
  undefined **ppuStack_58;
  int iStack_50;
  undefined **appuStack_4c [4];
  int *piStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined **ppuStack_2c;
  undefined8 uStack_28;
  int iStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791bd0;
  pvStack_10 = ExceptionList;
  piStack_3c = (int *)PTR_018bd540;
  uStack_38 = _UNK_018bd544;
  uStack_34 = _UNK_018bd548;
  uStack_30 = _UNK_018bd54c;
  appuStack_4c[3] = boost::exception_detail::bad_alloc_::vftable;
  ppuStack_2c = boost::exception_detail::bad_alloc_::vftable;
  uStack_28 = 0x18bca1c;
  appuStack_4c[0] = (undefined **)&DAT_018bd358;
  appuStack_4c[2] = boost::exception_detail::clone_base::vftable;
  uStack_8 = 1;
  uStack_14 = 2;
  ExceptionList = &pvStack_10;
  FUN_0054fbe0(appuStack_4c + 3);
  appuStack_6c[0] =
       boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_alloc_>::vftable;
  ppuStack_58 = boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_alloc_>::
                vftable;
  uStack_8 = 2;
  *(undefined ***)((int)appuStack_4c + (int)appuStack_4c[0][1]) =
       boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_alloc_>::vftable;
  *(undefined **)((int)&iStack_50 + (int)appuStack_4c[0][1]) = appuStack_4c[0][1] + -8;
  FUN_00554960(appuStack_6c,appuStack_4c + 3);
  pcStack_64 = 
  "class boost::exception_ptr __cdecl boost::exception_detail::get_static_exception_object<struct boost::exception_detail::bad_alloc_>(void)"
  ;
  pcStack_60 = 
  "C:\\teamcity-agent\\work\\Contrib2\\boost_1_56_0\\include\\boost/exception/detail/exception_ptr.hpp"
  ;
  uStack_5c = 0x80;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01e90d2c) {
    FUN_016f3809(&DAT_01e90d2c);
    if (DAT_01e90d2c == -1) {
      uStack_8._0_1_ = 4;
      piVar4 = (int *)FUN_01674e20(0x2c);
      piStack_18 = piVar4;
      if (piVar4 == (int *)0x0) {
        piVar4 = (int *)0x0;
        iStack_20 = 0;
      }
      else {
        piVar4[8] = (int)&DAT_018bd358;
        piVar4[10] = (int)boost::exception_detail::clone_base::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,6);
        uStack_14 = 6;
        FUN_0054fbe0(appuStack_6c);
        *piVar4 = (int)boost::exception_detail::
                       clone_impl<struct_boost::exception_detail::bad_alloc_>::vftable;
        piVar4[5] = (int)boost::exception_detail::
                         clone_impl<struct_boost::exception_detail::bad_alloc_>::vftable;
        uStack_8._1_3_ = 0;
        *(undefined ***)(*(int *)(piVar4[8] + 4) + 0x20 + (int)piVar4) =
             boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_alloc_>::
             vftable;
        *(undefined4 *)(*(int *)(piVar4[8] + 4) + 0x1c + (int)piVar4) = 0;
        iStack_20 = *(int *)(piVar4[8] + 4) + 0x20 + (int)piVar4;
      }
      piStack_1c = (int *)0x0;
      uStack_8._0_1_ = 7;
      puVar5 = (undefined4 *)FUN_0054d9d0(piVar4);
      piVar3 = piStack_18;
      piVar1 = (int *)*puVar5;
      *puVar5 = piStack_1c;
      uStack_8._0_1_ = 8;
      piStack_1c = piVar1;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_18[1] + -1;
        piStack_18[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_18 + 4))();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar2 = *piVar1 + -1;
          *piVar1 = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar3 + 8))();
          }
        }
      }
      _guard_check_icall(&iStack_20,piVar4,piVar4);
      piVar4 = piStack_1c;
      DAT_01e90d24 = iStack_20;
      DAT_01e90d28 = piStack_1c;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piStack_1c[1] = piStack_1c[1] + 1;
        UNLOCK();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar2 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_1c + 4))();
          LOCK();
          piVar1 = piVar4 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piVar4 + 8))();
          }
        }
      }
      FUN_016f3654(FUN_0187b040);
      FUN_016f37bf(&DAT_01e90d2c);
    }
  }
  *param_1 = DAT_01e90d24;
  piVar4 = DAT_01e90d28;
  param_1[1] = (int)DAT_01e90d28;
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar4 = piVar4 + 1;
    *piVar4 = *piVar4 + 1;
    UNLOCK();
  }
  FUN_00551820();
  appuStack_4c[3] = boost::exception_detail::bad_alloc_::vftable;
  ppuStack_2c = std::exception::vftable;
  FUN_0170c289(&uStack_28);
  appuStack_4c[3] = boost::exception::vftable;
  uStack_8 = 10;
  if (piStack_3c != (int *)0x0) {
    (**(code **)(*piStack_3c + 0x10))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2454 ; VA 0x0054e220 ; FUN_0054e220 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_0054e220(int *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined **appuStack_6c [2];
  char *pcStack_64;
  char *pcStack_60;
  undefined4 uStack_5c;
  undefined **ppuStack_58;
  int iStack_50;
  undefined **appuStack_4c [4];
  int *piStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined **ppuStack_2c;
  undefined8 uStack_28;
  int iStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791c50;
  pvStack_10 = ExceptionList;
  piStack_3c = (int *)PTR_018bd540;
  uStack_38 = _UNK_018bd544;
  uStack_34 = _UNK_018bd548;
  uStack_30 = _UNK_018bd54c;
  appuStack_4c[3] = boost::exception_detail::bad_exception_::vftable;
  ppuStack_2c = boost::exception_detail::bad_exception_::vftable;
  uStack_28 = 0x18bca00;
  appuStack_4c[0] = (undefined **)&DAT_018bd470;
  appuStack_4c[2] = boost::exception_detail::clone_base::vftable;
  uStack_8 = 1;
  uStack_14 = 2;
  ExceptionList = &pvStack_10;
  FUN_0054fce0(appuStack_4c + 3);
  appuStack_6c[0] =
       boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_exception_>::vftable;
  ppuStack_58 = boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_exception_>
                ::vftable;
  uStack_8 = 2;
  *(undefined ***)((int)appuStack_4c + (int)appuStack_4c[0][1]) =
       boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_exception_>::vftable;
  *(undefined **)((int)&iStack_50 + (int)appuStack_4c[0][1]) = appuStack_4c[0][1] + -8;
  FUN_00554960(appuStack_6c,appuStack_4c + 3);
  pcStack_64 = 
  "class boost::exception_ptr __cdecl boost::exception_detail::get_static_exception_object<struct boost::exception_detail::bad_exception_>(void)"
  ;
  pcStack_60 = 
  "C:\\teamcity-agent\\work\\Contrib2\\boost_1_56_0\\include\\boost/exception/detail/exception_ptr.hpp"
  ;
  uStack_5c = 0x80;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01e90d38) {
    FUN_016f3809(&DAT_01e90d38);
    if (DAT_01e90d38 == -1) {
      uStack_8._0_1_ = 4;
      piVar4 = (int *)FUN_01674e20(0x2c);
      piStack_18 = piVar4;
      if (piVar4 == (int *)0x0) {
        piVar4 = (int *)0x0;
        iStack_20 = 0;
      }
      else {
        piVar4[8] = (int)&DAT_018bd470;
        piVar4[10] = (int)boost::exception_detail::clone_base::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,6);
        uStack_14 = 6;
        FUN_0054fce0(appuStack_6c);
        *piVar4 = (int)boost::exception_detail::
                       clone_impl<struct_boost::exception_detail::bad_exception_>::vftable;
        piVar4[5] = (int)boost::exception_detail::
                         clone_impl<struct_boost::exception_detail::bad_exception_>::vftable;
        uStack_8._1_3_ = 0;
        *(undefined ***)(*(int *)(piVar4[8] + 4) + 0x20 + (int)piVar4) =
             boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_exception_>::
             vftable;
        *(undefined4 *)(*(int *)(piVar4[8] + 4) + 0x1c + (int)piVar4) = 0;
        iStack_20 = *(int *)(piVar4[8] + 4) + 0x20 + (int)piVar4;
      }
      piStack_1c = (int *)0x0;
      uStack_8._0_1_ = 7;
      puVar5 = (undefined4 *)FUN_0054da60(piVar4);
      piVar3 = piStack_18;
      piVar1 = (int *)*puVar5;
      *puVar5 = piStack_1c;
      uStack_8._0_1_ = 8;
      piStack_1c = piVar1;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_18[1] + -1;
        piStack_18[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_18 + 4))();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar2 = *piVar1 + -1;
          *piVar1 = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar3 + 8))();
          }
        }
      }
      _guard_check_icall(&iStack_20,piVar4,piVar4);
      piVar4 = piStack_1c;
      DAT_01e90d30 = iStack_20;
      DAT_01e90d34 = piStack_1c;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piStack_1c[1] = piStack_1c[1] + 1;
        UNLOCK();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar2 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_1c + 4))();
          LOCK();
          piVar1 = piVar4 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piVar4 + 8))();
          }
        }
      }
      FUN_016f3654(FUN_0187b0a0);
      FUN_016f37bf(&DAT_01e90d38);
    }
  }
  *param_1 = DAT_01e90d30;
  piVar4 = DAT_01e90d34;
  param_1[1] = (int)DAT_01e90d34;
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar4 = piVar4 + 1;
    *piVar4 = *piVar4 + 1;
    UNLOCK();
  }
  FUN_005518c0();
  appuStack_4c[3] = boost::exception_detail::bad_exception_::vftable;
  ppuStack_2c = std::exception::vftable;
  FUN_0170c289(&uStack_28);
  appuStack_4c[3] = boost::exception::vftable;
  uStack_8 = 10;
  if (piStack_3c != (int *)0x0) {
    (**(code **)(*piStack_3c + 0x10))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2455 ; VA 0x0054e4d0 ; FUN_0054e4d0 */

void FUN_0054e4d0(int *param_1)

{
  longlong lVar1;
  longlong lVar2;
  undefined8 uVar3;
  undefined8 uStack_14;
  int iStack_c;
  
  if ((param_1[1] < 1) && ((param_1[1] < 0 || (*param_1 == 0)))) {
    iStack_c = 0;
    uStack_14 = 0;
  }
  else {
    lVar1 = FUN_016de945();
    lVar2 = FUN_016f39b0(*param_1,param_1[1],10000000,0);
    uVar3 = FUN_016f39b0(lVar1 + lVar2,100,0);
    uStack_14 = FUN_016f3900(uVar3,1000000000,0);
    iStack_c = (int)uVar3 + (int)uStack_14 * -1000000000;
  }
  FUN_016de839(&uStack_14);
  return;
}



/* FUNCTION 2456 ; VA 0x0054e560 ; FUN_0054e560 */

void FUN_0054e560(uint *param_1)

{
  int iVar1;
  undefined8 uVar2;
  undefined8 uStack_14;
  int iStack_c;
  
  if (((int)param_1[1] < 1) && (((int)param_1[1] < 0 || (*param_1 == 0)))) {
    iStack_c = 0;
    uStack_14 = 0;
  }
  else {
    uVar2 = FUN_016de945();
    uVar2 = FUN_016f39b0(uVar2,100,0);
    iVar1 = (uint)uVar2 + *param_1;
    uStack_14 = FUN_016f3900(iVar1,(int)((ulonglong)uVar2 >> 0x20) + param_1[1] +
                                   (uint)CARRY4((uint)uVar2,*param_1),1000000000,0);
    iStack_c = iVar1 + (int)uStack_14 * -1000000000;
  }
  FUN_016de839(&uStack_14);
  return;
}



/* FUNCTION 2457 ; VA 0x0054e5e0 ; FUN_0054e5e0 */

void FUN_0054e5e0(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_5c [44];
  undefined auStack_30 [32];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791c68;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0054de60(auStack_30,param_1);
  uStack_8 = 0;
  FUN_0054dcd0(auStack_5c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_5c,&DAT_01c173d4);
}



/* FUNCTION 2458 ; VA 0x0054e630 ; FUN_0054e630 */

void FUN_0054e630(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_9c [64];
  undefined auStack_5c [76];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791c8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0054dec0(auStack_9c,param_1);
  uStack_8 = 0;
  FUN_0054ddb0(auStack_5c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_5c,&DAT_01c172bc);
}



/* FUNCTION 2459 ; VA 0x0054e680 ; FUN_0054e680 */

int * FUN_0054e680(int param_1)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  undefined1 *puVar5;
  bool bVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791cbf;
  pvStack_10 = ExceptionList;
  bVar6 = false;
  ExceptionList = &pvStack_10;
  FUN_016dda75(0);
  piVar2 = DAT_01e90d20;
  uStack_8 = 0;
  if (DAT_01e90cfc == 0) {
    FUN_016dda75(0);
    if (DAT_01e90cfc == 0) {
      DAT_01e90cfc = DAT_021130c8 + 1;
      DAT_021130c8 = DAT_01e90cfc;
    }
    FUN_016ddacd();
  }
  uVar1 = DAT_01e90cfc;
  iVar3 = *(int *)(param_1 + 4);
  if (DAT_01e90cfc < *(uint *)(iVar3 + 0xc)) {
    piVar4 = *(int **)(*(int *)(iVar3 + 8) + DAT_01e90cfc * 4);
    if (piVar4 != (int *)0x0) goto LAB_0054e7b1;
  }
  else {
    piVar4 = (int *)0x0;
  }
  if (*(char *)(iVar3 + 0x14) == '\0') {
LAB_0054e723:
    if (piVar4 != (int *)0x0) goto LAB_0054e7b1;
  }
  else {
    iVar3 = FUN_016de17b();
    if (uVar1 < *(uint *)(iVar3 + 0xc)) {
      piVar4 = *(int **)(*(int *)(iVar3 + 8) + uVar1 * 4);
      goto LAB_0054e723;
    }
  }
  piVar4 = piVar2;
  if (piVar2 == (int *)0x0) {
    piVar4 = (int *)FUN_01674e20(8);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (piVar4 == (int *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      iVar3 = *(int *)(param_1 + 4);
      if (iVar3 == 0) {
        puVar5 = &DAT_018bc9b8;
      }
      else {
        puVar5 = *(undefined1 **)(iVar3 + 0x18);
        if (puVar5 == (undefined1 *)0x0) {
          puVar5 = (undefined1 *)(iVar3 + 0x1c);
        }
      }
      FUN_0054f870(puVar5);
      bVar6 = true;
      piVar4[1] = 0;
      *piVar4 = (int)std::codecvt<char,char,struct__Mbstatet>::vftable;
    }
    if (bVar6) {
      FUN_00550e70();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_016de14f(piVar4);
    (**(code **)(*piVar4 + 4))();
    DAT_01e90d20 = piVar4;
  }
LAB_0054e7b1:
  FUN_016ddacd();
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 2460 ; VA 0x0054e7d0 ; FUN_0054e7d0 */

int * FUN_0054e7d0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  undefined1 *puVar6;
  int *piVar7;
  undefined auStack_30 [20];
  int *piStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791cef;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_016dda75(0);
  uStack_8 = 0;
  piStack_1c = DAT_01e90d10;
  if (DAT_021130e0 == 0) {
    FUN_016dda75(0);
    if (DAT_021130e0 == 0) {
      DAT_021130c8 = DAT_021130c8 + 1;
      DAT_021130e0 = DAT_021130c8;
    }
    FUN_016ddacd();
  }
  uVar3 = DAT_021130e0;
  iVar4 = *(int *)(param_1 + 4);
  if (DAT_021130e0 < *(uint *)(iVar4 + 0xc)) {
    piVar5 = *(int **)(*(int *)(iVar4 + 8) + DAT_021130e0 * 4);
    if (piVar5 != (int *)0x0) goto LAB_0054e920;
  }
  else {
    piVar5 = (int *)0x0;
  }
  if (*(char *)(iVar4 + 0x14) == '\0') {
LAB_0054e879:
    if (piVar5 != (int *)0x0) goto LAB_0054e920;
  }
  else {
    iVar4 = FUN_016de17b();
    if (uVar3 < *(uint *)(iVar4 + 0xc)) {
      piVar5 = *(int **)(*(int *)(iVar4 + 8) + uVar3 * 4);
      goto LAB_0054e879;
    }
  }
  piVar5 = piStack_1c;
  if (piStack_1c == (int *)0x0) {
    piVar5 = (int *)FUN_01674e20(0x18);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    piStack_1c = piVar5;
    if (piVar5 == (int *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      iVar4 = *(int *)(param_1 + 4);
      if (iVar4 == 0) {
        puVar6 = &DAT_018bc9b8;
      }
      else {
        puVar6 = *(undefined1 **)(iVar4 + 0x18);
        if (puVar6 == (undefined1 *)0x0) {
          puVar6 = (undefined1 *)(iVar4 + 0x1c);
        }
      }
      FUN_0054f870(puVar6);
      uStack_14 = 1;
      piVar5[1] = 0;
      *piVar5 = (int)std::ctype<char>::vftable;
      piVar7 = (int *)FUN_016ddd3f(auStack_30);
      iVar4 = piVar7[1];
      iVar1 = piVar7[2];
      iVar2 = piVar7[3];
      piVar5[2] = *piVar7;
      piVar5[3] = iVar4;
      piVar5[4] = iVar1;
      piVar5[5] = iVar2;
    }
    if ((uStack_14 & 1) != 0) {
      FUN_00550e70();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_016de14f(piVar5);
    (**(code **)(*piVar5 + 4))();
    DAT_01e90d10 = piVar5;
  }
LAB_0054e920:
  FUN_016ddacd();
  ExceptionList = pvStack_10;
  return piVar5;
}



/* FUNCTION 2461 ; VA 0x0054e940 ; FUN_0054e940 */

undefined4 __thiscall FUN_0054e940(undefined4 param_1,undefined4 param_2)

{
  FUN_0054e9f0(param_2);
  return param_1;
}



/* FUNCTION 2462 ; VA 0x0054e960 ; FUN_0054e960 */

int * __thiscall FUN_0054e960(int *param_1,int *param_2)

{
  int iVar1;
  code *pcVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  iVar1 = *param_2;
  puVar3 = (undefined4 *)(**(code **)(**(int **)(iVar1 + -0x10) + 0x10))();
  if ((-1 < *(int *)(iVar1 + -4)) && (puVar3 == *(undefined4 **)(iVar1 + -0x10))) {
    LOCK();
    *(int *)(iVar1 + -4) = *(int *)(iVar1 + -4) + 1;
    UNLOCK();
    *param_1 = iVar1;
    return param_1;
  }
  iVar4 = (**(code **)*puVar3)(*(undefined4 *)(iVar1 + -0xc),1);
  if (iVar4 != 0) {
    *(int *)(iVar4 + 4) = *(int *)(iVar1 + -0xc);
    iVar5 = *(int *)(iVar1 + -0xc) + 1;
    FUN_00557ba0(iVar4 + 0x10,iVar5,iVar1,iVar5);
    *param_1 = iVar4 + 0x10;
    return param_1;
  }
  FUN_005534b0();
  pcVar2 = (code *)swi(3);
  piVar6 = (int *)(*pcVar2)();
  return piVar6;
}



/* FUNCTION 2463 ; VA 0x0054e9f0 ; FUN_0054e9f0 */

int * __thiscall FUN_0054e9f0(int *param_1,char *param_2)

{
  int *piVar1;
  char cVar2;
  uint uVar3;
  code *pcVar4;
  int *piVar5;
  undefined4 *puVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  char *pcVar10;
  uint uVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791d08;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar5 = (int *)FUN_005527b0();
  if (piVar5 == (int *)0x0) {
    FUN_005522b0(0x80004005);
LAB_0054eb72:
    FUN_005522b0(0x80070057);
LAB_0054eb7c:
    FUN_005522b0(0x80070057);
    pcVar4 = (code *)swi(3);
    piVar5 = (int *)(*pcVar4)();
    return piVar5;
  }
  puVar6 = (undefined4 *)(**(code **)(*piVar5 + 0xc))();
  *param_1 = (int)(puVar6 + 4);
  uStack_8 = 0;
  if (param_2 != (char *)0x0) {
    if (((uint)param_2 & 0xffff0000) == 0) {
      FUN_00552980((uint)param_2 & 0xffff);
      ExceptionList = pvStack_10;
      return param_1;
    }
    pcVar10 = param_2;
    do {
      cVar2 = *pcVar10;
      pcVar10 = pcVar10 + 1;
    } while (cVar2 != '\0');
    uVar11 = (int)pcVar10 - (int)(param_2 + 1);
    if (uVar11 != 0) {
      uVar3 = puVar6[1];
      uVar7 = (int)param_2 - (int)(puVar6 + 4);
      if (-1 < (int)uVar11) {
        if ((int)(1 - puVar6[3] | puVar6[2] - uVar11) < 0) {
          FUN_00552b90(uVar11);
        }
        iVar8 = *param_1;
        if (uVar3 < uVar7) {
          FUN_00557ba0(iVar8,*(undefined4 *)(iVar8 + -8),param_2,uVar11);
        }
        else {
          iVar9 = uVar7 + iVar8;
          if ((iVar8 == 0) || (iVar9 == 0)) {
            puVar6 = (undefined4 *)FUN_0171689d();
            *puVar6 = 0x16;
            FUN_01716793();
          }
          else if (*(uint *)(iVar8 + -8) < uVar11) {
            puVar6 = (undefined4 *)FUN_0171689d();
            *puVar6 = 0x22;
            FUN_01716793();
          }
          else {
            FUN_0170cc70(iVar8,iVar9,uVar11);
          }
        }
        if ((int)uVar11 <= *(int *)(*param_1 + -8)) {
          *(uint *)(*param_1 + -0xc) = uVar11;
          *(undefined *)(uVar11 + *param_1) = 0;
          ExceptionList = pvStack_10;
          return param_1;
        }
      }
      goto LAB_0054eb72;
    }
  }
  piVar5 = (int *)*puVar6;
  uStack_8 = 1;
  if (puVar6[1] != 0) {
    piVar1 = puVar6 + 3;
    if ((int)puVar6[3] < 0) {
      if ((int)puVar6[2] < 0) goto LAB_0054eb7c;
      puVar6[1] = 0;
      *(undefined *)*param_1 = 0;
    }
    else {
      LOCK();
      iVar8 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar8 == 1 || iVar8 + -1 < 0) {
        (**(code **)(*(int *)*puVar6 + 4))(puVar6);
      }
      iVar8 = (**(code **)(*piVar5 + 0xc))();
      *param_1 = iVar8 + 0x10;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2464 ; VA 0x0054eb90 ; FUN_0054eb90 */

undefined4 __fastcall FUN_0054eb90(undefined4 param_1)

{
  return param_1;
}



/* FUNCTION 2465 ; VA 0x0054eba0 ; FUN_0054eba0 */

undefined4 * __thiscall FUN_0054eba0(undefined4 *param_1,undefined4 param_2)

{
  FUN_0054ee60();
  *param_1 = std::basic_filebuf<char,struct_std::char_traits<char>_>::vftable;
  FUN_00553bc0(param_2,0);
  return param_1;
}



/* FUNCTION 2466 ; VA 0x0054ebd0 ; FUN_0054ebd0 */

int * __thiscall
FUN_0054ebd0(int *param_1,undefined4 param_2,uint param_3,undefined4 param_4,int param_5)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  bool bVar6;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791d5a;
  pvStack_10 = ExceptionList;
  bVar6 = param_5 != 0;
  ExceptionList = &pvStack_10;
  if (bVar6) {
    ExceptionList = &pvStack_10;
    *param_1 = (int)&PTR_018bd138;
    param_1[0x1c] = (int)std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
    uStack_8 = 0;
  }
  uStack_14 = (uint)bVar6;
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x18;
  param_1[2] = 0;
  param_1[3] = 0;
  piStack_18 = param_1;
  FUN_00554f20(param_1 + 4,0);
  uStack_8 = 2;
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_ifstream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x70;
  FUN_0054ee60();
  param_1[4] = (int)std::basic_filebuf<char,struct_std::char_traits<char>_>::vftable;
  param_1[7] = (int)(param_1 + 5);
  *(undefined *)(param_1 + 0x16) = 0;
  param_1[0xb] = (int)(param_1 + 9);
  param_1[0xc] = (int)(param_1 + 10);
  param_1[0xf] = (int)(param_1 + 0xd);
  param_1[0x10] = (int)(param_1 + 0xe);
  *(undefined *)((int)param_1 + 0x4d) = 0;
  param_1[8] = (int)(param_1 + 6);
  param_1[6] = 0;
  *(undefined4 *)param_1[0xc] = 0;
  *(undefined4 *)param_1[0x10] = 0;
  *(undefined4 *)param_1[7] = 0;
  *(undefined4 *)param_1[0xb] = 0;
  *(undefined4 *)param_1[0xf] = 0;
  param_1[0x17] = 0;
  param_1[0x14] = DAT_01e90d08;
  param_1[0x15] = DAT_01e90d0c;
  param_1[0x12] = 0;
  uStack_8._0_1_ = 3;
  iVar3 = FUN_016de722(param_2,param_3 | 1,param_4);
  if (iVar3 == 0) {
    FUN_00554460((uint)(*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) == 0) * 4 + 2 |
                 *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc),0);
  }
  else {
    FUN_00553bc0(iVar3,1);
    piVar1 = *(int **)(param_1[0x11] + 4);
    uStack_8._0_1_ = 4;
    piStack_1c = piVar1;
    (**(code **)(*piVar1 + 4))();
    uStack_14 = bVar6 | 4;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    piVar4 = (int *)FUN_0054e680(auStack_20);
    cVar2 = (**(code **)(*piVar4 + 0xc))();
    if (cVar2 == '\0') {
      param_1[0x12] = (int)piVar4;
      FUN_00553ca0();
    }
    else {
      param_1[0x12] = 0;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (piVar1 != (int *)0x0) {
      puVar5 = (undefined4 *)(**(code **)(*piVar1 + 8))();
      if (puVar5 != (undefined4 *)0x0) {
        (**(code **)*puVar5)(1);
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2467 ; VA 0x0054edc0 ; FUN_0054edc0 */

int * __thiscall FUN_0054edc0(int *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791d8c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    ExceptionList = &pvStack_10;
    *param_1 = (int)&PTR_018bd0e8;
    param_1[6] = (int)std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
    uStack_8 = 0;
  }
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x18;
  param_1[2] = 0;
  param_1[3] = 0;
  FUN_00554f20(param_2,param_3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2468 ; VA 0x0054ee60 ; FUN_0054ee60 */

undefined4 * __fastcall FUN_0054ee60(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::basic_streambuf<char,struct_std::char_traits<char>_>::vftable;
  iVar1 = FUN_01674e20(8);
  if (iVar1 == 0) {
    iVar1 = 0;
  }
  else {
    uStack_8 = 0;
    uVar2 = FUN_016de181(1);
    *(undefined4 *)(iVar1 + 4) = uVar2;
  }
  param_1[0xd] = iVar1;
  param_1[3] = param_1 + 1;
  param_1[4] = param_1 + 2;
  param_1[7] = param_1 + 5;
  param_1[8] = param_1 + 6;
  param_1[0xb] = param_1 + 9;
  param_1[0xc] = param_1 + 10;
  param_1[2] = 0;
  *(undefined4 *)param_1[8] = 0;
  *(undefined4 *)param_1[0xc] = 0;
  *(undefined4 *)param_1[3] = 0;
  *(undefined4 *)param_1[7] = 0;
  *(undefined4 *)param_1[0xb] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2469 ; VA 0x0054ef20 ; FUN_0054ef20 */

undefined4 * __thiscall FUN_0054ef20(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  param_1[4] = 0;
  param_1[5] = 0;
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  *param_1 = *param_2;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(param_2 + 4);
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  return param_1;
}



/* FUNCTION 2470 ; VA 0x0054ef60 ; FUN_0054ef60 */

undefined4 * __thiscall FUN_0054ef60(undefined4 *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  
  param_1[4] = 0;
  param_1[5] = 0;
  uVar1 = param_2[4];
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  if (uVar1 < 0x10) {
    uVar4 = param_2[1];
    uVar2 = param_2[2];
    uVar3 = param_2[3];
    *param_1 = *param_2;
    param_1[1] = uVar4;
    param_1[2] = uVar2;
    param_1[3] = uVar3;
    param_1[4] = uVar1;
    param_1[5] = 0xf;
    return param_1;
  }
  uVar5 = uVar1 | 0xf;
  if (0x7fffffff < uVar5) {
    uVar5 = 0x7fffffff;
  }
  uVar4 = FUN_00554060(uVar5 + 1);
  *param_1 = uVar4;
  FUN_0170c6f0(uVar4,param_2,uVar1 + 1);
  param_1[4] = uVar1;
  param_1[5] = uVar5;
  return param_1;
}



/* FUNCTION 2471 ; VA 0x0054eff0 ; FUN_0054eff0 */

undefined * __thiscall FUN_0054eff0(undefined *param_1,char *param_2)

{
  char cVar1;
  char *pcVar2;
  
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  pcVar2 = param_2;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_2,(int)pcVar2 - (int)(param_2 + 1));
  return param_1;
}



/* FUNCTION 2472 ; VA 0x0054f030 ; FUN_0054f030 */

undefined * __fastcall FUN_0054f030(undefined *param_1)

{
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  return param_1;
}



/* FUNCTION 2473 ; VA 0x0054f050 ; FUN_0054f050 */

undefined4 * __thiscall FUN_0054f050(undefined4 *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  
  param_1[4] = 0;
  param_1[5] = 0;
  uVar1 = param_2[4];
  if (7 < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  if (uVar1 < 8) {
    uVar4 = param_2[1];
    uVar2 = param_2[2];
    uVar3 = param_2[3];
    *param_1 = *param_2;
    param_1[1] = uVar4;
    param_1[2] = uVar2;
    param_1[3] = uVar3;
    param_1[4] = uVar1;
    param_1[5] = 7;
    return param_1;
  }
  uVar5 = uVar1 | 7;
  if (0x7ffffffe < uVar5) {
    uVar5 = 0x7ffffffe;
  }
  uVar4 = FUN_005540c0(uVar5 + 1);
  *param_1 = uVar4;
  FUN_0170c6f0(uVar4,param_2,uVar1 * 2 + 2);
  param_1[4] = uVar1;
  param_1[5] = uVar5;
  return param_1;
}



/* FUNCTION 2474 ; VA 0x0054f0e0 ; FUN_0054f0e0 */

undefined4 * __thiscall FUN_0054f0e0(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791dd4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018bd31c;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::bad_function_call::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_function_call>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_function_call>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_function_call>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2475 ; VA 0x0054f1c0 ; FUN_0054f1c0 */

undefined4 * __thiscall FUN_0054f1c0(undefined4 *param_1,undefined4 param_2,int param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791dfc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[0x10] = &DAT_018bd2dc;
    param_1[0x12] = boost::exception_detail::clone_base::vftable;
    uStack_8 = 0;
  }
  FUN_0054f450(param_2);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::thread_resource_error>_>
             ::vftable;
  param_1[0xb] = boost::exception_detail::
                 clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::thread_resource_error>_>
                 ::vftable;
  *(undefined ***)(*(int *)(param_1[0x10] + 4) + 0x40 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::thread_resource_error>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[0x10] + 4) + 0x3c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2476 ; VA 0x0054f250 ; FUN_0054f250 */

undefined4 * __thiscall FUN_0054f250(undefined4 *param_1,undefined4 param_2,int param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791e2c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018bd358;
    param_1[10] = boost::exception_detail::clone_base::vftable;
    uStack_8 = 0;
  }
  FUN_0054fbe0(param_2);
  *param_1 = boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_alloc_>::
             vftable;
  param_1[5] = boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_alloc_>::
               vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_alloc_>::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2477 ; VA 0x0054f2e0 ; FUN_0054f2e0 */

undefined4 * __thiscall FUN_0054f2e0(undefined4 *param_1,undefined4 param_2,int param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791e2c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018bd470;
    param_1[10] = boost::exception_detail::clone_base::vftable;
    uStack_8 = 0;
  }
  FUN_0054fce0(param_2);
  *param_1 = boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_exception_>::
             vftable;
  param_1[5] = boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_exception_>::
               vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_exception_>::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2478 ; VA 0x0054f370 ; FUN_0054f370 */

undefined4 * __thiscall FUN_0054f370(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined auStack_18 [16];
  undefined4 *puStack_8;
  
  param_1[1] = param_3;
  *param_1 = std::ctype<char>::vftable;
  puStack_8 = param_1;
  puVar4 = (undefined4 *)FUN_016ddd3f(auStack_18);
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  param_1[2] = *puVar4;
  param_1[3] = uVar1;
  param_1[4] = uVar2;
  param_1[5] = uVar3;
  return param_1;
}



/* FUNCTION 2479 ; VA 0x0054f3b0 ; FUN_0054f3b0 */

undefined4 * __thiscall FUN_0054f3b0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791e48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::bad_function_call::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::error_info_injector<class_boost::bad_function_call>::vftable;
  param_1[3] = boost::exception_detail::error_info_injector<class_boost::bad_function_call>::vftable
  ;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2480 ; VA 0x0054f450 ; FUN_0054f450 */

undefined4 * __thiscall FUN_0054f450(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791e70;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::system::system_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0x14);
  *param_1 = boost::thread_resource_error::vftable;
  param_1[0xb] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x30);
  uStack_8 = 1;
  param_1[0xc] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[0xd] = *(undefined4 *)(param_2 + 0x34);
  param_1[0xe] = *(undefined4 *)(param_2 + 0x38);
  param_1[0xf] = *(undefined4 *)(param_2 + 0x3c);
  *param_1 = boost::exception_detail::error_info_injector<class_boost::thread_resource_error>::
             vftable;
  param_1[0xb] = boost::exception_detail::error_info_injector<class_boost::thread_resource_error>::
                 vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2481 ; VA 0x0054f510 ; FUN_0054f510 */

uint * __thiscall FUN_0054f510(uint *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  
  *param_1 = 0;
  uVar1 = *param_2;
  if (uVar1 != 0) {
    *param_1 = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar1 = param_2[3];
      uVar2 = param_2[4];
      uVar3 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar1;
      param_1[4] = uVar2;
      param_1[5] = uVar3;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
  }
  return param_1;
}



/* FUNCTION 2482 ; VA 0x0054f570 ; FUN_0054f570 */

undefined4 * __thiscall FUN_0054f570(undefined4 *param_1,undefined4 param_2)

{
  param_1[2] = param_2;
  *param_1 = 0;
  param_1[1] = 0;
  return param_1;
}



/* FUNCTION 2483 ; VA 0x0054f590 ; FUN_0054f590 */

undefined * __fastcall FUN_0054f590(undefined *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791eec;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_005542c0("0, 0, 0, 0",10);
  uStack_8 = 0;
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0xf;
  param_1[0x18] = 0;
  FUN_005542c0("0.0.0.0",7);
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined4 *)(param_1 + 0x44) = 0xf;
  param_1[0x30] = 0;
  *(undefined4 *)(param_1 + 0x58) = 0;
  *(undefined4 *)(param_1 + 0x5c) = 0xf;
  param_1[0x48] = 0;
  *(undefined4 *)(param_1 + 0x60) = 0xfddd;
  *(undefined4 *)(param_1 + 0x74) = 0;
  *(undefined4 *)(param_1 + 0x78) = 0xf;
  uStack_8._0_1_ = 3;
  param_1[100] = 0;
  FUN_005542c0("content",7);
  *(undefined2 *)(param_1 + 0x7c) = 0;
  *(undefined4 *)(param_1 + 0x90) = 0;
  *(undefined4 *)(param_1 + 0x94) = 0xf;
  param_1[0x80] = 0;
  *(undefined4 *)(param_1 + 0xa8) = 0;
  *(undefined4 *)(param_1 + 0xac) = 0xf;
  param_1[0x98] = 0;
  *(undefined4 *)(param_1 + 0xc0) = 0;
  *(undefined4 *)(param_1 + 0xc4) = 0xf;
  param_1[0xb0] = 0;
  *(undefined4 *)(param_1 + 0xd8) = 0;
  *(undefined4 *)(param_1 + 0xdc) = 0xf;
  param_1[200] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  *(undefined4 *)(param_1 + 0xf0) = 0;
  *(undefined4 *)(param_1 + 0xf4) = 0xf;
  param_1[0xe0] = 0;
  FUN_005542c0("gameserver.txt",0xe);
  param_1[0xf8] = 0;
  *(undefined4 *)(param_1 + 0x10c) = 0;
  *(undefined4 *)(param_1 + 0x110) = 0xf;
  param_1[0xfc] = 0;
  *(undefined4 *)(param_1 + 0x124) = 0;
  *(undefined4 *)(param_1 + 0x128) = 0xf;
  param_1[0x114] = 0;
  param_1[300] = 0;
  *(undefined4 *)(param_1 + 0x140) = 0;
  *(undefined4 *)(param_1 + 0x144) = 0xf;
  param_1[0x130] = 0;
  *(undefined4 *)(param_1 + 0x148) = 0;
  *(undefined4 *)(param_1 + 0x14c) = 0;
  *(undefined4 *)(param_1 + 0x150) = 0xffffffff;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2484 ; VA 0x0054f770 ; FUN_0054f770 */

undefined4 * __thiscall FUN_0054f770(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  uVar1 = FUN_01675290(param_2);
  *param_1 = uVar1;
  return param_1;
}



/* FUNCTION 2485 ; VA 0x0054f790 ; FUN_0054f790 */

undefined4 * __fastcall FUN_0054f790(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[6] = 0;
  param_1[7] = 0xf;
  *(undefined *)(param_1 + 2) = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  *(undefined *)(param_1 + 0xe) = 0;
  return param_1;
}



/* FUNCTION 2486 ; VA 0x0054f7e0 ; FUN_0054f7e0 */

undefined4 * __thiscall FUN_0054f7e0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791f08;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008828b0(param_2);
  *param_1 = TextXmlParser::vftable;
  uStack_8 = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  uVar1 = FUN_005535a0();
  param_1[7] = uVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2487 ; VA 0x0054f850 ; FUN_0054f850 */

undefined * __thiscall FUN_0054f850(undefined *param_1,undefined4 param_2,undefined param_3)

{
  *param_1 = param_3;
  *(undefined4 *)(param_1 + 4) = param_2;
  return param_1;
}



/* FUNCTION 2488 ; VA 0x0054f870 ; FUN_0054f870 */

int __thiscall FUN_0054f870(int param_1,int param_2)

{
  undefined auStack_20 [12];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791f6a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_016dda75(0);
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  *(undefined *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined2 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined2 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined *)(param_1 + 0x30) = 0;
  uStack_8 = 6;
  if (param_2 != 0) {
    FUN_016de288(param_1,param_2);
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_00550130("bad locale name");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_20,&DAT_01c17198);
}



/* FUNCTION 2489 ; VA 0x0054f920 ; FUN_0054f920 */

int __fastcall FUN_0054f920(int param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791f90;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_016df16d(param_1 + 4);
  if (iVar1 != 0) {
    FUN_016df3c9(iVar1);
  }
  uStack_8 = 0;
  iVar1 = FUN_016dee1a((undefined4 *)(param_1 + 8),1);
  if (iVar1 != 0) {
    FUN_016df3c9(iVar1);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *(undefined *)(param_1 + 0xc) = 0;
  iVar1 = FUN_016dee6d(*(undefined4 *)(param_1 + 8));
  if (iVar1 != 0) {
    FUN_016df3c9(iVar1);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2490 ; VA 0x0054f9c0 ; FUN_0054f9c0 */

undefined4 * __thiscall
FUN_0054f9c0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  undefined4 ****ppppuVar1;
  uint uVar2;
  undefined4 ***pppuStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  uint uStack_50;
  undefined4 ***apppuStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  undefined4 ***pppuStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  uint uStack_20;
  undefined4 ***pppuStack_1c;
  undefined uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fb0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60(param_4);
  uStack_8 = 0;
  if (iStack_24 != 0) {
    FUN_00554150(&DAT_018bcaac,2);
  }
  (**(code **)(*param_3 + 8))(apppuStack_4c,param_2);
  ppppuVar1 = apppuStack_4c;
  if (0xf < uStack_38) {
    ppppuVar1 = (undefined4 ****)apppuStack_4c[0];
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00554150(ppppuVar1,uStack_3c);
  if (0xf < uStack_38) {
    uVar2 = uStack_38 + 1;
    ppppuVar1 = (undefined4 ****)apppuStack_4c[0];
    if (0xfff < uVar2) {
      ppppuVar1 = (undefined4 ****)apppuStack_4c[0][-1];
      uVar2 = uStack_38 + 0x24;
      if (0x1f < (uint)((int)apppuStack_4c[0] + (-4 - (int)ppppuVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar1,uVar2);
  }
  *param_1 = std::exception::vftable;
  uStack_50 = uStack_20;
  *(undefined8 *)(param_1 + 1) = 0;
  pppuStack_64 = pppuStack_34;
  uStack_60 = uStack_30;
  uStack_5c = uStack_2c;
  uStack_58 = uStack_28;
  pppuStack_1c = &pppuStack_64;
  if (0xf < uStack_20) {
    pppuStack_1c = pppuStack_34;
  }
  iStack_24 = 0;
  uStack_20 = 0xf;
  pppuStack_34 = (undefined4 ***)((uint)pppuStack_34 & 0xffffff00);
  uStack_18 = 1;
  FUN_0170c226(&pppuStack_1c,param_1 + 1);
  *param_1 = std::runtime_error::vftable;
  if (0xf < uStack_50) {
    uVar2 = uStack_50 + 1;
    ppppuVar1 = (undefined4 ****)pppuStack_64;
    if (0xfff < uVar2) {
      ppppuVar1 = (undefined4 ****)pppuStack_64[-1];
      uVar2 = uStack_50 + 0x24;
      if (0x1f < (uint)((int)pppuStack_64 + (-4 - (int)ppppuVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar1,uVar2);
  }
  param_1[3] = param_2;
  param_1[4] = param_3;
  *param_1 = std::_System_error::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2491 ; VA 0x0054fb30 ; FUN_0054fb30 */

undefined4 * __thiscall FUN_0054fb30(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::_System_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  return param_1;
}



/* FUNCTION 2492 ; VA 0x0054fb80 ; FUN_0054fb80 */

undefined4 * __thiscall FUN_0054fb80(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::bad_alloc::vftable;
  return param_1;
}



/* FUNCTION 2493 ; VA 0x0054fbc0 ; FUN_0054fbc0 */

undefined4 * __fastcall FUN_0054fbc0(undefined4 *param_1)

{
  *(undefined8 *)(param_1 + 1) = 0;
  param_1[1] = "bad allocation";
  *param_1 = std::bad_alloc::vftable;
  return param_1;
}



/* FUNCTION 2494 ; VA 0x0054fbe0 ; FUN_0054fbe0 */

undefined4 * __thiscall FUN_0054fbe0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  
  *param_1 = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 4);
  param_1[1] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[2] = *(undefined4 *)(param_2 + 8);
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  param_1[5] = std::exception::vftable;
  *(undefined8 *)(param_1 + 6) = 0;
  FUN_0170c226(param_2 + 0x18,param_1 + 6);
  param_1[5] = std::bad_alloc::vftable;
  *param_1 = boost::exception_detail::bad_alloc_::vftable;
  param_1[5] = boost::exception_detail::bad_alloc_::vftable;
  return param_1;
}



/* FUNCTION 2495 ; VA 0x0054fc60 ; FUN_0054fc60 */

undefined4 * __fastcall FUN_0054fc60(undefined4 *param_1)

{
  *(undefined8 *)(param_1 + 1) = 0;
  param_1[1] = "bad cast";
  *param_1 = std::bad_cast::vftable;
  return param_1;
}



/* FUNCTION 2496 ; VA 0x0054fc80 ; FUN_0054fc80 */

undefined4 * __thiscall FUN_0054fc80(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::bad_exception::vftable;
  return param_1;
}



/* FUNCTION 2497 ; VA 0x0054fcc0 ; FUN_0054fcc0 */

undefined4 * __fastcall FUN_0054fcc0(undefined4 *param_1)

{
  *(undefined8 *)(param_1 + 1) = 0;
  param_1[1] = "bad exception";
  *param_1 = std::bad_exception::vftable;
  return param_1;
}



/* FUNCTION 2498 ; VA 0x0054fce0 ; FUN_0054fce0 */

undefined4 * __thiscall FUN_0054fce0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  
  *param_1 = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 4);
  param_1[1] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[2] = *(undefined4 *)(param_2 + 8);
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  param_1[5] = std::exception::vftable;
  *(undefined8 *)(param_1 + 6) = 0;
  FUN_0170c226(param_2 + 0x18,param_1 + 6);
  param_1[5] = std::bad_exception::vftable;
  *param_1 = boost::exception_detail::bad_exception_::vftable;
  param_1[5] = boost::exception_detail::bad_exception_::vftable;
  return param_1;
}



/* FUNCTION 2499 ; VA 0x0054fd60 ; FUN_0054fd60 */

undefined4 * __thiscall FUN_0054fd60(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::bad_function_call::vftable;
  return param_1;
}


