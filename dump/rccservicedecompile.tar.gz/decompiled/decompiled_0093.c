/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 23250 ; VA 0x00b0d5d0 ; FUN_00b0d5d0 */

void __thiscall FUN_00b0d5d0(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = 0x1f;
  if (param_2 < 0x1f) {
    iVar1 = param_2;
  }
  if (iVar1 < 1) {
    iVar1 = 0;
  }
  if (iVar1 != *(char *)(*(int *)(param_1 + 0xa8) + 0x22a)) {
    FUN_00c18180(iVar1);
    FUN_008a4940(&DAT_01eedb38);
  }
  return;
}



/* FUNCTION 23251 ; VA 0x00b0d620 ; FUN_00b0d620 */

void FUN_00b0d620(float *param_1)

{
  float *pfVar1;
  
  pfVar1 = param_1 + 2;
  param_1._0_2_ =
       CONCAT11((char)(int)(param_1[1] * DAT_018f9000),(char)(int)(*param_1 * DAT_018f9000));
  FUN_00b0d6a0(CONCAT12((char)(int)(*pfVar1 * DAT_018f9000),param_1._0_2_));
  return;
}



/* FUNCTION 23252 ; VA 0x00b0d680 ; FUN_00b0d680 */

void FUN_00b0d680(undefined3 param_1)

{
  FUN_00b0d6a0(param_1);
  return;
}



/* FUNCTION 23253 ; VA 0x00b0d6a0 ; FUN_00b0d6a0 */

void __thiscall FUN_00b0d6a0(int param_1,undefined4 param_2)

{
  char cStack_8;
  char cStack_7;
  
  cStack_8 = (char)*(undefined2 *)(param_1 + 200);
  if (((cStack_8 != (char)param_2) ||
      (cStack_7 = (char)((ushort)*(undefined2 *)(param_1 + 200) >> 8),
      cStack_7 != (char)((uint)param_2 >> 8))) || (*(char *)(param_1 + 0xca) != param_2._2_1_)) {
    *(undefined2 *)(param_1 + 200) = (undefined2)param_2;
    *(char *)(param_1 + 0xca) = param_2._2_1_;
    FUN_008a4940(&DAT_01eed3a8);
    FUN_008a4940(&DAT_01eed338);
    FUN_008a4940(&DAT_01eed370);
  }
  return;
}



/* FUNCTION 23254 ; VA 0x00b0d710 ; FUN_00b0d710 */

void FUN_00b0d710(void)

{
  undefined3 *puVar1;
  undefined extraout_var;
  undefined auStack_7 [3];
  
  puVar1 = (undefined3 *)FUN_00c98b10(auStack_7);
  FUN_00b0d6a0(CONCAT13(extraout_var,*puVar1));
  return;
}



/* FUNCTION 23255 ; VA 0x00b0d750 ; FUN_00b0d750 */

void FUN_00b0d750(int param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined auStack_34 [48];
  
  iVar2 = FUN_00c157b0();
  if (((((NAN(*(float *)(param_1 + 0x24)) || NAN(*(float *)(iVar2 + 0x24))) !=
         (*(float *)(param_1 + 0x24) == *(float *)(iVar2 + 0x24))) &&
       ((NAN(*(float *)(param_1 + 0x28)) || NAN(*(float *)(iVar2 + 0x28))) !=
        (*(float *)(param_1 + 0x28) == *(float *)(iVar2 + 0x28)))) &&
      ((NAN(*(float *)(param_1 + 0x2c)) || NAN(*(float *)(iVar2 + 0x2c))) !=
       (*(float *)(param_1 + 0x2c) == *(float *)(iVar2 + 0x2c)))) &&
     (cVar1 = FUN_01160ab0(iVar2), cVar1 != '\0')) {
    return;
  }
  FUN_00c14380();
  iVar2 = FUN_00b0c990(auStack_34,param_1);
  iVar3 = FUN_00c157b0();
  if ((((NAN(*(float *)(iVar2 + 0x24)) || NAN(*(float *)(iVar3 + 0x24))) ==
        (*(float *)(iVar2 + 0x24) == *(float *)(iVar3 + 0x24))) ||
      ((NAN(*(float *)(iVar2 + 0x28)) || NAN(*(float *)(iVar3 + 0x28))) ==
       (*(float *)(iVar2 + 0x28) == *(float *)(iVar3 + 0x28)))) ||
     (((NAN(*(float *)(iVar2 + 0x2c)) || NAN(*(float *)(iVar3 + 0x2c))) ==
       (*(float *)(iVar2 + 0x2c) == *(float *)(iVar3 + 0x2c)) ||
      (cVar1 = FUN_01160ab0(iVar3), cVar1 == '\0')))) {
    FUN_00c181c0(iVar2);
  }
  FUN_00b0a1b0();
  FUN_008a4940(&DAT_0212a430);
  FUN_008a4940(&DAT_0212a468);
  FUN_008a4940(&DAT_0212a660);
  FUN_008a4940(&DAT_0212a510);
  FUN_008a4940(&DAT_0212a4d8);
  iVar2 = FUN_008a40f0();
  if (iVar2 != 0) {
    FUN_008a4100();
    FUN_006eccd0();
  }
  return;
}



/* FUNCTION 23256 ; VA 0x00b0d880 ; FUN_00b0d880 */

void __thiscall FUN_00b0d880(int *param_1,undefined4 *param_2)

{
  int iVar1;
  code *pcVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined auStack_d8 [48];
  undefined auStack_a8 [48];
  undefined auStack_78 [48];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  int iStack_c;
  int iStack_8;
  
  iVar1 = param_1[0x2a];
  iStack_8 = iVar1;
  iVar4 = FUN_00c155c0();
  piVar5 = (int *)FUN_01255560();
  if ((*piVar5 - 1U < 6) && (iVar4 != 0)) {
    iVar4 = FUN_00ca1550();
    if (iVar4 != iVar1) {
      iStack_c = FUN_00ca1550();
      if (iStack_c == 0) {
        piVar5 = (int *)0x0;
      }
      else {
        piVar5 = (int *)(-(uint)(*(int *)(iStack_c + 0x1b0) != 0) &
                        *(int *)(iStack_c + 0x1b0) - 0x58U);
      }
      cVar3 = FUN_00c93d40(param_2);
      if (cVar3 != '\0') {
        uStack_18 = 0;
        uStack_14 = 0xff7fffff;
        uStack_10 = 0;
        pcVar2 = *(code **)(*piVar5 + 0x108);
        uVar6 = FUN_00709da0(&uStack_18);
        (*pcVar2)(uVar6);
        return;
      }
      uStack_48 = *param_2;
      uStack_44 = param_2[1];
      uStack_40 = param_2[2];
      uStack_3c = param_2[3];
      uStack_38 = param_2[4];
      uStack_34 = param_2[5];
      uStack_30 = param_2[6];
      uStack_2c = param_2[7];
      uStack_28 = param_2[8];
      uStack_24 = param_2[9];
      uStack_20 = param_2[10];
      uStack_1c = param_2[0xb];
      FUN_00c94b40(&uStack_48);
      pcVar2 = *(code **)(*piVar5 + 0x108);
      FUN_00c157b0();
      uVar6 = FUN_0071fcc0(auStack_78);
      FUN_0071f260(auStack_a8,uVar6);
      uVar6 = FUN_00c157b0();
      uVar6 = FUN_0071f260(auStack_d8,uVar6);
      (*pcVar2)(uVar6);
      return;
    }
  }
  (**(code **)(*param_1 + 0x108))(param_2);
  return;
}



/* FUNCTION 23257 ; VA 0x00b0d9c0 ; FUN_00b0d9c0 */

void FUN_00b0d9c0(int param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined auStack_34 [48];
  
  iVar2 = FUN_00c157b0();
  if (((((NAN(*(float *)(param_1 + 0x24)) || NAN(*(float *)(iVar2 + 0x24))) !=
         (*(float *)(param_1 + 0x24) == *(float *)(iVar2 + 0x24))) &&
       ((NAN(*(float *)(param_1 + 0x28)) || NAN(*(float *)(iVar2 + 0x28))) !=
        (*(float *)(param_1 + 0x28) == *(float *)(iVar2 + 0x28)))) &&
      ((NAN(*(float *)(param_1 + 0x2c)) || NAN(*(float *)(iVar2 + 0x2c))) !=
       (*(float *)(param_1 + 0x2c) == *(float *)(iVar2 + 0x2c)))) &&
     (cVar1 = FUN_01160ab0(iVar2), cVar1 != '\0')) {
    return;
  }
  FUN_00c14380();
  iVar2 = FUN_00b0c990(auStack_34,param_1);
  iVar3 = FUN_00c157b0();
  if ((((NAN(*(float *)(iVar2 + 0x24)) || NAN(*(float *)(iVar3 + 0x24))) ==
        (*(float *)(iVar2 + 0x24) == *(float *)(iVar3 + 0x24))) ||
      ((NAN(*(float *)(iVar2 + 0x28)) || NAN(*(float *)(iVar3 + 0x28))) ==
       (*(float *)(iVar2 + 0x28) == *(float *)(iVar3 + 0x28)))) ||
     (((NAN(*(float *)(iVar2 + 0x2c)) || NAN(*(float *)(iVar3 + 0x2c))) ==
       (*(float *)(iVar2 + 0x2c) == *(float *)(iVar3 + 0x2c)) ||
      (cVar1 = FUN_01160ab0(iVar3), cVar1 == '\0')))) {
    FUN_00c181c0(iVar2);
  }
  FUN_00b0a1b0();
  FUN_008a4940(&DAT_0212a430);
  iVar2 = FUN_008a40f0();
  if (iVar2 != 0) {
    FUN_008a4100();
    FUN_006eccd0();
  }
  return;
}



/* FUNCTION 23258 ; VA 0x00b0dac0 ; FUN_00b0dac0 */

void __thiscall FUN_00b0dac0(int param_1,undefined4 param_2)

{
  if ((char)param_2 != *(char *)(*(int *)(param_1 + 0xa8) + 0x222)) {
    FUN_00c18290(param_2);
    FUN_008a4940(&DAT_01eedac8);
  }
  return;
}



/* FUNCTION 23259 ; VA 0x00b0daf0 ; FUN_00b0daf0 */

void __thiscall FUN_00b0daf0(int param_1,float param_2)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  
  fVar2 = 0.0;
  if (0.0 <= param_2) {
    fVar2 = param_2;
  }
  fVar3 = DAT_018ce2f8;
  if (fVar2 <= DAT_018ce2f8) {
    fVar3 = fVar2;
  }
  pfVar1 = (float *)(*(int *)(param_1 + 0xa8) + 0x218);
  if ((NAN(fVar3) || NAN(*pfVar1)) == (fVar3 == *pfVar1)) {
    FUN_00c182b0(fVar3);
    FUN_008a4940(&DAT_01eed220);
  }
  return;
}



/* FUNCTION 23260 ; VA 0x00b0db40 ; FUN_00b0db40 */

void __thiscall FUN_00b0db40(int param_1,float param_2)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  
  fVar2 = 0.0;
  if (0.0 <= param_2) {
    fVar2 = param_2;
  }
  fVar3 = DAT_018daf58;
  if (fVar2 <= DAT_018daf58) {
    fVar3 = fVar2;
  }
  pfVar1 = (float *)(*(int *)(param_1 + 0xa8) + 0x214);
  if ((NAN(fVar3) || NAN(*pfVar1)) == (fVar3 == *pfVar1)) {
    FUN_00c183c0(fVar3);
    FUN_008a4940(&DAT_01eed258);
  }
  return;
}



/* FUNCTION 23261 ; VA 0x00b0db90 ; FUN_00b0db90 */

void __thiscall FUN_00b0db90(int param_1,char param_2)

{
  *(char *)(param_1 + 0xe7) = param_2;
  if ((param_2 == '\0') && (*(char *)(param_1 + 0xe6) == '\0')) {
    FUN_00c184f0();
    return;
  }
  FUN_00c184f0();
  return;
}



/* FUNCTION 23262 ; VA 0x00b0dbd0 ; FUN_00b0dbd0 */

void FUN_00b0dbd0(void)

{
  int iVar1;
  
  iVar1 = FUN_008a4100();
  *(undefined *)(iVar1 + 200) = 1;
  return;
}



/* FUNCTION 23263 ; VA 0x00b0dbe0 ; FUN_00b0dbe0 */

void __thiscall FUN_00b0dbe0(int param_1,float *param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  undefined8 uStack_1c;
  float fStack_14;
  undefined8 uStack_10;
  undefined4 uStack_8;
  
  iVar3 = *(int *)(param_1 + 0xa8);
  iVar1 = FUN_00c155c0();
  piVar2 = (int *)FUN_01255560();
  if ((*piVar2 - 1U < 6) && (iVar1 != 0)) {
    iVar3 = FUN_00ca1550();
  }
  uVar4 = -(uint)(iVar3 != 0) & iVar3 + 0x50U;
  FUN_00fa07b0();
  uStack_10 = *(undefined8 *)(uVar4 + 0xf0);
  uStack_1c._0_4_ = (float)*(undefined8 *)(uVar4 + 0xe4);
  uStack_8 = *(undefined4 *)(uVar4 + 0xf8);
  if ((((NAN((float)uStack_1c) || NAN(*param_2)) == ((float)uStack_1c == *param_2)) ||
      (uStack_1c._4_4_ = (float)((ulonglong)*(undefined8 *)(uVar4 + 0xe4) >> 0x20),
      (NAN(uStack_1c._4_4_) || NAN(param_2[1])) == (uStack_1c._4_4_ == param_2[1]))) ||
     ((NAN(*(float *)(uVar4 + 0xec)) || NAN(param_2[2])) == (*(float *)(uVar4 + 0xec) == param_2[2])
     )) {
    fStack_14 = param_2[2];
    uStack_1c = *(undefined8 *)param_2;
    FUN_00c19180(&uStack_1c);
    FUN_00b0a1b0();
    FUN_008a4940(&DAT_0212a580);
  }
  return;
}



/* FUNCTION 23264 ; VA 0x00b0dcd0 ; FUN_00b0dcd0 */

void __thiscall FUN_00b0dcd0(int param_1,float param_2)

{
  if ((NAN(param_2) || NAN(*(float *)(param_1 + 0xd4))) == (param_2 == *(float *)(param_1 + 0xd4)))
  {
    *(float *)(param_1 + 0xd4) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 23265 ; VA 0x00b0dd00 ; FUN_00b0dd00 */

void __thiscall FUN_00b0dd00(int param_1,char param_2)

{
  undefined uVar1;
  
  if (param_2 != *(char *)(param_1 + 0xe6)) {
    *(char *)(param_1 + 0xe6) = param_2;
    if ((param_2 != '\0') || (uVar1 = 0, *(char *)(param_1 + 0xe7) != '\0')) {
      uVar1 = 1;
    }
    FUN_00c184f0(uVar1);
    FUN_008a4940(&DAT_01eed5e8);
  }
  return;
}



/* FUNCTION 23266 ; VA 0x00b0dd50 ; FUN_00b0dd50 */

void __thiscall FUN_00b0dd50(undefined4 param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  
  FUN_008a6520(param_2);
  if (DAT_01ee41fb != '\0') {
    FUN_016774b0(DAT_01ee41fb,"PartInstance %p named",param_1);
    if (DAT_01ee41fb != '\0') {
      FUN_01677760(DAT_01ee41fb,"Name: %s",param_2);
    }
  }
  uVar1 = param_2[4];
  puVar3 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar3 = (undefined4 *)*param_2;
  }
  cVar2 = FUN_0055c360(puVar3,uVar1,"HumanoidRootPart",0x10);
  if (cVar2 != '\0') {
    FUN_00c18fe0(2);
    return;
  }
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  cVar2 = FUN_0055c360(param_2,uVar1,"Torso",5);
  FUN_00c18fe0(cVar2 != '\0');
  return;
}



/* FUNCTION 23267 ; VA 0x00b0de10 ; FUN_00b0de10 */

void FUN_00b0de10(undefined4 param_1)

{
  undefined4 *puVar1;
  undefined8 uStack_c;
  
  if ((char)param_1 != '\0') {
    puVar1 = (undefined4 *)FUN_016830f0(&uStack_c);
    FUN_00c185b0(param_1,*puVar1,puVar1[1]);
    return;
  }
  uStack_c = 0;
  FUN_00c185b0(param_1,0,0);
  return;
}



/* FUNCTION 23268 ; VA 0x00b0de70 ; FUN_00b0de70 */

void __thiscall FUN_00b0de70(int param_1,undefined4 param_2)

{
  char cVar1;
  undefined uVar2;
  undefined4 uVar3;
  undefined auStack_14 [4];
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined auStack_8 [4];
  
  uStack_c = *(undefined4 *)(*(int *)(param_1 + 0xa8) + 0x1dc);
  cVar1 = FUN_005e0cd0(&uStack_c);
  if (cVar1 != '\0') {
    FUN_0097bfe0(auStack_8,param_1);
    cVar1 = FUN_00a33d60(auStack_8);
    if (cVar1 != '\0') {
      FUN_00c17230(0);
    }
    uVar2 = FUN_00b03450(&param_2,auStack_8);
    *(undefined *)(param_1 + 0xe4) = uVar2;
    cVar1 = FUN_00b09400(auStack_8);
    if (cVar1 != '\0') {
      cVar1 = FUN_00a33d60(auStack_8);
      if (cVar1 != '\0') {
        uVar3 = FUN_016830f0(auStack_14);
        FUN_00c3e680(uVar3);
      }
    }
    uStack_10 = 1;
    cVar1 = FUN_005e0cd0(&uStack_10);
    if (cVar1 != '\0') {
      *(undefined4 *)(param_1 + 0xec) = uStack_c;
    }
    *(undefined4 *)(*(int *)(param_1 + 0xa8) + 0x1dc) = param_2;
  }
  return;
}



/* FUNCTION 23269 ; VA 0x00b0df50 ; FUN_00b0df50 */

void __thiscall FUN_00b0df50(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uVar1 = *(undefined4 *)(*(int *)(param_1 + 0xa8) + 0x1dc);
  FUN_00b0de70(param_2);
  uStack_8 = *(undefined4 *)(*(int *)(param_1 + 0xa8) + 0x1dc);
  uStack_c = uVar1;
  cVar2 = FUN_005e0cd0(&uStack_8);
  if (cVar2 != '\0') {
    cVar2 = FUN_00971ce0(param_1,1);
    if (cVar2 == '\0') {
      puStack_14 = (undefined4 *)0x0;
    }
    else {
      uStack_10 = 2;
      cVar2 = FUN_00a33d60(&uStack_10);
      if (cVar2 != '\0') {
        FUN_008a4940(&DAT_01eed858);
        return;
      }
      cVar2 = FUN_00b09720(&uStack_c);
      if (cVar2 == '\0') {
        puStack_14 = &uStack_c;
        uStack_10 = 0;
        FUN_00b0c2f0(param_1,3,&puStack_14);
      }
      cVar2 = FUN_00b09720(&uStack_8);
      if (cVar2 != '\0') {
        return;
      }
      puStack_14 = &uStack_8;
    }
    uStack_10 = 0;
    FUN_00b0c2f0(param_1,uStack_8,&puStack_14);
  }
  return;
}



/* FUNCTION 23270 ; VA 0x00b0e040 ; FUN_00b0e040 */

void __thiscall FUN_00b0e040(undefined4 param_1,undefined4 param_2,char param_3)

{
  int iVar1;
  
  iVar1 = FUN_008f7870(param_1);
  if ((iVar1 != 0) && ((*(int *)(iVar1 + 0x4a0) == 2 || (*(int *)(iVar1 + 0x4a0) == 3)))) {
    if (param_3 != '\0') {
      FUN_00b0e550(1);
    }
    FUN_00b0df50(param_2);
  }
  return;
}



/* FUNCTION 23271 ; VA 0x00b0e090 ; FUN_00b0e090 */

int FUN_00b0e090(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 uVar8;
  undefined auStack_94 [24];
  undefined auStack_7c [16];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  code *pcStack_64;
  undefined1 *puStack_60;
  char *pcStack_5c;
  undefined4 *puStack_58;
  undefined4 uStack_54;
  int *piStack_50;
  undefined4 uStack_4c;
  int *piStack_48;
  undefined auStack_44 [4];
  int iStack_40;
  int *piStack_3c;
  int *piStack_38;
  int iStack_34;
  uint uStack_30;
  undefined1 *puStack_2c;
  char *pcStack_28;
  undefined4 *puStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017edc5e;
  pvStack_10 = ExceptionList;
  piStack_38 = (int *)0x0;
  uStack_6c = 0;
  uStack_68 = 0xf;
  auStack_7c[0] = 0;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  cVar3 = FUN_00b02d50(&iStack_14,auStack_7c);
  if (cVar3 == '\0') {
    uVar8 = FUN_005543f0();
    FUN_00550130(uVar8);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_44,&DAT_01c17198);
  }
  if ((param_1 == 0) ||
     (iVar5 = *(int *)(param_1 + 0xc), iVar4 = FUN_00913630(),
     (uint)*(ushort *)(iVar4 + 0x1da) <
     (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) {
    piStack_48 = (int *)0x0;
    puVar6 = &uStack_4c;
    iStack_34 = 0;
    uVar7 = 6;
  }
  else {
    iStack_34 = param_1;
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    piStack_1c = param_2;
    puVar6 = &uStack_20;
    uVar7 = 5;
  }
  iStack_40 = iStack_34;
  piStack_3c = (int *)puVar6[1];
  piStack_38 = piStack_3c;
  *puVar6 = 0;
  puVar6[1] = 0;
  piVar2 = piStack_48;
  if (((uVar7 & 2) != 0) &&
     (uStack_30 = uVar7 & 0xfffffffd, uVar7 = uStack_30, piStack_48 != (int *)0x0)) {
    LOCK();
    iVar5 = piStack_48[1] + -1;
    piStack_48[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_48)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      uVar7 = uStack_30;
      if (iVar5 == 0) {
        (**(code **)(*piVar2 + 4))();
        uVar7 = uStack_30;
      }
    }
  }
  piVar2 = piStack_1c;
  if (((uVar7 & 1) != 0) && (piStack_1c != (int *)0x0)) {
    LOCK();
    iVar5 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar5 = iStack_34;
  uStack_8._0_1_ = 2;
  if ((iStack_34 == 0) && (param_1 != 0)) {
    FUN_00550130("SetNetworkOwner only takes player or \'nil\' instance as an argument.");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(&puStack_24,&DAT_01c17198);
  }
  if (iStack_14 == 0) {
    uVar7 = 0;
  }
  else {
    uVar7 = -(uint)(*(int *)(iStack_14 + 0x1b0) != 0) & *(int *)(iStack_14 + 0x1b0) - 0x58U;
  }
  cVar3 = FUN_00971ce0(uStack_18,0);
  if ((cVar3 != '\0') && (cVar3 = FUN_0097c970(uStack_18,0), cVar3 != '\0')) {
    FUN_00550b30();
    FUN_005507b0();
    iVar5 = FUN_00550b30();
    ExceptionList = pvStack_10;
    return iVar5;
  }
  iStack_14 = FUN_008f7870(uStack_18);
  if (iStack_14 == 0) {
    if (iVar5 != 0) goto LAB_00b0e3f5;
  }
  else {
    piVar2 = *(int **)(iStack_14 + 0x43c);
    puStack_58 = (undefined4 *)
                 FUN_0058c590(auStack_94,*piVar2 - (int)piVar2,piVar2[1] - (int)piVar2);
    uStack_8._0_1_ = 3;
    if (0xf < (uint)puStack_58[5]) {
      puStack_58 = (undefined4 *)*puStack_58;
    }
    piStack_1c = (int *)((uint)piStack_1c & 0xffffff00);
    piStack_50 = piStack_1c;
    puStack_2c = &DAT_018c5f98;
    pcStack_28 = "PartInstance_SetNetworkOwnerScript";
    uStack_20 = 0;
    pcStack_64 = FUN_0087c450;
    puStack_60 = &DAT_018c5f98;
    pcStack_5c = "PartInstance_SetNetworkOwnerScript";
    uStack_54 = 0;
    puStack_24 = puStack_58;
    FUN_008ab7d0(&DAT_01eedc84,&pcStack_64);
    uStack_8._0_1_ = 2;
    FUN_005507b0();
    if (iVar5 != 0) {
LAB_00b0e3f5:
      puVar6 = (undefined4 *)FUN_00927d30(&iStack_14);
      uVar8 = *puVar6;
      goto LAB_00b0e364;
    }
    piVar2 = *(int **)(iStack_14 + 0x43c);
    puStack_58 = (undefined4 *)
                 FUN_0058c590(auStack_94,*piVar2 - (int)piVar2,piVar2[1] - (int)piVar2);
    uStack_8._0_1_ = 4;
    if (0xf < (uint)puStack_58[5]) {
      puStack_58 = (undefined4 *)*puStack_58;
    }
    piStack_1c = (int *)((uint)piStack_1c & 0xffffff00);
    piStack_50 = piStack_1c;
    puStack_2c = &DAT_018c5f98;
    pcStack_28 = "PartInstance_SetNetworkOwnerScript_TOSERVER";
    uStack_20 = 0;
    pcStack_64 = FUN_0087c450;
    puStack_60 = &DAT_018c5f98;
    pcStack_5c = "PartInstance_SetNetworkOwnerScript_TOSERVER";
    uStack_54 = 0;
    puStack_24 = puStack_58;
    FUN_008ab7d0(&DAT_01eedc84,&pcStack_64);
    uStack_8._0_1_ = 2;
    FUN_005507b0();
  }
  uVar8 = 1;
LAB_00b0e364:
  if (uVar7 != 0) {
    FUN_00b0e550(1);
    FUN_00b0df50(uVar8);
  }
  piVar2 = piStack_38;
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_38[1] + -1;
    piStack_38[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_38)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar5 = FUN_005507b0();
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar2 = param_2 + 1;
    iVar4 = *piVar2;
    iVar5 = *piVar2;
    *piVar2 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar5 = (**(code **)*param_2)();
      LOCK();
      piVar2 = param_2 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar5 = (**(code **)(*param_2 + 4))();
        ExceptionList = pvStack_10;
        return iVar5;
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 23272 ; VA 0x00b0e450 ; FUN_00b0e450 */

void FUN_00b0e450(void)

{
  char cVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [12];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01799148;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00b02d50(&iStack_14,auStack_38);
  if (cVar1 == '\0') {
    uVar2 = FUN_005543f0();
    FUN_00550130(uVar2);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_20,&DAT_01c17198);
  }
  if (iStack_14 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = -(uint)(*(int *)(iStack_14 + 0x1b0) != 0) & *(int *)(iStack_14 + 0x1b0) - 0x58U;
  }
  if (*(char *)(*(int *)(uVar4 + 0xa8) + 0x22c) != '\0') {
    *(undefined *)(*(int *)(uVar4 + 0xa8) + 0x22c) = 0;
    cVar1 = FUN_0098c5a0(uVar4,0);
    if (cVar1 != '\0') {
      FUN_008a4940(&DAT_01eed490);
    }
  }
  if (0xf < uStack_24) {
    uVar3 = uStack_24 + 1;
    uVar4 = auStack_38[0];
    if (0xfff < uVar3) {
      uVar4 = *(uint *)(auStack_38[0] - 4);
      uVar3 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23273 ; VA 0x00b0e550 ; FUN_00b0e550 */

void __thiscall FUN_00b0e550(int param_1,uint param_2)

{
  char cVar1;
  
  if (*(byte *)(*(int *)(param_1 + 0xa8) + 0x22c) != param_2) {
    *(char *)(*(int *)(param_1 + 0xa8) + 0x22c) = (char)param_2;
    cVar1 = FUN_0098c5a0(param_1,0);
    if (cVar1 != '\0') {
      FUN_008a4940(&DAT_01eed490);
    }
  }
  return;
}



/* FUNCTION 23274 ; VA 0x00b0e590 ; FUN_00b0e590 */

void __thiscall FUN_00b0e590(int *param_1,float *param_2)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  iVar2 = FUN_00a9d0e0(param_1);
  if (iVar2 != 0) {
    FUN_00a9e6d0(1);
  }
  puVar3 = (undefined4 *)FUN_00c157b0();
  uStack_58 = *puVar3;
  uStack_54 = puVar3[1];
  uStack_50 = puVar3[2];
  uStack_4c = puVar3[3];
  uStack_48 = puVar3[4];
  uStack_44 = puVar3[5];
  uStack_40 = puVar3[6];
  uStack_3c = puVar3[7];
  uStack_38 = puVar3[8];
  uStack_34 = puVar3[9];
  uStack_30 = puVar3[10];
  uStack_2c = puVar3[0xb];
  FUN_01161740(&uStack_28,param_2[1] * DAT_0190119c,*param_2 * DAT_0190119c,
               param_2[2] * DAT_0190119c);
  cVar1 = FUN_01160b00(&uStack_58);
  if (cVar1 != '\0') {
    uStack_38 = uStack_8;
    uStack_58 = uStack_28;
    uStack_54 = uStack_24;
    uStack_50 = uStack_20;
    uStack_4c = uStack_1c;
    uStack_48 = uStack_18;
    uStack_44 = uStack_14;
    uStack_40 = uStack_10;
    uStack_3c = uStack_c;
    (**(code **)(*param_1 + 0x138))(&uStack_58);
    (**(code **)(*param_1 + 0x108))(&uStack_58);
    (**(code **)(*param_1 + 0x130))(2);
  }
  return;
}



/* FUNCTION 23275 ; VA 0x00b0e670 ; FUN_00b0e670 */

void __thiscall FUN_00b0e670(int param_1,int param_2,float param_3)

{
  int iVar1;
  undefined8 *puVar2;
  undefined4 uVar3;
  undefined4 uStack_10;
  float fStack_c;
  undefined4 uStack_8;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0xa8) + 0x238);
  if (iVar1 == 0) {
    puVar2 = (undefined8 *)FUN_00b05090();
  }
  else {
    puVar2 = (undefined8 *)(iVar1 + param_2 * 0xc);
  }
  fStack_c = (float)((ulonglong)*puVar2 >> 0x20);
  uStack_8 = *(undefined4 *)(puVar2 + 1);
  if ((NAN(fStack_c) || NAN(param_3)) == (fStack_c == param_3)) {
    _uStack_10 = CONCAT44(param_3,(int)*puVar2);
    FUN_00c19020(param_2,&uStack_10);
    FUN_0115b050();
    uVar3 = FUN_00dae7c0(param_2);
    FUN_008a4940(uVar3);
  }
  return;
}



/* FUNCTION 23276 ; VA 0x00b0e700 ; FUN_00b0e700 */

void __thiscall FUN_00b0e700(int param_1,int param_2,float param_3)

{
  int iVar1;
  undefined8 *puVar2;
  undefined4 uVar3;
  undefined8 uStack_10;
  float fStack_8;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0xa8) + 0x238);
  if (iVar1 == 0) {
    puVar2 = (undefined8 *)FUN_00b05090();
  }
  else {
    puVar2 = (undefined8 *)(iVar1 + param_2 * 0xc);
  }
  uStack_10 = *puVar2;
  if ((NAN(*(float *)(puVar2 + 1)) || NAN(param_3)) == (*(float *)(puVar2 + 1) == param_3)) {
    fStack_8 = param_3;
    FUN_00c19020(param_2,&uStack_10);
    FUN_0115b050();
    uVar3 = FUN_00dae820(param_2);
    FUN_008a4940(uVar3);
  }
  return;
}



/* FUNCTION 23277 ; VA 0x00b0e790 ; FUN_00b0e790 */

void __thiscall FUN_00b0e790(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0xe5)) {
    *(char *)(param_1 + 0xe5) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 23278 ; VA 0x00b0e7c0 ; FUN_00b0e7c0 */

void __thiscall FUN_00b0e7c0(int *param_1,float *param_2)

{
  int iVar1;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  iVar1 = FUN_00a9d0e0(param_1);
  if (iVar1 != 0) {
    FUN_00a9e6d0(1);
  }
  (**(code **)(*param_1 + 0xe4))(&fStack_10,param_2);
  iVar1 = *(int *)(param_1[0x2a] + 0x1ac);
  if ((((NAN(fStack_10) || NAN(*(float *)(iVar1 + 4))) == (fStack_10 == *(float *)(iVar1 + 4))) ||
      ((NAN(fStack_c) || NAN(*(float *)(iVar1 + 8))) == (fStack_c == *(float *)(iVar1 + 8)))) ||
     ((NAN(fStack_8) || NAN(*(float *)(iVar1 + 0xc))) == (fStack_8 == *(float *)(iVar1 + 0xc)))) {
    (**(code **)(*param_1 + 0xe8))(&fStack_10);
  }
  else if ((((NAN(fStack_10) || NAN(*param_2)) == (fStack_10 == *param_2)) ||
           ((NAN(fStack_c) || NAN(param_2[1])) == (fStack_c == param_2[1]))) ||
          ((NAN(fStack_8) || NAN(param_2[2])) == (fStack_8 == param_2[2]))) {
    FUN_008a4940(&DAT_01eed1e8);
    (**(code **)(*param_1 + 0x130))(2);
    return;
  }
  (**(code **)(*param_1 + 0x130))(2);
  return;
}



/* FUNCTION 23279 ; VA 0x00b0e890 ; FUN_00b0e890 */

void __thiscall FUN_00b0e890(int *param_1,float *param_2)

{
  float fVar1;
  int iVar2;
  char cVar3;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  cVar3 = (**(code **)(*param_1 + 0xb0))();
  if (cVar3 == '\0') {
    fVar1 = *param_2;
    iVar2 = *(int *)(param_1[0x2a] + 0x1ac);
    if ((((NAN(fVar1) || NAN(*(float *)(iVar2 + 4))) == (fVar1 == *(float *)(iVar2 + 4))) ||
        ((NAN(fVar1) || NAN(*(float *)(iVar2 + 8))) == (fVar1 == *(float *)(iVar2 + 8)))) ||
       ((NAN(fVar1) || NAN(*(float *)(iVar2 + 0xc))) == (fVar1 == *(float *)(iVar2 + 0xc)))) {
      param_2 = &fStack_10;
      fStack_10 = fVar1;
      fStack_c = fVar1;
      fStack_8 = fVar1;
      goto LAB_00b0e927;
    }
  }
  iVar2 = *(int *)(param_1[0x2a] + 0x1ac);
  if ((((NAN(*param_2) || NAN(*(float *)(iVar2 + 4))) != (*param_2 == *(float *)(iVar2 + 4))) &&
      ((NAN(param_2[1]) || NAN(*(float *)(iVar2 + 8))) != (param_2[1] == *(float *)(iVar2 + 8)))) &&
     ((NAN(param_2[2]) || NAN(*(float *)(iVar2 + 0xc))) != (param_2[2] == *(float *)(iVar2 + 0xc))))
  {
    return;
  }
LAB_00b0e927:
  FUN_00c18e20(param_2);
  FUN_008a4940(&DAT_01eed1b0);
  FUN_008a4940(&DAT_01eed1e8);
  return;
}



/* FUNCTION 23280 ; VA 0x00b0e950 ; FUN_00b0e950 */

void __thiscall FUN_00b0e950(int param_1,char *param_2)

{
  char *pcVar1;
  
  pcVar1 = *(char **)(*(int *)(param_1 + 0xa8) + 0x21c);
  if ((((*param_2 != *pcVar1) ||
       ((NAN(*(float *)(param_2 + 4)) || NAN(*(float *)(pcVar1 + 4))) ==
        (*(float *)(param_2 + 4) == *(float *)(pcVar1 + 4)))) ||
      ((NAN(*(float *)(param_2 + 0xc)) || NAN(*(float *)(pcVar1 + 0xc))) ==
       (*(float *)(param_2 + 0xc) == *(float *)(pcVar1 + 0xc)))) ||
     ((((NAN(*(float *)(param_2 + 8)) || NAN(*(float *)(pcVar1 + 8))) ==
        (*(float *)(param_2 + 8) == *(float *)(pcVar1 + 8)) ||
       ((NAN(*(float *)(param_2 + 0x10)) || NAN(*(float *)(pcVar1 + 0x10))) ==
        (*(float *)(param_2 + 0x10) == *(float *)(pcVar1 + 0x10)))) ||
      ((NAN(*(float *)(param_2 + 0x14)) || NAN(*(float *)(pcVar1 + 0x14))) ==
       (*(float *)(param_2 + 0x14) == *(float *)(pcVar1 + 0x14)))))) {
    FUN_00c18c80(param_2);
    FUN_008a4940(&DAT_01eed290);
  }
  return;
}



/* FUNCTION 23281 ; VA 0x00b0e9d0 ; FUN_00b0e9d0 */

void FUN_00b0e9d0(int param_1)

{
  char cVar1;
  int iVar2;
  
  iVar2 = FUN_00c157b0();
  if (((((NAN(*(float *)(param_1 + 0x24)) || NAN(*(float *)(iVar2 + 0x24))) !=
         (*(float *)(param_1 + 0x24) == *(float *)(iVar2 + 0x24))) &&
       ((NAN(*(float *)(param_1 + 0x28)) || NAN(*(float *)(iVar2 + 0x28))) !=
        (*(float *)(param_1 + 0x28) == *(float *)(iVar2 + 0x28)))) &&
      ((NAN(*(float *)(param_1 + 0x2c)) || NAN(*(float *)(iVar2 + 0x2c))) !=
       (*(float *)(param_1 + 0x2c) == *(float *)(iVar2 + 0x2c)))) &&
     (cVar1 = FUN_01160ab0(iVar2), cVar1 != '\0')) {
    return;
  }
  FUN_00c181c0(param_1);
  return;
}



/* FUNCTION 23282 ; VA 0x00b0ea40 ; FUN_00b0ea40 */

void __thiscall FUN_00b0ea40(int param_1,float param_2)

{
  if ((NAN(param_2) || NAN(*(float *)(param_1 + 0xd0))) == (param_2 == *(float *)(param_1 + 0xd0)))
  {
    *(float *)(param_1 + 0xd0) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 23283 ; VA 0x00b0ea70 ; FUN_00b0ea70 */

void __thiscall FUN_00b0ea70(int param_1,uint param_2)

{
  if (param_2 != *(ushort *)(*(int *)(param_1 + 0xa8) + 0x220)) {
    FUN_00c18c30(param_2);
    FUN_008a4940(&DAT_01eed418);
  }
  return;
}



/* FUNCTION 23284 ; VA 0x00b0eab0 ; FUN_00b0eab0 */

int __thiscall FUN_00b0eab0(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abb78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (param_2 != iStack_18) {
    if (iStack_18 != 0) {
      iVar2 = FUN_00c15700();
      if (iVar2 != 0) {
        iVar2 = FUN_00c155c0();
        if (iVar2 != 0) {
          *(int *)(iVar2 + 0x4c) = *(int *)(iVar2 + 0x4c) + -1;
        }
      }
    }
    if (param_2 != 0) {
      iVar2 = FUN_00c15700();
      if (iVar2 == 0) {
        param_2 = 0;
      }
      else {
        iVar2 = FUN_00c155c0();
        if (iVar2 != 0) {
          *(int *)(iVar2 + 0x4c) = *(int *)(iVar2 + 0x4c) + 1;
        }
      }
    }
    piVar3 = (int *)FUN_0060dcd0(auStack_20,param_2);
    iVar4 = piVar3[1];
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 8) = *(int *)(iVar4 + 8) + 1;
      UNLOCK();
      iVar4 = piVar3[1];
    }
    iVar2 = *piVar3;
    *(int *)(param_1 + 0xc0) = iVar2;
    piVar3 = *(int **)(param_1 + 0xc4);
    *(int *)(param_1 + 0xc4) = iVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      iVar2 = *piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        iVar2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar3 = piStack_1c + 1;
      iVar4 = *piVar3;
      iVar2 = *piVar3;
      *piVar3 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar3 = piStack_1c + 2;
        iVar4 = *piVar3;
        iVar2 = *piVar3;
        *piVar3 = iVar4 + -1;
        UNLOCK();
        if (iVar4 + -1 == 0) {
          iVar2 = (**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar3 = piStack_14 + 1;
    iVar4 = *piVar3;
    iVar2 = *piVar3;
    *piVar3 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar2 = (**(code **)*piStack_14)();
      LOCK();
      piVar3 = piStack_14 + 2;
      iVar4 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar2 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 23285 ; VA 0x00b0ebe0 ; FUN_00b0ebe0 */

void __thiscall FUN_00b0ebe0(int param_1,int param_2)

{
  if (param_2 < 0x80) {
    if (param_2 < -0x7f) {
      param_2 = -0x7f;
    }
  }
  else {
    param_2 = 0x7f;
  }
  if (param_2 != *(char *)(*(int *)(param_1 + 0xa8) + 0x22b)) {
    *(char *)(*(int *)(param_1 + 0xa8) + 0x22b) = (char)param_2;
    if (*(int *)(*(int *)(param_1 + 0xa8) + 0x1a8) != 0) {
      FUN_00bbf790(*(int *)(param_1 + 0xa8));
    }
    FUN_008a4940(&DAT_01eed2c8);
  }
  return;
}



/* FUNCTION 23286 ; VA 0x00b0ec40 ; FUN_00b0ec40 */

void __thiscall FUN_00b0ec40(int param_1,float *param_2)

{
  uint uVar1;
  undefined8 uStack_1c;
  undefined4 uStack_14;
  undefined8 uStack_10;
  float fStack_8;
  
  uVar1 = -(uint)(*(int *)(param_1 + 0xa8) != 0) & *(int *)(param_1 + 0xa8) + 0x50U;
  FUN_00fa07b0();
  uStack_1c = *(undefined8 *)(uVar1 + 0xe4);
  uStack_14 = *(undefined4 *)(uVar1 + 0xec);
  uStack_10._0_4_ = (float)*(undefined8 *)(uVar1 + 0xf0);
  if ((((NAN((float)uStack_10) || NAN(*param_2)) == ((float)uStack_10 == *param_2)) ||
      (uStack_10._4_4_ = (float)((ulonglong)*(undefined8 *)(uVar1 + 0xf0) >> 0x20),
      (NAN(uStack_10._4_4_) || NAN(param_2[1])) == (uStack_10._4_4_ == param_2[1]))) ||
     ((NAN(*(float *)(uVar1 + 0xf8)) || NAN(param_2[2])) == (*(float *)(uVar1 + 0xf8) == param_2[2])
     )) {
    fStack_8 = param_2[2];
    uStack_10 = *(undefined8 *)param_2;
    FUN_00c19180(&uStack_1c);
    FUN_00b0a1b0();
    FUN_008a4940(&DAT_0212a5b8);
  }
  return;
}



/* FUNCTION 23287 ; VA 0x00b0ed00 ; FUN_00b0ed00 */

void __thiscall FUN_00b0ed00(int *param_1,undefined4 param_2)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_00c155c0();
  piVar2 = (int *)FUN_01255560();
  if ((*piVar2 - 1U < 6) && (iVar1 != 0)) {
    iVar1 = FUN_00ca1550();
    if (iVar1 != 0) {
      (**(code **)(*(int *)(-(uint)(*(int *)(iVar1 + 0x1b0) != 0) & *(int *)(iVar1 + 0x1b0) - 0x58U)
                  + 0x110))(param_2);
      return;
    }
    param_1 = (int *)0x0;
  }
  (**(code **)(*param_1 + 0x110))(param_2);
  return;
}



/* FUNCTION 23288 ; VA 0x00b0ed70 ; FUN_00b0ed70 */

undefined4 * __thiscall FUN_00b0ed70(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar6 = (undefined4 *)FUN_0060e0c0(auStack_c,param_2);
  uVar3 = *puVar6;
  uVar4 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  *(undefined4 *)(param_1 + 0xd8) = uVar3;
  piVar5 = *(int **)(param_1 + 0xdc);
  *(undefined4 *)(param_1 + 0xdc) = uVar4;
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar1 = piVar5 + 2;
    iVar2 = *piVar1;
    puVar6 = (undefined4 *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puVar6 = (undefined4 *)(**(code **)(*piVar5 + 4))();
    }
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    piVar5 = piStack_8 + 2;
    iVar2 = *piVar5;
    *piVar5 = *piVar5 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puVar6 = (undefined4 *)(**(code **)(*piStack_8 + 4))();
    }
  }
  return puVar6;
}



/* FUNCTION 23289 ; VA 0x00b0ede0 ; FUN_00b0ede0 */

void __thiscall FUN_00b0ede0(int param_1,int param_2,int param_3)

{
  int iVar1;
  undefined8 *puVar2;
  undefined4 uVar3;
  int iStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0xa8) + 0x238);
  if (iVar1 == 0) {
    puVar2 = (undefined8 *)FUN_00b05090();
  }
  else {
    puVar2 = (undefined8 *)(iVar1 + param_2 * 0xc);
  }
  uStack_8 = *(undefined4 *)(puVar2 + 1);
  iStack_10 = (int)*puVar2;
  if (param_3 != iStack_10) {
    _iStack_10 = CONCAT44((int)((ulonglong)*puVar2 >> 0x20),param_3);
    FUN_00c19020(param_2,&iStack_10);
    FUN_0115b050();
    uVar3 = FUN_00dae880(param_2);
    FUN_008a4940(uVar3);
  }
  return;
}



/* FUNCTION 23290 ; VA 0x00b0ee60 ; FUN_00b0ee60 */

void __thiscall FUN_00b0ee60(int *param_1,int param_2,uint param_3)

{
  undefined4 uVar1;
  
  if (param_3 != *(byte *)(param_1[0x2a] + 0x22f + param_2)) {
    FUN_00c19160(param_2,param_3);
    (**(code **)(*param_1 + 0x130))(2);
    FUN_0115b050();
    uVar1 = FUN_00dae8e0(param_2);
    FUN_008a4940(uVar1);
    if (DAT_01d66c14 != '\0') {
      uVar1 = FUN_00dae880(param_2);
      FUN_008a4940(uVar1);
    }
  }
  return;
}



/* FUNCTION 23291 ; VA 0x00b0eed0 ; FUN_00b0eed0 */

void __thiscall FUN_00b0eed0(int *param_1,float *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined8 uStack_10;
  float fStack_8;
  
  iVar1 = FUN_00a9d0e0(param_1);
  if (iVar1 != 0) {
    FUN_00a9e6d0(1);
  }
  puVar2 = (undefined4 *)FUN_00c157b0();
  uStack_34 = *puVar2;
  uStack_30 = puVar2[1];
  uStack_2c = puVar2[2];
  uStack_28 = puVar2[3];
  uStack_24 = puVar2[4];
  uStack_20 = puVar2[5];
  uStack_1c = puVar2[6];
  uStack_18 = puVar2[7];
  uStack_14 = puVar2[8];
  if ((((NAN((float)puVar2[9]) || NAN(*param_2)) == ((float)puVar2[9] == *param_2)) ||
      ((NAN((float)puVar2[10]) || NAN(param_2[1])) == ((float)puVar2[10] == param_2[1]))) ||
     ((NAN((float)puVar2[0xb]) || NAN(param_2[2])) == ((float)puVar2[0xb] == param_2[2]))) {
    fStack_8 = param_2[2];
    uStack_10 = *(undefined8 *)param_2;
    (**(code **)(*param_1 + 0x138))(&uStack_34);
    (**(code **)(*param_1 + 0x108))(&uStack_34);
    (**(code **)(*param_1 + 0x130))(2);
  }
  return;
}



/* FUNCTION 23292 ; VA 0x00b0ef80 ; FUN_00b0ef80 */

void __thiscall FUN_00b0ef80(int param_1,float param_2)

{
  if ((NAN(param_2) || NAN(*(float *)(param_1 + 0xcc))) == (param_2 == *(float *)(param_1 + 0xcc)))
  {
    *(float *)(param_1 + 0xcc) = param_2;
    FUN_008a4940(&DAT_01eed458);
    FUN_0115b050();
  }
  return;
}



/* FUNCTION 23293 ; VA 0x00b0efc0 ; FUN_00b0efc0 */

void __thiscall FUN_00b0efc0(int param_1,undefined4 param_2,undefined3 *param_3)

{
  (**(code **)(param_1 + 0x18))(*param_3);
  return;
}



/* FUNCTION 23294 ; VA 0x00b0f000 ; FUN_00b0f000 */

void __thiscall FUN_00b0f000(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined2 *puVar5;
  int *piVar6;
  undefined auStack_dc [200];
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179904b;
  pvStack_10 = ExceptionList;
  iVar1 = *param_3;
  pcStack_14 = *(code **)(**(int **)(param_1 + 0x34) + 0x10);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088d0f0();
  if (iVar1 == iVar3) {
    iVar1 = *piVar2;
    iVar3 = FUN_0088d0f0();
    if (iVar1 != iVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar6 = piVar2 + 2;
    if (piVar2[1] == 0) {
      piVar6 = (int *)0x0;
    }
    param_3._0_3_ = CONCAT21(*(undefined2 *)piVar6,param_3._0_1_);
    param_3 = (int *)CONCAT13(*(undefined *)((int)piVar6 + 2),param_3._0_3_);
  }
  else {
    puVar4 = (undefined4 *)piVar2[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(piVar2 + 2,auStack_dc);
      puVar4 = (undefined4 *)piVar2[1];
    }
    uStack_8 = 0;
    puVar5 = (undefined2 *)FUN_0088a820();
    param_3._0_3_ = CONCAT21(*puVar5,param_3._0_1_);
    param_3 = (int *)CONCAT13(*(undefined *)(puVar5 + 1),param_3._0_3_);
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_dc);
    }
    uStack_8 = 0xffffffff;
  }
  (*pcStack_14)(param_2,(int)&param_3 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23295 ; VA 0x00b0f110 ; FUN_00b0f110 */

void __thiscall FUN_00b0f110(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_dc [200];
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179904b;
  pvStack_10 = ExceptionList;
  iVar1 = *param_3;
  pcStack_14 = *(code **)(**(int **)(param_1 + 0x34) + 0x10);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088d230();
  if (iVar1 == iVar3) {
    iVar1 = *piVar2;
    iVar3 = FUN_0088d230();
    if (iVar1 != iVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
  }
  else {
    puVar4 = (undefined4 *)piVar2[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(piVar2 + 2,auStack_dc);
      puVar4 = (undefined4 *)piVar2[1];
    }
    uStack_8 = 0;
    param_3 = (int *)FUN_0088acc0();
    param_3 = (int *)*param_3;
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_dc);
    }
    uStack_8 = 0xffffffff;
  }
  (*pcStack_14)(param_2,&param_3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23296 ; VA 0x00b0f210 ; FUN_00b0f210 */

void __thiscall FUN_00b0f210(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined auStack_f8 [200];
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  undefined8 uStack_20;
  code *pcStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017edc7b;
  pvStack_10 = ExceptionList;
  piStack_14 = *(int **)(param_1 + 0x34);
  pcStack_18 = *(code **)(*piStack_14 + 0x10);
  iVar1 = *param_3;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088d2d0();
  if (iVar1 == iVar2) {
    iVar1 = *param_3;
    iVar2 = FUN_0088d2d0();
    if (iVar1 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar3 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar3 = (int *)0x0;
    }
    iStack_30 = *piVar3;
    iStack_2c = piVar3[1];
    iStack_28 = piVar3[2];
    iStack_24 = piVar3[3];
    uStack_20 = *(undefined8 *)(piVar3 + 4);
  }
  else {
    puVar4 = (undefined4 *)param_3[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_3 + 2,auStack_f8);
      puVar4 = (undefined4 *)param_3[1];
    }
    uStack_8 = 0;
    piVar3 = (int *)FUN_0088adb0();
    iStack_30 = *piVar3;
    iStack_2c = piVar3[1];
    iStack_28 = piVar3[2];
    iStack_24 = piVar3[3];
    uStack_20 = *(undefined8 *)(piVar3 + 4);
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_f8);
    }
    uStack_8 = 0xffffffff;
  }
  (*pcStack_18)(param_2,&iStack_30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23297 ; VA 0x00b0f330 ; FUN_00b0f330 */

void __thiscall FUN_00b0f330(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_dc [200];
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179904b;
  pvStack_10 = ExceptionList;
  iVar1 = *param_3;
  pcStack_14 = *(code **)(**(int **)(param_1 + 0x34) + 0x10);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088d550();
  if (iVar1 == iVar3) {
    iVar1 = *piVar2;
    iVar3 = FUN_0088d550();
    if (iVar1 != iVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
  }
  else {
    puVar4 = (undefined4 *)piVar2[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(piVar2 + 2,auStack_dc);
      puVar4 = (undefined4 *)piVar2[1];
    }
    uStack_8 = 0;
    param_3 = (int *)FUN_0088b3e0();
    param_3 = (int *)*param_3;
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_dc);
    }
    uStack_8 = 0xffffffff;
  }
  (*pcStack_14)(param_2,&param_3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23298 ; VA 0x00b0f430 ; FUN_00b0f430 */

void __thiscall FUN_00b0f430(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_00b0f780();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23299 ; VA 0x00b0f480 ; FUN_00b0f480 */

undefined4 __fastcall FUN_00b0f480(int param_1)

{
  char cVar1;
  float fVar2;
  
  fVar2 = DAT_018ce2f8;
  if (0 < *(int *)(param_1 + 0x68)) {
    fVar2 = DAT_018ce2f4;
  }
  if ((DAT_018ce2f8 -
       (DAT_018ce2f8 - *(float *)(param_1 + 0x54)) * (DAT_018ce2f8 - *(float *)(param_1 + 0x5c)) *
       fVar2 < DAT_018ce2f8) &&
     (((((((cVar1 = FUN_00b034b0(), cVar1 != '\0' || (DAT_01eecc58 != '\0')) ||
          (DAT_01eecc59 != '\0')) || ((DAT_01eecc5a != '\0' || (DAT_01eecc5b != '\0')))) ||
        ((DAT_01eecc5c != '\0' || ((DAT_01eecc5e != '\0' || (DAT_01eecc5d != '\0')))))) ||
       (DAT_01eecc5f != '\0')) ||
      (((((DAT_01eecc60 != '\0' || (DAT_01edfaff != '\0')) || (DAT_01edfb00 != '\0')) ||
        (((DAT_01eecc61 != '\0' || (DAT_01eecc62 != '\0')) ||
         ((DAT_01eecc63 != '\0' || ((DAT_01d66bf4 != '\0' && (DAT_01eeeba9 != '\0')))))))) ||
       ((DAT_01d66c3c != '\0' && (DAT_01eecc64 != '\0')))))))) {
    return 1;
  }
  return 0;
}



/* FUNCTION 23300 ; VA 0x00b0f580 ; FUN_00b0f580 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b0f580(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017edca6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee02c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eee02c);
    if (DAT_01eee02c == -1) {
      uStack_8 = 0;
      FUN_009ca470("CollisionFidelity");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eedfc8 = RBX::Reflection::EnumDesc<enum_RBX::CollisionFidelity>::vftable;
      FUN_009caf20(&DAT_01d66dc0,4);
      FUN_016f3654(&LAB_0188d180);
      FUN_016f37bf(&DAT_01eee02c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eedfc8;
}



/* FUNCTION 23301 ; VA 0x00b0f630 ; FUN_00b0f630 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b0f630(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017edcc6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee094) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eee094);
    if (DAT_01eee094 == -1) {
      uStack_8 = 0;
      FUN_009ca470(&DAT_0194e7f4);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eee030 = RBX::Reflection::EnumDesc<enum_RBX::PartInstance::FormFactor>::vftable;
      FUN_009caf20(&DAT_01d66c64,4);
      FUN_009cac90("Block",1);
      FUN_016f3654(&LAB_0188d1a0);
      FUN_016f37bf(&DAT_01eee094);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eee030;
}



/* FUNCTION 23302 ; VA 0x00b0f6f0 ; FUN_00b0f6f0 */

undefined * FUN_00b0f6f0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017edcdc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eedf5c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eedf5c);
    if (DAT_01eedf5c == -1) {
      uStack_8 = 0;
      FUN_00ff4f30();
      FUN_016f3654(&LAB_0188d1c0);
      FUN_016f37bf(&DAT_01eedf5c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eedef8;
}



/* FUNCTION 23303 ; VA 0x00b0f780 ; FUN_00b0f780 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b0f780(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017edd06;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee0fc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eee0fc);
    if (DAT_01eee0fc == -1) {
      uStack_8 = 0;
      FUN_009ca470("NetworkOwnership");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eee098 = RBX::Reflection::EnumDesc<enum_RBX::NetworkOwnership>::vftable;
      FUN_009caf20(&DAT_01d66c4c,3);
      FUN_016f3654(&LAB_0188d1e0);
      FUN_016f37bf(&DAT_01eee0fc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eee098;
}



/* FUNCTION 23304 ; VA 0x00b0f830 ; FUN_00b0f830 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b0f830(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017edd26;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eedfc4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eedfc4);
    if (DAT_01eedfc4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("RenderFidelity");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eedf60 = RBX::Reflection::EnumDesc<enum_RBX::RenderFidelity>::vftable;
      FUN_009caf20(&DAT_01d66de0,3);
      FUN_016f3654(&LAB_0188d200);
      FUN_016f37bf(&DAT_01eedfc4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eedf60;
}



/* FUNCTION 23305 ; VA 0x00b0f8e0 ; FUN_00b0f8e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b0f8e0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee14c) {
    FUN_016f3809(&DAT_01eee14c);
    if (DAT_01eee14c == -1) {
      _DAT_01eee140 = FUN_005c65e0;
      _DAT_01eee144 = FUN_005c65e0;
      _DAT_01eee148 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eee14c);
    }
  }
  return &DAT_01eee140;
}



/* FUNCTION 23306 ; VA 0x00b0f950 ; FUN_00b0f950 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b0f950(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee10c) {
    FUN_016f3809(&DAT_01eee10c);
    if (DAT_01eee10c == -1) {
      _DAT_01eee100 = FUN_005c65e0;
      _DAT_01eee104 = FUN_005c65e0;
      _DAT_01eee108 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eee10c);
    }
  }
  return &DAT_01eee100;
}



/* FUNCTION 23307 ; VA 0x00b0f9c0 ; FUN_00b0f9c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b0f9c0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee12c) {
    FUN_016f3809(&DAT_01eee12c);
    if (DAT_01eee12c == -1) {
      _DAT_01eee120 = FUN_005c65e0;
      _DAT_01eee124 = FUN_005c65e0;
      _DAT_01eee128 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eee12c);
    }
  }
  return &DAT_01eee120;
}



/* FUNCTION 23308 ; VA 0x00b0fa30 ; FUN_00b0fa30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b0fa30(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee11c) {
    FUN_016f3809(&DAT_01eee11c);
    if (DAT_01eee11c == -1) {
      _DAT_01eee110 = FUN_005c65e0;
      _DAT_01eee114 = FUN_005c65e0;
      _DAT_01eee118 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eee11c);
    }
  }
  return &DAT_01eee110;
}



/* FUNCTION 23309 ; VA 0x00b0faa0 ; FUN_00b0faa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b0faa0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee13c) {
    FUN_016f3809(&DAT_01eee13c);
    if (DAT_01eee13c == -1) {
      _DAT_01eee130 = FUN_005c65e0;
      _DAT_01eee134 = FUN_005c65e0;
      _DAT_01eee138 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eee13c);
    }
  }
  return &DAT_01eee130;
}



/* FUNCTION 23310 ; VA 0x00b0fb10 ; FUN_00b0fb10 */

void FUN_00b0fb10(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4,uint param_5
                 ,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
                 undefined4 *param_10,ulonglong param_11,uint param_12,undefined4 param_13,
                 undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
                 undefined8 param_18)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017edd50;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_40 = 0;
  ExceptionList = &pvStack_10;
  if (param_12 != 0) {
    uStack_40 = param_12;
    if ((param_12 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = &param_14;
      uStack_50 = 0xb0fb7a;
      ExceptionList = &pvStack_10;
      (**(code **)(param_12 & 0xfffffffe))();
    }
    else {
      uStack_38 = param_14;
      uStack_34 = param_15;
      uStack_30 = param_16;
      puStack_2c = (undefined4 *)param_17;
      uStack_28 = param_18;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 3;
  if (param_5 != 0) {
    if ((param_5 & 1) == 0) {
      (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_58,0);
    }
    else {
      uStack_58 = param_7;
      uStack_54 = param_8;
      uStack_50 = param_9;
      puStack_4c = param_10;
      uStack_48 = param_11;
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00b04120(param_1,param_2,3,param_3,param_4);
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = CONCAT44(0xb0fc19,(undefined4)uStack_28);
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_28 = CONCAT44(0xb0fc28,(undefined4)uStack_28);
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    puStack_2c = &param_7;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xb0fc49;
    (**(code **)(param_5 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    puStack_2c = &param_14;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xb0fc77;
    (**(code **)(param_12 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23311 ; VA 0x00b0fc90 ; FUN_00b0fc90 */

void __thiscall FUN_00b0fc90(int *param_1,float *param_2,float *param_3)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  
  pfVar1 = (float *)(**(code **)(*param_1 + 0xbc))();
  fVar4 = param_3[2];
  if (param_3[2] <= pfVar1[2]) {
    fVar4 = pfVar1[2];
  }
  fVar3 = param_3[1];
  if (param_3[1] <= pfVar1[1]) {
    fVar3 = pfVar1[1];
  }
  fVar2 = *param_3;
  if (*param_3 <= *pfVar1) {
    fVar2 = *pfVar1;
  }
  *param_2 = fVar2;
  param_2[1] = fVar3;
  param_2[2] = fVar4;
  return;
}



/* FUNCTION 23312 ; VA 0x00b0fcf0 ; FUN_00b0fcf0 */

void FUN_00b0fcf0(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4,uint param_5
                 ,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
                 undefined4 *param_10,ulonglong param_11,uint param_12,undefined4 param_13,
                 undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
                 undefined8 param_18)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017edd50;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_40 = 0;
  ExceptionList = &pvStack_10;
  if (param_12 != 0) {
    uStack_40 = param_12;
    if ((param_12 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = &param_14;
      uStack_50 = 0xb0fd5a;
      ExceptionList = &pvStack_10;
      (**(code **)(param_12 & 0xfffffffe))();
    }
    else {
      uStack_38 = param_14;
      uStack_34 = param_15;
      uStack_30 = param_16;
      puStack_2c = (undefined4 *)param_17;
      uStack_28 = param_18;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 3;
  if (param_5 != 0) {
    if ((param_5 & 1) == 0) {
      (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_58,0);
    }
    else {
      uStack_58 = param_7;
      uStack_54 = param_8;
      uStack_50 = param_9;
      puStack_4c = param_10;
      uStack_48 = param_11;
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00b04120(param_1,param_2,1,param_3,param_4);
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = CONCAT44(0xb0fdf9,(undefined4)uStack_28);
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_28 = CONCAT44(0xb0fe08,(undefined4)uStack_28);
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    puStack_2c = &param_7;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xb0fe29;
    (**(code **)(param_5 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    puStack_2c = &param_14;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xb0fe57;
    (**(code **)(param_12 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23313 ; VA 0x00b0fe70 ; FUN_00b0fe70 */

void FUN_00b0fe70(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0x3f800000;
  return;
}



/* FUNCTION 23314 ; VA 0x00b0fe90 ; FUN_00b0fe90 */

void __fastcall FUN_00b0fe90(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  
  uVar2 = *(uint *)(param_1 + 0xb4);
  for (iVar1 = *(int *)(param_1 + 0x34); iVar1 != 0; iVar1 = *(int *)(iVar1 + 0x34)) {
    iVar3 = FUN_009ba880(iVar1);
    if (iVar3 != 0) goto LAB_00b0feba;
  }
  iVar3 = 0;
LAB_00b0feba:
  uVar4 = *(uint *)(param_1 + 0xb4) | 2;
  if (iVar3 == 0) {
    uVar4 = *(uint *)(param_1 + 0xb4) & 0xfffffffd;
  }
  *(uint *)(param_1 + 0xb4) = uVar4;
  if ((*(int **)(param_1 + 0xb0) != (int *)0x0) && (uVar2 != uVar4)) {
                    /* WARNING: Could not recover jumptable at 0x00b0fee6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(**(int **)(param_1 + 0xb0) + 0x30))();
    return;
  }
  return;
}



/* FUNCTION 23315 ; VA 0x00b0fef0 ; FUN_00b0fef0 */

void FUN_00b0fef0(int *param_1)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 uStack_c;
  char cStack_6;
  char cStack_5;
  
  uStack_c = 0xffffffff;
  FUN_00b03160(&uStack_c,&cStack_6,&cStack_5,param_1);
  iVar3 = FUN_00c15700();
  if (cStack_6 != '\0') {
    uVar5 = 0;
    if (param_1[1] - *param_1 >> 2 != 0) {
      do {
        iVar4 = FUN_00c15700();
        uVar1 = uStack_c;
        if (*(int *)(*param_1 + uVar5 * 4) == iVar4) {
          if (iVar4 == 0) {
            uVar6 = 0;
          }
          else {
            uVar6 = -(uint)(*(int *)(iVar4 + 0x1b0) != 0) & *(int *)(iVar4 + 0x1b0) - 0x58U;
          }
          iVar4 = FUN_008f7870(uVar6);
          if ((iVar4 != 0) && ((*(int *)(iVar4 + 0x4a0) == 2 || (*(int *)(iVar4 + 0x4a0) == 3)))) {
            if ((cStack_5 != '\0') && (*(char *)(*(int *)(uVar6 + 0xa8) + 0x22c) != '\x01')) {
              *(undefined *)(*(int *)(uVar6 + 0xa8) + 0x22c) = 1;
              cVar2 = FUN_0098c5a0(uVar6,0);
              if (cVar2 != '\0') {
                FUN_008a4940(&DAT_01eed490);
              }
            }
            FUN_00b0df50(uVar1);
          }
        }
        uVar5 = uVar5 + 1;
      } while (uVar5 < (uint)(param_1[1] - *param_1 >> 2));
    }
    uVar1 = uStack_c;
    if (iVar3 != 0) {
      uVar5 = -(uint)(*(int *)(iVar3 + 0x1b0) != 0) & *(int *)(iVar3 + 0x1b0) - 0x58U;
      iVar3 = FUN_008f7870(uVar5);
      if ((iVar3 != 0) && ((*(int *)(iVar3 + 0x4a0) == 2 || (*(int *)(iVar3 + 0x4a0) == 3)))) {
        if ((cStack_5 != '\0') && (*(char *)(*(int *)(uVar5 + 0xa8) + 0x22c) != '\x01')) {
          *(undefined *)(*(int *)(uVar5 + 0xa8) + 0x22c) = 1;
          cVar2 = FUN_0098c5a0(uVar5,0);
          if (cVar2 != '\0') {
            FUN_008a4940(&DAT_01eed490);
          }
        }
        FUN_00b0df50(uVar1);
      }
    }
  }
  return;
}



/* FUNCTION 23316 ; VA 0x00b10070 ; FUN_00b10070 */

void __fastcall FUN_00b10070(int param_1)

{
  char cVar1;
  undefined uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  uint uVar7;
  int iStack_10;
  uint uStack_c;
  uint uStack_8;
  
  iVar3 = FUN_00a9d0e0(param_1);
  if (iVar3 == 0) {
    iVar5 = 0;
  }
  else {
    iVar5 = *(int *)(iVar3 + 0x1b4);
  }
  uStack_c = *(uint *)(param_1 + 0xa8);
  iStack_10 = *(int *)(uStack_c + 0x1a8);
  if (iVar5 == iStack_10) {
    return;
  }
  if (iStack_10 != 0) {
    if (*(int *)(param_1 + 0xf0) != 0) {
      iVar4 = FUN_008a40f0();
      if (iVar4 == 0) {
LAB_00b100da:
        uStack_8 = uStack_8 & 0xffffff00;
      }
      else {
        iVar4 = FUN_008a40f0();
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        if (*(char *)(iVar4 + 200) == '\0') goto LAB_00b100da;
      }
      FUN_005e6780(uStack_8);
      uStack_c = *(uint *)(param_1 + 0xa8);
    }
    FUN_00c3e6b0(0);
    iVar4 = FUN_008a40f0();
    if (iVar4 == 0) {
LAB_00b1011e:
      uStack_8 = uStack_8 & 0xffffff00;
    }
    else {
      iVar4 = FUN_008a40f0();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (*(char *)(iVar4 + 200) == '\0') goto LAB_00b1011e;
    }
    FUN_00bc0610(uStack_c,uStack_8);
  }
  if (iVar5 == 0) {
    return;
  }
  FUN_00bbe3d0(*(undefined4 *)(param_1 + 0xa8));
  if (*(int *)(param_1 + 0xf0) == 0) goto LAB_00b1017f;
  iVar5 = FUN_008a40f0();
  if (iVar5 == 0) {
LAB_00b1016d:
    uStack_c = uStack_c & 0xffffff00;
  }
  else {
    iVar5 = FUN_008a40f0();
    uStack_c = CONCAT31(uStack_c._1_3_,1);
    if (*(char *)(iVar5 + 200) == '\0') goto LAB_00b1016d;
  }
  FUN_005e6780(uStack_c);
LAB_00b1017f:
  cVar1 = FUN_00c14800();
  if (cVar1 != '\0') {
    FUN_00c3e2a0();
  }
  if (iVar3 == 0) {
    iVar3 = 0;
  }
  else {
    iVar3 = iVar3 + 0x148;
  }
  FUN_00c3e6b0(iVar3);
  FUN_0097bfe0(&uStack_8,param_1);
  iStack_10 = *(int *)(*(int *)(param_1 + 0xa8) + 0x1dc);
  uVar6 = FUN_0067ad50(&uStack_c);
  cVar1 = FUN_00a33d60(uVar6);
  if (cVar1 != '\0') {
    iVar3 = FUN_0097bfc0(param_1);
    uVar7 = 2;
    if (iVar3 != 0) {
      uVar7 = uStack_8;
    }
    *(uint *)(*(int *)(param_1 + 0xa8) + 0x1dc) = uVar7;
  }
  iStack_10 = *(int *)(*(int *)(param_1 + 0xa8) + 0x1dc);
  uVar2 = FUN_00b03450(&iStack_10,&uStack_8);
  *(undefined *)(param_1 + 0xe4) = uVar2;
  return;
}



/* FUNCTION 23317 ; VA 0x00b10230 ; FUN_00b10230 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b10230(int param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  float *pfVar6;
  undefined4 *puVar7;
  float10 fVar8;
  float fVar9;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  undefined auStack_44 [36];
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  double dStack_14;
  float fStack_c;
  float fStack_8;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0xa8) + 0x1ac);
  fStack_1c = *(float *)(iVar1 + 8) * DAT_018f7860;
  fStack_c = *(float *)(iVar1 + 4) * DAT_018ce2f4;
  fStack_8 = *(float *)(iVar1 + 0xc) * DAT_018ce2f4;
  dStack_14 = (double)fStack_c;
  fVar8 = (float10)FUN_01725280(dStack_14);
  fVar9 = (float)fVar8;
  if (fVar9 < 0.0) {
    fVar9 = fVar9 - DAT_018ce2f4;
  }
  else {
    fVar9 = fVar9 + DAT_018ce2f4;
  }
  fStack_20 = fStack_c - (float)(int)fVar9;
  dStack_14 = (double)fStack_8;
  fVar8 = (float10)FUN_01725280(dStack_14);
  dStack_14 = (double)fVar8;
  fVar9 = (float)fVar8;
  if (fVar9 < 0.0) {
    fVar9 = fVar9 - DAT_018ce2f4;
  }
  else {
    fVar9 = fVar9 + DAT_018ce2f4;
  }
  uStack_54 = 0x3f800000;
  fStack_48 = fStack_8 - (float)(int)fVar9;
  uStack_74 = _DAT_018e3fb0;
  uStack_70 = _UNK_018e3fb4;
  uStack_6c = _UNK_018e3fb8;
  uStack_68 = _UNK_018e3fbc;
  uStack_64 = _DAT_018e3fb0;
  uStack_60 = _UNK_018e3fb4;
  uStack_5c = _UNK_018e3fb8;
  uStack_58 = _UNK_018e3fbc;
  fStack_50 = fStack_20;
  fStack_4c = fStack_1c;
  fStack_18 = fStack_48;
  pfVar6 = (float *)FUN_00c157b0();
  dStack_14 = (double)(ulonglong)
                      (uint)(pfVar6[1] * fStack_4c + *pfVar6 * fStack_50 + pfVar6[2] * fStack_48 +
                            pfVar6[9]);
  fStack_c = pfVar6[3] * fStack_50 + pfVar6[4] * fStack_4c + pfVar6[5] * fStack_48 + pfVar6[10];
  fStack_18 = pfVar6[6] * fStack_50 + pfVar6[7] * fStack_4c + pfVar6[8] * fStack_48 + pfVar6[0xb];
  puVar7 = (undefined4 *)FUN_01160c20(auStack_44,&uStack_74);
  uVar2 = puVar7[1];
  uVar3 = puVar7[2];
  uVar4 = puVar7[3];
  *param_2 = *puVar7;
  param_2[1] = uVar2;
  param_2[2] = uVar3;
  param_2[3] = uVar4;
  uVar3 = puVar7[5];
  uVar4 = puVar7[6];
  uVar5 = puVar7[7];
  uVar2 = puVar7[8];
  param_2[4] = puVar7[4];
  param_2[5] = uVar3;
  param_2[6] = uVar4;
  param_2[7] = uVar5;
  param_2[8] = uVar2;
  *(ulonglong *)(param_2 + 9) = CONCAT44(fStack_c,SUB84(dStack_14,0));
  param_2[0xb] = fStack_18;
  return param_2;
}



/* FUNCTION 23318 ; VA 0x00b10440 ; FUN_00b10440 */

void __thiscall FUN_00b10440(int param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&uStack_34,param_2);
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  uVar1 = DAT_01ede5c0;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 0;
    puVar2[2] = 0;
    puVar2[4] = uVar1;
    puVar2[5] = 7;
    puVar2[6] = uStack_10;
    puVar2[8] = 0;
    puVar2[9] = 0;
  }
  if (*(undefined4 **)(param_3 + 8) == (undefined4 *)0x0) {
    *(undefined4 **)(param_3 + 4) = puVar2;
  }
  else {
    **(undefined4 **)(param_3 + 8) = puVar2;
  }
  *(undefined4 **)(param_3 + 8) = puVar2;
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  uVar1 = DAT_01ede5c4;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 0;
    puVar2[2] = 0;
    puVar2[4] = uVar1;
    puVar2[5] = 7;
    puVar2[6] = uStack_c;
    puVar2[8] = 0;
    puVar2[9] = 0;
  }
  if (*(undefined4 **)(param_3 + 8) == (undefined4 *)0x0) {
    *(undefined4 **)(param_3 + 4) = puVar2;
  }
  else {
    **(undefined4 **)(param_3 + 8) = puVar2;
  }
  *(undefined4 **)(param_3 + 8) = puVar2;
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  uVar1 = DAT_01ede5c8;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 0;
    puVar2[2] = 0;
    puVar2[4] = uVar1;
    puVar2[5] = 7;
    puVar2[6] = uStack_8;
    puVar2[8] = 0;
    puVar2[9] = 0;
  }
  if (*(undefined4 **)(param_3 + 8) == (undefined4 *)0x0) {
    *(undefined4 **)(param_3 + 4) = puVar2;
  }
  else {
    **(undefined4 **)(param_3 + 8) = puVar2;
  }
  *(undefined4 **)(param_3 + 8) = puVar2;
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  uVar1 = DAT_01ede5cc;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 0;
    puVar2[2] = 0;
    puVar2[4] = uVar1;
    puVar2[5] = 7;
    puVar2[6] = uStack_34;
    puVar2[8] = 0;
    puVar2[9] = 0;
  }
  if (*(undefined4 **)(param_3 + 8) == (undefined4 *)0x0) {
    *(undefined4 **)(param_3 + 4) = puVar2;
  }
  else {
    **(undefined4 **)(param_3 + 8) = puVar2;
  }
  *(undefined4 **)(param_3 + 8) = puVar2;
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  uVar1 = DAT_01ede5d0;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 0;
    puVar2[2] = 0;
    puVar2[4] = uVar1;
    puVar2[5] = 7;
    puVar2[6] = uStack_30;
    puVar2[8] = 0;
    puVar2[9] = 0;
  }
  if (*(undefined4 **)(param_3 + 8) == (undefined4 *)0x0) {
    *(undefined4 **)(param_3 + 4) = puVar2;
  }
  else {
    **(undefined4 **)(param_3 + 8) = puVar2;
  }
  *(undefined4 **)(param_3 + 8) = puVar2;
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  uVar1 = DAT_01ede5d4;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 0;
    puVar2[2] = 0;
    puVar2[4] = uVar1;
    puVar2[5] = 7;
    puVar2[6] = uStack_2c;
    puVar2[8] = 0;
    puVar2[9] = 0;
  }
  if (*(undefined4 **)(param_3 + 8) == (undefined4 *)0x0) {
    *(undefined4 **)(param_3 + 4) = puVar2;
  }
  else {
    **(undefined4 **)(param_3 + 8) = puVar2;
  }
  *(undefined4 **)(param_3 + 8) = puVar2;
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  uVar1 = DAT_01ede5d8;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 0;
    puVar2[2] = 0;
    puVar2[4] = uVar1;
    puVar2[5] = 7;
    puVar2[6] = uStack_28;
    puVar2[8] = 0;
    puVar2[9] = 0;
  }
  if (*(undefined4 **)(param_3 + 8) == (undefined4 *)0x0) {
    *(undefined4 **)(param_3 + 4) = puVar2;
  }
  else {
    **(undefined4 **)(param_3 + 8) = puVar2;
  }
  *(undefined4 **)(param_3 + 8) = puVar2;
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  uVar1 = DAT_01ede5dc;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 0;
    puVar2[2] = 0;
    puVar2[4] = uVar1;
    puVar2[5] = 7;
    puVar2[6] = uStack_24;
    puVar2[8] = 0;
    puVar2[9] = 0;
  }
  if (*(undefined4 **)(param_3 + 8) == (undefined4 *)0x0) {
    *(undefined4 **)(param_3 + 4) = puVar2;
  }
  else {
    **(undefined4 **)(param_3 + 8) = puVar2;
  }
  *(undefined4 **)(param_3 + 8) = puVar2;
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  uVar1 = DAT_01ede5e0;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 0;
    puVar2[2] = 0;
    puVar2[4] = uVar1;
    puVar2[5] = 7;
    puVar2[6] = uStack_20;
    puVar2[8] = 0;
    puVar2[9] = 0;
  }
  if (*(undefined4 **)(param_3 + 8) == (undefined4 *)0x0) {
    *(undefined4 **)(param_3 + 4) = puVar2;
  }
  else {
    **(undefined4 **)(param_3 + 8) = puVar2;
  }
  *(undefined4 **)(param_3 + 8) = puVar2;
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  uVar1 = DAT_01ede5e4;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 0;
    puVar2[2] = 0;
    puVar2[4] = uVar1;
    puVar2[5] = 7;
    puVar2[6] = uStack_1c;
    puVar2[8] = 0;
    puVar2[9] = 0;
  }
  if (*(undefined4 **)(param_3 + 8) == (undefined4 *)0x0) {
    *(undefined4 **)(param_3 + 4) = puVar2;
  }
  else {
    **(undefined4 **)(param_3 + 8) = puVar2;
  }
  *(undefined4 **)(param_3 + 8) = puVar2;
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  uVar1 = DAT_01ede5e8;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 0;
    puVar2[2] = 0;
    puVar2[4] = uVar1;
    puVar2[5] = 7;
    puVar2[6] = uStack_18;
    puVar2[8] = 0;
    puVar2[9] = 0;
  }
  if (*(undefined4 **)(param_3 + 8) == (undefined4 *)0x0) {
    *(undefined4 **)(param_3 + 4) = puVar2;
  }
  else {
    **(undefined4 **)(param_3 + 8) = puVar2;
  }
  *(undefined4 **)(param_3 + 8) = puVar2;
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  uVar1 = DAT_01ede5ec;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 0;
    puVar2[2] = 0;
    puVar2[4] = uVar1;
    puVar2[5] = 7;
    puVar2[6] = uStack_14;
    puVar2[8] = 0;
    puVar2[9] = 0;
  }
  if (*(undefined4 **)(param_3 + 8) == (undefined4 *)0x0) {
    *(undefined4 **)(param_3 + 4) = puVar2;
    *(undefined4 **)(param_3 + 8) = puVar2;
    return;
  }
  **(undefined4 **)(param_3 + 8) = puVar2;
  *(undefined4 **)(param_3 + 8) = puVar2;
  return;
}



/* FUNCTION 23319 ; VA 0x00b10900 ; FUN_00b10900 */

undefined4 * __thiscall FUN_00b10900(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 extraout_ECX;
  undefined **ppuVar4;
  int *in_stack_00000014;
  int *in_stack_0000001c;
  int *in_stack_00000024;
  int *piStack_54;
  int *piStack_4c;
  int *piStack_44;
  undefined auStack_3c [16];
  int *piStack_2c;
  int *piStack_24;
  int *piStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017edd78;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00b157d0(&stack0x00000004);
  *param_1 = 0;
  FUN_00b157d0(extraout_ECX);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00b157d0(auStack_3c);
  ppuVar4 = &PTR_FUN_01951bf4;
  cVar3 = FUN_00b12660();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[2] + -1;
    piStack_1c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_1c + 4))();
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_24[2] + -1;
    piStack_24[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_24 + 4))();
    }
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_2c[2] + -1;
    piStack_2c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_2c + 4))();
    }
  }
  if (piStack_44 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_44[2] + -1;
    piStack_44[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_44 + 4))();
    }
  }
  if (piStack_4c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_4c[2] + -1;
    piStack_4c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_4c + 4))();
    }
  }
  if (piStack_54 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_54[2] + -1;
    piStack_54[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_54 + 4))();
    }
  }
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000024[2] + -1;
    in_stack_00000024[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*in_stack_00000024 + 4))();
    }
  }
  if (in_stack_0000001c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000001c[2] + -1;
    in_stack_0000001c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*in_stack_0000001c + 4))();
    }
  }
  if (in_stack_00000014 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000014 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*in_stack_00000014 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23320 ; VA 0x00b10a50 ; FUN_00b10a50 */

undefined4 * __thiscall FUN_00b10a50(undefined4 *param_1,undefined4 param_2)

{
  char cVar1;
  undefined **ppuVar2;
  undefined4 in_stack_00000014;
  undefined in_stack_00000018;
  undefined auStack_88 [12];
  undefined4 uStack_7c;
  undefined uStack_78;
  undefined4 uStack_74;
  undefined auStack_70 [12];
  undefined4 uStack_64;
  undefined uStack_60;
  undefined4 uStack_5c;
  undefined auStack_58 [12];
  undefined4 uStack_4c;
  undefined uStack_48;
  undefined4 uStack_44;
  undefined auStack_40 [12];
  undefined4 uStack_34;
  undefined uStack_30;
  undefined4 uStack_2c;
  undefined auStack_28 [12];
  undefined4 uStack_1c;
  undefined uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eddc3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_006d07c0(&stack0x00000008);
  uStack_7c = in_stack_00000014;
  uStack_78 = in_stack_00000018;
  uStack_74 = param_2;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_006d07c0(auStack_88);
  uStack_64 = uStack_7c;
  uStack_60 = uStack_78;
  uStack_5c = uStack_74;
  uStack_8._0_1_ = 2;
  FUN_006d07c0(auStack_70);
  uStack_4c = uStack_64;
  uStack_48 = uStack_60;
  uStack_2c = uStack_5c;
  uStack_8._0_1_ = 3;
  FUN_006d07c0(auStack_58);
  uStack_1c = uStack_4c;
  uStack_18 = uStack_48;
  uStack_8._0_1_ = 4;
  cVar1 = FUN_00585a40(&uStack_2c);
  if (cVar1 != '\0') {
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    FUN_00577b20();
  }
  else {
    uStack_44 = uStack_2c;
    FUN_006d07c0(auStack_28);
    uStack_34 = uStack_1c;
    uStack_30 = uStack_18;
    param_1[2] = uStack_44;
    uStack_8._0_1_ = 5;
    FUN_006d07c0(auStack_40);
    param_1[6] = uStack_34;
    *(undefined *)(param_1 + 7) = uStack_30;
    uStack_8._0_1_ = 6;
    FUN_00577b20();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_00577b20();
  }
  uStack_8._0_1_ = 10;
  FUN_00577b20();
  ppuVar2 = &PTR_FUN_01951b70;
  if (cVar1 != '\0') {
    ppuVar2 = (undefined **)0x0;
  }
  *param_1 = ppuVar2;
  uStack_8._0_1_ = 0xb;
  FUN_00577b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  FUN_00577b20();
  uStack_8 = 0xd;
  FUN_00577b20();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23321 ; VA 0x00b10bf0 ; FUN_00b10bf0 */

undefined4 * __thiscall
FUN_00b10bf0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_01951c0c;
  cVar3 = FUN_005918b0(param_2,param_3,param_4,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 23322 ; VA 0x00b10ce0 ; FUN_00b10ce0 */

undefined4 * __thiscall
FUN_00b10ce0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 in_stack_0000001c;
  undefined in_stack_00000020;
  undefined4 uStack_7c;
  int *piStack_78;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 *puStack_60;
  undefined4 uStack_50;
  int *piStack_4c;
  undefined auStack_48 [12];
  undefined4 uStack_3c;
  undefined uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined auStack_28 [12];
  undefined4 uStack_1c;
  undefined uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ede00;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_50;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_50 = param_3;
  piStack_4c = param_4;
  puStack_60 = (undefined4 *)&stack0x00000010;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uStack_64 = 0xb10d4a;
  FUN_006d07c0();
  uStack_3c = in_stack_0000001c;
  uStack_38 = in_stack_00000020;
  uStack_34 = param_2;
  puStack_14 = &uStack_30;
  *param_1 = 0;
  if (piStack_4c != (int *)0x0) {
    LOCK();
    piStack_4c[2] = piStack_4c[2] + 1;
    UNLOCK();
  }
  uStack_30 = uStack_50;
  piStack_2c = piStack_4c;
  puStack_60 = (undefined4 *)auStack_48;
  uStack_8._0_1_ = 3;
  uStack_64 = 0xb10d9d;
  FUN_006d07c0();
  uStack_1c = uStack_3c;
  uStack_18 = uStack_38;
  puStack_60 = param_1 + 2;
  puStack_14 = &uStack_7c;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piStack_2c[2] = piStack_2c[2] + 1;
    UNLOCK();
  }
  uStack_7c = uStack_30;
  piStack_78 = piStack_2c;
  uStack_8._0_1_ = 5;
  FUN_006d07c0(auStack_28);
  uStack_68 = uStack_1c;
  uStack_64 = CONCAT31(uStack_64._1_3_,uStack_18);
  ppuVar4 = &PTR_FUN_01951b60;
  uStack_8._0_1_ = 4;
  cVar3 = FUN_00b12a20();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  puStack_60 = (undefined4 *)0xb10e24;
  FUN_00577b20();
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_2c[2] + -1;
    piStack_2c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_60 = (undefined4 *)0xb10e3c;
      (**(code **)(*piStack_2c + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  puStack_60 = (undefined4 *)0xb10e48;
  FUN_00577b20();
  if (piStack_4c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_4c[2] + -1;
    piStack_4c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_60 = (undefined4 *)0xb10e5d;
      (**(code **)(*piStack_4c + 4))();
    }
  }
  uStack_8 = 8;
  puStack_60 = (undefined4 *)0xb10e6c;
  FUN_00577b20();
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_60 = (undefined4 *)0xb10e80;
      (**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23323 ; VA 0x00b10ea0 ; FUN_00b10ea0 */

undefined4 * __thiscall
FUN_00b10ea0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 in_stack_0000001c;
  undefined in_stack_00000020;
  undefined4 uStack_7c;
  int *piStack_78;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 *puStack_60;
  undefined4 uStack_50;
  int *piStack_4c;
  undefined auStack_48 [12];
  undefined4 uStack_3c;
  undefined uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined auStack_28 [12];
  undefined4 uStack_1c;
  undefined uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ede40;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_50;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_50 = param_3;
  piStack_4c = param_4;
  puStack_60 = (undefined4 *)&stack0x00000010;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uStack_64 = 0xb10f0a;
  FUN_006d07c0();
  uStack_3c = in_stack_0000001c;
  uStack_38 = in_stack_00000020;
  uStack_34 = param_2;
  puStack_14 = &uStack_30;
  *param_1 = 0;
  if (piStack_4c != (int *)0x0) {
    LOCK();
    piStack_4c[2] = piStack_4c[2] + 1;
    UNLOCK();
  }
  uStack_30 = uStack_50;
  piStack_2c = piStack_4c;
  puStack_60 = (undefined4 *)auStack_48;
  uStack_8._0_1_ = 3;
  uStack_64 = 0xb10f5d;
  FUN_006d07c0();
  uStack_1c = uStack_3c;
  uStack_18 = uStack_38;
  puStack_60 = param_1 + 2;
  puStack_14 = &uStack_7c;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piStack_2c[2] = piStack_2c[2] + 1;
    UNLOCK();
  }
  uStack_7c = uStack_30;
  piStack_78 = piStack_2c;
  uStack_8._0_1_ = 5;
  FUN_006d07c0(auStack_28);
  uStack_68 = uStack_1c;
  uStack_64 = CONCAT31(uStack_64._1_3_,uStack_18);
  ppuVar4 = &PTR_FUN_01951b68;
  uStack_8._0_1_ = 4;
  cVar3 = FUN_00b12c10();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  puStack_60 = (undefined4 *)0xb10fe4;
  FUN_00577b20();
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_2c[2] + -1;
    piStack_2c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_60 = (undefined4 *)0xb10ffc;
      (**(code **)(*piStack_2c + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  puStack_60 = (undefined4 *)0xb11008;
  FUN_00577b20();
  if (piStack_4c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_4c[2] + -1;
    piStack_4c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_60 = (undefined4 *)0xb1101d;
      (**(code **)(*piStack_4c + 4))();
    }
  }
  uStack_8 = 8;
  puStack_60 = (undefined4 *)0xb1102c;
  FUN_00577b20();
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_60 = (undefined4 *)0xb11040;
      (**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23324 ; VA 0x00b11060 ; FUN_00b11060 */

undefined4 * __thiscall FUN_00b11060(undefined4 *param_1,undefined4 param_2)

{
  char cVar1;
  undefined **ppuVar2;
  uint in_stack_00000034;
  undefined4 auStack_140 [21];
  undefined4 uStack_ec;
  undefined *puStack_e8;
  undefined *puStack_e4;
  undefined4 *puStack_e0;
  undefined auStack_cc [40];
  uint uStack_a4;
  undefined auStack_9c [40];
  undefined4 uStack_74;
  undefined auStack_6c [40];
  uint uStack_44;
  undefined auStack_3c [40];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ede6b;
  pvStack_10 = ExceptionList;
  puStack_e0 = (undefined4 *)&stack0x0000000c;
  uStack_8 = 0;
  puStack_e4 = (undefined *)0xb110a4;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00b17130();
  uStack_74 = param_2;
  puStack_e0 = (undefined4 *)auStack_cc;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  puStack_e4 = (undefined *)0xb110c6;
  FUN_00b17130();
  puStack_e0 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = auStack_140;
  auStack_140[0] = uStack_74;
  FUN_00b17130(auStack_6c);
  ppuVar2 = &PTR_FUN_01951bdc;
  cVar1 = FUN_00b12e00();
  if (cVar1 == '\0') {
    ppuVar2 = (undefined **)0x0;
  }
  *param_1 = ppuVar2;
  uStack_8._0_1_ = 3;
  if (uStack_44 != 0) {
    if (((uStack_44 & 1) == 0) && (*(code **)(uStack_44 & 0xfffffffe) != (code *)0x0)) {
      puStack_e8 = auStack_3c;
      puStack_e0 = (undefined4 *)0x2;
      uStack_ec = 0xb1111d;
      puStack_e4 = puStack_e8;
      (**(code **)(uStack_44 & 0xfffffffe))();
    }
    uStack_44 = 0;
  }
  puStack_e0 = (undefined4 *)0xb1112f;
  FUN_00a7c840();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_a4 != 0) {
    if (((uStack_a4 & 1) == 0) && (*(code **)(uStack_a4 & 0xfffffffe) != (code *)0x0)) {
      puStack_e8 = auStack_9c;
      puStack_e0 = (undefined4 *)0x2;
      uStack_ec = 0xb11156;
      puStack_e4 = puStack_e8;
      (**(code **)(uStack_a4 & 0xfffffffe))();
    }
    uStack_a4 = 0;
  }
  puStack_e0 = (undefined4 *)0xb1116e;
  FUN_00a7c840();
  uStack_8 = 5;
  if (in_stack_00000034 != 0) {
    if (((in_stack_00000034 & 1) == 0) &&
       (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
      puStack_e8 = &stack0x0000003c;
      puStack_e0 = (undefined4 *)0x2;
      uStack_ec = 0xb11192;
      puStack_e4 = puStack_e8;
      (**(code **)(in_stack_00000034 & 0xfffffffe))();
    }
    in_stack_00000034 = 0;
  }
  puStack_e0 = (undefined4 *)0xb111a4;
  FUN_00a7c840();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23325 ; VA 0x00b111c0 ; FUN_00b111c0 */

undefined4 * __thiscall
FUN_00b111c0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined4 uStack_5c;
  int iStack_58;
  undefined4 uStack_44;
  undefined *puStack_40;
  undefined4 uStack_34;
  int iStack_30;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017edea0;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_34;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_4 + 8) = *(int *)(param_4 + 8) + 1;
    UNLOCK();
  }
  uStack_34 = param_3;
  iStack_30 = param_4;
  puStack_40 = &stack0x00000010;
  uStack_8 = 1;
  uStack_7 = 0;
  uStack_44 = 0xb11229;
  FUN_0054ef60();
  *param_1 = 0;
  puStack_14 = &uStack_5c;
  if (iStack_30 != 0) {
    LOCK();
    *(int *)(iStack_30 + 8) = *(int *)(iStack_30 + 8) + 1;
    UNLOCK();
  }
  uStack_5c = uStack_34;
  iStack_58 = iStack_30;
  uStack_8 = 3;
  FUN_0054ef60(auStack_2c);
  _uStack_8 = CONCAT31(uStack_7,2);
  FUN_00b12fa0();
  puStack_40 = (undefined *)0xb11288;
  FUN_005d11a0();
  puStack_40 = (undefined *)0xb11290;
  FUN_005d11a0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23326 ; VA 0x00b112b0 ; FUN_00b112b0 */

undefined4 * __thiscall
FUN_00b112b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  FUN_00b13160(param_2,param_3,param_4);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 23327 ; VA 0x00b11340 ; FUN_00b11340 */

undefined4 * __thiscall
FUN_00b11340(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  *param_1 = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_01951ba8;
  cVar3 = FUN_00ae2a30(param_2,param_3,param_4,param_5,param_6,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 23328 ; VA 0x00b11460 ; FUN_00b11460 */

undefined4 * __thiscall
FUN_00b11460(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6,int *param_7,undefined4 param_8,int *param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uVar5;
  undefined auStack_6c [4];
  int *piStack_68;
  int *piStack_60;
  int *piStack_58;
  undefined4 uStack_4c;
  undefined4 uStack_44;
  undefined auStack_3c [4];
  int *piStack_38;
  int *piStack_30;
  int *piStack_28;
  undefined4 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017edec8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00b17f60(&param_4);
  uStack_4c = param_12;
  uStack_44 = param_2;
  *param_1 = 0;
  FUN_00b17f60(auStack_6c);
  uStack_1c = uStack_4c;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar5 = uStack_44;
  FUN_00b17f60(auStack_3c);
  ppuVar4 = &PTR_FUN_01951be4;
  cVar3 = FUN_00b13270(uVar5);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_28[2] + -1;
    piStack_28[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_28 + 4))();
    }
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_30[2] + -1;
    piStack_30[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_30 + 4))();
    }
  }
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_38[2] + -1;
    piStack_38[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_38 + 4))();
    }
  }
  if (piStack_58 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_58[2] + -1;
    piStack_58[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_58 + 4))();
    }
  }
  if (piStack_60 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_60[2] + -1;
    piStack_60[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_60 + 4))();
    }
  }
  if (piStack_68 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_68[2] + -1;
    piStack_68[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_68 + 4))();
    }
  }
  if (param_9 != (int *)0x0) {
    LOCK();
    iVar2 = param_9[2] + -1;
    param_9[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_9 + 4))();
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[2] + -1;
    param_7[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_7 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_5 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23329 ; VA 0x00b115d0 ; FUN_00b115d0 */

undefined4 * __thiscall
FUN_00b115d0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6,int *param_7,undefined4 param_8,int *param_9)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uVar5;
  undefined auStack_5c [4];
  int *piStack_58;
  int *piStack_50;
  int *piStack_48;
  undefined4 uStack_3c;
  undefined auStack_34 [4];
  int *piStack_30;
  int *piStack_28;
  int *piStack_20;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017edef8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00b17f60(&param_4);
  uStack_3c = param_2;
  *param_1 = 0;
  FUN_00b17f60(auStack_5c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar5 = uStack_3c;
  FUN_00b17f60(auStack_34);
  ppuVar4 = &PTR_FUN_01951bec;
  cVar3 = FUN_00b13430(uVar5);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_20[2] + -1;
    piStack_20[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_20 + 4))();
    }
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_28[2] + -1;
    piStack_28[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_28 + 4))();
    }
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_30[2] + -1;
    piStack_30[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_30 + 4))();
    }
  }
  if (piStack_48 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_48[2] + -1;
    piStack_48[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_48 + 4))();
    }
  }
  if (piStack_50 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_50[2] + -1;
    piStack_50[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_50 + 4))();
    }
  }
  if (piStack_58 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_58[2] + -1;
    piStack_58[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_58 + 4))();
    }
  }
  if (param_9 != (int *)0x0) {
    LOCK();
    iVar2 = param_9[2] + -1;
    param_9[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_9 + 4))();
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[2] + -1;
    param_7[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_7 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_5 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23330 ; VA 0x00b11730 ; FUN_00b11730 */

undefined4 * __thiscall
FUN_00b11730(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,int *param_6,undefined4 param_7,uint param_8)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_9c;
  undefined *puStack_98;
  undefined *puStack_94;
  undefined4 *puStack_90;
  undefined auStack_7c [8];
  int *piStack_74;
  uint uStack_6c;
  undefined auStack_64 [24];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined auStack_44 [8];
  int *piStack_3c;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017edf28;
  pvStack_10 = ExceptionList;
  puStack_90 = &param_4;
  uStack_8 = 0;
  puStack_94 = (undefined *)0xb11771;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00b16760();
  uStack_4c = param_2;
  uStack_48 = param_3;
  puStack_90 = (undefined4 *)auStack_7c;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  puStack_94 = (undefined *)0xb11793;
  FUN_00b16760();
  puStack_90 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = &uStack_c8;
  uStack_c8 = uStack_4c;
  uStack_c4 = uStack_48;
  FUN_00b16760(auStack_44);
  ppuVar4 = &PTR_FUN_01951b80;
  cVar3 = FUN_00b135e0();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      puStack_98 = auStack_2c;
      puStack_90 = (undefined4 *)0x2;
      uStack_9c = 0xb117f0;
      puStack_94 = puStack_98;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_3c[2] + -1;
    piStack_3c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_90 = (undefined4 *)0xb11812;
      (**(code **)(*piStack_3c + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_6c != 0) {
    if (((uStack_6c & 1) == 0) && (*(code **)(uStack_6c & 0xfffffffe) != (code *)0x0)) {
      puStack_98 = auStack_64;
      puStack_90 = (undefined4 *)0x2;
      uStack_9c = 0xb11833;
      puStack_94 = puStack_98;
      (**(code **)(uStack_6c & 0xfffffffe))();
    }
    uStack_6c = 0;
  }
  if (piStack_74 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_74[2] + -1;
    piStack_74[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_90 = (undefined4 *)0xb11852;
      (**(code **)(*piStack_74 + 4))();
    }
  }
  uStack_8 = 5;
  if (param_8 != 0) {
    if (((param_8 & 1) == 0) && (*(code **)(param_8 & 0xfffffffe) != (code *)0x0)) {
      puStack_98 = &stack0x00000024;
      puStack_90 = (undefined4 *)0x2;
      uStack_9c = 0xb11876;
      puStack_94 = puStack_98;
      (**(code **)(param_8 & 0xfffffffe))();
    }
    param_8 = 0;
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_90 = (undefined4 *)0xb11894;
      (**(code **)(*param_6 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23331 ; VA 0x00b118b0 ; FUN_00b118b0 */

undefined4 * __thiscall
FUN_00b118b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 *puStack_8;
  
  uStack_48 = param_2;
  uStack_44 = param_3;
  uStack_40 = param_4;
  uStack_3c = param_5;
  *param_1 = 0;
  uStack_38 = param_6;
  uStack_34 = param_7;
  uStack_30 = param_8;
  uStack_2c = param_9;
  puStack_8 = param_1;
  cVar1 = FUN_00585a40(&uStack_48);
  if (cVar1 != '\0') {
    *param_1 = 0;
    return param_1;
  }
  uStack_18 = uStack_48;
  uStack_14 = uStack_44;
  uStack_10 = uStack_40;
  uStack_c = uStack_3c;
  uStack_28 = uStack_38;
  uStack_24 = uStack_34;
  uStack_20 = uStack_30;
  uStack_1c = uStack_2c;
  puVar2 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar2 != (undefined4 *)0x0) {
    *puVar2 = uStack_18;
    puVar2[1] = uStack_14;
    puVar2[2] = uStack_10;
    puVar2[3] = uStack_c;
    puVar2[4] = uStack_28;
    puVar2[5] = uStack_24;
    puVar2[6] = uStack_20;
    puVar2[7] = uStack_1c;
    param_1[2] = puVar2;
    *param_1 = &PTR_FUN_01951b90;
    return param_1;
  }
  *param_1 = &PTR_FUN_01951b90;
  param_1[2] = 0;
  return param_1;
}



/* FUNCTION 23332 ; VA 0x00b11950 ; FUN_00b11950 */

int * __thiscall FUN_00b11950(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00b31a50();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 23333 ; VA 0x00b119a0 ; FUN_00b119a0 */

int * __thiscall FUN_00b119a0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00b31ac0();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 23334 ; VA 0x00b119f0 ; FUN_00b119f0 */

int * __thiscall FUN_00b119f0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00b31b30();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 23335 ; VA 0x00b11a40 ; FUN_00b11a40 */

int * __thiscall FUN_00b11a40(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00b31ba0();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 23336 ; VA 0x00b11a90 ; FUN_00b11a90 */

void __thiscall
FUN_00b11a90(undefined4 *param_1,undefined4 param_2,undefined4 *param_3,int *param_4)

{
  int *piVar1;
  code *pcVar2;
  uint *puVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  uint uStack_54;
  uint uStack_50;
  uint uStack_4c;
  uint *puStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017edf48;
  pvStack_10 = ExceptionList;
  pcVar2 = (code *)*param_3;
  puVar3 = (uint *)param_4[2];
  uStack_3c = 0;
  uVar4 = *puVar3;
  ExceptionList = &pvStack_10;
  if (uVar4 != 0) {
    uStack_3c = uVar4;
    if ((uVar4 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = puVar3 + 2;
      uStack_4c = 0xb11afe;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar4 & 0xfffffffe))();
    }
    else {
      uStack_34 = puVar3[2];
      uStack_30 = puVar3[3];
      uStack_2c = puVar3[4];
      uStack_28 = puVar3[5];
      uStack_24 = *(undefined8 *)(puVar3 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  puVar3 = (uint *)param_4[1];
  uStack_8 = 0;
  uVar4 = *puVar3;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      (**(code **)(uVar4 & 0xfffffffe))(puVar3 + 2,&uStack_54,0);
    }
    else {
      uStack_54 = puVar3[2];
      uStack_50 = puVar3[3];
      uStack_4c = puVar3[4];
      puStack_48 = (uint *)puVar3[5];
      uStack_44 = *(ulonglong *)(puVar3 + 6);
    }
  }
  puVar5 = (undefined4 *)*param_4;
  if (puVar5[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar6 = *puVar5;
  uVar7 = puVar5[1];
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  (*pcVar2)(*param_1,param_1[1],uVar6,uVar7);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23337 ; VA 0x00b11bc0 ; FUN_00b11bc0 */

void __thiscall
FUN_00b11bc0(undefined4 *param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 *puStack_5c;
  ulonglong uStack_58;
  uint uStack_50;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017edf48;
  pvStack_10 = ExceptionList;
  pcVar2 = (code *)*param_3;
  uStack_24 = param_1[0x15];
  uStack_28 = param_1[0x14];
  uStack_2c = param_1[0x13];
  uVar3 = *(undefined4 *)param_4[1];
  uStack_30 = param_1[0x12];
  uVar4 = *(undefined4 *)*param_4;
  uStack_50 = 0;
  uVar5 = param_1[10];
  ExceptionList = &pvStack_10;
  if (uVar5 != 0) {
    uStack_50 = uVar5;
    if ((uVar5 & 1) == 0) {
      uStack_58 = ZEXT48(&uStack_48);
      puStack_5c = param_1 + 0xc;
      uStack_60 = 0xb11c46;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar5 & 0xfffffffe))();
    }
    else {
      uStack_48 = param_1[0xc];
      uStack_44 = param_1[0xd];
      uStack_40 = param_1[0xe];
      uStack_3c = param_1[0xf];
      uStack_38 = *(undefined8 *)(param_1 + 0x10);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uVar5 = param_1[2];
  if (uVar5 != 0) {
    if ((uVar5 & 1) == 0) {
      (**(code **)(uVar5 & 0xfffffffe))(param_1 + 4,&uStack_68,0);
    }
    else {
      uStack_68 = param_1[4];
      uStack_64 = param_1[5];
      uStack_60 = param_1[6];
      puStack_5c = (undefined4 *)param_1[7];
      uStack_58 = *(ulonglong *)(param_1 + 8);
    }
  }
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  (*pcVar2)(*param_1,param_1[1],uVar4,uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23338 ; VA 0x00b11ce0 ; FUN_00b11ce0 */

void __thiscall
FUN_00b11ce0(undefined4 *param_1,undefined4 param_2,undefined4 *param_3,int *param_4)

{
  int *piVar1;
  undefined uVar2;
  code *pcVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  
  pcVar3 = (code *)*param_3;
  uVar4 = param_1[4];
  uVar2 = *(undefined *)(param_1 + 6);
  uVar5 = param_1[5];
  uVar6 = param_1[8];
  if (uVar6 != 0) {
    if ((uVar6 & 1) == 0) {
      (**(code **)(uVar6 & 0xfffffffe))(param_1 + 10,&uStack_30,0);
    }
    else {
      uStack_30 = param_1[10];
      uStack_2c = param_1[0xb];
      uStack_28 = param_1[0xc];
      uStack_24 = param_1[0xd];
      uStack_20 = *(undefined8 *)(param_1 + 0xe);
    }
  }
  puVar7 = (undefined4 *)*param_4;
  if (puVar7[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar7[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar8 = *puVar7;
  uVar9 = puVar7[1];
  if (param_1[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar10 = param_1[2];
  uVar11 = param_1[3];
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar3)(*param_1,param_1[1],uVar10,uVar11,uVar4,uVar5,uVar2,uVar8,uVar9);
  return;
}



/* FUNCTION 23339 ; VA 0x00b11de0 ; FUN_00b11de0 */

void FUN_00b11de0(undefined4 param_1,undefined4 *param_2,int *param_3)

{
  int *piVar1;
  code *pcVar2;
  uint uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017edf70;
  pvStack_10 = ExceptionList;
  pcVar2 = (code *)*param_2;
  uVar3 = *(uint *)param_3[2];
  ExceptionList = &pvStack_10;
  if ((uVar3 != 0) && (ExceptionList = &pvStack_10, (uVar3 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(uVar3 & 0xfffffffe))();
  }
  uStack_8 = 0;
  uVar3 = *(uint *)param_3[1];
  if ((uVar3 != 0) && ((uVar3 & 1) == 0)) {
    (**(code **)(uVar3 & 0xfffffffe))();
  }
  iVar4 = *param_3;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_008881d0();
  if (*(int *)(iVar4 + 4) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar4 + 4) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_0058c000();
  uStack_8 = 0xffffffff;
  (*pcVar2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23340 ; VA 0x00b11f10 ; FUN_00b11f10 */

void __thiscall
FUN_00b11f10(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  int *piVar1;
  undefined4 uVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017edfa0;
  pvStack_10 = ExceptionList;
  uVar2 = *param_1;
  uVar3 = param_1[0x12];
  ExceptionList = &pvStack_10;
  if ((uVar3 != 0) && (ExceptionList = &pvStack_10, (uVar3 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(uVar3 & 0xfffffffe))();
  }
  uStack_8 = 0;
  uVar3 = param_1[10];
  if ((uVar3 != 0) && ((uVar3 & 1) == 0)) {
    (**(code **)(uVar3 & 0xfffffffe))();
  }
  if (param_1[8] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[8] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 2;
  FUN_0054ef60(*param_4);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0054ef60(param_1 + 1);
  uStack_8 = 0xffffffff;
  FUN_00b1b540(uVar2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23341 ; VA 0x00b12040 ; FUN_00b12040 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b12040(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017edfd0;
  pvStack_10 = ExceptionList;
  if (DAT_01eee1c0 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee3d8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eee3d8);
      if (DAT_01eee3d8 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"MarketplaceService",1,uStack_20,0,0,3,0,0);
        _DAT_01eee3d0 = RBX::Creator<class_RBX::MarketplaceService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01eee1c8,&DAT_01eee3d0);
        FUN_016f3654(FUN_0188da50);
        FUN_016f37bf(&DAT_01eee3d8);
      }
    }
    DAT_01eee1c0 = &DAT_01eee1c8;
  }
  ExceptionList = pvStack_10;
  return DAT_01eee1c0;
}



/* FUNCTION 23342 ; VA 0x00b12140 ; FUN_00b12140 */

void FUN_00b12140(void)

{
  int iVar1;
  
  if (DAT_01eee3dc == 0) {
    iVar1 = FUN_00b12040();
    DAT_01eee3dc = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 23343 ; VA 0x00b12160 ; FUN_00b12160 */

int * __thiscall FUN_00b12160(int *param_1,undefined4 param_2)

{
  undefined *puVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  undefined4 *puVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  undefined4 uVar9;
  undefined auStack_48 [12];
  int *piStack_3c;
  int *piStack_38;
  char cStack_34;
  int *piStack_28;
  uint uStack_24;
  int *piStack_20;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ee017;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff78;
  uStack_24 = 0;
  piVar6 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  ExceptionList = &pvStack_10;
  piStack_38 = param_1;
  piStack_20 = param_1;
  puVar1 = &stack0xffffff78;
  if (piVar6 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*piVar6 + 4))();
    puVar1 = puStack_14;
  }
  puStack_14 = puVar1;
  uVar9 = 0;
  uStack_8 = 0;
  cStack_34 = FUN_00593b40(0);
  if (cStack_34 == '\0') goto LAB_00b12359;
  piVar6 = *(int **)(*(int *)(*(int *)(*param_1 + 4) + 0x30 + (int)param_1) + 4);
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  piStack_3c = piVar6;
  (**(code **)(*piVar6 + 4))();
  uStack_8._0_1_ = 4;
  FUN_016dda75(0);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  piStack_28 = DAT_01eeae50;
  uStack_18 = DAT_01eeae4c;
  if (DAT_01eeae4c == 0) {
    FUN_016dda75(0);
    if (DAT_01eeae4c == 0) {
      DAT_01eeae4c = DAT_021130c8 + 1;
      DAT_021130c8 = DAT_01eeae4c;
    }
    FUN_016ddacd();
  }
  uStack_18 = DAT_01eeae4c;
  if (DAT_01eeae4c < (uint)piVar6[3]) {
    piVar3 = *(int **)(piVar6[2] + DAT_01eeae4c * 4);
    if (piVar3 == (int *)0x0) goto LAB_00b1224f;
  }
  else {
    piVar3 = (int *)0x0;
LAB_00b1224f:
    if (*(char *)(piVar6 + 5) == '\0') {
LAB_00b12268:
      if (piVar3 != (int *)0x0) goto LAB_00b122d7;
    }
    else {
      iVar2 = FUN_016de17b();
      if (uStack_18 < *(uint *)(iVar2 + 0xc)) {
        piVar3 = *(int **)(*(int *)(iVar2 + 8) + uStack_18 * 4);
        goto LAB_00b12268;
      }
    }
    piVar3 = piStack_28;
    if (piStack_28 == (int *)0x0) {
      piVar3 = (int *)FUN_01674e20(8);
      uStack_8._0_1_ = 6;
      if (piVar3 == (int *)0x0) {
        piVar3 = (int *)0x0;
      }
      else {
        piVar4 = (int *)piVar6[6];
        if (piVar4 == (int *)0x0) {
          piVar4 = piVar6 + 7;
        }
        piStack_28 = piVar3;
        FUN_0054f870(piVar4);
        piVar3[1] = 0;
        *piVar3 = (int)std::
                       num_get<char,class_std::istreambuf_iterator<char,struct_std::char_traits<char>_>_>
                       ::vftable;
        FUN_00550e70();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      piStack_28 = piVar3;
      FUN_016de14f(piVar3);
      (**(code **)(*piVar3 + 4))();
      DAT_01eeae50 = piVar3;
    }
  }
LAB_00b122d7:
  uStack_8._0_1_ = 4;
  FUN_016ddacd();
  piStack_28 = (int *)CONCAT22(piStack_28._2_2_,1);
  iVar2 = *(int *)(*param_1 + 4) + (int)param_1;
  uStack_18 = CONCAT31((int3)(uStack_18 >> 8),*(int *)(iVar2 + 0x38) == 0) & 0xffff00ff;
  (**(code **)(*piVar3 + 0x34))
            (auStack_48,*(undefined4 *)(iVar2 + 0x38),uStack_18,0,piStack_28,iVar2,&uStack_24,
             param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  puVar5 = (undefined4 *)(**(code **)(*piVar6 + 8))();
  if (puVar5 != (undefined4 *)0x0) {
    (**(code **)*puVar5)(1);
    piVar6 = (int *)FUN_00b12352(uVar9);
    return piVar6;
  }
LAB_00b12359:
  uStack_8 = 1;
  uVar8 = *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc) | uStack_24;
  uVar7 = uVar8 | 4;
  if (*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) != 0) {
    uVar7 = uVar8;
  }
  FUN_00554460(uVar7,0);
  uStack_8 = 10;
  piVar6 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  if (piVar6 != (int *)0x0) {
    (**(code **)(*piVar6 + 8))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23344 ; VA 0x00b12336 ; Catch_All@00b12336 */

undefined * Catch_All_00b12336(void)

{
  FUN_005565b0(4,1);
  return &DAT_00b1234f;
}



/* FUNCTION 23345 ; VA 0x00b12352 ; FUN_00b12352 */

void FUN_00b12352(void)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  uint uVar4;
  int unaff_EBP;
  int *unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  uVar4 = *(uint *)((int)unaff_EDI + *(int *)(*unaff_EDI + 4) + 0xc) | *(uint *)(unaff_EBP + -0x20);
  uVar3 = uVar4 | 4;
  if (*(int *)((int)unaff_EDI + *(int *)(*unaff_EDI + 4) + 0x38) != 0) {
    uVar3 = uVar4;
  }
  FUN_00554460(uVar3,0);
  iVar1 = *unaff_EDI;
  *(undefined4 *)(unaff_EBP + -4) = 10;
  piVar2 = *(int **)(*(int *)(iVar1 + 4) + 0x38 + (int)unaff_EDI);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 8))();
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 23346 ; VA 0x00b123b0 ; FUN_00b123b0 */

void __thiscall FUN_00b123b0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee030;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::MarketplaceApiClient>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23347 ; VA 0x00b1241e ; Catch_All@00b1241e */

void Catch_All_00b1241e(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 23348 ; VA 0x00b12440 ; FUN_00b12440 */

int __thiscall FUN_00b12440(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee040;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::StandardPages*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 23349 ; VA 0x00b12512 ; Catch_All@00b12512 */

void Catch_All_00b12512(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 23350 ; VA 0x00b12530 ; FUN_00b12530 */

void __thiscall
FUN_00b12530(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_c = param_6;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_24 = param_3;
  uStack_18 = param_6;
  uStack_28 = param_2;
  uStack_20 = param_4;
  uStack_1c = param_5;
  cVar3 = FUN_00585a40(&uStack_28);
  if (cVar3 == '\0') {
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[2] = piStack_24[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_1c;
    uStack_10 = uStack_18;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[2] = piStack_24[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_28;
    param_1[3] = piStack_24;
    param_1[4] = uStack_20;
    param_1[5] = uStack_1c;
    param_1[6] = uStack_18;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[2] + -1;
      piStack_24[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[2] + -1;
      piStack_24[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[2] + -1;
      piStack_24[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01951bfc;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 23351 ; VA 0x00b12660 ; FUN_00b12660 */

undefined FUN_00b12660(void)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 extraout_ECX;
  undefined uVar5;
  int *in_stack_00000014;
  int *in_stack_0000001c;
  int *in_stack_00000024;
  undefined4 *in_stack_0000002c;
  undefined auStack_60 [16];
  int *piStack_50;
  int *piStack_48;
  int *piStack_40;
  undefined auStack_38 [16];
  int *piStack_28;
  int *piStack_20;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee068;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00b157d0(&stack0x00000004);
  uStack_8._0_1_ = 1;
  cVar2 = FUN_00585a40(extraout_ECX);
  if (cVar2 == '\0') {
    FUN_00b157d0(auStack_38);
    uStack_8._0_1_ = 2;
    iVar3 = FUN_01674e20(0x28);
    if (iVar3 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_00b157d0(auStack_60);
    }
    *in_stack_0000002c = uVar4;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_40[2] + -1;
      piStack_40[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_40 + 4))();
      }
    }
    if (piStack_48 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_48[2] + -1;
      piStack_48[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_48 + 4))();
      }
    }
    if (piStack_50 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_50[2] + -1;
      piStack_50[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_50 + 4))();
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_20[2] + -1;
      piStack_20[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_28[2] + -1;
      piStack_28[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
    uVar5 = 1;
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_20[2] + -1;
      piStack_20[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_28[2] + -1;
      piStack_28[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
    uVar5 = 0;
  }
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar3 = in_stack_00000024[2] + -1;
    in_stack_00000024[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*in_stack_00000024 + 4))();
    }
  }
  if (in_stack_0000001c != (int *)0x0) {
    LOCK();
    iVar3 = in_stack_0000001c[2] + -1;
    in_stack_0000001c[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*in_stack_0000001c + 4))();
    }
  }
  if (in_stack_00000014 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000014 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*in_stack_00000014 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 23352 ; VA 0x00b12800 ; FUN_00b12800 */

void __thiscall FUN_00b12800(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 uStack_98;
  int iStack_94;
  undefined auStack_90 [24];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  int iStack_68;
  undefined auStack_64 [24];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  int iStack_3c;
  undefined auStack_38 [24];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017ee0d5;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_98;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_4 + 4) = *(int *)(param_4 + 4) + 1;
    UNLOCK();
  }
  uStack_98 = param_3;
  iStack_94 = param_4;
  uStack_8 = 1;
  uStack_7 = 0;
  puStack_18 = param_1;
  FUN_0054ef60(&stack0x00000010);
  uStack_78 = in_stack_00000028;
  uStack_74 = in_stack_0000002c;
  uStack_44 = param_2;
  puStack_14 = &uStack_40;
  if (iStack_94 != 0) {
    LOCK();
    *(int *)(iStack_94 + 4) = *(int *)(iStack_94 + 4) + 1;
    UNLOCK();
  }
  uStack_40 = uStack_98;
  iStack_3c = iStack_94;
  uStack_8 = 3;
  FUN_0054ef60(auStack_90);
  uStack_20 = uStack_78;
  uStack_1c = uStack_74;
  uStack_8 = 4;
  cVar2 = FUN_00585a40(&uStack_44);
  if (cVar2 == '\0') {
    uStack_70 = uStack_44;
    puStack_14 = &uStack_6c;
    if (iStack_3c != 0) {
      LOCK();
      *(int *)(iStack_3c + 4) = *(int *)(iStack_3c + 4) + 1;
      UNLOCK();
    }
    uStack_6c = uStack_40;
    iStack_68 = iStack_3c;
    uStack_8 = 5;
    FUN_0054ef60(auStack_38);
    uStack_4c = uStack_20;
    uStack_48 = uStack_1c;
    uStack_8 = 6;
    puVar3 = (undefined4 *)FUN_01674e20(0x2c);
    uStack_8 = 7;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uStack_70;
      puVar3[1] = 0;
      puVar3[2] = 0;
      if (iStack_68 != 0) {
        LOCK();
        *(int *)(iStack_68 + 4) = *(int *)(iStack_68 + 4) + 1;
        UNLOCK();
      }
      puVar3[1] = uStack_6c;
      puVar3[2] = iStack_68;
      uStack_8 = 8;
      FUN_0054ef60(auStack_64);
      puVar3[9] = uStack_4c;
      puVar3[10] = uStack_48;
    }
    param_1[2] = puVar3;
    FUN_006511a0();
    FUN_006511a0();
    bVar1 = true;
  }
  else {
    FUN_006511a0();
    bVar1 = false;
  }
  FUN_006511a0();
  ppuVar4 = &PTR_FUN_01951bb0;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *puStack_18 = ppuVar4;
  FUN_006511a0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23353 ; VA 0x00b12a20 ; FUN_00b12a20 */

undefined FUN_00b12a20(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined uVar6;
  undefined4 in_stack_0000001c;
  undefined in_stack_00000020;
  int *in_stack_00000024;
  undefined4 uStack_54;
  int *piStack_50;
  undefined auStack_4c [12];
  undefined4 uStack_40;
  undefined uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  undefined auStack_2c [12];
  undefined4 uStack_20;
  undefined uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee11f;
  pvStack_10 = ExceptionList;
  uStack_38 = param_1;
  puStack_14 = &uStack_34;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_34 = param_2;
  piStack_30 = param_3;
  uStack_8 = 1;
  FUN_006d07c0(&stack0x00000010);
  uStack_20 = in_stack_0000001c;
  uStack_1c = in_stack_00000020;
  cVar4 = FUN_00585a40(&uStack_38);
  uVar3 = uStack_38;
  if (cVar4 == '\0') {
    puStack_14 = &uStack_54;
    if (piStack_30 != (int *)0x0) {
      LOCK();
      piStack_30[2] = piStack_30[2] + 1;
      UNLOCK();
    }
    uStack_54 = uStack_34;
    piStack_50 = piStack_30;
    uStack_8._0_1_ = 3;
    FUN_006d07c0(auStack_2c);
    uStack_40 = uStack_20;
    uStack_3c = uStack_1c;
    uStack_8._0_1_ = 4;
    puVar5 = (undefined4 *)FUN_01674e20(0x20);
    puStack_14 = puVar5;
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      puStack_18 = puVar5 + 1;
      *puVar5 = uVar3;
      *puStack_18 = 0;
      puVar5[2] = 0;
      if (piStack_50 != (int *)0x0) {
        LOCK();
        piStack_50[2] = piStack_50[2] + 1;
        UNLOCK();
      }
      *puStack_18 = uStack_54;
      puVar5[2] = piStack_50;
      uStack_8._0_1_ = 6;
      FUN_006d07c0(auStack_4c);
      puVar5[6] = uStack_40;
      *(undefined *)(puVar5 + 7) = uStack_3c;
    }
    *in_stack_00000024 = (int)puVar5;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_00577b20();
    if (piStack_50 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_50[2] + -1;
      piStack_50[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_50 + 4))();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    FUN_00577b20();
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_30[2] + -1;
      piStack_30[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
    uVar6 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    FUN_00577b20();
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_30[2] + -1;
      piStack_30[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
    uVar6 = 0;
  }
  uStack_8 = 10;
  FUN_00577b20();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 23354 ; VA 0x00b12c10 ; FUN_00b12c10 */

undefined FUN_00b12c10(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined uVar6;
  undefined4 in_stack_0000001c;
  undefined in_stack_00000020;
  int *in_stack_00000024;
  undefined4 uStack_54;
  int *piStack_50;
  undefined auStack_4c [12];
  undefined4 uStack_40;
  undefined uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  undefined auStack_2c [12];
  undefined4 uStack_20;
  undefined uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee16f;
  pvStack_10 = ExceptionList;
  uStack_38 = param_1;
  puStack_14 = &uStack_34;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_34 = param_2;
  piStack_30 = param_3;
  uStack_8 = 1;
  FUN_006d07c0(&stack0x00000010);
  uStack_20 = in_stack_0000001c;
  uStack_1c = in_stack_00000020;
  cVar4 = FUN_00585a40(&uStack_38);
  uVar3 = uStack_38;
  if (cVar4 == '\0') {
    puStack_14 = &uStack_54;
    if (piStack_30 != (int *)0x0) {
      LOCK();
      piStack_30[2] = piStack_30[2] + 1;
      UNLOCK();
    }
    uStack_54 = uStack_34;
    piStack_50 = piStack_30;
    uStack_8._0_1_ = 3;
    FUN_006d07c0(auStack_2c);
    uStack_40 = uStack_20;
    uStack_3c = uStack_1c;
    uStack_8._0_1_ = 4;
    puVar5 = (undefined4 *)FUN_01674e20(0x20);
    puStack_14 = puVar5;
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      puStack_18 = puVar5 + 1;
      *puVar5 = uVar3;
      *puStack_18 = 0;
      puVar5[2] = 0;
      if (piStack_50 != (int *)0x0) {
        LOCK();
        piStack_50[2] = piStack_50[2] + 1;
        UNLOCK();
      }
      *puStack_18 = uStack_54;
      puVar5[2] = piStack_50;
      uStack_8._0_1_ = 6;
      FUN_006d07c0(auStack_4c);
      puVar5[6] = uStack_40;
      *(undefined *)(puVar5 + 7) = uStack_3c;
    }
    *in_stack_00000024 = (int)puVar5;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_00577b20();
    if (piStack_50 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_50[2] + -1;
      piStack_50[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_50 + 4))();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    FUN_00577b20();
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_30[2] + -1;
      piStack_30[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
    uVar6 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    FUN_00577b20();
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_30[2] + -1;
      piStack_30[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
    uVar6 = 0;
  }
  uStack_8 = 10;
  FUN_00577b20();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 23355 ; VA 0x00b12e00 ; FUN_00b12e00 */

undefined FUN_00b12e00(undefined4 param_1)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined uVar4;
  uint in_stack_00000034;
  int *in_stack_00000064;
  undefined auStack_cc [40];
  uint uStack_a4;
  undefined auStack_9c [40];
  undefined4 auStack_74 [2];
  undefined auStack_6c [40];
  uint uStack_44;
  undefined auStack_3c [40];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee1aa;
  pvStack_10 = ExceptionList;
  auStack_74[0] = param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00b17130(&stack0x0000000c);
  uStack_8._0_1_ = 1;
  cVar2 = FUN_00585a40(auStack_74);
  uVar1 = auStack_74[0];
  if (cVar2 == '\0') {
    FUN_00b17130(auStack_6c);
    uStack_8._0_1_ = 2;
    puVar3 = (undefined4 *)FUN_01674e20(0x60);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uVar1;
      FUN_00b17130(auStack_cc);
    }
    *in_stack_00000064 = (int)puVar3;
    uStack_8._0_1_ = 4;
    if (uStack_a4 != 0) {
      if (((uStack_a4 & 1) == 0) && (*(code **)(uStack_a4 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_a4 & 0xfffffffe))(auStack_9c,auStack_9c,2);
      }
      uStack_a4 = 0;
    }
    FUN_00a7c840();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_44 != 0) {
      if (((uStack_44 & 1) == 0) && (*(code **)(uStack_44 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_44 & 0xfffffffe))(auStack_3c,auStack_3c,2);
      }
      uStack_44 = 0;
    }
    FUN_00a7c840();
    uVar4 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_44 != 0) {
      if (((uStack_44 & 1) == 0) && (*(code **)(uStack_44 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_44 & 0xfffffffe))(auStack_3c,auStack_3c,2);
      }
      uStack_44 = 0;
    }
    FUN_00a7c840();
    uVar4 = 0;
  }
  uStack_8 = 7;
  if (in_stack_00000034 != 0) {
    if (((in_stack_00000034 & 1) == 0) &&
       (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000034 & 0xfffffffe))(&stack0x0000003c,&stack0x0000003c,2);
    }
    in_stack_00000034 = 0;
  }
  FUN_00a7c840();
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 23356 ; VA 0x00b12fa0 ; FUN_00b12fa0 */

void __thiscall FUN_00b12fa0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined4 uStack_80;
  int iStack_7c;
  undefined auStack_78 [24];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  int iStack_58;
  undefined auStack_54 [24];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int iStack_34;
  undefined auStack_30 [24];
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017ee20f;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_80;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_4 + 8) = *(int *)(param_4 + 8) + 1;
    UNLOCK();
  }
  uStack_80 = param_3;
  iStack_7c = param_4;
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_0054ef60(&stack0x00000010);
  uStack_3c = param_2;
  puStack_14 = &uStack_38;
  if (iStack_7c != 0) {
    LOCK();
    *(int *)(iStack_7c + 8) = *(int *)(iStack_7c + 8) + 1;
    UNLOCK();
  }
  uStack_38 = uStack_80;
  iStack_34 = iStack_7c;
  uStack_8 = 3;
  FUN_0054ef60(auStack_78);
  uStack_8 = 4;
  cVar2 = FUN_00585a40(&uStack_3c);
  if (cVar2 == '\0') {
    uStack_60 = uStack_3c;
    puStack_14 = &uStack_5c;
    if (iStack_34 != 0) {
      LOCK();
      *(int *)(iStack_34 + 8) = *(int *)(iStack_34 + 8) + 1;
      UNLOCK();
    }
    uStack_5c = uStack_38;
    iStack_58 = iStack_34;
    uStack_8 = 5;
    FUN_0054ef60(auStack_30);
    uStack_8 = 6;
    puVar3 = (undefined4 *)FUN_01674e20(0x24);
    uStack_8 = 7;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uStack_60;
      puStack_18 = puVar3 + 1;
      *puStack_18 = 0;
      puVar3[2] = 0;
      if (iStack_58 != 0) {
        LOCK();
        *(int *)(iStack_58 + 8) = *(int *)(iStack_58 + 8) + 1;
        UNLOCK();
      }
      *puStack_18 = uStack_5c;
      puVar3[2] = iStack_58;
      uStack_8 = 8;
      FUN_0054ef60(auStack_54);
    }
    param_1[2] = puVar3;
    FUN_005d11a0();
    FUN_005d11a0();
    bVar1 = true;
  }
  else {
    FUN_005d11a0();
    bVar1 = false;
  }
  FUN_005d11a0();
  ppuVar4 = &PTR_FUN_01951bb8;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_005d11a0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23357 ; VA 0x00b13160 ; FUN_00b13160 */

void __thiscall FUN_00b13160(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  char cVar4;
  undefined **ppuVar5;
  undefined4 uStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 *puStack_8;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  piStack_c = param_4;
  uStack_10 = param_3;
  puStack_8 = param_1;
  cVar4 = FUN_00585a40(&uStack_14);
  if (cVar4 == '\0') {
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[2] = piStack_c[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = 0;
    param_1[4] = 0;
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[2] = piStack_c[2] + 1;
      UNLOCK();
    }
    param_1[3] = uStack_10;
    param_1[4] = piStack_c;
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    bVar3 = true;
  }
  else {
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    bVar3 = false;
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  ppuVar5 = &PTR_FUN_01951ba0;
  if (!bVar3) {
    ppuVar5 = (undefined **)0x0;
  }
  *puStack_8 = ppuVar5;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return;
}



/* FUNCTION 23358 ; VA 0x00b13270 ; FUN_00b13270 */

undefined FUN_00b13270(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,
                      undefined4 param_5,int *param_6,undefined4 param_7,int *param_8,
                      undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12
                      ,int *param_13)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined uVar6;
  undefined auStack_68 [4];
  int *piStack_64;
  int *piStack_5c;
  int *piStack_54;
  undefined4 uStack_48;
  undefined4 auStack_40 [2];
  undefined auStack_38 [4];
  int *piStack_34;
  int *piStack_2c;
  int *piStack_24;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee238;
  pvStack_10 = ExceptionList;
  auStack_40[0] = param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00b17f60(&param_3);
  uStack_18 = param_11;
  uStack_8._0_1_ = 1;
  cVar4 = FUN_00585a40(auStack_40);
  uVar3 = auStack_40[0];
  if (cVar4 == '\0') {
    FUN_00b17f60(auStack_38);
    uStack_48 = uStack_18;
    uStack_8._0_1_ = 2;
    puVar5 = (undefined4 *)FUN_01674e20(0x30);
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      *puVar5 = uVar3;
      FUN_00b17f60(auStack_68);
      puVar5[10] = uStack_48;
    }
    *param_13 = (int)puVar5;
    if (piStack_54 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_54[2] + -1;
      piStack_54[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_54 + 4))();
      }
    }
    if (piStack_5c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_5c[2] + -1;
      piStack_5c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_5c + 4))();
      }
    }
    if (piStack_64 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_64[2] + -1;
      piStack_64[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_64 + 4))();
      }
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[2] + -1;
      piStack_24[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_34[2] + -1;
      piStack_34[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
    uVar6 = 1;
  }
  else {
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[2] + -1;
      piStack_24[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_34[2] + -1;
      piStack_34[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
    uVar6 = 0;
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[2] + -1;
    param_8[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_8 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[2] + -1;
    param_6[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_6 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 23359 ; VA 0x00b13430 ; FUN_00b13430 */

undefined FUN_00b13430(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,
                      undefined4 param_5,int *param_6,undefined4 param_7,int *param_8,
                      undefined4 param_9,undefined4 param_10,int *param_11)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined uVar6;
  undefined auStack_58 [4];
  int *piStack_54;
  int *piStack_4c;
  int *piStack_44;
  undefined4 auStack_38 [2];
  undefined auStack_30 [4];
  int *piStack_2c;
  int *piStack_24;
  int *piStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee268;
  pvStack_10 = ExceptionList;
  auStack_38[0] = param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00b17f60(&param_3);
  uStack_8._0_1_ = 1;
  cVar4 = FUN_00585a40(auStack_38);
  uVar3 = auStack_38[0];
  if (cVar4 == '\0') {
    FUN_00b17f60(auStack_30);
    uStack_8._0_1_ = 2;
    puVar5 = (undefined4 *)FUN_01674e20(0x28);
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      *puVar5 = uVar3;
      FUN_00b17f60(auStack_58);
    }
    *param_11 = (int)puVar5;
    if (piStack_44 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_44[2] + -1;
      piStack_44[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_44 + 4))();
      }
    }
    if (piStack_4c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_4c[2] + -1;
      piStack_4c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_4c + 4))();
      }
    }
    if (piStack_54 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_54[2] + -1;
      piStack_54[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_54 + 4))();
      }
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[2] + -1;
      piStack_24[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
    uVar6 = 1;
  }
  else {
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[2] + -1;
      piStack_24[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
    uVar6 = 0;
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[2] + -1;
    param_8[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_8 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[2] + -1;
    param_6[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_6 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 23360 ; VA 0x00b135e0 ; FUN_00b135e0 */

undefined FUN_00b135e0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                      int *param_5,undefined4 param_6,uint param_7)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  undefined4 *puVar6;
  undefined uVar7;
  int *in_stack_0000003c;
  undefined auStack_7c [8];
  int *piStack_74;
  uint uStack_6c;
  undefined auStack_64 [24];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined auStack_44 [8];
  int *piStack_3c;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee2a7;
  pvStack_10 = ExceptionList;
  uStack_4c = param_1;
  uStack_48 = param_2;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00b16760(&param_3);
  uStack_8._0_1_ = 1;
  cVar5 = FUN_00585a40(&uStack_4c);
  uVar4 = uStack_48;
  uVar3 = uStack_4c;
  if (cVar5 == '\0') {
    FUN_00b16760(auStack_44);
    uStack_8._0_1_ = 2;
    puVar6 = (undefined4 *)FUN_01674e20(0x38);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar6;
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      *puVar6 = uVar3;
      puVar6[1] = uVar4;
      FUN_00b16760(auStack_7c);
    }
    *in_stack_0000003c = (int)puVar6;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (uStack_6c != 0) {
      if (((uStack_6c & 1) == 0) && (*(code **)(uStack_6c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_6c & 0xfffffffe))(auStack_64,auStack_64,2);
      }
      uStack_6c = 0;
    }
    if (piStack_74 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_74[2] + -1;
      piStack_74[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_74 + 4))();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    if (piStack_3c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_3c[2] + -1;
      piStack_3c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
    uVar7 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    if (piStack_3c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_3c[2] + -1;
      piStack_3c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
    uVar7 = 0;
  }
  uStack_8 = 7;
  if (param_7 != 0) {
    if (((param_7 & 1) == 0) && (*(code **)(param_7 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_7 & 0xfffffffe))(&stack0x00000024,&stack0x00000024,2);
    }
    param_7 = 0;
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_5 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 23361 ; VA 0x00b137b0 ; FUN_00b137b0 */

undefined4 * FUN_00b137b0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 in_stack_0000001c;
  undefined in_stack_00000020;
  undefined auStack_58 [12];
  undefined4 uStack_4c;
  undefined uStack_48;
  undefined auStack_44 [12];
  undefined auStack_38 [12];
  undefined auStack_2c [12];
  undefined auStack_20 [16];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar1 = in_stack_0000001c;
  puStack_c = &LAB_017ee2f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_006d07c0(&stack0x00000010);
  uStack_8._0_1_ = 1;
  FUN_006d07c0(auStack_44);
  uStack_8._0_1_ = 2;
  FUN_006d07c0(auStack_38);
  uStack_8._0_1_ = 3;
  FUN_006d07c0(auStack_2c);
  uStack_8._0_1_ = 4;
  FUN_006d07c0(auStack_20);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_4c = uVar1;
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_48 = in_stack_00000020;
  uStack_8._0_1_ = 7;
  FUN_00577b20();
  uStack_8._0_1_ = 8;
  FUN_00577b20();
  uStack_8._0_1_ = 9;
  *param_1 = param_2;
  FUN_006d07c0(auStack_58);
  param_1[4] = uStack_4c;
  *(undefined *)(param_1 + 5) = uStack_48;
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  FUN_00577b20();
  uStack_8 = 0xb;
  FUN_00577b20();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23362 ; VA 0x00b138b0 ; FUN_00b138b0 */

undefined4 *
FUN_00b138b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_c;
  int *piStack_8;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  piVar1 = param_4 + 1;
  if (param_4 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00b17bd0(param_3,param_4,param_5,param_6,param_7);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    piStack_8[1] = piStack_8[1] + 1;
    UNLOCK();
  }
  param_1[1] = uStack_c;
  param_1[2] = piStack_8;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_8[1] + -1;
    piStack_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      iVar2 = piStack_8[2] + -1;
      piStack_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 23363 ; VA 0x00b139a0 ; FUN_00b139a0 */

undefined4 *
FUN_00b139a0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,int param_5)

{
  int *piVar1;
  int iVar2;
  uint in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 *in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined auStack_88 [24];
  undefined4 uStack_70;
  int iStack_6c;
  undefined4 *puStack_68;
  undefined4 uStack_58;
  int iStack_54;
  undefined auStack_50 [24];
  undefined4 uStack_38;
  undefined4 uStack_34;
  int aiStack_30 [5];
  uint uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee330;
  pvStack_10 = ExceptionList;
  puStack_68 = &param_5;
  uStack_8 = 1;
  iStack_6c = 0xb139d1;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_18 = param_3;
  piStack_14 = param_4;
  puStack_68 = (undefined4 *)in_stack_00000034;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  iStack_6c = (int)in_stack_00000030;
  uStack_70 = in_stack_0000002c;
  in_stack_00000030 = (undefined4 *)auStack_88;
  FUN_0054ef60(aiStack_30);
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  FUN_00b183c0(param_3,param_4);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_68 = (undefined4 *)0xb13a43;
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        puStack_68 = (undefined4 *)0xb13a53;
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 1;
  if (0xf < uStack_1c) {
    puStack_68 = (undefined4 *)(uStack_1c + 1);
    iVar2 = aiStack_30[0];
    if (0xfff < puStack_68) {
      iVar2 = *(int *)(aiStack_30[0] + -4);
      puStack_68 = (undefined4 *)(uStack_1c + 0x24);
      if (0x1f < (aiStack_30[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_68 = (undefined4 *)0xb13b4d;
        FUN_017167a3();
      }
    }
    uStack_70 = 0xb13a88;
    iStack_6c = iVar2;
    FUN_01674ea0();
  }
  in_stack_00000030 = param_1 + 1;
  *param_1 = param_2;
  *in_stack_00000030 = 0;
  param_1[2] = 0;
  if (iStack_54 != 0) {
    LOCK();
    *(int *)(iStack_54 + 4) = *(int *)(iStack_54 + 4) + 1;
    UNLOCK();
  }
  *in_stack_00000030 = uStack_58;
  param_1[2] = iStack_54;
  puStack_68 = (undefined4 *)auStack_50;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  iStack_6c = 0xb13acc;
  FUN_0054ef60();
  param_1[9] = uStack_38;
  param_1[10] = uStack_34;
  puStack_68 = (undefined4 *)0xb13ae0;
  FUN_006511a0();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_68 = (undefined4 *)0xb13af6;
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_68 = (undefined4 *)0xb13b05;
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000028) {
    puStack_68 = (undefined4 *)(in_stack_00000028 + 1);
    iVar2 = param_5;
    if (0xfff < puStack_68) {
      iVar2 = *(int *)(param_5 + -4);
      puStack_68 = (undefined4 *)(in_stack_00000028 + 0x24);
      if (0x1f < (param_5 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_68 = (undefined4 *)&UNK_00b13b52;
        FUN_017167a3();
      }
    }
    uStack_70 = 0xb13b32;
    iStack_6c = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23364 ; VA 0x00b13b60 ; FUN_00b13b60 */

undefined4 * __thiscall
FUN_00b13b60(undefined4 param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 in_stack_00000020;
  undefined in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined auStack_54 [12];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 *puStack_40;
  int *piStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee360;
  pvStack_10 = ExceptionList;
  puStack_40 = (undefined4 *)in_stack_00000028;
  uStack_8 = 1;
  uStack_44 = CONCAT31((int3)((uint)param_1 >> 8),in_stack_00000024);
  _in_stack_00000024 = (undefined4 *)auStack_54;
  uStack_48 = in_stack_00000020;
  ExceptionList = &pvStack_10;
  FUN_006d07c0(&stack0x00000014);
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  puVar3 = (undefined4 *)FUN_00b169c0(param_4,param_5);
  _in_stack_00000024 = param_2 + 1;
  *param_2 = param_3;
  *_in_stack_00000024 = 0;
  param_2[2] = 0;
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *_in_stack_00000024 = *puVar3;
  param_2[2] = puVar3[1];
  puStack_40 = puVar3 + 2;
  uStack_8._0_1_ = 3;
  uStack_44 = 0xb13c1b;
  FUN_006d07c0();
  param_2[6] = puVar3[5];
  *(undefined *)(param_2 + 7) = *(undefined *)(puVar3 + 6);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  puStack_40 = (undefined4 *)0xb13c33;
  FUN_00577b20();
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_2c[2] + -1;
    piStack_2c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_40 = (undefined4 *)0xb13c4b;
      (**(code **)(*piStack_2c + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_40 = (undefined4 *)0xb13c5f;
      (**(code **)(*param_5 + 4))();
    }
  }
  uStack_8 = 5;
  puStack_40 = (undefined4 *)0xb13c6e;
  FUN_00577b20();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 23365 ; VA 0x00b13c90 ; FUN_00b13c90 */

undefined4 *
FUN_00b13c90(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,undefined4 param_6,uint param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 param_10,undefined4 param_11,undefined4 *param_12,ulonglong param_13,
            uint param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined4 param_18,undefined4 param_19,undefined8 param_20,undefined4 param_21,
            uint *param_22,undefined4 param_23,uint *param_24)

{
  int iVar1;
  uint *puVar2;
  uint auStack_c4 [2];
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 *puStack_b0;
  ulonglong uStack_ac;
  uint auStack_a4 [2];
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined8 uStack_8c;
  undefined4 uStack_84;
  undefined4 *puStack_80;
  undefined4 *puStack_7c;
  undefined4 uStack_78;
  uint uStack_44;
  undefined auStack_3c [44];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee398;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  puStack_7c = (undefined4 *)param_23;
  uStack_78 = param_24;
  param_24 = auStack_a4;
  uStack_84 = param_21;
  puStack_80 = param_22;
  auStack_a4[0] = 0;
  ExceptionList = &pvStack_10;
  puVar2 = auStack_a4;
  if (param_14 != 0) {
    auStack_a4[0] = param_14;
    if ((param_14 & 1) == 0) {
      uStack_ac = ZEXT48(&uStack_9c);
      puStack_b0 = &param_16;
      uStack_b4 = 0xb13d18;
      ExceptionList = &pvStack_10;
      param_22 = auStack_a4;
      (**(code **)(param_14 & 0xfffffffe))();
      puVar2 = param_24;
    }
    else {
      uStack_9c = param_16;
      uStack_98 = param_17;
      uStack_94 = param_18;
      uStack_90 = param_19;
      uStack_8c = param_20;
      ExceptionList = &pvStack_10;
      puVar2 = auStack_a4;
    }
  }
  param_24 = puVar2;
  param_22 = auStack_c4;
  uStack_8._0_1_ = 3;
  auStack_c4[0] = 0;
  puVar2 = auStack_c4;
  if (param_7 != 0) {
    auStack_c4[0] = param_7;
    if ((param_7 & 1) == 0) {
      (**(code **)(param_7 & 0xfffffffe))(&param_9,&uStack_bc,0);
      puVar2 = param_22;
    }
    else {
      uStack_bc = param_9;
      uStack_b8 = param_10;
      uStack_b4 = param_11;
      puStack_b0 = param_12;
      uStack_ac = param_13;
      puVar2 = auStack_c4;
    }
  }
  param_22 = puVar2;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 2;
  uStack_78 = FUN_00b17230(param_3,param_4,param_5,param_6);
  uStack_8._0_1_ = 4;
  *param_1 = param_2;
  puStack_7c = (undefined4 *)0xb13db2;
  FUN_00b17130();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((uStack_44 != 0) && ((uStack_44 & 1) == 0)) &&
     (*(code **)(uStack_44 & 0xfffffffe) != (code *)0x0)) {
    puStack_80 = (undefined4 *)auStack_3c;
    uStack_78 = 2;
    uStack_84 = 0xb13dd3;
    puStack_7c = puStack_80;
    (**(code **)(uStack_44 & 0xfffffffe))();
  }
  uStack_78 = 0xb13de5;
  FUN_00a7c840();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar1 = param_4[1] + -1;
    param_4[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_78 = 0xb13dfc;
      (**(code **)*param_4)();
      LOCK();
      iVar1 = param_4[2] + -1;
      param_4[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_78 = 0xb13e0d;
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (((param_7 != 0) && ((param_7 & 1) == 0)) && (*(code **)(param_7 & 0xfffffffe) != (code *)0x0))
  {
    puStack_80 = &param_9;
    uStack_78 = 2;
    uStack_84 = 0xb13e2e;
    puStack_7c = puStack_80;
    (**(code **)(param_7 & 0xfffffffe))();
  }
  uStack_8 = 7;
  if (((param_14 != 0) && ((param_14 & 1) == 0)) &&
     (*(code **)(param_14 & 0xfffffffe) != (code *)0x0)) {
    puStack_80 = &param_16;
    uStack_78 = 2;
    uStack_84 = 0xb13e5c;
    puStack_7c = puStack_80;
    (**(code **)(param_14 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23366 ; VA 0x00b13e80 ; FUN_00b13e80 */

undefined4 *
FUN_00b13e80(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piStack_8;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  puVar3 = (undefined4 *)FUN_00b163b0(param_3,param_4,param_5);
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = *puVar3;
  param_1[2] = puVar3[1];
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_8[2] + -1;
    piStack_8[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_8 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 23367 ; VA 0x00b13f20 ; FUN_00b13f20 */

undefined4 *
FUN_00b13f20(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,int param_5)

{
  int *piVar1;
  int iVar2;
  uint in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined auStack_78 [16];
  undefined4 uStack_68;
  int iStack_64;
  undefined4 *puStack_60;
  undefined4 uStack_54;
  int iStack_50;
  undefined auStack_4c [24];
  int aiStack_34 [5];
  uint uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee3e0;
  pvStack_10 = ExceptionList;
  puStack_60 = &param_5;
  uStack_8 = 1;
  iStack_64 = 0xb13f50;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_1c = param_3;
  piStack_18 = param_4;
  puStack_60 = (undefined4 *)in_stack_0000002c;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  puStack_14 = (undefined4 *)auStack_78;
  FUN_0054ef60(aiStack_34);
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  FUN_00b17520(param_3,param_4);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_60 = (undefined4 *)0xb13fbd;
      (**(code **)(*param_4 + 4))();
    }
  }
  uStack_8._0_1_ = 1;
  if (0xf < uStack_20) {
    puStack_60 = (undefined4 *)(uStack_20 + 1);
    iVar2 = aiStack_34[0];
    if (0xfff < puStack_60) {
      iVar2 = *(int *)(aiStack_34[0] + -4);
      puStack_60 = (undefined4 *)(uStack_20 + 0x24);
      if (0x1f < (aiStack_34[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_60 = (undefined4 *)0xb14099;
        FUN_017167a3();
      }
    }
    uStack_68 = 0xb13ff2;
    iStack_64 = iVar2;
    FUN_01674ea0();
  }
  puStack_14 = param_1 + 1;
  *param_1 = param_2;
  *puStack_14 = 0;
  param_1[2] = 0;
  if (iStack_50 != 0) {
    LOCK();
    *(int *)(iStack_50 + 8) = *(int *)(iStack_50 + 8) + 1;
    UNLOCK();
  }
  *puStack_14 = uStack_54;
  param_1[2] = iStack_50;
  puStack_60 = (undefined4 *)auStack_4c;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  iStack_64 = 0xb14036;
  FUN_0054ef60();
  puStack_60 = (undefined4 *)0xb1403e;
  FUN_005d11a0();
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_60 = (undefined4 *)0xb14052;
      (**(code **)(*param_4 + 4))();
    }
  }
  if (0xf < in_stack_00000028) {
    puStack_60 = (undefined4 *)(in_stack_00000028 + 1);
    iVar2 = param_5;
    if (0xfff < puStack_60) {
      iVar2 = *(int *)(param_5 + -4);
      puStack_60 = (undefined4 *)(in_stack_00000028 + 0x24);
      if (0x1f < (param_5 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_60 = (undefined4 *)&UNK_00b1409e;
        FUN_017167a3();
      }
    }
    uStack_68 = 0xb1407f;
    iStack_64 = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23368 ; VA 0x00b140a0 ; FUN_00b140a0 */

undefined4 *
FUN_00b140a0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piStack_14;
  int *piStack_c;
  
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  puVar3 = (undefined4 *)FUN_00b16440(param_3,param_4,param_5,param_6);
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = *puVar3;
  param_1[2] = puVar3[1];
  param_1[3] = 0;
  param_1[4] = 0;
  if (puVar3[3] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[3] = puVar3[2];
  param_1[4] = puVar3[3];
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[1] + -1;
    piStack_c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[2] + -1;
    piStack_14[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_14 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 23369 ; VA 0x00b141e0 ; FUN_00b141e0 */

undefined4 *
FUN_00b141e0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6,undefined4 param_7,undefined4 param_8,undefined param_9,
            undefined4 param_10,uint param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 *puStack_68;
  undefined8 uStack_64;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee410;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if (param_11 != 0) {
    if ((param_11 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_11 & 0xfffffffe))(&param_13,&uStack_74,0);
    }
    else {
      uStack_74 = param_13;
      uStack_70 = param_14;
      uStack_6c = param_15;
      puStack_68 = (undefined4 *)param_16;
      uStack_64 = param_17;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uVar3 = FUN_00b16fe0(param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  *param_1 = param_2;
  uStack_64 = CONCAT44(uVar3,0xb142d0);
  FUN_00b16ef0();
  uStack_64 = CONCAT44(0xb142d8,(undefined4)uStack_64);
  FUN_00b19bf0();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_64 = CONCAT44(0xb142ee,(undefined4)uStack_64);
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_64 = CONCAT44(0xb14305,(undefined4)uStack_64);
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_64 = CONCAT44(0xb14317,(undefined4)uStack_64);
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  uStack_8 = 4;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_68 = &param_13;
    uStack_64 = CONCAT44(2,puStack_68);
    uStack_6c = 0xb1433b;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23370 ; VA 0x00b14350 ; FUN_00b14350 */

undefined4 *
FUN_00b14350(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6,undefined4 param_7,int *param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  int *piVar1;
  int iVar2;
  undefined auStack_34 [4];
  int *piStack_30;
  int *piStack_28;
  int *piStack_20;
  undefined4 uStack_14;
  undefined4 uStack_c;
  int *piStack_8;
  
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[2] = param_8[2] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[2] = param_6[2] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  piStack_8 = param_4;
  uStack_c = param_3;
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[2] = param_8[2] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[2] = param_6[2] + 1;
    UNLOCK();
  }
  piVar1 = param_4 + 2;
  if (param_4 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00b18b00(param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11,param_12);
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*piStack_8 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[2] + -1;
    param_6[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_6 + 4))();
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[2] + -1;
    param_8[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_8 + 4))();
    }
  }
  *param_1 = param_2;
  FUN_00b17f60(auStack_34);
  param_1[10] = uStack_14;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_20[2] + -1;
    piStack_20[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_20 + 4))();
    }
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_28[2] + -1;
    piStack_28[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_28 + 4))();
    }
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_30[2] + -1;
    piStack_30[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_30 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[2] + -1;
    param_6[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_6 + 4))();
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar1 = param_8 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_8 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 23371 ; VA 0x00b14500 ; FUN_00b14500 */

undefined4 *
FUN_00b14500(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6,undefined4 param_7,int *param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piStack_24;
  int *piStack_1c;
  int *piStack_14;
  
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[2] = param_8[2] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[2] = param_6[2] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uVar3 = FUN_00b16ab0(param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11);
  *param_1 = param_2;
  FUN_00b17f60(uVar3);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[2] + -1;
    piStack_14[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_14 + 4))();
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[2] + -1;
    piStack_1c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_1c + 4))();
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_24[2] + -1;
    piStack_24[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_24 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[2] + -1;
    param_6[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_6 + 4))();
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar1 = param_8 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_8 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 23372 ; VA 0x00b14640 ; FUN_00b14640 */

undefined4 *
FUN_00b14640(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            uint param_5)

{
  int iVar1;
  undefined4 in_stack_00000024;
  uint in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  int *in_stack_00000034;
  uint in_stack_00000038;
  undefined4 in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined8 in_stack_00000050;
  uint in_stack_00000058;
  undefined4 in_stack_00000060;
  undefined4 in_stack_00000064;
  undefined4 in_stack_00000068;
  undefined4 in_stack_0000006c;
  undefined8 in_stack_00000070;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee463;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000058 != 0) && (ExceptionList = &pvStack_10, (in_stack_00000058 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_00000058 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 4;
  if ((in_stack_00000038 != 0) && ((in_stack_00000038 & 1) == 0)) {
    (**(code **)(in_stack_00000038 & 0xfffffffe))();
  }
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    in_stack_00000034[2] = in_stack_00000034[2] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 6;
  FUN_0054ef60(&param_5);
  uStack_8._0_1_ = 3;
  FUN_00b16d10(param_4);
  uStack_8._0_1_ = 7;
  *param_1 = param_2;
  param_1[1] = param_3;
  FUN_00b16c00();
  FUN_00b19b60();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (0xf < in_stack_00000028) {
    if ((0xfff < in_stack_00000028 + 1) && (0x1f < (param_5 - *(int *)(param_5 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  in_stack_00000024 = 0;
  in_stack_00000028 = 0xf;
  param_5 = param_5 & 0xffffff00;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    iVar1 = in_stack_00000034[2] + -1;
    in_stack_00000034[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*in_stack_00000034 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (in_stack_00000038 != 0) {
    if (((in_stack_00000038 & 1) == 0) &&
       (*(code **)(in_stack_00000038 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000038 & 0xfffffffe))();
    }
    in_stack_00000038 = 0;
  }
  uStack_8 = 9;
  if (((in_stack_00000058 != 0) && ((in_stack_00000058 & 1) == 0)) &&
     (*(code **)(in_stack_00000058 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000058 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23373 ; VA 0x00b14840 ; FUN_00b14840 */

undefined4 *
FUN_00b14840(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 param_10,undefined4 *param_11,ulonglong param_12,uint param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined4 param_18,undefined8 param_19)

{
  undefined4 uVar1;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 *puStack_90;
  ulonglong uStack_8c;
  uint uStack_84;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 *puStack_70;
  undefined8 uStack_6c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee490;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_84 = 0;
  ExceptionList = &pvStack_10;
  if (param_13 != 0) {
    uStack_84 = param_13;
    if ((param_13 & 1) == 0) {
      uStack_8c = ZEXT48(&uStack_7c);
      puStack_90 = &param_15;
      uStack_94 = 0xb148a7;
      ExceptionList = &pvStack_10;
      (**(code **)(param_13 & 0xfffffffe))();
    }
    else {
      uStack_7c = param_15;
      uStack_78 = param_16;
      uStack_74 = param_17;
      puStack_70 = (undefined4 *)param_18;
      uStack_6c = param_19;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  if (param_6 != 0) {
    if ((param_6 & 1) == 0) {
      (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_9c,0);
    }
    else {
      uStack_9c = param_8;
      uStack_98 = param_9;
      uStack_94 = param_10;
      puStack_90 = param_11;
      uStack_8c = param_12;
    }
  }
  uStack_8._0_1_ = 1;
  uVar1 = FUN_00b16630(param_4,param_5);
  uStack_8._0_1_ = 3;
  *param_1 = param_2;
  param_1[1] = param_3;
  uStack_6c = CONCAT44(uVar1,0xb14924);
  FUN_00b16560();
  uStack_6c = CONCAT44(0xb1492c,(undefined4)uStack_6c);
  FUN_0096ca80();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    puStack_70 = &param_8;
    uStack_6c = CONCAT44(2,puStack_70);
    uStack_74 = 0xb1494d;
    (**(code **)(param_6 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_13 != 0) && ((param_13 & 1) == 0)) &&
     (*(code **)(param_13 & 0xfffffffe) != (code *)0x0)) {
    puStack_70 = &param_15;
    uStack_6c = CONCAT44(2,puStack_70);
    uStack_74 = 0xb1497b;
    (**(code **)(param_13 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23374 ; VA 0x00b14990 ; FUN_00b14990 */

undefined4 *
FUN_00b14990(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,int *param_7,uint param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined *param_13,
            undefined8 param_14)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  undefined4 uVar4;
  uint auStack_6c [2];
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 *puStack_58;
  undefined8 uStack_54;
  int *piStack_3c;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee4b8;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined *)auStack_6c;
  uStack_8 = 1;
  auStack_6c[0] = 0;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_6c;
  if (param_8 != 0) {
    auStack_6c[0] = param_8;
    if ((param_8 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_8 & 0xfffffffe))(&param_10);
      puVar3 = (uint *)puStack_14;
    }
    else {
      uStack_64 = param_10;
      uStack_60 = param_11;
      uStack_5c = param_12;
      puStack_58 = (undefined4 *)param_13;
      uStack_54 = param_14;
      ExceptionList = &pvStack_10;
      puVar3 = auStack_6c;
    }
  }
  puStack_14 = (undefined *)puVar3;
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[2] = param_7[2] + 1;
    UNLOCK();
  }
  uVar4 = FUN_00b16820(param_4,param_5);
  uStack_8._0_1_ = 2;
  *param_1 = param_2;
  param_1[1] = param_3;
  uStack_54 = CONCAT44(uVar4,0xb14a4e);
  FUN_00b16760();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
     (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
    puStack_58 = (undefined4 *)auStack_2c;
    uStack_54 = CONCAT44(2,puStack_58);
    uStack_5c = 0xb14a6f;
    (**(code **)(uStack_34 & 0xfffffffe))();
  }
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_3c[2] + -1;
    piStack_3c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_54 = CONCAT44(0xb14a91,(undefined4)uStack_54);
      (**(code **)(*piStack_3c + 4))();
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    piVar1 = param_7 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      uStack_54 = CONCAT44(0xb14aa5,(undefined4)uStack_54);
      (**(code **)(*param_7 + 4))();
    }
  }
  uStack_8 = 4;
  if (((param_8 != 0) && ((param_8 & 1) == 0)) && (*(code **)(param_8 & 0xfffffffe) != (code *)0x0))
  {
    puStack_58 = &param_10;
    uStack_54 = CONCAT44(2,puStack_58);
    uStack_5c = 0xb14ac9;
    (**(code **)(param_8 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23375 ; VA 0x00b14ae0 ; FUN_00b14ae0 */

int * __fastcall FUN_00b14ae0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00b317b0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    return piVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23376 ; VA 0x00b14b10 ; FUN_00b14b10 */

undefined4 * __thiscall FUN_00b14b10(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ee4f1;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006eccd0();
  uStack_8 = 0;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 1;
  puVar5 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_00b22b40;
    puVar5[3] = _guard_check_icall;
    puVar5[4] = 0;
    puVar5[5] = param_1;
    uVar1 = param_3[1];
    uVar2 = param_3[2];
    uVar3 = param_3[3];
    puVar5[6] = *param_3;
    puVar5[7] = uVar1;
    puVar5[8] = uVar2;
    puVar5[9] = uVar3;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 23377 ; VA 0x00b14bf0 ; FUN_00b14bf0 */

int * __fastcall FUN_00b14bf0(int *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  int *piStack_8;
  
  iVar3 = *param_1;
  piStack_8 = param_1;
  iVar2 = FUN_00b31840();
  if (iVar3 == iVar2) {
    piVar6 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar6 = (int *)0x0;
    }
    if (piVar6 != (int *)0x0) {
      return piVar6;
    }
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 != iVar2) {
LAB_00b14c8b:
    thunk_FUN_00b31840();
    uVar4 = FUN_005543f0();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar5,uVar4);
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 == iVar2) {
    iVar3 = param_1[1];
    FUN_00b31840();
    piVar7 = param_1 + 2;
    piVar6 = piVar7;
    if (iVar3 == 0) {
      piVar6 = (int *)0x0;
    }
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    cVar1 = FUN_009cb180(piVar6,&piStack_8);
    if (cVar1 == '\0') goto LAB_00b14c8b;
    FUN_00b119a0(&piStack_8);
    iVar3 = FUN_00b31840();
    *param_1 = iVar3;
    iVar2 = FUN_00b31840();
    if (iVar3 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23378 ; VA 0x00b14cc0 ; FUN_00b14cc0 */

int * __fastcall FUN_00b14cc0(int *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  int *piStack_8;
  
  iVar3 = *param_1;
  piStack_8 = param_1;
  iVar2 = FUN_00b318f0();
  if (iVar3 == iVar2) {
    piVar6 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar6 = (int *)0x0;
    }
    if (piVar6 != (int *)0x0) {
      return piVar6;
    }
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 != iVar2) {
LAB_00b14d5b:
    thunk_FUN_00b318f0();
    uVar4 = FUN_005543f0();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar5,uVar4);
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 == iVar2) {
    iVar3 = param_1[1];
    FUN_00b318f0();
    piVar7 = param_1 + 2;
    piVar6 = piVar7;
    if (iVar3 == 0) {
      piVar6 = (int *)0x0;
    }
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    cVar1 = FUN_009cb180(piVar6,&piStack_8);
    if (cVar1 == '\0') goto LAB_00b14d5b;
    FUN_00b119f0(&piStack_8);
    iVar3 = FUN_00b318f0();
    *param_1 = iVar3;
    iVar2 = FUN_00b318f0();
    if (iVar3 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23379 ; VA 0x00b14d90 ; FUN_00b14d90 */

undefined4 *
FUN_00b14d90(undefined4 *param_1,undefined4 *param_2,undefined4 param_3,char *param_4,
            undefined4 *param_5)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  char *pcVar6;
  uint uVar7;
  uint uVar8;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee54c;
  pvStack_10 = ExceptionList;
  uVar8 = 0;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00e49d20();
  uVar4 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar3 + 0x1dc) != (undefined4 *)0x0) {
    uVar4 = **(undefined4 **)(iVar3 + 0x1dc);
  }
  uVar4 = FUN_01675290(uVar4);
  uStack_8 = 1;
  uStack_1c = uVar4;
  iStack_20 = FUN_01674e20(0xa0);
  uStack_8._0_1_ = 2;
  if (iStack_20 == 0) {
    uVar5 = 0;
  }
  else {
    uStack_28 = 0;
    uStack_24 = 0xf;
    uStack_18 = *param_5;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    pcVar6 = param_4;
    do {
      cVar1 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0(param_4,(int)pcVar6 - (int)(param_4 + 1));
    uVar8 = 1;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    uStack_14 = 1;
    uVar5 = *param_2;
    uVar2 = param_2[1];
    *param_2 = 0;
    param_2[1] = 0;
    uVar5 = FUN_00e4ffd0(uVar5,uVar2,param_3,auStack_38,uStack_18);
  }
  uStack_8 = 4;
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00b12440(uVar5,param_1);
  uStack_14 = uVar8 | 2;
  uStack_8 = 1;
  if ((uVar8 != 0) && (uStack_14 = 2, 0xf < uStack_24)) {
    uVar7 = uStack_24 + 1;
    uVar8 = auStack_38[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_38[0] - 4);
      uVar7 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  uStack_8 = 8;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23380 ; VA 0x00b14f20 ; FUN_00b14f20 */

void FUN_00b14f20(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = (int *)param_2[9];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = param_2[5];
  if (0xf < uVar3) {
    iVar4 = *param_2;
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  return;
}



/* FUNCTION 23381 ; VA 0x00b14fa0 ; FUN_00b14fa0 */

code * FUN_00b14fa0(undefined4 param_1,int param_2)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  code *pcVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  pcVar6 = *(code **)(param_2 + 8);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (pcVar6 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      ExceptionList = &pvStack_10;
      if (pcVar6 != (code *)0x0) {
        ExceptionList = &pvStack_10;
        pcVar6 = (code *)(*pcVar6)(param_2 + 0x10,param_2 + 0x10,2);
      }
    }
    *(undefined4 *)(param_2 + 8) = 0;
  }
  piVar5 = *(int **)(param_2 + 4);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      pcVar6 = (code *)(**(code **)*piVar5)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 23382 ; VA 0x00b15030 ; FUN_00b15030 */

undefined4 __thiscall FUN_00b15030(int param_1,undefined4 param_2,char *param_3,undefined4 *param_4)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  char *pcVar4;
  uint uStack_20;
  int iStack_1c;
  undefined2 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017ee570;
  pvStack_10 = ExceptionList;
  iStack_1c = 0;
  uStack_18 = 0;
  uStack_20 = -(uint)(param_1 != -3) & param_1 + 4U;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005c6580();
  iVar2 = iStack_1c;
  puStack_14 = (undefined *)(iStack_1c + 8);
  *(undefined4 *)(iStack_1c + 0x18) = 0;
  *(undefined4 *)(iStack_1c + 0x1c) = 0xf;
  *puStack_14 = 0;
  pcVar4 = param_3;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_3,(int)pcVar4 - (int)(param_3 + 1));
  iStack_8._0_1_ = 1;
  *(undefined4 *)(iVar2 + 0x20) = *param_4;
  *(undefined4 *)(iVar2 + 0x24) = 0;
  puVar3 = (undefined4 *)param_4[1];
  if (puVar3 != (undefined4 *)0x0) {
    (*(code *)*puVar3)(param_4 + 2,iVar2 + 0x28);
    puVar3 = (undefined4 *)param_4[1];
  }
  *(undefined4 **)(iVar2 + 0x24) = puVar3;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  uStack_18._1_1_ = '\x01';
  FUN_0094df20(param_2,&uStack_20);
  iVar2 = iStack_1c;
  iStack_8 = 2;
  if (iStack_1c != 0) {
    if (uStack_18._1_1_ != '\0') {
      FUN_00560ab0(uStack_20,iStack_1c + 8);
    }
    FUN_01674ea0(iVar2,0xf0);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 23383 ; VA 0x00b15140 ; FUN_00b15140 */

undefined4 __thiscall FUN_00b15140(int param_1,undefined4 param_2,char *param_3,undefined4 *param_4)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  undefined4 uVar4;
  uint uStack_20;
  int iStack_1c;
  undefined2 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017ee570;
  pvStack_10 = ExceptionList;
  iStack_1c = 0;
  uStack_18 = 0;
  uStack_20 = -(uint)(param_1 != -3) & param_1 + 4U;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005c6580();
  iVar2 = iStack_1c;
  puStack_14 = (undefined *)(iStack_1c + 8);
  *(undefined4 *)(iStack_1c + 0x18) = 0;
  *(undefined4 *)(iStack_1c + 0x1c) = 0xf;
  *puStack_14 = 0;
  pcVar3 = param_3;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_3,(int)pcVar3 - (int)(param_3 + 1));
  iStack_8._0_1_ = 1;
  uVar4 = FUN_0088c8c0();
  *(undefined4 *)(iVar2 + 0x20) = uVar4;
  *(undefined4 *)(iVar2 + 0x24) = 0;
  *(undefined4 *)(iVar2 + 0x28) = *param_4;
  uVar4 = FUN_005c9cc0();
  *(undefined4 *)(iVar2 + 0x24) = uVar4;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  uStack_18._1_1_ = '\x01';
  FUN_0094df20(param_2,&uStack_20);
  iVar2 = iStack_1c;
  iStack_8 = 2;
  if (iStack_1c != 0) {
    if (uStack_18._1_1_ != '\0') {
      FUN_00560ab0(uStack_20,iStack_1c + 8);
    }
    FUN_01674ea0(iVar2,0xf0);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 23384 ; VA 0x00b15250 ; FUN_00b15250 */

int FUN_00b15250(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01eadd74,&LAB_00670c50);
  uVar2 = FUN_00675b30();
  piVar3 = (int *)FUN_008aa140(uVar2);
  if (*piVar3 == 0) {
    if (DAT_01eee3dc == 0) {
      iVar4 = FUN_00b12040();
      DAT_01eee3dc = *(int *)(iVar4 + 4);
    }
    piVar5 = (int *)FUN_008a9ba0(auStack_c,DAT_01eee3dc);
    iVar4 = *piVar5;
    iVar1 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar3 = iVar4;
    piVar5 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar4 = piVar5[1] + -1;
      piVar5[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar4 = piVar5[2] + -1;
        piVar5[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_8[1] + -1;
      piStack_8[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar4 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return *piVar3;
  }
  return *piVar3;
}



/* FUNCTION 23385 ; VA 0x00b15320 ; FUN_00b15320 */

int __fastcall FUN_00b15320(int *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int aiStack_dc [50];
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179904b;
  pvStack_10 = ExceptionList;
  iVar3 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00b319a0();
  iVar6 = *param_1;
  if (iVar3 == iVar2) {
    iVar3 = FUN_00b319a0();
    if (iVar6 == iVar3) {
      piVar4 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar4 = (int *)0x0;
      }
      ExceptionList = pvStack_10;
      return *piVar4;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar5 = (undefined4 *)param_1[1];
  if (puVar5 != (undefined4 *)0x0) {
    (*(code *)*puVar5)(param_1 + 2,aiStack_dc);
    puVar5 = (undefined4 *)param_1[1];
  }
  uStack_8 = 0;
  iVar3 = FUN_00b319a0();
  if (iVar6 == iVar3) {
    piVar4 = aiStack_dc;
    if (puVar5 == (undefined4 *)0x0) {
      piVar4 = (int *)0x0;
    }
    if (piVar4 != (int *)0x0) goto LAB_00b15468;
  }
  iVar3 = FUN_0088cb40();
  if (iVar6 == iVar3) {
    iVar3 = FUN_0088cb40();
    if (iVar6 != iVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar4 = aiStack_dc;
    if (puVar5 == (undefined4 *)0x0) {
      piVar4 = (int *)0x0;
    }
    FUN_00b319a0();
    if (0xf < (uint)piVar4[5]) {
      piVar4 = (int *)*piVar4;
    }
    cVar1 = FUN_009cb180(piVar4,auStack_14);
    if (cVar1 != '\0') {
      FUN_00b11a40(auStack_14);
      iVar3 = FUN_00b319a0();
      iVar6 = FUN_00b319a0();
      if (iVar3 != iVar6) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar4 = aiStack_dc;
      if (puVar5 == (undefined4 *)0x0) {
        piVar4 = (int *)0x0;
      }
LAB_00b15468:
      iVar3 = *piVar4;
      uStack_8 = 1;
      if (puVar5 != (undefined4 *)0x0) {
        (*(code *)puVar5[2])(aiStack_dc);
      }
      ExceptionList = pvStack_10;
      return iVar3;
    }
  }
  thunk_FUN_00b319a0();
  uVar7 = FUN_005543f0();
  uVar8 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar8,uVar7);
}



/* FUNCTION 23386 ; VA 0x00b154e0 ; FUN_00b154e0 */

void FUN_00b154e0(int param_1,int param_2,code *param_3,undefined4 param_4,undefined4 *param_5)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  uint *puVar5;
  uint uStack_5c;
  undefined auStack_54 [24];
  uint auStack_3c [2];
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ee598;
  pvStack_10 = ExceptionList;
  puVar5 = (uint *)(param_1 + param_2);
  auStack_3c[0] = 0;
  uVar2 = *puVar5;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    auStack_3c[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))(puVar5 + 2,&uStack_34,0);
    }
    else {
      uStack_34 = puVar5[2];
      uStack_30 = puVar5[3];
      uStack_2c = puVar5[4];
      uStack_28 = puVar5[5];
      uStack_24 = *(undefined8 *)(puVar5 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8 = 0;
  piVar4 = (int *)param_5[2];
  uStack_1c = *param_5;
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar4[1] = piVar4[1] + 1;
    UNLOCK();
    piVar4 = (int *)param_5[2];
  }
  uStack_18 = param_5[1];
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar4[1] = piVar4[1] + 1;
    UNLOCK();
  }
  piStack_14 = piVar4;
  FUN_00b10bf0(uStack_1c,uStack_18,piVar4,0);
  iStack_8._0_1_ = 2;
  FUN_00b31c10(puVar5);
  iStack_8._0_1_ = 3;
  if (((uStack_5c != 0) && ((uStack_5c & 1) == 0)) &&
     (*(code **)(uStack_5c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_5c & 0xfffffffe))(auStack_54,auStack_54,2);
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  if (param_3 != (code *)0x0) {
    (*param_3)(auStack_3c);
  }
  iStack_8 = 4;
  if (((auStack_3c[0] != 0) && ((auStack_3c[0] & 1) == 0)) &&
     (*(code **)(auStack_3c[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_3c[0] & 0xfffffffe))(&uStack_34,&uStack_34,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23387 ; VA 0x00b15640 ; thunk_FUN_00b317b0 */

undefined * thunk_FUN_00b317b0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f137c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee594) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eee594);
    if (DAT_01eee594 == -1) {
      uStack_8 = 0;
      FUN_00ddcf50();
      FUN_016f3654(&LAB_0188d9d0);
      FUN_016f37bf(&DAT_01eee594);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eee530;
}



/* FUNCTION 23388 ; VA 0x00b15650 ; thunk_FUN_00b31840 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b31840(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f13a6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee52c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eee52c);
    if (DAT_01eee52c == -1) {
      uStack_8 = 0;
      FUN_009ca470("CurrencyType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eee4c8 = RBX::Reflection::EnumDesc<enum_RBX::MarketplaceService::CurrencyType>::vftable
      ;
      FUN_009caf20(&DAT_01d66f14,3);
      FUN_016f3654(&LAB_0188d9f0);
      FUN_016f37bf(&DAT_01eee52c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eee4c8;
}



/* FUNCTION 23389 ; VA 0x00b15660 ; thunk_FUN_00b318f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b318f0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f13c6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee4c4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eee4c4);
    if (DAT_01eee4c4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("InfoType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eee460 = RBX::Reflection::EnumDesc<enum_RBX::MarketplaceService::InfoType>::vftable;
      FUN_009caf20(&DAT_01d66f2c,5);
      FUN_016f3654(&LAB_0188da10);
      FUN_016f37bf(&DAT_01eee4c4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eee460;
}



/* FUNCTION 23390 ; VA 0x00b15670 ; thunk_FUN_00b319a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b319a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f13e6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee45c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eee45c);
    if (DAT_01eee45c == -1) {
      uStack_8 = 0;
      FUN_009ca470("ProductPurchaseDecision");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eee3f8 =
           RBX::Reflection::EnumDesc<enum_RBX::MarketplaceService::ProductPurchaseDecision>::vftable
      ;
      FUN_009caf20(&DAT_01d66f54,2);
      FUN_016f3654(&LAB_0188da30);
      FUN_016f37bf(&DAT_01eee45c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eee3f8;
}



/* FUNCTION 23391 ; VA 0x00b15680 ; FUN_00b15680 */

void FUN_00b15680(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c88b0;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(*param_2 + 0x270);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088daf0();
  if (iVar2 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  iVar2 = *(int *)(*param_2 + 0x1a0);
  iVar3 = FUN_0088cb40();
  if (iVar2 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  FUN_0054ef60();
  iVar2 = *param_2;
  uStack_8 = 0;
  iVar3 = *(int *)(iVar2 + 0xd0);
  iVar4 = FUN_0088cb40();
  if (iVar3 != iVar4) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  iVar3 = iVar2 + 0xd8;
  if (*(int *)(iVar2 + 0xd4) == 0) {
    iVar3 = 0;
  }
  FUN_0054ef60(iVar3);
  param_2 = (int *)*param_2;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar2 = *param_2;
  iVar3 = FUN_0088cdc0();
  if (iVar2 == iVar3) {
    piVar5 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar5 = (int *)0x0;
    }
    if (piVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(piVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_8 = 0xffffffff;
    FUN_00b25410(param_1,*piVar5,piVar5[1]);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23392 ; VA 0x00b157d0 ; FUN_00b157d0 */

undefined4 * __thiscall FUN_00b157d0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = 0;
  param_1[4] = 0;
  if (param_2[4] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[4] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = 0;
  param_1[6] = 0;
  if (param_2[6] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[6] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[5] = param_2[5];
  param_1[6] = param_2[6];
  param_1[7] = 0;
  param_1[8] = 0;
  if (param_2[8] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[8] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[7] = param_2[7];
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  return param_1;
}



/* FUNCTION 23393 ; VA 0x00b15870 ; FUN_00b15870 */

undefined4 * __thiscall
FUN_00b15870(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined param_10,undefined4 param_11,undefined8 param_12,
            undefined4 param_13)

{
  undefined4 uVar1;
  undefined *puVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ee5e4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040();
  FUN_009cb790(uVar1,param_4,param_11,param_12,param_13);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64,bool,enum_RBX::MarketplaceService::CurrencyType),4>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  puVar2 = (undefined *)FUN_01674e20(1);
  if (puVar2 == (undefined *)0x0) {
    puVar2 = (undefined *)0x0;
  }
  else {
    *puVar2 = param_10;
  }
  param_1[0x12] = puVar2;
  uStack_8._0_1_ = 3;
  puVar3 = (undefined4 *)FUN_01674e20(4);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = param_9;
  }
  param_1[0x13] = puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00b206f0(param_5,param_6,param_7,param_8);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23394 ; VA 0x00b15950 ; FUN_00b15950 */

undefined4 * __thiscall
FUN_00b15950(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ee63b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_00b12040();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::BoundFuncDesc<class_RBX::MarketplaceService,void___cdecl(bool),1>::
             vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_00888530();
  param_1[9] = uVar2;
  puVar1 = (undefined *)param_1[0x10];
  if (puVar1 == (undefined *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088daf0();
    iStack_e4 = 0;
    auStack_e0[0] = *puVar1;
    iStack_e4 = FUN_005c9ef0();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088daf0();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23395 ; VA 0x00b15ad0 ; FUN_00b15ad0 */

undefined4 * __thiscall
FUN_00b15ad0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10)

{
  undefined4 uVar1;
  undefined auStack_1e8 [432];
  undefined8 uStack_38;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_017ee67c;
  pvStack_1c = ExceptionList;
  uStack_38 = param_7;
  ExceptionList = &pvStack_1c;
  puStack_30 = param_1;
  uVar1 = FUN_00b12040();
  FUN_009cb970(uVar1,param_3,param_6,uStack_38,param_8);
  param_1[0xd] = param_2;
  iStack_14 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::MarketplaceService::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_14._0_1_ = 1;
  FUN_0086e3d0(param_5);
  FUN_0088cb40();
  FUN_00888740();
  iStack_14._0_1_ = 2;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00687810(auStack_1e8,&uStack_38,puStack_30);
  iStack_14._0_1_ = 3;
  if (param_1 + 10 != &uStack_2c) {
    FUN_0068a760();
    param_1[10] = uStack_2c;
    param_1[0xb] = uStack_28;
    param_1[0xc] = uStack_24;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
  }
  iStack_14._0_1_ = 4;
  FUN_0068a760();
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  FUN_016f32d1(auStack_1e8,0xd8,2,FUN_00688b10);
  param_1[0xe] = param_10;
  param_1[0xf] = param_9;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::MarketplaceService::*>
             ::vftable;
  ExceptionList = pvStack_1c;
  return param_1;
}



/* FUNCTION 23396 ; VA 0x00b15c50 ; FUN_00b15c50 */

undefined4 * __thiscall
FUN_00b15c50(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10)

{
  undefined4 uVar1;
  undefined auStack_1e8 [432];
  undefined8 uStack_38;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_017ee6bc;
  pvStack_1c = ExceptionList;
  uStack_38 = param_7;
  ExceptionList = &pvStack_1c;
  puStack_30 = param_1;
  uVar1 = FUN_00b12040();
  FUN_009cb970(uVar1,param_3,param_6,uStack_38,param_8);
  param_1[0xd] = param_2;
  iStack_14 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64)>_RBX::MarketplaceService::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_14._0_1_ = 1;
  FUN_0086e3d0(param_5);
  FUN_0088da50();
  FUN_00888740();
  iStack_14._0_1_ = 2;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00687810(auStack_1e8,&uStack_38,puStack_30);
  iStack_14._0_1_ = 3;
  if (param_1 + 10 != &uStack_2c) {
    FUN_0068a760();
    param_1[10] = uStack_2c;
    param_1[0xb] = uStack_28;
    param_1[0xc] = uStack_24;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
  }
  iStack_14._0_1_ = 4;
  FUN_0068a760();
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  FUN_016f32d1(auStack_1e8,0xd8,2,FUN_00688b10);
  param_1[0xe] = param_10;
  param_1[0xf] = param_9;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64)>_RBX::MarketplaceService::*>
             ::vftable;
  ExceptionList = pvStack_1c;
  return param_1;
}



/* FUNCTION 23397 ; VA 0x00b15dd0 ; FUN_00b15dd0 */

undefined4 * __thiscall
FUN_00b15dd0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined8 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined auStack_2c0 [648];
  undefined8 uStack_38;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_017ee707;
  pvStack_1c = ExceptionList;
  uStack_38 = param_8;
  ExceptionList = &pvStack_1c;
  puStack_30 = param_1;
  uVar1 = FUN_00b12040();
  FUN_009cb970(uVar1,param_3,param_7,uStack_38,param_9);
  param_1[0xd] = param_2;
  iStack_14 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64,bool),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64,bool)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64,bool)>_RBX::MarketplaceService::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_14._0_1_ = 1;
  FUN_0086e3d0(param_5);
  FUN_0088da50();
  FUN_00888740();
  iStack_14._0_1_ = 2;
  FUN_0086e3d0(param_6);
  FUN_0088daf0();
  FUN_00888740();
  iStack_14._0_1_ = 3;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00687810(auStack_2c0,&uStack_38,puStack_30);
  iStack_14._0_1_ = 4;
  if (param_1 + 10 != &uStack_2c) {
    FUN_0068a760();
    param_1[10] = uStack_2c;
    param_1[0xb] = uStack_28;
    param_1[0xc] = uStack_24;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
  }
  iStack_14._0_1_ = 5;
  FUN_0068a760();
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  FUN_016f32d1(auStack_2c0,0xd8,3,FUN_00688b10);
  param_1[0xe] = param_11;
  param_1[0xf] = param_10;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64,bool),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64,bool)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64,bool)>_RBX::MarketplaceService::*>
             ::vftable;
  ExceptionList = pvStack_1c;
  return param_1;
}



/* FUNCTION 23398 ; VA 0x00b15f70 ; FUN_00b15f70 */

undefined4 * __thiscall
FUN_00b15f70(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined8 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  undefined4 uVar1;
  undefined auStack_398 [864];
  undefined8 uStack_38;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_017ee762;
  pvStack_1c = ExceptionList;
  uStack_38 = param_9;
  ExceptionList = &pvStack_1c;
  puStack_30 = param_1;
  uVar1 = FUN_00b12040();
  FUN_009cb970(uVar1,param_3,param_8,uStack_38,param_10);
  param_1[0xd] = param_2;
  iStack_14 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64,bool,enum_RBX::MarketplaceService::CurrencyType),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64,bool,enum_RBX::MarketplaceService::CurrencyType)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64,bool,enum_RBX::MarketplaceService::CurrencyType)>_RBX::MarketplaceService::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_14._0_1_ = 1;
  FUN_0086e3d0(param_5);
  FUN_0088da50();
  FUN_00888740();
  iStack_14._0_1_ = 2;
  FUN_0086e3d0(param_6);
  FUN_0088daf0();
  FUN_00888740();
  iStack_14._0_1_ = 3;
  FUN_0086e3d0(param_7);
  FUN_00b31840();
  FUN_00888740();
  iStack_14._0_1_ = 4;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00687810(auStack_398,&uStack_38,puStack_30);
  iStack_14._0_1_ = 5;
  if (param_1 + 10 != &uStack_2c) {
    FUN_0068a760();
    param_1[10] = uStack_2c;
    param_1[0xb] = uStack_28;
    param_1[0xc] = uStack_24;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
  }
  iStack_14._0_1_ = 6;
  FUN_0068a760();
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  FUN_016f32d1(auStack_398,0xd8,4,FUN_00688b10);
  param_1[0xe] = param_12;
  param_1[0xf] = param_11;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64,bool,enum_RBX::MarketplaceService::CurrencyType),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64,bool,enum_RBX::MarketplaceService::CurrencyType)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64,bool,enum_RBX::MarketplaceService::CurrencyType)>_RBX::MarketplaceService::*>
             ::vftable;
  ExceptionList = pvStack_1c;
  return param_1;
}



/* FUNCTION 23399 ; VA 0x00b16130 ; FUN_00b16130 */

undefined4 * __thiscall
FUN_00b16130(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined8 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uStack_18 = param_5;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040();
  FUN_009cb970(uVar1,param_3,param_4,uStack_18,param_6);
  param_1[0xd] = param_2;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::MarketplaceService,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::MarketplaceService::*>
             ::vftable;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 0;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = 0;
    param_1[0xb] = 0;
    param_1[0xc] = 0;
  }
  uStack_8 = 1;
  FUN_0068a760();
  param_1[0xe] = param_8;
  param_1[0xf] = param_7;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::MarketplaceService,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::MarketplaceService::*>
             ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23400 ; VA 0x00b16210 ; FUN_00b16210 */

undefined4 * __thiscall FUN_00b16210(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee778;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 3);
  param_1[9] = param_2[9];
  param_1[10] = param_2[10];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23401 ; VA 0x00b162a0 ; FUN_00b162a0 */

undefined4 * __thiscall FUN_00b162a0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee798;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  uStack_8 = 0;
  FUN_006d07c0(param_2 + 3);
  param_1[6] = param_2[6];
  *(undefined *)(param_1 + 7) = *(undefined *)(param_2 + 7);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23402 ; VA 0x00b16330 ; FUN_00b16330 */

undefined4 * __thiscall FUN_00b16330(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee7b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23403 ; VA 0x00b163b0 ; FUN_00b163b0 */

undefined4 * __thiscall FUN_00b163b0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 2;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 23404 ; VA 0x00b16440 ; FUN_00b16440 */

undefined4 * __thiscall
FUN_00b16440(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 2;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  param_1[2] = param_4;
  param_1[3] = param_5;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 23405 ; VA 0x00b16560 ; FUN_00b16560 */

undefined4 * __thiscall FUN_00b16560(undefined4 *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ee7d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[2] = 0;
  uVar1 = param_2[2];
  if (uVar1 != 0) {
    param_1[2] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar2 = param_2[5];
      uVar3 = param_2[6];
      uVar4 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar2;
      param_1[6] = uVar3;
      param_1[7] = uVar4;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = 0;
  uVar1 = param_2[10];
  uStack_8 = 0;
  if (uVar1 != 0) {
    param_1[10] = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar2 = param_2[0xd];
      uVar3 = param_2[0xe];
      uVar4 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar2;
      param_1[0xe] = uVar3;
      param_1[0xf] = uVar4;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23406 ; VA 0x00b16630 ; FUN_00b16630 */

undefined4 __thiscall
FUN_00b16630(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 *param_9,ulonglong param_10,uint param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
            undefined8 param_17)

{
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee808;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_3c = 0;
  ExceptionList = &pvStack_10;
  if (param_11 != 0) {
    uStack_3c = param_11;
    if ((param_11 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = &param_13;
      uStack_4c = 0xb1669c;
      ExceptionList = &pvStack_10;
      (**(code **)(param_11 & 0xfffffffe))();
    }
    else {
      uStack_34 = param_13;
      uStack_30 = param_14;
      uStack_2c = param_15;
      puStack_28 = (undefined4 *)param_16;
      uStack_24 = param_17;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_54,0);
    }
    else {
      uStack_54 = param_6;
      uStack_50 = param_7;
      uStack_4c = param_8;
      puStack_48 = param_9;
      uStack_44 = param_10;
    }
  }
  uStack_8._0_1_ = 1;
  FUN_00b178d0(param_2,param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_28 = &param_6;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0xb16719;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_8 = 4;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_28 = &param_13;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0xb16747;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23407 ; VA 0x00b16760 ; FUN_00b16760 */

undefined4 * __thiscall FUN_00b16760(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar6 = ExceptionList;
  puStack_c = &LAB_017ee828;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[4] = 0;
  uVar2 = param_2[4];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[4] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[7];
      uVar4 = param_2[8];
      uVar5 = param_2[9];
      param_1[6] = param_2[6];
      param_1[7] = uVar3;
      param_1[8] = uVar4;
      param_1[9] = uVar5;
      *(undefined8 *)(param_1 + 10) = *(undefined8 *)(param_2 + 10);
      ExceptionList = pvVar6;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 6,param_1 + 6,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23408 ; VA 0x00b16820 ; FUN_00b16820 */

undefined4 * __thiscall
FUN_00b16820(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined8 param_12)

{
  int *piVar1;
  int iVar2;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee868;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_3c = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_6 != 0) {
    uStack_3c = param_6;
    if ((param_6 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_34,0);
    }
    else {
      uStack_34 = param_8;
      uStack_30 = param_9;
      uStack_2c = param_10;
      uStack_28 = param_11;
      uStack_24 = param_12;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  uStack_1c = param_4;
  piStack_18 = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  piVar1 = param_5 + 2;
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_4;
  param_1[2] = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  param_1[4] = 0;
  if (uStack_3c != 0) {
    param_1[4] = uStack_3c;
    if ((uStack_3c & 1) == 0) {
      (**(code **)(uStack_3c & 0xfffffffe))(&uStack_34,param_1 + 6,0);
    }
    else {
      param_1[6] = uStack_34;
      param_1[7] = uStack_30;
      param_1[8] = uStack_2c;
      param_1[9] = uStack_28;
      *(undefined8 *)(param_1 + 10) = uStack_24;
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((uStack_3c != 0) && ((uStack_3c & 1) == 0)) &&
     (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_3c & 0xfffffffe))(&uStack_34,&uStack_34,2);
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  uStack_8 = 6;
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_6 & 0xfffffffe))(&param_8,&param_8,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23409 ; VA 0x00b169c0 ; FUN_00b169c0 */

undefined4 __thiscall FUN_00b169c0(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 in_stack_00000018;
  undefined4 in_stack_0000001c;
  undefined auStack_48 [12];
  undefined4 uStack_3c;
  undefined *puStack_38;
  undefined auStack_28 [12];
  undefined4 uStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee8a0;
  pvStack_10 = ExceptionList;
  puStack_38 = &stack0x0000000c;
  uStack_8 = 1;
  uStack_3c = 0xb169f6;
  ExceptionList = &pvStack_10;
  puStack_14 = (undefined *)param_1;
  FUN_006d07c0();
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_1c = param_2;
  piStack_18 = param_3;
  puStack_38 = (undefined *)in_stack_0000001c;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_3c = in_stack_00000018;
  puStack_14 = auStack_48;
  FUN_006d07c0(auStack_28);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  FUN_00b17e20(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_38 = (undefined *)0xb16a65;
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  puStack_38 = (undefined *)0xb16a71;
  FUN_00577b20();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_38 = (undefined *)0xb16a85;
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = 5;
  puStack_38 = (undefined *)0xb16a94;
  FUN_00577b20();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23410 ; VA 0x00b16ab0 ; FUN_00b16ab0 */

undefined4 __thiscall
FUN_00b16ab0(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,int *param_7,undefined4 param_8,undefined4 param_9)

{
  int *piVar1;
  int iVar2;
  
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[2] = param_7[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[2] = param_7[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  FUN_00b17ff0(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[2] + -1;
    param_7[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_7 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    piVar1 = param_7 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_7 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 23411 ; VA 0x00b16c00 ; FUN_00b16c00 */

undefined4 * __thiscall FUN_00b16c00(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ee8c0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  FUN_0054ef60(param_2 + 1);
  param_1[7] = 0;
  param_1[8] = 0;
  if (param_2[8] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[8] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[7] = param_2[7];
  param_1[8] = param_2[8];
  param_1[10] = 0;
  uVar2 = param_2[10];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[10] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
    }
    else {
      uVar3 = param_2[0xd];
      uVar4 = param_2[0xe];
      uVar5 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar3;
      param_1[0xe] = uVar4;
      param_1[0xf] = uVar5;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
    }
  }
  param_1[0x12] = 0;
  uVar2 = param_2[0x12];
  uStack_8 = 1;
  if (uVar2 != 0) {
    param_1[0x12] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0x15];
      uVar4 = param_2[0x16];
      uVar5 = param_2[0x17];
      param_1[0x14] = param_2[0x14];
      param_1[0x15] = uVar3;
      param_1[0x16] = uVar4;
      param_1[0x17] = uVar5;
      *(undefined8 *)(param_1 + 0x18) = *(undefined8 *)(param_2 + 0x18);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x14,param_1 + 0x14,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23412 ; VA 0x00b16d10 ; FUN_00b16d10 */

undefined4 __thiscall FUN_00b16d10(undefined4 param_1,undefined4 param_2,uint param_3)

{
  int iVar1;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  uint in_stack_0000002c;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined4 in_stack_0000003c;
  undefined4 in_stack_00000040;
  undefined8 in_stack_00000044;
  uint in_stack_0000004c;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined4 in_stack_0000005c;
  undefined4 in_stack_00000060;
  undefined8 in_stack_00000064;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee908;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  if ((in_stack_0000004c != 0) && (ExceptionList = &pvStack_10, (in_stack_0000004c & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_0000004c & 0xfffffffe))();
  }
  uStack_8._0_1_ = 4;
  if ((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))();
  }
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[2] = in_stack_00000028[2] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 6;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 3;
  FUN_00b18630(param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (0xf < in_stack_0000001c) {
    if ((0xfff < in_stack_0000001c + 1) && (0x1f < (param_3 - *(int *)(param_3 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    iVar1 = in_stack_00000028[2] + -1;
    in_stack_00000028[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*in_stack_00000028 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (in_stack_0000002c != 0) {
    if (((in_stack_0000002c & 1) == 0) &&
       (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000002c & 0xfffffffe))();
    }
    in_stack_0000002c = 0;
  }
  uStack_8 = 8;
  if (((in_stack_0000004c != 0) && ((in_stack_0000004c & 1) == 0)) &&
     (*(code **)(in_stack_0000004c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000004c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23413 ; VA 0x00b16ef0 ; FUN_00b16ef0 */

undefined4 * __thiscall FUN_00b16ef0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar6 = ExceptionList;
  puStack_c = &LAB_017ee928;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  *(undefined *)(param_1 + 6) = *(undefined *)(param_2 + 6);
  param_1[8] = 0;
  uVar2 = param_2[8];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[8] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0xb];
      uVar4 = param_2[0xc];
      uVar5 = param_2[0xd];
      param_1[10] = param_2[10];
      param_1[0xb] = uVar3;
      param_1[0xc] = uVar4;
      param_1[0xd] = uVar5;
      *(undefined8 *)(param_1 + 0xe) = *(undefined8 *)(param_2 + 0xe);
      ExceptionList = pvVar6;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 10,param_1 + 10,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23414 ; VA 0x00b16fe0 ; FUN_00b16fe0 */

undefined4 __thiscall
FUN_00b16fe0(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            uint param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined8 param_16)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee958;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if (param_10 != 0) {
    if ((param_10 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_10 & 0xfffffffe))(&param_12,&uStack_34,0);
    }
    else {
      uStack_34 = param_12;
      uStack_30 = param_13;
      uStack_2c = param_14;
      puStack_28 = (undefined4 *)param_15;
      uStack_24 = param_16;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  FUN_00b189a0(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_24 = CONCAT44(0xb170c4,(undefined4)uStack_24);
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_24 = CONCAT44(0xb170db,(undefined4)uStack_24);
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_24 = CONCAT44(0xb170ed,(undefined4)uStack_24);
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  uStack_8 = 3;
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    puStack_28 = &param_12;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0xb17111;
    (**(code **)(param_10 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23415 ; VA 0x00b17130 ; FUN_00b17130 */

undefined4 * __thiscall FUN_00b17130(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee980;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  uVar2 = param_2[2];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[2] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar3 = param_2[5];
      uVar4 = param_2[6];
      uVar5 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar3;
      param_1[6] = uVar4;
      param_1[7] = uVar5;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = 0;
  uVar2 = param_2[10];
  uStack_8 = 1;
  if (uVar2 != 0) {
    param_1[10] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
    }
    else {
      uVar3 = param_2[0xd];
      uVar4 = param_2[0xe];
      uVar5 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar3;
      param_1[0xe] = uVar4;
      param_1[0xf] = uVar5;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
    }
  }
  param_1[0x12] = param_2[0x12];
  param_1[0x13] = param_2[0x13];
  param_1[0x14] = param_2[0x14];
  param_1[0x15] = param_2[0x15];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23416 ; VA 0x00b17230 ; FUN_00b17230 */

undefined4 __thiscall
FUN_00b17230(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 param_10,undefined4 *param_11,ulonglong param_12,uint param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined4 param_18,undefined8 param_19,undefined4 param_20,undefined4 param_21,
            undefined4 param_22,undefined4 param_23)

{
  int iVar1;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 *puStack_5c;
  ulonglong uStack_58;
  uint uStack_50;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  undefined4 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee9b0;
  pvStack_10 = ExceptionList;
  uStack_24 = param_23;
  uStack_8 = 2;
  puStack_28 = (undefined4 *)param_22;
  puStack_2c = (undefined4 *)param_21;
  uStack_30 = param_20;
  uStack_50 = 0;
  ExceptionList = &pvStack_10;
  if (param_13 != 0) {
    uStack_50 = param_13;
    if ((param_13 & 1) == 0) {
      uStack_58 = ZEXT48(&uStack_48);
      puStack_5c = &param_15;
      uStack_60 = 0xb172a9;
      ExceptionList = &pvStack_10;
      (**(code **)(param_13 & 0xfffffffe))();
    }
    else {
      uStack_48 = param_15;
      uStack_44 = param_16;
      uStack_40 = param_17;
      uStack_3c = param_18;
      uStack_38 = param_19;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 3;
  if (param_6 != 0) {
    if ((param_6 & 1) == 0) {
      (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_68,0);
    }
    else {
      uStack_68 = param_8;
      uStack_64 = param_9;
      uStack_60 = param_10;
      puStack_5c = param_11;
      uStack_58 = param_12;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00b18c50(param_2,param_3,param_4,param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_24 = 0xb17344;
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_24 = 0xb17355;
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    puStack_2c = &param_8;
    uStack_24 = 2;
    uStack_30 = 0xb17376;
    puStack_28 = puStack_2c;
    (**(code **)(param_6 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_13 != 0) && ((param_13 & 1) == 0)) &&
     (*(code **)(param_13 & 0xfffffffe) != (code *)0x0)) {
    puStack_2c = &param_15;
    uStack_24 = 2;
    uStack_30 = 0xb173a4;
    puStack_28 = puStack_2c;
    (**(code **)(param_13 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23417 ; VA 0x00b173c0 ; FUN_00b173c0 */

int __thiscall FUN_00b173c0(int param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  int aiStack_38 [5];
  uint uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee9e8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_0054ef60(&param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_20 = param_2;
  piStack_1c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_0060e3f0(param_2,param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_0054ef60(aiStack_38);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < uStack_24) {
    uVar3 = uStack_24 + 1;
    iVar2 = aiStack_38[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_38[0] + -4);
      uVar3 = uStack_24 + 0x24;
      if (0x1f < (aiStack_38[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  *(undefined4 *)(param_1 + 0x20) = in_stack_00000024;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000020) {
    uVar3 = in_stack_00000020 + 1;
    iVar2 = param_4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_4 + -4);
      uVar3 = in_stack_00000020 + 0x24;
      if (0x1f < (param_4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23418 ; VA 0x00b17520 ; FUN_00b17520 */

undefined4 * __thiscall
FUN_00b17520(undefined4 *param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000020;
  int aiStack_34 [5];
  uint uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eea28;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60(&param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_1c = param_2;
  piStack_18 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 2;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_0054ef60(aiStack_34);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (0xf < uStack_20) {
    uVar3 = uStack_20 + 1;
    iVar2 = aiStack_34[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_34[0] + -4);
      uVar3 = uStack_20 + 0x24;
      if (0x1f < (aiStack_34[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    uVar3 = in_stack_00000020 + 1;
    iVar2 = param_4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_4 + -4);
      uVar3 = in_stack_00000020 + 0x24;
      if (0x1f < (param_4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23419 ; VA 0x00b17670 ; FUN_00b17670 */

undefined4 * __thiscall
FUN_00b17670(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 2;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  param_1[2] = param_4;
  param_1[3] = param_5;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  param_1[4] = param_6;
  param_1[5] = param_7;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 23420 ; VA 0x00b17790 ; FUN_00b17790 */

undefined4 * __thiscall
FUN_00b17790(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,int *param_7)

{
  int *piVar1;
  int iVar2;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 2;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  param_1[2] = param_4;
  param_1[3] = param_5;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  param_1[4] = 0;
  param_1[5] = 0;
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[2] = param_7[2] + 1;
    UNLOCK();
  }
  param_1[4] = param_6;
  param_1[5] = param_7;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    piVar1 = param_7 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_7 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 23421 ; VA 0x00b178d0 ; FUN_00b178d0 */

undefined4 * __thiscall
FUN_00b178d0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10,uint param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
            undefined8 param_17)

{
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eea60;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_38 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_30,0);
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  *param_1 = param_2;
  uStack_8._0_1_ = 2;
  param_1[2] = 0;
  if (uStack_38 != 0) {
    param_1[2] = uStack_38;
    if ((uStack_38 & 1) == 0) {
      (**(code **)(uStack_38 & 0xfffffffe))(&uStack_30,param_1 + 4,0);
    }
    else {
      param_1[4] = uStack_30;
      param_1[5] = uStack_2c;
      param_1[6] = uStack_28;
      param_1[7] = uStack_24;
      *(undefined8 *)(param_1 + 8) = uStack_20;
    }
  }
  uStack_8._0_1_ = 3;
  if (((uStack_38 != 0) && ((uStack_38 & 1) == 0)) &&
     (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_38 & 0xfffffffe))(&uStack_30,&uStack_30,2);
  }
  uStack_8._0_1_ = 4;
  param_1[10] = 0;
  if (param_11 != 0) {
    param_1[10] = param_11;
    if ((param_11 & 1) == 0) {
      (**(code **)(param_11 & 0xfffffffe))(&param_13,param_1 + 0xc,0);
    }
    else {
      param_1[0xc] = param_13;
      param_1[0xd] = param_14;
      param_1[0xe] = param_15;
      param_1[0xf] = param_16;
      *(undefined8 *)(param_1 + 0x10) = param_17;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_4 & 0xfffffffe))(&param_6,&param_6,2);
  }
  uStack_8 = 6;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_11 & 0xfffffffe))(&param_13,&param_13,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23422 ; VA 0x00b17a60 ; FUN_00b17a60 */

undefined4 * __thiscall FUN_00b17a60(undefined4 *param_1,undefined4 param_2,uint param_3)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  int aiStack_44 [5];
  uint uStack_30;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eea90;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 2;
  FUN_0054ef60(aiStack_44);
  *param_1 = param_2;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0054ef60(aiStack_2c);
  if (0xf < uStack_18) {
    uVar2 = uStack_18 + 1;
    iVar1 = aiStack_2c[0];
    if (0xfff < uVar2) {
      iVar1 = *(int *)(aiStack_2c[0] + -4);
      uVar2 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  if (0xf < uStack_30) {
    uVar2 = uStack_30 + 1;
    iVar1 = aiStack_44[0];
    if (0xfff < uVar2) {
      iVar1 = *(int *)(aiStack_44[0] + -4);
      uVar2 = uStack_30 + 0x24;
      if (0x1f < (aiStack_44[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  param_1[7] = 0;
  param_1[8] = 0;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[2] = in_stack_00000028[2] + 1;
    UNLOCK();
  }
  param_1[7] = in_stack_00000024;
  param_1[8] = in_stack_00000028;
  if (0xf < in_stack_0000001c) {
    uVar3 = in_stack_0000001c + 1;
    uVar2 = param_3;
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(param_3 - 4);
      uVar3 = in_stack_0000001c + 0x24;
      if (0x1f < (param_3 - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    iVar1 = in_stack_00000028[2] + -1;
    in_stack_00000028[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*in_stack_00000028 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23423 ; VA 0x00b17bd0 ; FUN_00b17bd0 */

undefined4 * __thiscall FUN_00b17bd0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    piVar1 = param_3 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 1;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar2 = param_3[1] + -1;
      param_3[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_3)();
        LOCK();
        iVar2 = param_3[2] + -1;
        param_3[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_3 + 4))();
        }
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 23424 ; VA 0x00b17cc0 ; FUN_00b17cc0 */

int __thiscall
FUN_00b17cc0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined8 param_12)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eeab8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_0060e3f0(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  *(undefined4 *)(param_1 + 8) = 0;
  if (param_6 != 0) {
    *(uint *)(param_1 + 8) = param_6;
    if ((param_6 & 1) == 0) {
      (**(code **)(param_6 & 0xfffffffe))(&param_8,param_1 + 0x10,0);
    }
    else {
      *(undefined4 *)(param_1 + 0x10) = param_8;
      *(undefined4 *)(param_1 + 0x14) = param_9;
      *(undefined4 *)(param_1 + 0x18) = param_10;
      *(undefined4 *)(param_1 + 0x1c) = param_11;
      *(undefined8 *)(param_1 + 0x20) = param_12;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = 3;
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_6 & 0xfffffffe))(&param_8,&param_8,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23425 ; VA 0x00b17e20 ; FUN_00b17e20 */

undefined4 * __thiscall FUN_00b17e20(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 in_stack_00000018;
  undefined in_stack_0000001c;
  undefined auStack_3c [12];
  undefined auStack_30 [12];
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eeb08;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_006d07c0(&stack0x0000000c);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_24 = param_2;
  piStack_20 = param_3;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_006d07c0(auStack_3c);
  piVar1 = param_3 + 2;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_1c = param_2;
  piStack_18 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = 0;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_006d07c0(auStack_30);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_00577b20();
  param_1[5] = in_stack_00000018;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  FUN_00577b20();
  *(undefined *)(param_1 + 6) = in_stack_0000001c;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = 9;
  FUN_00577b20();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23426 ; VA 0x00b17f60 ; FUN_00b17f60 */

undefined4 * __thiscall FUN_00b17f60(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = 0;
  param_1[5] = 0;
  if (param_2[5] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[5] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  return param_1;
}



/* FUNCTION 23427 ; VA 0x00b17ff0 ; FUN_00b17ff0 */

int __thiscall
FUN_00b17ff0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,int *param_7,undefined4 param_8,undefined4 param_9)

{
  int *piVar1;
  int iVar2;
  
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[2] = param_7[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  FUN_00b17790(param_2,param_3,param_4,param_5,param_6,param_7);
  *(undefined4 *)(param_1 + 0x18) = param_8;
  *(undefined4 *)(param_1 + 0x1c) = param_9;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    piVar1 = param_7 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_7 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 23428 ; VA 0x00b180e0 ; FUN_00b180e0 */

int __thiscall FUN_00b180e0(int param_1,undefined4 param_2,uint param_3)

{
  int iVar1;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  uint in_stack_0000002c;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined4 in_stack_0000003c;
  undefined4 in_stack_00000040;
  undefined8 in_stack_00000044;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eeb48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000028[2] = in_stack_00000028[2] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 2;
  FUN_00b17a60(param_2);
  uStack_8._0_1_ = 4;
  *(undefined4 *)(param_1 + 0x28) = 0;
  if (in_stack_0000002c != 0) {
    *(uint *)(param_1 + 0x28) = in_stack_0000002c;
    if ((in_stack_0000002c & 1) == 0) {
      (**(code **)(in_stack_0000002c & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x30) = in_stack_00000034;
      *(undefined4 *)(param_1 + 0x34) = in_stack_00000038;
      *(undefined4 *)(param_1 + 0x38) = in_stack_0000003c;
      *(undefined4 *)(param_1 + 0x3c) = in_stack_00000040;
      *(undefined8 *)(param_1 + 0x40) = in_stack_00000044;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < in_stack_0000001c) {
    if ((0xfff < in_stack_0000001c + 1) && (0x1f < (param_3 - *(int *)(param_3 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    iVar1 = in_stack_00000028[2] + -1;
    in_stack_00000028[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*in_stack_00000028 + 4))();
    }
  }
  uStack_8 = 5;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23429 ; VA 0x00b18240 ; FUN_00b18240 */

int __thiscall
FUN_00b18240(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 *param_11,ulonglong param_12,uint param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined4 param_18,undefined8 param_19)

{
  int iVar1;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eeb80;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if (param_6 != 0) {
    if ((param_6 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_38,0);
    }
    else {
      uStack_38 = param_8;
      uStack_34 = param_9;
      uStack_30 = param_10;
      puStack_2c = param_11;
      uStack_28 = param_12;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00b17cc0(param_2,param_3,param_4,param_5);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  *(undefined4 *)(param_1 + 0x28) = 0;
  if (param_13 != 0) {
    *(uint *)(param_1 + 0x28) = param_13;
    if ((param_13 & 1) == 0) {
      uStack_28 = (ulonglong)(param_1 + 0x30);
      puStack_2c = &param_15;
      uStack_30 = 0xb18320;
      (**(code **)(param_13 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x30) = param_15;
      *(undefined4 *)(param_1 + 0x34) = param_16;
      *(undefined4 *)(param_1 + 0x38) = param_17;
      *(undefined4 *)(param_1 + 0x3c) = param_18;
      *(undefined8 *)(param_1 + 0x40) = param_19;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_28 = CONCAT44(0xb1833d,(undefined4)uStack_28);
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_28 = CONCAT44(0xb1834e,(undefined4)uStack_28);
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    puStack_2c = &param_8;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xb18373;
    (**(code **)(param_6 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_13 != 0) && ((param_13 & 1) == 0)) &&
     (*(code **)(param_13 & 0xfffffffe) != (code *)0x0)) {
    puStack_2c = &param_15;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xb183a1;
    (**(code **)(param_13 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23430 ; VA 0x00b183c0 ; FUN_00b183c0 */

int __thiscall FUN_00b183c0(int param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined auStack_5c [16];
  undefined4 uStack_4c;
  int iStack_48;
  undefined4 *puStack_44;
  int aiStack_34 [5];
  uint uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eebb0;
  pvStack_10 = ExceptionList;
  puStack_44 = &param_4;
  uStack_8 = 1;
  iStack_48 = 0xb183f6;
  ExceptionList = &pvStack_10;
  puStack_14 = (undefined *)param_1;
  FUN_0054ef60();
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_1c = param_2;
  piStack_18 = param_3;
  puStack_44 = (undefined4 *)in_stack_00000024;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  puStack_14 = auStack_5c;
  FUN_0054ef60(aiStack_34);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00b173c0(param_2,param_3);
  *(undefined4 *)(param_1 + 0x24) = in_stack_00000028;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_44 = (undefined4 *)0xb18467;
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        puStack_44 = (undefined4 *)0xb18477;
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < uStack_20) {
    puStack_44 = (undefined4 *)(uStack_20 + 1);
    iVar2 = aiStack_34[0];
    if (0xfff < puStack_44) {
      iVar2 = *(int *)(aiStack_34[0] + -4);
      puStack_44 = (undefined4 *)(uStack_20 + 0x24);
      if (0x1f < (aiStack_34[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_44 = (undefined4 *)0xb18516;
        FUN_017167a3();
      }
    }
    uStack_4c = 0xb184a4;
    iStack_48 = iVar2;
    FUN_01674ea0();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_44 = (undefined4 *)0xb184bd;
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_44 = (undefined4 *)0xb184cc;
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000020) {
    puStack_44 = (undefined4 *)(in_stack_00000020 + 1);
    iVar2 = param_4;
    if (0xfff < puStack_44) {
      iVar2 = *(int *)(param_4 + -4);
      puStack_44 = (undefined4 *)(in_stack_00000020 + 0x24);
      if (0x1f < (param_4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_44 = (undefined4 *)&UNK_00b1851b;
        FUN_017167a3();
      }
    }
    uStack_4c = 0xb184f9;
    iStack_48 = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23431 ; VA 0x00b18520 ; FUN_00b18520 */

int __thiscall
FUN_00b18520(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,undefined4 param_7,undefined param_8)

{
  int *piVar1;
  int iVar2;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  FUN_00b17670(param_2,param_3,param_4,param_5,param_6,param_7);
  *(undefined *)(param_1 + 0x18) = param_8;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 23432 ; VA 0x00b18630 ; FUN_00b18630 */

int __thiscall FUN_00b18630(int param_1,undefined4 param_2,uint param_3)

{
  int iVar1;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  uint in_stack_0000002c;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined4 in_stack_0000003c;
  undefined4 in_stack_00000040;
  undefined8 in_stack_00000044;
  uint in_stack_0000004c;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined4 in_stack_0000005c;
  undefined4 in_stack_00000060;
  undefined8 in_stack_00000064;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eebf8;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  if ((in_stack_0000002c != 0) && (ExceptionList = &pvStack_10, (in_stack_0000002c & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_0000002c & 0xfffffffe))();
  }
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[2] = in_stack_00000028[2] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 5;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 3;
  FUN_00b180e0(param_2);
  uStack_8._0_1_ = 6;
  *(undefined4 *)(param_1 + 0x48) = 0;
  if (in_stack_0000004c != 0) {
    *(uint *)(param_1 + 0x48) = in_stack_0000004c;
    if ((in_stack_0000004c & 1) == 0) {
      (**(code **)(in_stack_0000004c & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x50) = in_stack_00000054;
      *(undefined4 *)(param_1 + 0x54) = in_stack_00000058;
      *(undefined4 *)(param_1 + 0x58) = in_stack_0000005c;
      *(undefined4 *)(param_1 + 0x5c) = in_stack_00000060;
      *(undefined8 *)(param_1 + 0x60) = in_stack_00000064;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (0xf < in_stack_0000001c) {
    if ((0xfff < in_stack_0000001c + 1) && (0x1f < (param_3 - *(int *)(param_3 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    iVar1 = in_stack_00000028[2] + -1;
    in_stack_00000028[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*in_stack_00000028 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (in_stack_0000002c != 0) {
    if (((in_stack_0000002c & 1) == 0) &&
       (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000002c & 0xfffffffe))();
    }
    in_stack_0000002c = 0;
  }
  uStack_8 = 8;
  if (((in_stack_0000004c != 0) && ((in_stack_0000004c & 1) == 0)) &&
     (*(code **)(in_stack_0000004c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000004c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23433 ; VA 0x00b18810 ; FUN_00b18810 */

int __thiscall
FUN_00b18810(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 *param_11,ulonglong param_12,uint param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined4 param_18,undefined8 param_19,undefined4 param_20,undefined4 param_21)

{
  int iVar1;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee9b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_40 = 0;
  ExceptionList = &pvStack_10;
  if (param_13 != 0) {
    uStack_40 = param_13;
    if ((param_13 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = &param_15;
      uStack_50 = 0xb1887d;
      ExceptionList = &pvStack_10;
      (**(code **)(param_13 & 0xfffffffe))();
    }
    else {
      uStack_38 = param_15;
      uStack_34 = param_16;
      uStack_30 = param_17;
      puStack_2c = (undefined4 *)param_18;
      uStack_28 = param_19;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 3;
  if (param_6 != 0) {
    if ((param_6 & 1) == 0) {
      (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_58,0);
    }
    else {
      uStack_58 = param_8;
      uStack_54 = param_9;
      uStack_50 = param_10;
      puStack_4c = param_11;
      uStack_48 = param_12;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00b18240(param_2,param_3,param_4,param_5);
  *(undefined4 *)(param_1 + 0x48) = param_20;
  *(undefined4 *)(param_1 + 0x4c) = param_21;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_28 = CONCAT44(0xb18924,(undefined4)uStack_28);
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_28 = CONCAT44(0xb18935,(undefined4)uStack_28);
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    puStack_2c = &param_8;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xb18956;
    (**(code **)(param_6 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_13 != 0) && ((param_13 & 1) == 0)) &&
     (*(code **)(param_13 & 0xfffffffe) != (code *)0x0)) {
    puStack_2c = &param_15;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xb18984;
    (**(code **)(param_13 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23434 ; VA 0x00b189a0 ; FUN_00b189a0 */

int __thiscall
FUN_00b189a0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            uint param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined8 param_16)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eec30;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  FUN_00b18520(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  *(undefined4 *)(param_1 + 0x20) = 0;
  if (param_10 != 0) {
    *(uint *)(param_1 + 0x20) = param_10;
    if ((param_10 & 1) == 0) {
      (**(code **)(param_10 & 0xfffffffe))(&param_12,param_1 + 0x28,0);
    }
    else {
      *(undefined4 *)(param_1 + 0x28) = param_12;
      *(undefined4 *)(param_1 + 0x2c) = param_13;
      *(undefined4 *)(param_1 + 0x30) = param_14;
      *(undefined4 *)(param_1 + 0x34) = param_15;
      *(undefined8 *)(param_1 + 0x38) = param_16;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  uStack_8 = 4;
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_10 & 0xfffffffe))(&param_12,&param_12,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23435 ; VA 0x00b18b00 ; FUN_00b18b00 */

int __thiscall
FUN_00b18b00(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,int *param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10)

{
  int *piVar1;
  int iVar2;
  
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[2] = param_7[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[2] = param_7[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  FUN_00b17ff0(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9);
  *(undefined4 *)(param_1 + 0x20) = param_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[2] + -1;
    param_7[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_7 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    piVar1 = param_7 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_7 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 23436 ; VA 0x00b18c50 ; FUN_00b18c50 */

int __thiscall
FUN_00b18c50(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 *param_11,ulonglong param_12,uint param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined4 param_18,undefined8 param_19,undefined4 param_20,undefined4 param_21,
            undefined4 param_22,undefined4 param_23)

{
  int iVar1;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 *puStack_54;
  ulonglong uStack_50;
  uint uStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 *puStack_28;
  undefined4 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ee9b0;
  pvStack_10 = ExceptionList;
  uStack_24 = param_21;
  uStack_8 = 2;
  puStack_28 = (undefined4 *)param_20;
  uStack_48 = 0;
  ExceptionList = &pvStack_10;
  if (param_13 != 0) {
    uStack_48 = param_13;
    if ((param_13 & 1) == 0) {
      uStack_50 = ZEXT48(&uStack_40);
      puStack_54 = &param_15;
      uStack_58 = 0xb18cc3;
      ExceptionList = &pvStack_10;
      (**(code **)(param_13 & 0xfffffffe))();
    }
    else {
      uStack_40 = param_15;
      uStack_3c = param_16;
      uStack_38 = param_17;
      uStack_34 = param_18;
      uStack_30 = param_19;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 3;
  if (param_6 != 0) {
    if ((param_6 & 1) == 0) {
      (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_60,0);
    }
    else {
      uStack_60 = param_8;
      uStack_5c = param_9;
      uStack_58 = param_10;
      puStack_54 = param_11;
      uStack_50 = param_12;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00b18810(param_2,param_3,param_4,param_5);
  *(undefined4 *)(param_1 + 0x50) = param_22;
  *(undefined4 *)(param_1 + 0x54) = param_23;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_24 = 0xb18d6a;
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_24 = 0xb18d7b;
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    puStack_28 = &param_8;
    uStack_24 = 2;
    uStack_30 = CONCAT44(puStack_28,0xb18d9c);
    (**(code **)(param_6 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_13 != 0) && ((param_13 & 1) == 0)) &&
     (*(code **)(param_13 & 0xfffffffe) != (code *)0x0)) {
    puStack_28 = &param_15;
    uStack_24 = 2;
    uStack_30 = CONCAT44(puStack_28,0xb18dca);
    (**(code **)(param_13 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23437 ; VA 0x00b18df0 ; FUN_00b18df0 */

undefined4 * __fastcall FUN_00b18df0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  uint auStack_44 [2];
  code *pcStack_3c;
  undefined4 uStack_38;
  undefined4 *puStack_34;
  uint uStack_30;
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  int *piStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eeeda;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::MarketplaceService,class_RBX::ServiceInstance>::
             vftable;
  uVar4 = FUN_00b12040();
  param_1[3] = uVar4;
  *param_1 = RBX::MarketplaceService::vftable;
  uStack_8 = 1;
  param_1[0x16] = 0;
  *(undefined *)(param_1 + 0x17) = 0;
  uVar4 = FUN_00588320(0xb);
  param_1[0x18] = uVar4;
  param_1[0x19] = 0;
  param_1[0x1a] = 0x3f800000;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  *(undefined *)(param_1 + 0x1d) = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  *(undefined *)(param_1 + 0x24) = 0;
  uVar4 = FUN_00588320(0xb);
  param_1[0x25] = uVar4;
  param_1[0x26] = 0;
  param_1[0x27] = 0x3f800000;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  *(undefined *)(param_1 + 0x2a) = 0;
  uVar4 = FUN_00588320(0xb);
  param_1[0x2b] = uVar4;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0x3f800000;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  *(undefined *)(param_1 + 0x36) = 0;
  uVar4 = FUN_00588320(0xb);
  param_1[0x37] = uVar4;
  param_1[0x38] = 0;
  param_1[0x39] = 0x3f800000;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  uStack_8._0_1_ = 0xd;
  FUN_01682800(param_1 + 0x3c);
  param_1[0x3e] = 0;
  param_1[0x3f] = 0;
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  *(undefined *)(param_1 + 0x42) = 0;
  uVar4 = FUN_00588320(0xb);
  param_1[0x43] = uVar4;
  param_1[0x44] = 0;
  param_1[0x45] = 0x3f800000;
  param_1[0x46] = 0;
  param_1[0x47] = 0;
  param_1[0x48] = 0;
  param_1[0x49] = 0;
  param_1[0x4a] = 0;
  param_1[0x4b] = 0;
  param_1[0x4c] = 0;
  param_1[0x4d] = 0;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  param_1[0x50] = 0;
  param_1[0x51] = 0;
  param_1[0x52] = 0;
  param_1[0x53] = 0;
  param_1[0x54] = 0;
  param_1[0x55] = 0;
  param_1[0x56] = 0;
  param_1[0x57] = 0;
  param_1[0x58] = 0;
  param_1[0x59] = 0;
  param_1[0x5a] = 0;
  param_1[0x5b] = 0;
  param_1[0x5c] = 0;
  param_1[0x5d] = 0;
  param_1[0x5e] = 0;
  param_1[0x5f] = 0;
  param_1[0x60] = 0;
  param_1[0x61] = 0;
  param_1[0x62] = 0;
  param_1[99] = 0;
  param_1[100] = 0;
  param_1[0x65] = 0;
  param_1[0x66] = 0;
  puStack_18 = param_1 + 0x67;
  *puStack_18 = 0;
  param_1[0x68] = 0;
  param_1[0x69] = 0;
  param_1[0x6a] = 0;
  param_1[0x6c] = 0;
  param_1[0x74] = 0;
  param_1[0x75] = 0;
  param_1[0x76] = 0;
  param_1[0x77] = 0;
  param_1[0x78] = 0;
  param_1[0x79] = 0;
  param_1[0x7a] = 0;
  param_1[0x7b] = 0;
  piStack_1c = param_1 + 0x7c;
  *piStack_1c = 0;
  puStack_24 = param_1 + 0x7d;
  *puStack_24 = 0;
  param_1[0x7e] = 0;
  param_1[0x7f] = 0;
  param_1[0x80] = 0;
  param_1[0x81] = 0;
  param_1[0x82] = 0;
  param_1[0x83] = 0;
  param_1[0x84] = 0;
  param_1[0x85] = 0;
  uStack_8._0_1_ = 0x2b;
  puStack_34 = (undefined4 *)0x0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  FUN_005542c0("MarketplaceService",0x12);
  uStack_8._0_1_ = 0x2c;
  FUN_008a6520(auStack_44);
  uStack_8._0_1_ = 0x2b;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x2b;
  if (0xf < uStack_30) {
    uVar6 = uStack_30 + 1;
    uVar5 = auStack_44[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_44[0] - 4);
      uVar6 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar5) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  pcStack_3c = FUN_00b236d0;
  uStack_38 = 0;
  puStack_34 = param_1;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x2d);
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0x2e;
  puStack_28 = (undefined4 *)uVar4;
  puStack_2c = (undefined4 *)FUN_01674e20(0x28);
  if (puStack_2c == (undefined4 *)0x0) {
    puVar7 = (undefined4 *)0x0;
  }
  else {
    *puStack_2c = 0;
    puStack_2c[1] = 1;
    puStack_2c[2] = FUN_00b22a00;
    puStack_2c[3] = _guard_check_icall;
    puStack_2c[4] = 0;
    puStack_2c[5] = puStack_18;
    puStack_2c[6] = pcStack_3c;
    puStack_2c[7] = uStack_38;
    puStack_2c[8] = puStack_34;
    puStack_2c[9] = uStack_30;
    puVar7 = puStack_2c;
  }
  FUN_016797d0(puVar7);
  if (puVar7 != (undefined4 *)0x0) {
    LOCK();
    puVar7[1] = puVar7[1] + 1;
    UNLOCK();
  }
  uStack_14 = 2;
  uStack_8 = 0x2f;
  puStack_2c = puVar7;
  FUN_01675290(uVar4);
  uStack_8 = 0x2b;
  uStack_14 = 1;
  if (puVar7 != (undefined4 *)0x0) {
    piVar1 = puVar7 + 1;
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(puVar7);
    }
  }
  if (DAT_01d63cb0 != '\0') {
    pcStack_3c = FUN_00b31ca0;
    uStack_38 = 0;
    puStack_34 = puStack_20;
    FUN_006eccd0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0x30);
    uVar4 = FUN_01675290(DAT_02110da8);
    uStack_8 = 0x31;
    puStack_2c = (undefined4 *)uVar4;
    puStack_28 = (undefined4 *)FUN_01674e20(0x28);
    if (puStack_28 == (undefined4 *)0x0) {
      puVar7 = (undefined4 *)0x0;
    }
    else {
      *puStack_28 = 0;
      puStack_28[1] = 1;
      puStack_28[2] = FUN_00b22930;
      puStack_28[3] = _guard_check_icall;
      puStack_28[4] = 0;
      puStack_28[5] = piStack_1c;
      puStack_28[6] = pcStack_3c;
      puStack_28[7] = uStack_38;
      puStack_28[8] = puStack_34;
      puStack_28[9] = uStack_30;
      puVar7 = puStack_28;
    }
    FUN_016797d0(puVar7);
    if (puVar7 == (undefined4 *)0x0) {
      piStack_1c = (int *)&DAT_00000004;
    }
    else {
      piStack_1c = puVar7 + 1;
      LOCK();
      *piStack_1c = *piStack_1c + 1;
      UNLOCK();
    }
    uStack_14 = 9;
    uStack_8 = 0x32;
    puStack_28 = puVar7;
    FUN_01675290(uVar4);
    if (puVar7 != (undefined4 *)0x0) {
      LOCK();
      iVar2 = *piStack_1c;
      *piStack_1c = *piStack_1c + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_01674ea0(puVar7);
      }
    }
  }
  ExceptionList = pvStack_10;
  return puStack_20;
}



/* FUNCTION 23438 ; VA 0x00b19480 ; FUN_00b19480 */

void __fastcall FUN_00b19480(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x20);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 0x18);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 0x10);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00b194c4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 23439 ; VA 0x00b194d0 ; FUN_00b194d0 */

void __fastcall FUN_00b194d0(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 23440 ; VA 0x00b19530 ; FUN_00b19530 */

void __fastcall FUN_00b19530(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),8);
  }
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 23441 ; VA 0x00b19590 ; FUN_00b19590 */

void __fastcall FUN_00b19590(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),1);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),8);
  }
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 23442 ; VA 0x00b19600 ; FUN_00b19600 */

void __fastcall FUN_00b19600(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),1);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),8);
  }
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 23443 ; VA 0x00b19680 ; FUN_00b19680 */

void __fastcall FUN_00b19680(int param_1)

{
  if (*(int *)(param_1 + 0x50) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x50),1);
  }
  FUN_005c4ac0();
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),8);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),4);
  }
  FUN_009cb8d0();
  return;
}



/* FUNCTION 23444 ; VA 0x00b196e0 ; FUN_00b196e0 */

void __fastcall FUN_00b196e0(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),8);
  }
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8d0();
  return;
}



/* FUNCTION 23445 ; VA 0x00b19740 ; FUN_00b19740 */

void __fastcall FUN_00b19740(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::MarketplaceService>::vftable;
  uVar1 = FUN_00b12040(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23446 ; VA 0x00b19780 ; FUN_00b19780 */

void FUN_00b19780(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00577b20();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23447 ; VA 0x00b197c0 ; FUN_00b197c0 */

int __fastcall FUN_00b197c0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00577b20();
  piVar3 = *(int **)(param_1 + 8);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)(*piVar3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 23448 ; VA 0x00b19810 ; FUN_00b19810 */

void FUN_00b19810(void)

{
  FUN_00b19bf0();
  return;
}



/* FUNCTION 23449 ; VA 0x00b19820 ; FUN_00b19820 */

void __fastcall FUN_00b19820(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x1c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00b19864. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 23450 ; VA 0x00b19870 ; FUN_00b19870 */

code * __fastcall FUN_00b19870(int param_1)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  code *pcVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  pcVar4 = *(code **)(param_1 + 0x18);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (pcVar4 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    if (((uint)pcVar4 & 1) == 0) {
      pcVar4 = *(code **)((uint)pcVar4 & 0xfffffffe);
      ExceptionList = &pvStack_10;
      if (pcVar4 != (code *)0x0) {
        ExceptionList = &pvStack_10;
        pcVar4 = (code *)(*pcVar4)(param_1 + 0x20,param_1 + 0x20,2);
      }
    }
    *(undefined4 *)(param_1 + 0x18) = 0;
  }
  piVar3 = *(int **)(param_1 + 0x10);
  if (piVar3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar3 + 2);
    uVar2 = *puVar1;
    pcVar4 = (code *)*puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      pcVar4 = (code *)(**(code **)(*piVar3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return pcVar4;
}



/* FUNCTION 23451 ; VA 0x00b198e0 ; FUN_00b198e0 */

void FUN_00b198e0(void)

{
  FUN_00b19b60();
  return;
}



/* FUNCTION 23452 ; VA 0x00b198f0 ; FUN_00b198f0 */

code * __fastcall FUN_00b198f0(int param_1)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  code *pcVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  pcVar4 = *(code **)(param_1 + 0x10);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (pcVar4 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    if (((uint)pcVar4 & 1) == 0) {
      pcVar4 = *(code **)((uint)pcVar4 & 0xfffffffe);
      ExceptionList = &pvStack_10;
      if (pcVar4 != (code *)0x0) {
        ExceptionList = &pvStack_10;
        pcVar4 = (code *)(*pcVar4)(param_1 + 0x18,param_1 + 0x18,2);
      }
    }
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  piVar3 = *(int **)(param_1 + 8);
  if (piVar3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar3 + 2);
    uVar2 = *puVar1;
    pcVar4 = (code *)*puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      pcVar4 = (code *)(**(code **)(*piVar3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return pcVar4;
}



/* FUNCTION 23453 ; VA 0x00b19960 ; FUN_00b19960 */

int __fastcall FUN_00b19960(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00577b20();
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)(*piVar3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 23454 ; VA 0x00b199b0 ; thunk_FUN_00b19b60 */

void __fastcall thunk_FUN_00b19b60(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x48);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x50,param_1 + 0x50,2);
      }
    }
    *(undefined4 *)(param_1 + 0x48) = 0;
  }
  uVar1 = *(uint *)(param_1 + 0x28);
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x30,param_1 + 0x30,2);
      }
    }
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  FUN_00b19a90();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23455 ; VA 0x00b199c0 ; thunk_FUN_00b19bf0 */

code * __fastcall thunk_FUN_00b19bf0(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  code *pcVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  pcVar6 = *(code **)(param_1 + 0x20);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (pcVar6 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      ExceptionList = &pvStack_10;
      if (pcVar6 != (code *)0x0) {
        ExceptionList = &pvStack_10;
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x28,param_1 + 0x28,2);
      }
    }
    *(undefined4 *)(param_1 + 0x20) = 0;
  }
  piVar5 = *(int **)(param_1 + 0xc);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      puVar1 = (uint *)(piVar5 + 2);
      uVar3 = *puVar1;
      pcVar6 = (code *)*puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = *(int **)(param_1 + 4);
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar2 = piVar5 + 2;
    iVar4 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 23456 ; VA 0x00b199d0 ; FUN_00b199d0 */

void __fastcall FUN_00b199d0(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_00b14f20(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x30);
  }
  return;
}



/* FUNCTION 23457 ; VA 0x00b19a00 ; FUN_00b19a00 */

void __fastcall FUN_00b19a00(undefined4 *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    ExceptionList = &pvStack_10;
    if (*(char *)((int)param_1 + 9) != '\0') {
      ExceptionList = &pvStack_10;
      FUN_00b14fa0(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x30);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23458 ; VA 0x00b19a60 ; FUN_00b19a60 */

void __fastcall FUN_00b19a60(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_006f8c50();
      iVar1 = *(int *)(param_1 + 4);
    }
    FUN_01674ea0(iVar1,0x28);
  }
  return;
}



/* FUNCTION 23459 ; VA 0x00b19a90 ; FUN_00b19a90 */

void __fastcall FUN_00b19a90(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  piVar1 = *(int **)(param_1 + 0x20);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[2] + -1;
    piVar1[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  uVar2 = *(uint *)(param_1 + 0x18);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 4);
    uVar5 = uVar2 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0xf;
  *(undefined *)(param_1 + 4) = 0;
  return;
}



/* FUNCTION 23460 ; VA 0x00b19b00 ; FUN_00b19b00 */

void __fastcall FUN_00b19b00(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x28);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x30,param_1 + 0x30,2);
      }
    }
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  FUN_00b19a90();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23461 ; VA 0x00b19b60 ; FUN_00b19b60 */

void __fastcall FUN_00b19b60(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x48);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x50,param_1 + 0x50,2);
      }
    }
    *(undefined4 *)(param_1 + 0x48) = 0;
  }
  uVar1 = *(uint *)(param_1 + 0x28);
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x30,param_1 + 0x30,2);
      }
    }
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  FUN_00b19a90();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23462 ; VA 0x00b19bf0 ; FUN_00b19bf0 */

code * __fastcall FUN_00b19bf0(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  code *pcVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  pcVar6 = *(code **)(param_1 + 0x20);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (pcVar6 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      ExceptionList = &pvStack_10;
      if (pcVar6 != (code *)0x0) {
        ExceptionList = &pvStack_10;
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x28,param_1 + 0x28,2);
      }
    }
    *(undefined4 *)(param_1 + 0x20) = 0;
  }
  piVar5 = *(int **)(param_1 + 0xc);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      puVar1 = (uint *)(piVar5 + 2);
      uVar3 = *puVar1;
      pcVar6 = (code *)*puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = *(int **)(param_1 + 4);
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar2 = piVar5 + 2;
    iVar4 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 23463 ; VA 0x00b19c90 ; FUN_00b19c90 */

void __fastcall FUN_00b19c90(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00b14f20(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x30);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 23464 ; VA 0x00b19d40 ; FUN_00b19d40 */

void __fastcall FUN_00b19d40(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      ExceptionList = &pvStack_10;
      FUN_00b217d0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23465 ; VA 0x00b19de0 ; FUN_00b19de0 */

void __fastcall FUN_00b19de0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00b21870(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 23466 ; VA 0x00b19e60 ; FUN_00b19e60 */

void __fastcall FUN_00b19e60(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00b14f20(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x30);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 23467 ; VA 0x00b19e70 ; FUN_00b19e70 */

void __fastcall FUN_00b19e70(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      ExceptionList = &pvStack_10;
      FUN_00b217d0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23468 ; VA 0x00b19e80 ; FUN_00b19e80 */

void __fastcall FUN_00b19e80(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00b21870(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 23469 ; VA 0x00b19e90 ; FUN_00b19e90 */

void __fastcall FUN_00b19e90(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd050;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::MarketplaceService::vftable;
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  uVar3 = param_1[0x6c];
  uStack_8 = 0;
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x6e,param_1 + 0x6e,2);
      }
    }
    param_1[0x6c] = 0;
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_0056d250();
  LOCK();
  iVar1 = param_1[0x41];
  param_1[0x41] = 0;
  UNLOCK();
  if (iVar1 != 0) {
    CloseHandle(iVar1);
  }
  FUN_00b19de0();
  LOCK();
  iVar1 = param_1[0x35];
  param_1[0x35] = 0;
  UNLOCK();
  if (iVar1 != 0) {
    CloseHandle(iVar1);
  }
  piVar4 = (int *)param_1[0x31];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar1 = piVar4[1] + -1;
    piVar4[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar1 = piVar4[2] + -1;
      piVar4[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_00b19c90();
  FUN_00612580();
  LOCK();
  iVar1 = param_1[0x23];
  param_1[0x23] = 0;
  UNLOCK();
  if (iVar1 != 0) {
    CloseHandle(iVar1);
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar1 = param_1[0x21];
  if (iVar1 != 0) {
    piVar4 = (int *)(iVar1 + 4);
    LOCK();
    iVar2 = *piVar4;
    *piVar4 = *piVar4 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar1);
    }
  }
  uStack_8 = 2;
  FUN_01679490();
  iVar1 = param_1[0x20];
  if (iVar1 != 0) {
    piVar4 = (int *)(iVar1 + 4);
    LOCK();
    iVar2 = *piVar4;
    *piVar4 = *piVar4 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar1);
    }
  }
  uStack_8 = 3;
  FUN_01679490();
  iVar1 = param_1[0x1f];
  if (iVar1 != 0) {
    piVar4 = (int *)(iVar1 + 4);
    LOCK();
    iVar2 = *piVar4;
    *piVar4 = *piVar4 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar1);
    }
  }
  uStack_8 = 4;
  FUN_01679490();
  iVar1 = param_1[0x1e];
  if (iVar1 != 0) {
    piVar4 = (int *)(iVar1 + 4);
    LOCK();
    iVar2 = *piVar4;
    *piVar4 = *piVar4 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar1);
    }
  }
  FUN_00b19d40();
  uStack_8 = 5;
  FUN_01679490();
  iVar1 = param_1[0x16];
  if (iVar1 != 0) {
    piVar4 = (int *)(iVar1 + 4);
    LOCK();
    iVar2 = *piVar4;
    *piVar4 = *piVar4 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar1);
    }
  }
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23470 ; VA 0x00b1a2e0 ; FUN_00b1a2e0 */

uint * __fastcall FUN_00b1a2e0(uint *param_1)

{
  uint uVar1;
  
  uVar1 = *param_1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 2,param_1 + 2,2);
      }
    }
    *param_1 = 0;
  }
  return param_1;
}



/* FUNCTION 23471 ; VA 0x00b1a310 ; FUN_00b1a310 */

int * __thiscall FUN_00b1a310(byte *param_1,int param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  byte *pbVar9;
  undefined4 *puVar10;
  int aiStack_3c [5];
  uint uStack_28;
  uint uStack_24;
  int *piStack_20;
  undefined2 uStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar5 = param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017eef00;
  pvStack_10 = ExceptionList;
  pbVar9 = param_1 + *param_1 + 1;
  ExceptionList = &pvStack_10;
  uStack_14 = FUN_0055c740(pbVar9,param_2);
  FUN_00562fc0(&param_2,uStack_14,iVar5,-(uint)(pbVar9 != (byte *)0x0) & (uint)(pbVar9 + 1));
  if (param_2 != 0) {
    ExceptionList = pvStack_10;
    return (int *)(param_2 + 8);
  }
  piStack_20 = (int *)0x0;
  uStack_1c = 0;
  uStack_24 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(iVar5);
  iStack_8._0_1_ = 1;
  FUN_00b1f3d0();
  piVar4 = piStack_20;
  piStack_18 = piStack_20 + 2;
  FUN_0054ef60(aiStack_3c);
  piVar4[10] = 0;
  piVar4[0xb] = 0;
  piVar4[8] = 0;
  piVar4[9] = 0;
  piVar4[10] = 0;
  piVar4[0xb] = 0;
  uStack_1c = CONCAT11(1,(undefined)uStack_1c);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_28) {
    uVar8 = uStack_28 + 1;
    iVar5 = aiStack_3c[0];
    if (0xfff < uVar8) {
      iVar5 = *(int *)(aiStack_3c[0] + -4);
      uVar8 = uStack_28 + 0x24;
      if (0x1f < (aiStack_3c[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar8);
  }
  uVar2 = *(uint *)(param_1 + 8);
  uVar8 = uVar2 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar8 = FUN_005d6bb0(uVar8);
    if (uVar8 <= *(uint *)(param_1 + 4)) {
      uVar8 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar8);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar8) {
    param_2 = 1;
    uVar6 = uVar2 >> 1;
    if (uVar2 + (uVar2 >> 1) <= uVar8) {
      uVar6 = 1;
    }
    iVar5 = FUN_005d6bb0(uVar6 + uVar2);
    if (iVar5 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar5);
      puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar10;
      while (puVar3 != (undefined4 *)0x0) {
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) == 0
           ) {
          *piVar1 = (int)puVar10;
          puVar10 = puVar3;
        }
        else {
          *puVar10 = *puVar3;
          *puVar3 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar3;
        }
        puVar3 = (undefined4 *)*puVar10;
      }
    }
  }
  piVar4[1] = uStack_14;
  uStack_14 = uStack_14 % *(uint *)(param_1 + 4);
  piVar7 = *(int **)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
  piVar1 = (int *)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
  if (piVar7 == (int *)0x0) {
    piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar7 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar4;
    }
    *piVar1 = (int)piVar7;
    *piVar4 = *piVar7;
  }
  else {
    *piVar4 = *piVar7;
    piVar7 = (int *)*piVar1;
  }
  *piVar7 = (int)piVar4;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_18;
}



/* FUNCTION 23472 ; VA 0x00b1a530 ; FUN_00b1a530 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __thiscall FUN_00b1a530(byte *param_1,uint *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 *puVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017eef20;
  pvStack_10 = ExceptionList;
  uVar4 = *param_2;
  uVar8 = (uVar4 >> 3) + uVar4;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&piStack_14,uVar8,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (piStack_14 != (int *)0x0) {
    ExceptionList = pvStack_10;
    return piStack_14 + 2;
  }
  if (param_2[1] == 0) {
    piVar7 = (int *)0x0;
  }
  else {
    LOCK();
    piVar7 = (int *)(param_2[1] + 4);
    *piVar7 = *piVar7 + 1;
    UNLOCK();
    uVar4 = *param_2;
    piVar7 = (int *)param_2[1];
  }
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  piStack_14 = piVar7;
  FUN_00b1f430();
  piVar1 = piVar7 + 1;
  piStack_14 = (int *)0x8;
  if (piVar7 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  _DAT_00000010 = 0;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  _DAT_00000008 = uVar4;
  _DAT_0000000c = piVar7;
  if (piVar7 != (int *)0x0) {
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)*piVar7)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  uVar2 = *(uint *)(param_1 + 8);
  uVar4 = uVar2 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar4 = FUN_005d6bb0(uVar4);
    if (uVar4 <= *(uint *)(param_1 + 4)) {
      uVar4 = *(uint *)(param_1 + 4);
    }
    FUN_005c6680(uVar4);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar4) {
    uVar6 = uVar2 >> 1;
    if (uVar2 + (uVar2 >> 1) <= uVar4) {
      uVar6 = 1;
    }
    iVar5 = FUN_005d6bb0(uVar6 + uVar2);
    if (iVar5 != *(int *)(param_1 + 4)) {
      FUN_005c6680(iVar5);
      puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar9;
      while (puVar3 != (undefined4 *)0x0) {
        piVar7 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) == 0
           ) {
          *piVar7 = (int)puVar9;
          puVar9 = puVar3;
        }
        else {
          *puVar9 = *puVar3;
          *puVar3 = *(undefined4 *)*piVar7;
          *(undefined4 **)*piVar7 = puVar3;
        }
        puVar3 = (undefined4 *)*puVar9;
      }
    }
  }
  uVar4 = uVar8 % *(uint *)(param_1 + 4);
  piVar7 = *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  _DAT_00000004 = uVar8;
  if (piVar7 == (int *)0x0) {
    piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar7 != 0) {
      *(undefined4 *)
       (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
    }
    *puVar9 = piVar7;
    _DAT_00000000 = *piVar7;
  }
  else {
    _DAT_00000000 = *piVar7;
    piVar7 = (int *)*puVar9;
  }
  *piVar7 = 0;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_14;
}



/* FUNCTION 23473 ; VA 0x00b1a740 ; FUN_00b1a740 */

int * __thiscall FUN_00b1a740(byte *param_1,int *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eef38;
  pvStack_10 = ExceptionList;
  uVar4 = param_2[1];
  iVar5 = *param_2;
  uVar8 = uVar4;
  if (((int)uVar4 < 1) && ((int)uVar4 < 0)) {
    uVar8 = ~uVar4;
  }
  uVar8 = (uVar8 >> 2) + uVar8 * 0x40 + iVar5 ^ uVar8;
  ExceptionList = &pvStack_10;
  FUN_00606ff0(&param_2,uVar8,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (int *)0x0) {
    uStack_8 = 0;
    piVar3 = (int *)FUN_01674e20(0x20);
    *piVar3 = 0;
    piVar3[1] = 0;
    piVar3[4] = 0;
    piVar3[5] = 0;
    piVar3[6] = 0;
    piVar3[7] = 0;
    piVar3[2] = iVar5;
    piVar3[3] = uVar4;
    piVar3[6] = 0;
    piVar3[7] = 0;
    piVar3[4] = 0;
    piVar3[5] = 0;
    uVar1 = *(uint *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar4 = FUN_005d6bb0(uVar4);
      if (uVar4 <= *(uint *)(param_1 + 4)) {
        uVar4 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar4);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar4) {
      param_2 = (int *)0x1;
      uVar6 = uVar1 >> 1;
      if (uVar1 + (uVar1 >> 1) <= uVar4) {
        uVar6 = 1;
      }
      iVar5 = FUN_005d6bb0(uVar6 + uVar1);
      if (iVar5 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar5);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar9;
        while (puVar2 != (undefined4 *)0x0) {
          piVar7 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar7 = (int)puVar9;
            puVar9 = puVar2;
          }
          else {
            *puVar9 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar7;
            *(undefined4 **)*piVar7 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar9;
        }
      }
    }
    piVar3[1] = uVar8;
    uVar8 = uVar8 % *(uint *)(param_1 + 4);
    piVar7 = *(int **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (piVar7 == (int *)0x0) {
      piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar7 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar3;
      }
      *puVar9 = piVar7;
      *piVar3 = *piVar7;
    }
    else {
      *piVar3 = *piVar7;
      piVar7 = (int *)*puVar9;
    }
    *piVar7 = (int)piVar3;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return piVar3 + 2;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 23474 ; VA 0x00b1a940 ; FUN_00b1a940 */

int * __thiscall FUN_00b1a940(byte *param_1,int *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eef58;
  pvStack_10 = ExceptionList;
  uVar5 = param_2[1];
  iVar4 = *param_2;
  uVar8 = uVar5;
  if (((int)uVar5 < 1) && ((int)uVar5 < 0)) {
    uVar8 = ~uVar5;
  }
  uVar8 = (uVar8 >> 2) + uVar8 * 0x40 + iVar4 ^ uVar8;
  ExceptionList = &pvStack_10;
  FUN_00606ff0(&param_2,uVar8,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (int *)0x0) {
    uStack_8 = 0;
    piVar3 = (int *)FUN_01674e20(0x28);
    *piVar3 = 0;
    piVar3[1] = 0;
    piVar3[4] = 0;
    piVar3[5] = 0;
    piVar3[6] = 0;
    piVar3[7] = 0;
    piVar3[8] = 0;
    piVar3[9] = 0;
    piVar3[2] = iVar4;
    piVar3[3] = uVar5;
    *(undefined *)(piVar3 + 4) = 0;
    iVar4 = FUN_00588320(0xb);
    piVar3[5] = iVar4;
    piVar3[6] = 0;
    piVar3[7] = 0x3f800000;
    piVar3[8] = 0;
    piVar3[9] = 0;
    uVar1 = *(uint *)(param_1 + 8);
    uVar5 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar5 = FUN_005d6bb0(uVar5);
      if (uVar5 <= *(uint *)(param_1 + 4)) {
        uVar5 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar5);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar5) {
      param_2 = (int *)0x1;
      uVar6 = uVar1 >> 1;
      if (uVar1 + (uVar1 >> 1) <= uVar5) {
        uVar6 = 1;
      }
      iVar4 = FUN_005d6bb0(uVar6 + uVar1);
      if (iVar4 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar4);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar9;
        while (puVar2 != (undefined4 *)0x0) {
          piVar7 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar7 = (int)puVar9;
            puVar9 = puVar2;
          }
          else {
            *puVar9 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar7;
            *(undefined4 **)*piVar7 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar9;
        }
      }
    }
    piVar3[1] = uVar8;
    uVar8 = uVar8 % *(uint *)(param_1 + 4);
    piVar7 = *(int **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (piVar7 == (int *)0x0) {
      piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar7 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar3;
      }
      *puVar9 = piVar7;
      *piVar3 = *piVar7;
    }
    else {
      *piVar3 = *piVar7;
      piVar7 = (int *)*puVar9;
    }
    *piVar7 = (int)piVar3;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return piVar3 + 2;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 23475 ; VA 0x00b1ab60 ; FUN_00b1ab60 */

int * __thiscall FUN_00b1ab60(byte *param_1,int *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eef78;
  pvStack_10 = ExceptionList;
  uVar4 = param_2[1];
  iVar5 = *param_2;
  uVar8 = uVar4;
  if (((int)uVar4 < 1) && ((int)uVar4 < 0)) {
    uVar8 = ~uVar4;
  }
  uVar8 = (uVar8 >> 2) + uVar8 * 0x40 + iVar5 ^ uVar8;
  ExceptionList = &pvStack_10;
  FUN_00606ff0(&param_2,uVar8,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (int *)0x0) {
    uStack_8 = 0;
    piVar3 = (int *)FUN_01674e20(0x18);
    *piVar3 = 0;
    piVar3[1] = 0;
    piVar3[4] = 0;
    piVar3[5] = 0;
    piVar3[3] = uVar4;
    piVar3[2] = iVar5;
    if (piVar3 + 4 != (int *)0x0) {
      piVar3[4] = 0;
    }
    uVar1 = *(uint *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar4 = FUN_005d6bb0(uVar4);
      if (uVar4 <= *(uint *)(param_1 + 4)) {
        uVar4 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar4);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar4) {
      param_2 = (int *)0x1;
      uVar6 = uVar1 >> 1;
      if (uVar1 + (uVar1 >> 1) <= uVar4) {
        uVar6 = 1;
      }
      iVar5 = FUN_005d6bb0(uVar6 + uVar1);
      if (iVar5 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar5);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar9;
        while (puVar2 != (undefined4 *)0x0) {
          piVar7 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar7 = (int)puVar9;
            puVar9 = puVar2;
          }
          else {
            *puVar9 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar7;
            *(undefined4 **)*piVar7 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar9;
        }
      }
    }
    piVar3[1] = uVar8;
    uVar8 = uVar8 % *(uint *)(param_1 + 4);
    piVar7 = *(int **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (piVar7 == (int *)0x0) {
      piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar7 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar3;
      }
      *puVar9 = piVar7;
      *piVar3 = *piVar7;
    }
    else {
      *piVar3 = *piVar7;
      piVar7 = (int *)*puVar9;
    }
    *piVar7 = (int)piVar3;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return piVar3 + 2;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 23476 ; VA 0x00b1ad50 ; FUN_00b1ad50 */

int __fastcall FUN_00b1ad50(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 *puVar8;
  code *pcStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  uint uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined auStack_a0 [28];
  undefined4 uStack_84;
  undefined auStack_80 [24];
  undefined4 uStack_68;
  int *piStack_64;
  undefined auStack_54 [4];
  int *piStack_50;
  int iStack_4c;
  int *piStack_48;
  int iStack_44;
  int *piStack_40;
  undefined *puStack_38;
  code *pcStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eefb0;
  pvStack_10 = ExceptionList;
  piStack_64 = &iStack_44;
  uStack_68 = 0xb1ad7c;
  ExceptionList = &pvStack_10;
  iVar7 = FUN_00587490();
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  if (iStack_44 != 0) {
    piStack_64 = &iStack_4c;
    uStack_68 = 0xb1ad9c;
    iVar7 = FUN_00587490();
    uStack_8._0_1_ = 1;
    if (iStack_4c != 0) {
      piStack_64 = (int *)auStack_54;
      uStack_68 = 0xb1adb6;
      puVar8 = (undefined4 *)FUN_00b264d0();
      piStack_30 = (int *)*puVar8;
      puStack_38 = auStack_80;
      puStack_20 = auStack_80;
      uStack_b4 = param_1[1];
      uStack_b8 = *param_1;
      iStack_28 = param_1[2] + 1;
      uStack_84 = 0;
      pcStack_34 = *(code **)(*piStack_30 + 0x28);
      puStack_1c = (undefined *)&uStack_ac;
      uStack_24 = CONCAT31(uStack_24._1_3_,DAT_01eee1b9);
      uStack_b0 = (uint)DAT_01eee1b9;
      uStack_2c = param_1[9];
      uStack_8._0_1_ = 2;
      if (param_1[8] != 0) {
        LOCK();
        piVar1 = (int *)(param_1[8] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      uStack_c0 = param_1[7];
      uStack_bc = param_1[8];
      if (param_1[6] != 0) {
        LOCK();
        piVar1 = (int *)(param_1[6] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      uStack_c8 = param_1[5];
      uStack_c4 = param_1[6];
      if (param_1[4] != 0) {
        LOCK();
        piVar1 = (int *)(param_1[4] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      uStack_d0 = param_1[3];
      pcStack_d4 = FUN_00b28bb0;
      uStack_cc = param_1[4];
      uStack_18 = uStack_b8;
      uStack_14 = uStack_b4;
      FUN_00b14500(&uStack_ac);
      uStack_b0 = 0xb1ae8e;
      FUN_00b115d0();
      puStack_20 = auStack_a0;
      uStack_8._0_1_ = 3;
      uStack_a4 = 0;
      if (param_1[8] != 0) {
        LOCK();
        piVar1 = (int *)(param_1[8] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      uVar3 = param_1[7];
      uVar4 = param_1[8];
      if (param_1[6] != 0) {
        LOCK();
        piVar1 = (int *)(param_1[6] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      uVar5 = param_1[5];
      uVar6 = param_1[6];
      if (param_1[4] != 0) {
        LOCK();
        piVar1 = (int *)(param_1[4] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_00b14350(&pcStack_d4,FUN_00b28ce0,param_1[3],param_1[4],uVar5,uVar6,uVar3,uVar4,uStack_18,
                   uStack_14,iStack_28,uStack_24);
      FUN_00b11460();
      uStack_a4 = uStack_2c;
      uStack_a8 = uStack_14;
      uStack_8._0_1_ = 2;
      uStack_ac = uStack_18;
      uStack_b0 = 0xb1af4c;
      iVar7 = (*pcStack_34)();
      if (piStack_50 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_50 + 1;
        iVar2 = *piVar1;
        iVar7 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          piStack_64 = (int *)0xb1af62;
          (**(code **)*piStack_50)();
          LOCK();
          piVar1 = piStack_50 + 2;
          iVar2 = *piVar1;
          iVar7 = *piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            piStack_64 = (int *)0xb1af72;
            iVar7 = (**(code **)(*piStack_50 + 4))();
          }
        }
      }
    }
    if (piStack_48 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_48 + 1;
      iVar2 = *piVar1;
      iVar7 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piStack_64 = (int *)0xb1af88;
        (**(code **)*piStack_48)();
        LOCK();
        piVar1 = piStack_48 + 2;
        iVar2 = *piVar1;
        iVar7 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          piStack_64 = (int *)0xb1af98;
          iVar7 = (**(code **)(*piStack_48 + 4))();
        }
      }
    }
  }
  if (piStack_40 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_40 + 1;
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_64 = (int *)0xb1afae;
      iVar7 = (**(code **)*piStack_40)();
      LOCK();
      piVar1 = piStack_40 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_64 = (int *)0xb1afbd;
        iVar7 = (**(code **)(*piStack_40 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 23477 ; VA 0x00b1afd0 ; FUN_00b1afd0 */

/* WARNING: Removing unreachable block (ram,0x00b1b07a) */
/* WARNING: Removing unreachable block (ram,0x00b1b086) */
/* WARNING: Removing unreachable block (ram,0x00b1b094) */

void __thiscall FUN_00b1afd0(uint *param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  code *pcVar1;
  uint in_stack_0000002c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eefe8;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if (*param_1 == 0) {
    ExceptionList = &pvStack_10;
    FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0();
  }
  pcVar1 = *(code **)((*param_1 & 0xfffffffe) + 4);
  ExceptionList = &pvStack_10;
  FUN_005880d0();
  uStack_8._0_1_ = 4;
  FUN_005880d0(&param_4);
  uStack_8._0_1_ = 2;
  (*pcVar1)(param_1 + 2,param_2,param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))();
    }
    param_4 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23478 ; VA 0x00b1b120 ; FUN_00b1b120 */

int __thiscall
FUN_00b1b120(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ef008;
  pvStack_10 = ExceptionList;
  pcVar3 = (code *)*param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  iVar4 = (*pcVar3)(param_3,param_4,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 23479 ; VA 0x00b1b1c0 ; FUN_00b1b1c0 */

void __thiscall FUN_00b1b1c0(undefined4 *param_1,undefined4 param_2,uint param_3)

{
  code *pcVar1;
  undefined uVar2;
  uint *puVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 *in_stack_00000034;
  ulonglong in_stack_00000038;
  uint in_stack_00000040;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined8 in_stack_00000058;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  ulonglong uStack_48;
  uint auStack_40 [2];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ef048;
  pvStack_10 = ExceptionList;
  param_2 = auStack_40;
  pcVar1 = (code *)*param_1;
  uStack_8 = 2;
  auStack_40[0] = 0;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_40;
  if (in_stack_00000040 != 0) {
    auStack_40[0] = in_stack_00000040;
    if ((in_stack_00000040 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = &stack0x00000048;
      uStack_50 = 0xb1b230;
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000040 & 0xfffffffe))();
      puVar3 = param_2;
    }
    else {
      uStack_38 = in_stack_00000048;
      uStack_34 = in_stack_0000004c;
      uStack_30 = in_stack_00000050;
      uStack_2c = in_stack_00000054;
      uStack_28 = in_stack_00000058;
      ExceptionList = &pvStack_10;
      puVar3 = auStack_40;
    }
  }
  param_2 = puVar3;
  uStack_8._0_1_ = 3;
  if (in_stack_00000020 != 0) {
    if ((in_stack_00000020 & 1) == 0) {
      (**(code **)(in_stack_00000020 & 0xfffffffe))(&stack0x00000028,&uStack_58,0);
    }
    else {
      uStack_58 = in_stack_00000028;
      uStack_54 = in_stack_0000002c;
      uStack_50 = in_stack_00000030;
      puStack_4c = in_stack_00000034;
      uStack_48 = in_stack_00000038;
    }
  }
  uStack_8._0_1_ = 4;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 2;
  (*pcVar1)();
  uStack_8._0_1_ = 1;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    uVar4 = param_3;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(param_3 - 4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_3 - uVar4) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (in_stack_00000020 != 0) {
    if (((in_stack_00000020 & 1) == 0) &&
       (*(code **)(in_stack_00000020 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000020 & 0xfffffffe))(&stack0x00000028,&stack0x00000028,2);
    }
    in_stack_00000020 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_00000040 != 0) && ((in_stack_00000040 & 1) == 0)) &&
     (*(code **)(in_stack_00000040 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000040 & 0xfffffffe))(&stack0x00000048,&stack0x00000048,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23480 ; VA 0x00b1b350 ; FUN_00b1b350 */

void __thiscall FUN_00b1b350(undefined4 *param_1,undefined4 param_2,uint param_3)

{
  code *pcVar1;
  int iVar2;
  uint *puVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  uint in_stack_00000028;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined4 in_stack_0000003c;
  undefined8 in_stack_00000040;
  uint auStack_40 [2];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ef088;
  pvStack_10 = ExceptionList;
  param_2 = auStack_40;
  pcVar1 = (code *)*param_1;
  uStack_8 = 2;
  auStack_40[0] = 0;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_40;
  if (in_stack_00000028 != 0) {
    auStack_40[0] = in_stack_00000028;
    if ((in_stack_00000028 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000028 & 0xfffffffe))(&stack0x00000030);
      puVar3 = param_2;
    }
    else {
      uStack_38 = in_stack_00000030;
      uStack_34 = in_stack_00000034;
      uStack_30 = in_stack_00000038;
      uStack_2c = in_stack_0000003c;
      uStack_28 = in_stack_00000040;
      ExceptionList = &pvStack_10;
      puVar3 = auStack_40;
    }
  }
  param_2 = puVar3;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    in_stack_00000024[2] = in_stack_00000024[2] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 4;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 2;
  (*pcVar1)();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    uVar4 = param_3;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(param_3 - 4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_3 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000024[2] + -1;
    in_stack_00000024[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*in_stack_00000024 + 4))();
    }
  }
  uStack_8 = 5;
  if (((in_stack_00000028 != 0) && ((in_stack_00000028 & 1) == 0)) &&
     (*(code **)(in_stack_00000028 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000028 & 0xfffffffe))(&stack0x00000030,&stack0x00000030,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23481 ; VA 0x00b1b4b0 ; FUN_00b1b4b0 */

void __thiscall FUN_00b1b4b0(undefined4 *param_1,undefined4 param_2,int param_3)

{
  code *pcVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  pcVar1 = (code *)*param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_3);
  (*pcVar1)();
  if (0xf < in_stack_0000001c) {
    uVar3 = in_stack_0000001c + 1;
    iVar2 = param_3;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_3 + -4);
      uVar3 = in_stack_0000001c + 0x24;
      if (0x1f < (param_3 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23482 ; VA 0x00b1b540 ; FUN_00b1b540 */

void __thiscall FUN_00b1b540(undefined4 *param_1,undefined4 param_2,uint param_3)

{
  code *pcVar1;
  int iVar2;
  undefined uVar3;
  uint *puVar4;
  uint uVar5;
  uint uVar6;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000030;
  uint in_stack_00000034;
  undefined4 in_stack_00000038;
  int *in_stack_0000003c;
  uint in_stack_00000040;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined8 in_stack_00000058;
  uint in_stack_00000060;
  undefined4 in_stack_00000068;
  undefined4 in_stack_0000006c;
  undefined4 in_stack_00000070;
  undefined4 in_stack_00000074;
  undefined8 in_stack_00000078;
  uint auStack_48 [2];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ef0e8;
  pvStack_10 = ExceptionList;
  param_2 = auStack_48;
  pcVar1 = (code *)*param_1;
  uStack_8 = 4;
  auStack_48[0] = 0;
  ExceptionList = &pvStack_10;
  puVar4 = auStack_48;
  if (in_stack_00000060 != 0) {
    auStack_48[0] = in_stack_00000060;
    if ((in_stack_00000060 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000060 & 0xfffffffe))();
      puVar4 = param_2;
    }
    else {
      uStack_40 = in_stack_00000068;
      uStack_3c = in_stack_0000006c;
      uStack_38 = in_stack_00000070;
      uStack_34 = in_stack_00000074;
      uStack_30 = in_stack_00000078;
      ExceptionList = &pvStack_10;
      puVar4 = auStack_48;
    }
  }
  param_2 = puVar4;
  uStack_8._0_1_ = 5;
  if ((in_stack_00000040 != 0) && ((in_stack_00000040 & 1) == 0)) {
    (**(code **)(in_stack_00000040 & 0xfffffffe))();
  }
  if (in_stack_0000003c != (int *)0x0) {
    LOCK();
    in_stack_0000003c[2] = in_stack_0000003c[2] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 7;
  FUN_0054ef60(&stack0x00000020);
  uStack_8._0_1_ = 8;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 4;
  (*pcVar1)();
  uStack_8._0_1_ = 3;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < in_stack_0000001c) {
    uVar6 = in_stack_0000001c + 1;
    uVar5 = param_3;
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(param_3 - 4);
      uVar6 = in_stack_0000001c + 0x24;
      if (0x1f < (param_3 - uVar5) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (0xf < in_stack_00000034) {
    uVar6 = in_stack_00000034 + 1;
    uVar5 = in_stack_00000020;
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(in_stack_00000020 - 4);
      uVar6 = in_stack_00000034 + 0x24;
      if (0x1f < (in_stack_00000020 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  in_stack_00000030 = 0;
  in_stack_00000034 = 0xf;
  in_stack_00000020 = in_stack_00000020 & 0xffffff00;
  if (in_stack_0000003c != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_0000003c[2] + -1;
    in_stack_0000003c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*in_stack_0000003c + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  if (in_stack_00000040 != 0) {
    if (((in_stack_00000040 & 1) == 0) &&
       (*(code **)(in_stack_00000040 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000040 & 0xfffffffe))(&stack0x00000048,&stack0x00000048,2);
    }
    in_stack_00000040 = 0;
  }
  uStack_8 = 10;
  if (((in_stack_00000060 != 0) && ((in_stack_00000060 & 1) == 0)) &&
     (*(code **)(in_stack_00000060 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000060 & 0xfffffffe))(&stack0x00000068,&stack0x00000068,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23483 ; VA 0x00b1b780 ; FUN_00b1b780 */

/* WARNING: Removing unreachable block (ram,0x00b1b7d2) */
/* WARNING: Removing unreachable block (ram,0x00b1b7e2) */
/* WARNING: Removing unreachable block (ram,0x00b1b7e8) */

void * __thiscall FUN_00b1b780(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ef118;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 23484 ; VA 0x00b1b853 ; Catch@00b1b853 */

undefined * Catch_00b1b853(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00b1b864;
}



/* FUNCTION 23485 ; VA 0x00b1b880 ; FUN_00b1b880 */

/* WARNING: Removing unreachable block (ram,0x00b1b98e) */
/* WARNING: Removing unreachable block (ram,0x00b1b99e) */
/* WARNING: Removing unreachable block (ram,0x00b1b9a4) */

void * __thiscall FUN_00b1b880(int *param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  void *pvVar3;
  uint in_stack_00000020;
  int in_stack_00000024;
  uint in_stack_00000038;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ef160;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_01675290();
    uStack_8._0_1_ = 5;
    FUN_005e6300();
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    FUN_01675290();
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar2 = param_3[1] + -1;
      param_3[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_3)();
        LOCK();
        piVar1 = param_3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_3 + 4))();
        }
      }
    }
    FUN_005507b0();
    pvVar3 = (void *)FUN_005507b0();
    ExceptionList = pvStack_10;
    return pvVar3;
  }
  pvVar3 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar3 = (void *)*piVar1;
    ExceptionList = &pvStack_10;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar3 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar3 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000020) {
    if ((0xfff < in_stack_00000020 + 1) && (0x1f < (param_4 - *(int *)(param_4 + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    pvVar3 = (void *)FUN_01674ea0();
  }
  if (0xf < in_stack_00000038) {
    if ((0xfff < in_stack_00000038 + 1) &&
       (0x1f < (in_stack_00000024 - *(int *)(in_stack_00000024 + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    pvVar3 = (void *)FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return pvVar3;
}



/* FUNCTION 23486 ; VA 0x00b1ba49 ; Catch@00b1ba49 */

undefined * Catch_00b1ba49(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x28));
  return &DAT_00b1ba5a;
}



/* FUNCTION 23487 ; VA 0x00b1ba80 ; FUN_00b1ba80 */

/* WARNING: Removing unreachable block (ram,0x00b1bb41) */
/* WARNING: Removing unreachable block (ram,0x00b1bb51) */
/* WARNING: Removing unreachable block (ram,0x00b1bb57) */

void * __thiscall FUN_00b1ba80(int *param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  void *pvVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_00000020;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ef190;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 4;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    FUN_01675290(uVar3);
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar4 = param_3[1] + -1;
      param_3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*param_3)();
        LOCK();
        piVar1 = param_3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*param_3 + 4))();
        }
      }
    }
    pvVar2 = (void *)FUN_005507b0();
    ExceptionList = pvStack_10;
    return pvVar2;
  }
  pvVar2 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar4 = *piVar1;
    pvVar2 = (void *)*piVar1;
    ExceptionList = &pvStack_10;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      pvVar2 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        pvVar2 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000020) {
    uVar5 = in_stack_00000020 + 1;
    iVar4 = param_4;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_4 + -4);
      uVar5 = in_stack_00000020 + 0x24;
      if (0x1f < (param_4 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    pvVar2 = (void *)FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return pvVar2;
}



/* FUNCTION 23488 ; VA 0x00b1bbd8 ; Catch@00b1bbd8 */

undefined * Catch_00b1bbd8(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00b1bbe9;
}



/* FUNCTION 23489 ; VA 0x00b1bc10 ; FUN_00b1bc10 */

/* WARNING: Removing unreachable block (ram,0x00b1bc62) */
/* WARNING: Removing unreachable block (ram,0x00b1bc72) */
/* WARNING: Removing unreachable block (ram,0x00b1bc78) */

void * __thiscall FUN_00b1bc10(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ef1b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 23490 ; VA 0x00b1bce9 ; Catch@00b1bce9 */

undefined * Catch_00b1bce9(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00b1bcfa;
}



/* FUNCTION 23491 ; VA 0x00b1bd10 ; FUN_00b1bd10 */

/* WARNING: Removing unreachable block (ram,0x00b1bd62) */
/* WARNING: Removing unreachable block (ram,0x00b1bd72) */
/* WARNING: Removing unreachable block (ram,0x00b1bd78) */

void * __thiscall FUN_00b1bd10(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ef1e8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 23492 ; VA 0x00b1bdec ; Catch@00b1bdec */

undefined * Catch_00b1bdec(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00b1bdfd;
}



/* FUNCTION 23493 ; VA 0x00b1be10 ; FUN_00b1be10 */

/* WARNING: Removing unreachable block (ram,0x00b1be62) */
/* WARNING: Removing unreachable block (ram,0x00b1be72) */
/* WARNING: Removing unreachable block (ram,0x00b1be78) */

void * __thiscall FUN_00b1be10(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ef218;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 23494 ; VA 0x00b1beef ; Catch@00b1beef */

undefined * Catch_00b1beef(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00b1bf00;
}



/* FUNCTION 23495 ; VA 0x00b1bf20 ; FUN_00b1bf20 */

/* WARNING: Removing unreachable block (ram,0x00b1bf7a) */
/* WARNING: Removing unreachable block (ram,0x00b1bf8a) */
/* WARNING: Removing unreachable block (ram,0x00b1bf90) */

void __fastcall FUN_00b1bf20(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef240;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8 = 2;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = 4;
    FUN_01675290(uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23496 ; VA 0x00b1bfd5 ; Catch@00b1bfd5 */

undefined * Catch_00b1bfd5(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x20));
  return &DAT_00b1bfe6;
}



/* FUNCTION 23497 ; VA 0x00b1c000 ; FUN_00b1c000 */

int __thiscall FUN_00b1c000(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),8);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),8);
  }
  FUN_005c4ac0();
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 23498 ; VA 0x00b1c060 ; FUN_00b1c060 */

undefined4 __thiscall FUN_00b1c060(undefined4 param_1,byte param_2)

{
  FUN_00b194d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 23499 ; VA 0x00b1c090 ; FUN_00b1c090 */

undefined4 __thiscall FUN_00b1c090(undefined4 param_1,byte param_2)

{
  FUN_00b19530();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}


