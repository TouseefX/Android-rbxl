/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 11250 ; VA 0x0078b070 ; FUN_0078b070 */

void __thiscall FUN_0078b070(int param_1,char *param_2)

{
  undefined8 uVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  uint *puVar5;
  undefined4 *puVar6;
  undefined4 ****ppppuVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  char *pcVar10;
  int iVar11;
  char *pcVar12;
  int iVar13;
  undefined4 ****ppppuVar14;
  uint uVar15;
  uint uVar16;
  undefined *puVar17;
  undefined auStack_d0 [16];
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined uStack_b8;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined uStack_a0;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  int aiStack_84 [5];
  uint uStack_70;
  undefined4 ***pppuStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined8 uStack_5c;
  undefined4 ***apppuStack_54 [4];
  undefined4 uStack_44;
  uint uStack_40;
  code *pcStack_3c;
  int iStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  int iStack_1c;
  undefined4 ***pppuStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0d78;
  pvStack_10 = ExceptionList;
  pppuStack_18 = (undefined4 ****)0x0;
  pcVar10 = param_2;
  if (0xf < *(uint *)(param_2 + 0x14)) {
    pcVar10 = *(char **)param_2;
  }
  if (*(int *)(param_2 + 0x10) == 0) {
LAB_0078b0ce:
    iVar13 = -1;
  }
  else {
    iVar4 = *(int *)(param_2 + 0x10) + -1;
    iVar13 = -1;
    if (iVar4 != -1) {
      iVar13 = iVar4;
    }
    pcVar12 = pcVar10 + iVar13;
    cVar3 = *pcVar12;
    while (cVar3 != '/') {
      if (pcVar12 == pcVar10) goto LAB_0078b0ce;
      pcVar12 = pcVar12 + -1;
      cVar3 = *pcVar12;
    }
    iVar13 = (int)pcVar12 - (int)pcVar10;
  }
  uVar15 = iVar13 + 1;
  uStack_44 = 0;
  uStack_40 = 0xf;
  apppuStack_54[0] = (undefined4 ***)((uint)apppuStack_54[0] & 0xffffff00);
  iStack_1c = param_1;
  if (*(uint *)(param_2 + 0x10) < uVar15) {
    ExceptionList = &pvStack_10;
    FUN_00554050();
LAB_0078b654:
                    /* WARNING: Subroutine does not return */
    FUN_017167a3();
  }
  iVar4 = *(uint *)(param_2 + 0x10) - uVar15;
  iVar13 = -1;
  if (iVar4 != -1) {
    iVar13 = iVar4;
  }
  pcVar10 = param_2;
  if (0xf < *(uint *)(param_2 + 0x14)) {
    pcVar10 = *(char **)param_2;
  }
  ExceptionList = &pvStack_10;
  FUN_005542c0(pcVar10 + uVar15,iVar13);
  uStack_8 = 0;
  (**(code **)(**(int **)(param_1 + 0x3c) + 0x30))(aiStack_84);
  uStack_8._0_1_ = 1;
  puVar5 = (uint *)FUN_00585d40(0,"shaders_",8);
  uStack_34 = *puVar5;
  uStack_30 = puVar5[1];
  uStack_2c = puVar5[2];
  uStack_28 = puVar5[3];
  uStack_24 = *(undefined8 *)(puVar5 + 4);
  puVar5[4] = 0;
  puVar5[5] = 0xf;
  *(undefined *)puVar5 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puVar6 = (undefined4 *)FUN_00554150(".pack",5);
  pppuStack_6c = (undefined4 ***)*puVar6;
  uStack_68 = puVar6[1];
  uStack_64 = puVar6[2];
  uStack_60 = puVar6[3];
  uVar1 = *(undefined8 *)(puVar6 + 4);
  puVar6[4] = 0;
  puVar6[5] = 0xf;
  *(undefined *)puVar6 = 0;
  uStack_5c._4_4_ = (uint)((ulonglong)uVar1 >> 0x20);
  uStack_5c._0_4_ = (undefined4)uVar1;
  ppppuVar14 = &pppuStack_6c;
  if (0xf < uStack_5c._4_4_) {
    ppppuVar14 = (undefined4 ****)pppuStack_6c;
  }
  ppppuVar7 = apppuStack_54;
  if (0xf < uStack_40) {
    ppppuVar7 = (undefined4 ****)apppuStack_54[0];
  }
  uVar8 = (undefined4)uStack_5c;
  uStack_5c = uVar1;
  pppuStack_18 = pppuStack_6c;
  cStack_11 = FUN_0055c360(ppppuVar7,uStack_44,ppppuVar14,uVar8);
  if (0xf < uStack_5c._4_4_) {
    uVar15 = uStack_5c._4_4_ + 1;
    ppppuVar14 = (undefined4 ****)pppuStack_18;
    if (0xfff < uVar15) {
      ppppuVar14 = (undefined4 ****)pppuStack_18[-1];
      uVar15 = uStack_5c._4_4_ + 0x24;
      if ((undefined *)0x1f < (undefined *)((int)pppuStack_18 + (-4 - (int)ppppuVar14)))
      goto LAB_0078b654;
    }
    FUN_01674ea0(ppppuVar14,uVar15);
  }
  uStack_8._0_1_ = 1;
  if (0xf < uStack_24._4_4_) {
    uVar16 = uStack_24._4_4_ + 1;
    uVar15 = uStack_34;
    if (0xfff < uVar16) {
      uVar15 = *(uint *)(uStack_34 - 4);
      uVar16 = uStack_24._4_4_ + 0x24;
      if (0x1f < (uStack_34 - uVar15) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar15,uVar16);
  }
  uStack_24 = 0xf00000000;
  uStack_34 = uStack_34 & 0xffffff00;
  uStack_8._0_1_ = 0;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_70) {
    uVar15 = uStack_70 + 1;
    iVar13 = aiStack_84[0];
    if (0xfff < uVar15) {
      iVar13 = *(int *)(aiStack_84[0] + -4);
      uVar15 = uStack_70 + 0x24;
      if (0x1f < (aiStack_84[0] - iVar13) - 4U) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar13,uVar15);
  }
  if (cStack_11 == '\0') {
    iVar13 = FUN_0058eea0("rbxasset://",0);
    if (((iVar13 == 0) || (iVar13 = FUN_0058eea0(&DAT_018db19c,0), iVar13 == 0)) ||
       (iVar13 = FUN_0058eea0("rbxapp://",0), iVar13 == 0)) {
      pcVar10 = param_2;
      if (0xf < *(uint *)(param_2 + 0x14)) {
        pcVar10 = *(char **)param_2;
      }
      cVar3 = FUN_0055c360(pcVar10,*(undefined4 *)(param_2 + 0x10),
                           "rbxasset://textures/materials.json",0x22);
      if (cVar3 == '\0') {
        pcVar10 = param_2;
        if (0xf < *(uint *)(param_2 + 0x14)) {
          pcVar10 = *(char **)param_2;
        }
        cVar3 = FUN_0055c360(pcVar10,*(undefined4 *)(param_2 + 0x10),
                             "rbxasset://terrain/materials.json",0x21);
        if (((cVar3 != '\0') && (iVar13 = FUN_00a9d3e0(), iVar13 != 0)) &&
           (iVar4 = *(int *)(iVar13 + 0xc), iVar11 = FUN_00af0010(),
           (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar11 + 0x1d8) <=
           (uint)*(ushort *)(iVar11 + 0x1da))) {
          pppuStack_18 = (undefined4 ***)FUN_008f7870(iVar13);
          pcStack_3c = FUN_0078c4e0;
          iStack_38 = iVar13;
          cVar3 = FUN_00585a40(&pcStack_3c);
          if (cVar3 == '\0') {
            puVar17 = &DAT_018fce29;
          }
          else {
            puVar17 = (undefined *)0x0;
          }
          FUN_0090ca30(puVar17);
        }
      }
      else {
        pppuStack_18 = (undefined4 ***)FUN_01674e20(0xfc0);
        uStack_8._0_1_ = 5;
        if (pppuStack_18 == (undefined4 ***)0x0) {
          uVar8 = 0;
        }
        else {
          uVar8 = FUN_0078e6a0();
        }
        iVar13 = *(int *)(param_1 + 0x5a8);
        uStack_8._0_1_ = 0;
        *(undefined4 *)(param_1 + 0x5a8) = uVar8;
        if (iVar13 != 0) {
          uStack_8._0_1_ = 6;
          FUN_016f32d1(iVar13,0xa8,0x18,FUN_00789520);
          uStack_8._0_1_ = 0;
          FUN_01674ea0(iVar13,0xfc0);
        }
        *(undefined *)(*(int *)(param_1 + 0x4e4) + 0x211) = 1;
        pppuStack_18 = (undefined4 ***)FUN_01674e20(&LAB_0051dda8);
        uStack_8._0_1_ = 7;
        if ((undefined4 ****)pppuStack_18 == (undefined4 ****)0x0) {
          uVar8 = 0;
        }
        else {
          uVar8 = FUN_0075d8e0(param_1);
        }
        iVar13 = *(int *)(param_1 + 0x54c);
        *(undefined4 *)(param_1 + 0x54c) = uVar8;
        if (iVar13 != 0) {
          FUN_00789f40(1);
        }
      }
      uStack_c0 = 0;
      uStack_bc = 0xf;
      auStack_d0[0] = 0;
      uStack_a8 = 0;
      uStack_a4 = 0xf;
      uStack_b8 = 0;
      uStack_90 = 0;
      uStack_8c = 0xf;
      uStack_a0 = 0;
      uStack_8._0_1_ = 8;
      FUN_0054ef60(param_2);
      uStack_8._0_1_ = 9;
      FUN_009cbbb0(&pppuStack_6c);
      uStack_8._0_1_ = 10;
      FUN_00786660(&pppuStack_6c,auStack_d0,0);
      FUN_005507b0();
      FUN_00637950();
    }
  }
  else {
    iStack_1c = *(int *)(param_1 + 0x4f4);
    uVar8 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x30))(aiStack_84);
    uStack_8._0_1_ = 3;
    puVar9 = (undefined4 *)FUN_008c8420();
    uStack_24._0_4_ = 0;
    uStack_24._4_4_ = 0xf;
    uStack_34 = uStack_34 & 0xffffff00;
    uStack_8._0_1_ = 4;
    pppuStack_18 = (undefined4 ***)&DAT_0000000f;
    FUN_0058a190(puVar9[4] + 10);
    puVar6 = puVar9 + 4;
    if (0xf < (uint)puVar9[5]) {
      puVar9 = (undefined4 *)*puVar9;
    }
    FUN_00554150(puVar9,*puVar6);
    FUN_00554150("../shaders",10);
    FUN_00791300(&uStack_34,uVar8,param_1 + 0x5ac,1);
    if (0xf < uStack_24._4_4_) {
      uVar16 = uStack_24._4_4_ + 1;
      uVar15 = uStack_34;
      if (0xfff < uVar16) {
        uVar15 = *(uint *)(uStack_34 - 4);
        uVar16 = uStack_24._4_4_ + 0x24;
        if (0x1f < (uStack_34 - uVar15) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar15,uVar16);
    }
    uStack_24 = 0xf00000000;
    uStack_34 = uStack_34 & 0xffffff00;
    if (0xf < uStack_70) {
      uVar15 = uStack_70 + 1;
      iVar13 = aiStack_84[0];
      if (0xfff < uVar15) {
        iVar13 = *(int *)(aiStack_84[0] + -4);
        uVar15 = uStack_70 + 0x24;
        if (0x1f < (aiStack_84[0] - iVar13) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar13,uVar15);
    }
  }
  if (0xf < uStack_40) {
    uVar15 = uStack_40 + 1;
    ppppuVar14 = (undefined4 ****)apppuStack_54[0];
    if (0xfff < uVar15) {
      ppppuVar14 = (undefined4 ****)apppuStack_54[0][-1];
      uVar15 = uStack_40 + 0x24;
      if (0x1f < (uint)((int)apppuStack_54[0] + (-4 - (int)ppppuVar14))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar14,uVar15);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11251 ; VA 0x0078b680 ; FUN_0078b680 */

undefined __fastcall FUN_0078b680(int param_1)

{
  char cVar1;
  int iVar2;
  undefined4 ****ppppuVar3;
  undefined uVar4;
  uint uVar5;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x3c) + 0x30))(apppuStack_28);
  uStack_8 = 0;
  if ((DAT_01d60f98 == '\0') ||
     (iVar2 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x24))(), iVar2 != 0)) {
LAB_0078b779:
    uVar4 = 0;
  }
  else {
    ppppuVar3 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar3 = (undefined4 ****)apppuStack_28[0];
    }
    cVar1 = FUN_0055c360(ppppuVar3,uStack_18,"d3d11_durango",0xd);
    if (cVar1 == '\0') {
      ppppuVar3 = apppuStack_28;
      if (0xf < uStack_14) {
        ppppuVar3 = (undefined4 ****)apppuStack_28[0];
      }
      cVar1 = FUN_0055c360(ppppuVar3,uStack_18,"d3d11",5);
      if (cVar1 == '\0') {
        ppppuVar3 = apppuStack_28;
        if (0xf < uStack_14) {
          ppppuVar3 = (undefined4 ****)apppuStack_28[0];
        }
        cVar1 = FUN_0055c360(ppppuVar3,uStack_18,"d3d10_1",7);
        if (cVar1 == '\0') {
          ppppuVar3 = apppuStack_28;
          if (0xf < uStack_14) {
            ppppuVar3 = (undefined4 ****)apppuStack_28[0];
          }
          cVar1 = FUN_0055c360(ppppuVar3,uStack_18,"metal_osx",9);
          if (cVar1 == '\0') {
            ppppuVar3 = apppuStack_28;
            if (0xf < uStack_14) {
              ppppuVar3 = (undefined4 ****)apppuStack_28[0];
            }
            cVar1 = FUN_0055c360(ppppuVar3,uStack_18,"vulkan_desktop",0xe);
            if (cVar1 == '\0') goto LAB_0078b779;
          }
        }
      }
    }
    uVar4 = 1;
  }
  if (0xf < uStack_14) {
    uVar5 = uStack_14 + 1;
    ppppuVar3 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar5) {
      ppppuVar3 = (undefined4 ****)((undefined4 ****)apppuStack_28[0])[-1];
      uVar5 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 11252 ; VA 0x0078b7c0 ; FUN_0078b7c0 */

void __fastcall FUN_0078b7c0(int param_1)

{
  FUN_009d7ee0(*(undefined4 *)(param_1 + 0x5c4));
  return;
}



/* FUNCTION 11253 ; VA 0x0078b7d0 ; FUN_0078b7d0 */

undefined __fastcall FUN_0078b7d0(int param_1)

{
  char cVar1;
  int iVar2;
  undefined4 ****ppppuVar3;
  undefined uVar4;
  undefined4 uVar5;
  undefined4 ****ppppuVar6;
  uint uVar7;
  undefined4 ***apppuStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  (**(code **)(**(int **)(param_1 + 0x3c) + 0x30))(apppuStack_2c);
  uVar7 = uStack_18;
  uVar5 = uStack_1c;
  ppppuVar6 = (undefined4 ****)apppuStack_2c[0];
  ppppuVar3 = apppuStack_2c;
  if (0xf < uStack_18) {
    ppppuVar3 = (undefined4 ****)apppuStack_2c[0];
  }
  uStack_8 = 0;
  cVar1 = FUN_0055c360(ppppuVar3,uStack_1c,"d3d11_durango",0xd);
  if (cVar1 == '\0') {
    ppppuVar3 = apppuStack_2c;
    if (0xf < uVar7) {
      ppppuVar3 = ppppuVar6;
    }
    cVar1 = FUN_0055c360(ppppuVar3,uVar5,"d3d10",5);
    if (cVar1 == '\0') {
      ppppuVar3 = apppuStack_2c;
      if (0xf < uVar7) {
        ppppuVar3 = ppppuVar6;
      }
      cVar1 = FUN_0055c360(ppppuVar3,uVar5,"d3d10_1",7);
      if (cVar1 == '\0') {
        ppppuVar3 = apppuStack_2c;
        if (0xf < uVar7) {
          ppppuVar3 = ppppuVar6;
        }
        cVar1 = FUN_0055c360(ppppuVar3,uVar5,"d3d11",5);
        if (cVar1 == '\0') {
          ppppuVar3 = apppuStack_2c;
          if (0xf < uVar7) {
            ppppuVar3 = ppppuVar6;
          }
          cVar1 = FUN_0055c360(ppppuVar3,uVar5,"metal_osx",9);
          if (cVar1 == '\0') {
            ppppuVar3 = apppuStack_2c;
            if (0xf < uVar7) {
              ppppuVar3 = ppppuVar6;
            }
            cVar1 = FUN_0055c360(ppppuVar3,uVar5,"metal_ios",9);
            if ((cVar1 == '\0') ||
               (iVar2 = (**(code **)(**(int **)(iStack_14 + 0x3c) + 0x40))(), uVar5 = uStack_1c,
               ppppuVar6 = (undefined4 ****)apppuStack_2c[0], uVar7 = uStack_18,
               *(int *)(iVar2 + 0x34) == 0)) {
              ppppuVar3 = apppuStack_2c;
              if (0xf < uVar7) {
                ppppuVar3 = ppppuVar6;
              }
              cVar1 = FUN_0055c360(ppppuVar3,uVar5,"vulkan_mobile",0xd);
              if (cVar1 == '\0') {
                ppppuVar3 = apppuStack_2c;
                if (0xf < uVar7) {
                  ppppuVar3 = ppppuVar6;
                }
                cVar1 = FUN_0055c360(ppppuVar3,uVar5,"vulkan_desktop",0xe);
                if (cVar1 == '\0') {
                  ppppuVar3 = apppuStack_2c;
                  if (0xf < uVar7) {
                    ppppuVar3 = ppppuVar6;
                  }
                  cVar1 = FUN_0055c360(ppppuVar3,uVar5,"glsl3",5);
                  if ((cVar1 == '\0') || (DAT_01d60e58 == '\0')) {
                    ppppuVar3 = apppuStack_2c;
                    if (0xf < uVar7) {
                      ppppuVar3 = ppppuVar6;
                    }
                    cVar1 = FUN_0055c360(ppppuVar3,uVar5,"glsles3",7);
                    if ((cVar1 == '\0') || (DAT_01d60e60 == '\0')) {
                      uVar4 = 0;
                      apppuStack_2c[0] = ppppuVar6;
                      uStack_18 = uVar7;
                      goto LAB_0078b9b1;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  iVar2 = (**(code **)(**(int **)(iStack_14 + 0x3c) + 0x40))();
  if ((*(uint *)(iVar2 + 0x2c) < 0xc) ||
     (iVar2 = (**(code **)(**(int **)(iStack_14 + 0x3c) + 0x40))(), *(char *)(iVar2 + 1) == '\0')) {
    uVar4 = 0;
  }
  else {
    uVar4 = 1;
  }
LAB_0078b9b1:
  if (0xf < uStack_18) {
    uVar7 = uStack_18 + 1;
    ppppuVar6 = (undefined4 ****)apppuStack_2c[0];
    if (0xfff < uVar7) {
      ppppuVar6 = (undefined4 ****)((undefined4 ****)apppuStack_2c[0])[-1];
      uVar7 = uStack_18 + 0x24;
      if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar6,uVar7);
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 11254 ; VA 0x0078ba00 ; FUN_0078ba00 */

undefined __fastcall FUN_0078ba00(int param_1)

{
  char cVar1;
  int iVar2;
  undefined4 ****ppppuVar3;
  undefined uVar4;
  undefined4 uVar5;
  undefined4 ****ppppuVar6;
  uint uVar7;
  undefined4 ***apppuStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  (**(code **)(**(int **)(param_1 + 0x3c) + 0x30))(apppuStack_2c);
  uVar7 = uStack_18;
  uVar5 = uStack_1c;
  ppppuVar6 = (undefined4 ****)apppuStack_2c[0];
  ppppuVar3 = apppuStack_2c;
  if (0xf < uStack_18) {
    ppppuVar3 = (undefined4 ****)apppuStack_2c[0];
  }
  uStack_8 = 0;
  cVar1 = FUN_0055c360(ppppuVar3,uStack_1c,"d3d11_durango",0xd);
  if (cVar1 == '\0') {
    ppppuVar3 = apppuStack_2c;
    if (0xf < uVar7) {
      ppppuVar3 = ppppuVar6;
    }
    cVar1 = FUN_0055c360(ppppuVar3,uVar5,"d3d11",5);
    if (cVar1 == '\0') {
      ppppuVar3 = apppuStack_2c;
      if (0xf < uVar7) {
        ppppuVar3 = ppppuVar6;
      }
      cVar1 = FUN_0055c360(ppppuVar3,uVar5,"metal_osx",9);
      if (cVar1 == '\0') {
        ppppuVar3 = apppuStack_2c;
        if (0xf < uVar7) {
          ppppuVar3 = ppppuVar6;
        }
        cVar1 = FUN_0055c360(ppppuVar3,uVar5,"metal_ios",9);
        if (((cVar1 == '\0') ||
            (iVar2 = (**(code **)(**(int **)(iStack_14 + 0x3c) + 0x40))(), uVar5 = uStack_1c,
            ppppuVar6 = (undefined4 ****)apppuStack_2c[0], uVar7 = uStack_18,
            *(int *)(iVar2 + 0x34) == 0)) || (DAT_01d60e70 == '\0')) {
          ppppuVar3 = apppuStack_2c;
          if (0xf < uVar7) {
            ppppuVar3 = ppppuVar6;
          }
          cVar1 = FUN_0055c360(ppppuVar3,uVar5,"vulkan_desktop",0xe);
          if (cVar1 == '\0') {
            ppppuVar3 = apppuStack_2c;
            if (0xf < uVar7) {
              ppppuVar3 = ppppuVar6;
            }
            cVar1 = FUN_0055c360(ppppuVar3,uVar5,"vulkan_mobile",0xd);
            if ((cVar1 == '\0') || (DAT_01d60e78 == '\0')) {
              uVar4 = 0;
              apppuStack_2c[0] = ppppuVar6;
              uStack_18 = uVar7;
              goto LAB_0078bb66;
            }
          }
        }
      }
    }
  }
  iVar2 = (**(code **)(**(int **)(iStack_14 + 0x3c) + 0x40))();
  if (((*(uint *)(iVar2 + 0x2c) < 0x10) ||
      (iVar2 = (**(code **)(**(int **)(iStack_14 + 0x3c) + 0x40))(), *(char *)(iVar2 + 1) == '\0'))
     || (DAT_01d60e68 == '\0')) {
    uVar4 = 0;
  }
  else {
    uVar4 = 1;
  }
LAB_0078bb66:
  if (0xf < uStack_18) {
    uVar7 = uStack_18 + 1;
    ppppuVar6 = (undefined4 ****)apppuStack_2c[0];
    if (0xfff < uVar7) {
      ppppuVar6 = (undefined4 ****)((undefined4 ****)apppuStack_2c[0])[-1];
      uVar7 = uStack_18 + 0x24;
      if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar6,uVar7);
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 11255 ; VA 0x0078bbb0 ; FUN_0078bbb0 */

undefined __fastcall FUN_0078bbb0(int param_1)

{
  char cVar1;
  int iVar2;
  undefined4 ****ppppuVar3;
  undefined uVar4;
  uint uVar5;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x3c) + 0x30))(apppuStack_28);
  uStack_8 = 0;
  if ((((DAT_01d60f70 == '\0') ||
       (iVar2 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x24))(), iVar2 != 0)) ||
      (iVar2 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))(), *(char *)(iVar2 + 4) == '\0')) ||
     ((iVar2 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))(), *(char *)(iVar2 + 0x13) == '\0'
      || (iVar2 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))(),
         *(char *)(iVar2 + 0x15) == '\0')))) {
LAB_0078bcc1:
    uVar4 = 0;
  }
  else {
    ppppuVar3 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar3 = (undefined4 ****)apppuStack_28[0];
    }
    cVar1 = FUN_0055c360(ppppuVar3,uStack_18,"d3d11",5);
    if (cVar1 == '\0') {
      ppppuVar3 = apppuStack_28;
      if (0xf < uStack_14) {
        ppppuVar3 = (undefined4 ****)apppuStack_28[0];
      }
      cVar1 = FUN_0055c360(ppppuVar3,uStack_18,"d3d10_1",7);
      if (cVar1 == '\0') {
        ppppuVar3 = apppuStack_28;
        if (0xf < uStack_14) {
          ppppuVar3 = (undefined4 ****)apppuStack_28[0];
        }
        cVar1 = FUN_0055c360(ppppuVar3,uStack_18,"metal_osx",9);
        if (cVar1 == '\0') {
          ppppuVar3 = apppuStack_28;
          if (0xf < uStack_14) {
            ppppuVar3 = (undefined4 ****)apppuStack_28[0];
          }
          cVar1 = FUN_0055c360(ppppuVar3,uStack_18,"vulkan_desktop",0xe);
          if (cVar1 == '\0') goto LAB_0078bcc1;
        }
      }
    }
    uVar4 = 1;
  }
  if (0xf < uStack_14) {
    uVar5 = uStack_14 + 1;
    ppppuVar3 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar5) {
      ppppuVar3 = (undefined4 ****)((undefined4 ****)apppuStack_28[0])[-1];
      uVar5 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 11256 ; VA 0x0078bd10 ; FUN_0078bd10 */

void __fastcall FUN_0078bd10(int param_1)

{
  FUN_009d7ef0(*(undefined4 *)(param_1 + 0x5c4));
  return;
}



/* FUNCTION 11257 ; VA 0x0078bd20 ; FUN_0078bd20 */

void __fastcall FUN_0078bd20(int param_1)

{
  FUN_009d7fc0(*(undefined4 *)(param_1 + 0x5c4));
  return;
}



/* FUNCTION 11258 ; VA 0x0078bd30 ; FUN_0078bd30 */

void __fastcall FUN_0078bd30(int param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0daa;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_01f0795c);
  uStack_8 = 0;
  uVar3 = FUN_016f3cd0();
  iVar4 = FUN_01674e20(0x80);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iVar4 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00813030(param_1,0x800,0x800,uVar3);
  }
  puVar1 = *(undefined4 **)(param_1 + 0x53c);
  *(undefined4 *)(param_1 + 0x53c) = uVar3;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  uStack_8 = 2;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11259 ; VA 0x0078bdf0 ; FUN_0078bdf0 */

void FUN_0078bdf0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1da021c);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_RBX::MegaClusterInstance*),class_boost::_bi::list1<class_boost::_bi::value<class_RBX::MegaClusterInstance*>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 11260 ; VA 0x0078be60 ; FUN_0078be60 */

void __fastcall FUN_0078be60(int param_1)

{
  undefined4 *puVar1;
  char ****ppppcVar2;
  char ****ppppcVar3;
  undefined *puVar4;
  undefined4 ****ppppuVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  undefined auStack_58 [24];
  undefined4 ***apppuStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  char ***apppcStack_28 [4];
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0de0;
  pvStack_10 = ExceptionList;
  if (DAT_01d60ea0 != '\0') {
    ExceptionList = &pvStack_10;
    if (*(int **)(param_1 + 0x3c) != (int *)0x0) {
      ExceptionList = &pvStack_10;
      puVar1 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x3c) + 0x2c))(auStack_58);
      uStack_8 = 0;
      if (0xf < (uint)puVar1[5]) {
        puVar1 = (undefined4 *)*puVar1;
      }
      FUN_0151f850("gpu/featureLvl",puVar1);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      puVar1 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x3c) + 0x30))(auStack_58);
      uStack_8 = 1;
      if (0xf < (uint)puVar1[5]) {
        puVar1 = (undefined4 *)*puVar1;
      }
      FUN_0151f850("gpu/shadingLang",puVar1);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      FUN_0054ef60(*(int *)(param_1 + 0x3c) + 0x40);
      uStack_8 = 2;
      ppppcVar3 = apppcStack_28;
      if (0xf < uStack_14) {
        ppppcVar3 = (char ****)apppcStack_28[0];
      }
      ppppcVar2 = apppcStack_28;
      if (0xf < uStack_14) {
        ppppcVar2 = (char ****)apppcStack_28[0];
      }
      iVar6 = 0;
      iVar8 = ((int)ppppcVar3 + iStack_18) - (int)ppppcVar2;
      if ((char ****)((int)ppppcVar3 + iStack_18) < ppppcVar2) {
        iVar8 = 0;
      }
      if (iVar8 != 0) {
        do {
          if (*(char *)ppppcVar2 == ' ') {
            *(char *)ppppcVar2 = '_';
          }
          iVar6 = iVar6 + 1;
          ppppcVar2 = (char ****)((int)ppppcVar2 + 1);
        } while (iVar6 != iVar8);
      }
      ppppcVar3 = apppcStack_28;
      if (0xf < uStack_14) {
        ppppcVar3 = (char ****)apppcStack_28[0];
      }
      FUN_0151f850("gpu/adapter",ppppcVar3);
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fc50("gpu/vram",*(undefined4 *)(iVar6 + 0x40),*(undefined4 *)(iVar6 + 0x44));
      puVar4 = (undefined *)(**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/threadSafe",*puVar4);
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsFramebufferHalfFloat",*(undefined *)(iVar6 + 1));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsFramebuffer",*(undefined *)(iVar6 + 2));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsShaders",*(undefined *)(iVar6 + 3));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsCompute",*(undefined *)(iVar6 + 4));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsInstancing",*(undefined *)(iVar6 + 5));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsStencil",*(undefined *)(iVar6 + 6));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsDepth16",*(undefined *)(iVar6 + 7));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsDepth24",*(undefined *)(iVar6 + 8));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsDepthFloat",*(undefined *)(iVar6 + 9));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsDepthClamp",*(undefined *)(iVar6 + 10));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsSamplerBorderColor",*(undefined *)(iVar6 + 0xb));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsIndex32",*(undefined *)(iVar6 + 0xc));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsConstantBuffers",*(undefined *)(iVar6 + 0xd));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsMemorylessRenderTargets",*(undefined *)(iVar6 + 0xe));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsTextureDXT",*(undefined *)(iVar6 + 0xf));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsTexturePVR",*(undefined *)(iVar6 + 0x10));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsTextureETC1",*(undefined *)(iVar6 + 0x11));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsTextureETC2",*(undefined *)(iVar6 + 0x12));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsTextureRGB10A2",*(undefined *)(iVar6 + 0x13));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsTextureRG11B10F",*(undefined *)(iVar6 + 0x14));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsTextureHalfFloat",*(undefined *)(iVar6 + 0x15));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsTexture3D",*(undefined *)(iVar6 + 0x16));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsTextureNPOT",*(undefined *)(iVar6 + 0x17));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsTexturePartialMipChain",*(undefined *)(iVar6 + 0x18));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsTextureArray",*(undefined *)(iVar6 + 0x19));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsTextureDepth",*(undefined *)(iVar6 + 0x1a));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsTextureMSAA",*(undefined *)(iVar6 + 0x1b));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsRenderTargetR8G8",*(undefined *)(iVar6 + 0x1c));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsTextureCubeGenerateMipmaps",*(undefined *)(iVar6 + 0x1d));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/supportsTextureCubeFramebuffer",*(undefined *)(iVar6 + 0x1e));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/colorOrderBGR",*(undefined *)(iVar6 + 0x38));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/needsHalfPixelOffset",*(undefined *)(iVar6 + 0x39));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/requiresRenderTargetFlipping",*(undefined *)(iVar6 + 0x3a));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fcf0("gpu/hasMinusOneToOneDepth",*(undefined *)(iVar6 + 0x3b));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fa60("gpu/maxDrawBuffers",*(undefined4 *)(iVar6 + 0x20));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fa60("gpu/maxSamples",*(undefined4 *)(iVar6 + 0x24));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fa60("gpu/maxTextureSize",*(undefined4 *)(iVar6 + 0x28));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fa60("gpu/maxTextureUnits",*(undefined4 *)(iVar6 + 0x2c));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fa60("gpu/maxConstantBufferSize",*(undefined4 *)(iVar6 + 0x30));
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fa60("gpu/textureSamplesMSAAFP16",*(undefined4 *)(iVar6 + 0x34));
      uStack_8 = 0xffffffff;
      FUN_005507b0();
    }
    FUN_00712f70();
    FUN_009cb090(apppuStack_40,*(undefined4 *)(param_1 + 0x5c4));
    uStack_8 = 3;
    ppppuVar5 = apppuStack_40;
    if (0xf < uStack_2c) {
      ppppuVar5 = (undefined4 ****)apppuStack_40[0];
    }
    FUN_0151f850("gpu/disp/tech",ppppuVar5);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_2c) {
      uVar7 = uStack_2c + 1;
      ppppuVar5 = (undefined4 ****)apppuStack_40[0];
      if (0xfff < uVar7) {
        ppppuVar5 = (undefined4 ****)apppuStack_40[0][-1];
        uVar7 = uStack_2c + 0x24;
        if (0x1f < (uint)((int)apppuStack_40[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar5,uVar7);
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    apppuStack_40[0] = (undefined4 ***)((uint)apppuStack_40[0] & 0xffffff00);
    FUN_0151f9c0("gpu/disp/width",*(undefined4 *)(param_1 + 0x4d4));
    FUN_0151f9c0("gpu/disp/height",*(undefined4 *)(param_1 + 0x4d8));
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11261 ; VA 0x0078c450 ; FUN_0078c450 */

void FUN_0078c450(int param_1)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x10) != 0) {
    iVar1 = FUN_00789c40(param_1);
    *(undefined4 *)(iVar1 + 0x18) = 2;
  }
  return;
}



/* FUNCTION 11262 ; VA 0x0078c480 ; FUN_0078c480 */

void __thiscall FUN_0078c480(undefined4 *param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint uVar6;
  
  puVar1 = (undefined4 *)*param_1;
  puVar3 = (undefined4 *)FUN_01674f30(param_1[2] << 2);
  *param_1 = puVar3;
  if ((int)param_1[2] < (int)param_2) {
    param_2 = param_1[2];
  }
  uVar5 = 0;
  uVar6 = param_2 & 0x3fffffff;
  if (puVar3 + param_2 < puVar3) {
    uVar6 = 0;
  }
  puVar4 = puVar1;
  if (uVar6 != 0) {
    do {
      uVar2 = *puVar4;
      puVar4 = puVar4 + 1;
      uVar5 = uVar5 + 1;
      *puVar3 = uVar2;
      puVar3 = puVar3 + 1;
    } while (uVar5 < uVar6);
  }
  FUN_01674ea0(puVar1);
  return;
}



/* FUNCTION 11263 ; VA 0x0078c4e0 ; FUN_0078c4e0 */

void FUN_0078c4e0(int param_1)

{
  int iVar1;
  
  FUN_00afd380();
  iVar1 = FUN_0170d75d(*(undefined4 *)(param_1 + 0xb0),0,&RBX::GfxPart::RTTI_Type_Descriptor,
                       &RBX::Graphics::SmoothCluster::RTTI_Type_Descriptor,0);
  if (iVar1 != 0) {
    FUN_0080b070();
    return;
  }
  return;
}



/* FUNCTION 11264 ; VA 0x0078c520 ; FUN_0078c520 */

uint __fastcall FUN_0078c520(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  int *piVar9;
  
  uVar4 = FUN_00791b90();
  if (*(int *)(param_1 + 0x584) == 0) {
    piVar8 = (int *)0x0;
  }
  else {
    uVar4 = *(uint *)(param_1 + 0x580);
    piVar8 = *(int **)(*(int *)(param_1 + 0x590) + uVar4 * 4);
  }
  while( true ) {
    if (piVar8 == (int *)0x0) {
      return uVar4;
    }
    piVar1 = piVar8 + 8;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) break;
    piVar8 = (int *)*piVar8;
  }
  FUN_0078b070(piVar8 + 2);
  piVar1 = (int *)*piVar8;
  uVar4 = (uint)piVar8[1] % *(uint *)(param_1 + 0x580);
  piVar2 = *(int **)(*(int *)(param_1 + 0x590) + uVar4 * 4);
  for (piVar9 = (int *)*piVar2; piVar9 != piVar8; piVar9 = (int *)*piVar9) {
    piVar2 = piVar9;
  }
  do {
    *piVar2 = *piVar9;
    uVar7 = piVar9[7];
    if (0xf < uVar7) {
      iVar3 = piVar9[2];
      uVar6 = uVar7 + 1;
      iVar5 = iVar3;
      if (0xfff < uVar6) {
        iVar5 = *(int *)(iVar3 + -4);
        uVar6 = uVar7 + 0x24;
        if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar6);
    }
    piVar9[6] = 0;
    piVar9[7] = 0xf;
    *(undefined *)(piVar9 + 2) = 0;
    FUN_01674ea0(piVar9,0x24);
    *(int *)(param_1 + 0x584) = *(int *)(param_1 + 0x584) + -1;
    uVar7 = uVar4;
    if (*piVar2 == 0) {
LAB_0078c62a:
      uVar6 = *(uint *)(param_1 + 0x590);
      if (*(int **)(uVar6 + uVar4 * 4) == piVar2) {
        *(undefined4 *)(uVar6 + uVar4 * 4) = 0;
      }
    }
    else {
      uVar7 = *(uint *)(*piVar2 + 4);
      uVar6 = uVar7 / *(uint *)(param_1 + 0x580);
      uVar7 = uVar7 % *(uint *)(param_1 + 0x580);
      if (uVar4 != uVar7) {
        *(int **)(*(int *)(param_1 + 0x590) + uVar7 * 4) = piVar2;
        goto LAB_0078c62a;
      }
    }
    piVar9 = (int *)*piVar2;
    uVar4 = uVar7;
    if (piVar9 == piVar1) {
      return uVar6;
    }
  } while( true );
}



/* FUNCTION 11265 ; VA 0x0078c660 ; FUN_0078c660 */

void __fastcall FUN_0078c660(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int aiStack_48 [5];
  uint uStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0e11;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  uStack_18 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x30))(aiStack_48);
  uStack_8 = 0;
  puVar2 = (undefined4 *)FUN_008c8420();
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_14 = 1;
  FUN_0058a190(puVar2[4] + 10);
  puVar1 = puVar2 + 4;
  if (0xf < (uint)puVar2[5]) {
    puVar2 = (undefined4 *)*puVar2;
  }
  FUN_00554150(puVar2,*puVar1);
  FUN_00554150("../shaders",10);
  FUN_00791300(auStack_30,uStack_18,param_1 + 0x5ac,1);
  if (0xf < uStack_1c) {
    uVar4 = uStack_1c + 1;
    uVar5 = auStack_30[0];
    if (0xfff < uVar4) {
      uVar5 = *(uint *)(auStack_30[0] - 4);
      uVar4 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar4);
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  if (0xf < uStack_34) {
    uVar5 = uStack_34 + 1;
    iVar3 = aiStack_48[0];
    if (0xfff < uVar5) {
      iVar3 = *(int *)(aiStack_48[0] + -4);
      uVar5 = uStack_34 + 0x24;
      if (0x1f < (aiStack_48[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11266 ; VA 0x0078c7a0 ; FUN_0078c7a0 */

void __thiscall FUN_0078c7a0(int param_1,undefined4 param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  
  iVar3 = FUN_007875e0(param_2);
  iVar4 = *(int *)(param_1 + 0x598);
  if (iVar3 != iVar4) {
    cVar2 = FUN_00570370(param_2,iVar3 + 0x10);
    if (cVar2 == '\0') goto LAB_0078c7d2;
  }
  iVar3 = iVar4;
LAB_0078c7d2:
  if (iVar3 != iVar4) {
    piVar1 = *(int **)(iVar3 + 0x28);
    *(undefined4 *)(iVar3 + 0x28) = 0;
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 4))(1);
    }
    iVar4 = *(int *)(iVar3 + 0x2c);
    *(undefined4 *)(iVar3 + 0x2c) = 0;
    if (iVar4 != 0) {
      FUN_007f8b70();
      FUN_01674ea0(iVar4,0x178);
    }
    iVar4 = FUN_00553830(iVar3);
    FUN_00787a40((int *)(param_1 + 0x598),iVar4 + 0x10);
    FUN_01674ea0(iVar4,0x44);
  }
  return;
}



/* FUNCTION 11267 ; VA 0x0078c840 ; FUN_0078c840 */

void __thiscall FUN_0078c840(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 *puVar2;
  
  iVar1 = *(int *)(param_1 + 0x4e4);
  if (*(int *)(iVar1 + 600) == 0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    puVar2 = *(undefined4 **)(*(int *)(iVar1 + 0x264) + *(int *)(iVar1 + 0x254) * 4);
  }
  for (; puVar2 != (undefined4 *)0x0; puVar2 = (undefined4 *)*puVar2) {
    FUN_0079aeb0(param_2,puVar2[3]);
  }
  FUN_00795ed0();
  return;
}



/* FUNCTION 11268 ; VA 0x0078c8a0 ; FUN_0078c8a0 */

void __thiscall FUN_0078c8a0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar1 = *(int **)(param_1 + 0x598);
  piVar2 = (int *)*piVar1;
  while (piVar2 != piVar1) {
    iVar3 = (**(code **)(**(int **)(param_1 + 0x3c) + 0xc))(piVar2[0xf]);
    if (iVar3 != 0) {
      FUN_0079c180(param_2,piVar2[0xb],piVar2[0xc],iVar3,piVar2[0xd],piVar2[0xe],param_1 + 0x40,0);
    }
    FUN_00551320();
  }
  return;
}



/* FUNCTION 11269 ; VA 0x0078c900 ; FUN_0078c900 */

void __thiscall FUN_0078c900(int param_1,int param_2,char param_3)

{
  int iVar1;
  int iVar2;
  float fVar3;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 == param_2) {
    return;
  }
  iVar2 = *(int *)(param_1 + 8);
  *(int *)(param_1 + 4) = param_2;
  if (param_2 <= iVar2) {
    if (iVar2 / 3 < param_2) {
      return;
    }
    if (param_3 == '\0') {
      return;
    }
    if (param_2 < 0xb) {
      return;
    }
    if (iVar1 <= param_2) {
      param_2 = iVar1;
    }
    FUN_0078c480(param_2);
    return;
  }
  if (iVar2 == 0) {
    *(int *)(param_1 + 8) = param_2;
    FUN_0078c480(iVar1);
    return;
  }
  if (9 < param_2) {
    fVar3 = DAT_018df57c;
    if ((iVar2 * 4 < 0x61a81) && (fVar3 = DAT_018df580, 64000 < iVar2 * 4)) {
      fVar3 = DAT_018daf58;
    }
    param_2 = ((int)((float)iVar2 * fVar3) - iVar2) + param_2;
    *(int *)(param_1 + 8) = param_2;
    if (9 < param_2) goto LAB_0078c986;
  }
  *(undefined4 *)(param_1 + 8) = 10;
LAB_0078c986:
  FUN_0078c480(iVar1);
  return;
}



/* FUNCTION 11270 ; VA 0x0078c9c0 ; FUN_0078c9c0 */

void FUN_0078c9c0(undefined4 param_1,undefined4 *param_2)

{
  undefined4 ****ppppuVar1;
  uint uVar2;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_01675460(apppuStack_28,"gfx/pass/%s/batches",param_1);
  ppppuVar1 = apppuStack_28;
  if (0xf < uStack_14) {
    ppppuVar1 = (undefined4 ****)apppuStack_28[0];
  }
  FUN_0151fa60(ppppuVar1,*param_2);
  uStack_18 = 0;
  ppppuVar1 = apppuStack_28;
  if (0xf < uStack_14) {
    ppppuVar1 = (undefined4 ****)apppuStack_28[0];
  }
  *(undefined *)ppppuVar1 = 0;
  FUN_01675460(apppuStack_28,"gfx/pass/%s/tris",param_1);
  ppppuVar1 = apppuStack_28;
  if (0xf < uStack_14) {
    ppppuVar1 = (undefined4 ****)apppuStack_28[0];
  }
  FUN_0151fa60(ppppuVar1,(uint)param_2[1] / 3);
  uStack_18 = 0;
  ppppuVar1 = apppuStack_28;
  if (0xf < uStack_14) {
    ppppuVar1 = (undefined4 ****)apppuStack_28[0];
  }
  *(undefined *)ppppuVar1 = 0;
  FUN_01675460(apppuStack_28,"gfx/pass/%s/cbKbs",param_1);
  ppppuVar1 = apppuStack_28;
  if (0xf < uStack_14) {
    ppppuVar1 = (undefined4 ****)apppuStack_28[0];
  }
  FUN_0151fa60(ppppuVar1,param_2[2] + 0x3ff >> 10);
  uStack_18 = 0;
  ppppuVar1 = apppuStack_28;
  if (0xf < uStack_14) {
    ppppuVar1 = (undefined4 ****)apppuStack_28[0];
  }
  *(undefined *)ppppuVar1 = 0;
  FUN_01675460(apppuStack_28,"gfx/pass/%s/matChanges",param_1);
  ppppuVar1 = apppuStack_28;
  if (0xf < uStack_14) {
    ppppuVar1 = (undefined4 ****)apppuStack_28[0];
  }
  FUN_0151fa60(ppppuVar1,param_2[3]);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    ppppuVar1 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar2) {
      ppppuVar1 = (undefined4 ****)apppuStack_28[0][-1];
      uVar2 = uStack_14 + 0x24;
      if ((undefined *)0x1f < (undefined *)((int)apppuStack_28[0] + (-4 - (int)ppppuVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11271 ; VA 0x0078cb40 ; FUN_0078cb40 */

void __thiscall FUN_0078cb40(int param_1,undefined4 param_2,undefined8 *param_3)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  float10 fVar6;
  uint uVar7;
  undefined auStack_15c [48];
  undefined auStack_12c [240];
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  int iStack_18;
  float fStack_14;
  uint uStack_10;
  undefined4 *puStack_c;
  float fStack_8;
  
  iStack_18 = param_1;
  uVar1 = FUN_00d226b0(auStack_15c);
  FUN_007cd9c0(uVar1);
  uVar1 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x20))();
  fVar6 = (float10)FUN_00d22f10();
  fStack_8 = (float)fVar6;
  uStack_10 = (uint)fStack_8 ^ DAT_018c4ea0;
  fVar6 = (float10)FUN_00d21090();
  fStack_8 = (float)((uint)(float)fVar6 ^ DAT_018c4ea0);
  fStack_14 = (float)*(int *)(param_1 + 0x4d4) / (float)*(int *)(param_1 + 0x4d8);
  fVar6 = (float10)FUN_00d22950();
  puStack_c = (undefined4 *)(float)fVar6;
  FUN_007cd880(puStack_c,fStack_14,fStack_8,uStack_10,uVar1);
  FUN_007a0bb0(param_3);
  iVar3 = *(int *)(param_1 + 0x4e4);
  if (iVar3 != 0) {
    *(undefined8 *)(iVar3 + 0x280) = *param_3;
    *(undefined4 *)(iVar3 + 0x288) = *(undefined4 *)(param_3 + 1);
  }
  puStack_c = (undefined4 *)(param_1 + 0x284);
  puVar4 = (undefined4 *)(param_1 + 0x40);
  puVar5 = puStack_c;
  for (iVar3 = 0x91; iVar3 != 0; iVar3 = iVar3 + -1) {
    *puVar5 = *puVar4;
    puVar4 = puVar4 + 1;
    puVar5 = puVar5 + 1;
  }
  piVar2 = (int *)(**(code **)(**(int **)(iStack_18 + 0x3c) + 0x24))();
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x14))(auStack_12c);
    fVar6 = (float10)FUN_00d22f10();
    uVar7 = (uint)(float)fVar6 ^ DAT_018c4ea0;
    fVar6 = (float10)FUN_00d21090();
    if (fStack_20 <= fStack_30) {
      fStack_20 = fStack_30;
    }
    if (fStack_24 <= fStack_34) {
      fStack_24 = fStack_34;
    }
    if (fStack_28 <= fStack_38) {
      fStack_28 = fStack_38;
    }
    if (fStack_2c <= fStack_3c) {
      fStack_2c = fStack_3c;
    }
    FUN_007cd720(fStack_2c,fStack_28,fStack_24,fStack_20,(uint)(float)fVar6 ^ DAT_018c4ea0,uVar7,0);
  }
  return;
}



/* FUNCTION 11272 ; VA 0x0078cd30 ; FUN_0078cd30 */

void __thiscall FUN_0078cd30(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  
  iVar3 = FUN_007875e0(param_2);
  iVar1 = *(int *)(param_1 + 0x598);
  if (iVar3 != iVar1) {
    cVar2 = FUN_00570370(param_2,iVar3 + 0x10);
    if (cVar2 == '\0') goto LAB_0078cd62;
  }
  iVar3 = iVar1;
LAB_0078cd62:
  if (iVar3 != iVar1) {
    *(undefined4 *)(iVar3 + 0x40) = param_3;
  }
  return;
}



/* FUNCTION 11273 ; VA 0x0078cd80 ; FUN_0078cd80 */

void __thiscall FUN_0078cd80(int param_1,undefined4 param_2)

{
  char cVar1;
  
  cVar1 = FUN_009d7ef0(*(undefined4 *)(param_1 + 0x5c4));
  if (cVar1 != '\0') {
    *(undefined4 *)(param_1 + 0x5c8) = param_2;
    return;
  }
  *(undefined4 *)(param_1 + 0x5c8) = 0;
  return;
}



/* FUNCTION 11274 ; VA 0x0078cdc0 ; FUN_0078cdc0 */

void __thiscall FUN_0078cdc0(int param_1,float param_2)

{
  int iVar1;
  
  if ((NAN(param_2) || NAN(*(float *)(param_1 + 0x594))) == (param_2 == *(float *)(param_1 + 0x594))
     ) {
    *(float *)(param_1 + 0x594) = param_2;
    if ((-(uint)(*(int *)(param_1 + 0x5a0) != 0) & *(int *)(param_1 + 0x5a0) + 0xcU) != 0) {
      iVar1 = FUN_006348f0();
      if (iVar1 != 0) {
        FUN_00b9cea0((int)*(float *)(param_1 + 0x594));
      }
    }
    if ((-(uint)(*(int *)(param_1 + 0x5a0) != 0) & *(int *)(param_1 + 0x5a0) + 0xcU) != 0) {
      iVar1 = FUN_007878b0();
      if (iVar1 != 0) {
        FUN_00d2d3e0(param_2);
        FUN_0078bd30();
        FUN_0078ab70();
      }
    }
  }
  return;
}



/* FUNCTION 11275 ; VA 0x0078ce50 ; FUN_0078ce50 */

void __thiscall FUN_0078ce50(int param_1,int param_2)

{
  char cVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  bool bVar9;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0e64;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffc8;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_0078b7d0();
  cVar2 = FUN_0078ba00();
  iVar5 = *(int *)(param_1 + 0x5c4);
  if (param_2 == 4) {
    bVar9 = cVar2 == '\0';
  }
  else {
    bVar9 = param_2 == 3;
  }
  iVar6 = param_2;
  if (bVar9) {
    iVar6 = (uint)(cVar1 != '\0') * 2 + 1;
  }
  *(int *)(param_1 + 0x5c4) = iVar6;
  if (iVar5 != iVar6) {
    uStack_8 = 0;
    cVar1 = FUN_009d7fc0(iVar6);
    if (cVar1 == '\0') {
      puVar3 = *(undefined4 **)(param_1 + 0x574);
      *(undefined4 *)(param_1 + 0x574) = 0;
      if (puVar3 != (undefined4 *)0x0) {
        (**(code **)*puVar3)(1);
      }
      FUN_007982a0();
    }
    else {
      if (DAT_01f6dcc0 != '\0') {
        FUN_016774b0(DAT_01f6dcc0,"Future is bright shadows",0);
      }
      if (*(int **)(param_1 + 0x578) == (int *)0x0) {
        uStack_2c = 0;
        uStack_28 = 0;
        puVar3 = &uStack_2c;
        uStack_8 = 2;
        uVar7 = 2;
      }
      else {
        puVar3 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x578) + 0x20))();
        if (puVar3[1] != 0) {
          LOCK();
          piVar8 = (int *)(puVar3[1] + 4);
          *piVar8 = *piVar8 + 1;
          UNLOCK();
        }
        uStack_24 = *puVar3;
        uStack_20 = puVar3[1];
        puVar3 = &uStack_24;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        uVar7 = 1;
      }
      uStack_18 = uVar7;
      uVar4 = FUN_007a7270(param_1,puVar3);
      puVar3 = *(undefined4 **)(param_1 + 0x574);
      *(undefined4 *)(param_1 + 0x574) = uVar4;
      if (puVar3 != (undefined4 *)0x0) {
        (**(code **)*puVar3)(1);
      }
      if ((uVar7 & 2) != 0) {
        uVar7 = uVar7 & 0xfffffffd;
        FUN_00550b30();
      }
      uStack_8 = 0;
      if ((uVar7 & 1) != 0) {
        FUN_00550b30();
      }
      FUN_00798720();
    }
    if (DAT_01d60bc0 != '\0') {
      *(undefined *)(*(int *)(param_1 + 0x4e4) + 0x211) = 1;
      param_2 = FUN_01674e20(&LAB_0051dda8);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      if (param_2 == 0) {
        iVar5 = 0;
      }
      else {
        iVar5 = FUN_0075d8e0(param_1);
      }
      piVar8 = (int *)(param_1 + 0x54c);
      if (piVar8 != &param_2) {
        iVar6 = *piVar8;
        *piVar8 = iVar5;
        iVar5 = iVar6;
      }
      if (iVar5 != 0) {
        FUN_00789f40(1);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11276 ; VA 0x0078d03b ; Catch@0078d03b */

undefined4 Catch_0078d03b(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  if (DAT_01f6dcc0 != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x18) + 4))();
    FUN_01677650(DAT_01f6dcc0,"Error creating future is bright shadow maps: %s",uVar1);
  }
  return 0x78d01e;
}



/* FUNCTION 11277 ; VA 0x0078d070 ; FUN_0078d070 */

void __thiscall FUN_0078d070(int param_1,undefined4 param_2,undefined4 param_3)

{
  *(undefined4 *)(param_1 + 0x4d4) = param_2;
  *(undefined4 *)(param_1 + 0x4d8) = param_3;
  if (*(int *)(param_1 + 0x4c8) != 0) {
    FUN_00804190();
    return;
  }
  return;
}



/* FUNCTION 11278 ; VA 0x0078d0a0 ; FUN_0078d0a0 */

void __thiscall FUN_0078d0a0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  char cVar2;
  int iVar3;
  
  iVar3 = FUN_007875e0(param_2);
  iVar1 = *(int *)(param_1 + 0x598);
  if (iVar3 != iVar1) {
    cVar2 = FUN_00570370(param_2,iVar3 + 0x10);
    if (cVar2 == '\0') goto LAB_0078d0d2;
  }
  iVar3 = iVar1;
LAB_0078d0d2:
  if (iVar3 != iVar1) {
    *(undefined4 *)(iVar3 + 0x34) = param_3;
    *(undefined4 *)(iVar3 + 0x38) = param_4;
    if (*(int *)(iVar3 + 0x28) != 0) {
      FUN_00804190(param_3,param_4);
    }
  }
  return;
}



/* FUNCTION 11279 ; VA 0x0078d100 ; FUN_0078d100 */

void __thiscall FUN_0078d100(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 ****ppppuVar5;
  int iVar6;
  undefined4 ****ppppuVar7;
  undefined4 uVar8;
  undefined8 uVar9;
  undefined auStack_64 [24];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  char cStack_3c;
  undefined4 ***apppuStack_34 [4];
  int iStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0ea4;
  pvStack_10 = ExceptionList;
  if (((char)param_3 != '\0') && (DAT_01d60e80 != '\0')) {
    ExceptionList = &pvStack_10;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1cb8)
       && (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb1cb8), cVar1 = DAT_01d80f3c,
          DAT_01eb1cb8 == -1)) {
      uStack_8 = 0;
      uVar9 = FUN_0152dab0("telem",&DAT_018fc8e0,0xffffffff);
      param_3 = (undefined4)((ulonglong)uVar9 >> 0x20);
      if ((cVar1 != '\0') && (DAT_01d7ad40 != '\0')) {
        FUN_01532a30(uVar9);
      }
      uStack_8 = 0xffffffff;
      DAT_01eb1cb0 = (int)uVar9;
      DAT_01eb1cb4 = param_3;
      FUN_016f37bf(&DAT_01eb1cb8);
    }
    uVar8 = DAT_01eb1cb0;
    cVar1 = DAT_01d80f3c;
    cStack_11 = DAT_01d80f3c;
    uStack_18 = DAT_01eb1cb0;
    uStack_4c = DAT_01eb1cb0;
    uStack_1c = DAT_01eb1cb4;
    uStack_48 = DAT_01eb1cb4;
    uStack_44 = FUN_01532c80(DAT_01eb1cb0,DAT_01eb1cb4);
    uVar2 = param_2;
    cStack_3c = cVar1;
    uStack_8 = 1;
    if (*(int *)(param_1 + 0x3c) != 0) {
      FUN_0054ef60(*(int *)(param_1 + 0x3c) + 0x40);
      ppppuVar5 = apppuStack_34;
      if (0xf < uStack_20) {
        ppppuVar5 = (undefined4 ****)apppuStack_34[0];
      }
      uStack_8._0_1_ = 2;
      param_3 = CONCAT13(0x5f,(undefined3)param_3);
      ppppuVar7 = apppuStack_34;
      if (0xf < uStack_20) {
        ppppuVar7 = (undefined4 ****)apppuStack_34[0];
      }
      param_2 = CONCAT13(0x20,(undefined3)param_2);
      FUN_00787bd0(ppppuVar7,iStack_24 + (int)ppppuVar5,(int)&param_2 + 3,(int)&param_3 + 3);
      puVar4 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x3c) + 0x2c))(auStack_64);
      uStack_8._0_1_ = 3;
      if (0xf < (uint)puVar4[5]) {
        puVar4 = (undefined4 *)*puVar4;
      }
      FUN_0151f850("gfx/featurelevel",puVar4);
      uStack_8._0_1_ = 2;
      FUN_005507b0();
      puVar4 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x3c) + 0x30))(auStack_64);
      uStack_8._0_1_ = 4;
      if (0xf < (uint)puVar4[5]) {
        puVar4 = (undefined4 *)*puVar4;
      }
      FUN_0151f850("gfx/shadinglang",puVar4);
      uStack_8._0_1_ = 2;
      FUN_005507b0();
      ppppuVar5 = apppuStack_34;
      if (0xf < uStack_20) {
        ppppuVar5 = (undefined4 ****)apppuStack_34[0];
      }
      FUN_0151f850("gfx/adapter",ppppuVar5);
      iVar6 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      FUN_0151fc50("gfx/vram",*(undefined4 *)(iVar6 + 0x40),*(undefined4 *)(iVar6 + 0x44));
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_005507b0();
      uVar8 = uStack_18;
    }
    FUN_00712f70();
    FUN_009cb090(apppuStack_34,*(undefined4 *)(param_1 + 0x5c4));
    uStack_8._0_1_ = 5;
    ppppuVar5 = apppuStack_34;
    if (0xf < uStack_20) {
      ppppuVar5 = (undefined4 ****)apppuStack_34[0];
    }
    FUN_0151f850("gfx/disp/tech",ppppuVar5);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_005507b0();
    FUN_0151f9c0("gfx/disp/width",*(undefined4 *)(param_1 + 0x4d4));
    FUN_0151f9c0("gfx/disp/height",*(undefined4 *)(param_1 + 0x4d8));
    FUN_0078c9c0("total",*(undefined4 *)(param_1 + 0x528),uVar2);
    FUN_0078c9c0("scene",*(int *)(param_1 + 0x528) + 0x10,uVar2);
    FUN_0078c9c0("shadow",*(int *)(param_1 + 0x528) + 0x20,uVar2);
    FUN_0078c9c0(&DAT_018fc970,*(int *)(param_1 + 0x528) + 0x30,uVar2);
    FUN_0078c9c0("imgui",*(int *)(param_1 + 0x528) + 0x40,uVar2);
    FUN_0078c9c0("adorns",*(int *)(param_1 + 0x528) + 0x50,uVar2);
    uVar3 = uStack_1c;
    uVar2 = (undefined4)uStack_44;
    uStack_8 = 6;
    FUN_0152dda0(uVar8,uStack_1c,uStack_44);
    if ((cStack_11 != '\0') && (DAT_01d7ad40 != '\0')) {
      FUN_01532d10(uVar8,uVar3,uVar2,uStack_44._4_4_);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11280 ; VA 0x0078d440 ; FUN_0078d440 */

void __fastcall FUN_0078d440(int param_1)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 auStack_b0 [40];
  
  puVar2 = *(undefined4 **)(param_1 + 0x524);
  puVar3 = auStack_b0;
  for (iVar1 = 0x28; iVar1 != 0; iVar1 = iVar1 + -1) {
    *puVar3 = *puVar2;
    puVar2 = puVar2 + 1;
    puVar3 = puVar3 + 1;
  }
  puVar2 = auStack_b0;
  puVar3 = *(undefined4 **)(param_1 + 0x528);
  for (iVar1 = 0x28; iVar1 != 0; iVar1 = iVar1 + -1) {
    *puVar3 = *puVar2;
    puVar2 = puVar2 + 1;
    puVar3 = puVar3 + 1;
  }
  return;
}



/* FUNCTION 11281 ; VA 0x0078d490 ; FUN_0078d490 */

void __fastcall FUN_0078d490(int param_1)

{
  uint *puVar1;
  uint uVar2;
  double *pdVar3;
  double dVar4;
  double dVar5;
  float fVar6;
  undefined auStack_c [8];
  
  pdVar3 = (double *)FUN_01683070(auStack_c,2);
  if (*(int *)(param_1 + 8) == 0 && *(int *)(param_1 + 0xc) == 0) {
    *(double *)(param_1 + 0x10) = *pdVar3;
    fVar6 = 0.0;
    dVar4 = 0.0;
    dVar5 = 0.0;
  }
  else {
    dVar4 = *pdVar3 - *(double *)(param_1 + 0x10);
    dVar5 = dVar4 - *(double *)(param_1 + 0x20);
    fVar6 = (float)dVar4;
  }
  *(double *)(param_1 + 0x18) = dVar5;
  *(double *)(param_1 + 0x20) = dVar4;
  *(float *)(param_1 + 0x28) = fVar6;
  puVar1 = (uint *)(param_1 + 8);
  uVar2 = *puVar1;
  *puVar1 = *puVar1 + 1;
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + (uint)(0xfffffffe < uVar2);
  return;
}



/* FUNCTION 11282 ; VA 0x0078d4f0 ; FUN_0078d4f0 */

int __thiscall FUN_0078d4f0(uint *param_1,uint param_2,undefined4 param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0eb0;
  pvStack_10 = ExceptionList;
  uVar1 = *param_1;
  iVar3 = (int)(param_1[1] - uVar1) / 0x50;
  if (iVar3 == 0x3333333) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar7 = iVar3 + 1;
  uVar5 = (int)(param_1[2] - uVar1) / 0x50;
  uVar8 = uVar7;
  if ((uVar5 <= 0x3333333 - (uVar5 >> 1)) && (uVar8 = (uVar5 >> 1) + uVar5, uVar8 < uVar7)) {
    uVar8 = uVar7;
  }
  uVar5 = uVar8 * 0x50;
  if (uVar8 < 0x3333334) {
    uVar8 = uVar5;
    if (0xfff < uVar5) goto LAB_0078d5ab;
    if (uVar5 == 0) {
      uVar8 = 0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      uVar8 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar8 = 0xffffffff;
LAB_0078d5ab:
    uVar2 = uVar8 + 0x23;
    if (uVar2 <= uVar8) {
      uVar2 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_0078d6f4;
    uVar8 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar8 - 4) = iVar3;
  }
  uStack_8 = 0;
  iVar3 = ((int)(param_2 - uVar1) / 0x50) * 0x50;
  iVar4 = iVar3 + uVar8;
  FUN_0078dbd0(param_1,iVar4,param_3);
  if (param_2 == param_1[1]) {
    FUN_0078da70(*param_1,param_1[1],uVar8,param_1);
  }
  else {
    FUN_0078da70(*param_1,param_2,uVar8,param_1);
    FUN_0078da70(param_2,param_1[1],iVar4 + 0x50,param_1);
  }
  if (*param_1 != 0) {
    FUN_0075c400(*param_1,param_1[1],param_1);
    uVar1 = *param_1;
    uVar6 = ((int)(param_1[2] - uVar1) / 0x50) * 0x50;
    uVar2 = uVar1;
    if (0xfff < uVar6) {
      uVar2 = *(uint *)(uVar1 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar1 - uVar2) - 4) {
LAB_0078d6f4:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar6);
  }
  *param_1 = uVar8;
  param_1[1] = uVar7 * 0x50 + uVar8;
  param_1[2] = uVar5 + uVar8;
  ExceptionList = pvStack_10;
  return *param_1 + iVar3;
}



/* FUNCTION 11283 ; VA 0x0078d6cb ; Catch_All@0078d6cb */

void Catch_All_0078d6cb(void)

{
  int unaff_EBP;
  
  FUN_0075f040(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x18));
  FUN_006fec30(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x1c));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11284 ; VA 0x0078d700 ; FUN_0078d700 */

void __thiscall FUN_0078d700(int *param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 *puVar6;
  int iVar7;
  uint uStack_c;
  
  uVar5 = (param_1[1] - *param_1) / 0x14;
  uStack_c = (param_1[2] - *param_1) / 0x14;
  if (param_2 <= uStack_c) {
    if (uVar5 < param_2) {
      iVar3 = FUN_0078df80(param_1[1],param_2 - uVar5);
      param_1[1] = iVar3;
      return;
    }
    if (param_2 != uVar5) {
      iVar3 = *param_1 + param_2 * 0x14;
      FUN_0075c3b0(iVar3,param_1[1],param_1);
      param_1[1] = iVar3;
    }
    return;
  }
  if (param_2 < 0xccccccd) {
    if (0xccccccc - (uStack_c >> 1) < uStack_c) {
      uStack_c = param_2;
    }
    else {
      uStack_c = (uStack_c >> 1) + uStack_c;
      if (uStack_c < param_2) {
        uStack_c = param_2;
      }
    }
    puVar2 = (undefined4 *)FUN_00618130(uStack_c);
    FUN_0078df80(puVar2 + uVar5 * 5,param_2 - uVar5);
    puVar1 = (undefined4 *)param_1[1];
    puVar6 = puVar2;
    for (puVar4 = (undefined4 *)*param_1; puVar4 != puVar1; puVar4 = puVar4 + 5) {
      *puVar6 = 0;
      puVar6[1] = 0;
      *puVar6 = *puVar4;
      puVar6[1] = puVar4[1];
      *puVar4 = 0;
      puVar4[1] = 0;
      *(undefined8 *)(puVar6 + 2) = *(undefined8 *)(puVar4 + 2);
      puVar6[4] = puVar4[4];
      puVar6 = puVar6 + 5;
    }
    FUN_0075c3b0(puVar6,puVar6,param_1);
    if (*param_1 != 0) {
      FUN_0075c3b0(*param_1,param_1[1],param_1);
      iVar3 = *param_1;
      uVar5 = ((param_1[2] - iVar3) / 0x14) * 0x14;
      iVar7 = iVar3;
      if (0xfff < uVar5) {
        iVar7 = *(int *)(iVar3 + -4);
        uVar5 = uVar5 + 0x23;
        if (0x1f < (iVar3 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar7,uVar5);
    }
    *param_1 = (int)puVar2;
    param_1[1] = (int)(puVar2 + param_2 * 5);
    param_1[2] = (int)(puVar2 + uStack_c * 5);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 11285 ; VA 0x0078d8d0 ; FUN_0078d8d0 */

void __thiscall FUN_0078d8d0(int *param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 *puVar8;
  int iVar9;
  uint uStack_10;
  
  iVar4 = param_1[1];
  iVar9 = *param_1;
  uVar7 = iVar4 - iVar9 >> 4;
  uStack_10 = param_1[2] - iVar9 >> 4;
  if (param_2 <= uStack_10) {
    if (param_2 <= uVar7) {
      if (param_2 != uVar7) {
        iVar9 = param_2 * 0x10 + iVar9;
        FUN_0075c360(iVar9,iVar4,param_1);
        param_1[1] = iVar9;
      }
      return;
    }
    iVar4 = FUN_0078dff0(iVar4,param_2 - uVar7);
    param_1[1] = iVar4;
    return;
  }
  if (0xfffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  if (0xfffffff - (uStack_10 >> 1) < uStack_10) {
    uStack_10 = param_2;
  }
  else {
    uStack_10 = (uStack_10 >> 1) + uStack_10;
    if (uStack_10 < param_2) {
      uStack_10 = param_2;
    }
  }
  puVar2 = (undefined4 *)FUN_0078e090(uStack_10);
  FUN_0078dff0(puVar2 + uVar7 * 4,param_2 - uVar7);
  puVar1 = (undefined4 *)param_1[1];
  puVar8 = (undefined4 *)*param_1;
  puVar3 = puVar2;
  if (puVar8 != puVar1) {
    puVar5 = puVar8 + 3;
    puVar6 = puVar2 + 3;
    do {
      *puVar3 = *puVar8;
      puVar8 = puVar8 + 4;
      puVar6[-2] = puVar5[-2];
      puVar3 = puVar3 + 4;
      puVar6[-1] = 0;
      *puVar6 = 0;
      puVar6[-1] = puVar5[-1];
      *puVar6 = *puVar5;
      puVar5[-1] = 0;
      *puVar5 = 0;
      puVar5 = puVar5 + 4;
      puVar6 = puVar6 + 4;
    } while (puVar8 != puVar1);
  }
  FUN_0075c360(puVar3,puVar3,param_1);
  if (*param_1 != 0) {
    FUN_0075c360(*param_1,param_1[1],param_1);
    iVar4 = *param_1;
    uVar7 = param_1[2] - iVar4 & 0xfffffff0;
    iVar9 = iVar4;
    if (0xfff < uVar7) {
      iVar9 = *(int *)(iVar4 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar4 - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar9,uVar7);
  }
  *param_1 = (int)puVar2;
  param_1[1] = (int)(puVar2 + param_2 * 4);
  param_1[2] = (int)(puVar2 + uStack_10 * 4);
  return;
}



/* FUNCTION 11286 ; VA 0x0078da70 ; FUN_0078da70 */

undefined4 *
FUN_0078da70(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  
  puVar5 = param_3;
  if (param_1 != param_2) {
    puVar3 = param_1 + 0xc;
    puVar4 = param_3 + 0xd;
    do {
      puVar1 = puVar3 + 0x14;
      *puVar5 = puVar3[-0xc];
      puVar5 = puVar5 + 0x14;
      puVar4[-0xc] = puVar3[-0xb];
      *(undefined8 *)(puVar4 + -0xb) = *(undefined8 *)(puVar3 + -10);
      puVar4[-9] = puVar3[-8];
      *(undefined2 *)(puVar4 + -8) = *(undefined2 *)(puVar3 + -7);
      *(undefined *)((int)puVar4 + -0x1e) = *(undefined *)((int)puVar3 + -0x1a);
      *(undefined8 *)(puVar4 + -7) = *(undefined8 *)(puVar3 + -6);
      puVar4[-5] = puVar3[-4];
      puVar4[-4] = 0;
      puVar4[-3] = 0;
      puVar4[-4] = puVar3[-3];
      puVar4[-3] = puVar3[-2];
      puVar3[-3] = 0;
      puVar3[-2] = 0;
      puVar4[-2] = 0;
      *(undefined4 *)((int)param_3 + (-0x50 - (int)param_1) + (int)puVar1) = 0;
      *puVar4 = 0;
      puVar4[-2] = puVar3[-1];
      *(undefined4 *)((int)param_3 + (-0x50 - (int)param_1) + (int)puVar1) = *puVar3;
      *puVar4 = puVar3[1];
      puVar3[-1] = 0;
      *puVar3 = 0;
      puVar3[1] = 0;
      puVar4[1] = 0;
      puVar4[2] = 0;
      puVar4[3] = 0;
      puVar4[1] = puVar3[2];
      puVar4[2] = puVar3[3];
      puVar4[3] = puVar3[4];
      puVar3[2] = 0;
      puVar3[3] = 0;
      puVar3[4] = 0;
      puVar4[4] = 0;
      puVar4[5] = 0;
      puVar4[6] = 0;
      puVar4[4] = puVar3[5];
      puVar4[5] = puVar3[6];
      puVar4[6] = puVar3[7];
      puVar2 = puVar3 + 8;
      puVar3[5] = 0;
      puVar3[6] = 0;
      puVar3[7] = 0;
      puVar3 = puVar1;
      puVar4 = puVar4 + 0x14;
    } while (puVar2 != param_2);
  }
  FUN_0075c400(puVar5,puVar5,param_4);
  return puVar5;
}



/* FUNCTION 11287 ; VA 0x0078dbd0 ; FUN_0078dbd0 */

void FUN_0078dbd0(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b0ee1;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_2 = *param_3;
  param_2[1] = param_3[1];
  *(undefined8 *)(param_2 + 2) = *(undefined8 *)(param_3 + 2);
  param_2[4] = param_3[4];
  *(undefined2 *)(param_2 + 5) = *(undefined2 *)(param_3 + 5);
  *(undefined *)((int)param_2 + 0x16) = *(undefined *)((int)param_3 + 0x16);
  *(undefined8 *)(param_2 + 6) = *(undefined8 *)(param_3 + 6);
  param_2[8] = param_3[8];
  param_2[9] = 0;
  param_2[10] = 0;
  if (param_3[10] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[10] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[9] = param_3[9];
  param_2[10] = param_3[10];
  uStack_8 = 0;
  FUN_0078dde0(param_3 + 0xb);
  uStack_8._0_1_ = 1;
  FUN_0078dd30(param_3 + 0xe);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0078dca0(param_3 + 0x11);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11288 ; VA 0x0078dca0 ; FUN_0078dca0 */

int * __thiscall FUN_0078dca0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined auStack_10 [4];
  int *piStack_c;
  undefined uStack_5;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar3 = param_2[1] - *param_2;
  if (uVar3 != 0) {
    piStack_c = param_1;
    if (0x7fffffff < uVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar2 = FUN_00554060(uVar3);
    *param_1 = iVar2;
    param_1[1] = iVar2;
    param_1[2] = *param_1 + uVar3;
    iVar2 = *param_2;
    iVar1 = *param_1;
    FUN_0055b6b0(&uStack_5,auStack_10,auStack_10);
    iVar4 = param_2[1] - iVar2;
    FUN_0170cc70(iVar1,iVar2,iVar4);
    piStack_c[1] = iVar1 + iVar4;
    param_1 = piStack_c;
  }
  return param_1;
}



/* FUNCTION 11289 ; VA 0x0078dd30 ; FUN_0078dd30 */

int * __thiscall FUN_0078dd30(int *param_1,int *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 *puVar8;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar7 = param_2[1] - *param_2 >> 4;
  if (uVar7 != 0) {
    if (0xfffffff < uVar7) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar4 = FUN_0078e090(uVar7);
    *param_1 = iVar4;
    param_1[1] = iVar4;
    param_1[2] = uVar7 * 0x10 + *param_1;
    puVar5 = (undefined4 *)*param_2;
    puVar3 = (undefined4 *)param_2[1];
    puVar8 = (undefined4 *)*param_1;
    if (puVar5 != puVar3) {
      puVar6 = puVar8 + 3;
      do {
        *puVar8 = *puVar5;
        puVar6[-2] = puVar5[1];
        puVar6[-1] = 0;
        *puVar6 = 0;
        if (puVar5[3] != 0) {
          LOCK();
          piVar1 = (int *)(puVar5[3] + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        puVar8 = puVar8 + 4;
        puVar6[-1] = puVar5[2];
        puVar2 = puVar5 + 3;
        puVar5 = puVar5 + 4;
        *puVar6 = *puVar2;
        puVar6 = puVar6 + 4;
      } while (puVar5 != puVar3);
    }
    FUN_0075c360(puVar8,puVar8,param_1);
    param_1[1] = (int)puVar8;
  }
  return param_1;
}



/* FUNCTION 11290 ; VA 0x0078dde0 ; FUN_0078dde0 */

int * __thiscall FUN_0078dde0(int *param_1,int *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar3 = (param_2[1] - *param_2) / 0x14;
  if (uVar3 != 0) {
    if (0xccccccc < uVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar4 = FUN_00618130(uVar3);
    *param_1 = iVar4;
    param_1[1] = iVar4;
    param_1[2] = *param_1 + uVar3 * 0x14;
    puVar2 = (undefined4 *)param_2[1];
    puVar6 = (undefined4 *)*param_1;
    for (puVar5 = (undefined4 *)*param_2; puVar5 != puVar2; puVar5 = puVar5 + 5) {
      *puVar6 = 0;
      puVar6[1] = 0;
      if (puVar5[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar5[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      *puVar6 = *puVar5;
      puVar6[1] = puVar5[1];
      *(undefined8 *)(puVar6 + 2) = *(undefined8 *)(puVar5 + 2);
      puVar6[4] = puVar5[4];
      puVar6 = puVar6 + 5;
    }
    FUN_0075c3b0(puVar6,puVar6,param_1);
    param_1[1] = (int)puVar6;
  }
  return param_1;
}



/* FUNCTION 11291 ; VA 0x0078dea0 ; FUN_0078dea0 */

int __fastcall FUN_0078dea0(int param_1)

{
  FUN_016f4053(param_1,0xc,3,FUN_00569440,FUN_0075e040);
  *(undefined4 *)(param_1 + 0x24) = 0;
  return param_1;
}



/* FUNCTION 11292 ; VA 0x0078ded0 ; FUN_0078ded0 */

undefined4 * __thiscall
FUN_0078ded0(undefined4 *param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  
  *param_1 = param_3;
  param_1[1] = param_4;
  *(undefined2 *)(param_1 + 2) = 1;
  param_1[3] = 0;
  *(undefined *)(param_1 + 4) = 0;
  *(undefined2 *)(param_1 + 5) = 0x102;
  *(undefined *)((int)param_1 + 0x16) = 0;
  param_1[7] = 0x1000100;
  param_1[6] = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[9] = *param_2;
  param_1[10] = param_2[1];
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  return param_1;
}



/* FUNCTION 11293 ; VA 0x0078df80 ; FUN_0078df80 */

undefined4 * __thiscall FUN_0078df80(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  
  puVar2 = (undefined4 *)param_1[1];
  uVar3 = *param_1;
  if (param_3 != 0) {
    do {
      *param_2 = 0;
      param_2[1] = 0;
      if (puVar2[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar2[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      *param_2 = *puVar2;
      param_2[1] = puVar2[1];
      *(undefined8 *)(param_2 + 2) = *(undefined8 *)(puVar2 + 2);
      param_2[4] = puVar2[4];
      param_2 = param_2 + 5;
      param_3 = param_3 + -1;
    } while (param_3 != 0);
  }
  FUN_0075c3b0(param_2,param_2,uVar3);
  return param_2;
}



/* FUNCTION 11294 ; VA 0x0078dff0 ; FUN_0078dff0 */

undefined4 * __thiscall FUN_0078dff0(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  undefined4 uVar1;
  
  uVar1 = *param_1;
  if (param_3 != 0) {
    do {
      *param_2 = 0;
      param_2[1] = 0;
      param_2[2] = 0;
      param_2[3] = 0;
      param_2 = param_2 + 4;
      param_3 = param_3 + -1;
    } while (param_3 != 0);
  }
  FUN_0075c360(param_2,param_2,uVar1);
  return param_2;
}



/* FUNCTION 11295 ; VA 0x0078e040 ; FUN_0078e040 */

void __thiscall FUN_0078e040(int param_1,undefined4 param_2,int param_3)

{
  if (DAT_01d60bc0 != '\0') {
    param_3 = 0;
  }
  param_1 = param_1 + param_3 * 0xc;
  if (*(int *)(param_1 + 8) != *(int *)(param_1 + 4)) {
    FUN_0078dbd0(param_1);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x50;
    return;
  }
  FUN_0078d4f0(*(int *)(param_1 + 4),param_2);
  return;
}



/* FUNCTION 11296 ; VA 0x0078e090 ; FUN_0078e090 */

uint FUN_0078e090(uint param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = param_1 << 4;
  if (param_1 < 0x10000000) {
    if (uVar3 < 0x1000) {
      if (uVar3 != 0) {
        uVar3 = FUN_01674e20(uVar3);
        return uVar3;
      }
      return 0;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar3 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar2;
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 11297 ; VA 0x0078e100 ; FUN_0078e100 */

void __thiscall FUN_0078e100(int param_1,int *param_2)

{
  (**(code **)(*param_2 + 0x3c))(param_1 + 8,param_1 + 0x18,param_1 + 0x14);
  (**(code **)(*param_2 + 0x24))(*(undefined4 *)(param_1 + 0x24));
  FUN_0078e140(param_2);
  return;
}



/* FUNCTION 11298 ; VA 0x0078e140 ; FUN_0078e140 */

void __thiscall FUN_0078e140(int param_1,int *param_2)

{
  uint uVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  int iStack_8;
  
  piVar3 = param_2;
  uVar7 = 0;
  iVar4 = *(int *)(param_1 + 0x24);
  iVar5 = *(int *)(param_1 + 0x38);
  uVar1 = *(uint *)(iVar4 + 0x40);
  if (*(int *)(param_1 + 0x3c) - iVar5 >> 4 != 0) {
    iStack_8 = 0;
    do {
      if ((uVar1 & 1 << ((byte)uVar7 & 0x1f)) != 0) {
        iVar4 = *(int *)(iStack_8 + 4 + iVar5);
        if (iVar4 == 0) {
          iVar4 = *(int *)(iStack_8 + 8 + iVar5);
          if (iVar4 != 0) {
            (**(code **)(*param_2 + 0x28))(uVar7,iVar4);
          }
        }
        else {
          (**(code **)(*param_2 + 0x30))
                    (uVar7,*(int *)(param_1 + 0x44) + *(int *)(iStack_8 + *(int *)(param_1 + 0x38)),
                     iVar4);
        }
      }
      uVar7 = uVar7 + 1;
      iVar5 = *(int *)(param_1 + 0x38);
      iStack_8 = iStack_8 + 0x10;
    } while (uVar7 < (uint)(*(int *)(param_1 + 0x3c) - iVar5 >> 4));
    iVar4 = *(int *)(param_1 + 0x24);
  }
  uVar1 = *(uint *)(iVar4 + 0x44);
  uVar7 = 0;
  iVar5 = *(int *)(param_1 + 0x30) - *(int *)(param_1 + 0x2c);
  iVar4 = iVar5 >> 0x1f;
  if (iVar5 / 0x14 + iVar4 != iVar4) {
    param_2 = (int *)0x0;
    do {
      piVar2 = *(int **)((int)param_2 + *(int *)(param_1 + 0x2c));
      piVar6 = (int *)&DAT_01eb1b04;
      if (piVar2 != (int *)0x0) {
        piVar6 = piVar2;
      }
      if ((*piVar6 != 0) && ((uVar1 & 1 << ((byte)uVar7 & 0x1f)) != 0)) {
        (**(code **)(*piVar3 + 0x34))(uVar7,*piVar6,*(int *)(param_1 + 0x2c) + (int)param_2 + 8);
      }
      param_2 = (int *)((int)param_2 + 0x14);
      uVar7 = uVar7 + 1;
    } while (uVar7 < (uint)((*(int *)(param_1 + 0x30) - *(int *)(param_1 + 0x2c)) / 0x14));
  }
  return;
}



/* FUNCTION 11299 ; VA 0x0078e270 ; FUN_0078e270 */

void FUN_0078e270(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  
  if ((DAT_01d60bc0 != '\0') ||
     ((iVar1 = FUN_0078e2b0(param_1,param_2,param_3), iVar1 == 0 && (param_3 != 0)))) {
    FUN_0078e2b0(param_1,param_2,0);
  }
  return;
}



/* FUNCTION 11300 ; VA 0x0078e2b0 ; FUN_0078e2b0 */

uint * __thiscall FUN_0078e2b0(int param_1,uint param_2,uint param_3,int param_4)

{
  int iVar1;
  uint *puVar2;
  int iVar3;
  uint *puVar4;
  uint uVar5;
  
  puVar4 = (uint *)0x0;
  puVar2 = *(uint **)(param_1 + param_4 * 0xc);
  uVar5 = 0;
  iVar3 = *(int *)(param_1 + 4 + param_4 * 0xc) - (int)puVar2;
  iVar1 = iVar3 >> 0x1f;
  iVar3 = iVar3 / 0x50 + iVar1;
  if (iVar3 != iVar1) {
    do {
      if (puVar2[1] == param_3) {
        if (param_2 <= *puVar2) {
          return puVar2;
        }
        if ((DAT_01d60bc0 == '\0') && (param_4 == 0)) {
          puVar4 = puVar2;
        }
      }
      uVar5 = uVar5 + 1;
      puVar2 = puVar2 + 0x14;
    } while (uVar5 < (uint)(iVar3 - iVar1));
  }
  return puVar4;
}



/* FUNCTION 11301 ; VA 0x0078e320 ; FUN_0078e320 */

undefined * __thiscall FUN_0078e320(int param_1,uint param_2)

{
  if (param_2 < (uint)((*(int *)(param_1 + 0x30) - *(int *)(param_1 + 0x2c)) / 0x14)) {
    return (undefined *)(*(int *)(param_1 + 0x2c) + param_2 * 0x14);
  }
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1cd4) {
    FUN_016f3809(&DAT_01eb1cd4);
    if (DAT_01eb1cd4 == -1) {
      FUN_016f3654(&LAB_0187f1d0);
      FUN_016f37bf(&DAT_01eb1cd4);
    }
  }
  return &DAT_01eb1ccc;
}



/* FUNCTION 11302 ; VA 0x0078e3b0 ; FUN_0078e3b0 */

uint __fastcall FUN_0078e3b0(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iStack_8;
  
  iStack_8 = 0;
  do {
    for (iVar2 = *param_1; iVar2 != param_1[1]; iVar2 = iVar2 + 0x50) {
      for (piVar1 = *(int **)(iVar2 + 0x2c); piVar1 != *(int **)(iVar2 + 0x30); piVar1 = piVar1 + 5)
      {
        if ((*piVar1 != 0) && (*(int *)(*piVar1 + 8) == 1)) {
          return (uint)piVar1 & 0xffffff00;
        }
      }
    }
    iStack_8 = iStack_8 + 1;
    param_1 = param_1 + 3;
    if (2 < iStack_8) {
      return CONCAT31((int3)((uint)iStack_8 >> 8),1);
    }
  } while( true );
}



/* FUNCTION 11303 ; VA 0x0078e420 ; FUN_0078e420 */

void __fastcall FUN_0078e420(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = 3;
  do {
    FUN_0075c400(*param_1,param_1[1],param_1);
    param_1[1] = *param_1;
    param_1 = param_1 + 3;
    iVar1 = iVar1 + -1;
  } while (iVar1 != 0);
  return;
}



/* FUNCTION 11304 ; VA 0x0078e450 ; FUN_0078e450 */

undefined FUN_0078e450(undefined4 param_1)

{
  char cVar1;
  
  cVar1 = FUN_009d7ee0(param_1);
  if (cVar1 != '\0') {
    return 2;
  }
  cVar1 = FUN_009d7fc0(param_1);
  return cVar1 != '\0';
}



/* FUNCTION 11305 ; VA 0x0078e480 ; FUN_0078e480 */

void __thiscall FUN_0078e480(int param_1,undefined8 *param_2)

{
  *(undefined8 *)(param_1 + 0x18) = *param_2;
  *(undefined4 *)(param_1 + 0x20) = *(undefined4 *)(param_2 + 1);
  return;
}



/* FUNCTION 11306 ; VA 0x0078e4a0 ; FUN_0078e4a0 */

void __thiscall FUN_0078e4a0(int param_1,uint param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  iVar2 = *(int *)(param_1 + 0x38);
  if ((uint)(*(int *)(param_1 + 0x3c) - iVar2 >> 4) <= param_2) {
    FUN_0078d8d0(param_2 + 1,(int *)(param_1 + 0x38));
    iVar2 = *(int *)(param_1 + 0x38);
  }
  piVar3 = (int *)(param_2 * 0x10 + iVar2);
  if (piVar3[1] == 0) {
    piVar1 = (int *)(param_1 + 0x44);
    *piVar3 = *(int *)(param_1 + 0x48) - *piVar1;
    piVar3[1] = param_4;
    FUN_00715060((*(int *)(param_1 + 0x48) - *piVar1) + param_4,piVar1);
  }
  FUN_0170c6f0(*piVar3 + *(int *)(param_1 + 0x44),param_3,param_4);
  return;
}



/* FUNCTION 11307 ; VA 0x0078e510 ; FUN_0078e510 */

void __thiscall FUN_0078e510(int param_1,undefined2 *param_2)

{
  *(undefined2 *)(param_1 + 0x14) = *param_2;
  *(undefined *)(param_1 + 0x16) = *(undefined *)(param_2 + 1);
  return;
}



/* FUNCTION 11308 ; VA 0x0078e530 ; FUN_0078e530 */

void __thiscall FUN_0078e530(int param_1,undefined8 *param_2)

{
  *(undefined8 *)(param_1 + 8) = *param_2;
  *(undefined4 *)(param_1 + 0x10) = *(undefined4 *)(param_2 + 1);
  return;
}



/* FUNCTION 11309 ; VA 0x0078e550 ; FUN_0078e550 */

int __thiscall FUN_0078e550(int param_1,uint param_2,undefined4 *param_3,undefined8 *param_4)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined2 uStack_24;
  undefined4 uStack_20;
  undefined2 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0ef8;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)(param_1 + 0x2c);
  ExceptionList = &pvStack_10;
  if ((uint)((*(int *)(param_1 + 0x30) - *piVar1) / 0x14) <= param_2) {
    uStack_2c = 0;
    piStack_28 = (int *)0x0;
    uStack_24 = 0;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_0078d700(param_2 + 1,piVar1,&uStack_2c);
    piVar7 = piStack_28;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_28[1] + -1;
      piStack_28[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        piVar2 = piVar7 + 2;
        iVar6 = *piVar2 + -1;
        *piVar2 = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
  }
  piVar7 = (int *)param_3[1];
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar7[1] = piVar7[1] + 1;
    UNLOCK();
    piVar7 = (int *)param_3[1];
  }
  uVar4 = *param_3;
  uStack_18 = *param_4;
  iVar6 = *(int *)(param_4 + 1);
  puVar3 = (undefined4 *)(*piVar1 + param_2 * 0x14);
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar7[1] = piVar7[1] + 1;
    UNLOCK();
  }
  *puVar3 = uVar4;
  piVar1 = (int *)puVar3[1];
  puVar3[1] = piVar7;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar5 = piVar1[1] + -1;
    piVar1[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar5 = piVar1[2] + -1;
      piVar1[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  *(undefined8 *)(puVar3 + 2) = uStack_18;
  puVar3[4] = iVar6;
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar1 = piVar7 + 1;
    iVar5 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      iVar6 = (**(code **)*piVar7)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        iVar6 = (**(code **)(*piVar7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 11310 ; VA 0x0078e6a0 ; FUN_0078e6a0 */

int __fastcall FUN_0078e6a0(int param_1)

{
  uint *puVar1;
  float fVar2;
  float fVar3;
  uint *puVar4;
  uint uVar5;
  float *pfVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  uint *puVar12;
  undefined auStack_c4 [72];
  int iStack_7c;
  uint uStack_68;
  uint uStack_64;
  undefined4 uStack_54;
  uint uStack_50;
  uint uStack_4c;
  undefined4 uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined4 uStack_24;
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0f18;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  FUN_016f4053(param_1,0xa8,0x18,FUN_0078ec30,FUN_00789520);
  uStack_8 = 0;
  iStack_18 = 0;
  puVar12 = (uint *)(param_1 + 0x5c);
  do {
    puVar4 = (uint *)FUN_0078ed30(auStack_c4,iStack_18);
    puVar1 = puVar4 + 0x12;
    puVar12[-0x17] = *puVar4;
    uVar11 = puVar4[2];
    uVar10 = puVar4[3];
    uVar5 = puVar4[4];
    puVar12[-0x16] = puVar4[1];
    puVar12[-0x15] = uVar11;
    puVar12[-0x14] = uVar10;
    puVar12[-0x13] = uVar5;
    uVar11 = puVar4[6];
    uVar10 = puVar4[7];
    uVar5 = puVar4[8];
    puVar12[-0x12] = puVar4[5];
    puVar12[-0x11] = uVar11;
    puVar12[-0x10] = uVar10;
    puVar12[-0xf] = uVar5;
    uVar11 = puVar4[10];
    uVar10 = puVar4[0xb];
    uVar5 = puVar4[0xc];
    puVar12[-0xe] = puVar4[9];
    puVar12[-0xd] = uVar11;
    puVar12[-0xc] = uVar10;
    puVar12[-0xb] = uVar5;
    uVar11 = puVar4[0xe];
    uVar10 = puVar4[0xf];
    uVar5 = puVar4[0x10];
    puVar12[-10] = puVar4[0xd];
    puVar12[-9] = uVar11;
    puVar12[-8] = uVar10;
    puVar12[-7] = uVar5;
    *(undefined *)(puVar12 + -6) = *(undefined *)(puVar4 + 0x11);
    *(undefined *)((int)puVar12 + -0x17) = *(undefined *)((int)puVar4 + 0x45);
    puStack_14 = puVar4;
    if (puVar12 + -5 != puVar1) {
      uVar11 = *puVar12;
      if (0xf < uVar11) {
        uVar10 = puVar12[-5];
        uVar7 = uVar11 + 1;
        uVar5 = uVar10;
        if (0xfff < uVar7) {
          uVar5 = *(uint *)(uVar10 - 4);
          uVar7 = uVar11 + 0x24;
          if (0x1f < (uVar10 - uVar5) - 4) goto LAB_0078eadc;
        }
        FUN_01674ea0(uVar5,uVar7);
      }
      puVar12[-1] = 0;
      *puVar12 = 0xf;
      *(undefined *)(puVar12 + -5) = 0;
      uVar11 = puVar4[0x13];
      uVar10 = puVar4[0x14];
      uVar5 = puVar4[0x15];
      puVar12[-5] = *puVar1;
      puVar12[-4] = uVar11;
      puVar12[-3] = uVar10;
      puVar12[-2] = uVar5;
      *(undefined8 *)(puVar12 + -1) = *(undefined8 *)(puVar4 + 0x16);
      puVar4[0x16] = 0;
      puVar4[0x17] = 0xf;
      *(undefined *)puVar1 = 0;
    }
    puVar4 = puStack_14;
    puVar1 = puStack_14 + 0x18;
    if (puVar12 + 1 != puVar1) {
      uVar11 = puVar12[6];
      if (0xf < uVar11) {
        uVar10 = puVar12[1];
        uVar7 = uVar11 + 1;
        uVar5 = uVar10;
        if (0xfff < uVar7) {
          uVar5 = *(uint *)(uVar10 - 4);
          uVar7 = uVar11 + 0x24;
          if (0x1f < (uVar10 - uVar5) - 4) goto LAB_0078eadc;
        }
        FUN_01674ea0(uVar5,uVar7);
      }
      puVar12[5] = 0;
      puVar12[6] = 0xf;
      *(undefined *)(puVar12 + 1) = 0;
      uVar11 = puVar4[0x19];
      uVar10 = puVar4[0x1a];
      uVar5 = puVar4[0x1b];
      puVar12[1] = *puVar1;
      puVar12[2] = uVar11;
      puVar12[3] = uVar10;
      puVar12[4] = uVar5;
      *(undefined8 *)(puVar12 + 5) = *(undefined8 *)(puVar4 + 0x1c);
      puVar4[0x1c] = 0;
      puVar4[0x1d] = 0xf;
      *(undefined *)puVar1 = 0;
    }
    puVar4 = puStack_14;
    puVar1 = puStack_14 + 0x1e;
    if (puVar12 + 7 != puVar1) {
      uVar11 = puVar12[0xc];
      if (0xf < uVar11) {
        uVar10 = puVar12[7];
        uVar7 = uVar11 + 1;
        uVar5 = uVar10;
        if (0xfff < uVar7) {
          uVar5 = *(uint *)(uVar10 - 4);
          uVar7 = uVar11 + 0x24;
          if (0x1f < (uVar10 - uVar5) - 4) goto LAB_0078eadc;
        }
        FUN_01674ea0(uVar5,uVar7);
      }
      puVar12[0xb] = 0;
      puVar12[0xc] = 0xf;
      *(undefined *)(puVar12 + 7) = 0;
      uVar11 = puVar4[0x1f];
      uVar10 = puVar4[0x20];
      uVar5 = puVar4[0x21];
      puVar12[7] = *puVar1;
      puVar12[8] = uVar11;
      puVar12[9] = uVar10;
      puVar12[10] = uVar5;
      *(undefined8 *)(puVar12 + 0xb) = *(undefined8 *)(puVar4 + 0x22);
      puVar4[0x22] = 0;
      puVar4[0x23] = 0xf;
      *(undefined *)puVar1 = 0;
    }
    puVar4 = puStack_14;
    puVar1 = puStack_14 + 0x24;
    if (puVar12 + 0xd != puVar1) {
      uVar11 = puVar12[0x12];
      if (0xf < uVar11) {
        uVar10 = puVar12[0xd];
        uVar7 = uVar11 + 1;
        uVar5 = uVar10;
        if (0xfff < uVar7) {
          uVar5 = *(uint *)(uVar10 - 4);
          uVar7 = uVar11 + 0x24;
          if (0x1f < (uVar10 - uVar5) - 4) goto LAB_0078eadc;
        }
        FUN_01674ea0(uVar5,uVar7);
      }
      puVar12[0x11] = 0;
      puVar12[0x12] = 0xf;
      *(undefined *)(puVar12 + 0xd) = 0;
      uVar11 = puVar4[0x25];
      uVar10 = puVar4[0x26];
      uVar5 = puVar4[0x27];
      puVar12[0xd] = *puVar1;
      puVar12[0xe] = uVar11;
      puVar12[0xf] = uVar10;
      puVar12[0x10] = uVar5;
      *(undefined8 *)(puVar12 + 0x11) = *(undefined8 *)(puVar4 + 0x28);
      puVar4[0x28] = 0;
      puVar4[0x29] = 0xf;
      *(undefined *)puVar1 = 0;
    }
    if (0xf < uStack_20) {
      uVar10 = uStack_20 + 1;
      uVar11 = uStack_34;
      if (0xfff < uVar10) {
        uVar11 = *(uint *)(uStack_34 - 4);
        uVar10 = uStack_20 + 0x24;
        if (0x1f < (uStack_34 - uVar11) - 4) goto LAB_0078eadc;
      }
      FUN_01674ea0(uVar11,uVar10);
    }
    uStack_24 = 0;
    uStack_20 = 0xf;
    uStack_34 = uStack_34 & 0xffffff00;
    if (0xf < uStack_38) {
      uVar10 = uStack_38 + 1;
      uVar11 = uStack_4c;
      if (0xfff < uVar10) {
        uVar11 = *(uint *)(uStack_4c - 4);
        uVar10 = uStack_38 + 0x24;
        if (0x1f < (uStack_4c - uVar11) - 4) goto LAB_0078eadc;
      }
      FUN_01674ea0(uVar11,uVar10);
    }
    uStack_3c = 0;
    uStack_38 = 0xf;
    uStack_4c = uStack_4c & 0xffffff00;
    if (0xf < uStack_50) {
      uVar10 = uStack_50 + 1;
      uVar11 = uStack_64;
      if (0xfff < uVar10) {
        uVar11 = *(uint *)(uStack_64 - 4);
        uVar10 = uStack_50 + 0x24;
        if (0x1f < (uStack_64 - uVar11) - 4) goto LAB_0078eadc;
      }
      FUN_01674ea0(uVar11,uVar10);
    }
    uStack_54 = 0;
    uStack_50 = 0xf;
    uStack_64 = uStack_64 & 0xffffff00;
    if (0xf < uStack_68) {
      uVar11 = uStack_68 + 1;
      iVar8 = iStack_7c;
      if (0xfff < uVar11) {
        iVar8 = *(int *)(iStack_7c + -4);
        uVar11 = uStack_68 + 0x24;
        if (0x1f < (iStack_7c - iVar8) - 4U) {
LAB_0078eadc:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar8,uVar11);
    }
    iVar8 = iStack_1c;
    puVar12 = puVar12 + 0x2a;
    iStack_18 = iStack_18 + 1;
    if (0x17 < iStack_18) {
      FUN_0078f670(&DAT_01d60ea8);
      fVar3 = DAT_018fd17c;
      fVar2 = DAT_018ce2f8;
      pfVar6 = (float *)(iVar8 + 0x34);
      iVar9 = 0x18;
      do {
        if (pfVar6[-4] < fVar3) {
          *pfVar6 = fVar2 / (fVar2 - pfVar6[-4]);
        }
        else {
          *pfVar6 = 3.4028235e+38;
        }
        if (pfVar6[-3] < fVar3) {
          pfVar6[1] = fVar2 / (fVar2 - pfVar6[-3]);
        }
        else {
          pfVar6[1] = 3.4028235e+38;
        }
        if (pfVar6[-2] <= fVar3) {
          pfVar6[2] = fVar2 / (fVar2 - pfVar6[-2]);
        }
        else {
          pfVar6[2] = 3.4028235e+38;
        }
        pfVar6 = pfVar6 + 0x2a;
        iVar9 = iVar9 + -1;
      } while (iVar9 != 0);
      ExceptionList = pvStack_10;
      return iVar8;
    }
  } while( true );
}



/* FUNCTION 11311 ; VA 0x0078eaf0 ; FUN_0078eaf0 */

undefined4 * __thiscall FUN_0078eaf0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  *param_1 = *param_2;
  uVar1 = param_2[2];
  uVar2 = param_2[3];
  uVar3 = param_2[4];
  param_1[1] = param_2[1];
  param_1[2] = uVar1;
  param_1[3] = uVar2;
  param_1[4] = uVar3;
  uVar1 = param_2[6];
  uVar2 = param_2[7];
  uVar3 = param_2[8];
  param_1[5] = param_2[5];
  param_1[6] = uVar1;
  param_1[7] = uVar2;
  param_1[8] = uVar3;
  uVar1 = param_2[10];
  uVar2 = param_2[0xb];
  uVar3 = param_2[0xc];
  param_1[9] = param_2[9];
  param_1[10] = uVar1;
  param_1[0xb] = uVar2;
  param_1[0xc] = uVar3;
  uVar1 = param_2[0xe];
  uVar2 = param_2[0xf];
  uVar3 = param_2[0x10];
  param_1[0xd] = param_2[0xd];
  param_1[0xe] = uVar1;
  param_1[0xf] = uVar2;
  param_1[0x10] = uVar3;
  *(undefined *)(param_1 + 0x11) = *(undefined *)(param_2 + 0x11);
  *(undefined *)((int)param_1 + 0x45) = *(undefined *)((int)param_2 + 0x45);
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  uVar1 = param_2[0x13];
  uVar2 = param_2[0x14];
  uVar3 = param_2[0x15];
  param_1[0x12] = param_2[0x12];
  param_1[0x13] = uVar1;
  param_1[0x14] = uVar2;
  param_1[0x15] = uVar3;
  *(undefined8 *)(param_1 + 0x16) = *(undefined8 *)(param_2 + 0x16);
  param_2[0x16] = 0;
  param_2[0x17] = 0xf;
  *(undefined *)(param_2 + 0x12) = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  uVar1 = param_2[0x19];
  uVar2 = param_2[0x1a];
  uVar3 = param_2[0x1b];
  param_1[0x18] = param_2[0x18];
  param_1[0x19] = uVar1;
  param_1[0x1a] = uVar2;
  param_1[0x1b] = uVar3;
  *(undefined8 *)(param_1 + 0x1c) = *(undefined8 *)(param_2 + 0x1c);
  param_2[0x1c] = 0;
  param_2[0x1d] = 0xf;
  *(undefined *)(param_2 + 0x18) = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  uVar1 = param_2[0x1f];
  uVar2 = param_2[0x20];
  uVar3 = param_2[0x21];
  param_1[0x1e] = param_2[0x1e];
  param_1[0x1f] = uVar1;
  param_1[0x20] = uVar2;
  param_1[0x21] = uVar3;
  *(undefined8 *)(param_1 + 0x22) = *(undefined8 *)(param_2 + 0x22);
  param_2[0x22] = 0;
  param_2[0x23] = 0xf;
  *(undefined *)(param_2 + 0x1e) = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  uVar1 = param_2[0x25];
  uVar2 = param_2[0x26];
  uVar3 = param_2[0x27];
  param_1[0x24] = param_2[0x24];
  param_1[0x25] = uVar1;
  param_1[0x26] = uVar2;
  param_1[0x27] = uVar3;
  *(undefined8 *)(param_1 + 0x28) = *(undefined8 *)(param_2 + 0x28);
  param_2[0x28] = 0;
  param_2[0x29] = 0xf;
  *(undefined *)(param_2 + 0x24) = 0;
  return param_1;
}



/* FUNCTION 11312 ; VA 0x0078ec30 ; FUN_0078ec30 */

int __fastcall FUN_0078ec30(int param_1)

{
  float fVar1;
  float fVar2;
  
  fVar1 = DAT_018ce2f8;
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 4) = 0x3f800000;
  *(undefined4 *)(param_1 + 8) = 0x3f800000;
  *(undefined4 *)(param_1 + 0xc) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x10) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x14) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x18) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x1c) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x20) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x40) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x34) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x38) = 0x3f800000;
  fVar2 = DAT_018c45c4;
  if (*(float *)(param_1 + 0x2c) <= DAT_018fd17c) {
    fVar2 = fVar1 / (fVar1 - *(float *)(param_1 + 0x2c));
  }
  *(float *)(param_1 + 0x3c) = fVar2;
  *(undefined4 *)(param_1 + 0x58) = 0;
  *(undefined4 *)(param_1 + 0x5c) = 0xf;
  *(undefined *)(param_1 + 0x48) = 0;
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0xf;
  *(undefined *)(param_1 + 0x60) = 0;
  *(undefined4 *)(param_1 + 0x88) = 0;
  *(undefined4 *)(param_1 + 0x8c) = 0xf;
  *(undefined *)(param_1 + 0x78) = 0;
  *(undefined4 *)(param_1 + 0xa0) = 0;
  *(undefined4 *)(param_1 + 0xa4) = 0xf;
  *(undefined *)(param_1 + 0x90) = 0;
  return param_1;
}



/* FUNCTION 11313 ; VA 0x0078ed30 ; FUN_0078ed30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0078ed30(undefined4 param_1,undefined4 param_2)

{
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_6c;
  undefined2 uStack_68;
  
  FUN_0078ec30();
  switch(param_2) {
  case 0:
    uStack_a8 = 0x3f800000;
    uStack_a4 = 0x3f19999a;
    uStack_98 = 0x3f000000;
  default:
switchD_0078ed4d_caseD_18:
    uStack_ac = 0;
LAB_0078ed7c:
    uStack_68 = 0x101;
    goto LAB_0078ed82;
  case 1:
    uStack_ac = 1;
    uStack_a8 = 0x3f800000;
    uStack_a4 = 0x3f19999a;
    uStack_98 = 0x3f000000;
    goto LAB_0078ed7c;
  case 2:
    uStack_a8 = 0;
    uStack_a4 = 0x3ecccccd;
    uStack_98 = 0;
    uStack_6c = 0;
    goto switchD_0078ed4d_caseD_18;
  case 3:
    uStack_ac = 1;
    uStack_a8 = 0;
    uStack_a4 = 0x3ecccccd;
    uStack_98 = 0;
    uStack_6c = 0;
    goto LAB_0078ed7c;
  case 4:
    uStack_ac = 2;
    uStack_a8 = 0;
    uStack_98 = 0;
    goto LAB_0078ed7c;
  case 5:
    uStack_a0 = _DAT_018fd240;
    uStack_9c = _UNK_018fd244;
    uStack_98 = _UNK_018fd248;
    uStack_94 = _UNK_018fd24c;
    break;
  case 6:
  case 0x15:
    uStack_a0 = _DAT_018fd220;
    uStack_9c = _UNK_018fd224;
    uStack_98 = _UNK_018fd228;
    uStack_94 = _UNK_018fd22c;
    goto LAB_0078ef47;
  case 7:
    uStack_ac = 5;
    uStack_a0 = _DAT_018f99a0;
    uStack_9c = _UNK_018f99a4;
    uStack_98 = _UNK_018f99a8;
    uStack_94 = _UNK_018f99ac;
    goto LAB_0078ee62;
  case 8:
    uStack_a0 = _DAT_018fd1c0;
    uStack_9c = _UNK_018fd1c4;
    uStack_98 = _UNK_018fd1c8;
    uStack_94 = _UNK_018fd1cc;
    uStack_ac = 6;
    uStack_a8 = 0x3f800000;
    uStack_90 = _DAT_018fd1a0;
    uStack_8c = _UNK_018fd1a4;
    uStack_88 = _UNK_018fd1a8;
    uStack_84 = _UNK_018fd1ac;
    goto LAB_0078ee7a;
  case 9:
    uStack_a0 = _DAT_018fd1d0;
    uStack_9c = _UNK_018fd1d4;
    uStack_98 = _UNK_018fd1d8;
    uStack_94 = _UNK_018fd1dc;
    uStack_ac = 6;
    uStack_68 = 0x100;
    uStack_a8 = 0x3f800000;
    uStack_90 = _DAT_018fd1a0;
    uStack_8c = _UNK_018fd1a4;
    uStack_88 = _UNK_018fd1a8;
    uStack_84 = _UNK_018fd1ac;
    goto LAB_0078ee80;
  case 10:
    uStack_a0 = _DAT_018fd1b0;
    uStack_9c = _UNK_018fd1b4;
    uStack_98 = _UNK_018fd1b8;
    uStack_94 = _UNK_018fd1bc;
    uStack_ac = 6;
    uStack_68 = 0x100;
    uStack_a8 = 0x3f800000;
    uStack_90 = _DAT_018fd190;
    uStack_8c = _UNK_018fd194;
    uStack_88 = _UNK_018fd198;
    uStack_84 = _UNK_018fd19c;
    goto LAB_0078ee80;
  case 0xb:
    uStack_a0 = _DAT_018fd200;
    uStack_9c = _UNK_018fd204;
    uStack_98 = _UNK_018fd208;
    uStack_94 = _UNK_018fd20c;
LAB_0078ef47:
    uStack_ac = 5;
    uStack_90 = _DAT_018fac00;
    uStack_8c = _UNK_018fac04;
    uStack_88 = _UNK_018fac08;
    uStack_84 = _UNK_018fac0c;
    goto LAB_0078ef5f;
  case 0xc:
    uStack_a0 = _DAT_018fd250;
    uStack_9c = _UNK_018fd254;
    uStack_98 = _UNK_018fd258;
    uStack_94 = _UNK_018fd25c;
    break;
  case 0xd:
    uStack_a0 = _DAT_018fd1e0;
    uStack_9c = _UNK_018fd1e4;
    uStack_98 = _UNK_018fd1e8;
    uStack_94 = _UNK_018fd1ec;
    uStack_ac = 6;
    uStack_90 = _DAT_018fd190;
    uStack_8c = _UNK_018fd194;
    uStack_88 = _UNK_018fd198;
    uStack_84 = _UNK_018fd19c;
    goto LAB_0078ef5f;
  case 0xe:
    uStack_a0 = _DAT_018fd230;
    uStack_9c = _UNK_018fd234;
    uStack_98 = _UNK_018fd238;
    uStack_94 = _UNK_018fd23c;
    break;
  case 0xf:
    uStack_a0 = _DAT_018f99a0;
    uStack_9c = _UNK_018f99a4;
    uStack_98 = _UNK_018f99a8;
    uStack_94 = _UNK_018f99ac;
    uStack_ac = 7;
    uStack_68 = 1;
    uStack_a8 = 0x3f800000;
    uStack_90 = _DAT_018fd1f0;
    uStack_8c = _UNK_018fd1f4;
    uStack_88 = _UNK_018fd1f8;
    uStack_84 = _UNK_018fd1fc;
    goto LAB_0078ee80;
  case 0x10:
    uStack_a0 = _DAT_018fd220;
    uStack_9c = _UNK_018fd224;
    uStack_98 = _UNK_018fd228;
    uStack_94 = _UNK_018fd22c;
    break;
  case 0x11:
    uStack_ac = 5;
    uStack_a8 = 0x3f266666;
    uStack_90 = _DAT_018fac00;
    uStack_8c = _UNK_018fac04;
    uStack_88 = _UNK_018fac08;
    uStack_84 = _UNK_018fac0c;
    uStack_a0 = _DAT_018fd230;
    uStack_9c = _UNK_018fd234;
    uStack_98 = _UNK_018fd238;
    uStack_94 = _UNK_018fd23c;
    goto LAB_0078ee7a;
  case 0x12:
    uStack_a0 = _DAT_018f99a0;
    uStack_9c = _UNK_018f99a4;
    uStack_98 = _UNK_018f99a8;
    uStack_94 = _UNK_018f99ac;
    break;
  case 0x13:
    uStack_ac = 4;
    uStack_90 = _DAT_018fac00;
    uStack_8c = _UNK_018fac04;
    uStack_88 = _UNK_018fac08;
    uStack_84 = _UNK_018fac0c;
    uStack_a0 = _DAT_018fd210;
    uStack_9c = _UNK_018fd214;
    uStack_98 = _UNK_018fd218;
    uStack_94 = _UNK_018fd21c;
LAB_0078ef5f:
    uStack_a8 = 0x3f800000;
    uStack_68 = 0;
    uStack_80 = 0;
    uStack_7c = 0;
    goto LAB_0078ed82;
  case 0x14:
    uStack_ac = 7;
    goto LAB_0078f04e;
  case 0x16:
    uStack_ac = 8;
    uStack_68 = 0;
    goto LAB_0078f054;
  case 0x17:
    uStack_ac = 10;
LAB_0078f04e:
    uStack_68 = 1;
LAB_0078f054:
    uStack_a0 = _DAT_018f99a0;
    uStack_9c = _UNK_018f99a4;
    uStack_98 = _UNK_018f99a8;
    uStack_94 = _UNK_018f99ac;
    uStack_a8 = 0x3f800000;
    uStack_90 = _DAT_018fd180;
    uStack_8c = _UNK_018fd184;
    uStack_88 = _UNK_018fd188;
    uStack_84 = _UNK_018fd18c;
    uStack_80 = 0x3f400000;
    uStack_7c = 0x3f800000;
    goto LAB_0078ed82;
  }
  uStack_ac = 4;
LAB_0078ee62:
  uStack_a8 = 0x3f800000;
  uStack_90 = _DAT_018fac00;
  uStack_8c = _UNK_018fac04;
  uStack_88 = _UNK_018fac08;
  uStack_84 = _UNK_018fac0c;
LAB_0078ee7a:
  uStack_68 = 0;
LAB_0078ee80:
  uStack_80 = 0;
  uStack_7c = 0x3f800000;
LAB_0078ed82:
  FUN_0078eaf0(&uStack_ac);
  FUN_00789520();
  return param_1;
}



/* FUNCTION 11314 ; VA 0x0078f120 ; FUN_0078f120 */

int __thiscall FUN_0078f120(int param_1,int param_2)

{
  return param_2 * 0xa8 + param_1;
}



/* FUNCTION 11315 ; VA 0x0078f130 ; FUN_0078f130 */

char FUN_0078f130(int param_1,char param_2)

{
  if (param_1 < 0x371) {
    if (param_1 == 0x370) {
      return 0x15;
    }
    if (param_1 < 0x311) {
      if (param_1 == 0x310) {
        return 7;
      }
      if (param_1 < 0x121) {
        if (param_1 == 0x120) {
          return 4;
        }
        if (param_1 == 0x100) {
          return param_2 != '\0';
        }
        if (param_1 == 0x110) {
          return (param_2 != '\0') + '\x02';
        }
      }
      else {
        if (param_1 == 0x200) {
          return 5;
        }
        if (param_1 == 0x210) {
          return 6;
        }
      }
    }
    else {
      switch(param_1) {
      case 800:
        return 8;
      case 0x330:
        return 9;
      case 0x340:
        return 10;
      case 0x350:
        return 0xb;
      case 0x360:
        return 0xc;
      }
    }
  }
  else if (param_1 < 0x511) {
    if (param_1 == 0x510) {
      return 0x12;
    }
    switch(param_1) {
    case 0x410:
      return 0xd;
    case 0x420:
      return 0xe;
    case 0x430:
      return 0xf;
    case 0x440:
      return 0x10;
    case 0x500:
      return 0x11;
    }
  }
  else if (param_1 < 0x621) {
    if (param_1 == 0x620) {
      return 0x16;
    }
    if (param_1 == 0x520) {
      return 0x13;
    }
    if (param_1 == 0x600) {
      return 0x14;
    }
  }
  else if (param_1 == 0x630) {
    return 0x17;
  }
  return false;
}



/* FUNCTION 11316 ; VA 0x0078f3f0 ; FUN_0078f3f0 */

undefined4 FUN_0078f3f0(undefined4 param_1)

{
  char cVar1;
  
  cVar1 = FUN_00790050(param_1,"plastic");
  if (cVar1 == '\0') {
    cVar1 = FUN_00790050(param_1,"plastic_reflective");
    if (cVar1 != '\0') {
      return 1;
    }
    cVar1 = FUN_00790050(param_1,"smoothplastic");
    if (cVar1 != '\0') {
      return 2;
    }
    cVar1 = FUN_00790050(param_1,"smoothplastic_reflective");
    if (cVar1 != '\0') {
      return 3;
    }
    cVar1 = FUN_00790050(param_1,&DAT_018fce8c);
    if (cVar1 != '\0') {
      return 4;
    }
    cVar1 = FUN_00790050(param_1,&DAT_018fce94);
    if (cVar1 != '\0') {
      return 5;
    }
    cVar1 = FUN_00790050(param_1,"woodplanks");
    if (cVar1 != '\0') {
      return 6;
    }
    cVar1 = FUN_00790050(param_1,"marble");
    if (cVar1 != '\0') {
      return 7;
    }
    cVar1 = FUN_00790050(param_1,"slate");
    if (cVar1 != '\0') {
      return 8;
    }
    cVar1 = FUN_00790050(param_1,"concrete");
    if (cVar1 != '\0') {
      return 9;
    }
    cVar1 = FUN_00790050(param_1,"granite");
    if (cVar1 != '\0') {
      return 10;
    }
    cVar1 = FUN_00790050(param_1,"brick");
    if (cVar1 != '\0') {
      return 0xb;
    }
    cVar1 = FUN_00790050(param_1,"pebble");
    if (cVar1 != '\0') {
      return 0xc;
    }
    cVar1 = FUN_00790050(param_1,&DAT_018fcedc);
    if (cVar1 != '\0') {
      return 0xd;
    }
    cVar1 = FUN_00790050(param_1,"diamondplate");
    if (cVar1 != '\0') {
      return 0xe;
    }
    cVar1 = FUN_00790050(param_1,"aluminum");
    if (cVar1 != '\0') {
      return 0xf;
    }
    cVar1 = FUN_00790050(param_1,"metal");
    if (cVar1 != '\0') {
      return 0x10;
    }
    cVar1 = FUN_00790050(param_1,"grass");
    if (cVar1 != '\0') {
      return 0x11;
    }
    cVar1 = FUN_00790050(param_1,&DAT_018fcf10);
    if (cVar1 != '\0') {
      return 0x12;
    }
    cVar1 = FUN_00790050(param_1,"fabric");
    if (cVar1 != '\0') {
      return 0x13;
    }
    cVar1 = FUN_00790050(param_1,&DAT_018fcf20);
    if (cVar1 != '\0') {
      return 0x14;
    }
    cVar1 = FUN_00790050(param_1,"cobblestone");
    if (cVar1 != '\0') {
      return 0x15;
    }
    cVar1 = FUN_00790050(param_1,"glass");
    if (cVar1 != '\0') {
      return 0x16;
    }
    cVar1 = FUN_00790050(param_1,"forcefield");
    if (cVar1 != '\0') {
      return 0x17;
    }
  }
  return 0;
}



/* FUNCTION 11317 ; VA 0x0078f670 ; FUN_0078f670 */

/* WARNING: Type propagation algorithm not settling */

uint FUN_0078f670(undefined4 *param_1)

{
  bool bVar1;
  int iVar2;
  float fVar3;
  undefined4 *******pppppppuVar4;
  char cVar5;
  undefined uVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 *******pppppppuVar10;
  int *piVar11;
  int iVar12;
  uint uVar13;
  int iVar14;
  uint uVar15;
  undefined4 *puVar16;
  int *piVar17;
  float10 fVar18;
  int aiStack_2ac [3];
  byte abStack_2a0 [4];
  undefined auStack_29c [96];
  undefined **appuStack_23c [18];
  undefined auStack_1f4 [8];
  undefined auStack_1ec [8];
  undefined auStack_1e4 [8];
  undefined auStack_1dc [8];
  undefined auStack_1d4 [8];
  undefined auStack_1cc [8];
  undefined auStack_1c4 [8];
  undefined auStack_1bc [8];
  undefined auStack_1b4 [8];
  undefined auStack_1ac [8];
  undefined auStack_1a4 [8];
  undefined auStack_19c [8];
  undefined auStack_194 [8];
  undefined auStack_18c [8];
  undefined auStack_184 [8];
  undefined auStack_17c [8];
  undefined auStack_174 [8];
  undefined auStack_16c [8];
  undefined auStack_164 [8];
  undefined auStack_15c [8];
  int aiStack_154 [5];
  uint uStack_140;
  undefined **appuStack_13c [4];
  int *piStack_12c;
  int *piStack_128;
  int *piStack_11c;
  uint *puStack_118;
  int *piStack_10c;
  uint uStack_100;
  uint uStack_fc;
  undefined4 uStack_f0;
  undefined **appuStack_ec [18];
  uint auStack_a4 [4];
  undefined4 uStack_94;
  uint uStack_90;
  undefined4 *******apppppppuStack_8c [5];
  uint uStack_78;
  undefined auStack_74 [24];
  undefined auStack_5c [8];
  uint auStack_54 [4];
  undefined4 uStack_44;
  uint uStack_40;
  undefined auStack_3c [12];
  int iStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  undefined auStack_24 [4];
  undefined auStack_20 [4];
  undefined4 uStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar16 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0fd7;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  FUN_008cb670(aiStack_154,param_1);
  uStack_8 = 0;
  puVar7 = (undefined4 *)FUN_0151a8d0(auStack_a4,aiStack_154);
  uStack_8._0_1_ = 1;
  if (7 < (uint)puVar7[5]) {
    puVar7 = (undefined4 *)*puVar7;
  }
  FUN_0054ebd0(puVar7,0x21,0x40,1);
  uStack_8._0_1_ = 3;
  if (7 < uStack_90) {
    uVar13 = uStack_90 * 2 + 2;
    uVar15 = auStack_a4[0];
    if (0xfff < uVar13) {
      uVar15 = *(uint *)(auStack_a4[0] - 4);
      uVar13 = uStack_90 * 2 + 0x25;
      if (0x1f < (auStack_a4[0] - uVar15) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar15,uVar13);
  }
  auStack_a4[0] = auStack_a4[0] & 0xffff0000;
  uStack_94 = 0;
  uStack_90 = 7;
  if ((abStack_2a0[*(int *)(aiStack_2ac[0] + 4)] & 6) != 0) {
    param_1 = (undefined4 *)((uint)param_1 & 0xffffff);
    goto LAB_0078ff77;
  }
  appuStack_13c[0] = &PTR_018be314;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  uStack_1c = 1;
  appuStack_ec[0] = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  uStack_f0 = 0x48;
  FUN_00554f20(appuStack_13c + 1,0);
  uStack_8 = 6;
  *(undefined ***)(appuStack_13c[0][1] + (int)appuStack_13c) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)((int)&uStack_140 + (int)appuStack_13c[0][1]) = appuStack_13c[0][1] + -0x50;
  FUN_0054ee60();
  appuStack_13c[1] =
       std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::vftable
  ;
  uStack_100 = 0;
  uStack_fc = 4;
  uStack_8._0_1_ = 7;
  FUN_0056f130(auStack_29c);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  uStack_44 = 0;
  uStack_40 = 0xf;
  auStack_54[0] = auStack_54[0] & 0xffffff00;
  uStack_1c = 9;
  if (((uStack_fc & 2) == 0) && (uVar13 = *puStack_118, uVar13 != 0)) {
    if (uVar13 < uStack_100) {
      uVar13 = uStack_100;
    }
    iVar12 = *piStack_128;
    iVar14 = uVar13 - iVar12;
LAB_0078f87b:
    FUN_005542c0(iVar12,iVar14);
  }
  else if (((uStack_fc & 4) == 0) && (*piStack_11c != 0)) {
    iVar12 = *piStack_12c;
    iVar14 = (*piStack_11c - iVar12) + *piStack_10c;
    goto LAB_0078f87b;
  }
  uStack_8 = 9;
  FUN_016819e0(auStack_3c,auStack_54);
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  cVar5 = FUN_016816d0();
  if (cVar5 == '\0') {
    FUN_0167eea0(auStack_5c,"materials");
    cVar5 = FUN_01681830();
    if (cVar5 == '\0') {
      if (0xf < (uint)puVar16[5]) {
        puVar16 = (undefined4 *)*puVar16;
      }
      FUN_0086f2f0(3,"File: \'%s\', PartMaterialTable: materials was not an array.",puVar16);
      param_1 = (undefined4 *)((uint)param_1 & 0xffffff);
    }
    else {
      FUN_016810c0(auStack_20);
      FUN_01680ea0(&param_1);
      FUN_01681140(auStack_24);
      cVar5 = FUN_005e0cd0(auStack_24);
      while (cVar5 != '\0') {
        FUN_0167efb0(auStack_18);
        FUN_0167eea0(auStack_1c4,&DAT_018c387c);
        FUN_016813d0(apppppppuStack_8c,"plastic");
        uVar13 = uStack_78;
        pppppppuVar4 = apppppppuStack_8c[0];
        uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
        pppppppuVar10 = apppppppuStack_8c;
        if (0xf < uStack_78) {
          pppppppuVar10 = apppppppuStack_8c[0];
        }
        iStack_30 = FUN_0078f3f0(pppppppuVar10);
        if (iStack_30 < 5) {
          pppppppuVar10 = apppppppuStack_8c;
          if (0xf < uVar13) {
            pppppppuVar10 = pppppppuVar4;
          }
          FUN_0086f2f0(2,"Material override has ignored. Material \'%s\'",pppppppuVar10);
        }
        else {
          piVar17 = (int *)(iStack_30 * 0xa8 + iStack_28);
          FUN_0167eea0(auStack_1cc,"disable_diffuse_texture");
          uVar6 = FUN_0167e3d0(*(undefined *)(piVar17 + 0x11));
          *(undefined *)(piVar17 + 0x11) = uVar6;
          FUN_0167eea0(auStack_1d4,"disable_normal_texture");
          uVar6 = FUN_0167e3d0(*(undefined *)((int)piVar17 + 0x45));
          *(undefined *)((int)piVar17 + 0x45) = uVar6;
          FUN_0167eea0(auStack_1dc,"texture_tiling");
          fVar18 = (float10)FUN_0167e320(piVar17[1]);
          piVar17[1] = (int)(float)fVar18;
          FUN_0167eea0(auStack_1e4,"plastic_roughness");
          fVar18 = (float10)FUN_0167e320(piVar17[2]);
          piVar17[2] = (int)(float)fVar18;
          FUN_0167eea0(auStack_1ec,"normal_shadow_scale");
          fVar18 = (float10)FUN_0167e320(piVar17[3]);
          piVar17[3] = (int)(float)fVar18;
          FUN_0167eea0(auStack_1f4,"normal_detail_tiling");
          fVar18 = (float10)FUN_0167e320(piVar17[4]);
          piVar17[4] = (int)(float)fVar18;
          FUN_0167eea0(auStack_15c,"normal_detail_scale");
          fVar18 = (float10)FUN_0167e320(piVar17[4]);
          bVar1 = (float)piVar17[0xc] <= DAT_018fd178;
          piVar17[5] = (int)(float)fVar18;
          uStack_1c = CONCAT31(uStack_1c._1_3_,bVar1);
          FUN_0167eea0(auStack_164,"opt_blend_color");
          cVar5 = FUN_0167e3d0(uStack_1c);
          iVar12 = DAT_018ce2f8;
          if (cVar5 != '\0') {
            iVar12 = 0;
          }
          piVar17[0xc] = iVar12;
          uStack_2c = CONCAT31(uStack_2c._1_3_,*piVar17 == 5);
          FUN_0167eea0(auStack_16c,"wang_tiles");
          cVar5 = FUN_0167e3d0(uStack_2c);
          if (cVar5 == '\0') {
            FUN_0167eea0(auStack_174,"far_diffuse_cutoff");
            fVar18 = (float10)FUN_0167e320(piVar17[9]);
            piVar17[9] = (int)(float)fVar18;
            FUN_0167eea0(auStack_17c,"far_normal_cutoff");
            fVar18 = (float10)FUN_0167e320(piVar17[10]);
            piVar17[10] = (int)(float)fVar18;
            FUN_0167eea0(auStack_184,"far_specular_cutoff");
            fVar18 = (float10)FUN_0167e320(piVar17[10]);
            piVar17[0xb] = (int)(float)fVar18;
            FUN_0167eea0(auStack_18c,"far_diffuse_tiling");
            fVar18 = (float10)FUN_0167e320(piVar17[6]);
            piVar17[6] = (int)(float)fVar18;
            FUN_0167eea0(auStack_194,"far_normal_tiling");
            fVar18 = (float10)FUN_0167e320(piVar17[7]);
            piVar17[7] = (int)(float)fVar18;
            FUN_0167eea0(auStack_19c,"far_specular_tiling");
            fVar18 = (float10)FUN_0167e320(piVar17[8]);
            fVar3 = DAT_018fd178;
            bVar1 = (float)piVar17[9] <= DAT_018fd178;
            piVar17[8] = (int)(float)fVar18;
            if (bVar1) {
              piVar17[6] = 0x3f800000;
            }
            if ((float)piVar17[10] <= fVar3) {
              piVar17[7] = 0x3f800000;
            }
            if ((float)piVar17[0xb] <= fVar3) {
              piVar17[8] = 0x3f800000;
            }
            if ((fVar3 < (float)piVar17[10]) || (fVar3 < (float)piVar17[0xb])) {
              *piVar17 = 7;
            }
            else {
              *piVar17 = (uint)(fVar3 < (float)piVar17[9]) * 2 + 4;
            }
          }
          else {
            *piVar17 = 5;
            piVar17[6] = 0x3f800000;
            piVar17[7] = 0x3f800000;
            piVar17[8] = 0x3f800000;
            piVar17[9] = 0;
            piVar17[10] = 0;
            piVar17[0xb] = 0;
          }
          FUN_0167eea0(auStack_1a4,"custom_diffuse_texture");
          piVar11 = (int *)FUN_01681330(auStack_74,piVar17 + 0x12);
          if (piVar17 + 0x12 != piVar11) {
            FUN_005507b0();
            iVar12 = piVar11[1];
            iVar14 = piVar11[2];
            iVar2 = piVar11[3];
            piVar17[0x12] = *piVar11;
            piVar17[0x13] = iVar12;
            piVar17[0x14] = iVar14;
            piVar17[0x15] = iVar2;
            iVar12 = piVar11[5];
            piVar17[0x16] = piVar11[4];
            piVar17[0x17] = iVar12;
            piVar11[4] = 0;
            piVar11[5] = 0xf;
            *(undefined *)piVar11 = 0;
          }
          FUN_005507b0();
          FUN_0167eea0(auStack_1ac,"custom_normal_texture");
          piVar11 = (int *)FUN_01681330(auStack_74,piVar17 + 0x18);
          if (piVar17 + 0x18 != piVar11) {
            FUN_005507b0();
            iVar12 = piVar11[1];
            iVar14 = piVar11[2];
            iVar2 = piVar11[3];
            piVar17[0x18] = *piVar11;
            piVar17[0x19] = iVar12;
            piVar17[0x1a] = iVar14;
            piVar17[0x1b] = iVar2;
            iVar12 = piVar11[5];
            piVar17[0x1c] = piVar11[4];
            piVar17[0x1d] = iVar12;
            piVar11[4] = 0;
            piVar11[5] = 0xf;
            *(undefined *)piVar11 = 0;
          }
          FUN_005507b0();
          FUN_0167eea0(auStack_1b4,"custom_specular_texture");
          piVar11 = (int *)FUN_01681330(auStack_74,piVar17 + 0x1e);
          if (piVar17 + 0x1e != piVar11) {
            FUN_005507b0();
            iVar12 = piVar11[1];
            iVar14 = piVar11[2];
            iVar2 = piVar11[3];
            piVar17[0x1e] = *piVar11;
            piVar17[0x1f] = iVar12;
            piVar17[0x20] = iVar14;
            piVar17[0x21] = iVar2;
            iVar12 = piVar11[5];
            piVar17[0x22] = piVar11[4];
            piVar17[0x23] = iVar12;
            piVar11[4] = 0;
            piVar11[5] = 0xf;
            *(undefined *)piVar11 = 0;
          }
          FUN_005507b0();
          FUN_0167eea0(auStack_1bc,"custom_normal_detail_texture");
          piVar11 = (int *)FUN_01681330(auStack_74,piVar17 + 0x24);
          if (piVar17 + 0x24 != piVar11) {
            FUN_005507b0();
            iVar12 = piVar11[1];
            iVar14 = piVar11[2];
            iVar2 = piVar11[3];
            piVar17[0x24] = *piVar11;
            piVar17[0x25] = iVar12;
            piVar17[0x26] = iVar14;
            piVar17[0x27] = iVar2;
            iVar12 = piVar11[5];
            piVar17[0x28] = piVar11[4];
            piVar17[0x29] = iVar12;
            piVar11[4] = 0;
            piVar11[5] = 0xf;
            *(undefined *)piVar11 = 0;
          }
          FUN_005507b0();
          if (iStack_30 == 0x16) {
            *piVar17 = 8;
          }
          else if (iStack_30 == 0x17) {
            *piVar17 = 10;
          }
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,10);
        FUN_005507b0();
        FUN_0167f070();
        cVar5 = FUN_005e0cd0(auStack_24);
      }
      param_1 = (undefined4 *)CONCAT13(1,SUB43(param_1,0));
    }
  }
  else {
    uVar8 = FUN_01681490();
    uVar9 = FUN_016814a0();
    if (0xf < (uint)puVar16[5]) {
      puVar16 = (undefined4 *)*puVar16;
    }
    FUN_0086f2f0(3,"File: \'%s\', Failed to parse JSON: %s at %d",puVar16,uVar9,uVar8);
    param_1 = (undefined4 *)((uint)param_1 & 0xffffff);
  }
  FUN_0167ec40();
  uStack_8._0_1_ = 7;
  if (0xf < uStack_40) {
    uVar15 = uStack_40 + 1;
    uVar13 = auStack_54[0];
    if (0xfff < uVar15) {
      uVar13 = *(uint *)(auStack_54[0] - 4);
      uVar15 = uStack_40 + 0x24;
      if (0x1f < (auStack_54[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar13,uVar15);
  }
  uStack_44 = 0;
  uStack_40 = 0xf;
  auStack_54[0] = auStack_54[0] & 0xffffff00;
  *(undefined ***)(appuStack_13c[0][1] + (int)appuStack_13c) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)((int)&uStack_140 + (int)appuStack_13c[0][1]) = appuStack_13c[0][1] + -0x50;
  FUN_0056b950();
  *(undefined ***)(appuStack_13c[0][1] + (int)appuStack_13c) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)((int)&uStack_140 + (int)appuStack_13c[0][1]) = appuStack_13c[0][1] + -8;
  uStack_8._0_1_ = 0xc;
  appuStack_ec[0] = std::ios_base::vftable;
  FUN_016de551(appuStack_ec);
LAB_0078ff77:
  *(undefined ***)((int)aiStack_2ac + *(int *)(aiStack_2ac[0] + 4)) =
       std::basic_ifstream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(auStack_29c + *(int *)(aiStack_2ac[0] + 4) + -0x14) =
       *(int *)(aiStack_2ac[0] + 4) + -0x70;
  FUN_00550570();
  *(undefined ***)((int)aiStack_2ac + *(int *)(aiStack_2ac[0] + 4)) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(auStack_29c + *(int *)(aiStack_2ac[0] + 4) + -0x14) =
       *(int *)(aiStack_2ac[0] + 4) + -0x18;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  appuStack_23c[0] = std::ios_base::vftable;
  FUN_016de551(appuStack_23c);
  if (0xf < uStack_140) {
    iVar12 = aiStack_154[0];
    if ((0xfff < uStack_140 + 1) &&
       (iVar12 = *(int *)(aiStack_154[0] + -4), 0x1f < (aiStack_154[0] - iVar12) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0(iVar12);
  }
  ExceptionList = pvStack_10;
  return (uint)param_1 >> 0x18;
}



/* FUNCTION 11318 ; VA 0x00790050 ; FUN_00790050 */

undefined4 FUN_00790050(char *param_1,char *param_2)

{
  char cVar1;
  char cVar2;
  char *pcVar3;
  char cVar4;
  
  cVar4 = *param_1;
  if (cVar4 != '\0') {
    pcVar3 = param_2;
    do {
      cVar1 = *pcVar3;
      cVar2 = cVar4 + ' ';
      if (0x19 < (byte)(cVar4 + 0xbfU)) {
        cVar2 = cVar4;
      }
      cVar4 = cVar1 + ' ';
      if (0x19 < (byte)(cVar1 + 0xbfU)) {
        cVar4 = cVar1;
      }
      if (((cVar2 != cVar4) || (cVar2 < ' ')) || (cVar4 < ' ')) {
        return 0;
      }
      cVar4 = pcVar3[(int)(param_1 + (1 - (int)param_2))];
      pcVar3 = pcVar3 + 1;
    } while (cVar4 != '\0');
  }
  return 1;
}



/* FUNCTION 11319 ; VA 0x007900c0 ; FUN_007900c0 */

uint * __thiscall FUN_007900c0(uint *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x2aaaaaa < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar3 = param_2 * 0x60;
    if (uVar3 < 0x1000) {
      if (uVar3 == 0) {
        uVar1 = 0;
      }
      else {
        uVar1 = FUN_01674e20(uVar3);
      }
    }
    else {
      uVar1 = uVar3 + 0x23;
      if (uVar1 <= uVar3) {
        uVar1 = 0xffffffff;
      }
      iVar2 = FUN_01674e20(uVar1);
      if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar1 = iVar2 + 0x23U & 0xffffffe0;
      *(int *)(uVar1 - 4) = iVar2;
    }
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + uVar3;
    uVar1 = *param_1;
    if (param_2 != 0) {
      FUN_0170d1f0(uVar1,0,uVar3);
      uVar1 = uVar1 + uVar3;
    }
    param_1[1] = uVar1;
  }
  return param_1;
}



/* FUNCTION 11320 ; VA 0x00790170 ; FUN_00790170 */

uint * __thiscall FUN_00790170(uint *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x3ffffff < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar3 = param_2 * 0x40;
    if (uVar3 < 0x1000) {
      if (uVar3 == 0) {
        uVar1 = 0;
      }
      else {
        uVar1 = FUN_01674e20(uVar3);
      }
    }
    else {
      uVar1 = uVar3 + 0x23;
      if (uVar1 <= uVar3) {
        uVar1 = 0xffffffff;
      }
      iVar2 = FUN_01674e20(uVar1);
      if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar1 = iVar2 + 0x23U & 0xffffffe0;
      *(int *)(uVar1 - 4) = iVar2;
    }
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + uVar3;
    uVar1 = *param_1;
    if (param_2 != 0) {
      FUN_0170d1f0(uVar1,0,param_2 << 6);
      uVar1 = uVar1 + uVar3;
    }
    param_1[1] = uVar1;
  }
  return param_1;
}



/* FUNCTION 11321 ; VA 0x00790220 ; FUN_00790220 */

undefined4 * __thiscall FUN_00790220(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b1027;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  *(undefined *)(param_1 + 1) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[2] = uVar1;
  param_1[3] = 0;
  param_1[4] = 0x3f800000;
  param_1[5] = 0;
  param_1[6] = 0;
  uStack_8 = 0;
  *(undefined *)(param_1 + 7) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[8] = uVar1;
  param_1[9] = 0;
  param_1[10] = 0x3f800000;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  *(undefined *)(param_1 + 0xd) = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0xf;
  *(undefined *)(param_1 + 0x12) = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_0058a190(0x100);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11322 ; VA 0x00790300 ; FUN_00790300 */

void __fastcall FUN_00790300(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if (param_1[1] != 0) {
    ExceptionList = &pvStack_10;
    (*(code *)*param_1)(param_1[1]);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11323 ; VA 0x00790340 ; FUN_00790340 */

void __fastcall FUN_00790340(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_0153ccd0();
    FUN_01674ea0(iVar1,4);
  }
  return;
}



/* FUNCTION 11324 ; VA 0x00790360 ; thunk_FUN_007908d0 */

void __fastcall thunk_FUN_007908d0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x60) * 0x60;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 11325 ; VA 0x00790370 ; FUN_00790370 */

void __fastcall FUN_00790370(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[2] - iVar1 & 0xffffffc0;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 11326 ; VA 0x007903d0 ; FUN_007903d0 */

void __fastcall FUN_007903d0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x5c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x48);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x58) = 0;
  *(undefined4 *)(param_1 + 0x5c) = 0xf;
  *(undefined *)(param_1 + 0x48) = 0;
  thunk_FUN_00577a40();
  iVar2 = *(int *)(param_1 + 0x38);
  if (iVar2 != 0) {
    FUN_0153ccd0();
    FUN_01674ea0(iVar2,4);
  }
  FUN_0075ddb0();
  FUN_0075ddb0();
  return;
}



/* FUNCTION 11327 ; VA 0x00790450 ; FUN_00790450 */

int * __thiscall FUN_00790450(byte *param_1,uint *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  byte *pbVar8;
  undefined4 *puVar9;
  int aiStack_40 [5];
  uint uStack_2c;
  uint uStack_28;
  int *piStack_24;
  undefined2 uStack_20;
  int *piStack_1c;
  uint uStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b1050;
  pvStack_10 = ExceptionList;
  pbVar8 = param_1 + *param_1 + 1;
  ExceptionList = &pvStack_10;
  pbStack_14 = param_1;
  uStack_18 = FUN_0055c740(pbVar8,param_2);
  iVar4 = (int)param_2;
  FUN_00562fc0(&param_2,uStack_18,param_2,-(uint)(pbVar8 != (byte *)0x0) & (uint)(pbVar8 + 1));
  if (param_2 != (uint *)0x0) {
    ExceptionList = pvStack_10;
    return (int *)((int)param_2 + 8);
  }
  piStack_24 = (int *)0x0;
  uStack_20 = 0;
  uStack_28 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(iVar4);
  iStack_8._0_1_ = 1;
  uStack_20 = 0;
  piVar3 = (int *)FUN_01674e20(0x28);
  uStack_20 = CONCAT11(uStack_20._1_1_,1);
  piStack_1c = piVar3 + 2;
  *piVar3 = 0;
  piVar3[1] = 0;
  *piStack_1c = 0;
  piVar3[3] = 0;
  piVar3[4] = 0;
  piVar3[5] = 0;
  piVar3[6] = 0;
  piVar3[7] = 0;
  piVar3[8] = 0;
  piVar3[9] = 0;
  piStack_24 = piVar3;
  FUN_0054ef60(aiStack_40);
  piVar3[8] = 0;
  piVar3[9] = 0;
  uStack_20 = CONCAT11(1,(undefined)uStack_20);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_2c) {
    uVar7 = uStack_2c + 1;
    iVar4 = aiStack_40[0];
    if (0xfff < uVar7) {
      iVar4 = *(int *)(aiStack_40[0] + -4);
      uVar7 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar7);
  }
  uVar1 = *(uint *)(param_1 + 8);
  uVar7 = uVar1 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar7 = FUN_005d6bb0(uVar7);
    if (uVar7 <= *(uint *)(param_1 + 4)) {
      uVar7 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar7);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    param_2 = (uint *)0x1;
    uVar5 = uVar1 >> 1;
    if (uVar1 + (uVar1 >> 1) <= uVar7) {
      uVar5 = 1;
    }
    uVar7 = FUN_005d6bb0(uVar5 + *(int *)(param_1 + 8));
    param_2 = (uint *)(param_1 + 4);
    if (uVar7 != *param_2) {
      FUN_005d2b00(uVar7);
      puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *param_2 * 4);
      puVar2 = (undefined4 *)*puVar9;
      while (piVar3 = piStack_24, puVar2 != (undefined4 *)0x0) {
        piVar3 = (int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar2[1] % *param_2) * 4);
        if (*(int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar2[1] % *param_2) * 4) == 0) {
          *piVar3 = (int)puVar9;
          puVar9 = puVar2;
        }
        else {
          *puVar9 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar3;
          *(undefined4 **)*piVar3 = puVar2;
        }
        param_1 = pbStack_14;
        puVar2 = (undefined4 *)*puVar9;
      }
    }
  }
  piVar3[1] = uStack_18;
  uVar7 = *(uint *)(param_1 + 4);
  piVar3 = (int *)(*(int *)(param_1 + 0x14) + (uStack_18 % uVar7) * 4);
  if ((int *)*piVar3 == (int *)0x0) {
    piVar6 = (int *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (*piVar6 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar6 + 4) % uVar7) * 4) = piStack_24;
    }
    *piVar3 = (int)piVar6;
    *piStack_24 = *piVar6;
  }
  else {
    *piStack_24 = *(int *)*piVar3;
    piVar6 = (int *)*piVar3;
  }
  *piVar6 = (int)piStack_24;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_1c;
}



/* FUNCTION 11328 ; VA 0x00790690 ; FUN_00790690 */

int * __thiscall FUN_00790690(byte *param_1,uint *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  byte *pbVar8;
  undefined4 *puVar9;
  int aiStack_40 [5];
  uint uStack_2c;
  uint uStack_28;
  int *piStack_24;
  undefined2 uStack_20;
  int *piStack_1c;
  uint uStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b1070;
  pvStack_10 = ExceptionList;
  pbVar8 = param_1 + *param_1 + 1;
  ExceptionList = &pvStack_10;
  pbStack_14 = param_1;
  uStack_18 = FUN_0055c740(pbVar8,param_2);
  iVar4 = (int)param_2;
  FUN_00562fc0(&param_2,uStack_18,param_2,-(uint)(pbVar8 != (byte *)0x0) & (uint)(pbVar8 + 1));
  if (param_2 != (uint *)0x0) {
    ExceptionList = pvStack_10;
    return (int *)((int)param_2 + 8);
  }
  piStack_24 = (int *)0x0;
  uStack_20 = 0;
  uStack_28 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(iVar4);
  iStack_8._0_1_ = 1;
  uStack_20 = 0;
  piVar3 = (int *)FUN_01674e20(0x28);
  uStack_20 = CONCAT11(uStack_20._1_1_,1);
  piStack_1c = piVar3 + 2;
  *piVar3 = 0;
  piVar3[1] = 0;
  *piStack_1c = 0;
  piVar3[3] = 0;
  piVar3[4] = 0;
  piVar3[5] = 0;
  piVar3[6] = 0;
  piVar3[7] = 0;
  piVar3[8] = 0;
  piVar3[9] = 0;
  piStack_24 = piVar3;
  FUN_0054ef60(aiStack_40);
  piVar3[8] = 0;
  piVar3[9] = 0;
  uStack_20 = CONCAT11(1,(undefined)uStack_20);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_2c) {
    uVar7 = uStack_2c + 1;
    iVar4 = aiStack_40[0];
    if (0xfff < uVar7) {
      iVar4 = *(int *)(aiStack_40[0] + -4);
      uVar7 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar7);
  }
  uVar1 = *(uint *)(param_1 + 8);
  uVar7 = uVar1 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar7 = FUN_005d6bb0(uVar7);
    if (uVar7 <= *(uint *)(param_1 + 4)) {
      uVar7 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar7);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    param_2 = (uint *)0x1;
    uVar5 = uVar1 >> 1;
    if (uVar1 + (uVar1 >> 1) <= uVar7) {
      uVar5 = 1;
    }
    uVar7 = FUN_005d6bb0(uVar5 + *(int *)(param_1 + 8));
    param_2 = (uint *)(param_1 + 4);
    if (uVar7 != *param_2) {
      FUN_005d2b00(uVar7);
      puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *param_2 * 4);
      puVar2 = (undefined4 *)*puVar9;
      while (piVar3 = piStack_24, puVar2 != (undefined4 *)0x0) {
        piVar3 = (int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar2[1] % *param_2) * 4);
        if (*(int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar2[1] % *param_2) * 4) == 0) {
          *piVar3 = (int)puVar9;
          puVar9 = puVar2;
        }
        else {
          *puVar9 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar3;
          *(undefined4 **)*piVar3 = puVar2;
        }
        param_1 = pbStack_14;
        puVar2 = (undefined4 *)*puVar9;
      }
    }
  }
  piVar3[1] = uStack_18;
  uVar7 = *(uint *)(param_1 + 4);
  piVar3 = (int *)(*(int *)(param_1 + 0x14) + (uStack_18 % uVar7) * 4);
  if ((int *)*piVar3 == (int *)0x0) {
    piVar6 = (int *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (*piVar6 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar6 + 4) % uVar7) * 4) = piStack_24;
    }
    *piVar3 = (int)piVar6;
    *piStack_24 = *piVar6;
  }
  else {
    *piStack_24 = *(int *)*piVar3;
    piVar6 = (int *)*piVar3;
  }
  *piVar6 = (int)piStack_24;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_1c;
}



/* FUNCTION 11329 ; VA 0x007908d0 ; FUN_007908d0 */

void __fastcall FUN_007908d0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x60) * 0x60;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 11330 ; VA 0x00790940 ; FUN_00790940 */

void FUN_00790940(undefined4 *param_1,uint param_2)

{
  uint uVar1;
  undefined *puVar2;
  uint uVar3;
  undefined4 *puVar4;
  
  if (param_2 != 0) {
    uVar3 = param_1[4];
    uVar1 = uVar3 + 8;
    if (uVar3 < uVar1) {
      FUN_00578160(8,0);
    }
    else {
      puVar4 = param_1;
      if (0xf < (uint)param_1[5]) {
        puVar4 = (undefined4 *)*param_1;
      }
      param_1[4] = uVar1;
      *(undefined *)((int)puVar4 + uVar1) = 0;
    }
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    puVar2 = (undefined *)((int)param_1 + uVar3);
    *puVar2 = (&DAT_018fd2a4)[param_2 >> 0x1c];
    puVar2[1] = (&DAT_018fd2a4)[param_2 >> 0x18 & 0xf];
    puVar2[2] = (&DAT_018fd2a4)[param_2 >> 0x14 & 0xf];
    puVar2[3] = (&DAT_018fd2a4)[param_2 >> 0x10 & 0xf];
    puVar2[4] = (&DAT_018fd2a4)[param_2 >> 0xc & 0xf];
    puVar2[5] = (&DAT_018fd2a4)[param_2 >> 8 & 0xf];
    puVar2[6] = (&DAT_018fd2a4)[param_2 >> 4 & 0xf];
    puVar2[7] = (&DAT_018fd2a4)[param_2 & 0xf];
  }
  return;
}



/* FUNCTION 11331 ; VA 0x00790a20 ; FUN_00790a20 */

undefined4 * __thiscall
FUN_00790a20(int *param_1,undefined4 *param_2,char *param_3,int *param_4,uint param_5)

{
  char cVar1;
  int *piVar2;
  code *pcVar3;
  undefined4 uVar4;
  undefined4 ****ppppuVar5;
  int iVar6;
  char *pcVar7;
  uint uVar8;
  int *piVar9;
  byte *pbVar10;
  uint uVar11;
  undefined auStack_68 [4];
  undefined auStack_64 [20];
  undefined4 ***apppuStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  int *piStack_34;
  int *piStack_30;
  undefined *puStack_2c;
  undefined *puStack_28;
  int iStack_24;
  byte *pbStack_20;
  uint uStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b10cc;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff8c;
  uVar11 = 0;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  piStack_30 = param_1;
  FUN_016f4053(auStack_68,8,3,FUN_005502b0,FUN_00550b30);
  uStack_8 = 1;
  uStack_1c = 0;
  if (param_5 != 0) {
    puStack_2c = auStack_64 + -(int)param_4;
    pbStack_20 = (byte *)(param_1 + 1);
    puStack_28 = auStack_68 + -(int)param_4;
    piVar9 = param_4;
    do {
      pbVar10 = pbStack_20;
      uStack_40 = 0;
      uStack_3c = 0xf;
      apppuStack_50[0] = (undefined4 ***)((uint)apppuStack_50[0] & 0xffffff00);
      if (*piVar9 != 0) {
        FUN_005542c0(*piVar9,piVar9[1]);
      }
      uVar11 = 2;
      pbVar10 = pbVar10 + *pbVar10 + 1;
      uVar4 = FUN_0055c740(pbVar10,apppuStack_50);
      FUN_00562fc0(&iStack_24,uVar4,apppuStack_50,
                   -(uint)(pbVar10 != (byte *)0x0) & (uint)(pbVar10 + 1));
      if (0xf < uStack_3c) {
        uVar8 = uStack_3c + 1;
        ppppuVar5 = (undefined4 ****)apppuStack_50[0];
        if (0xfff < uVar8) {
          ppppuVar5 = (undefined4 ****)apppuStack_50[0][-1];
          uVar8 = uStack_3c + 0x24;
          if (0x1f < (uint)((int)apppuStack_50[0] + (-4 - (int)ppppuVar5))) goto LAB_00790dee;
        }
        FUN_01674ea0(ppppuVar5,uVar8);
      }
      if (iStack_24 == 0) {
        uStack_18 = 2;
        if (DAT_01f6dcc0 != '\0') {
          uStack_40 = 0;
          apppuStack_50[0] = (undefined4 ***)((uint)apppuStack_50[0] & 0xffffff00);
          if (param_4[uStack_1c * 2] == 0) {
            uStack_3c = 0xf;
          }
          else {
            uStack_3c = 0xf;
            FUN_005542c0(param_4[uStack_1c * 2],param_4[uStack_1c * 2 + 1]);
          }
          uVar11 = 6;
          uStack_18 = 6;
          uStack_8._0_1_ = 2;
          ppppuVar5 = apppuStack_50;
          if (0xf < uStack_3c) {
            ppppuVar5 = (undefined4 ****)apppuStack_50[0];
          }
          FUN_01677650(DAT_01f6dcc0,"Error: shader %s is not available",ppppuVar5);
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          if (0xf < uStack_3c) {
            uVar8 = uStack_3c + 1;
            ppppuVar5 = (undefined4 ****)apppuStack_50[0];
            if (0xfff < uVar8) {
              ppppuVar5 = (undefined4 ****)apppuStack_50[0][-1];
              uVar8 = uStack_3c + 0x24;
              if (0x1f < (uint)((int)apppuStack_50[0] + (-4 - (int)ppppuVar5))) {
LAB_00790dee:
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(ppppuVar5,uVar8);
          }
        }
        *param_2 = 0;
        param_2[1] = 0;
        goto LAB_00790cf9;
      }
      iVar6 = *(int *)(iStack_24 + 0x24);
      if (iVar6 != 0) {
        LOCK();
        *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
        UNLOCK();
        iVar6 = *(int *)(iStack_24 + 0x24);
      }
      *(undefined4 *)(puStack_28 + (int)piVar9) = *(undefined4 *)(iStack_24 + 0x20);
      piVar2 = *(int **)(puStack_2c + (int)piVar9);
      *(int *)(puStack_2c + (int)piVar9) = iVar6;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar6 = piVar2[1] + -1;
        piVar2[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar6 = piVar2[2] + -1;
          piVar2[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      piVar9 = piVar9 + 2;
      uStack_1c = uStack_1c + 1;
      uStack_18 = uVar11;
    } while (uStack_1c < param_5);
    uStack_18 = 2;
    param_1 = piStack_30;
  }
  uStack_8._0_1_ = 3;
  (**(code **)(**(int **)(*param_1 + 0x3c) + 0x38))(&piStack_34,auStack_68,param_5);
  uStack_8._0_1_ = 4;
  uStack_40 = 0;
  uStack_3c = 0xf;
  apppuStack_50[0] = (undefined4 ***)((uint)apppuStack_50[0] & 0xffffff00);
  pcVar3 = *(code **)(*piStack_34 + 0xc);
  pcVar7 = param_3;
  do {
    cVar1 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_3,(int)pcVar7 - (int)(param_3 + 1));
  uStack_8._0_1_ = 5;
  (*pcVar3)(apppuStack_50);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (0xf < uStack_3c) {
    uVar8 = uStack_3c + 1;
    ppppuVar5 = (undefined4 ****)apppuStack_50[0];
    if (0xfff < uVar8) {
      ppppuVar5 = (undefined4 ****)apppuStack_50[0][-1];
      uVar8 = uStack_3c + 0x24;
      if (0x1f < (uint)((int)apppuStack_50[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar5,uVar8);
  }
  piVar9 = piStack_34;
  piStack_34 = (int *)0x0;
  *param_2 = piVar9;
  param_2[1] = piStack_30;
  piStack_30 = (int *)0x0;
LAB_00790cf9:
  uStack_8 = uStack_8 & 0xffffff00;
  uStack_18 = uVar11 | 1;
  FUN_016f32d1(auStack_68,8,3,FUN_00550b30);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 11332 ; VA 0x00790d52 ; Catch@00790d52 */

undefined * Catch_00790d52(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  int unaff_EBP;
  
  if (DAT_01f6dcc0 != '\0') {
    FUN_01677650(DAT_01f6dcc0,"Error: failed to link shader program %s",
                 *(undefined4 *)(unaff_EBP + 0xc));
  }
  cVar2 = DAT_01f6dcc0;
  uVar3 = (**(code **)(**(int **)(unaff_EBP + -0x34) + 4))();
  FUN_0054eff0(uVar3);
  *(undefined *)(unaff_EBP + -4) = 7;
  FUN_0147da10(unaff_EBP + -0x4c,cVar2);
  FUN_005507b0();
  puVar1 = *(undefined4 **)(unaff_EBP + 8);
  *(uint *)(unaff_EBP + -0x14) = *(uint *)(unaff_EBP + -0x14) | 1;
  *puVar1 = 0;
  puVar1[1] = 0;
  return &LAB_00790dba;
}



/* FUNCTION 11333 ; VA 0x00790e00 ; FUN_00790e00 */

int * __thiscall FUN_00790e00(int param_1,int *param_2,int param_3,uint param_4)

{
  char cVar1;
  int iVar2;
  void **ppvVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  char *pcVar7;
  uint uVar8;
  int iVar9;
  byte *pbVar10;
  uint uVar11;
  char acStack_14c [256];
  uint auStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b10f0;
  pvStack_10 = ExceptionList;
  iVar9 = 0;
  uVar11 = 0;
  iStack_14 = param_1;
  ExceptionList = &pvStack_10;
  ppvVar3 = &pvStack_10;
  if (param_4 != 0) {
    do {
      iVar2 = *(int *)(param_3 + 4 + uVar11 * 8);
      FUN_0170c6f0(acStack_14c + iVar9,*(undefined4 *)(param_3 + uVar11 * 8),iVar2);
      iVar2 = iVar2 + iVar9;
      uVar11 = uVar11 + 1;
      acStack_14c[iVar2] = ',';
      iVar9 = iVar2 + 1;
      ppvVar3 = (void **)ExceptionList;
    } while (uVar11 < param_4);
  }
  ExceptionList = ppvVar3;
  iVar2 = iStack_14;
  pcVar7 = acStack_14c;
  acStack_14c[iVar9] = '\0';
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  do {
    cVar1 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(acStack_14c,(int)pcVar7 - (int)(acStack_14c + 1));
  pbVar10 = (byte *)(iVar2 + 0x1c) + *(byte *)(iVar2 + 0x1c) + 1;
  uVar4 = FUN_0055c740(pbVar10,auStack_4c);
  FUN_00562fc0(&piStack_18,uVar4,auStack_4c,-(uint)(pbVar10 != (byte *)0x0) & (uint)(pbVar10 + 1));
  if (0xf < uStack_38) {
    uVar8 = uStack_38 + 1;
    uVar11 = auStack_4c[0];
    if (0xfff < uVar8) {
      uVar11 = *(uint *)(auStack_4c[0] - 4);
      uVar8 = uStack_38 + 0x24;
      if (0x1f < (auStack_4c[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar8);
  }
  if (piStack_18 == (int *)0x0) {
    piVar5 = (int *)FUN_00790a20(auStack_1c,acStack_14c,param_3,param_4);
    pcVar7 = acStack_14c;
    uStack_8 = 0;
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    do {
      cVar1 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0(acStack_14c,(int)pcVar7 - (int)(acStack_14c + 1));
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar6 = FUN_00790690(auStack_34);
    iVar9 = piVar5[1];
    piVar5[1] = 0;
    iVar2 = *piVar5;
    *piVar5 = 0;
    *(int *)(iVar6 + 0x18) = iVar2;
    piVar5 = *(int **)(iVar6 + 0x1c);
    *(int *)(iVar6 + 0x1c) = iVar9;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar9 = piVar5[1] + -1;
      piVar5[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar9 = piVar5[2] + -1;
        piVar5[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    iVar9 = *(int *)(iVar6 + 0x1c);
    *param_2 = 0;
    param_2[1] = 0;
    if (iVar9 != 0) {
      LOCK();
      *(int *)(iVar9 + 4) = *(int *)(iVar9 + 4) + 1;
      UNLOCK();
      iVar9 = *(int *)(iVar6 + 0x1c);
    }
    *param_2 = *(int *)(iVar6 + 0x18);
    param_2[1] = iVar9;
    if (0xf < uStack_20) {
      uVar8 = uStack_20 + 1;
      uVar11 = auStack_34[0];
      if (0xfff < uVar8) {
        uVar11 = *(uint *)(auStack_34[0] - 4);
        uVar8 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar8);
    }
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_18[1] + -1;
      piStack_18[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar5 = piStack_18 + 2;
        iVar9 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar9 == 1) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar9 = piStack_18[9];
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar9 != 0) {
    LOCK();
    *(int *)(iVar9 + 4) = *(int *)(iVar9 + 4) + 1;
    UNLOCK();
    iVar9 = piStack_18[9];
  }
  *param_2 = piStack_18[8];
  param_2[1] = iVar9;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 11334 ; VA 0x007910b0 ; FUN_007910b0 */

undefined4 * __thiscall
FUN_007910b0(int *param_1,undefined4 *param_2,undefined4 param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,int param_7,int param_8)

{
  uint uVar1;
  undefined4 uVar2;
  int *piVar3;
  uint uVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined4 *puVar7;
  int iVar8;
  int iVar9;
  int *piStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b1108;
  pvStack_10 = ExceptionList;
  piVar3 = param_1 + 0x12;
  piStack_14 = param_1;
  if ((uint)param_1[0x16] < param_4) {
    ExceptionList = &pvStack_10;
    FUN_00578160(param_4 - param_1[0x16],0);
  }
  else {
    piVar6 = piVar3;
    if (0xf < (uint)param_1[0x17]) {
      piVar6 = (int *)*piVar3;
    }
    ExceptionList = &pvStack_10;
    param_1[0x16] = param_4;
    *(undefined *)(param_4 + (int)piVar6) = 0;
  }
  piVar6 = piVar3;
  if (0xf < (uint)param_1[0x17]) {
    piVar6 = (int *)*piVar3;
  }
  FUN_0170c6f0(piVar6,param_3,param_4);
  FUN_00790940(piVar3,param_5);
  FUN_00592760(0x2c);
  uVar1 = param_1[0x16];
  uVar4 = param_7 + uVar1;
  if (uVar1 < uVar4) {
    FUN_00578160(uVar4 - uVar1,0);
  }
  else {
    piVar6 = piVar3;
    if (0xf < (uint)param_1[0x17]) {
      piVar6 = (int *)*piVar3;
    }
    param_1[0x16] = uVar4;
    *(undefined *)((int)piVar6 + uVar4) = 0;
  }
  piVar6 = piVar3;
  if (0xf < (uint)param_1[0x17]) {
    piVar6 = (int *)*piVar3;
  }
  FUN_0170c6f0((int)piVar6 + uVar1,param_6,param_7);
  FUN_00790940(piVar3,param_8);
  FUN_00592760(0x2c);
  iVar9 = (int)param_1 + *(byte *)(param_1 + 7) + 0x1d;
  uVar5 = FUN_0055c740(iVar9,piVar3);
  FUN_00562fc0(&param_8,uVar5,piVar3,-(uint)(iVar9 != 0) & iVar9 + 1U);
  if (param_8 == 0) {
    uVar4 = param_1[0x17];
    piStack_28 = piVar3;
    if (0xf < uVar4) {
      piStack_28 = (int *)*piVar3;
    }
    iStack_24 = uVar1 - 1;
    iStack_1c = (piStack_14[0x16] - uVar1) + -1;
    piVar6 = piVar3;
    if (0xf < uVar4) {
      piVar6 = (int *)*piVar3;
    }
    iStack_20 = (int)piVar6 + uVar1;
    piVar6 = piVar3;
    if (0xf < uVar4) {
      piVar6 = (int *)*piVar3;
    }
    puVar7 = (undefined4 *)FUN_00790a20(auStack_18,piVar6,&piStack_28,2);
    uStack_8 = 0;
    iVar9 = FUN_00790690(piVar3);
    uVar5 = *puVar7;
    uVar2 = puVar7[1];
    *puVar7 = 0;
    puVar7[1] = 0;
    *(undefined4 *)(iVar9 + 0x18) = uVar5;
    piVar3 = *(int **)(iVar9 + 0x1c);
    *(undefined4 *)(iVar9 + 0x1c) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar8 = piVar3[1] + -1;
      piVar3[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar8 = piVar3[2] + -1;
        piVar3[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = piStack_14;
    iVar8 = *(int *)(iVar9 + 0x1c);
    *param_2 = 0;
    param_2[1] = 0;
    if (iVar8 != 0) {
      LOCK();
      *(int *)(iVar8 + 4) = *(int *)(iVar8 + 4) + 1;
      UNLOCK();
      iVar8 = *(int *)(iVar9 + 0x1c);
    }
    *param_2 = *(undefined4 *)(iVar9 + 0x18);
    param_2[1] = iVar8;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_14[1] + -1;
      piStack_14[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar6 = piVar3 + 2;
        iVar9 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar9 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar9 = *(int *)(param_8 + 0x24);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar9 != 0) {
    LOCK();
    *(int *)(iVar9 + 4) = *(int *)(iVar9 + 4) + 1;
    UNLOCK();
    iVar9 = *(int *)(param_8 + 0x24);
  }
  *param_2 = *(undefined4 *)(param_8 + 0x20);
  param_2[1] = iVar9;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 11335 ; VA 0x00791300 ; FUN_00791300 */

void __thiscall
FUN_00791300(int *param_1,char *param_2,undefined4 *param_3,undefined4 *param_4,char param_5)

{
  undefined uVar1;
  char cVar2;
  uint *puVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  double *pdVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  char *pcVar12;
  uint uVar13;
  uint uVar14;
  char *pcVar15;
  int **ppiVar16;
  undefined auStack_10c [12];
  undefined auStack_100 [12];
  undefined auStack_f4 [16];
  int iStack_e4;
  int iStack_e0;
  undefined2 uStack_dc;
  undefined2 uStack_da;
  int iStack_d4;
  int iStack_d0;
  int iStack_cc;
  int iStack_c8;
  int iStack_c4;
  uint uStack_c0;
  double dStack_bc;
  uint uStack_b4;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  undefined8 uStack_a4;
  char *pcStack_9c;
  char *pcStack_98;
  uint auStack_90 [4];
  undefined4 uStack_80;
  uint uStack_7c;
  uint uStack_78;
  undefined4 uStack_68;
  uint uStack_64;
  char *pcStack_60;
  int iStack_5c;
  int iStack_58;
  code *pcStack_54;
  int iStack_50;
  char *pcStack_4c;
  uint uStack_48;
  undefined4 auStack_40 [3];
  char *pcStack_34;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int iStack_20;
  uint uStack_1c;
  char *pcStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b1190;
  pvStack_10 = ExceptionList;
  pcStack_18 = (char *)0x0;
  puStack_14 = &stack0xfffffee8;
  piStack_30 = *(int **)(*param_1 + 0x3c);
  ExceptionList = &pvStack_10;
  piStack_24 = param_1;
  FUN_016827e0(&dStack_bc);
  pcVar12 = param_2;
  uStack_8 = 0;
  uStack_68 = 0;
  uStack_64 = 0xf;
  uStack_78 = uStack_78 & 0xffffff00;
  pcStack_18 = (char *)0x1;
  FUN_0058a190(*(int *)(param_2 + 0x10) + 9);
  pcVar15 = pcVar12 + 0x10;
  if (0xf < *(uint *)(pcVar12 + 0x14)) {
    pcVar12 = *(char **)pcVar12;
  }
  FUN_00554150(pcVar12,*(undefined4 *)pcVar15);
  FUN_00554150("/shaders_",9);
  puVar7 = param_3;
  if (0xf < (uint)param_3[5]) {
    puVar7 = (undefined4 *)*param_3;
  }
  puVar3 = (uint *)FUN_00554150(puVar7,param_3[4]);
  pcStack_18 = (char *)0x3;
  uStack_b4 = *puVar3;
  uStack_b0 = puVar3[1];
  uStack_ac = puVar3[2];
  uStack_a8 = puVar3[3];
  uStack_a4 = *(undefined8 *)(puVar3 + 4);
  puVar3[4] = 0;
  puVar3[5] = 0xf;
  *(undefined *)puVar3 = 0;
  uStack_8._0_1_ = 1;
  piVar4 = (int *)FUN_00554150(".pack",5);
  iStack_d4 = *piVar4;
  iStack_d0 = piVar4[1];
  iStack_cc = piVar4[2];
  iStack_c8 = piVar4[3];
  iStack_c4 = piVar4[4];
  uStack_c0 = piVar4[5];
  piVar4[4] = 0;
  piVar4[5] = 0xf;
  *(undefined *)piVar4 = 0;
  uStack_8._0_1_ = 3;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_a4._4_4_) {
    uVar14 = uStack_a4._4_4_ + 1;
    uVar13 = uStack_b4;
    if (0xfff < uVar14) {
      uVar13 = *(uint *)(uStack_b4 - 4);
      uVar14 = uStack_a4._4_4_ + 0x24;
      if (0x1f < (uStack_b4 - uVar13) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar13,uVar14);
  }
  uStack_a4 = 0xf00000000;
  uStack_b4 = uStack_b4 & 0xffffff00;
  uStack_8._0_1_ = 4;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 4;
  if (0xf < uStack_64) {
    uVar14 = uStack_64 + 1;
    uVar13 = uStack_78;
    if (0xfff < uVar14) {
      uVar13 = *(uint *)(uStack_78 - 4);
      uVar14 = uStack_64 + 0x24;
      if (0x1f < (uStack_78 - uVar13) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar13,uVar14);
  }
  uStack_68 = 0;
  uStack_64 = 0xf;
  uStack_78 = uStack_78 & 0xffffff00;
  iVar5 = FUN_0153ad50(&iStack_d4);
  pcStack_54 = FUN_01718190;
  uStack_8._0_1_ = 5;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 5;
  iStack_50 = iVar5;
  iStack_20 = iVar5;
  if (iVar5 == 0) {
    uStack_8._0_1_ = uVar1;
    uVar10 = FUN_005543f0();
    uVar11 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Error opening shader pack %s (%s)",uVar11,uVar10);
  }
  iVar6 = FUN_017189e9(&iStack_e4,1,0x10,iVar5);
  if (iVar6 != 0x10) {
    FUN_016756b0(auStack_f4,"Unexpected end of file while reading %d bytes",0x10);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_f4,&DAT_01c17198);
  }
  if (iStack_e4 != 0x53584252) {
    uVar10 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Error: shader pack %s is corrupted",uVar10);
  }
  if (iStack_e0 != 7) {
    uVar10 = FUN_005543f0(7,iStack_e0);
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Error: shader pack %s is outdated (expected version %d, got %d instead)",uVar10);
  }
  FUN_00790170(uStack_dc,(int)&param_2 + 3);
  uStack_8._0_1_ = 6;
  pcStack_18 = (char *)(iStack_5c - (int)pcStack_60 >> 6);
  FUN_00791b40(iVar5,pcStack_60,(int)pcStack_18 << 6);
  FUN_007900c0(uStack_da,(int)&param_2 + 3);
  pcStack_34 = pcStack_98;
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_00791b40(iVar5,pcStack_9c,(((int)pcStack_98 - (int)pcStack_9c) / 0x60) * 0x60);
  uStack_1c = 0;
  pcVar15 = pcStack_60;
  if (pcStack_18 != (char *)0x0) {
    do {
      param_2 = pcVar15 + 1;
      pcVar12 = pcVar15;
      do {
        cVar2 = *pcVar12;
        pcVar12 = pcVar12 + 1;
      } while (cVar2 != '\0');
      puVar7 = param_4;
      if (0xf < (uint)param_4[5]) {
        puVar7 = (undefined4 *)*param_4;
      }
      cVar2 = FUN_0055c360(puVar7,param_4[4],pcVar15,(int)pcVar12 - (int)param_2);
      iVar5 = iStack_20;
      if (cVar2 != '\0') {
        uStack_48 = uStack_1c;
        if (-1 < (int)uStack_1c) {
          pcStack_4c = pcStack_98;
          pcVar15 = pcStack_9c;
          while( true ) {
            pcStack_18 = pcVar15;
            if (pcVar15 == pcStack_98) {
              piVar4 = piStack_24;
              if (DAT_01f6dcc0 != '\0') {
                uVar10 = FUN_01726462(iStack_20);
                piVar4 = piStack_24;
                puVar7 = param_4;
                if (0xf < (uint)param_4[5]) {
                  puVar7 = (undefined4 *)*param_4;
                }
                puVar8 = param_3;
                if (0xf < (uint)param_3[5]) {
                  puVar8 = (undefined4 *)*param_3;
                }
                FUN_01677520(DAT_01f6dcc0,"Loaded %d shaders from pack %s variant %s (%d bytes)",
                             piStack_24[3],puVar8,puVar7,uVar10);
                if (DAT_01f6dcc0 != '\0') {
                  pdVar9 = (double *)FUN_016827e0(&piStack_2c);
                  FUN_01677520(DAT_01f6dcc0,"Compiled %d shaders in %d ms",piVar4[3],
                               (int)((*pdVar9 - dStack_bc) * DAT_018c0d70));
                }
              }
              if (param_5 != '\0') {
                pdVar9 = (double *)FUN_016827e0(&piStack_2c);
                FUN_0086f2f0(0,"Loaded %d shaders in %d ms",piVar4[3],
                             (int)((*pdVar9 - dStack_bc) * DAT_018c0d70));
              }
              FUN_007908d0();
              uStack_8._0_1_ = 5;
              if (pcStack_60 != (char *)0x0) {
                uVar13 = iStack_58 - (int)pcStack_60 & 0xffffffc0;
                pcVar15 = pcStack_60;
                if (0xfff < uVar13) {
                  pcVar15 = *(char **)(pcStack_60 + -4);
                  uVar13 = uVar13 + 0x23;
                  if ((char *)0x1f < pcStack_60 + (-4 - (int)pcVar15)) {
                    /* WARNING: Subroutine does not return */
                    FUN_017167a3();
                  }
                }
                FUN_01674ea0(pcVar15,uVar13);
              }
              uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
              if (iVar5 != 0) {
                (*pcStack_54)(iVar5);
              }
              if (0xf < uStack_c0) {
                uVar13 = uStack_c0 + 1;
                iVar5 = iStack_d4;
                if (0xfff < uVar13) {
                  iVar5 = *(int *)(iStack_d4 + -4);
                  uVar13 = uStack_c0 + 0x24;
                  if (0x1f < (iStack_d4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
                    FUN_017167a3();
                  }
                }
                FUN_01674ea0(iVar5,uVar13);
              }
              ExceptionList = pvStack_10;
              return;
            }
            if ((byte)pcVar15[0x5d] == uStack_1c) break;
            pcVar15 = pcVar15 + 0x60;
          }
          FUN_007158e0(*(undefined4 *)(pcVar15 + 0x54),(int)&param_2 + 3);
          uStack_8._0_1_ = 8;
          FUN_01718e22(iStack_20,*(undefined4 *)(pcVar15 + 0x50),0);
          iVar5 = *(int *)(pcVar15 + 0x54);
          iVar6 = FUN_017189e9(auStack_40[0],1,iVar5,iStack_20);
          if (iVar6 != iVar5) {
            FUN_016756b0(auStack_100,"Unexpected end of file while reading %d bytes",iVar5);
                    /* WARNING: Subroutine does not return */
            FUN_0170c2a8(auStack_100,&DAT_01c17198);
          }
          uStack_8._0_1_ = 9;
          uStack_80 = 0;
          uStack_7c = 0xf;
          auStack_90[0] = auStack_90[0] & 0xffffff00;
          pcVar12 = pcVar15;
          do {
            cVar2 = *pcVar12;
            pcVar12 = pcVar12 + 1;
          } while (cVar2 != '\0');
          FUN_005542c0(pcVar15,(int)pcVar12 - (int)(pcVar15 + 1));
          uStack_8._0_1_ = 10;
          FUN_00790940(auStack_90,*(undefined4 *)(pcVar15 + 0x58));
          cVar2 = pcVar15[0x5c];
          if (cVar2 == 'c') {
            uVar10 = 2;
          }
          else if (cVar2 == 'p') {
            uVar10 = 1;
          }
          else {
            if (cVar2 != 'v') {
              FUN_016756b0(auStack_10c,"Unknown shader type %c",(int)cVar2);
                    /* WARNING: Subroutine does not return */
              FUN_0170c2a8(auStack_10c,&DAT_01c17198);
            }
            uVar10 = 0;
          }
          puVar7 = auStack_40;
          ppiVar16 = &piStack_2c;
          (**(code **)(*piStack_30 + 0x34))(ppiVar16,uVar10,puVar7);
          uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
          (**(code **)(*piStack_2c + 0xc))(auStack_90);
          iVar5 = FUN_00790450(auStack_90);
          if (piStack_28 != (int *)0x0) {
            LOCK();
            piStack_28[1] = piStack_28[1] + 1;
            UNLOCK();
          }
          *(int **)(iVar5 + 0x18) = piStack_2c;
          piVar4 = *(int **)(iVar5 + 0x1c);
          *(int **)(iVar5 + 0x1c) = piStack_28;
          if (piVar4 != (int *)0x0) {
            LOCK();
            iVar5 = piVar4[1] + -1;
            piVar4[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)*piVar4)();
              LOCK();
              iVar5 = piVar4[2] + -1;
              piVar4[2] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)(*piVar4 + 4))();
              }
            }
          }
          if (piStack_28 != (int *)0x0) {
            LOCK();
            iVar5 = piStack_28[1] + -1;
            piStack_28[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)*piStack_28)();
              LOCK();
              iVar5 = piStack_28[2] + -1;
              piStack_28[2] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)(*piStack_28 + 4))();
              }
            }
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,9);
          if (0xf < uStack_7c) {
            uVar14 = uStack_7c + 1;
            uVar13 = auStack_90[0];
            if (0xfff < uVar14) {
              uVar13 = *(uint *)(auStack_90[0] - 4);
              uVar14 = uStack_7c + 0x24;
              if (0x1f < (auStack_90[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(uVar13,uVar14);
          }
          FUN_0079186d(ppiVar16,uVar10,puVar7);
          return;
        }
        break;
      }
      uStack_1c = uStack_1c + 1;
      pcVar15 = pcVar15 + 0x40;
    } while (uStack_1c < pcStack_18);
  }
  uVar10 = FUN_005543f0();
  uVar11 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Error: shader pack %s does not have variant %s",uVar11,uVar10);
}



/* FUNCTION 11336 ; VA 0x007917f3 ; Catch@007917f3 */

undefined * Catch_007917f3(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  if (DAT_01f6dcc0 != '\0') {
    FUN_01677650(DAT_01f6dcc0,"Error: failed to create shader %s",*(undefined4 *)(unaff_EBP + -0x14)
                );
  }
  *(char *)(unaff_EBP + -0x40) = DAT_01f6dcc0;
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0xe4) + 4))();
  FUN_0054eff0(uVar1);
  *(undefined *)(unaff_EBP + -4) = 0xd;
  FUN_0147da10(unaff_EBP + -0x8c,*(undefined4 *)(unaff_EBP + -0x40));
  FUN_005507b0();
  return &DAT_00791858;
}



/* FUNCTION 11337 ; VA 0x0079186d ; FUN_0079186d */

void __fastcall FUN_0079186d(undefined4 param_1,uint param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  double *pdVar6;
  char *pcVar7;
  int iVar8;
  int *piVar9;
  uint uVar10;
  uint uVar11;
  int unaff_EBP;
  char *unaff_ESI;
  char *pcVar12;
  char *unaff_EDI;
  int iVar13;
  
  iVar13 = *(int *)(unaff_EBP + -0x3c);
  *(undefined4 *)(unaff_EBP + -4) = 8;
  *(undefined *)(unaff_EBP + -4) = 7;
  if (iVar13 != 0) {
    uVar11 = *(int *)(unaff_EBP + -0x34) - iVar13;
    iVar2 = iVar13;
    if (0xfff < uVar11) {
      iVar2 = *(int *)(iVar13 + -4);
      uVar11 = uVar11 + 0x23;
      if (0x1f < (iVar13 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar11);
    param_2 = *(uint *)(unaff_EBP + -0x18);
    *(undefined4 *)(unaff_EBP + -0x3c) = 0;
    *(undefined4 *)(unaff_EBP + -0x38) = 0;
    *(undefined4 *)(unaff_EBP + -0x34) = 0;
  }
  do {
    pcVar12 = unaff_ESI;
    unaff_ESI = pcVar12 + 0x60;
    *(char **)(unaff_EBP + -0x14) = unaff_ESI;
    if (unaff_ESI == unaff_EDI) {
      iVar13 = *(int *)(unaff_EBP + -0x1c);
      if (DAT_01f6dcc0 == '\0') {
        iVar2 = *(int *)(unaff_EBP + -0x20);
      }
      else {
        uVar3 = FUN_01726462(iVar13);
        piVar9 = *(int **)(unaff_EBP + 0x10);
        if (0xf < (uint)piVar9[5]) {
          piVar9 = (int *)*piVar9;
        }
        piVar5 = *(int **)(unaff_EBP + 0xc);
        if (0xf < (uint)piVar5[5]) {
          piVar5 = (int *)*piVar5;
        }
        iVar2 = *(int *)(unaff_EBP + -0x20);
        FUN_01677520(DAT_01f6dcc0,"Loaded %d shaders from pack %s variant %s (%d bytes)",
                     *(undefined4 *)(iVar2 + 0xc),piVar5,piVar9,uVar3);
        if (DAT_01f6dcc0 != '\0') {
          pdVar6 = (double *)FUN_016827e0(unaff_EBP + -0x28);
          FUN_01677520(DAT_01f6dcc0,"Compiled %d shaders in %d ms",*(undefined4 *)(iVar2 + 0xc),
                       (int)((*pdVar6 - *(double *)(unaff_EBP + -0xb8)) * DAT_018c0d70));
        }
      }
      if (*(char *)(unaff_EBP + 0x14) != '\0') {
        pdVar6 = (double *)FUN_016827e0(unaff_EBP + -0x28);
        FUN_0086f2f0(0,"Loaded %d shaders in %d ms",*(undefined4 *)(iVar2 + 0xc),
                     (int)((*pdVar6 - *(double *)(unaff_EBP + -0xb8)) * DAT_018c0d70));
      }
      FUN_007908d0();
      iVar2 = *(int *)(unaff_EBP + -0x5c);
      *(undefined *)(unaff_EBP + -4) = 5;
      if (iVar2 != 0) {
        uVar11 = *(int *)(unaff_EBP + -0x54) - iVar2 & 0xffffffc0;
        iVar8 = iVar2;
        if (0xfff < uVar11) {
          iVar8 = *(int *)(iVar2 + -4);
          uVar11 = uVar11 + 0x23;
          if (0x1f < (iVar2 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar8,uVar11);
      }
      *(undefined *)(unaff_EBP + -4) = 0xe;
      if (iVar13 != 0) {
        (**(code **)(unaff_EBP + -0x50))(iVar13);
      }
      uVar11 = *(uint *)(unaff_EBP + -0xbc);
      if (0xf < uVar11) {
        iVar13 = *(int *)(unaff_EBP + -0xd0);
        uVar10 = uVar11 + 1;
        iVar2 = iVar13;
        if (0xfff < uVar10) {
          iVar2 = *(int *)(iVar13 + -4);
          uVar10 = uVar11 + 0x24;
          if (0x1f < (iVar13 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar2,uVar10);
      }
      ExceptionList = *(void **)(unaff_EBP + -0xc);
      return;
    }
  } while ((byte)pcVar12[0xbd] != param_2);
  FUN_007158e0(*(undefined4 *)(pcVar12 + 0xb4),unaff_EBP + 0xb);
  uVar3 = *(undefined4 *)(pcVar12 + 0xb0);
  *(undefined *)(unaff_EBP + -4) = 8;
  FUN_01718e22(*(undefined4 *)(unaff_EBP + -0x1c),uVar3,0);
  iVar13 = *(int *)(pcVar12 + 0xb4);
  iVar2 = FUN_017189e9(*(undefined4 *)(unaff_EBP + -0x3c),1,iVar13,
                       *(undefined4 *)(unaff_EBP + -0x1c));
  if (iVar2 == iVar13) {
    *(undefined *)(unaff_EBP + -4) = 9;
    *(undefined4 *)(unaff_EBP + -0x7c) = 0;
    *(undefined4 *)(unaff_EBP + -0x78) = 0xf;
    *(undefined *)(unaff_EBP + -0x8c) = 0;
    pcVar7 = unaff_ESI;
    do {
      cVar1 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0(unaff_ESI,(int)pcVar7 - (int)(pcVar12 + 0x61));
    uVar3 = *(undefined4 *)(pcVar12 + 0xb8);
    *(undefined *)(unaff_EBP + -4) = 10;
    FUN_00790940(unaff_EBP + -0x8c,uVar3);
    cVar1 = pcVar12[0xbc];
    if (cVar1 == 'c') {
      uVar3 = 2;
    }
    else if (cVar1 == 'p') {
      uVar3 = 1;
    }
    else {
      if (cVar1 != 'v') {
        FUN_016756b0(unaff_EBP + -0x108,"Unknown shader type %c",(int)cVar1);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(unaff_EBP + -0x108,&DAT_01c17198);
      }
      uVar3 = 0;
    }
    iVar13 = unaff_EBP + -0x3c;
    iVar2 = unaff_EBP + -0x28;
    (**(code **)(**(int **)(unaff_EBP + -0x2c) + 0x34))(iVar2,uVar3,iVar13);
    *(undefined *)(unaff_EBP + -4) = 0xb;
    (**(code **)(**(int **)(unaff_EBP + -0x28) + 0xc))(unaff_EBP + -0x8c);
    iVar4 = FUN_00790450(unaff_EBP + -0x8c);
    iVar8 = *(int *)(unaff_EBP + -0x24);
    if (iVar8 != 0) {
      LOCK();
      *(int *)(iVar8 + 4) = *(int *)(iVar8 + 4) + 1;
      UNLOCK();
      iVar8 = *(int *)(unaff_EBP + -0x24);
    }
    *(undefined4 *)(iVar4 + 0x18) = *(undefined4 *)(unaff_EBP + -0x28);
    piVar9 = *(int **)(iVar4 + 0x1c);
    *(int *)(iVar4 + 0x1c) = iVar8;
    if (piVar9 != (int *)0x0) {
      LOCK();
      iVar8 = piVar9[1] + -1;
      piVar9[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piVar9)();
        LOCK();
        iVar8 = piVar9[2] + -1;
        piVar9[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar9 + 4))();
        }
      }
    }
    piVar9 = *(int **)(unaff_EBP + -0x24);
    if (piVar9 != (int *)0x0) {
      LOCK();
      iVar8 = piVar9[1] + -1;
      piVar9[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piVar9)();
        LOCK();
        iVar8 = piVar9[2] + -1;
        piVar9[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar9 + 4))();
        }
      }
    }
    uVar11 = *(uint *)(unaff_EBP + -0x78);
    *(undefined *)(unaff_EBP + -4) = 9;
    if (0xf < uVar11) {
      iVar8 = *(int *)(unaff_EBP + -0x8c);
      uVar10 = uVar11 + 1;
      iVar4 = iVar8;
      if (0xfff < uVar10) {
        iVar4 = *(int *)(iVar8 + -4);
        uVar10 = uVar11 + 0x24;
        if (0x1f < (iVar8 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar10);
    }
    FUN_0079186d(iVar2,uVar3,iVar13);
    return;
  }
  FUN_016756b0(unaff_EBP + -0xfc,"Unexpected end of file while reading %d bytes",iVar13);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(unaff_EBP + -0xfc,&DAT_01c17198);
}



/* FUNCTION 11338 ; VA 0x00791b40 ; FUN_00791b40 */

void FUN_00791b40(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined auStack_10 [12];
  
  iVar1 = FUN_017189e9(param_2,1,param_3,param_1);
  if (iVar1 == param_3) {
    return;
  }
  FUN_016756b0(auStack_10,"Unexpected end of file while reading %d bytes",param_3);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 11339 ; VA 0x00791b90 ; FUN_00791b90 */

void __fastcall FUN_00791b90(int param_1)

{
  if (*(int *)(param_1 + 0x38) != 0) {
    FUN_0153ccf0();
    if (*(char *)(param_1 + 0x34) != '\0') {
      *(undefined *)(param_1 + 0x34) = 0;
      FUN_0078c660();
      return;
    }
  }
  return;
}



/* FUNCTION 11340 ; VA 0x00791bc0 ; FUN_00791bc0 */

void __thiscall FUN_00791bc0(int *param_1,uint param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  
  iVar6 = param_1[1];
  iVar5 = *param_1;
  uVar2 = iVar6 - iVar5 >> 3;
  uVar7 = param_1[2] - iVar5 >> 3;
  if (param_2 <= uVar7) {
    if (uVar2 < param_2) {
      iVar5 = FUN_00793d40(iVar6,param_2 - uVar2);
      param_1[1] = iVar5;
      return;
    }
    if (param_2 != uVar2) {
      iVar5 = iVar5 + param_2 * 8;
      FUN_005596d0(iVar5,iVar6,param_1);
      param_1[1] = iVar5;
    }
    return;
  }
  if (0x1fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar3 = param_2;
  if ((uVar7 <= 0x1fffffff - (uVar7 >> 1)) && (uVar3 = (uVar7 >> 1) + uVar7, uVar3 < param_2)) {
    uVar3 = param_2;
  }
  uVar7 = uVar3 * 8;
  if (uVar3 < 0x20000000) {
    if (0xfff < uVar7) goto LAB_00791c32;
    if (uVar7 == 0) {
      puVar10 = (undefined4 *)0x0;
    }
    else {
      puVar10 = (undefined4 *)FUN_01674e20(uVar7);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_00791c32:
    uVar4 = uVar7 + 0x23;
    if (uVar4 <= uVar7) {
      uVar4 = 0xffffffff;
    }
    iVar5 = FUN_01674e20(uVar4);
    if (iVar5 == 0) goto LAB_00791d63;
    puVar10 = (undefined4 *)(iVar5 + 0x23U & 0xffffffe0);
    puVar10[-1] = iVar5;
  }
  FUN_00793d40(puVar10 + uVar2 * 2,param_2 - uVar2);
  puVar1 = (undefined4 *)param_1[1];
  puVar9 = puVar10;
  for (puVar8 = (undefined4 *)*param_1; puVar8 != puVar1; puVar8 = puVar8 + 2) {
    *puVar9 = 0;
    puVar9[1] = 0;
    *puVar9 = *puVar8;
    puVar9[1] = puVar8[1];
    puVar9 = puVar9 + 2;
    *puVar8 = 0;
    puVar8[1] = 0;
  }
  FUN_005596d0(puVar9,puVar9,param_1);
  if (*param_1 != 0) {
    FUN_005596d0(*param_1,param_1[1],param_1);
    iVar5 = *param_1;
    uVar2 = param_1[2] - iVar5 & 0xfffffff8;
    iVar6 = iVar5;
    if (0xfff < uVar2) {
      iVar6 = *(int *)(iVar5 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar5 - iVar6) - 4U) {
LAB_00791d63:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar2);
  }
  *param_1 = (int)puVar10;
  param_1[1] = (int)(puVar10 + param_2 * 2);
  param_1[2] = (int)(puVar10 + uVar3 * 2);
  return;
}



/* FUNCTION 11341 ; VA 0x00791d70 ; FUN_00791d70 */

void __thiscall FUN_00791d70(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b11a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<struct_RBX::Graphics::SceneManager::GuiClusterRT>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11342 ; VA 0x00791dde ; Catch_All@00791dde */

void Catch_All_00791dde(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_007959b0(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11343 ; VA 0x00791e00 ; FUN_00791e00 */

void __thiscall FUN_00791e00(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b11b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<struct_RBX::Graphics::RTPool::RT>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11344 ; VA 0x00791e6e ; Catch_All@00791e6e */

void Catch_All_00791e6e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00795a50(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 11345 ; VA 0x00791e90 ; FUN_00791e90 */

undefined4 * __fastcall FUN_00791e90(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0x3f800000;
  return param_1;
}



/* FUNCTION 11346 ; VA 0x00791eb0 ; FUN_00791eb0 */

undefined4 * __thiscall FUN_00791eb0(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b1230;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  param_1[0xf] = param_2;
  param_1[0x10] = 2;
  param_1[0x11] = 1;
  *(undefined2 *)(param_1 + 0x12) = 0;
  uStack_24 = 0;
  piStack_20 = (int *)0x0;
  uStack_8 = 9;
  puStack_14 = param_1;
  FUN_007735a0(&uStack_24,3);
  piVar1 = piStack_18;
  param_1[0xb] = uStack_1c;
  piVar2 = (int *)param_1[0xc];
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  param_1[0xc] = piVar1;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
    piVar2 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[1] + -1;
      piStack_18[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  piVar2 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_20[1] + -1;
    piStack_20[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_24 = 0;
  piStack_20 = (int *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  FUN_007735a0(&uStack_24,3);
  piVar1 = piStack_18;
  param_1[0xd] = uStack_1c;
  piVar2 = (int *)param_1[0xe];
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  param_1[0xe] = piVar1;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
    piVar2 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[1] + -1;
      piStack_18[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  piVar2 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_20[1] + -1;
    piStack_20[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11347 ; VA 0x007920d0 ; FUN_007920d0 */

int * __thiscall FUN_007920d0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  char cVar4;
  undefined uVar5;
  int iVar6;
  undefined4 uVar7;
  undefined *puVar8;
  int *piVar9;
  bool bVar10;
  undefined auStack_34 [4];
  int *piStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b14b1;
  pvStack_10 = ExceptionList;
  piStack_14 = (int *)0x0;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0x7f7fffff;
  param_1[5] = 0x7f7fffff;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  *(undefined *)(param_1 + 0xd) = 0;
  param_1[0xe] = 0;
  *(undefined2 *)(param_1 + 0xf) = 0;
  *(undefined *)((int)param_1 + 0x3e) = 1;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0x3f800000;
  piStack_2c = param_1;
  FUN_00776530();
  param_1[0xe9] = 0;
  param_1[0xea] = 0;
  param_1[0xeb] = 0x3f800000;
  param_1[0xec] = 0;
  param_1[0xed] = 0;
  param_1[0xee] = 0;
  param_1[0xef] = 0x3f800000;
  FUN_01165ab0();
  param_1[0x100] = 0;
  param_1[0x101] = 0;
  param_1[0x102] = 0;
  param_1[0x103] = 0;
  param_1[0x104] = 0;
  param_1[0x105] = (int)&DAT_bf800000;
  param_1[0x106] = 0;
  param_1[0x107] = 0;
  param_1[0x108] = 0;
  param_1[0x109] = 0;
  param_1[0x10a] = 0;
  param_1[0x10b] = 0;
  param_1[0x10c] = 0;
  param_1[0x10d] = 0;
  param_1[0x10e] = 0;
  param_1[0x10f] = 0;
  param_1[0x110] = 0;
  param_1[0x111] = 0;
  param_1[0x112] = 0;
  param_1[0x113] = 0;
  param_1[0x114] = 0;
  uStack_8._0_1_ = 0x12;
  FUN_016f4053(param_1 + 0x115,4,3,FUN_00550050,&LAB_00793410);
  param_1[0x119] = 0;
  param_1[0x11a] = 0;
  param_1[0x11b] = 0;
  param_1[0x11c] = 0;
  param_1[0x11d] = 0;
  param_1[0x11e] = 0;
  *(undefined *)(param_1 + 0x124) = 0;
  param_1[0x122] = 0;
  param_1[0x123] = 0;
  param_1[0x125] = 0;
  param_1[0x126] = 0;
  param_1[0x127] = 0;
  *(undefined *)(param_1 + 0x129) = 0;
  param_1[0x12a] = 0;
  param_1[299] = 0;
  param_1[300] = 0;
  piVar9 = *(int **)(param_2 + 0x3c);
  uStack_8._0_1_ = 0x18;
  piStack_24 = piVar9;
  piStack_1c = (int *)FUN_01674e20(0x38);
  uStack_8._0_1_ = 0x19;
  if (piStack_1c == (int *)0x0) {
    iVar6 = 0;
  }
  else {
    iVar6 = FUN_00816c30();
  }
  iVar2 = param_1[6];
  uStack_8._0_1_ = 0x18;
  param_1[6] = iVar6;
  if (iVar2 != 0) {
    FUN_00816ca0();
    FUN_01674ea0(iVar2,0x38);
  }
  piStack_1c = (int *)FUN_01674e20(0xbc);
  uStack_8._0_1_ = 0x1a;
  if (piStack_1c == (int *)0x0) {
    iVar6 = 0;
  }
  else {
    iVar6 = FUN_007f6300();
  }
  iVar2 = param_1[10];
  uStack_8._0_1_ = 0x18;
  param_1[10] = iVar6;
  if (iVar2 != 0) {
    uStack_8._0_1_ = 0x1b;
    FUN_016f32d1(iVar2,0xc,0xf,FUN_00612d60);
    uStack_8._0_1_ = 0x18;
    FUN_01674ea0(iVar2,0xbc);
  }
  piStack_1c = (int *)FUN_01674e20(0x18);
  uStack_8._0_1_ = 0x1c;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x1c;
  if (piStack_1c == (int *)0x0) {
    iVar6 = 0;
    uStack_8._0_1_ = uVar5;
  }
  else {
    uVar7 = FUN_00797f00(auStack_34,piVar9);
    uStack_8._0_1_ = 0x1d;
    piStack_14 = (int *)0x1;
    iVar6 = FUN_0147c720(uVar7,0,0,0,3);
  }
  piStack_1c = (int *)param_1[0x107];
  param_1[0x107] = iVar6;
  if (piStack_1c != (int *)0x0) {
    piVar9 = *(int **)((int)piStack_1c + 4);
    if (piVar9 != (int *)0x0) {
      LOCK();
      iVar6 = piVar9[1] + -1;
      piVar9[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar9)();
        LOCK();
        iVar6 = piVar9[2] + -1;
        piVar9[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar9 + 4))();
        }
      }
    }
    FUN_01674ea0(piStack_1c,0x18);
  }
  uStack_8 = 0x18;
  if ((((uint)piStack_14 & 1) != 0) && (piStack_30 != (int *)0x0)) {
    LOCK();
    iVar6 = piStack_30[1] + -1;
    piStack_30[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      iVar6 = piStack_30[2] + -1;
      piStack_30[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  piStack_1c = (int *)FUN_01674e20(0x18c);
  uStack_8._0_1_ = 0x1f;
  if (piStack_1c == (int *)0x0) {
    iVar6 = 0;
  }
  else {
    iVar6 = FUN_0081a040(param_2);
  }
  piStack_1c = (int *)param_1[0x109];
  uStack_8._0_1_ = 0x18;
  param_1[0x109] = iVar6;
  if (piStack_1c != (int *)0x0) {
    FUN_0081a3c0();
    FUN_01674ea0(piStack_1c,0x18c);
  }
  piStack_1c = (int *)FUN_01674e20(0x4f0);
  uStack_8._0_1_ = 0x20;
  if (piStack_1c == (int *)0x0) {
    iVar6 = 0;
  }
  else {
    iVar6 = FUN_0081dac0(param_2);
  }
  piStack_1c = (int *)param_1[0x10a];
  uStack_8._0_1_ = 0x18;
  param_1[0x10a] = iVar6;
  if (piStack_1c != (int *)0x0) {
    FUN_0081e900();
    FUN_01674ea0(piStack_1c,0x4f0);
  }
  if (DAT_01d60fb8 != '\0') {
    piStack_1c = (int *)FUN_01674e20(0x88);
    uStack_8._0_1_ = 0x21;
    if (piStack_1c == (int *)0x0) {
      iVar6 = 0;
    }
    else {
      iVar6 = FUN_008225e0(param_2);
    }
    piStack_1c = (int *)param_1[0x10b];
    uStack_8._0_1_ = 0x18;
    param_1[0x10b] = iVar6;
    if (piStack_1c != (int *)0x0) {
      FUN_00822820();
      FUN_01674ea0(piStack_1c,0x88);
    }
  }
  piStack_1c = (int *)FUN_01674e20(0x6c);
  uStack_8._0_1_ = 0x22;
  if (piStack_1c == (int *)0x0) {
    iVar6 = 0;
  }
  else {
    iVar6 = FUN_008235f0(param_2);
  }
  iVar2 = param_1[0x10e];
  uStack_8._0_1_ = 0x18;
  param_1[0x10e] = iVar6;
  if (iVar2 != 0) {
    FUN_008238c0();
    FUN_01674ea0(iVar2,0x6c);
  }
  puVar8 = (undefined *)FUN_01674e20(0x30);
  uStack_8._0_1_ = 0x23;
  if (puVar8 == (undefined *)0x0) {
    puVar8 = (undefined *)0x0;
  }
  else {
    *(int *)(puVar8 + 0x1c) = param_2;
    *puVar8 = 1;
    *(undefined4 *)(puVar8 + 4) = 0x400ccccd;
    *(undefined4 *)(puVar8 + 8) = 0x41c00000;
    puVar8[0xc] = 0;
    *(undefined4 *)(puVar8 + 0x10) = 0x3ecccccd;
    *(undefined4 *)(puVar8 + 0x14) = 0x40400000;
    *(undefined4 *)(puVar8 + 0x18) = 0x3f4ccccd;
    piStack_1c = (int *)puVar8;
    FUN_016f4053(puVar8 + 0x20,4,2,FUN_00550050,FUN_00793290);
    *(undefined4 *)(puVar8 + 0x28) = 0;
    *(undefined4 *)(puVar8 + 0x2c) = 0;
  }
  piStack_1c = (int *)param_1[0x10f];
  uStack_8._0_1_ = 0x18;
  param_1[0x10f] = (int)puVar8;
  if (piStack_1c != (int *)0x0) {
    uStack_8._0_1_ = 0x24;
    FUN_016f32d1((int)piStack_1c + 0x20,4,2,FUN_00793290);
    uStack_8._0_1_ = 0x18;
    FUN_01674ea0(piStack_1c,0x30);
  }
  piStack_1c = (int *)FUN_01674e20(0x30);
  uStack_8._0_1_ = 0x25;
  if (piStack_1c == (int *)0x0) {
    iVar6 = 0;
  }
  else {
    iVar6 = FUN_007930b0(param_2);
  }
  piStack_1c = (int *)param_1[0x112];
  uStack_8._0_1_ = 0x18;
  param_1[0x112] = iVar6;
  if (piStack_1c != (int *)0x0) {
    piVar9 = *(int **)((int)piStack_1c + 0x2c);
    if (piVar9 != (int *)0x0) {
      LOCK();
      iVar6 = piVar9[1] + -1;
      piVar9[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar9)();
        LOCK();
        iVar6 = piVar9[2] + -1;
        piVar9[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar9 + 4))();
        }
      }
    }
    FUN_01674ea0(piStack_1c,0x30);
  }
  if (DAT_01d60f98 != '\0') {
    iVar6 = FUN_01674e20(0x5c);
    uStack_8._0_1_ = 0x26;
    piStack_1c = (int *)iVar6;
    if (iVar6 == 0) {
      iVar6 = 0;
    }
    else {
      FUN_01165ab0();
      *(int **)(iVar6 + 0x40) = param_1;
    }
    iVar2 = param_1[0x111];
    uStack_8._0_1_ = 0x18;
    param_1[0x111] = iVar6;
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x5c);
    }
  }
  piStack_1c = (int *)FUN_01674e20(0xc);
  if (piStack_1c == (int *)0x0) {
    piVar9 = (int *)0x0;
  }
  else {
    *piStack_1c = (int)param_1;
    piStack_1c[2] = 0;
    piVar9 = piStack_1c;
  }
  iVar6 = param_1[0x110];
  param_1[0x110] = (int)piVar9;
  if (iVar6 != 0) {
    FUN_01674ea0(iVar6,0xc);
  }
  piStack_1c = (int *)FUN_01674e20(0x1b8);
  uStack_8._0_1_ = 0x27;
  if (piStack_1c == (int *)0x0) {
    iVar6 = 0;
  }
  else {
    iVar6 = FUN_008265a0(param_2);
  }
  puVar3 = (undefined4 *)param_1[0x113];
  uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
  param_1[0x113] = iVar6;
  if (puVar3 != (undefined4 *)0x0) {
    (**(code **)*puVar3)(1);
  }
  puVar8 = (undefined *)FUN_01674e20(0x1c);
  if (puVar8 == (undefined *)0x0) {
    puVar8 = (undefined *)0x0;
  }
  else {
    *puVar8 = 0;
    *(undefined4 *)(puVar8 + 4) = 0x3f800000;
    *(undefined4 *)(puVar8 + 8) = 0x3f800000;
    *(undefined4 *)(puVar8 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar8 + 0x10) = 0;
    *(undefined4 *)(puVar8 + 0x14) = 0;
    *(undefined4 *)(puVar8 + 0x18) = 0;
  }
  iVar6 = param_1[0x114];
  param_1[0x114] = (int)puVar8;
  if (iVar6 != 0) {
    FUN_01674ea0(iVar6,0x1c);
  }
  piVar9 = (int *)FUN_01674e20(0x10);
  if (piVar9 == (int *)0x0) {
    piVar9 = (int *)0x0;
  }
  else {
    *piVar9 = param_2;
    piVar9[1] = 0;
    piVar9[2] = 0;
    piVar9[3] = 0;
  }
  iVar6 = param_1[0x10c];
  param_1[0x10c] = (int)piVar9;
  if (iVar6 != 0) {
    FUN_00577ac0();
    FUN_01674ea0(iVar6,0x10);
  }
  iVar6 = FUN_01674e20(0x4c);
  uStack_8._0_1_ = 0x28;
  if (iVar6 == 0) {
    iVar6 = 0;
  }
  else {
    iVar6 = FUN_00791eb0(param_2);
  }
  iVar2 = param_1[0x10d];
  uStack_8._0_1_ = 0x18;
  param_1[0x10d] = iVar6;
  if (iVar2 != 0) {
    FUN_00793500();
    FUN_01674ea0(iVar2,0x4c);
  }
  iVar6 = FUN_01674e20(0xbc);
  uStack_8._0_1_ = 0x29;
  if (iVar6 == 0) {
    iVar6 = 0;
  }
  else {
    iVar6 = FUN_007f6300();
  }
  iVar2 = param_1[0xb];
  uStack_8._0_1_ = 0x18;
  param_1[0xb] = iVar6;
  if (iVar2 != 0) {
    uStack_8._0_1_ = 0x2a;
    FUN_016f32d1(iVar2,0xc,0xf,FUN_00612d60);
    uStack_8._0_1_ = 0x18;
    FUN_01674ea0(iVar2,0xbc);
  }
  cVar4 = DAT_01d60f78;
  *(char *)(param_1 + 0xd) = DAT_01d60f78;
  bVar10 = DAT_01d60f80 != '\0';
  param_1[0xe] = (uint)bVar10;
  if ((cVar4 != '\0') || (bVar10 != 0)) {
    iVar6 = FUN_01674e20(0xbc);
    uStack_8._0_1_ = 0x2b;
    if (iVar6 == 0) {
      iVar6 = 0;
    }
    else {
      iVar6 = FUN_007f6300();
    }
    iVar2 = param_1[0xc];
    param_1[0xc] = iVar6;
    if (iVar2 != 0) {
      uStack_8._0_1_ = 0x2c;
      FUN_016f32d1(iVar2,0xc,0xf,FUN_00612d60);
      FUN_01674ea0(iVar2,0xbc);
    }
  }
  uStack_18 = 0;
  piStack_14 = (int *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x2d);
  FUN_007735a0(&uStack_18,3);
  piVar1 = piStack_1c;
  param_1[0x11b] = iStack_20;
  piVar9 = (int *)param_1[0x11c];
  iStack_20 = 0;
  piStack_1c = (int *)0x0;
  param_1[0x11c] = (int)piVar1;
  if (piVar9 != (int *)0x0) {
    LOCK();
    iVar6 = piVar9[1] + -1;
    piVar9[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar9)();
      LOCK();
      iVar6 = piVar9[2] + -1;
      piVar9[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar9 + 4))();
      }
    }
    piVar9 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar6 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar9 + 2;
        iVar6 = *piVar1 + -1;
        *piVar1 = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar9 + 4))();
        }
      }
    }
  }
  piVar9 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_14[1] + -1;
    piStack_14[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar9 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar9 + 4))();
      }
    }
  }
  uStack_18 = 0;
  piStack_14 = (int *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x2e);
  FUN_007735a0(&uStack_18,3);
  piVar1 = piStack_1c;
  param_1[0x11d] = iStack_20;
  piVar9 = (int *)param_1[0x11e];
  iStack_20 = 0;
  piStack_1c = (int *)0x0;
  param_1[0x11e] = (int)piVar1;
  if (piVar9 != (int *)0x0) {
    LOCK();
    iVar6 = piVar9[1] + -1;
    piVar9[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar9)();
      LOCK();
      iVar6 = piVar9[2] + -1;
      piVar9[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar9 + 4))();
      }
    }
    piVar9 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar6 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar9 + 2;
        iVar6 = *piVar1 + -1;
        *piVar1 = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar9 + 4))();
        }
      }
    }
  }
  piVar9 = piStack_14;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_14[1] + -1;
    piStack_14[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar9 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar9 + 4))();
      }
    }
  }
  piVar9 = piStack_24;
  iVar6 = (**(code **)(*piStack_24 + 0x40))();
  if (*(char *)(iVar6 + 9) == '\0') {
    iVar6 = (**(code **)(*piVar9 + 0x40))();
    iVar6 = (*(char *)(iVar6 + 8) != '\0') + 0x16;
  }
  else {
    iVar6 = 0x19;
  }
  param_1[0x128] = iVar6;
  uStack_28 = 0;
  piStack_24 = (int *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x2f);
  FUN_00791bc0(0xc,param_1 + 0x125,&uStack_28);
  piVar9 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_24[1] + -1;
    piStack_24[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar9 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar9 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11348 ; VA 0x00792bc0 ; FUN_00792bc0 */

undefined4 * __thiscall
FUN_00792bc0(undefined4 *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 *puVar7;
  char cVar8;
  undefined4 *puVar9;
  undefined auStack_50 [4];
  int *piStack_4c;
  undefined auStack_40 [4];
  int *piStack_3c;
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b1534;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  puStack_18 = param_1 + 2;
  uStack_8 = 0;
  puStack_14 = param_1;
  FUN_016f4053(puStack_18,8,2,FUN_005502b0,FUN_00550b30);
  puStack_1c = param_1 + 6;
  uStack_8._0_1_ = 1;
  FUN_016f4053(puStack_1c,8,2,FUN_005502b0,FUN_00550b30);
  uStack_8._0_1_ = 2;
  uVar5 = FUN_01675290(DAT_01eb1cfc);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  piVar2 = *(int **)(param_2 + 0x3c);
  uStack_20 = uVar5;
  (**(code **)(*piVar2 + 0x40))();
  iVar6 = (**(code **)(*piVar2 + 0x40))();
  if (*(char *)(iVar6 + 6) == '\0') {
    iVar6 = (**(code **)(*piVar2 + 0x40))();
    cVar8 = (*(char *)(iVar6 + 8) != '\0') + '\x16';
  }
  else {
    iVar6 = (**(code **)(*piVar2 + 0x40))();
    cVar8 = (*(char *)(iVar6 + 8) == '\0') * '\x02' + '\x18';
  }
  FUN_0147c180(auStack_28,0,cVar8,param_4,param_4,2);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  puVar7 = (undefined4 *)FUN_0147c180(auStack_30,0,param_3,param_4,param_4,3);
  uVar3 = *puVar7;
  uVar4 = puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  *puStack_18 = uVar3;
  piVar2 = (int *)puStack_18[1];
  puStack_18[1] = uVar4;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = piStack_2c;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  puVar7 = (undefined4 *)FUN_0147c180(auStack_30,0,param_3,param_4,param_4,3);
  puVar9 = puStack_14 + 4;
  uVar3 = *puVar7;
  uVar4 = puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  *puVar9 = uVar3;
  piVar2 = (int *)puStack_14[5];
  puStack_14[5] = uVar4;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = piStack_2c;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_0147d420(auStack_28);
  uStack_8._0_1_ = 5;
  FUN_0147d420(puStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  puVar7 = (undefined4 *)FUN_0147bf30(auStack_30,auStack_40,auStack_50);
  uVar3 = *puVar7;
  uVar4 = puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  *puStack_1c = uVar3;
  piVar2 = (int *)puStack_1c[1];
  puStack_1c[1] = uVar4;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = piStack_2c;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = piStack_3c;
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = piStack_4c;
  uStack_8._0_1_ = 4;
  if (piStack_4c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_4c[1] + -1;
    piStack_4c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_4c)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_0147d420(auStack_28);
  uStack_8._0_1_ = 7;
  FUN_0147d420(puVar9);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  puVar7 = (undefined4 *)FUN_0147bf30(auStack_30,auStack_50,auStack_40);
  uVar3 = *puVar7;
  uVar4 = puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  puStack_14[8] = uVar3;
  piVar2 = (int *)puStack_14[9];
  puStack_14[9] = uVar4;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = piStack_2c;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = piStack_4c;
  if (piStack_4c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_4c[1] + -1;
    piStack_4c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_4c)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = piStack_3c;
  uStack_8._0_1_ = 4;
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_0147d420(auStack_28);
  uStack_8._0_1_ = 9;
  FUN_0147d420(puStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  puVar7 = (undefined4 *)FUN_0147bf30(auStack_30,auStack_50,auStack_40);
  uVar3 = *puVar7;
  uVar4 = puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  *puStack_14 = uVar3;
  piVar2 = (int *)puStack_14[1];
  puStack_14[1] = uVar4;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      iVar6 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  if (piStack_4c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_4c[1] + -1;
    piStack_4c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_4c)();
      LOCK();
      iVar6 = piStack_4c[2] + -1;
      piStack_4c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_4c + 4))();
      }
    }
  }
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      iVar6 = piStack_3c[2] + -1;
      piStack_3c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_24[1] + -1;
    piStack_24[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar2 = piStack_24 + 2;
      iVar6 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  FUN_01675290(uVar5);
  ExceptionList = pvStack_10;
  return puStack_14;
}



/* FUNCTION 11349 ; VA 0x007930b0 ; FUN_007930b0 */

undefined4 * __thiscall FUN_007930b0(undefined4 *param_1,undefined4 param_2)

{
  undefined uVar1;
  undefined4 uVar2;
  int *piVar3;
  code *pcVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  uint uVar9;
  undefined auStack_74 [88];
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b154b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  *(undefined *)(param_1 + 4) = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0x3f800000;
  param_1[8] = 0x3f800000;
  param_1[9] = 0x3f800000;
  param_1[10] = 0;
  param_1[0xb] = 0;
  uVar9 = 0;
  uStack_8 = 0;
  do {
    auStack_74[uVar9] =
         (char)(int)((float)((double)(int)uVar9 + (double)(&DAT_018c0d90)[-((int)uVar9 >> 0x1f)]) *
                     DAT_018e3f7c * DAT_018f9000);
    uVar9 = uVar9 + 1;
  } while (uVar9 < 0x40);
  uVar9 = 0;
  puStack_14 = param_1;
  do {
    uVar6 = FUN_01679ce0();
    uVar1 = auStack_74[uVar9];
    auStack_74[uVar9] = auStack_74[uVar6 & 0x3f];
    uVar9 = uVar9 + 1;
    auStack_74[uVar6 & 0x3f] = uVar1;
  } while (uVar9 < 0x40);
  puVar7 = (undefined4 *)FUN_0147c180(auStack_1c,0,0,8,8,5);
  uVar8 = *puVar7;
  uVar2 = puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  param_1[10] = uVar8;
  piVar3 = (int *)param_1[0xb];
  param_1[0xb] = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[1] + -1;
    piVar3[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar5 = piVar3[2] + -1;
      piVar3[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_18[1] + -1;
    piStack_18[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar3 = piStack_18 + 2;
      iVar5 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  pcVar4 = *(code **)(*(int *)param_1[10] + 0x10);
  uVar8 = FUN_0147ce60(0,0,8,8);
  (*pcVar4)(0,0,uVar8,auStack_74,0x40);
  (**(code **)(*(int *)param_1[10] + 0x2c))();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11350 ; VA 0x00793250 ; FUN_00793250 */

void __fastcall FUN_00793250(int *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,0x18);
  }
  return;
}



/* FUNCTION 11351 ; VA 0x00793290 ; FUN_00793290 */

void __fastcall FUN_00793290(int *param_1)

{
  if (*param_1 != 0) {
    FUN_007957e0(*param_1);
  }
  return;
}



/* FUNCTION 11352 ; VA 0x007932a0 ; FUN_007932a0 */

void __fastcall FUN_007932a0(int *param_1)

{
  if (*param_1 != 0) {
    FUN_00795850(*param_1);
  }
  return;
}



/* FUNCTION 11353 ; VA 0x007932b0 ; FUN_007932b0 */

void __fastcall FUN_007932b0(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_0081e900();
    FUN_01674ea0(iVar1,0x4f0);
  }
  return;
}



/* FUNCTION 11354 ; VA 0x007932d0 ; FUN_007932d0 */

void __fastcall FUN_007932d0(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_00822820();
    FUN_01674ea0(iVar1,0x88);
  }
  return;
}



/* FUNCTION 11355 ; VA 0x007932f0 ; FUN_007932f0 */

void __fastcall FUN_007932f0(int *param_1)

{
  if (*param_1 != 0) {
    FUN_01674ea0(*param_1,0x1c);
  }
  return;
}



/* FUNCTION 11356 ; VA 0x00793310 ; FUN_00793310 */

void __fastcall FUN_00793310(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_00816ca0();
    FUN_01674ea0(iVar1,0x38);
  }
  return;
}



/* FUNCTION 11357 ; VA 0x00793330 ; FUN_00793330 */

void __fastcall FUN_00793330(int *param_1)

{
  if (*param_1 != 0) {
    FUN_01674ea0(*param_1,0x5c);
  }
  return;
}



/* FUNCTION 11358 ; VA 0x00793350 ; FUN_00793350 */

void __fastcall FUN_00793350(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(iVar1 + 0x20,4,2,FUN_00793290);
    FUN_01674ea0(iVar1,0x30);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11359 ; VA 0x007933b0 ; FUN_007933b0 */

void __fastcall FUN_007933b0(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_00793500();
    FUN_01674ea0(iVar1,0x4c);
  }
  return;
}



/* FUNCTION 11360 ; VA 0x007933d0 ; FUN_007933d0 */

void __fastcall FUN_007933d0(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_00577ac0();
    FUN_01674ea0(iVar1,0x10);
  }
  return;
}



/* FUNCTION 11361 ; VA 0x007933f0 ; FUN_007933f0 */

void __fastcall FUN_007933f0(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_008238c0();
    FUN_01674ea0(iVar1,0x6c);
  }
  return;
}



/* FUNCTION 11362 ; VA 0x00793420 ; FUN_00793420 */

void __fastcall FUN_00793420(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_0081a3c0();
    FUN_01674ea0(iVar1,0x18c);
  }
  return;
}



/* FUNCTION 11363 ; VA 0x00793440 ; FUN_00793440 */

void __fastcall FUN_00793440(int *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 0x2c);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,0x30);
  }
  return;
}



/* FUNCTION 11364 ; VA 0x00793480 ; FUN_00793480 */

void __fastcall FUN_00793480(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x6c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x58);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x4c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x007934f9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 11365 ; VA 0x00793500 ; FUN_00793500 */

void __fastcall FUN_00793500(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = (int *)param_1[0xe];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0xc];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[10];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[8];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (param_1[6] != 0) {
    FUN_007957e0(param_1[6]);
  }
  if (param_1[5] != 0) {
    FUN_007957e0(param_1[5]);
  }
  piVar2 = (int *)param_1[4];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[2];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (*param_1 != 0) {
    FUN_00795850(*param_1);
  }
  return;
}



/* FUNCTION 11366 ; VA 0x00793620 ; FUN_00793620 */

void __fastcall FUN_00793620(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017949a0;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(param_1 + 0x4a8);
  ExceptionList = &pvStack_10;
  if (iVar2 != 0) {
    uVar5 = (*(int *)(param_1 + 0x4b0) - iVar2 >> 2) * 4;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar5 + 0x23;
      ExceptionList = &pvStack_10;
      if (0x1f < (iVar2 - iVar4) - 4U) goto LAB_00793a34;
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x4a8) = 0;
    *(undefined4 *)(param_1 + 0x4ac) = 0;
    *(undefined4 *)(param_1 + 0x4b0) = 0;
  }
  FUN_00577ac0();
  piVar3 = *(int **)(param_1 + 0x478);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = *(int **)(param_1 + 0x470);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = *(int **)(param_1 + 0x468);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_016f32d1(param_1 + 0x454,4,3,&LAB_00793410);
  if (*(int *)(param_1 + 0x450) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x450),0x1c);
  }
  if (*(undefined4 **)(param_1 + 0x44c) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x44c))(1);
  }
  iVar2 = *(int *)(param_1 + 0x448);
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 0x2c);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,0x30);
  }
  if (*(int *)(param_1 + 0x444) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x444),0x5c);
  }
  if (*(int *)(param_1 + 0x440) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x440),0xc);
  }
  iVar2 = *(int *)(param_1 + 0x43c);
  if (iVar2 != 0) {
    uStack_8 = 0;
    FUN_016f32d1(iVar2 + 0x20,4,2,FUN_00793290);
    uStack_8 = 0xffffffff;
    FUN_01674ea0(iVar2,0x30);
  }
  iVar2 = *(int *)(param_1 + 0x438);
  if (iVar2 != 0) {
    FUN_008238c0();
    FUN_01674ea0(iVar2,0x6c);
  }
  iVar2 = *(int *)(param_1 + 0x434);
  if (iVar2 != 0) {
    FUN_00793500();
    FUN_01674ea0(iVar2,0x4c);
  }
  iVar2 = *(int *)(param_1 + 0x430);
  if (iVar2 != 0) {
    FUN_00577ac0();
    FUN_01674ea0(iVar2,0x10);
  }
  iVar2 = *(int *)(param_1 + 0x42c);
  if (iVar2 != 0) {
    FUN_00822820();
    FUN_01674ea0(iVar2,0x88);
  }
  iVar2 = *(int *)(param_1 + 0x428);
  if (iVar2 != 0) {
    FUN_0081e900();
    FUN_01674ea0(iVar2,0x4f0);
  }
  iVar2 = *(int *)(param_1 + 0x424);
  if (iVar2 != 0) {
    FUN_0081a3c0();
    FUN_01674ea0(iVar2,0x18c);
  }
  iVar2 = *(int *)(param_1 + 0x420);
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,0x18);
  }
  iVar2 = *(int *)(param_1 + 0x41c);
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,0x18);
  }
  iVar2 = *(int *)(param_1 + 0x30);
  if (iVar2 != 0) {
    uStack_8 = 1;
    FUN_016f32d1(iVar2,0xc,0xf,FUN_00612d60);
    uStack_8 = 0xffffffff;
    FUN_01674ea0(iVar2,0xbc);
  }
  iVar2 = *(int *)(param_1 + 0x2c);
  if (iVar2 != 0) {
    uStack_8 = 2;
    FUN_016f32d1(iVar2,0xc,0xf,FUN_00612d60);
    uStack_8 = 0xffffffff;
    FUN_01674ea0(iVar2,0xbc);
  }
  iVar2 = *(int *)(param_1 + 0x28);
  if (iVar2 != 0) {
    uStack_8 = 3;
    FUN_016f32d1(iVar2,0xc,0xf,FUN_00612d60);
    FUN_01674ea0(iVar2,0xbc);
  }
  iVar2 = *(int *)(param_1 + 0x1c);
  if (iVar2 != 0) {
    uVar5 = *(int *)(param_1 + 0x24) - iVar2 & 0xfffffffc;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar2 - iVar4) - 4U) {
LAB_00793a34:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x1c) = 0;
    *(undefined4 *)(param_1 + 0x20) = 0;
    *(undefined4 *)(param_1 + 0x24) = 0;
  }
  iVar2 = *(int *)(param_1 + 0x18);
  if (iVar2 != 0) {
    FUN_00816ca0();
    FUN_01674ea0(iVar2,0x38);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11367 ; VA 0x00793a40 ; FUN_00793a40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00793a40(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b156c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2310;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2318) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2318);
    uVar1 = CONCAT44(_DAT_01eb2314,_DAT_01eb2310);
    if (DAT_01eb2318 == -1) {
      uStack_8 = 0;
      _DAT_01eb2308 = FUN_0152dab0("Render","Id_OpaqueAdorns",0xffffffff);
      _DAT_01eb2310 = FUN_0152dab0(&DAT_018fb928,"Id_OpaqueAdorns",0xffffffff);
      FUN_016f37bf(&DAT_01eb2318);
      uVar1 = _DAT_01eb2310;
    }
  }
  _DAT_01eb2310 = uVar1;
  *param_1 = _DAT_01eb2308;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11368 ; VA 0x00793b00 ; FUN_00793b00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00793b00(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b158c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb20a0;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb20a8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb20a8);
    uVar1 = CONCAT44(_DAT_01eb20a4,_DAT_01eb20a0);
    if (DAT_01eb20a8 == -1) {
      uStack_8 = 0;
      _DAT_01eb2098 = FUN_0152dab0("Render","Id_GlassTint",0xffffffff);
      _DAT_01eb20a0 = FUN_0152dab0(&DAT_018fb928,"Id_GlassTint",0xffffffff);
      FUN_016f37bf(&DAT_01eb20a8);
      uVar1 = _DAT_01eb20a0;
    }
  }
  _DAT_01eb20a0 = uVar1;
  *param_1 = _DAT_01eb2098;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11369 ; VA 0x00793bc0 ; FUN_00793bc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00793bc0(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b15ac;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2388;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2390) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2390);
    uVar1 = CONCAT44(_DAT_01eb238c,_DAT_01eb2388);
    if (DAT_01eb2390 == -1) {
      uStack_8 = 0;
      _DAT_01eb2380 = FUN_0152dab0("Render","Id_Transparent",0xffffffff);
      _DAT_01eb2388 = FUN_0152dab0(&DAT_018fb928,"Id_Transparent",0xffffffff);
      FUN_016f37bf(&DAT_01eb2390);
      uVar1 = _DAT_01eb2388;
    }
  }
  _DAT_01eb2388 = uVar1;
  *param_1 = _DAT_01eb2380;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11370 ; VA 0x00793c80 ; FUN_00793c80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00793c80(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b15cc;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2028;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2030) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2030);
    uVar1 = CONCAT44(_DAT_01eb202c,_DAT_01eb2028);
    if (DAT_01eb2030 == -1) {
      uStack_8 = 0;
      _DAT_01eb2020 = FUN_0152dab0("Render","Id_Opaque",0xffffffff);
      _DAT_01eb2028 = FUN_0152dab0(&DAT_018fb928,"Id_Opaque",0xffffffff);
      FUN_016f37bf(&DAT_01eb2030);
      uVar1 = _DAT_01eb2028;
    }
  }
  _DAT_01eb2028 = uVar1;
  *param_1 = _DAT_01eb2020;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11371 ; VA 0x00793d40 ; FUN_00793d40 */

undefined4 * __thiscall FUN_00793d40(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  
  uVar2 = *param_1;
  if (param_3 != 0) {
    puVar3 = (undefined4 *)param_1[1];
    do {
      *param_2 = 0;
      param_2[1] = 0;
      if (puVar3[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar3[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      *param_2 = *puVar3;
      param_2[1] = puVar3[1];
      param_2 = param_2 + 2;
      param_3 = param_3 + -1;
    } while (param_3 != 0);
  }
  FUN_005596d0(param_2,param_2,uVar2);
  return param_2;
}



/* FUNCTION 11372 ; VA 0x00793da0 ; FUN_00793da0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00793da0(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b15ec;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2280;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2288) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2288);
    uVar1 = CONCAT44(_DAT_01eb2284,_DAT_01eb2280);
    if (DAT_01eb2288 == -1) {
      uStack_8 = 0;
      _DAT_01eb2278 = FUN_0152dab0("Render","Id_OpaqueCasters",0xffffffff);
      _DAT_01eb2280 = FUN_0152dab0(&DAT_018fb928,"Id_OpaqueCasters",0xffffffff);
      FUN_016f37bf(&DAT_01eb2288);
      uVar1 = _DAT_01eb2280;
    }
  }
  _DAT_01eb2280 = uVar1;
  *param_1 = _DAT_01eb2278;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11373 ; VA 0x00793e60 ; FUN_00793e60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00793e60(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b160c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb1fc0;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1fc8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb1fc8);
    uVar1 = CONCAT44(_DAT_01eb1fc4,_DAT_01eb1fc0);
    if (DAT_01eb1fc8 == -1) {
      uStack_8 = 0;
      _DAT_01eb1fb8 = FUN_0152dab0("Render","Id_Screen",0xffffffff);
      _DAT_01eb1fc0 = FUN_0152dab0(&DAT_018fb928,"Id_Screen",0xffffffff);
      FUN_016f37bf(&DAT_01eb1fc8);
      uVar1 = _DAT_01eb1fc0;
    }
  }
  _DAT_01eb1fc0 = uVar1;
  *param_1 = _DAT_01eb1fb8;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11374 ; VA 0x00793f20 ; FUN_00793f20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00793f20(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b162c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb22d8;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb22e0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb22e0);
    uVar1 = CONCAT44(_DAT_01eb22dc,_DAT_01eb22d8);
    if (DAT_01eb22e0 == -1) {
      uStack_8 = 0;
      _DAT_01eb22d0 = FUN_0152dab0("Render","Id_OpaqueWithAlpha",0xffffffff);
      _DAT_01eb22d8 = FUN_0152dab0(&DAT_018fb928,"Id_OpaqueWithAlpha",0xffffffff);
      FUN_016f37bf(&DAT_01eb22e0);
      uVar1 = _DAT_01eb22d8;
    }
  }
  _DAT_01eb22d8 = uVar1;
  *param_1 = _DAT_01eb22d0;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11375 ; VA 0x00793fe0 ; FUN_00793fe0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00793fe0(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b164c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb23d8;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb23e0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb23e0);
    uVar1 = CONCAT44(_DAT_01eb23dc,_DAT_01eb23d8);
    if (DAT_01eb23e0 == -1) {
      uStack_8 = 0;
      _DAT_01eb23d0 = FUN_0152dab0("Render","Id_AlwaysOnTop",0xffffffff);
      _DAT_01eb23d8 = FUN_0152dab0(&DAT_018fb928,"Id_AlwaysOnTop",0xffffffff);
      FUN_016f37bf(&DAT_01eb23e0);
      uVar1 = _DAT_01eb23d8;
    }
  }
  _DAT_01eb23d8 = uVar1;
  *param_1 = _DAT_01eb23d0;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11376 ; VA 0x007940a0 ; FUN_007940a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007940a0(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b166c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb23f0;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb23f8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb23f8);
    uVar1 = CONCAT44(_DAT_01eb23f4,_DAT_01eb23f0);
    if (DAT_01eb23f8 == -1) {
      uStack_8 = 0;
      _DAT_01eb23e8 = FUN_0152dab0("Render","Id_Screen",0xffffffff);
      _DAT_01eb23f0 = FUN_0152dab0(&DAT_018fb928,"Id_Screen",0xffffffff);
      FUN_016f37bf(&DAT_01eb23f8);
      uVar1 = _DAT_01eb23f0;
    }
  }
  _DAT_01eb23f0 = uVar1;
  *param_1 = _DAT_01eb23e8;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11377 ; VA 0x00794160 ; FUN_00794160 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00794160(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b168c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb21a8;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb21b0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb21b0);
    uVar1 = CONCAT44(_DAT_01eb21ac,_DAT_01eb21a8);
    if (DAT_01eb21b0 == -1) {
      uStack_8 = 0;
      _DAT_01eb21a0 = FUN_0152dab0("Render","Id_OnTopWithDepth",0xffffffff);
      _DAT_01eb21a8 = FUN_0152dab0(&DAT_018fb928,"Id_OnTopWithDepth",0xffffffff);
      FUN_016f37bf(&DAT_01eb21b0);
      uVar1 = _DAT_01eb21a8;
    }
  }
  _DAT_01eb21a8 = uVar1;
  *param_1 = _DAT_01eb21a0;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11378 ; VA 0x00794220 ; FUN_00794220 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00794220(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b16ac;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2328;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2330) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2330);
    uVar1 = CONCAT44(_DAT_01eb232c,_DAT_01eb2328);
    if (DAT_01eb2330 == -1) {
      uStack_8 = 0;
      _DAT_01eb2320 = FUN_0152dab0("Render","Id_Water",0xffffffff);
      _DAT_01eb2328 = FUN_0152dab0(&DAT_018fb928,"Id_Water",0xffffffff);
      FUN_016f37bf(&DAT_01eb2330);
      uVar1 = _DAT_01eb2328;
    }
  }
  _DAT_01eb2328 = uVar1;
  *param_1 = _DAT_01eb2320;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11379 ; VA 0x007942e0 ; FUN_007942e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007942e0(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b16cc;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb1f90;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1f98) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb1f98);
    uVar1 = CONCAT44(_DAT_01eb1f94,_DAT_01eb1f90);
    if (DAT_01eb1f98 == -1) {
      uStack_8 = 0;
      _DAT_01eb1f88 = FUN_0152dab0("Render","Id_Screen",0xffffffff);
      _DAT_01eb1f90 = FUN_0152dab0(&DAT_018fb928,"Id_Screen",0xffffffff);
      FUN_016f37bf(&DAT_01eb1f98);
      uVar1 = _DAT_01eb1f90;
    }
  }
  _DAT_01eb1f90 = uVar1;
  *param_1 = _DAT_01eb1f88;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11380 ; VA 0x007943a0 ; FUN_007943a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007943a0(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b16ec;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2438;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2440) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2440);
    uVar1 = CONCAT44(_DAT_01eb243c,_DAT_01eb2438);
    if (DAT_01eb2440 == -1) {
      uStack_8 = 0;
      _DAT_01eb2430 = FUN_0152dab0("Render","Id_Transparent",0xffffffff);
      _DAT_01eb2438 = FUN_0152dab0(&DAT_018fb928,"Id_Transparent",0xffffffff);
      FUN_016f37bf(&DAT_01eb2440);
      uVar1 = _DAT_01eb2438;
    }
  }
  _DAT_01eb2438 = uVar1;
  *param_1 = _DAT_01eb2430;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11381 ; VA 0x00794460 ; FUN_00794460 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00794460(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b170c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2160;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2168) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2168);
    uVar1 = CONCAT44(_DAT_01eb2164,_DAT_01eb2160);
    if (DAT_01eb2168 == -1) {
      uStack_8 = 0;
      _DAT_01eb2158 = FUN_0152dab0("Render","Id_AlwaysOnTop",0xffffffff);
      _DAT_01eb2160 = FUN_0152dab0(&DAT_018fb928,"Id_AlwaysOnTop",0xffffffff);
      FUN_016f37bf(&DAT_01eb2168);
      uVar1 = _DAT_01eb2160;
    }
  }
  _DAT_01eb2160 = uVar1;
  *param_1 = _DAT_01eb2158;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11382 ; VA 0x00794520 ; FUN_00794520 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00794520(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b172c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2058;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2060) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2060);
    uVar1 = CONCAT44(_DAT_01eb205c,_DAT_01eb2058);
    if (DAT_01eb2060 == -1) {
      uStack_8 = 0;
      _DAT_01eb2050 = FUN_0152dab0("Render","Id_Decals",0xffffffff);
      _DAT_01eb2058 = FUN_0152dab0(&DAT_018fb928,"Id_Decals",0xffffffff);
      FUN_016f37bf(&DAT_01eb2060);
      uVar1 = _DAT_01eb2058;
    }
  }
  _DAT_01eb2058 = uVar1;
  *param_1 = _DAT_01eb2050;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11383 ; VA 0x007945e0 ; FUN_007945e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007945e0(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b174c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2210;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2218) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2218);
    uVar1 = CONCAT44(_DAT_01eb2214,_DAT_01eb2210);
    if (DAT_01eb2218 == -1) {
      uStack_8 = 0;
      _DAT_01eb2208 = FUN_0152dab0("Render","Id_OpaqueCasters",0xffffffff);
      _DAT_01eb2210 = FUN_0152dab0(&DAT_018fb928,"Id_OpaqueCasters",0xffffffff);
      FUN_016f37bf(&DAT_01eb2218);
      uVar1 = _DAT_01eb2210;
    }
  }
  _DAT_01eb2210 = uVar1;
  *param_1 = _DAT_01eb2208;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11384 ; VA 0x007946a0 ; FUN_007946a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007946a0(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b176c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2370;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2378) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2378);
    uVar1 = CONCAT44(_DAT_01eb2374,_DAT_01eb2370);
    if (DAT_01eb2378 == -1) {
      uStack_8 = 0;
      _DAT_01eb2368 = FUN_0152dab0("Render","Id_Transparent",0xffffffff);
      _DAT_01eb2370 = FUN_0152dab0(&DAT_018fb928,"Id_Transparent",0xffffffff);
      FUN_016f37bf(&DAT_01eb2378);
      uVar1 = _DAT_01eb2370;
    }
  }
  _DAT_01eb2370 = uVar1;
  *param_1 = _DAT_01eb2368;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11385 ; VA 0x00794760 ; FUN_00794760 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00794760(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b178c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb23a0;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb23a8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb23a8);
    uVar1 = CONCAT44(_DAT_01eb23a4,_DAT_01eb23a0);
    if (DAT_01eb23a8 == -1) {
      uStack_8 = 0;
      _DAT_01eb2398 = FUN_0152dab0("Render","Id_TransparentCasters",0xffffffff);
      _DAT_01eb23a0 = FUN_0152dab0(&DAT_018fb928,"Id_TransparentCasters",0xffffffff);
      FUN_016f37bf(&DAT_01eb23a8);
      uVar1 = _DAT_01eb23a0;
    }
  }
  _DAT_01eb23a0 = uVar1;
  *param_1 = _DAT_01eb2398;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11386 ; VA 0x00794820 ; FUN_00794820 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00794820(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b17ac;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2040;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2048) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2048);
    uVar1 = CONCAT44(_DAT_01eb2044,_DAT_01eb2040);
    if (DAT_01eb2048 == -1) {
      uStack_8 = 0;
      _DAT_01eb2038 = FUN_0152dab0("Render","Id_OpaqueCasters",0xffffffff);
      _DAT_01eb2040 = FUN_0152dab0(&DAT_018fb928,"Id_OpaqueCasters",0xffffffff);
      FUN_016f37bf(&DAT_01eb2048);
      uVar1 = _DAT_01eb2040;
    }
  }
  _DAT_01eb2040 = uVar1;
  *param_1 = _DAT_01eb2038;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11387 ; VA 0x007948e0 ; FUN_007948e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007948e0(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b17cc;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2298;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb22a0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb22a0);
    uVar1 = CONCAT44(_DAT_01eb229c,_DAT_01eb2298);
    if (DAT_01eb22a0 == -1) {
      uStack_8 = 0;
      _DAT_01eb2290 = FUN_0152dab0("Render","Id_Decals",0xffffffff);
      _DAT_01eb2298 = FUN_0152dab0(&DAT_018fb928,"Id_Decals",0xffffffff);
      FUN_016f37bf(&DAT_01eb22a0);
      uVar1 = _DAT_01eb2298;
    }
  }
  _DAT_01eb2298 = uVar1;
  *param_1 = _DAT_01eb2290;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11388 ; VA 0x007949a0 ; FUN_007949a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007949a0(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b17ec;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2088;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2090) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2090);
    uVar1 = CONCAT44(_DAT_01eb208c,_DAT_01eb2088);
    if (DAT_01eb2090 == -1) {
      uStack_8 = 0;
      _DAT_01eb2080 = FUN_0152dab0("Render","Id_OpaqueWithAlpha",0xffffffff);
      _DAT_01eb2088 = FUN_0152dab0(&DAT_018fb928,"Id_OpaqueWithAlpha",0xffffffff);
      FUN_016f37bf(&DAT_01eb2090);
      uVar1 = _DAT_01eb2088;
    }
  }
  _DAT_01eb2088 = uVar1;
  *param_1 = _DAT_01eb2080;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11389 ; VA 0x00794a60 ; FUN_00794a60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00794a60(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b180c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb1fa8;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1fb0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb1fb0);
    uVar1 = CONCAT44(_DAT_01eb1fac,_DAT_01eb1fa8);
    if (DAT_01eb1fb0 == -1) {
      uStack_8 = 0;
      _DAT_01eb1fa0 = FUN_0152dab0("Render","Id_ScreenOnTopOfBlur",0xffffffff);
      _DAT_01eb1fa8 = FUN_0152dab0(&DAT_018fb928,"Id_ScreenOnTopOfBlur",0xffffffff);
      FUN_016f37bf(&DAT_01eb1fb0);
      uVar1 = _DAT_01eb1fa8;
    }
  }
  _DAT_01eb1fa8 = uVar1;
  *param_1 = _DAT_01eb1fa0;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11390 ; VA 0x00794b20 ; FUN_00794b20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00794b20(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b182c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2268;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2270) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2270);
    uVar1 = CONCAT44(_DAT_01eb226c,_DAT_01eb2268);
    if (DAT_01eb2270 == -1) {
      uStack_8 = 0;
      _DAT_01eb2260 = FUN_0152dab0("Render","Id_Terrain",0xffffffff);
      _DAT_01eb2268 = FUN_0152dab0(&DAT_018fb928,"Id_Terrain",0xffffffff);
      FUN_016f37bf(&DAT_01eb2270);
      uVar1 = _DAT_01eb2268;
    }
  }
  _DAT_01eb2268 = uVar1;
  *param_1 = _DAT_01eb2260;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11391 ; VA 0x00794be0 ; FUN_00794be0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00794be0(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b184c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2250;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2258) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2258);
    uVar1 = CONCAT44(_DAT_01eb2254,_DAT_01eb2250);
    if (DAT_01eb2258 == -1) {
      uStack_8 = 0;
      _DAT_01eb2248 = FUN_0152dab0("Render","Id_Opaque",0xffffffff);
      _DAT_01eb2250 = FUN_0152dab0(&DAT_018fb928,"Id_Opaque",0xffffffff);
      FUN_016f37bf(&DAT_01eb2258);
      uVar1 = _DAT_01eb2250;
    }
  }
  _DAT_01eb2250 = uVar1;
  *param_1 = _DAT_01eb2248;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11392 ; VA 0x00794ca0 ; FUN_00794ca0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00794ca0(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b186c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb20b8;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb20c0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb20c0);
    uVar1 = CONCAT44(_DAT_01eb20bc,_DAT_01eb20b8);
    if (DAT_01eb20c0 == -1) {
      uStack_8 = 0;
      _DAT_01eb20b0 = FUN_0152dab0("Render","Id_Glass",0xffffffff);
      _DAT_01eb20b8 = FUN_0152dab0(&DAT_018fb928,"Id_Glass",0xffffffff);
      FUN_016f37bf(&DAT_01eb20c0);
      uVar1 = _DAT_01eb20b8;
    }
  }
  _DAT_01eb20b8 = uVar1;
  *param_1 = _DAT_01eb20b0;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11393 ; VA 0x00794d60 ; FUN_00794d60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00794d60(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b188c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2178;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2180) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2180);
    uVar1 = CONCAT44(_DAT_01eb217c,_DAT_01eb2178);
    if (DAT_01eb2180 == -1) {
      uStack_8 = 0;
      _DAT_01eb2170 = FUN_0152dab0("Render","Id_Screen",0xffffffff);
      _DAT_01eb2178 = FUN_0152dab0(&DAT_018fb928,"Id_Screen",0xffffffff);
      FUN_016f37bf(&DAT_01eb2180);
      uVar1 = _DAT_01eb2178;
    }
  }
  _DAT_01eb2178 = uVar1;
  *param_1 = _DAT_01eb2170;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11394 ; VA 0x00794e20 ; FUN_00794e20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00794e20(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b18ac;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2500;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2508) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2508);
    uVar1 = CONCAT44(_DAT_01eb2504,_DAT_01eb2500);
    if (DAT_01eb2508 == -1) {
      uStack_8 = 0;
      _DAT_01eb24f8 = FUN_0152dab0("Render","Id_OpaqueCasters",0xffffffff);
      _DAT_01eb2500 = FUN_0152dab0(&DAT_018fb928,"Id_OpaqueCasters",0xffffffff);
      FUN_016f37bf(&DAT_01eb2508);
      uVar1 = _DAT_01eb2500;
    }
  }
  _DAT_01eb2500 = uVar1;
  *param_1 = _DAT_01eb24f8;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11395 ; VA 0x00794ee0 ; FUN_00794ee0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00794ee0(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b18cc;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2358;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2360) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2360);
    uVar1 = CONCAT44(_DAT_01eb235c,_DAT_01eb2358);
    if (DAT_01eb2360 == -1) {
      uStack_8 = 0;
      _DAT_01eb2350 = FUN_0152dab0("Render","Id_Glass",0xffffffff);
      _DAT_01eb2358 = FUN_0152dab0(&DAT_018fb928,"Id_Glass",0xffffffff);
      FUN_016f37bf(&DAT_01eb2360);
      uVar1 = _DAT_01eb2358;
    }
  }
  _DAT_01eb2358 = uVar1;
  *param_1 = _DAT_01eb2350;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11396 ; VA 0x00794fa0 ; FUN_00794fa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00794fa0(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b18ec;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2238;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2240) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2240);
    uVar1 = CONCAT44(_DAT_01eb223c,_DAT_01eb2238);
    if (DAT_01eb2240 == -1) {
      uStack_8 = 0;
      _DAT_01eb2230 = FUN_0152dab0("Render","Id_OpaqueWithAlpha",0xffffffff);
      _DAT_01eb2238 = FUN_0152dab0(&DAT_018fb928,"Id_OpaqueWithAlpha",0xffffffff);
      FUN_016f37bf(&DAT_01eb2240);
      uVar1 = _DAT_01eb2238;
    }
  }
  _DAT_01eb2238 = uVar1;
  *param_1 = _DAT_01eb2230;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11397 ; VA 0x00795060 ; FUN_00795060 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00795060(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b190c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb1fd8;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1fe0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb1fe0);
    uVar1 = CONCAT44(_DAT_01eb1fdc,_DAT_01eb1fd8);
    if (DAT_01eb1fe0 == -1) {
      uStack_8 = 0;
      _DAT_01eb1fd0 = FUN_0152dab0("Render","Id_ScreenOnTopOfBlur",0xffffffff);
      _DAT_01eb1fd8 = FUN_0152dab0(&DAT_018fb928,"Id_ScreenOnTopOfBlur",0xffffffff);
      FUN_016f37bf(&DAT_01eb1fe0);
      uVar1 = _DAT_01eb1fd8;
    }
  }
  _DAT_01eb1fd8 = uVar1;
  *param_1 = _DAT_01eb1fd0;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11398 ; VA 0x00795120 ; FUN_00795120 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00795120(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b192c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb20d0;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb20d8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb20d8);
    uVar1 = CONCAT44(_DAT_01eb20d4,_DAT_01eb20d0);
    if (DAT_01eb20d8 == -1) {
      uStack_8 = 0;
      _DAT_01eb20c8 = FUN_0152dab0("Render","Id_Transparent",0xffffffff);
      _DAT_01eb20d0 = FUN_0152dab0(&DAT_018fb928,"Id_Transparent",0xffffffff);
      FUN_016f37bf(&DAT_01eb20d8);
      uVar1 = _DAT_01eb20d0;
    }
  }
  _DAT_01eb20d0 = uVar1;
  *param_1 = _DAT_01eb20c8;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11399 ; VA 0x007951e0 ; FUN_007951e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007951e0(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b194c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2070;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2078) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2078);
    uVar1 = CONCAT44(_DAT_01eb2074,_DAT_01eb2070);
    if (DAT_01eb2078 == -1) {
      uStack_8 = 0;
      _DAT_01eb2068 = FUN_0152dab0("Render","Id_OpaqueWithAlpha",0xffffffff);
      _DAT_01eb2070 = FUN_0152dab0(&DAT_018fb928,"Id_OpaqueWithAlpha",0xffffffff);
      FUN_016f37bf(&DAT_01eb2078);
      uVar1 = _DAT_01eb2070;
    }
  }
  _DAT_01eb2070 = uVar1;
  *param_1 = _DAT_01eb2068;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11400 ; VA 0x007952a0 ; FUN_007952a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007952a0(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b196c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2190;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2198) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2198);
    uVar1 = CONCAT44(_DAT_01eb2194,_DAT_01eb2190);
    if (DAT_01eb2198 == -1) {
      uStack_8 = 0;
      _DAT_01eb2188 = FUN_0152dab0("Render","Id_ScreenOnTopOfBlur",0xffffffff);
      _DAT_01eb2190 = FUN_0152dab0(&DAT_018fb928,"Id_ScreenOnTopOfBlur",0xffffffff);
      FUN_016f37bf(&DAT_01eb2198);
      uVar1 = _DAT_01eb2190;
    }
  }
  _DAT_01eb2190 = uVar1;
  *param_1 = _DAT_01eb2188;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11401 ; VA 0x00795360 ; FUN_00795360 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00795360(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b198c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2340;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2348) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2348);
    uVar1 = CONCAT44(_DAT_01eb2344,_DAT_01eb2340);
    if (DAT_01eb2348 == -1) {
      uStack_8 = 0;
      _DAT_01eb2338 = FUN_0152dab0("Render","Id_GlassTint",0xffffffff);
      _DAT_01eb2340 = FUN_0152dab0(&DAT_018fb928,"Id_GlassTint",0xffffffff);
      FUN_016f37bf(&DAT_01eb2348);
      uVar1 = _DAT_01eb2340;
    }
  }
  _DAT_01eb2340 = uVar1;
  *param_1 = _DAT_01eb2338;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11402 ; VA 0x00795420 ; FUN_00795420 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00795420(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b19ac;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb2010;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2018) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2018);
    uVar1 = CONCAT44(_DAT_01eb2014,_DAT_01eb2010);
    if (DAT_01eb2018 == -1) {
      uStack_8 = 0;
      _DAT_01eb2008 = FUN_0152dab0("Render","Id_OpaqueWithAlpha",0xffffffff);
      _DAT_01eb2010 = FUN_0152dab0(&DAT_018fb928,"Id_OpaqueWithAlpha",0xffffffff);
      FUN_016f37bf(&DAT_01eb2018);
      uVar1 = _DAT_01eb2010;
    }
  }
  _DAT_01eb2010 = uVar1;
  *param_1 = _DAT_01eb2008;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11403 ; VA 0x007954e0 ; FUN_007954e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007954e0(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b19cc;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb22c0;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb22c8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb22c8);
    uVar1 = CONCAT44(_DAT_01eb22c4,_DAT_01eb22c0);
    if (DAT_01eb22c8 == -1) {
      uStack_8 = 0;
      _DAT_01eb22b8 = FUN_0152dab0("Render","Id_OpaqueWithAlpha",0xffffffff);
      _DAT_01eb22c0 = FUN_0152dab0(&DAT_018fb928,"Id_OpaqueWithAlpha",0xffffffff);
      FUN_016f37bf(&DAT_01eb22c8);
      uVar1 = _DAT_01eb22c0;
    }
  }
  _DAT_01eb22c0 = uVar1;
  *param_1 = _DAT_01eb22b8;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11404 ; VA 0x007955a0 ; FUN_007955a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007955a0(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b19ec;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb21e0;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb21e8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb21e8);
    uVar1 = CONCAT44(_DAT_01eb21e4,_DAT_01eb21e0);
    if (DAT_01eb21e8 == -1) {
      uStack_8 = 0;
      _DAT_01eb21d8 = FUN_0152dab0("Render","Id_Opaque",0xffffffff);
      _DAT_01eb21e0 = FUN_0152dab0(&DAT_018fb928,"Id_Opaque",0xffffffff);
      FUN_016f37bf(&DAT_01eb21e8);
      uVar1 = _DAT_01eb21e0;
    }
  }
  _DAT_01eb21e0 = uVar1;
  *param_1 = _DAT_01eb21d8;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11405 ; VA 0x00795660 ; FUN_00795660 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00795660(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b1a0c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb21f8;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2200) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2200);
    uVar1 = CONCAT44(_DAT_01eb21fc,_DAT_01eb21f8);
    if (DAT_01eb2200 == -1) {
      uStack_8 = 0;
      _DAT_01eb21f0 = FUN_0152dab0("Render","Id_Terrain",0xffffffff);
      _DAT_01eb21f8 = FUN_0152dab0(&DAT_018fb928,"Id_Terrain",0xffffffff);
      FUN_016f37bf(&DAT_01eb2200);
      uVar1 = _DAT_01eb21f8;
    }
  }
  _DAT_01eb21f8 = uVar1;
  *param_1 = _DAT_01eb21f0;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11406 ; VA 0x00795720 ; FUN_00795720 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00795720(undefined8 *param_1)

{
  undefined8 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b1a2c;
  pvStack_10 = ExceptionList;
  uVar1 = _DAT_01eb20e8;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb20f0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb20f0);
    uVar1 = CONCAT44(_DAT_01eb20ec,_DAT_01eb20e8);
    if (DAT_01eb20f0 == -1) {
      uStack_8 = 0;
      _DAT_01eb20e0 = FUN_0152dab0("Render","Id_TransparentCasters",0xffffffff);
      _DAT_01eb20e8 = FUN_0152dab0(&DAT_018fb928,"Id_TransparentCasters",0xffffffff);
      FUN_016f37bf(&DAT_01eb20f0);
      uVar1 = _DAT_01eb20e8;
    }
  }
  _DAT_01eb20e8 = uVar1;
  *param_1 = _DAT_01eb20e0;
  param_1[1] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11407 ; VA 0x007957e0 ; FUN_007957e0 */

void FUN_007957e0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  if (param_1 != 0) {
    piVar2 = *(int **)(param_1 + 0xc);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = *(int **)(param_1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(param_1,0x10);
  }
  return;
}



/* FUNCTION 11408 ; VA 0x00795850 ; FUN_00795850 */

void FUN_00795850(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  if (param_1 != 0) {
    piVar2 = *(int **)(param_1 + 0x1c);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = *(int **)(param_1 + 0x14);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = *(int **)(param_1 + 0xc);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = *(int **)(param_1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(param_1,0x20);
  }
  return;
}



/* FUNCTION 11409 ; VA 0x00795910 ; FUN_00795910 */

void FUN_00795910(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  if (param_1 != 0) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(param_1 + 0x18,8,2,FUN_00550b30);
    FUN_016f32d1(param_1 + 8,8,2,FUN_00550b30);
    piVar2 = *(int **)(param_1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(param_1,0x28);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11410 ; VA 0x007959b0 ; FUN_007959b0 */

int __thiscall FUN_007959b0(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1c);
  }
  return param_1;
}



/* FUNCTION 11411 ; VA 0x00795a50 ; FUN_00795a50 */

int __thiscall FUN_00795a50(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 11412 ; VA 0x00795ac0 ; FUN_00795ac0 */

void __fastcall FUN_00795ac0(int param_1)

{
  if (*(int *)(param_1 + 0xc) != 0) {
    FUN_007959b0(1);
  }
  return;
}



/* FUNCTION 11413 ; VA 0x00795ad0 ; FUN_00795ad0 */

void __fastcall FUN_00795ad0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar2 = *(int *)(param_1 + 0xc);
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 0xc);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,0x10);
  }
  return;
}



/* FUNCTION 11414 ; VA 0x00795b40 ; FUN_00795b40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00795b40(int *param_1,int *param_2,int param_3,uint param_4)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  uint uVar5;
  float fVar6;
  undefined8 uVar7;
  undefined auStack_124 [16];
  float fStack_114;
  float fStack_110;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined2 uStack_20;
  undefined uStack_1e;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  ushort uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b1a68;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  piStack_24 = param_1;
  if (*(int *)(iVar1 + 0x34) < DAT_01eb2528) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2528);
    if (DAT_01eb2528 == -1) {
      uStack_8 = 0;
      uVar7 = FUN_0152dab0("Render","Shadow Blur",0xffffffff);
      DAT_01eb2524 = (undefined4)((ulonglong)uVar7 >> 0x20);
      DAT_01eb2520 = (undefined4)uVar7;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb2528);
    }
  }
  uStack_38 = DAT_01eb2520;
  uStack_58 = DAT_01eb2520;
  uStack_34 = DAT_01eb2524;
  uStack_54 = DAT_01eb2524;
  uStack_50 = FUN_0152d930(DAT_01eb2520,DAT_01eb2524);
  uStack_8 = 1;
  if (*(int *)(iVar1 + 0x34) < DAT_01eb2538) {
    FUN_016f3809(&DAT_01eb2538);
    if (DAT_01eb2538 == -1) {
      uStack_8._0_1_ = 2;
      uVar7 = FUN_0152dab0(&DAT_018fb928,"Shadow Blur",0xffffffff);
      DAT_01eb2534 = (undefined4)((ulonglong)uVar7 >> 0x20);
      DAT_01eb2530 = (undefined4)uVar7;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eb2538);
    }
  }
  uStack_30 = DAT_01eb2530;
  uStack_48 = DAT_01eb2530;
  uStack_2c = DAT_01eb2534;
  uStack_44 = DAT_01eb2534;
  uStack_40 = FUN_0152d930(DAT_01eb2530,DAT_01eb2534);
  uStack_1e = param_4 != 0;
  uStack_8._0_1_ = 3;
  iVar1 = *(int *)(*param_1 + 0x4ec);
  iVar2 = *(int *)(*(int *)(param_3 + 8) + 0x30);
  uStack_20 = 0;
  iStack_28 = iVar2;
  FUN_0147bca0();
  uStack_a4 = 1;
  uStack_a0 = _DAT_018e3fb0;
  uStack_9c = _UNK_018e3fb4;
  uStack_98 = _UNK_018e3fb8;
  uStack_94 = _UNK_018e3fbc;
  FUN_00829a50(iVar2,iVar2);
  uVar5 = param_4 | 1;
  fVar6 = DAT_018ce2f8 / (float)iVar2;
  fStack_114 = fVar6;
  (**(code **)(*param_2 + 0x14))(*(undefined4 *)(param_3 + 0x20),param_4,uVar5,&uStack_a4,0);
  uStack_1c._0_2_ = 0x100;
  uStack_18 = 0;
  uStack_14 = 0;
  (**(code **)(*param_2 + 0x34))(0,*(undefined4 *)(param_3 + 8),&uStack_1c);
  uStack_1c = CONCAT22(uStack_1c._2_2_,0x100);
  uStack_18 = 0;
  uStack_14 = 0;
  (**(code **)(*param_2 + 0x34))(1,*(undefined4 *)(iVar1 + 0x24),&uStack_1c);
  uStack_18 = 0x1000100;
  uStack_1c = 0xf;
  uStack_14 = uStack_14 & 0xff00;
  FUN_0082a430(param_2,*piStack_24,"PassThroughVS","ShadowBlurFS",auStack_124,&uStack_1c,&uStack_20)
  ;
  (**(code **)(*param_2 + 0x18))();
  FUN_00829a50(iStack_28,iStack_28);
  fStack_110 = fVar6;
  (**(code **)(*param_2 + 0x14))(*(undefined4 *)(param_3 + 0x18),uVar5,uVar5,0,0);
  uStack_1c._0_2_ = 0x100;
  uStack_18 = 0;
  uStack_14 = 0;
  (**(code **)(*param_2 + 0x34))(0,*(undefined4 *)(param_3 + 0x10),&uStack_1c);
  piVar3 = piStack_24;
  uStack_1c = CONCAT22(uStack_1c._2_2_,0x100);
  uStack_18 = 0;
  uStack_14 = 0;
  puVar4 = (undefined4 *)&DAT_01eb1b04;
  if ((undefined4 *)piStack_24[0x119] != (undefined4 *)0x0) {
    puVar4 = (undefined4 *)piStack_24[0x119];
  }
  (**(code **)(*param_2 + 0x34))(1,*puVar4,&uStack_1c);
  uStack_18 = 0x1000100;
  uStack_1c = 0xf;
  uStack_14 = uStack_14 & 0xff00;
  FUN_0082a430(param_2,*piVar3,"PassThroughVS","ShadowBlurFS",auStack_124,&uStack_1c,&uStack_20);
  (**(code **)(*param_2 + 0x18))();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_0152dda0(uStack_30,uStack_2c,uStack_40);
  uStack_8 = 5;
  FUN_0152dda0(uStack_38,uStack_34,uStack_50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11415 ; VA 0x00795ec0 ; FUN_00795ec0 */

undefined4 __fastcall FUN_00795ec0(int param_1)

{
  return CONCAT31((int3)((uint)*(int *)(param_1 + 0x434) >> 8),
                  *(int *)(*(int *)(param_1 + 0x434) + 0x40) == 1);
}



/* FUNCTION 11416 ; VA 0x00795ed0 ; FUN_00795ed0 */

void __fastcall FUN_00795ed0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  
  piVar1 = *(int **)(param_1 + 0x498);
  for (piVar4 = *(int **)(param_1 + 0x494); piVar4 != piVar1; piVar4 = piVar4 + 2) {
    iVar2 = *piVar4;
    if (iVar2 != 0) {
      if (DAT_01d60edc < *(int *)(iVar2 + 0x18)) {
        *piVar4 = 0;
        piVar3 = (int *)piVar4[1];
        piVar4[1] = 0;
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar2 = piVar3[1] + -1;
          piVar3[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar2 = piVar3[2] + -1;
            piVar3[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
      }
      else {
        *(int *)(iVar2 + 0x18) = *(int *)(iVar2 + 0x18) + 1;
      }
    }
  }
  return;
}



/* FUNCTION 11417 ; VA 0x00795f40 ; FUN_00795f40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __thiscall
FUN_00795f40(int param_1,int *param_2,int *param_3,float param_4,int param_5,undefined4 param_6,
            float param_7,undefined4 param_8,int param_9)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  code *pcVar5;
  undefined4 uVar6;
  undefined uVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  char *pcVar11;
  undefined4 *****pppppuVar12;
  int *piVar13;
  int iVar14;
  uint uVar15;
  undefined4 ******ppppppuVar16;
  undefined4 ******ppppppuVar17;
  uint uVar18;
  double dVar19;
  float fVar20;
  undefined8 uVar21;
  undefined auStack_17c [16];
  float fStack_16c;
  float fStack_168;
  float fStack_164;
  float fStack_160;
  float fStack_15c;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  int aiStack_104 [12];
  undefined4 *puStack_d4;
  int *piStack_d0;
  undefined2 auStack_cc [2];
  undefined4 uStack_c8;
  undefined2 uStack_c4;
  undefined2 auStack_c0 [2];
  undefined4 uStack_bc;
  undefined2 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  int iStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined8 uStack_90;
  int iStack_88;
  int iStack_84;
  undefined8 uStack_80;
  uint uStack_78;
  undefined2 auStack_74 [2];
  undefined4 uStack_70;
  undefined2 uStack_6c;
  uint uStack_68;
  int iStack_64;
  int iStack_60;
  int iStack_5c;
  int iStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined uStack_4c;
  float fStack_48;
  uint uStack_44;
  undefined2 uStack_3e;
  undefined uStack_3c;
  undefined2 uStack_3b;
  undefined uStack_39;
  int iStack_38;
  undefined4 *****apppppuStack_34 [4];
  int iStack_24;
  uint uStack_20;
  int iStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b1b1e;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  FUN_016f4053(aiStack_104 + 2,8,5,FUN_005502b0,FUN_00550b30);
  uStack_8 = 1;
  dVar19 = (double)(*(float *)(param_1 + 0x14) / DAT_018fde90);
  FUN_01727bb0();
  fStack_48 = (float)dVar19;
  dVar19 = DAT_018ce308;
  FUN_01727bb0();
  uVar8 = 2;
  if (1 < param_5) {
    uVar8 = 0;
  }
  fVar20 = fStack_48 / (float)dVar19;
  if (fStack_48 / (float)dVar19 <= DAT_018ce2f0) {
    fVar20 = DAT_018ce2f0;
  }
  fStack_48 = fVar20 + DAT_018df580;
  if (DAT_018fde88 <= fVar20 + DAT_018df580) {
    fStack_48 = DAT_018fde88;
  }
  iStack_38 = (int)fStack_48;
  uStack_44 = uVar8;
  uStack_14 = uVar8;
  if ((int)uVar8 < iStack_38) {
    piVar13 = aiStack_104 + uVar8 * 2 + 3;
    uVar18 = 0;
    do {
      uVar8 = uVar8 + 1;
      uVar9 = *(uint *)((int)param_4 + 0x30) >> ((byte)uVar8 & 0x1f);
      if (uVar9 == 0) {
        uVar9 = 1;
      }
      uVar15 = *(uint *)((int)param_4 + 0x34) >> ((byte)uVar8 & 0x1f);
      if (uVar15 == 0) {
        uVar15 = 1;
      }
      if ((char)param_8 == '\0') {
        FUN_007994e0(&iStack_5c,uVar9,uVar15,1,*(undefined4 *)((int)param_4 + 0x2c));
        iVar14 = iStack_58;
        iVar10 = iStack_5c;
        uVar18 = uVar18 | 4;
        iStack_5c = 0;
        iStack_58 = 0;
      }
      else {
        FUN_007994e0(&iStack_64,uVar9,uVar15,1,0x1c);
        iVar14 = iStack_60;
        iVar10 = iStack_64;
        uVar18 = uVar18 | 2;
        iStack_64 = 0;
        iStack_60 = 0;
      }
      piVar13[-1] = iVar10;
      uStack_18 = uVar18;
      piVar1 = (int *)*piVar13;
      *piVar13 = iVar14;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar10 = piVar1[1] + -1;
        piVar1[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar10 = piVar1[2] + -1;
          piVar1[2] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      if (piVar13[-1] == 0) {
        *param_2 = 0;
        param_2[1] = 0;
        goto LAB_00796c10;
      }
      uStack_14 = uStack_14 + 1;
      piVar13 = piVar13 + 2;
      param_1 = iStack_1c;
      uVar18 = uStack_18;
    } while ((int)uStack_14 < iStack_38);
  }
  iVar10 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  iStack_60 = iVar10;
  if ((*(int *)(iVar10 + 0x34) < DAT_01eb1d58) && (FUN_016f3809(&DAT_01eb1d58), DAT_01eb1d58 == -1))
  {
    uStack_8._0_1_ = 2;
    uVar21 = FUN_0152dab0("Render","DownSample",0xffffffff);
    DAT_01eb1d54 = (undefined4)((ulonglong)uVar21 >> 0x20);
    DAT_01eb1d50 = (undefined4)uVar21;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_016f37bf(&DAT_01eb1d58);
  }
  iStack_58 = DAT_01eb1d50;
  uStack_b4 = DAT_01eb1d54;
  uStack_98 = DAT_01eb1d50;
  uStack_94 = DAT_01eb1d54;
  uStack_90 = FUN_0152d930(DAT_01eb1d50,DAT_01eb1d54);
  uStack_8._0_1_ = 3;
  if (*(int *)(iVar10 + 0x34) < DAT_01eb1d68) {
    FUN_016f3809(&DAT_01eb1d68);
    if (DAT_01eb1d68 == -1) {
      uStack_8._0_1_ = 4;
      uVar21 = FUN_0152dab0(&DAT_018fb928,"DownSample",0xffffffff);
      DAT_01eb1d64 = (undefined4)((ulonglong)uVar21 >> 0x20);
      DAT_01eb1d60 = (undefined4)uVar21;
      uStack_8._0_1_ = 3;
      FUN_016f37bf(&DAT_01eb1d68);
    }
  }
  uStack_b0 = DAT_01eb1d60;
  uStack_ac = DAT_01eb1d64;
  iStack_88 = DAT_01eb1d60;
  iStack_84 = DAT_01eb1d64;
  uStack_80 = FUN_0152d930(DAT_01eb1d60,DAT_01eb1d64);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (*(int *)(iVar10 + 0x34) < DAT_01eb1df0) {
    FUN_016f3809(&DAT_01eb1df0);
    if (DAT_01eb1df0 == -1) {
      _DAT_01eb1d70 = _DAT_018fdec0;
      _DAT_01eb1d74 = _UNK_018fdec4;
      uRam01eb1d78 = _UNK_018fdec8;
      uRam01eb1d7c = _UNK_018fdecc;
      _DAT_01eb1d80 = _DAT_018fdef0;
      uRam01eb1d84 = _UNK_018fdef4;
      uRam01eb1d88 = _UNK_018fdef8;
      uRam01eb1d8c = _UNK_018fdefc;
      _DAT_01eb1d90 = _DAT_018fdf10;
      uRam01eb1d94 = _UNK_018fdf14;
      uRam01eb1d98 = _UNK_018fdf18;
      uRam01eb1d9c = _UNK_018fdf1c;
      _DAT_01eb1da0 = _DAT_018fdf30;
      uRam01eb1da4 = _UNK_018fdf34;
      uRam01eb1da8 = _UNK_018fdf38;
      uRam01eb1dac = _UNK_018fdf3c;
      _DAT_01eb1db0 = _DAT_018fdee0;
      uRam01eb1db4 = _UNK_018fdee4;
      uRam01eb1db8 = _UNK_018fdee8;
      uRam01eb1dbc = _UNK_018fdeec;
      _DAT_01eb1dc0 = _DAT_018fdf00;
      uRam01eb1dc4 = _UNK_018fdf04;
      uRam01eb1dc8 = _UNK_018fdf08;
      uRam01eb1dcc = _UNK_018fdf0c;
      _DAT_01eb1dd0 = _DAT_018fdf20;
      uRam01eb1dd4 = _UNK_018fdf24;
      uRam01eb1dd8 = _UNK_018fdf28;
      uRam01eb1ddc = _UNK_018fdf2c;
      _DAT_01eb1de0 = _DAT_018fdf40;
      uRam01eb1de4 = _UNK_018fdf44;
      uRam01eb1de8 = _UNK_018fdf48;
      uRam01eb1dec = _UNK_018fdf4c;
      FUN_016f37bf(&DAT_01eb1df0);
    }
  }
  uStack_78 = uStack_44;
  if ((int)uStack_44 < iStack_38) {
    iStack_a8 = uStack_44 + 1;
    uVar8 = uStack_44;
    do {
      uVar18 = uStack_44;
      uStack_68 = *(uint *)(aiStack_104[uVar8 * 2 + 2] + 8);
      uStack_14 = (uint)param_4;
      if (uVar8 != uStack_44) {
        uStack_14 = *(uint *)aiStack_104[uVar8 * 2];
      }
      uStack_78 = uVar8;
      FUN_00829d10(*(uint *)(aiStack_104[uVar8 * 2 + 2] + 8));
      iVar10 = iStack_1c;
      uStack_10c = *(undefined4 *)(param_1 + 0x10);
      uStack_108 = *(undefined4 *)(param_1 + 0x18);
      if ((param_5 < 2) && (uVar8 == uVar18)) {
        uStack_68 = *(uint *)((int)param_4 + 0x30) >> ((byte)iStack_a8 & 0x1f);
        if (uStack_68 == 0) {
          uStack_68 = 1;
        }
        uVar8 = *(uint *)((int)param_4 + 0x34) >> ((byte)iStack_a8 & 0x1f);
        if (uVar8 == 0) {
          uVar8 = 1;
        }
        FUN_007a1d80(param_3,uStack_68,uVar8);
        uVar18 = *(uint *)(iVar10 + 0x2c) & 0x8000000f;
        if ((int)uVar18 < 0) {
          uVar18 = (uVar18 - 1 | 0xfffffff0) + 1;
        }
        fStack_16c = *(float *)(&DAT_01eb1d70 + uVar18 * 8) /
                     (float)((double)*(int *)((int)param_4 + 0x30) +
                            (double)(&DAT_018c0d90)[-(*(int *)((int)param_4 + 0x30) >> 0x1f)]);
        fStack_168 = *(float *)(&DAT_01eb1d74 + uVar18 * 8) /
                     (float)((double)*(int *)((int)param_4 + 0x34) +
                            (double)(&DAT_018c0d90)[-(*(int *)((int)param_4 + 0x34) >> 0x1f)]);
        fVar20 = (DAT_018ce2f8 - param_7) * _DAT_018fde60 + DAT_018f994c;
        fStack_164 = DAT_018fde74;
        if (fVar20 <= DAT_018fde74) {
          fStack_164 = fVar20;
        }
        uVar9 = *(int *)(iVar10 + 0x28) - 1U & 1;
        fStack_160 = (float)(int)uVar18 + DAT_018ce2f4;
        uVar2 = **(undefined4 **)(iVar10 + 0x20 + *(int *)(iVar10 + 0x28) * 4);
        (**(code **)(*param_3 + 0x14))
                  (*(undefined4 *)(*(int *)(iVar10 + 0x20 + uVar9 * 4) + 8),0,1,0,0);
        auStack_c0[0] = 0x101;
        uStack_bc = 0;
        uStack_b8 = 0;
        (**(code **)(*param_3 + 0x34))(0,uStack_14,auStack_c0);
        auStack_cc[0] = 0x101;
        uStack_c8 = 0;
        uStack_c4 = 0;
        (**(code **)(*param_3 + 0x34))(1,uVar2,auStack_cc);
        pcVar11 = "DownSampleGlowTemporalLinear8x8FS";
        uStack_3b = 0;
        if ((char)param_8 == '\0') {
          pcVar11 = "DownSampleGlowTemporal8x8FS";
        }
        uStack_39 = 0;
        uStack_a0 = 0x1000100;
        uStack_a4 = 0xf;
        uStack_9c = 0;
        FUN_0082a430(param_3,*(undefined4 *)(iStack_1c + 0x1c),"PassThroughVS",pcVar11,auStack_17c,
                     &uStack_a4,&uStack_3b);
        (**(code **)(*param_3 + 0x18))();
        FUN_007994e0(&puStack_d4,uStack_68,uVar8,1,3);
        param_1 = iStack_1c;
        uStack_18 = uStack_18 | 8;
        uStack_8._0_1_ = 6;
        FUN_0082a540(param_3,*(undefined4 *)(iStack_1c + 0x1c),
                     **(undefined4 **)(iStack_1c + 0x20 + uVar9 * 4),
                     *(undefined4 *)(aiStack_104[uStack_44 * 2 + 2] + 8),*puStack_d4,puStack_d4[2],
                     0x3f800000,0x41200000);
        piVar13 = piStack_d0;
        *(int *)(param_1 + 0x2c) = *(int *)(param_1 + 0x2c) + 1;
        *(uint *)(param_1 + 0x28) = *(int *)(param_1 + 0x28) - 1U & 1;
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
        if (piStack_d0 != (int *)0x0) {
          LOCK();
          iVar10 = piStack_d0[1] + -1;
          piStack_d0[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piStack_d0)();
            LOCK();
            piVar1 = piVar13 + 2;
            iVar10 = *piVar1 + -1;
            *piVar1 = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar13 + 4))();
            }
          }
        }
      }
      else {
        (**(code **)(*param_3 + 0x14))(uStack_68,0,1,0,0);
        auStack_74[0] = 0x101;
        uStack_70 = 0;
        uStack_6c = 0;
        (**(code **)(*param_3 + 0x34))(0,uStack_14,auStack_74);
        iStack_24 = 0;
        uStack_20 = 0xf;
        apppppuStack_34[0] = (undefined4 *****)((uint)apppppuStack_34[0] & 0xffffff00);
        FUN_005542c0("DownSampleGjoel",0xf);
        iVar10 = iStack_24;
        uStack_8 = CONCAT31(uStack_8._1_3_,7);
        if ((int)uVar18 < (int)uVar8) {
          uStack_14 = uStack_20;
          if (uStack_20 - iStack_24 < 3) {
            if (0x7fffffffU - iStack_24 < 3) goto LAB_00796e28;
            uVar8 = iStack_24 + 3U | 0xf;
            if (uVar8 < 0x80000000) {
              if (0x7fffffff - (uStack_20 >> 1) < uStack_20) {
                uVar8 = 0x7fffffff;
              }
              else {
                uVar18 = uStack_20 + (uStack_20 >> 1);
                if (uVar8 < uVar18) {
                  uVar8 = uVar18;
                }
              }
            }
            else {
              uVar8 = 0x7fffffff;
            }
            uVar18 = uVar8 + 1;
            if (uVar18 < 0x1000) {
              if (uVar18 == 0) {
                ppppppuVar17 = (undefined4 ******)0x0;
              }
              else {
                ppppppuVar17 = (undefined4 ******)FUN_01674e20(uVar18);
              }
            }
            else {
              uVar9 = uVar8 + 0x24;
              if (uVar9 <= uVar18) {
                uVar9 = 0xffffffff;
              }
              pppppuVar12 = (undefined4 *****)FUN_01674e20(uVar9);
              if (pppppuVar12 == (undefined4 *****)0x0) goto LAB_00796e23;
              ppppppuVar17 = (undefined4 ******)((int)pppppuVar12 + 0x23U & 0xffffffe0);
              ppppppuVar17[-1] = pppppuVar12;
            }
            pppppuVar12 = apppppuStack_34[0];
            iStack_24 = iVar10 + 3;
            uStack_20 = uVar8;
            if (uStack_14 < 0x10) {
              FUN_0170c6f0(ppppppuVar17,apppppuStack_34,iVar10);
              *(undefined2 *)((int)ppppppuVar17 + iVar10) = DAT_018fd758;
              *(undefined *)((int)ppppppuVar17 + iVar10 + 2) = DAT_018fd75a;
              *(undefined *)((int)ppppppuVar17 + iVar10 + 3) = 0;
              apppppuStack_34[0] = ppppppuVar17;
            }
            else {
              FUN_0170c6f0(ppppppuVar17,apppppuStack_34[0],iVar10);
              *(undefined2 *)((int)ppppppuVar17 + iVar10) = DAT_018fd758;
              uVar8 = uStack_14 + 1;
              *(undefined *)((int)ppppppuVar17 + iVar10 + 2) = DAT_018fd75a;
              *(undefined *)((int)ppppppuVar17 + iVar10 + 3) = 0;
              ppppppuVar16 = (undefined4 ******)pppppuVar12;
              if (0xfff < uVar8) {
                ppppppuVar16 = (undefined4 ******)pppppuVar12[-1];
                uVar8 = uStack_14 + 0x24;
                if (0x1f < (uint)((int)pppppuVar12 + (-4 - (int)ppppppuVar16))) goto LAB_00796e23;
              }
              FUN_01674ea0(ppppppuVar16,uVar8);
              apppppuStack_34[0] = ppppppuVar17;
            }
          }
          else {
            ppppppuVar17 = apppppuStack_34;
            if (0xf < uStack_20) {
              ppppppuVar17 = (undefined4 ******)apppppuStack_34[0];
            }
            iVar10 = (int)ppppppuVar17 + iStack_24;
            iStack_24 = iStack_24 + 3;
            FUN_0170cc70(iVar10,&DAT_018fd758,3);
            *(undefined *)(iVar10 + 3) = 0;
          }
        }
        else if ((char)param_8 != '\0') {
          uStack_14 = uStack_20;
          if (uStack_20 - iStack_24 < 6) {
            if (0x7fffffffU - iStack_24 < 6) goto LAB_00796e28;
            uVar8 = iStack_24 + 6U | 0xf;
            if (uVar8 < 0x80000000) {
              if (0x7fffffff - (uStack_20 >> 1) < uStack_20) {
                uVar8 = 0x7fffffff;
              }
              else {
                uVar18 = (uStack_20 >> 1) + uStack_20;
                if (uVar8 < uVar18) {
                  uVar8 = uVar18;
                }
              }
            }
            else {
              uVar8 = 0x7fffffff;
            }
            uVar18 = uVar8 + 1;
            if (uVar18 < 0x1000) {
              if (uVar18 == 0) {
                ppppppuVar17 = (undefined4 ******)0x0;
              }
              else {
                ppppppuVar17 = (undefined4 ******)FUN_01674e20(uVar18);
              }
            }
            else {
              uVar9 = uVar8 + 0x24;
              if (uVar9 <= uVar18) {
                uVar9 = 0xffffffff;
              }
              pppppuVar12 = (undefined4 *****)FUN_01674e20(uVar9);
              if (pppppuVar12 == (undefined4 *****)0x0) goto LAB_00796e23;
              ppppppuVar17 = (undefined4 ******)((int)pppppuVar12 + 0x23U & 0xffffffe0);
              ppppppuVar17[-1] = pppppuVar12;
            }
            pppppuVar12 = apppppuStack_34[0];
            iStack_24 = iVar10 + 6;
            uStack_20 = uVar8;
            if (uStack_14 < 0x10) {
              FUN_0170c6f0(ppppppuVar17,apppppuStack_34,iVar10);
              *(undefined4 *)((int)ppppppuVar17 + iVar10) = DAT_018fd75c;
              *(undefined2 *)((int)ppppppuVar17 + iVar10 + 4) = DAT_018fd760;
              *(undefined *)((int)ppppppuVar17 + iVar10 + 6) = 0;
              apppppuStack_34[0] = ppppppuVar17;
            }
            else {
              FUN_0170c6f0(ppppppuVar17,apppppuStack_34[0],iVar10);
              *(undefined4 *)((int)ppppppuVar17 + iVar10) = DAT_018fd75c;
              uVar8 = uStack_14 + 1;
              *(undefined2 *)((int)ppppppuVar17 + iVar10 + 4) = DAT_018fd760;
              *(undefined *)((int)ppppppuVar17 + iVar10 + 6) = 0;
              ppppppuVar16 = (undefined4 ******)pppppuVar12;
              if (0xfff < uVar8) {
                ppppppuVar16 = (undefined4 ******)pppppuVar12[-1];
                uVar8 = uStack_14 + 0x24;
                if (0x1f < (uint)((int)pppppuVar12 + (-4 - (int)ppppppuVar16))) goto LAB_00796e23;
              }
              FUN_01674ea0(ppppppuVar16,uVar8);
              apppppuStack_34[0] = ppppppuVar17;
            }
          }
          else {
            ppppppuVar17 = apppppuStack_34;
            if (0xf < uStack_20) {
              ppppppuVar17 = (undefined4 ******)apppppuStack_34[0];
            }
            iVar10 = (int)ppppppuVar17 + iStack_24;
            iStack_24 = iStack_24 + 6;
            FUN_0170cc70(iVar10,&DAT_018fd75c,6);
            *(undefined *)(iVar10 + 6) = 0;
          }
        }
        iVar10 = iStack_24;
        uStack_14 = uStack_20;
        if (uStack_20 - iStack_24 < 2) {
          if (0x7fffffffU - iStack_24 < 2) {
LAB_00796e28:
            uStack_20 = uStack_14;
            FUN_00554040();
            pcVar5 = (code *)swi(3);
            piVar13 = (int *)(*pcVar5)();
            return piVar13;
          }
          uVar8 = iStack_24 + 2U | 0xf;
          if (uVar8 < 0x80000000) {
            if (0x7fffffff - (uStack_20 >> 1) < uStack_20) {
              uVar8 = 0x7fffffff;
            }
            else {
              uVar18 = (uStack_20 >> 1) + uStack_20;
              if (uVar8 < uVar18) {
                uVar8 = uVar18;
              }
            }
          }
          else {
            uVar8 = 0x7fffffff;
          }
          uVar18 = uVar8 + 1;
          if (uVar18 < 0x1000) {
            if (uVar18 == 0) {
              ppppppuVar17 = (undefined4 ******)0x0;
            }
            else {
              ppppppuVar17 = (undefined4 ******)FUN_01674e20(uVar18);
            }
          }
          else {
            uVar9 = uVar8 + 0x24;
            if (uVar9 <= uVar18) {
              uVar9 = 0xffffffff;
            }
            pppppuVar12 = (undefined4 *****)FUN_01674e20(uVar9);
            if (pppppuVar12 == (undefined4 *****)0x0) goto LAB_00796e23;
            ppppppuVar17 = (undefined4 ******)((int)pppppuVar12 + 0x23U & 0xffffffe0);
            ppppppuVar17[-1] = pppppuVar12;
          }
          pppppuVar12 = apppppuStack_34[0];
          iStack_24 = iVar10 + 2;
          uStack_20 = uVar8;
          if (uStack_14 < 0x10) {
            FUN_0170c6f0(ppppppuVar17,apppppuStack_34,iVar10);
            *(undefined2 *)(iVar10 + (int)ppppppuVar17) = DAT_018fd764;
            *(undefined *)(iVar10 + 2 + (int)ppppppuVar17) = 0;
            apppppuStack_34[0] = ppppppuVar17;
          }
          else {
            FUN_0170c6f0(ppppppuVar17,apppppuStack_34[0],iVar10);
            uVar8 = uStack_14 + 1;
            *(undefined2 *)(iVar10 + (int)ppppppuVar17) = DAT_018fd764;
            *(undefined *)(iVar10 + 2 + (int)ppppppuVar17) = 0;
            ppppppuVar16 = (undefined4 ******)pppppuVar12;
            if (0xfff < uVar8) {
              ppppppuVar16 = (undefined4 ******)pppppuVar12[-1];
              uVar8 = uStack_14 + 0x24;
              if (0x1f < (uint)((int)pppppuVar12 + (-4 - (int)ppppppuVar16))) goto LAB_00796e23;
            }
            FUN_01674ea0(ppppppuVar16,uVar8);
            apppppuStack_34[0] = ppppppuVar17;
          }
        }
        else {
          ppppppuVar17 = apppppuStack_34;
          if (0xf < uStack_20) {
            ppppppuVar17 = (undefined4 ******)apppppuStack_34[0];
          }
          iVar10 = (int)ppppppuVar17 + iStack_24;
          iStack_24 = iStack_24 + 2;
          FUN_0170cc70(iVar10,&DAT_018fd764,2);
          *(undefined *)(iVar10 + 2) = 0;
        }
        uStack_3e = 0;
        uStack_3c = 0;
        ppppppuVar17 = apppppuStack_34;
        if (0xf < uStack_20) {
          ppppppuVar17 = (undefined4 ******)apppppuStack_34[0];
        }
        uStack_50 = 0x1000100;
        uStack_54 = 0xf;
        uStack_4c = 0;
        FUN_0082a430(param_3,*(undefined4 *)(iStack_1c + 0x1c),"DownSampleGjoel8UVVS",ppppppuVar17,
                     auStack_17c,&uStack_54,&uStack_3e);
        (**(code **)(*param_3 + 0x18))();
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
        param_1 = iStack_1c;
        if (0xf < uStack_20) {
          uVar8 = uStack_20 + 1;
          ppppppuVar17 = (undefined4 ******)apppppuStack_34[0];
          if (0xfff < uVar8) {
            ppppppuVar17 = (undefined4 ******)apppppuStack_34[0][-1];
            uVar8 = uStack_20 + 0x24;
            if (0x1f < (uint)((int)apppppuStack_34[0] + (-4 - (int)ppppppuVar17))) {
LAB_00796e23:
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(ppppppuVar17,uVar8);
          param_1 = iStack_1c;
        }
      }
      uVar8 = uStack_78 + 1;
      uStack_78 = uVar8;
    } while ((int)uVar8 < iStack_38);
  }
  uVar8 = uStack_44;
  uStack_8._0_1_ = 8;
  FUN_0152dda0(uStack_b0,uStack_ac,uStack_80);
  uStack_8._0_1_ = 9;
  FUN_0152dda0(iStack_58,uStack_b4,uStack_90);
  iVar10 = iStack_60;
  uStack_8._0_1_ = 1;
  uVar7 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (*(int *)(iStack_60 + 0x34) < DAT_01eb1e00) {
    uStack_8._0_1_ = uVar7;
    FUN_016f3809(&DAT_01eb1e00);
    if (DAT_01eb1e00 == -1) {
      uStack_8._0_1_ = 10;
      uVar21 = FUN_0152dab0("Render","UpSample",0xffffffff);
      DAT_01eb1dfc = (int)((ulonglong)uVar21 >> 0x20);
      DAT_01eb1df8 = (int)uVar21;
      uStack_8._0_1_ = 1;
      FUN_016f37bf(&DAT_01eb1e00);
    }
  }
  iStack_58 = DAT_01eb1df8;
  iStack_60 = DAT_01eb1dfc;
  iStack_88 = DAT_01eb1df8;
  iStack_84 = DAT_01eb1dfc;
  uVar21 = FUN_0152d930(DAT_01eb1df8,DAT_01eb1dfc);
  uStack_8._0_1_ = 0xb;
  uVar7 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xb;
  uStack_80 = uVar21;
  if (*(int *)(iVar10 + 0x34) < DAT_01eb1e10) {
    uStack_8._0_1_ = uVar7;
    FUN_016f3809(&DAT_01eb1e10);
    if (DAT_01eb1e10 == -1) {
      uStack_8._0_1_ = 0xc;
      uVar21 = FUN_0152dab0(&DAT_018fb928,"UpSample",0xffffffff);
      DAT_01eb1e0c = (undefined4)((ulonglong)uVar21 >> 0x20);
      DAT_01eb1e08 = (undefined4)uVar21;
      uStack_8._0_1_ = 0xb;
      FUN_016f37bf(&DAT_01eb1e10);
    }
  }
  uVar6 = DAT_01eb1e0c;
  uVar2 = DAT_01eb1e08;
  uStack_98 = DAT_01eb1e08;
  uStack_94 = DAT_01eb1e0c;
  uVar21 = FUN_0152d930(DAT_01eb1e08,DAT_01eb1e0c);
  uStack_90 = uVar21;
  uStack_8._0_1_ = 0xd;
  param_4 = DAT_018ce2f8;
  if (param_9 == 2) {
    param_4 = *(float *)(param_1 + 4) / fStack_48;
  }
  for (uVar18 = iStack_38 - 2; (int)uVar8 <= (int)uVar18; uVar18 = uVar18 - 1) {
    uVar3 = *(undefined4 *)(aiStack_104[uVar18 * 2 + 2] + 8);
    uVar4 = *(undefined4 *)aiStack_104[uVar18 * 2 + 4];
    FUN_00829d10(uVar3);
    fStack_15c = DAT_018ce2f8;
    if (uVar18 == iStack_38 - 2U) {
      fStack_15c = fStack_48 - (float)iStack_38;
    }
    if (uVar18 == uVar8) {
      fStack_15c = fStack_15c * param_4;
    }
    (**(code **)(*param_3 + 0x14))(uVar3,1,1,0,0);
    auStack_74[0] = 0x101;
    uStack_70 = 0;
    uStack_6c = 0;
    (**(code **)(*param_3 + 0x34))(0,uVar4,auStack_74);
    param_8._1_2_ = 0;
    param_8._3_1_ = 0;
    uStack_50 = 0;
    uStack_54 = 0xf;
    uStack_4c = 0;
    FUN_0082a430(param_3,*(undefined4 *)(iStack_1c + 0x1c),"PassThroughVS","UpSampleTentFS",
                 auStack_17c,&uStack_54,(int)&param_8 + 1);
    (**(code **)(*param_3 + 0x18))();
  }
  uStack_8._0_1_ = 0xe;
  FUN_0152dda0(uVar2,uVar6,uStack_90);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  FUN_0152dda0(iStack_58,iStack_60,uStack_80);
  iVar10 = aiStack_104[uVar8 * 2 + 3];
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar10 != 0) {
    LOCK();
    *(int *)(iVar10 + 4) = *(int *)(iVar10 + 4) + 1;
    UNLOCK();
    iVar10 = aiStack_104[uVar8 * 2 + 3];
  }
  *param_2 = aiStack_104[uVar8 * 2 + 2];
  param_2[1] = iVar10;
LAB_00796c10:
  uStack_18 = uStack_18 | 1;
  uStack_8 = uStack_8 & 0xffffff00;
  FUN_016f32d1(aiStack_104 + 2,8,5,FUN_00550b30);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 11418 ; VA 0x00796e30 ; FUN_00796e30 */

undefined4 *
FUN_00796e30(undefined4 *param_1,int *param_2,int param_3,uint param_4,int param_5,float *param_6)

{
  int *piVar1;
  int iVar2;
  uint3 uVar3;
  undefined4 uVar4;
  float *pfVar5;
  int *piVar6;
  undefined uVar7;
  char cVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  uint uVar11;
  uint uVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  undefined8 uVar16;
  undefined auStack_1d4 [64];
  undefined4 auStack_194 [3];
  undefined4 uStack_188;
  undefined4 uStack_180;
  uint uStack_178;
  undefined auStack_154 [16];
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  float fStack_134;
  float fStack_130;
  float fStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  uint uStack_108;
  float fStack_d4;
  float fStack_d0;
  float fStack_cc;
  undefined4 uStack_c8;
  float fStack_c4;
  float fStack_c0;
  float fStack_bc;
  undefined4 uStack_b8;
  float fStack_b4;
  float fStack_b0;
  float fStack_ac;
  undefined4 uStack_a8;
  float fStack_a4;
  float fStack_a0;
  float fStack_9c;
  float fStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  uint uStack_6c;
  undefined8 uStack_68;
  float fStack_60;
  uint uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  int *piStack_48;
  undefined4 *puStack_44;
  int *piStack_40;
  undefined4 *puStack_3c;
  float fStack_38;
  undefined4 *puStack_34;
  float fStack_30;
  float fStack_2c;
  undefined8 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b1bd4;
  pvStack_10 = ExceptionList;
  uStack_50 = 0;
  uVar12 = *(uint *)(param_3 + 0x30) >> 2;
  if (uVar12 == 0) {
    uVar12 = 1;
  }
  uVar11 = *(uint *)(param_3 + 0x34) >> 2;
  if (uVar11 == 0) {
    uVar11 = 1;
  }
  ExceptionList = &pvStack_10;
  uStack_5c = uVar11;
  FUN_016f4053(&puStack_4c,8,2,FUN_005502b0,FUN_00550b30);
  uStack_8 = 1;
  cVar8 = FUN_009d7ef0(param_5);
  param_5 = 3;
  if (cVar8 != '\0') {
    param_5 = 0x1c;
  }
  FUN_007994e0(&puStack_3c,uVar12,uVar11,1,param_5);
  piVar6 = piStack_48;
  puStack_4c = puStack_3c;
  uStack_50 = 2;
  piStack_48 = (int *)fStack_38;
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar2 = piVar6[1] + -1;
    piVar6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      iVar2 = piVar6[2] + -1;
      piVar6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  FUN_007994e0(&puStack_3c,uVar12,uStack_5c,1,param_5);
  piVar6 = piStack_40;
  puStack_44 = puStack_3c;
  uStack_50 = 6;
  piStack_40 = (int *)fStack_38;
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar2 = piVar6[1] + -1;
    piVar6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  if ((puStack_4c == (undefined4 *)0x0) || (puStack_44 == (undefined4 *)0x0)) {
    *param_1 = 0;
    param_1[1] = 0;
  }
  else {
    iVar2 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    param_5 = iVar2;
    if (*(int *)(iVar2 + 0x34) < DAT_01eb1e60) {
      FUN_016f3809(&DAT_01eb1e60);
      if (DAT_01eb1e60 == -1) {
        uStack_8._0_1_ = 2;
        uVar16 = FUN_0152dab0("Render","SunRaysDownSample",0xffffffff);
        DAT_01eb1e5c = (undefined4)((ulonglong)uVar16 >> 0x20);
        DAT_01eb1e58 = (float)uVar16;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_016f37bf(&DAT_01eb1e60);
      }
    }
    fStack_38 = DAT_01eb1e58;
    fStack_60 = (float)DAT_01eb1e5c;
    fStack_30 = DAT_01eb1e58;
    fStack_2c = (float)DAT_01eb1e5c;
    uStack_28 = FUN_0152d930(DAT_01eb1e58,DAT_01eb1e5c);
    uStack_8._0_1_ = 3;
    if (*(int *)(iVar2 + 0x34) < DAT_01eb1e70) {
      FUN_016f3809(&DAT_01eb1e70);
      if (DAT_01eb1e70 == -1) {
        uStack_8._0_1_ = 4;
        uVar16 = FUN_0152dab0(&DAT_018fb928,"SunRaysDownSample",0xffffffff);
        DAT_01eb1e6c = (uint)((ulonglong)uVar16 >> 0x20);
        DAT_01eb1e68 = (undefined4)uVar16;
        uStack_8._0_1_ = 3;
        FUN_016f37bf(&DAT_01eb1e70);
      }
    }
    uStack_74 = DAT_01eb1e68;
    uStack_5c = DAT_01eb1e6c;
    uStack_70 = DAT_01eb1e68;
    uStack_6c = DAT_01eb1e6c;
    uVar16 = FUN_0152d930(DAT_01eb1e68,DAT_01eb1e6c);
    uStack_8._0_1_ = 5;
    uStack_68 = uVar16;
    FUN_00829d10(puStack_4c[2]);
    (**(code **)(*param_2 + 0x14))(puStack_4c[2],0,1,0,0);
    uStack_1c = CONCAT22(uStack_1c._2_2_,0x101);
    uStack_18 = 0;
    uStack_14 = (uint)uStack_14._2_2_ << 0x10;
    (**(code **)(*param_2 + 0x34))(0,param_3,&uStack_1c);
    uVar3 = (uint3)param_4;
    param_4 = (uint)(uVar3 & 0xff);
    uStack_18 = 0x1000100;
    uStack_1c = 0xf;
    uStack_14 = uStack_14 & 0xffffff00;
    FUN_0082a430(param_2,*puStack_34,"DownSample4x4VS","DownSample4x4MaxFS",auStack_154,&uStack_1c,
                 (int)&param_4 + 1);
    (**(code **)(*param_2 + 0x18))();
    uStack_8._0_1_ = 6;
    FUN_0152dda0(uStack_74,uStack_5c,uVar16);
    uStack_8._0_1_ = 7;
    FUN_0152dda0(fStack_38,fStack_60,uStack_28);
    puVar10 = puStack_34;
    pfVar5 = param_6;
    uStack_8._0_1_ = 1;
    uStack_28._4_4_ = 0x3f800000;
    fStack_30 = *param_6 + (float)puStack_34[1];
    fStack_2c = (float)puStack_34[2] + param_6[1];
    uStack_28._0_4_ = (float)puStack_34[3] + param_6[2];
    FUN_01165b90(&uStack_84,&fStack_30);
    FUN_01126580(&uStack_58);
    FUN_01163140(uStack_78);
    uStack_28._4_4_ = 0x3f800000;
    fStack_30 = (float)puVar10[1] + *pfVar5;
    fStack_2c = (float)puVar10[2] + pfVar5[1];
    uStack_28._0_4_ = (float)puVar10[3] + pfVar5[2];
    FUN_01165b90(&uStack_94,&fStack_30);
    fStack_d4 = pfVar5[7];
    fStack_d0 = pfVar5[8];
    fStack_cc = pfVar5[9];
    uStack_c8 = 0;
    fStack_c4 = pfVar5[0xb];
    fStack_c0 = pfVar5[0xc];
    fStack_bc = pfVar5[0xd];
    uStack_b8 = 0;
    fStack_b4 = pfVar5[0xf];
    fStack_b0 = pfVar5[0x10];
    fStack_ac = pfVar5[0x11];
    uStack_a8 = 0;
    fStack_a4 = pfVar5[0x13];
    fStack_a0 = pfVar5[0x14];
    fStack_9c = pfVar5[0x15];
    fStack_98 = pfVar5[0x16];
    FUN_01165af0(auStack_1d4,&fStack_d4);
    fStack_30 = (float)puVar10[1];
    fStack_2c = (float)puVar10[2];
    uStack_28._0_4_ = (float)puVar10[3];
    uStack_28._4_4_ = 0x3f800000;
    puVar9 = (undefined4 *)FUN_01165b90(&uStack_70,&fStack_30);
    uStack_84 = *puVar9;
    uStack_80 = puVar9[1];
    uStack_7c = puVar9[2];
    uStack_78 = puVar9[3];
    puVar9 = (undefined4 *)FUN_01126580(&puStack_3c);
    uStack_58 = *puVar9;
    uStack_54 = puVar9[1];
    FUN_01163140(uStack_78);
    fStack_30 = (float)puVar10[1];
    fStack_2c = (float)puVar10[2];
    uStack_28._0_4_ = (float)puVar10[3];
    uStack_28._4_4_ = 0x3f800000;
    puVar10 = (undefined4 *)FUN_01165b90(&uStack_70,&fStack_30);
    uStack_94 = *puVar10;
    uStack_90 = puVar10[1];
    uStack_8c = puVar10[2];
    uStack_88 = puVar10[3];
    FUN_01165e00(auStack_194);
    iVar2 = param_5;
    if (*(int *)(param_5 + 0x34) < DAT_01eb1e80) {
      FUN_016f3809(&DAT_01eb1e80);
      if (DAT_01eb1e80 == -1) {
        uStack_8._0_1_ = 8;
        uVar16 = FUN_0152dab0("Render","SunRaysCompute",0xffffffff);
        DAT_01eb1e7c = (undefined4)((ulonglong)uVar16 >> 0x20);
        DAT_01eb1e78 = (float)uVar16;
        uStack_8._0_1_ = 1;
        FUN_016f37bf(&DAT_01eb1e80);
      }
    }
    fStack_60 = DAT_01eb1e78;
    fStack_38 = (float)DAT_01eb1e7c;
    fStack_30 = DAT_01eb1e78;
    fStack_2c = (float)DAT_01eb1e7c;
    uStack_28 = FUN_0152d930(DAT_01eb1e78,DAT_01eb1e7c);
    uStack_8._0_1_ = 9;
    if (*(int *)(iVar2 + 0x34) < DAT_01eb1e90) {
      FUN_016f3809(&DAT_01eb1e90);
      if (DAT_01eb1e90 == -1) {
        uStack_8._0_1_ = 10;
        uVar16 = FUN_0152dab0(&DAT_018fb928,"SunRaysCompute",0xffffffff);
        DAT_01eb1e8c = (undefined4)((ulonglong)uVar16 >> 0x20);
        DAT_01eb1e88 = (undefined4)uVar16;
        uStack_8._0_1_ = 9;
        FUN_016f37bf(&DAT_01eb1e90);
      }
    }
    uVar4 = DAT_01eb1e88;
    param_4 = DAT_01eb1e8c;
    uStack_70 = DAT_01eb1e88;
    uStack_6c = DAT_01eb1e8c;
    uVar16 = FUN_0152d930(DAT_01eb1e88,DAT_01eb1e8c);
    uStack_8._0_1_ = 0xb;
    uStack_68 = uVar16;
    FUN_00829d10(puStack_44[2]);
    fStack_130 = (float)puStack_34[6];
    uStack_144 = uStack_58;
    uStack_140 = uStack_54;
    uStack_13c = uStack_94;
    uStack_138 = uStack_90;
    fStack_12c = fStack_130 * fStack_130;
    fVar13 = 0.0;
    if (0.0 <= (float)puStack_34[2] * DAT_018fde94) {
      fVar13 = (float)puStack_34[2] * DAT_018fde94;
    }
    fVar15 = DAT_018ce2f8;
    if (fVar13 <= DAT_018ce2f8) {
      fVar15 = fVar13;
    }
    fVar14 = (float)puStack_34[2] * param_6[5] + (float)puStack_34[1] * param_6[4] +
             (float)puStack_34[3] * param_6[6];
    fVar13 = 0.0;
    if (0.0 <= fVar14) {
      fVar13 = fVar14;
    }
    uStack_120 = puStack_34[8];
    fVar14 = DAT_018ce2f8;
    if (fVar13 <= DAT_018ce2f8) {
      fVar14 = fVar13;
    }
    uStack_11c = puStack_34[9];
    fStack_134 = fVar14 * fVar15 * (float)puStack_34[5];
    uStack_128 = uStack_8c;
    uStack_124 = puStack_34[7];
    uStack_118 = 0;
    uStack_20 = auStack_194[0];
    uStack_1c = uStack_180;
    uStack_18 = uStack_188;
    uStack_14 = uStack_178;
    uStack_114 = auStack_194[0];
    uStack_110 = uStack_180;
    uStack_10c = uStack_188;
    uStack_108 = uStack_178;
    (**(code **)(*param_2 + 0x14))(puStack_44[2],0,1,0,0);
    uStack_1c._0_2_ = 0x100;
    uStack_18 = 0;
    uStack_14 = uStack_14 & 0xffff0000;
    (**(code **)(*param_2 + 0x34))(0,*puStack_4c,&uStack_1c);
    uStack_1c = (uint)uStack_1c._2_2_ << 0x10;
    uStack_18 = 0;
    uStack_14 = uStack_14 & 0xffff0000;
    (**(code **)(*param_2 + 0x34))(1,puStack_34[10],&uStack_1c);
    param_6._0_3_ = (uint3)param_6 & 0xff;
    param_6 = (float *)(uint)(uint3)param_6;
    uStack_18 = 0x1000100;
    uStack_1c = 0xf;
    uStack_14 = uStack_14 & 0xffffff00;
    FUN_0082a430(param_2,*puStack_34,"PassThroughPosVS","SunRaysFS",auStack_154,&uStack_1c,
                 (int)&param_6 + 1);
    (**(code **)(*param_2 + 0x18))();
    uStack_8._0_1_ = 0xc;
    FUN_0152dda0(uVar4,param_4,uVar16);
    uStack_8._0_1_ = 0xd;
    FUN_0152dda0(fStack_60,fStack_38,uStack_28);
    iVar2 = param_5;
    uStack_8._0_1_ = 1;
    uVar7 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (*(int *)(param_5 + 0x34) < DAT_01eb1ea0) {
      uStack_8._0_1_ = uVar7;
      FUN_016f3809(&DAT_01eb1ea0);
      if (DAT_01eb1ea0 == -1) {
        uStack_8._0_1_ = 0xe;
        uVar16 = FUN_0152dab0("Render","SunRaysBlur",0xffffffff);
        DAT_01eb1e9c = (undefined4)((ulonglong)uVar16 >> 0x20);
        DAT_01eb1e98 = (float)uVar16;
        uStack_8._0_1_ = 1;
        FUN_016f37bf(&DAT_01eb1ea0);
      }
    }
    fStack_38 = DAT_01eb1e98;
    param_5 = DAT_01eb1e9c;
    fStack_30 = DAT_01eb1e98;
    fStack_2c = (float)DAT_01eb1e9c;
    uVar16 = FUN_0152d930(DAT_01eb1e98,DAT_01eb1e9c);
    uStack_8._0_1_ = 0xf;
    uVar7 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xf;
    uStack_28 = uVar16;
    if (*(int *)(iVar2 + 0x34) < DAT_01eb1eb0) {
      uStack_8._0_1_ = uVar7;
      FUN_016f3809(&DAT_01eb1eb0);
      if (DAT_01eb1eb0 == -1) {
        uStack_8._0_1_ = 0x10;
        uVar16 = FUN_0152dab0(&DAT_018fb928,"SunRaysBlur",0xffffffff);
        DAT_01eb1eac = (undefined4)((ulonglong)uVar16 >> 0x20);
        DAT_01eb1ea8 = (undefined4)uVar16;
        uStack_8._0_1_ = 0xf;
        FUN_016f37bf(&DAT_01eb1eb0);
      }
    }
    uVar4 = DAT_01eb1ea8;
    param_4 = DAT_01eb1eac;
    uStack_70 = DAT_01eb1ea8;
    uStack_6c = DAT_01eb1eac;
    uVar16 = FUN_0152d930(DAT_01eb1ea8,DAT_01eb1eac);
    uStack_8._0_1_ = 0x11;
    uStack_68 = uVar16;
    FUN_00829d10(puStack_4c[2]);
    uStack_20 = uStack_58;
    uStack_1c = uStack_54;
    uStack_18 = 0;
    uStack_14 = 0;
    uStack_144 = uStack_58;
    uStack_140 = uStack_54;
    uStack_13c = 0;
    uStack_138 = 0;
    (**(code **)(*param_2 + 0x14))(puStack_4c[2],0,1,0,0);
    uStack_1c = CONCAT22(uStack_1c._2_2_,0x101);
    uStack_18 = 0;
    uStack_14 = uStack_14 & 0xffff0000;
    (**(code **)(*param_2 + 0x34))(0,*puStack_44,&uStack_1c);
    param_6._0_3_ = (uint3)param_6 & 0xff;
    param_6 = (float *)(uint)(uint3)param_6;
    uStack_18 = 0x1000100;
    uStack_1c = 0xf;
    uStack_14 = uStack_14 & 0xffffff00;
    FUN_0082a430(param_2,*puStack_34,"PassThroughPosVS","RadialBlurFS",auStack_154,&uStack_1c,
                 (int)&param_6 + 1);
    (**(code **)(*param_2 + 0x18))();
    uStack_8._0_1_ = 0x12;
    FUN_0152dda0(uVar4,param_4,uVar16);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
    FUN_0152dda0(fStack_38,param_5,uStack_28);
    *param_1 = 0;
    param_1[1] = 0;
    if (piStack_48 != (int *)0x0) {
      LOCK();
      *(int *)((int)piStack_48 + 4) = *(int *)((int)piStack_48 + 4) + 1;
      UNLOCK();
    }
    *param_1 = puStack_4c;
    param_1[1] = piStack_48;
  }
  uStack_50 = 7;
  uStack_8 = uStack_8 & 0xffffff00;
  FUN_016f32d1(&puStack_4c,8,2,FUN_00550b30);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11419 ; VA 0x00797910 ; FUN_00797910 */

void __thiscall FUN_00797910(int param_1,float *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  float *pfVar4;
  undefined4 *puVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  double dVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  undefined8 uStack_c0;
  float fStack_b8;
  float fStack_b4;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  float fStack_a4;
  float fStack_a0;
  float fStack_9c;
  float fStack_98;
  float fStack_94;
  undefined auStack_90 [8];
  float fStack_88;
  undefined auStack_84 [12];
  undefined auStack_78 [12];
  undefined auStack_6c [104];
  
  uStack_c0._4_4_ = param_2[1] - *(float *)(param_1 + 0x404);
  fVar6 = *(float *)(param_1 + 0x40c) - param_2[4];
  uStack_c0._0_4_ = *param_2 - *(float *)(param_1 + 0x400);
  fStack_b8 = param_2[2] - *(float *)(param_1 + 0x408);
  fVar7 = *(float *)(param_1 + 0x410) - param_2[5];
  fVar8 = *(float *)(param_1 + 0x414) - param_2[6];
  dVar9 = (double)(uStack_c0._4_4_ * uStack_c0._4_4_ + (float)uStack_c0 * (float)uStack_c0 +
                  fStack_b8 * fStack_b8);
  FUN_017267a0();
  fStack_b4 = (float)dVar9;
  dVar9 = (double)(fVar7 * fVar7 + fVar6 * fVar6 + fVar8 * fVar8);
  FUN_017267a0();
  fVar6 = fStack_b4;
  if (fStack_b4 <= (float)dVar9 * DAT_018df580) {
    fVar6 = (float)dVar9 * DAT_018df580;
  }
  fVar7 = *(float *)(param_1 + 0x418);
  if (*(float *)(param_1 + 0x418) <= fVar6) {
    fVar7 = fVar6;
  }
  fVar6 = 0.0;
  if (0.0 <= fVar7 - DAT_018f9938) {
    fVar6 = fVar7 - DAT_018f9938;
  }
  fVar7 = DAT_018ce2f8;
  if (fVar6 <= DAT_018ce2f8) {
    fVar7 = fVar6;
  }
  *(float *)(param_1 + 0x418) = fVar7;
  if (DAT_01d60f70 != '\0') {
    uVar3 = FUN_01160a40(*(undefined4 *)(param_1 + 0x94),*(undefined4 *)(param_1 + 0x98),
                         *(undefined4 *)(param_1 + 0x9c),*(undefined4 *)(param_1 + 0xa4),
                         *(undefined4 *)(param_1 + 0xa8),*(undefined4 *)(param_1 + 0xac),
                         *(undefined4 *)(param_1 + 0xb4),*(undefined4 *)(param_1 + 0xb8),
                         *(undefined4 *)(param_1 + 0xbc));
    FUN_00cf6ea0(uVar3);
    fVar10 = (float)(uStack_b0 ^ DAT_018c4ea0);
    fVar13 = (float)(uStack_a8 ^ DAT_018c4ea0);
    fVar6 = *(float *)(param_1 + 0x3b4);
    fVar7 = *(float *)(param_1 + 0x3b8);
    fVar11 = (float)(uStack_ac ^ DAT_018c4ea0);
    fVar8 = *(float *)(param_1 + 0x3b0);
    fVar12 = *(float *)(param_1 + 0x3bc);
    fStack_a0 = (fVar6 * fVar13 - fVar7 * fVar11) + fVar8 * fStack_a4 + fVar10 * fVar12;
    fStack_9c = (fVar7 * fVar10 - fVar8 * fVar13) + fVar6 * fStack_a4 + fVar11 * fVar12;
    fStack_98 = (fVar8 * fVar11 - fVar6 * fVar10) + fVar7 * fStack_a4 + fVar13 * fVar12;
    fStack_94 = fStack_a4 * fVar12 - (fVar6 * fVar11 + fVar8 * fVar10 + fVar7 * fVar13);
    FUN_00cf7180(auStack_6c);
    *(uint *)(param_1 + 0x3b0) = uStack_b0;
    *(uint *)(param_1 + 0x3b4) = uStack_ac;
    *(uint *)(param_1 + 0x3b8) = uStack_a8;
    *(float *)(param_1 + 0x3bc) = fStack_a4;
    pfVar4 = (float *)FUN_011658d0(auStack_90);
    fStack_b4 = pfVar4[1] * uStack_c0._4_4_ + *pfVar4 * (float)uStack_c0 + pfVar4[2] * fStack_b8;
    pfVar4 = (float *)FUN_011658d0(auStack_84);
    fVar6 = *pfVar4 * (float)uStack_c0;
    fVar12 = pfVar4[1] * uStack_c0._4_4_;
    fVar7 = pfVar4[2] * fStack_b8;
    pfVar4 = (float *)FUN_011658d0(auStack_78);
    fVar8 = pfVar4[2] * fStack_b8;
    fStack_88 = fStack_b4;
    fStack_b8 = fStack_b4;
    uStack_c0 = CONCAT44(fVar12 + fVar6 + fVar7,
                         pfVar4[1] * uStack_c0._4_4_ + (float)uStack_c0 * *pfVar4 + fVar8);
    puVar5 = (undefined4 *)FUN_01165980(auStack_6c,&uStack_c0);
    uVar3 = puVar5[1];
    uVar1 = puVar5[2];
    uVar2 = puVar5[3];
    *(undefined4 *)(param_1 + 0x3c0) = *puVar5;
    *(undefined4 *)(param_1 + 0x3c4) = uVar3;
    *(undefined4 *)(param_1 + 0x3c8) = uVar1;
    *(undefined4 *)(param_1 + 0x3cc) = uVar2;
    uVar3 = puVar5[5];
    uVar1 = puVar5[6];
    uVar2 = puVar5[7];
    *(undefined4 *)(param_1 + 0x3d0) = puVar5[4];
    *(undefined4 *)(param_1 + 0x3d4) = uVar3;
    *(undefined4 *)(param_1 + 0x3d8) = uVar1;
    *(undefined4 *)(param_1 + 0x3dc) = uVar2;
    uVar3 = puVar5[9];
    uVar1 = puVar5[10];
    uVar2 = puVar5[0xb];
    *(undefined4 *)(param_1 + 0x3e0) = puVar5[8];
    *(undefined4 *)(param_1 + 0x3e4) = uVar3;
    *(undefined4 *)(param_1 + 1000) = uVar1;
    *(undefined4 *)(param_1 + 0x3ec) = uVar2;
    uVar3 = puVar5[0xd];
    uVar1 = puVar5[0xe];
    uVar2 = puVar5[0xf];
    *(undefined4 *)(param_1 + 0x3f0) = puVar5[0xc];
    *(undefined4 *)(param_1 + 0x3f4) = uVar3;
    *(undefined4 *)(param_1 + 0x3f8) = uVar1;
    *(undefined4 *)(param_1 + 0x3fc) = uVar2;
    *(uint *)(param_1 + 0x3b0) = uStack_b0;
    *(uint *)(param_1 + 0x3b4) = uStack_ac;
    *(uint *)(param_1 + 0x3b8) = uStack_a8;
    *(float *)(param_1 + 0x3bc) = fStack_a4;
  }
  *(undefined8 *)(param_1 + 0x400) = *(undefined8 *)param_2;
  *(float *)(param_1 + 0x408) = param_2[2];
  *(undefined8 *)(param_1 + 0x40c) = *(undefined8 *)(param_2 + 4);
  *(float *)(param_1 + 0x414) = param_2[6];
  return;
}



/* FUNCTION 11420 ; VA 0x00797d70 ; FUN_00797d70 */

void __thiscall FUN_00797d70(int param_1,undefined4 param_2,int param_3,undefined4 param_4)

{
  undefined auStack_84 [64];
  undefined auStack_44 [64];
  
  if (DAT_01d60f70 != '\0') {
    FUN_007a0100(param_2,*(undefined4 *)(*(int *)(param_1 + 0x434) + 0x24),1);
    FUN_01165af0(auStack_44,param_1 + 0x3c0);
    FUN_01165e00(auStack_84);
    FUN_008241c0(param_2,*(undefined4 *)(param_1 + 0x430),
                 *(undefined4 *)(*(int *)(param_1 + 0x434) + 0xc),param_4,param_3 + 0x5c,auStack_84,
                 auStack_44);
  }
  return;
}



/* FUNCTION 11421 ; VA 0x00797df0 ; FUN_00797df0 */

void __thiscall FUN_00797df0(int *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  uint uVar2;
  int iVar3;
  float10 fVar4;
  int aiStack_20 [3];
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b1be8;
  pvStack_10 = ExceptionList;
  aiStack_20[0] = 0;
  aiStack_20[1] = 0;
  aiStack_20[2] = 0;
  uStack_8 = 0;
  if (DAT_01d60f68 == '\0') {
    ExceptionList = &pvStack_10;
    fVar4 = (float10)FUN_00855cb0();
    fStack_14 = (float)fVar4;
    FUN_00817870(aiStack_20,param_2,param_1 + 1,fStack_14);
  }
  else {
    uVar1 = *(undefined4 *)(*(int *)(*param_1 + 0x4fc) + 0x160);
    ExceptionList = &pvStack_10;
    fVar4 = (float10)FUN_01156be0();
    fStack_14 = (float)fVar4;
    FUN_008173d0(aiStack_20,param_2,param_1 + 1,param_1[5],fStack_14,uVar1);
  }
  param_1[4] = *(int *)(param_1[6] + 0x30);
  if (aiStack_20[0] != 0) {
    uVar2 = aiStack_20[2] - aiStack_20[0] & 0xfffffffc;
    iVar3 = aiStack_20[0];
    if (0xfff < uVar2) {
      iVar3 = *(int *)(aiStack_20[0] + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (aiStack_20[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11422 ; VA 0x00797f00 ; FUN_00797f00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00797f00(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b1c18;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1f18) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb1f18);
    if (DAT_01eb1f18 == -1) {
      FUN_0147c5c0(0,0,2,0,0);
      FUN_016f37bf(&DAT_01eb1f18);
    }
  }
  FUN_0147c1b0(auStack_28,&DAT_01eb1f04,1,0xc);
  uStack_4c = _DAT_018fdeb0;
  uStack_48 = _UNK_018fdeb4;
  uStack_44 = _UNK_018fdeb8;
  uStack_40 = _UNK_018fdebc;
  uStack_8 = 0;
  uStack_3c = _DAT_018fded0;
  uStack_38 = _UNK_018fded4;
  uStack_34 = _UNK_018fded8;
  uStack_30 = _UNK_018fdedc;
  uStack_2c = 0;
  (**(code **)(*param_2 + 0x3c))(&piStack_20,0,0x24,0xc,0);
  uStack_8._0_1_ = 1;
  (**(code **)(*piStack_20 + 0x18))(0,&uStack_4c,0x24);
  uStack_18 = 0;
  piStack_14 = (int *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0147c0e0(param_1,auStack_28,&piStack_20,&uStack_18);
  piVar2 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar3 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_24[1] + -1;
    piStack_24[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar2 = piStack_24 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11423 ; VA 0x00798090 ; FUN_00798090 */

undefined4 FUN_00798090(undefined4 param_1,int *param_2)

{
  int *piVar1;
  uint uVar2;
  uint *puVar3;
  undefined8 *puVar4;
  int *piVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined8 auStack_1dc [54];
  undefined auStack_2c [4];
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b1c48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1f30) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb1f30), DAT_01eb1f30 == -1)) {
    FUN_0147c5c0(0,0,2,0,0);
    FUN_016f37bf(&DAT_01eb1f30);
  }
  FUN_0147c1b0(auStack_2c,&DAT_01eb1f1c,1,0xc);
  uStack_8 = 0;
  iVar6 = 0x24;
  do {
    FUN_00569440();
    iVar6 = iVar6 + -1;
  } while (iVar6 != 0);
  puVar4 = auStack_1dc;
  puVar3 = &DAT_018fd8b0;
  do {
    piVar5 = (int *)&DAT_00000006;
    do {
      uVar2 = *puVar3;
      uVar9 = DAT_018f7864;
      if ((uVar2 & 1) != 0) {
        uVar9 = DAT_018ce2f8;
      }
      uVar8 = DAT_018f7864;
      if ((uVar2 & 2) != 0) {
        uVar8 = DAT_018ce2f8;
      }
      uVar7 = DAT_018f7864;
      if ((uVar2 & 4) != 0) {
        uVar7 = DAT_018ce2f8;
      }
      puVar3 = puVar3 + 1;
      piStack_14 = (int *)uVar9;
      *puVar4 = CONCAT44(uVar8,uVar7);
      *(undefined4 *)(puVar4 + 1) = uVar9;
      puVar4 = (undefined8 *)((int)puVar4 + 0xc);
      piVar5 = (int *)((int)piVar5 + -1);
    } while (piVar5 != (int *)0x0);
  } while ((int)puVar3 < 0x18fd940);
  (**(code **)(*param_2 + 0x3c))(&piStack_24,0,0x1b0,0xc,0);
  uStack_8._0_1_ = 1;
  (**(code **)(*piStack_24 + 0x18))(0,auStack_1dc,0x1b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  piStack_18 = piVar5;
  piStack_14 = piVar5;
  FUN_0147c0e0(param_1,auStack_2c,&piStack_24,&piStack_18);
  piVar5 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_14[1] + -1;
    piStack_14[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_20[1] + -1;
    piStack_20[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar6 = piStack_20[2] + -1;
      piStack_20[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_28[1] + -1;
    piStack_28[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar5 = piStack_28 + 2;
      iVar6 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 11424 ; VA 0x007982a0 ; FUN_007982a0 */

void __fastcall FUN_007982a0(int *param_1)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  uint auStack_90 [4];
  undefined4 uStack_80;
  uint uStack_7c;
  uint uStack_78;
  undefined4 uStack_68;
  uint uStack_64;
  uint uStack_60;
  undefined4 uStack_50;
  uint uStack_4c;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  undefined auStack_2c [4];
  int *piStack_28;
  int *piStack_20;
  int iStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b1cd0;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  puStack_14 = &stack0xffffff64;
  if (param_1[0x108] == 0) {
    piVar6 = *(int **)(*param_1 + 0x3c);
    ExceptionList = &pvStack_10;
    piStack_20 = piVar6;
    iStack_1c = FUN_01674e20(0x18);
    uStack_8 = 0;
    if (iStack_1c == 0) {
      iVar5 = 0;
    }
    else {
      uVar4 = FUN_00798090(auStack_2c,piVar6);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      uStack_18 = 1;
      iVar5 = FUN_0147c720(uVar4,0,0,0,0x24);
    }
    iStack_1c = param_1[0x108];
    param_1[0x108] = iVar5;
    if (iStack_1c != 0) {
      piVar6 = *(int **)(iStack_1c + 4);
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar5 = piVar6[1] + -1;
        piVar6[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          iVar5 = piVar6[2] + -1;
          piVar6[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      FUN_01674ea0(iStack_1c,0x18);
    }
    piVar6 = piStack_28;
    if (((uStack_18 & 1) != 0) && (piStack_28 != (int *)0x0)) {
      LOCK();
      iVar5 = piStack_28[1] + -1;
      piStack_28[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    uStack_80 = 0;
    uStack_7c = 0xf;
    auStack_90[0] = auStack_90[0] & 0xffffff00;
    uStack_68 = 0;
    uStack_64 = 0xf;
    uStack_78 = uStack_78 & 0xffffff00;
    uStack_50 = 0;
    uStack_4c = 0xf;
    uStack_60 = uStack_60 & 0xffffff00;
    uStack_8 = 3;
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = auStack_44[0] & 0xffffff00;
    FUN_005542c0("rbxasset://textures/shadowblurmask.png",0x26);
    uStack_8._0_1_ = 4;
    FUN_009cbbb0(auStack_44);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    piVar6 = (int *)FUN_00782480(auStack_2c,auStack_44,3,auStack_90,0x425c0000,0);
    iVar5 = *piVar6;
    iVar3 = piVar6[1];
    *piVar6 = 0;
    piVar6[1] = 0;
    param_1[0x119] = iVar5;
    piVar6 = (int *)param_1[0x11a];
    param_1[0x11a] = iVar3;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar5 = piVar6[1] + -1;
      piVar6[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        iVar5 = piVar6[2] + -1;
        piVar6[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_28[1] + -1;
      piStack_28[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        piVar6 = piStack_28 + 2;
        iVar5 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piStack_28 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (0xf < uStack_30) {
      uVar8 = uStack_30 + 1;
      uVar7 = auStack_44[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_44[0] - 4);
        uVar8 = uStack_30 + 0x24;
        if (0x1f < (auStack_44[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = auStack_44[0] & 0xffffff00;
    uStack_8 = 0xffffffff;
    if (0xf < uStack_4c) {
      uVar8 = uStack_4c + 1;
      uVar7 = uStack_60;
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(uStack_60 - 4);
        uVar8 = uStack_4c + 0x24;
        if (0x1f < (uStack_60 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_50 = 0;
    uStack_4c = 0xf;
    uStack_60 = uStack_60 & 0xffffff00;
    if (0xf < uStack_64) {
      uVar8 = uStack_64 + 1;
      uVar7 = uStack_78;
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(uStack_78 - 4);
        uVar8 = uStack_64 + 0x24;
        if (0x1f < (uStack_78 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_68 = 0;
    uStack_64 = 0xf;
    uStack_78 = uStack_78 & 0xffffff00;
    if (0xf < uStack_7c) {
      uVar8 = uStack_7c + 1;
      uVar7 = auStack_90[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_90[0] - 4);
        uVar8 = uStack_7c + 0x24;
        if (0x1f < (auStack_90[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_8 = 6;
    iVar5 = (**(code **)(*piStack_20 + 0x40))();
    cVar2 = *(char *)(iVar5 + 0x1c);
    param_1[0x118] = 0x3e4ccccd;
    uStack_18 = (cVar2 == '\0') + 1;
    piStack_20 = (int *)FUN_01674e20(0x28);
    uVar7 = uStack_18;
    uStack_8._0_1_ = 7;
    if (piStack_20 == (int *)0x0) {
      iVar5 = 0;
    }
    else {
      iVar5 = FUN_00792bc0(*param_1,uStack_18,0x100);
    }
    iVar3 = param_1[0x115];
    uStack_8._0_1_ = 6;
    param_1[0x115] = iVar5;
    if (iVar3 != 0) {
      FUN_00795910(iVar3);
    }
    piStack_20 = (int *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 8;
    if (piStack_20 == (int *)0x0) {
      iVar5 = 0;
    }
    else {
      iVar5 = FUN_00792bc0(*param_1,uVar7,0x200);
    }
    iVar3 = param_1[0x116];
    uStack_8._0_1_ = 6;
    param_1[0x116] = iVar5;
    if (iVar3 != 0) {
      FUN_00795910(iVar3);
    }
    piStack_20 = (int *)FUN_01674e20(0x28);
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    if (piStack_20 == (int *)0x0) {
      iVar5 = 0;
    }
    else {
      iVar5 = FUN_00792bc0(*param_1,uVar7,0x400);
    }
    iVar3 = param_1[0x117];
    param_1[0x117] = iVar5;
    if (iVar3 != 0) {
      FUN_00795910(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11425 ; VA 0x007986d1 ; Catch@007986d1 */

undefined4 Catch_007986d1(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  if (DAT_01f6dcc0 != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x20) + 4))();
    FUN_01677650(DAT_01f6dcc0,"Error creating shadow maps: %s",uVar1);
  }
  return 0x7986c0;
}



/* FUNCTION 11426 ; VA 0x00798720 ; FUN_00798720 */

/* WARNING: Removing unreachable block (ram,0x00798832) */
/* WARNING: Removing unreachable block (ram,0x0079883b) */
/* WARNING: Removing unreachable block (ram,0x00798849) */

void __fastcall FUN_00798720(int *param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int iStack_c;
  
  iVar1 = param_1[0x115];
  param_1[0x115] = 0;
  if (iVar1 != 0) {
    FUN_00795910(iVar1);
  }
  iVar1 = param_1[0x116];
  param_1[0x116] = 0;
  if (iVar1 != 0) {
    FUN_00795910(iVar1);
  }
  iVar1 = param_1[0x117];
  param_1[0x117] = 0;
  if (iVar1 != 0) {
    FUN_00795910(iVar1);
  }
  iVar1 = param_1[0x108];
  param_1[0x108] = 0;
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,0x18);
  }
  FUN_007735a0(*(int *)(*param_1 + 0x4ec) + 0x34,3);
  param_1[0x119] = iStack_c;
  piVar2 = (int *)param_1[0x11a];
  param_1[0x11a] = iVar1;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar1 = piVar2[1] + -1;
    piVar2[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar1 = piVar2[2] + -1;
      piVar2[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_007f63a0();
  return;
}



/* FUNCTION 11427 ; VA 0x00798860 ; FUN_00798860 */

void __thiscall FUN_00798860(int param_1,float *param_2,float param_3)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  undefined8 uVar14;
  undefined8 uVar15;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b1d14;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  if (*(int *)(iVar1 + 0x34) < DAT_01eb2568) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2568);
    if (DAT_01eb2568 == -1) {
      uStack_8 = 0;
      uVar14 = FUN_0152dab0("LightGrid","gatherLights",0xffffffff);
      DAT_01eb2564 = (undefined4)((ulonglong)uVar14 >> 0x20);
      DAT_01eb2560 = (undefined4)uVar14;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb2568);
    }
  }
  uVar4 = DAT_01eb2564;
  uVar3 = DAT_01eb2560;
  uVar14 = FUN_0152d930(DAT_01eb2560,DAT_01eb2564);
  uStack_8 = 1;
  FUN_00817260((uint *)(param_1 + 0x1c),param_2,1);
  if (*(int *)(iVar1 + 0x34) < DAT_01eb2578) {
    FUN_016f3809(&DAT_01eb2578);
    if (DAT_01eb2578 == -1) {
      uStack_8._0_1_ = 2;
      uVar15 = FUN_0152dab0("LightGrid",&DAT_018fde18,0xffffffff);
      DAT_01eb2574 = (undefined4)((ulonglong)uVar15 >> 0x20);
      DAT_01eb2570 = (undefined4)uVar15;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eb2578);
    }
  }
  uVar6 = DAT_01eb2574;
  uVar5 = DAT_01eb2570;
  uVar15 = FUN_0152d930(DAT_01eb2570,DAT_01eb2574);
  uStack_8._0_1_ = 3;
  *(undefined4 *)(param_1 + 0x4ac) = *(undefined4 *)(param_1 + 0x4a8);
  piVar9 = *(int **)(param_1 + 0x1c);
  uVar8 = 0;
  uVar7 = (uint)((int)*(int **)(param_1 + 0x20) + (3 - (int)piVar9)) >> 2;
  if (*(int **)(param_1 + 0x20) < piVar9) {
    uVar7 = 0;
  }
  if (uVar7 != 0) {
    do {
      iStack_14 = *piVar9;
      if ((*(int *)(iStack_14 + 0xd4) != 0) && (0.0 < *(float *)(iStack_14 + 0xe4))) {
        fVar13 = *(float *)(iStack_14 + 0xa0) - param_2[1];
        fVar12 = *(float *)(iStack_14 + 0x9c) - *param_2;
        fVar10 = *(float *)(iStack_14 + 0xa4) - param_2[2];
        fVar11 = *(float *)(iStack_14 + 0xe8) + param_3;
        if (fVar13 * fVar13 + fVar12 * fVar12 + fVar10 * fVar10 <= fVar11 * fVar11) {
          piVar2 = *(int **)(param_1 + 0x4ac);
          if (*(int **)(param_1 + 0x4b0) == piVar2) {
            FUN_006030d0(piVar2,&iStack_14);
          }
          else {
            *piVar2 = iStack_14;
            *(int *)(param_1 + 0x4ac) = *(int *)(param_1 + 0x4ac) + 4;
          }
        }
      }
      uVar8 = uVar8 + 1;
      piVar9 = piVar9 + 1;
    } while (uVar8 != uVar7);
  }
  uStack_8._0_1_ = 4;
  FUN_0152dda0(uVar5,uVar6,uVar15);
  uStack_8._0_1_ = 1;
  if (*(int *)(iVar1 + 0x34) < DAT_01eb2588) {
    FUN_016f3809(&DAT_01eb2588);
    if (DAT_01eb2588 == -1) {
      uStack_8._0_1_ = 5;
      uVar15 = FUN_0152da50("LightGrid");
      DAT_01eb2584 = (undefined4)((ulonglong)uVar15 >> 0x20);
      DAT_01eb2580 = (undefined4)uVar15;
      uStack_8._0_1_ = 1;
      FUN_016f37bf(&DAT_01eb2588);
    }
  }
  FUN_0152d760(DAT_01eb2580,DAT_01eb2584,"Lights: %d",
               *(int *)(param_1 + 0x4ac) - *(int *)(param_1 + 0x4a8) >> 2);
  uStack_8 = 6;
  FUN_0152dda0(uVar3,uVar4,uVar14);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11428 ; VA 0x00798b60 ; FUN_00798b60 */

undefined8 * __thiscall FUN_00798b60(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined8 *puVar3;
  
  if (*(int *)(param_1 + 0x40) == 0) {
    iVar2 = *(int *)(param_1 + 0x424);
    *(undefined4 *)param_2 = *(undefined4 *)(iVar2 + 0xd4);
    *(undefined4 *)((int)param_2 + 4) = *(undefined4 *)(iVar2 + 0xd8);
    *(undefined4 *)(param_2 + 1) = *(undefined4 *)(iVar2 + 0xdc);
    return param_2;
  }
  if (*(int *)(param_1 + 0x40) != 1) {
    puVar3 = (undefined8 *)FUN_0115ee90();
    uVar1 = *(undefined4 *)(puVar3 + 1);
    *param_2 = *puVar3;
    *(undefined4 *)(param_2 + 1) = uVar1;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x428);
  *(undefined4 *)param_2 = *(undefined4 *)(iVar2 + 0x418);
  *(undefined4 *)((int)param_2 + 4) = *(undefined4 *)(iVar2 + 0x41c);
  *(undefined4 *)(param_2 + 1) = *(undefined4 *)(iVar2 + 0x420);
  return param_2;
}



/* FUNCTION 11429 ; VA 0x00798be0 ; FUN_00798be0 */

int __fastcall FUN_00798be0(int param_1)

{
  return *(int *)(param_1 + 0x434) + 0x2c;
}



/* FUNCTION 11430 ; VA 0x00798bf0 ; FUN_00798bf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall FUN_00798bf0(int param_1,undefined4 param_2)

{
  float fVar1;
  int iVar2;
  float *pfVar3;
  int iVar4;
  undefined auStack_1ec [64];
  undefined auStack_1ac [128];
  undefined auStack_12c [64];
  float fStack_ec;
  float afStack_e8 [16];
  float afStack_a8 [16];
  float afStack_68 [16];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  iStack_1c = param_1;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1ec0) {
    FUN_016f3809(&DAT_01eb1ec0);
    if (DAT_01eb1ec0 == -1) {
      DAT_01eb1eb4 = 1.0;
      DAT_01eb1eb8 = 1.0;
      DAT_01eb1ebc = 1.0;
      FUN_016f37bf(&DAT_01eb1ec0);
    }
  }
  fStack_c = (DAT_018ce2f4 - (*(float *)(param_1 + 0x14) + DAT_018ce2f8) * DAT_018ce2f4) +
             *(float *)(param_1 + 0x10);
  fStack_14 = DAT_01eb1eb4 * fStack_c;
  fStack_10 = DAT_01eb1eb8 * fStack_c;
  fStack_c = DAT_01eb1ebc * fStack_c;
  FUN_01165980(&DAT_01d71e5c,&fStack_14);
  fStack_c = *(float *)(param_1 + 0x14) + DAT_018ce2f8;
  fStack_14 = DAT_01eb1eb4 * fStack_c;
  fStack_10 = DAT_01eb1eb8 * fStack_c;
  fStack_c = DAT_01eb1ebc * fStack_c;
  FUN_007a02f0(afStack_e8 + 0xf,&fStack_14);
  FUN_01165af0(afStack_a8 + 0xf,afStack_e8 + 0xf);
  FUN_01165a00(0x3eae147b,0x3f0ccccd,0x3de147ae,0,0x3eae147b,0x3f0ccccd,0x3de147ae,0,0x3eae147b,
               0x3f0ccccd,0x3de147ae,0,0,0,0,0x3f800000);
  fStack_8 = (float)(*(uint *)(param_1 + 0x18) ^ DAT_018c4ea0);
  iVar2 = FUN_01165af0(auStack_1ac,afStack_a8 + 0xf);
  fStack_14 = fStack_8;
  fStack_10 = fStack_8;
  fStack_c = fStack_8;
  FUN_007a02f0(auStack_12c,&fStack_14);
  FUN_01165ab0();
  fStack_8 = (float)((int)afStack_68 - iVar2);
  pfVar3 = (float *)(iVar2 + 8);
  iStack_18 = (int)afStack_a8 - iVar2;
  iVar4 = 0;
  do {
    fVar1 = fStack_8;
    *(float *)((int)afStack_a8 + iVar4 + -4) = pfVar3[-2] - *(float *)((int)afStack_68 + iVar4 + -4)
    ;
    *(float *)((int)afStack_a8 + iVar4) = pfVar3[-1] - *(float *)((int)afStack_68 + iVar4);
    iVar4 = iVar4 + 0x10;
    *(float *)((int)afStack_a8 + (-4 - iVar2) + (int)pfVar3) =
         *pfVar3 - *(float *)((int)afStack_68 + (-4 - iVar2) + (int)pfVar3);
    *(float *)(iStack_18 + (int)pfVar3) = pfVar3[1] - *(float *)((int)fVar1 + (int)pfVar3);
    pfVar3 = pfVar3 + 4;
  } while (iVar4 < 0x40);
  iVar2 = FUN_01165af0(auStack_1ec,afStack_e8 + 0xf);
  FUN_01165ab0();
  fStack_8 = (float)((int)afStack_68 - iVar2);
  pfVar3 = (float *)(iVar2 + 8);
  iStack_18 = (int)afStack_e8 - iVar2;
  iVar4 = 0;
  do {
    fVar1 = fStack_8;
    *(float *)((int)afStack_e8 + iVar4 + -4) = *(float *)((int)afStack_68 + iVar4 + -4) + pfVar3[-2]
    ;
    *(float *)((int)afStack_e8 + iVar4) = *(float *)((int)afStack_68 + iVar4) + pfVar3[-1];
    iVar4 = iVar4 + 0x10;
    *(float *)((int)afStack_e8 + (-4 - iVar2) + (int)pfVar3) =
         *(float *)((int)afStack_68 + (-4 - iVar2) + (int)pfVar3) + *pfVar3;
    *(float *)(iStack_18 + (int)pfVar3) = *(float *)((int)fVar1 + (int)pfVar3) + pfVar3[1];
    pfVar3 = pfVar3 + 4;
  } while (iVar4 < 0x40);
  afStack_68[0xf] = (float)_DAT_018f99a0;
  uStack_28 = _UNK_018f99a4;
  uStack_24 = _UNK_018f99a8;
  uStack_20 = _UNK_018f99ac;
  FUN_01165f50(3,afStack_68 + 0xf);
  pfVar3 = (float *)FUN_0115e8f0(iStack_1c + 4);
  fStack_14 = *pfVar3;
  fStack_10 = pfVar3[1];
  fStack_c = pfVar3[2];
  FUN_007a02f0(auStack_12c,&fStack_14);
  FUN_01165af0(param_2,&fStack_ec);
  return param_2;
}



/* FUNCTION 11431 ; VA 0x00798fd0 ; FUN_00798fd0 */

int __fastcall FUN_00798fd0(int param_1)

{
  return *(int *)(param_1 + 0x434) + 0x34;
}



/* FUNCTION 11432 ; VA 0x00798fe0 ; FUN_00798fe0 */

undefined4 * __thiscall
FUN_00798fe0(int *param_1,undefined4 *param_2,uint param_3,uint param_4,uint param_5)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined auStack_64 [4];
  int *piStack_60;
  undefined auStack_54 [4];
  int *piStack_50;
  undefined4 uStack_44;
  int *piStack_40;
  undefined4 uStack_3c;
  int *piStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  int *piStack_2c;
  uint uStack_24;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b1d48;
  pvStack_10 = ExceptionList;
  uVar2 = param_3;
  if (param_3 < param_4) {
    uVar2 = param_4;
  }
  puStack_14 = &stack0xffffff90;
  puStack_20 = (undefined4 *)(uint)(0x80 < uVar2);
  if (0x100 < uVar2) {
    puStack_20 = (undefined4 *)0x2;
  }
  if (0x200 < uVar2) {
    puStack_20 = (undefined4 *)0x3;
  }
  piStack_18 = *(int **)(*param_1 + 0x3c);
  ExceptionList = &pvStack_10;
  piStack_2c = param_1;
  iVar3 = (**(code **)(*piStack_18 + 0x40))();
  uVar2 = *(uint *)(iVar3 + 0x24);
  if (param_5 < *(uint *)(iVar3 + 0x24)) {
    uVar2 = param_5;
  }
  if (uVar2 == 2) {
    puVar6 = (undefined4 *)((int)puStack_20 + 4);
  }
  else {
    puVar6 = puStack_20;
    if (uVar2 == 4) {
      puVar6 = (undefined4 *)((int)puStack_20 + 8);
    }
  }
  iVar3 = *(int *)((int)puVar6 * 8 + param_1[0x125]);
  if (iVar3 == 0) {
    uStack_24 = uVar2;
    if ((*(char *)(param_1 + 0x129) != '\0') && (1 < uVar2)) {
      FUN_00798fe0(param_2,param_3,param_4,1);
      ExceptionList = pvStack_10;
      return param_2;
    }
    iVar3 = 0x80 << ((byte)puStack_20 & 0x1f);
    uStack_8 = 0;
    FUN_0147c120(&uStack_3c,0,param_1[0x128],iVar3,iVar3,1,1,1,uVar2,0x42);
    uStack_8._0_1_ = 1;
    uVar4 = 0x42;
    if (uVar2 == 1) {
      uVar4 = 3;
    }
    FUN_0147c120(&uStack_34,0,3,iVar3,iVar3,1,1,1,uVar2,uVar4);
    uStack_8._0_1_ = 2;
    FUN_0147d420(&uStack_3c);
    uStack_8._0_1_ = 3;
    FUN_0147d420(&uStack_34);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_0147bf30(&uStack_44,auStack_54,auStack_64);
    if (piStack_50 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_50[1] + -1;
      piStack_50[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_50)();
        LOCK();
        iVar3 = piStack_50[2] + -1;
        piStack_50[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_50 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    if (piStack_60 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_60[1] + -1;
      piStack_60[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_60)();
        LOCK();
        iVar3 = piStack_60[2] + -1;
        piStack_60[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_60 + 4))();
        }
      }
    }
    puVar7 = (undefined4 *)(param_1[0x125] + (int)puVar6 * 8);
    puStack_20 = puVar7;
    puVar5 = (undefined4 *)FUN_01674e20(0x1c);
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      *puVar5 = 0;
      puVar5[1] = 0;
      if (piStack_30 != (int *)0x0) {
        LOCK();
        piStack_30[1] = piStack_30[1] + 1;
        UNLOCK();
      }
      *puVar5 = uStack_34;
      puVar5[1] = piStack_30;
      puVar5[2] = 0;
      puVar5[3] = 0;
      if (piStack_38 != (int *)0x0) {
        LOCK();
        piStack_38[1] = piStack_38[1] + 1;
        UNLOCK();
      }
      puVar5[2] = uStack_3c;
      puVar5[3] = piStack_38;
      puVar5[4] = 0;
      puVar5[5] = 0;
      if (piStack_40 != (int *)0x0) {
        LOCK();
        piStack_40[1] = piStack_40[1] + 1;
        UNLOCK();
      }
      puVar5[4] = uStack_44;
      puVar5[5] = piStack_40;
      puVar5[6] = 0;
    }
    uStack_1c = 0;
    piStack_18 = (int *)0x0;
    FUN_00791d70(puVar5,param_2);
    *puVar7 = uStack_1c;
    piVar1 = (int *)puVar7[1];
    puStack_20[1] = piStack_18;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar3 = piVar1[1] + -1;
      piVar1[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar3 = piVar1[2] + -1;
        piVar1[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    puVar6 = (undefined4 *)(param_1[0x125] + (int)puVar6 * 8);
    *param_2 = 0;
    param_2[1] = 0;
    if (puVar6[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar6[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *param_2 = *puVar6;
    param_2[1] = puVar6[1];
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_40[1] + -1;
      piStack_40[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_40)();
        LOCK();
        iVar3 = piStack_40[2] + -1;
        piStack_40[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_40 + 4))();
        }
      }
    }
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_30[1] + -1;
      piStack_30[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        iVar3 = piStack_30[2] + -1;
        piStack_30[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_30 + 4))();
        }
      }
    }
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_38[1] + -1;
      piStack_38[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_38)();
        LOCK();
        piVar1 = piStack_38 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piStack_38 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  *(undefined4 *)(iVar3 + 0x18) = 0;
  puVar6 = (undefined4 *)(param_1[0x125] + (int)puVar6 * 8);
  *param_2 = 0;
  param_2[1] = 0;
  if (puVar6[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar6[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_2 = *puVar6;
  param_2[1] = puVar6[1];
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 11433 ; VA 0x00799395 ; Catch@00799395 */

undefined * Catch_00799395(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + -0x20) == 1) {
    uVar2 = (**(code **)(**(int **)(unaff_EBP + -0x24) + 4))();
    FUN_0086f2f0(3,"Error initializing GuiCluster Framebuffer %s",uVar2);
    return &LAB_007993b9;
  }
  if (DAT_01f6dcc0 != '\0') {
    uVar2 = (**(code **)(**(int **)(unaff_EBP + -0x24) + 4))();
    FUN_01677650(DAT_01f6dcc0,"Error initializing GuiCluster Buffer MSAA: %s",uVar2);
  }
  uVar2 = *(undefined4 *)(unaff_EBP + 0x10);
  uVar1 = *(undefined4 *)(unaff_EBP + 0xc);
  *(undefined *)(*(int *)(unaff_EBP + -0x28) + 0x4a4) = 1;
  FUN_00798fe0(*(undefined4 *)(unaff_EBP + 8),uVar1,uVar2,1);
  return &LAB_00799423;
}



/* FUNCTION 11434 ; VA 0x00799440 ; FUN_00799440 */

float10 __thiscall FUN_00799440(int param_1,int param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  
  fVar3 = *(float *)(param_1 + 8) * *(float *)(param_2 + 0x14) +
          *(float *)(param_1 + 4) * *(float *)(param_2 + 0x10) +
          *(float *)(param_1 + 0xc) * *(float *)(param_2 + 0x18);
  fVar2 = 0.0;
  if (0.0 <= fVar3) {
    fVar2 = fVar3;
  }
  fVar3 = DAT_018ce2f8;
  if (fVar2 <= DAT_018ce2f8) {
    fVar3 = fVar2;
  }
  fVar1 = *(float *)(param_1 + 8) * DAT_018fde94;
  fVar2 = 0.0;
  if (0.0 <= fVar1) {
    fVar2 = fVar1;
  }
  fVar1 = DAT_018ce2f8;
  if (fVar2 <= DAT_018ce2f8) {
    fVar1 = fVar2;
  }
  return (float10)fVar3 * (float10)fVar1;
}



/* FUNCTION 11435 ; VA 0x007994b0 ; FUN_007994b0 */

int __fastcall FUN_007994b0(int param_1)

{
  if (*(int *)(param_1 + 0x40) == 0) {
    return *(int *)(param_1 + 0x424) + 0x74;
  }
  if (*(int *)(param_1 + 0x40) != 1) {
    return 0;
  }
  return *(int *)(param_1 + 0x428) + 0x3b8;
}



/* FUNCTION 11436 ; VA 0x007994e0 ; FUN_007994e0 */

void __thiscall
FUN_007994e0(int *param_1,undefined4 *param_2,int param_3,int param_4,int param_5,int param_6)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined *puVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  undefined4 uVar9;
  undefined8 uVar10;
  int *piStack_68;
  undefined auStack_5c [4];
  int *piStack_58;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined auStack_3c [4];
  int *piStack_38;
  undefined4 *puStack_30;
  int iStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b1d94;
  pvStack_10 = ExceptionList;
  puVar8 = (undefined4 *)param_1[1];
  puStack_14 = &stack0xffffff88;
  while( true ) {
    if (puVar8 == (undefined4 *)param_1[2]) {
      ExceptionList = &pvStack_10;
      piStack_18 = param_1;
      puVar6 = &stack0xffffff88;
      if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1f40
          ) && (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb1f40), puVar6 = puStack_14,
               DAT_01eb1f40 == -1)) {
        uStack_8 = 0;
        uVar10 = FUN_0152dab0("Render","RTPool::getRT",0xffffffff);
        DAT_01eb1f3c = (undefined4)((ulonglong)uVar10 >> 0x20);
        DAT_01eb1f38 = (undefined4)uVar10;
        uStack_8 = 0xffffffff;
        FUN_016f37bf(&DAT_01eb1f40);
        puVar6 = puStack_14;
      }
      puStack_14 = puVar6;
      uStack_24 = DAT_01eb1f38;
      uStack_4c = DAT_01eb1f38;
      uStack_20 = DAT_01eb1f3c;
      uStack_48 = DAT_01eb1f3c;
      uStack_44 = FUN_0152d930(DAT_01eb1f38,DAT_01eb1f3c);
      uStack_8 = 1;
      uVar7 = FUN_01675290(DAT_01eb1cfc);
      uStack_8._0_1_ = 3;
      uStack_1c = *(undefined4 *)(*piStack_18 + 0x3c);
      uStack_28 = uVar7;
      puVar8 = (undefined4 *)FUN_01674e20(0x10);
      if (puVar8 == (undefined4 *)0x0) {
        puVar8 = (undefined4 *)0x0;
      }
      else {
        *puVar8 = 0;
        puVar8[1] = 0;
        puVar8[2] = 0;
        puVar8[3] = 0;
      }
      puStack_30 = (undefined4 *)0x0;
      iStack_2c = 0;
      FUN_00791e00(puVar8,param_6);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      puVar8 = (undefined4 *)FUN_0147c150(auStack_3c,0,param_6,param_3,param_4,1,param_5,1,3);
      uVar9 = *puVar8;
      uVar4 = puVar8[1];
      *puVar8 = 0;
      puVar8[1] = 0;
      *puStack_30 = uVar9;
      piVar5 = (int *)puStack_30[1];
      puStack_30[1] = uVar4;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar2 = piVar5[1] + -1;
        piVar5[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar2 = piVar5[2] + -1;
          piVar5[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      piVar5 = piStack_38;
      if (piStack_38 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_38[1] + -1;
        piStack_38[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_38)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar2 = *piVar1 + -1;
          *piVar1 = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      uVar9 = FUN_0147d4b0();
      uStack_8._0_1_ = 5;
      FUN_0147d420(puStack_30);
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      puVar8 = (undefined4 *)FUN_0147bf30(auStack_3c,auStack_5c,uVar9);
      uVar9 = *puVar8;
      uVar4 = puVar8[1];
      *puVar8 = 0;
      puVar8[1] = 0;
      puStack_30[2] = uVar9;
      piVar5 = (int *)puStack_30[3];
      puStack_30[3] = uVar4;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar2 = piVar5[1] + -1;
        piVar5[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar2 = piVar5[2] + -1;
          piVar5[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      if (piStack_38 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_38[1] + -1;
        piStack_38[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_38)();
          LOCK();
          iVar2 = piStack_38[2] + -1;
          piStack_38[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piStack_38 + 4))();
          }
        }
      }
      if (piStack_58 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_58[1] + -1;
        piStack_58[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_58)();
          LOCK();
          iVar2 = piStack_58[2] + -1;
          piStack_58[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piStack_58 + 4))();
          }
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      if (piStack_68 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_68[1] + -1;
        piStack_68[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_68)();
          LOCK();
          piVar5 = piStack_68 + 2;
          iVar2 = *piVar5;
          *piVar5 = *piVar5 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piStack_68 + 4))();
          }
        }
      }
      puVar8 = (undefined4 *)piStack_18[2];
      if ((undefined4 *)piStack_18[3] == puVar8) {
        FUN_005c1970(puVar8,&puStack_30);
      }
      else {
        *puVar8 = 0;
        puVar8[1] = 0;
        if (iStack_2c != 0) {
          LOCK();
          *(int *)(iStack_2c + 4) = *(int *)(iStack_2c + 4) + 1;
          UNLOCK();
        }
        *puVar8 = puStack_30;
        puVar8[1] = iStack_2c;
        piStack_18[2] = piStack_18[2] + 8;
      }
      *param_2 = puStack_30;
      param_2[1] = iStack_2c;
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      FUN_01675290(uVar7);
      uStack_8 = 8;
      uVar9 = uStack_20;
      uVar10 = uStack_44;
      FUN_0152dda0(uStack_24,uStack_20,uStack_44);
      FUN_007998b0(uVar9,uVar10,uVar7);
      return;
    }
    iVar2 = puVar8[1];
    if (((((iVar2 != 0) && (*(int *)(iVar2 + 4) == 1)) &&
         (iVar3 = *(int *)*puVar8, *(int *)(iVar3 + 0x30) == param_3)) &&
        ((*(int *)(iVar3 + 0x34) == param_4 && (*(int *)(iVar3 + 0x3c) == param_5)))) &&
       (*(int *)(iVar3 + 0x2c) == param_6)) break;
    puVar8 = puVar8 + 2;
  }
  *param_2 = 0;
  param_2[1] = 0;
  LOCK();
  *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
  UNLOCK();
  uVar7 = puVar8[1];
  *param_2 = *puVar8;
  param_2[1] = uVar7;
  return;
}



/* FUNCTION 11437 ; VA 0x00799815 ; Catch@00799815 */

undefined * Catch_00799815(void)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  if (DAT_01f6dcc0 != '\0') {
    uVar2 = (**(code **)(**(int **)(unaff_EBP + -0x30) + 4))();
    FUN_01677650(DAT_01f6dcc0,"RTPool: failed to create texture: %s",uVar2);
    if (DAT_01f6dcc0 != '\0') {
      FUN_016773b0(DAT_01f6dcc0,"RTPool: width %u height %u miplevels %u format %u count %u",
                   *(undefined4 *)(unaff_EBP + 0xc),*(undefined4 *)(unaff_EBP + 0x10),
                   *(undefined4 *)(unaff_EBP + 0x14),*(undefined4 *)(unaff_EBP + 0x18),
                   *(int *)(*(int *)(unaff_EBP + -0x14) + 8) -
                   *(int *)(*(int *)(unaff_EBP + -0x14) + 4) >> 3);
    }
  }
  puVar1 = *(undefined4 **)(unaff_EBP + 8);
  *puVar1 = 0;
  puVar1[1] = 0;
  return &DAT_00799886;
}



/* FUNCTION 11438 ; VA 0x007998b0 ; FUN_007998b0 */

void FUN_007998b0(void)

{
  int unaff_EBP;
  
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 11439 ; VA 0x00799920 ; FUN_00799920 */

undefined4 FUN_00799920(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_007994e0(param_1,param_2,param_3,1,param_4);
  return param_1;
}



/* FUNCTION 11440 ; VA 0x00799940 ; FUN_00799940 */

void FUN_00799940(int *param_1,int param_2)

{
  uint3 uVar1;
  int *piVar2;
  undefined8 uVar3;
  char *pcVar4;
  undefined auStack_bc [16];
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  uint uStack_a0;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined8 uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b1db4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2558) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2558);
    if (DAT_01eb2558 == -1) {
      uStack_8 = 0;
      uVar3 = FUN_0152dab0(&DAT_018fb928,"Linearize Depth to color target",0xffffffff);
      DAT_01eb2554 = (undefined4)((ulonglong)uVar3 >> 0x20);
      DAT_01eb2550 = (undefined4)uVar3;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb2558);
    }
  }
  uStack_2c = DAT_01eb2550;
  uStack_3c = DAT_01eb2550;
  uStack_28 = DAT_01eb2554;
  uStack_38 = DAT_01eb2554;
  uStack_34 = FUN_0152d930(DAT_01eb2550,DAT_01eb2554);
  piVar2 = param_1;
  uStack_8 = 1;
  (**(code **)(*param_1 + 0x14))(*(undefined4 *)(*(int *)(puStack_24[0x10d] + 0x18) + 8),0,1,0,0);
  FUN_00829d10(*(undefined4 *)(*(int *)(puStack_24[0x10d] + 0x18) + 8));
  uStack_a0 = puStack_24[0xea];
  uStack_a4 = puStack_24[0xe9];
  uStack_ac = *(undefined4 *)(param_2 + 0x84);
  uStack_a8 = *(undefined4 *)(param_2 + 0x88);
  uStack_1c = CONCAT22((short)((uint)uStack_a8 >> 0x10),0x100);
  uStack_18 = 0;
  uStack_14 = uStack_a0 & 0xffff0000;
  uStack_20 = uStack_ac;
  if (*(uint *)(puStack_24[0x10d] + 0x44) < 2) {
    (**(code **)(*piVar2 + 0x34))(0,*(undefined4 *)(puStack_24[0x10d] + 4),&uStack_1c);
    pcVar4 = "LinearizeDepthFS";
  }
  else {
    (**(code **)(*piVar2 + 0x34))(4);
    pcVar4 = "LinearizeDepthAAFS";
  }
  uVar1 = (uint3)param_1;
  param_1 = (int *)(uint)(uVar1 & 0xff);
  uStack_18 = 0x1000100;
  uStack_1c = 0xf;
  uStack_14 = uStack_14 & 0xffffff00;
  FUN_0082a430(piVar2,*puStack_24,"PassThroughVS",pcVar4,auStack_bc,&uStack_1c,(int)&param_1 + 1);
  (**(code **)(*piVar2 + 0x18))();
  uStack_8 = 2;
  FUN_0152dda0(uStack_2c,uStack_28,uStack_34);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11441 ; VA 0x00799b60 ; FUN_00799b60 */

undefined4 * __thiscall
FUN_00799b60(undefined4 *param_1,undefined4 *param_2,int *param_3,undefined4 *param_4,
            undefined4 *param_5,int *param_6,undefined4 *param_7,int *param_8,undefined4 param_9,
            undefined4 param_10,char param_11,undefined4 param_12)

{
  int *piVar1;
  uint3 uVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined uVar5;
  int iVar6;
  undefined4 ****ppppuVar7;
  uint uVar8;
  uint uVar9;
  float fVar10;
  float fVar11;
  undefined8 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  char *pcVar15;
  char *pcVar16;
  undefined auStack_10c [68];
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 ***apppuStack_8c [4];
  undefined4 uStack_7c;
  uint uStack_78;
  undefined4 *puStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 uStack_68;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  int iStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  int *piStack_44;
  undefined4 *puStack_40;
  int *piStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined4 *puStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  ushort uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b1e67;
  pvStack_10 = ExceptionList;
  uStack_4c = 0;
  uStack_8 = 2;
  puStack_74 = param_1;
  if (*(char *)(param_1 + 1) == '\0') {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    param_2[1] = 0;
  }
  else {
    uVar8 = *(uint *)((int)param_4 + 0x30) >> 2;
    iStack_50 = *(int *)*param_1;
    if (uVar8 == 0) {
      uVar8 = 1;
    }
    uVar9 = *(uint *)((int)param_4 + 0x34) >> 2;
    if (uVar9 == 0) {
      uVar9 = 1;
    }
    ExceptionList = &pvStack_10;
    uStack_38 = uVar8;
    uStack_34 = uVar9;
    iVar6 = (**(code **)(**(int **)(iStack_50 + 0x3c) + 0x40))();
    piStack_2c = (int *)0x1b;
    if (*(char *)(iVar6 + 0x13) == '\0') {
      piStack_2c = (int *)0x3;
    }
    FUN_016f4053(&puStack_48,8,2,FUN_005502b0,FUN_00550b30);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_007994e0(&puStack_24,uVar8,uVar9,1,piStack_2c);
    piVar4 = piStack_44;
    puStack_48 = puStack_24;
    uStack_4c = 2;
    piStack_44 = piStack_20;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar6 = piVar4[1] + -1;
      piVar4[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar6 = piVar4[2] + -1;
        piVar4[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    FUN_007994e0(&puStack_24,uStack_38,uStack_34,1,piStack_2c);
    piVar4 = piStack_3c;
    puStack_40 = puStack_24;
    uStack_4c = 6;
    piStack_3c = piStack_20;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar6 = piVar4[1] + -1;
      piVar4[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar6 = piVar4[2] + -1;
        piVar4[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if ((puStack_48 != (undefined4 *)0x0) && (puStack_40 != (undefined4 *)0x0)) {
      iVar6 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
      if ((*(int *)(iVar6 + 0x34) < DAT_01eb1e20) &&
         (FUN_016f3809(&DAT_01eb1e20), DAT_01eb1e20 == -1)) {
        uStack_8._0_1_ = 4;
        uVar12 = FUN_0152dab0("Render","DownSample",0xffffffff);
        DAT_01eb1e1c = (undefined4)((ulonglong)uVar12 >> 0x20);
        DAT_01eb1e18 = (undefined4)uVar12;
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        FUN_016f37bf(&DAT_01eb1e20);
      }
      uVar13 = DAT_01eb1e18;
      piStack_2c = (int *)DAT_01eb1e1c;
      uStack_70 = DAT_01eb1e18;
      uStack_6c = DAT_01eb1e1c;
      uStack_68 = FUN_0152d930(DAT_01eb1e18,DAT_01eb1e1c);
      uStack_8._0_1_ = 5;
      if (*(int *)(iVar6 + 0x34) < DAT_01eb1e30) {
        FUN_016f3809(&DAT_01eb1e30);
        if (DAT_01eb1e30 == -1) {
          uStack_8._0_1_ = 6;
          uVar12 = FUN_0152dab0(&DAT_018fb928,"DownSample",0xffffffff);
          DAT_01eb1e2c = (undefined4)((ulonglong)uVar12 >> 0x20);
          DAT_01eb1e28 = (undefined4)uVar12;
          uStack_8._0_1_ = 5;
          FUN_016f37bf(&DAT_01eb1e30);
        }
      }
      uStack_34 = DAT_01eb1e28;
      uStack_38 = DAT_01eb1e2c;
      uStack_60 = DAT_01eb1e28;
      uStack_5c = DAT_01eb1e2c;
      uStack_58 = FUN_0152d930(DAT_01eb1e28,DAT_01eb1e2c);
      uStack_8._0_1_ = 7;
      FUN_00829d10(puStack_48[2]);
      (**(code **)(*param_3 + 0x14))(puStack_48[2],0,1,0,0);
      uStack_1c = CONCAT22(uStack_1c._2_2_,0x101);
      uStack_18 = 0;
      uStack_14 = 0;
      (**(code **)(*param_3 + 0x34))(0,param_4,&uStack_1c);
      uVar2 = (uint3)param_4;
      param_4 = (undefined4 *)(uint)(uVar2 & 0xff);
      puStack_24 = (undefined4 *)0x1000100;
      uStack_28 = 0xf;
      piStack_20 = (int *)((uint)piStack_20 & 0xffffff00);
      if (param_11 == '\0') {
        pcVar16 = "DownSample4x4AvgFS";
        pcVar15 = "DownSample4x4VS";
      }
      else {
        pcVar16 = "PassThroughFS";
        pcVar15 = "PassThroughVS";
      }
      FUN_0082a430(param_3,iStack_50,pcVar15,pcVar16,auStack_10c,&uStack_28,(int)&param_4 + 1);
      (**(code **)(*param_3 + 0x18))();
      uStack_8._0_1_ = 8;
      FUN_0152dda0(uStack_34,uStack_38,uStack_58);
      uStack_8._0_1_ = 9;
      FUN_0152dda0(uVar13,piStack_2c,uStack_68);
      if (piStack_44 != (int *)0x0) {
        LOCK();
        piStack_44[1] = piStack_44[1] + 1;
        UNLOCK();
      }
      param_4 = puStack_48;
      puStack_30 = puStack_48;
      piStack_2c = piStack_44;
      if (piStack_3c != (int *)0x0) {
        LOCK();
        piStack_3c[1] = piStack_3c[1] + 1;
        UNLOCK();
      }
      puStack_24 = puStack_40;
      piStack_20 = piStack_3c;
      uStack_8._0_1_ = 0xb;
      uVar5 = (undefined)uStack_8;
      uStack_8._0_1_ = 0xb;
      if ((param_5 != (undefined4 *)0x0) || (param_7 != (undefined4 *)0x0)) {
        if (*(int *)(iVar6 + 0x34) < DAT_01eb1e40) {
          uStack_8._0_1_ = uVar5;
          FUN_016f3809(&DAT_01eb1e40);
          if (DAT_01eb1e40 == -1) {
            uStack_8._0_1_ = 0xc;
            uVar12 = FUN_0152dab0("Render","FXCompositing",0xffffffff);
            DAT_01eb1e3c = (undefined4)((ulonglong)uVar12 >> 0x20);
            DAT_01eb1e38 = (undefined4)uVar12;
            uStack_8._0_1_ = 0xb;
            FUN_016f37bf(&DAT_01eb1e40);
          }
        }
        uStack_34 = DAT_01eb1e38;
        uStack_38 = DAT_01eb1e3c;
        uStack_60 = DAT_01eb1e38;
        uStack_5c = DAT_01eb1e3c;
        uVar12 = FUN_0152d930(DAT_01eb1e38,DAT_01eb1e3c);
        uStack_8._0_1_ = 0xd;
        uVar5 = (undefined)uStack_8;
        uStack_8._0_1_ = 0xd;
        uStack_58 = uVar12;
        if (*(int *)(iVar6 + 0x34) < DAT_01eb1e50) {
          uStack_8._0_1_ = uVar5;
          FUN_016f3809(&DAT_01eb1e50);
          if (DAT_01eb1e50 == -1) {
            uStack_8._0_1_ = 0xe;
            uVar12 = FUN_0152dab0(&DAT_018fb928,"FXCompositing",0xffffffff);
            DAT_01eb1e4c = (undefined4)((ulonglong)uVar12 >> 0x20);
            DAT_01eb1e48 = (undefined4)uVar12;
            uStack_8._0_1_ = 0xd;
            FUN_016f37bf(&DAT_01eb1e50);
          }
        }
        uVar3 = DAT_01eb1e48;
        param_4 = (undefined4 *)DAT_01eb1e4c;
        uStack_70 = DAT_01eb1e48;
        uStack_6c = DAT_01eb1e4c;
        uVar12 = FUN_0152d930(DAT_01eb1e48,DAT_01eb1e4c);
        iVar6 = iStack_50;
        uStack_8._0_1_ = 0xf;
        uVar13 = *(undefined4 *)(*(int *)(iStack_50 + 0x4ec) + 0x3c);
        uStack_68 = uVar12;
        FUN_00829d10(puStack_40[2]);
        uStack_c8 = param_9;
        uStack_c4 = 0x40200000;
        if (param_11 == '\0') {
          uStack_c4 = 0x3f800000;
        }
        uStack_c0 = param_10;
        (**(code **)(*param_3 + 0x14))(puStack_40[2],0,1,0,0);
        uStack_1c._0_2_ = 0x101;
        uStack_18 = 0;
        uStack_14 = 0;
        (**(code **)(*param_3 + 0x34))(0,*puStack_48,&uStack_1c);
        uStack_1c._0_2_ = 0x101;
        uStack_18 = 0;
        uStack_14 = 0;
        uVar14 = uVar13;
        if (param_7 != (undefined4 *)0x0) {
          uVar14 = *param_7;
        }
        (**(code **)(*param_3 + 0x34))(2,uVar14,&uStack_1c);
        uStack_1c = CONCAT22(uStack_1c._2_2_,0x101);
        uStack_18 = 0;
        uStack_14 = 0;
        if (param_5 != (undefined4 *)0x0) {
          uVar13 = *param_5;
        }
        (**(code **)(*param_3 + 0x34))(3,uVar13,&uStack_1c);
        uStack_7c = 0;
        uStack_78 = 0xf;
        apppuStack_8c[0] = (undefined4 ***)((uint)apppuStack_8c[0] & 0xffffff00);
        uStack_8._0_1_ = 0x10;
        if ((char)param_12 == '\0') {
          uVar13 = 0xf;
          pcVar15 = "FXCompositingFS";
        }
        else {
          uVar13 = 0x15;
          pcVar15 = "FXCompositingLinearFS";
        }
        FUN_005542c0(pcVar15,uVar13);
        param_12._1_2_ = 0;
        param_12._3_1_ = 0;
        uStack_18 = 0x1000100;
        ppppuVar7 = apppuStack_8c;
        if (0xf < uStack_78) {
          ppppuVar7 = (undefined4 ****)apppuStack_8c[0];
        }
        uStack_1c = 0xf;
        uStack_14 = uStack_14 & 0xff00;
        FUN_0082a430(param_3,iVar6,"PassThroughVS",ppppuVar7,auStack_10c,&uStack_1c,
                     (int)&param_12 + 1);
        (**(code **)(*param_3 + 0x18))();
        FUN_0056ecd0(&puStack_40);
        FUN_0056ecd0(&puStack_48);
        FUN_005507b0();
        uStack_8._0_1_ = 0x11;
        FUN_0152dda0(uVar3,param_4,uStack_68);
        uStack_8._0_1_ = 0x12;
        FUN_0152dda0(uStack_34,uStack_38,uStack_58);
      }
      piVar4 = piStack_2c;
      uStack_8._0_1_ = 0xb;
      fVar10 = DAT_018ce2f8;
      if (DAT_018ce2f8 <= (float)puStack_74[2] * DAT_018f993c) {
        fVar10 = (float)puStack_74[2] * DAT_018f993c;
      }
      fVar11 = DAT_018fde90;
      if (fVar10 <= DAT_018fde90) {
        fVar11 = fVar10;
      }
      fVar10 = DAT_018fde90;
      if (param_11 != '\0') {
        fVar10 = DAT_018df580;
      }
      param_4 = puStack_30;
      FUN_0082a540(param_3,*(undefined4 *)*puStack_74,*puStack_30,puStack_30[2],*puStack_24,
                   puStack_24[2],fVar11,fVar10);
      puStack_30 = (undefined4 *)0x0;
      piStack_2c = (int *)0x0;
      *param_2 = param_4;
      param_2[1] = piVar4;
      uStack_4c = 7;
      FUN_00550b30();
      FUN_00550b30();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_016f32d1(&puStack_48,8,2,FUN_00550b30);
      FUN_00550b30();
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return param_2;
    }
    *param_2 = 0;
    param_2[1] = 0;
    uStack_4c = 7;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_016f32d1(&puStack_48,8,2,FUN_00550b30);
  }
  piVar4 = param_6;
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar6 = param_6[1] + -1;
    param_6[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = param_8;
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar6 = param_8[1] + -1;
    param_8[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 11442 ; VA 0x0079a370 ; FUN_0079a370 */

int __thiscall
FUN_0079a370(int *param_1,undefined4 param_2,int param_3,float param_4,undefined4 param_5)

{
  int *piVar1;
  undefined4 uVar2;
  char cVar3;
  undefined4 *puVar4;
  uint *puVar5;
  int *piVar6;
  int iVar7;
  int iVar8;
  float10 fVar9;
  double dVar10;
  float fVar11;
  undefined8 uVar12;
  undefined auStack_88 [16];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined uStack_64;
  undefined2 uStack_63;
  undefined uStack_61;
  int *piStack_60;
  int *piStack_5c;
  undefined8 uStack_58;
  undefined4 uStack_4c;
  int *piStack_48;
  int *piStack_44;
  int *piStack_40;
  int *piStack_38;
  int *piStack_34;
  int iStack_30;
  undefined4 *puStack_2c;
  int *piStack_28;
  char cStack_21;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017b1ecc;
  pvStack_1c = ExceptionList;
  iVar8 = *(int *)(*param_1 + 0x4fc);
  piStack_44 = *(int **)(*param_1 + 0x524);
  ExceptionList = &pvStack_1c;
  piStack_34 = param_1;
  iStack_30 = iVar8;
  cVar3 = FUN_01156450();
  piStack_40 = (int *)(uint)(cVar3 != '\0');
  if ((*(float *)(*param_1 + 0x594) <= DAT_018ce2f8) || (DAT_01d60fd0 != '\0')) {
    puStack_2c = (undefined4 *)param_4;
    piStack_28 = (int *)param_3;
  }
  else if (DAT_01d60fe0 == '\0') {
    if (DAT_01d60fd8 == '\0') {
      piStack_28 = (int *)FUN_016f3cd0();
      puStack_2c = (undefined4 *)FUN_016f3cd0();
    }
    else {
      piStack_28 = (int *)FUN_016f3cd0();
      puStack_2c = (undefined4 *)FUN_016f3cd0();
    }
  }
  else {
    fVar9 = (float10)FUN_01156400();
    puStack_2c = (undefined4 *)(float)fVar9;
    piStack_28 = (int *)FUN_016f3cd0();
    puStack_2c = (undefined4 *)FUN_016f3cd0();
  }
  piStack_38 = (int *)FUN_01156c00();
  if (DAT_01eb1ce0 != 0) {
    piStack_38 = (int *)DAT_01eb1ce0;
  }
  if (((*(int **)param_1[0x10d] != (int *)0x0) && (iVar7 = **(int **)param_1[0x10d], iVar7 != 0)) &&
     (((int *)*(int *)(iVar7 + 0x30) != piStack_28 ||
      ((undefined4 *)*(float *)(iVar7 + 0x34) != puStack_2c)))) {
    iVar8 = param_1[0x10c];
    puVar4 = (undefined4 *)(iVar8 + 4);
    FUN_005596d0(*puVar4,*(undefined4 *)(iVar8 + 8),puVar4);
    *(undefined4 *)(iVar8 + 8) = *puVar4;
    iVar8 = iStack_30;
  }
  FUN_007a0eb0(piStack_28,puStack_2c,piStack_40,piStack_38,*(undefined4 *)(*param_1 + 0x5c4));
  if (param_1[0x10] == 0) {
    FUN_0081b8a0();
  }
  else if (param_1[0x10] == 1) {
    FUN_008201e0();
  }
  if ((DAT_01d60fb8 != '\0') && (*(char *)((int)param_1 + 0x3d) != '\0')) {
    FUN_00822c20();
  }
  FUN_00829290(param_2,*(undefined8 *)(param_1 + 0x120));
  fVar11 = DAT_018ce2f8;
  piStack_60 = (int *)0x0;
  piStack_5c = (int *)0x0;
  uStack_58._0_4_ = 0;
  uStack_58._4_4_ = 0;
  piStack_44[0x14] = 0;
  piStack_44[0x15] = 0;
  piStack_44[0x16] = 0;
  piStack_44[0x17] = 0;
  piStack_44[0x10] = 0;
  piStack_44[0x11] = 0;
  piStack_44[0x12] = 0;
  piStack_44[0x13] = 0;
  piStack_44[0xc] = 0;
  piStack_44[0xd] = 0;
  piStack_44[0xe] = 0;
  piStack_44[0xf] = 0;
  piStack_44[8] = 0;
  piStack_44[9] = 0;
  piStack_44[10] = 0;
  piStack_44[0xb] = 0;
  piStack_44[4] = 0;
  piStack_44[5] = 0;
  piStack_44[6] = 0;
  piStack_44[7] = 0;
  *piStack_44 = 0;
  piStack_44[1] = 0;
  piStack_44[2] = 0;
  piStack_44[3] = 0;
  param_1[0x71] =
       (int)(fVar11 / (float)((double)(int)piStack_28 +
                             (double)(&DAT_018c0d90)[-((int)piStack_28 >> 0x1f)]) +
            fVar11 / (float)((double)(int)puStack_2c +
                            (double)(&DAT_018c0d90)[-((int)puStack_2c >> 0x1f)]));
  FUN_00833c00();
  cVar3 = FUN_0078b7c0();
  if (cVar3 == '\0') {
    param_1[299] = param_1[0x12a];
  }
  else {
    param_1[8] = param_1[7];
    fVar9 = (float10)FUN_01156f90();
    FUN_00798860(param_5,(float)fVar9);
  }
  param_1[8] = param_1[7];
  if (DAT_01d60f68 == '\0') {
    fVar9 = (float10)FUN_00855cb0();
    piStack_44 = (int *)(float)fVar9;
    FUN_00817870(param_1 + 7,param_5,param_1 + 1,piStack_44);
    puVar5 = (uint *)(param_1 + 7);
    param_1[4] = *(int *)(param_1[6] + 0x30);
  }
  else {
    uVar2 = *(undefined4 *)(iVar8 + 0x160);
    fVar9 = (float10)FUN_01156be0();
    piStack_44 = (int *)(float)fVar9;
    puVar5 = (uint *)(piStack_34 + 7);
    FUN_008173d0(puVar5,param_5,piStack_34 + 1,piStack_34[5],piStack_44,uVar2);
    param_1 = piStack_34;
    piStack_34[4] = *(int *)(piStack_34[6] + 0x30);
    fVar11 = *(float *)(piStack_34[6] + 0x34);
    puStack_2c = (undefined4 *)fVar11;
    if (DAT_01d60fa0 != '\0') {
      fVar9 = (float10)FUN_00816d90(fVar11,piStack_34[5]);
      piStack_44 = (int *)(float)fVar9;
      param_1[5] = (int)piStack_44;
      if ((NAN((float)piStack_44) || NAN((float)puStack_2c)) !=
          ((float)piStack_44 == (float)puStack_2c)) goto LAB_0079a82d;
      fVar9 = (float10)FUN_016973e0();
      dVar10 = (double)(float)param_1[5];
      piStack_40 = (int *)(float)fVar9;
      FUN_017267a0();
      piStack_44 = (int *)(float)dVar10;
      dVar10 = (double)(float)puStack_2c;
      FUN_017267a0();
      fVar11 = ((float)piStack_44 - (float)dVar10) * (float)piStack_40 + (float)dVar10;
      fVar11 = fVar11 * fVar11;
    }
    param_1[5] = (int)fVar11;
  }
LAB_0079a82d:
  FUN_007cbaa0(param_2,puVar5,param_1 + 0x12a);
  piStack_38 = *(int **)((int)ThreadLocalStoragePointer + _tls_index * 4);
  if ((piStack_38[0xd] < DAT_01eb2120) && (FUN_016f3809(), DAT_01eb2120 == -1)) {
    uStack_14 = 0;
    uVar12 = FUN_0152dab0("Render","updateRenderQueue",0xffffffff);
    DAT_01eb211c = (int *)((ulonglong)uVar12 >> 0x20);
    DAT_01eb2118 = (int *)uVar12;
    uStack_14 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb2120);
  }
  piStack_48 = DAT_01eb2118;
  piStack_60 = DAT_01eb2118;
  piStack_40 = DAT_01eb211c;
  piStack_5c = DAT_01eb211c;
  uStack_58 = FUN_0152d930(DAT_01eb2118,DAT_01eb211c);
  uStack_14 = 1;
  if (*(char *)(param_1 + 0xd) == '\0') {
LAB_0079a8a7:
    cStack_21 = '\0';
    if (param_1[0xe] == 0) goto LAB_0079a8b5;
  }
  else {
    cVar3 = FUN_0078b7c0();
    if (cVar3 == '\0') goto LAB_0079a8a7;
  }
  cStack_21 = '\x01';
LAB_0079a8b5:
  puStack_2c = (undefined4 *)*puVar5;
  piStack_44 = (int *)((uint)((int)puVar5[1] + (3 - (int)puStack_2c)) >> 2);
  piStack_28 = (int *)0x0;
  if ((undefined4 *)puVar5[1] < puStack_2c) {
    piStack_44 = (int *)0x0;
  }
  if (piStack_44 != (int *)0x0) {
    do {
      piVar6 = (int *)*puStack_2c;
      (**(code **)(*piVar6 + 4))(param_1[10],param_5,0);
      if (cStack_21 != '\0') {
        (**(code **)(*piVar6 + 4))(param_1[0xc]);
      }
      piStack_28 = (int *)((int)piStack_28 + 1);
      puStack_2c = puStack_2c + 1;
    } while (piStack_28 != piStack_44);
  }
  uStack_14 = 2;
  FUN_0152dda0(piStack_48,piStack_40,uStack_58);
  uStack_14 = 0xffffffff;
  if (DAT_01d60f68 == '\0') {
    fVar9 = (float10)FUN_00855cb0();
    param_1[5] = (int)(float)fVar9;
  }
  FUN_00833940();
  FUN_0082f190(param_1[10],param_2);
  FUN_0082f9c0();
  FUN_0082f870();
  piStack_48 = *(int **)(*param_1 + 0x578);
  if (piStack_48 != (int *)0x0) {
    if (piStack_38[0xd] < DAT_01eb2130) {
      FUN_016f3809();
      if (DAT_01eb2130 == -1) {
        uStack_14 = 3;
        uVar12 = FUN_0152dab0("Render","debugOverlay",0xffffffff);
        DAT_01eb212c = (int *)((ulonglong)uVar12 >> 0x20);
        DAT_01eb2128 = (int *)uVar12;
        uStack_14 = 0xffffffff;
        FUN_016f37bf(&DAT_01eb2130);
      }
    }
    piStack_40 = DAT_01eb2128;
    piStack_60 = DAT_01eb2128;
    piStack_44 = DAT_01eb212c;
    piStack_5c = DAT_01eb212c;
    uVar12 = FUN_0152d930(DAT_01eb2128,DAT_01eb212c);
    uStack_63 = 0;
    auStack_88 = ZEXT816(0);
    uStack_61 = 0;
    uStack_14 = 4;
    uStack_78 = 0;
    uStack_74 = 0;
    uStack_70 = 0;
    uStack_6c = 0;
    uStack_68 = 0;
    uStack_64 = 0;
    uStack_58 = uVar12;
    (**(code **)(*piStack_48 + 0x14))(*piStack_34,auStack_88);
    uStack_14 = 5;
    FUN_0152dda0(piStack_40,piStack_44,uVar12);
    uStack_14 = 0xffffffff;
    param_1 = piStack_34;
  }
  FUN_0078af00();
  FUN_007fab80();
  FUN_0078ae30();
  FUN_00803ff0();
  FUN_007a0d20();
  piVar6 = (int *)param_1[0xc];
  if (piVar6 != (int *)0x0) {
    if (piStack_38[0xd] < DAT_01eb1ee0) {
      FUN_016f3809();
      if (DAT_01eb1ee0 == -1) {
        uStack_14 = 6;
        uVar12 = FUN_0152dab0("Render","sortObjects",0xffffffff);
        DAT_01eb1edc = (int *)((ulonglong)uVar12 >> 0x20);
        DAT_01eb1ed8 = (int *)uVar12;
        uStack_14 = 0xffffffff;
        FUN_016f37bf(&DAT_01eb1ee0);
      }
    }
    piStack_44 = DAT_01eb1ed8;
    piStack_60 = DAT_01eb1ed8;
    piStack_48 = DAT_01eb1edc;
    piStack_5c = DAT_01eb1edc;
    uVar12 = FUN_0152d930(DAT_01eb1ed8,DAT_01eb1edc);
    uStack_14 = 7;
    iVar8 = 0xf;
    do {
      iVar7 = piVar6[1] - *piVar6 >> 0x1f;
      if ((piVar6[1] - *piVar6) / 0x18 + iVar7 != iVar7) {
        uStack_58 = uVar12;
        FUN_007f6480();
        uVar12 = uStack_58;
      }
      piVar6 = piVar6 + 3;
      iVar8 = iVar8 + -1;
    } while (iVar8 != 0);
    uStack_14 = 8;
    uStack_58 = uVar12;
    FUN_0152dda0(piStack_44,piStack_48,uVar12);
    uStack_14 = 0xffffffff;
    param_1 = piStack_34;
  }
  iVar8 = iStack_30;
  if (DAT_01d60f98 != '\0') {
    piStack_44 = (int *)FUN_01156ce0();
    piStack_48 = *(int **)(param_1[0x10d] + 0x40);
    cVar3 = FUN_0078b680();
    if (cVar3 != '\0') {
      piStack_38 = (int *)param_1[0x111];
      if ((((*(char *)(piStack_38 + 0x16) != '\0') &&
           ((NAN((float)piStack_38[0x15]) == ((float)piStack_38[0x15] == 0.0) ||
            ((*(char *)(piStack_38 + 0x16) != '\0' &&
             (NAN((float)piStack_38[0x14]) == ((float)piStack_38[0x14] == 0.0))))))) &&
          (piStack_48 == (int *)0x1)) && (piStack_44 == (int *)0x3)) {
        FUN_01165e00();
        FUN_00816c00();
      }
    }
  }
  if (*(int *)(*param_1 + 0x574) == 0) {
    iVar7 = param_1[0x117];
    if (((iVar7 == 0) || (*(int *)(iVar8 + 0x14) < 0xe)) &&
       ((iVar7 = param_1[0x116], iVar7 == 0 || (*(int *)(iVar8 + 0x14) < 6)))) {
      iVar7 = param_1[0x115];
    }
    if (iVar7 != 0) {
      FUN_0079c970(param_2,iVar7);
      iVar8 = FUN_00773ad0();
      ExceptionList = pvStack_1c;
      return iVar8;
    }
    param_1[0x78] = 0;
    uStack_4c = 0;
    piStack_48 = (int *)0x0;
    uStack_14 = 9;
    iVar8 = FUN_00773ad0();
    piVar6 = piStack_48;
  }
  else {
    param_1[0x77] = 0;
    param_1[0x78] = 0;
    FUN_00773ad0();
    (**(code **)(**(int **)(*param_1 + 0x574) + 0x18))();
    uStack_14 = 10;
    iVar8 = FUN_00773ad0();
    piVar6 = piStack_38;
  }
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar1 = piVar6 + 1;
    iVar7 = *piVar1;
    iVar8 = *piVar1;
    *piVar1 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      iVar8 = (**(code **)*piVar6)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        iVar8 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return iVar8;
}



/* FUNCTION 11443 ; VA 0x0079add0 ; FUN_0079add0 */

void __fastcall FUN_0079add0(int *param_1)

{
  int *piVar1;
  
  piVar1 = *(int **)(*param_1 + 0x524);
  if (param_1[0xc] != 0) {
    FUN_007f63a0();
  }
  FUN_007f63a0();
  if (param_1[0xc] != 0) {
    FUN_007f63a0();
  }
  FUN_0078af00();
  FUN_007fa660();
  *piVar1 = piVar1[0x14] + piVar1[0x10] + piVar1[0xc] + piVar1[4] + piVar1[8];
  piVar1[1] = piVar1[5] + piVar1[9] + piVar1[0xd] + piVar1[0x11] + piVar1[0x15];
  piVar1[2] = piVar1[6] + piVar1[10] + piVar1[0xe] + piVar1[0x12] + piVar1[0x16];
  piVar1[3] = piVar1[7] + piVar1[0xb] + piVar1[0xf] + piVar1[0x13] + piVar1[0x17];
  return;
}



/* FUNCTION 11444 ; VA 0x0079aeb0 ; FUN_0079aeb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0079aeb0(int *param_1,int *param_2,float param_3)

{
  undefined8 uVar1;
  undefined8 uVar2;
  bool bVar3;
  uint3 uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  int *piVar9;
  undefined4 uVar10;
  float *pfVar11;
  undefined4 *puVar12;
  undefined *puVar13;
  int iVar14;
  int *piVar15;
  int *piVar16;
  undefined8 uVar17;
  int aiStack_4c4 [212];
  undefined auStack_174 [16];
  float fStack_164;
  float fStack_160;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_fc;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined8 uStack_ec;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined8 uStack_dc;
  int iStack_d4;
  int *piStack_d0;
  int iStack_cc;
  int iStack_c8;
  uint uStack_c4;
  int iStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined8 uStack_b4;
  int iStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  int iStack_9c;
  int iStack_98;
  int *piStack_94;
  float fStack_90;
  int iStack_8c;
  int *piStack_88;
  undefined4 *puStack_84;
  int *piStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  int *piStack_54;
  int iStack_50;
  uint uStack_4c;
  int iStack_48;
  int iStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  int iStack_34;
  undefined8 uStack_30;
  uint uStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b1f75;
  pvStack_10 = ExceptionList;
  iVar14 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  piStack_54 = param_1;
  if (*(int *)(iVar14 + 0x34) < DAT_01eb1ff0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb1ff0);
    if (DAT_01eb1ff0 == -1) {
      uStack_8 = 0;
      uVar17 = FUN_0152dab0(&DAT_018fb928,"GuiScene",0xffffffff);
      DAT_01eb1fec = (undefined4)((ulonglong)uVar17 >> 0x20);
      DAT_01eb1fe8 = (undefined4)uVar17;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb1ff0);
    }
  }
  uStack_a8 = DAT_01eb1fe8;
  uStack_f4 = DAT_01eb1fe8;
  uStack_b8 = DAT_01eb1fec;
  uStack_f0 = DAT_01eb1fec;
  uStack_ec = FUN_0152d930(DAT_01eb1fe8,DAT_01eb1fec);
  uStack_8 = 1;
  if (*(int *)(iVar14 + 0x34) < DAT_01eb2000) {
    FUN_016f3809(&DAT_01eb2000);
    if (DAT_01eb2000 == -1) {
      uStack_8._0_1_ = 2;
      uVar17 = FUN_0152dab0("Render","GuiScene",0xffffffff);
      DAT_01eb1ffc = (undefined4)((ulonglong)uVar17 >> 0x20);
      DAT_01eb1ff8 = (undefined4)uVar17;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eb2000);
    }
  }
  uStack_bc = DAT_01eb1ff8;
  uStack_e4 = DAT_01eb1ff8;
  uStack_a4 = DAT_01eb1ffc;
  uStack_e0 = DAT_01eb1ffc;
  uStack_dc = FUN_0152d930(DAT_01eb1ff8,DAT_01eb1ffc);
  uStack_8._0_1_ = 3;
  uVar10 = FUN_01675290(DAT_01eb3ab0);
  uStack_8._0_1_ = 4;
  uStack_a0 = uVar10;
  uStack_4c = FUN_01156c00(*(undefined4 *)(*param_1 + 0x594));
  if (DAT_01eb1ce0 != 0) {
    uStack_4c = DAT_01eb1ce0;
  }
  if ((*(char *)((int)param_3 + 0x75) == '\0') || (*(uint *)((int)param_3 + 0x314) < uStack_4c)) {
    FUN_00819480(1);
    FUN_008196b0(&iStack_8c);
    uStack_8._0_1_ = 8;
    if (iStack_8c != 0) {
      *(uint *)((int)param_3 + 0x314) = uStack_4c;
      iStack_44 = (int)(short)*(undefined4 *)((int)param_3 + 0x2c4);
      iStack_48 = (int)(short)((uint)*(undefined4 *)((int)param_3 + 0x2c4) >> 0x10);
      FUN_00798fe0(&iStack_d4,iStack_44,iStack_48,uStack_4c);
      uStack_8._0_1_ = 0xc;
      FUN_00798fe0(&puStack_84,iStack_44,iStack_48,1);
      if ((iStack_d4 != 0) && (puStack_84 != (undefined4 *)0x0)) {
        iStack_c8 = *(int *)(iStack_d4 + 0x14);
        if (iStack_c8 != 0) {
          LOCK();
          *(int *)(iStack_c8 + 4) = *(int *)(iStack_c8 + 4) + 1;
          UNLOCK();
          iStack_c8 = *(int *)(iStack_d4 + 0x14);
        }
        iStack_cc = *(int *)(iStack_d4 + 0x10);
        iStack_c0 = puStack_84[5];
        if (iStack_c0 != 0) {
          LOCK();
          *(int *)(iStack_c0 + 4) = *(int *)(iStack_c0 + 4) + 1;
          UNLOCK();
          iStack_c0 = puStack_84[5];
        }
        uStack_c4 = puStack_84[4];
        iStack_14 = *(int *)(*param_1 + 0x4ec);
        puVar12 = (undefined4 *)&DAT_01eb1b04;
        if ((undefined4 *)param_1[0x11b] != (undefined4 *)0x0) {
          puVar12 = (undefined4 *)param_1[0x11b];
        }
        if (puVar12[1] != 0) {
          LOCK();
          piVar15 = (int *)(puVar12[1] + 4);
          *piVar15 = *piVar15 + 1;
          UNLOCK();
        }
        uStack_64 = *puVar12;
        uStack_60 = puVar12[1];
        puVar12 = (undefined4 *)&DAT_01eb1b04;
        if ((undefined4 *)param_1[0x11d] != (undefined4 *)0x0) {
          puVar12 = (undefined4 *)param_1[0x11d];
        }
        if (puVar12[1] != 0) {
          LOCK();
          piVar15 = (int *)(puVar12[1] + 4);
          *piVar15 = *piVar15 + 1;
          UNLOCK();
        }
        uStack_5c = *puVar12;
        uStack_58 = puVar12[1];
        uStack_8._0_1_ = 0x14;
        iStack_50 = iStack_cc;
        uStack_4c = uStack_c4;
        FUN_00773ad0(iStack_14 + 0x24);
        FUN_00773ad0(iStack_14 + 0x34);
        uStack_7c = 0;
        uStack_78 = 0;
        uStack_74 = 0;
        uStack_70 = 0;
        uStack_6c = 0;
        uStack_68 = 0;
        uStack_8._0_1_ = 0x17;
        puVar13 = &DAT_01eb1b04;
        if (*(undefined **)(param_1[0x113] + 0x118) != (undefined *)0x0) {
          puVar13 = *(undefined **)(param_1[0x113] + 0x118);
        }
        FUN_0056ecd0(puVar13);
        puVar13 = &DAT_01eb1b04;
        if (*(undefined **)(param_1[0x113] + 0x84) != (undefined *)0x0) {
          puVar13 = *(undefined **)(param_1[0x113] + 0x84);
        }
        FUN_0056ecd0(puVar13);
        puVar13 = &DAT_01eb1b04;
        if (*(undefined **)(param_1[0x113] + 0x94) != (undefined *)0x0) {
          puVar13 = *(undefined **)(param_1[0x113] + 0x94);
        }
        FUN_0056ecd0(puVar13);
        iVar14 = iStack_14;
        FUN_00773ad0(iStack_14 + 100);
        FUN_00773ad0(iVar14 + 0x5c);
        FUN_00773ad0(iVar14 + 0x5c);
        uVar8 = (uint)param_3;
        param_1 = param_1 + 0x15;
        piVar15 = param_1;
        piVar16 = aiStack_4c4;
        piStack_94 = param_1;
        for (iVar14 = 0xd4; piVar9 = piStack_54, iVar14 != 0; iVar14 = iVar14 + -1) {
          *piVar16 = *piVar15;
          piVar15 = piVar15 + 1;
          piVar16 = piVar16 + 1;
        }
        iStack_98 = piStack_54[0xe9];
        iStack_ac = *(int *)((int)param_3 + 0x2ec);
        iStack_9c = piStack_54[0xea];
        uVar17 = *(undefined8 *)((int)param_3 + 0x2e4);
        uVar1 = *(undefined8 *)((int)param_3 + 0x2f0);
        iStack_34 = *(int *)((int)param_3 + 0x2f8);
        uVar2 = *(undefined8 *)((int)param_3 + 0x2d8);
        uStack_30._0_4_ = (int)uVar2;
        uStack_30._4_4_ = (int)((ulonglong)uVar2 >> 0x20);
        uStack_28 = *(uint *)((int)param_3 + 0x2e0);
        param_3 = DAT_018ce2f8;
        piStack_54[0x35] = (int)uStack_30;
        piStack_54[0x36] = uStack_30._4_4_;
        piStack_54[0x37] = uStack_28;
        piStack_54[0x38] = 0x3f800000;
        iVar6 = _UNK_018f99ac;
        iVar5 = _UNK_018f99a8;
        iVar14 = _UNK_018f99a4;
        piStack_54[0x39] = _DAT_018f99a0;
        piStack_54[0x3a] = iVar14;
        piStack_54[0x3b] = iVar5;
        piStack_54[0x3c] = iVar6;
        uStack_b4._0_4_ = (int)uVar17;
        uStack_b4._4_4_ = (int)((ulonglong)uVar17 >> 0x20);
        iStack_18 = 0;
        piStack_54[0x3d] = (int)uStack_b4;
        piStack_54[0x3e] = uStack_b4._4_4_;
        piStack_54[0x3f] = iStack_ac;
        piStack_54[0x40] = 0x3f800000;
        uStack_3c._0_4_ = (float)uVar1;
        fStack_24 = (float)uStack_3c;
        uStack_3c._4_4_ = (int)((ulonglong)uVar1 >> 0x20);
        fStack_20 = (float)uStack_3c._4_4_;
        piStack_54[0x41] = (int)(float)uStack_3c;
        piStack_54[0x42] = uStack_3c._4_4_;
        piStack_54[0x43] = iStack_34;
        piStack_54[0x44] = 0;
        iVar6 = _UNK_018f99ac;
        iVar5 = _UNK_018f99a8;
        iVar14 = _UNK_018f99a4;
        piStack_54[0x45] = _DAT_018f99a0;
        piStack_54[0x46] = iVar14;
        piStack_54[0x47] = iVar5;
        piStack_54[0x48] = iVar6;
        iVar6 = _UNK_018fb58c;
        iVar5 = _UNK_018fb588;
        iVar14 = _UNK_018fb584;
        piStack_54[0x79] = _DAT_018fb580;
        piStack_54[0x7a] = iVar14;
        piStack_54[0x7b] = iVar5;
        piStack_54[0x7c] = iVar6;
        iVar6 = _UNK_018fb58c;
        iVar5 = _UNK_018fb588;
        iVar14 = _UNK_018fb584;
        piStack_54[0x7d] = _DAT_018fb580;
        piStack_54[0x7e] = iVar14;
        piStack_54[0x7f] = iVar5;
        piStack_54[0x80] = iVar6;
        uStack_b4 = uVar17;
        uStack_3c = uVar1;
        uStack_30 = uVar2;
        fStack_1c = (float)iStack_34;
        FUN_00829500(param_1);
        iStack_14 = piVar9[0x50];
        uStack_3c = 0x3f4000003f400000;
        iStack_34 = 0x3f400000;
        pfVar11 = (float *)FUN_0115e8f0(&uStack_3c);
        fStack_24 = *pfVar11;
        fStack_20 = pfVar11[1];
        fStack_1c = pfVar11[2];
        iStack_18 = iStack_14;
        piVar9[0x4d] = (int)fStack_24;
        piVar9[0x4e] = (int)fStack_20;
        piVar9[0x4f] = (int)fStack_1c;
        piVar9[0x50] = iStack_14;
        piVar9[0x49] = 0x3f800000;
        piVar9[0x4a] = 0;
        piVar9[0x4b] = -0x48d83a54;
        piVar9[0x4c] = 0x3f800000;
        piVar9[0xe9] = 0x47c35000;
        piVar9[0xea] = 0x3727c5ac;
        FUN_007ce460(uVar8 + 0x80);
        iVar7 = _UNK_018f99ac;
        iVar6 = _UNK_018f99a8;
        iVar5 = _UNK_018f99a4;
        iVar14 = _DAT_018f99a0;
        piVar9[0x51] = 0x40800000;
        piVar9[0x52] = 0x3e800000;
        piVar9[0x53] = 0x3e800000;
        piVar9[0x55] = iVar14;
        piVar9[0x56] = iVar5;
        piVar9[0x57] = iVar6;
        piVar9[0x58] = iVar7;
        uStack_40 = 0;
        piVar9[0x59] = 0;
        piVar9[0x5a] = 0;
        piVar9[0x5b] = 0;
        piVar9[0x5c] = 0;
        piVar9[0x5d] = 0;
        piVar9[0x5e] = 0;
        piVar9[0x5f] = 0;
        piVar9[0x60] = 0;
        iVar6 = _UNK_018fdeac;
        iVar5 = _UNK_018fdea8;
        iVar14 = _UNK_018fdea4;
        piVar9[0x61] = _DAT_018fdea0;
        piVar9[0x62] = iVar14;
        piVar9[99] = iVar5;
        piVar9[100] = iVar6;
        uStack_3c = 0;
        iStack_34 = 0;
        fStack_90 = param_3 / (float)iStack_48;
        param_3 = param_3 / (float)iStack_44;
        piVar9[0x71] = (int)(param_3 + fStack_90);
        FUN_00819cb0(piVar9[10],uVar8 + 0x80,0);
        FUN_007a0d20(piVar9[10]);
        if ((DAT_01d60f90 != '\0') && (piVar9[0xe] != 0)) {
          FUN_00819cb0(piVar9[0xc],uVar8 + 0x80,3);
          FUN_007a0d20(piVar9[0xc]);
        }
        iStack_14 = piVar9[0xe];
        FUN_0147bca0();
        uStack_13c = *(undefined4 *)(uVar8 + 0x2c8);
        uStack_138 = *(undefined4 *)(uVar8 + 0x2cc);
        uStack_134 = *(undefined4 *)(uVar8 + 0x2d0);
        uStack_130 = *(undefined4 *)(uVar8 + 0x2d4);
        uStack_140 = 0x11;
        uStack_fc = 0;
        bVar3 = *(uint *)(iStack_50 + 0x30) < 2;
        if (bVar3) {
          iVar14 = 0;
        }
        else {
          FUN_005502b0();
          iVar14 = (int)&uStack_30 + 4;
          uStack_30 = CONCAT44(1,(int)uStack_30);
          uStack_28 = uStack_4c;
        }
        (**(code **)(*param_2 + 0x14))(iStack_50,0,bVar3,&uStack_140,iVar14);
        (**(code **)(*param_2 + 0x1c))(0,0,iStack_44,iStack_48);
        FUN_0078a4a0(param_2);
        fStack_24 = param_3;
        fStack_20 = fStack_90;
        fStack_1c = 0.0;
        iStack_18 = 0;
        piVar9[0xc9] = (int)param_3;
        piVar9[0xca] = (int)fStack_90;
        piVar9[0xcb] = 0;
        piVar9[0xcc] = 0;
        FUN_0078b680();
        piVar9[0x54] = 0;
        FUN_007a0ae0(1 < *(uint *)(iStack_50 + 0x30));
        (**(code **)(*param_2 + 0x30))(0,piVar9 + 0x15,0x350);
        if ((DAT_01d60f90 != '\0') && (iStack_14 == 1)) {
          uVar10 = FUN_00795420(&fStack_24);
          FUN_0079bb50(param_2,piVar9[0xc] + 0x3c,&uStack_40,uVar10,0,0);
        }
        uVar10 = FUN_00793c80(&fStack_24);
        FUN_0079bb50(param_2,piVar9[10],&uStack_40,uVar10,0,0);
        uVar10 = FUN_00794820(&fStack_24);
        FUN_0079bb50(param_2,piVar9[10] + 0x24,&uStack_40,uVar10,0,0);
        uVar10 = FUN_00794520(&fStack_24);
        FUN_0079bb50(param_2,piVar9[10] + 0x18,&uStack_40,uVar10,0,0);
        if ((DAT_01d60f90 != '\0') && (iStack_14 == 2)) {
          uVar10 = FUN_007951e0(&fStack_24);
          FUN_0079bb50(param_2,piVar9[0xc] + 0x3c,&uStack_40,uVar10,0,0);
        }
        uVar10 = FUN_007949a0(&fStack_24);
        FUN_0079bb50(param_2,piVar9[10] + 0x3c,&uStack_40,uVar10,0,0);
        uVar10 = FUN_00793b00(&fStack_24);
        FUN_0079bb50(param_2,piVar9[10] + 0x54,&uStack_40,uVar10,0,0);
        uVar10 = FUN_00794ca0(&fStack_24);
        FUN_0079bb50(param_2,piVar9[10] + 0x60,&uStack_40,uVar10,0,0);
        uVar10 = FUN_00795120(&fStack_24);
        FUN_0079bb50(param_2,piVar9[10] + 0x6c,&uStack_40,uVar10,0,0);
        uVar10 = FUN_00795720(&fStack_24);
        FUN_0079bb50(param_2,piVar9[10] + 0x78,&uStack_40,uVar10,0,0);
        (**(code **)(*param_2 + 0x18))();
        (**(code **)(*param_2 + 0x14))(iStack_8c,0,1,0,0);
        FUN_00829d10(iStack_8c);
        uStack_30 = CONCAT62(uStack_30._2_6_,0x101);
        uStack_30 = uStack_30 & 0xffffffff;
        uStack_28 = uStack_28 & 0xffff0000;
        fStack_164 = (float)iStack_44 /
                     (float)((double)*(int *)(uStack_4c + 0x28) +
                            (double)(&DAT_018c0d90)[-(*(int *)(uStack_4c + 0x28) >> 0x1f)]);
        fStack_160 = (float)iStack_48 /
                     (float)((double)*(int *)(uStack_4c + 0x2c) +
                            (double)(&DAT_018c0d90)[-(*(int *)(uStack_4c + 0x2c) >> 0x1f)]);
        (**(code **)(*param_2 + 0x34))(0,*puStack_84,&uStack_30);
        uVar4 = SUB43(param_3,0);
        param_3 = (float)(uint)(uVar4 & 0xff);
        uStack_30 = 0x10001000000000f;
        uStack_28 = uStack_28 & 0xffffff00;
        FUN_0082a430(param_2,*piVar9,"CopyGuiVS","ProcessGuiFS",auStack_174,&uStack_30,
                     (int)&param_3 + 1);
        (**(code **)(*param_2 + 0x18))();
        FUN_007f63a0();
        if ((DAT_01d60f90 != '\0') && (piVar9[0xc] != 0)) {
          FUN_007f63a0();
        }
        FUN_00773ad0(&uStack_64);
        FUN_00773ad0(&uStack_5c);
        FUN_00773ad0(&uStack_7c);
        FUN_00773ad0(&uStack_74);
        FUN_00773ad0(&uStack_6c);
        piVar15 = aiStack_4c4;
        piVar16 = piStack_94;
        for (iVar14 = 0xd4; iVar14 != 0; iVar14 = iVar14 + -1) {
          *piVar16 = *piVar15;
          piVar15 = piVar15 + 1;
          piVar16 = piVar16 + 1;
        }
        piStack_54[0xe9] = iStack_98;
        piStack_54[0xea] = iStack_9c;
        FUN_00550b30();
        FUN_00550b30();
        FUN_00550b30();
        FUN_00550b30();
        FUN_00550b30();
        FUN_00550b30();
        FUN_00550b30();
        uVar10 = uStack_a0;
      }
      if (piStack_80 != (int *)0x0) {
        LOCK();
        iVar14 = piStack_80[1] + -1;
        piStack_80[1] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)*piStack_80)();
          LOCK();
          iVar14 = piStack_80[2] + -1;
          piStack_80[2] = iVar14;
          UNLOCK();
          if (iVar14 == 0) {
            (**(code **)(*piStack_80 + 4))();
          }
        }
      }
      if (piStack_d0 != (int *)0x0) {
        LOCK();
        iVar14 = piStack_d0[1] + -1;
        piStack_d0[1] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)*piStack_d0)();
          LOCK();
          iVar14 = piStack_d0[2] + -1;
          piStack_d0[2] = iVar14;
          UNLOCK();
          if (iVar14 == 0) {
            (**(code **)(*piStack_d0 + 4))();
          }
        }
      }
    }
    if (piStack_88 != (int *)0x0) {
      LOCK();
      iVar14 = piStack_88[1] + -1;
      piStack_88[1] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)*piStack_88)();
        LOCK();
        piVar15 = piStack_88 + 2;
        iVar14 = *piVar15;
        *piVar15 = *piVar15 + -1;
        UNLOCK();
        if (iVar14 == 1) {
          (**(code **)(*piStack_88 + 4))();
        }
      }
    }
  }
  uStack_8._0_1_ = 0x18;
  FUN_01675290(uVar10);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
  FUN_0152dda0(uStack_bc,uStack_a4,uStack_dc);
  uStack_8 = 0x1a;
  FUN_0152dda0(uStack_a8,uStack_b8,uStack_ec);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11445 ; VA 0x0079bb50 ; FUN_0079bb50 */

void FUN_0079bb50(int *param_1,int *param_2,int *param_3,undefined4 *param_4,int *param_5,
                 char param_6)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  undefined *puVar4;
  int iVar5;
  code *pcVar6;
  int *piVar7;
  uint uVar8;
  int iVar9;
  uint uVar10;
  undefined8 uVar11;
  undefined8 uVar12;
  undefined8 uVar13;
  undefined uStack_50;
  undefined uStack_4f;
  undefined4 uStack_4c;
  undefined uStack_48;
  undefined8 uStack_44;
  uint uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  uint uStack_28;
  uint uStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b1fa8;
  pvStack_10 = ExceptionList;
  iVar9 = param_2[1] - *param_2 >> 0x1f;
  if ((param_2[1] - *param_2) / 0x18 + iVar9 == iVar9) {
    return;
  }
  uStack_34 = param_4[1];
  uStack_38 = *param_4;
  ExceptionList = &pvStack_10;
  uVar11 = FUN_0152d930(uStack_38,uStack_34);
  uStack_2c = param_4[3];
  uStack_30 = param_4[2];
  uStack_8 = 0;
  uVar12 = FUN_0152d930(uStack_30,uStack_2c);
  iStack_20 = *param_2;
  uStack_44 = 0;
  uStack_8._0_1_ = 1;
  uVar10 = (param_2[1] - iStack_20) / 0x18;
  uStack_3c = 0;
  param_2 = (int *)0x0;
  iStack_18 = 0;
  uStack_14 = uVar10;
  if (DAT_01d79a58 == '\0') {
    if (param_5 == (int *)0x0) {
      uStack_24 = 0;
      if (uVar10 != 0) {
        do {
          iVar9 = *(int *)(iStack_20 + 4 + uStack_24 * 0x18);
          puVar1 = (undefined4 *)(iStack_20 + uStack_24 * 0x18);
          if (iStack_18 != iVar9) {
            iStack_18 = iVar9;
            FUN_0078e100(param_1);
            param_2 = (int *)((int)param_2 + 1);
          }
          iVar9 = 1;
          uVar10 = uStack_24 + 1;
          if (uVar10 < uStack_14) {
            iVar5 = puVar1[1];
            piVar7 = puVar1 + 8;
            do {
              if (((piVar7[-1] != iVar5) || (*piVar7 != puVar1[2])) ||
                 (*(int *)piVar7[-2] != *(int *)*puVar1)) break;
              iVar5 = puVar1[1];
              uVar10 = uVar10 + 1;
              iVar9 = iVar9 + 1;
              piVar7 = piVar7 + 6;
            } while (uVar10 < uStack_14);
          }
          (**(code **)(*(int *)*puVar1 + 4))(param_1,puVar1,iVar9,&uStack_44);
          uStack_24 = uStack_24 + iVar9;
          iVar9 = (int)param_2;
        } while (uStack_24 < uStack_14);
        goto LAB_0079bf3c;
      }
    }
    else {
      uStack_24 = 0;
      if (uVar10 != 0) {
        do {
          puVar1 = (undefined4 *)(iStack_20 + uStack_24 * 0x18);
          cVar3 = FUN_007f63d0(param_5[1],*(undefined *)(param_5 + 2));
          if (cVar3 == '\0') {
            iVar9 = puVar1[1];
            if (iStack_18 != iVar9) {
              iVar5 = *param_5;
              if (iVar5 == 0) {
                iVar5 = iVar9 + 0x14;
              }
              iStack_18 = iVar9;
              (**(code **)(*param_1 + 0x3c))(puVar1[1] + 8,iVar9 + 0x18,iVar5);
              (**(code **)(*param_1 + 0x24))(*(undefined4 *)(puVar1[1] + 0x24));
              FUN_0078e140(param_1);
              param_2 = (int *)((int)param_2 + 1);
            }
            uVar8 = uStack_24 + 1;
            iStack_1c = 1;
            puVar2 = puVar1;
            if (uVar8 < uVar10) {
              do {
                uVar10 = uStack_14;
                if (((puVar2[7] != puVar1[1]) || (puVar2[8] != puVar1[2])) ||
                   ((*(int *)puVar2[6] != *(int *)*puVar1 ||
                    (cVar3 = FUN_007f63d0(param_5[1],*(undefined *)(param_5 + 2)),
                    uVar10 = uStack_14, cVar3 != '\0')))) break;
                iStack_1c = iStack_1c + 1;
                uVar8 = uVar8 + 1;
                puVar2 = puVar2 + 6;
              } while (uVar8 < uStack_14);
            }
            (**(code **)(*(int *)*puVar1 + 4))(param_1,puVar1,iStack_1c,&uStack_44);
            iVar9 = iStack_1c;
          }
          else {
            iVar9 = 1;
          }
          uStack_24 = uStack_24 + iVar9;
          iVar9 = (int)param_2;
        } while (uStack_24 < uVar10);
        goto LAB_0079bf3c;
      }
    }
    uStack_24 = 0;
    iVar9 = 0;
  }
  else {
    uStack_24 = 0;
    iVar9 = 0;
    if (uVar10 != 0) {
      do {
        puVar1 = (undefined4 *)(iStack_20 + uStack_24 * 0x18);
        if ((param_5 == (int *)0x0) ||
           (cVar3 = FUN_007f63d0(param_5[1],*(undefined *)(param_5 + 2)), cVar3 == '\0')) {
          iVar9 = puVar1[1];
          if (iStack_18 != iVar9) {
            if ((param_5 == (int *)0x0) || (iStack_1c = *param_5, iStack_1c == 0)) {
              iStack_1c = iVar9 + 0x14;
            }
            if ((DAT_01d79a58 == '\0') || (param_6 == '\0')) {
              pcVar6 = *(code **)(*param_1 + 0x3c);
              iVar5 = puVar1[1];
              puVar4 = (undefined *)(iVar5 + 8);
            }
            else {
              uStack_48 = *(undefined *)(iVar9 + 0x10);
              uStack_4c = *(undefined4 *)(iVar9 + 0xc);
              uStack_50 = *(undefined *)(iVar9 + 8);
              uStack_4f = 1;
              pcVar6 = *(code **)(*param_1 + 0x3c);
              iVar5 = puVar1[1];
              puVar4 = &uStack_50;
            }
            iStack_18 = iVar9;
            (*pcVar6)(puVar4,iVar5 + 0x18,iStack_1c);
            (**(code **)(*param_1 + 0x24))(*(undefined4 *)(puVar1[1] + 0x24));
            FUN_0078e140(param_1);
            param_2 = (int *)((int)param_2 + 1);
          }
          uStack_28 = uStack_24 + 1;
          iStack_1c = 1;
          puVar2 = puVar1;
          if (uStack_28 < uVar10) {
            do {
              uVar10 = uStack_14;
              if ((((puVar2[7] != puVar1[1]) || (puVar2[8] != puVar1[2])) ||
                  (*(int *)puVar2[6] != *(int *)*puVar1)) ||
                 ((param_5 != (int *)0x0 &&
                  (cVar3 = FUN_007f63d0(param_5[1],*(undefined *)(param_5 + 2)), uVar10 = uStack_14,
                  cVar3 != '\0')))) break;
              iStack_1c = iStack_1c + 1;
              uStack_28 = uStack_28 + 1;
              uVar10 = uStack_14;
              puVar2 = puVar2 + 6;
            } while (uStack_28 < uStack_14);
          }
          (**(code **)(*(int *)*puVar1 + 4))(param_1,puVar1,iStack_1c,&uStack_44);
          iVar9 = iStack_1c;
        }
        else {
          iVar9 = 1;
        }
        uStack_24 = uStack_24 + iVar9;
        iVar9 = (int)param_2;
      } while (uStack_24 < uVar10);
    }
  }
LAB_0079bf3c:
  iVar5 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  if ((*(int *)(iVar5 + 0x34) < DAT_01eb1ef0) && (FUN_016f3809(&DAT_01eb1ef0), DAT_01eb1ef0 == -1))
  {
    uStack_8._0_1_ = 2;
    uVar13 = FUN_0152da50("Render");
    DAT_01eb1eec = (undefined4)((ulonglong)uVar13 >> 0x20);
    DAT_01eb1ee8 = (undefined4)uVar13;
    uStack_8._0_1_ = 1;
    FUN_016f37bf(&DAT_01eb1ef0);
  }
  FUN_0152d760(DAT_01eb1ee8,DAT_01eb1eec,"%d batches %d materials %d triangles %d kb cbuf",
               (int)uStack_44,iVar9,uStack_44._4_4_ / 3,uStack_3c >> 10);
  if ((*(int *)(iVar5 + 0x34) < DAT_01eb1f00) && (FUN_016f3809(&DAT_01eb1f00), DAT_01eb1f00 == -1))
  {
    uStack_8._0_1_ = 3;
    uVar13 = FUN_0152da50(&DAT_018fb928);
    DAT_01eb1efc = (undefined4)((ulonglong)uVar13 >> 0x20);
    DAT_01eb1ef8 = (undefined4)uVar13;
    uStack_8._0_1_ = 1;
    FUN_016f37bf(&DAT_01eb1f00);
  }
  FUN_0152d760(DAT_01eb1ef8,DAT_01eb1efc,"%d batches %d materials %d triangles %d kb cbuf",
               (int)uStack_44,iVar9,uStack_44._4_4_ / 3,uStack_3c >> 10);
  *param_3 = *param_3 + (int)uStack_44;
  param_3[1] = param_3[1] + uStack_44._4_4_;
  param_3[2] = param_3[2] + uStack_3c;
  param_3[3] = param_3[3] + iVar9;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_0152dda0(uStack_30,uStack_2c,uVar12);
  uStack_8 = 5;
  FUN_0152dda0(uStack_38,uStack_34,uVar11);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11446 ; VA 0x0079c0c0 ; FUN_0079c0c0 */

void __thiscall FUN_0079c0c0(int param_1,int *param_2,undefined4 param_3,int param_4)

{
  undefined4 uVar1;
  undefined4 auStack_60 [17];
  undefined4 uStack_1c;
  undefined auStack_14 [16];
  
  FUN_0147bca0();
  auStack_60[0] = 0x10;
  uStack_1c = 0;
  (**(code **)(*param_2 + 0x14))(param_3,1,1,auStack_60,0);
  FUN_0078a340(param_2,0);
  (**(code **)(*param_2 + 0x30))(0,param_1 + 0x54,0x350);
  uVar1 = FUN_00794160(auStack_14);
  FUN_0079bb50(param_2,*(int *)(param_1 + 0x28) + 0x84,param_4 + 0x10,uVar1,0,0);
  (**(code **)(*param_2 + 0x18))();
  return;
}



/* FUNCTION 11447 ; VA 0x0079c150 ; FUN_0079c150 */

void __thiscall
FUN_0079c150(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  FUN_0079c180(param_2,param_3,*(undefined4 *)(param_1 + 0x28),param_4,param_5,param_6,param_7,
               param_8);
  return;
}



/* FUNCTION 11448 ; VA 0x0079c180 ; FUN_0079c180 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall
FUN_0079c180(int *param_1,int *param_2,undefined4 param_3,int param_4,undefined4 param_5,int param_6
            ,int param_7,undefined4 param_8,int param_9)

{
  int *piVar1;
  ulonglong uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  int *piVar8;
  int *piVar9;
  undefined8 uVar10;
  int aiStack_660 [212];
  undefined auStack_310 [580];
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined auStack_80 [16];
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 uStack_68;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  int iStack_1c;
  undefined4 *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b2010;
  pvStack_10 = ExceptionList;
  iVar7 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  iStack_1c = iVar7;
  if (*(int *)(iVar7 + 0x34) < DAT_01eb1f50) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb1f50);
    if (DAT_01eb1f50 == -1) {
      uStack_8 = 0;
      uVar10 = FUN_0152dab0(&DAT_018fb928,"Scene",0xffffffff);
      DAT_01eb1f4c = (undefined4)((ulonglong)uVar10 >> 0x20);
      DAT_01eb1f48 = (undefined4)uVar10;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb1f50);
    }
  }
  uStack_40 = DAT_01eb1f48;
  uStack_60 = DAT_01eb1f48;
  uStack_3c = DAT_01eb1f4c;
  uStack_5c = DAT_01eb1f4c;
  uStack_58 = FUN_0152d930(DAT_01eb1f48,DAT_01eb1f4c);
  uStack_8 = 1;
  if (*(int *)(iVar7 + 0x34) < DAT_01eb1f60) {
    FUN_016f3809(&DAT_01eb1f60);
    if (DAT_01eb1f60 == -1) {
      uStack_8._0_1_ = 2;
      uVar10 = FUN_0152dab0("Render","Scene",0xffffffff);
      DAT_01eb1f5c = (undefined4)((ulonglong)uVar10 >> 0x20);
      DAT_01eb1f58 = (undefined4)uVar10;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eb1f60);
    }
  }
  uStack_38 = DAT_01eb1f58;
  uStack_50 = DAT_01eb1f58;
  uStack_34 = DAT_01eb1f5c;
  uStack_4c = DAT_01eb1f5c;
  uStack_48 = FUN_0152d930(DAT_01eb1f58,DAT_01eb1f5c);
  uStack_2c = 0;
  uStack_28 = 0;
  iVar7 = *(int *)(*param_1 + 0x524);
  puStack_18 = (undefined4 *)(iVar7 + 0x30);
  uStack_24._0_4_ = 0;
  uStack_24._4_4_ = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  *puStack_18 = 0;
  *(undefined4 *)(iVar7 + 0x34) = 0;
  *(undefined4 *)(iVar7 + 0x38) = 0;
  *(undefined4 *)(iVar7 + 0x3c) = 0;
  FUN_007fab80(param_4);
  FUN_0147bca0();
  uStack_cc = 1;
  uStack_c8 = _DAT_018e0040;
  uStack_c4 = _UNK_018e0044;
  uStack_c0 = _UNK_018e0048;
  uStack_bc = _UNK_018e004c;
  piVar1 = *(int **)(*param_1 + 0x3c);
  piVar8 = param_1 + 0x15;
  piVar9 = aiStack_660;
  for (iVar7 = 0xd4; iVar7 != 0; iVar7 = iVar7 + -1) {
    *piVar9 = *piVar8;
    piVar8 = piVar8 + 1;
    piVar9 = piVar9 + 1;
  }
  piStack_14 = piVar1;
  uVar4 = (**(code **)(*piVar1 + 0x20))();
  iVar7 = (**(code **)(*piStack_14 + 0x40))();
  piStack_14 = (int *)CONCAT31(piStack_14._1_3_,*(undefined *)(iVar7 + 0x39));
  FUN_007cc9d0();
  uVar5 = FUN_01165df0();
  FUN_007cdb40(uVar5);
  FUN_007cd5d0((float)param_6,(float)param_7,&DAT_bf800000,0x3f800000,piStack_14,uVar4);
  FUN_007ce460(auStack_310);
  (**(code **)(*param_2 + 0x14))(param_5,0,1,&uStack_cc,0);
  iVar7 = iStack_1c;
  if (*(int *)(iStack_1c + 0x34) < DAT_01eb1f70) {
    FUN_016f3809(&DAT_01eb1f70);
    if (DAT_01eb1f70 == -1) {
      uStack_8._0_1_ = 4;
      uVar10 = FUN_0152dab0(&DAT_018fb928,"Scene2D",0xffffffff);
      DAT_01eb1f6c = (undefined4)((ulonglong)uVar10 >> 0x20);
      DAT_01eb1f68 = (undefined4)uVar10;
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      FUN_016f37bf(&DAT_01eb1f70);
    }
  }
  piStack_14 = (int *)DAT_01eb1f68;
  uStack_2c = DAT_01eb1f68;
  iStack_1c = DAT_01eb1f6c;
  uStack_28 = DAT_01eb1f6c;
  uStack_24 = FUN_0152d930(DAT_01eb1f68,DAT_01eb1f6c);
  uStack_8._0_1_ = 5;
  if (*(int *)(iVar7 + 0x34) < DAT_01eb1f80) {
    FUN_016f3809(&DAT_01eb1f80);
    if (DAT_01eb1f80 == -1) {
      uStack_8._0_1_ = 6;
      uVar10 = FUN_0152dab0("Render","Scene2D",0xffffffff);
      DAT_01eb1f7c = (undefined4)((ulonglong)uVar10 >> 0x20);
      DAT_01eb1f78 = (undefined4)uVar10;
      uStack_8._0_1_ = 5;
      FUN_016f37bf(&DAT_01eb1f80);
    }
  }
  uVar5 = DAT_01eb1f7c;
  uVar4 = DAT_01eb1f78;
  uStack_70 = DAT_01eb1f78;
  uStack_6c = DAT_01eb1f7c;
  uStack_68 = FUN_0152d930(DAT_01eb1f78,DAT_01eb1f7c);
  uVar2 = (ulonglong)uStack_68 >> 0x20;
  uStack_8._0_1_ = 7;
  (**(code **)(*param_2 + 0x30))(0,aiStack_660,0x350);
  uVar6 = FUN_007942e0(auStack_80);
  FUN_0079bb50(param_2,param_4 + 0x9c,puStack_18,uVar6,0,0);
  uVar6 = FUN_00794a60(auStack_80);
  iStack_30 = param_4 + 0xa8;
  FUN_0079bb50(param_2,iStack_30,puStack_18,uVar6,0,0);
  uStack_8._0_1_ = 8;
  FUN_0152dda0(uVar4,uVar5,(undefined4)uStack_68,(int)uVar2);
  uStack_8._0_1_ = 9;
  FUN_0152dda0(piStack_14,iStack_1c,uStack_24);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  (**(code **)(*param_2 + 0x18))();
  if (param_9 != 0) {
    (**(code **)(*param_2 + 0x14))(param_9,0,1,&uStack_cc,0);
    (**(code **)(*param_2 + 0x30))(0,aiStack_660,0x350);
    uVar4 = FUN_00793e60(auStack_80);
    puVar3 = puStack_18;
    FUN_0079bb50(param_2,param_4 + 0x9c,puStack_18,uVar4,0,0);
    uVar4 = FUN_00795060(auStack_80);
    FUN_0079bb50(param_2,iStack_30,puVar3,uVar4,0,0);
    (**(code **)(*param_2 + 0x18))();
  }
  FUN_007f63a0();
  FUN_007fa660();
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  FUN_0152dda0(uStack_38,uStack_34,uStack_48);
  uStack_8 = 0xb;
  FUN_0152dda0(uStack_40,uStack_3c,uStack_58);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11449 ; VA 0x0079c680 ; FUN_0079c680 */

void __thiscall
FUN_0079c680(int *param_1,undefined4 param_2,int param_3,undefined4 param_4,undefined4 param_5)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  float fVar7;
  double dVar8;
  double dVar9;
  undefined8 uVar10;
  undefined8 uVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b2048;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  if (*(int *)(iVar1 + 0x34) < DAT_01eb2100) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb2100);
    if (DAT_01eb2100 == -1) {
      uStack_8 = 0;
      uVar10 = FUN_0152dab0(&DAT_018fb928,"Scene",0xffffffff);
      DAT_01eb20fc = (undefined4)((ulonglong)uVar10 >> 0x20);
      DAT_01eb20f8 = (undefined4)uVar10;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb2100);
    }
  }
  uVar4 = DAT_01eb20fc;
  uVar3 = DAT_01eb20f8;
  uVar10 = FUN_0152d930(DAT_01eb20f8,DAT_01eb20fc);
  uStack_8 = 1;
  if (*(int *)(iVar1 + 0x34) < DAT_01eb2110) {
    FUN_016f3809(&DAT_01eb2110);
    if (DAT_01eb2110 == -1) {
      uStack_8._0_1_ = 2;
      uVar11 = FUN_0152dab0("Render","Scene",0xffffffff);
      DAT_01eb210c = (undefined4)((ulonglong)uVar11 >> 0x20);
      DAT_01eb2108 = (undefined4)uVar11;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eb2110);
    }
  }
  uVar6 = DAT_01eb210c;
  uVar5 = DAT_01eb2108;
  uVar11 = FUN_0152d930(DAT_01eb2108,DAT_01eb210c);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  dVar8 = *(double *)(*param_1 + 0x18) + *(double *)(param_1 + 0x122);
  *(double *)(param_1 + 0x122) = dVar8;
  fVar7 = (float)dVar8;
  dVar8 = (double)(fVar7 * DAT_018fde64);
  FUN_017279f0();
  dVar9 = (double)fVar7;
  FUN_017279f0();
  param_1[0x50] =
       (int)(float)(double)CONCAT44((uint)((ulonglong)(double)((float)dVar9 * (float)dVar8) >> 0x20)
                                    & DAT_018c0da0._4_4_,
                                    SUB84((double)((float)dVar9 * (float)dVar8),0) &
                                    (uint)DAT_018c0da0);
  FUN_0079a370(param_2,*(undefined4 *)(param_3 + 0x28),*(undefined4 *)(param_3 + 0x2c),param_4);
  FUN_0079d8b0(param_2,param_3,param_4,param_5);
  piVar2 = *(int **)(*param_1 + 0x524);
  if (param_1[0xc] != 0) {
    FUN_007f63a0();
  }
  FUN_007f63a0();
  if (param_1[0xc] != 0) {
    FUN_007f63a0();
  }
  FUN_0078af00();
  FUN_007fa660();
  *piVar2 = piVar2[0x14] + piVar2[0x10] + piVar2[0xc] + piVar2[4] + piVar2[8];
  piVar2[1] = piVar2[5] + piVar2[9] + piVar2[0xd] + piVar2[0x11] + piVar2[0x15];
  piVar2[2] = piVar2[6] + piVar2[10] + piVar2[0xe] + piVar2[0x12] + piVar2[0x16];
  piVar2[3] = piVar2[7] + piVar2[0xb] + piVar2[0xf] + piVar2[0x13] + piVar2[0x17];
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_0152dda0(uVar5,uVar6,uVar11);
  uStack_8 = 5;
  FUN_0152dda0(uVar3,uVar4,uVar10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11450 ; VA 0x0079c970 ; FUN_0079c970 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0079c970(int *param_1,int *param_2,undefined4 *param_3)

{
  uint *puVar1;
  int *piVar2;
  char *pcVar3;
  int iVar4;
  uint3 uVar5;
  float *pfVar6;
  int iVar7;
  int *piVar8;
  undefined4 uVar9;
  undefined4 *puVar10;
  int iVar11;
  float10 fVar12;
  undefined8 uVar13;
  undefined auStack_538 [220];
  undefined auStack_45c [360];
  undefined auStack_2f4 [64];
  undefined auStack_2b4 [64];
  undefined auStack_274 [64];
  undefined auStack_234 [16];
  undefined4 uStack_224;
  undefined4 uStack_220;
  undefined4 uStack_21c;
  undefined4 uStack_218;
  undefined4 uStack_214;
  undefined4 uStack_210;
  undefined4 uStack_20c;
  undefined4 uStack_208;
  undefined4 uStack_204;
  undefined4 uStack_200;
  undefined4 uStack_1fc;
  undefined4 uStack_1f8;
  undefined auStack_1b4 [64];
  uint uStack_174;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined4 uStack_168;
  undefined4 uStack_164;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined auStack_128 [16];
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined8 uStack_f4;
  float fStack_ec;
  undefined8 uStack_e8;
  int iStack_e0;
  float fStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  float fStack_d0;
  undefined4 uStack_cc;
  float fStack_c8;
  undefined4 uStack_c4;
  float fStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined8 uStack_94;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined8 uStack_84;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  int *piStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined uStack_60;
  float fStack_5c;
  float fStack_58;
  undefined8 uStack_54;
  float fStack_4c;
  undefined8 uStack_44;
  int iStack_3c;
  undefined4 uStack_38;
  char *pcStack_34;
  int *piStack_30;
  char *pcStack_2c;
  char cStack_25;
  char *pcStack_24;
  float fStack_20;
  undefined8 uStack_1c;
  char *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b20be;
  pvStack_10 = ExceptionList;
  piVar8 = *(int **)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  piStack_6c = param_1;
  piStack_30 = piVar8;
  if (piVar8[0xd] < DAT_01eb24d0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809();
    if (DAT_01eb24d0 == -1) {
      uStack_8 = 0;
      uVar13 = FUN_0152dab0("Render","renderShadowMap",0xffffffff);
      DAT_01eb24cc = (undefined4)((ulonglong)uVar13 >> 0x20);
      DAT_01eb24c8 = (undefined4)uVar13;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb24d0);
    }
  }
  uStack_7c = DAT_01eb24c8;
  uStack_9c = DAT_01eb24c8;
  uStack_78 = DAT_01eb24cc;
  uStack_98 = DAT_01eb24cc;
  uStack_94 = FUN_0152d930(DAT_01eb24c8,DAT_01eb24cc);
  uStack_8 = 1;
  if (piVar8[0xd] < DAT_01eb24e0) {
    FUN_016f3809();
    if (DAT_01eb24e0 == -1) {
      uStack_8._0_1_ = 2;
      uVar13 = FUN_0152dab0(&DAT_018fb928,"ShadowMap",0xffffffff);
      DAT_01eb24dc = (undefined4)((ulonglong)uVar13 >> 0x20);
      DAT_01eb24d8 = (undefined4)uVar13;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eb24e0);
    }
  }
  uStack_74 = DAT_01eb24d8;
  uStack_8c = DAT_01eb24d8;
  uStack_70 = DAT_01eb24dc;
  uStack_88 = DAT_01eb24dc;
  uStack_84 = FUN_0152d930(DAT_01eb24d8,DAT_01eb24dc);
  uStack_e8 = *(undefined8 *)(param_1 + 1);
  iStack_e0 = param_1[3];
  uStack_8._0_1_ = 3;
  iVar11 = *(int *)(param_3[2] + 0x30);
  pcStack_14 = (char *)((float)iVar11 * (float)param_1[0x118] * DAT_018ce2f4);
  FUN_007cc9d0();
  fStack_ec = (float)param_1[3];
  uStack_118 = _DAT_018e3fb0;
  uStack_114 = _UNK_018e3fb4;
  uStack_110 = _UNK_018e3fb8;
  uStack_10c = _UNK_018e3fbc;
  uStack_108 = _DAT_018e3fb0;
  uStack_104 = _UNK_018e3fb4;
  uStack_100 = _UNK_018e3fb8;
  uStack_fc = _UNK_018e3fbc;
  uStack_38 = DAT_018ce2f8;
  uStack_f4 = *(undefined8 *)(param_1 + 1);
  uStack_f8 = 0x3f800000;
  pfVar6 = (float *)FUN_011658d0();
  fStack_20 = (float)uStack_f4 - *pfVar6;
  uStack_1c._0_4_ = (char *)(uStack_f4._4_4_ - pfVar6[1]);
  uStack_1c._4_4_ = fStack_ec - pfVar6[2];
  FUN_01163c40();
  iVar7 = FUN_01165df0();
  uStack_d8 = *(undefined4 *)(iVar7 + 4);
  uStack_d4 = *(undefined4 *)(iVar7 + 8);
  fStack_d0 = *(float *)(iVar7 + 0xc);
  uStack_cc = *(undefined4 *)(iVar7 + 0x10);
  uStack_c4 = *(undefined4 *)(iVar7 + 0x18);
  fStack_c0 = *(float *)(iVar7 + 0x1c);
  uStack_bc = *(undefined4 *)(iVar7 + 0x20);
  uStack_b8 = *(undefined4 *)(iVar7 + 0x24);
  uStack_ac = *(undefined4 *)(iVar7 + 0x30);
  uStack_a8 = *(undefined4 *)(iVar7 + 0x34);
  uStack_a4 = *(undefined4 *)(iVar7 + 0x38);
  uStack_a0 = *(undefined4 *)(iVar7 + 0x3c);
  uStack_b4 = 0x3c800000;
  uStack_b0 = 0x3f000000;
  fStack_dc = (float)uStack_38 / (float)pcStack_14;
  fStack_c8 = fStack_dc;
  FUN_007cd9c0();
  FUN_007cd560(&fStack_dc,0);
  iVar11 = iVar11 / 2;
  pcStack_24 = _DAT_018f99a0;
  fStack_20 = _UNK_018f99a4;
  uStack_1c._0_4_ = (char *)_UNK_018f99a8;
  uStack_1c._4_4_ = (float)_UNK_018f99ac;
  FUN_01165b90(&fStack_5c,&pcStack_24);
  uStack_44 = (double)((float)iVar11 * fStack_5c);
  fVar12 = (float10)FUN_01725280(uStack_44);
  pcStack_2c = (char *)((float)fVar12 / (float)iVar11);
  uStack_44 = (double)((float)iVar11 * fStack_58);
  fVar12 = (float10)FUN_01725280(uStack_44);
  uStack_44 = (double)fVar12;
  fStack_d0 = (float)pcStack_2c - fStack_5c;
  fStack_c0 = (float)fVar12 / (float)iVar11 - fStack_58;
  FUN_007cd560(&fStack_dc,0);
  puVar1 = (uint *)(param_1 + 7);
  pcVar3 = (char *)DAT_018df584;
  if (DAT_018df584 <= (float)pcStack_14) {
    pcVar3 = pcStack_14;
  }
  param_1[8] = *puVar1;
  FUN_00817dd0(puVar1,&uStack_e8,pcVar3,2);
  if (piStack_30[0xd] < DAT_01eb24f0) {
    FUN_016f3809();
    if (DAT_01eb24f0 == -1) {
      uStack_8._0_1_ = 4;
      uVar13 = FUN_0152dab0("Render","updateRenderQueue",0xffffffff);
      DAT_01eb24ec = (float)((ulonglong)uVar13 >> 0x20);
      DAT_01eb24e8 = (char *)uVar13;
      uStack_8._0_1_ = 3;
      FUN_016f37bf(&DAT_01eb24f0);
    }
  }
  pcStack_34 = DAT_01eb24e8;
  pcStack_24 = DAT_01eb24e8;
  fStack_4c = DAT_01eb24ec;
  fStack_20 = DAT_01eb24ec;
  uStack_1c = FUN_0152d930(DAT_01eb24e8,DAT_01eb24ec);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_007f63a0();
  puVar10 = (undefined4 *)*puVar1;
  pcStack_14 = (char *)0x0;
  pcStack_2c = (char *)((param_1[8] - (int)puVar10) + 3U >> 2);
  if ((undefined4 *)param_1[8] < puVar10) {
    pcStack_2c = (char *)0x0;
  }
  if (pcStack_2c != (char *)0x0) {
    do {
      (**(code **)(*(int *)*puVar10 + 4))(param_1[0xb],auStack_538,2);
      puVar10 = puVar10 + 1;
      pcStack_14 = pcStack_14 + 1;
    } while (pcStack_14 != pcStack_2c);
  }
  FUN_007a0d20();
  uStack_8._0_1_ = 6;
  FUN_0152dda0(pcStack_34,fStack_4c,uStack_1c);
  uStack_8._0_1_ = 3;
  FUN_007ce460();
  iVar11 = (**(code **)(**(int **)(*param_1 + 0x3c) + 0x40))();
  if (*(char *)(iVar11 + 0x3a) == '\0') {
    uStack_38 = DAT_018f7864;
  }
  fStack_20 = 0.5;
  uStack_1c._0_4_ = (char *)0x3f000000;
  uStack_1c._4_4_ = 0.0;
  FUN_01165980(&DAT_01d71e5c,&fStack_20);
  uStack_1c._0_4_ = (char *)((float)uStack_38 * DAT_018ce2f4);
  fStack_20 = 0.5;
  uStack_1c._4_4_ = 1.0;
  FUN_007a02f0(&fStack_dc,&fStack_20);
  FUN_01165af0(auStack_274,&fStack_dc);
  FUN_01165af0(auStack_1b4,auStack_45c);
  piVar8 = (int *)FUN_01165f10();
  iVar11 = piVar8[1];
  iVar7 = piVar8[2];
  iVar4 = piVar8[3];
  param_1[0x65] = *piVar8;
  param_1[0x66] = iVar11;
  param_1[0x67] = iVar7;
  param_1[0x68] = iVar4;
  piVar8 = (int *)FUN_01165f10();
  iVar11 = piVar8[1];
  iVar7 = piVar8[2];
  iVar4 = piVar8[3];
  param_1[0x69] = *piVar8;
  param_1[0x6a] = iVar11;
  param_1[0x6b] = iVar7;
  param_1[0x6c] = iVar4;
  piVar8 = (int *)FUN_01165f10();
  iVar11 = piVar8[1];
  iVar7 = piVar8[2];
  iVar4 = piVar8[3];
  param_1[0x6d] = *piVar8;
  param_1[0x6e] = iVar11;
  param_1[0x6f] = iVar7;
  param_1[0x70] = iVar4;
  iVar11 = (**(code **)(**(int **)(*param_1 + 0x3c) + 0x40))();
  uStack_174 = 0;
  cStack_25 = *(char *)(iVar11 + 6);
  if (cStack_25 != '\0') {
    uStack_174 = 0x20;
  }
  pcStack_2c = (char *)uStack_174;
  FUN_0147bca0();
  uStack_174 = uStack_174 | 0x11;
  uStack_170 = _DAT_018e3fb0;
  uStack_16c = _UNK_018e3fb4;
  uStack_168 = _UNK_018e3fb8;
  uStack_164 = _UNK_018e3fbc;
  uStack_130 = 0x3f800000;
  uStack_12c = 0;
  (**(code **)(*param_2 + 0x14))(*param_3,0,(uint)pcStack_2c | 1,&uStack_174,0);
  (**(code **)(*param_2 + 0x30))(0,param_1 + 0x15,0x350);
  uVar9 = FUN_00794e20(&fStack_5c);
  FUN_0079bb50(param_2,param_1[0xb] + 0x24,*(int *)(*param_1 + 0x524) + 0x20,uVar9,0,0);
  uStack_54 = CONCAT44(uStack_54._4_4_,(undefined4)uStack_54);
  if ((3 < (uint)(param_1[8] - param_1[7])) &&
     (uStack_54 = CONCAT44(uStack_54._4_4_,(undefined4)uStack_54), cStack_25 != '\0')) {
    if (piStack_30[0xd] < DAT_01eb2518) {
      FUN_016f3809(&DAT_01eb2518);
      if (DAT_01eb2518 == -1) {
        uStack_8._0_1_ = 7;
        uVar13 = FUN_0152dab0(&DAT_018fb928,"StencilMark",0xffffffff);
        DAT_01eb2514 = (float)((ulonglong)uVar13 >> 0x20);
        DAT_01eb2510 = (float)uVar13;
        uStack_8._0_1_ = 3;
        FUN_016f37bf(&DAT_01eb2518);
      }
    }
    uStack_44 = (double)CONCAT44(DAT_01eb2510,(undefined4)uStack_44);
    fStack_5c = DAT_01eb2510;
    fStack_4c = DAT_01eb2514;
    fStack_58 = DAT_01eb2514;
    uStack_54 = FUN_0152d930(DAT_01eb2510,DAT_01eb2514);
    uStack_8._0_1_ = 8;
    uVar5 = (uint3)uStack_38;
    uStack_38 = (int *)CONCAT13(2,uVar5 & 0xff);
    uStack_64 = 0x1000100;
    uStack_68 = 0;
    uStack_60 = 0;
    fStack_20 = (float)((uint)fStack_20 & 0xffff0000);
    uStack_1c._0_4_ = (char *)0x0;
    uStack_1c._4_4_ = (float)((uint)uStack_1c._4_4_ & 0xffffff00);
    (**(code **)(*param_2 + 0x3c))(&fStack_20,&uStack_68,(int)&uStack_38 + 1);
    pcStack_24 = "ShadowBlurMarkVS";
    fStack_20 = 2.24208e-44;
    uStack_1c._0_4_ = "ShadowBlurMarkFS";
    uStack_1c._4_4_ = 2.24208e-44;
    FUN_00790e00(&iStack_3c,&pcStack_24,2);
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    if (iStack_3c != 0) {
      (**(code **)(*param_2 + 0x24))(iStack_3c);
      piStack_30 = (int *)param_1[7];
      pcStack_14 = (char *)0x0;
      pcStack_34 = (char *)((param_1[8] - (int)piStack_30) + 3U >> 2);
      if ((int *)param_1[8] < piStack_30) {
        pcStack_34 = (char *)0x0;
      }
      if (pcStack_34 != (char *)0x0) {
        do {
          iVar11 = *piStack_30;
          fStack_20 = (*(float *)(iVar11 + 0x18) + *(float *)(iVar11 + 0x24)) * DAT_018ce2f4;
          uStack_1c._0_4_ =
               (char *)((*(float *)(iVar11 + 0x28) + *(float *)(iVar11 + 0x1c)) * DAT_018ce2f4);
          uStack_1c._4_4_ = (*(float *)(iVar11 + 0x2c) + *(float *)(iVar11 + 0x20)) * DAT_018ce2f4;
          FUN_01165980(&DAT_01d71e5c,&fStack_20);
          FUN_01165af0(auStack_2f4,auStack_128);
          FUN_01165a00((*(float *)(iVar11 + 0x24) - *(float *)(iVar11 + 0x18)) * DAT_018ce2f4 *
                       DAT_018df57c,0,0,0,0,
                       (*(float *)(iVar11 + 0x28) - *(float *)(iVar11 + 0x1c)) * DAT_018ce2f4 *
                       DAT_018df57c,0,0,0,0,
                       (*(float *)(iVar11 + 0x2c) - *(float *)(iVar11 + 0x20)) * DAT_018ce2f4 *
                       DAT_018df57c,0,0,0,0,0x3f800000);
          FUN_01165af0(&fStack_dc,auStack_2b4);
          FUN_00829a50(1,1);
          puVar10 = (undefined4 *)FUN_01165f10(0);
          uStack_224 = *puVar10;
          uStack_220 = puVar10[1];
          uStack_21c = puVar10[2];
          uStack_218 = puVar10[3];
          puVar10 = (undefined4 *)FUN_01165f10(1);
          uStack_214 = *puVar10;
          uStack_210 = puVar10[1];
          uStack_20c = puVar10[2];
          uStack_208 = puVar10[3];
          puVar10 = (undefined4 *)FUN_01165f10(2);
          uStack_204 = *puVar10;
          uStack_200 = puVar10[1];
          uStack_1fc = puVar10[2];
          uStack_1f8 = puVar10[3];
          (**(code **)(*param_2 + 0x30))(1,auStack_234,0x80);
          param_1 = piStack_6c;
          puVar10 = (undefined4 *)piStack_6c[0x108];
          (**(code **)(*param_2 + 0x40))(*puVar10,puVar10[2],puVar10[3],puVar10[4],puVar10[5],0);
          pcStack_14 = pcStack_14 + 1;
          piStack_30 = piStack_30 + 1;
        } while (pcStack_14 != pcStack_34);
      }
    }
    piVar8 = uStack_38;
    if (uStack_38 != (int *)0x0) {
      LOCK();
      iVar11 = uStack_38[1] + -1;
      uStack_38[1] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        (**(code **)*uStack_38)();
        LOCK();
        piVar2 = piVar8 + 2;
        iVar11 = *piVar2 + -1;
        *piVar2 = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    uStack_8._0_1_ = 10;
    FUN_0152dda0(uStack_44._4_4_,fStack_4c,uStack_54);
    uStack_8._0_1_ = 3;
  }
  (**(code **)(*param_2 + 0x18))();
  if (3 < (uint)(param_1[8] - param_1[7])) {
    FUN_00795b40(param_2,param_3,pcStack_2c);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  FUN_0152dda0(uStack_74,uStack_70,uStack_84);
  uStack_8 = 0xc;
  FUN_0152dda0(uStack_7c,uStack_78,uStack_94);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11451 ; VA 0x0079d410 ; FUN_0079d410 */

void __fastcall FUN_0079d410(int param_1)

{
  if (*(int *)(param_1 + 0x40) == 0) {
    FUN_0081ba10();
    return;
  }
  if (*(int *)(param_1 + 0x40) == 1) {
    FUN_00820880();
    return;
  }
  return;
}



/* FUNCTION 11452 ; VA 0x0079d440 ; FUN_0079d440 */

void __thiscall FUN_0079d440(int *param_1,int *param_2,int param_3,int param_4)

{
  undefined uVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uVar5;
  int *piVar6;
  int iVar7;
  int *piVar8;
  undefined8 uVar9;
  int aiStack_944 [212];
  int aiStack_5f4 [212];
  undefined auStack_2a4 [580];
  undefined auStack_60 [16];
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b20f8;
  pvStack_10 = ExceptionList;
  piStack_1c = *(int **)(*param_1 + 0x3c);
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  if (*(char *)(param_1 + 0x124) == '\0') {
    iVar7 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    ExceptionList = &pvStack_10;
    if ((*(int *)(iVar7 + 0x34) < DAT_01eb2140) &&
       (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb2140), DAT_01eb2140 == -1)) {
      uStack_8 = 0;
      uVar9 = FUN_0152dab0("Render",&DAT_018fdbdc,0xffffffff);
      DAT_01eb213c = (undefined4)((ulonglong)uVar9 >> 0x20);
      DAT_01eb2138 = (undefined4)uVar9;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb2140);
    }
    uStack_30 = DAT_01eb2138;
    uStack_50 = DAT_01eb2138;
    uStack_2c = DAT_01eb213c;
    uStack_4c = DAT_01eb213c;
    uStack_48 = FUN_0152d930(DAT_01eb2138,DAT_01eb213c);
    uStack_8 = 1;
    if (*(int *)(iVar7 + 0x34) < DAT_01eb2150) {
      FUN_016f3809(&DAT_01eb2150);
      if (DAT_01eb2150 == -1) {
        uStack_8._0_1_ = 2;
        uVar9 = FUN_0152dab0(&DAT_018fb928,&DAT_018fdbdc,0xffffffff);
        DAT_01eb214c = (undefined4)((ulonglong)uVar9 >> 0x20);
        DAT_01eb2148 = (undefined4)uVar9;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_016f37bf(&DAT_01eb2150);
      }
    }
    uStack_28 = DAT_01eb2148;
    uStack_40 = DAT_01eb2148;
    uStack_24 = DAT_01eb214c;
    uStack_3c = DAT_01eb214c;
    uStack_38 = FUN_0152d930(DAT_01eb2148,DAT_01eb214c);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_0078a340(param_2,0);
    piStack_20 = param_1 + 0x15;
    (**(code **)(*param_2 + 0x30))(0,piStack_20,0x350);
    uVar3 = FUN_00794460(auStack_60);
    FUN_0079bb50(param_2,param_1[10] + 0x90,param_4 + 0x10,uVar3,0,0);
    iVar7 = 0;
    do {
      FUN_0078af00();
      FUN_007fa410(param_2,param_3,param_4 + 0x50,iVar7);
      iVar7 = iVar7 + 1;
    } while (iVar7 < 0xb);
    piVar6 = piStack_20;
    piVar8 = aiStack_5f4;
    for (iVar7 = 0xd4; piVar2 = piStack_1c, iVar7 != 0; iVar7 = iVar7 + -1) {
      *piVar8 = *piVar6;
      piVar6 = piVar6 + 1;
      piVar8 = piVar8 + 1;
    }
    uVar3 = (**(code **)(*piStack_1c + 0x20))();
    iVar7 = (**(code **)(*piVar2 + 0x40))();
    uVar1 = *(undefined *)(iVar7 + 0x39);
    iVar7 = FUN_0078af10();
    iVar4 = FUN_0078af20();
    FUN_007cc9d0();
    uVar5 = FUN_01165df0();
    FUN_007cdb40(uVar5);
    FUN_007cd5d0((float)iVar4,(float)iVar7,&DAT_bf800000,0x3f800000,uVar1,uVar3);
    FUN_007ce460(auStack_2a4);
    (**(code **)(*param_2 + 0x30))(0,aiStack_5f4,0x350);
    uVar3 = FUN_00794d60(auStack_60);
    param_1 = piStack_14;
    FUN_0079bb50(param_2,piStack_14[10] + 0x9c,param_4 + 0x30,uVar3,0,0);
    FUN_0078af00();
    uVar3 = FUN_0078af10();
    uVar5 = FUN_0078af20();
    FUN_007fa140(param_2,uVar5,uVar3,param_4 + 0x30,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_0152dda0(uStack_28,uStack_24,uStack_38);
    uStack_8 = 5;
    FUN_0152dda0(uStack_30,uStack_2c,uStack_48);
  }
  param_3 = param_4 + 0x30;
  uStack_8 = 0xffffffff;
  piVar6 = param_1 + 0x15;
  piVar8 = aiStack_944;
  for (iVar7 = 0xd4; piVar2 = piStack_1c, iVar7 != 0; iVar7 = iVar7 + -1) {
    *piVar8 = *piVar6;
    piVar6 = piVar6 + 1;
    piVar8 = piVar8 + 1;
  }
  uVar3 = (**(code **)(*piStack_1c + 0x20))();
  iVar7 = (**(code **)(*piVar2 + 0x40))();
  uVar1 = *(undefined *)(iVar7 + 0x39);
  iVar7 = FUN_0078af10();
  iVar4 = FUN_0078af20();
  FUN_007cc9d0();
  uVar5 = FUN_01165df0();
  FUN_007cdb40(uVar5);
  FUN_007cd5d0((float)iVar4,(float)iVar7,&DAT_bf800000,0x3f800000,uVar1,uVar3);
  FUN_007ce460(auStack_2a4);
  (**(code **)(*param_2 + 0x30))(0,aiStack_944,0x350);
  uVar3 = FUN_007952a0(&uStack_40);
  FUN_0079bb50(param_2,piStack_14[10] + 0xa8,param_3,uVar3,0,0);
  FUN_0078af00();
  uVar3 = FUN_0078af10();
  uVar5 = FUN_0078af20();
  FUN_007fa140(param_2,uVar5,uVar3,param_3,1);
  FUN_00553510(param_2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11453 ; VA 0x0079d8b0 ; FUN_0079d8b0 */

int __thiscall FUN_0079d8b0(int *param_1,int *param_2,uint param_3,int param_4,int param_5)

{
  float *pfVar1;
  int iVar2;
  int *piVar3;
  uint3 uVar4;
  undefined uVar5;
  char cVar6;
  byte bVar7;
  int iVar8;
  int iVar9;
  undefined4 *puVar10;
  int *piVar11;
  uint uVar12;
  int *piVar13;
  float10 fVar14;
  float fVar15;
  float fVar16;
  undefined8 uVar17;
  char *pcVar18;
  int **ppiVar19;
  undefined4 uVar20;
  undefined4 uVar21;
  undefined8 *puVar22;
  int aiStack_7e0 [212];
  undefined auStack_490 [580];
  undefined auStack_24c [128];
  undefined auStack_1cc [16];
  int *piStack_1bc;
  int *piStack_1b8;
  int iStack_1b4;
  int iStack_1b0;
  undefined4 uStack_198;
  int iStack_194;
  int iStack_190;
  int iStack_18c;
  int iStack_188;
  undefined4 uStack_154;
  uint uStack_14c;
  undefined4 uStack_148;
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  int iStack_108;
  undefined4 uStack_104;
  undefined8 uStack_100;
  undefined4 uStack_f8;
  int *piStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined8 uStack_e0;
  undefined4 uStack_d8;
  int *piStack_d4;
  int *piStack_d0;
  undefined8 uStack_cc;
  int *piStack_c4;
  int *piStack_c0;
  undefined8 uStack_bc;
  int *piStack_b4;
  int *piStack_b0;
  undefined8 uStack_ac;
  undefined4 uStack_a4;
  int *piStack_a0;
  int *piStack_9c;
  undefined8 uStack_98;
  undefined4 uStack_90;
  int iStack_8c;
  int iStack_88;
  int iStack_84;
  int *piStack_80;
  int *piStack_7c;
  undefined8 uStack_78;
  float fStack_70;
  int *piStack_6c;
  int *piStack_68;
  int *piStack_64;
  undefined8 uStack_60;
  undefined4 *puStack_58;
  int *piStack_54;
  int *piStack_50;
  char cStack_49;
  int *piStack_48;
  int *piStack_44;
  int *piStack_40;
  int *piStack_3c;
  int *piStack_38;
  int *piStack_34;
  undefined8 uStack_30;
  int iStack_28;
  char cStack_23;
  char cStack_22;
  char cStack_21;
  int *piStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  byte bStack_13;
  char cStack_12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b22cc;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1[0x10d] + 0x40) == 2) {
    return param_1[0x10d];
  }
  iStack_18 = *(int *)(*param_1 + 0x524);
  fStack_70 = *(float *)(*param_1 + 0x4fc);
  ExceptionList = &pvStack_10;
  piStack_3c = param_1;
  iStack_84 = FUN_01156ce0();
  iVar9 = param_4;
  uStack_90 = *(undefined4 *)(*param_1 + 0x5c4);
  piStack_50 = param_1 + 0x15;
  FUN_007ce460(param_4);
  FUN_00797910(iVar9);
  iStack_28 = *(int *)(param_1[0x10d] + 0x40);
  cVar6 = FUN_0078b680();
  if (cVar6 == '\0') {
LAB_0079d987:
    cStack_22 = '\0';
    if (iStack_28 == 1) goto LAB_0079d990;
LAB_0079d9a0:
    cStack_21 = '\0';
  }
  else {
    iVar8 = param_1[0x111];
    if ((*(char *)(iVar8 + 0x58) == '\0') ||
       ((((NAN(*(float *)(iVar8 + 0x54)) != (*(float *)(iVar8 + 0x54) == 0.0) &&
          ((*(char *)(iVar8 + 0x58) == '\0' ||
           (NAN(*(float *)(iVar8 + 0x50)) != (*(float *)(iVar8 + 0x50) == 0.0))))) ||
         (iStack_28 != 1)) || (iStack_84 != 3)))) goto LAB_0079d987;
    cStack_22 = '\x01';
LAB_0079d990:
    iVar8 = FUN_01157030();
    if (iVar8 == 0) goto LAB_0079d9a0;
    cStack_21 = '\x01';
  }
  if ((DAT_01d60f70 == '\0') || (cStack_21 == '\0')) {
LAB_0079d9c1:
    piStack_48 = (int *)((uint)piStack_48 & 0xffffff00);
  }
  else {
    cVar6 = FUN_0078bbb0();
    piStack_48 = (int *)CONCAT31(piStack_48._1_3_,1);
    if (cVar6 == '\0') goto LAB_0079d9c1;
  }
  piStack_6c = (int *)(*(uint *)(param_1[10] + 0xb4) & 0xffffff01);
  if ((((iStack_28 != 1) || (iStack_84 < 3)) || (iVar8 = param_1[0x112], iVar8 == 0)) ||
     ((*(char *)(iVar8 + 0x10) == '\0' || (*(float *)(iVar8 + 0x14) <= DAT_018ce2f0)))) {
LAB_0079da2a:
    cStack_23 = '\0';
  }
  else {
    fVar14 = (float10)FUN_00799440(iVar9);
    piStack_40 = (int *)(float)fVar14;
    if ((float)piStack_40 <= DAT_018ce2f0) goto LAB_0079da2a;
    iVar8 = (**(code **)(**(int **)(*param_1 + 0x3c) + 0x40))();
    cStack_23 = '\x01';
    if (*(char *)(iVar8 + 0x14) == '\0') goto LAB_0079da2a;
  }
  iVar8 = (**(code **)(**(int **)(*param_1 + 0x3c) + 0x40))();
  uStack_a4 = CONCAT31(uStack_a4._1_3_,*(undefined *)(iVar8 + 0x14));
  piStack_54 = (int *)(*(uint *)(param_1[10] + 0xb4) >> 1 & 0xffffff01);
  if (((cStack_21 == '\0') && (cStack_23 == '\0')) && ((*(uint *)(param_1[10] + 0xb4) & 4) == 0)) {
    bStack_13 = '\0';
  }
  else {
    bStack_13 = '\x01';
  }
  iVar8 = FUN_0078ae30();
  iStack_8c = *(int *)(iVar8 + 200);
  iStack_88 = *(int *)(iVar8 + 0xcc);
  if ((*(int *)(param_1[0x10d] + 0x40) != 0) || (cStack_49 = '\x01', iStack_8c != iStack_88)) {
    cStack_49 = '\0';
  }
  uStack_1c = (int *)param_1[0xe];
  FUN_0078b680();
  param_1[0x54] = 0;
  FUN_007a0ae0(1 < *(uint *)(param_1[0x10d] + 0x44));
  piVar13 = param_2;
  uStack_60._0_4_ = 0;
  uStack_60._4_4_ = 0;
  iVar8 = *(int *)(*(int *)(*(int *)param_1[0x10d] + 0x10) + 0x2c);
  iVar2 = *(int *)(*(int *)(*(int *)param_1[0x10d] + 0x10) + 0x28);
  piStack_64 = (int *)(DAT_018ce2f8 /
                      (float)((double)iVar8 + (double)(&DAT_018c0d90)[-(iVar8 >> 0x1f)]));
  piStack_68 = (int *)(DAT_018ce2f8 /
                      (float)((double)iVar2 + (double)(&DAT_018c0d90)[-(iVar2 >> 0x1f)]));
  param_1[0xc9] = (int)piStack_68;
  param_1[0xca] = (int)piStack_64;
  param_1[0xcb] = 0;
  param_1[0xcc] = 0;
  if ((DAT_01d60fb8 != '\0') && (*(char *)((int)param_1 + 0x3d) != '\0')) {
    FUN_00822f40(param_2,param_1[0x10c],iVar9,*(undefined4 *)(*(int *)param_1[0x10d] + 0x10),
                 param_1 + 0x15);
  }
  iStack_28 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  if ((*(int *)(iStack_28 + 0x34) < DAT_01eb21c0) &&
     (FUN_016f3809(&DAT_01eb21c0), DAT_01eb21c0 == -1)) {
    uStack_8 = 0;
    uVar17 = FUN_0152dab0("Render","Clear",0xffffffff);
    DAT_01eb21bc = (int *)((ulonglong)uVar17 >> 0x20);
    DAT_01eb21b8 = (int *)uVar17;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb21c0);
  }
  piStack_20 = DAT_01eb21b8;
  piStack_d4 = DAT_01eb21b8;
  piStack_40 = DAT_01eb21bc;
  piStack_d0 = DAT_01eb21bc;
  uStack_cc = FUN_0152d930(DAT_01eb21b8,DAT_01eb21bc);
  uStack_8 = 1;
  FUN_0147bca0();
  iStack_194 = param_1[0x11];
  iStack_190 = param_1[0x12];
  iStack_18c = param_1[0x13];
  iStack_188 = param_1[0x14];
  piVar11 = (int *)param_1[0x10d];
  uStack_198 = 0x11;
  uStack_154 = 0;
  if (((uint)piVar11[0x11] < 2) || (cStack_49 == '\0')) {
    puVar22 = (undefined8 *)0x0;
    if (piVar11[0x10] == 1) {
      uVar21 = 0x11;
    }
    else {
      uVar21 = 1;
    }
  }
  else {
    FUN_005502b0();
    piVar11 = (int *)param_1[0x10d];
    puVar22 = &uStack_78;
    uStack_78._0_4_ = 1.4013e-45;
    uVar21 = 0;
    uStack_78._4_4_ = *(int **)(*piVar11 + 0x10);
  }
  (**(code **)(*piVar13 + 0x14))(piVar11[7],0,uVar21,&uStack_198,puVar22);
  uStack_8 = 2;
  FUN_0152dda0(piStack_20,piStack_40,uStack_cc);
  uStack_8 = 0xffffffff;
  (**(code **)(*piVar13 + 0x30))(0,param_1 + 0x15,0x350);
  FUN_0078a340(piVar13,0);
  if (*(char *)(param_1 + 0xd) == '\0') {
LAB_0079ddc0:
    cStack_12 = '\0';
  }
  else {
    cVar6 = FUN_0078b7c0();
    if (cVar6 == '\0') goto LAB_0079ddc0;
    cStack_12 = '\x01';
    if (*(int *)(iStack_28 + 0x34) < DAT_01eb21d0) {
      FUN_016f3809(&DAT_01eb21d0);
      if (DAT_01eb21d0 == -1) {
        uStack_8 = 3;
        uVar17 = FUN_0152dab0(&DAT_018fb928,"DepthPass",0xffffffff);
        DAT_01eb21cc = (int *)((ulonglong)uVar17 >> 0x20);
        DAT_01eb21c8 = (int *)uVar17;
        uStack_8 = 0xffffffff;
        FUN_016f37bf(&DAT_01eb21d0);
      }
    }
    piStack_40 = DAT_01eb21c8;
    piStack_68 = DAT_01eb21c8;
    piStack_20 = DAT_01eb21cc;
    piStack_64 = DAT_01eb21cc;
    uVar17 = FUN_0152d930(DAT_01eb21c8,DAT_01eb21cc);
    uStack_8 = 4;
    uStack_60 = uVar17;
    uVar21 = FUN_007955a0(&piStack_b4);
    FUN_0079bb50(param_2,piStack_3c[0xc],iStack_18 + 0x10,uVar21,0,0);
    uVar21 = FUN_00795660(&piStack_b4);
    FUN_0079bb50(param_2,piStack_3c[0xc] + 0xc,iStack_18 + 0x10,uVar21,0,0);
    uVar21 = FUN_007945e0(&piStack_b4);
    FUN_0079bb50(param_2,piStack_3c[0xc] + 0x24,iStack_18 + 0x10,uVar21,0,0);
    uStack_8 = 5;
    FUN_0152dda0(piStack_40,piStack_20,uVar17);
    uStack_8 = 0xffffffff;
  }
  if (uStack_1c == (int *)0x1) {
    if (*(int *)(iStack_28 + 0x34) < DAT_01eb2228) {
      FUN_016f3809(&DAT_01eb2228);
      if (DAT_01eb2228 == -1) {
        uStack_8 = 6;
        uVar17 = FUN_0152dab0(&DAT_018fb928,"OpaqueWithAlphaDepthPass",0xffffffff);
        DAT_01eb2224 = (int *)((ulonglong)uVar17 >> 0x20);
        DAT_01eb2220 = (int *)uVar17;
        uStack_8 = 0xffffffff;
        FUN_016f37bf(&DAT_01eb2228);
      }
    }
    piStack_40 = DAT_01eb2220;
    piStack_68 = DAT_01eb2220;
    piStack_20 = DAT_01eb2224;
    piStack_64 = DAT_01eb2224;
    uVar17 = FUN_0152d930(DAT_01eb2220,DAT_01eb2224);
    uStack_8 = 7;
    uStack_60 = uVar17;
    uVar21 = FUN_00794fa0(&piStack_b4);
    FUN_0079bb50(param_2,piStack_3c[0xc] + 0x3c,iStack_18 + 0x10,uVar21,0,0);
    uStack_8 = 8;
    FUN_0152dda0(piStack_40,piStack_20,uVar17);
    uStack_8 = 0xffffffff;
  }
  piVar13 = param_2;
  piVar11 = piStack_3c;
  if (((DAT_01d60f70 != '\0') && ((char)piStack_48 != '\0')) && (cStack_12 != '\0')) {
    (**(code **)(*param_2 + 0x18))();
    piVar11 = piStack_3c;
    FUN_00797d70(piVar13,param_4,0);
    if (*(int *)(piVar11[0x10d] + 0x40) == 1) {
      uVar20 = 0x11;
      uVar21 = 0x11;
    }
    else {
      uVar20 = 1;
      uVar21 = 1;
    }
    (**(code **)(*piVar13 + 0x14))(*(undefined4 *)(piVar11[0x10d] + 0x1c),uVar21,uVar20,0,0);
    FUN_0078b680();
    piVar11[0x54] = 0;
    FUN_007a0ae0(1 < *(uint *)(piVar11[0x10d] + 0x44));
    (**(code **)(*piVar13 + 0x30))(0,piVar11 + 0x15,0x350);
    FUN_0078a340(piVar13,piStack_48);
  }
  uVar21 = FUN_00794be0(&piStack_68);
  FUN_0079bb50(piVar13,piVar11[10],iStack_18 + 0x10,uVar21,0,0);
  uVar21 = FUN_00794b20(&piStack_68);
  FUN_0079bb50(piVar13,piVar11[10] + 0xc,iStack_18 + 0x10,uVar21,0,0);
  piStack_20 = (int *)piVar11[0x77];
  piStack_40 = (int *)piVar11[0x78];
  piVar11[0x77] = 0;
  piVar11[0x78] = 0;
  (**(code **)(*piVar13 + 0x30))(0,piVar11 + 0x15,0x350);
  uVar21 = FUN_00793da0(&piStack_68);
  FUN_0079bb50(piVar13,piVar11[10] + 0x24,iStack_18 + 0x10,uVar21,0,0);
  piVar11[0x77] = (int)piStack_20;
  piVar11[0x78] = (int)piStack_40;
  (**(code **)(*piVar13 + 0x30))(0,piVar11 + 0x15,0x350);
  uVar21 = FUN_007948e0(&piStack_68);
  FUN_0079bb50(piVar13,piVar11[10] + 0x18,iStack_18 + 0x10,uVar21,0,0);
  if (*(char *)((int)piVar11 + 0x3e) != '\0') {
    if (piVar11[0x10] == 0) {
      FUN_0081ba10(piVar13,param_4,0,0);
    }
    else if (piVar11[0x10] == 1) {
      FUN_00820880(piVar13,param_4,0,0);
    }
  }
  if (uStack_1c == (int *)0x2) {
    if (*(int *)(iStack_28 + 0x34) < DAT_01eb22b0) {
      FUN_016f3809(&DAT_01eb22b0);
      if (DAT_01eb22b0 == -1) {
        uStack_8 = 9;
        uVar17 = FUN_0152dab0(&DAT_018fb928,"OpaqueWithAlphaDepthPass",0xffffffff);
        DAT_01eb22ac = (int *)((ulonglong)uVar17 >> 0x20);
        DAT_01eb22a8 = (int *)uVar17;
        uStack_8 = 0xffffffff;
        FUN_016f37bf(&DAT_01eb22b0);
      }
    }
    piStack_40 = DAT_01eb22a8;
    piStack_68 = DAT_01eb22a8;
    piStack_20 = DAT_01eb22ac;
    piStack_64 = DAT_01eb22ac;
    uVar17 = FUN_0152d930(DAT_01eb22a8,DAT_01eb22ac);
    uStack_8 = 10;
    uStack_60 = uVar17;
    uVar21 = FUN_007954e0(&piStack_b4);
    FUN_0079bb50(param_2,piStack_3c[0xc] + 0x3c,iStack_18 + 0x10,uVar21,0,0);
    uStack_8 = 0xb;
    FUN_0152dda0(piStack_40,piStack_20,uVar17);
    uStack_8 = 0xffffffff;
    piVar13 = param_2;
    piVar11 = piStack_3c;
  }
  uVar21 = FUN_00793f20(&piStack_68);
  FUN_0079bb50(piVar13,piVar11[10] + 0x3c,iStack_18 + 0x10,uVar21,0,0);
  if ((DAT_01d60fb8 != '\0') && (*(char *)((int)piVar11 + 0x3d) != '\0')) {
    FUN_008228d0(piVar13);
  }
  if (*(int *)(piVar11[0x10d] + 0x40) == 1) {
    (**(code **)(*piVar13 + 0x18))();
    if (((char)piStack_54 != '\0') ||
       (((uStack_78 = CONCAT44(uStack_78._4_4_,(float)uStack_78), (char)piStack_48 != '\0' &&
         (uStack_78 = CONCAT44(uStack_78._4_4_,(float)uStack_78), bStack_13 != '\0')) &&
        (uStack_78 = CONCAT44(uStack_78._4_4_,(float)uStack_78), cStack_12 == '\0')))) {
      if (*(int *)(iStack_28 + 0x34) < DAT_01eb22f0) {
        FUN_016f3809(&DAT_01eb22f0);
        if (DAT_01eb22f0 == -1) {
          uStack_8 = 0xc;
          uVar17 = FUN_0152dab0(&DAT_018fb928,"ResolveColor",0xffffffff);
          DAT_01eb22ec = (int *)((ulonglong)uVar17 >> 0x20);
          DAT_01eb22e8 = (int *)uVar17;
          uStack_8 = 0xffffffff;
          FUN_016f37bf(&DAT_01eb22f0);
        }
      }
      piStack_20 = DAT_01eb22e8;
      piStack_80 = DAT_01eb22e8;
      piStack_54 = DAT_01eb22ec;
      piStack_7c = DAT_01eb22ec;
      uStack_78 = FUN_0152d930(DAT_01eb22e8,DAT_01eb22ec);
      iVar9 = piVar11[0x10d];
      uStack_8 = 0xd;
      if (*(uint *)(iVar9 + 0x44) < 2) {
        (**(code **)(*piVar13 + 8))
                  (*(undefined4 *)(*(int *)piVar11[0x10d] + 0x10),**(undefined4 **)(iVar9 + 0x14),0,
                   0);
      }
      else {
        (**(code **)(*piVar13 + 0xc))
                  (*(undefined4 *)(*(int *)piVar11[0x10d] + 0x18),
                   *(undefined4 *)(*(int *)(iVar9 + 0x14) + 8),1);
      }
      uStack_8 = 0xe;
      FUN_0152dda0(piStack_20,piStack_54,uStack_78);
      uStack_8 = 0xffffffff;
    }
    if (DAT_01d60f70 == '\0') {
LAB_0079e27f:
      if (bStack_13 != '\0') {
        if (*(int *)(iStack_28 + 0x34) < DAT_01eb2300) {
          FUN_016f3809(&DAT_01eb2300);
          if (DAT_01eb2300 == -1) {
            uStack_8 = 0xf;
            uVar17 = FUN_0152dab0(&DAT_018fb928,"Linearize Depth to color target",0xffffffff);
            DAT_01eb22fc = (int *)((ulonglong)uVar17 >> 0x20);
            DAT_01eb22f8 = (int *)uVar17;
            uStack_8 = 0xffffffff;
            FUN_016f37bf(&DAT_01eb2300);
          }
        }
        piStack_20 = DAT_01eb22f8;
        piStack_80 = DAT_01eb22f8;
        piStack_54 = DAT_01eb22fc;
        piStack_7c = DAT_01eb22fc;
        uVar17 = FUN_0152d930(DAT_01eb22f8,DAT_01eb22fc);
        uStack_8 = 0x10;
        uStack_78 = uVar17;
        (**(code **)(*piVar13 + 0x14))(*(undefined4 *)(*(int *)(piVar11[0x10d] + 0x18) + 8),0,1,0,0)
        ;
        FUN_00829d10(*(undefined4 *)(*(int *)(piVar11[0x10d] + 0x18) + 8));
        piVar13 = param_2;
        iStack_1b0 = piVar11[0xea];
        iStack_1b4 = piVar11[0xe9];
        piStack_1bc = *(int **)(param_4 + 0x84);
        piStack_1b8 = *(int **)(param_4 + 0x88);
        piStack_34 = (int *)CONCAT22(piStack_34._2_2_,0x100);
        uStack_30._0_4_ = 0.0;
        uStack_30._4_4_ = (int *)((uint)uStack_30._6_2_ << 0x10);
        piStack_68 = piStack_1bc;
        piStack_64 = piStack_1b8;
        uStack_60._0_4_ = iStack_1b4;
        uStack_60._4_4_ = iStack_1b0;
        if (*(uint *)(piVar11[0x10d] + 0x44) < 2) {
          (**(code **)(*param_2 + 0x34))(0,*(undefined4 *)(piVar11[0x10d] + 4),&piStack_34);
          pcVar18 = "LinearizeDepthFS";
        }
        else {
          (**(code **)(*param_2 + 0x34))(4);
          pcVar18 = "LinearizeDepthAAFS";
        }
        uVar4 = (uint3)uStack_1c;
        uStack_1c = (int *)(uint)(uVar4 & 0xff);
        uStack_30._0_4_ = 2.3510604e-38;
        piStack_34 = (int *)0xf;
        uStack_30._4_4_ = (int *)((uint)uStack_30._4_4_ & 0xffffff00);
        FUN_0082a430(piVar13,*piVar11,"PassThroughVS",pcVar18,auStack_1cc,&piStack_34,
                     (int)&uStack_1c + 1);
        (**(code **)(*piVar13 + 0x18))();
        uStack_8 = 0x11;
        FUN_0152dda0(piStack_20,piStack_54,uStack_78);
        uStack_8 = 0xffffffff;
      }
LAB_0079e3f6:
      if (cStack_21 != '\0') {
LAB_0079e3fc:
        FUN_00825410(piVar13,piVar11[0x10c],**(undefined4 **)(piVar11[0x10d] + 0x18));
      }
    }
    else {
      if (bStack_13 == '\0') goto LAB_0079e3f6;
      if (cStack_12 != '\0') goto LAB_0079e27f;
      if ((char)piStack_48 != '\0') {
        FUN_00797d70(piVar13,param_4,**(undefined4 **)(piVar11[0x10d] + 0x14));
      }
      if (*(int *)(piVar11[0x10d] + 0x18) != 0) {
        FUN_00799940(piVar13,param_4);
      }
      if ((cStack_21 != '\0') && ((char)piStack_48 == '\0')) goto LAB_0079e3fc;
    }
    (**(code **)(*piVar13 + 0x14))(*(undefined4 *)(piVar11[0x10d] + 0x1c),0x11,0x11,0,0);
    if (((char)piStack_48 == '\0') || (cStack_12 == '\0')) {
      uVar21 = 0;
    }
    else {
      uVar21 = 1;
    }
    FUN_0078a340(piVar13,uVar21);
    (**(code **)(*piVar13 + 0x30))(0,piVar11 + 0x15,0x350);
    if (cStack_21 != '\0') {
      if ((char)piStack_48 == '\0') {
        iVar9 = FUN_01157030();
        FUN_00825160(param_2,**(undefined4 **)(piVar11[0x10d] + 0x18),
                     *(undefined4 *)(piVar11[0x10d] + 0x1c),iVar9 == 1);
        piVar13 = param_2;
      }
      else if (cStack_12 == '\0') {
        iVar9 = FUN_01157030();
        uStack_60._4_4_ = piVar11[0xea];
        uStack_60._0_4_ = piVar11[0xe9];
        piStack_64 = *(int **)(param_4 + 0x88);
        piStack_68 = *(int **)(param_4 + 0x84);
        FUN_00823ed0(param_2,*(undefined4 *)(piVar11[0x10d] + 0xc),
                     *(undefined4 *)(piVar11[0x10d] + 0x1c),&piStack_68,iVar9 == 1);
        piVar13 = param_2;
      }
    }
  }
  uVar21 = FUN_00793a40(&piStack_68);
  FUN_0079bb50(piVar13,piVar11[10] + 0x30,iStack_18 + 0x10,uVar21,0,0);
  uVar21 = FUN_00794220(&piStack_68);
  FUN_0079bb50(piVar13,piVar11[10] + 0x48,iStack_18 + 0x10,uVar21,0,0);
  uVar21 = FUN_00795360(&piStack_68);
  FUN_0079bb50(piVar13,piVar11[10] + 0x54,iStack_18 + 0x10,uVar21,0,0);
  uVar21 = FUN_00794ee0(&piStack_68);
  FUN_0079bb50(piVar13,piVar11[10] + 0x60,iStack_18 + 0x10,uVar21,0,0);
  if (((cStack_22 == '\0') || (*(char *)(piVar11[0x111] + 0x58) == '\0')) ||
     (fVar15 = *(float *)(piVar11[0x111] + 0x54),
     (NAN(fVar15) || NAN(DAT_018ce2f0)) != (fVar15 == DAT_018ce2f0))) {
    uVar21 = FUN_00793bc0(&piStack_68);
    ppiVar19 = (int **)0x0;
  }
  else {
    cVar6 = FUN_0078b680();
    if (cVar6 == '\0') {
LAB_0079e644:
      piVar11[0x54] = 0;
    }
    else {
      iVar9 = piVar11[0x111];
      if ((*(char *)(iVar9 + 0x58) == '\0') ||
         ((NAN(*(float *)(iVar9 + 0x54)) != (*(float *)(iVar9 + 0x54) == 0.0) &&
          ((*(char *)(iVar9 + 0x58) == '\0' ||
           (NAN(*(float *)(iVar9 + 0x50)) != (*(float *)(iVar9 + 0x50) == 0.0)))))))
      goto LAB_0079e644;
      fVar14 = (float10)FUN_008152d0();
      piStack_54 = (int *)(float)fVar14;
      piVar3 = DAT_018f784c;
      if ((float)DAT_018f784c <= (float)piStack_54) {
        piVar3 = piStack_54;
      }
      piVar11[0x54] = (uint)piVar3 ^ DAT_018c4ea0;
    }
    (**(code **)(*piVar13 + 0x30))(0,piVar11 + 0x15,0x350);
    FUN_0078a340(piVar13,0);
    piStack_7c = &uStack_1c;
    uStack_1c = (int *)CONCAT13(uStack_1c._3_1_,4);
    fVar14 = (float10)FUN_008151f0(1);
    uStack_78._4_4_ = (int *)CONCAT31(uStack_78._5_3_,1);
    uStack_78._0_4_ = (float)fVar14;
    uVar21 = FUN_007946a0(&piStack_68);
    ppiVar19 = &piStack_7c;
  }
  FUN_0079bb50(piVar13,piVar11[10] + 0x6c,iStack_18 + 0x10,uVar21,ppiVar19,0);
  if (cStack_22 != '\0') {
    (**(code **)(*piVar13 + 0x18))();
    (**(code **)(*piVar13 + 0x14))(*(undefined4 *)(piVar11[0x10d] + 0x1c),0x11,0x11,0,0);
    if (((char)piStack_48 == '\0') || (cStack_12 == '\0')) {
      uVar21 = 0;
    }
    else {
      uVar21 = 1;
    }
    FUN_0078a340(piVar13,uVar21);
    FUN_0078b680();
    piVar11[0x54] = 0;
    (**(code **)(*piVar13 + 0x30))(0,piVar11 + 0x15,0x350);
  }
  piStack_54 = (int *)piVar11[0x77];
  piStack_20 = (int *)piVar11[0x78];
  piVar11[0x77] = 0;
  piVar11[0x78] = 0;
  (**(code **)(*piVar13 + 0x30))(0,piVar11 + 0x15,0x350);
  uVar21 = FUN_00794760(&piStack_68);
  FUN_0079bb50(piVar13,piVar11[10] + 0x78,iStack_18 + 0x10,uVar21,0,0);
  piVar11[0x77] = (int)piStack_54;
  piVar11[0x78] = (int)piStack_20;
  (**(code **)(*piVar13 + 0x30))(0,piVar11 + 0x15,0x350);
  piVar3 = *(int **)(*piVar11 + 0x578);
  if (piVar3 != (int *)0x0) {
    (**(code **)(*piVar3 + 0x18))(piVar13,*piVar11,param_4);
  }
  if (*(int *)(iStack_28 + 0x34) < DAT_01eb23b8) {
    FUN_016f3809(&DAT_01eb23b8);
    if (DAT_01eb23b8 == -1) {
      uStack_8 = 0x12;
      uVar17 = FUN_0152dab0("Render",&DAT_018fdbdc,0xffffffff);
      DAT_01eb23b4 = (int *)((ulonglong)uVar17 >> 0x20);
      DAT_01eb23b0 = (int *)uVar17;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb23b8);
    }
  }
  piStack_44 = DAT_01eb23b0;
  piStack_80 = DAT_01eb23b0;
  uStack_1c = DAT_01eb23b4;
  piStack_7c = DAT_01eb23b4;
  uVar17 = FUN_0152d930(DAT_01eb23b0,DAT_01eb23b4);
  uStack_8 = 0x13;
  uStack_78 = uVar17;
  if (*(int *)(iStack_28 + 0x34) < DAT_01eb23c8) {
    FUN_016f3809(&DAT_01eb23c8);
    if (DAT_01eb23c8 == -1) {
      uStack_8._0_1_ = 0x14;
      uVar17 = FUN_0152dab0(&DAT_018fb928,&DAT_018fdbdc,0xffffffff);
      DAT_01eb23c4 = (int *)((ulonglong)uVar17 >> 0x20);
      DAT_01eb23c0 = (int *)uVar17;
      uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
      FUN_016f37bf(&DAT_01eb23c8);
    }
  }
  piStack_40 = DAT_01eb23c0;
  piStack_38 = DAT_01eb23c0;
  piStack_20 = DAT_01eb23c4;
  piStack_34 = DAT_01eb23c4;
  uStack_30 = FUN_0152d930(DAT_01eb23c0,DAT_01eb23c4);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
  FUN_0078af00();
  FUN_007fa2f0(piVar13,param_4,iStack_18 + 0x30);
  if (*(char *)(piVar11 + 0x124) != '\0') {
    uVar21 = FUN_00793fe0(&piStack_68);
    FUN_0079bb50(piVar13,piVar11[10] + 0x90,iStack_18 + 0x10,uVar21,0,0);
    fStack_70 = 0.0;
    do {
      FUN_0078af00();
      FUN_007fa410(piVar13,param_4,iStack_18 + 0x50,fStack_70);
      fStack_70 = (float)((int)fStack_70 + 1);
    } while ((int)fStack_70 < 0xb);
    piVar13 = piStack_50;
    piVar11 = aiStack_7e0;
    for (iVar9 = 0xd4; piVar3 = piStack_3c, iVar9 != 0; iVar9 = iVar9 + -1) {
      *piVar11 = *piVar13;
      piVar13 = piVar13 + 1;
      piVar11 = piVar11 + 1;
    }
    piStack_50 = (int *)(**(code **)(**(int **)(*piStack_3c + 0x3c) + 0x20))();
    iVar9 = (**(code **)(**(int **)(*piVar3 + 0x3c) + 0x40))();
    piStack_54 = (int *)CONCAT31(piStack_54._1_3_,*(undefined *)(iVar9 + 0x39));
    iVar9 = FUN_0078af10();
    iVar8 = FUN_0078af20();
    FUN_007cc9d0();
    uVar21 = FUN_01165df0();
    FUN_007cdb40(uVar21);
    FUN_007cd5d0((float)iVar8,(float)iVar9,&DAT_bf800000,0x3f800000,piStack_54,piStack_50);
    FUN_007ce460(auStack_490);
    piVar13 = param_2;
    (**(code **)(*param_2 + 0x30))(0,aiStack_7e0,0x350);
    uVar21 = FUN_007940a0(&piStack_68);
    FUN_0079bb50(piVar13,piStack_3c[10] + 0x9c,iStack_18 + 0x30,uVar21,0,0);
    FUN_0078af00();
    uVar21 = FUN_0078af10();
    uVar20 = FUN_0078af20();
    piVar13 = param_2;
    FUN_007fa140(param_2,uVar20,uVar21,iStack_18 + 0x30,0);
    piVar11 = piStack_3c;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
  FUN_0152dda0(piStack_40,piStack_20,uStack_30);
  uStack_8 = 0x17;
  FUN_0152dda0(piStack_44,uStack_1c,uStack_78);
  uStack_8 = 0xffffffff;
  (**(code **)(*piVar13 + 0x18))();
  if ((iStack_8c != iStack_88) && (cStack_22 == '\0')) {
    FUN_0079c0c0(piVar13,*(undefined4 *)(piVar11[0x10d] + 0x1c),iStack_18);
  }
  iVar9 = iStack_28;
  if ((1 < *(uint *)(piVar11[0x10d] + 0x44)) && (cStack_49 == '\0')) {
    if (*(int *)(iStack_28 + 0x34) < DAT_01eb2408) {
      FUN_016f3809(&DAT_01eb2408);
      if (DAT_01eb2408 == -1) {
        uStack_8 = 0x18;
        uVar17 = FUN_0152dab0("Render",&DAT_018fdcec,0xffffffff);
        DAT_01eb2404 = (int *)((ulonglong)uVar17 >> 0x20);
        DAT_01eb2400 = (int *)uVar17;
        uStack_8 = 0xffffffff;
        FUN_016f37bf(&DAT_01eb2408);
      }
    }
    piStack_20 = DAT_01eb2400;
    piStack_80 = DAT_01eb2400;
    piStack_54 = DAT_01eb2404;
    piStack_7c = DAT_01eb2404;
    uVar17 = FUN_0152d930(DAT_01eb2400,DAT_01eb2404);
    uStack_8 = 0x19;
    uStack_78 = uVar17;
    if (*(int *)(iVar9 + 0x34) < DAT_01eb2418) {
      FUN_016f3809(&DAT_01eb2418);
      if (DAT_01eb2418 == -1) {
        uStack_8._0_1_ = 0x1a;
        uVar17 = FUN_0152dab0(&DAT_018fb928,&DAT_018fdcec,0xffffffff);
        DAT_01eb2414 = (int *)((ulonglong)uVar17 >> 0x20);
        DAT_01eb2410 = (int *)uVar17;
        uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
        FUN_016f37bf(&DAT_01eb2418);
      }
    }
    piStack_50 = DAT_01eb2410;
    piStack_68 = DAT_01eb2410;
    piStack_44 = DAT_01eb2414;
    piStack_64 = DAT_01eb2414;
    uVar17 = FUN_0152d930(DAT_01eb2410,DAT_01eb2414);
    uStack_8._0_1_ = 0x1b;
    uStack_60 = uVar17;
    (**(code **)(*piVar13 + 0xc))
              (*(undefined4 *)(*(int *)piStack_3c[0x10d] + 0x18),
               *(undefined4 *)(*(int *)piStack_3c[0x10d] + 0x10),1);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x1c);
    FUN_0152dda0(piStack_50,piStack_44,(int)uStack_60,(int)((ulonglong)uVar17 >> 0x20));
    uStack_8 = 0x1d;
    FUN_0152dda0(piStack_20,piStack_54,uStack_78);
    uStack_8 = 0xffffffff;
    piVar13 = param_2;
    piVar11 = piStack_3c;
  }
  if (cStack_22 == '\0') goto LAB_0079ee4c;
  if (*(int *)(iStack_28 + 0x34) < DAT_01eb2428) {
    FUN_016f3809(&DAT_01eb2428);
    if (DAT_01eb2428 == -1) {
      uStack_8 = 0x1e;
      uVar17 = FUN_0152dab0(&DAT_018fb928,"Depth of Field",0xffffffff);
      DAT_01eb2424 = (int *)((ulonglong)uVar17 >> 0x20);
      DAT_01eb2420 = (int *)uVar17;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb2428);
    }
  }
  piStack_54 = DAT_01eb2420;
  piStack_80 = DAT_01eb2420;
  piStack_50 = DAT_01eb2424;
  piStack_7c = DAT_01eb2424;
  uVar17 = FUN_0152d930(DAT_01eb2420,DAT_01eb2424);
  uStack_8 = 0x1f;
  uStack_78 = uVar17;
  if ((*(char *)(piVar11[0x111] + 0x58) != '\0') &&
     (fVar15 = *(float *)(piVar11[0x111] + 0x54), NAN(fVar15) == (fVar15 == 0.0))) {
    FUN_007a0100(piVar13,*(undefined4 *)(piVar11[0x10d] + 0x24),1);
    piStack_44 = (int *)piVar11[0x111];
    puVar10 = *(undefined4 **)piVar11[0x10d];
    if (puVar10[1] != 0) {
      LOCK();
      piVar3 = (int *)(puVar10[1] + 4);
      *piVar3 = *piVar3 + 1;
      UNLOCK();
    }
    uVar21 = *puVar10;
    uVar20 = puVar10[1];
    iVar9 = piVar11[0x10d];
    if (*(int *)(iVar9 + 0x10) != 0) {
      LOCK();
      piVar3 = (int *)(*(int *)(iVar9 + 0x10) + 4);
      *piVar3 = *piVar3 + 1;
      UNLOCK();
    }
    FUN_00815320(piVar13,*(undefined4 *)(iVar9 + 0xc),*(undefined4 *)(iVar9 + 0x10),uVar21,uVar20);
    (**(code **)(*piVar13 + 0x14))(*(undefined4 *)(*(int *)piVar11[0x10d] + 0x10),0x11,1,0,0);
    cVar6 = FUN_0078b680();
    if (cVar6 == '\0') {
LAB_0079ecc9:
      piVar11[0x54] = 0;
    }
    else {
      iVar9 = piVar11[0x111];
      if ((*(char *)(iVar9 + 0x58) == '\0') ||
         ((NAN(*(float *)(iVar9 + 0x54)) != (*(float *)(iVar9 + 0x54) == 0.0) &&
          ((*(char *)(iVar9 + 0x58) == '\0' ||
           (NAN(*(float *)(iVar9 + 0x50)) != (*(float *)(iVar9 + 0x50) == 0.0)))))))
      goto LAB_0079ecc9;
      fVar14 = (float10)FUN_008152d0();
      piStack_44 = (int *)(float)fVar14;
      piVar3 = DAT_018f784c;
      if ((float)DAT_018f784c <= (float)piStack_44) {
        piVar3 = piStack_44;
      }
      piVar11[0x54] = (int)piVar3;
    }
    (**(code **)(*piVar13 + 0x30))(0,piVar11 + 0x15,0x350);
    if (((char)piStack_48 == '\0') || (cStack_12 == '\0')) {
      uVar21 = 0;
    }
    else {
      uVar21 = 1;
    }
    FUN_0078a340(piVar13,uVar21);
    piStack_34 = &uStack_1c;
    uStack_1c = (int *)CONCAT13(uStack_1c._3_1_,4);
    fVar14 = (float10)FUN_008151f0(0);
    uStack_30._4_4_ = (int *)((uint)uStack_30._4_4_ & 0xffffff00);
    uStack_30._0_4_ = (float)fVar14;
    uVar21 = FUN_007943a0(&piStack_68);
    FUN_0079bb50(piVar13,piVar11[10] + 0x6c,iStack_18 + 0x10,uVar21,&piStack_34,0);
    (**(code **)(*piVar13 + 0x18))();
  }
  if ((*(char *)(piVar11[0x111] + 0x58) != '\0') &&
     (fVar15 = *(float *)(piVar11[0x111] + 0x50), NAN(fVar15) == (fVar15 == 0.0))) {
    FUN_007a0100(piVar13,*(undefined4 *)(piVar11[0x10d] + 0x24),0);
    piStack_44 = (int *)piVar11[0x111];
    puVar10 = *(undefined4 **)piVar11[0x10d];
    if (puVar10[1] != 0) {
      LOCK();
      piVar3 = (int *)(puVar10[1] + 4);
      *piVar3 = *piVar3 + 1;
      UNLOCK();
    }
    uVar21 = *puVar10;
    uVar20 = puVar10[1];
    iVar9 = piVar11[0x10d];
    if (*(int *)(iVar9 + 0x10) != 0) {
      LOCK();
      piVar3 = (int *)(*(int *)(iVar9 + 0x10) + 4);
      *piVar3 = *piVar3 + 1;
      UNLOCK();
    }
    FUN_00815cd0(piVar13,*(undefined4 *)(iVar9 + 0xc),*(undefined4 *)(iVar9 + 0x10),uVar21,uVar20);
  }
  FUN_0078b680();
  piVar11[0x54] = 0;
  if (iStack_8c != iStack_88) {
    FUN_0079c0c0(piVar13,*(undefined4 *)(*(int *)piVar11[0x10d] + 0x10),iStack_18);
  }
  uStack_8 = 0x20;
  FUN_0152dda0(piStack_54,piStack_50,uStack_78);
LAB_0079ee4c:
  iStack_88 = 0;
  uStack_cc._0_4_ = 0;
  piStack_48 = (int *)0x0;
  uStack_cc._4_4_ = (int *)0x0;
  uStack_8 = 0x21;
  if ((((char)piStack_6c == '\0') &&
      ((*(char *)(piVar11[0x10f] + 0xc) == '\0' ||
       (*(float *)(piVar11[0x10f] + 0x10) <= DAT_018fd178)))) || (bStack_13 = 1, iStack_84 < 1)) {
    bStack_13 = 0;
  }
  cVar6 = FUN_0078bd10();
  if (((cVar6 == '\0') || (*(float *)(piVar11[0x10f] + 0x10) <= DAT_018ce2f0)) ||
     (pfVar1 = (float *)(piVar11[0x10f] + 0x18), DAT_018e3f8c < *pfVar1 || DAT_018e3f8c == *pfVar1))
  {
    bVar7 = 0;
  }
  else {
    bVar7 = 1;
  }
  bStack_13 = bStack_13 | bVar7;
  if (bStack_13 != 0) {
    if (*(int *)(iStack_28 + 0x34) < DAT_01eb2450) {
      FUN_016f3809(&DAT_01eb2450);
      if (DAT_01eb2450 == -1) {
        uStack_8._0_1_ = 0x22;
        uVar17 = FUN_0152dab0("Render",&DAT_018fdd04,0xffffffff);
        DAT_01eb244c = (int *)((ulonglong)uVar17 >> 0x20);
        DAT_01eb2448 = (int *)uVar17;
        uStack_8 = CONCAT31(uStack_8._1_3_,0x21);
        FUN_016f37bf(&DAT_01eb2450);
      }
    }
    piStack_20 = DAT_01eb2448;
    piStack_c4 = DAT_01eb2448;
    piStack_54 = DAT_01eb244c;
    piStack_c0 = DAT_01eb244c;
    uStack_bc = FUN_0152d930(DAT_01eb2448,DAT_01eb244c);
    uStack_8._0_1_ = 0x23;
    if (*(int *)(iStack_28 + 0x34) < DAT_01eb2460) {
      FUN_016f3809(&DAT_01eb2460);
      if (DAT_01eb2460 == -1) {
        uStack_8._0_1_ = 0x24;
        uVar17 = FUN_0152dab0(&DAT_018fb928,&DAT_018fdd04,0xffffffff);
        DAT_01eb245c = (int *)((ulonglong)uVar17 >> 0x20);
        DAT_01eb2458 = (int *)uVar17;
        uStack_8._0_1_ = 0x23;
        FUN_016f37bf(&DAT_01eb2460);
      }
    }
    piStack_50 = DAT_01eb2458;
    piStack_38 = DAT_01eb2458;
    piStack_44 = DAT_01eb245c;
    piStack_34 = DAT_01eb245c;
    uVar17 = FUN_0152d930(DAT_01eb2458,DAT_01eb245c);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x25);
    uStack_30 = uVar17;
    puVar10 = (undefined4 *)
              FUN_00795f40(&uStack_78,piVar13,**(undefined4 **)piVar11[0x10d],iStack_84,
                           piVar11[0x10c],piVar11[0x106],uStack_a4,uStack_90);
    uStack_cc._4_4_ = (int *)puVar10[1];
    uStack_cc._0_4_ = *puVar10;
    *puVar10 = 0;
    puVar10[1] = 0;
    piStack_6c = uStack_78._4_4_;
    iStack_88 = (undefined4)uStack_cc;
    piStack_48 = uStack_cc._4_4_;
    if (uStack_78._4_4_ != (int *)0x0) {
      LOCK();
      iVar9 = uStack_78._4_4_[1] + -1;
      uStack_78._4_4_[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*uStack_78._4_4_)();
        LOCK();
        iVar9 = piStack_6c[2] + -1;
        piStack_6c[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_6c + 4))();
        }
      }
    }
    uStack_8._0_1_ = 0x26;
    FUN_0152dda0(piStack_50,piStack_44,uStack_30);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x27);
    FUN_0152dda0(piStack_20,piStack_54,uStack_bc);
  }
  iStack_8c = 0;
  uStack_bc._0_4_ = 0;
  uStack_1c = (int *)0x0;
  uStack_bc._4_4_ = (int *)0x0;
  uStack_8._0_1_ = 0x28;
  if (cStack_23 != '\0') {
    if (*(int *)(iStack_28 + 0x34) < DAT_01eb2470) {
      FUN_016f3809(&DAT_01eb2470);
      if (DAT_01eb2470 == -1) {
        uStack_8._0_1_ = 0x29;
        uVar17 = FUN_0152dab0("Render","SunRays",0xffffffff);
        DAT_01eb246c = (int *)((ulonglong)uVar17 >> 0x20);
        DAT_01eb2468 = (int *)uVar17;
        uStack_8._0_1_ = 0x28;
        FUN_016f37bf(&DAT_01eb2470);
      }
    }
    piStack_20 = DAT_01eb2468;
    piStack_a0 = DAT_01eb2468;
    piStack_54 = DAT_01eb246c;
    piStack_9c = DAT_01eb246c;
    uStack_98 = FUN_0152d930(DAT_01eb2468,DAT_01eb246c);
    uStack_8._0_1_ = 0x2a;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x2a;
    if (*(int *)(iStack_28 + 0x34) < DAT_01eb2480) {
      uStack_8._0_1_ = uVar5;
      FUN_016f3809(&DAT_01eb2480);
      if (DAT_01eb2480 == -1) {
        uStack_8._0_1_ = 0x2b;
        uVar17 = FUN_0152dab0(&DAT_018fb928,"SunRays",0xffffffff);
        DAT_01eb247c = (int *)((ulonglong)uVar17 >> 0x20);
        DAT_01eb2478 = (int *)uVar17;
        uStack_8._0_1_ = 0x2a;
        FUN_016f37bf(&DAT_01eb2480);
      }
    }
    piStack_50 = DAT_01eb2478;
    piStack_38 = DAT_01eb2478;
    piStack_44 = DAT_01eb247c;
    piStack_34 = DAT_01eb247c;
    uVar17 = FUN_0152d930(DAT_01eb2478,DAT_01eb247c);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x2c);
    uStack_30 = uVar17;
    puVar10 = (undefined4 *)
              FUN_00796e30(&uStack_78,piVar13,**(undefined4 **)(piVar11[0x10d] + 0x18),
                           piVar11[0x10c],uStack_90,param_4);
    uStack_bc._4_4_ = (int *)puVar10[1];
    uStack_bc._0_4_ = *puVar10;
    *puVar10 = 0;
    puVar10[1] = 0;
    piStack_6c = uStack_78._4_4_;
    iStack_8c = (undefined4)uStack_bc;
    uStack_1c = uStack_bc._4_4_;
    if (uStack_78._4_4_ != (int *)0x0) {
      LOCK();
      iVar9 = uStack_78._4_4_[1] + -1;
      uStack_78._4_4_[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*uStack_78._4_4_)();
        LOCK();
        iVar9 = piStack_6c[2] + -1;
        piStack_6c[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_6c + 4))();
        }
      }
    }
    uStack_8._0_1_ = 0x2d;
    FUN_0152dda0(piStack_50,piStack_44,uStack_30);
    uStack_8._0_1_ = 0x2e;
    FUN_0152dda0(piStack_20,piStack_54,uStack_98);
  }
  uStack_78._0_4_ = 0.0;
  piStack_40 = (int *)0x0;
  uStack_78._4_4_ = (int *)0x0;
  uStack_8._0_1_ = 0x2f;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x2f;
  if (*(char *)(piVar11[0x110] + 4) == '\0') {
    fStack_70 = 0.0;
  }
  else {
    fVar16 = (*(float *)(piVar11[0x110] + 8) * DAT_018f993c - 0.0) * DAT_018fde70;
    fVar15 = 0.0;
    if (0.0 <= fVar16) {
      fVar15 = fVar16;
    }
    fStack_70 = DAT_018ce2f8;
    if (fVar15 <= DAT_018ce2f8) {
      fStack_70 = fVar15;
    }
    uStack_ac = CONCAT44(uStack_ac._4_4_,(undefined4)uStack_ac);
    if (0.0 < fStack_70) {
      if (*(int *)(iStack_28 + 0x34) < DAT_01eb2490) {
        uStack_8._0_1_ = uVar5;
        FUN_016f3809(&DAT_01eb2490);
        if (DAT_01eb2490 == -1) {
          uStack_8._0_1_ = 0x30;
          uVar17 = FUN_0152dab0("Render","BlurFx",0xffffffff);
          DAT_01eb248c = (int *)((ulonglong)uVar17 >> 0x20);
          DAT_01eb2488 = (int *)uVar17;
          uStack_8._0_1_ = 0x2f;
          FUN_016f37bf(&DAT_01eb2490);
        }
      }
      uStack_98._4_4_ = DAT_01eb2488;
      piStack_68 = DAT_01eb2488;
      piStack_20 = DAT_01eb248c;
      piStack_64 = DAT_01eb248c;
      uVar17 = FUN_0152d930(DAT_01eb2488,DAT_01eb248c);
      uStack_8._0_1_ = 0x31;
      uVar5 = (undefined)uStack_8;
      uStack_8._0_1_ = 0x31;
      uStack_60 = uVar17;
      if (*(int *)(iStack_28 + 0x34) < DAT_01eb24a0) {
        uStack_8._0_1_ = uVar5;
        FUN_016f3809(&DAT_01eb24a0);
        if (DAT_01eb24a0 == -1) {
          uStack_8._0_1_ = 0x32;
          uVar17 = FUN_0152dab0(&DAT_018fb928,"BlurFx",0xffffffff);
          DAT_01eb249c = (int *)((ulonglong)uVar17 >> 0x20);
          DAT_01eb2498 = (int *)uVar17;
          uStack_8._0_1_ = 0x31;
          FUN_016f37bf(&DAT_01eb24a0);
        }
      }
      piStack_54 = DAT_01eb2498;
      piStack_b4 = DAT_01eb2498;
      piStack_50 = DAT_01eb249c;
      piStack_b0 = DAT_01eb249c;
      uStack_ac = FUN_0152d930(DAT_01eb2498,DAT_01eb249c);
      piStack_44 = (int *)piVar11[0x110];
      iVar9 = piVar11[0xeb];
      uStack_8 = CONCAT31(uStack_8._1_3_,0x33);
      uVar21 = *(undefined4 *)(piVar11[0x10f] + 4);
      piStack_6c = (int *)**(undefined4 **)piVar11[0x10d];
      if (uStack_1c != (int *)0x0) {
        LOCK();
        uStack_1c[1] = uStack_1c[1] + 1;
        UNLOCK();
      }
      if (piStack_48 != (int *)0x0) {
        LOCK();
        piStack_48[1] = piStack_48[1] + 1;
        UNLOCK();
      }
      puVar10 = (undefined4 *)
                FUN_00799b60(&uStack_30,piVar13,piStack_6c,iStack_88,piStack_48,iStack_8c,uStack_1c,
                             uVar21,iVar9,iStack_84 < 2,uStack_a4,uStack_90);
      uStack_78._0_4_ = (float)*puVar10;
      uStack_78._4_4_ = (int *)puVar10[1];
      *puVar10 = 0;
      puVar10[1] = 0;
      piStack_6c = uStack_30._4_4_;
      piStack_40 = uStack_78._4_4_;
      if (uStack_30._4_4_ != (int *)0x0) {
        LOCK();
        iVar9 = uStack_30._4_4_[1] + -1;
        uStack_30._4_4_[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*uStack_30._4_4_)();
          LOCK();
          iVar9 = piStack_6c[2] + -1;
          piStack_6c[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piStack_6c + 4))();
          }
        }
      }
      piVar3 = piStack_48;
      if (DAT_018ce2f8 <= fStack_70) {
        uStack_cc._0_4_ = 0;
        piStack_6c = piStack_48;
        piStack_48 = (int *)0x0;
        uStack_cc._4_4_ = (int *)0x0;
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar9 = piVar3[1] + -1;
          piVar3[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar9 = piStack_6c[2] + -1;
            piStack_6c[2] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)(*piStack_6c + 4))();
            }
          }
        }
        FUN_0058a2b0();
        uStack_1c = uStack_bc._4_4_;
      }
      uStack_8._0_1_ = 0x34;
      FUN_0152dda0(piStack_54,piStack_50,uStack_ac);
      uStack_8._0_1_ = 0x35;
      FUN_0152dda0(uStack_98._4_4_,piStack_20,uStack_60);
    }
  }
  uStack_8._0_1_ = 0x2f;
  uStack_14c = 0;
  FUN_01165ab0();
  iStack_108 = 0;
  uStack_104 = 0;
  uStack_100 = 0;
  uStack_f8 = 0;
  piStack_f4 = (int *)0x0;
  uStack_f0 = 0;
  uStack_ec = 0;
  uStack_e8 = 0;
  uStack_e4 = 0;
  uStack_8._0_1_ = 0x36;
  uStack_e0 = 0;
  uStack_d8 = 0;
  cVar6 = FUN_0078bd10();
  if (((cVar6 == '\0') || (1 < iStack_84)) || (bStack_13 == 0)) {
    uVar12 = 0;
  }
  else {
    uVar12 = 2;
  }
  uStack_14c = uStack_14c | (double)(float)piVar11[0x14] <= DAT_018fde80 | uVar12 | 4;
  uStack_d8 = uStack_90;
  FUN_0056ecd0(&uStack_78);
  uStack_100 = CONCAT44(fStack_70,(int *)uStack_100);
  FUN_0056ecd0(&uStack_bc);
  uStack_e0._0_5_ = CONCAT14((undefined)uStack_a4,(int *)uStack_e0);
  FUN_0056ecd0(&uStack_cc);
  iVar9 = piVar11[0x10f];
  uStack_f0 = *(undefined4 *)(iVar9 + 4);
  uStack_ec = *(undefined4 *)(iVar9 + 0x18);
  uStack_e8 = *(undefined4 *)(iVar9 + 0x10);
  puVar10 = (undefined4 *)FUN_00798bf0(&iStack_18c);
  uVar12 = param_3;
  puStack_58 = (undefined4 *)0x0;
  piStack_54 = (int *)0x0;
  uStack_148 = *puVar10;
  uStack_144 = puVar10[1];
  uStack_140 = puVar10[2];
  uStack_13c = puVar10[3];
  uStack_138 = puVar10[4];
  uStack_134 = puVar10[5];
  uStack_130 = puVar10[6];
  uStack_12c = puVar10[7];
  uStack_128 = puVar10[8];
  uStack_124 = puVar10[9];
  uStack_120 = puVar10[10];
  uStack_11c = puVar10[0xb];
  uStack_118 = puVar10[0xc];
  uStack_114 = puVar10[0xd];
  uStack_110 = puVar10[0xe];
  uStack_10c = puVar10[0xf];
  iStack_108 = piVar11[0xeb];
  uStack_8 = CONCAT31(uStack_8._1_3_,0x37);
  cStack_23 = (float)DAT_01d60ed4 / DAT_018ce320 <= *(float *)(*piVar11 + 0x594);
  if ((NAN(*(float *)(*piVar11 + 0x594)) || NAN((float)DAT_01d60ed4 / DAT_018ce320)) ||
      !(bool)cStack_23) {
    (**(code **)(*piVar13 + 0x14))(param_3,0,1,0,0);
    piVar13 = param_2;
    FUN_00829e70(param_2,*piVar11,**(undefined4 **)piVar11[0x10d],&uStack_14c,uVar12);
  }
  else {
    iVar9 = **(int **)piVar11[0x10d];
    FUN_007994e0(&uStack_98,*(undefined4 *)(iVar9 + 0x30),*(undefined4 *)(iVar9 + 0x34),1,
                 *(undefined4 *)(iVar9 + 0x2c));
    FUN_005587e0(&uStack_98);
    if (uStack_98._4_4_ != (undefined4 *)0x0) {
      LOCK();
      iVar9 = uStack_98._4_4_[1] + -1;
      uStack_98._4_4_[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*uStack_98._4_4_)();
        LOCK();
        iVar9 = uStack_98._4_4_[2] + -1;
        uStack_98._4_4_[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*uStack_98._4_4_ + 4))();
        }
      }
    }
    (**(code **)(*piVar13 + 0x14))(puStack_58[2],0,1,0,0);
    FUN_00829e70(piVar13,*piVar11,**(undefined4 **)piVar11[0x10d],&uStack_14c,puStack_58[2]);
    (**(code **)(*piVar13 + 0x18))();
    (**(code **)(*piVar13 + 0x14))(param_3,0,1,0,0);
    iVar9 = iStack_28;
    if (*(int *)(iStack_28 + 0x34) < DAT_01eb24b0) {
      FUN_016f3809(&DAT_01eb24b0);
      if (DAT_01eb24b0 == -1) {
        uStack_8._0_1_ = 0x38;
        uVar17 = FUN_0152dab0("Render","RetinaBlit",0xffffffff);
        DAT_01eb24ac = (int *)((ulonglong)uVar17 >> 0x20);
        DAT_01eb24a8 = (int *)uVar17;
        uStack_8 = CONCAT31(uStack_8._1_3_,0x37);
        FUN_016f37bf(&DAT_01eb24b0);
      }
    }
    piStack_50 = DAT_01eb24a8;
    piStack_68 = DAT_01eb24a8;
    piStack_44 = DAT_01eb24ac;
    piStack_64 = DAT_01eb24ac;
    uVar17 = FUN_0152d930(DAT_01eb24a8,DAT_01eb24ac);
    uStack_8._0_1_ = 0x39;
    uStack_60 = uVar17;
    if (*(int *)(iVar9 + 0x34) < DAT_01eb24c0) {
      FUN_016f3809(&DAT_01eb24c0);
      if (DAT_01eb24c0 == -1) {
        uStack_8._0_1_ = 0x3a;
        uVar17 = FUN_0152dab0(&DAT_018fb928,"RetinaBlit",0xffffffff);
        DAT_01eb24bc = (int *)((ulonglong)uVar17 >> 0x20);
        DAT_01eb24b8 = (int *)uVar17;
        uStack_8._0_1_ = 0x39;
        FUN_016f37bf(&DAT_01eb24c0);
      }
    }
    piStack_6c = DAT_01eb24b8;
    piStack_b4 = DAT_01eb24b8;
    uStack_98._4_4_ = DAT_01eb24bc;
    piStack_b0 = DAT_01eb24bc;
    uVar17 = FUN_0152d930(DAT_01eb24b8,DAT_01eb24bc);
    uStack_8._0_1_ = 0x3b;
    uStack_ac = uVar17;
    FUN_00829d10(param_3);
    piStack_34 = (int *)CONCAT22(piStack_34._2_2_,0x101);
    uStack_30._0_4_ = 0.0;
    uStack_30._4_4_ = (int *)((uint)uStack_30._4_4_ & 0xffff0000);
    (**(code **)(*param_2 + 0x34))(0,*puStack_58,&piStack_34);
    uVar4 = (uint3)param_3;
    param_3 = (uint)(uVar4 & 0xff);
    uStack_30._0_4_ = 2.3510604e-38;
    piStack_34 = (int *)&DAT_0000000f;
    uStack_30._4_4_ = (int *)((uint)uStack_30._4_4_ & 0xffffff00);
    FUN_0082a430(param_2,*piStack_3c,"PassThroughVS","PassThroughFS",auStack_1cc,&piStack_34,
                 (int)&param_3 + 1);
    uStack_8._0_1_ = 0x3c;
    FUN_0152dda0(piStack_6c,uStack_98._4_4_,uVar17);
    uStack_8._0_1_ = 0x3d;
    FUN_0152dda0(piStack_50,piStack_44,uStack_60);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x37);
    piVar13 = param_2;
    piVar11 = piStack_3c;
  }
  FUN_0079d440(piVar13,param_4,iStack_18);
  iVar9 = (**(code **)(*piVar13 + 0x18))();
  if (param_5 != 0) {
    (**(code **)(*piVar13 + 0x14))(param_5,0,1,0,0);
    if (cStack_23 == '\0') {
      FUN_00829e70(piVar13,*piVar11,**(undefined4 **)piVar11[0x10d],&uStack_14c,param_5);
    }
    else {
      FUN_00829d10(param_5);
      piStack_34 = (int *)CONCAT22(piStack_34._2_2_,0x101);
      uStack_30._0_4_ = 0.0;
      uStack_30._4_4_ = (int *)((uint)uStack_30._4_4_ & 0xffff0000);
      (**(code **)(*piVar13 + 0x34))(0,*puStack_58,&piStack_34);
      uVar4 = (uint3)param_2;
      param_2 = (int *)(uint)(uVar4 & 0xff);
      uStack_30._0_4_ = 2.3510604e-38;
      piStack_34 = (int *)&DAT_0000000f;
      uStack_30._4_4_ = (int *)((uint)uStack_30._4_4_ & 0xffffff00);
      FUN_0082a430(piVar13,*piVar11,"PassThroughVS","PassThroughFS",auStack_24c,&piStack_34,
                   (int)&param_2 + 1);
    }
    FUN_0079d440(piVar13,param_4,iStack_18);
    iVar9 = (**(code **)(*piVar13 + 0x18))();
  }
  piVar13 = piStack_54;
  if (piStack_54 != (int *)0x0) {
    LOCK();
    piVar11 = piStack_54 + 1;
    iVar8 = *piVar11;
    iVar9 = *piVar11;
    *piVar11 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      (**(code **)*piStack_54)();
      LOCK();
      piVar11 = piVar13 + 2;
      iVar8 = *piVar11;
      iVar9 = *piVar11;
      *piVar11 = iVar8 + -1;
      UNLOCK();
      if (iVar8 + -1 == 0) {
        iVar9 = (**(code **)(*piVar13 + 4))();
      }
    }
  }
  piVar13 = (int *)uStack_e0;
  if ((int *)uStack_e0 != (int *)0x0) {
    LOCK();
    piVar11 = (int *)uStack_e0 + 1;
    iVar8 = *piVar11;
    iVar9 = *piVar11;
    *piVar11 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      (**(code **)*(int *)uStack_e0)();
      LOCK();
      piVar11 = piVar13 + 2;
      iVar8 = *piVar11;
      iVar9 = *piVar11;
      *piVar11 = iVar8 + -1;
      UNLOCK();
      if (iVar8 + -1 == 0) {
        iVar9 = (**(code **)(*piVar13 + 4))();
      }
    }
  }
  piVar13 = piStack_f4;
  if (piStack_f4 != (int *)0x0) {
    LOCK();
    piVar11 = piStack_f4 + 1;
    iVar8 = *piVar11;
    iVar9 = *piVar11;
    *piVar11 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      (**(code **)*piStack_f4)();
      LOCK();
      piVar11 = piVar13 + 2;
      iVar8 = *piVar11;
      iVar9 = *piVar11;
      *piVar11 = iVar8 + -1;
      UNLOCK();
      if (iVar8 + -1 == 0) {
        iVar9 = (**(code **)(*piVar13 + 4))();
      }
    }
  }
  piVar13 = (int *)uStack_100;
  if ((int *)uStack_100 != (int *)0x0) {
    LOCK();
    piVar11 = (int *)uStack_100 + 1;
    iVar8 = *piVar11;
    iVar9 = *piVar11;
    *piVar11 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      (**(code **)*(int *)uStack_100)();
      LOCK();
      piVar11 = piVar13 + 2;
      iVar8 = *piVar11;
      iVar9 = *piVar11;
      *piVar11 = iVar8 + -1;
      UNLOCK();
      if (iVar8 + -1 == 0) {
        iVar9 = (**(code **)(*piVar13 + 4))();
      }
    }
  }
  piVar13 = piStack_40;
  if (piStack_40 != (int *)0x0) {
    LOCK();
    piVar11 = piStack_40 + 1;
    iVar8 = *piVar11;
    iVar9 = *piVar11;
    *piVar11 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      (**(code **)*piStack_40)();
      LOCK();
      piVar11 = piVar13 + 2;
      iVar8 = *piVar11;
      iVar9 = *piVar11;
      *piVar11 = iVar8 + -1;
      UNLOCK();
      if (iVar8 + -1 == 0) {
        iVar9 = (**(code **)(*piVar13 + 4))();
      }
    }
  }
  piVar13 = uStack_1c;
  if (uStack_1c != (int *)0x0) {
    LOCK();
    piVar11 = uStack_1c + 1;
    iVar8 = *piVar11;
    iVar9 = *piVar11;
    *piVar11 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      (**(code **)*uStack_1c)();
      LOCK();
      piVar11 = piVar13 + 2;
      iVar8 = *piVar11;
      iVar9 = *piVar11;
      *piVar11 = iVar8 + -1;
      UNLOCK();
      if (iVar8 + -1 == 0) {
        iVar9 = (**(code **)(*piVar13 + 4))();
      }
    }
  }
  piVar13 = piStack_48;
  if (piStack_48 != (int *)0x0) {
    LOCK();
    piVar11 = piStack_48 + 1;
    iVar8 = *piVar11;
    iVar9 = *piVar11;
    *piVar11 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      iVar9 = (**(code **)*piStack_48)();
      LOCK();
      piVar11 = piVar13 + 2;
      iVar8 = *piVar11;
      *piVar11 = *piVar11 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        iVar9 = (**(code **)(*piVar13 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar9;
}



/* FUNCTION 11454 ; VA 0x007a0010 ; FUN_007a0010 */

void __fastcall FUN_007a0010(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  param_1[7] = 0;
  piVar2 = (int *)param_1[8];
  param_1[8] = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar3 = *param_1;
  *param_1 = 0;
  if (iVar3 != 0) {
    FUN_00795850(iVar3);
  }
  FUN_007a0070();
  return;
}



/* FUNCTION 11455 ; VA 0x007a0070 ; FUN_007a0070 */

void __fastcall FUN_007a0070(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  iVar2 = *(int *)(param_1 + 0x14);
  *(undefined4 *)(param_1 + 0x14) = 0;
  if (iVar2 != 0) {
    FUN_007957e0(iVar2);
  }
  iVar2 = *(int *)(param_1 + 0x18);
  *(undefined4 *)(param_1 + 0x18) = 0;
  if (iVar2 != 0) {
    FUN_007957e0(iVar2);
  }
  *(undefined4 *)(param_1 + 4) = 0;
  piVar3 = *(int **)(param_1 + 8);
  *(undefined4 *)(param_1 + 8) = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  iVar2 = *(int *)(*(int *)(param_1 + 0x3c) + 0x4ec);
  FUN_00773ad0(iVar2 + 0x34);
  FUN_00773ad0(iVar2 + 0x24);
  return;
}



/* FUNCTION 11456 ; VA 0x007a0100 ; FUN_007a0100 */

void __thiscall FUN_007a0100(undefined4 *param_1,int *param_2,undefined4 param_3,char param_4)

{
  char *pcVar1;
  undefined8 uVar2;
  undefined2 uStack0000000d;
  undefined uStack0000000f;
  undefined auStack_b4 [128];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  ushort uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b22f4;
  pvStack_10 = ExceptionList;
  if (1 < *(uint *)(param_1[0x10d] + 0x44)) {
    ExceptionList = &pvStack_10;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb2548)
       && (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb2548), DAT_01eb2548 == -1)) {
      uStack_8 = 0;
      uVar2 = FUN_0152dab0(&DAT_018fb928,"Software Depth Resolve",0xffffffff);
      DAT_01eb2544 = (undefined4)((ulonglong)uVar2 >> 0x20);
      DAT_01eb2540 = (undefined4)uVar2;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb2548);
    }
    uStack_24 = DAT_01eb2540;
    uStack_34 = DAT_01eb2540;
    uStack_20 = DAT_01eb2544;
    uStack_30 = DAT_01eb2544;
    uStack_2c = FUN_0152d930(DAT_01eb2540,DAT_01eb2544);
    uStack_8 = 1;
    (**(code **)(*param_2 + 0x14))(param_3,0,0x10,0,0);
    FUN_00829d10(*(undefined4 *)(*(int *)(param_1[0x10d] + 0x18) + 8));
    uStack_1c = CONCAT22(uStack_1c._2_2_,0x100);
    uStack_18 = 0;
    uStack_14 = 0;
    (**(code **)(*param_2 + 0x34))(4,*(undefined4 *)(param_1[0x10d] + 4),&uStack_1c);
    uStack0000000d = 0x100;
    uStack0000000f = 0;
    uStack_18 = 0x1000100;
    uStack_1c = 0xf;
    uStack_14 = uStack_14 & 0xff00;
    if (param_4 == '\0') {
      pcVar1 = "DepthResolveMax4FS";
      if (*(int *)(param_1[0x10d] + 0x44) != 4) {
        pcVar1 = "DepthResolveMax2FS";
      }
    }
    else {
      pcVar1 = "DepthResolveMin4FS";
      if (*(int *)(param_1[0x10d] + 0x44) != 4) {
        pcVar1 = "DepthResolveMin2FS";
      }
    }
    FUN_0082a430(param_2,*param_1,"PassThroughVS",pcVar1,auStack_b4,&uStack_1c,&stack0x0000000d);
    (**(code **)(*param_2 + 0x18))();
    uStack_8 = 2;
    FUN_0152dda0(uStack_24,uStack_20,uStack_2c);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11457 ; VA 0x007a02f0 ; FUN_007a02f0 */

undefined4 FUN_007a02f0(undefined4 param_1,undefined4 *param_2)

{
  FUN_01165a00(*param_2,0,0,0,0,param_2[1],0,0,0,0,param_2[2],0,0,0,0,0x3f800000);
  return param_1;
}



/* FUNCTION 11458 ; VA 0x007a0390 ; FUN_007a0390 */

undefined4 FUN_007a0390(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_10 = param_2;
  uStack_c = param_3;
  uStack_8 = param_4;
  FUN_007a02f0(param_1,&uStack_10);
  return param_1;
}



/* FUNCTION 11459 ; VA 0x007a03d0 ; FUN_007a03d0 */

void __thiscall
FUN_007a03d0(int param_1,undefined param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x43c);
  *(undefined4 *)(iVar1 + 0x10) = param_3;
  *(undefined4 *)(iVar1 + 0x18) = param_4;
  *(undefined *)(iVar1 + 0xc) = param_2;
  *(undefined4 *)(iVar1 + 0x14) = param_5;
  return;
}



/* FUNCTION 11460 ; VA 0x007a0410 ; FUN_007a0410 */

void __thiscall FUN_007a0410(int param_1,undefined param_2,undefined4 param_3)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x440);
  *(undefined *)(iVar1 + 4) = param_2;
  *(undefined4 *)(iVar1 + 8) = param_3;
  return;
}



/* FUNCTION 11461 ; VA 0x007a0430 ; FUN_007a0430 */

void __thiscall FUN_007a0430(int param_1,undefined4 *param_2)

{
  *(undefined4 *)(param_1 + 0x44) = *param_2;
  *(undefined4 *)(param_1 + 0x48) = param_2[1];
  *(undefined4 *)(param_1 + 0x4c) = param_2[2];
  *(undefined4 *)(param_1 + 0x50) = param_2[3];
  return;
}



/* FUNCTION 11462 ; VA 0x007a0460 ; FUN_007a0460 */

void __thiscall FUN_007a0460(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0x3d) = param_2;
  return;
}



/* FUNCTION 11463 ; VA 0x007a0470 ; FUN_007a0470 */

void __thiscall
FUN_007a0470(int param_1,undefined param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 *param_6)

{
  undefined *puVar1;
  
  puVar1 = *(undefined **)(param_1 + 0x450);
  *(undefined4 *)(puVar1 + 0x10) = param_3;
  *(undefined4 *)(puVar1 + 0x14) = param_4;
  *puVar1 = param_2;
  *(undefined4 *)(puVar1 + 0x18) = param_5;
  *(undefined4 *)(puVar1 + 4) = *param_6;
  *(undefined4 *)(puVar1 + 8) = param_6[1];
  *(undefined4 *)(puVar1 + 0xc) = param_6[2];
  return;
}



/* FUNCTION 11464 ; VA 0x007a04c0 ; FUN_007a04c0 */

void __thiscall FUN_007a04c0(int param_1,char param_2,int param_3)

{
  int iVar1;
  char cVar2;
  float10 fVar3;
  float fVar4;
  
  cVar2 = FUN_0078b680();
  if ((cVar2 != '\0') && (param_2 != '\0')) {
    iVar1 = *(int *)(param_1 + 0x444);
    if ((*(char *)(iVar1 + 0x58) != '\0') &&
       ((NAN(*(float *)(iVar1 + 0x54)) == (*(float *)(iVar1 + 0x54) == 0.0) ||
        ((*(char *)(iVar1 + 0x58) != '\0' &&
         (NAN(*(float *)(iVar1 + 0x50)) == (*(float *)(iVar1 + 0x50) == 0.0))))))) {
      fVar3 = (float10)FUN_008152d0();
      fVar4 = DAT_018f784c;
      if (DAT_018f784c <= (float)fVar3) {
        fVar4 = (float)fVar3;
      }
      if (param_3 == 0) {
        fVar4 = (float)((uint)fVar4 ^ DAT_018c4ea0);
      }
      else if (param_3 == 2) {
        fVar3 = (float10)FUN_00815310();
        *(float *)(param_1 + 0x150) = (float)fVar3;
        return;
      }
      *(float *)(param_1 + 0x150) = fVar4;
      return;
    }
  }
  *(undefined4 *)(param_1 + 0x150) = 0;
  return;
}



/* FUNCTION 11465 ; VA 0x007a0580 ; FUN_007a0580 */

void FUN_007a0580(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  char cVar1;
  
  cVar1 = FUN_0078b680();
  if (cVar1 != '\0') {
    FUN_00816b90(param_1,param_2,param_3,param_4,param_5);
  }
  return;
}



/* FUNCTION 11466 ; VA 0x007a05e0 ; FUN_007a05e0 */

void __thiscall FUN_007a05e0(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x3ac) = param_2;
  return;
}



/* FUNCTION 11467 ; VA 0x007a0600 ; FUN_007a0600 */

void __thiscall FUN_007a0600(int param_1,undefined4 param_2,float param_3,float param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  float fVar5;
  
  uVar1 = *(undefined4 *)(param_1 + 0x140);
  puVar4 = (undefined4 *)FUN_0115e8f0(param_2);
  fVar5 = DAT_018ce2f8;
  uVar2 = puVar4[1];
  uVar3 = puVar4[2];
  *(undefined4 *)(param_1 + 0x134) = *puVar4;
  *(undefined4 *)(param_1 + 0x138) = uVar2;
  *(undefined4 *)(param_1 + 0x13c) = uVar3;
  *(undefined4 *)(param_1 + 0x140) = uVar1;
  *(undefined4 *)(param_1 + 0x128) = 0;
  *(undefined4 *)(param_1 + 0x130) = 0x3f800000;
  fVar5 = fVar5 / (param_4 - param_3);
  *(float *)(param_1 + 0x124) = fVar5 * param_4;
  *(uint *)(param_1 + 300) = (uint)fVar5 ^ DAT_018c4ea0;
  *(float *)(param_1 + 0x3a4) = param_4;
  if ((NAN(param_4) || NAN(param_3)) != (param_4 == param_3)) {
    *(undefined4 *)(param_1 + 0x3a8) = 0;
    return;
  }
  *(float *)(param_1 + 0x3a8) = fVar5;
  return;
}



/* FUNCTION 11468 ; VA 0x007a06e0 ; FUN_007a06e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_007a06e0(int param_1,float *param_2,float param_3,undefined4 param_4)

{
  undefined8 uVar1;
  int iVar2;
  undefined8 *puVar3;
  float *pfVar4;
  float *pfVar5;
  float fVar6;
  float fVar7;
  double dVar8;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  undefined8 uStack_10;
  float fStack_8;
  
  iVar2 = *(int *)(*(int *)(param_1 + 0x44c) + 0x84);
  if (((iVar2 == 0) || (iVar2 = *(int *)(iVar2 + 8), iVar2 == 1)) || (iVar2 == 0)) {
    if (*(int *)(param_1 + 0x40) == 0) {
      iVar2 = *(int *)(param_1 + 0x424);
      fStack_1c = *(float *)(iVar2 + 0xd4);
      fStack_18 = *(float *)(iVar2 + 0xd8);
      fStack_14 = *(float *)(iVar2 + 0xdc);
    }
    else if (*(int *)(param_1 + 0x40) == 1) {
      iVar2 = *(int *)(param_1 + 0x428);
      fStack_1c = *(float *)(iVar2 + 0x418);
      fStack_18 = *(float *)(iVar2 + 0x41c);
      fStack_14 = *(float *)(iVar2 + 0x420);
    }
    else {
      puVar3 = (undefined8 *)FUN_0115ee90();
      uVar1 = *puVar3;
      fStack_14 = *(float *)(puVar3 + 1);
      uStack_10._4_4_ = (float)((ulonglong)uVar1 >> 0x20);
      uStack_10._0_4_ = (float)uVar1;
      fStack_18 = uStack_10._4_4_;
      fStack_1c = (float)uStack_10;
      uStack_10 = uVar1;
      fStack_8 = fStack_14;
    }
    fStack_1c = *param_2 * fStack_1c;
    fStack_18 = param_2[1] * fStack_18;
    fStack_14 = param_2[2] * fStack_14;
    FUN_0115e8f0(&fStack_1c);
    pfVar4 = (float *)FUN_011658d0(&fStack_1c);
    pfVar5 = (float *)FUN_011658d0(&uStack_10);
    fStack_2c = (*pfVar4 + *pfVar5) * DAT_018ce2f4 * fStack_28;
    fStack_28 = fStack_24 * (pfVar4[1] + pfVar5[1]) * DAT_018ce2f4;
    fVar6 = fStack_20 * (pfVar4[2] + pfVar5[2]) * DAT_018ce2f4;
  }
  else {
    fStack_2c = *param_2;
    fStack_28 = param_2[1];
    fVar6 = param_2[2];
  }
  fVar7 = DAT_018ce2f8;
  *(float *)(param_1 + 0x134) = fStack_2c;
  *(float *)(param_1 + 0x138) = fStack_28;
  *(float *)(param_1 + 0x13c) = fVar6;
  *(undefined4 *)(param_1 + 0x140) = *(undefined4 *)(param_1 + 0x140);
  *(undefined4 *)(param_1 + 0x124) = 0;
  fVar6 = 0.0;
  if (0.0 <= param_3) {
    fVar6 = param_3;
  }
  if (fVar6 <= fVar7) {
    fVar7 = fVar6;
  }
  *(undefined4 *)(param_1 + 0x128) = param_4;
  dVar8 = (double)fVar7;
  FUN_01726ab0();
  fVar6 = DAT_018ce2f8;
  *(undefined4 *)(param_1 + 0x130) = 0;
  *(float *)(param_1 + 300) = (float)dVar8 * _DAT_018fde98;
  fVar7 = (fVar6 - fVar7) * DAT_018ce320;
  *(float *)(param_1 + 0x3a4) = fVar7;
  if (NAN(fVar7) == (fVar7 == 0.0)) {
    *(float *)(param_1 + 0x3a8) = fVar6 / fVar7;
    return;
  }
  *(undefined4 *)(param_1 + 0x3a8) = 0;
  return;
}



/* FUNCTION 11469 ; VA 0x007a0910 ; FUN_007a0910 */

void __thiscall FUN_007a0910(int param_1,undefined param_2,undefined4 param_3,undefined4 param_4)

{
  undefined *puVar1;
  
  puVar1 = *(undefined **)(param_1 + 0x43c);
  *(undefined4 *)(puVar1 + 4) = param_3;
  *puVar1 = param_2;
  *(undefined4 *)(puVar1 + 8) = param_4;
  return;
}



/* FUNCTION 11470 ; VA 0x007a0940 ; FUN_007a0940 */

void __thiscall
FUN_007a0940(int param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  *(undefined4 *)(param_1 + 0x1e4) = *param_2;
  *(undefined4 *)(param_1 + 0x1e8) = uVar1;
  *(undefined4 *)(param_1 + 0x1ec) = uVar2;
  *(undefined4 *)(param_1 + 0x1f0) = param_4;
  uVar1 = param_3[1];
  uVar2 = param_3[2];
  *(undefined4 *)(param_1 + 500) = *param_3;
  *(undefined4 *)(param_1 + 0x1f8) = uVar1;
  *(undefined4 *)(param_1 + 0x1fc) = uVar2;
  *(undefined4 *)(param_1 + 0x200) = param_5;
  FUN_00829500(param_1 + 0x54);
  return;
}



/* FUNCTION 11471 ; VA 0x007a09d0 ; FUN_007a09d0 */

void __thiscall
FUN_007a09d0(int param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4,
            undefined4 *param_5,undefined4 *param_6)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  *(undefined4 *)(param_1 + 0xd4) = *param_2;
  *(undefined4 *)(param_1 + 0xd8) = uVar1;
  *(undefined4 *)(param_1 + 0xdc) = uVar2;
  *(undefined4 *)(param_1 + 0xe0) = 0x3f800000;
  uVar1 = param_6[1];
  uVar2 = param_6[2];
  *(undefined4 *)(param_1 + 0xe4) = *param_6;
  *(undefined4 *)(param_1 + 0xe8) = uVar1;
  *(undefined4 *)(param_1 + 0xec) = uVar2;
  *(undefined4 *)(param_1 + 0xf0) = 0x3f800000;
  uVar1 = param_4[1];
  uVar2 = param_4[2];
  *(undefined4 *)(param_1 + 0xf4) = *param_4;
  *(undefined4 *)(param_1 + 0xf8) = uVar1;
  *(undefined4 *)(param_1 + 0xfc) = uVar2;
  *(undefined4 *)(param_1 + 0x100) = 0x3f800000;
  uVar1 = param_3[1];
  uVar2 = param_3[2];
  *(undefined4 *)(param_1 + 0x104) = *param_3;
  *(undefined4 *)(param_1 + 0x108) = uVar1;
  *(undefined4 *)(param_1 + 0x10c) = uVar2;
  *(undefined4 *)(param_1 + 0x110) = 0;
  uVar1 = param_5[1];
  uVar2 = param_5[2];
  *(undefined4 *)(param_1 + 0x114) = *param_5;
  *(undefined4 *)(param_1 + 0x118) = uVar1;
  *(undefined4 *)(param_1 + 0x11c) = uVar2;
  *(undefined4 *)(param_1 + 0x120) = 0x3f800000;
  return;
}



/* FUNCTION 11472 ; VA 0x007a0ae0 ; FUN_007a0ae0 */

void __thiscall FUN_007a0ae0(int *param_1,char param_2)

{
  float fVar1;
  int iVar2;
  float fVar3;
  
  if (((DAT_01d79a48 == '\0') ||
      (iVar2 = (**(code **)(**(int **)(*param_1 + 0x3c) + 0x40))(), *(char *)(iVar2 + 0x1b) == '\0')
      ) || (fVar3 = DAT_018d0938, param_2 == '\0')) {
    fVar3 = 0.0;
    if (0.0 <= (float)DAT_01d60f0c * DAT_018f784c) {
      fVar3 = (float)DAT_01d60f0c * DAT_018f784c;
    }
    fVar1 = DAT_018fde78;
    if (fVar3 <= DAT_018fde78) {
      fVar1 = fVar3;
    }
    fVar3 = DAT_018fd178;
    if (DAT_018fd178 <= (float)DAT_01d60f14 * DAT_018f784c) {
      fVar3 = (float)DAT_01d60f14 * DAT_018f784c;
    }
    if (DAT_01eb1ce4 == 1) {
      param_1[0xd3] = 0;
      return;
    }
    fVar3 = (DAT_018ce2f8 / fVar3) / DAT_018f784c + fVar1;
    if (DAT_01eb1ce4 == 2) {
      param_1[0xd3] = (int)(fVar1 + DAT_018d0938);
      return;
    }
  }
  param_1[0xd3] = (int)fVar3;
  return;
}



/* FUNCTION 11473 ; VA 0x007a0bb0 ; FUN_007a0bb0 */

void __thiscall FUN_007a0bb0(int param_1,undefined8 *param_2)

{
  *(undefined8 *)(param_1 + 4) = *param_2;
  *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)(param_2 + 1);
  return;
}



/* FUNCTION 11474 ; VA 0x007a0bd0 ; FUN_007a0bd0 */

void __thiscall FUN_007a0bd0(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0x3e) = param_2;
  return;
}



/* FUNCTION 11475 ; VA 0x007a0be0 ; FUN_007a0be0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall
FUN_007a0be0(int *param_1,undefined param_2,undefined8 *param_3,float param_4,float param_5)

{
  int iVar1;
  undefined4 uVar2;
  char cVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  
  fVar6 = DAT_018ce2f8;
  param_5 = param_5 * _DAT_018fde68;
  iVar1 = param_1[0x112];
  uVar2 = *(undefined4 *)(*param_1 + 0x5c4);
  *(undefined *)(iVar1 + 0x10) = param_2;
  *(undefined8 *)(iVar1 + 4) = *param_3;
  param_4 = param_4 * DAT_018fde58;
  *(undefined4 *)(iVar1 + 0xc) = *(undefined4 *)(param_3 + 1);
  *(float *)(iVar1 + 0x14) = param_4;
  fVar5 = *(float *)(iVar1 + 8) - DAT_018e1340;
  *(float *)(iVar1 + 0x18) = DAT_018fde78 - param_5;
  fVar5 = fVar5 * _DAT_018fde8c;
  fVar4 = 0.0;
  if (0.0 <= fVar5) {
    fVar4 = fVar5;
  }
  fVar5 = fVar6;
  if (fVar4 <= fVar6) {
    fVar5 = fVar4;
  }
  fVar6 = fVar6 - fVar5 * DAT_018e1340;
  fVar4 = fVar5 * _DAT_018fde5c + _DAT_018fde6c;
  fVar5 = fVar5 * _DAT_018fde7c + _DAT_018fde54;
  cVar3 = FUN_009d7ef0(uVar2);
  if (cVar3 != '\0') {
    fVar6 = fVar6 * fVar6;
    fVar4 = fVar4 * fVar4;
    fVar5 = fVar5 * fVar5;
  }
  *(float *)(iVar1 + 0x1c) = fVar6;
  *(float *)(iVar1 + 0x20) = fVar4;
  *(float *)(iVar1 + 0x24) = fVar5;
  return;
}



/* FUNCTION 11476 ; VA 0x007a0cf0 ; FUN_007a0cf0 */

void __thiscall FUN_007a0cf0(int param_1,char param_2)

{
  if ((DAT_01d79a58 != '\0') && (param_2 != '\0')) {
    *(undefined *)(param_1 + 0x3c) = 1;
    return;
  }
  *(undefined *)(param_1 + 0x3c) = 0;
  return;
}



/* FUNCTION 11477 ; VA 0x007a0d20 ; FUN_007a0d20 */

void FUN_007a0d20(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  undefined8 uVar6;
  undefined4 uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b2314;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1ed0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb1ed0);
    if (DAT_01eb1ed0 == -1) {
      uStack_8 = 0;
      uVar6 = FUN_0152dab0("Render","sortObjects",0xffffffff);
      DAT_01eb1ecc = (undefined4)((ulonglong)uVar6 >> 0x20);
      DAT_01eb1ec8 = (undefined4)uVar6;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb1ed0);
    }
  }
  uVar3 = DAT_01eb1ecc;
  uVar2 = DAT_01eb1ec8;
  uVar6 = FUN_0152d930(DAT_01eb1ec8,DAT_01eb1ecc);
  iVar5 = 0;
  uStack_8 = 1;
  do {
    iVar4 = *(int *)(param_1 + 4 + iVar5 * 0xc) - *(int *)(param_1 + iVar5 * 0xc);
    iVar1 = iVar4 >> 0x1f;
    if (iVar4 / 0x18 + iVar1 != iVar1) {
      if ((DAT_01d60f60 == '\0') || (iVar5 != 0)) {
        if ((DAT_01d60fb0 == '\0') || (iVar5 != 1)) {
          if (iVar5 == 5) {
            if ((DAT_01d60f80 == '\0') && (DAT_01d60f88 == '\0')) {
              uVar7 = 6;
            }
            else {
LAB_007a0e10:
              uVar7 = 1;
            }
          }
          else if ((iVar5 == 9) || (iVar5 == 10)) {
            uVar7 = 2;
          }
          else if (iVar5 == 0xc) {
            uVar7 = 3;
          }
          else {
            if ((iVar5 != 8) && (iVar5 != 7)) {
              if (iVar5 == 0xd) goto LAB_007a0e21;
              goto LAB_007a0e10;
            }
            uVar7 = 4;
          }
        }
        else {
          uVar7 = 6;
        }
      }
      else {
        uVar7 = 5;
      }
      FUN_007f6480(uVar7);
    }
LAB_007a0e21:
    iVar5 = iVar5 + 1;
    if (0xe < iVar5) {
      uStack_8 = 2;
      FUN_0152dda0(uVar2,uVar3,uVar6);
      ExceptionList = pvStack_10;
      return;
    }
  } while( true );
}



/* FUNCTION 11478 ; VA 0x007a0eb0 ; FUN_007a0eb0 */

void __thiscall FUN_007a0eb0(int *param_1,int param_2,int param_3,int param_4,uint param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  char cVar4;
  int iVar5;
  undefined4 *puVar6;
  int *piVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  undefined *puVar10;
  undefined auStack_84 [4];
  int *piStack_80;
  undefined auStack_74 [4];
  int *piStack_70;
  undefined auStack_64 [4];
  int *piStack_60;
  undefined auStack_5c [4];
  int *piStack_58;
  undefined auStack_44 [4];
  int *piStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  int iStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  int iStack_24;
  int iStack_20;
  int *piStack_1c;
  char cStack_15;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b23b0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff70;
  piStack_28 = param_1;
  if ((*param_1 != 0) && (param_4 == 2)) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffff70;
    FUN_007a0010();
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uStack_3c = FUN_01675290(DAT_01eb1cfc);
  uStack_8 = 0;
  piStack_1c = *(int **)(param_1[0xf] + 0x3c);
  iVar5 = (**(code **)(*piStack_1c + 0x40))();
  if (*(char *)(param_1 + 0x12) != '\0') {
    param_4 = 0;
  }
  if (*(char *)((int)param_1 + 0x49) != '\0') {
    param_5 = 1;
  }
  if (*(uint *)(iVar5 + 0x24) <= param_5) {
    param_5 = *(uint *)(iVar5 + 0x24);
  }
  uStack_30 = param_5;
  cVar4 = FUN_0078b680();
  if ((cVar4 == '\0') || (param_4 != 1)) {
    cStack_15 = '\0';
    if (param_4 != 1) goto LAB_007a0f90;
  }
  else {
    cStack_15 = '\x01';
  }
  if (*(char *)(iVar5 + 0x1a) == '\0') {
    param_4 = 0;
  }
  else if ((1 < param_5) && (uStack_30 = param_5, *(char *)(iVar5 + 0x1b) == '\0')) {
    param_5 = 1;
    uStack_30 = param_5;
  }
LAB_007a0f90:
  if (*(char *)(iVar5 + 9) == '\0') {
    iStack_34 = (*(char *)(iVar5 + 8) != '\0') + 0x16;
  }
  else {
    iStack_34 = 0x19;
  }
  uStack_2c = 0x42;
  if (param_4 == 1) {
    uStack_2c = 0x13;
  }
  iStack_20 = iStack_34;
  iVar5 = (**(code **)(*piStack_1c + 0x40))();
  iStack_38 = 0x1b;
  if (*(char *)(iVar5 + 0x13) == '\0') {
    iStack_38 = 3;
  }
  iStack_24 = iStack_38;
  if ((((((int *)*param_1 == (int *)0x0) ||
        (iVar5 = *(int *)*param_1, *(int *)(iVar5 + 0x30) != param_2)) ||
       (*(int *)(iVar5 + 0x34) != param_3)) ||
      ((param_4 != param_1[0x10] || (param_5 != param_1[0x11])))) ||
     (*(int *)(iVar5 + 0x2c) != iStack_38)) {
    FUN_007a0010();
    if (1 < param_5) {
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      puVar6 = (undefined4 *)FUN_01674e20(0x20);
      if (puVar6 == (undefined4 *)0x0) {
        puVar6 = (undefined4 *)0x0;
      }
      else {
        puVar6[3] = 0;
        puVar6[5] = 0;
        puVar6[7] = 0;
        *puVar6 = 0;
        puVar6[1] = 0;
        puVar6[2] = 0;
        puVar6[3] = 0;
        puVar6[4] = 0;
        puVar6[5] = 0;
        puVar6[6] = 0;
        puVar6[7] = 0;
      }
      iVar5 = *param_1;
      *param_1 = (int)puVar6;
      if (iVar5 != 0) {
        FUN_00795850(iVar5);
      }
      piVar7 = (int *)FUN_0147c120(auStack_44,0,iStack_20,param_2,param_3,1,1,1,param_5,uStack_2c);
      iVar5 = *piVar7;
      iVar2 = piVar7[1];
      *piVar7 = 0;
      piVar7[1] = 0;
      param_1[1] = iVar5;
      piVar7 = (int *)param_1[2];
      param_1[2] = iVar2;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar5 = piVar7[1] + -1;
        piVar7[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar5 = piVar7[2] + -1;
          piVar7[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      piVar7 = piStack_40;
      if (piStack_40 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_40[1] + -1;
        piStack_40[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_40)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar5 = *piVar1 + -1;
          *piVar1 = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      if (cStack_15 != '\0') {
        uVar8 = FUN_0147c180(auStack_44,0,iStack_20,param_2,param_3,3);
        FUN_005587e0(uVar8);
        piVar7 = piStack_40;
        if (piStack_40 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_40[1] + -1;
          piStack_40[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piStack_40)();
            LOCK();
            piVar1 = piVar7 + 2;
            iVar5 = *piVar1 + -1;
            *piVar1 = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
        FUN_0147d420(param_1 + 3);
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        uVar8 = FUN_0147bff0(auStack_44,0,0,auStack_64);
        FUN_005587e0(uVar8);
        if (piStack_40 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_40[1] + -1;
          piStack_40[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piStack_40)();
            LOCK();
            iVar5 = piStack_40[2] + -1;
            piStack_40[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piStack_40 + 4))();
            }
          }
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        if (piStack_60 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_60[1] + -1;
          piStack_60[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piStack_60)();
            LOCK();
            iVar5 = piStack_60[2] + -1;
            piStack_60[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piStack_60 + 4))();
            }
          }
        }
      }
      uVar8 = 2;
      if (param_4 == 0) {
        uVar8 = 0x42;
      }
      puVar6 = (undefined4 *)
               FUN_0147c120(auStack_5c,0,iStack_24,param_2,param_3,1,1,1,uStack_30,uVar8);
      iVar5 = *param_1;
      uVar8 = *puVar6;
      uVar3 = puVar6[1];
      *puVar6 = 0;
      puVar6[1] = 0;
      *(undefined4 *)(iVar5 + 8) = uVar8;
      piVar7 = *(int **)(iVar5 + 0xc);
      *(undefined4 *)(iVar5 + 0xc) = uVar3;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar5 = piVar7[1] + -1;
        piVar7[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar5 = piVar7[2] + -1;
          piVar7[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      piVar7 = piStack_58;
      if (piStack_58 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_58[1] + -1;
        piStack_58[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_58)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar5 = *piVar1 + -1;
          *piVar1 = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      FUN_0147d420(param_1 + 1);
      uStack_8._0_1_ = 3;
      FUN_0147d420(*param_1 + 8);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      puVar6 = (undefined4 *)FUN_0147bf30(auStack_5c,auStack_74,auStack_84);
      iVar5 = *param_1;
      uVar8 = *puVar6;
      uVar3 = puVar6[1];
      *puVar6 = 0;
      puVar6[1] = 0;
      *(undefined4 *)(iVar5 + 0x18) = uVar8;
      piVar7 = *(int **)(iVar5 + 0x1c);
      *(undefined4 *)(iVar5 + 0x1c) = uVar3;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar5 = piVar7[1] + -1;
        piVar7[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar5 = piVar7[2] + -1;
          piVar7[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      piVar7 = piStack_58;
      if (piStack_58 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_58[1] + -1;
        piStack_58[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_58)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar5 = *piVar1 + -1;
          *piVar1 = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      piVar7 = piStack_70;
      if (piStack_70 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_70[1] + -1;
        piStack_70[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_70)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar5 = *piVar1 + -1;
          *piVar1 = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      piVar7 = piStack_80;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (piStack_80 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_80[1] + -1;
        piStack_80[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_80)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar5 = *piVar1 + -1;
          *piVar1 = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      puVar9 = (undefined4 *)FUN_0147c180(auStack_5c,0,iStack_24,param_2,param_3,3);
      puVar6 = (undefined4 *)*param_1;
      uVar8 = *puVar9;
      uVar3 = puVar9[1];
      *puVar9 = 0;
      puVar9[1] = 0;
      *puVar6 = uVar8;
      piVar7 = (int *)puVar6[1];
      puVar6[1] = uVar3;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar5 = piVar7[1] + -1;
        piVar7[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar5 = piVar7[2] + -1;
          piVar7[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      piVar7 = piStack_58;
      if (piStack_58 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_58[1] + -1;
        piStack_58[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_58)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar5 = *piVar1 + -1;
          *piVar1 = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      if (cStack_15 == '\0') {
        puVar10 = (undefined *)FUN_0147d4b0();
        uStack_8._0_1_ = 7;
        FUN_0147d420(*param_1);
        uStack_8 = CONCAT31(uStack_8._1_3_,8);
      }
      else {
        FUN_0147d420(param_1 + 3);
        uStack_8._0_1_ = 5;
        FUN_0147d420(*param_1);
        puVar10 = auStack_74;
        uStack_8 = CONCAT31(uStack_8._1_3_,6);
      }
      uVar8 = FUN_0147bf30(auStack_5c,auStack_84,puVar10);
      FUN_005587e0(uVar8);
      if (piStack_58 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_58[1] + -1;
        piStack_58[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_58)();
          LOCK();
          iVar5 = piStack_58[2] + -1;
          piStack_58[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piStack_58 + 4))();
          }
        }
      }
      if (piStack_80 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_80[1] + -1;
        piStack_80[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_80)();
          LOCK();
          iVar5 = piStack_80[2] + -1;
          piStack_80[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piStack_80 + 4))();
          }
        }
      }
      if (piStack_70 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_70[1] + -1;
        piStack_70[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_70)();
          LOCK();
          iVar5 = piStack_70[2] + -1;
          piStack_70[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piStack_70 + 4))();
          }
        }
      }
      param_1[0x11] = uStack_30;
      param_1[0x10] = 0;
      FUN_007a1520();
      return;
    }
    if ((param_5 == 1) || ((*(char *)((int)param_1 + 0x49) != '\0' && (1 < param_5)))) {
      uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
      piVar7 = (int *)FUN_0147c180(auStack_5c,0,iStack_20,param_2,param_3,uStack_2c);
      iVar5 = *piVar7;
      iVar2 = piVar7[1];
      *piVar7 = 0;
      piVar7[1] = 0;
      param_1[1] = iVar5;
      piVar7 = (int *)param_1[2];
      param_1[2] = iVar2;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar5 = piVar7[1] + -1;
        piVar7[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar5 = piVar7[2] + -1;
          piVar7[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      piVar7 = piStack_58;
      if (piStack_58 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_58[1] + -1;
        piStack_58[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_58)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar5 = *piVar1 + -1;
          *piVar1 = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      FUN_0056ecd0(param_1 + 1);
      puVar6 = (undefined4 *)FUN_01674e20(0x20);
      if (puVar6 == (undefined4 *)0x0) {
        puVar6 = (undefined4 *)0x0;
      }
      else {
        puVar6[3] = 0;
        puVar6[5] = 0;
        puVar6[7] = 0;
        *puVar6 = 0;
        puVar6[1] = 0;
        puVar6[2] = 0;
        puVar6[3] = 0;
        puVar6[4] = 0;
        puVar6[5] = 0;
        puVar6[6] = 0;
        puVar6[7] = 0;
      }
      iVar5 = *param_1;
      *param_1 = (int)puVar6;
      if (iVar5 != 0) {
        FUN_00795850(iVar5);
      }
      puVar9 = (undefined4 *)FUN_0147c180(auStack_5c,0,iStack_24,param_2,param_3,3);
      puVar6 = (undefined4 *)*param_1;
      uVar8 = *puVar9;
      uVar3 = puVar9[1];
      *puVar9 = 0;
      puVar9[1] = 0;
      *puVar6 = uVar8;
      piVar7 = (int *)puVar6[1];
      puVar6[1] = uVar3;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar5 = piVar7[1] + -1;
        piVar7[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar5 = piVar7[2] + -1;
          piVar7[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      piVar7 = piStack_58;
      if (piStack_58 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_58[1] + -1;
        piStack_58[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_58)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar5 = *piVar1 + -1;
          *piVar1 = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      FUN_0147d420(param_1 + 1);
      uStack_8._0_1_ = 0x11;
      FUN_0147d420(*param_1);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
      puVar6 = (undefined4 *)FUN_0147bf30(auStack_5c,auStack_84,auStack_74);
      iVar5 = *param_1;
      uVar8 = *puVar6;
      uVar3 = puVar6[1];
      *puVar6 = 0;
      puVar6[1] = 0;
      *(undefined4 *)(iVar5 + 0x10) = uVar8;
      piVar7 = *(int **)(iVar5 + 0x14);
      *(undefined4 *)(iVar5 + 0x14) = uVar3;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar5 = piVar7[1] + -1;
        piVar7[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar5 = piVar7[2] + -1;
          piVar7[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      piVar7 = piStack_58;
      if (piStack_58 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_58[1] + -1;
        piStack_58[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_58)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar5 = *piVar1 + -1;
          *piVar1 = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      piVar7 = piStack_80;
      if (piStack_80 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_80[1] + -1;
        piStack_80[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_80)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar5 = *piVar1 + -1;
          *piVar1 = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      piVar7 = piStack_70;
      if (piStack_70 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_70[1] + -1;
        piStack_70[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_70)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar5 = *piVar1 + -1;
          *piVar1 = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      param_1[0x11] = 1;
      param_1[0x10] = 0;
      uStack_8 = 0;
      if (param_4 == 1) {
        uStack_8 = 0x15;
        puVar6 = (undefined4 *)FUN_01674e20(0x10);
        if (puVar6 == (undefined4 *)0x0) {
          puVar6 = (undefined4 *)0x0;
        }
        else {
          *puVar6 = 0;
          puVar6[1] = 0;
          puVar6[2] = 0;
          puVar6[3] = 0;
        }
        iVar5 = param_1[5];
        param_1[5] = (int)puVar6;
        if (iVar5 != 0) {
          FUN_007957e0(iVar5);
        }
        uVar8 = FUN_0147c180(auStack_5c,0,iStack_24,param_2,param_3,3);
        FUN_005587e0(uVar8);
        piVar7 = piStack_58;
        if (piStack_58 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_58[1] + -1;
          piStack_58[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piStack_58)();
            LOCK();
            piVar1 = piVar7 + 2;
            iVar5 = *piVar1 + -1;
            *piVar1 = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
        uVar8 = FUN_0147d4b0();
        uStack_8._0_1_ = 0x16;
        FUN_0147d420(param_1[5]);
        uStack_8 = CONCAT31(uStack_8._1_3_,0x17);
        uVar8 = FUN_0147bf30(auStack_5c,auStack_84,uVar8);
        FUN_005587e0(uVar8);
        piVar7 = piStack_58;
        if (piStack_58 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_58[1] + -1;
          piStack_58[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piStack_58)();
            LOCK();
            piVar1 = piVar7 + 2;
            iVar5 = *piVar1 + -1;
            *piVar1 = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
        piVar7 = piStack_80;
        if (piStack_80 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_80[1] + -1;
          piStack_80[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piStack_80)();
            LOCK();
            piVar1 = piVar7 + 2;
            iVar5 = *piVar1 + -1;
            *piVar1 = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
        piVar7 = piStack_70;
        uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
        if (piStack_70 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_70[1] + -1;
          piStack_70[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piStack_70)();
            LOCK();
            piVar1 = piVar7 + 2;
            iVar5 = *piVar1 + -1;
            *piVar1 = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
        puVar6 = (undefined4 *)FUN_01674e20(0x10);
        if (puVar6 == (undefined4 *)0x0) {
          puVar6 = (undefined4 *)0x0;
        }
        else {
          *puVar6 = 0;
          puVar6[1] = 0;
          puVar6[2] = 0;
          puVar6[3] = 0;
        }
        iVar5 = param_1[6];
        param_1[6] = (int)puVar6;
        if (iVar5 != 0) {
          FUN_007957e0(iVar5);
        }
        uVar8 = FUN_0147c180(auStack_5c,0,5,param_2,param_3,3);
        FUN_005587e0(uVar8);
        piVar7 = piStack_58;
        if (piStack_58 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_58[1] + -1;
          piStack_58[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piStack_58)();
            LOCK();
            piVar1 = piVar7 + 2;
            iVar5 = *piVar1 + -1;
            *piVar1 = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
        uVar8 = FUN_0147d4b0();
        uStack_8._0_1_ = 0x18;
        FUN_0147d420(param_1[6]);
        uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
        uVar8 = FUN_0147bf30(auStack_5c,auStack_84,uVar8);
        FUN_005587e0(uVar8);
        if (piStack_58 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_58[1] + -1;
          piStack_58[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piStack_58)();
            LOCK();
            iVar5 = piStack_58[2] + -1;
            piStack_58[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piStack_58 + 4))();
            }
          }
        }
        if (piStack_80 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_80[1] + -1;
          piStack_80[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piStack_80)();
            LOCK();
            iVar5 = piStack_80[2] + -1;
            piStack_80[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piStack_80 + 4))();
            }
          }
        }
        if (piStack_70 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_70[1] + -1;
          piStack_70[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piStack_70)();
            LOCK();
            piVar7 = piStack_70 + 2;
            iVar5 = *piVar7;
            *piVar7 = *piVar7 + -1;
            UNLOCK();
            if (iVar5 == 1) {
              (**(code **)(*piStack_70 + 4))();
            }
          }
        }
        param_1[0x10] = 1;
        param_1[0x11] = 1;
        FUN_007a1c93();
        return;
      }
    }
    if ((uint)param_1[0x11] < 2) {
      iVar5 = *param_1 + 0x10;
    }
    else {
      iVar5 = *param_1 + 0x18;
    }
    FUN_0056ecd0(iVar5);
  }
  if (param_1[0x10] == 1) {
    FUN_00773ad0(param_1[5]);
    iVar5 = param_1[6];
  }
  else {
    iVar5 = *(int *)(param_1[0xf] + 0x4ec);
    FUN_00773ad0(iVar5 + 0x34);
    iVar5 = iVar5 + 0x24;
  }
  FUN_00773ad0(iVar5);
  uStack_8 = 0x1b;
  FUN_007a1d55();
  return;
}



/* FUNCTION 11479 ; VA 0x007a14d2 ; Catch@007a14d2 */

undefined * Catch_007a14d2(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  if (DAT_01f6dcc0 != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x44) + 4))();
    FUN_01677650(DAT_01f6dcc0,"Error initializing Main Color Buffer MSAA: %s",uVar1);
  }
  *(undefined *)(*(int *)(unaff_EBP + -0x24) + 0x49) = 1;
  FUN_007a0010();
  return &DAT_007a150b;
}



/* FUNCTION 11480 ; VA 0x007a1520 ; FUN_007a1520 */

void FUN_007a1520(void)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int *piVar7;
  undefined4 *puVar8;
  int iVar9;
  int *unaff_EBX;
  int unaff_EBP;
  uint unaff_ESI;
  int unaff_EDI;
  
  cVar2 = *(char *)((int)unaff_EBX + 0x49);
  *(undefined4 *)(unaff_EBP + -4) = 0;
  if ((cVar2 == '\0') && (*(int *)(unaff_EBP + 0x10) == 1)) {
    *(undefined *)(unaff_EBP + -4) = 10;
    puVar5 = (undefined4 *)FUN_01674e20(0x10);
    *(undefined4 **)(unaff_EBP + -0x3c) = puVar5;
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      *puVar5 = 0;
      puVar5[1] = 0;
      puVar5[2] = 0;
      puVar5[3] = 0;
    }
    iVar9 = unaff_EBX[5];
    unaff_EBX[5] = (int)puVar5;
    if (iVar9 != 0) {
      FUN_007957e0(iVar9);
    }
    uVar6 = FUN_0147c180(unaff_EBP + -0x58,0,*(undefined4 *)(unaff_EBP + -0x20),
                         *(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + 0xc),3);
    FUN_005587e0(uVar6);
    FUN_00550b30();
    uVar6 = FUN_0147d4b0();
    *(undefined4 *)(unaff_EBP + -0x3c) = uVar6;
    iVar9 = unaff_EBX[5];
    *(undefined *)(unaff_EBP + -4) = 0xb;
    FUN_0147d420(iVar9);
    *(undefined *)(unaff_EBP + -4) = 0xc;
    uVar6 = FUN_0147bf30(unaff_EBP + -0x58,unaff_EBP + -0x80,*(undefined4 *)(unaff_EBP + -0x3c));
    FUN_005587e0(uVar6);
    FUN_00550b30();
    FUN_00550b30();
    *(undefined *)(unaff_EBP + -4) = 10;
    FUN_00550b30();
    puVar5 = (undefined4 *)FUN_01674e20(0x10);
    *(undefined4 **)(unaff_EBP + -0x3c) = puVar5;
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      *puVar5 = 0;
      puVar5[1] = 0;
      puVar5[2] = 0;
      puVar5[3] = 0;
    }
    iVar9 = unaff_EBX[6];
    unaff_EBX[6] = (int)puVar5;
    if (iVar9 != 0) {
      FUN_007957e0(iVar9);
    }
    uVar6 = FUN_0147c180(unaff_EBP + -0x58,0,5,*(undefined4 *)(unaff_EBP + 8),
                         *(undefined4 *)(unaff_EBP + 0xc),3);
    FUN_005587e0(uVar6);
    FUN_00550b30();
    uVar6 = FUN_0147d4b0();
    *(undefined4 *)(unaff_EBP + -0x3c) = uVar6;
    iVar9 = unaff_EBX[6];
    *(undefined *)(unaff_EBP + -4) = 0xd;
    FUN_0147d420(iVar9);
    *(undefined *)(unaff_EBP + -4) = 0xe;
    uVar6 = FUN_0147bf30(unaff_EBP + -0x58,unaff_EBP + -0x80,*(undefined4 *)(unaff_EBP + -0x3c));
    FUN_005587e0(uVar6);
    FUN_00550b30();
    FUN_00550b30();
    FUN_00550b30();
    unaff_EBX[0x10] = 1;
    unaff_EBX[0x11] = unaff_ESI;
    *(undefined4 *)(unaff_EBP + -4) = 0;
  }
  if ((unaff_ESI == 1) || ((*(char *)((int)unaff_EBX + 0x49) != '\0' && (1 < unaff_ESI)))) {
    *(undefined *)(unaff_EBP + -4) = 0x10;
    piVar7 = (int *)FUN_0147c180(unaff_EBP + -0x58,0,*(undefined4 *)(unaff_EBP + -0x1c),
                                 *(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + 0xc),
                                 *(undefined4 *)(unaff_EBP + -0x28));
    iVar9 = *piVar7;
    iVar3 = piVar7[1];
    *piVar7 = 0;
    piVar7[1] = 0;
    unaff_EBX[1] = iVar9;
    piVar7 = (int *)unaff_EBX[2];
    unaff_EBX[2] = iVar3;
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar9 = piVar7[1] + unaff_EDI;
      piVar7[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piVar7)();
        LOCK();
        iVar9 = piVar7[2] + unaff_EDI;
        piVar7[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    piVar7 = *(int **)(unaff_EBP + -0x54);
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar9 = piVar7[1] + unaff_EDI;
      piVar7[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piVar7)();
        LOCK();
        iVar9 = piVar7[2] + unaff_EDI;
        piVar7[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    FUN_0056ecd0(unaff_EBX + 1);
    puVar5 = (undefined4 *)FUN_01674e20(0x20);
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      puVar5[3] = 0;
      puVar5[5] = 0;
      puVar5[7] = 0;
      *puVar5 = 0;
      puVar5[1] = 0;
      puVar5[2] = 0;
      puVar5[3] = 0;
      puVar5[4] = 0;
      puVar5[5] = 0;
      puVar5[6] = 0;
      puVar5[7] = 0;
    }
    iVar9 = *unaff_EBX;
    *unaff_EBX = (int)puVar5;
    if (iVar9 != 0) {
      FUN_00795850(iVar9);
    }
    puVar8 = (undefined4 *)
             FUN_0147c180(unaff_EBP + -0x58,0,*(undefined4 *)(unaff_EBP + -0x20),
                          *(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + 0xc),3);
    puVar5 = (undefined4 *)*unaff_EBX;
    uVar6 = *puVar8;
    uVar4 = puVar8[1];
    *puVar8 = 0;
    puVar8[1] = 0;
    *puVar5 = uVar6;
    piVar7 = (int *)puVar5[1];
    puVar5[1] = uVar4;
    *(int **)(unaff_EBP + 0x14) = piVar7;
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar9 = piVar7[1] + unaff_EDI;
      piVar7[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piVar7)();
        LOCK();
        iVar9 = piVar7[2] + unaff_EDI;
        piVar7[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    piVar7 = *(int **)(unaff_EBP + -0x54);
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar9 = piVar7[1] + unaff_EDI;
      piVar7[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piVar7)();
        LOCK();
        iVar9 = piVar7[2] + unaff_EDI;
        piVar7[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    FUN_0147d420(unaff_EBX + 1);
    iVar9 = *unaff_EBX;
    *(undefined *)(unaff_EBP + -4) = 0x11;
    FUN_0147d420(iVar9);
    *(undefined *)(unaff_EBP + -4) = 0x12;
    puVar5 = (undefined4 *)FUN_0147bf30(unaff_EBP + -0x58,unaff_EBP + -0x80,unaff_EBP + -0x70);
    iVar9 = *unaff_EBX;
    uVar6 = *puVar5;
    uVar4 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    *(undefined4 *)(iVar9 + 0x10) = uVar6;
    piVar7 = *(int **)(iVar9 + 0x14);
    *(undefined4 *)(iVar9 + 0x14) = uVar4;
    *(int **)(unaff_EBP + 0x14) = piVar7;
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar9 = piVar7[1] + unaff_EDI;
      piVar7[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piVar7)();
        LOCK();
        iVar9 = piVar7[2] + unaff_EDI;
        piVar7[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    piVar7 = *(int **)(unaff_EBP + -0x54);
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar9 = piVar7[1] + unaff_EDI;
      piVar7[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piVar7)();
        LOCK();
        iVar9 = piVar7[2] + unaff_EDI;
        piVar7[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    piVar7 = *(int **)(unaff_EBP + -0x7c);
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar9 = piVar7[1] + unaff_EDI;
      piVar7[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piVar7)();
        LOCK();
        iVar9 = piVar7[2] + unaff_EDI;
        piVar7[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    piVar7 = *(int **)(unaff_EBP + -0x6c);
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar9 = piVar7[1] + unaff_EDI;
      piVar7[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piVar7)();
        LOCK();
        iVar9 = piVar7[2] + unaff_EDI;
        piVar7[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    iVar9 = *(int *)(unaff_EBP + 0x10);
    unaff_EBX[0x11] = 1;
    unaff_EBX[0x10] = 0;
    *(undefined4 *)(unaff_EBP + -4) = 0;
    if (iVar9 == 1) {
      *(undefined *)(unaff_EBP + -4) = 0x15;
      puVar5 = (undefined4 *)FUN_01674e20(0x10);
      *(undefined4 **)(unaff_EBP + 0x10) = puVar5;
      if (puVar5 == (undefined4 *)0x0) {
        puVar5 = (undefined4 *)0x0;
      }
      else {
        *puVar5 = 0;
        puVar5[1] = 0;
        puVar5[2] = 0;
        puVar5[3] = 0;
      }
      iVar9 = unaff_EBX[5];
      unaff_EBX[5] = (int)puVar5;
      if (iVar9 != 0) {
        FUN_007957e0(iVar9);
      }
      uVar6 = FUN_0147c180(unaff_EBP + -0x58,0,*(undefined4 *)(unaff_EBP + -0x20),
                           *(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + 0xc),3);
      FUN_005587e0(uVar6);
      piVar7 = *(int **)(unaff_EBP + -0x54);
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar9 = piVar7[1] + unaff_EDI;
        piVar7[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar9 = piVar7[2] + unaff_EDI;
          piVar7[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      uVar6 = FUN_0147d4b0();
      iVar9 = unaff_EBX[5];
      *(undefined *)(unaff_EBP + -4) = 0x16;
      FUN_0147d420(iVar9);
      *(undefined *)(unaff_EBP + -4) = 0x17;
      uVar6 = FUN_0147bf30(unaff_EBP + -0x58,unaff_EBP + -0x80,uVar6);
      FUN_005587e0(uVar6);
      piVar7 = *(int **)(unaff_EBP + -0x54);
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar9 = piVar7[1] + unaff_EDI;
        piVar7[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar9 = piVar7[2] + unaff_EDI;
          piVar7[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      piVar7 = *(int **)(unaff_EBP + -0x7c);
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar9 = piVar7[1] + unaff_EDI;
        piVar7[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar9 = piVar7[2] + unaff_EDI;
          piVar7[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      piVar7 = *(int **)(unaff_EBP + -0x6c);
      *(undefined *)(unaff_EBP + -4) = 0x15;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar9 = piVar7[1] + unaff_EDI;
        piVar7[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar9 = piVar7[2] + unaff_EDI;
          piVar7[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      puVar5 = (undefined4 *)FUN_01674e20(0x10);
      *(undefined4 **)(unaff_EBP + 0x10) = puVar5;
      if (puVar5 == (undefined4 *)0x0) {
        puVar5 = (undefined4 *)0x0;
      }
      else {
        *puVar5 = 0;
        puVar5[1] = 0;
        puVar5[2] = 0;
        puVar5[3] = 0;
      }
      iVar9 = unaff_EBX[6];
      unaff_EBX[6] = (int)puVar5;
      if (iVar9 != 0) {
        FUN_007957e0(iVar9);
      }
      uVar6 = FUN_0147c180(unaff_EBP + -0x58,0,5,*(undefined4 *)(unaff_EBP + 8),
                           *(undefined4 *)(unaff_EBP + 0xc),3);
      FUN_005587e0(uVar6);
      piVar7 = *(int **)(unaff_EBP + -0x54);
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar9 = piVar7[1] + unaff_EDI;
        piVar7[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar9 = piVar7[2] + unaff_EDI;
          piVar7[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      uVar6 = FUN_0147d4b0();
      iVar9 = unaff_EBX[6];
      *(undefined *)(unaff_EBP + -4) = 0x18;
      FUN_0147d420(iVar9);
      *(undefined *)(unaff_EBP + -4) = 0x19;
      uVar6 = FUN_0147bf30(unaff_EBP + -0x58,unaff_EBP + -0x80,uVar6);
      FUN_005587e0(uVar6);
      piVar7 = *(int **)(unaff_EBP + -0x54);
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar9 = piVar7[1] + unaff_EDI;
        piVar7[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar9 = piVar7[2] + unaff_EDI;
          piVar7[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      piVar7 = *(int **)(unaff_EBP + -0x7c);
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar9 = piVar7[1] + unaff_EDI;
        piVar7[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar9 = piVar7[2] + unaff_EDI;
          piVar7[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      piVar7 = *(int **)(unaff_EBP + -0x6c);
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar9 = piVar7[1] + unaff_EDI;
        piVar7[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar9 = *piVar1;
          *piVar1 = *piVar1 + unaff_EDI;
          UNLOCK();
          if (iVar9 == 1) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      unaff_EBX[0x10] = 1;
      unaff_EBX[0x11] = 1;
      FUN_007a1c93();
      return;
    }
  }
  if ((uint)unaff_EBX[0x11] < 2) {
    iVar9 = *unaff_EBX + 0x10;
  }
  else {
    iVar9 = *unaff_EBX + 0x18;
  }
  FUN_0056ecd0(iVar9);
  if (unaff_EBX[0x10] == 1) {
    FUN_00773ad0(unaff_EBX[5]);
    iVar9 = unaff_EBX[6];
  }
  else {
    iVar9 = *(int *)(unaff_EBX[0xf] + 0x4ec);
    FUN_00773ad0(iVar9 + 0x34);
    iVar9 = iVar9 + 0x24;
  }
  FUN_00773ad0(iVar9);
  *(undefined4 *)(unaff_EBP + -4) = 0x1b;
  FUN_007a1d55();
  return;
}



/* FUNCTION 11481 ; VA 0x007a16d9 ; Catch@007a16d9 */

undefined * Catch_007a16d9(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  if (DAT_01f6dcc0 != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x48) + 4))();
    FUN_01677650(DAT_01f6dcc0,"Error initializing GBuffer MSAA: %s",uVar1);
  }
  *(undefined *)(*(int *)(unaff_EBP + -0x24) + 0x49) = 1;
  FUN_007a0010();
  return &DAT_007a1712;
}



/* FUNCTION 11482 ; VA 0x007a1c57 ; Catch@007a1c57 */

undefined * Catch_007a1c57(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  if (DAT_01f6dcc0 != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x4c) + 4))();
    FUN_01677650(DAT_01f6dcc0,"Error initializing GBuffer: %s",uVar1);
  }
  *(undefined *)(*(int *)(unaff_EBP + -0x24) + 0x48) = 1;
  FUN_007a0070();
  return &DAT_007a1c90;
}



/* FUNCTION 11483 ; VA 0x007a1c93 ; FUN_007a1c93 */

void FUN_007a1c93(void)

{
  int iVar1;
  int *unaff_EBX;
  int unaff_EBP;
  
  *(undefined4 *)(unaff_EBP + -4) = 0;
  if ((uint)unaff_EBX[0x11] < 2) {
    iVar1 = *unaff_EBX + 0x10;
  }
  else {
    iVar1 = *unaff_EBX + 0x18;
  }
  FUN_0056ecd0(iVar1);
  if (unaff_EBX[0x10] == 1) {
    FUN_00773ad0(unaff_EBX[5]);
    iVar1 = unaff_EBX[6];
  }
  else {
    iVar1 = *(int *)(unaff_EBX[0xf] + 0x4ec);
    FUN_00773ad0(iVar1 + 0x34);
    iVar1 = iVar1 + 0x24;
  }
  FUN_00773ad0(iVar1);
  *(undefined4 *)(unaff_EBP + -4) = 0x1b;
  FUN_007a1d55();
  return;
}



/* FUNCTION 11484 ; VA 0x007a1cf0 ; Catch@007a1cf0 */

undefined * Catch_007a1cf0(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  if (DAT_01f6dcc0 != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x50) + 4))();
    FUN_01677650(DAT_01f6dcc0,"Error initializing Main Color Buffer: %s",uVar1);
    if (DAT_01f6dcc0 != '\0') {
      FUN_01677490(DAT_01f6dcc0,"Resolution: %dx%d",*(undefined4 *)(unaff_EBP + 8),
                   *(undefined4 *)(unaff_EBP + 0xc),0);
    }
  }
  *(undefined4 *)(*(int *)(unaff_EBP + -0x24) + 0x40) = 2;
  FUN_007a0010();
  return &DAT_007a1d4e;
}



/* FUNCTION 11485 ; VA 0x007a1d55 ; FUN_007a1d55 */

void FUN_007a1d55(void)

{
  int unaff_EBP;
  
  FUN_01675290(*(undefined4 *)(unaff_EBP + -0x38));
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 11486 ; VA 0x007a1d80 ; FUN_007a1d80 */

void __thiscall FUN_007a1d80(int param_1,int *param_2,int param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  int *piVar8;
  undefined4 auStack_98 [20];
  int *piStack_48;
  undefined auStack_3c [4];
  int *piStack_38;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b23d0;
  pvStack_10 = ExceptionList;
  iStack_18 = 2;
  piVar8 = (int *)(param_1 + 0x20);
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  do {
    piVar4 = (int *)*piVar8;
    if (piVar4 == (int *)0x0) {
      piStack_1c = (int *)FUN_01674e20(0x10);
      if (piStack_1c == (int *)0x0) {
        piVar4 = (int *)0x0;
      }
      else {
        *piStack_1c = 0;
        piStack_1c[1] = 0;
        piStack_1c[2] = 0;
        piStack_1c[3] = 0;
        piVar4 = piStack_1c;
      }
      iVar2 = *piVar8;
      *piVar8 = (int)piVar4;
      if (iVar2 != 0) {
        FUN_007957e0(iVar2);
        piVar4 = (int *)*piVar8;
      }
    }
    iVar2 = *piVar4;
    if ((((iVar2 == 0) || (piVar4[2] == 0)) || (*(int *)(iVar2 + 0x30) != param_3)) ||
       (*(int *)(iVar2 + 0x34) != param_4)) {
      piStack_1c = *(int **)(*(int *)(iStack_14 + 0x1c) + 0x3c);
      puVar5 = (undefined4 *)FUN_0147c150(auStack_24,0,3,param_3,param_4,1,1,1,3);
      puVar7 = (undefined4 *)*piVar8;
      uVar6 = *puVar5;
      uVar3 = puVar5[1];
      *puVar5 = 0;
      puVar5[1] = 0;
      *puVar7 = uVar6;
      piVar4 = (int *)puVar7[1];
      puVar7[1] = uVar3;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar2 = piVar4[1] + -1;
        piVar4[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar2 = piVar4[2] + -1;
          piVar4[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      piVar4 = piStack_20;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_20[1] + -1;
        piStack_20[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar1 = piVar4 + 2;
          iVar2 = *piVar1 + -1;
          *piVar1 = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      uVar6 = FUN_0147d4b0();
      uStack_8 = 0;
      FUN_0147d420(*piVar8);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      puVar7 = (undefined4 *)FUN_0147bf30(auStack_2c,auStack_3c,uVar6);
      iVar2 = *piVar8;
      uVar6 = *puVar7;
      uVar3 = puVar7[1];
      *puVar7 = 0;
      puVar7[1] = 0;
      *(undefined4 *)(iVar2 + 8) = uVar6;
      piVar4 = *(int **)(iVar2 + 0xc);
      *(undefined4 *)(iVar2 + 0xc) = uVar3;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar2 = piVar4[1] + -1;
        piVar4[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar2 = piVar4[2] + -1;
          piVar4[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      piVar4 = piStack_28;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_28[1] + -1;
        piStack_28[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_28)();
          LOCK();
          piVar1 = piVar4 + 2;
          iVar2 = *piVar1 + -1;
          *piVar1 = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      piVar4 = piStack_38;
      if (piStack_38 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_38[1] + -1;
        piStack_38[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_38)();
          LOCK();
          piVar1 = piVar4 + 2;
          iVar2 = *piVar1 + -1;
          *piVar1 = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      piVar4 = piStack_48;
      uStack_8 = 0xffffffff;
      if (piStack_48 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_48[1] + -1;
        piStack_48[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_48)();
          LOCK();
          piVar1 = piVar4 + 2;
          iVar2 = *piVar1 + -1;
          *piVar1 = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      FUN_0147bca0();
      auStack_98[0] = 1;
      (**(code **)(*param_2 + 0x14))(*(undefined4 *)(*piVar8 + 8),0,1,auStack_98,0);
      (**(code **)(*param_2 + 0x18))();
    }
    piVar8 = piVar8 + 1;
    iStack_18 = iStack_18 + -1;
  } while (iStack_18 != 0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 11487 ; VA 0x007a2000 ; FUN_007a2000 */

int __thiscall
FUN_007a2000(int *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  undefined4 *puVar11;
  uint uVar12;
  undefined4 *puVar13;
  undefined4 *puVar14;
  undefined4 *puVar15;
  
  iVar10 = *param_1;
  iVar6 = (int)param_2 - iVar10 >> 5;
  iVar7 = param_1[1] - iVar10 >> 5;
  if (iVar7 == 0x7ffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar7 + 1;
  uVar12 = param_1[2] - iVar10 >> 5;
  uVar8 = uVar1;
  if ((uVar12 <= 0x7ffffff - (uVar12 >> 1)) && (uVar8 = (uVar12 >> 1) + uVar12, uVar8 < uVar1)) {
    uVar8 = uVar1;
  }
  uVar12 = uVar8 * 0x20;
  if (uVar8 < 0x8000000) {
    if (0xfff < uVar12) goto LAB_007a2072;
    if (uVar12 == 0) {
      puVar15 = (undefined4 *)0x0;
    }
    else {
      puVar15 = (undefined4 *)FUN_01674e20(uVar12);
    }
  }
  else {
    uVar12 = 0xffffffff;
LAB_007a2072:
    uVar9 = uVar12 + 0x23;
    if (uVar9 <= uVar12) {
      uVar9 = 0xffffffff;
    }
    iVar10 = FUN_01674e20(uVar9);
    if (iVar10 == 0) goto LAB_007a21be;
    puVar15 = (undefined4 *)(iVar10 + 0x23U & 0xffffffe0);
    puVar15[-1] = iVar10;
  }
  puVar3 = puVar15 + iVar6 * 8;
  uVar2 = *param_4;
  *puVar3 = *param_3;
  puVar3[1] = uVar2;
  *(undefined *)(puVar3 + 2) = 0;
  puVar3[3] = 0xffffffff;
  puVar3[4] = 1;
  puVar3[6] = 0;
  puVar3[7] = 0;
  puVar14 = (undefined4 *)param_1[1];
  puVar11 = (undefined4 *)*param_1;
  puVar13 = puVar15;
  if (param_2 == puVar14) {
    for (; puVar11 != puVar14; puVar11 = puVar11 + 8) {
      uVar2 = puVar11[1];
      uVar4 = puVar11[2];
      uVar5 = puVar11[3];
      *puVar13 = *puVar11;
      puVar13[1] = uVar2;
      puVar13[2] = uVar4;
      puVar13[3] = uVar5;
      uVar2 = puVar11[5];
      uVar4 = puVar11[6];
      uVar5 = puVar11[7];
      puVar13[4] = puVar11[4];
      puVar13[5] = uVar2;
      puVar13[6] = uVar4;
      puVar13[7] = uVar5;
      puVar13 = puVar13 + 8;
    }
  }
  else {
    if (puVar11 != param_2) {
      do {
        uVar2 = puVar11[1];
        uVar4 = puVar11[2];
        uVar5 = puVar11[3];
        *puVar13 = *puVar11;
        puVar13[1] = uVar2;
        puVar13[2] = uVar4;
        puVar13[3] = uVar5;
        puVar14 = puVar11 + 4;
        uVar2 = puVar11[5];
        uVar4 = puVar11[6];
        uVar5 = puVar11[7];
        puVar11 = puVar11 + 8;
        puVar13[4] = *puVar14;
        puVar13[5] = uVar2;
        puVar13[6] = uVar4;
        puVar13[7] = uVar5;
        puVar13 = puVar13 + 8;
      } while (puVar11 != param_2);
      puVar14 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar14) {
      do {
        uVar2 = param_2[1];
        uVar4 = param_2[2];
        uVar5 = param_2[3];
        puVar3[8] = *param_2;
        puVar3[9] = uVar2;
        puVar3[10] = uVar4;
        puVar3[0xb] = uVar5;
        puVar11 = param_2 + 4;
        uVar2 = param_2[5];
        uVar4 = param_2[6];
        uVar5 = param_2[7];
        param_2 = param_2 + 8;
        puVar3[0xc] = *puVar11;
        puVar3[0xd] = uVar2;
        puVar3[0xe] = uVar4;
        puVar3[0xf] = uVar5;
        puVar3 = puVar3 + 8;
      } while (param_2 != puVar14);
    }
  }
  iVar10 = *param_1;
  if (iVar10 != 0) {
    uVar12 = param_1[2] - iVar10 & 0xffffffe0;
    iVar7 = iVar10;
    if (0xfff < uVar12) {
      iVar7 = *(int *)(iVar10 + -4);
      uVar12 = uVar12 + 0x23;
      if (0x1f < (iVar10 - iVar7) - 4U) {
LAB_007a21be:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar12);
  }
  *param_1 = (int)puVar15;
  param_1[1] = (int)(puVar15 + uVar1 * 8);
  param_1[2] = (int)(puVar15 + uVar8 * 8);
  return *param_1 + iVar6 * 0x20;
}



/* FUNCTION 11488 ; VA 0x007a21d0 ; FUN_007a21d0 */

int __thiscall
FUN_007a21d0(int *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4,
            undefined4 *param_5)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  int iVar12;
  int iVar13;
  uint uVar14;
  undefined4 *puVar15;
  undefined4 *puVar16;
  
  iVar8 = *param_1;
  iVar12 = (int)param_2 - iVar8 >> 4;
  iVar13 = param_1[1] - iVar8 >> 4;
  if (iVar13 == 0xfffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar13 + 1;
  uVar14 = param_1[2] - iVar8 >> 4;
  uVar6 = uVar1;
  if ((uVar14 <= 0xfffffff - (uVar14 >> 1)) && (uVar6 = (uVar14 >> 1) + uVar14, uVar6 < uVar1)) {
    uVar6 = uVar1;
  }
  uVar14 = uVar6 * 0x10;
  if (uVar6 < 0x10000000) {
    if (0xfff < uVar14) goto LAB_007a2243;
    if (uVar14 == 0) {
      puVar9 = (undefined4 *)0x0;
    }
    else {
      puVar9 = (undefined4 *)FUN_01674e20(uVar14);
    }
  }
  else {
    uVar14 = 0xffffffff;
LAB_007a2243:
    uVar7 = uVar14 + 0x23;
    if (uVar7 <= uVar14) {
      uVar7 = 0xffffffff;
    }
    iVar8 = FUN_01674e20(uVar7);
    if (iVar8 == 0) goto LAB_007a2379;
    puVar9 = (undefined4 *)(iVar8 + 0x23U & 0xffffffe0);
    puVar9[-1] = iVar8;
  }
  puVar10 = puVar9 + iVar12 * 4;
  uVar2 = *param_5;
  uVar3 = param_5[1];
  uVar4 = *param_4;
  *puVar10 = *param_3;
  puVar10[3] = uVar3;
  puVar10[1] = uVar4;
  puVar10[2] = uVar2;
  puVar16 = (undefined4 *)param_1[1];
  puVar11 = (undefined4 *)*param_1;
  puVar15 = puVar9;
  if (param_2 == puVar16) {
    for (; puVar11 != puVar16; puVar11 = puVar11 + 4) {
      uVar2 = puVar11[1];
      uVar3 = puVar11[2];
      uVar4 = puVar11[3];
      *puVar15 = *puVar11;
      puVar15[1] = uVar2;
      puVar15[2] = uVar3;
      puVar15[3] = uVar4;
      puVar15 = puVar15 + 4;
    }
  }
  else {
    if (puVar11 != param_2) {
      do {
        uVar2 = *puVar11;
        uVar3 = puVar11[1];
        uVar4 = puVar11[2];
        uVar5 = puVar11[3];
        puVar11 = puVar11 + 4;
        *puVar15 = uVar2;
        puVar15[1] = uVar3;
        puVar15[2] = uVar4;
        puVar15[3] = uVar5;
        puVar15 = puVar15 + 4;
      } while (puVar11 != param_2);
      puVar16 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar16) {
      do {
        uVar2 = *param_2;
        uVar3 = param_2[1];
        uVar4 = param_2[2];
        uVar5 = param_2[3];
        param_2 = param_2 + 4;
        puVar10[4] = uVar2;
        puVar10[5] = uVar3;
        puVar10[6] = uVar4;
        puVar10[7] = uVar5;
        puVar10 = puVar10 + 4;
      } while (param_2 != puVar16);
    }
  }
  iVar8 = *param_1;
  if (iVar8 != 0) {
    uVar14 = param_1[2] - iVar8 & 0xfffffff0;
    iVar13 = iVar8;
    if (0xfff < uVar14) {
      iVar13 = *(int *)(iVar8 + -4);
      uVar14 = uVar14 + 0x23;
      if (0x1f < (iVar8 - iVar13) - 4U) {
LAB_007a2379:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar13,uVar14);
  }
  *param_1 = (int)puVar9;
  param_1[1] = (int)(puVar9 + uVar1 * 4);
  param_1[2] = (int)(puVar9 + uVar6 * 4);
  return *param_1 + iVar12 * 0x10;
}



/* FUNCTION 11489 ; VA 0x007a2390 ; FUN_007a2390 */

int __thiscall FUN_007a2390(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  
  iVar6 = *param_1;
  iVar2 = (int)param_2 - iVar6 >> 3;
  iVar3 = param_1[1] - iVar6 >> 3;
  if (iVar3 == 0x1fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar3 + 1;
  uVar7 = param_1[2] - iVar6 >> 3;
  uVar4 = uVar1;
  if ((uVar7 <= 0x1fffffff - (uVar7 >> 1)) && (uVar4 = (uVar7 >> 1) + uVar7, uVar4 < uVar1)) {
    uVar4 = uVar1;
  }
  uVar7 = uVar4 * 8;
  if (uVar4 < 0x20000000) {
    if (0xfff < uVar7) goto LAB_007a2407;
    if (uVar7 == 0) {
      puVar10 = (undefined4 *)0x0;
    }
    else {
      puVar10 = (undefined4 *)FUN_01674e20(uVar7);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_007a2407:
    uVar5 = uVar7 + 0x23;
    if (uVar5 <= uVar7) {
      uVar5 = 0xffffffff;
    }
    iVar6 = FUN_01674e20(uVar5);
    if (iVar6 == 0) goto LAB_007a2522;
    puVar10 = (undefined4 *)(iVar6 + 0x23U & 0xffffffe0);
    puVar10[-1] = iVar6;
  }
  puVar10[iVar2 * 2] = *param_3;
  puVar10[iVar2 * 2 + 1] = param_3[1];
  puVar11 = (undefined4 *)param_1[1];
  puVar8 = (undefined4 *)*param_1;
  puVar9 = puVar10;
  if (param_2 == puVar11) {
    for (; puVar8 != puVar11; puVar8 = puVar8 + 2) {
      *puVar9 = *puVar8;
      puVar9[1] = puVar8[1];
      puVar9 = puVar9 + 2;
    }
  }
  else {
    if (puVar8 != param_2) {
      do {
        *puVar9 = *puVar8;
        puVar11 = puVar8 + 1;
        puVar8 = puVar8 + 2;
        puVar9[1] = *puVar11;
        puVar9 = puVar9 + 2;
      } while (puVar8 != param_2);
      puVar11 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar11) {
      puVar8 = puVar10 + iVar2 * 2 + 2;
      do {
        *puVar8 = *param_2;
        puVar9 = param_2 + 1;
        param_2 = param_2 + 2;
        puVar8[1] = *puVar9;
        puVar8 = puVar8 + 2;
      } while (param_2 != puVar11);
    }
  }
  iVar6 = *param_1;
  if (iVar6 != 0) {
    uVar7 = param_1[2] - iVar6 & 0xfffffff8;
    iVar3 = iVar6;
    if (0xfff < uVar7) {
      iVar3 = *(int *)(iVar6 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar6 - iVar3) - 4U) {
LAB_007a2522:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar7);
  }
  *param_1 = (int)puVar10;
  param_1[1] = (int)(puVar10 + uVar1 * 2);
  param_1[2] = (int)(puVar10 + uVar4 * 2);
  return *param_1 + iVar2 * 8;
}



/* FUNCTION 11490 ; VA 0x007a2530 ; FUN_007a2530 */

void FUN_007a2530(int *param_1,int *param_2,int *param_3)

{
  float fVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  int iStack_8;
  
  iVar4 = *param_1;
  fVar1 = *(float *)(iVar4 + 0x1cc);
  iVar2 = (int)param_3 - (int)param_1 >> 2;
  if (iVar2 < 0x29) {
    iVar2 = *param_2;
    if (*(float *)(iVar2 + 0x1cc) <= fVar1 && fVar1 != *(float *)(iVar2 + 0x1cc)) {
      *param_2 = iVar4;
      *param_1 = iVar2;
      iVar2 = *param_2;
    }
    iVar4 = *param_3;
    fVar1 = *(float *)(iVar4 + 0x1cc);
    if (fVar1 < *(float *)(iVar2 + 0x1cc)) {
      *param_3 = iVar2;
      *param_2 = iVar4;
      if (fVar1 < *(float *)(*param_1 + 0x1cc)) {
        *param_2 = *param_1;
        *param_1 = iVar4;
        return;
      }
    }
  }
  else {
    iVar3 = iVar2 + 1 >> 3;
    iVar2 = param_1[iVar3];
    if (*(float *)(iVar2 + 0x1cc) <= fVar1 && fVar1 != *(float *)(iVar2 + 0x1cc)) {
      param_1[iVar3] = iVar4;
      *param_1 = iVar2;
      iVar2 = param_1[iVar3];
    }
    iVar4 = param_1[iVar3 * 2];
    fVar1 = *(float *)(iVar4 + 0x1cc);
    if (fVar1 < *(float *)(iVar2 + 0x1cc)) {
      param_1[iVar3 * 2] = iVar2;
      param_1[iVar3] = iVar4;
      if (fVar1 < *(float *)(*param_1 + 0x1cc)) {
        param_1[iVar3] = *param_1;
        *param_1 = iVar4;
      }
    }
    piVar5 = param_2 + -iVar3;
    iVar4 = *param_2;
    fVar1 = *(float *)(*piVar5 + 0x1cc);
    if (*(float *)(iVar4 + 0x1cc) <= fVar1 && fVar1 != *(float *)(iVar4 + 0x1cc)) {
      *param_2 = *piVar5;
      *piVar5 = iVar4;
      iVar4 = *param_2;
    }
    iVar2 = param_2[iVar3];
    fVar1 = *(float *)(iVar2 + 0x1cc);
    if (fVar1 < *(float *)(iVar4 + 0x1cc)) {
      param_2[iVar3] = iVar4;
      *param_2 = iVar2;
      if (fVar1 < *(float *)(*piVar5 + 0x1cc)) {
        *param_2 = *piVar5;
        *piVar5 = iVar2;
      }
    }
    piVar5 = param_3 + iVar3 * -2;
    piVar6 = param_3 + -iVar3;
    iStack_8 = *piVar6;
    if (*(float *)(iStack_8 + 0x1cc) <= *(float *)(*piVar5 + 0x1cc) &&
        *(float *)(*piVar5 + 0x1cc) != *(float *)(iStack_8 + 0x1cc)) {
      *piVar6 = *piVar5;
      *piVar5 = iStack_8;
      iStack_8 = *piVar6;
    }
    iVar4 = *param_3;
    fVar1 = *(float *)(iVar4 + 0x1cc);
    if (fVar1 < *(float *)(iStack_8 + 0x1cc)) {
      *param_3 = iStack_8;
      *piVar6 = iVar4;
      if (fVar1 < *(float *)(*piVar5 + 0x1cc)) {
        *piVar6 = *piVar5;
        *piVar5 = iVar4;
      }
    }
    iVar4 = *param_2;
    fVar1 = *(float *)(param_1[iVar3] + 0x1cc);
    if (*(float *)(iVar4 + 0x1cc) <= fVar1 && fVar1 != *(float *)(iVar4 + 0x1cc)) {
      *param_2 = param_1[iVar3];
      param_1[iVar3] = iVar4;
      iVar4 = *param_2;
    }
    iVar2 = *piVar6;
    fVar1 = *(float *)(iVar2 + 0x1cc);
    if (fVar1 < *(float *)(iVar4 + 0x1cc)) {
      *piVar6 = iVar4;
      *param_2 = iVar2;
      if (fVar1 < *(float *)(param_1[iVar3] + 0x1cc)) {
        *param_2 = param_1[iVar3];
        param_1[iVar3] = iVar2;
      }
    }
  }
  return;
}



/* FUNCTION 11491 ; VA 0x007a2730 ; FUN_007a2730 */

void __thiscall FUN_007a2730(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  undefined auStack_1c [4];
  uint uStack_18;
  uint uStack_14;
  int iStack_10;
  int iStack_c;
  undefined uStack_6;
  char cStack_5;
  
  param_4 = param_4 - param_3;
  uVar3 = param_4 >> 2;
  iStack_10 = param_2 - *param_1 >> 2;
  if ((uVar3 == 1) && (param_2 == param_1[1])) {
    cStack_5 = '\x01';
  }
  else {
    cStack_5 = '\0';
    if (uVar3 == 0) {
      return;
    }
  }
  uStack_18 = param_1[1];
  if (uVar3 <= (uint)((int)(param_1[2] - uStack_18) >> 2)) {
    iStack_10 = uVar3 * 4;
    uStack_14 = uStack_18 - param_2;
    if ((uint)((int)uStack_14 >> 2) <= uVar3) {
      iVar1 = iStack_10 + param_2;
      FUN_0055b6b0(&uStack_6,auStack_1c,auStack_1c);
      FUN_0170cc70(iVar1,param_2,uStack_14);
      param_1[1] = uStack_14 + iVar1;
      FUN_0055b6b0(&uStack_6,auStack_1c,auStack_1c);
      FUN_0170cc70(param_2,param_3,param_4);
      return;
    }
    iVar1 = uStack_18 + uVar3 * -4;
    FUN_0055b6b0(&uStack_6,auStack_1c,auStack_1c);
    uVar2 = uStack_18;
    FUN_0170cc70(uStack_18,iVar1,uVar3 * 4);
    param_1[1] = iStack_10 + uVar2;
    iVar1 = iVar1 - param_2;
    FUN_0170cc70(uVar2 - iVar1,param_2,iVar1);
    FUN_0055b6b0(&uStack_6,auStack_1c,auStack_1c);
    FUN_0170cc70(param_2,param_3,param_4);
    return;
  }
  iVar1 = (int)(uStack_18 - *param_1) >> 2;
  if (0x3fffffffU - iVar1 < uVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uStack_18 = iVar1 + uVar3;
  uVar2 = param_1[2] - *param_1 >> 2;
  uStack_14 = uStack_18;
  if ((uVar2 <= 0x3fffffff - (uVar2 >> 1)) &&
     (uStack_14 = (uVar2 >> 1) + uVar2, uStack_14 < uStack_18)) {
    uStack_14 = uStack_18;
  }
  iStack_c = FUN_00577ed0(uStack_14);
  iVar1 = iStack_c + iStack_10 * 4;
  FUN_0055b6b0(&uStack_6,auStack_1c,auStack_1c);
  FUN_0170cc70(iVar1,param_3,param_4);
  iVar1 = iStack_c;
  if (cStack_5 != '\0') {
    FUN_007a5f20(*param_1,param_1[1],iStack_c);
    FUN_00601e00(iVar1,uStack_18,uStack_14);
    return;
  }
  FUN_007a5ee0(*param_1,param_2,iStack_c);
  FUN_007a5ee0(param_2,param_1[1],iVar1 + (iStack_10 + uVar3) * 4);
  FUN_00601e00(iVar1,uStack_18,uStack_14);
  return;
}



/* FUNCTION 11492 ; VA 0x007a2930 ; FUN_007a2930 */

void FUN_007a2930(int param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  int iVar15;
  uint uVar16;
  int iVar17;
  int iVar18;
  int iVar19;
  int iVar20;
  int *piVar21;
  int iVar22;
  int iVar23;
  int iVar24;
  
  uVar16 = param_2 - param_1 >> 5;
  iVar22 = param_2 - param_1 >> 6;
  if (0 < iVar22) {
    iVar17 = (int)(uVar16 - 1) >> 1;
    iVar18 = iVar22 * 0x20 + param_1;
    do {
      iVar4 = *(int *)(iVar18 + -0x20);
      iVar5 = *(int *)(iVar18 + -0x1c);
      iVar6 = *(int *)(iVar18 + -0x18);
      iVar7 = *(int *)(iVar18 + -0x14);
      iVar22 = iVar22 + -1;
      uVar8 = *(undefined4 *)(iVar18 + -0x10);
      uVar9 = *(undefined4 *)(iVar18 + -0xc);
      uVar10 = *(undefined4 *)(iVar18 + -8);
      uVar11 = *(undefined4 *)(iVar18 + -4);
      iVar23 = iVar22;
      while (iVar23 < iVar17) {
        iVar19 = iVar23 * 0x40 + param_1;
        iVar20 = FUN_008361f0(*(undefined4 *)
                               (*(int *)(iVar19 + 0x44) * 0x278 + 0x260 +
                               *(int *)(*(int *)(iVar19 + 0x40) + 0x14)));
        iVar19 = FUN_008361f0(*(undefined4 *)
                               (*(int *)(iVar19 + 0x24) * 0x278 + 0x260 +
                               *(int *)(*(int *)(iVar19 + 0x20) + 0x14)));
        iVar24 = iVar23 * 0x20;
        iVar23 = (*(int *)(iVar20 + 8) <= *(int *)(iVar19 + 8)) + 1 + iVar23 * 2;
        puVar1 = (undefined4 *)(iVar23 * 0x20 + param_1);
        uVar12 = puVar1[1];
        uVar13 = puVar1[2];
        uVar14 = puVar1[3];
        puVar2 = (undefined4 *)(iVar24 + param_1);
        *puVar2 = *puVar1;
        puVar2[1] = uVar12;
        puVar2[2] = uVar13;
        puVar2[3] = uVar14;
        puVar1 = (undefined4 *)(iVar23 * 0x20 + 0x10 + param_1);
        uVar12 = puVar1[1];
        uVar13 = puVar1[2];
        uVar14 = puVar1[3];
        puVar2 = (undefined4 *)(iVar24 + 0x10 + param_1);
        *puVar2 = *puVar1;
        puVar2[1] = uVar12;
        puVar2[2] = uVar13;
        puVar2[3] = uVar14;
      }
      if ((iVar23 == iVar17) && ((uVar16 & 1) == 0)) {
        puVar2 = (undefined4 *)(uVar16 * 0x20 + -0x20 + param_1);
        uVar12 = puVar2[1];
        uVar13 = puVar2[2];
        uVar14 = puVar2[3];
        puVar1 = (undefined4 *)(iVar23 * 0x20 + param_1);
        *puVar1 = *puVar2;
        puVar1[1] = uVar12;
        puVar1[2] = uVar13;
        puVar1[3] = uVar14;
        puVar1 = (undefined4 *)(uVar16 * 0x20 + -0x10 + param_1);
        uVar12 = puVar1[1];
        uVar13 = puVar1[2];
        uVar14 = puVar1[3];
        puVar2 = (undefined4 *)(iVar23 * 0x20 + 0x10 + param_1);
        *puVar2 = *puVar1;
        puVar2[1] = uVar12;
        puVar2[2] = uVar13;
        puVar2[3] = uVar14;
        iVar23 = uVar16 - 1;
      }
      if (iVar22 < iVar23) {
        do {
          iVar24 = iVar23 + -1 >> 1;
          piVar21 = (int *)(iVar24 * 0x20 + param_1);
          iVar19 = FUN_008361f0(*(undefined4 *)
                                 (piVar21[1] * 0x278 + 0x260 + *(int *)(*piVar21 + 0x14)));
          iVar20 = FUN_008361f0(*(undefined4 *)(iVar5 * 0x278 + 0x260 + *(int *)(iVar4 + 0x14)));
          if (*(int *)(iVar19 + 8) <= *(int *)(iVar20 + 8)) break;
          iVar19 = piVar21[1];
          iVar20 = piVar21[2];
          iVar15 = piVar21[3];
          piVar3 = (int *)(iVar23 * 0x20 + param_1);
          *piVar3 = *piVar21;
          piVar3[1] = iVar19;
          piVar3[2] = iVar20;
          piVar3[3] = iVar15;
          iVar19 = piVar21[5];
          iVar20 = piVar21[6];
          iVar15 = piVar21[7];
          piVar3 = (int *)(iVar23 * 0x20 + 0x10 + param_1);
          *piVar3 = piVar21[4];
          piVar3[1] = iVar19;
          piVar3[2] = iVar20;
          piVar3[3] = iVar15;
          iVar23 = iVar24;
        } while (iVar22 < iVar24);
      }
      piVar21 = (int *)(iVar23 * 0x20 + param_1);
      *piVar21 = iVar4;
      piVar21[1] = iVar5;
      piVar21[2] = iVar6;
      piVar21[3] = iVar7;
      puVar1 = (undefined4 *)(iVar23 * 0x20 + 0x10 + param_1);
      *puVar1 = uVar8;
      puVar1[1] = uVar9;
      puVar1[2] = uVar10;
      puVar1[3] = uVar11;
      iVar18 = iVar18 + -0x20;
    } while (0 < iVar22);
  }
  return;
}



/* FUNCTION 11493 ; VA 0x007a2b20 ; FUN_007a2b20 */

void FUN_007a2b20(int *param_1,int *param_2,int *param_3)

{
  float fVar1;
  float fVar2;
  int iVar3;
  int iVar4;
  bool bVar5;
  bool bVar6;
  
  iVar4 = *param_2;
  iVar3 = *param_1;
  fVar1 = *(float *)(iVar4 + 0x1cc);
  fVar2 = *(float *)(iVar3 + 0x1cc);
  if ((NAN(fVar1) || NAN(fVar2)) == (fVar1 == fVar2)) {
    bVar6 = fVar2 == fVar1;
    bVar5 = fVar2 < fVar1;
  }
  else {
    bVar6 = *(float *)(iVar4 + 0x224) == *(float *)(iVar3 + 0x224);
    bVar5 = *(float *)(iVar4 + 0x224) < *(float *)(iVar3 + 0x224);
  }
  if (!bVar5 && !bVar6) {
    *param_2 = iVar3;
    *param_1 = iVar4;
    iVar4 = *param_2;
  }
  fVar1 = *(float *)(iVar4 + 0x1cc);
  iVar3 = *param_3;
  fVar2 = *(float *)(iVar3 + 0x1cc);
  if ((NAN(fVar2) || NAN(fVar1)) == (fVar2 == fVar1)) {
    bVar6 = fVar1 == fVar2;
    bVar5 = fVar1 < fVar2;
  }
  else {
    bVar6 = *(float *)(iVar3 + 0x224) == *(float *)(iVar4 + 0x224);
    bVar5 = *(float *)(iVar3 + 0x224) < *(float *)(iVar4 + 0x224);
  }
  if (!bVar5 && !bVar6) {
    *param_3 = iVar4;
    *param_2 = iVar3;
    iVar4 = *param_1;
    fVar1 = *(float *)(iVar4 + 0x1cc);
    if ((NAN(fVar2) || NAN(fVar1)) == (fVar2 == fVar1)) {
      bVar6 = fVar1 == fVar2;
      bVar5 = fVar1 < fVar2;
    }
    else {
      bVar6 = *(float *)(iVar3 + 0x224) == *(float *)(iVar4 + 0x224);
      bVar5 = *(float *)(iVar3 + 0x224) < *(float *)(iVar4 + 0x224);
    }
    if (!bVar5 && !bVar6) {
      *param_2 = iVar4;
      *param_1 = iVar3;
    }
  }
  return;
}



/* FUNCTION 11494 ; VA 0x007a2be0 ; FUN_007a2be0 */

void FUN_007a2be0(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  char cVar10;
  int iVar11;
  int iVar12;
  
  iVar11 = FUN_008361f0(*(undefined4 *)(*(int *)(*param_2 + 0x14) + 0x260 + param_2[1] * 0x278));
  iVar12 = FUN_008361f0(*(undefined4 *)(param_1[1] * 0x278 + 0x260 + *(int *)(*param_1 + 0x14)));
  if (*(int *)(iVar12 + 8) < *(int *)(iVar11 + 8)) {
    iVar11 = *param_2;
    iVar12 = param_2[1];
    iVar1 = param_2[2];
    iVar2 = param_2[3];
    iVar3 = param_2[4];
    iVar4 = param_2[5];
    iVar5 = param_2[6];
    iVar6 = param_2[7];
    iVar7 = param_1[1];
    iVar8 = param_1[2];
    iVar9 = param_1[3];
    *param_2 = *param_1;
    param_2[1] = iVar7;
    param_2[2] = iVar8;
    param_2[3] = iVar9;
    iVar7 = param_1[5];
    iVar8 = param_1[6];
    iVar9 = param_1[7];
    param_2[4] = param_1[4];
    param_2[5] = iVar7;
    param_2[6] = iVar8;
    param_2[7] = iVar9;
    *param_1 = iVar11;
    param_1[1] = iVar12;
    param_1[2] = iVar1;
    param_1[3] = iVar2;
    param_1[4] = iVar3;
    param_1[5] = iVar4;
    param_1[6] = iVar5;
    param_1[7] = iVar6;
  }
  iVar11 = FUN_008361f0(*(undefined4 *)(param_3[1] * 0x278 + 0x260 + *(int *)(*param_3 + 0x14)));
  iVar12 = FUN_008361f0(*(undefined4 *)(*(int *)(*param_2 + 0x14) + 0x260 + param_2[1] * 0x278));
  if (*(int *)(iVar12 + 8) < *(int *)(iVar11 + 8)) {
    iVar11 = param_2[1];
    iVar12 = param_2[2];
    iVar1 = param_2[3];
    iVar2 = *param_3;
    iVar3 = param_3[1];
    iVar4 = param_3[2];
    iVar5 = param_3[3];
    iVar6 = param_3[4];
    iVar7 = param_3[5];
    iVar8 = param_3[6];
    iVar9 = param_3[7];
    *param_3 = *param_2;
    param_3[1] = iVar11;
    param_3[2] = iVar12;
    param_3[3] = iVar1;
    iVar11 = param_2[5];
    iVar12 = param_2[6];
    iVar1 = param_2[7];
    param_3[4] = param_2[4];
    param_3[5] = iVar11;
    param_3[6] = iVar12;
    param_3[7] = iVar1;
    *param_2 = iVar2;
    param_2[1] = iVar3;
    param_2[2] = iVar4;
    param_2[3] = iVar5;
    param_2[4] = iVar6;
    param_2[5] = iVar7;
    param_2[6] = iVar8;
    param_2[7] = iVar9;
    cVar10 = FUN_007a5e20(param_2,param_1);
    if (cVar10 != '\0') {
      iVar11 = param_1[1];
      iVar12 = param_1[2];
      iVar1 = param_1[3];
      iVar2 = *param_2;
      iVar3 = param_2[1];
      iVar4 = param_2[2];
      iVar5 = param_2[3];
      iVar6 = param_2[4];
      iVar7 = param_2[5];
      iVar8 = param_2[6];
      iVar9 = param_2[7];
      *param_2 = *param_1;
      param_2[1] = iVar11;
      param_2[2] = iVar12;
      param_2[3] = iVar1;
      iVar11 = param_1[5];
      iVar12 = param_1[6];
      iVar1 = param_1[7];
      param_2[4] = param_1[4];
      param_2[5] = iVar11;
      param_2[6] = iVar12;
      param_2[7] = iVar1;
      *param_1 = iVar2;
      param_1[1] = iVar3;
      param_1[2] = iVar4;
      param_1[3] = iVar5;
      param_1[4] = iVar6;
      param_1[5] = iVar7;
      param_1[6] = iVar8;
      param_1[7] = iVar9;
    }
  }
  return;
}



/* FUNCTION 11495 ; VA 0x007a2d00 ; FUN_007a2d00 */

void FUN_007a2d00(uint *param_1,int *param_2,int *param_3,undefined4 param_4)

{
  float fVar1;
  float fVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  int *piVar9;
  int *piVar10;
  bool bVar11;
  bool bVar12;
  int *piStack_10;
  int *piStack_c;
  int *piStack_8;
  
  piStack_10 = param_2 + ((int)param_3 - (int)param_2 >> 3);
  iVar4 = (int)(param_3 + -1) - (int)param_2 >> 2;
  if (iVar4 < 0x29) {
    FUN_007a2b20(param_2,piStack_10,param_3 + -1,param_4);
  }
  else {
    iVar4 = iVar4 + 1 >> 3;
    FUN_007a2b20(param_2,param_2 + iVar4,param_2 + iVar4 * 2,param_4);
    FUN_007a2b20(piStack_10 + -iVar4,piStack_10,piStack_10 + iVar4,param_4);
    piVar6 = param_3 + -1;
    FUN_007a2b20(piVar6 + iVar4 * -2,piVar6 + -iVar4,piVar6,param_4);
    FUN_007a2b20(param_2 + iVar4,piStack_10,piVar6 + -iVar4,param_4);
  }
  piVar6 = piStack_10 + 1;
  if (param_2 < piStack_10) {
    while( true ) {
      iVar4 = *piStack_10;
      iVar3 = piStack_10[-1];
      fVar1 = *(float *)(iVar4 + 0x1cc);
      fVar2 = *(float *)(iVar3 + 0x1cc);
      if ((NAN(fVar2) || NAN(fVar1)) == (fVar2 == fVar1)) {
        bVar12 = fVar1 == fVar2;
        bVar11 = fVar1 < fVar2;
      }
      else {
        bVar12 = *(float *)(iVar3 + 0x224) == *(float *)(iVar4 + 0x224);
        bVar11 = *(float *)(iVar3 + 0x224) < *(float *)(iVar4 + 0x224);
      }
      if (!bVar11 && !bVar12) break;
      if ((NAN(fVar1) || NAN(fVar2)) == (fVar1 == fVar2)) {
        bVar12 = fVar2 == fVar1;
        bVar11 = fVar2 < fVar1;
      }
      else {
        bVar12 = *(float *)(iVar4 + 0x224) == *(float *)(iVar3 + 0x224);
        bVar11 = *(float *)(iVar4 + 0x224) < *(float *)(iVar3 + 0x224);
      }
      if ((!bVar11 && !bVar12) || (piStack_10 = piStack_10 + -1, piStack_10 <= param_2)) break;
    }
  }
  piVar7 = piStack_10;
  piVar9 = piVar6;
  piVar10 = piVar6;
  piStack_8 = piVar6;
  piStack_c = piStack_10;
  piVar8 = piStack_10;
  if (piVar6 < param_3) {
    iVar4 = *piStack_10;
    fVar1 = *(float *)(iVar4 + 0x1cc);
    while( true ) {
      iVar3 = *piVar6;
      fVar2 = *(float *)(iVar3 + 0x1cc);
      if ((NAN(fVar2) || NAN(fVar1)) == (fVar2 == fVar1)) {
        bVar12 = fVar1 == fVar2;
        bVar11 = fVar1 < fVar2;
      }
      else {
        bVar12 = *(float *)(iVar3 + 0x224) == *(float *)(iVar4 + 0x224);
        bVar11 = *(float *)(iVar3 + 0x224) < *(float *)(iVar4 + 0x224);
      }
      piVar9 = piVar6;
      piVar10 = piVar6;
      piStack_8 = piVar6;
      if (!bVar11 && !bVar12) break;
      if ((NAN(fVar1) || NAN(fVar2)) == (fVar1 == fVar2)) {
        bVar12 = fVar2 == fVar1;
        bVar11 = fVar2 < fVar1;
      }
      else {
        bVar12 = *(float *)(iVar4 + 0x224) == *(float *)(iVar3 + 0x224);
        bVar11 = *(float *)(iVar4 + 0x224) < *(float *)(iVar3 + 0x224);
      }
      if ((!bVar11 && !bVar12) ||
         (piVar6 = piVar6 + 1, piVar9 = piVar6, piVar10 = piVar6, piStack_8 = piVar6,
         param_3 <= piVar6)) break;
    }
  }
joined_r0x007a2ea2:
  do {
    piVar5 = piVar7;
    piStack_10 = piVar10;
    if (param_3 <= piVar9) {
joined_r0x007a2f32:
      while (piVar10 = piVar9, param_2 < piVar7) {
        piVar5 = piVar5 + -1;
        iVar4 = *piVar5;
        iVar3 = *piVar8;
        fVar1 = *(float *)(iVar4 + 0x1cc);
        fVar2 = *(float *)(iVar3 + 0x1cc);
        if ((NAN(fVar1) || NAN(fVar2)) == (fVar1 == fVar2)) {
          bVar12 = fVar2 == fVar1;
          bVar11 = fVar2 < fVar1;
        }
        else {
          bVar12 = *(float *)(iVar4 + 0x224) == *(float *)(iVar3 + 0x224);
          bVar11 = *(float *)(iVar4 + 0x224) < *(float *)(iVar3 + 0x224);
        }
        piVar6 = piStack_8;
        if (bVar11 || bVar12) {
          if ((NAN(fVar2) || NAN(fVar1)) == (fVar2 == fVar1)) {
            bVar12 = fVar1 == fVar2;
            bVar11 = fVar1 < fVar2;
          }
          else {
            bVar12 = *(float *)(iVar3 + 0x224) == *(float *)(iVar4 + 0x224);
            bVar11 = *(float *)(iVar3 + 0x224) < *(float *)(iVar4 + 0x224);
          }
          piVar10 = piStack_10;
          piStack_c = piVar7;
          if (!bVar11 && !bVar12) break;
          piVar8 = piVar8 + -1;
          if (piVar8 != piVar5) {
            iVar3 = *piVar8;
            *piVar8 = iVar4;
            *piVar5 = iVar3;
          }
        }
        piStack_c = piVar7 + -1;
        piVar9 = piStack_10;
        piVar7 = piStack_c;
      }
      if (piVar7 == param_2) {
        if (piVar10 == param_3) {
          *param_1 = (uint)piVar8;
          param_1[1] = (uint)piVar6;
          return;
        }
        if (piVar6 != piVar10) {
          iVar4 = *piVar8;
          *piVar8 = *piVar6;
          *piVar6 = iVar4;
        }
        piVar6 = piVar6 + 1;
        iVar4 = *piVar8;
        *piVar8 = *piVar10;
        *piVar10 = iVar4;
        piVar9 = piVar10 + 1;
        piVar10 = piVar10 + 1;
        piStack_8 = piVar6;
        piVar8 = piVar8 + 1;
      }
      else {
        piVar7 = piVar7 + -1;
        piStack_c = piVar7;
        if (piVar10 == param_3) {
          piVar8 = piVar8 + -1;
          if (piVar7 != piVar8) {
            iVar4 = *piVar7;
            *piVar7 = *piVar8;
            *piVar8 = iVar4;
          }
          piVar9 = piVar6 + -1;
          piVar6 = piVar6 + -1;
          iVar4 = *piVar8;
          *piVar8 = *piVar9;
          *piVar6 = iVar4;
          piVar9 = piVar10;
          piVar10 = piStack_10;
          piStack_8 = piVar6;
        }
        else {
          iVar4 = *piVar10;
          *piVar10 = *piVar7;
          *piVar7 = iVar4;
          piVar9 = piVar10 + 1;
          piVar10 = piVar10 + 1;
        }
      }
      goto joined_r0x007a2ea2;
    }
    iVar4 = *piVar9;
    fVar1 = *(float *)(*piVar8 + 0x1cc);
    fVar2 = *(float *)(iVar4 + 0x1cc);
    if ((NAN(fVar1) || NAN(fVar2)) == (fVar1 == fVar2)) {
      bVar12 = fVar2 == fVar1;
      bVar11 = fVar2 < fVar1;
    }
    else {
      bVar12 = *(float *)(*piVar8 + 0x224) == *(float *)(iVar4 + 0x224);
      bVar11 = *(float *)(*piVar8 + 0x224) < *(float *)(iVar4 + 0x224);
    }
    piVar7 = piStack_c;
    if (bVar11 || bVar12) {
      if ((NAN(fVar2) || NAN(fVar1)) == (fVar2 == fVar1)) {
        bVar12 = fVar1 == fVar2;
        bVar11 = fVar1 < fVar2;
      }
      else {
        bVar12 = *(float *)(iVar4 + 0x224) == *(float *)(*piVar8 + 0x224);
        bVar11 = *(float *)(iVar4 + 0x224) < *(float *)(*piVar8 + 0x224);
      }
      piVar5 = piStack_c;
      piStack_8 = piVar6;
      piStack_10 = piVar9;
      if (!bVar11 && !bVar12) goto joined_r0x007a2f32;
      if (piVar6 != piVar9) {
        iVar3 = *piVar6;
        *piVar6 = iVar4;
        *piVar9 = iVar3;
      }
      piVar6 = piVar6 + 1;
    }
    piVar9 = piVar9 + 1;
    piVar10 = piVar9;
    piStack_8 = piVar6;
  } while( true );
}



/* FUNCTION 11496 ; VA 0x007a3050 ; FUN_007a3050 */

void FUN_007a3050(undefined4 *param_1,int *param_2,int *param_3,undefined4 param_4)

{
  float fVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  int *piStack_10;
  int *piStack_c;
  int *piStack_8;
  
  piVar5 = param_2 + ((int)param_3 - (int)param_2 >> 3);
  FUN_007a2530(param_2,piVar5,param_3 + -1,param_4);
  piVar4 = piVar5 + 1;
  for (; param_2 < piVar5; piVar5 = piVar5 + -1) {
    if ((*(float *)(piVar5[-1] + 0x1cc) < *(float *)(*piVar5 + 0x1cc)) ||
       (*(float *)(*piVar5 + 0x1cc) < *(float *)(piVar5[-1] + 0x1cc))) break;
  }
  piVar7 = piVar4;
  piStack_10 = piVar4;
  piStack_8 = piVar4;
  piStack_c = piVar5;
  piVar6 = piVar5;
  if (piVar4 < param_3) {
    do {
      piVar7 = piVar4;
      piStack_10 = piVar4;
      piStack_8 = piVar4;
      if ((*(float *)(*piVar4 + 0x1cc) < *(float *)(*piVar5 + 0x1cc)) ||
         (*(float *)(*piVar5 + 0x1cc) < *(float *)(*piVar4 + 0x1cc))) break;
      piVar4 = piVar4 + 1;
      piVar7 = piVar4;
      piStack_10 = piVar4;
      piStack_8 = piVar4;
    } while (piVar4 < param_3);
  }
joined_r0x007a30fa:
  do {
    piVar3 = piVar5;
    if (param_3 <= piVar7) {
joined_r0x007a3140:
      while (piVar8 = piVar7, param_2 < piVar5) {
        piVar3 = piVar3 + -1;
        piVar4 = piStack_8;
        if (*(float *)(*piVar6 + 0x1cc) <= *(float *)(*piVar3 + 0x1cc)) {
          piVar8 = piStack_10;
          piStack_c = piVar5;
          if (*(float *)(*piVar6 + 0x1cc) < *(float *)(*piVar3 + 0x1cc)) break;
          piVar6 = piVar6 + -1;
          if (piVar6 != piVar3) {
            iVar2 = *piVar6;
            *piVar6 = *piVar3;
            *piVar3 = iVar2;
          }
        }
        piStack_c = piVar5 + -1;
        piVar7 = piStack_10;
        piVar5 = piStack_c;
      }
      if (piVar5 == param_2) {
        if (piVar8 == param_3) {
          *param_1 = piVar6;
          param_1[1] = piVar4;
          return;
        }
        if (piVar4 != piVar8) {
          iVar2 = *piVar6;
          *piVar6 = *piVar4;
          *piVar4 = iVar2;
        }
        iVar2 = *piVar6;
        piVar4 = piVar4 + 1;
        *piVar6 = *piVar8;
        *piVar8 = iVar2;
        piVar7 = piVar8 + 1;
        piStack_10 = piVar8 + 1;
        piStack_8 = piVar4;
        piVar6 = piVar6 + 1;
      }
      else {
        piVar5 = piVar5 + -1;
        piStack_c = piVar5;
        if (piVar8 == param_3) {
          piVar6 = piVar6 + -1;
          if (piVar5 != piVar6) {
            iVar2 = *piVar5;
            *piVar5 = *piVar6;
            *piVar6 = iVar2;
          }
          iVar2 = *piVar6;
          piVar4 = piVar4 + -1;
          *piVar6 = *piVar4;
          *piVar4 = iVar2;
          piVar7 = piVar8;
          piStack_8 = piVar4;
        }
        else {
          iVar2 = *piVar8;
          *piVar8 = *piVar5;
          *piVar5 = iVar2;
          piVar7 = piVar8 + 1;
          piStack_10 = piVar8 + 1;
        }
      }
      goto joined_r0x007a30fa;
    }
    fVar1 = *(float *)(*piVar7 + 0x1cc);
    piVar5 = piStack_c;
    if (fVar1 <= *(float *)(*piVar6 + 0x1cc)) {
      piVar3 = piStack_c;
      piStack_8 = piVar4;
      piStack_10 = piVar7;
      if (fVar1 < *(float *)(*piVar6 + 0x1cc)) goto joined_r0x007a3140;
      if (piVar4 != piVar7) {
        iVar2 = *piVar4;
        *piVar4 = *piVar7;
        *piVar7 = iVar2;
      }
      piVar4 = piVar4 + 1;
    }
    piVar7 = piVar7 + 1;
    piStack_10 = piVar7;
    piStack_8 = piVar4;
  } while( true );
}



/* FUNCTION 11497 ; VA 0x007a3220 ; FUN_007a3220 */

void FUN_007a3220(uint *param_1,int *param_2,int *param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  int *piVar12;
  int *piVar13;
  int *piVar14;
  int *piVar15;
  int *piVar16;
  int *piStack_18;
  int *piStack_10;
  int *piStack_c;
  int *piStack_8;
  
  piVar13 = param_3 + -8;
  piVar16 = param_2 + ((int)param_3 - (int)param_2 >> 6) * 8;
  iVar10 = (int)piVar13 - (int)param_2 >> 5;
  if (iVar10 < 0x29) {
    FUN_007a2be0(param_2,piVar16,piVar13,param_4);
  }
  else {
    iVar10 = iVar10 + 1 >> 3;
    FUN_007a2be0(param_2,param_2 + iVar10 * 8,param_2 + iVar10 * 0x10,param_4);
    FUN_007a2be0(piVar16 + iVar10 * -8,piVar16,piVar16 + iVar10 * 8,param_4);
    FUN_007a2be0(piVar13 + iVar10 * -0x10,piVar13 + iVar10 * -8,piVar13,param_4);
    FUN_007a2be0(param_2 + iVar10 * 8,piVar16,piVar13 + iVar10 * -8,param_4);
  }
  piStack_8 = piVar16;
  if (param_2 < piVar16) {
    while( true ) {
      iVar10 = FUN_008361f0(*(undefined4 *)
                             (piStack_8[-7] * 0x278 + 0x260 + *(int *)(piStack_8[-8] + 0x14)));
      iVar11 = FUN_008361f0(*(undefined4 *)
                             (*(int *)(*piStack_8 + 0x14) + 0x260 + piStack_8[1] * 0x278));
      if (*(int *)(iVar11 + 8) < *(int *)(iVar10 + 8)) break;
      iVar10 = FUN_008361f0(*(undefined4 *)
                             (*(int *)(*piStack_8 + 0x14) + 0x260 + piStack_8[1] * 0x278));
      iVar11 = FUN_008361f0(*(undefined4 *)
                             (piStack_8[-7] * 0x278 + 0x260 + *(int *)(piStack_8[-8] + 0x14)));
      if ((*(int *)(iVar11 + 8) < *(int *)(iVar10 + 8)) ||
         (piStack_8 = piStack_8 + -8, piStack_8 <= param_2)) break;
    }
  }
  do {
    piVar16 = piVar16 + 8;
    piVar13 = piStack_8;
    piStack_18 = piVar16;
    piStack_c = piVar16;
    piStack_10 = piStack_8;
    if (param_3 <= piVar16) goto joined_r0x007a3485;
    iVar10 = FUN_008361f0(*(undefined4 *)(*(int *)(*piVar16 + 0x14) + 0x260 + piVar16[1] * 0x278));
    iVar11 = FUN_008361f0(*(undefined4 *)
                           (piStack_8[1] * 0x278 + 0x260 + *(int *)(*piStack_8 + 0x14)));
    if (*(int *)(iVar11 + 8) < *(int *)(iVar10 + 8)) break;
    iVar10 = FUN_008361f0(*(undefined4 *)
                           (piStack_8[1] * 0x278 + 0x260 + *(int *)(*piStack_8 + 0x14)));
    iVar11 = FUN_008361f0(*(undefined4 *)(*(int *)(*piVar16 + 0x14) + 0x260 + piVar16[1] * 0x278));
  } while (*(int *)(iVar10 + 8) <= *(int *)(iVar11 + 8));
joined_r0x007a3485:
  do {
    piVar15 = piVar13;
    if (param_3 <= piVar16) {
joined_r0x007a356e:
      while (piVar12 = piVar13, param_2 < piVar13) {
        piVar14 = piVar15 + -8;
        iVar10 = FUN_008361f0(*(undefined4 *)
                               (piVar15[-7] * 0x278 + 0x260 + *(int *)(*piVar14 + 0x14)));
        iVar11 = FUN_008361f0(*(undefined4 *)
                               (*(int *)(*piStack_8 + 0x14) + 0x260 + piStack_8[1] * 0x278));
        piVar12 = piStack_8;
        piVar16 = piStack_18;
        if (*(int *)(iVar10 + 8) <= *(int *)(iVar11 + 8)) {
          iVar10 = FUN_008361f0(*(undefined4 *)
                                 (*(int *)(*piStack_8 + 0x14) + 0x260 + piStack_8[1] * 0x278));
          iVar11 = FUN_008361f0(*(undefined4 *)
                                 (piVar15[-7] * 0x278 + 0x260 + *(int *)(*piVar14 + 0x14)));
          piVar12 = piStack_10;
          if (*(int *)(iVar11 + 8) < *(int *)(iVar10 + 8)) break;
          piVar12 = piStack_8 + -8;
          if (piVar12 != piVar14) {
            iVar10 = piVar15[-7];
            iVar11 = piVar15[-6];
            iVar1 = piVar15[-5];
            iVar2 = *piVar12;
            iVar3 = piStack_8[-7];
            iVar4 = piStack_8[-6];
            iVar5 = piStack_8[-5];
            iVar6 = piStack_8[-4];
            iVar7 = piStack_8[-3];
            iVar8 = piStack_8[-2];
            iVar9 = piStack_8[-1];
            *piVar12 = *piVar14;
            piStack_8[-7] = iVar10;
            piStack_8[-6] = iVar11;
            piStack_8[-5] = iVar1;
            iVar10 = piVar15[-3];
            iVar11 = piVar15[-2];
            iVar1 = piVar15[-1];
            piStack_8[-4] = piVar15[-4];
            piStack_8[-3] = iVar10;
            piStack_8[-2] = iVar11;
            piStack_8[-1] = iVar1;
            *piVar14 = iVar2;
            piVar15[-7] = iVar3;
            piVar15[-6] = iVar4;
            piVar15[-5] = iVar5;
            piVar15[-4] = iVar6;
            piVar15[-3] = iVar7;
            piVar15[-2] = iVar8;
            piVar15[-1] = iVar9;
          }
        }
        piStack_10 = piStack_10 + -8;
        piVar15 = piVar14;
        piStack_8 = piVar12;
        piVar13 = piStack_10;
      }
      if (piVar12 == param_2) {
        if (piVar16 == param_3) {
          param_1[1] = (uint)piStack_c;
          *param_1 = (uint)piStack_8;
          return;
        }
        if (piStack_c != piVar16) {
          iVar10 = piStack_c[1];
          iVar11 = piStack_c[2];
          iVar1 = piStack_c[3];
          iVar2 = *piStack_8;
          iVar3 = piStack_8[1];
          iVar4 = piStack_8[2];
          iVar5 = piStack_8[3];
          iVar6 = piStack_8[4];
          iVar7 = piStack_8[5];
          iVar8 = piStack_8[6];
          iVar9 = piStack_8[7];
          *piStack_8 = *piStack_c;
          piStack_8[1] = iVar10;
          piStack_8[2] = iVar11;
          piStack_8[3] = iVar1;
          iVar10 = piStack_c[5];
          iVar11 = piStack_c[6];
          iVar1 = piStack_c[7];
          piStack_8[4] = piStack_c[4];
          piStack_8[5] = iVar10;
          piStack_8[6] = iVar11;
          piStack_8[7] = iVar1;
          *piStack_c = iVar2;
          piStack_c[1] = iVar3;
          piStack_c[2] = iVar4;
          piStack_c[3] = iVar5;
          piStack_c[4] = iVar6;
          piStack_c[5] = iVar7;
          piStack_c[6] = iVar8;
          piStack_c[7] = iVar9;
        }
        iVar10 = piVar16[1];
        iVar11 = piVar16[2];
        iVar1 = piVar16[3];
        iVar2 = *piStack_8;
        iVar3 = piStack_8[1];
        iVar4 = piStack_8[2];
        iVar5 = piStack_8[3];
        iVar6 = piStack_8[4];
        iVar7 = piStack_8[5];
        iVar8 = piStack_8[6];
        iVar9 = piStack_8[7];
        *piStack_8 = *piVar16;
        piStack_8[1] = iVar10;
        piStack_8[2] = iVar11;
        piStack_8[3] = iVar1;
        iVar10 = piVar16[5];
        iVar11 = piVar16[6];
        iVar1 = piVar16[7];
        piStack_8[4] = piVar16[4];
        piStack_8[5] = iVar10;
        piStack_8[6] = iVar11;
        piStack_8[7] = iVar1;
        piStack_8 = piStack_8 + 8;
        *piVar16 = iVar2;
        piVar16[1] = iVar3;
        piVar16[2] = iVar4;
        piVar16[3] = iVar5;
        piVar16[4] = iVar6;
        piVar16[5] = iVar7;
        piVar16[6] = iVar8;
        piVar16[7] = iVar9;
        piVar16 = piVar16 + 8;
        piVar13 = piVar12;
        piStack_18 = piVar16;
        piStack_c = piStack_c + 8;
      }
      else {
        piVar13 = piVar12 + -8;
        piStack_10 = piVar13;
        if (piVar16 == param_3) {
          piVar15 = piStack_8 + -8;
          if (piVar13 != piVar15) {
            iVar10 = piStack_8[-7];
            iVar11 = piStack_8[-6];
            iVar1 = piStack_8[-5];
            iVar2 = *piVar13;
            iVar3 = piVar12[-7];
            iVar4 = piVar12[-6];
            iVar5 = piVar12[-5];
            iVar6 = piVar12[-4];
            iVar7 = piVar12[-3];
            iVar8 = piVar12[-2];
            iVar9 = piVar12[-1];
            *piVar13 = *piVar15;
            piVar12[-7] = iVar10;
            piVar12[-6] = iVar11;
            piVar12[-5] = iVar1;
            iVar10 = piStack_8[-3];
            iVar11 = piStack_8[-2];
            iVar1 = piStack_8[-1];
            piVar12[-4] = piStack_8[-4];
            piVar12[-3] = iVar10;
            piVar12[-2] = iVar11;
            piVar12[-1] = iVar1;
            *piVar15 = iVar2;
            piStack_8[-7] = iVar3;
            piStack_8[-6] = iVar4;
            piStack_8[-5] = iVar5;
            piStack_8[-4] = iVar6;
            piStack_8[-3] = iVar7;
            piStack_8[-2] = iVar8;
            piStack_8[-1] = iVar9;
          }
          iVar10 = *piVar15;
          iVar11 = piStack_8[-7];
          iVar1 = piStack_8[-6];
          iVar2 = piStack_8[-5];
          piVar12 = piStack_c + -8;
          iVar3 = piStack_8[-4];
          iVar4 = piStack_8[-3];
          iVar5 = piStack_8[-2];
          iVar6 = piStack_8[-1];
          iVar7 = piStack_c[-7];
          iVar8 = piStack_c[-6];
          iVar9 = piStack_c[-5];
          *piVar15 = *piVar12;
          piStack_8[-7] = iVar7;
          piStack_8[-6] = iVar8;
          piStack_8[-5] = iVar9;
          iVar7 = piStack_c[-3];
          iVar8 = piStack_c[-2];
          iVar9 = piStack_c[-1];
          piStack_8[-4] = piStack_c[-4];
          piStack_8[-3] = iVar7;
          piStack_8[-2] = iVar8;
          piStack_8[-1] = iVar9;
          *piVar12 = iVar10;
          piStack_c[-7] = iVar11;
          piStack_c[-6] = iVar1;
          piStack_c[-5] = iVar2;
          piStack_c[-4] = iVar3;
          piStack_c[-3] = iVar4;
          piStack_c[-2] = iVar5;
          piStack_c[-1] = iVar6;
          piStack_c = piVar12;
          piStack_8 = piVar15;
        }
        else {
          iVar10 = piVar12[-7];
          iVar11 = piVar12[-6];
          iVar1 = piVar12[-5];
          iVar2 = *piVar16;
          iVar3 = piVar16[1];
          iVar4 = piVar16[2];
          iVar5 = piVar16[3];
          iVar6 = piVar16[4];
          iVar7 = piVar16[5];
          iVar8 = piVar16[6];
          iVar9 = piVar16[7];
          *piVar16 = *piVar13;
          piVar16[1] = iVar10;
          piVar16[2] = iVar11;
          piVar16[3] = iVar1;
          iVar10 = piVar12[-3];
          iVar11 = piVar12[-2];
          iVar1 = piVar12[-1];
          piVar16[4] = piVar12[-4];
          piVar16[5] = iVar10;
          piVar16[6] = iVar11;
          piVar16[7] = iVar1;
          piVar16 = piVar16 + 8;
          *piVar13 = iVar2;
          piVar12[-7] = iVar3;
          piVar12[-6] = iVar4;
          piVar12[-5] = iVar5;
          piVar12[-4] = iVar6;
          piVar12[-3] = iVar7;
          piVar12[-2] = iVar8;
          piVar12[-1] = iVar9;
          piStack_18 = piVar16;
        }
      }
      goto joined_r0x007a3485;
    }
    iVar10 = FUN_008361f0(*(undefined4 *)
                           (*(int *)(*piStack_8 + 0x14) + 0x260 + piStack_8[1] * 0x278));
    iVar11 = FUN_008361f0(*(undefined4 *)(piVar16[1] * 0x278 + 0x260 + *(int *)(*piVar16 + 0x14)));
    piVar13 = piStack_10;
    if (*(int *)(iVar10 + 8) <= *(int *)(iVar11 + 8)) {
      iVar10 = FUN_008361f0(*(undefined4 *)(piVar16[1] * 0x278 + 0x260 + *(int *)(*piVar16 + 0x14)))
      ;
      iVar11 = FUN_008361f0(*(undefined4 *)
                             (*(int *)(*piStack_8 + 0x14) + 0x260 + piStack_8[1] * 0x278));
      piVar15 = piStack_10;
      piStack_18 = piVar16;
      if (*(int *)(iVar11 + 8) < *(int *)(iVar10 + 8)) goto joined_r0x007a356e;
      if (piStack_c != piVar16) {
        iVar10 = piVar16[1];
        iVar11 = piVar16[2];
        iVar1 = piVar16[3];
        iVar2 = *piStack_c;
        iVar3 = piStack_c[1];
        iVar4 = piStack_c[2];
        iVar5 = piStack_c[3];
        iVar6 = piStack_c[4];
        iVar7 = piStack_c[5];
        iVar8 = piStack_c[6];
        iVar9 = piStack_c[7];
        *piStack_c = *piVar16;
        piStack_c[1] = iVar10;
        piStack_c[2] = iVar11;
        piStack_c[3] = iVar1;
        iVar10 = piVar16[5];
        iVar11 = piVar16[6];
        iVar1 = piVar16[7];
        piStack_c[4] = piVar16[4];
        piStack_c[5] = iVar10;
        piStack_c[6] = iVar11;
        piStack_c[7] = iVar1;
        *piVar16 = iVar2;
        piVar16[1] = iVar3;
        piVar16[2] = iVar4;
        piVar16[3] = iVar5;
        piVar16[4] = iVar6;
        piVar16[5] = iVar7;
        piVar16[6] = iVar8;
        piVar16[7] = iVar9;
      }
      piStack_c = piStack_c + 8;
    }
    piVar16 = piVar16 + 8;
    piStack_18 = piVar16;
  } while( true );
}



/* FUNCTION 11498 ; VA 0x007a3770 ; FUN_007a3770 */

void FUN_007a3770(int param_1,int param_2,uint param_3,int *param_4)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  bool bVar8;
  bool bVar9;
  
  iVar7 = (int)(param_3 - 1) >> 1;
  iVar5 = param_2;
  iVar6 = param_2;
  if (param_2 < iVar7) {
    do {
      iVar6 = *(int *)(param_1 + 4 + iVar5 * 8);
      iVar4 = *(int *)(param_1 + 8 + iVar5 * 8);
      fVar2 = *(float *)(iVar6 + 0x1cc);
      fVar3 = *(float *)(iVar4 + 0x1cc);
      if ((NAN(fVar3) || NAN(fVar2)) == (fVar3 == fVar2)) {
        bVar9 = fVar2 == fVar3;
        bVar8 = fVar2 < fVar3;
      }
      else {
        fVar2 = *(float *)(iVar4 + 0x224);
        pfVar1 = (float *)(iVar6 + 0x224);
        bVar9 = fVar2 == *pfVar1;
        bVar8 = fVar2 < *pfVar1;
      }
      iVar6 = iVar5 * 2 + 1 + ((!bVar8 && !bVar9) ^ 1);
      *(undefined4 *)(param_1 + iVar5 * 4) = *(undefined4 *)(param_1 + iVar6 * 4);
      iVar5 = iVar6;
    } while (iVar6 < iVar7);
  }
  if ((iVar6 == iVar7) && ((param_3 & 1) == 0)) {
    *(undefined4 *)(param_1 + iVar6 * 4) = *(undefined4 *)(param_1 + -4 + param_3 * 4);
    iVar6 = param_3 - 1;
  }
  while (param_2 < iVar6) {
    iVar7 = iVar6 + -1 >> 1;
    iVar5 = *(int *)(param_1 + iVar7 * 4);
    fVar2 = *(float *)(*param_4 + 0x1cc);
    fVar3 = *(float *)(iVar5 + 0x1cc);
    if ((NAN(fVar3) || NAN(fVar2)) == (fVar3 == fVar2)) {
      bVar9 = fVar2 == fVar3;
      bVar8 = fVar2 < fVar3;
    }
    else {
      pfVar1 = (float *)(*param_4 + 0x224);
      bVar9 = *(float *)(iVar5 + 0x224) == *pfVar1;
      bVar8 = *(float *)(iVar5 + 0x224) < *pfVar1;
    }
    if (bVar8 || bVar9) break;
    *(int *)(param_1 + iVar6 * 4) = iVar5;
    iVar6 = iVar7;
  }
  *(int *)(param_1 + iVar6 * 4) = *param_4;
  return;
}



/* FUNCTION 11499 ; VA 0x007a3870 ; FUN_007a3870 */

void FUN_007a3870(int param_1,int param_2,uint param_3,int *param_4)

{
  float *pfVar1;
  float fVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  
  iVar6 = (int)(param_3 - 1) >> 1;
  iVar3 = param_2;
  iVar4 = param_2;
  if (param_2 < iVar6) {
    do {
      fVar2 = *(float *)(*(int *)(param_1 + 4 + iVar3 * 8) + 0x1cc);
      pfVar1 = (float *)(*(int *)(param_1 + 8 + iVar3 * 8) + 0x1cc);
      iVar4 = ((*pfVar1 <= fVar2 && fVar2 != *pfVar1) ^ 1) + 1 + iVar3 * 2;
      *(undefined4 *)(param_1 + iVar3 * 4) = *(undefined4 *)(param_1 + iVar4 * 4);
      iVar3 = iVar4;
    } while (iVar4 < iVar6);
  }
  if ((iVar4 == iVar6) && ((param_3 & 1) == 0)) {
    *(undefined4 *)(param_1 + iVar4 * 4) = *(undefined4 *)(param_1 + -4 + param_3 * 4);
    iVar4 = param_3 - 1;
  }
  if (param_2 < iVar4) {
    while( true ) {
      iVar3 = *param_4;
      iVar5 = iVar4 + -1 >> 1;
      iVar6 = *(int *)(param_1 + iVar5 * 4);
      pfVar1 = (float *)(iVar6 + 0x1cc);
      if (*(float *)(iVar3 + 0x1cc) < *pfVar1 || *(float *)(iVar3 + 0x1cc) == *pfVar1) break;
      *(int *)(param_1 + iVar4 * 4) = iVar6;
      iVar4 = iVar5;
      if (iVar5 <= param_2) {
        *(int *)(param_1 + iVar5 * 4) = *param_4;
        return;
      }
    }
  }
  else {
    iVar3 = *param_4;
  }
  *(int *)(param_1 + iVar4 * 4) = iVar3;
  return;
}


