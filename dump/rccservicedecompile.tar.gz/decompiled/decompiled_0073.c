/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 18250 ; VA 0x009a0700 ; FUN_009a0700 */

undefined4 * __thiscall
FUN_009a0700(undefined4 *param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined4 auStack_e0 [50];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d298b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar1 = FUN_0099be20();
  FUN_009cb790(uVar1,param_4,param_6,param_7,param_8);
  *(undefined8 *)(param_1 + 0xe) = param_2;
  *param_1 = RBX::Reflection::BoundFuncDesc<class_RBX::Humanoid,void___cdecl(float),1>::vftable;
  param_1[0x10] = param_3;
  param_1[0x11] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar1 = FUN_00888530();
  param_1[9] = uVar1;
  puVar2 = (undefined4 *)param_1[0x11];
  if (puVar2 == (undefined4 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar2 = &uStack_1b8;
    uStack_8 = 3;
    uVar4 = 2;
  }
  else {
    uStack_e8 = FUN_0088c960();
    iStack_e4 = 0;
    auStack_e0[0] = *puVar2;
    iStack_e4 = FUN_00630820();
    puVar2 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar4 = 1;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088c960();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar4;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar4 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18251 ; VA 0x009a0880 ; FUN_009a0880 */

undefined4 * __thiscall
FUN_009a0880(undefined4 *param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d292b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_0099be20();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  *(undefined8 *)(param_1 + 0xe) = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::Humanoid,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
             ::vftable;
  param_1[0x10] = param_3;
  param_1[0x11] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_00888530();
  param_1[9] = uVar2;
  puVar3 = (undefined4 *)param_1[0x11];
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088cdc0();
    iStack_e4 = 0;
    if (puVar3[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar3[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e0 = *puVar3;
    uStack_dc = puVar3[1];
    iStack_e4 = FUN_006309e0();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(&uStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18252 ; VA 0x009a0a30 ; FUN_009a0a30 */

undefined4 * __thiscall
FUN_009a0a30(undefined4 *param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d29eb;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_0099be20();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  *(undefined8 *)(param_1 + 0xe) = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::Humanoid,bool___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
             ::vftable;
  param_1[0x10] = param_3;
  param_1[0x11] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_0088daf0();
  param_1[9] = uVar2;
  iVar1 = param_1[0x11];
  if (iVar1 == 0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088cb40();
    iStack_e4 = 0;
    FUN_0054ef60(iVar1);
    iStack_e4 = FUN_005c9d30();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18253 ; VA 0x009a0bb0 ; FUN_009a0bb0 */

undefined4 * __thiscall
FUN_009a0bb0(undefined4 *param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined8 param_8,
            undefined4 param_9)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined4 auStack_e0 [50];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d2a4b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar1 = FUN_0099be20();
  FUN_009cb790(uVar1,param_4,param_7,param_8,param_9);
  *(undefined8 *)(param_1 + 0xe) = param_2;
  uStack_8 = 0;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::Humanoid,bool___cdecl(enum_RBX::Humanoid::Status),1>::vftable;
  param_1[0x10] = param_3;
  puVar2 = (undefined4 *)FUN_01674e20(4);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = param_6;
  }
  param_1[0x11] = puVar2;
  uStack_8._0_1_ = 1;
  uVar1 = FUN_0088daf0();
  param_1[9] = uVar1;
  puVar2 = (undefined4 *)param_1[0x11];
  if (puVar2 == (undefined4 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar2 = &uStack_1b8;
    uStack_8 = 3;
    uVar4 = 2;
  }
  else {
    uStack_e8 = FUN_009c68d0();
    iStack_e4 = 0;
    auStack_e0[0] = *puVar2;
    iStack_e4 = FUN_009c6cd0();
    puVar2 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar4 = 1;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_009c68d0();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar4;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar4 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18254 ; VA 0x009a0d40 ; FUN_009a0d40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __fastcall FUN_009a0d40(undefined4 *param_1)

{
  int iVar1;
  void *pvVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("HumanoidRigType");
  pvVar2 = ThreadLocalStoragePointer;
  iVar1 = _tls_index;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::HumanoidRigType>::vftable;
  uStack_8 = 0;
  if (*(int *)(*(int *)((int)pvVar2 + iVar1 * 4) + 0x34) < DAT_01ee3b44) {
    FUN_016f3809(&DAT_01ee3b44);
    if (DAT_01ee3b44 == -1) {
      _DAT_01d64f58 = PTR_DAT_01d64a34;
      _DAT_01d64f60 = PTR_DAT_01d64a38;
      FUN_016f37bf(&DAT_01ee3b44);
    }
  }
  FUN_009caf20(&DAT_01d64f54,2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18255 ; VA 0x009a0df0 ; FUN_009a0df0 */

undefined4 *
FUN_009a0df0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d2a81;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb970(uVar1,param_3,0,CONCAT44(uStack_28,uStack_2c),0);
  puStack_14[0xe] = param_1;
  puStack_14[0xf] = param_2;
  iStack_8 = 0;
  *puStack_14 = RBX::Reflection::
                EventDesc<class_RBX::Humanoid,void___cdecl(float),class_rbx::signal<void___cdecl(float)>,class_rbx::signal<void___cdecl(float)>_RBX::Humanoid::*>
                ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088c960();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687810(auStack_104,&uStack_2c,param_3);
  iStack_8._0_1_ = 2;
  if (puStack_14 + 10 != &uStack_20) {
    FUN_0068a760();
    puStack_14[10] = uStack_20;
    puStack_14[0xb] = uStack_1c;
    puStack_14[0xc] = uStack_18;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_18 = 0;
  }
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  *puStack_14 = RBX::Reflection::
                EventDesc<class_RBX::Humanoid,void___cdecl(float),class_rbx::signal<void___cdecl(float)>,class_rbx::signal<void___cdecl(float)>_RBX::Humanoid::*>
                ::vftable;
  ExceptionList = pvStack_10;
  return puStack_14;
}



/* FUNCTION 18256 ; VA 0x009a0f30 ; FUN_009a0f30 */

undefined4 *
FUN_009a0f30(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined8 param_5,undefined4 param_6)

{
  undefined4 uVar1;
  undefined auStack_f8 [216];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d2ab1;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb970(uVar1,param_3,0,param_5,param_6);
  puStack_14[0xe] = param_1;
  puStack_14[0xf] = param_2;
  iStack_8 = 0;
  *puStack_14 = RBX::Reflection::
                EventDesc<class_RBX::Humanoid,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::Humanoid::*>
                ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687810(auStack_f8,&uStack_20,param_3);
  iStack_8._0_1_ = 2;
  if (puStack_14 + 10 != &uStack_20) {
    FUN_0068a760();
    puStack_14[10] = uStack_20;
    puStack_14[0xb] = uStack_1c;
    puStack_14[0xc] = uStack_18;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_18 = 0;
  }
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_f8,0xd8,1,FUN_00688b10);
  *puStack_14 = RBX::Reflection::
                EventDesc<class_RBX::Humanoid,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::Humanoid::*>
                ::vftable;
  ExceptionList = pvStack_10;
  return puStack_14;
}



/* FUNCTION 18257 ; VA 0x009a1070 ; FUN_009a1070 */

undefined4 *
FUN_009a1070(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined8 param_5,undefined4 param_6)

{
  undefined4 uVar1;
  undefined auStack_f8 [216];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d2ae1;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb970(uVar1,param_3,0,param_5,param_6);
  puStack_14[0xe] = param_1;
  puStack_14[0xf] = param_2;
  iStack_8 = 0;
  *puStack_14 = RBX::Reflection::
                EventDesc<class_RBX::Humanoid,void___cdecl(enum_RBX::Humanoid::Status),class_rbx::signal<void___cdecl(enum_RBX::Humanoid::Status)>,class_rbx::signal<void___cdecl(enum_RBX::Humanoid::Status)>_RBX::Humanoid::*>
                ::vftable;
  FUN_0086e3d0(param_4);
  FUN_009c68d0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687810(auStack_f8,&uStack_20,param_3);
  iStack_8._0_1_ = 2;
  if (puStack_14 + 10 != &uStack_20) {
    FUN_0068a760();
    puStack_14[10] = uStack_20;
    puStack_14[0xb] = uStack_1c;
    puStack_14[0xc] = uStack_18;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_18 = 0;
  }
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_f8,0xd8,1,FUN_00688b10);
  *puStack_14 = RBX::Reflection::
                EventDesc<class_RBX::Humanoid,void___cdecl(enum_RBX::Humanoid::Status),class_rbx::signal<void___cdecl(enum_RBX::Humanoid::Status)>,class_rbx::signal<void___cdecl(enum_RBX::Humanoid::Status)>_RBX::Humanoid::*>
                ::vftable;
  ExceptionList = pvStack_10;
  return puStack_14;
}



/* FUNCTION 18258 ; VA 0x009a11b0 ; FUN_009a11b0 */

undefined4 *
FUN_009a11b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d2b11;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0099be20();
  FUN_009cb970(uVar1,param_3,0,CONCAT44(uStack_28,uStack_2c),0);
  puStack_14[0xe] = param_1;
  puStack_14[0xf] = param_2;
  iStack_8 = 0;
  *puStack_14 = RBX::Reflection::
                EventDesc<class_RBX::Humanoid,void___cdecl(bool),class_rbx::signal<void___cdecl(bool)>,class_rbx::signal<void___cdecl(bool)>_RBX::Humanoid::*>
                ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687810(auStack_104,&uStack_2c,param_3);
  iStack_8._0_1_ = 2;
  if (puStack_14 + 10 != &uStack_20) {
    FUN_0068a760();
    puStack_14[10] = uStack_20;
    puStack_14[0xb] = uStack_1c;
    puStack_14[0xc] = uStack_18;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_18 = 0;
  }
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  *puStack_14 = RBX::Reflection::
                EventDesc<class_RBX::Humanoid,void___cdecl(bool),class_rbx::signal<void___cdecl(bool)>,class_rbx::signal<void___cdecl(bool)>_RBX::Humanoid::*>
                ::vftable;
  ExceptionList = pvStack_10;
  return puStack_14;
}



/* FUNCTION 18259 ; VA 0x009a12f0 ; FUN_009a12f0 */

undefined4 __thiscall
FUN_009a12f0(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,undefined4 param_7,int *param_8,undefined4 param_9,int *param_10,
            undefined4 param_11,uint param_12,undefined4 param_13,undefined4 param_14,
            undefined4 param_15,undefined4 param_16,undefined4 *param_17,ulonglong param_18,
            uint param_19,undefined4 param_20,undefined4 param_21,undefined4 param_22,
            undefined4 param_23,undefined4 param_24,undefined8 param_25)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 *puStack_50;
  ulonglong uStack_4c;
  uint uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 *puStack_30;
  undefined8 uStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d2b58;
  pvStack_10 = ExceptionList;
  uStack_8 = 5;
  uStack_44 = 0;
  ExceptionList = &pvStack_10;
  if (param_19 != 0) {
    uStack_44 = param_19;
    if ((param_19 & 1) == 0) {
      uStack_4c = ZEXT48(&uStack_3c);
      puStack_50 = &param_21;
      uStack_54 = 0x9a135d;
      ExceptionList = &pvStack_10;
      (**(code **)(param_19 & 0xfffffffe))();
    }
    else {
      uStack_3c = param_21;
      uStack_38 = param_22;
      uStack_34 = param_23;
      puStack_30 = (undefined4 *)param_24;
      uStack_2c = param_25;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 6;
  if (param_12 != 0) {
    if ((param_12 & 1) == 0) {
      (**(code **)(param_12 & 0xfffffffe))(&param_14,&uStack_5c,0);
    }
    else {
      uStack_5c = param_14;
      uStack_58 = param_15;
      uStack_54 = param_16;
      puStack_50 = param_17;
      uStack_4c = param_18;
    }
  }
  if (param_10 != (int *)0x0) {
    LOCK();
    param_10[1] = param_10[1] + 1;
    UNLOCK();
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_009a1c90(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_2c = CONCAT44(0x9a1471,(undefined4)uStack_2c);
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_2c = CONCAT44(0x9a1486,(undefined4)uStack_2c);
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_2c = CONCAT44(0x9a149c,(undefined4)uStack_2c);
      (**(code **)*param_8)();
      LOCK();
      iVar2 = param_8[2] + -1;
      param_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_2c = CONCAT44(0x9a14ac,(undefined4)uStack_2c);
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  if (param_10 != (int *)0x0) {
    LOCK();
    iVar2 = param_10[1] + -1;
    param_10[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_2c = CONCAT44(0x9a14c2,(undefined4)uStack_2c);
      (**(code **)*param_10)();
      LOCK();
      piVar1 = param_10 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_2c = CONCAT44(0x9a14d1,(undefined4)uStack_2c);
        (**(code **)(*param_10 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    puStack_30 = &param_14;
    uStack_2c = CONCAT44(2,puStack_30);
    uStack_34 = 0x9a14f2;
    (**(code **)(param_12 & 0xfffffffe))();
  }
  uStack_8 = 8;
  if (((param_19 != 0) && ((param_19 & 1) == 0)) &&
     (*(code **)(param_19 & 0xfffffffe) != (code *)0x0)) {
    puStack_30 = &param_21;
    uStack_2c = CONCAT44(2,puStack_30);
    uStack_34 = 0x9a1520;
    (**(code **)(param_19 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18260 ; VA 0x009a1540 ; FUN_009a1540 */

undefined4 * __thiscall
FUN_009a1540(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,undefined4 param_7,int *param_8)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  piVar1 = param_3 + 2;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = 0;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  param_1[2] = 0;
  piVar2 = param_5 + 2;
  param_1[3] = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  param_1[2] = param_4;
  param_1[3] = param_5;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[2] + -1;
    param_5[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  param_1[4] = 0;
  param_1[5] = 0;
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  param_1[4] = param_7;
  param_1[5] = param_8;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[2] + -1;
    param_3[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[2] + -1;
    param_5[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar3 = param_8[1] + -1;
    param_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 18261 ; VA 0x009a16c0 ; FUN_009a16c0 */

int __thiscall
FUN_009a16c0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,undefined4 param_7,int *param_8,undefined4 param_9,int *param_10)

{
  int *piVar1;
  int iVar2;
  
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  FUN_009a1540(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  if (param_10 != (int *)0x0) {
    LOCK();
    param_10[1] = param_10[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x18) = param_9;
  *(int **)(param_1 + 0x1c) = param_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      iVar2 = param_8[2] + -1;
      param_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  if (param_10 != (int *)0x0) {
    LOCK();
    iVar2 = param_10[1] + -1;
    param_10[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_10)();
      LOCK();
      piVar1 = param_10 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_10 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 18262 ; VA 0x009a1800 ; FUN_009a1800 */

int __thiscall
FUN_009a1800(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,undefined4 param_7,int *param_8,undefined4 param_9,int *param_10,
            undefined4 param_11)

{
  int *piVar1;
  int iVar2;
  
  if (param_10 != (int *)0x0) {
    LOCK();
    param_10[1] = param_10[1] + 1;
    UNLOCK();
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  FUN_009a16c0(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10);
  *(undefined4 *)(param_1 + 0x20) = param_11;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      iVar2 = param_8[2] + -1;
      param_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  if (param_10 != (int *)0x0) {
    LOCK();
    iVar2 = param_10[1] + -1;
    param_10[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_10)();
      LOCK();
      piVar1 = param_10 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_10 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 18263 ; VA 0x009a1940 ; FUN_009a1940 */

int __thiscall
FUN_009a1940(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,undefined4 param_7,int *param_8,undefined4 param_9,int *param_10,
            undefined4 param_11,uint param_12,undefined4 param_13,undefined4 param_14,
            undefined4 param_15,undefined4 param_16,undefined4 param_17,undefined8 param_18)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d2ba0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_10 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_10[1] = param_10[1] + 1;
    UNLOCK();
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  FUN_009a1800(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  *(undefined4 *)(param_1 + 0x28) = 0;
  if (param_12 != 0) {
    *(uint *)(param_1 + 0x28) = param_12;
    if ((param_12 & 1) == 0) {
      (**(code **)(param_12 & 0xfffffffe))(&param_14,param_1 + 0x30,0);
    }
    else {
      *(undefined4 *)(param_1 + 0x30) = param_14;
      *(undefined4 *)(param_1 + 0x34) = param_15;
      *(undefined4 *)(param_1 + 0x38) = param_16;
      *(undefined4 *)(param_1 + 0x3c) = param_17;
      *(undefined8 *)(param_1 + 0x40) = param_18;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      iVar2 = param_8[2] + -1;
      param_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  if (param_10 != (int *)0x0) {
    LOCK();
    iVar2 = param_10[1] + -1;
    param_10[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_10)();
      LOCK();
      piVar1 = param_10 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_10 + 4))();
      }
    }
  }
  uStack_8 = 6;
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_12 & 0xfffffffe))(&param_14,&param_14,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18264 ; VA 0x009a1b20 ; FUN_009a1b20 */

undefined4 * __thiscall FUN_009a1b20(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d2bc0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = 0;
  param_1[5] = 0;
  if (param_2[5] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[5] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  param_1[6] = 0;
  param_1[7] = 0;
  if (param_2[7] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[7] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  param_1[8] = param_2[8];
  param_1[10] = 0;
  uVar2 = param_2[10];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[10] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
    }
    else {
      uVar3 = param_2[0xd];
      uVar4 = param_2[0xe];
      uVar5 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar3;
      param_1[0xe] = uVar4;
      param_1[0xf] = uVar5;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
    }
  }
  param_1[0x12] = 0;
  uVar2 = param_2[0x12];
  uStack_8 = 1;
  if (uVar2 != 0) {
    param_1[0x12] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0x15];
      uVar4 = param_2[0x16];
      uVar5 = param_2[0x17];
      param_1[0x14] = param_2[0x14];
      param_1[0x15] = uVar3;
      param_1[0x16] = uVar4;
      param_1[0x17] = uVar5;
      *(undefined8 *)(param_1 + 0x18) = *(undefined8 *)(param_2 + 0x18);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x14,param_1 + 0x14,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18265 ; VA 0x009a1c90 ; FUN_009a1c90 */

int __thiscall
FUN_009a1c90(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,undefined4 param_7,int *param_8,undefined4 param_9,int *param_10,
            undefined4 param_11,uint param_12,undefined4 param_13,undefined4 param_14,
            undefined4 param_15,undefined4 param_16,undefined4 *param_17,ulonglong param_18,
            uint param_19,undefined4 param_20,undefined4 param_21,undefined4 param_22,
            undefined4 param_23,undefined4 param_24,undefined8 param_25)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d2c08;
  pvStack_10 = ExceptionList;
  uStack_8 = 5;
  ExceptionList = &pvStack_10;
  if (param_12 != 0) {
    if ((param_12 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_12 & 0xfffffffe))(&param_14,&uStack_38,0);
    }
    else {
      uStack_38 = param_14;
      uStack_34 = param_15;
      uStack_30 = param_16;
      puStack_2c = param_17;
      uStack_28 = param_18;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_10 != (int *)0x0) {
    LOCK();
    param_10[1] = param_10[1] + 1;
    UNLOCK();
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  FUN_009a1940(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  *(undefined4 *)(param_1 + 0x48) = 0;
  if (param_19 != 0) {
    *(uint *)(param_1 + 0x48) = param_19;
    if ((param_19 & 1) == 0) {
      uStack_28 = (ulonglong)(param_1 + 0x50);
      puStack_2c = &param_21;
      uStack_30 = 0x9a1deb;
      (**(code **)(param_19 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x50) = param_21;
      *(undefined4 *)(param_1 + 0x54) = param_22;
      *(undefined4 *)(param_1 + 0x58) = param_23;
      *(undefined4 *)(param_1 + 0x5c) = param_24;
      *(undefined8 *)(param_1 + 0x60) = param_25;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = CONCAT44(0x9a1e06,(undefined4)uStack_28);
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = CONCAT44(0x9a1e1b,(undefined4)uStack_28);
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = CONCAT44(0x9a1e32,(undefined4)uStack_28);
      (**(code **)*param_8)();
      LOCK();
      iVar2 = param_8[2] + -1;
      param_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_28 = CONCAT44(0x9a1e43,(undefined4)uStack_28);
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  if (param_10 != (int *)0x0) {
    LOCK();
    iVar2 = param_10[1] + -1;
    param_10[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = CONCAT44(0x9a1e5a,(undefined4)uStack_28);
      (**(code **)*param_10)();
      LOCK();
      piVar1 = param_10 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_28 = CONCAT44(0x9a1e6a,(undefined4)uStack_28);
        (**(code **)(*param_10 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    puStack_2c = &param_14;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0x9a1e8b;
    (**(code **)(param_12 & 0xfffffffe))();
  }
  uStack_8 = 8;
  if (((param_19 != 0) && ((param_19 & 1) == 0)) &&
     (*(code **)(param_19 & 0xfffffffe) != (code *)0x0)) {
    puStack_2c = &param_21;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0x9a1eb9;
    (**(code **)(param_19 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18266 ; VA 0x009a1ed0 ; FUN_009a1ed0 */

undefined4 * __thiscall FUN_009a1ed0(undefined4 *param_1,int param_2,int param_3)

{
  undefined4 uVar1;
  undefined auStack_2c [8];
  undefined4 *puStack_24;
  int iStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d2c3e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  puStack_24 = param_1;
  uVar1 = FUN_009a6cf0(0,0);
  param_1[1] = uVar1;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  uStack_8 = 1;
  *param_1 = 0x3f800000;
  FUN_005cb500(8);
  uStack_8 = 2;
  iStack_20 = param_3;
  if (param_2 != param_3) {
    do {
      iStack_14 = *(int *)param_1[1];
      puStack_1c = *(undefined4 **)(iStack_14 + 4);
      uStack_18 = FUN_0099bfc0(iStack_14,puStack_1c,param_2);
      if (param_1[2] == 0x5d1745c) {
                    /* WARNING: Subroutine does not return */
        FUN_016ddcd9("list<T> too long");
      }
      param_1[2] = param_1[2] + 1;
      *(undefined4 *)(iStack_14 + 4) = uStack_18;
      *puStack_1c = uStack_18;
      FUN_0099c7c0(auStack_2c,*(int *)param_1[1] + 8,*(int *)param_1[1]);
      param_2 = param_2 + 0x24;
    } while (param_2 != iStack_20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18267 ; VA 0x009a1fe0 ; FUN_009a1fe0 */

undefined4 * __fastcall FUN_009a1fe0(undefined4 *param_1)

{
  *param_1 = 0x3f800000;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0x3f800000;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0x3f800000;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  *(undefined2 *)(param_1 + 0x14) = 0;
  *(undefined *)((int)param_1 + 0x52) = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  *(undefined *)((int)param_1 + 0x5d) = 1;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  return param_1;
}



/* FUNCTION 18268 ; VA 0x009a20d0 ; FUN_009a20d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_009a20d0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  byte bVar6;
  char cVar7;
  undefined4 uVar8;
  int *piVar9;
  uint *puVar10;
  int iVar11;
  uint uVar12;
  undefined **ppuVar13;
  byte bVar14;
  undefined **ppuVar15;
  undefined4 ****ppppuVar16;
  uint uVar17;
  undefined4 ***apppuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d30f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 != (undefined4 *)0x0) {
    ExceptionList = &pvStack_10;
    param_1[0x4e] = &DAT_01937ef0;
    param_1[0x1f9] = RBX::IHasLocation::vftable;
    uStack_8 = 0;
  }
  uStack_18 = (uint)(param_2 != (undefined4 *)0x0);
  puStack_14 = param_1;
  FUN_0089a7a0();
  uStack_8 = 1;
  *param_1 = RBX::DescribedCreatable<class_RBX::Humanoid,class_RBX::Instance>::vftable;
  uVar8 = FUN_0099be20();
  param_1[3] = uVar8;
  puVar1 = param_1 + 0x15;
  uStack_8 = 2;
  param_2 = puVar1;
  FUN_00ca27c0();
  param_1[0x3f] = RBX::Connector::vftable;
  param_1[0x40] = 0xffffffff;
  param_1[0x41] = 0xffffffff;
  param_1[0x42] = 0xffffffff;
  param_1[0x43] = 0xffffffff;
  param_1[0x44] = 0xffffffff;
  param_1[0x45] = 0xffffffff;
  *puVar1 = RBX::KernelJoint::vftable;
  param_1[0x17] = RBX::KernelJoint::vftable;
  param_1[0x3f] = RBX::KernelJoint::vftable;
  uStack_8._0_1_ = 3;
  *(undefined *)(param_1 + 0x57) = 0;
  param_1[0x58] = 0;
  FUN_016f4053(param_1 + 0x59,4,2,FUN_00610ca0,FUN_005f60a0);
  param_1[0x46] = RBX::IAdornable::vftable;
  param_1[0x47] = 0xffffffff;
  param_1[0x48] = 0xffffffff;
  param_1[0x49] = 0xffffffff;
  param_1[0x4a] = 0;
  param_1[0x4b] = 0;
  param_1[0x4c] = 0;
  uStack_8._0_1_ = 5;
  FUN_00f81d80(0);
  puVar5 = puStack_14;
  puStack_14[0x53] = RBX::IModelModifier::vftable;
  puStack_14[0x54] = RBX::IStepped::vftable;
  puStack_14[0x55] = 0;
  puStack_14[0x56] = 0;
  *puVar1 = RBX::Humanoid::vftable;
  *puStack_14 = RBX::Humanoid::vftable;
  param_1[0x4d] = RBX::Humanoid::vftable;
  puStack_14[0x17] = RBX::Humanoid::vftable;
  puStack_14[0x3f] = RBX::Humanoid::vftable;
  puStack_14[0x46] = RBX::Humanoid::vftable;
  puStack_14[0x53] = RBX::Humanoid::vftable;
  puStack_14[0x54] = RBX::Humanoid::vftable;
  *(undefined ***)(*(int *)(puStack_14[0x4e] + 4) + 0x138 + (int)puStack_14) =
       RBX::Humanoid::vftable;
  *(int *)(*(int *)(puStack_14[0x4e] + 4) + 0x134 + (int)puStack_14) =
       *(int *)(puStack_14[0x4e] + 4) + -0x6ac;
  puStack_14[0x5b] = 0;
  puStack_14[0x5c] = 0;
  puStack_14[0x5d] = 0;
  puStack_14[0x5e] = 0;
  puStack_14[99] = 0;
  puStack_14[100] = 0xf;
  *(undefined *)(puStack_14 + 0x5f) = 0;
  puStack_14[0x65] = 0;
  puStack_14[0x66] = 0;
  puStack_14[0x67] = 0;
  puStack_14[0x68] = 0;
  puStack_14[0x69] = 0;
  puStack_14[0x6a] = 0;
  puStack_14[0x6b] = 0;
  puStack_14[0x6c] = 0;
  puStack_14[0x6d] = 0;
  puStack_14[0x6e] = 0;
  puStack_14[0x6f] = 0;
  puStack_14[0x70] = 0;
  puStack_14[0x71] = 0;
  puStack_14[0x72] = 0;
  puStack_14[0x73] = 0;
  puStack_14[0x74] = 0;
  puStack_14[0x75] = 0;
  puStack_14[0x76] = 0;
  puStack_14[0x77] = 0;
  puStack_14[0x78] = 0;
  puStack_14[0x79] = 0;
  puStack_14[0x7a] = 0;
  uStack_8._0_1_ = 0xb;
  puStack_14[0x7b] = 0;
  piVar9 = (int *)FUN_01674e20(4);
  if (piVar9 == (int *)0x0) {
    piVar9 = (int *)0x0;
    param_2 = (undefined4 *)0x0;
  }
  else {
    param_2 = (undefined4 *)0x41800000;
    *piVar9 = 0x41800000 - (int)piVar9;
  }
  puVar5[0x7c] = piVar9;
  uStack_8._0_1_ = 0xc;
  puVar10 = (uint *)FUN_01674e20(4);
  if (puVar10 == (uint *)0x0) {
    puVar10 = (uint *)0x0;
    param_2 = (undefined4 *)0x0;
  }
  else {
    param_2 = (undefined4 *)0x41800000;
    *puVar10 = (uint)puVar10 ^ 0x41800000;
  }
  puVar5[0x7d] = puVar10;
  uStack_8._0_1_ = 0xd;
  puVar10 = (uint *)FUN_01674e20(4);
  if (puVar10 == (uint *)0x0) {
    puVar10 = (uint *)0x0;
    param_2 = (undefined4 *)0x0;
  }
  else {
    param_2 = (undefined4 *)0x3f800000;
    *puVar10 = (uint)puVar10 ^ 0x3f800000;
  }
  puVar5[0x7e] = puVar10;
  uStack_8._0_1_ = 0xe;
  puVar10 = (uint *)FUN_01674e20(4);
  if (puVar10 == (uint *)0x0) {
    puVar10 = (uint *)0x0;
    param_2 = (undefined4 *)0x0;
  }
  else {
    param_2 = (undefined4 *)0x42c80000;
    *puVar10 = (uint)puVar10 ^ 0x42c80000;
  }
  puVar5[0x7f] = puVar10;
  uStack_8._0_1_ = 0xf;
  piVar9 = (int *)FUN_01674e20(4);
  if (piVar9 == (int *)0x0) {
    piVar9 = (int *)0x0;
    param_2 = (undefined4 *)0x0;
  }
  else {
    param_2 = (undefined4 *)0x42c80000;
    *piVar9 = 0x42c80000 - (int)piVar9;
  }
  puVar5[0x80] = piVar9;
  uStack_8._0_1_ = 0x10;
  puVar5[0x81] = puVar5 + 0x81;
  puVar10 = (uint *)FUN_01674e20(4);
  if (puVar10 == (uint *)0x0) {
    puVar10 = (uint *)0x0;
    param_2 = (undefined4 *)0x0;
  }
  else {
    param_2 = (undefined4 *)0x42480000;
    *puVar10 = (uint)puVar10 ^ 0x42480000;
  }
  puVar5[0x82] = puVar10;
  uStack_8._0_1_ = 0x11;
  *(undefined *)(puVar5 + 0x83) = 1;
  piVar9 = (int *)FUN_01674e20(4);
  if (piVar9 == (int *)0x0) {
    piVar9 = (int *)0x0;
    param_2 = (undefined4 *)0x0;
  }
  else {
    param_2 = (undefined4 *)0x40e66666;
    *piVar9 = 0x40e66666 - (int)piVar9;
  }
  puVar5[0x84] = piVar9;
  uStack_8._0_1_ = 0x12;
  puVar10 = (uint *)FUN_01674e20(4);
  if (puVar10 == (uint *)0x0) {
    puVar10 = (uint *)0x0;
    param_2 = (undefined4 *)0x0;
  }
  else {
    param_2 = (undefined4 *)0x42b20000;
    *puVar10 = (uint)puVar10 ^ 0x42b20000;
  }
  puVar5[0x85] = puVar10;
  uStack_8._0_1_ = 0x13;
  iVar11 = FUN_01674e20(4);
  if (iVar11 == 0) {
    iVar11 = 0;
  }
  else {
    *(int *)iVar11 = iVar11;
  }
  param_2 = (undefined4 *)0x0;
  puVar5[0x86] = iVar11;
  uStack_8._0_1_ = 0x14;
  bVar6 = FUN_01679ce0();
  bVar14 = 1;
  if ((bVar6 & 0x7f) != 0) {
    bVar14 = bVar6 & 0x7f;
  }
  *(byte *)(puVar5 + 0x87) = -bVar14;
  bVar6 = FUN_01679ce0();
  bVar14 = 1;
  if ((bVar6 & 0x7f) != 0) {
    bVar14 = bVar6 & 0x7f;
  }
  *(byte *)((int)puVar5 + 0x21d) = -bVar14;
  bVar6 = FUN_01679ce0();
  bVar14 = 1;
  if ((bVar6 & 0x7f) != 0) {
    bVar14 = bVar6 & 0x7f;
  }
  *(byte *)((int)puVar5 + 0x21e) = -bVar14;
  bVar6 = FUN_01679ce0();
  bVar14 = 1;
  if ((bVar6 & 0x7f) != 0) {
    bVar14 = bVar6 & 0x7f;
  }
  *(byte *)((int)puVar5 + 0x21f) = -bVar14;
  bVar6 = FUN_01679ce0();
  bVar14 = 1;
  if ((bVar6 & 0x7f) != 0) {
    bVar14 = bVar6 & 0x7f;
  }
  *(byte *)(puVar5 + 0x88) = -bVar14;
  bVar6 = FUN_01679ce0();
  bVar14 = 1;
  if ((bVar6 & 0x7f) != 0) {
    bVar14 = bVar6 & 0x7f;
  }
  *(byte *)((int)puVar5 + 0x221) = -bVar14;
  bVar6 = FUN_01679ce0();
  bVar14 = 1;
  if ((bVar6 & 0x7f) != 0) {
    bVar14 = bVar6 & 0x7f;
  }
  *(byte *)((int)puVar5 + 0x222) = -bVar14;
  bVar6 = FUN_01679ce0();
  bVar14 = 1;
  if ((bVar6 & 0x7f) != 0) {
    bVar14 = bVar6 & 0x7f;
  }
  *(byte *)((int)puVar5 + 0x223) = -bVar14;
  bVar6 = FUN_01679ce0();
  bVar14 = 1;
  if ((bVar6 & 0x7f) != 0) {
    bVar14 = bVar6 & 0x7f;
  }
  *(byte *)(puVar5 + 0x89) = -bVar14;
  bVar6 = FUN_01679ce0();
  bVar14 = 1;
  if ((bVar6 & 0x7f) != 0) {
    bVar14 = bVar6 & 0x7f;
  }
  *(byte *)((int)puVar5 + 0x225) = bVar14;
  puVar5[0x8a] = 0;
  piVar9 = (int *)FUN_01674e20(4);
  if (piVar9 == (int *)0x0) {
    piVar9 = (int *)0x0;
    param_2 = (undefined4 *)0x0;
  }
  else {
    param_2 = (undefined4 *)((uint)piVar9 & 0xffffff00);
    *piVar9 = (int)param_2 + (int)piVar9;
  }
  puVar5[0x8b] = piVar9;
  uStack_8._0_1_ = 0x15;
  piVar9 = (int *)FUN_01674e20(4);
  if (piVar9 == (int *)0x0) {
    piVar9 = (int *)0x0;
    param_2 = (undefined4 *)0x0;
  }
  else {
    param_2 = (undefined4 *)CONCAT31((int3)((uint)piVar9 >> 8),1);
    *piVar9 = (int)param_2 + (int)piVar9;
  }
  puVar5[0x8c] = piVar9;
  puVar5[0x8d] = 0;
  puVar5[0x8e] = 0x10101;
  uStack_8._0_1_ = 0x16;
  puVar5[0x8f] = 0;
  puVar5[0x90] = 0;
  puVar5[0x91] = 0;
  uVar12 = FUN_01679ce0();
  uVar17 = 1;
  if (uVar12 != 0) {
    uVar17 = uVar12;
  }
  puVar5[0x92] = uVar17;
  puVar5[0x93] = uVar17 ^ 0x22;
  puVar5[0x94] = 0;
  puVar5[0x95] = 0;
  puVar5[0x96] = 0;
  puVar5[0x97] = 0;
  puVar5[0x98] = 0x42c80000;
  puVar5[0x99] = 0x42c80000;
  puVar5[0x9a] = 0;
  puVar5[0x9b] = 0;
  puVar5[0x9c] = 0;
  *(undefined *)(puVar5 + 0x9d) = 0;
  puVar5[0xa2] = 0;
  puVar5[0xa3] = 0xf;
  *(undefined *)(puVar5 + 0x9e) = 0;
  *(undefined2 *)(puVar5 + 0xa4) = 0;
  *(undefined *)((int)puVar5 + 0x292) = 0;
  *(undefined8 *)(puVar5 + 0xa6) = 0;
  puVar5[0xa8] = 0;
  puVar5[0xa9] = 0;
  *(undefined *)(puVar5 + 0xaa) = 1;
  puVar5[0xaf] = 0;
  puVar5[0xb0] = 0x3f800000;
  puVar5[0xb1] = 0;
  puVar5[0xb2] = 0;
  puVar5[0xb3] = 0;
  puVar5[0xb4] = 0;
  puVar5[0xb5] = 0;
  puVar5[0xb6] = 0;
  puVar5[0xb7] = 0;
  puVar5[0xb8] = 0x700;
  *(undefined2 *)(puVar5 + 0xb9) = 0;
  *(undefined *)((int)puVar5 + 0x2e6) = 0;
  puVar5[0xba] = 0;
  puVar5[0xbb] = 0;
  puVar5[0xbc] = 0;
  puVar5[0xbd] = 0;
  puVar5[0xbe] = 0;
  puVar5[0xbf] = 0;
  puVar5[0xc0] = 0;
  puVar5[0xc1] = 0;
  puVar5[0xc2] = 0;
  puVar5[199] = 0;
  puVar5[200] = 0xf;
  *(undefined *)(puVar5 + 0xc3) = 0;
  puVar5[0xc9] = 0x3f800000;
  puVar5[0xca] = 0x3f800000;
  puVar5[0xcb] = 0x3f800000;
  uStack_8._0_1_ = 0x1c;
  puVar5[0xcc] = 0x3f800000;
  puVar5[0xcd] = 0;
  *(undefined *)(puVar5 + 0xce) = 1;
  puVar5[0xcf] = 0;
  FUN_016f4053(puVar5 + 0xd0,8,7,FUN_005502b0,FUN_00550b30);
  uStack_8._0_1_ = 0x1d;
  FUN_016f4053(puVar5 + 0xde,8,0x10,FUN_005502b0,FUN_00550b30);
  puVar5[0xfe] = 0;
  puVar5[0xff] = 0;
  uStack_8._0_1_ = 0x1f;
  FUN_00d7edb0();
  uStack_8._0_1_ = 0x20;
  FUN_00d7edb0();
  puVar5[0x192] = 0;
  puVar5[0x193] = 0;
  puVar5[0x194] = 0;
  puVar5[0x195] = 0;
  puVar5[0x196] = 0;
  puVar5[0x197] = 0;
  *(undefined *)(puVar5 + 0x198) = 0;
  param_2 = (undefined4 *)0xb;
  ppuVar13 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2)
  ;
  ppuVar15 = ppuVar13 + -1;
  if (ppuVar13 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar15 = ppuVar13;
  }
  puVar5[0x199] = *ppuVar15;
  puVar5[0x19a] = 0;
  puVar5[0x19b] = 0x3f800000;
  puVar5[0x19c] = 0;
  puVar5[0x19d] = 0;
  *(undefined *)(puVar5 + 0x19e) = 0;
  param_2 = (undefined4 *)0xb;
  ppuVar13 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2)
  ;
  ppuVar15 = ppuVar13 + -1;
  if (ppuVar13 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar15 = ppuVar13;
  }
  puVar5[0x19f] = *ppuVar15;
  puVar5[0x1a0] = 0;
  puVar5[0x1a1] = 0x3f800000;
  puVar5[0x1a2] = 0;
  puVar5[0x1a3] = 0;
  *(undefined *)(puVar5 + 0x1a4) = 0;
  param_2 = (undefined4 *)0xb;
  ppuVar13 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2)
  ;
  ppuVar15 = ppuVar13 + -1;
  if (ppuVar13 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar15 = ppuVar13;
  }
  puVar5[0x1a5] = *ppuVar15;
  puVar5[0x1a6] = 0;
  puVar5[0x1a7] = 0x3f800000;
  puVar5[0x1a8] = 0;
  puVar5[0x1a9] = 0;
  *(undefined *)(puVar5 + 0x1aa) = 0;
  param_2 = (undefined4 *)0xb;
  ppuVar13 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2)
  ;
  ppuVar15 = ppuVar13 + -1;
  if (ppuVar13 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar15 = ppuVar13;
  }
  puVar5[0x1ab] = *ppuVar15;
  puVar5[0x1ac] = 0;
  puVar5[0x1ad] = 0x3f800000;
  puVar5[0x1ae] = 0;
  puVar5[0x1af] = 0;
  *(undefined *)(puVar5 + 0x1b0) = 0;
  param_2 = (undefined4 *)0xb;
  ppuVar13 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2)
  ;
  ppuVar15 = ppuVar13 + -1;
  if (ppuVar13 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar15 = ppuVar13;
  }
  puVar5[0x1b1] = *ppuVar15;
  puVar5[0x1b2] = 0;
  puVar5[0x1b3] = 0x3f800000;
  puVar5[0x1b4] = 0;
  puVar5[0x1b5] = 0;
  puVar5[0x1b6] = 0;
  puVar5[0x1b7] = 0;
  puVar5[0x1b8] = 0;
  puVar5[0x1b9] = 0;
  puVar5[0x1ba] = 0;
  puVar5[0x1bb] = 0;
  puVar5[0x1bc] = 0;
  puVar5[0x1bd] = 0;
  puVar5[0x1be] = 0;
  puVar5[0x1bf] = 0;
  puVar5[0x1c0] = 5;
  puVar5[0x1c1] = 5;
  puVar5[0x1c2] = 0;
  puVar5[0x1c3] = 0;
  puVar5[0x1c4] = 0;
  puVar5[0x1c5] = 0;
  puVar5[0x1c6] = 0;
  puVar5[0x1c7] = 0;
  puVar5[0x1c8] = 0;
  puVar5[0x1c9] = 0;
  puVar5[0x1ca] = 0;
  puVar5[0x1cb] = 0;
  puVar5[0x1cc] = 0;
  puVar5[0x1cd] = 0;
  puVar5[0x1ce] = 0;
  puVar5[0x1cf] = 0;
  puVar5[0x1d0] = 0;
  puVar5[0x1d1] = 0;
  puVar5[0x1d2] = 0;
  puVar5[0x1d3] = 0;
  puVar5[0x1d4] = 0;
  puVar5[0x1d5] = 0;
  puVar5[0x1d6] = 0;
  puVar5[0x1d7] = 0;
  puVar5[0x1d8] = 0;
  puVar5[0x1d9] = 0;
  puVar5[0x1da] = 0;
  puVar5[0x1db] = 0;
  puVar5[0x1dc] = 0;
  puVar5[0x1dd] = 0;
  puVar5[0x1de] = 0;
  puVar5[0x1df] = 0;
  puVar5[0x1e0] = 0;
  puVar5[0x1e1] = 0;
  puVar5[0x1e2] = 0;
  *(undefined *)(puVar5 + 0x1e3) = 0;
  param_2 = (undefined4 *)0xb;
  ppuVar13 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2)
  ;
  param_2 = (undefined4 *)0xb;
  ppuVar15 = ppuVar13 + -1;
  if (ppuVar13 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar15 = ppuVar13;
  }
  puVar5[0x1e4] = *ppuVar15;
  puVar5[0x1e5] = 0;
  puVar5[0x1e6] = 0x3f800000;
  puVar5[0x1e7] = 0;
  puVar5[0x1e8] = 0;
  *(undefined *)(puVar5 + 0x1e9) = 0;
  ppuVar13 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2)
  ;
  param_2 = (undefined4 *)0xb;
  ppuVar15 = ppuVar13 + -1;
  if (ppuVar13 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar15 = ppuVar13;
  }
  puVar5[0x1ea] = *ppuVar15;
  puVar5[0x1eb] = 0;
  puVar5[0x1ec] = 0x3f800000;
  puVar5[0x1ed] = 0;
  puVar5[0x1ee] = 0;
  *(undefined *)(puVar5 + 0x1ef) = 0;
  ppuVar13 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2)
  ;
  ppuVar15 = ppuVar13 + -1;
  if (ppuVar13 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar15 = ppuVar13;
  }
  puVar5[0x1f0] = *ppuVar15;
  puVar5[0x1f1] = 0;
  puVar5[0x1f2] = 0x3f800000;
  puVar5[499] = 0;
  puVar5[500] = 0;
  puVar5[0x1f5] = 0;
  puVar5[0x1f6] = 0;
  uStack_8._0_1_ = 0x52;
  uStack_20 = 0;
  uStack_1c = 0xf;
  apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
  FUN_005542c0("Humanoid",8);
  piVar9 = (int *)puVar5[10];
  uStack_8 = CONCAT31(uStack_8._1_3_,0x53);
  ppppuVar16 = apppuStack_30;
  if (0xf < uStack_1c) {
    ppppuVar16 = (undefined4 ****)apppuStack_30[0];
  }
  piVar2 = piVar9 + 4;
  if (0xf < (uint)piVar9[5]) {
    piVar9 = (int *)*piVar9;
  }
  cVar7 = FUN_0055c360(piVar9,*piVar2,ppppuVar16,uStack_20);
  param_2._3_1_ = cVar7;
  FUN_008a6520(apppuStack_30);
  if (param_2._3_1_ == '\0') {
    cVar7 = FUN_00fa0fb0(puVar5[10],puVar5,0);
    *(bool *)(puVar5 + 0xa4) = cVar7 == '\0';
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x52);
  if (0xf < uStack_1c) {
    uVar17 = uStack_1c + 1;
    ppppuVar16 = (undefined4 ****)apppuStack_30[0];
    if (0xfff < uVar17) {
      ppppuVar16 = (undefined4 ****)apppuStack_30[0][-1];
      uVar17 = uStack_1c + 0x24;
      if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar16))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar16,uVar17);
  }
  if (DAT_01f754a1 != '\0') {
    FUN_016774b0(DAT_01f754a1,"Humanoid created - %p",puVar5);
  }
  uVar4 = _UNK_019399ec;
  uVar3 = _UNK_019399e8;
  uVar8 = _UNK_019399e4;
  *(undefined4 *)((int)puVar5 + 0x2a9) = _DAT_019399e0;
  *(undefined4 *)((int)puVar5 + 0x2ad) = uVar8;
  *(undefined4 *)((int)puVar5 + 0x2b1) = uVar3;
  *(undefined4 *)((int)puVar5 + 0x2b5) = uVar4;
  *(undefined *)((int)puVar5 + 0x2b9) = 1;
  if (DAT_01d64a48 != '\0') {
    puVar5[0x95] = 2;
  }
  if ((DAT_01d64a98 == '\0') && (cVar7 = FUN_00f94340(), cVar7 == '\0')) {
    ExceptionList = pvStack_10;
    return puVar5;
  }
  puVar5[0x55] = 4;
  ExceptionList = pvStack_10;
  return puVar5;
}



/* FUNCTION 18269 ; VA 0x009a2f90 ; FUN_009a2f90 */

undefined4 * __fastcall FUN_009a2f90(undefined4 *param_1)

{
  float fVar1;
  float fVar2;
  float fVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  float *pfVar9;
  int iVar10;
  ulonglong uVar11;
  undefined8 uVar12;
  undefined auStack_80 [48];
  undefined auStack_50 [44];
  float fStack_24;
  ulonglong uStack_20;
  undefined8 uStack_14;
  undefined8 uStack_c;
  
  uStack_c = (ulonglong)DAT_018ce2f4;
  uStack_14 = (ulonglong)(uint)uStack_14;
  uStack_20 = 0;
  puVar8 = (undefined4 *)FUN_00d6a420(0);
  fStack_24 = 0.0;
  uVar4 = puVar8[1];
  uVar5 = puVar8[2];
  uVar6 = puVar8[3];
  *param_1 = *puVar8;
  param_1[1] = uVar4;
  param_1[2] = uVar5;
  param_1[3] = uVar6;
  uVar4 = puVar8[5];
  uVar5 = puVar8[6];
  uVar6 = puVar8[7];
  param_1[4] = puVar8[4];
  param_1[5] = uVar4;
  param_1[6] = uVar5;
  param_1[7] = uVar6;
  uVar4 = puVar8[8];
  *(ulonglong *)(param_1 + 9) = CONCAT44((int)uStack_c,DAT_018ce2f8);
  uVar11 = (ulonglong)DAT_018f7864;
  param_1[8] = uVar4;
  param_1[0xb] = uStack_14._4_4_;
  uStack_14 = uVar11;
  puVar8 = (undefined4 *)FUN_00d6a420(3);
  uVar4 = puVar8[1];
  uVar5 = puVar8[2];
  uVar6 = puVar8[3];
  param_1[0xc] = *puVar8;
  param_1[0xd] = uVar4;
  param_1[0xe] = uVar5;
  param_1[0xf] = uVar6;
  uVar4 = puVar8[5];
  uVar5 = puVar8[6];
  uVar6 = puVar8[7];
  param_1[0x10] = puVar8[4];
  param_1[0x11] = uVar4;
  param_1[0x12] = uVar5;
  param_1[0x13] = uVar6;
  param_1[0x14] = puVar8[8];
  *(ulonglong *)(param_1 + 0x15) = CONCAT44((int)uStack_c,(uint)uStack_14);
  param_1[0x17] = fStack_24;
  fStack_24 = 0.0;
  puVar8 = (undefined4 *)FUN_00d6a420(0);
  uVar4 = puVar8[1];
  uVar5 = puVar8[2];
  uVar6 = puVar8[3];
  param_1[0x18] = *puVar8;
  param_1[0x19] = uVar4;
  param_1[0x1a] = uVar5;
  param_1[0x1b] = uVar6;
  uVar4 = puVar8[5];
  uVar5 = puVar8[6];
  uVar6 = puVar8[7];
  param_1[0x1c] = puVar8[4];
  param_1[0x1d] = uVar4;
  param_1[0x1e] = uVar5;
  param_1[0x1f] = uVar6;
  uVar12 = CONCAT44((int)uStack_14,DAT_018ce2f8);
  param_1[0x20] = puVar8[8];
  *(undefined8 *)(param_1 + 0x21) = uVar12;
  param_1[0x23] = fStack_24;
  fStack_24 = 0.0;
  puVar8 = (undefined4 *)FUN_00d6a420(3);
  uVar4 = puVar8[1];
  uVar5 = puVar8[2];
  uVar6 = puVar8[3];
  param_1[0x24] = *puVar8;
  param_1[0x25] = uVar4;
  param_1[0x26] = uVar5;
  param_1[0x27] = uVar6;
  uVar4 = puVar8[5];
  uVar5 = puVar8[6];
  uVar6 = puVar8[7];
  param_1[0x28] = puVar8[4];
  param_1[0x29] = uVar4;
  param_1[0x2a] = uVar5;
  param_1[0x2b] = uVar6;
  param_1[0x2c] = puVar8[8];
  *(ulonglong *)(param_1 + 0x2d) = CONCAT44((int)uStack_14,(int)uStack_14);
  param_1[0x2f] = fStack_24;
  fStack_24 = 0.0;
  pfVar9 = (float *)FUN_00d6a420(1);
  uVar4 = DAT_018ce2f8;
  fVar1 = pfVar9[1];
  fVar2 = pfVar9[2];
  fVar3 = pfVar9[3];
  param_1[0x30] = *pfVar9;
  param_1[0x31] = fVar1;
  param_1[0x32] = fVar2;
  param_1[0x33] = fVar3;
  fVar1 = pfVar9[5];
  fVar2 = pfVar9[6];
  fVar3 = pfVar9[7];
  param_1[0x34] = pfVar9[4];
  param_1[0x35] = fVar1;
  param_1[0x36] = fVar2;
  param_1[0x37] = fVar3;
  param_1[0x38] = pfVar9[8];
  *(ulonglong *)(param_1 + 0x39) = CONCAT44(uVar4,(undefined4)uStack_20);
  param_1[0x3b] = fStack_24;
  fStack_24 = 0.0;
  puVar8 = (undefined4 *)FUN_00d6a420(0);
  uVar4 = puVar8[1];
  uVar5 = puVar8[2];
  uVar6 = puVar8[3];
  param_1[0x3c] = *puVar8;
  param_1[0x3d] = uVar4;
  param_1[0x3e] = uVar5;
  param_1[0x3f] = uVar6;
  uVar4 = puVar8[5];
  uVar5 = puVar8[6];
  uVar6 = puVar8[7];
  param_1[0x40] = puVar8[4];
  param_1[0x41] = uVar4;
  param_1[0x42] = uVar5;
  param_1[0x43] = uVar6;
  uVar12 = CONCAT44((int)uStack_c,DAT_018f7860);
  param_1[0x44] = puVar8[8];
  *(undefined8 *)(param_1 + 0x45) = uVar12;
  param_1[0x47] = fStack_24;
  fStack_24 = 0.0;
  puVar8 = (undefined4 *)FUN_00d6a420(3);
  uVar4 = puVar8[1];
  uVar5 = puVar8[2];
  uVar6 = puVar8[3];
  param_1[0x48] = *puVar8;
  param_1[0x49] = uVar4;
  param_1[0x4a] = uVar5;
  param_1[0x4b] = uVar6;
  uVar4 = puVar8[5];
  uVar5 = puVar8[6];
  uVar6 = puVar8[7];
  param_1[0x4c] = puVar8[4];
  param_1[0x4d] = uVar4;
  param_1[0x4e] = uVar5;
  param_1[0x4f] = uVar6;
  param_1[0x50] = puVar8[8];
  *(ulonglong *)(param_1 + 0x51) = CONCAT44((int)uStack_c,(int)uStack_c);
  param_1[0x53] = fStack_24;
  fStack_24 = 0.0;
  puVar8 = (undefined4 *)FUN_00d6a420(0);
  uVar7 = DAT_018ce2f8;
  uVar4 = puVar8[1];
  uVar5 = puVar8[2];
  uVar6 = puVar8[3];
  param_1[0x54] = *puVar8;
  param_1[0x55] = uVar4;
  param_1[0x56] = uVar5;
  param_1[0x57] = uVar6;
  uVar4 = puVar8[5];
  uVar5 = puVar8[6];
  uVar6 = puVar8[7];
  param_1[0x58] = puVar8[4];
  param_1[0x59] = uVar4;
  param_1[0x5a] = uVar5;
  param_1[0x5b] = uVar6;
  param_1[0x5c] = puVar8[8];
  *(ulonglong *)(param_1 + 0x5d) = CONCAT44(uVar7,(int)uStack_c);
  param_1[0x5f] = fStack_24;
  fStack_24 = 0.0;
  puVar8 = (undefined4 *)FUN_00d6a420(3);
  uVar7 = DAT_018ce2f8;
  uVar4 = puVar8[1];
  uVar5 = puVar8[2];
  uVar6 = puVar8[3];
  param_1[0x60] = *puVar8;
  param_1[0x61] = uVar4;
  param_1[0x62] = uVar5;
  param_1[99] = uVar6;
  uVar4 = puVar8[5];
  uVar5 = puVar8[6];
  uVar6 = puVar8[7];
  param_1[100] = puVar8[4];
  param_1[0x65] = uVar4;
  param_1[0x66] = uVar5;
  param_1[0x67] = uVar6;
  uVar12 = CONCAT44(uVar7,DAT_018f7860);
  param_1[0x68] = puVar8[8];
  *(undefined8 *)(param_1 + 0x69) = uVar12;
  param_1[0x6b] = fStack_24;
  fStack_24 = 0.0;
  puVar8 = (undefined4 *)FUN_00d6a420(1);
  uVar4 = puVar8[1];
  uVar5 = puVar8[2];
  uVar6 = puVar8[3];
  param_1[0x6c] = *puVar8;
  param_1[0x6d] = uVar4;
  param_1[0x6e] = uVar5;
  param_1[0x6f] = uVar6;
  uVar4 = puVar8[5];
  uVar5 = puVar8[6];
  uVar6 = puVar8[7];
  param_1[0x70] = puVar8[4];
  param_1[0x71] = uVar4;
  param_1[0x72] = uVar5;
  param_1[0x73] = uVar6;
  uVar12 = CONCAT44(DAT_018f7860,(int)uStack_20);
  param_1[0x74] = puVar8[8];
  *(undefined8 *)(param_1 + 0x75) = uVar12;
  param_1[0x77] = fStack_24;
  iVar10 = FUN_0071fcc0(auStack_80);
  fVar1 = *(float *)(iVar10 + 0x28);
  fVar2 = *(float *)(iVar10 + 0x24);
  fVar3 = *(float *)(iVar10 + 0x2c);
  uStack_20 = (ulonglong)
              (uint)((float)param_1[0x31] * fVar1 + (float)param_1[0x30] * fVar2 +
                     (float)param_1[0x32] * fVar3 + (float)param_1[0x39]);
  fStack_24 = (float)param_1[0x36] * fVar2 + (float)param_1[0x37] * fVar1 +
              (float)param_1[0x38] * fVar3 + (float)param_1[0x3b];
  uStack_c._4_4_ =
       (float)param_1[0x33] * fVar2 + (float)param_1[0x34] * fVar1 + (float)param_1[0x35] * fVar3 +
       (float)param_1[0x3a];
  puVar8 = (undefined4 *)FUN_01160c20(auStack_50,iVar10);
  uVar4 = puVar8[1];
  uVar5 = puVar8[2];
  uVar6 = puVar8[3];
  param_1[0x78] = *puVar8;
  param_1[0x79] = uVar4;
  param_1[0x7a] = uVar5;
  param_1[0x7b] = uVar6;
  uVar4 = puVar8[5];
  uVar5 = puVar8[6];
  uVar6 = puVar8[7];
  param_1[0x7c] = puVar8[4];
  param_1[0x7d] = uVar4;
  param_1[0x7e] = uVar5;
  param_1[0x7f] = uVar6;
  param_1[0x80] = puVar8[8];
  *(ulonglong *)(param_1 + 0x81) = CONCAT44(uStack_c._4_4_,(int)uStack_20);
  param_1[0x83] = fStack_24;
  return param_1;
}



/* FUNCTION 18270 ; VA 0x009a3370 ; FUN_009a3370 */

undefined4 * __thiscall FUN_009a3370(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  *param_1 = *param_2;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  uVar1 = param_2[5];
  uVar2 = param_2[6];
  uVar3 = param_2[7];
  param_1[4] = param_2[4];
  param_1[5] = uVar1;
  param_1[6] = uVar2;
  param_1[7] = uVar3;
  uVar1 = param_2[9];
  uVar2 = param_2[10];
  uVar3 = param_2[0xb];
  param_1[8] = param_2[8];
  param_1[9] = uVar1;
  param_1[10] = uVar2;
  param_1[0xb] = uVar3;
  *(undefined8 *)(param_1 + 0xc) = *(undefined8 *)(param_2 + 0xc);
  param_1[0xe] = param_2[0xe];
  *(undefined8 *)(param_1 + 0xf) = *(undefined8 *)(param_2 + 0xf);
  param_1[0x11] = param_2[0x11];
  return param_1;
}



/* FUNCTION 18271 ; VA 0x009a33c0 ; FUN_009a33c0 */

void * __fastcall FUN_009a33c0(int param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  byte bVar4;
  int iVar5;
  void *pvVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar2 = *(uint *)(param_1 + 0x14);
  uStack_8 = 0;
  pvVar6 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((uVar2 & 0xfffffff8) != 0) {
    bVar4 = ~(byte)((int)uVar2 >> 2);
    pvVar6 = (void *)CONCAT31((int3)((int)uVar2 >> 10),bVar4);
    ExceptionList = &pvStack_10;
    if ((bVar4 & 1) == 0) {
      iVar5 = param_1 + 8;
      if (((int)uVar2 >> 1 & 1U) == 0) {
        iVar5 = *(int *)(param_1 + 8);
      }
      ExceptionList = &pvStack_10;
      pvVar6 = (void *)(**(code **)((uVar2 & 0xfffffff8) + 8))(iVar5);
    }
    if (((int)uVar2 >> 1 & 1U) == 0) {
      pvVar6 = (void *)FUN_01674ee0(*(undefined4 *)(param_1 + 8));
    }
  }
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar5 = *piVar1;
    pvVar6 = (void *)*piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      pvVar6 = (void *)(**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        pvVar6 = (void *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar6;
}



/* FUNCTION 18272 ; VA 0x009a3470 ; FUN_009a3470 */

void __fastcall FUN_009a3470(int param_1)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 0x54);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x10))(piVar1 != (int *)(param_1 + 0x30));
    *(undefined4 *)(param_1 + 0x54) = 0;
  }
  piVar1 = *(int **)(param_1 + 0x2c);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x10))(piVar1 != (int *)(param_1 + 8));
    *(undefined4 *)(param_1 + 0x2c) = 0;
  }
  piVar1 = *(int **)(param_1 + 4);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
                    /* WARNING: Could not recover jumptable at 0x009a34c7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar1 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 18273 ; VA 0x009a34d0 ; FUN_009a34d0 */

void __fastcall FUN_009a34d0(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0x48);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),0xc);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 18274 ; VA 0x009a3530 ; FUN_009a3530 */

void __fastcall FUN_009a3530(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0x48);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 18275 ; VA 0x009a3590 ; FUN_009a3590 */

void __fastcall FUN_009a3590(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8d0();
  return;
}



/* FUNCTION 18276 ; VA 0x009a35f0 ; FUN_009a35f0 */

void __fastcall FUN_009a35f0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Humanoid>::vftable;
  uVar1 = FUN_0099be20(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18277 ; VA 0x009a3630 ; FUN_009a3630 */

void __fastcall FUN_009a3630(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_009a3790();
  return;
}



/* FUNCTION 18278 ; VA 0x009a3690 ; FUN_009a3690 */

void __fastcall FUN_009a3690(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00995940(*param_1,param_1[1],param_1[2]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18279 ; VA 0x009a36d0 ; FUN_009a36d0 */

void __fastcall FUN_009a36d0(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x50);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x58,param_1 + 0x58,2);
      }
    }
    *(undefined4 *)(param_1 + 0x50) = 0;
  }
  FUN_009a39a0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18280 ; VA 0x009a3730 ; FUN_009a3730 */

void __fastcall FUN_009a3730(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x48);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x50,param_1 + 0x50,2);
      }
    }
    *(undefined4 *)(param_1 + 0x48) = 0;
  }
  FUN_009a39a0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18281 ; VA 0x009a3790 ; FUN_009a3790 */

void __fastcall FUN_009a3790(int *param_1)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  int *piVar7;
  
  piVar5 = (int *)*param_1;
  piVar7 = (int *)*piVar5;
  *piVar5 = (int)piVar5;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar5 = (int *)*param_1;
  if (piVar7 != piVar5) {
    do {
      uVar1 = piVar7[7];
      piVar2 = (int *)*piVar7;
      if (0xf < uVar1) {
        iVar3 = piVar7[2];
        uVar6 = uVar1 + 1;
        iVar4 = iVar3;
        if (0xfff < uVar6) {
          iVar4 = *(int *)(iVar3 + -4);
          uVar6 = uVar1 + 0x24;
          if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar6);
      }
      piVar7[6] = 0;
      piVar7[7] = 0xf;
      *(undefined *)(piVar7 + 2) = 0;
      FUN_01674ea0(piVar7,0x2c);
      piVar5 = (int *)*param_1;
      piVar7 = piVar2;
    } while (piVar2 != piVar5);
  }
  FUN_01674ea0(piVar5,0x2c);
  return;
}



/* FUNCTION 18282 ; VA 0x009a3820 ; FUN_009a3820 */

void __fastcall FUN_009a3820(undefined4 *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    ExceptionList = &pvStack_10;
    if (*(char *)((int)param_1 + 9) != '\0') {
      ExceptionList = &pvStack_10;
      FUN_0099f5c0(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x24);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18283 ; VA 0x009a3880 ; FUN_009a3880 */

void __fastcall FUN_009a3880(undefined4 *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    ExceptionList = &pvStack_10;
    if (*(char *)((int)param_1 + 9) != '\0') {
      ExceptionList = &pvStack_10;
      FUN_0099f670(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x14);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18284 ; VA 0x009a38e0 ; FUN_009a38e0 */

void __fastcall FUN_009a38e0(undefined4 *param_1)

{
  FUN_009abb30();
  FUN_01674ea0(*param_1,0x14);
  return;
}



/* FUNCTION 18285 ; VA 0x009a3900 ; FUN_009a3900 */

void __fastcall FUN_009a3900(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x009a3957. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 18286 ; VA 0x009a3960 ; FUN_009a3960 */

void __fastcall FUN_009a3960(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x1c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_009a3900();
  return;
}



/* FUNCTION 18287 ; VA 0x009a39a0 ; FUN_009a39a0 */

void __fastcall FUN_009a39a0(int param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar2 = *(uint *)(param_1 + 0x28);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x30,param_1 + 0x30,2);
      }
    }
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  piVar3 = *(int **)(param_1 + 0x1c);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_009a3900();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18288 ; VA 0x009a3a30 ; FUN_009a3a30 */

void __fastcall FUN_009a3a30(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      ExceptionList = &pvStack_10;
      FUN_009af8d0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18289 ; VA 0x009a3ad0 ; FUN_009a3ad0 */

void __fastcall FUN_009a3ad0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      ExceptionList = &pvStack_10;
      FUN_009af930(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18290 ; VA 0x009a3b70 ; FUN_009a3b70 */

void __fastcall FUN_009a3b70(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 *puVar8;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar8 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar8;
        if (puVar8[9] != 0) {
          if (puVar8[6] != 0) {
            puVar2 = (undefined4 *)(puVar8[9] + puVar8[5] * 4);
            puVar6 = (undefined4 *)*puVar2;
            do {
              *puVar2 = *puVar6;
              FUN_01674ea0(puVar6,0xc);
              puVar8[6] = puVar8[6] + -1;
              puVar6 = (undefined4 *)*puVar2;
            } while (puVar6 != (undefined4 *)0x0);
          }
          uVar7 = puVar8[5] * 4 + 4;
          iVar3 = puVar8[9];
          iVar4 = iVar3;
          if (0xfff < uVar7) {
            iVar4 = *(int *)(iVar3 + -4);
            uVar7 = puVar8[5] * 4 + 0x27;
            if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_009a3c78;
          }
          FUN_01674ea0(iVar4,uVar7);
          puVar8[9] = 0;
          puVar8[8] = 0;
        }
        FUN_01674ea0(puVar8,0x28);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar8 = (undefined4 *)*puVar1;
      } while (puVar8 != (undefined4 *)0x0);
    }
    iVar3 = *(int *)(param_1 + 4) * 4;
    uVar7 = iVar3 + 4;
    iVar4 = *(int *)(param_1 + 0x14);
    iVar5 = iVar4;
    if (0xfff < uVar7) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar7 = iVar3 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
LAB_009a3c78:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar7);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 18291 ; VA 0x009a3c80 ; FUN_009a3c80 */

void __fastcall FUN_009a3c80(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_00617bc0();
    FUN_01674ea0(iVar1,0x1c);
  }
  return;
}



/* FUNCTION 18292 ; VA 0x009a3ca0 ; FUN_009a3ca0 */

void __fastcall FUN_009a3ca0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      ExceptionList = &pvStack_10;
      FUN_009af8d0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18293 ; VA 0x009a3cb0 ; FUN_009a3cb0 */

void __fastcall FUN_009a3cb0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      ExceptionList = &pvStack_10;
      FUN_009af930(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18294 ; VA 0x009a3cc0 ; FUN_009a3cc0 */

void __fastcall FUN_009a3cc0(int *param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint *puVar5;
  int iVar6;
  int iVar7;
  
  iVar6 = *param_1;
  if (iVar6 != 0) {
    iVar7 = param_1[1];
    if (iVar6 != iVar7) {
      puVar5 = (uint *)(iVar6 + 0x34);
      do {
        uVar4 = *puVar5;
        if (0xf < uVar4) {
          uVar1 = puVar5[-5];
          uVar3 = uVar4 + 1;
          uVar2 = uVar1;
          if (0xfff < uVar3) {
            uVar2 = *(uint *)(uVar1 - 4);
            uVar3 = uVar4 + 0x24;
            if (0x1f < (uVar1 - uVar2) - 4) goto LAB_009a3ddf;
          }
          FUN_01674ea0(uVar2,uVar3);
        }
        puVar5[-1] = 0;
        *puVar5 = 0xf;
        *(undefined *)(puVar5 + -5) = 0;
        uVar4 = puVar5[-6];
        if (0xf < uVar4) {
          uVar1 = puVar5[-0xb];
          uVar3 = uVar4 + 1;
          uVar2 = uVar1;
          if (0xfff < uVar3) {
            uVar2 = *(uint *)(uVar1 - 4);
            uVar3 = uVar4 + 0x24;
            if (0x1f < (uVar1 - uVar2) - 4) goto LAB_009a3ddf;
          }
          FUN_01674ea0(uVar2,uVar3);
        }
        puVar5[-7] = 0;
        iVar6 = iVar6 + 0x60;
        puVar5[-6] = 0xf;
        *(undefined *)(puVar5 + -0xb) = 0;
        puVar5 = puVar5 + 0x18;
      } while (iVar6 != iVar7);
      iVar6 = *param_1;
    }
    uVar4 = ((param_1[2] - iVar6) / 0x60) * 0x60;
    iVar7 = iVar6;
    if (0xfff < uVar4) {
      iVar7 = *(int *)(iVar6 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar6 - iVar7) - 4U) {
LAB_009a3ddf:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar4);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 18295 ; VA 0x009a3df0 ; FUN_009a3df0 */

void __fastcall FUN_009a3df0(int *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  iVar4 = *param_1;
  if (iVar4 != 0) {
    iVar5 = param_1[1];
    if (iVar4 != iVar5) {
      do {
        piVar1 = *(int **)(iVar4 + 0x48);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[1] + -1;
          piVar1[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar2 = piVar1[2] + -1;
            piVar1[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        iVar4 = iVar4 + 0x78;
      } while (iVar4 != iVar5);
      iVar4 = *param_1;
    }
    uVar3 = ((param_1[2] - iVar4) / 0x78) * 0x78;
    iVar5 = iVar4;
    if (0xfff < uVar3) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 18296 ; VA 0x009a3eb0 ; FUN_009a3eb0 */

void __fastcall FUN_009a3eb0(int *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  int *piVar5;
  
  piVar4 = (int *)*param_1;
  if (piVar4 != (int *)0x0) {
    piVar5 = (int *)param_1[1];
    if (piVar4 != piVar5) {
      do {
        piVar1 = (int *)*piVar4;
        if (piVar1 != (int *)0x0) {
          iVar2 = *piVar1;
          if (iVar2 != 0) {
            FUN_00617bc0();
            FUN_01674ea0(iVar2,0x1c);
          }
          FUN_01674ea0(piVar1,8);
        }
        piVar4 = piVar4 + 1;
      } while (piVar4 != piVar5);
      piVar4 = (int *)*param_1;
    }
    uVar3 = param_1[2] - (int)piVar4 & 0xfffffffc;
    piVar5 = piVar4;
    if (0xfff < uVar3) {
      piVar5 = (int *)piVar4[-1];
      uVar3 = uVar3 + 0x23;
      if (0x1f < (uint)((int)piVar4 + (-4 - (int)piVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar5,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 18297 ; VA 0x009a3f60 ; FUN_009a3f60 */

void FUN_009a3f60(void)

{
  FUN_0056d250();
  thunk_FUN_007c6140();
  FUN_009a3b70();
  return;
}



/* FUNCTION 18298 ; VA 0x009a3f80 ; FUN_009a3f80 */

void __fastcall FUN_009a3f80(int param_1)

{
  *(undefined ***)(param_1 + -8) = RBX::CameraSubject::vftable;
  *(undefined ***)(*(int *)(*(int *)(param_1 + -4) + 4) + -4 + param_1) =
       RBX::CameraSubject::vftable;
  return;
}



/* FUNCTION 18299 ; VA 0x009a3fa0 ; FUN_009a3fa0 */

void __fastcall FUN_009a3fa0(undefined4 *param_1)

{
  *param_1 = RBX::HitTestFilter::vftable;
  return;
}



/* FUNCTION 18300 ; VA 0x009a3fb0 ; FUN_009a3fb0 */

void __fastcall FUN_009a3fb0(undefined4 *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3110;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Humanoid::vftable;
  param_1[0x15] = RBX::Humanoid::vftable;
  param_1[0x17] = RBX::Humanoid::vftable;
  param_1[0x3f] = RBX::Humanoid::vftable;
  param_1[0x46] = RBX::Humanoid::vftable;
  param_1[0x4d] = RBX::Humanoid::vftable;
  param_1[0x53] = RBX::Humanoid::vftable;
  param_1[0x54] = RBX::Humanoid::vftable;
  *(undefined ***)(*(int *)(param_1[0x4e] + 4) + 0x138 + (int)param_1) = RBX::Humanoid::vftable;
  *(int *)(*(int *)(param_1[0x4e] + 4) + 0x134 + (int)param_1) =
       *(int *)(param_1[0x4e] + 4) + -0x6ac;
  if (DAT_01f754a1 != '\0') {
    FUN_016774b0(DAT_01f754a1,"Humanoid destroyed - %p",param_1);
  }
  piVar1 = (int *)param_1[0x1f6];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_0056d250();
  thunk_FUN_007c6140();
  FUN_009a3b70();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = param_1[0x1ce];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  uStack_8 = 1;
  FUN_01679490();
  iVar3 = param_1[0x1c5];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_016790b0();
  piVar1 = (int *)param_1[0x1c3];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0x1bf];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uStack_8 = 2;
  FUN_01679490();
  iVar3 = param_1[0x1bc];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 3;
  FUN_01679490();
  iVar3 = param_1[0x1bb];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 4;
  FUN_01679490();
  iVar3 = param_1[0x1ba];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 5;
  FUN_01679490();
  iVar3 = param_1[0x1b9];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 6;
  FUN_01679490();
  iVar3 = param_1[0x1b8];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  piVar1 = (int *)param_1[0x1b7];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_009a3ad0();
  FUN_009a3ad0();
  FUN_009a3ad0();
  FUN_009a3ad0();
  FUN_009a3a30();
  uStack_8 = 7;
  FUN_01679490();
  iVar3 = param_1[0x197];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 8;
  FUN_01679490();
  iVar3 = param_1[0x196];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 9;
  FUN_01679490();
  iVar3 = param_1[0x195];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 10;
  FUN_01679490();
  iVar3 = param_1[0x194];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  piVar1 = (int *)param_1[0x193];
  uStack_8 = 0xffffffff;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_008600a0();
  FUN_008600a0();
  piVar1 = (int *)param_1[0xff];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_016f32d1(param_1 + 0xde,8,0x10,FUN_00550b30);
  FUN_016f32d1(param_1 + 0xd0,8,7,FUN_00550b30);
  uVar2 = param_1[200];
  if (0xf < uVar2) {
    iVar3 = param_1[0xc3];
    uVar5 = uVar2 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_009a4916;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[199] = 0;
  param_1[200] = 0xf;
  *(undefined *)(param_1 + 0xc3) = 0;
  piVar1 = (int *)param_1[0xb7];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0xb5];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0xb3];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0xa9];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uVar2 = param_1[0xa3];
  if (0xf < uVar2) {
    iVar3 = param_1[0x9e];
    uVar5 = uVar2 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_009a4916;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0xa2] = 0;
  param_1[0xa3] = 0xf;
  *(undefined *)(param_1 + 0x9e) = 0;
  if (param_1[0x8c] != 0) {
    FUN_01674ea0(param_1[0x8c],4);
  }
  if (param_1[0x8b] != 0) {
    FUN_01674ea0(param_1[0x8b],4);
  }
  if (param_1[0x86] != 0) {
    FUN_01674ea0(param_1[0x86],4);
  }
  if (param_1[0x85] != 0) {
    FUN_01674ea0(param_1[0x85],4);
  }
  if (param_1[0x84] != 0) {
    FUN_01674ea0(param_1[0x84],4);
  }
  if (param_1[0x82] != 0) {
    FUN_01674ea0(param_1[0x82],4);
  }
  if (param_1[0x80] != 0) {
    FUN_01674ea0(param_1[0x80],4);
  }
  if (param_1[0x7f] != 0) {
    FUN_01674ea0(param_1[0x7f],4);
  }
  if (param_1[0x7e] != 0) {
    FUN_01674ea0(param_1[0x7e],4);
  }
  if (param_1[0x7d] != 0) {
    FUN_01674ea0(param_1[0x7d],4);
  }
  if (param_1[0x7c] != 0) {
    FUN_01674ea0(param_1[0x7c],4);
  }
  piVar1 = (int *)param_1[0x68];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0x66];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uVar2 = param_1[100];
  if (0xf < uVar2) {
    iVar3 = param_1[0x5f];
    uVar5 = uVar2 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_009a4916:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[99] = 0;
  param_1[100] = 0xf;
  *(undefined *)(param_1 + 0x5f) = 0;
  param_1[0x54] = RBX::IStepped::vftable;
  uStack_8 = 0xb;
  FUN_01679490();
  iVar3 = param_1[0x56];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  param_1[0x53] = RBX::IModelModifier::vftable;
  param_1[0x4d] = RBX::CameraSubject::vftable;
  *(undefined ***)(*(int *)(param_1[0x4e] + 4) + 0x138 + (int)param_1) = RBX::CameraSubject::vftable
  ;
  FUN_0115a710();
  uStack_8 = 0xc;
  FUN_016f32d1(param_1 + 0x59,4,2,FUN_005f60a0);
  param_1[0x15] = RBX::KernelJoint::vftable;
  param_1[0x17] = RBX::KernelJoint::vftable;
  param_1[0x3f] = RBX::Connector::vftable;
  FUN_00ca2b60();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18301 ; VA 0x009a4920 ; FUN_009a4920 */

void __fastcall FUN_009a4920(int param_1)

{
  *(undefined ***)(param_1 + -0x18) = RBX::CameraSubject::vftable;
  *(undefined ***)(*(int *)(*(int *)(param_1 + -0x14) + 4) + -0x14 + param_1) =
       RBX::CameraSubject::vftable;
  return;
}



/* FUNCTION 18302 ; VA 0x009a4940 ; FUN_009a4940 */

void __fastcall FUN_009a4940(undefined4 *param_1)

{
  *param_1 = RBX::IModelModifier::vftable;
  return;
}



/* FUNCTION 18303 ; VA 0x009a4950 ; FUN_009a4950 */

void __fastcall FUN_009a4950(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::IStepped::vftable;
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = param_1[2];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18304 ; VA 0x009a49b0 ; FUN_009a49b0 */

void __fastcall FUN_009a49b0(undefined4 *param_1)

{
  *param_1 = RBX::KernelJoint::vftable;
  param_1[2] = RBX::KernelJoint::vftable;
  param_1[0x2a] = RBX::Connector::vftable;
  FUN_00ca2b60();
  return;
}



/* FUNCTION 18305 ; VA 0x009a49d0 ; FUN_009a49d0 */

void __fastcall FUN_009a49d0(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016f32d1(param_1 + 8,4,2,FUN_005f60a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18306 ; VA 0x009a4a10 ; FUN_009a4a10 */

void __fastcall FUN_009a4a10(uint *param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_18);
  if (iStack_18 != 0) {
    FUN_00b04dd0();
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_14[1] + -1;
    piStack_14[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar4 = piStack_14[2] + -1;
      piStack_14[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[9];
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  uVar3 = *param_1;
  uStack_8 = 0;
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 2,param_1 + 2,2);
      }
    }
    *param_1 = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18307 ; VA 0x009a4ad0 ; FUN_009a4ad0 */

int * __thiscall FUN_009a4ad0(byte *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  char cVar3;
  uint uVar4;
  int *piVar5;
  int iVar6;
  undefined4 *puVar7;
  uint uVar8;
  int *piVar9;
  uint uVar10;
  undefined4 *puVar11;
  int aiStack_3c [5];
  uint uStack_28;
  uint uStack_24;
  int *piStack_20;
  undefined2 uStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3130;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_0055c740(param_1 + *param_1 + 1,param_2);
  uStack_14 = uVar4 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar11 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
    uVar10 = uStack_14;
    if (puVar11 == (undefined4 *)0x0) {
      puVar11 = (undefined4 *)0x0;
    }
    else {
      puVar11 = (undefined4 *)*puVar11;
    }
    for (; puVar11 != (undefined4 *)0x0; puVar11 = (undefined4 *)*puVar11) {
      if (uVar4 == puVar11[1]) {
        piVar5 = puVar11 + 2;
        if (0xf < (uint)puVar11[7]) {
          piVar5 = (int *)*piVar5;
        }
        puVar7 = param_2;
        if (0xf < (uint)param_2[5]) {
          puVar7 = (undefined4 *)*param_2;
        }
        cVar3 = FUN_0055c360(puVar7,param_2[4],piVar5,puVar11[6]);
        uVar10 = uStack_14;
        if (cVar3 != '\0') {
          if (puVar11 != (undefined4 *)0x0) {
            ExceptionList = pvStack_10;
            return puVar11 + 2;
          }
          break;
        }
      }
      else if ((uint)puVar11[1] % *(uint *)(param_1 + 4) != uVar10) break;
    }
  }
  piStack_20 = (int *)0x0;
  uStack_1c = 0;
  uStack_24 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(param_2);
  iStack_8._0_1_ = 1;
  FUN_009ade70();
  piVar5 = piStack_20;
  piStack_18 = piStack_20 + 2;
  FUN_0054ef60(aiStack_3c);
  piVar5[8] = 0;
  uStack_1c = CONCAT11(1,(undefined)uStack_1c);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_28) {
    uVar10 = uStack_28 + 1;
    iVar6 = aiStack_3c[0];
    if (0xfff < uVar10) {
      iVar6 = *(int *)(aiStack_3c[0] + -4);
      uVar10 = uStack_28 + 0x24;
      if (0x1f < (aiStack_3c[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar10);
  }
  uVar2 = *(uint *)(param_1 + 8);
  uVar10 = uVar2 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar10 = FUN_005c9310(uVar10);
    if (uVar10 <= *(uint *)(param_1 + 4)) {
      uVar10 = *(uint *)(param_1 + 4);
    }
    FUN_005c6680(uVar10);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar10) {
    uStack_14 = 1;
    uVar8 = uVar2 >> 1;
    if (uVar2 + (uVar2 >> 1) <= uVar10) {
      uVar8 = 1;
    }
    iVar6 = FUN_005c9310(uVar8 + uVar2);
    if (iVar6 != *(int *)(param_1 + 4)) {
      FUN_005c6680(iVar6);
      puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar11;
      while (puVar7 != (undefined4 *)0x0) {
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar7[1] % *(uint *)(param_1 + 4)) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar7[1] % *(uint *)(param_1 + 4)) * 4) == 0
           ) {
          *piVar1 = (int)puVar11;
          puVar11 = puVar7;
        }
        else {
          *puVar11 = *puVar7;
          *puVar7 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar7;
        }
        puVar7 = (undefined4 *)*puVar11;
      }
    }
  }
  piVar5[1] = uVar4;
  uVar4 = uVar4 % *(uint *)(param_1 + 4);
  piVar9 = *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  piVar1 = (int *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  if (piVar9 == (int *)0x0) {
    piVar9 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar9 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar9 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar5;
    }
    *piVar1 = (int)piVar9;
    *piVar5 = *piVar9;
  }
  else {
    *piVar5 = *piVar9;
    piVar9 = (int *)*piVar1;
  }
  *piVar9 = (int)piVar5;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_18;
}



/* FUNCTION 18308 ; VA 0x009a4d30 ; FUN_009a4d30 */

uint * __thiscall FUN_009a4d30(int param_1,uint *param_2)

{
  int *piVar1;
  uint *puVar2;
  undefined4 *puVar3;
  uint uVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  undefined4 *puVar8;
  uint uVar9;
  int *piVar10;
  uint uVar11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017d3150;
  pvStack_10 = ExceptionList;
  uVar6 = *param_2;
  uVar4 = (uVar6 >> 3) + uVar6;
  uVar11 = uVar4 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar8 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar11 * 4);
    if (puVar8 == (undefined4 *)0x0) {
      puVar8 = (undefined4 *)0x0;
    }
    else {
      puVar8 = (undefined4 *)*puVar8;
    }
    for (; puVar8 != (undefined4 *)0x0; puVar8 = (undefined4 *)*puVar8) {
      if (uVar4 == puVar8[1]) {
        if (uVar6 == puVar8[2]) {
          if (puVar8 != (undefined4 *)0x0) {
            return puVar8 + 2;
          }
          break;
        }
      }
      else if ((uint)puVar8[1] % *(uint *)(param_1 + 4) != uVar11) break;
    }
  }
  piVar10 = (int *)param_2[1];
  ExceptionList = &pvStack_10;
  if (piVar10 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar10[1] = piVar10[1] + 1;
    UNLOCK();
    piVar10 = (int *)param_2[1];
  }
  uVar6 = *param_2;
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  piVar5 = (int *)FUN_01674e20(0x14);
  piVar1 = piVar10 + 1;
  puVar2 = (uint *)(piVar5 + 2);
  *piVar5 = 0;
  piVar5[1] = 0;
  piVar5[3] = 0;
  piVar5[4] = 0;
  *puVar2 = 0;
  piVar5[3] = 0;
  if (piVar10 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *puVar2 = uVar6;
  piVar5[3] = (int)piVar10;
  piVar5[4] = 0;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (piVar10 != (int *)0x0) {
    LOCK();
    iVar7 = *piVar1;
    *piVar1 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      (**(code **)*piVar10)();
      LOCK();
      iVar7 = piVar10[2] + -1;
      piVar10[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar10 + 4))();
      }
    }
  }
  uVar11 = *(uint *)(param_1 + 8);
  uVar6 = uVar11 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar6 = FUN_005c9310(uVar6);
    if (uVar6 <= *(uint *)(param_1 + 4)) {
      uVar6 = *(uint *)(param_1 + 4);
    }
    FUN_005c6680(uVar6);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar6) {
    uVar9 = uVar11 >> 1;
    if (uVar11 + (uVar11 >> 1) <= uVar6) {
      uVar9 = 1;
    }
    iVar7 = FUN_005c9310(uVar9 + uVar11);
    if (iVar7 != *(int *)(param_1 + 4)) {
      FUN_005c6680(iVar7);
      puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar8;
      while (puVar3 != (undefined4 *)0x0) {
        uVar6 = (uint)puVar3[1] % *(uint *)(param_1 + 4);
        piVar10 = (int *)(*(int *)(param_1 + 0x14) + uVar6 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar6 * 4) == 0) {
          *piVar10 = (int)puVar8;
          puVar8 = puVar3;
        }
        else {
          *puVar8 = *puVar3;
          *puVar3 = *(undefined4 *)*piVar10;
          *(undefined4 **)*piVar10 = puVar3;
        }
        puVar3 = (undefined4 *)*puVar8;
      }
    }
  }
  piVar5[1] = uVar4;
  uVar4 = uVar4 % *(uint *)(param_1 + 4);
  piVar10 = *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  if (piVar10 == (int *)0x0) {
    piVar10 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar10 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar10 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar5;
    }
    *puVar8 = piVar10;
    *piVar5 = *piVar10;
  }
  else {
    *piVar5 = *piVar10;
    piVar10 = (int *)*puVar8;
  }
  *piVar10 = (int)piVar5;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return puVar2;
}



/* FUNCTION 18309 ; VA 0x009a4f80 ; FUN_009a4f80 */

uint * __thiscall FUN_009a4f80(int param_1,uint *param_2)

{
  int *piVar1;
  uint *puVar2;
  undefined4 *puVar3;
  uint uVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  undefined4 *puVar8;
  uint uVar9;
  int *piVar10;
  uint uVar11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017d3170;
  pvStack_10 = ExceptionList;
  uVar6 = *param_2;
  uVar4 = (uVar6 >> 3) + uVar6;
  uVar11 = uVar4 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar8 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar11 * 4);
    if (puVar8 == (undefined4 *)0x0) {
      puVar8 = (undefined4 *)0x0;
    }
    else {
      puVar8 = (undefined4 *)*puVar8;
    }
    for (; puVar8 != (undefined4 *)0x0; puVar8 = (undefined4 *)*puVar8) {
      if (uVar4 == puVar8[1]) {
        if (uVar6 == puVar8[2]) {
          if (puVar8 != (undefined4 *)0x0) {
            return puVar8 + 2;
          }
          break;
        }
      }
      else if ((uint)puVar8[1] % *(uint *)(param_1 + 4) != uVar11) break;
    }
  }
  piVar10 = (int *)param_2[1];
  ExceptionList = &pvStack_10;
  if (piVar10 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar10[1] = piVar10[1] + 1;
    UNLOCK();
    piVar10 = (int *)param_2[1];
  }
  uVar6 = *param_2;
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  piVar5 = (int *)FUN_01674e20(0x14);
  piVar1 = piVar10 + 1;
  puVar2 = (uint *)(piVar5 + 2);
  *piVar5 = 0;
  piVar5[1] = 0;
  piVar5[3] = 0;
  piVar5[4] = 0;
  *puVar2 = 0;
  piVar5[3] = 0;
  if (piVar10 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *puVar2 = uVar6;
  piVar5[3] = (int)piVar10;
  piVar5[4] = 0;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (piVar10 != (int *)0x0) {
    LOCK();
    iVar7 = *piVar1;
    *piVar1 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      (**(code **)*piVar10)();
      LOCK();
      iVar7 = piVar10[2] + -1;
      piVar10[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar10 + 4))();
      }
    }
  }
  uVar11 = *(uint *)(param_1 + 8);
  uVar6 = uVar11 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar6 = FUN_005c9310(uVar6);
    if (uVar6 <= *(uint *)(param_1 + 4)) {
      uVar6 = *(uint *)(param_1 + 4);
    }
    FUN_005c6680(uVar6);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar6) {
    uVar9 = uVar11 >> 1;
    if (uVar11 + (uVar11 >> 1) <= uVar6) {
      uVar9 = 1;
    }
    iVar7 = FUN_005c9310(uVar9 + uVar11);
    if (iVar7 != *(int *)(param_1 + 4)) {
      FUN_005c6680(iVar7);
      puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar8;
      while (puVar3 != (undefined4 *)0x0) {
        uVar6 = (uint)puVar3[1] % *(uint *)(param_1 + 4);
        piVar10 = (int *)(*(int *)(param_1 + 0x14) + uVar6 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar6 * 4) == 0) {
          *piVar10 = (int)puVar8;
          puVar8 = puVar3;
        }
        else {
          *puVar8 = *puVar3;
          *puVar3 = *(undefined4 *)*piVar10;
          *(undefined4 **)*piVar10 = puVar3;
        }
        puVar3 = (undefined4 *)*puVar8;
      }
    }
  }
  piVar5[1] = uVar4;
  uVar4 = uVar4 % *(uint *)(param_1 + 4);
  piVar10 = *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  if (piVar10 == (int *)0x0) {
    piVar10 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar10 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar10 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar5;
    }
    *puVar8 = piVar10;
    *piVar5 = *piVar10;
  }
  else {
    *piVar5 = *piVar10;
    piVar10 = (int *)*puVar8;
  }
  *piVar10 = (int)piVar5;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return puVar2;
}



/* FUNCTION 18310 ; VA 0x009a51d0 ; FUN_009a51d0 */

int * __thiscall FUN_009a51d0(int param_1,int *param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  uint uVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d3188;
  pvStack_10 = ExceptionList;
  uVar3 = param_2[1];
  iVar4 = *param_2;
  uVar8 = uVar3;
  if (((int)uVar3 < 1) && ((int)uVar3 < 0)) {
    uVar8 = ~uVar3;
  }
  uVar8 = (uVar8 >> 2) + uVar8 * 0x40 + iVar4 ^ uVar8;
  uVar9 = uVar8 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar5 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      puVar5 = (undefined4 *)*puVar5;
    }
    for (; puVar5 != (undefined4 *)0x0; puVar5 = (undefined4 *)*puVar5) {
      if (uVar8 == puVar5[1]) {
        if ((iVar4 == puVar5[2]) && (uVar3 == puVar5[3])) {
          return puVar5 + 2;
        }
      }
      else if ((uint)puVar5[1] % *(uint *)(param_1 + 4) != uVar9) break;
    }
  }
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar2 = (int *)FUN_01674e20(0x18);
  *piVar2 = 0;
  piVar2[1] = 0;
  piVar2[4] = 0;
  piVar2[5] = 0;
  piVar2[3] = uVar3;
  piVar2[2] = iVar4;
  if (piVar2 + 4 != (int *)0x0) {
    piVar2[4] = 0;
  }
  uVar9 = *(uint *)(param_1 + 8);
  uVar3 = uVar9 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar3 = FUN_005c9310(uVar3);
    if (uVar3 <= *(uint *)(param_1 + 4)) {
      uVar3 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar3);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar3) {
    uVar6 = uVar9 >> 1;
    if (uVar9 + (uVar9 >> 1) <= uVar3) {
      uVar6 = 1;
    }
    iVar4 = FUN_005c9310(uVar6 + uVar9);
    if (iVar4 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar4);
      puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)*puVar5;
      while (puVar1 != (undefined4 *)0x0) {
        uVar3 = (uint)puVar1[1] % *(uint *)(param_1 + 4);
        piVar7 = (int *)(*(int *)(param_1 + 0x14) + uVar3 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar3 * 4) == 0) {
          *piVar7 = (int)puVar5;
          puVar5 = puVar1;
        }
        else {
          *puVar5 = *puVar1;
          *puVar1 = *(undefined4 *)*piVar7;
          *(undefined4 **)*piVar7 = puVar1;
        }
        puVar1 = (undefined4 *)*puVar5;
      }
    }
  }
  piVar2[1] = uVar8;
  uVar8 = uVar8 % *(uint *)(param_1 + 4);
  piVar7 = *(int **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
  puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
  if (piVar7 == (int *)0x0) {
    piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar7 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar2;
    }
    *puVar5 = piVar7;
    *piVar2 = *piVar7;
  }
  else {
    *piVar2 = *piVar7;
    piVar7 = (int *)*puVar5;
  }
  *piVar7 = (int)piVar2;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piVar2 + 2;
}



/* FUNCTION 18311 ; VA 0x009a53e0 ; FUN_009a53e0 */

int FUN_009a53e0(int *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined *puVar6;
  int iVar7;
  int *in_stack_fffffe1c;
  undefined4 uVar8;
  undefined4 uVar9;
  int iStack_1d0;
  int iStack_1cc;
  undefined auStack_1c8 [200];
  int iStack_100;
  int iStack_fc;
  undefined auStack_f8 [200];
  int iStack_30;
  undefined auStack_28 [8];
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d3222;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piVar2 = (int *)*param_1;
  if ((piVar2 == (int *)param_1[1]) || (2 < (uint)((param_1[1] - (int)piVar2) / 0xd0))) {
    ExceptionList = &pvStack_10;
    iVar5 = FUN_01674e20(0xc);
    uStack_8._0_1_ = 1;
    iStack_18 = iVar5;
    if (iVar5 == 0) {
      iVar5 = 0;
    }
    else {
      FUN_00569550(1,&uStack_11);
    }
    uStack_8._0_1_ = 0;
    piStack_20 = (int *)0x0;
    piStack_1c = (int *)0x0;
    FUN_0055ba30(iVar5,param_2);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    puVar3 = (undefined4 *)*piStack_20;
    uVar8 = FUN_0088daf0();
    *puVar3 = uVar8;
    iStack_18 = FUN_005c9ef0();
    iVar5 = puVar3[1];
    if (iVar5 == iStack_18) {
      *(undefined *)(puVar3 + 2) = 0;
    }
    else {
      if (iVar5 != 0) {
        (**(code **)(iVar5 + 8))(puVar3 + 2);
      }
      *(undefined *)(puVar3 + 2) = 0;
      puVar3[1] = iStack_18;
    }
    piVar2 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
    }
    iVar5 = FUN_00948fa0(piStack_20,piStack_1c);
    if (piVar2 != (int *)0x0) {
      LOCK();
      piVar1 = piVar2 + 1;
      iVar4 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar4 = *piVar1;
        iVar5 = *piVar1;
        *piVar1 = iVar4 + -1;
        UNLOCK();
        if (iVar4 + -1 == 0) {
          iVar5 = (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  else {
    iStack_100 = *piVar2;
    iStack_fc = 0;
    iStack_18 = iStack_100;
    if ((undefined4 *)piVar2[1] == (undefined4 *)0x0) {
      iStack_fc = 0;
      ExceptionList = &pvStack_10;
    }
    else {
      in_stack_fffffe1c = piVar2 + 2;
      ExceptionList = &pvStack_10;
      (**(code **)piVar2[1])(in_stack_fffffe1c,auStack_f8);
      iStack_fc = piVar2[1];
    }
    iVar5 = iStack_100;
    uStack_8._0_1_ = 3;
    uVar8 = 0x9a5487;
    iVar4 = FUN_0088daf0();
    if (iVar5 == iVar4) {
      if ((param_1[1] - *param_1) / 0xd0 == 2) {
        FUN_0056a440(*param_1 + 0xd0);
        uStack_8._0_1_ = 7;
        iVar5 = FUN_0088cdc0();
        if (iStack_1d0 == iVar5) {
          iVar5 = FUN_0088cdc0();
          if (iStack_1d0 != iVar5) {
                    /* WARNING: Subroutine does not return */
            FUN_016757c0("Variant cast failed");
          }
          puVar6 = auStack_1c8;
          if (iStack_1cc == 0) {
            puVar6 = (undefined *)0x0;
          }
          uVar8 = 0x9a55bc;
          FUN_00557fc0(puVar6);
          uStack_8._0_1_ = 8;
          iVar5 = *(int *)(iStack_30 + 0xc);
          uVar9 = 0x9a55cb;
          iVar7 = FUN_00e643e0();
          iVar4 = 0;
          if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
              (uint)*(ushort *)(iVar7 + 0x1da)) {
            iVar4 = iStack_30;
          }
          if (iVar4 == 0) {
            iVar5 = FUN_01674e20(0xc);
            uStack_8._0_1_ = 9;
            iStack_18 = iVar5;
            if (iVar5 == 0) {
              iVar5 = 0;
            }
            else {
              FUN_00569550(1,&uStack_11);
            }
            uStack_8._0_1_ = 8;
            FUN_00557ff0(iVar5);
            uStack_8._0_1_ = 10;
            uVar8 = FUN_00605c60();
            uVar9 = 0x9a565f;
            FUN_00602370(uVar8);
            FUN_00557fc0(auStack_28);
            FUN_00948fa0(uVar9,uVar8);
            FUN_00550b30();
            FUN_00550b30();
          }
          else {
            FUN_00557fc0(&param_1);
            FUN_00948fa0(uVar8,uVar9);
            FUN_00550b30();
          }
        }
        else {
          iVar5 = FUN_01674e20(0xc);
          uStack_8._0_1_ = 0xb;
          iStack_18 = iVar5;
          if (iVar5 == 0) {
            iVar5 = 0;
          }
          else {
            FUN_00569550(1,&uStack_11);
          }
          uStack_8._0_1_ = 7;
          FUN_00557ff0(iVar5);
          uStack_8._0_1_ = 0xc;
          uVar8 = FUN_00605c60();
          uVar9 = 0x9a56d6;
          FUN_00602370(uVar8);
          FUN_00557fc0(auStack_28);
          FUN_00948fa0(uVar9,uVar8);
          FUN_00550b30();
        }
        uStack_8._0_1_ = 0xd;
        if (iStack_1cc != 0) {
          (**(code **)(iStack_1cc + 8))(auStack_1c8);
        }
      }
      else {
        FUN_00557fc0(&param_1);
        FUN_00948fa0(in_stack_fffffe1c,uVar8);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
      iVar5 = iStack_fc;
      if (iStack_fc != 0) {
        iVar5 = (**(code **)(iStack_fc + 8))(auStack_f8);
      }
    }
    else {
      iVar5 = FUN_01674e20(0xc);
      uStack_8._0_1_ = 4;
      iStack_18 = iVar5;
      if (iVar5 == 0) {
        iVar5 = 0;
      }
      else {
        FUN_00569550(1,&uStack_11);
      }
      uStack_8._0_1_ = 3;
      piStack_20 = (int *)0x0;
      piStack_1c = (int *)0x0;
      FUN_0055ba30(iVar5,param_2);
      piVar2 = piStack_20;
      uStack_8._0_1_ = 5;
      uStack_11 = 0;
      FUN_005e52b0(&uStack_11);
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piStack_1c[1] = piStack_1c[1] + 1;
        UNLOCK();
      }
      FUN_00948fa0(piVar2,piStack_1c);
      FUN_00550b30();
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      iVar5 = iStack_fc;
      if (iStack_fc != 0) {
        iVar5 = (**(code **)(iStack_fc + 8))(auStack_f8);
      }
    }
  }
  piVar2 = param_2;
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar4 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar5 = (**(code **)*param_2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar5 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 18312 ; VA 0x009a5870 ; FUN_009a5870 */

undefined4 * __thiscall FUN_009a5870(uint *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined *puVar5;
  undefined4 uVar6;
  undefined auStack_e4 [212];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d3253;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piVar2 = (int *)*param_2;
  if (piVar2 == (int *)param_2[1]) {
    if (*param_1 == 0) {
      ExceptionList = &pvStack_10;
      uVar6 = FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
      FUN_0054e5e0(uVar6);
    }
    ExceptionList = &pvStack_10;
    puVar3 = (undefined4 *)(**(code **)((*param_1 & 0xfffffffe) + 4))(param_1 + 2,0);
  }
  else {
    iVar1 = *piVar2;
    puVar3 = (undefined4 *)piVar2[1];
    ExceptionList = &pvStack_10;
    if (puVar3 != (undefined4 *)0x0) {
      ExceptionList = &pvStack_10;
      (*(code *)*puVar3)(piVar2 + 2,auStack_e4);
      puVar3 = (undefined4 *)piVar2[1];
    }
    uStack_8._0_1_ = 2;
    iVar4 = FUN_0088daf0();
    if (iVar1 == iVar4) {
      iVar4 = FUN_0088daf0();
      if (iVar1 != iVar4) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar5 = auStack_e4;
      if (puVar3 == (undefined4 *)0x0) {
        puVar5 = (undefined *)0x0;
      }
      FUN_008927d0(*puVar5);
    }
    else {
      if (*param_1 == 0) {
        uVar6 = FUN_0054fda0();
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
                    /* WARNING: Subroutine does not return */
        FUN_0054e5e0(uVar6);
      }
      (**(code **)((*param_1 & 0xfffffffe) + 4))(param_1 + 2,0);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (puVar3 != (undefined4 *)0x0) {
      puVar3 = (undefined4 *)(*(code *)puVar3[2])(auStack_e4);
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 1;
    iVar1 = *piVar2;
    puVar3 = (undefined4 *)*piVar2;
    *piVar2 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      puVar3 = (undefined4 *)(**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar1 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        puVar3 = (undefined4 *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar3;
}



/* FUNCTION 18313 ; VA 0x009a59e0 ; FUN_009a59e0 */

int __thiscall FUN_009a59e0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017d3270;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  uStack_40 = 0;
  uVar3 = param_1[10];
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    uStack_40 = uVar3;
    if ((uVar3 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = param_1 + 0xc;
      uStack_50 = 0x9a5a4a;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    else {
      uStack_38 = param_1[0xc];
      uStack_34 = param_1[0xd];
      uStack_30 = param_1[0xe];
      uStack_2c = param_1[0xf];
      uStack_28 = *(undefined8 *)(param_1 + 0x10);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8._0_1_ = 1;
  uVar3 = param_1[2];
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(param_1 + 4,&uStack_58,0);
    }
    else {
      uStack_58 = param_1[4];
      uStack_54 = param_1[5];
      uStack_50 = param_1[6];
      puStack_4c = (undefined4 *)param_1[7];
      uStack_48 = *(ulonglong *)(param_1 + 8);
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  iVar4 = FUN_009bec60(*param_1,param_1[1],param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      uStack_28 = CONCAT44(0x9a5b09,(undefined4)uStack_28);
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_28 = CONCAT44(0x9a5b18,(undefined4)uStack_28);
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 18314 ; VA 0x009a5b30 ; FUN_009a5b30 */

void __thiscall FUN_009a5b30(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*(int **)(param_1 + 0x24) == (int *)0x0) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_016ddc9c();
  }
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x24) + 8))(&param_2);
  if (0xf < in_stack_00000018) {
    uVar2 = in_stack_00000018 + 1;
    iVar1 = param_2;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_2 + -4);
      uVar2 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18315 ; VA 0x009a5bb0 ; FUN_009a5bb0 */

int __thiscall FUN_009a5bb0(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d3288;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*(int **)(param_1 + 0x24) != (int *)0x0) {
    ExceptionList = &pvStack_10;
    iVar4 = (**(code **)(**(int **)(param_1 + 0x24) + 8))(&param_2);
    piVar3 = param_3;
    if (param_3 != (int *)0x0) {
      LOCK();
      piVar1 = param_3 + 1;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)*param_3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar4 = (**(code **)(*piVar3 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return iVar4;
  }
  ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
  FUN_016ddc9c();
}



/* FUNCTION 18316 ; VA 0x009a5c30 ; FUN_009a5c30 */

int __thiscall FUN_009a5c30(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  pcVar3 = (code *)*param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  iVar4 = (*pcVar3)(param_3,param_4);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 18317 ; VA 0x009a5ce0 ; FUN_009a5ce0 */

int __thiscall
FUN_009a5ce0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b4ed0;
  pvStack_10 = ExceptionList;
  pcVar3 = (code *)*param_1;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_6 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  iVar4 = (*pcVar3)(param_3,param_4,param_5,param_6);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 18318 ; VA 0x009a5dd0 ; FUN_009a5dd0 */

/* WARNING: Removing unreachable block (ram,0x009a5e22) */
/* WARNING: Removing unreachable block (ram,0x009a5e32) */
/* WARNING: Removing unreachable block (ram,0x009a5e38) */

void * __thiscall FUN_009a5dd0(int *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d32b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 18319 ; VA 0x009a5ea6 ; Catch@009a5ea6 */

undefined * Catch_009a5ea6(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_009a5eb7;
}



/* FUNCTION 18320 ; VA 0x009a5ec9 ; FUN_009a5ec9 */

void FUN_009a5ec9(void)

{
  FUN_009a6980();
  return;
}



/* FUNCTION 18321 ; VA 0x009a5ed7 ; FUN_009a5ed7 */

void FUN_009a5ed7(void)

{
  FUN_009a6980();
  return;
}



/* FUNCTION 18322 ; VA 0x009a5ee2 ; FUN_009a5ee2 */

void FUN_009a5ee2(void)

{
  FUN_009a6980();
  return;
}



/* FUNCTION 18323 ; VA 0x009a5eed ; FUN_009a5eed */

void FUN_009a5eed(void)

{
  FUN_009a6980();
  return;
}



/* FUNCTION 18324 ; VA 0x009a5ef5 ; FUN_009a5ef5 */

void FUN_009a5ef5(void)

{
  FUN_009a6980();
  return;
}



/* FUNCTION 18325 ; VA 0x009a5efd ; FUN_009a5efd */

void FUN_009a5efd(void)

{
  FUN_009a6980();
  return;
}



/* FUNCTION 18326 ; VA 0x009a5f08 ; FUN_009a5f08 */

void FUN_009a5f08(void)

{
  FUN_009a6a60();
  return;
}



/* FUNCTION 18327 ; VA 0x009a5f10 ; FUN_009a5f10 */

void FUN_009a5f10(void)

{
  FUN_009a6a60();
  return;
}



/* FUNCTION 18328 ; VA 0x009a5f20 ; FUN_009a5f20 */

undefined4 __thiscall FUN_009a5f20(undefined4 param_1,byte param_2)

{
  FUN_009a34d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 18329 ; VA 0x009a5f50 ; FUN_009a5f50 */

int __thiscall FUN_009a5f50(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),1);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),0xc);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 18330 ; VA 0x009a5fa0 ; FUN_009a5fa0 */

int __thiscall FUN_009a5fa0(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),1);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 18331 ; VA 0x009a5ff0 ; FUN_009a5ff0 */

undefined4 __thiscall FUN_009a5ff0(undefined4 param_1,byte param_2)

{
  FUN_005c4ac0();
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 18332 ; VA 0x009a6020 ; FUN_009a6020 */

undefined4 __thiscall FUN_009a6020(undefined4 param_1,byte param_2)

{
  FUN_009a3530();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 18333 ; VA 0x009a6050 ; FUN_009a6050 */

int __thiscall FUN_009a6050(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),8);
  }
  FUN_009cb8d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 18334 ; VA 0x009a6090 ; FUN_009a6090 */

int __thiscall FUN_009a6090(int param_1,byte param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 18335 ; VA 0x009a6100 ; FUN_009a6100 */

undefined4 __thiscall FUN_009a6100(undefined4 param_1,byte param_2)

{
  FUN_009a3590();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 18336 ; VA 0x009a6130 ; FUN_009a6130 */

undefined4 __thiscall FUN_009a6130(undefined4 param_1,byte param_2)

{
  FUN_005c4ac0();
  FUN_009cb8d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 18337 ; VA 0x009a6160 ; FUN_009a6160 */

int __thiscall FUN_009a6160(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),8);
  }
  FUN_005c4ac0();
  FUN_009cb8d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 18338 ; VA 0x009a61a0 ; FUN_009a61a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_009a61a0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Humanoid::CollisionType>::vftable;
  _DAT_01ee3d88 = _DAT_01ee3d88 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 18339 ; VA 0x009a61d0 ; FUN_009a61d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_009a61d0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Humanoid::HumanoidDisplayDistanceType>::vftable;
  _DAT_01ee3d98 = _DAT_01ee3d98 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 18340 ; VA 0x009a6200 ; FUN_009a6200 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_009a6200(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Humanoid::HumanoidHealthDisplayType>::vftable;
  _DAT_01ee3da0 = _DAT_01ee3da0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 18341 ; VA 0x009a6230 ; FUN_009a6230 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_009a6230(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Humanoid::Limb>::vftable;
  _DAT_01ee3d70 = _DAT_01ee3d70 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 18342 ; VA 0x009a6260 ; FUN_009a6260 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_009a6260(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Humanoid::NameOcclusion>::vftable;
  _DAT_01ee3d90 = _DAT_01ee3d90 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 18343 ; VA 0x009a6290 ; FUN_009a6290 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_009a6290(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Humanoid::R15PartType>::vftable;
  _DAT_01ee3d78 = _DAT_01ee3d78 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 18344 ; VA 0x009a62c0 ; FUN_009a62c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_009a62c0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::HUMAN::StateType>::vftable;
  _DAT_01f1481c = _DAT_01f1481c + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 18345 ; VA 0x009a62f0 ; FUN_009a62f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_009a62f0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Humanoid::Status>::vftable;
  _DAT_01ee3d68 = _DAT_01ee3d68 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 18346 ; VA 0x009a6320 ; FUN_009a6320 */

undefined4 __thiscall FUN_009a6320(undefined4 param_1,byte param_2)

{
  FUN_009cba00();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 18347 ; VA 0x009a6350 ; FUN_009a6350 */

undefined4 * __thiscall FUN_009a6350(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::FilteredSelection<class_RBX::PartInstance>::vftable;
  param_1[0x16] = RBX::FilteredSelection<class_RBX::PartInstance>::vftable;
  if (param_1[0x17] != 0) {
    FUN_009e0a40(param_1 + 0x16);
  }
  iVar2 = param_1[0x19];
  if (iVar2 != 0) {
    uVar5 = param_1[0x1b] - iVar2 & 0xfffffffc;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    param_1[0x19] = 0;
    param_1[0x1a] = 0;
    param_1[0x1b] = 0;
  }
  piVar3 = (int *)param_1[0x18];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x70);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18348 ; VA 0x009a6440 ; FUN_009a6440 */

undefined4 * __thiscall FUN_009a6440(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::PartMaterial>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 18349 ; VA 0x009a6470 ; FUN_009a6470 */

undefined4 * __thiscall FUN_009a6470(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::PartInstance*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 18350 ; VA 0x009a64a0 ; FUN_009a64a0 */

undefined4 * __thiscall FUN_009a64a0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 18351 ; VA 0x009a64d0 ; FUN_009a64d0 */

undefined4 * __thiscall FUN_009a64d0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Humanoid::CollisionType>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 18352 ; VA 0x009a6500 ; FUN_009a6500 */

undefined4 * __thiscall FUN_009a6500(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<enum_RBX::Humanoid::HumanoidDisplayDistanceType>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 18353 ; VA 0x009a6530 ; FUN_009a6530 */

undefined4 * __thiscall FUN_009a6530(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Humanoid::HumanoidHealthDisplayType>
             ::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 18354 ; VA 0x009a6560 ; FUN_009a6560 */

undefined4 * __thiscall FUN_009a6560(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::HumanoidRigType>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 18355 ; VA 0x009a6590 ; FUN_009a6590 */

undefined4 * __thiscall FUN_009a6590(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Humanoid::NameOcclusion>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 18356 ; VA 0x009a65c0 ; FUN_009a65c0 */

undefined4 * __thiscall FUN_009a65c0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::PartMaterial>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 18357 ; VA 0x009a65f0 ; FUN_009a65f0 */

undefined4 * __thiscall FUN_009a65f0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::HUMAN::StateType>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 18358 ; VA 0x009a6620 ; FUN_009a6620 */

undefined4 * __thiscall FUN_009a6620(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::PartInstance*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 18359 ; VA 0x009a6650 ; FUN_009a6650 */

undefined4 * __thiscall FUN_009a6650(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Camera::CameraMode>::GetSet::vftable
  ;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 18360 ; VA 0x009a6680 ; FUN_009a6680 */

undefined4 * __thiscall FUN_009a6680(int param_1,byte param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)(param_1 + -8);
  *puVar1 = RBX::CameraSubject::vftable;
  *(undefined ***)(*(int *)(*(int *)(param_1 + -4) + 4) + -4 + param_1) =
       RBX::CameraSubject::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(puVar1,0xc);
  }
  return puVar1;
}



/* FUNCTION 18361 ; VA 0x009a66c0 ; FUN_009a66c0 */

undefined4 * __thiscall FUN_009a66c0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Connector::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1c);
  }
  return param_1;
}



/* FUNCTION 18362 ; VA 0x009a66f0 ; FUN_009a66f0 */

undefined4 * __thiscall FUN_009a66f0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::HitTestFilter::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 18363 ; VA 0x009a6720 ; FUN_009a6720 */

undefined4 * __thiscall FUN_009a6720(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::HitTestFilter::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,8);
  }
  return param_1;
}



/* FUNCTION 18364 ; VA 0x009a6750 ; FUN_009a6750 */

undefined4 * __thiscall FUN_009a6750(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::PartInstance*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 18365 ; VA 0x009a6780 ; FUN_009a6780 */

undefined4 * __thiscall FUN_009a6780(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Humanoid::CollisionType>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 18366 ; VA 0x009a67b0 ; FUN_009a67b0 */

undefined4 * __thiscall FUN_009a67b0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<enum_RBX::Humanoid::HumanoidDisplayDistanceType>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 18367 ; VA 0x009a67e0 ; FUN_009a67e0 */

undefined4 * __thiscall FUN_009a67e0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Humanoid::HumanoidHealthDisplayType>
             ::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 18368 ; VA 0x009a6810 ; FUN_009a6810 */

undefined4 * __thiscall FUN_009a6810(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::HumanoidRigType>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 18369 ; VA 0x009a6840 ; FUN_009a6840 */

undefined4 * __thiscall FUN_009a6840(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Humanoid::NameOcclusion>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 18370 ; VA 0x009a6870 ; FUN_009a6870 */

undefined4 * __thiscall FUN_009a6870(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::PartMaterial>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 18371 ; VA 0x009a68a0 ; FUN_009a68a0 */

undefined4 * __thiscall FUN_009a68a0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::HUMAN::StateType>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 18372 ; VA 0x009a68d0 ; FUN_009a68d0 */

int __thiscall FUN_009a68d0(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009a3eb0();
  FUN_009a3df0();
  uStack_8 = 0;
  FUN_01679490();
  iVar4 = *(int *)(param_1 + 0x60);
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  piVar1 = *(int **)(param_1 + 0x58);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x80);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18373 ; VA 0x009a6980 ; FUN_009a6980 */

int __thiscall FUN_009a6980(int param_1,byte param_2)

{
  FUN_009a3fb0();
  *(undefined ***)(param_1 + 0x7e4) = RBX::IHasLocation::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x7e8);
  }
  return param_1;
}



/* FUNCTION 18374 ; VA 0x009a69b0 ; FUN_009a69b0 */

undefined4 * __thiscall FUN_009a69b0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::IModelModifier::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 18375 ; VA 0x009a69e0 ; FUN_009a69e0 */

undefined4 * __thiscall FUN_009a69e0(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::IStepped::vftable;
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = param_1[2];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18376 ; VA 0x009a6a60 ; FUN_009a6a60 */

undefined4 * __thiscall FUN_009a6a60(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::KernelJoint::vftable;
  param_1[2] = RBX::KernelJoint::vftable;
  param_1[0x2a] = RBX::Connector::vftable;
  FUN_00ca2b60();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc4);
  }
  return param_1;
}



/* FUNCTION 18377 ; VA 0x009a6aa0 ; FUN_009a6aa0 */

uint __fastcall FUN_009a6aa0(int param_1)

{
  int *piVar1;
  uint uVar2;
  char cVar3;
  byte bVar4;
  uint uVar5;
  int iVar6;
  undefined4 uVar7;
  byte bVar8;
  undefined4 uStack_38;
  undefined4 uStack_28;
  undefined4 *puStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3f11;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x228) == 0) {
    uVar5 = *(uint *)(param_1 + 0x340);
  }
  else {
    uVar5 = *(uint *)(param_1 + 0x3f0);
  }
  if (uVar5 == 0) {
    if (*(int *)(param_1 + 0x228) == 0) {
      uVar5 = *(uint *)(param_1 + 0x370);
    }
    else {
      uVar5 = *(uint *)(param_1 + 0x380);
    }
    if (uVar5 == 0) goto LAB_009a6cd1;
  }
  uVar2 = *(uint *)(uVar5 + 0xa8);
  uVar5 = uVar2;
  if ((uVar2 != 0) && (*(int *)(param_1 + 0x6f4) != 0)) {
    ExceptionList = &pvStack_10;
    FUN_00ca4900(0,uVar2);
    FUN_00ca4900(1,*(undefined4 *)(*(int *)(param_1 + 0x6f4) + 0xd4));
    uVar5 = FUN_00c3dac0(param_1 + 0x54,*(undefined4 *)(param_1 + 0x6f4),1);
    if (*(int **)(param_1 + 0x58) != (int *)0x0) {
      iVar6 = (**(code **)(**(int **)(param_1 + 0x58) + 4))();
      uVar5 = *(uint *)(param_1 + 0x58);
      if (iVar6 == 0xf) {
        uVar5 = *(uint *)(uVar5 + 4);
      }
      if (*(int *)(uVar5 + 0xc) != 0) {
        FUN_00b06640(uVar2);
        iVar6 = FUN_008a4100();
        iStack_8 = 0;
        uVar7 = FUN_01675290(DAT_02110da8);
        iStack_8._0_1_ = 1;
        puStack_1c = (undefined4 *)FUN_01674e20(0x30);
        if (puStack_1c == (undefined4 *)0x0) {
          puStack_1c = (undefined4 *)0x0;
        }
        else {
          *puStack_1c = 0;
          puStack_1c[1] = 1;
          puStack_1c[2] = FUN_009b03d0;
          puStack_1c[3] = _guard_check_icall;
          puStack_1c[4] = 0;
          puStack_1c[6] = FUN_009bc4b0;
          puStack_1c[7] = 0xfffffecc;
          puStack_1c[8] = 0;
          puStack_1c[9] = uStack_28;
          puStack_1c[5] = iVar6 + 0x88;
          *(ulonglong *)(puStack_1c + 10) = CONCAT44(uStack_38,param_1);
        }
        FUN_016797d0(puStack_1c);
        puStack_14 = puStack_1c;
        if (puStack_1c != (undefined4 *)0x0) {
          LOCK();
          puStack_1c[1] = puStack_1c[1] + 1;
          UNLOCK();
        }
        iStack_8._0_1_ = 2;
        FUN_01675290(uVar7);
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        cVar3 = FUN_01679300(&puStack_14);
        if (cVar3 != '\0') {
          FUN_01679490();
          FUN_016791c0(&puStack_14);
        }
        iStack_8 = 0xffffffff;
        if (puStack_14 != (undefined4 *)0x0) {
          piVar1 = puStack_14 + 1;
          LOCK();
          iVar6 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar6 == 1) {
            FUN_01674ea0(puStack_14);
          }
        }
        bVar4 = FUN_01679ce0();
        bVar8 = 1;
        if ((bVar4 & 0x7f) != 0) {
          bVar8 = bVar4 & 0x7f;
        }
        *(byte *)(param_1 + 0x21c) = bVar8;
        ExceptionList = pvStack_10;
        return 1;
      }
    }
  }
LAB_009a6cd1:
  ExceptionList = pvStack_10;
  return uVar5 & 0xffffff00;
}



/* FUNCTION 18378 ; VA 0x009a6cf0 ; FUN_009a6cf0 */

void FUN_009a6cf0(int param_1,int param_2)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_01674e20(0x2c);
  if (param_1 == 0) {
    *piVar1 = (int)piVar1;
    piVar1[1] = (int)piVar1;
    return;
  }
  *piVar1 = param_1;
  piVar1[1] = param_2;
  return;
}



/* FUNCTION 18379 ; VA 0x009a6d20 ; FUN_009a6d20 */

void __fastcall FUN_009a6d20(int param_1)

{
  FUN_0099c2c0(param_1 + 8);
  return;
}



/* FUNCTION 18380 ; VA 0x009a6d30 ; FUN_009a6d30 */

void __fastcall FUN_009a6d30(int param_1)

{
  FUN_0099c400(param_1 + 8);
  return;
}



/* FUNCTION 18381 ; VA 0x009a6d40 ; FUN_009a6d40 */

void __fastcall FUN_009a6d40(int param_1)

{
  FUN_0099c540(param_1 + 8);
  return;
}



/* FUNCTION 18382 ; VA 0x009a6d50 ; FUN_009a6d50 */

void __fastcall FUN_009a6d50(int param_1)

{
  FUN_0099c680(param_1 + 8);
  return;
}



/* FUNCTION 18383 ; VA 0x009a6d60 ; FUN_009a6d60 */

void __thiscall FUN_009a6d60(int param_1,char param_2)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 8);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x10,param_1 + 0x10,2);
      }
    }
    *(undefined4 *)(param_1 + 8) = 0;
  }
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0x28);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18384 ; VA 0x009a6dd0 ; FUN_009a6dd0 */

void __fastcall FUN_009a6dd0(int param_1)

{
  if (*(int *)(param_1 + 0xc) != 0) {
    FUN_009a68d0(1);
  }
  return;
}



/* FUNCTION 18385 ; VA 0x009a6de0 ; FUN_009a6de0 */

void __fastcall FUN_009a6de0(int param_1)

{
  FUN_01674ea0(*(undefined4 *)(param_1 + 0xc),0x10);
  return;
}



/* FUNCTION 18386 ; VA 0x009a6df0 ; FUN_009a6df0 */

void FUN_009a6df0(void)

{
  FUN_009a3cc0();
  return;
}



/* FUNCTION 18387 ; VA 0x009a6e00 ; FUN_009a6e00 */

void __fastcall FUN_009a6e00(int param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  iVar4 = *(int *)(param_1 + 0xc);
  if (iVar4 != 0) {
    iVar5 = *(int *)(param_1 + 0x10);
    if (iVar4 != iVar5) {
      do {
        piVar1 = *(int **)(iVar4 + 4);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[1] + -1;
          piVar1[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar2 = piVar1[2] + -1;
            piVar1[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        iVar4 = iVar4 + 8;
      } while (iVar4 != iVar5);
      iVar4 = *(int *)(param_1 + 0xc);
    }
    uVar3 = *(int *)(param_1 + 0x14) - iVar4 & 0xfffffff8;
    iVar5 = iVar4;
    if (0xfff < uVar3) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  return;
}



/* FUNCTION 18388 ; VA 0x009a6eb0 ; FUN_009a6eb0 */

void FUN_009a6eb0(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar1 = *param_1;
  uVar2 = param_1[1];
  *param_1 = 0;
  param_1[1] = 0;
  FUN_009a53e0(uVar1,uVar2);
  return;
}



/* FUNCTION 18389 ; VA 0x009a6ef0 ; FUN_009a6ef0 */

void FUN_009a6ef0(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar1 = *param_1;
  uVar2 = param_1[1];
  *param_1 = 0;
  param_1[1] = 0;
  FUN_009a5870(uVar1,uVar2);
  return;
}



/* FUNCTION 18390 ; VA 0x009a6f30 ; FUN_009a6f30 */

void FUN_009a6f30(undefined4 *param_1)

{
  undefined8 uVar1;
  undefined4 uVar2;
  
  uVar2 = *param_1;
  uVar1 = *(undefined8 *)(param_1 + 4);
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  FUN_005e65e0(uVar2,param_1[1],param_1[2],param_1[3],uVar1);
  return;
}



/* FUNCTION 18391 ; VA 0x009a6f80 ; thunk_FUN_009c6470 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_009c6470(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d55b6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee3fac) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee3fac);
    if (DAT_01ee3fac == -1) {
      uStack_8 = 0;
      FUN_009ca470("HumanoidDisplayDistanceType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee3f48 =
           RBX::Reflection::EnumDesc<enum_RBX::Humanoid::HumanoidDisplayDistanceType>::vftable;
      FUN_009caf20(&DAT_01d64f24,3);
      FUN_016f3654(&LAB_01886cd0);
      FUN_016f37bf(&DAT_01ee3fac);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee3f48;
}



/* FUNCTION 18392 ; VA 0x009a6f90 ; thunk_FUN_009c6520 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_009c6520(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d55d6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee3f44) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee3f44);
    if (DAT_01ee3f44 == -1) {
      uStack_8 = 0;
      FUN_009ca470("HumanoidHealthDisplayType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee3ee0 =
           RBX::Reflection::EnumDesc<enum_RBX::Humanoid::HumanoidHealthDisplayType>::vftable;
      FUN_009caf20(&DAT_01d64f3c,3);
      FUN_016f3654(&LAB_01886cf0);
      FUN_016f37bf(&DAT_01ee3f44);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee3ee0;
}



/* FUNCTION 18393 ; VA 0x009a6fa0 ; thunk_FUN_009c65d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_009c65d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d55f6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee3e74) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee3e74);
    if (DAT_01ee3e74 == -1) {
      uStack_8 = 0;
      FUN_009ca470(&DAT_01938ba4);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee3e10 = RBX::Reflection::EnumDesc<enum_RBX::Humanoid::Limb>::vftable;
      FUN_009caf20(&DAT_01d64f74,7);
      FUN_016f3654(&LAB_01886d10);
      FUN_016f37bf(&DAT_01ee3e74);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee3e10;
}



/* FUNCTION 18394 ; VA 0x009a6fb0 ; thunk_FUN_009c6680 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_009c6680(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5616;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee4014) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee4014);
    if (DAT_01ee4014 == -1) {
      uStack_8 = 0;
      FUN_009ca470("NameOcclusion");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee3fb0 = RBX::Reflection::EnumDesc<enum_RBX::Humanoid::NameOcclusion>::vftable;
      FUN_009caf20(&DAT_01d64f0c,3);
      FUN_016f3654(&LAB_01886d30);
      FUN_016f37bf(&DAT_01ee4014);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee3fb0;
}



/* FUNCTION 18395 ; VA 0x009a6fc0 ; FUN_009a6fc0 */

void FUN_009a6fc0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  FUN_01674ea0(param_1,0x2c);
  return;
}



/* FUNCTION 18396 ; VA 0x009a7020 ; FUN_009a7020 */

undefined4 * __thiscall FUN_009a7020(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_4dd444fc3bc9f580bc95870b96003314>,void,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>_>
             ::vftable;
  param_2[2] = 0;
  FUN_005880d0(param_1 + 8);
  return param_2;
}



/* FUNCTION 18397 ; VA 0x009a7050 ; FUN_009a7050 */

undefined4 * __thiscall FUN_009a7050(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_5fc0ede2d0ae68360350b7320687fc49>,void,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>_>
             ::vftable;
  param_2[2] = 0;
  FUN_005880d0(param_1 + 8);
  return param_2;
}



/* FUNCTION 18398 ; VA 0x009a7080 ; FUN_009a7080 */

undefined4 * __thiscall FUN_009a7080(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_95bcb670a0e1b2e0928fabe058461903>,void,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>_>
             ::vftable;
  param_2[2] = 0;
  FUN_005880d0(param_1 + 8);
  return param_2;
}



/* FUNCTION 18399 ; VA 0x009a70b0 ; FUN_009a70b0 */

undefined4 * __thiscall FUN_009a70b0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,void,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
             ::vftable;
  param_2[2] = 0;
  FUN_005880d0(param_1 + 8);
  return param_2;
}



/* FUNCTION 18400 ; VA 0x009a70e0 ; FUN_009a70e0 */

TypeDescriptor * FUN_009a70e0(void)

{
  return &<lambda_4dd444fc3bc9f580bc95870b96003314>::RTTI_Type_Descriptor;
}



/* FUNCTION 18401 ; VA 0x009a70f0 ; FUN_009a70f0 */

TypeDescriptor * FUN_009a70f0(void)

{
  return &<lambda_5fc0ede2d0ae68360350b7320687fc49>::RTTI_Type_Descriptor;
}



/* FUNCTION 18402 ; VA 0x009a7100 ; FUN_009a7100 */

TypeDescriptor * FUN_009a7100(void)

{
  return &<lambda_95bcb670a0e1b2e0928fabe058461903>::RTTI_Type_Descriptor;
}



/* FUNCTION 18403 ; VA 0x009a7110 ; FUN_009a7110 */

TypeDescriptor * FUN_009a7110(void)

{
  return &boost::
          function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>
          ::RTTI_Type_Descriptor;
}



/* FUNCTION 18404 ; VA 0x009a7120 ; FUN_009a7120 */

int __thiscall FUN_009a7120(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if ((param_2 != 0) &&
     (iVar4 = *(int *)(param_2 + 0xc), ExceptionList = &pvStack_10, iVar2 = FUN_00c8dce0(),
     (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
     (uint)*(ushort *)(iVar2 + 0x1da))) {
    if (((param_1 == 0) || (iVar4 = *(int *)(param_1 + 0x34), iVar4 == 0)) ||
       (iVar2 = *(int *)(iVar4 + 0xc), iVar3 = FUN_00b63e30(),
       (uint)*(ushort *)(iVar3 + 0x1da) <
       (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
      iVar4 = FUN_0086f2f0(2,"AddAcessory failed: Humanoid is not a valid character.");
    }
    else {
      iVar2 = FUN_009ba890(*(undefined4 *)(param_2 + 0x34));
      if (iVar2 != 0) {
        FUN_0086f2f0(2,"AddAcessory failed: Accessory is already being worn by another character.");
        iVar4 = FUN_00550b30();
        ExceptionList = pvStack_10;
        return iVar4;
      }
      iVar4 = FUN_008a65e0(iVar4,0);
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      piVar1 = param_3 + 1;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)*param_3)();
        LOCK();
        piVar1 = param_3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar4 = (**(code **)(*param_3 + 4))();
          ExceptionList = pvStack_10;
          return iVar4;
        }
      }
    }
    ExceptionList = pvStack_10;
    return iVar4;
  }
  FUN_00550130("AddAccessory should be passed a valid Accessory object.");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 18405 ; VA 0x009a7260 ; FUN_009a7260 */

undefined FUN_009a7260(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined uVar5;
  uint in_stack_00000018;
  int *piStack_1c;
  int *piStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d3f30;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_009b6f20();
  if (iVar2 != 0) {
    iVar2 = FUN_008a1240(&param_1);
    if (iVar2 == 0) {
      FUN_00965c50(&piStack_1c);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      (**(code **)(*piStack_1c + 0x38))(&param_1);
      uStack_11 = 1;
      FUN_00db5830(&uStack_11);
      uVar3 = FUN_009b6f20();
      FUN_008a65e0(uVar3,0);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_18[1] + -1;
        piStack_18[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar1 = piStack_18 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
      uVar5 = 1;
      goto LAB_009a730e;
    }
  }
  uVar5 = 0;
LAB_009a730e:
  if (0xf < in_stack_00000018) {
    uVar4 = in_stack_00000018 + 1;
    iVar2 = param_1;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(param_1 + -4);
      uVar4 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 18406 ; VA 0x009a7360 ; FUN_009a7360 */

void FUN_009a7360(undefined4 param_1)

{
  undefined auStack_24 [20];
  undefined4 uStack_10;
  
  uStack_10 = 0x9a736c;
  FUN_009c68d0();
  FUN_009cb090(auStack_24,param_1);
  FUN_009a7260();
  return;
}



/* FUNCTION 18407 ; VA 0x009a7390 ; FUN_009a7390 */

void FUN_009a7390(void)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  char *pcVar5;
  uint uVar6;
  uint uVar7;
  float fVar8;
  uint auStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  uint auStack_54 [4];
  undefined4 uStack_44;
  uint uStack_40;
  undefined auStack_3c [12];
  undefined4 auStack_30 [2];
  undefined4 uStack_28;
  undefined4 uStack_24;
  float fStack_20;
  undefined4 uStack_1c;
  float fStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3f50;
  pvStack_10 = ExceptionList;
  uStack_44 = 0;
  uStack_40 = 0xf;
  auStack_54[0] = auStack_54[0] & 0xffffff00;
  pcVar5 = PTR_DAT_01d64a40;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(PTR_DAT_01d64a40,(int)pcVar5 - (int)(PTR_DAT_01d64a40 + 1));
  uStack_8 = 0;
  uVar2 = FUN_008a1240(auStack_54);
  iVar3 = FUN_009ab420(uVar2);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_40) {
    uVar7 = uStack_40 + 1;
    uVar6 = auStack_54[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_54[0] - 4);
      uVar7 = uStack_40 + 0x24;
      if (0x1f < (auStack_54[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_44 = 0;
  uStack_40 = 0xf;
  auStack_54[0] = auStack_54[0] & 0xffffff00;
  uStack_5c = 0;
  uStack_58 = 0xf;
  auStack_6c[0] = auStack_6c[0] & 0xffffff00;
  pcVar5 = PTR_DAT_01d64a44;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(PTR_DAT_01d64a44,(int)pcVar5 - (int)(PTR_DAT_01d64a44 + 1));
  uStack_8 = 1;
  uVar2 = FUN_008a1240(auStack_6c);
  iVar4 = FUN_009ab420(uVar2);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_58) {
    uVar7 = uStack_58 + 1;
    uVar6 = auStack_6c[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_6c[0] - 4);
      uVar7 = uStack_58 + 0x24;
      if (0x1f < (auStack_6c[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_5c = 0;
  uStack_58 = 0xf;
  auStack_6c[0] = auStack_6c[0] & 0xffffff00;
  if (iVar4 == 0) {
    if (iVar3 == 0) {
      ExceptionList = pvStack_10;
      return;
    }
  }
  else if (iVar3 == 0) {
    fStack_14 = DAT_018c45c4;
    goto LAB_009a752c;
  }
  iVar3 = FUN_00a6bd00(auStack_3c);
  fStack_14 = *(float *)(iVar3 + 4);
LAB_009a752c:
  fVar8 = DAT_018c45c4;
  if (iVar4 != 0) {
    iVar3 = FUN_00a6bd00(auStack_3c);
    fVar8 = *(float *)(iVar3 + 4);
  }
  if (fVar8 <= fStack_14) {
    fStack_14 = fVar8;
  }
  iVar3 = FUN_00a6bd00(auStack_3c);
  fStack_14 = *(float *)(iVar3 + 4) - fStack_14;
  iVar3 = FUN_00b08320();
  fStack_18 = *(float *)(iVar3 + 4) * DAT_018ce2f4;
  FUN_00a6bd00(auStack_30);
  uStack_24 = auStack_30[0];
  fStack_20 = fStack_14 - fStack_18;
  uStack_1c = uStack_28;
  FUN_00d6dad0(&uStack_24);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18408 ; VA 0x009a75e0 ; FUN_009a75e0 */

void FUN_009a75e0(undefined4 *param_1)

{
  *param_1 = 0x3f800000;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0x3f800000;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0x3f800000;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  return;
}



/* FUNCTION 18409 ; VA 0x009a7640 ; FUN_009a7640 */

void __thiscall
FUN_009a7640(code *param_1,undefined4 param_2,int *param_3,int *param_4,int *param_5,int param_6,
            uint param_7)

{
  int iVar1;
  uint *puVar2;
  int *piVar3;
  char cVar4;
  int *piVar5;
  bool bVar6;
  uint in_stack_00000038;
  undefined4 in_stack_00000040;
  int *in_stack_00000044;
  int *in_stack_00000048;
  int *in_stack_0000004c;
  undefined8 in_stack_00000050;
  code *pcStack_178;
  int *piStack_174;
  int *piStack_170;
  int iStack_16c;
  int *piStack_168;
  int *piStack_164;
  int *piStack_160;
  int *piStack_15c;
  int *piStack_158;
  int *piStack_154;
  int *piStack_150;
  undefined auStack_14c [20];
  undefined4 uStack_138;
  undefined4 *puStack_134;
  undefined4 *puStack_130;
  int aiStack_12c [6];
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined auStack_10c [96];
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  int *piStack_a4;
  int *piStack_a0;
  int **ppiStack_9c;
  undefined4 *puStack_98;
  char *pcStack_94;
  int *piStack_90;
  uint auStack_8c [2];
  undefined4 uStack_84;
  int *piStack_80;
  int *piStack_7c;
  int *piStack_78;
  undefined8 uStack_74;
  int aiStack_64 [7];
  int *piStack_48;
  int *piStack_44;
  int *piStack_40;
  int iStack_3c;
  int *piStack_38;
  undefined auStack_34 [4];
  int *piStack_30;
  undefined *puStack_2c;
  undefined *puStack_28;
  undefined *puStack_24;
  code *pcStack_20;
  int *piStack_1c;
  int *piStack_18;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d4000;
  pvStack_10 = ExceptionList;
  piStack_1c = (int *)0x0;
  iStack_3c = 0;
  piStack_38 = (int *)0x0;
  puStack_24 = (undefined *)auStack_8c;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  cStack_11 = '\0';
  auStack_8c[0] = 0;
  ExceptionList = &pvStack_10;
  puVar2 = auStack_8c;
  pcStack_20 = param_1;
  if (in_stack_00000038 != 0) {
    auStack_8c[0] = in_stack_00000038;
    if ((in_stack_00000038 & 1) == 0) {
      pcStack_94 = (char *)&uStack_84;
      piStack_90 = (int *)0x0;
      puStack_98 = &stack0x00000040;
      ppiStack_9c = (int **)0x9a76c7;
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000038 & 0xfffffffe))();
      puVar2 = (uint *)puStack_24;
    }
    else {
      uStack_84 = in_stack_00000040;
      piStack_80 = in_stack_00000044;
      piStack_7c = in_stack_00000048;
      piStack_78 = in_stack_0000004c;
      uStack_74 = in_stack_00000050;
      ExceptionList = &pvStack_10;
      puVar2 = auStack_8c;
    }
  }
  puStack_24 = (undefined *)puVar2;
  piStack_90 = &iStack_3c;
  pcStack_94 = &cStack_11;
  puStack_98 = param_5;
  ppiStack_9c = &piStack_1c;
  piStack_a0 = param_4;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_a8 = param_2;
  piStack_a4 = param_3;
  uStack_ac = 0x9a770b;
  cVar4 = FUN_009c5e40();
  if (cVar4 == '\0') goto LAB_009a7a9c;
  uStack_74 = CONCAT44(&piStack_44,0x9a771f);
  FUN_0099fc60();
  aiStack_64[3] = 0;
  aiStack_64[4] = 0;
  aiStack_64[5] = 0;
  aiStack_64[0] = 0;
  aiStack_64[1] = 0;
  aiStack_64[2] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if ((DAT_01d64ac8 == '\0') || (*(int *)(param_1 + 0x228) == 0)) {
LAB_009a7773:
    param_5 = (int *)((uint)param_5 & 0xffffff);
  }
  else {
    uStack_74 = CONCAT44(param_1,0x9a7768);
    cVar4 = FUN_008bc690();
    param_5 = (int *)CONCAT13(1,param_5._0_3_);
    if (cVar4 == '\0') goto LAB_009a7773;
  }
  uStack_74 = CONCAT44(param_1,auStack_34);
  piStack_78 = (int *)0x9a7781;
  piStack_7c = (int *)FUN_009b49f0();
  piStack_78 = &iStack_3c;
  uStack_8._0_1_ = 7;
  piStack_80 = (int *)0x9a778f;
  cStack_12 = FUN_009a87d0();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  piStack_18 = piStack_30;
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_30[1] + -1;
    piStack_30[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_74 = CONCAT44(0x9a77b2,(undefined4)uStack_74);
      (**(code **)*piStack_30)();
      LOCK();
      iVar1 = piStack_18[2] + -1;
      piStack_18[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_74 = CONCAT44(0x9a77c3,(undefined4)uStack_74);
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piVar5 = piStack_18;
  if (cStack_12 != '\0') {
    piStack_18 = (int *)((uint)piStack_18 & 0xffffff00);
    piVar3 = piStack_18;
    piStack_18._1_3_ = SUB43(piVar5,1);
    if (((DAT_01d64ab8 == '\0') || (param_6 != 3)) && ((DAT_01d64ac0 == '\0' || (param_6 != 1)))) {
      if (DAT_01d64ab0 != '\0') {
        piStack_18 = (int *)CONCAT31(piStack_18._1_3_,cStack_11 == '\0');
        piVar3 = piStack_18;
      }
    }
    else {
      piStack_18 = (int *)CONCAT31(piStack_18._1_3_,1);
      piVar3 = piStack_18;
    }
    piStack_18 = piVar3;
    if (param_5._3_1_ == '\0') {
      uStack_74 = CONCAT44(piStack_18,aiStack_64 + 3);
      piStack_78 = piStack_44;
      piStack_7c = piStack_1c;
      piStack_80 = (int *)0x9a7833;
      FUN_00e30c10();
    }
    else {
      uStack_74 = CONCAT44(piStack_18,aiStack_64);
      piStack_78 = aiStack_64 + 3;
      piStack_7c = piStack_44;
      piStack_80 = piStack_1c;
      uStack_84 = 0x9a7822;
      FUN_00e30ca0();
    }
  }
  if ((piStack_1c != (int *)0x0) && (piStack_1c != (int *)0xfffffff4)) {
    uStack_74 = CONCAT44(0x9a7846,(undefined4)uStack_74);
    FUN_005c2760();
  }
  *(int *)(param_1 + 0x33c) = *(int *)(param_1 + 0x33c) + 1;
  piStack_1c = *(int **)(param_1 + 0x33c);
  uStack_74 = CONCAT44(0x9a7866,(undefined4)uStack_74);
  piStack_78 = (int *)FUN_008ccd70();
  bVar6 = param_5._3_1_ == '\0';
  param_5 = (int *)CONCAT31(param_5._1_3_,DAT_01ee37b5);
  uStack_74 = 0x100000003;
  if (bVar6) {
    piStack_18 = (int *)&puStack_98;
    puStack_130 = &stack0x00000038;
    ppiStack_9c = (int **)0x0;
    puStack_24 = auStack_10c;
    piStack_30 = aiStack_12c;
    puStack_134 = (undefined4 *)0x9a7985;
    FUN_0054f510();
    puStack_2c = auStack_14c;
    uStack_8._0_1_ = 0xf;
    piStack_150 = (int *)&param_7;
    piStack_154 = (int *)0x9a799a;
    FUN_0054f510();
    piStack_150 = piStack_1c;
    piStack_158 = aiStack_64 + 6;
    uStack_8._0_1_ = 0x10;
    piStack_154 = (int *)0x3;
    piStack_15c = (int *)0x9a79ae;
    piStack_15c = (int *)FUN_0089d950();
    puStack_28 = (undefined *)&piStack_158;
    piStack_160 = (int *)&piStack_158;
    uStack_8._0_1_ = 0x11;
    piStack_164 = (int *)0x9a79c1;
    FUN_00917080();
    if (piStack_40 != (int *)0x0) {
      LOCK();
      piStack_40[1] = piStack_40[1] + 1;
      UNLOCK();
    }
    piStack_160 = piStack_44;
    piStack_15c = piStack_40;
    piStack_164 = param_5;
    piStack_174 = &iStack_16c;
    uStack_8._0_1_ = 0x13;
    piStack_170 = param_4;
    pcStack_178 = (code *)0x9a79ff;
    piStack_1c = (int *)&piStack_160;
    FUN_005e5de0();
    uStack_8._0_1_ = 0x14;
    pcStack_178 = pcStack_20;
    FUN_0060e0c0(&piStack_174);
    pcStack_178 = FUN_009a7b50;
    uStack_8._0_1_ = 0x15;
    FUN_0099ddc0(puStack_24);
    uStack_110 = 0x9a7a2d;
    FUN_0099b4d0();
    piStack_a0 = aiStack_64 + 3;
    ppiStack_9c = (int **)0x42200000;
    piStack_a4 = (int *)0x9a7a41;
    FUN_008d16d0();
    piVar5 = piStack_40;
  }
  else {
    puStack_24 = (undefined *)&ppiStack_9c;
    puStack_134 = &stack0x00000038;
    piStack_a0 = (int *)0x0;
    piStack_18 = &uStack_110;
    puStack_28 = (undefined *)&puStack_130;
    uStack_138 = 0x9a78a4;
    piStack_7c = piStack_78;
    piStack_78 = aiStack_64;
    FUN_0054f510();
    puStack_2c = (undefined *)&piStack_150;
    uStack_8._0_1_ = 8;
    piStack_154 = (int *)&param_7;
    piStack_158 = (int *)0x9a78b9;
    FUN_0054f510();
    piStack_154 = piStack_1c;
    piStack_15c = aiStack_64 + 6;
    uStack_8._0_1_ = 9;
    piStack_158 = (int *)0x3;
    piStack_160 = (int *)0x9a78cd;
    piStack_160 = (int *)FUN_0089d950();
    piStack_1c = (int *)&piStack_15c;
    piStack_164 = (int *)&piStack_15c;
    uStack_8._0_1_ = 10;
    piStack_168 = (int *)0x9a78e0;
    FUN_00917080();
    if (piStack_40 != (int *)0x0) {
      LOCK();
      piStack_40[1] = piStack_40[1] + 1;
      UNLOCK();
    }
    piStack_164 = piStack_44;
    piStack_160 = piStack_40;
    piStack_168 = param_5;
    pcStack_178 = (code *)&piStack_170;
    uStack_8._0_1_ = 0xc;
    piStack_174 = param_4;
    piStack_30 = (int *)&piStack_164;
    FUN_005e5de0();
    uStack_8._0_1_ = 0xd;
    FUN_0060e0c0(&pcStack_178,pcStack_20);
    uStack_8._0_1_ = 0xe;
    FUN_0099ddc0(piStack_18,FUN_009a7b50);
    uStack_114 = 0x9a794c;
    FUN_0099b4d0();
    piStack_a4 = aiStack_64 + 3;
    piStack_a0 = (int *)0x42200000;
    uStack_a8 = 0x9a7960;
    FUN_008d1df0();
    piVar5 = piStack_40;
  }
  if (piStack_48 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_48[1] + -1;
    piStack_48[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_74 = CONCAT44(0x9a7a58,(undefined4)uStack_74);
      (**(code **)*piStack_48)();
      LOCK();
      iVar1 = piStack_48[2] + -1;
      piStack_48[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_74 = CONCAT44(0x9a7a69,(undefined4)uStack_74);
        (**(code **)(*piStack_48 + 4))();
      }
    }
  }
  uStack_74 = CONCAT44(0x9a7a71,(undefined4)uStack_74);
  FUN_0056d320();
  uStack_74 = CONCAT44(0x9a7a79,(undefined4)uStack_74);
  FUN_00577a40();
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar1 = piVar5[1] + -1;
    piVar5[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_74 = CONCAT44(0x9a7a8c,(undefined4)uStack_74);
      (**(code **)*piVar5)();
      LOCK();
      iVar1 = piVar5[2] + -1;
      piVar5[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_74 = CONCAT44(0x9a7a9c,(undefined4)uStack_74);
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
LAB_009a7a9c:
  piVar5 = piStack_38;
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_38[1] + -1;
    piStack_38[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_74 = CONCAT44(0x9a7ab2,(undefined4)uStack_74);
      (**(code **)*piStack_38)();
      LOCK();
      piVar3 = piVar5 + 2;
      iVar1 = *piVar3 + -1;
      *piVar3 = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_74 = CONCAT44(0x9a7ac2,(undefined4)uStack_74);
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_74 = CONCAT44(0x9a7ad8,(undefined4)uStack_74);
      (**(code **)*param_3)();
      LOCK();
      piVar5 = param_3 + 2;
      iVar1 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        uStack_74 = CONCAT44(0x9a7ae7,(undefined4)uStack_74);
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
  if (param_7 != 0) {
    if (((param_7 & 1) == 0) && (*(code **)(param_7 & 0xfffffffe) != (code *)0x0)) {
      piStack_78 = (int *)&stack0x00000020;
      uStack_74 = CONCAT44(2,piStack_78);
      piStack_7c = (int *)0x9a7b08;
      (**(code **)(param_7 & 0xfffffffe))();
    }
    param_7 = 0;
  }
  uStack_8 = 0x17;
  if (((in_stack_00000038 != 0) && ((in_stack_00000038 & 1) == 0)) &&
     (*(code **)(in_stack_00000038 & 0xfffffffe) != (code *)0x0)) {
    piStack_78 = &stack0x00000040;
    uStack_74 = CONCAT44(2,piStack_78);
    piStack_7c = (int *)0x9a7b36;
    (**(code **)(in_stack_00000038 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18410 ; VA 0x009a7b50 ; FUN_009a7b50 */

/* WARNING: Removing unreachable block (ram,0x009a822b) */
/* WARNING: Removing unreachable block (ram,0x009a8231) */
/* WARNING: Removing unreachable block (ram,0x009a8235) */

void FUN_009a7b50(undefined4 param_1,int *param_2,int param_3,int *param_4,int *param_5,int *param_6
                 ,int *param_7,int *param_8,undefined4 param_9,int *param_10,int param_11,
                 uint param_12)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined **ppuVar5;
  undefined **ppuVar6;
  int *piVar7;
  undefined4 *puVar8;
  uint in_stack_00000050;
  uint in_stack_ffffff3c;
  uint3 uVar10;
  uint uVar9;
  undefined4 in_stack_ffffff40;
  undefined4 in_stack_ffffff44;
  undefined *puVar11;
  undefined4 in_stack_ffffff48;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined auStack_88 [8];
  undefined auStack_80 [8];
  undefined auStack_78 [12];
  undefined auStack_6c [4];
  int iStack_68;
  int iStack_64;
  int iStack_58;
  undefined uStack_54;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined auStack_3c [4];
  undefined *puStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined uStack_23;
  undefined uStack_22;
  undefined uStack_21;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d4083;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff54;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_20);
  uStack_8._0_1_ = 7;
  if (iStack_20 == 0) {
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        iVar4 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    if (param_2 != (int *)0x0) {
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
    if (param_4 != (int *)0x0) {
      LOCK();
      iVar4 = param_4[2] + -1;
      param_4[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
    piVar7 = param_6;
    if (param_6 != (int *)0x0) {
      LOCK();
      iVar4 = param_6[1] + -1;
      param_6[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*param_6)();
        LOCK();
        piVar1 = piVar7 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    piVar7 = param_8;
    if (param_8 != (int *)0x0) {
      LOCK();
      iVar4 = param_8[1] + -1;
      param_8[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*param_8)();
        LOCK();
        piVar1 = piVar7 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    piVar7 = param_10;
    if (param_10 != (int *)0x0) {
      LOCK();
      iVar4 = param_10[1] + -1;
      param_10[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*param_10)();
        LOCK();
        piVar1 = piVar7 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    if (param_12 != 0) {
      if (((param_12 & 1) == 0) && (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(param_12 & 0xfffffffe))(&stack0x00000038,&stack0x00000038,2);
      }
      param_12 = 0;
    }
    uStack_8 = 9;
    goto LAB_009a838a;
  }
  iStack_18 = 0;
  piVar7 = (int *)0x0;
  if (param_4 == (int *)0x0) {
LAB_009a7cd7:
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar4 = piVar7[1] + -1;
      piVar7[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar7)();
        LOCK();
        iVar4 = piVar7[2] + -1;
        piVar7[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    if (iStack_18 == 0) goto LAB_009a7d07;
  }
  else {
    piVar7 = param_4 + 1;
    iVar4 = param_4[1];
    while (iVar4 != 0) {
      LOCK();
      iVar3 = *piVar7;
      if (iVar4 == iVar3) {
        *piVar7 = iVar4 + 1;
        iVar3 = iVar4;
      }
      UNLOCK();
      if (iVar3 == iVar4) {
        iStack_18 = param_3;
        piVar7 = param_4;
        goto LAB_009a7cd7;
      }
      iVar4 = *piVar7;
    }
LAB_009a7d07:
    iVar4 = FUN_008f7870(iStack_20);
    iStack_18 = iVar4;
    if (iVar4 == 0) {
      uVar13 = 0xf;
      in_stack_ffffff3c = in_stack_ffffff3c & 0xffffff00;
      FUN_005542c0("Humanoid::ApplyDescription() DataModel was not available",0x38);
      FUN_005e65e0(in_stack_ffffff3c,in_stack_ffffff40,in_stack_ffffff44,in_stack_ffffff48,iVar4,
                   uVar13);
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar4 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          iVar4 = piStack_1c[2] + -1;
          piStack_1c[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
      if (param_2 != (int *)0x0) {
        LOCK();
        iVar4 = param_2[2] + -1;
        param_2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*param_2 + 4))();
        }
      }
      if (param_4 != (int *)0x0) {
        LOCK();
        iVar4 = param_4[2] + -1;
        param_4[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*param_4 + 4))();
        }
      }
      piVar7 = param_6;
      if (param_6 != (int *)0x0) {
        LOCK();
        iVar4 = param_6[1] + -1;
        param_6[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*param_6)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar4 = *piVar1 + -1;
          *piVar1 = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      piVar7 = param_8;
      if (param_8 != (int *)0x0) {
        LOCK();
        iVar4 = param_8[1] + -1;
        param_8[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*param_8)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar4 = *piVar1 + -1;
          *piVar1 = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      piVar7 = param_10;
      if (param_10 != (int *)0x0) {
        LOCK();
        iVar4 = param_10[1] + -1;
        param_10[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*param_10)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,10);
      if (param_12 != 0) {
        if (((param_12 & 1) == 0) && (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(param_12 & 0xfffffffe))(&stack0x00000038,&stack0x00000038,2);
        }
        param_12 = 0;
      }
      uStack_8 = 0xb;
      goto LAB_009a838a;
    }
  }
  uVar10 = (uint3)(in_stack_ffffff3c >> 8);
  if ((*(int *)(iStack_20 + 0x228) == 0) || (*(int *)(iStack_20 + 0x3f0) != 0)) {
    if ((param_5 == (int *)0x0) ||
       ((param_7 == (int *)0x0 || (param_7[1] - *param_7 >> 3 != param_5[1] - *param_5 >> 3)))) {
      uVar13 = 0;
      uVar14 = 0xf;
      iVar4 = (uint)uVar10 << 8;
      FUN_005542c0("Humanoid::ApplyDescription() Unexpected number of assets returned from the back-end"
                   ,0x53);
      FUN_005e65e0(iVar4,in_stack_ffffff40,in_stack_ffffff44,in_stack_ffffff48,uVar13,uVar14);
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar4 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          iVar4 = piStack_1c[2] + -1;
          piStack_1c[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
      if (param_2 != (int *)0x0) {
        LOCK();
        iVar4 = param_2[2] + -1;
        param_2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*param_2 + 4))();
        }
      }
      if (param_4 != (int *)0x0) {
        LOCK();
        iVar4 = param_4[2] + -1;
        param_4[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*param_4 + 4))();
        }
      }
      piVar7 = param_6;
      if (param_6 != (int *)0x0) {
        LOCK();
        iVar4 = param_6[1] + -1;
        param_6[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*param_6)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar4 = *piVar1 + -1;
          *piVar1 = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      piVar7 = param_8;
      if (param_8 != (int *)0x0) {
        LOCK();
        iVar4 = param_8[1] + -1;
        param_8[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*param_8)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar4 = *piVar1 + -1;
          *piVar1 = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      piVar7 = param_10;
      if (param_10 != (int *)0x0) {
        LOCK();
        iVar4 = param_10[1] + -1;
        param_10[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*param_10)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
      if (param_12 != 0) {
        if (((param_12 & 1) == 0) && (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(param_12 & 0xfffffffe))(&stack0x00000038,&stack0x00000038,2);
        }
        param_12 = 0;
      }
      uStack_8 = 0xd;
LAB_009a838a:
      if (((in_stack_00000050 != 0) && ((in_stack_00000050 & 1) == 0)) &&
         (*(code **)(in_stack_00000050 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(in_stack_00000050 & 0xfffffffe))(&stack0x00000058,&stack0x00000058,2);
      }
      ExceptionList = pvStack_10;
      return;
    }
    FUN_009bf8f0(&param_5,&param_7,&param_9);
    uVar13 = FUN_009b49f0(auStack_78,iStack_20);
    puVar11 = (undefined *)&param_9;
    uStack_8._0_1_ = 0xe;
    uVar14 = 0x9a7f3f;
    cVar2 = FUN_00e2e930(uVar13,puVar11);
    uStack_8._0_1_ = 7;
    FUN_00550b30();
    if (cVar2 == '\0') {
      uVar12 = 0;
      uVar15 = 0xf;
      in_stack_ffffff3c = in_stack_ffffff3c & 0xffffff00;
      FUN_005542c0("Humanoid::ApplyDescription() The current and new HumanoidDescription have common assets in different properties"
                   ,0x6f);
      FUN_005e65e0(in_stack_ffffff3c,uVar14,uVar13,puVar11,uVar12,uVar15);
    }
    else {
      FUN_005693e0(0xb,&uStack_23,&uStack_22,&uStack_21);
      uStack_8._0_1_ = 0xf;
      uVar13 = FUN_009b49f0(auStack_80,iStack_20);
      uStack_8._0_1_ = 0x10;
      puVar11 = (undefined *)&param_9;
      uVar9 = 0x9a7fd0;
      FUN_00e2e7d0(uVar13,puVar11,auStack_6c);
      uStack_8._0_1_ = 0xf;
      FUN_00550b30();
      if (iStack_64 == 0) {
        puVar8 = (undefined4 *)0x0;
      }
      else {
        puVar8 = *(undefined4 **)(iStack_58 + iStack_68 * 4);
      }
      for (; puVar8 != (undefined4 *)0x0; puVar8 = (undefined4 *)*puVar8) {
        uVar14 = 0x9a8011;
        cVar2 = FUN_00f96fc0(puVar8[2],puVar8[3]);
        if (cVar2 != '\0') {
          uVar12 = 0;
          uVar15 = 0xf;
          uVar9 = uVar9 & 0xffffff00;
          FUN_005542c0("Humanoid::ApplyDescription() The current HumanoidDescription does not match the assets currently applied to the character. Did you edit the character?"
                       ,0x96);
          FUN_005e65e0(uVar9,uVar13,puVar11,uVar14,uVar12,uVar15);
          FUN_00612320();
          goto LAB_009a7f7d;
        }
      }
      if (param_11 == *(int *)(iStack_20 + 0x33c)) {
        FUN_009c1210(iStack_20,1);
        iVar4 = iStack_18;
        FUN_009a83c0(&param_5,&param_7,auStack_6c,iStack_18,&param_9);
        if (iVar4 != -0xc) {
          FUN_0063f510();
        }
        uVar13 = FUN_009b49f0(auStack_88,iStack_20);
        uStack_8._0_1_ = 0x11;
        FUN_00bb5090(iStack_20,uVar13,&param_9);
        FUN_00550b30();
        auStack_3c[0] = 0;
        iStack_18 = 0xb;
        ppuVar5 = (undefined **)
                  FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&iStack_18);
        ppuVar6 = ppuVar5 + -1;
        if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
          ppuVar6 = ppuVar5;
        }
        puStack_38 = *ppuVar6;
        uStack_34 = 0;
        uStack_30 = 0x3f800000;
        uStack_2c = 0;
        uStack_28 = 0;
        uStack_8._0_1_ = 0x12;
        FUN_00e30fa0(auStack_3c);
        FUN_00f971b0(auStack_3c);
        uStack_8._0_1_ = 0xf;
        FUN_00612320();
        FUN_00e33950(iStack_20);
        uStack_54 = 0;
        uStack_44 = 0;
        uStack_40 = 0xf;
        uStack_8._0_1_ = 0x13;
        if (*(int *)(iStack_20 + 0x228) == 0) {
          uVar13 = FUN_009b4820(iStack_20);
          FUN_009bf280(uVar13);
        }
        else if (DAT_01d64aa8 == '\0') {
          FUN_009aa270();
        }
        else {
          uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
          FUN_009aa270();
          uStack_8._0_1_ = 0x13;
          uStack_8._1_3_ = 0;
        }
        FUN_00e336e0(iStack_20);
        FUN_009abbd0(iStack_20,&param_9);
        FUN_009c1210(iStack_20,0);
        if (param_12 != 0) {
          FUN_005515c0();
        }
        FUN_005507b0();
        FUN_00612320();
      }
      else {
        if (param_12 != 0) {
          FUN_005515c0();
        }
        FUN_00612320();
      }
    }
LAB_009a7f7d:
    FUN_00550b30();
    FUN_0056c200();
    FUN_0056c200();
  }
  else {
    uVar13 = 0;
    uVar14 = 0xf;
    iVar4 = (uint)uVar10 << 8;
    FUN_005542c0("Humanoid::ApplyDescription() Humanoid has no HumanoidRootPart",0x3d);
    FUN_005e65e0(iVar4,in_stack_ffffff40,in_stack_ffffff44,in_stack_ffffff48,uVar13,uVar14);
    FUN_00550b30();
    if (param_2 != (int *)0x0) {
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
    if (param_4 != (int *)0x0) {
      LOCK();
      piVar7 = param_4 + 2;
      iVar4 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  FUN_00550b30();
  FUN_00550b30();
  FUN_00550b30();
  FUN_00550990();
  FUN_00550990();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18411 ; VA 0x009a819c ; Catch@009a819c */

undefined * Catch_009a819c(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x6c) + 4))();
  uVar1 = FUN_01675640(unaff_EBP + -0x9c,
                       "Humanoid::ApplyDescription() buildRigFromAttachments error: %s",uVar1);
  FUN_005511f0(uVar1);
  FUN_005507b0();
  return &DAT_009a81d3;
}



/* FUNCTION 18412 ; VA 0x009a83c0 ; FUN_009a83c0 */

void __thiscall
FUN_009a83c0(int param_1,int *param_2,int *param_3,undefined4 param_4,int param_5,
            undefined4 *param_6)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  bool bVar4;
  char cVar5;
  int iVar6;
  int *piVar7;
  undefined4 uVar8;
  char *pcVar9;
  int iVar10;
  uint uVar11;
  undefined8 uVar12;
  int aiStack_64 [9];
  int *piStack_40;
  int *piStack_3c;
  int *piStack_38;
  undefined8 uStack_34;
  undefined auStack_2c [4];
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined auStack_1c [4];
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d40b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (((param_1 == 0) ||
      (iVar10 = *(int *)(param_1 + 0x34), ExceptionList = &pvStack_10, iVar10 == 0)) ||
     (iVar2 = *(int *)(iVar10 + 0xc), ExceptionList = &pvStack_10, iVar6 = FUN_00b63e30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    iVar10 = 0;
  }
  FUN_0060e0c0(auStack_2c,iVar10);
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  if ((-(uint)(param_5 != 0) & param_5 + 0xcU) != 0) {
    FUN_0063f510();
  }
  uVar11 = 0;
  if (((int *)*param_2)[1] - *(int *)*param_2 >> 3 != 0) {
    do {
      if ((uint)(((int *)*param_3)[1] - *(int *)*param_3 >> 3) <= uVar11) goto LAB_009a87c7;
      uVar12 = FUN_00f990b0();
      uStack_34 = uVar12;
      piVar7 = (int *)FUN_009b2bb0(auStack_1c,&uStack_34);
      if (*piVar7 != 0) {
        iVar10 = *(int *)*param_2;
        if ((uint)(((int *)*param_2)[1] - iVar10 >> 3) <= uVar11) {
LAB_009a87c2:
          FUN_00577c40();
LAB_009a87c7:
          FUN_00577c40();
          pcVar3 = (code *)swi(3);
          (*pcVar3)();
          return;
        }
        iVar2 = *(int *)(iVar10 + 4 + uVar11 * 8);
        if (iVar2 != 0) {
          LOCK();
          piVar7 = (int *)(iVar2 + 4);
          *piVar7 = *piVar7 + 1;
          UNLOCK();
        }
        piStack_24 = *(int **)(iVar10 + uVar11 * 8);
        piStack_20 = *(int **)(iVar10 + 4 + uVar11 * 8);
        uStack_8._0_1_ = 1;
        if ((piStack_24 == (int *)0x0) || (piStack_24[1] - *piStack_24 >> 3 == 0)) {
LAB_009a8527:
          bVar4 = false;
        }
        else {
          iVar10 = *(int *)*param_3;
          if ((uint)(((int *)*param_3)[1] - iVar10 >> 3) <= uVar11) goto LAB_009a87c7;
          cVar5 = (**(code **)**(undefined4 **)(iVar10 + uVar11 * 8))
                            (&piStack_24,*(int *)(iStack_14 + 0x228) != 0);
          if (cVar5 == '\0') goto LAB_009a8527;
          bVar4 = true;
        }
        if (bVar4) {
          piStack_40 = (int *)0x0;
          uStack_8._0_1_ = 2;
          if ((uint)(((int *)*param_3)[1] - *(int *)*param_3 >> 3) <= uVar11) goto LAB_009a87c7;
          uVar12 = FUN_00f990b0();
          iVar2 = *(int *)(iStack_14 + 0x228);
          iVar10 = *(int *)*param_2;
          if ((uint)(((int *)*param_2)[1] - iVar10 >> 3) <= uVar11) goto LAB_009a87c2;
          iVar6 = *(int *)(iVar10 + 4 + uVar11 * 8);
          if (iVar6 != 0) {
            LOCK();
            piVar7 = (int *)(iVar6 + 4);
            *piVar7 = *piVar7 + 1;
            UNLOCK();
          }
          FUN_00f968c0(auStack_2c,*(undefined4 *)(iVar10 + uVar11 * 8),
                       *(undefined4 *)(iVar10 + 4 + uVar11 * 8),iVar2 != 0,uVar12,aiStack_64);
          if (piStack_40 != (int *)0x0) {
            (**(code **)(*piStack_40 + 0x10))
                      (CONCAT31((int3)((uint)aiStack_64 >> 8),piStack_40 != aiStack_64));
          }
        }
        else {
          if ((uint)(((int *)*param_3)[1] - *(int *)*param_3 >> 3) <= uVar11) goto LAB_009a87c7;
          uVar12 = FUN_00f990b0();
          iVar10 = FUN_00e2fd10(uVar12);
          pcVar9 = "Shirt";
          if (iVar10 != 0xb) {
            pcVar9 = "Pants";
          }
          FUN_0086f2f0(2,"Humanoid::ApplyDescription() Failed to load %s, default applied",pcVar9);
          piVar7 = (int *)FUN_01674e20(0x18);
          if (piVar7 == (int *)0x0) {
            piVar7 = (int *)0x0;
          }
          else {
            piVar7[1] = 1;
            piVar7[2] = 1;
            *piVar7 = (int)std::
                           _Ref_count_obj<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>
                           ::vftable;
            piVar7[3] = 0;
            piVar7[4] = 0;
            piVar7[5] = 0;
          }
          piVar1 = piVar7 + 3;
          uStack_8._0_1_ = 3;
          uStack_18 = *param_6;
          piStack_3c = piVar1;
          piStack_38 = piVar7;
          if ((uint)(((int *)*param_3)[1] - *(int *)*param_3 >> 3) <= uVar11) goto LAB_009a87c7;
          uVar12 = FUN_00f990b0();
          uVar8 = FUN_00e2fd10(uVar12);
          FUN_00bb3e50(uVar8,piVar1);
          piStack_40 = (int *)0x0;
          uStack_8._0_1_ = 4;
          if ((uint)(((int *)*param_3)[1] - *(int *)*param_3 >> 3) <= uVar11) goto LAB_009a87c7;
          uVar12 = FUN_00f990b0();
          iVar10 = *(int *)(iStack_14 + 0x228);
          if (piVar7 != (int *)0x0) {
            LOCK();
            piVar7[1] = piVar7[1] + 1;
            UNLOCK();
          }
          FUN_00f968c0(auStack_2c,piVar7 + 3,piVar7,iVar10 != 0,uVar12,aiStack_64);
          if (piStack_40 != (int *)0x0) {
            (**(code **)(*piStack_40 + 0x10))
                      (CONCAT31((int3)((uint)aiStack_64 >> 8),piStack_40 != aiStack_64));
          }
          if (piVar7 != (int *)0x0) {
            LOCK();
            iVar10 = piVar7[1] + -1;
            piVar7[1] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)*piVar7)();
              LOCK();
              iVar10 = piVar7[2] + -1;
              piVar7[2] = iVar10;
              UNLOCK();
              if (iVar10 == 0) {
                (**(code **)(*piVar7 + 4))();
              }
            }
          }
        }
        piVar7 = piStack_20;
        uStack_8._0_1_ = 0;
        if (piStack_20 != (int *)0x0) {
          LOCK();
          iVar10 = piStack_20[1] + -1;
          piStack_20[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piStack_20)();
            LOCK();
            piVar1 = piVar7 + 2;
            iVar10 = *piVar1 + -1;
            *piVar1 = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
      }
      uVar11 = uVar11 + 1;
    } while (uVar11 < (uint)(((int *)*param_2)[1] - *(int *)*param_2 >> 3));
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piVar7 = piStack_28 + 2;
    iVar10 = *piVar7;
    *piVar7 = *piVar7 + -1;
    UNLOCK();
    if (iVar10 == 1) {
      (**(code **)(*piStack_28 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18413 ; VA 0x009a87d0 ; FUN_009a87d0 */

bool FUN_009a87d0(undefined4 param_1,undefined4 param_2)

{
  undefined **ppuVar1;
  undefined **ppuVar2;
  bool bVar3;
  undefined auStack_2c [4];
  undefined *puStack_28;
  int iStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d40d8;
  pvStack_10 = ExceptionList;
  auStack_2c[0] = 0;
  uStack_14 = 0xb;
  ExceptionList = &pvStack_10;
  ppuVar1 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_14);
  ppuVar2 = ppuVar1 + -1;
  if (ppuVar1 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar2 = ppuVar1;
  }
  puStack_28 = *ppuVar2;
  iStack_24 = 0;
  uStack_20 = 0x3f800000;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 0;
  FUN_00e2e7d0(param_1,param_2,auStack_2c);
  bVar3 = iStack_24 != 0;
  FUN_00612320();
  ExceptionList = pvStack_10;
  return bVar3;
}



/* FUNCTION 18414 ; VA 0x009a8870 ; FUN_009a8870 */

bool FUN_009a8870(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00b63e30();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) goto LAB_009a88a2;
  }
  param_1 = 0;
LAB_009a88a2:
  return param_1 != 0;
}



/* FUNCTION 18415 ; VA 0x009a88b0 ; FUN_009a88b0 */

/* WARNING: Removing unreachable block (ram,0x009a8a6f) */
/* WARNING: Removing unreachable block (ram,0x009a8ac1) */
/* WARNING: Removing unreachable block (ram,0x009a8ab6) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_009a88b0(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  undefined *puVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined **ppuVar8;
  int iVar9;
  undefined4 *puVar10;
  undefined **ppuVar11;
  undefined4 *puVar12;
  undefined4 *puVar13;
  float10 fVar14;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d4100;
  pvStack_10 = ExceptionList;
  puStack_14 = *(undefined4 **)(param_2 + 0xc);
  puVar13 = *(undefined4 **)(param_1 + 0x14);
  ExceptionList = &pvStack_10;
  *(undefined4 **)(param_1 + 0xc) = puStack_14;
  if (puVar13 == (undefined4 *)0x0) {
    uVar7 = 0;
  }
  else {
    fVar14 = (float10)FUN_01725160(((double)*(int *)(param_1 + 4) +
                                   (double)(&DAT_018c0d90)[-(*(int *)(param_1 + 4) >> 0x1f)]) *
                                   (double)(float)puStack_14);
    if ((double)fVar14 < _DAT_018c4e98) {
      uVar7 = FUN_016f3eb1();
    }
    else {
      uVar7 = 0xffffffff;
    }
  }
  *(uint *)(param_1 + 0x10) = uVar7;
  if ((*(int *)(param_1 + 8) != 0) || (*(int *)(param_2 + 8) != 0)) {
    uVar2 = *(uint *)(param_2 + 8);
    if (uVar2 < uVar7) {
      puVar12 = puVar13 + *(int *)(param_1 + 4);
      for (; puVar13 != puVar12; puVar13 = puVar13 + 1) {
        *puVar13 = 0;
      }
    }
    else {
      fVar14 = (float10)FUN_01725280(((double)(int)uVar2 +
                                     (double)(&DAT_018c0d90)[-((int)uVar2 >> 0x1f)]) /
                                     (double)(float)puStack_14);
      if ((double)fVar14 + DAT_018c0d60 < _DAT_018c4e98) {
        puStack_14 = (undefined4 *)FUN_016f3eb1();
      }
      else {
        puStack_14 = (undefined4 *)0xffffffff;
      }
      ppuVar8 = (undefined **)
                FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_14);
      ppuVar11 = ppuVar8 + -1;
      if (ppuVar8 != &boost::lock_error::vftable_meta_ptr) {
        ppuVar11 = ppuVar8;
      }
      puVar3 = *ppuVar11;
      uStack_8 = 0;
      puStack_14 = (undefined4 *)0x0;
      FUN_005c24c0(&puStack_14,puVar3 + 1);
      if (*(int *)(param_1 + 0x14) != 0) {
        *(undefined4 *)((int)puVar3 * 4) =
             *(undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        iVar1 = *(int *)(param_1 + 4) * 4;
        uVar7 = iVar1 + 4;
        iVar4 = *(int *)(param_1 + 0x14);
        iVar9 = iVar4;
        if (0xfff < uVar7) {
          iVar9 = *(int *)(iVar4 + -4);
          uVar7 = iVar1 + 0x27;
          if (0x1f < (iVar4 - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar9,uVar7);
      }
      *(undefined **)(param_1 + 4) = puVar3;
      *(undefined4 *)(param_1 + 0x14) = 0;
      *(undefined4 *)(param_1 + 0x10) = 0;
    }
    puVar13 = (undefined4 *)0x0;
    if (*(int *)(param_1 + 8) != 0) {
      puVar13 = *(undefined4 **)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      *(undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4) = 0;
      *(undefined4 *)(param_1 + 8) = 0;
    }
    uStack_8 = 2;
    if (*(int *)(param_2 + 8) == 0) {
      puVar12 = (undefined4 *)0x0;
    }
    else {
      puVar12 = *(undefined4 **)(*(int *)(param_2 + 0x14) + *(int *)(param_2 + 4) * 4);
    }
    puVar6 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
    while (puVar12 != (undefined4 *)0x0) {
      if (puVar13 == (undefined4 *)0x0) {
        puVar10 = (undefined4 *)FUN_01674e20(0x10);
        *puVar10 = 0;
        puVar10[1] = 0;
        *(undefined8 *)(puVar10 + 2) = 0;
        puVar10[2] = puVar12[2];
      }
      else {
        puVar5 = (undefined4 *)*puVar13;
        *puVar13 = 0;
        puVar13[2] = puVar12[2];
        puVar10 = puVar13;
        puVar13 = puVar5;
      }
      puVar10[3] = puVar12[3];
      puVar10[1] = puVar12[1];
      *puVar6 = puVar10;
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
      puVar10 = (undefined4 *)*puVar6;
      puVar12 = (undefined4 *)*puVar12;
      uVar7 = (uint)puVar10[1] % *(uint *)(param_1 + 4);
      puStack_14 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
      if (*(int *)(*(int *)(param_1 + 0x14) + uVar7 * 4) == 0) {
        *puStack_14 = puVar6;
        puVar6 = puVar10;
      }
      else {
        *puVar6 = *puVar10;
        *puVar10 = *(undefined4 *)*puStack_14;
        *(undefined4 **)*puStack_14 = puVar10;
      }
    }
    while (puVar13 != (undefined4 *)0x0) {
      puVar12 = (undefined4 *)*puVar13;
      FUN_01674ea0(puVar13,0x10);
      puVar13 = puVar12;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18416 ; VA 0x009a8c40 ; FUN_009a8c40 */

void __fastcall FUN_009a8c40(int param_1)

{
  undefined4 uVar1;
  int *piVar2;
  code *pcVar3;
  undefined uVar4;
  char cVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uVar8;
  int iVar9;
  undefined8 *puVar10;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined8 uStack_d0;
  undefined4 uStack_c8;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined8 uStack_b8;
  undefined auStack_b0 [16];
  int *piStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  int iStack_94;
  int iStack_90;
  int iStack_8c;
  int iStack_88;
  undefined4 uStack_84;
  int *piStack_80;
  undefined4 uStack_7c;
  int *piStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  int *piStack_6c;
  int *piStack_68;
  int *piStack_64;
  int iStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  uint uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  ulonglong uStack_38;
  undefined4 uStack_30;
  int *piStack_2c;
  int iStack_28;
  undefined uStack_21;
  int *apiStack_20 [2];
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d424b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_60 = param_1;
  if (*(int *)(param_1 + 0x6d8) == 0) {
    ExceptionList = &pvStack_10;
    puVar6 = (undefined4 *)FUN_0099f430(&piStack_6c);
    uVar8 = *puVar6;
    uVar1 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x6d8) = uVar8;
    piVar2 = *(int **)(param_1 + 0x6dc);
    *(undefined4 *)(param_1 + 0x6dc) = uVar1;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar9 = piVar2[1] + -1;
      piVar2[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar9 = piVar2[2] + -1;
        piVar2[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    if (piStack_68 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_68[1] + -1;
      piStack_68[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_68)();
        LOCK();
        piVar2 = piStack_68 + 2;
        iVar9 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar9 == 1) {
          (**(code **)(*piStack_68 + 4))();
        }
      }
    }
    uStack_21 = 0;
    (**(code **)(*DAT_02119b74 + 0x10))(*(undefined4 *)(param_1 + 0x6d8),&uStack_21);
    FUN_008a65e0(param_1,0);
  }
  if ((*(int *)(param_1 + 0x34) != 0) &&
     (iVar9 = *(int *)(*(int *)(param_1 + 0x34) + 0xc), iVar7 = FUN_00b63e30(),
     (uint)*(ushort *)(iVar9 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
     (uint)*(ushort *)(iVar7 + 0x1da))) {
    iVar9 = *(int *)(param_1 + 0x228);
    if (iVar9 == 1) {
      iVar9 = *(int *)(param_1 + 0x3f0);
      if (iVar9 != 0) {
        uStack_70 = 0;
        piStack_6c = (int *)0x0;
        piStack_68 = (int *)0x0;
        uStack_8 = 0;
        FUN_009b6750(&uStack_70);
        FUN_009a98d0(iVar9,&uStack_70);
        FUN_0056d320();
        ExceptionList = pvStack_10;
        return;
      }
    }
    else {
      if (DAT_01d64ae8 != '\0') {
        if (iVar9 == 0) {
          uVar8 = *(undefined4 *)(param_1 + 0x348);
        }
        else {
          uVar8 = *(undefined4 *)(param_1 + 0x378);
        }
        FUN_0060dcd0(&piStack_6c,uVar8);
        uStack_8 = 1;
        if (*(int *)(param_1 + 0x228) == 0) {
          uVar8 = *(undefined4 *)(param_1 + 0x370);
        }
        else {
          uVar8 = *(undefined4 *)(param_1 + 0x380);
        }
        FUN_0060dcd0(&iStack_88,uVar8);
        uStack_8._0_1_ = 2;
        if (*(int *)(param_1 + 0x228) == 0) {
          uVar8 = *(undefined4 *)(param_1 + 0x350);
        }
        else {
          uVar8 = *(undefined4 *)(param_1 + 1000);
        }
        FUN_0060dcd0(&uStack_b8,uVar8);
        uStack_8._0_1_ = 3;
        if (*(int *)(param_1 + 0x228) == 0) {
          uVar8 = *(undefined4 *)(param_1 + 0x358);
        }
        else {
          uVar8 = *(undefined4 *)(param_1 + 0x3d0);
        }
        FUN_0060dcd0(&uStack_c0,uVar8);
        uStack_8._0_1_ = 4;
        if (*(int *)(param_1 + 0x228) == 0) {
          uVar8 = *(undefined4 *)(param_1 + 0x360);
        }
        else {
          uVar8 = *(undefined4 *)(param_1 + 0x3b8);
        }
        FUN_0060dcd0(&uStack_98,uVar8);
        uStack_8._0_1_ = 5;
        if (*(int *)(param_1 + 0x228) == 0) {
          uVar8 = *(undefined4 *)(param_1 + 0x368);
        }
        else {
          uVar8 = *(undefined4 *)(param_1 + 0x3a0);
        }
        FUN_0060dcd0(&piStack_2c,uVar8);
        uStack_8._0_1_ = 6;
        uVar4 = (undefined)uStack_8;
        uStack_8._0_1_ = 6;
        if (iStack_88 != 0) {
          uVar8 = FUN_009b7250();
          FUN_0060dcd0(&iStack_90,uVar8);
          uStack_8._0_1_ = 7;
          uVar4 = (undefined)uStack_8;
          uStack_8._0_1_ = 7;
          if (iStack_90 != 0) {
            FUN_009bb850(apiStack_20);
            uStack_8._0_1_ = 8;
            piStack_a0 = (int *)0x0;
            uStack_9c = 0xf;
            auStack_b0[0] = 0;
            pcVar3 = *(code **)(*apiStack_20[0] + 0x38);
            FUN_005542c0("RootJoint",9);
            uStack_8._0_1_ = 9;
            (*pcVar3)(auStack_b0);
            uStack_8._0_1_ = 8;
            FUN_005507b0();
            iVar9 = iStack_90;
            FUN_00c3d740(iStack_90);
            FUN_00c3d770(iStack_88);
            uStack_9c = 0;
            uStack_18 = 0;
            puVar6 = (undefined4 *)FUN_00d6a420(1);
            uStack_5c = *puVar6;
            uStack_58 = puVar6[1];
            uStack_54 = puVar6[2];
            uStack_50 = puVar6[3];
            uStack_4c = puVar6[4];
            uStack_48 = puVar6[5];
            uStack_44 = puVar6[6];
            uStack_40 = puVar6[7];
            uStack_3c = puVar6[8];
            uStack_30 = uStack_9c;
            uStack_38 = CONCAT44((int)uStack_18,(int)uStack_18);
            FUN_00c3ceb0(&uStack_5c);
            FUN_00c3cee0(&uStack_5c);
            FUN_008a65e0(iVar9,0);
            cVar5 = FUN_00f94350();
            if (((cVar5 == '\0') || (*(int *)(iStack_60 + 0x178) == 0)) ||
               (*(char *)(*(int *)(iStack_60 + 0x178) + 1) == '\0')) {
              FUN_00c18540(0x3dcccccd);
            }
            else {
              if (iStack_8c != 0) {
                LOCK();
                *(int *)(iStack_8c + 8) = *(int *)(iStack_8c + 8) + 1;
                UNLOCK();
              }
              uStack_18 = CONCAT44(iStack_8c,iStack_90);
              if (iStack_8c != 0) {
                LOCK();
                *(int *)(iStack_8c + 8) = *(int *)(iStack_8c + 8) + 1;
                UNLOCK();
              }
              uStack_8._0_1_ = 10;
              FUN_009b1bb0(iStack_90,iStack_8c,iVar9,&DAT_01d650a6);
              FUN_0056c200();
            }
            uStack_8._0_1_ = 7;
            FUN_00550b30();
            uVar4 = (undefined)uStack_8;
          }
          uStack_8._0_1_ = uVar4;
          FUN_009bb850(&piStack_78);
          uStack_8._0_1_ = 0xc;
          FUN_009bb850(&piStack_80);
          uStack_8._0_1_ = 0xd;
          FUN_009bb850(&piStack_a0);
          uStack_8._0_1_ = 0xe;
          FUN_009bb850(apiStack_20);
          uStack_8._0_1_ = 0xf;
          FUN_009bb850(&uStack_18);
          uStack_8._0_1_ = 0x10;
          uStack_38 = uStack_38 & 0xffffffff;
          uStack_30 = 0xf;
          uStack_44 = uStack_44 & 0xffffff00;
          pcVar3 = *(code **)(*piStack_78 + 0x38);
          FUN_005542c0("Right Shoulder",0xe);
          uStack_8._0_1_ = 0x11;
          (*pcVar3)(&uStack_44);
          uStack_8._0_1_ = 0x10;
          FUN_005507b0();
          uStack_38 = uStack_38 & 0xffffffff;
          uStack_30 = 0xf;
          uStack_44 = uStack_44 & 0xffffff00;
          pcVar3 = *(code **)(*piStack_80 + 0x38);
          FUN_005542c0("Left Shoulder",0xd);
          uStack_8._0_1_ = 0x12;
          (*pcVar3)(&uStack_44);
          uStack_8._0_1_ = 0x10;
          FUN_005507b0();
          uStack_38 = uStack_38 & 0xffffffff;
          uStack_30 = 0xf;
          uStack_44 = uStack_44 & 0xffffff00;
          pcVar3 = *(code **)(*piStack_a0 + 0x38);
          FUN_005542c0("Right Hip",9);
          uStack_8._0_1_ = 0x13;
          (*pcVar3)(&uStack_44);
          uStack_8._0_1_ = 0x10;
          FUN_005507b0();
          uStack_38 = uStack_38 & 0xffffffff;
          uStack_30 = 0xf;
          uStack_44 = uStack_44 & 0xffffff00;
          pcVar3 = *(code **)(*apiStack_20[0] + 0x38);
          FUN_005542c0("Left Hip",8);
          uStack_8._0_1_ = 0x14;
          (*pcVar3)(&uStack_44);
          uStack_8._0_1_ = 0x10;
          FUN_005507b0();
          uStack_38 = uStack_38 & 0xffffffff;
          uStack_30 = 0xf;
          uStack_44 = uStack_44 & 0xffffff00;
          pcVar3 = *(code **)(*(int *)uStack_18 + 0x38);
          FUN_005542c0(&DAT_018db7cc,4);
          uStack_8._0_1_ = 0x15;
          (*pcVar3)(&uStack_44);
          uStack_8._0_1_ = 0x10;
          FUN_005507b0();
          iVar9 = iStack_88;
          FUN_00c3d740(iStack_88);
          FUN_00c3d740(iVar9);
          FUN_00c3d740(iVar9);
          FUN_00c3d740(iVar9);
          FUN_00c3d740(iVar9);
          FUN_00c3d770((undefined4)uStack_b8);
          FUN_00c3d770(uStack_c0);
          FUN_00c3d770(uStack_98);
          FUN_00c3d770(piStack_2c);
          FUN_00c3d770(piStack_6c);
          iVar9 = FUN_009c6d40();
          FUN_00c3ceb0(iVar9);
          FUN_00c3ceb0(iVar9 + 0x30);
          FUN_00c3ceb0(iVar9 + 0x60);
          FUN_00c3ceb0(iVar9 + 0x90);
          FUN_00c3ceb0(iVar9 + 0xc0);
          FUN_00c3cee0(iVar9 + 0xf0);
          FUN_00c3cee0(iVar9 + 0x120);
          FUN_00c3cee0(iVar9 + 0x150);
          FUN_00c3cee0(iVar9 + 0x180);
          FUN_00c3cee0(iVar9 + 0x1b0);
          FUN_008a65e0(iStack_88,0);
          FUN_008a65e0(iStack_88,0);
          FUN_008a65e0(iStack_88,0);
          FUN_008a65e0(iStack_88,0);
          FUN_008a65e0(iStack_88,0);
          FUN_00550b30();
          FUN_00550b30();
          FUN_00550b30();
          FUN_00550b30();
          FUN_00550b30();
          FUN_00550b30();
          uVar4 = (undefined)uStack_8;
        }
        uStack_8._0_1_ = uVar4;
        FUN_00550b30();
        FUN_00550b30();
        FUN_00550b30();
        FUN_00550b30();
        FUN_00550b30();
        FUN_00550b30();
        ExceptionList = pvStack_10;
        return;
      }
      if (iVar9 == 0) {
        uStack_84 = *(undefined4 *)(param_1 + 0x350);
        uStack_9c = *(undefined4 *)(param_1 + 0x348);
        iStack_8c = *(undefined4 *)(param_1 + 0x358);
        uStack_74 = *(undefined4 *)(param_1 + 0x360);
        iStack_94 = *(int *)(param_1 + 0x370);
        uStack_7c = *(undefined4 *)(param_1 + 0x368);
      }
      else {
        uStack_9c = *(undefined4 *)(param_1 + 0x378);
        iStack_94 = *(int *)(param_1 + 0x380);
        uStack_84 = *(undefined4 *)(param_1 + 1000);
        iStack_8c = *(undefined4 *)(param_1 + 0x3d0);
        uStack_74 = *(undefined4 *)(param_1 + 0x3b8);
        uStack_7c = *(undefined4 *)(param_1 + 0x3a0);
      }
      if (iStack_94 != 0) {
        iStack_28 = FUN_009b7250();
        if (iStack_28 != 0) {
          FUN_009bb850(&piStack_6c);
          uStack_8 = 0x16;
          uStack_38 = uStack_38 & 0xffffffff;
          uStack_30 = 0xf;
          uStack_44 = uStack_44 & 0xffffff00;
          pcVar3 = *(code **)(*piStack_6c + 0x38);
          FUN_005542c0("RootJoint",9);
          uStack_8._0_1_ = 0x17;
          (*pcVar3)(&uStack_44);
          uStack_8._0_1_ = 0x16;
          FUN_005507b0();
          iVar9 = iStack_28;
          FUN_00c3d740(iStack_28);
          FUN_00c3d770(iStack_94);
          uStack_bc = 0;
          uStack_b8 = 0;
          puVar6 = (undefined4 *)FUN_00d6a420(1);
          uStack_f4 = *puVar6;
          uStack_f0 = puVar6[1];
          uStack_ec = puVar6[2];
          uStack_e8 = puVar6[3];
          uStack_e4 = puVar6[4];
          uStack_e0 = puVar6[5];
          uStack_dc = puVar6[6];
          uStack_d8 = puVar6[7];
          uStack_d4 = puVar6[8];
          uStack_c8 = uStack_bc;
          uStack_d0 = CONCAT44((int)uStack_b8,(int)uStack_b8);
          FUN_00c3ceb0(&uStack_f4);
          FUN_00c3cee0(&uStack_f4);
          FUN_008a65e0(iVar9,0);
          cVar5 = FUN_00f94350();
          if (((cVar5 == '\0') || (*(int *)(iStack_60 + 0x178) == 0)) ||
             (*(char *)(*(int *)(iStack_60 + 0x178) + 1) == '\0')) {
            FUN_00c18540(0x3dcccccd);
          }
          else {
            puVar10 = &uStack_18;
            FUN_0060e0c0(puVar10,iStack_28);
            if (uStack_18._4_4_ != 0) {
              LOCK();
              *(int *)(uStack_18._4_4_ + 8) = *(int *)(uStack_18._4_4_ + 8) + 1;
              UNLOCK();
            }
            uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
            FUN_009b1bb0((int *)uStack_18,uStack_18._4_4_,puVar10,&DAT_01d650b6);
            FUN_0056c200();
          }
          uStack_8 = 0xffffffff;
          FUN_00550b30();
        }
        FUN_009bb850(apiStack_20);
        uStack_8 = 0x1a;
        FUN_009bb850(&piStack_2c);
        uStack_8._0_1_ = 0x1b;
        FUN_009bb850(&piStack_64);
        uStack_8._0_1_ = 0x1c;
        FUN_009bb850(&uStack_18);
        uStack_8._0_1_ = 0x1d;
        FUN_009bb850(&piStack_6c);
        uStack_8._0_1_ = 0x1e;
        uStack_38 = uStack_38 & 0xffffffff;
        uStack_30 = 0xf;
        uStack_44 = uStack_44 & 0xffffff00;
        pcVar3 = *(code **)(*apiStack_20[0] + 0x38);
        FUN_005542c0("Right Shoulder",0xe);
        uStack_8._0_1_ = 0x1f;
        (*pcVar3)(&uStack_44);
        uStack_8._0_1_ = 0x1e;
        FUN_005507b0();
        uStack_38 = uStack_38 & 0xffffffff;
        uStack_30 = 0xf;
        uStack_44 = uStack_44 & 0xffffff00;
        pcVar3 = *(code **)(*piStack_2c + 0x38);
        FUN_005542c0("Left Shoulder",0xd);
        uStack_8._0_1_ = 0x20;
        (*pcVar3)(&uStack_44);
        uStack_8._0_1_ = 0x1e;
        FUN_005507b0();
        uStack_38 = uStack_38 & 0xffffffff;
        uStack_30 = 0xf;
        uStack_44 = uStack_44 & 0xffffff00;
        pcVar3 = *(code **)(*piStack_64 + 0x38);
        FUN_005542c0("Right Hip",9);
        uStack_8._0_1_ = 0x21;
        (*pcVar3)(&uStack_44);
        uStack_8._0_1_ = 0x1e;
        FUN_005507b0();
        uStack_38 = uStack_38 & 0xffffffff;
        uStack_30 = 0xf;
        uStack_44 = uStack_44 & 0xffffff00;
        pcVar3 = *(code **)(*(int *)uStack_18 + 0x38);
        FUN_005542c0("Left Hip",8);
        uStack_8._0_1_ = 0x22;
        (*pcVar3)(&uStack_44);
        uStack_8._0_1_ = 0x1e;
        FUN_005507b0();
        uStack_38 = uStack_38 & 0xffffffff;
        uStack_30 = 0xf;
        uStack_44 = uStack_44 & 0xffffff00;
        pcVar3 = *(code **)(*piStack_6c + 0x38);
        FUN_005542c0(&DAT_018db7cc,4);
        uStack_8._0_1_ = 0x23;
        (*pcVar3)(&uStack_44);
        uStack_8 = CONCAT31(uStack_8._1_3_,0x1e);
        FUN_005507b0();
        iVar9 = iStack_94;
        FUN_00c3d740(iStack_94);
        FUN_00c3d740(iVar9);
        FUN_00c3d740(iVar9);
        FUN_00c3d740(iVar9);
        FUN_00c3d740(iVar9);
        FUN_00c3d770(uStack_84);
        FUN_00c3d770(iStack_8c);
        FUN_00c3d770(uStack_74);
        FUN_00c3d770(uStack_7c);
        FUN_00c3d770(uStack_9c);
        iVar9 = FUN_009c6d40();
        FUN_00c3ceb0(iVar9);
        FUN_00c3ceb0(iVar9 + 0x30);
        FUN_00c3ceb0(iVar9 + 0x60);
        FUN_00c3ceb0(iVar9 + 0x90);
        FUN_00c3ceb0(iVar9 + 0xc0);
        FUN_00c3cee0(iVar9 + 0xf0);
        FUN_00c3cee0(iVar9 + 0x120);
        FUN_00c3cee0(iVar9 + 0x150);
        FUN_00c3cee0(iVar9 + 0x180);
        FUN_00c3cee0(iVar9 + 0x1b0);
        iVar9 = iStack_94;
        FUN_008a65e0(iStack_94,0);
        FUN_008a65e0(iVar9,0);
        FUN_008a65e0(iVar9,0);
        FUN_008a65e0(iVar9,0);
        FUN_008a65e0(iVar9,0);
        FUN_00550b30();
        FUN_00550b30();
        FUN_00550b30();
        FUN_00550b30();
        FUN_00550b30();
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18417 ; VA 0x009a98d0 ; FUN_009a98d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_009a98d0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined8 uVar1;
  char cVar2;
  int *piVar3;
  int *piVar4;
  float *pfVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  char *pcVar9;
  uint uVar10;
  uint *puVar11;
  uint uVar12;
  int *piVar13;
  float fVar14;
  float fStack_d0;
  float fStack_cc;
  float fStack_c8;
  float fStack_c4;
  float fStack_c0;
  float fStack_bc;
  float fStack_b8;
  float fStack_b4;
  float fStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  int *piStack_98;
  uint auStack_94 [4];
  undefined4 uStack_84;
  uint uStack_80;
  undefined8 uStack_7c;
  float fStack_74;
  int iStack_70;
  int *piStack_6c;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  int iStack_5c;
  float fStack_58;
  int iStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  int *piStack_48;
  int *piStack_44;
  int *piStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  uint uStack_20;
  int *piStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d428e;
  pvStack_10 = ExceptionList;
  uStack_50 = 0;
  uStack_4c = 0;
  ExceptionList = &pvStack_10;
  iStack_54 = param_1;
  uStack_50 = FUN_0089c660();
  fStack_3c = 0.0;
  fStack_38 = 0.0;
  fStack_34 = 0.0;
  fStack_30 = 0.0;
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  if (**(char **)(param_1 + 0x230) == (char)*(char **)(param_1 + 0x230)) goto LAB_009a9fbe;
  FUN_009c71f0(param_2,param_3,&uStack_50,0,&fStack_3c,&fStack_38,&fStack_34,&fStack_30);
  if ((DAT_018e452c < fStack_34) && (DAT_018e452c < fStack_30)) {
    piVar13 = (int *)0x0;
    piStack_1c = (int *)0x0;
    piStack_48 = (int *)0x0;
    piStack_44 = (int *)0x0;
    piStack_2c = (int *)0x0;
    piStack_40 = (int *)0x0;
    uStack_8._0_1_ = 1;
    if (fStack_34 <= fStack_30) {
      fStack_58 = fStack_30 / fStack_34;
      uStack_14 = 0;
      piStack_18 = (int *)*param_3;
      uStack_20 = (uint)((int)param_3[1] + (3 - (int)piStack_18)) >> 2;
      if ((int *)param_3[1] < piStack_18) {
        uStack_20 = 0;
      }
      if (uStack_20 == 0) goto LAB_009a9b8f;
      do {
        piStack_28 = (int *)*piStack_18;
        piVar4 = (int *)piStack_28[10];
        piStack_1c = (int *)piVar4[4];
        piVar3 = piVar4;
        if (0xf < (uint)piVar4[5]) {
          piVar3 = (int *)*piVar4;
        }
        piStack_24 = piStack_28;
        cVar2 = FUN_0055c360(piVar3,piStack_1c,"LeftUpperLeg",0xc);
        if (cVar2 == '\0') {
          piVar3 = piVar4;
          if (0xf < (uint)piVar4[5]) {
            piVar3 = (int *)*piVar4;
          }
          cVar2 = FUN_0055c360(piVar3,piStack_1c,"LeftLowerLeg",0xc);
          if (cVar2 != '\0') goto LAB_009a9b46;
          if (0xf < (uint)piVar4[5]) {
            piVar4 = (int *)*piVar4;
          }
          cVar2 = FUN_0055c360(piVar4,piStack_1c,"LeftFoot",8);
          if (cVar2 != '\0') goto LAB_009a9b46;
        }
        else {
LAB_009a9b46:
          if (piStack_2c == piVar13) {
            FUN_006030d0(piVar13,&piStack_24);
            piStack_2c = piStack_40;
            piVar13 = piStack_44;
          }
          else {
            *piVar13 = (int)piStack_28;
            piStack_44 = piVar13 + 1;
            piVar13 = piStack_44;
          }
        }
        uStack_14 = uStack_14 + 1;
        piStack_18 = piStack_18 + 1;
      } while (uStack_14 != uStack_20);
      piStack_1c = piStack_48;
    }
    else {
      fStack_58 = fStack_34 / fStack_30;
      uStack_14 = 0;
      piStack_18 = (int *)*param_3;
      uStack_20 = (uint)((int)param_3[1] + (3 - (int)piStack_18)) >> 2;
      if ((int *)param_3[1] < piStack_18) {
        uStack_20 = 0;
      }
      if (uStack_20 == 0) {
LAB_009a9b8f:
        uStack_14 = 0;
      }
      else {
        do {
          piStack_28 = (int *)*piStack_18;
          piVar4 = (int *)piStack_28[10];
          piStack_1c = (int *)piVar4[4];
          piVar3 = piVar4;
          if (0xf < (uint)piVar4[5]) {
            piVar3 = (int *)*piVar4;
          }
          piStack_24 = piStack_28;
          cVar2 = FUN_0055c360(piVar3,piStack_1c,"RightUpperLeg",0xd);
          if (cVar2 == '\0') {
            piVar3 = piVar4;
            if (0xf < (uint)piVar4[5]) {
              piVar3 = (int *)*piVar4;
            }
            cVar2 = FUN_0055c360(piVar3,piStack_1c,"RightLowerLeg",0xd);
            if (cVar2 != '\0') goto LAB_009a9a50;
            if (0xf < (uint)piVar4[5]) {
              piVar4 = (int *)*piVar4;
            }
            cVar2 = FUN_0055c360(piVar4,piStack_1c,"RightFoot",9);
            if (cVar2 != '\0') goto LAB_009a9a50;
          }
          else {
LAB_009a9a50:
            if (piStack_2c == piVar13) {
              FUN_006030d0(piVar13,&piStack_24);
              piStack_2c = piStack_40;
              piVar13 = piStack_44;
            }
            else {
              *piVar13 = (int)piStack_28;
              piStack_44 = piVar13 + 1;
              piVar13 = piStack_44;
            }
          }
          uStack_14 = uStack_14 + 1;
          piStack_18 = piStack_18 + 1;
        } while (uStack_14 != uStack_20);
        piStack_1c = piStack_48;
      }
    }
    piStack_28 = piStack_1c;
    piStack_48 = piStack_1c;
    if (piStack_1c != piVar13) {
      do {
        piStack_24 = (int *)*piStack_28;
        uStack_9c = 0;
        piStack_98 = (int *)0x0;
        puVar11 = (uint *)piStack_24[10];
        uVar12 = puVar11[4];
        if (0xf < puVar11[5]) {
          puVar11 = (uint *)*puVar11;
        }
        if (uVar12 < 0x10) {
          uStack_ac = *puVar11;
          uStack_a8 = puVar11[1];
          uStack_a4 = puVar11[2];
          uStack_a0 = puVar11[3];
          piStack_18 = (int *)&DAT_0000000f;
          uStack_14 = uStack_ac;
        }
        else {
          piStack_18 = (int *)(uVar12 | 0xf);
          if ((int *)0x7fffffff < piStack_18) {
            piStack_18 = (int *)0x7fffffff;
          }
          piVar13 = (int *)((int)piStack_18 + 1);
          if (piVar13 < &DAT_00001000) {
            if (piVar13 == (int *)0x0) {
              uStack_ac = 0;
            }
            else {
              uStack_ac = FUN_01674e20(piVar13);
            }
          }
          else {
            piVar4 = piStack_18 + 9;
            if (piVar4 <= piVar13) {
              piVar4 = (int *)0xffffffff;
            }
            iVar6 = FUN_01674e20(piVar4);
            if (iVar6 == 0) goto LAB_009aa066;
            uStack_ac = iVar6 + 0x23U & 0xffffffe0;
            *(int *)(uStack_ac - 4) = iVar6;
          }
          uStack_14 = uStack_ac;
          FUN_0170c6f0(uStack_ac,puVar11,uVar12 + 1);
        }
        piVar13 = piStack_24;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        uStack_9c = uVar12;
        piStack_98 = piStack_18;
        FUN_009b5ee0(&fStack_b8,piStack_24);
        pfVar5 = (float *)FUN_00b08320();
        fStack_68 = pfVar5[2] / fStack_b0;
        fStack_60 = *pfVar5 / fStack_b8;
        fStack_64 = (pfVar5[1] / fStack_b4) * fStack_58;
        fStack_bc = fStack_68 * fStack_b0;
        fStack_c4 = fStack_60 * fStack_b8;
        fStack_c0 = fStack_64 * fStack_b4;
        (**(code **)(*piVar13 + 0xe8))(&fStack_c4);
        uVar12 = 0;
        uStack_20 = 0;
        iVar6 = FUN_005d6c30();
        if (iVar6 != 0) {
          do {
            iVar6 = *(int *)(*(int *)piVar13[0xb] + uVar12 * 8);
            if ((iVar6 == 0) ||
               (iVar8 = *(int *)(iVar6 + 0xc), iVar7 = FUN_00d6bbd0(), iStack_5c = iVar6,
               (uint)*(ushort *)(iVar7 + 0x1da) <
               (uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8))) {
              iStack_5c = 0;
            }
            if ((iVar6 == 0) ||
               (iVar8 = *(int *)(iVar6 + 0xc), iVar7 = FUN_00d77b00(),
               (uint)*(ushort *)(iVar7 + 0x1da) <
               (uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8))) {
              iVar6 = 0;
            }
            iVar8 = iStack_5c;
            if (iVar6 != 0) {
              iVar8 = 0;
            }
            FUN_0060dcd0(&iStack_70,iVar8);
            uStack_8._0_1_ = 3;
            if (iStack_70 != 0) {
              uStack_84 = 0;
              uStack_80 = 0xf;
              auStack_94[0] = auStack_94[0] & 0xffffff00;
              pcVar9 = PTR_DAT_01d64a08;
              do {
                cVar2 = *pcVar9;
                pcVar9 = pcVar9 + 1;
              } while (cVar2 != '\0');
              FUN_005542c0(PTR_DAT_01d64a08,(int)pcVar9 - (int)(PTR_DAT_01d64a08 + 1));
              uStack_8 = CONCAT31(uStack_8._1_3_,4);
              iVar6 = FUN_008a1240(auStack_94);
              if ((iVar6 == 0) ||
                 (iVar8 = *(int *)(iVar6 + 0xc), iVar7 = FUN_00dafce0(),
                 (uint)*(ushort *)(iVar7 + 0x1da) <
                 (uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8))) {
                iVar6 = 0;
              }
              uStack_8._0_1_ = 3;
              if (0xf < uStack_80) {
                uVar10 = uStack_80 + 1;
                uVar12 = auStack_94[0];
                if (0xfff < uVar10) {
                  uVar12 = *(uint *)(auStack_94[0] - 4);
                  uVar10 = uStack_80 + 0x24;
                  if (0x1f < (auStack_94[0] - uVar12) - 4) goto LAB_009aa066;
                }
                FUN_01674ea0(uVar12,uVar10);
              }
              uStack_84 = 0;
              uStack_80 = 0xf;
              auStack_94[0] = auStack_94[0] & 0xffffff00;
              if (iVar6 != 0) {
                uVar1 = *(undefined8 *)(iVar6 + 0x54);
                fStack_74 = *(float *)(iVar6 + 0x5c);
                uStack_7c._0_4_ = (float)uVar1;
                fStack_d0 = fStack_60 * (float)uStack_7c;
                uStack_7c._4_4_ = (float)((ulonglong)uVar1 >> 0x20);
                fStack_cc = fStack_64 * uStack_7c._4_4_;
                fStack_c8 = fStack_68 * fStack_74;
                uStack_7c = uVar1;
                FUN_00d6dad0(&fStack_d0);
              }
            }
            piVar13 = piStack_6c;
            uStack_8 = CONCAT31(uStack_8._1_3_,2);
            if (piStack_6c != (int *)0x0) {
              LOCK();
              iVar6 = piStack_6c[1] + -1;
              piStack_6c[1] = iVar6;
              UNLOCK();
              if (iVar6 == 0) {
                (**(code **)*piStack_6c)();
                LOCK();
                piVar4 = piVar13 + 2;
                iVar6 = *piVar4 + -1;
                *piVar4 = iVar6;
                UNLOCK();
                if (iVar6 == 0) {
                  (**(code **)(*piVar13 + 4))();
                }
              }
            }
            piVar13 = piStack_24;
            uVar12 = uStack_20 + 1;
            uStack_20 = uVar12;
            uVar10 = FUN_005d6c30();
          } while (uVar12 < uVar10);
        }
        uStack_8._0_1_ = 1;
        if (&DAT_0000000f < piStack_18) {
          piVar13 = (int *)((int)piStack_18 + 1);
          uVar12 = uStack_14;
          if ((int *)0xfff < piVar13) {
            uVar12 = *(uint *)(uStack_14 - 4);
            piVar13 = piStack_18 + 9;
            if (0x1f < (uStack_14 - uVar12) - 4) goto LAB_009aa066;
          }
          FUN_01674ea0(uVar12,piVar13);
        }
        piStack_28 = piStack_28 + 1;
      } while (piStack_28 != piStack_44);
    }
    uStack_8._0_1_ = 0;
    param_1 = iStack_54;
    if (piStack_1c != (int *)0x0) {
      uVar12 = (int)piStack_2c - (int)piStack_1c & 0xfffffffc;
      piVar13 = piStack_1c;
      if (0xfff < uVar12) {
        piVar13 = (int *)piStack_1c[-1];
        uVar12 = uVar12 + 0x23;
        if (0x1f < (uint)((int)piStack_1c + (-4 - (int)piVar13))) {
LAB_009aa066:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(piVar13,uVar12);
      param_1 = iStack_54;
    }
  }
  FUN_009abb30();
LAB_009a9fbe:
  fStack_30 = 0.0;
  fStack_34 = 0.0;
  fStack_38 = 0.0;
  fStack_3c = 0.0;
  FUN_009c71f0(param_2,param_3,&uStack_50,1,&fStack_3c,&fStack_38,&fStack_34,&fStack_30);
  if (**(char **)(param_1 + 0x230) != (char)*(char **)(param_1 + 0x230)) {
    fVar14 = fStack_38;
    if (fStack_38 <= fStack_3c) {
      fVar14 = fStack_3c;
    }
    if (((float)(double)CONCAT44((uint)((ulonglong)(double)(fStack_3c - fStack_38) >> 0x20) &
                                 DAT_018c0da0._4_4_,
                                 SUB84((double)(fStack_3c - fStack_38),0) & (uint)DAT_018c0da0) <
         ((float)_DAT_01d6499c / DAT_018ce324) * fVar14) &&
       (fVar14 = fStack_38, fStack_3c <= fStack_38)) {
      fVar14 = fStack_3c;
    }
    FUN_009c3910(fVar14);
  }
  FUN_009abb30();
  FUN_01674ea0(uStack_50,0x14);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18418 ; VA 0x009aa070 ; FUN_009aa070 */

void __thiscall FUN_009aa070(int param_1,int param_2)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  code *pcStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d42a8;
  pvStack_10 = ExceptionList;
  if (param_2 != 0) {
    ExceptionList = &pvStack_10;
    if (DAT_01d64af0 != '\0') {
      ExceptionList = &pvStack_10;
      FUN_009c4910(0);
    }
    uStack_24 = 0;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_8 = 0;
    if (((param_1 != 0) && (*(int *)(param_1 + 0x34) != 0)) &&
       (iVar1 = *(int *)(*(int *)(param_1 + 0x34) + 0xc), iVar4 = FUN_00b63e30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
       (uint)*(ushort *)(iVar4 + 0x1da))) {
      puStack_14 = &uStack_24;
      pcStack_18 = FUN_009abd70;
      FUN_00917910(&pcStack_18);
    }
    FUN_009a98d0(param_2,&uStack_24);
    if (DAT_01d64af0 == '\0') {
      puStack_14 = (undefined4 *)0x0;
      param_2 = 0;
      if (DAT_01d641ec == '\0') {
        FUN_009c1ba0(*(undefined8 *)(param_1 + 0x324),*(undefined4 *)(param_1 + 0x32c),
                     *(undefined4 *)(param_1 + 0x330));
      }
      else {
        FUN_009b3a80(&puStack_14,&param_2);
        FUN_009c2010(*(undefined8 *)(param_1 + 0x324),*(undefined4 *)(param_1 + 0x32c),
                     *(undefined4 *)(param_1 + 0x330),puStack_14,param_2);
      }
    }
    if (((param_1 != 0) && (iVar1 = *(int *)(param_1 + 0x34), iVar1 != 0)) &&
       ((iVar4 = *(int *)(iVar1 + 0xc), iVar5 = FUN_00b63e30(),
        (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
        (uint)*(ushort *)(iVar5 + 0x1da) &&
        (puVar2 = *(undefined4 **)(iVar1 + 0x2c), puVar2 != (undefined4 *)0x0)))) {
      piVar3 = (int *)puVar2[1];
      for (piVar6 = (int *)*puVar2; piVar6 != piVar3; piVar6 = piVar6 + 2) {
        param_2 = *piVar6;
        if ((param_2 != 0) &&
           (iVar1 = *(int *)(param_2 + 0xc), iVar4 = FUN_00a697d0(),
           (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
           (uint)*(ushort *)(iVar4 + 0x1da))) {
          if (param_2 != 0) {
            FUN_00a6b120();
          }
          break;
        }
      }
    }
    FUN_0056d320();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18419 ; VA 0x009aa270 ; FUN_009aa270 */

void __fastcall FUN_009aa270(int param_1)

{
  int iVar1;
  undefined auStack_10 [12];
  
  if (*(int *)(param_1 + 0x228) == 0) {
    iVar1 = *(int *)(param_1 + 0x340);
  }
  else {
    iVar1 = *(int *)(param_1 + 0x3f0);
  }
  if (iVar1 != 0) {
    FUN_009aa070(iVar1);
    return;
  }
  FUN_00550130("Humanoid has no HumanoidRootPart.");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 18420 ; VA 0x009aa2c0 ; FUN_009aa2c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float * __thiscall FUN_009aa2c0(int param_1,float *param_2)

{
  float fVar1;
  ulonglong uVar2;
  char cVar3;
  ulonglong *puVar4;
  int iVar5;
  uint uVar6;
  bool bVar7;
  float10 fVar8;
  double dVar9;
  float fVar10;
  float fVar11;
  undefined auStack_64 [12];
  undefined auStack_58 [12];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  float fStack_44;
  undefined8 uStack_40;
  float fStack_38;
  undefined8 uStack_30;
  undefined8 uStack_28;
  undefined8 uStack_20;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  undefined uStack_5;
  
  *param_2 = 0.0;
  param_2[1] = 0.0;
  param_2[2] = 0.0;
  param_2[3] = 0.0;
  param_2[4] = 0.0;
  param_2[5] = 0.0;
  uVar2 = *(ulonglong *)(param_1 + 0x7c);
  fStack_38 = *(float *)(param_1 + 0x84);
  uStack_40._0_4_ = (float)uVar2;
  uStack_40._4_4_ = (float)(uVar2 >> 0x20);
  if (((NAN((float)uStack_40) == ((float)uStack_40 == 0.0)) ||
      (NAN(uStack_40._4_4_) == (uStack_40._4_4_ == 0.0))) || (NAN(fStack_38) == (fStack_38 == 0.0)))
  {
    uStack_40 = uVar2;
    if (*(int **)(param_1 + 0x5c4) == (int *)0x0) {
      bVar7 = false;
      fVar11 = (float)uStack_40;
      fVar10 = uStack_40._4_4_;
    }
    else {
      iVar5 = (**(code **)(**(int **)(param_1 + 0x5c4) + 0x3c))();
      bVar7 = iVar5 == 4;
      fVar11 = (float)uStack_40;
      fVar10 = uStack_40._4_4_;
    }
    if (!bVar7) {
      fVar10 = 0.0;
      uStack_40 = uStack_40 & 0xffffffff;
    }
    if (((NAN(fVar11) == (fVar11 == 0.0)) || (NAN(fVar10) == (fVar10 == 0.0))) ||
       (NAN(fStack_38) == (fStack_38 == 0.0))) {
      puVar4 = (ulonglong *)FUN_00c94eb0(auStack_58,&uStack_40);
      uStack_40 = *puVar4;
      fStack_38 = *(float *)(puVar4 + 1);
    }
  }
  else {
    uStack_40 = *(ulonglong *)(param_1 + 0x88);
    fStack_38 = *(float *)(param_1 + 0x90);
    fVar10 = (float)uStack_40;
    if ((((NAN(fVar10) == (fVar10 == 0.0)) ||
         (NAN(*(float *)(param_1 + 0x8c)) == (*(float *)(param_1 + 0x8c) == 0.0))) ||
        (NAN(*(float *)(param_1 + 0x90)) == (*(float *)(param_1 + 0x90) == 0.0))) &&
       (fVar10 = *(float *)(param_1 + 0x8c) * *(float *)(param_1 + 0x8c) + fVar10 * fVar10 +
                 *(float *)(param_1 + 0x90) * *(float *)(param_1 + 0x90),
       (NAN(fVar10) || NAN(DAT_018ce2f8)) == (fVar10 == DAT_018ce2f8))) {
      FUN_01160810();
    }
  }
  if ((param_1 != 0x134) && (fStack_c = *(float *)(param_1 + -0x100), fStack_c != 0.0)) {
    FUN_00b63e30();
  }
  fStack_c = (float)FUN_00980070();
  if ((*(char *)(param_1 + 0x15e) != '\0') && (cVar3 = FUN_009ab310(), cVar3 != '\0')) {
    uStack_4c = 0;
    uStack_48 = 0;
    fStack_44 = 0.0;
    FUN_009b7850(&uStack_5,&uStack_4c);
    uStack_40 = CONCAT44(uStack_48,uStack_4c);
    fStack_38 = fStack_44;
  }
  fStack_10 = (float)(**(int **)(param_1 + 0xbc) + (int)*(int **)(param_1 + 0xbc));
  fVar10 = (float)(**(uint **)(param_1 + 0xc4) ^ (uint)*(uint **)(param_1 + 0xc4));
  *(ulonglong *)param_2 =
       CONCAT44(fStack_10 * uStack_40._4_4_ * fVar10,(float)uStack_40 * fStack_10 * fVar10);
  param_2[2] = fStack_38 * fStack_10 * fVar10;
  fStack_14 = (float)(**(uint **)(param_1 + 0xc0) ^ (uint)*(uint **)(param_1 + 0xc0));
  if (fStack_10 <= fStack_14) {
    uVar6 = 0;
  }
  else {
    iVar5 = *(int *)(param_1 + 0xd0) - (param_1 + 0xd0);
    uStack_20 = (double)CONCAT44(iVar5,(undefined4)uStack_20);
    uVar6 = iVar5 + 1;
  }
  uStack_28 = (double)CONCAT44(uVar6,(undefined4)uStack_28);
  uStack_30 = (double)CONCAT44(uVar6,(undefined4)uStack_30);
  *(uint *)(param_1 + 0xd0) = param_1 + 0xd0 + uVar6;
  if (8 < uVar6) {
    fStack_18 = 4.9706146e-34;
    DAT_01eaf558 = DAT_01eaf558 | 0x200000;
  }
  if (_DAT_019399b0 <
      (double)(float)(double)CONCAT44((uint)((ulonglong)(double)fVar10 >> 0x20) &
                                      (uint)((ulonglong)DAT_018c0da0 >> 0x20),
                                      SUB84((double)fVar10,0) & (uint)DAT_018c0da0)) {
    fStack_18 = 5.288325e-34;
    DAT_01eaf558 = DAT_01eaf558 | 0x200000;
  }
  if (*(char *)(param_1 + 0xf1) < '\x01') goto LAB_009aa790;
  bVar7 = fStack_c != 0.0;
  fStack_c = fVar10;
  if (bVar7) {
    FUN_0090c170();
    iVar5 = FUN_0086b740();
    if (iVar5 == 1) {
      param_2[4] = *(float *)(param_1 + 0xb8) * DAT_018f997c * DAT_018ce2f4;
      fVar10 = fStack_c;
      goto LAB_009aa790;
    }
  }
  dVar9 = (double)(*param_2 * *param_2 + param_2[1] * param_2[1] + param_2[2] * param_2[2]);
  fVar10 = fStack_c;
  if (NAN(dVar9) != (dVar9 == 0.0)) goto LAB_009aa790;
  uVar6 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  uStack_30 = (double)CONCAT44((uint)((ulonglong)dVar9 >> 0x20) & uVar6,
                               SUB84(dVar9,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
  uStack_20 = (double)CONCAT44((uint)((ulonglong)(dVar9 - 0.0) >> 0x20) & uVar6,
                               SUB84(dVar9 - 0.0,0) & (uint)DAT_018c0da0);
  fVar8 = (float10)FUN_01160810();
  uStack_28 = (double)fVar8;
  dVar9 = DAT_018f76b0;
  if ((NAN(uStack_30) || NAN(uStack_28)) == (uStack_30 == uStack_28)) {
    dVar9 = uStack_30 * DAT_018f76b0;
  }
  fVar10 = fStack_c;
  if (uStack_20 <= dVar9) goto LAB_009aa790;
  uStack_30 = (double)(float)((uint)param_2[2] ^ DAT_018c4ea0);
  fVar8 = (float10)FUN_01728580();
  fStack_18 = (float)fVar8;
  if (*(int *)(param_1 + 0xf4) == 0) {
    iVar5 = *(int *)(param_1 + 0x20c);
  }
  else {
    iVar5 = *(int *)(param_1 + 700);
  }
  if (iVar5 == 0) {
    if (*(int *)(param_1 + 0xf4) == 0) {
      iVar5 = *(int *)(param_1 + 0x23c);
    }
    else {
      iVar5 = *(int *)(param_1 + 0x24c);
    }
    if (iVar5 != 0) goto LAB_009aa72d;
    fVar10 = 0.0;
  }
  else {
LAB_009aa72d:
    FUN_00b077e0();
    iVar5 = FUN_011612d0(auStack_64,2);
    uStack_30 = (double)*(float *)(iVar5 + 8);
    fVar8 = (float10)FUN_01728580();
    fVar10 = (float)fVar8;
  }
  fVar8 = (float10)FUN_009bf200((double)(fStack_18 - fVar10));
  param_2[4] = (float)(fVar8 * (float10)DAT_018f997c);
  fVar10 = fStack_c;
LAB_009aa790:
  fStack_c = fVar10;
  if (DAT_01ee41ed != '\0') {
    fVar10 = param_2[1];
    fVar11 = *param_2;
    fVar1 = param_2[2];
    if (DAT_018fd178 < fVar11 * fVar11 + fVar10 * fVar10 + fVar1 * fVar1) {
      FUN_016774d0(DAT_01ee41ed,"Moving velocity: %f %f %f",fVar11,fVar10,fVar1,0);
    }
  }
  return param_2;
}



/* FUNCTION 18421 ; VA 0x009aa810 ; FUN_009aa810 */

float10 FUN_009aa810(float param_1,float param_2,float param_3)

{
  double dVar1;
  
  if ((NAN(param_1) || NAN(DAT_018ce2f0)) != (param_1 == DAT_018ce2f0)) {
    return (float10)0;
  }
  param_1 = ((float)DAT_01d6fdd0 * param_2 * DAT_018daf54) / param_1;
  dVar1 = (double)((param_1 + param_1) * param_3);
  return (float10)(float)(double)CONCAT44((uint)((ulonglong)dVar1 >> 0x20) & DAT_018c0da0._4_4_,
                                          SUB84(dVar1,0) & (uint)DAT_018c0da0);
}



/* FUNCTION 18422 ; VA 0x009aa870 ; FUN_009aa870 */

float10 FUN_009aa870(float param_1,float param_2)

{
  double dVar1;
  
  if ((NAN(param_1) || NAN(DAT_018ce2f0)) != (param_1 == DAT_018ce2f0)) {
    return (float10)0;
  }
  dVar1 = (double)((float)DAT_01d6fdd0 * param_2 * DAT_018daf54);
  FUN_01726ab0();
  return (float10)((float)dVar1 / (param_1 + param_1));
}



/* FUNCTION 18423 ; VA 0x009aa8d0 ; FUN_009aa8d0 */

float10 __fastcall FUN_009aa8d0(int param_1)

{
  double dVar1;
  float fVar2;
  float fVar3;
  
  if (*(char *)(param_1 + 0x20c) != '\0') {
    return (float10)(float)(**(uint **)(param_1 + 0x208) ^ (uint)*(uint **)(param_1 + 0x208));
  }
  if (*(int *)(param_1 + 0x6f4) != 0) {
    fVar2 = *(float *)(*(int *)(param_1 + 0x6f4) + 0xc4);
    dVar1 = (double)((fVar2 + fVar2) *
                    (float)(**(int **)(param_1 + 0x210) + (int)*(int **)(param_1 + 0x210)));
    FUN_017267a0();
    fVar3 = (float)dVar1 / ((float)DAT_01d6fdd0 * DAT_018daf54);
    fVar2 = 0.0;
    if (0.0 <= fVar3) {
      fVar2 = fVar3;
    }
    fVar3 = DAT_018ce324;
    if (fVar2 <= DAT_018ce324) {
      fVar3 = fVar2;
    }
    return (float10)fVar3;
  }
  return (float10)0;
}



/* FUNCTION 18424 ; VA 0x009aa970 ; FUN_009aa970 */

float10 FUN_009aa970(float param_1,float param_2)

{
  double dVar1;
  
  dVar1 = (double)((param_1 + param_1) * param_2);
  FUN_017267a0();
  return (float10)((float)dVar1 / ((float)DAT_01d6fdd0 * DAT_018daf54));
}



/* FUNCTION 18425 ; VA 0x009aa9c0 ; FUN_009aa9c0 */

void FUN_009aa9c0(int *param_1,int *param_2,int param_3,undefined4 param_4,int param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  code *pcVar4;
  char cVar5;
  undefined **ppuVar6;
  int *piVar7;
  int iVar8;
  undefined8 *puVar9;
  undefined **ppuVar10;
  uint uVar11;
  undefined8 uVar12;
  undefined auStack_54 [4];
  undefined *puStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined8 uStack_34;
  undefined8 uStack_2c;
  undefined8 uStack_24;
  int *piStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d42d0;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_3 + 8) != 0) {
    ExceptionList = &pvStack_10;
    if (param_5 != param_3) {
      ExceptionList = &pvStack_10;
      FUN_009a88b0(param_3,param_3);
    }
    auStack_54[0] = 0;
    uStack_14 = 0xb;
    ppuVar6 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_14);
    ppuVar10 = ppuVar6 + -1;
    if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar10 = ppuVar6;
    }
    puStack_50 = *ppuVar10;
    uStack_4c = 0;
    uStack_48 = 0x3f800000;
    uStack_44 = 0;
    uStack_40 = 0;
    uStack_8 = 0;
    FUN_00e30f30(auStack_54);
    uVar11 = 0;
    if (((int *)*param_1)[1] - *(int *)*param_1 >> 3 != 0) {
      do {
        iVar8 = *(int *)*param_2;
        if ((uint)(((int *)*param_2)[1] - iVar8 >> 3) <= uVar11) {
          FUN_00577c40();
LAB_009aabcf:
          FUN_00577c40();
          pcVar4 = (code *)swi(3);
          (*pcVar4)();
          return;
        }
        uVar12 = FUN_00f990b0();
        uStack_24 = uVar12;
        piVar7 = (int *)FUN_009b2bb0(&uStack_14,&uStack_24);
        if (*piVar7 != 0) {
          iVar2 = *(int *)*param_1;
          if ((uint)(((int *)*param_1)[1] - iVar2 >> 3) <= uVar11) goto LAB_009aabcf;
          iVar3 = *(int *)(iVar2 + 4 + uVar11 * 8);
          if (iVar3 != 0) {
            LOCK();
            piVar7 = (int *)(iVar3 + 4);
            *piVar7 = *piVar7 + 1;
            UNLOCK();
          }
          piStack_1c = *(int **)(iVar2 + uVar11 * 8);
          piStack_18 = *(int **)(iVar2 + 4 + uVar11 * 8);
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          if ((piStack_1c == (int *)0x0) || (piStack_1c[1] - *piStack_1c >> 3 == 0)) {
LAB_009aab2d:
            uVar12 = FUN_00f990b0();
            uStack_34 = uVar12;
            iVar8 = FUN_009a51d0(&uStack_34);
            cVar5 = FUN_00f995a0(*(undefined4 *)(iVar8 + 8));
            if (cVar5 != '\0') {
              uVar12 = FUN_00f990b0();
              puVar9 = &uStack_3c;
              goto LAB_009aab67;
            }
          }
          else {
            cVar5 = (**(code **)**(undefined4 **)(iVar8 + uVar11 * 8))(&piStack_1c,param_4);
            if (cVar5 == '\0') goto LAB_009aab2d;
            uVar12 = FUN_00f990b0();
            puVar9 = &uStack_2c;
            uStack_2c = uVar12;
            uVar12 = uStack_3c;
LAB_009aab67:
            uStack_3c = uVar12;
            FUN_009b12c0(puVar9);
          }
          piVar7 = piStack_18;
          uStack_8 = uStack_8 & 0xffffff00;
          if (piStack_18 != (int *)0x0) {
            LOCK();
            iVar8 = piStack_18[1] + -1;
            piStack_18[1] = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)*piStack_18)();
              LOCK();
              piVar1 = piVar7 + 2;
              iVar8 = *piVar1 + -1;
              *piVar1 = iVar8;
              UNLOCK();
              if (iVar8 == 0) {
                (**(code **)(*piVar7 + 4))();
              }
            }
          }
        }
        uVar11 = uVar11 + 1;
      } while (uVar11 < (uint)(((int *)*param_1)[1] - *(int *)*param_1 >> 3));
    }
    FUN_0056d250();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18426 ; VA 0x009aabe0 ; FUN_009aabe0 */

void FUN_009aabe0(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,uint *param_6,uint *param_7)

{
  uint uVar1;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  undefined8 uStack_a0;
  undefined4 uStack_98;
  undefined auStack_94 [12];
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_6c;
  undefined4 uStack_58;
  uint *puStack_54;
  uint *puStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d42f0;
  pvStack_10 = ExceptionList;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ee37b5);
  uStack_48 = 0;
  uVar1 = *param_7;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    uStack_48 = uVar1;
    if ((uVar1 & 1) == 0) {
      puStack_50 = &uStack_40;
      uStack_4c = 0;
      puStack_54 = param_7 + 2;
      uStack_58 = 0x9aac6e;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))();
    }
    else {
      uStack_40 = param_7[2];
      uStack_3c = param_7[3];
      uStack_38 = param_7[4];
      uStack_34 = param_7[5];
      uStack_30 = *(undefined8 *)(param_7 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uStack_6c = 0;
  uStack_98 = param_1;
  uVar1 = *param_6;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_6 + 2,&uStack_b0,0);
    }
    else {
      uStack_b0 = param_6[2];
      uStack_ac = param_6[3];
      uStack_a8 = param_6[4];
      uStack_a4 = param_6[5];
      uStack_a0 = *(undefined8 *)(param_6 + 6);
    }
  }
  FUN_008bfbf0(auStack_94,FUN_008e61f0);
  uStack_98 = 0x9aace5;
  FUN_008dc4b0();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_84 = param_5;
  uStack_88 = 0x9aacf6;
  FUN_0054ef60();
  uStack_8 = 0xffffffff;
  uStack_84 = 0x9aad03;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18427 ; VA 0x009aad20 ; FUN_009aad20 */

void FUN_009aad20(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 *param_5,uint *param_6,uint *param_7)

{
  int *piVar1;
  uint uVar2;
  uint uStack_244;
  uint uStack_240;
  uint uStack_23c;
  uint uStack_238;
  undefined8 uStack_234;
  undefined4 uStack_22c;
  undefined4 uStack_228;
  undefined4 uStack_160;
  undefined auStack_15c [232];
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_58;
  uint *puStack_54;
  uint *puStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d4310;
  pvStack_10 = ExceptionList;
  uStack_48 = 0;
  uVar2 = *param_7;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_48 = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_50 = &uStack_40;
      uStack_4c = 0;
      puStack_54 = param_7 + 2;
      uStack_58 = 0x9aada6;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_40 = param_7[2];
      uStack_3c = param_7[3];
      uStack_38 = param_7[4];
      uStack_34 = param_7[5];
      uStack_30 = *(undefined8 *)(param_7 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8 = 0;
  uStack_6c = 0;
  uStack_234 = CONCAT44(0x9aadd3,(undefined4)uStack_234);
  uStack_22c = FUN_00888530();
  uStack_228 = 0;
  iStack_8._0_1_ = 1;
  uVar2 = *param_6;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_6 + 2,&uStack_244,0);
    }
    else {
      uStack_244 = param_6[2];
      uStack_240 = param_6[3];
      uStack_23c = param_6[4];
      uStack_238 = param_6[5];
      uStack_234 = *(undefined8 *)(param_6 + 6);
    }
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_008bf820(auStack_15c);
  uStack_160 = 0x9aae3f;
  FUN_008bd310();
  if (param_5[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_70 = *param_5;
  uStack_6c = param_5[1];
  iStack_8 = 0xffffffff;
  uStack_74 = 0x9aae76;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18428 ; VA 0x009aae90 ; FUN_009aae90 */

void FUN_009aae90(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 *param_5,uint *param_6,uint *param_7)

{
  undefined4 uVar1;
  uint uVar2;
  uint *puVar3;
  uint *puVar4;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  undefined8 uStack_9c;
  undefined4 uStack_94;
  undefined4 uStack_80;
  uint *puStack_7c;
  uint *puStack_78;
  undefined4 uStack_74;
  uint auStack_70 [2];
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  undefined8 uStack_58;
  uint uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  undefined *puStack_20;
  undefined *puStack_1c;
  code *pcStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cef70;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)auStack_70;
  puStack_20 = (undefined *)auStack_70;
  pcStack_18 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ee37b5);
  uStack_14 = *param_5;
  uVar1 = param_5[1];
  auStack_70[0] = 0;
  uVar2 = *param_7;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_70;
  puVar4 = auStack_70;
  if (uVar2 != 0) {
    auStack_70[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_78 = &uStack_68;
      uStack_74 = 0;
      puStack_7c = param_7 + 2;
      uStack_80 = 0x9aaf23;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
      puVar3 = (uint *)puStack_20;
      puVar4 = (uint *)puStack_1c;
    }
    else {
      uStack_68 = param_7[2];
      uStack_64 = param_7[3];
      uStack_60 = param_7[4];
      uStack_5c = param_7[5];
      uStack_58 = *(undefined8 *)(param_7 + 6);
      ExceptionList = &pvStack_10;
      puVar3 = auStack_70;
      puVar4 = auStack_70;
    }
  }
  puStack_1c = (undefined *)puVar4;
  puStack_20 = (undefined *)puVar3;
  uStack_8 = 0;
  uStack_94 = param_1;
  uVar2 = *param_6;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_6 + 2);
    }
    else {
      uStack_ac = param_6[2];
      uStack_a8 = param_6[3];
      uStack_a4 = param_6[4];
      uStack_a0 = param_6[5];
      uStack_9c = *(undefined8 *)(param_6 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_94 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_40 != 0) {
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_ac,0);
    }
    else {
      uStack_ac = uStack_38;
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
    }
  }
  FUN_00960050();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
     (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
    uStack_94 = 2;
    uStack_9c = CONCAT44(&uStack_38,&uStack_38);
    uStack_a0 = 0x9ab005;
    (**(code **)(uStack_40 & 0xfffffffe))();
  }
  uStack_8 = 0xffffffff;
  uStack_9c = CONCAT44(uStack_14,0x9ab029);
  uStack_94 = uVar1;
  (*pcStack_18)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18429 ; VA 0x009ab040 ; FUN_009ab040 */

void FUN_009ab040(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 *param_6,uint *param_7,uint *param_8)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uStack_b4;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  undefined8 uStack_a4;
  undefined4 uStack_9c;
  undefined auStack_98 [4];
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_5c;
  uint *puStack_58;
  uint *puStack_54;
  undefined4 uStack_50;
  uint uStack_4c;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  undefined8 uStack_34;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d4330;
  pvStack_10 = ExceptionList;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ee37b5);
  uVar1 = *param_6;
  uVar2 = param_6[1];
  uStack_4c = 0;
  uVar3 = *param_8;
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    uStack_4c = uVar3;
    if ((uVar3 & 1) == 0) {
      puStack_54 = &uStack_44;
      uStack_50 = 0;
      puStack_58 = param_8 + 2;
      uStack_5c = 0x9ab0dc;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    else {
      uStack_44 = param_8[2];
      uStack_40 = param_8[3];
      uStack_3c = param_8[4];
      uStack_38 = param_8[5];
      uStack_34 = *(undefined8 *)(param_8 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uStack_70 = 0;
  uStack_9c = param_1;
  uVar3 = *param_7;
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(param_7 + 2,&uStack_b4,0);
    }
    else {
      uStack_b4 = param_7[2];
      uStack_b0 = param_7[3];
      uStack_ac = param_7[4];
      uStack_a8 = param_7[5];
      uStack_a4 = *(undefined8 *)(param_7 + 6);
    }
  }
  FUN_008bfbf0(auStack_98,FUN_008e61f0);
  uStack_9c = 0x9ab153;
  FUN_008dc4b0();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_90 = param_5;
  uStack_94 = 0x9ab16a;
  uStack_74 = uVar1;
  uStack_70 = uVar2;
  FUN_0054ef60();
  uStack_8 = 0xffffffff;
  uStack_90 = 0x9ab177;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18430 ; VA 0x009ab190 ; FUN_009ab190 */

void FUN_009ab190(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 *param_5,undefined4 *param_6,uint *param_7,uint *param_8)

{
  int *piVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uStack_244;
  uint uStack_240;
  uint uStack_23c;
  uint uStack_238;
  undefined8 uStack_234;
  undefined4 uStack_22c;
  undefined4 uStack_228;
  undefined4 uStack_160;
  undefined auStack_15c [228];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_58;
  uint *puStack_54;
  uint *puStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d4350;
  pvStack_10 = ExceptionList;
  uVar2 = *param_6;
  uStack_48 = 0;
  uVar3 = *param_8;
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    uStack_48 = uVar3;
    if ((uVar3 & 1) == 0) {
      puStack_50 = &uStack_40;
      uStack_4c = 0;
      puStack_54 = param_8 + 2;
      uStack_58 = 0x9ab21e;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    else {
      uStack_40 = param_8[2];
      uStack_3c = param_8[3];
      uStack_38 = param_8[4];
      uStack_34 = param_8[5];
      uStack_30 = *(undefined8 *)(param_8 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8 = 0;
  uStack_6c = 0;
  uStack_234 = CONCAT44(0x9ab24b,(undefined4)uStack_234);
  uStack_22c = FUN_00888530();
  uStack_228 = 0;
  iStack_8._0_1_ = 1;
  uVar3 = *param_7;
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(param_7 + 2,&uStack_244,0);
    }
    else {
      uStack_244 = param_7[2];
      uStack_240 = param_7[3];
      uStack_23c = param_7[4];
      uStack_238 = param_7[5];
      uStack_234 = *(undefined8 *)(param_7 + 6);
    }
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_008bf820(auStack_15c);
  uStack_160 = 0x9ab2b7;
  FUN_008bd310();
  if (param_5[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_74 = *param_5;
  uStack_70 = param_5[1];
  iStack_8 = 0xffffffff;
  uStack_78 = 0x9ab2f1;
  uStack_6c = uVar2;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18431 ; VA 0x009ab310 ; FUN_009ab310 */

undefined __fastcall FUN_009ab310(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  if ((param_1 != 0) && (iVar3 = *(int *)(param_1 + 0x34), iVar3 != 0)) {
    iVar1 = *(int *)(iVar3 + 0xc);
    iVar2 = FUN_00b63e30();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) goto LAB_009ab346;
  }
  iVar3 = 0;
LAB_009ab346:
  iVar3 = FUN_00980070(iVar3);
  if (iVar3 != 0) {
    return *(undefined *)(param_1 + 0x2a8);
  }
  return 1;
}



/* FUNCTION 18432 ; VA 0x009ab370 ; FUN_009ab370 */

void FUN_009ab370(float *param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  
  fVar1 = *param_1;
  fVar2 = param_1[2];
  FUN_01165610(0x358637bd);
  fVar3 = *param_2 * fVar1 + param_2[1] * 0.0 + param_2[2] * fVar2;
  if (fVar3 < 0.0) {
    *param_2 = *param_2 - fVar1 * fVar3;
    param_2[1] = param_2[1] - fVar3 * 0.0;
    param_2[2] = param_2[2] - fVar2 * fVar3;
  }
  return;
}



/* FUNCTION 18433 ; VA 0x009ab420 ; FUN_009ab420 */

int FUN_009ab420(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  if ((param_1 == 0) ||
     (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_00d6bbd0(), iVar3 = param_1,
     (uint)*(ushort *)(iVar2 + 0x1da) <
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))) {
    iVar3 = 0;
  }
  if ((param_1 == 0) ||
     (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_00d77b00(),
     (uint)*(ushort *)(iVar2 + 0x1da) <
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))) {
    param_1 = 0;
  }
  if (param_1 != 0) {
    iVar3 = 0;
  }
  return iVar3;
}



/* FUNCTION 18434 ; VA 0x009ab490 ; FUN_009ab490 */

/* WARNING: Removing unreachable block (ram,0x009ab4f5) */
/* WARNING: Removing unreachable block (ram,0x009ab508) */
/* WARNING: Removing unreachable block (ram,0x009ab50f) */
/* WARNING: Removing unreachable block (ram,0x009ab516) */

void __thiscall FUN_009ab490(int param_1,int param_2)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d4360;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x6f8);
  if (iVar1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_00587410();
    **(int **)(iVar1 + 0x24) = param_2 + (int)*(int **)(iVar1 + 0x24);
    **(int **)(iVar1 + 0x20) =
         ~(**(int **)(iVar1 + 0x24) - (int)*(int **)(iVar1 + 0x24)) + 0x82U +
         (int)*(int **)(iVar1 + 0x20);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18435 ; VA 0x009ab540 ; FUN_009ab540 */

void __fastcall FUN_009ab540(int param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 *puStack_30;
  undefined4 *puStack_2c;
  int iStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  code *pcStack_1c;
  undefined4 **ppuStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d4378;
  pvStack_10 = ExceptionList;
  if ((((DAT_01d64a60 != '\0') &&
       (ExceptionList = &pvStack_10, iStack_14 = FUN_008f7870(param_1), iStack_14 != 0)) &&
      ((cVar1 = FUN_008ff0d0(), cVar1 == '\0' || (*(int *)(iStack_14 + 0x4a0) != 3)))) &&
     ((*(int *)(param_1 + 0x228) == 1 && (*(int *)(param_1 + 0x234) == 1)))) {
    iStack_14 = iStack_14 + 0xc;
    puStack_30 = (undefined4 *)0x0;
    puStack_2c = (undefined4 *)0x0;
    iStack_28 = 0;
    uStack_8 = 0;
    if ((*(int *)(param_1 + 0x34) != 0) &&
       (iVar3 = *(int *)(*(int *)(param_1 + 0x34) + 0xc), iVar2 = FUN_00b63e30(),
       (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      ppuStack_18 = &puStack_30;
      pcStack_1c = FUN_009abd70;
      FUN_00917910(&pcStack_1c);
    }
    if ((iStack_14 != 0) && (iVar3 = FUN_005cf750(), iVar3 != 0)) {
      piVar4 = (int *)FUN_00980300(auStack_24);
      iStack_14 = *piVar4;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_20[1] + -1;
        piStack_20[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar4 = piStack_20 + 2;
          iVar3 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piStack_20 + 4))();
          }
        }
      }
      if (iStack_14 != 0) {
        uVar6 = 0;
        ppuStack_18 = (undefined4 **)((uint)((int)puStack_2c + (3 - (int)puStack_30)) >> 2);
        if (puStack_2c < puStack_30) {
          ppuStack_18 = (undefined4 **)0x0;
        }
        puVar5 = puStack_30;
        if (ppuStack_18 != (undefined4 **)0x0) {
          do {
            FUN_009c8840(*puVar5,iStack_14);
            puVar5 = puVar5 + 1;
            uVar6 = uVar6 + 1;
          } while ((undefined4 **)uVar6 != ppuStack_18);
        }
        if (puStack_30 == (undefined4 *)0x0) {
          ExceptionList = pvStack_10;
          return;
        }
        uVar6 = iStack_28 - (int)puStack_30 & 0xfffffffc;
        puVar5 = puStack_30;
        if (0xfff < uVar6) {
          puVar5 = (undefined4 *)puStack_30[-1];
          uVar6 = uVar6 + 0x23;
          if (0x1f < (uint)((int)puStack_30 + (-4 - (int)puVar5))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(puVar5,uVar6);
        ExceptionList = pvStack_10;
        return;
      }
    }
    FUN_0056d320();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18436 ; VA 0x009ab710 ; FUN_009ab710 */

undefined4 * __thiscall FUN_009ab710(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  code *pcStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  int iStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017d43a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puVar5 = (undefined4 *)ExceptionList;
  ExceptionList = &pvStack_10;
  if ((param_1 != 0) &&
     (puVar5 = *(undefined4 **)(param_1 + 0x34), ExceptionList = &pvStack_10,
     puVar5 != (undefined4 *)0x0)) {
    iVar2 = puVar5[3];
    ExceptionList = &pvStack_10;
    iVar4 = FUN_00b63e30();
    puVar5 = (undefined4 *)(uint)*(ushort *)(iVar4 + 0x1da);
    if ((undefined4 *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) <=
        puVar5) {
      puVar8 = &DAT_01d64e20;
      iStack_18 = param_2;
      uStack_14 = 0;
      puStack_1c = *(undefined4 **)(param_2 + 0x28);
      do {
        puVar5 = puVar8;
        if (0xf < (uint)puVar8[5]) {
          puVar5 = (undefined4 *)*puVar8;
        }
        puVar7 = puStack_1c;
        if (0xf < (uint)puStack_1c[5]) {
          puVar7 = (undefined4 *)*puStack_1c;
        }
        cVar3 = FUN_0055c360(puVar7,puStack_1c[4],puVar5,puVar8[4]);
        if (cVar3 != '\0') {
          iVar2 = *(int *)(iStack_18 + 0xc);
          iVar6 = FUN_00daf5e0();
          iVar4 = iStack_18;
          puVar8 = puStack_24;
          puVar5 = (undefined4 *)(uint)*(ushort *)(iVar6 + 0x1da);
          if ((undefined4 *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)) <=
              puVar5) {
            puStack_1c = (undefined4 *)((uint)puStack_1c & 0xffffff00);
            puStack_24 = puStack_1c;
            pcStack_38 = FUN_009c4910;
            uStack_34 = 0xfffffecc;
            uStack_30 = 0;
            puStack_2c = puVar8;
            iStack_28 = param_1;
            iStack_18 = FUN_0099e410(&puStack_1c,&pcStack_38);
            uStack_8 = CONCAT31(uStack_8._1_3_,1);
            FUN_009a4ad0(*(undefined4 *)(iVar4 + 0x28));
            cVar3 = FUN_01679300(iStack_18);
            if (cVar3 != '\0') {
              FUN_01679490();
              FUN_016791c0(iStack_18);
            }
            uStack_8 = uStack_8 & 0xffffff00;
            if (puStack_1c != (undefined4 *)0x0) {
              piVar1 = puStack_1c + 1;
              LOCK();
              iVar2 = *piVar1;
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (iVar2 == 1) {
                FUN_01674ea0(puStack_1c);
              }
            }
            puVar5 = (undefined4 *)FUN_009c4910(0);
          }
          break;
        }
        puVar8 = puVar8 + 6;
        uStack_14 = uStack_14 + 0x18;
        puVar5 = puStack_1c;
      } while (uStack_14 < 0x90);
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    puVar5 = (undefined4 *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puVar5 = (undefined4 *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puVar5 = (undefined4 *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar5;
}



/* FUNCTION 18437 ; VA 0x009ab8e0 ; FUN_009ab8e0 */

uint __thiscall FUN_009ab8e0(uint param_1,int param_2,int *param_3,uint param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  undefined4 ****ppppuVar6;
  char *pcVar7;
  uint uVar8;
  uint *puVar9;
  undefined4 ****ppppuVar10;
  uint *puVar11;
  uint *puVar12;
  undefined4 ***apppuStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint *puStack_28;
  uint *puStack_24;
  uint *puStack_20;
  uint uStack_1c;
  uint *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d43d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uStack_1c = param_1;
  if ((param_1 != 0) && (ExceptionList = &pvStack_10, *(int *)(param_1 + 0x34) != 0)) {
    iVar2 = *(int *)(*(int *)(param_1 + 0x34) + 0xc);
    ExceptionList = &pvStack_10;
    iVar5 = FUN_00b63e30();
    param_1 = (uint)*(ushort *)(iVar5 + 0x1da);
    if (((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <= param_1) &&
       ((param_2 != 0 && (param_1 = param_4, param_4 != 0)))) {
      FUN_0054ef60(*(undefined4 *)(param_4 + 0x28));
      ppppuVar10 = (undefined4 ****)apppuStack_40[0];
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      pcVar7 = PTR_DAT_01d64a08;
      do {
        cVar4 = *pcVar7;
        pcVar7 = pcVar7 + 1;
      } while (cVar4 != '\0');
      ppppuVar6 = apppuStack_40;
      if (0xf < uStack_2c) {
        ppppuVar6 = (undefined4 ****)apppuStack_40[0];
      }
      cVar4 = FUN_0055c360(ppppuVar6,uStack_30,PTR_DAT_01d64a08,
                           (int)pcVar7 - (int)(PTR_DAT_01d64a08 + 1));
      if (((cVar4 != '\0') || (cVar4 = FUN_00558b60(apppuStack_40,PTR_DAT_01d64a0c), cVar4 != '\0'))
         && (piVar3 = *(int **)(param_2 + 0x2c), piVar3 != (int *)0x0)) {
        puStack_28 = (uint *)0x0;
        puVar11 = (uint *)0x0;
        cStack_11 = '\0';
        puVar9 = (uint *)0x0;
        puStack_24 = (uint *)0x0;
        puStack_20 = (uint *)0x0;
        puStack_18 = (uint *)piVar3[1];
        puVar12 = (uint *)*piVar3;
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        if (puVar12 != puStack_18) {
          do {
            uVar8 = *puVar12;
            if (((uVar8 != 0) && (uVar8 != param_4)) &&
               (cVar4 = FUN_00558b30(*(undefined4 *)(uVar8 + 0x28),apppuStack_40), cVar4 != '\0')) {
              cStack_11 = '\x01';
              if (puVar9 == puVar11) {
                FUN_005c1970(puVar11,puVar12);
                puVar9 = puStack_20;
                puVar11 = puStack_24;
              }
              else {
                *puVar11 = 0;
                puVar11[1] = 0;
                if (puVar12[1] != 0) {
                  LOCK();
                  piVar3 = (int *)(puVar12[1] + 4);
                  *piVar3 = *piVar3 + 1;
                  UNLOCK();
                }
                *puVar11 = *puVar12;
                puVar11[1] = puVar12[1];
                puStack_24 = puVar11 + 2;
                puVar11 = puStack_24;
              }
            }
            puVar12 = puVar12 + 2;
          } while (puVar12 != puStack_18);
          puVar12 = puStack_28;
          if (cStack_11 != '\0') {
            for (; puVar12 != puVar11; puVar12 = puVar12 + 2) {
              (**(code **)(*(int *)*puVar12 + 0x2c))();
            }
            FUN_009c4910(0);
            FUN_009b11e0(&param_2);
          }
        }
        thunk_FUN_00577ac0();
        ppppuVar10 = (undefined4 ****)apppuStack_40[0];
      }
      param_1 = uStack_2c;
      if (0xf < uStack_2c) {
        uVar8 = uStack_2c + 1;
        ppppuVar6 = ppppuVar10;
        if (0xfff < uVar8) {
          ppppuVar6 = (undefined4 ****)ppppuVar10[-1];
          uVar8 = uStack_2c + 0x24;
          if (0x1f < (uint)((int)ppppuVar10 + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        param_1 = FUN_01674ea0(ppppuVar6,uVar8);
      }
    }
  }
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar12 = (uint *)(param_3 + 1);
    uVar8 = *puVar12;
    param_1 = *puVar12;
    *puVar12 = uVar8 - 1;
    UNLOCK();
    if (uVar8 - 1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      puVar12 = (uint *)(piVar3 + 2);
      uVar8 = *puVar12;
      param_1 = *puVar12;
      *puVar12 = uVar8 - 1;
      UNLOCK();
      if (uVar8 - 1 == 0) {
        param_1 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    puVar12 = (uint *)(param_5 + 1);
    uVar8 = *puVar12;
    param_1 = *puVar12;
    *puVar12 = uVar8 - 1;
    UNLOCK();
    if (uVar8 - 1 == 0) {
      param_1 = (**(code **)*param_5)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_1 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18438 ; VA 0x009abb30 ; FUN_009abb30 */

void __fastcall FUN_009abb30(int *param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  iVar3 = iVar1;
  piVar4 = *(int **)(iVar1 + 4);
  ExceptionList = &pvStack_10;
  if (*(char *)((int)*(int **)(iVar1 + 4) + 0xd) == '\0') {
    do {
      FUN_0089c7e0(piVar4[2]);
      piVar2 = (int *)*piVar4;
      FUN_01674ea0(piVar4,0x14);
      piVar4 = piVar2;
    } while (*(char *)((int)piVar2 + 0xd) == '\0');
    iVar3 = *param_1;
  }
  *(int *)(iVar3 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18439 ; VA 0x009abbb0 ; FUN_009abbb0 */

void __thiscall FUN_009abbb0(undefined4 param_1,int *param_2)

{
  if (*param_2 != 0) {
    FUN_009abbd0(param_1,param_2);
  }
  return;
}



/* FUNCTION 18440 ; VA 0x009abbd0 ; FUN_009abbd0 */

void * FUN_009abbd0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  undefined4 uVar4;
  void *pvVar5;
  int *piVar6;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d43f0;
  pvStack_10 = ExceptionList;
  pvVar5 = ExceptionList;
  if (*param_2 != 0) {
    ExceptionList = &pvStack_10;
    FUN_009b49f0(&piStack_18,param_1);
    uStack_8 = 0;
    if (piStack_18 != (int *)0x0) {
      FUN_008a65e0(0,0);
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_14[1] + -1;
      piStack_14[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        iVar3 = piStack_14[2] + -1;
        piStack_14[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    piVar6 = (int *)param_2[1];
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      piVar6 = (int *)param_2[1];
    }
    piStack_18 = (int *)*param_2;
    uStack_8 = 1;
    pcVar2 = *(code **)(*piStack_18 + 0x38);
    piStack_14 = piVar6;
    uVar4 = FUN_00e2c4f0();
    (*pcVar2)(uVar4);
    pvVar5 = (void *)FUN_008a65e0(param_1,0);
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar1 = piVar6 + 1;
      iVar3 = *piVar1;
      pvVar5 = (void *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        pvVar5 = (void *)(**(code **)*piVar6)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          pvVar5 = (void *)(**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 18441 ; VA 0x009abcc0 ; FUN_009abcc0 */

undefined4 * __thiscall FUN_009abcc0(undefined4 param_1,int param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puVar4 = (undefined4 *)ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  if (param_2 != 0) {
    iVar2 = *(int *)(param_2 + 0xc);
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00aff8c0();
    puVar4 = (undefined4 *)(uint)*(ushort *)(iVar3 + 0x1da);
    if ((undefined4 *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) <=
        puVar4) {
      uStack_14 = *(undefined4 *)(param_2 + 0xa8);
      puVar4 = *(undefined4 **)(param_4 + 4);
      if (*(undefined4 **)(param_4 + 8) == puVar4) {
        puVar4 = (undefined4 *)FUN_0063d9b0(puVar4,&uStack_14);
      }
      else {
        *puVar4 = uStack_14;
        *(int *)(param_4 + 4) = *(int *)(param_4 + 4) + 4;
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    puVar4 = (undefined4 *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puVar4 = (undefined4 *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puVar4 = (undefined4 *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 18442 ; VA 0x009abd70 ; FUN_009abd70 */

int * __thiscall FUN_009abd70(int param_1,int param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piVar4 = (int *)ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (param_2 != 0) {
    iVar2 = *(int *)(param_2 + 0xc);
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00aff8c0();
    piVar4 = (int *)(uint)*(ushort *)(iVar3 + 0x1da);
    if ((int *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) <= piVar4) {
      iStack_14 = param_2;
      piVar4 = *(int **)(param_4 + 4);
      if (*(int **)(param_4 + 8) == piVar4) {
        piVar4 = (int *)FUN_006030d0(piVar4,&iStack_14);
      }
      else {
        *piVar4 = param_2;
        *(int *)(param_4 + 4) = *(int *)(param_4 + 4) + 4;
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    piVar4 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piVar4 = (int *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piVar4 = (int *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 18443 ; VA 0x009abe20 ; FUN_009abe20 */

undefined4 * FUN_009abe20(int param_1,int *param_2,int param_3)

{
  undefined4 uVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  int *piVar6;
  undefined4 uStack_e0;
  undefined4 *puStack_dc;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d441e;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_009c68d0();
  piVar6 = *(int **)(param_1 + 0x28);
  if (0xf < (uint)piVar6[5]) {
    piVar6 = (int *)*piVar6;
  }
  iVar4 = (**(code **)(*piVar3 + 4))(piVar6);
  if (iVar4 != 0) {
    uStack_e0 = FUN_00888530();
    puStack_dc = (undefined4 *)0x0;
    uStack_8 = 1;
    cVar2 = FUN_009cb360(&uStack_e0);
    if (cVar2 != '\0') {
      puVar5 = *(undefined4 **)(param_3 + 4);
      if (*(undefined4 **)(param_3 + 8) == puVar5) {
        FUN_0098ded0(puVar5,&uStack_e0);
      }
      else {
        *puVar5 = uStack_e0;
        puVar5[1] = 0;
        if (puStack_dc != (undefined4 *)0x0) {
          (*(code *)*puStack_dc)(auStack_d8,puVar5 + 2);
        }
        puVar5[1] = puStack_dc;
        *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 0xd0;
      }
      _uStack_8 = CONCAT31(uStack_7,2);
      goto LAB_009abf7e;
    }
    uStack_8 = 3;
    if (puStack_dc != (undefined4 *)0x0) {
      (*(code *)puStack_dc[2])(auStack_d8);
    }
    uStack_8 = 0;
  }
  uVar1 = *(undefined4 *)(param_1 + 0x28);
  uStack_e0 = FUN_0088cb40();
  puStack_dc = (undefined4 *)0x0;
  FUN_0054ef60(uVar1);
  puStack_dc = (undefined4 *)FUN_005c9d30();
  _uStack_8 = CONCAT31(uStack_7,4);
  if (*(int *)(param_3 + 8) == *(int *)(param_3 + 4)) {
    FUN_005ca4f0(*(int *)(param_3 + 4),&uStack_e0);
  }
  else {
    FUN_005caf00(&uStack_e0);
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 0xd0;
  }
  _uStack_8 = CONCAT31(uStack_7,5);
LAB_009abf7e:
  puVar5 = puStack_dc;
  if (puStack_dc != (undefined4 *)0x0) {
    puVar5 = (undefined4 *)(*(code *)puStack_dc[2])(auStack_d8);
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar6 = param_2 + 1;
    iVar4 = *piVar6;
    puVar5 = (undefined4 *)*piVar6;
    *piVar6 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      puVar5 = (undefined4 *)(**(code **)*param_2)();
      LOCK();
      piVar6 = param_2 + 2;
      iVar4 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        puVar5 = (undefined4 *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar5;
}



/* FUNCTION 18444 ; VA 0x009abfd0 ; FUN_009abfd0 */

void __thiscall FUN_009abfd0(int param_1,char param_2,uint param_3)

{
  int iVar1;
  
  if (((param_2 != '\0') && (iVar1 = (**(code **)(*(int *)(param_1 + -0xa8) + 0x44))(), iVar1 != 0))
     && (*(char *)(iVar1 + 0x3e) != '\0')) {
    return;
  }
  if ((*(int *)(param_1 + 0x5f8) != 0) && (*(int *)(param_1 + 0x5fc) != 0)) {
    if (DAT_01d69148 != '\0') {
      if (((*(int *)(param_1 + 0x2fc) == 0) ||
          (iVar1 = *(int *)(*(int *)(param_1 + 0x2fc) + 0xa8), iVar1 == 0)) || (iVar1 == -0x50)) {
        iVar1 = 0;
      }
      else {
        iVar1 = *(int *)(iVar1 + 0x70);
      }
      if (iVar1 == 0) {
        return;
      }
      if ((param_3 & *(int *)(*(int *)(*(int *)(iVar1 + 0x20) + 0x2c) + 0x14) - 1U) != 0) {
        return;
      }
    }
    FUN_00dc3e30();
  }
  return;
}



/* FUNCTION 18445 ; VA 0x009ac050 ; FUN_009ac050 */

float10 __thiscall FUN_009ac050(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  float10 fVar3;
  float fVar4;
  
  if (**(char **)(param_2 + 0x21c) == '\0') {
    fVar3 = (float10)FUN_00f9cda0(*(undefined4 *)(param_1 + 0x2e0));
  }
  else {
    fVar3 = (float10)FUN_00f9ce10(param_2,0x100);
  }
  if (((*(int *)(param_1 + 0x3f8) == 0) ||
      (iVar2 = *(int *)(*(int *)(param_1 + 0x3f8) + 0xa8), iVar2 == 0)) || (iVar2 == -0x50)) {
    iVar2 = 0;
  }
  else {
    iVar2 = *(int *)(iVar2 + 0x70);
  }
  iVar1 = *(int *)(iVar2 + 0x24);
  if (iVar1 == 0) {
    if ((*(char *)(iVar2 + 0x3c) != '\0') && (*(int *)(iVar2 + 0x20) != iVar2)) {
      return (float10)0.0 * (float10)DAT_01d67c6c * (float10)(float)fVar3;
    }
    fVar4 = *(float *)(iVar2 + 0x84);
  }
  else {
    if (*(char *)(iVar1 + 4) != '\0') {
      FUN_00f958d0();
    }
    fVar4 = *(float *)(iVar1 + 0x14);
  }
  return (float10)fVar4 * (float10)DAT_01d67c6c * (float10)(float)fVar3;
}



/* FUNCTION 18446 ; VA 0x009ac110 ; FUN_009ac110 */

uint __fastcall FUN_009ac110(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  if (*(int *)(param_1 + 0x228) == 0) {
    uVar2 = *(uint *)(param_1 + 0x370);
  }
  else {
    uVar2 = *(uint *)(param_1 + 0x380);
  }
  if ((uVar2 != 0) && (uVar2 = *(uint *)(uVar2 + 0xa8), uVar2 != 0)) {
    iVar4 = 0;
    iVar5 = 0;
    iVar1 = FUN_00c16390();
    iVar3 = iVar4;
    if (0 < iVar1) {
      do {
        iVar1 = FUN_00c15720(iVar5);
        iVar3 = iVar4 + 1;
        if (*(char *)(iVar1 + 0xd) != '\0') {
          iVar3 = iVar4;
        }
        iVar5 = iVar5 + 1;
        iVar1 = FUN_00c16390();
        iVar4 = iVar3;
      } while (iVar5 < iVar1);
    }
    uVar2 = *(uint *)(param_1 + 0x250);
    *(int *)(param_1 + 0x250) = iVar3;
    if ((int)uVar2 < iVar3) {
      return CONCAT31((int3)(uVar2 >> 8),1);
    }
  }
  return uVar2 & 0xffffff00;
}



/* FUNCTION 18447 ; VA 0x009ac1a0 ; FUN_009ac1a0 */

undefined * FUN_009ac1a0(undefined *param_1,int param_2,float *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  float fVar7;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  int iStack_64;
  undefined uStack_60;
  undefined4 uStack_5c;
  int iStack_58;
  undefined4 uStack_54;
  int iStack_50;
  undefined uStack_4c;
  undefined4 uStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  uint uStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d4440;
  pvStack_10 = ExceptionList;
  iStack_58 = 0;
  uStack_54 = 0;
  iStack_50 = 0;
  uStack_4c = 0;
  uStack_48 = 0x10;
  uStack_6c = 0;
  uStack_68 = 0;
  iStack_64 = 0;
  uStack_60 = 0;
  uStack_5c = 0x10;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01674fa0(0x60,0x10);
  if (iVar3 != 0) {
    FUN_0099eb50(iVar3,iStack_58,uStack_54);
    if (iStack_50 != 0) {
      FUN_01674ee0(iStack_58);
    }
    iStack_50 = 0x18;
    iStack_58 = iVar3;
  }
  FUN_009c14b0(0x24);
  uVar6 = 0;
  fStack_18 = DAT_018c45c4;
  fStack_1c = DAT_018c45c4;
  piVar1 = *(int **)(param_2 + 0x2c);
  fStack_14 = DAT_018c45c4;
  fStack_20 = DAT_018c45d0;
  fStack_24 = DAT_018c45d0;
  fStack_28 = DAT_018c45d0;
  if (piVar1 == (int *)0x0) {
    uStack_2c = 0;
  }
  else {
    uStack_2c = piVar1[1] - *piVar1 >> 3;
  }
  fVar7 = DAT_018c45c4;
  if (uStack_2c != 0) {
    do {
      iVar3 = *(int *)(**(int **)(param_2 + 0x2c) + uVar6 * 8);
      iVar2 = *(int *)(iVar3 + 0xc);
      iVar4 = FUN_00d6bbd0();
      iVar5 = 0;
      if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
          (uint)*(ushort *)(iVar4 + 0x1da)) {
        iVar5 = iVar3;
      }
      if (iVar5 != 0) {
        FUN_00a6bd00(&fStack_44);
        if (fStack_3c <= fStack_14) {
          fStack_14 = fStack_3c;
        }
        if (fStack_44 <= fStack_18) {
          fStack_18 = fStack_44;
        }
        if (fStack_40 <= fStack_1c) {
          fStack_1c = fStack_40;
        }
        if (fStack_20 <= fStack_44) {
          fStack_20 = fStack_44;
        }
        if (fStack_24 <= fStack_40) {
          fStack_24 = fStack_40;
        }
        if (fStack_28 <= fStack_3c) {
          fStack_28 = fStack_3c;
        }
      }
      uVar6 = uVar6 + 1;
    } while (uVar6 < uStack_2c);
    fVar7 = fStack_18;
    if (fStack_18 < fStack_1c) {
      fVar7 = fStack_1c;
    }
  }
  if (fVar7 < fStack_14) {
    fVar7 = fStack_14;
  }
  if ((NAN(fVar7) || NAN(DAT_018c45c4)) == (fVar7 == DAT_018c45c4)) {
    fVar7 = fStack_20;
    if (fStack_24 < fStack_20) {
      fVar7 = fStack_24;
    }
    if (fStack_28 < fVar7) {
      fVar7 = fStack_28;
    }
    if ((NAN(fVar7) || NAN(DAT_018c45d0)) == (fVar7 == DAT_018c45d0)) {
      fStack_14 = (fStack_14 + fStack_28) * DAT_018ce2f4;
      fStack_44 = (fStack_18 + fStack_20) * DAT_018ce2f4;
      fStack_40 = (fStack_1c + fStack_24) * DAT_018ce2f4;
      fStack_38 = fStack_44 - *param_3;
      fStack_44 = *param_3 + fStack_44;
      fStack_30 = fStack_14 - param_3[2];
      fStack_3c = param_3[2] + fStack_14;
      fStack_34 = fStack_40 - param_3[1];
      fStack_40 = param_3[1] + fStack_40;
      FUN_009bf170(&fStack_38);
      FUN_009bf170(&fStack_34);
      FUN_009bf170(&fStack_30);
      FUN_009bf170(&fStack_38);
      FUN_009bf170(&fStack_34);
      FUN_009bf170(&fStack_3c);
      FUN_009bf170(&fStack_44);
      FUN_009bf170(&fStack_34);
      FUN_009bf170(&fStack_30);
      FUN_009bf170(&fStack_44);
      FUN_009bf170(&fStack_34);
      FUN_009bf170(&fStack_3c);
      FUN_009bf170(&fStack_38);
      FUN_009bf170(&fStack_40);
      FUN_009bf170(&fStack_30);
      FUN_009bf170(&fStack_44);
      FUN_009bf170(&fStack_40);
      FUN_009bf170(&fStack_30);
      FUN_009bf170(&fStack_38);
      FUN_009bf170(&fStack_40);
      FUN_009bf170(&fStack_3c);
      FUN_009bf170(&fStack_44);
      FUN_009bf170(&fStack_40);
      FUN_009bf170(&fStack_3c);
      FUN_009b9b00(&uStack_6c,2,1,0);
      FUN_009b9b00(&uStack_6c,2,3,1);
      FUN_009b9b00(&uStack_6c,6,5,4);
      FUN_009b9b00(&uStack_6c,6,7,5);
      FUN_009b9b00(&uStack_6c,2,5,7);
      FUN_009b9b00(&uStack_6c,2,7,3);
      FUN_009b9b00(&uStack_6c,0,6,4);
      FUN_009b9b00(&uStack_6c,1,6,0);
      FUN_009b9b00(&uStack_6c,1,3,6);
      FUN_009b9b00(&uStack_6c,3,7,6);
      FUN_009b9b00(&uStack_6c,2,4,5);
      FUN_009b9b00(&uStack_6c,0,4,2);
      FUN_00cc83c0(param_1,&iStack_58,&uStack_6c);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      uStack_68 = 0;
      if (iStack_64 != 0) {
        FUN_01674ee0(uStack_6c);
        iStack_64 = 0;
        uStack_6c = 0;
      }
      uStack_8 = 5;
      goto LAB_009ac6b4;
    }
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uStack_68 = 0;
  if (iStack_64 != 0) {
    FUN_01674ee0(uStack_6c);
    iStack_64 = 0;
    uStack_6c = 0;
  }
  uStack_8 = 3;
LAB_009ac6b4:
  uStack_54 = 0;
  if (iStack_50 != 0) {
    FUN_01674ee0(iStack_58);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18448 ; VA 0x009ac6e0 ; FUN_009ac6e0 */

undefined4 * __thiscall
FUN_009ac6e0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d4481;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar3 = param_5[1] + -1;
      param_5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar3 = *(int *)(*(int *)(param_3 + 0x138) + *(int *)(param_1 + 0x3c));
  iVar2 = *(int *)(param_1 + 0x38);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_00922680;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = iVar3 + 0x138 + iVar2 + param_3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar3 = param_5[2] + -1;
      param_5[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18449 ; VA 0x009ac8a0 ; FUN_009ac8a0 */

undefined4 * __thiscall
FUN_009ac8a0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bbbb1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar3 = param_5[1] + -1;
      param_5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar3 = *(int *)(*(int *)(param_3 + 0x138) + *(int *)(param_1 + 0x3c));
  iVar2 = *(int *)(param_1 + 0x38);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_0089f8b0;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = iVar3 + 0x138 + iVar2 + param_3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar3 = param_5[2] + -1;
      param_5[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18450 ; VA 0x009aca60 ; FUN_009aca60 */

undefined4 * __thiscall
FUN_009aca60(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  code *pcStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bbbf1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  pcStack_2c = (code *)*(undefined8 *)(param_1 + 0x38);
  ExceptionList = &pvStack_10;
  uVar3 = (*pcStack_2c)(1);
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_0089f9f0;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = uVar3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18451 ; VA 0x009acc30 ; FUN_009acc30 */

undefined4 * __thiscall
FUN_009acc30(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8141;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar3 = param_5[1] + -1;
      param_5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar3 = *(int *)(*(int *)(param_3 + 0x138) + *(int *)(param_1 + 0x3c));
  iVar2 = *(int *)(param_1 + 0x38);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_00922c30;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = iVar3 + 0x138 + iVar2 + param_3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar3 = param_5[2] + -1;
      param_5[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18452 ; VA 0x009acdf0 ; FUN_009acdf0 */

undefined4 * __thiscall
FUN_009acdf0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bbc31;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar3 = param_5[1] + -1;
      param_5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar3 = *(int *)(*(int *)(param_3 + 0x138) + *(int *)(param_1 + 0x3c));
  iVar2 = *(int *)(param_1 + 0x38);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_0089fb30;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = iVar3 + 0x138 + iVar2 + param_3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar3 = param_5[2] + -1;
      param_5[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18453 ; VA 0x009acfb0 ; FUN_009acfb0 */

undefined4 * __thiscall
FUN_009acfb0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d44c1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar3 = param_5[1] + -1;
      param_5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar3 = *(int *)(*(int *)(param_3 + 0x138) + *(int *)(param_1 + 0x3c));
  iVar2 = *(int *)(param_1 + 0x38);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_009afe20;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = iVar3 + 0x138 + iVar2 + param_3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar3 = param_5[2] + -1;
      param_5[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18454 ; VA 0x009ad170 ; FUN_009ad170 */

undefined4 * __thiscall
FUN_009ad170(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d4501;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar3 = param_5[1] + -1;
      param_5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar3 = *(int *)(*(int *)(param_3 + 0x138) + *(int *)(param_1 + 0x3c));
  iVar2 = *(int *)(param_1 + 0x38);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_009aff50;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = iVar3 + 0x138 + iVar2 + param_3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar3 = param_5[2] + -1;
      param_5[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18455 ; VA 0x009ad330 ; FUN_009ad330 */

undefined4 * __thiscall
FUN_009ad330(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d4541;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar3 = param_5[1] + -1;
      param_5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar3 = *(int *)(*(int *)(param_3 + 0x138) + *(int *)(param_1 + 0x3c));
  iVar2 = *(int *)(param_1 + 0x38);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_009b0080;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = iVar3 + 0x138 + iVar2 + param_3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar3 = param_5[2] + -1;
      param_5[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18456 ; VA 0x009ad4f0 ; FUN_009ad4f0 */

undefined4 * __thiscall
FUN_009ad4f0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ab301;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar3 = param_5[1] + -1;
      param_5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar3 = *(int *)(*(int *)(param_3 + 0x138) + *(int *)(param_1 + 0x3c));
  iVar2 = *(int *)(param_1 + 0x38);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_007037b0;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = iVar3 + 0x138 + iVar2 + param_3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar3 = param_5[2] + -1;
      param_5[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18457 ; VA 0x009ad6b0 ; FUN_009ad6b0 */

undefined4 * __thiscall
FUN_009ad6b0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cf181;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar3 = param_5[1] + -1;
      param_5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar3 = *(int *)(*(int *)(param_3 + 0x138) + *(int *)(param_1 + 0x3c));
  iVar2 = *(int *)(param_1 + 0x38);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_008f4680;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = iVar3 + 0x138 + iVar2 + param_3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar3 = param_5[2] + -1;
      param_5[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18458 ; VA 0x009ad870 ; FUN_009ad870 */

undefined4 * __thiscall
FUN_009ad870(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3b51;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar3 = param_5[1] + -1;
      param_5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar3 = *(int *)(*(int *)(param_3 + 0x138) + *(int *)(param_1 + 0x3c));
  iVar2 = *(int *)(param_1 + 0x38);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_008f4680;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = iVar3 + 0x138 + iVar2 + param_3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar3 = param_5[2] + -1;
      param_5[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18459 ; VA 0x009ada30 ; FUN_009ada30 */

undefined4 * __thiscall
FUN_009ada30(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d4581;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar3 = param_5[1] + -1;
      param_5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar3 = *(int *)(*(int *)(param_3 + 0x138) + *(int *)(param_1 + 0x3c));
  iVar2 = *(int *)(param_1 + 0x38);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_009b0180;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = iVar3 + 0x138 + iVar2 + param_3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar3 = param_5[2] + -1;
      param_5[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18460 ; VA 0x009adbf0 ; FUN_009adbf0 */

void FUN_009adbf0(void)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  code *pcStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  uint uStack_24;
  uint auStack_1c [2];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d45a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008a4100();
  iStack_2c = uStack_24;
  iStack_14 = CONCAT31(iStack_14._1_3_,1);
  uStack_24 = iStack_14;
  pcStack_38 = FUN_009bcd90;
  uStack_34 = 0xfffffecc;
  uStack_30 = 0;
  iStack_14 = FUN_0099e690(auStack_1c,&pcStack_38);
  uStack_8 = 0;
  cVar3 = FUN_01679300(iStack_14);
  if (cVar3 != '\0') {
    FUN_01679490();
    FUN_016791c0(iStack_14);
  }
  uStack_8 = 0xffffffff;
  if (auStack_1c[0] != 0) {
    piVar1 = (int *)(auStack_1c[0] + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(auStack_1c[0]);
    }
  }
  FUN_008a4100();
  iStack_2c = uStack_24;
  auStack_1c[0] = auStack_1c[0] & 0xffffff00;
  uStack_24 = auStack_1c[0];
  pcStack_38 = FUN_009bcd90;
  uStack_34 = 0xfffffecc;
  uStack_30 = 0;
  auStack_1c[0] = FUN_0099e690(&iStack_14,&pcStack_38);
  uStack_8 = 1;
  cVar3 = FUN_01679300(auStack_1c[0]);
  if (cVar3 != '\0') {
    FUN_01679490();
    FUN_016791c0(auStack_1c[0]);
  }
  uStack_8 = 0xffffffff;
  if (iStack_14 != 0) {
    piVar1 = (int *)(iStack_14 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iStack_14);
    }
  }
  cVar3 = FUN_00f94320();
  if (cVar3 != '\0') {
    FUN_009b1bb0();
    ExceptionList = pvStack_10;
    return;
  }
  FUN_009addb0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18461 ; VA 0x009addb0 ; FUN_009addb0 */

void __fastcall FUN_009addb0(int param_1)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  undefined auStack_1c [4];
  undefined4 uStack_18;
  int iStack_14;
  
  uVar3 = 0;
  *(undefined *)(param_1 + 0x338) = 0;
  iStack_14 = 0x9addc6;
  iVar1 = FUN_005d6c30();
  if (iVar1 != 0) {
    do {
      iStack_14 = 1;
      FUN_0060dcd0(auStack_1c,*(undefined4 *)(**(int **)(param_1 + 0x2c) + uVar3 * 8));
      FUN_009bcd90();
      uVar3 = uVar3 + 1;
      iStack_14 = 0x9addf8;
      uVar2 = FUN_005d6c30();
    } while (uVar3 < uVar2);
  }
  iStack_14 = *(undefined4 *)(param_1 + 0x34);
  *(undefined *)(param_1 + 0x338) = 1;
  uStack_18 = 0x9ade0b;
  iStack_14 = FUN_00980070();
  if (iStack_14 == 0) {
    uStack_18 = 0x9ade1a;
    FUN_009c4910();
  }
  return;
}



/* FUNCTION 18462 ; VA 0x009ade20 ; FUN_009ade20 */

undefined4 FUN_009ade20(int param_1)

{
  undefined4 uVar1;
  
  if (param_1 != 0) {
    uVar1 = FUN_009ba890(*(undefined4 *)(param_1 + 0x34));
    return uVar1;
  }
  return 0;
}



/* FUNCTION 18463 ; VA 0x009ade40 ; FUN_009ade40 */

int FUN_009ade40(int param_1)

{
  int iVar1;
  
  if (param_1 != 0) {
    while (param_1 = *(int *)(param_1 + 0x34), param_1 != 0) {
      iVar1 = FUN_009ba890(param_1);
      if (iVar1 != 0) {
        return iVar1;
      }
    }
  }
  return 0;
}



/* FUNCTION 18464 ; VA 0x009ade70 ; FUN_009ade70 */

void __fastcall FUN_009ade70(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  if (param_1[1] == 0) {
    *(undefined2 *)(param_1 + 2) = 0;
    puVar1 = (undefined4 *)FUN_01674e20(0x24);
    param_1[1] = puVar1;
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    *(undefined8 *)(puVar1 + 6) = 0;
    puVar1[8] = 0;
    *(undefined *)(param_1 + 2) = 1;
    return;
  }
  if (*(char *)((int)param_1 + 9) != '\0') {
    FUN_0099f5c0(*param_1,param_1[1] + 8);
    *(undefined *)((int)param_1 + 9) = 0;
  }
  return;
}



/* FUNCTION 18465 ; VA 0x009aded0 ; FUN_009aded0 */

void FUN_009aded0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_009c63c0();
    *param_2 = uVar3;
    iVar4 = FUN_009c6a30();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 18466 ; VA 0x009adf30 ; FUN_009adf30 */

void FUN_009adf30(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_009c6470();
    *param_2 = uVar3;
    iVar4 = FUN_009c6aa0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 18467 ; VA 0x009adf90 ; FUN_009adf90 */

void FUN_009adf90(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_009c6520();
    *param_2 = uVar3;
    iVar4 = FUN_009c6b10();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 18468 ; VA 0x009adff0 ; FUN_009adff0 */

void FUN_009adff0(undefined4 param_1,undefined4 *param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined auStack_8 [4];
  
  cVar1 = FUN_009cb5f0(param_1,auStack_8);
  if (cVar1 != '\0') {
    uVar2 = FUN_009c65d0();
    *param_2 = uVar2;
    FUN_0099b7f0(auStack_8);
  }
  return;
}



/* FUNCTION 18469 ; VA 0x009ae020 ; FUN_009ae020 */

void FUN_009ae020(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_009c6680();
    *param_2 = uVar3;
    iVar4 = FUN_009c6b80();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 18470 ; VA 0x009ae080 ; FUN_009ae080 */

void FUN_009ae080(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_009c6730();
    *param_2 = uVar3;
    iVar4 = FUN_009c6bf0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 18471 ; VA 0x009ae0e0 ; FUN_009ae0e0 */

void FUN_009ae0e0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_009c67e0();
    *param_2 = uVar3;
    iVar4 = FUN_009c6c60();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 18472 ; VA 0x009ae140 ; FUN_009ae140 */

void FUN_009ae140(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_009c68d0();
    *param_2 = uVar3;
    iVar4 = FUN_009c6cd0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 18473 ; VA 0x009ae1a0 ; FUN_009ae1a0 */

undefined4 FUN_009ae1a0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  char cVar2;
  char *pcVar3;
  undefined4 *puVar4;
  int iVar5;
  char *pcVar6;
  
  pcVar3 = (char *)FUN_00dc3b10(0);
  puVar1 = param_1;
  pcVar6 = pcVar3;
  do {
    cVar2 = *pcVar6;
    pcVar6 = pcVar6 + 1;
  } while (cVar2 != '\0');
  puVar4 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar4 = (undefined4 *)*param_1;
  }
  cVar2 = FUN_0055c360(puVar4,param_1[4],pcVar3,(int)pcVar6 - (int)(pcVar3 + 1));
  puVar4 = param_2;
  if (cVar2 == '\0') {
    param_1 = (undefined4 *)0x8;
    cVar2 = FUN_009b8ba0(puVar1,&param_1,param_2);
    if (cVar2 == '\0') {
      param_1 = (undefined4 *)0xa;
      cVar2 = FUN_009b8ba0(puVar1,&param_1,puVar4);
      if (cVar2 == '\0') {
        param_1 = (undefined4 *)0xc;
        cVar2 = FUN_009b8ba0(puVar1,&param_1,puVar4);
        if (cVar2 == '\0') {
          param_1 = (undefined4 *)0xb;
          cVar2 = FUN_009b8ba0(puVar1,&param_1,puVar4);
          if (cVar2 == '\0') {
            param_1 = (undefined4 *)0x1;
            cVar2 = FUN_009b8ba0(puVar1,&param_1,puVar4);
            if (cVar2 == '\0') {
              param_1 = (undefined4 *)0x2;
              cVar2 = FUN_009b8ba0(puVar1,&param_1,puVar4);
              if (cVar2 == '\0') {
                param_1 = (undefined4 *)0x3;
                cVar2 = FUN_009b8ba0(puVar1,&param_1,puVar4);
                if (cVar2 == '\0') {
                  param_1 = (undefined4 *)0x7;
                  cVar2 = FUN_009b8ba0(puVar1,&param_1,puVar4);
                  if (cVar2 == '\0') {
                    param_1 = (undefined4 *)0x6;
                    cVar2 = FUN_009b8ba0(puVar1,&param_1,puVar4);
                    if (cVar2 == '\0') {
                      param_1 = (undefined4 *)0x5;
                      cVar2 = FUN_009b8ba0(puVar1,&param_1,puVar4);
                      if (cVar2 == '\0') {
                        param_1 = (undefined4 *)0xd;
                        cVar2 = FUN_009b8ba0(puVar1,&param_1,puVar4);
                        if (cVar2 == '\0') {
                          param_1 = (undefined4 *)0xe;
                          cVar2 = FUN_009b8ba0(puVar1,&param_1,puVar4);
                          if (cVar2 == '\0') {
                            param_1 = (undefined4 *)0xf;
                            cVar2 = FUN_009b8ba0(puVar1,&param_1,puVar4);
                            if (cVar2 == '\0') {
                              param_1 = (undefined4 *)0x4;
                              cVar2 = FUN_009b8ba0(puVar1,&param_1,puVar4);
                              if (cVar2 == '\0') {
                                param_1 = (undefined4 *)0x10;
                                cVar2 = FUN_009b8ba0(puVar1,&param_1,puVar4);
                                if (cVar2 == '\0') {
                                  iVar5 = FUN_0058eea0(&DAT_0192ff80,0);
                                  if (iVar5 != 0) {
                                    *puVar4 = 0x12;
                                    return 1;
                                  }
                                  return 0;
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  else {
    *param_2 = 0;
  }
  return 1;
}



/* FUNCTION 18474 ; VA 0x009ae3c0 ; FUN_009ae3c0 */

void FUN_009ae3c0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_009c63c0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18475 ; VA 0x009ae400 ; FUN_009ae400 */

void FUN_009ae400(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_009c6470();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18476 ; VA 0x009ae440 ; FUN_009ae440 */

void FUN_009ae440(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_009c6520();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18477 ; VA 0x009ae480 ; FUN_009ae480 */

void FUN_009ae480(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_009c65d0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18478 ; VA 0x009ae4c0 ; FUN_009ae4c0 */

void FUN_009ae4c0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_009c6680();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18479 ; VA 0x009ae500 ; FUN_009ae500 */

void FUN_009ae500(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_009c6730();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18480 ; VA 0x009ae540 ; FUN_009ae540 */

void FUN_009ae540(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_009c67e0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18481 ; VA 0x009ae580 ; FUN_009ae580 */

void FUN_009ae580(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_009c68d0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18482 ; VA 0x009ae5c0 ; FUN_009ae5c0 */

undefined4 * FUN_009ae5c0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (DAT_01d64a10 == '\0') {
    puVar4 = (undefined4 *)FUN_0099f090(auStack_c);
  }
  else {
    puVar4 = (undefined4 *)FUN_0099f160(auStack_c,&stack0x00000008);
  }
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 18483 ; VA 0x009ae640 ; FUN_009ae640 */

uint FUN_009ae640(undefined4 param_1,int param_2,int param_3)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  undefined4 uVar6;
  uint uVar7;
  int iVar8;
  int *piVar9;
  undefined auStack_60 [48];
  undefined auStack_30 [4];
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d45b8;
  pvStack_10 = ExceptionList;
  iStack_1c = *(int *)(param_3 + 0x34);
  ExceptionList = &pvStack_10;
  if ((iStack_1c == 0) ||
     (iVar8 = *(int *)(iStack_1c + 0xc), ExceptionList = &pvStack_10, iVar3 = FUN_00aff8c0(),
     (uint)*(ushort *)(iVar3 + 0x1da) <
     (uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    iStack_1c = 0;
  }
  piStack_28 = (int *)0x0;
  piStack_24 = (int *)0x0;
  uStack_8 = 0;
  piStack_20 = (int *)FUN_008a1240(param_1);
  piStack_14 = (int *)0x0;
  piStack_18 = (int *)0x0;
  if (piStack_20 != (int *)0x0) {
    iVar8 = piStack_20[3];
    iVar3 = FUN_00c395b0();
    piVar9 = (int *)0x0;
    if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) {
      piVar9 = piStack_20;
    }
    puVar4 = (undefined4 *)FUN_0060dcd0(auStack_30,piVar9);
    piVar9 = (int *)*puVar4;
    piVar5 = (int *)puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    piStack_20 = piStack_2c;
    piStack_28 = piVar9;
    piStack_24 = piVar5;
    piStack_18 = piVar5;
    piStack_14 = piVar9;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar8 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        iVar8 = piStack_20[2] + -1;
        piStack_20[2] = iVar8;
        UNLOCK();
        piStack_18 = piVar5;
        piStack_14 = piVar9;
        if (iVar8 == 0) {
          (**(code **)(*piStack_20 + 4))();
          piStack_18 = piVar5;
          piStack_14 = piVar9;
        }
      }
    }
  }
  piVar9 = piStack_18;
  if (piStack_14 == (int *)0x0) {
    puVar4 = (undefined4 *)FUN_0099f370(auStack_30);
    piVar5 = (int *)*puVar4;
    piVar9 = (int *)puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    piStack_28 = piVar5;
    piStack_24 = piVar9;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar8 = piStack_18[1] + -1;
      piStack_18[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar8 = piStack_18[2] + -1;
        piStack_18[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    piStack_20 = piStack_2c;
    piStack_14 = piVar5;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar8 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        iVar8 = piStack_20[2] + -1;
        piStack_20[2] = iVar8;
        UNLOCK();
        piStack_14 = piVar5;
        if (iVar8 == 0) {
          (**(code **)(*piStack_20 + 4))();
          piStack_14 = piVar5;
        }
      }
    }
  }
  (**(code **)(*piStack_14 + 0x38))(param_1);
  piStack_20 = *(int **)(param_2 + 0x34);
  if ((piStack_20 == (int *)0x0) ||
     (iVar8 = *(int *)((int)piStack_20 + 0xc), iVar3 = FUN_00aff8c0(), piVar5 = piStack_20,
     (uint)*(ushort *)(iVar3 + 0x1da) <
     (uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    piVar5 = (int *)0;
  }
  FUN_00c3d740(piVar5);
  iVar8 = iStack_1c;
  FUN_00c3d770(iStack_1c);
  uVar6 = FUN_00d6c620(auStack_60);
  FUN_00c3ceb0(uVar6);
  uVar6 = FUN_00d6c620(auStack_60);
  FUN_00c3cee0(uVar6);
  uVar7 = FUN_008a65e0(iVar8,0);
  if ((DAT_01d6c7b4 != '\0') && (iVar8 != 0)) {
    iVar8 = *(int *)(iVar8 + 0xc);
    iVar3 = FUN_00cfb1a0();
    uVar7 = (uint)*(ushort *)(iVar3 + 0x1da);
    if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <= uVar7) {
      iVar8 = FUN_00d6c620(auStack_60);
      FUN_00cfdce0(iVar8 + 0x24);
      uVar7 = FUN_00cfdb20(1);
    }
  }
  if (piVar9 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar9 + 1);
    uVar2 = *puVar1;
    uVar7 = *puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      uVar7 = (**(code **)*piVar9)();
      LOCK();
      piVar5 = piVar9 + 2;
      iVar8 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        uVar7 = (**(code **)(*piVar9 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 18484 ; VA 0x009ae900 ; FUN_009ae900 */

int FUN_009ae900(undefined4 param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_0000001c;
  float in_stack_00000020;
  double dStack_20;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d45e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_008a1240(&param_2);
  if (iVar3 != 0) {
    iVar3 = *(int *)(iVar3 + 0xc);
    iVar4 = FUN_00daf5e0();
    if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da)) {
      uStack_18 = (double)in_stack_00000020;
      iVar3 = FUN_00db5760(&uStack_18);
      goto LAB_009ae9dd;
    }
  }
  FUN_00915ec0(&uStack_18);
  dStack_20 = (double)in_stack_00000020;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00db5760(&dStack_20);
  (**(code **)(*(int *)uStack_18 + 0x38))(&param_2);
  iVar3 = FUN_008a65e0(param_1,0);
  piVar2 = uStack_18._4_4_;
  if (uStack_18._4_4_ != (int *)0x0) {
    LOCK();
    piVar1 = uStack_18._4_4_ + 1;
    iVar4 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar3 = (**(code **)*uStack_18._4_4_)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar3 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
LAB_009ae9dd:
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    iVar3 = param_2;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(param_2 + -4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar3 = FUN_01674ea0(iVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 18485 ; VA 0x009aea30 ; FUN_009aea30 */

void __thiscall FUN_009aea30(int param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4)

{
  *(undefined *)(param_1 + 0x338) = 0;
  FUN_009afbf0(param_1,param_2,param_3,param_4);
  *(undefined *)(param_1 + 0x338) = 1;
  if (*(int *)(param_1 + 0x6f4) != 0) {
    FUN_009c4910(0);
  }
  return;
}



/* FUNCTION 18486 ; VA 0x009aea90 ; FUN_009aea90 */

void __thiscall FUN_009aea90(int param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined uVar1;
  
  *(undefined *)(param_1 + 0x338) = 0;
  uVar1 = 0;
  FUN_005542c0("BodyTypeScale",0xd);
  FUN_009ae900(param_1,uVar1);
  uVar1 = 0;
  FUN_005542c0("BodyProportionScale",0x13);
  FUN_009ae900(param_1,uVar1);
  FUN_009afbf0(param_1,param_2,param_3,param_4);
  *(undefined *)(param_1 + 0x338) = 1;
  if (*(int *)(param_1 + 0x6f4) != 0) {
    FUN_009c4910(0);
  }
  return;
}



/* FUNCTION 18487 ; VA 0x009aeb50 ; FUN_009aeb50 */

void FUN_009aeb50(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0x2c;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 18488 ; VA 0x009aeb90 ; FUN_009aeb90 */

void __thiscall FUN_009aeb90(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  undefined8 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined8 uStack_1b4;
  undefined4 uStack_1ac;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798da0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  puVar2 = *(undefined8 **)(param_1 + 0x44);
  if (puVar2 == (undefined8 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar5 = 2;
  }
  else {
    uStack_1bc = FUN_0088d870();
    iStack_1b8 = 0;
    uStack_1b4 = *puVar2;
    uStack_1ac = *(undefined4 *)(puVar2 + 1);
    iStack_1b8 = FUN_006315b0();
    puStack_18 = &uStack_1bc;
    uVar5 = 1;
  }
  uStack_8 = (uint)(puVar2 == (undefined8 *)0x0);
  uStack_14 = uVar5;
  uVar3 = FUN_0088d870();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(&uStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = *(undefined4 **)(param_1 + 0x48);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar6 = &uStack_35c;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar6[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar6[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar6;
    uStack_e0 = puVar6[1];
    iStack_e8 = FUN_006309e0();
    puVar6 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar3 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_e8 != 0)) {
    (**(code **)(iStack_e8 + 8))(&uStack_e4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18489 ; VA 0x009aede0 ; FUN_009aede0 */

void __thiscall FUN_009aede0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined8 *puVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined8 uStack_e4;
  undefined4 uStack_dc;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  puVar1 = *(undefined8 **)(param_1 + 0x44);
  if (puVar1 == (undefined8 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088d870();
    iStack_e8 = 0;
    uStack_e4 = *puVar1;
    uStack_dc = *(undefined4 *)(puVar1 + 1);
    iStack_e8 = FUN_006315b0();
    puStack_18 = &uStack_ec;
    uVar5 = 1;
  }
  uStack_8 = (uint)(puVar1 == (undefined8 *)0x0);
  uStack_14 = uVar5;
  uVar3 = FUN_0088d870();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar2 = *(undefined **)(param_1 + 0x48);
  if (puVar2 == (undefined *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar6 = &uStack_35c;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_1bc = FUN_0088daf0();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar2;
    iStack_1b8 = FUN_005c9ef0();
    puVar6 = &uStack_1bc;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar3 = FUN_0088daf0();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18490 ; VA 0x009af010 ; FUN_009af010 */

void __thiscall FUN_009af010(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar4 = 2;
  }
  else {
    uStack_ec = thunk_FUN_009c67e0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar5;
    iStack_e8 = FUN_009c6c60();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(puVar5 == (undefined4 *)0x0);
  uStack_14 = uVar4;
  uVar2 = thunk_FUN_009c67e0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar1 = *(undefined **)(param_1 + 0x48);
  if (puVar1 == (undefined *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_1bc = FUN_0088daf0();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar1;
    iStack_1b8 = FUN_005c9ef0();
    puVar5 = &uStack_1bc;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18491 ; VA 0x009af230 ; FUN_009af230 */

void __thiscall FUN_009af230(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 auStack_1b4 [50];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798da0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088daf0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar4 = 2;
  }
  else {
    uStack_1bc = FUN_009c6730();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar5;
    iStack_1b8 = FUN_009c6bf0();
    puStack_18 = &uStack_1bc;
    uVar4 = 1;
  }
  uStack_8 = (uint)(puVar5 == (undefined4 *)0x0);
  uStack_14 = uVar4;
  uVar2 = FUN_009c6730();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x48);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    iStack_e8 = FUN_006309e0();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_e8 != 0)) {
    (**(code **)(iStack_e8 + 8))(&uStack_e4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18492 ; VA 0x009af480 ; FUN_009af480 */

void __thiscall FUN_009af480(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 auStack_1b4 [50];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uStack_8 = 1;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    iStack_e8 = FUN_006309e0();
    puStack_18 = &uStack_ec;
    uStack_8 = 0;
    uVar4 = 1;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x48);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_1bc = thunk_FUN_0098cfc0();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar5;
    iStack_1b8 = FUN_0098d0e0();
    puVar5 = &uStack_1bc;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = thunk_FUN_0098cfc0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18493 ; VA 0x009af6d0 ; FUN_009af6d0 */

void __thiscall FUN_009af6d0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8320;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088daf0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x48) == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar4 = &uStack_28c;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    puVar4 = (undefined4 *)FUN_005c1470(*(int *)(param_1 + 0x48));
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18494 ; VA 0x009af8d0 ; FUN_009af8d0 */

int __thiscall FUN_009af8d0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_0099f5c0(-(uint)(param_1 != -3) & param_1 + 4U,puVar1 + 2);
    FUN_01674ea0(puVar1,0x24);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    iVar2 = iVar2 + 1;
    puVar1 = (undefined4 *)*param_2;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 18495 ; VA 0x009af930 ; FUN_009af930 */

int __thiscall FUN_009af930(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_0099f670(-(uint)(param_1 != -3) & param_1 + 4U,puVar1 + 2);
    FUN_01674ea0(puVar1,0x14);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    iVar2 = iVar2 + 1;
    puVar1 = (undefined4 *)*param_2;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 18496 ; VA 0x009af990 ; FUN_009af990 */

void __thiscall FUN_009af990(int param_1,int param_2)

{
  if (param_2 + 0x138 +
      *(int *)(*(int *)(param_2 + 0x138) + *(int *)(param_1 + 0x3c)) + *(int *)(param_1 + 0x38) != 0
     ) {
    FUN_016795b0();
  }
  return;
}



/* FUNCTION 18497 ; VA 0x009af9c0 ; FUN_009af9c0 */

void __fastcall FUN_009af9c0(int param_1)

{
  int iVar1;
  undefined4 uStack_10;
  
  uStack_10 = (code *)*(undefined8 *)(param_1 + 0x38);
  iVar1 = (*uStack_10)(0);
  if (iVar1 != 0) {
    FUN_016795b0();
  }
  return;
}



/* FUNCTION 18498 ; VA 0x009afa00 ; FUN_009afa00 */

void FUN_009afa00(undefined4 param_1,float *param_2,int param_3)

{
  float fVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  float fStack_b0;
  float fStack_ac;
  undefined8 uStack_a8;
  undefined4 uStack_a0;
  undefined8 uStack_9c;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  float fStack_6c;
  float fStack_68;
  float fStack_64;
  undefined8 uStack_60;
  undefined4 uStack_58;
  undefined8 uStack_54;
  undefined4 uStack_4c;
  float fStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  float fStack_14;
  float fStack_10;
  ulonglong uStack_c;
  
  iVar2 = FUN_00ca1550();
  if (iVar2 == 0) {
    iVar4 = 0;
  }
  else {
    iVar4 = iVar2 + 0x50;
  }
  uStack_90 = *(undefined4 *)(iVar4 + 0xb4);
  uStack_8c = *(undefined4 *)(iVar4 + 0xb8);
  uStack_88 = *(undefined4 *)(iVar4 + 0xbc);
  uStack_84 = *(undefined4 *)(iVar4 + 0xc0);
  uStack_80 = *(undefined4 *)(iVar4 + 0xc4);
  uStack_7c = *(undefined4 *)(iVar4 + 200);
  uStack_78 = *(undefined4 *)(iVar4 + 0xcc);
  uStack_74 = *(undefined4 *)(iVar4 + 0xd0);
  uStack_70 = *(undefined4 *)(iVar4 + 0xd4);
  fStack_6c = *(float *)(iVar4 + 0xd8);
  fStack_68 = *(float *)(iVar4 + 0xdc);
  fStack_64 = *(float *)(iVar4 + 0xe0);
  uStack_60 = *(undefined8 *)(iVar4 + 0xe4);
  uStack_58 = *(undefined4 *)(iVar4 + 0xec);
  uStack_54 = *(undefined8 *)(iVar4 + 0xf0);
  uStack_4c = *(undefined4 *)(iVar4 + 0xf8);
  fVar5 = param_2[4] * fStack_68;
  uStack_c = (ulonglong)
             (uint)(param_2[1] * fStack_68 + *param_2 * fStack_6c + param_2[2] * fStack_64 +
                   param_2[9]);
  fVar7 = param_2[3] * fStack_6c;
  fVar6 = param_2[5] * fStack_64;
  fVar1 = param_2[10];
  fStack_40 = param_2[6] * fStack_6c + param_2[7] * fStack_68 + param_2[8] * fStack_64 +
              param_2[0xb];
  puVar3 = (undefined4 *)FUN_01160c20(&uStack_b4,&uStack_90);
  uStack_3c = *puVar3;
  uStack_38 = puVar3[1];
  uStack_34 = puVar3[2];
  uStack_30 = puVar3[3];
  uStack_2c = puVar3[4];
  uStack_28 = puVar3[5];
  uStack_24 = puVar3[6];
  uStack_20 = puVar3[7];
  uStack_1c = puVar3[8];
  fStack_10 = fStack_40;
  uStack_18 = (undefined4)uStack_c;
  fStack_14 = fVar7 + fVar5 + fVar6 + fVar1;
  FUN_00c94b40(&uStack_3c);
  uStack_d8 = uStack_3c;
  uStack_d4 = uStack_38;
  uStack_d0 = uStack_34;
  uStack_cc = uStack_30;
  uStack_c8 = uStack_2c;
  uStack_c4 = uStack_28;
  uStack_c0 = uStack_24;
  uStack_bc = uStack_20;
  uStack_b8 = uStack_1c;
  uStack_b4 = uStack_18;
  fStack_b0 = fStack_14;
  fStack_ac = fStack_10;
  uStack_a8 = uStack_60;
  uStack_a0 = uStack_58;
  uStack_94 = uStack_4c;
  uStack_9c = uStack_54;
  FUN_00fa0400(&uStack_d8,iVar2 + 0x30);
  iVar2 = 0;
  if (0 < *(int *)(param_3 + 0x14)) {
    do {
      iVar4 = *(int *)(*(int *)(param_3 + 0x10) + iVar2 * 4);
      FUN_009afa00(param_1,param_2,-(uint)(iVar4 != 0) & iVar4 - 8U);
      iVar2 = iVar2 + 1;
    } while (iVar2 < *(int *)(param_3 + 0x14));
  }
  return;
}



/* FUNCTION 18499 ; VA 0x009afbf0 ; FUN_009afbf0 */

void FUN_009afbf0(undefined4 param_1)

{
  undefined uVar1;
  
  uVar1 = 0;
  FUN_005542c0("BodyWidthScale",0xe);
  FUN_009ae900(param_1,uVar1);
  uVar1 = 0;
  FUN_005542c0("BodyHeightScale",0xf);
  FUN_009ae900(param_1,uVar1);
  uVar1 = 0;
  FUN_005542c0("BodyDepthScale",0xe);
  FUN_009ae900(param_1,uVar1);
  uVar1 = 0;
  FUN_005542c0("HeadScale",9);
  FUN_009ae900(param_1,uVar1);
  return;
}


