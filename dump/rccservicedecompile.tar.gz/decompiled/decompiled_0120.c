/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 30000 ; VA 0x00ca2620 ; FUN_00ca2620 */

int * __fastcall FUN_00ca2620(int *param_1)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = (int *)*param_1;
  param_1[1] = param_1[1] + 1;
  if (piVar1[3] < param_1[1]) {
    iVar2 = *piVar1;
    param_1[2] = param_1[2] + 1;
    param_1[1] = iVar2;
    if (piVar1[4] < param_1[2]) {
      iVar2 = piVar1[1];
      param_1[3] = param_1[3] + 1;
      param_1[2] = iVar2;
      if (piVar1[5] < param_1[3]) {
        iVar2 = piVar1[5];
        *(ulonglong *)(param_1 + 1) = CONCAT44(piVar1[4] + 1,piVar1[3] + 1);
        param_1[3] = iVar2 + 1;
      }
    }
  }
  return param_1;
}



/* FUNCTION 30001 ; VA 0x00ca2680 ; FUN_00ca2680 */

int FUN_00ca2680(int *param_1)

{
  return param_1[1] * 0x1c00 + param_1[2] * 0x300000 + *param_1 * 0xb;
}



/* FUNCTION 30002 ; VA 0x00ca26a0 ; FUN_00ca26a0 */

undefined4 * __thiscall
FUN_00ca26a0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 *param_5)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01810993;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[1] = 0;
  param_1[2] = RBX::SpanningEdge::vftable;
  *(undefined *)(param_1 + 3) = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  *param_1 = RBX::Joint::vftable;
  param_1[2] = RBX::Joint::vftable;
  *(undefined *)(param_1 + 8) = 0;
  param_1[9] = 0;
  *(undefined2 *)(param_1 + 10) = 0x300;
  param_1[0xb] = param_2;
  param_1[0xc] = param_3;
  param_1[0xd] = 0xffffffff;
  param_1[0xe] = 0xffffffff;
  param_1[0xf] = 0xffffffff;
  uVar1 = param_4[1];
  uVar2 = param_4[2];
  uVar3 = param_4[3];
  uStack_8 = 1;
  param_1[0x10] = *param_4;
  param_1[0x11] = uVar1;
  param_1[0x12] = uVar2;
  param_1[0x13] = uVar3;
  uVar1 = param_4[5];
  uVar2 = param_4[6];
  uVar3 = param_4[7];
  param_1[0x14] = param_4[4];
  param_1[0x15] = uVar1;
  param_1[0x16] = uVar2;
  param_1[0x17] = uVar3;
  uVar1 = param_4[9];
  uVar2 = param_4[10];
  uVar3 = param_4[0xb];
  param_1[0x18] = param_4[8];
  param_1[0x19] = uVar1;
  param_1[0x1a] = uVar2;
  param_1[0x1b] = uVar3;
  uVar1 = param_5[1];
  uVar2 = param_5[2];
  uVar3 = param_5[3];
  param_1[0x1c] = *param_5;
  param_1[0x1d] = uVar1;
  param_1[0x1e] = uVar2;
  param_1[0x1f] = uVar3;
  uVar1 = param_5[5];
  uVar2 = param_5[6];
  uVar3 = param_5[7];
  param_1[0x20] = param_5[4];
  param_1[0x21] = uVar1;
  param_1[0x22] = uVar2;
  param_1[0x23] = uVar3;
  uVar1 = param_5[9];
  uVar2 = param_5[10];
  uVar3 = param_5[0xb];
  param_1[0x24] = param_5[8];
  param_1[0x25] = uVar1;
  param_1[0x26] = uVar2;
  param_1[0x27] = uVar3;
  param_1[0x28] = 0xffffffff;
  param_1[0x29] = 0;
  if (DAT_01ee41fe != '\0') {
    FUN_01677490(DAT_01ee41fe,"Joint %p created, prim0: %p, prim1: %p",param_1,param_2,param_3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30003 ; VA 0x00ca27c0 ; FUN_00ca27c0 */

undefined4 * __fastcall FUN_00ca27c0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01810993;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[1] = 0;
  param_1[2] = RBX::SpanningEdge::vftable;
  *(undefined *)(param_1 + 3) = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  *param_1 = RBX::Joint::vftable;
  param_1[2] = RBX::Joint::vftable;
  *(undefined *)(param_1 + 8) = 0;
  param_1[9] = 0;
  *(undefined2 *)(param_1 + 10) = 0x300;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0xffffffff;
  param_1[0xe] = 0xffffffff;
  param_1[0xf] = 0xffffffff;
  param_1[0x10] = 0x3f800000;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0x3f800000;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0x3f800000;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0x3f800000;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0x3f800000;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0x3f800000;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0xffffffff;
  param_1[0x29] = 0;
  uStack_8 = 1;
  if (DAT_01ee41fe != '\0') {
    FUN_016774b0(DAT_01ee41fe,"Joint %p created, empty primitives",param_1);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30004 ; VA 0x00ca2960 ; FUN_00ca2960 */

undefined4 * __fastcall FUN_00ca2960(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01810993;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[1] = 0;
  param_1[2] = RBX::SpanningEdge::vftable;
  *(undefined *)(param_1 + 3) = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  *param_1 = RBX::Joint::vftable;
  param_1[2] = RBX::Joint::vftable;
  *(undefined *)(param_1 + 8) = 0;
  param_1[9] = 0;
  *(undefined2 *)(param_1 + 10) = 0x300;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0xffffffff;
  param_1[0xe] = 0xffffffff;
  param_1[0xf] = 0xffffffff;
  param_1[0x10] = 0x3f800000;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0x3f800000;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0x3f800000;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0x3f800000;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0x3f800000;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0x3f800000;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0xffffffff;
  param_1[0x29] = 0;
  uStack_8 = 1;
  if (DAT_01ee41fe != '\0') {
    FUN_016774b0(DAT_01ee41fe,"Joint %p created, empty primitives",param_1);
  }
  *param_1 = RBX::MechanicalJoint::vftable;
  *(byte *)(param_1 + 0x2b) = *(byte *)(param_1 + 0x2b) & 0xfe | 2;
  param_1[2] = RBX::MechanicalJoint::vftable;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30005 ; VA 0x00ca2b60 ; FUN_00ca2b60 */

void __fastcall FUN_00ca2b60(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Joint::vftable;
  param_1[2] = RBX::Joint::vftable;
  if (DAT_01ee41fe != '\0') {
    FUN_016774b0(DAT_01ee41fe,"Joint %p destroyed",param_1);
  }
  param_1[0xd] = 0xffffffff;
  param_1[0xe] = 0xffffffff;
  param_1[2] = RBX::SpanningEdge::vftable;
  *param_1 = RBX::IPipelined::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30006 ; VA 0x00ca2bd0 ; FUN_00ca2bd0 */

void __fastcall FUN_00ca2bd0(undefined4 *param_1)

{
  *param_1 = RBX::SpanningEdge::vftable;
  return;
}



/* FUNCTION 30007 ; VA 0x00ca2bd7 ; FUN_00ca2bd7 */

void FUN_00ca2bd7(void)

{
  FUN_00ca2bf0();
  return;
}



/* FUNCTION 30008 ; VA 0x00ca2bdf ; FUN_00ca2bdf */

void FUN_00ca2bdf(void)

{
  FUN_00ca2c80();
  return;
}



/* FUNCTION 30009 ; VA 0x00ca2bf0 ; FUN_00ca2bf0 */

undefined4 * __thiscall FUN_00ca2bf0(undefined4 *param_1,byte param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Joint::vftable;
  param_1[2] = RBX::Joint::vftable;
  uStack_8 = 0;
  if (DAT_01ee41fe != '\0') {
    FUN_016774b0(DAT_01ee41fe,"Joint %p destroyed",param_1);
  }
  param_1[0xd] = 0xffffffff;
  param_1[0xe] = 0xffffffff;
  param_1[2] = RBX::SpanningEdge::vftable;
  *param_1 = RBX::IPipelined::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xa8);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30010 ; VA 0x00ca2c80 ; FUN_00ca2c80 */

undefined4 * __thiscall FUN_00ca2c80(undefined4 *param_1,byte param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::MechanicalJoint::vftable;
  param_1[2] = RBX::MechanicalJoint::vftable;
  iVar1 = param_1[0x2f];
  if (iVar1 != 0) {
    uVar3 = (param_1[0x31] - iVar1 >> 2) * 4;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_00ca2ddf;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[0x2f] = 0;
    param_1[0x30] = 0;
    param_1[0x31] = 0;
  }
  iVar1 = param_1[0x2c];
  if (iVar1 != 0) {
    uVar3 = (param_1[0x2e] - iVar1 >> 2) * 4;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_00ca2ddf:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[0x2c] = 0;
    param_1[0x2d] = 0;
    param_1[0x2e] = 0;
  }
  *param_1 = RBX::Joint::vftable;
  param_1[2] = RBX::Joint::vftable;
  uStack_8 = 0;
  if (DAT_01ee41fe != '\0') {
    FUN_016774b0(DAT_01ee41fe,"Joint %p destroyed",param_1);
  }
  param_1[0xd] = 0xffffffff;
  param_1[0xe] = 0xffffffff;
  param_1[2] = RBX::SpanningEdge::vftable;
  *param_1 = RBX::IPipelined::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,200);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30011 ; VA 0x00ca2df0 ; FUN_00ca2df0 */

undefined4 * __thiscall FUN_00ca2df0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::SpanningEdge::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,8);
  }
  return param_1;
}



/* FUNCTION 30012 ; VA 0x00ca2e20 ; FUN_00ca2e20 */

undefined4
FUN_00ca2e20(int param_1,undefined4 param_2,float param_3,undefined4 param_4,undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  char cVar3;
  int iVar4;
  float *pfVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  undefined auStack_f0 [12];
  undefined auStack_e4 [12];
  undefined auStack_d8 [12];
  undefined auStack_cc [12];
  undefined auStack_c0 [12];
  undefined auStack_b4 [12];
  float fStack_a8;
  float fStack_a4;
  float fStack_a0;
  float fStack_9c;
  float fStack_98;
  float fStack_94;
  float fStack_90;
  float fStack_8c;
  float fStack_88;
  float fStack_84;
  float fStack_80;
  float fStack_7c;
  float fStack_78;
  float fStack_74;
  float fStack_70;
  float fStack_6c;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  int iStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  iStack_38 = (**(code **)(**(int **)(param_1 + 0x1ac) + 0x38))(param_2);
  uVar2 = param_4;
  iVar1 = (int)param_3;
  iStack_38 = iStack_38 + -1;
  fStack_2c = 0.0;
  iVar4 = (**(code **)(**(int **)((int)param_3 + 0x1ac) + 0x38))(param_4);
  iVar4 = iVar4 + -1;
  param_3 = (float)iVar4;
  if (0 < iStack_38) {
    do {
      fVar7 = fStack_2c;
      (**(code **)(**(int **)(param_1 + 0x1ac) + 0x34))(&fStack_84,param_2,fStack_2c);
      pfVar5 = (float *)FUN_00c157b0();
      fStack_3c = fStack_80 * pfVar5[1];
      fStack_2c = fStack_84 * *pfVar5;
      fStack_30 = fStack_7c * pfVar5[2];
      fStack_8 = pfVar5[9];
      fStack_c = fStack_84 * pfVar5[3];
      fStack_1c = fStack_84 * pfVar5[6];
      fStack_10 = fStack_80 * pfVar5[4];
      fStack_20 = fStack_80 * pfVar5[7];
      fStack_14 = fStack_7c * pfVar5[5];
      fStack_24 = fStack_7c * pfVar5[8];
      fStack_18 = pfVar5[10];
      fStack_28 = pfVar5[0xb];
      pfVar5 = (float *)FUN_00c157b0();
      fVar8 = (fStack_2c + fStack_3c + fStack_30 + fStack_8) - pfVar5[9];
      fVar6 = (fStack_c + fStack_10 + fStack_14 + fStack_18) - pfVar5[10];
      fVar9 = (fStack_1c + fStack_20 + fStack_24 + fStack_28) - pfVar5[0xb];
      fStack_58 = pfVar5[5] * fVar6 + pfVar5[2] * fVar8 + pfVar5[8] * fVar9;
      fStack_5c = pfVar5[4] * fVar6 + pfVar5[1] * fVar8 + pfVar5[7] * fVar9;
      fStack_2c = (float)((int)fVar7 + 1);
      fStack_60 = pfVar5[3] * fVar6 + fVar8 * *pfVar5 + pfVar5[6] * fVar9;
      (**(code **)(**(int **)(param_1 + 0x1ac) + 0x34))(&fStack_90,param_2,fStack_2c);
      pfVar5 = (float *)FUN_00c157b0();
      fStack_28 = fStack_8c * pfVar5[1];
      fStack_24 = fStack_90 * *pfVar5;
      fStack_20 = fStack_88 * pfVar5[2];
      fStack_1c = pfVar5[9];
      fStack_18 = fStack_90 * pfVar5[3];
      fStack_8 = fStack_90 * pfVar5[6];
      fStack_14 = fStack_8c * pfVar5[4];
      fStack_30 = fStack_8c * pfVar5[7];
      fStack_10 = fStack_88 * pfVar5[5];
      fStack_3c = fStack_88 * pfVar5[8];
      fStack_c = pfVar5[10];
      fStack_34 = pfVar5[0xb];
      pfVar5 = (float *)FUN_00c157b0();
      fVar8 = (fStack_28 + fStack_24 + fStack_20 + fStack_1c) - pfVar5[9];
      fVar7 = (fStack_18 + fStack_14 + fStack_10 + fStack_c) - pfVar5[10];
      fVar6 = (fStack_8 + fStack_30 + fStack_3c + fStack_34) - pfVar5[0xb];
      fStack_4c = pfVar5[5] * fVar7 + pfVar5[2] * fVar8 + pfVar5[8] * fVar6;
      iVar4 = 0;
      fStack_50 = pfVar5[4] * fVar7 + pfVar5[1] * fVar8 + pfVar5[7] * fVar6;
      fStack_54 = pfVar5[3] * fVar7 + fVar8 * *pfVar5 + pfVar5[6] * fVar6;
      if (0 < (int)param_3) {
        do {
          (**(code **)(**(int **)(iVar1 + 0x1ac) + 0x34))(auStack_d8,uVar2,iVar4);
          iVar4 = iVar4 + 1;
          (**(code **)(**(int **)(iVar1 + 0x1ac) + 0x34))(auStack_cc,uVar2,iVar4);
          fStack_40 = 1e+06;
          cVar3 = FUN_00c944d0(&fStack_60,&fStack_54,auStack_d8,auStack_cc,&fStack_40,param_5);
          if ((cVar3 != '\0') && (fStack_40 < DAT_018fe498)) {
            return 1;
          }
        } while (iVar4 < (int)param_3);
      }
      iVar4 = (int)param_3;
      (**(code **)(**(int **)(iVar1 + 0x1ac) + 0x34))(auStack_c0,uVar2,param_3);
      (**(code **)(**(int **)(iVar1 + 0x1ac) + 0x34))(auStack_b4,uVar2,0);
      fStack_44 = 1e+06;
      cVar3 = FUN_00c944d0(&fStack_60,&fStack_54,auStack_c0,auStack_b4,&fStack_44,param_5);
      if ((cVar3 != '\0') && (fStack_44 < DAT_018fe498)) {
        return 1;
      }
    } while ((int)fStack_2c < iStack_38);
  }
  (**(code **)(**(int **)(param_1 + 0x1ac) + 0x34))(&fStack_9c,param_2,iStack_38);
  pfVar5 = (float *)FUN_00c157b0();
  param_3 = fStack_98 * pfVar5[1];
  fStack_34 = fStack_9c * *pfVar5;
  fStack_28 = fStack_94 * pfVar5[2];
  fStack_24 = pfVar5[9];
  fStack_1c = fStack_9c * pfVar5[3];
  fStack_10 = fStack_9c * pfVar5[6];
  fStack_20 = pfVar5[4] * fStack_98;
  fStack_c = fStack_98 * pfVar5[7];
  fStack_18 = pfVar5[5] * fStack_94;
  fStack_8 = fStack_94 * pfVar5[8];
  fStack_14 = pfVar5[10];
  fStack_30 = pfVar5[0xb];
  pfVar5 = (float *)FUN_00c157b0();
  fVar8 = (param_3 + fStack_34 + fStack_28 + fStack_24) - pfVar5[9];
  fVar7 = (fStack_20 + fStack_1c + fStack_18 + fStack_14) - pfVar5[10];
  fVar6 = (fStack_10 + fStack_c + fStack_8 + fStack_30) - pfVar5[0xb];
  fStack_70 = pfVar5[5] * fVar7 + pfVar5[2] * fVar8 + pfVar5[8] * fVar6;
  fStack_74 = pfVar5[4] * fVar7 + pfVar5[1] * fVar8 + pfVar5[7] * fVar6;
  fStack_78 = pfVar5[3] * fVar7 + fVar8 * *pfVar5 + pfVar5[6] * fVar6;
  (**(code **)(**(int **)(param_1 + 0x1ac) + 0x34))(&fStack_a8,param_2,0);
  pfVar5 = (float *)FUN_00c157b0();
  fVar7 = pfVar5[1];
  param_3 = fStack_a8 * *pfVar5;
  fStack_34 = fStack_a0 * pfVar5[2];
  fStack_28 = pfVar5[9];
  fStack_20 = fStack_a8 * pfVar5[3];
  fStack_10 = fStack_a8 * pfVar5[6];
  fStack_24 = fStack_a4 * pfVar5[4];
  fStack_14 = fStack_a4 * pfVar5[7];
  fStack_1c = fStack_a0 * pfVar5[5];
  fStack_18 = pfVar5[10];
  fStack_c = pfVar5[8] * fStack_a0;
  fStack_8 = pfVar5[0xb];
  pfVar5 = (float *)FUN_00c157b0();
  fVar6 = (fStack_a4 * fVar7 + param_3 + fStack_34 + fStack_28) - pfVar5[9];
  fVar7 = (fStack_24 + fStack_20 + fStack_1c + fStack_18) - pfVar5[10];
  fVar8 = (fStack_14 + fStack_10 + fStack_c + fStack_8) - pfVar5[0xb];
  fStack_64 = pfVar5[5] * fVar7 + pfVar5[2] * fVar6 + pfVar5[8] * fVar8;
  fStack_68 = pfVar5[4] * fVar7 + pfVar5[1] * fVar6 + pfVar5[7] * fVar8;
  param_1 = 0;
  fStack_6c = pfVar5[3] * fVar7 + fVar6 * *pfVar5 + pfVar5[6] * fVar8;
  if (0 < iVar4) {
    do {
      (**(code **)(**(int **)(iVar1 + 0x1ac) + 0x34))(auStack_b4,uVar2,param_1);
      param_1 = param_1 + 1;
      (**(code **)(**(int **)(iVar1 + 0x1ac) + 0x34))(auStack_c0,uVar2,param_1);
      param_3 = 1e+06;
      cVar3 = FUN_00c944d0(&fStack_78,&fStack_6c,auStack_b4,auStack_c0,&param_3,param_5);
      if ((cVar3 != '\0') && (param_3 < DAT_018fe498)) {
        return 1;
      }
    } while (param_1 < iVar4);
  }
  (**(code **)(**(int **)(iVar1 + 0x1ac) + 0x34))(auStack_f0,uVar2,iVar4);
  (**(code **)(**(int **)(iVar1 + 0x1ac) + 0x34))(auStack_e4,uVar2,0);
  fStack_48 = 1e+06;
  cVar3 = FUN_00c944d0(&fStack_78,&fStack_6c,auStack_f0,auStack_e4,&fStack_48,param_5);
  if ((cVar3 != '\0') && (fStack_48 < DAT_018fe498)) {
    return 1;
  }
  return 0;
}



/* FUNCTION 30013 ; VA 0x00ca36a0 ; FUN_00ca36a0 */

undefined4 FUN_00ca36a0(int param_1,undefined4 param_2,int param_3,undefined4 param_4,float param_5)

{
  char cVar1;
  int iVar2;
  float *pfVar3;
  int iVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  undefined auStack_58 [12];
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  iVar2 = (**(code **)(**(int **)(param_1 + 0x1ac) + 0x38))(param_2);
  iVar4 = 0;
  if (0 < iVar2) {
    do {
      pfVar3 = (float *)(**(code **)(**(int **)(param_1 + 0x1ac) + 0x34))(auStack_58,param_2,iVar4);
      fStack_14 = *pfVar3 * param_5;
      fStack_8 = pfVar3[1] * param_5;
      fStack_1c = pfVar3[2] * param_5;
      pfVar3 = (float *)FUN_00c157b0();
      fStack_c = pfVar3[1];
      fStack_10 = *pfVar3;
      fStack_18 = pfVar3[2];
      fStack_20 = pfVar3[9];
      fStack_24 = pfVar3[3];
      fStack_28 = pfVar3[4];
      fStack_2c = pfVar3[5];
      fStack_30 = pfVar3[10];
      fStack_34 = pfVar3[6];
      fStack_38 = pfVar3[7];
      fStack_3c = pfVar3[8];
      fStack_40 = pfVar3[0xb];
      pfVar3 = (float *)FUN_00c157b0();
      fVar6 = (fStack_c * fStack_8 + fStack_10 * fStack_14 + fStack_18 * fStack_1c + fStack_20) -
              pfVar3[9];
      fVar5 = (fStack_14 * fStack_24 + fStack_8 * fStack_28 + fStack_1c * fStack_2c + fStack_30) -
              pfVar3[10];
      fVar7 = (fStack_14 * fStack_34 + fStack_8 * fStack_38 + fStack_3c * fStack_1c + fStack_40) -
              pfVar3[0xb];
      fStack_44 = pfVar3[5] * fVar5 + pfVar3[2] * fVar6 + pfVar3[8] * fVar7;
      fStack_48 = pfVar3[4] * fVar5 + pfVar3[1] * fVar6 + pfVar3[7] * fVar7;
      fStack_4c = pfVar3[3] * fVar5 + fVar6 * *pfVar3 + pfVar3[6] * fVar7;
      cVar1 = (**(code **)(**(int **)(param_3 + 0x1ac) + 0x3c))(&fStack_4c,param_4);
      if (cVar1 != '\0') {
        return 1;
      }
      iVar4 = iVar4 + 1;
    } while (iVar4 < iVar2);
  }
  iVar2 = (**(code **)(**(int **)(param_3 + 0x1ac) + 0x38))(param_4);
  iVar4 = 0;
  if (0 < iVar2) {
    do {
      pfVar3 = (float *)(**(code **)(**(int **)(param_3 + 0x1ac) + 0x34))(auStack_58,param_4,iVar4);
      fStack_40 = *pfVar3 * param_5;
      fStack_34 = pfVar3[1] * param_5;
      fStack_2c = pfVar3[2] * param_5;
      pfVar3 = (float *)FUN_00c157b0();
      fStack_38 = pfVar3[1];
      fStack_3c = *pfVar3;
      fStack_30 = pfVar3[2];
      fStack_28 = pfVar3[9];
      fStack_20 = pfVar3[4];
      fStack_24 = pfVar3[3];
      fStack_1c = pfVar3[5];
      fStack_18 = pfVar3[10];
      fStack_10 = pfVar3[7];
      fStack_14 = pfVar3[6];
      fStack_c = pfVar3[8];
      fStack_8 = pfVar3[0xb];
      pfVar3 = (float *)FUN_00c157b0();
      fVar5 = (fStack_40 * fStack_3c + fStack_38 * fStack_34 + fStack_30 * fStack_2c + fStack_28) -
              pfVar3[9];
      fVar7 = (fStack_24 * fStack_40 + fStack_20 * fStack_34 + fStack_2c * fStack_1c + fStack_18) -
              pfVar3[10];
      fVar6 = (fStack_14 * fStack_40 + fStack_34 * fStack_10 + fStack_2c * fStack_c + fStack_8) -
              pfVar3[0xb];
      fStack_44 = pfVar3[5] * fVar7 + pfVar3[2] * fVar5 + pfVar3[8] * fVar6;
      fStack_48 = pfVar3[4] * fVar7 + pfVar3[1] * fVar5 + pfVar3[7] * fVar6;
      fStack_4c = pfVar3[3] * fVar7 + fVar5 * *pfVar3 + pfVar3[6] * fVar6;
      cVar1 = (**(code **)(**(int **)(param_1 + 0x1ac) + 0x3c))(&fStack_4c,param_2);
      if (cVar1 != '\0') {
        return 1;
      }
      iVar4 = iVar4 + 1;
    } while (iVar4 < iVar2);
  }
  return 0;
}



/* FUNCTION 30014 ; VA 0x00ca3ae0 ; FUN_00ca3ae0 */

undefined FUN_00ca3ae0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                      undefined4 param_5)

{
  char cVar1;
  
  cVar1 = FUN_00ca36a0(param_1,param_2,param_3,param_4,param_5);
  if (cVar1 == '\0') {
    cVar1 = FUN_00ca2e20(param_1,param_2,param_3,param_4,param_5);
    if (cVar1 == '\0') {
      return 0;
    }
  }
  return 1;
}



/* FUNCTION 30015 ; VA 0x00ca3b30 ; FUN_00ca3b30 */

void __thiscall FUN_00ca3b30(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  piVar1 = *(int **)(param_1 + 0xb4);
  if (*(int **)(param_1 + 0xb8) == piVar1) {
    FUN_006030d0(piVar1,&param_2);
  }
  else {
    *piVar1 = param_2;
    *(int *)(param_1 + 0xb4) = *(int *)(param_1 + 0xb4) + 4;
  }
  iVar2 = param_2;
  if (*(int **)(param_1 + 4) != (int *)0x0) {
    iVar3 = (**(code **)(**(int **)(param_1 + 4) + 4))();
    if (iVar3 == 0xf) {
      *(uint *)(iVar2 + 8) =
           -(uint)(*(int *)(param_1 + 0x2c) != 0) & *(int *)(param_1 + 0x2c) + 0x50U;
      *(uint *)(iVar2 + 0xc) =
           -(uint)(*(int *)(param_1 + 0x30) != 0) & *(int *)(param_1 + 0x30) + 0x50U;
      iVar3 = FUN_00ffd7b0();
      (**(code **)(**(int **)(iVar3 + 0x2c) + 0xc))(iVar2);
    }
  }
  return;
}



/* FUNCTION 30016 ; VA 0x00ca3bb0 ; FUN_00ca3bb0 */

void __thiscall FUN_00ca3bb0(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  piVar1 = *(int **)(param_1 + 0xc0);
  if (*(int **)(param_1 + 0xc4) == piVar1) {
    FUN_006030d0(piVar1,&param_2);
  }
  else {
    *piVar1 = param_2;
    *(int *)(param_1 + 0xc0) = *(int *)(param_1 + 0xc0) + 4;
  }
  iVar2 = param_2;
  if (*(int **)(param_1 + 4) != (int *)0x0) {
    iVar3 = (**(code **)(**(int **)(param_1 + 4) + 4))();
    if (iVar3 == 0xf) {
      *(uint *)(iVar2 + 8) =
           -(uint)(*(int *)(param_1 + 0x2c) != 0) & *(int *)(param_1 + 0x2c) + 0x50U;
      *(uint *)(iVar2 + 0xc) =
           -(uint)(*(int *)(param_1 + 0x30) != 0) & *(int *)(param_1 + 0x30) + 0x50U;
      iVar3 = FUN_00ffd7b0();
      (**(code **)(**(int **)(iVar3 + 0x2c) + 0x14))(iVar2);
    }
  }
  return;
}



/* FUNCTION 30017 ; VA 0x00ca3c30 ; FUN_00ca3c30 */

void FUN_00ca3c30(int param_1,int param_2,char param_3)

{
  int *piVar1;
  bool bVar2;
  char cVar3;
  int iVar4;
  
  if ((*(char *)(param_1 + 0x223) == '\0') && (cVar3 = FUN_00c14800(), cVar3 == '\0')) {
    bVar2 = false;
  }
  else {
    bVar2 = true;
  }
  if (((param_2 == 0) || (*(char *)(param_2 + 0x223) != '\0')) ||
     (cVar3 = FUN_00c14800(), cVar3 != '\0')) {
    cVar3 = '\x01';
  }
  if (bVar2) {
    if (cVar3 != '\0') {
      return;
    }
  }
  else {
    param_2 = param_1;
    if (cVar3 == '\0') {
      return;
    }
  }
  if (((param_2 != 0) && (*(int *)(param_2 + 0x1a8) != 0)) && (iVar4 = FUN_00c155c0(), iVar4 != 0))
  {
    iVar4 = FUN_00c19fc0(iVar4);
    piVar1 = (int *)(iVar4 + 0x50);
    if (param_3 != '\0') {
      *piVar1 = *piVar1 + 1;
      return;
    }
    *piVar1 = *piVar1 + -1;
  }
  return;
}



/* FUNCTION 30018 ; VA 0x00ca3cc0 ; FUN_00ca3cc0 */

void __fastcall FUN_00ca3cc0(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  char cVar3;
  
  iVar1 = *(int *)(param_1 + 0x2c);
  uVar2 = *(undefined4 *)(param_1 + 0x30);
  if (iVar1 != 0) {
    cVar3 = FUN_00ca0980(param_1);
    if (cVar3 != '\0') {
      FUN_00ca3c30(iVar1,uVar2,0);
    }
  }
  return;
}



/* FUNCTION 30019 ; VA 0x00ca3cf0 ; FUN_00ca3cf0 */

void __fastcall FUN_00ca3cf0(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  char cVar3;
  
  iVar1 = *(int *)(param_1 + 0x2c);
  uVar2 = *(undefined4 *)(param_1 + 0x30);
  if (iVar1 != 0) {
    cVar3 = FUN_00ca0980(param_1);
    if (cVar3 != '\0') {
      FUN_00ca3c30(iVar1,uVar2,1);
    }
  }
  return;
}



/* FUNCTION 30020 ; VA 0x00ca3d20 ; FUN_00ca3d20 */

undefined4 FUN_00ca3d20(int param_1,undefined4 *param_2,int param_3,undefined4 *param_4)

{
  char cVar1;
  int iVar2;
  
  iVar2 = (**(code **)(**(int **)(param_1 + 0x1ac) + 0x40))(*param_2);
  cVar1 = *(char *)(iVar2 + 0x22f + param_1);
  iVar2 = (**(code **)(**(int **)(param_3 + 0x1ac) + 0x40))(*param_4);
  if ((cVar1 != '\x01') && (*(char *)(iVar2 + 0x22f + param_3) != '\x01')) {
    return 0;
  }
  return 1;
}



/* FUNCTION 30021 ; VA 0x00ca3d80 ; FUN_00ca3d80 */

undefined4 FUN_00ca3d80(int param_1,undefined4 *param_2,int param_3,undefined4 *param_4)

{
  char cVar1;
  char cVar2;
  int iVar3;
  
  iVar3 = (**(code **)(**(int **)(param_1 + 0x1ac) + 0x40))(*param_2);
  cVar1 = *(char *)(iVar3 + 0x22f + param_1);
  iVar3 = (**(code **)(**(int **)(param_3 + 0x1ac) + 0x40))(*param_4);
  cVar2 = *(char *)(iVar3 + 0x22f + param_3);
  if ((((cVar1 != '\x06') && (cVar2 != '\x06')) && (cVar1 != '\b')) &&
     (((cVar2 != '\b' && (cVar1 != '\a')) && (cVar2 != '\a')))) {
    return 0;
  }
  return 1;
}



/* FUNCTION 30022 ; VA 0x00ca3df0 ; FUN_00ca3df0 */

undefined4 FUN_00ca3df0(int param_1,undefined4 *param_2,int param_3,undefined4 *param_4)

{
  char cVar1;
  char cVar2;
  int iVar3;
  bool bVar4;
  
  iVar3 = (**(code **)(**(int **)(param_1 + 0x1ac) + 0x40))(*param_2);
  cVar1 = *(char *)(iVar3 + 0x22f + param_1);
  iVar3 = (**(code **)(**(int **)(param_3 + 0x1ac) + 0x40))(*param_4);
  cVar2 = *(char *)(iVar3 + 0x22f + param_3);
  if (cVar1 == '\x03') {
    bVar4 = cVar2 == '\x04';
LAB_00ca3e50:
    if (bVar4) {
      return 1;
    }
  }
  else {
    if (cVar1 == '\x04') {
      if (cVar2 == '\x03') {
        return 1;
      }
      goto LAB_00ca3e57;
    }
    if (cVar1 == '\x05') {
      if (cVar2 == '\x05') {
        return 1;
      }
      if (cVar2 == '\x04') {
        return 1;
      }
      bVar4 = cVar2 == '\x03';
      goto LAB_00ca3e50;
    }
  }
  if (cVar1 != '\x03') {
    return 0;
  }
LAB_00ca3e57:
  if (cVar2 != '\x05') {
    return 0;
  }
  return 1;
}



/* FUNCTION 30023 ; VA 0x00ca3e70 ; FUN_00ca3e70 */

undefined4 FUN_00ca3e70(int param_1,undefined4 *param_2,int param_3,undefined4 *param_4)

{
  char cVar1;
  int iVar2;
  
  iVar2 = (**(code **)(**(int **)(param_1 + 0x1ac) + 0x40))(*param_2);
  cVar1 = *(char *)(iVar2 + 0x22f + param_1);
  iVar2 = (**(code **)(**(int **)(param_3 + 0x1ac) + 0x40))(*param_4);
  if ((cVar1 != '\x02') && (*(char *)(iVar2 + 0x22f + param_3) != '\x02')) {
    return 0;
  }
  return 1;
}



/* FUNCTION 30024 ; VA 0x00ca3ed0 ; FUN_00ca3ed0 */

int * FUN_00ca3ed0(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  if ((param_2 == 0x1a) || (param_2 == 0)) {
    piVar1 = *(int **)(param_1 + 0x1b8);
    if ((piVar1 != (int *)0x0) && (iVar3 = (**(code **)(*piVar1 + 0x10))(), iVar3 == param_2)) {
      return piVar1;
    }
  }
  else {
    iVar3 = 0;
    iVar4 = *(int *)(param_1 + 0x1d4) - *(int *)(param_1 + 0x1d0) >> 3;
    if (0 < iVar4) {
      do {
        piVar1 = (int *)FUN_00c156d0(iVar3);
        iVar2 = (**(code **)(*piVar1 + 0x10))();
        if (iVar2 == param_2) {
          return piVar1;
        }
        iVar3 = iVar3 + 1;
      } while (iVar3 < iVar4);
    }
  }
  return (int *)0x0;
}



/* FUNCTION 30025 ; VA 0x00ca3f50 ; FUN_00ca3f50 */

uint __thiscall FUN_00ca3f50(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x24 + param_2 * 4);
  return -(uint)(iVar1 != 0) & iVar1 + 8U;
}



/* FUNCTION 30026 ; VA 0x00ca3f70 ; FUN_00ca3f70 */

uint FUN_00ca3f70(int param_1)

{
  uint uVar1;
  uint uVar2;
  
  uVar1 = FUN_00c164f0();
  if ((*(int *)(param_1 + 0x30) != 0) && (uVar2 = FUN_00c164f0(), uVar1 < uVar2)) {
    uVar1 = uVar2;
  }
  return uVar1;
}



/* FUNCTION 30027 ; VA 0x00ca3fa0 ; FUN_00ca3fa0 */

void __thiscall FUN_00ca3fa0(int param_1,undefined4 *param_2,int param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined auStack_34 [48];
  
  if (*(int *)(param_1 + 0x2c + param_3 * 4) == 0) {
    puVar4 = (undefined4 *)FUN_0060efa0();
  }
  else {
    FUN_00c157b0();
    iVar5 = 0x40;
    if (param_3 != 0) {
      iVar5 = 0x70;
    }
    puVar4 = (undefined4 *)FUN_0071f260(auStack_34,iVar5 + param_1);
  }
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *param_2 = *puVar4;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  uVar1 = puVar4[5];
  uVar2 = puVar4[6];
  uVar3 = puVar4[7];
  param_2[4] = puVar4[4];
  param_2[5] = uVar1;
  param_2[6] = uVar2;
  param_2[7] = uVar3;
  uVar1 = puVar4[9];
  uVar2 = puVar4[10];
  uVar3 = puVar4[0xb];
  param_2[8] = puVar4[8];
  param_2[9] = uVar1;
  param_2[10] = uVar2;
  param_2[0xb] = uVar3;
  return;
}



/* FUNCTION 30028 ; VA 0x00ca4010 ; FUN_00ca4010 */

int FUN_00ca4010(int param_1)

{
  int iVar1;
  undefined auStack_10 [12];
  
  if (param_1 == 0) {
    FUN_011612d0(auStack_10,2);
    iVar1 = FUN_00d6a2d0(auStack_10,0x38d1b717);
    if (iVar1 == 6) {
      iVar1 = 2;
    }
    return iVar1;
  }
  FUN_011612d0(auStack_10,2);
  iVar1 = FUN_00d6a2d0(auStack_10,0x38d1b717);
  if (iVar1 == 6) {
    iVar1 = 2;
  }
  iVar1 = FUN_00d6a3a0(iVar1);
  return iVar1;
}



/* FUNCTION 30029 ; VA 0x00ca4090 ; FUN_00ca4090 */

int * FUN_00ca4090(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  if ((param_2 != 0x1a) && (param_2 != 0)) {
    iVar3 = 0;
    iVar4 = *(int *)(param_1 + 0x1d4) - *(int *)(param_1 + 0x1d0) >> 3;
    if (0 < iVar4) {
      do {
        piVar1 = (int *)FUN_00c156d0(iVar3);
        iVar2 = (**(code **)(*piVar1 + 0x10))();
        if (iVar2 == param_2) {
          return piVar1;
        }
        iVar3 = iVar3 + 1;
      } while (iVar3 < iVar4);
    }
    return (int *)0x0;
  }
  piVar1 = *(int **)(param_1 + 0x1b8);
  if ((piVar1 != (int *)0x0) && (iVar3 = (**(code **)(*piVar1 + 0x10))(), iVar3 == param_2)) {
    return piVar1;
  }
  return (int *)0x0;
}



/* FUNCTION 30030 ; VA 0x00ca4120 ; FUN_00ca4120 */

undefined4 FUN_00ca4120(int param_1,undefined4 *param_2,int param_3,undefined4 *param_4)

{
  char cVar1;
  char cVar2;
  int iVar3;
  
  iVar3 = (**(code **)(**(int **)(param_1 + 0x1ac) + 0x40))(*param_2);
  cVar1 = *(char *)(iVar3 + 0x22f + param_1);
  iVar3 = (**(code **)(**(int **)(param_3 + 0x1ac) + 0x40))(*param_4);
  cVar2 = *(char *)(iVar3 + 0x22f + param_3);
  if (((((cVar1 != '\x03') || (cVar2 == '\x04')) && ((cVar2 != '\x03' || (cVar1 == '\x04')))) &&
      (((cVar1 != '\x05' || (cVar2 == '\x03')) || (cVar2 == '\x04')))) &&
     (((cVar2 != '\x05' || (cVar1 == '\x03')) || (cVar1 == '\x04')))) {
    return 0;
  }
  return 1;
}



/* FUNCTION 30031 ; VA 0x00ca41a0 ; FUN_00ca41a0 */

void __fastcall FUN_00ca41a0(int param_1)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x2c) != 0) {
    iVar1 = FUN_00c155c0();
    if (iVar1 != 0) {
      *(undefined *)(iVar1 + 0x36) = 1;
    }
  }
  if (*(int *)(param_1 + 0x30) != 0) {
    iVar1 = FUN_00c155c0();
    if (iVar1 != 0) {
      *(undefined *)(iVar1 + 0x36) = 1;
    }
  }
  return;
}



/* FUNCTION 30032 ; VA 0x00ca41d0 ; FUN_00ca41d0 */

bool __thiscall FUN_00ca41d0(int param_1,int param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  char cVar7;
  byte bVar8;
  int iVar9;
  int iVar10;
  uint uVar11;
  uint uVar12;
  int *piVar13;
  char cVar14;
  int *piVar15;
  bool bVar16;
  bool bVar17;
  bool bVar18;
  
  piVar1 = (int *)(param_1 - 8);
  piVar15 = (int *)(-(uint)(param_2 != 0) & param_2 - 8U);
  if (piVar1 == piVar15) {
    return false;
  }
  iVar9 = (**(code **)(*piVar1 + 0x10))();
  iVar10 = (**(code **)(*piVar15 + 0x10))();
  if (iVar9 != iVar10) {
    return iVar9 < iVar10;
  }
  iVar3 = piVar15[0xb];
  iVar4 = *(int *)(param_1 + 0x24);
  iVar5 = *(int *)(param_1 + 0x28);
  iVar6 = piVar15[0xc];
  if (((iVar4 == 0) || (cVar7 = FUN_00c15bc0(), cVar7 != '\0')) &&
     ((iVar5 == 0 || (cVar7 = FUN_00c15bc0(), cVar7 != '\0')))) {
    param_2._3_1_ = 0;
  }
  else {
    param_2._3_1_ = 1;
  }
  if (((iVar3 == 0) || (cVar7 = FUN_00c15bc0(), cVar7 != '\0')) &&
     ((iVar6 == 0 || (cVar7 = FUN_00c15bc0(), cVar7 != '\0')))) {
    bVar8 = 0;
  }
  else {
    bVar8 = 1;
  }
  if (param_2._3_1_ != bVar8) {
    return (bool)((bVar8 ^ 1) & param_2._3_1_);
  }
  if (iVar5 == 0) {
    cVar7 = *(char *)(iVar4 + 0x22b);
  }
  else {
    cVar7 = *(char *)(iVar5 + 0x22b);
    if (*(char *)(iVar5 + 0x22b) <= *(char *)(iVar4 + 0x22b)) {
      cVar7 = *(char *)(iVar4 + 0x22b);
    }
  }
  cVar2 = *(char *)(iVar3 + 0x22b);
  cVar14 = cVar2;
  if ((iVar6 != 0) && (cVar14 = *(char *)(iVar6 + 0x22b), *(char *)(iVar6 + 0x22b) <= cVar2)) {
    cVar14 = cVar2;
  }
  bVar18 = SBORROW1(cVar7,cVar14);
  bVar17 = (char)(cVar7 - cVar14) < '\0';
  bVar16 = cVar7 == cVar14;
  if (bVar16) {
    uVar11 = FUN_00ca3f70(piVar1);
    uVar12 = FUN_00ca3f70(piVar15);
    if (uVar11 != uVar12) {
      return uVar12 < uVar11;
    }
    FUN_009b2c70();
    cVar7 = FUN_00bbe9e0(iVar9);
    if ((cVar7 == '\0') && (cVar7 = FUN_00bbe9e0(iVar10), cVar7 == '\0')) {
      piVar13 = piVar15 + 0x28;
      param_1 = param_1 + 0x98;
    }
    else {
      param_1 = FUN_00c15b60();
      piVar13 = (int *)FUN_00c15b60();
    }
    iVar9 = FUN_00bbc470(param_1,piVar13);
    bVar18 = false;
    bVar17 = iVar9 < 0;
    bVar16 = iVar9 == 0;
    if (bVar16) {
      return piVar1 < piVar15;
    }
  }
  return !bVar16 && bVar18 == bVar17;
}



/* FUNCTION 30033 ; VA 0x00ca4390 ; FUN_00ca4390 */

void __fastcall FUN_00ca4390(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x30);
  if ((*(int *)(param_1 + 0x2c) != 0) && (*(int *)(*(int *)(param_1 + 0x2c) + 0x1b0) != 0)) {
    FUN_00c3e3a0();
  }
  if ((iVar1 != 0) && (*(int *)(iVar1 + 0x1b0) != 0)) {
    FUN_00c3e3a0();
    return;
  }
  return;
}



/* FUNCTION 30034 ; VA 0x00ca43c0 ; FUN_00ca43c0 */

uint __thiscall FUN_00ca43c0(int param_1,int param_2)

{
  uint uVar1;
  
  uVar1 = *(uint *)(param_1 + 0x24);
  if ((-(uint)(param_2 != 0) & param_2 - 8U) == uVar1) {
    uVar1 = *(uint *)(param_1 + 0x28);
  }
  return uVar1 + 8 & -(uint)(uVar1 != 0);
}



/* FUNCTION 30035 ; VA 0x00ca43f0 ; FUN_00ca43f0 */

void FUN_00ca43f0(int param_1,undefined4 *param_2,int param_3,undefined4 *param_4)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float *pfVar8;
  int iVar9;
  undefined4 *puVar10;
  undefined auStack_cc [48];
  undefined auStack_9c [36];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined8 uStack_54;
  float fStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  float fStack_1c;
  float fStack_10;
  ulonglong uStack_c;
  
  pfVar8 = (float *)FUN_00c157b0();
  iVar9 = (**(code **)(**(int **)(param_1 + 0x1ac) + 0x24))(auStack_cc,*param_2);
  fVar1 = *(float *)(iVar9 + 0x28);
  fVar2 = *(float *)(iVar9 + 0x24);
  fVar3 = *(float *)(iVar9 + 0x2c);
  fVar4 = pfVar8[4];
  uStack_c = (ulonglong)(uint)(pfVar8[1] * fVar1 + *pfVar8 * fVar2 + pfVar8[2] * fVar3 + pfVar8[9]);
  fVar5 = pfVar8[3];
  fVar6 = pfVar8[5];
  fVar7 = pfVar8[10];
  fStack_10 = pfVar8[6] * fVar2 + pfVar8[7] * fVar1 + pfVar8[8] * fVar3 + pfVar8[0xb];
  puVar10 = (undefined4 *)FUN_01160c20(auStack_9c,iVar9);
  uStack_78 = *puVar10;
  uStack_74 = puVar10[1];
  uStack_70 = puVar10[2];
  uStack_6c = puVar10[3];
  uStack_68 = puVar10[4];
  uStack_64 = puVar10[5];
  uStack_60 = puVar10[6];
  uStack_5c = puVar10[7];
  uStack_58 = puVar10[8];
  uStack_54 = CONCAT44(fVar5 * fVar2 + fVar4 * fVar1 + fVar6 * fVar3 + fVar7,(int)uStack_c);
  fStack_4c = fStack_10;
  pfVar8 = (float *)FUN_00c157b0();
  iVar9 = (**(code **)(**(int **)(param_3 + 0x1ac) + 0x24))(auStack_cc,*param_4);
  fVar1 = *(float *)(iVar9 + 0x28);
  fVar2 = *(float *)(iVar9 + 0x24);
  fVar3 = *(float *)(iVar9 + 0x2c);
  fVar4 = pfVar8[4];
  uStack_c = (ulonglong)(uint)(pfVar8[1] * fVar1 + fVar2 * *pfVar8 + pfVar8[2] * fVar3 + pfVar8[9]);
  fVar5 = pfVar8[3];
  fVar6 = pfVar8[5];
  fVar7 = pfVar8[10];
  fStack_10 = pfVar8[6] * fVar2 + pfVar8[7] * fVar1 + pfVar8[8] * fVar3 + pfVar8[0xb];
  puVar10 = (undefined4 *)FUN_01160c20(auStack_9c,iVar9);
  uStack_48 = *puVar10;
  uStack_44 = puVar10[1];
  uStack_40 = puVar10[2];
  uStack_3c = puVar10[3];
  uStack_38 = puVar10[4];
  uStack_34 = puVar10[5];
  uStack_30 = puVar10[6];
  uStack_2c = puVar10[7];
  uStack_28 = puVar10[8];
  fStack_1c = fStack_10;
  uStack_24 = CONCAT44(fVar5 * fVar2 + fVar4 * fVar1 + fVar6 * fVar3 + fVar7,(int)uStack_c);
  FUN_00c93120(&uStack_78,&uStack_48,0x3c23d70a);
  return;
}



/* FUNCTION 30036 ; VA 0x00ca4610 ; FUN_00ca4610 */

void __thiscall FUN_00ca4610(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  int *piVar7;
  
  FUN_00598640(param_2);
  uVar3 = -(uint)(*(int *)(param_1 + 0x2c) != 0) & *(int *)(param_1 + 0x2c) + 0x50U;
  uVar4 = -(uint)(*(int *)(param_1 + 0x30) != 0) & *(int *)(param_1 + 0x30) + 0x50U;
  iVar2 = FUN_00ffd7b0();
  piVar7 = *(int **)(param_1 + 0xb0);
  piVar1 = *(int **)(iVar2 + 0x2c);
  uVar6 = 0;
  uVar5 = (uint)((int)*(int **)(param_1 + 0xb4) + (3 - (int)piVar7)) >> 2;
  if (*(int **)(param_1 + 0xb4) < piVar7) {
    uVar5 = 0;
  }
  if (uVar5 != 0) {
    do {
      iVar2 = *piVar7;
      *(uint *)(iVar2 + 8) = uVar3;
      *(uint *)(iVar2 + 0xc) = uVar4;
      (**(code **)(*piVar1 + 0xc))(iVar2);
      uVar6 = uVar6 + 1;
      piVar7 = piVar7 + 1;
    } while (uVar6 != uVar5);
  }
  uVar6 = 0;
  piVar7 = *(int **)(param_1 + 0xbc);
  uVar5 = (uint)((int)*(int **)(param_1 + 0xc0) + (3 - (int)piVar7)) >> 2;
  if (*(int **)(param_1 + 0xc0) < piVar7) {
    uVar5 = 0;
  }
  if (uVar5 != 0) {
    do {
      iVar2 = *piVar7;
      *(uint *)(iVar2 + 8) = uVar3;
      *(uint *)(iVar2 + 0xc) = uVar4;
      (**(code **)(*piVar1 + 0x14))(iVar2);
      uVar6 = uVar6 + 1;
      piVar7 = piVar7 + 1;
    } while (uVar6 != uVar5);
  }
  return;
}



/* FUNCTION 30037 ; VA 0x00ca46f0 ; FUN_00ca46f0 */

void __fastcall FUN_00ca46f0(int param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined4 *puVar5;
  
  iVar2 = FUN_00ffd7b0();
  puVar5 = *(undefined4 **)(param_1 + 0xb0);
  piVar1 = *(int **)(iVar2 + 0x2c);
  uVar4 = 0;
  uVar3 = (uint)((int)*(undefined4 **)(param_1 + 0xb4) + (3 - (int)puVar5)) >> 2;
  if (*(undefined4 **)(param_1 + 0xb4) < puVar5) {
    uVar3 = 0;
  }
  if (uVar3 != 0) {
    do {
      (**(code **)(*piVar1 + 0x10))(*puVar5);
      uVar4 = uVar4 + 1;
      puVar5 = puVar5 + 1;
    } while (uVar4 != uVar3);
  }
  uVar4 = 0;
  puVar5 = *(undefined4 **)(param_1 + 0xbc);
  uVar3 = (uint)((int)*(undefined4 **)(param_1 + 0xc0) + (3 - (int)puVar5)) >> 2;
  if (*(undefined4 **)(param_1 + 0xc0) < puVar5) {
    uVar3 = 0;
  }
  if (uVar3 != 0) {
    do {
      (**(code **)(*piVar1 + 0x18))(*puVar5);
      uVar4 = uVar4 + 1;
      puVar5 = puVar5 + 1;
    } while (uVar4 != uVar3);
  }
  FUN_00ffd7f0();
  return;
}



/* FUNCTION 30038 ; VA 0x00ca47a0 ; FUN_00ca47a0 */

void __thiscall FUN_00ca47a0(int param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  
  uVar5 = 0;
  piVar2 = *(int **)(param_1 + 0xb0);
  uVar4 = *(int *)(param_1 + 0xb4) - (int)piVar2 >> 2;
  if (uVar4 != 0) {
    while (*piVar2 != param_2) {
      uVar5 = uVar5 + 1;
      piVar2 = piVar2 + 1;
      if (uVar4 <= uVar5) {
        return;
      }
    }
    if ((*(int **)(param_1 + 4) != (int *)0x0) &&
       (iVar3 = (**(code **)(**(int **)(param_1 + 4) + 4))(), iVar3 == 0xf)) {
      iVar3 = FUN_00ffd7b0();
      (**(code **)(**(int **)(iVar3 + 0x2c) + 0x10))(param_2);
    }
    iVar1 = *(int *)(param_1 + 0xb0) + uVar5 * 4;
    iVar3 = iVar1 + 4;
    FUN_0170cc70(iVar1,iVar3,*(int *)(param_1 + 0xb4) - iVar3);
    *(int *)(param_1 + 0xb4) = *(int *)(param_1 + 0xb4) + -4;
  }
  return;
}



/* FUNCTION 30039 ; VA 0x00ca4830 ; FUN_00ca4830 */

void __thiscall FUN_00ca4830(int param_1,int param_2,undefined4 *param_3)

{
  float *pfVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  int iVar6;
  undefined4 *puVar7;
  
  iVar6 = 0x40;
  if (param_2 != 0) {
    iVar6 = 0x70;
  }
  pfVar1 = (float *)(iVar6 + 0x24 + param_1);
  iVar6 = iVar6 + param_1;
  if (((((NAN((float)param_3[9]) || NAN(*pfVar1)) != ((float)param_3[9] == *pfVar1)) &&
       ((NAN((float)param_3[10]) || NAN(*(float *)(iVar6 + 0x28))) !=
        ((float)param_3[10] == *(float *)(iVar6 + 0x28)))) &&
      ((NAN((float)param_3[0xb]) || NAN(*(float *)(iVar6 + 0x2c))) !=
       ((float)param_3[0xb] == *(float *)(iVar6 + 0x2c)))) &&
     (cVar5 = FUN_01160ab0(iVar6), cVar5 != '\0')) {
    return;
  }
  puVar7 = (undefined4 *)(param_1 + 0x40);
  uVar2 = param_3[1];
  uVar3 = param_3[2];
  uVar4 = param_3[3];
  if (param_2 != 0) {
    puVar7 = (undefined4 *)(param_1 + 0x70);
  }
  *puVar7 = *param_3;
  puVar7[1] = uVar2;
  puVar7[2] = uVar3;
  puVar7[3] = uVar4;
  uVar2 = param_3[5];
  uVar3 = param_3[6];
  uVar4 = param_3[7];
  puVar7[4] = param_3[4];
  puVar7[5] = uVar2;
  puVar7[6] = uVar3;
  puVar7[7] = uVar4;
  uVar2 = param_3[9];
  uVar3 = param_3[10];
  uVar4 = param_3[0xb];
  puVar7[8] = param_3[8];
  puVar7[9] = uVar2;
  puVar7[10] = uVar3;
  puVar7[0xb] = uVar4;
  FUN_00c94b40(puVar7);
  if (*(int **)(param_1 + 4) != (int *)0x0) {
    iVar6 = (**(code **)(**(int **)(param_1 + 4) + 4))();
    if (iVar6 == 0xf) {
      iVar6 = *(int *)(*(int *)(param_1 + 4) + 4);
    }
    else {
      iVar6 = *(int *)(param_1 + 4);
    }
    if (*(int *)(iVar6 + 0xc) != 0) {
      FUN_00bbea80(param_1);
    }
  }
  return;
}



/* FUNCTION 30040 ; VA 0x00ca48f0 ; FUN_00ca48f0 */

void __thiscall FUN_00ca48f0(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x24) = param_2;
  return;
}



/* FUNCTION 30041 ; VA 0x00ca4900 ; FUN_00ca4900 */

void __thiscall FUN_00ca4900(int param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  if (DAT_01ee41fe != '\0') {
    FUN_01677490(DAT_01ee41fe,"Joint %p, setting primitive %u to %p",param_1,param_2,param_3);
  }
  piVar1 = (int *)(param_1 + (param_2 + 0xb) * 4);
  if (param_3 != *piVar1) {
    if (*(int **)(param_1 + 4) == (int *)0x0) {
      iVar3 = 0;
    }
    else {
      iVar3 = (**(code **)(**(int **)(param_1 + 4) + 4))();
      if (iVar3 == 0xf) {
        iVar3 = *(int *)(*(int *)(param_1 + 4) + 4);
      }
      else {
        iVar3 = *(int *)(param_1 + 4);
      }
      iVar3 = *(int *)(iVar3 + 0xc);
      if ((iVar3 != 0) && (iVar2 = *piVar1, iVar2 != 0)) {
        FUN_00bbf250(param_1,iVar2);
      }
    }
    if (param_2 == 0) {
      *(int *)(param_1 + 0x2c) = param_3;
    }
    else {
      *(int *)(param_1 + 0x30) = param_3;
    }
    if ((iVar3 != 0) && (param_3 != 0)) {
      FUN_00bbf260(param_1,param_3);
    }
  }
  return;
}



/* FUNCTION 30042 ; VA 0x00ca49a0 ; FUN_00ca49a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __thiscall
FUN_00ca49a0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018109bf;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f02624) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f02624);
    if (DAT_01f02624 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01f02600 = RBX::Reflection::RefType<class_RBX::Attachment*>::vftable;
      FUN_016f3654(&LAB_01897ef0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01f02624);
    }
  }
  uVar2 = FUN_00ca4c20();
  FUN_009ca670(uVar2,&DAT_01f02600,param_2,param_3,param_8,param_9,param_10,param_11,param_12,
               param_12,0);
  param_1[0xd] = (int)RBX::IIDREF::vftable;
  uStack_8 = 1;
  *param_1 = (int)RBX::Reflection::
                  RefPropDescriptor<class_RBX::Constraints::Constraint,class_RBX::Attachment>::
                  vftable;
  param_1[0xd] = (int)RBX::Reflection::
                      RefPropDescriptor<class_RBX::Constraints::Constraint,class_RBX::Attachment>::
                      vftable;
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::Constraints::Constraint,class_RBX::Attachment*>::
              GetSetImpl<class_RBX::Attachment*_(__thiscall_RBX::Constraints::Constraint::*)(void)const_,void_(__thiscall_RBX::Constraints::Constraint::*)(class_RBX::Attachment*)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  param_1[0xe] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (**(code **)(*param_1 + 0xc))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar1 = (**(code **)(*param_1 + 8))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30043 ; VA 0x00ca4b00 ; FUN_00ca4b00 */

int FUN_00ca4b00(undefined4 param_1,undefined4 *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  code *pcVar6;
  int iVar7;
  int *piVar8;
  int *piVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1dc0;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)param_3[1];
  piVar8 = (int *)puVar3[1];
  ExceptionList = &pvStack_10;
  if (piVar8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
    piVar8 = (int *)puVar3[1];
  }
  uVar4 = *puVar3;
  puVar3 = (undefined4 *)*param_3;
  piVar9 = (int *)puVar3[1];
  if (piVar9 != (int *)0x0) {
    LOCK();
    piVar9[1] = piVar9[1] + 1;
    UNLOCK();
    piVar9 = (int *)puVar3[1];
  }
  uVar5 = *puVar3;
  uStack_8 = 1;
  pcVar6 = (code *)*param_2;
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
  }
  if (piVar9 != (int *)0x0) {
    LOCK();
    piVar9[1] = piVar9[1] + 1;
    UNLOCK();
  }
  iVar7 = (*pcVar6)(uVar5,piVar9,uVar4,piVar8);
  if (piVar9 != (int *)0x0) {
    piVar1 = piVar9 + 1;
    LOCK();
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar9)();
      LOCK();
      piVar1 = piVar9 + 2;
      iVar2 = *piVar1;
      iVar7 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar7 = (**(code **)(*piVar9 + 4))();
      }
    }
  }
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar9 = piVar8 + 1;
    iVar2 = *piVar9;
    iVar7 = *piVar9;
    *piVar9 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar7 = (**(code **)*piVar8)();
      LOCK();
      piVar9 = piVar8 + 2;
      iVar2 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar7 = (**(code **)(*piVar8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 30044 ; VA 0x00ca4c20 ; FUN_00ca4c20 */

undefined * FUN_00ca4c20(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018109dc;
  pvStack_10 = ExceptionList;
  if (DAT_01f02298 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f024a8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f024a8);
      if (DAT_01f024a8 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Constraint",0,uStack_20,0,0,0x1b,0,&DAT_01f0228c);
        FUN_016f3654(&LAB_01897ee0);
        FUN_016f37bf(&DAT_01f024a8);
      }
    }
    DAT_01f02298 = &DAT_01f022a0;
  }
  ExceptionList = pvStack_10;
  return DAT_01f02298;
}



/* FUNCTION 30045 ; VA 0x00ca4d00 ; FUN_00ca4d00 */

undefined4 * __thiscall FUN_00ca4d00(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6248;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0;
  puVar5 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_00ca59a0;
    puVar5[3] = _guard_check_icall;
    puVar5[4] = 0;
    puVar5[5] = param_1;
    uVar1 = param_3[1];
    uVar2 = param_3[2];
    uVar3 = param_3[3];
    puVar5[6] = *param_3;
    puVar5[7] = uVar1;
    puVar5[8] = uVar2;
    puVar5[9] = uVar3;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 30046 ; VA 0x00ca4dc0 ; thunk_FUN_00ca6970 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00ca6970(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01810b26;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f02594) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f02594);
    if (DAT_01f02594 == -1) {
      uStack_8 = 0;
      FUN_009ca470("ActuatorRelativeTo");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01f02530 = RBX::Reflection::EnumDesc<enum_RBX::Constraints::ActuatorRelativeTo>::vftable;
      FUN_009caf20(&DAT_01d68b24,3);
      FUN_016f3654(&LAB_01897e20);
      FUN_016f37bf(&DAT_01f02594);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01f02530;
}



/* FUNCTION 30047 ; VA 0x00ca4dd0 ; thunk_FUN_00ca6a20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00ca6a20(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01810b46;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f025fc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f025fc);
    if (DAT_01f025fc == -1) {
      uStack_8 = 0;
      FUN_009ca470("ActuatorType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01f02598 = RBX::Reflection::EnumDesc<enum_RBX::Constraints::ActuatorType>::vftable;
      FUN_009caf20(&DAT_01d68b0c,3);
      FUN_016f3654(&LAB_01897e40);
      FUN_016f37bf(&DAT_01f025fc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01f02598;
}



/* FUNCTION 30048 ; VA 0x00ca4de0 ; thunk_FUN_00ca6ad0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00ca6ad0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01810b66;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f0252c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f0252c);
    if (DAT_01f0252c == -1) {
      uStack_8 = 0;
      FUN_009ca470("AlignType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01f024c8 = RBX::Reflection::EnumDesc<enum_RBX::Constraints::AlignType>::vftable;
      FUN_009caf20(&DAT_01d68b3c,2);
      FUN_016f3654(&LAB_01897e60);
      FUN_016f37bf(&DAT_01f0252c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01f024c8;
}



/* FUNCTION 30049 ; VA 0x00ca4df0 ; FUN_00ca4df0 */

undefined2 __fastcall FUN_00ca4df0(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_00d6bbd0();
  return CONCAT11((char)(*(ushort *)(iVar2 + 0x1da) >> 8),
                  (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
                  (uint)*(ushort *)(iVar2 + 0x1da));
}



/* FUNCTION 30050 ; VA 0x00ca4e20 ; FUN_00ca4e20 */

undefined4 * __thiscall FUN_00ca4e20(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01810a89;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0089a650(param_2);
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::Constraints::Constraint,class_RBX::Instance>::vftable;
  uVar1 = FUN_00ca4c20();
  param_1[3] = uVar1;
  param_1[0x15] = RBX::IJointOwner::vftable;
  param_1[0x16] = RBX::IAdornable::vftable;
  param_1[0x17] = 0xffffffff;
  param_1[0x18] = 0xffffffff;
  param_1[0x19] = 0xffffffff;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  *param_1 = RBX::Constraints::Constraint::vftable;
  param_1[0x15] = RBX::Constraints::Constraint::vftable;
  param_1[0x16] = RBX::Constraints::Constraint::vftable;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  *(undefined *)(param_1 + 0x1f) = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  uStack_8._0_1_ = 6;
  uStack_8._1_3_ = 0;
  FUN_016f4053(param_1 + 0x27,4,2,FUN_00610ca0,FUN_005f60a0);
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0xc2;
  uStack_8._0_1_ = 9;
  *(undefined2 *)(param_1 + 0x2c) = 0x100;
  *(undefined *)((int)param_1 + 0xb2) = 0;
  iVar2 = FUN_01674e20(200);
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  if (iVar2 == 0) {
    iVar2 = 0;
  }
  else {
    iVar2 = FUN_00ca2960();
  }
  param_1[0x20] = iVar2;
  *(undefined4 *)(iVar2 + 0xa0) = param_1[6];
  *(undefined4 *)(iVar2 + 0xa4) = param_1[7];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30051 ; VA 0x00ca4fb0 ; FUN_00ca4fb0 */

void __fastcall FUN_00ca4fb0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017949a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Constraints::Constraint::vftable;
  param_1[0x15] = RBX::Constraints::Constraint::vftable;
  param_1[0x16] = RBX::Constraints::Constraint::vftable;
  FUN_00ca6140();
  if ((undefined4 *)param_1[0x20] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x20])(1);
  }
  param_1[0x20] = 0;
  uStack_8 = 0;
  FUN_01679490();
  iVar4 = param_1[0x2a];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar4 = param_1[0x29];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 0xffffffff;
  FUN_016f32d1(param_1 + 0x27,4,2,FUN_005f60a0);
  uStack_8 = 2;
  FUN_01679490();
  iVar4 = param_1[0x26];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 3;
  FUN_01679490();
  iVar4 = param_1[0x25];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  piVar1 = (int *)param_1[0x24];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[2] + -1;
    piVar1[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  piVar1 = (int *)param_1[0x22];
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar2 = piVar1 + 2;
    iVar4 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_0115a710();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30052 ; VA 0x00ca5150 ; FUN_00ca5150 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00ca5150(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Constraints::ActuatorRelativeTo>::vftable;
  _DAT_01f024b8 = _DAT_01f024b8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 30053 ; VA 0x00ca5180 ; FUN_00ca5180 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00ca5180(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Constraints::ActuatorType>::vftable;
  _DAT_01f024b0 = _DAT_01f024b0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 30054 ; VA 0x00ca51b0 ; FUN_00ca51b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00ca51b0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Constraints::AlignType>::vftable;
  _DAT_01f024c0 = _DAT_01f024c0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 30055 ; VA 0x00ca51e0 ; FUN_00ca51e0 */

undefined4 * __thiscall FUN_00ca51e0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Attachment*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 30056 ; VA 0x00ca5210 ; FUN_00ca5210 */

undefined4 __thiscall FUN_00ca5210(undefined4 param_1,byte param_2)

{
  FUN_00ca4fb0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xb4);
  }
  return param_1;
}



/* FUNCTION 30057 ; VA 0x00ca5240 ; FUN_00ca5240 */

undefined4 * __thiscall FUN_00ca5240(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Attachment*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 30058 ; VA 0x00ca5270 ; FUN_00ca5270 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00ca5270(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_00ca6970();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01f02644) {
      FUN_016f3809(&DAT_01f02644);
      if (DAT_01f02644 == -1) {
        _DAT_01f02638 = FUN_005c65e0;
        _DAT_01f0263c = FUN_005c65e0;
        _DAT_01f02640 = _guard_check_icall;
        FUN_016f37bf(&DAT_01f02644);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01f02638) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01f02638;
  }
  return;
}



/* FUNCTION 30059 ; VA 0x00ca5330 ; FUN_00ca5330 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00ca5330(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_00ca6a20();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01f02634) {
      FUN_016f3809(&DAT_01f02634);
      if (DAT_01f02634 == -1) {
        _DAT_01f02628 = FUN_005c65e0;
        _DAT_01f0262c = FUN_005c65e0;
        _DAT_01f02630 = _guard_check_icall;
        FUN_016f37bf(&DAT_01f02634);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01f02628) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01f02628;
  }
  return;
}



/* FUNCTION 30060 ; VA 0x00ca53f0 ; FUN_00ca53f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00ca53f0(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_00ca6ad0();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01f02654) {
      FUN_016f3809(&DAT_01f02654);
      if (DAT_01f02654 == -1) {
        _DAT_01f02648 = FUN_005c65e0;
        _DAT_01f0264c = FUN_005c65e0;
        _DAT_01f02650 = _guard_check_icall;
        FUN_016f37bf(&DAT_01f02654);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01f02648) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01f02648;
  }
  return;
}



/* FUNCTION 30061 ; VA 0x00ca54b0 ; FUN_00ca54b0 */

void FUN_00ca54b0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00ca6970();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 30062 ; VA 0x00ca54f0 ; FUN_00ca54f0 */

void FUN_00ca54f0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00ca6a20();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 30063 ; VA 0x00ca5530 ; FUN_00ca5530 */

void FUN_00ca5530(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00ca6ad0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 30064 ; VA 0x00ca5570 ; FUN_00ca5570 */

void __fastcall FUN_00ca5570(int *param_1)

{
  byte *pbVar1;
  char cVar2;
  byte bVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  undefined *puVar8;
  undefined4 *******pppppppuVar9;
  uint uVar10;
  bool bVar11;
  code *pcStack_84;
  undefined1 *puStack_80;
  char *pcStack_7c;
  undefined4 ******ppppppuStack_78;
  undefined4 uStack_74;
  uint uStack_70;
  undefined4 ******appppppuStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  undefined auStack_3f [3];
  undefined1 *puStack_3c;
  char *pcStack_38;
  undefined4 ******ppppppuStack_34;
  undefined4 uStack_30;
  uint uStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01810ad8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00ca6140();
  piVar4 = (int *)FUN_00587490(auStack_20);
  iStack_18 = *piVar4;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar6 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  piVar4 = (int *)FUN_00587490(auStack_28);
  iStack_14 = *piVar4;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_24[1] + -1;
    piStack_24[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar6 = piStack_24[2] + -1;
      piStack_24[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  iVar6 = iStack_18;
  *(undefined *)((int)param_1 + 0xb2) = 0;
  if ((((param_1[0x1d] != 0) && (*(int *)(param_1[0x1d] + 0x1b4) != 0)) && (iStack_18 != 0)) &&
     ((iVar5 = FUN_00a9d0e0(iStack_18), iVar5 != 0 &&
      (iVar5 = FUN_006e16a0(*(undefined4 *)(iVar6 + 0x34)), iVar6 = iStack_14, iVar5 != 0)))) {
    if (iStack_14 == 0) {
      cVar2 = (**(code **)(*param_1 + 0xa4))();
      bVar11 = cVar2 == '\0';
    }
    else {
      iVar5 = FUN_00a9d0e0(iStack_14);
      if (iVar5 == 0) goto LAB_00ca5680;
      iVar6 = FUN_006e16a0(*(undefined4 *)(iVar6 + 0x34));
      bVar11 = iVar6 == 0;
    }
    if (!bVar11) {
      *(undefined *)((int)param_1 + 0xb2) = 1;
    }
  }
LAB_00ca5680:
  FUN_0115b050();
  if (*(char *)((int)param_1 + 0xb1) == '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  if (*(char *)((int)param_1 + 0xb2) == '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  iVar6 = FUN_00ca5a50();
  if (iVar6 == 0) {
    iStack_14 = 0;
  }
  else {
    iVar6 = FUN_00ca5a50();
    iStack_14 = FUN_006e16a0(*(undefined4 *)(iVar6 + 0x34));
  }
  iVar6 = FUN_00ca5ab0();
  if (iVar6 == 0) {
    iVar6 = 0;
  }
  else {
    iVar6 = FUN_00ca5ab0();
    iVar6 = FUN_006e16a0(*(undefined4 *)(iVar6 + 0x34));
  }
  if (iStack_14 == 0) {
    ExceptionList = pvStack_10;
    return;
  }
  if ((iVar6 == 0) && (cVar2 = (**(code **)(*param_1 + 0xa4))(), cVar2 == '\0')) {
    ExceptionList = pvStack_10;
    return;
  }
  piStack_1c = *(int **)(iStack_14 + 0xa8);
  if (iVar6 == 0) {
    iVar6 = 0;
  }
  else {
    iVar6 = *(int *)(iVar6 + 0xa8);
  }
  iStack_14 = *(int *)(param_1[0x1d] + 0x1b4);
  if (piStack_1c == (int *)0x0) {
    iVar5 = 0;
  }
  else {
    iVar5 = *(int *)((int)piStack_1c + 0x1a8);
  }
  iStack_18 = iVar6;
  if (iStack_14 != iVar5) goto LAB_00ca584d;
  cVar2 = (**(code **)(*param_1 + 0xa4))();
  if (cVar2 == '\0') {
    if (iVar6 == 0) {
      iVar6 = 0;
    }
    else {
      iVar6 = *(int *)(iVar6 + 0x1a8);
    }
LAB_00ca577a:
    if (iStack_14 != iVar6) goto LAB_00ca584d;
  }
  else if (iVar6 != 0) {
    iVar6 = *(int *)(iVar6 + 0x1a8);
    goto LAB_00ca577a;
  }
  iVar6 = param_1[0x20];
  uVar7 = (**(code **)(*param_1 + 0xa8))();
  *(undefined4 *)(iVar6 + 0xa8) = uVar7;
  iVar6 = param_1[0x20];
  bVar3 = (**(code **)(*param_1 + 0xac))();
  pbVar1 = (byte *)(iVar6 + 0xac);
  *pbVar1 = *pbVar1 ^ (*(byte *)(iVar6 + 0xac) ^ bVar3) & 1;
  iVar6 = param_1[0x20];
  cVar2 = (**(code **)(*param_1 + 0xb0))();
  pbVar1 = (byte *)(iVar6 + 0xac);
  *pbVar1 = *pbVar1 ^ (cVar2 * '\x02' ^ *(byte *)(iVar6 + 0xac)) & 2;
  FUN_00ca48f0(param_1 + 0x15);
  iVar6 = iStack_14;
  piVar4 = piStack_1c;
  if (piStack_1c == (int *)0x0) {
    piVar4 = *(int **)(iStack_14 + 0xd4);
  }
  FUN_00ca4900(0,piVar4);
  iVar5 = iStack_18;
  if (iStack_18 == 0) {
    iVar5 = *(int *)(iVar6 + 0xd4);
  }
  FUN_00ca4900(1,iVar5);
  (**(code **)(*param_1 + 0xb4))(0);
  (**(code **)(*param_1 + 0xb4))(1);
  FUN_00bbe190(param_1[0x20]);
LAB_00ca584d:
  FUN_00ca6f70();
  iVar6 = FUN_008f78c0(param_1);
  if (iVar6 != 0) {
    piVar4 = *(int **)(iVar6 + 0x43c);
    iVar6 = piVar4[1] - (int)piVar4;
    iVar5 = *piVar4 - (int)piVar4;
    if ((iVar6 < 1) && (iVar6 < 0)) {
      iVar6 = FUN_0055c3d0(auStack_3f,-iVar5,-(iVar6 + (uint)(iVar5 != 0)));
      *(undefined *)(iVar6 + -1) = 0x2d;
      puVar8 = (undefined *)(iVar6 + -1);
    }
    else {
      puVar8 = (undefined *)FUN_0055c3d0(auStack_3f,iVar5,iVar6);
    }
    uStack_5c = 0;
    appppppuStack_6c[0] = (undefined4 ******)((uint)appppppuStack_6c[0] & 0xffffff00);
    uStack_58 = 0xf;
    if (puVar8 != auStack_3f) {
      FUN_005542c0(puVar8,(int)auStack_3f - (int)puVar8);
    }
    uStack_2c = uStack_2c & 0xffffff00;
    puStack_3c = &DAT_018c5f98;
    ppppppuStack_78 = appppppuStack_6c;
    if (0xf < uStack_58) {
      ppppppuStack_78 = appppppuStack_6c[0];
    }
    uStack_70 = uStack_2c;
    pcStack_38 = "MechanicalJointsInUse";
    uStack_30 = 0;
    uStack_8 = 0;
    pcStack_84 = FUN_0087c450;
    puStack_80 = &DAT_018c5f98;
    pcStack_7c = "MechanicalJointsInUse";
    uStack_74 = 0;
    ppppppuStack_34 = ppppppuStack_78;
    FUN_008ab7d0(&DAT_01f02290,&pcStack_84);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_58) {
      uVar10 = uStack_58 + 1;
      pppppppuVar9 = (undefined4 *******)appppppuStack_6c[0];
      if (0xfff < uVar10) {
        pppppppuVar9 = (undefined4 *******)appppppuStack_6c[0][-1];
        uVar10 = uStack_58 + 0x24;
        if (0x1f < (uint)((int)appppppuStack_6c[0] + (-4 - (int)pppppppuVar9))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppppuVar9,uVar10);
    }
    uStack_5c = 0;
    uStack_58 = 0xf;
    appppppuStack_6c[0] = (undefined4 ******)((uint)appppppuStack_6c[0] & 0xffffff00);
  }
  FUN_00ca3cf0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30065 ; VA 0x00ca5990 ; FUN_00ca5990 */

void FUN_00ca5990(void)

{
  FUN_00ca5570();
  return;
}



/* FUNCTION 30066 ; VA 0x00ca59a0 ; FUN_00ca59a0 */

int FUN_00ca59a0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b4ed0;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined *)&param_2;
  puStack_14 = (undefined *)&param_4;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00ca4b00(param_1,param_1 + 0x18,&puStack_18,0);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_5)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 30067 ; VA 0x00ca5a50 ; FUN_00ca5a50 */

undefined4 FUN_00ca5a50(void)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00587490(auStack_c);
  uVar2 = *puVar4;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return uVar2;
  }
  return uVar2;
}



/* FUNCTION 30068 ; VA 0x00ca5ab0 ; FUN_00ca5ab0 */

undefined4 FUN_00ca5ab0(void)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00587490(auStack_c);
  uVar2 = *puVar4;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return uVar2;
  }
  return uVar2;
}



/* FUNCTION 30069 ; VA 0x00ca5b10 ; FUN_00ca5b10 */

void FUN_00ca5b10(void)

{
  int iVar1;
  
  if (DAT_01f024ac == 0) {
    iVar1 = FUN_00ca4c20();
    DAT_01f024ac = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 30070 ; VA 0x00ca5b30 ; FUN_00ca5b30 */

void __thiscall FUN_00ca5b30(int param_1,undefined4 *param_2)

{
  *param_2 = *(undefined4 *)(param_1 + 0xac);
  return;
}



/* FUNCTION 30071 ; VA 0x00ca5b50 ; FUN_00ca5b50 */

float10 FUN_00ca5b50(void)

{
  return (float10)DAT_018e0028;
}



/* FUNCTION 30072 ; VA 0x00ca5b80 ; FUN_00ca5b80 */

void FUN_00ca5b80(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00ca6970();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 30073 ; VA 0x00ca5bc0 ; FUN_00ca5bc0 */

void FUN_00ca5bc0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00ca6a20();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 30074 ; VA 0x00ca5c00 ; FUN_00ca5c00 */

void FUN_00ca5c00(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00ca6ad0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 30075 ; VA 0x00ca5c40 ; FUN_00ca5c40 */

void __thiscall FUN_00ca5c40(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int iVar2;
  
  FUN_008a3ee0(param_2);
  uVar1 = FUN_00a9d0e0(param_1);
  *(undefined4 *)(param_1 + 0x74) = uVar1;
  uVar1 = FUN_008b3380(param_1);
  *(undefined4 *)(param_1 + 0x78) = uVar1;
  iVar2 = FUN_007c0ce0();
  *(bool *)(param_1 + 0x7c) = iVar2 != 0;
  FUN_0115b050();
  FUN_00ca5570();
  FUN_00ca6f70();
  return;
}



/* FUNCTION 30076 ; VA 0x00ca5c90 ; FUN_00ca5c90 */

int * FUN_00ca5c90(int param_1,int *param_2,int param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d47f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_00587490(auStack_20);
  iStack_14 = *piVar3;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    piVar3 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      piVar3 = (int *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piVar3 = (int *)(**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if (param_1 != iStack_14) goto LAB_00ca5d36;
  if (param_3 == 0) {
LAB_00ca5d29:
    param_3 = 0;
  }
  else {
    iVar2 = *(int *)(param_3 + 0xc);
    iVar4 = FUN_00aff8c0();
    if ((uint)*(ushort *)(iVar4 + 0x1da) <
        (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) goto LAB_00ca5d29;
  }
  piVar3 = (int *)FUN_00ca5eb0(0,param_3);
LAB_00ca5d36:
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    piVar3 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      piVar3 = (int *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piVar3 = (int *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    piVar3 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piVar3 = (int *)(**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piVar3 = (int *)(**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar3;
}



/* FUNCTION 30077 ; VA 0x00ca5da0 ; FUN_00ca5da0 */

int * FUN_00ca5da0(int param_1,int *param_2,int param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d47f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_00587490(auStack_20);
  iStack_14 = *piVar3;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    piVar3 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      piVar3 = (int *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piVar3 = (int *)(**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if (param_1 != iStack_14) goto LAB_00ca5e46;
  if (param_3 == 0) {
LAB_00ca5e39:
    param_3 = 0;
  }
  else {
    iVar2 = *(int *)(param_3 + 0xc);
    iVar4 = FUN_00aff8c0();
    if ((uint)*(ushort *)(iVar4 + 0x1da) <
        (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) goto LAB_00ca5e39;
  }
  piVar3 = (int *)FUN_00ca5eb0(1,param_3);
LAB_00ca5e46:
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    piVar3 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      piVar3 = (int *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piVar3 = (int *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    piVar3 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piVar3 = (int *)(**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piVar3 = (int *)(**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar3;
}



/* FUNCTION 30078 ; VA 0x00ca5eb0 ; FUN_00ca5eb0 */

void __thiscall FUN_00ca5eb0(undefined4 param_1,undefined4 *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017cbd31;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01679490();
  FUN_00ca5570();
  if (param_3 != 0) {
    param_3 = param_3 + 0xf0;
    iStack_8 = 0;
    uVar4 = FUN_01675290(DAT_02110da8);
    iStack_8._0_1_ = 1;
    puVar5 = (undefined4 *)FUN_01674e20(0x1c);
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      *puVar5 = 0;
      puVar5[1] = 1;
      puVar5[2] = FUN_00ca5990;
      puVar5[3] = _guard_check_icall;
      puVar5[4] = 0;
      puVar5[5] = param_3;
      puVar5[6] = param_1;
    }
    FUN_016797d0(puVar5);
    if (puVar5 != (undefined4 *)0x0) {
      LOCK();
      puVar5[1] = puVar5[1] + 1;
      UNLOCK();
    }
    iStack_8._0_1_ = 2;
    param_2 = puVar5;
    FUN_01675290(uVar4);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    cVar3 = FUN_01679300(&param_2);
    if (cVar3 != '\0') {
      FUN_01679490();
      FUN_016791c0(&param_2);
    }
    if (param_2 != (undefined4 *)0x0) {
      piVar1 = param_2 + 1;
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_01674ea0(param_2);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30079 ; VA 0x00ca5ff0 ; FUN_00ca5ff0 */

void __fastcall FUN_00ca5ff0(int *param_1)

{
  (**(code **)(*param_1 + 0xb4))(0);
  FUN_00ca6f70();
  return;
}



/* FUNCTION 30080 ; VA 0x00ca6010 ; FUN_00ca6010 */

void __fastcall FUN_00ca6010(int *param_1)

{
  (**(code **)(*param_1 + 0xb4))(1);
  FUN_00ca6f70();
  return;
}



/* FUNCTION 30081 ; VA 0x00ca6030 ; FUN_00ca6030 */

void __fastcall FUN_00ca6030(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x80);
  *(undefined4 *)(iVar1 + 0xa0) = *(undefined4 *)(param_1 + 0x18);
  *(undefined4 *)(iVar1 + 0xa4) = *(undefined4 *)(param_1 + 0x1c);
  return;
}



/* FUNCTION 30082 ; VA 0x00ca6050 ; FUN_00ca6050 */

void FUN_00ca6050(void)

{
  FUN_00ca6f70();
  return;
}



/* FUNCTION 30083 ; VA 0x00ca6060 ; FUN_00ca6060 */

void __thiscall FUN_00ca6060(int *param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined auStack_14 [4];
  int *piStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  if (*(char *)((int)param_1 + 0xb2) != '\0') {
    piVar2 = (int *)FUN_00587490(auStack_14);
    iStack_8 = *piVar2;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_10[1] + -1;
      piStack_10[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_10)();
        LOCK();
        iVar1 = piStack_10[2] + -1;
        piStack_10[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piStack_10 + 4))();
        }
      }
    }
    puVar3 = (undefined4 *)FUN_00587490(auStack_1c);
    uStack_c = *puVar3;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_18[1] + -1;
      piStack_18[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar2 = piStack_18 + 2;
        iVar1 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    iVar1 = iStack_8;
    if ((*(char *)(param_2 + 0x10) != '\0') && (iStack_8 != 0)) {
      iVar4 = (**(code **)(*(int *)(param_1[0x1e] + 0x144) + 8))();
      FUN_01000f50(iVar1,uStack_c,iVar4 + 0x6c);
    }
    (**(code **)(*param_1 + 0xbc))(param_2,iVar1,uStack_c);
  }
  return;
}



/* FUNCTION 30084 ; VA 0x00ca6140 ; FUN_00ca6140 */

void __fastcall FUN_00ca6140(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  iVar3 = *(int *)(param_1 + 0x80);
  piVar1 = *(int **)(iVar3 + 4);
  if (piVar1 != (int *)0x0) {
    iVar2 = (**(code **)(*piVar1 + 4))();
    iVar3 = *(int *)(iVar3 + 4);
    if (iVar2 == 0xf) {
      iVar3 = *(int *)(iVar3 + 4);
    }
    if (*(int *)(iVar3 + 0xc) != 0) {
      FUN_00ca3cc0();
      FUN_00bc0420(*(undefined4 *)(param_1 + 0x80));
      FUN_00ca48f0(0);
      FUN_00ca4900(0,0);
      FUN_00ca4900(1,0);
    }
  }
  return;
}



/* FUNCTION 30085 ; VA 0x00ca61b0 ; FUN_00ca61b0 */

void __thiscall FUN_00ca61b0(int param_1,int param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  if ((*(char *)(param_1 + 0x5a) != '\0') && (*(char *)(param_1 + 0x58) != '\0')) {
    *(undefined4 *)(param_2 + 0x18) = 7;
    pcVar1 = *(code **)(*(int *)(param_1 + -0x58) + 0xb8);
    uVar2 = FUN_00ca5ab0();
    uVar3 = FUN_00ca5a50();
    (*pcVar1)(param_2,uVar3,uVar2);
  }
  return;
}



/* FUNCTION 30086 ; VA 0x00ca6200 ; FUN_00ca6200 */

void __thiscall FUN_00ca6200(int *param_1,undefined4 param_2,byte param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 *puVar4;
  char *pcVar5;
  undefined auStack_68 [48];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined auStack_14 [4];
  int *piStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  if (*(char *)((int)param_1 + 0xb2) != '\0') {
    puVar4 = (undefined4 *)FUN_00587490(auStack_14);
    uStack_c = *puVar4;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[1] + -1;
      piStack_10[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_10)();
        LOCK();
        iVar2 = piStack_10[2] + -1;
        piStack_10[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_10 + 4))();
        }
      }
    }
    puVar4 = (undefined4 *)FUN_00587490(auStack_1c);
    uStack_8 = *puVar4;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[1] + -1;
      piStack_18[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piStack_18 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    if ((param_1[0x1e] == 0) || (cVar3 = FUN_008b4100(), cVar3 == '\0')) {
      FUN_0060efa0();
      uStack_28 = 0;
      uStack_24 = 0;
      uStack_20 = 0;
      cVar3 = (**(code **)(*param_1 + 0xcc))(auStack_68,&uStack_28);
      if (cVar3 != '\0') {
        pcVar5 = &DAT_01d71704;
        if ((param_3 & 2) != 0) {
          pcVar5 = s_333_fff__01d716f4;
        }
        uStack_38 = *(undefined4 *)pcVar5;
        uStack_34 = *(undefined4 *)(pcVar5 + 4);
        uStack_30 = *(undefined4 *)(pcVar5 + 8);
        uStack_2c = *(undefined4 *)(pcVar5 + 0xc);
        FUN_0114dc00(auStack_68,&uStack_28,param_2,&uStack_38,0x3ca3d70a);
      }
      if (*(char *)(param_1 + 0x2c) == '\0') {
        (**(code **)(*param_1 + 0xb8))(param_2,uStack_c,uStack_8);
      }
    }
  }
  return;
}



/* FUNCTION 30087 ; VA 0x00ca6340 ; FUN_00ca6340 */

void __thiscall FUN_00ca6340(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 uVar7;
  int iVar8;
  code *pcStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  int *piStack_20;
  undefined4 *puStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01810b00;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined4 *)(param_1 + 0x84);
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  piVar4 = (int *)FUN_00587490(&iStack_24);
  piVar1 = piStack_20;
  iStack_18 = *piVar4;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_20[1] + -1;
    piStack_20[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar4 = piVar1 + 2;
      iVar8 = *piVar4 + -1;
      *piVar4 = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (iStack_18 != param_2) {
    puVar5 = (undefined4 *)FUN_0060dcd0(&iStack_24,param_2);
    iVar8 = puVar5[1];
    if (iVar8 != 0) {
      LOCK();
      *(int *)(iVar8 + 8) = *(int *)(iVar8 + 8) + 1;
      UNLOCK();
      iVar8 = puVar5[1];
    }
    *puStack_1c = *puVar5;
    piVar1 = (int *)puStack_1c[1];
    puStack_1c[1] = iVar8;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar8 = piVar1[2] + -1;
      piVar1[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar8 = piStack_20[1] + -1;
      piStack_20[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar8 = piStack_20[2] + -1;
        piStack_20[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar8 = iStack_14;
    FUN_00ca5570();
    if (param_2 == 0) {
      FUN_01679490();
      FUN_01679490();
    }
    else {
      puStack_1c = *(undefined4 **)(param_2 + 0x34);
      if ((puStack_1c == (undefined4 *)0x0) ||
         (iVar2 = puStack_1c[3], iVar6 = FUN_00aff8c0(), puVar5 = puStack_1c, iVar8 = iStack_14,
         (uint)*(ushort *)(iVar6 + 0x1da) <
         (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
        puVar5 = (undefined4 *)0x0;
      }
      FUN_00ca5eb0(0,puVar5);
      pcStack_2c = FUN_00ca5c90;
      uStack_28 = 0;
      iStack_24 = iVar8;
      puStack_1c = (undefined4 *)FUN_00ca4d00(&iStack_18,&pcStack_2c);
      uStack_8 = 0;
      cVar3 = FUN_01679300(puStack_1c);
      if (cVar3 != '\0') {
        FUN_01679490();
        FUN_016791c0(puStack_1c);
      }
      uStack_8 = 0xffffffff;
      if (iStack_18 != 0) {
        piVar1 = (int *)(iStack_18 + 4);
        LOCK();
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          FUN_01674ea0(iStack_18);
        }
      }
      pcStack_2c = FUN_00ca5ff0;
      uStack_28 = 0;
      iStack_24 = iVar8;
      uVar7 = FUN_00836450(&puStack_1c,&pcStack_2c);
      uStack_8 = 1;
      cVar3 = FUN_01679300(uVar7);
      if (cVar3 != '\0') {
        FUN_01679490();
        FUN_016791c0(uVar7);
      }
      uStack_8 = 0xffffffff;
      if (puStack_1c != (undefined4 *)0x0) {
        piVar1 = puStack_1c + 1;
        LOCK();
        iVar8 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar8 == 1) {
          FUN_01674ea0(puStack_1c);
        }
      }
    }
    FUN_008a4940(&DAT_0213aa70);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30088 ; VA 0x00ca65a0 ; FUN_00ca65a0 */

void __thiscall FUN_00ca65a0(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 uVar7;
  int iVar8;
  code *pcStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  int *piStack_20;
  undefined4 *puStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01810b00;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined4 *)(param_1 + 0x8c);
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  piVar4 = (int *)FUN_00587490(&iStack_24);
  piVar1 = piStack_20;
  iStack_18 = *piVar4;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_20[1] + -1;
    piStack_20[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar4 = piVar1 + 2;
      iVar8 = *piVar4 + -1;
      *piVar4 = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (iStack_18 != param_2) {
    puVar5 = (undefined4 *)FUN_0060dcd0(&iStack_24,param_2);
    iVar8 = puVar5[1];
    if (iVar8 != 0) {
      LOCK();
      *(int *)(iVar8 + 8) = *(int *)(iVar8 + 8) + 1;
      UNLOCK();
      iVar8 = puVar5[1];
    }
    *puStack_1c = *puVar5;
    piVar1 = (int *)puStack_1c[1];
    puStack_1c[1] = iVar8;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar8 = piVar1[2] + -1;
      piVar1[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar8 = piStack_20[1] + -1;
      piStack_20[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar8 = piStack_20[2] + -1;
        piStack_20[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar8 = iStack_14;
    FUN_00ca5570();
    if (param_2 == 0) {
      FUN_01679490();
      FUN_01679490();
    }
    else {
      puStack_1c = *(undefined4 **)(param_2 + 0x34);
      if ((puStack_1c == (undefined4 *)0x0) ||
         (iVar2 = puStack_1c[3], iVar6 = FUN_00aff8c0(), puVar5 = puStack_1c, iVar8 = iStack_14,
         (uint)*(ushort *)(iVar6 + 0x1da) <
         (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
        puVar5 = (undefined4 *)0x0;
      }
      FUN_00ca5eb0(1,puVar5);
      pcStack_2c = FUN_00ca5da0;
      uStack_28 = 0;
      iStack_24 = iVar8;
      puStack_1c = (undefined4 *)FUN_00ca4d00(&iStack_18,&pcStack_2c);
      uStack_8 = 0;
      cVar3 = FUN_01679300(puStack_1c);
      if (cVar3 != '\0') {
        FUN_01679490();
        FUN_016791c0(puStack_1c);
      }
      uStack_8 = 0xffffffff;
      if (iStack_18 != 0) {
        piVar1 = (int *)(iStack_18 + 4);
        LOCK();
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          FUN_01674ea0(iStack_18);
        }
      }
      pcStack_2c = FUN_00ca6010;
      uStack_28 = 0;
      iStack_24 = iVar8;
      uVar7 = FUN_00836450(&puStack_1c,&pcStack_2c);
      uStack_8 = 1;
      cVar3 = FUN_01679300(uVar7);
      if (cVar3 != '\0') {
        FUN_01679490();
        FUN_016791c0(uVar7);
      }
      uStack_8 = 0xffffffff;
      if (puStack_1c != (undefined4 *)0x0) {
        piVar1 = puStack_1c + 1;
        LOCK();
        iVar8 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar8 == 1) {
          FUN_01674ea0(puStack_1c);
        }
      }
    }
    FUN_008a4940(&DAT_0213aaac);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30089 ; VA 0x00ca6800 ; FUN_00ca6800 */

void __thiscall FUN_00ca6800(int param_1,int *param_2)

{
  if (*param_2 != *(int *)(param_1 + 0xac)) {
    *(int *)(param_1 + 0xac) = *param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 30090 ; VA 0x00ca6830 ; FUN_00ca6830 */

void __thiscall FUN_00ca6830(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0xb1)) {
    FUN_00ca6f70();
    *(char *)(param_1 + 0xb1) = param_2;
    FUN_00ca5570();
    FUN_008a4940(&DAT_0213aae8);
  }
  return;
}



/* FUNCTION 30091 ; VA 0x00ca6870 ; FUN_00ca6870 */

void __thiscall FUN_00ca6870(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  
  piVar2 = param_3;
  if ((param_3 != (int *)0x0) &&
     (iVar1 = param_3[3], iVar3 = FUN_00d6bbd0(),
     (uint)*(ushort *)(iVar3 + 0x1da) <
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    piVar6 = (int *)param_1[1];
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    if (param_2 == (int *)0x0) {
      param_2 = (int *)&DAT_018e3e8c;
    }
    else {
      (**(code **)(*param_2 + 0x10))();
      param_2 = (int *)FUN_005543f0();
    }
    (**(code **)(*piVar2 + 0x10))();
    uVar4 = FUN_005543f0();
    (**(code **)(*param_1 + 0x4c))();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Expected %s got %s for %s:%s.",uVar5,uVar4,param_2,piVar6);
  }
  param_3 = piVar2;
  (**(code **)(*(int *)param_1[0xe] + 0x10))(param_2,&param_3);
  return;
}



/* FUNCTION 30092 ; VA 0x00ca6920 ; FUN_00ca6920 */

void __thiscall FUN_00ca6920(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0xb0)) {
    *(char *)(param_1 + 0xb0) = param_2;
    FUN_008a4940(&DAT_0213ab58);
    FUN_0115b050();
  }
  return;
}



/* FUNCTION 30093 ; VA 0x00ca6950 ; FUN_00ca6950 */

undefined __fastcall FUN_00ca6950(int param_1)

{
  if ((((*(char *)(param_1 + 0x24) == '\0') && (*(char *)(param_1 + 0x5a) != '\0')) &&
      (*(char *)(param_1 + 0x58) != '\0')) && (*(char *)(param_1 + 0x59) != '\0')) {
    return 1;
  }
  return 0;
}



/* FUNCTION 30094 ; VA 0x00ca6970 ; FUN_00ca6970 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00ca6970(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01810b26;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f02594) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f02594);
    if (DAT_01f02594 == -1) {
      uStack_8 = 0;
      FUN_009ca470("ActuatorRelativeTo");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01f02530 = RBX::Reflection::EnumDesc<enum_RBX::Constraints::ActuatorRelativeTo>::vftable;
      FUN_009caf20(&DAT_01d68b24,3);
      FUN_016f3654(&LAB_01897e20);
      FUN_016f37bf(&DAT_01f02594);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01f02530;
}



/* FUNCTION 30095 ; VA 0x00ca6a20 ; FUN_00ca6a20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00ca6a20(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01810b46;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f025fc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f025fc);
    if (DAT_01f025fc == -1) {
      uStack_8 = 0;
      FUN_009ca470("ActuatorType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01f02598 = RBX::Reflection::EnumDesc<enum_RBX::Constraints::ActuatorType>::vftable;
      FUN_009caf20(&DAT_01d68b0c,3);
      FUN_016f3654(&LAB_01897e40);
      FUN_016f37bf(&DAT_01f025fc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01f02598;
}



/* FUNCTION 30096 ; VA 0x00ca6ad0 ; FUN_00ca6ad0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00ca6ad0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01810b66;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f0252c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f0252c);
    if (DAT_01f0252c == -1) {
      uStack_8 = 0;
      FUN_009ca470("AlignType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01f024c8 = RBX::Reflection::EnumDesc<enum_RBX::Constraints::AlignType>::vftable;
      FUN_009caf20(&DAT_01d68b3c,2);
      FUN_016f3654(&LAB_01897e60);
      FUN_016f37bf(&DAT_01f0252c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01f024c8;
}



/* FUNCTION 30097 ; VA 0x00ca6b80 ; FUN_00ca6b80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00ca6b80(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f02644) {
    FUN_016f3809(&DAT_01f02644);
    if (DAT_01f02644 == -1) {
      _DAT_01f02638 = FUN_005c65e0;
      _DAT_01f0263c = FUN_005c65e0;
      _DAT_01f02640 = _guard_check_icall;
      FUN_016f37bf(&DAT_01f02644);
    }
  }
  return &DAT_01f02638;
}



/* FUNCTION 30098 ; VA 0x00ca6bf0 ; FUN_00ca6bf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00ca6bf0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f02634) {
    FUN_016f3809(&DAT_01f02634);
    if (DAT_01f02634 == -1) {
      _DAT_01f02628 = FUN_005c65e0;
      _DAT_01f0262c = FUN_005c65e0;
      _DAT_01f02630 = _guard_check_icall;
      FUN_016f37bf(&DAT_01f02634);
    }
  }
  return &DAT_01f02628;
}



/* FUNCTION 30099 ; VA 0x00ca6c60 ; FUN_00ca6c60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00ca6c60(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f02654) {
    FUN_016f3809(&DAT_01f02654);
    if (DAT_01f02654 == -1) {
      _DAT_01f02648 = FUN_005c65e0;
      _DAT_01f0264c = FUN_005c65e0;
      _DAT_01f02650 = _guard_check_icall;
      FUN_016f37bf(&DAT_01f02654);
    }
  }
  return &DAT_01f02648;
}



/* FUNCTION 30100 ; VA 0x00ca6cd0 ; FUN_00ca6cd0 */

int * FUN_00ca6cd0(undefined8 *param_1,undefined8 *param_2,undefined8 *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined8 *puVar6;
  undefined auStack_1c [12];
  undefined auStack_10 [4];
  int *piStack_c;
  int iStack_8;
  
  piVar4 = (int *)FUN_00587490(auStack_10);
  piVar2 = piStack_c;
  iStack_8 = *piVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_c + 1;
    iVar3 = *piVar1;
    piVar4 = (int *)*piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      piVar4 = (int *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        piVar4 = (int *)(**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (iStack_8 != 0) {
    puVar5 = (undefined4 *)FUN_00587490(auStack_10);
    piVar4 = piStack_c;
    iStack_8 = *puVar5;
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_c[1] + -1;
      piStack_c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        piVar2 = piVar4 + 2;
        iVar3 = *piVar2 + -1;
        *piVar2 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    puVar6 = (undefined8 *)FUN_00d6cb20(auStack_1c);
    *param_1 = *puVar6;
    *(undefined4 *)(param_1 + 1) = *(undefined4 *)(puVar6 + 1);
    FUN_00587490(auStack_10);
    piVar4 = piStack_c;
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_c[1] + -1;
      piStack_c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        piVar2 = piVar4 + 2;
        iVar3 = *piVar2 + -1;
        *piVar2 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    puVar6 = (undefined8 *)FUN_00d6c520(auStack_1c);
    *param_2 = *puVar6;
    *(undefined4 *)(param_2 + 1) = *(undefined4 *)(puVar6 + 1);
    FUN_00587490(auStack_10);
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_c[1] + -1;
      piStack_c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        piVar4 = piStack_c + 2;
        iVar3 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piStack_c + 4))();
        }
      }
    }
    puVar6 = (undefined8 *)FUN_00d6cbe0(auStack_1c);
    *param_3 = *puVar6;
    piVar4 = *(int **)(puVar6 + 1);
    *(int **)(param_3 + 1) = piVar4;
  }
  return piVar4;
}



/* FUNCTION 30101 ; VA 0x00ca6e20 ; FUN_00ca6e20 */

int * FUN_00ca6e20(undefined8 *param_1,undefined8 *param_2,undefined8 *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined8 *puVar6;
  undefined auStack_1c [12];
  undefined auStack_10 [4];
  int *piStack_c;
  int iStack_8;
  
  piVar4 = (int *)FUN_00587490(auStack_10);
  piVar2 = piStack_c;
  iStack_8 = *piVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_c + 1;
    iVar3 = *piVar1;
    piVar4 = (int *)*piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      piVar4 = (int *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        piVar4 = (int *)(**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (iStack_8 != 0) {
    puVar5 = (undefined4 *)FUN_00587490(auStack_10);
    piVar4 = piStack_c;
    iStack_8 = *puVar5;
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_c[1] + -1;
      piStack_c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        piVar2 = piVar4 + 2;
        iVar3 = *piVar2 + -1;
        *piVar2 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    puVar6 = (undefined8 *)FUN_00d6cb20(auStack_1c);
    *param_1 = *puVar6;
    *(undefined4 *)(param_1 + 1) = *(undefined4 *)(puVar6 + 1);
    FUN_00587490(auStack_10);
    piVar4 = piStack_c;
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_c[1] + -1;
      piStack_c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        piVar2 = piVar4 + 2;
        iVar3 = *piVar2 + -1;
        *piVar2 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    puVar6 = (undefined8 *)FUN_00d6c520(auStack_1c);
    *param_2 = *puVar6;
    *(undefined4 *)(param_2 + 1) = *(undefined4 *)(puVar6 + 1);
    FUN_00587490(auStack_10);
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_c[1] + -1;
      piStack_c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        piVar4 = piStack_c + 2;
        iVar3 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piStack_c + 4))();
        }
      }
    }
    puVar6 = (undefined8 *)FUN_00d6cbe0(auStack_1c);
    *param_3 = *puVar6;
    piVar4 = *(int **)(puVar6 + 1);
    *(int **)(param_3 + 1) = piVar4;
  }
  return piVar4;
}



/* FUNCTION 30102 ; VA 0x00ca6f70 ; FUN_00ca6f70 */

void __fastcall FUN_00ca6f70(int param_1)

{
  int iVar1;
  
  if ((((*(char *)(param_1 + 0xb1) != '\0') && (*(char *)(param_1 + 0xb2) != '\0')) &&
      (*(int *)(param_1 + 0x80) != 0)) &&
     ((*(int *)(param_1 + 0x74) != 0 && (*(int *)(*(int *)(param_1 + 0x74) + 0x1b4) != 0)))) {
    iVar1 = FUN_00ca5a50();
    if ((iVar1 != 0) &&
       ((iVar1 = FUN_006c7c70(), iVar1 != 0 && (*(int *)(*(int *)(iVar1 + 0xa8) + 0x1a8) != 0)))) {
      FUN_00bc1c10(*(int *)(iVar1 + 0xa8),1);
    }
    iVar1 = FUN_00ca5ab0();
    if (((iVar1 != 0) && (iVar1 = FUN_006c7c70(), iVar1 != 0)) &&
       (*(int *)(*(int *)(iVar1 + 0xa8) + 0x1a8) != 0)) {
      FUN_00bc1c10(*(int *)(iVar1 + 0xa8),1);
    }
    FUN_00ca4390();
    return;
  }
  return;
}



/* FUNCTION 30103 ; VA 0x00ca7020 ; FUN_00ca7020 */

int __thiscall FUN_00ca7020(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01810b70;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Stats::CoreMemoryStatsItem*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 30104 ; VA 0x00ca70f2 ; Catch_All@00ca70f2 */

void Catch_All_00ca70f2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 30105 ; VA 0x00ca7110 ; FUN_00ca7110 */

int __thiscall FUN_00ca7110(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01810b80;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Stats::DeveloperTagStatsItem*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 30106 ; VA 0x00ca71e2 ; Catch_All@00ca71e2 */

void Catch_All_00ca71e2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 30107 ; VA 0x00ca7200 ; FUN_00ca7200 */

int __thiscall FUN_00ca7200(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01810b90;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Stats::MemoryTrackerCategoryStatsItem*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 30108 ; VA 0x00ca72d2 ; Catch_All@00ca72d2 */

void Catch_All_00ca72d2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 30109 ; VA 0x00ca72f0 ; FUN_00ca72f0 */

int __thiscall FUN_00ca72f0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01810ba0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Stats::PerformanceStatsChildItem*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 30110 ; VA 0x00ca73c2 ; Catch_All@00ca73c2 */

void Catch_All_00ca73c2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 30111 ; VA 0x00ca73e0 ; FUN_00ca73e0 */

int __thiscall FUN_00ca73e0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01810bb0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Stats::PlaceMemoryStatsItem*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 30112 ; VA 0x00ca74b2 ; Catch_All@00ca74b2 */

void Catch_All_00ca74b2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 30113 ; VA 0x00ca74d0 ; FUN_00ca74d0 */

int __thiscall FUN_00ca74d0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01810bc0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Stats::UntrackedMemoryStatsItem*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 30114 ; VA 0x00ca75a2 ; Catch_All@00ca75a2 */

void Catch_All_00ca75a2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 30115 ; VA 0x00ca75c0 ; FUN_00ca75c0 */

undefined4 * FUN_00ca75c0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01810c08;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009fb200();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x78);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0170d1f0(puVar3,0,0x78);
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar4 = FUN_009fb200();
    puVar3[3] = uVar4;
    *(undefined8 *)(puVar3 + 0x16) = 0;
    puVar3[0x1c] = 0;
    puVar3[0x1d] = 0xf;
    *(undefined *)(puVar3 + 0x18) = 0;
    *puVar3 = RBX::Stats::CoreMemoryStatsItem::vftable;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00ca7020(puVar3,param_1);
  uStack_8 = 7;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30116 ; VA 0x00ca76c0 ; FUN_00ca76c0 */

undefined4 * FUN_00ca76c0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01810c5b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009fb200();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x88);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0170d1f0(puVar3,0,0x88);
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar4 = FUN_009fb200();
    puVar3[3] = uVar4;
    *(undefined8 *)(puVar3 + 0x16) = 0;
    puVar3[0x1c] = 0;
    puVar3[0x1d] = 0xf;
    *(undefined *)(puVar3 + 0x18) = 0;
    *puVar3 = RBX::Stats::DeveloperTagStatsItem::vftable;
    puVar3[0x1f] = 0;
    puVar3[0x20] = 0;
    puVar3[0x21] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00ca7110(puVar3,param_1);
  uStack_8 = 7;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30117 ; VA 0x00ca77f0 ; FUN_00ca77f0 */

undefined4 * FUN_00ca77f0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01810cab;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009fb200();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x80);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0170d1f0(puVar3,0,0x80);
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar4 = FUN_009fb200();
    puVar3[3] = uVar4;
    *(undefined8 *)(puVar3 + 0x16) = 0;
    puVar3[0x1c] = 0;
    puVar3[0x1d] = 0xf;
    *(undefined *)(puVar3 + 0x18) = 0;
    *puVar3 = RBX::Stats::MemoryTrackerCategoryStatsItem::vftable;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00ca7200(puVar3,param_1);
  uStack_8 = 7;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30118 ; VA 0x00ca7900 ; FUN_00ca7900 */

undefined4 * FUN_00ca7900(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01810cfb;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009fb200();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x80);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0170d1f0(puVar3,0,0x80);
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar4 = FUN_009fb200();
    puVar3[3] = uVar4;
    *(undefined8 *)(puVar3 + 0x16) = 0;
    puVar3[0x1c] = 0;
    puVar3[0x1d] = 0xf;
    *(undefined *)(puVar3 + 0x18) = 0;
    *puVar3 = RBX::Stats::PerformanceStatsChildItem::vftable;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00ca72f0(puVar3,param_1);
  uStack_8 = 7;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30119 ; VA 0x00ca7a10 ; FUN_00ca7a10 */

undefined4 * FUN_00ca7a10(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01810d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009fb200();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x78);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0170d1f0(puVar3,0,0x78);
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar4 = FUN_009fb200();
    puVar3[3] = uVar4;
    *(undefined8 *)(puVar3 + 0x16) = 0;
    puVar3[0x1c] = 0;
    puVar3[0x1d] = 0xf;
    *(undefined *)(puVar3 + 0x18) = 0;
    *puVar3 = RBX::Stats::PlaceMemoryStatsItem::vftable;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00ca73e0(puVar3,param_1);
  uStack_8 = 7;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30120 ; VA 0x00ca7b10 ; FUN_00ca7b10 */

undefined4 * FUN_00ca7b10(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01810d98;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009fb200();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x78);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0170d1f0(puVar3,0,0x78);
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar4 = FUN_009fb200();
    puVar3[3] = uVar4;
    *(undefined8 *)(puVar3 + 0x16) = 0;
    puVar3[0x1c] = 0;
    puVar3[0x1d] = 0xf;
    *(undefined *)(puVar3 + 0x18) = 0;
    *puVar3 = RBX::Stats::UntrackedMemoryStatsItem::vftable;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00ca74d0(puVar3,param_1);
  uStack_8 = 7;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30121 ; VA 0x00ca7c10 ; FUN_00ca7c10 */

undefined4 * __fastcall FUN_00ca7c10(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01810dee;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
  uVar1 = FUN_009fb200();
  param_1[3] = uVar1;
  *(undefined8 *)(param_1 + 0x16) = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0xf;
  *(undefined *)(param_1 + 0x18) = 0;
  uStack_8 = 1;
  *param_1 = RBX::Stats::PerformanceStatsItem::vftable;
  FUN_016f4053(param_1 + 0x1e,8,6,FUN_005502b0,FUN_00550b30);
  uStack_8._0_1_ = 2;
  FUN_016f4053(param_1 + 0x2a,8,6,FUN_005502b0,FUN_00550b30);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_008a6520(&DAT_01d68b68);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30122 ; VA 0x00ca7cd0 ; FUN_00ca7cd0 */

int __thiscall FUN_00ca7cd0(int param_1,byte param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  
  iVar1 = *(int *)(param_1 + 0x7c);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x84) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_00ca7d8f;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x7c) = 0;
    *(undefined4 *)(param_1 + 0x80) = 0;
    *(undefined4 *)(param_1 + 0x84) = 0;
  }
  uVar3 = *(uint *)(param_1 + 0x74);
  if (0xf < uVar3) {
    iVar1 = *(int *)(param_1 + 0x60);
    uVar4 = uVar3 + 1;
    iVar2 = iVar1;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar4 = uVar3 + 0x24;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_00ca7d8f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0xf;
  *(undefined *)(param_1 + 0x60) = 0;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x88);
  }
  return param_1;
}



/* FUNCTION 30123 ; VA 0x00ca7da0 ; FUN_00ca7da0 */

int __thiscall FUN_00ca7da0(int param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_016f32d1(param_1 + 0xa8,8,6,FUN_00550b30);
  FUN_016f32d1(param_1 + 0x78,8,6,FUN_00550b30);
  uVar1 = *(uint *)(param_1 + 0x74);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x60);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0xf;
  *(undefined *)(param_1 + 0x60) = 0;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xd8);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30124 ; VA 0x00ca7e60 ; FUN_00ca7e60 */

undefined4 * __thiscall FUN_00ca7e60(int param_1,undefined4 *param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01810e19;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00ca75c0(param_2);
  uStack_8 = 0;
  (**(code **)(*(int *)*param_2 + 0x38))(&DAT_01d68b80);
  FUN_008a65e0(*(undefined4 *)(param_1 + 0x78),0);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 30125 ; VA 0x00ca7ee0 ; FUN_00ca7ee0 */

undefined4 * __thiscall FUN_00ca7ee0(int param_1,undefined4 *param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01810e49;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00ca7a10(param_2);
  uStack_8 = 0;
  (**(code **)(*(int *)*param_2 + 0x38))(&DAT_01d68b98);
  FUN_008a65e0(*(undefined4 *)(param_1 + 0x78),0);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 30126 ; VA 0x00ca7f60 ; FUN_00ca7f60 */

int * FUN_00ca7f60(void)

{
  int *piVar1;
  char cVar2;
  uint *puVar3;
  code *pcVar4;
  int iVar5;
  int *piVar6;
  undefined uVar7;
  int iVar8;
  uint uVar9;
  undefined4 uVar10;
  int *piVar11;
  char *pcVar12;
  char *pcVar13;
  uint uVar14;
  uint uVar15;
  int *piVar16;
  uint auStack_5c [4];
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_44;
  int *piStack_40;
  code *pcStack_3c;
  int *piStack_38;
  int *piStack_34;
  int *piStack_30;
  char *pcStack_2c;
  code *pcStack_28;
  uint uStack_24;
  int *piStack_20;
  uint uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01810ecb;
  pvStack_10 = ExceptionList;
  uVar14 = 0;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  FUN_00ca7e60(&uStack_44);
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  FUN_00ca7ee0(&pcStack_3c);
  iStack_14 = 0;
  do {
    iVar5 = iStack_14;
    if ((iStack_14 != 0) && (iStack_14 != 0x11)) {
      pcStack_28 = pcStack_3c;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_00ca76c0(&piStack_34);
      uVar14 = uVar14 | 4;
      piStack_20 = piStack_34;
      uVar15 = 0;
      piStack_34[0x1e] = iVar5;
      uStack_1c = 0;
      uStack_24 = uVar14;
      uStack_18 = uVar14;
      iVar8 = FUN_01675020();
      piVar11 = piStack_20;
      if (iVar8 != 0) {
        do {
          iVar8 = FUN_01675030(uVar15);
          if (iVar5 == iVar8) {
            puVar3 = (uint *)piVar11[0x20];
            if ((uint *)piVar11[0x21] == puVar3) {
              FUN_00595d30(puVar3,&uStack_1c);
              uVar15 = uStack_1c;
            }
            else {
              *puVar3 = uVar15;
              piVar11[0x20] = piVar11[0x20] + 4;
            }
          }
          uVar15 = uVar15 + 1;
          uStack_1c = uVar15;
          uVar9 = FUN_01675020();
          uVar14 = uStack_24;
        } while (uVar15 < uVar9);
      }
      pcVar4 = *(code **)(*piStack_34 + 0x38);
      uVar10 = FUN_00cce030(auStack_5c,iStack_14);
      uStack_8._0_1_ = 3;
      (*pcVar4)(uVar10);
      uStack_8._0_1_ = 2;
      uVar7 = (undefined)uStack_8;
      uStack_8._0_1_ = 2;
      if (0xf < uStack_48) {
        uVar9 = uStack_48 + 1;
        uVar15 = auStack_5c[0];
        if (0xfff < uVar9) {
          uVar15 = *(uint *)(auStack_5c[0] - 4);
          uVar9 = uStack_48 + 0x24;
          if (0x1f < (auStack_5c[0] - uVar15) - 4) goto LAB_00ca82d5;
        }
        FUN_01674ea0(uVar15,uVar9);
      }
      uStack_4c = 0;
      uStack_48 = 0xf;
      auStack_5c[0] = auStack_5c[0] & 0xffffff00;
      FUN_008a65e0(pcStack_28,0);
      piVar11 = piStack_30;
      uVar14 = uVar14 & 0xfffffffb;
      uStack_18 = uVar14;
      if (piStack_30 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_30[1] + -1;
        piStack_30[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_30)();
          LOCK();
          piVar16 = piVar11 + 2;
          iVar5 = *piVar16 + -1;
          *piVar16 = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar11 + 4))();
          }
        }
      }
    }
    iStack_14 = iStack_14 + 1;
  } while (iStack_14 < 0x17);
  uStack_8._0_1_ = 4;
  FUN_00ca7b10(&piStack_34);
  uStack_18 = uVar14 | 8;
  (**(code **)(*piStack_34 + 0x38))(&DAT_01d68bb0);
  FUN_008a65e0(*(undefined4 *)(pcStack_2c + 0x78),0);
  piVar11 = piStack_30;
  uVar14 = uVar14 & 0xfffffff7;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_18 = uVar14;
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_30[1] + -1;
    piStack_30[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar16 = piVar11 + 2;
      iVar5 = *piVar16 + -1;
      *piVar16 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar11 + 4))();
      }
    }
  }
  piVar11 = (int *)FUN_01675020();
  piVar16 = (int *)0x0;
  piStack_20 = piVar11;
  if (piVar11 != (int *)0x0) {
    do {
      piVar11 = (int *)FUN_01675030(piVar16);
      if (piVar11 == (int *)0x0) {
        uStack_24 = uStack_44;
        uStack_8._0_1_ = 5;
        FUN_00ca77f0(&piStack_34);
        uStack_18 = uVar14 | 0x10;
        piStack_34[0x1e] = (int)piVar16;
        pcStack_28 = *(code **)(*piStack_34 + 0x38);
        pcVar12 = (char *)FUN_01675050(piVar16);
        uStack_4c = 0;
        uStack_48 = 0xf;
        auStack_5c[0] = auStack_5c[0] & 0xffffff00;
        pcStack_2c = pcVar12 + 1;
        pcVar13 = pcVar12;
        do {
          cVar2 = *pcVar13;
          pcVar13 = pcVar13 + 1;
        } while (cVar2 != '\0');
        FUN_005542c0(pcVar12,(int)pcVar13 - (int)pcStack_2c);
        uStack_8._0_1_ = 6;
        (*pcStack_28)(auStack_5c);
        uStack_8._0_1_ = 5;
        if (0xf < uStack_48) {
          uVar9 = uStack_48 + 1;
          uVar15 = auStack_5c[0];
          if (0xfff < uVar9) {
            uVar15 = *(uint *)(auStack_5c[0] - 4);
            uVar9 = uStack_48 + 0x24;
            uVar7 = (undefined)uStack_8;
            if (0x1f < (auStack_5c[0] - uVar15) - 4) {
LAB_00ca82d5:
              uStack_8._0_1_ = uVar7;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar15,uVar9);
        }
        uStack_4c = 0;
        uStack_48 = 0xf;
        auStack_5c[0] = auStack_5c[0] & 0xffffff00;
        piVar11 = (int *)FUN_008a65e0(uStack_24,0);
        piVar6 = piStack_30;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        uVar14 = uVar14 & 0xffffffef;
        uStack_18 = uVar14;
        if (piStack_30 != (int *)0x0) {
          LOCK();
          piVar1 = piStack_30 + 1;
          iVar5 = *piVar1;
          piVar11 = (int *)*piVar1;
          *piVar1 = iVar5 + -1;
          UNLOCK();
          if (iVar5 + -1 == 0) {
            (**(code **)*piStack_30)();
            LOCK();
            piVar1 = piVar6 + 2;
            iVar5 = *piVar1;
            piVar11 = (int *)*piVar1;
            *piVar1 = iVar5 + -1;
            UNLOCK();
            if (iVar5 + -1 == 0) {
              piVar11 = (int *)(**(code **)(*piVar6 + 4))();
            }
          }
        }
      }
      piVar16 = (int *)((int)piVar16 + 1);
    } while (piVar16 < piStack_20);
  }
  if (piStack_38 != (int *)0x0) {
    LOCK();
    piVar16 = piStack_38 + 1;
    iVar5 = *piVar16;
    piVar11 = (int *)*piVar16;
    *piVar16 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)*piStack_38)();
      LOCK();
      piVar16 = piStack_38 + 2;
      iVar5 = *piVar16;
      piVar11 = (int *)*piVar16;
      *piVar16 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        piVar11 = (int *)(**(code **)(*piStack_38 + 4))();
      }
    }
  }
  if (piStack_40 != (int *)0x0) {
    LOCK();
    piVar16 = piStack_40 + 1;
    iVar5 = *piVar16;
    piVar11 = (int *)*piVar16;
    *piVar16 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      piVar11 = (int *)(**(code **)*piStack_40)();
      LOCK();
      piVar16 = piStack_40 + 2;
      iVar5 = *piVar16;
      *piVar16 = *piVar16 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        piVar11 = (int *)(**(code **)(*piStack_40 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar11;
}



/* FUNCTION 30127 ; VA 0x00ca82e0 ; FUN_00ca82e0 */

undefined4 FUN_00ca82e0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if ((param_1 != 0) && (param_1 != -0xc)) {
    FUN_005789c0(&DAT_01ea8dec,&LAB_005cf1b0);
    uVar3 = FUN_005cf480();
    piVar4 = (int *)FUN_008aa140(uVar3);
    if (*piVar4 == 0) {
      uVar3 = FUN_009fb760();
      piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
      iVar1 = *piVar5;
      iVar2 = piVar5[1];
      *piVar5 = 0;
      piVar5[1] = 0;
      *piVar4 = iVar1;
      piVar5 = (int *)piVar4[1];
      piVar4[1] = iVar2;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar1 = piVar5[1] + -1;
        piVar5[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar1 = piVar5[2] + -1;
          piVar5[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      if (piStack_8 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_8[1] + -1;
        piStack_8[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_8)();
          LOCK();
          piVar5 = piStack_8 + 2;
          iVar1 = *piVar5;
          *piVar5 = *piVar5 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_8 + 4))();
          }
        }
      }
    }
    if (*piVar4 != 0) {
      return *(undefined4 *)(*piVar4 + 0x58);
    }
  }
  return 0;
}



/* FUNCTION 30128 ; VA 0x00ca83c0 ; FUN_00ca83c0 */

void __fastcall FUN_00ca83c0(int param_1)

{
  int *piVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  undefined4 *puVar7;
  char *pcVar8;
  uint uVar9;
  char *pcVar10;
  uint uVar11;
  int iVar12;
  uint uVar13;
  undefined8 uVar14;
  uint auStack_54 [4];
  undefined4 uStack_44;
  uint uStack_40;
  int *piStack_3c;
  int *piStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  uint uStack_2c;
  undefined4 *puStack_28;
  code *pcStack_24;
  int *piStack_20;
  char *pcStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_01810f1a;
  pvStack_10 = ExceptionList;
  uVar13 = 0;
  iVar12 = 0;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  do {
    iVar6 = iStack_14;
    iStack_8 = 0;
    puStack_28 = (undefined4 *)FUN_00ca7900(&piStack_3c);
    uStack_2c = uVar13 | 1;
    piStack_3c[0x1e] = iVar12;
    piStack_20 = piStack_3c;
    pcStack_24 = *(code **)(*piStack_3c + 0x38);
    switch(iVar12) {
    case 0:
      pcVar8 = "Memory";
      break;
    case 1:
      pcVar8 = "CPU";
      break;
    case 2:
      pcVar8 = "GPU";
      break;
    case 3:
      pcVar8 = "Ping";
      break;
    case 4:
      pcVar8 = "NetworkReceived";
      break;
    case 5:
      pcVar8 = "NetworkSent";
      break;
    default:
      pcVar8 = "*Unknown*";
    }
    uStack_44 = 0;
    uStack_40 = 0xf;
    auStack_54[0] = auStack_54[0] & 0xffffff00;
    pcStack_1c = pcVar8 + 1;
    pcVar10 = pcVar8;
    do {
      cVar2 = *pcVar10;
      pcVar10 = pcVar10 + 1;
    } while (cVar2 != '\0');
    uStack_18 = uStack_2c;
    FUN_005542c0(pcVar8,(int)pcVar10 - (int)pcStack_1c);
    iStack_8._0_1_ = 1;
    (*pcStack_24)(auStack_54);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_40) {
      uVar11 = uStack_40 + 1;
      uVar9 = auStack_54[0];
      if (0xfff < uVar11) {
        uVar9 = *(uint *)(auStack_54[0] - 4);
        uVar11 = uStack_40 + 0x24;
        if (0x1f < (auStack_54[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar11);
    }
    uStack_44 = 0;
    uStack_40 = 0xf;
    auStack_54[0] = auStack_54[0] & 0xffffff00;
    FUN_008a65e0(iVar6,0);
    uVar3 = *puStack_28;
    uVar4 = puStack_28[1];
    *puStack_28 = 0;
    puStack_28[1] = 0;
    *(undefined4 *)(iVar6 + 0x78 + iVar12 * 8) = uVar3;
    piVar5 = *(int **)(iVar6 + 0x7c + iVar12 * 8);
    *(undefined4 *)(iStack_14 + 0x7c + iVar12 * 8) = uVar4;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar6 = piVar5[1] + -1;
      piVar5[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar6 = piVar5[2] + -1;
        piVar5[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    piVar5 = piStack_38;
    uStack_18 = uVar13;
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_38[1] + -1;
      piStack_38[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_38)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar6 = *piVar1 + -1;
        *piVar1 = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    iStack_8 = 2;
    switch(iVar12) {
    case 0:
      pcVar8 = "MaxMemory";
      break;
    case 1:
      pcVar8 = "MaxCPU";
      break;
    case 2:
      pcVar8 = "MaxGPU";
      break;
    case 3:
      pcVar8 = "MaxPing";
      break;
    case 4:
      pcVar8 = "MaxNetworkReceived";
      break;
    case 5:
      pcVar8 = "MaxNetworkSent";
      break;
    default:
      pcVar8 = "*Unknown*";
    }
    puVar7 = (undefined4 *)FUN_009ff040(&uStack_34,pcVar8);
    uStack_18 = uVar13 | 2;
    switch(iVar12) {
    case 0:
      FUN_009ffaf0((int)DAT_019750e8,(int)((ulonglong)DAT_019750e8 >> 0x20));
      break;
    case 1:
    case 2:
      uVar14 = DAT_019750d8;
      goto LAB_00ca85f5;
    case 3:
    case 4:
    case 5:
      uVar14 = DAT_019750e0;
LAB_00ca85f5:
      FUN_009ffd50(uStack_34,uVar14,"%.4f msec",(int)uVar14,(int)((ulonglong)uVar14 >> 0x20));
    }
    uVar3 = *puVar7;
    uVar4 = puVar7[1];
    *puVar7 = 0;
    puVar7[1] = 0;
    *(undefined4 *)(iStack_14 + 0xa8 + iVar12 * 8) = uVar3;
    piVar5 = *(int **)(iStack_14 + 0xac + iVar12 * 8);
    *(undefined4 *)(iStack_14 + 0xac + iVar12 * 8) = uVar4;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar6 = piVar5[1] + -1;
      piVar5[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar6 = piVar5[2] + -1;
        piVar5[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    piVar5 = piStack_30;
    uVar13 = uStack_2c & 0xfffffffc;
    iStack_8 = 0xffffffff;
    uStack_18 = uVar13;
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_30[1] + -1;
      piStack_30[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar6 = *piVar1 + -1;
        *piVar1 = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    iVar12 = iVar12 + 1;
    if (5 < iVar12) {
      FUN_00ca7f60();
      FUN_009ffd50();
      FUN_009ffd50();
      ExceptionList = pvStack_10;
      return;
    }
  } while( true );
}



/* FUNCTION 30129 ; VA 0x00ca8750 ; FUN_00ca8750 */

void __thiscall FUN_00ca8750(int param_1,float param_2)

{
  FUN_009ffd50(*(undefined4 *)(param_1 + 0x80),(double)param_2,"%.4f msec",(double)param_2);
  return;
}



/* FUNCTION 30130 ; VA 0x00ca8790 ; FUN_00ca8790 */

void __thiscall FUN_00ca8790(int param_1,float param_2)

{
  FUN_009ffd50(*(undefined4 *)(param_1 + 0x98),(double)param_2,"%.2f KB/s",(double)param_2);
  return;
}



/* FUNCTION 30131 ; VA 0x00ca87d0 ; FUN_00ca87d0 */

void __thiscall FUN_00ca87d0(int param_1,float param_2)

{
  FUN_009ffd50(*(undefined4 *)(param_1 + 0xa0),(double)param_2,"%.2f KB/s",(double)param_2);
  return;
}



/* FUNCTION 30132 ; VA 0x00ca8810 ; FUN_00ca8810 */

void __thiscall FUN_00ca8810(int param_1,float param_2)

{
  FUN_009ffd50(*(undefined4 *)(param_1 + 0x90),(double)param_2,"%.4f msec",(double)param_2);
  return;
}



/* FUNCTION 30133 ; VA 0x00ca8850 ; FUN_00ca8850 */

void __thiscall FUN_00ca8850(int param_1,float param_2)

{
  FUN_009ffd50(*(undefined4 *)(param_1 + 0x88),(double)param_2,"%.4f msec",(double)param_2);
  return;
}



/* FUNCTION 30134 ; VA 0x00ca8890 ; FUN_00ca8890 */

void FUN_00ca8890(void)

{
  double in_XMM0_Qa;
  
  FUN_00ccdf90();
  FUN_00cce000();
  FUN_01675100();
  FUN_016f3fe0();
  FUN_009ffaf0((double)((float)in_XMM0_Qa * DAT_019750d0));
  return;
}



/* FUNCTION 30135 ; VA 0x00ca88f0 ; FUN_00ca88f0 */

void __fastcall FUN_00ca88f0(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar3 = 0;
  iVar2 = *(int *)(param_1 + 0x7c);
  if (iVar2 != *(int *)(param_1 + 0x80)) {
    do {
      iVar1 = FUN_016750a0();
      iVar2 = iVar2 + 4;
      iVar3 = iVar3 + iVar1;
    } while (iVar2 != *(int *)(param_1 + 0x80));
  }
  FUN_009ffaf0((double)((float)((double)iVar3 + (double)(&DAT_018c0d90)[-(iVar3 >> 0x1f)]) *
                       DAT_019750d0));
  return;
}



/* FUNCTION 30136 ; VA 0x00ca8950 ; FUN_00ca8950 */

void FUN_00ca8950(void)

{
  int iVar1;
  
  iVar1 = FUN_016750a0();
  FUN_009ffaf0((double)((float)((double)iVar1 + (double)(&DAT_018c0d90)[-(iVar1 >> 0x1f)]) *
                       DAT_019750d0));
  return;
}



/* FUNCTION 30137 ; VA 0x00ca8990 ; FUN_00ca8990 */

void __fastcall FUN_00ca8990(int param_1)

{
  double in_XMM0_Qa;
  
  if (*(int *)(param_1 + 0x78) == 0) {
    FUN_01522960();
    FUN_016f3fe0();
    FUN_009ffaf0((double)((float)in_XMM0_Qa * DAT_019750d0));
  }
  return;
}



/* FUNCTION 30138 ; VA 0x00ca89d0 ; FUN_00ca89d0 */

void FUN_00ca89d0(void)

{
  int iVar1;
  
  FUN_00ccdf90();
  iVar1 = FUN_00cce000();
  FUN_009ffaf0((double)((float)((double)iVar1 + (double)(&DAT_018c0d90)[-(iVar1 >> 0x1f)]) *
                       DAT_019750d0));
  return;
}



/* FUNCTION 30139 ; VA 0x00ca8a20 ; FUN_00ca8a20 */

void FUN_00ca8a20(void)

{
  uint uVar1;
  uint uVar2;
  
  uVar1 = FUN_01522960();
  uVar2 = FUN_01675100();
  if (uVar1 < uVar2) {
    FUN_009ffaf0(0);
    return;
  }
  FUN_009ffaf0((double)((float)((double)(int)(uVar1 - uVar2) +
                               (double)(&DAT_018c0d90)[-((int)(uVar1 - uVar2) >> 0x1f)]) *
                       DAT_019750d0));
  return;
}



/* FUNCTION 30140 ; VA 0x00ca8a80 ; FUN_00ca8a80 */

undefined4 * __thiscall
FUN_00ca8a80(undefined4 *param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined auStack_64 [4];
  int *piStack_60;
  uint uStack_5c;
  undefined auStack_54 [24];
  undefined auStack_3c [4];
  int *piStack_38;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01810f48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00cab410(&param_2);
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_00cab410(auStack_64);
  uStack_8._0_1_ = 2;
  FUN_00cab410(auStack_3c);
  ppuVar4 = &PTR_FUN_01975640;
  cVar3 = FUN_00caa2b0();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
    }
    uStack_34 = 0;
  }
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_38[2] + -1;
    piStack_38[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_38 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_5c != 0) {
    if (((uStack_5c & 1) == 0) && (*(code **)(uStack_5c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_5c & 0xfffffffe))(auStack_54,auStack_54,2);
    }
    uStack_5c = 0;
  }
  if (piStack_60 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_60[2] + -1;
    piStack_60[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_60 + 4))();
    }
  }
  uStack_8 = 5;
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30141 ; VA 0x00ca8bd0 ; FUN_00ca8bd0 */

undefined4 * __thiscall
FUN_00ca8bd0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  char cVar1;
  int iVar2;
  undefined **ppuVar3;
  uint in_stack_00000020;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_68;
  int iStack_64;
  int *piStack_60;
  int aiStack_4c [5];
  uint uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01810f78;
  pvStack_10 = ExceptionList;
  piStack_60 = &param_4;
  uStack_8 = 0;
  iStack_64 = 0xca8c11;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60();
  uStack_34 = param_2;
  uStack_30 = param_3;
  piStack_60 = aiStack_4c;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  iStack_64 = 0xca8c33;
  FUN_0054ef60();
  piStack_60 = param_1 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_14 = &uStack_80;
  uStack_80 = uStack_34;
  uStack_7c = uStack_30;
  FUN_0054ef60(aiStack_2c);
  ppuVar3 = &PTR_FUN_01975668;
  cVar1 = FUN_00caa580();
  if (cVar1 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  if (0xf < uStack_18) {
    piStack_60 = (int *)(uStack_18 + 1);
    iVar2 = aiStack_2c[0];
    if (0xfff < piStack_60) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      piStack_60 = (int *)(uStack_18 + 0x24);
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_60 = (int *)0xca8d18;
        FUN_017167a3();
      }
    }
    uStack_68 = 0xca8c9c;
    iStack_64 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < uStack_38) {
    piStack_60 = (int *)(uStack_38 + 1);
    iVar2 = aiStack_4c[0];
    if (0xfff < piStack_60) {
      iVar2 = *(int *)(aiStack_4c[0] + -4);
      piStack_60 = (int *)(uStack_38 + 0x24);
      if (0x1f < (aiStack_4c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_60 = (int *)0xca8d1d;
        FUN_017167a3();
      }
    }
    uStack_68 = 0xca8ccc;
    iStack_64 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000020) {
    piStack_60 = (int *)(in_stack_00000020 + 1);
    iVar2 = param_4;
    if (0xfff < piStack_60) {
      iVar2 = *(int *)(param_4 + -4);
      piStack_60 = (int *)(in_stack_00000020 + 0x24);
      if (0x1f < (param_4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_60 = (int *)&UNK_00ca8d22;
        FUN_017167a3();
      }
    }
    uStack_68 = 0xca8cfc;
    iStack_64 = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30142 ; VA 0x00ca8d30 ; FUN_00ca8d30 */

undefined4 * __thiscall
FUN_00ca8d30(undefined4 *param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined auStack_64 [4];
  int *piStack_60;
  uint uStack_5c;
  undefined auStack_54 [24];
  undefined auStack_3c [4];
  int *piStack_38;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01810fa8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00cab410(&param_2);
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_00cab410(auStack_64);
  uStack_8._0_1_ = 2;
  FUN_00cab410(auStack_3c);
  ppuVar4 = &PTR_FUN_01975660;
  cVar3 = FUN_00caa730();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
    }
    uStack_34 = 0;
  }
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_38[2] + -1;
    piStack_38[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_38 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_5c != 0) {
    if (((uStack_5c & 1) == 0) && (*(code **)(uStack_5c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_5c & 0xfffffffe))(auStack_54,auStack_54,2);
    }
    uStack_5c = 0;
  }
  if (piStack_60 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_60[2] + -1;
    piStack_60[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_60 + 4))();
    }
  }
  uStack_8 = 5;
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30143 ; VA 0x00ca8e80 ; FUN_00ca8e80 */

undefined4 * __thiscall
FUN_00ca8e80(undefined4 *param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined auStack_64 [4];
  int *piStack_60;
  uint uStack_5c;
  undefined auStack_54 [24];
  undefined auStack_3c [4];
  int *piStack_38;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01810fd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00cab410(&param_2);
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_00cab410(auStack_64);
  uStack_8._0_1_ = 2;
  FUN_00cab410(auStack_3c);
  ppuVar4 = &PTR_FUN_01975630;
  cVar3 = FUN_00caa8e0();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
    }
    uStack_34 = 0;
  }
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_38[2] + -1;
    piStack_38[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_38 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_5c != 0) {
    if (((uStack_5c & 1) == 0) && (*(code **)(uStack_5c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_5c & 0xfffffffe))(auStack_54,auStack_54,2);
    }
    uStack_5c = 0;
  }
  if (piStack_60 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_60[2] + -1;
    piStack_60[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_60 + 4))();
    }
  }
  uStack_8 = 5;
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30144 ; VA 0x00ca8fd0 ; FUN_00ca8fd0 */

undefined4 * __thiscall
FUN_00ca8fd0(undefined4 *param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined auStack_64 [4];
  int *piStack_60;
  uint uStack_5c;
  undefined auStack_54 [24];
  undefined auStack_3c [4];
  int *piStack_38;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01811008;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00cab410(&param_2);
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_00cab410(auStack_64);
  uStack_8._0_1_ = 2;
  FUN_00cab410(auStack_3c);
  ppuVar4 = &PTR_FUN_01975650;
  cVar3 = FUN_00caaa90();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
    }
    uStack_34 = 0;
  }
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_38[2] + -1;
    piStack_38[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_38 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_5c != 0) {
    if (((uStack_5c & 1) == 0) && (*(code **)(uStack_5c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_5c & 0xfffffffe))(auStack_54,auStack_54,2);
    }
    uStack_5c = 0;
  }
  if (piStack_60 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_60[2] + -1;
    piStack_60[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_60 + 4))();
    }
  }
  uStack_8 = 5;
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30145 ; VA 0x00ca9120 ; FUN_00ca9120 */

undefined4 * __thiscall
FUN_00ca9120(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  char cVar1;
  int iVar2;
  undefined **ppuVar3;
  uint in_stack_00000020;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_68;
  int iStack_64;
  int *piStack_60;
  int aiStack_4c [5];
  uint uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01811038;
  pvStack_10 = ExceptionList;
  piStack_60 = &param_4;
  uStack_8 = 0;
  iStack_64 = 0xca9161;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60();
  uStack_34 = param_2;
  uStack_30 = param_3;
  piStack_60 = aiStack_4c;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  iStack_64 = 0xca9183;
  FUN_0054ef60();
  piStack_60 = param_1 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_14 = &uStack_80;
  uStack_80 = uStack_34;
  uStack_7c = uStack_30;
  FUN_0054ef60(aiStack_2c);
  ppuVar3 = &PTR_FUN_01975670;
  cVar1 = FUN_00caad60();
  if (cVar1 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  if (0xf < uStack_18) {
    piStack_60 = (int *)(uStack_18 + 1);
    iVar2 = aiStack_2c[0];
    if (0xfff < piStack_60) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      piStack_60 = (int *)(uStack_18 + 0x24);
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_60 = (int *)0xca9268;
        FUN_017167a3();
      }
    }
    uStack_68 = 0xca91ec;
    iStack_64 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < uStack_38) {
    piStack_60 = (int *)(uStack_38 + 1);
    iVar2 = aiStack_4c[0];
    if (0xfff < piStack_60) {
      iVar2 = *(int *)(aiStack_4c[0] + -4);
      piStack_60 = (int *)(uStack_38 + 0x24);
      if (0x1f < (aiStack_4c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_60 = (int *)0xca926d;
        FUN_017167a3();
      }
    }
    uStack_68 = 0xca921c;
    iStack_64 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000020) {
    piStack_60 = (int *)(in_stack_00000020 + 1);
    iVar2 = param_4;
    if (0xfff < piStack_60) {
      iVar2 = *(int *)(param_4 + -4);
      piStack_60 = (int *)(in_stack_00000020 + 0x24);
      if (0x1f < (param_4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_60 = (int *)&UNK_00ca9272;
        FUN_017167a3();
      }
    }
    uStack_68 = 0xca924c;
    iStack_64 = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30146 ; VA 0x00ca9280 ; FUN_00ca9280 */

int __fastcall FUN_00ca9280(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int aiStack_40 [5];
  uint uStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01811068;
  pvStack_10 = ExceptionList;
  uStack_14 = param_1[2];
  uStack_18 = param_1[3];
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  piVar4 = (int *)param_1[1];
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar4[2] = piVar4[2] + 1;
    UNLOCK();
    piVar4 = (int *)param_1[1];
  }
  uStack_20 = *param_1;
  uStack_8 = 0;
  piStack_1c = piVar4;
  iVar3 = FUN_00587490();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iStack_28 != 0) {
    FUN_0054ef60(aiStack_40);
    FUN_00ca9120();
    iVar3 = FUN_0090ca30();
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_24 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piStack_24 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar1 = piVar4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      iVar3 = (**(code **)(*piVar4 + 4))();
    }
  }
  if (0xf < uStack_2c) {
    if (0xfff < uStack_2c + 1) {
      if (0x1f < (aiStack_40[0] - *(int *)(aiStack_40[0] + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar3 = FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 30147 ; VA 0x00ca93b0 ; FUN_00ca93b0 */

void __thiscall FUN_00ca93b0(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01811090;
  pvStack_10 = ExceptionList;
  uStack_40 = 0;
  uVar2 = param_1[10];
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_40 = uVar2;
    if ((uVar2 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = param_1 + 0xc;
      uStack_50 = 0xca9412;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_38 = param_1[0xc];
      uStack_34 = param_1[0xd];
      uStack_30 = param_1[0xe];
      uStack_2c = param_1[0xf];
      uStack_28 = *(undefined8 *)(param_1 + 0x10);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uVar2 = param_1[2];
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_1 + 4,&uStack_58,0);
    }
    else {
      uStack_58 = param_1[4];
      uStack_54 = param_1[5];
      uStack_50 = param_1[6];
      puStack_4c = (undefined4 *)param_1[7];
      uStack_48 = *(ulonglong *)(param_1 + 8);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(param_2);
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  FUN_00cb0a70(*param_1,param_1[1]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30148 ; VA 0x00ca94c0 ; FUN_00ca94c0 */

void __thiscall FUN_00ca94c0(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018110b0;
  pvStack_10 = ExceptionList;
  uStack_40 = 0;
  uVar2 = param_1[10];
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_40 = uVar2;
    if ((uVar2 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = param_1 + 0xc;
      uStack_50 = 0xca9522;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_38 = param_1[0xc];
      uStack_34 = param_1[0xd];
      uStack_30 = param_1[0xe];
      uStack_2c = param_1[0xf];
      uStack_28 = *(undefined8 *)(param_1 + 0x10);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uVar2 = param_1[2];
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_1 + 4,&uStack_58,0);
    }
    else {
      uStack_58 = param_1[4];
      uStack_54 = param_1[5];
      uStack_50 = param_1[6];
      puStack_4c = (undefined4 *)param_1[7];
      uStack_48 = *(ulonglong *)(param_1 + 8);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(param_2);
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  FUN_00cb0d90(*param_1,param_1[1]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30149 ; VA 0x00ca95d0 ; FUN_00ca95d0 */

int __fastcall FUN_00ca95d0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int aiStack_40 [5];
  uint uStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01811068;
  pvStack_10 = ExceptionList;
  uStack_14 = param_1[2];
  uStack_18 = param_1[3];
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  piVar4 = (int *)param_1[1];
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar4[2] = piVar4[2] + 1;
    UNLOCK();
    piVar4 = (int *)param_1[1];
  }
  uStack_20 = *param_1;
  uStack_8 = 0;
  piStack_1c = piVar4;
  iVar3 = FUN_00587490();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iStack_28 != 0) {
    FUN_0054ef60(aiStack_40);
    FUN_00ca8bd0();
    iVar3 = FUN_0090ca30();
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_24 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piStack_24 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar1 = piVar4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      iVar3 = (**(code **)(*piVar4 + 4))();
    }
  }
  if (0xf < uStack_2c) {
    if (0xfff < uStack_2c + 1) {
      if (0x1f < (aiStack_40[0] - *(int *)(aiStack_40[0] + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar3 = FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 30150 ; VA 0x00ca9700 ; FUN_00ca9700 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00ca9700(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018110e0;
  pvStack_10 = ExceptionList;
  if (DAT_01f0267c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f02890) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f02890);
      if (DAT_01f02890 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"GroupService",1,uStack_20,0,0,1,0,0);
        _DAT_01f02888 = RBX::Creator<class_RBX::GroupService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01f02680,&DAT_01f02888);
        FUN_016f3654(FUN_018981c0);
        FUN_016f37bf(&DAT_01f02890);
      }
    }
    DAT_01f0267c = &DAT_01f02680;
  }
  ExceptionList = pvStack_10;
  return DAT_01f0267c;
}



/* FUNCTION 30151 ; VA 0x00ca9800 ; FUN_00ca9800 */

void FUN_00ca9800(void)

{
  int iVar1;
  
  if (DAT_01f02894 == 0) {
    iVar1 = FUN_00ca9700();
    DAT_01f02894 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 30152 ; VA 0x00ca9820 ; FUN_00ca9820 */

void __thiscall FUN_00ca9820(int *param_1,uint param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uStack_c;
  
  uVar5 = param_2;
  uVar2 = (int)(param_3 - param_2) / 0x28;
  iVar4 = *param_1;
  uStack_c = (param_1[1] - iVar4) / 0x28;
  uVar3 = (param_1[2] - iVar4) / 0x28;
  if (uVar2 <= uVar3) {
    if (uVar2 <= uStack_c) {
      uStack_c = uStack_c & 0xffffff00;
      iVar1 = iVar4 + uVar2 * 0x28;
      FUN_00ca99a0(param_2,param_3,iVar4,uStack_c);
      FUN_005f6200(iVar1,param_1[1]);
      param_1[1] = iVar1;
      return;
    }
    param_2 = param_2 & 0xffffff00;
    iVar1 = uVar5 + uStack_c * 0x28;
    FUN_00ca99a0(uVar5,iVar1,iVar4,param_2);
    iVar4 = FUN_00caa220(iVar1,param_3,param_1[1],param_1);
    param_1[1] = iVar4;
    return;
  }
  if (0x6666666 < uVar2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar5 = uVar2;
  if ((uVar3 <= 0x6666666 - (uVar3 >> 1)) && (uVar5 = (uVar3 >> 1) + uVar3, uVar5 < uVar2)) {
    uVar5 = uVar2;
  }
  if (iVar4 != 0) {
    FUN_005f6200(iVar4,param_1[1]);
    FUN_005f6c10(*param_1,uVar3);
  }
  FUN_00cac350(uVar5);
  iVar4 = FUN_00caa220(param_2,param_3,*param_1,param_1);
  param_1[1] = iVar4;
  return;
}



/* FUNCTION 30153 ; VA 0x00ca9960 ; FUN_00ca9960 */

int FUN_00ca9960(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  
  iVar1 = FUN_00970740(param_1,param_2);
  *(undefined4 *)(iVar1 + 8) = *param_3;
  *(undefined4 *)(iVar1 + 0xc) = param_3[1];
  FUN_00cab820(param_3 + 2);
  return iVar1;
}



/* FUNCTION 30154 ; VA 0x00ca99a0 ; FUN_00ca99a0 */

/* WARNING: Removing unreachable block (ram,0x00ca9ada) */

int * FUN_00ca99a0(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  void **ppvVar2;
  int iVar3;
  int aiStack_60 [9];
  int *piStack_3c;
  int aiStack_38 [9];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018110f8;
  pvStack_10 = ExceptionList;
  ppvVar2 = &pvStack_10;
  if (param_1 == param_2) {
    return param_3;
  }
  do {
    ExceptionList = ppvVar2;
    piStack_14 = (int *)0x0;
    uStack_8 = 0;
    if (*(undefined4 **)(param_1 + 0x24) != (undefined4 *)0x0) {
      piStack_14 = (int *)(**(code **)**(undefined4 **)(param_1 + 0x24))(aiStack_38);
    }
    uStack_8 = 1;
    if ((piStack_14 == aiStack_38) || (piVar1 = (int *)param_3[9], piVar1 == param_3)) {
      piStack_3c = (int *)0x0;
      if (piStack_14 != (int *)0x0) {
        piVar1 = piStack_14;
        if (piStack_14 == aiStack_38) {
          piStack_3c = (int *)(**(code **)(*piStack_14 + 4))(aiStack_60);
          if (piStack_14 == (int *)0x0) goto LAB_00ca9a56;
          (**(code **)(*piStack_14 + 0x10))
                    (CONCAT31((int3)((uint)aiStack_38 >> 8),piStack_14 != aiStack_38));
          piVar1 = piStack_3c;
        }
        piStack_3c = piVar1;
        piStack_14 = (int *)0x0;
      }
LAB_00ca9a56:
      piVar1 = (int *)param_3[9];
      if (piVar1 != (int *)0x0) {
        if (piVar1 == param_3) {
          piStack_14 = (int *)(**(code **)(*piVar1 + 4))(aiStack_38);
          piVar1 = (int *)param_3[9];
          if (piVar1 == (int *)0x0) goto LAB_00ca9aa0;
          (**(code **)(*piVar1 + 0x10))(CONCAT31((int3)((uint)*piVar1 >> 8),piVar1 != param_3));
          piVar1 = piStack_14;
        }
        piStack_14 = piVar1;
        param_3[9] = 0;
      }
LAB_00ca9aa0:
      if (piStack_3c != (int *)0x0) {
        if (piStack_3c == aiStack_60) {
          iVar3 = (**(code **)(*piStack_3c + 4))(param_3);
          param_3[9] = iVar3;
          if (piStack_3c != (int *)0x0) {
            (**(code **)(*piStack_3c + 0x10))
                      (CONCAT31((int3)((uint)aiStack_60 >> 8),piStack_3c != aiStack_60));
            piStack_3c = (int *)0x0;
          }
        }
        else {
          param_3[9] = (int)piStack_3c;
        }
      }
    }
    else {
      param_3[9] = (int)piStack_14;
      piStack_14 = piVar1;
    }
    uStack_8 = 0xffffffff;
    if (piStack_14 != (int *)0x0) {
      (**(code **)(*piStack_14 + 0x10))(piStack_14 != aiStack_38);
    }
    param_1 = param_1 + 0x28;
    param_3 = param_3 + 10;
    ppvVar2 = (void **)ExceptionList;
    if (param_1 == param_2) {
      ExceptionList = pvStack_10;
      return param_3;
    }
  } while( true );
}



/* FUNCTION 30155 ; VA 0x00ca9b50 ; FUN_00ca9b50 */

int __thiscall FUN_00ca9b50(int *param_1,int param_2,int param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01811118;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  iVar2 = (param_1[1] - iVar1) / 0x28;
  if (iVar2 == 0x6666666) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar7 = iVar2 + 1;
  uVar3 = (param_1[2] - iVar1) / 0x28;
  uVar9 = uVar7;
  if ((uVar3 <= 0x6666666 - (uVar3 >> 1)) && (uVar9 = (uVar3 >> 1) + uVar3, uVar9 < uVar7)) {
    uVar9 = uVar7;
  }
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00cac970(uVar9);
  iVar5 = ((param_2 - iVar1) / 0x28) * 0x28;
  iVar1 = iVar5 + iVar4;
  *(undefined4 *)(iVar1 + 0x24) = 0;
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  if (*(undefined4 **)(param_3 + 0x24) != (undefined4 *)0x0) {
    uVar6 = (**(code **)**(undefined4 **)(param_3 + 0x24))(iVar1);
    *(undefined4 *)(iVar5 + iVar4 + 0x24) = uVar6;
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (param_2 == param_1[1]) {
    FUN_00caa220(*param_1,param_1[1],iVar4,param_1);
  }
  else {
    FUN_00cac8b0(*param_1,param_2,iVar4);
    FUN_00cac8b0(param_2,param_1[1],iVar1 + 0x28);
  }
  if (*param_1 != 0) {
    FUN_005f6200(*param_1,param_1[1]);
    iVar1 = *param_1;
    uVar7 = ((param_1[2] - iVar1) / 0x28) * 0x28;
    iVar8 = iVar1;
    if (0xfff < uVar7) {
      iVar8 = *(int *)(iVar1 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar1 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar7);
  }
  *param_1 = iVar4;
  param_1[1] = iVar4 + (iVar2 * 5 + 5) * 8;
  param_1[2] = iVar4 + uVar9 * 0x28;
  ExceptionList = pvStack_10;
  return *param_1 + iVar5;
}



/* FUNCTION 30156 ; VA 0x00ca9d0a ; Catch_All@00ca9d0a */

void Catch_All_00ca9d0a(void)

{
  int unaff_EBP;
  
  FUN_005f6200(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x1c));
  FUN_005f6c10(*(undefined4 *)(unaff_EBP + -0x24),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 30157 ; VA 0x00ca9d40 ; FUN_00ca9d40 */

undefined4 * FUN_00ca9d40(uint *param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01811138;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_01674e20(0x50);
  uStack_8 = 0;
  *puVar4 = std::
            _Func_impl_no_alloc<class_<lambda_330865718c09507678fa7a6d1c6308c2>,void,class_std::shared_ptr<struct_RBX::GroupService::GroupRolesResult_const_>_>
            ::vftable;
  puVar4[2] = 0;
  uVar1 = *param_1;
  if (uVar1 != 0) {
    puVar4[2] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_1 + 2,puVar4 + 4,0);
    }
    else {
      uVar1 = param_1[3];
      uVar2 = param_1[4];
      uVar3 = param_1[5];
      puVar4[4] = param_1[2];
      puVar4[5] = uVar1;
      puVar4[6] = uVar2;
      puVar4[7] = uVar3;
      *(undefined8 *)(puVar4 + 8) = *(undefined8 *)(param_1 + 6);
    }
  }
  puVar4[10] = 0;
  uVar1 = param_1[8];
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (uVar1 != 0) {
    puVar4[10] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_1 + 10,puVar4 + 0xc,0);
    }
    else {
      uVar1 = param_1[0xb];
      uVar2 = param_1[0xc];
      uVar3 = param_1[0xd];
      puVar4[0xc] = param_1[10];
      puVar4[0xd] = uVar1;
      puVar4[0xe] = uVar2;
      puVar4[0xf] = uVar3;
      *(undefined8 *)(puVar4 + 0x10) = *(undefined8 *)(param_1 + 0xe);
    }
  }
  puVar4[0x12] = param_1[0x10];
  puVar4[0x13] = param_1[0x11];
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 30158 ; VA 0x00ca9e21 ; Catch_All@00ca9e21 */

void Catch_All_00ca9e21(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x50);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 30159 ; VA 0x00ca9e40 ; FUN_00ca9e40 */

undefined4 * FUN_00ca9e40(int param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01811158;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x50);
  uStack_8 = 0;
  *puVar1 = std::
            _Func_impl_no_alloc<class_<lambda_330865718c09507678fa7a6d1c6308c2>,void,class_std::shared_ptr<struct_RBX::GroupService::GroupRolesResult_const_>_>
            ::vftable;
  puVar1[2] = 0;
  FUN_005880d0(param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  puVar1[10] = 0;
  FUN_005880d0(param_1 + 0x20);
  puVar1[0x12] = *(undefined4 *)(param_1 + 0x40);
  puVar1[0x13] = *(undefined4 *)(param_1 + 0x44);
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 30160 ; VA 0x00ca9ec9 ; Catch_All@00ca9ec9 */

void Catch_All_00ca9ec9(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x50);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 30161 ; VA 0x00ca9ee0 ; FUN_00ca9ee0 */

undefined4 * FUN_00ca9ee0(uint *param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01811178;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_01674e20(0x50);
  uStack_8 = 0;
  *puVar4 = std::
            _Func_impl_no_alloc<class_<lambda_68d5bed75bd3d27e4f729d85f19c6337>,void,class_std::shared_ptr<struct_RBX::GroupService::GroupRolesResult_const_>_>
            ::vftable;
  puVar4[2] = 0;
  uVar1 = *param_1;
  if (uVar1 != 0) {
    puVar4[2] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_1 + 2,puVar4 + 4,0);
    }
    else {
      uVar1 = param_1[3];
      uVar2 = param_1[4];
      uVar3 = param_1[5];
      puVar4[4] = param_1[2];
      puVar4[5] = uVar1;
      puVar4[6] = uVar2;
      puVar4[7] = uVar3;
      *(undefined8 *)(puVar4 + 8) = *(undefined8 *)(param_1 + 6);
    }
  }
  puVar4[10] = 0;
  uVar1 = param_1[8];
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (uVar1 != 0) {
    puVar4[10] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_1 + 10,puVar4 + 0xc,0);
    }
    else {
      uVar1 = param_1[0xb];
      uVar2 = param_1[0xc];
      uVar3 = param_1[0xd];
      puVar4[0xc] = param_1[10];
      puVar4[0xd] = uVar1;
      puVar4[0xe] = uVar2;
      puVar4[0xf] = uVar3;
      *(undefined8 *)(puVar4 + 0x10) = *(undefined8 *)(param_1 + 0xe);
    }
  }
  puVar4[0x12] = param_1[0x10];
  puVar4[0x13] = param_1[0x11];
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 30162 ; VA 0x00ca9fc1 ; Catch_All@00ca9fc1 */

void Catch_All_00ca9fc1(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x50);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 30163 ; VA 0x00ca9fe0 ; FUN_00ca9fe0 */

undefined4 * FUN_00ca9fe0(int param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01811198;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x50);
  uStack_8 = 0;
  *puVar1 = std::
            _Func_impl_no_alloc<class_<lambda_68d5bed75bd3d27e4f729d85f19c6337>,void,class_std::shared_ptr<struct_RBX::GroupService::GroupRolesResult_const_>_>
            ::vftable;
  puVar1[2] = 0;
  FUN_005880d0(param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  puVar1[10] = 0;
  FUN_005880d0(param_1 + 0x20);
  puVar1[0x12] = *(undefined4 *)(param_1 + 0x40);
  puVar1[0x13] = *(undefined4 *)(param_1 + 0x44);
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 30164 ; VA 0x00caa069 ; Catch_All@00caa069 */

void Catch_All_00caa069(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x50);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 30165 ; VA 0x00caa080 ; FUN_00caa080 */

undefined4 * FUN_00caa080(uint *param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018111b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_01674e20(0x50);
  uStack_8 = 0;
  *puVar4 = std::
            _Func_impl_no_alloc<class_<lambda_c7c981181f7fb988110f93015bab1295>,void,class_std::shared_ptr<struct_RBX::GroupService::GroupRolesResult_const_>_>
            ::vftable;
  puVar4[2] = 0;
  uVar1 = *param_1;
  if (uVar1 != 0) {
    puVar4[2] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_1 + 2,puVar4 + 4,0);
    }
    else {
      uVar1 = param_1[3];
      uVar2 = param_1[4];
      uVar3 = param_1[5];
      puVar4[4] = param_1[2];
      puVar4[5] = uVar1;
      puVar4[6] = uVar2;
      puVar4[7] = uVar3;
      *(undefined8 *)(puVar4 + 8) = *(undefined8 *)(param_1 + 6);
    }
  }
  puVar4[10] = 0;
  uVar1 = param_1[8];
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (uVar1 != 0) {
    puVar4[10] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_1 + 10,puVar4 + 0xc,0);
    }
    else {
      uVar1 = param_1[0xb];
      uVar2 = param_1[0xc];
      uVar3 = param_1[0xd];
      puVar4[0xc] = param_1[10];
      puVar4[0xd] = uVar1;
      puVar4[0xe] = uVar2;
      puVar4[0xf] = uVar3;
      *(undefined8 *)(puVar4 + 0x10) = *(undefined8 *)(param_1 + 0xe);
    }
  }
  puVar4[0x12] = param_1[0x10];
  puVar4[0x13] = param_1[0x11];
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 30166 ; VA 0x00caa161 ; Catch_All@00caa161 */

void Catch_All_00caa161(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x50);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 30167 ; VA 0x00caa180 ; FUN_00caa180 */

undefined4 * FUN_00caa180(int param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018111d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x50);
  uStack_8 = 0;
  *puVar1 = std::
            _Func_impl_no_alloc<class_<lambda_c7c981181f7fb988110f93015bab1295>,void,class_std::shared_ptr<struct_RBX::GroupService::GroupRolesResult_const_>_>
            ::vftable;
  puVar1[2] = 0;
  FUN_005880d0(param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  puVar1[10] = 0;
  FUN_005880d0(param_1 + 0x20);
  puVar1[0x12] = *(undefined4 *)(param_1 + 0x40);
  puVar1[0x13] = *(undefined4 *)(param_1 + 0x44);
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 30168 ; VA 0x00caa209 ; Catch_All@00caa209 */

void Catch_All_00caa209(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x50);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 30169 ; VA 0x00caa220 ; FUN_00caa220 */

int FUN_00caa220(int param_1,int param_2,int param_3)

{
  void **ppvVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_01811200;
  pvStack_10 = ExceptionList;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  ppvVar1 = &pvStack_10;
  if (param_1 != param_2) {
    do {
      *(undefined4 *)(param_3 + 0x24) = 0;
      uStack_8 = 1;
      if (*(undefined4 **)(param_1 + 0x24) != (undefined4 *)0x0) {
        uVar2 = (**(code **)**(undefined4 **)(param_1 + 0x24))(param_3);
        *(undefined4 *)(param_3 + 0x24) = uVar2;
      }
      param_3 = param_3 + 0x28;
      param_1 = param_1 + 0x28;
      ppvVar1 = (void **)ExceptionList;
    } while (param_1 != param_2);
  }
  ExceptionList = ppvVar1;
  uStack_8 = 0;
  FUN_0072a040();
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 30170 ; VA 0x00caa2b0 ; FUN_00caa2b0 */

undefined FUN_00caa2b0(undefined4 param_1,int *param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined uVar5;
  undefined4 *in_stack_0000002c;
  undefined auStack_64 [4];
  int *piStack_60;
  uint uStack_5c;
  undefined auStack_54 [24];
  undefined auStack_3c [4];
  int *piStack_38;
  uint uStack_34;
  undefined auStack_2c [24];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01811237;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00cab410(&param_1);
  uStack_8._0_1_ = 1;
  cVar3 = FUN_00585a40(auStack_3c);
  if (cVar3 == '\0') {
    FUN_00cab410(auStack_3c);
    uStack_8._0_1_ = 2;
    iStack_14 = FUN_01674e20(0x28);
    uStack_8._0_1_ = 3;
    if (iStack_14 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_00cab410(auStack_64);
    }
    *in_stack_0000002c = uVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (uStack_5c != 0) {
      if (((uStack_5c & 1) == 0) && (*(code **)(uStack_5c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_5c & 0xfffffffe))(auStack_54,auStack_54,2);
      }
      uStack_5c = 0;
    }
    if (piStack_60 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_60[2] + -1;
      piStack_60[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_60 + 4))();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_38[2] + -1;
      piStack_38[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
    uVar5 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_38[2] + -1;
      piStack_38[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
    uVar5 = 0;
  }
  uStack_8 = 7;
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_3 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_3 = 0;
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 30171 ; VA 0x00caa460 ; FUN_00caa460 */

void __thiscall
FUN_00caa460(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_18 = param_3;
  uStack_1c = param_2;
  uStack_14 = param_4;
  uStack_10 = param_5;
  cVar3 = FUN_00585a40(&uStack_1c);
  if (cVar3 == '\0') {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_10;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_1c;
    param_1[3] = piStack_18;
    param_1[4] = uStack_14;
    param_1[5] = uStack_10;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01975680;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 30172 ; VA 0x00caa580 ; FUN_00caa580 */

undefined FUN_00caa580(undefined4 param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char cVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  undefined uVar8;
  uint in_stack_00000020;
  int *in_stack_00000024;
  int aiStack_4c [5];
  uint uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01811277;
  pvStack_10 = ExceptionList;
  uStack_34 = param_1;
  uStack_30 = param_2;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 1;
  cVar3 = FUN_00585a40(&uStack_34);
  uVar2 = uStack_30;
  uVar1 = uStack_34;
  if (cVar3 == '\0') {
    FUN_0054ef60(auStack_2c);
    uStack_8._0_1_ = 2;
    puVar4 = (undefined4 *)FUN_01674e20(0x20);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[1] = uVar2;
      FUN_0054ef60(aiStack_4c);
    }
    *in_stack_00000024 = (int)puVar4;
    if (0xf < uStack_38) {
      uVar6 = uStack_38 + 1;
      iVar5 = aiStack_4c[0];
      if (0xfff < uVar6) {
        iVar5 = *(int *)(aiStack_4c[0] + -4);
        uVar6 = uStack_38 + 0x24;
        if (0x1f < (aiStack_4c[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar6);
    }
    if (0xf < uStack_18) {
      uVar7 = uStack_18 + 1;
      uVar6 = auStack_2c[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_2c[0] - 4);
        uVar7 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uVar8 = 1;
  }
  else {
    if (0xf < uStack_18) {
      uVar7 = uStack_18 + 1;
      uVar6 = auStack_2c[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_2c[0] - 4);
        uVar7 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uVar8 = 0;
  }
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_18 = 0xf;
  uStack_1c = 0;
  if (0xf < in_stack_00000020) {
    uVar6 = in_stack_00000020 + 1;
    iVar5 = param_3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(param_3 + -4);
      uVar6 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 30173 ; VA 0x00caa730 ; FUN_00caa730 */

undefined FUN_00caa730(undefined4 param_1,int *param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined uVar5;
  undefined4 *in_stack_0000002c;
  undefined auStack_64 [4];
  int *piStack_60;
  uint uStack_5c;
  undefined auStack_54 [24];
  undefined auStack_3c [4];
  int *piStack_38;
  uint uStack_34;
  undefined auStack_2c [24];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018112b7;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00cab410(&param_1);
  uStack_8._0_1_ = 1;
  cVar3 = FUN_00585a40(auStack_3c);
  if (cVar3 == '\0') {
    FUN_00cab410(auStack_3c);
    uStack_8._0_1_ = 2;
    iStack_14 = FUN_01674e20(0x28);
    uStack_8._0_1_ = 3;
    if (iStack_14 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_00cab410(auStack_64);
    }
    *in_stack_0000002c = uVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (uStack_5c != 0) {
      if (((uStack_5c & 1) == 0) && (*(code **)(uStack_5c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_5c & 0xfffffffe))(auStack_54,auStack_54,2);
      }
      uStack_5c = 0;
    }
    if (piStack_60 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_60[2] + -1;
      piStack_60[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_60 + 4))();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_38[2] + -1;
      piStack_38[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
    uVar5 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_38[2] + -1;
      piStack_38[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
    uVar5 = 0;
  }
  uStack_8 = 7;
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_3 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_3 = 0;
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 30174 ; VA 0x00caa8e0 ; FUN_00caa8e0 */

undefined FUN_00caa8e0(undefined4 param_1,int *param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined uVar5;
  undefined4 *in_stack_0000002c;
  undefined auStack_64 [4];
  int *piStack_60;
  uint uStack_5c;
  undefined auStack_54 [24];
  undefined auStack_3c [4];
  int *piStack_38;
  uint uStack_34;
  undefined auStack_2c [24];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018112f7;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00cab410(&param_1);
  uStack_8._0_1_ = 1;
  cVar3 = FUN_00585a40(auStack_3c);
  if (cVar3 == '\0') {
    FUN_00cab410(auStack_3c);
    uStack_8._0_1_ = 2;
    iStack_14 = FUN_01674e20(0x28);
    uStack_8._0_1_ = 3;
    if (iStack_14 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_00cab410(auStack_64);
    }
    *in_stack_0000002c = uVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (uStack_5c != 0) {
      if (((uStack_5c & 1) == 0) && (*(code **)(uStack_5c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_5c & 0xfffffffe))(auStack_54,auStack_54,2);
      }
      uStack_5c = 0;
    }
    if (piStack_60 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_60[2] + -1;
      piStack_60[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_60 + 4))();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_38[2] + -1;
      piStack_38[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
    uVar5 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_38[2] + -1;
      piStack_38[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
    uVar5 = 0;
  }
  uStack_8 = 7;
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_3 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_3 = 0;
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 30175 ; VA 0x00caaa90 ; FUN_00caaa90 */

undefined FUN_00caaa90(undefined4 param_1,int *param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined uVar5;
  undefined4 *in_stack_0000002c;
  undefined auStack_64 [4];
  int *piStack_60;
  uint uStack_5c;
  undefined auStack_54 [24];
  undefined auStack_3c [4];
  int *piStack_38;
  uint uStack_34;
  undefined auStack_2c [24];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01811337;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00cab410(&param_1);
  uStack_8._0_1_ = 1;
  cVar3 = FUN_00585a40(auStack_3c);
  if (cVar3 == '\0') {
    FUN_00cab410(auStack_3c);
    uStack_8._0_1_ = 2;
    iStack_14 = FUN_01674e20(0x28);
    uStack_8._0_1_ = 3;
    if (iStack_14 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_00cab410(auStack_64);
    }
    *in_stack_0000002c = uVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (uStack_5c != 0) {
      if (((uStack_5c & 1) == 0) && (*(code **)(uStack_5c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_5c & 0xfffffffe))(auStack_54,auStack_54,2);
      }
      uStack_5c = 0;
    }
    if (piStack_60 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_60[2] + -1;
      piStack_60[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_60 + 4))();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_38[2] + -1;
      piStack_38[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
    uVar5 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_38[2] + -1;
      piStack_38[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
    uVar5 = 0;
  }
  uStack_8 = 7;
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_3 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_3 = 0;
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 30176 ; VA 0x00caac40 ; FUN_00caac40 */

void __thiscall
FUN_00caac40(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_18 = param_3;
  uStack_1c = param_2;
  uStack_14 = param_4;
  uStack_10 = param_5;
  cVar3 = FUN_00585a40(&uStack_1c);
  if (cVar3 == '\0') {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_10;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_1c;
    param_1[3] = piStack_18;
    param_1[4] = uStack_14;
    param_1[5] = uStack_10;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01975678;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 30177 ; VA 0x00caad60 ; FUN_00caad60 */

undefined FUN_00caad60(undefined4 param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char cVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  undefined uVar8;
  uint in_stack_00000020;
  int *in_stack_00000024;
  int aiStack_4c [5];
  uint uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01811377;
  pvStack_10 = ExceptionList;
  uStack_34 = param_1;
  uStack_30 = param_2;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 1;
  cVar3 = FUN_00585a40(&uStack_34);
  uVar2 = uStack_30;
  uVar1 = uStack_34;
  if (cVar3 == '\0') {
    FUN_0054ef60(auStack_2c);
    uStack_8._0_1_ = 2;
    puVar4 = (undefined4 *)FUN_01674e20(0x20);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[1] = uVar2;
      FUN_0054ef60(aiStack_4c);
    }
    *in_stack_00000024 = (int)puVar4;
    if (0xf < uStack_38) {
      uVar6 = uStack_38 + 1;
      iVar5 = aiStack_4c[0];
      if (0xfff < uVar6) {
        iVar5 = *(int *)(aiStack_4c[0] + -4);
        uVar6 = uStack_38 + 0x24;
        if (0x1f < (aiStack_4c[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar6);
    }
    if (0xf < uStack_18) {
      uVar7 = uStack_18 + 1;
      uVar6 = auStack_2c[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_2c[0] - 4);
        uVar7 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uVar8 = 1;
  }
  else {
    if (0xf < uStack_18) {
      uVar7 = uStack_18 + 1;
      uVar6 = auStack_2c[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_2c[0] - 4);
        uVar7 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uVar8 = 0;
  }
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_18 = 0xf;
  uStack_1c = 0;
  if (0xf < in_stack_00000020) {
    uVar6 = in_stack_00000020 + 1;
    iVar5 = param_3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(param_3 + -4);
      uVar6 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 30178 ; VA 0x00caaf10 ; FUN_00caaf10 */

int * __thiscall FUN_00caaf10(byte *param_1,int *param_2,int *param_3,int *param_4)

{
  uint *puVar1;
  int *piVar2;
  int *piVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int *piVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  undefined4 *puVar13;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01811398;
  pvStack_10 = ExceptionList;
  uVar11 = param_3[1];
  if (((int)uVar11 < 1) && ((int)uVar11 < 0)) {
    uVar11 = ~uVar11;
  }
  uVar11 = (uVar11 >> 2) + uVar11 * 0x40 + *param_3 ^ uVar11;
  ExceptionList = &pvStack_10;
  FUN_00606ff0(&iStack_14,uVar11,param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (iStack_14 == 0) {
    uStack_8 = 0;
    iStack_14 = 0;
    piVar9 = (int *)FUN_01674e20(0x18);
    iStack_14 = CONCAT22(iStack_14._2_2_,0x101);
    *piVar9 = 0;
    piVar9[1] = 0;
    piVar9[2] = 0;
    piVar9[3] = 0;
    piVar9[4] = 0;
    piVar9[5] = 0;
    iVar6 = param_4[1];
    iVar7 = param_4[2];
    iVar8 = param_4[3];
    piVar9[2] = *param_4;
    piVar9[3] = iVar6;
    piVar9[4] = iVar7;
    piVar9[5] = iVar8;
    uVar4 = *(uint *)(param_1 + 8);
    uVar10 = uVar4 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar10 = FUN_005d6bb0(uVar10);
      if (uVar10 <= *(uint *)(param_1 + 4)) {
        uVar10 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar10);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar10) {
      uVar12 = uVar4 >> 1;
      if (uVar4 + (uVar4 >> 1) <= uVar10) {
        uVar12 = 1;
      }
      uVar10 = FUN_005d6bb0(uVar12 + *(int *)(param_1 + 8));
      puVar1 = (uint *)(param_1 + 4);
      if (uVar10 != *puVar1) {
        FUN_005d2b00(uVar10);
        puVar13 = (undefined4 *)(*(int *)(param_1 + 0x14) + *puVar1 * 4);
        puVar5 = (undefined4 *)*puVar13;
        while (puVar5 != (undefined4 *)0x0) {
          piVar2 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar5[1] % *puVar1) * 4);
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar5[1] % *puVar1) * 4) == 0) {
            *piVar2 = (int)puVar13;
            puVar13 = puVar5;
          }
          else {
            *puVar13 = *puVar5;
            *puVar5 = *(undefined4 *)*piVar2;
            *(undefined4 **)*piVar2 = puVar5;
          }
          puVar5 = (undefined4 *)*puVar13;
        }
      }
    }
    piVar9[1] = uVar11;
    uVar10 = *(uint *)(param_1 + 4);
    piVar2 = (int *)(*(int *)(param_1 + 0x14) + (uVar11 % uVar10) * 4);
    if ((int *)*piVar2 == (int *)0x0) {
      piVar3 = (int *)(*(int *)(param_1 + 0x14) + uVar10 * 4);
      if (*piVar3 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar3 + 4) % uVar10) * 4) = piVar9;
      }
      *piVar2 = (int)piVar3;
      *piVar9 = *piVar3;
      *piVar3 = (int)piVar9;
    }
    else {
      *piVar9 = *(int *)*piVar2;
      *(int **)*piVar2 = piVar9;
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *param_2 = (int)piVar9;
    *(undefined *)(param_2 + 1) = 1;
    ExceptionList = pvStack_10;
    return param_2;
  }
  *param_2 = iStack_14;
  *(undefined *)(param_2 + 1) = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 30179 ; VA 0x00cab120 ; FUN_00cab120 */

void FUN_00cab120(int *param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int *piStack_8;
  
  piStack_8 = (int *)(*(int *)(param_2 + 0x14) + *(int *)(param_2 + 4) * 4);
  if (param_1 != (int *)0x0) {
    do {
      iVar2 = *(int *)(param_3 + 4);
      if (iVar2 == 0) {
        *(undefined2 *)(param_3 + 8) = 0;
        puVar5 = (undefined4 *)FUN_01674e20(0x30);
        *(undefined4 **)(param_3 + 4) = puVar5;
        *puVar5 = 0;
        puVar5[1] = 0;
        puVar5[2] = 0;
        puVar5[3] = 0;
        puVar5[4] = 0;
        puVar5[5] = 0;
        puVar5[6] = 0;
        puVar5[7] = 0;
        puVar5[8] = 0;
        puVar5[9] = 0;
        *(undefined8 *)(puVar5 + 10) = 0;
        *(undefined *)(param_3 + 8) = 1;
      }
      else if (*(char *)(param_3 + 9) != '\0') {
        uVar8 = *(uint *)(iVar2 + 0x28);
        if (0xf < uVar8) {
          iVar3 = *(int *)(iVar2 + 0x14);
          uVar7 = uVar8 + 1;
          iVar6 = iVar3;
          if (0xfff < uVar7) {
            iVar6 = *(int *)(iVar3 + -4);
            uVar7 = uVar8 + 0x24;
            if (0x1f < (iVar3 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar6,uVar7);
        }
        *(undefined4 *)(iVar2 + 0x24) = 0;
        *(undefined4 *)(iVar2 + 0x28) = 0xf;
        *(undefined *)(iVar2 + 0x14) = 0;
        *(undefined *)(param_3 + 9) = 0;
      }
      iVar2 = *(int *)(param_3 + 4);
      *(int *)(iVar2 + 8) = param_1[2];
      *(int *)(iVar2 + 0xc) = param_1[3];
      *(int *)(iVar2 + 0x10) = param_1[4];
      FUN_0054ef60(param_1 + 5);
      *(undefined *)(param_3 + 9) = 1;
      iVar2 = *(int *)(param_3 + 4);
      *(undefined4 *)(param_3 + 4) = 0;
      *(int *)(iVar2 + 4) = param_1[1];
      *piStack_8 = iVar2;
      *(int *)(param_2 + 8) = *(int *)(param_2 + 8) + 1;
      param_1 = (int *)*param_1;
      piVar4 = (int *)*piStack_8;
      uVar8 = (uint)piVar4[1] % *(uint *)(param_2 + 4);
      piVar1 = (int *)(*(int *)(param_2 + 0x14) + uVar8 * 4);
      if (*(int *)(*(int *)(param_2 + 0x14) + uVar8 * 4) == 0) {
        *piVar1 = (int)piStack_8;
        piStack_8 = piVar4;
      }
      else {
        *piStack_8 = *piVar4;
        *piVar4 = *(int *)*piVar1;
        *(int **)*piVar1 = piVar4;
      }
    } while (param_1 != (int *)0x0);
  }
  return;
}



/* FUNCTION 30180 ; VA 0x00cab260 ; FUN_00cab260 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Restarted to delay deadcode elimination for space: ram */

code * FUN_00cab260(code *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 uStack_1bc;
  code **ppcStack_1b8;
  undefined auStack_1b4 [184];
  undefined4 uStack_fc;
  undefined *puStack_f8;
  undefined *puStack_f4;
  int *piStack_f0;
  undefined4 uStack_dc;
  int *piStack_d8;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd64b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  piStack_f0 = (int *)0xcab28c;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_0088cdc0();
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_dc = in_stack_00000024;
  piStack_d8 = in_stack_00000028;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead288) {
    piStack_f0 = &DAT_01ead288;
    puStack_f4 = (undefined *)0xcab3cc;
    FUN_016f3809();
    if (DAT_01ead288 == -1) {
      piStack_f0 = &DAT_01ead288;
      DAT_01ead27c = FUN_0057bbb0;
      _DAT_01ead280 = FUN_005880a0;
      DAT_01ead284 = FUN_0057d5e0;
      puStack_f4 = (undefined *)0xcab404;
      FUN_016f37bf();
    }
  }
  puStack_14 = (undefined *)&uStack_1bc;
  uStack_8._0_1_ = 2;
  ppcStack_1b8 = (code **)0x0;
  uStack_1bc = uVar4;
  (*DAT_01ead27c)(&uStack_dc,auStack_1b4);
  ppcStack_1b8 = &DAT_01ead27c;
  FUN_008c6ce0();
  uStack_8._0_1_ = 3;
  piStack_f0 = &uStack_dc;
  puStack_f4 = (undefined *)0xcab35c;
  (*DAT_01ead284)();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_1 != (code *)0x0) && (((uint)param_1 & 1) == 0)) &&
     (param_1 = *(code **)((uint)param_1 & 0xfffffffe), param_1 != (code *)0x0)) {
    puStack_f8 = &stack0x0000000c;
    piStack_f0 = (int *)0x2;
    uStack_fc = 0xcab380;
    puStack_f4 = puStack_f8;
    param_1 = (code *)(*param_1)();
  }
  piVar3 = in_stack_00000028;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000028 + 1;
    iVar2 = *piVar1;
    param_1 = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_f0 = (int *)0xcab3a3;
      param_1 = (code *)(**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_f0 = (int *)0xcab3b2;
        param_1 = (code *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30181 ; VA 0x00cab410 ; FUN_00cab410 */

undefined4 * __thiscall FUN_00cab410(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar6 = ExceptionList;
  puStack_c = &LAB_018113b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  uVar2 = param_2[2];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[2] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[5];
      uVar4 = param_2[6];
      uVar5 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar3;
      param_1[6] = uVar4;
      param_1[7] = uVar5;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
      ExceptionList = pvVar6;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30182 ; VA 0x00cab4c0 ; FUN_00cab4c0 */

undefined4 * __thiscall FUN_00cab4c0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018113e3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  uVar2 = param_2[2];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[2] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar3 = param_2[5];
      uVar4 = param_2[6];
      uVar5 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar3;
      param_1[6] = uVar4;
      param_1[7] = uVar5;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = 0;
  uVar2 = param_2[10];
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (uVar2 != 0) {
    param_1[10] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0xd];
      uVar4 = param_2[0xe];
      uVar5 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar3;
      param_1[0xe] = uVar4;
      param_1[0xf] = uVar5;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30183 ; VA 0x00cab5c0 ; FUN_00cab5c0 */

undefined4 * __thiscall FUN_00cab5c0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01811403;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  uVar2 = param_2[2];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[2] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar3 = param_2[5];
      uVar4 = param_2[6];
      uVar5 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar3;
      param_1[6] = uVar4;
      param_1[7] = uVar5;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = 0;
  uVar2 = param_2[10];
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (uVar2 != 0) {
    param_1[10] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0xd];
      uVar4 = param_2[0xe];
      uVar5 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar3;
      param_1[0xe] = uVar4;
      param_1[0xf] = uVar5;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30184 ; VA 0x00cab6c0 ; FUN_00cab6c0 */

undefined4 * __thiscall
FUN_00cab6c0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 *param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181145b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar1 = FUN_00ca9700();
  FUN_009cb820(uVar1,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundYieldFuncDesc<class_RBX::GroupService,class_std::shared_ptr<class_RBX::Instance>___cdecl(__int64),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar1 = FUN_0088cdc0();
  param_1[9] = uVar1;
  if (param_1[0x10] == 0) {
    uStack_e8 = FUN_00888530();
    iStack_e4 = 0;
    param_6 = &uStack_e8;
    uStack_8 = 3;
    uVar3 = 2;
  }
  else {
    param_6 = (undefined4 *)FUN_005c1470(param_1[0x10]);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar3 = 1;
  }
  uStack_14 = uVar3;
  uVar1 = FUN_0088da50();
  uVar2 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar2,uVar1,param_6);
  if ((uVar3 & 2) != 0) {
    uVar3 = uVar3 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar3;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  if ((uVar3 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30185 ; VA 0x00cab820 ; FUN_00cab820 */

undefined4 * __thiscall FUN_00cab820(undefined4 *param_1,undefined4 *param_2)

{
  *param_1 = *param_2;
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  param_2[4] = 0;
  param_2[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  param_1[8] = param_2[8];
  param_2[6] = 0;
  param_2[7] = 0;
  param_2[8] = 0;
  return param_1;
}



/* FUNCTION 30186 ; VA 0x00cab8a0 ; FUN_00cab8a0 */

int * __thiscall FUN_00cab8a0(int *param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01811470;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar1 = (param_2[1] - *param_2) / 0x28;
  if (uVar1 != 0) {
    if (0x6666666 < uVar1) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar2 = FUN_00cac970(uVar1);
    *param_1 = iVar2;
    param_1[1] = iVar2;
    uStack_8 = 0;
    param_1[2] = *param_1 + uVar1 * 0x28;
    iVar2 = FUN_00caa220(*param_2,param_2[1],*param_1,param_1);
    param_1[1] = iVar2;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30187 ; VA 0x00cab944 ; Catch_All@00cab944 */

void Catch_All_00cab944(void)

{
  FUN_0091a5b0();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 30188 ; VA 0x00cab960 ; FUN_00cab960 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * __thiscall FUN_00cab960(undefined *param_1,undefined *param_2)

{
  int iVar1;
  undefined4 uVar2;
  float10 fVar3;
  uint uStack_20;
  undefined8 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181149b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  puStack_14 = param_1;
  FUN_0054ef60();
  param_1[0x1c] = 0;
  uStack_8 = 0;
  uStack_1c = ((double)*(int *)(param_2 + 0x24) +
              (double)(&DAT_018c0d90)[-(*(int *)(param_2 + 0x24) >> 0x1f)]) /
              (double)*(float *)(param_2 + 0x28);
  fVar3 = (float10)FUN_01725280(uStack_1c);
  uStack_1c = (double)fVar3;
  if (uStack_1c + DAT_018c0d60 < _DAT_018c4e98) {
    FUN_016f3eb1();
  }
  uVar2 = FUN_00588320();
  *(undefined4 *)(param_1 + 0x20) = uVar2;
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x28) = *(undefined4 *)(param_2 + 0x28);
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0;
  uStack_8._0_1_ = 1;
  if (*(int *)(param_2 + 0x24) != 0) {
    FUN_005d2b00();
    uStack_1c = (double)((ulonglong)uStack_1c & 0xffff000000000000);
    uStack_20 = -(uint)(param_1 != (undefined *)0xffffffe1) & (uint)(param_1 + 0x20);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (*(int *)(param_2 + 0x24) == 0) {
      uVar2 = 0;
    }
    else {
      uVar2 = *(undefined4 *)(*(int *)(param_2 + 0x30) + *(int *)(param_2 + 0x20) * 4);
    }
    FUN_00cab120(uVar2,param_1 + 0x1c,&uStack_20);
    iVar1 = (int)uStack_1c;
    if ((int)uStack_1c != 0) {
      if (uStack_1c._5_1_ != '\0') {
        FUN_00a5f130(uStack_20,(int)uStack_1c + 8);
      }
      FUN_01674ea0(iVar1,0x30);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30189 ; VA 0x00cabac0 ; FUN_00cabac0 */

undefined4 * __fastcall FUN_00cabac0(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018114d3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::GroupService,class_RBX::ServiceInstance>::vftable;
  uVar2 = FUN_00ca9700();
  param_1[3] = uVar2;
  *param_1 = RBX::GroupService::vftable;
  puVar1 = param_1 + 0x17;
  param_1[0x16] =
       RBX::
       LRUCache<__int64,struct_RBX::GroupService::GroupRolesRequestRecord,struct_boost::hash<__int64>_>
       ::vftable;
  uStack_8 = 1;
  *puVar1 = 0;
  param_1[0x18] = 0;
  puStack_18 = puVar1;
  uVar2 = FUN_00970740(0,0);
  *puVar1 = uVar2;
  *(undefined *)(param_1 + 0x19) = 0;
  uVar2 = FUN_00588320(0xb);
  param_1[0x1a] = uVar2;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0x3f800000;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  uStack_8._0_1_ = 2;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("GroupService",0xc);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_008a6520(auStack_30);
  if (0xf < uStack_1c) {
    uVar4 = uStack_1c + 1;
    uVar3 = auStack_30[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_30[0] - 4);
      uVar4 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 30190 ; VA 0x00cabbf0 ; FUN_00cabbf0 */

void __fastcall FUN_00cabbf0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::GroupService>::vftable;
  uVar1 = FUN_00ca9700(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30191 ; VA 0x00cabc30 ; FUN_00cabc30 */

void __fastcall FUN_00cabc30(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  *param_1 = RBX::
             LRUCache<__int64,struct_RBX::GroupService::GroupRolesRequestRecord,struct_boost::hash<__int64>_>
             ::vftable;
  FUN_00cad150();
  if (param_1[5] != 0) {
    puVar1 = (undefined4 *)(param_1[8] + param_1[4] * 4);
    puVar2 = (undefined4 *)*puVar1;
    do {
      *puVar1 = *puVar2;
      FUN_01674ea0(puVar2,0x18);
      param_1[5] = param_1[5] + -1;
      puVar2 = (undefined4 *)*puVar1;
    } while (puVar2 != (undefined4 *)0x0);
    puVar2 = (undefined4 *)param_1[8];
    puVar1 = puVar2 + param_1[4];
    for (; puVar2 != puVar1; puVar2 = puVar2 + 1) {
      *puVar2 = 0;
    }
  }
  param_1[9] = 0;
  FUN_0056d250();
  FUN_00cad150();
  FUN_01674ea0(param_1[1],0x38);
  return;
}



/* FUNCTION 30192 ; VA 0x00cabcc0 ; FUN_00cabcc0 */

void __fastcall FUN_00cabcc0(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_00a5f130(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x30);
  }
  return;
}



/* FUNCTION 30193 ; VA 0x00cabcf0 ; FUN_00cabcf0 */

int __fastcall FUN_00cabcf0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_0091a5b0();
  piVar3 = *(int **)(param_1 + 0x14);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00cabd23. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar4 = (**(code **)(*piVar3 + 4))();
        return iVar4;
      }
    }
  }
  return iVar4;
}



/* FUNCTION 30194 ; VA 0x00cabd30 ; FUN_00cabd30 */

int __fastcall FUN_00cabd30(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_0091a5b0();
  piVar3 = *(int **)(param_1 + 0x1c);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00cabd63. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar4 = (**(code **)(*piVar3 + 4))();
        return iVar4;
      }
    }
  }
  return iVar4;
}



/* FUNCTION 30195 ; VA 0x00cabd70 ; FUN_00cabd70 */

void __fastcall FUN_00cabd70(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  if (*(int *)(param_1 + 0x14) != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        uVar6 = puVar7[10];
        if (0xf < uVar6) {
          iVar2 = puVar7[5];
          uVar5 = uVar6 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar6 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00cabe2d;
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        puVar7[9] = 0;
        puVar7[10] = 0xf;
        *(undefined *)(puVar7 + 5) = 0;
        FUN_01674ea0(puVar7,0x30);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar3 = *(int *)(param_1 + 0x14);
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_00cabe2d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 30196 ; VA 0x00cabe40 ; thunk_FUN_0091a5b0 */

void __fastcall thunk_FUN_0091a5b0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_005f6200(*param_1,param_1[1]);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x28) * 0x28;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 30197 ; VA 0x00cabe50 ; FUN_00cabe50 */

int __fastcall FUN_00cabe50(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_0091a5b0();
  piVar3 = *(int **)(param_1 + 0xc);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00cabe83. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar4 = (**(code **)(*piVar3 + 4))();
        return iVar4;
      }
    }
  }
  return iVar4;
}



/* FUNCTION 30198 ; VA 0x00cabe90 ; FUN_00cabe90 */

void __fastcall FUN_00cabe90(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  FUN_00cabd70();
  uVar1 = *(uint *)(param_1 + 0x18);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 4);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0xf;
  *(undefined *)(param_1 + 4) = 0;
  return;
}



/* FUNCTION 30199 ; VA 0x00cabef0 ; FUN_00cabef0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __thiscall FUN_00cabef0(byte *param_1,uint *param_2)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  undefined4 *puVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018114e8;
  pvStack_10 = ExceptionList;
  uVar6 = ((int *)param_2)[1];
  iVar3 = *param_2;
  uVar8 = uVar6;
  if (((int)uVar6 < 1) && ((int)uVar6 < 0)) {
    uVar8 = ~uVar6;
  }
  uVar8 = (uVar8 >> 2) + uVar8 * 0x40 + iVar3 ^ uVar8;
  ExceptionList = &pvStack_10;
  FUN_00606ff0(&param_2,uVar8,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (uint *)0x0) {
    uStack_8 = 0;
    FUN_00cad1c0();
    _DAT_00000010 = 0;
    _DAT_00000018 = 0;
    _DAT_0000001c = 0;
    _DAT_00000020 = 0;
    uRam00000028 = 0xf;
    _DAT_00000014 = 0;
    uVar4 = *(uint *)(param_1 + 8);
    uVar1 = uVar4 + 1;
    _DAT_00000008 = iVar3;
    _DAT_0000000c = uVar6;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar6 = FUN_005d6bb0(uVar1);
      if (uVar6 <= *(uint *)(param_1 + 4)) {
        uVar6 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar6);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar1) {
      param_2 = (uint *)0x1;
      uVar6 = uVar4 >> 1;
      if (uVar4 + (uVar4 >> 1) <= uVar1) {
        uVar6 = 1;
      }
      uVar6 = FUN_005d6bb0(uVar6 + *(int *)(param_1 + 8));
      param_2 = (uint *)(param_1 + 4);
      if (uVar6 != *param_2) {
        FUN_005d2b00(uVar6);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *param_2 * 4);
        puVar5 = (undefined4 *)*puVar9;
        while (puVar5 != (undefined4 *)0x0) {
          piVar2 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar5[1] % *param_2) * 4);
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar5[1] % *param_2) * 4) == 0) {
            *piVar2 = (int)puVar9;
            puVar9 = puVar5;
          }
          else {
            *puVar9 = *puVar5;
            *puVar5 = *(undefined4 *)*piVar2;
            *(undefined4 **)*piVar2 = puVar5;
          }
          puVar5 = (undefined4 *)*puVar9;
        }
      }
    }
    iVar3 = *(int *)(param_1 + 0x14);
    uVar6 = *(uint *)(param_1 + 4);
    piVar2 = (int *)(iVar3 + (uVar8 % uVar6) * 4);
    _DAT_00000004 = uVar8;
    if ((int *)*piVar2 == (int *)0x0) {
      piVar7 = (int *)(iVar3 + uVar6 * 4);
      if (*piVar7 != 0) {
        *(undefined4 *)(iVar3 + (*(uint *)(*piVar7 + 4) % uVar6) * 4) = 0;
      }
      *piVar2 = (int)piVar7;
      _DAT_00000000 = *piVar7;
    }
    else {
      _DAT_00000000 = *(int *)*piVar2;
      piVar7 = (int *)*piVar2;
    }
    *piVar7 = 0;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return (int *)&DAT_00000008;
  }
  ExceptionList = pvStack_10;
  return (int *)param_2 + 2;
}



/* FUNCTION 30200 ; VA 0x00cac100 ; FUN_00cac100 */

void __thiscall FUN_00cac100(undefined4 *param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 ****ppppuVar4;
  uint uVar5;
  uint uVar6;
  undefined auStack_60 [4];
  uint uStack_5c;
  undefined4 uStack_4c;
  uint uStack_48;
  undefined uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 ***apppuStack_2c [4];
  int iStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01811510;
  pvStack_10 = ExceptionList;
  if (((-(uint)(param_2 != 0) & param_2 + 0xcU) != 0) &&
     (ExceptionList = &pvStack_10, iVar3 = FUN_00916100(), iVar3 != 0)) {
    uVar1 = param_1[1];
    uVar2 = *param_1;
    FUN_0054ef60(param_1 + 2);
    uStack_8 = 0;
    uStack_4c = 0;
    uStack_48 = 0xf;
    uStack_5c = uStack_5c & 0xffffff00;
    uStack_44 = 0;
    uStack_40 = FUN_00588320(0xb);
    uStack_3c = 0;
    uStack_38 = 0x3f800000;
    uStack_34 = 0;
    uStack_30 = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    auStack_60[0] = 0;
    if (iStack_1c == 0) {
      iStack_1c = 0xd;
      ppppuVar4 = (undefined4 ****)"unknown error";
    }
    else {
      ppppuVar4 = apppuStack_2c;
      if (0xf < uStack_18) {
        ppppuVar4 = (undefined4 ****)apppuStack_2c[0];
      }
    }
    FUN_005542c0(ppppuVar4,iStack_1c);
    FUN_00cab960(auStack_60);
    FUN_00cacec0(uVar2,uVar1);
    FUN_00cabd70();
    if (0xf < uStack_48) {
      uVar5 = uStack_48 + 1;
      uVar6 = uStack_5c;
      if (0xfff < uVar5) {
        uVar6 = *(uint *)(uStack_5c - 4);
        uVar5 = uStack_48 + 0x24;
        if (0x1f < (uStack_5c - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar5);
    }
    if (0xf < uStack_18) {
      uVar6 = uStack_18 + 1;
      ppppuVar4 = (undefined4 ****)apppuStack_2c[0];
      if (0xfff < uVar6) {
        ppppuVar4 = (undefined4 ****)apppuStack_2c[0][-1];
        uVar6 = uStack_18 + 0x24;
        if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar4,uVar6);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30201 ; VA 0x00cac270 ; FUN_00cac270 */

int __thiscall FUN_00cac270(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01811528;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*(int **)(param_1 + 0x24) != (int *)0x0) {
    ExceptionList = &pvStack_10;
    iVar4 = (**(code **)(**(int **)(param_1 + 0x24) + 8))(&param_2);
    piVar3 = param_3;
    if (param_3 != (int *)0x0) {
      LOCK();
      piVar1 = param_3 + 1;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)*param_3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar4 = (**(code **)(*piVar3 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return iVar4;
  }
  ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
  FUN_016ddc9c();
}



/* FUNCTION 30202 ; VA 0x00cac2f0 ; FUN_00cac2f0 */

undefined4 __thiscall FUN_00cac2f0(undefined4 param_1,byte param_2)

{
  FUN_00cabc30();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 30203 ; VA 0x00cac320 ; FUN_00cac320 */

undefined4 __thiscall FUN_00cac320(undefined4 param_1,byte param_2)

{
  FUN_00cabc30();
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x80);
  }
  return param_1;
}



/* FUNCTION 30204 ; VA 0x00cac350 ; FUN_00cac350 */

uint __thiscall FUN_00cac350(int *param_1,uint param_2)

{
  uint in_EAX;
  int iVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 == 0) {
    return in_EAX & 0xffffff00;
  }
  if (param_2 < 0x6666667) {
    iVar1 = FUN_00cac970(param_2);
    *param_1 = iVar1;
    param_1[1] = iVar1;
    iVar1 = *param_1 + param_2 * 0x28;
    param_1[2] = iVar1;
    return CONCAT31((int3)((uint)iVar1 >> 8),1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 30205 ; VA 0x00cac3b0 ; FUN_00cac3b0 */

void __fastcall FUN_00cac3b0(int param_1)

{
  FUN_00ca9d40(param_1 + 8);
  return;
}



/* FUNCTION 30206 ; VA 0x00cac3c0 ; FUN_00cac3c0 */

void __fastcall FUN_00cac3c0(int param_1)

{
  FUN_00ca9ee0(param_1 + 8);
  return;
}



/* FUNCTION 30207 ; VA 0x00cac3d0 ; FUN_00cac3d0 */

void __fastcall FUN_00cac3d0(int param_1)

{
  FUN_00caa080(param_1 + 8);
  return;
}



/* FUNCTION 30208 ; VA 0x00cac3e0 ; FUN_00cac3e0 */

void __thiscall FUN_00cac3e0(undefined4 param_1,char param_2)

{
  FUN_008c3510();
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0x50);
  }
  return;
}



/* FUNCTION 30209 ; VA 0x00cac410 ; FUN_00cac410 */

void FUN_00cac410(void)

{
  FUN_00cabe90();
  return;
}



/* FUNCTION 30210 ; VA 0x00cac420 ; FUN_00cac420 */

int __thiscall FUN_00cac420(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  char *pcVar3;
  int *piVar4;
  int iVar5;
  char *pcVar6;
  undefined auStack_44 [12];
  undefined4 uStack_38;
  undefined4 *puStack_34;
  int iStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01811610;
  pvStack_10 = ExceptionList;
  pcVar3 = (char *)*param_2;
  piVar4 = (int *)param_2[1];
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  param_2[1] = 0;
  uStack_8 = 0;
  if (*pcVar3 == '\0') {
    pcVar6 = pcVar3 + 4;
    if (0xf < *(uint *)(pcVar3 + 0x18)) {
      pcVar6 = *(char **)pcVar6;
    }
    FUN_01675640(auStack_44,"Player:GetRankInGroup failed because %s",pcVar6);
    iVar5 = FUN_005e65e0();
  }
  else {
    iStack_30 = param_1 + 0x48;
    puStack_34 = &param_2;
    uStack_38 = 0xcac477;
    FUN_00cad5c0();
    if (param_2 == (undefined4 *)0x0) {
      if (*(uint *)(param_1 + 8) == 0) {
        iStack_30 = 0xcac509;
        iStack_30 = FUN_0054fda0();
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
        puStack_34 = (undefined4 *)&UNK_00cac513;
        FUN_0054e5e0();
      }
      puStack_34 = (undefined4 *)(param_1 + 0x10);
      iStack_30 = 0;
      uStack_38 = 0xcac49e;
      iVar5 = (**(code **)((*(uint *)(param_1 + 8) & 0xfffffffe) + 4))();
    }
    else {
      iStack_30 = param_2[4];
      puStack_34 = (undefined4 *)0xcac488;
      iVar5 = FUN_008927d0();
    }
  }
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar1 = piVar4 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iStack_30 = 0xcac4e0;
      iVar5 = (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iStack_30 = 0xcac4ef;
        iVar5 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 30211 ; VA 0x00cac520 ; FUN_00cac520 */

int __thiscall FUN_00cac520(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  char *pcVar3;
  int *piVar4;
  int iVar5;
  char *pcVar6;
  undefined auStack_38 [12];
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  int iStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01811628;
  pvStack_10 = ExceptionList;
  pcVar3 = (char *)*param_2;
  piVar4 = (int *)param_2[1];
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  param_2[1] = 0;
  uStack_8 = 0;
  if (*pcVar3 == '\0') {
    pcVar6 = pcVar3 + 4;
    if (0xf < *(uint *)(pcVar3 + 0x18)) {
      pcVar6 = *(char **)pcVar6;
    }
    FUN_01675640(auStack_38,"Player:GetRoleInGroup failed because %s",pcVar6);
  }
  else {
    iStack_24 = param_1 + 0x48;
    puStack_28 = &param_2;
    uStack_2c = 0xcac577;
    FUN_00cad5c0();
    if (param_2 == (undefined4 *)0x0) {
      puStack_28 = (undefined4 *)0x0;
      iStack_24 = 0xf;
      auStack_38[0] = 0;
      FUN_005542c0("Guest",5);
    }
    else {
      FUN_0054ef60(param_2 + 5);
    }
  }
  iVar5 = FUN_005e65e0();
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar1 = piVar4 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iStack_24 = 0xcac5ee;
      iVar5 = (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iStack_24 = 0xcac5fd;
        iVar5 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 30212 ; VA 0x00cac610 ; FUN_00cac610 */

int __thiscall FUN_00cac610(int param_1,undefined4 *param_2)

{
  int iVar1;
  char *pcVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  char *pcVar6;
  undefined auStack_48 [12];
  undefined4 uStack_3c;
  undefined *puStack_38;
  int iStack_34;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01811650;
  pvStack_10 = ExceptionList;
  pcVar2 = (char *)*param_2;
  piVar3 = (int *)param_2[1];
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  param_2[1] = 0;
  uStack_8 = 0;
  if (*pcVar2 == '\0') {
    pcVar6 = pcVar2 + 4;
    if (0xf < *(uint *)(pcVar2 + 0x18)) {
      pcVar6 = *(char **)pcVar6;
    }
    FUN_01675640(auStack_48,"Player:IsInGroup failed because %s",pcVar6);
    iVar5 = FUN_005e65e0();
  }
  else {
    iStack_34 = param_1 + 0x48;
    puStack_38 = auStack_14;
    uStack_3c = 0xcac666;
    piVar4 = (int *)FUN_00cad5c0();
    param_2 = (undefined4 *)CONCAT31(param_2._1_3_,*piVar4 != 0);
    if (*(uint *)(param_1 + 8) == 0) {
      iStack_34 = 0xcac6ee;
      iStack_34 = FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
      puStack_38 = &UNK_00cac6f8;
      FUN_0054e5e0();
    }
    iStack_34 = (int)param_2;
    puStack_38 = (undefined *)(param_1 + 0x10);
    uStack_3c = 0xcac683;
    iVar5 = (**(code **)((*(uint *)(param_1 + 8) & 0xfffffffe) + 4))();
  }
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar4 = piVar3 + 1;
    iVar1 = *piVar4;
    iVar5 = *piVar4;
    *piVar4 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iStack_34 = 0xcac6c5;
      iVar5 = (**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iStack_34 = 0xcac6d4;
        iVar5 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 30213 ; VA 0x00cac700 ; FUN_00cac700 */

undefined4 * __thiscall FUN_00cac700(int param_1,undefined4 *param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01811668;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_330865718c09507678fa7a6d1c6308c2>,void,class_std::shared_ptr<struct_RBX::GroupService::GroupRolesResult_const_>_>
             ::vftable;
  param_2[2] = 0;
  FUN_005880d0(param_1 + 8);
  uStack_8 = 0;
  param_2[10] = 0;
  FUN_005880d0(param_1 + 0x28);
  param_2[0x12] = *(undefined4 *)(param_1 + 0x48);
  param_2[0x13] = *(undefined4 *)(param_1 + 0x4c);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 30214 ; VA 0x00cac780 ; FUN_00cac780 */

undefined4 * __thiscall FUN_00cac780(int param_1,undefined4 *param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c47f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_68d5bed75bd3d27e4f729d85f19c6337>,void,class_std::shared_ptr<struct_RBX::GroupService::GroupRolesResult_const_>_>
             ::vftable;
  param_2[2] = 0;
  FUN_005880d0(param_1 + 8);
  uStack_8 = 0;
  param_2[10] = 0;
  FUN_005880d0(param_1 + 0x28);
  param_2[0x12] = *(undefined4 *)(param_1 + 0x48);
  param_2[0x13] = *(undefined4 *)(param_1 + 0x4c);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 30215 ; VA 0x00cac800 ; FUN_00cac800 */

undefined4 * __thiscall FUN_00cac800(int param_1,undefined4 *param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01811688;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_c7c981181f7fb988110f93015bab1295>,void,class_std::shared_ptr<struct_RBX::GroupService::GroupRolesResult_const_>_>
             ::vftable;
  param_2[2] = 0;
  FUN_005880d0(param_1 + 8);
  uStack_8 = 0;
  param_2[10] = 0;
  FUN_005880d0(param_1 + 0x28);
  param_2[0x12] = *(undefined4 *)(param_1 + 0x48);
  param_2[0x13] = *(undefined4 *)(param_1 + 0x4c);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 30216 ; VA 0x00cac880 ; FUN_00cac880 */

TypeDescriptor * FUN_00cac880(void)

{
  return &<lambda_330865718c09507678fa7a6d1c6308c2>::RTTI_Type_Descriptor;
}



/* FUNCTION 30217 ; VA 0x00cac890 ; FUN_00cac890 */

TypeDescriptor * FUN_00cac890(void)

{
  return &<lambda_68d5bed75bd3d27e4f729d85f19c6337>::RTTI_Type_Descriptor;
}



/* FUNCTION 30218 ; VA 0x00cac8a0 ; FUN_00cac8a0 */

TypeDescriptor * FUN_00cac8a0(void)

{
  return &<lambda_c7c981181f7fb988110f93015bab1295>::RTTI_Type_Descriptor;
}



/* FUNCTION 30219 ; VA 0x00cac8b0 ; FUN_00cac8b0 */

int FUN_00cac8b0(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_018116b0;
  pvStack_10 = ExceptionList;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    puVar4 = param_1 + 9;
    ExceptionList = &pvStack_10;
    do {
      *(undefined4 *)(param_3 + 0x24) = 0;
      piVar2 = (int *)*puVar4;
      uStack_8 = 1;
      if (piVar2 != (int *)0x0) {
        if (piVar2 == puVar4 + -9) {
          uVar3 = (**(code **)(*piVar2 + 4))(param_3);
          *(undefined4 *)(param_3 + 0x24) = uVar3;
          piVar2 = (int *)*puVar4;
          if (piVar2 == (int *)0x0) goto LAB_00cac932;
          (**(code **)(*piVar2 + 0x10))(CONCAT31((int3)((uint)*piVar2 >> 8),piVar2 != puVar4 + -9));
        }
        else {
          *(int **)(param_3 + 0x24) = piVar2;
        }
        *puVar4 = 0;
      }
LAB_00cac932:
      param_3 = param_3 + 0x28;
      puVar1 = puVar4 + 1;
      puVar4 = puVar4 + 10;
    } while (puVar1 != param_2);
  }
  uStack_8 = 0;
  FUN_0072a040();
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 30220 ; VA 0x00cac970 ; FUN_00cac970 */

uint FUN_00cac970(uint param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = param_1 * 0x28;
  if (param_1 < 0x6666667) {
    if (uVar3 < 0x1000) {
      if (uVar3 != 0) {
        uVar3 = FUN_01674e20(uVar3);
        return uVar3;
      }
      return 0;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar3 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar2;
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 30221 ; VA 0x00cac9e0 ; FUN_00cac9e0 */

void FUN_00cac9e0(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 uint *param_5,uint *param_6)

{
  undefined4 uVar1;
  uint uVar2;
  uint *puVar3;
  uint *puVar4;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  undefined8 uStack_9c;
  undefined4 uStack_94;
  undefined4 uStack_80;
  uint *puStack_7c;
  uint *puStack_78;
  undefined4 uStack_74;
  uint auStack_70 [2];
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  undefined8 uStack_58;
  uint uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  undefined *puStack_20;
  undefined *puStack_1c;
  code *pcStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018116d0;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)auStack_70;
  puStack_20 = (undefined *)auStack_70;
  pcStack_18 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01f02679);
  uStack_14 = *param_4;
  uVar1 = param_4[1];
  auStack_70[0] = 0;
  uVar2 = *param_6;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_70;
  puVar4 = auStack_70;
  if (uVar2 != 0) {
    auStack_70[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_78 = &uStack_68;
      uStack_74 = 0;
      puStack_7c = param_6 + 2;
      uStack_80 = 0xcaca65;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
      puVar3 = (uint *)puStack_20;
      puVar4 = (uint *)puStack_1c;
    }
    else {
      uStack_68 = param_6[2];
      uStack_64 = param_6[3];
      uStack_60 = param_6[4];
      uStack_5c = param_6[5];
      uStack_58 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
      puVar3 = auStack_70;
      puVar4 = auStack_70;
    }
  }
  puStack_1c = (undefined *)puVar4;
  puStack_20 = (undefined *)puVar3;
  uStack_8 = 0;
  uStack_94 = param_1;
  uVar2 = *param_5;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_5 + 2);
    }
    else {
      uStack_ac = param_5[2];
      uStack_a8 = param_5[3];
      uStack_a4 = param_5[4];
      uStack_a0 = param_5[5];
      uStack_9c = *(undefined8 *)(param_5 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_94 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_40 != 0) {
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_ac,0);
    }
    else {
      uStack_ac = uStack_38;
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
    }
  }
  FUN_00912d50();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
     (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
    uStack_94 = 2;
    uStack_9c = CONCAT44(&uStack_38,&uStack_38);
    uStack_a0 = 0xcacb47;
    (**(code **)(uStack_40 & 0xfffffffe))();
  }
  uStack_8 = 0xffffffff;
  uStack_9c = CONCAT44(uStack_14,0xcacb67);
  uStack_94 = uVar1;
  (*pcStack_18)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30222 ; VA 0x00cacb80 ; FUN_00cacb80 */

void FUN_00cacb80(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 uint *param_5,uint *param_6)

{
  undefined4 uVar1;
  uint uVar2;
  uint *puVar3;
  uint *puVar4;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  undefined8 uStack_9c;
  undefined4 uStack_94;
  undefined4 uStack_80;
  uint *puStack_7c;
  uint *puStack_78;
  undefined4 uStack_74;
  uint auStack_70 [2];
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  undefined8 uStack_58;
  uint uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  undefined *puStack_20;
  undefined *puStack_1c;
  code *pcStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018116f0;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)auStack_70;
  puStack_20 = (undefined *)auStack_70;
  pcStack_18 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01f02679);
  uStack_14 = *param_4;
  uVar1 = param_4[1];
  auStack_70[0] = 0;
  uVar2 = *param_6;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_70;
  puVar4 = auStack_70;
  if (uVar2 != 0) {
    auStack_70[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_78 = &uStack_68;
      uStack_74 = 0;
      puStack_7c = param_6 + 2;
      uStack_80 = 0xcacc05;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
      puVar3 = (uint *)puStack_20;
      puVar4 = (uint *)puStack_1c;
    }
    else {
      uStack_68 = param_6[2];
      uStack_64 = param_6[3];
      uStack_60 = param_6[4];
      uStack_5c = param_6[5];
      uStack_58 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
      puVar3 = auStack_70;
      puVar4 = auStack_70;
    }
  }
  puStack_1c = (undefined *)puVar4;
  puStack_20 = (undefined *)puVar3;
  uStack_8 = 0;
  uStack_94 = param_1;
  uVar2 = *param_5;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_5 + 2);
    }
    else {
      uStack_ac = param_5[2];
      uStack_a8 = param_5[3];
      uStack_a4 = param_5[4];
      uStack_a0 = param_5[5];
      uStack_9c = *(undefined8 *)(param_5 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_94 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_40 != 0) {
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_ac,0);
    }
    else {
      uStack_ac = uStack_38;
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
    }
  }
  FUN_00960570();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
     (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
    uStack_94 = 2;
    uStack_9c = CONCAT44(&uStack_38,&uStack_38);
    uStack_a0 = 0xcacce7;
    (**(code **)(uStack_40 & 0xfffffffe))();
  }
  uStack_8 = 0xffffffff;
  uStack_9c = CONCAT44(uStack_14,0xcacd07);
  uStack_94 = uVar1;
  (*pcStack_18)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30223 ; VA 0x00cacd20 ; FUN_00cacd20 */

void FUN_00cacd20(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 uint *param_5,uint *param_6)

{
  undefined4 uVar1;
  uint uVar2;
  uint *puVar3;
  uint *puVar4;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  undefined8 uStack_9c;
  undefined4 uStack_94;
  undefined4 uStack_80;
  uint *puStack_7c;
  uint *puStack_78;
  undefined4 uStack_74;
  uint auStack_70 [2];
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  undefined8 uStack_58;
  uint uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  undefined *puStack_20;
  undefined *puStack_1c;
  code *pcStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01811710;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)auStack_70;
  puStack_20 = (undefined *)auStack_70;
  pcStack_18 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01f02679);
  uStack_14 = *param_4;
  uVar1 = param_4[1];
  auStack_70[0] = 0;
  uVar2 = *param_6;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_70;
  puVar4 = auStack_70;
  if (uVar2 != 0) {
    auStack_70[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_78 = &uStack_68;
      uStack_74 = 0;
      puStack_7c = param_6 + 2;
      uStack_80 = 0xcacda5;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
      puVar3 = (uint *)puStack_20;
      puVar4 = (uint *)puStack_1c;
    }
    else {
      uStack_68 = param_6[2];
      uStack_64 = param_6[3];
      uStack_60 = param_6[4];
      uStack_5c = param_6[5];
      uStack_58 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
      puVar3 = auStack_70;
      puVar4 = auStack_70;
    }
  }
  puStack_1c = (undefined *)puVar4;
  puStack_20 = (undefined *)puVar3;
  uStack_8 = 0;
  uStack_94 = param_1;
  uVar2 = *param_5;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_5 + 2);
    }
    else {
      uStack_ac = param_5[2];
      uStack_a8 = param_5[3];
      uStack_a4 = param_5[4];
      uStack_a0 = param_5[5];
      uStack_9c = *(undefined8 *)(param_5 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_94 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_40 != 0) {
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_ac,0);
    }
    else {
      uStack_ac = uStack_38;
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
    }
  }
  FUN_00b567b0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
     (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
    uStack_94 = 2;
    uStack_9c = CONCAT44(&uStack_38,&uStack_38);
    uStack_a0 = 0xcace87;
    (**(code **)(uStack_40 & 0xfffffffe))();
  }
  uStack_8 = 0xffffffff;
  uStack_9c = CONCAT44(uStack_14,0xcacea7);
  uStack_94 = uVar1;
  (*pcStack_18)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30224 ; VA 0x00cacec0 ; FUN_00cacec0 */

void __thiscall FUN_00cacec0(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  char cVar5;
  int *piVar6;
  uint uVar7;
  int iVar8;
  int in_stack_00000010;
  uint in_stack_00000024;
  int aiStack_80 [9];
  int *piStack_5c;
  undefined8 uStack_58;
  int *piStack_50;
  int *piStack_4c;
  int iStack_48;
  int iStack_44;
  undefined4 uStack_40;
  int iStack_38;
  int iStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01811767;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar6 = (int *)FUN_01674e20(0x40);
  uStack_8._0_1_ = 1;
  if (piVar6 == (int *)0x0) {
    piVar6 = (int *)0x0;
  }
  else {
    piVar6[1] = 1;
    piVar6[2] = 1;
    *piVar6 = (int)std::_Ref_count_obj<struct_RBX::GroupService::GroupRolesResult>::vftable;
    piStack_20 = piVar6;
    FUN_00cab960(&stack0x0000000c);
  }
  piVar4 = piVar6 + 3;
  uStack_40 = 0;
  uStack_58 = 0;
  piStack_50 = (int *)0x0;
  piStack_4c = (int *)0x0;
  iStack_48 = 0;
  iStack_44 = 0;
  uStack_8._0_1_ = 3;
  piStack_20 = (int *)(param_1 + 0x58);
  piStack_2c = piVar4;
  piStack_28 = piVar6;
  cVar5 = FUN_00cad4d0(&stack0x00000004,&uStack_58,1);
  iVar8 = iStack_48;
  if (cVar5 == '\0') {
    FUN_0091a5b0();
  }
  else {
    iStack_18 = iStack_44;
    iStack_34 = iStack_44;
    uStack_8._0_1_ = 4;
    iStack_14 = iStack_48;
    iStack_38 = iStack_48;
    iStack_48 = 0;
    iStack_44 = 0;
    uStack_30 = uStack_40;
    uStack_40 = 0;
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
    }
    piStack_1c = piStack_4c;
    piStack_50 = piVar4;
    piVar4 = piVar6;
    if (piStack_4c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_4c[1] + -1;
      piStack_4c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        puVar2 = (undefined4 *)*piStack_4c;
        piStack_4c = piVar6;
        (*(code *)*puVar2)();
        LOCK();
        iVar3 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar3;
        UNLOCK();
        piVar4 = piStack_4c;
        if (iVar3 == 0) {
          (**(code **)(*piStack_1c + 4))();
          piVar4 = piStack_4c;
        }
      }
    }
    piStack_4c = piVar4;
    FUN_00cb1730(&stack0x00000004,&uStack_58,DAT_01d68be0,0);
    if (iVar8 != iStack_18) {
      do {
        piStack_5c = (int *)0x0;
        uStack_8._0_1_ = 5;
        if (*(undefined4 **)(iVar8 + 0x24) != (undefined4 *)0x0) {
          piStack_5c = (int *)(**(code **)**(undefined4 **)(iVar8 + 0x24))(aiStack_80);
        }
        if (piVar6 != (int *)0x0) {
          LOCK();
          piVar6[1] = piVar6[1] + 1;
          UNLOCK();
        }
        piStack_24 = piVar6 + 3;
        uStack_8 = CONCAT31(uStack_8._1_3_,7);
        piStack_20 = piVar6;
        if (piStack_5c == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
          FUN_016ddc9c();
        }
        (**(code **)(*piStack_5c + 8))(&piStack_24);
        piVar4 = piStack_20;
        if (piStack_20 != (int *)0x0) {
          LOCK();
          iVar8 = piStack_20[1] + -1;
          piStack_20[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piStack_20)();
            LOCK();
            piVar1 = piVar4 + 2;
            iVar8 = *piVar1 + -1;
            *piVar1 = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        uStack_8._0_1_ = 4;
        if (piStack_5c != (int *)0x0) {
          (**(code **)(*piStack_5c + 0x10))(piStack_5c != aiStack_80);
        }
        iVar8 = iStack_14 + 0x28;
        iStack_14 = iVar8;
      } while (iVar8 != iStack_18);
    }
    FUN_0091a5b0();
    FUN_0091a5b0();
  }
  piVar4 = piStack_4c;
  if (piStack_4c != (int *)0x0) {
    LOCK();
    iVar8 = piStack_4c[1] + -1;
    piStack_4c[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_4c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar8 = *piVar1 + -1;
      *piVar1 = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar8 = piVar6[1] + -1;
    piVar6[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      piVar4 = piVar6 + 2;
      iVar8 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  FUN_00cabd70();
  if (0xf < in_stack_00000024) {
    uVar7 = in_stack_00000024 + 1;
    iVar8 = in_stack_00000010;
    if (0xfff < uVar7) {
      iVar8 = *(int *)(in_stack_00000010 + -4);
      uVar7 = in_stack_00000024 + 0x24;
      if (0x1f < (in_stack_00000010 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar7);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30225 ; VA 0x00cad150 ; FUN_00cad150 */

void __fastcall FUN_00cad150(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  
  piVar1 = (int *)*param_1;
  piVar4 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar4 != (int *)*param_1) {
    do {
      piVar1 = (int *)*piVar4;
      FUN_0091a5b0();
      piVar2 = (int *)piVar4[9];
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar3 = piVar2[1] + -1;
        piVar2[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar3 = piVar2[2] + -1;
          piVar2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      FUN_01674ea0(piVar4,0x38);
      piVar4 = piVar1;
    } while (piVar1 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 30226 ; VA 0x00cad1c0 ; FUN_00cad1c0 */

void __fastcall FUN_00cad1c0(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  if (param_1[1] == 0) {
    *(undefined2 *)(param_1 + 2) = 0;
    puVar1 = (undefined4 *)FUN_01674e20(0x30);
    param_1[1] = puVar1;
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    puVar1[6] = 0;
    puVar1[7] = 0;
    puVar1[8] = 0;
    puVar1[9] = 0;
    *(undefined8 *)(puVar1 + 10) = 0;
    *(undefined *)(param_1 + 2) = 1;
    return;
  }
  if (*(char *)((int)param_1 + 9) != '\0') {
    FUN_00a5f130(*param_1,param_1[1] + 8);
    *(undefined *)((int)param_1 + 9) = 0;
  }
  return;
}



/* FUNCTION 30227 ; VA 0x00cad220 ; FUN_00cad220 */

undefined4 * FUN_00cad220(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00916040(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 30228 ; VA 0x00cad290 ; FUN_00cad290 */

void __thiscall FUN_00cad290(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  uint in_stack_0000002c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3d80;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uStack_18 = FUN_009269c0(param_3,param_1 + 0x40);
  FUN_00cac9e0(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_18,
               &param_4,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 3;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30229 ; VA 0x00cad350 ; FUN_00cad350 */

void __thiscall FUN_00cad350(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  uint in_stack_0000002c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3d80;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uStack_18 = FUN_009269c0(param_3,param_1 + 0x40);
  FUN_00cacb80(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_18,
               &param_4,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 3;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30230 ; VA 0x00cad410 ; FUN_00cad410 */

void __thiscall FUN_00cad410(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  uint in_stack_0000002c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3d80;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uStack_18 = FUN_009269c0(param_3,param_1 + 0x40);
  FUN_00cacd20(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_18,
               &param_4,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 3;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30231 ; VA 0x00cad4d0 ; FUN_00cad4d0 */

undefined4 __thiscall FUN_00cad4d0(int param_1,int *param_2,undefined4 *param_3,undefined4 param_4)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  
  piVar1 = param_2;
  iVar6 = param_1 + 0xd + (uint)*(byte *)(param_1 + 0xc);
  uVar4 = param_2[1];
  if (((int)uVar4 < 1) && ((int)uVar4 < 0)) {
    uVar4 = ~uVar4;
  }
  FUN_00606ff0(&param_2,(uVar4 >> 2) + uVar4 * 0x40 + *param_2 ^ uVar4,param_2,
               -(uint)(iVar6 != 0) & iVar6 + 1U);
  piVar2 = param_2;
  if (param_2 == (int *)0x0) {
    return 0;
  }
  if ((char)param_4 != '\0') {
    FUN_00929190(&param_4,piVar1);
  }
  puVar3 = param_3;
  if (param_3 != (undefined4 *)0x0) {
    iVar6 = piVar2[4];
    *param_3 = *(undefined4 *)(iVar6 + 0x18);
    param_3[1] = *(undefined4 *)(iVar6 + 0x1c);
    iVar5 = *(int *)(iVar6 + 0x24);
    if (iVar5 != 0) {
      LOCK();
      *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
      UNLOCK();
      iVar5 = *(int *)(iVar6 + 0x24);
    }
    param_3[2] = *(undefined4 *)(iVar6 + 0x20);
    piVar1 = (int *)param_3[3];
    param_3[3] = iVar5;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar5 = piVar1[1] + -1;
      piVar1[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar5 = piVar1[2] + -1;
        piVar1[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    if (puVar3 + 4 != (undefined4 *)(iVar6 + 0x28)) {
      FUN_00ca9820(*(undefined4 *)(iVar6 + 0x28),*(undefined4 *)(iVar6 + 0x2c),param_4);
    }
  }
  return 1;
}



/* FUNCTION 30232 ; VA 0x00cad5c0 ; FUN_00cad5c0 */

void __thiscall FUN_00cad5c0(byte *param_1,undefined4 *param_2,int *param_3)

{
  uint uVar1;
  
  uVar1 = param_3[1];
  if (((int)uVar1 < 1) && ((int)uVar1 < 0)) {
    uVar1 = ~uVar1;
  }
  FUN_00606ff0(&param_3,(uVar1 >> 2) + uVar1 * 0x40 + *param_3 ^ uVar1,param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  *param_2 = param_3;
  return;
}



/* FUNCTION 30233 ; VA 0x00cad620 ; FUN_00cad620 */

void FUN_00cad620(undefined4 param_1,int *param_2,uint param_3,undefined4 param_4,undefined4 param_5
                 ,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined8 param_9,
                 char *param_10,undefined4 param_11,undefined *param_12,undefined4 param_13,
                 undefined4 param_14,uint *param_15,undefined8 param_16)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  int **ppiVar4;
  char **ppcVar5;
  undefined *puVar6;
  int *piVar7;
  undefined4 *puVar8;
  uint auStack_f4 [2];
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined8 uStack_dc;
  int *piStack_d4;
  int *piStack_d0;
  undefined auStack_cc [28];
  undefined4 uStack_b0;
  undefined4 *puStack_ac;
  undefined4 *puStack_a8;
  undefined *puStack_a4;
  undefined auStack_a0 [16];
  undefined4 uStack_90;
  undefined4 *puStack_8c;
  undefined **ppuStack_88;
  uint *puStack_84;
  char *pcStack_80;
  undefined4 *puStack_7c;
  undefined *puStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  uint *puStack_6c;
  undefined8 uStack_68;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  undefined auStack_40 [4];
  int *piStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  undefined *puStack_28;
  undefined *puStack_24;
  undefined *puStack_20;
  code *pcStack_1c;
  undefined *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018117b8;
  pvStack_10 = ExceptionList;
  puStack_6c = auStack_58;
  uStack_8 = 1;
  uStack_68 = CONCAT44(param_2,param_1);
  uStack_70 = 0xcad655;
  ExceptionList = &pvStack_10;
  FUN_01091b00();
  uStack_8._0_1_ = 2;
  param_2 = (int *)0xa;
  uStack_74 = 0xcad666;
  uStack_74 = FUN_008f7870();
  puStack_78 = auStack_40;
  puStack_7c = (undefined4 *)0xcad670;
  ppuStack_88 = (undefined **)FUN_005e5de0();
  puStack_7c = &param_2;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  pcStack_80 = "Groups";
  puStack_84 = auStack_58;
  puStack_8c = &uStack_38;
  uStack_90 = 0xcad68b;
  puVar8 = (undefined4 *)FUN_00b14d90();
  param_2 = (int *)*puVar8;
  piVar1 = (int *)puVar8[1];
  *puVar8 = 0;
  puVar8[1] = 0;
  piStack_14 = piStack_34;
  piStack_30 = param_2;
  piStack_2c = piVar1;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_34[1] + -1;
    piStack_34[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_68 = CONCAT44(0xcad6c3,(undefined4)uStack_68);
      (**(code **)*piStack_34)();
      LOCK();
      iVar2 = piStack_14[2] + -1;
      piStack_14[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_68 = CONCAT44(0xcad6d4,(undefined4)uStack_68);
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_3c[2] + -1;
    piStack_3c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_68 = CONCAT44(0xcad6ed,(undefined4)uStack_68);
      (**(code **)(*piStack_3c + 4))();
    }
  }
  puStack_20 = (undefined *)&pcStack_80;
  puStack_18 = (undefined *)&pcStack_80;
  pcStack_1c = *(code **)(*param_2 + 0xa4);
  pcStack_80 = (char *)0x0;
  ppcVar5 = &pcStack_80;
  if (param_10 != (char *)0x0) {
    pcStack_80 = param_10;
    if (((uint)param_10 & 1) == 0) {
      ppuStack_88 = &puStack_78;
      puStack_84 = (uint *)0x0;
      puStack_8c = &param_12;
      uStack_90 = 0xcad73f;
      (**(code **)((uint)param_10 & 0xfffffffe))();
      ppcVar5 = (char **)puStack_20;
    }
    else {
      puStack_78 = param_12;
      uStack_74 = param_13;
      uStack_70 = param_14;
      puStack_6c = param_15;
      uStack_68 = param_16;
      ppcVar5 = &pcStack_80;
    }
  }
  puStack_20 = (undefined *)ppcVar5;
  puStack_18 = auStack_a0;
  puStack_a4 = (undefined *)0x0;
  piStack_14 = (int *)auStack_cc;
  puStack_24 = (undefined *)&piStack_d4;
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar1[1] = piVar1[1] + 1;
    UNLOCK();
  }
  puStack_28 = (undefined *)auStack_f4;
  uStack_8._0_1_ = 7;
  auStack_f4[0] = 0;
  piStack_d4 = param_2;
  piStack_d0 = piVar1;
  puVar3 = auStack_f4;
  ppiVar4 = &piStack_d4;
  puVar6 = auStack_a0;
  piVar7 = (int *)auStack_cc;
  if (param_3 != 0) {
    auStack_f4[0] = param_3;
    if ((param_3 & 1) == 0) {
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_ec,0);
      puVar3 = (uint *)puStack_28;
      ppiVar4 = (int **)puStack_24;
      puVar6 = puStack_18;
      piVar7 = piStack_14;
    }
    else {
      uStack_ec = param_5;
      uStack_e8 = param_6;
      uStack_e4 = param_7;
      uStack_e0 = param_8;
      uStack_dc = param_9;
      puVar3 = auStack_f4;
      ppiVar4 = &piStack_d4;
      puVar6 = auStack_a0;
      piVar7 = (int *)auStack_cc;
    }
  }
  piStack_14 = piVar7;
  puStack_18 = puVar6;
  puStack_24 = (undefined *)ppiVar4;
  puStack_28 = (undefined *)puVar3;
  uStack_8._0_1_ = 6;
  FUN_009649e0(piStack_14);
  piStack_d0 = (int *)0xcad7d4;
  FUN_0095fd80();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  puStack_a4 = (undefined *)0xcad7de;
  (*pcStack_1c)();
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[1] + -1;
    piVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_a4 = (undefined *)0xcad7f1;
      (**(code **)*piVar1)();
      LOCK();
      piVar7 = piVar1 + 2;
      iVar2 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_a4 = (undefined *)0xcad800;
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 1;
  if (0xf < uStack_44) {
    puStack_a4 = (undefined *)(uStack_44 + 1);
    puStack_a8 = (undefined4 *)auStack_58[0];
    if (0xfff < puStack_a4) {
      puStack_a8 = *(undefined4 **)(auStack_58[0] - 4);
      puStack_a4 = (undefined *)(uStack_44 + 0x24);
      if (0x1f < (auStack_58[0] - (int)puStack_a8) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_a4 = &UNK_00cad8b3;
        FUN_017167a3();
      }
    }
    puStack_ac = (undefined4 *)0xcad835;
    FUN_01674ea0();
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      puStack_ac = &param_5;
      puStack_a4 = (undefined *)0x2;
      uStack_b0 = 0xcad86b;
      puStack_a8 = puStack_ac;
      (**(code **)(param_3 & 0xfffffffe))();
    }
    param_3 = 0;
  }
  uStack_8 = 9;
  if (((param_10 != (char *)0x0) && (((uint)param_10 & 1) == 0)) &&
     (*(code **)((uint)param_10 & 0xfffffffe) != (code *)0x0)) {
    puStack_ac = &param_12;
    puStack_a4 = (undefined *)0x2;
    uStack_b0 = 0xcad899;
    puStack_a8 = puStack_ac;
    (**(code **)((uint)param_10 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30234 ; VA 0x00cad8c0 ; FUN_00cad8c0 */

void FUN_00cad8c0(undefined4 param_1,int *param_2,uint param_3,undefined4 param_4,undefined4 param_5
                 ,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined8 param_9,
                 char *param_10,undefined4 param_11,undefined *param_12,undefined4 param_13,
                 undefined4 param_14,uint *param_15,undefined8 param_16)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  int **ppiVar4;
  char **ppcVar5;
  undefined *puVar6;
  int *piVar7;
  undefined4 *puVar8;
  uint auStack_f4 [2];
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined8 uStack_dc;
  int *piStack_d4;
  int *piStack_d0;
  undefined auStack_cc [28];
  undefined4 uStack_b0;
  undefined4 *puStack_ac;
  undefined4 *puStack_a8;
  undefined *puStack_a4;
  undefined auStack_a0 [16];
  undefined4 uStack_90;
  undefined4 *puStack_8c;
  undefined **ppuStack_88;
  uint *puStack_84;
  char *pcStack_80;
  undefined4 *puStack_7c;
  undefined *puStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  uint *puStack_6c;
  undefined8 uStack_68;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  undefined auStack_40 [4];
  int *piStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  undefined *puStack_28;
  undefined *puStack_24;
  undefined *puStack_20;
  code *pcStack_1c;
  undefined *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018117b8;
  pvStack_10 = ExceptionList;
  puStack_6c = auStack_58;
  uStack_8 = 1;
  uStack_68 = CONCAT44(param_2,param_1);
  uStack_70 = 0xcad8f5;
  ExceptionList = &pvStack_10;
  FUN_01091fa0();
  uStack_8._0_1_ = 2;
  param_2 = (int *)0xa;
  uStack_74 = 0xcad906;
  uStack_74 = FUN_008f7870();
  puStack_78 = auStack_40;
  puStack_7c = (undefined4 *)0xcad910;
  ppuStack_88 = (undefined **)FUN_005e5de0();
  puStack_7c = &param_2;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  pcStack_80 = "Groups";
  puStack_84 = auStack_58;
  puStack_8c = &uStack_38;
  uStack_90 = 0xcad92b;
  puVar8 = (undefined4 *)FUN_00b14d90();
  param_2 = (int *)*puVar8;
  piVar1 = (int *)puVar8[1];
  *puVar8 = 0;
  puVar8[1] = 0;
  piStack_14 = piStack_34;
  piStack_30 = param_2;
  piStack_2c = piVar1;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_34[1] + -1;
    piStack_34[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_68 = CONCAT44(0xcad963,(undefined4)uStack_68);
      (**(code **)*piStack_34)();
      LOCK();
      iVar2 = piStack_14[2] + -1;
      piStack_14[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_68 = CONCAT44(0xcad974,(undefined4)uStack_68);
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_3c[2] + -1;
    piStack_3c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_68 = CONCAT44(0xcad98d,(undefined4)uStack_68);
      (**(code **)(*piStack_3c + 4))();
    }
  }
  puStack_20 = (undefined *)&pcStack_80;
  puStack_18 = (undefined *)&pcStack_80;
  pcStack_1c = *(code **)(*param_2 + 0xa4);
  pcStack_80 = (char *)0x0;
  ppcVar5 = &pcStack_80;
  if (param_10 != (char *)0x0) {
    pcStack_80 = param_10;
    if (((uint)param_10 & 1) == 0) {
      ppuStack_88 = &puStack_78;
      puStack_84 = (uint *)0x0;
      puStack_8c = &param_12;
      uStack_90 = 0xcad9df;
      (**(code **)((uint)param_10 & 0xfffffffe))();
      ppcVar5 = (char **)puStack_20;
    }
    else {
      puStack_78 = param_12;
      uStack_74 = param_13;
      uStack_70 = param_14;
      puStack_6c = param_15;
      uStack_68 = param_16;
      ppcVar5 = &pcStack_80;
    }
  }
  puStack_20 = (undefined *)ppcVar5;
  puStack_18 = auStack_a0;
  puStack_a4 = (undefined *)0x0;
  piStack_14 = (int *)auStack_cc;
  puStack_24 = (undefined *)&piStack_d4;
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar1[1] = piVar1[1] + 1;
    UNLOCK();
  }
  puStack_28 = (undefined *)auStack_f4;
  uStack_8._0_1_ = 7;
  auStack_f4[0] = 0;
  piStack_d4 = param_2;
  piStack_d0 = piVar1;
  puVar3 = auStack_f4;
  ppiVar4 = &piStack_d4;
  puVar6 = auStack_a0;
  piVar7 = (int *)auStack_cc;
  if (param_3 != 0) {
    auStack_f4[0] = param_3;
    if ((param_3 & 1) == 0) {
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_ec,0);
      puVar3 = (uint *)puStack_28;
      ppiVar4 = (int **)puStack_24;
      puVar6 = puStack_18;
      piVar7 = piStack_14;
    }
    else {
      uStack_ec = param_5;
      uStack_e8 = param_6;
      uStack_e4 = param_7;
      uStack_e0 = param_8;
      uStack_dc = param_9;
      puVar3 = auStack_f4;
      ppiVar4 = &piStack_d4;
      puVar6 = auStack_a0;
      piVar7 = (int *)auStack_cc;
    }
  }
  piStack_14 = piVar7;
  puStack_18 = puVar6;
  puStack_24 = (undefined *)ppiVar4;
  puStack_28 = (undefined *)puVar3;
  uStack_8._0_1_ = 6;
  FUN_009649e0(piStack_14);
  piStack_d0 = (int *)0xcada74;
  FUN_0095fd80();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  puStack_a4 = (undefined *)0xcada7e;
  (*pcStack_1c)();
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[1] + -1;
    piVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_a4 = (undefined *)0xcada91;
      (**(code **)*piVar1)();
      LOCK();
      piVar7 = piVar1 + 2;
      iVar2 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_a4 = (undefined *)0xcadaa0;
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 1;
  if (0xf < uStack_44) {
    puStack_a4 = (undefined *)(uStack_44 + 1);
    puStack_a8 = (undefined4 *)auStack_58[0];
    if (0xfff < puStack_a4) {
      puStack_a8 = *(undefined4 **)(auStack_58[0] - 4);
      puStack_a4 = (undefined *)(uStack_44 + 0x24);
      if (0x1f < (auStack_58[0] - (int)puStack_a8) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_a4 = &UNK_00cadb53;
        FUN_017167a3();
      }
    }
    puStack_ac = (undefined4 *)0xcadad5;
    FUN_01674ea0();
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      puStack_ac = &param_5;
      puStack_a4 = (undefined *)0x2;
      uStack_b0 = 0xcadb0b;
      puStack_a8 = puStack_ac;
      (**(code **)(param_3 & 0xfffffffe))();
    }
    param_3 = 0;
  }
  uStack_8 = 9;
  if (((param_10 != (char *)0x0) && (((uint)param_10 & 1) == 0)) &&
     (*(code **)((uint)param_10 & 0xfffffffe) != (code *)0x0)) {
    puStack_ac = &param_12;
    puStack_a4 = (undefined *)0x2;
    uStack_b0 = 0xcadb39;
    puStack_a8 = puStack_ac;
    (**(code **)((uint)param_10 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30235 ; VA 0x00cadb60 ; FUN_00cadb60 */

void FUN_00cadb60(uint param_1,int param_2,uint param_3,undefined4 param_4,undefined4 param_5,
                 undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined8 param_9,
                 uint param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
                 undefined4 param_14,undefined4 *param_15,undefined8 param_16)

{
  int *piVar1;
  undefined4 **ppuVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  int *piVar7;
  uint uVar8;
  undefined8 uVar9;
  undefined auStack_24c [4];
  undefined4 uStack_248;
  undefined4 *puStack_244;
  undefined4 *puStack_240;
  undefined4 uStack_23c;
  undefined4 *puStack_238;
  undefined4 *puStack_234;
  undefined4 *puStack_230;
  undefined **ppuStack_22c;
  undefined4 uStack_228;
  undefined4 uStack_224;
  undefined4 uStack_220;
  undefined4 *puStack_21c;
  undefined8 uStack_218;
  undefined4 uStack_210;
  char *pcStack_20c;
  undefined4 uStack_208;
  undefined uStack_204;
  undefined4 uStack_200;
  undefined8 uStack_1fc;
  undefined4 *puStack_1f4;
  undefined4 uStack_1f0;
  undefined auStack_1e4 [72];
  undefined auStack_19c [72];
  undefined auStack_154 [72];
  undefined auStack_10c [72];
  undefined auStack_c4 [72];
  undefined4 uStack_7c;
  undefined4 uStack_78;
  uint uStack_74;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined8 uStack_5c;
  uint uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 *puStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  int iStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined4 *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018118f2;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if ((param_2 < 1) && ((param_2 < 0 || (param_1 == 0)))) {
    uStack_208 = 0x40;
    puStack_1f4 = (undefined4 *)0x0;
    uStack_1f0 = 0xf;
    pcStack_20c = "GroupService:GetGroupInfoAsync() argument is not a valid groupId";
    uStack_204 = 0;
    uStack_210 = 0xcadbba;
    ExceptionList = &pvStack_10;
    FUN_005542c0();
    uStack_208 = 0xcadbc2;
    FUN_005e65e0();
    goto LAB_00cae1b8;
  }
  puStack_1f4 = (undefined4 *)0xcadbcd;
  ExceptionList = &pvStack_10;
  iStack_24 = FUN_0064e700();
  if (iStack_24 == 0) goto LAB_00cae1b8;
  if (DAT_01d68c04 == '\0') {
LAB_00cadee9:
    puStack_20 = (undefined *)&pcStack_20c;
    puStack_18 = &pcStack_20c;
    uStack_210 = 0;
    uStack_218._0_4_ = 0xcadefa;
    uVar4 = FUN_008f7870();
    uStack_218 = CONCAT44(uStack_218._4_4_,uVar4);
    puStack_21c = &uStack_2c;
    uStack_220 = 0xcadf04;
    puVar5 = (undefined4 *)FUN_005e5de0();
    puStack_1c = (undefined *)&puStack_238;
    puStack_238 = (undefined4 *)*puVar5;
    puStack_234 = (undefined4 *)puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    puStack_230 = (undefined4 *)0x0;
    uStack_8._0_1_ = 0x12;
    ppuVar2 = &puStack_238;
    if (param_10 != 0) {
      puStack_230 = (undefined4 *)param_10;
      if ((param_10 & 1) == 0) {
        puStack_240 = &uStack_228;
        uStack_23c = 0;
        puStack_244 = &param_12;
        uStack_248 = 0xcadf71;
        (**(code **)(param_10 & 0xfffffffe))();
        ppuVar2 = (undefined4 **)puStack_1c;
      }
      else {
        uStack_228 = param_12;
        uStack_224 = param_13;
        uStack_220 = param_14;
        puStack_21c = param_15;
        uStack_218 = param_16;
        ppuVar2 = &puStack_238;
      }
    }
    puStack_1c = (undefined *)ppuVar2;
    uStack_8._0_1_ = 0x11;
    uStack_23c = 0xcadf80;
    FUN_00ca8a80();
    puStack_1c = (undefined *)&ppuStack_22c;
    uStack_8._0_1_ = 0x13;
    puStack_234 = (undefined4 *)0xcadf92;
    puStack_234 = (undefined4 *)FUN_008f7870();
    puStack_238 = &uStack_34;
    uStack_23c = 0xcadf9c;
    puVar5 = (undefined4 *)FUN_005e5de0();
    puStack_18 = &uStack_7c;
    uStack_7c = *puVar5;
    uStack_78 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    uStack_8._0_1_ = 0x15;
    uStack_74 = 0;
    if (param_3 != 0) {
      uStack_74 = param_3;
      if ((param_3 & 1) == 0) {
        puStack_234 = &uStack_6c;
        puStack_230 = (undefined4 *)0x0;
        puStack_238 = &param_5;
        uStack_23c = 0xcae009;
        (**(code **)(param_3 & 0xfffffffe))();
      }
      else {
        uStack_6c = param_5;
        uStack_68 = param_6;
        uStack_64 = param_7;
        uStack_60 = param_8;
        uStack_5c = param_9;
      }
    }
    uStack_8._0_1_ = 0x16;
    uStack_54 = 0;
    if (param_10 != 0) {
      uStack_54 = param_10;
      if ((param_10 & 1) == 0) {
        puStack_234 = &uStack_4c;
        puStack_230 = (undefined4 *)0x0;
        puStack_238 = &param_12;
        uStack_23c = 0xcae04a;
        (**(code **)(param_10 & 0xfffffffe))();
      }
      else {
        uStack_4c = param_12;
        uStack_48 = param_13;
        uStack_44 = param_14;
        puStack_40 = param_15;
        uStack_3c = param_16;
      }
    }
    puStack_230 = &uStack_7c;
    uStack_8._0_1_ = 0x17;
    puStack_234 = (undefined4 *)0xcae060;
    FUN_00cab5c0();
    puStack_230 = (undefined4 *)auStack_10c;
    uStack_8._0_1_ = 0x18;
    ppuStack_22c = (undefined **)0x0;
    puStack_234 = (undefined4 *)0xcae07c;
    FUN_00cab5c0();
    puStack_230 = (undefined4 *)auStack_154;
    uStack_8._0_1_ = 0x19;
    puStack_234 = (undefined4 *)0xcae092;
    FUN_00cab5c0();
    puStack_230 = (undefined4 *)auStack_19c;
    uStack_8._0_1_ = 0x1a;
    puStack_234 = (undefined4 *)0xcae0a8;
    FUN_00cab5c0();
    puStack_230 = (undefined4 *)auStack_c4;
    uStack_8._0_1_ = 0x1b;
    puStack_234 = (undefined4 *)0xcae0b8;
    cVar3 = FUN_00585a40();
    if (cVar3 == '\0') {
      puStack_230 = (undefined4 *)auStack_c4;
      puStack_234 = (undefined4 *)0xcae0d1;
      FUN_00cab5c0();
      puStack_230 = (undefined4 *)0x48;
      uStack_8._0_1_ = 0x1c;
      puStack_234 = (undefined4 *)0xcae0dc;
      puStack_18 = (undefined4 *)FUN_01674e20();
      uStack_8._0_1_ = 0x1d;
      if (puStack_18 == (undefined4 *)0x0) {
        uStack_224 = 0;
      }
      else {
        puStack_230 = (undefined4 *)auStack_1e4;
        puStack_234 = (undefined4 *)0xcae0f8;
        uStack_224 = FUN_00cab5c0();
      }
      puStack_230 = (undefined4 *)0xcae10a;
      FUN_008e9ba0();
      puStack_230 = (undefined4 *)0xcae115;
      FUN_008e9ba0();
      cStack_11 = '\x01';
    }
    else {
      puStack_230 = (undefined4 *)0xcae126;
      FUN_008e9ba0();
      cStack_11 = '\0';
    }
    puStack_230 = (undefined4 *)0xcae135;
    FUN_008e9ba0();
    ppuStack_22c = &PTR_FUN_01975638;
    if (cStack_11 == '\0') {
      ppuStack_22c = (undefined **)0x0;
    }
    puStack_230 = (undefined4 *)0xcae14f;
    FUN_008e9ba0();
    puStack_230 = (undefined4 *)0xcae15a;
    FUN_008e9ba0();
    puStack_230 = (undefined4 *)0xcae162;
    FUN_008e9ba0();
    puStack_230 = (undefined4 *)0xa;
    puStack_234 = (undefined4 *)0x0;
    uStack_8._0_1_ = 0x1e;
    FUN_01093490(auStack_24c,param_1,param_2);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x1f);
    FUN_00bcb3b0();
    piVar7 = piStack_28;
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_30[2] + -1;
      piStack_30[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        uStack_1f0 = 0xcae1a4;
        (**(code **)(*piStack_30 + 4))();
        piVar7 = piStack_28;
      }
    }
  }
  else {
    uStack_1f0 = 0;
    puStack_1f4 = (undefined4 *)0x64;
    uStack_1fc._4_4_ = (undefined4 *)param_2;
    uStack_1fc._0_4_ = param_1;
    uStack_200 = 0xcadbf6;
    uStack_1fc = FUN_016f3900();
    uStack_1f0 = 0;
    puStack_1f4 = (undefined4 *)0x64;
    uStack_200 = 0xcadc01;
    uVar9 = FUN_016f39b0();
    uVar8 = param_1 - (uint)uVar9;
    iVar6 = ((param_2 - (int)((ulonglong)uVar9 >> 0x20)) - (uint)(param_1 < (uint)uVar9)) +
            (uint)(0xfffffffe < uVar8);
    if (((int)DAT_01d68bf8 >> 0x1f < iVar6) ||
       (((int)DAT_01d68bf8 >> 0x1f <= iVar6 && (DAT_01d68bf8 < uVar8 + 1)))) goto LAB_00cadee9;
    puStack_1c = (undefined *)&pcStack_20c;
    puStack_18 = &pcStack_20c;
    uStack_210 = 0;
    uStack_218._0_4_ = 0xcadc37;
    uVar4 = FUN_008f7870();
    uStack_218 = CONCAT44(uStack_218._4_4_,uVar4);
    puStack_21c = &uStack_34;
    uStack_220 = 0xcadc41;
    puVar5 = (undefined4 *)FUN_005e5de0();
    puStack_20 = (undefined *)&puStack_238;
    puStack_238 = (undefined4 *)*puVar5;
    puStack_234 = (undefined4 *)puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    puStack_230 = (undefined4 *)0x0;
    uStack_8._0_1_ = 3;
    ppuVar2 = &puStack_238;
    if (param_10 != 0) {
      puStack_230 = (undefined4 *)param_10;
      if ((param_10 & 1) == 0) {
        puStack_240 = &uStack_228;
        uStack_23c = 0;
        puStack_244 = &param_12;
        uStack_248 = 0xcadcae;
        (**(code **)(param_10 & 0xfffffffe))();
        ppuVar2 = (undefined4 **)puStack_20;
      }
      else {
        uStack_228 = param_12;
        uStack_224 = param_13;
        uStack_220 = param_14;
        puStack_21c = param_15;
        uStack_218 = param_16;
        ppuVar2 = &puStack_238;
      }
    }
    puStack_20 = (undefined *)ppuVar2;
    uStack_8._0_1_ = 2;
    uStack_23c = 0xcadcbd;
    FUN_00ca8e80();
    puStack_20 = (undefined *)&ppuStack_22c;
    uStack_8._0_1_ = 4;
    puStack_234 = (undefined4 *)0xcadccf;
    puStack_234 = (undefined4 *)FUN_008f7870();
    puStack_238 = &uStack_2c;
    uStack_23c = 0xcadcd9;
    puVar5 = (undefined4 *)FUN_005e5de0();
    puStack_18 = &uStack_7c;
    uStack_7c = *puVar5;
    uStack_78 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    uStack_8._0_1_ = 6;
    uStack_74 = 0;
    if (param_3 != 0) {
      uStack_74 = param_3;
      if ((param_3 & 1) == 0) {
        puStack_234 = &uStack_6c;
        puStack_230 = (undefined4 *)0x0;
        puStack_238 = &param_5;
        uStack_23c = 0xcadd46;
        (**(code **)(param_3 & 0xfffffffe))();
      }
      else {
        uStack_6c = param_5;
        uStack_68 = param_6;
        uStack_64 = param_7;
        uStack_60 = param_8;
        uStack_5c = param_9;
      }
    }
    uStack_8._0_1_ = 7;
    uStack_54 = 0;
    if (param_10 != 0) {
      uStack_54 = param_10;
      if ((param_10 & 1) == 0) {
        puStack_234 = &uStack_4c;
        puStack_230 = (undefined4 *)0x0;
        puStack_238 = &param_12;
        uStack_23c = 0xcadd87;
        (**(code **)(param_10 & 0xfffffffe))();
      }
      else {
        uStack_4c = param_12;
        uStack_48 = param_13;
        uStack_44 = param_14;
        puStack_40 = param_15;
        uStack_3c = param_16;
      }
    }
    puStack_230 = &uStack_7c;
    uStack_8._0_1_ = 8;
    puStack_234 = (undefined4 *)0xcadd9d;
    FUN_00cab5c0();
    puStack_230 = (undefined4 *)auStack_1e4;
    uStack_8._0_1_ = 9;
    ppuStack_22c = (undefined **)0x0;
    puStack_234 = (undefined4 *)0xcaddb9;
    FUN_00cab5c0();
    puStack_230 = (undefined4 *)auStack_19c;
    uStack_8._0_1_ = 10;
    puStack_234 = (undefined4 *)0xcaddcf;
    FUN_00cab5c0();
    puStack_230 = (undefined4 *)auStack_154;
    uStack_8._0_1_ = 0xb;
    puStack_234 = (undefined4 *)0xcadde5;
    FUN_00cab5c0();
    puStack_230 = (undefined4 *)auStack_c4;
    uStack_8._0_1_ = 0xc;
    puStack_234 = (undefined4 *)0xcaddf5;
    cVar3 = FUN_00585a40();
    if (cVar3 == '\0') {
      puStack_230 = (undefined4 *)auStack_c4;
      puStack_234 = (undefined4 *)0xcade0e;
      FUN_00cab5c0();
      puStack_230 = (undefined4 *)0x48;
      uStack_8._0_1_ = 0xd;
      puStack_234 = (undefined4 *)0xcade19;
      puStack_18 = (undefined4 *)FUN_01674e20();
      uStack_8._0_1_ = 0xe;
      if (puStack_18 == (undefined4 *)0x0) {
        uStack_224 = 0;
      }
      else {
        puStack_230 = (undefined4 *)auStack_10c;
        puStack_234 = (undefined4 *)0xcade35;
        uStack_224 = FUN_00cab5c0();
      }
      puStack_230 = (undefined4 *)0xcade47;
      FUN_008e9ba0();
      puStack_230 = (undefined4 *)0xcade52;
      FUN_008e9ba0();
      cStack_11 = '\x01';
    }
    else {
      puStack_230 = (undefined4 *)0xcade63;
      FUN_008e9ba0();
      cStack_11 = '\0';
    }
    puStack_230 = (undefined4 *)0xcade72;
    FUN_008e9ba0();
    ppuStack_22c = &PTR_FUN_01975628;
    if (cStack_11 == '\0') {
      ppuStack_22c = (undefined **)0x0;
    }
    puStack_230 = (undefined4 *)0xcade8c;
    FUN_008e9ba0();
    puStack_230 = (undefined4 *)0xcade97;
    FUN_008e9ba0();
    puStack_230 = (undefined4 *)0xcade9f;
    FUN_008e9ba0();
    puStack_230 = (undefined4 *)0xa;
    puStack_234 = (undefined4 *)0x0;
    uStack_8._0_1_ = 0xf;
    FUN_01092ff0(auStack_24c,param_1,param_2);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
    FUN_00bcb620();
    piVar7 = piStack_30;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_28[2] + -1;
      piStack_28[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        uStack_1f0 = 0xcadee1;
        (**(code **)(*piStack_28 + 4))();
        piVar7 = piStack_30;
      }
    }
  }
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar1 = piVar7 + 2;
    iVar6 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar6 == 1) {
      uStack_1f0 = 0xcae1b8;
      (**(code **)(*piVar7 + 4))();
    }
  }
LAB_00cae1b8:
  uStack_8 = CONCAT31(uStack_8._1_3_,0x20);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    uStack_1fc._4_4_ = &param_5;
    uStack_1f0 = 2;
    uStack_1fc._0_4_ = 0xcae1d9;
    puStack_1f4 = uStack_1fc._4_4_;
    (**(code **)(param_3 & 0xfffffffe))();
  }
  uStack_8 = 0x21;
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    uStack_1fc._4_4_ = &param_12;
    uStack_1f0 = 2;
    uStack_1fc._0_4_ = 0xcae207;
    puStack_1f4 = uStack_1fc._4_4_;
    (**(code **)(param_10 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30236 ; VA 0x00cae220 ; FUN_00cae220 */

void FUN_00cae220(uint param_1,int param_2,uint param_3,undefined4 param_4,undefined4 param_5,
                 undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined8 param_9,
                 uint param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
                 undefined4 param_14,undefined4 *param_15,undefined8 param_16)

{
  int *piVar1;
  undefined4 **ppuVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  int *piVar7;
  uint uVar8;
  undefined8 uVar9;
  undefined auStack_250 [4];
  undefined4 uStack_24c;
  undefined4 *puStack_248;
  undefined4 *puStack_244;
  undefined4 uStack_240;
  undefined4 *puStack_23c;
  undefined4 *puStack_238;
  undefined4 *puStack_234;
  undefined **ppuStack_230;
  undefined4 uStack_22c;
  undefined4 uStack_228;
  undefined4 uStack_224;
  undefined4 *puStack_220;
  undefined8 uStack_21c;
  undefined4 uStack_214;
  undefined auStack_210 [12];
  undefined4 uStack_204;
  undefined8 uStack_200;
  undefined4 *puStack_1f8;
  undefined4 uStack_1f4;
  undefined auStack_1e8 [72];
  undefined auStack_1a0 [72];
  undefined auStack_158 [72];
  undefined auStack_110 [72];
  undefined auStack_c8 [72];
  undefined4 uStack_80;
  undefined4 uStack_7c;
  uint uStack_78;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined8 uStack_60;
  uint uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 *puStack_44;
  undefined8 uStack_40;
  undefined4 uStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  undefined *puStack_24;
  int iStack_20;
  undefined *puStack_1c;
  undefined4 *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01811a2a;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if ((param_2 < 1) && ((param_2 < 0 || (param_1 == 0)))) {
    uStack_28 = 0;
    puStack_24 = (undefined *)0x0;
    uStack_8 = 2;
    puStack_1f8 = (undefined4 *)0x0;
    uStack_1f4 = 0;
    uStack_200._4_4_ = (undefined4 *)0xcae284;
    ExceptionList = &pvStack_10;
    FUN_00bef900();
    goto LAB_00cae87a;
  }
  puStack_1f8 = (undefined4 *)0xcae28f;
  ExceptionList = &pvStack_10;
  iStack_20 = FUN_0064e700();
  if (iStack_20 == 0) goto LAB_00cae87a;
  if (DAT_01d68c04 == '\0') {
LAB_00cae5ab:
    puStack_24 = auStack_210;
    puStack_18 = (undefined4 *)auStack_210;
    uStack_214 = 0;
    uStack_21c._0_4_ = 0xcae5bc;
    uVar4 = FUN_008f7870();
    uStack_21c = CONCAT44(uStack_21c._4_4_,uVar4);
    puStack_220 = &uStack_30;
    uStack_224 = 0xcae5c6;
    puVar5 = (undefined4 *)FUN_005e5de0();
    puStack_1c = (undefined *)&puStack_23c;
    puStack_23c = (undefined4 *)*puVar5;
    puStack_238 = (undefined4 *)puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    puStack_234 = (undefined4 *)0x0;
    uStack_8._0_1_ = 0x13;
    ppuVar2 = &puStack_23c;
    if (param_10 != 0) {
      puStack_234 = (undefined4 *)param_10;
      if ((param_10 & 1) == 0) {
        puStack_244 = &uStack_22c;
        uStack_240 = 0;
        puStack_248 = &param_12;
        uStack_24c = 0xcae633;
        (**(code **)(param_10 & 0xfffffffe))();
        ppuVar2 = (undefined4 **)puStack_1c;
      }
      else {
        uStack_22c = param_12;
        uStack_228 = param_13;
        uStack_224 = param_14;
        puStack_220 = param_15;
        uStack_21c = param_16;
        ppuVar2 = &puStack_23c;
      }
    }
    puStack_1c = (undefined *)ppuVar2;
    uStack_8._0_1_ = 0x12;
    uStack_240 = 0xcae642;
    FUN_00ca8d30();
    puStack_1c = (undefined *)&ppuStack_230;
    uStack_8._0_1_ = 0x14;
    puStack_238 = (undefined4 *)0xcae654;
    puStack_238 = (undefined4 *)FUN_008f7870();
    puStack_23c = &uStack_38;
    uStack_240 = 0xcae65e;
    puVar5 = (undefined4 *)FUN_005e5de0();
    puStack_18 = &uStack_80;
    uStack_80 = *puVar5;
    uStack_7c = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    uStack_8._0_1_ = 0x16;
    uStack_78 = 0;
    if (param_3 != 0) {
      uStack_78 = param_3;
      if ((param_3 & 1) == 0) {
        puStack_238 = &uStack_70;
        puStack_234 = (undefined4 *)0x0;
        puStack_23c = &param_5;
        uStack_240 = 0xcae6cb;
        (**(code **)(param_3 & 0xfffffffe))();
      }
      else {
        uStack_70 = param_5;
        uStack_6c = param_6;
        uStack_68 = param_7;
        uStack_64 = param_8;
        uStack_60 = param_9;
      }
    }
    uStack_8._0_1_ = 0x17;
    uStack_58 = 0;
    if (param_10 != 0) {
      uStack_58 = param_10;
      if ((param_10 & 1) == 0) {
        puStack_238 = &uStack_50;
        puStack_234 = (undefined4 *)0x0;
        puStack_23c = &param_12;
        uStack_240 = 0xcae70c;
        (**(code **)(param_10 & 0xfffffffe))();
      }
      else {
        uStack_50 = param_12;
        uStack_4c = param_13;
        uStack_48 = param_14;
        puStack_44 = param_15;
        uStack_40 = param_16;
      }
    }
    puStack_234 = &uStack_80;
    uStack_8._0_1_ = 0x18;
    puStack_238 = (undefined4 *)0xcae722;
    FUN_00cab4c0();
    puStack_234 = (undefined4 *)auStack_110;
    uStack_8._0_1_ = 0x19;
    ppuStack_230 = (undefined **)0x0;
    puStack_238 = (undefined4 *)0xcae73e;
    FUN_00cab4c0();
    puStack_234 = (undefined4 *)auStack_158;
    uStack_8._0_1_ = 0x1a;
    puStack_238 = (undefined4 *)0xcae754;
    FUN_00cab4c0();
    puStack_234 = (undefined4 *)auStack_1a0;
    uStack_8._0_1_ = 0x1b;
    puStack_238 = (undefined4 *)0xcae76a;
    FUN_00cab4c0();
    puStack_234 = (undefined4 *)auStack_c8;
    uStack_8._0_1_ = 0x1c;
    puStack_238 = (undefined4 *)0xcae77a;
    cVar3 = FUN_00585a40();
    if (cVar3 == '\0') {
      puStack_234 = (undefined4 *)auStack_c8;
      puStack_238 = (undefined4 *)0xcae793;
      FUN_00cab4c0();
      puStack_234 = (undefined4 *)0x48;
      uStack_8._0_1_ = 0x1d;
      puStack_238 = (undefined4 *)0xcae79e;
      puStack_18 = (undefined4 *)FUN_01674e20();
      uStack_8._0_1_ = 0x1e;
      if (puStack_18 == (undefined4 *)0x0) {
        uStack_228 = 0;
      }
      else {
        puStack_234 = (undefined4 *)auStack_1e8;
        puStack_238 = (undefined4 *)0xcae7ba;
        uStack_228 = FUN_00cab4c0();
      }
      puStack_234 = (undefined4 *)0xcae7cc;
      FUN_008e9ba0();
      puStack_234 = (undefined4 *)0xcae7d7;
      FUN_008e9ba0();
      cStack_11 = '\x01';
    }
    else {
      puStack_234 = (undefined4 *)0xcae7e8;
      FUN_008e9ba0();
      cStack_11 = '\0';
    }
    puStack_234 = (undefined4 *)0xcae7f7;
    FUN_008e9ba0();
    ppuStack_230 = &PTR_FUN_01975658;
    if (cStack_11 == '\0') {
      ppuStack_230 = (undefined **)0x0;
    }
    puStack_234 = (undefined4 *)0xcae811;
    FUN_008e9ba0();
    puStack_234 = (undefined4 *)0xcae81c;
    FUN_008e9ba0();
    puStack_234 = (undefined4 *)0xcae824;
    FUN_008e9ba0();
    puStack_234 = (undefined4 *)0xa;
    puStack_238 = (undefined4 *)0x0;
    uStack_8._0_1_ = 0x1f;
    FUN_01092c20(auStack_250,param_1,param_2);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x20);
    FUN_00bcb3b0();
    piVar7 = piStack_2c;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_34[2] + -1;
      piStack_34[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        uStack_1f4 = 0xcae866;
        (**(code **)(*piStack_34 + 4))();
        piVar7 = piStack_2c;
      }
    }
  }
  else {
    uStack_1f4 = 0;
    puStack_1f8 = (undefined4 *)0x64;
    uStack_200._4_4_ = (undefined4 *)param_2;
    uStack_200._0_4_ = param_1;
    uStack_204 = 0xcae2b8;
    uStack_200 = FUN_016f3900();
    uStack_1f4 = 0;
    puStack_1f8 = (undefined4 *)0x64;
    uStack_204 = 0xcae2c3;
    uVar9 = FUN_016f39b0();
    uVar8 = param_1 - (uint)uVar9;
    iVar6 = ((param_2 - (int)((ulonglong)uVar9 >> 0x20)) - (uint)(param_1 < (uint)uVar9)) +
            (uint)(0xfffffffe < uVar8);
    if (((int)DAT_01d68bf8 >> 0x1f < iVar6) ||
       (((int)DAT_01d68bf8 >> 0x1f <= iVar6 && (DAT_01d68bf8 < uVar8 + 1)))) goto LAB_00cae5ab;
    puStack_1c = auStack_210;
    puStack_18 = (undefined4 *)auStack_210;
    uStack_214 = 0;
    uStack_21c._0_4_ = 0xcae2f9;
    uVar4 = FUN_008f7870();
    uStack_21c = CONCAT44(uStack_21c._4_4_,uVar4);
    puStack_220 = &uStack_38;
    uStack_224 = 0xcae303;
    puVar5 = (undefined4 *)FUN_005e5de0();
    puStack_24 = (undefined *)&puStack_23c;
    puStack_23c = (undefined4 *)*puVar5;
    puStack_238 = (undefined4 *)puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    puStack_234 = (undefined4 *)0x0;
    uStack_8._0_1_ = 4;
    ppuVar2 = &puStack_23c;
    if (param_10 != 0) {
      puStack_234 = (undefined4 *)param_10;
      if ((param_10 & 1) == 0) {
        puStack_244 = &uStack_22c;
        uStack_240 = 0;
        puStack_248 = &param_12;
        uStack_24c = 0xcae370;
        (**(code **)(param_10 & 0xfffffffe))();
        ppuVar2 = (undefined4 **)puStack_24;
      }
      else {
        uStack_22c = param_12;
        uStack_228 = param_13;
        uStack_224 = param_14;
        puStack_220 = param_15;
        uStack_21c = param_16;
        ppuVar2 = &puStack_23c;
      }
    }
    puStack_24 = (undefined *)ppuVar2;
    uStack_8._0_1_ = 3;
    uStack_240 = 0xcae37f;
    FUN_00ca8fd0();
    puStack_24 = (undefined *)&ppuStack_230;
    uStack_8._0_1_ = 5;
    puStack_238 = (undefined4 *)0xcae391;
    puStack_238 = (undefined4 *)FUN_008f7870();
    puStack_23c = &uStack_30;
    uStack_240 = 0xcae39b;
    puVar5 = (undefined4 *)FUN_005e5de0();
    puStack_18 = &uStack_80;
    uStack_80 = *puVar5;
    uStack_7c = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    uStack_8._0_1_ = 7;
    uStack_78 = 0;
    if (param_3 != 0) {
      uStack_78 = param_3;
      if ((param_3 & 1) == 0) {
        puStack_238 = &uStack_70;
        puStack_234 = (undefined4 *)0x0;
        puStack_23c = &param_5;
        uStack_240 = 0xcae408;
        (**(code **)(param_3 & 0xfffffffe))();
      }
      else {
        uStack_70 = param_5;
        uStack_6c = param_6;
        uStack_68 = param_7;
        uStack_64 = param_8;
        uStack_60 = param_9;
      }
    }
    uStack_8._0_1_ = 8;
    uStack_58 = 0;
    if (param_10 != 0) {
      uStack_58 = param_10;
      if ((param_10 & 1) == 0) {
        puStack_238 = &uStack_50;
        puStack_234 = (undefined4 *)0x0;
        puStack_23c = &param_12;
        uStack_240 = 0xcae449;
        (**(code **)(param_10 & 0xfffffffe))();
      }
      else {
        uStack_50 = param_12;
        uStack_4c = param_13;
        uStack_48 = param_14;
        puStack_44 = param_15;
        uStack_40 = param_16;
      }
    }
    puStack_234 = &uStack_80;
    uStack_8._0_1_ = 9;
    puStack_238 = (undefined4 *)0xcae45f;
    FUN_00cab4c0();
    puStack_234 = (undefined4 *)auStack_1e8;
    uStack_8._0_1_ = 10;
    ppuStack_230 = (undefined **)0x0;
    puStack_238 = (undefined4 *)0xcae47b;
    FUN_00cab4c0();
    puStack_234 = (undefined4 *)auStack_1a0;
    uStack_8._0_1_ = 0xb;
    puStack_238 = (undefined4 *)0xcae491;
    FUN_00cab4c0();
    puStack_234 = (undefined4 *)auStack_158;
    uStack_8._0_1_ = 0xc;
    puStack_238 = (undefined4 *)0xcae4a7;
    FUN_00cab4c0();
    puStack_234 = (undefined4 *)auStack_c8;
    uStack_8._0_1_ = 0xd;
    puStack_238 = (undefined4 *)0xcae4b7;
    cVar3 = FUN_00585a40();
    if (cVar3 == '\0') {
      puStack_234 = (undefined4 *)auStack_c8;
      puStack_238 = (undefined4 *)0xcae4d0;
      FUN_00cab4c0();
      puStack_234 = (undefined4 *)0x48;
      uStack_8._0_1_ = 0xe;
      puStack_238 = (undefined4 *)0xcae4db;
      puStack_18 = (undefined4 *)FUN_01674e20();
      uStack_8._0_1_ = 0xf;
      if (puStack_18 == (undefined4 *)0x0) {
        uStack_228 = 0;
      }
      else {
        puStack_234 = (undefined4 *)auStack_110;
        puStack_238 = (undefined4 *)0xcae4f7;
        uStack_228 = FUN_00cab4c0();
      }
      puStack_234 = (undefined4 *)0xcae509;
      FUN_008e9ba0();
      puStack_234 = (undefined4 *)0xcae514;
      FUN_008e9ba0();
      cStack_11 = '\x01';
    }
    else {
      puStack_234 = (undefined4 *)0xcae525;
      FUN_008e9ba0();
      cStack_11 = '\0';
    }
    puStack_234 = (undefined4 *)0xcae534;
    FUN_008e9ba0();
    ppuStack_230 = &PTR_FUN_01975648;
    if (cStack_11 == '\0') {
      ppuStack_230 = (undefined **)0x0;
    }
    puStack_234 = (undefined4 *)0xcae54e;
    FUN_008e9ba0();
    puStack_234 = (undefined4 *)0xcae559;
    FUN_008e9ba0();
    puStack_234 = (undefined4 *)0xcae561;
    FUN_008e9ba0();
    puStack_234 = (undefined4 *)0xa;
    puStack_238 = (undefined4 *)0x0;
    uStack_8._0_1_ = 0x10;
    FUN_01092980(auStack_250,param_1,param_2);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
    FUN_00bcb620();
    piVar7 = piStack_34;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar6 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        uStack_1f4 = 0xcae5a3;
        (**(code **)(*piStack_2c + 4))();
        piVar7 = piStack_34;
      }
    }
  }
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar1 = piVar7 + 2;
    iVar6 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar6 == 1) {
      uStack_1f4 = 0xcae87a;
      (**(code **)(*piVar7 + 4))();
    }
  }
LAB_00cae87a:
  uStack_8 = CONCAT31(uStack_8._1_3_,0x21);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    uStack_200._4_4_ = &param_5;
    uStack_1f4 = 2;
    uStack_200._0_4_ = 0xcae89b;
    puStack_1f8 = uStack_200._4_4_;
    (**(code **)(param_3 & 0xfffffffe))();
  }
  uStack_8 = 0x22;
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    uStack_200._4_4_ = &param_12;
    uStack_1f4 = 2;
    uStack_200._0_4_ = 0xcae8c9;
    puStack_1f8 = uStack_200._4_4_;
    (**(code **)(param_10 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30237 ; VA 0x00cae8e0 ; FUN_00cae8e0 */

int FUN_00cae8e0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  undefined4 *puVar5;
  int iVar6;
  double *pdVar7;
  undefined4 uVar8;
  int *in_stack_00000030;
  undefined4 auStack_10c [3];
  undefined4 uStack_100;
  undefined4 uStack_fc;
  int *piStack_f8;
  undefined4 *puStack_f4;
  int iStack_f0;
  undefined4 auStack_ec [3];
  undefined4 uStack_e0;
  undefined4 *puStack_dc;
  double *pdStack_d8;
  double *pdStack_d4;
  undefined4 *puStack_d0;
  double adStack_c0 [3];
  undefined auStack_a8 [4];
  undefined uStack_a4;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined auStack_74 [4];
  int *piStack_70;
  undefined auStack_6c [16];
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined *puStack_50;
  undefined auStack_4c [4];
  int *piStack_48;
  double dStack_44;
  undefined4 uStack_3c;
  int *piStack_38;
  int iStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01811ab0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if ((param_2 < 1) && (param_2 < 0)) {
    puStack_d0 = (undefined4 *)0xb;
    uStack_94 = 0;
    uStack_90 = 0xf;
    uStack_a4 = 0;
    uStack_8c = 0;
    pdStack_d4 = (double *)0xcae94c;
    ExceptionList = &pvStack_10;
    uStack_88 = FUN_00588320();
    uStack_84 = 0;
    uStack_80 = 0x3f800000;
    uStack_7c = 0;
    uStack_78 = 0;
    pdStack_d4 = (double *)0x40;
    uStack_8._0_1_ = 1;
    auStack_a8[0] = 1;
    pdStack_d8 = (double *)0xcae980;
    puVar5 = (undefined4 *)FUN_01674e20();
    uStack_8._0_1_ = 2;
    puStack_1c = puVar5;
    if (puVar5 == (undefined4 *)0x0) {
      puStack_d0 = (undefined4 *)0x0;
    }
    else {
      puStack_d0 = (undefined4 *)auStack_a8;
      puVar5[1] = 1;
      puVar5[2] = 1;
      *puVar5 = std::_Ref_count_obj<struct_RBX::GroupService::GroupRolesResult>::vftable;
      pdStack_d4 = (double *)0xcae9b3;
      FUN_00cab960();
      puStack_d0 = puVar5;
    }
    pdStack_d4 = (double *)(puStack_d0 + 3);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    uStack_54 = 0;
    puStack_50 = (undefined *)0x0;
    pdStack_d8 = (double *)0xcae9de;
    FUN_00cac270();
    puStack_d0 = (undefined4 *)0xcae9e9;
    iVar6 = FUN_00cabe90();
    goto LAB_00caed45;
  }
  uStack_3c = 0;
  dStack_44 = 0.0;
  piStack_38 = (int *)0x0;
  iStack_34 = 0;
  iStack_30 = 0;
  uStack_2c = 0;
  puStack_d0 = (undefined4 *)0x1;
  pdStack_d4 = &dStack_44;
  uStack_8 = 4;
  pdStack_d8 = (double *)&param_1;
  puStack_dc = (undefined4 *)0xcaea2f;
  ExceptionList = &pvStack_10;
  cVar4 = FUN_00cad4d0();
  if (cVar4 == '\0') {
LAB_00caeaa9:
    puStack_d0 = (undefined4 *)auStack_4c;
    pdStack_d4 = (double *)0xcaeab2;
    pdVar7 = (double *)FUN_01682800();
    dStack_44 = (double)DAT_01d68be8 + *pdVar7;
    puStack_d0 = (undefined4 *)&stack0x0000000c;
    pdStack_d4 = (double *)0xcaead6;
    FUN_00cb1530();
    puStack_d0 = (undefined4 *)0x0;
    pdStack_d4 = (double *)DAT_01d68be0;
    pdStack_d8 = &dStack_44;
    puStack_dc = &param_1;
    uStack_e0 = 0xcaeaee;
    FUN_00cb1730();
    pdStack_d4 = (double *)0xcaeaf4;
    puStack_1c = (undefined4 *)FUN_0064e700();
    if (puStack_1c != (undefined4 *)0x0) {
      uStack_5c = 0;
      uStack_58 = 0xf;
      auStack_6c[0] = 0;
      puStack_d0 = (undefined4 *)param_2;
      pdStack_d4 = (double *)param_1;
      pdStack_d8 = adStack_c0;
      uStack_8._0_1_ = 5;
      if (DAT_01f0265c < DAT_01f02674) {
        puStack_dc = (undefined4 *)0xcaeb3a;
        puVar5 = (undefined4 *)FUN_010926e0();
        uStack_8 = CONCAT31(uStack_8._1_3_,6);
      }
      else {
        puStack_dc = (undefined4 *)0xcaeb48;
        puVar5 = (undefined4 *)FUN_01092440();
        uStack_8 = CONCAT31(uStack_8._1_3_,7);
      }
      if ((undefined4 *)auStack_6c != puVar5) {
        puStack_d0 = (undefined4 *)puVar5[4];
        if (0xf < (uint)puVar5[5]) {
          puVar5 = (undefined4 *)*puVar5;
        }
        pdStack_d8 = (double *)0xcaeb6b;
        pdStack_d4 = (double *)puVar5;
        FUN_005542c0();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      puStack_d0 = (undefined4 *)0xcaeb7a;
      FUN_005507b0();
      puStack_50 = (undefined *)auStack_ec;
      puStack_20 = auStack_ec;
      puStack_f4 = (undefined4 *)0xcaeb89;
      puStack_f4 = (undefined4 *)FUN_008f7870();
      piStack_f8 = (int *)auStack_4c;
      uStack_fc = 0xcaeb93;
      puVar5 = (undefined4 *)FUN_005e5de0();
      piVar3 = (int *)puVar5[1];
      uStack_fc = *puVar5;
      *puVar5 = 0;
      puVar5[1] = 0;
      piVar1 = piVar3 + 2;
      puStack_24 = param_1;
      puStack_14 = (undefined4 *)param_2;
      if (piVar3 != (int *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      *puStack_20 = 0;
      if (piVar3 != (int *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      puStack_f4 = puStack_24;
      iStack_f0 = (int)puStack_14;
      uStack_100 = 0xcaebf6;
      piStack_f8 = piVar3;
      FUN_00caa460();
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar6 = *piVar1;
        *piVar1 = iVar6 + -1;
        UNLOCK();
        if (iVar6 + -1 == 0) {
          iStack_f0 = 0xcaec09;
          (**(code **)(*piVar3 + 4))();
        }
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar6 = *piVar1;
          *piVar1 = iVar6 + -1;
          UNLOCK();
          if (iVar6 + -1 == 0) {
            iStack_f0 = 0xcaec1c;
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      puStack_20 = auStack_10c;
      puStack_14 = auStack_10c;
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
      uVar8 = FUN_008f7870(puStack_18);
      puVar5 = (undefined4 *)FUN_005e5de0(auStack_74,uVar8);
      piVar3 = (int *)puVar5[1];
      uVar8 = *puVar5;
      *puVar5 = 0;
      puVar5[1] = 0;
      piVar1 = piVar3 + 2;
      puStack_18 = param_1;
      puStack_24 = (undefined4 *)param_2;
      if (piVar3 != (int *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      *puStack_14 = 0;
      if (piVar3 != (int *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_00caac40(uVar8,piVar3,puStack_18,puStack_24);
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar6 = *piVar1;
        *piVar1 = iVar6 + -1;
        UNLOCK();
        if (iVar6 + -1 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar6 = *piVar1;
          *piVar1 = iVar6 + -1;
          UNLOCK();
          if (iVar6 + -1 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      uStack_8._0_1_ = 0xb;
      FUN_0054ef60(auStack_6c);
      uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
      FUN_00bcb620();
      if (piStack_70 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_70[2] + -1;
        piStack_70[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          puStack_d0 = (undefined4 *)0xcaecfb;
          (**(code **)(*piStack_70 + 4))();
        }
      }
      if (piStack_48 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_48[2] + -1;
        piStack_48[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          puStack_d0 = (undefined4 *)0xcaed10;
          (**(code **)(*piStack_48 + 4))();
        }
      }
      puStack_d0 = (undefined4 *)0xcaed18;
      FUN_005507b0();
    }
    puStack_d0 = (undefined4 *)0xcaed20;
    iVar6 = FUN_0091a5b0();
    piVar1 = piStack_38;
  }
  else {
    if (iStack_34 == iStack_30) {
      puStack_d0 = (undefined4 *)auStack_4c;
      pdStack_d4 = (double *)0xcaea6a;
      pdVar7 = (double *)FUN_01682800();
      if (dStack_44 < *pdVar7 || dStack_44 == *pdVar7) goto LAB_00caeaa9;
      pdStack_d8 = (double *)&uStack_3c;
      puStack_dc = (undefined4 *)0xcaea86;
      FUN_00557fc0();
      pdStack_d8 = (double *)0xcaea8e;
      FUN_00cac270();
    }
    else {
      puStack_d0 = (undefined4 *)&stack0x0000000c;
      pdStack_d4 = (double *)0xcaea47;
      FUN_00cb1530();
      puStack_d0 = (undefined4 *)0x0;
      pdStack_d4 = (double *)DAT_01d68be0;
      pdStack_d8 = &dStack_44;
      puStack_dc = &param_1;
      uStack_e0 = 0xcaea5f;
      FUN_00cb1730();
    }
    puStack_d0 = (undefined4 *)0xcaea96;
    iVar6 = FUN_0091a5b0();
    piVar1 = piStack_38;
  }
  piStack_38 = piVar1;
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar3 = piVar1 + 1;
    iVar2 = *piVar3;
    iVar6 = *piVar3;
    *piVar3 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puStack_d0 = (undefined4 *)0xcaed36;
      iVar6 = (**(code **)*piVar1)();
      LOCK();
      piVar3 = piVar1 + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_d0 = (undefined4 *)0xcaed45;
        iVar6 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
LAB_00caed45:
  if (in_stack_00000030 != (int *)0x0) {
    puStack_d0 = (undefined4 *)(uint)(in_stack_00000030 != (int *)&stack0x0000000c);
    pdStack_d4 = (double *)0xcaed5d;
    iVar6 = (**(code **)(*in_stack_00000030 + 0x10))();
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 30238 ; VA 0x00caed70 ; FUN_00caed70 */

uint FUN_00caed70(uint param_1,int param_2,uint param_3,uint param_4)

{
  int iVar1;
  uint uVar2;
  char *pcVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  
  iVar1 = 0;
  uVar5 = 0;
  uVar4 = 0;
  uVar6 = 0;
  if (param_1 < param_2 + param_1) {
    pcVar3 = (char *)(param_1 + 2);
    param_1 = (((param_2 + param_1) - param_1) - 1 >> 4) + 1;
    do {
      uVar5 = (uVar5 << 0xf | uVar5 >> 0x11) + ((int)pcVar3[-2] ^ param_3);
      uVar5 = (uVar5 * 0x400 | uVar5 >> 0x16) + iVar1;
      uVar4 = (param_3 - (int)pcVar3[-1]) - (uVar4 << 0xf | uVar4 >> 0x11);
      uVar4 = (uVar4 * 0x400 | uVar4 >> 0x16) + uVar6;
      uVar6 = (uVar6 >> 0x18 | (uVar6 & 0xff0000) >> 8 | (uVar6 & 0xff00) << 8 | uVar6 << 0x18) +
              ((int)*pcVar3 ^ param_3);
      uVar2 = (pcVar3[1] - iVar1) - param_3;
      pcVar3 = pcVar3 + 0x10;
      uVar6 = (uVar6 * 0x20 | uVar6 >> 0x1b) + uVar4;
      iVar1 = uVar5 - (uVar2 * 0x400 | uVar2 >> 0x16);
      param_1 = param_1 + -1;
    } while (param_1 != 0);
  }
  return (iVar1 - uVar4) + uVar6 + uVar5 ^ param_4;
}



/* FUNCTION 30239 ; VA 0x00caee10 ; FUN_00caee10 */

void __thiscall FUN_00caee10(int param_1,undefined4 *param_2,undefined4 *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  int *piStack_64;
  int aiStack_50 [2];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  int *piStack_3c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined auStack_18 [4];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01811adb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00929190(&puStack_14,param_2);
  if (puStack_14 != (undefined4 *)0x0) {
    FUN_00cb15b0(&puStack_14);
  }
  aiStack_50[0] = param_4;
  puStack_14 = &uStack_48;
  uStack_48 = *param_3;
  piStack_3c = (int *)param_3[3];
  uStack_44 = param_3[1];
  if (piStack_3c != (int *)0x0) {
    LOCK();
    piStack_3c[1] = piStack_3c[1] + 1;
    UNLOCK();
    piStack_3c = (int *)param_3[3];
  }
  uStack_40 = param_3[2];
  uStack_8 = 0;
  FUN_00cab8a0(param_3 + 4);
  uStack_80 = *param_2;
  uStack_7c = param_2[1];
  uStack_8 = 1;
  FUN_00cab820(aiStack_50);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  iVar2 = **(int **)(param_1 + 4);
  puVar3 = *(undefined4 **)(iVar2 + 4);
  uVar5 = FUN_00ca9960(iVar2,puVar3,&uStack_80);
  if (*(int *)(param_1 + 8) != 0x4924923) {
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *(undefined4 *)(iVar2 + 4) = uVar5;
    *puVar3 = uVar5;
    FUN_0091a5b0();
    if (piStack_64 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_64[1] + -1;
      piStack_64[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_64)();
        LOCK();
        iVar2 = piStack_64[2] + -1;
        piStack_64[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_64 + 4))();
        }
      }
    }
    uStack_8 = 0xffffffff;
    FUN_0091a5b0();
    piVar4 = piStack_3c;
    if (piStack_3c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_3c[1] + -1;
      piStack_3c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_3c)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    uStack_28 = *param_2;
    uStack_24 = param_2[1];
    uStack_20 = **(undefined4 **)(param_1 + 4);
    FUN_00caaf10(auStack_18,&uStack_28,&uStack_28);
    *(int *)(param_1 + 0x24) = *(int *)(param_1 + 0x24) + param_4;
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("list<T> too long");
}



/* FUNCTION 30240 ; VA 0x00caefb0 ; FUN_00caefb0 */

void FUN_00caefb0(int *param_1,int param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  uint in_stack_0000001c;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c4780;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  puVar2 = (undefined4 *)*param_1;
  uVar4 = puVar2[2];
  ExceptionList = &pvStack_10;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar4 & 0xfffffffe))(puVar2 + 4,&uStack_30,0);
    }
    else {
      uStack_30 = puVar2[4];
      uStack_2c = puVar2[5];
      uStack_28 = puVar2[6];
      uStack_24 = puVar2[7];
      uStack_20 = *(undefined8 *)(puVar2 + 8);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8._0_1_ = 1;
  FUN_0054ef60(&param_2);
  if (puVar2[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_00cb0c40(*puVar2,puVar2[1]);
  if (0xf < in_stack_0000001c) {
    uVar4 = in_stack_0000001c + 1;
    iVar3 = param_2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(param_2 + -4);
      uVar4 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar3) - 4U) {
        uStack_20 = CONCAT44(&UNK_00caf0a6,(undefined4)uStack_20);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_20 = CONCAT44(uVar4,iVar3);
    uStack_24 = 0xcaf08f;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30241 ; VA 0x00caf0b0 ; FUN_00caf0b0 */

void FUN_00caf0b0(undefined4 param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00ca9280(&param_2);
  if (0xf < in_stack_0000001c) {
    uVar2 = in_stack_0000001c + 1;
    iVar1 = param_2;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_2 + -4);
      uVar2 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30242 ; VA 0x00caf120 ; FUN_00caf120 */

void FUN_00caf120(undefined4 param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00ca93b0(&param_2);
  if (0xf < in_stack_0000001c) {
    uVar2 = in_stack_0000001c + 1;
    iVar1 = param_2;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_2 + -4);
      uVar2 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30243 ; VA 0x00caf1a0 ; FUN_00caf1a0 */

void FUN_00caf1a0(undefined4 param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00ca94c0(&param_2);
  if (0xf < in_stack_0000001c) {
    uVar2 = in_stack_0000001c + 1;
    iVar1 = param_2;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_2 + -4);
      uVar2 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30244 ; VA 0x00caf220 ; FUN_00caf220 */

void FUN_00caf220(int *param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  puVar1 = (undefined4 *)*param_1;
  if ((-(uint)(param_2 != 0) & param_2 + 0xcU) != 0) {
    iVar4 = FUN_00916100();
    if (iVar4 != 0) {
      uVar2 = *puVar1;
      uVar3 = puVar1[1];
      FUN_0054ef60(puVar1 + 2);
      FUN_00cb0460(uVar2,uVar3);
    }
  }
  return;
}



/* FUNCTION 30245 ; VA 0x00caf270 ; FUN_00caf270 */

void FUN_00caf270(int *param_1,int param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  uint in_stack_0000001c;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c4780;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  puVar2 = (undefined4 *)*param_1;
  uVar4 = puVar2[2];
  ExceptionList = &pvStack_10;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar4 & 0xfffffffe))(puVar2 + 4,&uStack_30,0);
    }
    else {
      uStack_30 = puVar2[4];
      uStack_2c = puVar2[5];
      uStack_28 = puVar2[6];
      uStack_24 = puVar2[7];
      uStack_20 = *(undefined8 *)(puVar2 + 8);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8._0_1_ = 1;
  FUN_0054ef60(&param_2);
  if (puVar2[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_00cb0920(*puVar2,puVar2[1]);
  if (0xf < in_stack_0000001c) {
    uVar4 = in_stack_0000001c + 1;
    iVar3 = param_2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(param_2 + -4);
      uVar4 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar3) - 4U) {
        uStack_20 = CONCAT44(&UNK_00caf366,(undefined4)uStack_20);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_20 = CONCAT44(uVar4,iVar3);
    uStack_24 = 0xcaf34f;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30246 ; VA 0x00caf370 ; FUN_00caf370 */

void FUN_00caf370(undefined4 param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00ca95d0(&param_2);
  if (0xf < in_stack_0000001c) {
    uVar2 = in_stack_0000001c + 1;
    iVar1 = param_2;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_2 + -4);
      uVar2 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 30247 ; VA 0x00caf3e0 ; FUN_00caf3e0 */

void FUN_00caf3e0(undefined4 param_1,undefined4 param_2)

{
  FUN_00cac100(param_2);
  return;
}



/* FUNCTION 30248 ; VA 0x00caf400 ; FUN_00caf400 */

uint FUN_00caf400(void)

{
  int iVar1;
  
  iVar1 = FUN_00ca9700();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 30249 ; VA 0x00caf420 ; FUN_00caf420 */

uint FUN_00caf420(void)

{
  int iVar1;
  
  iVar1 = FUN_00ca9700();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}


