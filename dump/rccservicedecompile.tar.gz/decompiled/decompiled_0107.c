/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 26750 ; VA 0x00becdc0 ; FUN_00becdc0 */

undefined4 __thiscall
FUN_00becdc0(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 *param_9,ulonglong param_10,uint param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
            undefined8 param_17)

{
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01802b58;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_3c = 0;
  ExceptionList = &pvStack_10;
  if (param_11 != 0) {
    uStack_3c = param_11;
    if ((param_11 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = &param_13;
      uStack_4c = 0xbece2c;
      ExceptionList = &pvStack_10;
      (**(code **)(param_11 & 0xfffffffe))();
    }
    else {
      uStack_34 = param_13;
      uStack_30 = param_14;
      uStack_2c = param_15;
      puStack_28 = (undefined4 *)param_16;
      uStack_24 = param_17;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_54,0);
    }
    else {
      uStack_54 = param_6;
      uStack_50 = param_7;
      uStack_4c = param_8;
      puStack_48 = param_9;
      uStack_44 = param_10;
    }
  }
  uStack_8._0_1_ = 1;
  FUN_00bed590(param_2,param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_28 = &param_6;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0xbecea9;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_8 = 4;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_28 = &param_13;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0xbeced7;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26751 ; VA 0x00becef0 ; FUN_00becef0 */

undefined4 * __thiscall FUN_00becef0(undefined4 *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802b78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  FUN_00bedad0(param_2 + 1);
  param_1[8] = 0;
  uVar1 = param_2[8];
  uStack_8 = 0;
  if (uVar1 != 0) {
    param_1[8] = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar2 = param_2[0xb];
      uVar3 = param_2[0xc];
      uVar4 = param_2[0xd];
      param_1[10] = param_2[10];
      param_1[0xb] = uVar2;
      param_1[0xc] = uVar3;
      param_1[0xd] = uVar4;
      *(undefined8 *)(param_1 + 0xe) = *(undefined8 *)(param_2 + 0xe);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 10,param_1 + 10,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26752 ; VA 0x00becf90 ; FUN_00becf90 */

undefined4 * __thiscall FUN_00becf90(undefined4 *param_1,undefined4 param_2)

{
  uint in_stack_00000024;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined8 in_stack_0000003c;
  uint uStack_80;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 uStack_68;
  undefined auStack_60 [24];
  undefined auStack_48 [24];
  undefined auStack_30 [28];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01802bd0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_80 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (in_stack_00000024 != 0) {
    uStack_80 = in_stack_00000024;
    if ((in_stack_00000024 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000024 & 0xfffffffe))(&stack0x0000002c,&uStack_78,0);
    }
    else {
      uStack_78 = in_stack_0000002c;
      uStack_74 = in_stack_00000030;
      uStack_70 = in_stack_00000034;
      uStack_6c = in_stack_00000038;
      uStack_68 = in_stack_0000003c;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  FUN_00bedad0(&stack0x00000008);
  uStack_8._0_1_ = 4;
  FUN_00bedad0(auStack_60);
  uStack_8._0_1_ = 5;
  FUN_00bedad0(auStack_48);
  *param_1 = param_2;
  uStack_8._0_1_ = 6;
  FUN_00bedad0(auStack_30);
  FUN_00612320();
  FUN_00612320();
  uStack_8._0_1_ = 7;
  param_1[8] = 0;
  if (uStack_80 != 0) {
    param_1[8] = uStack_80;
    if ((uStack_80 & 1) == 0) {
      (**(code **)(uStack_80 & 0xfffffffe))(&uStack_78,param_1 + 10,0);
    }
    else {
      param_1[10] = uStack_78;
      param_1[0xb] = uStack_74;
      param_1[0xc] = uStack_70;
      param_1[0xd] = uStack_6c;
      *(undefined8 *)(param_1 + 0xe) = uStack_68;
    }
  }
  FUN_00612320();
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (((uStack_80 != 0) && ((uStack_80 & 1) == 0)) &&
     (*(code **)(uStack_80 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_80 & 0xfffffffe))(&uStack_78,&uStack_78,2);
  }
  FUN_00612320();
  uStack_8 = 9;
  if (((in_stack_00000024 != 0) && ((in_stack_00000024 & 1) == 0)) &&
     (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000024 & 0xfffffffe))(&stack0x0000002c,&stack0x0000002c,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26753 ; VA 0x00bed110 ; FUN_00bed110 */

undefined4 * __thiscall FUN_00bed110(undefined4 *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802bf0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  FUN_00bedad0(param_2 + 1);
  param_1[8] = 0;
  uVar1 = param_2[8];
  uStack_8 = 0;
  if (uVar1 != 0) {
    param_1[8] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 10,param_1 + 10,0);
    }
    else {
      uVar2 = param_2[0xb];
      uVar3 = param_2[0xc];
      uVar4 = param_2[0xd];
      param_1[10] = param_2[10];
      param_1[0xb] = uVar2;
      param_1[0xc] = uVar3;
      param_1[0xd] = uVar4;
      *(undefined8 *)(param_1 + 0xe) = *(undefined8 *)(param_2 + 0xe);
    }
  }
  param_1[0x10] = 0;
  uVar1 = param_2[0x10];
  uStack_8 = 1;
  if (uVar1 != 0) {
    param_1[0x10] = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar2 = param_2[0x13];
      uVar3 = param_2[0x14];
      uVar4 = param_2[0x15];
      param_1[0x12] = param_2[0x12];
      param_1[0x13] = uVar2;
      param_1[0x14] = uVar3;
      param_1[0x15] = uVar4;
      *(undefined8 *)(param_1 + 0x16) = *(undefined8 *)(param_2 + 0x16);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0x12,param_1 + 0x12,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26754 ; VA 0x00bed200 ; FUN_00bed200 */

undefined4 __thiscall FUN_00bed200(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  uint in_stack_00000024;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined8 in_stack_0000003c;
  uint in_stack_00000044;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined8 in_stack_0000005c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01802c28;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000044 != 0) && (ExceptionList = &pvStack_10, (in_stack_00000044 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_00000044 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 3;
  if ((in_stack_00000024 != 0) && ((in_stack_00000024 & 1) == 0)) {
    (**(code **)(in_stack_00000024 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 4;
  FUN_00bedad0(&stack0x0000000c);
  uStack_8._0_1_ = 2;
  FUN_00bed720(param_2,param_3);
  FUN_00612320();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (in_stack_00000024 != 0) {
    if (((in_stack_00000024 & 1) == 0) &&
       (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000024 & 0xfffffffe))();
    }
    in_stack_00000024 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) &&
     (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000044 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26755 ; VA 0x00bed350 ; FUN_00bed350 */

undefined4 * __thiscall FUN_00bed350(undefined4 *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802c50;
  pvStack_10 = ExceptionList;
  uVar2 = param_2[1];
  uVar3 = param_2[2];
  uVar4 = param_2[3];
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = uVar2;
  param_1[2] = uVar3;
  param_1[3] = uVar4;
  FUN_00bedad0(param_2 + 4);
  param_1[10] = 0;
  uVar1 = param_2[10];
  uStack_8 = 0;
  if (uVar1 != 0) {
    param_1[10] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
    }
    else {
      uVar2 = param_2[0xd];
      uVar3 = param_2[0xe];
      uVar4 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar2;
      param_1[0xe] = uVar3;
      param_1[0xf] = uVar4;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
    }
  }
  param_1[0x12] = 0;
  uVar1 = param_2[0x12];
  uStack_8 = 1;
  if (uVar1 != 0) {
    param_1[0x12] = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar2 = param_2[0x15];
      uVar3 = param_2[0x16];
      uVar4 = param_2[0x17];
      param_1[0x14] = param_2[0x14];
      param_1[0x15] = uVar2;
      param_1[0x16] = uVar3;
      param_1[0x17] = uVar4;
      *(undefined8 *)(param_1 + 0x18) = *(undefined8 *)(param_2 + 0x18);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0x14,param_1 + 0x14,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26756 ; VA 0x00bed440 ; FUN_00bed440 */

undefined4 __thiscall
FUN_00bed440(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  uint in_stack_00000028;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined4 in_stack_0000003c;
  undefined8 in_stack_00000040;
  uint in_stack_00000048;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined4 in_stack_0000005c;
  undefined8 in_stack_00000060;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01802c88;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000048 != 0) && (ExceptionList = &pvStack_10, (in_stack_00000048 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_00000048 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 3;
  if ((in_stack_00000028 != 0) && ((in_stack_00000028 & 1) == 0)) {
    (**(code **)(in_stack_00000028 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 4;
  FUN_00bedad0(&stack0x00000010);
  uStack_8._0_1_ = 2;
  FUN_00bed8f0(param_2,param_3,param_4);
  FUN_00612320();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (in_stack_00000028 != 0) {
    if (((in_stack_00000028 & 1) == 0) &&
       (*(code **)(in_stack_00000028 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000028 & 0xfffffffe))();
    }
    in_stack_00000028 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_00000048 != 0) && ((in_stack_00000048 & 1) == 0)) &&
     (*(code **)(in_stack_00000048 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000048 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26757 ; VA 0x00bed590 ; FUN_00bed590 */

undefined4 * __thiscall
FUN_00bed590(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10,uint param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
            undefined8 param_17)

{
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01802cc0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_38 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_30,0);
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  *param_1 = param_2;
  uStack_8._0_1_ = 2;
  param_1[2] = 0;
  if (uStack_38 != 0) {
    param_1[2] = uStack_38;
    if ((uStack_38 & 1) == 0) {
      (**(code **)(uStack_38 & 0xfffffffe))(&uStack_30,param_1 + 4,0);
    }
    else {
      param_1[4] = uStack_30;
      param_1[5] = uStack_2c;
      param_1[6] = uStack_28;
      param_1[7] = uStack_24;
      *(undefined8 *)(param_1 + 8) = uStack_20;
    }
  }
  uStack_8._0_1_ = 3;
  if (((uStack_38 != 0) && ((uStack_38 & 1) == 0)) &&
     (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_38 & 0xfffffffe))(&uStack_30,&uStack_30,2);
  }
  uStack_8._0_1_ = 4;
  param_1[10] = 0;
  if (param_11 != 0) {
    param_1[10] = param_11;
    if ((param_11 & 1) == 0) {
      (**(code **)(param_11 & 0xfffffffe))(&param_13,param_1 + 0xc,0);
    }
    else {
      param_1[0xc] = param_13;
      param_1[0xd] = param_14;
      param_1[0xe] = param_15;
      param_1[0xf] = param_16;
      *(undefined8 *)(param_1 + 0x10) = param_17;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_4 & 0xfffffffe))(&param_6,&param_6,2);
  }
  uStack_8 = 6;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_11 & 0xfffffffe))(&param_13,&param_13,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26758 ; VA 0x00bed720 ; FUN_00bed720 */

undefined4 * __thiscall FUN_00bed720(undefined4 *param_1,undefined4 param_2)

{
  uint in_stack_00000024;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined8 in_stack_0000003c;
  uint in_stack_00000044;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined8 in_stack_0000005c;
  uint uStack_68;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined auStack_48 [24];
  undefined auStack_30 [28];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01802d18;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_68 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (in_stack_00000024 != 0) {
    uStack_68 = in_stack_00000024;
    if ((in_stack_00000024 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000024 & 0xfffffffe))(&stack0x0000002c,&uStack_60,0);
    }
    else {
      uStack_60 = in_stack_0000002c;
      uStack_5c = in_stack_00000030;
      uStack_58 = in_stack_00000034;
      uStack_54 = in_stack_00000038;
      uStack_50 = in_stack_0000003c;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 3;
  FUN_00bedad0(&stack0x0000000c);
  uStack_8._0_1_ = 5;
  FUN_00bedad0(auStack_48);
  *param_1 = param_2;
  uStack_8._0_1_ = 6;
  FUN_00bedad0(auStack_30);
  FUN_00612320();
  uStack_8._0_1_ = 7;
  param_1[8] = 0;
  if (uStack_68 != 0) {
    param_1[8] = uStack_68;
    if ((uStack_68 & 1) == 0) {
      (**(code **)(uStack_68 & 0xfffffffe))(&uStack_60,param_1 + 10,0);
    }
    else {
      param_1[10] = uStack_60;
      param_1[0xb] = uStack_5c;
      param_1[0xc] = uStack_58;
      param_1[0xd] = uStack_54;
      *(undefined8 *)(param_1 + 0xe) = uStack_50;
    }
  }
  FUN_00612320();
  uStack_8._0_1_ = 8;
  if (((uStack_68 != 0) && ((uStack_68 & 1) == 0)) &&
     (*(code **)(uStack_68 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_68 & 0xfffffffe))(&uStack_60,&uStack_60,2);
  }
  uStack_8._0_1_ = 9;
  param_1[0x10] = 0;
  if (in_stack_00000044 != 0) {
    param_1[0x10] = in_stack_00000044;
    if ((in_stack_00000044 & 1) == 0) {
      (**(code **)(in_stack_00000044 & 0xfffffffe))(&stack0x0000004c,param_1 + 0x12,0);
    }
    else {
      param_1[0x12] = in_stack_0000004c;
      param_1[0x13] = in_stack_00000050;
      param_1[0x14] = in_stack_00000054;
      param_1[0x15] = in_stack_00000058;
      *(undefined8 *)(param_1 + 0x16) = in_stack_0000005c;
    }
  }
  FUN_00612320();
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  if (in_stack_00000024 != 0) {
    if (((in_stack_00000024 & 1) == 0) &&
       (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000024 & 0xfffffffe))(&stack0x0000002c,&stack0x0000002c,2);
    }
    in_stack_00000024 = 0;
  }
  uStack_8 = 0xb;
  if (((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) &&
     (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000044 & 0xfffffffe))(&stack0x0000004c,&stack0x0000004c,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26759 ; VA 0x00bed8f0 ; FUN_00bed8f0 */

undefined4 * __thiscall
FUN_00bed8f0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  uint in_stack_00000028;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined4 in_stack_0000003c;
  undefined8 in_stack_00000040;
  uint in_stack_00000048;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined4 in_stack_0000005c;
  undefined8 in_stack_00000060;
  uint uStack_68;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined auStack_48 [24];
  undefined auStack_30 [28];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01802d78;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_68 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (in_stack_00000028 != 0) {
    uStack_68 = in_stack_00000028;
    if ((in_stack_00000028 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000028 & 0xfffffffe))(&stack0x00000030,&uStack_60,0);
    }
    else {
      uStack_60 = in_stack_00000030;
      uStack_5c = in_stack_00000034;
      uStack_58 = in_stack_00000038;
      uStack_54 = in_stack_0000003c;
      uStack_50 = in_stack_00000040;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 3;
  FUN_00bedad0(&stack0x00000010);
  uStack_8._0_1_ = 5;
  FUN_00bedad0(auStack_48);
  *param_1 = param_2;
  param_1[2] = param_3;
  param_1[3] = param_4;
  uStack_8._0_1_ = 6;
  FUN_00bedad0(auStack_30);
  FUN_00612320();
  uStack_8._0_1_ = 7;
  param_1[10] = 0;
  if (uStack_68 != 0) {
    param_1[10] = uStack_68;
    if ((uStack_68 & 1) == 0) {
      (**(code **)(uStack_68 & 0xfffffffe))(&uStack_60,param_1 + 0xc,0);
    }
    else {
      param_1[0xc] = uStack_60;
      param_1[0xd] = uStack_5c;
      param_1[0xe] = uStack_58;
      param_1[0xf] = uStack_54;
      *(undefined8 *)(param_1 + 0x10) = uStack_50;
    }
  }
  FUN_00612320();
  uStack_8._0_1_ = 8;
  if (((uStack_68 != 0) && ((uStack_68 & 1) == 0)) &&
     (*(code **)(uStack_68 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_68 & 0xfffffffe))(&uStack_60,&uStack_60,2);
  }
  uStack_8._0_1_ = 9;
  param_1[0x12] = 0;
  if (in_stack_00000048 != 0) {
    param_1[0x12] = in_stack_00000048;
    if ((in_stack_00000048 & 1) == 0) {
      (**(code **)(in_stack_00000048 & 0xfffffffe))(&stack0x00000050,param_1 + 0x14,0);
    }
    else {
      param_1[0x14] = in_stack_00000050;
      param_1[0x15] = in_stack_00000054;
      param_1[0x16] = in_stack_00000058;
      param_1[0x17] = in_stack_0000005c;
      *(undefined8 *)(param_1 + 0x18) = in_stack_00000060;
    }
  }
  FUN_00612320();
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  if (in_stack_00000028 != 0) {
    if (((in_stack_00000028 & 1) == 0) &&
       (*(code **)(in_stack_00000028 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000028 & 0xfffffffe))(&stack0x00000030,&stack0x00000030,2);
    }
    in_stack_00000028 = 0;
  }
  uStack_8 = 0xb;
  if (((in_stack_00000048 != 0) && ((in_stack_00000048 & 1) == 0)) &&
     (*(code **)(in_stack_00000048 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000048 & 0xfffffffe))(&stack0x00000050,&stack0x00000050,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26760 ; VA 0x00bedad0 ; FUN_00bedad0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * __thiscall FUN_00bedad0(undefined *param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint unaff_EBX;
  undefined4 *puVar5;
  float10 fVar6;
  longlong lVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  fVar6 = (float10)FUN_01725280(((double)*(int *)(param_2 + 8) +
                                (double)(&DAT_018c0d90)[-(*(int *)(param_2 + 8) >> 0x1f)]) /
                                (double)*(float *)(param_2 + 0xc));
  if ((double)fVar6 + DAT_018c0d60 < _DAT_018c4e98) {
    FUN_016f3eb1();
  }
  uVar3 = FUN_00588320();
  *(undefined4 *)(param_1 + 4) = uVar3;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0xc);
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  uStack_8 = 0;
  if (*(int *)(param_2 + 8) != 0) {
    FUN_005d2b00();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (*(int *)(param_2 + 8) == 0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      puVar5 = *(undefined4 **)(*(int *)(param_2 + 0x14) + *(int *)(param_2 + 4) * 4);
    }
    lVar7 = (ulonglong)unaff_EBX << 0x20;
    puVar2 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
    while (puVar5 != (undefined4 *)0x0) {
      uVar3 = (undefined4)((ulonglong)lVar7 >> 0x20);
      lVar7 = CONCAT44(uVar3,0x10);
      puVar4 = (undefined4 *)FUN_01674e20(0x10,uVar3);
      *puVar4 = 0;
      puVar4[1] = 0;
      *(undefined8 *)(puVar4 + 2) = 0;
      puVar4[2] = puVar5[2];
      puVar4[3] = puVar5[3];
      puVar4[1] = puVar5[1];
      *puVar2 = puVar4;
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
      puVar1 = (undefined4 *)*puVar2;
      puVar5 = (undefined4 *)*puVar5;
      puVar4 = (undefined4 *)
               (*(int *)(param_1 + 0x14) + ((uint)puVar1[1] % *(uint *)(param_1 + 4)) * 4);
      if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar1[1] % *(uint *)(param_1 + 4)) * 4) == 0)
      {
        *puVar4 = puVar2;
        puVar2 = puVar1;
      }
      else {
        *puVar2 = *puVar1;
        *puVar1 = *(undefined4 *)*puVar4;
        *(undefined4 **)*puVar4 = puVar1;
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26761 ; VA 0x00bedc90 ; FUN_00bedc90 */

undefined4 * __fastcall FUN_00bedc90(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802e5e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::FriendService,class_RBX::ServiceInstance>::vftable;
  uVar1 = FUN_00bea180();
  param_1[3] = uVar1;
  *param_1 = RBX::FriendService::vftable;
  param_1[0x16] = 0;
  uStack_8 = 1;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  *(undefined *)(param_1 + 0x1d) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[0x1e] = uVar1;
  param_1[0x1f] = 0;
  param_1[0x20] = 0x3f800000;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  FUN_016dee4c(param_1 + 0x23,0x102);
  *(undefined *)(param_1 + 0x2f) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[0x30] = uVar1;
  param_1[0x31] = 0;
  param_1[0x32] = 0x3f800000;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  FUN_016dee4c(param_1 + 0x35,0x102);
  *(undefined *)(param_1 + 0x41) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[0x42] = uVar1;
  param_1[0x43] = 0;
  param_1[0x44] = 0x3f800000;
  param_1[0x45] = 0;
  param_1[0x46] = 0;
  *(undefined *)(param_1 + 0x47) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[0x48] = uVar1;
  param_1[0x49] = 0;
  param_1[0x4a] = 0x3f800000;
  param_1[0x4b] = 0;
  param_1[0x4c] = 0;
  *(undefined *)(param_1 + 0x4d) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[0x4e] = uVar1;
  param_1[0x4f] = 0;
  param_1[0x50] = 0x3f800000;
  param_1[0x51] = 0;
  param_1[0x52] = 0;
  uStack_8._0_1_ = 0xd;
  param_1[0x54] = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("FriendService",0xd);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  param_1[0x54] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26762 ; VA 0x00bedef0 ; FUN_00bedef0 */

int __thiscall
FUN_00bedef0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 4) = param_2;
  *(int **)(param_1 + 8) = param_3;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 0x28) = param_4;
  *(undefined4 *)(param_1 + 0x2c) = param_5;
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 0x38) = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 26763 ; VA 0x00bedf90 ; FUN_00bedf90 */

void __fastcall FUN_00bedf90(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(param_1 + 0x54);
  ExceptionList = &pvStack_10;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[2] + -1;
    ExceptionList = &pvStack_10;
    piVar1[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  uVar2 = *(uint *)(param_1 + 0x30);
  uStack_8 = 0;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x38,param_1 + 0x38,2);
      }
    }
    *(undefined4 *)(param_1 + 0x30) = 0;
  }
  uVar2 = *(uint *)(param_1 + 0x10);
  uStack_8 = 1;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x18,param_1 + 0x18,2);
      }
    }
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26764 ; VA 0x00bee030 ; FUN_00bee030 */

void __fastcall FUN_00bee030(int param_1)

{
  uint uVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  
  uVar1 = *(uint *)(param_1 + 0x3c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x28);
    uVar5 = uVar1 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x3c) = 0xf;
  *(undefined *)(param_1 + 0x28) = 0;
  piVar3 = *(int **)(param_1 + 0x24);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[2] + -1;
    piVar3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar3 + 4))();
    }
  }
  FUN_00612320();
  return;
}



/* FUNCTION 26765 ; VA 0x00bee0a0 ; FUN_00bee0a0 */

void __fastcall FUN_00bee0a0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::FriendService>::vftable;
  uVar1 = FUN_00bea180(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26766 ; VA 0x00bee0e0 ; FUN_00bee0e0 */

void __fastcall FUN_00bee0e0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00bea450(*param_1,param_1[1],param_1[2]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26767 ; VA 0x00bee120 ; FUN_00bee120 */

void __fastcall FUN_00bee120(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x28);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x30,param_1 + 0x30,2);
      }
    }
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  FUN_00612320();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26768 ; VA 0x00bee180 ; FUN_00bee180 */

void __fastcall FUN_00bee180(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x18);
  uStack_8 = 0;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x20,param_1 + 0x20,2);
      }
    }
    *(undefined4 *)(param_1 + 0x18) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26769 ; VA 0x00bee1e0 ; FUN_00bee1e0 */

void FUN_00bee1e0(void)

{
  FUN_00612320();
  return;
}



/* FUNCTION 26770 ; VA 0x00bee1f0 ; FUN_00bee1f0 */

void FUN_00bee1f0(void)

{
  FUN_00bee360();
  return;
}



/* FUNCTION 26771 ; VA 0x00bee200 ; FUN_00bee200 */

void FUN_00bee200(void)

{
  FUN_00bee3f0();
  return;
}



/* FUNCTION 26772 ; VA 0x00bee210 ; FUN_00bee210 */

void __fastcall FUN_00bee210(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x20);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x28,param_1 + 0x28,2);
      }
    }
    *(undefined4 *)(param_1 + 0x20) = 0;
  }
  FUN_00612320();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26773 ; VA 0x00bee270 ; FUN_00bee270 */

void FUN_00bee270(void)

{
  FUN_00612320();
  return;
}



/* FUNCTION 26774 ; VA 0x00bee280 ; thunk_FUN_00bee360 */

void __fastcall thunk_FUN_00bee360(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x40);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x48,param_1 + 0x48,2);
      }
    }
    *(undefined4 *)(param_1 + 0x40) = 0;
  }
  uVar1 = *(uint *)(param_1 + 0x20);
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x28,param_1 + 0x28,2);
      }
    }
    *(undefined4 *)(param_1 + 0x20) = 0;
  }
  FUN_00612320();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26775 ; VA 0x00bee290 ; thunk_FUN_00bee3f0 */

void __fastcall thunk_FUN_00bee3f0(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x48);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x50,param_1 + 0x50,2);
      }
    }
    *(undefined4 *)(param_1 + 0x48) = 0;
  }
  uVar1 = *(uint *)(param_1 + 0x28);
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x30,param_1 + 0x30,2);
      }
    }
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  FUN_00612320();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26776 ; VA 0x00bee2a0 ; FUN_00bee2a0 */

void __fastcall FUN_00bee2a0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_00bee5b0();
      iVar1 = *(int *)(param_1 + 4);
    }
    FUN_01674ea0(iVar1,0x28);
  }
  return;
}



/* FUNCTION 26777 ; VA 0x00bee2d0 ; FUN_00bee2d0 */

void __fastcall FUN_00bee2d0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_00bee640();
      iVar1 = *(int *)(param_1 + 4);
    }
    FUN_01674ea0(iVar1,0x50);
  }
  return;
}



/* FUNCTION 26778 ; VA 0x00bee300 ; FUN_00bee300 */

void __fastcall FUN_00bee300(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x28);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x30,param_1 + 0x30,2);
      }
    }
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  FUN_00612320();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26779 ; VA 0x00bee360 ; FUN_00bee360 */

void __fastcall FUN_00bee360(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x40);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x48,param_1 + 0x48,2);
      }
    }
    *(undefined4 *)(param_1 + 0x40) = 0;
  }
  uVar1 = *(uint *)(param_1 + 0x20);
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x28,param_1 + 0x28,2);
      }
    }
    *(undefined4 *)(param_1 + 0x20) = 0;
  }
  FUN_00612320();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26780 ; VA 0x00bee3f0 ; FUN_00bee3f0 */

void __fastcall FUN_00bee3f0(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x48);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x50,param_1 + 0x50,2);
      }
    }
    *(undefined4 *)(param_1 + 0x48) = 0;
  }
  uVar1 = *(uint *)(param_1 + 0x28);
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x30,param_1 + 0x30,2);
      }
    }
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  FUN_00612320();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26781 ; VA 0x00bee480 ; FUN_00bee480 */

void __fastcall FUN_00bee480(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00bee5b0();
        FUN_01674ea0(puVar6,0x28);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 26782 ; VA 0x00bee510 ; FUN_00bee510 */

void __fastcall FUN_00bee510(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00bf1770(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 26783 ; VA 0x00bee590 ; FUN_00bee590 */

void __fastcall FUN_00bee590(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00bee5b0();
        FUN_01674ea0(puVar6,0x28);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 26784 ; VA 0x00bee5a0 ; FUN_00bee5a0 */

void __fastcall FUN_00bee5a0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00bf1770(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 26785 ; VA 0x00bee5b0 ; FUN_00bee5b0 */

void __fastcall FUN_00bee5b0(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_00bea450(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar3 = param_1[2] - iVar1 & 0xffffffc0;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26786 ; VA 0x00bee640 ; FUN_00bee640 */

int __fastcall FUN_00bee640(int param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar4 = FUN_00a59a30();
  uVar2 = *(uint *)(param_1 + 0x20);
  if (0xf < uVar2) {
    iVar4 = *(int *)(param_1 + 0xc);
    uVar6 = uVar2 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  piVar3 = *(int **)(param_1 + 8);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar5 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00bee6b5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar4 = (**(code **)(*piVar3 + 4))();
        return iVar4;
      }
    }
  }
  return iVar4;
}



/* FUNCTION 26787 ; VA 0x00bee6d0 ; FUN_00bee6d0 */

uint * __thiscall FUN_00bee6d0(uint *param_1,uint *param_2)

{
  uint uVar1;
  uint auStack_50 [2];
  undefined auStack_48 [24];
  uint auStack_30 [2];
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802e80;
  pvStack_10 = ExceptionList;
  auStack_30[0] = 0;
  uVar1 = *param_2;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    auStack_30[0] = uVar1;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,&uStack_28,0);
    }
    else {
      uStack_28 = param_2[2];
      uStack_24 = param_2[3];
      uStack_20 = param_2[4];
      uStack_1c = param_2[5];
      uStack_18 = *(undefined8 *)(param_2 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  if (param_1 != auStack_30) {
    auStack_50[0] = 0;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    FUN_005880d0(auStack_30);
    FUN_005880d0(param_1);
    FUN_005880d0(auStack_50);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (auStack_50[0] != 0) {
      if (((auStack_50[0] & 1) == 0) && (*(code **)(auStack_50[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_50[0] & 0xfffffffe))(auStack_48,auStack_48,2);
      }
      auStack_50[0] = 0;
    }
  }
  uStack_8 = 3;
  if (((auStack_30[0] != 0) && ((auStack_30[0] & 1) == 0)) &&
     (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_30[0] & 0xfffffffe))(&uStack_28,&uStack_28,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26788 ; VA 0x00bee7d0 ; FUN_00bee7d0 */

int * __thiscall FUN_00bee7d0(byte *param_1,int *param_2)

{
  uint *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  int *piVar9;
  uint uVar10;
  uint uVar11;
  int *piVar12;
  undefined4 *puVar13;
  int *piVar14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar14 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802e98;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar8 = FUN_00bf3620(param_2);
  FUN_00a29a20(&param_2,uVar8,piVar14,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != (int *)0x0) {
    ExceptionList = pvStack_10;
    return param_2 + 2;
  }
  iVar4 = *piVar14;
  iVar5 = piVar14[1];
  iVar6 = piVar14[2];
  iVar7 = piVar14[3];
  uStack_8 = 0;
  piVar9 = (int *)FUN_01674e20(0x28);
  *piVar9 = 0;
  piVar9[1] = 0;
  piVar9[6] = 0;
  piVar9[7] = 0;
  piVar9[8] = 0;
  piVar9[9] = 0;
  piVar9[2] = iVar4;
  piVar9[3] = iVar5;
  piVar9[4] = iVar6;
  piVar9[5] = iVar7;
  piVar9[6] = 0;
  piVar9[7] = 0;
  piVar9[8] = 0;
  uVar2 = *(uint *)(param_1 + 8);
  uVar10 = uVar2 + 1;
  piVar14 = piVar9;
  param_2 = piVar9;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar10 = FUN_005d6bb0(uVar10);
    if (uVar10 <= *(uint *)(param_1 + 4)) {
      uVar10 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar10);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar10) {
    uVar11 = uVar2 >> 1;
    if (uVar2 + (uVar2 >> 1) <= uVar10) {
      uVar11 = 1;
    }
    uVar10 = FUN_005d6bb0(uVar11 + *(int *)(param_1 + 8));
    puVar1 = (uint *)(param_1 + 4);
    if (uVar10 != *puVar1) {
      FUN_005d2b00(uVar10);
      puVar13 = (undefined4 *)(*(int *)(param_1 + 0x14) + *puVar1 * 4);
      puVar3 = (undefined4 *)*puVar13;
      while (piVar14 = param_2, puVar3 != (undefined4 *)0x0) {
        piVar14 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *puVar1) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *puVar1) * 4) == 0) {
          *piVar14 = (int)puVar13;
          puVar13 = puVar3;
        }
        else {
          *puVar13 = *puVar3;
          *puVar3 = *(undefined4 *)*piVar14;
          *(undefined4 **)*piVar14 = puVar3;
        }
        puVar3 = (undefined4 *)*puVar13;
      }
    }
  }
  piVar14[1] = uVar8;
  uVar10 = *(uint *)(param_1 + 4);
  piVar14 = (int *)(*(int *)(param_1 + 0x14) + (uVar8 % uVar10) * 4);
  if ((int *)*piVar14 == (int *)0x0) {
    piVar12 = (int *)(*(int *)(param_1 + 0x14) + uVar10 * 4);
    if (*piVar12 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar12 + 4) % uVar10) * 4) = param_2;
    }
    *piVar14 = (int)piVar12;
    *param_2 = *piVar12;
  }
  else {
    *param_2 = *(int *)*piVar14;
    piVar12 = (int *)*piVar14;
  }
  *piVar12 = (int)param_2;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piVar9 + 2;
}



/* FUNCTION 26789 ; VA 0x00bee9d0 ; FUN_00bee9d0 */

int * __thiscall FUN_00bee9d0(byte *param_1,int *param_2)

{
  uint *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  int *piVar9;
  uint uVar10;
  uint uVar11;
  int *piVar12;
  undefined4 *puVar13;
  int *piVar14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar9 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802eb8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar8 = FUN_00bf3620(param_2);
  FUN_00a29a20(&param_2,uVar8,piVar9,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != (int *)0x0) {
    ExceptionList = pvStack_10;
    return param_2 + 2;
  }
  iVar4 = *piVar9;
  iVar5 = piVar9[1];
  iVar6 = piVar9[2];
  iVar7 = piVar9[3];
  uStack_8 = 0;
  piVar9 = (int *)FUN_01674e20(0x20);
  *piVar9 = 0;
  piVar9[1] = 0;
  piVar9[6] = 0;
  piVar9[7] = 0;
  piVar9[2] = iVar4;
  piVar9[3] = iVar5;
  piVar9[4] = iVar6;
  piVar9[5] = iVar7;
  if (piVar9 + 6 != (int *)0x0) {
    piVar9[6] = 0;
  }
  uVar2 = *(uint *)(param_1 + 8);
  uVar10 = uVar2 + 1;
  piVar14 = piVar9;
  param_2 = piVar9;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar10 = FUN_005d6bb0(uVar10);
    if (uVar10 <= *(uint *)(param_1 + 4)) {
      uVar10 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar10);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar10) {
    uVar11 = uVar2 >> 1;
    if (uVar2 + (uVar2 >> 1) <= uVar10) {
      uVar11 = 1;
    }
    uVar10 = FUN_005d6bb0(uVar11 + *(int *)(param_1 + 8));
    puVar1 = (uint *)(param_1 + 4);
    if (uVar10 != *puVar1) {
      FUN_005d2b00(uVar10);
      puVar13 = (undefined4 *)(*(int *)(param_1 + 0x14) + *puVar1 * 4);
      puVar3 = (undefined4 *)*puVar13;
      while (piVar14 = param_2, puVar3 != (undefined4 *)0x0) {
        piVar14 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *puVar1) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *puVar1) * 4) == 0) {
          *piVar14 = (int)puVar13;
          puVar13 = puVar3;
        }
        else {
          *puVar13 = *puVar3;
          *puVar3 = *(undefined4 *)*piVar14;
          *(undefined4 **)*piVar14 = puVar3;
        }
        puVar3 = (undefined4 *)*puVar13;
      }
    }
  }
  piVar14[1] = uVar8;
  uVar10 = *(uint *)(param_1 + 4);
  piVar14 = (int *)(*(int *)(param_1 + 0x14) + (uVar8 % uVar10) * 4);
  if ((int *)*piVar14 == (int *)0x0) {
    piVar12 = (int *)(*(int *)(param_1 + 0x14) + uVar10 * 4);
    if (*piVar12 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar12 + 4) % uVar10) * 4) = param_2;
    }
    *piVar14 = (int)piVar12;
    *param_2 = *piVar12;
  }
  else {
    *param_2 = *(int *)*piVar14;
    piVar12 = (int *)*piVar14;
  }
  *piVar12 = (int)param_2;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piVar9 + 2;
}



/* FUNCTION 26790 ; VA 0x00beebc0 ; FUN_00beebc0 */

int * __thiscall FUN_00beebc0(byte *param_1,int *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802ed8;
  pvStack_10 = ExceptionList;
  uVar4 = param_2[1];
  iVar5 = *param_2;
  uVar8 = uVar4;
  if (((int)uVar4 < 1) && ((int)uVar4 < 0)) {
    uVar8 = ~uVar4;
  }
  uVar8 = (uVar8 >> 2) + uVar8 * 0x40 + iVar5 ^ uVar8;
  ExceptionList = &pvStack_10;
  FUN_00606ff0(&param_2,uVar8,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (int *)0x0) {
    uStack_8 = 0;
    piVar3 = (int *)FUN_01674e20(0x50);
    *piVar3 = 0;
    piVar3[1] = 0;
    piVar3[4] = 0;
    piVar3[5] = 0;
    piVar3[6] = 0;
    piVar3[7] = 0;
    piVar3[8] = 0;
    piVar3[9] = 0;
    piVar3[10] = 0;
    piVar3[0xb] = 0;
    piVar3[0xc] = 0;
    piVar3[0xd] = 0;
    piVar3[0xe] = 0;
    piVar3[0xf] = 0;
    piVar3[0x10] = 0;
    piVar3[0x11] = 0;
    piVar3[0x12] = 0;
    piVar3[0x13] = 0;
    piVar3[2] = iVar5;
    piVar3[3] = uVar4;
    piVar3[5] = 0;
    piVar3[6] = 0;
    piVar3[0xb] = 0;
    piVar3[0xc] = 0xf;
    *(undefined *)(piVar3 + 7) = 0;
    piVar3[0xe] = 0;
    piVar3[0xf] = 0;
    piVar3[0x10] = 0;
    piVar3[0x11] = 0;
    piVar3[0x12] = 0;
    uVar1 = *(uint *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar4 = FUN_005d6bb0(uVar4);
      if (uVar4 <= *(uint *)(param_1 + 4)) {
        uVar4 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar4);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar4) {
      param_2 = (int *)0x1;
      uVar6 = uVar1 >> 1;
      if (uVar1 + (uVar1 >> 1) <= uVar4) {
        uVar6 = 1;
      }
      iVar5 = FUN_005d6bb0(uVar6 + uVar1);
      if (iVar5 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar5);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar9;
        while (puVar2 != (undefined4 *)0x0) {
          piVar7 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar7 = (int)puVar9;
            puVar9 = puVar2;
          }
          else {
            *puVar9 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar7;
            *(undefined4 **)*piVar7 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar9;
        }
      }
    }
    piVar3[1] = uVar8;
    uVar8 = uVar8 % *(uint *)(param_1 + 4);
    piVar7 = *(int **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (piVar7 == (int *)0x0) {
      piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar7 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar3;
      }
      *puVar9 = piVar7;
      *piVar3 = *piVar7;
    }
    else {
      *piVar3 = *piVar7;
      piVar7 = (int *)*puVar9;
    }
    *piVar7 = (int)piVar3;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return piVar3 + 2;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 26791 ; VA 0x00beee40 ; FUN_00beee40 */

int __thiscall FUN_00beee40(undefined4 *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  uint *puVar4;
  int iVar5;
  uint uVar6;
  uint in_stack_00000018;
  uint auStack_50 [2];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  int iStack_28;
  int *piStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01802f08;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_38 = CONCAT44(&iStack_28,0xbeee72);
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00587490();
  uStack_8._0_1_ = 1;
  if (iStack_28 != 0) {
    uStack_18 = *param_1;
    puStack_1c = (undefined *)auStack_50;
    puStack_20 = (undefined *)auStack_50;
    uStack_14 = param_1[1];
    auStack_50[0] = 0;
    uVar6 = param_1[2];
    puVar3 = auStack_50;
    puVar4 = auStack_50;
    if (uVar6 != 0) {
      auStack_50[0] = uVar6;
      if ((uVar6 & 1) == 0) {
        (**(code **)(uVar6 & 0xfffffffe))(param_1 + 4,&uStack_48,0);
        puVar3 = (uint *)puStack_20;
        puVar4 = (uint *)puStack_1c;
      }
      else {
        uStack_48 = param_1[4];
        uStack_44 = param_1[5];
        uStack_40 = param_1[6];
        uStack_3c = param_1[7];
        uStack_38 = *(undefined8 *)(param_1 + 8);
        puVar3 = auStack_50;
        puVar4 = auStack_50;
      }
    }
    puStack_1c = (undefined *)puVar4;
    puStack_20 = (undefined *)puVar3;
    uStack_8._0_1_ = 2;
    FUN_0054ef60(&param_2);
    uStack_8._0_1_ = 1;
    iVar5 = FUN_00bf7070(uStack_18,uStack_14);
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_24 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      uStack_38 = CONCAT44(0xbeef0b,(undefined4)uStack_38);
      iVar5 = (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piStack_24 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_38 = CONCAT44(0xbeef1a,(undefined4)uStack_38);
        iVar5 = (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000018) {
    uVar6 = in_stack_00000018 + 1;
    iVar5 = param_2;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(param_2 + -4);
      uVar6 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar5) - 4U) {
        uStack_38 = CONCAT44(&UNK_00beef61,(undefined4)uStack_38);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_38 = CONCAT44(uVar6,iVar5);
    uStack_3c = 0xbeef47;
    iVar5 = FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 26792 ; VA 0x00beef70 ; FUN_00beef70 */

int __thiscall FUN_00beef70(int param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  bool bVar6;
  undefined auStack_4c [16];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int iStack_34;
  int *piStack_30;
  int aiStack_2c [2];
  undefined4 *puStack_24;
  undefined4 uStack_20;
  int aiStack_1c [2];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802f40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00587490(&iStack_34);
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  if ((iStack_34 != 0) && (bVar6 = (char)param_2 != '\0', bVar6)) {
    puVar1 = (undefined4 *)(param_1 + 8);
    iVar4 = FUN_00bf16a0(puVar1);
    if (iVar4 != 0) {
      puVar5 = (undefined4 *)(param_1 + 0x10);
      iVar4 = FUN_00bf16a0(puVar5);
      if (iVar4 != 0) {
        uStack_3c = 0;
        uStack_38 = 0xf;
        auStack_4c[0] = 0;
        FUN_005542c0("FriendService-FriendRequestAccepted",0x23);
        uStack_8._0_1_ = 1;
        FUN_008783f0(auStack_4c,1,0);
        uStack_8._0_1_ = 0;
        FUN_005507b0();
        FUN_0087c450(&DAT_018c5f98,"FriendService","FriendRequestAccepted",1,0,0);
        iVar4 = FUN_0064e810(iStack_34);
        param_2 = iVar4;
        if (iVar4 != 0) {
          FUN_0097fc00(aiStack_2c,*puVar1,*(undefined4 *)(param_1 + 0xc));
          uStack_8._0_1_ = 2;
          FUN_0097fc00(aiStack_1c,*puVar5,*(undefined4 *)(param_1 + 0x14));
          uStack_8._0_1_ = 3;
          if ((aiStack_2c[0] != 0) && (aiStack_1c[0] != 0)) {
            FUN_00927d30(&param_2);
            FUN_00927d30(&uStack_14);
            puStack_24 = &param_2;
            uStack_20 = 0;
            FUN_00bf9a20(iStack_34,*puVar1,*(undefined4 *)(param_1 + 0xc),*puVar5,
                         *(undefined4 *)(param_1 + 0x14),2,&puStack_24);
            puStack_24 = &uStack_14;
            uStack_20 = 0;
            FUN_00bf9a20(iStack_34,*puVar1,*(undefined4 *)(param_1 + 0xc),*puVar5,
                         *(undefined4 *)(param_1 + 0x14),2,&puStack_24);
          }
          FUN_00550b30();
          iVar4 = FUN_00550b30();
        }
      }
    }
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_30 + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar4 = (**(code **)*piStack_30)();
      LOCK();
      piVar2 = piStack_30 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar4 = (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 26793 ; VA 0x00bef140 ; FUN_00bef140 */

void __thiscall FUN_00bef140(char *param_1,undefined4 *param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  char *pcVar4;
  uint uVar5;
  char *pcVar6;
  uint in_stack_00000018;
  int iVar7;
  uint in_stack_ffffffb4;
  uint in_stack_ffffffb8;
  char *in_stack_ffffffbc;
  char *pcVar8;
  undefined4 uVar9;
  undefined auStack_28 [12];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01802f60;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pcVar6 = "";
  pcVar8 = (char *)0xbef179;
  ExceptionList = &pvStack_10;
  FUN_016819e0(auStack_28,&param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  cVar1 = FUN_016816d0();
  if (cVar1 == '\0') {
    pcVar8 = (char *)0xbef1fa;
    FUN_0167eea0(auStack_1c,"success");
    cVar1 = FUN_01681870();
    if (cVar1 == '\0') {
      pcVar6 = "not an object";
    }
    else {
      cVar1 = FUN_01682670();
      if (cVar1 == '\0') {
        pcVar6 = "no member success";
      }
      else {
        cVar1 = FUN_0167e5c0();
        if (cVar1 == '\0') {
          pcVar6 = "success is not a bool";
        }
        else {
          cVar1 = FUN_0167e3d0(0);
          if (cVar1 != '\0') {
            if (DAT_01d6802c != 0) {
              if (0xf < *(uint *)(param_1 + 0x14)) {
                param_1 = *(char **)param_1;
              }
              FUN_01677520(DAT_01d6802c,"%s success",param_1);
            }
            FUN_005515c0();
            goto LAB_00bef268;
          }
        }
      }
    }
    if (DAT_01d6802c != 0) {
      if (0xf < *(uint *)(param_1 + 0x14)) {
        param_1 = *(char **)param_1;
      }
      in_stack_ffffffbc = (char *)(uint)DAT_01d6802c;
      pcVar8 = "%s failure: %s";
      in_stack_ffffffb8 = 0xbef232;
      FUN_01677520(in_stack_ffffffbc,"%s failure: %s",param_1,pcVar6);
    }
    pcVar4 = pcVar6;
    do {
      cVar1 = *pcVar4;
      pcVar4 = pcVar4 + 1;
    } while (cVar1 != '\0');
    iVar7 = (int)pcVar4 - (int)(pcVar6 + 1);
  }
  else {
    if (DAT_01d6802c != 0) {
      puVar3 = &param_2;
      if (0xf < in_stack_00000018) {
        puVar3 = param_2;
      }
      uVar2 = FUN_016814a0();
      if (0xf < *(uint *)(param_1 + 0x14)) {
        param_1 = *(char **)param_1;
      }
      in_stack_ffffffb8 = (uint)DAT_01d6802c;
      in_stack_ffffffbc = "%s failed: parse error \"%s\", json: %s";
      in_stack_ffffffb4 = 0xbef1c7;
      FUN_01677520(in_stack_ffffffb8,"%s failed: parse error \"%s\", json: %s",param_1,uVar2,puVar3)
      ;
      pcVar8 = param_1;
    }
    iVar7 = 0xb;
    pcVar6 = "parse error";
  }
  uVar9 = 0xf;
  uVar2 = 0;
  in_stack_ffffffb4 = in_stack_ffffffb4 & 0xffffff00;
  FUN_005542c0(pcVar6,iVar7);
  FUN_005e65e0(in_stack_ffffffb4,in_stack_ffffffb8,in_stack_ffffffbc,pcVar8,uVar2,uVar9);
LAB_00bef268:
  FUN_0167ec40();
  if (0xf < in_stack_00000018) {
    uVar5 = in_stack_00000018 + 1;
    puVar3 = param_2;
    if (0xfff < uVar5) {
      puVar3 = (undefined4 *)param_2[-1];
      uVar5 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26794 ; VA 0x00bef340 ; FUN_00bef340 */

int __thiscall FUN_00bef340(undefined4 *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  uint *puVar4;
  int iVar5;
  uint uVar6;
  uint in_stack_00000018;
  uint auStack_78 [2];
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 *puStack_64;
  ulonglong uStack_60;
  uint auStack_58 [2];
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  int iStack_30;
  int *piStack_2c;
  undefined *puStack_28;
  undefined *puStack_24;
  undefined *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01802f90;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_40 = CONCAT44(&iStack_30,0xbef372);
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00587490();
  uStack_8._0_1_ = 1;
  if (iStack_30 != 0) {
    uStack_14 = param_1[2];
    puStack_24 = (undefined *)auStack_58;
    puStack_20 = (undefined *)auStack_58;
    uStack_1c = *param_1;
    uStack_18 = param_1[1];
    auStack_58[0] = 0;
    uVar6 = param_1[0xc];
    puVar3 = auStack_58;
    if (uVar6 != 0) {
      auStack_58[0] = uVar6;
      if ((uVar6 & 1) == 0) {
        uStack_60 = ZEXT48(&uStack_50);
        puStack_64 = param_1 + 0xe;
        uStack_68 = 0xbef3d6;
        (**(code **)(uVar6 & 0xfffffffe))();
        puVar3 = (uint *)puStack_20;
      }
      else {
        uStack_50 = param_1[0xe];
        uStack_4c = param_1[0xf];
        uStack_48 = param_1[0x10];
        uStack_44 = param_1[0x11];
        uStack_40 = *(undefined8 *)(param_1 + 0x12);
        puVar3 = auStack_58;
      }
    }
    puStack_20 = (undefined *)puVar3;
    puStack_24 = (undefined *)auStack_78;
    puStack_28 = (undefined *)auStack_78;
    uStack_8._0_1_ = 2;
    auStack_78[0] = 0;
    uVar6 = param_1[4];
    puVar3 = auStack_78;
    puVar4 = auStack_78;
    if (uVar6 != 0) {
      auStack_78[0] = uVar6;
      if ((uVar6 & 1) == 0) {
        (**(code **)(uVar6 & 0xfffffffe))(param_1 + 6,&uStack_70,0);
        puVar3 = (uint *)puStack_28;
        puVar4 = (uint *)puStack_24;
      }
      else {
        uStack_70 = param_1[6];
        uStack_6c = param_1[7];
        uStack_68 = param_1[8];
        puStack_64 = (undefined4 *)param_1[9];
        uStack_60 = *(ulonglong *)(param_1 + 10);
        puVar3 = auStack_78;
        puVar4 = auStack_78;
      }
    }
    puStack_24 = (undefined *)puVar4;
    puStack_28 = (undefined *)puVar3;
    uStack_8._0_1_ = 3;
    FUN_0054ef60(&param_2);
    uStack_8._0_1_ = 1;
    iVar5 = FUN_00bf7310(uStack_1c,uStack_18,uStack_14);
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_2c + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      uStack_40 = CONCAT44(0xbef463,(undefined4)uStack_40);
      iVar5 = (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piStack_2c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_40 = CONCAT44(0xbef472,(undefined4)uStack_40);
        iVar5 = (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  if (0xf < in_stack_00000018) {
    uVar6 = in_stack_00000018 + 1;
    iVar5 = param_2;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(param_2 + -4);
      uVar6 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar5) - 4U) {
        uStack_40 = CONCAT44(&UNK_00bef4b9,(undefined4)uStack_40);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_40 = CONCAT44(uVar6,iVar5);
    uStack_44 = 0xbef49f;
    iVar5 = FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 26795 ; VA 0x00bef4c0 ; FUN_00bef4c0 */

void FUN_00bef4c0(undefined4 *param_1)

{
  uint *puVar1;
  uint uVar2;
  undefined uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0("fetch friends failed",0x14);
  FUN_005e65e0(uVar3);
  puVar1 = (uint *)*param_1;
  if (puVar1 != (uint *)0x0) {
    uVar2 = puVar1[8];
    uStack_8 = 0;
    if (uVar2 != 0) {
      if ((uVar2 & 1) == 0) {
        if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
          (**(code **)(uVar2 & 0xfffffffe))(puVar1 + 10,puVar1 + 10,2);
        }
      }
      puVar1[8] = 0;
    }
    uVar2 = *puVar1;
    uStack_8 = 1;
    if (uVar2 != 0) {
      if ((uVar2 & 1) == 0) {
        if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
          (**(code **)(uVar2 & 0xfffffffe))(puVar1 + 2,puVar1 + 2,2);
        }
      }
      *puVar1 = 0;
    }
    FUN_01674ea0(puVar1,0x40);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26796 ; VA 0x00bef590 ; FUN_00bef590 */

void FUN_00bef590(undefined4 *param_1)

{
  uint *puVar1;
  uint uVar2;
  undefined uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0("friend fetch is already in progress",0x23);
  FUN_005e65e0(uVar3);
  puVar1 = (uint *)*param_1;
  if (puVar1 != (uint *)0x0) {
    uVar2 = puVar1[8];
    uStack_8 = 0;
    if (uVar2 != 0) {
      if ((uVar2 & 1) == 0) {
        if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
          (**(code **)(uVar2 & 0xfffffffe))(puVar1 + 10,puVar1 + 10,2);
        }
      }
      puVar1[8] = 0;
    }
    uVar2 = *puVar1;
    uStack_8 = 1;
    if (uVar2 != 0) {
      if ((uVar2 & 1) == 0) {
        if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
          (**(code **)(uVar2 & 0xfffffffe))(puVar1 + 2,puVar1 + 2,2);
        }
      }
      *puVar1 = 0;
    }
    FUN_01674ea0(puVar1,0x40);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26797 ; VA 0x00bef660 ; FUN_00bef660 */

void FUN_00bef660(undefined4 *param_1)

{
  int *piVar1;
  uint *puVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[2] + 4);
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00bef900(param_1[1],param_1[2]);
  puVar2 = (uint *)*param_1;
  if (puVar2 != (uint *)0x0) {
    uVar3 = puVar2[8];
    uStack_8 = 0;
    if (uVar3 != 0) {
      if ((uVar3 & 1) == 0) {
        if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
          (**(code **)(uVar3 & 0xfffffffe))(puVar2 + 10,puVar2 + 10,2);
        }
      }
      puVar2[8] = 0;
    }
    uVar3 = *puVar2;
    uStack_8 = 1;
    if (uVar3 != 0) {
      if ((uVar3 & 1) == 0) {
        if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
          (**(code **)(uVar3 & 0xfffffffe))(puVar2 + 2,puVar2 + 2,2);
        }
      }
      *puVar2 = 0;
    }
    FUN_01674ea0(puVar2,0x40);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26798 ; VA 0x00bef730 ; FUN_00bef730 */

undefined4 * __fastcall FUN_00bef730(int *param_1)

{
  int *piVar1;
  code *pcVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uStack_68;
  undefined4 **ppuStack_64;
  undefined *puStack_60;
  undefined4 *puStack_58;
  undefined4 uStack_4c;
  int iStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802fb0;
  pvStack_10 = ExceptionList;
  LOCK();
  iVar4 = *(int *)(*param_1 + 0x150);
  ExceptionList = &pvStack_10;
  if (iVar4 == 0) {
    ExceptionList = &pvStack_10;
    *(int *)(*param_1 + 0x150) = 1;
    iVar4 = 0;
  }
  UNLOCK();
  if (iVar4 == 0) {
    piStack_40 = &uStack_24;
    uStack_44 = 0xbef774;
    FUN_005cac50();
    uStack_8 = 0;
    pcVar2 = *(code **)**(undefined4 **)(*param_1 + 0x14c);
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piStack_20[1] = piStack_20[1] + 1;
      UNLOCK();
    }
    uStack_44 = uStack_24;
    piStack_40 = piStack_20;
    iStack_48 = 0xbef7ac;
    iVar4 = (*pcVar2)();
    if (iVar4 < 0) {
      iStack_48 = *param_1;
      iVar4 = param_1[1];
      uStack_4c = 0xbef817;
      uStack_1c = FUN_008f7870();
      iStack_48 = 1;
      puStack_18 = &uStack_68;
      iStack_14 = iVar4;
      cVar3 = FUN_00585a40(&iStack_14);
      puVar5 = puStack_18;
      if (cVar3 == '\0') {
        puStack_18[2] = iStack_14;
        *puVar5 = &DAT_01960561;
      }
      else {
        *puStack_18 = 0;
      }
    }
    else {
      puStack_18 = (undefined4 *)param_1[1];
      iStack_48 = *param_1;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        piStack_20[1] = piStack_20[1] + 1;
        UNLOCK();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      uStack_4c = 0xbef7d3;
      FUN_008f7870();
      iStack_48 = 1;
      FUN_00be9970(puStack_18,uStack_24,piStack_20,0);
    }
    FUN_0090ca30();
    puVar5 = (undefined4 *)(*param_1 + 0x150);
    LOCK();
    *puVar5 = 0;
    UNLOCK();
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_20 + 1;
      iVar4 = *piVar1;
      puVar5 = (undefined4 *)*piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        iStack_48 = 0xbef87c;
        puVar5 = (undefined4 *)(**(code **)*piStack_20)();
        LOCK();
        piVar1 = piStack_20 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          iStack_48 = 0xbef88b;
          puVar5 = (undefined4 *)(**(code **)(*piStack_20 + 4))();
          ExceptionList = pvStack_10;
          return puVar5;
        }
      }
    }
  }
  else {
    piStack_40 = (int *)*param_1;
    puVar5 = (undefined4 *)param_1[1];
    uStack_44 = 0xbef8a6;
    FUN_008f7870();
    ppuStack_64 = &puStack_18;
    piStack_40 = (int *)0x1;
    uStack_68 = 0xbef8be;
    puStack_18 = puVar5;
    cVar3 = FUN_00585a40();
    if (cVar3 == '\0') {
      puStack_58 = puStack_18;
      puStack_60 = &DAT_01960569;
    }
    else {
      puStack_60 = (undefined *)0x0;
    }
    ppuStack_64 = (undefined4 **)0xbef8e4;
    puVar5 = (undefined4 *)FUN_0090ca30();
  }
  ExceptionList = pvStack_10;
  return puVar5;
}



/* FUNCTION 26799 ; VA 0x00bef900 ; FUN_00bef900 */

/* WARNING: Removing unreachable block (ram,0x00bef96d) */
/* WARNING: Removing unreachable block (ram,0x00bef979) */
/* WARNING: Removing unreachable block (ram,0x00bef987) */

undefined4 __thiscall FUN_00bef900(uint *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01802fd0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*param_1 == 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar1);
  }
  ExceptionList = &pvStack_10;
  uVar1 = (**(code **)((*param_1 & 0xfffffffe) + 4))(param_1 + 2,param_2,param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 26800 ; VA 0x00bef9c0 ; FUN_00bef9c0 */

/* WARNING: Removing unreachable block (ram,0x00befa2d) */
/* WARNING: Removing unreachable block (ram,0x00befa39) */
/* WARNING: Removing unreachable block (ram,0x00befa47) */

undefined4 __thiscall FUN_00bef9c0(uint *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01802ff0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*param_1 == 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar1);
  }
  ExceptionList = &pvStack_10;
  uVar1 = (**(code **)((*param_1 & 0xfffffffe) + 4))(param_1 + 2,param_2,param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 26801 ; VA 0x00befa80 ; FUN_00befa80 */

void __thiscall FUN_00befa80(undefined4 *param_1,undefined4 param_2,uint param_3)

{
  code *pcVar1;
  undefined uVar2;
  uint *puVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 *in_stack_00000034;
  ulonglong in_stack_00000038;
  uint in_stack_00000040;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined8 in_stack_00000058;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  ulonglong uStack_48;
  uint auStack_40 [2];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01803028;
  pvStack_10 = ExceptionList;
  param_2 = auStack_40;
  pcVar1 = (code *)*param_1;
  uStack_8 = 2;
  auStack_40[0] = 0;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_40;
  if (in_stack_00000040 != 0) {
    auStack_40[0] = in_stack_00000040;
    if ((in_stack_00000040 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = &stack0x00000048;
      uStack_50 = 0xbefaf0;
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000040 & 0xfffffffe))();
      puVar3 = param_2;
    }
    else {
      uStack_38 = in_stack_00000048;
      uStack_34 = in_stack_0000004c;
      uStack_30 = in_stack_00000050;
      uStack_2c = in_stack_00000054;
      uStack_28 = in_stack_00000058;
      ExceptionList = &pvStack_10;
      puVar3 = auStack_40;
    }
  }
  param_2 = puVar3;
  uStack_8._0_1_ = 3;
  if (in_stack_00000020 != 0) {
    if ((in_stack_00000020 & 1) == 0) {
      (**(code **)(in_stack_00000020 & 0xfffffffe))(&stack0x00000028,&uStack_58,0);
    }
    else {
      uStack_58 = in_stack_00000028;
      uStack_54 = in_stack_0000002c;
      uStack_50 = in_stack_00000030;
      puStack_4c = in_stack_00000034;
      uStack_48 = in_stack_00000038;
    }
  }
  uStack_8._0_1_ = 4;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 2;
  (*pcVar1)();
  uStack_8._0_1_ = 1;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    uVar4 = param_3;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(param_3 - 4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_3 - uVar4) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (in_stack_00000020 != 0) {
    if (((in_stack_00000020 & 1) == 0) &&
       (*(code **)(in_stack_00000020 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000020 & 0xfffffffe))(&stack0x00000028,&stack0x00000028,2);
    }
    in_stack_00000020 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_00000040 != 0) && ((in_stack_00000040 & 1) == 0)) &&
     (*(code **)(in_stack_00000040 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000040 & 0xfffffffe))(&stack0x00000048,&stack0x00000048,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26802 ; VA 0x00befc10 ; FUN_00befc10 */

void __thiscall FUN_00befc10(undefined4 *param_1)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  int *piVar4;
  uint *puVar5;
  uint *puStack00000004;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  uint in_stack_00000028;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined4 in_stack_0000003c;
  undefined8 in_stack_00000040;
  uint auStack_40 [2];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01803068;
  pvStack_10 = ExceptionList;
  puStack00000004 = auStack_40;
  pcVar2 = (code *)*param_1;
  uStack_8 = 2;
  auStack_40[0] = 0;
  ExceptionList = &pvStack_10;
  puVar5 = auStack_40;
  if (in_stack_00000028 != 0) {
    auStack_40[0] = in_stack_00000028;
    if ((in_stack_00000028 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000028 & 0xfffffffe))(&stack0x00000030);
      puVar5 = puStack00000004;
    }
    else {
      uStack_38 = in_stack_00000030;
      uStack_34 = in_stack_00000034;
      uStack_30 = in_stack_00000038;
      uStack_2c = in_stack_0000003c;
      uStack_28 = in_stack_00000040;
      ExceptionList = &pvStack_10;
      puVar5 = auStack_40;
    }
  }
  puStack00000004 = puVar5;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    in_stack_00000024[1] = in_stack_00000024[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 4;
  FUN_00bedad0(&stack0x00000008);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  (*pcVar2)();
  FUN_00612320();
  piVar4 = in_stack_00000024;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar3 = in_stack_00000024[1] + -1;
    in_stack_00000024[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  uStack_8 = 5;
  if (((in_stack_00000028 != 0) && ((in_stack_00000028 & 1) == 0)) &&
     (*(code **)(in_stack_00000028 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000028 & 0xfffffffe))(&stack0x00000030,&stack0x00000030,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26803 ; VA 0x00befd40 ; FUN_00befd40 */

void __thiscall FUN_00befd40(undefined4 *param_1,undefined4 param_2,uint param_3)

{
  code *pcVar1;
  undefined uVar2;
  uint *puVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_00000038;
  undefined4 in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined8 in_stack_00000050;
  uint in_stack_00000058;
  undefined4 in_stack_00000060;
  undefined4 in_stack_00000064;
  undefined4 in_stack_00000068;
  undefined4 in_stack_0000006c;
  undefined8 in_stack_00000070;
  uint auStack_44 [2];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018030b8;
  pvStack_10 = ExceptionList;
  param_2 = auStack_44;
  pcVar1 = (code *)*param_1;
  uStack_8 = 3;
  auStack_44[0] = 0;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_44;
  if (in_stack_00000058 != 0) {
    auStack_44[0] = in_stack_00000058;
    if ((in_stack_00000058 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000058 & 0xfffffffe))();
      puVar3 = param_2;
    }
    else {
      uStack_3c = in_stack_00000060;
      uStack_38 = in_stack_00000064;
      uStack_34 = in_stack_00000068;
      uStack_30 = in_stack_0000006c;
      uStack_2c = in_stack_00000070;
      ExceptionList = &pvStack_10;
      puVar3 = auStack_44;
    }
  }
  param_2 = puVar3;
  uStack_8._0_1_ = 4;
  if ((in_stack_00000038 != 0) && ((in_stack_00000038 & 1) == 0)) {
    (**(code **)(in_stack_00000038 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 5;
  FUN_00bedad0(&stack0x00000020);
  uStack_8._0_1_ = 6;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 3;
  (*pcVar1)();
  uStack_8._0_1_ = 2;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    uVar4 = param_3;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(param_3 - 4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_3 - uVar4) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  FUN_00612320();
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (in_stack_00000038 != 0) {
    if (((in_stack_00000038 & 1) == 0) &&
       (*(code **)(in_stack_00000038 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000038 & 0xfffffffe))(&stack0x00000040,&stack0x00000040,2);
    }
    in_stack_00000038 = 0;
  }
  uStack_8 = 8;
  if (((in_stack_00000058 != 0) && ((in_stack_00000058 & 1) == 0)) &&
     (*(code **)(in_stack_00000058 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000058 & 0xfffffffe))(&stack0x00000060,&stack0x00000060,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26804 ; VA 0x00befef0 ; FUN_00befef0 */

void __thiscall
FUN_00befef0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  code *pcVar1;
  uint *puVar2;
  uint in_stack_00000028;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined4 *in_stack_0000003c;
  ulonglong in_stack_00000040;
  uint in_stack_00000048;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined4 in_stack_0000005c;
  undefined8 in_stack_00000060;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  ulonglong uStack_48;
  uint auStack_40 [2];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018030f8;
  pvStack_10 = ExceptionList;
  param_2 = auStack_40;
  pcVar1 = (code *)*param_1;
  uStack_8 = 2;
  auStack_40[0] = 0;
  ExceptionList = &pvStack_10;
  puVar2 = auStack_40;
  if (in_stack_00000048 != 0) {
    auStack_40[0] = in_stack_00000048;
    if ((in_stack_00000048 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = &stack0x00000050;
      uStack_50 = 0xbeff60;
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000048 & 0xfffffffe))();
      puVar2 = param_2;
    }
    else {
      uStack_38 = in_stack_00000050;
      uStack_34 = in_stack_00000054;
      uStack_30 = in_stack_00000058;
      uStack_2c = in_stack_0000005c;
      uStack_28 = in_stack_00000060;
      ExceptionList = &pvStack_10;
      puVar2 = auStack_40;
    }
  }
  param_2 = puVar2;
  uStack_8._0_1_ = 3;
  if (in_stack_00000028 != 0) {
    if ((in_stack_00000028 & 1) == 0) {
      (**(code **)(in_stack_00000028 & 0xfffffffe))(&stack0x00000030,&uStack_58,0);
    }
    else {
      uStack_58 = in_stack_00000030;
      uStack_54 = in_stack_00000034;
      uStack_50 = in_stack_00000038;
      puStack_4c = in_stack_0000003c;
      uStack_48 = in_stack_00000040;
    }
  }
  uStack_8._0_1_ = 4;
  FUN_00bedad0(&stack0x00000010);
  uStack_8._0_1_ = 2;
  (*pcVar1)(param_3,param_4);
  FUN_00612320();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (in_stack_00000028 != 0) {
    if (((in_stack_00000028 & 1) == 0) &&
       (*(code **)(in_stack_00000028 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000028 & 0xfffffffe))(&stack0x00000030,&stack0x00000030,2);
    }
    in_stack_00000028 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_00000048 != 0) && ((in_stack_00000048 & 1) == 0)) &&
     (*(code **)(in_stack_00000048 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000048 & 0xfffffffe))(&stack0x00000050,&stack0x00000050,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26805 ; VA 0x00bf0040 ; FUN_00bf0040 */

int __thiscall FUN_00bf0040(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 26806 ; VA 0x00bf00a0 ; FUN_00bf00a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00bf00a0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::FriendService_FriendEventType>::vftable;
  _DAT_01ef7860 = _DAT_01ef7860 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 26807 ; VA 0x00bf00d0 ; FUN_00bf00d0 */

undefined4 * __thiscall FUN_00bf00d0(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::FriendService::vftable;
  FUN_00612320();
  FUN_00bee480();
  FUN_006f8c50();
  FUN_016dedfb(param_1 + 0x35);
  FUN_00bee510();
  FUN_016dedfb(param_1 + 0x23);
  FUN_00bee510();
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = param_1[0x1c];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar3 = param_1[0x1b];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x154);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26808 ; VA 0x00bf0200 ; FUN_00bf0200 */

void FUN_00bf0200(void)

{
  FUN_0056d250();
  return;
}



/* FUNCTION 26809 ; VA 0x00bf0210 ; FUN_00bf0210 */

void __thiscall FUN_00bf0210(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00bea450(param_2,param_3,param_1);
  return;
}



/* FUNCTION 26810 ; VA 0x00bf0230 ; FUN_00bf0230 */

undefined4 * FUN_00bf0230(int param_1,int param_2,undefined4 *param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_01803210;
  pvStack_10 = ExceptionList;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    do {
      uStack_8 = 0;
      *param_3 = 0;
      FUN_005880d0(param_1);
      uStack_8 = 1;
      param_3[8] = 0;
      FUN_005880d0(param_1 + 0x20);
      param_3 = param_3 + 0x10;
      param_1 = param_1 + 0x40;
    } while (param_1 != param_2);
  }
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 26811 ; VA 0x00bf02c0 ; FUN_00bf02c0 */

undefined4 * __thiscall FUN_00bf02c0(undefined4 param_1,int param_2,int param_3,undefined4 *param_4)

{
  void **ppvVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01803230;
  pvStack_10 = ExceptionList;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  ppvVar1 = &pvStack_10;
  if (param_2 != param_3) {
    do {
      uStack_8._0_1_ = 0;
      *param_4 = 0;
      FUN_005880d0(param_2);
      uStack_8._0_1_ = 1;
      param_4[8] = 0;
      FUN_005880d0(param_2 + 0x20);
      param_4 = param_4 + 0x10;
      param_2 = param_2 + 0x40;
      ppvVar1 = (void **)ExceptionList;
    } while (param_2 != param_3);
  }
  ExceptionList = ppvVar1;
  uStack_8 = 2;
  FUN_00bea450(param_4,param_4,param_1);
  ExceptionList = pvStack_10;
  return param_4;
}



/* FUNCTION 26812 ; VA 0x00bf0370 ; FUN_00bf0370 */

void __thiscall
FUN_00bf0370(int *param_1,int param_2,int *param_3,undefined4 param_4,int *param_5,uint param_6)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  undefined uVar4;
  char cVar5;
  int iVar6;
  int iVar7;
  undefined4 uVar8;
  int *piVar9;
  uint uVar10;
  uint uVar11;
  undefined4 in_stack_00000024;
  uint in_stack_00000028;
  int in_stack_0000002c;
  uint in_stack_00000040;
  undefined4 *puVar12;
  uint auStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  undefined4 uStack_34;
  undefined4 *puStack_30;
  undefined4 *puStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018032af;
  pvStack_10 = ExceptionList;
  piVar2 = param_1 + 0x23;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  piStack_28 = piVar2;
  piStack_20 = param_1;
  iVar6 = FUN_016dee6d(piVar2);
  if (iVar6 != 0) {
    FUN_016df3c9(iVar6);
  }
  piStack_14 = param_1 + 0x1d;
  iVar6 = (int)param_1 + *(byte *)(param_1 + 0x1d) + 0x75;
  if (((int)param_3 < 1) && ((int)param_3 < 0)) {
    iStack_1c = -1 - param_2;
    uVar11 = -(int)param_3 - 1;
  }
  else {
    iStack_1c = param_2;
    uVar11 = (uint)param_3;
  }
  FUN_00606ff0(&piStack_18,(uVar11 >> 2) + uVar11 * 0x40 + param_2 ^ uVar11,&param_2,
               -(uint)(iVar6 != 0) & iVar6 + 1U);
  piVar1 = piStack_18;
  uStack_34 = 0;
  puStack_30 = (undefined4 *)0x0;
  puStack_2c = (undefined4 *)0x0;
  uStack_8._0_1_ = 3;
  if (piStack_18 != (int *)0x0) {
    if (piStack_18[6] != 0) {
      LOCK();
      piVar9 = (int *)(piStack_18[6] + 4);
      *piVar9 = *piVar9 + 1;
      UNLOCK();
    }
    cVar5 = FUN_00bf46c0(param_4,param_5,piStack_18[5],piStack_18[6]);
    if (cVar5 == '\0') {
      param_3 = *(int **)piVar1[5];
      piStack_20 = (int *)((int *)piVar1[5])[1];
      if (param_3 != piStack_20) {
        do {
          iVar6 = *param_3;
          iVar7 = FUN_008881d0();
          if (iVar6 != iVar7) {
                    /* WARNING: Subroutine does not return */
            FUN_016757c0("Variant cast failed");
          }
          piVar9 = param_3 + 2;
          if (param_3[1] == 0) {
            piVar9 = (int *)0x0;
          }
          piStack_18 = (int *)piVar9[1];
          if (piStack_18 != (int *)0x0) {
            LOCK();
            piStack_18[1] = piStack_18[1] + 1;
            UNLOCK();
            piStack_18 = (int *)piVar9[1];
          }
          iStack_1c = *piVar9;
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          if (puStack_2c == puStack_30) {
            FUN_00bea500(puStack_30,&iStack_1c);
          }
          else {
            FUN_00bebf00(&uStack_34);
            puStack_30 = puStack_30 + 0x34;
          }
          piVar9 = piStack_18;
          uStack_8._0_1_ = 3;
          if (piStack_18 != (int *)0x0) {
            LOCK();
            iVar6 = piStack_18[1] + -1;
            piStack_18[1] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)*piStack_18)();
              LOCK();
              piVar3 = piVar9 + 2;
              iVar6 = *piVar3 + -1;
              *piVar3 = iVar6;
              UNLOCK();
              if (iVar6 == 0) {
                (**(code **)(*piVar9 + 4))();
              }
            }
          }
          param_3 = param_3 + 0x34;
        } while (param_3 != piStack_20);
      }
      FUN_00888650(&uStack_24);
      uStack_8._0_1_ = 5;
      uStack_3c = 0;
      uStack_38 = 0xf;
      auStack_4c[0] = auStack_4c[0] & 0xffffff00;
      FUN_005542c0(&DAT_018c1fd8,2);
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      iVar6 = FUN_005c4c00(auStack_4c);
      uVar8 = FUN_0088da50();
      *(undefined4 *)(iVar6 + 0x18) = uVar8;
      param_3 = (int *)FUN_005c9e80();
      uVar11 = *(uint *)(iVar6 + 0x1c);
      if ((int *)uVar11 == param_3) {
        *(undefined4 *)(iVar6 + 0x20) = param_4;
        *(int **)(iVar6 + 0x24) = param_5;
      }
      else {
        if (uVar11 != 0) {
          (**(code **)(uVar11 + 8))(iVar6 + 0x20);
        }
        *(undefined4 *)(iVar6 + 0x20) = param_4;
        *(int **)(iVar6 + 0x24) = param_5;
        *(int **)(iVar6 + 0x1c) = param_3;
      }
      uStack_8._0_1_ = 5;
      if (0xf < uStack_38) {
        uVar10 = uStack_38 + 1;
        uVar11 = auStack_4c[0];
        if (0xfff < uVar10) {
          uVar11 = *(uint *)(auStack_4c[0] - 4);
          uVar10 = uStack_38 + 0x24;
          if (0x1f < (auStack_4c[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar11,uVar10);
      }
      uStack_3c = 0;
      uStack_38 = 0xf;
      auStack_4c[0] = auStack_4c[0] & 0xffffff00;
      FUN_005542c0(&DAT_018c387c,4);
      puVar12 = &param_6;
      uStack_8._0_1_ = 7;
      FUN_005c4c00(auStack_4c);
      FUN_005c16d0(puVar12);
      uStack_8._0_1_ = 5;
      uVar4 = (undefined)uStack_8;
      uStack_8._0_1_ = 5;
      if (0xf < uStack_38) {
        uVar10 = uStack_38 + 1;
        uVar11 = auStack_4c[0];
        if (0xfff < uVar10) {
          uVar11 = *(uint *)(auStack_4c[0] - 4);
          uVar10 = uStack_38 + 0x24;
          if (0x1f < (auStack_4c[0] - uVar11) - 4) {
            uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar11,uVar10);
      }
      uStack_3c = 0;
      uStack_38 = 0xf;
      auStack_4c[0] = auStack_4c[0] & 0xffffff00;
      FUN_005542c0("displayName",0xb);
      puVar12 = &stack0x0000002c;
      uStack_8._0_1_ = 8;
      FUN_005c4c00(auStack_4c);
      FUN_005c16d0(puVar12);
      uStack_8._0_1_ = 5;
      uVar4 = (undefined)uStack_8;
      uStack_8._0_1_ = 5;
      if (0xf < uStack_38) {
        uVar10 = uStack_38 + 1;
        uVar11 = auStack_4c[0];
        if (0xfff < uVar10) {
          uVar11 = *(uint *)(auStack_4c[0] - 4);
          uVar10 = uStack_38 + 0x24;
          if (0x1f < (auStack_4c[0] - uVar11) - 4) {
            uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar11,uVar10);
      }
      param_5 = (int *)CONCAT13(1,param_5._0_3_);
      uStack_3c = 0;
      uStack_38 = 0xf;
      auStack_4c[0] = auStack_4c[0] & 0xffffff00;
      FUN_005542c0("isOnline",8);
      iVar6 = (int)&param_5 + 3;
      uStack_8._0_1_ = 9;
      FUN_005c4c00(auStack_4c);
      FUN_005e52b0(iVar6);
      uStack_8._0_1_ = 5;
      uVar4 = (undefined)uStack_8;
      uStack_8._0_1_ = 5;
      if (0xf < uStack_38) {
        uVar10 = uStack_38 + 1;
        uVar11 = auStack_4c[0];
        if (0xfff < uVar10) {
          uVar11 = *(uint *)(auStack_4c[0] - 4);
          uVar10 = uStack_38 + 0x24;
          if (0x1f < (auStack_4c[0] - uVar11) - 4) {
            uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar11,uVar10);
      }
      param_5 = (int *)((uint)param_5 & 0xffffff);
      uStack_3c = 0;
      uStack_38 = 0xf;
      auStack_4c[0] = auStack_4c[0] & 0xffffff00;
      FUN_005542c0("isDeleted",9);
      iVar6 = (int)&param_5 + 3;
      uStack_8._0_1_ = 10;
      FUN_005c4c00(auStack_4c);
      FUN_005e52b0(iVar6);
      uStack_8._0_1_ = 5;
      uVar4 = (undefined)uStack_8;
      uStack_8._0_1_ = 5;
      if (0xf < uStack_38) {
        uVar10 = uStack_38 + 1;
        uVar11 = auStack_4c[0];
        if (0xfff < uVar10) {
          uVar11 = *(uint *)(auStack_4c[0] - 4);
          uVar10 = uStack_38 + 0x24;
          if (0x1f < (auStack_4c[0] - uVar11) - 4) {
            uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar11,uVar10);
      }
      param_5 = (int *)((uint)param_5 & 0xffffff);
      uStack_3c = 0;
      uStack_38 = 0xf;
      auStack_4c[0] = auStack_4c[0] & 0xffffff00;
      FUN_005542c0("isBanned",8);
      iVar6 = (int)&param_5 + 3;
      uStack_8._0_1_ = 0xb;
      FUN_005c4c00(auStack_4c);
      FUN_005e52b0(iVar6);
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      if (0xf < uStack_38) {
        uVar10 = uStack_38 + 1;
        uVar11 = auStack_4c[0];
        if (0xfff < uVar10) {
          uVar11 = *(uint *)(auStack_4c[0] - 4);
          uVar10 = uStack_38 + 0x24;
          if (0x1f < (auStack_4c[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar11,uVar10);
      }
      puVar12 = puStack_30;
      param_5 = puStack_30;
      if (puStack_2c == puStack_30) {
        FUN_00bea670(puStack_30,&uStack_24);
        piVar9 = piStack_20;
      }
      else {
        uVar8 = FUN_008881d0();
        piVar9 = piStack_20;
        *puVar12 = uVar8;
        puVar12[1] = 0;
        puVar12[2] = 0;
        puVar12[3] = 0;
        if (piStack_20 != (int *)0x0) {
          LOCK();
          piStack_20[1] = piStack_20[1] + 1;
          UNLOCK();
        }
        param_5[2] = uStack_24;
        param_5[3] = (int)piStack_20;
        uVar8 = FUN_005ea820();
        param_5[1] = uVar8;
        puStack_30 = puStack_30 + 0x34;
      }
      param_5 = (int *)FUN_01674e20(0x18);
      uStack_8._0_1_ = 0xc;
      if (param_5 == (undefined4 *)0x0) {
        param_5 = (undefined4 *)0x0;
      }
      else {
        param_5[1] = 1;
        param_5[2] = 1;
        *param_5 = (int)std::
                        _Ref_count_obj<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>
                        ::vftable;
        FUN_006d07c0(&uStack_34);
      }
      piVar1[5] = (int)(param_5 + 3);
      piVar3 = (int *)piVar1[6];
      piVar1[6] = (int)param_5;
      param_5 = piVar3;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar6 = piVar3[1] + -1;
        piVar3[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar6 = param_5[2] + -1;
          param_5[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*param_5 + 4))();
          }
        }
      }
      if (piVar9 != (int *)0x0) {
        LOCK();
        iVar6 = piVar9[1] + -1;
        piVar9[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar9)();
          LOCK();
          piVar1 = piVar9 + 2;
          iVar6 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar6 == 1) {
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
    }
  }
  uStack_8._0_1_ = 0xd;
  FUN_00577b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  iVar6 = FUN_016deec8(piVar2);
  if (iVar6 != 0) {
    FUN_016df3c9(iVar6);
  }
  if (0xf < in_stack_00000028) {
    uVar10 = in_stack_00000028 + 1;
    uVar11 = param_6;
    if (0xfff < uVar10) {
      uVar11 = *(uint *)(param_6 - 4);
      uVar10 = in_stack_00000028 + 0x24;
      if (0x1f < (param_6 - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar10);
  }
  in_stack_00000024 = 0;
  in_stack_00000028 = 0xf;
  param_6 = param_6 & 0xffffff00;
  if (0xf < in_stack_00000040) {
    uVar11 = in_stack_00000040 + 1;
    iVar6 = in_stack_0000002c;
    if (0xfff < uVar11) {
      iVar6 = *(int *)(in_stack_0000002c + -4);
      uVar11 = in_stack_00000040 + 0x24;
      if (0x1f < (in_stack_0000002c - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar11);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26813 ; VA 0x00bf0a20 ; FUN_00bf0a20 */

void __thiscall
FUN_00bf0a20(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 param_10,undefined4 param_11,undefined8 param_12,uint param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined4 param_18,undefined8 param_19)

{
  undefined uVar1;
  int iVar2;
  longlong lVar3;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined8 uStack_b0;
  undefined auStack_a8 [48];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_5c;
  undefined4 *puStack_58;
  undefined4 *puStack_54;
  undefined4 *puStack_50;
  uint uStack_4c;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 *puStack_38;
  undefined8 uStack_34;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018032e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (DAT_01d68044 != '\0') {
    uStack_34 = CONCAT44(param_1,0xbf0a5f);
    ExceptionList = &pvStack_10;
    iVar2 = FUN_0064e810();
    if ((iVar2 != 0) && (*(int *)(iVar2 + 0xf4) != 0)) {
      uStack_34 = CONCAT44(0xbf0a79,(undefined4)uStack_34);
      lVar3 = FUN_00928340();
      uVar1 = DAT_01ef7639;
      if (lVar3 == CONCAT44(param_5,param_4)) {
        puStack_50 = &param_13;
        puStack_54 = (undefined4 *)0xbf0a9b;
        FUN_0054f510();
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        uStack_70 = 0;
        FUN_0054f510(&param_6);
        FUN_00beba60(auStack_a8,FUN_00bf6f80,0,param_1,param_2,param_3,uVar1);
        uStack_b0 = CONCAT44(0xbf0adc,(undefined4)uStack_b0);
        FUN_00be9df0();
        uStack_70 = param_5;
        uStack_74 = param_4;
        goto LAB_00bf0bb9;
      }
    }
  }
  uVar1 = DAT_01ef7639;
  uStack_4c = 0;
  if (param_13 != 0) {
    uStack_4c = param_13;
    if ((param_13 & 1) == 0) {
      puStack_54 = &uStack_44;
      puStack_50 = (undefined4 *)0x0;
      puStack_58 = &param_15;
      uStack_5c = 0xbf0b36;
      (**(code **)(param_13 & 0xfffffffe))();
    }
    else {
      uStack_44 = param_15;
      uStack_40 = param_16;
      uStack_3c = param_17;
      puStack_38 = (undefined4 *)param_18;
      uStack_34 = param_19;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_70 = 0;
  if (param_6 != 0) {
    if ((param_6 & 1) == 0) {
      (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_c0,0);
    }
    else {
      uStack_c0 = param_8;
      uStack_bc = param_9;
      uStack_b8 = param_10;
      uStack_b4 = param_11;
      uStack_b0 = param_12;
    }
  }
  FUN_00beba60(auStack_a8,FUN_00bf6f80,0,param_1,param_4,param_5,uVar1);
  uStack_b0 = CONCAT44(0xbf0bb1,(undefined4)uStack_b0);
  FUN_00be9df0();
  uStack_70 = param_3;
  uStack_74 = param_2;
LAB_00bf0bb9:
  uStack_8._0_1_ = 1;
  uStack_78 = 0xbf0bc2;
  FUN_00bf2850();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (param_6 != 0) {
    if (((param_6 & 1) == 0) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0)) {
      puStack_38 = &param_8;
      uStack_34 = CONCAT44(2,puStack_38);
      uStack_3c = 0xbf0be3;
      (**(code **)(param_6 & 0xfffffffe))();
    }
    param_6 = 0;
  }
  uStack_8 = 5;
  if (((param_13 != 0) && ((param_13 & 1) == 0)) &&
     (*(code **)(param_13 & 0xfffffffe) != (code *)0x0)) {
    puStack_38 = &param_15;
    uStack_34 = CONCAT44(2,puStack_38);
    uStack_3c = 0xbf0c11;
    (**(code **)(param_13 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26814 ; VA 0x00bf0c30 ; FUN_00bf0c30 */

void FUN_00bf0c30(undefined4 param_1,code *param_2,undefined4 param_3,uint *param_4,uint *param_5)

{
  uint uVar1;
  uint *puVar2;
  uint *puVar3;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  undefined8 uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_7c;
  uint *puStack_78;
  uint *puStack_74;
  undefined4 uStack_70;
  uint auStack_6c [2];
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined8 uStack_54;
  uint uStack_3c;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined *puStack_1c;
  undefined *puStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7df0;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined *)auStack_6c;
  puStack_1c = (undefined *)auStack_6c;
  pcStack_14 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ef7639);
  auStack_6c[0] = 0;
  uVar1 = *param_5;
  ExceptionList = &pvStack_10;
  puVar2 = auStack_6c;
  puVar3 = auStack_6c;
  if (uVar1 != 0) {
    auStack_6c[0] = uVar1;
    if ((uVar1 & 1) == 0) {
      puStack_74 = &uStack_64;
      uStack_70 = 0;
      puStack_78 = param_5 + 2;
      uStack_7c = 0xbf0ca7;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))();
      puVar2 = (uint *)puStack_1c;
      puVar3 = (uint *)puStack_18;
    }
    else {
      uStack_64 = param_5[2];
      uStack_60 = param_5[3];
      uStack_5c = param_5[4];
      uStack_58 = param_5[5];
      uStack_54 = *(undefined8 *)(param_5 + 6);
      ExceptionList = &pvStack_10;
      puVar2 = auStack_6c;
      puVar3 = auStack_6c;
    }
  }
  puStack_18 = (undefined *)puVar3;
  puStack_1c = (undefined *)puVar2;
  uStack_8 = 0;
  uStack_90 = param_1;
  uVar1 = *param_4;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_4 + 2);
    }
    else {
      uStack_a8 = param_4[2];
      uStack_a4 = param_4[3];
      uStack_a0 = param_4[4];
      uStack_9c = param_4[5];
      uStack_98 = *(undefined8 *)(param_4 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_90 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_3c != 0) {
    if ((uStack_3c & 1) == 0) {
      (**(code **)(uStack_3c & 0xfffffffe))(&uStack_34,&uStack_a8,0);
    }
    else {
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
      uStack_98 = uStack_24;
    }
  }
  FUN_00912d50();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_3c != 0) && ((uStack_3c & 1) == 0)) &&
     (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
    uStack_90 = 2;
    uStack_98 = CONCAT44(&uStack_34,&uStack_34);
    uStack_9c = 0xbf0d89;
    (**(code **)(uStack_3c & 0xfffffffe))();
  }
  uStack_8 = 0xffffffff;
  uStack_90 = 0xbf0da3;
  (*pcStack_14)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26815 ; VA 0x00bf0dc0 ; FUN_00bf0dc0 */

void __thiscall FUN_00bf0dc0(int param_1,int param_2,uint param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  uint uStack_20;
  int *piStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  iVar3 = FUN_016dee6d(param_1 + 0x8c);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  iVar3 = param_2;
  iVar6 = param_1 + 0x75 + (uint)*(byte *)(param_1 + 0x74);
  if (((int)param_3 < 1) && ((int)param_3 < 0)) {
    uStack_14 = -param_3 - 1;
  }
  else {
    uStack_14 = param_3;
  }
  FUN_00606ff0(&uStack_20,(uStack_14 >> 2) + uStack_14 * 0x40 + param_2 ^ uStack_14,&param_2,
               -(uint)(iVar6 != 0) & iVar6 + 1U);
  iVar6 = iStack_18;
  if (((uStack_20 != 0) && (*(int *)(uStack_20 + 0x40) == *(int *)(uStack_20 + 0x44))) &&
     (*(int *)(iStack_18 + 0x7c) != 0)) {
    uStack_14 = param_3;
    if (((int)param_3 < 1) && ((int)param_3 < 0)) {
      uStack_14 = -param_3 - 1;
    }
    uStack_14 = (uStack_14 >> 2) + uStack_14 * 0x40 + iVar3 ^ uStack_14;
    uStack_20 = uStack_14 % *(uint *)(iStack_18 + 0x78);
    iVar1 = uStack_20 * 4;
    piStack_1c = *(int **)(iVar1 + *(int *)(iStack_18 + 0x88));
    if ((piStack_1c != (int *)0x0) &&
       (piVar2 = (int *)*piStack_1c, (int *)*piStack_1c != (int *)0x0)) {
      while (piVar5 = piVar2, piVar2 = piStack_1c,
            (uint)piVar5[1] % *(uint *)(iStack_18 + 0x78) == uStack_20) {
        if (((piVar5[1] == uStack_14) && (iVar3 == piVar5[2])) && (param_3 == piVar5[3])) {
          FUN_00bf1770(piStack_1c,*piVar5);
          if (*piVar2 != 0) {
            uVar7 = *(uint *)(*piVar2 + 4) % *(uint *)(iVar6 + 0x78);
            if (uStack_20 == uVar7) break;
            *(int **)(*(int *)(iVar6 + 0x88) + uVar7 * 4) = piVar2;
          }
          puVar4 = (undefined4 *)(*(int *)(iVar6 + 0x88) + iVar1);
          if ((int *)*puVar4 == piVar2) {
            *puVar4 = 0;
          }
          break;
        }
        piVar2 = (int *)*piVar5;
        piStack_1c = piVar5;
        if ((int *)*piVar5 == (int *)0x0) break;
      }
    }
  }
  uStack_8 = 0;
  iVar3 = FUN_016deec8(param_1 + 0x8c);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26816 ; VA 0x00bf0f80 ; FUN_00bf0f80 */

void __thiscall FUN_00bf0f80(int param_1,int param_2,uint param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int *piVar6;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_016dee6d(param_1 + 0xd4);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  iVar3 = param_1 + 0xbd + (uint)*(byte *)(param_1 + 0xbc);
  uVar4 = param_3;
  if (((int)param_3 < 1) && ((int)param_3 < 0)) {
    uVar4 = -param_3 - 1;
  }
  FUN_00606ff0(&piStack_14,(uVar4 >> 2) + uVar4 * 0x40 + param_2 ^ uVar4,&param_2,
               -(uint)(iVar3 != 0) & iVar3 + 1U);
  if ((piStack_14 != (int *)0x0) && (piStack_14[0x10] == piStack_14[0x11])) {
    uVar4 = (uint)piStack_14[1] % *(uint *)(param_1 + 0xc0);
    piVar1 = *(int **)(*(int *)(param_1 + 0xd0) + uVar4 * 4);
    for (piVar6 = (int *)*piVar1; piVar2 = (int *)*piStack_14, piVar6 != piStack_14;
        piVar6 = (int *)*piVar6) {
      piVar1 = piVar6;
    }
    do {
      piStack_14 = piVar2;
      *piVar1 = *piVar6;
      FUN_00bee640();
      FUN_01674ea0(piVar6,0x50);
      *(int *)(param_1 + 0xc4) = *(int *)(param_1 + 0xc4) + -1;
      uVar5 = uVar4;
      if (*piVar1 == 0) {
LAB_00bf10b0:
        if (*(int **)(*(int *)(param_1 + 0xd0) + uVar4 * 4) == piVar1) {
          *(undefined4 *)(*(int *)(param_1 + 0xd0) + uVar4 * 4) = 0;
        }
      }
      else {
        uVar5 = *(uint *)(*piVar1 + 4) % *(uint *)(param_1 + 0xc0);
        if (uVar4 != uVar5) {
          *(int **)(*(int *)(param_1 + 0xd0) + uVar5 * 4) = piVar1;
          goto LAB_00bf10b0;
        }
      }
      piVar6 = (int *)*piVar1;
      uVar4 = uVar5;
      piVar2 = piStack_14;
    } while (piVar6 != piStack_14);
  }
  uStack_8 = 0;
  iVar3 = FUN_016deec8(param_1 + 0xd4);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26817 ; VA 0x00bf1100 ; FUN_00bf1100 */

undefined4 * __thiscall
FUN_00bf1100(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01803321;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00922b20;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 26818 ; VA 0x00bf12a0 ; FUN_00bf12a0 */

undefined4 * __thiscall
FUN_00bf12a0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01803361;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00bf17c0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 26819 ; VA 0x00bf1450 ; FUN_00bf1450 */

undefined4 * __thiscall
FUN_00bf1450(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018033a1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00bf1930;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 26820 ; VA 0x00bf1600 ; FUN_00bf1600 */

void FUN_00bf1600(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00bfa7a0();
    *param_2 = uVar3;
    iVar4 = FUN_009361b0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 26821 ; VA 0x00bf1660 ; FUN_00bf1660 */

void FUN_00bf1660(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00bfa7a0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 26822 ; VA 0x00bf16a0 ; FUN_00bf16a0 */

bool __thiscall FUN_00bf16a0(byte *param_1,int *param_2)

{
  uint uVar1;
  
  uVar1 = param_2[1];
  if (((int)uVar1 < 1) && ((int)uVar1 < 0)) {
    uVar1 = ~uVar1;
  }
  FUN_00606ff0(&param_2,(uVar1 >> 2) + uVar1 * 0x40 + *param_2 ^ uVar1,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  return param_2 != (int *)0x0;
}



/* FUNCTION 26823 ; VA 0x00bf1700 ; FUN_00bf1700 */

undefined4 * FUN_00bf1700(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00671780(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 26824 ; VA 0x00bf1770 ; FUN_00bf1770 */

int __thiscall FUN_00bf1770(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_00bee640();
    FUN_01674ea0(puVar1,0x50);
    iVar2 = iVar2 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar1 = (undefined4 *)*param_2;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 26825 ; VA 0x00bf17c0 ; FUN_00bf17c0 */

void FUN_00bf17c0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e104f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_290 = FUN_0088da50();
  uStack_288 = param_2;
  uStack_28c = 0;
  uStack_284 = param_3;
  uStack_28c = FUN_005c9e80();
  iStack_8._0_1_ = 1;
  uStack_1c0 = FUN_0088da50();
  uStack_1b8 = param_4;
  uStack_1bc = 0;
  uStack_1b4 = param_5;
  uStack_1bc = FUN_005c9e80();
  iStack_8._0_1_ = 2;
  uStack_f0 = FUN_00bfa7a0();
  uStack_ec = 0;
  uStack_e8 = param_6;
  uStack_ec = FUN_009361b0();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_290,&uStack_20,piVar1);
  iStack_8._0_1_ = 4;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 5;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  iStack_8 = 6;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26826 ; VA 0x00bf1930 ; FUN_00bf1930 */

void FUN_00bf1930(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e104f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_290 = FUN_0088da50();
  uStack_288 = param_2;
  uStack_28c = 0;
  uStack_284 = param_3;
  uStack_28c = FUN_005c9e80();
  iStack_8._0_1_ = 1;
  uStack_1c0 = FUN_0088da50();
  uStack_1b8 = param_4;
  uStack_1bc = 0;
  uStack_1b4 = param_5;
  uStack_1bc = FUN_005c9e80();
  iStack_8._0_1_ = 2;
  uStack_f0 = FUN_00935e70();
  uStack_ec = 0;
  uStack_e8 = param_6;
  uStack_ec = FUN_00936220();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_290,&uStack_20,piVar1);
  iStack_8._0_1_ = 4;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 5;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  iStack_8 = 6;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26827 ; VA 0x00bf1aa0 ; FUN_00bf1aa0 */

void FUN_00bf1aa0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  (**(code **)(param_1 + 0x18))(param_2,param_3,param_4,param_5,param_6);
  return;
}



/* FUNCTION 26828 ; VA 0x00bf1ad0 ; FUN_00bf1ad0 */

void __thiscall FUN_00bf1ad0(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  uint in_stack_0000002c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3d80;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_00bf0c30(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&param_4,
               &stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 3;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26829 ; VA 0x00bf1b70 ; FUN_00bf1b70 */

void FUN_00bf1b70(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  code *pcVar1;
  undefined4 uStack_298;
  undefined4 uStack_294;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f12e7;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  uStack_24 = 0;
  ExceptionList = &pvStack_10;
  FUN_00be37a0(param_2,param_3,param_4,param_5,param_6);
  pcVar1 = *(code **)(*param_1 + 8);
  uStack_298 = FUN_0088da50();
  uStack_294 = 0;
  uStack_290 = param_2;
  uStack_28c = param_3;
  uStack_294 = FUN_005c9e80();
  uStack_8 = 0;
  uStack_1c8 = FUN_0088da50();
  uStack_1c0 = param_4;
  uStack_1c4 = 0;
  uStack_1bc = param_5;
  uStack_1c4 = FUN_005c9e80();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_f8 = FUN_00935e70();
  uStack_f4 = 0;
  uStack_f0 = param_6;
  uStack_f4 = FUN_00936220();
  uStack_8 = 2;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_298,&uStack_28,param_1);
  uStack_8._0_1_ = 3;
  (*pcVar1)(uStack_14,&uStack_20,&uStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00577b20();
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_298,0xd0,3,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26830 ; VA 0x00bf1ce0 ; FUN_00bf1ce0 */

void FUN_00bf1ce0(undefined4 param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  int *piVar8;
  
  iVar1 = *param_2;
  iVar7 = *(int *)(iVar1 + 0x1a0);
  iVar5 = FUN_00bfa7a0();
  if (iVar7 == iVar5) {
    puVar6 = (undefined4 *)(iVar1 + 0x1a8);
    iVar7 = *param_2;
    if (*(int *)(iVar1 + 0x1a4) == 0) {
      puVar6 = (undefined4 *)0x0;
    }
    iVar1 = *(int *)(iVar7 + 0xd0);
    uVar2 = *puVar6;
    iVar5 = FUN_0088da50();
    if (iVar1 == iVar5) {
      puVar6 = (undefined4 *)(iVar7 + 0xd8);
      param_2 = (int *)*param_2;
      if (*(int *)(iVar7 + 0xd4) == 0) {
        puVar6 = (undefined4 *)0x0;
      }
      iVar1 = *param_2;
      uVar3 = *puVar6;
      uVar4 = puVar6[1];
      iVar7 = FUN_0088da50();
      if (iVar1 == iVar7) {
        piVar8 = param_2 + 2;
        if (param_2[1] == 0) {
          piVar8 = (int *)0x0;
        }
        FUN_00be37a0(*piVar8,piVar8[1],uVar3,uVar4,uVar2);
        return;
      }
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 26831 ; VA 0x00bf1d90 ; FUN_00bf1d90 */

void FUN_00bf1d90(undefined4 param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  int *piVar8;
  
  iVar1 = *param_2;
  iVar7 = *(int *)(iVar1 + 0x1a0);
  iVar5 = FUN_00935e70();
  if (iVar7 == iVar5) {
    puVar6 = (undefined4 *)(iVar1 + 0x1a8);
    iVar7 = *param_2;
    if (*(int *)(iVar1 + 0x1a4) == 0) {
      puVar6 = (undefined4 *)0x0;
    }
    iVar1 = *(int *)(iVar7 + 0xd0);
    uVar2 = *puVar6;
    iVar5 = FUN_0088da50();
    if (iVar1 == iVar5) {
      puVar6 = (undefined4 *)(iVar7 + 0xd8);
      param_2 = (int *)*param_2;
      if (*(int *)(iVar7 + 0xd4) == 0) {
        puVar6 = (undefined4 *)0x0;
      }
      iVar1 = *param_2;
      uVar3 = *puVar6;
      uVar4 = puVar6[1];
      iVar7 = FUN_0088da50();
      if (iVar1 == iVar7) {
        piVar8 = param_2 + 2;
        if (param_2[1] == 0) {
          piVar8 = (int *)0x0;
        }
        FUN_00be37a0(*piVar8,piVar8[1],uVar3,uVar4,uVar2);
        return;
      }
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 26832 ; VA 0x00bf1e40 ; FUN_00bf1e40 */

void __thiscall
FUN_00bf1e40(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int iVar1;
  
  iVar1 = FUN_0064e810(param_1);
  if (iVar1 != 0) {
    FUN_0097c690(param_2,param_3,param_4,param_5,param_6);
  }
  return;
}



/* FUNCTION 26833 ; VA 0x00bf1e70 ; FUN_00bf1e70 */

void __thiscall
FUN_00bf1e70(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,int param_6)

{
  char cVar1;
  int iVar2;
  
  cVar1 = FUN_00971ce0(param_1,0);
  if (cVar1 == '\0') {
    FUN_00bfa730(param_2,param_3,param_4,param_5,param_6);
  }
  iVar2 = FUN_0064e810(param_1);
  if (iVar2 != 0) {
    FUN_0097c890(param_2,param_3,param_4,param_5,param_6);
    if (param_6 == 3) {
      param_6 = 4;
    }
    else if (param_6 == 4) {
      param_6 = 3;
    }
    FUN_0097c890(param_4,param_5,param_2,param_3,param_6);
  }
  return;
}



/* FUNCTION 26834 ; VA 0x00bf1ef0 ; FUN_00bf1ef0 */

undefined4 __thiscall
FUN_00bf1ef0(int param_1,undefined4 param_2,int param_3,undefined4 param_4,int param_5)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 uStack_14;
  int iStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  if ((-1 < param_3) && (-1 < param_5)) {
    iStack_8 = param_5;
    uStack_14 = param_2;
    iVar2 = param_1 + 0x105 + (uint)*(byte *)(param_1 + 0x104);
    iStack_10 = param_3;
    uStack_c = param_4;
    uVar3 = -(uint)(iVar2 != 0) & iVar2 + 1U;
    puVar4 = &uStack_14;
    uVar1 = FUN_00bf3620(puVar4);
    FUN_00a29a20(&param_3,uVar1,puVar4,uVar3);
    if (param_3 == 0) {
      return 0;
    }
    return *(undefined4 *)(param_3 + 0x18);
  }
  return 1;
}



/* FUNCTION 26835 ; VA 0x00bf1f90 ; FUN_00bf1f90 */

void __thiscall
FUN_00bf1f90(undefined **param_1,undefined *param_2,uint param_3,uint param_4,uint param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined8 param_11,undefined4 *param_12,undefined4 param_13,
            undefined **param_14,undefined *param_15,undefined4 param_16,undefined4 param_17,
            undefined8 param_18)

{
  undefined *puVar1;
  int *piVar2;
  undefined **ppuVar3;
  int *piVar4;
  char **ppcVar5;
  undefined **ppuVar6;
  char cVar7;
  double *pdVar8;
  undefined4 *puVar9;
  undefined *puVar10;
  undefined **ppuVar11;
  int iVar12;
  uint uVar13;
  double dVar14;
  undefined4 *in_stack_fffffcf8;
  undefined ***in_stack_fffffcfc;
  undefined4 uVar15;
  undefined *puStack_2fc;
  uint uStack_2f8;
  undefined4 *puStack_2f4;
  undefined4 **ppuStack_2f0;
  undefined **ppuStack_2ec;
  undefined *puStack_2e8;
  undefined4 uStack_2e4;
  undefined4 uStack_2e0;
  undefined8 uStack_2dc;
  undefined4 uStack_2cc;
  char *pcStack_2c8;
  undefined *puStack_2c4;
  uint uStack_2c0;
  undefined **ppuStack_2bc;
  undefined **ppuStack_2b8;
  undefined4 *puStack_2b4;
  undefined4 ***pppuStack_2b0;
  undefined **ppuStack_2ac;
  int aiStack_2a0 [22];
  int aiStack_248 [22];
  int aiStack_1f0 [22];
  int aiStack_198 [22];
  int aiStack_140 [22];
  undefined4 auStack_e8 [6];
  undefined **ppuStack_d0;
  undefined uStack_cc;
  undefined4 uStack_c8;
  int iStack_c4;
  undefined4 ***apppuStack_c0 [4];
  undefined4 uStack_b0;
  uint uStack_ac;
  undefined *puStack_a4;
  undefined *puStack_a0;
  undefined4 *puStack_9c;
  undefined4 uStack_98;
  undefined *puStack_8c;
  uint uStack_88;
  uint uStack_84;
  uint uStack_7c;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined8 uStack_64;
  undefined4 *puStack_5c;
  int *piStack_54;
  undefined *puStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined *puStack_3c;
  int *piStack_38;
  undefined8 uStack_34;
  undefined auStack_2c [4];
  int iStack_28;
  undefined **ppuStack_24;
  undefined *puStack_20;
  int *piStack_1c;
  undefined *puStack_18;
  undefined **ppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01803465;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ppuStack_24 = param_1;
  if ((int)param_4 < 0) {
    puStack_2c4 = (undefined *)0x38;
    pppuStack_2b0 = (undefined4 ***)0x0;
    ppuStack_2ac = (undefined **)0xf;
    pcStack_2c8 = "GetFriendsOnline maxFriends argument can not be negative";
    uStack_2c0 = uStack_2c0 & 0xffffff00;
    uStack_2cc = 0xbf1fe4;
    ExceptionList = &pvStack_10;
    FUN_005542c0();
    puStack_2c4 = (undefined *)0xbf1fec;
    FUN_005e65e0();
    goto LAB_00bf25bf;
  }
  ppuVar3 = param_1 + 0x35;
  pppuStack_2b0 = (undefined4 ***)0xbf2003;
  ExceptionList = &pvStack_10;
  ppuStack_2ac = ppuVar3;
  ppuStack_d0 = ppuVar3;
  ppuStack_2ac = (undefined **)FUN_016dee6d();
  if (ppuStack_2ac != (undefined **)0x0) {
    pppuStack_2b0 = (undefined4 ***)0xbf2010;
    FUN_016df3c9();
  }
  ppuStack_14 = param_1 + 0x2f;
  iVar12 = (int)param_1 + *(byte *)(param_1 + 0x2f) + 0xbd;
  uStack_8._0_1_ = 2;
  ppuStack_2ac = (undefined **)(-(uint)(iVar12 != 0) & iVar12 + 1U);
  puStack_20 = param_2;
  uVar13 = param_3;
  if (((int)param_3 < 1) && ((int)param_3 < 0)) {
    puStack_20 = (undefined *)(-1 - (int)param_2);
    uVar13 = -param_3 - 1;
  }
  pppuStack_2b0 = (undefined4 ***)&param_2;
  puStack_2b4 = (undefined4 *)((uint)(param_2 + (uVar13 >> 2) + uVar13 * 0x40) ^ uVar13);
  ppuStack_2b8 = &puStack_18;
  ppuStack_2bc = (undefined **)0xbf207d;
  FUN_00606ff0();
  puVar10 = puStack_18;
  if (puStack_18 == (undefined *)0x0) {
LAB_00bf2179:
    ppuStack_2ac = &puStack_20;
    pppuStack_2b0 = (undefined4 ***)0xbf2182;
    puVar9 = (undefined4 *)FUN_01682800();
    ppuStack_2ac = (undefined **)puVar9[1];
    pppuStack_2b0 = (undefined4 ***)*puVar9;
    ppuStack_2b8 = (undefined **)0x0;
    puStack_2b4 = (undefined4 *)0x0;
    ppuStack_2bc = (undefined **)0xbf21a7;
    FUN_00bedef0();
    ppuStack_2ac = (undefined **)&param_12;
    uStack_8._0_1_ = 5;
    pppuStack_2b0 = (undefined4 ***)&param_5;
    puStack_2b4 = &uStack_74;
    ppuStack_2b8 = (undefined **)0xbf21bc;
    ppuStack_2ac = (undefined **)FUN_00bec580();
    uStack_8._0_1_ = 6;
    pppuStack_2b0 = (undefined4 ***)0xbf21cf;
    FUN_00bec000();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    ppuStack_2ac = (undefined **)0xbf21db;
    FUN_008c3510();
    ppuStack_2ac = &param_2;
    pppuStack_2b0 = (undefined4 ***)0xbf21e7;
    iVar12 = FUN_00beebc0();
    *(undefined *)(iVar12 + 8) = uStack_cc;
    ppuStack_14 = (undefined **)(iVar12 + 8);
    if (iStack_c4 != 0) {
      LOCK();
      *(int *)(iStack_c4 + 4) = *(int *)(iStack_c4 + 4) + 1;
      UNLOCK();
    }
    *(undefined4 *)(iVar12 + 0xc) = uStack_c8;
    piVar4 = *(int **)(iVar12 + 0x10);
    *(int *)(iVar12 + 0x10) = iStack_c4;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar12 = piVar4[1] + -1;
      piVar4[1] = iVar12;
      UNLOCK();
      if (iVar12 == 0) {
        ppuStack_2ac = (undefined **)0xbf222d;
        (**(code **)*piVar4)();
        LOCK();
        iVar12 = piVar4[2] + -1;
        piVar4[2] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          ppuStack_2ac = (undefined **)0xbf223e;
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if ((undefined4 ****)(ppuStack_14 + 3) != apppuStack_c0) {
      ppuStack_2ac = (undefined **)uStack_b0;
      pppuStack_2b0 = apppuStack_c0;
      if (0xf < uStack_ac) {
        pppuStack_2b0 = apppuStack_c0[0];
      }
      puStack_2b4 = (undefined4 *)0xbf2268;
      FUN_005542c0();
    }
    ppuStack_14[10] = puStack_a4;
    ppuStack_14[0xb] = puStack_a0;
    if ((undefined4 **)(ppuStack_14 + 0xc) != &puStack_9c) {
      ppuStack_2ac = (undefined **)param_4;
      pppuStack_2b0 = (undefined4 ***)uStack_98;
      puStack_2b4 = puStack_9c;
      ppuStack_2b8 = (undefined **)0xbf229e;
      FUN_00bea2a0();
    }
    ppuStack_2ac = ppuStack_24;
    pppuStack_2b0 = (undefined4 ***)0xbf22a6;
    iStack_28 = FUN_0064e700();
    puVar10 = param_2;
    if (iStack_28 != 0) {
      ppuStack_2ac = (undefined **)param_3;
      puStack_2b4 = auStack_e8;
      pppuStack_2b0 = (undefined4 ***)param_2;
      ppuStack_2b8 = (undefined **)0xbf22c7;
      FUN_00f82a00();
      ppuStack_2b8 = ppuStack_24;
      ppuStack_2bc = &puStack_20;
      uStack_8._0_1_ = 7;
      uStack_2c0 = 0xbf22d7;
      FUN_0068f9a0();
      ppuStack_24 = &pcStack_2c8;
      uStack_8._0_1_ = 8;
      uStack_34 = (double)CONCAT44(&pcStack_2c8,(undefined4)uStack_34);
      uStack_2cc = 0;
      puStack_18 = (undefined *)&puStack_2fc;
      puStack_2fc = puVar10;
      uStack_2f8 = param_3;
      puStack_2f4 = (undefined4 *)0x0;
      ppcVar5 = &pcStack_2c8;
      ppuVar11 = &puStack_2fc;
      if (param_12 != (undefined4 *)0x0) {
        puStack_2f4 = param_12;
        if (((uint)param_12 & 1) == 0) {
          in_stack_fffffcfc = &ppuStack_2ec;
          in_stack_fffffcf8 = &param_14;
          (**(code **)((uint)param_12 & 0xfffffffe))(in_stack_fffffcf8,in_stack_fffffcfc,0);
          ppcVar5 = ppuStack_24;
          ppuVar11 = (undefined **)puStack_18;
        }
        else {
          ppuStack_2ec = param_14;
          puStack_2e8 = param_15;
          uStack_2e4 = param_16;
          uStack_2e0 = param_17;
          uStack_2dc = param_18;
          ppcVar5 = &pcStack_2c8;
          ppuVar11 = &puStack_2fc;
        }
      }
      puStack_18 = (undefined *)ppuVar11;
      ppuStack_24 = ppcVar5;
      puVar10 = puStack_18;
      piVar4 = piStack_1c;
      *(undefined4 *)(puStack_18 + 0x28) = 0;
      *(undefined4 *)(puVar10 + 0x2c) = 0;
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
      *(undefined **)(puVar10 + 0x28) = puStack_20;
      *(int **)(puVar10 + 0x2c) = piVar4;
      uVar15 = 0xbf2365;
      FUN_00be9710();
      ppuStack_24 = &puStack_8c;
      uStack_8._0_1_ = 9;
      puStack_18 = (undefined *)&puStack_2e8;
      ppuStack_14 = &puStack_2e8;
      puStack_8c = param_2;
      uStack_88 = param_3;
      uStack_84 = param_4;
      uStack_7c = 0;
      ppuVar11 = &puStack_2e8;
      ppuVar6 = &puStack_2e8;
      if (param_5 != 0) {
        uStack_7c = param_5;
        if ((param_5 & 1) == 0) {
          ppuStack_2f0 = (undefined4 **)&uStack_74;
          ppuStack_2ec = (undefined **)0x0;
          puStack_2f4 = &param_7;
          uStack_2f8 = 0xbf23cd;
          (**(code **)(param_5 & 0xfffffffe))();
          ppuVar11 = (undefined **)puStack_18;
          ppuVar6 = ppuStack_14;
        }
        else {
          uStack_74 = param_7;
          uStack_70 = param_8;
          uStack_6c = param_9;
          uStack_68 = param_10;
          uStack_64 = param_11;
          ppuVar11 = &puStack_2e8;
          ppuVar6 = &puStack_2e8;
        }
      }
      ppuStack_14 = ppuVar6;
      puStack_18 = (undefined *)ppuVar11;
      uStack_8._0_1_ = 10;
      puStack_5c = (undefined4 *)0x0;
      if (param_12 != (undefined4 *)0x0) {
        puStack_5c = param_12;
        if (((uint)param_12 & 1) == 0) {
          ppuStack_2f0 = &piStack_54;
          ppuStack_2ec = (undefined **)0x0;
          puStack_2f4 = &param_14;
          uStack_2f8 = 0xbf240e;
          (**(code **)((uint)param_12 & 0xfffffffe))();
        }
        else {
          piStack_54 = (int *)param_14;
          puStack_50 = param_15;
          uStack_4c = param_16;
          uStack_48 = param_17;
          uStack_44 = param_18;
        }
      }
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
      puStack_3c = puStack_20;
      piStack_38 = piVar4;
      ppuStack_2ec = &puStack_8c;
      uStack_8._0_1_ = 0xb;
      ppuStack_2f0 = (undefined4 **)0xbf2446;
      FUN_00beca40();
      uStack_8._0_1_ = 0xc;
      *ppuStack_14 = (undefined *)0x0;
      ppuStack_2ec = (undefined **)aiStack_2a0;
      ppuStack_2f0 = (undefined4 **)0xbf2465;
      FUN_00beca40();
      ppuStack_2ec = (undefined **)aiStack_248;
      uStack_8._0_1_ = 0xd;
      ppuStack_2f0 = (undefined4 **)0xbf247b;
      FUN_00beca40();
      ppuStack_2ec = (undefined **)aiStack_1f0;
      uStack_8._0_1_ = 0xe;
      ppuStack_2f0 = (undefined4 **)0xbf2491;
      FUN_00beca40();
      ppuStack_2ec = (undefined **)aiStack_140;
      uStack_8._0_1_ = 0xf;
      ppuStack_2f0 = (undefined4 **)0xbf24a1;
      cVar7 = FUN_00585a40();
      if (cVar7 == '\0') {
        ppuStack_2ec = (undefined **)aiStack_140;
        ppuStack_2f0 = (undefined4 **)0xbf24ba;
        FUN_00beca40();
        ppuStack_2ec = (undefined **)0x58;
        uStack_8._0_1_ = 0x10;
        ppuStack_2f0 = (undefined4 **)0xbf24c5;
        param_4 = FUN_01674e20();
        uStack_8._0_1_ = 0x11;
        if (param_4 == 0) {
          puVar10 = (undefined *)0x0;
        }
        else {
          ppuStack_2ec = (undefined **)aiStack_198;
          ppuStack_2f0 = (undefined4 **)0xbf24e1;
          puVar10 = (undefined *)FUN_00beca40();
        }
        ppuStack_14[2] = puVar10;
        ppuStack_2ec = (undefined **)0xbf24f6;
        FUN_00bedf90();
        ppuStack_2ec = (undefined **)0xbf2501;
        FUN_00bedf90();
        param_4 = CONCAT13(1,(undefined3)param_4);
      }
      else {
        ppuStack_2ec = (undefined **)0xbf2512;
        FUN_00bedf90();
        param_4 = param_4 & 0xffffff;
      }
      ppuStack_2ec = (undefined **)0xbf2521;
      FUN_00bedf90();
      ppuVar11 = &PTR_FUN_01960500;
      if (param_4._3_1_ == '\0') {
        ppuVar11 = (undefined **)0x0;
      }
      *ppuStack_14 = (undefined *)ppuVar11;
      ppuStack_2ec = (undefined **)0xbf253e;
      FUN_00bedf90();
      ppuStack_2ec = (undefined **)0xbf2549;
      FUN_00bedf90();
      ppuStack_2ec = (undefined **)0xbf2554;
      FUN_00bedf90();
      ppuStack_2ec = (undefined **)0x13;
      ppuStack_2f0 = (undefined4 **)0x0;
      uStack_8._0_1_ = 0x12;
      FUN_0054ef60(auStack_e8);
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      FUN_00bcb620(in_stack_fffffcf8,in_stack_fffffcfc,uVar15);
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar2 = piVar4 + 2;
        iVar12 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar12 == 1) {
          ppuStack_2ac = (undefined **)0xbf258f;
          (**(code **)(*piVar4 + 4))();
        }
      }
      ppuStack_2ac = (undefined **)0xbf259a;
      FUN_005507b0();
    }
    ppuStack_2ac = (undefined **)0xbf25a5;
    FUN_00bee640();
    uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
  }
  else {
    puVar1 = puStack_18 + 0x40;
    if (*(int *)(puStack_18 + 0x40) == *(int *)(puStack_18 + 0x44)) {
      if (puStack_18[0x10] != '\0') {
        puStack_20 = *(undefined **)(puStack_18 + 0x38);
        uStack_34 = (double)DAT_01d68008;
        piStack_1c = *(int **)(puStack_18 + 0x3c);
        ppuStack_2ac = (undefined **)auStack_2c;
        pppuStack_2b0 = (undefined4 ***)0xbf20f0;
        puStack_18 = puVar1;
        pdVar8 = (double *)FUN_016830f0();
        dVar14 = uStack_34 + (double)CONCAT44(piStack_1c,puStack_20);
        if (*pdVar8 <= dVar14 && dVar14 != *pdVar8) {
          puStack_2b4 = (undefined4 *)(puVar10 + 0x14);
          ppuStack_2b8 = (undefined **)0xbf2111;
          FUN_00557fc0();
          puStack_2b4 = (undefined4 *)0xbf2119;
          FUN_00bef900();
          goto LAB_00bf2170;
        }
        puVar1 = puStack_18;
        if (puVar10[0x10] != '\0') goto LAB_00bf2179;
      }
      puStack_18 = puVar1;
      puStack_20 = *(undefined **)(puVar10 + 0x38);
      uStack_34 = (double)DAT_01d68010;
      piStack_1c = *(int **)(puVar10 + 0x3c);
      ppuStack_2ac = (undefined **)auStack_2c;
      pppuStack_2b0 = (undefined4 ***)0xbf2147;
      pdVar8 = (double *)FUN_016830f0();
      dVar14 = (double)CONCAT44(piStack_1c,puStack_20) + uStack_34;
      if (dVar14 < *pdVar8 || dVar14 == *pdVar8) goto LAB_00bf2179;
      puStack_2c4 = puVar10 + 0x1c;
      pcStack_2c8 = (char *)0xbf2168;
      FUN_0054ef60();
      puStack_2c4 = (undefined *)0xbf2170;
      FUN_005e65e0();
    }
    else {
      ppuStack_2ac = (undefined **)&param_12;
      pppuStack_2b0 = (undefined4 ***)&param_5;
      puStack_2b4 = &uStack_74;
      ppuStack_2b8 = (undefined **)0xbf20a7;
      puStack_18 = puVar1;
      ppuStack_2ac = (undefined **)FUN_00bec580();
      uStack_8._0_1_ = 3;
      pppuStack_2b0 = (undefined4 ***)0xbf20b7;
      FUN_00bec000();
      ppuStack_2ac = (undefined **)0xbf20bf;
      FUN_008c3510();
    }
LAB_00bf2170:
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
  }
  pppuStack_2b0 = (undefined4 ***)0xbf25af;
  ppuStack_2ac = ppuVar3;
  ppuStack_2ac = (undefined **)FUN_016deec8();
  if (ppuStack_2ac != (undefined **)0x0) {
    pppuStack_2b0 = (undefined4 ***)0xbf25bc;
    FUN_016df3c9();
  }
LAB_00bf25bf:
  uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
  if (param_5 != 0) {
    if (((param_5 & 1) == 0) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0)) {
      puStack_2b4 = &param_7;
      ppuStack_2ac = (undefined **)0x2;
      ppuStack_2b8 = (undefined **)0xbf25e0;
      pppuStack_2b0 = (undefined4 ***)puStack_2b4;
      (**(code **)(param_5 & 0xfffffffe))();
    }
    param_5 = 0;
  }
  uStack_8 = 0x15;
  if (((param_12 != (undefined4 *)0x0) && (((uint)param_12 & 1) == 0)) &&
     (*(code **)((uint)param_12 & 0xfffffffe) != (code *)0x0)) {
    puStack_2b4 = &param_14;
    ppuStack_2ac = (undefined **)0x2;
    ppuStack_2b8 = (undefined **)0xbf260e;
    pppuStack_2b0 = (undefined4 ***)puStack_2b4;
    (**(code **)((uint)param_12 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26836 ; VA 0x00bf2630 ; FUN_00bf2630 */

void FUN_00bf2630(uint param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined8 param_7,uint param_8,
                 undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13,undefined8 param_14)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint auStack_5c [2];
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  uint auStack_3c [2];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined auStack_1c [4];
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018034b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  auStack_5c[0] = 0;
  ExceptionList = &pvStack_10;
  if (param_8 != 0) {
    auStack_5c[0] = param_8;
    if ((param_8 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_8 & 0xfffffffe))(&param_10,&uStack_54,0);
    }
    else {
      uStack_54 = param_10;
      uStack_50 = param_11;
      uStack_4c = param_12;
      uStack_48 = param_13;
      uStack_44 = param_14;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  auStack_3c[0] = 0;
  if (param_1 != 0) {
    auStack_3c[0] = param_1;
    if ((param_1 & 1) == 0) {
      (**(code **)(param_1 & 0xfffffffe))(&param_3,&uStack_34,0);
    }
    else {
      uStack_34 = param_3;
      uStack_30 = param_4;
      uStack_2c = param_5;
      uStack_28 = param_6;
      uStack_24 = param_7;
    }
  }
  uStack_8._0_1_ = 4;
  puStack_14 = (undefined4 *)FUN_01674e20(0x40);
  if (puStack_14 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puStack_14 = 0;
    puStack_14[8] = 0;
    puVar4 = puStack_14;
  }
  FUN_00bee6d0(auStack_3c);
  FUN_008c4480(auStack_5c);
  uStack_8._0_1_ = 5;
  if (auStack_3c[0] != 0) {
    if (((auStack_3c[0] & 1) == 0) && (*(code **)(auStack_3c[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_3c[0] & 0xfffffffe))(&uStack_34,&uStack_34,2);
    }
    auStack_3c[0] = 0;
  }
  uStack_8._0_1_ = 6;
  if (((auStack_5c[0] != 0) && ((auStack_5c[0] & 1) == 0)) &&
     (*(code **)(auStack_5c[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_5c[0] & 0xfffffffe))(&uStack_54,&uStack_54,2);
  }
  uStack_8._0_1_ = 1;
  puStack_18 = puVar4;
  puStack_14 = (undefined4 *)FUN_00bec440(auStack_1c);
  if (puStack_14 != (undefined4 *)0x0) {
    LOCK();
    puStack_14[1] = puStack_14[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 7;
  cVar2 = FUN_0168a8f0();
  if (cVar2 == '\0') {
    uVar3 = FUN_005503c0();
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
                    /* WARNING: Subroutine does not return */
    FUN_0054e630(uVar3);
  }
  uStack_8._0_1_ = 9;
  FUN_016899e0();
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  FUN_016899e0();
  puVar4 = puStack_14;
  if (puStack_14 != (undefined4 *)0x0) {
    LOCK();
    iVar1 = puStack_14[1] + -1;
    puStack_14[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*puStack_14)(0);
      uVar3 = GetProcessHeap(0,puVar4);
      HeapFree(uVar3);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_1 & 0xfffffffe))(&param_3,&param_3,2);
  }
  uStack_8 = 0xc;
  if (((param_8 != 0) && ((param_8 & 1) == 0)) && (*(code **)(param_8 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_8 & 0xfffffffe))(&param_10,&param_10,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26837 ; VA 0x00bf2850 ; FUN_00bf2850 */

void __thiscall FUN_00bf2850(undefined4 *param_1,int param_2,undefined4 *param_3,uint param_4)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint uVar6;
  char cVar7;
  double *pdVar8;
  undefined4 *puVar9;
  undefined *puVar10;
  int iVar11;
  undefined **ppuVar12;
  int iVar13;
  undefined4 *puVar14;
  byte *pbVar15;
  double dVar16;
  uint in_stack_0000002c;
  undefined auStack_308 [24];
  undefined4 uStack_2f0;
  undefined4 *puStack_2ec;
  byte abStack_2e8 [24];
  undefined4 uStack_2d0;
  uint *puStack_2cc;
  char *pcStack_2c8;
  int iStack_2c4;
  undefined uStack_2c0;
  undefined4 uStack_2bc;
  int iStack_2b8;
  code **ppcStack_2b4;
  undefined4 *puStack_2b0;
  code **ppcStack_2ac;
  undefined4 uStack_2a0;
  undefined4 uStack_29c;
  undefined auStack_298 [72];
  undefined4 uStack_250;
  undefined4 uStack_24c;
  undefined auStack_248 [72];
  undefined4 uStack_200;
  undefined4 uStack_1fc;
  undefined auStack_1f8 [72];
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined auStack_1a8 [72];
  undefined4 uStack_160;
  undefined4 uStack_15c;
  undefined auStack_158 [72];
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined auStack_108 [8];
  undefined auStack_100 [64];
  code *pcStack_c0;
  undefined4 uStack_bc;
  undefined8 uStack_b8;
  undefined8 uStack_b0;
  uint auStack_a8 [2];
  code *pcStack_a0;
  undefined4 uStack_9c;
  undefined4 *puStack_98;
  undefined4 uStack_94;
  undefined8 uStack_90;
  uint auStack_88 [2];
  code *pcStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 uStack_70;
  code *pcStack_68;
  undefined4 uStack_64;
  undefined4 *puStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined4 uStack_38;
  int *piStack_34;
  undefined auStack_30 [4];
  undefined *puStack_2c;
  byte *pbStack_28;
  undefined4 *puStack_24;
  undefined8 uStack_20;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar6 = (uint)param_3;
  puStack_c = &LAB_0180358b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  puStack_24 = param_1;
  if (((int)param_3 < 1) && (((int)param_3 < 0 || (param_2 == 0)))) {
    ppcStack_2ac = (code **)0xc;
    puStack_2b0 = (undefined4 *)0xbf289a;
    ExceptionList = &pvStack_10;
    puStack_2b0 = (undefined4 *)FUN_01674e20();
    if (puStack_2b0 == (undefined4 *)0x0) {
      puStack_2b0 = (undefined4 *)0x0;
    }
    else {
      *puStack_2b0 = 0;
      puStack_2b0[1] = 0;
      puStack_2b0[2] = 0;
    }
    ppcStack_2ac = (code **)param_3;
    uStack_38 = 0;
    piStack_34 = (int *)0x0;
    ppcStack_2b4 = (code **)0xbf28d3;
    FUN_006047e0();
    piVar2 = piStack_34;
    uStack_8._0_1_ = 2;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      piStack_34[1] = piStack_34[1] + 1;
      UNLOCK();
    }
    puStack_2b0 = (undefined4 *)uStack_38;
    ppcStack_2ac = (code **)piStack_34;
    ppcStack_2b4 = (code **)0xbf2904;
    FUN_00bef900();
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar13 = piVar2[1] + -1;
      piVar2[1] = iVar13;
      UNLOCK();
      if (iVar13 == 0) {
        ppcStack_2ac = (code **)0xbf2922;
        (**(code **)*piVar2)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar13 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar13 == 1) {
          ppcStack_2ac = (code **)0xbf2935;
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    goto LAB_00bf3042;
  }
  piVar2 = param_1 + 0x23;
  puStack_2b0 = (undefined4 *)0xbf2949;
  ExceptionList = &pvStack_10;
  ppcStack_2ac = (code **)piVar2;
  piStack_34 = piVar2;
  ppcStack_2ac = (code **)FUN_016dee6d();
  if (ppcStack_2ac != (code **)0x0) {
    puStack_2b0 = (undefined4 *)0xbf2956;
    FUN_016df3c9();
  }
  pbStack_28 = (byte *)(puStack_24 + 0x1d);
  uStack_8._0_1_ = 3;
  iVar13 = (int)puStack_24 + *pbStack_28 + 0x75;
  ppcStack_2ac = (code **)(-(uint)(iVar13 != 0) & iVar13 + 1U);
  puStack_2b0 = &param_2;
  ppcStack_2b4 = (code **)((uVar6 >> 2) + uVar6 * 0x40 + param_2 ^ uVar6);
  iStack_2b8 = (int)&uStack_20 + 4;
  uStack_2bc = 0xbf299a;
  FUN_00606ff0();
  iVar13 = uStack_20._4_4_;
  if (uStack_20._4_4_ == 0) {
LAB_00bf2ab6:
    ppcStack_2ac = (code **)&uStack_40;
    puStack_2b0 = (undefined4 *)0xbf2abf;
    puVar9 = (undefined4 *)FUN_01682800();
    ppcStack_2ac = (code **)puVar9[1];
    puStack_2b0 = (undefined4 *)*puVar9;
    iStack_2b8 = 0;
    ppcStack_2b4 = (code **)0x0;
    uStack_2bc = 0xbf2ae4;
    puVar10 = (undefined *)FUN_00bedef0();
    ppcStack_2ac = (code **)&param_2;
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    puStack_2b0 = (undefined4 *)0xbf2af9;
    puStack_2c = puVar10;
    iVar11 = FUN_00beebc0();
    *(undefined *)(iVar11 + 8) = *puVar10;
    uVar3 = *(undefined4 *)(puVar10 + 4);
    iVar13 = iVar11 + 8;
    *(undefined4 *)(puVar10 + 4) = 0;
    uVar4 = *(undefined4 *)(puVar10 + 8);
    *(undefined4 *)(puVar10 + 8) = 0;
    *(undefined4 *)(iVar11 + 0xc) = uVar3;
    piStack_14 = *(int **)(iVar11 + 0x10);
    uStack_20 = (double)CONCAT44(iVar13,(undefined4)uStack_20);
    *(undefined4 *)(iVar11 + 0x10) = uVar4;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar11 = piStack_14[1] + -1;
      piStack_14[1] = iVar11;
      UNLOCK();
      puVar10 = puStack_2c;
      if (iVar11 == 0) {
        ppcStack_2ac = (code **)0xbf2b38;
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piStack_14 + 2;
        iVar13 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar13 == 1) {
          ppcStack_2ac = (code **)0xbf2b48;
          (**(code **)(*piStack_14 + 4))();
        }
        iVar13 = uStack_20._4_4_;
        puVar10 = puStack_2c;
      }
    }
    piStack_14 = (int *)(iVar13 + 0xc);
    puVar9 = (undefined4 *)(puVar10 + 0xc);
    if (piStack_14 != puVar9) {
      ppcStack_2ac = (code **)0xbf2b62;
      FUN_005507b0();
      uVar3 = *(undefined4 *)(puVar10 + 0x10);
      uVar4 = *(undefined4 *)(puVar10 + 0x14);
      uVar5 = *(undefined4 *)(puVar10 + 0x18);
      *piStack_14 = *puVar9;
      piStack_14[1] = uVar3;
      piStack_14[2] = uVar4;
      piStack_14[3] = uVar5;
      *(undefined8 *)(piStack_14 + 4) = *(undefined8 *)(puVar10 + 0x1c);
      *(undefined4 *)(puVar10 + 0x1c) = 0;
      *(undefined4 *)(puVar10 + 0x20) = 0xf;
      *(undefined *)puVar9 = 0;
      iVar13 = uStack_20._4_4_;
    }
    puVar10 = puStack_2c;
    *(undefined4 *)(iVar13 + 0x28) = *(undefined4 *)(puStack_2c + 0x28);
    puVar9 = (undefined4 *)(puStack_2c + 0x30);
    *(undefined4 *)(iVar13 + 0x2c) = *(undefined4 *)(puStack_2c + 0x2c);
    piStack_14 = (int *)(iVar13 + 0x30);
    if (piStack_14 != puVar9) {
      ppcStack_2ac = (code **)0xbf2bac;
      FUN_00a59a30();
      *piStack_14 = *puVar9;
      piStack_14[1] = *(undefined4 *)(puVar10 + 0x34);
      piStack_14[2] = *(undefined4 *)(puVar10 + 0x38);
      *puVar9 = 0;
      *(undefined4 *)(puVar10 + 0x34) = 0;
      *(undefined4 *)(puVar10 + 0x38) = 0;
    }
    uStack_8._0_1_ = 3;
    ppcStack_2ac = (code **)0xbf2be2;
    FUN_00bee640();
    ppcStack_2ac = (code **)&param_2;
    puStack_2b0 = (undefined4 *)0xbf2bee;
    FUN_00beebc0();
    ppcStack_2ac = (code **)&stack0x0000002c;
    puStack_2b0 = &param_4;
    ppcStack_2b4 = (code **)auStack_100;
    iStack_2b8 = 0xbf2c05;
    ppcStack_2ac = (code **)FUN_00bec580();
    uStack_8._0_1_ = 7;
    puStack_2b0 = (undefined4 *)0xbf2c14;
    FUN_00bec000();
    ppcStack_2ac = (code **)0xbf2c1f;
    FUN_008c3510();
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    puStack_2b0 = (undefined4 *)0xbf2c29;
    ppcStack_2ac = (code **)piVar2;
    ppcStack_2ac = (code **)FUN_016deec8();
    if (ppcStack_2ac != (code **)0x0) {
      puStack_2b0 = (undefined4 *)0xbf2c36;
      FUN_016df3c9();
    }
    puVar9 = puStack_24;
    uVar6 = (uint)param_3;
    ppcStack_2ac = &pcStack_68;
    puStack_48 = puStack_24;
    uStack_40 = CONCAT44(param_3,param_2);
    pcStack_68 = FUN_00bf8270;
    uStack_64 = 0;
    _puStack_60 = CONCAT44(uStack_44,puStack_24);
    uStack_58 = uStack_40;
    puStack_2b0 = (undefined4 *)0xbf2c7b;
    cVar7 = FUN_00585a40();
    if (cVar7 == '\0') {
      pcStack_80 = pcStack_68;
      uStack_7c = uStack_64;
      uStack_78 = puStack_60;
      uStack_74 = uStack_5c;
      auStack_88[0] = 0x19604f1;
      uStack_70 = uStack_58;
    }
    else {
      auStack_88[0] = 0;
    }
    ppcStack_2ac = &pcStack_50;
    uStack_40 = CONCAT44(uVar6,param_2);
    uStack_b8 = CONCAT44(uStack_44,puVar9);
    pcStack_c0 = FUN_00bf86a0;
    uStack_bc = 0;
    uStack_b0 = uStack_40;
    pcStack_50 = FUN_00bf86a0;
    uStack_4c = 0;
    puStack_48 = puVar9;
    puStack_2b0 = (undefined4 *)0xbf2cf6;
    cVar7 = FUN_00585a40();
    if (cVar7 == '\0') {
      pcStack_a0 = pcStack_50;
      uStack_9c = uStack_4c;
      puStack_98 = puStack_48;
      uStack_94 = uStack_44;
      auStack_a8[0] = 0x19604f9;
      uStack_90 = uStack_40;
    }
    else {
      auStack_a8[0] = 0;
    }
    ppcStack_2ac = (code **)puVar9;
    uStack_8._0_1_ = 10;
    puStack_2b0 = (undefined4 *)0xbf2d39;
    piStack_14 = (int *)FUN_00965f10();
    if (piStack_14 == (int *)0x0) {
      iStack_2c4 = 0x14;
      puStack_2b0 = (undefined4 *)0x0;
      ppcStack_2ac = (code **)0xf;
      pcStack_2c8 = "No HttpRbxApiService";
      uStack_2c0 = 0;
      puStack_2cc = (uint *)0xbf2fd2;
      FUN_005542c0();
      iStack_2c4 = 0xbf2fdd;
      FUN_005e65e0();
    }
    else {
      ppcStack_2ac = (code **)uVar6;
      puStack_2b0 = (undefined4 *)param_2;
      ppcStack_2b4 = &pcStack_c0;
      iStack_2b8 = 0xbf2d57;
      FUN_00f830e0();
      piStack_34 = (int *)&pcStack_2c8;
      param_3 = (undefined4 *)CONCAT31(param_3._1_3_,DAT_01ef7639);
      puStack_2cc = auStack_88;
      uStack_8._0_1_ = 0xb;
      uStack_2d0 = 0xbf2d77;
      FUN_0054f510();
      pbStack_28 = abStack_2e8;
      puStack_24 = (undefined4 *)abStack_2e8;
      pbVar15 = abStack_2e8;
      uStack_8._0_1_ = 0xc;
      uStack_20 = (double)CONCAT44(auStack_308,(undefined4)uStack_20);
      FUN_0054f510(auStack_88);
      uStack_8._0_1_ = 0xd;
      FUN_0054f510(auStack_a8);
      uStack_8._0_1_ = 0xc;
      FUN_00beb670(&uStack_2a0,FUN_00bf8880,0,puVar9,param_3);
      uStack_250 = uStack_2a0;
      uStack_24c = uStack_29c;
      puStack_2ec = (undefined4 *)auStack_298;
      uStack_8._0_1_ = 0xe;
      uStack_2f0 = 0xbf2dfb;
      FUN_00beccf0();
      uStack_200 = uStack_250;
      uStack_1fc = uStack_24c;
      puStack_2ec = (undefined4 *)auStack_248;
      uStack_8._0_1_ = 0xf;
      abStack_2e8[0] = 0;
      abStack_2e8[1] = 0;
      abStack_2e8[2] = 0;
      abStack_2e8[3] = 0;
      uStack_2f0 = 0xbf2e2f;
      FUN_00beccf0();
      uStack_1b0 = uStack_200;
      uStack_1ac = uStack_1fc;
      puStack_2ec = (undefined4 *)auStack_1f8;
      uStack_8._0_1_ = 0x10;
      uStack_2f0 = 0xbf2e5d;
      FUN_00beccf0();
      uStack_110 = uStack_1b0;
      uStack_10c = uStack_1ac;
      puStack_2ec = (undefined4 *)auStack_1a8;
      uStack_8._0_1_ = 0x11;
      uStack_2f0 = 0xbf2e8b;
      FUN_00beccf0();
      puStack_2ec = &uStack_110;
      uStack_8._0_1_ = 0x12;
      uStack_2f0 = 0xbf2e9b;
      cVar7 = FUN_00585a40();
      if (cVar7 == '\0') {
        uStack_160 = uStack_110;
        uStack_15c = uStack_10c;
        puStack_2ec = (undefined4 *)auStack_108;
        uStack_2f0 = 0xbf2ed0;
        FUN_00beccf0();
        puStack_2ec = (undefined4 *)0x50;
        uStack_8._0_1_ = 0x13;
        uStack_2f0 = 0xbf2edb;
        puVar9 = (undefined4 *)FUN_01674e20();
        uStack_8._0_1_ = 0x14;
        if (puVar9 == (undefined4 *)0x0) {
          puVar14 = (undefined4 *)0x0;
          param_3 = puVar9;
        }
        else {
          puStack_2ec = (undefined4 *)auStack_158;
          *puVar9 = uStack_160;
          puVar9[1] = uStack_15c;
          uStack_2f0 = 0xbf2f0b;
          param_3 = puVar9;
          FUN_00beccf0();
          puVar14 = puVar9;
        }
        puStack_24[2] = puVar14;
        puStack_2ec = (undefined4 *)0xbf2f20;
        FUN_0096ca80();
        puStack_2ec = (undefined4 *)0xbf2f2b;
        FUN_0096ca80();
        param_3 = (undefined4 *)CONCAT13(1,param_3._0_3_);
        pbVar15 = (byte *)puStack_24;
      }
      else {
        puStack_2ec = (undefined4 *)0xbf2f3f;
        FUN_0096ca80();
        param_3 = (undefined4 *)((uint)param_3 & 0xffffff);
      }
      puStack_2ec = (undefined4 *)0xbf2f4e;
      FUN_0096ca80();
      ppuVar12 = &PTR_FUN_01960550;
      if (param_3._3_1_ == '\0') {
        ppuVar12 = (undefined **)0x0;
      }
      *(undefined ***)pbVar15 = ppuVar12;
      puStack_2ec = (undefined4 *)0xbf2f68;
      FUN_0096ca80();
      puStack_2ec = (undefined4 *)0xbf2f73;
      FUN_0096ca80();
      puStack_2ec = (undefined4 *)0xbf2f7e;
      FUN_0096ca80();
      puStack_2ec = (undefined4 *)0x13;
      uStack_2f0 = 0;
      uStack_8._0_1_ = 0x15;
      FUN_0054ef60(&pcStack_c0);
      uStack_8._0_1_ = 0xb;
      FUN_00bcb620();
      ppcStack_2ac = (code **)0xbf2fae;
      FUN_005507b0();
    }
    uStack_8._0_1_ = 0x16;
    if (auStack_a8[0] != 0) {
      if (((auStack_a8[0] & 1) == 0) && (*(code **)(auStack_a8[0] & 0xfffffffe) != (code *)0x0)) {
        ppcStack_2b4 = &pcStack_a0;
        ppcStack_2ac = (code **)0x2;
        iStack_2b8 = 0xbf3004;
        puStack_2b0 = ppcStack_2b4;
        (**(code **)(auStack_a8[0] & 0xfffffffe))();
      }
      auStack_a8[0] = 0;
    }
    uStack_8._0_1_ = 0x17;
    if (auStack_88[0] != 0) {
      if (((auStack_88[0] & 1) == 0) && (*(code **)(auStack_88[0] & 0xfffffffe) != (code *)0x0)) {
        ppcStack_2b4 = &pcStack_80;
        ppcStack_2ac = (code **)0x2;
        iStack_2b8 = 0xbf3035;
        puStack_2b0 = ppcStack_2b4;
        (**(code **)(auStack_88[0] & 0xfffffffe))();
      }
      auStack_88[0] = 0;
    }
  }
  else {
    piVar1 = (int *)(uStack_20._4_4_ + 0x40);
    uStack_20 = (double)CONCAT44(uStack_20._4_4_ + 0x40,(undefined4)uStack_20);
    if (*piVar1 == *(int *)(iVar13 + 0x44)) {
      if (*(char *)(iVar13 + 0x10) != '\0') {
        uStack_18 = *(undefined4 *)(iVar13 + 0x38);
        uStack_20 = (double)DAT_01d67ff4;
        piStack_14 = *(int **)(iVar13 + 0x3c);
        ppcStack_2ac = (code **)auStack_30;
        puStack_2b0 = (undefined4 *)0xbf2a13;
        pdVar8 = (double *)FUN_016830f0();
        dVar16 = (double)CONCAT44(piStack_14,uStack_18) + uStack_20;
        if (*pdVar8 <= dVar16 && dVar16 != *pdVar8) {
          ppcStack_2b4 = (code **)(iVar13 + 0x14);
          iStack_2b8 = 0xbf2a34;
          FUN_00557fc0();
          ppcStack_2b4 = (code **)0xbf2a3c;
          FUN_00bef900();
          goto LAB_00bf2a93;
        }
        if (*(char *)(iVar13 + 0x10) != '\0') goto LAB_00bf2ab6;
      }
      uStack_18 = *(undefined4 *)(iVar13 + 0x38);
      uStack_20 = (double)DAT_01d67ffc;
      piStack_14 = *(int **)(iVar13 + 0x3c);
      ppcStack_2ac = (code **)auStack_30;
      puStack_2b0 = (undefined4 *)0xbf2a6a;
      pdVar8 = (double *)FUN_016830f0();
      dVar16 = (double)CONCAT44(piStack_14,uStack_18) + uStack_20;
      if (dVar16 < *pdVar8 || dVar16 == *pdVar8) goto LAB_00bf2ab6;
      iStack_2c4 = iVar13 + 0x1c;
      pcStack_2c8 = (char *)0xbf2a8b;
      FUN_0054ef60();
      iStack_2c4 = 0xbf2a93;
      FUN_005e65e0();
    }
    else {
      ppcStack_2ac = (code **)&stack0x0000002c;
      puStack_2b0 = &param_4;
      ppcStack_2b4 = (code **)auStack_100;
      iStack_2b8 = 0xbf29c7;
      ppcStack_2ac = (code **)FUN_00bec580();
      uStack_8._0_1_ = 4;
      puStack_2b0 = (undefined4 *)0xbf29d7;
      FUN_00bec000();
      ppcStack_2ac = (code **)0xbf29e2;
      FUN_008c3510();
    }
LAB_00bf2a93:
    uStack_8._0_1_ = 5;
    puStack_2b0 = (undefined4 *)0xbf2a9d;
    ppcStack_2ac = (code **)piVar2;
    ppcStack_2ac = (code **)FUN_016deec8();
    if (ppcStack_2ac != (code **)0x0) {
      puStack_2b0 = (undefined4 *)0xbf2aae;
      FUN_016df3c9();
    }
  }
LAB_00bf3042:
  uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      ppcStack_2b4 = (code **)&stack0x00000014;
      ppcStack_2ac = (code **)0x2;
      iStack_2b8 = 0xbf3063;
      puStack_2b0 = ppcStack_2b4;
      (**(code **)(param_4 & 0xfffffffe))();
    }
    param_4 = 0;
  }
  uStack_8 = 0x19;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    ppcStack_2b4 = (code **)&stack0x00000034;
    ppcStack_2ac = (code **)0x2;
    iStack_2b8 = 0xbf3091;
    puStack_2b0 = ppcStack_2b4;
    (**(code **)(in_stack_0000002c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26838 ; VA 0x00bf30b0 ; FUN_00bf30b0 */

void FUN_00bf30b0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  longlong lVar3;
  undefined4 uVar4;
  undefined auStack_64 [4];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  uint uStack_4c;
  int iStack_48;
  undefined8 uStack_44;
  undefined8 uStack_3c;
  undefined auStack_34 [8];
  int *piStack_2c;
  undefined4 uStack_28;
  longlong lStack_24;
  uint uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018035e0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  lVar3 = FUN_00928340();
  lStack_24 = FUN_00928340();
  uVar2 = (undefined4)((ulonglong)lStack_24 >> 0x20);
  if (lVar3 != lStack_24) {
    iVar1 = FUN_00bf1ef0(lVar3,lStack_24);
    switch(param_3) {
    case 0:
      if (iVar1 != 2) {
        iVar1 = FUN_00bf1ef0(lVar3,(undefined4)lStack_24,uVar2);
        if (iVar1 != 3) {
          FUN_00bfa850(lVar3,(undefined4)lStack_24,uVar2,1);
          uStack_54 = 0;
          uStack_50 = 0xf;
          auStack_64[0] = 0;
          FUN_005542c0("FriendService-FriendRequestIssued",0x21);
          uStack_8 = 0;
          FUN_008783f0(auStack_64,1,0);
          uStack_8 = 0xffffffff;
          FUN_005507b0();
          FUN_0087c450(&DAT_018c5f98,"FriendService","FriendRequestIssued",1,0,0);
          FUN_00927d30(&param_3);
          FUN_00927d30(&iStack_18);
          piStack_2c = &param_3;
          uStack_28 = 0;
          FUN_00bf9a20(uStack_14,lVar3,(undefined4)lStack_24,uVar2,0,&piStack_2c);
          uVar4 = 0;
LAB_00bf34f1:
          piStack_2c = &iStack_18;
          uStack_28 = 0;
          FUN_00bf9a20(uStack_14,lVar3,(undefined4)lStack_24,uVar2,uVar4,&piStack_2c);
          ExceptionList = pvStack_10;
          return;
        }
      }
      break;
    case 1:
      if (iVar1 != 2) {
        iVar1 = FUN_00bf1ef0(lVar3,(undefined4)lStack_24,uVar2);
        if (iVar1 == 3) {
          FUN_00bfa850(lVar3,(undefined4)lStack_24,uVar2,0);
          uStack_54 = 0;
          uStack_50 = 0xf;
          auStack_64[0] = 0;
          FUN_005542c0("FriendService-FriendRequestRevoked",0x22);
          uStack_8 = 1;
          FUN_008783f0(auStack_64,1,0);
          uStack_8 = 0xffffffff;
          FUN_005507b0();
          FUN_0087c450(&DAT_018c5f98,"FriendService","FriendRequestRevoked",1,0,0);
          FUN_00927d30(&param_3);
          FUN_00927d30(&iStack_18);
          piStack_2c = &param_3;
          uStack_28 = 0;
          FUN_00bf9a20(uStack_14,lVar3,(undefined4)lStack_24,uVar2,1,&piStack_2c);
          uVar4 = 1;
          goto LAB_00bf34f1;
        }
      }
      break;
    case 2:
      if (iVar1 != 2) {
        iVar1 = FUN_00bf1ef0((undefined4)lStack_24,uVar2,lVar3);
        if (iVar1 == 3) {
          FUN_0068f9a0(&uStack_1c,uStack_14);
          uStack_8 = 2;
          param_1._3_1_ = 0;
          uVar2 = FUN_00bf4900(auStack_34,lVar3,lStack_24);
          iVar1 = FUN_00bee7d0(uVar2);
          if (iStack_18 != 0) {
            LOCK();
            *(int *)(iStack_18 + 8) = *(int *)(iStack_18 + 8) + 1;
            UNLOCK();
          }
          uStack_4c = uStack_1c;
          iStack_48 = iStack_18;
          uStack_8 = CONCAT31(uStack_8._1_3_,3);
          uStack_44 = lVar3;
          uStack_3c = lStack_24;
          if (*(int *)(iVar1 + 0x18) == *(int *)(iVar1 + 0x14)) {
            FUN_00bea9d0(*(int *)(iVar1 + 0x14),&uStack_4c,
                         (undefined *)((int)register0x00000010 + 7));
          }
          else {
            FUN_00bebe10(iVar1 + 0x10);
            *(int *)(iVar1 + 0x14) = *(int *)(iVar1 + 0x14) + 0x40;
          }
          FUN_0056c200();
          auStack_64[0] = 0;
          uStack_60 = FUN_00588320(0xb);
          uStack_5c = 0;
          uStack_58 = 0x3f800000;
          uStack_54 = 0;
          uStack_50 = 0;
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          FUN_00bf36a0(&piStack_2c,&lStack_24);
          FUN_00bf9b70(lVar3,auStack_64);
          FUN_00612320();
          FUN_0056c200();
          ExceptionList = pvStack_10;
          return;
        }
      }
      break;
    case 3:
      if (iVar1 == 2) {
        uStack_54 = 0;
        uStack_50 = 0xf;
        auStack_64[0] = 0;
        FUN_005542c0("FriendService-FriendshipBroken",0x1e);
        uStack_8 = 6;
        FUN_008783f0(auStack_64,1,0);
        uStack_8 = 0xffffffff;
        FUN_005507b0();
        FUN_0087c450(&DAT_018c5f98,"FriendService","FriendshipBroken",1,0,0);
        uStack_4c = uStack_4c & 0xffffff00;
        iStack_48 = FUN_00588320(0xb);
        uStack_44._0_4_ = 0;
        uStack_44._4_4_ = 0x3f800000;
        uStack_3c._0_4_ = 0;
        uStack_3c._4_4_ = 0;
        uStack_8 = 7;
        FUN_00bf36a0(&piStack_2c,&lStack_24);
        FUN_00bf9b70(lVar3,&uStack_4c);
        FUN_00612320();
      }
      else {
        iVar1 = FUN_00bf1ef0((undefined4)lStack_24,uVar2,lVar3);
        if (iVar1 == 3) {
          FUN_00bfa850((undefined4)lStack_24,uVar2,lVar3,0);
          uStack_54 = 0;
          uStack_50 = 0xf;
          auStack_64[0] = 0;
          FUN_005542c0("FriendService-FriendRequestDenied",0x21);
          uStack_8 = 5;
          FUN_008783f0(auStack_64,1,0);
          uStack_8 = 0xffffffff;
          FUN_005507b0();
          FUN_0087c450(&DAT_018c5f98,"FriendService","FriendRequestDenied",1,0,0);
          FUN_00927d30(&param_3);
          FUN_00927d30(&iStack_18);
          piStack_2c = &param_3;
          uStack_28 = 0;
          FUN_00bf9a20(uStack_14,lVar3,(undefined4)lStack_24,uVar2,3,&piStack_2c);
          uVar4 = 3;
          goto LAB_00bf34f1;
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26839 ; VA 0x00bf3600 ; FUN_00bf3600 */

bool FUN_00bf3600(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  
  iVar1 = FUN_00bf1ef0(param_1,param_2,param_3,param_4);
  return iVar1 == 3;
}



/* FUNCTION 26840 ; VA 0x00bf3620 ; FUN_00bf3620 */

uint FUN_00bf3620(int *param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  
  uVar2 = param_1[1];
  if (((int)uVar2 < 1) && ((int)uVar2 < 0)) {
    uVar2 = ~uVar2;
  }
  uVar3 = param_1[3];
  uVar2 = (uVar2 >> 2) + uVar2 * 0x40 + *param_1 ^ uVar2;
  uVar1 = uVar2 + 0x9e3779b9;
  if (((int)uVar3 < 1) && ((int)uVar3 < 0)) {
    uVar3 = ~uVar3;
  }
  return (uVar1 >> 2) + 0x2c15e7f9 +
         ((uVar3 >> 2) + uVar3 * 0x40 + param_1[2] ^ uVar3) + uVar2 * 0x40 ^ uVar1;
}



/* FUNCTION 26841 ; VA 0x00bf36a0 ; FUN_00bf36a0 */

void __thiscall FUN_00bf36a0(byte *param_1,undefined4 *param_2,uint *param_3)

{
  uint uVar1;
  byte *pbVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined uVar5;
  uint *puVar6;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined2 uStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar6 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018035f8;
  pvStack_10 = ExceptionList;
  uVar4 = param_3[1];
  uVar1 = *param_3;
  puStack_1c = (undefined4 *)uVar1;
  if (((int)uVar4 < 1) && ((int)uVar4 < 0)) {
    uVar4 = ~uVar4;
    puStack_1c = (undefined4 *)~uVar1;
  }
  uVar4 = (uVar4 >> 2) + uVar4 * 0x40 + uVar1 ^ uVar4;
  ExceptionList = &pvStack_10;
  pbStack_14 = param_1;
  FUN_00606ff0(&param_3,uVar4,param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  pbVar2 = pbStack_14;
  if (param_3 == (uint *)0x0) {
    puStack_1c = (undefined4 *)0x0;
    uStack_20 = -(uint)(pbStack_14 != (byte *)0xfffffffd) & (uint)(pbStack_14 + 4);
    uStack_8 = 0;
    uStack_18 = 0;
    puStack_1c = (undefined4 *)FUN_01674e20(0x10);
    uStack_18 = 0x101;
    *puStack_1c = 0;
    puStack_1c[1] = 0;
    *(undefined8 *)(puStack_1c + 2) = 0;
    puStack_1c[2] = *puVar6;
    puStack_1c[3] = puVar6[1];
    FUN_0062b610(*(int *)(pbVar2 + 8) + 1);
    puVar3 = (undefined4 *)FUN_005c5550(&param_3,&uStack_20,uVar4);
    uVar5 = 1;
    puVar6 = (uint *)*puVar3;
    if (puStack_1c != (undefined4 *)0x0) {
      FUN_01674ea0(puStack_1c,0x10);
    }
  }
  else {
    uVar5 = 0;
    puVar6 = param_3;
  }
  *param_2 = puVar6;
  *(undefined *)(param_2 + 1) = uVar5;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26842 ; VA 0x00bf37d0 ; FUN_00bf37d0 */

/* WARNING: Removing unreachable block (ram,0x00bf3837) */
/* WARNING: Removing unreachable block (ram,0x00bf3845) */
/* WARNING: Removing unreachable block (ram,0x00bf386d) */
/* WARNING: Removing unreachable block (ram,0x00bf3855) */

void FUN_00bf37d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00beee40(param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26843 ; VA 0x00bf3880 ; FUN_00bf3880 */

/* WARNING: Removing unreachable block (ram,0x00bf3950) */
/* WARNING: Removing unreachable block (ram,0x00bf395e) */
/* WARNING: Removing unreachable block (ram,0x00bf398c) */
/* WARNING: Removing unreachable block (ram,0x00bf396e) */

void FUN_00bf3880(undefined4 *param_1,undefined4 ****param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,uint param_7)

{
  undefined4 ****ppppuVar1;
  int *piVar2;
  uint uVar3;
  undefined4 ***pppuStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017969d0;
  pvStack_10 = ExceptionList;
  pppuStack_28 = param_2;
  uStack_24 = param_3;
  uStack_20 = param_4;
  uStack_1c = param_5;
  uStack_18 = param_6;
  uStack_14 = param_7;
  piVar2 = (int *)*param_1;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (DAT_01d6802c != '\0') {
    ppppuVar1 = &pppuStack_28;
    if (0xf < param_7) {
      ppppuVar1 = param_2;
    }
    if (0xf < (uint)piVar2[5]) {
      piVar2 = (int *)*piVar2;
    }
    ExceptionList = &pvStack_10;
    FUN_01677520(DAT_01d6802c,"%s error: %s",piVar2,ppppuVar1);
  }
  FUN_0054ef60(&pppuStack_28);
  FUN_005e65e0();
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    ppppuVar1 = (undefined4 ****)pppuStack_28;
    if (0xfff < uVar3) {
      ppppuVar1 = (undefined4 ****)pppuStack_28[-1];
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)pppuStack_28 + (-4 - (int)ppppuVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar1,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26844 ; VA 0x00bf39a0 ; FUN_00bf39a0 */

void FUN_00bf39a0(undefined4 param_1,undefined4 param_2)

{
  FUN_00beef70(param_2);
  return;
}



/* FUNCTION 26845 ; VA 0x00bf39b0 ; FUN_00bf39b0 */

/* WARNING: Removing unreachable block (ram,0x00bf3a17) */
/* WARNING: Removing unreachable block (ram,0x00bf3a25) */
/* WARNING: Removing unreachable block (ram,0x00bf3a4d) */
/* WARNING: Removing unreachable block (ram,0x00bf3a35) */

void FUN_00bf39b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00bef140(param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26846 ; VA 0x00bf3a60 ; FUN_00bf3a60 */

/* WARNING: Removing unreachable block (ram,0x00bf3ac7) */
/* WARNING: Removing unreachable block (ram,0x00bf3ad5) */
/* WARNING: Removing unreachable block (ram,0x00bf3afd) */
/* WARNING: Removing unreachable block (ram,0x00bf3ae5) */

void FUN_00bf3a60(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00bef340(param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26847 ; VA 0x00bf3b10 ; FUN_00bf3b10 */

int FUN_00bf3b10(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puVar6;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01803620;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  iStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = param_1[2];
    if (*(int *)(iVar3 + 8) == 0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      piVar1 = (int *)(iVar3 + 4);
      iVar3 = *(int *)(iVar3 + 0x14);
      puVar6 = *(undefined4 **)(iVar3 + *piVar1 * 4);
    }
    for (; puVar6 != (undefined4 *)0x0; puVar6 = (undefined4 *)*puVar6) {
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = auStack_30[0] & 0xffffff00;
      FUN_005542c0(&DAT_018bc9b8,0);
      iStack_8._0_1_ = 1;
      iVar3 = FUN_00bfa9e0(*param_1,param_1[1],puVar6[2],puVar6[3],puVar6[4],1,auStack_30);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (0xf < uStack_1c) {
        uVar5 = uStack_1c + 1;
        uVar4 = auStack_30[0];
        if (0xfff < uVar5) {
          uVar4 = *(uint *)(auStack_30[0] - 4);
          uVar5 = uStack_1c + 0x24;
          if (0x1f < (auStack_30[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        iVar3 = FUN_01674ea0(uVar4,uVar5);
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 26848 ; VA 0x00bf3c40 ; FUN_00bf3c40 */

/* WARNING: Removing unreachable block (ram,0x00bf3d04) */
/* WARNING: Removing unreachable block (ram,0x00bf3d12) */
/* WARNING: Removing unreachable block (ram,0x00bf3d52) */
/* WARNING: Removing unreachable block (ram,0x00bf3d22) */

void FUN_00bf3c40(undefined4 *param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_01803648;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  uStack_8 = 1;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01d6802c != '\0') {
    piVar2 = piVar1;
    if (0xf < (uint)piVar1[5]) {
      piVar2 = (int *)*piVar1;
    }
    ExceptionList = &pvStack_10;
    FUN_01677520(DAT_01d6802c,"%s success",piVar2);
  }
  if (piVar1[6] == 0) {
    uVar3 = FUN_0054fda0();
    _uStack_8 = CONCAT31(uStack_7,2);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar3);
  }
  (**(code **)((piVar1[6] & 0xfffffffeU) + 4))(piVar1 + 8);
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    iVar4 = param_2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_2 + -4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26849 ; VA 0x00bf3d80 ; FUN_00bf3d80 */

undefined4 * FUN_00bf3d80(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01803668;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)*param_1;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    if (puVar3[4] == 0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      puVar4 = (undefined4 *)puVar3[3];
      puVar5 = *(undefined4 **)(puVar3[7] + (int)puVar4 * 4);
    }
    for (; puVar5 != (undefined4 *)0x0; puVar5 = (undefined4 *)*puVar5) {
      FUN_00bfa9e0(*puVar3,puVar3[1],puVar5[2],puVar5[3],0,puVar3[0xe] == 0,puVar3 + 10);
      puVar4 = puVar3 + 10;
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    puVar4 = (undefined4 *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puVar4 = (undefined4 *)(**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puVar4 = (undefined4 *)(**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 26850 ; VA 0x00bf3e40 ; FUN_00bf3e40 */

void FUN_00bf3e40(undefined4 *param_1,int param_2)

{
  undefined4 uVar1;
  code *pcVar2;
  int iVar3;
  uint uVar4;
  uint in_stack_0000001c;
  int aiStack_30 [5];
  uint uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01803690;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = param_1[4];
  uVar1 = param_1[5];
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  pcVar2 = (code *)*param_1;
  FUN_0054ef60(aiStack_30);
  (*pcVar2)(uStack_14,uVar1);
  if (0xf < uStack_1c) {
    uVar4 = uStack_1c + 1;
    iVar3 = aiStack_30[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_30[0] + -4);
      uVar4 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  if (0xf < in_stack_0000001c) {
    uVar4 = in_stack_0000001c + 1;
    iVar3 = param_2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(param_2 + -4);
      uVar4 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26851 ; VA 0x00bf3f30 ; FUN_00bf3f30 */

int FUN_00bf3f30(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  code *pcVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018036b0;
  pvStack_10 = ExceptionList;
  uVar3 = param_1[5];
  uVar4 = param_1[4];
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  pcVar5 = (code *)*param_1;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar6 = (*pcVar5)(uVar4,uVar3,param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar6 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 26852 ; VA 0x00bf4010 ; FUN_00bf4010 */

int FUN_00bf4010(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  code *pcVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018036d0;
  pvStack_10 = ExceptionList;
  uVar3 = param_1[5];
  uVar4 = param_1[4];
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  pcVar5 = (code *)*param_1;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar6 = (*pcVar5)(uVar4,uVar3,param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar6 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 26853 ; VA 0x00bf40f0 ; FUN_00bf40f0 */

void FUN_00bf40f0(int *param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_0000001c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  int iStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_018036f8;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  iVar2 = *param_1;
  uVar1 = *(undefined4 *)(iVar2 + 8);
  uStack_40 = 0;
  uVar3 = *(uint *)(iVar2 + 0x30);
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    uStack_40 = uVar3;
    if ((uVar3 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      iStack_4c = iVar2 + 0x38;
      uStack_50 = 0xbf4160;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    else {
      uStack_38 = *(undefined4 *)(iVar2 + 0x38);
      uStack_34 = *(undefined4 *)(iVar2 + 0x3c);
      uStack_30 = *(undefined4 *)(iVar2 + 0x40);
      uStack_2c = *(undefined4 *)(iVar2 + 0x44);
      uStack_28 = *(undefined8 *)(iVar2 + 0x48);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8._0_1_ = 1;
  uVar3 = *(uint *)(iVar2 + 0x10);
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(iVar2 + 0x18,&uStack_58,0);
    }
    else {
      uStack_58 = *(undefined4 *)(iVar2 + 0x18);
      uStack_54 = *(undefined4 *)(iVar2 + 0x1c);
      uStack_50 = *(undefined4 *)(iVar2 + 0x20);
      iStack_4c = *(int *)(iVar2 + 0x24);
      uStack_48 = *(ulonglong *)(iVar2 + 0x28);
    }
  }
  iStack_8._0_1_ = 2;
  FUN_0054ef60(&param_2);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_00befa80(uVar1);
  if (0xf < in_stack_0000001c) {
    uVar3 = in_stack_0000001c + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
        uStack_28 = CONCAT44(&UNK_00bf4211,(undefined4)uStack_28);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_28 = CONCAT44(uVar3,iVar2);
    uStack_2c = 0xbf41f9;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26854 ; VA 0x00bf4220 ; FUN_00bf4220 */

int FUN_00bf4220(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_01803728;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  iVar5 = *param_1;
  uVar3 = *(undefined4 *)(iVar5 + 8);
  uVar4 = *(uint *)(iVar5 + 0x28);
  ExceptionList = &pvStack_10;
  if ((uVar4 != 0) && (ExceptionList = &pvStack_10, (uVar4 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(uVar4 & 0xfffffffe))(iVar5 + 0x30);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iStack_8._0_1_ = 2;
  FUN_00bedad0(iVar5 + 0xc);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  iVar5 = FUN_00befc10(uVar3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 26855 ; VA 0x00bf4320 ; FUN_00bf4320 */

int FUN_00bf4320(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01803748;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar3 = *param_1;
  param_1 = &param_2;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00be9f00(param_1,uVar3,&param_1,0);
  piVar4 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 26856 ; VA 0x00bf43a0 ; FUN_00bf43a0 */

void FUN_00bf43a0(int *param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  code *pcVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_0000001c;
  undefined auStack_70 [16];
  undefined4 uStack_60;
  undefined4 *puStack_5c;
  undefined auStack_4c [24];
  int aiStack_34 [5];
  uint uStack_20;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01803788;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puVar1 = (undefined4 *)*param_1;
  uStack_14 = puVar1[4];
  uVar2 = puVar1[5];
  puStack_5c = &param_2;
  uStack_60 = 0xbf43e5;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  puStack_5c = puVar1 + 6;
  uStack_8._0_1_ = 1;
  uStack_60 = 0xbf43f5;
  FUN_00bedad0();
  puStack_18 = auStack_70;
  uStack_8._0_1_ = 3;
  pcVar3 = (code *)*puVar1;
  FUN_0054ef60(aiStack_34);
  uStack_8._0_1_ = 4;
  FUN_00bedad0(auStack_4c);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  (*pcVar3)(uStack_14,uVar2);
  FUN_00612320();
  if (0xf < uStack_20) {
    uVar5 = uStack_20 + 1;
    iVar4 = aiStack_34[0];
    if (0xfff < uVar5) {
      iVar4 = *(int *)(aiStack_34[0] + -4);
      uVar5 = uStack_20 + 0x24;
      if (0x1f < (aiStack_34[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    iVar4 = param_2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_2 + -4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26857 ; VA 0x00bf44c0 ; FUN_00bf44c0 */

void FUN_00bf44c0(undefined4 *param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar1 = *param_1;
  param_1 = &param_2;
  ExceptionList = &pvStack_10;
  FUN_00bea080(param_1,uVar1,&param_1,0);
  if (0xf < in_stack_0000001c) {
    uVar3 = in_stack_0000001c + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26858 ; VA 0x00bf4540 ; FUN_00bf4540 */

void FUN_00bf4540(int *param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_0000001c;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  int iStack_54;
  ulonglong uStack_50;
  uint uStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_018037b8;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  iVar4 = *param_1;
  uVar1 = *(undefined4 *)(iVar4 + 0x10);
  uVar2 = *(undefined4 *)(iVar4 + 8);
  uVar3 = *(undefined4 *)(iVar4 + 0x14);
  uStack_48 = 0;
  uVar5 = *(uint *)(iVar4 + 0x50);
  ExceptionList = &pvStack_10;
  if (uVar5 != 0) {
    uStack_48 = uVar5;
    if ((uVar5 & 1) == 0) {
      uStack_50 = ZEXT48(&uStack_40);
      iStack_54 = iVar4 + 0x58;
      uStack_58 = 0xbf45bc;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar5 & 0xfffffffe))();
    }
    else {
      uStack_40 = *(undefined4 *)(iVar4 + 0x58);
      uStack_3c = *(undefined4 *)(iVar4 + 0x5c);
      uStack_38 = *(undefined4 *)(iVar4 + 0x60);
      uStack_34 = *(undefined4 *)(iVar4 + 100);
      uStack_30 = *(undefined8 *)(iVar4 + 0x68);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8._0_1_ = 1;
  uVar5 = *(uint *)(iVar4 + 0x30);
  if (uVar5 != 0) {
    if ((uVar5 & 1) == 0) {
      (**(code **)(uVar5 & 0xfffffffe))(iVar4 + 0x38,&uStack_60,0);
    }
    else {
      uStack_60 = *(undefined4 *)(iVar4 + 0x38);
      uStack_5c = *(undefined4 *)(iVar4 + 0x3c);
      uStack_58 = *(undefined4 *)(iVar4 + 0x40);
      iStack_54 = *(int *)(iVar4 + 0x44);
      uStack_50 = *(ulonglong *)(iVar4 + 0x48);
    }
  }
  iStack_8._0_1_ = 2;
  FUN_00bedad0(iVar4 + 0x18);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_00befef0(uVar2,uVar1,uVar3);
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    iVar4 = param_2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_2 + -4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar4) - 4U) {
        uStack_30 = CONCAT44(&UNK_00bf4673,(undefined4)uStack_30);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_30 = CONCAT44(uVar5,iVar4);
    uStack_34 = 0xbf465b;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26859 ; VA 0x00bf4680 ; FUN_00bf4680 */

uint FUN_00bf4680(void)

{
  int iVar1;
  
  iVar1 = FUN_00bea180();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 26860 ; VA 0x00bf46a0 ; FUN_00bf46a0 */

uint FUN_00bf46a0(void)

{
  int iVar1;
  
  iVar1 = FUN_00bea180();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 26861 ; VA 0x00bf46c0 ; FUN_00bf46c0 */

undefined FUN_00bf46c0(undefined4 param_1,undefined4 param_2,int *param_3,int *param_4)

{
  int iVar1;
  void **ppvVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  undefined uVar7;
  int *piVar8;
  int *piVar9;
  byte *pbVar10;
  longlong lVar11;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  byte *pbStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_018037e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piStack_14 = (int *)*param_3;
  piStack_1c = (int *)param_3[1];
  ExceptionList = &pvStack_10;
  ppvVar2 = &pvStack_10;
  if (piStack_14 != piStack_1c) {
    do {
      iVar1 = *piStack_14;
      iVar3 = FUN_008881d0();
      piVar9 = piStack_14;
      if (iVar1 == iVar3) {
        iVar1 = *piStack_14;
        iVar3 = FUN_008881d0();
        if (iVar1 != iVar3) {
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("Variant cast failed");
        }
        piVar8 = piVar9 + 2;
        if (piVar9[1] == 0) {
          piVar8 = (int *)0x0;
        }
        piVar9 = (int *)piVar8[1];
        if (piVar9 != (int *)0x0) {
          LOCK();
          piVar9[1] = piVar9[1] + 1;
          UNLOCK();
          piVar9 = (int *)piVar8[1];
        }
        pbVar10 = (byte *)*piVar8;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        uStack_2c = 0;
        uStack_28 = 0xf;
        auStack_3c[0] = auStack_3c[0] & 0xffffff00;
        pbStack_24 = pbVar10;
        piStack_20 = piVar9;
        FUN_005542c0(&DAT_018c1fd8,2);
        pbVar10 = pbVar10 + *pbVar10 + 1;
        uVar4 = FUN_0055c740(pbVar10,auStack_3c);
        FUN_00562fc0(&piStack_18,uVar4,auStack_3c,
                     -(uint)(pbVar10 != (byte *)0x0) & (uint)(pbVar10 + 1));
        if (0xf < uStack_28) {
          uVar6 = uStack_28 + 1;
          uVar5 = auStack_3c[0];
          if (0xfff < uVar6) {
            uVar5 = *(uint *)(auStack_3c[0] - 4);
            uVar6 = uStack_28 + 0x24;
            if (0x1f < (auStack_3c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar5,uVar6);
        }
        uStack_2c = 0;
        uStack_28 = 0xf;
        auStack_3c[0] = auStack_3c[0] & 0xffffff00;
        if (((piStack_18 != (int *)0x0) && (*(char *)(piStack_18[8] + 0x21) != '\0')) &&
           (lVar11 = FUN_00563790(), lVar11 == CONCAT44(param_2,param_1))) {
          if (piVar9 != (int *)0x0) {
            LOCK();
            iVar1 = piVar9[1] + -1;
            piVar9[1] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)*piVar9)();
              LOCK();
              iVar1 = piVar9[2] + -1;
              piVar9[2] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)(*piVar9 + 4))();
              }
            }
          }
          uVar7 = 1;
          goto LAB_00bf4842;
        }
        uStack_8 = uStack_8 & 0xffffff00;
        if (piVar9 != (int *)0x0) {
          LOCK();
          iVar1 = piVar9[1] + -1;
          piVar9[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar9)();
            LOCK();
            iVar1 = piVar9[2] + -1;
            piVar9[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar9 + 4))();
            }
          }
        }
      }
      piStack_14 = piStack_14 + 0x34;
      ppvVar2 = (void **)ExceptionList;
    } while (piStack_14 != piStack_1c);
  }
  ExceptionList = ppvVar2;
  uVar7 = 0;
LAB_00bf4842:
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar1 = param_4[1] + -1;
    param_4[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar9 = param_4 + 2;
      iVar1 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 26862 ; VA 0x00bf48c0 ; FUN_00bf48c0 */

void FUN_00bf48c0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00bfa7a0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 26863 ; VA 0x00bf4900 ; FUN_00bf4900 */

void FUN_00bf4900(uint *param_1,uint param_2,uint param_3,uint param_4,uint param_5)

{
  uint uVar1;
  uint uVar2;
  
  uVar1 = param_4;
  uVar2 = param_5;
  if (((int)param_5 <= (int)param_3) && (((int)param_5 < (int)param_3 || (param_4 < param_2)))) {
    uVar1 = param_2;
    uVar2 = param_3;
    param_2 = param_4;
    param_3 = param_5;
  }
  param_1[1] = param_3;
  *param_1 = param_2;
  param_1[3] = uVar2;
  param_1[2] = uVar1;
  return;
}



/* FUNCTION 26864 ; VA 0x00bf4940 ; FUN_00bf4940 */

void FUN_00bf4940(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c49af;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar4 = *param_1;
      ExceptionList = &pvStack_10;
      iVar3 = FUN_01674e20(0x30);
      uStack_8 = 0;
      if (iVar3 != 0) {
        iVar4 = FUN_00bec830(iVar4);
        *param_2 = iVar4;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        piVar1 = *(int **)(iVar4 + 0x2c);
        ExceptionList = &pvStack_10;
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar3 = piVar1[2] + -1;
          ExceptionList = &pvStack_10;
          piVar1[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        uVar2 = *(uint *)(iVar4 + 8);
        uStack_8 = 1;
        if (uVar2 != 0) {
          if ((uVar2 & 1) == 0) {
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              (**(code **)(uVar2 & 0xfffffffe))(iVar4 + 0x10,iVar4 + 0x10,2);
            }
          }
          *(undefined4 *)(iVar4 + 8) = 0;
        }
        FUN_01674ea0(iVar4,0x30);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1df9aa0);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_1963c5b29987058524fc3f8f5e63133b>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26865 ; VA 0x00bf4ac0 ; FUN_00bf4ac0 */

void FUN_00bf4ac0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b7ff;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x38);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00bec8c0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c3170();
        FUN_01674ea0(iVar2,0x38);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1df9a30);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_1aca4dc6978e022fff16957f9d714c0c>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26866 ; VA 0x00bf4c10 ; FUN_00bf4c10 */

void FUN_00bf4c10(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b7ff;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x38);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00bec8c0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c3170();
        FUN_01674ea0(iVar2,0x38);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1df99c0);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_22df49abd67e1cf83d5389b3db59051c>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26867 ; VA 0x00bf4d60 ; FUN_00bf4d60 */

int * FUN_00bf4d60(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      param_2[4] = param_1[4];
      piVar3 = (int *)param_1[5];
      param_2[5] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00bf4e27. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00bf4d9e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dfa928);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_5cdd3995f1a6a54379fec7cacbe37bfc>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 26868 ; VA 0x00bf4e40 ; FUN_00bf4e40 */

void FUN_00bf4e40(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c005f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x58);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00bec960(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0096d6c0();
        FUN_01674ea0(iVar2,0x58);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1df9a68);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_73b6d769bb799432a26e747b601c4ae7>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26869 ; VA 0x00bf4f90 ; FUN_00bf4f90 */

void FUN_00bf4f90(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c005f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x58);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00beca40(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00bedf90();
        FUN_01674ea0(iVar2,0x58);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1df9ad8);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_831c49aaf07d92f0228a06234e84c776>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26870 ; VA 0x00bf50e0 ; FUN_00bf50e0 */

int * FUN_00bf50e0(int param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      piVar3 = (int *)FUN_00becb30(param_1);
      if (param_3 == 1) {
        piVar2 = *(int **)(param_1 + 0x14);
        if (piVar2 != (int *)0x0) {
          LOCK();
          piVar1 = piVar2 + 2;
          iVar4 = *piVar1;
          piVar3 = (int *)*piVar1;
          *piVar1 = iVar4 + -1;
          UNLOCK();
          if (iVar4 + -1 == 0) {
            piVar3 = (int *)(**(code **)(*piVar2 + 4))();
          }
        }
        piVar2 = *(int **)(param_1 + 0xc);
        if (piVar2 != (int *)0x0) {
          LOCK();
          piVar1 = piVar2 + 1;
          iVar4 = *piVar1;
          piVar3 = (int *)*piVar1;
          *piVar1 = iVar4 + -1;
          UNLOCK();
          if (iVar4 + -1 == 0) {
            piVar3 = (int *)(**(code **)*piVar2)();
            LOCK();
            piVar1 = piVar2 + 2;
            iVar4 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar4 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00bf5184. Too many branches */
                    /* WARNING: Treating indirect jump as call */
              piVar3 = (int *)(**(code **)(*piVar2 + 4))();
              return piVar3;
            }
          }
        }
      }
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)FUN_00bf0040(0);
      return piVar3;
    }
    if (param_3 == 3) {
      piVar3 = (int *)FUN_0170d8dd(*param_2 + 4,0x1df945c);
      iVar4 = 0;
      if (piVar3 == (int *)0x0) {
        iVar4 = param_1;
      }
      *param_2 = iVar4;
      return piVar3;
    }
  }
  *param_2 = (int)&<lambda_849aee767121ede5ce7f921ca324fe9b>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 26871 ; VA 0x00bf51a0 ; FUN_00bf51a0 */

void FUN_00bf51a0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1dfa880);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_8a48455cf3991658619cb31e60b76c7d>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 26872 ; VA 0x00bf5200 ; FUN_00bf5200 */

void FUN_00bf5200(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      return;
    }
    if (param_3 == 1) {
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1dfa8f0);
      iVar2 = 0;
      if (iVar1 == 0) {
        iVar2 = param_1;
      }
      *param_2 = iVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_985bea9bb31204137d47a8aeebf89ac9>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 26873 ; VA 0x00bf5260 ; FUN_00bf5260 */

void FUN_00bf5260(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c005f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x58);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00bec960(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0096d6c0();
        FUN_01674ea0(iVar2,0x58);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1df99f8);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_9e4d5d2056449d41233829c1647398d0>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26874 ; VA 0x00bf53b0 ; FUN_00bf53b0 */

void FUN_00bf53b0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1dfa848);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_babbdc277ac900c3c556046b79aaf95f>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 26875 ; VA 0x00bf5410 ; FUN_00bf5410 */

int * FUN_00bf5410(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = 0;
      param_2[2] = 0;
      if (param_1[2] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[2] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[1] = param_1[1];
      piVar3 = (int *)param_1[2];
      param_2[2] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[2];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00bf54f2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[2];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00bf5466. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dfa8b8);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_c40c0ccea3f6e93ffa6b602ff990041e>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 26876 ; VA 0x00bf5510 ; FUN_00bf5510 */

void FUN_00bf5510(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c000f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x40);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00becb90(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00bee030();
        FUN_01674ea0(iVar2,0x40);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1df982c);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_f92dcbfe1be032bee62b7cf57ac0f5c3>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26877 ; VA 0x00bf5660 ; FUN_00bf5660 */

void FUN_00bf5660(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar3 = param_1[1];
      iVar1 = param_1[2];
      iVar2 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar3;
      param_2[2] = iVar1;
      param_2[3] = iVar2;
      *(undefined8 *)(param_2 + 4) = *(undefined8 *)(param_1 + 4);
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1df9c2c);
      piVar4 = (int *)0x0;
      if (iVar3 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf2<void,class_RBX::FriendService,__int64,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::list3<class_boost::_bi::value<class_RBX::FriendService*>,class_boost::_bi::value<__int64>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 26878 ; VA 0x00bf56d0 ; FUN_00bf56d0 */

void FUN_00bf56d0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar3 = param_1[1];
      iVar1 = param_1[2];
      iVar2 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar3;
      param_2[2] = iVar1;
      param_2[3] = iVar2;
      *(undefined8 *)(param_2 + 4) = *(undefined8 *)(param_1 + 4);
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1df9b14);
      piVar4 = (int *)0x0;
      if (iVar3 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf2<void,class_RBX::FriendService,__int64,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>_>,class_boost::_bi::list3<class_boost::_bi::value<class_RBX::FriendService*>,class_boost::_bi::value<__int64>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 26879 ; VA 0x00bf5740 ; FUN_00bf5740 */

void FUN_00bf5740(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar3 = param_1[1];
      iVar1 = param_1[2];
      iVar2 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar3;
      param_2[2] = iVar1;
      param_2[3] = iVar2;
      *(undefined8 *)(param_2 + 4) = *(undefined8 *)(param_1 + 4);
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dfa52c);
      piVar4 = (int *)0x0;
      if (iVar3 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf2<void,class_RBX::FriendService,__int64,class_std::shared_ptr<class_boost::unordered::unordered_map<__int64,enum_RBX::FriendService_FriendStatus,struct_boost::hash<__int64>,struct_std::equal_to<__int64>,class_std::allocator<struct_std::pair<__int64_const_,enum_RBX::FriendService_FriendStatus>_>_>_>_>,class_boost::_bi::list3<class_boost::_bi::value<class_RBX::FriendService*>,class_boost::_bi::value<__int64>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 26880 ; VA 0x00bf57b0 ; FUN_00bf57b0 */

void FUN_00bf57b0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a13f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x50);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        puVar2[1] = puVar1[1];
        FUN_00beccf0(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0096ca80();
        FUN_01674ea0(iVar3,0x50);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1df91ac);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf3<void,class_RBX::FriendService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_boost::function<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::list4<class_boost::_bi::value<class_RBX::FriendService*>,struct_boost::arg<1>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26881 ; VA 0x00bf5910 ; FUN_00bf5910 */

void FUN_00bf5910(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018037ff;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_01674e20(0x48);
      uStack_8 = 0;
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = *puVar1;
        puVar3[1] = puVar1[1];
        FUN_00becef0(puVar1 + 2);
        *param_2 = (int)puVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        uVar2 = *(uint *)(iVar4 + 0x28);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(iVar4 + 0x30,iVar4 + 0x30,2);
            }
          }
          *(undefined4 *)(iVar4 + 0x28) = 0;
        }
        FUN_00612320();
        FUN_01674ea0(iVar4,0x48);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1df9494);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf3<void,class_RBX::FriendService,class_boost::unordered::unordered_set<__int64,struct_boost::hash<__int64>,struct_std::equal_to<__int64>,class_std::allocator<__int64>_>,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,class_boost::function<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<__int64,enum_RBX::FriendService_FriendStatus,struct_boost::hash<__int64>,struct_std::equal_to<__int64>,class_std::allocator<struct_std::pair<__int64_const_,enum_RBX::FriendService_FriendStatus>_>_>_>)>_>,class_boost::_bi::list4<class_boost::_bi::value<class_RBX::FriendService*>,class_boost::_bi::value<class_boost::unordered::unordered_set<__int64,struct_boost::hash<__int64>,struct_std::equal_to<__int64>,class_std::allocator<__int64>_>_>,struct_boost::arg<1>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<__int64,enum_RBX::FriendService_FriendStatus,struct_boost::hash<__int64>,struct_std::equal_to<__int64>,class_std::allocator<struct_std::pair<__int64_const_,enum_RBX::FriendService_FriendStatus>_>_>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26882 ; VA 0x00bf5a90 ; FUN_00bf5a90 */

void FUN_00bf5a90(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dcd9f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x38);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_00becc80(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uVar1 = *(uint *)(iVar3 + 0x18);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar3 + 0x20,iVar3 + 0x20,2);
            }
          }
          *(undefined4 *)(iVar3 + 0x18) = 0;
        }
        FUN_01674ea0(iVar3,0x38);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1df9864);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf3<void,class_RBX::FriendService,__int64,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,class_boost::function<void___cdecl(bool)>_>,class_boost::_bi::list4<class_boost::_bi::value<class_RBX::FriendService*>,class_boost::_bi::value<__int64>,struct_boost::arg<1>,class_boost::_bi::value<class_boost::function<void___cdecl(bool)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26883 ; VA 0x00bf5c00 ; FUN_00bf5c00 */

void FUN_00bf5c00(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cbc1f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar5 = (undefined4 *)FUN_01674e20(0x30);
      uStack_8 = 0;
      if (puVar5 != (undefined4 *)0x0) {
        *puVar5 = *puVar1;
        puVar5[1] = puVar1[1];
        uVar2 = puVar1[3];
        uVar3 = puVar1[4];
        uVar4 = puVar1[5];
        puVar5[2] = puVar1[2];
        puVar5[3] = uVar2;
        puVar5[4] = uVar3;
        puVar5[5] = uVar4;
        FUN_00bedad0(puVar1 + 6);
        *param_2 = (int)puVar5;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar6 = *param_2;
      if (iVar6 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00612320();
        FUN_01674ea0(iVar6,0x30);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar6 = FUN_0170d8dd(*param_2 + 4,0x1dfa69c);
      if (iVar6 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf3<void,class_RBX::FriendService,__int64,class_boost::unordered::unordered_set<__int64,struct_boost::hash<__int64>,struct_std::equal_to<__int64>,class_std::allocator<__int64>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::list4<class_boost::_bi::value<class_RBX::FriendService*>,class_boost::_bi::value<__int64>,class_boost::_bi::value<class_boost::unordered::unordered_set<__int64,struct_boost::hash<__int64>,struct_std::equal_to<__int64>,class_std::allocator<__int64>_>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26884 ; VA 0x00bf5d60 ; FUN_00bf5d60 */

void FUN_00bf5d60(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c007f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x68);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        puVar2[1] = puVar1[1];
        FUN_00bed110(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00bee360();
        FUN_01674ea0(iVar3,0x68);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1df9d14);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf4<void,class_RBX::FriendService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_boost::unordered::unordered_set<__int64,struct_boost::hash<__int64>,struct_std::equal_to<__int64>,class_std::allocator<__int64>_>,class_boost::function<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<__int64,enum_RBX::FriendService_FriendStatus,struct_boost::hash<__int64>,struct_std::equal_to<__int64>,class_std::allocator<struct_std::pair<__int64_const_,enum_RBX::FriendService_FriendStatus>_>_>_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::list5<class_boost::_bi::value<class_RBX::FriendService*>,struct_boost::arg<1>,class_boost::_bi::value<class_boost::unordered::unordered_set<__int64,struct_boost::hash<__int64>,struct_std::equal_to<__int64>,class_std::allocator<__int64>_>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<__int64,enum_RBX::FriendService_FriendStatus,struct_boost::hash<__int64>,struct_std::equal_to<__int64>,class_std::allocator<struct_std::pair<__int64_const_,enum_RBX::FriendService_FriendStatus>_>_>_>)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26885 ; VA 0x00bf5ec0 ; FUN_00bf5ec0 */

void FUN_00bf5ec0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bffef;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x70);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        puVar2[1] = puVar1[1];
        FUN_00bed350(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00bee3f0();
        FUN_01674ea0(iVar3,0x70);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dfa13c);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf4<void,class_RBX::FriendService,__int64,class_boost::unordered::unordered_set<__int64,struct_boost::hash<__int64>,struct_std::equal_to<__int64>,class_std::allocator<__int64>_>,class_boost::function<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<__int64,enum_RBX::FriendService_FriendStatus,struct_boost::hash<__int64>,struct_std::equal_to<__int64>,class_std::allocator<struct_std::pair<__int64_const_,enum_RBX::FriendService_FriendStatus>_>_>_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::list5<class_boost::_bi::value<class_RBX::FriendService*>,class_boost::_bi::value<__int64>,class_boost::_bi::value<class_boost::unordered::unordered_set<__int64,struct_boost::hash<__int64>,struct_std::equal_to<__int64>,class_std::allocator<__int64>_>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<__int64,enum_RBX::FriendService_FriendStatus,struct_boost::hash<__int64>,struct_std::equal_to<__int64>,class_std::allocator<struct_std::pair<__int64_const_,enum_RBX::FriendService_FriendStatus>_>_>_>)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26886 ; VA 0x00bf6020 ; FUN_00bf6020 */

void __thiscall FUN_00bf6020(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01803862;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar3 = FUN_016793f0();
  if (cVar3 != '\0') {
    FUN_01679490();
  }
  cVar3 = FUN_016793f0();
  if (cVar3 != '\0') {
    FUN_01679490();
  }
  iVar2 = (int)param_3;
  FUN_008a4210(param_2,param_3);
  if (iVar2 != 0) {
    cVar3 = FUN_0097c970(param_1,0);
    if (cVar3 != '\0') {
      FUN_006eccd0();
      uStack_8 = 0;
      uVar4 = FUN_01675290(DAT_02110da8);
      uStack_8 = 1;
      param_2 = (undefined4 *)uVar4;
      puVar5 = (undefined4 *)FUN_01674e20(0x28);
      if (puVar5 == (undefined4 *)0x0) {
        puVar5 = (undefined4 *)0x0;
      }
      else {
        *puVar5 = 0;
        puVar5[1] = 1;
        puVar5[2] = FUN_00bf1aa0;
        puVar5[3] = _guard_check_icall;
        puVar5[4] = 0;
        puVar5[5] = param_1 + 0x60;
        puVar5[6] = FUN_00bf1e70;
        puVar5[7] = 0;
        puVar5[8] = param_1;
        puVar5[9] = uStack_2c;
      }
      FUN_016797d0(puVar5);
      if (puVar5 != (undefined4 *)0x0) {
        LOCK();
        puVar5[1] = puVar5[1] + 1;
        UNLOCK();
      }
      uStack_8 = 2;
      param_3 = puVar5;
      FUN_01675290(uVar4);
      uStack_8 = 3;
      cVar3 = FUN_01679300(&param_3);
      if (cVar3 != '\0') {
        FUN_01679490();
        FUN_016791c0(&param_3);
      }
      uStack_8 = 0xffffffff;
      if (param_3 != (undefined4 *)0x0) {
        piVar1 = param_3 + 1;
        LOCK();
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          FUN_01674ea0(param_3);
        }
      }
      param_3 = (undefined4 *)(param_1 + 0x58);
      FUN_006eccd0();
      uStack_8 = 4;
      uVar4 = FUN_01675290(DAT_02110da8);
      uStack_8 = 5;
      puVar5 = (undefined4 *)FUN_01674e20(0x28);
      if (puVar5 == (undefined4 *)0x0) {
        puVar5 = (undefined4 *)0x0;
      }
      else {
        *puVar5 = 0;
        puVar5[1] = 1;
        puVar5[2] = FUN_00bf1aa0;
        puVar5[3] = _guard_check_icall;
        puVar5[4] = 0;
        puVar5[5] = param_3;
        puVar5[6] = FUN_00bf1e40;
        puVar5[7] = 0;
        puVar5[8] = param_1;
        puVar5[9] = uStack_2c;
      }
      FUN_016797d0(puVar5);
      if (puVar5 != (undefined4 *)0x0) {
        LOCK();
        puVar5[1] = puVar5[1] + 1;
        UNLOCK();
      }
      uStack_8 = 6;
      param_2 = puVar5;
      FUN_01675290(uVar4);
      uStack_8 = 7;
      cVar3 = FUN_01679300(&param_2);
      if (cVar3 != '\0') {
        FUN_01679490();
        FUN_016791c0(&param_2);
      }
      if (param_2 != (undefined4 *)0x0) {
        piVar1 = param_2 + 1;
        LOCK();
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          FUN_01674ea0(param_2);
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26887 ; VA 0x00bf62d0 ; FUN_00bf62d0 */

void __thiscall FUN_00bf62d0(int param_1,int param_2,uint param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  int iStack_c;
  int iStack_8;
  
  iVar1 = param_2;
  if (DAT_01ef7604 != '\0') {
    FUN_016774b0(DAT_01ef7604,"FriendService:PlayerAdded %lld",param_2);
  }
  cVar2 = FUN_00971ce0(param_1,0);
  uVar4 = param_3;
  if (cVar2 != '\0') {
    FUN_00bf9b70(iVar1,param_3,param_1 + 0x134);
  }
  iVar3 = param_1 + 0x135 + (uint)*(byte *)(param_1 + 0x134);
  if (((int)uVar4 < 1) && ((int)uVar4 < 0)) {
    iStack_c = -1 - iVar1;
    uVar4 = -uVar4 - 1;
  }
  else {
    iStack_c = iVar1;
  }
  FUN_00606ff0(&iStack_8,(uVar4 >> 2) + uVar4 * 0x40 + iVar1 ^ uVar4,&param_2,
               -(uint)(iVar3 != 0) & iVar3 + 1U);
  if (iStack_8 == 0) {
    FUN_00bf36a0(&iStack_c,&param_2);
  }
  return;
}



/* FUNCTION 26888 ; VA 0x00bf63a0 ; FUN_00bf63a0 */

int * __thiscall FUN_00bf63a0(int param_1,int param_2,uint param_3)

{
  uint uVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  int *piVar7;
  uint uStack_8;
  
  if (DAT_01ef7604 != '\0') {
    FUN_01677520(DAT_01ef7604,"FriendService:PlayerRemoving %lld",param_2,param_3);
  }
  if (*(int *)(param_1 + 0x10c) == 0) {
    piVar3 = (int *)0x0;
  }
  else {
    piVar3 = *(int **)(*(int *)(param_1 + 0x118) + *(int *)(param_1 + 0x108) * 4);
  }
  do {
    while( true ) {
      if (piVar3 == (int *)0x0) {
        FUN_00bf0dc0(param_2,param_3);
        piVar3 = (int *)FUN_00bf0f80(param_2,param_3);
        if (*(int *)(param_1 + 0x13c) != 0) {
          uVar5 = param_3;
          if (((int)param_3 < 1) && ((int)param_3 < 0)) {
            uVar5 = ~param_3;
          }
          uVar5 = (uVar5 >> 2) + uVar5 * 0x40 + param_2 ^ uVar5;
          uVar6 = uVar5 % *(uint *)(param_1 + 0x138);
          piVar3 = *(int **)(param_1 + 0x148);
          piVar7 = (int *)piVar3[uVar6];
          if ((piVar7 != (int *)0x0) && (piVar4 = (int *)*piVar7, (int *)*piVar7 != (int *)0x0)) {
            while( true ) {
              piVar2 = piVar4;
              uVar1 = piVar2[1];
              piVar3 = (int *)(uVar1 / *(uint *)(param_1 + 0x138));
              if (uVar1 % *(uint *)(param_1 + 0x138) != uVar6) break;
              if (((uVar1 == uVar5) && (param_2 == piVar2[2])) && (param_3 == piVar2[3])) {
                piVar3 = (int *)*piVar2;
                piVar4 = piVar3;
                while( true ) {
                  *piVar7 = (int)piVar4;
                  FUN_01674ea0(piVar2,0x10);
                  *(int *)(param_1 + 0x13c) = *(int *)(param_1 + 0x13c) + -1;
                  piVar2 = (int *)*piVar7;
                  if (piVar2 == piVar3) break;
                  piVar4 = (int *)*piVar2;
                }
                if (piVar2 != (int *)0x0) {
                  uVar5 = (uint)piVar2[1] % *(uint *)(param_1 + 0x138);
                  if (uVar6 == uVar5) {
                    return (int *)((uint)piVar2[1] / *(uint *)(param_1 + 0x138));
                  }
                  *(int **)(*(int *)(param_1 + 0x148) + uVar5 * 4) = piVar7;
                }
                piVar3 = (int *)(*(int *)(param_1 + 0x148) + uVar6 * 4);
                if ((int *)*piVar3 != piVar7) {
                  return piVar3;
                }
                *piVar3 = 0;
                return piVar3;
              }
              piVar4 = (int *)*piVar2;
              piVar7 = piVar2;
              if (piVar4 == (int *)0x0) {
                return piVar4;
              }
            }
          }
        }
        return piVar3;
      }
      if (((piVar3[2] == param_2) && (piVar3[3] == param_3)) ||
         ((piVar3[4] == param_2 && (piVar3[5] == param_3)))) break;
      piVar3 = (int *)*piVar3;
    }
    uStack_8 = (uint)piVar3[1] % *(uint *)(param_1 + 0x108);
    piVar7 = (int *)*piVar3;
    piVar4 = *(int **)(*(int *)(param_1 + 0x118) + uStack_8 * 4);
    for (piVar2 = (int *)*piVar4; piVar2 != piVar3; piVar2 = (int *)*piVar2) {
      piVar4 = piVar2;
    }
    do {
      *piVar4 = *piVar2;
      FUN_01674ea0(piVar2,0x20);
      *(int *)(param_1 + 0x10c) = *(int *)(param_1 + 0x10c) + -1;
      uVar5 = uStack_8;
      if (*piVar4 == 0) {
LAB_00bf6470:
        if (*(int **)(*(int *)(param_1 + 0x118) + uStack_8 * 4) == piVar4) {
          *(undefined4 *)(*(int *)(param_1 + 0x118) + uStack_8 * 4) = 0;
        }
      }
      else {
        uVar5 = *(uint *)(*piVar4 + 4) % *(uint *)(param_1 + 0x108);
        if (uStack_8 != uVar5) {
          *(int **)(*(int *)(param_1 + 0x118) + uVar5 * 4) = piVar4;
          goto LAB_00bf6470;
        }
      }
      piVar2 = (int *)*piVar4;
      uStack_8 = uVar5;
      piVar3 = piVar7;
    } while (piVar2 != piVar7);
  } while( true );
}



/* FUNCTION 26889 ; VA 0x00bf65c0 ; FUN_00bf65c0 */

void FUN_00bf65c0(undefined4 param_1,uint param_2)

{
  undefined uVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000030;
  uint in_stack_00000034;
  uint in_stack_00000038;
  undefined4 in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined8 in_stack_00000050;
  uint in_stack_00000058;
  undefined4 in_stack_00000060;
  undefined4 in_stack_00000064;
  undefined4 in_stack_00000068;
  undefined4 in_stack_0000006c;
  undefined8 in_stack_00000070;
  undefined auStack_2e4 [20];
  undefined4 uStack_2d0;
  undefined4 *puStack_2cc;
  undefined4 *puStack_2c8;
  undefined4 *puStack_2c4;
  undefined **appuStack_2c0 [2];
  undefined4 uStack_2b8;
  undefined4 uStack_2b0;
  undefined4 *puStack_2ac;
  undefined4 *puStack_2a8;
  undefined4 *puStack_2a4;
  undefined **appuStack_2a0 [2];
  undefined4 uStack_298;
  undefined4 uStack_290;
  undefined4 *puStack_28c;
  undefined4 *puStack_288;
  char *pcStack_284;
  undefined auStack_278 [32];
  undefined auStack_258 [56];
  undefined auStack_220 [32];
  undefined auStack_200 [56];
  undefined auStack_1c8 [32];
  undefined auStack_1a8 [56];
  undefined auStack_170 [32];
  undefined auStack_150 [56];
  undefined auStack_118 [32];
  undefined auStack_f8 [56];
  undefined auStack_c0 [24];
  uint uStack_a8;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined8 uStack_90;
  uint uStack_88;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 uStack_70;
  undefined auStack_68 [24];
  uint uStack_50;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined auStack_30 [16];
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01803962;
  pvStack_10 = ExceptionList;
  pcStack_284 = (char *)param_1;
  uStack_8 = 3;
  puStack_288 = (undefined4 *)0xbf65ef;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0064e700();
  if (iVar3 == 0) {
    puStack_288 = (undefined4 *)auStack_30;
    pcStack_284 = "No HttpRbxApiService";
    puStack_28c = (undefined4 *)0xbf6a7e;
    FUN_016756b0();
    puStack_288 = (undefined4 *)auStack_30;
    pcStack_284 = "";
                    /* WARNING: Subroutine does not return */
    puStack_28c = (undefined4 *)0xbf6a8f;
    FUN_0170c2a8();
  }
  puStack_20 = (undefined *)appuStack_2a0;
  puStack_18 = auStack_68;
  puStack_2a4 = &param_2;
  puStack_2a8 = (undefined4 *)0xbf6616;
  FUN_0054ef60();
  uStack_8._0_1_ = 4;
  uStack_50 = 0;
  if (in_stack_00000058 != 0) {
    uStack_50 = in_stack_00000058;
    if ((in_stack_00000058 & 1) == 0) {
      puStack_2a8 = &uStack_48;
      puStack_2a4 = (undefined4 *)0x0;
      puStack_2ac = &stack0x00000060;
      uStack_2b0 = 0xbf6654;
      (**(code **)(in_stack_00000058 & 0xfffffffe))();
    }
    else {
      uStack_48 = in_stack_00000060;
      uStack_44 = in_stack_00000064;
      uStack_40 = in_stack_00000068;
      uStack_3c = in_stack_0000006c;
      uStack_38 = in_stack_00000070;
    }
  }
  puStack_2a4 = (undefined4 *)auStack_68;
  uStack_8._0_1_ = 5;
  puStack_2a8 = (undefined4 *)0xbf666a;
  FUN_00bec8c0();
  puStack_2a4 = (undefined4 *)auStack_150;
  uStack_8._0_1_ = 6;
  appuStack_2a0[0] = (undefined **)0x0;
  puStack_2a8 = (undefined4 *)0xbf6686;
  FUN_00bec8c0();
  puStack_2a4 = (undefined4 *)auStack_258;
  uStack_8._0_1_ = 7;
  puStack_2a8 = (undefined4 *)0xbf669c;
  FUN_00bec8c0();
  puStack_2a4 = (undefined4 *)auStack_200;
  uStack_8._0_1_ = 8;
  puStack_2a8 = (undefined4 *)0xbf66b2;
  FUN_00bec8c0();
  puStack_2a4 = (undefined4 *)auStack_f8;
  uStack_8._0_1_ = 9;
  puStack_2a8 = (undefined4 *)0xbf66c2;
  cVar2 = FUN_00585a40();
  if (cVar2 == '\0') {
    puStack_2a4 = (undefined4 *)auStack_f8;
    puStack_2a8 = (undefined4 *)0xbf66db;
    FUN_00bec8c0();
    puStack_2a4 = (undefined4 *)0x38;
    uStack_8._0_1_ = 10;
    puStack_2a8 = (undefined4 *)0xbf66e6;
    puStack_18 = (undefined *)FUN_01674e20();
    uStack_8._0_1_ = 0xb;
    if (puStack_18 == (undefined *)0x0) {
      uStack_298 = 0;
    }
    else {
      puStack_2a4 = (undefined4 *)auStack_1a8;
      puStack_2a8 = (undefined4 *)0xbf6702;
      uStack_298 = FUN_00bec8c0();
    }
    puStack_2a4 = (undefined4 *)0xbf6714;
    FUN_008c3170();
    puStack_2a4 = (undefined4 *)0xbf671f;
    FUN_008c3170();
    cStack_11 = '\x01';
  }
  else {
    puStack_2a4 = (undefined4 *)0xbf6730;
    FUN_008c3170();
    cStack_11 = '\0';
  }
  puStack_2a4 = (undefined4 *)0xbf673f;
  FUN_008c3170();
  appuStack_2a0[0] = &PTR_FUN_01960518;
  if (cStack_11 == '\0') {
    appuStack_2a0[0] = (undefined **)0x0;
  }
  puStack_2a4 = (undefined4 *)0xbf6759;
  FUN_008c3170();
  puStack_2a4 = (undefined4 *)0xbf6764;
  FUN_008c3170();
  puStack_2a4 = (undefined4 *)0xbf676c;
  FUN_008c3170();
  puStack_18 = (undefined *)appuStack_2c0;
  uStack_8._0_1_ = 0xc;
  puStack_1c = auStack_c0;
  puStack_2c4 = &param_2;
  puStack_2c8 = (undefined4 *)0xbf6790;
  FUN_0054ef60();
  uStack_8._0_1_ = 0xd;
  uStack_a8 = 0;
  if (in_stack_00000038 != 0) {
    uStack_a8 = in_stack_00000038;
    if ((in_stack_00000038 & 1) == 0) {
      puStack_2c8 = &uStack_a0;
      puStack_2c4 = (undefined4 *)0x0;
      puStack_2cc = &stack0x00000040;
      uStack_2d0 = 0xbf67dd;
      (**(code **)(in_stack_00000038 & 0xfffffffe))();
    }
    else {
      uStack_a0 = in_stack_00000040;
      uStack_9c = in_stack_00000044;
      uStack_98 = in_stack_00000048;
      uStack_94 = in_stack_0000004c;
      uStack_90 = in_stack_00000050;
    }
  }
  uStack_8._0_1_ = 0xe;
  uStack_88 = 0;
  if (in_stack_00000058 != 0) {
    uStack_88 = in_stack_00000058;
    if ((in_stack_00000058 & 1) == 0) {
      puStack_2c8 = &uStack_80;
      puStack_2c4 = (undefined4 *)0x0;
      puStack_2cc = &stack0x00000060;
      uStack_2d0 = 0xbf6824;
      (**(code **)(in_stack_00000058 & 0xfffffffe))();
    }
    else {
      uStack_80 = in_stack_00000060;
      uStack_7c = in_stack_00000064;
      uStack_78 = in_stack_00000068;
      uStack_74 = in_stack_0000006c;
      uStack_70 = in_stack_00000070;
    }
  }
  puStack_2c4 = (undefined4 *)auStack_c0;
  uStack_8._0_1_ = 0xf;
  puStack_2c8 = (undefined4 *)0xbf683d;
  FUN_00bec960();
  puStack_2c4 = (undefined4 *)auStack_118;
  uStack_8._0_1_ = 0x10;
  appuStack_2c0[0] = (undefined **)0x0;
  puStack_2c8 = (undefined4 *)0xbf6859;
  FUN_00bec960();
  puStack_2c4 = (undefined4 *)auStack_1c8;
  uStack_8._0_1_ = 0x11;
  puStack_2c8 = (undefined4 *)0xbf686f;
  FUN_00bec960();
  puStack_2c4 = (undefined4 *)auStack_220;
  uStack_8._0_1_ = 0x12;
  puStack_2c8 = (undefined4 *)0xbf6885;
  FUN_00bec960();
  puStack_2c4 = (undefined4 *)auStack_170;
  uStack_8._0_1_ = 0x13;
  puStack_2c8 = (undefined4 *)0xbf6895;
  cVar2 = FUN_00585a40();
  if (cVar2 == '\0') {
    puStack_2c4 = (undefined4 *)auStack_170;
    puStack_2c8 = (undefined4 *)0xbf68ae;
    FUN_00bec960();
    puStack_2c4 = (undefined4 *)0x58;
    uStack_8._0_1_ = 0x14;
    puStack_2c8 = (undefined4 *)0xbf68b9;
    puStack_1c = (undefined *)FUN_01674e20();
    uStack_8._0_1_ = 0x15;
    if (puStack_1c == (undefined *)0x0) {
      uStack_2b8 = 0;
    }
    else {
      puStack_2c4 = (undefined4 *)auStack_278;
      puStack_2c8 = (undefined4 *)0xbf68d5;
      uStack_2b8 = FUN_00bec960();
    }
    puStack_2c4 = (undefined4 *)0xbf68e7;
    FUN_0096d6c0();
    puStack_2c4 = (undefined4 *)0xbf68f2;
    FUN_0096d6c0();
    cStack_11 = '\x01';
  }
  else {
    puStack_2c4 = (undefined4 *)0xbf6903;
    FUN_0096d6c0();
    cStack_11 = '\0';
  }
  puStack_2c4 = (undefined4 *)0xbf6912;
  FUN_0096d6c0();
  appuStack_2c0[0] = &PTR_FUN_01960510;
  if (cStack_11 == '\0') {
    appuStack_2c0[0] = (undefined **)0x0;
  }
  puStack_2c4 = (undefined4 *)0xbf692c;
  FUN_0096d6c0();
  puStack_2c4 = (undefined4 *)0xbf6937;
  FUN_0096d6c0();
  puStack_2c4 = (undefined4 *)0xbf6942;
  FUN_0096d6c0();
  puStack_2c4 = (undefined4 *)0x13;
  puStack_2c8 = (undefined4 *)0x2;
  puStack_2cc = (undefined4 *)0x0;
  puStack_1c = auStack_2e4;
  uStack_8._0_1_ = 0x16;
  FUN_0054ef60(&stack0x00000020);
  uStack_8._0_1_ = 0x17;
  FUN_0054ef60(&param_2);
  uStack_8._0_1_ = 3;
  FUN_00bd1000();
  uStack_8._0_1_ = 2;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < in_stack_0000001c) {
    pcStack_284 = (char *)(in_stack_0000001c + 1);
    uVar4 = param_2;
    if (0xfff < pcStack_284) {
      uVar4 = *(uint *)(param_2 - 4);
      pcStack_284 = (char *)(in_stack_0000001c + 0x24);
      if (0x1f < (param_2 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        pcStack_284 = (char *)0xbf6a94;
        uStack_8._0_1_ = uVar1;
        FUN_017167a3();
      }
    }
    puStack_28c = (undefined4 *)0xbf69af;
    puStack_288 = (undefined4 *)uVar4;
    FUN_01674ea0();
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_2 = param_2 & 0xffffff00;
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000034) {
    pcStack_284 = (char *)(in_stack_00000034 + 1);
    uVar4 = in_stack_00000020;
    if (0xfff < pcStack_284) {
      uVar4 = *(uint *)(in_stack_00000020 - 4);
      pcStack_284 = (char *)(in_stack_00000034 + 0x24);
      if (0x1f < (in_stack_00000020 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        pcStack_284 = &UNK_00bf6a99;
        uStack_8._0_1_ = uVar1;
        FUN_017167a3();
      }
    }
    puStack_28c = (undefined4 *)0xbf69f9;
    puStack_288 = (undefined4 *)uVar4;
    FUN_01674ea0();
  }
  in_stack_00000030 = 0;
  in_stack_00000034 = 0xf;
  in_stack_00000020 = in_stack_00000020 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
  if (in_stack_00000038 != 0) {
    if (((in_stack_00000038 & 1) == 0) &&
       (*(code **)(in_stack_00000038 & 0xfffffffe) != (code *)0x0)) {
      puStack_28c = &stack0x00000040;
      pcStack_284 = (char *)0x2;
      uStack_290 = 0xbf6a2f;
      puStack_288 = puStack_28c;
      (**(code **)(in_stack_00000038 & 0xfffffffe))();
    }
    in_stack_00000038 = 0;
  }
  uStack_8 = 0x19;
  if (((in_stack_00000058 != 0) && ((in_stack_00000058 & 1) == 0)) &&
     (*(code **)(in_stack_00000058 & 0xfffffffe) != (code *)0x0)) {
    puStack_28c = &stack0x00000060;
    pcStack_284 = (char *)0x2;
    uStack_290 = 0xbf6a5d;
    puStack_288 = puStack_28c;
    (**(code **)(in_stack_00000058 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26890 ; VA 0x00bf6aa0 ; FUN_00bf6aa0 */

void FUN_00bf6aa0(undefined4 param_1,uint param_2)

{
  undefined uVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000030;
  uint in_stack_00000034;
  uint in_stack_00000038;
  undefined4 in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined8 in_stack_00000050;
  uint in_stack_00000058;
  undefined4 in_stack_00000060;
  undefined4 in_stack_00000064;
  undefined4 in_stack_00000068;
  undefined4 in_stack_0000006c;
  undefined8 in_stack_00000070;
  undefined auStack_2e4 [20];
  undefined4 uStack_2d0;
  undefined4 *puStack_2cc;
  undefined4 *puStack_2c8;
  undefined4 *puStack_2c4;
  undefined **appuStack_2c0 [2];
  undefined4 uStack_2b8;
  undefined4 uStack_2b0;
  undefined4 *puStack_2ac;
  undefined4 *puStack_2a8;
  undefined4 *puStack_2a4;
  undefined **appuStack_2a0 [2];
  undefined4 uStack_298;
  undefined4 uStack_290;
  undefined4 *puStack_28c;
  undefined4 *puStack_288;
  char *pcStack_284;
  undefined auStack_278 [32];
  undefined auStack_258 [56];
  undefined auStack_220 [32];
  undefined auStack_200 [56];
  undefined auStack_1c8 [32];
  undefined auStack_1a8 [56];
  undefined auStack_170 [32];
  undefined auStack_150 [56];
  undefined auStack_118 [32];
  undefined auStack_f8 [56];
  undefined auStack_c0 [24];
  uint uStack_a8;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined8 uStack_90;
  uint uStack_88;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 uStack_70;
  undefined auStack_68 [24];
  uint uStack_50;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined auStack_30 [16];
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01803a62;
  pvStack_10 = ExceptionList;
  pcStack_284 = (char *)param_1;
  uStack_8 = 3;
  puStack_288 = (undefined4 *)0xbf6acf;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0064e700();
  if (iVar3 == 0) {
    puStack_288 = (undefined4 *)auStack_30;
    pcStack_284 = "No HttpRbxApiService";
    puStack_28c = (undefined4 *)0xbf6f5e;
    FUN_016756b0();
    puStack_288 = (undefined4 *)auStack_30;
    pcStack_284 = "";
                    /* WARNING: Subroutine does not return */
    puStack_28c = (undefined4 *)0xbf6f6f;
    FUN_0170c2a8();
  }
  puStack_20 = (undefined *)appuStack_2a0;
  puStack_18 = auStack_68;
  puStack_2a4 = &param_2;
  puStack_2a8 = (undefined4 *)0xbf6af6;
  FUN_0054ef60();
  uStack_8._0_1_ = 4;
  uStack_50 = 0;
  if (in_stack_00000058 != 0) {
    uStack_50 = in_stack_00000058;
    if ((in_stack_00000058 & 1) == 0) {
      puStack_2a8 = &uStack_48;
      puStack_2a4 = (undefined4 *)0x0;
      puStack_2ac = &stack0x00000060;
      uStack_2b0 = 0xbf6b34;
      (**(code **)(in_stack_00000058 & 0xfffffffe))();
    }
    else {
      uStack_48 = in_stack_00000060;
      uStack_44 = in_stack_00000064;
      uStack_40 = in_stack_00000068;
      uStack_3c = in_stack_0000006c;
      uStack_38 = in_stack_00000070;
    }
  }
  puStack_2a4 = (undefined4 *)auStack_68;
  uStack_8._0_1_ = 5;
  puStack_2a8 = (undefined4 *)0xbf6b4a;
  FUN_00bec8c0();
  puStack_2a4 = (undefined4 *)auStack_150;
  uStack_8._0_1_ = 6;
  appuStack_2a0[0] = (undefined **)0x0;
  puStack_2a8 = (undefined4 *)0xbf6b66;
  FUN_00bec8c0();
  puStack_2a4 = (undefined4 *)auStack_258;
  uStack_8._0_1_ = 7;
  puStack_2a8 = (undefined4 *)0xbf6b7c;
  FUN_00bec8c0();
  puStack_2a4 = (undefined4 *)auStack_200;
  uStack_8._0_1_ = 8;
  puStack_2a8 = (undefined4 *)0xbf6b92;
  FUN_00bec8c0();
  puStack_2a4 = (undefined4 *)auStack_f8;
  uStack_8._0_1_ = 9;
  puStack_2a8 = (undefined4 *)0xbf6ba2;
  cVar2 = FUN_00585a40();
  if (cVar2 == '\0') {
    puStack_2a4 = (undefined4 *)auStack_f8;
    puStack_2a8 = (undefined4 *)0xbf6bbb;
    FUN_00bec8c0();
    puStack_2a4 = (undefined4 *)0x38;
    uStack_8._0_1_ = 10;
    puStack_2a8 = (undefined4 *)0xbf6bc6;
    puStack_18 = (undefined *)FUN_01674e20();
    uStack_8._0_1_ = 0xb;
    if (puStack_18 == (undefined *)0x0) {
      uStack_298 = 0;
    }
    else {
      puStack_2a4 = (undefined4 *)auStack_1a8;
      puStack_2a8 = (undefined4 *)0xbf6be2;
      uStack_298 = FUN_00bec8c0();
    }
    puStack_2a4 = (undefined4 *)0xbf6bf4;
    FUN_008c3170();
    puStack_2a4 = (undefined4 *)0xbf6bff;
    FUN_008c3170();
    cStack_11 = '\x01';
  }
  else {
    puStack_2a4 = (undefined4 *)0xbf6c10;
    FUN_008c3170();
    cStack_11 = '\0';
  }
  puStack_2a4 = (undefined4 *)0xbf6c1f;
  FUN_008c3170();
  appuStack_2a0[0] = &PTR_FUN_01960528;
  if (cStack_11 == '\0') {
    appuStack_2a0[0] = (undefined **)0x0;
  }
  puStack_2a4 = (undefined4 *)0xbf6c39;
  FUN_008c3170();
  puStack_2a4 = (undefined4 *)0xbf6c44;
  FUN_008c3170();
  puStack_2a4 = (undefined4 *)0xbf6c4c;
  FUN_008c3170();
  puStack_18 = (undefined *)appuStack_2c0;
  uStack_8._0_1_ = 0xc;
  puStack_1c = auStack_c0;
  puStack_2c4 = &param_2;
  puStack_2c8 = (undefined4 *)0xbf6c70;
  FUN_0054ef60();
  uStack_8._0_1_ = 0xd;
  uStack_a8 = 0;
  if (in_stack_00000038 != 0) {
    uStack_a8 = in_stack_00000038;
    if ((in_stack_00000038 & 1) == 0) {
      puStack_2c8 = &uStack_a0;
      puStack_2c4 = (undefined4 *)0x0;
      puStack_2cc = &stack0x00000040;
      uStack_2d0 = 0xbf6cbd;
      (**(code **)(in_stack_00000038 & 0xfffffffe))();
    }
    else {
      uStack_a0 = in_stack_00000040;
      uStack_9c = in_stack_00000044;
      uStack_98 = in_stack_00000048;
      uStack_94 = in_stack_0000004c;
      uStack_90 = in_stack_00000050;
    }
  }
  uStack_8._0_1_ = 0xe;
  uStack_88 = 0;
  if (in_stack_00000058 != 0) {
    uStack_88 = in_stack_00000058;
    if ((in_stack_00000058 & 1) == 0) {
      puStack_2c8 = &uStack_80;
      puStack_2c4 = (undefined4 *)0x0;
      puStack_2cc = &stack0x00000060;
      uStack_2d0 = 0xbf6d04;
      (**(code **)(in_stack_00000058 & 0xfffffffe))();
    }
    else {
      uStack_80 = in_stack_00000060;
      uStack_7c = in_stack_00000064;
      uStack_78 = in_stack_00000068;
      uStack_74 = in_stack_0000006c;
      uStack_70 = in_stack_00000070;
    }
  }
  puStack_2c4 = (undefined4 *)auStack_c0;
  uStack_8._0_1_ = 0xf;
  puStack_2c8 = (undefined4 *)0xbf6d1d;
  FUN_00bec960();
  puStack_2c4 = (undefined4 *)auStack_118;
  uStack_8._0_1_ = 0x10;
  appuStack_2c0[0] = (undefined **)0x0;
  puStack_2c8 = (undefined4 *)0xbf6d39;
  FUN_00bec960();
  puStack_2c4 = (undefined4 *)auStack_1c8;
  uStack_8._0_1_ = 0x11;
  puStack_2c8 = (undefined4 *)0xbf6d4f;
  FUN_00bec960();
  puStack_2c4 = (undefined4 *)auStack_220;
  uStack_8._0_1_ = 0x12;
  puStack_2c8 = (undefined4 *)0xbf6d65;
  FUN_00bec960();
  puStack_2c4 = (undefined4 *)auStack_170;
  uStack_8._0_1_ = 0x13;
  puStack_2c8 = (undefined4 *)0xbf6d75;
  cVar2 = FUN_00585a40();
  if (cVar2 == '\0') {
    puStack_2c4 = (undefined4 *)auStack_170;
    puStack_2c8 = (undefined4 *)0xbf6d8e;
    FUN_00bec960();
    puStack_2c4 = (undefined4 *)0x58;
    uStack_8._0_1_ = 0x14;
    puStack_2c8 = (undefined4 *)0xbf6d99;
    puStack_1c = (undefined *)FUN_01674e20();
    uStack_8._0_1_ = 0x15;
    if (puStack_1c == (undefined *)0x0) {
      uStack_2b8 = 0;
    }
    else {
      puStack_2c4 = (undefined4 *)auStack_278;
      puStack_2c8 = (undefined4 *)0xbf6db5;
      uStack_2b8 = FUN_00bec960();
    }
    puStack_2c4 = (undefined4 *)0xbf6dc7;
    FUN_0096d6c0();
    puStack_2c4 = (undefined4 *)0xbf6dd2;
    FUN_0096d6c0();
    cStack_11 = '\x01';
  }
  else {
    puStack_2c4 = (undefined4 *)0xbf6de3;
    FUN_0096d6c0();
    cStack_11 = '\0';
  }
  puStack_2c4 = (undefined4 *)0xbf6df2;
  FUN_0096d6c0();
  appuStack_2c0[0] = &PTR_FUN_01960520;
  if (cStack_11 == '\0') {
    appuStack_2c0[0] = (undefined **)0x0;
  }
  puStack_2c4 = (undefined4 *)0xbf6e0c;
  FUN_0096d6c0();
  puStack_2c4 = (undefined4 *)0xbf6e17;
  FUN_0096d6c0();
  puStack_2c4 = (undefined4 *)0xbf6e22;
  FUN_0096d6c0();
  puStack_2c4 = (undefined4 *)0x13;
  puStack_2c8 = (undefined4 *)0x2;
  puStack_2cc = (undefined4 *)0x0;
  puStack_1c = auStack_2e4;
  uStack_8._0_1_ = 0x16;
  FUN_0054ef60(&stack0x00000020);
  uStack_8._0_1_ = 0x17;
  FUN_0054ef60(&param_2);
  uStack_8._0_1_ = 3;
  FUN_00bd12f0();
  uStack_8._0_1_ = 2;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < in_stack_0000001c) {
    pcStack_284 = (char *)(in_stack_0000001c + 1);
    uVar4 = param_2;
    if (0xfff < pcStack_284) {
      uVar4 = *(uint *)(param_2 - 4);
      pcStack_284 = (char *)(in_stack_0000001c + 0x24);
      if (0x1f < (param_2 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        pcStack_284 = (char *)0xbf6f74;
        uStack_8._0_1_ = uVar1;
        FUN_017167a3();
      }
    }
    puStack_28c = (undefined4 *)0xbf6e8f;
    puStack_288 = (undefined4 *)uVar4;
    FUN_01674ea0();
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_2 = param_2 & 0xffffff00;
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000034) {
    pcStack_284 = (char *)(in_stack_00000034 + 1);
    uVar4 = in_stack_00000020;
    if (0xfff < pcStack_284) {
      uVar4 = *(uint *)(in_stack_00000020 - 4);
      pcStack_284 = (char *)(in_stack_00000034 + 0x24);
      if (0x1f < (in_stack_00000020 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        pcStack_284 = &UNK_00bf6f79;
        uStack_8._0_1_ = uVar1;
        FUN_017167a3();
      }
    }
    puStack_28c = (undefined4 *)0xbf6ed9;
    puStack_288 = (undefined4 *)uVar4;
    FUN_01674ea0();
  }
  in_stack_00000030 = 0;
  in_stack_00000034 = 0xf;
  in_stack_00000020 = in_stack_00000020 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
  if (in_stack_00000038 != 0) {
    if (((in_stack_00000038 & 1) == 0) &&
       (*(code **)(in_stack_00000038 & 0xfffffffe) != (code *)0x0)) {
      puStack_28c = &stack0x00000040;
      pcStack_284 = (char *)0x2;
      uStack_290 = 0xbf6f0f;
      puStack_288 = puStack_28c;
      (**(code **)(in_stack_00000038 & 0xfffffffe))();
    }
    in_stack_00000038 = 0;
  }
  uStack_8 = 0x19;
  if (((in_stack_00000058 != 0) && ((in_stack_00000058 & 1) == 0)) &&
     (*(code **)(in_stack_00000058 & 0xfffffffe) != (code *)0x0)) {
    puStack_28c = &stack0x00000060;
    pcStack_284 = (char *)0x2;
    uStack_290 = 0xbf6f3d;
    puStack_288 = puStack_28c;
    (**(code **)(in_stack_00000058 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26891 ; VA 0x00bf6f80 ; FUN_00bf6f80 */

void FUN_00bf6f80(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,uint param_5
                 )

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01803a88;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uVar3 = FUN_00bf46c0(param_1,param_2,param_3,param_4);
  if (param_5 != 0) {
    (**(code **)((param_5 & 0xfffffffe) + 4))(&stack0x0000001c,uVar3);
    if (param_4 != (int *)0x0) {
      LOCK();
      iVar2 = param_4[1] + -1;
      param_4[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_4)();
        LOCK();
        piVar1 = param_4 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_4 + 4))();
        }
      }
    }
    uStack_8 = 3;
    if (((param_5 != 0) && ((param_5 & 1) == 0)) &&
       (*(code **)(param_5 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_5 & 0xfffffffe))(&stack0x0000001c,&stack0x0000001c,2);
    }
    ExceptionList = pvStack_10;
    return;
  }
  uVar4 = FUN_0054fda0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar4);
}



/* FUNCTION 26892 ; VA 0x00bf7070 ; FUN_00bf7070 */

void __thiscall FUN_00bf7070(int param_1,undefined4 param_2,undefined4 param_3,uint *param_4)

{
  uint **ppuVar1;
  uint *puVar2;
  int iVar3;
  uint uVar4;
  uint *puVar5;
  uint uVar6;
  uint in_stack_0000001c;
  uint in_stack_00000020;
  uint in_stack_00000024;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint *puStack_20;
  uint *puStack_1c;
  undefined4 uStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01803ad0;
  pvStack_10 = ExceptionList;
  puStack_20 = (uint *)0x0;
  puStack_1c = (uint *)0x0;
  uStack_18 = 0;
  puStack_14 = (uint *)(param_1 + 0xd4);
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_016dee6d();
  if (iVar3 != 0) {
    FUN_016df3c9();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  iVar3 = FUN_00beebc0();
  *(undefined *)(iVar3 + 8) = 0;
  if ((uint **)(iVar3 + 0x14) != &param_4) {
    puVar5 = (uint *)&param_4;
    if (0xf < in_stack_00000020) {
      puVar5 = param_4;
    }
    FUN_005542c0(puVar5,in_stack_0000001c);
  }
  ppuVar1 = (uint **)(iVar3 + 0x38);
  puVar5 = (uint *)0x0;
  if (&puStack_20 != ppuVar1) {
    puVar5 = *ppuVar1;
    *ppuVar1 = (uint *)0x0;
    puStack_1c = *(uint **)(iVar3 + 0x3c);
    *(undefined4 *)(iVar3 + 0x3c) = 0;
    uStack_18 = *(undefined4 *)(iVar3 + 0x40);
    *(undefined4 *)(iVar3 + 0x40) = 0;
    puStack_20 = puVar5;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  iVar3 = FUN_016deec8();
  if (iVar3 != 0) {
    FUN_016df3c9();
  }
  if (puVar5 != puStack_1c) {
    puVar5 = puVar5 + 8;
    do {
      uVar4 = in_stack_0000001c;
      uStack_8._0_1_ = 2;
      puStack_14 = (uint *)&param_4;
      if (0xf < in_stack_00000020) {
        puStack_14 = param_4;
      }
      if (in_stack_0000001c < 0x10) {
        uVar6 = *puStack_14;
        uStack_40 = puStack_14[1];
        uStack_3c = puStack_14[2];
        uStack_38 = puStack_14[3];
      }
      else {
        uVar6 = in_stack_0000001c | 0xf;
        if (0x7fffffff < uVar6) {
          uVar6 = 0x7fffffff;
        }
        if (uVar6 + 1 < 0x1000) {
          if (uVar6 == 0xffffffff) {
            uVar6 = 0;
          }
          else {
            uVar6 = FUN_01674e20();
          }
        }
        else {
          iVar3 = FUN_01674e20();
          if (iVar3 == 0) goto LAB_00bf72ea;
          uVar6 = iVar3 + 0x23U & 0xffffffe0;
          *(int *)(uVar6 - 4) = iVar3;
        }
        FUN_0170c6f0(uVar6,puStack_14,uVar4 + 1);
      }
      uStack_8._0_1_ = 5;
      if (*puVar5 == 0) {
        FUN_0054fda0();
        uStack_8 = CONCAT31(uStack_8._1_3_,6);
                    /* WARNING: Subroutine does not return */
        FUN_0054e5e0();
      }
      (**(code **)((*puVar5 & 0xfffffffe) + 4))(puVar5 + 2,uVar6,uStack_40,uStack_3c,uStack_38);
      puVar2 = puVar5 + 8;
      puVar5 = puVar5 + 0x10;
    } while (puVar2 != puStack_1c);
  }
  uStack_8._0_1_ = 2;
  FUN_00a59a30();
  uStack_8._0_1_ = 0;
  if (0xf < in_stack_00000020) {
    uVar4 = in_stack_00000020 + 1;
    puVar5 = param_4;
    if (0xfff < uVar4) {
      puVar5 = (uint *)param_4[-1];
      uVar4 = in_stack_00000020 + 0x24;
      if (0x1f < (uint)((int)param_4 + (-4 - (int)puVar5))) {
LAB_00bf72ea:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar5,uVar4);
  }
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_4 = (uint *)((uint)param_4 & 0xffffff00);
  uStack_8 = 7;
  if (((in_stack_00000024 != 0) && ((in_stack_00000024 & 1) == 0)) &&
     (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000024 & 0xfffffffe))(&stack0x0000002c,&stack0x0000002c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26893 ; VA 0x00bf7310 ; FUN_00bf7310 */

void FUN_00bf7310(undefined4 param_1,undefined4 param_2,byte *param_3)

{
  int *piVar1;
  int ****ppppiVar2;
  code *pcVar3;
  int ***pppiVar4;
  uint uVar5;
  int ***pppiVar6;
  int ****ppppiVar7;
  char cVar8;
  int ****ppppiVar9;
  int iVar10;
  int iVar11;
  undefined4 *puVar12;
  int iVar13;
  int ******ppppppiVar14;
  int *piVar15;
  byte *pbVar16;
  int iVar17;
  int *****pppppiVar18;
  int in_stack_00000020;
  uint in_stack_00000028;
  uint in_stack_00000048;
  char *pcVar19;
  undefined uVar20;
  undefined4 in_stack_fffffef8;
  undefined4 in_stack_fffffefc;
  undefined4 in_stack_ffffff00;
  undefined *puVar21;
  undefined4 uVar22;
  undefined4 uVar23;
  undefined4 uVar24;
  undefined4 uVar25;
  undefined4 uVar26;
  undefined auStack_e8 [16];
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  int ****ppppiStack_d0;
  int ***pppiStack_cc;
  undefined auStack_c8 [16];
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  byte *pbStack_b0;
  int ****ppppiStack_ac;
  int *piStack_9c;
  int iStack_98;
  int iStack_94;
  int iStack_90;
  int iStack_8c;
  int iStack_88;
  int iStack_84;
  int iStack_80;
  int iStack_7c;
  int iStack_78;
  int iStack_74;
  byte *pbStack_70;
  int *piStack_6c;
  int iStack_68;
  int *piStack_64;
  int *****apppppiStack_60 [4];
  undefined4 uStack_50;
  uint uStack_4c;
  int ***pppiStack_48;
  int *piStack_44;
  int *piStack_40;
  undefined4 uStack_3c;
  int *piStack_38;
  int iStack_34;
  uint uStack_30;
  int ****ppppiStack_2c;
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01803b94;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  if (in_stack_00000020 == 0) {
    uVar22 = 0;
    uVar23 = 0xf;
    uVar20 = 0;
    ExceptionList = &pvStack_10;
    FUN_005542c0("Empty response received from web server for GetFriendsOnlineSuccess",0x43);
    FUN_005e65e0(uVar20,in_stack_fffffef8,in_stack_fffffefc,in_stack_ffffff00,uVar22,uVar23);
    goto LAB_00bf81a9;
  }
  pbStack_70 = (byte *)0x0;
  piStack_6c = (int *)0x0;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  puVar21 = &stack0x00000010;
  uVar22 = 0xbf7394;
  ExceptionList = &pvStack_10;
  cVar8 = FUN_0098f070(puVar21,&pbStack_70,0);
  pbVar16 = pbStack_70;
  if (cVar8 == '\0') {
    uVar23 = 0;
    uVar24 = 0xf;
    FUN_005542c0("Friends response was not valid JSON for GetFriendsOnlineSuccess",0x3f);
    FUN_005e65e0(cVar8,in_stack_fffffef8,uVar22,puVar21,uVar23,uVar24);
LAB_00bf8184:
    piVar15 = piStack_6c;
    if (piStack_6c == (int *)0x0) goto LAB_00bf81a9;
    LOCK();
    iVar17 = piStack_6c[1] + -1;
    piStack_6c[1] = iVar17;
    UNLOCK();
    if (iVar17 != 0) goto LAB_00bf81a9;
    (**(code **)*piStack_6c)();
    LOCK();
    piVar1 = piVar15 + 2;
    iVar17 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
  }
  else {
    uStack_50 = 0;
    uStack_4c = 0xf;
    apppppiStack_60[0] = (int *****)((uint)apppppiStack_60[0] & 0xffffff00);
    FUN_005542c0(&DAT_018be4a0,4);
    pbVar16 = pbVar16 + *pbVar16 + 1;
    uVar22 = FUN_0055c740(pbVar16,apppppiStack_60);
    ppppppiVar14 = (int ******)&ppppiStack_2c;
    uVar23 = 0xbf741f;
    FUN_00562fc0(ppppppiVar14,uVar22,apppppiStack_60,
                 -(uint)(pbVar16 != (byte *)0x0) & (uint)(pbVar16 + 1));
    FUN_005507b0();
    ppppiVar7 = ppppiStack_2c;
    ppppiVar2 = (int ****)ppppiStack_2c[8];
    ppppiVar9 = (int ****)FUN_008882f0();
    if (ppppiVar2 != ppppiVar9) {
      uVar24 = 0;
      uVar25 = 0xf;
      uVar20 = 0;
      FUN_005542c0("Friends is not of the expected type \'ValueTable\' in GetFriendsOnlineSuccess",
                   0x4b);
      FUN_005e65e0(uVar20,uVar23,ppppppiVar14,uVar22,uVar24,uVar25);
      goto LAB_00bf8184;
    }
    ppppiVar2 = (int ****)ppppiVar7[8];
    ppppiVar9 = (int ****)FUN_008882f0();
    if (ppppiVar2 != ppppiVar9) {
LAB_00bf8216:
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    ppppiStack_d0 = ppppiVar7 + 10;
    if ((int ****)ppppiVar7[9] == (int ****)0x0) {
      ppppiStack_d0 = (int ****)0x0;
    }
    pppiStack_cc = (int ***)((int *****)ppppiStack_d0)[1];
    if ((int ****)pppiStack_cc != (int ****)0x0) {
      LOCK();
      ((int ****)pppiStack_cc)[1] = (int ***)((int)((int ****)pppiStack_cc)[1] + 1);
      UNLOCK();
      pppiStack_cc = (int ***)((int *****)ppppiStack_d0)[1];
    }
    ppppiStack_d0 = (int ****)*ppppiStack_d0;
    uStack_8._0_1_ = 4;
    pppiStack_48 = pppiStack_cc;
    ppppiStack_2c = ppppiStack_d0;
    FUN_005cac50(&piStack_44);
    ppppiVar2 = (int ****)ppppiVar7[8];
    uStack_8._0_1_ = 5;
    ppppiVar9 = (int ****)FUN_008882f0();
    ppppiVar7 = ppppiStack_2c;
    piVar15 = piStack_44;
    pbVar16 = param_3;
    if (ppppiVar2 != ppppiVar9) {
      uVar24 = 0;
      uVar25 = 0xf;
      uVar20 = 0;
      FUN_005542c0("Failed to parse online friends JSON in GetFriendsOnline",0x37);
      FUN_005e65e0(uVar20,uVar23,ppppppiVar14,uVar22,uVar24,uVar25);
LAB_00bf8138:
      if (piStack_40 != (int *)0x0) {
        LOCK();
        iVar17 = piStack_40[1] + -1;
        piStack_40[1] = iVar17;
        UNLOCK();
        if (iVar17 == 0) {
          (**(code **)*piStack_40)();
          LOCK();
          iVar17 = piStack_40[2] + -1;
          piStack_40[2] = iVar17;
          UNLOCK();
          if (iVar17 == 0) {
            (**(code **)(*piStack_40 + 4))();
          }
        }
      }
      pppiVar6 = pppiStack_48;
      if ((int ****)pppiStack_48 != (int ****)0x0) {
        LOCK();
        pppiVar4 = (int ***)((int)pppiStack_48[1] + -1);
        pppiStack_48[1] = (int **)pppiVar4;
        UNLOCK();
        if (pppiVar4 == (int ***)0x0) {
          (*(code *)**pppiStack_48)();
          LOCK();
          ppppiVar2 = (int ****)(pppiVar6 + 2);
          pppiVar4 = (int ***)((int)*ppppiVar2 + -1);
          *ppppiVar2 = pppiVar4;
          UNLOCK();
          if (pppiVar4 == (int ***)0x0) {
            (*(code *)(*pppiVar6)[1])();
          }
        }
      }
      goto LAB_00bf8184;
    }
    if (param_3 < (byte *)(((int)ppppiStack_2c[1] - (int)*ppppiStack_2c) / 0xd0)) {
      uVar22 = 0xbf7502;
      FUN_006045c0(param_3,piStack_44);
      piVar15 = piStack_44;
      if (pbVar16 != (byte *)0x0) {
        iVar17 = 0;
        do {
          FUN_0056ee80((int)*ppppiVar7 + iVar17);
          iVar17 = iVar17 + 0xd0;
          pbVar16 = pbVar16 + -1;
          piVar15 = piStack_44;
        } while (pbVar16 != (byte *)0x0);
      }
    }
    else {
      FUN_0056ed30(ppppiStack_2c);
    }
    FUN_005cac50(&iStack_68);
    uStack_8._0_1_ = 6;
    FUN_00a9e690((piVar15[1] - *piVar15) / 0xd0);
    iVar17 = piVar15[1];
    iVar13 = *piVar15;
    uStack_30 = 0;
    iVar10 = iVar17 - iVar13 >> 0x1f;
    if ((iVar17 - iVar13) / 0xd0 + iVar10 != iVar10) {
      piStack_9c = (int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
      iStack_34 = 0;
      do {
        if ((uint)((iVar17 - iVar13) / 0xd0) <= uStack_30) {
LAB_00bf826a:
          FUN_00577c40();
          pcVar3 = (code *)swi(3);
          (*pcVar3)();
          return;
        }
        iVar17 = *(int *)(iVar13 + iStack_34);
        iVar10 = FUN_008881d0();
        iVar13 = iStack_34;
        if (iVar17 != iVar10) {
          uVar24 = 0;
          uVar25 = 0xf;
          uVar20 = 0;
          FUN_005542c0("Internal error: FriendEntry is not of the expected type \'ValueTable\' in GetFriendsOnline"
                       ,0x58);
          FUN_005e65e0(uVar20,uVar23,ppppppiVar14,uVar22,uVar24,uVar25);
LAB_00bf8006:
          if (piStack_64 != (int *)0x0) {
            LOCK();
            iVar17 = piStack_64[1] + -1;
            piStack_64[1] = iVar17;
            UNLOCK();
            if (iVar17 == 0) {
              (**(code **)*piStack_64)();
              LOCK();
              iVar17 = piStack_64[2] + -1;
              piStack_64[2] = iVar17;
              UNLOCK();
              if (iVar17 == 0) {
                (**(code **)(*piStack_64 + 4))();
              }
            }
          }
          goto LAB_00bf8138;
        }
        iVar17 = *piVar15;
        if ((uint)((piVar15[1] - iVar17) / 0xd0) <= uStack_30) goto LAB_00bf826a;
        iVar10 = *(int *)(iVar17 + iStack_34);
        iVar11 = FUN_008881d0();
        if (iVar10 != iVar11) goto LAB_00bf8216;
        puVar12 = (undefined4 *)(iVar13 + 8 + iVar17);
        if (*(int *)(iVar17 + 4 + iVar13) == 0) {
          puVar12 = (undefined4 *)0x0;
        }
        pppppiVar18 = (int *****)puVar12[1];
        if (pppppiVar18 != (int *****)0x0) {
          LOCK();
          pppppiVar18[1] = (int ****)((int)pppppiVar18[1] + 1);
          UNLOCK();
          pppppiVar18 = (int *****)puVar12[1];
        }
        pbVar16 = (byte *)*puVar12;
        uStack_8._0_1_ = 7;
        param_3 = pbVar16;
        pbStack_b0 = pbVar16;
        ppppiStack_ac = (int ****)pppppiVar18;
        ppppiStack_2c = (int ****)pppppiVar18;
        FUN_00888650(&uStack_3c);
        uStack_8._0_1_ = 8;
        uStack_b8 = 0;
        uStack_b4 = 0xf;
        auStack_c8[0] = 0;
        FUN_005542c0(&DAT_018c1fd8,2);
        pbVar16 = pbVar16 + *pbVar16 + 1;
        uVar22 = FUN_0055c740(pbVar16,auStack_c8);
        piVar15 = &iStack_74;
        uVar23 = 0xbf769e;
        FUN_00562fc0(piVar15,uVar22,auStack_c8,-(uint)(pbVar16 != (byte *)0x0) & (uint)(pbVar16 + 1)
                    );
        FUN_005507b0();
        if (iStack_74 == 0) {
          uVar24 = 0x43;
          pcVar19 = "Internal error: GetFriendsOnline response \'VisitorId\' field missing";
LAB_00bf7f6d:
          uVar25 = 0;
          uVar26 = 0xf;
          uVar20 = 0;
          FUN_005542c0(pcVar19,uVar24);
          FUN_005e65e0(uVar20,uVar23,piVar15,uVar22,uVar25,uVar26);
LAB_00bf7f8b:
          piVar15 = piStack_38;
          if (piStack_38 != (int *)0x0) {
            LOCK();
            iVar17 = piStack_38[1] + -1;
            piStack_38[1] = iVar17;
            UNLOCK();
            if (iVar17 == 0) {
              (**(code **)*piStack_38)();
              LOCK();
              piVar1 = piVar15 + 2;
              iVar17 = *piVar1 + -1;
              *piVar1 = iVar17;
              UNLOCK();
              if (iVar17 == 0) {
                (**(code **)(*piVar15 + 4))();
              }
            }
          }
          if (pppppiVar18 != (int *****)0x0) {
            LOCK();
            ppppiVar2 = (int ****)((int)pppppiVar18[1] + -1);
            pppppiVar18[1] = ppppiVar2;
            UNLOCK();
            if (ppppiVar2 == (int ****)0x0) {
              (*(code *)**pppppiVar18)();
              LOCK();
              ppppiVar2 = (int ****)((int)pppppiVar18[2] + -1);
              pppppiVar18[2] = ppppiVar2;
              UNLOCK();
              if (ppppiVar2 == (int ****)0x0) {
                (*(code *)(*pppppiVar18)[1])();
              }
            }
          }
          goto LAB_00bf8006;
        }
        uStack_18 = 0;
        iVar17 = iStack_74 + 0x20;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        FUN_005542c0("VisitorId",9);
        uStack_8._0_1_ = 9;
        FUN_005c4c00(auStack_28);
        FUN_0056ee80(iVar17);
        uStack_8._0_1_ = 8;
        FUN_005507b0();
        uStack_18 = 0;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        FUN_005542c0(&DAT_018c387c,4);
        uVar22 = 0xbf7730;
        FUN_00580040(&iStack_78,auStack_28);
        FUN_005507b0();
        if (iStack_78 == 0) {
          uVar24 = 0x42;
          pcVar19 = "Internal error: GetFriendsOnline response \'UserName\' field missing";
          goto LAB_00bf7f6d;
        }
        uStack_18 = 0;
        iVar17 = iStack_78 + 0x20;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        FUN_005542c0("UserName",8);
        uStack_8._0_1_ = 10;
        FUN_005c4c00(auStack_28);
        FUN_0056ee80(iVar17);
        uStack_8._0_1_ = 8;
        FUN_005507b0();
        uStack_18 = 0;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        FUN_005542c0("userPresence",0xc);
        uVar22 = 0xbf77bc;
        FUN_00580040(&iStack_7c,auStack_28);
        FUN_005507b0();
        if (iStack_7c == 0) {
          uVar24 = 0x42;
          pcVar19 = "PresenceData does not exist for returned entry in GetFriendsOnline";
          goto LAB_00bf7f6d;
        }
        iVar17 = *(int *)(iStack_7c + 0x20);
        iVar13 = FUN_008881d0();
        if (iVar17 != iVar13) {
          uVar24 = 0x49;
          pcVar19 = "PresenceData is not of the expected type \'ValueTable\' in GetFriendsOnline";
          goto LAB_00bf7f6d;
        }
        uVar22 = FUN_0055d640();
        FUN_00557fc0(uVar22);
        uStack_8._0_1_ = 0xb;
        uStack_18 = 0;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        FUN_005542c0("lastOnline",10);
        uVar22 = 0xbf782f;
        FUN_00580040(&iStack_80,auStack_28);
        FUN_005507b0();
        if (iStack_80 == 0) {
          uVar24 = 0x44;
          pcVar19 = "Internal error: GetFriendsOnline response \'LastOnline\' field missing";
LAB_00bf7f09:
          uVar25 = 0;
          uVar26 = 0xf;
          uVar20 = 0;
          FUN_005542c0(pcVar19,uVar24);
          FUN_005e65e0(uVar20,uVar23,piVar15,uVar22,uVar25,uVar26);
          FUN_00550b30();
          pppppiVar18 = (int *****)ppppiStack_2c;
          goto LAB_00bf7f8b;
        }
        uStack_18 = 0;
        iVar17 = iStack_80 + 0x20;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        FUN_005542c0("LastOnline",10);
        uStack_8._0_1_ = 0xc;
        FUN_005c4c00(auStack_28);
        FUN_0056ee80(iVar17);
        uStack_8._0_1_ = 0xb;
        FUN_005507b0();
        uStack_18 = 0;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        FUN_005542c0("lastLocation",0xc);
        uVar22 = 0xbf78bd;
        FUN_00580040(&iStack_84,auStack_28);
        FUN_005507b0();
        if (iStack_84 == 0) {
          uVar24 = 0x46;
          pcVar19 = "Internal error: GetFriendsOnline response \'LastLocation\' field missing";
          goto LAB_00bf7f09;
        }
        uStack_18 = 0;
        iVar17 = iStack_84 + 0x20;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        FUN_005542c0("LastLocation",0xc);
        uStack_8._0_1_ = 0xd;
        FUN_005c4c00(auStack_28);
        FUN_0056ee80(iVar17);
        uStack_8._0_1_ = 0xb;
        FUN_005507b0();
        uStack_18 = 0;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        FUN_005542c0("placeId",7);
        uVar22 = 0xbf794b;
        FUN_00580040(&iStack_88,auStack_28);
        FUN_005507b0();
        if (iStack_88 == 0) {
          uVar24 = 0x41;
          pcVar19 = "Internal error: GetFriendsOnline response \'PlaceId\' field missing";
          goto LAB_00bf7f09;
        }
        uStack_18 = 0;
        iVar17 = iStack_88 + 0x20;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        FUN_005542c0("PlaceId",7);
        uStack_8._0_1_ = 0xe;
        FUN_005c4c00(auStack_28);
        FUN_0056ee80(iVar17);
        uStack_8._0_1_ = 0xb;
        FUN_005507b0();
        uStack_18 = 0;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        if (DAT_01d68034 == '\0') {
          FUN_005542c0("universeId",10);
          uVar22 = 0xbf7a43;
          FUN_00580040(&iStack_90,auStack_28);
          FUN_005507b0();
          iVar17 = iStack_90;
          if (iStack_90 == 0) goto LAB_00bf7e6f;
          uStack_18 = 0;
          uStack_14 = 0xf;
          auStack_28[0] = 0;
          FUN_005542c0("GameId",6);
          uStack_8._0_1_ = 0x10;
        }
        else {
          FUN_005542c0("gameInstanceId",0xe);
          uVar22 = 0xbf79e5;
          FUN_00580040(&iStack_8c,auStack_28);
          FUN_005507b0();
          iVar17 = iStack_8c;
          if (iStack_8c == 0) {
LAB_00bf7e6f:
            uVar24 = 0x40;
            pcVar19 = "Internal error: GetFriendsOnline response \'GameId\' field missing";
            goto LAB_00bf7f09;
          }
          uStack_18 = 0;
          uStack_14 = 0xf;
          auStack_28[0] = 0;
          FUN_005542c0("GameId",6);
          uStack_8._0_1_ = 0xf;
        }
        iVar17 = iVar17 + 0x20;
        FUN_005c4c00(auStack_28);
        FUN_0056ee80(iVar17);
        uStack_8._0_1_ = 0xb;
        FUN_005507b0();
        if (DAT_01d6803c != '\0') {
          uStack_18 = 0;
          uStack_14 = 0xf;
          auStack_28[0] = 0;
          FUN_005542c0("displayName",0xb);
          uVar22 = 0xbf7ae2;
          FUN_00580040(&iStack_94,auStack_28);
          FUN_005507b0();
          if (iStack_94 == 0) {
            uVar24 = 0x45;
            pcVar19 = "Internal error: GetFriendsOnline response \'DisplayName\' field missing";
            goto LAB_00bf7f09;
          }
          uStack_18 = 0;
          iVar17 = iStack_94 + 0x20;
          uStack_14 = 0xf;
          auStack_28[0] = 0;
          FUN_005542c0("DisplayName",0xb);
          uStack_8._0_1_ = 0x11;
          FUN_005c4c00(auStack_28);
          FUN_0056ee80(iVar17);
          uStack_8._0_1_ = 0xb;
          FUN_005507b0();
        }
        uStack_18 = 0;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        FUN_005542c0("UserLocationType",0x10);
        uVar22 = 0xbf7b73;
        FUN_00580040(&iStack_98,auStack_28);
        FUN_005507b0();
        if (iStack_98 == 0) {
          uVar24 = 0x4a;
          pcVar19 = "Internal error: GetFriendsOnline response \'LastLocationType\' field missing";
          goto LAB_00bf7f09;
        }
        uVar22 = FUN_0055d610();
        FUN_0054ef60(uVar22);
        uVar5 = uStack_4c;
        uVar22 = uStack_50;
        pppppiVar18 = apppppiStack_60[0];
        ppppppiVar14 = apppppiStack_60;
        if (0xf < uStack_4c) {
          ppppppiVar14 = (int ******)apppppiStack_60[0];
        }
        uStack_8._0_1_ = 0x12;
        uVar23 = 0xbf7bbe;
        cVar8 = FUN_0055c360(ppppppiVar14,uStack_50,"MobileWebsite",0xd);
        if (cVar8 != '\0') {
          uVar22 = 0;
          goto LAB_00bf7cd5;
        }
        ppppppiVar14 = apppppiStack_60;
        if (0xf < uVar5) {
          ppppppiVar14 = (int ******)pppppiVar18;
        }
        uVar23 = 0xbf7be3;
        cVar8 = FUN_0055c360(ppppppiVar14,uVar22,&DAT_018cd594,3);
        if (cVar8 == '\0') {
          ppppppiVar14 = apppppiStack_60;
          if (0xf < uVar5) {
            ppppppiVar14 = (int ******)pppppiVar18;
          }
          uVar23 = 0xbf7c05;
          cVar8 = FUN_0055c360(ppppppiVar14,uVar22,"Android",7);
          if (cVar8 != '\0') goto LAB_00bf7cd0;
          ppppppiVar14 = apppppiStack_60;
          if (0xf < uVar5) {
            ppppppiVar14 = (int ******)pppppiVar18;
          }
          uVar23 = 0xbf7c27;
          cVar8 = FUN_0055c360(ppppppiVar14,uVar22,&DAT_0195ff44,4);
          if (cVar8 != '\0') {
            uVar22 = 2;
            goto LAB_00bf7cd5;
          }
          ppppppiVar14 = apppppiStack_60;
          if (0xf < uVar5) {
            ppppppiVar14 = (int ******)pppppiVar18;
          }
          uVar23 = 0xbf7c4f;
          cVar8 = FUN_0055c360(ppppppiVar14,uVar22,"Studio",6);
          if (cVar8 != '\0') {
            uVar22 = 3;
            goto LAB_00bf7cd5;
          }
          ppppppiVar14 = apppppiStack_60;
          if (0xf < uVar5) {
            ppppppiVar14 = (int ******)pppppiVar18;
          }
          uVar23 = 0xbf7c74;
          cVar8 = FUN_0055c360(ppppppiVar14,uVar22,&DAT_018c5f98,4);
          if (cVar8 != '\0') {
            uVar22 = 4;
            goto LAB_00bf7cd5;
          }
          ppppppiVar14 = apppppiStack_60;
          if (0xf < uVar5) {
            ppppppiVar14 = (int ******)pppppiVar18;
          }
          uVar23 = 0xbf7c99;
          cVar8 = FUN_0055c360(ppppppiVar14,uVar22,&DAT_018c8cf0,4);
          if (cVar8 != '\0') {
            uVar22 = 5;
            goto LAB_00bf7cd5;
          }
          ppppppiVar14 = apppppiStack_60;
          if (0xf < uVar5) {
            ppppppiVar14 = (int ******)pppppiVar18;
          }
          uVar23 = 0xbf7cbe;
          cVar8 = FUN_0055c360(ppppppiVar14,uVar22,&DAT_018c5f8c,9);
          if (cVar8 != '\0') {
            uVar22 = 6;
            goto LAB_00bf7cd5;
          }
          uVar24 = 0;
          uVar25 = 0xf;
          uVar20 = 0;
          FUN_005542c0("Internal error: GetFriendsOnline response \'LastLocationType\' does not match any known type"
                       ,0x5a);
          FUN_005e65e0(uVar20,uVar23,ppppppiVar14,uVar22,uVar24,uVar25);
          FUN_005507b0();
          FUN_00550b30();
          pppppiVar18 = (int *****)ppppiStack_2c;
          goto LAB_00bf7f8b;
        }
LAB_00bf7cd0:
        uVar22 = 1;
LAB_00bf7cd5:
        uStack_18 = 0;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        FUN_005542c0("LocationType",0xc);
        uVar24 = uStack_3c;
        uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
        iVar17 = FUN_005c4c00(auStack_28);
        uVar25 = FUN_0088c8c0();
        *(undefined4 *)(iVar17 + 0x18) = uVar25;
        if ((*(int *)(*piStack_9c + 0x34) < DAT_01ea8c18) &&
           (FUN_016f3809(&DAT_01ea8c18), DAT_01ea8c18 == -1)) {
          DAT_01ea8c0c = FUN_005c65e0;
          DAT_01ea8c10 = FUN_005c65e0;
          DAT_01ea8c14 = _guard_check_icall;
          FUN_016f37bf(&DAT_01ea8c18);
        }
        puVar12 = *(undefined4 **)(iVar17 + 0x1c);
        if ((code **)puVar12 == &DAT_01ea8c0c) {
          *(undefined4 *)(iVar17 + 0x20) = uVar22;
        }
        else {
          if (puVar12 != (undefined4 *)0x0) {
            (*(code *)puVar12[2])(iVar17 + 0x20);
          }
          *(undefined4 *)(iVar17 + 0x20) = uVar22;
          *(code ***)(iVar17 + 0x1c) = &DAT_01ea8c0c;
        }
        uStack_8._0_1_ = 0x12;
        FUN_005507b0();
        param_3 = (byte *)CONCAT13(1,param_3._0_3_);
        uStack_d8 = 0;
        uStack_d4 = 0xf;
        auStack_e8[0] = 0;
        FUN_005542c0("IsOnline",8);
        iVar17 = (int)&param_3 + 3;
        uStack_8._0_1_ = 0x14;
        uVar22 = 0xbf7da9;
        FUN_005c4c00(auStack_e8);
        FUN_005e52b0(iVar17);
        uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
        FUN_005507b0();
        iVar17 = iStack_68;
        puVar12 = *(undefined4 **)(iStack_68 + 4);
        if (*(undefined4 **)(iStack_68 + 8) == puVar12) {
          uVar22 = 0xbf7e0d;
          FUN_00beac80(puVar12,&uStack_3c);
        }
        else {
          uVar25 = FUN_008881d0();
          *puVar12 = uVar25;
          puVar12[1] = 0;
          puVar12[2] = uVar24;
          puVar12[3] = piStack_38;
          uStack_3c = 0;
          piStack_38 = (int *)0x0;
          uVar24 = FUN_005ea820();
          puVar12[1] = uVar24;
          *(int *)(iVar17 + 4) = *(int *)(iVar17 + 4) + 0xd0;
        }
        FUN_005507b0();
        FUN_00550b30();
        FUN_00550b30();
        uStack_8._0_1_ = 6;
        FUN_00550b30();
        uStack_30 = uStack_30 + 1;
        iStack_34 = iStack_34 + 0xd0;
        iVar17 = piStack_44[1];
        iVar13 = *piStack_44;
        piVar15 = piStack_44;
      } while (uStack_30 < (uint)((iVar17 - iVar13) / 0xd0));
    }
    if (piStack_64 != (int *)0x0) {
      LOCK();
      piStack_64[1] = piStack_64[1] + 1;
      UNLOCK();
    }
    FUN_00bf84e0(param_1,param_2,iStack_68,piStack_64);
    if (piStack_64 != (int *)0x0) {
      LOCK();
      iVar17 = piStack_64[1] + -1;
      piStack_64[1] = iVar17;
      UNLOCK();
      if (iVar17 == 0) {
        (**(code **)*piStack_64)();
        LOCK();
        iVar17 = piStack_64[2] + -1;
        piStack_64[2] = iVar17;
        UNLOCK();
        if (iVar17 == 0) {
          (**(code **)(*piStack_64 + 4))();
        }
      }
    }
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar17 = piStack_40[1] + -1;
      piStack_40[1] = iVar17;
      UNLOCK();
      if (iVar17 == 0) {
        (**(code **)*piStack_40)();
        LOCK();
        iVar17 = piStack_40[2] + -1;
        piStack_40[2] = iVar17;
        UNLOCK();
        if (iVar17 == 0) {
          (**(code **)(*piStack_40 + 4))();
        }
      }
    }
    pppiVar6 = pppiStack_48;
    if ((int ****)pppiStack_48 != (int ****)0x0) {
      LOCK();
      pppiVar4 = (int ***)((int)pppiStack_48[1] + -1);
      pppiStack_48[1] = (int **)pppiVar4;
      UNLOCK();
      if (pppiVar4 == (int ***)0x0) {
        (*(code *)**pppiStack_48)();
        LOCK();
        ppppiVar2 = (int ****)(pppiVar6 + 2);
        pppiVar4 = (int ***)((int)*ppppiVar2 + -1);
        *ppppiVar2 = pppiVar4;
        UNLOCK();
        if (pppiVar4 == (int ***)0x0) {
          (*(code *)(*pppiVar6)[1])();
        }
      }
    }
    piVar15 = piStack_6c;
    if (piStack_6c == (int *)0x0) goto LAB_00bf81a9;
    LOCK();
    iVar17 = piStack_6c[1] + -1;
    piStack_6c[1] = iVar17;
    UNLOCK();
    if (iVar17 != 0) goto LAB_00bf81a9;
    (**(code **)*piStack_6c)();
    LOCK();
    piVar1 = piVar15 + 2;
    iVar17 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
  }
  if (iVar17 == 1) {
    (**(code **)(*piVar15 + 4))();
  }
LAB_00bf81a9:
  FUN_005507b0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
  if (in_stack_00000028 != 0) {
    if (((in_stack_00000028 & 1) == 0) &&
       (*(code **)(in_stack_00000028 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000028 & 0xfffffffe))(&stack0x00000030,&stack0x00000030,2);
    }
    in_stack_00000028 = 0;
  }
  uStack_8 = 0x16;
  if (((in_stack_00000048 != 0) && ((in_stack_00000048 & 1) == 0)) &&
     (*(code **)(in_stack_00000048 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000048 & 0xfffffffe))(&stack0x00000050,&stack0x00000050,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26894 ; VA 0x00bf8270 ; FUN_00bf8270 */

void __thiscall FUN_00bf8270(int param_1,undefined4 param_2,undefined4 param_3,uint *param_4)

{
  uint **ppuVar1;
  undefined uVar2;
  int iVar3;
  uint *puVar4;
  uint uVar5;
  uint uVar6;
  uint in_stack_0000001c;
  uint in_stack_00000020;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint *puStack_2c;
  uint *puStack_28;
  undefined4 uStack_24;
  int iStack_20;
  uint *puStack_1c;
  uint uStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01803bc8;
  pvStack_10 = ExceptionList;
  iStack_20 = param_1 + 0x8c;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_016dee6d();
  if (iVar3 != 0) {
    FUN_016df3c9();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar3 = FUN_00beebc0();
  *(undefined *)(iVar3 + 8) = 0;
  iVar3 = FUN_00beebc0();
  if ((uint **)(iVar3 + 0x14) != &param_4) {
    puVar4 = (uint *)&param_4;
    if (0xf < in_stack_00000020) {
      puVar4 = param_4;
    }
    FUN_005542c0(puVar4,in_stack_0000001c);
  }
  puStack_2c = (uint *)0x0;
  puStack_28 = (uint *)0x0;
  uStack_24 = 0;
  uStack_8._0_1_ = 2;
  iVar3 = FUN_00beebc0();
  ppuVar1 = (uint **)(iVar3 + 0x38);
  if (&puStack_2c != ppuVar1) {
    puStack_2c = *ppuVar1;
    *ppuVar1 = (uint *)0x0;
    puStack_28 = *(uint **)(iVar3 + 0x3c);
    *(undefined4 *)(iVar3 + 0x3c) = 0;
    uStack_24 = *(undefined4 *)(iVar3 + 0x40);
    *(undefined4 *)(iVar3 + 0x40) = 0;
    puStack_1c = puStack_28;
    if (puStack_2c != puStack_28) {
      param_3 = puStack_2c + 8;
      uVar2 = (undefined)uStack_8;
      do {
        uStack_8._0_1_ = uVar2;
        uVar6 = in_stack_0000001c;
        puStack_14 = (uint *)&param_4;
        if (0xf < in_stack_00000020) {
          puStack_14 = param_4;
        }
        if (in_stack_0000001c < 0x10) {
          uVar5 = *puStack_14;
          uStack_4c = puStack_14[1];
          uStack_48 = puStack_14[2];
          uStack_44 = puStack_14[3];
        }
        else {
          uStack_18 = in_stack_0000001c | 0xf;
          if (0x7fffffff < uStack_18) {
            uStack_18 = 0x7fffffff;
          }
          if (uStack_18 + 1 < 0x1000) {
            if (uStack_18 == 0xffffffff) {
              uVar5 = 0;
            }
            else {
              uVar5 = FUN_01674e20();
            }
          }
          else {
            iVar3 = FUN_01674e20();
            if (iVar3 == 0) goto LAB_00bf84c5;
            uVar5 = iVar3 + 0x23U & 0xffffffe0;
            *(int *)(uVar5 - 4) = iVar3;
          }
          FUN_0170c6f0(uVar5,puStack_14,uVar6 + 1);
        }
        uStack_8._0_1_ = 3;
        if (*param_3 == 0) {
          FUN_0054fda0();
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
          FUN_0054e5e0();
        }
        (**(code **)((*param_3 & 0xfffffffe) + 4))(param_3 + 2,uVar5,uStack_4c,uStack_48,uStack_44);
        uStack_8._0_1_ = 2;
        uVar2 = (undefined)uStack_8;
        uStack_8._0_1_ = 2;
        puVar4 = param_3 + 8;
        param_3 = param_3 + 0x10;
      } while (puVar4 != puStack_1c);
    }
  }
  FUN_00a59a30();
  uStack_8._0_1_ = 5;
  iVar3 = FUN_016deec8();
  if (iVar3 != 0) {
    FUN_016df3c9();
  }
  if (0xf < in_stack_00000020) {
    uVar6 = in_stack_00000020 + 1;
    puVar4 = param_4;
    if (0xfff < uVar6) {
      puVar4 = (uint *)param_4[-1];
      uVar6 = in_stack_00000020 + 0x24;
      if (0x1f < (uint)((int)param_4 + (-4 - (int)puVar4))) {
LAB_00bf84c5:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar4,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26895 ; VA 0x00bf84e0 ; FUN_00bf84e0 */

int __thiscall
FUN_00bf84e0(int param_1,undefined4 param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined uVar4;
  int iVar5;
  undefined4 uVar6;
  uint **ppuVar7;
  uint *puVar8;
  uint *puVar9;
  uint *puStack_24;
  uint *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01803c08;
  pvStack_10 = ExceptionList;
  puVar8 = (uint *)0x0;
  puStack_24 = (uint *)0x0;
  puStack_20 = (uint *)0x0;
  uStack_1c = 0;
  param_1 = param_1 + 0xd4;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  piStack_14 = (int *)param_1;
  iVar5 = FUN_016dee6d(param_1);
  if (iVar5 != 0) {
    FUN_016df3c9(iVar5);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  iVar5 = FUN_00beebc0(&param_2);
  *(undefined *)(iVar5 + 8) = 1;
  param_3 = iVar5 + 8;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar5 + 0xc) = param_4;
  piVar3 = *(int **)(iVar5 + 0x10);
  *(int **)(iVar5 + 0x10) = param_5;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[1] + -1;
    piVar3[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar5 = piVar3[2] + -1;
      piVar3[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ppuVar7 = (uint **)(param_3 + 0x30);
  puVar9 = (uint *)0x0;
  if (&puStack_24 != ppuVar7) {
    puVar9 = *ppuVar7;
    *ppuVar7 = (uint *)0x0;
    puVar8 = *(uint **)(param_3 + 0x34);
    *(undefined4 *)(param_3 + 0x34) = 0;
    uStack_1c = *(undefined4 *)(param_3 + 0x38);
    *(undefined4 *)(param_3 + 0x38) = 0;
    puStack_24 = puVar9;
    puStack_20 = puVar8;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  iVar5 = FUN_016deec8(param_1);
  if (iVar5 != 0) {
    FUN_016df3c9(iVar5);
  }
  while( true ) {
    if (puVar9 == puVar8) {
      uStack_8._0_1_ = 1;
      iVar5 = FUN_00a59a30();
      piVar3 = param_5;
      if (param_5 != (int *)0x0) {
        LOCK();
        piVar1 = param_5 + 1;
        iVar2 = *piVar1;
        iVar5 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar5 = (**(code **)*param_5)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            iVar5 = (**(code **)(*piVar3 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return iVar5;
    }
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 4;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 4;
    if (*puVar9 == 0) break;
    uStack_18 = 0;
    piStack_14 = (int *)0x0;
    (**(code **)((*puVar9 & 0xfffffffe) + 4))(puVar9 + 2,param_4,param_5);
    puVar9 = puVar9 + 0x10;
  }
  uStack_18 = param_4;
  piStack_14 = param_5;
  uStack_8._0_1_ = uVar4;
  uVar6 = FUN_0054fda0();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar6);
}



/* FUNCTION 26896 ; VA 0x00bf86a0 ; FUN_00bf86a0 */

int __thiscall
FUN_00bf86a0(int param_1,undefined4 param_2,uint *param_3,undefined4 param_4,int *param_5)

{
  uint **ppuVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  uint *puVar7;
  uint *puStack_2c;
  uint *puStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01803c48;
  pvStack_10 = ExceptionList;
  iVar5 = param_1 + 0x8c;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_18 = iVar5;
  iVar4 = FUN_016dee6d(iVar5);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  iStack_14 = param_1 + 0x74;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar4 = FUN_00beebc0(&param_2);
  *(undefined *)(iVar4 + 8) = 1;
  iVar4 = FUN_00beebc0(&param_2);
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar4 + 0xc) = param_4;
  piVar3 = *(int **)(iVar4 + 0x10);
  *(int **)(iVar4 + 0x10) = param_5;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  puStack_2c = (uint *)0x0;
  puStack_28 = (uint *)0x0;
  uStack_24 = 0;
  uStack_8._0_1_ = 2;
  iVar4 = FUN_00beebc0(&param_2);
  puVar7 = (uint *)0x0;
  param_3 = (uint *)0x0;
  ppuVar1 = (uint **)(iVar4 + 0x38);
  if (&puStack_2c != ppuVar1) {
    puVar7 = *ppuVar1;
    *ppuVar1 = (uint *)0x0;
    param_3 = *(uint **)(iVar4 + 0x3c);
    *(undefined4 *)(iVar4 + 0x3c) = 0;
    uStack_24 = *(undefined4 *)(iVar4 + 0x40);
    *(undefined4 *)(iVar4 + 0x40) = 0;
    puStack_2c = puVar7;
    puStack_28 = param_3;
  }
  if (puVar7 != param_3) {
    do {
      if (param_5 != (int *)0x0) {
        LOCK();
        param_5[1] = param_5[1] + 1;
        UNLOCK();
      }
      uStack_20 = param_4;
      piStack_1c = param_5;
      uStack_8._0_1_ = 3;
      if (*puVar7 == 0) {
        uVar6 = FUN_0054fda0();
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
        FUN_0054e5e0(uVar6);
      }
      uStack_20 = 0;
      piStack_1c = (int *)0x0;
      (**(code **)((*puVar7 & 0xfffffffe) + 4))(puVar7 + 2,param_4,param_5);
      puVar7 = puVar7 + 0x10;
    } while (puVar7 != param_3);
  }
  FUN_00a59a30();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  iVar5 = FUN_016deec8(iVar5);
  if (iVar5 != 0) {
    iVar5 = FUN_016df3c9(iVar5);
  }
  piVar3 = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar2 = param_5 + 1;
    iVar4 = *piVar2;
    iVar5 = *piVar2;
    *piVar2 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar5 = (**(code **)*param_5)();
      LOCK();
      piVar2 = piVar3 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar5 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 26897 ; VA 0x00bf8880 ; FUN_00bf8880 */

void FUN_00bf8880(uint param_1)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  byte *pbVar8;
  int in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_0000003c;
  char *pcVar9;
  undefined uVar10;
  undefined4 in_stack_ffffffa8;
  undefined4 in_stack_ffffffac;
  int *piVar11;
  undefined4 in_stack_ffffffb0;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined auStack_3c [16];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined auStack_24 [8];
  byte *pbStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01803c88;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  if (in_stack_00000014 == 0) {
    uVar12 = 0;
    uVar13 = 0xf;
    uVar10 = 0;
    ExceptionList = &pvStack_10;
    FUN_005542c0("Empty response received from web server",0x27);
    FUN_005e65e0(uVar10,in_stack_ffffffa8,in_stack_ffffffac,in_stack_ffffffb0,uVar12,uVar13);
  }
  else {
    pbStack_1c = (byte *)0x0;
    piStack_18 = (int *)0x0;
    uStack_8._0_1_ = 3;
    uStack_8._1_3_ = 0;
    puVar4 = &param_1;
    piVar11 = (int *)0xbf88fa;
    ExceptionList = &pvStack_10;
    cVar3 = FUN_0098f070(puVar4,&pbStack_1c,0);
    pbVar8 = pbStack_1c;
    if (cVar3 == '\0') {
      uVar12 = 0x23;
      pcVar9 = "Friends response was not valid JSON";
    }
    else {
      uStack_2c = 0;
      uStack_28 = 0xf;
      auStack_3c[0] = 0;
      FUN_005542c0(&DAT_018be4a0,4);
      pbVar8 = pbVar8 + *pbVar8 + 1;
      puVar4 = (undefined4 *)FUN_0055c740(pbVar8,auStack_3c);
      piVar11 = &iStack_14;
      in_stack_ffffffa8 = 0xbf8965;
      FUN_00562fc0(piVar11,puVar4,auStack_3c,-(uint)(pbVar8 != (byte *)0x0) & (uint)(pbVar8 + 1));
      FUN_005507b0();
      if (iStack_14 != 0) {
        iVar2 = *(int *)(iStack_14 + 0x20);
        iVar5 = FUN_008882f0();
        if (iVar2 == iVar5) {
          uVar12 = FUN_0055d670();
          uVar13 = 0xbf8993;
          FUN_00557fc0(uVar12);
          uStack_8._0_1_ = 4;
          FUN_00557fc0(auStack_24);
          FUN_00bef900(uVar13,uVar12);
          FUN_00550b30();
          FUN_00550b30();
          goto LAB_00bf8a11;
        }
      }
      uVar12 = 0x1c;
      pcVar9 = "Failed to parse friends JSON";
    }
    uVar13 = 0;
    uVar14 = 0xf;
    uVar10 = 0;
    FUN_005542c0(pcVar9,uVar12);
    FUN_005e65e0(uVar10,in_stack_ffffffa8,piVar11,puVar4,uVar13,uVar14);
    piVar11 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[1] + -1;
      piStack_18[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar11 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar11 + 4))();
        }
      }
    }
  }
LAB_00bf8a11:
  uStack_8._0_1_ = 1;
  uVar10 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    uVar7 = in_stack_00000018 + 1;
    uVar6 = param_1;
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(param_1 - 4);
      uVar7 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - uVar6) - 4) {
        uStack_8._0_1_ = uVar10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = param_1 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (in_stack_0000001c != 0) {
    if (((in_stack_0000001c & 1) == 0) &&
       (*(code **)(in_stack_0000001c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000001c & 0xfffffffe))(&stack0x00000024,&stack0x00000024,2);
    }
    in_stack_0000001c = 0;
  }
  uStack_8 = 6;
  if (((in_stack_0000003c != 0) && ((in_stack_0000003c & 1) == 0)) &&
     (*(code **)(in_stack_0000003c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000003c & 0xfffffffe))(&stack0x00000044,&stack0x00000044,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26898 ; VA 0x00bf8ad0 ; FUN_00bf8ad0 */

void FUN_00bf8ad0(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  int in_stack_00000024;
  uint in_stack_00000038;
  undefined auStack_90 [24];
  undefined4 uStack_78;
  undefined4 *puStack_74;
  undefined *puStack_70;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined auStack_58 [24];
  undefined4 uStack_40;
  int *piStack_3c;
  undefined auStack_38 [24];
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01803cec;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  puStack_74 = (undefined4 *)0xbf8afd;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_008f7870();
  if (iVar1 != 0) {
    puStack_74 = &uStack_20;
    uStack_78 = 0xbf8b14;
    FUN_0068f9a0();
    puStack_18 = &uStack_60;
    uStack_8._0_1_ = 2;
    puStack_70 = (undefined *)0x1;
    puStack_14 = auStack_90;
    uStack_60 = param_1;
    uStack_5c = param_2;
    FUN_00bedad0();
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[2] = piStack_1c[2] + 1;
      UNLOCK();
    }
    uStack_40 = uStack_20;
    piStack_3c = piStack_1c;
    uStack_8._0_1_ = 4;
    FUN_0054ef60();
    uStack_8._0_1_ = 5;
    FUN_00bedad0(auStack_58);
    if (piStack_3c != (int *)0x0) {
      LOCK();
      piStack_3c[2] = piStack_3c[2] + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 7;
    FUN_0054ef60(auStack_38);
    uStack_8._0_1_ = 5;
    FUN_00be9a60();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00bee030();
    FUN_0090ca30();
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar1 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        puStack_70 = (undefined *)0xbf8c01;
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  puStack_70 = (undefined *)0xbf8c09;
  FUN_00612320();
  if (0xf < in_stack_00000038) {
    puStack_70 = (undefined *)(in_stack_00000038 + 1);
    iVar1 = in_stack_00000024;
    if (0xfff < puStack_70) {
      iVar1 = *(int *)(in_stack_00000024 + -4);
      puStack_70 = (undefined *)(in_stack_00000038 + 0x24);
      if (0x1f < (in_stack_00000024 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_70 = &UNK_00bf8c51;
        FUN_017167a3();
      }
    }
    uStack_78 = 0xbf8c36;
    puStack_74 = (undefined4 *)iVar1;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26899 ; VA 0x00bf8c60 ; FUN_00bf8c60 */

void __thiscall FUN_00bf8c60(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  uint in_stack_00000024;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined8 in_stack_0000003c;
  uint in_stack_00000044;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined8 in_stack_0000005c;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined8 uStack_c0;
  undefined auStack_b8 [64];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_5c;
  undefined4 *puStack_58;
  undefined4 *puStack_54;
  undefined4 uStack_50;
  uint uStack_4c;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 *puStack_38;
  undefined8 uStack_34;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01803d28;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_4c = 0;
  ExceptionList = &pvStack_10;
  if (in_stack_00000044 != 0) {
    uStack_4c = in_stack_00000044;
    if ((in_stack_00000044 & 1) == 0) {
      puStack_54 = &uStack_44;
      uStack_50 = 0;
      puStack_58 = &stack0x0000004c;
      uStack_5c = 0xbf8cd2;
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000044 & 0xfffffffe))();
    }
    else {
      uStack_44 = in_stack_0000004c;
      uStack_40 = in_stack_00000050;
      uStack_3c = in_stack_00000054;
      puStack_38 = (undefined4 *)in_stack_00000058;
      uStack_34 = in_stack_0000005c;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 3;
  uStack_70 = 0;
  if (in_stack_00000024 != 0) {
    if ((in_stack_00000024 & 1) == 0) {
      (**(code **)(in_stack_00000024 & 0xfffffffe))(&stack0x0000002c,&uStack_d0,0);
    }
    else {
      uStack_d0 = in_stack_0000002c;
      uStack_cc = in_stack_00000030;
      uStack_c8 = in_stack_00000034;
      uStack_c4 = in_stack_00000038;
      uStack_c0 = in_stack_0000003c;
    }
  }
  uStack_8._0_1_ = 4;
  FUN_00bedad0(&stack0x0000000c);
  uStack_8._0_1_ = 3;
  FUN_00beb930(auStack_b8,FUN_00bf8de0,0,param_1);
  uStack_c0 = CONCAT44(0xbf8d60,(undefined4)uStack_c0);
  FUN_00be9c80();
  uStack_70 = param_3;
  uStack_8._0_1_ = 2;
  uStack_74 = param_2;
  uStack_78 = 0xbf8d71;
  FUN_00bf2850();
  uStack_34 = CONCAT44(0xbf8d79,(undefined4)uStack_34);
  FUN_00612320();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (in_stack_00000024 != 0) {
    if (((in_stack_00000024 & 1) == 0) &&
       (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
      puStack_38 = &stack0x0000002c;
      uStack_34 = CONCAT44(2,puStack_38);
      uStack_3c = 0xbf8d9a;
      (**(code **)(in_stack_00000024 & 0xfffffffe))();
    }
    in_stack_00000024 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) &&
     (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
    puStack_38 = &stack0x0000004c;
    uStack_34 = CONCAT44(2,puStack_38);
    uStack_3c = 0xbf8dc8;
    (**(code **)(in_stack_00000044 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26900 ; VA 0x00bf8de0 ; FUN_00bf8de0 */

void FUN_00bf8de0(undefined4 param_1,int param_2,int param_3,undefined4 param_4,undefined4 param_5,
                 int param_6,undefined4 param_7,int *param_8,uint param_9)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  undefined4 *puVar6;
  int iStack_38;
  undefined4 uStack_34;
  int iStack_30;
  undefined auStack_28 [8];
  undefined4 uStack_20;
  int *piStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01803d60;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  FUN_00bec650(&uStack_20);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uVar4 = uStack_20;
  piVar1 = piStack_1c;
  if (param_3 == 0) {
    puVar6 = (undefined4 *)0x0;
  }
  else {
    puVar6 = *(undefined4 **)(param_6 + param_2 * 4);
  }
  for (; puVar6 != (undefined4 *)0x0; puVar6 = (undefined4 *)*puVar6) {
    iVar2 = puVar6[2];
    uVar3 = puVar6[3];
    if (param_8 != (int *)0x0) {
      LOCK();
      param_8[1] = param_8[1] + 1;
      UNLOCK();
    }
    piStack_1c = piVar1;
    cVar5 = FUN_00bf46c0(iVar2,uVar3,param_7,param_8);
    uVar4 = uStack_20;
    iStack_30 = (cVar5 != '\0') + 1;
    iStack_38 = iVar2;
    uStack_34 = uVar3;
    FUN_00bec1d0(auStack_28,&iStack_38,&iStack_38);
    piVar1 = piStack_1c;
  }
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar1[1] = piVar1[1] + 1;
    UNLOCK();
  }
  FUN_00bef9c0(uVar4,piVar1);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[1] + -1;
    piVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_00612320();
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  uStack_8 = 4;
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_9 & 0xfffffffe))(&stack0x0000002c,&stack0x0000002c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26901 ; VA 0x00bf8f50 ; FUN_00bf8f50 */

int __thiscall
FUN_00bf8f50(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01803d80;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_008f7870(param_1);
  if (iVar3 != 0) {
    FUN_0068f9a0(&uStack_1c,param_1);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    FUN_00be9860(param_2,param_3,param_4,param_5,uStack_1c,piStack_18,0);
    iVar3 = FUN_0090ca30();
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 26902 ; VA 0x00bf9060 ; FUN_00bf9060 */

void FUN_00bf9060(uint param_1)

{
  char cVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  undefined4 ***pppuVar5;
  undefined *puVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  int *piVar10;
  byte *pbVar11;
  byte *pbVar12;
  undefined8 uVar13;
  int in_stack_00000014;
  uint in_stack_00000018;
  int in_stack_00000020;
  int in_stack_00000024;
  int in_stack_00000030;
  uint in_stack_00000034;
  uint in_stack_00000054;
  char *pcVar14;
  undefined uVar15;
  undefined4 in_stack_fffffef4;
  undefined4 in_stack_fffffef8;
  int **ppiVar16;
  undefined4 in_stack_fffffefc;
  undefined4 uVar17;
  undefined4 uVar18;
  undefined8 *puVar19;
  undefined4 uVar20;
  undefined auStack_ec [8];
  undefined auStack_e4 [8];
  undefined auStack_dc [8];
  undefined auStack_d4 [8];
  byte *pbStack_cc;
  int *piStack_c8;
  undefined auStack_c4 [16];
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined auStack_ac [16];
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined8 uStack_94;
  undefined4 uStack_8c;
  undefined8 uStack_84;
  undefined4 uStack_7c;
  undefined8 uStack_74;
  undefined4 uStack_6c;
  int *piStack_64;
  int *piStack_60;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  undefined8 uStack_50;
  undefined4 uStack_48;
  byte *pbStack_40;
  int *piStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  undefined4 **appuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01803ddb;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  if (in_stack_00000014 == 0) {
    uVar17 = 0;
    uVar18 = 0xf;
    uVar15 = 0;
    ExceptionList = &pvStack_10;
    FUN_005542c0("Empty response received from web server",0x27);
    FUN_005e65e0(uVar15,in_stack_fffffef4,in_stack_fffffef8,in_stack_fffffefc,uVar17,uVar18);
    uStack_94 = CONCAT44(uStack_94._4_4_,(undefined4)uStack_94);
    uStack_84 = CONCAT44(uStack_84._4_4_,(undefined4)uStack_84);
    uStack_74 = CONCAT44(uStack_74._4_4_,(undefined4)uStack_74);
    uStack_50 = CONCAT44(uStack_50._4_4_,(undefined4)uStack_50);
    goto LAB_00bf95ac;
  }
  pbStack_40 = (byte *)0x0;
  piStack_3c = (int *)0x0;
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  puVar2 = &param_1;
  ppiVar16 = (int **)0xbf90de;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_0098f070(puVar2,&pbStack_40,0);
  pbVar11 = pbStack_40;
  if (cVar1 == '\0') {
    uVar17 = 0x2f;
    pcVar14 = "Friendship statuses response was not valid JSON";
LAB_00bf9566:
    uVar18 = 0;
    uVar20 = 0xf;
    uVar15 = 0;
    FUN_005542c0(pcVar14,uVar17);
    FUN_005e65e0(uVar15,in_stack_fffffef4,ppiVar16,puVar2,uVar18,uVar20);
    piVar10 = piStack_3c;
    uStack_94 = CONCAT44(uStack_94._4_4_,(undefined4)uStack_94);
    uStack_84 = CONCAT44(uStack_84._4_4_,(undefined4)uStack_84);
    uStack_74 = CONCAT44(uStack_74._4_4_,(undefined4)uStack_74);
    uStack_50 = CONCAT44(uStack_50._4_4_,(undefined4)uStack_50);
    if (piStack_3c == (int *)0x0) goto LAB_00bf95ac;
    LOCK();
    iVar7 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar7;
    UNLOCK();
    uStack_94 = CONCAT44(uStack_94._4_4_,(undefined4)uStack_94);
    uStack_84 = CONCAT44(uStack_84._4_4_,(undefined4)uStack_84);
    uStack_74 = CONCAT44(uStack_74._4_4_,(undefined4)uStack_74);
    uStack_50 = CONCAT44(uStack_50._4_4_,(undefined4)uStack_50);
    if (iVar7 != 0) goto LAB_00bf95ac;
    (**(code **)*piStack_3c)();
    LOCK();
    piVar4 = piVar10 + 2;
    iVar7 = *piVar4;
    *piVar4 = *piVar4 + -1;
    UNLOCK();
    if (iVar7 != 1) goto LAB_00bf95ac;
    iVar7 = *piVar10;
  }
  else {
    uStack_20 = 0;
    uStack_1c = 0xf;
    appuStack_30[0] = (undefined4 **)((uint)appuStack_30[0] & 0xffffff00);
    FUN_005542c0(&DAT_018be4a0,4);
    pbVar11 = pbVar11 + *pbVar11 + 1;
    puVar2 = (undefined4 *)FUN_0055c740(pbVar11,appuStack_30);
    ppiVar16 = &piStack_14;
    in_stack_fffffef4 = 0xbf9149;
    FUN_00562fc0(ppiVar16,puVar2,appuStack_30,-(uint)(pbVar11 != (byte *)0x0) & (uint)(pbVar11 + 1))
    ;
    FUN_005507b0();
    if ((piStack_14 == (int *)0x0) ||
       (iVar7 = piStack_14[8], iVar3 = FUN_008882f0(), iVar7 != iVar3)) {
      uVar17 = 0x29;
      pcVar14 = "Failed to parse friendship statuses array";
      goto LAB_00bf9566;
    }
    FUN_00bec650(&uStack_38);
    uStack_8._0_1_ = 5;
    uVar17 = FUN_0055d670();
    FUN_00557fc0(uVar17);
    uStack_8._0_1_ = 6;
    piStack_14 = (int *)*piStack_64;
    piStack_18 = (int *)piStack_64[1];
    if (piStack_14 != piStack_18) {
      do {
        iVar7 = *piStack_14;
        iVar3 = FUN_008881d0();
        piVar10 = piStack_14;
        if (iVar7 == iVar3) {
          iVar7 = *piStack_14;
          iVar3 = FUN_008881d0();
          if (iVar7 != iVar3) {
                    /* WARNING: Subroutine does not return */
            FUN_016757c0("Variant cast failed");
          }
          piVar4 = piVar10 + 2;
          if (piVar10[1] == 0) {
            piVar4 = (int *)0x0;
          }
          piVar10 = (int *)piVar4[1];
          if (piVar10 != (int *)0x0) {
            LOCK();
            piVar10[1] = piVar10[1] + 1;
            UNLOCK();
            piVar10 = (int *)piVar4[1];
          }
          pbVar11 = (byte *)*piVar4;
          uStack_8._0_1_ = 7;
          uStack_9c = 0;
          uStack_98 = 0xf;
          auStack_ac[0] = 0;
          pbStack_cc = pbVar11;
          piStack_c8 = piVar10;
          FUN_005542c0(&DAT_018c1fd8,2);
          pbVar12 = pbVar11 + *pbVar11 + 1;
          uVar17 = FUN_0055c740(pbVar12,auStack_ac);
          FUN_00562fc0(&iStack_54,uVar17,auStack_ac,
                       -(uint)(pbVar12 != (byte *)0x0) & (uint)(pbVar12 + 1));
          FUN_005507b0();
          uStack_b4 = 0;
          uStack_b0 = 0xf;
          auStack_c4[0] = 0;
          FUN_005542c0("status",6);
          pbVar11 = pbVar11 + *pbVar11 + 1;
          uVar17 = FUN_0055c740(pbVar11,auStack_c4);
          FUN_00562fc0(&iStack_58,uVar17,auStack_c4,
                       -(uint)(pbVar11 != (byte *)0x0) & (uint)(pbVar11 + 1));
          FUN_005507b0();
          if (((iStack_54 != 0) && (iStack_58 != 0)) &&
             (*(char *)(*(int *)(iStack_54 + 0x20) + 0x21) != '\0')) {
            iVar7 = *(int *)(iStack_58 + 0x20);
            iStack_5c = iStack_58 + 0x20;
            iVar3 = FUN_0088cb40();
            if (iVar7 == iVar3) {
              uVar13 = FUN_00563790();
              FUN_00563690(appuStack_30);
              pppuVar5 = appuStack_30;
              if (0xf < uStack_1c) {
                pppuVar5 = (undefined4 ***)appuStack_30[0];
              }
              uStack_8._0_1_ = 8;
              cVar1 = FUN_0055c360(pppuVar5,uStack_20,"Friends",7);
              if (cVar1 == '\0') {
                pppuVar5 = appuStack_30;
                if (0xf < uStack_1c) {
                  pppuVar5 = (undefined4 ***)appuStack_30[0];
                }
                cVar1 = FUN_0055c360(pppuVar5,uStack_20,"NotFriends",10);
                if (cVar1 != '\0') {
                  puVar19 = &uStack_84;
                  puVar6 = auStack_e4;
                  uStack_7c = 1;
                  uStack_84 = uVar13;
                  uVar13 = uStack_50;
                  goto LAB_00bf942d;
                }
                pppuVar5 = appuStack_30;
                if (0xf < uStack_1c) {
                  pppuVar5 = (undefined4 ***)appuStack_30[0];
                }
                cVar1 = FUN_0055c360(pppuVar5,uStack_20,"RequestSent",0xb);
                if (cVar1 != '\0') {
                  puVar19 = &uStack_94;
                  puVar6 = auStack_ec;
                  uStack_8c = 3;
                  uStack_94 = uVar13;
                  uVar13 = uStack_50;
                  goto LAB_00bf942d;
                }
                pppuVar5 = appuStack_30;
                if (0xf < uStack_1c) {
                  pppuVar5 = (undefined4 ***)appuStack_30[0];
                }
                cVar1 = FUN_0055c360(pppuVar5,uStack_20,"RequestReceived",0xf);
                if (cVar1 != '\0') {
                  puVar19 = &uStack_50;
                  puVar6 = auStack_d4;
                  uStack_48 = 4;
                  goto LAB_00bf942d;
                }
              }
              else {
                puVar19 = &uStack_74;
                puVar6 = auStack_dc;
                uStack_6c = 2;
                uStack_74 = uVar13;
                uVar13 = uStack_50;
LAB_00bf942d:
                uStack_50 = uVar13;
                FUN_00bec1d0(puVar6,puVar19,puVar19);
              }
              FUN_005507b0();
            }
          }
          uStack_8._0_1_ = 6;
          if (piVar10 != (int *)0x0) {
            LOCK();
            iVar7 = piVar10[1] + -1;
            piVar10[1] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)*piVar10)();
              LOCK();
              iVar7 = piVar10[2] + -1;
              piVar10[2] = iVar7;
              UNLOCK();
              if (iVar7 == 0) {
                (**(code **)(*piVar10 + 4))();
              }
            }
          }
        }
        piStack_14 = piStack_14 + 0x34;
      } while (piStack_14 != piStack_18);
    }
    piVar10 = piStack_34;
    if (in_stack_00000024 == 0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      puVar2 = *(undefined4 **)(in_stack_00000030 + in_stack_00000020 * 4);
    }
    for (; puVar2 != (undefined4 *)0x0; puVar2 = (undefined4 *)*puVar2) {
      uStack_50._0_4_ = puVar2[2];
      uStack_50._4_4_ = puVar2[3];
      uStack_48 = 0;
      piStack_34 = piVar10;
      FUN_00bec1d0(auStack_d4,&uStack_50,&uStack_50);
      piVar10 = piStack_34;
    }
    if (piVar10 != (int *)0x0) {
      LOCK();
      piVar10[1] = piVar10[1] + 1;
      UNLOCK();
    }
    FUN_00bef9c0(uStack_38,piVar10);
    if (piStack_60 != (int *)0x0) {
      LOCK();
      iVar7 = piStack_60[1] + -1;
      piStack_60[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_60)();
        LOCK();
        iVar7 = piStack_60[2] + -1;
        piStack_60[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piStack_60 + 4))();
        }
      }
    }
    if (piVar10 != (int *)0x0) {
      LOCK();
      iVar7 = piVar10[1] + -1;
      piVar10[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar10)();
        LOCK();
        iVar7 = piVar10[2] + -1;
        piVar10[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar10 + 4))();
        }
      }
    }
    piVar10 = piStack_3c;
    if (piStack_3c == (int *)0x0) goto LAB_00bf95ac;
    LOCK();
    iVar7 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar7;
    UNLOCK();
    if (iVar7 != 0) goto LAB_00bf95ac;
    (**(code **)*piStack_3c)();
    LOCK();
    piVar4 = piVar10 + 2;
    iVar7 = *piVar4;
    *piVar4 = *piVar4 + -1;
    UNLOCK();
    if (iVar7 != 1) goto LAB_00bf95ac;
    iVar7 = *piVar10;
  }
  (**(code **)(iVar7 + 4))();
LAB_00bf95ac:
  uStack_8._0_1_ = 2;
  uVar15 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < in_stack_00000018) {
    uVar9 = in_stack_00000018 + 1;
    uVar8 = param_1;
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(param_1 - 4);
      uVar9 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - uVar8) - 4) {
        uStack_8._0_1_ = uVar15;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = param_1 & 0xffffff00;
  FUN_00612320();
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  if (in_stack_00000034 != 0) {
    if (((in_stack_00000034 & 1) == 0) &&
       (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000034 & 0xfffffffe))(&stack0x0000003c,&stack0x0000003c,2);
    }
    in_stack_00000034 = 0;
  }
  uStack_8 = 10;
  if (((in_stack_00000054 != 0) && ((in_stack_00000054 & 1) == 0)) &&
     (*(code **)(in_stack_00000054 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000054 & 0xfffffffe))(&stack0x0000005c,&stack0x0000005c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26903 ; VA 0x00bf9680 ; FUN_00bf9680 */

void __thiscall
FUN_00bf9680(byte *param_1,byte *param_2,int *param_3,undefined4 param_4,undefined4 *param_5)

{
  int *piVar1;
  byte *pbVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  int *piVar9;
  uint uVar10;
  uint uVar11;
  byte *pbVar12;
  longlong lVar13;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  byte *pbStack_2c;
  int *piStack_28;
  byte *pbStack_24;
  byte *pbStack_20;
  byte *pbStack_1c;
  int iStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01803e17;
  pvStack_10 = ExceptionList;
  pbVar2 = param_1 + 0x8c;
  ExceptionList = &pvStack_10;
  pbStack_24 = pbVar2;
  pbStack_1c = param_1;
  iVar5 = FUN_016dee6d(pbVar2);
  if (iVar5 != 0) {
    FUN_016df3c9(iVar5);
  }
  pbStack_14 = param_1 + 0x74;
  uStack_8 = 0;
  if (((int)param_3 < 1) && ((int)param_3 < 0)) {
    pbStack_2c = (byte *)(-1 - (int)param_2);
    piVar9 = (int *)(-1 - (int)param_3);
  }
  else {
    pbStack_2c = param_2;
    piVar9 = param_3;
  }
  FUN_00606ff0(&iStack_18,(uint)(param_2 + ((uint)piVar9 >> 2) + (int)piVar9 * 0x40) ^ (uint)piVar9,
               &param_2,-(uint)(param_1 + param_1[0x74] + 0x75 != (byte *)0x0) &
                        (uint)(param_1 + param_1[0x74] + 0x75 + 1));
  iVar5 = iStack_18;
  iStack_38 = 0;
  iStack_34 = 0;
  iStack_30 = 0;
  uStack_8._0_1_ = 1;
  if (iStack_18 != 0) {
    if (*(int *)(iStack_18 + 0x18) != 0) {
      LOCK();
      piVar9 = (int *)(*(int *)(iStack_18 + 0x18) + 4);
      *piVar9 = *piVar9 + 1;
      UNLOCK();
    }
    cVar4 = FUN_00bf46c0(param_4,param_5,*(undefined4 *)(iStack_18 + 0x14),
                         *(undefined4 *)(iStack_18 + 0x18));
    if (cVar4 != '\0') {
      piVar9 = *(int **)(iVar5 + 0x14);
      param_3 = (int *)((piVar9[1] - *piVar9) / 0xd0 + -1);
      if ((int *)((iStack_30 - iStack_38) / 0xd0) < param_3) {
        if ((int *)0x13b13b1 < param_3) {
                    /* WARNING: Subroutine does not return */
          FUN_00577c30();
        }
        FUN_00a974c0(param_3);
        piVar9 = *(int **)(iVar5 + 0x14);
      }
      pbStack_14 = (byte *)*piVar9;
      pbStack_20 = (byte *)piVar9[1];
      if (pbStack_14 != pbStack_20) {
        do {
          iVar3 = *(int *)pbStack_14;
          iVar6 = FUN_008881d0();
          if (iVar3 != iVar6) {
                    /* WARNING: Subroutine does not return */
            FUN_016757c0("Variant cast failed");
          }
          pbVar12 = pbStack_14 + 8;
          if (*(int *)(pbStack_14 + 4) == 0) {
            pbVar12 = (byte *)0x0;
          }
          param_3 = *(int **)(pbVar12 + 4);
          if (param_3 != (int *)0x0) {
            LOCK();
            param_3[1] = param_3[1] + 1;
            UNLOCK();
            param_3 = *(int **)(pbVar12 + 4);
          }
          pbVar12 = *(byte **)pbVar12;
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          uStack_40 = 0;
          uStack_3c = 0xf;
          auStack_50[0] = auStack_50[0] & 0xffffff00;
          pbStack_2c = pbVar12;
          piStack_28 = param_3;
          pbStack_1c = pbVar12;
          FUN_005542c0(&DAT_018c1fd8,2);
          pbVar12 = pbVar12 + *pbVar12 + 1;
          uVar7 = FUN_0055c740(pbVar12,auStack_50);
          FUN_00562fc0(&iStack_18,uVar7,auStack_50,
                       -(uint)(pbVar12 != (byte *)0x0) & (uint)(pbVar12 + 1));
          if (0xf < uStack_3c) {
            uVar11 = uStack_3c + 1;
            uVar10 = auStack_50[0];
            if (0xfff < uVar11) {
              uVar10 = *(uint *)(auStack_50[0] - 4);
              uVar11 = uStack_3c + 0x24;
              if (0x1f < (auStack_50[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(uVar10,uVar11);
          }
          uStack_40 = 0;
          uStack_3c = 0xf;
          auStack_50[0] = auStack_50[0] & 0xffffff00;
          piVar9 = param_3;
          if (((iStack_18 != 0) && (*(char *)(*(int *)(iStack_18 + 0x20) + 0x21) != '\0')) &&
             (lVar13 = FUN_00563790(), piVar9 = param_3, lVar13 != CONCAT44(param_5,param_4))) {
            if (iStack_30 == iStack_34) {
              FUN_00bea500(iStack_34,&pbStack_2c);
              piVar9 = piStack_28;
            }
            else {
              FUN_00bebf00(&iStack_38);
              iStack_34 = iStack_34 + 0xd0;
              piVar9 = piStack_28;
            }
          }
          uStack_8._0_1_ = 1;
          if (piVar9 != (int *)0x0) {
            LOCK();
            iVar3 = piVar9[1] + -1;
            piVar9[1] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)*piVar9)();
              LOCK();
              iVar3 = piVar9[2] + -1;
              piVar9[2] = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                (**(code **)(*piVar9 + 4))();
              }
            }
          }
          pbStack_14 = pbStack_14 + 0xd0;
        } while (pbStack_14 != pbStack_20);
      }
      puVar8 = (undefined4 *)FUN_01674e20(0x18);
      uStack_8._0_1_ = 3;
      param_5 = puVar8;
      if (puVar8 == (undefined4 *)0x0) {
        puVar8 = (undefined4 *)0x0;
      }
      else {
        puVar8[1] = 1;
        puVar8[2] = 1;
        *puVar8 = std::
                  _Ref_count_obj<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>
                  ::vftable;
        FUN_006d07c0(&iStack_38);
      }
      *(undefined4 **)(iVar5 + 0x14) = puVar8 + 3;
      piVar9 = *(int **)(iVar5 + 0x18);
      *(undefined4 **)(iVar5 + 0x18) = puVar8;
      if (piVar9 != (int *)0x0) {
        LOCK();
        iVar5 = piVar9[1] + -1;
        piVar9[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar9)();
          LOCK();
          piVar1 = piVar9 + 2;
          iVar5 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar5 == 1) {
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_00577b20();
  uStack_8 = 7;
  iVar5 = FUN_016deec8(pbVar2);
  if (iVar5 != 0) {
    FUN_016df3c9(iVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26904 ; VA 0x00bf9a20 ; FUN_00bf9a20 */

void FUN_00bf9a20(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  code *pcVar1;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01803e67;
  pvStack_10 = ExceptionList;
  pcVar1 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_290 = FUN_0088da50();
  uStack_288 = param_2;
  uStack_28c = 0;
  uStack_284 = param_3;
  uStack_28c = FUN_005c9e80();
  uStack_8 = 0;
  uStack_1c0 = FUN_0088da50();
  uStack_1b8 = param_4;
  uStack_1bc = 0;
  uStack_1b4 = param_5;
  uStack_1bc = FUN_005c9e80();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_f0 = FUN_00bfa7a0();
  uStack_ec = 0;
  uStack_e8 = param_6;
  uStack_ec = FUN_009361b0();
  uStack_8 = 2;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_290,&uStack_20,param_1);
  uStack_8._0_1_ = 3;
  (*pcVar1)(uStack_14,&uStack_20,param_7);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00577b20();
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26905 ; VA 0x00bf9b70 ; FUN_00bf9b70 */

void FUN_00bf9b70(undefined **param_1,uint param_2,int param_3)

{
  uint uVar1;
  bool bVar2;
  undefined **ppuVar3;
  undefined **ppuVar4;
  undefined ***pppuVar5;
  char cVar6;
  undefined4 *puVar7;
  int iVar8;
  int *piVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  code **ppcVar12;
  undefined *apuStack_550 [2];
  code *pcStack_548;
  undefined4 uStack_544;
  undefined4 uStack_540;
  code **ppcStack_53c;
  undefined8 uStack_538;
  undefined **ppuStack_530;
  byte *pbStack_52c;
  code *pcStack_528;
  undefined4 uStack_524;
  undefined **ppuStack_520;
  code **ppcStack_51c;
  undefined8 uStack_518;
  undefined4 uStack_508;
  undefined4 uStack_504;
  undefined auStack_500 [104];
  undefined4 uStack_498;
  undefined4 uStack_494;
  undefined auStack_490 [96];
  undefined auStack_430 [24];
  undefined4 uStack_418;
  undefined4 uStack_414;
  undefined4 uStack_410;
  undefined4 uStack_40c;
  undefined auStack_408 [96];
  undefined4 uStack_3a8;
  undefined4 uStack_3a4;
  undefined4 uStack_3a0;
  undefined4 uStack_39c;
  undefined auStack_398 [96];
  undefined4 uStack_338;
  undefined4 uStack_334;
  undefined4 uStack_330;
  undefined4 uStack_32c;
  undefined auStack_328 [96];
  undefined4 uStack_2c8;
  undefined4 uStack_2c4;
  undefined4 uStack_2c0;
  undefined4 uStack_2bc;
  undefined auStack_2b8 [96];
  undefined4 uStack_258;
  undefined4 uStack_254;
  undefined4 uStack_250;
  undefined4 uStack_24c;
  undefined auStack_248 [96];
  code *pcStack_1e8;
  undefined4 uStack_1e4;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined **ppuStack_1d8;
  uint uStack_1d4;
  undefined auStack_1d0 [24];
  code *pcStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined **ppuStack_1a8;
  uint uStack_1a4;
  undefined auStack_1a0 [24];
  undefined **appuStack_188 [2];
  code *apcStack_180 [6];
  undefined **appuStack_168 [2];
  code *apcStack_160 [6];
  code *pcStack_148;
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined **ppuStack_138;
  uint uStack_134;
  undefined auStack_130 [24];
  undefined **ppuStack_118;
  uint uStack_114;
  code *pcStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined **ppuStack_100;
  uint uStack_fc;
  undefined auStack_f8 [24];
  code *pcStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined **ppuStack_d0;
  uint uStack_cc;
  code *pcStack_c8;
  undefined4 uStack_c4;
  undefined8 uStack_c0;
  ulonglong uStack_b8;
  undefined **ppuStack_b0;
  code *pcStack_a8;
  undefined4 uStack_a4;
  undefined **ppuStack_a0;
  code **ppcStack_9c;
  undefined8 uStack_98;
  undefined *puStack_90;
  code *pcStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  code **ppcStack_7c;
  ulonglong uStack_78;
  code *pcStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined **ppuStack_60;
  uint uStack_5c;
  code *pcStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  code **ppcStack_4c;
  undefined8 uStack_48;
  byte bStack_40;
  undefined auStack_3f [3];
  code *pcStack_3c;
  int iStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined *puStack_28;
  code **ppcStack_24;
  undefined **ppuStack_20;
  undefined4 uStack_1c;
  code *pcStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180401b;
  pvStack_10 = ExceptionList;
  if ((*(int *)(param_3 + 8) != 0) && (-1 < (int)param_2)) {
    bStack_40 = 0;
    uStack_518 = 0xb00bf9bc1;
    ExceptionList = &pvStack_10;
    pcStack_3c = (code *)FUN_00588320();
    iStack_38 = 0;
    uStack_34 = 0x3f800000;
    uStack_30 = 0;
    uStack_2c = 0;
    iStack_8 = 0;
    piVar9 = *(int **)(*(int *)(param_3 + 0x14) + *(int *)(param_3 + 4) * 4);
    if (piVar9 != (int *)0x0) {
      do {
        ppuStack_118 = (undefined **)piVar9[2];
        uVar1 = piVar9[3];
        uStack_114 = uVar1;
        ppuStack_20 = ppuStack_118;
        if (((ppuStack_118 != param_1) || (uVar1 != param_2)) && (-1 < (int)uVar1)) {
          ppcStack_51c = (code **)((uint)((int)ppuStack_118 + (uVar1 >> 2) + uVar1 * 0x40) ^ uVar1);
          uStack_518 = CONCAT44(-(uint)(auStack_3f + bStack_40 != (undefined *)0x0) &
                                (uint)(auStack_3f + bStack_40 + 1),&ppuStack_118);
          ppuStack_520 = &puStack_28;
          uStack_524 = 0xbf9c6e;
          ppcStack_24 = ppcStack_51c;
          FUN_00606ff0();
          if (puStack_28 == (undefined *)0x0) {
            ppcStack_4c = &pcStack_3c;
            iStack_8._0_1_ = 1;
            uStack_48._0_6_ = 0;
            uStack_518 = 0x1000bf9c92;
            puVar7 = (undefined4 *)FUN_01674e20();
            uStack_48._0_6_ = CONCAT24(0x101,puVar7);
            *puVar7 = 0;
            puVar7[1] = 0;
            puVar7[2] = ppuStack_20;
            puVar7[3] = uVar1;
            uStack_518 = CONCAT44(iStack_38 + 1,0xbf9cc1);
            FUN_0062b610();
            uStack_518 = CONCAT44(ppcStack_24,&ppcStack_4c);
            ppcStack_51c = &pcStack_18;
            ppuStack_520 = (undefined **)0xbf9cd4;
            FUN_005c5550();
            iStack_8 = (uint)iStack_8._1_3_ << 8;
            if ((int)uStack_48 != 0) {
              uStack_518 = CONCAT44(0x10,(int)uStack_48);
              ppcStack_51c = (code **)0xbf9ce7;
              FUN_01674ea0();
            }
          }
        }
        piVar9 = (int *)*piVar9;
      } while (piVar9 != (int *)0x0);
      if (iStack_38 != 0) {
        uStack_518 = CONCAT44(&bStack_40,0xbf9d0f);
        FUN_00bedad0();
        iStack_8._0_1_ = 2;
        uStack_518 = CONCAT44(auStack_430,0xbf9d25);
        FUN_00bedad0();
        iStack_8._0_1_ = 3;
        uStack_518 = CONCAT44(&pcStack_c8,0xbf9d3b);
        FUN_00bedad0();
        iStack_8._0_1_ = 4;
        uStack_518 = CONCAT44(auStack_130,0xbf9d4e);
        FUN_00bedad0();
        uStack_108 = uStack_1c;
        iStack_8._0_1_ = 5;
        ppuStack_100 = param_1;
        uStack_fc = param_2;
        uStack_518 = CONCAT44(&pcStack_58,0xbf9d7c);
        FUN_00bedad0();
        uStack_518 = CONCAT44(0xbf9d84,(undefined4)uStack_518);
        FUN_00612320();
        uStack_518 = CONCAT44(0xbf9d8f,(undefined4)uStack_518);
        FUN_00612320();
        uStack_518 = CONCAT44(0xbf9d9a,(undefined4)uStack_518);
        FUN_00612320();
        iStack_8._0_1_ = 6;
        pcStack_1e8 = FUN_00bf8ad0;
        uStack_1e4 = 0;
        uStack_1e0 = uStack_108;
        uStack_1dc = uStack_104;
        ppuStack_1d8 = ppuStack_100;
        uStack_1d4 = uStack_fc;
        uStack_518 = CONCAT44(auStack_f8,0xbf9dd2);
        FUN_00bedad0();
        uStack_518 = CONCAT44(0xbf9ddd,(undefined4)uStack_518);
        FUN_00612320();
        uStack_518 = CONCAT44(0xbf9de8,(undefined4)uStack_518);
        FUN_00612320();
        pcStack_1b8 = pcStack_1e8;
        uStack_1b4 = uStack_1e4;
        iStack_8._0_1_ = 7;
        uStack_1b0 = uStack_1e0;
        uStack_1ac = uStack_1dc;
        ppuStack_1a8 = ppuStack_1d8;
        uStack_1a4 = uStack_1d4;
        uStack_518 = CONCAT44(auStack_1d0,0xbf9e24);
        FUN_00bedad0();
        pcStack_70 = pcStack_1b8;
        uStack_6c = uStack_1b4;
        iStack_8._0_1_ = 8;
        ppuStack_b0 = (undefined **)0x0;
        uStack_68 = uStack_1b0;
        uStack_64 = uStack_1ac;
        ppuStack_60 = ppuStack_1a8;
        uStack_5c = uStack_1a4;
        uStack_518 = CONCAT44(auStack_1a0,0xbf9e5e);
        FUN_00bedad0();
        iStack_8._0_1_ = 9;
        pcStack_148 = pcStack_70;
        uStack_144 = uStack_6c;
        uStack_140 = uStack_68;
        uStack_13c = uStack_64;
        ppuStack_138 = ppuStack_60;
        uStack_134 = uStack_5c;
        uStack_518 = CONCAT44(&pcStack_58,0xbf9e8e);
        FUN_00bedad0();
        pcStack_110 = pcStack_148;
        uStack_10c = uStack_144;
        iStack_8._0_1_ = 10;
        uStack_108 = uStack_140;
        uStack_104 = uStack_13c;
        ppuStack_100 = ppuStack_138;
        uStack_fc = uStack_134;
        uStack_518 = CONCAT44(auStack_130,0xbf9eca);
        FUN_00bedad0();
        iStack_8._0_1_ = 0xb;
        uStack_518 = CONCAT44(&pcStack_110,0xbf9eda);
        cVar6 = FUN_00585a40();
        if (cVar6 == '\0') {
          pcStack_e0 = pcStack_110;
          uStack_dc = uStack_10c;
          uStack_d8 = uStack_108;
          uStack_d4 = uStack_104;
          ppuStack_d0 = ppuStack_100;
          uStack_cc = uStack_fc;
          uStack_518 = CONCAT44(auStack_f8,0xbf9f1d);
          FUN_00bedad0();
          iStack_8._0_1_ = 0xc;
          uStack_518 = 0x3000bf9f28;
          pcStack_a8 = (code *)FUN_01674e20();
          iStack_8._0_1_ = 0xd;
          pcStack_18 = pcStack_a8;
          if (pcStack_a8 == (code *)0x0) {
            pcStack_a8 = (code *)0x0;
          }
          else {
            *(code **)pcStack_a8 = pcStack_e0;
            *(undefined4 *)(pcStack_a8 + 4) = uStack_dc;
            *(undefined4 *)(pcStack_a8 + 8) = uStack_d8;
            *(undefined4 *)(pcStack_a8 + 0xc) = uStack_d4;
            *(undefined ***)(pcStack_a8 + 0x10) = ppuStack_d0;
            *(uint *)(pcStack_a8 + 0x14) = uStack_cc;
            uStack_518 = CONCAT44(&pcStack_c8,0xbf9f63);
            FUN_00bedad0();
          }
          uStack_518 = CONCAT44(0xbf9f78,(undefined4)uStack_518);
          FUN_00612320();
          uStack_518 = CONCAT44(0xbf9f83,(undefined4)uStack_518);
          FUN_00612320();
          cStack_11 = '\x01';
        }
        else {
          uStack_518 = CONCAT44(0xbf9f97,(undefined4)uStack_518);
          FUN_00612320();
          cStack_11 = '\0';
        }
        uStack_518 = CONCAT44(0xbf9fa6,(undefined4)uStack_518);
        FUN_00612320();
        ppuStack_b0 = &PTR_FUN_019604d0;
        if (cStack_11 == '\0') {
          ppuStack_b0 = (undefined **)0x0;
        }
        uStack_518 = CONCAT44(0xbf9fc1,(undefined4)uStack_518);
        FUN_00612320();
        uStack_518 = CONCAT44(0xbf9fcc,(undefined4)uStack_518);
        FUN_00612320();
        uStack_518 = CONCAT44(0xbf9fd7,(undefined4)uStack_518);
        FUN_00612320();
        uStack_48 = CONCAT44(param_2,param_1);
        uStack_c0 = CONCAT44(ppcStack_4c,uStack_1c);
        pcStack_c8 = FUN_00bf8f50;
        uStack_c4 = 0;
        uStack_b8 = uStack_48;
        pcStack_58 = FUN_00bf8f50;
        uStack_54 = 0;
        uStack_50 = uStack_1c;
        uStack_518 = CONCAT44(&pcStack_58,0xbfa01f);
        cVar6 = FUN_00585a40();
        if (cVar6 == '\0') {
          pcStack_88 = pcStack_58;
          uStack_84 = uStack_54;
          uStack_80 = uStack_50;
          ppcStack_7c = ppcStack_4c;
          puStack_90 = (undefined *)0x19604d9;
          uStack_78 = uStack_48;
        }
        else {
          puStack_90 = (undefined *)0x0;
        }
        pcStack_18 = (code *)&ppuStack_530;
        ppcStack_24 = (code **)&ppuStack_530;
        iStack_8._0_1_ = 0xf;
        ppuStack_530 = (undefined **)0x0;
        pppuVar5 = &ppuStack_530;
        if (ppuStack_b0 != (undefined **)0x0) {
          ppuStack_530 = ppuStack_b0;
          if (((uint)ppuStack_b0 & 1) == 0) {
            uStack_538 = ZEXT48(&pcStack_528);
            ppcStack_53c = &pcStack_a8;
            uStack_540 = 0xbfa0a9;
            (**(code **)((uint)ppuStack_b0 & 0xfffffffe))();
            pppuVar5 = (undefined ***)pcStack_18;
          }
          else {
            pcStack_528 = pcStack_a8;
            uStack_524 = uStack_a4;
            ppuStack_520 = ppuStack_a0;
            ppcStack_51c = ppcStack_9c;
            uStack_518 = uStack_98;
            pppuVar5 = &ppuStack_530;
          }
        }
        pcStack_18 = (code *)pppuVar5;
        ppcStack_24 = (code **)apuStack_550;
        ppuStack_20 = apuStack_550;
        iStack_8._0_1_ = 0x10;
        apuStack_550[0] = (undefined *)0x0;
        ppcVar12 = (code **)apuStack_550;
        ppuVar3 = apuStack_550;
        if (puStack_90 != (undefined *)0x0) {
          apuStack_550[0] = puStack_90;
          if (((uint)puStack_90 & 1) == 0) {
            (**(code **)((uint)puStack_90 & 0xfffffffe))(&pcStack_88,&pcStack_548,0);
            ppcVar12 = ppcStack_24;
            ppuVar3 = ppuStack_20;
          }
          else {
            pcStack_548 = pcStack_88;
            uStack_544 = uStack_84;
            uStack_540 = uStack_80;
            ppcStack_53c = ppcStack_7c;
            uStack_538 = uStack_78;
            ppcVar12 = (code **)apuStack_550;
            ppuVar3 = apuStack_550;
          }
        }
        ppuStack_20 = ppuVar3;
        ppcStack_24 = ppcVar12;
        iStack_8._0_1_ = 0x11;
        FUN_00bedad0(&bStack_40);
        uVar10 = uStack_1c;
        iStack_8._0_1_ = 0xf;
        FUN_00bebc90(&uStack_508,FUN_00bf8c60,0,uStack_1c,param_1,param_2);
        uStack_258 = uStack_508;
        uStack_254 = uStack_504;
        iStack_8._0_1_ = 0x12;
        uStack_518 = CONCAT44(auStack_500,0xbfa160);
        FUN_00bed350();
        uStack_2c8 = uStack_258;
        uStack_2c4 = uStack_254;
        iStack_8._0_1_ = 0x13;
        appuStack_188[0] = (undefined **)0x0;
        uStack_518 = CONCAT44(&uStack_250,0xbfa198);
        FUN_00bed350();
        uStack_338 = uStack_2c8;
        uStack_334 = uStack_2c4;
        iStack_8._0_1_ = 0x14;
        uStack_518 = CONCAT44(&uStack_2c0,0xbfa1c6);
        FUN_00bed350();
        uStack_418 = uStack_338;
        uStack_414 = uStack_334;
        iStack_8._0_1_ = 0x15;
        uStack_518 = CONCAT44(&uStack_330,0xbfa1f4);
        FUN_00bed350();
        iStack_8._0_1_ = 0x16;
        uStack_518 = CONCAT44(&uStack_418,0xbfa204);
        cVar6 = FUN_00585a40();
        if (cVar6 == '\0') {
          uStack_3a8 = uStack_418;
          uStack_3a4 = uStack_414;
          uStack_518 = CONCAT44(&uStack_410,0xbfa239);
          FUN_00bed350();
          iStack_8._0_1_ = 0x17;
          uStack_518 = 0x7000bfa244;
          apcStack_180[0] = (code *)FUN_01674e20();
          iStack_8._0_1_ = 0x18;
          pcStack_18 = apcStack_180[0];
          if (apcStack_180[0] == (code *)0x0) {
            apcStack_180[0] = (code *)0x0;
          }
          else {
            *(undefined4 *)apcStack_180[0] = uStack_3a8;
            *(undefined4 *)(apcStack_180[0] + 4) = uStack_3a4;
            uStack_518 = CONCAT44(&uStack_3a0,0xbfa274);
            FUN_00bed350();
          }
          uStack_518 = CONCAT44(0xbfa289,(undefined4)uStack_518);
          FUN_00bee3f0();
          uStack_518 = CONCAT44(0xbfa294,(undefined4)uStack_518);
          FUN_00bee3f0();
          cStack_11 = '\x01';
          uVar10 = uStack_1c;
        }
        else {
          uStack_518 = CONCAT44(0xbfa2a8,(undefined4)uStack_518);
          FUN_00bee3f0();
          cStack_11 = '\0';
        }
        uStack_518 = CONCAT44(0xbfa2b7,(undefined4)uStack_518);
        FUN_00bee3f0();
        appuStack_188[0] = &PTR_FUN_019604e0;
        if (cStack_11 == '\0') {
          appuStack_188[0] = (undefined **)0x0;
        }
        uStack_518 = CONCAT44(0xbfa2d5,(undefined4)uStack_518);
        FUN_00bee3f0();
        uStack_518 = CONCAT44(0xbfa2e0,(undefined4)uStack_518);
        FUN_00bee3f0();
        uStack_518 = CONCAT44(0xbfa2eb,(undefined4)uStack_518);
        FUN_00bee3f0();
        ppuStack_20 = (undefined **)&ppuStack_530;
        pcStack_18 = (code *)&ppuStack_530;
        ppcStack_24 = (code **)CONCAT31(ppcStack_24._1_3_,DAT_01ef7639);
        iStack_8._0_1_ = 0x19;
        ppuStack_530 = (undefined **)0x0;
        pppuVar5 = &ppuStack_530;
        if (ppuStack_b0 != (undefined **)0x0) {
          ppuStack_530 = ppuStack_b0;
          if (((uint)ppuStack_b0 & 1) == 0) {
            uStack_538 = ZEXT48(&pcStack_528);
            ppcStack_53c = &pcStack_a8;
            uStack_540 = 0xbfa347;
            (**(code **)((uint)ppuStack_b0 & 0xfffffffe))();
            pppuVar5 = (undefined ***)pcStack_18;
          }
          else {
            pcStack_528 = pcStack_a8;
            uStack_524 = uStack_a4;
            ppuStack_520 = ppuStack_a0;
            ppcStack_51c = ppcStack_9c;
            uStack_518 = uStack_98;
            pppuVar5 = &ppuStack_530;
          }
        }
        pcStack_18 = (code *)pppuVar5;
        ppuStack_20 = apuStack_550;
        puStack_28 = (undefined *)apuStack_550;
        iStack_8._0_1_ = 0x1a;
        apuStack_550[0] = (undefined *)0x0;
        ppuVar3 = apuStack_550;
        ppuVar4 = apuStack_550;
        if (puStack_90 != (undefined *)0x0) {
          apuStack_550[0] = puStack_90;
          if (((uint)puStack_90 & 1) == 0) {
            (**(code **)((uint)puStack_90 & 0xfffffffe))(&pcStack_88,&pcStack_548,0);
            ppuVar3 = (undefined **)puStack_28;
            ppuVar4 = ppuStack_20;
          }
          else {
            pcStack_548 = pcStack_88;
            uStack_544 = uStack_84;
            uStack_540 = uStack_80;
            ppcStack_53c = ppcStack_7c;
            uStack_538 = uStack_78;
            ppuVar3 = apuStack_550;
            ppuVar4 = apuStack_550;
          }
        }
        ppuStack_20 = ppuVar4;
        puStack_28 = (undefined *)ppuVar3;
        iStack_8._0_1_ = 0x1b;
        FUN_00bedad0(param_3);
        iStack_8._0_1_ = 0x19;
        uVar11 = uVar10;
        ppcVar12 = ppcStack_24;
        FUN_00beb7c0(&uStack_410,FUN_00bf9060,0,uVar10,ppcStack_24);
        uStack_3a0 = uStack_410;
        uStack_39c = uStack_40c;
        iStack_8._0_1_ = 0x1c;
        uStack_518 = CONCAT44(auStack_408,0xbfa3fb);
        FUN_00bed110();
        uStack_330 = uStack_3a0;
        uStack_32c = uStack_39c;
        iStack_8._0_1_ = 0x1d;
        appuStack_168[0] = (undefined **)0x0;
        uStack_518 = CONCAT44(auStack_398,0xbfa433);
        FUN_00bed110();
        uStack_2c0 = uStack_330;
        uStack_2bc = uStack_32c;
        iStack_8._0_1_ = 0x1e;
        uStack_518 = CONCAT44(auStack_328,0xbfa461);
        FUN_00bed110();
        uStack_498 = uStack_2c0;
        uStack_494 = uStack_2bc;
        iStack_8._0_1_ = 0x1f;
        uStack_518 = CONCAT44(auStack_2b8,0xbfa48f);
        FUN_00bed110();
        iStack_8._0_1_ = 0x20;
        uStack_518 = CONCAT44(&uStack_498,0xbfa49f);
        cVar6 = FUN_00585a40();
        if (cVar6 == '\0') {
          uStack_250 = uStack_498;
          uStack_24c = uStack_494;
          uStack_518 = CONCAT44(auStack_490,0xbfa4d4);
          FUN_00bed110();
          iStack_8._0_1_ = 0x21;
          uStack_518 = 0x6800bfa4df;
          apcStack_160[0] = (code *)FUN_01674e20();
          iStack_8._0_1_ = 0x22;
          if (apcStack_160[0] == (code *)0x0) {
            apcStack_160[0] = (code *)0x0;
          }
          else {
            *(undefined4 *)apcStack_160[0] = uStack_250;
            *(undefined4 *)(apcStack_160[0] + 4) = uStack_24c;
            uStack_518 = CONCAT44(auStack_248,0xbfa50f);
            FUN_00bed110();
          }
          uStack_518 = CONCAT44(0xbfa524,(undefined4)uStack_518);
          FUN_00bee360();
          uStack_518 = CONCAT44(0xbfa52f,(undefined4)uStack_518);
          FUN_00bee360();
          bVar2 = true;
          uVar10 = uStack_1c;
        }
        else {
          uStack_518 = CONCAT44(0xbfa543,(undefined4)uStack_518);
          FUN_00bee360();
          bVar2 = false;
        }
        uStack_518 = CONCAT44(0xbfa552,(undefined4)uStack_518);
        FUN_00bee360();
        appuStack_168[0] = &PTR_FUN_019604e8;
        if (!bVar2) {
          appuStack_168[0] = (undefined **)0x0;
        }
        uStack_518 = CONCAT44(0xbfa570,(undefined4)uStack_518);
        FUN_00bee360();
        uStack_518 = CONCAT44(0xbfa57b,(undefined4)uStack_518);
        FUN_00bee360();
        uStack_518 = CONCAT44(0xbfa586,(undefined4)uStack_518);
        FUN_00bee360();
        iStack_8._0_1_ = 0x23;
        uStack_518 = CONCAT44(uVar10,0xbfa590);
        iVar8 = FUN_00965f10();
        if (iVar8 == 0) {
          pbStack_52c = (byte *)0x14;
          uStack_518 = 0xf00000000;
          ppuStack_530 = (undefined **)0x19600dc;
          pcStack_528 = (code *)((uint)pcStack_528 & 0xffffff00);
          uStack_538 = CONCAT44(0xbfa635,(undefined4)uStack_538);
          FUN_005542c0();
          pbStack_52c = (byte *)0xbfa640;
          FUN_005e65e0();
        }
        else {
          pbStack_52c = &bStack_40;
          ppuStack_530 = (undefined **)0xbfa5a7;
          FUN_00bedad0();
          pbStack_52c = (byte *)param_2;
          ppuStack_530 = param_1;
          uStack_538 = CONCAT44(&pcStack_c8,0xbfa5b7);
          FUN_00f83450();
          iStack_8._0_1_ = 0x24;
          uStack_538 = CONCAT44(appuStack_188,0xbfa5cf);
          FUN_0054f510();
          iStack_8._0_1_ = 0x25;
          FUN_0054f510(appuStack_168);
          iStack_8._0_1_ = 0x26;
          FUN_0054ef60(&pcStack_c8);
          iStack_8._0_1_ = 0x24;
          FUN_00bcb620(uVar11,ppcVar12);
          uStack_518 = CONCAT44(0xbfa616,(undefined4)uStack_518);
          FUN_005507b0();
        }
        iStack_8._0_1_ = 0x27;
        if (appuStack_168[0] != (undefined **)0x0) {
          if ((((uint)appuStack_168[0] & 1) == 0) &&
             (*(code **)((uint)appuStack_168[0] & 0xfffffffe) != (code *)0x0)) {
            ppcStack_51c = apcStack_160;
            uStack_518 = CONCAT44(2,ppcStack_51c);
            ppuStack_520 = (undefined **)0xbfa667;
            (**(code **)((uint)appuStack_168[0] & 0xfffffffe))();
          }
          appuStack_168[0] = (undefined **)0x0;
        }
        iStack_8._0_1_ = 0x28;
        if (appuStack_188[0] != (undefined **)0x0) {
          if ((((uint)appuStack_188[0] & 1) == 0) &&
             (*(code **)((uint)appuStack_188[0] & 0xfffffffe) != (code *)0x0)) {
            ppcStack_51c = apcStack_180;
            uStack_518 = CONCAT44(2,ppcStack_51c);
            ppuStack_520 = (undefined **)0xbfa69b;
            (**(code **)((uint)appuStack_188[0] & 0xfffffffe))();
          }
          appuStack_188[0] = (undefined **)0x0;
        }
        iStack_8._0_1_ = 0x29;
        if (puStack_90 != (undefined *)0x0) {
          if ((((uint)puStack_90 & 1) == 0) &&
             (*(code **)((uint)puStack_90 & 0xfffffffe) != (code *)0x0)) {
            ppcStack_51c = &pcStack_88;
            uStack_518 = CONCAT44(2,ppcStack_51c);
            ppuStack_520 = (undefined **)0xbfa6cf;
            (**(code **)((uint)puStack_90 & 0xfffffffe))();
          }
          puStack_90 = (undefined *)0x0;
        }
        iStack_8 = CONCAT31(iStack_8._1_3_,0x2a);
        if (((ppuStack_b0 != (undefined **)0x0) && (((uint)ppuStack_b0 & 1) == 0)) &&
           (*(code **)((uint)ppuStack_b0 & 0xfffffffe) != (code *)0x0)) {
          ppcStack_51c = &pcStack_a8;
          uStack_518 = CONCAT44(2,ppcStack_51c);
          ppuStack_520 = (undefined **)0xbfa703;
          (**(code **)((uint)ppuStack_b0 & 0xfffffffe))();
        }
      }
    }
    uStack_518 = CONCAT44(0xbfa70e,(undefined4)uStack_518);
    FUN_00612320();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26906 ; VA 0x00bfa720 ; FUN_00bfa720 */

void FUN_00bfa720(void)

{
  FUN_00bef730();
  return;
}



/* FUNCTION 26907 ; VA 0x00bfa730 ; FUN_00bfa730 */

void FUN_00bfa730(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 int param_5)

{
  int iVar1;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_14 = param_1;
  uStack_8 = param_4;
  uStack_20 = param_4;
  uStack_1c = param_1;
  uStack_10 = param_2;
  uStack_c = param_3;
  uStack_24 = param_3;
  uStack_18 = param_2;
  iVar1 = FUN_00bee9d0(&uStack_14);
  *(int *)(iVar1 + 0x10) = param_5;
  if (param_5 == 3) {
    param_5 = 4;
  }
  else if (param_5 == 4) {
    param_5 = 3;
  }
  iVar1 = FUN_00bee9d0(&uStack_24);
  *(int *)(iVar1 + 0x10) = param_5;
  return;
}



/* FUNCTION 26908 ; VA 0x00bfa7a0 ; FUN_00bfa7a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00bfa7a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804046;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef78cc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef78cc);
    if (DAT_01ef78cc == -1) {
      uStack_8 = 0;
      FUN_009ca470("FriendRequestEvent");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef7868 = RBX::Reflection::EnumDesc<enum_RBX::FriendService_FriendEventType>::vftable;
      FUN_009caf20(&DAT_01d6808c,4);
      FUN_016f3654(&LAB_01892a40);
      FUN_016f37bf(&DAT_01ef78cc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef7868;
}



/* FUNCTION 26909 ; VA 0x00bfa850 ; FUN_00bfa850 */

void __thiscall
FUN_00bfa850(int param_1,int param_2,uint param_3,int param_4,uint param_5,char param_6)

{
  int iVar1;
  uint uVar2;
  undefined1 *puVar3;
  int iVar4;
  uint uVar5;
  int iStack_30;
  uint uStack_2c;
  int iStack_28;
  uint uStack_24;
  int iStack_20;
  uint uStack_1c;
  int iStack_18;
  uint uStack_14;
  int iStack_c;
  int iStack_8;
  
  uVar2 = param_3;
  iVar1 = param_2;
  iVar4 = param_1 + 0x135 + (uint)*(byte *)(param_1 + 0x134);
  uVar5 = param_3;
  if (((int)param_3 < 1) && ((int)param_3 < 0)) {
    uVar5 = ~param_3;
  }
  iStack_8 = param_1;
  FUN_00606ff0(&iStack_c,(uVar5 >> 2) + uVar5 * 0x40 + param_2 ^ uVar5,&param_2,
               -(uint)(iVar4 != 0) & iVar4 + 1U);
  if ((iStack_c != 0) && (iVar4 = FUN_00bf16a0(&param_4), uVar5 = param_5, iVar4 != 0)) {
    if (DAT_01ef7604 != '\0') {
      puVar3 = &DAT_018bdf50;
      if (param_6 == '\0') {
        puVar3 = &DAT_018bdf48;
      }
      FUN_01677520(DAT_01ef7604,"FriendService: FriendRequestOnline (%lld to %lld) %s",iVar1,uVar2,
                   param_4,param_5,puVar3);
    }
    iStack_c = FUN_00bf1ef0(iVar1,uVar2,param_4,uVar5);
    param_3 = iStack_8 + 0x104;
    if (param_6 == '\0') {
      iStack_28 = param_4;
      iStack_20 = param_4;
      iStack_30 = iVar1;
      uStack_2c = uVar2;
      uStack_24 = uVar5;
      uStack_1c = uVar5;
      iStack_18 = iVar1;
      uStack_14 = uVar2;
      iVar4 = FUN_00bee9d0(&iStack_30);
      *(undefined4 *)(iVar4 + 0x10) = 1;
      iVar4 = FUN_00bee9d0(&iStack_20);
      *(undefined4 *)(iVar4 + 0x10) = 1;
    }
    else {
      iStack_18 = param_4;
      iStack_30 = param_4;
      iStack_20 = iVar1;
      uStack_1c = uVar2;
      uStack_14 = uVar5;
      uStack_2c = uVar5;
      iStack_28 = iVar1;
      uStack_24 = uVar2;
      iVar4 = FUN_00bee9d0(&iStack_20);
      *(undefined4 *)(iVar4 + 0x10) = 3;
      iVar4 = FUN_00bee9d0(&iStack_30);
      *(undefined4 *)(iVar4 + 0x10) = 4;
    }
    iVar4 = FUN_00bf1ef0(iVar1,uVar2,param_4,uVar5);
    if (iVar4 != iStack_c) {
      FUN_00bf1b70(iStack_8,iVar1,uVar2,param_4,uVar5,iVar4);
    }
  }
  return;
}



/* FUNCTION 26910 ; VA 0x00bfa9e0 ; FUN_00bfa9e0 */

void __thiscall
FUN_00bfa9e0(int param_1,uint param_2,int param_3,uint param_4,uint param_5,int *param_6,
            char param_7,int *param_8)

{
  int *piVar1;
  uint *puVar2;
  undefined1 *puVar3;
  int iVar4;
  int iVar5;
  uint *puVar6;
  undefined4 uVar7;
  uint uVar8;
  int *piVar9;
  uint *puVar10;
  int *piVar11;
  int iStack_6c;
  int iStack_68;
  int iStack_64;
  uint uStack_5c;
  uint uStack_58;
  int iStack_54;
  uint uStack_50;
  int iStack_4c;
  uint *puStack_3c;
  uint *puStack_38;
  int iStack_34;
  undefined4 uStack_30;
  uint *puStack_2c;
  uint *puStack_28;
  int *piStack_24;
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804070;
  pvStack_10 = ExceptionList;
  uStack_30 = CONCAT31(uStack_30._1_3_,param_6 == (int *)0x2);
  puStack_14 = &stack0xffffff84;
  piStack_24 = (int *)param_4;
  iStack_18 = param_5;
  uStack_20 = param_2;
  iStack_1c = param_3;
  if (((int)param_5 <= param_3) && (((int)param_5 < param_3 || (param_4 < param_2)))) {
    uStack_20 = param_4;
    iStack_1c = param_5;
    piStack_24 = (int *)param_2;
    iStack_18 = param_3;
  }
  piVar9 = piStack_24;
  uStack_58 = uStack_20;
  iStack_54 = iStack_1c;
  uStack_50 = (uint)piStack_24;
  iStack_4c = iStack_18;
  puStack_28 = (uint *)param_1;
  if (param_7 == '\0') {
    puStack_2c = (uint *)&DAT_018bdf48;
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffff84;
  }
  else {
    if (DAT_01ef7604 == '\0') {
      puStack_2c = (uint *)&DAT_018bdf48;
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffff84;
    }
    else {
      puVar3 = &DAT_018bdf50;
      puStack_2c = (uint *)&DAT_018bdf48;
      if (param_6 != (int *)0x2) {
        puVar3 = &DAT_018bdf48;
      }
      ExceptionList = &pvStack_10;
      FUN_01677520(DAT_01ef7604,"FriendService: CacheStatusOnline (%lld %lld) %s",uStack_20,
                   iStack_1c,piStack_24,iStack_18,puVar3);
    }
    iVar4 = FUN_00bf1ef0(uStack_20,iStack_1c,piVar9,iStack_18);
    FUN_00bfa730(param_2,param_3,param_4,param_5,param_6);
    iVar5 = FUN_00bf1ef0(uStack_20,iStack_1c,piStack_24,iStack_18);
    piVar9 = piStack_24;
    if (iVar5 != iVar4) {
      FUN_00bf1b70(param_1,uStack_20,iStack_1c,piStack_24,iStack_18,iVar5);
    }
  }
  if (DAT_01ef7606 != '\0') {
    if (param_7 == '\0') {
      puVar6 = (uint *)"ERROR";
    }
    else {
      puVar6 = (uint *)"true";
      if (param_6 != (int *)0x2) {
        puVar6 = puStack_2c;
      }
    }
    FUN_01677520(DAT_01ef7606,"FriendService: StatusCallback (%lld, %lld) %s",uStack_20,iStack_1c,
                 piVar9,iStack_18,puVar6);
  }
  iVar4 = (uint)*(byte *)(param_1 + 0x11c) + param_1 + 0x11d;
  uVar7 = FUN_00bf3620(&uStack_58);
  FUN_00a29a20(&param_6,uVar7,&uStack_58,-(uint)(iVar4 != 0) & iVar4 + 1U);
  if (param_6 != (int *)0x0) {
    puVar6 = (uint *)param_6[7];
    puStack_3c = (uint *)param_6[6];
    iStack_34 = param_6[8];
    param_6[6] = 0;
    param_6[7] = 0;
    param_6[8] = 0;
    piStack_24 = (int *)*param_6;
    uStack_8 = 0;
    puStack_2c = (uint *)((int)puStack_28 + 0x120);
    param_5 = (uint)param_6[1] % *puStack_2c;
    piVar9 = *(int **)(*(int *)((int)puStack_28 + 0x130) + param_5 * 4);
    for (piVar11 = (int *)*piVar9; piVar1 = piVar9, puStack_38 = puVar6, piVar11 != param_6;
        piVar11 = (int *)*piVar11) {
      piVar9 = piVar11;
    }
    do {
      param_6 = piVar1;
      *piVar9 = *piVar11;
      FUN_00bee5b0();
      FUN_01674ea0(piVar11,0x28);
      *(int *)((int)puStack_28 + 0x124) = *(int *)((int)puStack_28 + 0x124) + -1;
      uVar8 = param_5;
      if (*piVar9 == 0) {
LAB_00bfac45:
        if (*(int **)(*(int *)((int)puStack_28 + 0x130) + param_5 * 4) == piVar9) {
          *(undefined4 *)(*(int *)((int)puStack_28 + 0x130) + param_5 * 4) = 0;
        }
      }
      else {
        uVar8 = *(uint *)(*piVar9 + 4) % *puStack_2c;
        piVar9 = param_6;
        if (param_5 != uVar8) {
          *(int **)(*(int *)((int)puStack_28 + 0x130) + uVar8 * 4) = param_6;
          goto LAB_00bfac45;
        }
      }
      piVar11 = (int *)*piVar9;
      puVar10 = puStack_3c;
      param_5 = uVar8;
      piVar1 = param_6;
      puVar2 = puVar6;
    } while (piVar11 != piStack_24);
    while (puStack_28 = puVar2, puStack_2c = puVar10, puVar10 != puVar6) {
      uStack_8._0_1_ = 1;
      if (param_7 == '\0') {
        uVar8 = param_8[4];
        param_6 = param_8;
        if (0xf < (uint)param_8[5]) {
          param_6 = (int *)*param_8;
        }
        if (uVar8 < 0x10) {
          iVar4 = *param_6;
          iStack_6c = param_6[1];
          iStack_68 = param_6[2];
          iStack_64 = param_6[3];
          uStack_5c = 0xf;
        }
        else {
          uStack_5c = uVar8 | 0xf;
          if (0x7fffffff < uStack_5c) {
            uStack_5c = 0x7fffffff;
          }
          iVar4 = FUN_00554060(uStack_5c + 1);
          FUN_0170c6f0(iVar4,param_6,uVar8 + 1);
        }
        uStack_8._0_1_ = 3;
        if (puVar10[8] == 0) {
          uVar7 = FUN_0054fda0();
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
          FUN_0054e5e0(uVar7);
        }
        (**(code **)((puVar10[8] & 0xfffffffe) + 4))
                  (puVar10 + 10,iVar4,iStack_6c,iStack_68,iStack_64,uVar8,uStack_5c);
        uStack_8 = 0;
        puVar10 = puVar10 + 0x10;
        puVar2 = puStack_28;
      }
      else {
        if (*puVar10 == 0) {
          uVar7 = FUN_0054fda0();
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
          FUN_0054e5e0(uVar7);
        }
        (**(code **)((*puVar10 & 0xfffffffe) + 4))(puVar10 + 2,uStack_30);
        uStack_8 = 0;
        puVar10 = puVar10 + 0x10;
        puVar2 = puStack_28;
      }
    }
    FUN_00bee5b0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26911 ; VA 0x00bfad7a ; Catch_All@00bfad7a */

undefined * Catch_All_00bfad7a(void)

{
  return &DAT_00bfad80;
}



/* FUNCTION 26912 ; VA 0x00bfade0 ; FUN_00bfade0 */

undefined4 * __thiscall FUN_00bfade0(undefined4 *param_1)

{
  char cVar1;
  uint uVar2;
  undefined **ppuVar3;
  uint in_stack_00000018;
  uint in_stack_0000003c;
  undefined4 in_stack_00000058;
  undefined auStack_c8 [20];
  uint uStack_b4;
  undefined auStack_b0 [32];
  uint uStack_90;
  undefined auStack_8c [28];
  undefined auStack_70 [20];
  uint uStack_5c;
  undefined auStack_58 [32];
  uint uStack_38;
  undefined auStack_34 [28];
  undefined4 *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180409b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  FUN_00bfbdf0(&stack0x00000004);
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_00bfbdf0(auStack_c8);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00bfbdf0(auStack_70);
  ppuVar3 = &PTR_FUN_01960a14;
  cVar1 = FUN_00bfb410();
  if (cVar1 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uVar2 = uStack_38;
  if ((int)uStack_38 < 0) {
    uVar2 = ~uStack_38;
  }
  FUN_00bfbac0(uStack_38,uVar2,&uStack_11,auStack_34,in_stack_00000058,in_stack_00000058,0,0);
  uVar2 = uStack_5c;
  if ((int)uStack_5c < 0) {
    uVar2 = ~uStack_5c;
  }
  FUN_00bfbac0(uStack_5c,uVar2,&uStack_11,auStack_58,in_stack_00000058,in_stack_00000058,0,0);
  uVar2 = uStack_90;
  if ((int)uStack_90 < 0) {
    uVar2 = ~uStack_90;
  }
  FUN_00bfbac0(uStack_90,uVar2,&uStack_11,auStack_8c,in_stack_00000058,in_stack_00000058,0,0);
  uVar2 = uStack_b4;
  if ((int)uStack_b4 < 0) {
    uVar2 = ~uStack_b4;
  }
  FUN_00bfbac0(uStack_b4,uVar2,&uStack_11,auStack_b0,in_stack_00000058,in_stack_00000058,0,0);
  uVar2 = in_stack_0000003c;
  if ((int)in_stack_0000003c < 0) {
    uVar2 = ~in_stack_0000003c;
  }
  FUN_00bfbac0(in_stack_0000003c,uVar2,&uStack_11,&stack0x00000040,in_stack_00000058,
               in_stack_00000058,0,0);
  uVar2 = in_stack_00000018;
  if ((int)in_stack_00000018 < 0) {
    uVar2 = ~in_stack_00000018;
  }
  FUN_00bfbac0(in_stack_00000018,uVar2,&uStack_11,&stack0x0000001c,in_stack_00000058,
               in_stack_00000058,0,0);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26913 ; VA 0x00bfaf70 ; FUN_00bfaf70 */

undefined4 * __thiscall
FUN_00bfaf70(undefined4 *param_1,uint param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined8 param_8)

{
  uint *puVar1;
  char cVar2;
  undefined **ppuVar3;
  uint auStack_80 [2];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 uStack_68;
  undefined4 *puStack_60;
  uint uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018040c8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_34 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_2 != 0) {
    uStack_34 = param_2;
    if ((param_2 & 1) == 0) {
      puStack_60 = (undefined4 *)0x0;
      uStack_68 = CONCAT44(&uStack_2c,&param_4);
      uStack_6c = 0xbfafd4;
      ExceptionList = &pvStack_10;
      (**(code **)(param_2 & 0xfffffffe))();
    }
    else {
      uStack_2c = param_4;
      uStack_28 = param_5;
      uStack_24 = param_6;
      uStack_20 = param_7;
      uStack_1c = param_8;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  uStack_54 = 0;
  if (uStack_34 != 0) {
    uStack_54 = uStack_34;
    if ((uStack_34 & 1) == 0) {
      puStack_60 = (undefined4 *)0x0;
      uStack_68 = CONCAT44(&uStack_4c,&uStack_2c);
      uStack_6c = 0xbfb01d;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    else {
      uStack_4c = uStack_2c;
      uStack_48 = uStack_28;
      uStack_44 = uStack_24;
      uStack_40 = uStack_20;
      uStack_3c = uStack_1c;
    }
  }
  puStack_60 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = auStack_80;
  auStack_80[0] = 0;
  puVar1 = auStack_80;
  if (uStack_54 != 0) {
    auStack_80[0] = uStack_54;
    if ((uStack_54 & 1) == 0) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,&uStack_78,0);
      puVar1 = puStack_14;
    }
    else {
      uStack_78 = uStack_4c;
      uStack_74 = uStack_48;
      uStack_70 = uStack_44;
      uStack_6c = uStack_40;
      uStack_68 = uStack_3c;
      puVar1 = auStack_80;
    }
  }
  puStack_14 = puVar1;
  ppuVar3 = &PTR_FUN_01960a0c;
  cVar2 = FUN_00bfb600();
  if (cVar2 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8._0_1_ = 3;
  if (((uStack_54 != 0) && ((uStack_54 & 1) == 0)) &&
     (*(code **)(uStack_54 & 0xfffffffe) != (code *)0x0)) {
    puStack_60 = (undefined4 *)0x2;
    uStack_68 = CONCAT44(&uStack_4c,&uStack_4c);
    uStack_6c = 0xbfb0a6;
    (**(code **)(uStack_54 & 0xfffffffe))();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      puStack_60 = (undefined4 *)0x2;
      uStack_68 = CONCAT44(&uStack_2c,&uStack_2c);
      uStack_6c = 0xbfb0d5;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  uStack_8 = 5;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    puStack_60 = (undefined4 *)0x2;
    uStack_68 = CONCAT44(&param_4,&param_4);
    uStack_6c = 0xbfb103;
    (**(code **)(param_2 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26914 ; VA 0x00bfb120 ; FUN_00bfb120 */

undefined * FUN_00bfb120(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018040ec;
  pvStack_10 = ExceptionList;
  if (DAT_01ef78e4 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef7af0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef7af0);
      if (DAT_01ef7af0 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"PermissionsService",1,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_01892b70);
        FUN_016f37bf(&DAT_01ef7af0);
      }
    }
    DAT_01ef78e4 = &DAT_01ef78e8;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef78e4;
}



/* FUNCTION 26915 ; VA 0x00bfb200 ; FUN_00bfb200 */

void FUN_00bfb200(void)

{
  int iVar1;
  
  if (DAT_01ef7af4 == 0) {
    iVar1 = FUN_00bfb120();
    DAT_01ef7af4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 26916 ; VA 0x00bfb220 ; FUN_00bfb220 */

void FUN_00bfb220(uint *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  uint *puVar3;
  uint *puVar4;
  uint uVar5;
  uint *puVar6;
  
  puVar4 = param_2;
  puVar3 = param_1;
  if (param_1 != param_2) {
    puVar6 = param_1 + 1;
    do {
      uVar2 = *puVar6;
      uVar5 = ~uVar2;
      if (-1 < (int)uVar2) {
        uVar5 = uVar2;
      }
      FUN_00bfbac0(uVar2,uVar5,(int)&param_1 + 3,puVar6 + 1,puVar3,param_1,0,0);
      puVar1 = puVar6 + 8;
      puVar6 = puVar6 + 9;
    } while (puVar1 != puVar4);
  }
  return;
}



/* FUNCTION 26917 ; VA 0x00bfb270 ; FUN_00bfb270 */

int __thiscall FUN_00bfb270(int *param_1,int param_2,undefined4 *param_3)

{
  uint uVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804100;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffbc;
  iVar5 = *param_1;
  puStack_1c = (undefined4 *)((param_2 - iVar5) / 0x24);
  iVar3 = (param_1[1] - iVar5) / 0x24;
  if (iVar3 == 0x71c71c7) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar3 + 1;
  uVar6 = (param_1[2] - iVar5) / 0x24;
  uVar7 = uVar1;
  if ((uVar6 <= 0x71c71c7 - (uVar6 >> 1)) && (uVar7 = (uVar6 >> 1) + uVar6, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  ExceptionList = &pvStack_10;
  uStack_20 = uVar7;
  puStack_14 = &stack0xffffffbc;
  puVar4 = (undefined4 *)FUN_00a203e0(uVar7);
  iVar5 = (int)puStack_1c * 0x24;
  puVar2 = puVar4 + (int)puStack_1c * 9;
  puStack_1c = puVar2 + 9;
  *puVar2 = *param_3;
  puStack_24 = puVar2 + 2;
  uVar1 = param_3[1];
  uStack_8 = 0;
  uVar6 = ~uVar1;
  if (-1 < (int)uVar1) {
    uVar6 = uVar1;
  }
  puStack_18 = puStack_1c;
  FUN_00bfbc40(uVar1,uVar6,&puStack_24,param_3 + 2,param_2,param_2,0,0);
  uVar1 = param_3[1];
  uVar6 = ~uVar1;
  if (-1 < (int)uVar1) {
    uVar6 = uVar1;
  }
  puVar2[1] = uVar6;
  puStack_18 = puVar2;
  if (param_2 == param_1[1]) {
    FUN_00bfcb40(*param_1,param_1[1],puVar4);
  }
  else {
    FUN_00bfca80(*param_1,param_2,puVar4);
    puStack_18 = puVar4;
    FUN_00bfca80(param_2,param_1[1],puStack_1c);
  }
  FUN_00bfc930(puVar4,iVar3 + 1,uVar7);
  ExceptionList = pvStack_10;
  return *param_1 + iVar5;
}



/* FUNCTION 26918 ; VA 0x00bfb3e5 ; Catch_All@00bfb3e5 */

void Catch_All_00bfb3e5(void)

{
  int unaff_EBP;
  
  FUN_00bfc9c0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x18));
  FUN_00781060(*(undefined4 *)(unaff_EBP + -0x34),*(undefined4 *)(unaff_EBP + -0x1c));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 26919 ; VA 0x00bfb410 ; FUN_00bfb410 */

undefined FUN_00bfb410(void)

{
  char cVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined uVar4;
  uint in_stack_00000018;
  uint in_stack_0000003c;
  undefined4 *in_stack_0000005c;
  undefined auStack_c4 [20];
  uint uStack_b0;
  undefined auStack_ac [32];
  uint uStack_8c;
  undefined auStack_88 [28];
  undefined auStack_6c [20];
  uint uStack_58;
  undefined auStack_54 [32];
  uint uStack_34;
  undefined auStack_30 [28];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180413a;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00bfbdf0(&stack0x00000004);
  uStack_8._0_1_ = 1;
  cVar1 = FUN_00585a40(auStack_6c);
  if (cVar1 == '\0') {
    FUN_00bfbdf0(auStack_6c);
    uStack_8._0_1_ = 2;
    iStack_14 = FUN_01674e20(0x58);
    uStack_8._0_1_ = 3;
    if (iStack_14 == 0) {
      uVar2 = 0;
    }
    else {
      uVar2 = FUN_00bfbdf0(auStack_c4);
    }
    *in_stack_0000005c = uVar2;
    uVar3 = uStack_8c;
    if ((int)uStack_8c < 0) {
      uVar3 = ~uStack_8c;
    }
    FUN_00bfbac0(uStack_8c,uVar3,(int)&stack0x0000005c + 3,auStack_88,in_stack_0000005c,
                 in_stack_0000005c,0,0);
    uVar3 = uStack_b0;
    if ((int)uStack_b0 < 0) {
      uVar3 = ~uStack_b0;
    }
    FUN_00bfbac0(uStack_b0,uVar3,(int)&stack0x0000005c + 3,auStack_ac,in_stack_0000005c,
                 in_stack_0000005c,0,0);
    uVar3 = uStack_34;
    if ((int)uStack_34 < 0) {
      uVar3 = ~uStack_34;
    }
    FUN_00bfbac0(uStack_34,uVar3,(int)&stack0x0000005c + 3,auStack_30,in_stack_0000005c,
                 in_stack_0000005c,0,0);
    uVar3 = uStack_58;
    if ((int)uStack_58 < 0) {
      uVar3 = ~uStack_58;
    }
    FUN_00bfbac0(uStack_58,uVar3,(int)&stack0x0000005c + 3,auStack_54,in_stack_0000005c,
                 in_stack_0000005c,0,0);
    uVar4 = 1;
  }
  else {
    uVar3 = uStack_34;
    if ((int)uStack_34 < 0) {
      uVar3 = ~uStack_34;
    }
    FUN_00bfbac0(uStack_34,uVar3,(int)&stack0x0000005c + 3,auStack_30,in_stack_0000005c,
                 in_stack_0000005c,0,0);
    uVar3 = uStack_58;
    if ((int)uStack_58 < 0) {
      uVar3 = ~uStack_58;
    }
    FUN_00bfbac0(uStack_58,uVar3,(int)&stack0x0000005c + 3,auStack_54,in_stack_0000005c,
                 in_stack_0000005c,0,0);
    uVar4 = 0;
  }
  uVar3 = in_stack_0000003c;
  if ((int)in_stack_0000003c < 0) {
    uVar3 = ~in_stack_0000003c;
  }
  FUN_00bfbac0(in_stack_0000003c,uVar3,(int)&stack0x0000005c + 3,&stack0x00000040,in_stack_0000005c,
               in_stack_0000005c,0,0);
  uVar3 = in_stack_00000018;
  if ((int)in_stack_00000018 < 0) {
    uVar3 = ~in_stack_00000018;
  }
  FUN_00bfbac0(in_stack_00000018,uVar3,(int)&stack0x0000005c + 3,&stack0x0000001c,in_stack_0000005c,
               in_stack_0000005c,0,0);
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 26920 ; VA 0x00bfb600 ; FUN_00bfb600 */

undefined FUN_00bfb600(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 *param_8)

{
  char cVar1;
  undefined4 *puVar2;
  undefined uVar3;
  undefined4 *puStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 *apuStack_34 [2];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01804177;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  apuStack_34[0] = (undefined4 *)0x0;
  puStack_14 = param_1;
  ExceptionList = &pvStack_10;
  if (param_1 != (undefined4 *)0x0) {
    apuStack_34[0] = param_1;
    if (((uint)param_1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)((uint)param_1 & 0xfffffffe))(&param_3,&uStack_2c,0);
    }
    else {
      uStack_2c = param_3;
      uStack_28 = param_4;
      uStack_24 = param_5;
      uStack_20 = param_6;
      uStack_1c = param_7;
      ExceptionList = &pvStack_10;
    }
  }
  puStack_14 = param_1;
  uStack_8._0_1_ = 1;
  cVar1 = FUN_00585a40(apuStack_34);
  if (cVar1 == '\0') {
    puStack_54 = (undefined4 *)0x0;
    if (apuStack_34[0] != (undefined4 *)0x0) {
      puStack_54 = apuStack_34[0];
      if (((uint)apuStack_34[0] & 1) == 0) {
        (**(code **)((uint)apuStack_34[0] & 0xfffffffe))(&uStack_2c,&uStack_4c,0);
      }
      else {
        uStack_4c = uStack_2c;
        uStack_48 = uStack_28;
        uStack_44 = uStack_24;
        uStack_40 = uStack_20;
        uStack_3c = uStack_1c;
      }
    }
    uStack_8._0_1_ = 2;
    puVar2 = (undefined4 *)FUN_01674e20(0x20);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar2;
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = 0;
      if (puStack_54 != (undefined4 *)0x0) {
        *puVar2 = puStack_54;
        if (((uint)puStack_54 & 1) == 0) {
          (**(code **)((uint)puStack_54 & 0xfffffffe))(&uStack_4c,puVar2 + 2,0);
        }
        else {
          puVar2[2] = uStack_4c;
          puVar2[3] = uStack_48;
          puVar2[4] = uStack_44;
          puVar2[5] = uStack_40;
          *(undefined8 *)(puVar2 + 6) = uStack_3c;
        }
      }
    }
    *param_8 = puVar2;
    uStack_8._0_1_ = 4;
    if (((puStack_54 != (undefined4 *)0x0) && (((uint)puStack_54 & 1) == 0)) &&
       (*(code **)((uint)puStack_54 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)((uint)puStack_54 & 0xfffffffe))(&uStack_4c,&uStack_4c,2);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (apuStack_34[0] != (undefined4 *)0x0) {
      if ((((uint)apuStack_34[0] & 1) == 0) &&
         (*(code **)((uint)apuStack_34[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)((uint)apuStack_34[0] & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
      }
      apuStack_34[0] = (undefined4 *)0x0;
    }
    uVar3 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (apuStack_34[0] != (undefined4 *)0x0) {
      if ((((uint)apuStack_34[0] & 1) == 0) &&
         (*(code **)((uint)apuStack_34[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)((uint)apuStack_34[0] & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
        puStack_14 = param_1;
      }
      apuStack_34[0] = (undefined4 *)0x0;
    }
    uVar3 = 0;
    param_1 = puStack_14;
  }
  uStack_8 = 7;
  if (((param_1 != (undefined4 *)0x0) && (((uint)param_1 & 1) == 0)) &&
     (*(code **)((uint)param_1 & 0xfffffffe) != (code *)0x0)) {
    param_8._3_1_ = uVar3;
    (**(code **)((uint)param_1 & 0xfffffffe))(&param_3,&param_3,2);
    ExceptionList = pvStack_10;
    return param_8._3_1_;
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 26921 ; VA 0x00bfb810 ; FUN_00bfb810 */

void __thiscall FUN_00bfb810(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 *puVar5;
  uint uVar6;
  
  puVar5 = param_2;
  puVar3 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar3) {
    *puVar3 = *param_2;
    puVar1 = puVar3 + 2;
    uVar4 = param_2[1];
    puVar2 = param_2 + 2;
    uVar6 = ~uVar4;
    if (-1 < (int)uVar4) {
      uVar6 = uVar4;
    }
    param_2 = puVar1;
    FUN_00bfbc40(uVar4,uVar6,&param_2,puVar2,puVar1,puVar1,0,0);
    uVar4 = puVar5[1];
    uVar6 = ~uVar4;
    if (-1 < (int)uVar4) {
      uVar6 = uVar4;
    }
    puVar3[1] = uVar6;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x24;
    return;
  }
  FUN_00bfb270(puVar3,param_2);
  return;
}



/* FUNCTION 26922 ; VA 0x00bfb890 ; FUN_00bfb890 */

undefined4 * FUN_00bfb890(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018041bc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_01960a64;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::bad_get::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_get>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_get>_>::
            vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_get>_>::
       vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26923 ; VA 0x00bfb970 ; FUN_00bfb970 */

undefined4 * FUN_00bfb970(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  param_1[3] = boost::exception::vftable;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0xffffffff;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::bad_get>::vftable;
  param_1[3] = boost::exception_detail::error_info_injector<class_boost::bad_get>::vftable;
  return param_1;
}



/* FUNCTION 26924 ; VA 0x00bfb9d0 ; _guard_check_icall */

void _guard_check_icall(void)

{
  return;
}



/* FUNCTION 26925 ; VA 0x00bfb9e0 ; FUN_00bfb9e0 */

void FUN_00bfb9e0(uint *param_1)

{
  uint *puVar1;
  uint *puVar2;
  uint uVar3;
  code *pcVar4;
  uint uVar5;
  int iVar6;
  undefined4 uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018041d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != (uint *)0x0) {
    puVar1 = (uint *)((int)&param_1 + 3);
    puVar2 = param_1 + 1;
    uVar3 = *param_1;
    uVar5 = ~uVar3;
    if (-1 < (int)uVar3) {
      uVar5 = uVar3;
    }
    ExceptionList = &pvStack_10;
    param_1 = puVar1;
    iVar6 = FUN_00bfbba0(uVar3,uVar5,&param_1,puVar2,puVar1,puVar1,0,0);
    if (iVar6 != 0) {
      ExceptionList = pvStack_10;
      return;
    }
  }
  uVar7 = FUN_00bfc160(0,0);
  uStack_8 = 0;
  FUN_00bfba70(uVar7);
  pcVar4 = (code *)swi(3);
  (*pcVar4)();
  return;
}



/* FUNCTION 26926 ; VA 0x00bfba70 ; FUN_00bfba70 */

void FUN_00bfba70(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_5c [44];
  undefined auStack_30 [32];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018041f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bfb970(auStack_30,param_1);
  uStack_8 = 0;
  FUN_00bfb890(auStack_5c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_5c,&DAT_01cb1f0c);
}



/* FUNCTION 26927 ; VA 0x00bfbac0 ; FUN_00bfbac0 */

int FUN_00bfbac0(undefined4 param_1,int param_2,undefined4 param_3,int param_4,undefined4 param_5,
                undefined4 param_6)

{
  uint uVar1;
  code *pcVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  char *extraout_ECX;
  int extraout_EDX;
  undefined4 unaff_EBX;
  
  switch(param_2) {
  case 0:
    uVar1 = *(uint *)(param_4 + 0x18);
    if (0xf < uVar1) {
      iVar4 = *(int *)(param_4 + 4);
      uVar5 = uVar1 + 1;
      iVar3 = iVar4;
      if (0xfff < uVar5) {
        iVar3 = *(int *)(iVar4 + -4);
        uVar5 = uVar1 + 0x24;
        if (0x1f < (iVar4 - iVar3) - 4U) goto LAB_00bfbb34;
      }
      param_2 = FUN_01674ea0(iVar3,uVar5);
    }
    *(undefined4 *)(param_4 + 0x14) = 0;
    *(undefined4 *)(param_4 + 0x18) = 0xf;
    *(undefined *)(param_4 + 4) = 0;
switchD_00bfbacb_caseD_1:
    return param_2;
  case 1:
    goto switchD_00bfbacb_caseD_1;
  case 2:
  case 3:
  case 4:
  case 5:
  case 6:
  case 7:
  case 8:
  case 9:
  case 10:
  case 0xb:
  case 0xc:
  case 0xd:
  case 0xe:
  case 0xf:
  case 0x10:
  case 0x11:
  case 0x12:
  case 0x13:
    _guard_check_icall(param_1,param_3,param_4,0,param_6,1);
    *(char *)(extraout_EDX + -0x44e6ff41) =
         *(char *)(extraout_EDX + -0x44e6ff41) >> ((byte)extraout_ECX & 0x1f);
    *extraout_ECX = *extraout_ECX + (char)((uint)unaff_EBX >> 8);
    *extraout_ECX = *extraout_ECX;
    *extraout_ECX = *extraout_ECX;
    *extraout_ECX = *extraout_ECX;
    *extraout_ECX = *extraout_ECX;
    *extraout_ECX = *extraout_ECX;
    switch(param_2) {
    case 0:
      return param_4;
    case 1:
      return 0;
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    case 8:
    case 9:
    case 10:
    case 0xb:
    case 0xc:
    case 0xd:
    case 0xe:
    case 0xf:
    case 0x10:
    case 0x11:
    case 0x12:
    case 0x13:
      break;
    default:
      _guard_check_icall(param_1,param_2,param_3,param_4,param_2,param_6,0,0);
    }
    _guard_check_icall(param_1,param_3,param_4,0,param_6,1);
    pcVar2 = (code *)swi(3);
    iVar4 = (*pcVar2)();
    return iVar4;
  default:
    _guard_check_icall(param_1,param_2,param_3,param_4,param_2,param_6,0,0);
LAB_00bfbb34:
                    /* WARNING: Subroutine does not return */
    FUN_017167a3();
  }
}



/* FUNCTION 26928 ; VA 0x00bfbba0 ; FUN_00bfbba0 */

undefined4
FUN_00bfbba0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  code *pcVar1;
  undefined4 uVar2;
  
  switch(param_2) {
  case 0:
    return param_4;
  case 1:
    return 0;
  case 2:
  case 3:
  case 4:
  case 5:
  case 6:
  case 7:
  case 8:
  case 9:
  case 10:
  case 0xb:
  case 0xc:
  case 0xd:
  case 0xe:
  case 0xf:
  case 0x10:
  case 0x11:
  case 0x12:
  case 0x13:
    break;
  default:
    _guard_check_icall(param_1,param_2,param_3,param_4,param_2,param_6,0,0);
  }
  _guard_check_icall(param_1,param_3,param_4,0,param_6,1);
  pcVar1 = (code *)swi(3);
  uVar2 = (*pcVar1)();
  return uVar2;
}



/* FUNCTION 26929 ; VA 0x00bfbc40 ; FUN_00bfbc40 */

/* WARNING: This function may have set the stack pointer */

void FUN_00bfbc40(undefined4 param_1,undefined4 param_2,undefined4 *param_3,undefined *param_4,
                 undefined4 param_5,undefined4 param_6)

{
  code *pcVar1;
  char extraout_DL;
  int unaff_EBX;
  
  switch(param_2) {
  case 0:
    *(undefined *)*param_3 = *param_4;
    FUN_0054ef60(param_4 + 4);
    return;
  case 1:
    *(undefined *)*param_3 = *param_4;
    return;
  case 2:
  case 3:
  case 4:
  case 5:
  case 6:
  case 7:
  case 8:
  case 9:
  case 10:
  case 0xb:
  case 0xc:
  case 0xd:
  case 0xe:
  case 0xf:
  case 0x10:
  case 0x11:
  case 0x12:
  case 0x13:
    break;
  default:
    _guard_check_icall(param_1,param_2,param_3,param_4,param_2,param_6,0,0);
  }
  _guard_check_icall(param_1,param_3,param_4,0,param_6,1);
  *(char *)(unaff_EBX + -0x6cff4044) = *(char *)(unaff_EBX + -0x6cff4044) + extraout_DL;
  *(char *)(unaff_EBX + -0x6cff4044) = *(char *)(unaff_EBX + -0x6cff4044) + extraout_DL;
  *(char *)(unaff_EBX + -0x6cff4044) = *(char *)(unaff_EBX + -0x6cff4044) + extraout_DL;
  *(char *)(unaff_EBX + -0x6cff4044) = *(char *)(unaff_EBX + -0x6cff4044) + extraout_DL;
  *(char *)(unaff_EBX + -0x33ff4044) = *(char *)(unaff_EBX + -0x33ff4044) + extraout_DL;
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 26930 ; VA 0x00bfbd00 ; _guard_check_icall */

void _guard_check_icall(void)

{
  return;
}



/* FUNCTION 26931 ; VA 0x00bfbd10 ; FUN_00bfbd10 */

uint * __thiscall FUN_00bfbd10(uint *param_1,uint *param_2)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804218;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uVar2 = *param_2;
  if (uVar2 != 0) {
    *param_1 = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
    }
    else {
      uVar2 = param_2[3];
      uVar3 = param_2[4];
      uVar4 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar2;
      param_1[4] = uVar3;
      param_1[5] = uVar4;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
    }
  }
  param_1[8] = 0;
  uVar2 = param_2[8];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[8] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 10,param_1 + 10,0);
    }
    else {
      uVar2 = param_2[0xb];
      uVar3 = param_2[0xc];
      uVar4 = param_2[0xd];
      param_1[10] = param_2[10];
      param_1[0xb] = uVar2;
      param_1[0xc] = uVar3;
      param_1[0xd] = uVar4;
      *(undefined8 *)(param_1 + 0xe) = *(undefined8 *)(param_2 + 0xe);
    }
  }
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  if (param_2[0x11] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0x11] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x10] = param_2[0x10];
  param_1[0x11] = param_2[0x11];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26932 ; VA 0x00bfbdf0 ; FUN_00bfbdf0 */

undefined4 * __thiscall FUN_00bfbdf0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  uint uVar3;
  undefined4 *puVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar4 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180423b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  puVar1 = param_1 + 6;
  uVar3 = param_2[5];
  puVar2 = param_2 + 6;
  uVar5 = ~uVar3;
  if (-1 < (int)uVar3) {
    uVar5 = uVar3;
  }
  param_2 = puVar1;
  FUN_00bfbc40(uVar3,uVar5,&param_2,puVar2,puVar1,puVar1,0,0);
  uVar3 = puVar4[5];
  uVar5 = ~uVar3;
  if (-1 < (int)uVar3) {
    uVar5 = uVar3;
  }
  param_1[5] = uVar5;
  param_1[0xd] = puVar4[0xd];
  param_2 = param_1 + 0xf;
  uVar3 = puVar4[0xe];
  uStack_8 = 0;
  uVar5 = ~uVar3;
  if (-1 < (int)uVar3) {
    uVar5 = uVar3;
  }
  FUN_00bfbc40(uVar3,uVar5,&param_2,puVar4 + 0xf,param_2,param_2,0,0);
  uVar3 = puVar4[0xe];
  uVar5 = ~uVar3;
  if (-1 < (int)uVar3) {
    uVar5 = uVar3;
  }
  param_1[0xe] = uVar5;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26933 ; VA 0x00bfbed0 ; FUN_00bfbed0 */

undefined4 * __thiscall FUN_00bfbed0(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804274;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_01960a64;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::bad_get::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_get>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_get>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_get>_>::
       vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26934 ; VA 0x00bfbfb0 ; FUN_00bfbfb0 */

undefined4 * __thiscall FUN_00bfbfb0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804288;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::bad_get::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::error_info_injector<class_boost::bad_get>::vftable;
  param_1[3] = boost::exception_detail::error_info_injector<class_boost::bad_get>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26935 ; VA 0x00bfc050 ; FUN_00bfc050 */

undefined4 * __thiscall FUN_00bfc050(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  uint uVar3;
  undefined4 *puVar4;
  uint uVar5;
  
  puVar4 = param_2;
  *param_1 = *param_2;
  puVar1 = param_1 + 2;
  uVar3 = param_2[1];
  puVar2 = param_2 + 2;
  uVar5 = ~uVar3;
  if (-1 < (int)uVar3) {
    uVar5 = uVar3;
  }
  param_2 = puVar1;
  FUN_00bfbc40(uVar3,uVar5,&param_2,puVar2,puVar1,puVar1,0,0);
  uVar3 = puVar4[1];
  uVar5 = ~uVar3;
  if (-1 < (int)uVar3) {
    uVar5 = uVar3;
  }
  param_1[1] = uVar5;
  return param_1;
}



/* FUNCTION 26936 ; VA 0x00bfc0b0 ; FUN_00bfc0b0 */

undefined4 * __fastcall FUN_00bfc0b0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018042a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0089a650("PermissionsService");
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::PermissionsService,class_RBX::ServiceInstance>::vftable;
  uVar1 = FUN_00bfb120();
  param_1[3] = uVar1;
  *param_1 = RBX::PermissionsService::vftable;
  *(undefined2 *)(param_1 + 0x16) = 0x101;
  *(undefined *)((int)param_1 + 0x5a) = 1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26937 ; VA 0x00bfc120 ; FUN_00bfc120 */

undefined4 * __thiscall FUN_00bfc120(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::bad_get::vftable;
  return param_1;
}



/* FUNCTION 26938 ; VA 0x00bfc160 ; FUN_00bfc160 */

undefined4 * __fastcall FUN_00bfc160(undefined4 *param_1)

{
  *(undefined8 *)(param_1 + 1) = 0;
  *param_1 = boost::bad_get::vftable;
  return param_1;
}



/* FUNCTION 26939 ; VA 0x00bfc180 ; FUN_00bfc180 */

void __fastcall FUN_00bfc180(int param_1)

{
  uint uVar1;
  uint uVar2;
  undefined4 uStack_9;
  undefined uStack_5;
  
  uVar1 = *(uint *)(param_1 + 0x38);
  uVar2 = ~uVar1;
  if (-1 < (int)uVar1) {
    uVar2 = uVar1;
  }
  FUN_00bfbac0(uVar1,uVar2,&uStack_5,param_1 + 0x3c);
  uVar1 = *(uint *)(param_1 + 0x14);
  uVar2 = ~uVar1;
  if (-1 < (int)uVar1) {
    uVar2 = uVar1;
  }
  FUN_00bfbac0(uVar1,uVar2,&uStack_5,param_1 + 0x18,uStack_9,uStack_9,0,0);
  return;
}



/* FUNCTION 26940 ; VA 0x00bfc1e0 ; FUN_00bfc1e0 */

void __fastcall FUN_00bfc1e0(undefined4 *param_1)

{
  FUN_00bfb220(*param_1,param_1[1],param_1[2]);
  return;
}



/* FUNCTION 26941 ; VA 0x00bfc200 ; FUN_00bfc200 */

void __fastcall FUN_00bfc200(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::bad_get>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26942 ; VA 0x00bfc270 ; FUN_00bfc270 */

void __fastcall FUN_00bfc270(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_00bfb220(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x24) * 0x24;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 26943 ; VA 0x00bfc2f0 ; FUN_00bfc2f0 */

void __fastcall FUN_00bfc2f0(int param_1)

{
  uint uVar1;
  uint uVar2;
  undefined uStack_5;
  
  uVar1 = *(uint *)(param_1 + 4);
  uVar2 = ~uVar1;
  if (-1 < (int)uVar1) {
    uVar2 = uVar1;
  }
  FUN_00bfbac0(uVar1,uVar2,&uStack_5,param_1 + 8);
  return;
}



/* FUNCTION 26944 ; VA 0x00bfc330 ; FUN_00bfc330 */

int __thiscall FUN_00bfc330(uint *param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  undefined uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined auStack_168 [212];
  uint auStack_94 [4];
  undefined4 uStack_84;
  uint uStack_80;
  uint auStack_7c [4];
  undefined4 uStack_6c;
  uint uStack_68;
  uint auStack_64 [4];
  undefined4 uStack_54;
  uint uStack_50;
  uint auStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  undefined auStack_34 [4];
  int *piStack_30;
  uint *puStack_2c;
  int iStack_28;
  int iStack_24;
  uint uStack_20;
  int *piStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_01804306;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffe84;
  uVar6 = param_1[0x11];
  uStack_20 = 0;
  piStack_1c = (int *)0x0;
  ExceptionList = &pvStack_10;
  if (uVar6 != 0) {
    piVar9 = (int *)(uVar6 + 4);
    iVar3 = *(int *)(uVar6 + 4);
    ExceptionList = &pvStack_10;
    while (iVar3 != 0) {
      LOCK();
      iVar1 = *piVar9;
      if (iVar3 == iVar1) {
        *piVar9 = iVar3 + 1;
        iVar1 = iVar3;
      }
      UNLOCK();
      if (iVar1 == iVar3) {
        uStack_20 = param_1[0x10];
        piStack_1c = (int *)param_1[0x11];
        break;
      }
      iVar3 = *piVar9;
    }
  }
  piVar9 = piStack_1c;
  uStack_8 = 2;
  uStack_7 = 0;
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  puStack_2c = param_1;
  FUN_005542c0("Creator",7);
  uStack_8 = 3;
  FUN_0091d440(auStack_4c);
  FUN_00636000(auStack_34);
  uStack_8 = 5;
  uVar10 = uStack_8;
  uStack_8 = 5;
  if (0xf < uStack_38) {
    uVar7 = uStack_38 + 1;
    uVar6 = auStack_4c[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_4c[0] - 4);
      uVar7 = uStack_38 + 0x24;
      if (0x1f < (auStack_4c[0] - uVar6) - 4) {
        uStack_8 = uVar10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  uStack_54 = 0;
  uStack_50 = 0xf;
  auStack_64[0] = auStack_64[0] & 0xffffff00;
  FUN_005542c0("CreatorTargetId",0xf);
  uStack_8 = 6;
  piVar2 = (int *)FUN_0091d440(auStack_64);
  iStack_18 = *piVar2;
  iVar3 = FUN_0088da50();
  if (iStack_18 == iVar3) {
    iStack_18 = *piVar2;
    iVar3 = FUN_0088da50();
    if (iStack_18 != iVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar4 = piVar2 + 2;
    if (piVar2[1] == 0) {
      piVar4 = (int *)0x0;
    }
    iStack_24 = *piVar4;
    iStack_18 = piVar4[1];
  }
  else {
    if ((undefined4 *)piVar2[1] != (undefined4 *)0x0) {
      (**(code **)piVar2[1])(piVar2 + 2,auStack_168);
    }
    iVar3 = piVar2[1];
    uStack_8 = 7;
    piVar2 = (int *)FUN_0088baa0();
    iStack_24 = *piVar2;
    iStack_18 = piVar2[1];
    uStack_8 = 8;
    if (iVar3 != 0) {
      (**(code **)(iVar3 + 8))(auStack_168);
    }
  }
  uStack_8 = 5;
  uVar10 = uStack_8;
  uStack_8 = 5;
  if (0xf < uStack_50) {
    uVar7 = uStack_50 + 1;
    uVar6 = auStack_64[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_64[0] - 4);
      uVar7 = uStack_50 + 0x24;
      if (0x1f < (auStack_64[0] - uVar6) - 4) {
        uStack_8 = uVar10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_6c = 0;
  uStack_68 = 0xf;
  auStack_7c[0] = auStack_7c[0] & 0xffffff00;
  FUN_005542c0("CreatorType",0xb);
  _uStack_8 = CONCAT31(uStack_7,9);
  FUN_0091d440(auStack_7c);
  puVar5 = (undefined4 *)FUN_00563690(auStack_94);
  uVar12 = puVar5[4];
  if (0xf < (uint)puVar5[5]) {
    puVar5 = (undefined4 *)*puVar5;
  }
  uVar11 = 0xbfc59c;
  uVar6 = FUN_0055c360(puVar5,uVar12,&DAT_0192a9d8,4);
  if (0xf < uStack_80) {
    uVar8 = uStack_80 + 1;
    uVar7 = auStack_94[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_94[0] - 4);
      uVar8 = uStack_80 + 0x24;
      if (0x1f < (auStack_94[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uVar12 = 0xbfc5d9;
    FUN_01674ea0(uVar7,uVar8);
  }
  uStack_84 = 0;
  uStack_80 = 0xf;
  auStack_94[0] = auStack_94[0] & 0xffffff00;
  uStack_8 = 5;
  if (0xf < uStack_68) {
    uVar8 = uStack_68 + 1;
    uVar7 = auStack_7c[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_7c[0] - 4);
      uVar8 = uStack_68 + 0x24;
      if (0x1f < (auStack_7c[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uVar12 = 0xbfc626;
    FUN_01674ea0(uVar7,uVar8);
  }
  piVar2 = *(int **)(uStack_20 + 0x454);
  iStack_28 = piVar2[1] - (int)piVar2;
  if (((iStack_24 == *piVar2 - (int)piVar2) && (iStack_18 == iStack_28)) &&
     ((uVar6 & 0xff ^ 1) == *(uint *)(uStack_20 + 0x458))) {
    if (*param_1 == 0) {
      uVar12 = FUN_0054fda0();
      _uStack_8 = CONCAT31(uStack_7,10);
                    /* WARNING: Subroutine does not return */
      FUN_0054e5e0(uVar12);
    }
    iVar3 = (**(code **)((*param_1 & 0xfffffffe) + 4))(param_1 + 2);
  }
  else {
    uVar13 = 0;
    uVar14 = 0xf;
    uVar10 = 0;
    FUN_005542c0("Can not teleport to place created by third party with teleport protections enabled on this universe."
                 ,100);
    iVar3 = FUN_005e65e0(uVar10,uVar11,puVar5,uVar12,uVar13,uVar14);
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_30 + 1;
    iVar1 = *piVar2;
    iVar3 = *piVar2;
    *piVar2 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar2 = piStack_30 + 2;
      iVar1 = *piVar2;
      iVar3 = *piVar2;
      *piVar2 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        (**(code **)(*piStack_30 + 4))();
        iVar3 = FUN_00bfc6ff();
        return iVar3;
      }
    }
  }
  if (piVar9 != (int *)0x0) {
    LOCK();
    piVar2 = piVar9 + 1;
    iVar1 = *piVar2;
    iVar3 = *piVar2;
    *piVar2 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*piVar9)();
      LOCK();
      piVar2 = piVar9 + 2;
      iVar1 = *piVar2;
      iVar3 = *piVar2;
      *piVar2 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar3 = (**(code **)(*piVar9 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar9 = param_3 + 1;
    iVar1 = *piVar9;
    iVar3 = *piVar9;
    *piVar9 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar9 = param_3 + 2;
      iVar1 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 26945 ; VA 0x00bfc6c6 ; Catch@00bfc6c6 */

undefined * Catch_00bfc6c6(void)

{
  undefined uVar1;
  
  uVar1 = 0;
  FUN_005542c0("Third party teleport protection was unable to confirm safety of teleportation place."
               ,0x54);
  FUN_005e65e0(uVar1);
  return &DAT_00bfc6f9;
}



/* FUNCTION 26946 ; VA 0x00bfc6ff ; FUN_00bfc6ff */

void FUN_00bfc6ff(void)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int unaff_EBP;
  int unaff_ESI;
  int *unaff_EDI;
  
  if (unaff_EDI != (int *)0x0) {
    LOCK();
    iVar3 = unaff_EDI[1] + unaff_ESI;
    unaff_EDI[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*unaff_EDI)();
      LOCK();
      iVar3 = unaff_EDI[2] + unaff_ESI;
      unaff_EDI[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*unaff_EDI + 4))();
      }
    }
  }
  piVar2 = *(int **)(unaff_EBP + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + unaff_ESI;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + unaff_ESI;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 26947 ; VA 0x00bfc790 ; FUN_00bfc790 */

void __fastcall FUN_00bfc790(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_get>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_get>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_get>_>::
       vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::bad_get>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26948 ; VA 0x00bfc828 ; FUN_00bfc828 */

void FUN_00bfc828(void)

{
  FUN_00bfc850();
  return;
}



/* FUNCTION 26949 ; VA 0x00bfc833 ; FUN_00bfc833 */

void FUN_00bfc833(void)

{
  FUN_00bfc850();
  return;
}



/* FUNCTION 26950 ; VA 0x00bfc83b ; FUN_00bfc83b */

void FUN_00bfc83b(void)

{
  FUN_00bfc880();
  return;
}



/* FUNCTION 26951 ; VA 0x00bfc850 ; FUN_00bfc850 */

undefined4 __thiscall FUN_00bfc850(undefined4 param_1,byte param_2)

{
  FUN_00bfc790();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 26952 ; VA 0x00bfc880 ; FUN_00bfc880 */

undefined4 * __thiscall FUN_00bfc880(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::bad_get>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26953 ; VA 0x00bfc900 ; FUN_00bfc900 */

undefined4 __thiscall FUN_00bfc900(undefined4 param_1,byte param_2)

{
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x5c);
  }
  return param_1;
}



/* FUNCTION 26954 ; VA 0x00bfc930 ; FUN_00bfc930 */

void __thiscall FUN_00bfc930(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_00bfb220(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x24) * 0x24;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  *param_1 = param_2;
  param_1[1] = param_2 + param_3 * 0x24;
  param_1[2] = param_2 + param_4 * 0x24;
  return;
}



/* FUNCTION 26955 ; VA 0x00bfc9c0 ; FUN_00bfc9c0 */

void __thiscall FUN_00bfc9c0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00bfb220(param_2,param_3,param_1);
  return;
}



/* FUNCTION 26956 ; VA 0x00bfc9e0 ; FUN_00bfc9e0 */

void __thiscall FUN_00bfc9e0(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804400;
  pvStack_10 = ExceptionList;
  iVar1 = param_1[1];
  iVar2 = *param_1;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00a203e0(param_2);
  uStack_8 = 0;
  FUN_00bfcb40(*param_1,param_1[1],uVar3);
  FUN_00bfc930(uVar3,(iVar1 - iVar2) / 0x24,param_2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26957 ; VA 0x00bfca5c ; Catch_All@00bfca5c */

void Catch_All_00bfca5c(void)

{
  int unaff_EBP;
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar2 = *(undefined4 *)(unaff_EBP + 8);
  uVar1 = *(undefined4 *)(unaff_EBP + -0x14);
  FUN_0054eb90(uVar1,uVar2);
  FUN_00781060(uVar1,uVar2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 26958 ; VA 0x00bfca80 ; FUN_00bfca80 */

uint * __thiscall FUN_00bfca80(undefined4 param_1,uint *param_2,uint *param_3,uint *param_4)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint *puVar4;
  uint *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01804418;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puVar4 = param_4;
  ExceptionList = &pvStack_10;
  if (param_2 != param_3) {
    puVar5 = param_2 + 1;
    ExceptionList = &pvStack_10;
    do {
      *puVar4 = puVar5[-1];
      param_4 = puVar4 + 2;
      uVar2 = *puVar5;
      uVar3 = ~uVar2;
      if (-1 < (int)uVar2) {
        uVar3 = uVar2;
      }
      FUN_00bfbc40(uVar2,uVar3,&param_4,puVar5 + 1,param_4,param_4,0,0);
      uVar2 = *puVar5;
      uVar3 = ~uVar2;
      if (-1 < (int)uVar2) {
        uVar3 = uVar2;
      }
      puVar4[1] = uVar3;
      puVar4 = puVar4 + 9;
      puVar1 = puVar5 + 8;
      puVar5 = puVar5 + 9;
    } while (puVar1 != param_3);
  }
  FUN_00bfb220(puVar4,puVar4,param_1);
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 26959 ; VA 0x00bfcb40 ; FUN_00bfcb40 */

void __thiscall FUN_00bfcb40(undefined4 param_1,uint *param_2,uint *param_3,uint *param_4)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint *puVar4;
  uint *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01804418;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puVar4 = param_4;
  ExceptionList = &pvStack_10;
  if (param_2 != param_3) {
    puVar5 = param_2 + 1;
    ExceptionList = &pvStack_10;
    do {
      *puVar4 = puVar5[-1];
      param_4 = puVar4 + 2;
      uVar2 = *puVar5;
      uVar3 = ~uVar2;
      if (-1 < (int)uVar2) {
        uVar3 = uVar2;
      }
      FUN_00bfbc40(uVar2,uVar3,&param_4,puVar5 + 1,param_4,param_4,0,0);
      uVar2 = *puVar5;
      uVar3 = ~uVar2;
      if (-1 < (int)uVar2) {
        uVar3 = uVar2;
      }
      puVar4[1] = uVar3;
      puVar4 = puVar4 + 9;
      puVar1 = puVar5 + 8;
      puVar5 = puVar5 + 9;
    } while (puVar1 != param_3);
  }
  FUN_00bfb220(puVar4,puVar4,param_1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26960 ; VA 0x00bfcc00 ; FUN_00bfcc00 */

void FUN_00bfcc00(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804438;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00bfe030(auStack_1c,param_1,param_2);
  uStack_8 = 0;
  FUN_00bfb810(param_3);
  FUN_00bfec40(param_1,param_2,auStack_1c);
  FUN_00bfc270();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26961 ; VA 0x00bfcc70 ; FUN_00bfcc70 */

void __thiscall
FUN_00bfcc70(undefined *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10,uint *param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
            undefined8 param_17)

{
  undefined *puVar1;
  undefined *puVar2;
  uint **ppuVar3;
  char cVar4;
  int iVar5;
  int *piVar6;
  int iVar7;
  undefined **ppuVar8;
  uint *puStack_298;
  int iStack_294;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined8 uStack_280;
  undefined4 uStack_278;
  undefined auStack_274 [16];
  undefined4 uStack_264;
  undefined4 *puStack_260;
  undefined4 *puStack_25c;
  undefined4 *puStack_258;
  uint auStack_24c [18];
  uint auStack_204 [18];
  uint auStack_1bc [18];
  uint auStack_174 [18];
  uint auStack_12c [18];
  uint auStack_e4 [18];
  uint auStack_9c [2];
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined8 uStack_84;
  uint *puStack_7c;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined8 uStack_64;
  undefined4 uStack_5c;
  int *piStack_58;
  undefined auStack_50 [4];
  int *piStack_4c;
  undefined *puStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  uint *puStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined *puStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018044e7;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  puStack_1c = param_1;
  if (param_1[0x5a] == '\0') {
    puVar1 = *(undefined **)(param_1 + 0x34);
    ExceptionList = &pvStack_10;
    if ((puVar1 != (undefined *)0x0) &&
       (param_1 = puVar1, ExceptionList = &pvStack_10, *(int *)(puVar1 + 0x34) != 0)) {
      puStack_258 = (undefined4 *)0xbfccd4;
      ExceptionList = &pvStack_10;
      param_1 = (undefined *)FUN_005c8ac0();
    }
    if (param_1 != (undefined *)0x0) {
      iVar7 = *(int *)(param_1 + 0xc);
      puStack_258 = (undefined4 *)0xbfcce6;
      iVar5 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
          (uint)*(ushort *)(iVar5 + 0x1da)) {
        puStack_258 = (undefined4 *)&LAB_00670c50;
        puStack_25c = (undefined4 *)&DAT_01eadd74;
        puStack_260 = (undefined4 *)0xbfcd14;
        FUN_005789c0();
        puStack_258 = (undefined4 *)0xbfcd1c;
        puStack_258 = (undefined4 *)FUN_00675b30();
        puStack_25c = (undefined4 *)0xbfcd24;
        piStack_18 = (int *)FUN_008aa140();
        if (*piStack_18 == 0) {
          puStack_258 = (undefined4 *)0xbfcd31;
          puStack_258 = (undefined4 *)FUN_00b12140();
          puStack_25c = (undefined4 *)auStack_50;
          puStack_260 = (undefined4 *)0xbfcd3d;
          piVar6 = (int *)FUN_008a9ba0();
          iVar7 = *piVar6;
          iVar5 = piVar6[1];
          *piVar6 = 0;
          piVar6[1] = 0;
          *piStack_18 = iVar7;
          piVar6 = (int *)piStack_18[1];
          piStack_18[1] = iVar5;
          if (piVar6 != (int *)0x0) {
            LOCK();
            iVar7 = piVar6[1] + -1;
            piVar6[1] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              puStack_258 = (undefined4 *)0xbfcd70;
              (**(code **)*piVar6)();
              LOCK();
              iVar7 = piVar6[2] + -1;
              piVar6[2] = iVar7;
              UNLOCK();
              if (iVar7 == 0) {
                puStack_258 = (undefined4 *)0xbfcd80;
                (**(code **)(*piVar6 + 4))();
              }
            }
          }
          if (piStack_4c != (int *)0x0) {
            LOCK();
            iVar7 = piStack_4c[1] + -1;
            piStack_4c[1] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              puStack_258 = (undefined4 *)0xbfcd96;
              (**(code **)*piStack_4c)();
              LOCK();
              iVar7 = piStack_4c[2] + -1;
              piStack_4c[2] = iVar7;
              UNLOCK();
              if (iVar7 == 0) {
                puStack_258 = (undefined4 *)0xbfcda6;
                (**(code **)(*piStack_4c + 4))();
              }
            }
          }
        }
      }
    }
    puStack_258 = (undefined4 *)puStack_1c;
    puStack_25c = (undefined4 *)0xbfcdb7;
    puStack_25c = (undefined4 *)FUN_008f7870();
    puStack_260 = &uStack_44;
    uStack_264 = 0xbfcdc1;
    FUN_005e5de0();
    uStack_8._0_1_ = 3;
    auStack_9c[0] = 0;
    if (param_4 != 0) {
      auStack_9c[0] = param_4;
      if ((param_4 & 1) == 0) {
        puStack_25c = &uStack_94;
        puStack_258 = (undefined4 *)0x0;
        puStack_260 = &param_6;
        uStack_264 = 0xbfce0e;
        (**(code **)(param_4 & 0xfffffffe))();
      }
      else {
        uStack_94 = param_6;
        uStack_90 = param_7;
        uStack_8c = param_8;
        uStack_88 = param_9;
        uStack_84 = param_10;
      }
    }
    uStack_8._0_1_ = 4;
    puStack_7c = (uint *)0x0;
    if (param_11 != (uint *)0x0) {
      puStack_7c = param_11;
      if (((uint)param_11 & 1) == 0) {
        puStack_258 = (undefined4 *)0x0;
        puStack_25c = &uStack_74;
        puStack_260 = &param_13;
        uStack_264 = 0xbfce50;
        (**(code **)((uint)param_11 & 0xfffffffe))();
      }
      else {
        uStack_74 = param_13;
        uStack_70 = param_14;
        uStack_6c = param_15;
        uStack_68 = param_16;
        uStack_64 = param_17;
      }
    }
    if (piStack_40 != (int *)0x0) {
      LOCK();
      piStack_40[2] = piStack_40[2] + 1;
      UNLOCK();
    }
    uStack_5c = uStack_44;
    piStack_58 = piStack_40;
    uStack_8._0_1_ = 5;
    puStack_3c = (uint *)0x0;
    if (param_11 != (uint *)0x0) {
      puStack_3c = param_11;
      if (((uint)param_11 & 1) == 0) {
        puStack_258 = (undefined4 *)0x0;
        puStack_25c = &uStack_34;
        puStack_260 = &param_13;
        uStack_264 = 0xbfceb7;
        (**(code **)((uint)param_11 & 0xfffffffe))();
      }
      else {
        uStack_34 = param_13;
        uStack_30 = param_14;
        uStack_2c = param_15;
        uStack_28 = param_16;
        uStack_24 = param_17;
      }
    }
    puStack_48 = auStack_274;
    puStack_1c = auStack_274;
    uStack_8._0_1_ = 6;
    uStack_278 = 0;
    piStack_18 = (int *)&puStack_298;
    puStack_298 = (uint *)0x0;
    puVar1 = auStack_274;
    puVar2 = auStack_274;
    ppuVar3 = &puStack_298;
    if (puStack_3c != (uint *)0x0) {
      puStack_298 = puStack_3c;
      if (((uint)puStack_3c & 1) == 0) {
        (**(code **)((uint)puStack_3c & 0xfffffffe))(&uStack_34,&uStack_290,0);
        puVar1 = puStack_48;
        puVar2 = puStack_1c;
        ppuVar3 = (uint **)piStack_18;
      }
      else {
        uStack_290 = uStack_34;
        uStack_28c = uStack_30;
        uStack_288 = uStack_2c;
        uStack_284 = uStack_28;
        uStack_280 = uStack_24;
        puVar1 = auStack_274;
        puVar2 = auStack_274;
        ppuVar3 = &puStack_298;
      }
    }
    piStack_18 = (int *)ppuVar3;
    puStack_1c = puVar2;
    puStack_48 = puVar1;
    FUN_00bfaf70();
    piStack_18 = &iStack_294;
    uStack_8._0_1_ = 7;
    puStack_298 = auStack_9c;
    FUN_00bfbd10();
    puStack_298 = auStack_24c;
    uStack_8._0_1_ = 8;
    FUN_00bfbd10();
    uStack_8._0_1_ = 9;
    *piStack_18 = 0;
    puStack_298 = auStack_204;
    FUN_00bfbd10();
    puStack_298 = auStack_1bc;
    uStack_8._0_1_ = 10;
    FUN_00bfbd10();
    puStack_298 = auStack_174;
    uStack_8._0_1_ = 0xb;
    FUN_00bfbd10();
    puStack_298 = auStack_e4;
    uStack_8._0_1_ = 0xc;
    cVar4 = FUN_00585a40();
    if (cVar4 == '\0') {
      puStack_298 = auStack_e4;
      FUN_00bfbd10();
      puStack_298 = (uint *)0x48;
      uStack_8._0_1_ = 0xd;
      puStack_1c = (undefined *)FUN_01674e20();
      uStack_8._0_1_ = 0xe;
      if (puStack_1c == (undefined *)0x0) {
        iVar7 = 0;
      }
      else {
        puStack_298 = auStack_12c;
        iVar7 = FUN_00bfbd10();
      }
      piStack_18[2] = iVar7;
      puStack_298 = (uint *)0xbfcff7;
      FUN_005e6080();
      puStack_298 = (uint *)0xbfd002;
      FUN_005e6080();
      cStack_11 = '\x01';
    }
    else {
      puStack_298 = (uint *)0xbfd013;
      FUN_005e6080();
      cStack_11 = '\0';
    }
    puStack_298 = (uint *)0xbfd022;
    FUN_005e6080();
    ppuVar8 = &PTR_FUN_01960a04;
    if (cStack_11 == '\0') {
      ppuVar8 = (undefined **)0x0;
    }
    *piStack_18 = (int)ppuVar8;
    puStack_298 = (uint *)0xbfd03f;
    FUN_005e6080();
    puStack_298 = (uint *)0xbfd04a;
    FUN_005e6080();
    uStack_8._0_1_ = 7;
    puStack_298 = (uint *)0xbfd059;
    FUN_005e6080();
    puStack_298 = (uint *)0x0;
    uStack_8._0_1_ = 6;
    FUN_00b265e0(param_2,param_3);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
    if (puStack_3c != (uint *)0x0) {
      if ((((uint)puStack_3c & 1) == 0) &&
         (*(code **)((uint)puStack_3c & 0xfffffffe) != (code *)0x0)) {
        puStack_260 = &uStack_34;
        puStack_258 = (undefined4 *)0x2;
        uStack_264 = 0xbfd091;
        puStack_25c = puStack_260;
        (**(code **)((uint)puStack_3c & 0xfffffffe))();
      }
      puStack_3c = (uint *)0x0;
    }
    puStack_258 = (undefined4 *)0xbfd0a6;
    FUN_005e6080();
    if (piStack_40 != (int *)0x0) {
      LOCK();
      piVar6 = piStack_40 + 2;
      iVar7 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        puStack_258 = (undefined4 *)0xbfd0bc;
        (**(code **)(*piStack_40 + 4))();
      }
    }
  }
  else {
    if (param_4 == 0) {
      puStack_258 = (undefined4 *)0xbfd128;
      ExceptionList = &pvStack_10;
      puStack_258 = (undefined4 *)FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
      puStack_25c = (undefined4 *)&UNK_00bfd132;
      FUN_0054e5e0();
    }
    puStack_258 = &param_6;
    puStack_25c = (undefined4 *)0xbfccb9;
    ExceptionList = &pvStack_10;
    (**(code **)((param_4 & 0xfffffffe) + 4))();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_260 = &param_6;
    puStack_258 = (undefined4 *)0x2;
    uStack_264 = 0xbfd0dd;
    puStack_25c = puStack_260;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_8 = 0x11;
  if (((param_11 != (uint *)0x0) && (((uint)param_11 & 1) == 0)) &&
     (*(code **)((uint)param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_260 = &param_13;
    puStack_258 = (undefined4 *)0x2;
    uStack_264 = 0xbfd10b;
    puStack_25c = puStack_260;
    (**(code **)((uint)param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26962 ; VA 0x00bfd140 ; FUN_00bfd140 */

void FUN_00bfd140(void)

{
  char *pcVar1;
  char *pcVar2;
  char cVar3;
  int *piVar4;
  uint uVar5;
  undefined *puVar6;
  undefined4 *apuStack_170 [2];
  char *pcStack_168;
  char *pcStack_164;
  undefined4 uStack_160;
  uint uStack_15c;
  undefined *puStack_158;
  undefined4 uStack_154;
  undefined *puStack_150;
  char *pcStack_14c;
  char *pcStack_148;
  char *pcStack_144;
  char *pcStack_140;
  char *pcStack_13c;
  undefined *puStack_138;
  undefined4 auStack_134 [7];
  undefined4 uStack_118;
  undefined auStack_114 [24];
  undefined4 uStack_fc;
  int *piStack_f8;
  undefined *apuStack_f4 [2];
  char *pcStack_ec;
  char *pcStack_e8;
  undefined4 uStack_dc;
  int *piStack_d8;
  undefined *puStack_d4;
  undefined *puStack_d0;
  char *pcStack_cc;
  char *pcStack_c8;
  undefined4 *puStack_c4;
  char *pcStack_c0;
  char *pcStack_bc;
  char *pcStack_b8;
  undefined auStack_a8 [24];
  undefined4 uStack_90;
  uint uStack_8c;
  undefined auStack_88 [28];
  undefined auStack_6c [8];
  undefined *puStack_64;
  undefined *puStack_60;
  undefined *puStack_5c;
  undefined4 uStack_58;
  undefined *puStack_54;
  undefined auStack_50 [28];
  undefined *puStack_34;
  char *pcStack_30;
  char *pcStack_2c;
  code *pcStack_28;
  int *piStack_24;
  undefined uStack_1d;
  char *pcStack_1c;
  char *pcStack_18;
  undefined **ppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804557;
  pvStack_10 = ExceptionList;
  pcStack_b8 = (char *)0xbfd16b;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01255560();
  if (*piVar4 == 5) {
    pcVar1 = (char *)piVar4[3];
    pcVar2 = (char *)piVar4[2];
    if ((-1 < (int)pcVar1) && ((0 < (int)pcVar1 || (pcVar2 != (char *)0x0)))) {
      uStack_58 = 1;
      auStack_50[0] = 1;
      puStack_54 = (undefined *)0x1;
      pcStack_b8 = (char *)&uStack_58;
      uStack_8 = 0;
      puStack_c4 = (undefined4 *)0xbfd1a6;
      pcStack_c0 = pcVar2;
      pcStack_bc = pcVar1;
      cVar3 = FUN_00bfd480();
      if (cVar3 == '\0') {
        uStack_90 = 1;
        auStack_88[0] = 0;
        uStack_8c = 1;
        pcStack_b8 = auStack_6c;
        uStack_8._0_1_ = 1;
        pcStack_bc = (char *)0xbfd20a;
        piVar4 = (int *)FUN_00eb65e0();
        piStack_24 = *(int **)(*piVar4 + 0x58);
        pcStack_b8 = (char *)0xbfd21d;
        FUN_00550b30();
        pcStack_b8 = (char *)&uStack_90;
        puStack_c4 = (undefined4 *)0xbfd22d;
        pcStack_c0 = pcVar2;
        pcStack_bc = pcVar1;
        cVar3 = FUN_00bfd480();
        if (cVar3 != '\0') {
          if (DAT_01d680d0 == '\0') {
            pcStack_b8 = "ScriptInjection permission denied.";
                    /* WARNING: Subroutine does not return */
            pcStack_bc = (char *)0xbfd441;
            FUN_016757c0();
          }
          puStack_c4 = (undefined4 *)auStack_a8;
          pcStack_b8 = (char *)0x0;
          pcStack_c8 = (char *)0xbfd457;
          pcStack_c0 = pcVar2;
          pcStack_bc = pcVar1;
          (**(code **)(*piStack_24 + 0xe0))();
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          pcStack_c8 = (char *)0xbfd462;
          pcStack_c8 = (char *)FUN_005543f0();
          pcStack_cc = "%s";
                    /* WARNING: Subroutine does not return */
          puStack_d0 = (undefined *)0xbfd46d;
          FUN_016757c0();
        }
        if (DAT_01d680d8 != '\0') {
          pcStack_c0 = auStack_a8;
          puStack_c4 = (undefined4 *)0xbfd25a;
          pcStack_bc = pcVar2;
          pcStack_b8 = pcVar1;
          puStack_c4 = (undefined4 *)FUN_0058c590();
          uStack_8._0_1_ = 3;
          if (0xf < (uint)puStack_c4[5]) {
            puStack_c4 = (undefined4 *)*puStack_c4;
          }
          pcStack_b8 = (char *)0x0;
          pcStack_bc = (char *)0x0;
          pcStack_c0 = (char *)0x0;
          pcStack_c8 = "ScriptInjectionRequested";
          pcStack_cc = "Studio";
          puStack_d0 = (undefined *)0xbfd27f;
          FUN_0087c450();
          uStack_8._0_1_ = 1;
          pcStack_b8 = (char *)0xbfd291;
          FUN_005507b0();
        }
        pcStack_b8 = (char *)&uStack_90;
        puStack_c4 = (undefined4 *)0xbfd2a1;
        pcStack_c0 = pcVar2;
        pcStack_bc = pcVar1;
        FUN_00bfcc00();
        puStack_5c = (undefined *)&puStack_d4;
        pcStack_28 = *(code **)(*piStack_24 + 0xdc);
        piStack_d8 = (int *)&pcStack_1c;
        uStack_dc = 0xbfd2c6;
        pcStack_1c = pcVar2;
        pcStack_18 = pcVar1;
        cVar3 = FUN_00585a40();
        if (cVar3 == '\0') {
          pcStack_cc = pcStack_1c;
          pcStack_c8 = pcStack_18;
          puStack_d4 = &DAT_01960a25;
        }
        else {
          puStack_d4 = (undefined *)0x0;
        }
        puStack_60 = (undefined *)apuStack_f4;
        piStack_f8 = (int *)&pcStack_30;
        uStack_fc = 0xbfd302;
        pcStack_30 = pcVar2;
        pcStack_2c = pcVar1;
        cVar3 = FUN_00585a40();
        if (cVar3 == '\0') {
          pcStack_ec = pcStack_30;
          pcStack_e8 = pcStack_2c;
          apuStack_f4[0] = &DAT_01960a1d;
        }
        else {
          apuStack_f4[0] = (undefined *)0x0;
        }
        puStack_64 = auStack_114;
        puStack_34 = auStack_114;
        uStack_8._0_1_ = 5;
        uStack_118 = 0;
        pcStack_18 = (char *)apuStack_170;
        apuStack_170[0] = ppuStack_14;
        uStack_160 = uStack_90;
        ppuStack_14 = &puStack_158;
        uVar5 = uStack_8c;
        if ((int)uStack_8c < 0) {
          uVar5 = ~uStack_8c;
        }
        pcStack_168 = pcVar2;
        pcStack_164 = pcVar1;
        FUN_00bfbc40(uStack_8c,uVar5,&ppuStack_14,auStack_88,apuStack_170,apuStack_170,0,0);
        uStack_15c = uStack_8c;
        if ((int)uStack_8c < 0) {
          uStack_15c = ~uStack_8c;
        }
        pcStack_13c = (char *)uStack_58;
        ppuStack_14 = (undefined **)auStack_134;
        uStack_8._0_1_ = 6;
        puVar6 = puStack_54;
        if ((int)puStack_54 < 0) {
          puVar6 = (undefined *)~(uint)puStack_54;
        }
        FUN_00bfbc40(puStack_54,puVar6,&ppuStack_14,auStack_50,pcStack_18,pcStack_18,0,0);
        puStack_138 = puStack_54;
        if ((int)puStack_54 < 0) {
          puStack_138 = (undefined *)~(uint)puStack_54;
        }
        uStack_8._0_1_ = 5;
        FUN_00bfade0();
        uStack_8._0_1_ = 7;
        pcStack_13c = (char *)&uStack_58;
        pcStack_140 = (char *)0xbfd3f5;
        FUN_00bfc050();
        piVar4 = piStack_24;
        uStack_8._0_1_ = 1;
        pcStack_144 = (char *)0xbfd403;
        pcStack_140 = pcVar2;
        pcStack_13c = pcVar1;
        (*pcStack_28)();
        if (DAT_01d680d0 != '\0') {
          puStack_150 = auStack_a8;
          pcStack_144 = (char *)0x1;
          uStack_154 = 0xbfd421;
          pcStack_14c = pcVar2;
          pcStack_148 = pcVar1;
          (**(code **)(*piVar4 + 0xe0))();
          uStack_8 = CONCAT31(uStack_8._1_3_,8);
          uStack_154 = 0xbfd42c;
          uStack_154 = FUN_005543f0();
          puStack_158 = &DAT_018bd25c;
                    /* WARNING: Subroutine does not return */
          uStack_15c = 0xbfd437;
          FUN_016757c0();
        }
        pcStack_144 = "ScriptInjection not allowed for plugin. User was prompted for the future.";
                    /* WARNING: Subroutine does not return */
        pcStack_148 = &UNK_00bfd477;
        FUN_016757c0();
      }
      puStack_d0 = puStack_54;
      if ((int)puStack_54 < 0) {
        puStack_d0 = (undefined *)~(uint)puStack_54;
      }
      pcStack_b8 = (char *)0x0;
      pcStack_bc = (char *)0x0;
      pcStack_c0 = (char *)pcStack_28;
      pcStack_c8 = auStack_50;
      puStack_c4 = (undefined4 *)pcStack_28;
      pcStack_cc = &uStack_1d;
      puStack_d4 = puStack_54;
      piStack_d8 = (int *)0xbfd1ce;
      FUN_00bfbac0();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26963 ; VA 0x00bfd480 ; FUN_00bfd480 */

undefined FUN_00bfd480(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined uVar2;
  int iStack_1c;
  int iStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804438;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00bfe030(&iStack_1c,param_1,param_2);
  uStack_8 = 0;
  do {
    if (iStack_1c == iStack_18) {
      uVar2 = 0;
LAB_00bfd4d8:
      FUN_00bfc270();
      ExceptionList = pvStack_10;
      return uVar2;
    }
    cVar1 = FUN_01076570(iStack_1c,param_3);
    if (cVar1 != '\0') {
      uVar2 = 1;
      goto LAB_00bfd4d8;
    }
    iStack_1c = iStack_1c + 0x24;
  } while( true );
}



/* FUNCTION 26964 ; VA 0x00bfd4f9 ; FUN_00bfd4f9 */

void FUN_00bfd4f9(void)

{
  FUN_00bfd510();
  return;
}



/* FUNCTION 26965 ; VA 0x00bfd510 ; FUN_00bfd510 */

int __fastcall FUN_00bfd510(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018045ab;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_01960a64;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = boost::bad_get::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_get>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_get>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_get>_>::
         vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 26966 ; VA 0x00bfd630 ; FUN_00bfd630 */

undefined4 * FUN_00bfd630(undefined4 *param_1,int *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  int *piVar7;
  undefined auStack_40 [4];
  int iStack_3c;
  undefined auStack_38 [28];
  int *piStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_018045e1;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uStack_8 = 0;
  uStack_14 = 1;
  piVar7 = (int *)*param_2;
  piStack_1c = (int *)param_2[1];
  if (piVar7 != piStack_1c) {
    do {
      iVar6 = *piVar7;
      iVar3 = FUN_008881d0();
      if ((iVar6 == iVar3) && (piVar7[1] != 0)) {
        piVar4 = piVar7 + 2;
      }
      else {
        piVar4 = (int *)0x0;
      }
      if (piVar4 != (int *)0x0) {
        puStack_18 = (undefined4 *)FUN_01076680(auStack_40,*piVar4);
        puVar1 = (undefined4 *)param_1[1];
        uStack_8 = 1;
        if ((undefined4 *)param_1[2] == puVar1) {
          FUN_00bfb270(puVar1,puStack_18);
        }
        else {
          *puVar1 = *puStack_18;
          param_2 = puVar1 + 2;
          uVar2 = puStack_18[1];
          uVar5 = ~uVar2;
          if (-1 < (int)uVar2) {
            uVar5 = uVar2;
          }
          FUN_00bfbc40(uVar2,uVar5,&param_2,puStack_18 + 2,param_1,param_1,0,0);
          uVar2 = puStack_18[1];
          uVar5 = ~uVar2;
          if (-1 < (int)uVar2) {
            uVar5 = uVar2;
          }
          puVar1[1] = uVar5;
          param_1[1] = param_1[1] + 0x24;
        }
        uStack_8 = uStack_8 & 0xffffff00;
        iVar6 = iStack_3c;
        if (iStack_3c < 0) {
          iVar6 = -1 - iStack_3c;
        }
        FUN_00bfbac0(iStack_3c,iVar6,(int)&param_2 + 3,auStack_38,param_1,param_1,0,0);
      }
      piVar7 = piVar7 + 0x34;
    } while (piVar7 != piStack_1c);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26967 ; VA 0x00bfd780 ; FUN_00bfd780 */

void __thiscall FUN_00bfd780(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [204];
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0aa0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_005c13e0(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x44) == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    puVar4 = (undefined4 *)FUN_005c1420(*(int *)(param_1 + 0x44));
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_008882f0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26968 ; VA 0x00bfd960 ; FUN_00bfd960 */

undefined4 __thiscall FUN_00bfd960(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  int aiStack_30 [5];
  uint uStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804600;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_3);
  uVar3 = FUN_009d09d0(aiStack_30,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  uStack_8 = 0;
  uVar3 = (**(code **)(param_1 + 0x38))(auStack_18,uVar3);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar3 = FUN_009d5950(param_3,uVar3);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (0xf < uStack_1c) {
    uVar4 = uStack_1c + 1;
    iVar2 = aiStack_30[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_30[0] + -4);
      uVar4 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 26969 ; VA 0x00bfda50 ; FUN_00bfda50 */

undefined4 FUN_00bfda50(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804620;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01256300(param_2);
  puVar4 = (undefined4 *)FUN_009d11e0(auStack_1c,param_2,param_3,2,iVar3 - param_3,iStack_14 + 0x44)
  ;
  uStack_8 = 0;
  uVar5 = FUN_009d09d0(auStack_34,param_2,param_3,1,iVar3 - param_3,iStack_14 + 0x40);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  pcVar2 = *(code **)(iStack_14 + 0x38);
  if (puVar4[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar2)(uVar5,*puVar4,puVar4[1]);
  if (0xf < uStack_20) {
    uVar7 = uStack_20 + 1;
    uVar6 = auStack_34[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_34[0] - 4);
      uVar7 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 26970 ; VA 0x00bfdb80 ; FUN_00bfdb80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_00bfdb80(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  void *pvVar2;
  undefined uVar3;
  char cVar4;
  int *piVar5;
  int iVar6;
  int iVar7;
  int *piVar8;
  uint uVar9;
  undefined auStack_144 [4];
  int iStack_140;
  undefined auStack_13c [28];
  undefined4 uStack_120;
  undefined4 *puStack_11c;
  int iStack_118;
  int iStack_114;
  int aiStack_50 [5];
  uint uStack_3c;
  int *piStack_38;
  int *piStack_34;
  int iStack_2c;
  int *piStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804671;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar5 = (int *)FUN_00eb65e0(auStack_1c);
  piVar8 = piStack_18;
  piVar5 = *(int **)(*piVar5 + 0x58);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_18[1] + -1;
    piStack_18[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar8 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  (**(code **)(*piVar5 + 0xcc))(aiStack_50,param_1,param_2);
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  iVar6 = FUN_0098ee00(aiStack_50,param_3);
  if ((char)iVar6 == '\0') {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to parse permissions.");
  }
  if ((DAT_01d70a1c != '\0') || (DAT_01d70a14 != '\0')) {
    FUN_005cac50(&iStack_2c);
    uStack_8._0_1_ = 1;
    (**(code **)(*piVar5 + 0xd4))(&piStack_38,param_1,param_2);
    uStack_8._0_1_ = 2;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 2;
    piVar5 = *(int **)*param_3;
    piStack_18 = (int *)((int *)*param_3)[1];
    piStack_20 = piVar5;
    if (piVar5 != piStack_18) {
      do {
        iVar6 = *piVar5;
        piStack_20 = piVar5;
        iVar7 = FUN_008881d0();
        if ((iVar6 == iVar7) && (piVar5[1] != 0)) {
          piVar8 = piVar5 + 2;
        }
        else {
          piVar8 = (int *)0x0;
        }
        if (piVar8 != (int *)0x0) {
          FUN_01076680(auStack_144,*piVar8);
          uStack_8._0_1_ = 3;
          cVar4 = FUN_01076b40();
          uStack_8._0_1_ = 2;
          iVar6 = iStack_140;
          if (iStack_140 < 0) {
            iVar6 = -1 - iStack_140;
          }
          FUN_00bfbac0(iStack_140,iVar6,&uStack_11,auStack_13c,piStack_18,piStack_18,0,0);
          piVar5 = piStack_20;
          if (cVar4 == '\0') {
            uStack_120 = FUN_008881d0();
            iStack_114 = piVar8[1];
            puStack_11c = (undefined4 *)0x0;
            if (iStack_114 != 0) {
              LOCK();
              *(int *)(iStack_114 + 4) = *(int *)(iStack_114 + 4) + 1;
              UNLOCK();
              iStack_114 = piVar8[1];
            }
            iStack_118 = *piVar8;
            if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
                 DAT_01ea8a9c) && (FUN_016f3809(&DAT_01ea8a9c), DAT_01ea8a9c == -1)) {
              DAT_01ea8a90 = FUN_0057bbb0;
              DAT_01ea8a94 = FUN_005880a0;
              DAT_01ea8a98 = FUN_0057d5e0;
              FUN_016f37bf(&DAT_01ea8a9c);
            }
            puStack_11c = &DAT_01ea8a90;
            uStack_8 = CONCAT31(uStack_8._1_3_,4);
            if (*(int *)(iStack_2c + 8) == *(int *)(iStack_2c + 4)) {
              FUN_005ca4f0(*(int *)(iStack_2c + 4),&uStack_120);
            }
            else {
              FUN_005caaf0(iStack_2c);
              *(int *)(iStack_2c + 4) = *(int *)(iStack_2c + 4) + 0xd0;
            }
            uStack_8._0_1_ = 5;
            if (puStack_11c != (undefined4 *)0x0) {
              (*(code *)puStack_11c[2])(&iStack_118);
            }
            uStack_8._0_1_ = 2;
            piVar5 = piStack_20;
          }
        }
        piVar5 = piVar5 + 0x34;
        piStack_20 = piVar5;
        uVar3 = (undefined)uStack_8;
      } while (piVar5 != piStack_18);
    }
    uStack_8._0_1_ = uVar3;
    piStack_18 = piStack_34;
    piVar5 = piStack_38;
    if (piStack_38 != piStack_34) {
      do {
        cVar4 = FUN_01076b40();
        if (cVar4 != '\0') {
          piVar8 = (int *)FUN_01076b70(auStack_24);
          uStack_8 = CONCAT31(uStack_8._1_3_,6);
          uStack_120 = FUN_008881d0();
          pvVar2 = ThreadLocalStoragePointer;
          iVar6 = _tls_index;
          puStack_11c = (undefined4 *)0x0;
          iStack_118 = *piVar8;
          iStack_114 = piVar8[1];
          *piVar8 = 0;
          piVar8[1] = 0;
          if ((*(int *)(*(int *)((int)pvVar2 + iVar6 * 4) + 0x34) < DAT_01ea93d0) &&
             (FUN_016f3809(&DAT_01ea93d0), DAT_01ea93d0 == -1)) {
            _DAT_01ea93c4 = FUN_0057bbb0;
            _DAT_01ea93c8 = FUN_005880a0;
            DAT_01ea93cc = FUN_0057d5e0;
            FUN_016f37bf(&DAT_01ea93d0);
          }
          puStack_11c = (undefined4 *)&DAT_01ea93c4;
          uStack_8 = CONCAT31(uStack_8._1_3_,7);
          if (*(int *)(iStack_2c + 8) == *(int *)(iStack_2c + 4)) {
            FUN_005ca4f0(*(int *)(iStack_2c + 4),&uStack_120);
          }
          else {
            FUN_005caaf0(iStack_2c);
            *(int *)(iStack_2c + 4) = *(int *)(iStack_2c + 4) + 0xd0;
          }
          uStack_8._0_1_ = 8;
          if (puStack_11c != (undefined4 *)0x0) {
            (*(code *)puStack_11c[2])(&iStack_118);
          }
          piVar8 = piStack_20;
          uStack_8._0_1_ = 2;
          if (piStack_20 != (int *)0x0) {
            LOCK();
            iVar6 = piStack_20[1] + -1;
            piStack_20[1] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)*piStack_20)();
              LOCK();
              piVar1 = piVar8 + 2;
              iVar6 = *piVar1 + -1;
              *piVar1 = iVar6;
              UNLOCK();
              if (iVar6 == 0) {
                (**(code **)(*piVar8 + 4))();
              }
            }
          }
        }
        piVar5 = piVar5 + 9;
      } while (piVar5 != piStack_18);
    }
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[1] = piStack_28[1] + 1;
      UNLOCK();
    }
    *param_3 = iStack_2c;
    piVar5 = (int *)param_3[1];
    param_3[1] = (int)piStack_28;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar6 = piVar5[1] + -1;
      piVar5[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar6 = piVar5[2] + -1;
        piVar5[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    iVar6 = FUN_00bfc270();
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piVar5 = piStack_28 + 1;
      iVar7 = *piVar5;
      iVar6 = *piVar5;
      *piVar5 = iVar7 + -1;
      UNLOCK();
      if (iVar7 + -1 == 0) {
        iVar6 = (**(code **)*piStack_28)();
        LOCK();
        piVar5 = piStack_28 + 2;
        iVar7 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar7 == 1) {
          iVar6 = (**(code **)(*piStack_28 + 4))();
        }
      }
    }
  }
  if (0xf < uStack_3c) {
    uVar9 = uStack_3c + 1;
    iVar6 = aiStack_50[0];
    if (0xfff < uVar9) {
      iVar6 = *(int *)(aiStack_50[0] + -4);
      uVar9 = uStack_3c + 0x24;
      if (0x1f < (aiStack_50[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar6 = FUN_01674ea0(iVar6,uVar9);
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 26971 ; VA 0x00bfe030 ; FUN_00bfe030 */

undefined4 FUN_00bfe030(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795998;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009cdfb0(&uStack_18);
  uStack_8 = 0;
  FUN_00bfdb80(param_2,param_3,&uStack_18);
  FUN_00bfd630(param_1,uStack_18);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26972 ; VA 0x00bfe0d0 ; FUN_00bfe0d0 */

void __thiscall FUN_00bfe0d0(int param_1,undefined4 param_2)

{
  char cVar1;
  undefined uVar2;
  undefined auStack_3c [12];
  undefined auStack_30 [8];
  undefined auStack_28 [8];
  undefined auStack_20 [8];
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804688;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016819e0(auStack_3c,param_2);
  uStack_8 = 0;
  cVar1 = FUN_016816d0();
  if (cVar1 == '\0') {
    cVar1 = FUN_01681870();
    if (cVar1 != '\0') {
      FUN_0167eea0(auStack_18,"permissions");
      cVar1 = FUN_01681870();
      if (cVar1 != '\0') {
        FUN_0167eea0(auStack_20,"IsThirdPartyAssetAllowed");
        cVar1 = FUN_0167e5c0();
        if (cVar1 != '\0') {
          uVar2 = FUN_0167e3d0(0);
          *(undefined *)(param_1 + 0x58) = uVar2;
        }
        FUN_0167eea0(auStack_28,"IsThirdPartyPurchaseAllowed");
        cVar1 = FUN_0167e5c0();
        if (cVar1 != '\0') {
          uVar2 = FUN_0167e3d0(0);
          *(undefined *)(param_1 + 0x59) = uVar2;
        }
        FUN_0167eea0(auStack_30,"IsThirdPartyTeleportAllowed");
        cVar1 = FUN_0167e5c0();
        if (cVar1 != '\0') {
          uVar2 = FUN_0167e3d0(0);
          *(undefined *)(param_1 + 0x5a) = uVar2;
        }
      }
    }
  }
  FUN_0167ec40();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26973 ; VA 0x00bfe1e0 ; FUN_00bfe1e0 */

void FUN_00bfe1e0(undefined4 *param_1)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  if (DAT_01d680d8 != '\0') {
    ExceptionList = &pvStack_10;
    puVar1 = (undefined4 *)FUN_0058c590(aiStack_28,*param_1,param_1[1]);
    uStack_8 = 0;
    if (0xf < (uint)puVar1[5]) {
      puVar1 = (undefined4 *)*puVar1;
    }
    FUN_0087c450("Studio","ScriptInjectionDenied",puVar1,0,0,0);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      iVar2 = aiStack_28[0];
      if (0xfff < uVar3) {
        iVar2 = *(int *)(aiStack_28[0] + -4);
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26974 ; VA 0x00bfe290 ; FUN_00bfe290 */

void FUN_00bfe290(int *param_1)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  ExceptionList = &pvStack_10;
  FUN_00bfea70(*(undefined4 *)(iVar2 + 8),*(undefined4 *)(iVar2 + 0xc),iVar2 + 0x10,iVar2 + 0x34);
  if (DAT_01d680d8 != '\0') {
    puVar1 = (undefined4 *)
             FUN_0058c590(aiStack_28,*(undefined4 *)(iVar2 + 8),*(undefined4 *)(iVar2 + 0xc));
    uStack_8 = 0;
    if (0xf < (uint)puVar1[5]) {
      puVar1 = (undefined4 *)*puVar1;
    }
    FUN_0087c450("Studio","ScriptInjectionAllowed",puVar1,0,0,0);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      iVar2 = aiStack_28[0];
      if (0xfff < uVar3) {
        iVar2 = *(int *)(aiStack_28[0] + -4);
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26975 ; VA 0x00bfe350 ; FUN_00bfe350 */

/* WARNING: Removing unreachable block (ram,0x00bfe3ad) */
/* WARNING: Removing unreachable block (ram,0x00bfe3b9) */
/* WARNING: Removing unreachable block (ram,0x00bfe3c7) */

undefined4 FUN_00bfe350(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1328;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bfc330(param_2,param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 26976 ; VA 0x00bfe3e0 ; FUN_00bfe3e0 */

/* WARNING: Removing unreachable block (ram,0x00bfe491) */
/* WARNING: Removing unreachable block (ram,0x00bfe49f) */
/* WARNING: Removing unreachable block (ram,0x00bfe4cd) */
/* WARNING: Removing unreachable block (ram,0x00bfe4af) */

void FUN_00bfe3e0(undefined4 param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint in_stack_0000001c;
  undefined uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017969d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0("Third party teleport protection was unable to confirm safety of teleportation place."
               ,0x54);
  FUN_005e65e0(uVar3);
  if (0xf < in_stack_0000001c) {
    uVar2 = in_stack_0000001c + 1;
    iVar1 = param_2;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_2 + -4);
      uVar2 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26977 ; VA 0x00bfe4e0 ; FUN_00bfe4e0 */

undefined __fastcall FUN_00bfe4e0(int param_1)

{
  return *(undefined *)(param_1 + 0x5a);
}



/* FUNCTION 26978 ; VA 0x00bfe4f0 ; FUN_00bfe4f0 */

undefined4 FUN_00bfe4f0(undefined4 param_1)

{
  FUN_009cdfb0(param_1);
  return param_1;
}



/* FUNCTION 26979 ; VA 0x00bfe510 ; FUN_00bfe510 */

void FUN_00bfe510(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  return;
}



/* FUNCTION 26980 ; VA 0x00bfe550 ; FUN_00bfe550 */

void FUN_00bfe550(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1dfb3e4);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_054f40712761c74c811dc60b375335a3>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 26981 ; VA 0x00bfe5c0 ; FUN_00bfe5c0 */

void FUN_00bfe5c0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bffcf;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x48);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00bfbd10(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_005e6080();
        FUN_01674ea0(iVar2,0x48);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dfb48c);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_892ea67dfb530cf202d8b3fae566aa93>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26982 ; VA 0x00bfe710 ; FUN_00bfe710 */

void FUN_00bfe710(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c005f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      param_3 = FUN_01674e20(0x58);
      uStack_8 = 0;
      if (param_3 != 0) {
        iVar2 = FUN_00bfbdf0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        uVar1 = *(uint *)(iVar2 + 0x38);
        uVar3 = ~uVar1;
        if (-1 < (int)uVar1) {
          uVar3 = uVar1;
        }
        ExceptionList = &pvStack_10;
        FUN_00bfbac0(uVar1,uVar3,(int)&param_3 + 3,iVar2 + 0x3c,2,2,0,0);
        uVar1 = *(uint *)(iVar2 + 0x14);
        uVar3 = ~uVar1;
        if (-1 < (int)uVar1) {
          uVar3 = uVar1;
        }
        FUN_00bfbac0(uVar1,uVar3,(int)&param_3 + 3,iVar2 + 0x18,param_3,param_3,0,0);
        FUN_01674ea0(iVar2,0x58);
      }
    }
    else {
      if (param_3 != 3) goto LAB_00bfe864;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dfb41c);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
    }
    *param_2 = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00bfe864:
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_89cffbf6da5f9b938f9eb080bb47fada>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26983 ; VA 0x00bfe890 ; FUN_00bfe890 */

void FUN_00bfe890(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1dfb3ac);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_a7d01e7de396430ca92227d0a212f3ca>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 26984 ; VA 0x00bfe900 ; FUN_00bfe900 */

void FUN_00bfe900(int *param_1,int *param_2,int param_3)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b7df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar4 = *param_1;
      ExceptionList = &pvStack_10;
      iVar3 = FUN_01674e20(0x20);
      uStack_8 = 0;
      if (iVar3 != 0) {
        iVar4 = FUN_005e5f00(iVar4);
        *param_2 = iVar4;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      puVar1 = (uint *)*param_2;
      if (puVar1 != (uint *)0x0) {
        uVar2 = *puVar1;
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(puVar1 + 2,puVar1 + 2,2);
            }
          }
          *puVar1 = 0;
        }
        FUN_01674ea0(puVar1,0x20);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dfb454);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_d469d11a537ca4a4059a4fbdaa30e006>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26985 ; VA 0x00bfea70 ; FUN_00bfea70 */

void FUN_00bfea70(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puStack_30;
  undefined4 *puStack_2c;
  undefined4 uStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018046b0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00bfe030(&puStack_30,param_1,param_2);
  uStack_24 = 0;
  puStack_20 = (undefined4 *)0x0;
  puStack_1c = (undefined4 *)0x0;
  uStack_8 = 1;
  puStack_14 = puStack_2c;
  uVar5 = ((int)puStack_2c - (int)puStack_30) / 0x24;
  puVar6 = puStack_30;
  if (uVar5 != 0) {
    if (0x71c71c7 < uVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_00bfc9e0(uVar5);
    puVar6 = puStack_30;
  }
  puVar1 = param_4;
  puStack_14 = puStack_2c;
  if (puVar6 != puStack_2c) {
    do {
      cVar3 = FUN_01076570(puVar6,param_3);
      puVar2 = puStack_20;
      if (cVar3 == '\0') {
        puVar7 = puVar6;
        if (puStack_1c != puStack_20) {
          *puStack_20 = *puVar6;
          param_4 = puStack_20 + 2;
          uVar5 = puVar6[1];
          uVar4 = ~uVar5;
          if (-1 < (int)uVar5) {
            uVar4 = uVar5;
          }
          FUN_00bfbc40(uVar5,uVar4,&param_4,puVar6 + 2,param_4,param_4,0,0);
          uVar5 = puVar6[1];
          goto LAB_00bfeb96;
        }
LAB_00bfebac:
        FUN_00bfb270(puStack_20,puVar7);
      }
      else {
        puVar7 = puVar1;
        if (puStack_1c == puStack_20) goto LAB_00bfebac;
        *puStack_20 = *puVar1;
        param_4 = puStack_20 + 2;
        uVar5 = puVar1[1];
        uVar4 = ~uVar5;
        if (-1 < (int)uVar5) {
          uVar4 = uVar5;
        }
        FUN_00bfbc40(uVar5,uVar4,&param_4,puVar1 + 2,param_4,param_4,0,0);
        uVar5 = puVar1[1];
LAB_00bfeb96:
        uVar4 = ~uVar5;
        if (-1 < (int)uVar5) {
          uVar4 = uVar5;
        }
        puVar2[1] = uVar4;
        puStack_20 = puStack_20 + 9;
      }
      puVar6 = puVar6 + 9;
    } while (puVar6 != puStack_14);
  }
  FUN_00bfec40(param_1,param_2,&uStack_24);
  FUN_00bfc270();
  FUN_00bfc270();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26986 ; VA 0x00bfebfc ; FUN_00bfebfc */

void FUN_00bfebfc(void)

{
  FUN_00bfec10();
  return;
}



/* FUNCTION 26987 ; VA 0x00bfec10 ; FUN_00bfec10 */

void __fastcall FUN_00bfec10(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00bfbed0(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01cb1f0c);
}



/* FUNCTION 26988 ; VA 0x00bfec40 ; FUN_00bfec40 */

int FUN_00bfec40(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  undefined auStack_28 [4];
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018046d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005cac50(&iStack_20);
  uStack_8 = 0;
  iVar3 = param_3[1];
  for (iVar6 = *param_3; iVar6 != iVar3; iVar6 = iVar6 + 0x24) {
    uVar5 = FUN_01076b70(auStack_28);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (*(int *)(iStack_20 + 8) == *(int *)(iStack_20 + 4)) {
      FUN_00beac80(*(int *)(iStack_20 + 4),uVar5);
    }
    else {
      FUN_00b67b80(uVar5);
      *(int *)(iStack_20 + 4) = *(int *)(iStack_20 + 4) + 0xd0;
    }
    piVar2 = piStack_24;
    uStack_8 = uStack_8 & 0xffffff00;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_24[1] + -1;
      piStack_24[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  iStack_18 = iStack_20;
  uStack_8 = 2;
  piStack_14 = piStack_1c;
  iVar6 = FUN_00bfed50(param_1,param_2,&iStack_18);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_14 + 1;
    iVar3 = *piVar2;
    iVar6 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar6 = (**(code **)*piStack_14)();
      LOCK();
      piVar2 = piStack_14 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar6 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 26989 ; VA 0x00bfed50 ; FUN_00bfed50 */

void FUN_00bfed50(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  undefined uVar4;
  char cVar5;
  int *piVar6;
  undefined4 uVar7;
  uint uVar8;
  uint uVar9;
  int iStack_110;
  undefined auStack_10c [200];
  undefined auStack_44 [12];
  undefined auStack_38 [4];
  int *piStack_34;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180470b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar6 = (int *)FUN_00eb65e0(auStack_38);
  piVar6 = *(int **)(*piVar6 + 0x58);
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_34[1] + -1;
    piStack_34[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piStack_34 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_8 = 0;
  uVar7 = FUN_005c1420(param_3);
  uStack_8._0_1_ = 1;
  cVar5 = FUN_0098fc00(uVar7,auStack_2c,1);
  cStack_11 = cVar5 == '\0';
  uStack_8._0_1_ = 2;
  if (iStack_110 != 0) {
    (**(code **)(iStack_110 + 8))(auStack_10c);
  }
  uStack_8._0_1_ = 0;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (cStack_11 == '\0') {
    pcVar2 = *(code **)(*piVar6 + 0xd0);
    FUN_0054ef60(auStack_2c);
    (*pcVar2)(param_1,param_2);
    if ((DAT_01d70a1c != '\0') || (DAT_01d70a14 != '\0')) {
      pcVar2 = *(code **)(*piVar6 + 0xd8);
      uVar7 = FUN_00bfd630(auStack_44,*param_3);
      uStack_8._0_1_ = 3;
      (*pcVar2)(param_1,param_2,uVar7);
      FUN_00bfc270();
    }
    if (0xf < uStack_18) {
      uVar9 = uStack_18 + 1;
      uVar8 = auStack_2c[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_2c[0] - 4);
        uVar9 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    ExceptionList = pvStack_10;
    return;
  }
  uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to serialize permissions.");
}



/* FUNCTION 26990 ; VA 0x00bfeed0 ; FUN_00bfeed0 */

void __thiscall FUN_00bfeed0(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0x59) = param_2;
  return;
}



/* FUNCTION 26991 ; VA 0x00bfeee0 ; FUN_00bfeee0 */

void __thiscall FUN_00bfeee0(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0x5a) = param_2;
  return;
}



/* FUNCTION 26992 ; VA 0x00bfeef0 ; FUN_00bfeef0 */

char * FUN_00bfeef0(void)

{
  return "boost::bad_get: failed value get using boost::get";
}



/* FUNCTION 26993 ; VA 0x00bfef00 ; FUN_00bfef00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00bfef00(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804740;
  pvStack_10 = ExceptionList;
  if (DAT_01ef7af8 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef7d10) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef7d10);
      if (DAT_01ef7d10 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ReplicatedStorage",1,uStack_20,0,0,0xb,0,0);
        _DAT_01ef7d08 = RBX::Creator<class_RBX::ReplicatedStorage>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef7b00,&DAT_01ef7d08);
        FUN_016f3654(FUN_01892b80);
        FUN_016f37bf(&DAT_01ef7d10);
      }
    }
    DAT_01ef7af8 = &DAT_01ef7b00;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef7af8;
}



/* FUNCTION 26994 ; VA 0x00bff000 ; FUN_00bff000 */

void FUN_00bff000(void)

{
  int iVar1;
  
  if (DAT_01ef7d14 == 0) {
    iVar1 = FUN_00bfef00();
    DAT_01ef7d14 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 26995 ; VA 0x00bff020 ; FUN_00bff020 */

undefined4 * __fastcall FUN_00bff020(undefined4 *param_1)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804768;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::ReplicatedStorage,class_RBX::ServiceInstance>::
             vftable;
  uVar1 = FUN_00bfef00();
  param_1[3] = uVar1;
  uStack_8 = 1;
  *param_1 = RBX::ReplicatedStorage::vftable;
  FUN_0054eff0("ReplicatedStorage");
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_008a6520(aiStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    iVar2 = aiStack_2c[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26996 ; VA 0x00bff0d0 ; FUN_00bff0d0 */

void __fastcall FUN_00bff0d0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::ReplicatedStorage>::vftable;
  uVar1 = FUN_00bfef00(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26997 ; VA 0x00bff110 ; FUN_00bff110 */

undefined4 * FUN_00bff110(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00673350(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 26998 ; VA 0x00bff180 ; FUN_00bff180 */

uint FUN_00bff180(void)

{
  int iVar1;
  
  iVar1 = FUN_00bfef00();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 26999 ; VA 0x00bff1a0 ; FUN_00bff1a0 */

uint FUN_00bff1a0(void)

{
  int iVar1;
  
  iVar1 = FUN_00bfef00();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}


