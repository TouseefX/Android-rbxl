/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 25750 ; VA 0x00bac9e0 ; FUN_00bac9e0 */

undefined4 * __thiscall FUN_00bac9e0(undefined4 *param_1,undefined4 *param_2)

{
  *param_1 = std::_Func_impl_no_alloc<class_<lambda_62ce43819271da14e996b090ba34b547>,void,int>::
             vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[1] = *param_2;
  param_1[2] = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[3] = param_2[2];
  param_1[4] = param_2[3];
  param_2[2] = 0;
  param_2[3] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[5] = param_2[4];
  param_1[6] = param_2[5];
  param_1[7] = param_2[6];
  param_2[4] = 0;
  param_2[5] = 0;
  param_2[6] = 0;
  return param_1;
}



/* FUNCTION 25751 ; VA 0x00baca90 ; FUN_00baca90 */

int * __thiscall FUN_00baca90(int *param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  undefined4 uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fcca8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  iVar6 = FUN_00601dc0();
  *param_1 = iVar6;
  uStack_8 = 1;
  uVar7 = FUN_00bacc60(*(undefined4 *)(*param_2 + 4),iVar6,param_2);
  *(undefined4 *)(*param_1 + 4) = uVar7;
  piVar2 = (int *)*param_1;
  param_1[1] = param_2[1];
  piVar3 = (int *)piVar2[1];
  if (*(char *)((int)piVar3 + 0xd) == '\0') {
    cVar1 = *(char *)(*piVar3 + 0xd);
    piVar5 = (int *)*piVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*piVar5 + 0xd);
      piVar3 = piVar5;
      piVar5 = (int *)*piVar5;
    }
    *piVar2 = (int)piVar3;
    iVar6 = *(int *)(*param_1 + 4);
    iVar4 = *(int *)(iVar6 + 8);
    cVar1 = *(char *)(iVar4 + 0xd);
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*(int *)(iVar4 + 8) + 0xd);
      iVar6 = iVar4;
      iVar4 = *(int *)(iVar4 + 8);
    }
    *(int *)(*param_1 + 8) = iVar6;
  }
  else {
    *piVar2 = (int)piVar2;
    *(int *)(*param_1 + 8) = *param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25752 ; VA 0x00bacb4e ; Catch_All@00bacb4e */

void Catch_All_00bacb4e(void)

{
  FUN_00bad7e0();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 25753 ; VA 0x00bacb60 ; FUN_00bacb60 */

undefined * FUN_00bacb60(void)

{
  undefined *puVar1;
  undefined4 uVar2;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fcccc;
  pvStack_10 = ExceptionList;
  if (DAT_01ef2eec == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef30f8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef30f8);
      puVar1 = PTR_s_InternalSyncService_01d679b8;
      if (DAT_01ef30f8 == -1) {
        uStack_8 = 0;
        uVar2 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar2,puVar1,1,uStack_20,0,0,1,5,0);
        FUN_016f3654(&LAB_018915f0);
        FUN_016f37bf(&DAT_01ef30f8);
      }
    }
    DAT_01ef2eec = &DAT_01ef2ef0;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef2eec;
}



/* FUNCTION 25754 ; VA 0x00bacc40 ; FUN_00bacc40 */

void FUN_00bacc40(void)

{
  int iVar1;
  
  if (DAT_01ef30fc == 0) {
    iVar1 = FUN_00bacb60();
    DAT_01ef30fc = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 25755 ; VA 0x00bacc60 ; FUN_00bacc60 */

undefined4 * __thiscall
FUN_00bacc60(int *param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fcce0;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)*param_1;
  if (*(char *)((int)param_2 + 0xd) == '\0') {
    ExceptionList = &pvStack_10;
    puVar1 = (undefined4 *)FUN_0093f460(param_2 + 4);
    uStack_8 = 0;
    puVar1[1] = param_3;
    *(undefined *)(puVar1 + 3) = *(undefined *)(param_2 + 3);
    if (*(char *)((int)puVar3 + 0xd) != '\0') {
      puVar3 = puVar1;
    }
    uVar2 = FUN_00bacc60(*param_2,puVar1,param_4);
    *puVar1 = uVar2;
    uVar2 = FUN_00bacc60(param_2[2],puVar1,param_4);
    puVar1[2] = uVar2;
  }
  ExceptionList = pvStack_10;
  return puVar3;
}



/* FUNCTION 25756 ; VA 0x00baccf4 ; Catch_All@00baccf4 */

void Catch_All_00baccf4(void)

{
  int unaff_EBP;
  
  FUN_00949f40(*(undefined4 *)(unaff_EBP + 0xc));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 25757 ; VA 0x00bacd10 ; FUN_00bacd10 */

int __thiscall FUN_00bacd10(int *param_1,int param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  uint uVar9;
  int iVar10;
  int iVar11;
  
  iVar11 = *param_1;
  iVar10 = param_2 - iVar11 >> 3;
  iVar4 = param_1[1] - iVar11 >> 3;
  if (iVar4 == 0x1fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar5 = iVar4 + 1;
  uVar9 = param_1[2] - iVar11 >> 3;
  uVar6 = uVar5;
  if ((uVar9 <= 0x1fffffff - (uVar9 >> 1)) && (uVar6 = (uVar9 >> 1) + uVar9, uVar6 < uVar5)) {
    uVar6 = uVar5;
  }
  puVar7 = (undefined4 *)FUN_00578020(uVar6);
  puVar7[iVar10 * 2] = 0;
  puVar7[iVar10 * 2 + 1] = 0;
  puVar1 = puVar7 + iVar10 * 2;
  *puVar1 = *param_3;
  puVar1[1] = param_3[1];
  *param_3 = 0;
  param_3[1] = 0;
  iVar4 = param_1[1];
  iVar11 = *param_1;
  puVar8 = puVar7;
  if (param_2 != iVar4) {
    FUN_006cfaf0(iVar11,param_2,puVar7,param_1);
    iVar4 = param_1[1];
    puVar8 = puVar1 + 2;
    iVar11 = param_2;
  }
  FUN_006cfaf0(iVar11,iVar4,puVar8,param_1);
  iVar11 = *param_1;
  if (iVar11 != 0) {
    iVar4 = param_1[1];
    if (iVar11 != iVar4) {
      do {
        piVar2 = *(int **)(iVar11 + 4);
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = piVar2[2] + -1;
          piVar2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
        iVar11 = iVar11 + 8;
      } while (iVar11 != iVar4);
      iVar11 = *param_1;
    }
    uVar9 = param_1[2] - iVar11 & 0xfffffff8;
    iVar4 = iVar11;
    if (0xfff < uVar9) {
      iVar4 = *(int *)(iVar11 + -4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (iVar11 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar9);
  }
  *param_1 = (int)puVar7;
  param_1[1] = (int)(puVar7 + uVar5 * 2);
  param_1[2] = (int)(puVar7 + uVar6 * 2);
  return *param_1 + iVar10 * 8;
}



/* FUNCTION 25758 ; VA 0x00bace60 ; FUN_00bace60 */

int FUN_00bace60(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fccf8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ead650,&LAB_006340b0);
  uVar2 = FUN_006351d0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00b75e90();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00b76660(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ead650,&LAB_006340b0);
      uVar2 = FUN_006351d0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 25759 ; VA 0x00bacff0 ; FUN_00bacff0 */

undefined4 FUN_00bacff0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_00bace60();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 25760 ; VA 0x00bad050 ; FUN_00bad050 */

void __thiscall FUN_00bad050(undefined4 param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  
  puVar3 = (undefined4 *)FUN_01674e20(0x10,param_1);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    puVar3[1] = 1;
    puVar3[2] = 1;
    *puVar3 = std::_Ref_count_obj<class_rbx::signals::scoped_connection>::vftable;
    puVar3[3] = 0;
    if (((int *)*param_3 != (int *)0x0) && (*(int *)*param_3 != 0)) {
      iVar2 = *param_3;
      puVar3[3] = iVar2;
      piVar1 = (int *)(iVar2 + 4);
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
      *param_2 = (int)(puVar3 + 3);
      param_2[1] = (int)puVar3;
      return;
    }
  }
  *param_2 = (int)(puVar3 + 3);
  param_2[1] = (int)puVar3;
  return;
}



/* FUNCTION 25761 ; VA 0x00bad0d0 ; FUN_00bad0d0 */

undefined4 * __thiscall FUN_00bad0d0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fcd23;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  uStack_8 = 1;
  FUN_00776490(param_2 + 4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25762 ; VA 0x00bad170 ; FUN_00bad170 */

int __fastcall FUN_00bad170(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_005e6280();
  piVar3 = *(int **)(param_1 + 0xc);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)(*piVar3 + 4))();
    }
  }
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00bad1a7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar4 = (**(code **)(*piVar3 + 4))();
      return iVar4;
    }
  }
  return iVar4;
}



/* FUNCTION 25763 ; VA 0x00bad1b0 ; FUN_00bad1b0 */

int __thiscall FUN_00bad1b0(int *param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  void *pvVar3;
  int *piVar4;
  undefined3 uVar5;
  int iVar6;
  undefined **ppuStack_48;
  int *piStack_44;
  undefined *puStack_40;
  undefined ***pppuStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  pvVar3 = ExceptionList;
  puStack_c = &LAB_017fcd50;
  pvStack_10 = ExceptionList;
  iVar6 = *param_1;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iStack_18 = param_2;
  piStack_14 = param_3;
  uStack_7 = 0;
  uVar5 = uStack_7;
  uStack_8 = 1;
  uStack_7 = 0;
  if (*(int *)(iVar6 + 0x94) == 0) {
    FUN_00bae0a0(auStack_20,param_2);
    piStack_44 = &iStack_18;
    ppuStack_48 = std::
                  _Func_impl_no_alloc<class_<lambda_3a1bb91b88d139e7095637a7c8529f35>,void,class_RBX::FileSyncItem*>
                  ::vftable;
    puStack_40 = auStack_20;
    pppuStack_24 = &ppuStack_48;
    uStack_8 = 3;
    iVar6 = FUN_00badf00(iStack_18,pppuStack_24);
    if (pppuStack_24 != (undefined ***)0x0) {
      iVar6 = (*(code *)(*pppuStack_24)[4])(pppuStack_24 != &ppuStack_48);
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_1c + 1;
      iVar2 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piStack_1c + 2;
        iVar2 = *piVar1;
        iVar6 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar6 = (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    if (piStack_14 == (int *)0x0) goto LAB_00bad2b0;
  }
  else {
    uStack_7 = uVar5;
    if (param_3 == (int *)0x0) {
      ExceptionList = pvVar3;
      return param_2;
    }
  }
  piVar4 = piStack_14;
  LOCK();
  piVar1 = piStack_14 + 1;
  iVar2 = *piVar1;
  iVar6 = *piVar1;
  *piVar1 = iVar2 + -1;
  UNLOCK();
  if (iVar2 + -1 == 0) {
    (**(code **)*piStack_14)();
    LOCK();
    piVar1 = piVar4 + 2;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)(*piVar4 + 4))();
    }
  }
LAB_00bad2b0:
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 25764 ; VA 0x00bad2f0 ; FUN_00bad2f0 */

int __thiscall FUN_00bad2f0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined auStack_30 [8];
  int aiStack_28 [2];
  int aiStack_20 [2];
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017fcd78;
  pvStack_10 = ExceptionList;
  iVar3 = param_1[5] - param_1[4] >> 3;
  if ((param_2 < iVar3) && (-1 < param_2)) {
    iVar3 = param_1[1];
    iStack_18 = 0;
    piStack_14 = (int *)0x0;
    ExceptionList = &pvStack_10;
    if (iVar3 != 0) {
      piVar1 = (int *)(iVar3 + 4);
      iVar2 = *(int *)(iVar3 + 4);
      ExceptionList = &pvStack_10;
      while (iVar2 != 0) {
        LOCK();
        iVar3 = *piVar1;
        if (iVar2 == iVar3) {
          *piVar1 = iVar2 + 1;
          iVar3 = iVar2;
        }
        UNLOCK();
        if (iVar3 == iVar2) {
          iVar3 = *param_1;
          piStack_14 = (int *)param_1[1];
          iStack_18 = iVar3;
          break;
        }
        iVar2 = *piVar1;
      }
    }
    piVar1 = piStack_14;
    uStack_8 = 0;
    uStack_7 = 0;
    if (iStack_18 != 0) {
      piVar4 = (int *)FUN_00587490(auStack_30);
      iVar2 = *piVar4;
      iVar3 = FUN_00550b30();
      if (iVar2 != 0) {
        FUN_00587490(aiStack_20);
        uStack_8 = 1;
        if (aiStack_20[0] != 0) {
          uVar5 = *(undefined4 *)(aiStack_20[0] + 0x34);
          piVar4 = aiStack_28;
          FUN_00ba4f80(piVar4,uVar5);
          uStack_8 = 2;
          if (aiStack_28[0] != 0) {
            FUN_00557fc0(aiStack_20);
            FUN_00ba6610(piVar4,uVar5);
          }
          FUN_00550b30();
        }
        iVar3 = FUN_00550b30();
      }
    }
    if (piVar1 != (int *)0x0) {
      LOCK();
      piVar4 = piVar1 + 1;
      iVar2 = *piVar4;
      iVar3 = *piVar4;
      *piVar4 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)*piVar1)();
        LOCK();
        piVar4 = piVar1 + 2;
        iVar2 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar3 = (**(code **)(*piVar1 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 25765 ; VA 0x00bad430 ; FUN_00bad430 */

undefined4 __thiscall FUN_00bad430(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x3c);
  }
  return param_1;
}



/* FUNCTION 25766 ; VA 0x00bad450 ; FUN_00bad450 */

int __thiscall FUN_00bad450(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_0094e3b0(&iStack_14,**(undefined4 **)(param_1 + 0x28),*(undefined4 **)(param_1 + 0x28));
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x28),0x18);
  piVar2 = *(int **)(param_1 + 0x24);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x1c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x30);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25767 ; VA 0x00bad560 ; FUN_00bad560 */

void __thiscall FUN_00bad560(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_267de1d404a8b3d5e9c2db4a13e65840>,void,class_RBX::FileSyncItem*>
             ::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  return;
}



/* FUNCTION 25768 ; VA 0x00bad580 ; FUN_00bad580 */

void __thiscall FUN_00bad580(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_3a1bb91b88d139e7095637a7c8529f35>,void,class_RBX::FileSyncItem*>
             ::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  return;
}



/* FUNCTION 25769 ; VA 0x00bad5a0 ; FUN_00bad5a0 */

undefined4 * __thiscall FUN_00bad5a0(int param_1,undefined4 *param_2)

{
  *param_2 = std::_Func_impl_no_alloc<class_<lambda_62ce43819271da14e996b090ba34b547>,void,int>::
             vftable;
  FUN_00bad0d0(param_1 + 4);
  return param_2;
}



/* FUNCTION 25770 ; VA 0x00bad5c0 ; FUN_00bad5c0 */

void __thiscall FUN_00bad5c0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_c7caee1a0ff5946c85b64739e68839d1>,void,class_RBX::FileSyncItem*>
             ::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  return;
}



/* FUNCTION 25771 ; VA 0x00bad5e0 ; FUN_00bad5e0 */

int __thiscall FUN_00bad5e0(int param_1,char param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_005e6280();
  piVar3 = *(int **)(param_1 + 0x10);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)(*piVar3 + 4))();
    }
  }
  piVar3 = *(int **)(param_1 + 8);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      iVar4 = (**(code **)(*piVar3 + 4))();
    }
  }
  if (param_2 != '\0') {
    iVar4 = FUN_01674ea0(param_1,0x20);
  }
  return iVar4;
}



/* FUNCTION 25772 ; VA 0x00bad640 ; FUN_00bad640 */

void FUN_00bad640(void)

{
  FUN_00bad450(0);
  return;
}



/* FUNCTION 25773 ; VA 0x00bad650 ; FUN_00bad650 */

void __fastcall FUN_00bad650(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0xc);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25774 ; VA 0x00bad6b0 ; FUN_00bad6b0 */

void __fastcall FUN_00bad6b0(int param_1)

{
  FUN_00ba6a00(**(undefined4 **)(param_1 + 4));
  return;
}



/* FUNCTION 25775 ; VA 0x00bad6d0 ; FUN_00bad6d0 */

void __fastcall FUN_00bad6d0(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  
  iVar2 = **(int **)(param_1 + 8);
  if (*(int *)(iVar2 + 0xc) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar2 + 0xc) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar3 = *(undefined4 *)(iVar2 + 8);
  uVar4 = *(undefined4 *)(iVar2 + 0xc);
  puVar5 = *(undefined4 **)(param_1 + 4);
  if (puVar5[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00ba6800(*puVar5,puVar5[1],uVar3,uVar4);
  return;
}



/* FUNCTION 25776 ; VA 0x00bad740 ; FUN_00bad740 */

void FUN_00bad740(undefined4 *param_1)

{
  FUN_00bad2f0(*param_1);
  return;
}



/* FUNCTION 25777 ; VA 0x00bad760 ; FUN_00bad760 */

void __fastcall FUN_00bad760(int param_1)

{
  FUN_00ba67e0(**(undefined4 **)(param_1 + 4));
  return;
}



/* FUNCTION 25778 ; VA 0x00bad780 ; FUN_00bad780 */

void __fastcall FUN_00bad780(int param_1)

{
  FUN_00bac9e0(param_1 + 4);
  return;
}



/* FUNCTION 25779 ; VA 0x00bad7a0 ; FUN_00bad7a0 */

TypeDescriptor * FUN_00bad7a0(void)

{
  return &<lambda_267de1d404a8b3d5e9c2db4a13e65840>::RTTI_Type_Descriptor;
}



/* FUNCTION 25780 ; VA 0x00bad7b0 ; FUN_00bad7b0 */

TypeDescriptor * FUN_00bad7b0(void)

{
  return &<lambda_3a1bb91b88d139e7095637a7c8529f35>::RTTI_Type_Descriptor;
}



/* FUNCTION 25781 ; VA 0x00bad7c0 ; FUN_00bad7c0 */

TypeDescriptor * FUN_00bad7c0(void)

{
  return &<lambda_62ce43819271da14e996b090ba34b547>::RTTI_Type_Descriptor;
}



/* FUNCTION 25782 ; VA 0x00bad7d0 ; FUN_00bad7d0 */

TypeDescriptor * FUN_00bad7d0(void)

{
  return &<lambda_c7caee1a0ff5946c85b64739e68839d1>::RTTI_Type_Descriptor;
}



/* FUNCTION 25783 ; VA 0x00bad7e0 ; FUN_00bad7e0 */

void __fastcall FUN_00bad7e0(undefined4 *param_1)

{
  undefined4 *puStack_8;
  
  puStack_8 = param_1;
  FUN_0094e3b0(&puStack_8,*(undefined4 *)*param_1,(undefined4 *)*param_1);
  return;
}



/* FUNCTION 25784 ; VA 0x00bad800 ; FUN_00bad800 */

undefined4 * FUN_00bad800(undefined4 param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined auStack_34 [4];
  int *piStack_30;
  undefined4 *puStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fcdda;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_00bae160(&puStack_2c,param_1);
  uStack_8 = 0;
  if (puStack_2c[6] == 0) {
    iStack_18 = FUN_008a4100();
    iStack_18 = iStack_18 + 8;
    uStack_8._0_1_ = 1;
    uVar4 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 2;
    uStack_24 = uVar4;
    puStack_1c = (undefined4 *)FUN_01674e20(0x1c);
    if (puStack_1c == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      *puStack_1c = 0;
      puStack_1c[1] = 1;
      puStack_1c[2] = FUN_00bade30;
      puStack_1c[3] = _guard_check_icall;
      puStack_1c[4] = 0;
      puStack_1c[5] = iStack_18;
      puStack_1c[6] = puStack_20;
      puVar5 = puStack_1c;
    }
    FUN_016797d0(puVar5);
    if (puVar5 != (undefined4 *)0x0) {
      LOCK();
      puVar5[1] = puVar5[1] + 1;
      UNLOCK();
    }
    uStack_14 = 4;
    uStack_8._0_1_ = 3;
    puStack_1c = puVar5;
    FUN_01675290(uVar4);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    puVar5 = (undefined4 *)FUN_00bad050(auStack_34,&puStack_1c);
    uVar4 = *puVar5;
    uVar2 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    puStack_2c[6] = uVar4;
    piVar3 = (int *)puStack_2c[7];
    puStack_2c[7] = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar6 = piVar3[1] + -1;
      piVar3[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar6 = piVar3[2] + -1;
        piVar3[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = piStack_30;
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_30[1] + -1;
      piStack_30[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar6 = *piVar1 + -1;
        *piVar1 = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    uStack_8 = uStack_8 & 0xffffff00;
    if (puStack_1c != (undefined4 *)0x0) {
      piVar3 = puStack_1c + 1;
      LOCK();
      iVar6 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      uStack_14 = 0;
      if (iVar6 == 1) {
        FUN_01674ea0(puStack_1c);
      }
    }
    uStack_14 = 0;
  }
  if (puStack_2c[8] == 0) {
    iVar6 = FUN_008a4100();
    uStack_8._0_1_ = 4;
    uVar4 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 5;
    uStack_24 = uVar4;
    puStack_1c = (undefined4 *)FUN_01674e20(0x1c);
    if (puStack_1c == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      *puStack_1c = 0;
      puStack_1c[1] = 1;
      puStack_1c[2] = FUN_00badcc0;
      puStack_1c[3] = _guard_check_icall;
      puStack_1c[4] = 0;
      puStack_1c[5] = iVar6 + 0xc;
      puStack_1c[6] = puStack_20;
      puVar5 = puStack_1c;
    }
    FUN_016797d0(puVar5);
    if (puVar5 != (undefined4 *)0x0) {
      LOCK();
      puVar5[1] = puVar5[1] + 1;
      UNLOCK();
    }
    uStack_14 = 8;
    uStack_8._0_1_ = 6;
    puStack_20 = puVar5;
    FUN_01675290(uVar4);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    puVar5 = (undefined4 *)FUN_00bad050(auStack_34,&puStack_20);
    uVar4 = *puVar5;
    uVar2 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    puStack_2c[8] = uVar4;
    piVar3 = (int *)puStack_2c[9];
    puStack_2c[9] = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar6 = piVar3[1] + -1;
      piVar3[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar6 = piVar3[2] + -1;
        piVar3[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_30[1] + -1;
      piStack_30[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        iVar6 = piStack_30[2] + -1;
        piStack_30[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_30 + 4))();
        }
      }
    }
    puStack_2c = puStack_20;
    if (puStack_20 != (undefined4 *)0x0) {
      piVar3 = puStack_20 + 1;
      LOCK();
      iVar6 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        puStack_2c = (undefined4 *)FUN_01674ea0(puStack_20);
      }
    }
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piVar3 = piStack_28 + 1;
    iVar6 = *piVar3;
    puStack_2c = (undefined4 *)*piVar3;
    *piVar3 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      puStack_2c = (undefined4 *)(**(code **)*piStack_28)();
      LOCK();
      piVar3 = piStack_28 + 2;
      iVar6 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        puStack_2c = (undefined4 *)(**(code **)(*piStack_28 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puStack_2c;
}



/* FUNCTION 25785 ; VA 0x00badb10 ; FUN_00badb10 */

int FUN_00badb10(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined auStack_34 [4];
  int *piStack_30;
  int iStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fce19;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00ba5c00(param_1);
  if ((char)iVar3 != '\0') {
    FUN_00bae160(&iStack_2c,param_1);
    uStack_8 = 0;
    if (*(int *)(iStack_2c + 0x10) == 0) {
      iStack_18 = param_1 + 0x4c;
      uStack_8._0_1_ = 1;
      uStack_8._1_3_ = 0;
      uVar4 = FUN_01675290(DAT_02110da8);
      uStack_8._0_1_ = 2;
      uStack_24 = uVar4;
      puStack_1c = (undefined4 *)FUN_01674e20(0x20);
      if (puStack_1c == (undefined4 *)0x0) {
        puVar5 = (undefined4 *)0x0;
      }
      else {
        *puStack_1c = 0;
        puStack_1c[1] = 1;
        puStack_1c[2] = FUN_00badd50;
        puStack_1c[3] = _guard_check_icall;
        puStack_1c[4] = 0;
        puStack_1c[6] = uStack_14;
        puStack_1c[5] = iStack_18;
        puStack_1c[7] = param_1;
        puVar5 = puStack_1c;
      }
      FUN_016797d0(puVar5);
      if (puVar5 != (undefined4 *)0x0) {
        LOCK();
        puVar5[1] = puVar5[1] + 1;
        UNLOCK();
      }
      uStack_20 = 4;
      uStack_8._0_1_ = 3;
      puStack_1c = puVar5;
      FUN_01675290(uVar4);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      uVar4 = FUN_00bad050(auStack_34,&puStack_1c);
      FUN_005587e0(uVar4);
      if (piStack_30 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_30[1] + -1;
        piStack_30[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_30)();
          LOCK();
          iVar3 = piStack_30[2] + -1;
          piStack_30[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_30 + 4))();
          }
        }
      }
      uStack_8 = uStack_8 & 0xffffff00;
      if (puStack_1c != (undefined4 *)0x0) {
        piVar1 = puStack_1c + 1;
        LOCK();
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          FUN_01674ea0(puStack_1c);
        }
      }
    }
    iVar3 = FUN_00bad800(param_1);
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_28 + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)*piStack_28)();
        LOCK();
        piVar1 = piStack_28 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar3 = (**(code **)(*piStack_28 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 25786 ; VA 0x00badcc0 ; FUN_00badcc0 */

int FUN_00badcc0(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00bad1b0(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 25787 ; VA 0x00badd50 ; FUN_00badd50 */

void FUN_00badd50(int param_1,int param_2)

{
  int iVar1;
  char cVar2;
  undefined **ppuStack_38;
  undefined4 *puStack_34;
  undefined ***pppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar1 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fce40;
  pvStack_10 = ExceptionList;
  if (param_2 != 0) {
    ExceptionList = &pvStack_10;
    cVar2 = FUN_005764c0("Source");
    if (cVar2 == '\0') {
      cVar2 = FUN_005764c0(&DAT_018d8974);
      if (cVar2 == '\0') {
        ExceptionList = pvStack_10;
        return;
      }
      param_1 = *(undefined4 *)(iVar1 + 0x1c);
      if (*(int *)(*(int *)(iVar1 + 0x18) + 0x94) != 0) {
        ExceptionList = pvStack_10;
        return;
      }
      ppuStack_38 = std::
                    _Func_impl_no_alloc<class_<lambda_267de1d404a8b3d5e9c2db4a13e65840>,void,class_RBX::FileSyncItem*>
                    ::vftable;
      uStack_8 = 1;
    }
    else {
      param_1 = *(undefined4 *)(iVar1 + 0x1c);
      if (*(int *)(*(int *)(iVar1 + 0x18) + 0x94) != 0) {
        ExceptionList = pvStack_10;
        return;
      }
      ppuStack_38 = std::
                    _Func_impl_no_alloc<class_<lambda_c7caee1a0ff5946c85b64739e68839d1>,void,class_RBX::FileSyncItem*>
                    ::vftable;
      uStack_8 = 0;
    }
    puStack_34 = &param_1;
    pppuStack_14 = &ppuStack_38;
    FUN_00badf00(param_1,pppuStack_14);
    if (pppuStack_14 != (undefined ***)0x0) {
      (*(code *)(*pppuStack_14)[4])(pppuStack_14 != &ppuStack_38);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25788 ; VA 0x00bade30 ; FUN_00bade30 */

int FUN_00bade30(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b5e40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00bae6b0(param_2,param_3,0);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 25789 ; VA 0x00badf00 ; FUN_00badf00 */

int FUN_00badf00(undefined4 param_1,int param_2)

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  int iVar8;
  int iStack_30;
  int *piStack_2c;
  undefined4 *puStack_28;
  int iStack_20;
  int *piStack_1c;
  undefined auStack_18 [4];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fce68;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00bae0a0(&iStack_30,param_1);
  uStack_8 = 0;
  if (iStack_30 != 0) {
    FUN_00baca90(iStack_30 + 0x28,(int)&param_1 + 3);
    puVar6 = puStack_28;
    puVar3 = (undefined4 *)*puStack_28;
    while (uStack_8._1_3_ = (undefined3)((uint)uStack_8 >> 8), puVar3 != puVar6) {
      iVar4 = puVar3[5];
      iStack_20 = 0;
      piStack_1c = (int *)0x0;
      if (iVar4 != 0) {
        piVar1 = (int *)(iVar4 + 4);
        iVar4 = *(int *)(iVar4 + 4);
        while (iVar4 != 0) {
          LOCK();
          iVar8 = *piVar1;
          if (iVar4 == iVar8) {
            *piVar1 = iVar4 + 1;
            iVar8 = iVar4;
          }
          UNLOCK();
          if (iVar8 == iVar4) {
            iStack_20 = puVar3[4];
            piStack_1c = (int *)puVar3[5];
            break;
          }
          iVar4 = *piVar1;
        }
      }
      piVar1 = piStack_1c;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (iStack_20 != 0) {
        iStack_14 = iStack_20;
        if (*(int **)(param_2 + 0x24) == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
          FUN_016ddc9c();
        }
        (**(code **)(**(int **)(param_2 + 0x24) + 8))(&iStack_14);
      }
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar4 = piVar1[1] + -1;
        piVar1[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar4 = piVar1[2] + -1;
          piVar1[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      puVar5 = (undefined4 *)puVar3[2];
      if (*(char *)((int)puVar5 + 0xd) == '\0') {
        cVar2 = *(char *)((int)*puVar5 + 0xd);
        puVar3 = puVar5;
        puVar5 = (undefined4 *)*puVar5;
        while (cVar2 == '\0') {
          cVar2 = *(char *)((int)*puVar5 + 0xd);
          puVar3 = puVar5;
          puVar5 = (undefined4 *)*puVar5;
        }
      }
      else {
        cVar2 = *(char *)((int)puVar3[1] + 0xd);
        puVar7 = (undefined4 *)puVar3[1];
        puVar5 = puVar3;
        while ((puVar3 = puVar7, cVar2 == '\0' && (puVar5 == (undefined4 *)puVar3[2]))) {
          cVar2 = *(char *)((int)puVar3[1] + 0xd);
          puVar7 = (undefined4 *)puVar3[1];
          puVar5 = puVar3;
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_0094e3b0(auStack_18,*puStack_28,puStack_28);
    iStack_30 = FUN_01674ea0(puStack_28,0x18);
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_2c + 1;
    iVar4 = *piVar1;
    iStack_30 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iStack_30 = (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piStack_2c + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iStack_30 = (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iStack_30;
}



/* FUNCTION 25790 ; VA 0x00bae0a0 ; FUN_00bae0a0 */

void __thiscall FUN_00bae0a0(int param_1,undefined4 *param_2,int param_3)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_3 == 0) {
    *param_2 = 0;
    param_2[1] = 0;
    return;
  }
  iVar2 = FUN_0060e0c0(auStack_c,param_3);
  puVar1 = *(undefined4 **)(param_1 + 0x88);
  if (*(char *)((int)puVar1[1] + 0xd) == '\0') {
    puVar3 = (undefined4 *)puVar1[1];
    puVar5 = puVar1;
    do {
      if ((uint)puVar3[5] < *(uint *)(iVar2 + 4)) {
        puVar4 = (undefined4 *)puVar3[2];
      }
      else {
        puVar4 = (undefined4 *)*puVar3;
        puVar5 = puVar3;
      }
      puVar3 = puVar4;
    } while (*(char *)((int)puVar4 + 0xd) == '\0');
    if ((puVar5 != puVar1) && ((uint)puVar5[5] <= *(uint *)(iVar2 + 4))) goto LAB_00bae10f;
  }
  puVar5 = puVar1;
LAB_00bae10f:
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_8[2] + -1;
    piStack_8[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_8 + 4))();
    }
  }
  *param_2 = 0;
  param_2[1] = 0;
  if (puVar5 != *(undefined4 **)(param_1 + 0x88)) {
    iVar2 = puVar5[7];
    if (iVar2 != 0) {
      LOCK();
      *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
      UNLOCK();
      iVar2 = puVar5[7];
    }
    *param_2 = puVar5[6];
    param_2[1] = iVar2;
  }
  return;
}



/* FUNCTION 25791 ; VA 0x00bae160 ; FUN_00bae160 */

int * FUN_00bae160(int *param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  int *piVar7;
  int iStack_38;
  int *piStack_34;
  int iStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017fcefc;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00bae0a0(param_1,param_2);
  uStack_8 = 0;
  uStack_18 = 1;
  if (*param_1 == 0) {
    puVar4 = (undefined4 *)FUN_01674e20(0x3c);
    uStack_8 = 1;
    piStack_1c = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      piVar7 = puVar4 + 3;
      puVar4[1] = 1;
      puVar4[2] = 1;
      *puVar4 = std::_Ref_count_obj<struct_RBX::FileSyncService::InstanceInfo>::vftable;
      piStack_2c = piVar7;
      FUN_0170d1f0(piVar7,0,0x30);
      *piVar7 = 0;
      puVar4[4] = 0;
      puVar4[5] = 0;
      puVar4[6] = 0;
      puVar4[7] = 0;
      puVar4[8] = 0;
      puVar4[9] = 0;
      puVar4[10] = 0;
      puVar4[0xb] = 0;
      puVar4[0xc] = 0;
      piVar7 = puVar4 + 0xd;
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      *piVar7 = 0;
      puVar4[0xe] = 0;
      piStack_34 = piVar7;
      iVar5 = FUN_00601dc0();
      *piVar7 = iVar5;
    }
    uStack_8 = uStack_8 & 0xffffff00;
    *param_1 = (int)(puVar4 + 3);
    piVar7 = (int *)param_1[1];
    param_1[1] = (int)puVar4;
    uStack_18 = 3;
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar5 = piVar7[1] + -1;
      piVar7[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar7)();
        LOCK();
        iVar5 = piVar7[2] + -1;
        piVar7[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    puVar6 = (undefined4 *)FUN_0060e0c0(&iStack_38,param_2);
    puVar4 = (undefined4 *)*param_1;
    uVar2 = *puVar6;
    uVar3 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *puVar4 = uVar2;
    piVar7 = (int *)puVar4[1];
    puVar4[1] = uVar3;
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar5 = piVar7[2] + -1;
      piVar7[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar7 + 4))();
      }
    }
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_34[2] + -1;
      piStack_34[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
    puVar4 = (undefined4 *)FUN_0060e0c0(&iStack_38,param_2);
    uStack_28 = *puVar4;
    piStack_24 = (int *)puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    piStack_1c = (int *)param_1[1];
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
      piStack_1c = (int *)param_1[1];
    }
    iStack_20 = *param_1;
    uStack_8 = 8;
    iVar5 = FUN_00ba0940(&uStack_28);
    FUN_00ba0f70(&iStack_30,0,iVar5 + 0x10,iVar5);
    piVar7 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar5 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar7 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_24[2] + -1;
      piStack_24[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
    uStack_8 = uStack_8 & 0xffffff00;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_34[2] + -1;
      piStack_34[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
    FUN_00bae0a0(&iStack_38,param_2);
    uStack_8 = 9;
    FUN_00587490(&iStack_30);
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    if (iStack_30 != 0) {
      puVar4 = (undefined4 *)FUN_0060e0c0(&iStack_20,*(undefined4 *)(param_2 + 0x34));
      uVar2 = *puVar4;
      uVar3 = puVar4[1];
      *puVar4 = 0;
      puVar4[1] = 0;
      *(undefined4 *)(iStack_38 + 8) = uVar2;
      piVar7 = *(int **)(iStack_38 + 0xc);
      *(undefined4 *)(iStack_38 + 0xc) = uVar3;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar5 = piVar7[2] + -1;
        piVar7[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar5 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
      FUN_00badb10(param_2);
    }
    piVar7 = piStack_2c;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar5 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        piVar1 = piVar7 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    piVar7 = piStack_34;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_34[1] + -1;
      piStack_34[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        piVar1 = piVar7 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25792 ; VA 0x00bae4c0 ; FUN_00bae4c0 */

undefined4 FUN_00bae4c0(int param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  int iStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  int iStack_8;
  
  FUN_00bae0a0(&iStack_18,param_2);
  if (iStack_18 != 0) {
    piVar8 = *(int **)(iStack_18 + 0x28);
    piVar7 = (int *)*piVar8;
    piStack_c = piVar8;
    if (piVar7 != piVar8) {
      do {
        iVar2 = piVar7[5];
        piVar6 = (int *)0x0;
        iStack_8 = 0;
        uStack_10 = 0;
        if (iVar2 != 0) {
          iVar3 = *(int *)(iVar2 + 4);
          while (piVar6 = (int *)0x0, iVar3 != 0) {
            LOCK();
            iVar5 = *(int *)(iVar2 + 4);
            if (iVar3 == iVar5) {
              *(int *)(iVar2 + 4) = iVar3 + 1;
              iVar5 = iVar3;
            }
            UNLOCK();
            piVar8 = piStack_c;
            if (iVar5 == iVar3) {
              iStack_8 = piVar7[4];
              piVar6 = (int *)piVar7[5];
              break;
            }
            iVar3 = *(int *)(iVar2 + 4);
          }
        }
        if (piVar6 != (int *)0x0) {
          LOCK();
          iVar2 = piVar6[1] + -1;
          piVar6[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar6)();
            LOCK();
            iVar2 = piVar6[2] + -1;
            piVar6[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
        if (iStack_8 != param_1) {
          if (piStack_14 != (int *)0x0) {
            LOCK();
            iVar2 = piStack_14[1] + -1;
            piStack_14[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piStack_14)();
              LOCK();
              piVar8 = piStack_14 + 2;
              iVar2 = *piVar8;
              *piVar8 = *piVar8 + -1;
              UNLOCK();
              if (iVar2 == 1) {
                (**(code **)(*piStack_14 + 4))();
              }
            }
          }
          return 1;
        }
        piVar6 = (int *)piVar7[2];
        if (*(char *)((int)piVar6 + 0xd) == '\0') {
          cVar1 = *(char *)(*piVar6 + 0xd);
          piVar7 = piVar6;
          piVar6 = (int *)*piVar6;
          while (cVar1 == '\0') {
            cVar1 = *(char *)(*piVar6 + 0xd);
            piVar7 = piVar6;
            piVar6 = (int *)*piVar6;
          }
        }
        else {
          cVar1 = *(char *)(piVar7[1] + 0xd);
          piVar4 = (int *)piVar7[1];
          piVar6 = piVar7;
          while ((piVar7 = piVar4, cVar1 == '\0' && (piVar6 == (int *)piVar7[2]))) {
            cVar1 = *(char *)(piVar7[1] + 0xd);
            piVar4 = (int *)piVar7[1];
            piVar6 = piVar7;
          }
        }
      } while (piVar7 != piVar8);
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar8 = piStack_14 + 2;
      iVar2 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  return 0;
}



/* FUNCTION 25793 ; VA 0x00bae620 ; FUN_00bae620 */

undefined4 FUN_00bae620(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  uint uStack_c;
  int *piStack_8;
  
  FUN_00bae0a0(&uStack_c,param_1);
  if ((uStack_c != 0) && (*(int *)(uStack_c + 0x2c) != 0)) {
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_8[1] + -1;
      piStack_8[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar1 = piStack_8 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return 1;
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_8[1] + -1;
    piStack_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  return 0;
}



/* FUNCTION 25794 ; VA 0x00bae6b0 ; FUN_00bae6b0 */

int * __thiscall FUN_00bae6b0(int param_1,int param_2,int *param_3,char param_4)

{
  int iVar1;
  int *piVar2;
  undefined uVar3;
  char cVar4;
  int *piVar5;
  uint uVar6;
  int *piVar7;
  int *piVar8;
  int *piVar9;
  undefined4 uVar10;
  int *piVar11;
  int **ppiVar12;
  int *piStack_38;
  int *piStack_34;
  int *piStack_30;
  int iStack_2c;
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017fcf30;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  piVar5 = (int *)FUN_00ba5c00(param_2);
  if (((char)piVar5 == '\0') || (*(int *)(param_1 + 0x94) != 0)) goto LAB_00bae94e;
  uVar10 = 0xbae70e;
  piVar5 = (int *)FUN_00bae0a0(&iStack_2c,*(undefined4 *)(param_2 + 0x34));
  uStack_8 = 1;
  if (iStack_2c == 0) {
LAB_00bae925:
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piVar9 = piStack_28 + 1;
      iVar1 = *piVar9;
      piVar5 = (int *)*piVar9;
      *piVar9 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        piVar9 = piStack_28 + 2;
        iVar1 = *piVar9;
        piVar5 = (int *)*piVar9;
        *piVar9 = iVar1 + -1;
        UNLOCK();
        if (iVar1 + -1 == 0) {
          piVar5 = (int *)(**(code **)(*piStack_28 + 4))();
        }
      }
    }
  }
  else {
    piStack_38 = (int *)0x0;
    piVar7 = (int *)0x0;
    piStack_14 = (int *)0x0;
    piStack_34 = (int *)0x0;
    piStack_30 = (int *)0x0;
    piVar9 = *(int **)(iStack_2c + 0x28);
    uStack_8 = 2;
    uVar3 = uStack_8;
    uStack_8 = 2;
    piStack_18 = (int *)*piVar9;
    piVar5 = piStack_18;
    if (piStack_18 != piVar9) {
      do {
        piVar5 = piStack_14;
        piVar11 = (int *)0xbae751;
        FUN_00587490(&iStack_24);
        uStack_8 = 3;
        if ((iStack_24 != 0) && ((param_4 != '\0' || (cVar4 = FUN_00ba4f20(), cVar4 != '\0')))) {
          if (piVar5 == piVar7) {
            uVar10 = 0xbae7a6;
            piVar11 = piVar7;
            FUN_005c1970(piVar7,&iStack_24);
            piStack_14 = piStack_30;
            piVar7 = piStack_34;
          }
          else {
            *piVar7 = 0;
            piVar7[1] = 0;
            if (piStack_20 != (int *)0x0) {
              LOCK();
              piStack_20[1] = piStack_20[1] + 1;
              UNLOCK();
            }
            *piVar7 = iStack_24;
            piVar7[1] = (int)piStack_20;
            piStack_34 = piVar7 + 2;
            piVar7 = piStack_34;
          }
        }
        piVar5 = piStack_20;
        uStack_8 = 2;
        if (piStack_20 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_20[1] + -1;
          piStack_20[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_20)();
            LOCK();
            piVar8 = piVar5 + 2;
            iVar1 = *piVar8 + -1;
            *piVar8 = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        FUN_00551320();
        piVar2 = piStack_14;
        piVar8 = piStack_38;
      } while (piStack_18 != piVar9);
      if (piStack_38 != piVar7) {
        piVar5 = (int *)((int)piVar7 - (int)piStack_38 >> 3);
        if (piVar5 == (int *)0x1) {
          if (param_3 != (int *)0x0) {
            LOCK();
            param_3[1] = param_3[1] + 1;
            UNLOCK();
          }
          piVar5 = (int *)FUN_00ba6610(param_2,param_3);
          piVar9 = piStack_14;
        }
        else {
          piVar9 = piStack_14;
          if (*(int *)(iStack_1c + 0x84) != 0) {
            ppiVar12 = &piStack_38;
            FUN_00557fc0(&param_2);
            piVar5 = (int *)FUN_00baeb00(uVar10,piVar11,ppiVar12);
            piVar7 = piStack_34;
            piVar8 = piStack_38;
            piVar9 = piStack_30;
          }
        }
        if (piVar8 != (int *)0x0) {
          FUN_005596d0(piVar8,piVar7,&piStack_38);
          uVar6 = (int)piVar9 - (int)piVar8 & 0xfffffff8;
          piVar5 = piVar8;
          if (0xfff < uVar6) {
            piVar5 = (int *)piVar8[-1];
            uVar6 = uVar6 + 0x23;
            if (0x1f < (uint)((int)piVar8 + (-4 - (int)piVar5))) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          piVar5 = (int *)FUN_01674ea0(piVar5,uVar6);
        }
        goto LAB_00bae925;
      }
      piVar5 = piStack_18;
      uVar3 = uStack_8;
      if (piStack_38 != (int *)0x0) {
        FUN_005596d0(piStack_38,piVar7,&piStack_38);
        uVar6 = (int)piVar2 - (int)piVar8 & 0xfffffff8;
        piVar5 = piVar8;
        if (0xfff < uVar6) {
          piVar5 = (int *)piVar8[-1];
          uVar6 = uVar6 + 0x23;
          if (0x1f < (uint)((int)piVar8 + (-4 - (int)piVar5))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        piVar5 = (int *)FUN_01674ea0(piVar5,uVar6);
        uVar3 = uStack_8;
      }
    }
    uStack_8 = uVar3;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piVar9 = piStack_28 + 1;
      iVar1 = *piVar9;
      piVar5 = (int *)*piVar9;
      *piVar9 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        piVar9 = piStack_28 + 2;
        iVar1 = *piVar9;
        piVar5 = (int *)*piVar9;
        *piVar9 = iVar1 + -1;
        UNLOCK();
        if (iVar1 + -1 == 0) {
          piVar5 = (int *)(**(code **)(*piStack_28 + 4))();
        }
      }
    }
  }
LAB_00bae94e:
  piVar9 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar7 = param_3 + 1;
    iVar1 = *piVar7;
    piVar5 = (int *)*piVar7;
    *piVar7 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      piVar5 = (int *)(**(code **)*param_3)();
      LOCK();
      piVar7 = piVar9 + 2;
      iVar1 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        piVar5 = (int *)(**(code **)(*piVar9 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar5;
}



/* FUNCTION 25795 ; VA 0x00bae9a0 ; FUN_00bae9a0 */

int __thiscall FUN_00bae9a0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined auStack_2c [8];
  undefined auStack_24 [4];
  int *piStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017fcf58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_00bae160(auStack_1c,param_3);
  iStack_8 = 0;
  uVar2 = FUN_0060e0c0(auStack_24,param_2);
  iStack_8._0_1_ = 1;
  FUN_00940eb0(auStack_2c,0,uVar2,param_3);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_20[2] + -1;
    piStack_20[2] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)(*piStack_20 + 4))();
    }
  }
  if (param_1 != 0) {
    iVar5 = *(int *)(param_1 + 0x34);
    iVar3 = iStack_14;
    if ((iVar5 != 0) && (iVar3 = iVar5, *(int *)(iVar5 + 0x34) != 0)) {
      iVar3 = FUN_005c8ac0();
    }
    if ((iVar3 != 0) &&
       (iVar5 = *(int *)(iVar3 + 0xc), iVar3 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
       (uint)*(ushort *)(iVar3 + 0x1da))) {
      FUN_00bace60();
    }
  }
  puVar4 = (undefined4 *)FUN_00ba4f80(auStack_24,param_3);
  iStack_8._0_1_ = 2;
  FUN_00b76b00(param_3,*puVar4);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_20[1] + -1;
    piStack_20[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar5 = piStack_20[2] + -1;
      piStack_20[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  iVar5 = FUN_005e6780(param_3);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar3 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar5 = (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar5 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 25796 ; VA 0x00baeb00 ; FUN_00baeb00 */

int __thiscall FUN_00baeb00(int param_1,int param_2,int *param_3,undefined4 *param_4)

{
  int **ppiVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  char cVar6;
  undefined4 ******ppppppuVar7;
  undefined4 uVar8;
  int **ppiVar9;
  undefined4 *puVar10;
  int *piVar11;
  int *piVar12;
  uint uVar13;
  int iVar14;
  int *piVar15;
  int aiStack_98 [4];
  undefined4 *****apppppuStack_88 [4];
  int iStack_78;
  int *piStack_74;
  undefined auStack_70 [4];
  int *apiStack_6c [2];
  int *piStack_64;
  undefined4 uStack_5c;
  uint uStack_58;
  int iStack_54;
  int *piStack_50;
  int iStack_4c;
  int *piStack_48;
  uint uStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  int *piStack_30;
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017fcff6;
  puStack_2c = (undefined4 *)0x0;
  puStack_28 = (undefined4 *)0x0;
  puStack_24 = (undefined4 *)0x0;
  uStack_38 = 0;
  piStack_34 = (int *)0x0;
  piStack_30 = (int *)0x0;
  uStack_7 = 0;
  uStack_8 = 2;
  piVar15 = (int *)*param_4;
  piVar3 = (int *)param_4[1];
  pvStack_10 = ExceptionList;
  piVar11 = piStack_34;
  ExceptionList = &pvStack_10;
  do {
    piStack_34 = piVar11;
    if (piVar15 == piVar3) {
      FUN_0060e0c0(&iStack_18,param_1);
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[2] = param_3[2] + 1;
        UNLOCK();
      }
      iStack_20 = param_2;
      piStack_1c = param_3;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        piStack_14[2] = piStack_14[2] + 1;
        UNLOCK();
      }
      iStack_54 = iStack_18;
      piStack_50 = piStack_14;
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[2] = param_3[2] + 1;
        UNLOCK();
      }
      iStack_4c = param_2;
      piStack_48 = param_3;
      uStack_8 = 0xd;
      FUN_00776490(&uStack_38);
      _uStack_8 = CONCAT31(uStack_7,0xe);
      if (puStack_2c != puStack_28) {
        FUN_00bad0d0(&iStack_54);
        piStack_74 = (int *)0x0;
        piStack_74 = (int *)FUN_00bac9e0(auStack_70);
        FUN_005e6280();
        if (piStack_64 != (int *)0x0) {
          LOCK();
          iVar14 = piStack_64[2] + -1;
          piStack_64[2] = iVar14;
          UNLOCK();
          if (iVar14 == 0) {
            (**(code **)(*piStack_64 + 4))();
          }
        }
        if (apiStack_6c[0] != (int *)0x0) {
          LOCK();
          iVar14 = apiStack_6c[0][2] + -1;
          apiStack_6c[0][2] = iVar14;
          UNLOCK();
          if (iVar14 == 0) {
            (**(code **)(*apiStack_6c[0] + 4))();
          }
        }
        _uStack_8 = CONCAT31(uStack_7,0xf);
        if (*(int **)(param_1 + 0x84) == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
          FUN_016ddc9c();
        }
        (**(code **)(**(int **)(param_1 + 0x84) + 8))(&puStack_2c,aiStack_98);
        if (piStack_74 != (int *)0x0) {
          (**(code **)(*piStack_74 + 0x10))(piStack_74 != aiStack_98);
        }
      }
      FUN_005e6280();
      if (piStack_48 != (int *)0x0) {
        LOCK();
        iVar14 = piStack_48[2] + -1;
        piStack_48[2] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)(*piStack_48 + 4))();
        }
      }
      if (piStack_50 != (int *)0x0) {
        LOCK();
        iVar14 = piStack_50[2] + -1;
        piStack_50[2] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)(*piStack_50 + 4))();
        }
      }
      if (param_3 != (int *)0x0) {
        LOCK();
        iVar14 = param_3[2] + -1;
        param_3[2] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)(*param_3 + 4))();
        }
      }
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar14 = piStack_14[2] + -1;
        piStack_14[2] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
      FUN_005e6280();
      iVar14 = thunk_FUN_00577a40();
      if (param_3 != (int *)0x0) {
        LOCK();
        piVar15 = param_3 + 1;
        iVar2 = *piVar15;
        iVar14 = *piVar15;
        *piVar15 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar14 = (**(code **)*param_3)();
          LOCK();
          piVar15 = param_3 + 2;
          iVar2 = *piVar15;
          *piVar15 = *piVar15 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            iVar14 = (**(code **)(*param_3 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return iVar14;
    }
    FUN_00ba4f80(&iStack_18,*(undefined4 *)(param_2 + 0x34));
    uStack_8 = 3;
    if (iStack_18 != 0) {
      FUN_0054f050(iStack_18);
      uStack_8 = 4;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        piStack_14[1] = piStack_14[1] + 1;
        UNLOCK();
      }
      cVar6 = FUN_00ba5ba0(iStack_18,piStack_14);
      if (cVar6 != '\0') {
        uStack_5c = 0;
        uStack_58 = 7;
        apiStack_6c[0] = (int *)((uint)apiStack_6c[0] & 0xffff0000);
        uStack_8 = 5;
        iStack_78 = 0;
        piStack_74 = (int *)&DAT_0000000f;
        apppppuStack_88[0] = (undefined4 *****)((uint)apppppuStack_88[0] & 0xffffff00);
        FUN_00551260(&DAT_018bc9b8);
        uStack_8 = 6;
        if (iStack_78 != 0) {
          ppppppuVar7 = apppppuStack_88;
          if (&DAT_0000000f < piStack_74) {
            ppppppuVar7 = (undefined4 ******)apppppuStack_88[0];
          }
          iVar14 = iStack_78 + (int)ppppppuVar7;
          ppppppuVar7 = apppppuStack_88;
          if (&DAT_0000000f < piStack_74) {
            ppppppuVar7 = (undefined4 ******)apppppuStack_88[0];
          }
          uVar8 = FUN_01686580();
          FUN_01685950(ppppppuVar7,iVar14,apiStack_6c,uVar8);
          piVar11 = piStack_34;
        }
        uStack_8 = 5;
        if (&DAT_0000000f < piStack_74) {
          piVar12 = (int *)((int)piStack_74 + 1);
          ppppppuVar7 = (undefined4 ******)apppppuStack_88[0];
          if ((int *)0xfff < piVar12) {
            ppppppuVar7 = (undefined4 ******)apppppuStack_88[0][-1];
            piVar12 = piStack_74 + 9;
            if (0x1f < (uint)((int)apppppuStack_88[0] + (-4 - (int)ppppppuVar7))) goto LAB_00baf029;
          }
          FUN_01674ea0(ppppppuVar7,piVar12);
        }
        iStack_78 = 0;
        piStack_74 = (int *)&DAT_0000000f;
        apppppuStack_88[0] = (undefined4 *****)((uint)apppppuStack_88[0] & 0xffffff00);
        _uStack_8 = CONCAT31(uStack_7,7);
        ppiVar9 = (int **)FUN_01688950(apiStack_6c);
        if (&piStack_50 != ppiVar9) {
          ppiVar1 = ppiVar9 + 4;
          if ((int *)0x7 < ppiVar9[5]) {
            ppiVar9 = (int **)*ppiVar9;
          }
          FUN_0058ed10(ppiVar9,*ppiVar1);
        }
        uStack_8 = 4;
        if (7 < uStack_58) {
          uVar13 = uStack_58 * 2 + 2;
          piVar12 = apiStack_6c[0];
          if (0xfff < uVar13) {
            piVar12 = (int *)apiStack_6c[0][-1];
            uVar13 = uStack_58 * 2 + 0x25;
            if (0x1f < (uint)((int)apiStack_6c[0] + (-4 - (int)piVar12))) goto LAB_00baf029;
          }
          FUN_01674ea0(piVar12,uVar13);
        }
      }
      puVar10 = (undefined4 *)FUN_0151a940(apiStack_6c,&piStack_50);
      uStack_8 = 8;
      if (puStack_24 == puStack_28) {
        FUN_0058d0a0(puStack_28,puVar10);
      }
      else {
        puStack_28[4] = 0;
        puStack_28[5] = 0;
        uVar8 = puVar10[1];
        uVar4 = puVar10[2];
        uVar5 = puVar10[3];
        *puStack_28 = *puVar10;
        puStack_28[1] = uVar8;
        puStack_28[2] = uVar4;
        puStack_28[3] = uVar5;
        uVar8 = puVar10[5];
        puStack_28[4] = puVar10[4];
        puStack_28[5] = uVar8;
        puVar10[4] = 0;
        puVar10[5] = 0xf;
        *(undefined *)puVar10 = 0;
        puStack_28 = puStack_28 + 6;
      }
      uStack_8 = 4;
      if (0xf < uStack_58) {
        uVar13 = uStack_58 + 1;
        piVar12 = apiStack_6c[0];
        if (0xfff < uVar13) {
          piVar12 = (int *)apiStack_6c[0][-1];
          uVar13 = uStack_58 + 0x24;
          if (0x1f < (uint)((int)apiStack_6c[0] + (-4 - (int)piVar12))) goto LAB_00baf029;
        }
        FUN_01674ea0(piVar12,uVar13);
      }
      piStack_1c = (int *)piVar15[1];
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piStack_1c[2] = piStack_1c[2] + 1;
        UNLOCK();
        piStack_1c = (int *)piVar15[1];
      }
      iStack_20 = *piVar15;
      uStack_8 = 9;
      if (piStack_30 == piVar11) {
        FUN_00bacd10(piVar11,&iStack_20);
        if (piStack_1c != (int *)0x0) {
          LOCK();
          iVar14 = piStack_1c[2] + -1;
          piStack_1c[2] = iVar14;
          UNLOCK();
          if (iVar14 == 0) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
      else {
        *piVar11 = iStack_20;
        piVar11[1] = (int)piStack_1c;
        piStack_34 = piVar11 + 2;
        iStack_20 = 0;
        piStack_1c = (int *)0x0;
      }
      uStack_8 = 3;
      if (7 < uStack_3c) {
        uVar13 = uStack_3c * 2 + 2;
        piVar11 = piStack_50;
        if (0xfff < uVar13) {
          piVar11 = (int *)piStack_50[-1];
          uVar13 = uStack_3c * 2 + 0x25;
          if (0x1f < (uint)((int)piStack_50 + (-4 - (int)piVar11))) {
LAB_00baf029:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(piVar11,uVar13);
      }
    }
    piVar11 = piStack_14;
    uStack_8 = 2;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar14 = piStack_14[1] + -1;
      piStack_14[1] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar12 = piVar11 + 2;
        iVar14 = *piVar12 + -1;
        *piVar12 = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)(*piVar11 + 4))();
        }
      }
    }
    piVar15 = piVar15 + 2;
    piVar11 = piStack_34;
  } while( true );
}



/* FUNCTION 25797 ; VA 0x00baf040 ; FUN_00baf040 */

void __thiscall FUN_00baf040(int param_1,undefined4 param_2,char param_3)

{
  undefined4 uVar1;
  
  uVar1 = 0;
  if (param_3 == '\0') {
    uVar1 = param_2;
  }
  *(undefined4 *)(param_1 + 0x94) = uVar1;
  return;
}



/* FUNCTION 25798 ; VA 0x00baf060 ; FUN_00baf060 */

int FUN_00baf060(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  int *piVar9;
  int iStack_2c;
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd018;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00bae0a0(&iStack_24,param_2);
  piVar9 = piStack_20;
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  if (iStack_24 != 0) {
    piVar1 = (int *)(iStack_24 + 0x28);
    piStack_1c = piVar1;
    iStack_18 = FUN_0060e0c0(&iStack_2c,param_1);
    puVar8 = (undefined4 *)*piVar1;
    uStack_8._0_1_ = 1;
    puVar4 = (undefined4 *)puVar8[1];
    param_1 = puVar8;
    if (*(char *)((int)puVar4 + 0xd) == '\0') {
      puVar7 = puVar4;
      do {
        if ((uint)puVar7[5] < *(uint *)(iStack_18 + 4)) {
          puVar5 = (undefined4 *)puVar7[2];
        }
        else {
          if ((*(char *)((int)puVar8 + 0xd) != '\0') && (*(uint *)(iStack_18 + 4) < (uint)puVar7[5])
             ) {
            puVar8 = puVar7;
          }
          puVar5 = (undefined4 *)*puVar7;
          param_1 = puVar7;
        }
        puVar7 = puVar5;
      } while (*(char *)((int)puVar5 + 0xd) == '\0');
    }
    puVar7 = param_1;
    if (*(char *)((int)puVar8 + 0xd) == '\0') {
      puVar4 = (undefined4 *)*puVar8;
    }
    piVar1 = piStack_1c;
    if (*(char *)((int)puVar4 + 0xd) == '\0') {
      do {
        if (*(uint *)(iStack_18 + 4) < (uint)puVar4[5]) {
          puVar5 = (undefined4 *)*puVar4;
          puVar8 = puVar4;
        }
        else {
          puVar5 = (undefined4 *)puVar4[2];
        }
        puVar4 = puVar5;
      } while (*(char *)((int)puVar5 + 0xd) == '\0');
    }
    while (piStack_1c = piVar1, param_1 != puVar8) {
      FUN_00551320();
      piVar1 = piStack_1c;
    }
    FUN_0094e3b0(&param_1,puVar7,puVar8);
    uStack_8._0_1_ = 0;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_28[2] + -1;
      piStack_28[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
    iVar3 = iStack_24;
    if (piVar1[1] == 0) {
      if (piVar9 != (int *)0x0) {
        LOCK();
        piVar9[1] = piVar9[1] + 1;
        UNLOCK();
      }
      iStack_2c = iStack_24;
      piStack_28 = piVar9;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (*(int *)(iStack_24 + 0x10) != 0) {
        FUN_01679490();
      }
      if (*(int *)(iVar3 + 0x18) != 0) {
        FUN_01679490();
      }
      if (*(int *)(iVar3 + 0x20) != 0) {
        FUN_01679490();
      }
      puVar8 = *(undefined4 **)(iStack_14 + 0x88);
      puVar4 = (undefined4 *)puVar8[1];
      cVar2 = *(char *)((int)puVar4 + 0xd);
      puVar7 = puVar8;
      puVar5 = puVar4;
      while (cVar2 == '\0') {
        if ((uint)puVar5[5] < *(uint *)(iStack_24 + 4)) {
          puVar6 = (undefined4 *)puVar5[2];
          puVar5 = puVar7;
        }
        else {
          if ((*(char *)((int)puVar8 + 0xd) != '\0') && (*(uint *)(iStack_24 + 4) < (uint)puVar5[5])
             ) {
            puVar8 = puVar5;
          }
          puVar6 = (undefined4 *)*puVar5;
        }
        puVar7 = puVar5;
        puVar5 = puVar6;
        piVar9 = piStack_20;
        cVar2 = *(char *)((int)puVar6 + 0xd);
      }
      if (*(char *)((int)puVar8 + 0xd) == '\0') {
        puVar4 = (undefined4 *)*puVar8;
      }
      param_1 = puVar7;
      if (*(char *)((int)puVar4 + 0xd) == '\0') {
        do {
          if (*(uint *)(iStack_24 + 4) < (uint)puVar4[5]) {
            puVar5 = (undefined4 *)*puVar4;
            puVar8 = puVar4;
          }
          else {
            puVar5 = (undefined4 *)puVar4[2];
          }
          puVar4 = puVar5;
        } while (*(char *)((int)puVar5 + 0xd) == '\0');
      }
      while (param_1 != puVar8) {
        FUN_00551320();
      }
      FUN_00ba4780(&param_1,puVar7,puVar8);
      uStack_8._0_1_ = 0;
      if (piVar9 != (int *)0x0) {
        LOCK();
        iVar3 = piVar9[1] + -1;
        piVar9[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar9)();
          LOCK();
          iVar3 = piVar9[2] + -1;
          piVar9[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
    }
    FUN_00bacff0(iStack_14);
    FUN_00b77230(param_2);
    iStack_24 = FUN_005e6780(param_2);
  }
  if (piVar9 != (int *)0x0) {
    LOCK();
    piVar1 = piVar9 + 1;
    iVar3 = *piVar1;
    iStack_24 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iStack_24 = (**(code **)*piVar9)();
      LOCK();
      piVar1 = piVar9 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iStack_24 = (**(code **)(*piVar9 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iStack_24;
}



/* FUNCTION 25799 ; VA 0x00baf2d0 ; FUN_00baf2d0 */

int * __thiscall FUN_00baf2d0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00bb1ae0();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 25800 ; VA 0x00baf320 ; FUN_00baf320 */

int * __thiscall FUN_00baf320(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00bb1b50();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 25801 ; VA 0x00baf370 ; FUN_00baf370 */

undefined * FUN_00baf370(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd03c;
  pvStack_10 = ExceptionList;
  if (DAT_01ef3108 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef3318) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef3318);
      if (DAT_01ef3318 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"VRService",1,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_018917d0);
        FUN_016f37bf(&DAT_01ef3318);
      }
    }
    DAT_01ef3108 = &DAT_01ef3110;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef3108;
}



/* FUNCTION 25802 ; VA 0x00baf450 ; FUN_00baf450 */

void FUN_00baf450(void)

{
  int iVar1;
  
  if (DAT_01ef331c == 0) {
    iVar1 = FUN_00baf370();
    DAT_01ef331c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 25803 ; VA 0x00baf470 ; FUN_00baf470 */

int * __fastcall FUN_00baf470(int *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  int *piStack_8;
  
  iVar3 = *param_1;
  piStack_8 = param_1;
  iVar2 = FUN_00b849a0();
  if (iVar3 == iVar2) {
    piVar6 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar6 = (int *)0x0;
    }
    if (piVar6 != (int *)0x0) {
      return piVar6;
    }
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 != iVar2) {
LAB_00baf50b:
    thunk_FUN_00b849a0();
    uVar4 = FUN_005543f0();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar5,uVar4);
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 == iVar2) {
    iVar3 = param_1[1];
    FUN_00b849a0();
    piVar7 = param_1 + 2;
    piVar6 = piVar7;
    if (iVar3 == 0) {
      piVar6 = (int *)0x0;
    }
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    cVar1 = FUN_009cb180(piVar6,&piStack_8);
    if (cVar1 == '\0') goto LAB_00baf50b;
    FUN_00b79ff0(&piStack_8);
    iVar3 = FUN_00b849a0();
    *param_1 = iVar3;
    iVar2 = FUN_00b849a0();
    if (iVar3 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25804 ; VA 0x00baf540 ; FUN_00baf540 */

int __fastcall FUN_00baf540(int param_1)

{
  int iVar1;
  int iVar2;
  
  do {
    param_1 = *(int *)(param_1 + 0x34);
    if (param_1 == 0) {
      return 0;
    }
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00c68a10();
  } while ((uint)*(ushort *)(iVar2 + 0x1da) <
           (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8));
  return param_1;
}



/* FUNCTION 25805 ; VA 0x00baf580 ; thunk_FUN_00b849a0 */

undefined * thunk_FUN_00b849a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8b6c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef1a84) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef1a84);
    if (DAT_01ef1a84 == -1) {
      uStack_8 = 0;
      FUN_00baf9b0();
      FUN_016f3654(&LAB_018903c0);
      FUN_016f37bf(&DAT_01ef1a84);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef1a20;
}



/* FUNCTION 25806 ; VA 0x00baf590 ; thunk_FUN_00bb1980 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00bb1980(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd516;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef3404) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef3404);
    if (DAT_01ef3404 == -1) {
      uStack_8 = 0;
      FUN_009ca470("VRTouchpad");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef33a0 = RBX::Reflection::EnumDesc<enum_RBX::VRService::VRTouchpad>::vftable;
      FUN_009caf20(&DAT_01d67a28,2);
      FUN_016f3654(&LAB_01891730);
      FUN_016f37bf(&DAT_01ef3404);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef33a0;
}



/* FUNCTION 25807 ; VA 0x00baf5a0 ; thunk_FUN_00bb1a30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00bb1a30(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd536;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef339c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef339c);
    if (DAT_01ef339c == -1) {
      uStack_8 = 0;
      FUN_009ca470("VRTouchpadMode");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef3338 = RBX::Reflection::EnumDesc<enum_RBX::VRService::VRTouchpadMode>::vftable;
      FUN_009caf20(&DAT_01d67a38,3);
      FUN_016f3654(&LAB_01891750);
      FUN_016f37bf(&DAT_01ef339c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef3338;
}



/* FUNCTION 25808 ; VA 0x00baf5b0 ; FUN_00baf5b0 */

undefined4 FUN_00baf5b0(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 < param_3) {
LAB_00baf72d:
    uStack_8 = 0xffffffff;
    if ((undefined4 *)*param_5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar4);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_5;
  }
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar1 = FUN_009d1bf0(param_1,param_2,&iStack_ec,1);
  iVar5 = iStack_ec;
  if (cVar1 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    goto LAB_00baf72d;
  }
  iVar2 = FUN_00bb1980();
  iVar4 = iStack_ec;
  if (iVar5 == iVar2) {
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    if (puVar3 != (undefined4 *)0x0) goto LAB_00baf6d8;
  }
  iVar2 = FUN_0088cb40();
  iVar5 = iStack_ec;
  if (iVar4 == iVar2) {
    iVar4 = FUN_0088cb40();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    FUN_00bb1980();
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    cVar1 = FUN_009cb180(puVar3,&param_3);
    if (cVar1 != '\0') {
      FUN_00baf2d0(&param_3);
      iVar4 = FUN_00bb1980();
      iStack_ec = iVar4;
      iVar5 = FUN_00bb1980();
      if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar3 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
LAB_00baf6d8:
      uVar6 = *puVar3;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
  }
  thunk_FUN_00bb1980();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 25809 ; VA 0x00baf7b0 ; FUN_00baf7b0 */

undefined4 FUN_00baf7b0(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 < param_3) {
LAB_00baf92d:
    uStack_8 = 0xffffffff;
    if ((undefined4 *)*param_5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar4);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_5;
  }
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar1 = FUN_009d1bf0(param_1,param_2,&iStack_ec,1);
  iVar5 = iStack_ec;
  if (cVar1 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    goto LAB_00baf92d;
  }
  iVar2 = FUN_00bb1a30();
  iVar4 = iStack_ec;
  if (iVar5 == iVar2) {
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    if (puVar3 != (undefined4 *)0x0) goto LAB_00baf8d8;
  }
  iVar2 = FUN_0088cb40();
  iVar5 = iStack_ec;
  if (iVar4 == iVar2) {
    iVar4 = FUN_0088cb40();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    FUN_00bb1a30();
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    cVar1 = FUN_009cb180(puVar3,&param_3);
    if (cVar1 != '\0') {
      FUN_00baf320(&param_3);
      iVar4 = FUN_00bb1a30();
      iStack_ec = iVar4;
      iVar5 = FUN_00bb1a30();
      if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar3 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
LAB_00baf8d8:
      uVar6 = *puVar3;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
  }
  thunk_FUN_00bb1a30();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 25810 ; VA 0x00baf9b0 ; FUN_00baf9b0 */

undefined4 * __fastcall FUN_00baf9b0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("UserCFrame");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::VRService::UserCFrame>::vftable;
  FUN_009caf20(&DAT_01d67a10,3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25811 ; VA 0x00bafa10 ; FUN_00bafa10 */

undefined4 * __fastcall FUN_00bafa10(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint auStack_2c [4];
  int iStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd0ad;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::VRService,class_RBX::ServiceInstance>::vftable;
  uVar1 = FUN_00baf370();
  param_1[3] = uVar1;
  *param_1 = RBX::VRService::vftable;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  uStack_8 = 6;
  *(undefined2 *)(param_1 + 0x1b) = 0;
  iVar4 = 3;
  do {
    FUN_0060efa0();
    iVar4 = iVar4 + -1;
  } while (iVar4 != 0);
  param_1[0x41] = 0;
  iVar4 = 2;
  do {
    FUN_00569440();
    iVar4 = iVar4 + -1;
  } while (iVar4 != 0);
  param_1[0x50] = 0;
  param_1[0x51] = 0xf;
  *(undefined *)(param_1 + 0x4c) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 7;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  iStack_1c = iVar4;
  FUN_005542c0("VRService",9);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  *(undefined2 *)(param_1 + 0x40) = 0;
  *(undefined *)((int)param_1 + 0x102) = 0;
  param_1[0x42] = 1;
  param_1[0x43] = 1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25812 ; VA 0x00bafb80 ; FUN_00bafb80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00bafb80(int param_1,uint *param_2)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fd0c8;
  pvStack_10 = ExceptionList;
  uVar2 = *param_2;
  uVar9 = uVar2 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar6 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      puVar6 = (undefined4 *)*puVar6;
    }
    for (; puVar6 != (undefined4 *)0x0; puVar6 = (undefined4 *)*puVar6) {
      if (uVar2 == puVar6[1]) {
        if (uVar2 == puVar6[2]) {
          if (puVar6 != (undefined4 *)0x0) {
            return puVar6 + 2;
          }
          break;
        }
      }
      else if ((uint)puVar6[1] % *(uint *)(param_1 + 4) != uVar9) break;
    }
  }
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00619db0();
  _DAT_0000000c = 0;
  _DAT_00000010 = 0;
  uVar3 = *(uint *)(param_1 + 8);
  uVar9 = uVar3 + 1;
  _DAT_00000008 = uVar2;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar9 = FUN_005d6bb0(uVar9);
    if (uVar9 <= *(uint *)(param_1 + 4)) {
      uVar9 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar9);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar9) {
    uVar7 = uVar3 >> 1;
    if (uVar3 + (uVar3 >> 1) <= uVar9) {
      uVar7 = 1;
    }
    iVar5 = FUN_005d6bb0(uVar7 + *(int *)(param_1 + 8));
    if (iVar5 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar5);
      puVar6 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar4 = (undefined4 *)*puVar6;
      while (puVar4 != (undefined4 *)0x0) {
        uVar9 = (uint)puVar4[1] % *(uint *)(param_1 + 4);
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + uVar9 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar9 * 4) == 0) {
          *piVar1 = (int)puVar6;
          puVar6 = puVar4;
        }
        else {
          *puVar6 = *puVar4;
          *puVar4 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar4;
        }
        puVar4 = (undefined4 *)*puVar6;
      }
    }
  }
  piVar1 = (int *)(*(int *)(param_1 + 0x14) + (uVar2 % *(uint *)(param_1 + 4)) * 4);
  _DAT_00000004 = uVar2;
  if ((int *)*piVar1 == (int *)0x0) {
    piVar8 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar8 != 0) {
      *(undefined4 *)
       (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar8 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
    }
    *piVar1 = (int)piVar8;
    _DAT_00000000 = *piVar8;
  }
  else {
    _DAT_00000000 = *(int *)*piVar1;
    piVar8 = (int *)*piVar1;
  }
  *piVar8 = 0;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return (undefined4 *)&DAT_00000008;
}



/* FUNCTION 25813 ; VA 0x00bafd40 ; FUN_00bafd40 */

/* WARNING: Removing unreachable block (ram,0x00bafd9e) */
/* WARNING: Removing unreachable block (ram,0x00bafdae) */
/* WARNING: Removing unreachable block (ram,0x00bafdb4) */

void __fastcall FUN_00bafd40(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd0f0;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8 = 2;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = 4;
    FUN_01675290(uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25814 ; VA 0x00bafe0b ; Catch@00bafe0b */

undefined * Catch_00bafe0b(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x20));
  return &DAT_00bafe1c;
}



/* FUNCTION 25815 ; VA 0x00bafe30 ; FUN_00bafe30 */

int __thiscall FUN_00bafe30(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),0x30);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 25816 ; VA 0x00bafe80 ; FUN_00bafe80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00bafe80(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::VRService::VRTouchpad>::vftable;
  _DAT_01ef3328 = _DAT_01ef3328 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 25817 ; VA 0x00bafeb0 ; FUN_00bafeb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00bafeb0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::VRService::VRTouchpadMode>::vftable;
  _DAT_01ef3330 = _DAT_01ef3330 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 25818 ; VA 0x00bafee0 ; FUN_00bafee0 */

undefined4 * __thiscall FUN_00bafee0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::VRService::UserCFrame>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 25819 ; VA 0x00baff10 ; FUN_00baff10 */

undefined4 * __thiscall FUN_00baff10(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::VRService::UserCFrame>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 25820 ; VA 0x00baff40 ; FUN_00baff40 */

int __thiscall FUN_00baff40(int param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x144);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x130);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x140) = 0;
  *(undefined4 *)(param_1 + 0x144) = 0xf;
  *(undefined *)(param_1 + 0x130) = 0;
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x148);
  }
  return param_1;
}



/* FUNCTION 25821 ; VA 0x00bafff0 ; FUN_00bafff0 */

undefined __fastcall FUN_00bafff0(int param_1)

{
  undefined uVar1;
  
  uVar1 = *(undefined *)(param_1 + 0x6d);
  *(undefined *)(param_1 + 0x6d) = 0;
  return uVar1;
}



/* FUNCTION 25822 ; VA 0x00bb0000 ; FUN_00bb0000 */

undefined4 * __thiscall
FUN_00bb0000(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fd451;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00bb0a40;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25823 ; VA 0x00bb01a0 ; FUN_00bb01a0 */

undefined4 * __thiscall
FUN_00bb01a0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fd491;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00bb0b50;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25824 ; VA 0x00bb0340 ; FUN_00bb0340 */

undefined4 * __thiscall
FUN_00bb0340(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fd4d1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00bb0c80;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25825 ; VA 0x00bb04e0 ; FUN_00bb04e0 */

void FUN_00bb04e0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00bb1980();
    *param_2 = uVar3;
    iVar4 = FUN_00bb1ae0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 25826 ; VA 0x00bb0540 ; FUN_00bb0540 */

void FUN_00bb0540(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00bb1a30();
    *param_2 = uVar3;
    iVar4 = FUN_00bb1b50();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 25827 ; VA 0x00bb05a0 ; FUN_00bb05a0 */

void FUN_00bb05a0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00bb1980();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25828 ; VA 0x00bb05e0 ; FUN_00bb05e0 */

void FUN_00bb05e0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00bb1a30();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25829 ; VA 0x00bb0620 ; FUN_00bb0620 */

void __thiscall FUN_00bb0620(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd560;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar4 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_00a93d20(iVar1);
    uVar4 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar4;
  uVar2 = FUN_00b00260();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar5 = &uStack_28c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_ec = FUN_00b849a0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar5;
    iStack_e8 = FUN_00b84b30();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_00b849a0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_e8 != 0)) {
    (**(code **)(iStack_e8 + 8))(auStack_e4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25830 ; VA 0x00bb0820 ; FUN_00bb0820 */

void __thiscall FUN_00bb0820(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 auStack_1b4 [50];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar1 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  puVar4 = *(undefined4 **)(param_1 + 0x40);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar3 = 2;
  }
  else {
    uStack_ec = FUN_00bb1980();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar4;
    iStack_e8 = FUN_00bb1ae0();
    puStack_18 = &uStack_ec;
    uVar3 = 1;
  }
  uStack_8 = (uint)(puVar4 == (undefined4 *)0x0);
  uStack_14 = uVar3;
  uVar1 = FUN_00bb1980();
  uVar2 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar2,uVar1,puStack_18);
  if ((uVar3 & 2) != 0) {
    uVar3 = uVar3 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar3;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar3 & 1) != 0) {
    uVar3 = uVar3 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar3;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 5;
    uVar3 = uVar3 | 8;
  }
  else {
    uStack_1bc = FUN_00bb1a30();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar4;
    iStack_1b8 = FUN_00bb1b50();
    puVar4 = &uStack_1bc;
    uStack_8 = 4;
    uVar3 = uVar3 | 4;
  }
  uStack_14 = uVar3;
  uVar1 = FUN_00bb1a30();
  uVar2 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar2,uVar1,puVar4);
  if ((uVar3 & 8) != 0) {
    uVar3 = uVar3 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar3;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar3 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25831 ; VA 0x00bb0a40 ; FUN_00bb0a40 */

void FUN_00bb0a40(int param_1)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 in_stack_00000038;
  undefined auStack_1c0 [208];
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8524;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  FUN_00a93d20(&stack0x00000008);
  iStack_8._0_1_ = 1;
  uStack_f0 = FUN_00b849a0();
  uStack_ec = 0;
  uStack_e8 = in_stack_00000038;
  uStack_ec = FUN_00b84b30();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(auStack_1c0,&uStack_20,piVar1);
  iStack_8._0_1_ = 3;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 4;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1c0,0xd0,2,FUN_0056e5b0);
  iStack_8 = 5;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25832 ; VA 0x00bb0b50 ; FUN_00bb0b50 */

void FUN_00bb0b50(int param_1,undefined4 param_2,undefined param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8524;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_1c0 = FUN_00b849a0();
  uStack_1bc = 0;
  uStack_1b8 = param_2;
  uStack_1bc = FUN_00b84b30();
  iStack_8._0_1_ = 1;
  uStack_f0 = FUN_0088daf0();
  uStack_ec = 0;
  uStack_e8 = param_3;
  uStack_ec = FUN_005c9ef0();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,piVar1);
  iStack_8._0_1_ = 3;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 4;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  iStack_8 = 5;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25833 ; VA 0x00bb0c80 ; FUN_00bb0c80 */

void FUN_00bb0c80(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8524;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_1c0 = FUN_00bb1980();
  uStack_1bc = 0;
  uStack_1b8 = param_2;
  uStack_1bc = FUN_00bb1ae0();
  iStack_8._0_1_ = 1;
  uStack_f0 = FUN_00bb1a30();
  uStack_ec = 0;
  uStack_e8 = param_3;
  uStack_ec = FUN_00bb1b50();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,piVar1);
  iStack_8._0_1_ = 3;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 4;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  iStack_8 = 5;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25834 ; VA 0x00bb0db0 ; FUN_00bb0db0 */

undefined4 __thiscall FUN_00bb0db0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined auStack_70 [48];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  
  iVar1 = FUN_01256300(param_3);
  uVar2 = FUN_00b82000(param_3,param_4,1,iVar1 - param_4,param_1 + 0x40);
  puVar3 = (undefined4 *)(**(code **)(param_1 + 0x38))(auStack_70,uVar2);
  uStack_20 = *puVar3;
  uStack_1c = puVar3[1];
  uStack_18 = puVar3[2];
  uStack_14 = puVar3[3];
  uStack_30 = puVar3[4];
  uStack_2c = puVar3[5];
  uStack_28 = puVar3[6];
  uStack_24 = puVar3[7];
  uStack_40 = puVar3[8];
  uStack_3c = puVar3[9];
  uStack_38 = puVar3[10];
  uStack_34 = puVar3[0xb];
  puVar3 = (undefined4 *)FUN_0087ddc0(param_3,PTR_DAT_01d6d364,0x30,DAT_01ede6d4);
  *puVar3 = uStack_20;
  puVar3[1] = uStack_1c;
  puVar3[2] = uStack_18;
  puVar3[3] = uStack_14;
  puVar3[4] = uStack_30;
  puVar3[5] = uStack_2c;
  puVar3[6] = uStack_28;
  puVar3[7] = uStack_24;
  puVar3[8] = uStack_40;
  puVar3[9] = uStack_3c;
  puVar3[10] = uStack_38;
  puVar3[0xb] = uStack_34;
  return 1;
}



/* FUNCTION 25835 ; VA 0x00bb0e60 ; FUN_00bb0e60 */

undefined4 __thiscall FUN_00bb0e60(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  
  uVar1 = param_3;
  iVar3 = FUN_01256300(param_3);
  iVar3 = iVar3 - param_4;
  if (0 < iVar3) {
    uVar4 = FUN_00bb1980();
    cVar2 = FUN_009d1e20(uVar4,uVar1,param_4 + 1,&param_3);
    uVar4 = param_3;
    if (cVar2 != '\0') goto LAB_00bb0eb6;
  }
  uVar4 = FUN_00baf5b0(uVar1,param_4,1,iVar3,param_1 + 0x40);
LAB_00bb0eb6:
  uVar4 = (**(code **)(param_1 + 0x38))(uVar4);
  FUN_00bb1a30();
  iVar3 = FUN_009cb050(uVar4);
  if (iVar3 == 0) {
    FUN_01256980(uVar1);
    return 1;
  }
  FUN_00880a00(uVar1,iVar3);
  return 1;
}



/* FUNCTION 25836 ; VA 0x00bb0f10 ; FUN_00bb0f10 */

undefined4 FUN_00bb0f10(undefined4 param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined4 uStack_118;
  int iStack_114;
  undefined auStack_110 [200];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd4eb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_2);
  iVar2 = iVar2 - param_3;
  uStack_18 = FUN_00b82000(param_2,param_3,2,iVar2,iStack_14 + 0x44);
  if (iVar2 < 1) {
LAB_00bb0f94:
    param_3 = param_3 + 1;
    if (0 < iVar2) {
      uStack_118 = FUN_00888530();
      iStack_114 = 0;
      uStack_8 = 0;
      cVar1 = FUN_009d1bf0(param_2,param_3,&uStack_118,1);
      if (cVar1 != '\0') {
        puVar3 = (undefined4 *)FUN_0088ab30();
        uStack_28 = *puVar3;
        uStack_24 = puVar3[1];
        uStack_20 = puVar3[2];
        uStack_1c = puVar3[3];
        uStack_38 = puVar3[4];
        uStack_34 = puVar3[5];
        uStack_30 = puVar3[6];
        uStack_2c = puVar3[7];
        uStack_48 = puVar3[8];
        uStack_44 = puVar3[9];
        uStack_40 = puVar3[10];
        uStack_3c = puVar3[0xb];
        uStack_8 = 1;
        if (iStack_114 != 0) {
          (**(code **)(iStack_114 + 8))(auStack_110);
        }
        uStack_8 = 0xffffffff;
        uVar4 = uStack_28;
        uVar5 = uStack_24;
        uVar6 = uStack_20;
        uVar7 = uStack_1c;
        uVar8 = uStack_38;
        uVar9 = uStack_34;
        uVar10 = uStack_30;
        uVar11 = uStack_2c;
        uVar12 = uStack_48;
        uVar13 = uStack_44;
        uVar14 = uStack_40;
        uVar15 = uStack_3c;
        goto LAB_00bb1065;
      }
      uStack_8 = 2;
      if (iStack_114 != 0) {
        (**(code **)(iStack_114 + 8))(auStack_110);
      }
      uStack_8 = 0xffffffff;
    }
    puVar3 = *(undefined4 **)(iStack_14 + 0x40);
    if (puVar3 == (undefined4 *)0x0) {
      FUN_016756b0(&uStack_24,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(&uStack_24,&DAT_01c17198);
    }
  }
  else {
    FUN_0060efa0();
    puVar3 = (undefined4 *)FUN_01257810(param_2,param_3 + 1,DAT_01ede6d4);
    if (puVar3 == (undefined4 *)0x0) goto LAB_00bb0f94;
  }
  uVar4 = *puVar3;
  uVar5 = puVar3[1];
  uVar6 = puVar3[2];
  uVar7 = puVar3[3];
  uVar8 = puVar3[4];
  uVar9 = puVar3[5];
  uVar10 = puVar3[6];
  uVar11 = puVar3[7];
  uVar12 = puVar3[8];
  uVar13 = puVar3[9];
  uVar14 = puVar3[10];
  uVar15 = puVar3[0xb];
LAB_00bb1065:
  (**(code **)(iStack_14 + 0x38))
            (uVar4,uVar5,uVar6,uVar7,uVar8,uVar9,uVar10,uVar11,uVar12,uVar13,uVar14,uVar15,uStack_18
            );
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 25837 ; VA 0x00bb10c0 ; FUN_00bb10c0 */

undefined4 FUN_00bb10c0(undefined4 param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uStack_c;
  int iStack_8;
  
  uVar1 = param_2;
  iVar3 = FUN_01256300(param_2);
  iVar3 = iVar3 - param_3;
  if (iVar3 < 2) {
LAB_00bb1104:
    param_2 = FUN_00baf7b0(uVar1,param_3,2,iVar3,iStack_8 + 0x44);
  }
  else {
    uVar4 = FUN_00bb1a30();
    cVar2 = FUN_009d1e20(uVar4,uVar1,param_3 + 2,&param_2);
    if (cVar2 == '\0') goto LAB_00bb1104;
  }
  if (0 < iVar3) {
    uVar4 = FUN_00bb1980();
    cVar2 = FUN_009d1e20(uVar4,uVar1,param_3 + 1,&uStack_c);
    if (cVar2 != '\0') goto LAB_00bb115b;
  }
  uStack_c = FUN_00baf5b0(uVar1,param_3,1,iVar3,iStack_8 + 0x40);
LAB_00bb115b:
  (**(code **)(iStack_8 + 0x38))(uStack_c,param_2);
  return 0;
}



/* FUNCTION 25838 ; VA 0x00bb1180 ; FUN_00bb1180 */

void __thiscall FUN_00bb1180(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_01256300(param_3);
  uVar2 = FUN_00b82000(param_3,param_4,1,iVar1 - param_4,param_1 + 0x40);
  uVar2 = (**(code **)(param_1 + 0x38))(uVar2);
  FUN_009d5ac0(param_3,uVar2);
  return;
}



/* FUNCTION 25839 ; VA 0x00bb11d0 ; FUN_00bb11d0 */

void FUN_00bb11d0(undefined4 param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  
  iVar1 = *param_2;
  iVar5 = *(int *)(iVar1 + 0xd0);
  iVar3 = FUN_00b849a0();
  if (iVar5 == iVar3) {
    puVar4 = (undefined4 *)(iVar1 + 0xd8);
    if (*(int *)(iVar1 + 0xd4) == 0) {
      puVar4 = (undefined4 *)0x0;
    }
    uVar2 = *puVar4;
    param_2 = (int *)*param_2;
    iVar1 = *param_2;
    iVar5 = FUN_00b00260();
    if (iVar1 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
      FUN_00bafd40(*piVar6,piVar6[1],piVar6[2],piVar6[3],piVar6[4],piVar6[5],piVar6[6],piVar6[7],
                   piVar6[8],piVar6[9],piVar6[10],piVar6[0xb],uVar2);
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25840 ; VA 0x00bb1260 ; FUN_00bb1260 */

void FUN_00bb1260(undefined4 param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  int iVar14;
  undefined4 *puVar15;
  int iVar16;
  int *piVar17;
  
  iVar1 = *param_2;
  iVar16 = *(int *)(iVar1 + 0xd0);
  iVar14 = FUN_00b00260();
  if (iVar16 == iVar14) {
    puVar15 = (undefined4 *)(iVar1 + 0xd8);
    if (*(int *)(iVar1 + 0xd4) == 0) {
      puVar15 = (undefined4 *)0x0;
    }
    uVar2 = *puVar15;
    uVar3 = puVar15[1];
    uVar4 = puVar15[2];
    uVar5 = puVar15[3];
    uVar6 = puVar15[4];
    uVar7 = puVar15[5];
    uVar8 = puVar15[6];
    uVar9 = puVar15[7];
    uVar10 = puVar15[8];
    uVar11 = puVar15[9];
    uVar12 = puVar15[10];
    uVar13 = puVar15[0xb];
    param_2 = (int *)*param_2;
    iVar1 = *param_2;
    iVar16 = FUN_00b849a0();
    if (iVar1 == iVar16) {
      piVar17 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar17 = (int *)0x0;
      }
      FUN_00b7d0c0(*piVar17,uVar2,uVar3,uVar4,uVar5,uVar6,uVar7,uVar8,uVar9,uVar10,uVar11,uVar12,
                   uVar13);
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25841 ; VA 0x00bb1320 ; FUN_00bb1320 */

void FUN_00bb1320(undefined4 param_1,int *param_2)

{
  undefined uVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined *puVar5;
  int iVar6;
  int *piVar7;
  
  iVar2 = *param_2;
  iVar6 = *(int *)(iVar2 + 0xd0);
  iVar4 = FUN_0088daf0();
  if (iVar6 == iVar4) {
    puVar5 = (undefined *)(iVar2 + 0xd8);
    piVar3 = (int *)*param_2;
    if (*(int *)(iVar2 + 0xd4) == 0) {
      puVar5 = (undefined *)0x0;
    }
    iVar2 = *piVar3;
    uVar1 = *puVar5;
    param_2 = (int *)CONCAT13(uVar1,param_2._0_3_);
    iVar6 = FUN_00b849a0();
    if (iVar2 == iVar6) {
      piVar7 = piVar3 + 2;
      if (piVar3[1] == 0) {
        piVar7 = (int *)0x0;
      }
      param_2 = (int *)CONCAT31(param_2._1_3_,uVar1);
      FUN_005e66b0(*piVar7,param_2);
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25842 ; VA 0x00bb13a0 ; FUN_00bb13a0 */

void FUN_00bb13a0(undefined4 param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  
  iVar1 = *param_2;
  iVar5 = *(int *)(iVar1 + 0xd0);
  iVar3 = FUN_00bb1a30();
  if (iVar5 == iVar3) {
    puVar4 = (undefined4 *)(iVar1 + 0xd8);
    param_2 = (int *)*param_2;
    if (*(int *)(iVar1 + 0xd4) == 0) {
      puVar4 = (undefined4 *)0x0;
    }
    iVar1 = *param_2;
    uVar2 = *puVar4;
    iVar5 = FUN_00bb1980();
    if (iVar1 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
      FUN_006150c0(*piVar6,uVar2);
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25843 ; VA 0x00bb1440 ; FUN_00bb1440 */

undefined __thiscall FUN_00bb1440(int param_1,int param_2)

{
  return *(undefined *)(param_2 + 0x100 + param_1);
}



/* FUNCTION 25844 ; VA 0x00bb1460 ; FUN_00bb1460 */

undefined4 __thiscall FUN_00bb1460(int param_1,int param_2)

{
  return *(undefined4 *)(param_1 + 0x108 + param_2 * 4);
}



/* FUNCTION 25845 ; VA 0x00bb1480 ; FUN_00bb1480 */

void __thiscall FUN_00bb1480(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_00b849a0();
  *param_3 = uVar3;
  iVar4 = FUN_00b84b30();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 25846 ; VA 0x00bb14e0 ; FUN_00bb14e0 */

undefined4 __fastcall FUN_00bb14e0(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_0097bfc0(param_1);
  if (iVar1 != 0) {
    uVar2 = FUN_00928330();
    return uVar2;
  }
  return 1;
}



/* FUNCTION 25847 ; VA 0x00bb1500 ; FUN_00bb1500 */

void FUN_00bb1500(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00bb1980();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25848 ; VA 0x00bb1540 ; FUN_00bb1540 */

void FUN_00bb1540(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00bb1a30();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25849 ; VA 0x00bb1580 ; FUN_00bb1580 */

void __thiscall FUN_00bb1580(int param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  float10 fVar2;
  
  if ((param_2 != 0) && (*(char *)(param_1 + 0x6c) != '\0')) {
    iVar1 = FUN_008f7870(param_2);
    if (iVar1 != 0) {
      fVar2 = (float10)FUN_008f7ed0(&DAT_018ccd30,0);
      FUN_0087c7b0(&DAT_018c5f98,"VRTimeMS",(int)(fVar2 * (float10)DAT_018c0d70));
    }
  }
  FUN_008a4210(param_2,param_3);
  return;
}



/* FUNCTION 25850 ; VA 0x00bb1600 ; FUN_00bb1600 */

void FUN_00bb1600(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13)

{
  FUN_00bafd40(param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,
               param_11,param_12,param_13);
  return;
}



/* FUNCTION 25851 ; VA 0x00bb1630 ; FUN_00bb1630 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00bb1630(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  
  uVar10 = _UNK_018e3fbc;
  uVar7 = _UNK_018e3fb8;
  uVar4 = _UNK_018e3fb4;
  uVar1 = _DAT_018e3fb0;
  *(undefined4 *)(param_1 + 0x70) = _DAT_018e3fb0;
  *(undefined4 *)(param_1 + 0x74) = uVar4;
  *(undefined4 *)(param_1 + 0x78) = uVar7;
  *(undefined4 *)(param_1 + 0x7c) = uVar10;
  uVar11 = _UNK_018e3fbc;
  uVar8 = _UNK_018e3fb8;
  uVar5 = _UNK_018e3fb4;
  uVar2 = _DAT_018e3fb0;
  *(undefined4 *)(param_1 + 0x80) = uVar1;
  *(undefined4 *)(param_1 + 0x84) = uVar4;
  *(undefined4 *)(param_1 + 0x88) = uVar7;
  *(undefined4 *)(param_1 + 0x8c) = uVar10;
  uVar12 = _UNK_018e3fbc;
  uVar9 = _UNK_018e3fb8;
  uVar6 = _UNK_018e3fb4;
  uVar3 = _DAT_018e3fb0;
  *(undefined4 *)(param_1 + 0x90) = uVar1;
  *(undefined4 *)(param_1 + 0x94) = uVar4;
  *(undefined4 *)(param_1 + 0x98) = uVar7;
  *(undefined4 *)(param_1 + 0x9c) = uVar10;
  uVar10 = _UNK_018e3fbc;
  uVar7 = _UNK_018e3fb8;
  uVar4 = _UNK_018e3fb4;
  uVar1 = _DAT_018e3fb0;
  *(undefined4 *)(param_1 + 0xa0) = uVar2;
  *(undefined4 *)(param_1 + 0xa4) = uVar5;
  *(undefined4 *)(param_1 + 0xa8) = uVar8;
  *(undefined4 *)(param_1 + 0xac) = uVar11;
  uVar11 = _UNK_018e3fbc;
  uVar8 = _UNK_018e3fb8;
  uVar5 = _UNK_018e3fb4;
  uVar2 = _DAT_018e3fb0;
  *(undefined4 *)(param_1 + 0xb0) = uVar3;
  *(undefined4 *)(param_1 + 0xb4) = uVar6;
  *(undefined4 *)(param_1 + 0xb8) = uVar9;
  *(undefined4 *)(param_1 + 0xbc) = uVar12;
  uVar12 = _UNK_018e3fbc;
  uVar9 = _UNK_018e3fb8;
  uVar6 = _UNK_018e3fb4;
  uVar3 = _DAT_018e3fb0;
  *(undefined4 *)(param_1 + 0xc0) = uVar1;
  *(undefined4 *)(param_1 + 0xc4) = uVar4;
  *(undefined4 *)(param_1 + 200) = uVar7;
  *(undefined4 *)(param_1 + 0xcc) = uVar10;
  uVar10 = _UNK_018e3fbc;
  uVar7 = _UNK_018e3fb8;
  uVar4 = _UNK_018e3fb4;
  uVar1 = _DAT_018e3fb0;
  *(undefined4 *)(param_1 + 0xd0) = uVar2;
  *(undefined4 *)(param_1 + 0xd4) = uVar5;
  *(undefined4 *)(param_1 + 0xd8) = uVar8;
  *(undefined4 *)(param_1 + 0xdc) = uVar11;
  *(undefined4 *)(param_1 + 0xe0) = uVar3;
  *(undefined4 *)(param_1 + 0xe4) = uVar6;
  *(undefined4 *)(param_1 + 0xe8) = uVar9;
  *(undefined4 *)(param_1 + 0xec) = uVar12;
  *(undefined4 *)(param_1 + 0xf0) = uVar1;
  *(undefined4 *)(param_1 + 0xf4) = uVar4;
  *(undefined4 *)(param_1 + 0xf8) = uVar7;
  *(undefined4 *)(param_1 + 0xfc) = uVar10;
  return;
}



/* FUNCTION 25852 ; VA 0x00bb16b0 ; FUN_00bb16b0 */

void __thiscall FUN_00bb16b0(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0x104) != param_2) {
    *(int *)(param_1 + 0x104) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25853 ; VA 0x00bb16e0 ; FUN_00bb16e0 */

void __thiscall FUN_00bb16e0(int param_1,int param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  int iVar5;
  
  iVar5 = param_2 * 0x30 + param_1;
  if (((((NAN(*(float *)(iVar5 + 0x94)) || NAN((float)param_3[9])) ==
         (*(float *)(iVar5 + 0x94) == (float)param_3[9])) ||
       ((NAN(*(float *)(iVar5 + 0x98)) || NAN((float)param_3[10])) ==
        (*(float *)(iVar5 + 0x98) == (float)param_3[10]))) ||
      ((NAN(*(float *)(iVar5 + 0x9c)) || NAN((float)param_3[0xb])) ==
       (*(float *)(iVar5 + 0x9c) == (float)param_3[0xb]))) ||
     (cVar4 = FUN_01160ab0(param_3), cVar4 == '\0')) {
    uVar1 = param_3[1];
    uVar2 = param_3[2];
    uVar3 = param_3[3];
    *(undefined4 *)(iVar5 + 0x70) = *param_3;
    *(undefined4 *)(iVar5 + 0x74) = uVar1;
    *(undefined4 *)(iVar5 + 0x78) = uVar2;
    *(undefined4 *)(iVar5 + 0x7c) = uVar3;
    uVar1 = param_3[5];
    uVar2 = param_3[6];
    uVar3 = param_3[7];
    *(undefined4 *)(iVar5 + 0x80) = param_3[4];
    *(undefined4 *)(iVar5 + 0x84) = uVar1;
    *(undefined4 *)(iVar5 + 0x88) = uVar2;
    *(undefined4 *)(iVar5 + 0x8c) = uVar3;
    uVar1 = param_3[9];
    uVar2 = param_3[10];
    uVar3 = param_3[0xb];
    *(undefined4 *)(iVar5 + 0x90) = param_3[8];
    *(undefined4 *)(iVar5 + 0x94) = uVar1;
    *(undefined4 *)(iVar5 + 0x98) = uVar2;
    *(undefined4 *)(iVar5 + 0x9c) = uVar3;
    FUN_00b7d0c0(param_2,*param_3,param_3[1],param_3[2],param_3[3],param_3[4],param_3[5],param_3[6],
                 param_3[7],param_3[8],param_3[9],param_3[10],param_3[0xb]);
    iVar5 = FUN_008acee0(param_1);
    if (iVar5 != 0) {
      FUN_00b7d0c0(param_2,*param_3,param_3[1],param_3[2],param_3[3],param_3[4],param_3[5],
                   param_3[6],param_3[7],param_3[8],param_3[9],param_3[10],param_3[0xb]);
    }
  }
  return;
}



/* FUNCTION 25854 ; VA 0x00bb17c0 ; FUN_00bb17c0 */

void __thiscall FUN_00bb17c0(int param_1,int param_2,char param_3)

{
  if (*(char *)(param_2 + 0x100 + param_1) != param_3) {
    *(char *)(param_2 + 0x100 + param_1) = param_3;
    FUN_005e66b0();
    return;
  }
  return;
}



/* FUNCTION 25855 ; VA 0x00bb17f0 ; FUN_00bb17f0 */

void __thiscall FUN_00bb17f0(int param_1,undefined4 *param_2)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puVar3 = (undefined4 *)(param_1 + 0x130);
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00558b30(puVar3,&param_2);
  if (cVar1 == '\0') {
    if ((undefined4 **)puVar3 != &param_2) {
      puVar2 = &param_2;
      if (0xf < in_stack_00000018) {
        puVar2 = param_2;
      }
      FUN_005542c0(puVar2,in_stack_00000014);
    }
    FUN_008a4940(&DAT_02131300);
    FUN_0054ef60(puVar3);
    FUN_006ecaa0();
  }
  if (0xf < in_stack_00000018) {
    uVar4 = in_stack_00000018 + 1;
    puVar3 = param_2;
    if (0xfff < uVar4) {
      puVar3 = (undefined4 *)param_2[-1];
      uVar4 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25856 ; VA 0x00bb18b0 ; FUN_00bb18b0 */

void __thiscall FUN_00bb18b0(int param_1,char param_2)

{
  int iVar1;
  
  if (*(char *)(param_1 + 0x6c) != param_2) {
    *(char *)(param_1 + 0x6c) = param_2;
    FUN_008a4940(&DAT_02131000);
    iVar1 = FUN_008acee0(param_1);
    if (iVar1 != 0) {
      FUN_00b83f80();
    }
    if (*(char *)(param_1 + 0x6c) == '\0') {
      FUN_005542c0(&DAT_018bc9b8,0);
    }
  }
  return;
}



/* FUNCTION 25857 ; VA 0x00bb1900 ; FUN_00bb1900 */

void __thiscall FUN_00bb1900(int param_1,int param_2,int param_3)

{
  if (*(int *)(param_1 + 0x108 + param_2 * 4) != param_3) {
    *(int *)(param_1 + 0x108 + param_2 * 4) = param_3;
    FUN_006150c0();
    return;
  }
  return;
}



/* FUNCTION 25858 ; VA 0x00bb1930 ; FUN_00bb1930 */

void __thiscall FUN_00bb1930(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_00b849a0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25859 ; VA 0x00bb1980 ; FUN_00bb1980 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00bb1980(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd516;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef3404) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef3404);
    if (DAT_01ef3404 == -1) {
      uStack_8 = 0;
      FUN_009ca470("VRTouchpad");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef33a0 = RBX::Reflection::EnumDesc<enum_RBX::VRService::VRTouchpad>::vftable;
      FUN_009caf20(&DAT_01d67a28,2);
      FUN_016f3654(&LAB_01891730);
      FUN_016f37bf(&DAT_01ef3404);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef33a0;
}



/* FUNCTION 25860 ; VA 0x00bb1a30 ; FUN_00bb1a30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00bb1a30(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd536;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef339c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef339c);
    if (DAT_01ef339c == -1) {
      uStack_8 = 0;
      FUN_009ca470("VRTouchpadMode");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef3338 = RBX::Reflection::EnumDesc<enum_RBX::VRService::VRTouchpadMode>::vftable;
      FUN_009caf20(&DAT_01d67a38,3);
      FUN_016f3654(&LAB_01891750);
      FUN_016f37bf(&DAT_01ef339c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef3338;
}



/* FUNCTION 25861 ; VA 0x00bb1ae0 ; FUN_00bb1ae0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00bb1ae0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef3424) {
    FUN_016f3809(&DAT_01ef3424);
    if (DAT_01ef3424 == -1) {
      _DAT_01ef3418 = FUN_005c65e0;
      _DAT_01ef341c = FUN_005c65e0;
      _DAT_01ef3420 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef3424);
    }
  }
  return &DAT_01ef3418;
}



/* FUNCTION 25862 ; VA 0x00bb1b50 ; FUN_00bb1b50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00bb1b50(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef3414) {
    FUN_016f3809(&DAT_01ef3414);
    if (DAT_01ef3414 == -1) {
      _DAT_01ef3408 = FUN_005c65e0;
      _DAT_01ef340c = FUN_005c65e0;
      _DAT_01ef3410 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef3414);
    }
  }
  return &DAT_01ef3408;
}



/* FUNCTION 25863 ; VA 0x00bb1bc0 ; FUN_00bb1bc0 */

void __fastcall FUN_00bb1bc0(int param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  int iVar7;
  undefined auStack_34 [4];
  int *piStack_30;
  int iStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6ac8;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 0x6c) == '\0') {
    return;
  }
  iVar3 = *(int *)(param_1 + 0x34);
  iVar2 = param_1;
  ExceptionList = &pvStack_10;
  if ((iVar3 != 0) && (iVar2 = iVar3, ExceptionList = &pvStack_10, *(int *)(iVar3 + 0x34) != 0)) {
    ExceptionList = &pvStack_10;
    iVar2 = FUN_005c8ac0();
  }
  if ((iVar2 == 0) ||
     (iVar3 = *(int *)(iVar2 + 0xc), iVar2 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar2 + 0x1da) <
     (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))) {
    piStack_1c = (int *)0x0;
  }
  else {
    piStack_1c = (int *)FUN_006348f0();
  }
  iVar3 = *(int *)(param_1 + 0x34);
  if ((iVar3 != 0) && (param_1 = iVar3, *(int *)(iVar3 + 0x34) != 0)) {
    param_1 = FUN_005c8ac0();
  }
  if ((param_1 == 0) ||
     (iVar3 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar2 + 0x1da) <
     (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))) {
    iStack_18 = 0;
  }
  else {
    iStack_18 = FUN_008e1dc0();
  }
  cStack_11 = '\0';
  if (piStack_1c == (int *)0x0) {
    ExceptionList = pvStack_10;
    return;
  }
  if (iStack_18 == 0) {
    ExceptionList = pvStack_10;
    return;
  }
  iVar3 = FUN_00b98e50();
  if (((iVar3 != 0) && (iVar3 = FUN_00baf540(), iVar3 != 0)) &&
     (cVar1 = FUN_00c69ba0(), cVar1 == '\0')) {
    ExceptionList = pvStack_10;
    return;
  }
  piStack_1c = (int *)FUN_00b98080(auStack_34);
  iVar2 = 0;
  iStack_28 = 0;
  iVar3 = piStack_1c[1];
  if (iVar3 != 0) {
    piVar5 = (int *)(iVar3 + 4);
    iVar3 = *(int *)(iVar3 + 4);
    while (iVar3 != 0) {
      LOCK();
      iVar2 = *piVar5;
      if (iVar3 == iVar2) {
        *piVar5 = iVar3 + 1;
        iVar2 = iVar3;
      }
      UNLOCK();
      if (iVar2 == iVar3) {
        iVar2 = *piStack_1c;
        iStack_28 = piStack_1c[1];
        goto LAB_00bb1d0d;
      }
      iVar3 = *piVar5;
    }
    iVar2 = 0;
    iStack_28 = 0;
  }
LAB_00bb1d0d:
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_8 = 0;
  iStack_2c = iVar2;
  FUN_00550b30();
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_30[2] + -1;
    piStack_30[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piStack_30 + 4))();
    }
  }
  if (iVar2 != 0) {
    iVar3 = *(int *)(iVar2 + 0xc);
    iVar4 = FUN_00c6de80();
    iVar7 = iStack_18;
    iVar6 = 0;
    if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da)) {
      iVar6 = iVar2;
    }
    if ((iVar6 != 0) && (*(char *)(iVar6 + 0x342) != '\0')) {
      cVar1 = FUN_00620ec0(iStack_18);
      if (cVar1 == '\0') {
        FUN_00b9d020(iVar6,0);
      }
      else {
        FUN_00b9d020(iVar6,iVar7);
      }
      goto LAB_00bb1db5;
    }
  }
  cStack_11 = '\x01';
  iVar7 = iStack_18;
LAB_00bb1db5:
  uStack_8 = 0xffffffff;
  FUN_00550b30();
  if (cStack_11 != '\0') {
    iVar2 = FUN_00b98e50();
    iVar3 = 0;
    if ((iVar2 != 0) && (cVar1 = FUN_00620ec0(iVar7), cVar1 != '\0')) {
      iVar3 = iVar7;
    }
    FUN_00b9d020(0,iVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25864 ; VA 0x00bb1e10 ; FUN_00bb1e10 */

void __thiscall FUN_00bb1e10(int param_1,int param_2,undefined4 param_3,char *param_4)

{
  ulonglong uVar1;
  float fVar2;
  int iVar3;
  float *pfVar4;
  double dVar5;
  double dVar6;
  float fVar7;
  float fVar8;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  undefined8 uStack_5c;
  float fStack_54;
  ulonglong uStack_50;
  undefined auStack_48 [4];
  undefined auStack_44 [4];
  float fStack_40;
  undefined auStack_3c [4];
  int iStack_38;
  float fStack_34;
  int iStack_30;
  float fStack_2c;
  undefined auStack_28 [4];
  float fStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017fd568;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iStack_38 = param_1;
  iStack_30 = FUN_008acee0(param_1);
  if (iStack_30 == 0) {
    ExceptionList = pvStack_1c;
    return;
  }
  fStack_40 = *(float *)(param_1 + 0x108 + param_2 * 4);
  if ((int)fStack_40 < 0) {
    ExceptionList = pvStack_1c;
    return;
  }
  if ((int)fStack_40 < 2) {
    if (param_4[0xc] == '\0') goto LAB_00bb229d;
    iVar3 = FUN_00bafb80(&DAT_01d67a00 + param_2 * 4);
    FUN_00557fc0(iVar3 + 4);
    fStack_68 = *(float *)(param_4 + 4);
    fStack_64 = *(float *)(param_4 + 8);
    uVar1 = *(ulonglong *)(param_4 + 4);
    fStack_24 = 0.0;
    fStack_2c = 0.0;
    uStack_14 = 0;
    uStack_50 = 0;
    fStack_60 = 0.0;
    uStack_5c = 0;
    if (param_4[1] == '\0') {
      fStack_34 = 1.4013e-45;
    }
    else {
      fStack_34 = 2.8026e-45;
      if (*param_4 != '\0') {
        fStack_34 = 0.0;
      }
      *(ulonglong *)(param_1 + 0x118 + param_2 * 0xc) = uVar1;
      *(undefined4 *)(param_1 + 0x120 + param_2 * 0xc) = 0;
    }
    fVar2 = DAT_01900a10;
    if (fStack_40 == 1.4013e-45) {
      fVar7 = *(float *)(param_1 + 0x118 + param_2 * 0xc);
      fVar8 = fStack_64 - *(float *)(param_1 + 0x11c + param_2 * 0xc);
      fStack_60 = 0.0 - *(float *)(param_1 + 0x120 + param_2 * 0xc);
      fStack_40 = fStack_68 - fVar7;
      fVar7 = fVar7 * DAT_01900a10;
      uStack_5c = CONCAT44(fVar8,fStack_40);
      *(float *)(param_1 + 0x11c + param_2 * 0xc) =
           *(float *)(param_1 + 0x11c + param_2 * 0xc) * DAT_01900a10;
      *(float *)(param_1 + 0x120 + param_2 * 0xc) =
           *(float *)(param_1 + 0x120 + param_2 * 0xc) * fVar2;
      *(float *)(param_1 + 0x118 + param_2 * 0xc) = fVar7;
      dVar5 = (double)(fStack_40 * fStack_40 + fVar8 * fVar8 + fStack_60 * fStack_60);
      fStack_54 = fStack_60;
      FUN_017267a0();
      if ((float)dVar5 <= DAT_018ce2f8) {
LAB_00bb21ac:
        fStack_2c = fStack_54;
        fStack_24 = uStack_5c._4_4_;
        uStack_50 = uStack_5c & 0xffffffff;
      }
      else {
        fStack_2c = DAT_018ce2f8 / (float)dVar5;
        uStack_50 = (ulonglong)(uint)(fStack_2c * fStack_40);
        fStack_24 = uStack_5c._4_4_ * fStack_2c;
        uStack_5c = CONCAT44(fStack_24,fStack_2c * fStack_40);
        fStack_2c = fStack_54 * fStack_2c;
      }
    }
    else if (fStack_40 == 0.0) {
      fStack_54 = 0.0;
      uStack_5c = uVar1;
      goto LAB_00bb21ac;
    }
    fStack_54 = fStack_2c;
    FUN_00d81e10();
    pfVar4 = (float *)FUN_00d81770(&fStack_68);
    if (((((NAN(*pfVar4) || NAN((float)uStack_50)) == (*pfVar4 == (float)uStack_50)) ||
         ((NAN(pfVar4[1]) || NAN(fStack_24)) == (pfVar4[1] == fStack_24))) ||
        ((NAN(pfVar4[2]) || NAN(fStack_2c)) == (pfVar4[2] == fStack_2c))) || (param_4[1] != '\0')) {
      pfVar4 = (float *)FUN_00d81770(auStack_48);
      fStack_60 = fStack_2c - pfVar4[2];
      FUN_00d81dc0(CONCAT44(fStack_24 - pfVar4[1],(float)uStack_50 - *pfVar4),fStack_60);
      FUN_00d81ed0(uStack_5c,fStack_54);
      FUN_00b81ad0(auStack_3c);
    }
    uStack_14 = 0xffffffff;
    FUN_00550b30();
LAB_00bb229d:
    if (param_4[0xe] == '\0') {
      ExceptionList = pvStack_1c;
      return;
    }
    iVar3 = FUN_00bafb80(&DAT_01d67a08 + param_2 * 4);
    FUN_00557fc0(iVar3 + 4);
    uStack_14 = 1;
    FUN_00d81e10();
    FUN_00b81ad0(&uStack_50);
    FUN_00550b30();
    ExceptionList = pvStack_1c;
    return;
  }
  if (fStack_40 != 2.8026e-45) {
    ExceptionList = pvStack_1c;
    return;
  }
  fStack_34 = *(float *)(param_1 + 0x110 + param_2 * 4);
  fVar2 = fStack_34;
  if (*param_4 != '\0') {
    dVar5 = (double)*(float *)(param_4 + 4);
    dVar6 = (double)*(float *)(param_4 + 8);
    if ((float)(double)CONCAT44((uint)((ulonglong)dVar5 >> 0x20) & DAT_018c0da0._4_4_,
                                SUB84(dVar5,0) & (uint)DAT_018c0da0) <=
        (float)(double)CONCAT44((uint)((ulonglong)dVar6 >> 0x20) & DAT_018c0da0._4_4_,
                                SUB84(dVar6,0) & (uint)DAT_018c0da0)) {
      fVar2 = (float)((*(float *)(param_4 + 8) < 0.0) + 0x3e9);
      fStack_24 = fVar2;
    }
    else {
      fVar2 = 1.4013e-42;
      fStack_24 = fVar2;
      if (DAT_018ce2f0 < *(float *)(param_4 + 4)) {
        fVar2 = 1.4055e-42;
        fStack_24 = fVar2;
      }
    }
  }
  fStack_2c = fVar2;
  if ((param_4[0xd] == '\0') || (fStack_34 == fVar2)) {
LAB_00bb1f98:
    if (param_4[0xe] == '\0') goto LAB_00bb1fe8;
  }
  else if (param_4[0xe] == '\0') {
    iVar3 = FUN_00bafb80(&fStack_34);
    FUN_00557fc0(iVar3 + 4);
    uStack_14 = 2;
    iVar3 = FUN_00bafb80(&fStack_2c);
    FUN_00557fc0(iVar3 + 4);
    uStack_14 = CONCAT31(uStack_14._1_3_,3);
    FUN_00d81e10();
    FUN_00d81e10();
    FUN_00b81ad0(auStack_44);
    FUN_00b81ad0(&uStack_50);
    FUN_00550b30();
    uStack_14 = 0xffffffff;
    FUN_00550b30();
    goto LAB_00bb1f98;
  }
  iVar3 = FUN_00bafb80(&fStack_2c);
  FUN_00557fc0(iVar3 + 4);
  uStack_14 = 4;
  FUN_00d81e10();
  FUN_00b81ad0(auStack_28);
  FUN_00550b30();
LAB_00bb1fe8:
  *(float *)(iStack_38 + 0x110 + param_2 * 4) = fVar2;
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 25865 ; VA 0x00bb2310 ; FUN_00bb2310 */

int * __thiscall
FUN_00bb2310(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd59b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00bb25e0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::StarterPlayerService,class_RBX::NumberRange>::
              GetSetImpl<class_RBX::NumberRange_(__thiscall_RBX::StarterPlayerService::*)(void)const_,void_(__thiscall_RBX::StarterPlayerService::*)(class_RBX::NumberRange_const&)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_00b33310();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_RBX::NumberRange>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::StarterPlayerService,class_RBX::NumberRange>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::StarterPlayerService,class_RBX::NumberRange>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25866 ; VA 0x00bb2410 ; FUN_00bb2410 */

int * __thiscall
FUN_00bb2410(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c0deb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00bb25e0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::StarterPlayerService,__int64>::
              GetSetImpl<__int64_(__thiscall_RBX::StarterPlayerService::*)(void)const_,void_(__thiscall_RBX::StarterPlayerService::*)(__int64)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088da50();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<__int64>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::StarterPlayerService,__int64>::
                    vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::StarterPlayerService,__int64>::
                    vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25867 ; VA 0x00bb2510 ; FUN_00bb2510 */

int * __thiscall
FUN_00bb2510(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c60c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00bb25e0();
  FUN_006846c0(uVar3,param_2,param_3,0,param_5,param_6,param_7,param_8,param_9);
  uStack_8 = 0;
  *param_1 = (int)RBX::Reflection::BoundProp<float,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<float,1>::BoundPropGetSet<class_RBX::StarterPlayerService>
              ::vftable;
    puVar4[1] = param_1;
    puVar4[2] = param_4;
    puVar4[4] = 0;
    puVar4[5] = 0;
  }
  puVar1 = (undefined4 *)param_1[0xd];
  param_1[0xd] = (int)puVar4;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  cVar2 = (**(code **)(*param_1 + 0xc))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar2 = (**(code **)(*param_1 + 8))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25868 ; VA 0x00bb25e0 ; FUN_00bb25e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00bb25e0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd5d0;
  pvStack_10 = ExceptionList;
  if (DAT_01ef3438 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef3650) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef3650);
      if (DAT_01ef3650 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"StarterPlayer",1,uStack_20,0,0,0xb,0,0);
        _DAT_01ef3648 = RBX::Creator<class_RBX::StarterPlayerService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef3440,&DAT_01ef3648);
        FUN_016f3654(FUN_01891ce0);
        FUN_016f37bf(&DAT_01ef3650);
      }
    }
    DAT_01ef3438 = &DAT_01ef3440;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef3438;
}



/* FUNCTION 25869 ; VA 0x00bb26e0 ; FUN_00bb26e0 */

void FUN_00bb26e0(void)

{
  int iVar1;
  
  if (DAT_01ef3654 == 0) {
    iVar1 = FUN_00bb25e0();
    DAT_01ef3654 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 25870 ; VA 0x00bb2700 ; FUN_00bb2700 */

int __thiscall FUN_00bb2700(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fd5e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::StarterCharacterScripts*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25871 ; VA 0x00bb27d2 ; Catch_All@00bb27d2 */

void Catch_All_00bb27d2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 25872 ; VA 0x00bb27f0 ; FUN_00bb27f0 */

int __thiscall FUN_00bb27f0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fd5f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::StarterPlayerScripts*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25873 ; VA 0x00bb28c2 ; Catch_All@00bb28c2 */

void Catch_All_00bb28c2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 25874 ; VA 0x00bb28e0 ; FUN_00bb28e0 */

undefined4 * FUN_00bb28e0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fd630;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c4b870();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(100);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c4cf10();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00bb2700(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25875 ; VA 0x00bb29a0 ; FUN_00bb29a0 */

undefined4 * FUN_00bb29a0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fd670;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c4b970();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(100);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c4cfe0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00bb27f0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25876 ; VA 0x00bb2a60 ; FUN_00bb2a60 */

int __fastcall FUN_00bb2a60(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
      iVar3 = *piVar6;
      if ((iVar3 != 0) &&
         (iVar4 = *(int *)(iVar3 + 0xc), iVar5 = FUN_00c4b970(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        return iVar3;
      }
    }
  }
  return 0;
}



/* FUNCTION 25877 ; VA 0x00bb2ac0 ; thunk_FUN_00935ba0 */

undefined * thunk_FUN_00935ba0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c964c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee20bc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee20bc);
    if (DAT_01ee20bc == -1) {
      uStack_8 = 0;
      FUN_00bb2cc0();
      FUN_016f3654(&LAB_018849c0);
      FUN_016f37bf(&DAT_01ee20bc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee2058;
}



/* FUNCTION 25878 ; VA 0x00bb2ad0 ; thunk_FUN_00935c30 */

undefined * thunk_FUN_00935c30(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c966c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee2124) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee2124);
    if (DAT_01ee2124 == -1) {
      uStack_8 = 0;
      FUN_00bb2d20();
      FUN_016f3654(&LAB_018849e0);
      FUN_016f37bf(&DAT_01ee2124);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee20c0;
}



/* FUNCTION 25879 ; VA 0x00bb2ae0 ; thunk_FUN_00935cc0 */

undefined * thunk_FUN_00935cc0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c968c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee1fec) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee1fec);
    if (DAT_01ee1fec == -1) {
      uStack_8 = 0;
      FUN_00bb2d80();
      FUN_016f3654(&LAB_01884a00);
      FUN_016f37bf(&DAT_01ee1fec);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee1f88;
}



/* FUNCTION 25880 ; VA 0x00bb2af0 ; thunk_FUN_00935d50 */

undefined * thunk_FUN_00935d50(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c96ac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee218c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee218c);
    if (DAT_01ee218c == -1) {
      uStack_8 = 0;
      FUN_00bb2de0();
      FUN_016f3654(&LAB_01884a20);
      FUN_016f37bf(&DAT_01ee218c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee2128;
}



/* FUNCTION 25881 ; VA 0x00bb2b00 ; thunk_FUN_00935de0 */

undefined * thunk_FUN_00935de0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c96cc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee2054) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee2054);
    if (DAT_01ee2054 == -1) {
      uStack_8 = 0;
      FUN_00bb2e40();
      FUN_016f3654(&LAB_01884a40);
      FUN_016f37bf(&DAT_01ee2054);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee1ff0;
}



/* FUNCTION 25882 ; VA 0x00bb2b10 ; FUN_00bb2b10 */

void * __thiscall FUN_00bb2b10(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  void *pvVar5;
  int *piVar6;
  int *piVar7;
  undefined4 *puVar8;
  int *piVar9;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017fd690;
  puVar8 = *(undefined4 **)(param_1 + 0x2c);
  pvVar5 = ExceptionList;
  if (puVar8 != (undefined4 *)0x0) {
    piVar6 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar6 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      piVar6 = *(int **)(param_1 + 0x30);
      puVar8 = *(undefined4 **)(param_1 + 0x2c);
    }
    piVar1 = (int *)puVar8[1];
    piVar9 = (int *)*puVar8;
    iStack_8 = 0;
    pvVar5 = pvStack_10;
    for (; piVar9 != piVar1; piVar9 = piVar9 + 2) {
      piVar7 = (int *)piVar9[1];
      iVar2 = *param_2;
      if (piVar7 != (int *)0x0) {
        LOCK();
        piVar7[1] = piVar7[1] + 1;
        UNLOCK();
        piVar7 = (int *)piVar9[1];
      }
      iStack_8._1_3_ = (uint3)((uint)iStack_8 >> 8);
      iStack_8._0_1_ = 1;
      if ((*piVar9 != 0) &&
         (iVar3 = *(int *)(*piVar9 + 0xc), iVar4 = FUN_00913630(),
         (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
         (uint)*(ushort *)(iVar4 + 0x1da))) {
        FUN_00932670(*(undefined4 *)(iVar2 + 0x58));
        FUN_00932570(*(undefined4 *)(iVar2 + 100));
        FUN_009325f0(*(undefined4 *)(iVar2 + 0x68));
        FUN_00933a30(*(undefined4 *)(iVar2 + 0x60));
        FUN_00933f50(*(undefined4 *)(iVar2 + 0x5c));
        FUN_00932530(*(undefined *)(iVar2 + 0xd0));
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar2 = piVar7[1] + -1;
        piVar7[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar2 = piVar7[2] + -1;
          piVar7[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      pvVar5 = (void *)FUN_00bb2b10(param_2);
    }
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar1 = piVar6 + 1;
      iVar2 = *piVar1;
      pvVar5 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar5 = (void *)(**(code **)*piVar6)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar5 = (void *)(**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 25883 ; VA 0x00bb2cc0 ; FUN_00bb2cc0 */

undefined4 * __fastcall FUN_00bb2cc0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("DevCameraOcclusionMode");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::StarterPlayerService::DeveloperCameraOcclusionMode>
             ::vftable;
  FUN_009caf20(&DAT_01d67ad0,2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25884 ; VA 0x00bb2d20 ; FUN_00bb2d20 */

undefined4 * __fastcall FUN_00bb2d20(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("DevComputerCameraMovementMode");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::
             EnumDesc<enum_RBX::StarterPlayerService::DeveloperComputerCameraMovementMode>::vftable;
  FUN_009caf20(&DAT_01d67aa8,5);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25885 ; VA 0x00bb2d80 ; FUN_00bb2d80 */

undefined4 * __fastcall FUN_00bb2d80(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("DevComputerMovementMode");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::
             EnumDesc<enum_RBX::StarterPlayerService::DeveloperComputerMovementMode>::vftable;
  FUN_009caf20(&DAT_01d67b18,4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25886 ; VA 0x00bb2de0 ; FUN_00bb2de0 */

undefined4 * __fastcall FUN_00bb2de0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("DevTouchCameraMovementMode");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::
             EnumDesc<enum_RBX::StarterPlayerService::DeveloperTouchCameraMovementMode>::vftable;
  FUN_009caf20(&DAT_01d67a88,4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25887 ; VA 0x00bb2e40 ; FUN_00bb2e40 */

undefined4 * __fastcall FUN_00bb2e40(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("DevTouchMovementMode");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::StarterPlayerService::DeveloperTouchMovementMode>::
             vftable;
  FUN_009caf20(&DAT_01d67ae0,7);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25888 ; VA 0x00bb2ea0 ; FUN_00bb2ea0 */

undefined4 * __fastcall FUN_00bb2ea0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd6f2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::StarterPlayerService,class_RBX::ServiceInstance>::
             vftable;
  uVar2 = FUN_00bb25e0();
  param_1[3] = uVar2;
  *param_1 = RBX::StarterPlayerService::vftable;
  param_1[0x16] = 0;
  param_1[0x17] = 0x42c80000;
  param_1[0x18] = 0x42c80000;
  iVar1 = DAT_01d67a50;
  param_1[0x1a] = 0x3f000000;
  *(undefined2 *)(param_1 + 0x1b) = 0x101;
  *(undefined *)((int)param_1 + 0x6e) = 1;
  param_1[0x1c] = 1;
  param_1[0x1d] = 0;
  uStack_8 = 1;
  param_1[0x19] = (float)iVar1;
  param_1[0x1e] = 0x3f666666;
  param_1[0x1f] = 0x3f866666;
  param_1[0x20] = 0x3f333333;
  param_1[0x21] = 0x3f800000;
  param_1[0x22] = 0x3f733333;
  param_1[0x23] = 0x3f800000;
  param_1[0x24] = 0;
  param_1[0x25] = 0x3f800000;
  param_1[0x26] = 0;
  param_1[0x27] = 0x3f800000;
  *(undefined *)(param_1 + 0x28) = 0;
  uVar2 = FUN_00588320(0xb);
  param_1[0x29] = uVar2;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0x3f800000;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  puStack_18 = param_1 + 0x35;
  uStack_8._0_1_ = 3;
  *(undefined2 *)(param_1 + 0x34) = 0x101;
  FUN_00f99400();
  uStack_8._0_1_ = 4;
  FUN_00f994b0();
  uStack_8._0_1_ = 5;
  FUN_00f99350();
  uStack_8._0_1_ = 6;
  *(undefined *)(param_1 + 0x4a) = 1;
  param_1[0x4b] = 0x42480000;
  param_1[0x4c] = 0x40e66666;
  param_1[0x4d] = 0x41800000;
  param_1[0x4e] = 0x42b20000;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("StarterPlayer",0xd);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_008a6520(auStack_30);
  if (0xf < uStack_1c) {
    uVar4 = uStack_1c + 1;
    uVar3 = auStack_30[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_30[0] - 4);
      uVar4 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25889 ; VA 0x00bb30f0 ; FUN_00bb30f0 */

void __fastcall FUN_00bb30f0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::StarterPlayerService>::vftable;
  uVar1 = FUN_00bb25e0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25890 ; VA 0x00bb3130 ; FUN_00bb3130 */

void __fastcall FUN_00bb3130(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = param_1[0x14];
  if (0xf < uVar1) {
    iVar2 = param_1[0xf];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00bb320c;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x13] = 0;
  param_1[0x14] = 0xf;
  *(undefined *)(param_1 + 0xf) = 0;
  param_1[7] = RBX::HumanoidDefaultBodyParts::vftable;
  uVar1 = param_1[0xd];
  if (0xf < uVar1) {
    iVar2 = param_1[8];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00bb320c;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0xc] = 0;
  param_1[0xd] = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  *param_1 = RBX::HumanoidDefaultBodyParts::vftable;
  uVar1 = param_1[6];
  if (0xf < uVar1) {
    iVar2 = param_1[1];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00bb320c:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[5] = 0;
  param_1[6] = 0xf;
  *(undefined *)(param_1 + 1) = 0;
  return;
}



/* FUNCTION 25891 ; VA 0x00bb3220 ; FUN_00bb3220 */

void __fastcall FUN_00bb3220(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = RBX::HumanoidDefaultBodyParts::vftable;
  uVar1 = param_1[6];
  if (0xf < uVar1) {
    iVar2 = param_1[1];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[5] = 0;
  param_1[6] = 0xf;
  *(undefined *)(param_1 + 1) = 0;
  return;
}



/* FUNCTION 25892 ; VA 0x00bb3280 ; FUN_00bb3280 */

void FUN_00bb3280(void)

{
  FUN_006f8c50();
  return;
}



/* FUNCTION 25893 ; VA 0x00bb3290 ; FUN_00bb3290 */

uint * __thiscall FUN_00bb3290(int param_1,uint *param_2)

{
  uint *puVar1;
  undefined4 *puVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  uint uVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fd708;
  pvStack_10 = ExceptionList;
  uVar4 = *param_2;
  uVar10 = (uVar4 >> 3) + uVar4;
  uVar9 = uVar10 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar6 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      puVar6 = (undefined4 *)*puVar6;
    }
    for (; puVar6 != (undefined4 *)0x0; puVar6 = (undefined4 *)*puVar6) {
      if (uVar10 == puVar6[1]) {
        if (uVar4 == puVar6[2]) {
          if (puVar6 != (undefined4 *)0x0) {
            return puVar6 + 2;
          }
          break;
        }
      }
      else if ((uint)puVar6[1] % *(uint *)(param_1 + 4) != uVar9) break;
    }
  }
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_01674e20(0x10);
  puVar1 = (uint *)(piVar3 + 2);
  *piVar3 = 0;
  piVar3[1] = 0;
  puVar1[0] = 0;
  puVar1[1] = 0;
  *puVar1 = uVar4;
  if (piVar3 + 3 != (int *)0x0) {
    piVar3[3] = 0;
  }
  uVar9 = *(uint *)(param_1 + 8);
  uVar4 = uVar9 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar4 = FUN_005d6bb0(uVar4);
    if (uVar4 <= *(uint *)(param_1 + 4)) {
      uVar4 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar4);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar4) {
    uVar7 = uVar9 >> 1;
    if (uVar9 + (uVar9 >> 1) <= uVar4) {
      uVar7 = 1;
    }
    iVar5 = FUN_005d6bb0(uVar7 + uVar9);
    if (iVar5 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar5);
      puVar6 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar2 = (undefined4 *)*puVar6;
      while (puVar2 != (undefined4 *)0x0) {
        uVar4 = (uint)puVar2[1] % *(uint *)(param_1 + 4);
        piVar8 = (int *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar4 * 4) == 0) {
          *piVar8 = (int)puVar6;
          puVar6 = puVar2;
        }
        else {
          *puVar6 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar8;
          *(undefined4 **)*piVar8 = puVar2;
        }
        puVar2 = (undefined4 *)*puVar6;
      }
    }
  }
  piVar3[1] = uVar10;
  uVar10 = uVar10 % *(uint *)(param_1 + 4);
  piVar8 = *(int **)(*(int *)(param_1 + 0x14) + uVar10 * 4);
  puVar6 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar10 * 4);
  if (piVar8 == (int *)0x0) {
    piVar8 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar8 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar8 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar3;
    }
    *puVar6 = piVar8;
    *piVar3 = *piVar8;
  }
  else {
    *piVar3 = *piVar8;
    piVar8 = (int *)*puVar6;
  }
  *piVar8 = (int)piVar3;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 25894 ; VA 0x00bb3470 ; FUN_00bb3470 */

undefined4 * __thiscall FUN_00bb3470(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::NumberRange>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 25895 ; VA 0x00bb34a0 ; FUN_00bb34a0 */

undefined4 * __thiscall FUN_00bb34a0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::NumberRange>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 25896 ; VA 0x00bb34d0 ; FUN_00bb34d0 */

undefined4 * __thiscall FUN_00bb34d0(undefined4 *param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = RBX::HumanoidDefaultBodyParts::vftable;
  uVar1 = param_1[6];
  if (0xf < uVar1) {
    iVar2 = param_1[1];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[5] = 0;
  param_1[6] = 0xf;
  *(undefined *)(param_1 + 1) = 0;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1c);
  }
  return param_1;
}



/* FUNCTION 25897 ; VA 0x00bb3540 ; FUN_00bb3540 */

int __thiscall FUN_00bb3540(int param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00bb3130();
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0xcc);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_006f8c50();
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x13c);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25898 ; VA 0x00bb35e0 ; FUN_00bb35e0 */

undefined4 FUN_00bb35e0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0xc);
    iVar1 = FUN_00c4b970();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
        (uint)*(ushort *)(iVar1 + 0x1da)) {
      return 1;
    }
    iVar2 = *(int *)(param_1 + 0xc);
    iVar1 = FUN_0099be20();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
        (uint)*(ushort *)(iVar1 + 0x1da)) {
      return 1;
    }
    iVar2 = *(int *)(param_1 + 0xc);
    iVar1 = FUN_00c4b870();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
        (uint)*(ushort *)(iVar1 + 0x1da)) {
      return 1;
    }
  }
  iVar2 = FUN_007097d0(param_1);
  if (iVar2 != 0) {
    return 1;
  }
  return 0;
}



/* FUNCTION 25899 ; VA 0x00bb3680 ; FUN_00bb3680 */

uint FUN_00bb3680(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00c4b970();
    uVar3 = (uint)*(ushort *)(iVar2 + 0x1da);
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <= uVar3)
    goto LAB_00bb3702;
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_0099be20();
    uVar3 = (uint)*(ushort *)(iVar2 + 0x1da);
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <= uVar3)
    goto LAB_00bb3702;
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00c4b870();
    uVar3 = (uint)*(ushort *)(iVar2 + 0x1da);
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <= uVar3)
    goto LAB_00bb3702;
  }
  uVar3 = FUN_007097d0(param_1);
  if (uVar3 == 0) {
    return 1;
  }
LAB_00bb3702:
  return uVar3 & 0xffffff00;
}



/* FUNCTION 25900 ; VA 0x00bb3720 ; FUN_00bb3720 */

int __thiscall FUN_00bb3720(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd880;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_0060dcd0(auStack_20,param_1);
  uStack_18 = *puVar4;
  piStack_14 = (int *)puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  uStack_8 = 1;
  iVar5 = FUN_00f99bb0(param_2,&uStack_18);
  piVar2 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar3 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar5 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar2 = piStack_1c + 1;
    iVar3 = *piVar2;
    iVar5 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar5 = (**(code **)*piStack_1c)();
      LOCK();
      piVar2 = piStack_1c + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar5 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 25901 ; VA 0x00bb37f0 ; FUN_00bb37f0 */

int __thiscall FUN_00bb37f0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined auStack_44 [4];
  int *piStack_40;
  undefined auStack_3c [4];
  int *piStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  int iStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd8c0;
  pvStack_10 = ExceptionList;
  iStack_1c = param_1 + 0xd4;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  piVar2 = (int *)FUN_0060dcd0(auStack_3c,param_1);
  iStack_24 = *piVar2;
  piStack_20 = (int *)piVar2[1];
  *piVar2 = 0;
  piVar2[1] = 0;
  uStack_8 = 1;
  iVar3 = FUN_00f9b370(param_2,&iStack_24);
  piVar2 = piStack_20;
  cStack_11 = (char)iVar3 == '\0';
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_20 + 1;
    iVar4 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        iVar3 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8 = 0xffffffff;
  if (piStack_38 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_38 + 1;
    iVar4 = *piVar2;
    iVar3 = *piVar2;
    *piVar2 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*piStack_38)();
      LOCK();
      piVar2 = piStack_38 + 2;
      iVar4 = *piVar2;
      iVar3 = *piVar2;
      *piVar2 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_38 + 4))();
      }
    }
  }
  if (cStack_11 == '\0') {
    ExceptionList = pvStack_10;
    return iVar3;
  }
  if (param_1 != 0) {
    iVar3 = *(int *)(param_1 + 0x34);
    iVar4 = iStack_18;
    if ((iVar3 != 0) && (iVar4 = iVar3, *(int *)(iVar3 + 0x34) != 0)) {
      iVar4 = FUN_005c8ac0();
    }
    if ((iVar4 != 0) &&
       (iVar3 = *(int *)(iVar4 + 0xc), iVar4 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
       (uint)*(ushort *)(iVar4 + 0x1da))) {
      uVar5 = FUN_005c2760();
      goto LAB_00bb391e;
    }
  }
  uVar5 = 0;
LAB_00bb391e:
  FUN_00e2f260(&uStack_34,uVar5,param_2);
  uStack_8 = 2;
  uVar5 = FUN_009ba880(uStack_34);
  iVar3 = FUN_0060dcd0(&iStack_24,uVar5);
  iVar4 = iStack_24;
  uStack_8._0_1_ = 3;
  if (iStack_24 != 0) {
    puVar6 = (undefined4 *)FUN_0060dcd0(auStack_44,iStack_18);
    uStack_2c = *puVar6;
    piStack_28 = (int *)puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    uStack_8._0_1_ = 5;
    iVar3 = FUN_00f99bb0(iVar4,&uStack_2c);
    piVar2 = piStack_28;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_28 + 1;
      iVar4 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar4 = *piVar1;
        iVar3 = *piVar1;
        *piVar1 = iVar4 + -1;
        UNLOCK();
        if (iVar4 + -1 == 0) {
          iVar3 = (**(code **)(*piVar2 + 4))();
        }
      }
    }
    if (piStack_40 != (int *)0x0) {
      LOCK();
      piVar2 = piStack_40 + 1;
      iVar4 = *piVar2;
      iVar3 = *piVar2;
      *piVar2 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)*piStack_40)();
        LOCK();
        piVar2 = piStack_40 + 2;
        iVar4 = *piVar2;
        iVar3 = *piVar2;
        *piVar2 = iVar4 + -1;
        UNLOCK();
        if (iVar4 + -1 == 0) {
          iVar3 = (**(code **)(*piStack_40 + 4))();
        }
      }
    }
  }
  piVar2 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_20 + 1;
    iVar4 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        iVar3 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_30 + 1;
    iVar4 = *piVar2;
    iVar3 = *piVar2;
    *piVar2 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar3 = (**(code **)*piStack_30)();
      LOCK();
      piVar2 = piStack_30 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar3 = (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 25902 ; VA 0x00bb3a50 ; FUN_00bb3a50 */

int __fastcall FUN_00bb3a50(undefined4 param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd880;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_0060dcd0(auStack_20,param_1);
  uStack_18 = *puVar4;
  piStack_14 = (int *)puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  uStack_8 = 1;
  iVar5 = FUN_00f9a020(&uStack_18);
  piVar2 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar3 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar5 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar2 = piStack_1c + 1;
    iVar3 = *piVar2;
    iVar5 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar5 = (**(code **)*piStack_1c)();
      LOCK();
      piVar2 = piStack_1c + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar5 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 25903 ; VA 0x00bb3b20 ; FUN_00bb3b20 */

undefined4 * FUN_00bb3b20(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_0063f450(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 25904 ; VA 0x00bb3b90 ; FUN_00bb3b90 */

void FUN_00bb3b90(void)

{
  FUN_00bb5530();
  return;
}



/* FUNCTION 25905 ; VA 0x00bb3ba0 ; FUN_00bb3ba0 */

void FUN_00bb3ba0(void)

{
  FUN_01017960();
  return;
}



/* FUNCTION 25906 ; VA 0x00bb3bb0 ; FUN_00bb3bb0 */

void FUN_00bb3bb0(void)

{
  FUN_01017d20();
  return;
}



/* FUNCTION 25907 ; VA 0x00bb3d20 ; FUN_00bb3d20 */

undefined4 FUN_00bb3d20(undefined4 param_1)

{
  FUN_01017ad0(param_1);
  return param_1;
}



/* FUNCTION 25908 ; VA 0x00bb3d40 ; FUN_00bb3d40 */

undefined4 FUN_00bb3d40(undefined4 param_1)

{
  FUN_01017b00(param_1);
  return param_1;
}



/* FUNCTION 25909 ; VA 0x00bb3d60 ; FUN_00bb3d60 */

undefined4 FUN_00bb3d60(undefined4 param_1)

{
  FUN_01017b30(param_1);
  return param_1;
}



/* FUNCTION 25910 ; VA 0x00bb3d80 ; FUN_00bb3d80 */

undefined4 FUN_00bb3d80(undefined4 param_1)

{
  FUN_01017b60(param_1);
  return param_1;
}



/* FUNCTION 25911 ; VA 0x00bb3da0 ; FUN_00bb3da0 */

undefined4 FUN_00bb3da0(undefined4 param_1)

{
  FUN_01017b90(param_1);
  return param_1;
}



/* FUNCTION 25912 ; VA 0x00bb3e50 ; FUN_00bb3e50 */

int __thiscall FUN_00bb3e50(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd880;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_0060dcd0(auStack_20,param_1);
  uStack_18 = *puVar4;
  piStack_14 = (int *)puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  uStack_8 = 1;
  iVar5 = FUN_00f9b130(&uStack_18,param_2,param_3);
  piVar2 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar3 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar5 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar2 = piStack_1c + 1;
    iVar3 = *piVar2;
    iVar5 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar5 = (**(code **)*piStack_1c)();
      LOCK();
      piVar2 = piStack_1c + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar5 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 25913 ; VA 0x00bb3f40 ; FUN_00bb3f40 */

undefined4 __thiscall FUN_00bb3f40(int param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar1 = param_3;
  puStack_c = &LAB_017fd8e9;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_008a25b0(param_2,param_3);
  uStack_8 = 0;
  if (((((puVar1 == &DAT_02131480) || (puVar1 == &DAT_02131b38)) ||
       (puVar1 == (undefined4 *)&DAT_02131bb0)) || (puVar1 == (undefined4 *)&DAT_02131b78)) &&
     ((*(int *)(param_1 + 0xbc) == 3 || (*(int *)(param_1 + 0xb8) == 3)))) {
    param_3 = (undefined4 *)param_1;
    iVar2 = FUN_00bb3290(&param_3);
    *(undefined4 *)(iVar2 + 4) = 2;
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25914 ; VA 0x00bb4000 ; FUN_00bb4000 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00bb4000(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined *puVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined auStack_c [8];
  
  puVar3 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_c,param_2);
  uVar4 = FUN_00b33310();
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  *param_3 = uVar4;
  if (*(int *)(iVar1 + 0x34) < DAT_01ead388) {
    FUN_016f3809(&DAT_01ead388);
    if (DAT_01ead388 == -1) {
      _DAT_01ead37c = FUN_005c6620;
      _DAT_01ead380 = FUN_005c6620;
      _DAT_01ead384 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead388);
    }
  }
  puVar2 = (undefined *)param_3[1];
  if (puVar2 == &DAT_01ead37c) {
    param_3[2] = *puVar3;
    param_3[3] = puVar3[1];
    return;
  }
  if (puVar2 != (undefined *)0x0) {
    (**(code **)(puVar2 + 8))(param_3 + 2);
    param_3[1] = 0;
  }
  param_3[2] = *puVar3;
  param_3[3] = puVar3[1];
  param_3[1] = &DAT_01ead37c;
  return;
}



/* FUNCTION 25915 ; VA 0x00bb40e0 ; FUN_00bb40e0 */

void __thiscall FUN_00bb40e0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_00935ba0();
  *param_3 = uVar3;
  iVar4 = FUN_00935f70();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 25916 ; VA 0x00bb4140 ; FUN_00bb4140 */

void __thiscall FUN_00bb4140(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_00935c30();
  *param_3 = uVar3;
  iVar4 = FUN_00935ff0();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 25917 ; VA 0x00bb41a0 ; FUN_00bb41a0 */

void __thiscall FUN_00bb41a0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_00935cc0();
  *param_3 = uVar3;
  iVar4 = FUN_00936060();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 25918 ; VA 0x00bb4200 ; FUN_00bb4200 */

void __thiscall FUN_00bb4200(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_00935d50();
  *param_3 = uVar3;
  iVar4 = FUN_009360d0();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 25919 ; VA 0x00bb4260 ; FUN_00bb4260 */

void __thiscall FUN_00bb4260(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_00935de0();
  *param_3 = uVar3;
  iVar4 = FUN_00936140();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 25920 ; VA 0x00bb42c0 ; FUN_00bb42c0 */

void __thiscall FUN_00bb42c0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_0090bd10();
  *param_3 = uVar3;
  iVar4 = FUN_0090c300();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 25921 ; VA 0x00bb4320 ; FUN_00bb4320 */

void __thiscall FUN_00bb4320(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_0090c0c0();
  *param_3 = uVar3;
  iVar4 = FUN_0090c530();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 25922 ; VA 0x00bb4380 ; FUN_00bb4380 */

undefined __thiscall FUN_00bb4380(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined uVar4;
  undefined4 *puVar5;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd880;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_0060dcd0(auStack_20,param_1);
  uStack_18 = *puVar5;
  piStack_14 = (int *)puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  uStack_8 = 1;
  uVar4 = FUN_00f9b1d0(param_2,&uStack_18);
  piVar2 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar2 = piStack_1c + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 25923 ; VA 0x00bb4460 ; FUN_00bb4460 */

void __fastcall FUN_00bb4460(int param_1)

{
  FUN_009c3b40(*(undefined4 *)(param_1 + 300));
  FUN_009c5380(*(undefined *)(param_1 + 0x128));
  FUN_009c3ad0(*(undefined4 *)(param_1 + 0x130));
  FUN_009c5a80(*(undefined4 *)(param_1 + 0x134));
  FUN_009c4240(*(undefined4 *)(param_1 + 0x138));
  return;
}



/* FUNCTION 25924 ; VA 0x00bb44e0 ; FUN_00bb44e0 */

uint __thiscall FUN_00bb44e0(int param_1,int param_2,int param_3)

{
  uint in_EAX;
  int *piVar1;
  uint uVar2;
  
  if (*(int *)(param_2 + 0xc) == param_3) {
    piVar1 = *(int **)(param_1 + 0x2c);
    if (piVar1 == (int *)0x0) {
      uVar2 = 0;
    }
    else {
      uVar2 = piVar1[1] - *piVar1 >> 3;
    }
    in_EAX = 0;
    if (uVar2 != 0) {
      piVar1 = (int *)*piVar1;
      do {
        if ((*piVar1 != param_2) && (*(int *)(*piVar1 + 0xc) == param_3)) goto LAB_00bb452c;
        in_EAX = in_EAX + 1;
        piVar1 = piVar1 + 2;
      } while (in_EAX < uVar2);
    }
    return CONCAT31((int3)(in_EAX >> 8),1);
  }
LAB_00bb452c:
  return in_EAX & 0xffffff00;
}



/* FUNCTION 25925 ; VA 0x00bb4540 ; FUN_00bb4540 */

undefined4 __thiscall FUN_00bb4540(int param_1,undefined *param_2)

{
  if (((param_2 != &DAT_021319e8) || (*(char *)(param_1 + 0x128) != '\0')) &&
     ((param_2 != &DAT_02131a20 || (*(char *)(param_1 + 0x128) == '\0')))) {
    return 0;
  }
  return 1;
}



/* FUNCTION 25926 ; VA 0x00bb4580 ; FUN_00bb4580 */

uint FUN_00bb4580(void)

{
  int iVar1;
  
  iVar1 = FUN_00bb25e0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 25927 ; VA 0x00bb45a0 ; FUN_00bb45a0 */

uint FUN_00bb45a0(void)

{
  int iVar1;
  
  iVar1 = FUN_00bb25e0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 25928 ; VA 0x00bb45c0 ; FUN_00bb45c0 */

void FUN_00bb45c0(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  
  uVar2 = FUN_00c4b970();
  cVar1 = FUN_00bb44e0(param_1,uVar2);
  if (cVar1 == '\0') {
    uVar2 = FUN_00c4b870();
    cVar1 = FUN_00bb44e0(param_1,uVar2);
    if (cVar1 == '\0') {
      return;
    }
  }
  *(undefined *)(param_1 + 0x22) = 1;
  return;
}



/* FUNCTION 25929 ; VA 0x00bb4600 ; FUN_00bb4600 */

void __thiscall FUN_00bb4600(undefined4 param_1,int param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined4 *puVar7;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar1 = (int)param_3;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd921;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  FUN_008a4210(param_2,param_3);
  if ((iVar1 != 0) && (cVar4 = FUN_00971ce0(iVar1,1), cVar4 != '\0')) {
    FUN_005789c0(&DAT_01ea8a70,&LAB_0055d570);
    uVar5 = FUN_00560c40();
    param_3 = (int *)FUN_008aa140(uVar5);
    if (*param_3 == 0) {
      uVar5 = FUN_00961660();
      piVar6 = (int *)FUN_008a9ba0(auStack_24,uVar5);
      iVar2 = *piVar6;
      iVar3 = piVar6[1];
      *piVar6 = 0;
      piVar6[1] = 0;
      *param_3 = iVar2;
      piVar6 = (int *)param_3[1];
      param_3[1] = iVar3;
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar2 = piVar6[1] + -1;
        piVar6[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          iVar2 = piVar6[2] + -1;
          piVar6[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      param_1 = uStack_14;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_20[1] + -1;
        piStack_20[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          iVar2 = piStack_20[2] + -1;
          piStack_20[2] = iVar2;
          UNLOCK();
          param_1 = uStack_14;
          if (iVar2 == 0) {
            (**(code **)(*piStack_20 + 4))();
            param_1 = uStack_14;
          }
        }
      }
    }
    if (*param_3 != 0) {
      param_2 = param_1;
      FUN_00bb2b10(&param_2);
    }
    param_2 = FUN_008f7870(iVar1);
    if (param_2 != 0) {
      param_2 = param_2 + 0xa8;
      iStack_8 = 0;
      uVar5 = FUN_01675290(DAT_02110da8);
      iStack_8._0_1_ = 1;
      uStack_1c = uVar5;
      piStack_20 = (int *)FUN_01674e20(0x1c);
      if (piStack_20 == (undefined4 *)0x0) {
        puVar7 = (undefined4 *)0x0;
      }
      else {
        *piStack_20 = 0;
        piStack_20[1] = 1;
        piStack_20[2] = (int)FUN_00bb3b90;
        piStack_20[3] = (int)_guard_check_icall;
        piStack_20[4] = 0;
        piStack_20[5] = param_2;
        piStack_20[6] = uStack_14;
        puVar7 = piStack_20;
      }
      FUN_016797d0(puVar7);
      if (puVar7 != (undefined4 *)0x0) {
        LOCK();
        puVar7[1] = puVar7[1] + 1;
        UNLOCK();
      }
      uStack_18 = 1;
      iStack_8._0_1_ = 2;
      param_3 = puVar7;
      FUN_01675290(uVar5);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      cVar4 = FUN_01679300(&param_3);
      if (cVar4 != '\0') {
        FUN_01679490();
        FUN_016791c0(&param_3);
      }
      if (param_3 != (undefined4 *)0x0) {
        piVar6 = param_3 + 1;
        LOCK();
        iVar1 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          FUN_01674ea0(param_3);
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25930 ; VA 0x00bb4820 ; FUN_00bb4820 */

void __fastcall FUN_00bb4820(int param_1)

{
  int iVar1;
  char *pcVar2;
  
  iVar1 = *(int *)(param_1 + 0xb8);
  if (iVar1 == 1) {
    pcVar2 = "TouchCameraMoveModeClassic";
  }
  else if (iVar1 == 2) {
    pcVar2 = "TouchCameraMoveModeFollow";
  }
  else if (iVar1 == 3) {
    pcVar2 = "TouchCameraMoveModeOrbital";
  }
  else {
    pcVar2 = "TouchCameraMoveModeUser";
  }
  FUN_0087c450(&DAT_018c5f98,"DevTouchCameraMove",pcVar2,0,0,0);
  switch(*(undefined4 *)(param_1 + 0xc4)) {
  case 1:
    pcVar2 = "TouchMovementModeThumbStick";
    break;
  case 2:
    pcVar2 = "TouchMovementModeDPad";
    break;
  case 3:
    pcVar2 = "TouchMovementModeThumbpad";
    break;
  case 4:
    pcVar2 = "TouchMovementModeClickToMove";
    break;
  case 5:
    pcVar2 = "TouchMovementModeScriptable";
    break;
  case 6:
    pcVar2 = "TouchMovementModeDynamicThumbstick";
    break;
  default:
    pcVar2 = "TouchMovementModeUser";
  }
  FUN_0087c450(&DAT_018c5f98,"DevTouchMovement",pcVar2,0,0,0);
  switch(*(undefined4 *)(param_1 + 0xbc)) {
  case 1:
    pcVar2 = "ComputerCameraMoveModeClassic";
    break;
  case 2:
    pcVar2 = "ComputerCameraMoveModeFollow";
    break;
  case 3:
    pcVar2 = "ComputerCameraMoveModeOrbital";
    break;
  case 4:
    pcVar2 = "ComputerCameraMoveModeCameraToggle";
    break;
  default:
    pcVar2 = "ComputerCameraMoveModeUser";
  }
  FUN_0087c450(&DAT_018c5f98,"DevComputerCameraMove",pcVar2,0,0,0);
  iVar1 = *(int *)(param_1 + 200);
  if (iVar1 == 1) {
    pcVar2 = "ComputerMovementModeKbdMouse";
  }
  else if (iVar1 == 2) {
    pcVar2 = "ComputerMovementModeClickToMove";
  }
  else if (iVar1 == 3) {
    pcVar2 = "ComputerMovementModeScriptable";
  }
  else {
    pcVar2 = "ComputerMovementModeUser";
  }
  FUN_0087c450(&DAT_018c5f98,"DevComputerMovement",pcVar2,0,0,0);
  pcVar2 = "False";
  if (*(char *)(param_1 + 0x6c) != '\0') {
    pcVar2 = "True";
  }
  FUN_0087c450(&DAT_018c5f98,"DevComputerEnableMouseLock",pcVar2,0,0,0);
  pcVar2 = "DevCameraOcclusionZoom";
  if (*(int *)(param_1 + 0xc0) == 1) {
    pcVar2 = "DevCameraOcclusionInvisi";
  }
  FUN_0087c450(&DAT_018c5f98,"DevCameraOcclusion",pcVar2,0,0,0);
  return;
}



/* FUNCTION 25931 ; VA 0x00bb49e0 ; FUN_00bb49e0 */

void __thiscall FUN_00bb49e0(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x6d) != param_2) {
    *(char *)(param_1 + 0x6d) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25932 ; VA 0x00bb4a00 ; FUN_00bb4a00 */

void FUN_00bb4a00(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  
  lVar2 = CONCAT44(param_5,param_4);
  cVar1 = FUN_00e31310(param_4,param_5);
  if (cVar1 == '\0') {
    lVar2 = FUN_005565e0();
  }
  lVar3 = FUN_01017a80(param_3);
  FUN_01017c10(param_3,lVar2,cVar1 == '\0');
  if (lVar2 != lVar3) {
    FUN_008a4940(param_6);
  }
  return;
}



/* FUNCTION 25933 ; VA 0x00bb4a80 ; FUN_00bb4a80 */

void __thiscall FUN_00bb4a80(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0xd0) != param_2) {
    *(char *)(param_1 + 0xd0) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25934 ; VA 0x00bb4ab0 ; FUN_00bb4ab0 */

void __thiscall FUN_00bb4ab0(int param_1,float param_2)

{
  float fVar1;
  float fVar2;
  
  fVar2 = *(float *)(param_1 + 0x68);
  if (*(float *)(param_1 + 0x68) <= param_2) {
    fVar2 = param_2;
  }
  fVar1 = (float)DAT_01d67a58;
  if (fVar2 <= (float)DAT_01d67a58) {
    fVar1 = fVar2;
  }
  if ((NAN(*(float *)(param_1 + 100)) || NAN(fVar1)) == (*(float *)(param_1 + 100) == fVar1)) {
    *(float *)(param_1 + 100) = fVar1;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25935 ; VA 0x00bb4af0 ; FUN_00bb4af0 */

void __thiscall FUN_00bb4af0(int param_1,float param_2)

{
  float fVar1;
  float fVar2;
  
  fVar1 = DAT_018ce2f4;
  if (DAT_018ce2f4 <= param_2) {
    fVar1 = param_2;
  }
  fVar2 = *(float *)(param_1 + 100);
  if (fVar1 <= *(float *)(param_1 + 100)) {
    fVar2 = fVar1;
  }
  if ((NAN(*(float *)(param_1 + 0x68)) || NAN(fVar2)) == (*(float *)(param_1 + 0x68) == fVar2)) {
    *(float *)(param_1 + 0x68) = fVar2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25936 ; VA 0x00bb4b30 ; FUN_00bb4b30 */

void __thiscall FUN_00bb4b30(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0x58) != param_2) {
    *(int *)(param_1 + 0x58) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25937 ; VA 0x00bb4b50 ; FUN_00bb4b50 */

void __thiscall FUN_00bb4b50(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0xc0) != param_2) {
    *(int *)(param_1 + 0xc0) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25938 ; VA 0x00bb4b80 ; FUN_00bb4b80 */

void __thiscall FUN_00bb4b80(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0xbc) != param_2) {
    *(int *)(param_1 + 0xbc) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25939 ; VA 0x00bb4bb0 ; FUN_00bb4bb0 */

void __thiscall FUN_00bb4bb0(int param_1,int param_2)

{
  if (*(int *)(param_1 + 200) != param_2) {
    *(int *)(param_1 + 200) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25940 ; VA 0x00bb4be0 ; FUN_00bb4be0 */

void __thiscall FUN_00bb4be0(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0xb8) != param_2) {
    *(int *)(param_1 + 0xb8) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25941 ; VA 0x00bb4c10 ; FUN_00bb4c10 */

void __thiscall FUN_00bb4c10(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0xc4) != param_2) {
    *(int *)(param_1 + 0xc4) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25942 ; VA 0x00bb4c40 ; FUN_00bb4c40 */

void __thiscall FUN_00bb4c40(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x6c) != param_2) {
    *(char *)(param_1 + 0x6c) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25943 ; VA 0x00bb4c60 ; FUN_00bb4c60 */

void __thiscall FUN_00bb4c60(int param_1,int param_2)

{
  if (param_2 != *(int *)(param_1 + 0x70)) {
    *(int *)(param_1 + 0x70) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25944 ; VA 0x00bb4c80 ; FUN_00bb4c80 */

void __thiscall FUN_00bb4c80(int param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00bb4a00(param_1,param_1 + 0x78,0x12,param_2,param_3,&DAT_02131860);
  return;
}



/* FUNCTION 25945 ; VA 0x00bb4cb0 ; FUN_00bb4cb0 */

void __thiscall FUN_00bb4cb0(int param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00bb4a00(param_1,param_1 + 0x78,0x11,param_2,param_3,&DAT_02131828);
  return;
}



/* FUNCTION 25946 ; VA 0x00bb4ce0 ; FUN_00bb4ce0 */

void __thiscall FUN_00bb4ce0(int param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00bb4a00(param_1,param_1 + 0x78,0x1d,param_2,param_3,&DAT_02131908);
  return;
}



/* FUNCTION 25947 ; VA 0x00bb4d10 ; FUN_00bb4d10 */

void __thiscall FUN_00bb4d10(int param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00bb4a00(param_1,param_1 + 0x78,0x1e,param_2,param_3,&DAT_02131940);
  return;
}



/* FUNCTION 25948 ; VA 0x00bb4d40 ; FUN_00bb4d40 */

void __thiscall FUN_00bb4d40(int param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00bb4a00(param_1,param_1 + 0x78,0xc,param_2,param_3,&DAT_021317f0);
  return;
}



/* FUNCTION 25949 ; VA 0x00bb4d70 ; FUN_00bb4d70 */

void __thiscall FUN_00bb4d70(int param_1,int param_2)

{
  if (param_2 != *(int *)(param_1 + 0x74)) {
    *(int *)(param_1 + 0x74) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25950 ; VA 0x00bb4d90 ; FUN_00bb4d90 */

void __thiscall FUN_00bb4d90(int param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00bb4a00(param_1,param_1 + 0x78,0x1c,param_2,param_3,&DAT_021318d0);
  return;
}



/* FUNCTION 25951 ; VA 0x00bb4dc0 ; FUN_00bb4dc0 */

void __thiscall FUN_00bb4dc0(int param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00bb4a00(param_1,param_1 + 0x78,0x1f,param_2,param_3,&DAT_02131978);
  return;
}



/* FUNCTION 25952 ; VA 0x00bb4df0 ; FUN_00bb4df0 */

void FUN_00bb4df0(float *param_1)

{
  float *pfVar1;
  undefined auStack_c [8];
  
  pfVar1 = (float *)FUN_01017ad0(auStack_c);
  if (((NAN(*param_1) || NAN(*pfVar1)) == (*param_1 == *pfVar1)) ||
     ((NAN(param_1[1]) || NAN(pfVar1[1])) == (param_1[1] == pfVar1[1]))) {
    FUN_01017ca0(param_1);
    FUN_008a4940(&DAT_02131710);
  }
  return;
}



/* FUNCTION 25953 ; VA 0x00bb4e50 ; FUN_00bb4e50 */

void FUN_00bb4e50(float *param_1)

{
  float *pfVar1;
  undefined auStack_c [8];
  
  pfVar1 = (float *)FUN_01017b00(auStack_c);
  if (((NAN(*param_1) || NAN(*pfVar1)) == (*param_1 == *pfVar1)) ||
     ((NAN(param_1[1]) || NAN(pfVar1[1])) == (param_1[1] == pfVar1[1]))) {
    FUN_01017cc0(param_1);
    FUN_008a4940(&DAT_021316d8);
  }
  return;
}



/* FUNCTION 25954 ; VA 0x00bb4eb0 ; FUN_00bb4eb0 */

void FUN_00bb4eb0(float *param_1)

{
  float *pfVar1;
  undefined auStack_c [8];
  
  pfVar1 = (float *)FUN_01017b30(auStack_c);
  if (((NAN(*param_1) || NAN(*pfVar1)) == (*param_1 == *pfVar1)) ||
     ((NAN(param_1[1]) || NAN(pfVar1[1])) == (param_1[1] == pfVar1[1]))) {
    FUN_01017ce0(param_1);
    FUN_008a4940(&DAT_02131668);
  }
  return;
}



/* FUNCTION 25955 ; VA 0x00bb4f10 ; FUN_00bb4f10 */

void FUN_00bb4f10(float *param_1)

{
  float *pfVar1;
  undefined auStack_c [8];
  
  pfVar1 = (float *)FUN_01017b60(auStack_c);
  if (((NAN(*param_1) || NAN(*pfVar1)) == (*param_1 == *pfVar1)) ||
     ((NAN(param_1[1]) || NAN(pfVar1[1])) == (param_1[1] == pfVar1[1]))) {
    FUN_01017d00(param_1);
    FUN_008a4940(&DAT_02131748);
  }
  return;
}



/* FUNCTION 25956 ; VA 0x00bb4f70 ; FUN_00bb4f70 */

void FUN_00bb4f70(float *param_1)

{
  float *pfVar1;
  undefined auStack_c [8];
  
  pfVar1 = (float *)FUN_01017b90(auStack_c);
  if (((NAN(*param_1) || NAN(*pfVar1)) == (*param_1 == *pfVar1)) ||
     ((NAN(param_1[1]) || NAN(pfVar1[1])) == (param_1[1] == pfVar1[1]))) {
    FUN_00c3e680(param_1);
    FUN_008a4940(&DAT_021316a0);
  }
  return;
}



/* FUNCTION 25957 ; VA 0x00bb4fd0 ; FUN_00bb4fd0 */

void __thiscall FUN_00bb4fd0(int param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00bb4a00(param_1,param_1 + 0x78,0xb,param_2,param_3,&DAT_021317b8);
  return;
}



/* FUNCTION 25958 ; VA 0x00bb5000 ; FUN_00bb5000 */

void __thiscall FUN_00bb5000(int param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00bb4a00(param_1,param_1 + 0x78,2,param_2,param_3,&DAT_02131780);
  return;
}



/* FUNCTION 25959 ; VA 0x00bb5030 ; FUN_00bb5030 */

void __thiscall FUN_00bb5030(int param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00bb4a00(param_1,param_1 + 0x78,0x1b,param_2,param_3,&DAT_02131898);
  return;
}



/* FUNCTION 25960 ; VA 0x00bb5060 ; FUN_00bb5060 */

void __thiscall FUN_00bb5060(int param_1,float param_2)

{
  float fVar1;
  
  fVar1 = 0.0;
  if (0.0 <= param_2) {
    fVar1 = param_2;
  }
  if ((NAN(*(float *)(param_1 + 0x60)) || NAN(fVar1)) == (*(float *)(param_1 + 0x60) == fVar1)) {
    *(float *)(param_1 + 0x60) = fVar1;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25961 ; VA 0x00bb5090 ; FUN_00bb5090 */

int __thiscall
FUN_00bb5090(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd880;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_0060dcd0(auStack_20,param_1);
  uStack_18 = *puVar4;
  piStack_14 = (int *)puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  uStack_8 = 1;
  iVar5 = FUN_00f9b6f0(param_2,&uStack_18,param_3,param_4);
  piVar2 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar3 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar5 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar2 = piStack_1c + 1;
    iVar3 = *piVar2;
    iVar5 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar5 = (**(code **)*piStack_1c)();
      LOCK();
      piVar2 = piStack_1c + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar5 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 25962 ; VA 0x00bb5170 ; FUN_00bb5170 */

void __thiscall FUN_00bb5170(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0xd1) != param_2) {
    *(char *)(param_1 + 0xd1) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25963 ; VA 0x00bb51a0 ; FUN_00bb51a0 */

void __thiscall FUN_00bb51a0(int param_1,float param_2)

{
  float fVar1;
  
  fVar1 = 0.0;
  if (0.0 <= param_2) {
    fVar1 = param_2;
  }
  if ((NAN(*(float *)(param_1 + 0x5c)) || NAN(fVar1)) == (*(float *)(param_1 + 0x5c) == fVar1)) {
    *(float *)(param_1 + 0x5c) = fVar1;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25964 ; VA 0x00bb51d0 ; FUN_00bb51d0 */

void __thiscall FUN_00bb51d0(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x6e) != param_2) {
    *(char *)(param_1 + 0x6e) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25965 ; VA 0x00bb51f0 ; FUN_00bb51f0 */

void __thiscall FUN_00bb51f0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  undefined auStack_e4 [200];
  code *pcStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc5bb;
  pvStack_10 = ExceptionList;
  iVar1 = *param_3;
  pcStack_1c = *(code **)(**(int **)(param_1 + 0x34) + 0x10);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00b33310();
  if (iVar1 == iVar2) {
    iVar1 = *param_3;
    iVar2 = FUN_00b33310();
    if (iVar1 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar4 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar4 = (int *)0x0;
    }
    iStack_18 = *piVar4;
    iStack_14 = piVar4[1];
  }
  else {
    puVar3 = (undefined4 *)param_3[1];
    if (puVar3 != (undefined4 *)0x0) {
      (*(code *)*puVar3)(param_3 + 2,auStack_e4);
      puVar3 = (undefined4 *)param_3[1];
    }
    uStack_8 = 0;
    piVar4 = (int *)FUN_00b331e0();
    iStack_18 = *piVar4;
    iStack_14 = piVar4[1];
    uStack_8 = 1;
    if (puVar3 != (undefined4 *)0x0) {
      (*(code *)puVar3[2])(auStack_e4);
    }
    uStack_8 = 0xffffffff;
  }
  (*pcStack_1c)(param_2,&iStack_18);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25966 ; VA 0x00bb5300 ; FUN_00bb5300 */

void __thiscall FUN_00bb5300(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_00935ba0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25967 ; VA 0x00bb5350 ; FUN_00bb5350 */

void __thiscall FUN_00bb5350(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_00935c30();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25968 ; VA 0x00bb53a0 ; FUN_00bb53a0 */

void __thiscall FUN_00bb53a0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_00935cc0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25969 ; VA 0x00bb53f0 ; FUN_00bb53f0 */

void __thiscall FUN_00bb53f0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_00935d50();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25970 ; VA 0x00bb5440 ; FUN_00bb5440 */

void __thiscall FUN_00bb5440(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_00935de0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25971 ; VA 0x00bb5490 ; FUN_00bb5490 */

void __thiscall FUN_00bb5490(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_0090bd10();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25972 ; VA 0x00bb54e0 ; FUN_00bb54e0 */

void __thiscall FUN_00bb54e0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_0090c0c0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25973 ; VA 0x00bb5530 ; FUN_00bb5530 */

uint __fastcall FUN_00bb5530(int *param_1)

{
  uint *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  int iVar5;
  void **ppvVar6;
  int iVar7;
  uint uVar8;
  int *piVar9;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd940;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)param_1[0xb];
  ppvVar6 = &pvStack_10;
  piStack_14 = param_1;
  if (puVar3 != (undefined4 *)0x0) {
    piVar4 = (int *)puVar3[1];
    ExceptionList = &pvStack_10;
    for (piVar9 = (int *)*puVar3; ppvVar6 = (void **)ExceptionList, piVar9 != piVar4;
        piVar9 = piVar9 + 2) {
      if ((*piVar9 != 0) &&
         (iVar5 = *(int *)(*piVar9 + 0xc), iVar7 = FUN_00c4b970(),
         (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
         (uint)*(ushort *)(iVar7 + 0x1da))) goto LAB_00bb55ef;
    }
  }
  ExceptionList = ppvVar6;
  piVar4 = piStack_14;
  FUN_00bb29a0(&iStack_20);
  uStack_8 = 0;
  if (iStack_20 != 0) {
    FUN_008a65e0(piVar4,0);
  }
  uStack_8 = 0xffffffff;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar5 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar5 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
LAB_00bb55ef:
  puVar3 = (undefined4 *)piStack_14[0xb];
  if (puVar3 != (undefined4 *)0x0) {
    piVar4 = (int *)puVar3[1];
    for (piVar9 = (int *)*puVar3; piVar9 != piVar4; piVar9 = piVar9 + 2) {
      if (*piVar9 != 0) {
        iVar5 = *(int *)(*piVar9 + 0xc);
        iVar7 = FUN_00c4b870();
        if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
            (uint)*(ushort *)(iVar7 + 0x1da)) {
          ExceptionList = pvStack_10;
          return (uint)*(ushort *)(iVar7 + 0x1da);
        }
      }
    }
  }
  piVar4 = piStack_14;
  uVar8 = FUN_00bb28e0(&iStack_18);
  uStack_8 = 1;
  if (iStack_18 != 0) {
    uVar8 = FUN_008a65e0(piVar4,0);
  }
  piVar4 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_14 + 1);
    uVar2 = *puVar1;
    uVar8 = *puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      uVar8 = (**(code **)*piStack_14)();
      LOCK();
      piVar9 = piVar4 + 2;
      iVar5 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        uVar8 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 25974 ; VA 0x00bb5690 ; FUN_00bb5690 */

void FUN_00bb5690(void)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  uint uVar4;
  uint uVar5;
  char *pcVar6;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd960;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00c4b970();
  pcVar6 = *(char **)(iVar2 + 4);
  if (0xf < *(uint *)(pcVar6 + 0x14)) {
    pcVar6 = *(char **)pcVar6;
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  pcVar3 = pcVar6;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar6,(int)pcVar3 - (int)(pcVar6 + 1));
  uStack_8 = 0;
  iVar2 = FUN_008a14e0(auStack_28);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_14) {
    uVar5 = uStack_14 + 1;
    uVar4 = auStack_28[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_28[0] - 4);
      uVar5 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  if (iVar2 != 0) {
    *(undefined *)(iVar2 + 0x22) = 0;
  }
  iVar2 = FUN_00c4b870();
  pcVar6 = *(char **)(iVar2 + 4);
  if (0xf < *(uint *)(pcVar6 + 0x14)) {
    pcVar6 = *(char **)pcVar6;
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  pcVar3 = pcVar6;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar6,(int)pcVar3 - (int)(pcVar6 + 1));
  uStack_8 = 1;
  iVar2 = FUN_008a14e0(auStack_28);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_14) {
    uVar5 = uStack_14 + 1;
    uVar4 = auStack_28[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_28[0] - 4);
      uVar5 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  if (iVar2 != 0) {
    *(undefined *)(iVar2 + 0x22) = 0;
  }
  FUN_008a50b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25975 ; VA 0x00bb57f0 ; FUN_00bb57f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_00bb57f0(undefined4 param_1,char param_2)

{
  int iVar1;
  float fVar2;
  short sStack_c;
  short sStack_a;
  short sStack_8;
  
  FUN_01168d80(param_1);
  if (param_2 != '\0') {
    iVar1 = (int)sStack_c;
    switch(iVar1) {
    case 1:
      return (float10)_DAT_0195c1a8;
    case 2:
      return (float10)_DAT_0195c1b8;
    case 3:
      return (float10)_DAT_0195c1c8;
    case 4:
      return (float10)_DAT_0195c1dc;
    default:
      return (float10)((float)(iVar1 * iVar1 * iVar1) * _DAT_0195c1a4);
    }
  }
  iVar1 = (int)sStack_c;
  if (iVar1 == 1) {
    switch((int)sStack_a) {
    case 1:
      switch((int)sStack_8) {
      case 1:
        return (float10)_DAT_0195c1b4;
      case 2:
        return (float10)_DAT_0195c1bc;
      case 3:
        return (float10)DAT_018daf58;
      case 4:
        return (float10)_DAT_0195c1c0;
      default:
        return (float10)((float)(int)sStack_8 * DAT_0191a25c);
      }
    case 2:
      goto switchD_00bb59b0_caseD_2;
    case 3:
      _param_2 = 1.66;
      if (DAT_018fde90 <= (float)(int)sStack_8) {
        _param_2 = 1.18;
      }
      return (float10)(int)sStack_8 * (float10)_param_2;
    case 4:
      _param_2 = 2.26;
      if (DAT_018fde90 <= (float)(int)sStack_8) {
        _param_2 = 1.53;
      }
      return (float10)(int)sStack_8 * (float10)_param_2;
    default:
      return (float10)(((float)(int)sStack_a * DAT_018fde64 + _DAT_0195c1b0) * (float)(int)sStack_8)
      ;
    }
  }
  if (iVar1 != 2) {
    return (float10)((float)((int)sStack_8 * (int)sStack_a * iVar1) * DAT_018e1340);
  }
  iVar1 = (int)sStack_a;
  if (iVar1 == 2) {
    iVar1 = (int)sStack_8;
    if (iVar1 == 2) {
      return (float10)_DAT_0195c1d0;
    }
    if (iVar1 == 3) {
      return (float10)_DAT_0195c1d4;
    }
    if (iVar1 == 4) {
      return (float10)_DAT_0195c1d8;
    }
    _param_2 = 1.9;
    if (DAT_01919f9c <= (float)iVar1) {
      _param_2 = 1.5;
    }
    return (float10)iVar1 * (float10)_param_2;
  }
  if (iVar1 != 3) {
    return (float10)((float)iVar1 * _DAT_0195c1b0 * (float)(int)sStack_8);
  }
  iVar1 = (int)sStack_8;
  if (iVar1 == 3) {
    return (float10)DAT_01919f9c;
  }
  if (iVar1 == 4) {
    return (float10)DAT_0195c1e0;
  }
  fVar2 = (float)iVar1;
  if (DAT_01919f9c <= fVar2) {
    return (float10)(fVar2 * DAT_018df57c);
  }
  return (float10)(fVar2 + fVar2);
switchD_00bb59b0_caseD_2:
  iVar1 = (int)sStack_8;
  if (iVar1 == 2) {
    return (float10)_DAT_0191a35c;
  }
  if (iVar1 == 3) {
    return (float10)_DAT_0195c1c4;
  }
  if (iVar1 == 4) {
    return (float10)_DAT_0195c1cc;
  }
  _param_2 = 0.9;
  if (DAT_01919f9c <= (float)iVar1) {
    _param_2 = 0.75;
  }
  return (float10)iVar1 * (float10)_param_2;
}



/* FUNCTION 25976 ; VA 0x00bb5b40 ; FUN_00bb5b40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_00bb5b40(undefined4 param_1,undefined4 param_2)

{
  float10 fVar1;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  FUN_00c95580(&fStack_14,param_1);
  if (fStack_c <= DAT_018ce2f8) {
    fStack_c = DAT_018ce2f8;
  }
  if (fStack_10 <= DAT_018ce2f8) {
    fStack_10 = DAT_018ce2f8;
  }
  fStack_20 = fStack_14;
  if (fStack_14 <= DAT_018ce2f8) {
    fStack_20 = DAT_018ce2f8;
  }
  fStack_1c = fStack_10;
  fStack_18 = fStack_c;
  fVar1 = (float10)FUN_00bb57f0(&fStack_20,param_2);
  fStack_8 = (float)fVar1;
  if (fStack_14 < DAT_018ce2f8) {
    fStack_8 = fStack_14 * fStack_8;
  }
  return (float10)fStack_8 * (float10)_DAT_0195c1e4 * (float10)_DAT_0195c1a0;
}



/* FUNCTION 25977 ; VA 0x00bb5be0 ; FUN_00bb5be0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_00bb5be0(void)

{
  return (float10)_DAT_0195c198;
}



/* FUNCTION 25978 ; VA 0x00bb5bf0 ; FUN_00bb5bf0 */

undefined4 FUN_00bb5bf0(void)

{
  return 0xf0;
}



/* FUNCTION 25979 ; VA 0x00bb5c00 ; FUN_00bb5c00 */

int __thiscall FUN_00bb5c00(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  uint uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  undefined4 *puVar9;
  uint uVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  int iVar13;
  undefined4 *puVar14;
  
  iVar2 = ((int)param_2 - *param_1) / 0x14;
  iVar8 = (param_1[1] - *param_1) / 0x14;
  if (iVar8 == 0xccccccc) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar8 + 1;
  uVar10 = (param_1[2] - *param_1) / 0x14;
  uVar6 = uVar1;
  if ((uVar10 <= 0xccccccc - (uVar10 >> 1)) && (uVar6 = (uVar10 >> 1) + uVar10, uVar6 < uVar1)) {
    uVar6 = uVar1;
  }
  uVar10 = uVar6 * 0x14;
  if (uVar6 < 0xccccccd) {
    if (0xfff < uVar10) goto LAB_00bb5c9e;
    if (uVar10 == 0) {
      puVar12 = (undefined4 *)0x0;
    }
    else {
      puVar12 = (undefined4 *)FUN_01674e20(uVar10);
    }
  }
  else {
    uVar10 = 0xffffffff;
LAB_00bb5c9e:
    uVar7 = uVar10 + 0x23;
    if (uVar7 <= uVar10) {
      uVar7 = 0xffffffff;
    }
    iVar8 = FUN_01674e20(uVar7);
    if (iVar8 == 0) goto LAB_00bb5de4;
    puVar12 = (undefined4 *)(iVar8 + 0x23U & 0xffffffe0);
    puVar12[-1] = iVar8;
  }
  uVar3 = param_3[1];
  uVar4 = param_3[2];
  uVar5 = param_3[3];
  puVar14 = puVar12 + iVar2 * 5;
  *puVar14 = *param_3;
  puVar14[1] = uVar3;
  puVar14[2] = uVar4;
  puVar14[3] = uVar5;
  puVar12[iVar2 * 5 + 4] = param_3[4];
  puVar14 = (undefined4 *)param_1[1];
  puVar9 = (undefined4 *)*param_1;
  puVar11 = puVar12;
  if (param_2 == puVar14) {
    for (; puVar9 != puVar14; puVar9 = puVar9 + 5) {
      uVar3 = puVar9[1];
      uVar4 = puVar9[2];
      uVar5 = puVar9[3];
      *puVar11 = *puVar9;
      puVar11[1] = uVar3;
      puVar11[2] = uVar4;
      puVar11[3] = uVar5;
      puVar11[4] = puVar9[4];
      puVar11 = puVar11 + 5;
    }
  }
  else {
    if (puVar9 != param_2) {
      do {
        uVar3 = puVar9[1];
        uVar4 = puVar9[2];
        uVar5 = puVar9[3];
        *puVar11 = *puVar9;
        puVar11[1] = uVar3;
        puVar11[2] = uVar4;
        puVar11[3] = uVar5;
        puVar14 = puVar9 + 4;
        puVar9 = puVar9 + 5;
        puVar11[4] = *puVar14;
        puVar11 = puVar11 + 5;
      } while (puVar9 != param_2);
      puVar14 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar14) {
      puVar9 = puVar12 + iVar2 * 5 + 5;
      do {
        uVar3 = param_2[1];
        uVar4 = param_2[2];
        uVar5 = param_2[3];
        *puVar9 = *param_2;
        puVar9[1] = uVar3;
        puVar9[2] = uVar4;
        puVar9[3] = uVar5;
        puVar11 = param_2 + 4;
        param_2 = param_2 + 5;
        puVar9[4] = *puVar11;
        puVar9 = puVar9 + 5;
      } while (param_2 != puVar14);
    }
  }
  iVar8 = *param_1;
  if (iVar8 != 0) {
    uVar10 = ((param_1[2] - iVar8) / 0x14) * 0x14;
    iVar13 = iVar8;
    if (0xfff < uVar10) {
      iVar13 = *(int *)(iVar8 + -4);
      uVar10 = uVar10 + 0x23;
      if (0x1f < (iVar8 - iVar13) - 4U) {
LAB_00bb5de4:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar13,uVar10);
  }
  *param_1 = (int)puVar12;
  param_1[1] = (int)(puVar12 + uVar1 * 5);
  param_1[2] = (int)(puVar12 + uVar6 * 5);
  return *param_1 + iVar2 * 0x14;
}



/* FUNCTION 25980 ; VA 0x00bb5df0 ; FUN_00bb5df0 */

int __thiscall FUN_00bb5df0(int *param_1,undefined8 *param_2,undefined8 *param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  undefined8 *puVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  undefined8 *puVar8;
  undefined8 *puVar9;
  int iVar10;
  undefined8 *puVar11;
  
  iVar6 = *param_1;
  iVar3 = (param_1[1] - *param_1) / 0xc;
  if (iVar3 == 0x15555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar3 + 1;
  uVar5 = (param_1[2] - *param_1) / 0xc;
  uVar7 = uVar1;
  if ((uVar5 <= 0x15555555 - (uVar5 >> 1)) && (uVar7 = (uVar5 >> 1) + uVar5, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  uVar5 = uVar7 * 0xc;
  if (uVar7 < 0x15555556) {
    uVar7 = uVar5;
    if (0xfff < uVar5) goto LAB_00bb5e8b;
    if (uVar5 == 0) {
      puVar9 = (undefined8 *)0x0;
    }
    else {
      puVar9 = (undefined8 *)FUN_01674e20(uVar5);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_00bb5e8b:
    uVar2 = uVar7 + 0x23;
    if (uVar2 <= uVar7) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_00bb5fdc;
    puVar9 = (undefined8 *)(iVar3 + 0x23U & 0xffffffe0);
    *(int *)((int)puVar9 + -4) = iVar3;
  }
  iVar6 = (((int)param_2 - iVar6) / 0xc) * 0xc;
  *(undefined8 *)(iVar6 + (int)puVar9) = *param_3;
  *(undefined4 *)(iVar6 + 8 + (int)puVar9) = *(undefined4 *)(param_3 + 1);
  puVar11 = (undefined8 *)param_1[1];
  puVar4 = (undefined8 *)*param_1;
  puVar8 = puVar9;
  if (param_2 == puVar11) {
    for (; puVar4 != puVar11; puVar4 = (undefined8 *)((int)puVar4 + 0xc)) {
      *puVar8 = *puVar4;
      *(undefined4 *)(puVar8 + 1) = *(undefined4 *)(puVar4 + 1);
      puVar8 = (undefined8 *)((int)puVar8 + 0xc);
    }
  }
  else {
    if (puVar4 != param_2) {
      do {
        *puVar8 = *puVar4;
        puVar11 = puVar4 + 1;
        puVar4 = (undefined8 *)((int)puVar4 + 0xc);
        *(undefined4 *)(puVar8 + 1) = *(undefined4 *)puVar11;
        puVar8 = (undefined8 *)((int)puVar8 + 0xc);
      } while (puVar4 != param_2);
      puVar11 = (undefined8 *)param_1[1];
    }
    if (param_2 != puVar11) {
      puVar4 = (undefined8 *)(iVar6 + 0xc + (int)puVar9);
      do {
        *puVar4 = *param_2;
        puVar8 = param_2 + 1;
        param_2 = (undefined8 *)((int)param_2 + 0xc);
        *(undefined4 *)(puVar4 + 1) = *(undefined4 *)puVar8;
        puVar4 = (undefined8 *)((int)puVar4 + 0xc);
      } while (param_2 != puVar11);
    }
  }
  iVar3 = *param_1;
  if (iVar3 != 0) {
    uVar7 = ((param_1[2] - iVar3) / 0xc) * 0xc;
    iVar10 = iVar3;
    if (0xfff < uVar7) {
      iVar10 = *(int *)(iVar3 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar3 - iVar10) - 4U) {
LAB_00bb5fdc:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar10,uVar7);
  }
  *param_1 = (int)puVar9;
  param_1[1] = (int)puVar9 + uVar1 * 0xc;
  param_1[2] = uVar5 + (int)puVar9;
  return *param_1 + iVar6;
}



/* FUNCTION 25981 ; VA 0x00bb5ff0 ; FUN_00bb5ff0 */

void FUN_00bb5ff0(int param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  float *pfVar3;
  float fVar4;
  float fVar5;
  uint uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  int iVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  int iVar14;
  bool bVar15;
  int iVar16;
  int iVar17;
  int iVar18;
  int iVar19;
  int iVar20;
  
  uVar6 = (param_2 - param_1) / 0x14;
  iVar19 = (int)uVar6 >> 1;
  if (0 < iVar19) {
    iVar20 = (int)(uVar6 - 1) >> 1;
    iVar16 = param_1 + iVar19 * 0x14;
    do {
      uVar7 = *(undefined4 *)(iVar16 + -0x14);
      uVar8 = *(undefined4 *)(iVar16 + -0x10);
      uVar9 = *(undefined4 *)(iVar16 + -0xc);
      iVar10 = *(int *)(iVar16 + -8);
      iVar19 = iVar19 + -1;
      fVar5 = *(float *)(iVar16 + -4);
      iVar14 = iVar19;
      while (iVar14 < iVar20) {
        iVar18 = *(int *)(param_1 + 0x34 + iVar14 * 0x28);
        iVar17 = *(int *)(param_1 + 0x20 + iVar14 * 0x28);
        if (iVar18 == iVar17) {
          fVar4 = *(float *)(param_1 + 0x24 + iVar14 * 0x28);
          pfVar3 = (float *)(param_1 + 0x38 + iVar14 * 0x28);
          bVar15 = *pfVar3 <= fVar4 && fVar4 != *pfVar3;
        }
        else {
          bVar15 = iVar18 < iVar17;
        }
        iVar17 = (bVar15 ^ 1) + 1 + iVar14 * 2;
        puVar1 = (undefined4 *)(param_1 + iVar17 * 0x14);
        uVar11 = puVar1[1];
        uVar12 = puVar1[2];
        uVar13 = puVar1[3];
        puVar2 = (undefined4 *)(param_1 + iVar14 * 0x14);
        *puVar2 = *puVar1;
        puVar2[1] = uVar11;
        puVar2[2] = uVar12;
        puVar2[3] = uVar13;
        *(undefined4 *)(param_1 + 0x10 + iVar14 * 0x14) =
             *(undefined4 *)(param_1 + 0x10 + iVar17 * 0x14);
        iVar14 = iVar17;
      }
      if ((iVar14 == iVar20) && ((uVar6 & 1) == 0)) {
        puVar2 = (undefined4 *)(param_1 + -0x14 + uVar6 * 0x14);
        uVar11 = puVar2[1];
        uVar12 = puVar2[2];
        uVar13 = puVar2[3];
        puVar1 = (undefined4 *)(param_1 + iVar14 * 0x14);
        *puVar1 = *puVar2;
        puVar1[1] = uVar11;
        puVar1[2] = uVar12;
        puVar1[3] = uVar13;
        *(undefined4 *)(param_1 + 0x10 + iVar14 * 0x14) =
             *(undefined4 *)(param_1 + -4 + uVar6 * 0x14);
        iVar14 = uVar6 - 1;
      }
      while (iVar19 < iVar14) {
        iVar18 = iVar14 + -1 >> 1;
        iVar17 = *(int *)(param_1 + 0xc + iVar18 * 0x14);
        if (iVar17 == iVar10) {
          pfVar3 = (float *)(param_1 + 0x10 + iVar18 * 0x14);
          bVar15 = *pfVar3 <= fVar5 && fVar5 != *pfVar3;
        }
        else {
          bVar15 = iVar17 < iVar10;
        }
        if (!bVar15) break;
        puVar1 = (undefined4 *)(param_1 + iVar18 * 0x14);
        uVar11 = puVar1[1];
        uVar12 = puVar1[2];
        uVar13 = puVar1[3];
        puVar2 = (undefined4 *)(param_1 + iVar14 * 0x14);
        *puVar2 = *puVar1;
        puVar2[1] = uVar11;
        puVar2[2] = uVar12;
        puVar2[3] = uVar13;
        *(undefined4 *)(param_1 + 0x10 + iVar14 * 0x14) =
             *(undefined4 *)(param_1 + 0x10 + iVar18 * 0x14);
        iVar14 = iVar18;
      }
      puVar1 = (undefined4 *)(param_1 + iVar14 * 0x14);
      *puVar1 = uVar7;
      puVar1[1] = uVar8;
      puVar1[2] = uVar9;
      puVar1[3] = iVar10;
      *(float *)(param_1 + 0x10 + iVar14 * 0x14) = fVar5;
      iVar16 = iVar16 + -0x14;
    } while (0 < iVar19);
  }
  return;
}



/* FUNCTION 25982 ; VA 0x00bb6140 ; FUN_00bb6140 */

void FUN_00bb6140(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  bool bVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  int iVar10;
  
  iVar10 = param_2[3];
  if (iVar10 == param_1[3]) {
    bVar2 = (float)param_2[4] <= (float)param_1[4] && (float)param_1[4] != (float)param_2[4];
  }
  else {
    bVar2 = iVar10 < (int)param_1[3];
  }
  if (bVar2) {
    uVar3 = param_1[1];
    uVar4 = param_1[2];
    uVar5 = param_1[3];
    uVar1 = param_2[4];
    uVar6 = *param_2;
    uVar7 = param_2[1];
    uVar8 = param_2[2];
    uVar9 = param_2[3];
    *param_2 = *param_1;
    param_2[1] = uVar3;
    param_2[2] = uVar4;
    param_2[3] = uVar5;
    param_2[4] = param_1[4];
    *param_1 = uVar6;
    param_1[1] = uVar7;
    param_1[2] = uVar8;
    param_1[3] = uVar9;
    param_1[4] = uVar1;
    iVar10 = param_2[3];
  }
  if (param_3[3] == iVar10) {
    bVar2 = (float)param_3[4] <= (float)param_2[4] && (float)param_2[4] != (float)param_3[4];
  }
  else {
    bVar2 = (int)param_3[3] < iVar10;
  }
  if (bVar2) {
    uVar3 = param_2[1];
    uVar4 = param_2[2];
    uVar5 = param_2[3];
    uVar1 = param_3[4];
    uVar6 = *param_3;
    uVar7 = param_3[1];
    uVar8 = param_3[2];
    uVar9 = param_3[3];
    *param_3 = *param_2;
    param_3[1] = uVar3;
    param_3[2] = uVar4;
    param_3[3] = uVar5;
    param_3[4] = param_2[4];
    *param_2 = uVar6;
    param_2[1] = uVar7;
    param_2[2] = uVar8;
    param_2[3] = uVar9;
    param_2[4] = uVar1;
    if (param_2[3] == param_1[3]) {
      bVar2 = (float)param_2[4] <= (float)param_1[4] && (float)param_1[4] != (float)param_2[4];
    }
    else {
      bVar2 = (int)param_2[3] < (int)param_1[3];
    }
    if (bVar2) {
      uVar3 = param_1[1];
      uVar4 = param_1[2];
      uVar5 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = uVar3;
      param_2[2] = uVar4;
      param_2[3] = uVar5;
      param_2[4] = param_1[4];
      *param_1 = uVar6;
      param_1[1] = uVar7;
      param_1[2] = uVar8;
      param_1[3] = uVar9;
      param_1[4] = uVar1;
    }
  }
  return;
}



/* FUNCTION 25983 ; VA 0x00bb61f0 ; FUN_00bb61f0 */

void FUN_00bb61f0(uint *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  float fVar1;
  float fVar2;
  int iVar3;
  undefined4 uVar4;
  bool bVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 *puVar13;
  int iVar14;
  float *pfVar15;
  undefined4 *puVar16;
  undefined4 *puVar17;
  undefined4 *puVar18;
  undefined4 *puVar19;
  undefined4 *puVar20;
  undefined4 *puStack_c;
  undefined4 *puStack_8;
  
  puVar16 = param_3 + -5;
  puVar18 = param_2 + (((int)param_3 - (int)param_2) / 0x14 >> 1) * 5;
  iVar14 = ((int)puVar16 - (int)param_2) / 0x14;
  if (iVar14 < 0x29) {
    FUN_00bb6140(param_2,puVar18,puVar16,param_4);
  }
  else {
    iVar14 = iVar14 + 1 >> 3;
    FUN_00bb6140(param_2,param_2 + iVar14 * 5,param_2 + iVar14 * 10,param_4);
    FUN_00bb6140(puVar18 + iVar14 * -5,puVar18,puVar18 + iVar14 * 5,param_4);
    FUN_00bb6140(puVar16 + iVar14 * -10,puVar16 + iVar14 * -5,puVar16,param_4);
    FUN_00bb6140(param_2 + iVar14 * 5,puVar18,puVar16 + iVar14 * -5,param_4);
  }
  puVar16 = puVar18 + 5;
  if (param_2 < puVar18) {
    pfVar15 = (float *)(puVar18 + -1);
    do {
      fVar1 = pfVar15[-1];
      fVar2 = pfVar15[4];
      if (fVar1 == fVar2) {
        bVar5 = *pfVar15 <= pfVar15[5] && pfVar15[5] != *pfVar15;
      }
      else {
        bVar5 = (int)fVar1 < (int)fVar2;
      }
      if (bVar5) break;
      if (fVar2 == fVar1) {
        bVar5 = pfVar15[5] <= *pfVar15 && *pfVar15 != pfVar15[5];
      }
      else {
        bVar5 = (int)fVar2 < (int)fVar1;
      }
      if (bVar5) break;
      puVar18 = puVar18 + -5;
      pfVar15 = pfVar15 + -5;
    } while (param_2 < puVar18);
  }
  puVar20 = puVar16;
  puStack_c = puVar16;
  puStack_8 = puVar18;
  puVar17 = puVar18;
  if (puVar16 < param_3) {
    iVar14 = puVar18[3];
    while( true ) {
      iVar3 = puVar16[3];
      if (iVar3 == iVar14) {
        bVar5 = (float)puVar16[4] <= (float)puVar18[4] && (float)puVar18[4] != (float)puVar16[4];
      }
      else {
        bVar5 = iVar3 < iVar14;
      }
      puVar20 = puVar16;
      puStack_c = puVar16;
      if (bVar5) break;
      if (iVar14 == iVar3) {
        bVar5 = (float)puVar18[4] <= (float)puVar16[4] && (float)puVar16[4] != (float)puVar18[4];
      }
      else {
        bVar5 = iVar14 < iVar3;
      }
      if ((bVar5) ||
         (puVar16 = puVar16 + 5, puVar20 = puVar16, puStack_c = puVar16, param_3 <= puVar16)) break;
    }
  }
joined_r0x00bb6362:
  do {
    puVar13 = puVar18;
    if (param_3 <= puVar16) {
joined_r0x00bb63d4:
      while (param_2 < puVar13) {
        iVar14 = puVar13[-2];
        iVar3 = puVar17[3];
        if (iVar14 == iVar3) {
          bVar5 = (float)puVar13[-1] <= (float)puVar17[4] && (float)puVar17[4] != (float)puVar13[-1]
          ;
        }
        else {
          bVar5 = iVar14 < iVar3;
        }
        puVar18 = puVar17;
        puVar16 = puStack_c;
        if (!bVar5) {
          if (iVar3 == iVar14) {
            bVar5 = (float)puVar17[4] <= (float)puVar13[-1] &&
                    (float)puVar13[-1] != (float)puVar17[4];
          }
          else {
            bVar5 = iVar3 < iVar14;
          }
          puStack_8 = puVar13;
          if (bVar5) break;
          puVar18 = puVar17 + -5;
          if (puVar18 != puVar13 + -5) {
            uVar6 = puVar13[-4];
            uVar7 = puVar13[-3];
            uVar8 = puVar13[-2];
            uVar4 = puVar17[-1];
            uVar9 = *puVar18;
            uVar10 = puVar17[-4];
            uVar11 = puVar17[-3];
            uVar12 = puVar17[-2];
            *puVar18 = puVar13[-5];
            puVar17[-4] = uVar6;
            puVar17[-3] = uVar7;
            puVar17[-2] = uVar8;
            puVar17[-1] = puVar13[-1];
            puVar13[-5] = uVar9;
            puVar13[-4] = uVar10;
            puVar13[-3] = uVar11;
            puVar13[-2] = uVar12;
            puVar13[-1] = uVar4;
          }
        }
        puStack_8 = puVar13 + -5;
        puVar17 = puVar18;
        puVar13 = puStack_8;
      }
      if (puVar13 == param_2) {
        if (puVar16 == param_3) {
          param_1[1] = (uint)puVar20;
          *param_1 = (uint)puVar17;
          return;
        }
        if (puVar20 != puVar16) {
          uVar6 = puVar20[1];
          uVar7 = puVar20[2];
          uVar8 = puVar20[3];
          uVar4 = puVar17[4];
          uVar9 = *puVar17;
          uVar10 = puVar17[1];
          uVar11 = puVar17[2];
          uVar12 = puVar17[3];
          *puVar17 = *puVar20;
          puVar17[1] = uVar6;
          puVar17[2] = uVar7;
          puVar17[3] = uVar8;
          puVar17[4] = puVar20[4];
          *puVar20 = uVar9;
          puVar20[1] = uVar10;
          puVar20[2] = uVar11;
          puVar20[3] = uVar12;
          puVar20[4] = uVar4;
        }
        uVar6 = puVar16[1];
        uVar7 = puVar16[2];
        uVar8 = puVar16[3];
        uVar4 = puVar17[4];
        uVar9 = *puVar17;
        uVar10 = puVar17[1];
        uVar11 = puVar17[2];
        uVar12 = puVar17[3];
        *puVar17 = *puVar16;
        puVar17[1] = uVar6;
        puVar17[2] = uVar7;
        puVar17[3] = uVar8;
        puVar17[4] = puVar16[4];
        *puVar16 = uVar9;
        puVar16[1] = uVar10;
        puVar16[2] = uVar11;
        puVar16[3] = uVar12;
        puVar16[4] = uVar4;
        puVar16 = puVar16 + 5;
        puVar18 = puVar13;
        puVar20 = puVar20 + 5;
        puStack_c = puVar16;
        puVar17 = puVar17 + 5;
      }
      else {
        puVar18 = puVar13 + -5;
        puStack_8 = puVar18;
        if (puVar16 == param_3) {
          puVar19 = puVar17 + -5;
          if (puVar18 != puVar19) {
            uVar6 = puVar17[-4];
            uVar7 = puVar17[-3];
            uVar8 = puVar17[-2];
            uVar4 = puVar13[-1];
            uVar9 = *puVar18;
            uVar10 = puVar13[-4];
            uVar11 = puVar13[-3];
            uVar12 = puVar13[-2];
            *puVar18 = *puVar19;
            puVar13[-4] = uVar6;
            puVar13[-3] = uVar7;
            puVar13[-2] = uVar8;
            puVar13[-1] = puVar17[-1];
            *puVar19 = uVar9;
            puVar17[-4] = uVar10;
            puVar17[-3] = uVar11;
            puVar17[-2] = uVar12;
            puVar17[-1] = uVar4;
          }
          uVar6 = puVar20[-4];
          uVar7 = puVar20[-3];
          uVar8 = puVar20[-2];
          uVar4 = puVar17[-1];
          uVar9 = *puVar19;
          uVar10 = puVar17[-4];
          uVar11 = puVar17[-3];
          uVar12 = puVar17[-2];
          *puVar19 = puVar20[-5];
          puVar17[-4] = uVar6;
          puVar17[-3] = uVar7;
          puVar17[-2] = uVar8;
          puVar17[-1] = puVar20[-1];
          puVar20[-5] = uVar9;
          puVar20[-4] = uVar10;
          puVar20[-3] = uVar11;
          puVar20[-2] = uVar12;
          puVar20[-1] = uVar4;
          puVar20 = puVar20 + -5;
          puVar17 = puVar19;
        }
        else {
          uVar6 = puVar13[-4];
          uVar7 = puVar13[-3];
          uVar8 = puVar13[-2];
          uVar4 = puVar16[4];
          uVar9 = *puVar16;
          uVar10 = puVar16[1];
          uVar11 = puVar16[2];
          uVar12 = puVar16[3];
          *puVar16 = *puVar18;
          puVar16[1] = uVar6;
          puVar16[2] = uVar7;
          puVar16[3] = uVar8;
          puVar16[4] = puVar13[-1];
          puVar16 = puVar16 + 5;
          *puVar18 = uVar9;
          puVar13[-4] = uVar10;
          puVar13[-3] = uVar11;
          puVar13[-2] = uVar12;
          puVar13[-1] = uVar4;
          puStack_c = puVar16;
        }
      }
      goto joined_r0x00bb6362;
    }
    iVar14 = puVar17[3];
    iVar3 = puVar16[3];
    if (iVar14 == iVar3) {
      bVar5 = (float)puVar17[4] <= (float)puVar16[4] && (float)puVar16[4] != (float)puVar17[4];
    }
    else {
      bVar5 = iVar14 < iVar3;
    }
    if (!bVar5) {
      if (iVar3 == iVar14) {
        bVar5 = (float)puVar16[4] <= (float)puVar17[4] && (float)puVar17[4] != (float)puVar16[4];
      }
      else {
        bVar5 = iVar3 < iVar14;
      }
      puVar13 = puStack_8;
      puStack_c = puVar16;
      if (bVar5) goto joined_r0x00bb63d4;
      if (puVar20 != puVar16) {
        uVar6 = puVar16[1];
        uVar7 = puVar16[2];
        uVar8 = puVar16[3];
        uVar4 = puVar20[4];
        uVar9 = *puVar20;
        uVar10 = puVar20[1];
        uVar11 = puVar20[2];
        uVar12 = puVar20[3];
        *puVar20 = *puVar16;
        puVar20[1] = uVar6;
        puVar20[2] = uVar7;
        puVar20[3] = uVar8;
        puVar20[4] = puVar16[4];
        *puVar16 = uVar9;
        puVar16[1] = uVar10;
        puVar16[2] = uVar11;
        puVar16[3] = uVar12;
        puVar16[4] = uVar4;
      }
      puVar20 = puVar20 + 5;
    }
    puVar16 = puVar16 + 5;
    puVar18 = puStack_8;
    puStack_c = puVar16;
  } while( true );
}



/* FUNCTION 25984 ; VA 0x00bb6520 ; FUN_00bb6520 */

void FUN_00bb6520(int param_1,int param_2,uint param_3,undefined4 *param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  float *pfVar3;
  float fVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  bool bVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  
  iVar10 = (int)(param_3 - 1) >> 1;
  iVar11 = param_2;
  iVar12 = param_2;
  if (param_2 < iVar10) {
    do {
      iVar5 = *(int *)(param_1 + 0x34 + iVar11 * 0x28);
      iVar12 = *(int *)(param_1 + 0x20 + iVar11 * 0x28);
      if (iVar5 == iVar12) {
        fVar4 = *(float *)(param_1 + 0x24 + iVar11 * 0x28);
        pfVar3 = (float *)(param_1 + 0x38 + iVar11 * 0x28);
        bVar9 = *pfVar3 <= fVar4 && fVar4 != *pfVar3;
      }
      else {
        bVar9 = iVar5 < iVar12;
      }
      iVar12 = (bVar9 ^ 1) + 1 + iVar11 * 2;
      puVar1 = (undefined4 *)(param_1 + iVar12 * 0x14);
      uVar6 = puVar1[1];
      uVar7 = puVar1[2];
      uVar8 = puVar1[3];
      puVar2 = (undefined4 *)(param_1 + iVar11 * 0x14);
      *puVar2 = *puVar1;
      puVar2[1] = uVar6;
      puVar2[2] = uVar7;
      puVar2[3] = uVar8;
      *(undefined4 *)(param_1 + 0x10 + iVar11 * 0x14) =
           *(undefined4 *)(param_1 + 0x10 + iVar12 * 0x14);
      iVar11 = iVar12;
    } while (iVar12 < iVar10);
  }
  if ((iVar12 == iVar10) && ((param_3 & 1) == 0)) {
    puVar2 = (undefined4 *)(param_1 + -0x14 + param_3 * 0x14);
    uVar6 = puVar2[1];
    uVar7 = puVar2[2];
    uVar8 = puVar2[3];
    puVar1 = (undefined4 *)(param_1 + iVar12 * 0x14);
    *puVar1 = *puVar2;
    puVar1[1] = uVar6;
    puVar1[2] = uVar7;
    puVar1[3] = uVar8;
    *(undefined4 *)(param_1 + 0x10 + iVar12 * 0x14) = *(undefined4 *)(param_1 + -4 + param_3 * 0x14)
    ;
    iVar12 = param_3 - 1;
  }
  while (param_2 < iVar12) {
    iVar10 = iVar12 + -1 >> 1;
    iVar11 = *(int *)(param_1 + 0xc + iVar10 * 0x14);
    if (iVar11 == param_4[3]) {
      pfVar3 = (float *)(param_1 + 0x10 + iVar10 * 0x14);
      bVar9 = *pfVar3 <= (float)param_4[4] && (float)param_4[4] != *pfVar3;
    }
    else {
      bVar9 = iVar11 < (int)param_4[3];
    }
    if (!bVar9) break;
    puVar1 = (undefined4 *)(param_1 + iVar10 * 0x14);
    uVar6 = puVar1[1];
    uVar7 = puVar1[2];
    uVar8 = puVar1[3];
    puVar2 = (undefined4 *)(param_1 + iVar12 * 0x14);
    *puVar2 = *puVar1;
    puVar2[1] = uVar6;
    puVar2[2] = uVar7;
    puVar2[3] = uVar8;
    *(undefined4 *)(param_1 + 0x10 + iVar12 * 0x14) =
         *(undefined4 *)(param_1 + 0x10 + iVar10 * 0x14);
    iVar12 = iVar10;
  }
  uVar6 = param_4[1];
  uVar7 = param_4[2];
  uVar8 = param_4[3];
  puVar1 = (undefined4 *)(param_1 + iVar12 * 0x14);
  *puVar1 = *param_4;
  puVar1[1] = uVar6;
  puVar1[2] = uVar7;
  puVar1[3] = uVar8;
  *(undefined4 *)(param_1 + 0x10 + iVar12 * 0x14) = param_4[4];
  return;
}



/* FUNCTION 25985 ; VA 0x00bb6620 ; FUN_00bb6620 */

void FUN_00bb6620(undefined4 *param_1,undefined4 *param_2,int param_3,undefined4 param_4)

{
  float fVar1;
  bool bVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 *puStack_c;
  undefined4 *puStack_8;
  
  iVar7 = (int)param_2 - (int)param_1;
  do {
    iVar7 = iVar7 / 0x14;
    if (iVar7 < 0x21) {
LAB_00bb66f0:
      if ((1 < iVar7) && (puVar6 = param_1, param_1 != param_2)) {
        while (puVar8 = puVar6 + 5, puVar8 != param_2) {
          uVar3 = *puVar8;
          uVar4 = puVar6[6];
          uVar5 = puVar6[7];
          iVar7 = puVar6[8];
          fVar1 = (float)puVar6[9];
          if (iVar7 == param_1[3]) {
            bVar2 = fVar1 < (float)param_1[4];
          }
          else {
            bVar2 = iVar7 < (int)param_1[3];
          }
          puVar6 = puVar8;
          if (bVar2) {
            for (; puVar8 != param_1; puVar8 = puVar8 + -5) {
              *puVar8 = puVar8[-5];
              puVar8[1] = puVar8[-4];
              puVar8[2] = puVar8[-3];
              puVar8[3] = puVar8[-2];
              puVar8[4] = puVar8[-1];
            }
            *param_1 = uVar3;
            param_1[1] = uVar4;
            param_1[2] = uVar5;
            param_1[3] = iVar7;
            param_1[4] = fVar1;
          }
          else {
            while( true ) {
              if (iVar7 == puVar8[-2]) {
                bVar2 = fVar1 < (float)puVar8[-1];
              }
              else {
                bVar2 = iVar7 < (int)puVar8[-2];
              }
              if (!bVar2) break;
              *puVar8 = puVar8[-5];
              puVar8[1] = puVar8[-4];
              puVar8[2] = puVar8[-3];
              puVar8[3] = puVar8[-2];
              puVar8[4] = puVar8[-1];
              puVar8 = puVar8 + -5;
            }
            *puVar8 = uVar3;
            puVar8[1] = uVar4;
            puVar8[2] = uVar5;
            puVar8[3] = iVar7;
            puVar8[4] = fVar1;
          }
        }
      }
      return;
    }
    if (param_3 < 1) {
      if (0x20 < iVar7) {
        FUN_00bb5ff0(param_1,param_2,param_4);
        iVar7 = ((int)param_2 - (int)param_1) / 0x14;
        if (iVar7 < 2) {
          return;
        }
        param_2 = param_2 + -5;
        if (iVar7 < 2) goto LAB_00bb67c1;
        do {
          uStack_20 = *param_2;
          uStack_1c = param_2[1];
          uStack_18 = param_2[2];
          uStack_14 = param_2[3];
          uStack_10 = param_2[4];
          uVar3 = param_1[1];
          uVar4 = param_1[2];
          uVar5 = param_1[3];
          *param_2 = *param_1;
          param_2[1] = uVar3;
          param_2[2] = uVar4;
          param_2[3] = uVar5;
          param_2[4] = param_1[4];
          FUN_00bb6520(param_1,0,((int)param_2 - (int)param_1) / 0x14,&uStack_20,param_4);
LAB_00bb67c1:
          param_2 = param_2 + -5;
        } while (1 < ((int)param_2 + (0x14 - (int)param_1)) / 0x14);
        return;
      }
      goto LAB_00bb66f0;
    }
    FUN_00bb61f0(&puStack_c,param_1,param_2,param_4);
    param_3 = (param_3 >> 1) + (param_3 >> 2);
    if (((int)puStack_c - (int)param_1) / 0x14 < ((int)param_2 - (int)puStack_8) / 0x14) {
      FUN_00bb6620(param_1,puStack_c,param_3,param_4);
      param_1 = puStack_8;
    }
    else {
      FUN_00bb6620(puStack_8,param_2,param_3,param_4);
      param_2 = puStack_c;
    }
    iVar7 = (int)param_2 - (int)param_1;
  } while( true );
}



/* FUNCTION 25986 ; VA 0x00bb6860 ; FUN_00bb6860 */

void __thiscall FUN_00bb6860(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  uint uVar2;
  int *piVar3;
  uint uVar4;
  uint uStack_c;
  
  piVar3 = *(int **)(param_1 + 4);
  uStack_c = 0;
  uVar2 = *(uint *)(param_1 + 8) & 0x3fffffff;
  if (piVar3 + *(uint *)(param_1 + 8) < piVar3) {
    uVar2 = 0;
  }
  if (uVar2 != 0) {
    do {
      uVar4 = -(uint)(*piVar3 != 0) & *piVar3 - 8U;
      if (DAT_01d69098 != '\0') {
        FUN_00ce61b0(uVar4);
      }
      FUN_00ce6740(uVar4);
      uVar1 = FUN_00ca1550();
      FUN_00bb69e0(param_2,param_3,uVar1,0);
      FUN_00bb6860(param_2,param_3);
      uStack_c = uStack_c + 1;
      piVar3 = piVar3 + 1;
    } while (uStack_c != uVar2);
  }
  return;
}



/* FUNCTION 25987 ; VA 0x00bb6910 ; FUN_00bb6910 */

void __thiscall FUN_00bb6910(int param_1,undefined4 param_2)

{
  uint uVar1;
  uint uVar2;
  int *piVar3;
  
  piVar3 = *(int **)(param_1 + 4);
  uVar2 = 0;
  uVar1 = *(uint *)(param_1 + 8) & 0x3fffffff;
  if (piVar3 + *(uint *)(param_1 + 8) < piVar3) {
    uVar1 = 0;
  }
  if (uVar1 != 0) {
    do {
      FUN_00ce67c0(-(uint)(*piVar3 != 0) & *piVar3 - 8U);
      FUN_00bb6910(param_2);
      uVar2 = uVar2 + 1;
      piVar3 = piVar3 + 1;
    } while (uVar2 != uVar1);
  }
  return;
}



/* FUNCTION 25988 ; VA 0x00bb6970 ; FUN_00bb6970 */

void __thiscall
FUN_00bb6970(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  uint uVar1;
  uint uVar2;
  int *piVar3;
  
  piVar3 = *(int **)(param_1 + 4);
  uVar2 = 0;
  uVar1 = *(uint *)(param_1 + 8) & 0x3fffffff;
  if (piVar3 + *(uint *)(param_1 + 8) < piVar3) {
    uVar1 = 0;
  }
  if (uVar1 != 0) {
    do {
      FUN_00ce6560(-(uint)(*piVar3 != 0) & *piVar3 - 8U);
      FUN_00bb6970(param_2,param_3,param_4,param_5);
      uVar2 = uVar2 + 1;
      piVar3 = piVar3 + 1;
    } while (uVar2 != uVar1);
  }
  return;
}



/* FUNCTION 25989 ; VA 0x00bb69e0 ; FUN_00bb69e0 */

void FUN_00bb69e0(undefined4 param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  
  if (((param_4 == 0) ||
      (((param_4 == 1 && (*(int *)(param_3 + 0x1b0) != 0)) &&
       (iVar3 = (**(code **)(**(int **)(param_3 + 0x1ac) + 8))(), iVar3 != 10)))) &&
     ((param_2 != 0 && (param_3 != *(int *)(param_2 + 0xd4))))) {
    FUN_00ce73c0(param_3);
  }
  iVar3 = 0;
  if (0 < *(int *)(param_3 + 0x14)) {
    do {
      iVar1 = *(int *)(*(int *)(param_3 + 0x10) + iVar3 * 4);
      uVar4 = -(uint)(iVar1 != 0) & iVar1 - 8U;
      cVar2 = FUN_00ca1a80(uVar4);
      if (cVar2 == '\0') {
        FUN_00bb69e0(param_1,param_2,uVar4,param_4);
      }
      iVar3 = iVar3 + 1;
    } while (iVar3 < *(int *)(param_3 + 0x14));
  }
  return;
}



/* FUNCTION 25990 ; VA 0x00bb6a70 ; FUN_00bb6a70 */

void FUN_00bb6a70(undefined4 param_1,int param_2,int param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  
  if (((param_3 == 0) ||
      (((param_3 == 1 && (*(int *)(param_2 + 0x1b0) != 0)) &&
       (iVar3 = (**(code **)(**(int **)(param_2 + 0x1ac) + 8))(), iVar3 != 10)))) &&
     (iVar3 = 0, 0 < (int)(*(int *)(param_2 + 0x1d4) - *(int *)(param_2 + 0x1d0) & 0xfffffff8U))) {
    do {
      uVar4 = FUN_00c156d0(iVar3);
      FUN_00bbbc10(uVar4);
      iVar3 = iVar3 + 1;
    } while (iVar3 < *(int *)(param_2 + 0x1d4) - *(int *)(param_2 + 0x1d0) >> 3);
  }
  iVar3 = 0;
  if (0 < *(int *)(param_2 + 0x14)) {
    do {
      iVar1 = *(int *)(*(int *)(param_2 + 0x10) + iVar3 * 4);
      uVar5 = -(uint)(iVar1 != 0) & iVar1 - 8U;
      cVar2 = FUN_00ca1a80(uVar5);
      if (cVar2 == '\0') {
        FUN_00bb6a70(param_1,uVar5,param_3);
      }
      iVar3 = iVar3 + 1;
    } while (iVar3 < *(int *)(param_2 + 0x14));
  }
  return;
}



/* FUNCTION 25991 ; VA 0x00bb6b30 ; FUN_00bb6b30 */

void FUN_00bb6b30(undefined4 param_1,int param_2,int param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  
  if (((param_3 == 0) ||
      (((param_3 == 1 && (*(int *)(param_2 + 0x1b0) != 0)) &&
       (iVar3 = (**(code **)(**(int **)(param_2 + 0x1ac) + 8))(), iVar3 != 10)))) &&
     (iVar3 = 0, 0 < (int)(*(int *)(param_2 + 0x1d4) - *(int *)(param_2 + 0x1d0) & 0xfffffff8U))) {
    do {
      uVar4 = FUN_00c156d0(iVar3);
      FUN_00bc0270(uVar4);
      iVar3 = iVar3 + 1;
    } while (iVar3 < *(int *)(param_2 + 0x1d4) - *(int *)(param_2 + 0x1d0) >> 3);
  }
  iVar3 = 0;
  if (0 < *(int *)(param_2 + 0x14)) {
    do {
      iVar1 = *(int *)(*(int *)(param_2 + 0x10) + iVar3 * 4);
      uVar5 = -(uint)(iVar1 != 0) & iVar1 - 8U;
      cVar2 = FUN_00ca1a80(uVar5);
      if (cVar2 == '\0') {
        FUN_00bb6b30(param_1,uVar5,param_3);
      }
      iVar3 = iVar3 + 1;
    } while (iVar3 < *(int *)(param_2 + 0x14));
  }
  return;
}



/* FUNCTION 25992 ; VA 0x00bb6bf0 ; FUN_00bb6bf0 */

undefined4 * __fastcall FUN_00bb6bf0(undefined4 *param_1)

{
  undefined4 uVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  uVar1 = FUN_0089c660();
  *param_1 = uVar1;
  return param_1;
}



/* FUNCTION 25993 ; VA 0x00bb6c20 ; FUN_00bb6c20 */

undefined4 * __thiscall FUN_00bb6c20(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uStack_30;
  undefined8 uStack_2c;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fd99c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = param_2;
  *param_1 = RBX::SpatialFilter::vftable;
  *(undefined2 *)(param_1 + 4) = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 1;
  param_1[8] = 0xffffffff;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  uStack_8 = 0;
  *(undefined *)((int)param_1 + 0x3d) = 0;
  puStack_14 = param_1;
  FUN_016f4053(param_1 + 0x10,8,10,FUN_00bb6bf0,FUN_00bb6d90);
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  uStack_20 = 0;
  uStack_1c = 0xc;
  uStack_2c = 0xc00000000;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uStack_30 = 0;
  uStack_24 = 0xc;
  FUN_006b3040(0,&uStack_30,(int)&param_2 + 3);
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  *(undefined2 *)(param_1 + 0x32) = 0;
  *(undefined *)((int)param_1 + 0xca) = 0;
  param_1[0x33] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25994 ; VA 0x00bb6d90 ; FUN_00bb6d90 */

void __fastcall FUN_00bb6d90(undefined4 *param_1)

{
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00bb7730(&puStack_14,*(undefined4 *)*param_1,(undefined4 *)*param_1);
  FUN_01674ea0(*param_1,0x14);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25995 ; VA 0x00bb6de0 ; FUN_00bb6de0 */

void __fastcall FUN_00bb6de0(undefined4 *param_1)

{
  *param_1 = RBX::IStage::vftable;
  return;
}



/* FUNCTION 25996 ; VA 0x00bb6df0 ; FUN_00bb6df0 */

undefined4 * __thiscall FUN_00bb6df0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::IStage::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  return param_1;
}



/* FUNCTION 25997 ; VA 0x00bb6e20 ; FUN_00bb6e20 */

undefined4 * __thiscall FUN_00bb6e20(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::IStage::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 25998 ; VA 0x00bb6e50 ; FUN_00bb6e50 */

undefined4 * __thiscall FUN_00bb6e50(undefined4 *param_1,byte param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::SpatialFilter::vftable;
  iVar1 = param_1[0x2e];
  uStack_8 = 0;
  if (iVar1 != 0) {
    uVar3 = param_1[0x30] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_00bb6f74;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[0x2e] = 0;
    param_1[0x2f] = 0;
    param_1[0x30] = 0;
  }
  iVar1 = param_1[0x28];
  if (iVar1 != 0) {
    uVar3 = param_1[0x2a] - iVar1 & 0xfffffff0;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_00bb6f74:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[0x28] = 0;
    param_1[0x29] = 0;
    param_1[0x2a] = 0;
  }
  FUN_00617bc0();
  FUN_016f32d1(param_1 + 0x10,8,10,FUN_00bb6d90);
  *param_1 = RBX::IStage::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xd0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25999 ; VA 0x00bb6f80 ; FUN_00bb6f80 */

void __fastcall FUN_00bb6f80(int param_1)

{
  FUN_00ca1550();
  FUN_00a33d60(param_1 + 0x20);
  return;
}


