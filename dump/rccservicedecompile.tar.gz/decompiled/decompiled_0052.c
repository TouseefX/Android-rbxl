/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 13000 ; VA 0x0084c630 ; FUN_0084c630 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __thiscall FUN_0084c630(int *param_1,undefined4 *param_2)

{
  float fVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined8 uVar13;
  int *piVar14;
  char cVar15;
  int iVar16;
  int iVar17;
  undefined4 uVar18;
  undefined4 *puVar19;
  float *pfVar20;
  undefined4 *puVar21;
  int iVar22;
  uint uVar23;
  int *piVar24;
  float10 fVar25;
  float fVar26;
  float fVar27;
  undefined8 uVar28;
  undefined auStack_27c [232];
  int *piStack_194;
  undefined4 uStack_190;
  int *piStack_18c;
  undefined4 uStack_188;
  int iStack_184;
  int *piStack_180;
  int *piStack_17c;
  int iStack_178;
  int iStack_174;
  int iStack_16c;
  int iStack_168;
  int iStack_160;
  int iStack_15c;
  undefined4 uStack_158;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined8 uStack_134;
  float fStack_12c;
  undefined auStack_128 [12];
  undefined auStack_11c [12];
  undefined8 uStack_110;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined8 uStack_100;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  float fStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  float fStack_dc;
  undefined4 uStack_d8;
  undefined8 uStack_d4;
  float fStack_cc;
  float fStack_c0;
  float fStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined8 uStack_a8;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined auStack_98 [4];
  int iStack_94;
  int iStack_90;
  undefined8 uStack_8c;
  int iStack_84;
  undefined8 uStack_80;
  int iStack_78;
  uint uStack_74;
  int *piStack_70;
  uint uStack_6c;
  undefined8 uStack_64;
  int iStack_5c;
  int iStack_58;
  undefined4 *puStack_54;
  undefined4 *puStack_50;
  int iStack_4c;
  int iStack_48;
  undefined4 *puStack_44;
  undefined4 *puStack_40;
  undefined4 *puStack_3c;
  int *piStack_38;
  int *piStack_34;
  int *piStack_30;
  uint uStack_2c;
  uint uStack_28;
  char cStack_21;
  int iStack_20;
  char cStack_19;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b788d;
  pvStack_10 = ExceptionList;
  iStack_5c = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  piStack_38 = param_1;
  if ((*(int *)(iStack_5c + 0x34) < DAT_01eb47e8) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb47e8), DAT_01eb47e8 == -1)) {
    uStack_8 = 0;
    uVar28 = FUN_0152dab0("Render","updateGeometry",0xffffffff);
    DAT_01eb47e4 = (undefined4)((ulonglong)uVar28 >> 0x20);
    DAT_01eb47e0 = (undefined4)uVar28;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb47e8);
  }
  uStack_a0 = DAT_01eb47e0;
  uStack_b0 = DAT_01eb47e0;
  uStack_9c = DAT_01eb47e4;
  uStack_ac = DAT_01eb47e4;
  uStack_a8 = FUN_0152d930(DAT_01eb47e0,DAT_01eb47e4);
  uStack_8 = 1;
  if (DAT_01d622c0 == '\0') {
    FUN_0084dbe0();
  }
  if ((*(char *)(param_1 + 0x35) == '\0') && (param_1[0x34] == 0)) {
    piStack_14 = (int *)param_1[0x29];
    piStack_18 = (int *)param_1[0x2a];
    if (piStack_14 != piStack_18) {
      do {
        iVar17 = *piStack_14;
        iVar2 = *(int *)(iVar17 + 0xc);
        iVar16 = FUN_00cfb1a0();
        param_1 = piStack_38;
        iVar22 = 0;
        if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar16 + 0x1d8) <=
            (uint)*(ushort *)(iVar16 + 0x1da)) {
          iVar22 = iVar17;
        }
        if ((iVar22 != 0) && (*(char *)(iVar22 + 0x191) != '\0')) {
          FUN_008477a0();
          break;
        }
        piStack_14 = piStack_14 + 2;
      } while (piStack_14 != piStack_18);
    }
  }
  if (DAT_01d622c0 != '\0') {
    if (param_1[0x34] != 0) {
      cVar15 = FUN_00685240();
      if (cVar15 != '\0') {
        FUN_00847cf0();
      }
      FUN_00d71a20(*(undefined4 *)(param_1[0x34] + 0x2c));
      FUN_00d75ef0(*(undefined4 *)(param_1[0x34] + 0x2c),*(undefined4 *)(param_1[0x34] + 0x28));
    }
    if ((DAT_01d622c0 != '\0') && (param_1[0x34] != 0)) {
      iVar17 = *(int *)(param_1[0x34] + 0x1c);
      goto LAB_0084c7a7;
    }
  }
  iVar17 = 0;
LAB_0084c7a7:
  iStack_48 = iVar17;
  cVar15 = (**(code **)(*param_1 + 0x30))();
  uVar18 = DAT_019011dc;
  if ((cVar15 != '\0') && (DAT_01d622a8 != '\0')) {
    uVar18 = DAT_01919f9c;
  }
  FUN_00844750(param_1[2],param_1[0x32],iVar17,param_1[0x2a] - param_1[0x29] >> 3,
               *(undefined *)(param_1 + 0x35),uVar18);
  iVar2 = DAT_018c45d0;
  iVar17 = DAT_018c45c4;
  iStack_58 = 0;
  puStack_54 = (undefined4 *)0x0;
  puStack_50 = (undefined4 *)0x0;
  puStack_44 = (undefined4 *)0x0;
  puStack_40 = (undefined4 *)0x0;
  puStack_3c = (undefined4 *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (*(char *)(param_1 + 0x35) == '\0') {
    FUN_007cfd20(0x10);
    FUN_007cfd20(0x10);
  }
  else {
    iStack_84 = 0x7f7fffff;
    uStack_8c = CONCAT44(DAT_018c45c4,DAT_018c45c4);
    uStack_64 = CONCAT44(0xff7fffff,(undefined4)uStack_64);
    iStack_78 = -0x800001;
    iStack_94 = iStack_15c;
    iStack_90 = 0;
    uStack_80 = CONCAT44(DAT_018c45d0,DAT_018c45d0);
    if (piStack_17c == piStack_180) {
      iStack_15c = iStack_15c + 1;
      FUN_00842420(piStack_180,&iStack_94);
    }
    else {
      *piStack_180 = iStack_15c;
      piStack_180[1] = 0;
      piStack_180[2] = iVar17;
      piStack_180[3] = iVar17;
      piStack_180[4] = 0x7f7fffff;
      piStack_180[5] = iVar2;
      piStack_180[6] = iVar2;
      piStack_180[7] = -0x800001;
      piStack_180 = piStack_180 + 8;
      iStack_15c = iStack_15c + 1;
    }
    FUN_007cfd20(1);
    FUN_007cfd20(1);
    piStack_18 = (int *)0xffffffff;
    if (puStack_50 == puStack_54) {
      FUN_0063d9b0(puStack_54,&piStack_18);
    }
    else {
      *puStack_54 = 0xffffffff;
      puStack_54 = puStack_54 + 1;
    }
    piStack_18 = (int *)0x0;
    if (puStack_3c == puStack_40) {
      FUN_0063d9b0(puStack_40,&piStack_18);
    }
    else {
      *puStack_40 = 0;
      puStack_40 = puStack_40 + 1;
    }
  }
  piStack_70 = (int *)0x0;
  if (*(int *)(iStack_5c + 0x34) < DAT_01eb47f8) {
    FUN_016f3809(&DAT_01eb47f8);
    if (DAT_01eb47f8 == -1) {
      uStack_8._0_1_ = 5;
      uVar28 = FUN_0152dab0("Render","FC geo prepare",0xffffffff);
      DAT_01eb47f4 = (undefined4)((ulonglong)uVar28 >> 0x20);
      DAT_01eb47f0 = (undefined4)uVar28;
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      FUN_016f37bf(&DAT_01eb47f8);
    }
  }
  piStack_34 = (int *)DAT_01eb47f0;
  uStack_108 = DAT_01eb47f0;
  piStack_30 = (int *)DAT_01eb47f4;
  uStack_104 = DAT_01eb47f4;
  uStack_100 = FUN_0152d930(DAT_01eb47f0,DAT_01eb47f4);
  param_1[0x38] = param_1[0x37];
  uStack_8._0_1_ = 7;
  FUN_007b3200(param_1[0x3a],param_1[0x3b]);
  param_1[0x3b] = param_1[0x3a];
  iStack_20 = param_1[0x29];
  uStack_8._0_1_ = 6;
  uStack_2c = 0;
  if (param_1[0x2a] - iStack_20 >> 3 != 0) {
    do {
      cStack_21 = '\0';
      iVar17 = *(int *)(iStack_20 + uStack_2c * 8);
      iVar2 = *(int *)(iVar17 + 0xc);
      iVar16 = FUN_00cfb1a0();
      uVar23 = uStack_2c;
      param_1 = piStack_38;
      iVar22 = 0;
      if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar16 + 0x1d8) <=
          (uint)*(ushort *)(iVar16 + 0x1da)) {
        iVar22 = iVar17;
      }
      if ((DAT_01d6c7c4 == '\0') || (iVar22 == 0)) {
LAB_0084ca47:
        uStack_6c = uStack_6c & 0xffffff00;
      }
      else {
        uStack_6c = CONCAT31(uStack_6c._1_3_,1);
        if (*(char *)(iVar22 + 0x191) == '\0') goto LAB_0084ca47;
      }
      uStack_28 = FUN_00760730(*(char *)(piStack_38 + 0x35) == '\0',
                               *(undefined4 *)(iStack_20 + uStack_2c * 8),auStack_27c,&cStack_21,
                               uStack_6c);
      if (*(char *)(param_1 + 0x36) != '\0') {
        uStack_28 = uStack_28 | 0x400;
      }
      iVar17 = FUN_00b084e0();
      if (iVar17 == 0x630) {
        uStack_28 = uStack_28 | 2;
      }
      uStack_74 = uStack_28 >> 1 & 0xffffff01;
      if (DAT_01d61b8c == '\0') {
LAB_0084cad6:
        cStack_19 = '\0';
      }
      else {
        iVar17 = FUN_00b08820();
        if ((iVar17 == 0) || (cStack_19 = '\x01', (uStack_28 & 4) == 0)) goto LAB_0084cad6;
      }
      piStack_14 = (int *)FUN_00d37670(*(undefined4 *)(iStack_20 + uVar23 * 8),0,0);
      piStack_18 = (int *)FUN_00b06f80();
      if ((*(char *)(param_1 + 0x35) == '\0') &&
         ((piStack_18 == (int *)0x0 || (piStack_18 != piStack_70)))) {
        fStack_b4 = 3.4028235e+38;
        uStack_8c = CONCAT44(DAT_018c45c4,DAT_018c45c4);
        iStack_90 = *(int *)(iStack_20 + uVar23 * 8);
        iStack_84 = 0x7f7fffff;
        fStack_c0 = -3.4028235e+38;
        iStack_78 = -0x800001;
        uStack_80 = CONCAT44(DAT_018c45d0,DAT_018c45d0);
        if ((iStack_48 == 0) || (DAT_01d622c0 == '\0')) {
LAB_0084cb9a:
          iStack_94 = iStack_15c;
          iStack_15c = iStack_15c + 1;
        }
        else {
          iStack_94 = FUN_00d71570(iStack_90);
          if (iStack_94 == -1) goto LAB_0084cb9a;
        }
        if (piStack_17c == piStack_180) {
          FUN_00842420(piStack_180,&iStack_94);
        }
        else {
          *piStack_180 = iStack_94;
          piStack_180[1] = iStack_90;
          piStack_180[2] = (int)uStack_8c;
          piStack_180[3] = uStack_8c._4_4_;
          piStack_180[4] = iStack_84;
          piStack_180[5] = (int)uStack_80;
          piStack_180[6] = uStack_80._4_4_;
          piStack_180[7] = iStack_78;
          piStack_180 = piStack_180 + 8;
        }
        piStack_70 = piStack_18;
        piStack_18 = (int *)0xffffffff;
        if (puStack_50 == puStack_54) {
          FUN_0063d9b0(puStack_54,&piStack_18);
        }
        else {
          *puStack_54 = 0xffffffff;
          puStack_54 = puStack_54 + 1;
        }
        piStack_18 = (int *)0x0;
        if (puStack_3c == puStack_40) {
          FUN_0063d9b0(puStack_40,&piStack_18);
        }
        else {
          *puStack_40 = 0;
          puStack_40 = puStack_40 + 1;
        }
      }
      iStack_4c = ((int)piStack_180 - iStack_184 >> 5) + -1;
      if (-1 < (int)piStack_14) {
        puStack_44[iStack_4c] = puStack_44[iStack_4c] + 1;
      }
      if ((char)uStack_74 == '\0') {
        if ((DAT_01d61b8c == '\0') || (piStack_14 = (int *)&DAT_00000005, cStack_19 == '\0')) {
          piStack_14 = (int *)0x0;
        }
      }
      else {
        iVar17 = FUN_00b084e0();
        piStack_14 = (int *)((iVar17 != 0x620) + 8);
      }
      fVar25 = (float10)FUN_00b08910();
      piStack_18 = (int *)(float)fVar25;
      if ((float)piStack_18 < DAT_018ce2f8) {
        FUN_00846330(iStack_4c,*(undefined4 *)(iStack_20 + uVar23 * 8),
                     *(undefined4 *)(*(int *)(iStack_20 + 4 + uVar23 * 8) + 0x24),uVar23,0,uStack_28
                     ,piStack_14,param_1,param_2);
      }
      iVar17 = *(int *)(iStack_20 + uVar23 * 8);
      if ((((*(byte *)(iVar17 + 0xb4) & 1) != 0) &&
          (piStack_18 = *(int **)(iVar17 + 0x2c), piStack_18 != (int *)0x0)) && (cStack_21 == '\0'))
      {
        iVar17 = *piStack_18;
        uStack_28 = uStack_28 & 0x1401 | 2;
        piStack_14 = (int *)0x0;
        if (piStack_18[1] - iVar17 >> 3 != 0) {
          do {
            iVar17 = *(int *)(iVar17 + (int)piStack_14 * 8);
            iVar2 = *(int *)(iVar17 + 0xc);
            iVar16 = FUN_00cffc50();
            iVar22 = 0;
            if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar16 + 0x1d8) <=
                (uint)*(ushort *)(iVar16 + 0x1da)) {
              iVar22 = iVar17;
            }
            uVar23 = uStack_2c;
            param_1 = piStack_38;
            if (iVar22 != 0) {
              fVar25 = (float10)FUN_00d00910();
              uVar23 = uStack_2c;
              param_1 = piStack_38;
              uStack_64 = CONCAT44((float)fVar25,(undefined4)uStack_64);
              if ((float)fVar25 < DAT_018ce2f8) {
                if (((char)uStack_74 != '\0') || (uVar18 = 2, cStack_19 != '\0')) {
                  uVar18 = 9;
                }
                FUN_00846330(iStack_4c,*(undefined4 *)(iStack_20 + uStack_2c * 8),
                             *(undefined4 *)(*(int *)(iStack_20 + 4 + uStack_2c * 8) + 0x24),
                             uStack_2c,iVar22,uStack_28,uVar18,piStack_38,param_2);
              }
            }
            piStack_14 = (int *)((int)piStack_14 + 1);
            iVar17 = *piStack_18;
          } while (piStack_14 < (int *)(piStack_18[1] - iVar17 >> 3));
        }
      }
      iStack_20 = param_1[0x29];
      uStack_2c = uVar23 + 1;
    } while (uStack_2c < (uint)(param_1[0x2a] - iStack_20 >> 3));
  }
  uStack_8._0_1_ = 8;
  FUN_0152dda0(piStack_34,piStack_30,uStack_100);
  uStack_8._0_1_ = 4;
  if (*(int *)(iStack_5c + 0x34) < DAT_01eb4808) {
    FUN_016f3809(&DAT_01eb4808);
    if (DAT_01eb4808 == -1) {
      uStack_8._0_1_ = 9;
      uVar28 = FUN_0152dab0("Render","clear",0xffffffff);
      DAT_01eb4804 = (undefined4)((ulonglong)uVar28 >> 0x20);
      DAT_01eb4800 = (undefined4)uVar28;
      uStack_8._0_1_ = 4;
      FUN_016f37bf(&DAT_01eb4808);
    }
  }
  uStack_64 = CONCAT44(DAT_01eb4800,(undefined4)uStack_64);
  piStack_30 = (int *)DAT_01eb4804;
  uVar28 = FUN_0152d930(DAT_01eb4800,DAT_01eb4804);
  piStack_34 = (int *)((ulonglong)uVar28 >> 0x20);
  uVar23 = 0;
  iVar17 = param_1[0xe];
  if (param_1[0xf] - iVar17 >> 2 != 0) {
    do {
      puVar21 = *(undefined4 **)(iVar17 + uVar23 * 4);
      if (puVar21 != (undefined4 *)0x0) {
        (**(code **)*puVar21)(1);
      }
      uVar23 = uVar23 + 1;
      iVar17 = param_1[0xe];
    } while (uVar23 < (uint)(param_1[0xf] - iVar17 >> 2));
  }
  param_1[0xf] = iVar17;
  uStack_8._0_1_ = 10;
  FUN_0152dda0(uStack_64._4_4_,piStack_30,(int)uVar28,piStack_34);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  iStack_4c = FUN_008487f0(param_1);
  piStack_30 = param_1 + 0x2c;
  FUN_00843570(iStack_15c,piStack_30);
  FUN_00843570(iStack_15c,param_1 + 0x2f);
  piVar24 = param_1 + 0x26;
  piStack_34 = piVar24;
  FUN_008433b0((int)piStack_180 - iStack_184 >> 5,piVar24);
  piVar14 = piStack_34;
  piStack_18 = (int *)*piVar24;
  piStack_14 = (int *)0x0;
  iVar17 = param_1[0x27] - (int)piStack_18 >> 0x1f;
  if ((param_1[0x27] - (int)piStack_18) / 0x2c + iVar17 != iVar17) {
    iVar17 = 0;
    uStack_2c = 0;
    param_2 = puStack_44;
    uStack_64 = CONCAT44(iStack_58 - (int)puStack_44,(undefined4)uStack_64);
    do {
      *(undefined4 *)(iVar17 + (int)piStack_18) = *(undefined4 *)(iStack_184 + 4 + uStack_2c);
      uStack_110 = *(undefined8 *)(iStack_184 + 8 + uStack_2c);
      uStack_108 = *(undefined4 *)(iStack_184 + 0x10 + uStack_2c);
      uStack_100._4_4_ = *(undefined4 *)(iStack_184 + 0x1c + uStack_2c);
      uVar13 = uStack_110;
      uVar28 = *(undefined8 *)(iStack_184 + 0x14 + uStack_2c);
      iVar2 = *piVar14;
      uStack_104 = (undefined4)uVar28;
      uStack_100._0_4_ = (undefined4)((ulonglong)uVar28 >> 0x20);
      uStack_110._4_4_ = (undefined4)((ulonglong)uStack_110 >> 0x20);
      puVar21 = (undefined4 *)(iVar17 + 8 + iVar2);
      *puVar21 = (undefined4)uStack_110;
      puVar21[1] = uStack_110._4_4_;
      puVar21[2] = uStack_108;
      puVar21[3] = uStack_104;
      *(ulonglong *)(iVar17 + 0x18 + iVar2) = CONCAT44(uStack_100._4_4_,(undefined4)uStack_100);
      *(undefined4 *)(*piVar14 + 0x20 + iVar17) = *(undefined4 *)(iStack_184 + uStack_2c);
      uStack_110 = uVar13;
      if (*(int *)(iVar17 + *piVar14) == 0) {
        puVar21 = &uStack_f8;
        uStack_f8 = _DAT_018e3fb0;
        uStack_f4 = _UNK_018e3fb4;
        uStack_f0 = _UNK_018e3fb8;
        fStack_ec = _UNK_018e3fbc;
        uStack_e8 = _DAT_018e3fb0;
        uStack_e4 = _UNK_018e3fb4;
        uStack_e0 = _UNK_018e3fb8;
        fStack_dc = _UNK_018e3fbc;
        uStack_d8 = _DAT_018e3fb0;
        uStack_d4 = CONCAT44(_UNK_018e3fb8,_UNK_018e3fb4);
        fStack_cc = _UNK_018e3fbc;
      }
      else {
        puVar19 = (undefined4 *)FUN_00b077e0();
        puVar21 = &uStack_158;
        uStack_158 = *puVar19;
        uStack_154 = puVar19[1];
        uStack_150 = puVar19[2];
        uStack_14c = puVar19[3];
        uStack_148 = puVar19[4];
        uStack_144 = puVar19[5];
        uStack_140 = puVar19[6];
        uStack_13c = puVar19[7];
        uStack_138 = puVar19[8];
        uStack_134 = *(undefined8 *)(puVar19 + 9);
        fStack_12c = (float)puVar19[0xb];
      }
      uVar18 = puVar21[1];
      uVar3 = puVar21[2];
      uVar4 = puVar21[3];
      puVar19 = (undefined4 *)(*(int *)(iVar17 + 0x20 + *piVar14) * 0x30 + *piStack_30);
      *puVar19 = *puVar21;
      puVar19[1] = uVar18;
      puVar19[2] = uVar3;
      puVar19[3] = uVar4;
      uVar18 = puVar21[5];
      uVar3 = puVar21[6];
      uVar4 = puVar21[7];
      puVar19[4] = puVar21[4];
      puVar19[5] = uVar18;
      puVar19[6] = uVar3;
      puVar19[7] = uVar4;
      uVar18 = puVar21[9];
      uVar3 = puVar21[10];
      uVar4 = puVar21[0xb];
      puVar19[8] = puVar21[8];
      puVar19[9] = uVar18;
      puVar19[10] = uVar3;
      puVar19[0xb] = uVar4;
      iVar2 = *(int *)(iVar17 + *piVar14);
      if (iVar2 == 0) {
        uVar18 = 0;
      }
      else {
        uVar18 = *(undefined4 *)(iVar2 + 0xa8);
      }
      *(undefined4 *)(iVar17 + 4 + *piVar14) = uVar18;
      piStack_14 = (int *)((int)piStack_14 + 1);
      uStack_2c = uStack_2c + 0x20;
      *(undefined4 *)(iVar17 + 0x24 + *piVar14) = *(undefined4 *)(uStack_64._4_4_ + (int)param_2);
      *(undefined4 *)(iVar17 + 0x28 + *piVar14) = *param_2;
      iVar17 = iVar17 + 0x2c;
      piStack_18 = (int *)*piVar14;
      param_1 = piStack_38;
      param_2 = param_2 + 1;
    } while (piStack_14 < (uint)((piVar14[1] - (int)piStack_18) / 0x2c));
  }
  if (param_1[0x34] != 0) {
    iVar17 = param_1[0x34] + 0xc;
    if (DAT_01d622c0 == '\0') {
      FUN_00843570((iStack_168 - iStack_16c) / 0x30,iVar17);
      iVar17 = param_1[0x34];
      param_2 = (undefined4 *)0x0;
      iVar22 = *(int *)(iVar17 + 0x10) - *(int *)(iVar17 + 0xc);
      iVar2 = iVar22 >> 0x1f;
      if (iVar22 / 0x30 + iVar2 != iVar2) {
        iVar17 = 0;
        do {
          iVar2 = iVar17 + 0x30;
          param_2 = (undefined4 *)((int)param_2 + 1);
          puVar21 = (undefined4 *)(iVar17 + iStack_16c);
          uVar18 = puVar21[1];
          uVar3 = puVar21[2];
          uVar4 = puVar21[3];
          puVar19 = (undefined4 *)(iVar17 + 0x10 + iStack_16c);
          uVar5 = *puVar19;
          uVar6 = puVar19[1];
          uVar7 = puVar19[2];
          uVar8 = puVar19[3];
          puVar19 = (undefined4 *)(iVar17 + 0x20 + iStack_16c);
          uVar9 = *puVar19;
          uVar10 = puVar19[1];
          uVar11 = puVar19[2];
          uVar12 = puVar19[3];
          iVar17 = *(int *)(param_1[0x34] + 0xc);
          puVar19 = (undefined4 *)(iVar17 + -0x30 + iVar2);
          *puVar19 = *puVar21;
          puVar19[1] = uVar18;
          puVar19[2] = uVar3;
          puVar19[3] = uVar4;
          puVar21 = (undefined4 *)(iVar17 + -0x20 + iVar2);
          *puVar21 = uVar5;
          puVar21[1] = uVar6;
          puVar21[2] = uVar7;
          puVar21[3] = uVar8;
          puVar21 = (undefined4 *)(iVar17 + -0x10 + iVar2);
          *puVar21 = uVar9;
          puVar21[1] = uVar10;
          puVar21[2] = uVar11;
          puVar21[3] = uVar12;
          iVar17 = iVar2;
        } while (param_2 < (uint)((*(int *)(param_1[0x34] + 0x10) - *(int *)(param_1[0x34] + 0xc)) /
                                 0x30));
        iVar17 = param_1[0x34];
      }
      FUN_006b25d0((iStack_174 - iStack_178) / 0x14,iVar17);
      piVar24 = (int *)param_1[0x34];
      piStack_14 = (int *)0x0;
      iVar17 = piVar24[1] - *piVar24 >> 0x1f;
      if ((piVar24[1] - *piVar24) / 0x14 + iVar17 != iVar17) {
        iVar17 = 0;
        do {
          puVar21 = (undefined4 *)(*(int *)param_1[0x34] + iVar17);
          *puVar21 = *(undefined4 *)(iVar17 + 4 + iStack_178);
          puVar21[1] = *(undefined4 *)(iVar17 + 8 + iStack_178);
          puVar21[4] = *(undefined4 *)(iVar17 + 0x10 + iStack_178);
          puVar21[2] = *(undefined4 *)(iVar17 + 0xc + iStack_178);
          *puVar21 = *(undefined4 *)(iVar17 + 4 + iStack_178);
          iVar2 = *(int *)(iVar17 + iStack_178);
          puVar21[3] = iVar2;
          FUN_0084a190(puVar21,iVar2 * 0x30 + param_1[0x2c]);
          piVar24 = (int *)param_1[0x34];
          iVar17 = iVar17 + 0x14;
          piStack_14 = (int *)((int)piStack_14 + 1);
        } while (piStack_14 < (uint)((piVar24[1] - *piVar24) / 0x14));
      }
    }
    else {
      uVar18 = FUN_00d71a00();
      FUN_00843570(uVar18,iVar17);
      iVar17 = FUN_00926d50();
      piVar24 = (int *)param_1[0x34];
      piStack_34 = (int *)(iVar17 * 0x30 + *(int *)piVar24[10]);
      piStack_14 = (int *)0x0;
      iVar17 = piVar24[4] - piVar24[3] >> 0x1f;
      if ((piVar24[4] - piVar24[3]) / 0x30 + iVar17 != iVar17) {
        param_2 = (undefined4 *)0x0;
        do {
          iVar17 = *(int *)piVar24[10] + (int)param_2;
          pfVar20 = (float *)FUN_0071fcc0(auStack_128);
          fVar26 = *(float *)(iVar17 + 0x28);
          fVar27 = *(float *)(iVar17 + 0x24);
          fVar1 = *(float *)(iVar17 + 0x2c);
          fStack_c0 = pfVar20[6] * fVar27 + pfVar20[7] * fVar26 + pfVar20[8] * fVar1 + pfVar20[0xb];
          piStack_30 = (int *)(pfVar20[3] * fVar27 + pfVar20[4] * fVar26 + pfVar20[5] * fVar1 +
                              pfVar20[10]);
          uStack_64 = (ulonglong)
                      (uint)(pfVar20[1] * fVar26 + fVar27 * *pfVar20 + pfVar20[2] * fVar1 +
                            pfVar20[9]);
          puVar21 = (undefined4 *)FUN_01160c20(auStack_98,iVar17);
          uStack_158 = *puVar21;
          uStack_154 = puVar21[1];
          uStack_150 = puVar21[2];
          uStack_14c = puVar21[3];
          uStack_148 = puVar21[4];
          uStack_144 = puVar21[5];
          uStack_140 = puVar21[6];
          uStack_13c = puVar21[7];
          uStack_138 = puVar21[8];
          uStack_134 = CONCAT44(piStack_30,(int)uStack_64);
          uStack_f8 = _DAT_018e3fb0;
          uStack_f4 = _UNK_018e3fb4;
          uStack_f0 = _UNK_018e3fb8;
          fStack_ec = _UNK_018e3fbc;
          fStack_12c = fStack_c0;
          uStack_e8 = _DAT_018e3fb0;
          uStack_e4 = _UNK_018e3fb4;
          uStack_e0 = _UNK_018e3fb8;
          fStack_dc = _UNK_018e3fbc;
          uStack_d8 = _DAT_018e3fb0;
          uStack_d4 = CONCAT44(_UNK_018e3fb8,_UNK_018e3fb4);
          fStack_cc = _UNK_018e3fbc;
          puVar21 = (undefined4 *)FUN_011630b0(auStack_98);
          uStack_f8 = *puVar21;
          uStack_f4 = puVar21[1];
          uStack_f0 = puVar21[2];
          fStack_ec = (float)puVar21[3];
          uStack_e8 = puVar21[4];
          uStack_e4 = puVar21[5];
          uStack_e0 = puVar21[6];
          fStack_dc = (float)puVar21[7];
          uStack_d8 = puVar21[8];
          pfVar20 = (float *)FUN_01160de0(auStack_11c);
          piStack_14 = (int *)((int)piStack_14 + 1);
          fVar27 = pfVar20[1] * uStack_134._4_4_ + (float)uStack_134 * *pfVar20 +
                   pfVar20[2] * fStack_12c;
          fVar26 = pfVar20[3] * (float)uStack_134 + pfVar20[4] * uStack_134._4_4_ +
                   pfVar20[5] * fStack_12c;
          uStack_d4 = CONCAT44(fVar26,fVar27);
          fStack_cc = pfVar20[6] * (float)uStack_134 + pfVar20[7] * uStack_134._4_4_ +
                      pfVar20[8] * fStack_12c;
          iVar17 = *(int *)(param_1[0x34] + 0xc);
          puVar21 = (undefined4 *)(iVar17 + (int)param_2);
          *puVar21 = uStack_f8;
          puVar21[1] = uStack_f4;
          puVar21[2] = uStack_f0;
          puVar21[3] = fStack_ec;
          puVar21 = (undefined4 *)(iVar17 + 0x10 + (int)param_2);
          *puVar21 = uStack_e8;
          puVar21[1] = uStack_e4;
          puVar21[2] = uStack_e0;
          puVar21[3] = fStack_dc;
          puVar21 = (undefined4 *)(iVar17 + 0x20 + (int)param_2);
          *puVar21 = uStack_d8;
          puVar21[1] = fVar27;
          puVar21[2] = fVar26;
          puVar21[3] = fStack_cc;
          iVar17 = **(int **)(param_1[0x34] + 0x28);
          puVar21 = (undefined4 *)(iVar17 + (int)param_2);
          uVar18 = puVar21[1];
          uVar3 = puVar21[2];
          uVar4 = puVar21[3];
          puVar19 = (undefined4 *)(iVar17 + 0x10 + (int)param_2);
          uVar5 = *puVar19;
          uVar6 = puVar19[1];
          uVar7 = puVar19[2];
          uVar8 = puVar19[3];
          puVar19 = (undefined4 *)(iVar17 + 0x20 + (int)param_2);
          uVar9 = *puVar19;
          uVar10 = puVar19[1];
          uVar11 = puVar19[2];
          uVar12 = puVar19[3];
          iVar17 = param_1[0x2c];
          puVar19 = (undefined4 *)(iVar17 + (int)param_2);
          *puVar19 = *puVar21;
          puVar19[1] = uVar18;
          puVar19[2] = uVar3;
          puVar19[3] = uVar4;
          puVar21 = (undefined4 *)(iVar17 + 0x10 + (int)param_2);
          *puVar21 = uVar5;
          puVar21[1] = uVar6;
          puVar21[2] = uVar7;
          puVar21[3] = uVar8;
          puVar21 = (undefined4 *)(iVar17 + 0x20 + (int)param_2);
          *puVar21 = uVar9;
          puVar21[1] = uVar10;
          puVar21[2] = uVar11;
          puVar21[3] = uVar12;
          piVar24 = (int *)param_1[0x34];
          param_2 = (undefined4 *)((int)param_2 + 0x30);
          fStack_b4 = fStack_cc;
        } while (piStack_14 < (uint)((piVar24[4] - piVar24[3]) / 0x30));
      }
    }
    piVar24[6] = iStack_160;
  }
  iVar17 = iStack_5c;
  if (*(int *)(iStack_5c + 0x34) < DAT_01eb4818) {
    FUN_016f3809(&DAT_01eb4818);
    if (DAT_01eb4818 == -1) {
      uStack_8._0_1_ = 0xb;
      uVar28 = FUN_0152da50("Render");
      DAT_01eb4814 = (undefined4)((ulonglong)uVar28 >> 0x20);
      DAT_01eb4810 = (undefined4)uVar28;
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      FUN_016f37bf(&DAT_01eb4818);
    }
  }
  FUN_0152d760(DAT_01eb4810,DAT_01eb4814,"%d parts, %d entities",param_1[0x2a] - param_1[0x29] >> 3,
               param_1[0xf] - param_1[0xe] >> 2);
  if (*(int *)(iVar17 + 0x34) < DAT_01eb4828) {
    FUN_016f3809(&DAT_01eb4828);
    if (DAT_01eb4828 == -1) {
      uStack_8._0_1_ = 0xc;
      uVar28 = FUN_0152da50("Render");
      DAT_01eb4824 = (undefined4)((ulonglong)uVar28 >> 0x20);
      DAT_01eb4820 = (undefined4)uVar28;
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      FUN_016f37bf(&DAT_01eb4828);
    }
  }
  iVar17 = iStack_4c;
  FUN_0152d760(DAT_01eb4820,DAT_01eb4824,"%d vertices (%d KB)",iStack_4c,
               (uint)(iStack_4c * 0x2c) >> 10);
  if (puStack_44 != (undefined4 *)0x0) {
    FUN_0057d270(puStack_44,(int)puStack_3c - (int)puStack_44 >> 2);
  }
  FUN_0056d320();
  uStack_8._0_1_ = 0xd;
  FUN_00764680();
  FUN_007c27b0();
  FUN_00617bc0();
  FUN_007a4f50();
  piVar24 = piStack_18c;
  uStack_8._0_1_ = 0xe;
  FUN_00845fb0(piStack_18c[1]);
  piStack_18c[1] = (int)piVar24;
  *piStack_18c = (int)piVar24;
  piStack_18c[2] = (int)piVar24;
  uStack_188 = 0;
  FUN_01674ea0(piStack_18c,0x38);
  piVar24 = piStack_194;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  FUN_00845fb0(piStack_194[1]);
  piStack_194[1] = (int)piVar24;
  *piStack_194 = (int)piVar24;
  piStack_194[2] = (int)piVar24;
  uStack_190 = 0;
  FUN_0054db70(piStack_194,0x38);
  FUN_00777180();
  uStack_8 = 0x10;
  FUN_0152dda0(uStack_a0,uStack_9c,uStack_a8);
  ExceptionList = pvStack_10;
  return iVar17;
}



/* FUNCTION 13001 ; VA 0x0084d8b0 ; FUN_0084d8b0 */

void __thiscall
FUN_0084d8b0(int *param_1,int param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6)

{
  undefined4 *puVar1;
  bool bVar2;
  int iVar3;
  float10 fVar4;
  float fVar5;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  float fStack_1c;
  float fStack_18;
  int iStack_14;
  int *piStack_10;
  undefined4 uStack_c;
  float fStack_8;
  
  if (((param_5 == 5) || (param_5 == 4)) || (bVar2 = false, param_5 == 2)) {
    bVar2 = true;
  }
  uStack_c = FUN_0078e450(param_6);
  piStack_10 = (int *)FUN_0078e270(param_4,param_5,uStack_c);
  if (piStack_10 != (int *)0x0) {
    iVar3 = param_1[2];
    fVar5 = 0.0;
    fStack_8 = 0.0;
    if (((iVar3 == 9) || (iVar3 == 10)) || ((iVar3 == 8 || (iVar3 == 5)))) {
      fVar4 = (float10)(**(code **)(*param_1 + 0xc))(param_3);
      fVar5 = (float)fVar4;
    }
    if (DAT_01d60f98 != '\0') {
      fVar4 = (float10)(**(code **)(*param_1 + 0x10))();
      fStack_8 = (float)fVar4;
    }
    iVar3 = param_1[2];
    if (iVar3 == 5) {
      param_3 = FUN_008418d0(fVar5);
      iVar3 = param_1[2];
    }
    else {
      param_3 = 0;
    }
    if (((iVar3 == 8) && (param_5 == 0)) && (*piStack_10 != 0)) {
      iVar3 = FUN_0078e270(param_4,1,uStack_c);
      if (iVar3 != 0) {
        piStack_20 = param_1 + 5;
        fStack_18 = fStack_8;
        iStack_14 = param_5;
        piStack_28 = param_1;
        piStack_24 = (int *)iVar3;
        fStack_1c = fVar5;
        FUN_007b4d60(&piStack_28);
      }
    }
    if (((*(byte *)(param_1[0x11] + 0x24) & 1) != 0) && (param_5 == 0)) {
      piStack_24 = (int *)FUN_0078e270(param_4,6,uStack_c);
      if (piStack_24 != (int *)0x0) {
        fStack_1c = fVar5 + DAT_018fd178;
        piStack_20 = param_1 + 5;
        fStack_18 = fStack_8;
        iStack_14 = param_5;
        piStack_28 = param_1;
        FUN_007b4d60(&piStack_28);
      }
    }
    piStack_24 = piStack_10;
    piStack_20 = param_1 + 0xb;
    if (!bVar2) {
      piStack_20 = param_1 + 5;
    }
    fStack_18 = fStack_8;
    iStack_14 = param_3;
    if (piStack_20[5] != 0) {
      iVar3 = param_2 + param_1[2] * 0xc;
      puVar1 = *(undefined4 **)(iVar3 + 4);
      if (*(undefined4 **)(iVar3 + 8) != puVar1) {
        *puVar1 = param_1;
        puVar1[1] = piStack_10;
        puVar1[2] = piStack_20;
        puVar1[3] = fVar5;
        *(ulonglong *)(puVar1 + 4) = CONCAT44(param_3,fStack_8);
        *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 0x18;
        *(uint *)(param_2 + 0xb4) = *(uint *)(param_2 + 0xb4) | param_1[4];
        return;
      }
      piStack_28 = param_1;
      fStack_1c = fVar5;
      FUN_006c6730(puVar1,&piStack_28);
    }
    *(uint *)(param_2 + 0xb4) = *(uint *)(param_2 + 0xb4) | param_1[4];
  }
  return;
}



/* FUNCTION 13002 ; VA 0x0084dac0 ; FUN_0084dac0 */

void __thiscall FUN_0084dac0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  float fVar1;
  int *piVar2;
  char cVar3;
  sbyte sVar4;
  int iVar5;
  undefined4 uVar6;
  sbyte sVar7;
  uint uVar8;
  float10 fVar9;
  
  if ((*(char *)(param_1 + 0xd8) == '\0') && (cVar3 = FUN_00841130(), cVar3 != '\0')) {
    return;
  }
  cVar3 = FUN_01156450();
  if ((cVar3 == '\0') || (cVar3 = FUN_00795ec0(), cVar3 == '\0')) {
    sVar7 = 1;
  }
  else {
    sVar7 = 0;
  }
  fVar1 = *(float *)(param_1 + 0x14);
  fVar9 = (float10)FUN_01156fe0(*(undefined4 *)(*(int *)(param_1 + 8) + 0x5c4));
  sVar4 = 2;
  if (fVar1 < (float)fVar9) {
    sVar4 = sVar7;
  }
  if (*(char *)(param_1 + 0xd8) != '\0') {
    sVar4 = 1;
  }
  uVar6 = *(undefined4 *)(*(int *)(param_1 + 8) + 0x5c4);
  cVar3 = FUN_0078bd20();
  if ((cVar3 != '\0') && (*(char *)(param_1 + 0xd8) != '\0')) {
    uVar6 = 1;
  }
  uVar8 = 0;
  iVar5 = *(int *)(param_1 + 0x38);
  if (*(int *)(param_1 + 0x3c) - iVar5 >> 2 != 0) {
    do {
      piVar2 = *(int **)(iVar5 + uVar8 * 4);
      if ((*(byte *)(piVar2 + 3) & (byte)(1 << sVar4)) != 0) {
        (**(code **)(*piVar2 + 8))(param_2,param_3,sVar4,param_4,uVar6);
      }
      uVar8 = uVar8 + 1;
      iVar5 = *(int *)(param_1 + 0x38);
    } while (uVar8 < (uint)(*(int *)(param_1 + 0x3c) - iVar5 >> 2));
  }
  if (*(char *)(*(int *)(*(int *)(param_1 + 8) + 0x510) + 0x20) != '\0') {
    FUN_008416d0(*(int *)(param_1 + 8),param_1 + 0x18);
  }
  return;
}



/* FUNCTION 13003 ; VA 0x0084dbe0 ; FUN_0084dbe0 */

void __fastcall FUN_0084dbe0(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  uVar5 = 0;
  iVar3 = *(int *)(param_1 + 0xa4);
  if (*(int *)(param_1 + 0xa8) - iVar3 >> 3 != 0) {
    do {
      iVar3 = *(int *)(iVar3 + uVar5 * 8);
      iVar1 = *(int *)(iVar3 + 0xc);
      iVar2 = FUN_00cfb1a0();
      iVar4 = 0;
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
          (uint)*(ushort *)(iVar2 + 0x1da)) {
        iVar4 = iVar3;
      }
      if (((iVar4 != 0) && (*(int *)(iVar3 + 0xac) == 0)) && (*(char *)(iVar4 + 0x191) != '\0')) {
        FUN_007c8d60(iVar3);
      }
      uVar5 = uVar5 + 1;
      iVar3 = *(int *)(param_1 + 0xa4);
    } while (uVar5 < (uint)(*(int *)(param_1 + 0xa8) - iVar3 >> 3));
  }
  FUN_007cbfc0(-(uint)(param_1 != 0) & param_1 + 0x74U);
  return;
}



/* FUNCTION 13004 ; VA 0x0084dc90 ; FUN_0084dc90 */

void __thiscall FUN_0084dc90(int param_1,float *param_2,float *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 *puVar13;
  undefined4 *puVar14;
  float fVar15;
  int iVar16;
  int *piVar17;
  float fVar18;
  float fVar19;
  undefined auStack_6c [56];
  float fStack_34;
  float fStack_28;
  float fStack_1c;
  float fStack_10;
  int *piStack_c;
  int iStack_8;
  
  piStack_c = (int *)(*(int **)(param_1 + 0xd0))[1];
  piVar17 = (int *)**(int **)(param_1 + 0xd0);
  iStack_8 = param_1;
  if (piVar17 != piStack_c) {
    do {
      if ((((*(char *)(iStack_8 + 0xd5) == '\0') &&
           (iVar16 = *(int *)(*(int *)(*(int *)(iStack_8 + 0xa4) + piVar17[1] * 8) + 0xac),
           iVar16 != 0)) && (*(char *)(iVar16 + 0x60) != '\0')) &&
         (piVar17[4] != *(int *)(iStack_8 + 0x94))) {
        iVar16 = piVar17[2] * 0x30 + *(int *)(iVar16 + 0x18);
        puVar13 = (undefined4 *)
                  FUN_0071f260(auStack_6c,
                               piVar17[4] * 0x30 + *(int *)(*(int *)(iStack_8 + 0xd0) + 0xc));
        uVar2 = puVar13[1];
        uVar3 = puVar13[2];
        uVar4 = puVar13[3];
        uVar5 = puVar13[4];
        uVar6 = puVar13[5];
        uVar7 = puVar13[6];
        uVar8 = puVar13[7];
        uVar9 = puVar13[8];
        uVar10 = puVar13[9];
        uVar11 = puVar13[10];
        uVar12 = puVar13[0xb];
        puVar14 = (undefined4 *)(piVar17[3] * 0x30 + *(int *)(iStack_8 + 0xb0));
        *puVar14 = *puVar13;
        puVar14[1] = uVar2;
        puVar14[2] = uVar3;
        puVar14[3] = uVar4;
        puVar14[4] = uVar5;
        puVar14[5] = uVar6;
        puVar14[6] = uVar7;
        puVar14[7] = uVar8;
        puVar14[8] = uVar9;
        puVar14[9] = uVar10;
        puVar14[10] = uVar11;
        puVar14[0xb] = uVar12;
        fStack_10 = param_3[2];
        if (*(float *)(iVar16 + 0x2c) <= param_3[2]) {
          fStack_10 = *(float *)(iVar16 + 0x2c);
        }
        fVar15 = param_3[1];
        if (*(float *)(iVar16 + 0x28) <= param_3[1]) {
          fVar15 = *(float *)(iVar16 + 0x28);
        }
        fVar18 = *param_3;
        if (*(float *)(iVar16 + 0x24) <= *param_3) {
          fVar18 = *(float *)(iVar16 + 0x24);
        }
        *(ulonglong *)param_3 = CONCAT44(fVar15,fVar18);
        param_3[2] = fStack_10;
        fVar15 = param_3[5];
        if (param_3[5] <= *(float *)(iVar16 + 0x2c)) {
          fVar15 = *(float *)(iVar16 + 0x2c);
        }
        fVar18 = param_3[4];
        if (param_3[4] <= *(float *)(iVar16 + 0x28)) {
          fVar18 = *(float *)(iVar16 + 0x28);
        }
        fVar19 = param_3[3];
        fStack_1c = fVar15;
        if (param_3[3] <= *(float *)(iVar16 + 0x24)) {
          fVar19 = *(float *)(iVar16 + 0x24);
        }
      }
      else {
        iVar16 = *(int *)(iStack_8 + 0xb0);
        iVar1 = *(int *)(*piVar17 * 0x2c + 0x20 + *(int *)(iStack_8 + 0x98));
        puVar13 = (undefined4 *)(iVar16 + iVar1 * 0x30);
        uVar2 = puVar13[1];
        uVar3 = puVar13[2];
        uVar4 = puVar13[3];
        puVar14 = (undefined4 *)(iVar16 + 0x10 + iVar1 * 0x30);
        uVar5 = *puVar14;
        uVar6 = puVar14[1];
        uVar7 = puVar14[2];
        uVar8 = puVar14[3];
        puVar14 = (undefined4 *)(iVar16 + 0x20 + iVar1 * 0x30);
        uVar9 = *puVar14;
        uVar10 = puVar14[1];
        uVar11 = puVar14[2];
        uVar12 = puVar14[3];
        iVar1 = piVar17[3];
        puVar14 = (undefined4 *)(iVar16 + iVar1 * 0x30);
        *puVar14 = *puVar13;
        puVar14[1] = uVar2;
        puVar14[2] = uVar3;
        puVar14[3] = uVar4;
        puVar13 = (undefined4 *)(iVar16 + 0x10 + iVar1 * 0x30);
        *puVar13 = uVar5;
        puVar13[1] = uVar6;
        puVar13[2] = uVar7;
        puVar13[3] = uVar8;
        puVar13 = (undefined4 *)(iVar16 + 0x20 + iVar1 * 0x30);
        *puVar13 = uVar9;
        puVar13[1] = uVar10;
        puVar13[2] = uVar11;
        puVar13[3] = uVar12;
        fStack_28 = param_3[2];
        if (param_2[2] <= param_3[2]) {
          fStack_28 = param_2[2];
        }
        fVar15 = param_3[1];
        if (param_2[1] <= param_3[1]) {
          fVar15 = param_2[1];
        }
        fVar18 = *param_3;
        if (*param_2 <= *param_3) {
          fVar18 = *param_2;
        }
        *(ulonglong *)param_3 = CONCAT44(fVar15,fVar18);
        param_3[2] = fStack_28;
        fVar15 = param_3[5];
        if (param_3[5] <= param_2[5]) {
          fVar15 = param_2[5];
        }
        fVar18 = param_3[4];
        if (param_3[4] <= param_2[4]) {
          fVar18 = param_2[4];
        }
        fVar19 = param_3[3];
        fStack_34 = fVar15;
        if (param_3[3] <= param_2[3]) {
          fVar19 = param_2[3];
        }
      }
      piVar17 = piVar17 + 5;
      *(ulonglong *)(param_3 + 3) = CONCAT44(fVar18,fVar19);
      param_3[5] = fVar15;
    } while (piVar17 != piStack_c);
  }
  return;
}



/* FUNCTION 13005 ; VA 0x0084ded0 ; FUN_0084ded0 */

undefined4 * __thiscall
FUN_0084ded0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined param_5,undefined param_6)

{
  param_1[1] = param_2;
  param_1[2] = param_3;
  *param_1 = RBX::Graphics::SuperCluster::vftable;
  param_1[3] = *param_4;
  param_1[4] = param_4[1];
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  *(undefined *)(param_1 + 9) = param_5;
  *(undefined *)((int)param_1 + 0x25) = param_6;
  param_1[8] = 0;
  return param_1;
}



/* FUNCTION 13006 ; VA 0x0084df30 ; FUN_0084df30 */

undefined4 * __thiscall FUN_0084df30(undefined4 *param_1,byte param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = 0;
  *param_1 = RBX::Graphics::SuperCluster::vftable;
  iVar3 = (int)(param_1[6] - param_1[5]) >> 2;
  if (0 < iVar3) {
    do {
      puVar1 = *(undefined4 **)(param_1[5] + iVar4 * 4);
      if (puVar1 != (undefined4 *)0x0) {
        (**(code **)*puVar1)(1);
      }
      iVar4 = iVar4 + 1;
    } while (iVar4 < iVar3);
  }
  param_1[6] = param_1[5];
  param_1[8] = 0;
  iVar3 = param_1[5];
  if (iVar3 != 0) {
    uVar2 = param_1[7] - iVar3 & 0xfffffffc;
    iVar4 = iVar3;
    if (0xfff < uVar2) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar2);
    param_1[5] = 0;
    param_1[6] = 0;
    param_1[7] = 0;
  }
  *param_1 = RBX::Graphics::ISuperCluster::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 13007 ; VA 0x0084dff0 ; FUN_0084dff0 */

void __thiscall FUN_0084dff0(int param_1,undefined4 param_2,char param_3)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  undefined4 uStack_c;
  int iStack_8;
  
  iStack_8 = param_1;
  if ((*(int *)(param_1 + 0x20) == 0) ||
     (uVar3 = (**(code **)(*(int *)(*(int *)(param_1 + 0x20) + 0x74) + 0x58))(),
     DAT_01d622e0 <= uVar3)) {
    iVar2 = iStack_8;
    iVar5 = 0;
    piVar6 = (int *)(iStack_8 + 0x14);
    iVar4 = *(int *)(iStack_8 + 0x18) - *(int *)(iStack_8 + 0x14) >> 2;
    if (0 < iVar4) {
      do {
        uVar3 = (**(code **)(*(int *)(*(int *)(*piVar6 + iVar5 * 4) + 0x74) + 0x58))();
        if (uVar3 < DAT_01d622e0) {
          piVar6 = *(int **)(*piVar6 + iVar5 * 4);
          goto LAB_0084e098;
        }
        iVar5 = iVar5 + 1;
      } while (iVar5 < iVar4);
    }
    uStack_c = FUN_008486e0(*(undefined4 *)(iStack_8 + 4),0,iStack_8,*(undefined *)(iStack_8 + 0x24)
                            ,*(undefined *)(iStack_8 + 0x25));
    puVar1 = *(undefined4 **)(iVar2 + 0x18);
    if (*(undefined4 **)(iVar2 + 0x1c) == puVar1) {
      FUN_006030d0(puVar1,&uStack_c);
    }
    else {
      *puVar1 = uStack_c;
      *(int *)(iVar2 + 0x18) = *(int *)(iVar2 + 0x18) + 4;
    }
    piVar6 = *(int **)(*(int *)(iStack_8 + 0x18) + -4);
LAB_0084e098:
    *(int **)(iStack_8 + 0x20) = piVar6;
  }
  else {
    piVar6 = *(int **)(iStack_8 + 0x20);
  }
  (**(code **)(*piVar6 + 0x14))(param_2);
  if (param_3 == '\0') {
    (**(code **)(piVar6[0x1d] + 8))();
    return;
  }
  (**(code **)(*piVar6 + 0x18))();
  return;
}



/* FUNCTION 13008 ; VA 0x0084e0d0 ; FUN_0084e0d0 */

void __fastcall FUN_0084e0d0(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = 0;
  iVar2 = *(int *)(param_1 + 0x18) - *(int *)(param_1 + 0x14) >> 2;
  if (0 < iVar2) {
    do {
      (**(code **)(**(int **)(*(int *)(param_1 + 0x14) + iVar1 * 4) + 0xc))();
      iVar1 = iVar1 + 1;
    } while (iVar1 < iVar2);
  }
  return;
}



/* FUNCTION 13009 ; VA 0x0084e100 ; FUN_0084e100 */

void FUN_0084e100(int *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b78a8;
  pvStack_10 = ExceptionList;
  iStack_28 = 0;
  iStack_24 = 0;
  iStack_20 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = (**(code **)(param_1[0x1d] + 0x58))();
  if ((uVar2 != 0) && (uVar2 <= DAT_01d622e0 >> 1)) {
    iVar5 = 0;
    uStack_1c = *(undefined4 *)(piStack_14[1] + 0x4e4);
    iStack_18 = piStack_14[6] - piStack_14[5] >> 2;
    uVar6 = uVar2;
    piVar4 = piStack_14;
    while (0 < (int)uVar6) {
      if (iStack_18 <= iVar5) {
        if (0 < (int)uVar6) goto LAB_0084e207;
        break;
      }
      piVar1 = *(int **)(piVar4[5] + iVar5 * 4);
      if (piVar1 != param_1) {
        iVar3 = (**(code **)(piVar1[0x1d] + 0x58))();
        uVar6 = uVar6 + (iVar3 - DAT_01d622e0);
        piVar4 = piStack_14;
      }
      iVar5 = iVar5 + 1;
    }
    (**(code **)(*param_1 + 0x10))(&iStack_28);
    (**(code **)(*piStack_14 + 0x10))(param_1);
    uVar6 = 0;
    if (uVar2 != 0) {
      do {
        FUN_007c8e00(iStack_28 + uVar6 * 8);
        uVar6 = uVar6 + 1;
      } while (uVar6 < uVar2);
    }
    FUN_00616fc0(iStack_28,iStack_24);
    iStack_24 = iStack_28;
  }
LAB_0084e207:
  if (iStack_28 != 0) {
    FUN_00616fc0(iStack_28,iStack_24);
    uVar2 = iStack_20 - iStack_28 & 0xfffffff8;
    iVar5 = iStack_28;
    if (0xfff < uVar2) {
      iVar5 = *(int *)(iStack_28 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iStack_28 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13010 ; VA 0x0084e260 ; FUN_0084e260 */

void __thiscall FUN_0084e260(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  
  piVar1 = *(int **)(param_1 + 0x18);
  piVar4 = *(int **)(param_1 + 0x14);
  if (piVar4 != piVar1) {
    do {
      if ((undefined4 *)*piVar4 == param_2) break;
      piVar4 = piVar4 + 1;
    } while (piVar4 != piVar1);
    if (piVar4 != piVar1) {
      piVar2 = piVar4 + 1;
      uVar3 = 0;
      uVar5 = (uint)((int)piVar1 + (3 - (int)piVar2)) >> 2;
      if (piVar1 < piVar2) {
        uVar5 = 0;
      }
      if (uVar5 != 0) {
        do {
          if ((undefined4 *)*piVar2 != param_2) {
            *piVar4 = *piVar2;
            piVar4 = piVar4 + 1;
          }
          uVar3 = uVar3 + 1;
          piVar2 = piVar2 + 1;
        } while (uVar3 != uVar5);
      }
      if (piVar4 != piVar1) {
        iVar6 = *(int *)(param_1 + 0x18) - (int)piVar1;
        FUN_0170cc70(piVar4,piVar1,iVar6);
        *(int *)(param_1 + 0x18) = iVar6 + (int)piVar4;
      }
    }
  }
  if (*(undefined4 **)(param_1 + 0x20) == param_2) {
    *(undefined4 *)(param_1 + 0x20) = 0;
  }
  if (param_2 != (undefined4 *)0x0) {
    (**(code **)*param_2)(1);
  }
  if (*(int *)(param_1 + 0x14) == *(int *)(param_1 + 0x18)) {
    FUN_007c6580(param_1);
  }
  return;
}



/* FUNCTION 13011 ; VA 0x0084e320 ; FUN_0084e320 */

void __thiscall FUN_0084e320(int param_1,undefined4 *param_2,int param_3,byte param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  ushort uVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  
  iVar1 = *(int *)(param_3 + 0xa8);
  iVar2 = *(int *)(param_1 + 8);
  iVar3 = FUN_00c157b0();
  fVar7 = *(float *)(iVar2 + 0x20) * *(float *)(iVar3 + 0x2c);
  iVar1 = *(int *)(iVar1 + 0x1ac);
  fVar5 = *(float *)(iVar2 + 0x18) * *(float *)(iVar3 + 0x24);
  fVar6 = *(float *)(iVar2 + 0x1c) * *(float *)(iVar3 + 0x28);
  if (fVar7 < 0.0) {
    fVar7 = fVar7 - DAT_018fee54;
  }
  if (fVar6 < 0.0) {
    fVar6 = fVar6 - DAT_018fee54;
  }
  if (fVar5 < 0.0) {
    fVar5 = fVar5 - DAT_018fee54;
  }
  if (((*(float *)(iVar2 + 0x24) <= *(float *)(iVar1 + 4)) ||
      (*(float *)(iVar2 + 0x28) <= *(float *)(iVar1 + 8))) ||
     (*(float *)(iVar2 + 0x2c) <= *(float *)(iVar1 + 0xc))) {
    uVar4 = 1;
  }
  else {
    uVar4 = 0;
  }
  *param_2 = CONCAT22((short)(int)fVar6,(short)(int)fVar5);
  *(short *)(param_2 + 1) = (short)(int)fVar7;
  *(ushort *)((int)param_2 + 6) = (ushort)param_4 * 2 | uVar4;
  return;
}



/* FUNCTION 13012 ; VA 0x0084e3f0 ; FUN_0084e3f0 */

int __fastcall FUN_0084e3f0(int param_1)

{
  return param_1 + 0xc;
}



/* FUNCTION 13013 ; VA 0x0084e430 ; FUN_0084e430 */

void __thiscall FUN_0084e430(uint *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  undefined4 *puVar7;
  uint uVar8;
  
  *param_1 = 0;
  uVar8 = ((int)param_3 - (int)param_2) / 0x14;
  param_1[1] = 0;
  param_1[2] = 0;
  if (uVar8 != 0) {
    if (0xccccccc < uVar8) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar8 = uVar8 * 0x14;
    if (uVar8 < 0x1000) {
      if (uVar8 == 0) {
        uVar5 = 0;
      }
      else {
        uVar5 = FUN_01674e20(uVar8);
      }
    }
    else {
      uVar5 = uVar8 + 0x23;
      if (uVar5 <= uVar8) {
        uVar5 = 0xffffffff;
      }
      iVar6 = FUN_01674e20(uVar5);
      if (iVar6 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar5 = iVar6 + 0x23U & 0xffffffe0;
      *(int *)(uVar5 - 4) = iVar6;
    }
    *param_1 = uVar5;
    param_1[1] = uVar5;
    param_1[2] = *param_1 + uVar8;
    puVar7 = (undefined4 *)*param_1;
    if (param_2 != param_3) {
      do {
        uVar2 = param_2[1];
        uVar3 = param_2[2];
        uVar4 = param_2[3];
        *puVar7 = *param_2;
        puVar7[1] = uVar2;
        puVar7[2] = uVar3;
        puVar7[3] = uVar4;
        puVar1 = param_2 + 4;
        param_2 = param_2 + 5;
        puVar7[4] = *puVar1;
        puVar7 = puVar7 + 5;
      } while (param_2 != param_3);
    }
    param_1[1] = (uint)puVar7;
  }
  return;
}



/* FUNCTION 13014 ; VA 0x0084e500 ; FUN_0084e500 */

void __thiscall FUN_0084e500(uint *param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  uint uVar2;
  int iVar3;
  undefined8 *puVar4;
  uint uVar5;
  
  uVar5 = ((int)param_3 - (int)param_2) / 0xc;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (uVar5 != 0) {
    if (0x15555555 < uVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar5 = uVar5 * 0xc;
    if (uVar5 < 0x1000) {
      if (uVar5 == 0) {
        uVar2 = 0;
      }
      else {
        uVar2 = FUN_01674e20(uVar5);
      }
    }
    else {
      uVar2 = uVar5 + 0x23;
      if (uVar2 <= uVar5) {
        uVar2 = 0xffffffff;
      }
      iVar3 = FUN_01674e20(uVar2);
      if (iVar3 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar2 = iVar3 + 0x23U & 0xffffffe0;
      *(int *)(uVar2 - 4) = iVar3;
    }
    *param_1 = uVar2;
    param_1[1] = uVar2;
    param_1[2] = *param_1 + uVar5;
    puVar4 = (undefined8 *)*param_1;
    if (param_2 != param_3) {
      do {
        *puVar4 = *param_2;
        puVar1 = param_2 + 1;
        param_2 = (undefined8 *)((int)param_2 + 0xc);
        *(undefined4 *)(puVar4 + 1) = *(undefined4 *)puVar1;
        puVar4 = (undefined8 *)((int)puVar4 + 0xc);
      } while (param_2 != param_3);
    }
    param_1[1] = (uint)puVar4;
  }
  return;
}



/* FUNCTION 13015 ; VA 0x0084e5d0 ; FUN_0084e5d0 */

void __thiscall FUN_0084e5d0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b78c0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Graphics::Emitter>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13016 ; VA 0x0084e63e ; Catch_All@0084e63e */

void Catch_All_0084e63e(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 13017 ; VA 0x0084e660 ; FUN_0084e660 */

int __thiscall FUN_0084e660(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  FUN_0084e5d0(param_2,param_2);
  *param_1 = 0;
  piVar3 = (int *)param_1[1];
  iVar4 = 0;
  param_1[1] = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  return iVar4;
}



/* FUNCTION 13018 ; VA 0x0084e6d0 ; FUN_0084e6d0 */

undefined4 * __thiscall FUN_0084e6d0(undefined4 *param_1,undefined4 param_2)

{
  FUN_0086d7b0(param_2,0);
  *param_1 = RBX::Graphics::ParticleEmitter::vftable;
  param_1[0x1d] = RBX::Graphics::ParticleEmitter::vftable;
  param_1[0x29] = 0x3f800000;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0x3f800000;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0x3f800000;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  *(undefined8 *)(param_1 + 0x35) = 0;
  param_1[0x37] = 0;
  *(undefined8 *)(param_1 + 0x38) = 0;
  param_1[0x3a] = 0;
  *(undefined2 *)(param_1 + 0x3b) = 0;
  param_1[0x42] = 0x3f800000;
  param_1[0x43] = 0;
  param_1[0x44] = 0;
  param_1[0x45] = 0;
  param_1[0x46] = 0x3f800000;
  param_1[0x47] = 0;
  param_1[0x48] = 0;
  param_1[0x49] = 0;
  param_1[0x4a] = 0x3f800000;
  param_1[0x4b] = 0;
  param_1[0x4c] = 0;
  param_1[0x4d] = 0;
  param_1[0x4e] = 0x3f800000;
  param_1[0x4f] = 0;
  param_1[0x50] = 0;
  param_1[0x51] = 0;
  param_1[0x52] = 0x3f800000;
  param_1[0x53] = 0;
  param_1[0x54] = 0;
  param_1[0x55] = 0;
  param_1[0x56] = 0x3f800000;
  param_1[0x57] = 0;
  param_1[0x58] = 0;
  param_1[0x59] = 0;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  param_1[0x5a] = 0x3f800000;
  param_1[0x5b] = 0;
  param_1[0x5c] = 0;
  param_1[0x5d] = 0;
  param_1[0x5e] = 0x3f800000;
  param_1[0x5f] = 0;
  param_1[0x60] = 0;
  param_1[0x61] = 0;
  param_1[0x62] = 0x3f800000;
  param_1[0x3e] = 0;
  param_1[0x3f] = 0;
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  param_1[99] = 0;
  param_1[100] = 0;
  param_1[0x65] = 0;
  return param_1;
}



/* FUNCTION 13019 ; VA 0x0084e990 ; FUN_0084e990 */

void __fastcall FUN_0084e990(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::ParticleEmitter::vftable;
  param_1[0x1d] = RBX::Graphics::ParticleEmitter::vftable;
  FUN_011590c0();
  param_1[0x25] = 0;
  piVar2 = (int *)param_1[0x26];
  param_1[0x26] = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  param_1[0x27] = 0;
  piVar2 = (int *)param_1[0x28];
  param_1[0x28] = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_007c78a0(param_1 + 0x1d,1);
  FUN_0082e1a0(param_1);
  piVar2 = (int *)param_1[0x41];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x3f];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x3d];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x28];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x26];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_0086d830();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13020 ; VA 0x0084eb40 ; FUN_0084eb40 */

void FUN_0084eb40(void)

{
  FUN_0084eb50();
  return;
}



/* FUNCTION 13021 ; VA 0x0084eb50 ; FUN_0084eb50 */

undefined4 __thiscall FUN_0084eb50(undefined4 param_1,byte param_2)

{
  FUN_0084e990();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x198);
  }
  return param_1;
}



/* FUNCTION 13022 ; VA 0x0084eb80 ; FUN_0084eb80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_0084eb80(float param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 *puVar13;
  int iVar14;
  undefined4 uVar15;
  int iVar16;
  int iVar17;
  float fVar18;
  bool bVar19;
  float10 fVar20;
  float fVar21;
  undefined8 uVar22;
  float fVar23;
  undefined4 uVar24;
  undefined4 uStack_19c;
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined4 uStack_190;
  undefined auStack_18c [16];
  undefined4 uStack_17c;
  undefined4 uStack_178;
  undefined uStack_174;
  undefined4 uStack_164;
  undefined4 uStack_160;
  undefined uStack_15c;
  undefined4 uStack_158;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined4 uStack_144;
  float fStack_140;
  float fStack_13c;
  float fStack_138;
  float fStack_134;
  undefined auStack_130 [8];
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined8 uStack_118;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  float fStack_108;
  float fStack_104;
  undefined auStack_100 [16];
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_d8;
  uint uStack_d4;
  undefined uStack_d0;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined8 uStack_bc;
  undefined auStack_b4 [16];
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined uStack_9c;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined uStack_84;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_68;
  float fStack_60;
  float fStack_58;
  undefined *puStack_54;
  undefined *puStack_50;
  undefined *puStack_4c;
  undefined8 uStack_48;
  float fStack_40;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  uint uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017b7bc7;
  pvStack_1c = ExceptionList;
  uStack_24 = 0;
  if (*(int *)((int)param_1 + 0x9c) == 0) {
    return;
  }
  ExceptionList = &pvStack_1c;
  fStack_58 = param_1;
  puVar13 = (undefined4 *)FUN_0060efa0();
  uVar15 = puVar13[1];
  uVar24 = puVar13[2];
  uVar4 = puVar13[3];
  *(undefined4 *)((int)param_1 + 0x108) = *puVar13;
  *(undefined4 *)((int)param_1 + 0x10c) = uVar15;
  *(undefined4 *)((int)param_1 + 0x110) = uVar24;
  *(undefined4 *)((int)param_1 + 0x114) = uVar4;
  uVar15 = puVar13[5];
  uVar24 = puVar13[6];
  uVar4 = puVar13[7];
  *(undefined4 *)((int)param_1 + 0x118) = puVar13[4];
  *(undefined4 *)((int)param_1 + 0x11c) = uVar15;
  *(undefined4 *)((int)param_1 + 0x120) = uVar24;
  *(undefined4 *)((int)param_1 + 0x124) = uVar4;
  uVar15 = puVar13[9];
  uVar24 = puVar13[10];
  uVar4 = puVar13[0xb];
  *(undefined4 *)((int)param_1 + 0x128) = puVar13[8];
  *(undefined4 *)((int)param_1 + 300) = uVar15;
  *(undefined4 *)((int)param_1 + 0x130) = uVar24;
  *(undefined4 *)((int)param_1 + 0x134) = uVar4;
  puVar13 = (undefined4 *)FUN_0060efa0();
  uVar15 = puVar13[1];
  uVar24 = puVar13[2];
  uVar4 = puVar13[3];
  *(undefined4 *)((int)param_1 + 0x138) = *puVar13;
  *(undefined4 *)((int)param_1 + 0x13c) = uVar15;
  *(undefined4 *)((int)param_1 + 0x140) = uVar24;
  *(undefined4 *)((int)param_1 + 0x144) = uVar4;
  uVar15 = puVar13[5];
  uVar24 = puVar13[6];
  uVar4 = puVar13[7];
  *(undefined4 *)((int)param_1 + 0x148) = puVar13[4];
  *(undefined4 *)((int)param_1 + 0x14c) = uVar15;
  *(undefined4 *)((int)param_1 + 0x150) = uVar24;
  *(undefined4 *)((int)param_1 + 0x154) = uVar4;
  uVar15 = puVar13[9];
  uVar24 = puVar13[10];
  uVar4 = puVar13[0xb];
  *(undefined4 *)((int)param_1 + 0x158) = puVar13[8];
  *(undefined4 *)((int)param_1 + 0x15c) = uVar15;
  *(undefined4 *)((int)param_1 + 0x160) = uVar24;
  *(undefined4 *)((int)param_1 + 0x164) = uVar4;
  puVar13 = (undefined4 *)FUN_0060efa0();
  iVar2 = *(int *)((int)param_1 + 0x9c);
  uVar15 = puVar13[1];
  uVar24 = puVar13[2];
  uVar4 = puVar13[3];
  *(undefined4 *)((int)param_1 + 0x168) = *puVar13;
  *(undefined4 *)((int)param_1 + 0x16c) = uVar15;
  *(undefined4 *)((int)param_1 + 0x170) = uVar24;
  *(undefined4 *)((int)param_1 + 0x174) = uVar4;
  uVar15 = puVar13[5];
  uVar24 = puVar13[6];
  uVar4 = puVar13[7];
  *(undefined4 *)((int)param_1 + 0x178) = puVar13[4];
  *(undefined4 *)((int)param_1 + 0x17c) = uVar15;
  *(undefined4 *)((int)param_1 + 0x180) = uVar24;
  *(undefined4 *)((int)param_1 + 0x184) = uVar4;
  uVar15 = puVar13[9];
  uVar24 = puVar13[10];
  uVar4 = puVar13[0xb];
  *(undefined4 *)((int)param_1 + 0x188) = puVar13[8];
  *(undefined4 *)((int)param_1 + 0x18c) = uVar15;
  *(undefined4 *)((int)param_1 + 400) = uVar24;
  *(undefined4 *)((int)param_1 + 0x194) = uVar4;
  iVar16 = *(int *)(iVar2 + 0xc);
  iVar14 = FUN_00d77570();
  fVar18 = fStack_58;
  iVar17 = 0;
  if ((uint)*(ushort *)(iVar16 + 0x1d8) - (uint)*(ushort *)(iVar14 + 0x1d8) <=
      (uint)*(ushort *)(iVar14 + 0x1da)) {
    iVar17 = iVar2;
  }
  if (iVar17 == 0) {
    iVar2 = *(int *)((int)fStack_58 + 0x9c);
    iVar16 = *(int *)(iVar2 + 0xc);
    iVar14 = FUN_00d76400();
    fVar18 = fStack_58;
    iVar17 = 0;
    if ((uint)*(ushort *)(iVar16 + 0x1d8) - (uint)*(ushort *)(iVar14 + 0x1d8) <=
        (uint)*(ushort *)(iVar14 + 0x1da)) {
      iVar17 = iVar2;
    }
    if (iVar17 == 0) {
      iVar2 = *(int *)((int)fStack_58 + 0x9c);
      iVar16 = *(int *)(iVar2 + 0xc);
      iVar14 = FUN_00d76d70();
      iVar17 = 0;
      if ((uint)*(ushort *)(iVar16 + 0x1d8) - (uint)*(ushort *)(iVar14 + 0x1d8) <=
          (uint)*(ushort *)(iVar14 + 0x1da)) {
        iVar17 = iVar2;
      }
      if (iVar17 == 0) {
        iVar2 = *(int *)((int)fStack_58 + 0x9c);
        iVar16 = *(int *)(iVar2 + 0xc);
        iVar14 = FUN_00d3f900();
        fVar18 = fStack_58;
        iVar17 = 0;
        if ((uint)*(ushort *)(iVar16 + 0x1d8) - (uint)*(ushort *)(iVar14 + 0x1d8) <=
            (uint)*(ushort *)(iVar14 + 0x1da)) {
          iVar17 = iVar2;
        }
        if (iVar17 != 0) {
          cVar1 = *(char *)(iVar17 + 0x58);
          *(char *)((int)fStack_58 + 0xed) = cVar1;
          if (cVar1 == '\0') {
            if (*(int *)((int)fStack_58 + 0xf0) != 0) {
              FUN_0058a2b0();
            }
            if (*(int *)((int)fVar18 + 0xf8) != 0) {
              FUN_0058a2b0();
            }
            if (*(int *)((int)fVar18 + 0x100) != 0) {
              FUN_0058a2b0();
            }
          }
          if (*(char *)((int)fVar18 + 0xed) == '\0') {
LAB_008505bb:
            bVar19 = *(int *)((int)fVar18 + 0xf0) == 0;
          }
          else {
            bVar19 = *(int *)((int)fVar18 + 0xf0) == 0;
            if (bVar19) {
              puStack_4c = (undefined *)FUN_01674e20(0x6a4);
              if (puStack_4c == (undefined *)0x0) {
                uVar15 = 0;
              }
              else {
                uStack_a4 = 0;
                uStack_a0 = 0xf;
                auStack_b4[0] = 0;
                uStack_8c = 0;
                uStack_88 = 0xf;
                uStack_9c = 0;
                uStack_74 = 0;
                uStack_70 = 0xf;
                uStack_84 = 0;
                uStack_24 = 0x20;
                uStack_14 = 0x1a;
                uVar15 = FUN_0082b6e0(*(undefined4 *)((int)fVar18 + 8),auStack_b4);
              }
              uStack_14 = 0x1b;
              FUN_0084e660(uVar15);
              uStack_14 = 0xffffffff;
              if ((uStack_24 & 0x20) != 0) {
                uStack_24 = uStack_24 & 0xffffffdf;
                FUN_00637950();
              }
              goto LAB_008505bb;
            }
          }
          uStack_68 = 0;
          if (!bVar19) {
            uStack_c4 = 0;
            uStack_c0 = 0xf;
            uStack_d4 = uStack_d4 & 0xffffff00;
            uStack_14 = 0x1c;
            uStack_bc = 0;
            FUN_00551260("rbxasset://textures/particles/forcefield_vortex_main.dds");
            uStack_bc = 5;
            FUN_0082e7d0(&DAT_01eb48b4);
            FUN_0082e2d0(&DAT_01eb4848,0);
            uStack_a4 = 0;
            uStack_a0 = 0xf;
            auStack_b4[0] = 0;
            uStack_8c = 0;
            uStack_88 = 0xf;
            uStack_9c = 0;
            uStack_74 = 0;
            uStack_70 = 0xf;
            uStack_84 = 0;
            uStack_14._0_1_ = 0x1d;
            FUN_0082e340(&uStack_d4,auStack_b4);
            uStack_14 = CONCAT31(uStack_14._1_3_,0x1c);
            FUN_00637950();
            uVar22 = CONCAT44(DAT_0191a364,(int)uStack_68);
            *(undefined4 *)(*(int *)((int)fVar18 + 0xf0) + 0xe0) = 0;
            fVar21 = DAT_018e3f90;
            iVar2 = *(int *)((int)fVar18 + 0xf0);
            *(undefined8 *)(iVar2 + 0xd4) = uVar22;
            *(undefined4 *)(iVar2 + 0xdc) = 0;
            iVar2 = *(int *)((int)fVar18 + 0xf0);
            fStack_28 = 0.0;
            *(undefined4 *)(iVar2 + 0x104) = 0x3fcccccd;
            *(undefined4 *)(iVar2 + 0x108) = 0x3fcccccd;
            iVar2 = *(int *)((int)fVar18 + 0xf0);
            *(ulonglong *)(iVar2 + 200) = CONCAT44(fVar21,(int)uStack_68);
            *(undefined4 *)(iVar2 + 0xd0) = 0;
            iVar2 = *(int *)((int)fVar18 + 0xf0);
            *(undefined4 *)(iVar2 + 0xe4) = 0x40df62bd;
            *(undefined4 *)(iVar2 + 0xe8) = 0x40df62bd;
            iVar2 = *(int *)((int)fVar18 + 0xf0);
            *(undefined4 *)(iVar2 + 0xf4) = 0x40000000;
            *(undefined4 *)(iVar2 + 0xf8) = 0x40000000;
            iVar2 = *(int *)((int)fVar18 + 0xf0);
            *(undefined4 *)(iVar2 + 0xfc) = 0x3e4ccccd;
            *(undefined4 *)(iVar2 + 0x100) = 0x3e4ccccd;
            iVar2 = *(int *)((int)fVar18 + 0xf0);
            *(undefined4 *)(iVar2 + 0xb8) = 0x40000000;
            *(undefined4 *)(iVar2 + 0xbc) = 0x40000000;
            iVar2 = *(int *)((int)fVar18 + 0xf0);
            *(undefined4 *)(iVar2 + 0xec) = 0x405f62bd;
            *(undefined4 *)(iVar2 + 0xf0) = 0x405f62bd;
            iVar2 = *(int *)((int)fVar18 + 0xf0);
            *(undefined4 *)(iVar2 + 0xc0) = 0x3e32b564;
            *(undefined4 *)(iVar2 + 0xc4) = 0x3e32b564;
            FUN_0082e7f0((float)((uint)*(byte *)((int)fVar18 + 0xed) * 0x28));
            iVar2 = *(int *)((int)fVar18 + 0xf0);
            fStack_28 = DAT_01d622fc * DAT_018ce2f4;
            fStack_30 = DAT_01d622f4 * DAT_018ce2f4;
            fStack_2c = DAT_01d622f8 * DAT_018ce2f4;
            fStack_40 = DAT_01d622fc * DAT_018f7860;
            uStack_48 = CONCAT44(DAT_01d622f8 * DAT_018f7860,DAT_01d622f4 * DAT_018f7860);
            puVar13 = (undefined4 *)FUN_00709d10(&uStack_48,&fStack_30);
            puStack_4c = (undefined *)0x3f800000;
            puStack_50 = (undefined *)0x3f800000;
            uVar15 = puVar13[1];
            uVar24 = puVar13[2];
            uVar4 = puVar13[3];
            uVar22 = *(undefined8 *)(puVar13 + 4);
            *(undefined4 *)(iVar2 + 0xa0) = *puVar13;
            *(undefined4 *)(iVar2 + 0xa4) = uVar15;
            *(undefined4 *)(iVar2 + 0xa8) = uVar24;
            *(undefined4 *)(iVar2 + 0xac) = uVar4;
            *(undefined4 *)(iVar2 + 0x98) = 0;
            *(undefined8 *)(iVar2 + 0xb0) = uVar22;
            FUN_0082e820(0x3f800000,0x3f800000);
            uVar4 = _UNK_018e004c;
            uVar24 = _UNK_018e0048;
            uVar15 = _UNK_018e0044;
            iVar2 = *(int *)((int)fVar18 + 0xf0);
            fStack_30 = 0.0;
            fStack_2c = -1.9;
            *(undefined4 *)(iVar2 + 0x678) = _DAT_018e0040;
            *(undefined4 *)(iVar2 + 0x67c) = uVar15;
            *(undefined4 *)(iVar2 + 0x680) = uVar24;
            *(undefined4 *)(iVar2 + 0x684) = uVar4;
            fStack_28 = 0.0;
            puVar13 = (undefined4 *)FUN_00709da0(&fStack_30);
            uStack_14 = 0xffffffff;
            uVar15 = puVar13[1];
            uVar24 = puVar13[2];
            uVar4 = puVar13[3];
            *(undefined4 *)((int)fVar18 + 0x108) = *puVar13;
            *(undefined4 *)((int)fVar18 + 0x10c) = uVar15;
            *(undefined4 *)((int)fVar18 + 0x110) = uVar24;
            *(undefined4 *)((int)fVar18 + 0x114) = uVar4;
            uVar15 = puVar13[5];
            uVar24 = puVar13[6];
            uVar4 = puVar13[7];
            *(undefined4 *)((int)fVar18 + 0x118) = puVar13[4];
            *(undefined4 *)((int)fVar18 + 0x11c) = uVar15;
            *(undefined4 *)((int)fVar18 + 0x120) = uVar24;
            *(undefined4 *)((int)fVar18 + 0x124) = uVar4;
            uVar15 = puVar13[9];
            uVar24 = puVar13[10];
            uVar4 = puVar13[0xb];
            *(undefined4 *)((int)fVar18 + 0x128) = puVar13[8];
            *(undefined4 *)((int)fVar18 + 300) = uVar15;
            *(undefined4 *)((int)fVar18 + 0x130) = uVar24;
            *(undefined4 *)((int)fVar18 + 0x134) = uVar4;
            *(undefined *)(*(int *)((int)fVar18 + 0xf0) + 0x124) = 1;
            FUN_005507b0();
          }
          if (*(char *)((int)fVar18 + 0xed) == '\0') {
LAB_008509f3:
            if (*(int *)((int)fVar18 + 0xf8) != 0) goto LAB_00850a00;
          }
          else {
            if (*(int *)((int)fVar18 + 0xf8) == 0) {
              puStack_4c = (undefined *)FUN_01674e20(0x6a4);
              if (puStack_4c == (undefined *)0x0) {
                uVar15 = 0;
              }
              else {
                uStack_a4 = 0;
                uStack_a0 = 0xf;
                auStack_b4[0] = 0;
                uStack_8c = 0;
                uStack_88 = 0xf;
                uStack_9c = 0;
                uStack_74 = 0;
                uStack_70 = 0xf;
                uStack_84 = 0;
                uStack_24 = uStack_24 | 0x40;
                uStack_14 = 0x1f;
                uVar15 = FUN_0082b6e0(*(undefined4 *)((int)fVar18 + 8),auStack_b4);
              }
              uStack_14 = 0x20;
              FUN_0084e660(uVar15);
              uStack_14 = 0xffffffff;
              if ((uStack_24 & 0x40) != 0) {
                uStack_24 = uStack_24 & 0xffffffbf;
                FUN_00637950();
              }
              goto LAB_008509f3;
            }
LAB_00850a00:
            uStack_c4 = 0;
            uStack_c0 = 0xf;
            uStack_d4 = uStack_d4 & 0xffffff00;
            uStack_14 = 0x21;
            uStack_bc = 0;
            FUN_00551260("rbxasset://textures/sparkle.png");
            uStack_bc = 5;
            FUN_0082e7d0(&DAT_01eb48b4);
            FUN_0082e2d0(&DAT_01eb4848,0);
            uStack_a4 = 0;
            uStack_a0 = 0xf;
            auStack_b4[0] = 0;
            uStack_8c = 0;
            uStack_88 = 0xf;
            uStack_9c = 0;
            uStack_74 = 0;
            uStack_70 = 0xf;
            uStack_84 = 0;
            uStack_14._0_1_ = 0x22;
            FUN_0082e340(&uStack_d4,auStack_b4);
            uStack_14 = CONCAT31(uStack_14._1_3_,0x21);
            FUN_00637950();
            uVar15 = (undefined4)uStack_68;
            *(undefined4 *)(*(int *)((int)fVar18 + 0xf8) + 0xe0) = 0;
            iVar2 = *(int *)((int)fVar18 + 0xf8);
            fStack_28 = 0.0;
            *(ulonglong *)(iVar2 + 0xd4) = CONCAT44(uVar15,uVar15);
            *(undefined4 *)(iVar2 + 0xdc) = 0;
            iVar2 = *(int *)((int)fVar18 + 0xf8);
            uVar22 = CONCAT44(DAT_018daf58,uVar15);
            *(undefined4 *)(iVar2 + 0x104) = 0x3e0f5c29;
            *(undefined4 *)(iVar2 + 0x108) = 0x3e0f5c29;
            iVar2 = *(int *)((int)fVar18 + 0xf8);
            *(undefined8 *)(iVar2 + 200) = uVar22;
            *(undefined4 *)(iVar2 + 0xd0) = 0;
            iVar2 = *(int *)((int)fVar18 + 0xf8);
            *(undefined4 *)(iVar2 + 0xe4) = 0;
            *(undefined4 *)(iVar2 + 0xe8) = 0;
            iVar2 = *(int *)((int)fVar18 + 0xf8);
            *(undefined4 *)(iVar2 + 0xf4) = 0x3d23d70a;
            *(undefined4 *)(iVar2 + 0xf8) = 0x3d23d70a;
            iVar2 = *(int *)((int)fVar18 + 0xf8);
            *(undefined4 *)(iVar2 + 0xfc) = 0x3d23d70a;
            *(undefined4 *)(iVar2 + 0x100) = 0x3d23d70a;
            iVar2 = *(int *)((int)fVar18 + 0xf8);
            *(undefined4 *)(iVar2 + 0xb8) = 0x40400000;
            *(undefined4 *)(iVar2 + 0xbc) = 0x40400000;
            iVar2 = *(int *)((int)fVar18 + 0xf8);
            *(undefined4 *)(iVar2 + 0xec) = 0xc10b9db6;
            *(undefined4 *)(iVar2 + 0xf0) = 0x410b9db6;
            iVar2 = *(int *)((int)fVar18 + 0xf8);
            *(undefined4 *)(iVar2 + 0xc0) = 0x3f06080b;
            *(undefined4 *)(iVar2 + 0xc4) = 0x3f06080b;
            FUN_0082e7f0((float)((uint)*(byte *)((int)fVar18 + 0xed) * 0xc));
            iVar2 = *(int *)((int)fVar18 + 0xf8);
            fStack_28 = DAT_01d622fc * DAT_018f994c;
            fStack_30 = DAT_01d622f4 * DAT_018f994c;
            fStack_2c = DAT_01d622f8 * DAT_018f994c;
            fStack_40 = DAT_01d622fc * DAT_0191a360;
            uStack_48 = CONCAT44(DAT_01d622f8 * DAT_0191a360,DAT_01d622f4 * DAT_0191a360);
            puVar13 = (undefined4 *)FUN_00709d10(&uStack_48,&fStack_30);
            puStack_4c = (undefined *)0x3fa66666;
            puStack_50 = (undefined *)0x3fa66666;
            uVar15 = puVar13[1];
            uVar24 = puVar13[2];
            uVar4 = puVar13[3];
            uVar22 = *(undefined8 *)(puVar13 + 4);
            *(undefined4 *)(iVar2 + 0xa0) = *puVar13;
            *(undefined4 *)(iVar2 + 0xa4) = uVar15;
            *(undefined4 *)(iVar2 + 0xa8) = uVar24;
            *(undefined4 *)(iVar2 + 0xac) = uVar4;
            *(undefined4 *)(iVar2 + 0x98) = 0;
            *(undefined8 *)(iVar2 + 0xb0) = uVar22;
            FUN_0082e820(0x3fa66666,0x3fa66666);
            uVar4 = _UNK_018e004c;
            uVar24 = _UNK_018e0048;
            uVar15 = _UNK_018e0044;
            iVar2 = *(int *)((int)fVar18 + 0xf8);
            *(undefined4 *)(iVar2 + 0x678) = _DAT_018e0040;
            *(undefined4 *)(iVar2 + 0x67c) = uVar15;
            *(undefined4 *)(iVar2 + 0x680) = uVar24;
            *(undefined4 *)(iVar2 + 0x684) = uVar4;
            *(undefined *)(*(int *)((int)fVar18 + 0xf8) + 0x124) = 1;
            puVar13 = (undefined4 *)FUN_0060efa0();
            uStack_14 = 0xffffffff;
            uVar15 = puVar13[1];
            uVar24 = puVar13[2];
            uVar4 = puVar13[3];
            *(undefined4 *)((int)fVar18 + 0x138) = *puVar13;
            *(undefined4 *)((int)fVar18 + 0x13c) = uVar15;
            *(undefined4 *)((int)fVar18 + 0x140) = uVar24;
            *(undefined4 *)((int)fVar18 + 0x144) = uVar4;
            uVar15 = puVar13[5];
            uVar24 = puVar13[6];
            uVar4 = puVar13[7];
            *(undefined4 *)((int)fVar18 + 0x148) = puVar13[4];
            *(undefined4 *)((int)fVar18 + 0x14c) = uVar15;
            *(undefined4 *)((int)fVar18 + 0x150) = uVar24;
            *(undefined4 *)((int)fVar18 + 0x154) = uVar4;
            uVar15 = puVar13[9];
            uVar24 = puVar13[10];
            uVar4 = puVar13[0xb];
            *(undefined4 *)((int)fVar18 + 0x158) = puVar13[8];
            *(undefined4 *)((int)fVar18 + 0x15c) = uVar15;
            *(undefined4 *)((int)fVar18 + 0x160) = uVar24;
            *(undefined4 *)((int)fVar18 + 0x164) = uVar4;
            FUN_005507b0();
          }
          if (*(char *)((int)fVar18 + 0xed) == '\0') {
LAB_00850e01:
            if (*(int *)((int)fVar18 + 0x100) == 0) goto LAB_0085187a;
          }
          else if (*(int *)((int)fVar18 + 0x100) == 0) {
            puStack_4c = (undefined *)FUN_01674e20(0x6a4);
            if (puStack_4c == (undefined *)0x0) {
              uVar15 = 0;
            }
            else {
              uStack_a4 = 0;
              uStack_a0 = 0xf;
              auStack_b4[0] = 0;
              uStack_8c = 0;
              uStack_88 = 0xf;
              uStack_9c = 0;
              uStack_74 = 0;
              uStack_70 = 0xf;
              uStack_84 = 0;
              uStack_24 = uStack_24 | 0x80;
              uStack_14 = 0x24;
              uVar15 = FUN_0082b6e0(*(undefined4 *)((int)fVar18 + 8),auStack_b4);
            }
            uStack_14 = 0x25;
            FUN_0084e660(uVar15);
            uStack_14 = 0xffffffff;
            if ((uStack_24 & 0x80) != 0) {
              FUN_00637950();
            }
            goto LAB_00850e01;
          }
          uStack_c4 = 0;
          uStack_c0 = 0xf;
          uStack_d4 = uStack_d4 & 0xffffff00;
          uStack_14 = 0x26;
          uStack_bc = 0;
          FUN_00551260("rbxasset://textures/particles/forcefield_glow_main.dds");
          uStack_bc = 0x200000004;
          FUN_0082e7d0(&DAT_01eb48a8);
          FUN_0082e2d0(&DAT_01eb489c,0);
          uStack_a4 = 0;
          uStack_a0 = 0xf;
          auStack_b4[0] = 0;
          uStack_8c = 0;
          uStack_88 = 0xf;
          uStack_9c = 0;
          uStack_74 = 0;
          uStack_70 = 0xf;
          uStack_84 = 0;
          uStack_14._0_1_ = 0x27;
          FUN_0082e340(&uStack_d4,auStack_b4);
          uStack_14 = CONCAT31(uStack_14._1_3_,0x26);
          FUN_00637950();
          uVar15 = (undefined4)uStack_68;
          *(undefined4 *)(*(int *)((int)fVar18 + 0x100) + 0xe0) = 0;
          iVar2 = *(int *)((int)fVar18 + 0x100);
          fStack_28 = 0.0;
          *(ulonglong *)(iVar2 + 0xd4) = CONCAT44(uVar15,uVar15);
          *(undefined4 *)(iVar2 + 0xdc) = 0;
          iVar2 = *(int *)((int)fVar18 + 0x100);
          *(undefined4 *)(iVar2 + 0x104) = 0x3f000000;
          *(undefined4 *)(iVar2 + 0x108) = 0x3f000000;
          iVar2 = *(int *)((int)fVar18 + 0x100);
          *(ulonglong *)(iVar2 + 200) = CONCAT44(uVar15,uVar15);
          *(undefined4 *)(iVar2 + 0xd0) = 0;
          iVar2 = *(int *)((int)fVar18 + 0x100);
          *(undefined4 *)(iVar2 + 0xe4) = 0;
          *(undefined4 *)(iVar2 + 0xe8) = 0;
          iVar2 = *(int *)((int)fVar18 + 0x100);
          *(undefined4 *)(iVar2 + 0xf4) = 0x408ccccd;
          *(undefined4 *)(iVar2 + 0xf8) = 0x408ccccd;
          iVar2 = *(int *)((int)fVar18 + 0x100);
          *(undefined4 *)(iVar2 + 0xfc) = 0x408ccccd;
          *(undefined4 *)(iVar2 + 0x100) = 0x408ccccd;
          iVar2 = *(int *)((int)fVar18 + 0x100);
          *(undefined4 *)(iVar2 + 0xb8) = 0;
          *(undefined4 *)(iVar2 + 0xbc) = 0;
          iVar2 = *(int *)((int)fVar18 + 0x100);
          *(undefined4 *)(iVar2 + 0xec) = 0x405f62bd;
          *(undefined4 *)(iVar2 + 0xf0) = 0x405f62bd;
          iVar2 = *(int *)((int)fVar18 + 0x100);
          *(undefined4 *)(iVar2 + 0xc0) = 0x3d0ef783;
          *(undefined4 *)(iVar2 + 0xc4) = 0x3d0ef783;
          FUN_0082e7f0((float)((uint)*(byte *)((int)fVar18 + 0xed) * 0xf));
          iVar2 = *(int *)((int)fVar18 + 0x100);
          fStack_30 = 0.0;
          fStack_2c = 0.0;
          fStack_28 = 0.0;
          uStack_48 = 0;
          fStack_40 = 0.0;
          puVar13 = (undefined4 *)FUN_00709d10(&uStack_48,&fStack_30);
          puStack_4c = (undefined *)0x40000000;
          puStack_50 = (undefined *)0x40000000;
          uVar15 = puVar13[1];
          uVar24 = puVar13[2];
          uVar4 = puVar13[3];
          uVar22 = *(undefined8 *)(puVar13 + 4);
          *(undefined4 *)(iVar2 + 0xa0) = *puVar13;
          *(undefined4 *)(iVar2 + 0xa4) = uVar15;
          *(undefined4 *)(iVar2 + 0xa8) = uVar24;
          *(undefined4 *)(iVar2 + 0xac) = uVar4;
          *(undefined4 *)(iVar2 + 0x98) = 0;
          *(undefined8 *)(iVar2 + 0xb0) = uVar22;
          FUN_0082e820(0x40000000,0x40000000);
          uVar4 = _UNK_018e004c;
          uVar24 = _UNK_018e0048;
          uVar15 = _UNK_018e0044;
          iVar2 = *(int *)((int)fVar18 + 0x100);
          fStack_30 = 0.0;
          fStack_2c = -0.5;
          *(undefined4 *)(iVar2 + 0x678) = _DAT_018e0040;
          *(undefined4 *)(iVar2 + 0x67c) = uVar15;
          *(undefined4 *)(iVar2 + 0x680) = uVar24;
          *(undefined4 *)(iVar2 + 0x684) = uVar4;
          fStack_28 = 0.0;
          puVar13 = (undefined4 *)FUN_00709da0(&fStack_30);
          uStack_14 = 0xffffffff;
          uVar15 = puVar13[1];
          uVar24 = puVar13[2];
          uVar4 = puVar13[3];
          *(undefined4 *)((int)fVar18 + 0x168) = *puVar13;
          *(undefined4 *)((int)fVar18 + 0x16c) = uVar15;
          *(undefined4 *)((int)fVar18 + 0x170) = uVar24;
          *(undefined4 *)((int)fVar18 + 0x174) = uVar4;
          uVar15 = puVar13[5];
          uVar24 = puVar13[6];
          uVar4 = puVar13[7];
          *(undefined4 *)((int)fVar18 + 0x178) = puVar13[4];
          *(undefined4 *)((int)fVar18 + 0x17c) = uVar15;
          *(undefined4 *)((int)fVar18 + 0x180) = uVar24;
          *(undefined4 *)((int)fVar18 + 0x184) = uVar4;
          uVar15 = puVar13[9];
          uVar24 = puVar13[10];
          uVar4 = puVar13[0xb];
          *(undefined4 *)((int)fVar18 + 0x188) = puVar13[8];
          *(undefined4 *)((int)fVar18 + 0x18c) = uVar15;
          *(undefined4 *)((int)fVar18 + 400) = uVar24;
          *(undefined4 *)((int)fVar18 + 0x194) = uVar4;
          *(undefined4 *)(*(int *)((int)fVar18 + 0x100) + 0x688) = 0x40200000;
          *(undefined4 *)(*(int *)((int)fVar18 + 0x100) + 0x66c) = 0x3f800000;
          *(undefined4 *)(*(int *)((int)fVar18 + 0x100) + 0x670) = 0x3e19999a;
          *(undefined *)(*(int *)((int)fVar18 + 0x100) + 0x124) = 1;
          FUN_005507b0();
          goto LAB_0085187a;
        }
        fVar21 = *(float *)((int)fStack_58 + 0x9c);
        iVar2 = *(int *)((int)fVar21 + 0xc);
        iVar16 = FUN_00d3dc90();
        fVar18 = fStack_58;
        puStack_4c = (undefined *)0.0;
        if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar16 + 0x1d8) <=
            (uint)*(ushort *)(iVar16 + 0x1da)) {
          puStack_4c = (undefined *)fVar21;
        }
        if (puStack_4c == (undefined *)0x0) goto LAB_0085187a;
        bVar19 = *(int *)((int)fStack_58 + 0xf0) == 0;
        piVar3 = (int *)((int)fStack_58 + 0xf0);
        *(undefined *)((int)fStack_58 + 0xed) = 1;
        if (bVar19) {
          fStack_60 = (float)FUN_01674e20(0x6a4);
          if (fStack_60 == 0.0) {
            uVar15 = 0;
          }
          else {
            uStack_a4 = 0;
            uStack_a0 = 0xf;
            auStack_b4[0] = 0;
            uStack_8c = 0;
            uStack_88 = 0xf;
            uStack_9c = 0;
            uStack_74 = 0;
            uStack_70 = 0xf;
            uStack_84 = 0;
            uStack_24 = 0x100;
            uStack_14 = 0x29;
            uVar15 = FUN_0082b6e0(*(undefined4 *)((int)fVar18 + 8),auStack_b4);
          }
          uStack_14 = 0x2a;
          FUN_0084e660(uVar15);
          uStack_14 = 0xffffffff;
          if ((uStack_24 & 0x100) != 0) {
            uStack_24 = uStack_24 & 0xfffffeff;
            FUN_00637950();
          }
          bVar19 = *piVar3 == 0;
        }
        uStack_48 = 0;
        if (!bVar19) {
          uStack_c4 = 0;
          uStack_c0 = 0xf;
          uStack_d4 = uStack_d4 & 0xffffff00;
          uStack_14 = 0x2b;
          uStack_bc = 0;
          FUN_00551260("rbxasset://textures/particles/sparkles_main.dds");
          uStack_bc = 0x100000005;
          FUN_0082e7d0(&DAT_01eb4854);
          FUN_0082e2d0(&DAT_01eb4860,0);
          uStack_a4 = 0;
          uStack_a0 = 0xf;
          auStack_b4[0] = 0;
          uStack_8c = 0;
          uStack_88 = 0xf;
          uStack_9c = 0;
          uStack_74 = 0;
          uStack_70 = 0xf;
          uStack_84 = 0;
          uStack_14._0_1_ = 0x2c;
          FUN_0082e340(&uStack_d4,auStack_b4);
          uStack_14 = CONCAT31(uStack_14._1_3_,0x2b);
          FUN_00637950();
          FUN_0082e7f0(0);
          iVar2 = *piVar3;
          *(ulonglong *)(iVar2 + 0xd4) = CONCAT44(DAT_0191a36c,(float)uStack_48);
          fStack_28 = 0.0;
          *(undefined4 *)(iVar2 + 0xdc) = 0;
          fStack_60 = 2.0;
          uStack_68 = CONCAT44(0x3fe66666,(undefined4)uStack_68);
          *(undefined4 *)(*piVar3 + 0xe0) = 0x3e4ccccd;
          iVar2 = *piVar3;
          *(undefined4 *)(iVar2 + 0xb8) = 0;
          *(undefined4 *)(iVar2 + 0xbc) = 0x41f00000;
          iVar2 = *piVar3;
          *(undefined4 *)(iVar2 + 0xc0) = 0x3fa78a0e;
          *(undefined4 *)(iVar2 + 0xc4) = 0x3fa78a0e;
          iVar2 = *piVar3;
          *(undefined4 *)(iVar2 + 0xf4) = 0x3f333333;
          *(undefined4 *)(iVar2 + 0xf8) = 0x3f333333;
          iVar2 = *piVar3;
          *(undefined4 *)(iVar2 + 0xfc) = 0x3f333333;
          *(undefined4 *)(iVar2 + 0x100) = 0x3f333333;
          FUN_0082e820(0x3fe66666,0x40000000);
          FUN_0082e7f0(0);
          iVar2 = *piVar3;
          fStack_30 = 0.0;
          fStack_2c = 0.0;
          fStack_28 = 0.0;
          uStack_68 = 0x8000000080000000;
          fStack_60 = -0.0;
          puVar13 = (undefined4 *)FUN_00709d10(&uStack_68,&fStack_30);
          uVar15 = *puVar13;
          uVar24 = puVar13[1];
          uVar4 = puVar13[2];
          uVar5 = puVar13[3];
          uVar22 = *(undefined8 *)(puVar13 + 4);
          *(undefined4 *)(iVar2 + 0x98) = 0;
          *(undefined4 *)(iVar2 + 0xa0) = uVar15;
          *(undefined4 *)(iVar2 + 0xa4) = uVar24;
          *(undefined4 *)(iVar2 + 0xa8) = uVar4;
          *(undefined4 *)(iVar2 + 0xac) = uVar5;
          *(undefined8 *)(iVar2 + 0xb0) = uVar22;
          puVar13 = (undefined4 *)FUN_00709da0((int)puStack_4c + 0x80);
          uVar15 = puVar13[1];
          uVar24 = puVar13[2];
          uVar4 = puVar13[3];
          uVar5 = puVar13[4];
          uVar6 = puVar13[5];
          uVar7 = puVar13[6];
          uVar8 = puVar13[7];
          uVar9 = puVar13[8];
          uVar10 = puVar13[9];
          uVar11 = puVar13[10];
          uVar12 = puVar13[0xb];
          iVar2 = *(int *)((int)fVar18 + 0xf0);
          *(undefined4 *)(iVar2 + 0x14) = *puVar13;
          *(undefined4 *)(iVar2 + 0x18) = uVar15;
          *(undefined4 *)(iVar2 + 0x1c) = uVar24;
          *(undefined4 *)(iVar2 + 0x20) = uVar4;
          *(undefined4 *)(iVar2 + 0x24) = uVar5;
          *(undefined4 *)(iVar2 + 0x28) = uVar6;
          *(undefined4 *)(iVar2 + 0x2c) = uVar7;
          *(undefined4 *)(iVar2 + 0x30) = uVar8;
          *(undefined4 *)(iVar2 + 0x34) = uVar9;
          *(undefined4 *)(iVar2 + 0x38) = uVar10;
          *(undefined4 *)(iVar2 + 0x3c) = uVar11;
          *(undefined4 *)(iVar2 + 0x40) = uVar12;
          FUN_0082c170(0x1e);
          uStack_14 = 0xffffffff;
          FUN_005507b0();
        }
        if (*(int *)((int)fVar18 + 0xf8) == 0) {
          fStack_60 = (float)FUN_01674e20(0x6a4);
          if (fStack_60 == 0.0) {
            uVar15 = 0;
          }
          else {
            uStack_a4 = 0;
            uStack_a0 = 0xf;
            auStack_b4[0] = 0;
            uStack_8c = 0;
            uStack_88 = 0xf;
            uStack_9c = 0;
            uStack_74 = 0;
            uStack_70 = 0xf;
            uStack_84 = 0;
            uStack_24 = uStack_24 | 0x200;
            uStack_14 = 0x2e;
            uVar15 = FUN_0082b6e0(*(undefined4 *)((int)fVar18 + 8),auStack_b4);
          }
          uStack_14 = 0x2f;
          FUN_0084e660(uVar15);
          uStack_14 = 0xffffffff;
          if ((uStack_24 & 0x200) != 0) {
            FUN_00637950();
          }
          if (*(int *)((int)fVar18 + 0xf8) != 0) goto LAB_00851576;
          goto LAB_0085186f;
        }
LAB_00851576:
        uStack_c4 = 0;
        uStack_c0 = 0xf;
        uStack_d4 = uStack_d4 & 0xffffff00;
        uStack_14 = 0x30;
        uStack_bc = 0;
        FUN_00551260("rbxasset://textures/explosion.png");
        uStack_bc = 0x100000003;
        FUN_0082e7d0(&DAT_01eb4854);
        FUN_0082e2d0(&DAT_01eb4860,0);
        uStack_a4 = 0;
        uStack_a0 = 0xf;
        auStack_b4[0] = 0;
        uStack_8c = 0;
        uStack_88 = 0xf;
        uStack_9c = 0;
        uStack_74 = 0;
        uStack_70 = 0xf;
        uStack_84 = 0;
        uStack_14._0_1_ = 0x31;
        FUN_0082e340(&uStack_d4,auStack_b4);
        uStack_14 = CONCAT31(uStack_14._1_3_,0x30);
        FUN_00637950();
        iVar2 = *(int *)((int)fVar18 + 0xf8);
        fStack_30 = 0.0;
        fStack_2c = 0.0;
        fStack_28 = 0.0;
        uStack_68 = 0x8000000080000000;
        fStack_60 = -0.0;
        puVar13 = (undefined4 *)FUN_00709d10(&uStack_68,&fStack_30);
        uVar15 = puVar13[1];
        uVar24 = puVar13[2];
        uVar4 = puVar13[3];
        uVar22 = *(undefined8 *)(puVar13 + 4);
        *(undefined4 *)(iVar2 + 0xa0) = *puVar13;
        *(undefined4 *)(iVar2 + 0xa4) = uVar15;
        *(undefined4 *)(iVar2 + 0xa8) = uVar24;
        *(undefined4 *)(iVar2 + 0xac) = uVar4;
        *(undefined4 *)(iVar2 + 0x98) = 0;
        *(undefined8 *)(iVar2 + 0xb0) = uVar22;
        piVar3 = (int *)((int)fVar18 + 0xf8);
        FUN_0082e7f0(0);
        iVar2 = *piVar3;
        fStack_28 = 0.0;
        *(ulonglong *)(iVar2 + 0xd4) = CONCAT44((int)uStack_48,(int)uStack_48);
        *(undefined4 *)(iVar2 + 0xdc) = 0;
        uStack_68 = CONCAT44(0x3fc00000,(undefined4)uStack_68);
        *(undefined4 *)(*piVar3 + 0xe0) = 0x3f000000;
        iVar2 = *piVar3;
        *(undefined4 *)(iVar2 + 0xb8) = 0x41700000;
        *(undefined4 *)(iVar2 + 0xbc) = 0x41f00000;
        iVar2 = *piVar3;
        *(undefined4 *)(iVar2 + 0xc0) = 0x3f913361;
        *(undefined4 *)(iVar2 + 0xc4) = 0x3f913361;
        iVar2 = *piVar3;
        *(undefined4 *)(iVar2 + 0xec) = 0xbfc90c10;
        *(undefined4 *)(iVar2 + 0xf0) = 0x3fc90c10;
        fStack_60 = 2.5;
        FUN_0082e820(0x3fc00000,0x40200000);
        iVar2 = *piVar3;
        uStack_48 = CONCAT44(&DAT_bf800000,(float)uStack_48);
        fStack_40 = 1.0;
        *(undefined4 *)(iVar2 + 0xf4) = 0x40800000;
        *(undefined4 *)(iVar2 + 0xf8) = 0x40800000;
        iVar2 = *piVar3;
        *(undefined4 *)(iVar2 + 0xfc) = 0x40800000;
        *(undefined4 *)(iVar2 + 0x100) = 0x40800000;
        iVar2 = *piVar3;
        puVar13 = (undefined4 *)FUN_0073e660((int)&uStack_68 + 4,0x3f490c10,(int)&uStack_48 + 4);
        uVar15 = puVar13[1];
        *(undefined4 *)(iVar2 + 0xe4) = *puVar13;
        *(undefined4 *)(iVar2 + 0xe8) = uVar15;
        iVar2 = *(int *)((int)fVar18 + 0xf8);
        *(undefined4 *)(iVar2 + 0x104) = 0x3f800000;
        *(undefined4 *)(iVar2 + 0x108) = 0x3f800000;
        FUN_0082e7f0(0);
        iVar2 = *(int *)((int)fVar18 + 0xf8);
        puVar13 = (undefined4 *)FUN_0073e0d0(0x3f4ccccd,0x3f000000,0x3f000000,0x3f000000);
        uVar15 = puVar13[1];
        uVar24 = puVar13[2];
        uVar4 = puVar13[3];
        *(undefined4 *)(iVar2 + 0x678) = *puVar13;
        *(undefined4 *)(iVar2 + 0x67c) = uVar15;
        *(undefined4 *)(iVar2 + 0x680) = uVar24;
        *(undefined4 *)(iVar2 + 0x684) = uVar4;
        puVar13 = (undefined4 *)FUN_00709da0((int)puStack_4c + 0x80);
        uVar15 = puVar13[1];
        uVar24 = puVar13[2];
        uVar4 = puVar13[3];
        uVar5 = puVar13[4];
        uVar6 = puVar13[5];
        uVar7 = puVar13[6];
        uVar8 = puVar13[7];
        uVar9 = puVar13[8];
        uVar10 = puVar13[9];
        uVar11 = puVar13[10];
        uVar12 = puVar13[0xb];
        iVar2 = *(int *)((int)fVar18 + 0xf8);
        *(undefined4 *)(iVar2 + 0x14) = *puVar13;
        *(undefined4 *)(iVar2 + 0x18) = uVar15;
        *(undefined4 *)(iVar2 + 0x1c) = uVar24;
        *(undefined4 *)(iVar2 + 0x20) = uVar4;
        *(undefined4 *)(iVar2 + 0x24) = uVar5;
        *(undefined4 *)(iVar2 + 0x28) = uVar6;
        *(undefined4 *)(iVar2 + 0x2c) = uVar7;
        *(undefined4 *)(iVar2 + 0x30) = uVar8;
        *(undefined4 *)(iVar2 + 0x34) = uVar9;
        *(undefined4 *)(iVar2 + 0x38) = uVar10;
        *(undefined4 *)(iVar2 + 0x3c) = uVar11;
        *(undefined4 *)(iVar2 + 0x40) = uVar12;
        FUN_0082c170(0x1e);
      }
      else {
        fVar20 = (float10)FUN_00d771c0();
        fStack_104 = (float)(fVar20 / (float10)_DAT_0191a35c);
        puStack_4c = (undefined *)(fStack_104 * DAT_018f993c);
        fVar20 = (float10)FUN_00d77190();
        uVar22 = *(undefined8 *)(iVar17 + 0x5c);
        fStack_40 = *(float *)(iVar17 + 100);
        uStack_48._0_4_ = (float)uVar22;
        fStack_34 = (float)uStack_48;
        uStack_48._4_4_ = (float)((ulonglong)uVar22 >> 0x20);
        fStack_30 = uStack_48._4_4_;
        fStack_60 = (float)fVar20;
        fStack_28 = 1.0;
        uStack_48 = uVar22;
        fStack_2c = fStack_40;
        FUN_01165750(&fStack_34);
        uVar22 = *(undefined8 *)(iVar17 + 0x68);
        fStack_40 = *(float *)(iVar17 + 0x70);
        uStack_48._0_4_ = (float)uVar22;
        fStack_34 = (float)uStack_48;
        uStack_48._4_4_ = (float)((ulonglong)uVar22 >> 0x20);
        fStack_30 = uStack_48._4_4_;
        fStack_28 = 1.0;
        uStack_48 = uVar22;
        fStack_2c = fStack_40;
        FUN_01165750(&fStack_34);
        fVar18 = fStack_58;
        *(undefined *)((int)fStack_58 + 0xed) = *(undefined *)(iVar17 + 0x58);
        fStack_40 = (float)puStack_4c * DAT_01d622fc;
        fStack_28 = (float)((uint)puStack_4c ^ DAT_018c4ea0);
        uStack_48 = CONCAT44((float)puStack_4c * DAT_01d622f8,(float)puStack_4c * DAT_01d622f4);
        fStack_30 = fStack_28 * DAT_01d622f4;
        fStack_2c = fStack_28 * DAT_01d622f8;
        fStack_28 = fStack_28 * DAT_01d622fc;
        FUN_00709d10(&fStack_30,&uStack_48);
        fStack_28 = (float)puStack_4c + (float)puStack_4c;
        fVar21 = (float)puStack_4c * DAT_0191a364;
        fStack_30 = fStack_28 * DAT_01d622f4;
        fStack_2c = fStack_28 * DAT_01d622f8;
        fStack_28 = fStack_28 * DAT_01d622fc;
        fStack_40 = fVar21 * DAT_01d622fc;
        uStack_48 = CONCAT44(fVar21 * DAT_01d622f8,fVar21 * DAT_01d622f4);
        FUN_00709d10(&uStack_48,&fStack_30);
        if (*(char *)((int)fVar18 + 0xed) == '\0') {
LAB_0084fc8b:
          bVar19 = *(int *)((int)fVar18 + 0xf0) == 0;
        }
        else {
          bVar19 = *(int *)((int)fVar18 + 0xf0) == 0;
          if (bVar19) {
            puStack_4c = (undefined *)FUN_01674e20(0x6a4);
            if (puStack_4c == (undefined *)0x0) {
              uVar15 = 0;
            }
            else {
              uStack_f0 = 0;
              uStack_ec = 0xf;
              auStack_100[0] = 0;
              uStack_d8 = 0;
              uStack_d4 = 0xf;
              uStack_e8 = 0;
              uStack_c0 = 0;
              uStack_bc = CONCAT44(uStack_bc._4_4_,0xf);
              uStack_d0 = 0;
              uStack_24 = 8;
              uStack_14 = 0x10;
              uVar15 = FUN_0082b6e0(*(undefined4 *)((int)fVar18 + 8),auStack_100);
            }
            uStack_14 = 0x11;
            FUN_0084e660(uVar15);
            uStack_14 = 0xffffffff;
            if ((uStack_24 & 8) != 0) {
              uStack_24 = uStack_24 & 0xfffffff7;
              FUN_00637950();
            }
            goto LAB_0084fc8b;
          }
        }
        uStack_48 = 0;
        if (!bVar19) {
          uStack_c4 = 0;
          uStack_c0 = 0xf;
          uStack_d4 = uStack_d4 & 0xffffff00;
          uStack_14 = 0x12;
          uStack_bc = 0;
          FUN_00551260("rbxasset://textures/particles/fire_main.dds");
          uStack_bc = 0x200000004;
          FUN_0082e7d0(&DAT_01eb4878);
          FUN_0082e2d0(&DAT_01eb486c,0);
          uStack_a4 = 0;
          uStack_a0 = 0xf;
          auStack_b4[0] = 0;
          uStack_8c = 0;
          uStack_88 = 0xf;
          uStack_9c = 0;
          uStack_74 = 0;
          uStack_70 = 0xf;
          uStack_84 = 0;
          uStack_14._0_1_ = 0x13;
          FUN_0082e340(&uStack_d4,auStack_b4);
          uStack_14 = CONCAT31(uStack_14._1_3_,0x12);
          FUN_00637950();
          uVar15 = (undefined4)uStack_48;
          *(undefined4 *)(*(int *)((int)fVar18 + 0xf0) + 0xe0) = 0x3ecccccd;
          iVar2 = *(int *)((int)fVar18 + 0xf0);
          fStack_28 = 0.0;
          *(ulonglong *)(iVar2 + 0xd4) = CONCAT44(uVar15,uVar15);
          fVar21 = fStack_104 * DAT_018f994c;
          *(undefined4 *)(iVar2 + 0xdc) = 0;
          iVar2 = *(int *)((int)fVar18 + 0xf0);
          fVar23 = fStack_104 * fStack_104 * DAT_018e1340;
          fVar21 = fVar21 * DAT_018f7864;
          *(float *)(iVar2 + 0x104) = fVar21;
          *(float *)(iVar2 + 0x108) = fVar21;
          iVar2 = *(int *)((int)fVar18 + 0xf0);
          *(ulonglong *)(iVar2 + 200) =
               CONCAT44((fVar23 + fStack_60 * DAT_01901f3c) * DAT_018ce2f4,uVar15);
          fVar21 = fStack_104 * DAT_01901d98;
          *(undefined4 *)(iVar2 + 0xd0) = 0;
          iVar2 = *(int *)((int)fVar18 + 0xf0);
          *(undefined4 *)(iVar2 + 0xe4) = 0xbfc90c10;
          *(undefined4 *)(iVar2 + 0xe8) = 0x3fc90c10;
          iVar2 = *(int *)((int)fVar18 + 0xf0);
          *(float *)(iVar2 + 0xf4) = fVar21;
          *(float *)(iVar2 + 0xf8) = fVar21;
          iVar2 = *(int *)((int)fVar18 + 0xf0);
          *(float *)(iVar2 + 0xfc) = fVar21;
          *(float *)(iVar2 + 0x100) = fVar21;
          iVar2 = *(int *)((int)fVar18 + 0xf0);
          fVar21 = (fStack_104 * DAT_018fabe0 * fStack_104 + fStack_60 * DAT_018fabe0) *
                   DAT_0191a25c;
          *(float *)(iVar2 + 0xb8) = fVar21;
          *(float *)(iVar2 + 0xbc) = fVar21;
          iVar2 = *(int *)((int)fVar18 + 0xf0);
          *(undefined4 *)(iVar2 + 0xec) = 0x3fdf62bd;
          *(undefined4 *)(iVar2 + 0xf0) = 0x3fdf62bd;
          iVar2 = *(int *)((int)fVar18 + 0xf0);
          *(undefined4 *)(iVar2 + 0xec) = 0xbfa78a0e;
          *(undefined4 *)(iVar2 + 0xf0) = 0x3fa78a0e;
          iVar2 = *(int *)((int)fVar18 + 0xf0);
          *(undefined4 *)(iVar2 + 0xc0) = 0x3e32b564;
          *(undefined4 *)(iVar2 + 0xc4) = 0x3e32b564;
          FUN_0082e7f0((float)((uint)*(byte *)((int)fVar18 + 0xed) * 0x41));
          iVar2 = *(int *)((int)fVar18 + 0xf0);
          puStack_4c = (undefined *)0x40000000;
          *(undefined4 *)(iVar2 + 0xa0) = uStack_128;
          *(undefined4 *)(iVar2 + 0xa4) = uStack_124;
          *(undefined4 *)(iVar2 + 0xa8) = uStack_120;
          *(undefined4 *)(iVar2 + 0xac) = uStack_11c;
          *(undefined4 *)(iVar2 + 0x98) = 0;
          *(undefined8 *)(iVar2 + 0xb0) = uStack_118;
          puStack_50 = (undefined *)0x3f800000;
          FUN_0082e820(0x3f800000,0x40000000);
          iVar2 = *(int *)((int)fVar18 + 0xf0);
          fStack_34 = fStack_140 * _DAT_01900b00;
          fStack_30 = fStack_13c * _UNK_01900b04;
          fStack_2c = fStack_138 * _UNK_01900b08;
          fStack_28 = fStack_134 * _UNK_01900b0c;
          uStack_14 = 0xffffffff;
          *(float *)(iVar2 + 0x678) = fStack_34;
          *(float *)(iVar2 + 0x67c) = fStack_30;
          *(float *)(iVar2 + 0x680) = fStack_2c;
          *(float *)(iVar2 + 0x684) = fStack_28;
          *(undefined4 *)(*(int *)((int)fVar18 + 0xf0) + 0x66c) = 0;
          *(undefined4 *)(*(int *)((int)fVar18 + 0xf0) + 0x670) = 0x3ecccccd;
          FUN_005507b0();
        }
        if (*(char *)((int)fVar18 + 0xed) == '\0') {
LAB_0085009b:
          if (*(int *)((int)fVar18 + 0xf8) != 0) goto LAB_008500a8;
          goto LAB_0085186f;
        }
        if (*(int *)((int)fVar18 + 0xf8) == 0) {
          puStack_4c = (undefined *)FUN_01674e20(0x6a4);
          if (puStack_4c == (undefined *)0x0) {
            uVar15 = 0;
          }
          else {
            uStack_a4 = 0;
            uStack_a0 = 0xf;
            auStack_b4[0] = 0;
            uStack_8c = 0;
            uStack_88 = 0xf;
            uStack_9c = 0;
            uStack_74 = 0;
            uStack_70 = 0xf;
            uStack_84 = 0;
            uStack_24 = uStack_24 | 0x10;
            uStack_14 = 0x15;
            uVar15 = FUN_0082b6e0(*(undefined4 *)((int)fVar18 + 8),auStack_b4);
          }
          uStack_14 = 0x16;
          FUN_0084e660(uVar15);
          uStack_14 = 0xffffffff;
          if ((uStack_24 & 0x10) != 0) {
            FUN_00637950();
          }
          goto LAB_0085009b;
        }
LAB_008500a8:
        puStack_4c = (undefined *)(fStack_104 * DAT_018fde64);
        uStack_c4 = 0;
        uStack_c0 = 0xf;
        uStack_d4 = uStack_d4 & 0xffffff00;
        fStack_58 = (float)puStack_4c / DAT_0191a368;
        uStack_14 = 0x17;
        uStack_bc = 0;
        FUN_00551260("rbxasset://textures/particles/fire_sparks_main.dds");
        uStack_bc = 1;
        FUN_0082e7d0(&DAT_01eb4884);
        FUN_0082e2d0(&DAT_01eb4848,0);
        uStack_a4 = 0;
        uStack_a0 = 0xf;
        auStack_b4[0] = 0;
        uStack_8c = 0;
        uStack_88 = 0xf;
        uStack_9c = 0;
        uStack_74 = 0;
        uStack_70 = 0xf;
        uStack_84 = 0;
        uStack_14._0_1_ = 0x18;
        FUN_0082e340(&uStack_d4,auStack_b4);
        uStack_14 = CONCAT31(uStack_14._1_3_,0x17);
        FUN_00637950();
        uVar15 = (undefined4)uStack_48;
        *(undefined4 *)(*(int *)((int)fVar18 + 0xf8) + 0xe0) = 0x3ecccccd;
        iVar2 = *(int *)((int)fVar18 + 0xf8);
        fStack_28 = 0.0;
        *(ulonglong *)(iVar2 + 0xd4) = CONCAT44(uVar15,uVar15);
        fVar21 = fStack_104 * fStack_104 * DAT_018e1340;
        *(undefined4 *)(iVar2 + 0xdc) = 0;
        iVar2 = *(int *)((int)fVar18 + 0xf8);
        *(float *)(iVar2 + 0x104) = fStack_58;
        *(float *)(iVar2 + 0x108) = fStack_58;
        iVar2 = *(int *)((int)fVar18 + 0xf8);
        *(ulonglong *)(iVar2 + 200) =
             CONCAT44((fVar21 + fStack_60 * DAT_01901f3c) * DAT_018ce2f4,uVar15);
        *(undefined4 *)(iVar2 + 0xd0) = 0;
        iVar2 = *(int *)((int)fVar18 + 0xf8);
        *(undefined4 *)(iVar2 + 0xe4) = 0xbfc90c10;
        *(undefined4 *)(iVar2 + 0xe8) = 0x3fc90c10;
        iVar2 = *(int *)((int)fVar18 + 0xf8);
        *(undefined **)(iVar2 + 0xf4) = puStack_4c;
        *(undefined **)(iVar2 + 0xf8) = puStack_4c;
        iVar2 = *(int *)((int)fVar18 + 0xf8);
        *(undefined **)(iVar2 + 0xfc) = puStack_4c;
        *(undefined **)(iVar2 + 0x100) = puStack_4c;
        iVar2 = *(int *)((int)fVar18 + 0xf8);
        fVar21 = (fStack_104 * DAT_018e452c * fStack_104 + fStack_60 * DAT_018fabe0) * DAT_0191a25c;
        *(float *)(iVar2 + 0xb8) = fVar21;
        *(float *)(iVar2 + 0xbc) = fVar21;
        iVar2 = *(int *)((int)fVar18 + 0xf8);
        *(undefined4 *)(iVar2 + 0xec) = 0x3fdf62bd;
        *(undefined4 *)(iVar2 + 0xf0) = 0x3fdf62bd;
        iVar2 = *(int *)((int)fVar18 + 0xf8);
        *(undefined4 *)(iVar2 + 0xec) = 0xbfa78a0e;
        *(undefined4 *)(iVar2 + 0xf0) = 0x3fa78a0e;
        iVar2 = *(int *)((int)fVar18 + 0xf8);
        *(undefined4 *)(iVar2 + 0xc0) = 0x3e32b564;
        *(undefined4 *)(iVar2 + 0xc4) = 0x3e32b564;
        FUN_0082e7f0((float)((uint)*(byte *)((int)fVar18 + 0xed) * 0x41));
        iVar2 = *(int *)((int)fVar18 + 0xf8);
        fStack_104 = 3.0;
        *(undefined4 *)(iVar2 + 0xa0) = uStack_158;
        *(undefined4 *)(iVar2 + 0xa4) = uStack_154;
        *(undefined4 *)(iVar2 + 0xa8) = uStack_150;
        *(undefined4 *)(iVar2 + 0xac) = uStack_14c;
        *(undefined4 *)(iVar2 + 0x98) = 0;
        *(ulonglong *)(iVar2 + 0xb0) = CONCAT44(uStack_144,uStack_148);
        fStack_108 = 1.5;
        FUN_0082e820(0x3fc00000,0x40400000);
        fStack_30 = 0.0;
        fStack_28 = 0.0;
        fStack_2c = (fStack_60 * DAT_018fde58 + (float)puStack_4c) * DAT_018df580;
        puVar13 = (undefined4 *)FUN_00709da0(&fStack_30);
        fStack_30 = 0.0;
        fStack_2c = 0.0;
        fStack_28 = 0.0;
        uVar15 = puVar13[1];
        uVar24 = puVar13[2];
        uVar4 = puVar13[3];
        *(undefined4 *)((int)fVar18 + 0x138) = *puVar13;
        *(undefined4 *)((int)fVar18 + 0x13c) = uVar15;
        *(undefined4 *)((int)fVar18 + 0x140) = uVar24;
        *(undefined4 *)((int)fVar18 + 0x144) = uVar4;
        uVar15 = puVar13[5];
        uVar24 = puVar13[6];
        uVar4 = puVar13[7];
        *(undefined4 *)((int)fVar18 + 0x148) = puVar13[4];
        *(undefined4 *)((int)fVar18 + 0x14c) = uVar15;
        *(undefined4 *)((int)fVar18 + 0x150) = uVar24;
        *(undefined4 *)((int)fVar18 + 0x154) = uVar4;
        uVar15 = puVar13[9];
        uVar24 = puVar13[10];
        uVar4 = puVar13[0xb];
        *(undefined4 *)((int)fVar18 + 0x158) = puVar13[8];
        *(undefined4 *)((int)fVar18 + 0x15c) = uVar15;
        *(undefined4 *)((int)fVar18 + 0x160) = uVar24;
        *(undefined4 *)((int)fVar18 + 0x164) = uVar4;
        puVar13 = (undefined4 *)FUN_00709da0(&fStack_30);
        uVar15 = puVar13[1];
        uVar24 = puVar13[2];
        uVar4 = puVar13[3];
        *(undefined4 *)((int)fVar18 + 0x138) = *puVar13;
        *(undefined4 *)((int)fVar18 + 0x13c) = uVar15;
        *(undefined4 *)((int)fVar18 + 0x140) = uVar24;
        *(undefined4 *)((int)fVar18 + 0x144) = uVar4;
        uVar15 = puVar13[5];
        uVar24 = puVar13[6];
        uVar4 = puVar13[7];
        *(undefined4 *)((int)fVar18 + 0x148) = puVar13[4];
        *(undefined4 *)((int)fVar18 + 0x14c) = uVar15;
        *(undefined4 *)((int)fVar18 + 0x150) = uVar24;
        *(undefined4 *)((int)fVar18 + 0x154) = uVar4;
        uVar15 = puVar13[9];
        uVar24 = puVar13[10];
        uVar4 = puVar13[0xb];
        iVar2 = *(int *)((int)fVar18 + 0xf8);
        *(undefined4 *)((int)fVar18 + 0x158) = puVar13[8];
        *(undefined4 *)((int)fVar18 + 0x15c) = uVar15;
        *(undefined4 *)((int)fVar18 + 0x160) = uVar24;
        *(undefined4 *)((int)fVar18 + 0x164) = uVar4;
        *(undefined4 *)(iVar2 + 0x678) = uStack_19c;
        *(undefined4 *)(iVar2 + 0x67c) = uStack_198;
        *(undefined4 *)(iVar2 + 0x680) = uStack_194;
        *(undefined4 *)(iVar2 + 0x684) = uStack_190;
        *(undefined4 *)(*(int *)((int)fVar18 + 0xf8) + 0x66c) = 0x3f800000;
      }
LAB_0085185d:
      uStack_14 = 0xffffffff;
      FUN_005507b0();
    }
    else {
      cVar1 = *(char *)(iVar17 + 0x58);
      *(char *)((int)fStack_58 + 0xed) = cVar1;
      if (cVar1 != '\0') {
        if (*(int *)((int)fStack_58 + 0xf0) == 0) {
          puStack_4c = (undefined *)FUN_01674e20(0x6a4);
          if (puStack_4c == (undefined *)0x0) {
            uVar15 = 0;
          }
          else {
            uStack_f0 = 0;
            uStack_ec = 0xf;
            auStack_100[0] = 0;
            uStack_d8 = 0;
            uStack_d4 = 0xf;
            uStack_e8 = 0;
            uStack_c0 = 0;
            uStack_bc = CONCAT44(uStack_bc._4_4_,0xf);
            uStack_d0 = 0;
            uStack_24 = 4;
            uStack_14 = 0xb;
            uVar15 = FUN_0082b6e0(*(undefined4 *)((int)fVar18 + 8),auStack_100);
          }
          uStack_14 = 0xc;
          FUN_0084e660(uVar15);
          uStack_14 = 0xffffffff;
          if ((uStack_24 & 4) != 0) {
            FUN_00637950();
          }
          goto LAB_0084f5f6;
        }
LAB_0084f603:
        fVar20 = (float10)FUN_00d76880();
        fStack_60 = (float)fVar20;
        fStack_104 = fStack_60 + DAT_018fde94;
        fVar20 = (float10)FUN_00d76850();
        fStack_58 = (float)fVar20;
        fVar20 = (float10)FUN_00d76820();
        uVar22 = *(undefined8 *)(iVar17 + 0x5c);
        fStack_40 = *(float *)(iVar17 + 100);
        uStack_48._0_4_ = (float)uVar22;
        fStack_34 = (float)uStack_48;
        uStack_48._4_4_ = (float)((ulonglong)uVar22 >> 0x20);
        fStack_30 = uStack_48._4_4_;
        puStack_4c = (undefined *)(float)fVar20;
        uStack_48 = uVar22;
        fStack_2c = fStack_40;
        fStack_28 = (float)puStack_4c;
        FUN_01165750(&fStack_34);
        fStack_40 = *(float *)(iVar17 + 100);
        uStack_48._0_4_ = (float)*(undefined8 *)(iVar17 + 0x5c);
        fStack_34 = (float)uStack_48;
        uStack_48._4_4_ = (float)((ulonglong)*(undefined8 *)(iVar17 + 0x5c) >> 0x20);
        fStack_30 = uStack_48._4_4_;
        uStack_48 = 0;
        fStack_28 = 0.0;
        fStack_2c = fStack_40;
        FUN_01165750(&fStack_34);
        uStack_c4 = 0;
        uStack_c0 = 0xf;
        uStack_d4 = uStack_d4 & 0xffffff00;
        uStack_14 = 0xd;
        uStack_bc = 0;
        FUN_00551260("rbxasset://textures/particles/smoke_main.dds");
        uStack_bc = 0x100000003;
        FUN_0082e7d0(&DAT_01eb48c0);
        FUN_0082e2d0(&DAT_01eb4848,0);
        uStack_17c = 0;
        uStack_178 = 0xf;
        auStack_18c[0] = 0;
        uStack_164 = 0;
        uStack_160 = 0xf;
        uStack_174 = 0;
        uStack_14c = 0;
        uStack_148 = 0xf;
        uStack_15c = 0;
        uStack_14._0_1_ = 0xe;
        FUN_0082e340(&uStack_d4,auStack_18c);
        uStack_14 = CONCAT31(uStack_14._1_3_,0xd);
        FUN_00637950();
        uVar15 = (undefined4)uStack_48;
        *(undefined4 *)(*(int *)((int)fVar18 + 0xf0) + 0xe0) = 0x3dcccccd;
        iVar2 = *(int *)((int)fVar18 + 0xf0);
        *(ulonglong *)(iVar2 + 0xd4) = CONCAT44(uVar15,uVar15);
        *(undefined4 *)(iVar2 + 0xdc) = 0x3ecccccd;
        iVar2 = *(int *)((int)fVar18 + 0xf0);
        fStack_28 = 0.0;
        fVar21 = (fStack_104 - fStack_60) / DAT_018e3f90;
        *(float *)(iVar2 + 0x104) = fVar21;
        *(float *)(iVar2 + 0x108) = fVar21;
        iVar2 = *(int *)((int)fVar18 + 0xf0);
        *(ulonglong *)(iVar2 + 200) = CONCAT44(uVar15,uVar15);
        *(undefined4 *)(iVar2 + 0xd0) = 0;
        iVar2 = *(int *)((int)fVar18 + 0xf0);
        fVar21 = fStack_58 * DAT_0190193c;
        *(undefined4 *)(iVar2 + 0xe4) = 0xbfc90c10;
        *(undefined4 *)(iVar2 + 0xe8) = 0x3fc90c10;
        iVar2 = *(int *)((int)fVar18 + 0xf0);
        *(float *)(iVar2 + 0xf4) = fStack_60;
        *(float *)(iVar2 + 0xf8) = fStack_60;
        iVar2 = *(int *)((int)fVar18 + 0xf0);
        *(float *)(iVar2 + 0xfc) = fStack_60;
        *(float *)(iVar2 + 0x100) = fStack_60;
        iVar2 = *(int *)((int)fVar18 + 0xf0);
        *(float *)(iVar2 + 0xb8) = fVar21;
        *(float *)(iVar2 + 0xbc) = fStack_58;
        iVar2 = *(int *)((int)fVar18 + 0xf0);
        *(undefined4 *)(iVar2 + 0xec) = 0xbeb2b564;
        *(undefined4 *)(iVar2 + 0xf0) = 0x3eb2b564;
        iVar2 = *(int *)((int)fVar18 + 0xf0);
        *(undefined4 *)(iVar2 + 0xc0) = 0x3f06080b;
        *(undefined4 *)(iVar2 + 0xc4) = 0x3f06080b;
        FUN_0082e7f0((float)((uint)*(byte *)((int)fVar18 + 0xed) * 7));
        iVar2 = *(int *)((int)fVar18 + 0xf0);
        uStack_48 = 0x3f8000003f800000;
        fStack_40 = 1.0;
        puStack_54 = &DAT_bf800000;
        puStack_50 = &DAT_bf800000;
        puStack_4c = &DAT_bf800000;
        puVar13 = (undefined4 *)FUN_00709d10(&puStack_54,&uStack_48);
        puStack_4c = (undefined *)0x40a00000;
        puStack_50 = (undefined *)0x40a00000;
        uVar15 = puVar13[1];
        uVar24 = puVar13[2];
        uVar4 = puVar13[3];
        uVar22 = *(undefined8 *)(puVar13 + 4);
        *(undefined4 *)(iVar2 + 0xa0) = *puVar13;
        *(undefined4 *)(iVar2 + 0xa4) = uVar15;
        *(undefined4 *)(iVar2 + 0xa8) = uVar24;
        *(undefined4 *)(iVar2 + 0xac) = uVar4;
        *(undefined4 *)(iVar2 + 0x98) = 0;
        *(undefined8 *)(iVar2 + 0xb0) = uVar22;
        FUN_0082e820(0x40a00000,0x40a00000);
        iVar2 = *(int *)((int)fVar18 + 0xf0);
        *(float *)(iVar2 + 0x678) = fStack_140;
        *(float *)(iVar2 + 0x67c) = fStack_13c;
        *(float *)(iVar2 + 0x680) = fStack_138;
        *(float *)(iVar2 + 0x684) = fStack_134;
        *(undefined4 *)(*(int *)((int)fVar18 + 0xf0) + 0x674) = 0x3f800000;
        goto LAB_0085185d;
      }
LAB_0084f5f6:
      if (*(int *)((int)fVar18 + 0xf0) != 0) goto LAB_0084f603;
    }
LAB_0085186f:
    FUN_0058a2b0();
    goto LAB_0085187a;
  }
  cVar1 = *(char *)(iVar17 + 0x58);
  *(char *)((int)fStack_58 + 0xed) = cVar1;
  uVar22 = *(undefined8 *)(iVar17 + 0x5c);
  fStack_108 = *(float *)(iVar17 + 100);
  uStack_48._0_4_ = (float)uVar22;
  uStack_110 = (float)uStack_48;
  uStack_48._4_4_ = (float)((ulonglong)uVar22 >> 0x20);
  uStack_10c = uStack_48._4_4_;
  fStack_104 = 0.9;
  uStack_48 = uVar22;
  fStack_40 = fStack_108;
  if (cVar1 == '\0') {
LAB_0084eda2:
    bVar19 = *(int *)((int)fVar18 + 0xf0) == 0;
  }
  else {
    bVar19 = *(int *)((int)fStack_58 + 0xf0) == 0;
    if (bVar19) {
      puStack_4c = (undefined *)FUN_01674e20(0x6a4);
      if (puStack_4c == (undefined *)0x0) {
        uVar15 = 0;
      }
      else {
        uStack_f0 = 0;
        uStack_ec = 0xf;
        auStack_100[0] = 0;
        uStack_d8 = 0;
        uStack_d4 = 0xf;
        uStack_e8 = 0;
        uStack_c0 = 0;
        uStack_bc = CONCAT44(uStack_bc._4_4_,0xf);
        uStack_d0 = 0;
        uStack_24 = 1;
        uStack_14 = 1;
        uVar15 = FUN_0082b6e0(*(undefined4 *)((int)fVar18 + 8),auStack_100);
      }
      uStack_14 = 2;
      FUN_0084e660(uVar15);
      uStack_14 = 0xffffffff;
      if ((uStack_24 & 1) != 0) {
        uStack_24 = uStack_24 & 0xfffffffe;
        FUN_00637950();
      }
      goto LAB_0084eda2;
    }
  }
  uStack_68 = 0;
  if (!bVar19) {
    uStack_120 = 0;
    uStack_11c = 0xf;
    auStack_130[0] = 0;
    uStack_14 = 3;
    uStack_118 = 0;
    FUN_00551260("rbxasset://textures/particles/sparkles_main.dds");
    uStack_118 = 0x300000004;
    FUN_0082e7d0(&DAT_01eb48cc);
    FUN_0082e2d0(&DAT_01eb4848,0);
    uStack_f0 = 0;
    uStack_ec = 0xf;
    auStack_100[0] = 0;
    uStack_d8 = 0;
    uStack_d4 = 0xf;
    uStack_e8 = 0;
    uStack_c0 = 0;
    uStack_bc = CONCAT44(uStack_bc._4_4_,0xf);
    uStack_d0 = 0;
    uStack_14._0_1_ = 4;
    FUN_0082e340(auStack_130,auStack_100);
    uStack_14 = CONCAT31(uStack_14._1_3_,3);
    FUN_00637950();
    uVar15 = DAT_018ce2f8;
    uVar24 = (undefined4)uStack_68;
    *(undefined4 *)(*(int *)((int)fVar18 + 0xf0) + 0xe0) = 0x3e4ccccd;
    iVar2 = *(int *)((int)fVar18 + 0xf0);
    fStack_28 = 0.0;
    *(ulonglong *)(iVar2 + 0xd4) = CONCAT44(uVar24,uVar24);
    *(undefined4 *)(iVar2 + 0xdc) = 0;
    iVar2 = *(int *)((int)fVar18 + 0xf0);
    *(undefined4 *)(iVar2 + 0x104) = 0x3f000000;
    *(undefined4 *)(iVar2 + 0x108) = 0x3f000000;
    iVar2 = *(int *)((int)fVar18 + 0xf0);
    *(ulonglong *)(iVar2 + 200) = CONCAT44(uVar15,uVar24);
    *(undefined4 *)(iVar2 + 0xd0) = 0;
    iVar2 = *(int *)((int)fVar18 + 0xf0);
    *(undefined4 *)(iVar2 + 0xe4) = 0xbfc90c10;
    *(undefined4 *)(iVar2 + 0xe8) = 0x3fc90c10;
    iVar2 = *(int *)((int)fVar18 + 0xf0);
    *(undefined4 *)(iVar2 + 0xf4) = 0x3ebd70a4;
    *(undefined4 *)(iVar2 + 0xf8) = 0x3ebd70a4;
    iVar2 = *(int *)((int)fVar18 + 0xf0);
    *(undefined4 *)(iVar2 + 0xfc) = 0x3ebd70a4;
    *(undefined4 *)(iVar2 + 0x100) = 0x3ebd70a4;
    iVar2 = *(int *)((int)fVar18 + 0xf0);
    *(undefined4 *)(iVar2 + 0xb8) = 0x40a00000;
    *(undefined4 *)(iVar2 + 0xbc) = 0x40a00000;
    iVar2 = *(int *)((int)fVar18 + 0xf0);
    *(undefined4 *)(iVar2 + 0xec) = 0x3f32b564;
    *(undefined4 *)(iVar2 + 0xf0) = 0x3fdf62bd;
    iVar2 = *(int *)((int)fVar18 + 0xf0);
    *(undefined4 *)(iVar2 + 0xc0) = 0x3fdf62bd;
    *(undefined4 *)(iVar2 + 0xc4) = 0x3fdf62bd;
    FUN_0082e7f0((float)((uint)*(byte *)((int)fVar18 + 0xed) * 0x1e));
    iVar2 = *(int *)((int)fVar18 + 0xf0);
    uStack_48 = 0x3e4ccccd3e4ccccd;
    fStack_40 = 0.2;
    puStack_54 = (undefined *)0xbe4ccccd;
    puStack_50 = (undefined *)0xbe4ccccd;
    puStack_4c = (undefined *)0xbe4ccccd;
    puVar13 = (undefined4 *)FUN_00709d10(&puStack_54,&uStack_48);
    puStack_4c = (undefined *)0x3fa66666;
    puStack_50 = (undefined *)0x3fa66666;
    uVar15 = puVar13[1];
    uVar24 = puVar13[2];
    uVar4 = puVar13[3];
    uVar22 = *(undefined8 *)(puVar13 + 4);
    *(undefined4 *)(iVar2 + 0xa0) = *puVar13;
    *(undefined4 *)(iVar2 + 0xa4) = uVar15;
    *(undefined4 *)(iVar2 + 0xa8) = uVar24;
    *(undefined4 *)(iVar2 + 0xac) = uVar4;
    *(undefined4 *)(iVar2 + 0x98) = 0;
    *(undefined8 *)(iVar2 + 0xb0) = uVar22;
    FUN_0082e820(0x3fa66666,0x3fa66666);
    iVar2 = *(int *)((int)fVar18 + 0xf0);
    uStack_14 = 0xffffffff;
    *(undefined4 *)(iVar2 + 0x678) = uStack_110;
    *(undefined4 *)(iVar2 + 0x67c) = uStack_10c;
    *(float *)(iVar2 + 0x680) = fStack_108;
    *(float *)(iVar2 + 0x684) = fStack_104;
    *(undefined4 *)(*(int *)((int)fVar18 + 0xf0) + 0x670) = 0x3f19999a;
    FUN_005507b0();
  }
  if (*(char *)((int)fVar18 + 0xed) == '\0') {
LAB_0084f16e:
    if (*(int *)((int)fVar18 + 0xf8) != 0) goto LAB_0084f17b;
  }
  else {
    if (*(int *)((int)fVar18 + 0xf8) == 0) {
      puStack_4c = (undefined *)FUN_01674e20(0x6a4);
      if (puStack_4c == (undefined *)0x0) {
        uVar15 = 0;
      }
      else {
        uStack_f0 = 0;
        uStack_ec = 0xf;
        auStack_100[0] = 0;
        uStack_d8 = 0;
        uStack_d4 = 0xf;
        uStack_e8 = 0;
        uStack_c0 = 0;
        uStack_bc = CONCAT44(uStack_bc._4_4_,0xf);
        uStack_d0 = 0;
        uStack_24 = uStack_24 | 2;
        uStack_14 = 6;
        uVar15 = FUN_0082b6e0(*(undefined4 *)((int)fVar18 + 8),auStack_100);
      }
      uStack_14 = 7;
      FUN_0084e660(uVar15);
      uStack_14 = 0xffffffff;
      if ((uStack_24 & 2) != 0) {
        FUN_00637950();
      }
      goto LAB_0084f16e;
    }
LAB_0084f17b:
    uStack_120 = 0;
    uStack_11c = 0xf;
    auStack_130[0] = 0;
    uStack_14 = 8;
    uStack_118 = 0;
    FUN_00551260("rbxasset://textures/particles/sparkles_main.dds");
    uStack_118 = 0x300000004;
    FUN_0082e7d0(&DAT_01eb48cc);
    FUN_0082e2d0(&DAT_01eb4848,0);
    uStack_f0 = 0;
    uStack_ec = 0xf;
    auStack_100[0] = 0;
    uStack_d8 = 0;
    uStack_d4 = 0xf;
    uStack_e8 = 0;
    uStack_c0 = 0;
    uStack_bc = CONCAT44(uStack_bc._4_4_,0xf);
    uStack_d0 = 0;
    uStack_14._0_1_ = 9;
    FUN_0082e340(auStack_130,auStack_100);
    uStack_14 = CONCAT31(uStack_14._1_3_,8);
    FUN_00637950();
    uVar15 = (undefined4)uStack_68;
    *(undefined4 *)(*(int *)((int)fVar18 + 0xf8) + 0xe0) = 0x40000000;
    iVar2 = *(int *)((int)fVar18 + 0xf8);
    fStack_28 = 0.0;
    *(ulonglong *)(iVar2 + 0xd4) = CONCAT44(uVar15,uVar15);
    *(undefined4 *)(iVar2 + 0xdc) = 0;
    iVar2 = *(int *)((int)fVar18 + 0xf8);
    uStack_48 = 0x4080000000000000;
    fStack_40 = 0.0;
    *(undefined4 *)(iVar2 + 0x104) = 0x3e4ccccd;
    *(undefined4 *)(iVar2 + 0x108) = 0x3e4ccccd;
    iVar2 = *(int *)((int)fVar18 + 0xf8);
    *(ulonglong *)(iVar2 + 200) = CONCAT44(uVar15,uVar15);
    *(undefined4 *)(iVar2 + 0xd0) = 0;
    iVar2 = *(int *)((int)fVar18 + 0xf8);
    *(undefined4 *)(iVar2 + 0xe4) = 0xbfc90c10;
    *(undefined4 *)(iVar2 + 0xe8) = 0x3fc90c10;
    iVar2 = *(int *)((int)fVar18 + 0xf8);
    *(undefined4 *)(iVar2 + 0xf4) = 0x3dcccccd;
    *(undefined4 *)(iVar2 + 0xf8) = 0x3dcccccd;
    iVar2 = *(int *)((int)fVar18 + 0xf8);
    *(undefined4 *)(iVar2 + 0xfc) = 0x3dcccccd;
    *(undefined4 *)(iVar2 + 0x100) = 0x3dcccccd;
    iVar2 = *(int *)((int)fVar18 + 0xf8);
    *(undefined4 *)(iVar2 + 0xb8) = 0x41000000;
    *(undefined4 *)(iVar2 + 0xbc) = 0x41000000;
    iVar2 = *(int *)((int)fVar18 + 0xf8);
    *(undefined4 *)(iVar2 + 0xec) = 0xc10b9db6;
    *(undefined4 *)(iVar2 + 0xf0) = 0x410b9db6;
    iVar2 = *(int *)((int)fVar18 + 0xf8);
    *(undefined4 *)(iVar2 + 0xc0) = 0x40278a0e;
    *(undefined4 *)(iVar2 + 0xc4) = 0x40278a0e;
    puVar13 = (undefined4 *)FUN_00709da0(&uStack_48);
    uVar15 = puVar13[1];
    uVar24 = puVar13[2];
    uVar4 = puVar13[3];
    *(undefined4 *)((int)fVar18 + 0x138) = *puVar13;
    *(undefined4 *)((int)fVar18 + 0x13c) = uVar15;
    *(undefined4 *)((int)fVar18 + 0x140) = uVar24;
    *(undefined4 *)((int)fVar18 + 0x144) = uVar4;
    uVar15 = puVar13[5];
    uVar24 = puVar13[6];
    uVar4 = puVar13[7];
    *(undefined4 *)((int)fVar18 + 0x148) = puVar13[4];
    *(undefined4 *)((int)fVar18 + 0x14c) = uVar15;
    *(undefined4 *)((int)fVar18 + 0x150) = uVar24;
    *(undefined4 *)((int)fVar18 + 0x154) = uVar4;
    uVar15 = puVar13[9];
    uVar24 = puVar13[10];
    uVar4 = puVar13[0xb];
    *(undefined4 *)((int)fVar18 + 0x158) = puVar13[8];
    *(undefined4 *)((int)fVar18 + 0x15c) = uVar15;
    *(undefined4 *)((int)fVar18 + 0x160) = uVar24;
    *(undefined4 *)((int)fVar18 + 0x164) = uVar4;
    FUN_0082e7f0((float)((uint)*(byte *)((int)fVar18 + 0xed) * 5));
    iVar2 = *(int *)((int)fVar18 + 0xf8);
    uStack_48 = 0x3e4ccccd3e4ccccd;
    fStack_40 = 0.2;
    puStack_54 = (undefined *)0xbe4ccccd;
    puStack_50 = (undefined *)0xbe4ccccd;
    puStack_4c = (undefined *)0xbe4ccccd;
    puVar13 = (undefined4 *)FUN_00709d10(&puStack_54,&uStack_48);
    puStack_4c = (undefined *)0x3fd9999a;
    puStack_50 = (undefined *)0x3fd9999a;
    uVar15 = puVar13[1];
    uVar24 = puVar13[2];
    uVar4 = puVar13[3];
    uVar22 = *(undefined8 *)(puVar13 + 4);
    *(undefined4 *)(iVar2 + 0xa0) = *puVar13;
    *(undefined4 *)(iVar2 + 0xa4) = uVar15;
    *(undefined4 *)(iVar2 + 0xa8) = uVar24;
    *(undefined4 *)(iVar2 + 0xac) = uVar4;
    *(undefined4 *)(iVar2 + 0x98) = 0;
    *(undefined8 *)(iVar2 + 0xb0) = uVar22;
    FUN_0082e820(0x3fd9999a,0x3fd9999a);
    iVar2 = *(int *)((int)fVar18 + 0xf8);
    uStack_14 = 0xffffffff;
    *(undefined4 *)(iVar2 + 0x678) = uStack_110;
    *(undefined4 *)(iVar2 + 0x67c) = uStack_10c;
    *(float *)(iVar2 + 0x680) = fStack_108;
    *(float *)(iVar2 + 0x684) = fStack_104;
    *(undefined4 *)(*(int *)((int)fVar18 + 0xf8) + 0x670) = 0x3f19999a;
    FUN_005507b0();
  }
  *(undefined4 *)((int)fVar18 + 0x100) = 0;
  piVar3 = *(int **)((int)fVar18 + 0x104);
  *(undefined4 *)((int)fVar18 + 0x104) = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
LAB_0085187a:
  puVar13 = (undefined4 *)FUN_005c4650();
  uVar15 = puVar13[1];
  uVar24 = puVar13[2];
  uVar4 = puVar13[3];
  *(undefined4 *)((int)fVar18 + 0xd4) = *puVar13;
  *(undefined4 *)((int)fVar18 + 0xd8) = uVar15;
  *(undefined4 *)((int)fVar18 + 0xdc) = uVar24;
  *(undefined4 *)((int)fVar18 + 0xe0) = uVar4;
  *(undefined8 *)((int)fVar18 + 0xe4) = *(undefined8 *)(puVar13 + 4);
  if (*(int *)((int)fVar18 + 0xf0) != 0) {
    uVar15 = FUN_0082c950(&uStack_158);
    FUN_007b4260(uVar15);
  }
  if (*(int *)((int)fVar18 + 0xf8) != 0) {
    uVar15 = FUN_0082c950(&uStack_158);
    FUN_007b4260(uVar15);
  }
  if (*(int *)((int)fVar18 + 0x100) != 0) {
    uVar15 = FUN_0082c950(&uStack_128);
    FUN_007b4260(uVar15);
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 13023 ; VA 0x00851920 ; FUN_00851920 */

void __thiscall FUN_00851920(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  bool bVar5;
  undefined4 uStack_24;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7c22;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  iVar3 = param_2[1];
  ExceptionList = &pvStack_10;
  if (iVar3 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
    UNLOCK();
    iVar3 = param_2[1];
  }
  *(int *)(param_1 + 0x94) = *param_2;
  piVar1 = *(int **)(param_1 + 0x98);
  *(int *)(param_1 + 0x98) = iVar3;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  iVar3 = param_3[1];
  if (iVar3 != 0) {
    LOCK();
    *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
    UNLOCK();
    iVar3 = param_3[1];
  }
  *(int *)(param_1 + 0x9c) = *param_3;
  piVar1 = *(int **)(param_1 + 0xa0);
  *(int *)(param_1 + 0xa0) = iVar3;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  puStack_18 = (undefined4 *)(*param_3 + 0x50);
  iStack_8 = 0;
  uVar2 = FUN_01675290(DAT_02110da8);
  iStack_8._0_1_ = 1;
  param_3 = (int *)FUN_01674e20(0x28);
  if (param_3 == (undefined4 *)0x0) {
    param_3 = (undefined4 *)0x0;
  }
  else {
    *param_3 = 0;
    param_3[1] = 1;
    param_3[2] = (int)FUN_00819150;
    param_3[3] = (int)_guard_check_icall;
    param_3[4] = 0;
    param_3[5] = (int)puStack_18;
    param_3[6] = (int)FUN_00851ef0;
    param_3[7] = 0;
    param_3[8] = param_1;
    param_3[9] = uStack_24;
  }
  FUN_016797d0(param_3);
  puStack_1c = param_3;
  if (param_3 != (undefined4 *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_14 = 1;
  iStack_8._0_1_ = 2;
  FUN_01675290(uVar2);
  puVar4 = *(undefined4 **)(param_1 + 0x84);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (*(undefined4 **)(param_1 + 0x88) == puVar4) {
    FUN_006335f0(puVar4,&puStack_1c);
    puVar4 = puStack_1c;
  }
  else {
    *puVar4 = param_3;
    *(int *)(param_1 + 0x84) = *(int *)(param_1 + 0x84) + 4;
    puVar4 = (undefined4 *)0x0;
  }
  uStack_14 = 0;
  iStack_8 = 0xffffffff;
  if (puVar4 != (undefined4 *)0x0) {
    piVar1 = puVar4 + 1;
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(puVar4);
    }
  }
  if (*param_2 != 0) {
    iVar3 = FUN_008a4100();
    puStack_1c = (undefined4 *)(iVar3 + 0x80);
    iStack_8 = 3;
    uVar2 = FUN_01675290(DAT_02110da8);
    iStack_8._0_1_ = 4;
    param_3 = (int *)FUN_01674e20(0x28);
    if (param_3 == (undefined4 *)0x0) {
      param_3 = (undefined4 *)0x0;
    }
    else {
      *param_3 = 0;
      param_3[1] = 1;
      param_3[2] = (int)FUN_00838650;
      param_3[3] = (int)_guard_check_icall;
      param_3[4] = 0;
      param_3[5] = (int)puStack_1c;
      param_3[6] = (int)FUN_00851fd0;
      param_3[7] = 0;
      param_3[8] = param_1;
      param_3[9] = uStack_24;
    }
    FUN_016797d0(param_3);
    puStack_18 = param_3;
    if (param_3 != (undefined4 *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    uStack_14 = 2;
    iStack_8._0_1_ = 5;
    FUN_01675290(uVar2);
    puVar4 = *(undefined4 **)(param_1 + 0x84);
    iStack_8 = CONCAT31(iStack_8._1_3_,3);
    if (*(undefined4 **)(param_1 + 0x88) == puVar4) {
      FUN_006335f0(puVar4,&puStack_18);
      puVar4 = puStack_18;
    }
    else {
      *puVar4 = param_3;
      *(int *)(param_1 + 0x84) = *(int *)(param_1 + 0x84) + 4;
      puVar4 = (undefined4 *)0x0;
    }
    iStack_8 = 0xffffffff;
    if (puVar4 != (undefined4 *)0x0) {
      piVar1 = puVar4 + 1;
      LOCK();
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        FUN_01674ea0(puVar4);
      }
    }
    if (DAT_01d6866c == '\0') {
      bVar5 = *(int *)(*param_2 + 0x70) == 0;
    }
    else {
      bVar5 = *(int *)(*param_2 + 0x6c) == -1;
    }
    if (bVar5) {
      FUN_007c7a50(-(uint)(param_1 != 0) & param_1 + 0x74U,1);
    }
    else {
      FUN_007c7840(-(uint)(param_1 != 0) & param_1 + 0x74U,1);
    }
  }
  (**(code **)(*(int *)(param_1 + 0x74) + 8))();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13024 ; VA 0x00851c70 ; FUN_00851c70 */

int __thiscall FUN_00851c70(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 *puVar9;
  undefined4 uStack_30;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 *puStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7c59;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  iVar8 = *(int *)(*param_2 + 0x34);
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (((iVar8 == 0) ||
      (iVar2 = *(int *)(iVar8 + 0xc), ExceptionList = &pvStack_10, iVar4 = FUN_00aff8c0(),
      iVar5 = iVar8,
      (uint)*(ushort *)(iVar4 + 0x1da) <
      (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) &&
     (iVar5 = 0, iVar8 != 0)) {
    iVar2 = *(int *)(iVar8 + 0xc);
    iVar5 = FUN_00d6bbd0();
    if ((uint)*(ushort *)(iVar5 + 0x1da) <
        (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) {
      iVar5 = 0;
    }
    else {
      iStack_18 = *(int *)(iVar8 + 0x34);
      if ((iStack_18 == 0) ||
         (iVar2 = *(int *)(iStack_18 + 0xc), iVar5 = FUN_00aff8c0(),
         (uint)*(ushort *)(iVar5 + 0x1da) <
         (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
        iStack_18 = 0;
      }
      iVar2 = iStack_14;
      iStack_1c = iVar8 + 0x4c;
      iStack_8 = 0;
      piVar6 = (int *)FUN_01675290(DAT_02110da8);
      iStack_8._0_1_ = 1;
      piStack_28 = piVar6;
      puStack_20 = (undefined4 *)FUN_01674e20(0x28);
      if (puStack_20 == (undefined4 *)0x0) {
        puVar9 = (undefined4 *)0x0;
      }
      else {
        *puStack_20 = 0;
        puStack_20[1] = 1;
        puStack_20[2] = FUN_00838650;
        puStack_20[3] = _guard_check_icall;
        puStack_20[4] = 0;
        puStack_20[5] = iStack_1c;
        puStack_20[6] = &LAB_00851fc0;
        puStack_20[7] = 0;
        puStack_20[8] = iVar2;
        puStack_20[9] = uStack_30;
        puVar9 = puStack_20;
      }
      FUN_016797d0(puVar9);
      if (puVar9 != (undefined4 *)0x0) {
        LOCK();
        puVar9[1] = puVar9[1] + 1;
        UNLOCK();
      }
      uStack_24 = 1;
      iStack_8._0_1_ = 2;
      puStack_20 = puVar9;
      FUN_01675290(piVar6);
      puVar3 = *(undefined4 **)(iStack_14 + 0x84);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (*(undefined4 **)(iStack_14 + 0x88) == puVar3) {
        FUN_006335f0(puVar3,&puStack_20);
        puVar9 = puStack_20;
      }
      else {
        *puVar3 = puVar9;
        *(int *)(iStack_14 + 0x84) = *(int *)(iStack_14 + 0x84) + 4;
        puVar9 = (undefined4 *)0x0;
      }
      iStack_8 = 0xffffffff;
      iVar5 = iStack_18;
      if (puVar9 != (undefined4 *)0x0) {
        piVar6 = puVar9 + 1;
        LOCK();
        iVar8 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar8 == 1) {
          FUN_01674ea0(puVar9);
          iVar5 = iStack_18;
        }
      }
    }
  }
  uVar7 = FUN_0060dcd0(auStack_2c,iVar5);
  iStack_8 = 3;
  iVar8 = FUN_00851920(uVar7,param_2);
  piVar6 = piStack_28;
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_28 + 1;
    iVar2 = *piVar1;
    iVar8 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar8 = (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar8 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar8;
}



/* FUNCTION 13025 ; VA 0x00851ea0 ; FUN_00851ea0 */

void __thiscall FUN_00851ea0(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x70);
  *param_2 = *(undefined8 *)(param_1 + 0x68);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 13026 ; VA 0x00851ec0 ; FUN_00851ec0 */

void __fastcall FUN_00851ec0(int param_1)

{
  if (*(char *)(param_1 + 0x78) == '\0') {
    *(undefined *)(param_1 + 0x78) = 1;
    if (param_1 == 0x74) {
      param_1 = 0;
    }
    FUN_007c8ce0(param_1);
  }
  return;
}



/* FUNCTION 13027 ; VA 0x00851ef0 ; FUN_00851ef0 */

int __thiscall FUN_00851ef0(int param_1,int param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  if (param_2 == 2) {
    ExceptionList = &pvStack_10;
    iVar3 = (**(code **)(*(int *)(param_1 + 0x74) + 8))();
    ExceptionList = pvStack_10;
    return iVar3;
  }
  param_2 = param_2 + -5;
  if (param_2 == 0) {
    piVar4 = *(int **)(param_1 + 0xa0);
    ExceptionList = &pvStack_10;
    if (piVar4 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = *(int **)(param_1 + 0xa0);
    }
    uStack_18 = *(undefined4 *)(param_1 + 0x9c);
    uStack_8 = 0;
    piStack_14 = piVar4;
    cVar2 = FUN_011584d0(uStack_18);
    if (cVar2 == '\0') {
      param_2 = (**(code **)(*(int *)(param_1 + 0x74) + 4))();
    }
    else {
      (**(code **)(*(int *)(param_1 + 0x74) + 0x40))();
      param_2 = FUN_00851c70(&uStack_18);
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar1 = piVar4 + 1;
      iVar3 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 13028 ; VA 0x00851fd0 ; FUN_00851fd0 */

void __thiscall FUN_00851fd0(int param_1,char param_2)

{
  int iVar1;
  
  iVar1 = param_1 + 0x74;
  if (param_2 != '\0') {
    if (param_1 == 0) {
      iVar1 = 0;
    }
    FUN_007c7a50(iVar1,1);
    return;
  }
  if (param_1 == 0) {
    iVar1 = 0;
  }
  FUN_007c7840(iVar1,1);
  return;
}



/* FUNCTION 13029 ; VA 0x00852010 ; FUN_00852010 */

int __fastcall FUN_00852010(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_011590c0();
  *(undefined4 *)(param_1 + 0x20) = 0;
  piVar3 = *(int **)(param_1 + 0x24);
  *(undefined4 *)(param_1 + 0x24) = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  *(undefined4 *)(param_1 + 0x28) = 0;
  piVar3 = *(int **)(param_1 + 0x2c);
  *(undefined4 *)(param_1 + 0x2c) = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00852084. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar4 = (**(code **)(*piVar3 + 4))();
        return iVar4;
      }
    }
  }
  return iVar4;
}



/* FUNCTION 13030 ; VA 0x00852090 ; FUN_00852090 */

void __fastcall FUN_00852090(int param_1)

{
  int iVar1;
  float fVar2;
  undefined8 uStack_28;
  float fStack_20;
  undefined8 uStack_1c;
  float fStack_14;
  float fStack_8;
  
  FUN_00c9f550(&uStack_28,param_1 + 0xa4);
  iVar1 = *(int *)(param_1 + 0xf0);
  if (iVar1 != 0) {
    if (*(float *)(iVar1 + 0x694) <= fStack_20) {
      fStack_20 = *(float *)(iVar1 + 0x694);
    }
    fVar2 = uStack_28._4_4_;
    if (*(float *)(iVar1 + 0x690) <= uStack_28._4_4_) {
      fVar2 = *(float *)(iVar1 + 0x690);
    }
    if (*(float *)(iVar1 + 0x68c) <= (float)uStack_28) {
      uStack_28._0_4_ = *(float *)(iVar1 + 0x68c);
    }
    uStack_28 = CONCAT44(fVar2,(float)uStack_28);
    if (fStack_14 <= *(float *)(iVar1 + 0x6a0)) {
      fStack_14 = *(float *)(iVar1 + 0x6a0);
    }
    fVar2 = uStack_1c._4_4_;
    if (uStack_1c._4_4_ <= *(float *)(iVar1 + 0x69c)) {
      fVar2 = *(float *)(iVar1 + 0x69c);
    }
    if ((float)uStack_1c <= *(float *)(iVar1 + 0x698)) {
      uStack_1c._0_4_ = *(float *)(iVar1 + 0x698);
    }
    uStack_1c = CONCAT44(fVar2,(float)uStack_1c);
    fStack_8 = fStack_14;
  }
  iVar1 = *(int *)(param_1 + 0xf8);
  if (iVar1 != 0) {
    if (*(float *)(iVar1 + 0x694) <= fStack_20) {
      fStack_20 = *(float *)(iVar1 + 0x694);
    }
    fVar2 = uStack_28._4_4_;
    if (*(float *)(iVar1 + 0x690) <= uStack_28._4_4_) {
      fVar2 = *(float *)(iVar1 + 0x690);
    }
    if (*(float *)(iVar1 + 0x68c) <= (float)uStack_28) {
      uStack_28._0_4_ = *(float *)(iVar1 + 0x68c);
    }
    uStack_28 = CONCAT44(fVar2,(float)uStack_28);
    if (fStack_14 <= *(float *)(iVar1 + 0x6a0)) {
      fStack_14 = *(float *)(iVar1 + 0x6a0);
    }
    fVar2 = uStack_1c._4_4_;
    if (uStack_1c._4_4_ <= *(float *)(iVar1 + 0x69c)) {
      fVar2 = *(float *)(iVar1 + 0x69c);
    }
    if ((float)uStack_1c <= *(float *)(iVar1 + 0x698)) {
      uStack_1c._0_4_ = *(float *)(iVar1 + 0x698);
    }
    uStack_1c = CONCAT44(fVar2,(float)uStack_1c);
    fStack_8 = fStack_14;
  }
  iVar1 = *(int *)(param_1 + 0x100);
  if (iVar1 != 0) {
    if (*(float *)(iVar1 + 0x694) <= fStack_20) {
      fStack_20 = *(float *)(iVar1 + 0x694);
    }
    fVar2 = uStack_28._4_4_;
    if (*(float *)(iVar1 + 0x690) <= uStack_28._4_4_) {
      fVar2 = *(float *)(iVar1 + 0x690);
    }
    if (*(float *)(iVar1 + 0x68c) <= (float)uStack_28) {
      uStack_28._0_4_ = *(float *)(iVar1 + 0x68c);
    }
    uStack_28 = CONCAT44(fVar2,(float)uStack_28);
    if (fStack_14 <= *(float *)(iVar1 + 0x6a0)) {
      fStack_14 = *(float *)(iVar1 + 0x6a0);
    }
    fVar2 = uStack_1c._4_4_;
    if (uStack_1c._4_4_ <= *(float *)(iVar1 + 0x69c)) {
      fVar2 = *(float *)(iVar1 + 0x69c);
    }
    if ((float)uStack_1c <= *(float *)(iVar1 + 0x698)) {
      uStack_1c._0_4_ = *(float *)(iVar1 + 0x698);
    }
    uStack_1c = CONCAT44(fVar2,(float)uStack_1c);
    fStack_8 = fStack_14;
  }
  FUN_008411b0(&uStack_28,*(undefined4 *)(param_1 + 4));
  return;
}



/* FUNCTION 13031 ; VA 0x008522e0 ; FUN_008522e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_008522e0(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  char cVar13;
  undefined4 *puVar14;
  int iVar15;
  undefined4 *puVar16;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined auStack_80 [48];
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  undefined4 uStack_24;
  int iStack_14;
  
  if (*(int *)(param_1 + 0x20) == 0) {
    puVar16 = (undefined4 *)FUN_0060efa0();
  }
  else {
    puVar14 = (undefined4 *)FUN_00b077e0();
    uStack_b0 = *puVar14;
    uStack_ac = puVar14[1];
    uStack_a8 = puVar14[2];
    uStack_a4 = puVar14[3];
    uStack_a0 = puVar14[4];
    uStack_9c = puVar14[5];
    uStack_98 = puVar14[6];
    uStack_94 = puVar14[7];
    puVar16 = &uStack_b0;
    uStack_90 = puVar14[8];
    uStack_8c = puVar14[9];
    uStack_88 = puVar14[10];
    uStack_84 = puVar14[0xb];
  }
  uStack_50 = *puVar16;
  uStack_4c = puVar16[1];
  uStack_48 = puVar16[2];
  uStack_44 = puVar16[3];
  uStack_40 = puVar16[4];
  uStack_3c = puVar16[5];
  uStack_38 = puVar16[6];
  uStack_34 = puVar16[7];
  uStack_30 = puVar16[8];
  uStack_2c = *(undefined8 *)(puVar16 + 9);
  uStack_24 = puVar16[0xb];
  if (((*(int *)(param_1 + 0x28) != 0) &&
      (iStack_14 = *(int *)(*(int *)(param_1 + 0x28) + 0x34), iStack_14 != 0)) &&
     (iVar1 = *(int *)(iStack_14 + 0xc), iVar15 = FUN_00d6bbd0(),
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar15 + 0x1d8) <=
     (uint)*(ushort *)(iVar15 + 0x1da))) {
    puVar16 = (undefined4 *)FUN_00d6c6c0(auStack_80);
    uStack_50 = *puVar16;
    uStack_4c = puVar16[1];
    uStack_48 = puVar16[2];
    uStack_44 = puVar16[3];
    uStack_40 = puVar16[4];
    uStack_3c = puVar16[5];
    uStack_38 = puVar16[6];
    uStack_34 = puVar16[7];
    uStack_30 = puVar16[8];
    uStack_2c = *(undefined8 *)(puVar16 + 9);
    uStack_24 = puVar16[0xb];
  }
  iStack_14 = *(int *)(param_1 + 0x28);
  if ((iStack_14 != 0) &&
     (iVar1 = *(int *)(iStack_14 + 0xc), iVar15 = FUN_00d3dc90(),
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar15 + 0x1d8) <=
     (uint)*(ushort *)(iVar15 + 0x1da))) {
    uStack_30 = DAT_01d71e7c;
    uStack_50 = _DAT_01d71e5c;
    uStack_4c = uRam01d71e60;
    uStack_48 = uRam01d71e64;
    uStack_44 = _DAT_01d71e68;
    uStack_40 = _DAT_01d71e6c;
    uStack_3c = uRam01d71e70;
    uStack_38 = _DAT_01d71e74;
    uStack_34 = uRam01d71e78;
    uStack_2c = *(undefined8 *)(iStack_14 + 0x80);
    uStack_24 = *(undefined4 *)(iStack_14 + 0x88);
  }
  if ((*(char *)(param_1 + 0x78) == '\0') && (cVar13 = FUN_01163470(&uStack_50), cVar13 != '\0')) {
    return;
  }
  *(undefined4 *)(param_1 + 0x30) = uStack_50;
  *(undefined4 *)(param_1 + 0x34) = uStack_4c;
  *(undefined4 *)(param_1 + 0x38) = uStack_48;
  *(undefined4 *)(param_1 + 0x3c) = uStack_44;
  *(undefined4 *)(param_1 + 0x40) = uStack_40;
  *(undefined4 *)(param_1 + 0x44) = uStack_3c;
  *(undefined4 *)(param_1 + 0x48) = uStack_38;
  *(undefined4 *)(param_1 + 0x4c) = uStack_34;
  *(undefined4 *)(param_1 + 0x50) = uStack_30;
  *(undefined4 *)(param_1 + 0x54) = (undefined4)uStack_2c;
  *(undefined4 *)(param_1 + 0x58) = uStack_2c._4_4_;
  *(undefined4 *)(param_1 + 0x5c) = uStack_24;
  if (*(int *)(param_1 + 0x7c) != 0) {
    puVar16 = (undefined4 *)FUN_0071f260(auStack_80,param_1 + 0x94);
    uVar2 = puVar16[1];
    uVar3 = puVar16[2];
    uVar4 = puVar16[3];
    uVar5 = puVar16[4];
    uVar6 = puVar16[5];
    uVar7 = puVar16[6];
    uVar8 = puVar16[7];
    uVar9 = puVar16[8];
    uVar10 = puVar16[9];
    uVar11 = puVar16[10];
    uVar12 = puVar16[0xb];
    iVar1 = *(int *)(param_1 + 0x7c);
    *(undefined4 *)(iVar1 + 0x14) = *puVar16;
    *(undefined4 *)(iVar1 + 0x18) = uVar2;
    *(undefined4 *)(iVar1 + 0x1c) = uVar3;
    *(undefined4 *)(iVar1 + 0x20) = uVar4;
    *(undefined4 *)(iVar1 + 0x24) = uVar5;
    *(undefined4 *)(iVar1 + 0x28) = uVar6;
    *(undefined4 *)(iVar1 + 0x2c) = uVar7;
    *(undefined4 *)(iVar1 + 0x30) = uVar8;
    *(undefined4 *)(iVar1 + 0x34) = uVar9;
    *(undefined4 *)(iVar1 + 0x38) = uVar10;
    *(undefined4 *)(iVar1 + 0x3c) = uVar11;
    *(undefined4 *)(iVar1 + 0x40) = uVar12;
  }
  if (*(int *)(param_1 + 0x84) != 0) {
    puVar16 = (undefined4 *)FUN_0071f260(auStack_80,param_1 + 0xc4);
    uVar2 = puVar16[1];
    uVar3 = puVar16[2];
    uVar4 = puVar16[3];
    uVar5 = puVar16[4];
    uVar6 = puVar16[5];
    uVar7 = puVar16[6];
    uVar8 = puVar16[7];
    uVar9 = puVar16[8];
    uVar10 = puVar16[9];
    uVar11 = puVar16[10];
    uVar12 = puVar16[0xb];
    iVar1 = *(int *)(param_1 + 0x84);
    *(undefined4 *)(iVar1 + 0x14) = *puVar16;
    *(undefined4 *)(iVar1 + 0x18) = uVar2;
    *(undefined4 *)(iVar1 + 0x1c) = uVar3;
    *(undefined4 *)(iVar1 + 0x20) = uVar4;
    *(undefined4 *)(iVar1 + 0x24) = uVar5;
    *(undefined4 *)(iVar1 + 0x28) = uVar6;
    *(undefined4 *)(iVar1 + 0x2c) = uVar7;
    *(undefined4 *)(iVar1 + 0x30) = uVar8;
    *(undefined4 *)(iVar1 + 0x34) = uVar9;
    *(undefined4 *)(iVar1 + 0x38) = uVar10;
    *(undefined4 *)(iVar1 + 0x3c) = uVar11;
    *(undefined4 *)(iVar1 + 0x40) = uVar12;
  }
  if (*(int *)(param_1 + 0x8c) != 0) {
    puVar16 = (undefined4 *)FUN_0071f260(auStack_80,param_1 + 0xf4);
    uVar2 = puVar16[1];
    uVar3 = puVar16[2];
    uVar4 = puVar16[3];
    uVar5 = puVar16[4];
    uVar6 = puVar16[5];
    uVar7 = puVar16[6];
    uVar8 = puVar16[7];
    uVar9 = puVar16[8];
    uVar10 = puVar16[9];
    uVar11 = puVar16[10];
    uVar12 = puVar16[0xb];
    iVar1 = *(int *)(param_1 + 0x8c);
    *(undefined4 *)(iVar1 + 0x14) = *puVar16;
    *(undefined4 *)(iVar1 + 0x18) = uVar2;
    *(undefined4 *)(iVar1 + 0x1c) = uVar3;
    *(undefined4 *)(iVar1 + 0x20) = uVar4;
    *(undefined4 *)(iVar1 + 0x24) = uVar5;
    *(undefined4 *)(iVar1 + 0x28) = uVar6;
    *(undefined4 *)(iVar1 + 0x2c) = uVar7;
    *(undefined4 *)(iVar1 + 0x30) = uVar8;
    *(undefined4 *)(iVar1 + 0x34) = uVar9;
    *(undefined4 *)(iVar1 + 0x38) = uVar10;
    *(undefined4 *)(iVar1 + 0x3c) = uVar11;
    *(undefined4 *)(iVar1 + 0x40) = uVar12;
  }
  (**(code **)(*(int *)(param_1 + -0x74) + 0xc))();
  return;
}



/* FUNCTION 13032 ; VA 0x00852500 ; FUN_00852500 */

void __fastcall FUN_00852500(int *param_1)

{
  if (param_1[3] == param_1[4]) {
    if (param_1 == (int *)0x74) {
      param_1 = (int *)0x0;
    }
    FUN_007c64b0(param_1);
    return;
  }
  FUN_0084eb80();
  (**(code **)(*param_1 + 0x44))();
  *(undefined *)(param_1 + 0x1e) = 0;
  return;
}



/* FUNCTION 13033 ; VA 0x00852540 ; FUN_00852540 */

void __thiscall FUN_00852540(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  char cVar1;
  int iVar2;
  
  cVar1 = FUN_00841130();
  if ((cVar1 == '\0') && (param_4 == 0)) {
    if (*(char *)(param_1 + 0xed) == '\0') {
      if (*(int *)(param_1 + 0xf0) != 0) {
        iVar2 = FUN_0082e210();
        if (iVar2 == 0) {
          FUN_0058a2b0();
        }
      }
      if (*(char *)(param_1 + 0xed) == '\0') {
        if (*(int *)(param_1 + 0xf8) != 0) {
          iVar2 = FUN_0082e210();
          if (iVar2 == 0) {
            FUN_0058a2b0();
          }
        }
        if ((*(char *)(param_1 + 0xed) == '\0') && (*(int *)(param_1 + 0x100) != 0)) {
          iVar2 = FUN_0082e210();
          if (iVar2 == 0) {
            FUN_0058a2b0();
          }
        }
      }
    }
    if (*(int *)(param_1 + 0xf0) != 0) {
      FUN_0082e2a0(*(int *)(param_1 + 0xf0));
    }
    if (*(int *)(param_1 + 0xf8) != 0) {
      FUN_0082e2a0(*(int *)(param_1 + 0xf8));
    }
    if (*(int *)(param_1 + 0x100) != 0) {
      FUN_0082e2a0(*(int *)(param_1 + 0x100));
    }
    if (((*(int *)(param_1 + 0xf0) != 0) || (*(int *)(param_1 + 0xf8) != 0)) ||
       (*(int *)(param_1 + 0x100) != 0)) {
      FUN_0082e230(param_1);
    }
    if ((*(char *)(*(int *)(*(int *)(param_1 + 8) + 0x510) + 0x20) != '\0') &&
       (((*(int *)(param_1 + 0xf0) != 0 || (*(int *)(param_1 + 0xf8) != 0)) ||
        (*(int *)(param_1 + 0x100) != 0)))) {
      FUN_008416d0(*(int *)(param_1 + 8),param_1 + 0x18);
    }
  }
  return;
}



/* FUNCTION 13034 ; VA 0x00852680 ; FUN_00852680 */

undefined4 * __thiscall FUN_00852680(undefined4 *param_1,undefined4 param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7c9f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00841300(param_2,0);
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x1d] = RBX::GfxPart::vftable;
  param_1[0x23] = 0xffffffff;
  *param_1 = RBX::Graphics::ExplosionEmitter::vftable;
  param_1[0x1d] = RBX::Graphics::ExplosionEmitter::vftable;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0x3f800000;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0x3f800000;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0x3f800000;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  *(undefined8 *)(param_1 + 0x34) = 0;
  param_1[0x36] = 0;
  *(undefined8 *)(param_1 + 0x37) = 0;
  param_1[0x39] = 0;
  uStack_8 = 3;
  *(undefined2 *)(param_1 + 0x3a) = 0;
  FUN_016f4053(param_1 + 0x3b,4,5,FUN_00550050,FUN_00550be0);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13035 ; VA 0x00852820 ; FUN_00852820 */

void __fastcall FUN_00852820(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::ExplosionEmitter::vftable;
  param_1[0x1d] = RBX::Graphics::ExplosionEmitter::vftable;
  FUN_011590c0();
  param_1[0x24] = 0;
  piVar2 = (int *)param_1[0x25];
  param_1[0x25] = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  param_1[0x26] = 0;
  piVar2 = (int *)param_1[0x27];
  param_1[0x27] = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_007c78a0(param_1 + 0x1d,1);
  FUN_016f32d1(param_1 + 0x3b,4,5,FUN_00550be0);
  piVar2 = (int *)param_1[0x27];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x25];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01158110();
  FUN_00841420();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13036 ; VA 0x0085295f ; FUN_0085295f */

void FUN_0085295f(void)

{
  FUN_00852970();
  return;
}



/* FUNCTION 13037 ; VA 0x00852970 ; FUN_00852970 */

undefined4 __thiscall FUN_00852970(undefined4 param_1,byte param_2)

{
  FUN_00852820();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x100);
  }
  return param_1;
}



/* FUNCTION 13038 ; VA 0x008529a0 ; FUN_008529a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_008529a0(int param_1)

{
  float fVar1;
  undefined8 uVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  uint uVar7;
  int iVar8;
  undefined4 *puVar9;
  undefined4 uVar10;
  float *pfVar11;
  int *piVar12;
  float fVar13;
  float fVar14;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined auStack_b4 [24];
  undefined auStack_9c [16];
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined8 uStack_84;
  undefined auStack_7c [16];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined uStack_64;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined uStack_4c;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  uint uStack_30;
  undefined8 uStack_2c;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  float fStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7de6;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  uStack_14 = 0;
  if (*(int *)(param_1 + 0x98) != 0) {
    iVar8 = *(int *)(param_1 + 0x98);
    piVar12 = (int *)(param_1 + 0xec);
    uVar4 = *(undefined4 *)(iVar8 + 0x88);
    uVar2 = *(undefined8 *)(iVar8 + 0x80);
    cVar3 = *(char *)(iVar8 + 0x98);
    ExceptionList = &pvStack_10;
    *(char *)(param_1 + 0xe9) = cVar3;
    if ((cVar3 != '\0') && (*piVar12 == 0)) {
      fStack_18 = (float)FUN_01674e20(0x6a4);
      uStack_8 = 0;
      if (fStack_18 == 0.0) {
        iVar8 = 0;
      }
      else {
        uStack_6c = 0;
        uStack_68 = 0xf;
        auStack_7c[0] = 0;
        uStack_54 = 0;
        uStack_50 = 0xf;
        uStack_64 = 0;
        uStack_3c = 0;
        uStack_38 = 0xf;
        uStack_4c = 0;
        uStack_8 = 1;
        uStack_14 = 1;
        uStack_24 = 1;
        iVar8 = FUN_0082b6e0(*(undefined4 *)(param_1 + 8),auStack_7c);
      }
      puVar9 = (undefined4 *)*piVar12;
      *piVar12 = iVar8;
      if (puVar9 != (undefined4 *)0x0) {
        (**(code **)*puVar9)(1);
      }
      uStack_8 = 0xffffffff;
      if ((uStack_14 & 1) != 0) {
        uStack_14 = uStack_14 & 0xfffffffe;
        FUN_00637950();
      }
    }
    uStack_2c = 0;
    uStack_c0 = (undefined4)uVar2;
    uStack_bc = (undefined4)((ulonglong)uVar2 >> 0x20);
    if (*(char *)(param_1 + 0xe9) != '\0') {
      uStack_8c = 0;
      uStack_88 = 0xf;
      auStack_9c[0] = 0;
      uStack_8 = 3;
      uStack_84 = 0;
      FUN_00551260("rbxasset://textures/particles/explosion01_core_main.dds");
      uStack_84 = 0x200000004;
      FUN_0082e7d0(&DAT_01eb4910);
      FUN_0082e2d0(&DAT_01eb48e0,0);
      uStack_6c = 0;
      uStack_68 = 0xf;
      auStack_7c[0] = 0;
      uStack_54 = 0;
      uStack_50 = 0xf;
      uStack_64 = 0;
      uStack_3c = 0;
      uStack_38 = 0xf;
      uStack_4c = 0;
      uStack_8._0_1_ = 4;
      FUN_0082e340(auStack_9c,auStack_7c);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      FUN_00637950();
      iVar8 = *piVar12;
      *(undefined4 *)(iVar8 + 0x670) = 0x3e4ccccd;
      uVar6 = uRam01d62320;
      uVar5 = uRam01d6231c;
      uVar10 = uRam01d62318;
      *(undefined4 *)(iVar8 + 0x678) = _DAT_01d62314;
      *(undefined4 *)(iVar8 + 0x67c) = uVar10;
      *(undefined4 *)(iVar8 + 0x680) = uVar5;
      *(undefined4 *)(iVar8 + 0x684) = uVar6;
      iVar8 = *piVar12;
      *(undefined4 *)(iVar8 + 0xe0) = 0x40800000;
      uVar7 = DAT_01eb493c;
      *(ulonglong *)(iVar8 + 0xd4) = CONCAT44(DAT_01eb4938,DAT_01eb4934);
      *(uint *)(iVar8 + 0xdc) = uVar7;
      iVar8 = *piVar12;
      fVar13 = DAT_01d62304 * DAT_018daf58;
      *(float *)(iVar8 + 0x104) = DAT_01d62300 * DAT_018daf58;
      *(float *)(iVar8 + 0x108) = fVar13;
      uVar7 = DAT_01eb493c;
      *(ulonglong *)(iVar8 + 200) = CONCAT44(DAT_01eb4938,DAT_01eb4934);
      *(uint *)(iVar8 + 0xd0) = uVar7;
      iVar8 = *piVar12;
      fVar13 = DAT_01d62324 * _DAT_0191a748;
      *(float *)(iVar8 + 0xe8) = DAT_01d62328 * _DAT_0191a748;
      *(float *)(iVar8 + 0xe4) = fVar13;
      fVar13 = DAT_018e3f90;
      fVar14 = DAT_01d62304 * DAT_018e3f90;
      *(float *)(iVar8 + 0xf4) = DAT_01d62300 * DAT_018e3f90;
      *(float *)(iVar8 + 0xf8) = fVar14;
      fVar14 = DAT_01d62304 * fVar13;
      *(float *)(iVar8 + 0xfc) = DAT_01d62300 * fVar13;
      *(float *)(iVar8 + 0x100) = fVar14;
      fVar13 = DAT_01d62304 * DAT_019011dc;
      *(float *)(iVar8 + 0xb8) = DAT_01d62300 * DAT_019011dc;
      *(float *)(iVar8 + 0xbc) = fVar13;
      fVar13 = DAT_01d62324 * _DAT_0191a738;
      *(float *)(iVar8 + 0xf0) = DAT_01d62328 * _DAT_0191a738;
      *(float *)(iVar8 + 0xec) = fVar13;
      fVar13 = DAT_01d62304 * _DAT_0191a72c;
      *(float *)(iVar8 + 0xc0) = DAT_01d62300 * _DAT_0191a72c;
      *(float *)(iVar8 + 0xc4) = fVar13;
      FUN_0082e7f0(0);
      uStack_20 = DAT_01d62308 ^ DAT_018c4ea0;
      uStack_1c = DAT_01d6230c ^ DAT_018c4ea0;
      iVar8 = *piVar12;
      fStack_18 = (float)(DAT_01d62310 ^ DAT_018c4ea0);
      puVar9 = (undefined4 *)FUN_00709d10(&uStack_20,&DAT_01d62308);
      fStack_18 = 0.7;
      uStack_1c = 0x3f000000;
      uVar10 = puVar9[1];
      uVar5 = puVar9[2];
      uVar6 = puVar9[3];
      uVar2 = *(undefined8 *)(puVar9 + 4);
      *(undefined4 *)(iVar8 + 0xa0) = *puVar9;
      *(undefined4 *)(iVar8 + 0xa4) = uVar10;
      *(undefined4 *)(iVar8 + 0xa8) = uVar5;
      *(undefined4 *)(iVar8 + 0xac) = uVar6;
      *(undefined4 *)(iVar8 + 0x98) = 0;
      *(undefined8 *)(iVar8 + 0xb0) = uVar2;
      FUN_0082e820(0x3f000000,0x3f333333);
      uVar6 = _UNK_018e3fbc;
      uVar5 = _UNK_018e3fb8;
      uVar10 = _UNK_018e3fb4;
      iVar8 = *(int *)(param_1 + 0xec);
      *(undefined4 *)(iVar8 + 0x14) = _DAT_018e3fb0;
      *(undefined4 *)(iVar8 + 0x18) = uVar10;
      *(undefined4 *)(iVar8 + 0x1c) = uVar5;
      *(undefined4 *)(iVar8 + 0x20) = uVar6;
      uVar6 = _UNK_018e3fbc;
      uVar5 = _UNK_018e3fb8;
      uVar10 = _UNK_018e3fb4;
      *(undefined4 *)(iVar8 + 0x24) = _DAT_018e3fb0;
      *(undefined4 *)(iVar8 + 0x28) = uVar10;
      *(undefined4 *)(iVar8 + 0x2c) = uVar5;
      *(undefined4 *)(iVar8 + 0x30) = uVar6;
      *(undefined4 *)(iVar8 + 0x34) = 0x3f800000;
      *(undefined4 *)(iVar8 + 0x38) = uStack_c0;
      *(undefined4 *)(iVar8 + 0x3c) = uStack_bc;
      *(undefined4 *)(iVar8 + 0x40) = uVar4;
      FUN_0082c170(100);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      if ((*(char *)(param_1 + 0xe9) != '\0') && (*(int *)(param_1 + 0xf0) == 0)) {
        fStack_18 = (float)FUN_01674e20(0x6a4);
        uStack_8 = 5;
        if (fStack_18 == 0.0) {
          uVar10 = 0;
        }
        else {
          uStack_6c = 0;
          uStack_68 = 0xf;
          auStack_7c[0] = 0;
          uStack_54 = 0;
          uStack_50 = 0xf;
          uStack_64 = 0;
          uStack_3c = 0;
          uStack_38 = 0xf;
          uStack_4c = 0;
          uStack_24 = uStack_14 | 2;
          uStack_8 = 6;
          uStack_14 = uStack_24;
          uVar10 = FUN_0082b6e0(*(undefined4 *)(param_1 + 8),auStack_7c);
        }
        puVar9 = *(undefined4 **)(param_1 + 0xf0);
        *(undefined4 *)(param_1 + 0xf0) = uVar10;
        if (puVar9 != (undefined4 *)0x0) {
          (**(code **)*puVar9)(1);
        }
        uStack_8 = 0xffffffff;
        if ((uStack_14 & 2) != 0) {
          uStack_14 = uStack_14 & 0xfffffffd;
          FUN_00637950();
        }
      }
    }
    if (*(char *)(param_1 + 0xe9) != '\0') {
      uStack_8c = 0;
      uStack_88 = 0xf;
      auStack_9c[0] = 0;
      uStack_8 = 8;
      uStack_84 = 0;
      FUN_00551260("rbxasset://textures/particles/explosion01_core_main.dds");
      uStack_84 = 0x200000004;
      FUN_0082e7d0(&DAT_01eb4910);
      FUN_0082e2d0(&DAT_01eb48e0,0);
      uStack_6c = 0;
      uStack_68 = 0xf;
      auStack_7c[0] = 0;
      uStack_54 = 0;
      uStack_50 = 0xf;
      uStack_64 = 0;
      uStack_3c = 0;
      uStack_38 = 0xf;
      uStack_4c = 0;
      uStack_8._0_1_ = 9;
      FUN_0082e340(auStack_9c,auStack_7c);
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      FUN_00637950();
      iVar8 = *(int *)(param_1 + 0xf0);
      fStack_18 = 0.0;
      *(undefined4 *)(iVar8 + 0x670) = 0x3e19999a;
      uVar6 = uRam01d62320;
      uVar5 = uRam01d6231c;
      uVar10 = uRam01d62318;
      *(undefined4 *)(iVar8 + 0x678) = _DAT_01d62314;
      *(undefined4 *)(iVar8 + 0x67c) = uVar10;
      *(undefined4 *)(iVar8 + 0x680) = uVar5;
      *(undefined4 *)(iVar8 + 0x684) = uVar6;
      iVar8 = *(int *)(param_1 + 0xf0);
      *(undefined4 *)(iVar8 + 0x688) = 0x3c23d70a;
      *(undefined4 *)(iVar8 + 0xe0) = 0x40000000;
      uVar7 = DAT_01eb493c;
      *(ulonglong *)(iVar8 + 0xd4) = CONCAT44(DAT_01eb4938,DAT_01eb4934);
      *(uint *)(iVar8 + 0xdc) = uVar7;
      iVar8 = *(int *)(param_1 + 0xf0);
      fVar13 = DAT_01d62300 * DAT_0191a364;
      *(float *)(iVar8 + 0x108) = DAT_01d62304 * DAT_0191a364;
      uVar10 = DAT_0191a734;
      *(float *)(iVar8 + 0x104) = fVar13;
      fVar13 = DAT_018fabe4;
      *(ulonglong *)(iVar8 + 200) = CONCAT44(uVar10,(undefined4)uStack_2c);
      *(undefined4 *)(iVar8 + 0xd0) = 0;
      iVar8 = *(int *)(param_1 + 0xf0);
      fVar14 = DAT_01d62328 * _DAT_0191a73c;
      *(float *)(iVar8 + 0xe4) = DAT_01d62324 * _DAT_0191a73c;
      *(float *)(iVar8 + 0xe8) = fVar14;
      fVar14 = DAT_01d62304 * fVar13;
      *(float *)(iVar8 + 0xf4) = DAT_01d62300 * fVar13;
      *(float *)(iVar8 + 0xf8) = fVar14;
      fVar14 = DAT_01d62304;
      *(float *)(iVar8 + 0xfc) = DAT_01d62300 * fVar13;
      *(float *)(iVar8 + 0x100) = fVar14 * fVar13;
      *(undefined4 *)(iVar8 + 0xb8) = 0x42700000;
      *(undefined4 *)(iVar8 + 0xbc) = 0x42a00000;
      uVar10 = DAT_01eb4930;
      uStack_1c = DAT_01eb492c;
      *(undefined4 *)(iVar8 + 0xec) = DAT_01eb492c;
      *(undefined4 *)(iVar8 + 0xf0) = uVar10;
      fVar13 = DAT_01d62300 * _DAT_0191a72c;
      *(float *)(iVar8 + 0xc4) = DAT_01d62304 * _DAT_0191a72c;
      *(float *)(iVar8 + 0xc0) = fVar13;
      FUN_0082e7f0(0);
      uStack_20 = DAT_01d62308 ^ DAT_018c4ea0;
      uStack_1c = DAT_01d6230c ^ DAT_018c4ea0;
      iVar8 = *(int *)(param_1 + 0xf0);
      fStack_18 = (float)(DAT_01d62310 ^ DAT_018c4ea0);
      puVar9 = (undefined4 *)FUN_00709d10(&uStack_20,&DAT_01d62308);
      fStack_18 = 1.0;
      uStack_1c = 0x3f800000;
      uVar10 = puVar9[1];
      uVar5 = puVar9[2];
      uVar6 = puVar9[3];
      uVar2 = *(undefined8 *)(puVar9 + 4);
      *(undefined4 *)(iVar8 + 0xa0) = *puVar9;
      *(undefined4 *)(iVar8 + 0xa4) = uVar10;
      *(undefined4 *)(iVar8 + 0xa8) = uVar5;
      *(undefined4 *)(iVar8 + 0xac) = uVar6;
      *(undefined4 *)(iVar8 + 0x98) = 0;
      *(undefined8 *)(iVar8 + 0xb0) = uVar2;
      FUN_0082e820(0x3f800000,0x3f800000);
      uVar6 = _UNK_018e3fbc;
      uVar5 = _UNK_018e3fb8;
      uVar10 = _UNK_018e3fb4;
      iVar8 = *(int *)(param_1 + 0xf0);
      *(undefined4 *)(iVar8 + 0x14) = _DAT_018e3fb0;
      *(undefined4 *)(iVar8 + 0x18) = uVar10;
      *(undefined4 *)(iVar8 + 0x1c) = uVar5;
      *(undefined4 *)(iVar8 + 0x20) = uVar6;
      uVar6 = _UNK_018e3fbc;
      uVar5 = _UNK_018e3fb8;
      uVar10 = _UNK_018e3fb4;
      *(undefined4 *)(iVar8 + 0x24) = _DAT_018e3fb0;
      *(undefined4 *)(iVar8 + 0x28) = uVar10;
      *(undefined4 *)(iVar8 + 0x2c) = uVar5;
      *(undefined4 *)(iVar8 + 0x30) = uVar6;
      *(undefined4 *)(iVar8 + 0x34) = 0x3f800000;
      *(undefined4 *)(iVar8 + 0x38) = uStack_c0;
      *(undefined4 *)(iVar8 + 0x3c) = uStack_bc;
      *(undefined4 *)(iVar8 + 0x40) = uVar4;
      FUN_0082c170(0x32);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      if ((*(char *)(param_1 + 0xe9) != '\0') && (*(int *)(param_1 + 0xf4) == 0)) {
        fStack_18 = (float)FUN_01674e20(0x6a4);
        uStack_8 = 10;
        if (fStack_18 == 0.0) {
          uVar10 = 0;
        }
        else {
          uStack_6c = 0;
          uStack_68 = 0xf;
          auStack_7c[0] = 0;
          uStack_54 = 0;
          uStack_50 = 0xf;
          uStack_64 = 0;
          uStack_3c = 0;
          uStack_38 = 0xf;
          uStack_4c = 0;
          uStack_24 = uStack_14 | 4;
          uStack_8 = 0xb;
          uStack_14 = uStack_24;
          uVar10 = FUN_0082b6e0(*(undefined4 *)(param_1 + 8),auStack_7c);
        }
        puVar9 = *(undefined4 **)(param_1 + 0xf4);
        *(undefined4 *)(param_1 + 0xf4) = uVar10;
        if (puVar9 != (undefined4 *)0x0) {
          (**(code **)*puVar9)(1);
        }
        uStack_8 = 0xffffffff;
        if ((uStack_14 & 4) != 0) {
          uStack_14 = uStack_14 & 0xfffffffb;
          FUN_00637950();
        }
      }
    }
    if (*(char *)(param_1 + 0xe9) != '\0') {
      uStack_8c = 0;
      uStack_88 = 0xf;
      auStack_9c[0] = 0;
      uStack_8 = 0xd;
      uStack_84 = 0;
      FUN_00551260("rbxasset://textures/particles/explosion01_shockwave_main.dds");
      uStack_84 = 5;
      FUN_0082e7d0(&DAT_01eb491c);
      FUN_0082e2d0(&DAT_01eb48e0,0);
      uStack_6c = 0;
      uStack_68 = 0xf;
      auStack_7c[0] = 0;
      uStack_54 = 0;
      uStack_50 = 0xf;
      uStack_64 = 0;
      uStack_3c = 0;
      uStack_38 = 0xf;
      uStack_4c = 0;
      uStack_8._0_1_ = 0xe;
      FUN_0082e340(auStack_9c,auStack_7c);
      uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
      FUN_00637950();
      iVar8 = *(int *)(param_1 + 0xf4);
      *(undefined4 *)(iVar8 + 0x670) = 0;
      uVar6 = uRam01d62320;
      uVar5 = uRam01d6231c;
      uVar10 = uRam01d62318;
      *(undefined4 *)(iVar8 + 0x678) = _DAT_01d62314;
      *(undefined4 *)(iVar8 + 0x67c) = uVar10;
      *(undefined4 *)(iVar8 + 0x680) = uVar5;
      *(undefined4 *)(iVar8 + 0x684) = uVar6;
      iVar8 = *(int *)(param_1 + 0xf4);
      *(undefined4 *)(iVar8 + 0xe0) = 0;
      uVar7 = DAT_01eb493c;
      *(ulonglong *)(iVar8 + 0xd4) = CONCAT44(DAT_01eb4938,DAT_01eb4934);
      *(uint *)(iVar8 + 0xdc) = uVar7;
      iVar8 = *(int *)(param_1 + 0xf4);
      fVar13 = DAT_01d62300 * DAT_01901960;
      *(float *)(iVar8 + 0x108) = DAT_01d62304 * DAT_01901960;
      *(float *)(iVar8 + 0x104) = fVar13;
      uVar7 = DAT_01eb493c;
      *(ulonglong *)(iVar8 + 200) = CONCAT44(DAT_01eb4938,DAT_01eb4934);
      *(uint *)(iVar8 + 0xd0) = uVar7;
      iVar8 = *(int *)(param_1 + 0xf4);
      fVar13 = DAT_01d62328 * _DAT_0191a73c;
      *(float *)(iVar8 + 0xe4) = DAT_01d62324 * _DAT_0191a73c;
      *(float *)(iVar8 + 0xe8) = fVar13;
      fVar14 = (float)uStack_2c;
      fVar13 = DAT_01d62304 * fVar14;
      *(float *)(iVar8 + 0xf4) = DAT_01d62300 * fVar14;
      *(float *)(iVar8 + 0xf8) = fVar13;
      fVar13 = DAT_01d62304 * fVar14;
      *(float *)(iVar8 + 0xfc) = DAT_01d62300 * fVar14;
      *(float *)(iVar8 + 0x100) = fVar13;
      uVar10 = DAT_01eb4930;
      *(undefined4 *)(iVar8 + 0xb8) = DAT_01eb492c;
      *(undefined4 *)(iVar8 + 0xbc) = uVar10;
      uVar10 = DAT_01eb4930;
      *(undefined4 *)(iVar8 + 0xec) = DAT_01eb492c;
      *(undefined4 *)(iVar8 + 0xf0) = uVar10;
      uVar10 = DAT_01eb4930;
      uStack_1c = DAT_01eb492c;
      *(undefined4 *)(iVar8 + 0xc0) = DAT_01eb492c;
      *(undefined4 *)(iVar8 + 0xc4) = uVar10;
      FUN_0082e7f0(0);
      uStack_20 = DAT_01eb4934 ^ DAT_018c4ea0;
      uStack_1c = DAT_01eb4938 ^ DAT_018c4ea0;
      iVar8 = *(int *)(param_1 + 0xf4);
      fStack_18 = (float)(DAT_01eb493c ^ DAT_018c4ea0);
      puVar9 = (undefined4 *)FUN_00709d10(&uStack_20,&DAT_01eb4934);
      fStack_18 = 0.7;
      uStack_1c = 0x3f000000;
      uVar10 = puVar9[1];
      uVar5 = puVar9[2];
      uVar6 = puVar9[3];
      uVar2 = *(undefined8 *)(puVar9 + 4);
      *(undefined4 *)(iVar8 + 0xa0) = *puVar9;
      *(undefined4 *)(iVar8 + 0xa4) = uVar10;
      *(undefined4 *)(iVar8 + 0xa8) = uVar5;
      *(undefined4 *)(iVar8 + 0xac) = uVar6;
      *(undefined4 *)(iVar8 + 0x98) = 0;
      *(undefined8 *)(iVar8 + 0xb0) = uVar2;
      FUN_0082e820(0x3f000000,0x3f333333);
      uVar6 = _UNK_018e3fbc;
      uVar5 = _UNK_018e3fb8;
      uVar10 = _UNK_018e3fb4;
      iVar8 = *(int *)(param_1 + 0xf4);
      *(undefined4 *)(iVar8 + 0x14) = _DAT_018e3fb0;
      *(undefined4 *)(iVar8 + 0x18) = uVar10;
      *(undefined4 *)(iVar8 + 0x1c) = uVar5;
      *(undefined4 *)(iVar8 + 0x20) = uVar6;
      uVar6 = _UNK_018e3fbc;
      uVar5 = _UNK_018e3fb8;
      uVar10 = _UNK_018e3fb4;
      *(undefined4 *)(iVar8 + 0x24) = _DAT_018e3fb0;
      *(undefined4 *)(iVar8 + 0x28) = uVar10;
      *(undefined4 *)(iVar8 + 0x2c) = uVar5;
      *(undefined4 *)(iVar8 + 0x30) = uVar6;
      *(undefined4 *)(iVar8 + 0x34) = 0x3f800000;
      *(undefined4 *)(iVar8 + 0x38) = uStack_c0;
      *(undefined4 *)(iVar8 + 0x3c) = uStack_bc;
      *(undefined4 *)(iVar8 + 0x40) = uVar4;
      FUN_0082c170(3);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      if ((*(char *)(param_1 + 0xe9) != '\0') && (*(int *)(param_1 + 0xf8) == 0)) {
        fStack_18 = (float)FUN_01674e20(0x6a4);
        uStack_8 = 0xf;
        if (fStack_18 == 0.0) {
          uVar10 = 0;
        }
        else {
          uStack_6c = 0;
          uStack_68 = 0xf;
          auStack_7c[0] = 0;
          uStack_54 = 0;
          uStack_50 = 0xf;
          uStack_64 = 0;
          uStack_3c = 0;
          uStack_38 = 0xf;
          uStack_4c = 0;
          uStack_24 = uStack_14 | 8;
          uStack_8 = 0x10;
          uStack_14 = uStack_24;
          uVar10 = FUN_0082b6e0(*(undefined4 *)(param_1 + 8),auStack_7c);
        }
        puVar9 = *(undefined4 **)(param_1 + 0xf8);
        *(undefined4 *)(param_1 + 0xf8) = uVar10;
        if (puVar9 != (undefined4 *)0x0) {
          (**(code **)*puVar9)(1);
        }
        uStack_8 = 0xffffffff;
        if ((uStack_14 & 8) != 0) {
          uStack_14 = uStack_14 & 0xfffffff7;
          FUN_00637950();
        }
      }
    }
    if (*(char *)(param_1 + 0xe9) != '\0') {
      uStack_8c = 0;
      uStack_88 = 0xf;
      auStack_9c[0] = 0;
      uStack_8 = 0x12;
      uStack_84 = 0;
      FUN_00551260("rbxasset://textures/particles/explosion01_core_main.dds");
      uStack_84 = 0x100000003;
      FUN_0082e7d0(&DAT_01eb4904);
      FUN_0082e2d0(&DAT_01eb48f8,0);
      uStack_6c = 0;
      uStack_68 = 0xf;
      auStack_7c[0] = 0;
      uStack_54 = 0;
      uStack_50 = 0xf;
      uStack_64 = 0;
      uStack_3c = 0;
      uStack_38 = 0xf;
      uStack_4c = 0;
      uStack_8._0_1_ = 0x13;
      FUN_0082e340(auStack_9c,auStack_7c);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
      FUN_00637950();
      iVar8 = *(int *)(param_1 + 0xf8);
      fStack_18 = 0.0;
      *(undefined4 *)(iVar8 + 0x670) = 0;
      uVar6 = uRam01d62320;
      uVar5 = uRam01d6231c;
      uVar10 = uRam01d62318;
      *(undefined4 *)(iVar8 + 0x678) = _DAT_01d62314;
      *(undefined4 *)(iVar8 + 0x67c) = uVar10;
      *(undefined4 *)(iVar8 + 0x680) = uVar5;
      *(undefined4 *)(iVar8 + 0x684) = uVar6;
      iVar8 = *(int *)(param_1 + 0xf8);
      *(undefined4 *)(iVar8 + 0x688) = 0x3ca3d70a;
      *(undefined4 *)(iVar8 + 0xe0) = 0x40000000;
      uVar7 = DAT_01eb493c;
      *(ulonglong *)(iVar8 + 0xd4) = CONCAT44(DAT_01eb4938,DAT_01eb4934);
      *(uint *)(iVar8 + 0xdc) = uVar7;
      fVar13 = DAT_01d62300;
      iVar8 = *(int *)(param_1 + 0xf8);
      *(float *)(iVar8 + 0x108) = DAT_01d62304;
      *(float *)(iVar8 + 0x104) = fVar13;
      *(ulonglong *)(iVar8 + 200) = CONCAT44(DAT_018fde94,(int)uStack_2c);
      *(undefined4 *)(iVar8 + 0xd0) = 0;
      iVar8 = *(int *)(param_1 + 0xf8);
      fVar13 = DAT_01d62324 * _DAT_0191a740;
      *(float *)(iVar8 + 0xe8) = DAT_01d62328 * _DAT_0191a740;
      *(float *)(iVar8 + 0xe4) = fVar13;
      fVar13 = DAT_018f9978;
      fVar14 = DAT_01d62304 * DAT_018f9978;
      *(float *)(iVar8 + 0xf4) = DAT_01d62300 * DAT_018f9978;
      *(float *)(iVar8 + 0xf8) = fVar14;
      fVar14 = DAT_01d62304 * fVar13;
      *(float *)(iVar8 + 0xfc) = DAT_01d62300 * fVar13;
      *(float *)(iVar8 + 0x100) = fVar14;
      *(undefined4 *)(iVar8 + 0xb8) = 0x40a00000;
      *(undefined4 *)(iVar8 + 0xbc) = 0x41a00000;
      fVar13 = DAT_01d62324 * _DAT_0191a704;
      *(float *)(iVar8 + 0xf0) = DAT_01d62328 * _DAT_0191a704;
      *(float *)(iVar8 + 0xec) = fVar13;
      fVar13 = DAT_01d62304 * _DAT_0191a72c;
      *(float *)(iVar8 + 0xc0) = DAT_01d62300 * _DAT_0191a72c;
      *(float *)(iVar8 + 0xc4) = fVar13;
      FUN_0082e7f0(0);
      uStack_30 = DAT_01eb4934 ^ DAT_018c4ea0;
      iVar8 = *(int *)(param_1 + 0xf8);
      uStack_2c = CONCAT44(DAT_01eb493c ^ DAT_018c4ea0,DAT_01eb4938 ^ DAT_018c4ea0);
      puVar9 = (undefined4 *)FUN_00709d10(&uStack_30,&DAT_01eb4934);
      uStack_2c = 0x400000003f800000;
      uVar10 = puVar9[1];
      uVar5 = puVar9[2];
      uVar6 = puVar9[3];
      uVar2 = *(undefined8 *)(puVar9 + 4);
      *(undefined4 *)(iVar8 + 0xa0) = *puVar9;
      *(undefined4 *)(iVar8 + 0xa4) = uVar10;
      *(undefined4 *)(iVar8 + 0xa8) = uVar5;
      *(undefined4 *)(iVar8 + 0xac) = uVar6;
      *(undefined4 *)(iVar8 + 0x98) = 0;
      *(undefined8 *)(iVar8 + 0xb0) = uVar2;
      FUN_0082e820(0x3f800000,0x40000000);
      uVar6 = _UNK_018e3fbc;
      uVar5 = _UNK_018e3fb8;
      uVar10 = _UNK_018e3fb4;
      iVar8 = *(int *)(param_1 + 0xf8);
      *(undefined4 *)(iVar8 + 0x14) = _DAT_018e3fb0;
      *(undefined4 *)(iVar8 + 0x18) = uVar10;
      *(undefined4 *)(iVar8 + 0x1c) = uVar5;
      *(undefined4 *)(iVar8 + 0x20) = uVar6;
      uVar6 = _UNK_018e3fbc;
      uVar5 = _UNK_018e3fb8;
      uVar10 = _UNK_018e3fb4;
      *(undefined4 *)(iVar8 + 0x24) = _DAT_018e3fb0;
      *(undefined4 *)(iVar8 + 0x28) = uVar10;
      *(undefined4 *)(iVar8 + 0x2c) = uVar5;
      *(undefined4 *)(iVar8 + 0x30) = uVar6;
      *(undefined4 *)(iVar8 + 0x34) = 0x3f800000;
      *(undefined4 *)(iVar8 + 0x38) = uStack_c0;
      *(undefined4 *)(iVar8 + 0x3c) = uStack_bc;
      *(undefined4 *)(iVar8 + 0x40) = uVar4;
      FUN_0082c170(0x3c);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      if ((*(char *)(param_1 + 0xe9) != '\0') && (*(int *)(param_1 + 0xfc) == 0)) {
        fStack_18 = (float)FUN_01674e20(0x6a4);
        uStack_8 = 0x14;
        if (fStack_18 == 0.0) {
          uVar10 = 0;
        }
        else {
          uStack_6c = 0;
          uStack_68 = 0xf;
          auStack_7c[0] = 0;
          uStack_54 = 0;
          uStack_50 = 0xf;
          uStack_64 = 0;
          uStack_3c = 0;
          uStack_38 = 0xf;
          uStack_4c = 0;
          uStack_24 = uStack_14 | 0x10;
          uStack_8 = 0x15;
          uStack_14 = uStack_24;
          uVar10 = FUN_0082b6e0(*(undefined4 *)(param_1 + 8),auStack_7c);
        }
        puVar9 = *(undefined4 **)(param_1 + 0xfc);
        *(undefined4 *)(param_1 + 0xfc) = uVar10;
        if (puVar9 != (undefined4 *)0x0) {
          (**(code **)*puVar9)(1);
        }
        uStack_8 = 0xffffffff;
        if ((uStack_14 & 0x10) != 0) {
          FUN_00637950();
        }
      }
    }
    if (*(char *)(param_1 + 0xe9) != '\0') {
      uStack_8c = 0;
      uStack_88 = 0xf;
      auStack_9c[0] = 0;
      uStack_8 = 0x17;
      uStack_84 = 0;
      FUN_00551260("rbxasset://textures/particles/explosion01_implosion_main.dds");
      uStack_84 = 1;
      FUN_0082e7d0(&DAT_01eb48ec);
      FUN_0082e2d0(&DAT_01eb48e0,0);
      uStack_6c = 0;
      uStack_68 = 0xf;
      auStack_7c[0] = 0;
      uStack_54 = 0;
      uStack_50 = 0xf;
      uStack_64 = 0;
      uStack_3c = 0;
      uStack_38 = 0xf;
      uStack_4c = 0;
      uStack_8._0_1_ = 0x18;
      FUN_0082e340(auStack_9c,auStack_7c);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x17);
      FUN_00637950();
      iVar8 = *(int *)(param_1 + 0xfc);
      *(undefined4 *)(iVar8 + 0x670) = 0;
      uVar6 = uRam01d62320;
      uVar5 = uRam01d6231c;
      uVar10 = uRam01d62318;
      *(undefined4 *)(iVar8 + 0x678) = _DAT_01d62314;
      *(undefined4 *)(iVar8 + 0x67c) = uVar10;
      *(undefined4 *)(iVar8 + 0x680) = uVar5;
      *(undefined4 *)(iVar8 + 0x684) = uVar6;
      iVar8 = *(int *)(param_1 + 0xfc);
      *(undefined4 *)(iVar8 + 0x688) = 0xbca3d70a;
      *(undefined4 *)(iVar8 + 0xe0) = 0;
      uVar7 = DAT_01eb493c;
      *(ulonglong *)(iVar8 + 0xd4) = CONCAT44(DAT_01eb4938,DAT_01eb4934);
      *(uint *)(iVar8 + 0xdc) = uVar7;
      iVar8 = *(int *)(param_1 + 0xfc);
      fVar13 = DAT_01d62300 * _DAT_0191a730;
      *(float *)(iVar8 + 0x108) = DAT_01d62304 * _DAT_0191a730;
      *(float *)(iVar8 + 0x104) = fVar13;
      uVar7 = DAT_01eb493c;
      *(ulonglong *)(iVar8 + 200) = CONCAT44(DAT_01eb4938,DAT_01eb4934);
      *(uint *)(iVar8 + 0xd0) = uVar7;
      iVar8 = *(int *)(param_1 + 0xfc);
      fVar13 = DAT_01d62324 * _DAT_0191a744;
      *(float *)(iVar8 + 0xe8) = DAT_01d62328 * _DAT_0191a744;
      *(float *)(iVar8 + 0xe4) = fVar13;
      fVar13 = DAT_019011dc;
      fVar14 = DAT_01d62304 * DAT_019011dc;
      *(float *)(iVar8 + 0xf4) = DAT_01d62300 * DAT_019011dc;
      *(float *)(iVar8 + 0xf8) = fVar14;
      fVar14 = DAT_01d62304 * fVar13;
      *(float *)(iVar8 + 0xfc) = DAT_01d62300 * fVar13;
      *(float *)(iVar8 + 0x100) = fVar14;
      *(undefined4 *)(iVar8 + 0xb8) = 0x41a00000;
      *(undefined4 *)(iVar8 + 0xbc) = 0x41a00000;
      uVar10 = DAT_01eb4930;
      *(undefined4 *)(iVar8 + 0xec) = DAT_01eb492c;
      *(undefined4 *)(iVar8 + 0xf0) = uVar10;
      uVar10 = DAT_01eb4930;
      uStack_2c = CONCAT44((int)((ulonglong)uStack_2c >> 0x20),DAT_01eb492c);
      *(undefined4 *)(iVar8 + 0xc0) = DAT_01eb492c;
      *(undefined4 *)(iVar8 + 0xc4) = uVar10;
      FUN_0082e7f0(0);
      uStack_30 = DAT_01eb4934 ^ DAT_018c4ea0;
      iVar8 = *(int *)(param_1 + 0xfc);
      uStack_2c = CONCAT44(DAT_01eb493c ^ DAT_018c4ea0,DAT_01eb4938 ^ DAT_018c4ea0);
      puVar9 = (undefined4 *)FUN_00709d10(&uStack_30,&DAT_01eb4934);
      uStack_2c = 0x3e99999a3dcccccd;
      uVar10 = puVar9[1];
      uVar5 = puVar9[2];
      uVar6 = puVar9[3];
      uVar2 = *(undefined8 *)(puVar9 + 4);
      *(undefined4 *)(iVar8 + 0xa0) = *puVar9;
      *(undefined4 *)(iVar8 + 0xa4) = uVar10;
      *(undefined4 *)(iVar8 + 0xa8) = uVar5;
      *(undefined4 *)(iVar8 + 0xac) = uVar6;
      *(undefined4 *)(iVar8 + 0x98) = 0;
      *(undefined8 *)(iVar8 + 0xb0) = uVar2;
      FUN_0082e820(0x3dcccccd,0x3e99999a);
      uVar6 = _UNK_018e3fbc;
      uVar5 = _UNK_018e3fb8;
      uVar10 = _UNK_018e3fb4;
      iVar8 = *(int *)(param_1 + 0xfc);
      *(undefined4 *)(iVar8 + 0x14) = _DAT_018e3fb0;
      *(undefined4 *)(iVar8 + 0x18) = uVar10;
      *(undefined4 *)(iVar8 + 0x1c) = uVar5;
      *(undefined4 *)(iVar8 + 0x20) = uVar6;
      uVar6 = _UNK_018e3fbc;
      uVar5 = _UNK_018e3fb8;
      uVar10 = _UNK_018e3fb4;
      *(undefined4 *)(iVar8 + 0x24) = _DAT_018e3fb0;
      *(undefined4 *)(iVar8 + 0x28) = uVar10;
      *(undefined4 *)(iVar8 + 0x2c) = uVar5;
      *(undefined4 *)(iVar8 + 0x30) = uVar6;
      *(undefined4 *)(iVar8 + 0x34) = 0x3f800000;
      *(undefined4 *)(iVar8 + 0x38) = uStack_c0;
      *(undefined4 *)(iVar8 + 0x3c) = uStack_bc;
      *(undefined4 *)(iVar8 + 0x40) = uVar4;
      FUN_0082c170(2);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
    }
    uVar6 = _UNK_018c4ebc;
    uVar5 = _UNK_018c4eb8;
    uVar10 = _UNK_018c4eb4;
    uVar4 = DAT_018c45d0;
    piVar12 = (int *)(param_1 + 0xec);
    *(undefined4 *)(param_1 + 0xd0) = _DAT_018c4eb0;
    *(undefined4 *)(param_1 + 0xd4) = uVar10;
    *(undefined4 *)(param_1 + 0xd8) = uVar5;
    *(undefined4 *)(param_1 + 0xdc) = uVar6;
    uStack_24 = 5;
    *(undefined4 *)(param_1 + 0xe0) = uVar4;
    *(undefined4 *)(param_1 + 0xe4) = uVar4;
    do {
      if (*piVar12 != 0) {
        pfVar11 = (float *)FUN_0082c950(auStack_b4);
        fVar13 = *(float *)(param_1 + 0xd8);
        if (pfVar11[2] <= *(float *)(param_1 + 0xd8)) {
          fVar13 = pfVar11[2];
        }
        fVar14 = *(float *)(param_1 + 0xd4);
        if (pfVar11[1] <= *(float *)(param_1 + 0xd4)) {
          fVar14 = pfVar11[1];
        }
        fVar1 = *(float *)(param_1 + 0xd0);
        if (*pfVar11 <= *(float *)(param_1 + 0xd0)) {
          fVar1 = *pfVar11;
        }
        uStack_2c = CONCAT44(fVar13,(undefined4)uStack_2c);
        *(ulonglong *)(param_1 + 0xd0) = CONCAT44(fVar14,fVar1);
        *(float *)(param_1 + 0xd8) = fVar13;
        fStack_18 = *(float *)(param_1 + 0xe4);
        if (*(float *)(param_1 + 0xe4) <= pfVar11[5]) {
          fStack_18 = pfVar11[5];
        }
        fVar13 = *(float *)(param_1 + 0xe0);
        if (*(float *)(param_1 + 0xe0) <= pfVar11[4]) {
          fVar13 = pfVar11[4];
        }
        fVar14 = *(float *)(param_1 + 0xdc);
        if (*(float *)(param_1 + 0xdc) <= pfVar11[3]) {
          fVar14 = pfVar11[3];
        }
        *(float *)(param_1 + 0xdc) = fVar14;
        *(float *)(param_1 + 0xe0) = fVar13;
        *(float *)(param_1 + 0xe4) = fStack_18;
      }
      piVar12 = piVar12 + 1;
      uStack_24 = uStack_24 + -1;
    } while (uStack_24 != 0);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13039 ; VA 0x00853f80 ; FUN_00853f80 */

void __thiscall FUN_00853f80(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  bool bVar5;
  undefined4 uStack_24;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7c22;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  iVar3 = param_2[1];
  ExceptionList = &pvStack_10;
  if (iVar3 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
    UNLOCK();
    iVar3 = param_2[1];
  }
  *(int *)(param_1 + 0x90) = *param_2;
  piVar1 = *(int **)(param_1 + 0x94);
  *(int *)(param_1 + 0x94) = iVar3;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  iVar3 = param_3[1];
  if (iVar3 != 0) {
    LOCK();
    *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
    UNLOCK();
    iVar3 = param_3[1];
  }
  *(int *)(param_1 + 0x98) = *param_3;
  piVar1 = *(int **)(param_1 + 0x9c);
  *(int *)(param_1 + 0x9c) = iVar3;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  puStack_18 = (undefined4 *)(*param_3 + 0x50);
  iStack_8 = 0;
  uVar2 = FUN_01675290(DAT_02110da8);
  iStack_8._0_1_ = 1;
  param_3 = (int *)FUN_01674e20(0x28);
  if (param_3 == (undefined4 *)0x0) {
    param_3 = (undefined4 *)0x0;
  }
  else {
    *param_3 = 0;
    param_3[1] = 1;
    param_3[2] = (int)FUN_00819150;
    param_3[3] = (int)_guard_check_icall;
    param_3[4] = 0;
    param_3[5] = (int)puStack_18;
    param_3[6] = (int)FUN_00854300;
    param_3[7] = 0;
    param_3[8] = param_1;
    param_3[9] = uStack_24;
  }
  FUN_016797d0(param_3);
  puStack_1c = param_3;
  if (param_3 != (undefined4 *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_14 = 1;
  iStack_8._0_1_ = 2;
  FUN_01675290(uVar2);
  puVar4 = *(undefined4 **)(param_1 + 0x84);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (*(undefined4 **)(param_1 + 0x88) == puVar4) {
    FUN_006335f0(puVar4,&puStack_1c);
    puVar4 = puStack_1c;
  }
  else {
    *puVar4 = param_3;
    *(int *)(param_1 + 0x84) = *(int *)(param_1 + 0x84) + 4;
    puVar4 = (undefined4 *)0x0;
  }
  uStack_14 = 0;
  iStack_8 = 0xffffffff;
  if (puVar4 != (undefined4 *)0x0) {
    piVar1 = puVar4 + 1;
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(puVar4);
    }
  }
  if (*param_2 != 0) {
    iVar3 = FUN_008a4100();
    puStack_1c = (undefined4 *)(iVar3 + 0x80);
    iStack_8 = 3;
    uVar2 = FUN_01675290(DAT_02110da8);
    iStack_8._0_1_ = 4;
    param_3 = (int *)FUN_01674e20(0x28);
    if (param_3 == (undefined4 *)0x0) {
      param_3 = (undefined4 *)0x0;
    }
    else {
      *param_3 = 0;
      param_3[1] = 1;
      param_3[2] = (int)FUN_00838650;
      param_3[3] = (int)_guard_check_icall;
      param_3[4] = 0;
      param_3[5] = (int)puStack_1c;
      param_3[6] = (int)FUN_00851fd0;
      param_3[7] = 0;
      param_3[8] = param_1;
      param_3[9] = uStack_24;
    }
    FUN_016797d0(param_3);
    puStack_18 = param_3;
    if (param_3 != (undefined4 *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    uStack_14 = 2;
    iStack_8._0_1_ = 5;
    FUN_01675290(uVar2);
    puVar4 = *(undefined4 **)(param_1 + 0x84);
    iStack_8 = CONCAT31(iStack_8._1_3_,3);
    if (*(undefined4 **)(param_1 + 0x88) == puVar4) {
      FUN_006335f0(puVar4,&puStack_18);
      puVar4 = puStack_18;
    }
    else {
      *puVar4 = param_3;
      *(int *)(param_1 + 0x84) = *(int *)(param_1 + 0x84) + 4;
      puVar4 = (undefined4 *)0x0;
    }
    iStack_8 = 0xffffffff;
    if (puVar4 != (undefined4 *)0x0) {
      piVar1 = puVar4 + 1;
      LOCK();
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        FUN_01674ea0(puVar4);
      }
    }
    if (DAT_01d6866c == '\0') {
      bVar5 = *(int *)(*param_2 + 0x70) == 0;
    }
    else {
      bVar5 = *(int *)(*param_2 + 0x6c) == -1;
    }
    if (bVar5) {
      FUN_007c7a50(-(uint)(param_1 != 0) & param_1 + 0x74U,1);
    }
    else {
      FUN_007c7840(-(uint)(param_1 != 0) & param_1 + 0x74U,1);
    }
  }
  (**(code **)(*(int *)(param_1 + 0x74) + 8))();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13040 ; VA 0x008542d0 ; FUN_008542d0 */

void __fastcall FUN_008542d0(int param_1)

{
  if (*(char *)(param_1 + 0x74) == '\0') {
    *(undefined *)(param_1 + 0x74) = 1;
    if (param_1 == 0x74) {
      param_1 = 0;
    }
    FUN_007c8ce0(param_1);
  }
  return;
}



/* FUNCTION 13041 ; VA 0x00854300 ; FUN_00854300 */

int __thiscall FUN_00854300(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7e00;
  pvStack_10 = ExceptionList;
  if (param_2 != 2) {
    param_2 = param_2 + -5;
    if (param_2 == 0) {
      piVar6 = *(int **)(param_1 + 0x9c);
      ExceptionList = &pvStack_10;
      if (piVar6 != (int *)0x0) {
        LOCK();
        ExceptionList = &pvStack_10;
        piVar6[1] = piVar6[1] + 1;
        UNLOCK();
        piVar6 = *(int **)(param_1 + 0x9c);
      }
      iVar5 = *(int *)(param_1 + 0x98);
      uStack_8 = 0;
      iStack_18 = iVar5;
      piStack_14 = piVar6;
      cVar3 = FUN_011584d0(iVar5);
      if (cVar3 == '\0') {
        param_2 = (**(code **)(*(int *)(param_1 + 0x74) + 4))();
      }
      else {
        (**(code **)(*(int *)(param_1 + 0x74) + 0x40))();
        iVar5 = *(int *)(iVar5 + 0x34);
        if ((iVar5 == 0) ||
           (iVar2 = *(int *)(iVar5 + 0xc), iVar4 = FUN_00aff8c0(),
           (uint)*(ushort *)(iVar4 + 0x1da) <
           (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) {
          iVar5 = 0;
        }
        FUN_0060dcd0(auStack_20,iVar5);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        param_2 = FUN_00853f80(auStack_20,&iStack_18);
        if (piStack_1c != (int *)0x0) {
          LOCK();
          piVar1 = piStack_1c + 1;
          iVar5 = *piVar1;
          param_2 = *piVar1;
          *piVar1 = iVar5 + -1;
          UNLOCK();
          if (iVar5 + -1 == 0) {
            (**(code **)*piStack_1c)();
            LOCK();
            piVar1 = piStack_1c + 2;
            iVar5 = *piVar1;
            param_2 = *piVar1;
            *piVar1 = iVar5 + -1;
            UNLOCK();
            if (iVar5 + -1 == 0) {
              param_2 = (**(code **)(*piStack_1c + 4))();
            }
          }
        }
      }
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar1 = piVar6 + 1;
        iVar5 = *piVar1;
        param_2 = *piVar1;
        *piVar1 = iVar5 + -1;
        UNLOCK();
        if (iVar5 + -1 == 0) {
          param_2 = (**(code **)*piVar6)();
          LOCK();
          piVar1 = piVar6 + 2;
          iVar5 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar5 == 1) {
            param_2 = (**(code **)(*piVar6 + 4))();
          }
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  ExceptionList = &pvStack_10;
  iVar5 = (**(code **)(*(int *)(param_1 + 0x74) + 8))();
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 13042 ; VA 0x00854450 ; FUN_00854450 */

void __thiscall FUN_00854450(int *param_1,int param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)*param_1;
  *param_1 = param_2;
  if (puVar1 != (undefined4 *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0085446a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)*puVar1)();
    return;
  }
  return;
}



/* FUNCTION 13043 ; VA 0x00854470 ; FUN_00854470 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00854470(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  char cVar12;
  undefined4 *puVar13;
  undefined4 *puVar14;
  int iVar15;
  undefined4 uVar16;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  undefined4 uStack_24;
  int iStack_14;
  
  if (*(int *)(param_1 + 0x1c) == 0) {
    puVar14 = (undefined4 *)FUN_0060efa0();
  }
  else {
    puVar13 = (undefined4 *)FUN_00b077e0();
    uStack_80 = *puVar13;
    uStack_7c = puVar13[1];
    uStack_78 = puVar13[2];
    uStack_74 = puVar13[3];
    uStack_70 = puVar13[4];
    uStack_6c = puVar13[5];
    uStack_68 = puVar13[6];
    uStack_64 = puVar13[7];
    puVar14 = &uStack_80;
    uStack_60 = puVar13[8];
    uStack_5c = puVar13[9];
    uStack_58 = puVar13[10];
    uStack_54 = puVar13[0xb];
  }
  uStack_50 = *puVar14;
  uStack_4c = puVar14[1];
  uStack_48 = puVar14[2];
  uStack_44 = puVar14[3];
  uStack_40 = puVar14[4];
  uStack_3c = puVar14[5];
  uStack_38 = puVar14[6];
  uStack_34 = puVar14[7];
  uStack_30 = puVar14[8];
  uStack_2c = *(undefined8 *)(puVar14 + 9);
  uStack_24 = puVar14[0xb];
  iStack_14 = *(int *)(param_1 + 0x24);
  if ((iStack_14 != 0) &&
     (iVar1 = *(int *)(iStack_14 + 0xc), iVar15 = FUN_00d3dc90(),
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar15 + 0x1d8) <=
     (uint)*(ushort *)(iVar15 + 0x1da))) {
    uStack_30 = DAT_01d71e7c;
    uStack_50 = _DAT_01d71e5c;
    uStack_4c = uRam01d71e60;
    uStack_48 = uRam01d71e64;
    uStack_44 = _DAT_01d71e68;
    uStack_40 = _DAT_01d71e6c;
    uStack_3c = uRam01d71e70;
    uStack_38 = _DAT_01d71e74;
    uStack_34 = uRam01d71e78;
    uStack_2c = *(undefined8 *)(iStack_14 + 0x80);
    uStack_24 = *(undefined4 *)(iStack_14 + 0x88);
  }
  if ((*(char *)(param_1 + 0x74) != '\0') || (cVar12 = FUN_01163470(&uStack_50), cVar12 == '\0')) {
    puVar14 = (undefined4 *)(param_1 + 0x2c);
    *puVar14 = uStack_50;
    *(undefined4 *)(param_1 + 0x30) = uStack_4c;
    *(undefined4 *)(param_1 + 0x34) = uStack_48;
    *(undefined4 *)(param_1 + 0x38) = uStack_44;
    *(undefined4 *)(param_1 + 0x3c) = uStack_40;
    *(undefined4 *)(param_1 + 0x40) = uStack_3c;
    *(undefined4 *)(param_1 + 0x44) = uStack_38;
    *(undefined4 *)(param_1 + 0x48) = uStack_34;
    *(undefined4 *)(param_1 + 0x4c) = uStack_30;
    *(undefined4 *)(param_1 + 0x50) = (undefined4)uStack_2c;
    *(undefined4 *)(param_1 + 0x54) = uStack_2c._4_4_;
    *(undefined4 *)(param_1 + 0x58) = uStack_24;
    iVar1 = *(int *)(param_1 + 0x78);
    if (iVar1 != 0) {
      *(undefined4 *)(iVar1 + 0x14) = uStack_50;
      *(undefined4 *)(iVar1 + 0x18) = uStack_4c;
      *(undefined4 *)(iVar1 + 0x1c) = uStack_48;
      *(undefined4 *)(iVar1 + 0x20) = uStack_44;
      *(undefined4 *)(iVar1 + 0x24) = uStack_40;
      *(undefined4 *)(iVar1 + 0x28) = uStack_3c;
      *(undefined4 *)(iVar1 + 0x2c) = uStack_38;
      *(undefined4 *)(iVar1 + 0x30) = uStack_34;
      *(undefined4 *)(iVar1 + 0x34) = uStack_30;
      *(undefined4 *)(iVar1 + 0x38) = (undefined4)uStack_2c;
      *(undefined4 *)(iVar1 + 0x3c) = uStack_2c._4_4_;
      *(undefined4 *)(iVar1 + 0x40) = uStack_24;
    }
    iVar1 = *(int *)(param_1 + 0x7c);
    if (iVar1 != 0) {
      uVar2 = *(undefined4 *)(param_1 + 0x30);
      uVar16 = *(undefined4 *)(param_1 + 0x34);
      uVar3 = *(undefined4 *)(param_1 + 0x38);
      uVar4 = *(undefined4 *)(param_1 + 0x3c);
      uVar5 = *(undefined4 *)(param_1 + 0x40);
      uVar6 = *(undefined4 *)(param_1 + 0x44);
      uVar7 = *(undefined4 *)(param_1 + 0x48);
      uVar8 = *(undefined4 *)(param_1 + 0x4c);
      uVar9 = *(undefined4 *)(param_1 + 0x50);
      uVar10 = *(undefined4 *)(param_1 + 0x54);
      uVar11 = *(undefined4 *)(param_1 + 0x58);
      *(undefined4 *)(iVar1 + 0x14) = *puVar14;
      *(undefined4 *)(iVar1 + 0x18) = uVar2;
      *(undefined4 *)(iVar1 + 0x1c) = uVar16;
      *(undefined4 *)(iVar1 + 0x20) = uVar3;
      *(undefined4 *)(iVar1 + 0x24) = uVar4;
      *(undefined4 *)(iVar1 + 0x28) = uVar5;
      *(undefined4 *)(iVar1 + 0x2c) = uVar6;
      *(undefined4 *)(iVar1 + 0x30) = uVar7;
      *(undefined4 *)(iVar1 + 0x34) = uVar8;
      *(undefined4 *)(iVar1 + 0x38) = uVar9;
      *(undefined4 *)(iVar1 + 0x3c) = uVar10;
      *(undefined4 *)(iVar1 + 0x40) = uVar11;
    }
    iVar1 = *(int *)(param_1 + 0x80);
    if (iVar1 != 0) {
      uVar2 = *(undefined4 *)(param_1 + 0x30);
      uVar16 = *(undefined4 *)(param_1 + 0x34);
      uVar3 = *(undefined4 *)(param_1 + 0x38);
      uVar4 = *(undefined4 *)(param_1 + 0x3c);
      uVar5 = *(undefined4 *)(param_1 + 0x40);
      uVar6 = *(undefined4 *)(param_1 + 0x44);
      uVar7 = *(undefined4 *)(param_1 + 0x48);
      uVar8 = *(undefined4 *)(param_1 + 0x4c);
      uVar9 = *(undefined4 *)(param_1 + 0x50);
      uVar10 = *(undefined4 *)(param_1 + 0x54);
      uVar11 = *(undefined4 *)(param_1 + 0x58);
      *(undefined4 *)(iVar1 + 0x14) = *puVar14;
      *(undefined4 *)(iVar1 + 0x18) = uVar2;
      *(undefined4 *)(iVar1 + 0x1c) = uVar16;
      *(undefined4 *)(iVar1 + 0x20) = uVar3;
      *(undefined4 *)(iVar1 + 0x24) = uVar4;
      *(undefined4 *)(iVar1 + 0x28) = uVar5;
      *(undefined4 *)(iVar1 + 0x2c) = uVar6;
      *(undefined4 *)(iVar1 + 0x30) = uVar7;
      *(undefined4 *)(iVar1 + 0x34) = uVar8;
      *(undefined4 *)(iVar1 + 0x38) = uVar9;
      *(undefined4 *)(iVar1 + 0x3c) = uVar10;
      *(undefined4 *)(iVar1 + 0x40) = uVar11;
    }
    iVar1 = *(int *)(param_1 + 0x84);
    if (iVar1 != 0) {
      uVar2 = *(undefined4 *)(param_1 + 0x30);
      uVar16 = *(undefined4 *)(param_1 + 0x34);
      uVar3 = *(undefined4 *)(param_1 + 0x38);
      uVar4 = *(undefined4 *)(param_1 + 0x3c);
      uVar5 = *(undefined4 *)(param_1 + 0x40);
      uVar6 = *(undefined4 *)(param_1 + 0x44);
      uVar7 = *(undefined4 *)(param_1 + 0x48);
      uVar8 = *(undefined4 *)(param_1 + 0x4c);
      uVar9 = *(undefined4 *)(param_1 + 0x50);
      uVar10 = *(undefined4 *)(param_1 + 0x54);
      uVar11 = *(undefined4 *)(param_1 + 0x58);
      *(undefined4 *)(iVar1 + 0x14) = *puVar14;
      *(undefined4 *)(iVar1 + 0x18) = uVar2;
      *(undefined4 *)(iVar1 + 0x1c) = uVar16;
      *(undefined4 *)(iVar1 + 0x20) = uVar3;
      *(undefined4 *)(iVar1 + 0x24) = uVar4;
      *(undefined4 *)(iVar1 + 0x28) = uVar5;
      *(undefined4 *)(iVar1 + 0x2c) = uVar6;
      *(undefined4 *)(iVar1 + 0x30) = uVar7;
      *(undefined4 *)(iVar1 + 0x34) = uVar8;
      *(undefined4 *)(iVar1 + 0x38) = uVar9;
      *(undefined4 *)(iVar1 + 0x3c) = uVar10;
      *(undefined4 *)(iVar1 + 0x40) = uVar11;
    }
    iVar1 = *(int *)(param_1 + 0x88);
    if (iVar1 != 0) {
      uVar2 = *(undefined4 *)(param_1 + 0x30);
      uVar16 = *(undefined4 *)(param_1 + 0x34);
      uVar3 = *(undefined4 *)(param_1 + 0x38);
      uVar4 = *(undefined4 *)(param_1 + 0x3c);
      uVar5 = *(undefined4 *)(param_1 + 0x40);
      uVar6 = *(undefined4 *)(param_1 + 0x44);
      uVar7 = *(undefined4 *)(param_1 + 0x48);
      uVar8 = *(undefined4 *)(param_1 + 0x4c);
      uVar9 = *(undefined4 *)(param_1 + 0x50);
      uVar10 = *(undefined4 *)(param_1 + 0x54);
      uVar11 = *(undefined4 *)(param_1 + 0x58);
      *(undefined4 *)(iVar1 + 0x14) = *puVar14;
      *(undefined4 *)(iVar1 + 0x18) = uVar2;
      *(undefined4 *)(iVar1 + 0x1c) = uVar16;
      *(undefined4 *)(iVar1 + 0x20) = uVar3;
      *(undefined4 *)(iVar1 + 0x24) = uVar4;
      *(undefined4 *)(iVar1 + 0x28) = uVar5;
      *(undefined4 *)(iVar1 + 0x2c) = uVar6;
      *(undefined4 *)(iVar1 + 0x30) = uVar7;
      *(undefined4 *)(iVar1 + 0x34) = uVar8;
      *(undefined4 *)(iVar1 + 0x38) = uVar9;
      *(undefined4 *)(iVar1 + 0x3c) = uVar10;
      *(undefined4 *)(iVar1 + 0x40) = uVar11;
    }
    uVar2 = *(undefined4 *)(param_1 + -0x70);
    uVar16 = FUN_00c9f550(&uStack_68,puVar14);
    FUN_008411b0(uVar16,uVar2);
  }
  return;
}



/* FUNCTION 13044 ; VA 0x00854640 ; FUN_00854640 */

void __fastcall FUN_00854640(int *param_1)

{
  if (param_1[3] == param_1[4]) {
    if (param_1 == (int *)0x74) {
      param_1 = (int *)0x0;
    }
    FUN_007c64b0(param_1);
    return;
  }
  FUN_008529a0();
  (**(code **)(*param_1 + 0x44))();
  *(undefined *)(param_1 + 0x1d) = 0;
  return;
}



/* FUNCTION 13045 ; VA 0x00854680 ; FUN_00854680 */

void __thiscall FUN_00854680(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  
  cVar1 = FUN_00841130();
  if ((cVar1 == '\0') && (param_4 == 0)) {
    piVar2 = (int *)(param_1 + 0xec);
    iVar3 = 5;
    do {
      if (*piVar2 != 0) {
        FUN_0082e2a0(*piVar2);
      }
      piVar2 = piVar2 + 1;
      iVar3 = iVar3 + -1;
    } while (iVar3 != 0);
    if (*(char *)(*(int *)(*(int *)(param_1 + 8) + 0x510) + 0x20) != '\0') {
      FUN_008416d0(*(int *)(param_1 + 8),param_1 + 0x18);
    }
  }
  return;
}



/* FUNCTION 13046 ; VA 0x008546f0 ; FUN_008546f0 */

int __thiscall FUN_008546f0(int *param_1,int param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  
  iVar7 = *param_1;
  iVar6 = (param_1[1] - iVar7) / 0x2c;
  if (iVar6 == 0x5d1745d) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar8 = iVar6 + 1;
  uVar2 = (param_1[2] - iVar7) / 0x2c;
  uVar9 = uVar8;
  if ((uVar2 <= 0x5d1745d - (uVar2 >> 1)) && (uVar9 = (uVar2 >> 1) + uVar2, uVar9 < uVar8)) {
    uVar9 = uVar8;
  }
  iVar6 = FUN_00716c50(uVar9);
  iVar7 = ((param_2 - iVar7) / 0x2c) * 0x2c;
  puVar1 = (undefined4 *)(iVar7 + iVar6);
  uVar3 = param_3[1];
  uVar4 = param_3[2];
  uVar5 = param_3[3];
  *puVar1 = *param_3;
  puVar1[1] = uVar3;
  puVar1[2] = uVar4;
  puVar1[3] = uVar5;
  uVar3 = param_3[5];
  uVar4 = param_3[6];
  uVar5 = param_3[7];
  puVar1[4] = param_3[4];
  puVar1[5] = uVar3;
  puVar1[6] = uVar4;
  puVar1[7] = uVar5;
  *(undefined8 *)(puVar1 + 8) = *(undefined8 *)(param_3 + 8);
  puVar1[10] = param_3[10];
  if (param_2 == param_1[1]) {
    FUN_008553a0(*param_1,param_1[1],iVar6);
  }
  else {
    FUN_00855360(*param_1,param_2,iVar6);
    FUN_00855360(param_2,param_1[1],puVar1 + 0xb);
  }
  FUN_00855260(iVar6,uVar8,uVar9);
  return *param_1 + iVar7;
}



/* FUNCTION 13047 ; VA 0x008546ff ; FUN_008546ff */

int __fastcall FUN_008546ff(int *param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int in_EAX;
  int iVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  int unaff_EBP;
  uint uVar11;
  
  iVar7 = *param_1;
  iVar8 = param_1[1];
  iVar9 = (int)((ulonglong)((longlong)in_EAX * (longlong)(param_2 - iVar7)) >> 0x20);
  *(int *)(unaff_EBP + -4) = (iVar9 >> 3) - (iVar9 >> 0x1f);
  iVar8 = (iVar8 - iVar7) / 0x2c;
  if (iVar8 == 0x5d1745d) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar10 = iVar8 + 1;
  uVar3 = (param_1[2] - iVar7) / 0x2c;
  uVar11 = uVar10;
  if ((uVar3 <= 0x5d1745d - (uVar3 >> 1)) && (uVar11 = (uVar3 >> 1) + uVar3, uVar11 < uVar10)) {
    uVar11 = uVar10;
  }
  iVar7 = FUN_00716c50(uVar11);
  iVar8 = *(int *)(unaff_EBP + -4) * 0x2c;
  puVar1 = (undefined4 *)(iVar8 + iVar7);
  *(int *)(unaff_EBP + -8) = iVar7;
  *(undefined4 **)(unaff_EBP + -4) = puVar1;
  *(int *)(unaff_EBP + -0xc) = iVar8;
  puVar2 = *(undefined4 **)(unaff_EBP + 0xc);
  uVar4 = puVar2[1];
  uVar5 = puVar2[2];
  uVar6 = puVar2[3];
  *puVar1 = *puVar2;
  puVar1[1] = uVar4;
  puVar1[2] = uVar5;
  puVar1[3] = uVar6;
  uVar4 = puVar2[5];
  uVar5 = puVar2[6];
  uVar6 = puVar2[7];
  puVar1[4] = puVar2[4];
  puVar1[5] = uVar4;
  puVar1[6] = uVar5;
  puVar1[7] = uVar6;
  *(undefined8 *)(puVar1 + 8) = *(undefined8 *)(puVar2 + 8);
  puVar1[10] = puVar2[10];
  if (*(int *)(unaff_EBP + 8) == param_1[1]) {
    FUN_008553a0(*param_1,param_1[1],iVar7);
  }
  else {
    FUN_00855360(*param_1,*(int *)(unaff_EBP + 8),iVar7);
    FUN_00855360(*(undefined4 *)(unaff_EBP + 8),param_1[1],*(int *)(unaff_EBP + -4) + 0x2c);
  }
  FUN_00855260(*(undefined4 *)(unaff_EBP + -8),uVar10,uVar11);
  return *param_1 + *(int *)(unaff_EBP + -0xc);
}



/* FUNCTION 13048 ; VA 0x00854800 ; FUN_00854800 */

undefined4 * __thiscall FUN_00854800(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  undefined2 auStack_34 [2];
  undefined4 uStack_30;
  undefined uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined2 uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined2 uStack_14;
  undefined uStack_12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7f01;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  FUN_00841300(param_2,0);
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x1d] = RBX::GfxPart::vftable;
  param_1[0x23] = 0xffffffff;
  param_1[0x24] = RBX::Graphics::Renderable::vftable;
  param_1[0x25] = RBX::Graphics::PlaneEffect::vftable;
  *param_1 = RBX::Graphics::BeamNode::vftable;
  param_1[0x1d] = RBX::Graphics::BeamNode::vftable;
  param_1[0x24] = RBX::Graphics::BeamNode::vftable;
  param_1[0x25] = RBX::Graphics::BeamNode::vftable;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  *(undefined *)(param_1 + 0x28) = 1;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  uStack_8._0_1_ = 5;
  uStack_8._1_3_ = 0;
  FUN_0147c770();
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  uStack_8._0_1_ = 10;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0x3f800000;
  param_1[0x3d] = 0;
  param_1[0x3e] = 0;
  param_1[0x3f] = 0;
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  param_1[0x43] = 0;
  param_1[0x44] = 0;
  param_1[0x45] = 1;
  *(undefined2 *)(param_1 + 0x46) = 1;
  param_1[0x47] = 0;
  param_1[0x48] = 0;
  FUN_016827e0(param_1 + 0x4a);
  param_1[0x4c] = 0;
  param_1[0x4d] = 0;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  uStack_8._0_1_ = 0xc;
  param_1[0x50] = 0x3f800000;
  param_1[0x51] = 0;
  param_1[0x52] = 0;
  param_1[0x53] = 0;
  param_1[0x54] = 0x3f800000;
  param_1[0x55] = 0;
  param_1[0x56] = 0;
  param_1[0x57] = 0;
  iVar6 = 0x20;
  param_1[0x58] = 0x3f800000;
  param_1[0x59] = 0;
  param_1[0x5a] = 0;
  param_1[0x5b] = 0;
  param_1[0x5c] = 0x3f800000;
  param_1[0x5d] = 0;
  param_1[0x5e] = 0;
  param_1[0x5f] = 0;
  param_1[0x60] = 0x3f800000;
  param_1[0x61] = 0;
  param_1[0x62] = 0;
  param_1[99] = 0;
  param_1[100] = 0x3f800000;
  param_1[0x65] = 0;
  param_1[0x66] = 0;
  param_1[0x67] = 0;
  *(undefined *)(param_1 + 0x68) = 0;
  do {
    FUN_00569440();
    iVar6 = iVar6 + -1;
  } while (iVar6 != 0);
  uVar3 = FUN_01675290(DAT_01eb41bc);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  param_1[0x29] = param_2[0x141];
  uStack_1c = uVar3;
  FUN_00832180(param_2);
  iVar6 = param_1[0x29];
  iVar5 = *(int *)(iVar6 + 0x18);
  if (iVar5 != 0) {
    LOCK();
    *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
    UNLOCK();
    iVar5 = *(int *)(iVar6 + 0x18);
  }
  param_1[0x2d] = *(undefined4 *)(iVar6 + 0x14);
  piVar1 = (int *)param_1[0x2e];
  param_1[0x2e] = iVar5;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar6 = piVar1[1] + -1;
    piVar1[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar6 = piVar1[2] + -1;
      piVar1[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  param_1[0x2f] = 0;
  if ((uint)((int)(param_1[0x2c] - param_1[0x2a]) / 0x2c) < 0x3c) {
    FUN_008552d0(0x3c);
  }
  if ((*(int *)(param_1[0x29] + 0x1c) == 0) || (*(int *)(param_1[0x29] + 0x24) == 0)) {
    uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  }
  else {
    param_2 = (undefined4 *)FUN_01674e20(0x50);
    uStack_8._0_1_ = 0xf;
    if (param_2 == (undefined4 *)0x0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_0078ded0(param_1[0x29] + 0x24,0,0);
    }
    uStack_8._0_1_ = 0xd;
    FUN_007f76e0(uVar4);
    auStack_34[0] = 0;
    uStack_30 = 0;
    uStack_2c = 0;
    uStack_14 = 4;
    uStack_12 = 0;
    FUN_0078e530(auStack_34);
    FUN_0078e510(&uStack_14);
    uStack_24 = 0x60400;
    uStack_28 = 0xf;
    uStack_20 = (ushort)uStack_20._1_1_ << 8;
    FUN_0078e480(&uStack_28);
    uStack_28 = CONCAT22(uStack_28._2_2_,0x101);
    uStack_24 = 0;
    uStack_20 = 0;
    FUN_0078e550(0xf,*(int *)(*(int *)(param_1[2] + 0x4f8) + 0x44c) + 0x84,&uStack_28);
    param_2 = (undefined4 *)FUN_01674e20(0x50);
    uStack_8._0_1_ = 0x10;
    if (param_2 == (undefined4 *)0x0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_0078ded0(param_1[0x29] + 0x34,0,0);
    }
    uStack_8._0_1_ = 0xd;
    FUN_007f76e0(uVar4);
    FUN_0078e530(auStack_34);
    FUN_0078e510(&uStack_14);
    uStack_24 = 0x60400;
    uStack_28 = 0xf;
    uStack_20 = uStack_20 & 0xff00;
    FUN_0078e480(&uStack_28);
    uStack_28._0_2_ = 0x101;
    uStack_24 = 0;
    uStack_20 = 0;
    FUN_0078e550(1,*(int *)(param_1[2] + 0x4f8) + 0x46c,&uStack_28);
    uStack_28 = CONCAT22(uStack_28._2_2_,0x101);
    uStack_24 = 0;
    uStack_20 = 0;
    FUN_0078e550(0xf,*(int *)(*(int *)(param_1[2] + 0x4f8) + 0x44c) + 0x84,&uStack_28);
    cVar2 = FUN_0078b7d0();
    if (cVar2 != '\0') {
      param_2 = (undefined4 *)FUN_01674e20(0x50);
      uStack_8._0_1_ = 0x11;
      if (param_2 == (undefined4 *)0x0) {
        uVar4 = 0;
      }
      else {
        uVar4 = FUN_0078ded0(param_1[0x29] + 0x44,0,0);
      }
      uStack_8._0_1_ = 0xd;
      FUN_007f76e0(uVar4);
      FUN_0078e530(auStack_34);
      FUN_0078e510(&uStack_14);
      uStack_24 = 0x60400;
      uStack_28 = 0xf;
      uStack_20 = uStack_20 & 0xff00;
      FUN_0078e480(&uStack_28);
      uStack_28._0_2_ = 0x101;
      uStack_24 = 0;
      uStack_20 = 0;
      FUN_0078e550(1,*(int *)(param_1[2] + 0x4f8) + 0x474,&uStack_28);
      uStack_28 = CONCAT22(uStack_28._2_2_,0x101);
      uStack_24 = 0;
      uStack_20 = 0;
      FUN_0078e550(0xf,*(int *)(*(int *)(param_1[2] + 0x4f8) + 0x44c) + 0x84,&uStack_28);
    }
    cVar2 = FUN_0078ba00();
    if (cVar2 != '\0') {
      param_2 = (undefined4 *)FUN_01674e20(0x50);
      uStack_8._0_1_ = 0x12;
      if (param_2 == (undefined4 *)0x0) {
        uVar4 = 0;
      }
      else {
        uVar4 = FUN_0078ded0(param_1[0x29] + 0x54,0,0);
      }
      uStack_8._0_1_ = 0xd;
      FUN_007f76e0(uVar4);
      FUN_0078e530(auStack_34);
      FUN_0078e510(&uStack_14);
      uStack_24 = 0x60400;
      uStack_28 = 0xf;
      uStack_20 = uStack_20 & 0xff00;
      FUN_0078e480(&uStack_28);
      uStack_28._0_2_ = 0x101;
      uStack_24 = 0;
      uStack_20 = 0;
      FUN_0078e550(1,*(int *)(param_1[2] + 0x4f8) + 0x474,&uStack_28);
      uStack_28 = CONCAT22(uStack_28._2_2_,0x101);
      uStack_24 = 0;
      uStack_20 = 0;
      FUN_0078e550(0xf,*(int *)(*(int *)(param_1[2] + 0x4f8) + 0x44c) + 0x84,&uStack_28);
    }
    param_2 = param_1 + 0x25;
    FUN_00708ea0(&uStack_24,&param_2,param_2);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
  }
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13049 ; VA 0x00854fa0 ; FUN_00854fa0 */

undefined4 * __fastcall FUN_00854fa0(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  return param_1;
}



/* FUNCTION 13050 ; VA 0x00854ff0 ; FUN_00854ff0 */

void __fastcall FUN_00854ff0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  puStack_14 = param_1 + 0x25;
  ExceptionList = &pvStack_10;
  *puStack_14 = RBX::Graphics::BeamNode::vftable;
  *param_1 = RBX::Graphics::BeamNode::vftable;
  param_1[0x1d] = RBX::Graphics::BeamNode::vftable;
  param_1[0x24] = RBX::Graphics::BeamNode::vftable;
  FUN_00831e60(&puStack_14);
  FUN_011590c0();
  param_1[0x26] = 0;
  piVar2 = (int *)param_1[0x27];
  param_1[0x27] = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_007c78a0(param_1 + 0x1d,0);
  piVar2 = (int *)param_1[0x4f];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = (int *)param_1[0x4d];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = (int *)param_1[0x3a];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x38];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x36];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x34];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x2e];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_0072e310();
  piVar2 = (int *)param_1[0x27];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  param_1[0x25] = RBX::Graphics::PlaneEffect::vftable;
  FUN_007f6360();
  FUN_01158110();
  FUN_00841420();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13051 ; VA 0x00855207 ; FUN_00855207 */

void FUN_00855207(void)

{
  FUN_00855230();
  return;
}



/* FUNCTION 13052 ; VA 0x0085520f ; FUN_0085520f */

void FUN_0085520f(void)

{
  FUN_00855230();
  return;
}



/* FUNCTION 13053 ; VA 0x0085521a ; FUN_0085521a */

void FUN_0085521a(void)

{
  FUN_00855230();
  return;
}



/* FUNCTION 13054 ; VA 0x00855230 ; FUN_00855230 */

undefined4 __thiscall FUN_00855230(undefined4 param_1,byte param_2)

{
  FUN_00854ff0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x3a8);
  }
  return param_1;
}



/* FUNCTION 13055 ; VA 0x00855260 ; FUN_00855260 */

void __thiscall FUN_00855260(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x2c) * 0x2c;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  *param_1 = param_2;
  param_1[1] = param_3 * 0x2c + param_2;
  param_1[2] = param_4 * 0x2c + param_2;
  return;
}



/* FUNCTION 13056 ; VA 0x008552d0 ; FUN_008552d0 */

void __thiscall FUN_008552d0(int *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 *puVar9;
  int iVar10;
  
  iVar2 = param_1[1];
  iVar3 = *param_1;
  iVar8 = FUN_00716c50(param_2);
  puVar9 = (undefined4 *)*param_1;
  puVar4 = (undefined4 *)param_1[1];
  if (puVar9 != puVar4) {
    iVar10 = iVar8 - (int)puVar9;
    do {
      uVar5 = puVar9[1];
      uVar6 = puVar9[2];
      uVar7 = puVar9[3];
      puVar1 = (undefined4 *)(iVar10 + (int)puVar9);
      *puVar1 = *puVar9;
      puVar1[1] = uVar5;
      puVar1[2] = uVar6;
      puVar1[3] = uVar7;
      uVar5 = puVar9[5];
      uVar6 = puVar9[6];
      uVar7 = puVar9[7];
      puVar1 = (undefined4 *)(iVar10 + 0x10 + (int)puVar9);
      *puVar1 = puVar9[4];
      puVar1[1] = uVar5;
      puVar1[2] = uVar6;
      puVar1[3] = uVar7;
      *(undefined8 *)(iVar10 + 0x20 + (int)puVar9) = *(undefined8 *)(puVar9 + 8);
      *(undefined4 *)(iVar10 + 0x28 + (int)puVar9) = puVar9[10];
      puVar9 = puVar9 + 0xb;
    } while (puVar9 != puVar4);
  }
  FUN_00855260(iVar8,(iVar2 - iVar3) / 0x2c,param_2);
  return;
}



/* FUNCTION 13057 ; VA 0x00855360 ; FUN_00855360 */

void FUN_00855360(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  if (param_1 != param_2) {
    do {
      uVar2 = param_1[1];
      uVar3 = param_1[2];
      uVar4 = param_1[3];
      *param_3 = *param_1;
      param_3[1] = uVar2;
      param_3[2] = uVar3;
      param_3[3] = uVar4;
      uVar2 = param_1[5];
      uVar3 = param_1[6];
      uVar4 = param_1[7];
      param_3[4] = param_1[4];
      param_3[5] = uVar2;
      param_3[6] = uVar3;
      param_3[7] = uVar4;
      *(undefined8 *)(param_3 + 8) = *(undefined8 *)(param_1 + 8);
      puVar1 = param_1 + 10;
      param_1 = param_1 + 0xb;
      param_3[10] = *puVar1;
      param_3 = param_3 + 0xb;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 13058 ; VA 0x008553a0 ; FUN_008553a0 */

void FUN_008553a0(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  if (param_1 != param_2) {
    param_3 = param_3 - (int)param_1;
    do {
      uVar2 = param_1[1];
      uVar3 = param_1[2];
      uVar4 = param_1[3];
      puVar1 = (undefined4 *)(param_3 + (int)param_1);
      *puVar1 = *param_1;
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      uVar2 = param_1[5];
      uVar3 = param_1[6];
      uVar4 = param_1[7];
      puVar1 = (undefined4 *)(param_3 + 0x10 + (int)param_1);
      *puVar1 = param_1[4];
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      *(undefined8 *)(param_3 + 0x20 + (int)param_1) = *(undefined8 *)(param_1 + 8);
      *(undefined4 *)(param_3 + 0x28 + (int)param_1) = param_1[10];
      param_1 = param_1 + 0xb;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 13059 ; VA 0x008553f0 ; FUN_008553f0 */

void __fastcall FUN_008553f0(int *param_1)

{
  int *piVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  char cVar7;
  float fVar8;
  undefined uVar9;
  undefined *puVar10;
  char *pcVar11;
  undefined4 *puVar12;
  float *pfVar13;
  char *pcVar14;
  uint uVar15;
  int *piVar16;
  int *piVar17;
  uint uVar18;
  int iVar19;
  float fVar20;
  double dVar21;
  undefined auStack_3b0 [384];
  undefined auStack_230 [8];
  float afStack_228 [30];
  float afStack_1b0 [65];
  uint uStack_ac;
  undefined4 uStack_9c;
  uint uStack_98;
  uint uStack_94;
  undefined4 uStack_84;
  uint uStack_80;
  uint uStack_7c;
  undefined4 uStack_6c;
  uint uStack_68;
  uint auStack_60 [4];
  undefined4 uStack_50;
  uint uStack_4c;
  uint auStack_48 [4];
  undefined4 uStack_38;
  int *piStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_017b7f2b;
  pvStack_1c = ExceptionList;
  if (param_1[0x26] != 0) {
    cVar7 = *(char *)(param_1[0x26] + 0x68);
    ExceptionList = &pvStack_1c;
    piStack_2c = param_1;
    puVar10 = &stack0xfffffffc;
    if (*(char *)(param_1 + 0x46) != cVar7) {
      ExceptionList = &pvStack_1c;
      *(char *)(param_1 + 0x46) = cVar7;
      FUN_00856010();
      puVar10 = puStack_20;
    }
    puStack_20 = puVar10;
    uStack_24 = FUN_00712f10();
    iStack_28 = 0x20;
    do {
      iStack_28 = iStack_28 + -1;
      FUN_00569440();
    } while (iStack_28 != 0);
    iVar19 = 0x20;
    do {
      FUN_00569440();
      iVar19 = iVar19 + -1;
    } while (iVar19 != 0);
    FUN_00a91b00(auStack_230,auStack_3b0,0x20);
    fVar20 = DAT_018f9000;
    iVar19 = 0x20;
    pfVar13 = afStack_228;
    piVar16 = piStack_2c + 0x89;
    do {
      fVar2 = *pfVar13;
      *(ulonglong *)piVar16 = CONCAT44(pfVar13[-1] * fVar20,pfVar13[-2] * fVar20);
      piStack_34 = (int *)(fVar2 * fVar20);
      piVar16[2] = (int)(fVar2 * fVar20);
      iVar19 = iVar19 + -1;
      pfVar13 = pfVar13 + 3;
      piVar16 = piVar16 + 3;
    } while (iVar19 != 0);
    uStack_24 = FUN_00d3c220();
    iVar19 = 0x20;
    do {
      FUN_005502b0();
      iVar19 = iVar19 + -1;
    } while (iVar19 != 0);
    FUN_00a935e0(afStack_1b0,0x20,0,0x3f800000);
    piVar16 = piStack_2c;
    fVar8 = DAT_018f9000;
    fVar2 = DAT_018ce2f8;
    fVar20 = DAT_018ce2f4;
    iVar19 = 0;
    pfVar13 = (float *)(piStack_2c + 0x6a);
    do {
      fVar3 = afStack_1b0[iVar19 * 2 + 3];
      fVar4 = afStack_1b0[iVar19 * 2 + 2];
      pfVar13[-1] = (fVar2 - (afStack_1b0[iVar19 * 2 + 1] + afStack_1b0[iVar19 * 2]) * fVar20) *
                    fVar8;
      fVar5 = afStack_1b0[iVar19 * 2 + 5];
      fVar6 = afStack_1b0[iVar19 * 2 + 4];
      *pfVar13 = (fVar2 - (fVar3 + fVar4) * fVar20) * fVar8;
      fVar3 = afStack_1b0[iVar19 * 2 + 7];
      fVar4 = afStack_1b0[iVar19 * 2 + 6];
      pfVar13[1] = (fVar2 - (fVar5 + fVar6) * fVar20) * fVar8;
      fVar5 = afStack_1b0[iVar19 * 2 + 9];
      fVar6 = afStack_1b0[iVar19 * 2 + 8];
      pfVar13[2] = (fVar2 - (fVar3 + fVar4) * fVar20) * fVar8;
      fVar3 = afStack_1b0[iVar19 * 2 + 0xb];
      fVar4 = afStack_1b0[iVar19 * 2 + 10];
      pfVar13[3] = (fVar2 - (fVar5 + fVar6) * fVar20) * fVar8;
      fVar5 = afStack_1b0[iVar19 * 2 + 0xd];
      fVar6 = afStack_1b0[iVar19 * 2 + 0xc];
      pfVar13[4] = (fVar2 - (fVar3 + fVar4) * fVar20) * fVar8;
      fVar3 = afStack_1b0[iVar19 * 2 + 0xf];
      fVar4 = afStack_1b0[iVar19 * 2 + 0xe];
      iVar19 = iVar19 + 8;
      pfVar13[5] = (fVar2 - (fVar5 + fVar6) * fVar20) * fVar8;
      pfVar13[6] = (fVar2 - (fVar3 + fVar4) * fVar20) * fVar8;
      pfVar13 = pfVar13 + 8;
    } while (iVar19 < 0x20);
    uStack_50 = 0;
    uStack_4c = 0xf;
    auStack_60[0] = auStack_60[0] & 0xffffff00;
    FUN_005542c0("Texture",7);
    iStack_14 = 0;
    uStack_24 = FUN_00d10320(piVar16[0x26],auStack_60);
    iStack_14._0_1_ = 1;
    pcVar11 = (char *)FUN_00d3acc0();
    if (0xf < *(uint *)(pcVar11 + 0x14)) {
      pcVar11 = *(char **)pcVar11;
    }
    uStack_38 = 0;
    piStack_34 = (int *)&DAT_0000000f;
    auStack_48[0] = auStack_48[0] & 0xffffff00;
    pcVar14 = pcVar11;
    do {
      cVar7 = *pcVar14;
      pcVar14 = pcVar14 + 1;
    } while (cVar7 != '\0');
    FUN_005542c0(pcVar11,(int)pcVar14 - (int)(pcVar11 + 1));
    iStack_14._0_1_ = 2;
    FUN_00856200(auStack_48,uStack_24);
    iStack_14._0_1_ = 1;
    uVar9 = (undefined)iStack_14;
    iStack_14._0_1_ = 1;
    if (&DAT_0000000f < piStack_34) {
      piVar17 = (int *)((int)piStack_34 + 1);
      uVar15 = auStack_48[0];
      if ((int *)0xfff < piVar17) {
        uVar15 = *(uint *)(auStack_48[0] - 4);
        piVar17 = piStack_34 + 9;
        if (0x1f < (auStack_48[0] - uVar15) - 4) {
          iStack_14._0_1_ = uVar9;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar15,piVar17);
    }
    iStack_14 = (uint)iStack_14._1_3_ << 8;
    if (0xf < uStack_68) {
      uVar18 = uStack_68 + 1;
      uVar15 = uStack_7c;
      if (0xfff < uVar18) {
        uVar15 = *(uint *)(uStack_7c - 4);
        uVar18 = uStack_68 + 0x24;
        if (0x1f < (uStack_7c - uVar15) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar15,uVar18);
    }
    uStack_6c = 0;
    uStack_68 = 0xf;
    uStack_7c = uStack_7c & 0xffffff00;
    if (0xf < uStack_80) {
      uVar18 = uStack_80 + 1;
      uVar15 = uStack_94;
      if (0xfff < uVar18) {
        uVar15 = *(uint *)(uStack_94 - 4);
        uVar18 = uStack_80 + 0x24;
        if (0x1f < (uStack_94 - uVar15) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar15,uVar18);
    }
    uStack_84 = 0;
    uStack_80 = 0xf;
    uStack_94 = uStack_94 & 0xffffff00;
    if (0xf < uStack_98) {
      uVar18 = uStack_98 + 1;
      uVar15 = uStack_ac;
      if (0xfff < uVar18) {
        uVar15 = *(uint *)(uStack_ac - 4);
        uVar18 = uStack_98 + 0x24;
        if (0x1f < (uStack_ac - uVar15) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar15,uVar18);
    }
    uStack_9c = 0;
    uStack_98 = 0xf;
    uStack_ac = uStack_ac & 0xffffff00;
    iStack_14 = 0xffffffff;
    if (0xf < uStack_4c) {
      uVar18 = uStack_4c + 1;
      uVar15 = auStack_60[0];
      if (0xfff < uVar18) {
        uVar15 = *(uint *)(auStack_60[0] - 4);
        uVar18 = uStack_4c + 0x24;
        if (0x1f < (auStack_60[0] - uVar15) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar15,uVar18);
    }
    fVar20 = DAT_018e452c;
    iVar19 = *(int *)(piVar16[0x26] + 0x88);
    if (iVar19 < 1) {
      iVar19 = 1;
    }
    piVar16[0x45] = iVar19;
    fVar2 = *(float *)(piVar16[0x26] + 0xa4);
    if (fVar20 <= fVar2) {
      fVar20 = fVar2;
    }
    piVar16[0x3c] = (int)fVar20;
    puVar12 = (undefined4 *)FUN_00587490(auStack_30);
    piVar17 = piStack_2c;
    uStack_24 = *puVar12;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar19 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar19;
      UNLOCK();
      if (iVar19 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        piVar1 = piVar17 + 2;
        iVar19 = *piVar1 + -1;
        *piVar1 = iVar19;
        UNLOCK();
        if (iVar19 == 0) {
          (**(code **)(*piVar17 + 4))();
        }
      }
    }
    puVar12 = (undefined4 *)FUN_00587490(&uStack_38);
    piVar17 = piStack_34;
    iStack_28 = *puVar12;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar19 = piStack_34[1] + -1;
      piStack_34[1] = iVar19;
      UNLOCK();
      if (iVar19 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        piVar1 = piVar17 + 2;
        iVar19 = *piVar1 + -1;
        *piVar1 = iVar19;
        UNLOCK();
        if (iVar19 == 0) {
          (**(code **)(*piVar17 + 4))();
        }
      }
    }
    FUN_00856080(iStack_28,uStack_24);
    iVar19 = piVar16[0x26];
    piVar16[0x3d] = *(uint *)(iVar19 + 0xa8) ^ DAT_018c4ea0;
    piVar16[0x3f] = *(int *)(iVar19 + 0xb0);
    *(undefined *)((int)piVar16 + 0x119) = *(undefined *)(iVar19 + 0xb4);
    piVar16[0x40] = *(int *)(iVar19 + 0xc0);
    piVar16[0x41] = *(int *)(iVar19 + 0xc4);
    piVar16[0x42] = *(int *)(iVar19 + 0xac);
    piVar16[0x43] = *(int *)(iVar19 + 0xb8);
    piVar16[0x44] = *(int *)(iVar19 + 0xbc);
    piVar16[0x47] = *(int *)(iVar19 + 0x84);
    dVar21 = (double)*(float *)(iVar19 + 0xd0);
    FUN_017267a0();
    piVar16[0x48] = (int)(float)dVar21;
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 13060 ; VA 0x00855a30 ; FUN_00855a30 */

void FUN_00855a30(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 *puVar8;
  int *piVar9;
  int iVar10;
  undefined4 uStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7f61;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  iVar2 = *param_1;
  iVar3 = *(int *)(iVar2 + 0xc);
  ExceptionList = &pvStack_10;
  iVar7 = FUN_00d3bb40();
  iVar10 = 0;
  if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
      (uint)*(ushort *)(iVar7 + 0x1da)) {
    iVar10 = iVar2;
  }
  puVar8 = (undefined4 *)FUN_0060dcd0(auStack_24,iVar10);
  uVar4 = *puVar8;
  uVar5 = puVar8[1];
  *puVar8 = 0;
  puVar8[1] = 0;
  *(undefined4 *)(iStack_14 + 0x98) = uVar4;
  piVar9 = *(int **)(iStack_14 + 0x9c);
  *(undefined4 *)(iStack_14 + 0x9c) = uVar5;
  if (piVar9 != (int *)0x0) {
    LOCK();
    iVar2 = piVar9[1] + -1;
    piVar9[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar9)();
      LOCK();
      iVar2 = piVar9[2] + -1;
      piVar9[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar9 + 4))();
      }
    }
  }
  piVar9 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_20[1] + -1;
    piStack_20[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar9 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar9 + 4))();
      }
    }
  }
  iVar2 = iStack_14;
  if (*(int *)(iStack_14 + 0x98) != 0) {
    iVar3 = *param_1;
    iStack_8 = 0;
    piVar9 = (int *)FUN_01675290(DAT_02110da8);
    iStack_8._0_1_ = 1;
    piStack_20 = piVar9;
    puStack_18 = (undefined4 *)FUN_01674e20(0x28);
    if (puStack_18 == (undefined4 *)0x0) {
      puVar8 = (undefined4 *)0x0;
    }
    else {
      *puStack_18 = 0;
      puStack_18[1] = 1;
      puStack_18[2] = FUN_00819150;
      puStack_18[3] = _guard_check_icall;
      puStack_18[4] = 0;
      puStack_18[5] = iVar3 + 0x50;
      puStack_18[6] = FUN_00832940;
      puStack_18[7] = 0;
      puStack_18[8] = iVar2;
      puStack_18[9] = uStack_28;
      puVar8 = puStack_18;
    }
    FUN_016797d0(puVar8);
    if (puVar8 != (undefined4 *)0x0) {
      LOCK();
      puVar8[1] = puVar8[1] + 1;
      UNLOCK();
    }
    uStack_1c = 1;
    iStack_8._0_1_ = 2;
    puStack_18 = puVar8;
    FUN_01675290(piVar9);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    puVar6 = *(undefined4 **)(iStack_14 + 0x84);
    if (*(undefined4 **)(iStack_14 + 0x88) == puVar6) {
      FUN_006335f0(puVar6,&puStack_18);
      puVar8 = puStack_18;
    }
    else {
      *puVar6 = puVar8;
      *(int *)(iStack_14 + 0x84) = *(int *)(iStack_14 + 0x84) + 4;
      puVar8 = (undefined4 *)0x0;
    }
    iStack_8 = 0xffffffff;
    if (puVar8 != (undefined4 *)0x0) {
      piVar9 = puVar8 + 1;
      LOCK();
      iVar2 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_01674ea0(puVar8);
      }
    }
  }
  (**(code **)(*(int *)(iStack_14 + 0x74) + 8))();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13061 ; VA 0x00855c30 ; FUN_00855c30 */

undefined4 FUN_00855c30(void)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00587490(auStack_c);
  uVar2 = *puVar4;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return uVar2;
  }
  return uVar2;
}



/* FUNCTION 13062 ; VA 0x00855cb0 ; FUN_00855cb0 */

float10 __fastcall FUN_00855cb0(int param_1)

{
  return (float10)*(float *)(param_1 + 0x84);
}



/* FUNCTION 13063 ; VA 0x00855cc0 ; FUN_00855cc0 */

undefined4 __fastcall FUN_00855cc0(int param_1)

{
  return *(undefined4 *)(param_1 + 0x88);
}



/* FUNCTION 13064 ; VA 0x00855cf0 ; FUN_00855cf0 */

float10 __fastcall FUN_00855cf0(int param_1)

{
  return (float10)*(float *)(param_1 + 0x58);
}



/* FUNCTION 13065 ; VA 0x00855d00 ; FUN_00855d00 */

void __thiscall FUN_00855d00(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    uVar2 = param_2[1];
    uVar3 = param_2[2];
    uVar4 = param_2[3];
    *puVar1 = *param_2;
    puVar1[1] = uVar2;
    puVar1[2] = uVar3;
    puVar1[3] = uVar4;
    uVar2 = param_2[5];
    uVar3 = param_2[6];
    uVar4 = param_2[7];
    puVar1[4] = param_2[4];
    puVar1[5] = uVar2;
    puVar1[6] = uVar3;
    puVar1[7] = uVar4;
    *(undefined8 *)(puVar1 + 8) = *(undefined8 *)(param_2 + 8);
    puVar1[10] = param_2[10];
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x2c;
    return;
  }
  FUN_008546f0(puVar1,param_2);
  return;
}



/* FUNCTION 13066 ; VA 0x00855d50 ; FUN_00855d50 */

void __thiscall FUN_00855d50(int param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  float *pfVar2;
  bool bVar3;
  bool bVar4;
  char cVar5;
  float fVar6;
  float10 fVar7;
  float fVar8;
  double dVar9;
  float fVar10;
  float fVar11;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  float fStack_14;
  float fStack_10;
  undefined4 uStack_c;
  
  fVar6 = *(float *)(param_1 + -0x80);
  fVar7 = (float10)FUN_01156fe0(*(undefined4 *)(*(int *)(param_1 + -0x8c) + 0x5c4));
  if ((float)fVar7 <= fVar6) {
LAB_00855da6:
    bVar4 = false;
  }
  else {
    cVar5 = FUN_0078b7c0();
    bVar4 = true;
    if (cVar5 == '\0') goto LAB_00855da6;
  }
  fVar6 = *(float *)(param_1 + -0x80);
  fVar7 = (float10)FUN_01156fe0(*(undefined4 *)(*(int *)(param_1 + -0x8c) + 0x5c4));
  if (fVar6 < (float)fVar7) {
    cVar5 = FUN_0078bd20();
    if (cVar5 != '\0') {
      bVar3 = true;
      goto LAB_00855def;
    }
  }
  bVar3 = false;
LAB_00855def:
  fStack_10 = *(float *)(param_1 + 0x8c);
  if (fStack_10 <= DAT_018f784c) {
    fVar6 = *(float *)(param_1 + 0x38);
  }
  else if (bVar4) {
    fVar6 = *(float *)(param_1 + 0x50);
  }
  else if (bVar3) {
    fVar6 = *(float *)(param_1 + 0x48);
  }
  else {
    fVar6 = *(float *)(param_1 + 0x40);
  }
  if (fVar6 != 0.0) {
    uStack_18 = *(undefined4 *)(param_1 + 0x74);
    iVar1 = **(int **)(param_1 + 0x10);
    fStack_14 = DAT_018ce2f8 - *(float *)(param_1 + 0x88);
    uStack_c = 0;
    FUN_0078e4a0(1,&uStack_18,0x10);
    fStack_28 = DAT_018ce2f4;
    *(undefined4 *)(param_1 + 0x2c) = param_3;
    *(undefined4 *)(param_1 + 0x34) = param_4;
    fStack_30 = (*(float *)(param_1 + 0x100) + *(float *)(param_1 + 0xd0)) * fStack_28;
    fStack_2c = (*(float *)(param_1 + 0x104) + *(float *)(param_1 + 0xd4)) * fStack_28;
    fStack_28 = (*(float *)(param_1 + 0x108) + *(float *)(param_1 + 0xd8)) * fStack_28;
    fVar7 = (float10)FUN_00841650(iVar1 + 0x40,&fStack_30,DAT_01918c84 - *(float *)(param_1 + 0x74))
    ;
    fStack_24 = (float)fVar7;
    if (DAT_01d60f98 == '\0') {
      fStack_20 = 0.0;
    }
    else {
      fVar11 = *(float *)(param_1 + 0xd4) - *(float *)(param_1 + 0x104);
      fVar10 = *(float *)(param_1 + 0xd0) - *(float *)(param_1 + 0x100);
      fVar8 = *(float *)(param_1 + 0xd8) - *(float *)(param_1 + 0x108);
      dVar9 = (double)(fVar11 * fVar11 + fVar10 * fVar10 + fVar8 * fVar8);
      FUN_017267a0();
      fStack_20 = (float)dVar9 * DAT_018ce2f4 + DAT_018e452c +
                  (float)(double)CONCAT44((uint)((ulonglong)(double)*(float *)(param_1 + 0x74) >>
                                                0x20) & DAT_018c0da0._4_4_,
                                          SUB84((double)*(float *)(param_1 + 0x74),0) &
                                          (uint)DAT_018c0da0);
    }
    if (param_1 == 0x94) {
      fStack_30 = 0.0;
    }
    else {
      fStack_30 = (float)(param_1 + -4);
    }
    fStack_28 = (float)(param_1 + 0x20);
    pfVar2 = *(float **)(param_2 + 0x70);
    uStack_1c = 0;
    if (*(float **)(param_2 + 0x74) != pfVar2) {
      *pfVar2 = fStack_30;
      pfVar2[1] = fVar6;
      pfVar2[2] = fStack_28;
      pfVar2[3] = fStack_24;
      *(ulonglong *)(pfVar2 + 4) = (ulonglong)(uint)fStack_20;
      *(int *)(param_2 + 0x70) = *(int *)(param_2 + 0x70) + 0x18;
      return;
    }
    fStack_2c = fVar6;
    FUN_006c6730(pfVar2,&fStack_30);
  }
  return;
}



/* FUNCTION 13067 ; VA 0x00856010 ; FUN_00856010 */

void __fastcall FUN_00856010(int param_1)

{
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  *(undefined4 *)(param_1 + 0xf8) = 0;
  FUN_016827e0(&uStack_c);
  *(undefined4 *)(param_1 + 0x128) = uStack_c;
  *(undefined4 *)(param_1 + 300) = uStack_8;
  FUN_007c7a50(param_1 + 0x74,0);
  if (*(char *)(param_1 + 0x118) != '\0') {
    FUN_007c7840(param_1 + 0x74,0);
  }
  return;
}



/* FUNCTION 13068 ; VA 0x00856080 ; FUN_00856080 */

int * __thiscall FUN_00856080(int param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  bool bVar5;
  int *piVar6;
  int *piVar7;
  undefined4 *puVar8;
  undefined auStack_18 [4];
  int *piStack_14;
  undefined auStack_10 [4];
  int *piStack_c;
  char cStack_5;
  
  piStack_c = (int *)0x0;
  piVar7 = (int *)FUN_00587490(auStack_18);
  bVar5 = false;
  if (*piVar7 == param_2) {
    piVar7 = (int *)FUN_00587490(auStack_10);
    bVar5 = true;
    cStack_5 = '\x01';
    if (*piVar7 == param_3) goto LAB_008560cf;
  }
  cStack_5 = '\0';
LAB_008560cf:
  piVar6 = piStack_c;
  if ((bVar5) && (piStack_c != (int *)0x0)) {
    LOCK();
    piVar1 = piStack_c + 1;
    iVar2 = *piVar1;
    piVar7 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar2 = *piVar1;
      piVar7 = (int *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piVar7 = (int *)(**(code **)(*piVar6 + 4))();
      }
    }
  }
  piVar6 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    piVar7 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar2 = *piVar1;
      piVar7 = (int *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piVar7 = (int *)(**(code **)(*piVar6 + 4))();
      }
    }
  }
  if (cStack_5 == '\0') {
    puVar8 = (undefined4 *)FUN_0060e0c0(auStack_18,param_2);
    uVar3 = *puVar8;
    uVar4 = puVar8[1];
    *puVar8 = 0;
    puVar8[1] = 0;
    *(undefined4 *)(param_1 + 0x130) = uVar3;
    piVar7 = *(int **)(param_1 + 0x134);
    *(undefined4 *)(param_1 + 0x134) = uVar4;
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar2 = piVar7[2] + -1;
      piVar7[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar7 + 4))();
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_14[2] + -1;
      piStack_14[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
    puVar8 = (undefined4 *)FUN_0060e0c0(auStack_18,param_3);
    uVar3 = *puVar8;
    uVar4 = puVar8[1];
    *puVar8 = 0;
    puVar8[1] = 0;
    *(undefined4 *)(param_1 + 0x138) = uVar3;
    piVar7 = *(int **)(param_1 + 0x13c);
    *(undefined4 *)(param_1 + 0x13c) = uVar4;
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar2 = piVar7[2] + -1;
      piVar7[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar7 + 4))();
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar7 = piStack_14 + 2;
      iVar2 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
    piVar7 = (int *)FUN_00856010();
  }
  return piVar7;
}



/* FUNCTION 13069 ; VA 0x00856200 ; FUN_00856200 */

void * __thiscall FUN_00856200(int param_1,int param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  void *pvVar5;
  undefined auStack_3c [24];
  undefined2 auStack_24 [2];
  undefined4 uStack_20;
  undefined2 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017b7058;
  pvStack_10 = ExceptionList;
  pvVar5 = ExceptionList;
  if ((*(int *)(param_1 + 0xcc) != 0) && (*(int *)(param_1 + 0xd4) != 0)) {
    uStack_18 = 0;
    piStack_14 = (int *)0x0;
    iStack_8 = 0;
    if (*(int *)(param_2 + 0x10) == 0) {
      ExceptionList = &pvStack_10;
      FUN_007735a0(*(int *)(*(int *)(param_1 + 8) + 0x4ec) + 0x24,3);
      FUN_005587e0(&uStack_20);
      FUN_00550b30();
    }
    else {
      ExceptionList = &pvStack_10;
      FUN_0054ef60(param_2);
      iStack_8._0_1_ = 1;
      FUN_009cbbb0(auStack_3c);
      iStack_8._0_1_ = 2;
      uVar4 = FUN_00782480(&uStack_20,auStack_3c,1,param_3,0x425c0000,0);
      FUN_005587e0(uVar4);
      FUN_00550b30();
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_005507b0();
    }
    auStack_24[0] = 1;
    uStack_20 = 0;
    uStack_1c = 0;
    FUN_0078e550(0,&uStack_18,auStack_24);
    auStack_24[0] = 1;
    uStack_20 = 0;
    uStack_1c = 0;
    pvVar5 = (void *)FUN_0078e550(0,&uStack_18,auStack_24);
    if (*(int *)(param_1 + 0xdc) != 0) {
      auStack_24[0] = 1;
      uStack_20 = 0;
      uStack_1c = 0;
      pvVar5 = (void *)FUN_0078e550(0,&uStack_18,auStack_24);
    }
    if (*(int *)(param_1 + 0xe4) != 0) {
      auStack_24[0] = 1;
      uStack_20 = 0;
      uStack_1c = 0;
      pvVar5 = (void *)FUN_0078e550(0,&uStack_18,auStack_24);
    }
    piVar3 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar2 = *piVar1;
      pvVar5 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar5 = (void *)(**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar5 = (void *)(**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 13070 ; VA 0x008563d0 ; FUN_008563d0 */

void __fastcall FUN_008563d0(int param_1)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  undefined8 uStack_30;
  float fStack_28;
  undefined8 uStack_24;
  float fStack_1c;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  fStack_10 = *(float *)(param_1 + 0xd8);
  fStack_c = fStack_10;
  if (DAT_018c45c4 < fStack_10) {
    fStack_c = DAT_018c45c4;
  }
  fVar6 = *(float *)(param_1 + 0xd4);
  fStack_8 = fVar6;
  if (DAT_018c45c4 < fVar6) {
    fStack_8 = DAT_018c45c4;
  }
  fVar5 = *(float *)(param_1 + 0xd0);
  fVar4 = DAT_018c45c4;
  if (fVar5 <= DAT_018c45c4) {
    fVar4 = fVar5;
  }
  if (fStack_10 < DAT_018c45d0) {
    fStack_10 = DAT_018c45d0;
  }
  if (fVar6 < DAT_018c45d0) {
    fVar6 = DAT_018c45d0;
  }
  fVar3 = DAT_018c45d0;
  if (DAT_018c45d0 <= fVar5) {
    fVar3 = fVar5;
  }
  fStack_28 = *(float *)(param_1 + 0x108);
  if (fStack_c < fStack_28) {
    fStack_28 = fStack_c;
  }
  fVar5 = *(float *)(param_1 + 0x104);
  if (fVar5 <= fStack_8) {
    fStack_8 = fVar5;
  }
  fVar2 = *(float *)(param_1 + 0x100);
  if (fVar2 <= fVar4) {
    fVar4 = fVar2;
  }
  uStack_30 = CONCAT44(fStack_8,fVar4);
  if (fStack_10 <= *(float *)(param_1 + 0x108)) {
    fStack_10 = *(float *)(param_1 + 0x108);
  }
  if (fVar6 <= fVar5) {
    fVar6 = fVar5;
  }
  if (fVar3 <= fVar2) {
    fVar3 = fVar2;
  }
  uStack_24 = CONCAT44(fVar6,fVar3);
  fVar5 = *(float *)(param_1 + 0x70);
  pfVar1 = (float *)(param_1 + 0x70);
  if (fVar5 < *(float *)(param_1 + 0x6c) || fVar5 == *(float *)(param_1 + 0x6c)) {
    pfVar1 = (float *)(param_1 + 0x6c);
  }
  fVar5 = *(float *)(param_1 + 0x7c);
  if (*(float *)(param_1 + 0x7c) <= *(float *)(param_1 + 0x78)) {
    fVar5 = *(float *)(param_1 + 0x78);
  }
  fVar2 = *pfVar1;
  if (*pfVar1 <= fVar5) {
    fVar2 = fVar5;
  }
  fStack_1c = fStack_10;
  fVar5 = fStack_8;
  if (DAT_018ce2f0 < fVar2) {
    fVar2 = fVar2 * DAT_018ce2f4;
    fVar4 = fVar4 - fVar2;
    fVar6 = fVar2 + fVar6;
    fStack_28 = fStack_28 - fVar2;
    fVar3 = fVar3 + fVar2;
    uStack_30 = CONCAT44(fStack_8 - fVar2,fVar4);
    uStack_24 = CONCAT44(fVar6,fVar3);
    fStack_1c = fVar2 + fStack_10;
    fVar5 = fStack_8 - fVar2;
  }
  if (((((NAN(fVar4) || NAN(*(float *)(param_1 + -0x7c))) == (fVar4 == *(float *)(param_1 + -0x7c)))
       || ((NAN(fVar5) || NAN(*(float *)(param_1 + -0x78))) ==
           (fVar5 == *(float *)(param_1 + -0x78)))) ||
      ((NAN(fStack_28) || NAN(*(float *)(param_1 + -0x74))) ==
       (fStack_28 == *(float *)(param_1 + -0x74)))) ||
     ((((NAN(fVar3) || NAN(*(float *)(param_1 + -0x70))) == (fVar3 == *(float *)(param_1 + -0x70))
       || ((NAN(fVar6) || NAN(*(float *)(param_1 + -0x6c))) ==
           (fVar6 == *(float *)(param_1 + -0x6c)))) ||
      ((NAN(fStack_1c) || NAN(*(float *)(param_1 + -0x68))) ==
       (fStack_1c == *(float *)(param_1 + -0x68)))))) {
    FUN_008411b0(&uStack_30,*(undefined4 *)(param_1 + -0x90));
  }
  return;
}



/* FUNCTION 13071 ; VA 0x008565c0 ; FUN_008565c0 */

undefined4 * __fastcall FUN_008565c0(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined auStack_58 [48];
  int iStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7f80;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490(&puStack_18);
  uStack_8 = 0;
  FUN_00587490(&iStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if ((((puStack_18 != (undefined4 *)0x0) && (iStack_28 != 0)) && (puStack_18[0xd] != 0)) &&
     (*(int *)(iStack_28 + 0x34) != 0)) {
    puStack_18 = (undefined4 *)FUN_011584d0(puStack_18);
    if ((char)puStack_18 != '\0') {
      puStack_18 = (undefined4 *)FUN_011584d0(iStack_28);
      if ((char)puStack_18 != '\0') {
        puVar7 = (undefined4 *)FUN_00d6c6c0(auStack_58);
        uVar3 = puVar7[1];
        uVar4 = puVar7[2];
        uVar5 = puVar7[3];
        *(undefined4 *)(param_1 + 0xcc) = *puVar7;
        *(undefined4 *)(param_1 + 0xd0) = uVar3;
        *(undefined4 *)(param_1 + 0xd4) = uVar4;
        *(undefined4 *)(param_1 + 0xd8) = uVar5;
        uVar3 = puVar7[5];
        uVar4 = puVar7[6];
        uVar5 = puVar7[7];
        *(undefined4 *)(param_1 + 0xdc) = puVar7[4];
        *(undefined4 *)(param_1 + 0xe0) = uVar3;
        *(undefined4 *)(param_1 + 0xe4) = uVar4;
        *(undefined4 *)(param_1 + 0xe8) = uVar5;
        uVar3 = puVar7[9];
        uVar4 = puVar7[10];
        uVar5 = puVar7[0xb];
        *(undefined4 *)(param_1 + 0xec) = puVar7[8];
        *(undefined4 *)(param_1 + 0xf0) = uVar3;
        *(undefined4 *)(param_1 + 0xf4) = uVar4;
        *(undefined4 *)(param_1 + 0xf8) = uVar5;
        puStack_18 = (undefined4 *)FUN_00d6c6c0(auStack_58);
        uVar3 = puStack_18[1];
        uVar4 = puStack_18[2];
        uVar5 = puStack_18[3];
        *(undefined4 *)(param_1 + 0xfc) = *puStack_18;
        *(undefined4 *)(param_1 + 0x100) = uVar3;
        *(undefined4 *)(param_1 + 0x104) = uVar4;
        *(undefined4 *)(param_1 + 0x108) = uVar5;
        uVar3 = puStack_18[5];
        uVar4 = puStack_18[6];
        uVar5 = puStack_18[7];
        *(undefined4 *)(param_1 + 0x10c) = puStack_18[4];
        *(undefined4 *)(param_1 + 0x110) = uVar3;
        *(undefined4 *)(param_1 + 0x114) = uVar4;
        *(undefined4 *)(param_1 + 0x118) = uVar5;
        uVar3 = puStack_18[8];
        uVar4 = puStack_18[9];
        uVar5 = puStack_18[10];
        uVar6 = puStack_18[0xb];
        *(undefined *)(param_1 + 300) = 1;
        *(undefined4 *)(param_1 + 0x11c) = uVar3;
        *(undefined4 *)(param_1 + 0x120) = uVar4;
        *(undefined4 *)(param_1 + 0x124) = uVar5;
        *(undefined4 *)(param_1 + 0x128) = uVar6;
      }
    }
  }
  iVar2 = *(int *)(param_1 + 0x24);
  if ((iVar2 != 0) && (*(char *)(iVar2 + 0xcc) != '\0')) {
    *(undefined4 *)(param_1 + 0x84) = *(undefined4 *)(iVar2 + 200);
    *(undefined *)(iVar2 + 0xcc) = 0;
    FUN_016827e0(&uStack_20);
    *(undefined4 *)(param_1 + 0xb4) = uStack_20;
    *(undefined4 **)(param_1 + 0xb8) = puStack_1c;
    puStack_18 = puStack_1c;
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_24 + 1;
    iVar2 = *piVar1;
    puStack_18 = (undefined4 *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piStack_24 + 2;
      iVar2 = *piVar1;
      puStack_18 = (undefined4 *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        puStack_18 = (undefined4 *)(**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    puStack_18 = (undefined4 *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puStack_18 = (undefined4 *)(**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_18 = (undefined4 *)(**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puStack_18;
}



/* FUNCTION 13072 ; VA 0x00856750 ; FUN_00856750 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __thiscall FUN_00856750(int param_1,int param_2,uint param_3)

{
  float fVar1;
  float fVar2;
  undefined8 uVar3;
  undefined4 *puVar4;
  float fVar5;
  uint uVar6;
  double *pdVar7;
  undefined4 uVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  float *pfVar12;
  int *piVar13;
  float10 fVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  double dVar18;
  double dVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  float fVar23;
  float fVar24;
  float fVar25;
  float fVar26;
  float fVar27;
  float fVar28;
  float fVar29;
  float fVar30;
  float fVar31;
  float fVar32;
  float fVar33;
  float fVar34;
  float fVar35;
  float fStack_b0;
  float fStack_ac;
  int iStack_a8;
  int iStack_a4;
  undefined8 uStack_a0;
  float fStack_98;
  float fStack_90;
  float fStack_8c;
  float fStack_88;
  undefined8 uStack_84;
  float fStack_7c;
  float fStack_78;
  int *piStack_74;
  float fStack_70;
  float fStack_6c;
  double dStack_68;
  undefined8 uStack_60;
  float fStack_58;
  undefined8 uStack_50;
  float fStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  undefined4 uStack_28;
  float fStack_14;
  
  if (*(char *)(param_1 + 0x10c) == '\0') {
    return 0;
  }
  piVar13 = (int *)(param_1 + 0x14);
  *(undefined *)(param_1 + 0x10c) = 0;
  *(int *)(param_1 + 0x18) = *piVar13;
  piStack_74 = piVar13;
  pdVar7 = (double *)FUN_016827e0(&uStack_a0);
  dStack_68 = *pdVar7 - *(double *)(param_1 + 0x94);
  FUN_016827e0(&uStack_a0);
  *(float *)(param_1 + 0x94) = (float)uStack_a0;
  *(float *)(param_1 + 0x98) = uStack_a0._4_4_;
  uStack_a0 = (double)((float)dStack_68 * *(float *)(param_1 + 0x60) + *(float *)(param_1 + 100));
  fVar14 = (float10)FUN_01728560();
  *(float *)(param_1 + 100) = (float)fVar14;
  uVar3 = *(undefined8 *)(*(int *)(param_1 + -0x8c) + 0x40);
  fStack_7c = *(float *)(*(int *)(param_1 + -0x8c) + 0x48);
  uStack_84._0_4_ = (float)uVar3;
  uStack_84._4_4_ = (float)((ulonglong)uVar3 >> 0x20);
  uStack_84._4_4_ = uStack_84._4_4_ - *(float *)(param_1 + 0x104);
  uStack_84._0_4_ = (float)uStack_84 - *(float *)(param_1 + 0x100);
  fVar15 = fStack_7c - *(float *)(param_1 + 0x108);
  dVar18 = (double)(uStack_84._4_4_ * uStack_84._4_4_ + (float)uStack_84 * (float)uStack_84 +
                   fVar15 * fVar15);
  uStack_84 = uVar3;
  FUN_017267a0();
  fVar22 = uStack_84._4_4_ - *(float *)(param_1 + 0xd4);
  fVar20 = (float)uStack_84 - *(float *)(param_1 + 0xd0);
  fVar15 = fStack_7c - *(float *)(param_1 + 0xd8);
  dVar19 = (double)(fVar22 * fVar22 + fVar20 * fVar20 + fVar15 * fVar15);
  FUN_017267a0();
  fStack_ac = (float)dVar18;
  if ((float)dVar18 <= (float)dVar19) {
    fStack_ac = (float)dVar19;
  }
  fVar14 = (float10)FUN_01156c80();
  fStack_8c = *(float *)(param_1 + 0x104) - *(float *)(param_1 + 0xd4);
  fStack_88 = *(float *)(param_1 + 0x108) - *(float *)(param_1 + 0xd8);
  fVar22 = *(float *)(param_1 + 0x100) - *(float *)(param_1 + 0xd0);
  fVar15 = (float)(fVar14 * (float10)(DAT_018ce2f8 - (fStack_ac - DAT_01901960) / _DAT_01918c7c));
  fVar20 = DAT_018e452c;
  if (DAT_018e452c <= fVar15) {
    fVar20 = fVar15;
  }
  fVar15 = DAT_018ce2f8;
  if (fVar20 <= DAT_018ce2f8) {
    fVar15 = fVar20;
  }
  fStack_90 = (float)(int)((float)*(int *)(param_1 + 0x80) * fVar15);
  if ((int)fStack_90 < 1) {
    fStack_90 = 1.4013e-45;
  }
  if ((NAN(*(float *)(param_1 + 0x6c)) == (*(float *)(param_1 + 0x6c) == 0.0)) ||
     (NAN(*(float *)(param_1 + 0x70)) == (*(float *)(param_1 + 0x70) == 0.0))) {
    FUN_011612d0(&uStack_a0,0);
    fVar15 = *(float *)(param_1 + 0x6c);
    fVar25 = (float)uStack_a0 * fVar15;
    fVar20 = *(float *)(param_1 + 0xd0);
    fStack_70 = uStack_a0._4_4_ * fVar15 + *(float *)(param_1 + 0xd4);
    fStack_78 = fStack_98 * fVar15 + *(float *)(param_1 + 0xd8);
    FUN_011612d0(&uStack_a0,0);
    fVar15 = *(float *)(param_1 + 0x70);
    fVar21 = *(float *)(param_1 + 0x100);
    puVar4 = *(undefined4 **)(param_1 + 0x18);
    fVar23 = (float)uStack_a0 * fVar15;
    uStack_40 = 0;
    uStack_3c = 0;
    uStack_38 = 0;
    fStack_30 = 0.0;
    fStack_2c = 0.0;
    uStack_28 = 0;
    fStack_6c = *(float *)(param_1 + 0x104) - uStack_a0._4_4_ * fVar15;
    uStack_60._0_4_ = *(float *)(param_1 + 0x108) - fStack_98 * fVar15;
    uStack_50 = 0;
    fStack_48 = 0.0;
    uStack_44 = 0;
    if (*(undefined4 **)(param_1 + 0x1c) == puVar4) {
      FUN_008546f0(puVar4,&uStack_50);
    }
    else {
      *puVar4 = 0;
      puVar4[1] = 0;
      puVar4[2] = 0;
      puVar4[3] = 0;
      puVar4[4] = 0;
      puVar4[5] = 0;
      puVar4[6] = 0;
      puVar4[7] = fStack_34;
      *(undefined8 *)(puVar4 + 8) = 0;
      puVar4[10] = 0;
      *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 0x2c;
    }
    iVar9 = *(int *)(param_1 + 0x18);
    uVar8 = *(undefined4 *)(param_1 + 0xd8);
    *(undefined8 *)(iVar9 + -0x2c) = *(undefined8 *)(param_1 + 0xd0);
    *(undefined4 *)(iVar9 + -0x24) = uVar8;
    fStack_b0 = 1.4013e-45;
    if (0 < (int)fStack_90) {
      fStack_70 = fStack_70 * DAT_018df580;
      fVar20 = (fVar25 + fVar20) * DAT_018df580;
      fStack_78 = fStack_78 * DAT_018df580;
      fVar15 = (fVar21 - fVar23) * DAT_018df580;
      fStack_6c = fStack_6c * DAT_018df580;
      uStack_60._0_4_ = (float)uStack_60 * DAT_018df580;
      do {
        fStack_30 = 0.0;
        uStack_28 = 0;
        fVar32 = (float)(int)fStack_b0 / (float)(int)fStack_90;
        fVar27 = DAT_018ce2f8 - fVar32;
        uStack_44 = 0;
        uStack_40 = 0;
        uStack_3c = 0;
        uStack_38 = 0;
        fVar34 = fVar32 * fVar32;
        fVar21 = fVar27 * fVar27;
        fVar29 = fVar34 * fVar32;
        fVar25 = fVar21 * fVar27;
        fVar26 = fVar20 * fVar32 * fVar21 + fVar25 * *(float *)(param_1 + 0xd0) +
                 fVar34 * fVar15 * fVar27 + fVar29 * *(float *)(param_1 + 0x100);
        dStack_68 = (double)CONCAT44(dStack_68._4_4_,fVar26);
        fVar23 = fStack_70 * fVar32 * fVar21 + fVar25 * *(float *)(param_1 + 0xd4) +
                 fVar34 * fStack_6c * fVar27 + *(float *)(param_1 + 0x104) * fVar29;
        uStack_a0 = (double)CONCAT44(uStack_a0._4_4_,fVar23);
        fStack_48 = fStack_78 * fVar32 * fVar21 + fVar25 * *(float *)(param_1 + 0xd8) +
                    fVar34 * (float)uStack_60 * fVar27 + *(float *)(param_1 + 0x108) * fVar29;
        uStack_50 = CONCAT44(fVar23,fVar26);
        iVar9 = *(int *)(param_1 + 0x18);
        fVar23 = fVar23 - *(float *)(iVar9 + -0x28);
        fVar26 = fVar26 - *(float *)(iVar9 + -0x2c);
        fVar21 = fStack_48 - *(float *)(iVar9 + -0x24);
        dVar18 = (double)(fVar23 * fVar23 + fVar26 * fVar26 + fVar21 * fVar21);
        fStack_14 = fStack_48;
        FUN_017267a0();
        if ((DAT_018fde58 <= (float)dVar18) || (fStack_b0 == fStack_90)) {
          puVar4 = *(undefined4 **)(param_1 + 0x18);
          fStack_2c = *(float *)(*(int *)(param_1 + 0x18) + -8) + (float)dVar18;
          if (*(undefined4 **)(param_1 + 0x1c) == puVar4) {
            FUN_008546f0(puVar4,&uStack_50);
          }
          else {
            *puVar4 = (undefined4)uStack_50;
            puVar4[1] = uStack_50._4_4_;
            puVar4[2] = fStack_48;
            puVar4[3] = uStack_44;
            puVar4[4] = uStack_40;
            puVar4[5] = uStack_3c;
            puVar4[6] = uStack_38;
            puVar4[7] = fStack_34;
            *(ulonglong *)(puVar4 + 8) = CONCAT44(fStack_2c,fStack_30);
            puVar4[10] = uStack_28;
            *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 0x2c;
          }
        }
        fStack_b0 = (float)((int)fStack_b0 + 1);
      } while ((int)fStack_b0 <= (int)fStack_90);
    }
    fVar15 = *(float *)(*(int *)(param_1 + 0x18) + -8);
    if (NAN(fVar15) != (fVar15 == 0.0)) {
      return 0;
    }
    iVar9 = *(int *)(param_1 + 0x18);
    for (iVar10 = *piVar13; iVar10 != iVar9; iVar10 = iVar10 + 0x2c) {
      *(float *)(iVar10 + 0x20) = *(float *)(iVar10 + 0x24) / fVar15;
    }
  }
  else {
    dVar18 = (double)(fStack_8c * fStack_8c + fVar22 * fVar22 + fStack_88 * fStack_88);
    FUN_017267a0();
    uStack_60._0_4_ = (float)dVar18;
    uVar8 = FUN_00854fa0();
    FUN_00855d00(uVar8);
    iVar9 = *(int *)(param_1 + 0x18);
    uVar8 = *(undefined4 *)(param_1 + 0xd8);
    iStack_a4 = 1;
    *(undefined8 *)(iVar9 + -0x2c) = *(undefined8 *)(param_1 + 0xd0);
    *(undefined4 *)(iVar9 + -0x24) = uVar8;
    if (0 < (int)fStack_90) {
      fVar15 = 0.0;
      fVar20 = fStack_90;
      do {
        uStack_28 = 0;
        fVar25 = (float)iStack_a4 / (float)(int)fVar20;
        fVar23 = fVar22 * fVar25 + *(float *)(param_1 + 0xd0);
        uStack_44 = 0;
        uStack_40 = 0;
        uStack_3c = 0;
        uStack_38 = 0;
        fVar21 = fStack_8c * fVar25 + *(float *)(param_1 + 0xd4);
        fStack_98 = fStack_88 * fVar25 + *(float *)(param_1 + 0xd8);
        fStack_78 = fVar25 * (float)uStack_60;
        uStack_50 = CONCAT44(fVar21,fVar23);
        fStack_48 = fStack_98;
        fStack_2c = fStack_78;
        if ((DAT_018fde58 <= fStack_78 - fVar15) || ((float)iStack_a4 == fVar20)) {
          pfVar12 = *(float **)(param_1 + 0x18);
          fStack_30 = fVar25;
          if (*(float **)(param_1 + 0x1c) == pfVar12) {
            FUN_008546f0(pfVar12,&uStack_50);
            fVar20 = fStack_90;
            fVar15 = fStack_78;
          }
          else {
            *pfVar12 = fVar23;
            pfVar12[1] = fVar21;
            pfVar12[2] = fStack_98;
            pfVar12[3] = 0.0;
            pfVar12[4] = 0.0;
            pfVar12[5] = 0.0;
            pfVar12[6] = 0.0;
            pfVar12[7] = fStack_34;
            *(ulonglong *)(pfVar12 + 8) = CONCAT44(fStack_78,fVar25);
            pfVar12[10] = 0.0;
            *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 0x2c;
            fVar20 = fStack_90;
            fVar15 = fStack_78;
          }
        }
        iStack_a4 = iStack_a4 + 1;
      } while (iStack_a4 <= (int)fVar20);
    }
  }
  fStack_b0 = *(float *)(param_1 + 0x18);
  iVar9 = *piVar13;
  if (*(int *)(param_1 + 0x68) == 0) {
    if ((float)iVar9 != fStack_b0) {
      do {
        *(float *)(iVar9 + 0x28) =
             *(float *)(iVar9 + 0x20) * *(float *)(param_1 + 0x5c) + *(float *)(param_1 + 100);
        iVar9 = iVar9 + 0x2c;
      } while ((float)iVar9 != fStack_b0);
      fStack_b0 = *(float *)(param_1 + 0x18);
    }
  }
  else if ((float)iVar9 != fStack_b0) {
    do {
      *(float *)(iVar9 + 0x28) =
           *(float *)(iVar9 + 0x24) / *(float *)(param_1 + 0x5c) + *(float *)(param_1 + 100);
      iVar9 = iVar9 + 0x2c;
    } while ((float)iVar9 != fStack_b0);
    fStack_b0 = *(float *)(param_1 + 0x18);
  }
  if (*(char *)(param_1 + 0x85) == '\0') {
    for (iVar9 = *piVar13; piVar13 = piStack_74, (float)iVar9 != fStack_b0; iVar9 = iVar9 + 0x2c) {
      *(float *)(iVar9 + 0x18) =
           (*(float *)(param_1 + 0x7c) - *(float *)(param_1 + 0x78)) * *(float *)(iVar9 + 0x20) +
           *(float *)(param_1 + 0x78);
      FUN_01163af0(&uStack_50,param_1 + 0xdc,*(float *)(iVar9 + 0x20));
      FUN_011612d0(&uStack_84,1);
      fVar20 = DAT_018ce2f8;
      fVar22 = *(float *)(iVar9 + 0x18) * DAT_018ce2f4;
      fStack_14 = fStack_7c * fVar22;
      fVar15 = *(float *)(iVar9 + 0x20);
      *(ulonglong *)(iVar9 + 0xc) = CONCAT44(uStack_84._4_4_ * fVar22,(float)uStack_84 * fVar22);
      *(float *)(iVar9 + 0x14) = fStack_14;
      fVar21 = DAT_01918c78;
      fVar22 = DAT_018fee54;
      if ((fVar15 < 0.0) || (fVar20 < fVar15)) {
        fVar15 = 0.0;
      }
      else {
        fVar23 = fVar15 * DAT_018fee54 * DAT_01918c78;
        iVar10 = (int)fVar23;
        fVar15 = *(float *)(param_1 + 0x110 + iVar10 * 4);
        fVar15 = (fVar23 - (float)iVar10) * (*(float *)(param_1 + 0x114 + iVar10 * 4) - fVar15) +
                 fVar15;
      }
      *(char *)(iVar9 + 0x1f) = (char)(int)fVar15;
      fVar15 = *(float *)(iVar9 + 0x20);
      if ((0.0 <= fVar15) && (fVar15 <= fVar20)) {
        fVar21 = fVar15 * fVar22 * fVar21;
        iVar10 = (int)fVar21;
        fVar15 = *(float *)(param_1 + 400 + iVar10 * 0xc);
        fVar21 = fVar21 - (float)iVar10;
        *(char *)(iVar9 + 0x1c) =
             (char)(int)((*(float *)(param_1 + 0x19c + iVar10 * 0xc) - fVar15) * fVar21 + fVar15);
        fVar15 = *(float *)(param_1 + 0x194 + iVar10 * 0xc);
        *(char *)(iVar9 + 0x1d) =
             (char)(int)((*(float *)(param_1 + 0x1a0 + iVar10 * 0xc) - fVar15) * fVar21 + fVar15);
        fVar15 = *(float *)(param_1 + 0x198 + iVar10 * 0xc);
        *(char *)(iVar9 + 0x1e) =
             (char)(int)((*(float *)(param_1 + 0x1a4 + iVar10 * 0xc) - fVar15) * fVar21 + fVar15);
      }
    }
  }
  else {
    fVar15 = *(float *)(param_1 + 0xd8) - fStack_7c;
    fVar21 = *(float *)(param_1 + 0xd4) - uStack_84._4_4_;
    fVar20 = *(float *)(param_1 + 0xd0) - (float)uStack_84;
    uStack_60._0_4_ = fVar15 * fStack_8c - fVar21 * fStack_88;
    uStack_60._4_4_ = fVar20 * fStack_88 - fVar15 * fVar22;
    fVar15 = fVar21 * fVar22 - fVar20 * fStack_8c;
    dVar18 = (double)(uStack_60._4_4_ * uStack_60._4_4_ + (float)uStack_60 * (float)uStack_60 +
                     fVar15 * fVar15);
    fStack_58 = fVar15;
    uStack_a0._0_4_ = (float)uStack_60;
    dStack_68._0_4_ = uStack_60._4_4_;
    FUN_017267a0();
    fStack_ac = (float)dVar18;
    if (DAT_01918ee4 <= fStack_ac) {
      if ((DAT_01918ee8 <= fStack_ac) || (fStack_ac <= DAT_018fd17c)) {
        fStack_ac = DAT_018ce2f8 / fStack_ac;
        fStack_b0 = fStack_ac * (float)uStack_a0;
        fStack_90 = fStack_ac * dStack_68._0_4_;
        fStack_ac = fStack_ac * fVar15;
      }
      else {
        uStack_a0._0_4_ = (float)uStack_60;
        uStack_a0._4_4_ = uStack_60._4_4_;
        fStack_98 = fStack_58;
        fStack_ac = fStack_58;
        fStack_90 = uStack_60._4_4_;
        fStack_b0 = (float)uStack_60;
      }
    }
    else {
      fStack_ac = 0.0;
      fStack_b0 = 0.0;
      fStack_90 = 0.0;
    }
    fVar21 = *(float *)(param_1 + 0x104) - uStack_84._4_4_;
    fStack_7c = *(float *)(param_1 + 0x108) - fStack_7c;
    fVar20 = *(float *)(param_1 + 0x100) - (float)uStack_84;
    uStack_84._0_4_ = fStack_7c * fStack_8c - fVar21 * fStack_88;
    fVar15 = fVar20 * fStack_8c;
    fStack_8c = fVar20 * fStack_88 - fStack_7c * fVar22;
    fVar15 = fVar21 * fVar22 - fVar15;
    dVar18 = (double)(fStack_8c * fStack_8c + (float)uStack_84 * (float)uStack_84 + fVar15 * fVar15)
    ;
    fStack_88 = (float)uStack_84;
    fStack_7c = fVar15;
    uStack_84._4_4_ = fStack_8c;
    FUN_017267a0();
    fVar20 = (float)dVar18;
    if (DAT_01918ee4 <= fVar20) {
      if ((DAT_01918ee8 <= fVar20) || (fVar20 <= DAT_018fd17c)) {
        fVar20 = DAT_018ce2f8 / fVar20;
        fStack_88 = fStack_88 * fVar20;
        fStack_8c = fStack_8c * fVar20;
        fVar15 = fVar15 * fVar20;
      }
      else {
        uStack_a0._4_4_ = uStack_84._4_4_;
        fStack_98 = fStack_7c;
        fVar15 = fStack_7c;
        fStack_88 = (float)uStack_84;
        fStack_8c = uStack_84._4_4_;
      }
    }
    else {
      fVar15 = 0.0;
      fStack_88 = 0.0;
      fStack_8c = 0.0;
    }
    iStack_a4 = *piVar13;
    dStack_68 = (double)CONCAT44(dStack_68._4_4_,*(int *)(param_1 + 0x18));
    if (iStack_a4 != *(int *)(param_1 + 0x18)) {
      pfVar12 = (float *)(iStack_a4 + 0x14);
      fStack_88 = fStack_88 - fStack_b0;
      fStack_8c = fStack_8c - fStack_90;
      do {
        fVar20 = pfVar12[3];
        fStack_14 = fVar20 * (fVar15 - fStack_ac) + fStack_ac;
        uStack_a0._0_4_ =
             (*(float *)(param_1 + 0x7c) - *(float *)(param_1 + 0x78)) * fVar20 +
             *(float *)(param_1 + 0x78);
        pfVar12[1] = (float)uStack_a0;
        *(ulonglong *)(pfVar12 + -2) =
             CONCAT44(fVar20 * fStack_8c + fStack_90,fVar20 * fStack_88 + fStack_b0);
        *pfVar12 = fStack_14;
        fVar20 = pfVar12[-2];
        uStack_60 = (ulonglong)(uint)fVar20;
        dVar18 = (double)(fVar20 * fVar20 + pfVar12[-1] * pfVar12[-1] + *pfVar12 * *pfVar12);
        FUN_017267a0();
        fVar22 = DAT_018ce2f8;
        fVar21 = DAT_018ce2f8 / (float)dVar18;
        uStack_a0._0_4_ = (float)uStack_a0 * DAT_018ce2f4;
        fVar20 = pfVar12[3];
        fStack_7c = *pfVar12 * fVar21 * (float)uStack_a0;
        *(ulonglong *)(pfVar12 + -2) =
             CONCAT44(pfVar12[-1] * fVar21 * (float)uStack_a0,
                      (float)uStack_60 * fVar21 * (float)uStack_a0);
        *pfVar12 = fStack_7c;
        fVar23 = DAT_01918c78;
        fVar21 = DAT_018fee54;
        if ((fVar20 < 0.0) || (fVar22 < fVar20)) {
          fVar20 = 0.0;
        }
        else {
          fVar25 = fVar20 * DAT_018fee54 * DAT_01918c78;
          iVar9 = (int)fVar25;
          fVar20 = *(float *)(param_1 + 0x110 + iVar9 * 4);
          fVar20 = (fVar25 - (float)iVar9) * (*(float *)(param_1 + 0x114 + iVar9 * 4) - fVar20) +
                   fVar20;
        }
        *(char *)((int)pfVar12 + 0xb) = (char)(int)fVar20;
        fVar20 = pfVar12[3];
        if ((0.0 <= fVar20) && (fVar20 <= fVar22)) {
          fVar23 = fVar20 * fVar21 * fVar23;
          iVar9 = (int)fVar23;
          fVar20 = *(float *)(param_1 + 400 + iVar9 * 0xc);
          fVar23 = fVar23 - (float)iVar9;
          *(char *)(pfVar12 + 2) =
               (char)(int)((*(float *)(param_1 + 0x19c + iVar9 * 0xc) - fVar20) * fVar23 + fVar20);
          fVar20 = *(float *)(param_1 + 0x194 + iVar9 * 0xc);
          *(char *)((int)pfVar12 + 9) =
               (char)(int)((*(float *)(param_1 + 0x1a0 + iVar9 * 0xc) - fVar20) * fVar23 + fVar20);
          fVar20 = *(float *)(param_1 + 0x198 + iVar9 * 0xc);
          *(char *)((int)pfVar12 + 10) =
               (char)(int)((*(float *)(param_1 + 0x1a4 + iVar9 * 0xc) - fVar20) * fVar23 + fVar20);
        }
        pfVar12 = pfVar12 + 0xb;
        iStack_a4 = iStack_a4 + 0x2c;
        piVar13 = piStack_74;
      } while ((float)iStack_a4 != dStack_68._0_4_);
    }
  }
  iVar9 = *piVar13;
  uVar6 = (piVar13[1] - iVar9) / 0x2c;
  if (param_3 / 6 + 1 < uVar6) {
    iVar10 = (uVar6 - param_3 / 6) + -1;
  }
  else {
    iVar10 = 0;
  }
  piStack_74 = (int *)(iVar10 + 1);
  iVar10 = 0;
  iStack_a8 = 0;
  if (piStack_74 < uVar6) {
    iVar11 = (int)piStack_74 * 0x2c;
    pfVar12 = (float *)(param_2 + 0x54);
    do {
      fVar15 = *(float *)(iVar11 + -0x2c + iVar9);
      fVar20 = *(float *)(iVar11 + -0x28 + iVar9);
      fVar22 = *(float *)(iVar11 + -0x24 + iVar9);
      fVar21 = *(float *)(iVar11 + -0x18 + iVar9);
      fVar23 = *(float *)(iVar11 + 0xc + iVar9);
      fVar25 = *(float *)(iVar11 + 4 + iVar9);
      fVar26 = *(float *)(iVar11 + -0x1c + iVar9);
      fVar30 = fVar15 - *(float *)(iVar11 + -0x20 + iVar9);
      fVar27 = *(float *)(iVar11 + iVar9);
      fVar33 = fVar20 - *(float *)(iVar11 + -0x1c + iVar9);
      fVar35 = fVar22 - *(float *)(iVar11 + -0x18 + iVar9);
      fVar16 = fVar23 + fVar27;
      fVar17 = *(float *)(iVar11 + 0x10 + iVar9) + fVar25;
      fVar29 = *(float *)(iVar11 + 0x10 + iVar9);
      fVar32 = *(float *)(iVar11 + 8 + iVar9);
      fVar34 = *(float *)(iVar11 + 0x14 + iVar9);
      fVar31 = *(float *)(iVar11 + 0x14 + iVar9) + fVar32;
      fVar1 = *(float *)(iVar11 + 0x18 + iVar9);
      fVar28 = DAT_018e452c;
      if (DAT_018e452c <= fVar1) {
        fVar28 = fVar1;
      }
      fVar2 = *(float *)(iVar11 + -0x14 + iVar9);
      fVar28 = (fVar2 + fVar1) / fVar28;
      fVar24 = fVar2;
      if (fVar2 < DAT_018e452c) {
        fVar24 = DAT_018e452c;
      }
      uVar8 = *(undefined4 *)(iVar11 + -4 + iVar9);
      fVar5 = *(float *)(iVar11 + -0x10 + iVar9);
      fVar24 = (fVar2 + fVar1) / fVar24;
      piStack_74 = (int *)((int)piStack_74 + 1);
      iVar10 = iStack_a8 + 6;
      pfVar12[-0x15] = *(float *)(iVar11 + -0x20 + iVar9) + fVar15;
      pfVar12[-0x14] = fVar26 + fVar20;
      pfVar12[-0x13] = fVar21 + fVar22;
      pfVar12[-0x12] = 0.0;
      pfVar12[-0xe] = fVar30;
      pfVar12[-0xd] = fVar33;
      pfVar12[-0xc] = fVar35;
      pfVar12[-0xb] = 1.0;
      *pfVar12 = fVar30;
      pfVar12[1] = fVar33;
      pfVar12[2] = fVar35;
      pfVar12[3] = 1.0;
      *(ulonglong *)(pfVar12 + -0x11) = CONCAT44(fVar28,uVar8);
      *(ulonglong *)(pfVar12 + -10) = CONCAT44(fVar28,uVar8);
      *(ulonglong *)(pfVar12 + 4) = CONCAT44(fVar28,uVar8);
      pfVar12[-0xf] = fVar5;
      pfVar12[-8] = fVar5;
      pfVar12[6] = fVar5;
      fVar15 = *(float *)(iVar11 + 0x1c + iVar9);
      uVar8 = *(undefined4 *)(iVar11 + 0x28 + iVar9);
      iVar11 = iVar11 + 0x2c;
      pfVar12[-7] = fVar16;
      pfVar12[-6] = fVar17;
      pfVar12[-5] = fVar31;
      pfVar12[-4] = 0.0;
      pfVar12[7] = fVar16;
      pfVar12[8] = fVar17;
      pfVar12[9] = fVar31;
      pfVar12[10] = 0.0;
      pfVar12[0xe] = fVar27 - fVar23;
      pfVar12[0xf] = fVar25 - fVar29;
      pfVar12[0x10] = fVar32 - fVar34;
      pfVar12[0x11] = 1.0;
      *(ulonglong *)(pfVar12 + -3) = CONCAT44(fVar24,uVar8);
      *(ulonglong *)(pfVar12 + 0xb) = CONCAT44(fVar24,uVar8);
      *(ulonglong *)(pfVar12 + 0x12) = CONCAT44(fVar24,uVar8);
      pfVar12[-1] = fVar15;
      pfVar12[0xd] = fVar15;
      pfVar12[0x14] = fVar15;
      pfVar12 = pfVar12 + 0x2a;
      iVar9 = *piVar13;
      iStack_a8 = iVar10;
    } while (piStack_74 < (uint)((piVar13[1] - iVar9) / 0x2c));
  }
  return iVar10;
}



/* FUNCTION 13073 ; VA 0x00857980 ; FUN_00857980 */

void __fastcall FUN_00857980(int *param_1)

{
  if (param_1[3] == param_1[4]) {
    if (param_1 == (int *)0x74) {
      param_1 = (int *)0x0;
    }
    FUN_007c64b0(param_1);
    return;
  }
  FUN_008553f0();
  (**(code **)(*param_1 + 0x44))();
  *(undefined *)(param_1 + 0xb) = 1;
  return;
}



/* FUNCTION 13074 ; VA 0x008579c0 ; FUN_008579c0 */

void __thiscall FUN_008579c0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  
  if (*(char *)(param_1 + 0x118) != '\0') {
    cVar3 = FUN_00841130();
    if ((cVar3 == '\0') && (param_4 == 0)) {
      iVar1 = *(int *)(param_1 + 0xa4);
      param_4 = param_1 + 0x94;
      piVar2 = *(int **)(iVar1 + 0x60);
      if (*(int **)(iVar1 + 100) == piVar2) {
        FUN_006030d0(piVar2,&param_4);
      }
      else {
        *piVar2 = param_4;
        *(int *)(iVar1 + 0x60) = *(int *)(iVar1 + 0x60) + 4;
      }
      if (*(char *)(*(int *)(*(int *)(param_1 + 8) + 0x510) + 0x20) != '\0') {
        FUN_008416d0(*(int *)(param_1 + 8),param_1 + 0x18);
      }
    }
  }
  return;
}



/* FUNCTION 13075 ; VA 0x00857a30 ; FUN_00857a30 */

undefined4 * __thiscall FUN_00857a30(undefined4 *param_1,undefined4 param_2)

{
  FUN_0086d7b0(param_2,0);
  *param_1 = RBX::Graphics::CustomEmitter::vftable;
  param_1[0x1d] = RBX::Graphics::CustomEmitter::vftable;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x29] = 0x3f800000;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0x3f800000;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0x3f800000;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  *(undefined8 *)(param_1 + 0x35) = 0;
  param_1[0x37] = 0;
  *(undefined8 *)(param_1 + 0x38) = 0;
  param_1[0x3a] = 0;
  *(undefined *)(param_1 + 0x3b) = 0;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  *(undefined *)(param_1 + 0x3e) = 0;
  return param_1;
}



/* FUNCTION 13076 ; VA 0x00857b60 ; FUN_00857b60 */

void __fastcall FUN_00857b60(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::CustomEmitter::vftable;
  param_1[0x1d] = RBX::Graphics::CustomEmitter::vftable;
  FUN_011590c0();
  param_1[0x25] = 0;
  piVar2 = (int *)param_1[0x26];
  param_1[0x26] = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  param_1[0x27] = 0;
  piVar2 = (int *)param_1[0x28];
  param_1[0x28] = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_007c78a0(param_1 + 0x1d,1);
  FUN_0082e1a0(param_1);
  if ((undefined4 *)param_1[0x3d] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x3d])(1);
  }
  piVar2 = (int *)param_1[0x28];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x26];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_0086d830();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13077 ; VA 0x00857ca5 ; FUN_00857ca5 */

void FUN_00857ca5(void)

{
  FUN_00857cb0();
  return;
}



/* FUNCTION 13078 ; VA 0x00857cb0 ; FUN_00857cb0 */

undefined4 __thiscall FUN_00857cb0(undefined4 param_1,byte param_2)

{
  FUN_00857b60();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xfc);
  }
  return param_1;
}



/* FUNCTION 13079 ; VA 0x00857ce0 ; FUN_00857ce0 */

void __fastcall FUN_00857ce0(int *param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  float *pfVar6;
  undefined4 *puVar7;
  int *piVar8;
  float fVar9;
  uint uVar10;
  float fVar11;
  ulonglong uStack_70;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  float fStack_5c;
  undefined auStack_58 [4];
  undefined auStack_54 [4];
  float fStack_50;
  undefined8 uStack_4c;
  uint auStack_44 [2];
  undefined auStack_3c [8];
  undefined4 uStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  float fStack_1c;
  float fStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7ff2;
  pvStack_10 = ExceptionList;
  fStack_1c = 0.0;
  fStack_18 = 0.0;
  if (param_1[0x27] != 0) {
    if (param_1[0x3d] == 0) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_01674e20(0x6a4);
      uStack_4c = CONCAT44(iVar3,(undefined4)uStack_4c);
      uStack_8 = 0;
      if (iVar3 == 0) {
        iVar3 = 0;
      }
      else {
        fStack_2c = 0.0;
        fStack_28 = 2.10195e-44;
        auStack_3c[0] = 0;
        FUN_00551260("Texture");
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        fStack_1c = 1.4013e-45;
        uVar4 = FUN_00d10320(param_1[0x27],auStack_3c);
        uStack_8 = 2;
        fStack_18 = 4.2039e-45;
        fStack_1c = 4.2039e-45;
        iVar3 = FUN_0082b6e0(param_1[2],uVar4);
      }
      puVar7 = (undefined4 *)param_1[0x3d];
      param_1[0x3d] = iVar3;
      if (puVar7 != (undefined4 *)0x0) {
        (**(code **)*puVar7)(1);
      }
      if (((uint)fStack_18 & 2) != 0) {
        fStack_18 = (float)((uint)fStack_18 & 0xfffffffd);
        FUN_00637950();
      }
      uStack_8 = 0xffffffff;
      if (((uint)fStack_18 & 1) != 0) {
        FUN_005507b0();
      }
      param_1[0x3c] = -2;
      uVar5 = 0xfffffffe;
    }
    else {
      uVar5 = param_1[0x3c];
      ExceptionList = &pvStack_10;
    }
    cStack_11 = '\0';
    if ((uVar5 & 4) != 0) {
      fStack_18 = DAT_018ce2f8;
      uStack_4c = (ulonglong)(uint)DAT_018ce2f8;
      fStack_30 = DAT_018ce2f8;
      fStack_2c = DAT_018ce2f8;
      fStack_1c = DAT_018ce2f8;
      fStack_28 = DAT_018ce2f8;
      if (param_1[0x25] != 0) {
        pfVar6 = (float *)FUN_00b082f0(auStack_58);
        fStack_50 = pfVar6[2] * DAT_018ce2f4;
        fStack_30 = *pfVar6 * DAT_018ce2f4;
        fStack_2c = pfVar6[1] * DAT_018ce2f4;
        uStack_4c = (ulonglong)(uint)fStack_30;
        fStack_28 = fStack_50;
        iVar3 = FUN_00836510(*(undefined4 *)(param_1[0x27] + 0x34));
        if (iVar3 == 0) {
          uStack_4c = (ulonglong)(uint)fStack_30;
          fStack_1c = fStack_28;
          fStack_18 = fStack_2c;
        }
        else {
          fStack_30 = (float)uStack_4c * 0.0;
          uStack_4c = CONCAT44((int)(uStack_4c >> 0x20),fStack_30);
          fStack_18 = fStack_2c * 0.0;
          fStack_1c = fStack_28 * 0.0;
        }
      }
      fVar9 = DAT_018ce2f8;
      *(undefined *)(param_1 + 0x3b) = *(undefined *)(param_1[0x27] + 0xa4);
      iVar3 = param_1[0x3d];
      *(float *)(iVar3 + 0x670) = fVar9 - *(float *)(param_1[0x27] + 0xa8);
      *(undefined4 *)(iVar3 + 0x674) = *(undefined4 *)(param_1[0x27] + 0xac);
      fStack_2c = fStack_18;
      fStack_28 = fStack_1c;
      FUN_0082e7f0((float)*(byte *)(param_1[0x27] + 0xa4) * *(float *)(param_1[0x27] + 0xb0));
      iVar3 = param_1[0x3d];
      uVar4 = *(undefined4 *)(param_1[0x27] + 0xb8);
      *(undefined4 *)(iVar3 + 0xb8) = *(undefined4 *)(param_1[0x27] + 0xb4);
      *(undefined4 *)(iVar3 + 0xbc) = uVar4;
      uStack_24 = *(undefined4 *)(param_1[0x27] + 0xbc);
      uStack_20 = *(undefined4 *)(param_1[0x27] + 0xc0);
      pfVar6 = (float *)FUN_01163100(auStack_54,0x43340000);
      fVar9 = pfVar6[1] * DAT_018f8ff4;
      *(float *)(iVar3 + 0xc0) = *pfVar6 * DAT_018f8ff4;
      *(float *)(iVar3 + 0xc4) = fVar9;
      iVar3 = param_1[0x3d];
      uStack_24 = *(undefined4 *)(param_1[0x27] + 0xc4);
      uStack_20 = *(undefined4 *)(param_1[0x27] + 200);
      pfVar6 = (float *)FUN_01163100(auStack_54,0x43340000);
      fVar9 = pfVar6[1] * DAT_018f8ff4;
      *(float *)(iVar3 + 0xe4) = *pfVar6 * DAT_018f8ff4;
      *(float *)(iVar3 + 0xe8) = fVar9;
      iVar3 = param_1[0x3d];
      uStack_24 = *(undefined4 *)(param_1[0x27] + 0xcc);
      uStack_20 = *(undefined4 *)(param_1[0x27] + 0xd0);
      pfVar6 = (float *)FUN_01163100(auStack_54,0x43340000);
      iVar1 = param_1[0x3d];
      fVar9 = *pfVar6 * DAT_018f8ff4;
      *(float *)(iVar3 + 0xf0) = pfVar6[1] * DAT_018f8ff4;
      *(float *)(iVar3 + 0xec) = fVar9;
      *(undefined4 *)(iVar1 + 0x688) = *(undefined4 *)(param_1[0x27] + 0xe8);
      uStack_20 = *(undefined4 *)(param_1[0x27] + 0xd8);
      uStack_24 = *(undefined4 *)(param_1[0x27] + 0xd4);
      FUN_0082e820(uStack_24,uStack_20);
      iVar3 = param_1[0x3d];
      uVar4 = *(undefined4 *)(param_1[0x27] + 0xe4);
      *(undefined8 *)(iVar3 + 0xd4) = *(undefined8 *)(param_1[0x27] + 0xdc);
      uVar5 = DAT_018c4ea0;
      *(undefined4 *)(iVar3 + 0xdc) = uVar4;
      uVar10 = (uint)uStack_4c ^ uVar5;
      iVar3 = param_1[0x3d];
      fStack_68 = (float)((uint)fStack_1c ^ uVar5);
      uStack_70 = CONCAT44((uint)fStack_18 ^ uVar5,uVar10);
      fStack_64 = fStack_30;
      fStack_60 = fStack_2c;
      *(undefined4 *)(iVar3 + 0x98) = 0;
      fVar11 = 0.0;
      fStack_5c = fStack_28;
      cStack_11 = '\x01';
      *(uint *)(iVar3 + 0xa0) = uVar10;
      *(uint *)(iVar3 + 0xa4) = (uint)fStack_18 ^ uVar5;
      *(float *)(iVar3 + 0xa8) = fStack_68;
      *(float *)(iVar3 + 0xac) = fStack_30;
      *(ulonglong *)(iVar3 + 0xb0) = CONCAT44(fStack_28,fStack_2c);
      iVar3 = param_1[0x3d];
      *(undefined4 *)(iVar3 + 0xe0) = *(undefined4 *)(param_1[0x27] + 0xf0);
      *(undefined *)(iVar3 + 0x124) = *(undefined *)(param_1[0x27] + 0xf4);
      iVar3 = param_1[0x3d];
      *(undefined4 *)(iVar3 + 0x128) = *(undefined4 *)(param_1[0x27] + 0xec);
      fVar9 = 0.0;
      switch(*(undefined4 *)(param_1[0x27] + 0xf8)) {
      case 1:
        fVar9 = DAT_018f8ff0;
        fVar11 = DAT_018f8ff0;
        break;
      case 2:
        fVar9 = DAT_01901f78;
        break;
      case 3:
        fVar9 = DAT_018f8ff4;
        break;
      case 4:
        fVar11 = DAT_01901f78;
      case 5:
        fVar9 = DAT_018f8ff0;
      }
      *(float *)(iVar3 + 300) = fVar11;
      *(float *)(iVar3 + 0x130) = fVar9;
      fStack_50 = fStack_68;
      if (*(char *)(param_1 + 0x3e) != '\0') {
        FUN_0082e190();
        *(undefined *)(param_1 + 0x3e) = 0;
      }
      if (0 < *(int *)(param_1[0x27] + 0xfc)) {
        (**(code **)(param_1[0x1d] + 0x44))();
        FUN_0082c170(*(undefined4 *)(param_1[0x27] + 0xfc));
        *(undefined4 *)(param_1[0x27] + 0xfc) = 0;
      }
    }
    uVar5 = param_1[0x3c];
    if ((uVar5 & 0x10) != 0) {
      uVar4 = FUN_0074b630();
      FUN_0082e7d0(uVar4);
      uVar4 = FUN_00d3acc0();
      FUN_0082e2d0(uVar4,1);
      uVar4 = FUN_0074ae10();
      FUN_0082e870(uVar4);
      uVar5 = param_1[0x3c];
      cStack_11 = '\x01';
    }
    if ((uVar5 & 8) != 0) {
      uStack_34 = 0;
      fStack_30 = 2.10195e-44;
      auStack_44[0] = auStack_44[0] & 0xffffff00;
      uStack_8 = 5;
      fStack_2c = 0.0;
      fStack_28 = 0.0;
      puVar7 = (undefined4 *)FUN_00d01ad0();
      if (0xf < (uint)puVar7[5]) {
        puVar7 = (undefined4 *)*puVar7;
      }
      FUN_00551260(puVar7);
      fStack_28 = 5.60519e-45;
      fStack_2c = 5.60519e-45;
      fStack_60 = 0.0;
      fStack_5c = 2.10195e-44;
      uStack_70 = uStack_70 & 0xffffffffffffff00;
      FUN_00551260("Texture");
      uStack_8._0_1_ = 6;
      uVar4 = FUN_00d10320(param_1[0x27],&uStack_70);
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      FUN_0082e340(auStack_44,uVar4);
      FUN_00637950();
      FUN_005507b0();
      uStack_8 = 0xffffffff;
      if (0xf < (uint)fStack_30) {
        uVar10 = (int)fStack_30 + 1;
        uVar5 = auStack_44[0];
        if (0xfff < uVar10) {
          uVar5 = *(uint *)(auStack_44[0] - 4);
          uVar10 = (int)fStack_30 + 0x24;
          if (0x1f < (auStack_44[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar5,uVar10);
      }
    }
    if (cStack_11 != '\0') {
      piVar8 = (int *)FUN_0082c950(&uStack_70);
      iVar3 = piVar8[1];
      iVar1 = piVar8[2];
      iVar2 = piVar8[3];
      param_1[0x35] = *piVar8;
      param_1[0x36] = iVar3;
      param_1[0x37] = iVar1;
      param_1[0x38] = iVar2;
      *(undefined8 *)(param_1 + 0x39) = *(undefined8 *)(piVar8 + 4);
      (**(code **)(*param_1 + 0xc))();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13080 ; VA 0x00858440 ; FUN_00858440 */

void __thiscall FUN_00858440(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  int iVar9;
  int iVar10;
  bool bVar11;
  code *pcStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  undefined auStack_2c [4];
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b809c;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  iVar10 = param_2[1];
  ExceptionList = &pvStack_10;
  if (iVar10 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(iVar10 + 4) = *(int *)(iVar10 + 4) + 1;
    UNLOCK();
    iVar10 = param_2[1];
  }
  *(int *)(param_1 + 0x94) = *param_2;
  piVar6 = *(int **)(param_1 + 0x98);
  *(int *)(param_1 + 0x98) = iVar10;
  iStack_14 = param_1;
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar10 = piVar6[1] + -1;
    piVar6[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      iVar10 = piVar6[2] + -1;
      piVar6[2] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  iVar10 = *param_3;
  iVar5 = *(int *)(iVar10 + 0xc);
  iVar3 = FUN_00d3a1d0();
  iVar9 = 0;
  if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
      (uint)*(ushort *)(iVar3 + 0x1da)) {
    iVar9 = iVar10;
  }
  puVar4 = (undefined4 *)FUN_0060dcd0(auStack_2c,iVar9);
  iVar10 = iStack_14;
  uVar7 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  *(undefined4 *)(iStack_14 + 0x9c) = uVar7;
  piStack_24 = *(int **)(iStack_14 + 0xa0);
  *(undefined4 *)(iStack_14 + 0xa0) = uVar2;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_24[1] + -1;
    piStack_24[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar5 = piStack_24[2] + -1;
      piStack_24[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  piStack_24 = piStack_28;
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_28[1] + -1;
    piStack_28[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      iVar5 = piStack_24[2] + -1;
      piStack_24[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (*param_2 != 0) {
    iVar5 = FUN_008a4100();
    piStack_20 = (int *)(iVar5 + 0x80);
    pcStack_3c = FUN_00851fd0;
    iStack_38 = 0;
    iStack_34 = iVar10;
    iStack_8 = 0;
    piVar6 = (int *)FUN_01675290(DAT_02110da8);
    iStack_8._0_1_ = 1;
    piStack_28 = piVar6;
    piStack_1c = (int *)FUN_01674e20(0x28);
    if (piStack_1c == (int *)0x0) {
      piStack_1c = (int *)0x0;
    }
    else {
      *piStack_1c = 0;
      piStack_1c[1] = 1;
      piStack_1c[2] = (int)FUN_00838650;
      piStack_1c[3] = (int)_guard_check_icall;
      piStack_1c[4] = 0;
      piStack_1c[5] = (int)piStack_20;
      piStack_1c[6] = (int)pcStack_3c;
      piStack_1c[7] = iStack_38;
      piStack_1c[8] = iStack_34;
      piStack_1c[9] = iStack_30;
    }
    FUN_016797d0(piStack_1c);
    piStack_24 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
    }
    uStack_18 = 1;
    iStack_8._0_1_ = 2;
    FUN_01675290(piVar6);
    puVar4 = *(undefined4 **)(iVar10 + 0x84);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (*(undefined4 **)(iVar10 + 0x88) == puVar4) {
      FUN_006335f0(puVar4,&piStack_24);
      piVar6 = piStack_24;
    }
    else {
      *puVar4 = piStack_1c;
      *(int *)(iVar10 + 0x84) = *(int *)(iVar10 + 0x84) + 4;
      piVar6 = (int *)0x0;
    }
    iStack_8 = 0xffffffff;
    if (piVar6 != (int *)0x0) {
      piVar1 = piVar6 + 1;
      LOCK();
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        FUN_01674ea0(piVar6);
      }
    }
    if (DAT_01d6866c == '\0') {
      bVar11 = *(int *)(*param_2 + 0x70) == 0;
    }
    else {
      bVar11 = *(int *)(*param_2 + 0x6c) == -1;
    }
    if (bVar11) {
      FUN_007c7a50(iVar10 + 0x74,1);
    }
    else {
      FUN_007c7840(iVar10 + 0x74,1);
    }
    uStack_18 = 0;
  }
  iVar5 = iVar10;
  if (*(int *)(iVar10 + 0x9c) != 0) {
    piStack_24 = (int *)(*(int *)(iVar10 + 0x9c) + 0x58);
    pcStack_3c = (code *)&LAB_00858ea0;
    iStack_38 = 0;
    iStack_34 = iStack_14;
    FUN_006eccd0();
    iStack_8 = 3;
    uVar7 = FUN_01675290(DAT_02110da8);
    iStack_8 = 4;
    piStack_28 = (int *)uVar7;
    piStack_1c = (int *)FUN_01674e20(0x28);
    if (piStack_1c == (int *)0x0) {
      piStack_1c = (int *)0x0;
    }
    else {
      *piStack_1c = 0;
      piStack_1c[1] = 1;
      piStack_1c[2] = (int)FUN_00838650;
      piStack_1c[3] = (int)_guard_check_icall;
      piStack_1c[4] = 0;
      piStack_1c[5] = (int)piStack_24;
      piStack_1c[6] = (int)pcStack_3c;
      piStack_1c[7] = iStack_38;
      piStack_1c[8] = iStack_34;
      piStack_1c[9] = iStack_30;
    }
    FUN_016797d0(piStack_1c);
    piStack_20 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
    }
    uStack_18 = 4;
    iStack_8 = 5;
    FUN_01675290(uVar7);
    uStack_18 = 2;
    puVar4 = *(undefined4 **)(iVar10 + 0x84);
    iStack_8 = 6;
    if (*(undefined4 **)(iVar10 + 0x88) == puVar4) {
      FUN_006335f0(puVar4,&piStack_20);
      piVar6 = piStack_20;
    }
    else {
      *puVar4 = piStack_1c;
      *(int *)(iVar10 + 0x84) = *(int *)(iVar10 + 0x84) + 4;
      piVar6 = (int *)0x0;
    }
    iStack_8 = 0xffffffff;
    if (piVar6 != (int *)0x0) {
      piVar1 = piVar6 + 1;
      LOCK();
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        FUN_01674ea0(piVar6);
      }
    }
    iStack_34 = iStack_14;
    pcStack_3c = (code *)&LAB_00858e80;
    iStack_38 = 0;
    piStack_24 = (int *)(*(int *)(iStack_14 + 0x9c) + 0x60);
    FUN_006eccd0();
    iStack_8 = 7;
    uVar7 = FUN_01675290(DAT_02110da8);
    iStack_8 = 8;
    piStack_28 = (int *)uVar7;
    piStack_1c = (int *)FUN_01674e20(0x28);
    if (piStack_1c == (int *)0x0) {
      piStack_1c = (int *)0x0;
    }
    else {
      *piStack_1c = 0;
      piStack_1c[1] = 1;
      piStack_1c[2] = (int)FUN_0067baa0;
      piStack_1c[3] = (int)_guard_check_icall;
      piStack_1c[4] = 0;
      piStack_1c[5] = (int)piStack_24;
      piStack_1c[6] = (int)pcStack_3c;
      piStack_1c[7] = iStack_38;
      piStack_1c[8] = iStack_34;
      piStack_1c[9] = iStack_30;
    }
    FUN_016797d0(piStack_1c);
    piStack_20 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
    }
    uStack_18 = 0x12;
    iStack_8 = 9;
    FUN_01675290(uVar7);
    uStack_18 = 10;
    puVar4 = *(undefined4 **)(iVar10 + 0x84);
    iStack_8 = 10;
    if (*(undefined4 **)(iVar10 + 0x88) == puVar4) {
      FUN_006335f0(puVar4,&piStack_20);
      if (piStack_20 != (int *)0x0) {
        piVar6 = piStack_20 + 1;
        LOCK();
        iVar5 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          FUN_01674ea0(piStack_20);
        }
      }
    }
    else {
      *puVar4 = piStack_1c;
      *(int *)(iVar10 + 0x84) = *(int *)(iVar10 + 0x84) + 4;
    }
    pcStack_3c = FUN_00858d10;
    iStack_38 = 0;
    piStack_24 = (int *)(*param_3 + 0x50);
    iStack_34 = iStack_14;
    iStack_8 = 0xb;
    piVar6 = (int *)FUN_01675290(DAT_02110da8);
    iStack_8._0_1_ = 0xc;
    piStack_28 = piVar6;
    param_3 = (int *)FUN_01674e20(0x28);
    if (param_3 == (int *)0x0) {
      param_3 = (int *)0x0;
    }
    else {
      *param_3 = 0;
      param_3[1] = 1;
      param_3[2] = (int)FUN_00819150;
      param_3[3] = (int)_guard_check_icall;
      param_3[4] = 0;
      param_3[5] = (int)piStack_24;
      param_3[6] = (int)pcStack_3c;
      param_3[7] = iStack_38;
      param_3[8] = iStack_34;
      param_3[9] = iStack_30;
    }
    FUN_016797d0(param_3);
    piStack_20 = param_3;
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    uStack_18 = 0x2a;
    iStack_8._0_1_ = 0xd;
    FUN_01675290(piVar6);
    puVar4 = *(undefined4 **)(iVar10 + 0x84);
    iStack_8 = CONCAT31(iStack_8._1_3_,0xb);
    if (*(undefined4 **)(iVar10 + 0x88) == puVar4) {
      FUN_006335f0(puVar4,&piStack_20);
      piVar6 = piStack_20;
    }
    else {
      *puVar4 = param_3;
      *(int *)(iVar10 + 0x84) = *(int *)(iVar10 + 0x84) + 4;
      piVar6 = (int *)0x0;
    }
    iStack_8 = 0xffffffff;
    if (piVar6 != (int *)0x0) {
      piVar1 = piVar6 + 1;
      LOCK();
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        FUN_01674ea0(piVar6);
      }
    }
    iVar5 = iStack_14;
    if (*param_2 != 0) {
      iStack_34 = iStack_14;
      pcStack_3c = FUN_00858de0;
      iStack_38 = 0;
      puVar8 = (undefined4 *)FUN_00836450(&param_2,&pcStack_3c);
      puVar4 = *(undefined4 **)(iVar10 + 0x84);
      iStack_8 = 0xe;
      if (*(undefined4 **)(iVar10 + 0x88) == puVar4) {
        FUN_006335f0(puVar4,puVar8);
      }
      else {
        *puVar4 = *puVar8;
        *puVar8 = 0;
        *(int *)(iVar10 + 0x84) = *(int *)(iVar10 + 0x84) + 4;
      }
      iStack_8 = 0xffffffff;
      iVar5 = iStack_14;
      if (param_2 != (int *)0x0) {
        piVar6 = param_2 + 1;
        LOCK();
        iVar10 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar10 == 1) {
          FUN_01674ea0(param_2);
          iVar5 = iStack_14;
        }
      }
    }
  }
  *(undefined4 *)(iVar5 + 0xf0) = 0xfffffffe;
  (**(code **)(*(int *)(iVar5 + 0x74) + 8))();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13081 ; VA 0x00858a90 ; FUN_00858a90 */

int __thiscall FUN_00858a90(int param_1,int *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  undefined4 uVar6;
  int iVar7;
  code *pcStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  int iStack_20;
  int iStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b80c0;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(*param_2 + 0x34);
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  if (((piVar1 == (int *)0x0) ||
      (iVar7 = piVar1[3], ExceptionList = &pvStack_10, iVar3 = FUN_00aff8c0(), piVar5 = piVar1,
      (uint)*(ushort *)(iVar3 + 0x1da) <
      (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) &&
     (piVar5 = (int *)0x0, piVar1 != (int *)0x0)) {
    iVar7 = piVar1[3];
    iVar3 = FUN_00d6bbd0();
    if ((uint)*(ushort *)(iVar3 + 0x1da) <
        (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
      piVar5 = (int *)0x0;
    }
    else {
      piStack_14 = (int *)piVar1[0xd];
      if ((piStack_14 == (int *)0x0) ||
         (iVar7 = piStack_14[3], iVar3 = FUN_00aff8c0(),
         (uint)*(ushort *)(iVar3 + 0x1da) <
         (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
        piStack_14 = (int *)0x0;
      }
      iVar7 = iStack_1c;
      iStack_28 = iStack_1c;
      pcStack_30 = FUN_00858e00;
      uStack_2c = 0;
      puVar4 = (undefined4 *)FUN_00836450(&iStack_20,&pcStack_30);
      puVar2 = *(undefined4 **)(iVar7 + 0x84);
      uStack_8 = 0;
      if (*(undefined4 **)(iVar7 + 0x88) == puVar2) {
        FUN_006335f0(puVar2,puVar4);
      }
      else {
        *puVar2 = *puVar4;
        *puVar4 = 0;
        *(int *)(iVar7 + 0x84) = *(int *)(iVar7 + 0x84) + 4;
      }
      uStack_8 = 0xffffffff;
      piVar5 = piStack_14;
      if (iStack_20 != 0) {
        piVar1 = (int *)(iStack_20 + 4);
        LOCK();
        iVar7 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar7 == 1) {
          FUN_01674ea0(iStack_20);
          piVar5 = piStack_14;
        }
      }
    }
  }
  uVar6 = FUN_0060dcd0(auStack_18,piVar5);
  uStack_8 = 1;
  iVar7 = FUN_00858440(uVar6,param_2);
  piVar1 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar5 = piStack_14 + 1;
    iVar3 = *piVar5;
    iVar7 = *piVar5;
    *piVar5 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar7 = (**(code **)*piStack_14)();
      LOCK();
      piVar5 = piVar1 + 2;
      iVar3 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar7 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 13082 ; VA 0x00858c50 ; FUN_00858c50 */

int __fastcall FUN_00858c50(int param_1)

{
  return param_1 + 0xd4;
}



/* FUNCTION 13083 ; VA 0x00858c60 ; FUN_00858c60 */

undefined __fastcall FUN_00858c60(int param_1)

{
  return *(undefined *)(param_1 + 0xf4);
}



/* FUNCTION 13084 ; VA 0x00858c70 ; FUN_00858c70 */

int __fastcall FUN_00858c70(int param_1)

{
  return param_1 + 0xcc;
}



/* FUNCTION 13085 ; VA 0x00858c80 ; FUN_00858c80 */

int __fastcall FUN_00858c80(int param_1)

{
  return param_1 + 0xc4;
}



/* FUNCTION 13086 ; VA 0x00858ca0 ; FUN_00858ca0 */

void __thiscall FUN_00858ca0(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0xc0);
  *param_2 = *(undefined4 *)(param_1 + 0xbc);
  param_2[1] = uVar1;
  return;
}



/* FUNCTION 13087 ; VA 0x00858ce0 ; FUN_00858ce0 */

void __fastcall FUN_00858ce0(int param_1)

{
  if ((*(uint *)(param_1 + 0x7c) & 1) == 0) {
    *(uint *)(param_1 + 0x7c) = *(uint *)(param_1 + 0x7c) | 1;
    if (param_1 == 0x74) {
      param_1 = 0;
    }
    FUN_007c8ce0(param_1);
  }
  return;
}



/* FUNCTION 13088 ; VA 0x00858d10 ; FUN_00858d10 */

int __thiscall FUN_00858d10(int param_1,int param_2,int param_3)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  if (param_2 == 2) {
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00858e00(*(undefined4 *)(param_3 + 4));
    ExceptionList = pvStack_10;
    return iVar3;
  }
  param_2 = param_2 + -5;
  if (param_2 == 0) {
    piVar4 = *(int **)(param_1 + 0xa0);
    ExceptionList = &pvStack_10;
    if (piVar4 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = *(int **)(param_1 + 0xa0);
    }
    uStack_18 = *(undefined4 *)(param_1 + 0x9c);
    uStack_8 = 0;
    piStack_14 = piVar4;
    cVar2 = FUN_011584d0(uStack_18);
    if (cVar2 == '\0') {
      param_2 = (**(code **)(*(int *)(param_1 + 0x74) + 4))();
    }
    else {
      (**(code **)(*(int *)(param_1 + 0x74) + 0x40))();
      param_2 = FUN_00858a90(&uStack_18);
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar1 = piVar4 + 1;
      iVar3 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 13089 ; VA 0x00858de0 ; FUN_00858de0 */

void __thiscall FUN_00858de0(int param_1,undefined *param_2)

{
  if (param_2 == &DAT_01eed1b0) {
    *(uint *)(param_1 + 0xf0) = *(uint *)(param_1 + 0xf0) | 4;
    (**(code **)(*(int *)(param_1 + 0x74) + 8))();
  }
  return;
}



/* FUNCTION 13090 ; VA 0x00858e00 ; FUN_00858e00 */

void __thiscall FUN_00858e00(int param_1,undefined4 *param_2)

{
  uint uVar1;
  int iVar2;
  code *pcVar3;
  
  uVar1 = *(uint *)(param_1 + 0xf0);
  iVar2 = *(int *)(param_1 + 0x74);
  if (param_2 == &DAT_0213e1e8) {
    *(uint *)(param_1 + 0xf0) = uVar1 | 8;
    (**(code **)(iVar2 + 8))();
    return;
  }
  if ((param_2 != &DAT_0213e220) && (param_2 != (undefined4 *)&DAT_0213e258)) {
    pcVar3 = *(code **)(iVar2 + 8);
    if (param_2 == (undefined4 *)&DAT_0213e290) {
      *(uint *)(param_1 + 0xf0) = uVar1 | 0x10;
      (*pcVar3)();
      return;
    }
    *(uint *)(param_1 + 0xf0) = uVar1 | 4;
    (*pcVar3)();
    return;
  }
  *(uint *)(param_1 + 0xf0) = uVar1 | 0x10;
  (**(code **)(iVar2 + 8))();
  return;
}



/* FUNCTION 13091 ; VA 0x00858ec0 ; FUN_00858ec0 */

void __fastcall FUN_00858ec0(int param_1)

{
  int iVar1;
  float fVar2;
  undefined8 uStack_28;
  float fStack_20;
  undefined8 uStack_1c;
  float fStack_14;
  float fStack_8;
  
  FUN_00c9f550(&uStack_28,param_1 + 0xa4);
  iVar1 = *(int *)(param_1 + 0xf4);
  if (iVar1 != 0) {
    if (*(float *)(iVar1 + 0x694) <= fStack_20) {
      fStack_20 = *(float *)(iVar1 + 0x694);
    }
    fVar2 = uStack_28._4_4_;
    if (*(float *)(iVar1 + 0x690) <= uStack_28._4_4_) {
      fVar2 = *(float *)(iVar1 + 0x690);
    }
    if (*(float *)(iVar1 + 0x68c) <= (float)uStack_28) {
      uStack_28._0_4_ = *(float *)(iVar1 + 0x68c);
    }
    uStack_28 = CONCAT44(fVar2,(float)uStack_28);
    if (fStack_14 <= *(float *)(iVar1 + 0x6a0)) {
      fStack_14 = *(float *)(iVar1 + 0x6a0);
    }
    fVar2 = uStack_1c._4_4_;
    if (uStack_1c._4_4_ <= *(float *)(iVar1 + 0x69c)) {
      fVar2 = *(float *)(iVar1 + 0x69c);
    }
    if ((float)uStack_1c <= *(float *)(iVar1 + 0x698)) {
      uStack_1c._0_4_ = *(float *)(iVar1 + 0x698);
    }
    uStack_1c = CONCAT44(fVar2,(float)uStack_1c);
    fStack_8 = fStack_14;
  }
  FUN_008411b0(&uStack_28,*(undefined4 *)(param_1 + 4));
  return;
}



/* FUNCTION 13092 ; VA 0x00858fb0 ; FUN_00858fb0 */

void __fastcall FUN_00858fb0(int param_1)

{
  undefined8 uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  char cVar14;
  undefined4 *puVar15;
  int iVar16;
  undefined4 *puVar17;
  undefined8 *puVar18;
  undefined auStack_b0 [48];
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_14;
  
  if (*(int *)(param_1 + 0x20) == 0) {
    puVar17 = (undefined4 *)FUN_0060efa0();
  }
  else {
    puVar15 = (undefined4 *)FUN_00b077e0();
    uStack_50 = *puVar15;
    uStack_4c = puVar15[1];
    uStack_48 = puVar15[2];
    uStack_44 = puVar15[3];
    uStack_40 = *(undefined8 *)(puVar15 + 4);
    uStack_38 = puVar15[6];
    uStack_34 = puVar15[7];
    puVar17 = &uStack_50;
    uStack_30 = puVar15[8];
    uStack_2c = puVar15[9];
    uStack_28 = puVar15[10];
    uStack_24 = puVar15[0xb];
  }
  uStack_80 = *puVar17;
  uStack_7c = puVar17[1];
  uStack_78 = puVar17[2];
  uStack_74 = puVar17[3];
  uStack_70 = puVar17[4];
  uStack_6c = puVar17[5];
  uStack_68 = puVar17[6];
  uStack_64 = puVar17[7];
  uStack_60 = puVar17[8];
  uStack_5c = puVar17[9];
  uStack_58 = puVar17[10];
  uStack_54 = puVar17[0xb];
  if (((*(int *)(param_1 + 0x28) != 0) &&
      (iStack_14 = *(int *)(*(int *)(param_1 + 0x28) + 0x34), iStack_14 != 0)) &&
     (iVar2 = *(int *)(iStack_14 + 0xc), iVar16 = FUN_00d6bbd0(),
     (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar16 + 0x1d8) <=
     (uint)*(ushort *)(iVar16 + 0x1da))) {
    puVar17 = (undefined4 *)FUN_00d6c6c0(auStack_b0);
    uStack_80 = *puVar17;
    uStack_7c = puVar17[1];
    uStack_78 = puVar17[2];
    uStack_74 = puVar17[3];
    uStack_70 = puVar17[4];
    uStack_6c = puVar17[5];
    uStack_68 = puVar17[6];
    uStack_64 = puVar17[7];
    uStack_60 = puVar17[8];
    uStack_5c = puVar17[9];
    uStack_58 = puVar17[10];
    uStack_54 = puVar17[0xb];
  }
  if (((*(byte *)(param_1 + 0x7c) & 2) == 0) && (cVar14 = FUN_01163470(&uStack_80), cVar14 != '\0'))
  {
    return;
  }
  *(undefined4 *)(param_1 + 0x30) = uStack_80;
  *(undefined4 *)(param_1 + 0x34) = uStack_7c;
  *(undefined4 *)(param_1 + 0x38) = uStack_78;
  *(undefined4 *)(param_1 + 0x3c) = uStack_74;
  *(undefined4 *)(param_1 + 0x40) = uStack_70;
  *(undefined4 *)(param_1 + 0x44) = uStack_6c;
  *(undefined4 *)(param_1 + 0x48) = uStack_68;
  *(undefined4 *)(param_1 + 0x4c) = uStack_64;
  *(undefined4 *)(param_1 + 0x50) = uStack_60;
  *(undefined4 *)(param_1 + 0x54) = uStack_5c;
  *(undefined4 *)(param_1 + 0x58) = uStack_58;
  *(undefined4 *)(param_1 + 0x5c) = uStack_54;
  iVar2 = *(int *)(param_1 + 0x80);
  if (iVar2 != 0) {
    if (*(int *)(param_1 + 0x20) == 0) {
      *(undefined4 *)(iVar2 + 0x10c) = 0;
      *(undefined4 *)(iVar2 + 0x110) = 0;
      *(undefined4 *)(iVar2 + 0x114) = 0;
      *(undefined4 *)(iVar2 + 0x118) = 0;
      *(undefined8 *)(iVar2 + 0x11c) = 0;
    }
    else {
      puVar18 = (undefined8 *)FUN_00b07b60();
      uVar1 = *puVar18;
      uStack_38 = *(undefined4 *)(puVar18 + 1);
      uStack_2c = *(undefined4 *)((int)puVar18 + 0x14);
      uStack_34 = (undefined4)*(undefined8 *)((int)puVar18 + 0xc);
      uStack_30 = (undefined4)((ulonglong)*(undefined8 *)((int)puVar18 + 0xc) >> 0x20);
      uStack_40._0_4_ = (undefined4)uVar1;
      uStack_40._4_4_ = (undefined4)((ulonglong)uVar1 >> 0x20);
      *(undefined4 *)(iVar2 + 0x10c) = (undefined4)uStack_40;
      *(undefined4 *)(iVar2 + 0x110) = uStack_40._4_4_;
      *(undefined4 *)(iVar2 + 0x114) = uStack_38;
      *(undefined4 *)(iVar2 + 0x118) = uStack_34;
      *(ulonglong *)(iVar2 + 0x11c) = CONCAT44(uStack_2c,uStack_30);
      uStack_40 = uVar1;
    }
    iVar2 = *(int *)(param_1 + 0x80);
    uVar3 = *(undefined4 *)(param_1 + 0x34);
    uVar4 = *(undefined4 *)(param_1 + 0x38);
    uVar5 = *(undefined4 *)(param_1 + 0x3c);
    uVar6 = *(undefined4 *)(param_1 + 0x40);
    uVar7 = *(undefined4 *)(param_1 + 0x44);
    uVar8 = *(undefined4 *)(param_1 + 0x48);
    uVar9 = *(undefined4 *)(param_1 + 0x4c);
    uVar10 = *(undefined4 *)(param_1 + 0x50);
    uVar11 = *(undefined4 *)(param_1 + 0x54);
    uVar12 = *(undefined4 *)(param_1 + 0x58);
    uVar13 = *(undefined4 *)(param_1 + 0x5c);
    *(undefined4 *)(iVar2 + 0x14) = *(undefined4 *)(param_1 + 0x30);
    *(undefined4 *)(iVar2 + 0x18) = uVar3;
    *(undefined4 *)(iVar2 + 0x1c) = uVar4;
    *(undefined4 *)(iVar2 + 0x20) = uVar5;
    *(undefined4 *)(iVar2 + 0x24) = uVar6;
    *(undefined4 *)(iVar2 + 0x28) = uVar7;
    *(undefined4 *)(iVar2 + 0x2c) = uVar8;
    *(undefined4 *)(iVar2 + 0x30) = uVar9;
    *(undefined4 *)(iVar2 + 0x34) = uVar10;
    *(undefined4 *)(iVar2 + 0x38) = uVar11;
    *(undefined4 *)(iVar2 + 0x3c) = uVar12;
    *(undefined4 *)(iVar2 + 0x40) = uVar13;
    FUN_0082e260((int *)(param_1 + -0x74));
    (**(code **)(*(int *)(param_1 + -0x74) + 0xc))();
  }
  return;
}



/* FUNCTION 13093 ; VA 0x00859160 ; FUN_00859160 */

void __fastcall FUN_00859160(int *param_1)

{
  if (param_1[3] == param_1[4]) {
    if (param_1 == (int *)0x74) {
      param_1 = (int *)0x0;
    }
    FUN_007c64b0(param_1);
    return;
  }
  FUN_00857ce0();
  (**(code **)(*param_1 + 0x44))();
  param_1[0x1f] = 0;
  return;
}



/* FUNCTION 13094 ; VA 0x008591b0 ; FUN_008591b0 */

void __fastcall FUN_008591b0(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined auStack_1c [24];
  
  if (*(int *)(param_1 + 0xf4) != 0) {
    puVar4 = (undefined4 *)FUN_0082c950(auStack_1c);
    uVar1 = puVar4[1];
    uVar2 = puVar4[2];
    uVar3 = puVar4[3];
    *(undefined4 *)(param_1 + 0xd4) = *puVar4;
    *(undefined4 *)(param_1 + 0xd8) = uVar1;
    *(undefined4 *)(param_1 + 0xdc) = uVar2;
    *(undefined4 *)(param_1 + 0xe0) = uVar3;
    *(undefined8 *)(param_1 + 0xe4) = *(undefined8 *)(puVar4 + 4);
  }
  return;
}



/* FUNCTION 13095 ; VA 0x008591f0 ; FUN_008591f0 */

void __thiscall FUN_008591f0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  char cVar1;
  int iVar2;
  
  cVar1 = FUN_00841130();
  if ((cVar1 == '\0') && (param_4 == 0)) {
    if ((*(char *)(param_1 + 0xec) == '\0') && (*(int *)(param_1 + 0xf4) != 0)) {
      iVar2 = FUN_0082e210();
      if (iVar2 == 0) {
        FUN_00854450(0);
      }
    }
    if (*(int *)(param_1 + 0xf4) != 0) {
      FUN_0082e2a0(*(int *)(param_1 + 0xf4));
      FUN_0082e230(param_1);
    }
    if (*(char *)(*(int *)(*(int *)(param_1 + 8) + 0x510) + 0x20) != '\0') {
      FUN_008416d0(*(int *)(param_1 + 8),param_1 + 0x18);
    }
  }
  return;
}



/* FUNCTION 13096 ; VA 0x00859280 ; FUN_00859280 */

int __thiscall FUN_00859280(uint *param_1,uint param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  uint uVar11;
  uint uVar12;
  
  uVar12 = *param_1;
  iVar10 = param_2 - uVar12;
  iVar2 = (int)(param_1[1] - uVar12) / 0x30;
  if (iVar2 == 0x5555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar8 = iVar2 + 1;
  uVar6 = (int)(param_1[2] - uVar12) / 0x30;
  uVar12 = uVar8;
  if ((uVar6 <= 0x5555555 - (uVar6 >> 1)) && (uVar12 = (uVar6 >> 1) + uVar6, uVar12 < uVar8)) {
    uVar12 = uVar8;
  }
  uVar8 = uVar12 * 0x30;
  if (uVar12 < 0x5555556) {
    uVar12 = uVar8;
    if (0xfff < uVar8) goto LAB_0085931b;
    if (uVar8 == 0) {
      uVar12 = 0;
    }
    else {
      uVar12 = FUN_01674e20(uVar8);
    }
  }
  else {
    uVar12 = 0xffffffff;
LAB_0085931b:
    uVar6 = uVar12 + 0x23;
    if (uVar6 <= uVar12) {
      uVar6 = 0xffffffff;
    }
    iVar7 = FUN_01674e20(uVar6);
    if (iVar7 == 0) goto LAB_00859462;
    uVar12 = iVar7 + 0x23U & 0xffffffe0;
    *(int *)(uVar12 - 4) = iVar7;
  }
  iVar10 = (iVar10 / 0x30) * 0x30;
  uVar3 = param_3[1];
  uVar4 = param_3[2];
  uVar5 = param_3[3];
  puVar1 = (undefined4 *)(iVar10 + uVar12);
  *puVar1 = *param_3;
  puVar1[1] = uVar3;
  puVar1[2] = uVar4;
  puVar1[3] = uVar5;
  uVar3 = param_3[5];
  uVar4 = param_3[6];
  uVar5 = param_3[7];
  puVar1 = (undefined4 *)(iVar10 + 0x10 + uVar12);
  *puVar1 = param_3[4];
  puVar1[1] = uVar3;
  puVar1[2] = uVar4;
  puVar1[3] = uVar5;
  uVar3 = param_3[9];
  uVar4 = param_3[10];
  uVar5 = param_3[0xb];
  puVar1 = (undefined4 *)(iVar10 + 0x20 + uVar12);
  *puVar1 = param_3[8];
  puVar1[1] = uVar3;
  puVar1[2] = uVar4;
  puVar1[3] = uVar5;
  uVar6 = param_1[1];
  if (param_2 == uVar6) {
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    FUN_0170cc70(uVar12,*param_1,uVar6 - *param_1);
  }
  else {
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(uVar12,*param_1,param_2 - *param_1);
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(iVar10 + 0x30 + uVar12,param_2,param_1[1] - param_2);
  }
  uVar6 = *param_1;
  if (uVar6 != 0) {
    uVar9 = ((int)(param_1[2] - uVar6) / 0x30) * 0x30;
    uVar11 = uVar6;
    if (0xfff < uVar9) {
      uVar11 = *(uint *)(uVar6 - 4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (uVar6 - uVar11) - 4) {
LAB_00859462:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar9);
  }
  *param_1 = uVar12;
  param_1[1] = (iVar2 * 3 + 3) * 0x10 + uVar12;
  param_1[2] = uVar8 + uVar12;
  return *param_1 + iVar10;
}



/* FUNCTION 13097 ; VA 0x00859470 ; FUN_00859470 */

void * __thiscall FUN_00859470(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  void *pvVar5;
  int *piVar6;
  int *piVar7;
  undefined4 *puVar8;
  int *piVar9;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a9260;
  puVar8 = *(undefined4 **)(param_1 + 0x2c);
  pvVar5 = ExceptionList;
  if (puVar8 != (undefined4 *)0x0) {
    piVar6 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar6 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      piVar6 = *(int **)(param_1 + 0x30);
      puVar8 = *(undefined4 **)(param_1 + 0x2c);
    }
    piVar1 = (int *)puVar8[1];
    piVar9 = (int *)*puVar8;
    iStack_8 = 0;
    pvVar5 = pvStack_10;
    for (; piVar9 != piVar1; piVar9 = piVar9 + 2) {
      piVar7 = (int *)piVar9[1];
      if (piVar7 != (int *)0x0) {
        LOCK();
        piVar7[1] = piVar7[1] + 1;
        UNLOCK();
        piVar7 = (int *)piVar9[1];
      }
      iVar2 = *piVar9;
      iStack_8._1_3_ = (uint3)((uint)iStack_8 >> 8);
      iStack_8._0_1_ = 1;
      if (((iVar2 != 0) &&
          (iVar3 = *(int *)(iVar2 + 0xc), iVar4 = FUN_00aff8c0(),
          (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
          (uint)*(ushort *)(iVar4 + 0x1da))) && (*(int **)(iVar2 + 0xb0) != (int *)0x0)) {
        (**(code **)(**(int **)(iVar2 + 0xb0) + 0x38))();
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar2 = piVar7[1] + -1;
        piVar7[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar2 = piVar7[2] + -1;
          piVar7[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      pvVar5 = (void *)FUN_00859470(param_2);
    }
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar1 = piVar6 + 1;
      iVar2 = *piVar1;
      pvVar5 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar5 = (void *)(**(code **)*piVar6)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar5 = (void *)(**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 13098 ; VA 0x008595b0 ; FUN_008595b0 */

undefined4 * __thiscall FUN_008595b0(undefined4 *param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b813f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00841300(param_2,0);
  *param_1 = RBX::Graphics::ModelCluster::vftable;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  uVar4 = FUN_005e9aa0(0,0);
  param_1[0x2a] = uVar4;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  uStack_8._0_1_ = 6;
  param_1[0x29] = 0x3f800000;
  FUN_005cb500(8);
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  param_1[0x33] = *param_3;
  param_1[0x34] = param_3[1];
  *(undefined2 *)(param_1 + 0x35) = 0;
  puVar5 = (undefined4 *)FUN_00761960(auStack_1c);
  uVar4 = *puVar5;
  uVar1 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  param_1[0x31] = uVar4;
  piVar2 = (int *)param_1[0x32];
  param_1[0x32] = uVar1;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar2 = piStack_18 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piVar2 = (int *)(*(int *)(puStack_14[2] + 0x524) + 0x88);
  *piVar2 = *piVar2 + 1;
  ExceptionList = pvStack_10;
  return puStack_14;
}



/* FUNCTION 13099 ; VA 0x00859790 ; FUN_00859790 */

undefined4 * __thiscall
FUN_00859790(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  iVar2 = (int)param_2;
  puStack_c = &LAB_017b81f2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  uStack_8 = 4;
  uStack_7 = 0;
  FUN_0060dcd0(param_1 + 7,param_2);
  param_1[0xb] = param_3;
  param_1[0xe] = param_4;
  param_4 = iVar2 + 0x48;
  param_1[9] = 0xd;
  param_1[10] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0xffffffff;
  uStack_8 = 6;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 7;
  puVar5 = (undefined4 *)FUN_01674e20(0x1c);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_0085a250;
    puVar5[3] = _guard_check_icall;
    puVar5[4] = 0;
    puVar5[5] = param_4;
    puVar5[6] = param_1;
  }
  FUN_016797d0(puVar5);
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 8;
  param_3 = puVar5;
  FUN_01675290(uVar4);
  _uStack_8 = CONCAT31(uStack_7,6);
  cVar3 = FUN_01679300(&param_3);
  if (cVar3 != '\0') {
    FUN_01679490();
    FUN_016791c0(&param_3);
  }
  if (param_3 != (undefined4 *)0x0) {
    piVar1 = param_3 + 1;
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(param_3);
    }
  }
  param_4 = (int)param_2 + 0x7c;
  uStack_8 = 9;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 10;
  puVar5 = (undefined4 *)FUN_01674e20(0x1c);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_0085a230;
    puVar5[3] = _guard_check_icall;
    puVar5[4] = 0;
    puVar5[5] = param_4;
    puVar5[6] = param_1;
  }
  FUN_016797d0(puVar5);
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 0xb;
  param_3 = puVar5;
  FUN_01675290(uVar4);
  _uStack_8 = CONCAT31(uStack_7,9);
  cVar3 = FUN_01679300(&param_3);
  if (cVar3 != '\0') {
    FUN_01679490();
    FUN_016791c0(&param_3);
  }
  if (param_3 != (undefined4 *)0x0) {
    piVar1 = param_3 + 1;
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(param_3);
    }
  }
  param_3 = (undefined4 *)((int)param_2 + 0x4c);
  uStack_8 = 0xc;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0xd;
  param_4 = uVar4;
  puVar5 = (undefined4 *)FUN_01674e20(0x1c);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_0085a360;
    puVar5[3] = _guard_check_icall;
    puVar5[4] = 0;
    puVar5[5] = param_3;
    puVar5[6] = param_1;
  }
  FUN_016797d0(puVar5);
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 0xe;
  param_2 = puVar5;
  FUN_01675290(uVar4);
  _uStack_8 = CONCAT31(uStack_7,0xc);
  cVar3 = FUN_01679300(&param_2);
  if (cVar3 != '\0') {
    FUN_01679490();
    FUN_016791c0(&param_2);
  }
  _uStack_8 = CONCAT31(uStack_7,5);
  if (param_2 != (undefined4 *)0x0) {
    piVar1 = param_2 + 1;
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(param_2);
    }
  }
  FUN_0085a570();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13100 ; VA 0x00859ae0 ; FUN_00859ae0 */

undefined4 * __thiscall
FUN_00859ae0(undefined4 *param_1,int param_2,undefined4 param_3,int *param_4,undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piStack_40;
  int *piStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b8218;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_0147c770();
  uStack_8._0_1_ = 1;
  uVar4 = FUN_0147c770();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00841220(param_2,uVar4,uVar3,param_5,0,0xff,0);
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_28[1] + -1;
    piStack_28[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      iVar2 = piStack_28[2] + -1;
      piStack_28[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  if (piStack_40 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_40[1] + -1;
    piStack_40[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_40)();
      LOCK();
      iVar2 = piStack_40[2] + -1;
      piStack_40[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_40 + 4))();
      }
    }
  }
  *param_1 = RBX::Graphics::ModelLodEntity::vftable;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  param_1[0x1c] = param_3;
  param_1[0x1e] = 0x7f7fffff;
  param_1[0x1f] = 0x7f7fffff;
  param_1[0x20] = 0x7f7fffff;
  param_1[0x1d] = param_4;
  param_1[0x21] = 0xff7fffff;
  param_1[0x22] = 0xff7fffff;
  param_1[0x23] = 0xff7fffff;
  *(undefined2 *)(param_1 + 0x24) = 0;
  piVar1 = (int *)(*(int *)(*(int *)(param_2 + 8) + 0x524) + 0x8c);
  *piVar1 = *piVar1 + 1;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13101 ; VA 0x00859c80 ; FUN_00859c80 */

void __fastcall FUN_00859c80(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  uint uStack_8;
  
  uStack_8 = 0;
  *param_1 = RBX::Graphics::ModelCluster::vftable;
  piVar5 = (int *)param_1[0x1d];
  uVar4 = (param_1[0x1e] - (int)piVar5) + 3U >> 2;
  if ((int *)param_1[0x1e] < piVar5) {
    uVar4 = 0;
  }
  if (uVar4 != 0) {
    do {
      iVar2 = *piVar5;
      if (iVar2 != 0) {
        FUN_00859e90();
        FUN_01674ea0(iVar2,0x3c);
      }
      uStack_8 = uStack_8 + 1;
      piVar5 = piVar5 + 1;
    } while (uStack_8 != uVar4);
  }
  piVar5 = (int *)(*(int *)(param_1[2] + 0x524) + 0x88);
  *piVar5 = *piVar5 + -1;
  piVar5 = (int *)param_1[0x32];
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar2 = piVar5[1] + -1;
    piVar5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  FUN_005e61c0();
  iVar2 = param_1[0x26];
  if (iVar2 != 0) {
    uVar4 = param_1[0x28] - iVar2 & 0xfffffffc;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00859e88;
    }
    FUN_01674ea0(iVar3,uVar4);
    param_1[0x26] = 0;
    param_1[0x27] = 0;
    param_1[0x28] = 0;
  }
  iVar2 = param_1[0x23];
  if (iVar2 != 0) {
    uVar4 = param_1[0x25] - iVar2 & 0xfffffffc;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00859e88;
    }
    FUN_01674ea0(iVar3,uVar4);
    param_1[0x23] = 0;
    param_1[0x24] = 0;
    param_1[0x25] = 0;
  }
  iVar2 = param_1[0x20];
  if (iVar2 != 0) {
    uVar4 = param_1[0x22] - iVar2 & 0xfffffffc;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00859e88;
    }
    FUN_01674ea0(iVar3,uVar4);
    param_1[0x20] = 0;
    param_1[0x21] = 0;
    param_1[0x22] = 0;
  }
  iVar2 = param_1[0x1d];
  if (iVar2 != 0) {
    uVar4 = param_1[0x1f] - iVar2 & 0xfffffffc;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00859e88:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
    param_1[0x1d] = 0;
    param_1[0x1e] = 0;
    param_1[0x1f] = 0;
  }
  FUN_00841420();
  return;
}



/* FUNCTION 13102 ; VA 0x00859e90 ; FUN_00859e90 */

void __fastcall FUN_00859e90(int *param_1)

{
  int *piVar1;
  int iVar2;
  void **ppvVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017949a0;
  iVar2 = param_1[5];
  ppvVar3 = &pvStack_10;
  pvStack_10 = ExceptionList;
  for (iVar4 = param_1[4]; ExceptionList = ppvVar3, iVar4 != iVar2; iVar4 = iVar4 + 4) {
    FUN_01679490();
    ppvVar3 = (void **)ExceptionList;
  }
  if (param_1[10] != 0) {
    piVar1 = (int *)(*(int *)(*(int *)(param_1[0xb] + 8) + 0x524) + 0x84);
    *piVar1 = *piVar1 + -1;
  }
  piVar1 = (int *)param_1[8];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[1] + -1;
    piVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_006378f0();
  uStack_8 = 0;
  FUN_01679490();
  iVar2 = param_1[3];
  if (iVar2 != 0) {
    piVar1 = (int *)(iVar2 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar2);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar2 = param_1[2];
  if (iVar2 != 0) {
    piVar1 = (int *)(iVar2 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar2);
    }
  }
  uStack_8 = 2;
  FUN_01679490();
  iVar2 = param_1[1];
  if (iVar2 != 0) {
    piVar1 = (int *)(iVar2 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar2);
    }
  }
  uStack_8 = 3;
  FUN_01679490();
  iVar2 = *param_1;
  if (iVar2 != 0) {
    piVar1 = (int *)(iVar2 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar2);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13103 ; VA 0x00859fe0 ; FUN_00859fe0 */

undefined4 __thiscall FUN_00859fe0(undefined4 param_1,byte param_2)

{
  FUN_00859c80();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xd8);
  }
  return param_1;
}



/* FUNCTION 13104 ; VA 0x0085a010 ; FUN_0085a010 */

undefined4 * __thiscall FUN_0085a010(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  *param_1 = RBX::Graphics::ModelLodEntity::vftable;
  piVar2 = (int *)(*(int *)(*(int *)(param_1[1] + 8) + 0x524) + 0x8c);
  *piVar2 = *piVar2 + -1;
  piVar2 = (int *)param_1[0x1d];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00612d60();
  iVar3 = param_1[0x16];
  if (iVar3 != 0) {
    uVar5 = param_1[0x18] - iVar3 & 0xfffffffc;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    param_1[0x16] = 0;
    param_1[0x17] = 0;
    param_1[0x18] = 0;
  }
  FUN_007c27b0();
  FUN_00841390();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x94);
  }
  return param_1;
}



/* FUNCTION 13105 ; VA 0x0085a0e0 ; FUN_0085a0e0 */

void __thiscall FUN_0085a0e0(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ad84f;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x78);
  iVar2 = *(int *)(param_1 + 0x74);
  ExceptionList = &pvStack_10;
  iVar4 = FUN_01674e20(0x3c);
  uStack_8 = 0;
  if (iVar4 == 0) {
    param_2 = 0;
  }
  else {
    param_2 = FUN_00859790(param_2,param_1,iVar1 - iVar2 >> 2);
  }
  puVar3 = *(undefined4 **)(param_1 + 0x78);
  uStack_8 = 0xffffffff;
  if (*(undefined4 **)(param_1 + 0x7c) != puVar3) {
    *puVar3 = param_2;
    *(int *)(param_1 + 0x78) = *(int *)(param_1 + 0x78) + 4;
    ExceptionList = pvStack_10;
    return;
  }
  FUN_0063d9b0(puVar3,&param_2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13106 ; VA 0x0085a180 ; FUN_0085a180 */

void FUN_0085a180(int *param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  uint uVar3;
  int iVar4;
  int aiStack_1c [5];
  uint uStack_8;
  
  puVar2 = (undefined4 *)(**(code **)(*param_1 + 0x30))(aiStack_1c);
  puVar1 = puVar2 + 4;
  if (0xf < (uint)puVar2[5]) {
    puVar2 = (undefined4 *)*puVar2;
  }
  uVar3 = FUN_0055c360(puVar2,*puVar1,"glsles3",7);
  DAT_01d62368 = ((uVar3 & 0xff ^ 1) + 1) * 0x40;
  if (0xf < uStack_8) {
    uVar3 = uStack_8 + 1;
    iVar4 = aiStack_1c[0];
    if (0xfff < uVar3) {
      iVar4 = *(int *)(aiStack_1c[0] + -4);
      uVar3 = uStack_8 + 0x24;
      if (0x1f < (aiStack_1c[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar3);
  }
  return;
}



/* FUNCTION 13107 ; VA 0x0085a200 ; FUN_0085a200 */

void FUN_0085a200(int param_1,undefined4 *param_2)

{
  uint *puVar1;
  
  if (param_2 == &DAT_0212ccf0) {
    puVar1 = (uint *)(*(int *)(param_1 + 0x18) + 0x24);
    *puVar1 = *puVar1 | 1;
    FUN_0085a570();
    return;
  }
  return;
}



/* FUNCTION 13108 ; VA 0x0085a230 ; FUN_0085a230 */

void FUN_0085a230(int param_1)

{
  uint *puVar1;
  
  if (*(int *)(*(int *)(param_1 + 0x18) + 0x28) != 0) {
    puVar1 = (uint *)(*(int *)(param_1 + 0x18) + 0x24);
    *puVar1 = *puVar1 | 1;
    FUN_0085a570();
    return;
  }
  return;
}



/* FUNCTION 13109 ; VA 0x0085a250 ; FUN_0085a250 */

int FUN_0085a250(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  uint *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b8250;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 3;
  puVar1 = (uint *)(*(int *)(param_1 + 0x18) + 0x24);
  *puVar1 = *puVar1 | 3;
  iVar4 = FUN_0085a570();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar3 = *piVar2;
      iVar4 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar2 = param_5 + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar2 = param_5 + 2;
      iVar3 = *piVar2;
      iVar4 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar3 = *piVar2;
      iVar4 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar2 = param_5 + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar4 = (**(code **)*param_5)();
      LOCK();
      piVar2 = param_5 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar4 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 13110 ; VA 0x0085a360 ; FUN_0085a360 */

void FUN_0085a360(int param_1,undefined4 *param_2)

{
  uint *puVar1;
  
  if (param_2 == &DAT_0212ccb8) {
    puVar1 = (uint *)(*(int *)(param_1 + 0x18) + 0x24);
    *puVar1 = *puVar1 | 9;
    FUN_0085a570();
    return;
  }
  if ((param_2 != (undefined4 *)&DAT_0212cc48) && (param_2 != &DAT_0212cc80)) {
    if (param_2 == &DAT_0212ccf0) {
      puVar1 = (uint *)(*(int *)(param_1 + 0x18) + 0x24);
      *puVar1 = *puVar1 | 1;
      FUN_0085a570();
      return;
    }
    return;
  }
  puVar1 = (uint *)(*(int *)(param_1 + 0x18) + 0x24);
  *puVar1 = *puVar1 | 4;
  FUN_0085a570();
  return;
}



/* FUNCTION 13111 ; VA 0x0085a3c0 ; FUN_0085a3c0 */

undefined4 __thiscall FUN_0085a3c0(int param_1,uint *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  uint uVar10;
  undefined4 *puVar11;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8272;
  pvStack_10 = ExceptionList;
  uVar2 = *param_2;
  puVar3 = *(undefined4 **)(param_1 + 0xa8);
  uVar10 = *(uint *)(param_1 + 0xbc) &
           (((uVar2 >> 8 & 0xff ^ (uVar2 & 0xff ^ 0x811c9dc5) * 0x1000193) * 0x1000193 ^
            uVar2 >> 0x10 & 0xff) * 0x1000193 ^ uVar2 >> 0x18) * 0x1000193;
  puVar4 = *(undefined4 **)(*(int *)(param_1 + 0xb0) + uVar10 * 8);
  puVar6 = puVar4;
  while( true ) {
    puVar11 = puVar3;
    if (puVar4 != puVar3) {
      puVar11 = (undefined4 *)**(undefined4 **)(uVar10 * 8 + 4 + *(int *)(param_1 + 0xb0));
    }
    if (puVar6 == puVar11) goto LAB_0085a487;
    if (puVar6[2] == uVar2) break;
    puVar6 = (undefined4 *)*puVar6;
  }
  if (puVar6 != puVar3) {
    return puVar6[3];
  }
LAB_0085a487:
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  iVar7 = FUN_01674e20(0x94);
  iVar5 = iStack_14;
  uStack_8 = 0;
  if (iVar7 == 0) {
    uVar8 = 0;
  }
  else {
    if (param_2[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uVar8 = FUN_00859ae0(iStack_14,*param_2,param_2[1],iStack_14 + 0xc4);
  }
  uStack_8 = 0xffffffff;
  FUN_00841620(uVar8);
  iVar7 = **(int **)(iVar5 + 0xa8);
  puVar3 = *(undefined4 **)(iVar7 + 4);
  uStack_18 = uVar2;
  iStack_14 = uVar8;
  uVar9 = FUN_005e5370(iVar7,puVar3,&uStack_18);
  if (*(int *)(iVar5 + 0xac) == 0xffffffe) {
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("list<T> too long");
  }
  *(int *)(iVar5 + 0xac) = *(int *)(iVar5 + 0xac) + 1;
  *(undefined4 *)(iVar7 + 4) = uVar9;
  *puVar3 = uVar9;
  iVar5 = **(int **)(iVar5 + 0xa8);
  FUN_00708c90(&uStack_18,iVar5 + 8,iVar5);
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 13112 ; VA 0x0085a570 ; FUN_0085a570 */

void __fastcall FUN_0085a570(int param_1)

{
  int iVar1;
  int *piVar2;
  int iStack_8;
  
  if ((*(uint *)(param_1 + 0x24) >> 5 & 1) == 0) {
    iVar1 = *(int *)(param_1 + 0x2c);
    *(uint *)(param_1 + 0x24) = *(uint *)(param_1 + 0x24) | 0x20;
    piVar2 = *(int **)(iVar1 + 0x9c);
    iStack_8 = param_1;
    if (*(int **)(iVar1 + 0xa0) == piVar2) {
      FUN_0063d9b0(piVar2,&iStack_8);
    }
    else {
      *piVar2 = param_1;
      *(int *)(iVar1 + 0x9c) = *(int *)(iVar1 + 0x9c) + 4;
    }
    if (*(char *)(iVar1 + 0xd5) == '\0') {
      FUN_007c8d30(iVar1);
      *(undefined *)(iVar1 + 0xd5) = 1;
    }
  }
  return;
}



/* FUNCTION 13113 ; VA 0x0085a5e0 ; FUN_0085a5e0 */

void __fastcall FUN_0085a5e0(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  void **ppvVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  int iVar8;
  int iVar9;
  undefined4 *puStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b2c61;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)(param_1 + 0x10);
  iVar9 = *piVar1;
  iVar4 = *(int *)(param_1 + 0x14);
  ExceptionList = &pvStack_10;
  ppvVar3 = &pvStack_10;
  iStack_18 = param_1;
  if (iVar9 != iVar4) {
    do {
      FUN_01679490();
      iVar9 = iVar9 + 4;
    } while (iVar9 != iVar4);
    iVar4 = *(int *)(param_1 + 0x14);
    ppvVar3 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar3;
  FUN_00633350(*piVar1,iVar4,piVar1);
  *(int *)(param_1 + 0x14) = *piVar1;
  for (iVar9 = *(int *)(*(int *)(iStack_18 + 0x1c) + 0x34); iVar9 != 0;
      iVar9 = *(int *)(iVar9 + 0x34)) {
    iVar4 = *(int *)(iVar9 + 0xc);
    iStack_14 = iVar9;
    iVar5 = FUN_00b63e30();
    iVar8 = 0;
    if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
        (uint)*(ushort *)(iVar5 + 0x1da)) {
      iVar8 = iVar9;
    }
    if (iVar8 != 0) {
      iStack_8 = 0;
      uVar6 = FUN_01675290(DAT_02110da8);
      iStack_8._0_1_ = 1;
      puVar7 = (undefined4 *)FUN_01674e20(0x1c);
      if (puVar7 == (undefined4 *)0x0) {
        puVar7 = (undefined4 *)0x0;
      }
      else {
        *puVar7 = 0;
        puVar7[1] = 1;
        puVar7[2] = FUN_0085a200;
        puVar7[3] = _guard_check_icall;
        puVar7[4] = 0;
        puVar7[5] = iVar8 + 0x4c;
        puVar7[6] = iStack_18;
      }
      FUN_016797d0(puVar7);
      if (puVar7 != (undefined4 *)0x0) {
        LOCK();
        puVar7[1] = puVar7[1] + 1;
        UNLOCK();
      }
      iStack_8._0_1_ = 2;
      puStack_1c = puVar7;
      FUN_01675290(uVar6);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      puVar2 = *(undefined4 **)(iStack_18 + 0x14);
      if (*(undefined4 **)(iStack_18 + 0x18) == puVar2) {
        FUN_006335f0(puVar2,&puStack_1c);
      }
      else {
        *puVar2 = puVar7;
        *(int *)(iStack_18 + 0x14) = *(int *)(iStack_18 + 0x14) + 4;
        puStack_1c = (undefined4 *)0x0;
      }
      iStack_8 = 0xffffffff;
      iVar9 = iStack_14;
      if (puStack_1c != (undefined4 *)0x0) {
        piVar1 = puStack_1c + 1;
        LOCK();
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          FUN_01674ea0(puStack_1c);
          iVar9 = iStack_14;
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13114 ; VA 0x0085a790 ; FUN_0085a790 */

void __thiscall FUN_0085a790(int param_1,int param_2)

{
  uint uVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined4 *puVar15;
  
  uVar1 = *(uint *)(param_2 + 0x34);
  *(undefined4 *)(param_2 + 0x34) = 0xffffffff;
  *(undefined4 *)(param_2 + 0x30) = 0;
  if (uVar1 < (*(int *)(param_1 + 0x5c) - *(int *)(param_1 + 0x58) >> 2) - 1U) {
    iVar2 = *(int *)(param_1 + 0x50);
    uVar4 = *(undefined4 *)(iVar2 + -0x2c);
    uVar5 = *(undefined4 *)(iVar2 + -0x28);
    uVar6 = *(undefined4 *)(iVar2 + -0x24);
    uVar7 = *(undefined4 *)(iVar2 + -0x20);
    uVar8 = *(undefined4 *)(iVar2 + -0x1c);
    uVar9 = *(undefined4 *)(iVar2 + -0x18);
    uVar10 = *(undefined4 *)(iVar2 + -0x14);
    uVar11 = *(undefined4 *)(iVar2 + -0x10);
    uVar12 = *(undefined4 *)(iVar2 + -0xc);
    uVar13 = *(undefined4 *)(iVar2 + -8);
    uVar14 = *(undefined4 *)(iVar2 + -4);
    puVar15 = (undefined4 *)(uVar1 * 0x30 + *(int *)(param_1 + 0x4c));
    *puVar15 = *(undefined4 *)(iVar2 + -0x30);
    puVar15[1] = uVar4;
    puVar15[2] = uVar5;
    puVar15[3] = uVar6;
    puVar15[4] = uVar7;
    puVar15[5] = uVar8;
    puVar15[6] = uVar9;
    puVar15[7] = uVar10;
    puVar15[8] = uVar11;
    puVar15[9] = uVar12;
    puVar15[10] = uVar13;
    puVar15[0xb] = uVar14;
    *(undefined4 *)(*(int *)(param_1 + 0x58) + uVar1 * 4) =
         *(undefined4 *)(*(int *)(param_1 + 0x5c) + -4);
    *(uint *)(*(int *)(*(int *)(param_1 + 0x58) + uVar1 * 4) + 0x34) = uVar1;
  }
  *(int *)(param_1 + 0x5c) = *(int *)(param_1 + 0x5c) + -4;
  *(int *)(param_1 + 0x50) = *(int *)(param_1 + 0x50) + -0x30;
  *(int *)(param_1 + 0x68) = *(int *)(param_1 + 0x68) + -0x18;
  if (*(int *)(param_1 + 0x58) == *(int *)(param_1 + 0x5c)) {
    iVar2 = *(int *)(param_2 + 0x2c);
    if (*(char *)(param_1 + 0x91) == '\0') {
      *(undefined *)(param_1 + 0x91) = 1;
      piVar3 = *(int **)(iVar2 + 0x90);
      if (*(int **)(iVar2 + 0x94) != piVar3) {
        *piVar3 = param_1;
        *(int *)(iVar2 + 0x90) = *(int *)(iVar2 + 0x90) + 4;
        *(undefined *)(iVar2 + 0xd4) = 1;
        return;
      }
      param_2 = param_1;
      FUN_006030d0(piVar3,&param_2);
      *(undefined *)(iVar2 + 0xd4) = 1;
    }
  }
  return;
}



/* FUNCTION 13115 ; VA 0x0085a860 ; FUN_0085a860 */

void FUN_0085a860(int *param_1,int *param_2,int param_3,int *param_4)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  undefined auStack_1818 [6112];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  FUN_016f40d0();
  iVar3 = DAT_01d62368;
  iVar7 = 0;
  if (param_3 != 0) {
    piVar1 = param_2 + 2;
    do {
      iVar4 = *(int *)(*param_2 + 0x4c);
      uVar6 = (*(int *)(*param_2 + 0x50) - iVar4) / 0x30;
      param_4[1] = param_4[1] + *(int *)(*piVar1 + 0x14) * uVar6;
      for (; uVar6 != 0; uVar6 = uVar6 - uVar5) {
        uVar5 = iVar3 - iVar7;
        if (uVar6 <= uVar5) {
          uVar5 = uVar6;
        }
        iStack_14 = uVar5 * 0x30;
        puStack_1c = auStack_1818 + iVar7 * 0x30;
        puStack_20 = (undefined *)0x85a8f8;
        puStack_18 = (undefined *)iVar4;
        FUN_0170c6f0();
        iVar7 = iVar7 + uVar5;
        if (iVar7 == iVar3) {
          puStack_18 = auStack_1818;
          puStack_1c = (undefined *)0x1;
          puStack_20 = (undefined *)0x85a91d;
          iStack_14 = iVar7 * 0x30;
          (**(code **)(*param_1 + 0x30))();
          puStack_20 = puStack_18;
          puVar2 = (undefined4 *)*piVar1;
          uStack_24 = puVar2[5];
          uStack_28 = puVar2[4];
          uStack_2c = puVar2[3];
          uStack_30 = puVar2[2];
          uStack_34 = *puVar2;
          uStack_38 = 0x85a93b;
          (**(code **)(*param_1 + 0x40))();
          param_4[2] = param_4[2] + iVar7 * 0x30;
          *param_4 = *param_4 + 1;
          iVar7 = 0;
        }
        iVar4 = iVar4 + iStack_14;
      }
      param_2 = param_2 + 6;
      param_3 = param_3 + -1;
    } while (param_3 != 0);
    if (iVar7 != 0) {
      puStack_18 = auStack_1818;
      puStack_1c = (undefined *)0x1;
      puStack_20 = (undefined *)0x85a98d;
      iStack_14 = iVar7 * 0x30;
      (**(code **)(*param_1 + 0x30))();
      puVar2 = (undefined4 *)*piVar1;
      uStack_24 = puVar2[5];
      uStack_28 = puVar2[4];
      uStack_2c = puVar2[3];
      uStack_30 = puVar2[2];
      uStack_34 = *puVar2;
      uStack_38 = 0x85a9a8;
      puStack_20 = (undefined *)iVar7;
      (**(code **)(*param_1 + 0x40))();
      param_4[2] = param_4[2] + iVar7 * 0x30;
      *param_4 = *param_4 + 1;
    }
  }
  return;
}



/* FUNCTION 13116 ; VA 0x0085a9c0 ; FUN_0085a9c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_0085a9c0(int param_1)

{
  float fVar1;
  int iVar2;
  int iVar3;
  float fVar4;
  float *pfVar5;
  uint uVar6;
  int *piVar7;
  int *piVar8;
  uint uVar9;
  float fVar10;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_34;
  float fStack_28;
  float fStack_1c;
  float fStack_10;
  int *piStack_c;
  int iStack_8;
  
  uVar9 = 0;
  uVar6 = (*(uint *)(param_1 + 0x9c) - *(uint *)(param_1 + 0x98)) + 3 >> 2;
  if (*(uint *)(param_1 + 0x9c) < *(uint *)(param_1 + 0x98)) {
    uVar6 = 0;
  }
  iStack_8 = param_1;
  if (uVar6 != 0) {
    do {
      FUN_0085ad30();
      uVar9 = uVar9 + 1;
    } while (uVar9 != uVar6);
  }
  *(undefined4 *)(iStack_8 + 0x9c) = *(undefined4 *)(iStack_8 + 0x98);
  if (*(char *)(iStack_8 + 0xd4) == '\0') {
    *(undefined *)(iStack_8 + 0xd5) = 0;
    return;
  }
  piVar8 = *(int **)(iStack_8 + 0x80);
  piVar7 = (int *)0x0;
  piStack_c = (int *)((uint)((int)*(int **)(iStack_8 + 0x84) + (3 - (int)piVar8)) >> 2);
  if (*(int **)(iStack_8 + 0x84) < piVar8) {
    piStack_c = (int *)0x0;
  }
  if (piStack_c != (int *)0x0) {
    do {
      iVar2 = *(int *)(*piVar8 + 0x38);
      *(undefined4 *)(*(int *)(iStack_8 + 0x74) + iVar2 * 4) =
           *(undefined4 *)(*(int *)(iStack_8 + 0x78) + -4);
      *(int *)(*(int *)(*(int *)(iStack_8 + 0x74) + iVar2 * 4) + 0x38) = iVar2;
      *(int *)(iStack_8 + 0x78) = *(int *)(iStack_8 + 0x78) + -4;
      iVar2 = *piVar8;
      if (iVar2 != 0) {
        FUN_00859e90();
        FUN_01674ea0(iVar2,0x3c);
      }
      piVar7 = (int *)((int)piVar7 + 1);
      piVar8 = piVar8 + 1;
    } while (piVar7 != piStack_c);
  }
  iVar2 = iStack_8;
  *(undefined4 *)(iStack_8 + 0x84) = *(undefined4 *)(iStack_8 + 0x80);
  piVar8 = *(int **)(iStack_8 + 0x90);
  fVar4 = DAT_018c45d0;
  fStack_54 = _DAT_018c4eb0;
  fStack_50 = _UNK_018c4eb4;
  fStack_4c = _UNK_018c4eb8;
  fStack_48 = _UNK_018c4ebc;
  for (piVar7 = *(int **)(iStack_8 + 0x8c); DAT_018c45d0 = fVar4, _DAT_018c4eb0 = fStack_54,
      _UNK_018c4eb4 = fStack_50, _UNK_018c4eb8 = fStack_4c, _UNK_018c4ebc = fStack_48,
      piVar7 != piVar8; piVar7 = piVar7 + 1) {
    iVar3 = *piVar7;
    if (*(int *)(iVar3 + 0x58) == *(int *)(iVar3 + 0x5c)) {
      piStack_c = *(int **)(iVar3 + 0x70);
      FUN_0070c9a0(&piStack_c);
      FUN_00841aa0(*piVar7);
      if ((undefined4 *)*piVar7 != (undefined4 *)0x0) {
        (*(code *)**(undefined4 **)*piVar7)(1);
      }
    }
    else {
      *(undefined *)(iVar3 + 0x91) = 0;
    }
    fVar4 = DAT_018c45d0;
    fStack_54 = _DAT_018c4eb0;
    fStack_50 = _UNK_018c4eb4;
    fStack_4c = _UNK_018c4eb8;
    fStack_48 = _UNK_018c4ebc;
  }
  *(undefined4 *)(iVar2 + 0x90) = *(undefined4 *)(iVar2 + 0x8c);
  piStack_c = *(int **)(iVar2 + 0x3c);
  fStack_44 = fVar4;
  fStack_40 = fVar4;
  for (piVar8 = *(int **)(iVar2 + 0x38); piVar8 != piStack_c; piVar8 = piVar8 + 1) {
    iVar3 = *piVar8;
    if (*(char *)(iVar3 + 0x90) != '\0') {
      *(undefined4 *)(iVar3 + 0x78) = 0x7f7fffff;
      *(undefined4 *)(iVar3 + 0x7c) = 0x7f7fffff;
      *(undefined4 *)(iVar3 + 0x80) = 0x7f7fffff;
      *(float *)(iVar3 + 0x84) = fVar4;
      *(ulonglong *)(iVar3 + 0x88) = CONCAT44(fVar4,fVar4);
      for (pfVar5 = *(float **)(iVar3 + 100); pfVar5 != *(float **)(iVar3 + 0x68);
          pfVar5 = pfVar5 + 6) {
        fStack_10 = *(float *)(iVar3 + 0x80);
        if (pfVar5[2] <= *(float *)(iVar3 + 0x80)) {
          fStack_10 = pfVar5[2];
        }
        fVar10 = *(float *)(iVar3 + 0x7c);
        if (pfVar5[1] <= *(float *)(iVar3 + 0x7c)) {
          fVar10 = pfVar5[1];
        }
        fVar1 = *(float *)(iVar3 + 0x78);
        if (*pfVar5 <= *(float *)(iVar3 + 0x78)) {
          fVar1 = *pfVar5;
        }
        *(ulonglong *)(iVar3 + 0x78) = CONCAT44(fVar10,fVar1);
        *(float *)(iVar3 + 0x80) = fStack_10;
        fStack_1c = *(float *)(iVar3 + 0x8c);
        if (*(float *)(iVar3 + 0x8c) <= pfVar5[5]) {
          fStack_1c = pfVar5[5];
        }
        fVar10 = *(float *)(iVar3 + 0x88);
        if (*(float *)(iVar3 + 0x88) <= pfVar5[4]) {
          fVar10 = pfVar5[4];
        }
        fVar1 = *(float *)(iVar3 + 0x84);
        if (*(float *)(iVar3 + 0x84) <= pfVar5[3]) {
          fVar1 = pfVar5[3];
        }
        *(ulonglong *)(iVar3 + 0x84) = CONCAT44(fVar10,fVar1);
        *(float *)(iVar3 + 0x8c) = fStack_1c;
      }
      *(undefined *)(iVar3 + 0x90) = 0;
    }
    if (*(float *)(iVar3 + 0x80) <= fStack_4c) {
      fStack_4c = *(float *)(iVar3 + 0x80);
    }
    if (*(float *)(iVar3 + 0x7c) <= fStack_50) {
      fStack_50 = *(float *)(iVar3 + 0x7c);
    }
    if (*(float *)(iVar3 + 0x78) <= fStack_54) {
      fStack_54 = *(float *)(iVar3 + 0x78);
    }
    fStack_58 = (float)((ulonglong)*(undefined8 *)(iVar3 + 0x88) >> 0x20);
    if (fStack_40 <= fStack_58) {
      fStack_40 = fStack_58;
    }
    fStack_5c = (float)*(undefined8 *)(iVar3 + 0x88);
    if (fStack_44 <= fStack_5c) {
      fStack_44 = fStack_5c;
    }
    if (fStack_48 <= *(float *)(iVar3 + 0x84)) {
      fStack_48 = *(float *)(iVar3 + 0x84);
    }
    fStack_34 = fStack_40;
    fStack_28 = fStack_4c;
  }
  FUN_008411b0(&fStack_54,*(undefined4 *)(*(int *)(*(int *)(iVar2 + 8) + 0x4e4) + 0x24));
  *(undefined2 *)(iVar2 + 0xd4) = 0;
  return;
}



/* FUNCTION 13117 ; VA 0x0085ad30 ; FUN_0085ad30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __fastcall FUN_0085ad30(int *param_1)

{
  uint *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  char cVar6;
  int *piVar7;
  int iVar8;
  undefined4 uVar9;
  uint uVar10;
  uint uVar11;
  undefined auStack_c4 [4];
  uint uStack_c0;
  undefined4 uStack_b0;
  uint uStack_ac;
  uint uStack_a4;
  undefined4 uStack_94;
  uint uStack_90;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8293;
  pvStack_10 = ExceptionList;
  puVar1 = (uint *)(param_1 + 9);
  uVar10 = param_1[9] & 0xffffffdf;
  iStack_18 = param_1[7];
  piVar7 = (int *)(uVar10 >> 1);
  ExceptionList = &pvStack_10;
  *puVar1 = uVar10;
  if (((uint)piVar7 & 1) != 0) {
    iVar8 = FUN_008b3380(iStack_18);
    if (iVar8 == 0) {
      *puVar1 = *puVar1 | 0x10;
      if (param_1[0xc] != 0) {
        FUN_0085a790(param_1);
      }
      iVar8 = param_1[0xb];
      piVar7 = *(int **)(iVar8 + 0x84);
      if (*(int **)(iVar8 + 0x88) == piVar7) {
        piStack_24 = param_1;
        piVar7 = (int *)FUN_0063d9b0(piVar7,&piStack_24);
        *(undefined *)(iVar8 + 0xd4) = 1;
        ExceptionList = pvStack_10;
        return piVar7;
      }
      *piVar7 = (int)param_1;
      *(int *)(iVar8 + 0x84) = *(int *)(iVar8 + 0x84) + 4;
      *(undefined *)(iVar8 + 0xd4) = 1;
      ExceptionList = pvStack_10;
      return piVar7;
    }
    piVar7 = (int *)FUN_0085a5e0();
    *puVar1 = *puVar1 & 0xfffffffd;
    uVar10 = (uint)*(byte *)puVar1;
  }
  if ((uVar10 & 1) == 0) goto LAB_0085aec1;
  iVar8 = FUN_00b65f00(iStack_18);
  if ((iVar8 == iStack_18) && (cVar6 = FUN_00b66010(), cVar6 != '\0')) {
    piStack_1c = (int *)((*(char *)(iStack_18 + 0x140) != '\0') + 1);
  }
  else {
    piStack_1c = (int *)0x0;
  }
  if ((DAT_01d62360 != '\0') && (piStack_1c == (int *)0x2)) {
    piStack_1c = (int *)0x1;
  }
  piVar7 = (int *)param_1[10];
  piStack_20 = piVar7;
  if (piVar7 != piStack_1c) {
    if (piVar7 == (int *)0x0) {
      piVar7 = (int *)(*(int *)(*(int *)(param_1[0xb] + 8) + 0x524) + 0x84);
      *piVar7 = *piVar7 + 1;
      piStack_20 = (int *)param_1[10];
    }
    param_1[10] = (int)piStack_1c;
    piVar7 = (int *)CONCAT31((int3)((uint)piStack_20 >> 8),piStack_1c == (int *)0x1);
    if ((piStack_1c == (int *)0x1) != (piStack_20 == (int *)0x1)) {
      uStack_11 = 0;
      piVar7 = (int *)FUN_00859470(&uStack_11);
      if ((piStack_20 == (int *)0x1) && (param_1[0xc] != 0)) {
        piVar7 = (int *)FUN_0085a790(param_1);
      }
      if (piStack_1c == (int *)0x1) {
        *puVar1 = *puVar1 | 8;
        goto LAB_0085aebe;
      }
    }
    if (piStack_1c == (int *)0x0) {
      piVar7 = *(int **)(*(int *)(param_1[0xb] + 8) + 0x524);
      piVar7[0x21] = piVar7[0x21] + -1;
    }
  }
LAB_0085aebe:
  *puVar1 = *puVar1 & 0xfffffffe;
LAB_0085aec1:
  if (param_1[10] == 1) {
    piStack_24 = (int *)FUN_00b65b40();
    piVar7 = (int *)FUN_00b65b50();
    piStack_28 = piVar7;
    if ((*puVar1 >> 3 & 1) == 0) {
      if ((*puVar1 >> 2 & 1) != 0) {
        piVar7 = (int *)FUN_0085b150(param_1,piStack_24,piVar7);
        *puVar1 = *puVar1 & 0xfffffffb;
      }
    }
    else {
      uStack_b0 = 0;
      uStack_ac = 0xf;
      uStack_c0 = uStack_c0 & 0xffffff00;
      uStack_94 = 0;
      uStack_90 = 0xf;
      uStack_a4 = uStack_a4 & 0xffffff00;
      uStack_8 = 0;
      uVar9 = FUN_00b4dfd0();
      FUN_0076ef70(uVar9);
      FUN_0076dfa0(auStack_30,auStack_c4,iStack_18);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (param_1[0xc] != 0) {
        FUN_0085a790(param_1);
      }
      piStack_1c = (int *)FUN_0085a3c0(auStack_30);
      param_1[0xd] = *(int *)((int)piStack_1c + 0x5c) - *(int *)((int)piStack_1c + 0x58) >> 2;
      param_1[0xc] = (int)piStack_1c;
      piVar7 = *(int **)((int)piStack_1c + 0x5c);
      piStack_20 = param_1;
      if (*(int **)((int)piStack_1c + 0x60) == piVar7) {
        FUN_0063d9b0(piVar7,&piStack_20);
      }
      else {
        *piVar7 = (int)param_1;
        *(int *)((int)piStack_1c + 0x5c) = *(int *)((int)piStack_1c + 0x5c) + 4;
      }
      piVar7 = piStack_20;
      FUN_0170d1f0(&uStack_60,0,0x30);
      puVar3 = *(undefined4 **)((int)piStack_1c + 0x50);
      if (*(undefined4 **)((int)piStack_1c + 0x54) == puVar3) {
        FUN_00859280(puVar3,&uStack_60);
      }
      else {
        *puVar3 = uStack_60;
        puVar3[1] = uStack_5c;
        puVar3[2] = uStack_58;
        puVar3[3] = uStack_54;
        puVar3[4] = uStack_50;
        puVar3[5] = uStack_4c;
        puVar3[6] = uStack_48;
        puVar3[7] = uStack_44;
        puVar3[8] = uStack_40;
        puVar3[9] = uStack_3c;
        puVar3[10] = uStack_38;
        puVar3[0xb] = uStack_34;
        *(int *)((int)piStack_1c + 0x50) = *(int *)((int)piStack_1c + 0x50) + 0x30;
      }
      uVar5 = _UNK_018c4ebc;
      uVar4 = _UNK_018c4eb8;
      uVar9 = _UNK_018c4eb4;
      uStack_48 = _DAT_018c4eb0;
      uStack_44 = _UNK_018c4eb4;
      uStack_40 = _UNK_018c4eb8;
      uStack_3c = _UNK_018c4ebc;
      uStack_38 = 0xff7fffff;
      uStack_34 = 0xff7fffff;
      puVar3 = *(undefined4 **)((int)piStack_1c + 0x68);
      if (*(undefined4 **)((int)piStack_1c + 0x6c) == puVar3) {
        FUN_00603350(puVar3,&uStack_48);
      }
      else {
        *puVar3 = _DAT_018c4eb0;
        puVar3[1] = uVar9;
        puVar3[2] = uVar4;
        puVar3[3] = uVar5;
        *(undefined8 *)(puVar3 + 4) = 0xff7fffffff7fffff;
        *(int *)((int)piStack_1c + 0x68) = *(int *)((int)piStack_1c + 0x68) + 0x18;
      }
      piVar7 = (int *)FUN_0085b150(piVar7,piStack_24,piStack_28);
      *puVar1 = *puVar1 & 0xfffffff3;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        puVar1 = (uint *)(piStack_2c + 1);
        uVar10 = *puVar1;
        piVar7 = (int *)*puVar1;
        *puVar1 = uVar10 - 1;
        UNLOCK();
        if (uVar10 - 1 == 0) {
          piVar7 = (int *)(**(code **)*piStack_2c)();
          LOCK();
          piVar2 = piStack_2c + 2;
          iVar8 = *piVar2;
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (iVar8 == 1) {
            piVar7 = (int *)(**(code **)(*piStack_2c + 4))();
          }
        }
      }
      if (0xf < uStack_90) {
        uVar11 = uStack_90 + 1;
        uVar10 = uStack_a4;
        if (0xfff < uVar11) {
          uVar10 = *(uint *)(uStack_a4 - 4);
          uVar11 = uStack_90 + 0x24;
          if (0x1f < (uStack_a4 - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        piVar7 = (int *)FUN_01674ea0(uVar10,uVar11);
      }
      uStack_94 = 0;
      uStack_90 = 0xf;
      uStack_a4 = uStack_a4 & 0xffffff00;
      if (0xf < uStack_ac) {
        uVar11 = uStack_ac + 1;
        uVar10 = uStack_c0;
        if (0xfff < uVar11) {
          uVar10 = *(uint *)(uStack_c0 - 4);
          uVar11 = uStack_ac + 0x24;
          if (0x1f < (uStack_c0 - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        piVar7 = (int *)FUN_01674ea0(uVar10,uVar11);
        ExceptionList = pvStack_10;
        return piVar7;
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar7;
}



/* FUNCTION 13118 ; VA 0x0085b150 ; FUN_0085b150 */

void __thiscall FUN_0085b150(int param_1,int param_2,float *param_3,float *param_4)

{
  undefined4 *puVar1;
  undefined8 uVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  float fVar8;
  undefined4 *puVar9;
  float *pfVar10;
  undefined auStack_2c [20];
  float fStack_18;
  float fStack_c;
  int iStack_8;
  
  pfVar10 = (float *)(*(int *)(param_2 + 0x34) * 0x30 + *(int *)(param_1 + 0x4c));
  *pfVar10 = *param_3 * *param_4;
  pfVar10[1] = param_3[1] * param_4[1];
  pfVar10[2] = param_3[2] * param_4[2];
  pfVar10[3] = param_3[9];
  pfVar10[4] = param_3[3] * *param_4;
  pfVar10[5] = param_3[4] * param_4[1];
  pfVar10[6] = param_3[5] * param_4[2];
  pfVar10[7] = param_3[10];
  pfVar10[8] = param_3[6] * *param_4;
  pfVar10[9] = param_3[7] * param_4[1];
  pfVar10[10] = param_3[8] * param_4[2];
  fVar8 = DAT_018ce2f4;
  pfVar10[0xb] = param_3[0xb];
  fStack_18 = param_4[2] * fVar8 + 0.0;
  fStack_c = 0.0 - param_4[2] * fVar8;
  iStack_8 = param_1;
  puVar9 = (undefined4 *)FUN_00c9f550(auStack_2c,param_3);
  uVar5 = puVar9[1];
  uVar6 = puVar9[2];
  uVar7 = puVar9[3];
  uVar2 = *(undefined8 *)(puVar9 + 4);
  iVar3 = *(int *)(param_2 + 0x34);
  iVar4 = *(int *)(iStack_8 + 100);
  puVar1 = (undefined4 *)(iVar4 + iVar3 * 0x18);
  *puVar1 = *puVar9;
  puVar1[1] = uVar5;
  puVar1[2] = uVar6;
  puVar1[3] = uVar7;
  *(undefined8 *)(iVar4 + 0x10 + iVar3 * 0x18) = uVar2;
  *(undefined *)(iStack_8 + 0x90) = 1;
  *(undefined *)(*(int *)(param_2 + 0x2c) + 0xd4) = 1;
  return;
}



/* FUNCTION 13119 ; VA 0x0085b2c0 ; FUN_0085b2c0 */

void __thiscall
FUN_0085b2c0(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6)

{
  int *piVar1;
  undefined4 uVar2;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  if (*(int *)(*(int *)(param_1 + 0x70) + 4) == 4) {
    uVar2 = FUN_0078e450(param_6);
    iStack_18 = FUN_0078e270(param_4,param_5,uVar2);
    if (iStack_18 != 0) {
      iStack_14 = *(int *)(param_1 + 0x70) + 0x6c;
      uStack_10 = 0;
      uStack_c = 0;
      uStack_8 = 0;
      param_2 = param_2 + *(int *)(param_1 + 8) * 0xc;
      piVar1 = *(int **)(param_2 + 4);
      if (*(int **)(param_2 + 8) != piVar1) {
        *piVar1 = param_1;
        piVar1[1] = iStack_18;
        piVar1[2] = iStack_14;
        piVar1[3] = 0;
        piVar1[4] = 0;
        piVar1[5] = 0;
        *(int *)(param_2 + 4) = *(int *)(param_2 + 4) + 0x18;
        return;
      }
      iStack_1c = param_1;
      FUN_006c6730(piVar1,&iStack_1c);
    }
  }
  return;
}



/* FUNCTION 13120 ; VA 0x0085b3c0 ; FUN_0085b3c0 */

void __thiscall FUN_0085b3c0(int *param_1,int param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uStack_14;
  uint uStack_10;
  int iStack_c;
  undefined uStack_5;
  
  iStack_c = param_3 - param_2;
  uVar2 = iStack_c / 0xc;
  iVar1 = *param_1;
  uStack_14 = (param_1[1] - iVar1) / 0xc;
  uStack_10 = (param_1[2] - iVar1) / 0xc;
  if (uVar2 <= uStack_10) {
    if (uVar2 <= uStack_14) {
      FUN_0170cc70(iVar1,param_2,iStack_c);
      param_1[1] = iVar1 + uVar2 * 0xc;
      return;
    }
    iVar4 = uStack_14 * 0xc;
    FUN_0170cc70(iVar1,param_2,iVar4);
    iVar1 = param_1[1];
    FUN_0055b6b0(&uStack_5,&uStack_14,&uStack_14);
    param_2 = param_2 + iVar4;
    iVar4 = param_3 - param_2;
    FUN_0170cc70(iVar1,param_2,iVar4);
    param_1[1] = iVar1 + iVar4;
    return;
  }
  if (0x15555555 < uVar2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar3 = uVar2;
  if ((uStack_10 <= 0x15555555 - (uStack_10 >> 1)) &&
     (uVar3 = (uStack_10 >> 1) + uStack_10, uVar3 < uVar2)) {
    uVar3 = uVar2;
  }
  if (iVar1 != 0) {
    FUN_0061a4e0(iVar1,uStack_10);
  }
  FUN_0085bef0(uVar3);
  iVar1 = *param_1;
  FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
  iVar4 = iStack_c;
  FUN_0170cc70(iVar1,param_2,iStack_c);
  param_1[1] = iVar1 + iVar4;
  return;
}



/* FUNCTION 13121 ; VA 0x0085b500 ; FUN_0085b500 */

int __thiscall FUN_0085b500(uint *param_1,uint param_2,undefined4 param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  
  uVar5 = *param_1;
  iVar1 = (int)(param_1[1] - uVar5) / 0x44;
  if (iVar1 == 0x3c3c3c3) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar7 = iVar1 + 1;
  uVar2 = (int)(param_1[2] - uVar5) / 0x44;
  uVar8 = uVar7;
  if ((uVar2 <= 0x3c3c3c3 - (uVar2 >> 1)) && (uVar8 = (uVar2 >> 1) + uVar2, uVar8 < uVar7)) {
    uVar8 = uVar7;
  }
  uVar7 = uVar8 * 0x44;
  if (uVar8 < 0x3c3c3c4) {
    uVar8 = uVar7;
    if (0xfff < uVar7) goto LAB_0085b59e;
    if (uVar7 == 0) {
      uVar8 = 0;
    }
    else {
      uVar8 = FUN_01674e20(uVar7);
    }
  }
  else {
    uVar8 = 0xffffffff;
LAB_0085b59e:
    uVar2 = uVar8 + 0x23;
    if (uVar2 <= uVar8) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_0085b6ad;
    uVar8 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar8 - 4) = iVar3;
  }
  iVar3 = ((int)(param_2 - uVar5) / 0x44) * 0x44;
  iVar4 = iVar3 + uVar8;
  FUN_0085b900(param_1,iVar4,param_3);
  uVar2 = param_1[1];
  uVar5 = *param_1;
  uVar6 = uVar8;
  if (param_2 != uVar2) {
    FUN_0085b860(uVar5,param_2,uVar8,param_1);
    uVar2 = param_1[1];
    uVar5 = param_2;
    uVar6 = iVar4 + 0x44;
  }
  FUN_0085b860(uVar5,uVar2,uVar6,param_1);
  if (*param_1 != 0) {
    FUN_007be660(*param_1,param_1[1],param_1);
    uVar5 = *param_1;
    uVar6 = ((int)(param_1[2] - *param_1) / 0x44) * 0x44;
    uVar2 = uVar5;
    if (0xfff < uVar6) {
      uVar2 = *(uint *)(uVar5 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar5 - uVar2) - 4) {
LAB_0085b6ad:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar6);
  }
  *param_1 = uVar8;
  param_1[1] = uVar8 + (iVar1 + 1) * 0x44;
  param_1[2] = uVar7 + uVar8;
  return *param_1 + iVar3;
}



/* FUNCTION 13122 ; VA 0x0085b6c0 ; FUN_0085b6c0 */

int __thiscall FUN_0085b6c0(int *param_1,int param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  
  iVar5 = *param_1;
  iVar7 = param_2 - iVar5;
  iVar3 = (param_1[1] - iVar5) / 0xc;
  if (iVar3 == 0x15555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar6 = iVar3 + 1;
  uVar4 = (param_1[2] - iVar5) / 0xc;
  uVar8 = uVar6;
  if ((uVar4 <= 0x15555555 - (uVar4 >> 1)) && (uVar8 = (uVar4 >> 1) + uVar4, uVar8 < uVar6)) {
    uVar8 = uVar6;
  }
  iVar5 = FUN_00618050(uVar8);
  iVar7 = (iVar7 / 0xc) * 0xc;
  puVar1 = (undefined8 *)(iVar7 + iVar5);
  *puVar1 = *param_3;
  *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(param_3 + 1);
  if (param_2 == param_1[1]) {
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    FUN_0170cc70(iVar5,*param_1,param_1[1] - *param_1);
  }
  else {
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(iVar5,*param_1,param_2 - *param_1);
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70((int)puVar1 + 0xc,param_2,param_1[1] - param_2);
  }
  iVar2 = *param_1;
  if (iVar2 != 0) {
    uVar6 = ((param_1[2] - iVar2) / 0xc) * 0xc;
    iVar9 = iVar2;
    if (0xfff < uVar6) {
      iVar9 = *(int *)(iVar2 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar2 - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar9,uVar6);
  }
  *param_1 = iVar5;
  param_1[1] = iVar5 + (iVar3 * 3 + 3) * 4;
  param_1[2] = iVar5 + uVar8 * 0xc;
  return *param_1 + iVar7;
}



/* FUNCTION 13123 ; VA 0x0085b860 ; FUN_0085b860 */

undefined4 *
FUN_0085b860(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  
  puVar7 = param_3;
  if (param_1 != param_2) {
    puVar6 = param_1 + 1;
    do {
      *puVar7 = 0;
      puVar1 = puVar6 + 0x11;
      *(undefined4 *)((int)param_3 + (-0x44 - (int)param_1) + (int)puVar1) = 0;
      *puVar7 = puVar6[-1];
      *(undefined4 *)((int)param_3 + (-0x44 - (int)param_1) + (int)puVar1) = *puVar6;
      puVar6[-1] = 0;
      *puVar6 = 0;
      puVar7[2] = puVar6[1];
      *(undefined *)(puVar7 + 3) = *(undefined *)(puVar6 + 2);
      uVar3 = puVar6[4];
      uVar4 = puVar6[5];
      uVar5 = puVar6[6];
      puVar7[4] = puVar6[3];
      puVar7[5] = uVar3;
      puVar7[6] = uVar4;
      puVar7[7] = uVar5;
      uVar3 = puVar6[8];
      uVar4 = puVar6[9];
      uVar5 = puVar6[10];
      puVar7[8] = puVar6[7];
      puVar7[9] = uVar3;
      puVar7[10] = uVar4;
      puVar7[0xb] = uVar5;
      uVar3 = puVar6[0xc];
      uVar4 = puVar6[0xd];
      uVar5 = puVar6[0xe];
      puVar7[0xc] = puVar6[0xb];
      puVar7[0xd] = uVar3;
      puVar7[0xe] = uVar4;
      puVar7[0xf] = uVar5;
      puVar7[0x10] = puVar6[0xf];
      puVar2 = puVar6 + 0x10;
      puVar7 = puVar7 + 0x11;
      puVar6 = puVar1;
    } while (puVar2 != param_2);
  }
  FUN_007be660(puVar7,puVar7,param_4);
  return puVar7;
}



/* FUNCTION 13124 ; VA 0x0085b900 ; FUN_0085b900 */

void FUN_0085b900(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  *param_2 = 0;
  param_2[1] = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_2 = *param_3;
  param_2[1] = param_3[1];
  param_2[2] = param_3[2];
  *(undefined *)(param_2 + 3) = *(undefined *)(param_3 + 3);
  uVar2 = param_3[5];
  uVar3 = param_3[6];
  uVar4 = param_3[7];
  param_2[4] = param_3[4];
  param_2[5] = uVar2;
  param_2[6] = uVar3;
  param_2[7] = uVar4;
  uVar2 = param_3[9];
  uVar3 = param_3[10];
  uVar4 = param_3[0xb];
  param_2[8] = param_3[8];
  param_2[9] = uVar2;
  param_2[10] = uVar3;
  param_2[0xb] = uVar4;
  uVar2 = param_3[0xd];
  uVar3 = param_3[0xe];
  uVar4 = param_3[0xf];
  param_2[0xc] = param_3[0xc];
  param_2[0xd] = uVar2;
  param_2[0xe] = uVar3;
  param_2[0xf] = uVar4;
  param_2[0x10] = param_3[0x10];
  return;
}



/* FUNCTION 13125 ; VA 0x0085b960 ; FUN_0085b960 */

void __thiscall FUN_0085b960(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  puVar2 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar2) {
    *puVar2 = 0;
    puVar2[1] = 0;
    if (param_2[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *puVar2 = *param_2;
    puVar2[1] = param_2[1];
    puVar2[2] = param_2[2];
    *(undefined *)(puVar2 + 3) = *(undefined *)(param_2 + 3);
    uVar3 = param_2[5];
    uVar4 = param_2[6];
    uVar5 = param_2[7];
    puVar2[4] = param_2[4];
    puVar2[5] = uVar3;
    puVar2[6] = uVar4;
    puVar2[7] = uVar5;
    uVar3 = param_2[9];
    uVar4 = param_2[10];
    uVar5 = param_2[0xb];
    puVar2[8] = param_2[8];
    puVar2[9] = uVar3;
    puVar2[10] = uVar4;
    puVar2[0xb] = uVar5;
    uVar3 = param_2[0xd];
    uVar4 = param_2[0xe];
    uVar5 = param_2[0xf];
    puVar2[0xc] = param_2[0xc];
    puVar2[0xd] = uVar3;
    puVar2[0xe] = uVar4;
    puVar2[0xf] = uVar5;
    puVar2[0x10] = param_2[0x10];
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x44;
    return;
  }
  FUN_0085b500(puVar2,param_2);
  return;
}



/* FUNCTION 13126 ; VA 0x0085b9e0 ; FUN_0085b9e0 */

void __thiscall FUN_0085b9e0(int param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  
  puVar1 = *(undefined8 **)(param_1 + 4);
  if (*(undefined8 **)(param_1 + 8) != puVar1) {
    *puVar1 = *param_2;
    *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(param_2 + 1);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0xc;
    return;
  }
  FUN_0085b6c0(puVar1,param_2);
  return;
}



/* FUNCTION 13127 ; VA 0x0085ba20 ; FUN_0085ba20 */

int __fastcall FUN_0085ba20(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_00d77b00();
  iVar3 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar3 = param_1;
  }
  return iVar3;
}



/* FUNCTION 13128 ; VA 0x0085ba50 ; FUN_0085ba50 */

int __fastcall FUN_0085ba50(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_00ca4c20();
  iVar3 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar3 = param_1;
  }
  return iVar3;
}



/* FUNCTION 13129 ; VA 0x0085ba80 ; FUN_0085ba80 */

int __fastcall FUN_0085ba80(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_00b4b860();
  iVar3 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar3 = param_1;
  }
  return iVar3;
}



/* FUNCTION 13130 ; VA 0x0085bab0 ; FUN_0085bab0 */

int FUN_0085bab0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01ea8c6c,&LAB_005c24a0);
      uVar3 = FUN_005c38d0();
      piVar4 = (int *)FUN_008aa140(uVar3);
      if (*piVar4 == 0) {
        uVar3 = FUN_009df680();
        piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar4 = iVar1;
        piVar5 = (int *)piVar4[1];
        piVar4[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_8[1] + -1;
          piStack_8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar5 = piStack_8 + 2;
            iVar1 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      return *piVar4;
    }
  }
  return 0;
}



/* FUNCTION 13131 ; VA 0x0085bbc0 ; FUN_0085bbc0 */

undefined2 __fastcall FUN_0085bbc0(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_00d7c7c0();
  return CONCAT11((char)(*(ushort *)(iVar2 + 0x1da) >> 8),
                  (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
                  (uint)*(ushort *)(iVar2 + 0x1da));
}



/* FUNCTION 13132 ; VA 0x0085bbf0 ; FUN_0085bbf0 */

undefined2 __fastcall FUN_0085bbf0(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_00d77b00();
  return CONCAT11((char)(*(ushort *)(iVar2 + 0x1da) >> 8),
                  (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
                  (uint)*(ushort *)(iVar2 + 0x1da));
}



/* FUNCTION 13133 ; VA 0x0085bc20 ; FUN_0085bc20 */

undefined2 __fastcall FUN_0085bc20(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_00d787b0();
  return CONCAT11((char)(*(ushort *)(iVar2 + 0x1da) >> 8),
                  (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
                  (uint)*(ushort *)(iVar2 + 0x1da));
}



/* FUNCTION 13134 ; VA 0x0085bc50 ; FUN_0085bc50 */

undefined2 __fastcall FUN_0085bc50(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_00b4b860();
  return CONCAT11((char)(*(ushort *)(iVar2 + 0x1da) >> 8),
                  (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
                  (uint)*(ushort *)(iVar2 + 0x1da));
}



/* FUNCTION 13135 ; VA 0x0085bc80 ; FUN_0085bc80 */

uint * __thiscall FUN_0085bc80(uint *param_1,uint param_2,undefined4 *param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b82a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0xfffffff < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar3 = param_2 * 0x10;
    if (uVar3 < 0x1000) {
      if (uVar3 == 0) {
        uVar1 = 0;
      }
      else {
        uVar1 = FUN_01674e20(uVar3);
      }
    }
    else {
      uVar1 = uVar3 + 0x23;
      if (uVar1 <= uVar3) {
        uVar1 = 0xffffffff;
      }
      iVar2 = FUN_01674e20(uVar1);
      if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar1 = iVar2 + 0x23U & 0xffffffe0;
      *(int *)(uVar1 - 4) = iVar2;
    }
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + uVar3;
    puVar4 = (undefined4 *)*param_1;
    uStack_8 = 1;
    for (; param_2 != 0; param_2 = param_2 - 1) {
      *puVar4 = *param_3;
      FUN_0085bd90(param_3 + 1);
      puVar4 = puVar4 + 4;
    }
    param_1[1] = (uint)puVar4;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13136 ; VA 0x0085bd78 ; Catch_All@0085bd78 */

void Catch_All_0085bd78(void)

{
  FUN_0085bf50();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 13137 ; VA 0x0085bd90 ; FUN_0085bd90 */

int * __thiscall FUN_0085bd90(int *param_1,int *param_2)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  undefined auStack_10 [4];
  int *piStack_c;
  undefined uStack_5;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar2 = (param_2[1] - *param_2) / 0xc;
  if (uVar2 != 0) {
    piStack_c = param_1;
    if (0x15555555 < uVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar3 = FUN_00618050(uVar2);
    *param_1 = iVar3;
    param_1[1] = iVar3;
    param_1[2] = *param_1 + uVar2 * 0xc;
    iVar3 = *param_2;
    iVar1 = *param_1;
    FUN_0055b6b0(&uStack_5,auStack_10,auStack_10);
    iVar4 = param_2[1] - iVar3;
    FUN_0170cc70(iVar1,iVar3,iVar4);
    piStack_c[1] = iVar1 + iVar4;
    param_1 = piStack_c;
  }
  return param_1;
}



/* FUNCTION 13138 ; VA 0x0085be30 ; thunk_FUN_0085bf50 */

void __fastcall thunk_FUN_0085bf50(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_00617ad0();
        iVar2 = iVar2 + 0x10;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = param_1[2] - iVar2 & 0xfffffff0;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 13139 ; VA 0x0085be40 ; FUN_0085be40 */

void __fastcall FUN_0085be40(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_1[1];
  for (iVar2 = *param_1; iVar2 != iVar1; iVar2 = iVar2 + 0x10) {
    FUN_00617ad0();
  }
  return;
}



/* FUNCTION 13140 ; VA 0x0085be70 ; FUN_0085be70 */

void FUN_0085be70(void)

{
  FUN_00617ad0();
  return;
}



/* FUNCTION 13141 ; VA 0x0085be80 ; FUN_0085be80 */

int * __fastcall FUN_0085be80(int *param_1)

{
  uint uVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar3 = (int *)*param_1;
  iVar4 = piVar3[1];
  iVar5 = *piVar3;
  uVar6 = param_1[1];
  do {
    uVar1 = uVar6 + 1;
    param_1[1] = uVar1;
    if ((uint)(iVar4 - iVar5 >> 2) <= uVar1) {
      return param_1;
    }
    iVar2 = uVar6 * 4;
    uVar6 = uVar1;
  } while (*(int *)(*piVar3 + 4 + iVar2) == piVar3[4]);
  return param_1;
}



/* FUNCTION 13142 ; VA 0x0085bec0 ; FUN_0085bec0 */

uint FUN_0085bec0(int param_1,uint param_2)

{
  byte *pbVar1;
  uint uVar2;
  uint uVar3;
  
  uVar2 = 0;
  uVar3 = 0x811c9dc5;
  if (param_2 != 0) {
    do {
      pbVar1 = (byte *)(uVar2 + param_1);
      uVar2 = uVar2 + 1;
      uVar3 = (*pbVar1 ^ uVar3) * 0x1000193;
    } while (uVar2 < param_2);
  }
  return uVar3;
}



/* FUNCTION 13143 ; VA 0x0085bef0 ; FUN_0085bef0 */

uint __thiscall FUN_0085bef0(int *param_1,uint param_2)

{
  uint in_EAX;
  int iVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 == 0) {
    return in_EAX & 0xffffff00;
  }
  if (param_2 < 0x15555556) {
    iVar1 = FUN_00618050(param_2);
    *param_1 = iVar1;
    param_1[1] = iVar1;
    iVar1 = *param_1 + param_2 * 0xc;
    param_1[2] = iVar1;
    return CONCAT31((int3)((uint)iVar1 >> 8),1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 13144 ; VA 0x0085bf50 ; FUN_0085bf50 */

void __fastcall FUN_0085bf50(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_00617ad0();
        iVar2 = iVar2 + 0x10;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = param_1[2] - iVar2 & 0xfffffff0;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 13145 ; VA 0x0085bfc0 ; FUN_0085bfc0 */

void FUN_0085bfc0(int param_1,undefined4 param_2,int *param_3,int param_4,int param_5)

{
  int iVar1;
  uint uVar2;
  uint *puVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 *puVar7;
  uint uVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  int *piVar12;
  uint *puVar13;
  undefined auStack_20 [4];
  int *piStack_1c;
  uint *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar6 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7668;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0xc);
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00aff8c0();
  iVar9 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
      (uint)*(ushort *)(iVar4 + 0x1da)) {
    iVar9 = iVar6;
  }
  if (iVar9 != 0) {
    puVar5 = (undefined4 *)FUN_0060dcd0(auStack_20,iVar6);
    uStack_8 = 0;
    puVar7 = *(undefined4 **)(param_4 + 4);
    if (*(undefined4 **)(param_4 + 8) == puVar7) {
      FUN_007086e0(puVar7,puVar5);
    }
    else {
      *puVar7 = 0;
      puVar7[1] = 0;
      *puVar7 = *puVar5;
      puVar7[1] = puVar5[1];
      *puVar5 = 0;
      puVar5[1] = 0;
      *(int *)(param_4 + 4) = *(int *)(param_4 + 4) + 8;
    }
    uStack_8 = 0xffffffff;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar1 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar12 = piStack_1c + 2;
        iVar1 = *piVar12;
        *piVar12 = *piVar12 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  piVar12 = param_3;
  if ((uint)((param_3[1] - *param_3 >> 2) * 3) >> 2 <= (uint)param_3[3]) {
    FUN_006286d0();
  }
  FUN_00620c30(&param_1);
  iVar6 = FUN_006b5480(&param_1);
  iVar1 = param_5;
  puVar7 = (undefined4 *)(-(uint)(iVar6 != 0) & iVar6 + 4U);
  if (puVar7 != (undefined4 *)0x0) {
    puStack_18 = (uint *)puVar7[1];
    puVar13 = (uint *)*puVar7;
    if (puVar13 != puStack_18) {
      do {
        param_1 = *piVar12;
        if (param_1 != piVar12[1]) {
          uStack_14 = piVar12[4];
          uVar8 = *puVar13;
          if (uVar8 != uStack_14) {
            uVar8 = (uVar8 >> 3) + uVar8;
            uVar11 = (piVar12[1] - param_1 >> 2) - 1;
            uVar10 = 0;
            do {
              uVar8 = uVar8 & uVar11;
              uVar2 = *(uint *)(param_1 + uVar8 * 4);
              piVar12 = param_3;
              if (uVar2 == *puVar13) goto LAB_0085c166;
              if (uVar2 == uStack_14) break;
              uVar8 = uVar8 + 1 + uVar10;
              uVar10 = uVar10 + 1;
            } while (uVar10 <= uVar11);
          }
        }
        puVar3 = *(uint **)(iVar1 + 4);
        if (*(uint **)(iVar1 + 8) == puVar3) {
          FUN_006030d0(puVar3,puVar13 + 1);
        }
        else {
          *puVar3 = puVar13[1];
          *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 4;
        }
        FUN_0085bfc0(*puVar13,param_2,piVar12,param_4,iVar1);
LAB_0085c166:
        puVar13 = puVar13 + 3;
      } while (puVar13 != puStack_18);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13146 ; VA 0x0085c190 ; FUN_0085c190 */

void FUN_0085c190(int *param_1,int *param_2,int param_3,int param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  int *piVar7;
  int iStack_c;
  int *piStack_8;
  
  iVar1 = (int)param_1;
  iVar5 = *(int *)((int)param_1 + 0xc);
  iVar3 = FUN_00aff8c0();
  iVar2 = param_4;
  iVar4 = *(int *)(iVar1 + 0xc);
  iStack_c = 0;
  if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
      (uint)*(ushort *)(iVar3 + 0x1da)) {
    iStack_c = iVar1;
  }
  if (iStack_c == 0) {
    iVar5 = FUN_00c396b0();
    param_1 = (int *)0;
    if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
        (uint)*(ushort *)(iVar5 + 0x1da)) {
      param_1 = (int *)iVar1;
    }
    if (param_1 == (int *)0x0) {
      iVar5 = *(int *)(iVar1 + 0xc);
      iVar4 = FUN_00c39bb0();
      param_1 = (int *)0;
      if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
          (uint)*(ushort *)(iVar4 + 0x1da)) {
        param_1 = (int *)iVar1;
      }
      if (param_1 == (int *)0x0) {
        iVar5 = *(int *)(iVar1 + 0xc);
        iVar4 = FUN_00d7c7c0();
        param_1 = (int *)0;
        if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
            (uint)*(ushort *)(iVar4 + 0x1da)) {
          param_1 = (int *)iVar1;
        }
        if (param_1 == (int *)0x0) {
          iVar5 = *(int *)(iVar1 + 0xc);
          iVar4 = FUN_00d787b0();
          param_1 = (int *)0;
          if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
              (uint)*(ushort *)(iVar4 + 0x1da)) {
            param_1 = (int *)iVar1;
          }
          if (param_1 == (int *)0x0) {
            iVar5 = FUN_0085ba80();
            param_1 = (int *)iVar1;
            if (iVar5 != 0) {
              piVar7 = *(int **)(iVar2 + 4);
              if (*(int **)(iVar2 + 8) == piVar7) {
                param_1 = (int *)iVar5;
                FUN_0063d9b0(piVar7,&param_1);
                param_1 = (int *)iVar1;
              }
              else {
                *piVar7 = iVar5;
                *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 4;
              }
            }
          }
          else {
            piVar7 = *(int **)(iVar2 + 4);
            if (*(int **)(iVar2 + 8) == piVar7) {
              FUN_0063d9b0(piVar7,&param_1);
              param_1 = (int *)iVar1;
            }
            else {
              *piVar7 = (int)param_1;
              *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 4;
              param_1 = (int *)iVar1;
            }
          }
        }
        else {
          piVar7 = *(int **)(iVar2 + 4);
          if (*(int **)(iVar2 + 8) == piVar7) {
            FUN_0063d9b0(piVar7,&param_1);
            param_1 = (int *)iVar1;
          }
          else {
            *piVar7 = (int)param_1;
            *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 4;
            param_1 = (int *)iVar1;
          }
        }
      }
      else {
        piVar7 = *(int **)(param_3 + 4);
        if (*(int **)(param_3 + 8) == piVar7) {
          FUN_0063d9b0(piVar7,&param_1);
          param_1 = (int *)iVar1;
        }
        else {
          *piVar7 = (int)param_1;
          *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 4;
          param_1 = (int *)iVar1;
        }
      }
    }
    else {
      piVar7 = *(int **)(param_3 + 4);
      if (*(int **)(param_3 + 8) == piVar7) {
        FUN_0063d9b0(piVar7,&param_1);
        param_1 = (int *)iVar1;
      }
      else {
        *piVar7 = (int)param_1;
        *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 4;
        param_1 = (int *)iVar1;
      }
    }
  }
  else {
    iVar3 = FUN_00cfb1a0();
    iVar5 = 0;
    if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) {
      iVar5 = iVar1;
    }
    if (iVar5 == 0) {
      piVar7 = *(int **)(iVar1 + 0x2c);
      if (piVar7 == (int *)0x0) {
        return;
      }
      piVar6 = (int *)*piVar7;
      piStack_8 = (int *)piVar7[1];
      if (piVar6 != piStack_8) {
        do {
          iVar5 = *(int *)(*piVar6 + 0xc);
          iVar4 = FUN_00d77b00();
          if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
              (uint)*(ushort *)(iVar4 + 0x1da)) {
            if ((uint)((param_2[1] - *param_2 >> 2) * 3) >> 2 <= (uint)param_2[3]) {
              FUN_006286d0();
            }
            FUN_00620c30(&iStack_c);
            break;
          }
          piVar6 = piVar6 + 2;
        } while (piVar6 != piStack_8);
      }
    }
    else {
      param_1 = (int *)iVar5;
      if ((uint)((param_2[1] - *param_2 >> 2) * 3) >> 2 <= (uint)param_2[3]) {
        FUN_006286d0();
      }
      FUN_00620c30(&param_1);
      param_1 = (int *)iVar1;
    }
  }
  piVar7 = *(int **)((int)param_1 + 0x2c);
  if (piVar7 != (int *)0x0) {
    param_1 = (int *)piVar7[1];
    piVar7 = (int *)*piVar7;
    if (piVar7 != param_1) {
      do {
        iVar5 = *(int *)(*piVar7 + 0xc);
        iVar4 = FUN_00b63e30();
        if ((uint)*(ushort *)(iVar4 + 0x1da) <
            (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) {
          FUN_0085c190(*piVar7,param_2,param_3,iVar2);
        }
        piVar7 = piVar7 + 2;
      } while (piVar7 != param_1);
    }
  }
  return;
}



/* FUNCTION 13147 ; VA 0x0085c480 ; FUN_0085c480 */

void FUN_0085c480(undefined4 param_1,int param_2,int *param_3)

{
  int *piVar1;
  uint uVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  int *piVar7;
  undefined4 uVar8;
  int iVar9;
  uint uVar10;
  undefined8 *puVar11;
  int iVar12;
  undefined4 **ppuVar13;
  undefined4 *puVar14;
  uint uVar15;
  undefined4 *puVar16;
  uint uVar17;
  uint uVar18;
  undefined4 *puVar19;
  undefined4 uStack_1cc;
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 *puStack_1bc;
  int *piStack_1b8;
  int iStack_1b4;
  int iStack_1b0;
  undefined4 uStack_1ac;
  int *piStack_1a8;
  undefined4 uStack_1a4;
  undefined auStack_1a0 [4];
  int *piStack_19c;
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined4 uStack_190;
  undefined4 uStack_18c;
  undefined4 uStack_188;
  undefined4 uStack_184;
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined4 uStack_178;
  undefined4 uStack_174;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined4 uStack_168;
  int iStack_164;
  undefined4 uStack_160;
  undefined4 uStack_15c;
  int iStack_158;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  int iStack_144;
  int iStack_140;
  undefined4 uStack_138;
  uint uStack_134;
  undefined4 uStack_12c;
  undefined4 *puStack_128;
  undefined4 uStack_124;
  undefined4 *puStack_120;
  undefined4 *puStack_11c;
  int iStack_118;
  int iStack_114;
  undefined4 *puStack_110;
  uint uStack_10c;
  undefined4 *puStack_108;
  undefined4 *puStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined4 *puStack_f4;
  undefined4 *puStack_f0;
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  int *piStack_e4;
  int *piStack_e0;
  undefined4 uStack_dc;
  int iStack_d8;
  int iStack_d4;
  undefined4 uStack_cc;
  undefined4 *puStack_c8;
  undefined4 *puStack_c0;
  int *piStack_bc;
  int *piStack_b8;
  int iStack_b4;
  undefined4 *puStack_b0;
  undefined4 *puStack_ac;
  undefined4 *puStack_a8;
  undefined4 *puStack_a4;
  undefined4 *puStack_a0;
  undefined4 *puStack_9c;
  undefined4 *puStack_98;
  int iStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined uStack_88;
  undefined uStack_87;
  undefined uStack_86;
  undefined uStack_85;
  int *piStack_84;
  int *piStack_80;
  int iStack_7c;
  int iStack_78;
  int iStack_74;
  int iStack_70;
  int iStack_6c;
  int iStack_68;
  uint uStack_60;
  undefined4 uStack_5c;
  undefined4 *puStack_54;
  undefined4 *puStack_50;
  undefined4 *puStack_4c;
  undefined4 *puStack_48;
  undefined4 *puStack_44;
  uint uStack_40;
  undefined4 *puStack_3c;
  int *piStack_38;
  undefined4 *puStack_34;
  undefined4 *puStack_30;
  char cStack_29;
  undefined4 *puStack_28;
  int *piStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b851e;
  pvStack_10 = ExceptionList;
  puStack_44 = (undefined4 *)0x0;
  puStack_14 = (undefined4 *)0x0;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_008f7870(param_2);
  if ((iVar4 != 0) &&
     (((iVar4 = FUN_006bf290(), iVar4 != 0 || (iVar4 = FUN_007c0ce0(), iVar4 != 0)) &&
      (DAT_01d6c7c4 != '\0')))) {
    if (DAT_01eb4954 != '\0') {
      piVar6 = *(int **)(param_2 + 0x28);
      if (0xf < (uint)piVar6[5]) {
        piVar6 = (int *)*piVar6;
      }
      FUN_01677650(DAT_01eb4954,"createSkinningIslandsForModel %s",piVar6);
    }
    uStack_fc = 0;
    FUN_0060e810(0,&uStack_fc,&uStack_85);
    uStack_cc = 0;
    puStack_c8 = (undefined4 *)0x0;
    piStack_84 = (int *)0x0;
    piStack_80 = (int *)0x0;
    iStack_7c = 0;
    piStack_e4 = (int *)0x0;
    piStack_e0 = (int *)0x0;
    uStack_dc = 0;
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    FUN_0085c190(param_2,&iStack_d8,&piStack_84,&piStack_e4);
    uStack_1a4 = 0;
    uStack_150 = 0;
    uStack_14c = 0;
    uStack_1cc = 0;
    uStack_1c8 = 0;
    uStack_1c4 = 0;
    uStack_1c0 = 0;
    uStack_148 = 0;
    FUN_00617ad0();
    uStack_8._0_1_ = 3;
    FUN_0085bc80(0,&uStack_1cc,&uStack_86);
    FUN_00617ad0();
    uStack_60 = 0;
    uStack_5c = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    uStack_40 = (uint)((int)piStack_80 + (3 - (int)piStack_84)) >> 2;
    if (piStack_80 < piStack_84) {
      uStack_40 = 0;
    }
    puVar16 = (undefined4 *)0x0;
    if (uStack_40 != 0) {
      uVar15 = 0;
      piVar6 = piStack_84;
      do {
        iVar4 = *piVar6;
        if (*(char *)(iVar4 + 0x8c) != '\0') {
          uStack_90 = FUN_00c3c010();
          uStack_8c = FUN_00c3c020();
          cVar3 = FUN_0067b800(&uStack_90);
          if ((cVar3 != '\0') && (cVar3 = FUN_0067b800(&uStack_8c), cVar3 != '\0')) {
            if ((uint)((iStack_68 - iStack_6c >> 4) * 3) >> 2 <= uStack_60) {
              FUN_0085e990();
            }
            FUN_006b6b20(&uStack_90);
            uStack_15c = uStack_8c;
            uStack_154 = 0;
            iStack_158 = iVar4;
            FUN_0085b9e0(&uStack_15c);
            if ((uint)((iStack_68 - iStack_6c >> 4) * 3) >> 2 <= uStack_60) {
              FUN_0085e990();
            }
            FUN_006b6b20(&uStack_8c);
            uStack_168 = uStack_90;
            uStack_160 = 0;
            iStack_164 = iVar4;
            FUN_0085b9e0(&uStack_168);
          }
        }
        uVar15 = uVar15 + 1;
        piVar6 = piVar6 + 1;
        puVar16 = puStack_44;
      } while (uVar15 != uStack_40);
    }
    puStack_48 = (undefined4 *)0x0;
    piStack_24 = (int *)((uint)((int)piStack_e0 + (3 - (int)piStack_e4)) >> 2);
    if (piStack_e0 < piStack_e4) {
      piStack_24 = (undefined4 *)0x0;
    }
    piVar6 = piStack_e4;
    if (piStack_24 != (undefined4 *)0x0) {
      do {
        puVar16 = (undefined4 *)*piVar6;
        iVar4 = puVar16[3];
        iVar5 = FUN_00ca4c20();
        puStack_4c = (undefined4 *)0x0;
        if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
            (uint)*(ushort *)(iVar5 + 0x1da)) {
          puStack_4c = puVar16;
        }
        if (puStack_4c == (undefined4 *)0x0) {
          iVar4 = puVar16[3];
          iVar5 = FUN_00b4b860();
          puVar14 = (undefined4 *)0x0;
          if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
              (uint)*(ushort *)(iVar5 + 0x1da)) {
            puVar14 = puVar16;
          }
          if ((puVar14 != (undefined4 *)0x0) && ((*(byte *)(puVar14 + 0x1d) & 1) != 0)) {
            puStack_98 = (undefined4 *)FUN_00b4c020();
            uVar8 = FUN_00b4c070();
            uStack_ec = uVar8;
            cVar3 = FUN_0067b800(&puStack_98);
            if ((cVar3 != '\0') && (cVar3 = FUN_0067b800(&uStack_ec), cVar3 != '\0')) {
              if ((uint)((iStack_68 - iStack_6c >> 4) * 3) >> 2 <= uStack_60) {
                FUN_0085e990();
              }
              iVar4 = FUN_006b6b20(&puStack_98);
              uStack_124 = 0;
              puVar11 = *(undefined8 **)(iVar4 + 8);
              uStack_12c = uVar8;
              puStack_128 = puVar14;
              if (*(undefined8 **)(iVar4 + 0xc) == puVar11) {
                FUN_0085b6c0(puVar11,&uStack_12c);
              }
              else {
                *puVar11 = CONCAT44(puVar14,uVar8);
                *(undefined4 *)(puVar11 + 1) = 0;
                *(int *)(iVar4 + 8) = *(int *)(iVar4 + 8) + 0xc;
              }
              if ((uint)((iStack_68 - iStack_6c >> 4) * 3) >> 2 <= uStack_60) {
                FUN_0085e990();
              }
              iVar4 = FUN_006b6b20(&uStack_ec);
              puStack_108 = puStack_98;
              puVar11 = *(undefined8 **)(iVar4 + 8);
              uStack_100 = 0;
              puStack_104 = puVar14;
              if (*(undefined8 **)(iVar4 + 0xc) == puVar11) {
                ppuVar13 = &puStack_108;
LAB_0085cb1c:
                FUN_0085b6c0(puVar11,ppuVar13);
              }
              else {
                *puVar11 = CONCAT44(puVar14,puStack_98);
                *(undefined4 *)(puVar11 + 1) = 0;
                *(int *)(iVar4 + 8) = *(int *)(iVar4 + 8) + 0xc;
              }
            }
          }
        }
        else if (*(char *)((int)puStack_4c + 0xb1) != '\0') {
          uStack_40 = FUN_00ca5a50();
          if (uStack_40 == 0) {
            puStack_28 = (undefined4 *)0x0;
          }
          else {
            puStack_28 = *(undefined4 **)(uStack_40 + 0x34);
          }
          if (puStack_28 == (undefined4 *)0x0) {
            puVar16 = (undefined4 *)0x0;
          }
          else {
            iVar4 = puStack_28[3];
            iVar5 = FUN_00aff8c0();
            puVar16 = (undefined4 *)0x0;
            if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
                (uint)*(ushort *)(iVar5 + 0x1da)) {
              puVar16 = puStack_28;
            }
          }
          puStack_e8 = puVar16;
          puStack_50 = puVar16;
          puStack_1c = (undefined4 *)FUN_00ca5ab0();
          if (puStack_1c == (undefined4 *)0x0) {
            puStack_28 = (undefined4 *)0x0;
          }
          else {
            puStack_28 = *(undefined4 **)((int)puStack_1c + 0x34);
          }
          if (puStack_28 == (undefined4 *)0x0) {
            puStack_28 = (undefined4 *)0x0;
            puVar14 = puStack_28;
          }
          else {
            iVar4 = *(int *)((int)puStack_28 + 0xc);
            iVar5 = FUN_00aff8c0();
            puVar14 = (undefined4 *)0;
            if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
                (uint)*(ushort *)(iVar5 + 0x1da)) {
              puVar14 = puStack_28;
            }
          }
          puStack_28 = puVar14;
          iStack_94 = (int)puStack_28;
          if ((iStack_d8 != iStack_d4) && (puVar16 != puStack_c8)) {
            uVar15 = ((uint)puStack_50 >> 3) + (int)puStack_50;
            uVar17 = (iStack_d4 - iStack_d8 >> 2) - 1;
            uVar10 = 0;
            do {
              uVar15 = uVar15 & uVar17;
              puVar14 = *(undefined4 **)(iStack_d8 + uVar15 * 4);
              if (puVar14 == puVar16) {
                cVar3 = FUN_0067b800(&iStack_94);
                if (cVar3 != '\0') {
                  if ((uint)((iStack_68 - iStack_6c >> 4) * 3) >> 2 <= uStack_60) {
                    FUN_0085e990();
                  }
                  iVar4 = FUN_006b6b20(&puStack_e8);
                  puVar14 = puStack_4c;
                  iStack_114 = (int)puStack_28;
                  puVar11 = *(undefined8 **)(iVar4 + 8);
                  puStack_110 = puStack_4c;
                  uStack_10c = uStack_40;
                  if (*(undefined8 **)(iVar4 + 0xc) == puVar11) {
                    FUN_0085b6c0(puVar11,&iStack_114);
                  }
                  else {
                    *puVar11 = CONCAT44(puStack_4c,puStack_28);
                    *(uint *)(puVar11 + 1) = uStack_40;
                    *(int *)(iVar4 + 8) = *(int *)(iVar4 + 8) + 0xc;
                  }
                  if ((uint)((iStack_68 - iStack_6c >> 4) * 3) >> 2 <= uStack_60) {
                    FUN_0085e990();
                  }
                  iVar4 = FUN_006b6b20(&iStack_94);
                  puStack_11c = puVar14;
                  puVar11 = *(undefined8 **)(iVar4 + 8);
                  iStack_118 = (int)puStack_1c;
                  puStack_120 = puVar16;
                  if (*(undefined8 **)(iVar4 + 0xc) == puVar11) {
                    ppuVar13 = &puStack_120;
                    goto LAB_0085cb1c;
                  }
                  *puVar11 = CONCAT44(puVar14,puVar16);
                  *(undefined4 **)(puVar11 + 1) = puStack_1c;
                  *(int *)(iVar4 + 8) = *(int *)(iVar4 + 8) + 0xc;
                }
                break;
              }
              if (puVar14 == puStack_c8) break;
              uVar15 = uVar15 + 1 + uVar10;
              uVar10 = uVar10 + 1;
            } while (uVar10 <= uVar17);
          }
        }
        puStack_48 = (undefined4 *)((int)puStack_48 + 1);
        puVar16 = puStack_44;
        piVar6 = piVar6 + 1;
      } while (puStack_48 != piStack_24);
    }
    uStack_f8 = 0;
    FUN_0060e810(0,&uStack_f8,&uStack_87);
    uStack_138 = 0;
    uStack_134 = 0;
    uVar15 = 0;
    uStack_40 = iStack_d4 - iStack_d8 >> 2;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    puStack_28 = (undefined4 *)0x0;
    if (uStack_40 != 0) {
      do {
        puStack_28 = (undefined4 *)uVar15;
        if (*(undefined4 **)(iStack_d8 + uVar15 * 4) != puStack_c8) break;
        uVar15 = uVar15 + 1;
        puStack_28 = (undefined4 *)uVar15;
      } while (uVar15 < uStack_40);
    }
LAB_0085cbb0:
    if (puStack_28 != (undefined4 *)uStack_40) {
      uVar15 = *(uint *)(iStack_d8 + (int)puStack_28 * 4);
      iVar4 = *(int *)(uVar15 + 0xc);
      iVar5 = FUN_00cfb1a0();
      uVar10 = 0;
      if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
          (uint)*(ushort *)(iVar5 + 0x1da)) {
        uVar10 = uVar15;
      }
      if ((uVar10 == 0) || (cStack_29 = '\x01', *(char *)(uVar10 + 0x191) == '\0')) {
        cStack_29 = '\0';
      }
      if ((iStack_144 != iStack_140) && (uVar15 != uStack_134)) {
        uVar10 = (uVar15 >> 3) + uVar15;
        uVar18 = (iStack_140 - iStack_144 >> 2) - 1;
        uVar17 = 0;
        do {
          uVar10 = uVar10 & uVar18;
          uVar2 = *(uint *)(iStack_144 + uVar10 * 4);
          if (uVar2 == uVar15) goto LAB_0085db6c;
          if (uVar2 == uStack_134) break;
          uVar10 = uVar10 + 1 + uVar17;
          uVar17 = uVar17 + 1;
        } while (uVar17 <= uVar18);
      }
      if (cStack_29 != '\0') {
        if (DAT_01eb4954 != '\0') {
          piVar6 = *(int **)(uVar15 + 0x28);
          if (0xf < (uint)piVar6[5]) {
            piVar6 = (int *)*piVar6;
          }
          FUN_01677650(DAT_01eb4954,"  new island for %s",piVar6);
        }
        iStack_78 = 0;
        iStack_74 = 0;
        iStack_70 = 0;
        piStack_bc = (int *)0x0;
        piStack_b8 = (int *)0x0;
        iStack_b4 = 0;
        uStack_8._0_1_ = 7;
        FUN_0085bfc0(uVar15,&iStack_6c,&iStack_144,&iStack_78,&piStack_bc);
        if (7 < (uint)(iStack_74 - iStack_78)) {
          piVar6 = (int *)FUN_01674e20(100);
          piStack_1a8 = piVar6;
          if (piVar6 == (int *)0x0) {
            piVar6 = (int *)0x0;
            piStack_18 = (int *)0x0;
          }
          else {
            piStack_18 = piVar6;
            FUN_0170d1f0(piVar6,0,100);
            *piVar6 = 0;
            piVar6[1] = 0;
            piVar6[2] = 0;
            piVar6[3] = 0;
            piVar6[4] = 0;
            piVar6[5] = 0;
            piVar6[6] = 0;
            piVar6[7] = 0;
            piVar6[8] = 0;
            piVar6[9] = 0;
            piVar6[10] = 0;
            piVar6[0xb] = 0;
            piVar6[0xc] = 0;
            piVar6[0xd] = 0;
            piVar6[0xe] = 0;
            uStack_8._0_1_ = 0xd;
            uStack_198 = 0;
            uStack_1ac = 0;
            uStack_174 = 0;
            uStack_16c = 0;
            uStack_194 = 0;
            uStack_170 = 0;
            FUN_00806e90(0,&uStack_174,&uStack_88);
            piVar6[0x12] = 0;
            piVar6[0x13] = 0;
            piVar6[0x14] = 0;
            piVar6[0x16] = 0;
            piVar6[0x17] = 0;
            *(undefined *)(piVar6 + 0x18) = 0;
            *(undefined *)((int)piVar6 + 0x61) = 0;
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,7);
          piVar7 = (int *)FUN_0060dcd0(auStack_1a0,param_2);
          iStack_1b4 = piVar7[1];
          if (iStack_1b4 != 0) {
            LOCK();
            *(int *)(iStack_1b4 + 8) = *(int *)(iStack_1b4 + 8) + 1;
            UNLOCK();
            iStack_1b4 = piVar7[1];
          }
          iStack_1b0 = *piVar7;
          piVar6[0x16] = iStack_1b0;
          piVar7 = (int *)piVar6[0x17];
          piVar6[0x17] = iStack_1b4;
          if (piVar7 != (int *)0x0) {
            LOCK();
            iVar4 = piVar7[2] + -1;
            piVar7[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar7 + 4))();
            }
          }
          piVar7 = piStack_19c;
          if (piStack_19c != (int *)0x0) {
            LOCK();
            iVar4 = piStack_19c[1] + -1;
            piStack_19c[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)*piStack_19c)();
              LOCK();
              piVar1 = piVar7 + 2;
              iVar4 = *piVar1 + -1;
              *piVar1 = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)(*piVar7 + 4))();
              }
            }
          }
          if (piVar6 != &iStack_78) {
            FUN_00641040();
            *piVar6 = iStack_78;
            piVar6[1] = iStack_74;
            piVar6[2] = iStack_70;
            iStack_78 = 0;
            iStack_74 = 0;
            iStack_70 = 0;
          }
          puStack_1c = (undefined4 *)*piVar6;
          piStack_38 = (int *)piVar6[1];
          if (puStack_1c != piStack_38) {
            piVar6 = piVar6 + 9;
            do {
              piStack_1b8 = (int *)puStack_1c[1];
              if (piStack_1b8 != (int *)0x0) {
                LOCK();
                piStack_1b8[1] = piStack_1b8[1] + 1;
                UNLOCK();
                piStack_1b8 = (int *)puStack_1c[1];
              }
              puVar14 = (undefined4 *)*puStack_1c;
              uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
              puStack_1bc = puVar14;
              puStack_34 = puVar14;
              piStack_24 = piStack_1b8;
              if (puVar14[0x2b] != 0) {
                FUN_007c6530(puVar14[0x2b]);
              }
              puVar14[0x2b] = piStack_18;
              piVar7 = (int *)puVar14[0x2c];
              if ((piVar7 != (int *)0x0) && (piVar7 != param_3)) {
                (**(code **)(*piVar7 + 8))();
              }
              puStack_30 = puVar14 + 0x12;
              uStack_8._0_1_ = 0xf;
              uVar8 = FUN_01675290(DAT_02110da8);
              uStack_8._0_1_ = 0x10;
              uStack_178 = uVar8;
              puStack_3c = (undefined4 *)FUN_01674e20(0x1c);
              if (puStack_3c == (undefined4 *)0x0) {
                puStack_20 = (undefined4 *)0x0;
              }
              else {
                *puStack_3c = 0;
                puStack_3c[1] = 1;
                puStack_3c[2] = FUN_0085dd80;
                puStack_3c[3] = _guard_check_icall;
                puStack_3c[4] = 0;
                puStack_3c[5] = puStack_30;
                puStack_3c[6] = piStack_18;
                puStack_20 = puStack_3c;
              }
              FUN_016797d0(puStack_20);
              puStack_9c = puStack_20;
              if (puStack_20 != (undefined4 *)0x0) {
                LOCK();
                puStack_20[1] = puStack_20[1] + 1;
                UNLOCK();
              }
              puStack_14 = (undefined4 *)((uint)puVar16 | 1);
              uStack_8._0_1_ = 0x11;
              FUN_01675290(uVar8);
              puVar14 = (undefined4 *)piVar6[1];
              uStack_8._0_1_ = 0xf;
              if ((undefined4 *)piVar6[2] == puVar14) {
                FUN_006335f0(puVar14,&puStack_9c);
                puStack_14 = (undefined4 *)((uint)puVar16 & 0xfffffffe);
                if (puStack_9c != (undefined4 *)0x0) {
                  piVar7 = puStack_9c + 1;
                  LOCK();
                  iVar4 = *piVar7;
                  *piVar7 = *piVar7 + -1;
                  UNLOCK();
                  if (iVar4 == 1) {
                    FUN_01674ea0(puStack_9c);
                  }
                }
              }
              else {
                *puVar14 = puStack_20;
                piVar6[1] = piVar6[1] + 4;
                puStack_14 = (undefined4 *)((uint)puVar16 & 0xfffffffe);
                puStack_9c = (undefined4 *)0x0;
              }
              puStack_30 = puStack_34 + 0x13;
              uStack_8._0_1_ = 0x12;
              puStack_3c = (undefined4 *)((uint)puVar16 & 0xfffffffe);
              uVar8 = FUN_01675290(DAT_02110da8);
              uStack_8._0_1_ = 0x13;
              uStack_17c = uVar8;
              puStack_f0 = (undefined4 *)FUN_01674e20(0x1c);
              if (puStack_f0 == (undefined4 *)0x0) {
                puStack_20 = (undefined4 *)0x0;
              }
              else {
                *puStack_f0 = 0;
                puStack_f0[1] = 1;
                puStack_f0[2] = FUN_0085e110;
                puStack_f0[3] = _guard_check_icall;
                puStack_f0[4] = 0;
                puStack_f0[5] = puStack_30;
                puStack_f0[6] = piStack_18;
                puStack_20 = puStack_f0;
              }
              FUN_016797d0(puStack_20);
              puStack_a0 = puStack_20;
              if (puStack_20 != (undefined4 *)0x0) {
                LOCK();
                puStack_20[1] = puStack_20[1] + 1;
                UNLOCK();
              }
              puStack_14 = (undefined4 *)((uint)puVar16 & 0xfffffffe | 2);
              uStack_8._0_1_ = 0x14;
              FUN_01675290(uVar8);
              puVar16 = (undefined4 *)piVar6[1];
              uStack_8._0_1_ = 0x12;
              if ((undefined4 *)piVar6[2] == puVar16) {
                FUN_006335f0(puVar16,&puStack_a0);
              }
              else {
                *puVar16 = puStack_20;
                piVar6[1] = piVar6[1] + 4;
                puStack_a0 = (undefined4 *)0x0;
              }
              puStack_20 = (undefined4 *)((uint)puStack_3c & 0xfffffffd);
              uStack_8._0_1_ = 0xe;
              puStack_14 = puStack_20;
              if (puStack_a0 != (undefined4 *)0x0) {
                piVar7 = puStack_a0 + 1;
                LOCK();
                iVar4 = *piVar7;
                *piVar7 = *piVar7 + -1;
                UNLOCK();
                if (iVar4 == 1) {
                  FUN_01674ea0(puStack_a0);
                }
              }
              iVar4 = FUN_008a4100();
              puStack_30 = (undefined4 *)(iVar4 + 0x10);
              uStack_8._0_1_ = 0x15;
              uVar8 = FUN_01675290(DAT_02110da8);
              uStack_8._0_1_ = 0x16;
              puStack_f0 = (undefined4 *)uVar8;
              puStack_f4 = (undefined4 *)FUN_01674e20(0x1c);
              if (puStack_f4 == (undefined4 *)0x0) {
                puVar16 = (undefined4 *)0x0;
              }
              else {
                *puStack_f4 = 0;
                puStack_f4[1] = 1;
                puStack_f4[2] = FUN_0085de70;
                puStack_f4[3] = _guard_check_icall;
                puStack_f4[4] = 0;
                puStack_f4[5] = puStack_30;
                puStack_f4[6] = piStack_18;
                puVar16 = puStack_f4;
              }
              FUN_016797d0(puVar16);
              if (puVar16 != (undefined4 *)0x0) {
                LOCK();
                puVar16[1] = puVar16[1] + 1;
                UNLOCK();
              }
              puStack_14 = (undefined4 *)((uint)puStack_20 | 4);
              uStack_8._0_1_ = 0x17;
              puStack_a4 = puVar16;
              FUN_01675290(uVar8);
              puVar14 = (undefined4 *)piVar6[1];
              uStack_8._0_1_ = 0x15;
              if ((undefined4 *)piVar6[2] == puVar14) {
                FUN_006335f0(puVar14,&puStack_a4);
              }
              else {
                *puVar14 = puVar16;
                piVar6[1] = piVar6[1] + 4;
                puStack_a4 = (undefined4 *)0x0;
              }
              puVar16 = puStack_3c;
              uVar15 = (uint)puStack_3c & 0xfffffff9;
              uStack_8._0_1_ = 0xe;
              puStack_14 = (undefined4 *)uVar15;
              if (puStack_a4 != (undefined4 *)0x0) {
                piVar7 = puStack_a4 + 1;
                LOCK();
                iVar4 = *piVar7;
                *piVar7 = *piVar7 + -1;
                UNLOCK();
                if (iVar4 == 1) {
                  FUN_01674ea0(puStack_a4);
                }
              }
              iVar4 = FUN_008a4100();
              puStack_3c = (undefined4 *)(iVar4 + 0x14);
              uStack_8._0_1_ = 0x18;
              uVar8 = FUN_01675290(DAT_02110da8);
              uStack_8._0_1_ = 0x19;
              puStack_f4 = (undefined4 *)uVar8;
              puStack_30 = (undefined4 *)FUN_01674e20(0x1c);
              if (puStack_30 == (undefined4 *)0x0) {
                puStack_20 = (undefined4 *)0x0;
              }
              else {
                *puStack_30 = 0;
                puStack_30[1] = 1;
                puStack_30[2] = FUN_0085de70;
                puStack_30[3] = _guard_check_icall;
                puStack_30[4] = 0;
                puStack_30[5] = puStack_3c;
                puStack_30[6] = piStack_18;
                puStack_20 = puStack_30;
              }
              FUN_016797d0(puStack_20);
              puStack_a8 = puStack_20;
              if (puStack_20 != (undefined4 *)0x0) {
                LOCK();
                puStack_20[1] = puStack_20[1] + 1;
                UNLOCK();
              }
              puStack_14 = (undefined4 *)(uVar15 | 8);
              uStack_8._0_1_ = 0x1a;
              FUN_01675290(uVar8);
              puVar14 = (undefined4 *)piVar6[1];
              uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
              if ((undefined4 *)piVar6[2] == puVar14) {
                FUN_006335f0(puVar14,&puStack_a8);
                puStack_14 = (undefined4 *)((uint)puVar16 & 0xfffffff1);
                if (puStack_a8 != (undefined4 *)0x0) {
                  piVar7 = puStack_a8 + 1;
                  LOCK();
                  iVar4 = *piVar7;
                  *piVar7 = *piVar7 + -1;
                  UNLOCK();
                  if (iVar4 == 1) {
                    FUN_01674ea0(puStack_a8);
                  }
                }
              }
              else {
                *puVar14 = puStack_20;
                piVar6[1] = piVar6[1] + 4;
                puStack_14 = (undefined4 *)((uint)puVar16 & 0xfffffff1);
                puStack_a8 = (undefined4 *)0x0;
              }
              puVar16 = (undefined4 *)((uint)puVar16 & 0xfffffff1);
              puStack_30 = puStack_34;
              iVar4 = FUN_006b5480(&puStack_30);
              puVar14 = (undefined4 *)(-(uint)(iVar4 != 0) & iVar4 + 4U);
              if (puVar14 != (undefined4 *)0x0) {
                puStack_34 = (undefined4 *)*puVar14;
                puStack_20 = (undefined4 *)puVar14[1];
                if (puStack_34 != puStack_20) {
                  do {
                    if (puStack_34[2] != 0) {
                      puStack_3c = (undefined4 *)(puStack_34[2] + 0x48);
                      uStack_8._0_1_ = 0x1b;
                      uVar8 = FUN_01675290(DAT_02110da8);
                      uStack_8._0_1_ = 0x1c;
                      uStack_180 = uVar8;
                      puStack_54 = (undefined4 *)FUN_01674e20(0x1c);
                      if (puStack_54 == (undefined4 *)0x0) {
                        puVar14 = (undefined4 *)0x0;
                      }
                      else {
                        *puStack_54 = 0;
                        puStack_54[1] = 1;
                        puStack_54[2] = FUN_0085dd80;
                        puStack_54[3] = _guard_check_icall;
                        puStack_54[4] = 0;
                        puStack_54[5] = puStack_3c;
                        puStack_54[6] = piStack_18;
                        puVar14 = puStack_54;
                      }
                      FUN_016797d0(puVar14);
                      if (puVar14 != (undefined4 *)0x0) {
                        LOCK();
                        puVar14[1] = puVar14[1] + 1;
                        UNLOCK();
                      }
                      puStack_14 = (undefined4 *)((uint)puVar16 | 0x10);
                      uStack_8._0_1_ = 0x1d;
                      puStack_ac = puVar14;
                      FUN_01675290(uVar8);
                      piVar6 = piStack_18;
                      uStack_8 = CONCAT31(uStack_8._1_3_,0x1b);
                      puVar19 = (undefined4 *)piStack_18[10];
                      if ((undefined4 *)piStack_18[0xb] == puVar19) {
                        FUN_006335f0(puVar19,&puStack_ac);
                        puStack_14 = (undefined4 *)((uint)puVar16 & 0xffffffef);
                        if (puStack_ac != (undefined4 *)0x0) {
                          piVar7 = puStack_ac + 1;
                          LOCK();
                          iVar4 = *piVar7;
                          *piVar7 = *piVar7 + -1;
                          UNLOCK();
                          if (iVar4 == 1) {
                            FUN_01674ea0(puStack_ac);
                          }
                        }
                      }
                      else {
                        *puVar19 = puVar14;
                        piStack_18[10] = piStack_18[10] + 4;
                        puStack_14 = (undefined4 *)((uint)puVar16 & 0xffffffef);
                        puStack_ac = (undefined4 *)0x0;
                      }
                      puVar16 = (undefined4 *)((uint)puVar16 & 0xffffffef);
                      piVar6 = piVar6 + 9;
                    }
                    puStack_34 = puStack_34 + 3;
                  } while (puStack_34 != puStack_20);
                }
              }
              piVar7 = piStack_24;
              uStack_8 = CONCAT31(uStack_8._1_3_,7);
              if (piStack_24 != (int *)0x0) {
                LOCK();
                iVar4 = piStack_24[1] + -1;
                piStack_24[1] = iVar4;
                UNLOCK();
                if (iVar4 == 0) {
                  (**(code **)*piStack_24)();
                  LOCK();
                  piVar1 = piVar7 + 2;
                  iVar4 = *piVar1 + -1;
                  *piVar1 = iVar4;
                  UNLOCK();
                  if (iVar4 == 0) {
                    (**(code **)(*piVar7 + 4))();
                  }
                }
              }
              puStack_1c = puStack_1c + 2;
            } while (puStack_1c != piStack_38);
          }
          piStack_38 = piStack_b8;
          piStack_24 = piStack_bc;
          if (piStack_bc != piStack_b8) {
            do {
              puStack_1c = (undefined4 *)(*piStack_24 + 0x48);
              uStack_8._0_1_ = 0x1e;
              uVar8 = FUN_01675290(DAT_02110da8);
              uStack_8._0_1_ = 0x1f;
              uStack_184 = uVar8;
              puStack_54 = (undefined4 *)FUN_01674e20(0x1c);
              if (puStack_54 == (undefined4 *)0x0) {
                puVar14 = (undefined4 *)0x0;
              }
              else {
                *puStack_54 = 0;
                puStack_54[1] = 1;
                puStack_54[2] = FUN_0085dd80;
                puStack_54[3] = _guard_check_icall;
                puStack_54[4] = 0;
                puStack_54[5] = puStack_1c;
                puStack_54[6] = piStack_18;
                puVar14 = puStack_54;
              }
              FUN_016797d0(puVar14);
              if (puVar14 != (undefined4 *)0x0) {
                LOCK();
                puVar14[1] = puVar14[1] + 1;
                UNLOCK();
              }
              puStack_14 = (undefined4 *)((uint)puVar16 | 0x20);
              uStack_8._0_1_ = 0x20;
              puStack_b0 = puVar14;
              FUN_01675290(uVar8);
              uStack_8._0_1_ = 0x1e;
              puVar19 = (undefined4 *)piStack_18[10];
              if ((undefined4 *)piStack_18[0xb] == puVar19) {
                FUN_006335f0(puVar19,&puStack_b0);
              }
              else {
                *puVar19 = puVar14;
                piStack_18[10] = piStack_18[10] + 4;
                puStack_b0 = (undefined4 *)0x0;
              }
              puVar16 = (undefined4 *)((uint)puVar16 & 0xffffffdf);
              uStack_8 = CONCAT31(uStack_8._1_3_,7);
              puStack_14 = puVar16;
              if (puStack_b0 != (undefined4 *)0x0) {
                piVar6 = puStack_b0 + 1;
                LOCK();
                iVar4 = *piVar6;
                *piVar6 = *piVar6 + -1;
                UNLOCK();
                if (iVar4 == 1) {
                  FUN_01674ea0(puStack_b0);
                }
              }
              piStack_24 = piStack_24 + 1;
            } while (piStack_24 != piStack_38);
          }
          piStack_38 = piStack_80;
          piStack_24 = piStack_84;
          if (piStack_84 != piStack_80) {
            do {
              puStack_1c = (undefined4 *)(*piStack_24 + 0x4c);
              uStack_8._0_1_ = 0x21;
              uVar8 = FUN_01675290(DAT_02110da8);
              uStack_8._0_1_ = 0x22;
              uStack_188 = uVar8;
              puStack_54 = (undefined4 *)FUN_01674e20(0x1c);
              if (puStack_54 == (undefined4 *)0x0) {
                puVar14 = (undefined4 *)0x0;
              }
              else {
                *puStack_54 = 0;
                puStack_54[1] = 1;
                puStack_54[2] = FUN_0085df40;
                puStack_54[3] = _guard_check_icall;
                puStack_54[4] = 0;
                puStack_54[5] = puStack_1c;
                puStack_54[6] = piStack_18;
                puVar14 = puStack_54;
              }
              FUN_016797d0(puVar14);
              if (puVar14 != (undefined4 *)0x0) {
                LOCK();
                puVar14[1] = puVar14[1] + 1;
                UNLOCK();
              }
              puStack_14 = (undefined4 *)((uint)puVar16 | 0x40);
              uStack_8._0_1_ = 0x23;
              puStack_c0 = puVar14;
              FUN_01675290(uVar8);
              uStack_8._0_1_ = 0x21;
              puVar19 = (undefined4 *)piStack_18[10];
              if ((undefined4 *)piStack_18[0xb] == puVar19) {
                FUN_006335f0(puVar19,&puStack_c0);
              }
              else {
                *puVar19 = puVar14;
                piStack_18[10] = piStack_18[10] + 4;
                puStack_c0 = (undefined4 *)0x0;
              }
              puVar16 = (undefined4 *)((uint)puVar16 & 0xffffffbf);
              uStack_8 = CONCAT31(uStack_8._1_3_,7);
              puStack_14 = puVar16;
              if (puStack_c0 != (undefined4 *)0x0) {
                piVar6 = puStack_c0 + 1;
                LOCK();
                iVar4 = *piVar6;
                *piVar6 = *piVar6 + -1;
                UNLOCK();
                if (iVar4 == 1) {
                  FUN_01674ea0(puStack_c0);
                }
              }
              piStack_24 = piStack_24 + 1;
            } while (piStack_24 != piStack_38);
          }
          piStack_24 = piStack_e4;
          piStack_38 = piStack_e0;
          if (piStack_e4 != piStack_e0) {
            do {
              iVar4 = *piStack_24;
              iVar5 = *(int *)(iVar4 + 0xc);
              iVar9 = FUN_00ca4c20();
              iVar12 = 0;
              if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar9 + 0x1d8) <=
                  (uint)*(ushort *)(iVar9 + 0x1da)) {
                iVar12 = iVar4;
              }
              if (iVar12 == 0) {
                iVar5 = *(int *)(iVar4 + 0xc);
                iVar9 = FUN_00b4b860();
                iVar12 = 0;
                if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar9 + 0x1d8) <=
                    (uint)*(ushort *)(iVar9 + 0x1da)) {
                  iVar12 = iVar4;
                }
                if (iVar12 != 0) {
                  puStack_1c = (undefined4 *)(iVar12 + 0x4c);
                  uStack_8._0_1_ = 0x27;
                  uVar8 = FUN_01675290(DAT_02110da8);
                  uStack_8._0_1_ = 0x28;
                  uStack_190 = uVar8;
                  puStack_54 = (undefined4 *)FUN_01674e20(0x1c);
                  if (puStack_54 == (undefined4 *)0x0) {
                    puVar14 = (undefined4 *)0x0;
                  }
                  else {
                    *puStack_54 = 0;
                    puStack_54[1] = 1;
                    puStack_54[2] = FUN_0085dd50;
                    puStack_54[3] = _guard_check_icall;
                    puStack_54[4] = 0;
                    puStack_54[5] = puStack_1c;
                    puStack_54[6] = piStack_18;
                    puVar14 = puStack_54;
                  }
                  FUN_016797d0(puVar14);
                  if (puVar14 != (undefined4 *)0x0) {
                    LOCK();
                    puVar14[1] = puVar14[1] + 1;
                    UNLOCK();
                  }
                  puStack_14 = (undefined4 *)((uint)puVar16 | 0x100);
                  uStack_8._0_1_ = 0x29;
                  puStack_48 = puVar14;
                  FUN_01675290(uVar8);
                  uStack_8._0_1_ = 0x27;
                  puVar19 = (undefined4 *)piStack_18[10];
                  if ((undefined4 *)piStack_18[0xb] == puVar19) {
                    FUN_006335f0(puVar19,&puStack_48);
                  }
                  else {
                    *puVar19 = puVar14;
                    piStack_18[10] = piStack_18[10] + 4;
                    puStack_48 = (undefined4 *)0x0;
                  }
                  puVar16 = (undefined4 *)((uint)puVar16 & 0xfffffeff);
                  puVar14 = puStack_48;
                  goto LAB_0085d8ea;
                }
              }
              else {
                puStack_1c = (undefined4 *)(iVar12 + 0x4c);
                uStack_8._0_1_ = 0x24;
                uVar8 = FUN_01675290(DAT_02110da8);
                uStack_8._0_1_ = 0x25;
                uStack_18c = uVar8;
                puStack_54 = (undefined4 *)FUN_01674e20(0x1c);
                if (puStack_54 == (undefined4 *)0x0) {
                  puVar14 = (undefined4 *)0x0;
                }
                else {
                  *puStack_54 = 0;
                  puStack_54[1] = 1;
                  puStack_54[2] = FUN_0085e0e0;
                  puStack_54[3] = _guard_check_icall;
                  puStack_54[4] = 0;
                  puStack_54[5] = puStack_1c;
                  puStack_54[6] = piStack_18;
                  puVar14 = puStack_54;
                }
                FUN_016797d0(puVar14);
                if (puVar14 != (undefined4 *)0x0) {
                  LOCK();
                  puVar14[1] = puVar14[1] + 1;
                  UNLOCK();
                }
                puStack_14 = (undefined4 *)((uint)puVar16 | 0x80);
                uStack_8._0_1_ = 0x26;
                puStack_44 = puVar14;
                FUN_01675290(uVar8);
                uStack_8._0_1_ = 0x24;
                puVar19 = (undefined4 *)piStack_18[10];
                if ((undefined4 *)piStack_18[0xb] == puVar19) {
                  FUN_006335f0(puVar19,&puStack_44);
                  puVar16 = (undefined4 *)((uint)puVar16 & 0xffffff7f);
                  puVar14 = puStack_44;
                }
                else {
                  *puVar19 = puVar14;
                  piStack_18[10] = piStack_18[10] + 4;
                  puVar16 = (undefined4 *)((uint)puVar16 & 0xffffff7f);
                  puStack_44 = (undefined4 *)0x0;
                  puVar14 = (undefined4 *)0x0;
                }
LAB_0085d8ea:
                uStack_8 = CONCAT31(uStack_8._1_3_,7);
                puStack_14 = puVar16;
                if (puVar14 != (undefined4 *)0x0) {
                  piVar6 = puVar14 + 1;
                  LOCK();
                  iVar4 = *piVar6;
                  *piVar6 = *piVar6 + -1;
                  UNLOCK();
                  if (iVar4 == 1) {
                    FUN_01674ea0(puVar14);
                  }
                }
              }
              piStack_24 = piStack_24 + 1;
            } while (piStack_24 != piStack_38);
          }
          FUN_008a40f0();
          iVar4 = FUN_008a4100();
          puStack_1c = (undefined4 *)(iVar4 + 0x10);
          uStack_8._0_1_ = 0x2a;
          puVar14 = (undefined4 *)FUN_01675290(DAT_02110da8);
          uStack_8._0_1_ = 0x2b;
          puStack_54 = puVar14;
          piStack_38 = (int *)FUN_01674e20(0x1c);
          if (piStack_38 == (undefined4 *)0x0) {
            puVar19 = (undefined4 *)0x0;
          }
          else {
            *piStack_38 = 0;
            piStack_38[1] = 1;
            piStack_38[2] = (int)FUN_0085df70;
            piStack_38[3] = (int)_guard_check_icall;
            piStack_38[4] = 0;
            piStack_38[5] = (int)puStack_1c;
            piStack_38[6] = (int)piStack_18;
            puVar19 = piStack_38;
          }
          FUN_016797d0(puVar19);
          if (puVar19 != (undefined4 *)0x0) {
            LOCK();
            puVar19[1] = puVar19[1] + 1;
            UNLOCK();
          }
          puStack_14 = (undefined4 *)((uint)puVar16 | 0x200);
          uStack_8._0_1_ = 0x2c;
          puStack_4c = puVar19;
          FUN_01675290(puVar14);
          uStack_8._0_1_ = 0x2a;
          puVar14 = (undefined4 *)piStack_18[10];
          if ((undefined4 *)piStack_18[0xb] == puVar14) {
            FUN_006335f0(puVar14,&puStack_4c);
            puStack_14 = (undefined4 *)((uint)puVar16 & 0xfffffdff);
            if (puStack_4c != (undefined4 *)0x0) {
              piVar6 = puStack_4c + 1;
              LOCK();
              iVar4 = *piVar6;
              *piVar6 = *piVar6 + -1;
              UNLOCK();
              if (iVar4 == 1) {
                FUN_01674ea0(puStack_4c);
              }
            }
          }
          else {
            *puVar14 = puVar19;
            piStack_18[10] = piStack_18[10] + 4;
            puStack_14 = (undefined4 *)((uint)puVar16 & 0xfffffdff);
            puStack_4c = (undefined4 *)0x0;
          }
          puStack_1c = (undefined4 *)(param_2 + 0x48);
          uStack_8._0_1_ = 0x2d;
          piStack_38 = (int *)((uint)puVar16 & 0xfffffdff);
          puVar14 = (undefined4 *)FUN_01675290(DAT_02110da8);
          uStack_8._0_1_ = 0x2e;
          piStack_24 = puVar14;
          puStack_3c = (undefined4 *)FUN_01674e20(0x1c);
          if (puStack_3c == (undefined4 *)0x0) {
            puVar19 = (undefined4 *)0x0;
          }
          else {
            *puStack_3c = 0;
            puStack_3c[1] = 1;
            puStack_3c[2] = FUN_0085dd80;
            puStack_3c[3] = _guard_check_icall;
            puStack_3c[4] = 0;
            puStack_3c[5] = puStack_1c;
            puStack_3c[6] = piStack_18;
            puVar19 = puStack_3c;
          }
          FUN_016797d0(puVar19);
          if (puVar19 != (undefined4 *)0x0) {
            LOCK();
            puVar19[1] = puVar19[1] + 1;
            UNLOCK();
          }
          puStack_14 = (undefined4 *)((uint)puVar16 & 0xfffffdff | 0x400);
          uStack_8._0_1_ = 0x2f;
          puStack_50 = puVar19;
          FUN_01675290(puVar14);
          piVar6 = piStack_18;
          puVar16 = (undefined4 *)piStack_18[10];
          uStack_8._0_1_ = 0x2d;
          if ((undefined4 *)piStack_18[0xb] == puVar16) {
            FUN_006335f0(puVar16,&puStack_50);
          }
          else {
            *puVar16 = puVar19;
            piStack_18[10] = piStack_18[10] + 4;
            puStack_50 = (undefined4 *)0x0;
          }
          puVar16 = (undefined4 *)((uint)piStack_38 & 0xfffffbff);
          uStack_8._0_1_ = 7;
          puStack_14 = puVar16;
          if (puStack_50 != (undefined4 *)0x0) {
            piVar7 = puStack_50 + 1;
            LOCK();
            iVar4 = *piVar7;
            *piVar7 = *piVar7 + -1;
            UNLOCK();
            if (iVar4 == 1) {
              FUN_01674ea0(puStack_50);
            }
          }
          *(undefined *)((int)piVar6 + 0x61) = 1;
          FUN_007c51a0(piVar6);
        }
        if (piStack_bc != (int *)0x0) {
          FUN_0057d270(piStack_bc,iStack_b4 - (int)piStack_bc >> 2);
          piStack_bc = (int *)0x0;
          piStack_b8 = (int *)0x0;
          iStack_b4 = 0;
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
        FUN_00641040();
      }
LAB_0085db6c:
      do {
        puStack_28 = (undefined4 *)((int)puStack_28 + 1);
        if ((uint)(iStack_d4 - iStack_d8 >> 2) <= puStack_28) break;
      } while (*(undefined4 **)(iStack_d8 + (int)puStack_28 * 4) == puStack_c8);
      goto LAB_0085cbb0;
    }
    FUN_0056d320();
    FUN_0085bf50();
    FUN_0056d320();
    if (piStack_84 != (int *)0x0) {
      FUN_0057d270(piStack_84,iStack_7c - (int)piStack_84 >> 2);
      piStack_84 = (int *)0x0;
      piStack_80 = (int *)0x0;
      iStack_7c = 0;
    }
    FUN_0056d320();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13148 ; VA 0x0085dc10 ; FUN_0085dc10 */

void __fastcall FUN_0085dc10(undefined4 *param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  
  iVar3 = param_1[9];
  iVar5 = param_1[10];
  if (iVar3 != iVar5) {
    do {
      FUN_01679490();
      iVar3 = iVar3 + 4;
    } while (iVar3 != iVar5);
    iVar5 = param_1[10];
  }
  FUN_00633350(param_1[9],iVar5,param_1 + 9);
  param_1[10] = param_1[9];
  piVar2 = (int *)param_1[1];
  for (piVar6 = (int *)*param_1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
    piVar4 = (int *)piVar6[1];
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)piVar6[1];
    }
    if (*(undefined4 **)(*piVar6 + 0xac) == param_1) {
      *(undefined4 *)(*piVar6 + 0xac) = 0;
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar3 = piVar4[1] + -1;
      piVar4[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar3 = piVar4[2] + -1;
        piVar4[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  iVar3 = param_1[0xd];
  iVar5 = param_1[0xc];
  if (iVar5 != iVar3) {
    do {
      FUN_01679490();
      iVar5 = iVar5 + 4;
    } while (iVar5 != iVar3);
    iVar3 = param_1[0xd];
  }
  FUN_00633350(param_1[0xc],iVar3,param_1 + 0xc);
  puVar1 = param_1 + 3;
  param_1[0xd] = param_1[0xc];
  FUN_007be660(*puVar1,param_1[4],puVar1);
  param_1[4] = *puVar1;
  FUN_005596d0(*param_1,param_1[1],param_1);
  param_1[1] = *param_1;
  param_1[0x16] = 0;
  piVar2 = (int *)param_1[0x17];
  param_1[0x17] = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar6 = piVar2 + 2;
    iVar3 = *piVar6;
    *piVar6 = *piVar6 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  *(undefined *)(param_1 + 0x18) = 0;
  *(undefined *)((int)param_1 + 0x61) = 0;
  return;
}



/* FUNCTION 13149 ; VA 0x0085dd50 ; FUN_0085dd50 */

void FUN_0085dd50(int param_1,undefined *param_2)

{
  if (((param_2 == &DAT_0212c024) || (param_2 == &DAT_0212c060)) || (param_2 == &DAT_0212c10c)) {
    *(undefined *)(*(int *)(param_1 + 0x18) + 0x61) = 0;
  }
  return;
}



/* FUNCTION 13150 ; VA 0x0085dd80 ; FUN_0085dd80 */

int FUN_0085dd80(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = *(int *)(param_1 + 0x18);
  *(undefined *)(iVar3 + 0x61) = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0085de41. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar3 = (**(code **)(*param_5 + 4))();
        return iVar3;
      }
    }
  }
  return iVar3;
}



/* FUNCTION 13151 ; VA 0x0085de50 ; FUN_0085de50 */

void FUN_0085de50(int param_1,undefined *param_2)

{
  if (param_2 == &DAT_0211a3a0) {
    *(undefined *)(*(int *)(param_1 + 0x18) + 0x60) = 0;
  }
  return;
}



/* FUNCTION 13152 ; VA 0x0085de70 ; FUN_0085de70 */

uint FUN_0085de70(int param_1,int param_2,int *param_3)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b5e40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar4 = *(int *)(param_2 + 0xc);
  uStack_8 = 1;
  iVar5 = FUN_00d77b00();
  uVar6 = (uint)*(ushort *)(iVar5 + 0x1da);
  if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <= uVar6) {
    uVar6 = *(uint *)(param_1 + 0x18);
    *(undefined *)(uVar6 + 0x61) = 0;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_3 + 1);
    uVar3 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      puVar1 = (uint *)(param_3 + 2);
      uVar3 = *puVar1;
      uVar6 = *puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        uVar6 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_3 + 1);
    uVar3 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar6 = (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uVar6 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 13153 ; VA 0x0085df40 ; FUN_0085df40 */

void FUN_0085df40(int param_1,undefined4 *param_2)

{
  if (((param_2 == &DAT_02134d38) || (param_2 == &DAT_02134d74)) ||
     (param_2 == (undefined4 *)&DAT_02134d00)) {
    *(undefined *)(*(int *)(param_1 + 0x18) + 0x61) = 0;
  }
  return;
}



/* FUNCTION 13154 ; VA 0x0085df70 ; FUN_0085df70 */

int FUN_0085df70(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b5e40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = *(int *)(param_2 + 0xc);
  uStack_8 = 1;
  iVar2 = FUN_00c396b0();
  if ((uint)*(ushort *)(iVar2 + 0x1da) <
      (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) {
    iVar3 = *(int *)(param_2 + 0xc);
    iVar2 = FUN_00c39bb0();
    if ((uint)*(ushort *)(iVar2 + 0x1da) <
        (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) {
      iVar3 = *(int *)(param_2 + 0xc);
      iVar2 = FUN_00d7c7c0();
      if ((uint)*(ushort *)(iVar2 + 0x1da) <
          (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) {
        iVar3 = *(int *)(param_2 + 0xc);
        iVar2 = FUN_00d787b0();
        if ((uint)*(ushort *)(iVar2 + 0x1da) <
            (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) {
          iVar3 = *(int *)(param_2 + 0xc);
          iVar2 = FUN_00b4b860();
          if ((uint)*(ushort *)(iVar2 + 0x1da) <
              (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) {
            iVar3 = FUN_0085bbf0();
            if ((char)iVar3 == '\0') goto LAB_0085e078;
          }
        }
      }
    }
  }
  iVar3 = *(int *)(param_1 + 0x18);
  *(undefined *)(iVar3 + 0x61) = 0;
LAB_0085e078:
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 13155 ; VA 0x0085e0e0 ; FUN_0085e0e0 */

void FUN_0085e0e0(int param_1,undefined *param_2)

{
  if (((param_2 == &DAT_0213aa70) || (param_2 == &DAT_0213aaac)) || (param_2 == &DAT_0213aae8)) {
    *(undefined *)(*(int *)(param_1 + 0x18) + 0x61) = 0;
  }
  return;
}



/* FUNCTION 13156 ; VA 0x0085e110 ; FUN_0085e110 */

void FUN_0085e110(int param_1,undefined4 *param_2)

{
  if (((param_2 == (undefined4 *)&DAT_0211a3a0) || (param_2 == &DAT_01f04f88)) ||
     (param_2 == &DAT_0213cf4c)) {
    *(undefined *)(*(int *)(param_1 + 0x18) + 0x60) = 0;
  }
  return;
}



/* FUNCTION 13157 ; VA 0x0085e140 ; FUN_0085e140 */

int FUN_0085e140(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = *(int *)(param_1 + 0x18);
  *(undefined *)(iVar3 + 0x60) = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0085e201. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar3 = (**(code **)(*param_5 + 4))();
        return iVar3;
      }
    }
  }
  return iVar3;
}



/* FUNCTION 13158 ; VA 0x0085e210 ; FUN_0085e210 */

undefined4 * __thiscall FUN_0085e210(int *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  char cVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  
  iVar2 = *param_1;
  iVar3 = param_1[1];
  if ((iVar2 != iVar3) &&
     (cVar6 = FUN_0055c360(*param_2,param_2[1],param_1[4],param_1[5]), cVar6 == '\0')) {
    uVar8 = (iVar3 - iVar2) / 0xc - 1;
    uVar7 = FUN_0085bec0(*param_2,param_2[1]);
    uVar9 = 0;
    uVar4 = *param_2;
    uVar5 = param_2[1];
    do {
      uVar7 = uVar7 & uVar8;
      puVar1 = (undefined4 *)(iVar2 + uVar7 * 0xc);
      cVar6 = FUN_0055c360(*puVar1,puVar1[1],uVar4,uVar5);
      if (cVar6 != '\0') {
        return puVar1;
      }
      cVar6 = FUN_0055c360(*puVar1,puVar1[1],param_1[4],param_1[5]);
      if (cVar6 != '\0') {
        return (undefined4 *)0x0;
      }
      uVar7 = uVar7 + 1 + uVar9;
      uVar9 = uVar9 + 1;
    } while (uVar9 <= uVar8);
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 13159 ; VA 0x0085e2f0 ; FUN_0085e2f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0085e2f0(int param_1,int param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 uVar7;
  int iVar8;
  int iVar9;
  int *piVar10;
  int *piVar11;
  undefined4 uStack_78;
  int *piStack_74;
  undefined uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined auStack_34 [4];
  int *piStack_30;
  undefined4 *puStack_2c;
  int *piStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b857a;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  puStack_2c = *(undefined4 **)(param_2 + 0x28);
  piStack_28 = (int *)puStack_2c[4];
  if (0xf < (uint)puStack_2c[5]) {
    puStack_2c = (undefined4 *)*puStack_2c;
  }
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  puStack_18 = puStack_2c;
  iVar4 = FUN_0085e210(&puStack_2c);
  piVar11 = (int *)(-(uint)(iVar4 != 0) & iVar4 + 8U);
  if (piVar11 == (int *)0x0) {
    uStack_68 = _DAT_018e3fb0;
    uStack_64 = _UNK_018e3fb4;
    uStack_60 = _UNK_018e3fb8;
    uStack_5c = _UNK_018e3fbc;
    uStack_78 = 0;
    uStack_58 = _DAT_018e3fb0;
    uStack_54 = _UNK_018e3fb4;
    uStack_50 = _UNK_018e3fb8;
    uStack_4c = _UNK_018e3fbc;
    piStack_74 = (int *)0x0;
    uStack_48 = _DAT_018e3fb0;
    uStack_44 = _UNK_018e3fb4;
    uStack_40 = _UNK_018e3fb8;
    uStack_3c = _UNK_018e3fbc;
    uStack_8 = 0;
    puVar5 = (undefined4 *)FUN_0060dcd0(auStack_24,param_2);
    uStack_78 = *puVar5;
    piStack_74 = (int *)puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_20[1] + -1;
      piStack_20[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar4 = piStack_20[2] + -1;
        piStack_20[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    uStack_38 = param_3;
    uStack_6c = 0;
    piStack_20 = (int *)(param_1 + 0xc);
    FUN_0085b960(&uStack_78);
    iVar4 = (*(int *)(param_1 + 0x10) - *(int *)(param_1 + 0xc)) / 0x44 + -1;
    if ((uint)(((*(int *)(param_1 + 0x40) - *(int *)(param_1 + 0x3c)) / 0xc) * 3) >> 2 <=
        *(uint *)(param_1 + 0x48)) {
      FUN_0085eb40();
    }
    iVar6 = FUN_0085e8b0(&puStack_2c);
    *(int *)(iVar6 + 8) = iVar4;
    if (DAT_01eb4954 != '\0') {
      FUN_01677520(DAT_01eb4954,"    %s %d new micro bone",puStack_18,iVar4);
    }
    piVar11 = piStack_74;
    if (piStack_74 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_74[1] + -1;
      piStack_74[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_74)();
        LOCK();
        piVar10 = piVar11 + 2;
        iVar4 = *piVar10 + -1;
        *piVar10 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar11 + 4))();
        }
      }
    }
  }
  else {
    piStack_20 = (int *)(param_1 + 0xc);
    iVar4 = *piVar11 * 0x10 + *piVar11;
    if (*(char *)(*piStack_20 + 0xc + iVar4 * 4) != '\0') {
      *(undefined *)(*piStack_20 + 0xc + iVar4 * 4) = 0;
      uVar7 = FUN_0060dcd0(auStack_34,param_2);
      FUN_005587e0(uVar7);
      piStack_28 = piStack_30;
      if (piStack_30 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_30[1] + -1;
        piStack_30[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_30)();
          LOCK();
          iVar4 = piStack_28[2] + -1;
          piStack_28[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piStack_28 + 4))();
          }
        }
      }
      *(undefined4 *)(*(int *)(param_1 + 0xc) + 0x40 + (*piVar11 * 0x10 + *piVar11) * 4) = param_3;
      if (DAT_01eb4954 != '\0') {
        FUN_01677520(DAT_01eb4954,"    %s %d switching part to micro bone",puStack_18,*piVar11);
      }
    }
  }
  uStack_8 = 1;
  uVar7 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 2;
  piStack_28 = (int *)uVar7;
  puStack_18 = (undefined4 *)FUN_01674e20(0x1c);
  if (puStack_18 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puStack_18 = 0;
    puStack_18[1] = 1;
    puStack_18[2] = FUN_0085e140;
    puStack_18[3] = _guard_check_icall;
    puStack_18[4] = 0;
    puStack_18[5] = param_2 + 0x48;
    puStack_18[6] = iStack_1c;
    puVar5 = puStack_18;
  }
  FUN_016797d0(puVar5);
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_14 = 1;
  uStack_8._0_1_ = 3;
  puStack_18 = puVar5;
  FUN_01675290(uVar7);
  puVar1 = *(undefined4 **)(param_1 + 0x34);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (*(undefined4 **)(param_1 + 0x38) == puVar1) {
    FUN_006335f0(puVar1,&puStack_18);
    uStack_14 = 0;
    if (puStack_18 != (undefined4 *)0x0) {
      piVar11 = puStack_18 + 1;
      LOCK();
      iVar4 = *piVar11;
      *piVar11 = *piVar11 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        FUN_01674ea0(puStack_18);
      }
    }
  }
  else {
    *puVar1 = puVar5;
    *(int *)(param_1 + 0x34) = *(int *)(param_1 + 0x34) + 4;
    uStack_14 = 0;
  }
  uStack_8 = 4;
  uVar7 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 5;
  piStack_28 = (int *)uVar7;
  puStack_18 = (undefined4 *)FUN_01674e20(0x1c);
  if (puStack_18 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puStack_18 = 0;
    puStack_18[1] = 1;
    puStack_18[2] = FUN_0085de50;
    puStack_18[3] = _guard_check_icall;
    puStack_18[4] = 0;
    puStack_18[5] = param_2 + 0x4c;
    puStack_18[6] = iStack_1c;
    puVar5 = puStack_18;
  }
  FUN_016797d0(puVar5);
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_14 = 2;
  uStack_8._0_1_ = 6;
  puStack_18 = puVar5;
  FUN_01675290(uVar7);
  puVar1 = *(undefined4 **)(param_1 + 0x34);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (*(undefined4 **)(param_1 + 0x38) == puVar1) {
    FUN_006335f0(puVar1,&puStack_18);
    puVar5 = puStack_18;
  }
  else {
    *puVar1 = puVar5;
    *(int *)(param_1 + 0x34) = *(int *)(param_1 + 0x34) + 4;
    puVar5 = (undefined4 *)0x0;
  }
  uStack_8 = 0xffffffff;
  if (puVar5 != (undefined4 *)0x0) {
    piVar11 = puVar5 + 1;
    LOCK();
    iVar4 = *piVar11;
    *piVar11 = *piVar11 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(puVar5);
    }
  }
  puVar5 = *(undefined4 **)(param_2 + 0x2c);
  if (puVar5 != (undefined4 *)0x0) {
    iVar4 = piStack_20[1];
    iVar6 = *piStack_20;
    piVar11 = (int *)puVar5[1];
    for (piVar10 = (int *)*puVar5; piVar10 != piVar11; piVar10 = piVar10 + 2) {
      iVar2 = *piVar10;
      iVar3 = *(int *)(iVar2 + 0xc);
      iVar8 = FUN_00d77b00();
      iVar9 = 0;
      if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8) <=
          (uint)*(ushort *)(iVar8 + 0x1da)) {
        iVar9 = iVar2;
      }
      if (iVar9 != 0) {
        FUN_0085e2f0(iVar9,(iVar4 - iVar6) / 0x44 + -1);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13160 ; VA 0x0085e790 ; FUN_0085e790 */

undefined4 __thiscall FUN_0085e790(int param_1,char *param_2)

{
  char *pcVar1;
  char cVar2;
  int iVar3;
  char *pcStack_c;
  int iStack_8;
  
  pcStack_c = param_2;
  pcVar1 = param_2 + 1;
  do {
    cVar2 = *param_2;
    param_2 = param_2 + 1;
  } while (cVar2 != '\0');
  iStack_8 = (int)param_2 - (int)pcVar1;
  iVar3 = FUN_0085e210(&pcStack_c);
  if (iVar3 != 0) {
    if ((uint)(((*(int *)(param_1 + 0x40) - *(int *)(param_1 + 0x3c)) / 0xc) * 3) >> 2 <=
        *(uint *)(param_1 + 0x48)) {
      FUN_0085eb40();
    }
    iVar3 = FUN_0085e8b0(&pcStack_c);
    return *(undefined4 *)(iVar3 + 8);
  }
  return 0xffffffff;
}



/* FUNCTION 13161 ; VA 0x0085e810 ; FUN_0085e810 */

undefined __fastcall FUN_0085e810(int param_1)

{
  return *(undefined *)(param_1 + 0xb1);
}



/* FUNCTION 13162 ; VA 0x0085e850 ; FUN_0085e850 */

int FUN_0085e850(char param_1)

{
  int iVar1;
  
  iVar1 = FUN_008a40f0();
  if ((iVar1 == 0) && (param_1 == '\0')) {
    return 0;
  }
  iVar1 = FUN_008a4100();
  return iVar1 + 0x10;
}



/* FUNCTION 13163 ; VA 0x0085e880 ; FUN_0085e880 */

void __thiscall FUN_0085e880(int param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x5c);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar1 != 0) {
    LOCK();
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
    iVar1 = *(int *)(param_1 + 0x5c);
  }
  *param_2 = *(undefined4 *)(param_1 + 0x58);
  param_2[1] = iVar1;
  return;
}



/* FUNCTION 13164 ; VA 0x0085e8b0 ; FUN_0085e8b0 */

int * __thiscall FUN_0085e8b0(int *param_1,int *param_2)

{
  byte *pbVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  char cVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  
  iVar3 = *param_1;
  uVar9 = 0x811c9dc5;
  uVar8 = (param_1[1] - iVar3) / 0xc - 1;
  uVar7 = 0;
  if (param_2[1] != 0) {
    do {
      pbVar1 = (byte *)(uVar7 + *param_2);
      uVar7 = uVar7 + 1;
      uVar9 = (*pbVar1 ^ uVar9) * 0x1000193;
    } while (uVar7 < (uint)param_2[1]);
  }
  uVar7 = 0;
  iVar4 = param_1[4];
  iVar5 = param_1[5];
  while( true ) {
    uVar9 = uVar9 & uVar8;
    piVar2 = (int *)(iVar3 + uVar9 * 0xc);
    cVar6 = FUN_0055c360(*piVar2,piVar2[1],iVar4,iVar5);
    if (cVar6 != '\0') {
      *piVar2 = *param_2;
      piVar2[1] = param_2[1];
      param_1[3] = param_1[3] + 1;
      return piVar2;
    }
    cVar6 = FUN_0055c360(*piVar2,piVar2[1],*param_2,param_2[1]);
    if (cVar6 != '\0') break;
    uVar9 = uVar9 + 1 + uVar7;
    uVar7 = uVar7 + 1;
    if (uVar8 < uVar7) {
      return (int *)0x0;
    }
  }
  return piVar2;
}



/* FUNCTION 13165 ; VA 0x0085e990 ; FUN_0085e990 */

void __fastcall FUN_0085e990(int *param_1)

{
  int iVar1;
  int iVar2;
  uint *puVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  int iStack_50;
  uint uStack_4c;
  int aiStack_44 [8];
  int *piStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b85a0;
  pvStack_10 = ExceptionList;
  if (*param_1 == param_1[1]) {
    iVar7 = 0x10;
  }
  else {
    iVar7 = (param_1[1] - *param_1 >> 4) * 2;
  }
  aiStack_44[0] = param_1[4];
  aiStack_44[1] = 0;
  aiStack_44[2] = 0;
  aiStack_44[3] = 0;
  aiStack_44[4] = 0;
  aiStack_44[5] = 0;
  aiStack_44[6] = 0;
  ExceptionList = &pvStack_10;
  piStack_24 = param_1;
  FUN_00617ad0();
  uStack_8 = 0;
  FUN_0085bc80(iVar7,aiStack_44,&uStack_11);
  FUN_00617ad0();
  uStack_4c = param_1[4];
  iStack_50 = 0;
  iVar7 = *param_1;
  uStack_8 = 1;
  uStack_20 = 0;
  uStack_1c = uStack_4c;
  if (param_1[1] - iVar7 >> 4 != 0) {
    aiStack_44[7] = 0;
    do {
      puStack_18 = (uint *)(iVar7 + aiStack_44[7]);
      uVar5 = *puStack_18;
      uVar4 = uStack_1c;
      if (uVar5 != param_1[4]) {
        uVar4 = (uVar5 >> 3) + uVar5;
        uVar6 = (iStack_58 - iStack_5c >> 4) - 1;
        uVar8 = 0;
        do {
          uVar4 = uVar4 & uVar6;
          puVar3 = (uint *)(uVar4 * 0x10 + iStack_5c);
          if (*puVar3 == uStack_1c) {
            *puVar3 = uVar5;
            iStack_50 = iStack_50 + 1;
            uVar5 = *puStack_18;
            goto LAB_0085eab0;
          }
          if (*puVar3 == uVar5) goto LAB_0085eab0;
          uVar4 = uVar4 + 1 + uVar8;
          uVar8 = uVar8 + 1;
        } while (uVar8 <= uVar6);
        puVar3 = (uint *)0x0;
LAB_0085eab0:
        *puVar3 = uVar5;
        param_1 = piStack_24;
        uVar4 = uStack_4c;
        if (puVar3 + 1 != puStack_18 + 1) {
          FUN_0085b3c0(puStack_18[1],puStack_18[2],aiStack_44[7]);
          param_1 = piStack_24;
          uVar4 = uStack_4c;
        }
      }
      uStack_1c = uVar4;
      uStack_20 = uStack_20 + 1;
      iVar7 = *param_1;
      aiStack_44[7] = aiStack_44[7] + 0x10;
    } while (uStack_20 < (uint)(param_1[1] - iVar7 >> 4));
  }
  if (param_1 != &iStack_5c) {
    *param_1 = iStack_5c;
    iVar1 = param_1[1];
    param_1[1] = iStack_58;
    iVar2 = param_1[2];
    param_1[2] = iStack_54;
    iStack_5c = iVar7;
    iStack_58 = iVar1;
    iStack_54 = iVar2;
  }
  FUN_0085bf50();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13166 ; VA 0x0085eb40 ; FUN_0085eb40 */

void __fastcall FUN_0085eb40(int *param_1)

{
  byte *pbVar1;
  int iVar2;
  char cVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  undefined4 *puVar9;
  int iStack_50;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  uint uStack_18;
  uint uStack_14;
  int iStack_10;
  int iStack_c;
  undefined uStack_5;
  
  if (*param_1 == param_1[1]) {
    iVar6 = 0x10;
  }
  else {
    iVar6 = ((param_1[1] - *param_1) / 0xc) * 2;
  }
  iStack_34 = param_1[4];
  iStack_30 = param_1[5];
  uStack_2c = 0;
  piStack_28 = param_1;
  FUN_00806e90(iVar6,&iStack_34,&uStack_5);
  iStack_40 = param_1[4];
  iVar6 = *param_1;
  iStack_3c = param_1[5];
  uStack_14 = 0;
  iStack_44 = 0;
  iVar8 = param_1[1] - iVar6 >> 0x1f;
  iStack_24 = iStack_40;
  iStack_20 = iStack_3c;
  if ((param_1[1] - iVar6) / 0xc + iVar8 != iVar8) {
    iStack_c = 0;
    do {
      iVar8 = iStack_c;
      iStack_10 = iVar6;
      cVar3 = FUN_0055c360(*(undefined4 *)(iStack_c + iVar6),*(undefined4 *)(iStack_c + 4 + iVar6),
                           param_1[4],param_1[5]);
      if (cVar3 == '\0') {
        uVar5 = *(uint *)(iVar8 + 4 + iVar6);
        uVar4 = 0;
        uStack_18 = (iStack_4c - iStack_50) / 0xc - 1;
        iStack_1c = *(int *)(iVar8 + iVar6);
        uVar7 = 0x811c9dc5;
        if (uVar5 != 0) {
          do {
            pbVar1 = (byte *)(iStack_1c + uVar4);
            uVar4 = uVar4 + 1;
            uVar7 = (*pbVar1 ^ uVar7) * 0x1000193;
          } while (uVar4 < uVar5);
        }
        uVar7 = uVar7 & uStack_18;
        uVar5 = 0;
        do {
          puVar9 = (undefined4 *)(iStack_50 + uVar7 * 0xc);
          cVar3 = FUN_0055c360(*puVar9,puVar9[1],iStack_24,iStack_20);
          if (cVar3 != '\0') {
            iStack_44 = iStack_44 + 1;
            *puVar9 = *(undefined4 *)(iStack_c + iStack_10);
            puVar9[1] = *(undefined4 *)(iStack_c + 4 + iStack_10);
            goto LAB_0085ecb9;
          }
          cVar3 = FUN_0055c360(*puVar9,puVar9[1],*(undefined4 *)(iStack_c + iStack_10),
                               *(undefined4 *)(iStack_c + 4 + iStack_10));
          if (cVar3 != '\0') goto LAB_0085ecb9;
          uVar7 = uVar7 + 1 + uVar5;
          uVar5 = uVar5 + 1;
          uVar7 = uVar7 & uStack_18;
        } while (uVar5 <= uStack_18);
        puVar9 = (undefined4 *)0x0;
LAB_0085ecb9:
        *puVar9 = *(undefined4 *)(iStack_c + iStack_10);
        puVar9[1] = *(undefined4 *)(iStack_c + 4 + iStack_10);
        puVar9[2] = *(undefined4 *)(iStack_c + 8 + iStack_10);
        iVar8 = iStack_c;
        param_1 = piStack_28;
      }
      iVar6 = *param_1;
      iStack_c = iVar8 + 0xc;
      uStack_14 = uStack_14 + 1;
      iStack_10 = iVar6;
    } while (uStack_14 < (uint)((param_1[1] - iVar6) / 0xc));
  }
  if (param_1 != &iStack_50) {
    *param_1 = iStack_50;
    iVar8 = param_1[1];
    param_1[1] = iStack_4c;
    iVar2 = param_1[2];
    param_1[2] = iStack_48;
    iStack_50 = iVar6;
    iStack_4c = iVar8;
    iStack_48 = iVar2;
  }
  FUN_00617ad0();
  return;
}



/* FUNCTION 13167 ; VA 0x0085ed40 ; FUN_0085ed40 */

void __fastcall FUN_0085ed40(int param_1)

{
  *(undefined *)(param_1 + 0x61) = 0;
  return;
}



/* FUNCTION 13168 ; VA 0x0085ed50 ; FUN_0085ed50 */

/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int ******* __thiscall FUN_0085ed50(int *******param_1,int ******param_2)

{
  int *piVar1;
  undefined8 uVar2;
  int *****pppppiVar3;
  int *****pppppiVar4;
  int *****pppppiVar5;
  int *****pppppiVar6;
  char cVar7;
  int iVar8;
  int *******pppppppiVar9;
  undefined4 uVar10;
  int *piVar11;
  int *******pppppppiVar12;
  int ******ppppppiVar13;
  float *pfVar14;
  float *pfVar15;
  int *******pppppppiVar16;
  int iVar17;
  int ******ppppppiVar18;
  uint uVar19;
  undefined4 uVar20;
  undefined auStack_148 [12];
  int aiStack_13c [5];
  uint uStack_128;
  int ******ppppppiStack_11c;
  int iStack_118;
  int *******pppppppiStack_114;
  undefined auStack_110 [4];
  int *piStack_10c;
  undefined auStack_108 [4];
  int *piStack_104;
  int *******pppppppiStack_100;
  int *******pppppppiStack_fc;
  int *****pppppiStack_f8;
  int *****pppppiStack_f4;
  int *****pppppiStack_f0;
  int *****pppppiStack_ec;
  int *****pppppiStack_e8;
  int *****pppppiStack_e4;
  int *****pppppiStack_e0;
  int *****pppppiStack_dc;
  int *****pppppiStack_d8;
  undefined8 uStack_d4;
  int ******ppppppiStack_cc;
  int *piStack_c8;
  int *piStack_c4;
  int *******pppppppiStack_c0;
  undefined uStack_bc;
  int *****pppppiStack_b8;
  int *****pppppiStack_b4;
  int *****pppppiStack_b0;
  int *****pppppiStack_ac;
  int *****pppppiStack_a8;
  int *****pppppiStack_a4;
  int *****pppppiStack_a0;
  int *****pppppiStack_9c;
  int *****pppppiStack_98;
  int *****pppppiStack_94;
  int *****pppppiStack_90;
  int ******ppppppiStack_8c;
  undefined4 uStack_88;
  int *******pppppppiStack_84;
  int *******pppppppiStack_80;
  int *******pppppppiStack_7c;
  int ******ppppppiStack_78;
  int *******pppppppiStack_74;
  int *****pppppiStack_70;
  int *****pppppiStack_6c;
  int *****pppppiStack_68;
  int *****pppppiStack_64;
  int *******pppppppiStack_60;
  int *******pppppppiStack_5c;
  int *******pppppppiStack_58;
  int *******pppppppiStack_54;
  int *******pppppppiStack_50;
  int *******pppppppiStack_4c;
  int *****pppppiStack_48;
  int *******pppppppiStack_44;
  int *******pppppppiStack_40;
  int *******pppppppiStack_3c;
  int iStack_38;
  int *******pppppppiStack_34;
  int *******pppppppiStack_30;
  int ******ppppppiStack_2c;
  int *******pppppppiStack_28;
  int *******pppppppiStack_24;
  int *******pppppppiStack_20;
  char cStack_19;
  int *******pppppppiStack_18;
  int *******pppppppiStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8607;
  if (*(char *)(param_1 + 0x18) != '\0') {
    return param_1;
  }
  ppppppiVar18 = param_1[0xd];
  pppppppiVar9 = param_1 + 0xc;
  pppppppiStack_34 = param_1;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  for (ppppppiVar13 = param_1[0xc]; pppppppiStack_20 = pppppppiVar9, ppppppiVar13 != ppppppiVar18;
      ppppppiVar13 = ppppppiVar13 + 1) {
    FUN_01679490();
    pppppppiVar9 = pppppppiStack_20;
  }
  FUN_00633350(*pppppppiVar9,pppppppiVar9[1],pppppppiVar9);
  pppppppiVar12 = pppppppiStack_34;
  pppppppiVar16 = pppppppiStack_34 + 3;
  pppppppiVar9[1] = *pppppppiVar9;
  pppppppiStack_4c = pppppppiVar16;
  FUN_007be660(*pppppppiVar16,pppppppiStack_34[4],pppppppiVar16);
  pppppppiVar9 = pppppppiStack_34;
  pppppppiVar12[4] = *pppppppiVar16;
  pppppppiStack_30 = pppppppiStack_34 + 0xf;
  pppppppiStack_34[0x10] = pppppppiStack_34[0xf];
  pppppppiStack_34[0x12] = (int ******)0x0;
  if (DAT_01eb4954 != '\0') {
    FUN_016774b0(DAT_01eb4954,"SkinningIsland::updateBones",0);
  }
  pppppppiStack_28 = (int *******)*pppppppiVar9;
  pppppppiStack_20 = (int *******)pppppppiVar9[1];
  if (pppppppiStack_28 != pppppppiStack_20) {
    do {
      ppppppiStack_78 = pppppppiStack_28[1];
      if (ppppppiStack_78 != (int ******)0x0) {
        LOCK();
        ppppppiStack_78[1] = (int *****)((int)ppppppiStack_78[1] + 1);
        UNLOCK();
        ppppppiStack_78 = pppppppiStack_28[1];
      }
      pppppppiStack_7c = (int *******)*pppppppiStack_28;
      ppppppiVar13 = pppppppiStack_7c[0xb];
      uStack_8 = 0;
      ppppppiStack_2c = ppppppiStack_78;
      if (ppppppiVar13 != (int ******)0x0) {
        pppppppiStack_24 = (int *******)ppppppiVar13[1];
        pppppppiStack_3c = (int *******)*ppppppiVar13;
        if (pppppppiStack_3c != pppppppiStack_24) {
          do {
            ppppppiVar13 = *pppppppiStack_3c;
            pppppiVar3 = ppppppiVar13[3];
            iVar8 = FUN_00d77b00();
            ppppppiVar18 = (int ******)0x0;
            if ((uint)*(ushort *)(pppppiVar3 + 0x76) - (uint)*(ushort *)(iVar8 + 0x1d8) <=
                (uint)*(ushort *)(iVar8 + 0x1da)) {
              ppppppiVar18 = ppppppiVar13;
            }
            if (ppppppiVar18 != (int ******)0x0) {
              FUN_0085e2f0(ppppppiVar18,0xffffffff);
            }
            pppppppiStack_3c = pppppppiStack_3c + 2;
          } while (pppppppiStack_3c != pppppppiStack_24);
        }
      }
      ppppppiVar13 = ppppppiStack_2c;
      uStack_8 = 0xffffffff;
      if (ppppppiStack_2c != (int ******)0x0) {
        LOCK();
        pppppiVar3 = (int *****)((int)ppppppiStack_2c[1] + -1);
        ppppppiStack_2c[1] = pppppiVar3;
        UNLOCK();
        if (pppppiVar3 == (int *****)0x0) {
          (*(code *)**ppppppiStack_2c)();
          LOCK();
          ppppppiVar18 = ppppppiVar13 + 2;
          pppppiVar3 = (int *****)((int)*ppppppiVar18 + -1);
          *ppppppiVar18 = pppppiVar3;
          UNLOCK();
          if (pppppiVar3 == (int *****)0x0) {
            (*(code *)(*ppppppiVar13)[1])();
          }
        }
      }
      pppppppiStack_28 = pppppppiStack_28 + 2;
    } while (pppppppiStack_28 != pppppppiStack_20);
    pppppppiStack_28 = (int *******)*pppppppiStack_34;
    pppppppiVar9 = pppppppiStack_34;
  }
  pppppppiStack_54 = (int *******)pppppppiVar9[1];
  if (pppppppiStack_28 != pppppppiStack_54) {
    do {
      pppppppiStack_fc = (int *******)pppppppiStack_28[1];
      if (pppppppiStack_fc != (int *******)0x0) {
        LOCK();
        pppppppiStack_fc[1] = (int ******)((int)pppppppiStack_fc[1] + 1);
        UNLOCK();
        pppppppiStack_fc = (int *******)pppppppiStack_28[1];
      }
      pppppppiVar9 = (int *******)*pppppppiStack_28;
      uStack_8 = 1;
      pppppppiStack_100 = pppppppiVar9;
      pppppppiStack_40 = pppppppiVar9;
      pppppppiStack_3c = pppppppiStack_fc;
      if (DAT_01eb4954 != '\0') {
        ppppppiVar13 = pppppppiVar9[10];
        if ((int *****)0xf < ppppppiVar13[5]) {
          ppppppiVar13 = (int ******)*ppppppiVar13;
        }
        FUN_01677650(DAT_01eb4954,"%s add part",ppppppiVar13);
      }
      ppppppiVar13 = pppppppiVar9[3];
      iVar8 = FUN_00cfb1a0();
      pppppppiVar9 = (int *******)(uint)*(ushort *)(iVar8 + 0x1da);
      pppppppiStack_24 = (int *******)0x0;
      if ((int *******)((uint)*(ushort *)(ppppppiVar13 + 0x76) - (uint)*(ushort *)(iVar8 + 0x1d8))
          <= pppppppiVar9) {
        pppppppiStack_24 = pppppppiStack_40;
      }
      if ((pppppppiStack_24 == (int *******)0x0) ||
         (cStack_19 = '\x01', *(char *)((int)pppppppiStack_24 + 0x191) == '\0')) {
        cStack_19 = '\0';
      }
      ppppppiVar13 = pppppppiStack_40[0x2c];
      if ((ppppppiVar13 != (int ******)0x0) && (ppppppiVar13 != param_2)) {
        pppppppiVar9 = (int *******)(*(code *)(*ppppppiVar13)[2])();
      }
      if (cStack_19 != '\0') {
        if (pppppppiStack_40 == (int *******)0x0) {
LAB_0085f86d:
          pppppppiVar12 = pppppppiStack_3c;
          if (pppppppiStack_3c == (int *******)0x0) {
            ExceptionList = pvStack_10;
            return pppppppiVar9;
          }
          LOCK();
          pppppppiVar9 = pppppppiStack_3c + 1;
          ppppppiVar13 = *pppppppiVar9;
          pppppppiVar16 = (int *******)*pppppppiVar9;
          *pppppppiVar9 = (int ******)((int)ppppppiVar13 + -1);
          UNLOCK();
          if ((int ******)((int)ppppppiVar13 + -1) != (int ******)0x0) {
            ExceptionList = pvStack_10;
            return pppppppiVar16;
          }
          pppppppiVar16 = (int *******)(*(code *)**pppppppiStack_3c)();
          LOCK();
          pppppppiVar9 = pppppppiVar12 + 2;
          ppppppiVar13 = *pppppppiVar9;
          *pppppppiVar9 = (int ******)((int)*pppppppiVar9 + -1);
          UNLOCK();
          if (ppppppiVar13 != (int ******)0x1) {
            ExceptionList = pvStack_10;
            return pppppppiVar16;
          }
          pppppppiVar9 = (int *******)(*(code *)(*pppppppiVar12)[1])();
          ExceptionList = pvStack_10;
          return pppppppiVar9;
        }
        pppppppiStack_18 = (int *******)pppppppiStack_40[0xd];
        pppppppiVar9 = pppppppiStack_40;
        if ((pppppppiStack_18 != (int *******)0x0) &&
           (pppppppiVar9 = pppppppiStack_18, pppppppiStack_18[0xd] != (int ******)0x0)) {
          pppppppiVar9 = (int *******)FUN_005c8ac0();
        }
        pppppppiStack_18 = pppppppiVar9;
        pppppppiVar9 = pppppppiStack_18;
        if (pppppppiStack_18 == (int *******)0x0) goto LAB_0085f86d;
        ppppppiVar13 = pppppppiStack_18[3];
        iVar8 = FUN_008a8c30();
        pppppppiVar9 = (int *******)(uint)*(ushort *)(iVar8 + 0x1da);
        if ((int *******)(uint)*(ushort *)(iVar8 + 0x1da) <
            (int *******)((uint)*(ushort *)(ppppppiVar13 + 0x76) - (uint)*(ushort *)(iVar8 + 0x1d8))
           ) goto LAB_0085f86d;
        FUN_005789c0(&DAT_01ea8c5c,&LAB_005c2460);
        uVar10 = FUN_005c36d0();
        pppppppiStack_14 = (int *******)FUN_008aa140(uVar10);
        if (*pppppppiStack_14 == (int ******)0x0) {
          uVar10 = FUN_008bd920();
          piVar11 = (int *)FUN_008a9ba0(auStack_108,uVar10);
          ppppppiVar13 = (int ******)*piVar11;
          ppppppiVar18 = (int ******)piVar11[1];
          *piVar11 = 0;
          piVar11[1] = 0;
          *pppppppiStack_14 = ppppppiVar13;
          ppppppiVar13 = pppppppiStack_14[1];
          pppppppiStack_14[1] = ppppppiVar18;
          if (ppppppiVar13 != (int ******)0x0) {
            LOCK();
            pppppiVar3 = (int *****)((int)ppppppiVar13[1] + -1);
            ppppppiVar13[1] = pppppiVar3;
            UNLOCK();
            if (pppppiVar3 == (int *****)0x0) {
              (*(code *)**ppppppiVar13)();
              LOCK();
              pppppiVar3 = (int *****)((int)ppppppiVar13[2] + -1);
              ppppppiVar13[2] = pppppiVar3;
              UNLOCK();
              if (pppppiVar3 == (int *****)0x0) {
                (*(code *)(*ppppppiVar13)[1])();
              }
            }
          }
          piVar11 = piStack_104;
          if (piStack_104 != (int *)0x0) {
            LOCK();
            iVar8 = piStack_104[1] + -1;
            piStack_104[1] = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)*piStack_104)();
              LOCK();
              piVar1 = piVar11 + 2;
              iVar8 = *piVar1 + -1;
              *piVar1 = iVar8;
              UNLOCK();
              if (iVar8 == 0) {
                (**(code **)(*piVar11 + 4))();
              }
            }
          }
        }
        pppppppiVar12 = (int *******)*pppppppiStack_14;
        pppppppiVar9 = pppppppiStack_14;
        if (pppppppiVar12 == (int *******)0x0) goto LAB_0085f86d;
        pppppppiStack_18 = (int *******)pppppppiVar12[0xd];
        if ((pppppppiStack_18 != (int *******)0x0) &&
           (pppppppiVar12 = pppppppiStack_18, pppppppiStack_18[0xd] != (int ******)0x0)) {
          pppppppiVar12 = (int *******)FUN_005c8ac0();
        }
        pppppppiStack_18 = pppppppiVar12;
        pppppppiVar9 = pppppppiStack_18;
        if (pppppppiStack_18 == (int *******)0x0) goto LAB_0085f86d;
        ppppppiVar13 = pppppppiStack_18[3];
        iVar8 = FUN_008a8c30();
        pppppppiVar9 = (int *******)(uint)*(ushort *)(iVar8 + 0x1da);
        if (pppppppiVar9 <
            (int *******)((uint)*(ushort *)(ppppppiVar13 + 0x76) - (uint)*(ushort *)(iVar8 + 0x1d8))
           ) goto LAB_0085f86d;
        FUN_005789c0(&DAT_01ea8c4c,&LAB_005c2490);
        uVar10 = FUN_005c3850();
        pppppppiStack_14 = (int *******)FUN_008aa140(uVar10);
        if (*pppppppiStack_14 == (int ******)0x0) {
          uVar10 = FUN_009de510();
          piVar11 = (int *)FUN_008a9ba0(auStack_110,uVar10);
          ppppppiVar13 = (int ******)*piVar11;
          ppppppiVar18 = (int ******)piVar11[1];
          *piVar11 = 0;
          piVar11[1] = 0;
          *pppppppiStack_14 = ppppppiVar13;
          ppppppiVar13 = pppppppiStack_14[1];
          pppppppiStack_14[1] = ppppppiVar18;
          if (ppppppiVar13 != (int ******)0x0) {
            LOCK();
            pppppiVar3 = (int *****)((int)ppppppiVar13[1] + -1);
            ppppppiVar13[1] = pppppiVar3;
            UNLOCK();
            if (pppppiVar3 == (int *****)0x0) {
              (*(code *)**ppppppiVar13)();
              LOCK();
              pppppiVar3 = (int *****)((int)ppppppiVar13[2] + -1);
              ppppppiVar13[2] = pppppiVar3;
              UNLOCK();
              if (pppppiVar3 == (int *****)0x0) {
                (*(code *)(*ppppppiVar13)[1])();
              }
            }
          }
          piVar11 = piStack_10c;
          if (piStack_10c != (int *)0x0) {
            LOCK();
            iVar8 = piStack_10c[1] + -1;
            piStack_10c[1] = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)*piStack_10c)();
              LOCK();
              piVar1 = piVar11 + 2;
              iVar8 = *piVar1 + -1;
              *piVar1 = iVar8;
              UNLOCK();
              if (iVar8 == 0) {
                (**(code **)(*piVar11 + 4))();
              }
            }
          }
        }
        pppppppiVar9 = (int *******)*pppppppiStack_14;
        pppppppiStack_20 = pppppppiVar9;
        if (pppppppiVar9 == (int *******)0x0) goto LAB_0085f86d;
        FUN_0054ef60(pppppppiStack_24 + 0x55);
        uStack_8._0_1_ = 2;
        pppppiStack_64 = (int *****)0x0;
        pppppppiStack_60 = (int *******)0x0;
        ppppppiStack_2c = pppppppiStack_40[10];
        pppppiStack_48 = ppppppiStack_2c[4];
        if ((int *****)0xf < ppppppiStack_2c[5]) {
          ppppppiStack_2c = (int ******)*ppppppiStack_2c;
        }
        if (pppppiStack_48 < (int *****)0x10) {
          pppppppiStack_74 = (int *******)*ppppppiStack_2c;
          pppppiStack_70 = ppppppiStack_2c[1];
          pppppiStack_6c = ppppppiStack_2c[2];
          pppppiStack_68 = ppppppiStack_2c[3];
          pppppppiStack_18 = (int *******)&DAT_0000000f;
          pppppppiStack_14 = pppppppiStack_74;
        }
        else {
          pppppppiStack_18 = (int *******)((uint)pppppiStack_48 | 0xf);
          if ((int *******)0x7fffffff < pppppppiStack_18) {
            pppppppiStack_18 = (int *******)0x7fffffff;
          }
          pppppppiVar9 = (int *******)((int)pppppppiStack_18 + 1);
          if (pppppppiVar9 < &DAT_00001000) {
            if (pppppppiVar9 == (int *******)0x0) {
              pppppppiStack_74 = (int *******)0x0;
            }
            else {
              pppppppiStack_74 = (int *******)FUN_01674e20(pppppppiVar9);
            }
          }
          else {
            pppppppiVar12 = pppppppiStack_18 + 9;
            if (pppppppiVar12 <= pppppppiVar9) {
              pppppppiVar12 = (int *******)0xffffffff;
            }
            ppppppiVar13 = (int ******)FUN_01674e20(pppppppiVar12);
            if (ppppppiVar13 == (int ******)0x0) goto LAB_0085fa48;
            pppppppiStack_74 = (int *******)((int)ppppppiVar13 + 0x23U & 0xffffffe0);
            pppppppiStack_74[-1] = ppppppiVar13;
          }
          pppppppiStack_14 = pppppppiStack_74;
          FUN_0170c6f0(pppppppiStack_74,ppppppiStack_2c,(int)pppppiStack_48 + 1);
        }
        pppppppiVar9 = (int *******)&pppppppiStack_50;
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        uVar20 = 0;
        pppppiStack_64 = pppppiStack_48;
        pppppppiStack_60 = pppppppiStack_18;
        uVar10 = FUN_008ccd50(0,pppppppiVar9);
        piVar11 = (int *)FUN_009dd5a0(&pppppppiStack_84,aiStack_13c,0x41a00000,uVar10,uVar20,
                                      pppppppiVar9);
        pppppppiVar9 = pppppppiStack_80;
        pppppppiStack_114 = (int *******)piVar11[1];
        iStack_118 = *piVar11;
        if (pppppppiStack_114 != (int *******)0x0) {
          LOCK();
          pppppppiStack_114[1] = (int ******)((int)pppppppiStack_114[1] + 1);
          UNLOCK();
          pppppppiStack_114 = (int *******)piVar11[1];
        }
        iStack_38 = iStack_118;
        pppppppiStack_24 = pppppppiStack_114;
        if (pppppppiStack_80 != (int *******)0x0) {
          LOCK();
          ppppppiVar13 = (int ******)((int)pppppppiStack_80[1] + -1);
          pppppppiStack_80[1] = ppppppiVar13;
          UNLOCK();
          if (ppppppiVar13 == (int ******)0x0) {
            (*(code *)**pppppppiStack_80)();
            LOCK();
            pppppppiVar12 = pppppppiVar9 + 2;
            ppppppiVar13 = (int ******)((int)*pppppppiVar12 + -1);
            *pppppppiVar12 = ppppppiVar13;
            UNLOCK();
            if (ppppppiVar13 == (int ******)0x0) {
              (*(code *)(*pppppppiVar9)[1])();
            }
          }
        }
        if ((pppppppiStack_50 == (int *******)0x1) && (iStack_38 != 0)) {
          ppppppiStack_2c = *(int *******)(iStack_38 + 0x30);
          pppppppiStack_44 =
               (int *******)((*(int *)(iStack_38 + 0x34) - (int)ppppppiStack_2c) / 0x3c);
          if ((pppppppiStack_44 != (int *******)0x0) &&
             (pppppppiStack_20 = (int *******)0x0, pppppppiStack_44 != (int *******)0x0)) {
            iStack_38 = *(int *)(iStack_38 + 0x3c);
            do {
              pppppppiVar9 = (int *******)((int)*ppppppiStack_2c + iStack_38);
              pppppppiStack_58 = pppppppiVar9;
              do {
                cVar7 = *(char *)pppppppiStack_58;
                pppppppiStack_58 = (int *******)((int)pppppppiStack_58 + 1);
              } while (cVar7 != '\0');
              pppppppiStack_58 = (int *******)((int)pppppppiStack_58 - (int)((int)pppppppiVar9 + 1))
              ;
              pppppppiStack_5c = pppppppiVar9;
              iVar8 = FUN_0085e210(&pppppppiStack_5c);
              piVar11 = (int *)(-(uint)(iVar8 != 0) & iVar8 + 8U);
              pppppppiVar12 = pppppppiVar9;
              do {
                cVar7 = *(char *)pppppppiVar12;
                pppppppiVar12 = (int *******)((int)pppppppiVar12 + 1);
              } while (cVar7 != '\0');
              pppppppiVar16 = (int *******)&pppppppiStack_74;
              if (&DAT_0000000f < pppppppiStack_18) {
                pppppppiVar16 = pppppppiStack_14;
              }
              cVar7 = FUN_0055c360(pppppppiVar16,pppppiStack_48,pppppppiVar9,
                                   (int)pppppppiVar12 - (int)((int)pppppppiVar9 + 1));
              if (cVar7 != '\0') {
                if (piVar11 == (int *)0x0) {
                  pppppiStack_b8 = _DAT_018e3fb0;
                  pppppiStack_b4 = _UNK_018e3fb4;
                  pppppiStack_b0 = _UNK_018e3fb8;
                  pppppiStack_ac = _UNK_018e3fbc;
                  pppppiStack_a8 = _DAT_018e3fb0;
                  pppppiStack_a4 = _UNK_018e3fb4;
                  pppppiStack_a0 = _UNK_018e3fb8;
                  pppppiStack_9c = _UNK_018e3fbc;
                  pppppiStack_98 = _DAT_018e3fb0;
                  pppppiStack_94 = _UNK_018e3fb4;
                  pppppiStack_90 = _UNK_018e3fb8;
                  ppppppiStack_8c = (int ******)_UNK_018e3fbc;
                  uStack_8 = CONCAT31(uStack_8._1_3_,5);
                  pppppppiStack_c0 = pppppppiStack_40;
                  uStack_bc = 1;
                  uStack_88 = 0xffffffff;
                  piStack_c8 = piVar11;
                  piStack_c4 = piVar11;
                  FUN_01151b50(&pppppiStack_f8,ppppppiStack_2c + 3);
                  FUN_00cfb1a0();
                  pfVar14 = (float *)FUN_00b08320();
                  pfVar15 = (float *)FUN_0074adf0(auStack_148);
                  pppppppiVar9 = pppppppiStack_4c;
                  pppppiStack_94 = (int *****)((*pfVar14 / *pfVar15) * (float)(int *****)uStack_d4);
                  pppppiStack_90 = (int *****)((pfVar14[1] / pfVar15[1]) * (float)uStack_d4._4_4_);
                  ppppppiStack_11c =
                       (int ******)((pfVar14[2] / pfVar15[2]) * (float)ppppppiStack_cc);
                  ppppppiVar13 = pppppppiStack_4c[1];
                  uStack_d4 = CONCAT44(pppppiStack_90,pppppiStack_94);
                  pppppiStack_b8 = pppppiStack_f8;
                  pppppiStack_b4 = pppppiStack_f4;
                  pppppiStack_b0 = pppppiStack_f0;
                  pppppiStack_ac = pppppiStack_ec;
                  pppppiStack_a8 = pppppiStack_e8;
                  pppppiStack_a4 = pppppiStack_e4;
                  pppppiStack_a0 = pppppiStack_e0;
                  pppppiStack_9c = pppppiStack_dc;
                  pppppiStack_98 = pppppiStack_d8;
                  ppppppiStack_cc = ppppppiStack_11c;
                  ppppppiStack_8c = ppppppiStack_11c;
                  if (pppppppiStack_4c[2] == ppppppiVar13) {
                    FUN_0085b500(ppppppiVar13,&piStack_c8);
                  }
                  else {
                    *ppppppiVar13 = (int *****)0x0;
                    ppppppiVar13[1] = (int *****)0x0;
                    ppppppiVar13[4] = pppppiStack_f8;
                    ppppppiVar13[5] = pppppiStack_f4;
                    ppppppiVar13[6] = pppppiStack_f0;
                    ppppppiVar13[7] = pppppiStack_ec;
                    ppppppiVar13[2] = (int *****)pppppppiStack_40;
                    ppppppiVar13[8] = pppppiStack_e8;
                    ppppppiVar13[9] = pppppiStack_e4;
                    ppppppiVar13[10] = pppppiStack_e0;
                    ppppppiVar13[0xb] = pppppiStack_dc;
                    *(undefined *)(ppppppiVar13 + 3) = 1;
                    ppppppiVar13[0xc] = pppppiStack_d8;
                    ppppppiVar13[0xd] = pppppiStack_94;
                    ppppppiVar13[0xe] = pppppiStack_90;
                    ppppppiVar13[0xf] = (int *****)ppppppiStack_11c;
                    ppppppiVar13[0x10] = (int *****)0xffffffff;
                    pppppppiStack_4c[1] = pppppppiStack_4c[1] + 0x11;
                  }
                  pppppppiVar12 = pppppppiStack_5c;
                  pppppppiStack_7c = pppppppiStack_5c;
                  pppppppiStack_44 =
                       (int *******)(((int)pppppppiVar9[1] - (int)*pppppppiVar9) / 0x44 + -1);
                  pppppppiVar9 = pppppppiStack_5c;
                  do {
                    cVar7 = *(char *)pppppppiVar9;
                    pppppppiVar9 = (int *******)((int)pppppppiVar9 + 1);
                  } while (cVar7 != '\0');
                  ppppppiStack_78 =
                       (int ******)((int)pppppppiVar9 - (int)((int)pppppppiStack_5c + 1));
                  if ((int ******)
                      ((uint)((((int)pppppppiStack_30[1] - (int)*pppppppiStack_30) / 0xc) * 3) >> 2)
                      <= pppppppiStack_30[3]) {
                    FUN_0085eb40();
                  }
                  iVar8 = FUN_0085e8b0(&pppppppiStack_7c);
                  *(int ********)(iVar8 + 8) = pppppppiStack_44;
                  if (DAT_01eb4954 != '\0') {
                    FUN_01677520(DAT_01eb4954,"    %s %d primary bone",pppppppiVar12,
                                 pppppppiStack_44);
                  }
                  piVar11 = piStack_c4;
                  if (piStack_c4 != (int *)0x0) {
                    LOCK();
                    iVar8 = piStack_c4[1] + -1;
                    piStack_c4[1] = iVar8;
                    UNLOCK();
                    if (iVar8 == 0) {
                      (**(code **)*piStack_c4)();
                      LOCK();
                      piVar1 = piVar11 + 2;
                      iVar8 = *piVar1 + -1;
                      *piVar1 = iVar8;
                      UNLOCK();
                      if (iVar8 == 0) {
                        (**(code **)(*piVar11 + 4))();
                      }
                    }
                  }
                }
                break;
              }
              pppppppiStack_20 = (int *******)((int)pppppppiStack_20 + 1);
              ppppppiStack_2c = ppppppiStack_2c + 0xf;
            } while (pppppppiStack_20 < pppppppiStack_44);
          }
        }
        pppppppiVar9 = pppppppiStack_24;
        if (pppppppiStack_24 != (int *******)0x0) {
          LOCK();
          ppppppiVar13 = (int ******)((int)pppppppiStack_24[1] + -1);
          pppppppiStack_24[1] = ppppppiVar13;
          UNLOCK();
          if (ppppppiVar13 == (int ******)0x0) {
            (*(code *)**pppppppiStack_24)();
            LOCK();
            pppppppiVar12 = pppppppiVar9 + 2;
            ppppppiVar13 = (int ******)((int)*pppppppiVar12 + -1);
            *pppppppiVar12 = ppppppiVar13;
            UNLOCK();
            if (ppppppiVar13 == (int ******)0x0) {
              (*(code *)(*pppppppiVar9)[1])();
            }
          }
        }
        uStack_8._0_1_ = 2;
        if (&DAT_0000000f < pppppppiStack_18) {
          pppppppiVar9 = (int *******)((int)pppppppiStack_18 + 1);
          pppppppiVar12 = pppppppiStack_14;
          if ((int *******)0xfff < pppppppiVar9) {
            pppppppiVar12 = (int *******)pppppppiStack_14[-1];
            pppppppiVar9 = pppppppiStack_18 + 9;
            if ((char *)0x1f < (char *)((int)pppppppiStack_14 + (-4 - (int)pppppppiVar12)))
            goto LAB_0085fa48;
          }
          FUN_01674ea0(pppppppiVar12,pppppppiVar9);
        }
        uStack_8._0_1_ = 1;
        if (0xf < uStack_128) {
          uVar19 = uStack_128 + 1;
          iVar8 = aiStack_13c[0];
          if (0xfff < uVar19) {
            iVar8 = *(int *)(aiStack_13c[0] + -4);
            uVar19 = uStack_128 + 0x24;
            if (0x1f < (aiStack_13c[0] - iVar8) - 4U) goto LAB_0085fa48;
          }
          FUN_01674ea0(iVar8,uVar19);
        }
      }
      pppppppiVar9 = pppppppiStack_3c;
      uStack_8 = 0xffffffff;
      if (pppppppiStack_3c != (int *******)0x0) {
        LOCK();
        ppppppiVar13 = (int ******)((int)pppppppiStack_3c[1] + -1);
        pppppppiStack_3c[1] = ppppppiVar13;
        UNLOCK();
        if (ppppppiVar13 == (int ******)0x0) {
          (*(code *)**pppppppiStack_3c)();
          LOCK();
          pppppppiVar12 = pppppppiVar9 + 2;
          ppppppiVar13 = (int ******)((int)*pppppppiVar12 + -1);
          *pppppppiVar12 = ppppppiVar13;
          UNLOCK();
          if (ppppppiVar13 == (int ******)0x0) {
            (*(code *)(*pppppppiVar9)[1])();
          }
        }
      }
      pppppppiStack_28 = pppppppiStack_28 + 2;
    } while (pppppppiStack_28 != pppppppiStack_54);
    pppppppiStack_28 = (int *******)*pppppppiStack_34;
    pppppppiVar9 = pppppppiStack_34;
  }
  pppppppiStack_50 = (int *******)pppppppiVar9[1];
  if (pppppppiStack_28 != pppppppiStack_50) {
    do {
      pppppppiStack_80 = (int *******)pppppppiStack_28[1];
      if (pppppppiStack_80 != (int *******)0x0) {
        LOCK();
        pppppppiStack_80[1] = (int ******)((int)pppppppiStack_80[1] + 1);
        UNLOCK();
        pppppppiStack_80 = (int *******)pppppppiStack_28[1];
      }
      pppppppiVar9 = (int *******)*pppppppiStack_28;
      ppppppiVar13 = pppppppiVar9[3];
      uStack_8 = 6;
      pppppppiStack_84 = pppppppiVar9;
      pppppppiStack_20 = pppppppiStack_80;
      iVar8 = FUN_00cfb1a0();
      pppppppiStack_54 = (int *******)0x0;
      if ((uint)*(ushort *)(ppppppiVar13 + 0x76) - (uint)*(ushort *)(iVar8 + 0x1d8) <=
          (uint)*(ushort *)(iVar8 + 0x1da)) {
        pppppppiStack_54 = pppppppiVar9;
      }
      if (((pppppppiStack_54 != (int *******)0x0) && (DAT_01d6c7b4 != '\0')) &&
         (*(char *)(pppppppiStack_54 + 100) != '\0')) {
        pppppppiStack_5c = (int *******)pppppppiStack_54[10];
        pppppppiStack_58 = (int *******)pppppppiStack_5c[4];
        if ((int ******)0xf < pppppppiStack_5c[5]) {
          pppppppiStack_5c = (int *******)*pppppppiStack_5c;
        }
        pppppppiStack_44 = pppppppiStack_58;
        pppppppiStack_24 = pppppppiStack_5c;
        iVar8 = FUN_0085e210(&pppppppiStack_5c);
        pppppiVar6 = _UNK_018e3fbc;
        pppppiVar5 = _UNK_018e3fb8;
        pppppiVar4 = _UNK_018e3fb4;
        pppppiVar3 = _DAT_018e3fb0;
        if ((iVar8 + 8U & -(uint)(iVar8 != 0)) == 0) {
          piStack_c8 = (int *)0x0;
          piStack_c4 = (int *)0x0;
          uVar2 = *(undefined8 *)(pppppppiStack_54 + 0x61);
          ppppppiStack_cc = pppppppiStack_54[99];
          ppppppiVar13 = pppppppiStack_4c[1];
          pppppiStack_d8 = (int *****)0x3f800000;
          uStack_d4._0_4_ = (int *****)uVar2;
          uStack_d4._4_4_ = (int *****)((ulonglong)uVar2 >> 0x20);
          uStack_8._0_1_ = 7;
          uStack_bc = 1;
          uStack_88 = 0xffffffff;
          pppppiStack_b8 = _DAT_018e3fb0;
          pppppiStack_b4 = _UNK_018e3fb4;
          pppppiStack_b0 = _UNK_018e3fb8;
          pppppiStack_ac = _UNK_018e3fbc;
          pppppiStack_a8 = _DAT_018e3fb0;
          pppppiStack_a4 = _UNK_018e3fb4;
          pppppiStack_a0 = _UNK_018e3fb8;
          pppppiStack_9c = _UNK_018e3fbc;
          pppppiStack_98 = (int *****)0x3f800000;
          pppppiStack_94 = (int *****)uStack_d4;
          pppppiStack_90 = uStack_d4._4_4_;
          uStack_d4 = uVar2;
          pppppppiStack_c0 = pppppppiVar9;
          ppppppiStack_8c = ppppppiStack_cc;
          if (pppppppiStack_4c[2] == ppppppiVar13) {
            FUN_0085b500(ppppppiVar13,&piStack_c8);
          }
          else {
            *ppppppiVar13 = (int *****)0x0;
            ppppppiVar13[1] = (int *****)0x0;
            ppppppiVar13[4] = pppppiVar3;
            ppppppiVar13[5] = pppppiVar4;
            ppppppiVar13[6] = pppppiVar5;
            ppppppiVar13[7] = pppppiVar6;
            ppppppiVar13[2] = (int *****)pppppppiVar9;
            ppppppiVar13[8] = pppppiVar3;
            ppppppiVar13[9] = pppppiVar4;
            ppppppiVar13[10] = pppppiVar5;
            ppppppiVar13[0xb] = pppppiVar6;
            *(undefined *)(ppppppiVar13 + 3) = 1;
            ppppppiVar13[0xc] = (int *****)0x3f800000;
            ppppppiVar13[0xd] = (int *****)uStack_d4;
            ppppppiVar13[0xe] = uStack_d4._4_4_;
            ppppppiVar13[0xf] = (int *****)ppppppiStack_cc;
            ppppppiVar13[0x10] = (int *****)0xffffffff;
            pppppppiStack_4c[1] = pppppppiStack_4c[1] + 0x11;
          }
          piVar11 = piStack_c4;
          iVar8 = ((int)pppppppiStack_4c[1] - (int)*pppppppiStack_4c) / 0x44 + -1;
          if ((int ******)
              ((uint)((((int)pppppppiStack_30[1] - (int)*pppppppiStack_30) / 0xc) * 3) >> 2) <=
              pppppppiStack_30[3]) {
            FUN_0085eb40();
          }
          iVar17 = FUN_0085e8b0(&pppppppiStack_5c);
          *(int *)(iVar17 + 8) = iVar8;
          if (DAT_01eb4954 != '\0') {
            pppppiStack_64 = (int *****)0x0;
            pppppppiStack_60 = (int *******)&DAT_0000000f;
            pppppppiStack_74 = (int *******)((uint)pppppppiStack_74 & 0xffffff00);
            FUN_005542c0(pppppppiStack_24,pppppppiStack_44);
            pppppppiVar9 = (int *******)&pppppppiStack_74;
            if (&DAT_0000000f < pppppppiStack_60) {
              pppppppiVar9 = pppppppiStack_74;
            }
            uStack_8._0_1_ = 8;
            FUN_01677520(DAT_01eb4954,"    %s %d rigid bone",pppppppiVar9,iVar8);
            uStack_8._0_1_ = 7;
            if (&DAT_0000000f < pppppppiStack_60) {
              pppppppiVar12 = (int *******)((int)pppppppiStack_60 + 1);
              pppppppiVar9 = pppppppiStack_74;
              if ((int *******)0xfff < pppppppiVar12) {
                pppppppiVar9 = (int *******)pppppppiStack_74[-1];
                pppppppiVar12 = pppppppiStack_60 + 9;
                if ((char *)0x1f < (char *)((int)pppppppiStack_74 + (-4 - (int)pppppppiVar9))) {
LAB_0085fa48:
                    /* WARNING: Subroutine does not return */
                  FUN_017167a3();
                }
              }
              FUN_01674ea0(pppppppiVar9,pppppppiVar12);
            }
          }
          if (piVar11 != (int *)0x0) {
            LOCK();
            iVar8 = piVar11[1] + -1;
            piVar11[1] = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)*piVar11)();
              LOCK();
              iVar8 = piVar11[2] + -1;
              piVar11[2] = iVar8;
              UNLOCK();
              if (iVar8 == 0) {
                (**(code **)(*piVar11 + 4))();
              }
            }
          }
        }
      }
      pppppppiVar9 = pppppppiStack_20;
      uStack_8 = 0xffffffff;
      if (pppppppiStack_20 != (int *******)0x0) {
        LOCK();
        ppppppiVar13 = (int ******)((int)pppppppiStack_20[1] + -1);
        pppppppiStack_20[1] = ppppppiVar13;
        UNLOCK();
        if (ppppppiVar13 == (int ******)0x0) {
          (*(code *)**pppppppiStack_20)();
          LOCK();
          pppppppiVar12 = pppppppiVar9 + 2;
          ppppppiVar13 = (int ******)((int)*pppppppiVar12 + -1);
          *pppppppiVar12 = ppppppiVar13;
          UNLOCK();
          if (ppppppiVar13 == (int ******)0x0) {
            (*(code *)(*pppppppiVar9)[1])();
          }
        }
      }
      pppppppiStack_28 = pppppppiStack_28 + 2;
      pppppppiVar9 = pppppppiStack_34;
    } while (pppppppiStack_28 != pppppppiStack_50);
  }
  pppppppiVar12 =
       (int *******)
       FUN_00843570(((int)pppppppiVar9[4] - (int)pppppppiVar9[3]) / 0x44,pppppppiVar9 + 6);
  *(undefined *)(pppppppiVar9 + 0x18) = 1;
  ExceptionList = pvStack_10;
  return pppppppiVar12;
}



/* FUNCTION 13169 ; VA 0x0085fa50 ; FUN_0085fa50 */

void __fastcall FUN_0085fa50(int param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  float *pfVar5;
  undefined4 *puVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  undefined auStack_f4 [48];
  undefined auStack_c4 [32];
  float fStack_a4;
  undefined8 uStack_a0;
  float fStack_98;
  float fStack_94;
  float fStack_90;
  float fStack_8c;
  float fStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  float fStack_5c;
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  undefined8 uStack_28;
  float fStack_20;
  ulonglong uStack_1c;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  float fStack_8;
  
  iStack_14 = param_1;
  iStack_10 = (*(int *)(param_1 + 0x10) - *(int *)(param_1 + 0xc)) / 0x44;
  if (iStack_10 != 0) {
    iVar7 = 0;
    iVar9 = 0;
    do {
      iStack_c = *(int *)(iStack_14 + 0x18);
      iVar8 = *(int *)(iStack_14 + 0xc) + iVar7;
      if (*(char *)(iVar8 + 0xc) == '\0') {
        iVar8 = *(int *)(iVar8 + 0x40);
        if (iVar8 == -1) {
          pfVar5 = (float *)FUN_00d6ca70(auStack_c4);
        }
        else {
          pfVar5 = (float *)(iStack_c + iVar8 * 0x30);
          fStack_94 = *pfVar5;
          fStack_90 = pfVar5[1];
          fStack_8c = pfVar5[2];
          fStack_88 = pfVar5[3];
          puVar1 = (undefined4 *)(iStack_c + 0x10 + iVar8 * 0x30);
          uStack_84 = *puVar1;
          uStack_80 = puVar1[1];
          uStack_7c = puVar1[2];
          uStack_78 = puVar1[3];
          puVar1 = (undefined4 *)(iStack_c + 0x20 + iVar8 * 0x30);
          pfVar5 = &fStack_94;
          uStack_74 = *puVar1;
          uStack_70 = puVar1[1];
          uStack_6c = puVar1[2];
          uStack_68 = puVar1[3];
        }
        fStack_4c = *pfVar5;
        fStack_48 = pfVar5[1];
        fStack_44 = pfVar5[2];
        fStack_40 = pfVar5[3];
        fStack_3c = pfVar5[4];
        fStack_38 = pfVar5[5];
        fStack_34 = pfVar5[6];
        fStack_30 = pfVar5[7];
        fStack_2c = pfVar5[8];
        uStack_28 = *(undefined8 *)(pfVar5 + 9);
        fStack_20 = pfVar5[0xb];
        iVar8 = FUN_00d78160(auStack_f4);
        fVar10 = *(float *)(iVar8 + 0x28);
        fVar12 = *(float *)(iVar8 + 0x24);
        fVar11 = *(float *)(iVar8 + 0x2c);
        uStack_1c = (ulonglong)
                    (uint)(fVar12 * fStack_4c + fVar10 * fStack_48 + fVar11 * fStack_44 +
                          (float)uStack_28);
        fStack_8 = fVar12 * fStack_40 + fVar10 * fStack_3c + fVar11 * fStack_38 + uStack_28._4_4_;
        fStack_5c = fVar12 * fStack_34 + fVar10 * fStack_30 + fVar11 * fStack_2c + fStack_20;
        puVar6 = (undefined4 *)FUN_01160c20(&fStack_88,iVar8);
        fVar11 = (float)uStack_1c;
        uStack_a0 = CONCAT44(fStack_8,fVar11);
        uVar2 = puVar6[1];
        uVar3 = puVar6[2];
        uVar4 = puVar6[3];
        uVar13 = puVar6[4];
        uVar14 = puVar6[5];
        uVar15 = puVar6[6];
        uVar16 = puVar6[7];
        fVar10 = (float)puVar6[8];
        fStack_98 = fStack_5c;
        puVar1 = (undefined4 *)(iVar9 + iStack_c);
        *puVar1 = *puVar6;
        puVar1[1] = uVar2;
        puVar1[2] = uVar3;
        puVar1[3] = uVar4;
        fVar12 = fStack_5c;
        fStack_a4 = fVar10;
      }
      else {
        pfVar5 = (float *)FUN_00b077e0();
        fVar10 = *(float *)(iVar8 + 0x34);
        fVar12 = *(float *)(iVar8 + 0x38);
        fVar11 = *(float *)(iVar8 + 0x3c);
        uStack_1c = (ulonglong)
                    (uint)(pfVar5[1] * fVar12 + fVar10 * *pfVar5 + pfVar5[2] * fVar11 + pfVar5[9]);
        fStack_8 = pfVar5[3] * fVar10 + pfVar5[4] * fVar12 + pfVar5[5] * fVar11 + pfVar5[10];
        fStack_50 = pfVar5[6] * fVar10 + pfVar5[7] * fVar12 + pfVar5[8] * fVar11 + pfVar5[0xb];
        puVar6 = (undefined4 *)FUN_01160c20(&fStack_88,iVar8 + 0x10);
        fVar11 = (float)uStack_1c;
        uVar2 = puVar6[1];
        uVar3 = puVar6[2];
        uVar4 = puVar6[3];
        uVar13 = puVar6[4];
        uVar14 = puVar6[5];
        uVar15 = puVar6[6];
        uVar16 = puVar6[7];
        fVar10 = (float)puVar6[8];
        fStack_2c = fVar10;
        fStack_20 = fStack_50;
        uStack_28 = CONCAT44(fStack_8,fVar11);
        puVar1 = (undefined4 *)(iVar9 + iStack_c);
        *puVar1 = *puVar6;
        puVar1[1] = uVar2;
        puVar1[2] = uVar3;
        puVar1[3] = uVar4;
        fVar12 = fStack_50;
      }
      iVar7 = iVar7 + 0x44;
      puVar1 = (undefined4 *)(iVar9 + 0x10 + iStack_c);
      *puVar1 = uVar13;
      puVar1[1] = uVar14;
      puVar1[2] = uVar15;
      puVar1[3] = uVar16;
      pfVar5 = (float *)(iVar9 + 0x20 + iStack_c);
      *pfVar5 = fVar10;
      pfVar5[1] = fVar11;
      pfVar5[2] = fStack_8;
      pfVar5[3] = fVar12;
      iVar9 = iVar9 + 0x30;
      iStack_10 = iStack_10 + -1;
    } while (iStack_10 != 0);
  }
  return;
}



/* FUNCTION 13170 ; VA 0x0085fce0 ; FUN_0085fce0 */

int __thiscall FUN_0085fce0(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  undefined4 *puVar11;
  uint uVar12;
  undefined4 *puVar13;
  int iVar14;
  
  iVar2 = ((int)param_2 - *param_1) / 0x28;
  iVar3 = (param_1[1] - *param_1) / 0x28;
  if (iVar3 == 0x6666666) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar12 = iVar3 + 1;
  uVar9 = (param_1[2] - *param_1) / 0x28;
  uVar8 = uVar12;
  if ((uVar9 <= 0x6666666 - (uVar9 >> 1)) && (uVar8 = (uVar9 >> 1) + uVar9, uVar8 < uVar12)) {
    uVar8 = uVar12;
  }
  uVar12 = uVar8 * 0x28;
  if (uVar8 < 0x6666667) {
    if (0xfff < uVar12) goto LAB_0085fd7b;
    if (uVar12 == 0) {
      puVar13 = (undefined4 *)0x0;
    }
    else {
      puVar13 = (undefined4 *)FUN_01674e20(uVar12);
    }
  }
  else {
    uVar12 = 0xffffffff;
LAB_0085fd7b:
    uVar9 = uVar12 + 0x23;
    if (uVar9 <= uVar12) {
      uVar9 = 0xffffffff;
    }
    iVar10 = FUN_01674e20(uVar9);
    if (iVar10 == 0) goto LAB_0085fea0;
    puVar13 = (undefined4 *)(iVar10 + 0x23U & 0xffffffe0);
    puVar13[-1] = iVar10;
  }
  uVar4 = param_3[1];
  uVar5 = param_3[2];
  uVar6 = param_3[3];
  puVar1 = puVar13 + iVar2 * 10;
  *puVar1 = *param_3;
  puVar1[1] = uVar4;
  puVar1[2] = uVar5;
  puVar1[3] = uVar6;
  uVar4 = param_3[5];
  uVar5 = param_3[6];
  uVar6 = param_3[7];
  puVar1 = puVar13 + iVar2 * 10 + 4;
  *puVar1 = param_3[4];
  puVar1[1] = uVar4;
  puVar1[2] = uVar5;
  puVar1[3] = uVar6;
  *(undefined8 *)(puVar13 + iVar2 * 10 + 8) = *(undefined8 *)(param_3 + 8);
  puVar1 = (undefined4 *)param_1[1];
  puVar11 = (undefined4 *)*param_1;
  puVar7 = puVar13;
  if (param_2 == puVar1) {
    for (; puVar11 != puVar1; puVar11 = puVar11 + 10) {
      uVar4 = puVar11[1];
      uVar5 = puVar11[2];
      uVar6 = puVar11[3];
      *puVar7 = *puVar11;
      puVar7[1] = uVar4;
      puVar7[2] = uVar5;
      puVar7[3] = uVar6;
      uVar4 = puVar11[5];
      uVar5 = puVar11[6];
      uVar6 = puVar11[7];
      puVar7[4] = puVar11[4];
      puVar7[5] = uVar4;
      puVar7[6] = uVar5;
      puVar7[7] = uVar6;
      *(undefined8 *)(puVar7 + 8) = *(undefined8 *)(puVar11 + 8);
      puVar7 = puVar7 + 10;
    }
  }
  else {
    FUN_00860350(puVar11,param_2,puVar13);
    FUN_00860350(param_2,param_1[1],puVar13 + iVar2 * 10 + 10);
  }
  iVar10 = *param_1;
  if (iVar10 != 0) {
    uVar12 = ((param_1[2] - iVar10) / 0x28) * 0x28;
    iVar14 = iVar10;
    if (0xfff < uVar12) {
      iVar14 = *(int *)(iVar10 + -4);
      uVar12 = uVar12 + 0x23;
      if (0x1f < (iVar10 - iVar14) - 4U) {
LAB_0085fea0:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar14,uVar12);
  }
  *param_1 = (int)puVar13;
  param_1[1] = (int)(puVar13 + (iVar3 * 5 + 5) * 2);
  param_1[2] = (int)(puVar13 + uVar8 * 10);
  return *param_1 + iVar2 * 0x28;
}



/* FUNCTION 13171 ; VA 0x0085feb0 ; FUN_0085feb0 */

int FUN_0085feb0(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ead600,&LAB_00634100);
  uVar3 = FUN_00635450();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00b7a190();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return *piVar4;
  }
  return *piVar4;
}



/* FUNCTION 13172 ; VA 0x0085ff70 ; FUN_0085ff70 */

int FUN_0085ff70(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 == 0) {
    return 0;
  }
  FUN_005789c0(&DAT_01ead600,&LAB_00634100);
  uVar3 = FUN_00635450();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00b7a190();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return *piVar4;
}



/* FUNCTION 13173 ; VA 0x00860030 ; FUN_00860030 */

void __fastcall FUN_00860030(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x24) * 0x24;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 13174 ; VA 0x008600a0 ; FUN_008600a0 */

void __fastcall FUN_008600a0(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  
  piVar2 = (int *)param_1[0x47];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar3 = param_1[0x42];
  if (iVar3 != 0) {
    uVar5 = ((param_1[0x44] - iVar3) / 0x18) * 0x18;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00860345;
    }
    FUN_01674ea0(iVar4,uVar5);
    param_1[0x42] = 0;
    param_1[0x43] = 0;
    param_1[0x44] = 0;
  }
  iVar3 = param_1[0x39];
  if (iVar3 != 0) {
    uVar5 = ((param_1[0x3b] - iVar3) / 0x24) * 0x24;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00860345;
    }
    FUN_01674ea0(iVar4,uVar5);
    param_1[0x39] = 0;
    param_1[0x3a] = 0;
    param_1[0x3b] = 0;
  }
  iVar3 = param_1[0x36];
  if (iVar3 != 0) {
    uVar5 = param_1[0x38] - iVar3 & 0xfffffffc;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00860345;
    }
    FUN_01674ea0(iVar4,uVar5);
    param_1[0x36] = 0;
    param_1[0x37] = 0;
    param_1[0x38] = 0;
  }
  iVar3 = param_1[0x33];
  if (iVar3 != 0) {
    uVar5 = param_1[0x35] - iVar3 & 0xfffffffc;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00860345;
    }
    FUN_01674ea0(iVar4,uVar5);
    param_1[0x33] = 0;
    param_1[0x34] = 0;
    param_1[0x35] = 0;
  }
  iVar3 = param_1[0x30];
  if (iVar3 != 0) {
    uVar5 = param_1[0x32] - iVar3 & 0xfffffffc;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00860345;
    }
    FUN_01674ea0(iVar4,uVar5);
    param_1[0x30] = 0;
    param_1[0x31] = 0;
    param_1[0x32] = 0;
  }
  uVar5 = param_1[0xb];
  if (0xf < uVar5) {
    iVar3 = param_1[6];
    uVar6 = uVar5 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = uVar5 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00860345;
    }
    FUN_01674ea0(iVar4,uVar6);
  }
  param_1[10] = 0;
  param_1[0xb] = 0xf;
  *(undefined *)(param_1 + 6) = 0;
  uVar5 = param_1[5];
  if (0xf < uVar5) {
    iVar3 = *param_1;
    uVar6 = uVar5 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = uVar5 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_00860345:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 13175 ; VA 0x00860350 ; FUN_00860350 */

void FUN_00860350(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined8 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  if (param_1 != param_2) {
    do {
      uVar2 = param_1[1];
      uVar3 = param_1[2];
      uVar4 = param_1[3];
      *param_3 = *param_1;
      param_3[1] = uVar2;
      param_3[2] = uVar3;
      param_3[3] = uVar4;
      uVar2 = param_1[5];
      uVar3 = param_1[6];
      uVar4 = param_1[7];
      param_3[4] = param_1[4];
      param_3[5] = uVar2;
      param_3[6] = uVar3;
      param_3[7] = uVar4;
      puVar1 = (undefined8 *)(param_1 + 8);
      param_1 = param_1 + 10;
      *(undefined8 *)(param_3 + 8) = *puVar1;
      param_3 = param_3 + 10;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 13176 ; VA 0x00860390 ; FUN_00860390 */

void __thiscall FUN_00860390(int param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined8 uVar1;
  undefined4 *puVar2;
  float *pfVar3;
  int iVar4;
  undefined8 *puVar5;
  undefined auStack_164 [64];
  undefined auStack_124 [16];
  undefined auStack_114 [12];
  undefined auStack_108 [12];
  undefined auStack_fc [12];
  float fStack_f0;
  undefined8 uStack_ec;
  undefined4 uStack_e4;
  float fStack_e0;
  float fStack_dc;
  undefined4 uStack_d8;
  undefined auStack_d4 [8];
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  float fStack_b8;
  float fStack_b4;
  float fStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined8 uStack_98;
  undefined4 uStack_90;
  undefined8 uStack_8c;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 uStack_78;
  undefined8 uStack_74;
  undefined4 uStack_6c;
  undefined8 uStack_68;
  undefined4 uStack_60;
  undefined8 uStack_5c;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  if (*(char *)(param_1 + 0x24) == '\0') {
    FUN_01165e00(auStack_164);
    iVar4 = 8;
    uStack_ec = CONCAT44(DAT_018f7864,DAT_018f7864);
    uStack_90 = 0;
    uStack_cc = 0x3f800000;
    uStack_e4 = 0;
    fStack_e0 = DAT_018ce2f8;
    fStack_dc = DAT_018ce2f8;
    uStack_d8 = 0x3f800000;
    do {
      FUN_00569440();
      iVar4 = iVar4 + -1;
    } while (iVar4 != 0);
    iVar4 = 0;
    puVar5 = &uStack_8c;
    do {
      puVar2 = (undefined4 *)FUN_00c9f1c0(auStack_d4,iVar4);
      uStack_a8 = *puVar2;
      uStack_a4 = puVar2[1];
      uStack_a0 = puVar2[2];
      uStack_9c = 0x3f800000;
      FUN_01165b90(auStack_fc,&uStack_a8);
      pfVar3 = (float *)FUN_011658d0(auStack_108);
      fStack_b0 = DAT_018ce2f8 / fStack_f0;
      fStack_b8 = *pfVar3 * fStack_b0;
      fStack_b4 = pfVar3[1] * fStack_b0;
      uStack_ac = 0x3f800000;
      fStack_b0 = pfVar3[2] * fStack_b0;
      puVar2 = (undefined4 *)FUN_011658d0(auStack_114);
      uStack_bc = 0x3f800000;
      uStack_c8 = *puVar2;
      uStack_c4 = puVar2[1];
      uStack_c0 = puVar2[2];
      FUN_01165b90(auStack_124,&uStack_c8);
      FUN_011658d0(&uStack_98);
      iVar4 = iVar4 + 1;
      *puVar5 = uStack_98;
      *(undefined4 *)(puVar5 + 1) = uStack_90;
      puVar5 = (undefined8 *)((int)puVar5 + 0xc);
    } while (iVar4 < 8);
    uStack_2c = uStack_8c;
    uStack_24 = uStack_84;
    uStack_20 = uStack_80;
    uStack_14 = *param_3;
    uStack_10 = param_3[1];
    uStack_c = param_3[2];
    uStack_8 = param_3[3];
    uVar1 = *(undefined8 *)(param_3 + 2);
    uStack_18 = uStack_78;
    puVar2 = *(undefined4 **)(param_1 + 0x10);
    if (*(undefined4 **)(param_1 + 0x14) == puVar2) {
      FUN_0085fce0(puVar2,&uStack_2c);
    }
    else {
      uStack_2c._0_4_ = (undefined4)uStack_8c;
      uStack_2c._4_4_ = (undefined4)((ulonglong)uStack_8c >> 0x20);
      uStack_20._0_4_ = (undefined4)uStack_80;
      *puVar2 = (undefined4)uStack_2c;
      puVar2[1] = uStack_2c._4_4_;
      puVar2[2] = uStack_84;
      puVar2[3] = (undefined4)uStack_20;
      uStack_20._4_4_ = (undefined4)((ulonglong)uStack_80 >> 0x20);
      puVar2[4] = uStack_20._4_4_;
      puVar2[5] = uStack_78;
      puVar2[6] = uStack_14;
      puVar2[7] = uStack_10;
      *(undefined8 *)(puVar2 + 8) = uVar1;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 0x28;
    }
    puVar2 = *(undefined4 **)(param_1 + 0x10);
    uStack_2c = uStack_80;
    uStack_20 = uStack_68;
    uStack_14 = *param_3;
    uStack_10 = param_3[1];
    uStack_c = param_3[2];
    uStack_8 = param_3[3];
    uVar1 = *(undefined8 *)(param_3 + 2);
    uStack_24 = uStack_78;
    uStack_18 = uStack_60;
    if (*(undefined4 **)(param_1 + 0x14) == puVar2) {
      FUN_0085fce0(puVar2,&uStack_2c);
    }
    else {
      uStack_2c._0_4_ = (undefined4)uStack_80;
      uStack_2c._4_4_ = (undefined4)((ulonglong)uStack_80 >> 0x20);
      uStack_20._0_4_ = (undefined4)uStack_68;
      *puVar2 = (undefined4)uStack_2c;
      puVar2[1] = uStack_2c._4_4_;
      puVar2[2] = uStack_78;
      puVar2[3] = (undefined4)uStack_20;
      uStack_20._4_4_ = (undefined4)((ulonglong)uStack_68 >> 0x20);
      puVar2[4] = uStack_20._4_4_;
      puVar2[5] = uStack_60;
      puVar2[6] = uStack_14;
      puVar2[7] = uStack_10;
      *(undefined8 *)(puVar2 + 8) = uVar1;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 0x28;
    }
    puVar2 = *(undefined4 **)(param_1 + 0x10);
    uStack_2c = uStack_74;
    uStack_20 = uStack_68;
    uStack_14 = *param_3;
    uStack_10 = param_3[1];
    uStack_c = param_3[2];
    uStack_8 = param_3[3];
    uVar1 = *(undefined8 *)(param_3 + 2);
    uStack_24 = uStack_6c;
    uStack_18 = uStack_60;
    if (*(undefined4 **)(param_1 + 0x14) == puVar2) {
      FUN_0085fce0(puVar2,&uStack_2c);
    }
    else {
      uStack_2c._0_4_ = (undefined4)uStack_74;
      uStack_2c._4_4_ = (undefined4)((ulonglong)uStack_74 >> 0x20);
      uStack_20._0_4_ = (undefined4)uStack_68;
      *puVar2 = (undefined4)uStack_2c;
      puVar2[1] = uStack_2c._4_4_;
      puVar2[2] = uStack_6c;
      puVar2[3] = (undefined4)uStack_20;
      uStack_20._4_4_ = (undefined4)((ulonglong)uStack_68 >> 0x20);
      puVar2[4] = uStack_20._4_4_;
      puVar2[5] = uStack_60;
      puVar2[6] = uStack_14;
      puVar2[7] = uStack_10;
      *(undefined8 *)(puVar2 + 8) = uVar1;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 0x28;
    }
    puVar2 = *(undefined4 **)(param_1 + 0x10);
    uStack_2c = uStack_8c;
    uStack_20 = uStack_74;
    uStack_14 = *param_3;
    uStack_10 = param_3[1];
    uStack_c = param_3[2];
    uStack_8 = param_3[3];
    uVar1 = *(undefined8 *)(param_3 + 2);
    uStack_24 = uStack_84;
    uStack_18 = uStack_6c;
    if (*(undefined4 **)(param_1 + 0x14) == puVar2) {
      FUN_0085fce0(puVar2,&uStack_2c);
    }
    else {
      uStack_2c._0_4_ = (undefined4)uStack_8c;
      uStack_2c._4_4_ = (undefined4)((ulonglong)uStack_8c >> 0x20);
      uStack_20._0_4_ = (undefined4)uStack_74;
      *puVar2 = (undefined4)uStack_2c;
      puVar2[1] = uStack_2c._4_4_;
      puVar2[2] = uStack_84;
      puVar2[3] = (undefined4)uStack_20;
      uStack_20._4_4_ = (undefined4)((ulonglong)uStack_74 >> 0x20);
      puVar2[4] = uStack_20._4_4_;
      puVar2[5] = uStack_6c;
      puVar2[6] = uStack_14;
      puVar2[7] = uStack_10;
      *(undefined8 *)(puVar2 + 8) = uVar1;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 0x28;
    }
    puVar2 = *(undefined4 **)(param_1 + 0x10);
    uStack_2c = uStack_5c;
    uStack_20 = uStack_50;
    uStack_14 = *param_3;
    uStack_10 = param_3[1];
    uStack_c = param_3[2];
    uStack_8 = param_3[3];
    uVar1 = *(undefined8 *)(param_3 + 2);
    uStack_24 = uStack_54;
    uStack_18 = uStack_48;
    if (*(undefined4 **)(param_1 + 0x14) == puVar2) {
      FUN_0085fce0(puVar2,&uStack_2c);
    }
    else {
      uStack_2c._0_4_ = (undefined4)uStack_5c;
      uStack_2c._4_4_ = (undefined4)((ulonglong)uStack_5c >> 0x20);
      uStack_20._0_4_ = (undefined4)uStack_50;
      *puVar2 = (undefined4)uStack_2c;
      puVar2[1] = uStack_2c._4_4_;
      puVar2[2] = uStack_54;
      puVar2[3] = (undefined4)uStack_20;
      uStack_20._4_4_ = (undefined4)((ulonglong)uStack_50 >> 0x20);
      puVar2[4] = uStack_20._4_4_;
      puVar2[5] = uStack_48;
      puVar2[6] = uStack_14;
      puVar2[7] = uStack_10;
      *(undefined8 *)(puVar2 + 8) = uVar1;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 0x28;
    }
    puVar2 = *(undefined4 **)(param_1 + 0x10);
    uStack_2c = uStack_50;
    uStack_20 = uStack_38;
    uStack_14 = *param_3;
    uStack_10 = param_3[1];
    uStack_c = param_3[2];
    uStack_8 = param_3[3];
    uVar1 = *(undefined8 *)(param_3 + 2);
    uStack_24 = uStack_48;
    uStack_18 = uStack_30;
    if (*(undefined4 **)(param_1 + 0x14) == puVar2) {
      FUN_0085fce0(puVar2,&uStack_2c);
    }
    else {
      uStack_2c._0_4_ = (undefined4)uStack_50;
      uStack_2c._4_4_ = (undefined4)((ulonglong)uStack_50 >> 0x20);
      uStack_20._0_4_ = (undefined4)uStack_38;
      *puVar2 = (undefined4)uStack_2c;
      puVar2[1] = uStack_2c._4_4_;
      puVar2[2] = uStack_48;
      puVar2[3] = (undefined4)uStack_20;
      uStack_20._4_4_ = (undefined4)((ulonglong)uStack_38 >> 0x20);
      puVar2[4] = uStack_20._4_4_;
      puVar2[5] = uStack_30;
      puVar2[6] = uStack_14;
      puVar2[7] = uStack_10;
      *(undefined8 *)(puVar2 + 8) = uVar1;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 0x28;
    }
    puVar2 = *(undefined4 **)(param_1 + 0x10);
    uStack_2c = uStack_44;
    uStack_20 = uStack_38;
    uStack_14 = *param_3;
    uStack_10 = param_3[1];
    uStack_c = param_3[2];
    uStack_8 = param_3[3];
    uVar1 = *(undefined8 *)(param_3 + 2);
    uStack_24 = uStack_3c;
    uStack_18 = uStack_30;
    if (*(undefined4 **)(param_1 + 0x14) == puVar2) {
      FUN_0085fce0(puVar2,&uStack_2c);
    }
    else {
      uStack_2c._0_4_ = (undefined4)uStack_44;
      uStack_2c._4_4_ = (undefined4)((ulonglong)uStack_44 >> 0x20);
      uStack_20._0_4_ = (undefined4)uStack_38;
      *puVar2 = (undefined4)uStack_2c;
      puVar2[1] = uStack_2c._4_4_;
      puVar2[2] = uStack_3c;
      puVar2[3] = (undefined4)uStack_20;
      uStack_20._4_4_ = (undefined4)((ulonglong)uStack_38 >> 0x20);
      puVar2[4] = uStack_20._4_4_;
      puVar2[5] = uStack_30;
      puVar2[6] = uStack_14;
      puVar2[7] = uStack_10;
      *(undefined8 *)(puVar2 + 8) = uVar1;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 0x28;
    }
    puVar2 = *(undefined4 **)(param_1 + 0x10);
    uStack_2c = uStack_5c;
    uStack_20 = uStack_44;
    uStack_14 = *param_3;
    uStack_10 = param_3[1];
    uStack_c = param_3[2];
    uStack_8 = param_3[3];
    uVar1 = *(undefined8 *)(param_3 + 2);
    uStack_24 = uStack_54;
    uStack_18 = uStack_3c;
    if (*(undefined4 **)(param_1 + 0x14) == puVar2) {
      FUN_0085fce0(puVar2,&uStack_2c);
    }
    else {
      uStack_2c._0_4_ = (undefined4)uStack_5c;
      uStack_2c._4_4_ = (undefined4)((ulonglong)uStack_5c >> 0x20);
      uStack_20._0_4_ = (undefined4)uStack_44;
      *puVar2 = (undefined4)uStack_2c;
      puVar2[1] = uStack_2c._4_4_;
      puVar2[2] = uStack_54;
      puVar2[3] = (undefined4)uStack_20;
      uStack_20._4_4_ = (undefined4)((ulonglong)uStack_44 >> 0x20);
      puVar2[4] = uStack_20._4_4_;
      puVar2[5] = uStack_3c;
      puVar2[6] = uStack_14;
      puVar2[7] = uStack_10;
      *(undefined8 *)(puVar2 + 8) = uVar1;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 0x28;
    }
    puVar2 = *(undefined4 **)(param_1 + 0x10);
    uStack_2c = uStack_38;
    uStack_20 = uStack_68;
    uStack_14 = *param_3;
    uStack_10 = param_3[1];
    uStack_c = param_3[2];
    uStack_8 = param_3[3];
    uVar1 = *(undefined8 *)(param_3 + 2);
    uStack_24 = uStack_30;
    uStack_18 = uStack_60;
    if (*(undefined4 **)(param_1 + 0x14) == puVar2) {
      FUN_0085fce0(puVar2,&uStack_2c);
    }
    else {
      uStack_2c._0_4_ = (undefined4)uStack_38;
      uStack_2c._4_4_ = (undefined4)((ulonglong)uStack_38 >> 0x20);
      uStack_20._0_4_ = (undefined4)uStack_68;
      *puVar2 = (undefined4)uStack_2c;
      puVar2[1] = uStack_2c._4_4_;
      puVar2[2] = uStack_30;
      puVar2[3] = (undefined4)uStack_20;
      uStack_20._4_4_ = (undefined4)((ulonglong)uStack_68 >> 0x20);
      puVar2[4] = uStack_20._4_4_;
      puVar2[5] = uStack_60;
      puVar2[6] = uStack_14;
      puVar2[7] = uStack_10;
      *(undefined8 *)(puVar2 + 8) = uVar1;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 0x28;
    }
    puVar2 = *(undefined4 **)(param_1 + 0x10);
    uStack_2c = uStack_44;
    uStack_20 = uStack_74;
    uStack_14 = *param_3;
    uStack_10 = param_3[1];
    uStack_c = param_3[2];
    uStack_8 = param_3[3];
    uVar1 = *(undefined8 *)(param_3 + 2);
    uStack_24 = uStack_3c;
    uStack_18 = uStack_6c;
    if (*(undefined4 **)(param_1 + 0x14) == puVar2) {
      FUN_0085fce0(puVar2,&uStack_2c);
    }
    else {
      uStack_2c._0_4_ = (undefined4)uStack_44;
      uStack_2c._4_4_ = (undefined4)((ulonglong)uStack_44 >> 0x20);
      uStack_20._0_4_ = (undefined4)uStack_74;
      *puVar2 = (undefined4)uStack_2c;
      puVar2[1] = uStack_2c._4_4_;
      puVar2[2] = uStack_3c;
      puVar2[3] = (undefined4)uStack_20;
      uStack_20._4_4_ = (undefined4)((ulonglong)uStack_74 >> 0x20);
      puVar2[4] = uStack_20._4_4_;
      puVar2[5] = uStack_6c;
      puVar2[6] = uStack_14;
      puVar2[7] = uStack_10;
      *(undefined8 *)(puVar2 + 8) = uVar1;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 0x28;
    }
    puVar2 = *(undefined4 **)(param_1 + 0x10);
    uStack_2c = uStack_50;
    uStack_20 = uStack_80;
    uStack_14 = *param_3;
    uStack_10 = param_3[1];
    uStack_c = param_3[2];
    uStack_8 = param_3[3];
    uVar1 = *(undefined8 *)(param_3 + 2);
    uStack_24 = uStack_48;
    uStack_18 = uStack_78;
    if (*(undefined4 **)(param_1 + 0x14) == puVar2) {
      FUN_0085fce0(puVar2,&uStack_2c);
    }
    else {
      uStack_2c._0_4_ = (undefined4)uStack_50;
      uStack_2c._4_4_ = (undefined4)((ulonglong)uStack_50 >> 0x20);
      uStack_20._0_4_ = (undefined4)uStack_80;
      *puVar2 = (undefined4)uStack_2c;
      puVar2[1] = uStack_2c._4_4_;
      puVar2[2] = uStack_48;
      puVar2[3] = (undefined4)uStack_20;
      uStack_20._4_4_ = (undefined4)((ulonglong)uStack_80 >> 0x20);
      puVar2[4] = uStack_20._4_4_;
      puVar2[5] = uStack_78;
      puVar2[6] = uStack_14;
      puVar2[7] = uStack_10;
      *(undefined8 *)(puVar2 + 8) = uVar1;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 0x28;
    }
    puVar2 = *(undefined4 **)(param_1 + 0x10);
    uStack_2c = uStack_5c;
    uStack_20 = uStack_8c;
    uStack_14 = *param_3;
    uStack_10 = param_3[1];
    uStack_c = param_3[2];
    uStack_8 = param_3[3];
    uVar1 = *(undefined8 *)(param_3 + 2);
    uStack_24 = uStack_54;
    uStack_18 = uStack_84;
    if (*(undefined4 **)(param_1 + 0x14) != puVar2) {
      uStack_2c._0_4_ = (undefined4)uStack_5c;
      uStack_2c._4_4_ = (undefined4)((ulonglong)uStack_5c >> 0x20);
      uStack_20._0_4_ = (undefined4)uStack_8c;
      *puVar2 = (undefined4)uStack_2c;
      puVar2[1] = uStack_2c._4_4_;
      puVar2[2] = uStack_54;
      puVar2[3] = (undefined4)uStack_20;
      uStack_20._4_4_ = (undefined4)((ulonglong)uStack_8c >> 0x20);
      puVar2[4] = uStack_20._4_4_;
      puVar2[5] = uStack_84;
      puVar2[6] = uStack_14;
      puVar2[7] = uStack_10;
      *(undefined8 *)(puVar2 + 8) = uVar1;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 0x28;
      return;
    }
    FUN_0085fce0(puVar2,&uStack_2c);
  }
  return;
}



/* FUNCTION 13177 ; VA 0x008609e0 ; FUN_008609e0 */

undefined4 __fastcall FUN_008609e0(int param_1)

{
  return *(undefined4 *)(param_1 + 0x5c);
}



/* FUNCTION 13178 ; VA 0x008609f0 ; FUN_008609f0 */

int __thiscall FUN_008609f0(int *param_1,int param_2,undefined4 *param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  
  iVar4 = *param_1;
  iVar3 = (param_1[1] - iVar4) / 0xc;
  if (iVar3 == 0x15555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar6 = iVar3 + 1;
  uVar2 = (param_1[2] - iVar4) / 0xc;
  uVar7 = uVar6;
  if ((uVar2 <= 0x15555555 - (uVar2 >> 1)) && (uVar7 = (uVar2 >> 1) + uVar2, uVar7 < uVar6)) {
    uVar7 = uVar6;
  }
  iVar3 = FUN_00618050(uVar7);
  iVar4 = ((param_2 - iVar4) / 0xc) * 0xc;
  puVar5 = (undefined4 *)(iVar4 + iVar3);
  uVar1 = *param_4;
  *puVar5 = *param_3;
  puVar5[1] = uVar1;
  puVar5[2] = 0;
  if (param_2 == param_1[1]) {
    FUN_00861090(*param_1,param_1[1],iVar3);
  }
  else {
    FUN_00861040(*param_1,param_2,iVar3);
    FUN_00861040(param_2,param_1[1],puVar5 + 3);
  }
  FUN_006bf950(iVar3,uVar6,uVar7);
  return *param_1 + iVar4;
}



/* FUNCTION 13179 ; VA 0x00860b00 ; FUN_00860b00 */

int __thiscall
FUN_00860b00(uint *param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 *param_5)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  undefined4 *puVar9;
  uint uVar10;
  undefined4 *puVar11;
  uint uVar12;
  
  uVar2 = *param_1;
  iVar5 = (int)(param_1[1] - uVar2) / 0xc;
  if (iVar5 == 0x15555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar8 = iVar5 + 1;
  uVar6 = (int)(param_1[2] - uVar2) / 0xc;
  uVar12 = uVar8;
  if ((uVar6 <= 0x15555555 - (uVar6 >> 1)) && (uVar12 = (uVar6 >> 1) + uVar6, uVar12 < uVar8)) {
    uVar12 = uVar8;
  }
  uVar8 = uVar12 * 0xc;
  if (uVar12 < 0x15555556) {
    uVar12 = uVar8;
    if (0xfff < uVar8) goto LAB_00860b98;
    if (uVar8 == 0) {
      uVar12 = 0;
    }
    else {
      uVar12 = FUN_01674e20(uVar8);
    }
  }
  else {
    uVar12 = 0xffffffff;
LAB_00860b98:
    uVar6 = uVar12 + 0x23;
    if (uVar6 <= uVar12) {
      uVar6 = 0xffffffff;
    }
    iVar7 = FUN_01674e20(uVar6);
    if (iVar7 == 0) goto LAB_00860cb0;
    uVar12 = iVar7 + 0x23U & 0xffffffe0;
    *(int *)(uVar12 - 4) = iVar7;
  }
  iVar7 = ((int)((int)param_2 - uVar2) / 0xc) * 0xc;
  uVar3 = *param_5;
  *(undefined4 *)(iVar7 + uVar12) = param_3;
  *(undefined4 *)(iVar7 + 4 + uVar12) = param_4;
  *(undefined4 *)(iVar7 + 8 + uVar12) = uVar3;
  puVar4 = (undefined4 *)param_1[1];
  puVar9 = (undefined4 *)*param_1;
  if (param_2 == puVar4) {
    if (puVar9 != puVar4) {
      puVar11 = (undefined4 *)(uVar12 + 8);
      do {
        puVar11[-2] = *puVar9;
        puVar11[-1] = puVar9[1];
        puVar1 = puVar9 + 2;
        puVar9 = puVar9 + 3;
        *puVar11 = *puVar1;
        puVar11 = puVar11 + 3;
      } while (puVar9 != puVar4);
    }
  }
  else {
    FUN_00861040(puVar9,param_2,uVar12);
    FUN_00861040(param_2,param_1[1],iVar7 + 0xc + uVar12);
  }
  uVar2 = *param_1;
  if (uVar2 != 0) {
    uVar10 = ((int)(param_1[2] - uVar2) / 0xc) * 0xc;
    uVar6 = uVar2;
    if (0xfff < uVar10) {
      uVar6 = *(uint *)(uVar2 - 4);
      uVar10 = uVar10 + 0x23;
      if (0x1f < (uVar2 - uVar6) - 4) {
LAB_00860cb0:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar10);
  }
  *param_1 = uVar12;
  param_1[1] = uVar12 + (iVar5 * 3 + 3) * 4;
  param_1[2] = uVar8 + uVar12;
  return *param_1 + iVar7;
}



/* FUNCTION 13180 ; VA 0x00860cc0 ; FUN_00860cc0 */

int __thiscall
FUN_00860cc0(int *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  uint uVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  
  iVar1 = *param_1;
  iVar5 = param_1[1] - iVar1 >> 5;
  if (iVar5 == 0x7ffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar6 = iVar5 + 1;
  uVar10 = param_1[2] - iVar1 >> 5;
  uVar7 = uVar6;
  if ((uVar10 <= 0x7ffffff - (uVar10 >> 1)) && (uVar7 = (uVar10 >> 1) + uVar10, uVar7 < uVar6)) {
    uVar7 = uVar6;
  }
  puVar8 = (undefined4 *)FUN_00577f40(uVar7);
  uVar10 = (int)param_2 - iVar1 & 0xffffffe0;
  *(undefined4 *)(uVar10 + (int)puVar8) = *param_3;
  *(undefined4 *)(uVar10 + 4 + (int)puVar8) = param_3[1];
  *(undefined4 *)(uVar10 + 8 + (int)puVar8) = 0x3f800000;
  *(undefined4 *)(uVar10 + 0xc + (int)puVar8) = 0x3f800000;
  *(undefined4 *)(uVar10 + 0x10 + (int)puVar8) = 0x3f800000;
  *(undefined4 *)(uVar10 + 0x14 + (int)puVar8) = 0x3f800000;
  *(undefined4 *)(uVar10 + 0x18 + (int)puVar8) = *param_4;
  *(undefined4 *)(uVar10 + 0x1c + (int)puVar8) = param_4[1];
  puVar12 = (undefined4 *)param_1[1];
  puVar9 = (undefined4 *)*param_1;
  puVar11 = puVar8;
  if (param_2 == puVar12) {
    for (; puVar9 != puVar12; puVar9 = puVar9 + 8) {
      uVar2 = puVar9[1];
      uVar3 = puVar9[2];
      uVar4 = puVar9[3];
      *puVar11 = *puVar9;
      puVar11[1] = uVar2;
      puVar11[2] = uVar3;
      puVar11[3] = uVar4;
      uVar2 = puVar9[5];
      uVar3 = puVar9[6];
      uVar4 = puVar9[7];
      puVar11[4] = puVar9[4];
      puVar11[5] = uVar2;
      puVar11[6] = uVar3;
      puVar11[7] = uVar4;
      puVar11 = puVar11 + 8;
    }
  }
  else {
    if (puVar9 != param_2) {
      do {
        uVar2 = puVar9[1];
        uVar3 = puVar9[2];
        uVar4 = puVar9[3];
        *puVar11 = *puVar9;
        puVar11[1] = uVar2;
        puVar11[2] = uVar3;
        puVar11[3] = uVar4;
        puVar12 = puVar9 + 4;
        uVar2 = puVar9[5];
        uVar3 = puVar9[6];
        uVar4 = puVar9[7];
        puVar9 = puVar9 + 8;
        puVar11[4] = *puVar12;
        puVar11[5] = uVar2;
        puVar11[6] = uVar3;
        puVar11[7] = uVar4;
        puVar11 = puVar11 + 8;
      } while (puVar9 != param_2);
      puVar12 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar12) {
      puVar9 = (undefined4 *)((int)puVar8 + uVar10 + 0x20);
      do {
        uVar2 = param_2[1];
        uVar3 = param_2[2];
        uVar4 = param_2[3];
        *puVar9 = *param_2;
        puVar9[1] = uVar2;
        puVar9[2] = uVar3;
        puVar9[3] = uVar4;
        puVar11 = param_2 + 4;
        uVar2 = param_2[5];
        uVar3 = param_2[6];
        uVar4 = param_2[7];
        param_2 = param_2 + 8;
        puVar9[4] = *puVar11;
        puVar9[5] = uVar2;
        puVar9[6] = uVar3;
        puVar9[7] = uVar4;
        puVar9 = puVar9 + 8;
      } while (param_2 != puVar12);
    }
  }
  FUN_007fdb40(puVar8,uVar6,uVar7);
  return *param_1 + uVar10;
}



/* FUNCTION 13181 ; VA 0x00860e00 ; FUN_00860e00 */

void __thiscall FUN_00860e00(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    uVar2 = *param_3;
    *puVar1 = *param_2;
    puVar1[1] = uVar2;
    puVar1[2] = 0;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0xc;
    return;
  }
  FUN_008609f0(puVar1,param_2,param_3);
  return;
}



/* FUNCTION 13182 ; VA 0x00860e50 ; FUN_00860e50 */

void __thiscall FUN_00860e50(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    *puVar1 = *param_2;
    puVar1[1] = param_2[1];
    puVar1[2] = 0x3f800000;
    puVar1[3] = 0x3f800000;
    puVar1[4] = 0x3f800000;
    puVar1[5] = 0x3f800000;
    puVar1[6] = *param_3;
    puVar1[7] = param_3[1];
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x20;
    return;
  }
  FUN_00860cc0(puVar1,param_2,param_3);
  return;
}



/* FUNCTION 13183 ; VA 0x00860ec0 ; FUN_00860ec0 */

undefined4 * __fastcall FUN_00860ec0(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  return param_1;
}



/* FUNCTION 13184 ; VA 0x00860f20 ; FUN_00860f20 */

void __fastcall FUN_00860f20(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0x18);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x20) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x18) = 0;
    *(undefined4 *)(param_1 + 0x1c) = 0;
    *(undefined4 *)(param_1 + 0x20) = 0;
  }
  return;
}



/* FUNCTION 13185 ; VA 0x00860f80 ; FUN_00860f80 */

void __thiscall FUN_00860f80(int *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  
  iVar2 = param_1[1];
  iVar3 = *param_1;
  iVar5 = FUN_00618050(param_2);
  puVar4 = (undefined4 *)param_1[1];
  puVar6 = (undefined4 *)*param_1;
  if (puVar6 != puVar4) {
    puVar7 = (undefined4 *)(iVar5 + 8);
    do {
      puVar7[-2] = *puVar6;
      puVar7[-1] = puVar6[1];
      puVar1 = puVar6 + 2;
      puVar6 = puVar6 + 3;
      *puVar7 = *puVar1;
      puVar7 = puVar7 + 3;
    } while (puVar6 != puVar4);
  }
  FUN_006bf950(iVar5,(iVar2 - iVar3) / 0xc,param_2);
  return;
}



/* FUNCTION 13186 ; VA 0x00860ff0 ; FUN_00860ff0 */

void __thiscall FUN_00860ff0(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  
  iVar1 = param_1[1];
  iVar2 = *param_1;
  puVar8 = (undefined4 *)FUN_00577f40(param_2);
  puVar3 = (undefined4 *)param_1[1];
  puVar7 = puVar8;
  for (puVar9 = (undefined4 *)*param_1; puVar9 != puVar3; puVar9 = puVar9 + 8) {
    uVar4 = puVar9[1];
    uVar5 = puVar9[2];
    uVar6 = puVar9[3];
    *puVar7 = *puVar9;
    puVar7[1] = uVar4;
    puVar7[2] = uVar5;
    puVar7[3] = uVar6;
    uVar4 = puVar9[5];
    uVar5 = puVar9[6];
    uVar6 = puVar9[7];
    puVar7[4] = puVar9[4];
    puVar7[5] = uVar4;
    puVar7[6] = uVar5;
    puVar7[7] = uVar6;
    puVar7 = puVar7 + 8;
  }
  FUN_007fdb40(puVar8,iVar1 - iVar2 >> 5,param_2);
  return;
}



/* FUNCTION 13187 ; VA 0x00861040 ; FUN_00861040 */

undefined4 * FUN_00861040(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  
  puVar3 = param_3;
  if (param_1 != param_2) {
    puVar2 = param_1 + 2;
    do {
      *puVar3 = puVar2[-2];
      puVar3[1] = puVar2[-1];
      puVar3 = puVar3 + 3;
      *(undefined4 *)((int)param_3 + (-0xc - (int)param_1) + (int)(puVar2 + 3)) = *puVar2;
      puVar1 = puVar2 + 1;
      puVar2 = puVar2 + 3;
    } while (puVar1 != param_2);
  }
  return puVar3;
}



/* FUNCTION 13188 ; VA 0x00861090 ; FUN_00861090 */

void FUN_00861090(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  
  if (param_1 != param_2) {
    puVar2 = (undefined4 *)(param_3 + 8);
    puVar3 = param_1;
    do {
      puVar2[-2] = *puVar3;
      puVar1 = puVar3 + 1;
      puVar3 = puVar3 + 3;
      puVar2[-1] = *puVar1;
      *puVar2 = *(undefined4 *)((int)param_1 + (-0xc - param_3) + (int)(puVar2 + 3));
      puVar2 = puVar2 + 3;
    } while (puVar3 != param_2);
  }
  return;
}



/* FUNCTION 13189 ; VA 0x008610e0 ; FUN_008610e0 */

void __thiscall FUN_008610e0(int *param_1,int param_2,float *param_3,float *param_4,float *param_5)

{
  int iVar1;
  float *pfVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  
  if (0 < param_2) {
    fVar3 = *param_5;
    fVar4 = *param_4;
    if ((NAN(fVar3) || NAN(fVar4)) == (fVar3 == fVar4)) {
      fVar5 = param_5[1];
      fVar8 = param_4[1];
      if ((NAN(fVar5) || NAN(fVar8)) == (fVar5 == fVar8)) {
        fVar9 = (float)param_2;
        pfVar2 = (float *)*param_1;
        fVar6 = (param_3[2] - *param_3) / (fVar4 - fVar3);
        fVar5 = (param_3[3] - param_3[1]) / (fVar8 - fVar5);
        fVar3 = (fVar4 + fVar3) * DAT_018ce2f4;
        fVar7 = (param_3[2] - *param_3) * DAT_018ce2f4 - fVar9;
        fVar4 = (fVar8 + param_5[1]) * DAT_018ce2f4;
        fVar8 = (param_3[3] - param_3[1]) * DAT_018ce2f4 - fVar9;
        if (pfVar2 != (float *)0x0) {
          *pfVar2 = fVar6;
          pfVar2[1] = fVar3 * fVar6;
          pfVar2[2] = fVar5;
          pfVar2[3] = fVar4 * fVar5;
          iVar1 = *param_1;
          *(float *)(iVar1 + 0x10) = fVar7;
          *(float *)(iVar1 + 0x14) = fVar8;
          *(float *)(iVar1 + 0x18) = fVar9;
          return;
        }
        pfVar2 = (float *)FUN_01674e20(0x1c);
        if (pfVar2 == (float *)0x0) {
          pfVar2 = (float *)0x0;
        }
        else {
          *pfVar2 = fVar6;
          pfVar2[1] = fVar3 * fVar6;
          pfVar2[2] = fVar5;
          pfVar2[3] = fVar5 * fVar4;
          pfVar2[4] = fVar7;
          pfVar2[5] = fVar8;
          pfVar2[6] = (float)param_2;
        }
        iVar1 = *param_1;
        *param_1 = (int)pfVar2;
        if (iVar1 == 0) {
          return;
        }
        FUN_01674ea0(iVar1,0x1c);
        return;
      }
    }
  }
  iVar1 = *param_1;
  *param_1 = 0;
  if (iVar1 != 0) {
    FUN_01674ea0(iVar1,0x1c);
  }
  return;
}



/* FUNCTION 13190 ; VA 0x008612b0 ; FUN_008612b0 */

void FUN_008612b0(undefined4 *param_1,float param_2,float param_3,float param_4,float param_5,
                 float param_6,float param_7,float *param_8,float *param_9,int param_10,int param_11
                 )

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  uint uVar5;
  undefined4 *puVar6;
  float *pfVar7;
  float fVar8;
  undefined4 *puVar9;
  float fVar10;
  float fVar11;
  undefined8 uVar12;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  undefined4 uStack_1c;
  float *pfStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017b863c;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb4998) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb4998), DAT_01eb4998 == -1)) {
    iStack_8._0_1_ = 1;
    uVar12 = FUN_0152dab0(&DAT_018fdbdc,"Gradient Tessellation Function Call",0xffffffff);
    DAT_01eb4994 = (undefined4)((ulonglong)uVar12 >> 0x20);
    DAT_01eb4990 = (undefined4)uVar12;
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_016f37bf(&DAT_01eb4998);
  }
  uStack_30 = DAT_01eb4990;
  uStack_2c = DAT_01eb4994;
  uVar12 = FUN_0152d930(DAT_01eb4990,DAT_01eb4994);
  iStack_8 = CONCAT31(iStack_8._1_3_,2);
  puVar1 = (undefined4 *)param_1[2];
  fVar10 = param_7 * (param_2 - param_4) - param_6 * (param_3 - param_5);
  puVar9 = param_1;
  if ((NAN(fVar10) || NAN(DAT_018ce2f0)) == (fVar10 == DAT_018ce2f0)) {
    puVar9 = (undefined4 *)
             (((*(float *)*puVar1 - param_4) * param_7 + (param_5 - ((float *)*puVar1)[1]) * param_6
              ) / fVar10);
  }
  puVar6 = (undefined4 *)puVar1[2];
  fVar10 = DAT_018ce2f8 - (float)puVar9;
  fStack_20 = fVar10;
  if (puVar6 != puVar1) {
    fVar11 = param_7 * (param_2 - param_4) - param_6 * (param_3 - param_5);
    puVar9 = param_1;
    do {
      if ((NAN(fVar11) || NAN(DAT_018ce2f0)) == (fVar11 == DAT_018ce2f0)) {
        puVar9 = (undefined4 *)
                 (((*(float *)*puVar6 - param_4) * param_7 +
                  (param_5 - ((float *)*puVar6)[1]) * param_6) / fVar11);
      }
      fVar8 = DAT_018ce2f8 - (float)puVar9;
      if (fVar8 <= fVar10) {
        fVar10 = fVar8;
      }
      if (fStack_20 <= fVar8) {
        fStack_20 = fVar8;
      }
      puVar6 = (undefined4 *)puVar6[2];
    } while (puVar6 != puVar1);
  }
  fStack_24 = param_4 - param_2;
  pfStack_18 = param_9;
  fStack_28 = param_5 - param_3;
  pfVar7 = param_8;
  fStack_14 = fVar10;
  if (param_8 != param_9) {
    do {
      fVar11 = *pfVar7;
      if (fVar10 < fVar11) {
        if (fStack_20 <= fVar11) break;
        uStack_34 = 0;
        uStack_3c = *param_1;
        uStack_38 = param_1[1];
        cVar4 = FUN_00861c90(param_2 + fVar11 * (param_4 - param_2),
                             param_3 + fVar11 * (param_5 - param_3),param_6,param_7,&uStack_3c);
        param_9 = pfStack_18;
        fVar10 = fStack_14;
        if (cVar4 != '\0') {
          puVar1 = (undefined4 *)param_1[2];
          if (0.0 <= (*(float *)puVar1[1] - *(float *)*puVar1) * fStack_24 +
                     (((float *)puVar1[1])[1] - ((float *)*puVar1)[1]) * fStack_28) {
            puVar1 = *(undefined4 **)(param_11 + 4);
            if (*(undefined4 **)(param_11 + 8) == puVar1) {
              FUN_00860b00(puVar1,uStack_3c,uStack_38,&uStack_34);
              param_9 = pfStack_18;
              fVar10 = fStack_14;
            }
            else {
              *puVar1 = uStack_3c;
              puVar1[1] = uStack_38;
              puVar1[2] = uStack_34;
              *(int *)(param_11 + 4) = *(int *)(param_11 + 4) + 0xc;
            }
          }
          else {
            uVar2 = param_1[1];
            uStack_1c = *param_1;
            puVar9 = *(undefined4 **)(param_11 + 4);
            if (*(undefined4 **)(param_11 + 8) == puVar9) {
              FUN_00860b00(puVar9,uStack_1c,uVar2,param_1 + 2);
              param_1[2] = uStack_34;
              param_9 = pfStack_18;
              fVar10 = fStack_14;
            }
            else {
              *puVar9 = uStack_1c;
              puVar9[2] = puVar1;
              puVar9[1] = uVar2;
              *(int *)(param_11 + 4) = *(int *)(param_11 + 4) + 0xc;
              param_1[2] = uStack_34;
            }
          }
        }
      }
      pfVar7 = pfVar7 + 1;
    } while (pfVar7 != param_9);
  }
  puVar1 = *(undefined4 **)(param_11 + 4);
  uVar2 = param_1[1];
  if (*(undefined4 **)(param_11 + 8) == puVar1) {
    FUN_00860b00(puVar1,*param_1,uVar2,param_1 + 2);
  }
  else {
    uVar3 = param_1[2];
    *puVar1 = *param_1;
    puVar1[1] = uVar2;
    puVar1[2] = uVar3;
    *(int *)(param_11 + 4) = *(int *)(param_11 + 4) + 0xc;
  }
  iStack_8 = CONCAT31(iStack_8._1_3_,3);
  FUN_0152dda0(uStack_30,uStack_2c,uVar12);
  if (param_8 != (float *)0x0) {
    uVar5 = param_10 - (int)param_8 & 0xfffffffc;
    pfVar7 = param_8;
    if (0xfff < uVar5) {
      pfVar7 = (float *)param_8[-1];
      uVar5 = uVar5 + 0x23;
      if (0x1f < (uint)((int)param_8 + (-4 - (int)pfVar7))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pfVar7,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13191 ; VA 0x008616b0 ; FUN_008616b0 */

void __thiscall
FUN_008616b0(int param_1,float param_2,float *param_3,float *param_4,float *param_5,float *param_6,
            int *param_7,float *param_8,int param_9)

{
  float fVar1;
  float fVar2;
  float fVar3;
  uint uVar4;
  int *piVar5;
  int *piVar6;
  int iVar7;
  int iVar8;
  float *pfVar9;
  float *pfVar10;
  int iVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  undefined8 uVar15;
  float fStack_9c;
  float fStack_98;
  float fStack_94;
  float fStack_90;
  float fStack_8c;
  float fStack_88;
  int *piStack_84;
  float *pfStack_80;
  undefined8 uStack_7c;
  int iStack_54;
  float *pfStack_50;
  float *pfStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  float fStack_38;
  int iStack_34;
  int iStack_30;
  float *pfStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 *puStack_20;
  int *piStack_1c;
  float fStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b866c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb49a8) {
    uStack_7c._4_4_ = (float *)&DAT_01eb49a8;
    uStack_7c._0_4_ = (char *)0x861c31;
    ExceptionList = &pvStack_10;
    FUN_016f3809();
    if (DAT_01eb49a8 == -1) {
      uStack_7c._4_4_ = (float *)0xffffffff;
      uStack_7c._0_4_ = "solve for Rect2d modifier";
      pfStack_80 = (float *)&DAT_018fdbdc;
      uStack_8 = 0;
      piStack_84 = (int *)0x861c59;
      uVar15 = FUN_0152dab0();
      DAT_01eb49a4 = (undefined4)((ulonglong)uVar15 >> 0x20);
      DAT_01eb49a0 = (undefined4)uVar15;
      piStack_84 = &DAT_01eb49a8;
      uStack_8 = 0xffffffff;
      fStack_88 = 1.2316165e-38;
      FUN_016f37bf();
    }
  }
  uStack_7c._4_4_ = (float *)DAT_01eb49a4;
  uStack_7c._0_4_ = (char *)DAT_01eb49a0;
  uStack_28 = DAT_01eb49a0;
  uStack_48 = DAT_01eb49a0;
  uStack_24 = DAT_01eb49a4;
  uStack_44 = DAT_01eb49a4;
  pfStack_80 = (float *)0x861710;
  uStack_40 = FUN_0152d930();
  piStack_1c = (int *)(param_1 + 4);
  *(undefined4 *)(param_1 + 8) = *(undefined4 *)(param_1 + 4);
  puStack_20 = (undefined4 *)(param_1 + 0x1c);
  *(int *)(param_1 + 0x14) = *(int *)(param_1 + 0x10);
  *(undefined4 *)(param_1 + 0x20) = *puStack_20;
  uStack_8 = 1;
  if (param_8 == (float *)0x0) {
    iVar11 = 0;
  }
  else {
    iVar11 = ((int)param_8[5] - (int)param_8[4]) / 0x14;
  }
  uStack_7c._4_4_ = (float *)(iVar11 * 2 + 6);
  if ((uint)(*(int *)(param_1 + 0xc) - *piStack_1c >> 5) < uStack_7c._4_4_) {
    if (0x7ffffff < uStack_7c._4_4_) {
                    /* WARNING: Subroutine does not return */
      uStack_7c._4_4_ = (float *)0x861c82;
      FUN_00577c30();
    }
    uStack_7c._0_4_ = (char *)0x86178b;
    FUN_00860ff0();
  }
  uStack_7c._4_4_ = (float *)(iVar11 * 4 + 6);
  if ((uint)((*(int *)(param_1 + 0x18) - *(int *)(param_1 + 0x10)) / 0xc) < uStack_7c._4_4_) {
    if (0x15555555 < uStack_7c._4_4_) {
                    /* WARNING: Subroutine does not return */
      uStack_7c._4_4_ = (float *)0x861c87;
      FUN_00577c30();
    }
    uStack_7c._0_4_ = (char *)0x8617bf;
    FUN_00860f80();
  }
  piVar5 = (int *)param_6;
  uStack_7c._4_4_ = param_6;
  uStack_7c._0_4_ = (char *)param_2;
  pfStack_80 = (float *)0x8617ce;
  FUN_00860e50();
  piVar6 = param_7;
  iStack_30 = *piVar5;
  pfStack_2c = (float *)param_7[1];
  fStack_18 = (float)(*(int *)(iStack_14 + 8) + -0x20);
  uStack_7c._4_4_ = (float *)&iStack_30;
  uStack_7c._0_4_ = (char *)param_4;
  pfStack_80 = (float *)0x8617ff;
  FUN_00860e50();
  uStack_7c._4_4_ = (float *)piVar6;
  uStack_7c._0_4_ = (char *)param_5;
  param_6 = (float *)(*(int *)(iStack_14 + 8) + -0x20);
  pfStack_80 = (float *)0x861817;
  FUN_00860e50();
  pfStack_2c = (float *)piVar5[1];
  iStack_30 = *piVar6;
  param_2 = (float)(*(int *)(iStack_14 + 8) + -0x20);
  uStack_7c._4_4_ = (float *)&iStack_30;
  uStack_7c._0_4_ = (char *)param_3;
  pfStack_80 = (float *)0x861845;
  FUN_00860e50();
  iVar8 = iStack_14;
  iVar11 = iStack_14 + 0x10;
  param_7 = (int *)(*(int *)(iStack_14 + 8) + -0x20);
  pfVar10 = *(float **)(iStack_14 + 0x14);
  if (*(float **)(iStack_14 + 0x18) == pfVar10) {
    uStack_7c._4_4_ = (float *)&param_6;
    uStack_7c._0_4_ = (char *)&fStack_18;
    piStack_84 = (undefined4 *)0x861884;
    pfStack_80 = pfVar10;
    FUN_008609f0();
  }
  else {
    *pfVar10 = fStack_18;
    pfVar10[1] = (float)param_6;
    pfVar10[2] = 0.0;
    *(int *)(iStack_14 + 0x14) = *(int *)(iStack_14 + 0x14) + 0xc;
  }
  pfVar10 = *(float **)(iVar8 + 0x14);
  param_4 = pfVar10 + -3;
  if (*(float **)(iVar8 + 0x18) == pfVar10) {
    uStack_7c._4_4_ = &param_2;
    uStack_7c._0_4_ = (char *)&param_6;
    piStack_84 = (undefined4 *)0x8618ba;
    pfStack_80 = pfVar10;
    FUN_008609f0();
  }
  else {
    *pfVar10 = (float)param_6;
    pfVar10[1] = param_2;
    pfVar10[2] = 0.0;
    *(int *)(iVar8 + 0x14) = *(int *)(iVar8 + 0x14) + 0xc;
  }
  pfVar10 = *(float **)(iVar8 + 0x14);
  param_5 = pfVar10 + -3;
  if (*(float **)(iVar8 + 0x18) == pfVar10) {
    uStack_7c._4_4_ = (float *)&param_7;
    uStack_7c._0_4_ = (char *)&param_2;
    piStack_84 = (undefined4 *)0x8618f0;
    pfStack_80 = pfVar10;
    FUN_008609f0();
  }
  else {
    *pfVar10 = param_2;
    pfVar10[1] = (float)param_7;
    pfVar10[2] = 0.0;
    *(int *)(iVar8 + 0x14) = *(int *)(iVar8 + 0x14) + 0xc;
  }
  pfVar10 = *(float **)(iVar8 + 0x14);
  param_6 = pfVar10 + -3;
  if (*(float **)(iVar8 + 0x18) == pfVar10) {
    uStack_7c._4_4_ = &fStack_18;
    uStack_7c._0_4_ = (char *)&param_7;
    piStack_84 = (undefined4 *)0x861926;
    pfStack_80 = pfVar10;
    FUN_008609f0();
  }
  else {
    *pfVar10 = (float)param_7;
    pfVar10[1] = fStack_18;
    pfVar10[2] = 0.0;
    *(int *)(iVar8 + 0x14) = *(int *)(iVar8 + 0x14) + 0xc;
  }
  iVar7 = iStack_14;
  iVar8 = *(int *)(iVar8 + 0x14);
  param_4[2] = (float)param_5;
  param_5[2] = (float)param_6;
  param_6[2] = (float)(iVar8 + -0xc);
  *(float **)(iVar8 + -4) = param_4;
  uVar4 = DAT_018c4ea0;
  if (param_8 == (float *)0x0) {
    iVar8 = *(int *)(iStack_14 + 4);
    pfStack_80 = (float *)(iStack_14 + 4);
    if (iVar8 != *(int *)(iStack_14 + 8)) {
      do {
        if (param_9 < 0) {
          fVar13 = (float)(*(uint *)(iVar8 + 4) ^ uVar4);
        }
        else {
          fVar13 = (float)param_9 - *(float *)(iVar8 + 4);
        }
        *(float *)(iVar8 + 4) = fVar13;
        iVar8 = iVar8 + 0x20;
        pfStack_80 = (float *)piStack_1c;
      } while (iVar8 != *(int *)(iStack_14 + 8));
    }
    piStack_84 = (int *)puStack_20[1];
    if ((int *)puStack_20[2] == piStack_84) {
      uStack_7c._4_4_ = (float *)&param_4;
      fStack_88 = 1.2315993e-38;
      uStack_7c._0_4_ = (char *)iVar11;
      FUN_00860b00();
    }
    else {
      *piStack_84 = (int)pfStack_80;
      piStack_84[1] = iVar11;
      piStack_84[2] = (int)param_4;
      puStack_20[1] = puStack_20[1] + 0xc;
    }
  }
  else {
    iStack_34 = iStack_14 + 4;
    pfStack_2c = param_4;
    pfVar9 = (float *)0x0;
    iStack_54 = 0;
    pfStack_50 = (float *)0x0;
    fVar13 = param_8[1];
    fVar1 = param_8[2];
    fVar2 = *param_8;
    fVar3 = param_8[3];
    fVar14 = fVar1 - fVar2;
    fVar12 = fVar13 - fVar3;
    pfStack_4c = (float *)0x0;
    param_6 = (float *)param_8[5];
    pfVar10 = (float *)param_8[4];
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    iStack_30 = iVar11;
    if (pfVar10 != param_6) {
      do {
        if (pfVar9 == pfStack_50) {
          pfStack_80 = (float *)0x8619da;
          uStack_7c._0_4_ = (char *)pfStack_50;
          uStack_7c._4_4_ = pfVar10;
          FUN_007d74c0();
          pfVar9 = pfStack_4c;
        }
        else {
          *pfStack_50 = *pfVar10;
          pfStack_50 = pfStack_50 + 1;
        }
        pfVar10 = pfVar10 + 5;
      } while (pfVar10 != param_6);
    }
    uStack_7c._4_4_ = (float *)(iVar7 + 0x1c);
    param_6 = &fStack_9c;
    fStack_9c = fVar2;
    fStack_98 = fVar13;
    fStack_94 = fVar1;
    fStack_90 = fVar3;
    fStack_8c = fVar12;
    fStack_88 = fVar14;
    FUN_0071ee30(&iStack_54);
    FUN_008612b0(&iStack_34);
    pfVar10 = *(float **)(iVar7 + 4);
    if (pfVar10 != *(float **)(iVar7 + 8)) {
      param_2 = (fVar2 - fVar1) * fVar14 - (fVar13 - fVar3) * fVar12;
      do {
        if (NAN(param_2) == (param_2 == 0.0)) {
          param_6 = (float *)(((*pfVar10 - fVar1) * fVar14 + (fVar3 - pfVar10[1]) * fVar12) /
                             param_2);
        }
        uStack_7c._0_4_ = (char *)&fStack_38;
        uStack_7c._4_4_ = (float *)(DAT_018ce2f8 - (float)param_6);
        pfStack_80 = (float *)0x861ae3;
        pfVar9 = (float *)FUN_01159ab0();
        pfVar10[2] = *pfVar9;
        pfVar10[3] = pfVar9[1];
        pfVar10[4] = pfVar9[2];
        pfVar10[5] = pfVar9[3];
        if (param_9 < 0) {
          fVar13 = (float)((uint)pfVar10[1] ^ DAT_018c4ea0);
        }
        else {
          fVar13 = (float)param_9 - pfVar10[1];
        }
        pfVar10[1] = fVar13;
        pfVar10 = pfVar10 + 8;
      } while (pfVar10 != *(float **)(iVar7 + 8));
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (iStack_54 != 0) {
      uStack_7c._4_4_ = (float *)(((int)pfStack_4c - iStack_54 >> 2) * 4);
      iVar11 = iStack_54;
      if (0xfff < uStack_7c._4_4_) {
        iVar11 = *(int *)(iStack_54 + -4);
        uStack_7c._4_4_ = (float *)((int)uStack_7c._4_4_ + 0x23);
        if (0x1f < (iStack_54 - iVar11) - 4U) {
                    /* WARNING: Subroutine does not return */
          uStack_7c._4_4_ = (float *)&UNK_00861c8c;
          FUN_017167a3();
        }
      }
      pfStack_80 = (float *)0x861b8b;
      uStack_7c._0_4_ = (char *)iVar11;
      FUN_01674ea0();
    }
  }
  uStack_8 = 3;
  pfStack_80 = (float *)uStack_24;
  piStack_84 = (int *)uStack_28;
  fStack_88 = 1.2316026e-38;
  uStack_7c = uStack_40;
  FUN_0152dda0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13192 ; VA 0x00861c90 ; FUN_00861c90 */

uint __thiscall
FUN_00861c90(int *param_1,float param_2,float param_3,float param_4,float param_5,int param_6)

{
  float fVar1;
  float fVar2;
  float *pfVar3;
  float *pfVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  int *piVar8;
  float *pfVar9;
  int iVar10;
  int *piVar11;
  int iVar12;
  int *piVar13;
  float fVar14;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  int *piStack_10;
  int *piStack_c;
  int *piStack_8;
  
  fStack_30 = 0.0;
  fStack_2c = 0.0;
  piVar13 = (int *)param_1[2];
  piStack_8 = (int *)0x0;
  piStack_c = (int *)0x0;
  pfVar3 = (float *)*piVar13;
  pfVar4 = (float *)piVar13[1];
  piStack_18 = (int *)piVar13[2];
  fVar1 = *pfVar4;
  fVar2 = pfVar4[1];
  fVar14 = (*pfVar3 - fVar1) * param_5 - (pfVar3[1] - fVar2) * param_4;
  piVar11 = (int *)((uint)CONCAT21((short)((uint)pfVar3 >> 0x10),
                                   (fVar14 == 0.0) << 6 | NAN(fVar14) << 2 | 2U | fVar14 < 0.0) << 8
                   );
  piStack_10 = piVar13;
  if (((NAN(fVar14) == (fVar14 == 0.0)) &&
      (fVar14 = ((fVar2 - param_3) * param_4 + (param_2 - fVar1) * param_5) / fVar14,
      DAT_018fd178 <= fVar14)) && (fVar14 <= DAT_01900c38)) {
    iVar5 = *piVar13;
    fStack_30 = fVar1 * (DAT_018ce2f8 - fVar14) + *pfVar3 * fVar14;
    fStack_2c = fVar2 * (DAT_018ce2f8 - fVar14) + *(float *)(iVar5 + 4) * fVar14;
    fStack_20 = (*(float *)(iVar5 + 0x18) - pfVar4[6]) * fVar14 + pfVar4[6];
    piStack_1c = (int *)((*(float *)(iVar5 + 0x1c) - pfVar4[7]) * fVar14 + pfVar4[7]);
    FUN_00860e50(&fStack_30,&fStack_20);
    iVar5 = param_1[1];
    puVar6 = *(undefined4 **)(iVar5 + 4);
    piStack_8 = (int *)(*(int *)(*param_1 + 4) + -0x20);
    if (*(undefined4 **)(iVar5 + 8) == puVar6) {
      FUN_008609f0(puVar6,&piStack_8,piVar13 + 1);
    }
    else {
      iVar7 = piVar13[1];
      *puVar6 = piStack_8;
      puVar6[1] = iVar7;
      puVar6[2] = 0;
      *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 0xc;
    }
    iVar5 = *(int *)(param_1[1] + 4);
    *(int *)(iVar5 + -4) = piVar13[2];
    piVar11 = piVar13 + 1;
    piVar13[2] = iVar5 + -0xc;
    *piVar11 = (int)piStack_8;
    piStack_10 = (int *)param_1[2];
  }
  piVar13 = piStack_8;
  if (piStack_18 != piStack_10) {
    do {
      pfVar3 = (float *)piStack_18[1];
      piStack_1c = piStack_18 + 2;
      piVar8 = (int *)*piStack_1c;
      piStack_14 = piStack_18 + 1;
      pfVar4 = (float *)*piStack_18;
      fVar1 = *pfVar3;
      fVar2 = pfVar3[1];
      piStack_10 = (int *)pfVar4[1];
      fVar14 = (*pfVar4 - fVar1) * param_5 - ((float)piStack_10 - fVar2) * param_4;
      piVar11 = (int *)((uint)CONCAT21((short)((uint)piStack_14 >> 0x10),
                                       (fVar14 == 0.0) << 6 | NAN(fVar14) << 2 | 2U | fVar14 < 0.0)
                       << 8);
      piStack_18 = piVar8;
      if (((NAN(fVar14) == (fVar14 == 0.0)) &&
          (fVar14 = ((fVar2 - param_3) * param_4 + (param_2 - fVar1) * param_5) / fVar14,
          DAT_018fd178 <= fVar14)) && (fVar14 <= DAT_01900c38)) {
        iVar5 = *param_1;
        pfVar9 = *(float **)(iVar5 + 4);
        fStack_30 = fVar1 * (DAT_018ce2f8 - fVar14) + *pfVar4 * fVar14;
        fStack_2c = fVar2 * (DAT_018ce2f8 - fVar14) + (float)piStack_10 * fVar14;
        fStack_28 = (pfVar4[6] - pfVar3[6]) * fVar14 + pfVar3[6];
        fStack_24 = (pfVar4[7] - pfVar3[7]) * fVar14 + pfVar3[7];
        if (*(float **)(iVar5 + 8) == pfVar9) {
          FUN_00860cc0(pfVar9,&fStack_30,&fStack_28);
        }
        else {
          *pfVar9 = fStack_30;
          pfVar9[1] = fStack_2c;
          pfVar9[2] = 1.0;
          pfVar9[3] = 1.0;
          pfVar9[4] = 1.0;
          pfVar9[5] = 1.0;
          pfVar9[6] = fStack_28;
          pfVar9[7] = fStack_24;
          *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 0x20;
        }
        piStack_10 = (int *)(*(int *)(*param_1 + 4) + -0x20);
        piVar11 = piStack_10;
        if (piVar13 == (int *)0x0) {
          piVar13 = piStack_10;
          piVar11 = piStack_c;
          piStack_8 = piStack_10;
        }
        piStack_c = piVar11;
        iVar5 = param_1[1];
        puVar6 = *(undefined4 **)(iVar5 + 4);
        if (*(undefined4 **)(iVar5 + 8) == puVar6) {
          FUN_008609f0(puVar6,&piStack_10,piStack_14);
        }
        else {
          iVar7 = *piStack_14;
          *puVar6 = piStack_10;
          puVar6[1] = iVar7;
          puVar6[2] = 0;
          *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 0xc;
        }
        iVar5 = *(int *)(param_1[1] + 4);
        *(int *)(iVar5 + -4) = *piStack_1c;
        *piStack_1c = iVar5 + -0xc;
        *piStack_14 = (int)piStack_10;
        piVar11 = piStack_14;
      }
    } while (piStack_18 != (int *)param_1[2]);
  }
  if (((piVar13 != (int *)0x0) && (piVar11 = piStack_c, piStack_c != (int *)0x0)) &&
     (piVar13 != piStack_c)) {
    piVar11 = (int *)*piStack_18;
    piVar8 = piStack_18;
    while (piVar11 != piVar13) {
      piVar8 = (int *)piVar8[2];
      piVar11 = (int *)*piVar8;
    }
    *(int **)(param_6 + 8) = piVar8;
    piVar11 = (int *)piVar8[1];
    while (piVar11 != piStack_c) {
      piVar8 = (int *)piVar8[2];
      piVar11 = (int *)piVar8[1];
    }
    iVar5 = piVar8[2];
    FUN_00860e00(&piStack_c,&piStack_8);
    iVar7 = *(int *)(param_1[1] + 4);
    piVar8[2] = iVar7 + -0xc;
    *(undefined4 *)(iVar7 + -4) = *(undefined4 *)(param_6 + 8);
    piVar11 = *(int **)(iVar5 + 4);
    iVar7 = iVar5;
    while (piVar11 != piStack_8) {
      iVar7 = *(int *)(iVar7 + 8);
      piVar11 = *(int **)(iVar7 + 4);
    }
    FUN_00860e00(&piStack_8,&piStack_c);
    iVar10 = *(int *)(param_1[1] + 4);
    iVar12 = iVar10 + -0xc;
    *(int *)(iVar7 + 8) = iVar12;
    *(int *)(iVar10 + -4) = iVar5;
    param_1[2] = iVar5;
    return CONCAT31((int3)((uint)iVar12 >> 8),1);
  }
  return (uint)piVar11 & 0xffffff00;
}



/* FUNCTION 13193 ; VA 0x008620b0 ; FUN_008620b0 */

int __thiscall FUN_008620b0(uint *param_1,uint param_2,float *param_3,float *param_4,float *param_5)

{
  int iVar1;
  float fVar2;
  float fVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  float fVar11;
  
  uVar10 = *param_1;
  iVar8 = param_2 - uVar10;
  iVar1 = (int)(param_1[1] - uVar10) / 0xc;
  if (iVar1 == 0x15555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar6 = iVar1 + 1;
  uVar4 = (int)(param_1[2] - uVar10) / 0xc;
  uVar10 = uVar6;
  if ((uVar4 <= 0x15555555 - (uVar4 >> 1)) && (uVar10 = (uVar4 >> 1) + uVar4, uVar10 < uVar6)) {
    uVar10 = uVar6;
  }
  uVar6 = uVar10 * 0xc;
  if (uVar10 < 0x15555556) {
    uVar10 = uVar6;
    if (0xfff < uVar6) goto LAB_00862148;
    if (uVar6 == 0) {
      uVar10 = 0;
    }
    else {
      uVar10 = FUN_01674e20(uVar6);
    }
  }
  else {
    uVar10 = 0xffffffff;
LAB_00862148:
    uVar4 = uVar10 + 0x23;
    if (uVar4 <= uVar10) {
      uVar4 = 0xffffffff;
    }
    iVar5 = FUN_01674e20(uVar4);
    if (iVar5 == 0) goto LAB_00862319;
    uVar10 = iVar5 + 0x23U & 0xffffffe0;
    *(int *)(uVar10 - 4) = iVar5;
  }
  fVar3 = DAT_018f9980;
  iVar8 = (iVar8 / 0xc) * 0xc;
  fVar11 = *param_4 * DAT_0191add4;
  *(short *)(iVar8 + uVar10) = (short)(int)(*param_3 * DAT_018f9980);
  *(short *)(iVar8 + 2 + uVar10) = (short)(int)(param_3[1] * fVar3);
  fVar2 = DAT_018f8ff8;
  *(short *)(iVar8 + 4 + uVar10) = (short)(int)(param_3[2] * fVar3);
  fVar3 = DAT_01900a1c;
  *(short *)(iVar8 + 6 + uVar10) = (short)(int)fVar11;
  *(char *)(iVar8 + 8 + uVar10) = (char)(int)(*param_5 * fVar3 + fVar2);
  *(char *)(iVar8 + 9 + uVar10) = (char)(int)(param_5[1] * fVar3 + fVar2);
  *(char *)(iVar8 + 10 + uVar10) = (char)(int)(param_5[2] * fVar3 + fVar2);
  uVar4 = *param_1;
  if (param_2 == param_1[1]) {
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    FUN_0170cc70(uVar10,uVar4,param_1[1] - uVar4);
  }
  else {
    FUN_0055b6b0((int)&param_4 + 3,&param_4,&param_4);
    FUN_0170cc70(uVar10,uVar4,param_2 - uVar4);
    FUN_0055b6b0((int)&param_4 + 3,&param_4,&param_4);
    FUN_0170cc70(iVar8 + 0xc + uVar10,param_2,param_1[1] - param_2);
  }
  uVar4 = *param_1;
  if (uVar4 != 0) {
    uVar7 = ((int)(param_1[2] - uVar4) / 0xc) * 0xc;
    uVar9 = uVar4;
    if (0xfff < uVar7) {
      uVar9 = *(uint *)(uVar4 - 4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (uVar4 - uVar9) - 4) {
LAB_00862319:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar7);
  }
  *param_1 = uVar10;
  param_1[1] = uVar10 + (iVar1 * 3 + 3) * 4;
  param_1[2] = uVar6 + uVar10;
  return *param_1 + iVar8;
}



/* FUNCTION 13194 ; VA 0x00862330 ; FUN_00862330 */

undefined4 * __fastcall FUN_00862330(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = 2;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  do {
    FUN_00569440();
    iVar1 = iVar1 + -1;
  } while (iVar1 != 0);
  iVar1 = 2;
  do {
    FUN_00569440();
    iVar1 = iVar1 + -1;
  } while (iVar1 != 0);
  return param_1;
}



/* FUNCTION 13195 ; VA 0x00862380 ; FUN_00862380 */

undefined4 * __thiscall FUN_00862380(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Graphics::GrassRenderEntity::vftable;
  FUN_00841390();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x7c);
  }
  return param_1;
}



/* FUNCTION 13196 ; VA 0x008623b0 ; FUN_008623b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint __thiscall
FUN_008623b0(int param_1,int *param_2,float *param_3,undefined4 *param_4,undefined4 param_5,
            undefined4 param_6)

{
  undefined8 uVar1;
  char cVar2;
  int iVar3;
  undefined2 *puVar4;
  undefined4 uVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  uint uVar10;
  float *pfVar11;
  float *pfVar12;
  int iVar13;
  uint uVar14;
  float *pfVar15;
  uint uVar16;
  float10 fVar17;
  double dVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  int iStack_88;
  uint uStack_84;
  undefined8 *puStack_7c;
  undefined8 *puStack_6c;
  undefined8 *puStack_68;
  float fStack_64;
  float fStack_58;
  float fStack_54;
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  
  param_4[1] = *param_4;
  iVar13 = param_2[3];
  uStack_84 = 0;
  puStack_7c = (undefined8 *)0x0;
  if ((uint)(param_2[4] - iVar13 >> 2) / 3 != 0) {
    iStack_88 = 0;
    do {
      if (*(char *)(((uint)puStack_7c >> 1) + param_2[6]) == '\0') {
        iVar3 = *param_2;
        pfVar11 = (float *)(*(int *)(iVar13 + iStack_88) * 0x10 + iVar3);
        pfVar15 = (float *)(*(int *)(iVar13 + 4 + iStack_88) * 0x10 + iVar3);
        pfVar12 = (float *)(*(int *)(iVar13 + 8 + iStack_88) * 0x10 + iVar3);
        if ((((*(char *)(pfVar11 + 3) == '\0') && (*(char *)(pfVar15 + 3) == '\0')) &&
            (*(char *)(pfVar12 + 3) == '\0')) &&
           (((cVar2 = *(char *)(param_1 + 0x80), *(char *)((int)pfVar11 + 0xd) == cVar2 ||
             (*(char *)((int)pfVar15 + 0xd) == cVar2)) || (*(char *)((int)pfVar12 + 0xd) == cVar2)))
           ) {
          fVar19 = (pfVar12[2] - pfVar11[2]) * (pfVar15[1] - pfVar11[1]) -
                   (pfVar12[1] - pfVar11[1]) * (pfVar15[2] - pfVar11[2]);
          fVar20 = (*pfVar12 - *pfVar11) * (pfVar15[2] - pfVar11[2]) -
                   (pfVar12[2] - pfVar11[2]) * (*pfVar15 - *pfVar11);
          puStack_6c = (undefined8 *)
                       ((pfVar12[1] - pfVar11[1]) * (*pfVar15 - *pfVar11) -
                       (*pfVar12 - *pfVar11) * (pfVar15[1] - pfVar11[1]));
          dVar18 = (double)(fVar19 * fVar19 + fVar20 * fVar20 +
                           (float)puStack_6c * (float)puStack_6c);
          FUN_017267a0();
          fVar21 = DAT_018ce2f8 / (float)dVar18;
          fVar19 = fVar19 * fVar21;
          fStack_64 = fVar21 * (float)puStack_6c;
          puStack_68 = (undefined8 *)(fVar21 * fVar20);
          fStack_58 = fVar19;
          fStack_54 = (float)puStack_68;
          fStack_50 = fStack_64;
          if (DAT_01901f3c <= fVar19 * 0.0 + (float)puStack_68 + fStack_64 * 0.0) {
            iVar13 = ((uint)*(ushort *)((int)pfVar12 + 0xe) * 0x100 +
                     (uint)*(ushort *)((int)pfVar15 + 0xe)) * 0x100 +
                     (uint)*(ushort *)((int)pfVar11 + 0xe);
            FUN_01679a70(iVar13,0);
            uStack_84 = uStack_84 ^ (uStack_84 >> 2) + 0x9e3779b9 + uStack_84 * 0x40 + iVar13;
            fVar17 = (float10)FUN_01679f10(_DAT_0191ade0,_UNK_0191ade4,_UNK_0191ade8,_UNK_0191adec);
            puStack_6c = (undefined8 *)(float)fVar17;
            fVar17 = (float10)FUN_01679f10(_DAT_0191ade0,_UNK_0191ade4,_UNK_0191ade8,_UNK_0191adec);
            fVar9 = DAT_018f9980;
            fVar8 = DAT_018f8ff8;
            fVar20 = (float)fVar17;
            fVar22 = (DAT_018ce2f8 - (float)puStack_6c) - fVar20;
            fStack_4c = (*pfVar15 * fVar20 + *pfVar11 * (float)puStack_6c + *pfVar12 * fVar22) *
                        DAT_018e3f8c - (param_3[3] + *param_3) * DAT_018ce2f4;
            fStack_48 = (pfVar11[1] * (float)puStack_6c + fVar20 * pfVar15[1] + pfVar12[1] * fVar22)
                        * DAT_018e3f8c - (param_3[4] + param_3[1]) * DAT_018ce2f4;
            fStack_44 = (pfVar11[2] * (float)puStack_6c + fVar20 * pfVar15[2] + pfVar12[2] * fVar22)
                        * DAT_018e3f8c - (param_3[5] + param_3[2]) * DAT_018ce2f4;
            cVar2 = *(char *)(param_1 + 0x80);
            fVar21 = DAT_018ce2f8;
            if (*(char *)((int)pfVar11 + 0xd) != cVar2) {
              fVar21 = 0.0;
            }
            fVar6 = DAT_018ce2f8;
            if (*(char *)((int)pfVar15 + 0xd) != cVar2) {
              fVar6 = 0.0;
            }
            fVar7 = DAT_018ce2f8;
            if (*(char *)((int)pfVar12 + 0xd) != cVar2) {
              fVar7 = 0.0;
            }
            puVar4 = (undefined2 *)param_4[1];
            puStack_6c = (undefined8 *)
                         (fVar7 * fVar22 + fVar6 * fVar20 + fVar21 * (float)puStack_6c);
            if ((undefined2 *)param_4[2] == puVar4) {
              FUN_008620b0(puVar4,&fStack_4c,&puStack_6c,&fStack_58);
            }
            else {
              fVar21 = (float)puStack_6c * DAT_0191add4;
              fVar20 = fStack_48 * DAT_018f9980;
              *puVar4 = (short)(int)(fStack_4c * DAT_018f9980);
              puVar4[1] = (short)(int)fVar20;
              fVar20 = DAT_01900a1c;
              puVar4[2] = (short)(int)(fStack_44 * fVar9);
              puVar4[3] = (short)(int)fVar21;
              *(char *)(puVar4 + 4) = (char)(int)(fVar19 * fVar20 + fVar8);
              *(char *)((int)puVar4 + 9) = (char)(int)((float)puStack_68 * fVar20 + fVar8);
              *(char *)(puVar4 + 5) = (char)(int)(fStack_64 * fVar20 + fVar8);
              param_4[1] = param_4[1] + 0xc;
            }
          }
        }
      }
      iStack_88 = iStack_88 + 0xc;
      puStack_7c = (undefined8 *)((int)puStack_7c + 1);
      iVar13 = param_2[3];
    } while (puStack_7c < (uint)(param_2[4] - iVar13 >> 2) / 3);
  }
  FUN_01679a70(param_5,param_6);
  puStack_68 = (undefined8 *)*param_4;
  puStack_6c = (undefined8 *)param_4[1];
  if ((puStack_68 != puStack_6c) &&
     (puStack_7c = (undefined8 *)((int)puStack_68 + 0xc), puStack_7c != puStack_6c)) {
    uVar16 = 2;
    do {
      do {
        uVar14 = 0;
        uVar10 = 0;
        if (uVar16 != 1) {
          uVar14 = FUN_01679da0();
          uVar10 = 0xffffffff;
        }
        fStack_64 = (float)(uVar10 % uVar16);
      } while ((uVar10 / uVar16 <= uVar14 / uVar16) && (fStack_64 != (float)(uVar16 - 1)));
      uVar14 = uVar14 % uVar16;
      if (uVar14 != uVar16 - 1) {
        uVar1 = *puStack_7c;
        uVar5 = *(undefined4 *)(puStack_7c + 1);
        *puStack_7c = *(undefined8 *)((int)puStack_68 + uVar14 * 0xc);
        *(undefined4 *)(puStack_7c + 1) = *(undefined4 *)((int)puStack_68 + uVar14 * 0xc + 8);
        *(undefined8 *)((int)puStack_68 + uVar14 * 0xc) = uVar1;
        *(undefined4 *)((int)puStack_68 + uVar14 * 0xc + 8) = uVar5;
      }
      puStack_7c = (undefined8 *)((int)puStack_7c + 0xc);
      uVar16 = uVar16 + 1;
    } while (puStack_7c != puStack_6c);
  }
  return uStack_84;
}



/* FUNCTION 13197 ; VA 0x00862900 ; FUN_00862900 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __fastcall FUN_00862900(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  float10 fVar6;
  float fVar7;
  char *pcVar8;
  char *pcVar9;
  undefined4 uVar10;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  float fStack_4c;
  float fStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b868f;
  pvStack_10 = ExceptionList;
  piVar5 = (int *)(param_1 + 0x78);
  if (*(int *)(param_1 + 0x78) != 0) {
    return piVar5;
  }
  ExceptionList = &pvStack_10;
  piStack_18 = piVar5;
  fStack_20 = (float)FUN_01674e20(0x28);
  uStack_8 = 0;
  if (fStack_20 == 0.0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_0078dea0();
  }
  fStack_20 = 0.0;
  uStack_8 = 0xffffffff;
  fStack_24 = 0.0;
  FUN_0075cd20(uVar2,0);
  *piVar5 = (int)fStack_24;
  piStack_14 = *(int **)(param_1 + 0x7c);
  *(float *)(param_1 + 0x7c) = fStack_20;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar3 = piStack_14[2] + -1;
      piStack_14[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (DAT_01d60bc0 == '\0') {
    FUN_0078e420();
    FUN_008644b0(*(undefined4 *)(param_1 + 0x20),piVar5,"GrassHQVS","GrassHQFS",0,1);
    FUN_008644b0(*(undefined4 *)(param_1 + 0x20),piVar5,"GrassVS","GrassFS",0,2);
    FUN_008644b0(*(undefined4 *)(param_1 + 0x20),piVar5,"GrassHQVSShadowed","GrassHQFSShadowed",1,1)
    ;
    cVar1 = FUN_0078ba00();
    if (cVar1 == '\0') goto LAB_00862a89;
    uVar10 = 1;
    uVar2 = 2;
    pcVar9 = "GrassHQFSShadowedFSM";
    pcVar8 = "GrassHQVSShadowedFSM";
  }
  else {
    FUN_0078e420();
    iVar3 = FUN_0078e450(*(undefined4 *)(*(int *)(param_1 + 0x20) + 0x5c4));
    if (iVar3 == 0) {
      pcVar9 = "GrassHQFS";
      pcVar8 = "GrassHQVS";
    }
    else if (iVar3 == 1) {
      pcVar9 = "GrassHQFSShadowed";
      pcVar8 = "GrassHQVSShadowed";
    }
    else {
      iVar3 = 2;
      pcVar9 = "GrassHQFSShadowedFSM";
      pcVar8 = "GrassHQVSShadowedFSM";
    }
    FUN_008644b0(*(undefined4 *)(param_1 + 0x20),piVar5,pcVar8,pcVar9,iVar3,1);
    uVar10 = 2;
    uVar2 = 0;
    pcVar9 = "GrassFS";
    pcVar8 = "GrassVS";
  }
  FUN_008644b0(*(undefined4 *)(param_1 + 0x20),piVar5,pcVar8,pcVar9,uVar2,uVar10);
LAB_00862a89:
  iVar3 = (uint)*(byte *)(param_1 + 0x80) * 3;
  piStack_14 = (int *)(DAT_01d62394 * DAT_018e1340 + DAT_01d62398 * DAT_018ce2f4 +
                      DAT_01d6239c * DAT_018e1340);
  fStack_1c = DAT_01d62394 * DAT_018ce2f4 - DAT_01d6239c * DAT_018ce2f4;
  fStack_20 = (DAT_01d62398 * DAT_018ce2f4 - DAT_01d62394 * DAT_018e1340) -
              DAT_01d6239c * DAT_018e1340;
  FUN_00808710(&fStack_3c,*(int *)(*(int *)(param_1 + 0x24) + 0x16c) + iVar3,
               *(int *)(*(int *)(param_1 + 0x24) + 0x160) + iVar3);
  fVar7 = fStack_34 * fStack_20;
  fStack_28 = fStack_34 * fStack_1c + fStack_38 * fStack_20;
  fStack_20 = 1.0;
  fStack_24 = fStack_3c * (float)piStack_14 - fStack_28;
  fVar7 = fStack_38 * fStack_1c - fVar7;
  fStack_28 = fStack_3c * (float)piStack_14 + fStack_28;
  fStack_2c = fStack_24 + fVar7;
  fStack_24 = fStack_24 - fVar7;
  fStack_28 = fStack_28 * fStack_28;
  fStack_2c = fStack_2c * fStack_2c;
  fStack_24 = fStack_24 * fStack_24;
  *(float *)(param_1 + 0xac) = fStack_2c;
  *(float *)(param_1 + 0xb0) = fStack_28;
  *(float *)(param_1 + 0xb4) = fStack_24;
  *(undefined4 *)(param_1 + 0xb8) = 0x3f800000;
  fVar6 = (float10)FUN_01156f90(*(undefined4 *)(param_1 + 0x250));
  uStack_5c = *(undefined4 *)(param_1 + 0xac);
  uStack_58 = *(undefined4 *)(param_1 + 0xb0);
  uStack_54 = *(undefined4 *)(param_1 + 0xb4);
  uStack_50 = *(undefined4 *)(param_1 + 0xb8);
  fStack_48 = (float)fVar6;
  fStack_4c = *(float *)(*(int *)(*(int *)(param_1 + 0x20) + 0x4f8) + 0x108) * _DAT_0191adb0 +
              _DAT_0191add0;
  uStack_40 = 0;
  uStack_44 = *(undefined4 *)(*(int *)(param_1 + 0x20) + 0x28);
  if (*piVar5 != 0) {
    piStack_14 = (int *)0x0;
    fStack_20 = fStack_48;
    do {
      iVar3 = *(int *)(*piVar5 + 4 + (int)piStack_14);
      iVar4 = *(int *)(*piVar5 + (int)piStack_14);
      piVar5 = piStack_18;
      for (; piStack_18 = piVar5, iVar4 != iVar3; iVar4 = iVar4 + 0x50) {
        FUN_0078e4a0(2,&uStack_5c,0x20);
        piVar5 = piStack_18;
      }
      piStack_14 = (int *)((int)piStack_14 + 0xc);
    } while ((int)piStack_14 < 0x24);
  }
  ExceptionList = pvStack_10;
  return piVar5;
}



/* FUNCTION 13198 ; VA 0x00862c50 ; FUN_00862c50 */

void __thiscall FUN_00862c50(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined auStack_10 [12];
  
  uVar1 = (**(code **)(**(int **)(param_1 + 0x4c) + 100))(auStack_10,0);
  FUN_00841650(param_2,uVar1);
  return;
}



/* FUNCTION 13199 ; VA 0x00862c80 ; FUN_00862c80 */

uint FUN_00862c80(int param_1)

{
  uint uVar1;
  
  uVar1 = 0;
  do {
    if ((&DAT_0191ab48)[uVar1] == param_1) {
      return uVar1;
    }
    uVar1 = uVar1 + 1;
  } while (uVar1 < 0x17);
  return CONCAT31((int3)(uVar1 >> 8),2);
}



/* FUNCTION 13200 ; VA 0x00862cb0 ; FUN_00862cb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00862cb0(int param_1)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  ulonglong uVar5;
  uint uVar6;
  float *pfVar7;
  int *piVar8;
  uint uVar9;
  undefined4 *puVar10;
  undefined2 *puVar11;
  int iVar12;
  undefined2 *puVar13;
  int iVar14;
  undefined8 *puVar15;
  uint uVar16;
  float10 fVar17;
  double dVar18;
  undefined8 uVar19;
  undefined8 uVar20;
  float fVar21;
  float fVar22;
  float fVar23;
  undefined auStack_178 [36];
  undefined auStack_154 [36];
  undefined auStack_130 [44];
  float fStack_104;
  float fStack_f8;
  float fStack_ec;
  ulonglong uStack_e8;
  double dStack_e0;
  undefined8 uStack_d8;
  undefined8 uStack_d0;
  undefined8 uStack_c8;
  undefined8 uStack_c0;
  float fStack_b4;
  float fStack_b0;
  float fStack_ac;
  float fStack_a8;
  float fStack_a4;
  float fStack_a0;
  float fStack_9c;
  float fStack_98;
  float fStack_94;
  float fStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  float fStack_7c;
  undefined8 uStack_78;
  float fStack_70;
  float fStack_6c;
  undefined8 uStack_68;
  int iStack_60;
  int iStack_54;
  float fStack_48;
  undefined uStack_41;
  undefined8 uStack_40;
  int *piStack_34;
  float fStack_30;
  undefined *puStack_2c;
  undefined *puStack_28;
  undefined4 *puStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017b86b0;
  pvStack_1c = ExceptionList;
  uVar6 = 0;
  do {
    if ((&DAT_0191ab48)[uVar6] == 0x500) goto LAB_00862d05;
    uVar6 = uVar6 + 1;
  } while (uVar6 < 0x17);
  uVar6 = 2;
LAB_00862d05:
  ExceptionList = &pvStack_1c;
  *(char *)(param_1 + 0x80) = (char)uVar6;
  *(undefined4 *)(param_1 + 0xbc) = 0;
  *(undefined4 *)(param_1 + 0xc0) = 0;
  *(undefined4 *)(param_1 + 0xc4) = 0;
  *(undefined4 *)(param_1 + 200) = 0;
  uVar4 = _UNK_018e004c;
  uVar3 = _UNK_018e0048;
  uVar2 = _UNK_018e0044;
  *(undefined4 *)(param_1 + 0xac) = _DAT_018e0040;
  *(undefined4 *)(param_1 + 0xb0) = uVar2;
  *(undefined4 *)(param_1 + 0xb4) = uVar3;
  *(undefined4 *)(param_1 + 0xb8) = uVar4;
  iStack_54 = param_1;
  FUN_01679a70(0xdeadbeef,0);
  puVar15 = &DAT_01eb49cc;
  uStack_c0 = DAT_0191ada8;
  uStack_c8 = DAT_0191ad90;
  uStack_d0 = DAT_01901948;
  uStack_d8 = 0;
  uStack_68 = DAT_0191adb8;
  uStack_78 = DAT_0191ada0;
  dStack_e0 = _PTR_018cf0f8;
  do {
    fVar17 = (float10)FUN_01679f10(uStack_78,uStack_68);
    fStack_30 = (float)fVar17;
    fVar17 = (float10)FUN_01679f10(uStack_c8,uStack_c0);
    puStack_24 = (undefined4 *)(float)fVar17;
    puStack_28 = (undefined *)((float)puStack_24 + fStack_30);
    fVar17 = (float10)FUN_01679f10(uStack_d8,uStack_d0);
    puStack_24 = (undefined4 *)(float)fVar17;
    fVar17 = (float10)FUN_01679fb0();
    uStack_40 = (double)fVar17;
    fVar21 = DAT_018f7864;
    if (dStack_e0 < uStack_40) {
      fVar21 = DAT_018ce2f8;
    }
    FUN_01161480(&fStack_b4,0,fVar21 * (float)puStack_24,0);
    FUN_01161480(auStack_130,fStack_30,0,0);
    FUN_01161480(auStack_154,puStack_28,0,0);
    puStack_24 = (undefined4 *)(fStack_b0 * 0.0 + fStack_b4 + fStack_ac * 0.0);
    fStack_30 = fStack_a4 * 0.0 + fStack_a8 + fStack_a0 * 0.0;
    fStack_88 = fStack_98 * 0.0 + fStack_9c + fStack_94 * 0.0;
    pfVar7 = (float *)FUN_01160c20(auStack_178,auStack_130);
    puStack_28 = (undefined *)(*pfVar7 * 0.0 + pfVar7[1] + pfVar7[2] * 0.0);
    fStack_48 = pfVar7[3] * 0.0 + pfVar7[4] + pfVar7[5] * 0.0;
    fStack_ec = pfVar7[6] * 0.0 + pfVar7[7] + pfVar7[8] * 0.0;
    pfVar7 = (float *)FUN_01160c20(auStack_178,auStack_154);
    puStack_2c = (undefined *)(*pfVar7 * 0.0 + pfVar7[1] + pfVar7[2] * 0.0);
    fStack_6c = pfVar7[3] * 0.0 + pfVar7[4] + pfVar7[5] * 0.0;
    fStack_7c = pfVar7[6] * 0.0 + pfVar7[7] + pfVar7[8] * 0.0;
    *(ulonglong *)((int)puVar15 + -0xc) = CONCAT44(fStack_30,puStack_24);
    *(float *)((int)puVar15 + -4) = fStack_88;
    fVar23 = fStack_48 - fStack_30;
    *puVar15 = CONCAT44(fStack_48,puStack_28);
    *(ulonglong *)((int)puVar15 + 0xc) = CONCAT44(fStack_6c,puStack_2c);
    fVar22 = (float)puStack_24 + (float)puStack_24;
    *(float *)(puVar15 + 1) = fStack_ec;
    *(float *)((int)puVar15 + 0x14) = fStack_7c;
    piStack_34 = (int *)(fStack_30 + fStack_30);
    fStack_70 = fStack_88 + fStack_88;
    fVar21 = fStack_70 * fVar23 - (float)piStack_34 * (fStack_ec - fStack_88);
    fStack_48 = fVar22 * (fStack_ec - fStack_88) -
                fStack_70 * ((float)puStack_28 - (float)puStack_24);
    uStack_e8 = (ulonglong)(uint)fVar21;
    puStack_28 = (undefined *)
                 ((float)piStack_34 * ((float)puStack_28 - (float)puStack_24) - fVar22 * fVar23);
    dVar18 = (double)(fStack_48 * fStack_48 + fVar21 * fVar21 +
                     (float)puStack_28 * (float)puStack_28);
    uStack_40._4_4_ = fVar22;
    FUN_017267a0();
    fVar21 = DAT_018ce2f8 / (float)dVar18;
    fStack_f8 = (float)puStack_28 * fVar21;
    puVar15[3] = CONCAT44(fStack_48 * fVar21,(float)uStack_e8 * fVar21);
    *(float *)(puVar15 + 4) = fStack_f8;
    fVar22 = fStack_70 * (fStack_6c - fStack_30) - (float)piStack_34 * (fStack_7c - fStack_88);
    fVar21 = uStack_40._4_4_ * (fStack_7c - fStack_88) -
             ((float)puStack_2c - (float)puStack_24) * fStack_70;
    puStack_2c = (undefined *)
                 (((float)puStack_2c - (float)puStack_24) * (float)piStack_34 -
                 uStack_40._4_4_ * (fStack_6c - fStack_30));
    uStack_40 = (double)CONCAT44(fVar21,(undefined4)uStack_40);
    dVar18 = (double)(fVar21 * fVar21 + fVar22 * fVar22 + (float)puStack_2c * (float)puStack_2c);
    piStack_34 = (int *)fVar22;
    FUN_017267a0();
    fVar21 = DAT_018ce2f8 / (float)dVar18;
    fStack_104 = fVar21 * (float)puStack_2c;
    *(ulonglong *)((int)puVar15 + 0x24) =
         CONCAT44(fVar21 * uStack_40._4_4_,fVar21 * (float)piStack_34);
    *(float *)((int)puVar15 + 0x2c) = fStack_104;
    puVar15 = (undefined8 *)((int)puVar15 + 0x3c);
  } while ((int)puVar15 < 0x1ec39cc);
  fStack_30 = 0.0;
  puStack_28 = &DAT_01ec39e0;
  puStack_2c = &DAT_01ec79f4;
  uVar19 = DAT_01900430;
  uVar20 = _UNK_01900438;
  do {
    piVar8 = (int *)(puStack_2c + -0x34);
    iVar14 = 0;
    do {
      iVar12 = iVar14 + 4;
      *piVar8 = iVar14 + (int)uVar19;
      piVar8[1] = iVar14 + (int)((ulonglong)uVar19 >> 0x20);
      piVar8[2] = iVar14 + (int)uVar20;
      piVar8[3] = iVar14 + (int)((ulonglong)uVar20 >> 0x20);
      piVar8 = piVar8 + 4;
      iVar14 = iVar12;
    } while (iVar12 < 0xc);
    if (iVar12 < 0xd) {
      piVar8 = (int *)(&DAT_01ec79c0 + ((int)fStack_30 + iVar12) * 4);
      do {
        *piVar8 = iVar12;
        piVar8 = piVar8 + 1;
        iVar12 = iVar12 + 1;
      } while (iVar12 < 0xd);
    }
    if (puStack_2c + -0x34 != puStack_2c) {
      uStack_40 = (double)((ulonglong)uStack_40 & 0xffffffff);
      uVar5 = (ulonglong)uStack_40;
      puStack_24 = (undefined4 *)(puStack_2c + -0x30);
      uStack_40._4_4_ = 0.0;
      piStack_34 = (int *)((uint)(puStack_2c + (3 - (int)(puStack_2c + -0x30))) >> 2);
      if (puStack_2c < puStack_2c + -0x30) {
        piStack_34 = (int *)uStack_40._4_4_;
      }
      uStack_40 = (double)uVar5;
      if (piStack_34 != (int *)0x0) {
        uVar6 = 2;
        do {
          do {
            uVar16 = 0;
            uVar9 = 0;
            if (uVar6 != 1) {
              uVar16 = FUN_01679da0();
              uVar9 = 0xffffffff;
            }
            uStack_40 = (double)CONCAT44(uVar9 % uVar6,(undefined4)uStack_40);
          } while ((uVar9 / uVar6 <= uVar16 / uVar6) && (uVar9 % uVar6 != uVar6 - 1));
          uVar16 = uVar16 % uVar6;
          if (uVar16 != uVar6 - 1) {
            uVar2 = *puStack_24;
            *puStack_24 = *(undefined4 *)(puStack_2c + uVar16 * 4 + -0x34);
            *(undefined4 *)(puStack_2c + uVar16 * 4 + -0x34) = uVar2;
          }
          puStack_24 = puStack_24 + 1;
          fVar21 = (float)(uVar6 - 1);
          uVar19 = DAT_01900430;
          uVar20 = _UNK_01900438;
          uVar6 = uVar6 + 1;
        } while ((int *)fVar21 != piStack_34);
      }
    }
    iVar14 = 0;
    piVar8 = (int *)(puStack_28 + -0x20);
    do {
      iVar12 = iVar14 + 4;
      *piVar8 = iVar14 + (int)uVar19;
      piVar8[1] = iVar14 + (int)((ulonglong)uVar19 >> 0x20);
      piVar8[2] = iVar14 + (int)uVar20;
      piVar8[3] = iVar14 + (int)((ulonglong)uVar20 >> 0x20);
      iVar14 = iVar12;
      piVar8 = piVar8 + 4;
    } while (iVar12 < 8);
    if (puStack_28 + -0x20 != puStack_28) {
      uStack_40 = (double)((ulonglong)uStack_40 & 0xffffffff);
      uVar5 = (ulonglong)uStack_40;
      puStack_24 = (undefined4 *)(puStack_28 + -0x1c);
      uStack_40._4_4_ = 0.0;
      piStack_34 = (int *)((uint)(puStack_28 + (3 - (int)(puStack_28 + -0x1c))) >> 2);
      if (puStack_28 < puStack_28 + -0x1c) {
        piStack_34 = (int *)uStack_40._4_4_;
      }
      uStack_40 = (double)uVar5;
      if (piStack_34 != (int *)0x0) {
        uVar6 = 2;
        do {
          do {
            uVar16 = 0;
            uVar9 = 0;
            if (uVar6 != 1) {
              uVar16 = FUN_01679da0();
              uVar9 = 0xffffffff;
            }
            uStack_40 = (double)CONCAT44(uVar9 % uVar6,(undefined4)uStack_40);
          } while ((uVar9 / uVar6 <= uVar16 / uVar6) && (uVar9 % uVar6 != uVar6 - 1));
          uVar16 = uVar16 % uVar6;
          if (uVar16 != uVar6 - 1) {
            uVar2 = *puStack_24;
            *puStack_24 = *(undefined4 *)(puStack_28 + uVar16 * 4 + -0x20);
            *(undefined4 *)(puStack_28 + uVar16 * 4 + -0x20) = uVar2;
          }
          puStack_24 = puStack_24 + 1;
          fVar21 = (float)(uVar6 - 1);
          uVar19 = DAT_01900430;
          uVar20 = _UNK_01900438;
          uVar6 = uVar6 + 1;
        } while ((int *)fVar21 != piStack_34);
      }
    }
    puStack_2c = puStack_2c + 0x34;
    fStack_30 = (float)((int)fStack_30 + 0xd);
    puStack_28 = puStack_28 + 0x20;
  } while ((int)puStack_2c < 0x1ece1f4);
  FUN_0071edc0(0x1ccb0,&uStack_41);
  iVar14 = iStack_54;
  uStack_14 = 0;
  puVar10 = (undefined4 *)
            (**(code **)(**(int **)(*(int *)(iStack_54 + 0x20) + 0x3c) + 0x3c))
                      (&uStack_78,1,0x39960,2,0);
  uVar2 = *puVar10;
  uVar3 = puVar10[1];
  *puVar10 = 0;
  puVar10[1] = 0;
  *(undefined4 *)(iVar14 + 0x48) = uVar2;
  piVar8 = *(int **)(iVar14 + 0x4c);
  *(undefined4 *)(iVar14 + 0x4c) = uVar3;
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar14 = piVar8[1] + -1;
    piVar8[1] = iVar14;
    UNLOCK();
    if (iVar14 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      iVar14 = piVar8[2] + -1;
      piVar8[2] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  piVar8 = uStack_78._4_4_;
  if (uStack_78._4_4_ != (int *)0x0) {
    LOCK();
    iVar14 = uStack_78._4_4_[1] + -1;
    uStack_78._4_4_[1] = iVar14;
    UNLOCK();
    if (iVar14 == 0) {
      (**(code **)*uStack_78._4_4_)();
      LOCK();
      piVar1 = piVar8 + 2;
      iVar14 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar14 == 1) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  iVar14 = 2;
  piVar8 = (int *)((int)(undefined2 *)uStack_68 + 8);
  do {
    piVar8[-2] = iVar14 + -2;
    piVar8[-1] = iVar14 + -1;
    *piVar8 = iVar14;
    piVar8[1] = iVar14 + -1;
    piVar8[2] = iVar14;
    piVar8[3] = iVar14 + 1;
    piVar8[4] = iVar14;
    piVar8[5] = iVar14 + 1;
    iVar12 = iVar14 + 2;
    iVar14 = iVar14 + 5;
    piVar8[6] = iVar12;
    piVar8 = piVar8 + 9;
  } while (iVar14 < 0xfff2);
  uStack_84 = 0;
  uStack_80 = 0;
  fStack_7c = 0.0;
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  piStack_34 = *(int **)(iStack_54 + 0x48);
  puVar11 = (undefined2 *)(**(code **)(*piStack_34 + 0x10))();
  uVar16 = 0;
  uVar6 = (uint)((int)uStack_68._4_4_ + (3 - (int)(undefined2 *)uStack_68)) >> 2;
  if (uStack_68._4_4_ < (undefined2 *)uStack_68) {
    uVar6 = 0;
  }
  puVar13 = (undefined2 *)uStack_68;
  if (uVar6 != 0) {
    do {
      uVar16 = uVar16 + 1;
      *puVar11 = *puVar13;
      puVar13 = puVar13 + 2;
      puVar11 = puVar11 + 1;
    } while (uVar16 != uVar6);
  }
  (**(code **)(*piStack_34 + 0x14))();
  if ((undefined2 *)uStack_68 != (undefined2 *)0x0) {
    uVar6 = iStack_60 - (int)(undefined2 *)uStack_68 & 0xfffffffc;
    iVar14 = (int)(undefined2 *)uStack_68;
    if (0xfff < uVar6) {
      iVar14 = *(int *)((int)(undefined2 *)uStack_68 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < ((int)(undefined2 *)uStack_68 - iVar14) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar14,uVar6);
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 13201 ; VA 0x00863610 ; FUN_00863610 */

bool __thiscall FUN_00863610(int param_1,char param_2)

{
  return param_2 == *(char *)(param_1 + 0x80);
}



/* FUNCTION 13202 ; VA 0x00863630 ; FUN_00863630 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00863630(undefined4 param_1,float *param_2,undefined4 param_3,undefined8 *param_4,
                 float param_5,char param_6)

{
  undefined8 uVar1;
  undefined8 uVar2;
  float fVar3;
  float fVar4;
  undefined uVar5;
  undefined uVar6;
  int iVar7;
  uint uVar8;
  undefined2 uVar9;
  float10 fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  double dVar20;
  float fVar21;
  float fVar22;
  float fVar23;
  float fVar24;
  float fVar25;
  float fVar26;
  float fVar27;
  float fVar28;
  float fVar29;
  float fVar30;
  float fVar31;
  undefined4 uStack_28;
  float fStack_20;
  float fStack_1c;
  float fStack_14;
  float fStack_10;
  
  fVar11 = 0.0;
  if (0.0 <= (float)DAT_01d62378 * DAT_018daf54) {
    fVar11 = (float)DAT_01d62378 * DAT_018daf54;
  }
  fVar12 = DAT_018ce2f8;
  if (fVar11 <= DAT_018ce2f8) {
    fVar12 = fVar11;
  }
  fVar10 = (float10)FUN_01679f10(DAT_0191adc8,(double)(fVar12 * _DAT_0191adc0 + DAT_018daf58));
  fVar4 = (float)fVar10 * param_5;
  fVar10 = (float10)FUN_01679f10(DAT_0191ad98,(double)(fVar12 * DAT_018fabdc + DAT_018fabdc));
  param_5 = (float)fVar10 * param_5;
  iVar7 = FUN_01679e20(0,0,0x3ff,0);
  fVar25 = DAT_018f9980;
  fVar11 = *(float *)((int)&DAT_01eb49c0 + iVar7 * 0x3c);
  fVar12 = *(float *)((int)&DAT_01eb49c0 + iVar7 * 0x3c + 4);
  fVar19 = *(float *)((int)&DAT_01eb49cc + iVar7 * 0x3c);
  fVar14 = *(float *)((int)&DAT_01eb49cc + iVar7 * 0x3c + 4);
  fVar15 = (float)(&DAT_01eb49d4)[iVar7 * 0xf];
  fVar22 = (float)((uint)(fVar11 * param_5) ^ DAT_018c4ea0);
  fVar26 = (float)((uint)(fVar12 * param_5) ^ DAT_018c4ea0);
  fVar28 = (float)((uint)((float)(&DAT_01eb49c8)[iVar7 * 0xf] * param_5) ^ DAT_018c4ea0);
  fVar11 = fVar11 * param_5;
  fVar12 = fVar12 * param_5;
  param_5 = (float)(&DAT_01eb49c8)[iVar7 * 0xf] * param_5;
  if (param_6 == '\0') {
    uVar1 = *(undefined8 *)((int)&DAT_01eb49e4 + iVar7 * 0x3c);
    fStack_20 = (float)uVar1;
    fStack_1c = (float)((ulonglong)uVar1 >> 0x20);
    uVar5 = (undefined)(int)(fStack_20 * DAT_01900a1c + DAT_018f8ff8);
    uVar6 = (undefined)(int)(fStack_1c * DAT_01900a1c + DAT_018f8ff8);
    uStack_28._0_2_ = CONCAT11(uVar6,uVar5);
    uVar8 = (uint)((float)(&DAT_01eb49ec)[iVar7 * 0xf] * DAT_01900a1c + DAT_018f8ff8);
    *param_4 = CONCAT26(0x19,CONCAT24((short)(int)((param_2[2] + fVar28) * DAT_018f9980),
                                      CONCAT22((short)(int)((param_2[1] + fVar26) * DAT_018f9980),
                                               (short)(int)((*param_2 + fVar22) * DAT_018f9980))));
    uStack_28._0_3_ = CONCAT12((char)uVar8,(undefined2)uStack_28);
    uStack_28 = CONCAT13(0xff,(uint3)uStack_28);
    *(uint *)(param_4 + 1) = uStack_28;
    uStack_28 = (uVar8 & 0xff) << 0x10;
    uStack_28 = CONCAT13(0xff,(uint3)uStack_28);
    *(ulonglong *)((int)param_4 + 0xc) =
         CONCAT26(0x19,CONCAT24((short)(int)((param_2[2] + param_5) * fVar25),
                                CONCAT22((short)(int)((param_2[1] + fVar12) * fVar25),
                                         (short)(int)((*param_2 + fVar11) * fVar25))));
    uStack_28._0_2_ = CONCAT11(uVar6,uVar5);
    *(uint *)((int)param_4 + 0x14) = uStack_28;
    uStack_28._0_2_ = CONCAT11(uVar6,uVar5);
    uStack_28 = CONCAT22((short)uVar8,(undefined2)uStack_28) & 0xffffff;
    param_4[3] = CONCAT26((short)(int)((fVar4 + DAT_018e452c) * fVar25),
                          CONCAT24((short)(int)((fVar15 * fVar4 + param_2[2]) * fVar25),
                                   CONCAT22((short)(int)((fVar14 * fVar4 + param_2[1]) * fVar25),
                                            (short)(int)((fVar19 * fVar4 + *param_2) * fVar25))));
    *(uint *)(param_4 + 4) = uStack_28;
    return;
  }
  fVar13 = fVar22 * DAT_01901f3c;
  fVar3 = (float)(&DAT_01eb49f8)[iVar7 * 0xf];
  fVar29 = fVar19 * fVar4 * DAT_01901f3c;
  fVar30 = fVar14 * fVar4 * DAT_01901f3c;
  fVar14 = fVar26 * DAT_01901f3c;
  fVar31 = fVar15 * fVar4 * DAT_01901f3c;
  fVar15 = fVar28 * DAT_01901f3c;
  fVar16 = fVar11 * DAT_01901f3c;
  fVar17 = fVar12 * DAT_01901f3c;
  fVar18 = param_5 * DAT_01901f3c;
  fVar23 = (float)(&DAT_01eb49e0)[iVar7 * 0xf] * fVar4 * DAT_018fde64;
  fVar27 = *(float *)((int)&DAT_01eb49d8 + iVar7 * 0x3c + 4) * fVar4 * DAT_018fde64;
  fVar21 = *(float *)((int)&DAT_01eb49d8 + iVar7 * 0x3c) * fVar4 * DAT_018fde64;
  uVar1 = *(undefined8 *)((int)&DAT_01eb49e4 + iVar7 * 0x3c);
  uVar2 = *(undefined8 *)((int)&DAT_01eb49f0 + iVar7 * 0x3c);
  fStack_14 = (float)uVar1;
  fStack_10 = (float)((ulonglong)uVar1 >> 0x20);
  fVar24 = fVar3 + (float)(&DAT_01eb49ec)[iVar7 * 0xf];
  uVar8 = (uint)(fStack_10 * DAT_01900a1c + DAT_018f8ff8);
  uStack_28._0_1_ = (undefined)(int)(fStack_14 * DAT_01900a1c + DAT_018f8ff8);
  uVar5 = (undefined)uStack_28;
  uStack_28._0_2_ = CONCAT11((char)uVar8,(undefined)uStack_28);
  fVar19 = (float)(&DAT_01eb49ec)[iVar7 * 0xf] * DAT_01900a1c + DAT_018f8ff8;
  *param_4 = CONCAT26(0x19,CONCAT24((short)(int)((param_2[2] + fVar28) * DAT_018f9980),
                                    CONCAT22((short)(int)((param_2[1] + fVar26) * DAT_018f9980),
                                             (short)(int)((fVar22 + *param_2) * DAT_018f9980))));
  uVar6 = (undefined)(int)fVar19;
  uStack_28._0_3_ = CONCAT12(uVar6,(undefined2)uStack_28);
  uStack_28 = CONCAT13(0xff,(uint3)uStack_28);
  *(uint *)(param_4 + 1) = uStack_28;
  uStack_28 = (uVar8 & 0xff) << 8;
  uStack_28._0_3_ = CONCAT12(uVar6,(undefined2)uStack_28);
  uStack_28 = CONCAT13(0xff,(uint3)uStack_28);
  fStack_20 = (float)uVar2;
  fStack_14 = fStack_20 + fStack_14;
  *(ulonglong *)((int)param_4 + 0xc) =
       CONCAT26(0x19,CONCAT24((short)(int)((param_5 + param_2[2]) * fVar25),
                              CONCAT22((short)(int)((fVar12 + param_2[1]) * fVar25),
                                       (short)(int)((*param_2 + fVar11) * fVar25))));
  fStack_1c = (float)((ulonglong)uVar2 >> 0x20);
  fStack_10 = fStack_1c + fStack_10;
  uStack_28 = CONCAT31(uStack_28._1_3_,uVar5);
  *(uint *)((int)param_4 + 0x14) = uStack_28;
  dVar20 = (double)(fStack_10 * fStack_10 + fStack_14 * fStack_14 + fVar24 * fVar24);
  FUN_017267a0();
  fVar19 = DAT_01900a1c;
  fVar12 = DAT_018f9980;
  fVar11 = DAT_018f8ff8;
  fVar25 = DAT_018ce2f8 / (float)dVar20;
  uVar9 = (undefined2)(int)((fVar4 * DAT_01901f3c + DAT_018e452c) * DAT_018f9980);
  fVar22 = fStack_10 * fVar25 * DAT_01900a1c + DAT_018f8ff8;
  uVar5 = (undefined)(int)(fStack_14 * fVar25 * DAT_01900a1c + DAT_018f8ff8);
  uStack_28._0_2_ = CONCAT11((char)(int)(fStack_10 * fVar25 * DAT_01900a1c + DAT_018f8ff8),uVar5);
  fVar26 = fVar24 * fVar25 * DAT_01900a1c + DAT_018f8ff8;
  fVar25 = fVar24 * fVar25 * DAT_01900a1c + DAT_018f8ff8;
  param_4[3] = CONCAT26(uVar9,CONCAT24((short)(int)((fVar15 + fVar31 + param_2[2]) * DAT_018f9980),
                                       CONCAT22((short)(int)((fVar14 + fVar30 + param_2[1]) *
                                                            DAT_018f9980),
                                                (short)(int)((fVar13 + fVar29 + *param_2) *
                                                            DAT_018f9980))));
  uStack_28._0_3_ = CONCAT12((char)(int)fVar25,(undefined2)uStack_28);
  uStack_28 = CONCAT13(0x4c,(uint3)uStack_28);
  *(uint *)(param_4 + 4) = uStack_28;
  *(ulonglong *)((int)param_4 + 0x24) =
       CONCAT26(uVar9,CONCAT24((short)(int)((fVar18 + fVar31 + param_2[2]) * fVar12),
                               CONCAT22((short)(int)((fVar17 + fVar30 + param_2[1]) * fVar12),
                                        (short)(int)((fVar16 + fVar29 + *param_2) * fVar12))));
  uStack_28._0_2_ = CONCAT11((char)(int)fVar22,uVar5);
  uStack_28._0_3_ = CONCAT12((char)(int)fVar26,(undefined2)uStack_28);
  uStack_28 = CONCAT13(0x4c,(uint3)uStack_28);
  *(uint *)((int)param_4 + 0x2c) = uStack_28;
  uStack_28._0_2_ =
       CONCAT11((char)(int)(fStack_1c * fVar19 + fVar11),(char)(int)(fStack_20 * fVar19 + fVar11));
  uStack_28._0_3_ = CONCAT12((char)(int)(fVar3 * fVar19 + fVar11),(undefined2)uStack_28);
  uStack_28 = (uint)(uint3)uStack_28;
  param_4[6] = CONCAT26((short)(int)((fVar4 + DAT_018e452c) * fVar12),
                        CONCAT24((short)(int)((fVar23 + fVar31 + param_2[2]) * fVar12),
                                 CONCAT22((short)(int)((fVar27 + fVar30 + param_2[1]) * fVar12),
                                          (short)(int)((fVar21 + fVar29 + *param_2) * fVar12))));
  *(uint *)(param_4 + 7) = uStack_28;
  return;
}



/* FUNCTION 13203 ; VA 0x00863ec0 ; FUN_00863ec0 */

int __thiscall
FUN_00863ec0(int param_1,undefined4 param_2,undefined4 param_3,int param_4,undefined4 param_5,
            int param_6,uint param_7)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  undefined4 *puVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  undefined auStack_a0 [12];
  undefined auStack_94 [8];
  float fStack_8c;
  float fStack_88;
  float fStack_84;
  float fStack_80;
  int iStack_7c;
  int iStack_78;
  float fStack_74;
  float fStack_70;
  float fStack_6c;
  uint uStack_68;
  int iStack_64;
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  undefined4 uStack_54;
  int *piStack_50;
  int iStack_4c;
  float *pfStack_48;
  float fStack_44;
  int iStack_40;
  float fStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  int iStack_30;
  uint uStack_2c;
  int iStack_28;
  uint uStack_24;
  int iStack_20;
  undefined *puStack_1c;
  undefined uStack_15;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  fStack_44 = DAT_018ce2f8;
  puStack_c = &LAB_017b86fa;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)0x0;
  piVar1 = (int *)(param_1 + 0x3c);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *(int *)(param_1 + 0x40) = *piVar1;
  if ((char)param_7 != '\0') {
    fStack_44 = DAT_0191ad8c;
  }
  iStack_4c = param_1;
  uVar4 = FUN_016f3cd0();
  uStack_15 = DAT_01d62378 < 100;
  if (DAT_01d62380 < 1) {
    iVar5 = 1;
  }
  else {
    iVar5 = DAT_01d62380;
    if (0x10 < DAT_01d62380) {
      iVar5 = 0x10;
    }
  }
  if ((char)param_7 == '\0') {
    iStack_28 = 0xd;
  }
  else {
    iStack_28 = 8;
    if ((bool)uStack_15) {
      iStack_28 = iVar5;
    }
  }
  uStack_68 = param_7 & 0xff ^ 1;
  uStack_2c = 0;
  if (!(bool)uStack_15) {
    uStack_2c = param_7 & 0xff;
  }
  puStack_1c = (undefined *)0x9;
  iStack_30 = 3;
  if ((char)uStack_2c != '\0') {
    iStack_30 = 9;
  }
  iStack_40 = uStack_2c * 2 + 3;
  iStack_64 = 3;
  uStack_24 = uVar4;
  FUN_006b2d20(iStack_40 * iStack_28 * uVar4,piVar1);
  uStack_14 = 0;
  if (uVar4 != 0) {
    iStack_20 = 0;
    do {
      FUN_01679a70(*(short *)(iStack_20 + 2 + param_4) * 0x10000 +
                   (int)*(short *)(iStack_20 + param_4),0);
      iVar5 = FUN_01679e20(0,0,0x1ff,0);
      if ((char)uStack_2c == '\0') {
        puStack_1c = &DAT_01ec79c0 + iVar5 * 0x34;
      }
      else {
        puStack_1c = &DAT_01ec39c0 + iVar5 * 0x20;
      }
      fStack_8c = (float)(int)*(short *)(iStack_20 + param_4) * DAT_018fabc4;
      fStack_88 = (float)(int)*(short *)(iStack_20 + 2 + param_4) * DAT_018fabc4;
      fStack_84 = (float)(int)*(short *)(iStack_20 + 4 + param_4) * DAT_018fabc4;
      fVar9 = (float)*(byte *)(iStack_20 + 8 + param_4);
      fVar7 = (float)*(byte *)(iStack_20 + 9 + param_4);
      fVar8 = (float)*(byte *)(iStack_20 + 10 + param_4);
      fStack_70 = (fVar7 + fVar7) / DAT_018f9000 - DAT_018ce2f8;
      piStack_34 = (int *)((fVar9 + fVar9) / DAT_018f9000 - DAT_018ce2f8);
      fStack_3c = (fVar8 + fVar8) / DAT_018f9000 - DAT_018ce2f8;
      fStack_80 = (float)(int)*(short *)(iStack_20 + 6 + param_4) * DAT_0191ad84;
      fStack_74 = (float)((uint)((float)piStack_34 * fStack_8c + fStack_70 * fStack_88 +
                                fStack_3c * fStack_84) ^ DAT_018c4ea0);
      iStack_78 = (int)((float)iStack_28 * fStack_80);
      if ((int)((float)iStack_28 * fStack_80) < 3) {
        iStack_78 = iStack_64;
      }
      iVar5 = 0;
      fStack_6c = fStack_8c;
      if (0 < iStack_28) {
        piStack_50 = (int *)(fStack_80 * DAT_018ce2f0);
        pfStack_48 = (float *)(&DAT_0191abac + uStack_68 * 0x80);
        do {
          fVar8 = (pfStack_48[-1] + pfStack_48[-1]) * fStack_80 + fStack_6c;
          fStack_58 = fStack_84 + (*pfStack_48 + *pfStack_48) * fStack_80;
          iStack_7c = *piVar1 + (*(int *)(puStack_1c + iVar5 * 4) * uStack_24 + uStack_14) *
                                iStack_40 * 0xc;
          fVar7 = fVar8 * (float)piStack_34 + (fStack_88 + (float)piStack_50) * fStack_70 +
                  fStack_58 * fStack_3c + fStack_74;
          fStack_58 = fStack_58 - fVar7 * fStack_3c;
          _fStack_60 = CONCAT44((fStack_88 + (float)piStack_50) - fVar7 * fStack_70,
                                fVar8 - fVar7 * (float)piStack_34);
          if (iVar5 < iStack_78) {
            FUN_00863630(auStack_94,&fStack_60,auStack_a0,iStack_7c,fStack_80 * fStack_44,uStack_2c)
            ;
          }
          else {
            FUN_0170c6f0(iStack_7c,
                         *piVar1 + (*(int *)(puStack_1c + iVar5 * 4 + -4) * uStack_24 + uStack_14) *
                                   iStack_40 * 0xc,iStack_40 * 0xc);
          }
          iVar5 = iVar5 + 1;
          pfStack_48 = pfStack_48 + 2;
        } while (iVar5 < iStack_28);
      }
      iStack_20 = iStack_20 + 0xc;
      uStack_14 = uStack_14 + 1;
      uVar4 = uStack_24;
    } while (uStack_14 < uStack_24);
  }
  if ((char)uStack_2c == '\0') {
    uStack_54 = 0;
    piStack_50 = (int *)0x0;
    puVar6 = &uStack_54;
    uStack_8 = 2;
    puStack_1c = (undefined *)0x2;
  }
  else {
    piStack_34 = *(int **)(iStack_4c + 0x4c);
    if (piStack_34 != (int *)0x0) {
      LOCK();
      piStack_34[1] = piStack_34[1] + 1;
      UNLOCK();
      piStack_34 = *(int **)(iStack_4c + 0x4c);
    }
    uStack_38 = *(undefined4 *)(iStack_4c + 0x48);
    puVar6 = &uStack_38;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    puStack_1c = (undefined *)0x1;
  }
  uStack_14 = (uint)puStack_1c;
  iVar5 = FUN_008649c0(param_2,param_3,piVar1,iStack_30 * iStack_28 * uVar4,puVar6,param_7);
  piVar1 = piStack_50;
  if (((uStack_14 & 2) != 0) && (uStack_14 = uStack_14 & 0xfffffffd, piStack_50 != (int *)0x0)) {
    LOCK();
    piVar2 = piStack_50 + 1;
    iVar3 = *piVar2;
    iVar5 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_50)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      iVar5 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar5 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = piStack_34;
  if (((uStack_14 & 1) != 0) && (piStack_34 != (int *)0x0)) {
    LOCK();
    piVar2 = piStack_34 + 1;
    iVar3 = *piVar2;
    iVar5 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar5 = (**(code **)*piStack_34)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar5 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (param_4 != 0) {
    uVar4 = ((param_6 - param_4) / 0xc) * 0xc;
    iVar5 = param_4;
    if (0xfff < uVar4) {
      iVar5 = *(int *)(param_4 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (param_4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar5 = FUN_01674ea0(iVar5,uVar4);
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 13204 ; VA 0x00864430 ; FUN_00864430 */

void __thiscall FUN_00864430(int param_1,int *param_2,int param_3,undefined4 param_4,int *param_5)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  
  uVar2 = *(uint *)(*(int *)(param_3 + 8) + 0x14) / *(uint *)(param_1 + 0x74);
  iVar3 = (int)((float)((double)(int)uVar2 + (double)(&DAT_018c0d90)[-((int)uVar2 >> 0x1f)]) *
               *(float *)(param_1 + 0x70)) * *(int *)(param_1 + 0x74);
  if (iVar3 != 0) {
    (**(code **)(*param_2 + 0x30))(1,param_1 + 0x50,0x20);
    puVar1 = *(undefined4 **)(param_3 + 8);
    (**(code **)(*param_2 + 0x40))(*puVar1,puVar1[2],puVar1[3],puVar1[4],iVar3,0);
    *param_5 = *param_5 + 1;
    param_5[1] = param_5[1] + *(int *)(*(int *)(param_3 + 8) + 0x14);
    param_5[2] = param_5[2] + 0x20;
  }
  return;
}



/* FUNCTION 13205 ; VA 0x008644b0 ; FUN_008644b0 */

int FUN_008644b0(uint param_1,undefined4 param_2,char *param_3,char *param_4,int param_5,
                undefined4 param_6)

{
  int *piVar1;
  char cVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  char *pcVar6;
  undefined auStack_88 [80];
  char *pcStack_38;
  int iStack_34;
  char *pcStack_30;
  int iStack_2c;
  uint auStack_28 [2];
  ushort uStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8723;
  pvStack_10 = ExceptionList;
  uVar3 = *(uint *)(param_1 + 0x4f8);
  uStack_14 = *(undefined4 *)(param_1 + 0x4f4);
  if (param_4 == (char *)0x0) {
    iStack_2c = 0;
  }
  else {
    pcVar6 = param_4;
    do {
      cVar2 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar2 != '\0');
    iStack_2c = (int)pcVar6 - (int)(param_4 + 1);
  }
  if (param_3 == (char *)0x0) {
    iStack_34 = 0;
  }
  else {
    pcVar6 = param_3;
    do {
      cVar2 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar2 != '\0');
    iStack_34 = (int)pcVar6 - (int)(param_3 + 1);
  }
  pcStack_38 = param_3;
  pcStack_30 = param_4;
  ExceptionList = &pvStack_10;
  param_1 = uVar3;
  iVar4 = FUN_00790e00(&iStack_1c,&pcStack_38,2);
  uStack_8 = 0;
  if (iStack_1c != 0) {
    FUN_0078ded0(&iStack_1c,param_6,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    auStack_28[0] = auStack_28[0] & 0xffff0000;
    auStack_28[1] = 0;
    uStack_20 = uStack_20 & 0xff00;
    FUN_0078e530(auStack_28);
    auStack_28[1] = 0x1000100;
    auStack_28[0] = 0xf;
    uStack_20 = uStack_20 & 0xff00;
    FUN_0078e480(auStack_28);
    param_1 = (uint)CONCAT21(0x104,(undefined)param_1);
    FUN_0078e510((int)&param_1 + 1);
    iVar4 = param_5;
    if ((param_5 == 1) || (iVar5 = 0x46c, param_5 == 2)) {
      iVar5 = 0x474;
    }
    auStack_28[0]._0_2_ = 0x101;
    auStack_28[1] = 0;
    uStack_20 = 0;
    FUN_0078e550(1,iVar5 + uVar3,auStack_28);
    auStack_28[0] = CONCAT22(auStack_28[0]._2_2_,0x101);
    auStack_28[1] = 0;
    uStack_20 = 0;
    FUN_0078e550(0xf,*(int *)(uVar3 + 0x44c) + 0x84,auStack_28);
    FUN_0078e040(auStack_88,iVar4);
    iVar4 = FUN_0075e0c0();
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar5 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      iVar4 = (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        iVar4 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 13206 ; VA 0x00864690 ; FUN_00864690 */

void __fastcall FUN_00864690(int param_1)

{
  int iVar1;
  char *pcVar2;
  char *pcVar3;
  undefined4 uVar4;
  
  FUN_0078e420();
  iVar1 = FUN_0078e450(*(undefined4 *)(*(int *)(param_1 + 0x20) + 0x5c4));
  if (iVar1 == 0) {
    pcVar2 = "GrassHQVS";
    pcVar3 = "GrassHQFS";
    uVar4 = 0;
  }
  else if (iVar1 == 1) {
    pcVar2 = "GrassHQVSShadowed";
    pcVar3 = "GrassHQFSShadowed";
    uVar4 = 1;
  }
  else {
    pcVar2 = "GrassHQVSShadowedFSM";
    pcVar3 = "GrassHQFSShadowedFSM";
    uVar4 = 2;
  }
  FUN_008644b0(*(undefined4 *)(param_1 + 0x20),param_1 + 0x78,pcVar2,pcVar3,uVar4,1);
  FUN_008644b0(*(undefined4 *)(param_1 + 0x20),param_1 + 0x78,"GrassVS","GrassFS",0,2);
  return;
}



/* FUNCTION 13207 ; VA 0x00864720 ; FUN_00864720 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00864720(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  float10 fVar4;
  float fVar5;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  float fStack_44;
  float fStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  iVar2 = (uint)*(byte *)(param_1 + 0x80) * 3;
  fStack_8 = DAT_01d62394 * DAT_018e1340 + DAT_01d62398 * DAT_018ce2f4 + DAT_01d6239c * DAT_018e1340
  ;
  fStack_c = DAT_01d62394 * DAT_018ce2f4 - DAT_01d6239c * DAT_018ce2f4;
  fStack_10 = (DAT_01d62398 * DAT_018ce2f4 - DAT_01d62394 * DAT_018e1340) -
              DAT_01d6239c * DAT_018e1340;
  iStack_14 = param_1;
  FUN_00808710(&fStack_34,*(int *)(*(int *)(param_1 + 0x24) + 0x16c) + iVar2,
               *(int *)(*(int *)(param_1 + 0x24) + 0x160) + iVar2);
  uStack_18 = 0x3f800000;
  fStack_20 = fStack_30 * fStack_10 + fStack_2c * fStack_c;
  fVar5 = fStack_30 * fStack_c - fStack_2c * fStack_10;
  fStack_1c = fStack_8 * fStack_34 - fStack_20;
  fStack_20 = fStack_20 + fStack_8 * fStack_34;
  fStack_24 = fVar5 + fStack_1c;
  fStack_1c = fStack_1c - fVar5;
  fStack_20 = fStack_20 * fStack_20;
  fStack_24 = fStack_24 * fStack_24;
  fStack_1c = fStack_1c * fStack_1c;
  *(float *)(param_1 + 0xac) = fStack_24;
  *(float *)(param_1 + 0xb0) = fStack_20;
  *(float *)(param_1 + 0xb4) = fStack_1c;
  *(undefined4 *)(param_1 + 0xb8) = 0x3f800000;
  fVar4 = (float10)FUN_01156f90(*(undefined4 *)(param_1 + 0x250));
  uStack_54 = *(undefined4 *)(param_1 + 0xac);
  uStack_50 = *(undefined4 *)(param_1 + 0xb0);
  uStack_4c = *(undefined4 *)(param_1 + 0xb4);
  uStack_48 = *(undefined4 *)(param_1 + 0xb8);
  fStack_40 = (float)fVar4;
  fStack_44 = *(float *)(*(int *)(*(int *)(param_1 + 0x20) + 0x4f8) + 0x108) * _DAT_0191adb0 +
              _DAT_0191add0;
  uStack_38 = 0;
  uStack_3c = *(undefined4 *)(*(int *)(param_1 + 0x20) + 0x28);
  if (*(int *)(param_1 + 0x78) != 0) {
    iVar2 = 0;
    fStack_10 = fStack_40;
    do {
      iVar1 = *(int *)(*(int *)(param_1 + 0x78) + 4 + iVar2);
      iVar3 = *(int *)(*(int *)(param_1 + 0x78) + iVar2);
      param_1 = iStack_14;
      for (; iStack_14 = param_1, iVar3 != iVar1; iVar3 = iVar3 + 0x50) {
        FUN_0078e4a0(2,&uStack_54,0x20);
        param_1 = iStack_14;
      }
      iVar2 = iVar2 + 0xc;
    } while (iVar2 < 0x24);
  }
  return;
}



/* FUNCTION 13208 ; VA 0x008648e0 ; FUN_008648e0 */

void __thiscall
FUN_008648e0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7)

{
  int iVar1;
  float10 fVar2;
  float fVar3;
  double dVar4;
  float fVar5;
  float fVar6;
  undefined8 uStack_14;
  undefined4 uStack_c;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0x4c) + 0x20);
  fVar2 = (float10)FUN_01156580();
  iVar1 = *(int *)(iVar1 + 0x4f8);
  fVar6 = (float)fVar2;
  uStack_14 = *(undefined8 *)(iVar1 + 4);
  uStack_c = *(undefined4 *)(iVar1 + 0xc);
  fVar2 = (float10)FUN_00c9ed90(&uStack_14);
  dVar4 = (double)fVar2;
  FUN_017267a0();
  fVar5 = 0.0;
  if (0.0 <= (float)dVar4) {
    fVar5 = (float)dVar4;
  }
  fVar3 = fVar6;
  if (fVar5 <= fVar6) {
    fVar3 = fVar5;
  }
  fVar3 = DAT_018daf58 / (fVar3 / fVar6 + DAT_018ce2f8) - DAT_018ce2f8;
  fVar5 = 0.0;
  if (0.0 <= fVar3) {
    fVar5 = fVar3;
  }
  fVar3 = DAT_018ce2f8;
  if (fVar5 <= DAT_018ce2f8) {
    fVar3 = fVar5;
  }
  *(float *)(param_1 + 0x70) = fVar3;
  if ((*(char *)(param_1 + 0x78) != '\0') && (DAT_018df584 <= fVar6)) {
    fVar6 = DAT_018df584;
  }
  *(float *)(param_1 + 0x60) = fVar6;
  FUN_00841ae0(param_2,param_3,param_4,param_5,param_7);
  return;
}



/* FUNCTION 13209 ; VA 0x008649c0 ; FUN_008649c0 */

undefined4 __thiscall
FUN_008649c0(int param_1,int *param_2,float *param_3,int *param_4,undefined4 param_5,
            undefined4 param_6,char param_7)

{
  int *piVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  int iVar6;
  int iVar7;
  undefined4 *puVar8;
  int *piVar9;
  undefined4 *puVar10;
  undefined4 uVar11;
  undefined auStack_58 [4];
  int *piStack_54;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  int *piStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  float fStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8757;
  pvStack_10 = ExceptionList;
  puVar10 = (undefined4 *)*param_2;
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  iStack_18 = param_1;
  if (puVar10 != (undefined4 *)0x0) {
    (**(code **)*puVar10)(1);
  }
  if (*param_4 != param_4[1]) {
    piStack_1c = *(int **)(*(int *)(param_1 + 0x20) + 0x3c);
    fStack_20 = (float)(((param_4[1] - *param_4) / 0xc) * 0xc);
    (**(code **)(*piStack_1c + 0x3c))(&piStack_28,0,fStack_20,0xc,0);
    piStack_14 = (int *)(param_1 + 0x58);
    uStack_8 = 0;
    if (*piStack_14 == 0) {
      if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ece1e8
          ) && (FUN_016f3809(&DAT_01ece1e8), DAT_01ece1e8 == -1)) {
        FUN_0147c5c0(0,0,5,0,0);
        FUN_0147c5c0(0,8,7,1,0);
        FUN_016f37bf(&DAT_01ece1e8);
      }
      piVar9 = (int *)FUN_0147c1b0(&fStack_38,&DAT_01ece1c0,2,0xc);
      iVar6 = *piVar9;
      iVar7 = piVar9[1];
      *piVar9 = 0;
      piVar9[1] = 0;
      *piStack_14 = iVar6;
      piVar9 = (int *)piStack_14[1];
      piStack_14[1] = iVar7;
      if (piVar9 != (int *)0x0) {
        LOCK();
        iVar6 = piVar9[1] + -1;
        piVar9[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar9)();
          LOCK();
          iVar6 = piVar9[2] + -1;
          piVar9[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
      piVar9 = piStack_34;
      if (piStack_34 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_34[1] + -1;
        piStack_34[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_34)();
          LOCK();
          piVar1 = piVar9 + 2;
          iVar6 = *piVar1 + -1;
          *piVar1 = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
    }
    FUN_0147c0e0(auStack_30,piStack_14,&piStack_28,param_6);
    uStack_8._0_1_ = 1;
    (**(code **)(*piStack_28 + 0x18))(0,*param_4,fStack_20);
    FUN_0147c720(auStack_30,0,0,0,param_5);
    uStack_8._0_1_ = 2;
    puVar10 = (undefined4 *)FUN_01674e20(0x7c);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    piStack_14 = puVar10;
    if (puVar10 == (undefined4 *)0x0) {
      puVar10 = (undefined4 *)0x0;
    }
    else {
      fVar2 = param_3[3];
      fVar3 = *param_3;
      fVar4 = param_3[1];
      fVar5 = param_3[4];
      piStack_1c = (int *)param_3[2];
      fStack_20 = param_3[5];
      uVar11 = FUN_00862900();
      FUN_00841220(0,auStack_58,auStack_58,uVar11,0,0xff,0);
      fStack_38 = DAT_018ce2f4;
      puVar10[0x13] = iStack_18;
      fStack_40 = (fVar3 + fVar2) * fStack_38;
      uVar11 = 3;
      *puVar10 = RBX::Graphics::GrassRenderEntity::vftable;
      if (param_7 != '\0') {
        uVar11 = 9;
      }
      puVar10[0x14] = 0;
      puVar10[0x15] = 0;
      puVar10[0x16] = 0;
      puVar10[0x17] = 0;
      puVar10[0x18] = 0;
      puVar10[0x19] = 0;
      fStack_3c = (fVar4 + fVar5) * fStack_38;
      puVar10[0x1a] = 0;
      puVar10[0x1b] = 0;
      piStack_34 = (int *)0x0;
      puVar10[0x1c] = 0x3f800000;
      puVar10[0x1d] = uVar11;
      *(char *)(puVar10 + 0x1e) = param_7;
      fStack_38 = (fStack_20 + (float)piStack_1c) * fStack_38;
      puVar10[0x14] = fStack_40;
      puVar10[0x15] = fStack_3c;
      puVar10[0x16] = fStack_38;
      puVar10[0x17] = 0;
      puVar10[0x18] = 0;
      puVar10[0x19] = 0;
      puVar10[0x1a] = 0;
      puVar10[0x1b] = 0;
      if (param_7 == '\0') {
        puVar10[0x19] = DAT_0191ad88;
      }
      else {
        puVar10[0x19] = DAT_018ff218;
      }
    }
    puVar8 = (undefined4 *)*param_2;
    *param_2 = (int)puVar10;
    if (puVar8 != (undefined4 *)0x0) {
      (**(code **)*puVar8)(1);
    }
    if (piStack_54 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_54[1] + -1;
      piStack_54[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_54)();
        LOCK();
        iVar6 = piStack_54[2] + -1;
        piStack_54[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_54 + 4))();
        }
      }
    }
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar6 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        iVar6 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_2c + 4))();
        }
      }
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_24[1] + -1;
      piStack_24[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar9 = piStack_24 + 2;
        iVar6 = *piVar9;
        *piVar9 = *piVar9 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 13210 ; VA 0x00864d90 ; FUN_00864d90 */

void __thiscall FUN_00864d90(int param_1,int param_2,int param_3)

{
  float *pfVar1;
  float fVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined4 uStack_8;
  
  iVar5 = 1;
  if (*(char *)(param_1 + 0xc) != '\0') {
    uStack_8 = 1;
    if (param_3 != 1) {
      do {
        iVar5 = *(int *)(*(int *)(param_1 + 4) + uStack_8 * 4);
        iVar4 = uStack_8;
        if (uStack_8 != 0) {
          do {
            iVar3 = *(int *)(*(int *)(param_1 + 4) + -4 + iVar4 * 4);
            fVar2 = *(float *)(param_2 + iVar3 * 4);
            pfVar1 = (float *)(param_2 + iVar5 * 4);
            if (fVar2 < *pfVar1 || fVar2 == *pfVar1) break;
            *(int *)(*(int *)(param_1 + 4) + iVar4 * 4) = iVar3;
            iVar4 = iVar4 + -1;
          } while (iVar4 != 0);
          if (uStack_8 != iVar4) {
            *(int *)(*(int *)(param_1 + 4) + iVar4 * 4) = iVar5;
          }
        }
        uStack_8 = uStack_8 + 1;
      } while (uStack_8 != param_3);
    }
    return;
  }
  **(undefined4 **)(param_1 + 4) = 0;
  if (param_3 != 1) {
    do {
      *(int *)(*(int *)(param_1 + 4) + iVar5 * 4) = iVar5;
      iVar4 = iVar5;
      if (iVar5 != 0) {
        do {
          iVar3 = *(int *)(*(int *)(param_1 + 4) + -4 + iVar4 * 4);
          fVar2 = *(float *)(param_2 + iVar3 * 4);
          pfVar1 = (float *)(param_2 + iVar5 * 4);
          if (fVar2 < *pfVar1 || fVar2 == *pfVar1) break;
          *(int *)(*(int *)(param_1 + 4) + iVar4 * 4) = iVar3;
          iVar4 = iVar4 + -1;
        } while (iVar4 != 0);
        if (iVar5 != iVar4) {
          *(int *)(*(int *)(param_1 + 4) + iVar4 * 4) = iVar5;
        }
      }
      iVar5 = iVar5 + 1;
    } while (iVar5 != param_3);
  }
  *(undefined *)(param_1 + 0xc) = 1;
  return;
}



/* FUNCTION 13211 ; VA 0x00864e50 ; FUN_00864e50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00864e50(byte *param_1,uint param_2)

{
  byte *pbVar1;
  undefined4 uVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  int extraout_ECX;
  byte *pbVar8;
  int iVar9;
  int *piVar10;
  int *piVar11;
  int iVar12;
  int iVar13;
  int iVar14;
  int iVar15;
  int iVar16;
  int iVar17;
  int aiStack_1418 [256];
  int aiStack_1018 [256];
  int aiStack_c18 [512];
  int aiStack_418 [254];
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  int *piVar18;
  int iVar19;
  
  FUN_016f40d0();
  piStack_14 = (int *)0x1000;
  piStack_1c = aiStack_1418;
  uStack_20 = 0x864e78;
  iStack_18 = extraout_ECX;
  FUN_0170d1f0();
  if (param_1 != param_1 + param_2 * 4) {
    pbVar8 = param_1 + 2;
    do {
      aiStack_1418[pbVar8[-2]] = aiStack_1418[pbVar8[-2]] + 1;
      aiStack_1018[pbVar8[-1]] = aiStack_1018[pbVar8[-1]] + 1;
      aiStack_c18[*pbVar8] = aiStack_c18[*pbVar8] + 1;
      aiStack_418[pbVar8[1] - 0x100] = aiStack_418[pbVar8[1] - 0x100] + 1;
      pbVar1 = pbVar8 + 2;
      pbVar8 = pbVar8 + 4;
    } while (pbVar1 != param_1 + param_2 * 4);
  }
  piStack_14 = aiStack_1418;
  iVar19 = 4;
  iVar9 = (int)piStack_14 - (int)aiStack_418;
  piVar18 = aiStack_1418 + 3;
  iVar13 = extraout_ECX;
  do {
    if (piStack_14[*param_1] != param_2) {
      aiStack_418[0] = *(int *)(iVar13 + 8);
      iVar12 = 0x33;
      piVar10 = aiStack_418;
      piVar11 = piVar18;
      do {
        aiStack_418[0] = aiStack_418[0] + *(int *)((int)piVar10 + iVar9) * 4;
        iVar13 = piVar11[-2];
        piVar10[1] = aiStack_418[0];
        aiStack_418[0] = aiStack_418[0] + iVar13 * 4;
        iVar13 = piVar11[-1];
        piVar10[2] = aiStack_418[0];
        aiStack_418[0] = aiStack_418[0] + iVar13 * 4;
        iVar13 = *piVar11;
        piVar10[3] = aiStack_418[0];
        aiStack_418[0] = aiStack_418[0] + iVar13 * 4;
        iVar13 = piVar11[1];
        piVar10[4] = aiStack_418[0];
        aiStack_418[0] = aiStack_418[0] + iVar13 * 4;
        piVar10[5] = aiStack_418[0];
        iVar13 = iStack_18;
        iVar12 = iVar12 + -1;
        piVar10 = piVar10 + 5;
        piVar11 = piVar11 + 5;
      } while (iVar12 != 0);
      if (*(char *)(iStack_18 + 0xc) == '\0') {
        uVar7 = 0;
        if (param_2 != 0) {
          do {
            *(uint *)aiStack_418[param_1[uVar7 * 4]] = uVar7;
            iVar12 = uVar7 * 4;
            uVar7 = uVar7 + 1;
            aiStack_418[param_1[iVar12]] = aiStack_418[param_1[iVar12]] + 4;
          } while (uVar7 < param_2);
        }
        *(undefined *)(iVar13 + 0xc) = 1;
      }
      else {
        uVar7 = 0;
        if (param_2 != 0) {
          do {
            iVar12 = *(int *)(*(int *)(iVar13 + 4) + uVar7 * 4);
            uVar7 = uVar7 + 1;
            *(int *)aiStack_418[param_1[iVar12 * 4]] = iVar12;
            aiStack_418[param_1[iVar12 * 4]] = aiStack_418[param_1[iVar12 * 4]] + 4;
          } while (uVar7 < param_2);
        }
      }
      uVar2 = *(undefined4 *)(iVar13 + 8);
      *(undefined4 *)(iVar13 + 8) = *(undefined4 *)(iVar13 + 4);
      *(undefined4 *)(iVar13 + 4) = uVar2;
    }
    iVar6 = _UNK_0190043c;
    iVar5 = _UNK_01900438;
    iVar4 = DAT_01900430._4_4_;
    iVar12 = (int)DAT_01900430;
    piVar18 = piVar18 + 0x100;
    piStack_14 = piStack_14 + 0x100;
    iVar9 = iVar9 + 0x400;
    param_1 = param_1 + 1;
    iVar19 = iVar19 + -1;
  } while (iVar19 != 0);
  if (*(char *)(iVar13 + 0xc) == '\0') {
    uVar7 = 0;
    if (param_2 != 0) {
      if (0xf < param_2) {
        uVar3 = *(uint *)(iVar13 + 4);
        if ((iVar13 + 4U < uVar3) || (uVar3 + (param_2 - 1) * 4 < iVar13 + 4U)) {
          iVar19 = 0x20;
          iVar9 = 8;
          do {
            iVar13 = iVar9 + -4;
            iVar14 = uVar7 + iVar12;
            iVar15 = uVar7 + iVar4;
            iVar16 = uVar7 + iVar5;
            iVar17 = uVar7 + iVar6;
            uVar7 = uVar7 + 0x10;
            piVar18 = (int *)(iVar19 + -0x20 + uVar3);
            *piVar18 = iVar14;
            piVar18[1] = iVar15;
            piVar18[2] = iVar16;
            piVar18[3] = iVar17;
            iVar14 = iVar9 + 4;
            piVar18 = (int *)(iVar19 + -0x10 + uVar3);
            *piVar18 = iVar13 + iVar12;
            piVar18[1] = iVar13 + iVar4;
            piVar18[2] = iVar13 + iVar5;
            piVar18[3] = iVar13 + iVar6;
            piVar18 = (int *)((uVar3 - 0x40) + iVar19 + 0x40);
            *piVar18 = iVar9 + iVar12;
            piVar18[1] = iVar9 + iVar4;
            piVar18[2] = iVar9 + iVar5;
            piVar18[3] = iVar9 + iVar6;
            piVar18 = (int *)(iVar19 + 0x10 + uVar3);
            *piVar18 = iVar14 + iVar12;
            piVar18[1] = iVar14 + iVar4;
            piVar18[2] = iVar14 + iVar5;
            piVar18[3] = iVar14 + iVar6;
            iVar19 = iVar19 + 0x40;
            iVar9 = iVar9 + 0x10;
            iVar13 = iStack_18;
          } while (uVar7 < (param_2 & 0xfffffff0));
        }
      }
      for (; uVar7 < param_2; uVar7 = uVar7 + 1) {
        *(uint *)(*(int *)(iVar13 + 4) + uVar7 * 4) = uVar7;
      }
    }
    *(undefined *)(iVar13 + 0xc) = 1;
  }
  return;
}



/* FUNCTION 13212 ; VA 0x008650c0 ; FUN_008650c0 */

int * __thiscall FUN_008650c0(int *param_1,int param_2)

{
  int iVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  *(undefined *)(param_1 + 3) = 0;
  if (param_2 != 0) {
    iVar1 = FUN_017268a0(0,param_2 * 4);
    param_1[2] = iVar1;
    iVar1 = FUN_017268a0(param_1[1],param_2 * 4);
    param_1[1] = iVar1;
    *param_1 = param_2;
    *(undefined *)(param_1 + 3) = 0;
  }
  return param_1;
}



/* FUNCTION 13213 ; VA 0x00865120 ; FUN_00865120 */

void __fastcall FUN_00865120(int param_1)

{
  FUN_017168b0(*(undefined4 *)(param_1 + 8));
  FUN_017168b0(*(undefined4 *)(param_1 + 4));
  return;
}



/* FUNCTION 13214 ; VA 0x00865140 ; FUN_00865140 */

uint * __thiscall FUN_00865140(uint *param_1,int param_2,uint param_3)

{
  uint uVar1;
  
  if ((param_2 != 0) && (param_3 != 0)) {
    if (param_3 != *param_1) {
      if (*param_1 < param_3) {
        uVar1 = FUN_017268a0(param_1[2],param_3 * 4);
        param_1[2] = uVar1;
        uVar1 = FUN_017268a0(param_1[1],param_3 * 4);
        param_1[1] = uVar1;
      }
      *param_1 = param_3;
      *(undefined *)(param_1 + 3) = 0;
    }
    if (param_3 < 0x20) {
      FUN_00864d90(param_2,param_3);
      return param_1;
    }
    FUN_00864e50(param_2,param_3);
  }
  return param_1;
}



/* FUNCTION 13215 ; VA 0x008651b0 ; FUN_008651b0 */

void __thiscall FUN_008651b0(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  
  puVar6 = param_2;
  iVar5 = (int)param_3 - (int)param_2;
  iVar3 = *param_1;
  uVar1 = iVar5 / 0x278;
  uVar7 = (param_1[1] - iVar3) / 0x278;
  uVar2 = (param_1[2] - iVar3) / 0x278;
  if (uVar2 < uVar1) {
    param_2 = (undefined4 *)uVar2;
    if (0x67b23a < uVar1) {
LAB_00865369:
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar7 = uVar1;
    if ((uVar2 <= 0x67b23a - (uVar2 >> 1)) && (uVar7 = (uVar2 >> 1) + uVar2, uVar7 < uVar1)) {
      uVar7 = uVar1;
    }
    if (iVar3 != 0) {
      FUN_0083ae50(iVar3,uVar2);
    }
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    if (uVar7 != 0) {
      if (0x67b23a < uVar7) goto LAB_00865369;
      iVar3 = FUN_0083cc60(uVar7);
      *param_1 = iVar3;
      param_1[1] = iVar3;
      param_1[2] = uVar7 * 0x278 + *param_1;
    }
    puVar4 = (undefined4 *)*param_1;
    if (puVar6 != param_3) {
      do {
        puVar9 = puVar6 + 0x9e;
        puVar8 = puVar4 + 0x9e;
        for (iVar3 = 0x9e; iVar3 != 0; iVar3 = iVar3 + -1) {
          *puVar4 = *puVar6;
          puVar6 = puVar6 + 1;
          puVar4 = puVar4 + 1;
        }
        puVar4 = puVar8;
        puVar6 = puVar9;
      } while (puVar9 != param_3);
      param_1[1] = (int)puVar8;
      return;
    }
  }
  else if (uVar7 < uVar1) {
    puVar8 = param_2 + uVar7 * 0x9e;
    param_2 = (undefined4 *)uVar2;
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    FUN_0170cc70(iVar3,puVar6,(int)puVar8 - (int)puVar6);
    puVar4 = (undefined4 *)param_1[1];
    if (puVar8 != param_3) {
      do {
        puVar6 = puVar8;
        puVar9 = puVar4;
        for (iVar3 = 0x9e; iVar3 != 0; iVar3 = iVar3 + -1) {
          *puVar9 = *puVar6;
          puVar6 = puVar6 + 1;
          puVar9 = puVar9 + 1;
        }
        puVar4 = puVar4 + 0x9e;
        puVar8 = puVar8 + 0x9e;
      } while (puVar8 != param_3);
      param_1[1] = (int)puVar4;
      return;
    }
  }
  else {
    param_2 = (undefined4 *)uVar2;
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(iVar3,puVar6,iVar5);
    puVar4 = (undefined4 *)(uVar1 * 0x278 + iVar3);
  }
  param_1[1] = (int)puVar4;
  return;
}



/* FUNCTION 13216 ; VA 0x00865370 ; FUN_00865370 */

int __thiscall FUN_00865370(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  int iVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  undefined4 *puVar13;
  undefined4 *puVar14;
  
  iVar2 = ((int)param_2 - *param_1) / 0x278;
  iVar3 = (param_1[1] - *param_1) / 0x278;
  if (iVar3 == 0x67b23a) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar3 + 1;
  uVar4 = (param_1[2] - *param_1) / 0x278;
  uVar5 = uVar1;
  if ((uVar4 <= 0x67b23a - (uVar4 >> 1)) && (uVar5 = (uVar4 >> 1) + uVar4, uVar5 < uVar1)) {
    uVar5 = uVar1;
  }
  puVar6 = (undefined4 *)FUN_0083cc60(uVar5);
  puVar13 = puVar6 + iVar2 * 0x9e;
  puVar11 = puVar13;
  for (iVar9 = 0x9e; iVar9 != 0; iVar9 = iVar9 + -1) {
    *puVar11 = *param_3;
    param_3 = param_3 + 1;
    puVar11 = puVar11 + 1;
  }
  puVar12 = (undefined4 *)param_1[1];
  puVar11 = (undefined4 *)*param_1;
  puVar8 = puVar6;
  if (param_2 == puVar12) {
    while (puVar11 != puVar12) {
      puVar10 = puVar11 + 0x9e;
      puVar7 = puVar8 + 0x9e;
      puVar13 = puVar11;
      puVar14 = puVar8;
      for (iVar9 = 0x9e; puVar11 = puVar10, puVar8 = puVar7, iVar9 != 0; iVar9 = iVar9 + -1) {
        *puVar14 = *puVar13;
        puVar13 = puVar13 + 1;
        puVar14 = puVar14 + 1;
      }
    }
  }
  else {
    if (puVar11 != param_2) {
      do {
        puVar14 = puVar11 + 0x9e;
        puVar12 = puVar8;
        for (iVar9 = 0x9e; iVar9 != 0; iVar9 = iVar9 + -1) {
          *puVar12 = *puVar11;
          puVar11 = puVar11 + 1;
          puVar12 = puVar12 + 1;
        }
        puVar8 = puVar8 + 0x9e;
        puVar11 = puVar14;
      } while (puVar14 != param_2);
      puVar12 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar12) {
      do {
        puVar13 = puVar13 + 0x9e;
        puVar8 = param_2 + 0x9e;
        puVar11 = puVar13;
        for (iVar9 = 0x9e; iVar9 != 0; iVar9 = iVar9 + -1) {
          *puVar11 = *param_2;
          param_2 = param_2 + 1;
          puVar11 = puVar11 + 1;
        }
        param_2 = puVar8;
      } while (puVar8 != puVar12);
    }
  }
  FUN_0083cbe0(puVar6,iVar3 + 1,uVar5);
  return *param_1 + iVar2 * 0x278;
}



/* FUNCTION 13217 ; VA 0x008654d0 ; FUN_008654d0 */

void FUN_008654d0(uint *param_1,uint *param_2,uint *param_3)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  uint *puVar4;
  uint uVar5;
  uint *puVar6;
  
  iVar3 = (int)param_3 - (int)param_1 >> 2;
  if (iVar3 < 0x29) {
    uVar5 = *param_2;
    if (uVar5 < *param_1) {
      *param_2 = *param_1;
      *param_1 = uVar5;
      uVar5 = *param_2;
    }
    uVar2 = *param_3;
    if (uVar2 < uVar5) {
      *param_3 = uVar5;
      *param_2 = uVar2;
      if (uVar2 < *param_1) {
        *param_2 = *param_1;
        *param_1 = uVar2;
      }
    }
  }
  else {
    iVar3 = iVar3 + 1 >> 3;
    uVar5 = param_1[iVar3];
    puVar1 = param_1 + iVar3;
    if (uVar5 < *param_1) {
      *puVar1 = *param_1;
      *param_1 = uVar5;
      uVar5 = *puVar1;
    }
    uVar2 = param_1[iVar3 * 2];
    if (uVar2 < uVar5) {
      param_1[iVar3 * 2] = uVar5;
      *puVar1 = uVar2;
      if (uVar2 < *param_1) {
        *puVar1 = *param_1;
        *param_1 = uVar2;
      }
    }
    puVar4 = param_2 + -iVar3;
    uVar5 = *param_2;
    if (uVar5 < *puVar4) {
      *param_2 = *puVar4;
      *puVar4 = uVar5;
      uVar5 = *param_2;
    }
    uVar2 = param_2[iVar3];
    if (uVar2 < uVar5) {
      param_2[iVar3] = uVar5;
      *param_2 = uVar2;
      if (uVar2 < *puVar4) {
        *param_2 = *puVar4;
        *puVar4 = uVar2;
      }
    }
    puVar4 = param_3 + -iVar3;
    puVar6 = param_3 + iVar3 * -2;
    param_1 = (uint *)*puVar4;
    if (param_1 < *puVar6) {
      *puVar4 = *puVar6;
      *puVar6 = (uint)param_1;
      param_1 = (uint *)*puVar4;
    }
    uVar5 = *param_3;
    if (uVar5 < param_1) {
      *param_3 = (uint)param_1;
      *puVar4 = uVar5;
      if (uVar5 < *puVar6) {
        *puVar4 = *puVar6;
        *puVar6 = uVar5;
      }
    }
    uVar5 = *param_2;
    if (uVar5 < *puVar1) {
      *param_2 = *puVar1;
      *puVar1 = uVar5;
      uVar5 = *param_2;
    }
    uVar2 = *puVar4;
    if (uVar2 < uVar5) {
      *puVar4 = uVar5;
      *param_2 = uVar2;
      if (uVar2 < *puVar1) {
        *param_2 = *puVar1;
        *puVar1 = uVar2;
        return;
      }
    }
  }
  return;
}



/* FUNCTION 13218 ; VA 0x00865600 ; FUN_00865600 */

void FUN_00865600(int param_1,int param_2,uint param_3,uint *param_4)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar3 = (int)(param_3 - 1) >> 1;
  iVar2 = param_2;
  iVar4 = param_2;
  if (param_2 < iVar3) {
    do {
      iVar4 = (2 - (uint)(*(uint *)(param_1 + 8 + iVar2 * 8) < *(uint *)(param_1 + 4 + iVar2 * 8)))
              + iVar2 * 2;
      *(undefined4 *)(param_1 + iVar2 * 4) = *(undefined4 *)(param_1 + iVar4 * 4);
      iVar2 = iVar4;
    } while (iVar4 < iVar3);
  }
  if ((iVar4 == iVar3) && ((param_3 & 1) == 0)) {
    *(undefined4 *)(param_1 + iVar4 * 4) = *(undefined4 *)(param_1 + -4 + param_3 * 4);
    iVar4 = param_3 - 1;
  }
  if (iVar4 <= param_2) {
    *(uint *)(param_1 + iVar4 * 4) = *param_4;
    return;
  }
  do {
    iVar2 = iVar4 + -1 >> 1;
    uVar1 = *(uint *)(param_1 + iVar2 * 4);
    if (*param_4 <= uVar1) break;
    *(uint *)(param_1 + iVar4 * 4) = uVar1;
    iVar4 = iVar2;
  } while (param_2 < iVar2);
  *(uint *)(param_1 + iVar4 * 4) = *param_4;
  return;
}



/* FUNCTION 13219 ; VA 0x008656a0 ; FUN_008656a0 */

void FUN_008656a0(uint *param_1,uint *param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint *puVar4;
  int iVar5;
  uint uVar6;
  uint *puVar7;
  uint *puVar8;
  uint *puVar9;
  int iVar10;
  uint *puVar11;
  uint *puVar12;
  int iVar13;
  uint *puStack_10;
  uint *puStack_c;
  uint *puStack_8;
  
  iVar3 = (int)param_2 - (int)param_1;
  puVar4 = param_2;
  do {
    iVar13 = iVar3 >> 2;
    if (iVar13 < 0x21) {
LAB_0086586c:
      if ((1 < iVar13) && (puVar8 = param_1, param_1 != puVar4)) {
        while (puVar11 = puVar8 + 1, puVar11 != puVar4) {
          param_2 = (uint *)*puVar11;
          if (param_2 < *param_1) {
            FUN_0170cc70((int)puVar11 + (4 - ((int)puVar11 - (int)param_1)),param_1,
                         (int)puVar11 - (int)param_1);
            *param_1 = (uint)param_2;
            puVar8 = puVar11;
          }
          else {
            uVar6 = *puVar8;
            puVar8 = puVar11;
            while (param_2 < uVar6) {
              *puVar8 = uVar6;
              uVar6 = puVar8[-2];
              puVar8 = puVar8 + -1;
            }
            *puVar8 = (uint)param_2;
            puVar8 = puVar11;
          }
        }
      }
      return;
    }
    if (param_3 < 1) {
      if (0x20 < iVar13) {
        iVar13 = (int)puVar4 - (int)param_1;
        uVar6 = iVar13 >> 2;
        iVar3 = iVar13 >> 3;
        if (0 < iVar3) {
          iVar5 = (int)(uVar6 - 1) >> 1;
          do {
            uVar2 = param_1[iVar3 + -1];
            iVar3 = iVar3 + -1;
            iVar1 = iVar3;
            while (iVar1 < iVar5) {
              iVar10 = (2 - (uint)(param_1[iVar1 * 2 + 2] < param_1[iVar1 * 2 + 1])) + iVar1 * 2;
              param_1[iVar1] = param_1[iVar10];
              iVar1 = iVar10;
            }
            if ((iVar1 == iVar5) && ((uVar6 & 1) == 0)) {
              param_1[iVar1] = param_1[uVar6 - 1];
              iVar1 = uVar6 - 1;
            }
            while (iVar3 < iVar1) {
              iVar10 = iVar1 + -1 >> 1;
              if (uVar2 <= param_1[iVar10]) break;
              param_1[iVar1] = param_1[iVar10];
              iVar1 = iVar10;
            }
            param_1[iVar1] = uVar2;
          } while (0 < iVar3);
        }
        if ((int)uVar6 < 2) {
          return;
        }
        do {
          if (1 < (int)uVar6) {
            param_2 = *(uint **)((int)param_1 + iVar13 + -4);
            *(uint *)((int)param_1 + iVar13 + -4) = *param_1;
            FUN_00865600(param_1,0,iVar13 + -4 >> 2,&param_2,param_4);
          }
          iVar13 = iVar13 + -4;
          uVar6 = iVar13 >> 2;
        } while (1 < (int)uVar6);
        return;
      }
      goto LAB_0086586c;
    }
    puVar8 = param_1 + (iVar3 >> 3);
    param_2 = puVar4;
    FUN_008654d0(param_1,puVar8,puVar4 + -1,param_4);
    puVar4 = puVar8 + 1;
    for (; param_1 < puVar8; puVar8 = puVar8 + -1) {
      uVar2 = puVar8[-1];
      uVar6 = *puVar8;
      if ((uVar2 < uVar6) || (uVar2 >= uVar6 && uVar2 != uVar6)) break;
    }
    puVar11 = puVar4;
    puStack_10 = puVar4;
    puStack_8 = puVar4;
    puStack_c = puVar8;
    puVar9 = puVar8;
    if (puVar4 < param_2) {
      uVar6 = *puVar8;
      do {
        uVar2 = *puVar4;
        puVar11 = puVar4;
        puStack_10 = puVar4;
        puStack_8 = puVar4;
        if ((uVar2 < uVar6) || (uVar2 >= uVar6 && uVar2 != uVar6)) break;
        puVar4 = puVar4 + 1;
        puVar11 = puVar4;
        puStack_10 = puVar4;
        puStack_8 = puVar4;
      } while (puVar4 < param_2);
    }
joined_r0x00865732:
    puVar7 = puVar8;
    if (puVar4 < param_2) {
      uVar6 = *puVar4;
      puVar8 = puStack_c;
      if (uVar6 <= *puVar9) {
        puVar7 = puStack_c;
        puStack_8 = puVar11;
        puStack_10 = puVar4;
        if (uVar6 < *puVar9) goto joined_r0x00865761;
        if (puVar11 != puVar4) {
          uVar2 = *puVar11;
          *puVar11 = uVar6;
          *puVar4 = uVar2;
        }
        puVar11 = puVar11 + 1;
      }
      puVar4 = puVar4 + 1;
      puStack_10 = puVar4;
      puStack_8 = puVar11;
      goto joined_r0x00865732;
    }
joined_r0x00865761:
    while (puVar12 = puVar11, param_1 < puVar8) {
      puVar7 = puVar7 + -1;
      puVar4 = puStack_10;
      if (*puVar9 <= *puVar7) {
        puVar12 = puStack_8;
        puStack_c = puVar8;
        if (*puVar9 < *puVar7) break;
        puVar9 = puVar9 + -1;
        if (puVar9 != puVar7) {
          uVar6 = *puVar9;
          *puVar9 = *puVar7;
          *puVar7 = uVar6;
        }
      }
      puStack_c = puVar8 + -1;
      puVar11 = puStack_8;
      puVar8 = puStack_c;
    }
    if (puVar8 != param_1) {
      puVar8 = puVar8 + -1;
      puStack_c = puVar8;
      if (puVar4 == param_2) {
        puVar9 = puVar9 + -1;
        if (puVar8 != puVar9) {
          uVar6 = *puVar8;
          *puVar8 = *puVar9;
          *puVar9 = uVar6;
        }
        puVar11 = puVar12 + -1;
        uVar6 = *puVar9;
        *puVar9 = puVar12[-1];
        *puVar11 = uVar6;
        puStack_8 = puVar11;
      }
      else {
        uVar6 = *puVar4;
        *puVar4 = *puVar8;
        puVar4 = puVar4 + 1;
        *puVar8 = uVar6;
        puVar11 = puVar12;
        puStack_10 = puVar4;
      }
      goto joined_r0x00865732;
    }
    if (puVar4 != param_2) {
      if (puVar12 != puVar4) {
        uVar6 = *puVar9;
        *puVar9 = *puVar12;
        *puVar12 = uVar6;
      }
      uVar6 = *puVar9;
      *puVar9 = *puVar4;
      *puVar4 = uVar6;
      puVar4 = puVar4 + 1;
      puVar11 = puVar12 + 1;
      puStack_10 = puVar4;
      puStack_8 = puVar12 + 1;
      puVar9 = puVar9 + 1;
      goto joined_r0x00865732;
    }
    param_3 = (param_3 >> 1) + (param_3 >> 2);
    if ((int)((int)puVar9 - (int)param_1 & 0xfffffffcU) <
        (int)((int)param_2 - (int)puVar12 & 0xfffffffcU)) {
      FUN_008656a0(param_1,puVar9,param_3,param_4);
      param_1 = puVar12;
    }
    else {
      FUN_008656a0(puVar12,param_2,param_3,param_4);
      param_2 = puVar9;
    }
    iVar3 = (int)param_2 - (int)param_1;
    puVar4 = param_2;
  } while( true );
}



/* FUNCTION 13220 ; VA 0x008659e0 ; FUN_008659e0 */

undefined4 * __thiscall FUN_008659e0(undefined4 *param_1,undefined4 param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8778;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0083a700(1);
  param_1[0x8b] = param_2;
  *param_1 = RBX::Graphics::Shadows::ShadowObjectPoint::vftable;
  uStack_8 = 0;
  if (0x277 < (param_1[6] - param_1[5]) - 0xed0) {
    FUN_0083bd60(6,param_1 + 5);
  }
  if (0x277 < (param_1[3] - param_1[2]) - 0xed0) {
    FUN_0083bd60(6,param_1 + 2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13221 ; VA 0x00865a70 ; FUN_00865a70 */

undefined4 * __thiscall FUN_00865a70(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Graphics::Shadows::ShadowObject::vftable;
  FUN_0083aaf0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x230);
  }
  return param_1;
}



/* FUNCTION 13222 ; VA 0x00865aa0 ; FUN_00865aa0 */

void __thiscall FUN_00865aa0(int param_1,undefined4 param_2)

{
  if (DAT_01d623a4 != '\0') {
    *(undefined4 *)(param_1 + 0x1d0) = param_2;
    return;
  }
  *(undefined4 *)(param_1 + 0x1d0) = *(undefined4 *)(*(int *)(param_1 + 0x22c) + 0x34);
  return;
}



/* FUNCTION 13223 ; VA 0x00865ad0 ; FUN_00865ad0 */

void __fastcall FUN_00865ad0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined auStack_288 [632];
  int iStack_10;
  int iStack_c;
  uint uStack_8;
  
  *(undefined4 *)(param_1 + 0x18) = *(undefined4 *)(param_1 + 0x14);
  iVar3 = *(int *)(param_1 + 8);
  iVar2 = *(int *)(param_1 + 0xc) - iVar3;
  uStack_8 = 0;
  iVar5 = iVar2 >> 0x1f;
  if (iVar2 / 0x278 + iVar5 != iVar5) {
    iStack_c = 0;
    iStack_10 = param_1;
    do {
      iVar5 = iStack_c;
      puVar1 = (undefined4 *)FUN_0083ad30(auStack_288,iStack_c + iVar3,0x3f800000);
      puVar4 = *(undefined4 **)(param_1 + 0x18);
      if (*(undefined4 **)(param_1 + 0x1c) == puVar4) {
        FUN_00865370(puVar4,puVar1);
      }
      else {
        for (iVar3 = 0x9e; iVar3 != 0; iVar3 = iVar3 + -1) {
          *puVar4 = *puVar1;
          puVar1 = puVar1 + 1;
          puVar4 = puVar4 + 1;
        }
        *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 0x278;
        iVar5 = iStack_c;
      }
      iStack_c = iVar5 + 0x278;
      uStack_8 = uStack_8 + 1;
      iVar3 = *(int *)(iStack_10 + 8);
    } while (uStack_8 < (uint)((*(int *)(iStack_10 + 0xc) - iVar3) / 0x278));
  }
  return;
}



/* FUNCTION 13224 ; VA 0x00865b90 ; FUN_00865b90 */

void __thiscall FUN_00865b90(int param_1,float *param_2)

{
  undefined8 uVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  bool bVar5;
  bool bVar6;
  bool bVar7;
  float fVar8;
  bool bVar9;
  bool bVar10;
  bool bVar11;
  int iVar12;
  float fVar13;
  float fVar14;
  double dVar15;
  uint uVar16;
  float fVar17;
  uint uVar18;
  float fVar19;
  float fStack_38;
  float fStack_34;
  float fStack_2c;
  float fStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_14;
  float fStack_10;
  float fStack_c;
  
  fVar14 = DAT_018f784c;
  if ((DAT_01d623a4 != '\0') ||
     (*(int *)(param_1 + 0x1d0) != *(int *)(*(int *)(param_1 + 0x22c) + 0x34))) {
    iVar12 = *(int *)(param_1 + 0x22c);
    dVar15 = (double)(*(float *)(param_1 + 0x224) - *(float *)(iVar12 + 0xe8));
    uVar16 = (uint)DAT_018c0da0;
    uVar18 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
    bVar5 = (float)(double)CONCAT44((uint)((ulonglong)dVar15 >> 0x20) & uVar18,
                                    SUB84(dVar15,0) & uVar16) <= DAT_018f784c;
    if (!bVar5) {
      *(float *)(param_1 + 0x224) = *(float *)(iVar12 + 0xe8);
    }
    dVar15 = (double)(*(float *)(param_1 + 0x214) - *(float *)(iVar12 + 0xf0));
    bVar6 = fVar14 < (float)(double)CONCAT44((uint)((ulonglong)dVar15 >> 0x20) & uVar18,
                                             SUB84(dVar15,0) & uVar16);
    if (bVar6) {
      *(float *)(param_1 + 0x214) = *(float *)(iVar12 + 0xf0);
      iVar12 = *(int *)(param_1 + 0x22c);
    }
    fVar17 = *(float *)(iVar12 + 0xf4);
    dVar15 = (double)(*(float *)(param_1 + 0x1e0) - fVar17);
    bVar7 = fVar14 < (float)(double)CONCAT44((uint)((ulonglong)dVar15 >> 0x20) & uVar18,
                                             SUB84(dVar15,0) & uVar16);
    if (bVar7) {
      *(float *)(param_1 + 0x1e0) = fVar17;
      iVar12 = *(int *)(param_1 + 0x22c);
      *(float *)(param_1 + 500) = fVar17 + DAT_018ce2f0;
    }
    uVar1 = *(undefined8 *)(iVar12 + 0x9c);
    fVar17 = *(float *)(iVar12 + 0xa4);
    fStack_38 = (float)uVar1;
    dVar15 = (double)(*(float *)(param_1 + 0x218) - fStack_38);
    if (((fVar14 < (float)(double)CONCAT44((uint)((ulonglong)dVar15 >> 0x20) & uVar18,
                                           SUB84(dVar15,0) & uVar16)) ||
        (fStack_34 = (float)((ulonglong)uVar1 >> 0x20),
        dVar15 = (double)(*(float *)(param_1 + 0x21c) - fStack_34),
        fVar14 < (float)(double)CONCAT44((uint)((ulonglong)dVar15 >> 0x20) & uVar18,
                                         SUB84(dVar15,0) & uVar16))) ||
       (dVar15 = (double)(*(float *)(param_1 + 0x220) - fVar17),
       fVar14 < (float)(double)CONCAT44((uint)((ulonglong)dVar15 >> 0x20) & uVar18,
                                        SUB84(dVar15,0) & uVar16))) {
      *(undefined8 *)(param_1 + 0x218) = uVar1;
      *(float *)(param_1 + 0x220) = fVar17;
      bVar9 = true;
      iVar12 = *(int *)(param_1 + 0x22c);
    }
    else {
      bVar9 = false;
    }
    fVar17 = *(float *)(iVar12 + 0x18);
    fVar19 = *(float *)(iVar12 + 0x1c);
    uVar3 = *(undefined8 *)(iVar12 + 0x18);
    fVar13 = *(float *)(iVar12 + 0x20);
    fVar8 = *(float *)(iVar12 + 0x24);
    uVar1 = *(undefined8 *)(iVar12 + 0x28);
    uVar4 = *(undefined8 *)(iVar12 + 0x24);
    fStack_10 = (float)uVar1;
    fStack_c = (float)((ulonglong)uVar1 >> 0x20);
    if (((*(float *)(param_1 + 0x208) <= *(float *)(param_1 + 0x1fc) &&
          *(float *)(param_1 + 0x1fc) != *(float *)(param_1 + 0x208)) ||
        (*(float *)(param_1 + 0x20c) <= *(float *)(param_1 + 0x200) &&
         *(float *)(param_1 + 0x200) != *(float *)(param_1 + 0x20c))) ||
       (*(float *)(param_1 + 0x210) <= *(float *)(param_1 + 0x204) &&
        *(float *)(param_1 + 0x204) != *(float *)(param_1 + 0x210))) {
      *(float *)(param_1 + 0x1fc) = fVar17;
      *(float *)(param_1 + 0x200) = fVar19;
      *(float *)(param_1 + 0x204) = fVar13;
      *(float *)(param_1 + 0x208) = fVar8;
      *(undefined8 *)(param_1 + 0x20c) = uVar1;
    }
    else {
      uVar1 = *(undefined8 *)(param_1 + 0x1fc);
      uVar2 = *(undefined8 *)(param_1 + 0x208);
      fStack_38 = (float)uVar1;
      dVar15 = (double)(fStack_38 - fVar17);
      if (((fVar14 < (float)(double)CONCAT44((uint)((ulonglong)dVar15 >> 0x20) & uVar18,
                                             SUB84(dVar15,0) & uVar16)) ||
          (fStack_34 = (float)((ulonglong)uVar1 >> 0x20), dVar15 = (double)(fStack_34 - fVar19),
          fVar14 < (float)(double)CONCAT44((uint)((ulonglong)dVar15 >> 0x20) & uVar18,
                                           SUB84(dVar15,0) & uVar16))) ||
         (dVar15 = (double)(*(float *)(param_1 + 0x204) - fVar13),
         fVar14 < (float)(double)CONCAT44((uint)((ulonglong)dVar15 >> 0x20) & uVar18,
                                          SUB84(dVar15,0) & uVar16))) {
        bVar11 = true;
      }
      else {
        bVar11 = false;
        fVar13 = *(float *)(param_1 + 0x204);
        uVar3 = uVar1;
      }
      fStack_2c = (float)uVar2;
      dVar15 = (double)(fStack_2c - fVar8);
      if (((fVar14 < (float)(double)CONCAT44((uint)((ulonglong)dVar15 >> 0x20) & uVar18,
                                             SUB84(dVar15,0) & uVar16)) ||
          (fStack_28 = (float)((ulonglong)uVar2 >> 0x20),
          fVar14 < (float)(double)CONCAT44((uint)((ulonglong)(double)(fStack_28 - fStack_10) >> 0x20
                                                 ) & uVar18,
                                           SUB84((double)(fStack_28 - fStack_10),0) & uVar16))) ||
         (dVar15 = (double)(*(float *)(param_1 + 0x210) - fStack_c),
         fVar14 < (float)(double)CONCAT44((uint)((ulonglong)dVar15 >> 0x20) & uVar18,
                                          SUB84(dVar15,0) & uVar16))) {
        bVar10 = true;
      }
      else {
        bVar10 = false;
        fStack_c = *(float *)(param_1 + 0x210);
        uVar4 = uVar2;
      }
      if (bVar10 || bVar11) {
        uStack_14 = (undefined4)uVar4;
        fStack_10 = (float)((ulonglong)uVar4 >> 0x20);
        uStack_20 = (undefined4)uVar3;
        uStack_1c = (undefined4)((ulonglong)uVar3 >> 0x20);
        *(undefined4 *)(param_1 + 0x1fc) = uStack_20;
        *(undefined4 *)(param_1 + 0x200) = uStack_1c;
        *(float *)(param_1 + 0x204) = fVar13;
        *(undefined4 *)(param_1 + 0x208) = uStack_14;
        *(ulonglong *)(param_1 + 0x20c) = CONCAT44(fStack_c,fStack_10);
      }
      else if (!bVar9 && (!bVar7 && (!bVar6 && bVar5))) goto LAB_00865eaa;
    }
    *(undefined *)(param_1 + 0x1d8) = 1;
  }
LAB_00865eaa:
  fVar17 = *(float *)(param_1 + 0x21c) - param_2[1];
  fVar19 = *(float *)(param_1 + 0x218) - *param_2;
  fVar14 = *(float *)(param_1 + 0x220) - param_2[2];
  dVar15 = (double)(fVar17 * fVar17 + fVar19 * fVar19 + fVar14 * fVar14);
  FUN_017267a0();
  *(float *)(param_1 + 0x228) = (float)dVar15;
  return;
}



/* FUNCTION 13225 ; VA 0x00865f10 ; FUN_00865f10 */

int __thiscall FUN_00865f10(int param_1,uint *param_2)

{
  int *piVar1;
  char cVar2;
  byte bVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  uint uVar6;
  int iVar7;
  int *piVar8;
  uint uVar9;
  undefined4 *puVar10;
  float fVar11;
  undefined4 auStack_f40 [158];
  undefined4 auStack_cc8 [158];
  undefined auStack_a50 [632];
  undefined4 auStack_7d8 [158];
  undefined4 auStack_560 [12];
  undefined auStack_530 [584];
  undefined auStack_2e8 [588];
  undefined auStack_9c [64];
  undefined auStack_5c [12];
  int iStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  int *piStack_44;
  uint uStack_40;
  int iStack_3c;
  int *piStack_38;
  undefined4 uStack_34;
  float fStack_30;
  int iStack_2c;
  int *piStack_28;
  uint uStack_24;
  float fStack_20;
  uint uStack_1c;
  int iStack_18;
  byte bStack_12;
  bool bStack_11;
  
  piStack_28 = (int *)(param_1 + 0x14);
  piVar8 = (int *)(param_1 + 8);
  iStack_50 = param_1;
  piStack_38 = piVar8;
  if (piVar8 != piStack_28) {
    FUN_008651b0(*piStack_28,*(undefined4 *)(param_1 + 0x18),iStack_2c);
  }
  uVar5 = *(undefined4 *)(param_1 + 0x224);
  *(undefined4 *)(param_1 + 0x24) = *(undefined4 *)(param_1 + 0x20);
  param_2[1] = *param_2;
  FUN_00817dd0(param_2,param_1 + 0x218,uVar5,4);
  uVar9 = *param_2;
  uVar6 = param_2[1];
  if (uVar9 == uVar6) {
    uStack_24 = 0;
    iVar7 = piStack_28[1] - *piStack_28 >> 0x1f;
    if ((piStack_28[1] - *piStack_28) / 0x278 + iVar7 != iVar7) {
      iStack_18 = 0;
      do {
        puVar4 = (undefined4 *)FUN_0083adf0(auStack_7d8,*piVar8 + iStack_18);
        piVar1 = piStack_28;
        puVar10 = auStack_560;
        for (iVar7 = 0x9e; iVar7 != 0; iVar7 = iVar7 + -1) {
          *puVar10 = *puVar4;
          puVar4 = puVar4 + 1;
          puVar10 = puVar10 + 1;
        }
        puVar4 = auStack_560;
        puVar10 = (undefined4 *)(*piVar1 + iStack_18);
        for (iVar7 = 0x9e; iVar7 != 0; iVar7 = iVar7 + -1) {
          *puVar10 = *puVar4;
          puVar4 = puVar4 + 1;
          puVar10 = puVar10 + 1;
        }
        uStack_24 = uStack_24 + 1;
        iStack_18 = iStack_18 + 0x278;
        piVar8 = piStack_38;
      } while (uStack_24 < (uint)((piVar1[1] - *piVar1) / 0x278));
    }
    return 0;
  }
  FUN_008656a0(uVar9,uVar6,(int)(uVar6 - uVar9) >> 2,iStack_2c);
  bStack_12 = 0;
  if (DAT_01d61034 != '\0') {
    iVar7 = FUN_007a8f10();
    iVar7 = FUN_00839ea0(param_1 + 0x1ec,param_2 + 6,param_1 + 0x1fc,
                         (float)((double)iVar7 + (double)(&DAT_018c0d90)[-(iVar7 >> 0x1f)]));
    if (*(int *)(param_1 + 0x1f0) != iVar7) {
      *(int *)(param_1 + 0x1f0) = iVar7;
      bStack_12 = 1;
    }
  }
  iStack_18 = 0;
  uStack_24 = 0;
  uStack_1c = 0;
  fVar11 = DAT_018e452c;
  do {
    uVar9 = uStack_1c;
    fStack_30 = *(float *)(param_1 + 0x214);
    if (*(float *)(param_1 + 0x214) <= fVar11) {
      fStack_30 = fVar11;
    }
    iStack_2c = *(int *)(param_1 + 8);
    fStack_20 = *(float *)(param_1 + 0x224);
    if (*(float *)(param_1 + 0x224) <= fStack_30 + fVar11) {
      fStack_20 = fStack_30 + fVar11;
    }
    FUN_007cc9d0();
    uVar5 = FUN_00839b40(auStack_9c,param_1 + 0x218,uStack_24,0);
    FUN_007cdb40(uVar5);
    FUN_007cd880(0x3fcfc395,0x3f800000,fStack_30,fStack_20,0);
    if ((DAT_01d6104c == '\0') && (cVar2 = FUN_007ccbf0(auStack_2e8), cVar2 == '\0')) {
      puVar4 = (undefined4 *)FUN_0083adf0(auStack_a50,*piStack_38 + uVar9);
      puVar10 = auStack_cc8;
      for (iVar7 = 0x9e; iVar7 != 0; iVar7 = iVar7 + -1) {
        *puVar10 = *puVar4;
        puVar4 = puVar4 + 1;
        puVar10 = puVar10 + 1;
      }
      puVar4 = auStack_cc8;
LAB_00866405:
      puVar10 = (undefined4 *)(*piStack_28 + uStack_1c);
    }
    else {
      iVar7 = FUN_007a8f10();
      FUN_0083ae90(auStack_530,auStack_2e8,9,iVar7 + 0x12,iVar7 + 0x12);
      fStack_20 = *(float *)(param_1 + 0x24);
      fStack_30 = (float)((int)fStack_20 - *(int *)(param_1 + 0x20) >> 2);
      iStack_3c = 0;
      uStack_48 = 0;
      piStack_44 = (int *)*param_2;
      uStack_40 = (uint)((int)param_2[1] + (3 - (int)piStack_44)) >> 2;
      if ((int *)param_2[1] < piStack_44) {
        uStack_40 = 0;
      }
      if (uStack_40 != 0) {
        do {
          iVar7 = *piStack_44;
          iStack_3c = iVar7;
          cVar2 = FUN_007ccd20(iVar7 + 0x18);
          if (cVar2 != '\0') {
            piVar8 = *(int **)(param_1 + 0x24);
            if (*(int **)(param_1 + 0x28) == piVar8) {
              FUN_006030d0(piVar8,&iStack_3c);
            }
            else {
              *piVar8 = iVar7;
              *(int *)(param_1 + 0x24) = *(int *)(param_1 + 0x24) + 4;
            }
          }
          uStack_48 = uStack_48 + 1;
          piStack_44 = piStack_44 + 1;
        } while (uStack_48 != uStack_40);
        fStack_20 = *(float *)(param_1 + 0x24);
        uVar9 = uStack_1c;
      }
      fStack_20 = (float)((int)fStack_20 - *(int *)(param_1 + 0x20) >> 2);
      FUN_0083b1c0(auStack_5c,0,(int *)(param_1 + 0x20),fStack_30,fStack_20);
      cVar2 = FUN_008363a0(*(undefined4 *)(uVar9 + 0x260 + iStack_2c));
      bStack_11 = cVar2 == '\0';
      if (cVar2 != '\0') {
        cVar2 = FUN_00839e70(auStack_5c);
        bStack_11 = cVar2 == '\0';
      }
      uStack_4c = *(undefined4 *)(uVar9 + 0x260 + *(int *)(param_1 + 8));
      uVar6 = FUN_007a8f10();
      uStack_34 = *(undefined4 *)(uVar9 + 8 + *(int *)(param_1 + 8));
      if (DAT_01d61034 == '\0') {
        iStack_2c = 0;
        uVar6 = FUN_0083a060(&uStack_34,&iStack_2c,param_2 + 6,param_1 + 0x1fc,(float)(int)uVar6);
        bVar3 = bStack_11;
        uStack_40 = uVar6;
        if (uVar6 != *(uint *)(uVar9 + 4 + *(int *)(param_1 + 8))) {
          if (DAT_01d6104c == '\0') {
            uStack_4c = FUN_00556df0();
          }
          uVar6 = uStack_40;
          bVar3 = 1;
        }
      }
      else {
        bVar3 = bStack_11 | bStack_12;
      }
      if (bVar3 == 0) {
        puVar4 = (undefined4 *)FUN_0083ad30(auStack_a50,*piStack_38 + uVar9,uStack_34);
        puVar10 = auStack_7d8;
        for (iVar7 = 0x9e; iVar7 != 0; iVar7 = iVar7 + -1) {
          *puVar10 = *puVar4;
          puVar4 = puVar4 + 1;
          puVar10 = puVar10 + 1;
        }
        puVar4 = auStack_7d8;
        goto LAB_00866405;
      }
      puVar4 = (undefined4 *)
               FUN_0083ad60(auStack_a50,auStack_5c,auStack_2e8,*(undefined4 *)(param_1 + 500),
                            fStack_30,fStack_20,&uStack_4c,uStack_34,uVar6,0xffffffff,0xffffffff);
      piVar8 = piStack_28;
      puVar10 = auStack_f40;
      for (iVar7 = 0x9e; iVar7 != 0; iVar7 = iVar7 + -1) {
        *puVar10 = *puVar4;
        puVar4 = puVar4 + 1;
        puVar10 = puVar10 + 1;
      }
      puVar4 = auStack_f40;
      puVar10 = (undefined4 *)(*piVar8 + uStack_1c);
      iStack_18 = iStack_18 + 1;
    }
    fVar11 = DAT_018e452c;
    uStack_24 = uStack_24 + 1;
    for (iVar7 = 0x9e; iVar7 != 0; iVar7 = iVar7 + -1) {
      *puVar10 = *puVar4;
      puVar4 = puVar4 + 1;
      puVar10 = puVar10 + 1;
    }
    uStack_1c = uStack_1c + 0x278;
    param_1 = iStack_50;
    if (0xecf < uStack_1c) {
      if (0 < iStack_18) {
        *(undefined *)(iStack_50 + 0x1d8) = 1;
      }
      return iStack_18;
    }
  } while( true );
}



/* FUNCTION 13226 ; VA 0x00866460 ; FUN_00866460 */

undefined4 * __thiscall FUN_00866460(undefined4 *param_1,int param_2)

{
  FUN_0083a700((*(int *)(param_2 + 0xd4) != 2) * '\x02' + '\x02');
  param_1[0x8b] = param_2;
  *param_1 = RBX::Graphics::Shadows::ShadowObjectSpot::vftable;
  param_1[0x8c] = 0x42b40000;
  param_1[0x8d] = 0;
  param_1[0x8e] = 0x3f800000;
  param_1[0x8f] = 0;
  param_1[0x90] = 0;
  return param_1;
}



/* FUNCTION 13227 ; VA 0x008664d0 ; FUN_008664d0 */

undefined4 * __thiscall FUN_008664d0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Graphics::Shadows::ShadowObject::vftable;
  FUN_0083aaf0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x244);
  }
  return param_1;
}



/* FUNCTION 13228 ; VA 0x00866500 ; FUN_00866500 */

void FUN_00866500(float *param_1,undefined4 param_2,int param_3,float *param_4,float param_5,
                 char param_6)

{
  int iVar1;
  float fVar2;
  double dVar3;
  float fVar4;
  float fVar5;
  
  if (*(int *)(param_3 + 0x1d4) != 2) {
    fVar4 = DAT_0191ae60;
    if (param_6 != '\0') {
      fVar4 = param_5 * DAT_018ce2f4;
    }
    iVar1 = *(int *)(param_3 + 0x22c);
    dVar3 = (double)((fVar4 * DAT_018f8ff4) / DAT_01900a20);
    FUN_01728120();
    fVar2 = *(float *)(iVar1 + 0xc0) / (float)dVar3;
    fVar4 = *(float *)(iVar1 + 0xd0) / (float)dVar3;
    if (fVar4 <= fVar2) {
      fVar4 = fVar2;
    }
    fVar2 = DAT_018e452c;
    if (DAT_018e452c <= fVar4) {
      fVar2 = fVar4;
    }
    fVar4 = *(float *)(param_3 + 0x224) + fVar2;
    if (fVar4 <= fVar2 + DAT_018fde58) {
      fVar4 = fVar2 + DAT_018fde58;
    }
    FUN_007cd880((param_5 * DAT_018f8ff4) / DAT_01900a20,0x3f800000,fVar2,fVar4,0);
    fVar4 = *(float *)(param_3 + 0x21c);
    *param_1 = *(float *)(param_3 + 0x218) - *param_4 * fVar2;
    fVar5 = param_4[2];
    param_1[1] = fVar4 - param_4[1] * fVar2;
    param_1[2] = *(float *)(param_3 + 0x220) - fVar5 * fVar2;
    return;
  }
  fVar2 = (param_5 * DAT_018ce2f4 * DAT_018f8ff4) / DAT_01900a20;
  fVar4 = *(float *)(param_3 + 0x214);
  if (*(float *)(param_3 + 0x214) <= DAT_018e452c) {
    fVar4 = DAT_018e452c;
  }
  fVar5 = *(float *)(param_3 + 0x224) + fVar4;
  if (fVar5 <= fVar4 + DAT_018fde58) {
    fVar5 = fVar4 + DAT_018fde58;
  }
  FUN_007cd880(fVar2 + fVar2,0x3f800000,fVar4,fVar5,0);
  fVar4 = *(float *)(param_3 + 0x220);
  *(undefined8 *)param_1 = *(undefined8 *)(param_3 + 0x218);
  param_1[2] = fVar4;
  return;
}



/* FUNCTION 13229 ; VA 0x008666e0 ; FUN_008666e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_008666e0(undefined4 param_1,int param_2)

{
  float fVar1;
  undefined4 *puVar2;
  float *pfVar3;
  double dVar4;
  float fVar5;
  undefined auStack_110 [36];
  undefined auStack_ec [36];
  undefined auStack_c8 [64];
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined8 uStack_64;
  float fStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  undefined4 uStack_10;
  uint uStack_c;
  float fStack_8;
  
  FUN_007cc9d0();
  fVar1 = DAT_018fde94;
  if (DAT_018fde94 <= *(float *)(param_2 + 0x230)) {
    fVar1 = *(float *)(param_2 + 0x230);
  }
  fVar5 = DAT_0191ae68;
  if (fVar1 <= DAT_0191ae68) {
    fVar5 = fVar1;
  }
  FUN_00866500(&fStack_1c,param_1,param_2,(float *)(param_2 + 0x234),fVar5,1);
  dVar4 = (double)*(float *)(param_2 + 0x238);
  uStack_10 = 0;
  if (DAT_01901f3c <=
      (float)(double)CONCAT44((uint)((ulonglong)dVar4 >> 0x20) & DAT_018c0da0._4_4_,
                              SUB84(dVar4,0) & (uint)DAT_018c0da0)) {
    uStack_c = 0;
    fStack_8 = 1.0;
  }
  else {
    uStack_c = 0x3f800000;
    fStack_8 = 0.0;
  }
  uStack_58 = _DAT_018e3fb0;
  uStack_54 = _UNK_018e3fb4;
  uStack_50 = _UNK_018e3fb8;
  uStack_4c = _UNK_018e3fbc;
  fStack_2c = fStack_14;
  fStack_24 = *(float *)(param_2 + 0x238) + fStack_18;
  uStack_48 = _DAT_018e3fb0;
  uStack_44 = _UNK_018e3fb4;
  uStack_40 = _UNK_018e3fb8;
  uStack_3c = _UNK_018e3fbc;
  uStack_38 = 0x3f800000;
  fStack_34 = fStack_1c;
  fStack_30 = fStack_18;
  fStack_28 = fStack_1c + *(float *)(param_2 + 0x234);
  fStack_20 = *(float *)(param_2 + 0x23c) + fStack_14;
  FUN_01163c80(&fStack_28,(ulonglong)uStack_c << 0x20,fStack_8);
  uStack_88 = _DAT_018e3fb0;
  uStack_84 = _UNK_018e3fb4;
  uStack_80 = _UNK_018e3fb8;
  uStack_7c = _UNK_018e3fbc;
  uStack_78 = _DAT_018e3fb0;
  uStack_74 = _UNK_018e3fb4;
  uStack_70 = _UNK_018e3fb8;
  uStack_6c = _UNK_018e3fbc;
  uStack_68 = _DAT_018e3fb0;
  uStack_64 = CONCAT44(_UNK_018e3fb8,_UNK_018e3fb4);
  fStack_5c = (float)_UNK_018e3fbc;
  puVar2 = (undefined4 *)FUN_011630b0(auStack_ec);
  uStack_88 = *puVar2;
  uStack_84 = puVar2[1];
  uStack_80 = puVar2[2];
  uStack_7c = puVar2[3];
  uStack_78 = puVar2[4];
  uStack_74 = puVar2[5];
  uStack_70 = puVar2[6];
  uStack_6c = puVar2[7];
  uStack_68 = puVar2[8];
  pfVar3 = (float *)FUN_01160de0(auStack_110);
  uStack_64 = CONCAT44(pfVar3[4] * fStack_30 + pfVar3[3] * fStack_34 + pfVar3[5] * fStack_2c,
                       pfVar3[1] * fStack_30 + *pfVar3 * fStack_34 + pfVar3[2] * fStack_2c);
  fStack_5c = pfVar3[7] * fStack_30 + pfVar3[6] * fStack_34 + pfVar3[8] * fStack_2c;
  fStack_8 = fStack_5c;
  FUN_011640a0(auStack_c8);
  FUN_007cdb40(auStack_c8);
  return param_1;
}



/* FUNCTION 13230 ; VA 0x00866900 ; FUN_00866900 */

void __fastcall FUN_00866900(int param_1)

{
  undefined8 uVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  float fVar7;
  double dVar8;
  uint uVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  undefined auStack_28c [632];
  int iStack_14;
  uint uStack_10;
  int iStack_c;
  uint uStack_8;
  
  uVar1 = DAT_018c0da0;
  fVar12 = (float)(*(uint *)(param_1 + 0x234) ^ DAT_018c4ea0);
  fVar11 = (float)(*(uint *)(param_1 + 0x238) ^ DAT_018c4ea0);
  fVar10 = (float)(*(uint *)(param_1 + 0x23c) ^ DAT_018c4ea0);
  *(undefined4 *)(param_1 + 0x18) = *(undefined4 *)(param_1 + 0x14);
  dVar8 = (double)fVar12;
  uVar5 = (uint)uVar1;
  uVar9 = (uint)((ulonglong)uVar1 >> 0x20);
  fVar13 = (float)(double)CONCAT44((uint)((ulonglong)dVar8 >> 0x20) & uVar9,SUB84(dVar8,0) & uVar5);
  dVar8 = (double)fVar11;
  fVar14 = (float)(double)CONCAT44((uint)((ulonglong)dVar8 >> 0x20) & uVar9,SUB84(dVar8,0) & uVar5);
  fVar7 = (float)(double)CONCAT44((uint)((ulonglong)(double)fVar10 >> 0x20) & uVar9,
                                  SUB84((double)fVar10,0) & uVar5);
  if (fVar13 <= fVar14) {
    if (fVar7 < fVar14) {
      iVar2 = (uint)(fVar11 < 0.0) * 2 + 3;
      goto LAB_008669b3;
    }
LAB_008669a3:
    iVar4 = 4;
    iVar2 = 1;
  }
  else {
    if (fVar13 <= fVar7) goto LAB_008669a3;
    iVar4 = 0;
    iVar2 = 2;
    fVar10 = fVar12;
  }
  if (fVar10 < 0.0) {
    iVar2 = iVar4;
  }
LAB_008669b3:
  uStack_10 = 1;
  if (*(int *)(param_1 + 0x1d4) != 4) {
    uStack_10 = *(uint *)(&DAT_01d623ac + iVar2 * 4);
  }
  uVar5 = *(uint *)(param_1 + 0x240);
  uStack_8 = 0;
  if (uVar5 != 0) {
    iStack_c = 0;
    iStack_14 = param_1;
    do {
      iVar2 = iStack_14;
      if (((DAT_01d61054 == '\0') || (uVar5 < 2)) || (uStack_10 != uStack_8)) {
        puVar3 = (undefined4 *)FUN_0083ac90(auStack_28c,*(int *)(iStack_14 + 8) + iStack_c);
      }
      else {
        puVar3 = (undefined4 *)FUN_0083adf0(auStack_28c,*(int *)(iStack_14 + 8) + iStack_c);
      }
      puVar6 = *(undefined4 **)(iVar2 + 0x18);
      if (*(undefined4 **)(iVar2 + 0x1c) == puVar6) {
        FUN_00865370(puVar6,puVar3);
      }
      else {
        for (iVar4 = 0x9e; iVar4 != 0; iVar4 = iVar4 + -1) {
          *puVar6 = *puVar3;
          puVar3 = puVar3 + 1;
          puVar6 = puVar6 + 1;
        }
        *(int *)(iVar2 + 0x18) = *(int *)(iVar2 + 0x18) + 0x278;
      }
      uStack_8 = uStack_8 + 1;
      iStack_c = iStack_c + 0x278;
      uVar5 = *(uint *)(iStack_14 + 0x240);
    } while (uStack_8 < uVar5);
  }
  return;
}



/* FUNCTION 13231 ; VA 0x00866a80 ; FUN_00866a80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00866a80(int param_1,float *param_2)

{
  undefined8 uVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  bool bVar5;
  bool bVar6;
  bool bVar7;
  bool bVar8;
  int iVar9;
  bool bVar10;
  undefined4 uVar11;
  float fVar12;
  double dVar13;
  float fVar14;
  float fVar15;
  uint uVar16;
  float fVar17;
  uint uVar18;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_2c;
  float fStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_14;
  float fStack_10;
  float fStack_c;
  
  fVar12 = DAT_018f784c;
  if ((DAT_01d623a4 == '\0') &&
     (*(int *)(param_1 + 0x1d0) == *(int *)(*(int *)(param_1 + 0x22c) + 0x34))) goto LAB_00866e65;
  iVar9 = *(int *)(param_1 + 0x22c);
  dVar13 = (double)(*(float *)(param_1 + 0x224) - *(float *)(iVar9 + 0xe8));
  uVar16 = (uint)DAT_018c0da0;
  uVar18 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  bVar10 = DAT_018f784c <
           (float)(double)CONCAT44((uint)((ulonglong)dVar13 >> 0x20) & uVar18,
                                   SUB84(dVar13,0) & uVar16);
  if (bVar10) {
    *(float *)(param_1 + 0x224) = *(float *)(iVar9 + 0xe8);
  }
  dVar13 = (double)(*(float *)(param_1 + 0x230) - *(float *)(iVar9 + 0xec));
  bVar5 = fVar12 < (float)(double)CONCAT44((uint)((ulonglong)dVar13 >> 0x20) & uVar18,
                                           SUB84(dVar13,0) & uVar16);
  if (bVar5) {
    *(float *)(param_1 + 0x230) = *(float *)(iVar9 + 0xec);
    iVar9 = *(int *)(param_1 + 0x22c);
  }
  dVar13 = (double)(*(float *)(param_1 + 0x214) - *(float *)(iVar9 + 0xf0));
  bVar6 = fVar12 < (float)(double)CONCAT44((uint)((ulonglong)dVar13 >> 0x20) & uVar18,
                                           SUB84(dVar13,0) & uVar16);
  if (bVar6) {
    *(float *)(param_1 + 0x214) = *(float *)(iVar9 + 0xf0);
    iVar9 = *(int *)(param_1 + 0x22c);
  }
  fVar15 = *(float *)(iVar9 + 0xf4);
  dVar13 = (double)(*(float *)(param_1 + 0x1e0) - fVar15);
  bVar7 = fVar12 < (float)(double)CONCAT44((uint)((ulonglong)dVar13 >> 0x20) & uVar18,
                                           SUB84(dVar13,0) & uVar16);
  if (bVar7) {
    *(float *)(param_1 + 0x1e0) = fVar15;
    iVar9 = *(int *)(param_1 + 0x22c);
    *(float *)(param_1 + 500) = fVar15 + DAT_018ce2f0;
  }
  uVar1 = *(undefined8 *)(iVar9 + 0x9c);
  fVar15 = *(float *)(iVar9 + 0xa4);
  fStack_38 = (float)uVar1;
  dVar13 = (double)(*(float *)(param_1 + 0x218) - fStack_38);
  if (((fVar12 < (float)(double)CONCAT44((uint)((ulonglong)dVar13 >> 0x20) & uVar18,
                                         SUB84(dVar13,0) & uVar16)) ||
      (fStack_34 = (float)((ulonglong)uVar1 >> 0x20),
      dVar13 = (double)(*(float *)(param_1 + 0x21c) - fStack_34),
      fVar12 < (float)(double)CONCAT44((uint)((ulonglong)dVar13 >> 0x20) & uVar18,
                                       SUB84(dVar13,0) & uVar16))) ||
     (dVar13 = (double)(*(float *)(param_1 + 0x220) - fVar15),
     fVar12 < (float)(double)CONCAT44((uint)((ulonglong)dVar13 >> 0x20) & uVar18,
                                      SUB84(dVar13,0) & uVar16))) {
    *(undefined8 *)(param_1 + 0x218) = uVar1;
    *(float *)(param_1 + 0x220) = fVar15;
    iVar9 = *(int *)(param_1 + 0x22c);
    bVar8 = true;
  }
  else {
    bVar8 = false;
  }
  fVar17 = DAT_018fee54;
  uVar1 = *(undefined8 *)(iVar9 + 0xa8);
  uVar11 = 1;
  fVar15 = *(float *)(iVar9 + 0xb0);
  fStack_38 = (float)uVar1;
  fStack_34 = (float)((ulonglong)uVar1 >> 0x20);
  fVar14 = *(float *)(param_1 + 0x238) * fStack_34 + *(float *)(param_1 + 0x234) * fStack_38 +
           *(float *)(param_1 + 0x23c) * fVar15;
  if (fVar14 < DAT_018fee54) {
    *(undefined8 *)(param_1 + 0x234) = uVar1;
    *(float *)(param_1 + 0x23c) = fVar15;
    iVar9 = *(int *)(param_1 + 0x22c);
  }
  bVar10 = fVar14 < fVar17 || (bVar8 || (bVar7 || (bVar6 || (bVar5 || bVar10))));
  fVar15 = *(float *)(iVar9 + 0x18);
  fVar17 = *(float *)(iVar9 + 0x1c);
  uVar3 = *(undefined8 *)(iVar9 + 0x18);
  fStack_3c = *(float *)(iVar9 + 0x20);
  fVar14 = *(float *)(iVar9 + 0x24);
  uVar1 = *(undefined8 *)(iVar9 + 0x28);
  uVar4 = *(undefined8 *)(iVar9 + 0x24);
  fStack_10 = (float)uVar1;
  fStack_c = (float)((ulonglong)uVar1 >> 0x20);
  if (((*(float *)(param_1 + 0x208) <= *(float *)(param_1 + 0x1fc) &&
        *(float *)(param_1 + 0x1fc) != *(float *)(param_1 + 0x208)) ||
      (*(float *)(param_1 + 0x20c) <= *(float *)(param_1 + 0x200) &&
       *(float *)(param_1 + 0x200) != *(float *)(param_1 + 0x20c))) ||
     (*(float *)(param_1 + 0x210) <= *(float *)(param_1 + 0x204) &&
      *(float *)(param_1 + 0x204) != *(float *)(param_1 + 0x210))) {
    *(float *)(param_1 + 0x1fc) = fVar15;
    *(float *)(param_1 + 0x200) = fVar17;
    *(float *)(param_1 + 0x204) = fStack_3c;
    *(float *)(param_1 + 0x208) = fVar14;
    *(undefined8 *)(param_1 + 0x20c) = uVar1;
LAB_00866e3b:
    bVar10 = true;
  }
  else {
    uVar1 = *(undefined8 *)(param_1 + 0x1fc);
    uVar2 = *(undefined8 *)(param_1 + 0x208);
    fStack_38 = (float)uVar1;
    dVar13 = (double)(fStack_38 - fVar15);
    if (((fVar12 < (float)(double)CONCAT44((uint)((ulonglong)dVar13 >> 0x20) & uVar18,
                                           SUB84(dVar13,0) & uVar16)) ||
        (fStack_34 = (float)((ulonglong)uVar1 >> 0x20), dVar13 = (double)(fStack_34 - fVar17),
        fVar12 < (float)(double)CONCAT44((uint)((ulonglong)dVar13 >> 0x20) & uVar18,
                                         SUB84(dVar13,0) & uVar16))) ||
       (dVar13 = (double)(*(float *)(param_1 + 0x204) - fStack_3c),
       fVar12 < (float)(double)CONCAT44((uint)((ulonglong)dVar13 >> 0x20) & uVar18,
                                        SUB84(dVar13,0) & uVar16))) {
      bVar5 = true;
    }
    else {
      bVar5 = false;
      uVar3 = uVar1;
      fStack_3c = *(float *)(param_1 + 0x204);
    }
    fStack_2c = (float)uVar2;
    dVar13 = (double)(fStack_2c - fVar14);
    if (((fVar12 < (float)(double)CONCAT44((uint)((ulonglong)dVar13 >> 0x20) & uVar18,
                                           SUB84(dVar13,0) & uVar16)) ||
        (fStack_28 = (float)((ulonglong)uVar2 >> 0x20),
        fVar12 < (float)(double)CONCAT44((uint)((ulonglong)(double)(fStack_28 - fStack_10) >> 0x20)
                                         & uVar18,SUB84((double)(fStack_28 - fStack_10),0) & uVar16)
        )) || (dVar13 = (double)(*(float *)(param_1 + 0x210) - fStack_c),
              fVar12 < (float)(double)CONCAT44((uint)((ulonglong)dVar13 >> 0x20) & uVar18,
                                               SUB84(dVar13,0) & uVar16))) {
      bVar6 = true;
    }
    else {
      bVar6 = false;
      fStack_c = *(float *)(param_1 + 0x210);
      uVar4 = uVar2;
    }
    if (bVar6 || bVar5) {
      uStack_14 = (undefined4)uVar4;
      fStack_10 = (float)((ulonglong)uVar4 >> 0x20);
      uStack_20 = (undefined4)uVar3;
      uStack_1c = (undefined4)((ulonglong)uVar3 >> 0x20);
      *(undefined4 *)(param_1 + 0x1fc) = uStack_20;
      *(undefined4 *)(param_1 + 0x200) = uStack_1c;
      *(float *)(param_1 + 0x204) = fStack_3c;
      *(undefined4 *)(param_1 + 0x208) = uStack_14;
      *(ulonglong *)(param_1 + 0x20c) = CONCAT44(fStack_c,fStack_10);
      goto LAB_00866e3b;
    }
  }
  if (_DAT_0191ae64 <= *(float *)(param_1 + 0x230)) {
    uVar11 = 6;
  }
  *(undefined4 *)(param_1 + 0x240) = uVar11;
  if (bVar10) {
    *(undefined *)(param_1 + 0x1d8) = 1;
  }
LAB_00866e65:
  fVar15 = *(float *)(param_1 + 0x21c) - param_2[1];
  fVar17 = *(float *)(param_1 + 0x218) - *param_2;
  fVar12 = *(float *)(param_1 + 0x220) - param_2[2];
  dVar13 = (double)(fVar15 * fVar15 + fVar17 * fVar17 + fVar12 * fVar12);
  FUN_017267a0();
  *(float *)(param_1 + 0x228) = (float)dVar13;
  return;
}



/* FUNCTION 13232 ; VA 0x00866ec0 ; FUN_00866ec0 */

int FUN_00866ec0(uint *param_1)

{
  char cVar1;
  byte bVar2;
  undefined4 *puVar3;
  uint **ppuVar4;
  uint ***pppuVar5;
  uint ***pppuVar6;
  undefined4 *extraout_ECX;
  int iVar7;
  int iVar8;
  undefined ****ppppuVar9;
  int *piVar10;
  uint ***pppuVar11;
  undefined ***pppuVar12;
  undefined4 *puVar13;
  float fVar14;
  double dVar15;
  uint uVar16;
  uint ***pppuVar17;
  uint uVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  undefined4 auStack_16a8 [158];
  undefined4 auStack_1430 [158];
  undefined4 auStack_11b8 [158];
  undefined auStack_f40 [588];
  int aiStack_cf4 [145];
  undefined4 auStack_ab0 [158];
  uint *apuStack_838 [146];
  undefined **appuStack_5f0 [146];
  undefined **appuStack_3a8 [12];
  undefined auStack_378 [4];
  uint **appuStack_374 [145];
  undefined **ppuStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined **ppuStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined **ppuStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined8 uStack_a0;
  int iStack_84;
  undefined **ppuStack_80;
  uint **ppuStack_7c;
  undefined **ppuStack_78;
  undefined4 uStack_74;
  int iStack_70;
  uint ***pppuStack_6c;
  uint **ppuStack_68;
  undefined ***pppuStack_64;
  uint *puStack_60;
  int iStack_5c;
  undefined ***pppuStack_58;
  undefined4 uStack_54;
  uint **ppuStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  uint **ppuStack_44;
  undefined ***pppuStack_40;
  undefined ***pppuStack_3c;
  undefined ***pppuStack_38;
  undefined ***pppuStack_34;
  uint ***pppuStack_30;
  uint ***pppuStack_2c;
  undefined ***pppuStack_28;
  undefined ***pppuStack_24;
  undefined ***pppuStack_20;
  uint ***pppuStack_1c;
  undefined4 uVar22;
  
  FUN_016f40d0();
  pppuStack_30 = (uint ***)(extraout_ECX + 5);
  ppppuVar9 = (undefined ****)(extraout_ECX + 2);
  iStack_70 = (extraout_ECX[6] - (int)*pppuStack_30) / 0x278;
  iStack_84 = extraout_ECX[0x90];
  pppuStack_20 = (undefined ***)iStack_84;
  if (ppppuVar9 != (undefined ****)pppuStack_30) {
    pppuVar12 = *ppppuVar9;
    *ppppuVar9 = (undefined ***)*pppuStack_30;
    *pppuStack_30 = (uint **)pppuVar12;
    uVar22 = extraout_ECX[3];
    extraout_ECX[3] = extraout_ECX[6];
    extraout_ECX[6] = uVar22;
    uVar22 = extraout_ECX[4];
    extraout_ECX[4] = extraout_ECX[7];
    extraout_ECX[7] = uVar22;
    pppuStack_20 = (undefined ***)extraout_ECX[0x90];
  }
  pppuStack_1c = (uint ***)(extraout_ECX + 5);
  pppuStack_6c = (uint ***)ppppuVar9;
  if ((undefined ***)((extraout_ECX[6] - (int)*pppuStack_1c) / 0x278) != pppuStack_20) {
    pppuStack_24 = (undefined ***)0x866f6c;
    FUN_0083bd60();
    pppuStack_20 = (undefined ***)extraout_ECX[0x90];
  }
  if ((undefined ***)((extraout_ECX[3] - (int)*ppppuVar9) / 0x278) != pppuStack_20) {
    pppuStack_24 = (undefined ***)0x866f9b;
    pppuStack_1c = (uint ***)ppppuVar9;
    FUN_0083bd60();
  }
  pppuStack_20 = (undefined ***)apuStack_838;
  pppuStack_24 = (undefined ***)0x866fa8;
  FUN_008666e0();
  ppuStack_b0 = (undefined **)extraout_ECX[0x7f];
  uStack_ac = extraout_ECX[0x80];
  uStack_a8 = extraout_ECX[0x81];
  uStack_a4 = extraout_ECX[0x82];
  pppuStack_38 = (undefined ***)(param_1 + 6);
  uStack_a0 = *(undefined8 *)(extraout_ECX + 0x83);
  if ((uint)extraout_ECX[0x90] < 2) {
    pppuStack_1c = (uint ***)apuStack_838;
    pppuStack_20 = (undefined ***)0x866ff9;
    cVar1 = FUN_007ccbf0();
  }
  else {
    pppuStack_1c = (uint ***)&ppuStack_b0;
    pppuStack_20 = (undefined ***)0x866fe9;
    cVar1 = FUN_007ccd20();
  }
  if (cVar1 == '\0') {
    extraout_ECX[6] = extraout_ECX[5];
    pppuStack_2c = (uint ***)0x0;
    if (extraout_ECX[0x90] != 0) {
      pppuStack_28 = (undefined ***)0x0;
      pppuVar12 = (undefined ***)extraout_ECX;
      do {
        pppuStack_1c = (uint ***)((int)*ppppuVar9 + (int)pppuStack_28);
        pppuStack_20 = (undefined ***)auStack_ab0;
        pppuStack_24 = (undefined ***)0x867031;
        pppuStack_1c = (uint ***)FUN_0083adf0();
        puVar3 = pppuVar12[6];
        if (pppuVar12[7] == (undefined **)puVar3) {
          pppuStack_24 = (undefined ***)0x867068;
          pppuStack_20 = (undefined ***)puVar3;
          FUN_00865370();
        }
        else {
          for (iVar7 = 0x9e; iVar7 != 0; iVar7 = iVar7 + -1) {
            *puVar3 = *pppuStack_1c;
            pppuStack_1c = pppuStack_1c + 1;
            puVar3 = puVar3 + 1;
          }
          pppuVar12[6] = (undefined **)((int)pppuVar12[6] + 0x278);
          ppppuVar9 = (undefined ****)pppuStack_6c;
          pppuVar12 = pppuStack_20;
        }
        pppuStack_2c = (uint ***)((int)pppuStack_2c + 1);
        pppuStack_28 = pppuStack_28 + 0x9e;
      } while (pppuStack_2c < pppuVar12[0x90]);
    }
    return 0;
  }
  pppuStack_1c = (uint ***)0x867095;
  iStack_5c = FUN_007a8f10();
  iStack_5c = iStack_5c + 0x12;
  param_1[1] = *param_1;
  iVar7 = extraout_ECX[0x75];
  pppuStack_1c = (uint ***)0x8670ae;
  puVar3 = (undefined4 *)FUN_01165df0();
  pppuVar11 = (uint ***)pppuStack_20;
  ppuStack_130 = (undefined **)*puVar3;
  uStack_12c = puVar3[1];
  uStack_128 = puVar3[2];
  uStack_124 = puVar3[3];
  if (iVar7 == 4) {
    uStack_e0 = puVar3[4];
    uStack_dc = puVar3[5];
    uStack_d8 = puVar3[6];
    uStack_d4 = puVar3[7];
    uStack_d0 = puVar3[8];
    uStack_cc = puVar3[9];
    uStack_c8 = puVar3[10];
    uStack_c4 = puVar3[0xb];
    uStack_c0 = puVar3[0xc];
    uStack_bc = puVar3[0xd];
    uStack_b8 = puVar3[0xe];
    uStack_b4 = puVar3[0xf];
    pppuStack_1c = &ppuStack_7c;
    pppuStack_20 = (undefined ***)0x867123;
    ppuStack_f0 = ppuStack_130;
    uStack_ec = uStack_12c;
    uStack_e8 = uStack_128;
    uStack_e4 = uStack_124;
    puVar3 = (undefined4 *)FUN_011658d0();
    uStack_54 = *puVar3;
    ppuStack_50 = (uint **)puVar3[1];
    uStack_4c = puVar3[2];
    pppuStack_1c = (uint ***)&uStack_54;
    pppuStack_20 = (undefined ***)0x0;
    uStack_48 = 0;
    pppuStack_24 = (undefined ***)0x867158;
    FUN_01165f50();
    pppuStack_1c = &ppuStack_7c;
    pppuStack_20 = (undefined ***)0x86716d;
    puVar3 = (undefined4 *)FUN_011658d0();
    uStack_54 = *puVar3;
    ppuStack_50 = (uint **)puVar3[1];
    uStack_4c = puVar3[2];
    pppuStack_1c = (uint ***)&uStack_54;
    pppuStack_20 = (undefined ***)0x1;
    uStack_48 = 0;
    pppuStack_24 = (undefined ***)0x8671a2;
    FUN_01165f50();
    ppuStack_80 = ((undefined ***)pppuVar11)[0x8d];
    pppuStack_1c = (uint ***)&ppuStack_80;
    ppuStack_7c = (uint **)((undefined ***)pppuVar11)[0x8e];
    ppuStack_78 = ((undefined ***)pppuVar11)[0x8f];
    pppuStack_20 = (undefined ***)0x2;
    uStack_74 = 0;
    pppuStack_24 = (undefined ***)0x8671e1;
    FUN_01165f50();
    ppuStack_130 = ppuStack_f0;
    uStack_12c = uStack_ec;
    uStack_128 = uStack_e8;
    uStack_124 = uStack_e4;
    uStack_120 = uStack_e0;
    uStack_11c = uStack_dc;
    uStack_118 = uStack_d8;
    uStack_114 = uStack_d4;
    uStack_110 = uStack_d0;
    uStack_10c = uStack_cc;
    uStack_108 = uStack_c8;
    uStack_104 = uStack_c4;
    uStack_100 = uStack_c0;
    uStack_fc = uStack_bc;
    uStack_f8 = uStack_b8;
    uStack_f4 = uStack_b4;
  }
  else {
    uStack_120 = puVar3[4];
    uStack_11c = puVar3[5];
    uStack_118 = puVar3[6];
    uStack_114 = puVar3[7];
    uStack_110 = puVar3[8];
    uStack_10c = puVar3[9];
    uStack_108 = puVar3[10];
    uStack_104 = puVar3[0xb];
    uStack_100 = puVar3[0xc];
    uStack_fc = puVar3[0xd];
    uStack_f8 = puVar3[0xe];
    uStack_f4 = puVar3[0xf];
  }
  if (((undefined ***)pppuVar11)[0x90] < (uint **)0x2) {
    pppuStack_1c = (uint ***)iStack_5c;
    pppuStack_20 = (undefined ***)iStack_5c;
    pppuStack_24 = (undefined ***)0x9;
    pppuStack_28 = (undefined ***)apuStack_838;
    pppuStack_2c = (uint ***)auStack_378;
    pppuStack_30 = (uint ***)0x867256;
    FUN_0083ae90();
    pppuStack_20 = (undefined ***)auStack_378;
    pppuStack_1c = (uint ***)0x4;
    pppuStack_24 = (undefined ***)param_1;
    pppuStack_28 = (undefined ***)0x867271;
    FUN_00817260();
  }
  else {
    pppuStack_1c = (uint ***)0x4;
    pppuStack_20 = &ppuStack_b0;
    pppuStack_24 = (undefined ***)param_1;
    pppuStack_28 = (undefined ***)0x86723a;
    FUN_008170c0();
  }
  pppuStack_1c = (uint ***)iStack_70;
  pppuStack_24 = (undefined ***)param_1[1];
  pppuStack_28 = (undefined ***)*param_1;
  pppuStack_20 = (undefined ***)((int)pppuStack_24 - (int)pppuStack_28 >> 2);
  pppuStack_2c = (uint ***)0x86728b;
  FUN_008656a0();
  fVar19 = (float)((uint)((undefined ***)pppuVar11)[0x8f] ^ DAT_018c4ea0);
  dVar15 = (double)(float)((uint)((undefined ***)pppuVar11)[0x8d] ^ DAT_018c4ea0);
  uVar16 = (uint)DAT_018c0da0;
  uVar18 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  fVar20 = (float)(double)CONCAT44((uint)((ulonglong)dVar15 >> 0x20) & uVar18,
                                   SUB84(dVar15,0) & uVar16);
  dVar15 = (double)(float)((uint)((undefined ***)pppuVar11)[0x8e] ^ DAT_018c4ea0);
  fVar21 = (float)(double)CONCAT44((uint)((ulonglong)dVar15 >> 0x20) & uVar18,
                                   SUB84(dVar15,0) & uVar16);
  fVar14 = (float)(double)CONCAT44((uint)((ulonglong)(double)fVar19 >> 0x20) & uVar18,
                                   SUB84((double)fVar19,0) & uVar16);
  if (fVar20 <= fVar21) {
    if (fVar14 < fVar21) {
      iVar7 = (uint)((float)((uint)((undefined ***)pppuVar11)[0x8e] ^ DAT_018c4ea0) < 0.0) * 2 + 3;
      goto LAB_0086732b;
    }
LAB_0086731b:
    iVar8 = 4;
    iVar7 = 1;
  }
  else {
    if (fVar20 <= fVar14) goto LAB_0086731b;
    iVar8 = 0;
    iVar7 = 2;
    fVar19 = (float)((uint)((undefined ***)pppuVar11)[0x8d] ^ DAT_018c4ea0);
  }
  if (fVar19 < 0.0) {
    iVar7 = iVar8;
  }
LAB_0086732b:
  if ((uint **)((undefined ***)pppuVar11)[0x75] == (uint **)0x4) {
    pppuStack_58 = (undefined ***)0x1;
  }
  else {
    pppuStack_58 = (undefined ***)*(uint ****)(&DAT_01d623ac + iVar7 * 4);
  }
  uVar22 = 0;
  if (DAT_01d61034 != '\0') {
    pppuStack_1c = (uint ***)0x867359;
    iVar7 = FUN_007a8f10();
    pppuStack_20 = &ppuStack_b0;
    pppuStack_1c = (uint ***)(float)((double)iVar7 + (double)(&DAT_018c0d90)[-(iVar7 >> 0x1f)]);
    pppuStack_24 = pppuStack_38;
    pppuStack_28 = (undefined ***)pppuVar11 + 0x7b;
    pppuStack_2c = (uint ***)0x86738d;
    ppuVar4 = (uint **)FUN_00839ea0();
    if ((uint **)((undefined ***)pppuVar11)[0x7c] != ppuVar4) {
      ((undefined ***)pppuVar11)[0x7c] = (undefined **)ppuVar4;
      uVar22 = 0x10000;
    }
  }
  pppuVar5 = (uint ***)((undefined ***)pppuVar11)[0x90];
  iVar7 = 0;
  pppuStack_34 = (undefined ***)0x0;
  if (pppuVar5 != (uint ***)0x0) {
    pppuStack_1c = (uint ***)0x0;
    iVar7 = 0;
    do {
      ppuStack_44 = (uint **)*ppppuVar9;
      if (pppuVar5 == (uint ***)0x1) {
        ppuVar4 = apuStack_838;
        piVar10 = aiStack_cf4;
        for (iVar8 = 0x91; iVar8 != 0; iVar8 = iVar8 + -1) {
          *piVar10 = (int)*ppuVar4;
          ppuVar4 = ppuVar4 + 1;
          piVar10 = piVar10 + 1;
        }
        piVar10 = aiStack_cf4;
        pppuVar12 = appuStack_5f0;
        for (iVar8 = 0x91; pppuVar11 = (uint ***)pppuStack_20, iVar8 != 0; iVar8 = iVar8 + -1) {
          *pppuVar12 = (undefined **)*piVar10;
          piVar10 = piVar10 + 1;
          pppuVar12 = pppuVar12 + 1;
        }
LAB_008673f3:
        if (DAT_01d6104c == '\0') {
          pppuStack_1c = (uint ***)appuStack_5f0;
          pppuStack_20 = (undefined ***)0x86740f;
          cVar1 = FUN_007ccbf0();
          if (cVar1 == '\0') {
            pppuStack_1c = (uint ***)((int)pppuVar11[2] + (int)pppuStack_1c);
            pppuStack_20 = appuStack_3a8;
            pppuStack_24 = (undefined ***)0x86742a;
            puVar3 = (undefined4 *)FUN_0083adf0();
            puVar13 = auStack_1430;
            for (iVar8 = 0x9e; iVar8 != 0; iVar8 = iVar8 + -1) {
              *puVar13 = *puVar3;
              puVar3 = puVar3 + 1;
              puVar13 = puVar13 + 1;
            }
            puVar3 = auStack_1430;
            goto LAB_0086773f;
          }
        }
        pppuStack_1c = (uint ***)iStack_5c;
        pppuStack_20 = (undefined ***)iStack_5c;
        pppuStack_24 = (undefined ***)0x9;
        pppuStack_28 = appuStack_5f0;
        pppuStack_2c = (uint ***)auStack_f40;
        pppuStack_30 = (uint ***)0x867516;
        FUN_0083ae90();
        pppuStack_2c = (uint ***)pppuVar11[9];
        pppuStack_24 = (undefined ***)((int)pppuStack_2c - (int)pppuVar11[8] >> 2);
        pppuStack_3c = (undefined ***)0x0;
        pppuStack_64 = (undefined ***)0x0;
        puStack_60 = (uint *)*param_1;
        pppuStack_40 = (undefined ***)((uint)((int)param_1[1] + (3 - (int)puStack_60)) >> 2);
        if ((int *)param_1[1] < puStack_60) {
          pppuStack_40 = (undefined ***)(uint ***)0x0;
        }
        if ((uint ***)pppuStack_40 != (uint ***)0x0) {
          do {
            pppuVar5 = (uint ***)*puStack_60;
            pppuStack_1c = pppuVar5 + 6;
            pppuStack_20 = (undefined ***)0x867574;
            pppuStack_3c = (undefined ***)pppuVar5;
            cVar1 = FUN_007ccd20();
            if (cVar1 != '\0') {
              pppuStack_20 = (undefined ***)pppuVar11[9];
              if ((undefined ***)pppuVar11[10] == pppuStack_20) {
                pppuStack_1c = (uint ***)&pppuStack_3c;
                pppuStack_24 = (undefined ***)0x8675b2;
                FUN_006030d0();
              }
              else {
                *pppuStack_20 = (undefined **)pppuVar5;
                pppuVar11[9] = pppuVar11[9] + 1;
              }
            }
            pppuStack_64 = (undefined ***)((int)pppuStack_64 + 1);
            puStack_60 = puStack_60 + 1;
          } while (pppuStack_64 != pppuStack_40);
          pppuStack_2c = (uint ***)pppuVar11[9];
        }
        pppuStack_1c = (uint ***)((int)pppuStack_2c - (int)pppuVar11[8] >> 2);
        pppuStack_20 = pppuStack_24;
        pppuStack_2c = &ppuStack_50;
        pppuStack_28 = (undefined ***)0x0;
        pppuStack_30 = (uint ***)0x8675d1;
        pppuStack_24 = (undefined ***)(pppuVar11 + 8);
        FUN_0083b1c0();
        pppuVar5 = pppuStack_1c;
        pppuStack_1c = *(uint ****)((int)ppuStack_44 + (int)pppuStack_1c + 0x260);
        pppuStack_20 = (undefined ***)0x8675ec;
        cVar1 = FUN_008363a0();
        if ((iStack_70 == iStack_84) && (cVar1 != '\0')) {
          pppuStack_1c = &ppuStack_50;
          pppuStack_20 = (undefined ***)0x86760a;
          cVar1 = FUN_00839e70();
          uVar22 = CONCAT13(cVar1 == '\0',(int3)uVar22);
        }
        else {
          uVar22 = CONCAT13(1,(int3)uVar22);
        }
        ppuStack_68 = *(uint ***)((int)pppuVar11[2] + (int)pppuVar5 + 0x260);
        pppuStack_1c = (uint ***)0x86762a;
        pppuVar6 = (uint ***)FUN_007a8f10();
        bVar2 = (byte)((uint)uVar22 >> 0x18);
        if (DAT_01d61034 == '\0') {
          pppuStack_20 = &ppuStack_b0;
          pppuStack_1c = (uint ***)(float)(int)pppuVar6;
          ppuStack_44 = (uint **)0x0;
          pppuStack_24 = pppuStack_38;
          pppuStack_28 = (undefined ***)&ppuStack_44;
          pppuStack_2c = (uint ***)&pppuStack_28;
          pppuStack_30 = (uint ***)0x867676;
          pppuVar6 = (uint ***)FUN_0083a060();
          pppuVar17 = (uint ***)pppuStack_28;
          pppuStack_40 = (undefined ***)pppuVar6;
          if (pppuVar6 != *(uint ****)((int)pppuVar11[2] + (int)pppuVar5 + 4)) {
            if (DAT_01d6104c == '\0') {
              pppuStack_1c = (uint ***)0x867695;
              ppuStack_68 = (uint **)FUN_00556df0();
            }
            bVar2 = 1;
            pppuVar6 = (uint ***)pppuStack_40;
            pppuVar17 = (uint ***)pppuStack_28;
          }
        }
        else {
          bVar2 = bVar2 | (byte)((uint)uVar22 >> 0x10);
          pppuVar17 = *(uint ****)((int)pppuVar11[2] + (int)pppuVar5 + 8);
        }
        if (bVar2 == 0) {
          pppuStack_20 = (undefined ***)((int)pppuVar11[2] + (int)pppuVar5);
          pppuStack_24 = appuStack_3a8;
          pppuStack_28 = (undefined ***)0x867727;
          pppuStack_1c = pppuVar17;
          puVar3 = (undefined4 *)FUN_0083ad30();
          puVar13 = auStack_ab0;
          for (iVar8 = 0x9e; iVar8 != 0; iVar8 = iVar8 + -1) {
            *puVar13 = *puVar3;
            puVar3 = puVar3 + 1;
            puVar13 = puVar13 + 1;
          }
          puVar3 = auStack_ab0;
          goto LAB_0086773f;
        }
        pppuStack_38 = (undefined ***)pppuVar11[0x7d];
        pppuStack_30 = &ppuStack_68;
        pppuStack_1c = (uint ***)0xffffffff;
        pppuStack_20 = (undefined ***)0xffffffff;
        pppuStack_3c = appuStack_5f0;
        pppuStack_40 = (undefined ***)&ppuStack_50;
        ppuStack_44 = (uint **)appuStack_3a8;
        uStack_48 = 0x8676e6;
        pppuStack_34 = (undefined ***)pppuVar6;
        pppuStack_2c = pppuStack_30;
        pppuStack_28 = (undefined ***)pppuVar17;
        pppuStack_24 = (undefined ***)pppuVar6;
        puVar3 = (undefined4 *)FUN_0083ad60();
        puVar13 = auStack_16a8;
        for (iVar8 = 0x9e; iVar8 != 0; iVar8 = iVar8 + -1) {
          *puVar13 = *puVar3;
          puVar3 = puVar3 + 1;
          puVar13 = puVar13 + 1;
        }
        puVar3 = auStack_16a8;
        puVar13 = (undefined4 *)((int)*pppuStack_30 + (int)pppuStack_1c);
        iVar7 = iVar7 + 1;
      }
      else {
        pppuStack_1c = (uint ***)0x867452;
        FUN_007cc9d0();
        pppuStack_1c = (uint ***)0x0;
        pppuStack_20 = (undefined ***)0x42ba0000;
        pppuStack_24 = (undefined ***)(pppuVar11 + 0x8d);
        pppuStack_2c = appuStack_374;
        pppuStack_30 = &ppuStack_7c;
        pppuStack_34 = (undefined ***)0x867474;
        pppuStack_28 = (undefined ***)pppuVar11;
        FUN_00866500();
        pppuStack_38 = &ppuStack_130;
        pppuStack_3c = (undefined ***)&ppuStack_7c;
        pppuStack_40 = &ppuStack_f0;
        ppuStack_44 = (uint **)0x86748e;
        pppuStack_34 = pppuStack_38;
        pppuStack_1c = (uint ***)FUN_00839b40();
        pppuStack_20 = (undefined ***)0x86749d;
        FUN_007cdb40();
        pppuVar11 = appuStack_374;
        pppuVar12 = appuStack_5f0;
        for (iVar8 = 0x91; iVar8 != 0; iVar8 = iVar8 + -1) {
          *pppuVar12 = (undefined **)*pppuVar11;
          pppuVar11 = pppuVar11 + 1;
          pppuVar12 = pppuVar12 + 1;
        }
        pppuVar11 = (uint ***)pppuStack_20;
        if ((pppuStack_20[0x90] < (uint **)0x2) || (pppuStack_58 != pppuStack_34))
        goto LAB_008673f3;
        pppuStack_1c = (uint ***)((int)pppuStack_20[2] + (int)pppuStack_1c);
        pppuStack_20 = appuStack_3a8;
        pppuStack_24 = (undefined ***)0x8674df;
        puVar3 = (undefined4 *)FUN_0083adf0();
        puVar13 = auStack_11b8;
        for (iVar8 = 0x9e; iVar8 != 0; iVar8 = iVar8 + -1) {
          *puVar13 = *puVar3;
          puVar3 = puVar3 + 1;
          puVar13 = puVar13 + 1;
        }
        puVar3 = auStack_11b8;
LAB_0086773f:
        puVar13 = (undefined4 *)((int)*pppuStack_30 + (int)pppuStack_1c);
      }
      pppuStack_1c = pppuStack_1c + 0x9e;
      for (iVar8 = 0x9e; iVar8 != 0; iVar8 = iVar8 + -1) {
        *puVar13 = *puVar3;
        puVar3 = puVar3 + 1;
        puVar13 = puVar13 + 1;
      }
      pppuStack_34 = (undefined ***)((int)pppuStack_34 + 1);
      pppuVar5 = (uint ***)pppuStack_20[0x90];
      ppppuVar9 = (undefined ****)pppuStack_6c;
      pppuVar11 = (uint ***)pppuStack_20;
    } while (pppuStack_34 < pppuVar5);
    if (0 < iVar7) {
      *(undefined *)(pppuStack_20 + 0x76) = 1;
    }
  }
  return iVar7;
}



/* FUNCTION 13233 ; VA 0x00867790 ; FUN_00867790 */

int FUN_00867790(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8790;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00616d10(param_1,param_2);
  uStack_8 = 0;
  FUN_00746e10(iVar1 + 8);
  *(undefined4 *)(iVar1 + 0xc) = 0;
  *(undefined4 *)(iVar1 + 0x10) = 0;
  *(undefined4 *)(iVar1 + 0x14) = 0;
  *(undefined4 *)(iVar1 + 0x18) = 0;
  *(undefined4 *)(iVar1 + 0x1c) = 0;
  *(undefined4 *)(iVar1 + 0x20) = 0;
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 13234 ; VA 0x00867816 ; Catch_All@00867816 */

void Catch_All_00867816(void)

{
  int unaff_EBP;
  
  FUN_00781060(*(undefined4 *)(unaff_EBP + 0xc),1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 13235 ; VA 0x00867830 ; FUN_00867830 */

int __thiscall FUN_00867830(uint *param_1,uint param_2,undefined4 param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  
  uVar8 = *param_1;
  iVar1 = (int)(param_1[1] - uVar8) / 0x2c;
  if (iVar1 == 0x5d1745d) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar5 = iVar1 + 1;
  uVar2 = (int)(param_1[2] - uVar8) / 0x2c;
  uVar7 = uVar5;
  if ((uVar2 <= 0x5d1745d - (uVar2 >> 1)) && (uVar7 = (uVar2 >> 1) + uVar2, uVar7 < uVar5)) {
    uVar7 = uVar5;
  }
  uVar5 = uVar7 * 0x2c;
  if (uVar7 < 0x5d1745e) {
    uVar7 = uVar5;
    if (0xfff < uVar5) goto LAB_008678cb;
    if (uVar5 == 0) {
      uVar7 = 0;
    }
    else {
      uVar7 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_008678cb:
    uVar2 = uVar7 + 0x23;
    if (uVar2 <= uVar7) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_008679d5;
    uVar7 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar7 - 4) = iVar3;
  }
  iVar4 = ((int)(param_2 - uVar8) / 0x2c) * 0x2c;
  iVar3 = iVar4 + uVar7;
  FUN_00868830(param_1,iVar3,param_3);
  uVar2 = param_1[1];
  uVar8 = *param_1;
  uVar6 = uVar7;
  if (param_2 != uVar2) {
    FUN_00868780(uVar8,param_2,uVar7,param_1);
    uVar2 = param_1[1];
    uVar8 = param_2;
    uVar6 = iVar3 + 0x2c;
  }
  FUN_00868780(uVar8,uVar2,uVar6,param_1);
  uVar8 = *param_1;
  if (uVar8 != 0) {
    uVar2 = param_1[1];
    if (uVar8 != uVar2) {
      do {
        FUN_0056b650();
        uVar8 = uVar8 + 0x2c;
      } while (uVar8 != uVar2);
      uVar8 = *param_1;
    }
    uVar6 = ((int)(param_1[2] - uVar8) / 0x2c) * 0x2c;
    uVar2 = uVar8;
    if (0xfff < uVar6) {
      uVar2 = *(uint *)(uVar8 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar8 - uVar2) - 4) {
LAB_008679d5:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar6);
  }
  *param_1 = uVar7;
  param_1[1] = (iVar1 + 1) * 0x2c + uVar7;
  param_1[2] = uVar5 + uVar7;
  return *param_1 + iVar4;
}



/* FUNCTION 13236 ; VA 0x008679e0 ; FUN_008679e0 */

void __thiscall
FUN_008679e0(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x4924922 < (uint)param_1[1]) {
    FUN_008695e0(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00867a92:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00867a92;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 13237 ; VA 0x00867b40 ; FUN_00867b40 */

undefined4 * __thiscall
FUN_00867b40(int *param_1,undefined4 *param_2,int *param_3,uint *param_4,undefined4 param_5)

{
  int iVar1;
  undefined *puVar2;
  char cVar3;
  int *piVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined auStack_24 [8];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b87a0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  piStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd0;
    FUN_008679e0(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar4 = (int *)*param_1;
  if (param_3 == (int *)*piVar4) {
    if ((*param_4 < (uint)param_3[4]) ||
       ((ExceptionList = &pvStack_10, puStack_14 = &stack0xffffffd0, *param_4 <= (uint)param_3[4] &&
        (ExceptionList = &pvStack_10, puStack_14 = &stack0xffffffd0, (int)param_4[1] < param_3[5])))
       ) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd0;
      FUN_008679e0(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar4) {
    iVar1 = piVar4[2];
    if ((*(uint *)(iVar1 + 0x10) < *param_4) ||
       ((ExceptionList = &pvStack_10, puStack_14 = &stack0xffffffd0,
        *(uint *)(iVar1 + 0x10) <= *param_4 &&
        (ExceptionList = &pvStack_10, puStack_14 = &stack0xffffffd0,
        *(int *)(iVar1 + 0x14) < (int)param_4[1])))) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd0;
      FUN_008679e0(param_2,0,iVar1,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    if ((*param_4 < (uint)param_3[4]) ||
       ((ExceptionList = &pvStack_10, puVar2 = &stack0xffffffd0, *param_4 <= (uint)param_3[4] &&
        (ExceptionList = &pvStack_10, puVar2 = &stack0xffffffd0, (int)param_4[1] < param_3[5])))) {
      piStack_18 = param_3;
      ExceptionList = &pvStack_10;
      piVar4 = (int *)FUN_0056f560();
      cVar3 = FUN_00845c00(*piVar4 + 0x10,param_4);
      puVar2 = puStack_14;
      if (cVar3 != '\0') {
        if (*(char *)(piStack_18[2] + 0xd) == '\0') {
          FUN_008679e0(param_2,1,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_008679e0(param_2,0,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    puStack_14 = puVar2;
    cVar3 = FUN_00845c00(param_3 + 4,param_4);
    if (cVar3 != '\0') {
      piStack_18 = param_3;
      piVar5 = (int *)FUN_00551320();
      piVar4 = piStack_18;
      if ((*piVar5 == *param_1) || (cVar3 = FUN_00845c00(param_4,piStack_18 + 4), cVar3 != '\0')) {
        if (*(char *)(param_3[2] + 0xd) == '\0') {
          FUN_008679e0(param_2,1,piVar4,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_008679e0(param_2,0,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = (undefined4 *)FUN_00867d90(auStack_24,0,param_4,param_5);
  *param_2 = *puVar6;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 13238 ; VA 0x00867d75 ; Catch_All@00867d75 */

void Catch_All_00867d75(void)

{
  int unaff_EBP;
  
  FUN_008695e0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 13239 ; VA 0x00867d90 ; FUN_00867d90 */

void __thiscall
FUN_00867d90(int *param_1,undefined4 *param_2,char param_3,uint *param_4,undefined4 param_5)

{
  uint uVar1;
  uint uVar2;
  uint *puVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar3 = param_4;
  puStack_c = &LAB_017b87b0;
  pvStack_10 = ExceptionList;
  puVar5 = (undefined4 *)*param_1;
  cVar4 = '\x01';
  uStack_8 = 0;
  if (*(char *)((int)puVar5[1] + 0xd) == '\0') {
    uVar1 = *param_4;
    puVar6 = (undefined4 *)puVar5[1];
    do {
      puVar5 = puVar6;
      uVar2 = puVar5[4];
      if (param_3 == '\0') {
        if ((uVar1 < uVar2) || ((uVar1 <= uVar2 && ((int)param_4[1] < (int)puVar5[5])))) {
          cVar4 = '\x01';
          goto LAB_00867e17;
        }
        cVar4 = '\0';
LAB_00867e0d:
        puVar6 = (undefined4 *)puVar5[2];
      }
      else {
        if ((uVar2 < uVar1) || ((uVar2 <= uVar1 && ((int)puVar5[5] < (int)param_4[1])))) {
          cVar4 = '\0';
        }
        else {
          cVar4 = '\x01';
        }
        if (cVar4 == '\0') goto LAB_00867e0d;
LAB_00867e17:
        puVar6 = (undefined4 *)*puVar5;
      }
    } while (*(char *)((int)puVar6 + 0xd) == '\0');
  }
  ExceptionList = &pvStack_10;
  _param_3 = puVar5;
  if (cVar4 != '\0') {
    if (puVar5 == *(undefined4 **)*param_1) {
      cVar4 = '\x01';
      ExceptionList = &pvStack_10;
      goto LAB_00867e38;
    }
    ExceptionList = &pvStack_10;
    FUN_0056f560();
  }
  puVar6 = _param_3;
  if ((*puVar3 <= (uint)_param_3[4]) &&
     ((*puVar3 < (uint)_param_3[4] || ((int)puVar3[1] <= (int)_param_3[5])))) {
    FUN_008695e0(param_5);
    *param_2 = puVar6;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00867e38:
  puVar5 = (undefined4 *)FUN_008679e0(&param_3,cVar4,puVar5,puVar3,param_5);
  *param_2 = *puVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13240 ; VA 0x00867eaf ; Catch_All@00867eaf */

void Catch_All_00867eaf(void)

{
  int unaff_EBP;
  
  FUN_008695e0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 13241 ; VA 0x00867ed0 ; FUN_00867ed0 */

void FUN_00867ed0(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  
  iVar2 = *param_2;
  if ((((byte)*(undefined4 *)(*param_1 + 0xc) & 4) < ((byte)*(undefined4 *)(iVar2 + 0xc) & 4)) &&
     (param_2 != param_1)) {
    *param_2 = *param_1;
    *param_1 = iVar2;
    iVar2 = param_2[1];
    param_2[1] = param_1[1];
    param_1[1] = iVar2;
    iVar2 = *param_2;
  }
  iVar1 = *param_3;
  if (((byte)*(undefined4 *)(iVar2 + 0xc) & 4) < ((byte)*(undefined4 *)(iVar1 + 0xc) & 4)) {
    if (param_3 != param_2) {
      *param_3 = iVar2;
      *param_2 = iVar1;
      iVar2 = param_3[1];
      param_3[1] = param_2[1];
      param_2[1] = iVar2;
      iVar2 = *param_2;
    }
    if ((((byte)*(undefined4 *)(*param_1 + 0xc) & 4) < ((byte)*(undefined4 *)(iVar2 + 0xc) & 4)) &&
       (param_2 != param_1)) {
      *param_2 = *param_1;
      *param_1 = iVar2;
      iVar2 = param_2[1];
      param_2[1] = param_1[1];
      param_1[1] = iVar2;
    }
  }
  return;
}



/* FUNCTION 13242 ; VA 0x00867f70 ; FUN_00867f70 */

void FUN_00867f70(uint *param_1,int *param_2,int *param_3,int *param_4)

{
  int iVar1;
  uint uVar2;
  int *piVar3;
  uint uVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  int *piVar9;
  int *piStack_8;
  
  piVar3 = param_3 + -2;
  piVar8 = param_2 + ((int)param_3 - (int)param_2 >> 4) * 2;
  iVar1 = (int)piVar3 - (int)param_2 >> 3;
  if (iVar1 < 0x29) {
    FUN_00867ed0(param_2,piVar8,piVar3,param_4);
  }
  else {
    iVar1 = iVar1 + 1 >> 3;
    FUN_00867ed0(param_2,param_2 + iVar1 * 2,param_2 + iVar1 * 4,param_4);
    FUN_00867ed0(piVar8 + iVar1 * -2,piVar8,piVar8 + iVar1 * 2,param_4);
    FUN_00867ed0(piVar3 + iVar1 * -4,piVar3 + iVar1 * -2,piVar3,param_4);
    FUN_00867ed0(param_2 + iVar1 * 2,piVar8,piVar3 + iVar1 * -2,param_4);
  }
  piVar3 = piVar8 + 2;
  while (((param_2 < piVar8 &&
          (uVar4 = *(uint *)(piVar8[-2] + 0xc) & 4, uVar2 = *(uint *)(*piVar8 + 0xc) & 4,
          uVar4 <= uVar2)) && (uVar2 <= uVar4))) {
    piVar8 = piVar8 + -2;
  }
  piVar7 = piVar3;
  piStack_8 = piVar3;
  param_4 = piVar8;
  if (piVar3 < param_3) {
    uVar2 = *(uint *)(*piVar8 + 0xc) & 4;
    do {
      uVar4 = *(uint *)(*piVar3 + 0xc) & 4;
      piVar7 = piVar3;
      piStack_8 = piVar3;
      if ((uVar2 < uVar4) || (uVar4 < uVar2)) break;
      piVar3 = piVar3 + 2;
      piVar7 = piVar3;
      piStack_8 = piVar3;
    } while (piVar3 < param_3);
  }
joined_r0x00868082:
  do {
    piVar6 = piVar8;
    piVar9 = piVar7;
    piVar8 = param_4;
    if (param_3 <= piVar3) {
joined_r0x008680c6:
      for (; param_2 < param_4; param_4 = param_4 + -2) {
        piVar5 = piVar8 + -2;
        uVar2 = *(uint *)(*piVar5 + 0xc) & 4;
        uVar4 = *(uint *)(*piVar6 + 0xc) & 4;
        piVar7 = piVar6;
        piVar3 = piStack_8;
        if (uVar2 <= uVar4) {
          if (uVar2 < uVar4) break;
          piVar7 = piVar6 + -2;
          if (piVar7 != piVar5) {
            iVar1 = *piVar7;
            *piVar7 = *piVar5;
            *piVar5 = iVar1;
            iVar1 = piVar6[-1];
            piVar6[-1] = piVar8[-1];
            piVar8[-1] = iVar1;
          }
        }
        piVar6 = piVar7;
        piVar8 = piVar5;
      }
      if (param_4 == param_2) {
        if (piVar3 == param_3) {
          param_1[1] = (uint)piVar9;
          *param_1 = (uint)piVar6;
          return;
        }
        if ((piVar9 != piVar3) && (piVar6 != piVar9)) {
          iVar1 = *piVar6;
          *piVar6 = *piVar9;
          *piVar9 = iVar1;
          iVar1 = piVar6[1];
          piVar6[1] = piVar9[1];
          piVar9[1] = iVar1;
        }
        if (piVar6 != piVar3) {
          iVar1 = *piVar6;
          *piVar6 = *piVar3;
          *piVar3 = iVar1;
          iVar1 = piVar6[1];
          piVar6[1] = piVar3[1];
          piVar3[1] = iVar1;
        }
        piVar3 = piVar3 + 2;
        piVar7 = piVar9 + 2;
        piStack_8 = piVar3;
        piVar8 = piVar6 + 2;
      }
      else {
        piVar5 = param_4 + -2;
        if (piVar3 == param_3) {
          piVar8 = piVar6 + -2;
          if (piVar5 != piVar8) {
            iVar1 = *piVar5;
            *piVar5 = *piVar8;
            *piVar8 = iVar1;
            iVar1 = param_4[-1];
            param_4[-1] = piVar6[-1];
            piVar6[-1] = iVar1;
          }
          piVar7 = piVar9 + -2;
          param_4 = piVar5;
          if (piVar8 != piVar7) {
            iVar1 = *piVar8;
            *piVar8 = *piVar7;
            *piVar7 = iVar1;
            iVar1 = piVar6[-1];
            piVar6[-1] = piVar9[-1];
            piVar9[-1] = iVar1;
          }
        }
        else {
          if (piVar3 != piVar5) {
            iVar1 = *piVar3;
            *piVar3 = *piVar5;
            *piVar5 = iVar1;
            iVar1 = piVar3[1];
            piVar3[1] = param_4[-1];
            param_4[-1] = iVar1;
          }
          piVar3 = piVar3 + 2;
          piVar7 = piVar9;
          piStack_8 = piVar3;
          param_4 = piVar5;
          piVar8 = piVar6;
        }
      }
      goto joined_r0x00868082;
    }
    uVar2 = *(uint *)(*piVar6 + 0xc) & 4;
    uVar4 = *(uint *)(*piVar3 + 0xc) & 4;
    if (uVar2 <= uVar4) {
      piStack_8 = piVar3;
      if (uVar2 < uVar4) goto joined_r0x008680c6;
      if (piVar9 != piVar3) {
        iVar1 = *piVar9;
        *piVar9 = *piVar3;
        *piVar3 = iVar1;
        iVar1 = piVar9[1];
        piVar9[1] = piVar3[1];
        piVar3[1] = iVar1;
      }
      piVar9 = piVar9 + 2;
    }
    piVar3 = piVar3 + 2;
    piVar7 = piVar9;
    piStack_8 = piVar3;
    piVar8 = piVar6;
  } while( true );
}



/* FUNCTION 13243 ; VA 0x00868210 ; FUN_00868210 */

void FUN_00868210(int param_1,int param_2,uint param_3,int *param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar3 = (int)(param_3 - 1) >> 1;
  iVar1 = param_2;
  iVar2 = param_2;
  if (param_2 < iVar3) {
    do {
      iVar2 = (2 - (uint)(((byte)*(undefined4 *)(*(int *)(param_1 + 8 + iVar1 * 0x10) + 0xc) & 4) <
                         ((byte)*(undefined4 *)(*(int *)(param_1 + 0x10 + iVar1 * 0x10) + 0xc) & 4))
              ) + iVar1 * 2;
      *(undefined4 *)(param_1 + iVar1 * 8) = *(undefined4 *)(param_1 + iVar2 * 8);
      *(undefined4 *)(param_1 + 4 + iVar1 * 8) = *(undefined4 *)(param_1 + 4 + iVar2 * 8);
      iVar1 = iVar2;
    } while (iVar2 < iVar3);
  }
  if ((iVar2 == iVar3) && ((param_3 & 1) == 0)) {
    *(undefined4 *)(param_1 + iVar2 * 8) = *(undefined4 *)(param_1 + -8 + param_3 * 8);
    *(undefined4 *)(param_1 + 4 + iVar2 * 8) = *(undefined4 *)(param_1 + -4 + param_3 * 8);
    iVar2 = param_3 - 1;
  }
  while (param_2 < iVar2) {
    iVar3 = iVar2 + -1 >> 1;
    iVar1 = *(int *)(param_1 + iVar3 * 8);
    if (((byte)*(undefined4 *)(iVar1 + 0xc) & 4) <= ((byte)*(undefined4 *)(*param_4 + 0xc) & 4))
    break;
    *(int *)(param_1 + iVar2 * 8) = iVar1;
    *(undefined4 *)(param_1 + 4 + iVar2 * 8) = *(undefined4 *)(param_1 + 4 + iVar3 * 8);
    iVar2 = iVar3;
  }
  *(int *)(param_1 + iVar2 * 8) = *param_4;
  *(int *)(param_1 + 4 + iVar2 * 8) = param_4[1];
  return;
}



/* FUNCTION 13244 ; VA 0x008682e0 ; FUN_008682e0 */

void __thiscall FUN_008682e0(uint *param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  uint uVar11;
  
  uVar7 = (int)(param_1[1] - *param_1) / 0x58;
  uVar8 = (int)(param_1[2] - *param_1) / 0x58;
  if (param_2 <= uVar8) {
    if (param_2 <= uVar7) {
      if (param_2 != uVar7) {
        param_1[1] = param_2 * 0x58 + *param_1;
      }
      return;
    }
    uVar7 = FUN_00869430(param_1[1],param_2 - uVar7);
    param_1[1] = uVar7;
    return;
  }
  if (0x2e8ba2e < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar11 = param_2;
  if ((uVar8 <= 0x2e8ba2e - (uVar8 >> 1)) && (uVar11 = (uVar8 >> 1) + uVar8, uVar11 < param_2)) {
    uVar11 = param_2;
  }
  uVar8 = uVar11 * 0x58;
  if (uVar11 < 0x2e8ba2f) {
    uVar11 = uVar8;
    if (0xfff < uVar8) goto LAB_0086836c;
    if (uVar8 == 0) {
      uVar11 = 0;
    }
    else {
      uVar11 = FUN_01674e20(uVar8);
    }
  }
  else {
    uVar11 = 0xffffffff;
LAB_0086836c:
    uVar5 = uVar11 + 0x23;
    if (uVar5 <= uVar11) {
      uVar5 = 0xffffffff;
    }
    iVar6 = FUN_01674e20(uVar5);
    if (iVar6 == 0) goto LAB_008684a0;
    uVar11 = iVar6 + 0x23U & 0xffffffe0;
    *(int *)(uVar11 - 4) = iVar6;
  }
  FUN_00869430(uVar7 * 0x58 + uVar11,param_2 - uVar7);
  puVar9 = (undefined4 *)*param_1;
  puVar10 = (undefined4 *)param_1[1];
  if (puVar9 != puVar10) {
    iVar6 = uVar11 - (int)puVar9;
    do {
      uVar2 = puVar9[1];
      uVar3 = puVar9[2];
      uVar4 = puVar9[3];
      puVar1 = (undefined4 *)(iVar6 + (int)puVar9);
      *puVar1 = *puVar9;
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      uVar2 = puVar9[5];
      uVar3 = puVar9[6];
      uVar4 = puVar9[7];
      puVar1 = (undefined4 *)(iVar6 + 0x10 + (int)puVar9);
      *puVar1 = puVar9[4];
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      uVar2 = puVar9[9];
      uVar3 = puVar9[10];
      uVar4 = puVar9[0xb];
      puVar1 = (undefined4 *)(iVar6 + 0x20 + (int)puVar9);
      *puVar1 = puVar9[8];
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      uVar2 = puVar9[0xd];
      uVar3 = puVar9[0xe];
      uVar4 = puVar9[0xf];
      puVar1 = (undefined4 *)(iVar6 + 0x30 + (int)puVar9);
      *puVar1 = puVar9[0xc];
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      uVar2 = puVar9[0x11];
      uVar3 = puVar9[0x12];
      uVar4 = puVar9[0x13];
      puVar1 = (undefined4 *)(iVar6 + 0x40 + (int)puVar9);
      *puVar1 = puVar9[0x10];
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      *(undefined8 *)(iVar6 + 0x50 + (int)puVar9) = *(undefined8 *)(puVar9 + 0x14);
      puVar9 = puVar9 + 0x16;
    } while (puVar9 != puVar10);
    puVar9 = (undefined4 *)*param_1;
  }
  if (puVar9 != (undefined4 *)0x0) {
    uVar7 = ((int)(param_1[2] - (int)puVar9) / 0x58) * 0x58;
    puVar10 = puVar9;
    if (0xfff < uVar7) {
      puVar10 = (undefined4 *)puVar9[-1];
      uVar7 = uVar7 + 0x23;
      if (0x1f < (uint)((int)puVar9 + (-4 - (int)puVar10))) {
LAB_008684a0:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar10,uVar7);
  }
  *param_1 = uVar11;
  param_1[1] = param_2 * 0x58 + uVar11;
  param_1[2] = uVar8 + uVar11;
  return;
}



/* FUNCTION 13245 ; VA 0x008684b0 ; FUN_008684b0 */

void FUN_008684b0(int *param_1,int *param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  bool bVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  int iVar8;
  int iVar9;
  int *piVar10;
  int *piVar11;
  int *piVar12;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  int iStack_10;
  uint uStack_c;
  int iStack_8;
  
  iVar4 = (int)param_2 - (int)param_1;
  piVar7 = param_2;
  piVar10 = param_1;
  do {
    iVar4 = iVar4 >> 3;
    if (iVar4 < 0x21) {
LAB_0086853d:
      if ((1 < iVar4) && (piVar3 = piVar10, piVar10 != piVar7)) {
        while (piVar7 = piVar3 + 2, piVar7 != param_2) {
          iVar4 = *piVar7;
          iVar9 = piVar3[3];
          uVar6 = *(uint *)(iVar4 + 0xc) & 4;
          if ((*(uint *)(*piVar10 + 0xc) & 4) < uVar6) {
            piVar11 = piVar3 + 1;
            piVar12 = piVar3 + 4;
            piVar3 = piVar7;
            while (piVar3 != piVar10) {
              piVar12[-2] = piVar11[-1];
              piVar12[-1] = *piVar11;
              piVar3 = piVar11 + -1;
              piVar11 = piVar11 + -2;
              piVar12 = piVar12 + -2;
            }
            *piVar10 = iVar4;
            piVar10[1] = iVar9;
            piVar3 = piVar7;
          }
          else {
            iVar5 = *piVar3;
            piVar11 = piVar7;
            piVar12 = piVar7;
            if ((*(uint *)(iVar5 + 0xc) & 4) < uVar6) {
              do {
                piVar12 = piVar3;
                *piVar11 = iVar5;
                piVar11[1] = piVar12[1];
                iVar5 = piVar12[-2];
                piVar3 = piVar12 + -2;
                piVar10 = param_1;
                piVar11 = piVar12;
              } while (((byte)*(undefined4 *)(iVar5 + 0xc) & 4) <
                       ((byte)*(undefined4 *)(iVar4 + 0xc) & 4));
            }
            *piVar12 = iVar4;
            piVar12[1] = iVar9;
            piVar3 = piVar7;
          }
        }
      }
      return;
    }
    if (param_3 < 1) {
      if (0x20 < iVar4) {
        iVar4 = (int)piVar7 - (int)piVar10;
        uVar6 = iVar4 >> 3;
        iVar9 = iVar4 >> 4;
        if (0 < iVar9) {
          iVar5 = (int)(uVar6 - 1) >> 1;
          piVar7 = piVar10 + iVar9 * 2;
          do {
            iStack_10 = piVar7[-2];
            piStack_18 = piVar7 + -2;
            iVar9 = iVar9 + -1;
            iStack_14 = piVar7[-1];
            iVar1 = iVar9;
            while (iVar1 < iVar5) {
              iVar8 = (2 - (uint)(((byte)*(undefined4 *)(piVar10[iVar1 * 4 + 2] + 0xc) & 4) <
                                 ((byte)*(undefined4 *)(piVar10[iVar1 * 4 + 4] + 0xc) & 4))) +
                      iVar1 * 2;
              piVar10[iVar1 * 2] = piVar10[iVar8 * 2];
              piVar10[iVar1 * 2 + 1] = piVar10[iVar8 * 2 + 1];
              iVar1 = iVar8;
            }
            if ((iVar1 == iVar5) && ((uVar6 & 1) == 0)) {
              piVar10[iVar1 * 2] = piVar10[uVar6 * 2 + -2];
              piVar10[iVar1 * 2 + 1] = piVar10[uVar6 * 2 + -1];
              iVar1 = uVar6 - 1;
            }
            while (iVar9 < iVar1) {
              iVar8 = iVar1 + -1 >> 1;
              if (((byte)*(undefined4 *)(piVar10[iVar8 * 2] + 0xc) & 4) <=
                  ((byte)*(undefined4 *)(iStack_10 + 0xc) & 4)) break;
              piVar10[iVar1 * 2] = piVar10[iVar8 * 2];
              piVar10[iVar1 * 2 + 1] = piVar10[iVar8 * 2 + 1];
              iVar1 = iVar8;
            }
            piVar10[iVar1 * 2] = iStack_10;
            piVar10[iVar1 * 2 + 1] = iStack_14;
            piVar7 = piStack_18;
            iStack_8 = iVar9;
          } while (0 < iVar9);
        }
        uStack_c = uVar6;
        if ((int)uVar6 < 2) {
          return;
        }
        do {
          piVar7 = param_2 + -2;
          bVar2 = 1 < (int)uVar6;
          uVar6 = iVar4 + -8 >> 3;
          if (bVar2) {
            piStack_20 = (int *)*piVar7;
            piStack_1c = (int *)param_2[-1];
            *piVar7 = *piVar10;
            *(int *)(iVar4 + -4 + (int)piVar10) = piVar10[1];
            FUN_00868210(piVar10,0,uVar6,&piStack_20,param_4);
          }
          param_2 = piVar7;
          iVar4 = iVar4 + -8;
        } while (1 < (int)uVar6);
        return;
      }
      goto LAB_0086853d;
    }
    FUN_00867f70(&piStack_20,piVar10,piVar7,param_4);
    param_3 = (param_3 >> 1) + (param_3 >> 2);
    if ((int)((int)piStack_20 - (int)piVar10 & 0xfffffff8U) <
        (int)((int)piVar7 - (int)piStack_1c & 0xfffffff8U)) {
      FUN_008684b0(piVar10,piStack_20,param_3,param_4);
      param_1 = piStack_1c;
      piVar10 = piStack_1c;
    }
    else {
      FUN_008684b0(piStack_1c,piVar7,param_3,param_4);
      param_2 = piStack_20;
      piVar7 = piStack_20;
    }
    iVar4 = (int)piVar7 - (int)piVar10;
  } while( true );
}



/* FUNCTION 13246 ; VA 0x00868780 ; FUN_00868780 */

undefined4 * FUN_00868780(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  
  puVar8 = param_3;
  if (param_1 != param_2) {
    puVar6 = param_1 + 8;
    puVar7 = param_3 + 9;
    do {
      puVar1 = puVar6 + 0xb;
      *puVar8 = puVar6[-8];
      puVar2 = puVar6 + 3;
      puVar7[-8] = puVar6[-7];
      puVar8 = puVar8 + 0xb;
      puVar7[-7] = puVar6[-6];
      uVar3 = puVar6[-4];
      uVar4 = puVar6[-3];
      uVar5 = puVar6[-2];
      puVar7[-6] = puVar6[-5];
      puVar7[-5] = uVar3;
      puVar7[-4] = uVar4;
      puVar7[-3] = uVar5;
      puVar7[-2] = 0;
      *(undefined4 *)((int)param_3 + (-0x2c - (int)param_1) + (int)puVar1) = 0;
      puVar7[-2] = puVar6[-1];
      *(undefined4 *)((int)param_3 + (-0x2c - (int)param_1) + (int)puVar1) = *puVar6;
      puVar6[-1] = 0;
      *puVar6 = 0;
      *puVar7 = 0;
      puVar7[1] = 0;
      *puVar7 = puVar6[1];
      puVar7[1] = puVar6[2];
      puVar6[1] = 0;
      puVar6[2] = 0;
      puVar6 = puVar1;
      puVar7 = puVar7 + 0xb;
    } while (puVar2 != param_2);
  }
  return puVar8;
}



/* FUNCTION 13247 ; VA 0x00868830 ; FUN_00868830 */

void FUN_00868830(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  *param_2 = *param_3;
  param_2[1] = param_3[1];
  param_2[2] = param_3[2];
  uVar2 = param_3[4];
  uVar3 = param_3[5];
  uVar4 = param_3[6];
  param_2[3] = param_3[3];
  param_2[4] = uVar2;
  param_2[5] = uVar3;
  param_2[6] = uVar4;
  param_2[7] = 0;
  param_2[8] = 0;
  if (param_3[8] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[8] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[7] = param_3[7];
  param_2[8] = param_3[8];
  param_2[9] = 0;
  param_2[10] = 0;
  if (param_3[10] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[10] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[9] = param_3[9];
  param_2[10] = param_3[10];
  return;
}



/* FUNCTION 13248 ; VA 0x008688a0 ; FUN_008688a0 */

int __fastcall FUN_008688a0(int *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  
  iVar1 = *param_1;
  puVar2 = *(undefined4 **)(iVar1 + 4);
  uVar3 = FUN_00867790(iVar1,puVar2);
  if (param_1[1] != 0x71c71c6) {
    param_1[1] = param_1[1] + 1;
    *(undefined4 *)(iVar1 + 4) = uVar3;
    *puVar2 = uVar3;
    return *(int *)(*param_1 + 4) + 8;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("list<T> too long");
}



/* FUNCTION 13249 ; VA 0x008688f0 ; FUN_008688f0 */

undefined4 __thiscall
FUN_008688f0(int *param_1,undefined4 *param_2,int *param_3,undefined4 *param_4,int *param_5,
            int *param_6,int *param_7,int *param_8,int *param_9,int param_10,int param_11,
            int param_12,int param_13)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  undefined8 uVar8;
  undefined4 uVar9;
  int iVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined *puVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  uint uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b87d4;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffac;
  ExceptionList = &pvStack_10;
  piStack_18 = param_1;
  puVar13 = &stack0xffffffac;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ece388) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ece388), puVar13 = puStack_14,
     DAT_01ece388 == -1)) {
    uStack_8 = 0;
    uVar8 = FUN_0152dab0("Render","create",0xffffffff);
    DAT_01ece384 = (undefined4)((ulonglong)uVar8 >> 0x20);
    DAT_01ece380 = (undefined4)uVar8;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01ece388);
    puVar13 = puStack_14;
  }
  puStack_14 = puVar13;
  uStack_20 = DAT_01ece380;
  uStack_30 = DAT_01ece380;
  uStack_1c = DAT_01ece384;
  uStack_2c = DAT_01ece384;
  uVar8 = FUN_0152d930(DAT_01ece380,DAT_01ece384);
  uVar7 = param_10 * 0x2c;
  uVar16 = 0;
  uVar15 = 0x2c;
  puVar13 = auStack_38;
  uVar14 = 0;
  uStack_8 = 2;
  uStack_24 = uVar7;
  puVar4 = (undefined4 *)(**(code **)(**(int **)(*param_1 + 0x3c) + 0x3c))(puVar13,0,uVar7,0x2c,0);
  uVar5 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  *param_2 = uVar5;
  piVar3 = (int *)param_2[1];
  param_2[1] = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar10 = piVar3[1] + -1;
    piVar3[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar10 = piVar3[2] + -1;
      piVar3[2] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = piStack_34;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar10 = piStack_34[1] + -1;
    piStack_34[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar10 = *piVar1 + -1;
      *piVar1 = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uVar12 = 0;
  uVar11 = 2;
  iVar10 = param_12 * 2;
  uVar9 = 1;
  puVar4 = (undefined4 *)(**(code **)(**(int **)(*param_1 + 0x3c) + 0x3c))(auStack_38,1,iVar10,2,0);
  uVar5 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  *param_4 = uVar5;
  piVar3 = (int *)param_4[1];
  param_4[1] = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar6 = piVar3[1] + -1;
    piVar3[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar6 = piVar3[2] + -1;
      piVar3[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = piStack_34;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_34[1] + -1;
    piStack_34[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if ((param_11 != 0) && (param_13 != 0)) {
    uVar5 = (**(code **)(**(int **)(*piStack_18 + 0x3c) + 0x3c))
                      (auStack_38,0,param_11 * 0x18,0x18,0);
    FUN_005587e0(uVar5);
    piVar3 = piStack_34;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_34[1] + -1;
      piStack_34[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar6 = *piVar1 + -1;
        *piVar1 = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    uVar5 = (**(code **)(**(int **)(*piStack_18 + 0x3c) + 0x3c))(auStack_38,1,param_13 * 2,2,0);
    FUN_005587e0(uVar5);
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_34[1] + -1;
      piStack_34[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        piVar3 = piStack_34 + 2;
        iVar6 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          (**(code **)(*piStack_34 + 4))();
        }
      }
    }
  }
  uStack_8 = 1;
  iVar6 = (**(code **)(*(int *)*param_2 + 0x10))();
  *param_6 = iVar6;
  iVar6 = (**(code **)(*(int *)*param_4 + 0x10))();
  *param_8 = iVar6;
  if ((int *)*param_3 != (int *)0x0) {
    iVar6 = (**(code **)(*(int *)*param_3 + 0x10))();
    *param_7 = iVar6;
  }
  if ((int *)*param_5 != (int *)0x0) {
    iVar6 = (**(code **)(*(int *)*param_5 + 0x10))();
    *param_9 = iVar6;
  }
  if (*param_6 != 0) {
    if (((*param_8 != 0) && ((*param_3 == 0 || (*param_7 != 0)))) &&
       ((*param_5 == 0 || (*param_9 != 0)))) {
      uStack_8 = 6;
      FUN_0152dda0(uStack_20,uStack_1c,uVar8);
      ExceptionList = pvStack_10;
      return 1;
    }
    (**(code **)(*(int *)*param_2 + 0x14))();
  }
  if (*param_7 != 0) {
    (**(code **)(*(int *)*param_3 + 0x14))();
  }
  if (*param_8 != 0) {
    (**(code **)(*(int *)*param_4 + 0x14))();
  }
  if (*param_9 != 0) {
    (**(code **)(*(int *)*param_5 + 0x14))();
  }
  if (DAT_01f6dcc0 != '\0') {
    FUN_01677490(DAT_01f6dcc0,"Error locking part geometry buffers: %d vertices, %d indices",
                 param_10,param_12,0);
  }
  FUN_0086f2f0(3,"Failed to lock %d kB VRAM for part render data",uStack_24 >> 10);
  uStack_8 = 5;
  FUN_0152dda0(uStack_20,uStack_1c,uVar8);
  uVar5 = FUN_00868cec(uVar9,iVar10,uVar11,uVar12,puVar13,uVar14,uVar7,uVar15,uVar16);
  return uVar5;
}


