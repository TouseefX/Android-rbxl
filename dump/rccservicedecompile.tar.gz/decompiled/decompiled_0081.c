/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 20250 ; VA 0x00a2ebf0 ; FUN_00a2ebf0 */

void FUN_00a2ebf0(int *param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  int iVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  puVar2 = (undefined4 *)*param_1;
  iVar6 = FUN_005f4f20();
  if (iVar6 != 0) {
    uVar3 = puVar2[5];
    uStack_14 = puVar2[2];
    uStack_10 = puVar2[3];
    uStack_c = *puVar2;
    uVar4 = puVar2[4];
    uStack_8 = puVar2[1];
    FUN_008f7870(iVar6);
    cVar5 = FUN_008f2030();
    if ((cVar5 == '\0') && (DAT_01d84e8e != '\0')) {
      FUN_016774b0(DAT_01d84e8e,
                   "PackageService::addPackageHashData doesn\'t have a datamodel write lock!",0);
    }
    FUN_00a2bcf0(&uStack_c);
    iVar7 = FUN_00a2c170(&uStack_14);
    *(undefined4 *)(iVar7 + 8) = uVar4;
    puVar1 = puVar2 + 6;
    *(undefined4 *)(iVar7 + 0xc) = uVar3;
    if (DAT_01d6fe68 != '\0') {
      FUN_008f7870(iVar6);
      cVar5 = FUN_008f2030();
      if ((cVar5 == '\0') && (DAT_01d84e8e != '\0')) {
        FUN_016774b0(DAT_01d84e8e,
                     "PackageService::addPackageHashData doesn\'t have a datamodel write lock!",0);
      }
      puVar8 = puVar1;
      FUN_00a2b660(puVar1);
      FUN_00a2b5b0(puVar8);
    }
    FUN_00a318b0(*puVar2,puVar2[1],puVar2[2],puVar2[3],puVar2[4],puVar2[5],puVar1);
  }
  return;
}



/* FUNCTION 20251 ; VA 0x00a2ed00 ; FUN_00a2ed00 */

/* WARNING: Removing unreachable block (ram,0x00a2ed67) */
/* WARNING: Removing unreachable block (ram,0x00a2ed75) */
/* WARNING: Removing unreachable block (ram,0x00a2ed9d) */
/* WARNING: Removing unreachable block (ram,0x00a2ed85) */

void FUN_00a2ed00(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a2d690(param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20252 ; VA 0x00a2edb0 ; FUN_00a2edb0 */

void FUN_00a2edb0(int *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)*param_1;
  (*(code *)*puVar1)(puVar1[4],puVar1[5],puVar1[6],puVar1[7],puVar1[8],puVar1[9],puVar1 + 10);
  return;
}



/* FUNCTION 20253 ; VA 0x00a2ede0 ; FUN_00a2ede0 */

int FUN_00a2ede0(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017db518;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = FUN_00a315b0(param_2,param_3,*param_1,param_1[1]);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20254 ; VA 0x00a2ee70 ; FUN_00a2ee70 */

/* WARNING: Removing unreachable block (ram,0x00a2ef00) */
/* WARNING: Removing unreachable block (ram,0x00a2ef09) */
/* WARNING: Removing unreachable block (ram,0x00a2ef18) */
/* WARNING: Removing unreachable block (ram,0x00a2ef26) */
/* WARNING: Removing unreachable block (ram,0x00a2ef2f) */
/* WARNING: Removing unreachable block (ram,0x00a2ef3d) */

undefined4
FUN_00a2ee70(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bfa90;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a2c780(param_2,param_3,param_4,param_5,param_6);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 20255 ; VA 0x00a2ef60 ; FUN_00a2ef60 */

int * __fastcall FUN_00a2ef60(int *param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  undefined4 *puVar6;
  int *piVar7;
  int iStack_24;
  int *piStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dcd5a;
  pvStack_10 = ExceptionList;
  puVar1 = (undefined4 *)(&DAT_01ea8970 + ((uint)param_1 % 0x29) * 4);
  ExceptionList = &pvStack_10;
  piVar5 = (int *)FUN_00587580();
  iVar3 = *param_1;
  piVar4 = (int *)param_1[1];
  piVar7 = piVar4 + 1;
  if (piVar4 != (int *)0x0) {
    LOCK();
    *piVar7 = *piVar7 + 1;
    UNLOCK();
  }
  *puVar1 = 0;
  uStack_8 = 0;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar7;
    piVar5 = (int *)*piVar7;
    *piVar7 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*piVar4 + 4))();
      LOCK();
      piVar7 = piVar4 + 2;
      iVar2 = *piVar7;
      piVar5 = (int *)*piVar7;
      *piVar7 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piVar5 = (int *)(**(code **)(*piVar4 + 8))();
      }
    }
  }
  if (iVar3 == 0) {
    piVar7 = (int *)0x0;
    uStack_8 = 1;
    puVar6 = (undefined4 *)FUN_01674e20(0x90);
    uStack_8._0_1_ = 2;
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      FUN_0056b2c0();
      *puVar6 = boost::detail::shared_state<class_std::shared_ptr<class_RBX::HttpResponse>_>::
                vftable;
      puVar6[0x22] = 0;
    }
    uStack_8._0_1_ = 1;
    FUN_00a27f00(puVar6);
    FUN_00587580();
    piVar5 = (int *)*param_1;
    if ((piVar5 == (int *)0x0) && (param_1[1] == 0)) {
      *param_1 = iStack_24;
      piVar5 = (int *)param_1[1];
      param_1[1] = (int)piStack_20;
      *puVar1 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      piStack_20 = piVar5;
    }
    else {
      piVar7 = (int *)param_1[1];
      if (piVar7 != (int *)0x0) {
        LOCK();
        piVar7[1] = piVar7[1] + 1;
        UNLOCK();
      }
      *puVar1 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piVar4 = piStack_20 + 1;
      iVar3 = *piVar4;
      piVar5 = (int *)*piVar4;
      *piVar4 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)(*piStack_20 + 4))();
        LOCK();
        piVar4 = piStack_20 + 2;
        iVar3 = *piVar4;
        piVar5 = (int *)*piVar4;
        *piVar4 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          piVar5 = (int *)(**(code **)(*piStack_20 + 8))();
        }
      }
    }
    uStack_8 = 6;
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar4 = piVar7 + 1;
      iVar3 = *piVar4;
      piVar5 = (int *)*piVar4;
      *piVar4 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        piVar5 = (int *)(**(code **)(*piVar7 + 4))();
        LOCK();
        piVar4 = piVar7 + 2;
        iVar3 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          piVar5 = (int *)(**(code **)(*piVar7 + 8))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar5;
}



/* FUNCTION 20256 ; VA 0x00a2f110 ; FUN_00a2f110 */

int * FUN_00a2f110(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      param_2[4] = param_1[4];
      piVar3 = (int *)param_1[5];
      param_2[5] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a2f1d7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a2f14e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc9010);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_0bcfce9d17dfb0fd4129cc8f3ad64381>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 20257 ; VA 0x00a2f1f0 ; FUN_00a2f1f0 */

int * FUN_00a2f1f0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      param_2[4] = param_1[4];
      piVar3 = (int *)param_1[5];
      param_2[5] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a2f2b7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a2f22e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc8fd8);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_228401333cfa1aad5b0eb5dd4005e0aa>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 20258 ; VA 0x00a2f2d0 ; FUN_00a2f2d0 */

void FUN_00a2f2d0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1dc8f68);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_357080f8f0931a427dc389e7819a311d>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 20259 ; VA 0x00a2f330 ; FUN_00a2f330 */

void FUN_00a2f330(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a13f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x50);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00a29bc0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00a2a790();
        FUN_01674ea0(iVar2,0x50);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dc8d20);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_52c8f48b8a063b77d40a3ac3e4b57d61>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 20260 ; VA 0x00a2f480 ; FUN_00a2f480 */

void FUN_00a2f480(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dcd82;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0xa0);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00a29c60(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00a2a840();
        FUN_01674ea0(iVar2,0xa0);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dc8f30);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_60cdd878429fb1086dbee65c5ae64896>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 20261 ; VA 0x00a2f5d0 ; FUN_00a2f5d0 */

void FUN_00a2f5d0(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dcd9f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar4 = *param_1;
      ExceptionList = &pvStack_10;
      iVar3 = FUN_01674e20(0x38);
      uStack_8 = 0;
      if (iVar3 != 0) {
        iVar4 = FUN_00a29d80(iVar4);
        *param_2 = iVar4;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        uVar1 = *(uint *)(iVar4 + 0x18);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar4 + 0x20,iVar4 + 0x20,2);
            }
          }
          *(undefined4 *)(iVar4 + 0x18) = 0;
        }
        piVar2 = *(int **)(iVar4 + 4);
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = piVar2[2] + -1;
          piVar2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
        FUN_01674ea0(iVar4,0x38);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dc90f0);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_67431168d603c26387745d6647039f9a>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 20262 ; VA 0x00a2f750 ; FUN_00a2f750 */

void FUN_00a2f750(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a17f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar4 = (undefined4 *)FUN_01674e20(0x28);
      uStack_8 = 0;
      if (puVar4 == (undefined4 *)0x0) {
        *param_2 = 0;
        ExceptionList = pvStack_10;
        return;
      }
      *puVar4 = *puVar1;
      puVar4[1] = puVar1[1];
      puVar4[2] = puVar1[2];
      puVar4[3] = puVar1[3];
      FUN_0054ef60(puVar1 + 4);
      *param_2 = (int)puVar4;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar6 = *param_2;
      if (iVar6 != 0) {
        uVar2 = *(uint *)(iVar6 + 0x24);
        ExceptionList = &pvStack_10;
        if (0xf < uVar2) {
          iVar3 = *(int *)(iVar6 + 0x10);
          uVar7 = uVar2 + 1;
          iVar5 = iVar3;
          if (0xfff < uVar7) {
            iVar5 = *(int *)(iVar3 + -4);
            uVar7 = uVar2 + 0x24;
            if (0x1f < (iVar3 - iVar5) - 4U) {
              ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          ExceptionList = &pvStack_10;
          FUN_01674ea0(iVar5,uVar7);
        }
        *(undefined4 *)(iVar6 + 0x20) = 0;
        *(undefined4 *)(iVar6 + 0x24) = 0xf;
        *(undefined *)(iVar6 + 0x10) = 0;
        FUN_01674ea0(iVar6,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar6 = FUN_0170d8dd(*param_2 + 4,0x1dc8fa0);
      if (iVar6 != 0) {
        *param_2 = 0;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = *param_1;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_71a9d95b2156f5a7c60a4e1c0279f307>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 20263 ; VA 0x00a2f900 ; FUN_00a2f900 */

void FUN_00a2f900(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dcd9f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar4 = *param_1;
      ExceptionList = &pvStack_10;
      iVar3 = FUN_01674e20(0x38);
      uStack_8 = 0;
      if (iVar3 != 0) {
        iVar4 = FUN_00a29d80(iVar4);
        *param_2 = iVar4;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        uVar1 = *(uint *)(iVar4 + 0x18);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar4 + 0x20,iVar4 + 0x20,2);
            }
          }
          *(undefined4 *)(iVar4 + 0x18) = 0;
        }
        piVar2 = *(int **)(iVar4 + 4);
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = piVar2[2] + -1;
          piVar2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
        FUN_01674ea0(iVar4,0x38);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dc9128);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_848a9eafb192abbd3de38ff5511cb4bb>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 20264 ; VA 0x00a2fa80 ; FUN_00a2fa80 */

int * FUN_00a2fa80(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[3] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[3];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a2fb38. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[3];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a2fabe. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc9048);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_8eb7b9146343a51fd985e1f0bcc40f44>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 20265 ; VA 0x00a2fb50 ; FUN_00a2fb50 */

int * FUN_00a2fb50(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a2fc07. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a2fb8e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc8c78);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_8ff86f9ef747c5dc05f291003e08050e>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 20266 ; VA 0x00a2fc20 ; FUN_00a2fc20 */

void FUN_00a2fc20(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar4 = *param_1;
      iVar3 = FUN_01674e20(0x20);
      if (iVar3 != 0) {
        iVar4 = FUN_00a29e50(iVar4);
        *param_2 = iVar4;
        return;
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        piVar2 = *(int **)(iVar4 + 0x1c);
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = piVar2[1] + -1;
          piVar2[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            iVar3 = piVar2[2] + -1;
            piVar2[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        piVar2 = *(int **)(iVar4 + 4);
        if (piVar2 != (int *)0x0) {
          LOCK();
          piVar1 = piVar2 + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piVar2 + 4))();
          }
        }
        FUN_01674ea0(iVar4,0x20);
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dc8d58);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        return;
      }
      *param_2 = 0;
      return;
    }
  }
  *param_2 = (int)&<lambda_9d9b95f513383f4d4b4c3b18a18656f7>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 20267 ; VA 0x00a2fd30 ; FUN_00a2fd30 */

void FUN_00a2fd30(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c007f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x68);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00a29ec0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00a2aa70();
        FUN_01674ea0(iVar2,0x68);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dc8ce8);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_ac3bf0f9989d59c1cfcae51762ab8bb6>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 20268 ; VA 0x00a2fe80 ; FUN_00a2fe80 */

int * FUN_00a2fe80(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      param_2[4] = param_1[4];
      piVar3 = (int *)param_1[5];
      param_2[5] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a2ff47. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a2febe. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc90b8);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_cf0e84ccad39a044ad002a2e6eb78774>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 20269 ; VA 0x00a2ff60 ; FUN_00a2ff60 */

void FUN_00a2ff60(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      puVar2 = (undefined4 *)FUN_01674e20(0x40);
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        puVar2[1] = puVar1[1];
        puVar2[2] = puVar1[2];
        puVar2[3] = puVar1[3];
        puVar2[4] = puVar1[4];
        puVar2[5] = puVar1[5];
        FUN_00a2a2d0(puVar1 + 6);
        *param_2 = (int)puVar2;
        return;
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        FUN_00a2b3d0();
        FUN_01674ea0(iVar3,0x40);
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dc8d90);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        return;
      }
      *param_2 = 0;
      return;
    }
  }
  *param_2 = (int)&<lambda_d094c51620fc6e437fdf28f7da53a15b>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 20270 ; VA 0x00a30060 ; FUN_00a30060 */

int * FUN_00a30060(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[3] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 == 1) {
        piVar4 = (int *)param_1[3];
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar1 = piVar4 + 1;
          iVar2 = *piVar1;
          piVar3 = (int *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            piVar1 = piVar4 + 2;
            iVar2 = *piVar1;
            piVar3 = (int *)*piVar1;
            *piVar1 = iVar2 + -1;
            UNLOCK();
            if (iVar2 + -1 == 0) {
              piVar3 = (int *)(**(code **)(*piVar4 + 4))();
            }
          }
        }
        piVar4 = (int *)param_1[1];
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar1 = piVar4 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00a30149. Too many branches */
                    /* WARNING: Treating indirect jump as call */
            piVar3 = (int *)(**(code **)(*piVar4 + 4))();
            return piVar3;
          }
        }
      }
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)FUN_0096efe0(0);
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc8cb0);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_d4e6538b6ea99f387faf6ab8aa313e41>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 20271 ; VA 0x00a30170 ; FUN_00a30170 */

void FUN_00a30170(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dcdc7;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar2 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_01674e20(0x38);
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = 0;
        puVar3[1] = 0;
        if (puVar2[1] != 0) {
          LOCK();
          piVar1 = (int *)(puVar2[1] + 8);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        *puVar3 = *puVar2;
        puVar3[1] = puVar2[1];
        uStack_8 = 1;
        FUN_0054ef60(puVar2 + 2);
        puVar3[8] = puVar2[8];
        puVar3[9] = puVar2[9];
        puVar3[10] = puVar2[10];
        puVar3[0xb] = puVar2[0xb];
        puVar3[0xc] = puVar2[0xc];
        *param_2 = (int)puVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        ExceptionList = &pvStack_10;
        FUN_005d11a0();
        FUN_01674ea0(iVar4,0x38);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dc9080);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_d9c30083e2513d4037ac4642b6fd9bf6>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 20272 ; VA 0x00a30300 ; FUN_00a30300 */

void FUN_00a30300(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar3 = param_1[1];
      iVar1 = param_1[2];
      iVar2 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar3;
      param_2[2] = iVar1;
      param_2[3] = iVar2;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dc8ea4);
      piVar4 = (int *)0x0;
      if (iVar3 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf0<void,class_RBX::PackageService>,class_boost::_bi::list1<class_boost::_bi::value<class_RBX::PackageService*>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 20273 ; VA 0x00a30370 ; FUN_00a30370 */

void FUN_00a30370(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      puVar5 = (undefined4 *)FUN_01674e20(0x50);
      if (puVar5 != (undefined4 *)0x0) {
        *puVar5 = *puVar1;
        puVar5[1] = puVar1[1];
        uVar2 = puVar1[3];
        uVar3 = puVar1[4];
        uVar4 = puVar1[5];
        puVar5[2] = puVar1[2];
        puVar5[3] = uVar2;
        puVar5[4] = uVar3;
        puVar5[5] = uVar4;
        uVar2 = puVar1[7];
        uVar3 = puVar1[8];
        uVar4 = puVar1[9];
        puVar5[6] = puVar1[6];
        puVar5[7] = uVar2;
        puVar5[8] = uVar3;
        puVar5[9] = uVar4;
        FUN_00a2a2d0(puVar1 + 10);
        *param_2 = (int)puVar5;
        return;
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar6 = *param_2;
      if (iVar6 != 0) {
        FUN_00a2b3d0();
        FUN_01674ea0(iVar6,0x50);
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar6 = FUN_0170d8dd(*param_2 + 4,0x1dc8dcc);
      if (iVar6 == 0) {
        *param_2 = *param_1;
        return;
      }
      *param_2 = 0;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf4<void,class_RBX::PackageService,__int64,__int64,__int64,class_RBX::PackageHash_const&>,class_boost::_bi::list5<class_boost::_bi::value<class_RBX::PackageService*>,class_boost::_bi::value<__int64>,class_boost::_bi::value<__int64>,class_boost::_bi::value<__int64>,class_boost::_bi::value<class_RBX::PackageHash>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 20274 ; VA 0x00a30460 ; FUN_00a30460 */

uint __thiscall FUN_00a30460(int param_1,undefined4 param_2,undefined4 param_3)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined auStack_78 [88];
  int *piStack_20;
  char cStack_1c;
  undefined4 *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dcdf8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0086f2f0(3,"Package Asset data retrieval failed for Asset number: %lld",param_2,param_3);
  FUN_0170d1f0(auStack_78,0,0x58);
  uVar5 = FUN_00a2a210();
  uStack_8 = 0;
  FUN_00a29ac0(&puStack_18,uVar5);
  uStack_8._0_1_ = 2;
  FUN_00a2b2f0();
  *puStack_18 = 0;
  puStack_18[1] = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  FUN_00591e70(param_1 + 0xf4);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uVar6 = FUN_00a2b8e0(&param_2);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piStack_14[1] = piStack_14[1] + 1;
    UNLOCK();
  }
  *(undefined4 **)(uVar6 + 8) = puStack_18;
  piVar4 = *(int **)(uVar6 + 0xc);
  *(int **)(uVar6 + 0xc) = piStack_14;
  if (piVar4 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar4 + 1);
    uVar2 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      puVar1 = (uint *)(piVar4 + 2);
      uVar2 = *puVar1;
      uVar6 = *puVar1;
      *puVar1 = uVar2 - 1;
      UNLOCK();
      if (uVar2 - 1 == 0) {
        uVar6 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (cStack_1c != '\0') {
    *piStack_20 = *piStack_20 + -1;
    if (*piStack_20 == 0) {
      LOCK();
      piStack_20[1] = 0;
      UNLOCK();
      puVar1 = (uint *)(piStack_20 + 2);
      LOCK();
      uVar6 = *puVar1;
      *puVar1 = *puVar1 + 0x80000000;
      UNLOCK();
      if (((uVar6 & 0x40000000) == 0) && (-0x80000000 < (int)uVar6)) {
        LOCK();
        uVar2 = *puVar1;
        *puVar1 = *puVar1 | 0x40000000;
        UNLOCK();
        if ((uVar2 >> 0x1e & 1) == 0) {
          uVar5 = FUN_00554e40();
          uVar6 = SetEvent(uVar5);
        }
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_14 + 1);
    uVar2 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      uVar6 = (**(code **)*piStack_14)();
      LOCK();
      piVar4 = piStack_14 + 2;
      iVar3 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        uVar6 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 20275 ; VA 0x00a305c0 ; FUN_00a305c0 */

void __thiscall
FUN_00a305c0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  char cVar1;
  undefined auStack_24 [8];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  if (*(int *)(param_1 + 0x164) != 0) {
    uStack_c = param_5;
    uStack_10 = param_4;
    uStack_14 = 0xa305db;
    cVar1 = FUN_00fbd190();
    if (cVar1 != '\0') {
      uStack_c = 1;
      uStack_10 = param_5;
      uStack_14 = param_4;
      uStack_18 = param_3;
      uStack_1c = param_2;
      FUN_0060e0c0(auStack_24,param_1);
      FUN_00a186c0();
    }
  }
  return;
}



/* FUNCTION 20276 ; VA 0x00a30610 ; FUN_00a30610 */

void __thiscall FUN_00a30610(int param_1,int param_2,uint param_3)

{
  uint *puVar1;
  int *piVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  int *piStack_34;
  char cStack_30;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar3 = FUN_00fba6e0(param_2,param_3);
  if (cVar3 != '\0') {
    FUN_00591e70(param_1 + 0xf4);
    if (*(int *)(param_1 + 0xe4) != 0) {
      uVar7 = param_3;
      if (((int)param_3 < 1) && ((int)param_3 < 0)) {
        uVar7 = ~param_3;
      }
      uVar7 = (uVar7 >> 2) + uVar7 * 0x40 + param_2 ^ uVar7;
      uVar8 = uVar7 % *(uint *)(param_1 + 0xe0);
      piStack_14 = *(int **)(uVar8 * 4 + *(int *)(param_1 + 0xf0));
      if ((piStack_14 != (int *)0x0) &&
         (piVar2 = (int *)*piStack_14, (int *)*piStack_14 != (int *)0x0)) {
        while (piVar6 = piVar2, (uint)piVar6[1] % *(uint *)(param_1 + 0xe0) == uVar8) {
          if (((piVar6[1] == uVar7) && (param_2 == piVar6[2])) && (param_3 == piVar6[3])) {
            FUN_00a2e000(piStack_14,*piVar6);
            if (*piStack_14 != 0) {
              uVar7 = *(uint *)(*piStack_14 + 4) % *(uint *)(param_1 + 0xe0);
              if (uVar8 == uVar7) break;
              *(int **)(*(int *)(param_1 + 0xf0) + uVar7 * 4) = piStack_14;
            }
            puVar4 = (undefined4 *)(*(int *)(param_1 + 0xf0) + uVar8 * 4);
            if ((int *)*puVar4 == piStack_14) {
              *puVar4 = 0;
            }
            break;
          }
          piVar2 = (int *)*piVar6;
          piStack_14 = piVar6;
          if ((int *)*piVar6 == (int *)0x0) break;
        }
      }
    }
    uStack_8 = 0;
    if ((cStack_30 != '\0') && (*piStack_34 = *piStack_34 + -1, *piStack_34 == 0)) {
      LOCK();
      piStack_34[1] = 0;
      UNLOCK();
      puVar1 = (uint *)(piStack_34 + 2);
      LOCK();
      uVar7 = *puVar1;
      *puVar1 = *puVar1 + 0x80000000;
      UNLOCK();
      if (((uVar7 & 0x40000000) == 0) && (-0x80000000 < (int)uVar7)) {
        LOCK();
        uVar7 = *puVar1;
        *puVar1 = *puVar1 | 0x40000000;
        UNLOCK();
        if ((uVar7 >> 0x1e & 1) == 0) {
          uVar5 = FUN_00554e40();
          SetEvent(uVar5);
        }
      }
    }
    uStack_8 = 0xffffffff;
    FUN_00a311f0(param_2,param_3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20277 ; VA 0x00a307a0 ; FUN_00a307a0 */

void __thiscall FUN_00a307a0(int param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  char cVar4;
  undefined4 ***pppuVar5;
  uint *puVar6;
  undefined4 uVar7;
  undefined **ppuVar8;
  uint uVar9;
  int *piVar10;
  uint *puVar11;
  longlong lVar12;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 *in_stack_0000001c;
  uint in_stack_00000020;
  uint in_stack_00000024;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined8 in_stack_0000003c;
  uint in_stack_00000044;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined8 in_stack_0000005c;
  char cStack00000064;
  char cStack00000067;
  uint *puStack_54c;
  undefined4 uStack_548;
  undefined4 *puStack_544;
  uint uStack_540;
  undefined4 *puStack_53c;
  undefined4 uStack_538;
  undefined4 *puStack_534;
  undefined4 *puStack_530;
  undefined4 **ppuStack_52c;
  undefined4 uStack_528;
  undefined4 *puStack_524;
  undefined *puStack_520;
  char *pcStack_51c;
  char *pcStack_518;
  uint uStack_514;
  uint *puStack_510;
  uint *puStack_50c;
  uint *puStack_508;
  undefined4 **ppuStack_504;
  undefined4 **ppuStack_500;
  undefined auStack_4f4 [160];
  undefined auStack_454 [160];
  undefined auStack_3b4 [160];
  undefined auStack_314 [160];
  undefined auStack_274 [160];
  undefined auStack_1d4 [24];
  uint *puStack_1bc;
  undefined4 uStack_1b8;
  undefined4 *puStack_1b4;
  uint uStack_1b0;
  uint uStack_1ac;
  undefined4 uStack_1a4;
  undefined4 uStack_1a0;
  undefined4 uStack_19c;
  undefined4 uStack_198;
  undefined8 uStack_194;
  uint uStack_18c;
  undefined4 uStack_184;
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined4 uStack_178;
  undefined8 uStack_174;
  uint uStack_13c;
  uint *puStack_138;
  uint uStack_134;
  uint uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined8 uStack_11c;
  undefined auStack_114 [24];
  uint uStack_fc;
  uint auStack_f4 [6];
  undefined4 uStack_dc;
  undefined auStack_d8 [16];
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  int *piStack_bc;
  uint auStack_b8 [2];
  uint auStack_b0 [6];
  uint uStack_98;
  uint uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  int *piStack_74;
  uint *puStack_70;
  undefined4 uStack_6c;
  undefined4 *puStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 **ppuStack_40;
  undefined4 *puStack_3c;
  undefined4 *puStack_38;
  undefined4 *puStack_34;
  undefined8 uStack_30;
  undefined8 uStack_28;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dcf68;
  pvStack_10 = ExceptionList;
  uStack_dc = 0;
  ppuStack_500 = (undefined4 **)&param_2;
  uStack_8 = 2;
  ppuStack_504 = (undefined4 **)0xa307dc;
  ExceptionList = &pvStack_10;
  lVar12 = FUN_00a15700();
  uStack_18 = (undefined4)((ulonglong)lVar12 >> 0x20);
  puVar11 = (uint *)lVar12;
  puStack_14 = puVar11;
  if (lVar12 == 0) {
    pcStack_518 = (char *)0x19;
    ppuStack_504 = (undefined4 **)0x0;
    ppuStack_500 = (undefined4 **)0xf;
    pcStack_51c = "Package assetId not found";
    uStack_514 = (uint)uStack_514._1_3_ << 8;
    puStack_520 = (undefined *)0xa30811;
    FUN_005542c0();
    pcStack_518 = (char *)0xa30819;
    FUN_005e65e0();
  }
  else {
    ppuStack_504 = (undefined4 **)((uint)in_stack_0000001c | in_stack_00000020);
    if (ppuStack_504 == (undefined4 **)0x0) {
      pcStack_518 = (char *)0x20;
      ppuStack_500 = (undefined4 **)0xf;
      pcStack_51c = "Package version number not found";
      uStack_514 = (uint)uStack_514._1_3_ << 8;
      puStack_520 = (undefined *)0xa30843;
      FUN_005542c0();
      pcStack_518 = (char *)0xa3084b;
      FUN_005e65e0();
    }
    else {
      ppuStack_504 = (undefined4 **)0xa30856;
      ppuStack_500 = (undefined4 **)param_1;
      puStack_20 = (undefined4 *)FUN_008f7870();
      if (puStack_20 == (undefined4 *)0x0) {
        pcStack_518 = (char *)0x14;
        ppuStack_500 = (undefined4 **)0xf;
        pcStack_51c = "Data model not found";
        uStack_514 = uStack_514 & 0xffffff00;
        puStack_520 = (undefined *)0xa3087d;
        ppuStack_504 = (undefined4 **)puStack_20;
        FUN_005542c0();
        pcStack_518 = (char *)0xa30885;
        FUN_005e65e0();
      }
      else {
        if (DAT_01d6feb8 != '\0') {
          ppuStack_500 = (undefined4 **)&stack0x00000024;
          ppuStack_504 = (undefined4 **)0xa308a6;
          FUN_0054f510();
          ppuStack_500 = (undefined4 **)&stack0x00000044;
          uStack_8._0_1_ = 3;
          ppuStack_504 = (undefined4 **)0xa308b9;
          FUN_0054f510();
          piVar10 = *(int **)(param_1 + 0x168);
          if (piVar10 != (int *)0x0) {
            LOCK();
            piVar10[2] = piVar10[2] + 1;
            UNLOCK();
            piVar10 = *(int **)(param_1 + 0x168);
          }
          uStack_c0 = *(undefined4 *)(param_1 + 0x164);
          uStack_28 = CONCAT44(&uStack_78,(undefined4)uStack_28);
          if (piVar10 != (int *)0x0) {
            LOCK();
            piVar10[2] = piVar10[2] + 1;
            UNLOCK();
          }
          puStack_70 = puStack_14;
          uStack_6c = uStack_18;
          puStack_68 = in_stack_0000001c;
          uStack_64 = in_stack_00000020;
          uStack_8._0_1_ = 6;
          uStack_60 = 0;
          piStack_bc = piVar10;
          uStack_78 = uStack_c0;
          piStack_74 = piVar10;
          puStack_1c = (undefined4 *)uStack_c0;
          if (uStack_134 != 0) {
            uStack_60 = uStack_134;
            if ((uStack_134 & 1) == 0) {
              ppuStack_504 = (undefined4 **)&uStack_58;
              ppuStack_500 = (undefined4 **)0x0;
              puStack_508 = &uStack_12c;
              puStack_50c = (uint *)0xa30966;
              (**(code **)(uStack_134 & 0xfffffffe))();
            }
            else {
              uStack_58 = uStack_12c;
              uStack_54 = uStack_128;
              uStack_50 = uStack_124;
              uStack_4c = uStack_120;
              uStack_48 = uStack_11c;
            }
          }
          ppuStack_500 = (undefined4 **)0x0;
          uStack_8._0_1_ = 7;
          puStack_53c = &uStack_78;
          uStack_540 = 0xa3097d;
          FUN_00a29d80();
          puStack_53c = (undefined4 *)0xa30988;
          ppuStack_500 = (undefined4 **)FUN_00a28380();
          if ((undefined4 **)&stack0x00000024 != ppuStack_500) {
            auStack_b8[0] = 0;
            uStack_8._0_1_ = 9;
            ppuStack_504 = (undefined4 **)0xa309ab;
            FUN_005880d0();
            ppuStack_500 = (undefined4 **)&stack0x00000024;
            ppuStack_504 = (undefined4 **)0xa309b6;
            FUN_005880d0();
            ppuStack_500 = (undefined4 **)auStack_b8;
            ppuStack_504 = (undefined4 **)0xa309c5;
            FUN_005880d0();
            uStack_8._0_1_ = 10;
            if (((auStack_b8[0] != 0) && ((auStack_b8[0] & 1) == 0)) &&
               (*(code **)(auStack_b8[0] & 0xfffffffe) != (code *)0x0)) {
              puStack_508 = auStack_b0;
              ppuStack_500 = (undefined4 **)0x2;
              puStack_50c = (uint *)0xa309ec;
              ppuStack_504 = (undefined4 **)puStack_508;
              (**(code **)(auStack_b8[0] & 0xfffffffe))();
            }
          }
          uStack_8._0_1_ = 0xb;
          if (((uStack_fc != 0) && ((uStack_fc & 1) == 0)) &&
             (*(code **)(uStack_fc & 0xfffffffe) != (code *)0x0)) {
            puStack_508 = auStack_f4;
            ppuStack_500 = (undefined4 **)0x2;
            puStack_50c = (uint *)0xa30a16;
            ppuStack_504 = (undefined4 **)puStack_508;
            (**(code **)(uStack_fc & 0xfffffffe))();
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
          if (uStack_60 != 0) {
            if (((uStack_60 & 1) == 0) && (*(code **)(uStack_60 & 0xfffffffe) != (code *)0x0)) {
              puStack_508 = &uStack_58;
              ppuStack_500 = (undefined4 **)0x2;
              puStack_50c = (uint *)0xa30a3e;
              ppuStack_504 = (undefined4 **)puStack_508;
              (**(code **)(uStack_60 & 0xfffffffe))();
            }
            uStack_60 = 0;
          }
          if (piStack_74 != (int *)0x0) {
            LOCK();
            iVar2 = piStack_74[2] + -1;
            piStack_74[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              ppuStack_500 = (undefined4 **)0xa30a60;
              (**(code **)(*piStack_74 + 4))();
            }
          }
          uStack_28 = CONCAT44(&uStack_78,(undefined4)uStack_28);
          if (piVar10 != (int *)0x0) {
            LOCK();
            piVar10[2] = piVar10[2] + 1;
            UNLOCK();
          }
          uStack_78 = puStack_1c;
          puStack_70 = puStack_14;
          uStack_6c = uStack_18;
          puStack_68 = in_stack_0000001c;
          uStack_64 = in_stack_00000020;
          uStack_8._0_1_ = 0xd;
          uStack_60 = 0;
          piStack_74 = piVar10;
          if (uStack_98 != 0) {
            uStack_60 = uStack_98;
            if ((uStack_98 & 1) == 0) {
              ppuStack_504 = (undefined4 **)&uStack_58;
              ppuStack_500 = (undefined4 **)0x0;
              puStack_508 = &uStack_90;
              puStack_50c = (uint *)0xa30ae4;
              (**(code **)(uStack_98 & 0xfffffffe))();
            }
            else {
              uStack_58 = uStack_90;
              uStack_54 = uStack_8c;
              uStack_50 = uStack_88;
              uStack_4c = uStack_84;
              uStack_48 = CONCAT44(uStack_7c,uStack_80);
            }
          }
          ppuStack_500 = (undefined4 **)0x0;
          uStack_8._0_1_ = 0xe;
          puStack_53c = &uStack_78;
          uStack_540 = 0xa30afb;
          FUN_00a29d80();
          puStack_53c = (undefined4 *)0xa30b06;
          ppuStack_500 = (undefined4 **)FUN_00a280b0();
          puStack_1c = ppuStack_500;
          if ((undefined4 **)&stack0x00000044 != ppuStack_500) {
            auStack_b8[0] = 0;
            uStack_8._0_1_ = 0x10;
            ppuStack_504 = (undefined4 **)0xa30b2a;
            FUN_005880d0();
            ppuStack_500 = (undefined4 **)&stack0x00000044;
            ppuStack_504 = (undefined4 **)0xa30b36;
            FUN_005880d0();
            ppuStack_500 = (undefined4 **)auStack_b8;
            ppuStack_504 = (undefined4 **)0xa30b45;
            FUN_005880d0();
            uStack_8._0_1_ = 0x11;
            if (((auStack_b8[0] != 0) && ((auStack_b8[0] & 1) == 0)) &&
               (*(code **)(auStack_b8[0] & 0xfffffffe) != (code *)0x0)) {
              puStack_508 = auStack_b0;
              ppuStack_500 = (undefined4 **)0x2;
              puStack_50c = (uint *)0xa30b6c;
              ppuStack_504 = (undefined4 **)puStack_508;
              (**(code **)(auStack_b8[0] & 0xfffffffe))();
            }
          }
          uStack_8._0_1_ = 0x12;
          if (((uStack_fc != 0) && ((uStack_fc & 1) == 0)) &&
             (*(code **)(uStack_fc & 0xfffffffe) != (code *)0x0)) {
            puStack_508 = auStack_f4;
            ppuStack_500 = (undefined4 **)0x2;
            puStack_50c = (uint *)0xa30b96;
            ppuStack_504 = (undefined4 **)puStack_508;
            (**(code **)(uStack_fc & 0xfffffffe))();
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
          if (uStack_60 != 0) {
            if (((uStack_60 & 1) == 0) && (*(code **)(uStack_60 & 0xfffffffe) != (code *)0x0)) {
              puStack_508 = &uStack_58;
              ppuStack_500 = (undefined4 **)0x2;
              puStack_50c = (uint *)0xa30bbe;
              ppuStack_504 = (undefined4 **)puStack_508;
              (**(code **)(uStack_60 & 0xfffffffe))();
            }
            uStack_60 = 0;
          }
          if (piStack_74 != (int *)0x0) {
            LOCK();
            iVar2 = piStack_74[2] + -1;
            piStack_74[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              ppuStack_500 = (undefined4 **)0xa30bdd;
              (**(code **)(*piStack_74 + 4))();
            }
          }
          if (piVar10 != (int *)0x0) {
            LOCK();
            piVar1 = piVar10 + 2;
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
              ppuStack_500 = (undefined4 **)0xa30bf0;
              (**(code **)(*piVar10 + 4))();
            }
          }
          ppuStack_500 = (undefined4 **)0xa30bfb;
          FUN_00550990();
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          ppuStack_500 = (undefined4 **)0xa30c0a;
          FUN_00550990();
          puVar11 = puStack_14;
        }
        if (puStack_20 == (undefined4 *)0xfffffff4) {
          puStack_1c = (undefined4 *)0x0;
        }
        else {
          ppuStack_500 = (undefined4 **)0xa30c1c;
          puStack_1c = (undefined4 *)FUN_005c2760();
        }
        puVar3 = in_stack_0000001c;
        uStack_30 = 0xf00000000;
        ppuStack_40 = (undefined4 **)((uint)ppuStack_40 & 0xffffff00);
        ppuStack_500 = (undefined4 **)in_stack_00000020;
        ppuStack_504 = (undefined4 **)in_stack_0000001c;
        puStack_508 = (uint *)uStack_18;
        uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
        puStack_50c = puVar11;
        if (cStack00000064 == '\0') {
          puStack_510 = &uStack_90;
          uStack_514 = 0xa30c73;
          pppuVar5 = (undefined4 ***)FUN_00f87c60();
          _cStack00000064 = (undefined *)0x2;
        }
        else {
          puStack_510 = auStack_b0;
          uStack_514 = 0xa30c5b;
          pppuVar5 = (undefined4 ***)FUN_00f87a20();
          _cStack00000064 = (undefined *)0x1;
        }
        if (&ppuStack_40 != pppuVar5) {
          ppuStack_500 = (undefined4 **)0xa30c8e;
          FUN_005507b0();
          ppuStack_40 = *pppuVar5;
          puStack_3c = pppuVar5[1];
          puStack_38 = pppuVar5[2];
          puStack_34 = pppuVar5[3];
          uStack_30 = *(undefined8 *)(pppuVar5 + 4);
          pppuVar5[4] = (undefined4 **)0x0;
          pppuVar5[5] = (undefined4 **)0xf;
          *(undefined *)pppuVar5 = 0;
        }
        if (((uint)_cStack00000064 & 2) != 0) {
          _cStack00000064 = (char *)((uint)_cStack00000064 & 0xfffffffd);
          ppuStack_500 = (undefined4 **)0xa30cc8;
          FUN_005507b0();
        }
        uStack_8 = 0x14;
        if (((uint)_cStack00000064 & 1) != 0) {
          ppuStack_500 = (undefined4 **)0xa30ce1;
          FUN_005507b0();
        }
        ppuStack_500 = (undefined4 **)0x0;
        ppuStack_504 = (undefined4 **)&DAT_018bc9b8;
        uStack_c8 = 0;
        uStack_c4 = 0xf;
        auStack_d8[0] = 0;
        puStack_508 = (uint *)0xa30d0e;
        FUN_005542c0();
        uStack_8._0_1_ = 0x16;
        if (DAT_01d65df8 != '\0') {
          ppuStack_500 = (undefined4 **)(undefined4)uStack_30;
          ppuStack_504 = &ppuStack_40;
          if (0xf < uStack_30._4_4_) {
            ppuStack_504 = ppuStack_40;
          }
          puStack_508 = (uint *)0xa30d35;
          FUN_005542c0();
          ppuStack_500 = (undefined4 **)0x1;
          puStack_524 = (undefined4 *)0x0;
          _cStack00000064 = (char *)&puStack_54c;
          puStack_54c = puStack_14;
          uStack_548 = uStack_18;
          uStack_540 = in_stack_00000020;
          puStack_544 = puVar3;
          FUN_0054ef60(&ppuStack_40);
          FUN_00a28200();
          puStack_524 = (undefined4 *)0xa30d75;
          FUN_0090ca30();
        }
        ppuStack_500 = &ppuStack_40;
        ppuStack_504 = (undefined4 **)0xa30d84;
        FUN_0054ef60();
        ppuStack_500 = (undefined4 **)auStack_114;
        uStack_8._0_1_ = 0x17;
        ppuStack_504 = (undefined4 **)0xa30d94;
        FUN_009cbbb0();
        puVar11 = puStack_14;
        uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
        if (DAT_01ee6c18 != 0) {
          ppuStack_500 = &ppuStack_40;
          if (0xf < uStack_30._4_4_) {
            ppuStack_500 = ppuStack_40;
          }
          ppuStack_504 = (undefined4 **)puVar3;
          puStack_508 = puStack_14;
          puStack_510 = (uint *)(uint)DAT_01ee6c18;
          puStack_50c = (uint *)0x1940ee8;
          uStack_514 = 0xa30dc4;
          FUN_01677490();
        }
        uStack_28 = 0;
        if (DAT_01d65e08 == '\0') {
          puStack_14 = (uint *)0x0;
          _cStack00000064 = (char *)0x0;
        }
        else {
          ppuStack_500 = (undefined4 **)&uStack_c0;
          ppuStack_504 = (undefined4 **)0xa30de4;
          puVar6 = (uint *)FUN_016830f0();
          _cStack00000064 = (char *)*puVar6;
          puStack_14 = (uint *)puVar6[1];
        }
        if (DAT_01d65e10 != '\0') {
          ppuStack_500 = (undefined4 **)0x22;
          ppuStack_504 = (undefined4 **)0x19409c4;
          uStack_80 = 0;
          uStack_7c = 0xf;
          uStack_90 = uStack_90 & 0xffffff00;
          puStack_508 = (uint *)0xa30e30;
          FUN_005542c0();
          ppuStack_500 = (undefined4 **)0x0;
          puStack_508 = &uStack_90;
          uStack_8._0_1_ = 0x19;
          ppuStack_504 = (undefined4 **)0x1;
          puStack_50c = (uint *)0xa30e44;
          FUN_008783f0();
          uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
          ppuStack_500 = (undefined4 **)0xa30e56;
          FUN_005507b0();
        }
        if (DAT_01d65e00 == '\0') {
          ppuStack_500 = (undefined4 **)0xa30ebe;
          puStack_508 = (uint *)FUN_008ccd70();
          ppuStack_500 = (undefined4 **)0x0;
          ppuStack_504 = (undefined4 **)0x0;
          puStack_20 = &uStack_528;
          uStack_28 = CONCAT44(auStack_1d4,(undefined4)uStack_28);
          ppuStack_52c = (undefined4 **)&param_2;
          puStack_530 = (undefined4 *)0xa30ee1;
          FUN_0054ef60();
          uStack_1b8 = uStack_18;
          uStack_1b0 = in_stack_00000020;
          uStack_8._0_1_ = 0x1a;
          puStack_1bc = puVar11;
          puStack_1b4 = puVar3;
          uStack_1ac = 0;
          if (in_stack_00000024 != 0) {
            uStack_1ac = in_stack_00000024;
            if ((in_stack_00000024 & 1) == 0) {
              puStack_530 = &uStack_1a4;
              ppuStack_52c = (undefined4 **)0x0;
              puStack_534 = &stack0x0000002c;
              uStack_538 = 0xa30f4c;
              (**(code **)(in_stack_00000024 & 0xfffffffe))();
            }
            else {
              uStack_1a4 = in_stack_0000002c;
              uStack_1a0 = in_stack_00000030;
              uStack_19c = in_stack_00000034;
              uStack_198 = in_stack_00000038;
              uStack_194 = in_stack_0000003c;
            }
          }
          uStack_8._0_1_ = 0x1b;
          uStack_18c = 0;
          if (in_stack_00000044 != 0) {
            uStack_18c = in_stack_00000044;
            if ((in_stack_00000044 & 1) == 0) {
              puStack_530 = &uStack_184;
              ppuStack_52c = (undefined4 **)0x0;
              puStack_534 = &stack0x0000004c;
              uStack_538 = 0xa30f9c;
              (**(code **)(in_stack_00000044 & 0xfffffffe))();
            }
            else {
              uStack_184 = in_stack_0000004c;
              uStack_180 = in_stack_00000050;
              uStack_17c = in_stack_00000054;
              uStack_178 = in_stack_00000058;
              uStack_174 = in_stack_0000005c;
            }
          }
          ppuStack_52c = (undefined4 **)auStack_d8;
          uStack_8._0_1_ = 0x1c;
          puStack_530 = (undefined4 *)0xa30fb5;
          FUN_0054ef60();
          ppuStack_52c = &ppuStack_40;
          uStack_8._0_1_ = 0x1d;
          puStack_530 = (undefined4 *)0xa30fc8;
          FUN_0054ef60();
          uStack_13c = (uint)_cStack00000064;
          puStack_138 = puStack_14;
          ppuStack_52c = (undefined4 **)auStack_1d4;
          uStack_8._0_1_ = 0x1e;
          puStack_530 = (undefined4 *)0xa30ff0;
          FUN_00a29c60();
          puVar3 = puStack_20;
          ppuStack_52c = (undefined4 **)auStack_4f4;
          uStack_8._0_1_ = 0x1f;
          *puStack_20 = 0;
          puStack_530 = (undefined4 *)0xa3100f;
          FUN_00a29c60();
          ppuStack_52c = (undefined4 **)auStack_454;
          uStack_8._0_1_ = 0x20;
          puStack_530 = (undefined4 *)0xa31025;
          FUN_00a29c60();
          ppuStack_52c = (undefined4 **)auStack_3b4;
          uStack_8._0_1_ = 0x21;
          puStack_530 = (undefined4 *)0xa3103b;
          FUN_00a29c60();
          ppuStack_52c = (undefined4 **)auStack_274;
          uStack_8._0_1_ = 0x22;
          puStack_530 = (undefined4 *)0xa3104b;
          cVar4 = FUN_00585a40();
          if (cVar4 == '\0') {
            ppuStack_52c = (undefined4 **)auStack_274;
            puStack_530 = (undefined4 *)0xa31064;
            FUN_00a29c60();
            ppuStack_52c = (undefined4 **)0xa0;
            uStack_8._0_1_ = 0x23;
            puStack_530 = (undefined4 *)0xa31072;
            _cStack00000064 = (char *)FUN_01674e20();
            uStack_8._0_1_ = 0x24;
            if (_cStack00000064 == (char *)0x0) {
              uVar7 = 0;
            }
            else {
              ppuStack_52c = (undefined4 **)auStack_314;
              puStack_530 = (undefined4 *)0xa3108e;
              uVar7 = FUN_00a29c60();
            }
            puVar3[2] = uVar7;
            ppuStack_52c = (undefined4 **)0xa310a0;
            FUN_00a2a840();
            ppuStack_52c = (undefined4 **)0xa310ab;
            FUN_00a2a840();
            _cStack00000064 = (char *)CONCAT13(1,_cStack00000064);
          }
          else {
            ppuStack_52c = (undefined4 **)0xa310bc;
            FUN_00a2a840();
            _cStack00000064 = (char *)((uint)_cStack00000064 & 0xffffff);
          }
          ppuStack_52c = (undefined4 **)0xa310cb;
          FUN_00a2a840();
          ppuVar8 = &PTR_FUN_019412e4;
          if (cStack00000067 == '\0') {
            ppuVar8 = (undefined **)0x0;
          }
          *puVar3 = ppuVar8;
          ppuStack_52c = (undefined4 **)0xa310e5;
          FUN_00a2a840();
          ppuStack_52c = (undefined4 **)0xa310f0;
          FUN_00a2a840();
          uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
          ppuStack_52c = (undefined4 **)0xa310ff;
          FUN_00a2a840();
          puStack_530 = (undefined4 *)auStack_114;
          ppuStack_52c = (undefined4 **)0x41f00000;
          puStack_534 = (undefined4 *)0xa31116;
          FUN_008d0b40();
        }
        else {
          ppuStack_500 = (undefined4 **)0x1;
          _cStack00000064 = "[Debug] Package Request Failure";
          puStack_524 = (undefined4 *)&stack0x00000064;
          uStack_528 = 0xa30e76;
          cVar4 = FUN_00585a40();
          if (cVar4 == '\0') {
            pcStack_518 = _cStack00000064;
            puStack_520 = &DAT_019412c9;
          }
          else {
            puStack_520 = (undefined *)0x0;
          }
          puStack_524 = (undefined4 *)0xa30e9d;
          FUN_0090ca30();
          pcStack_518 = "[Debug] Package Request Failure";
          pcStack_51c = (char *)0xa30eac;
          FUN_0054eff0();
          pcStack_518 = (char *)0xa30eb4;
          FUN_005e65e0();
        }
        ppuStack_500 = (undefined4 **)0xa31121;
        FUN_005507b0();
        ppuStack_500 = (undefined4 **)0xa3112c;
        FUN_005507b0();
        ppuStack_500 = (undefined4 **)0xa31134;
        FUN_005507b0();
      }
    }
  }
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    ppuStack_500 = (undefined4 **)(in_stack_00000018 + 1);
    uVar9 = param_2;
    if (0xfff < ppuStack_500) {
      uVar9 = *(uint *)(param_2 - 4);
      ppuStack_500 = (undefined4 **)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        ppuStack_500 = (undefined4 **)&UNK_00a311e7;
        FUN_017167a3();
      }
    }
    puStack_508 = (uint *)0xa31169;
    ppuStack_504 = (undefined4 **)uVar9;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x25);
  if (in_stack_00000024 != 0) {
    if (((in_stack_00000024 & 1) == 0) &&
       (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
      puStack_508 = &stack0x0000002c;
      ppuStack_500 = (undefined4 **)0x2;
      puStack_50c = (uint *)0xa3119f;
      ppuStack_504 = (undefined4 **)puStack_508;
      (**(code **)(in_stack_00000024 & 0xfffffffe))();
    }
    in_stack_00000024 = 0;
  }
  uStack_8 = 0x26;
  if (((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) &&
     (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
    puStack_508 = &stack0x0000004c;
    ppuStack_500 = (undefined4 **)0x2;
    puStack_50c = (uint *)0xa311cd;
    ppuStack_504 = (undefined4 **)puStack_508;
    (**(code **)(in_stack_00000044 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20278 ; VA 0x00a311f0 ; FUN_00a311f0 */

void __thiscall FUN_00a311f0(int param_1,int param_2,uint *param_3)

{
  int *piVar1;
  uint uVar2;
  uint *puVar3;
  int iVar4;
  int iVar5;
  uint auStack_fc [2];
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  uint *puStack_e8;
  undefined8 uStack_e4;
  int *piStack_dc;
  int iStack_b8;
  uint uStack_a4;
  int iStack_84;
  uint uStack_70;
  int aiStack_68 [5];
  uint uStack_54;
  uint uStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int iStack_34;
  undefined8 uStack_30;
  int iStack_28;
  int iStack_24;
  uint uStack_20;
  int *piStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dcfab;
  pvStack_10 = ExceptionList;
  piStack_dc = (int *)(param_1 + 0xf4);
  uStack_e4 = CONCAT44(0xa31224,(undefined4)uStack_e4);
  ExceptionList = &pvStack_10;
  iStack_24 = param_1;
  FUN_00591e70();
  iVar5 = param_2;
  iStack_28 = param_1 + 0xdc;
  iVar4 = param_1 + 0xdd + (uint)*(byte *)(param_1 + 0xdc);
  uStack_8 = 0;
  piStack_dc = (int *)(-(uint)(iVar4 != 0) & iVar4 + 1U);
  uStack_20 = (uint)param_3;
  if (((int)param_3 < 1) && ((int)param_3 < 0)) {
    uStack_20 = -(int)param_3 - 1;
  }
  uStack_e4 = CONCAT44(&param_2,(uStack_20 >> 2) + uStack_20 * 0x40 + param_2 ^ uStack_20);
  puStack_e8 = &uStack_14;
  uStack_ec = 0xa31293;
  uStack_14 = (uint)piStack_dc;
  FUN_00606ff0();
  if (uStack_14 == 0) {
    uStack_8 = 2;
    if (((char)piStack_18 != '\0') && (*piStack_1c = *piStack_1c + -1, *piStack_1c == 0)) {
      LOCK();
      piStack_1c[1] = 0;
      UNLOCK();
      puVar3 = (uint *)(piStack_1c + 2);
      LOCK();
      uVar2 = *puVar3;
      *puVar3 = *puVar3 + 0x80000000;
      UNLOCK();
      if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
        LOCK();
        uVar2 = *puVar3;
        *puVar3 = *puVar3 | 0x40000000;
        UNLOCK();
        if ((uVar2 >> 0x1e & 1) == 0) {
          piStack_dc = (int *)0xa3135f;
          piStack_dc = (int *)FUN_00554e40();
          uStack_e4 = CONCAT44(0xa31366,(undefined4)uStack_e4);
          SetEvent();
        }
      }
    }
    piStack_dc = (int *)param_3;
    uStack_8 = 0xffffffff;
    uStack_e4 = CONCAT44(iVar5,aiStack_68);
    puStack_e8 = (uint *)0xa3137a;
    FUN_00fbeda0();
    piStack_dc = (int *)0x0;
    uStack_8 = 3;
    uStack_e4 = ZEXT48(aiStack_68);
    puStack_e8 = (uint *)0xa31397;
    FUN_014cc090();
    piStack_dc = (int *)iStack_24;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    uStack_e4 = CONCAT44(&piStack_1c,0xa313a8);
    FUN_0060e0c0();
    if (piStack_18 != (int *)0x0) {
      piVar1 = piStack_18 + 2;
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_48 = 0;
    puStack_e8 = (uint *)param_2;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    uStack_e4 = CONCAT44(piStack_1c,param_3);
    piStack_dc = piStack_18;
    uStack_ec = 0xa313f9;
    FUN_00a290e0();
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_18[2] + -1;
      piStack_18[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        piStack_dc = (int *)0xa3140f;
        (**(code **)(*piStack_18 + 4))();
      }
      LOCK();
      iVar5 = piStack_18[2] + -1;
      piStack_18[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        piStack_dc = (int *)0xa31421;
        (**(code **)(*piStack_18 + 4))();
      }
    }
    piStack_dc = (int *)0x0;
    param_3 = auStack_fc;
    uStack_8._0_1_ = 6;
    auStack_fc[0] = 0;
    puVar3 = auStack_fc;
    if (uStack_48 != 0) {
      auStack_fc[0] = uStack_48;
      if ((uStack_48 & 1) == 0) {
        (**(code **)(uStack_48 & 0xfffffffe))(&uStack_40,&uStack_f4,0);
        puVar3 = param_3;
      }
      else {
        uStack_f4 = uStack_40;
        uStack_f0 = uStack_3c;
        uStack_ec = uStack_38;
        puStack_e8 = (uint *)iStack_34;
        uStack_e4 = uStack_30;
        puVar3 = auStack_fc;
      }
    }
    param_3 = puVar3;
    FUN_014ccc70();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    if (uStack_48 != 0) {
      if (((uStack_48 & 1) == 0) && (*(code **)(uStack_48 & 0xfffffffe) != (code *)0x0)) {
        piStack_dc = (int *)0x2;
        uStack_e4 = CONCAT44(&uStack_40,&uStack_40);
        puStack_e8 = (uint *)0xa31497;
        (**(code **)(uStack_48 & 0xfffffffe))();
      }
      uStack_48 = 0;
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        piStack_dc = (int *)0xa314b4;
        (**(code **)(*piStack_18 + 4))();
      }
    }
    if (0xf < uStack_70) {
      piStack_dc = (int *)(uStack_70 + 1);
      iVar5 = iStack_84;
      if (0xfff < piStack_dc) {
        iVar5 = *(int *)(iStack_84 + -4);
        piStack_dc = (int *)(uStack_70 + 0x24);
        if (0x1f < (iStack_84 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          piStack_dc = (int *)0xa3159d;
          FUN_017167a3();
        }
      }
      uStack_e4 = CONCAT44(iVar5,0xa314e5);
      FUN_01674ea0();
    }
    piStack_dc = (int *)0xa31505;
    FUN_0056cfd0();
    if (0xf < uStack_a4) {
      piStack_dc = (int *)(uStack_a4 + 1);
      iVar5 = iStack_b8;
      if (0xfff < piStack_dc) {
        iVar5 = *(int *)(iStack_b8 + -4);
        piStack_dc = (int *)(uStack_a4 + 0x24);
        if (0x1f < (iStack_b8 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          piStack_dc = (int *)0xa315a2;
          FUN_017167a3();
        }
      }
      uStack_e4 = CONCAT44(iVar5,0xa31538);
      FUN_01674ea0();
    }
    if (0xf < uStack_54) {
      piStack_dc = (int *)(uStack_54 + 1);
      iVar5 = aiStack_68[0];
      if (0xfff < piStack_dc) {
        iVar5 = *(int *)(aiStack_68[0] + -4);
        piStack_dc = (int *)(uStack_54 + 0x24);
        if (0x1f < (aiStack_68[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          piStack_dc = (int *)&UNK_00a315a7;
          FUN_017167a3();
        }
      }
      uStack_e4 = CONCAT44(iVar5,0xa31583);
      FUN_01674ea0();
    }
  }
  else {
    piStack_dc = (int *)0x1;
    uStack_e4 = CONCAT44(param_3,iVar5);
    puStack_e8 = (uint *)0xa312ae;
    FUN_00fba320();
    uStack_8 = 1;
    if (((char)piStack_18 != '\0') && (*piStack_1c = *piStack_1c + -1, *piStack_1c == 0)) {
      LOCK();
      piStack_1c[1] = 0;
      UNLOCK();
      puVar3 = (uint *)(piStack_1c + 2);
      LOCK();
      uVar2 = *puVar3;
      *puVar3 = *puVar3 + 0x80000000;
      UNLOCK();
      if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
        LOCK();
        uVar2 = *puVar3;
        *puVar3 = *puVar3 | 0x40000000;
        UNLOCK();
        if ((uVar2 >> 0x1e & 1) == 0) {
          piStack_dc = (int *)0xa31304;
          piStack_dc = (int *)FUN_00554e40();
          uStack_e4 = CONCAT44(0xa3130b,(undefined4)uStack_e4);
          SetEvent();
          ExceptionList = pvStack_10;
          return;
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20279 ; VA 0x00a315b0 ; FUN_00a315b0 */

void __thiscall
FUN_00a315b0(int param_1,int param_2,int *param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int *piVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int *piVar7;
  int **ppiVar8;
  undefined auStack_a4 [88];
  undefined auStack_4c [16];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined auStack_34 [12];
  undefined auStack_28 [8];
  undefined auStack_20 [8];
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar1 = param_5;
  uVar5 = param_4;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dcff6;
  pvStack_10 = ExceptionList;
  if (param_2 == 0) {
    ExceptionList = &pvStack_10;
    if ((param_3 != (int *)0x0) && (ExceptionList = &pvStack_10, DAT_01d84e8e != '\0')) {
      ExceptionList = &pvStack_10;
      uVar4 = (**(code **)(*param_3 + 4))();
      FUN_01677520(DAT_01d84e8e,
                   "PackageService::requestPackageAssetDataCallback Error Package[%lld]: %s",uVar5,
                   uVar1,uVar4);
    }
    if (DAT_01d6fec8 == '\0') {
      uStack_3c = 0;
      uStack_38 = 0xf;
      auStack_4c[0] = 0;
      FUN_005542c0("PackageErrorCode-CatchAll",0x19);
      uStack_8 = 0;
      FUN_008783f0(auStack_4c,1,0);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
    }
    FUN_00fba320(uVar5,uVar1,0);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  FUN_016819e0(auStack_34,param_2);
  uStack_8 = 1;
  cVar3 = FUN_016816d0();
  if (cVar3 == '\0') {
    cVar3 = FUN_01681870();
    if (cVar3 != '\0') {
      piStack_18 = (int *)0x0;
      uStack_14 = 0;
      uStack_8._0_1_ = 2;
      if (DAT_01d65e18 == '\0') {
        FUN_0170d1f0(auStack_a4,0,0x58);
        uVar5 = FUN_00a2a210();
        uStack_8._0_1_ = 4;
        uVar5 = FUN_00a29ac0(auStack_20,uVar5);
        FUN_005587e0(uVar5);
        FUN_00550b30();
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00a2b2f0();
        FUN_0167eda0(auStack_28,&DAT_01d65e60);
        cVar3 = FUN_01681870();
        if (cVar3 != '\0') {
          FUN_0167eda0(auStack_20,&DAT_01d65e30);
          iVar6 = FUN_0167e2d0(0);
          piVar2 = piStack_18;
          *piStack_18 = iVar6;
          piStack_18[1] = iVar6 >> 0x1f;
          FUN_0167eda0(auStack_20,&DAT_01d65e48);
          uVar5 = FUN_00563600(auStack_4c);
          piVar7 = piVar2 + 0x10;
          FUN_005511f0(uVar5);
          FUN_005507b0();
          if (*piVar2 != 0 || piVar2[1] != 0) {
            if (0xf < (uint)piVar2[0x15]) {
              piVar7 = (int *)*piVar7;
            }
            cVar3 = FUN_0055c360(piVar7,piVar2[0x14],&DAT_018bc9b8,0);
            if (cVar3 == '\0') goto LAB_00a31826;
          }
        }
        uVar5 = 0;
LAB_00a31866:
        FUN_00fba320(param_4,param_5,uVar5);
      }
      else {
        uVar5 = FUN_00a29fd0(auStack_34);
        uStack_8._0_1_ = 3;
        uVar5 = FUN_00a29ac0(auStack_28,uVar5);
        FUN_005587e0(uVar5);
        FUN_00550b30();
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00a2b2f0();
        if ((-1 < piStack_18[1]) && ((0 < piStack_18[1] || (*piStack_18 != 0)))) {
          if (piStack_18[0x14] == 0) {
            FUN_00550b30();
            goto LAB_00a3188e;
          }
LAB_00a31826:
          FUN_00591e70(param_1 + 0xf4);
          ppiVar8 = &piStack_18;
          uStack_8._0_1_ = 5;
          FUN_00a2b8e0(&param_4);
          FUN_0056ecd0(ppiVar8);
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          FUN_005923a0();
          uVar5 = 1;
          goto LAB_00a31866;
        }
      }
      FUN_00550b30();
      goto LAB_00a3188e;
    }
  }
  FUN_00fba320(param_4,param_5,0);
LAB_00a3188e:
  FUN_0167ec40();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20280 ; VA 0x00a318b0 ; FUN_00a318b0 */

undefined4 * __thiscall
FUN_00a318b0(int param_1,int param_2,uint param_3,int param_4,uint param_5,undefined4 param_6,
            undefined4 param_7)

{
  undefined4 *puVar1;
  int *piVar2;
  int *piVar3;
  char cVar4;
  undefined4 *puVar5;
  uint uVar6;
  int iVar7;
  undefined4 *puVar8;
  int *piVar9;
  longlong lVar10;
  undefined auStack_4c [40];
  int iStack_24;
  int *piStack_20;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_008f7870(param_1);
  cVar4 = FUN_008f2030();
  if ((cVar4 == '\0') && (DAT_01d84e8e != '\0')) {
    FUN_016774b0(DAT_01d84e8e,
                 "PackageService::runModifiedCheck doesn\'t have a datamodel write lock!",0);
  }
  iVar7 = param_1 + 0x135 + (uint)*(byte *)(param_1 + 0x134);
  if (((int)param_3 < 1) && ((int)param_3 < 0)) {
    iStack_24 = -1 - param_2;
    uVar6 = -param_3 - 1;
  }
  else {
    iStack_24 = param_2;
    uVar6 = param_3;
  }
  FUN_00606ff0(&puStack_14,(uVar6 >> 2) + uVar6 * 0x40 + param_2 ^ uVar6,&param_2,
               -(uint)(iVar7 != 0) & iVar7 + 1U);
  puVar5 = puStack_14;
  if (puStack_14 != (undefined4 *)0x0) {
    iVar7 = (int)puStack_14 + *(byte *)(puStack_14 + 4) + 0x11;
    if (((int)param_5 < 1) && ((int)param_5 < 0)) {
      iStack_24 = -1 - param_4;
      uVar6 = -param_5 - 1;
    }
    else {
      iStack_24 = param_4;
      uVar6 = param_5;
    }
    FUN_00606ff0(&puStack_14,(uVar6 >> 2) + uVar6 * 0x40 + param_4 ^ uVar6,&param_4,
                 -(uint)(iVar7 != 0) & iVar7 + 1U);
    puVar5 = puStack_14;
    if (puStack_14 != (undefined4 *)0x0) {
      iVar7 = puStack_14[6];
      puVar1 = puStack_14 + 4;
      if (iVar7 == 0) {
        piVar9 = (int *)0x0;
      }
      else {
        piVar9 = (int *)((undefined4 *)puStack_14[9])[puStack_14[5]];
        puVar5 = (undefined4 *)puStack_14[9];
      }
      puStack_14 = puVar1;
      if (piVar9 != (int *)0x0) {
        do {
          puVar5 = (undefined4 *)FUN_0060dcd0(&iStack_24,*(undefined4 *)(piVar9[2] + 0x34));
          iStack_8 = 0;
          if (iStack_24 != 0) {
            if (DAT_01d6fe68 == '\0') {
              lVar10 = FUN_00a16270(&iStack_24,0);
              if (lVar10 == CONCAT44(param_7,param_6)) {
                uVar6 = 0;
              }
              else {
                uVar6 = 1;
              }
            }
            else {
              FUN_00fbd8d0(&param_2,&param_4,&iStack_24);
              iStack_8._0_1_ = 1;
              cVar4 = FUN_00fbe730(auStack_4c);
              iStack_8 = (uint)iStack_8._1_3_ << 8;
              FUN_00a2b3d0();
              uVar6 = (uint)(cVar4 == '\0');
            }
            puVar5 = (undefined4 *)FUN_00eb3e50(uVar6 * 2 + -1);
            if (DAT_01d65e28 != '\0') {
              if (piVar9[3] != 0) {
                LOCK();
                piVar2 = (int *)(piVar9[3] + 4);
                *piVar2 = *piVar2 + 1;
                UNLOCK();
              }
              puVar5 = (undefined4 *)FUN_00a325f0(piVar9[2],piVar9[3],0,0);
            }
          }
          piVar2 = piStack_20;
          iStack_8 = 0xffffffff;
          if (piStack_20 != (int *)0x0) {
            LOCK();
            piVar3 = piStack_20 + 1;
            iVar7 = *piVar3;
            puVar5 = (undefined4 *)*piVar3;
            *piVar3 = iVar7 + -1;
            UNLOCK();
            if (iVar7 + -1 == 0) {
              (**(code **)*piStack_20)();
              LOCK();
              piVar3 = piVar2 + 2;
              iVar7 = *piVar3;
              puVar5 = (undefined4 *)*piVar3;
              *piVar3 = iVar7 + -1;
              UNLOCK();
              if (iVar7 + -1 == 0) {
                puVar5 = (undefined4 *)(**(code **)(*piVar2 + 4))();
              }
            }
          }
          piVar9 = (int *)*piVar9;
        } while (piVar9 != (int *)0x0);
        iVar7 = puStack_14[2];
      }
      puVar1 = puStack_14;
      if (iVar7 != 0) {
        FUN_008b20f0(puStack_14[5] + puStack_14[1] * 4,0);
        puVar8 = (undefined4 *)puVar1[5];
        puVar5 = puVar8 + puVar1[1];
        for (; puVar8 != puVar5; puVar8 = puVar8 + 1) {
          *puVar8 = 0;
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar5;
}



/* FUNCTION 20281 ; VA 0x00a31b60 ; FUN_00a31b60 */

int __thiscall FUN_00a31b60(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined8 uVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  undefined8 uVar7;
  undefined auStack_44 [32];
  undefined4 uStack_24;
  int *piStack_20;
  uint uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  uVar3 = CONCAT44(uStack_1c,ExceptionList);
  uVar7 = CONCAT44(uStack_1c,ExceptionList);
  puStack_c = &LAB_017dd040;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  uStack_18 = CONCAT44(uStack_18._4_4_,(undefined4)uStack_18);
  if ((param_2 != 0) &&
     (ExceptionList = &pvStack_10, uStack_18 = CONCAT44(uStack_18._4_4_,(undefined4)uStack_18),
     uVar7 = uVar3, *(int *)(param_2 + 0x34) != 0)) {
    ExceptionList = &pvStack_10;
    uVar4 = FUN_00eb3da0(auStack_44);
    uStack_8 = 1;
    uStack_18 = FUN_00a15700(uVar4);
    iVar6 = (int)uStack_18;
    uStack_8 = 0;
    FUN_005507b0();
    uVar7 = FUN_00eb3de0();
    uStack_1c = (uint)((ulonglong)uVar7 >> 0x20);
    if ((iVar6 != 0 || uStack_18._4_4_ != 0) &&
       (uVar5 = (uint)uVar7 | uStack_1c, uVar7 = CONCAT44(uStack_1c,uVar5), uVar5 != 0)) {
      uVar4 = FUN_00a2e250(iVar6,uStack_18._4_4_);
      uVar7 = CONCAT44(uStack_1c,uVar4);
      if ((char)uVar4 == '\0') {
        FUN_00591e70(param_1 + 0xf4);
        uStack_8 = 2;
        FUN_0060e0c0(&uStack_24,param_1);
        _uStack_8 = CONCAT31(uStack_7,3);
        if (piStack_20 != (int *)0x0) {
          piVar1 = piStack_20 + 2;
          LOCK();
          *piVar1 = *piVar1 + 1;
          UNLOCK();
          LOCK();
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        uVar4 = 0;
        if (piStack_20 != (int *)0x0) {
          LOCK();
          piStack_20[2] = piStack_20[2] + 1;
          UNLOCK();
        }
        FUN_00a29200(uStack_24,piStack_20,uStack_18);
        if (piStack_20 != (int *)0x0) {
          LOCK();
          iVar6 = piStack_20[2] + -1;
          piStack_20[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piStack_20 + 4))(uVar4);
          }
          LOCK();
          iVar6 = piStack_20[2] + -1;
          piStack_20[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piStack_20 + 4))();
          }
        }
        if (piStack_20 != (int *)0x0) {
          LOCK();
          piStack_20[2] = piStack_20[2] + 1;
          UNLOCK();
        }
        if (param_3 != (int *)0x0) {
          LOCK();
          param_3[1] = param_3[1] + 1;
          UNLOCK();
        }
        FUN_00a28610(uStack_24,piStack_20,param_2,param_3,0);
        uVar4 = (undefined4)uStack_18;
        FUN_00fba4d0(uStack_18);
        FUN_0056c200();
        uStack_8 = 0;
        FUN_005923a0();
        uVar4 = FUN_00a30610(uVar4,uStack_18._4_4_);
        uVar7 = CONCAT44(uStack_1c,uVar4);
      }
    }
  }
  uStack_1c = (uint)((ulonglong)uVar7 >> 0x20);
  iVar6 = (int)uVar7;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 20282 ; VA 0x00a31d50 ; FUN_00a31d50 */

/* WARNING: Type propagation algorithm not settling */

uint FUN_00a31d50(uint param_1,int *param_2)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int *piVar4;
  longlong lVar5;
  longlong lVar6;
  char cVar7;
  uint uVar8;
  int iVar9;
  undefined4 *puVar10;
  undefined4 uVar11;
  undefined4 *puVar12;
  undefined **ppuVar13;
  int iVar14;
  byte abStack_2c8 [16];
  undefined4 uStack_2b8;
  undefined *puStack_2b4;
  undefined8 uStack_2b0;
  uint *puStack_2a8;
  undefined auStack_29c [40];
  code *pcStack_274;
  undefined4 uStack_270;
  int iStack_26c;
  undefined4 uStack_268;
  undefined8 uStack_264;
  undefined8 uStack_25c;
  int iStack_254;
  int iStack_250;
  undefined auStack_24c [40];
  code *pcStack_224;
  undefined4 uStack_220;
  int iStack_21c;
  undefined4 uStack_218;
  undefined8 uStack_214;
  undefined8 uStack_20c;
  int iStack_204;
  int iStack_200;
  undefined auStack_1fc [40];
  code *pcStack_1d4;
  undefined4 uStack_1d0;
  int iStack_1cc;
  undefined4 uStack_1c8;
  undefined8 uStack_1c4;
  undefined8 uStack_1bc;
  int iStack_1b4;
  int iStack_1b0;
  undefined auStack_1ac [40];
  undefined auStack_184 [24];
  code *pcStack_16c;
  undefined4 uStack_168;
  int iStack_164;
  undefined4 uStack_160;
  undefined8 uStack_15c;
  undefined8 uStack_154;
  int iStack_14c;
  int iStack_148;
  undefined auStack_144 [40];
  code *pcStack_11c;
  undefined4 uStack_118;
  int iStack_114;
  undefined4 uStack_110;
  undefined8 uStack_10c;
  undefined8 uStack_104;
  int iStack_fc;
  int iStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined8 uStack_e4;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined8 uStack_d4;
  undefined auStack_cc [16];
  byte abStack_bc [8];
  undefined auStack_b4 [8];
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  code *pcStack_a4;
  undefined4 uStack_a0;
  int iStack_9c;
  undefined4 uStack_98;
  undefined8 uStack_94;
  undefined8 uStack_8c;
  int iStack_84;
  int iStack_80;
  undefined auStack_7c [40];
  undefined8 uStack_54;
  int iStack_4c;
  undefined8 uStack_48;
  undefined8 uStack_40;
  undefined8 uStack_38;
  uint uStack_30;
  undefined8 uStack_2c;
  int iStack_24;
  char cStack_1d;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017dd0c3;
  pvStack_10 = ExceptionList;
  uStack_38 = (ulonglong)(uint)uStack_38;
  uStack_8 = 0;
  uStack_7 = 0;
  uStack_2b0._4_4_ = (char *)0xa31d89;
  ExceptionList = &pvStack_10;
  FUN_008f7870();
  puStack_2a8 = (uint *)0xa31d93;
  uVar8 = FUN_008f2030();
  if (((char)uVar8 == '\0') && (uVar8 = (uint)DAT_01ee6c18, DAT_01ee6c18 != 0)) {
    puStack_2a8 = (uint *)0x0;
    uStack_2b0._0_4_ = (byte *)(uint)DAT_01ee6c18;
    uStack_2b0._4_4_ = "PackageService::scheduleModifiedCheck doesn\'t have a datamodel write lock!"
    ;
    puStack_2b4 = (undefined *)0xa31db0;
    uVar8 = FUN_016774b0();
  }
  if (param_1 == 0) goto LAB_00a325ad;
  puStack_2a8 = (uint *)auStack_184;
  uStack_2b0._4_4_ = (char *)0xa31dcd;
  FUN_00eb3da0();
  puStack_2a8 = (uint *)auStack_184;
  uStack_8 = 1;
  uStack_2b0._4_4_ = (char *)0xa31ddd;
  uStack_48 = FUN_00a15700();
  lVar5 = uStack_48;
  lVar6 = CONCAT44(uStack_40._4_4_,(undefined4 *)uStack_40);
  if (uStack_48 != 0) {
    puStack_2a8 = (uint *)0xa31df6;
    uStack_40 = FUN_00eb3de0();
    lVar5 = uStack_48;
    lVar6 = uStack_40;
    if (uStack_40 != 0) {
      puStack_2a8 = (uint *)0x0;
      uStack_2b0._4_4_ = (char *)0xa31e0e;
      FUN_00eb3e50();
      puStack_2a8 = (uint *)&uStack_48;
      uStack_2b0._4_4_ = (char *)0xa31e1d;
      FUN_00a2bab0();
      puStack_2a8 = (uint *)&uStack_40;
      uStack_2b0._4_4_ = (char *)0xa31e29;
      iVar9 = FUN_00a2bf30();
      puStack_14 = *(undefined4 **)(iVar9 + 0x10);
      puStack_2a8 = (uint *)&uStack_48;
      uStack_2b0._4_4_ = (char *)0xa31e3e;
      FUN_00a2bab0();
      puStack_2a8 = (uint *)&uStack_40;
      uStack_2b0._4_4_ = (char *)0xa31e4a;
      iVar9 = FUN_00a2bf30();
      uStack_2b0._4_4_ = (char *)((param_1 >> 3) + param_1);
      puStack_2a8 = &param_1;
      uStack_2b0._0_4_ = (byte *)&uStack_1c;
      puStack_2b4 = (undefined *)0xa31e69;
      uStack_1c._4_4_ = (uint *)uStack_2b0._4_4_;
      FUN_00a2e070();
      lVar6 = uStack_40;
      lVar5 = uStack_48;
      if ((uint)uStack_1c == 0) {
        uStack_2c = uStack_2c & 0xffff000000000000;
        uStack_30 = -(uint)(iVar9 != -0xb) & iVar9 + 0xcU;
        uStack_8 = 2;
        puStack_2a8 = (uint *)0xa31e9b;
        FUN_008b0490();
        *(undefined4 *)((int)(uint *)uStack_2c + 8) = 0;
        *(undefined4 *)((int)(uint *)uStack_2c + 0xc) = 0;
        if (param_2 != (int *)0x0) {
          LOCK();
          param_2[1] = param_2[1] + 1;
          UNLOCK();
        }
        *(uint *)((int)(uint *)uStack_2c + 8) = param_1;
        *(int **)((int)(uint *)uStack_2c + 0xc) = param_2;
        puStack_2a8 = (uint *)(*(int *)(iVar9 + 0x10) + 1);
        uStack_2c._0_6_ = CONCAT15(1,(undefined5)uStack_2c);
        uStack_2b0._4_4_ = (char *)0xa31ed3;
        FUN_0062b610();
        puStack_2a8 = uStack_1c._4_4_;
        uStack_2b0._4_4_ = (char *)&uStack_30;
        uStack_2b0._0_4_ = (byte *)((int)&uStack_38 + 4);
        puStack_2b4 = (undefined *)0xa31ee5;
        FUN_005c5550();
        uStack_8 = 1;
        lVar6 = uStack_40;
        lVar5 = uStack_48;
        if ((uint *)uStack_2c != (uint *)0x0) {
          if ((uStack_2c._5_1_ != '\0') &&
             (piVar4 = (int *)((uint *)uStack_2c)[3], piVar4 != (int *)0x0)) {
            LOCK();
            iVar9 = piVar4[1] + -1;
            piVar4[1] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              puStack_2a8 = (uint *)0xa31f0c;
              (**(code **)*piVar4)();
              LOCK();
              iVar9 = piVar4[2] + -1;
              piVar4[2] = iVar9;
              UNLOCK();
              if (iVar9 == 0) {
                puStack_2a8 = (uint *)0xa31f1c;
                (**(code **)(*piVar4 + 4))();
              }
            }
          }
          puStack_2a8 = (uint *)0x10;
          uStack_2b0._0_4_ = (undefined *)0xa31f27;
          uStack_2b0._4_4_ = (char *)(uint *)uStack_2c;
          FUN_01674ea0();
          lVar6 = uStack_40;
          lVar5 = uStack_48;
        }
      }
      iVar9 = iStack_4c;
      uStack_48._4_4_ = (byte *)((ulonglong)lVar5 >> 0x20);
      uStack_48._0_4_ = (int)lVar5;
      uStack_40._4_4_ = (uint)((ulonglong)lVar6 >> 0x20);
      uStack_40._0_4_ = (undefined4 *)lVar6;
      if (puStack_14 == (undefined4 *)0x0) {
        puStack_14 = (undefined4 *)uStack_40;
        uStack_1c._0_4_ = uStack_40._4_4_;
        iStack_24 = (int)uStack_48;
        puStack_2a8 = (uint *)iStack_4c;
        uStack_1c._4_4_ = (uint *)uStack_48._4_4_;
        uStack_2b0._4_4_ = (char *)0xa31f61;
        uStack_38 = lVar5;
        uStack_48 = lVar5;
        uStack_40 = lVar6;
        uStack_54 = lVar6;
        FUN_008f7870();
        puStack_2a8 = (uint *)0xa31f6b;
        cVar7 = FUN_008f2030();
        if ((cVar7 == '\0') && (DAT_01d84e8e != 0)) {
          puStack_2a8 = (uint *)0x0;
          uStack_2b0._0_4_ = (byte *)(uint)DAT_01d84e8e;
          uStack_2b0._4_4_ =
               "PackageService::getPackageHashData doesn\'t have a datamodel write lock!";
          puStack_2b4 = (undefined *)0xa31f88;
          FUN_016774b0();
        }
        iVar14 = iVar9 + 0x105 + (uint)*(byte *)(iVar9 + 0x104);
        puStack_2a8 = (uint *)(-(uint)(iVar14 != 0) & iVar14 + 1U);
        iVar14 = iStack_24;
        if (((int)uStack_1c._4_4_ < 1) && ((int)uStack_1c._4_4_ < 0)) {
          uStack_1c._4_4_ = (uint *)(-1 - (int)uStack_1c._4_4_);
          iVar14 = -1 - iStack_24;
        }
        uStack_2c = CONCAT44(uStack_2c._4_4_,iVar14);
        uStack_2b0._4_4_ = (char *)&uStack_38;
        uStack_2b0._0_4_ =
             (byte *)(((uint)uStack_1c._4_4_ >> 2) + (int)uStack_1c._4_4_ * 0x40 + iStack_24 ^
                     (uint)uStack_1c._4_4_);
        puStack_2b4 = (undefined *)((int)&uStack_1c + 4);
        uStack_2b8 = 0xa31fee;
        FUN_00606ff0();
        if (uStack_1c._4_4_ != (uint *)0x0) {
          puStack_2a8 = (uint *)(-(uint)((byte *)((int)uStack_1c._4_4_ +
                                                 *(byte *)((int)uStack_1c._4_4_ + 0x10) + 0x11) !=
                                        (byte *)0x0) &
                                (uint)((byte *)((int)uStack_1c._4_4_ +
                                               *(byte *)((int)uStack_1c._4_4_ + 0x10) + 0x11) + 1));
          puVar10 = puStack_14;
          if (((int)(uint)uStack_1c < 1) && ((int)(uint)uStack_1c < 0)) {
            uStack_1c._0_4_ = -(uint)uStack_1c - 1;
            puVar10 = (undefined4 *)(-1 - (int)puStack_14);
          }
          uStack_2c = CONCAT44(uStack_2c._4_4_,puVar10);
          uStack_2b0._4_4_ = (char *)&uStack_54;
          uStack_2b0._0_4_ =
               (byte *)((int)puStack_14 + ((uint)uStack_1c >> 2) + (uint)uStack_1c * 0x40 ^
                       (uint)uStack_1c);
          puStack_2b4 = (undefined *)&uStack_1c;
          uStack_2b8 = 0xa32055;
          uStack_1c._4_4_ = (uint *)((int)uStack_1c._4_4_ + 0x10);
          FUN_00606ff0();
          if ((uint)uStack_1c != 0) {
            iStack_24 = *(int *)((uint)uStack_1c + 0x10);
            uStack_54._4_4_ = *(int *)((uint)uStack_1c + 0x14);
            if (iStack_24 != 0 || uStack_54._4_4_ != 0) {
              puStack_2a8 = (uint *)0xa32081;
              FUN_00a2a340();
              uStack_8 = 3;
              if (DAT_01d6fe68 != '\0') {
                puStack_2a8 = (uint *)&uStack_40;
                uStack_2b0._4_4_ = (char *)&uStack_48;
                uStack_2b0._0_4_ = (byte *)0xa320a5;
                FUN_00fbd320();
                puStack_2a8 = (uint *)iVar9;
                uStack_2b0._4_4_ = (char *)0xa320ab;
                FUN_008f7870();
                puStack_2a8 = (uint *)0xa320b5;
                cVar7 = FUN_008f2030();
                if ((cVar7 == '\0') && (DAT_01d84e8e != 0)) {
                  puStack_2a8 = (uint *)0x0;
                  uStack_2b0._0_4_ = (byte *)(uint)DAT_01d84e8e;
                  uStack_2b0._4_4_ =
                       "PackageService::getPackageHash doesn\'t have a datamodel write lock!";
                  puStack_2b4 = (undefined *)0xa320d2;
                  FUN_016774b0();
                }
                iVar9 = iVar9 + 0x11d + (uint)*(byte *)(iVar9 + 0x11c);
                puStack_2a8 = (uint *)auStack_b4;
                uStack_2b0._4_4_ = (char *)0xa320f3;
                uStack_2b0._0_4_ = (byte *)FUN_00fbd350();
                uStack_2b0._4_4_ = auStack_b4;
                puStack_2a8 = (uint *)(-(uint)(iVar9 != 0) & iVar9 + 1U);
                puStack_2b4 = (undefined *)&uStack_1c;
                uStack_2b8 = 0xa32113;
                FUN_00a29a20();
                if ((uint)uStack_1c == 0) {
                  puStack_2a8 = (uint *)&uStack_2c;
                  uStack_2b0._4_4_ = (char *)&uStack_38;
                  uStack_d4 = 0;
                  uStack_38 = 0;
                  uStack_f4 = 0;
                  uStack_f0 = 0;
                  uStack_ec = 0;
                  uStack_e8 = 0;
                  uStack_e4 = 0;
                  uStack_dc = 0;
                  uStack_d8 = 0;
                  uStack_2c = 0;
                  uStack_2b0._0_4_ = (byte *)0xa32150;
                  FUN_00fbd320();
                  puStack_2a8 = &uStack_f4;
                  uStack_e4 = 0;
                  puStack_14 = (undefined4 *)&DAT_00000005;
                  uStack_dc = 0;
                  uStack_d8 = 0;
                  uStack_d4 = 0;
                }
                else {
                  puStack_2a8 = (uint *)((uint)uStack_1c + 0x18);
                  uStack_2b0._4_4_ = (char *)0xa3217b;
                  puStack_2a8 = (uint *)FUN_00a2a2d0();
                  puStack_14 = (undefined4 *)&DAT_00000006;
                }
                uStack_2b0._4_4_ = (char *)0xa32191;
                FUN_00a2a2d0();
                if (((uint)puStack_14 & 2) != 0) {
                  puStack_14 = (undefined4 *)((uint)puStack_14 & 0xfffffffd);
                  puStack_2a8 = (uint *)0xa321a6;
                  FUN_00a2b3d0();
                }
                if (((uint)puStack_14 & 1) != 0) {
                  puStack_2a8 = (uint *)0xa321b8;
                  FUN_00a2b3d0();
                }
                puStack_2a8 = (uint *)auStack_144;
                uStack_2b0._4_4_ = (char *)0xa321ca;
                FUN_00a2b5b0();
                puStack_2a8 = (uint *)0xa321d5;
                FUN_00a2b3d0();
              }
              uStack_2b0._4_4_ = (char *)0xa321de;
              uVar11 = FUN_008f7870();
              lVar5 = uStack_48;
              uStack_38 = CONCAT44(uVar11,(uint)uStack_38);
              puStack_2a8 = (uint *)0x1;
              puStack_14 = (undefined4 *)abStack_2c8;
              uStack_1c = uStack_40;
              FUN_00a2a2d0(auStack_29c);
              FUN_00a2a2d0(auStack_cc);
              FUN_00a2a2d0(&uStack_f4);
              iStack_9c = iStack_4c;
              iStack_84 = iStack_24;
              iStack_80 = uStack_54._4_4_;
              uStack_94 = lVar5;
              uStack_8c = uStack_1c;
              FUN_00a2a2d0(auStack_144);
              FUN_00a2b3d0();
              FUN_00a2b3d0();
              pcStack_274 = FUN_00a318b0;
              iStack_26c = iStack_9c;
              uStack_268 = uStack_98;
              uStack_270 = 0;
              iStack_254 = iStack_84;
              iStack_250 = iStack_80;
              uStack_264 = uStack_94;
              uStack_25c = uStack_8c;
              FUN_00a2a2d0(auStack_7c);
              FUN_00a2b3d0();
              FUN_00a2b3d0();
              pcStack_224 = pcStack_274;
              iStack_21c = iStack_26c;
              uStack_218 = uStack_268;
              uStack_220 = uStack_270;
              iStack_204 = iStack_254;
              iStack_200 = iStack_250;
              uStack_214 = uStack_264;
              uStack_20c = uStack_25c;
              FUN_00a2a2d0(auStack_24c);
              puVar10 = puStack_14;
              uStack_1c4 = uStack_214;
              uStack_1c8 = uStack_218;
              iStack_1cc = iStack_21c;
              uStack_1d0 = uStack_220;
              pcStack_1d4 = pcStack_224;
              *puStack_14 = 0;
              iStack_1b4 = iStack_204;
              iStack_1b0 = iStack_200;
              uStack_1bc = uStack_20c;
              FUN_00a2a2d0(auStack_1fc);
              pcStack_11c = pcStack_1d4;
              iStack_114 = iStack_1cc;
              uStack_110 = uStack_1c8;
              uStack_118 = uStack_1d0;
              iStack_fc = iStack_1b4;
              iStack_f8 = iStack_1b0;
              uStack_10c = uStack_1c4;
              uStack_104 = uStack_1bc;
              FUN_00a2a2d0(auStack_1ac);
              pcStack_a4 = pcStack_11c;
              iStack_9c = iStack_114;
              uStack_98 = uStack_110;
              uStack_a0 = uStack_118;
              iStack_84 = iStack_fc;
              iStack_80 = iStack_f8;
              uStack_94 = uStack_10c;
              uStack_8c = uStack_104;
              FUN_00a2a2d0(&uStack_f4);
              cVar7 = FUN_00585a40(&pcStack_a4);
              if (cVar7 == '\0') {
                pcStack_16c = pcStack_a4;
                iStack_164 = iStack_9c;
                uStack_160 = uStack_98;
                uStack_168 = uStack_a0;
                iStack_14c = iStack_84;
                iStack_148 = iStack_80;
                uStack_15c = uStack_94;
                uStack_154 = uStack_8c;
                FUN_00a2a2d0(auStack_7c);
                uStack_8 = 9;
                puVar12 = (undefined4 *)FUN_01674e20(0x50);
                if (puVar12 == (undefined4 *)0x0) {
                  puVar12 = (undefined4 *)0x0;
                }
                else {
                  *puVar12 = pcStack_16c;
                  puVar12[1] = uStack_168;
                  puVar12[2] = iStack_164;
                  puVar12[3] = uStack_160;
                  *(longlong *)(puVar12 + 4) = uStack_15c;
                  *(longlong *)(puVar12 + 6) = uStack_154;
                  puVar12[8] = iStack_14c;
                  puVar12[9] = iStack_148;
                  FUN_00a2a2d0(auStack_144);
                }
                puVar10[2] = puVar12;
                FUN_00a2b3d0();
                FUN_00a2b3d0();
                cStack_1d = '\x01';
              }
              else {
                FUN_00a2b3d0();
                cStack_1d = '\0';
              }
              FUN_00a2b3d0();
              ppuVar13 = &PTR_FUN_019412f4;
              if (cStack_1d == '\0') {
                ppuVar13 = (undefined **)0x0;
              }
              *puVar10 = ppuVar13;
              FUN_00a2b3d0();
              FUN_00a2b3d0();
              uStack_8 = 3;
              FUN_00a2b3d0();
              FUN_0090ca30();
              puStack_2a8 = (uint *)0xa3251e;
              FUN_00a2b3d0();
              lVar5 = uStack_48;
              lVar6 = uStack_40;
              goto LAB_00a325a2;
            }
          }
        }
        puStack_2a8 = (uint *)DAT_01d65dd4;
        uStack_38 = CONCAT44(abStack_2c8,(uint)uStack_38);
        uStack_2b0 = uStack_40;
        FUN_0054ef60(auStack_184);
        FUN_00a331a0();
        lVar5 = uStack_48;
        lVar6 = uStack_40;
        if (DAT_01d65e20 == '\0') {
          puStack_2a8 = (uint *)0x1a;
          uStack_2b0._4_4_ = "PackageRequestWebCopyStart";
          uStack_ac = 0;
          uStack_a8 = 0xf;
          abStack_bc[0] = 0;
          uStack_2b0._0_4_ = (byte *)0xa32580;
          FUN_005542c0();
          puStack_2a8 = (uint *)0x0;
          uStack_2b0._0_4_ = abStack_bc;
          uStack_8 = 10;
          uStack_2b0._4_4_ = (char *)0x1;
          puStack_2b4 = (undefined *)0xa32594;
          FUN_008783f0();
          puStack_2a8 = (uint *)0xa325a2;
          FUN_005507b0();
          lVar5 = uStack_48;
          lVar6 = uStack_40;
        }
      }
    }
  }
LAB_00a325a2:
  puStack_2a8 = (uint *)0xa325ad;
  uStack_48 = lVar5;
  uStack_40 = lVar6;
  uVar8 = FUN_005507b0();
LAB_00a325ad:
  piVar4 = param_2;
  if (param_2 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_2 + 1);
    uVar3 = *puVar1;
    uVar8 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      puStack_2a8 = (uint *)0xa325c3;
      uVar8 = (**(code **)*param_2)();
      LOCK();
      piVar2 = piVar4 + 2;
      iVar9 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        puStack_2a8 = (uint *)0xa325d2;
        uVar8 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 20283 ; VA 0x00a325f0 ; FUN_00a325f0 */

void * __thiscall FUN_00a325f0(uint *param_1,uint param_2,int *param_3,void *param_4,uint *param_5)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  char cVar7;
  void *pvVar8;
  uint *puVar9;
  undefined8 uVar10;
  undefined4 auStack_60 [5];
  undefined4 uStack_4c;
  void **ppvStack_48;
  uint *puStack_44;
  uint **ppuStack_40;
  uint *apuStack_34 [2];
  code *pcStack_2c;
  uint uStack_28;
  uint *puStack_24;
  undefined4 uStack_20;
  uint *puStack_1c;
  char cStack_18;
  void *pvStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar2 = (uint)param_5;
  puStack_c = &LAB_017dd101;
  pvStack_10 = ExceptionList;
  pvStack_14 = (void *)0x0;
  uStack_8 = 0;
  pvVar8 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((param_2 != 0) &&
     (pvVar8 = (void *)((uint)param_4 | (uint)param_5), ExceptionList = &pvStack_10,
     pvVar8 != (void *)0x0)) {
    ppuStack_40 = apuStack_34;
    puStack_44 = (uint *)0xa32637;
    ExceptionList = &pvStack_10;
    ppuStack_40 = (uint **)FUN_00eb3da0();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    pvStack_14 = (void *)0x1;
    puStack_44 = (uint *)0xa32648;
    uVar10 = FUN_00a15700();
    pvVar8 = (void *)uVar10;
    if ((pvVar8 != param_4) || ((uint)((ulonglong)uVar10 >> 0x20) != uVar2)) {
      param_5 = (uint *)CONCAT13(1,param_5._0_3_);
      goto LAB_00a3265e;
    }
  }
  param_5 = (uint *)((uint)param_5 & 0xffffff);
LAB_00a3265e:
  uStack_8 = 0;
  if ((((uint)pvStack_14 & 1) != 0) && (0xf < uStack_20)) {
    ppuStack_40 = (uint **)(uStack_20 + 1);
    puVar9 = apuStack_34[0];
    if (0xfff < ppuStack_40) {
      puVar9 = (uint *)apuStack_34[0][-1];
      ppuStack_40 = (uint **)(uStack_20 + 0x24);
      if (0x1f < (uint)((int)apuStack_34[0] + (-4 - (int)puVar9))) {
                    /* WARNING: Subroutine does not return */
        ppuStack_40 = (uint **)&UNK_00a3288b;
        FUN_017167a3();
      }
    }
    ppvStack_48 = (void **)0xa3269c;
    puStack_44 = puVar9;
    pvVar8 = (void *)FUN_01674ea0();
  }
  if (param_5._3_1_ == '\0') {
    puStack_44 = (uint *)0xa326b2;
    ppuStack_40 = (uint **)param_1;
    pvVar8 = (void *)FUN_008f7870();
    pvStack_14 = pvVar8;
    if (pvVar8 != (void *)0x0) {
      puStack_1c = param_1 + 0x2f;
      cStack_18 = '\0';
      ppuStack_40 = (uint **)0xa326d5;
      FUN_00587410();
      uStack_8._0_1_ = 2;
      if (param_1[0x33] == 0) {
        ppuStack_40 = (uint **)0x1;
        param_5 = auStack_60;
        pcStack_2c = FUN_00a2dc90;
        uStack_28 = 0;
        puStack_24 = param_1;
        cVar7 = FUN_00585a40(&pcStack_2c);
        uVar6 = uStack_20;
        puVar9 = puStack_24;
        uVar2 = uStack_28;
        puVar5 = param_5;
        if (cVar7 == '\0') {
          param_5[2] = (uint)pcStack_2c;
          puVar5[3] = uVar2;
          puVar5[4] = puVar9;
          puVar5[5] = uVar6;
          *puVar5 = &DAT_019412ed;
        }
        else {
          *param_5 = 0;
        }
        FUN_0090ca30();
      }
      param_5 = param_1 + 0x31;
      ppuStack_40 = (uint **)&param_2;
      puVar9 = (uint *)((param_2 >> 3) + param_2);
      ppvStack_48 = &pvStack_14;
      uStack_4c = 0xa32758;
      puStack_44 = puVar9;
      pvVar8 = (void *)FUN_00a2e070();
      if (pvStack_14 == (void *)0x0) {
        puStack_24 = (uint *)0x0;
        uStack_20 = uStack_20 & 0xffff0000;
        uStack_28 = -(uint)(param_5 != (uint *)0xfffffffd) & (uint)(param_5 + 1);
        uStack_8._0_1_ = 3;
        ppuStack_40 = (uint **)0xa3278d;
        FUN_008b0490();
        puStack_24[2] = 0;
        puStack_24[3] = 0;
        if (param_3 != (int *)0x0) {
          LOCK();
          param_3[1] = param_3[1] + 1;
          UNLOCK();
        }
        puStack_24[2] = param_2;
        puStack_24[3] = (uint)param_3;
        uStack_20._0_2_ = CONCAT11(1,(undefined)uStack_20);
        ppuStack_40 = (uint **)(param_5[2] + 1);
        puStack_44 = (uint *)0xa327c6;
        FUN_0062b610();
        puStack_44 = &uStack_28;
        ppvStack_48 = &pvStack_14;
        uStack_4c = 0xa327d7;
        ppuStack_40 = (uint **)puVar9;
        pvVar8 = (void *)FUN_005c5550();
        if (puStack_24 != (uint *)0x0) {
          if ((uStack_20._1_1_ != '\0') && (piVar3 = (int *)puStack_24[3], piVar3 != (int *)0x0)) {
            LOCK();
            iVar4 = piVar3[1] + -1;
            piVar3[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              ppuStack_40 = (uint **)0xa327fa;
              (**(code **)*piVar3)();
              LOCK();
              iVar4 = piVar3[2] + -1;
              piVar3[2] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                ppuStack_40 = (uint **)0xa3280a;
                (**(code **)(*piVar3 + 4))();
              }
            }
          }
          ppuStack_40 = (uint **)0x10;
          ppvStack_48 = (void **)0xa32815;
          puStack_44 = puStack_24;
          pvVar8 = (void *)FUN_01674ea0();
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      if (cStack_18 != '\0') {
        LOCK();
        pvVar8 = (void *)*puStack_1c;
        *puStack_1c = *puStack_1c + 0x80000000;
        UNLOCK();
        if ((((uint)pvVar8 & 0x40000000) == 0) && (-0x80000000 < (int)pvVar8)) {
          LOCK();
          uVar2 = *puStack_1c;
          *puStack_1c = *puStack_1c | 0x40000000;
          UNLOCK();
          if ((uVar2 >> 0x1e & 1) == 0) {
            ppuStack_40 = (uint **)0xa32848;
            ppuStack_40 = (uint **)FUN_00554e40();
            puStack_44 = (uint *)0xa3284f;
            pvVar8 = (void *)SetEvent();
          }
        }
      }
    }
  }
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar9 = (uint *)(param_3 + 1);
    uVar2 = *puVar9;
    pvVar8 = (void *)*puVar9;
    *puVar9 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      ppuStack_40 = (uint **)0xa32865;
      pvVar8 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        ppuStack_40 = (uint **)0xa32874;
        pvVar8 = (void *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar8;
}



/* FUNCTION 20284 ; VA 0x00a32890 ; FUN_00a32890 */

/* WARNING: Type propagation algorithm not settling */

void FUN_00a32890(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined8 param_6)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined uVar4;
  char cVar5;
  undefined4 uVar6;
  undefined **ppuVar7;
  undefined4 *puVar8;
  int iVar9;
  undefined **ppuVar10;
  undefined4 *******pppppppuVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  undefined8 uVar15;
  char *pcVar16;
  undefined **appuStack_128 [2];
  undefined8 uStack_120;
  undefined **appuStack_118 [3];
  uint auStack_10c [2];
  uint *puStack_104;
  uint *puStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined4 *puStack_f4;
  undefined4 *puStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 *puStack_e4;
  undefined4 *puStack_e0;
  int iStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_c4;
  undefined **ppuStack_c0;
  uint auStack_78 [4];
  undefined4 uStack_68;
  uint uStack_64;
  undefined auStack_60 [4];
  undefined *puStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  int iStack_44;
  uint uStack_40;
  int iStack_3c;
  undefined4 uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  undefined4 *******pppppppuStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar9 = param_1;
  puStack_c = &LAB_017dd1b5;
  pvStack_10 = ExceptionList;
  if (param_1 != 0) {
    appuStack_128[0] = &PTR_018bf148;
    appuStack_118[0] = (undefined **)&DAT_018bf150;
    uStack_8 = 0;
    uStack_30 = CONCAT44(1,(int *)uStack_30);
    ppuStack_c0 = std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
    uStack_c4 = 0x50;
    uStack_120 = 0;
    ExceptionList = &pvStack_10;
    FUN_00554f20(appuStack_118 + 2,0);
    *(undefined ***)((int)appuStack_118 + (int)appuStack_118[0][1]) =
         std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
    *(undefined **)((int)appuStack_118 + (int)(appuStack_118[0][1] + -4)) = appuStack_118[0][1] + -8
    ;
    *(undefined ***)((int)appuStack_128 + (int)appuStack_128[0][1]) =
         std::basic_iostream<char,struct_std::char_traits<char>_>::vftable;
    *(undefined **)(&stack0xfffffed4 + (int)appuStack_128[0][1]) = appuStack_128[0][1] + -0x20;
    uStack_8 = 5;
    *(undefined ***)((int)appuStack_128 + (int)appuStack_128[0][1]) =
         std::basic_stringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)(&stack0xfffffed4 + (int)appuStack_128[0][1]) = appuStack_128[0][1] + -0x68;
    appuStack_118[2] = std::basic_streambuf<char,struct_std::char_traits<char>_>::vftable;
    iStack_dc = FUN_01674e20();
    if (iStack_dc == 0) {
      iStack_dc = 0;
    }
    else {
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      uVar6 = FUN_016de181();
      *(undefined4 *)(iStack_dc + 4) = uVar6;
    }
    puStack_104 = auStack_10c;
    puStack_100 = auStack_10c + 1;
    puStack_f4 = &uStack_fc;
    puStack_f0 = &uStack_f8;
    puStack_e4 = &uStack_ec;
    puStack_e0 = &uStack_e8;
    auStack_10c[1] = 0;
    uStack_f8 = 0;
    uStack_e8 = 0;
    auStack_10c[0] = 0;
    uStack_fc = 0;
    uStack_ec = 0;
    appuStack_118[2] =
         std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    uStack_d8 = 0;
    uStack_d4 = 4;
    uStack_8 = 7;
    FUN_00a24aa0(appuStack_118,iVar9,0,0);
    FUN_0056b230();
    uStack_8._0_1_ = 8;
    if ((*(byte *)((int)auStack_10c + (int)appuStack_118[0][1]) & 6) == 0) {
      (**(code **)(**(int **)((int)&puStack_e0 + (int)appuStack_118[0][1]) + 0x28))
                (&uStack_48,0,0,2,2);
      if ((uStack_48 + uStack_40 & iStack_44 + iStack_3c + (uint)CARRY4(uStack_48,uStack_40)) ==
          0xffffffff) {
        FUN_00554460((uint)(*(int *)((int)&puStack_e0 + (int)appuStack_118[0][1]) == 0) * 4 + 2 |
                     *(uint *)((int)auStack_10c + (int)appuStack_118[0][1]),0);
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    cVar5 = thunk_FUN_0170e3b7();
    if (cVar5 == '\0') {
      FUN_00577770();
    }
    uStack_8._0_1_ = 10;
    piVar1 = *(int **)(*(int *)(*(int *)uStack_30 + 4) + 0x38 + (int)(int *)uStack_30);
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 8))();
    }
    auStack_60[0] = 0;
    param_1 = 0xb;
    ppuVar7 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_1);
    ppuVar10 = ppuVar7 + -1;
    if (ppuVar7 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar10 = ppuVar7;
    }
    puStack_5c = *ppuVar10;
    uStack_58 = 0;
    uStack_54 = 0x3f800000;
    uStack_50 = 0;
    uStack_4c = 0;
    uStack_8._0_1_ = 0xb;
    puVar8 = (undefined4 *)FUN_0058c590(&uStack_48,param_2,param_3);
    uStack_8._0_1_ = 0xc;
    uStack_18 = 0;
    uStack_14 = 0xf;
    pppppppuStack_28 = (undefined4 *******)((uint)pppppppuStack_28 & 0xffffff00);
    FUN_005542c0("package_asset_id",0x10);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
    iVar9 = FUN_005d15d0();
    if ((undefined4 *)(iVar9 + 0x18) != puVar8) {
      FUN_005507b0();
      uVar6 = puVar8[1];
      uVar2 = puVar8[2];
      uVar3 = puVar8[3];
      *(undefined4 *)(iVar9 + 0x18) = *puVar8;
      *(undefined4 *)(iVar9 + 0x1c) = uVar6;
      *(undefined4 *)(iVar9 + 0x20) = uVar2;
      *(undefined4 *)(iVar9 + 0x24) = uVar3;
      *(undefined8 *)(iVar9 + 0x28) = *(undefined8 *)(puVar8 + 4);
      puVar8[4] = 0;
      puVar8[5] = 0xf;
      *(undefined *)puVar8 = 0;
    }
    uStack_8._0_1_ = 0xc;
    if (0xf < uStack_14) {
      uVar12 = uStack_14 + 1;
      pppppppuVar11 = pppppppuStack_28;
      if (0xfff < uVar12) {
        pppppppuVar11 = (undefined4 *******)pppppppuStack_28[-1];
        uVar12 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)pppppppuStack_28 + (-4 - (int)pppppppuVar11))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppppuVar11,uVar12);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    pppppppuStack_28 = (undefined4 *******)((uint)pppppppuStack_28 & 0xffffff00);
    uStack_8._0_1_ = 0xb;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xb;
    if (0xf < uStack_34) {
      uVar13 = uStack_34 + 1;
      uVar12 = uStack_48;
      if (0xfff < uVar13) {
        uVar12 = *(uint *)(uStack_48 - 4);
        uVar13 = uStack_34 + 0x24;
        if (0x1f < (uStack_48 - uVar12) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar12,uVar13);
    }
    puVar8 = (undefined4 *)FUN_0058c590(&uStack_48,param_4,param_5);
    uStack_8._0_1_ = 0xe;
    uStack_18 = 0;
    uStack_14 = 0xf;
    pppppppuStack_28 = (undefined4 *******)((uint)pppppppuStack_28 & 0xffffff00);
    FUN_005542c0("package_version_num",0x13);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
    iVar9 = FUN_005d15d0();
    if ((undefined4 *)(iVar9 + 0x18) != puVar8) {
      FUN_005507b0();
      uVar6 = puVar8[1];
      uVar2 = puVar8[2];
      uVar3 = puVar8[3];
      *(undefined4 *)(iVar9 + 0x18) = *puVar8;
      *(undefined4 *)(iVar9 + 0x1c) = uVar6;
      *(undefined4 *)(iVar9 + 0x20) = uVar2;
      *(undefined4 *)(iVar9 + 0x24) = uVar3;
      *(undefined8 *)(iVar9 + 0x28) = *(undefined8 *)(puVar8 + 4);
      puVar8[4] = 0;
      puVar8[5] = 0xf;
      *(undefined *)puVar8 = 0;
    }
    uStack_8._0_1_ = 0xe;
    if (0xf < uStack_14) {
      uVar12 = uStack_14 + 1;
      pppppppuVar11 = pppppppuStack_28;
      if (0xfff < uVar12) {
        pppppppuVar11 = (undefined4 *******)pppppppuStack_28[-1];
        uVar12 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)pppppppuStack_28 + (-4 - (int)pppppppuVar11))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppppuVar11,uVar12);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    pppppppuStack_28 = (undefined4 *******)((uint)pppppppuStack_28 & 0xffffff00);
    uStack_8._0_1_ = 0xb;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xb;
    if (0xf < uStack_34) {
      uVar13 = uStack_34 + 1;
      uVar12 = uStack_48;
      if (0xfff < uVar13) {
        uVar12 = *(uint *)(uStack_48 - 4);
        uVar13 = uStack_34 + 0x24;
        if (0x1f < (uStack_48 - uVar12) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar12,uVar13);
    }
    FUN_0056b230();
    uStack_8._0_1_ = 0x10;
    if ((*(byte *)((int)auStack_10c + (int)appuStack_118[0][1]) & 6) == 0) {
      (**(code **)(**(int **)((int)&puStack_e0 + (int)appuStack_118[0][1]) + 0x28))
                (&uStack_48,0,0,1,2);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
      cVar5 = thunk_FUN_0170e3b7();
      if (cVar5 == '\0') {
        FUN_00577770();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
    }
    else {
      uStack_48 = 0xffffffff;
      iStack_44 = -1;
      uStack_40 = 0;
      iStack_3c = 0;
      uStack_38 = 0;
      uStack_34 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
      cVar5 = thunk_FUN_0170e3b7();
      if (cVar5 == '\0') {
        FUN_00577770();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
    }
    piVar1 = *(int **)(*(int *)(*(int *)uStack_30 + 4) + 0x38 + (int)(int *)uStack_30);
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 8))();
    }
    uStack_8._0_1_ = 0xb;
    puVar8 = (undefined4 *)
             FUN_0058c590(auStack_78,uStack_40 + uStack_48,
                          iStack_3c + iStack_44 + (uint)CARRY4(uStack_40,uStack_48));
    uStack_8._0_1_ = 0x15;
    uStack_18 = 0;
    uStack_14 = 0xf;
    pppppppuStack_28 = (undefined4 *******)((uint)pppppppuStack_28 & 0xffffff00);
    FUN_005542c0("package_size_byte",0x11);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
    iVar9 = FUN_005d15d0();
    if ((undefined4 *)(iVar9 + 0x18) != puVar8) {
      FUN_005507b0();
      uVar6 = puVar8[1];
      uVar2 = puVar8[2];
      uVar3 = puVar8[3];
      *(undefined4 *)(iVar9 + 0x18) = *puVar8;
      *(undefined4 *)(iVar9 + 0x1c) = uVar6;
      *(undefined4 *)(iVar9 + 0x20) = uVar2;
      *(undefined4 *)(iVar9 + 0x24) = uVar3;
      *(undefined8 *)(iVar9 + 0x28) = *(undefined8 *)(puVar8 + 4);
      puVar8[4] = 0;
      puVar8[5] = 0xf;
      *(undefined *)puVar8 = 0;
    }
    uStack_8._0_1_ = 0x15;
    if (0xf < uStack_14) {
      uVar12 = uStack_14 + 1;
      pppppppuVar11 = pppppppuStack_28;
      if (0xfff < uVar12) {
        pppppppuVar11 = (undefined4 *******)pppppppuStack_28[-1];
        uVar12 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)pppppppuStack_28 + (-4 - (int)pppppppuVar11))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppppuVar11,uVar12);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    pppppppuStack_28 = (undefined4 *******)((uint)pppppppuStack_28 & 0xffffff00);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    if (0xf < uStack_64) {
      uVar13 = uStack_64 + 1;
      uVar12 = auStack_78[0];
      if (0xfff < uVar13) {
        uVar12 = *(uint *)(auStack_78[0] - 4);
        uVar13 = uStack_64 + 0x24;
        if (0x1f < (auStack_78[0] - uVar12) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar12,uVar13);
    }
    uVar15 = FUN_01530150();
    iVar9 = FUN_0055c3d0((int)&uStack_14 + 1,uVar15);
    uStack_38 = 0;
    uStack_48 = uStack_48 & 0xffffff00;
    uStack_34 = 0xf;
    if (iVar9 != (int)&uStack_14 + 1) {
      FUN_005542c0(iVar9,((int)&uStack_14 + 1) - iVar9);
    }
    uVar12 = uStack_34;
    uStack_8._0_1_ = 0x17;
    uStack_68 = 0;
    uStack_64 = 0xf;
    auStack_78[0] = auStack_78[0] & 0xffffff00;
    FUN_005542c0("available_ram_mb",0x10);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
    iVar9 = FUN_005d15d0();
    if ((uint *)(iVar9 + 0x18) != &uStack_48) {
      FUN_005507b0();
      uVar13 = uStack_48;
      uVar12 = 0xf;
      uStack_48 = uStack_48 & 0xffffff00;
      *(uint *)(iVar9 + 0x18) = uVar13;
      *(int *)(iVar9 + 0x1c) = iStack_44;
      *(uint *)(iVar9 + 0x20) = uStack_40;
      *(int *)(iVar9 + 0x24) = iStack_3c;
      *(ulonglong *)(iVar9 + 0x28) = CONCAT44(uStack_34,uStack_38);
    }
    uStack_8._0_1_ = 0x17;
    if (0xf < uStack_64) {
      uVar14 = uStack_64 + 1;
      uVar13 = auStack_78[0];
      if (0xfff < uVar14) {
        uVar13 = *(uint *)(auStack_78[0] - 4);
        uVar14 = uStack_64 + 0x24;
        if (0x1f < (auStack_78[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar13,uVar14);
    }
    uStack_68 = 0;
    uStack_64 = 0xf;
    auStack_78[0] = auStack_78[0] & 0xffffff00;
    uStack_8._0_1_ = 0xb;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xb;
    if (0xf < uVar12) {
      uVar14 = uVar12 + 1;
      uVar13 = uStack_48;
      if (0xfff < uVar14) {
        uVar13 = *(uint *)(uStack_48 - 4);
        uVar14 = uVar12 + 0x24;
        if (0x1f < (uStack_48 - uVar13) - 4) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar13,uVar14);
    }
    if (DAT_01d65e08 == '\0') {
      FUN_0060e7f0(auStack_60);
      pcVar16 = "Package_Size";
    }
    else {
      uStack_30 = param_6;
      iVar9 = FUN_0066db30(&DAT_018c5880,param_6);
      FUN_00565660(iVar9,0);
      pppppppuVar11 = &pppppppuStack_28;
      if (0xf < uStack_14) {
        pppppppuVar11 = pppppppuStack_28;
      }
      FUN_0058ccc0(pppppppuVar11,iVar9 + 1,&DAT_018c5880,uStack_30);
      uStack_8._0_1_ = 0x19;
      uStack_38 = 0;
      uStack_34 = 0xf;
      uStack_48 = uStack_48 & 0xffffff00;
      FUN_005542c0("package_download_time",0x15);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x1a);
      iVar9 = FUN_005d15d0();
      if ((undefined4 ********)(iVar9 + 0x18) != &pppppppuStack_28) {
        FUN_005507b0();
        *(undefined4 ********)(iVar9 + 0x18) = pppppppuStack_28;
        *(undefined4 *)(iVar9 + 0x1c) = uStack_24;
        *(undefined4 *)(iVar9 + 0x20) = uStack_20;
        *(undefined4 *)(iVar9 + 0x24) = uStack_1c;
        *(ulonglong *)(iVar9 + 0x28) = CONCAT44(uStack_14,uStack_18);
        uStack_18 = 0;
        uStack_14 = 0xf;
        pppppppuStack_28 = (undefined4 *******)((uint)pppppppuStack_28 & 0xffffff00);
      }
      FUN_005507b0();
      uStack_8._0_1_ = 0xb;
      FUN_005507b0();
      FUN_0060e7f0(auStack_60);
      pcVar16 = "Load_Package";
    }
    FUN_0087c510("Studio","Package",pcVar16);
    FUN_0056cfd0();
    FUN_005705c0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20285 ; VA 0x00a331a0 ; FUN_00a331a0 */

void FUN_00a331a0(int param_1)

{
  int ***pppiVar1;
  undefined uVar2;
  uint *puVar3;
  int ****ppppiVar4;
  char cVar5;
  int **ppiVar6;
  undefined **ppuVar7;
  int iVar8;
  uint in_stack_00000018;
  int ****in_stack_0000001c;
  undefined4 *in_stack_00000020;
  undefined3 uStack00000024;
  char cStack00000027;
  undefined4 auStack_380 [4];
  undefined4 uStack_370;
  int ***pppiStack_36c;
  int ***pppiStack_368;
  undefined *puStack_364;
  int **ppiStack_360;
  undefined4 uStack_35c;
  int ***pppiStack_358;
  int ***pppiStack_354;
  int ***pppiStack_350;
  int ***pppiStack_34c;
  undefined8 uStack_348;
  uint auStack_340 [2];
  int **ppiStack_338;
  int ***pppiStack_334;
  int ***pppiStack_330;
  undefined8 uStack_32c;
  undefined8 uStack_324;
  undefined auStack_314 [104];
  undefined auStack_2ac [104];
  undefined auStack_244 [104];
  undefined auStack_1dc [104];
  undefined auStack_174 [104];
  int ***pppiStack_10c;
  int ***pppiStack_108;
  undefined auStack_104 [24];
  int **ppiStack_ec;
  int ***pppiStack_e8;
  int ***pppiStack_e4;
  undefined *puStack_e0;
  undefined *puStack_dc;
  int ***pppiStack_d4;
  int ***pppiStack_d0;
  int ***pppiStack_b4;
  undefined *puStack_b0;
  int **ppiStack_ac;
  int ***pppiStack_a4;
  int ***pppiStack_a0;
  int ***pppiStack_9c;
  int **ppiStack_98;
  ulonglong uStack_94;
  uint uStack_8c;
  int **ppiStack_84;
  int ***pppiStack_80;
  int ***pppiStack_7c;
  undefined *puStack_78;
  undefined8 uStack_74;
  int **ppiStack_68;
  int ***pppiStack_60;
  int ***pppiStack_5c;
  int ***pppiStack_58;
  int **ppiStack_54;
  ulonglong uStack_50;
  uint uStack_48;
  int **ppiStack_40;
  int ***pppiStack_3c;
  int ***pppiStack_38;
  undefined *puStack_34;
  undefined8 uStack_30;
  int ***pppiStack_28;
  int ***pppiStack_24;
  int ***pppiStack_20;
  undefined *puStack_1c;
  int ***pppiStack_18;
  int **ppiStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dd28d;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_324._0_4_ = (int ****)0xa331d2;
  ExceptionList = &pvStack_10;
  uStack_324._0_4_ = (int ****)FUN_008f7870();
  uStack_32c._4_4_ = &pppiStack_28;
  uStack_32c._0_4_ = (undefined4 *)0xa331df;
  puStack_1c = (undefined *)(int ****)uStack_324;
  FUN_005e5de0();
  uStack_32c._0_4_ = &param_1;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  pppiStack_330 = (int ***)0xa331ec;
  uStack_32c = FUN_00a15700();
  pppiStack_20 = (int ***)((ulonglong)uStack_32c >> 0x20);
  ppiStack_14 = (int **)uStack_32c;
  if ((int ****)pppiStack_24 != (int ****)0x0) {
    ppppiVar4 = (int ****)(pppiStack_24 + 2);
    LOCK();
    *ppppiVar4 = (int ***)((int)*ppppiVar4 + 1);
    UNLOCK();
    LOCK();
    *ppppiVar4 = (int ***)((int)*ppppiVar4 + 1);
    UNLOCK();
  }
  ppiStack_68 = (int **)0x0;
  if ((int ****)pppiStack_24 != (int ****)0x0) {
    LOCK();
    pppiStack_24[2] = (int **)((int)pppiStack_24[2] + 1);
    UNLOCK();
  }
  pppiStack_334 = pppiStack_28;
  pppiStack_330 = pppiStack_24;
  uStack_324._0_4_ = in_stack_0000001c;
  uStack_324._4_4_ = in_stack_00000020;
  ppiStack_338 = (int **)0xa3324c;
  FUN_00a294b0();
  if ((int ****)pppiStack_24 != (int ****)0x0) {
    LOCK();
    pppiVar1 = (int ***)((int)pppiStack_24[2] + -1);
    pppiStack_24[2] = (int **)pppiVar1;
    UNLOCK();
    if (pppiVar1 == (int ***)0x0) {
      uStack_324._4_4_ = (undefined4 *)0xa33265;
      (*(code *)(*pppiStack_24)[1])();
    }
    LOCK();
    pppiVar1 = (int ***)((int)pppiStack_24[2] + -1);
    pppiStack_24[2] = (int **)pppiVar1;
    UNLOCK();
    if (pppiVar1 == (int ***)0x0) {
      uStack_324._4_4_ = (undefined4 *)0xa33277;
      (*(code *)(*pppiStack_24)[1])();
    }
  }
  pppiStack_18 = (int ***)&pppiStack_10c;
  if ((int ****)pppiStack_24 != (int ****)0x0) {
    LOCK();
    pppiStack_24[2] = (int **)((int)pppiStack_24[2] + 1);
    UNLOCK();
  }
  pppiStack_10c = pppiStack_28;
  pppiStack_108 = pppiStack_24;
  uStack_324._4_4_ = &param_1;
  uStack_8._0_1_ = 3;
  uStack_324._0_4_ = (int ****)0xa332be;
  FUN_0054ef60();
  ppiStack_ec = ppiStack_14;
  pppiStack_e8 = pppiStack_20;
  pppiStack_e4 = (int ***)in_stack_0000001c;
  puStack_e0 = (undefined *)in_stack_00000020;
  puStack_dc = (undefined *)_uStack00000024;
  pppiStack_18 = (int ***)&pppiStack_a4;
  if ((int ****)pppiStack_108 != (int ****)0x0) {
    LOCK();
    pppiStack_108[2] = (int **)((int)pppiStack_108[2] + 1);
    UNLOCK();
  }
  pppiStack_a4 = pppiStack_10c;
  pppiStack_a0 = pppiStack_108;
  uStack_324._4_4_ = (undefined4 *)auStack_104;
  uStack_8._0_1_ = 5;
  uStack_324._0_4_ = (int ****)0xa33344;
  FUN_0054ef60();
  ppiStack_84 = ppiStack_ec;
  pppiStack_80 = pppiStack_e8;
  pppiStack_7c = pppiStack_e4;
  puStack_78 = puStack_e0;
  uStack_74 = CONCAT44(uStack_74._4_4_,puStack_dc);
  pppiStack_20 = (int ***)&pppiStack_354;
  uStack_48 = 0;
  if ((int ****)pppiStack_a0 != (int ****)0x0) {
    LOCK();
    pppiStack_a0[2] = (int **)((int)pppiStack_a0[2] + 1);
    UNLOCK();
  }
  pppiStack_354 = pppiStack_a4;
  pppiStack_350 = pppiStack_a0;
  pppiStack_358 = (int ***)&pppiStack_9c;
  uStack_8._0_1_ = 7;
  uStack_35c = 0xa333bf;
  FUN_0054ef60();
  pppiVar1 = pppiStack_20;
  uStack_8._0_1_ = 6;
  *(int ***)((int)pppiStack_20 + 0x20) = ppiStack_84;
  *(int ****)((int)pppiVar1 + 0x24) = pppiStack_80;
  *(int ****)((int)pppiVar1 + 0x28) = pppiStack_7c;
  *(undefined **)((int)pppiVar1 + 0x2c) = puStack_78;
  *(undefined4 *)((int)pppiVar1 + 0x30) = (undefined4)uStack_74;
  pppiStack_358 = (int ***)0xa333ec;
  FUN_00a29710();
  uStack_324._4_4_ = (undefined4 *)0xa333f7;
  FUN_005d11a0();
  uStack_324._4_4_ = (undefined4 *)0xa33402;
  FUN_005d11a0();
  uStack_8._0_1_ = 8;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  if (_uStack00000024 == (int ****)DAT_01d65dd4) {
    if ((puStack_1c != (undefined *)0x0) && (puStack_1c[0x1dd] != '\0')) {
      uStack_324._4_4_ = (undefined4 *)0xa33435;
      puStack_1c = (undefined *)FUN_005cf2a0();
      if (puStack_1c != (undefined *)0x0) {
        ppiStack_14 = (int **)((int)&uStack_348 + 4);
        _uStack00000024 = &pppiStack_d4;
        uStack_324 = (double)(DAT_01ee6e60 / 1000);
        if ((int ****)pppiStack_24 != (int ****)0x0) {
          LOCK();
          pppiStack_24[2] = (int **)((int)pppiStack_24[2] + 1);
          UNLOCK();
        }
        pppiStack_d4 = pppiStack_28;
        pppiStack_d0 = pppiStack_24;
        uStack_8._0_1_ = 0xb;
        pppiStack_34c = (int ***)0xa334b0;
        uStack_348._0_4_ = (int ****)&param_1;
        FUN_0054ef60();
        pppiStack_b4 = (int ***)in_stack_0000001c;
        puStack_b0 = (undefined *)in_stack_00000020;
        uStack_8._0_1_ = 0xc;
        ppiStack_ac = (int **)0x0;
        if ((int ***)ppiStack_68 != (int ***)0x0) {
          ppiStack_ac = ppiStack_68;
          if (((uint)ppiStack_68 & 1) == 0) {
            pppiStack_34c = (int ***)&pppiStack_a4;
            uStack_348._0_4_ = (int ****)0x0;
            pppiStack_350 = (int ***)&pppiStack_60;
            pppiStack_354 = (int ***)0xa3350f;
            (**(code **)((uint)ppiStack_68 & 0xfffffffe))();
          }
          else {
            pppiStack_a4 = pppiStack_60;
            pppiStack_a0 = pppiStack_5c;
            pppiStack_9c = pppiStack_58;
            ppiStack_98 = ppiStack_54;
            uStack_94 = uStack_50;
          }
        }
        uStack_8._0_1_ = 0xd;
        uStack_8c = 0;
        if (uStack_48 != 0) {
          uStack_8c = uStack_48;
          if ((uStack_48 & 1) == 0) {
            pppiStack_34c = &ppiStack_84;
            uStack_348._0_4_ = (int ****)0x0;
            pppiStack_350 = &ppiStack_40;
            pppiStack_354 = (int ***)0xa33556;
            (**(code **)(uStack_48 & 0xfffffffe))();
          }
          else {
            ppiStack_84 = ppiStack_40;
            pppiStack_80 = pppiStack_3c;
            pppiStack_7c = pppiStack_38;
            puStack_78 = puStack_34;
            uStack_74 = uStack_30;
          }
        }
        uStack_348._0_4_ = &pppiStack_d4;
        uStack_8._0_1_ = 0xe;
        pppiStack_34c = (int ***)0xa3356f;
        FUN_00a29ec0();
        uStack_8._0_1_ = 0xf;
        *ppiStack_14 = (int *)0x0;
        uStack_348._0_4_ = (int ****)auStack_314;
        pppiStack_34c = (int ***)0xa3358e;
        FUN_00a29ec0();
        uStack_348._0_4_ = (int ****)auStack_2ac;
        uStack_8._0_1_ = 0x10;
        pppiStack_34c = (int ***)0xa335a4;
        FUN_00a29ec0();
        uStack_348._0_4_ = (int ****)auStack_244;
        uStack_8._0_1_ = 0x11;
        pppiStack_34c = (int ***)0xa335ba;
        FUN_00a29ec0();
        uStack_348._0_4_ = (int ****)auStack_174;
        uStack_8._0_1_ = 0x12;
        pppiStack_34c = (int ***)0xa335ca;
        cVar5 = FUN_00585a40();
        if (cVar5 == '\0') {
          uStack_348._0_4_ = (int ****)auStack_174;
          pppiStack_34c = (int ***)0xa335e3;
          FUN_00a29ec0();
          uStack_348._0_4_ = (int ****)0x68;
          uStack_8._0_1_ = 0x13;
          pppiStack_34c = (int ***)0xa335ee;
          _uStack00000024 = (int ****)FUN_01674e20();
          uStack_8._0_1_ = 0x14;
          if (_uStack00000024 == (int ****)0x0) {
            ppiVar6 = (int **)0x0;
          }
          else {
            uStack_348._0_4_ = (int ****)auStack_1dc;
            pppiStack_34c = (int ***)0xa3360a;
            ppiVar6 = (int **)FUN_00a29ec0();
          }
          ppiStack_14[2] = (int *)ppiVar6;
          uStack_348._0_4_ = (int ****)0xa3361f;
          FUN_00a2aa70();
          uStack_348 = CONCAT44(uStack_348._4_4_,0xa3362a);
          FUN_00a2aa70();
          _uStack00000024 = (int ****)CONCAT13(1,uStack00000024);
        }
        else {
          uStack_348 = CONCAT44(uStack_348._4_4_,0xa3363b);
          FUN_00a2aa70();
          _uStack00000024 = (int ****)((uint)_uStack00000024 & 0xffffff);
        }
        uStack_348._0_4_ = (int ****)0xa3364a;
        FUN_00a2aa70();
        ppuVar7 = &PTR_FUN_01941314;
        if (cStack00000027 == '\0') {
          ppuVar7 = (undefined **)0x0;
        }
        *ppiStack_14 = (int *)ppuVar7;
        uStack_348._0_4_ = (int ****)0xa33667;
        FUN_00a2aa70();
        uStack_348._0_4_ = (int ****)0xa33672;
        FUN_00a2aa70();
        uStack_8 = CONCAT31(uStack_8._1_3_,8);
        uStack_348._0_4_ = (int ****)0xa33681;
        FUN_00a2aa70();
        uStack_348 = CONCAT44(uStack_348._4_4_,0xa33689);
        FUN_009eef30();
        goto LAB_00a3377d;
      }
    }
    uStack_8._0_1_ = 9;
    if (uStack_48 != 0) {
      if (((uStack_48 & 1) == 0) && (*(code **)(uStack_48 & 0xfffffffe) != (code *)0x0)) {
        uStack_32c._4_4_ = (int ****)&ppiStack_40;
        uStack_324._4_4_ = (undefined4 *)0x2;
        uStack_32c._0_4_ = (undefined4 *)0xa336af;
        uStack_324._0_4_ = uStack_32c._4_4_;
        (**(code **)(uStack_48 & 0xfffffffe))();
      }
      uStack_48 = 0;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
  }
  else {
    uStack_324._4_4_ = (undefined4 *)0x0;
    _uStack00000024 = (int ****)auStack_340;
    pppiStack_18 = (int ***)auStack_340;
    auStack_340[0] = 0;
    puVar3 = auStack_340;
    if (uStack_48 != 0) {
      auStack_340[0] = uStack_48;
      if ((uStack_48 & 1) == 0) {
        uStack_348 = ZEXT48(&ppiStack_338);
        pppiStack_34c = &ppiStack_40;
        pppiStack_350 = (int ***)0xa33708;
        uStack_8._0_1_ = uVar2;
        (**(code **)(uStack_48 & 0xfffffffe))();
        puVar3 = (uint *)_uStack00000024;
      }
      else {
        ppiStack_338 = ppiStack_40;
        pppiStack_334 = pppiStack_3c;
        pppiStack_330 = pppiStack_38;
        uStack_32c._0_4_ = (undefined4 *)puStack_34;
        uStack_32c._4_4_ = (int ****)uStack_30;
        uStack_324._0_4_ = (int ****)((ulonglong)uStack_30 >> 0x20);
        puVar3 = auStack_340;
      }
    }
    _uStack00000024 = (int ****)puVar3;
    pppiStack_18 = &ppiStack_360;
    puStack_1c = (undefined *)&ppiStack_360;
    uStack_8._0_1_ = 0x15;
    ppiStack_360 = (int **)0x0;
    pppiVar1 = &ppiStack_360;
    ppppiVar4 = (int ****)&ppiStack_360;
    if ((int ***)ppiStack_68 != (int ***)0x0) {
      ppiStack_360 = ppiStack_68;
      if (((uint)ppiStack_68 & 1) == 0) {
        pppiStack_368 = (int ***)&pppiStack_358;
        puStack_364 = (undefined *)0x0;
        pppiStack_36c = (int ***)&pppiStack_60;
        uStack_370 = 0xa33753;
        (**(code **)((uint)ppiStack_68 & 0xfffffffe))();
        pppiVar1 = (int ***)puStack_1c;
        ppppiVar4 = (int ****)pppiStack_18;
      }
      else {
        pppiStack_358 = pppiStack_60;
        pppiStack_354 = pppiStack_5c;
        pppiStack_350 = pppiStack_58;
        pppiStack_34c = (int ***)ppiStack_54;
        uStack_348 = uStack_50;
        pppiVar1 = &ppiStack_360;
        ppppiVar4 = (int ****)&ppiStack_360;
      }
    }
    pppiStack_18 = (int ***)ppppiVar4;
    puStack_1c = (undefined *)pppiVar1;
    puStack_364 = (undefined *)in_stack_00000020;
    uStack_8._0_1_ = 0x16;
    pppiStack_368 = (int ***)in_stack_0000001c;
    in_stack_00000020 = auStack_380;
    FUN_0054ef60(&param_1);
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    FUN_00a307a0();
LAB_00a3377d:
    uStack_8._0_1_ = 0x17;
    if (uStack_48 != 0) {
      if (((uStack_48 & 1) == 0) && (*(code **)(uStack_48 & 0xfffffffe) != (code *)0x0)) {
        uStack_32c._4_4_ = (int ****)&ppiStack_40;
        uStack_324._4_4_ = (undefined4 *)0x2;
        uStack_32c._0_4_ = (undefined4 *)0xa3379e;
        uStack_324._0_4_ = uStack_32c._4_4_;
        (**(code **)(uStack_48 & 0xfffffffe))();
      }
      uStack_48 = 0;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
  }
  if ((int ***)ppiStack_68 != (int ***)0x0) {
    if ((((uint)ppiStack_68 & 1) == 0) &&
       (*(code **)((uint)ppiStack_68 & 0xfffffffe) != (code *)0x0)) {
      uStack_32c._4_4_ = &pppiStack_60;
      uStack_324._4_4_ = (undefined4 *)0x2;
      uStack_32c._0_4_ = (undefined4 *)0xa337c9;
      uStack_324._0_4_ = uStack_32c._4_4_;
      (**(code **)((uint)ppiStack_68 & 0xfffffffe))();
    }
    ppiStack_68 = (int **)0x0;
  }
  if ((int ****)pppiStack_24 != (int ****)0x0) {
    LOCK();
    ppppiVar4 = (int ****)(pppiStack_24 + 2);
    pppiVar1 = *ppppiVar4;
    *ppppiVar4 = (int ***)((int)*ppppiVar4 + -1);
    UNLOCK();
    if (pppiVar1 == (int ***)0x1) {
      uStack_324._4_4_ = (undefined4 *)0xa337e6;
      (*(code *)(*pppiStack_24)[1])();
    }
  }
  if (0xf < in_stack_00000018) {
    uStack_324._4_4_ = (undefined4 *)(in_stack_00000018 + 1);
    iVar8 = param_1;
    if (0xfff < uStack_324._4_4_) {
      iVar8 = *(int *)(param_1 + -4);
      uStack_324._4_4_ = (undefined4 *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_1 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        uStack_324._4_4_ = (undefined4 *)&UNK_00a3382d;
        FUN_017167a3();
      }
    }
    uStack_32c._4_4_ = (int ****)0xa33813;
    uStack_324._0_4_ = (int ****)iVar8;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20286 ; VA 0x00a33830 ; FUN_00a33830 */

void __thiscall FUN_00a33830(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  if (*(int *)(param_1 + 0x164) != 0) {
    FUN_00fbd130(param_2,param_3,param_4);
  }
  return;
}



/* FUNCTION 20287 ; VA 0x00a33850 ; FUN_00a33850 */

undefined4 * FUN_00a33850(void)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 ****ppppuVar3;
  uint uVar4;
  undefined4 ***apppuStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  undefined auStack_2c [20];
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd2b4;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee70d0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee70d0);
    if (DAT_01ee70d0 == -1) {
      uStack_8 = 0;
      FUN_0171e1b0(auStack_18);
      uVar2 = FUN_017243c8(auStack_18);
      FUN_01724efb(auStack_2c,0x11,"%Y%m%dT%H%M%SZ",uVar2);
      uStack_34 = 0;
      uStack_30 = 0xf;
      apppuStack_44[0] = (undefined4 ***)((uint)apppuStack_44[0] & 0xffffff00);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_009c9100(apppuStack_44);
      ppppuVar3 = apppuStack_44;
      if (0xf < uStack_30) {
        ppppuVar3 = (undefined4 ****)apppuStack_44[0];
      }
      FUN_01675640(&DAT_01ee70b8,"%s_%s_%s_%s",&DAT_01941358,auStack_2c,&DAT_01941354,ppppuVar3);
      if (0xf < uStack_30) {
        uVar4 = uStack_30 + 1;
        ppppuVar3 = (undefined4 ****)apppuStack_44[0];
        if (0xfff < uVar4) {
          ppppuVar3 = (undefined4 ****)apppuStack_44[0][-1];
          uVar4 = uStack_30 + 0x24;
          if (0x1f < (uint)((int)apppuStack_44[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar3,uVar4);
      }
      FUN_016f3654(&LAB_01889800);
      FUN_016f37bf(&DAT_01ee70d0);
    }
  }
  puVar1 = &DAT_01ee70b8;
  if (0xf < DAT_01ee70cc) {
    puVar1 = DAT_01ee70b8;
  }
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 20288 ; VA 0x00a33990 ; FUN_00a33990 */

void __thiscall FUN_00a33990(int param_1,undefined4 *param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  int *piVar8;
  int *piVar9;
  int *piVar10;
  bool bVar11;
  int *piStack_c;
  int *piStack_8;
  
  piStack_c = (int *)0x0;
  piStack_8 = (int *)0x0;
  iVar2 = param_1;
  if (param_1 == -0xc) {
    iVar2 = 0;
  }
  uVar3 = *(int *)(iVar2 + 0x28) + 1;
  if (*(uint *)(param_1 + 0x24) < uVar3) {
    uVar6 = 0xffffffff;
    if ((float)(((double)(int)uVar3 + (double)(&DAT_018c0d90)[-((int)uVar3 >> 0x1f)]) /
                (double)*(float *)(param_1 + 0x20) + DAT_018c0d60) < DAT_018c0d80) {
      uVar6 = FUN_016f3cd0();
    }
    FUN_00a342a0(uVar6,param_3);
  }
  uVar6 = *(undefined4 *)(param_1 + 0x10);
  uVar4 = FUN_00a33df0(param_3);
  iVar5 = FUN_008a4250(uVar4,uVar6);
  piVar1 = (int *)(*(int *)(param_1 + 0x1c) + iVar5 * 4);
  piVar8 = (int *)*piVar1;
  while (piVar8 != (int *)0x0) {
    uVar3 = 0xc;
    piVar10 = (int *)(-(uint)(piVar8 != (int *)0x0) & (uint)(piVar8 + -0xc));
    piVar9 = param_3;
    piVar7 = piVar10;
    while (*piVar9 == *piVar7) {
      piVar9 = piVar9 + 1;
      piVar7 = piVar7 + 1;
      bVar11 = uVar3 < 4;
      uVar3 = uVar3 - 4;
      if (bVar11) goto LAB_00a33ad2;
    }
    piVar10 = piVar8 + 1;
    bVar11 = *(int **)*piVar10 == piVar8;
    piVar8 = (int *)0x0;
    if (bVar11) {
      piVar8 = (int *)*piVar10;
    }
  }
  piVar10 = (int *)FUN_00a33ff0(param_3,&piStack_8,param_4);
  piStack_c = piStack_8;
  if (piVar10 == piStack_8) {
    piVar9 = (int *)(-(uint)(*(int *)(iVar2 + 4) != 0) & *(int *)(iVar2 + 4) + 0x30U);
    piVar8 = (int *)(-(uint)(piStack_8 != (int *)0x0) & (uint)(piStack_8 + 0xc));
    if ((int *)*piVar1 == (int *)0x0) {
      iVar2 = *piVar9;
      *piVar8 = iVar2;
      piVar8[1] = *(int *)(*piVar9 + 4);
      *(int **)(iVar2 + 4) = piVar1;
      *piVar1 = (int)piVar8;
      *piVar9 = (int)piVar8;
    }
    else {
      *piVar8 = *(int *)*piVar1;
      piVar8[1] = *piVar1;
      *piVar1 = (int)piVar8;
      *(int **)piVar8[1] = piVar8;
    }
  }
LAB_00a33ad2:
  *param_2 = piVar10;
  if (piVar10 == piStack_c) {
    *(undefined *)(param_2 + 1) = 1;
    *(int *)(param_1 + 0x28) = *(int *)(param_1 + 0x28) + 1;
    return;
  }
  *(undefined *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 20289 ; VA 0x00a33b00 ; FUN_00a33b00 */

undefined4 * __thiscall FUN_00a33b00(undefined4 *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  int iVar7;
  int *piVar8;
  uint uVar9;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dd2cb;
  pvStack_10 = ExceptionList;
  piVar8 = param_1 + 4;
  ExceptionList = &pvStack_10;
  param_1[8] = 0;
  param_1[9] = 0;
  iVar7 = param_2[1];
  iVar1 = param_2[2];
  iVar2 = param_2[3];
  *piVar8 = *param_2;
  param_1[5] = iVar7;
  param_1[6] = iVar1;
  param_1[7] = iVar2;
  *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 4);
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  uStack_8 = 0;
  if (0xf < (uint)param_1[9]) {
    piVar8 = (int *)*piVar8;
  }
  puStack_14 = param_1;
  puVar6 = (undefined4 *)FUN_01530c60(aiStack_2c,piVar8,param_1[8],0x10);
  if (0xf < (uint)puVar6[5]) {
    puVar6 = (undefined4 *)*puVar6;
  }
  uVar3 = puVar6[1];
  uVar4 = puVar6[2];
  uVar5 = puVar6[3];
  *param_1 = *puVar6;
  param_1[1] = uVar3;
  param_1[2] = uVar4;
  param_1[3] = uVar5;
  if (0xf < uStack_18) {
    uVar9 = uStack_18 + 1;
    iVar7 = aiStack_2c[0];
    if (0xfff < uVar9) {
      iVar7 = *(int *)(aiStack_2c[0] + -4);
      uVar9 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar9);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20290 ; VA 0x00a33be0 ; FUN_00a33be0 */

undefined4 __thiscall FUN_00a33be0(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int iStack_2c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd2e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a33b00(param_2);
  uStack_8 = 0;
  FUN_00a34060(param_1,uVar1);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    iVar2 = iStack_2c;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iStack_2c + -4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (iStack_2c - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20291 ; VA 0x00a33c70 ; FUN_00a33c70 */

int * __fastcall FUN_00a33c70(int *param_1)

{
  undefined4 uVar1;
  undefined auStack_2c [16];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd31c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee70d8) {
    ExceptionList = &pvStack_10;
    piStack_14 = param_1;
    FUN_016f3809(&DAT_01ee70d8);
    if (DAT_01ee70d8 == -1) {
      uStack_8 = 0;
      uStack_1c = 0;
      uStack_18 = 0xf;
      auStack_2c[0] = 0;
      FUN_005542c0(&DAT_018bc9b8,0);
      uStack_8._0_1_ = 1;
      uVar1 = FUN_00a33b00(auStack_2c);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_00a34060(&DAT_01ee70d4,uVar1);
      FUN_0056ce50();
      FUN_005507b0();
      FUN_016f3654(FUN_01889860);
      FUN_016f37bf(&DAT_01ee70d8);
    }
  }
  *param_1 = DAT_01ee70d4;
  LOCK();
  *(int *)(DAT_01ee70d4 + 0x28) = *(int *)(DAT_01ee70d4 + 0x28) + 1;
  UNLOCK();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20292 ; VA 0x00a33d60 ; FUN_00a33d60 */

bool __thiscall FUN_00a33d60(int *param_1,int *param_2)

{
  return *param_1 == *param_2;
}



/* FUNCTION 20293 ; VA 0x00a33d80 ; FUN_00a33d80 */

undefined4 __thiscall FUN_00a33d80(undefined4 *param_1,undefined4 *param_2)

{
  byte bVar1;
  int *piVar2;
  byte *pbVar3;
  uint uVar4;
  bool bVar5;
  
  piVar2 = (int *)*param_1;
  uVar4 = 0xc;
  pbVar3 = (byte *)*param_2;
  while (*piVar2 == *(int *)pbVar3) {
    piVar2 = piVar2 + 1;
    pbVar3 = pbVar3 + 4;
    bVar5 = uVar4 < 4;
    uVar4 = uVar4 - 4;
    if (bVar5) {
      return 0;
    }
  }
  bVar1 = (byte)*piVar2;
  bVar5 = bVar1 < *pbVar3;
  if ((((bVar1 == *pbVar3) &&
       (bVar5 = *(byte *)((int)piVar2 + 1) < pbVar3[1], *(byte *)((int)piVar2 + 1) == pbVar3[1])) &&
      (bVar5 = *(byte *)((int)piVar2 + 2) < pbVar3[2], *(byte *)((int)piVar2 + 2) == pbVar3[2])) &&
     (bVar5 = *(byte *)((int)piVar2 + 3) < pbVar3[3], *(byte *)((int)piVar2 + 3) == pbVar3[3])) {
    return 0;
  }
  return CONCAT31((int3)(-(uint)bVar5 >> 8),(int)(-(uint)bVar5 | 1) < 0);
}



/* FUNCTION 20294 ; VA 0x00a33df0 ; FUN_00a33df0 */

uint FUN_00a33df0(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  bool bVar4;
  
  uVar3 = 0;
  iVar2 = 0;
  bVar4 = param_1 + 4 < param_1;
  if (param_1 <= param_1 + 4) {
    do {
      iVar1 = *param_1;
      param_1 = param_1 + 1;
      iVar2 = iVar2 + 1;
      uVar3 = uVar3 ^ iVar1 + -0x61c88647 + uVar3 * 0x40 + (uVar3 >> 2);
    } while (iVar2 != (-(uint)bVar4 & 0xfffffffc) + 4);
  }
  return uVar3;
}



/* FUNCTION 20295 ; VA 0x00a33e40 ; FUN_00a33e40 */

void __thiscall FUN_00a33e40(int *param_1,uint *param_2)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  int iStack_d8;
  int *piStack_c4;
  int *piStack_c0;
  int *piStack_b4;
  uint *puStack_b0;
  int *piStack_a4;
  uint auStack_a0 [26];
  uint uStack_38;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 auStack_18 [2];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd354;
  pvStack_10 = ExceptionList;
  auStack_18[0] = 0;
  iVar1 = *param_1;
  ExceptionList = &pvStack_10;
  FUN_00565940(3,1);
  uStack_38 = uStack_38 & 0xffffff00;
  uStack_8 = 0;
  FUN_008825f0(iVar1,iVar1 + 0x10,uStack_38,
               *(undefined4 *)((int)auStack_a0 + *(int *)(iStack_d8 + 4)),auStack_18,param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_20 = 0;
  uStack_1c = 0xf;
  uStack_30 = uStack_30 & 0xffffff00;
  auStack_18[0] = 2;
  if (((auStack_a0[3] & 2) == 0) && (uVar4 = *puStack_b0, uVar4 != 0)) {
    if (uVar4 < auStack_a0[2]) {
      uVar4 = auStack_a0[2];
    }
    iVar1 = *piStack_c0;
    iVar3 = uVar4 - iVar1;
  }
  else {
    if (((auStack_a0[3] & 4) != 0) || (*piStack_b4 == 0)) goto LAB_00a33f2b;
    iVar1 = *piStack_c4;
    iVar3 = (*piStack_b4 - iVar1) + *piStack_a4;
  }
  FUN_005542c0(iVar1,iVar3);
LAB_00a33f2b:
  if (param_2 == &uStack_30) {
    if (0xf < uStack_1c) {
      uVar4 = uStack_1c + 1;
      uVar2 = uStack_30;
      if (0xfff < uVar4) {
        uVar2 = *(uint *)(uStack_30 - 4);
        uVar4 = uStack_1c + 0x24;
        if (0x1f < (uStack_30 - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar2,uVar4);
    }
  }
  else {
    FUN_005507b0();
    *param_2 = uStack_30;
    param_2[1] = uStack_2c;
    param_2[2] = uStack_28;
    param_2[3] = uStack_24;
    *(ulonglong *)(param_2 + 4) = CONCAT44(uStack_1c,uStack_20);
  }
  FUN_005705c0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20296 ; VA 0x00a33fa0 ; FUN_00a33fa0 */

int __fastcall FUN_00a33fa0(int *param_1)

{
  return *param_1 + 0x10;
}



/* FUNCTION 20297 ; VA 0x00a33fb0 ; FUN_00a33fb0 */

void __thiscall FUN_00a33fb0(int *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  puVar1 = (undefined4 *)*param_1;
  uVar2 = puVar1[1];
  uVar3 = puVar1[2];
  uVar4 = puVar1[3];
  *param_2 = *puVar1;
  param_2[1] = uVar2;
  param_2[2] = uVar3;
  param_2[3] = uVar4;
  return;
}



/* FUNCTION 20298 ; VA 0x00a33fd0 ; FUN_00a33fd0 */

int FUN_00a33fd0(uint *param_1)

{
  return (*param_1 >> 3) + *param_1;
}



/* FUNCTION 20299 ; VA 0x00a33ff0 ; FUN_00a33ff0 */

undefined4 FUN_00a33ff0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  puVar4 = (undefined4 *)FUN_01674e20(0x38);
  *param_2 = puVar4;
  puVar4[8] = 0;
  puVar4[9] = 0;
  uVar1 = param_1[5];
  uVar2 = param_1[6];
  uVar3 = param_1[7];
  puVar4[4] = param_1[4];
  puVar4[5] = uVar1;
  puVar4[6] = uVar2;
  puVar4[7] = uVar3;
  *(undefined8 *)(puVar4 + 8) = *(undefined8 *)(param_1 + 8);
  param_1[8] = 0;
  param_1[9] = 0xf;
  *(undefined *)(param_1 + 4) = 0;
  uVar1 = param_1[1];
  uVar2 = param_1[2];
  uVar3 = param_1[3];
  *puVar4 = *param_1;
  puVar4[1] = uVar1;
  puVar4[2] = uVar2;
  puVar4[3] = uVar3;
  puVar4[10] = 0;
  puVar4[0xb] = 0;
  return *param_2;
}



/* FUNCTION 20300 ; VA 0x00a34060 ; FUN_00a34060 */

int * FUN_00a34060(int *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int aiStack_18 [2];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd370;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00585a90();
  uStack_20 = 0;
  uStack_1c = 0;
  iStack_38 = param_2[4];
  uStack_34 = param_2[5];
  uStack_30 = param_2[6];
  uStack_2c = param_2[7];
  uStack_28 = *(undefined8 *)(param_2 + 8);
  param_2[8] = 0;
  param_2[9] = 0xf;
  *(undefined *)(param_2 + 4) = 0;
  uVar2 = DAT_01ea8518;
  uStack_48 = *param_2;
  uStack_44 = param_2[1];
  uStack_40 = param_2[2];
  uStack_3c = param_2[3];
  uStack_8 = 0;
  EnterCriticalSection(DAT_01ea8518);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00a33990(aiStack_18,&uStack_48,uVar2);
  *param_1 = aiStack_18[0];
  LOCK();
  piVar1 = (int *)(aiStack_18[0] + 0x28);
  iVar3 = *piVar1;
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  if (iVar3 == 0) {
    *(int *)(*param_1 + 0x2c) = *(int *)(*param_1 + 0x2c) + 1;
  }
  LeaveCriticalSection(uVar2);
  if (0xf < uStack_28._4_4_) {
    uVar4 = uStack_28._4_4_ + 1;
    iVar3 = iStack_38;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iStack_38 + -4);
      uVar4 = uStack_28._4_4_ + 0x24;
      if (0x1f < (iStack_38 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20301 ; VA 0x00a34170 ; FUN_00a34170 */

void __thiscall FUN_00a34170(int *param_1,int param_2)

{
  int *piVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  int iStack_2c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd388;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00a33b00(param_2);
  uStack_8 = 0;
  FUN_00a34060(&param_2,uVar3);
  LOCK();
  *(int *)(param_2 + 0x28) = *(int *)(param_2 + 0x28) + 1;
  UNLOCK();
  iStack_14 = *param_1;
  *param_1 = param_2;
  uStack_8._0_1_ = 1;
  LOCK();
  iVar4 = *(int *)(iStack_14 + 0x28) + -1;
  *(int *)(iStack_14 + 0x28) = iVar4;
  UNLOCK();
  if (iVar4 == 0) {
    FUN_00585a90();
    uVar3 = DAT_01ea8518;
    EnterCriticalSection(DAT_01ea8518);
    cVar2 = FUN_00578b90(&iStack_14);
    if (cVar2 != '\0') {
      FUN_0057ef00(iStack_14);
    }
    LeaveCriticalSection(uVar3);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  LOCK();
  piVar1 = (int *)(param_2 + 0x28);
  iVar4 = *piVar1;
  *piVar1 = *piVar1 + -1;
  UNLOCK();
  if (iVar4 == 1) {
    FUN_00585a90();
    uVar3 = DAT_01ea8518;
    EnterCriticalSection(DAT_01ea8518);
    cVar2 = FUN_00578b90(&param_2);
    if (cVar2 != '\0') {
      FUN_0057ef00(param_2);
    }
    LeaveCriticalSection(uVar3);
  }
  if (0xf < uStack_18) {
    uVar5 = uStack_18 + 1;
    iVar4 = iStack_2c;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iStack_2c + -4);
      uVar5 = uStack_18 + 0x24;
      if (0x1f < (iStack_2c - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20302 ; VA 0x00a342a0 ; FUN_00a342a0 */

void __thiscall FUN_00a342a0(int param_1,undefined4 *param_2)

{
  int ****ppppiVar1;
  int iVar2;
  int iVar3;
  float fVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  undefined4 uVar10;
  uint uVar11;
  int ***pppiVar12;
  undefined4 *puVar13;
  int *****pppppiVar14;
  int *****pppppiVar15;
  undefined4 uStack_5c;
  undefined4 uStack_54;
  int iStack_50;
  int ****ppppiStack_40;
  int ***pppiStack_3c;
  uint uStack_38;
  uint uStack_34;
  int ****ppppiStack_30;
  int iStack_2c;
  int ****ppppiStack_28;
  int iStack_24;
  uint uStack_20;
  int iStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd3b8;
  pvStack_10 = ExceptionList;
  piVar5 = (int *)(param_1 + -8);
  if (param_1 == 0) {
    piVar5 = (int *)&DAT_00000004;
  }
  pppppiVar15 = (int *****)(-(uint)(*piVar5 != 0) & *piVar5 + 0x30U);
  ExceptionList = &pvStack_10;
  ppppiStack_30 = (int ****)pppppiVar15;
  iStack_14 = param_1;
  FUN_00565b60((int)&param_2 + 3,&ppppiStack_40,param_2);
  uStack_8 = 0;
  uVar6 = iStack_14 - 0xc;
  if (iStack_14 == 0) {
    uVar6 = 0xfffffff4;
  }
  uVar6 = -(uint)(iStack_14 != 0) & uVar6;
  uStack_38 = *(uint *)(uVar6 + 0x28);
  if (uStack_38 != 0) {
    uVar11 = uStack_38 * 4;
    if (uStack_38 < 0x40000000) {
      if (0xfff < uVar11) goto LAB_00a3433c;
      if (uVar11 == 0) {
        uVar11 = 0;
      }
      else {
        uVar11 = FUN_01674e20(uVar11);
      }
    }
    else {
      uVar11 = 0xffffffff;
LAB_00a3433c:
      uVar7 = uVar11 + 0x23;
      if (uVar7 <= uVar11) {
        uVar7 = 0xffffffff;
      }
      iVar8 = FUN_01674e20(uVar7);
      if (iVar8 == 0) goto LAB_00a345fa;
      uVar11 = iVar8 + 0x23U & 0xffffffe0;
      *(int *)(uVar11 - 4) = iVar8;
    }
    uStack_34 = *(uint *)(uVar6 + 0x28);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    uStack_20 = uVar11;
    if (uStack_34 == 0) {
      param_2 = (undefined4 *)0x0;
      iStack_1c = 0;
    }
    else {
      uVar7 = uStack_34 * 4;
      if (uStack_34 < 0x40000000) {
        if (uVar7 < 0x1000) {
          if (uVar7 == 0) {
            iStack_1c = *(int *)(uVar6 + 0x28);
            param_2 = (undefined4 *)0x0;
          }
          else {
            param_2 = (undefined4 *)FUN_01674e20(uVar7);
            iStack_1c = *(int *)(uVar6 + 0x28);
          }
          goto LAB_00a343ec;
        }
      }
      else {
        uVar7 = 0xffffffff;
      }
      uVar9 = uVar7 + 0x23;
      if (uVar9 <= uVar7) {
        uVar9 = 0xffffffff;
      }
      iVar8 = FUN_01674e20(uVar9);
      if (iVar8 == 0) goto LAB_00a345fa;
      param_2 = (undefined4 *)(iVar8 + 0x23U & 0xffffffe0);
      param_2[-1] = iVar8;
      iStack_1c = *(int *)(uVar6 + 0x28);
    }
LAB_00a343ec:
    if (iStack_1c != 0) {
      iStack_2c = uVar11 - (int)param_2;
      pppppiVar14 = pppppiVar15;
      puStack_18 = param_2;
      do {
        pppppiVar15 = (int *****)ppppiStack_30;
        pppppiVar14 = (int *****)*pppppiVar14;
        uVar6 = 0;
        iVar8 = 0;
        piVar5 = (int *)(-(uint)(pppppiVar14 != (int *****)0x0) & (uint)(pppppiVar14 + -0xc));
        iStack_24 = (-(uint)(piVar5 + 4 < piVar5) & 0xfffffffc) + 4;
        if (piVar5 <= piVar5 + 4) {
          do {
            iVar8 = iVar8 + 1;
            uVar6 = uVar6 ^ *piVar5 + -0x61c88647 + uVar6 * 0x40 + (uVar6 >> 2);
            piVar5 = piVar5 + 1;
          } while (iVar8 != iStack_24);
        }
        *(uint *)(iStack_2c + (int)puStack_18) = uVar6;
        *puStack_18 = pppppiVar14;
        ppppiVar1 = (int ****)*ppppiStack_30;
        pppiVar12 = *ppppiVar1;
        if ((int ****)pppiVar12[1] != ppppiVar1) {
          *pppiVar12[1] = (int *)0x0;
          pppiVar12 = *ppppiVar1;
        }
        pppiVar12[1] = (int **)ppppiVar1[1];
        *ppppiStack_30 = *ppppiVar1;
        ppppiStack_28 = (int ****)pppppiVar14;
        iVar8 = FUN_008a4250(uVar6,uStack_5c);
        pppiVar12 = (int ***)(iStack_50 + iVar8 * 4);
        if (*pppiVar12 == (int **)0x0) {
          *pppppiVar14 = ppppiStack_40;
          pppppiVar14[1] = (int ****)ppppiStack_40[1];
          (*pppppiVar14)[1] = pppiVar12;
          *pppiVar12 = (int **)pppppiVar14;
          ppppiStack_40 = (int ****)pppppiVar14;
        }
        else {
          *pppppiVar14 = (int ****)**pppiVar12;
          pppppiVar14[1] = (int ****)*pppiVar12;
          *pppiVar12 = (int **)pppppiVar14;
          *pppppiVar14[1] = (int ***)pppppiVar14;
        }
        puStack_18 = puStack_18 + 1;
        iStack_1c = iStack_1c + -1;
        pppppiVar14 = pppppiVar15;
      } while (iStack_1c != 0);
      iStack_1c = 0;
      uVar11 = uStack_20;
    }
    if (uStack_34 != 0) {
      uVar6 = uStack_34 * 4;
      puVar13 = param_2;
      if (0xfff < uVar6) {
        puVar13 = (undefined4 *)param_2[-1];
        uVar6 = uVar6 + 0x23;
        if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar13))) goto LAB_00a345fa;
      }
      FUN_01674ea0(puVar13,uVar6);
    }
    if (uStack_38 != 0) {
      uVar7 = uStack_38 * 4;
      uVar6 = uVar11;
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(uVar11 - 4);
        uVar7 = uVar7 + 0x23;
        if (0x1f < (uVar11 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
  }
  fVar4 = DAT_018c0d80;
  pppppiVar14 = pppppiVar15;
  if ((int *****)ppppiStack_40 != &ppppiStack_40) {
    pppppiVar14 = (int *****)ppppiStack_40;
  }
  *pppppiVar15 = (int ****)pppppiVar14;
  pppppiVar15[1] = (int ****)pppiStack_3c;
  **pppiStack_3c = (int *)pppppiVar15;
  *(*pppppiVar15)[1] = (int **)pppppiVar15;
  *(undefined4 *)(iStack_14 + 4) = uStack_5c;
  iVar8 = *(int *)(iStack_14 + 0xc);
  *(undefined4 *)(iStack_14 + 0xc) = uStack_54;
  iVar2 = *(int *)(iStack_14 + 0x10);
  *(int *)(iStack_14 + 0x10) = iStack_50;
  iVar3 = *(int *)(&DAT_018be080 + *(int *)(iStack_14 + 4) * 4);
  *(undefined4 *)(iStack_14 + 0x18) = 0xffffffff;
  if ((float)((double)iVar3 + (double)(&DAT_018c0d90)[-(iVar3 >> 0x1f)]) *
      *(float *)(iStack_14 + 0x14) < fVar4) {
    uVar10 = FUN_016f3cd0();
    *(undefined4 *)(iStack_14 + 0x18) = uVar10;
  }
  if (iVar8 != 0) {
    uVar6 = iVar8 * 4;
    iVar8 = iVar2;
    if (0xfff < uVar6) {
      iVar8 = *(int *)(iVar2 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar2 - iVar8) - 4U) {
LAB_00a345fa:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20303 ; VA 0x00a34610 ; FUN_00a34610 */

undefined * FUN_00a34610(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd3dc;
  pvStack_10 = ExceptionList;
  if (DAT_01ee70dc == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee72e8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee72e8);
      if (DAT_01ee72e8 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00b73900();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"CoreScript",0,uStack_20,0,0,1,5,0);
        FUN_016f3654(&LAB_018898e0);
        FUN_016f37bf(&DAT_01ee72e8);
      }
    }
    DAT_01ee70dc = &DAT_01ee70e0;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee70dc;
}



/* FUNCTION 20304 ; VA 0x00a346f0 ; FUN_00a346f0 */

void __thiscall FUN_00a346f0(int param_1,uint *param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  int *piVar8;
  bool bVar9;
  uint uStack_c;
  uint uStack_8;
  
  uStack_c = 0;
  uStack_8 = 0;
  iVar3 = param_1;
  if (param_1 == -0xc) {
    iVar3 = 0;
  }
  uVar4 = *(int *)(iVar3 + 0x28) + 1;
  if (*(uint *)(param_1 + 0x24) < uVar4) {
    uVar6 = 0xffffffff;
    if ((float)(((double)(int)uVar4 + (double)(&DAT_018c0d90)[-((int)uVar4 >> 0x1f)]) /
                (double)*(float *)(param_1 + 0x20) + DAT_018c0d60) < DAT_018c0d80) {
      uVar6 = FUN_016f3cd0();
    }
    FUN_00a35ca0(uVar6,param_3);
  }
  uVar6 = FUN_00886e30(param_3);
  iVar5 = FUN_008a4250(uVar6,*(undefined4 *)(param_1 + 0x10));
  piVar1 = (int *)(*(int *)(param_1 + 0x1c) + iVar5 * 4);
  piVar7 = (int *)*piVar1;
  while (piVar7 != (int *)0x0) {
    uVar4 = -(uint)(piVar7 != (int *)0x0) & (uint)(piVar7 + -4);
    cVar2 = FUN_00886890(uVar4);
    if (cVar2 != '\0') goto LAB_00a3481d;
    piVar8 = piVar7 + 1;
    bVar9 = *(int **)*piVar8 == piVar7;
    piVar7 = (int *)0x0;
    if (bVar9) {
      piVar7 = (int *)*piVar8;
    }
  }
  uVar4 = FUN_00a35710(param_3,&uStack_8,param_4);
  uStack_c = uStack_8;
  if (uVar4 == uStack_8) {
    piVar8 = (int *)(-(uint)(*(int *)(iVar3 + 4) != 0) & *(int *)(iVar3 + 4) + 0x10U);
    piVar7 = (int *)(-(uint)(uStack_8 != 0) & uStack_8 + 0x10);
    if ((int *)*piVar1 == (int *)0x0) {
      iVar3 = *piVar8;
      *piVar7 = iVar3;
      piVar7[1] = *(int *)(*piVar8 + 4);
      *(int **)(iVar3 + 4) = piVar1;
      *piVar1 = (int)piVar7;
      *piVar8 = (int)piVar7;
    }
    else {
      *piVar7 = *(int *)*piVar1;
      piVar7[1] = *piVar1;
      *piVar1 = (int)piVar7;
      *(int **)piVar7[1] = piVar7;
    }
  }
LAB_00a3481d:
  *param_2 = uVar4;
  if (uVar4 == uStack_c) {
    *(undefined *)(param_2 + 1) = 1;
    *(int *)(param_1 + 0x28) = *(int *)(param_1 + 0x28) + 1;
    return;
  }
  *(undefined *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 20305 ; VA 0x00a34850 ; FUN_00a34850 */

undefined * __thiscall FUN_00a34850(undefined *param_1,undefined4 param_2)

{
  undefined auStack_1c [4];
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd403;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 1;
  puStack_18 = param_1 + 4;
  puStack_14 = param_1;
  FUN_008866d0();
  uStack_8 = 0;
  FUN_00a357a0(param_1 + 4,auStack_1c);
  FUN_0056e380();
  FUN_0056e380();
  uStack_8 = 1;
  FUN_008866a0(param_2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20306 ; VA 0x00a348d0 ; FUN_00a348d0 */

undefined4 * __fastcall FUN_00a348d0(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd428;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00b74410();
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::CoreScript,class_RBX::BaseScript>::vftable;
  uVar1 = FUN_00a34610();
  param_1[3] = uVar1;
  uStack_8 = 1;
  *param_1 = RBX::CoreScript::vftable;
  *(undefined *)(param_1 + 0x38) = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("CoreScript",10);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20307 ; VA 0x00a349a0 ; thunk_FUN_00b74880 */

void __fastcall thunk_FUN_00b74880(undefined4 *param_1)

{
  int iVar1;
  int *piVar2;
  
  *param_1 = RBX::BaseScript::vftable;
  FUN_016790b0();
  FUN_016790b0();
  piVar2 = (int *)param_1[0x35];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar1 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if ((iVar1 == 1) && (piVar2 != (int *)0x0)) {
      FUN_00d889a0();
      FUN_01674ea0(piVar2,8);
    }
  }
  FUN_009ec770();
  return;
}



/* FUNCTION 20308 ; VA 0x00a349b0 ; FUN_00a349b0 */

undefined4 __thiscall FUN_00a349b0(undefined4 param_1,byte param_2)

{
  FUN_00b74880();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xe0);
  }
  return param_1;
}



/* FUNCTION 20309 ; VA 0x00a349e0 ; FUN_00a349e0 */

undefined4 __thiscall FUN_00a349e0(undefined4 param_1,byte param_2)

{
  FUN_00b74880();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xe4);
  }
  return param_1;
}



/* FUNCTION 20310 ; VA 0x00a34a10 ; FUN_00a34a10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a34a10(undefined *param_1,undefined4 *param_2,undefined4 param_3,char param_4)

{
  uint uVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  byte *pbVar5;
  uint uVar6;
  byte *pbVar7;
  byte *pbVar8;
  int iVar9;
  bool bVar10;
  int iStack_a0;
  int iStack_7c;
  uint uStack_68;
  int iStack_64;
  uint uStack_50;
  int iStack_4c;
  int iStack_3c;
  uint uStack_38;
  char acStack_1c [4];
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd48c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01675290();
  uStack_8 = 0;
  cVar3 = FUN_00585a40();
  if ((cVar3 == '\0') || (cVar3 = FUN_00b74e80(), cVar3 != '\0')) {
    cVar3 = FUN_00554b40();
    if (cVar3 == '\0') {
      uStack_8._0_1_ = 9;
      iVar2 = iStack_18;
      if (param_4 != '\0') {
        param_3 = param_2;
        uVar1 = param_2[4];
        if (0xf < (uint)param_2[5]) {
          param_3 = (undefined4 *)*param_2;
        }
        if (6 < uVar1) {
          pbVar5 = (byte *)FUN_0170db20();
          iVar2 = iStack_18;
          while (pbVar5 != (byte *)0x0) {
            pbVar8 = &DAT_01941514;
            iVar9 = 3;
            pbVar7 = pbVar5;
            if (*(int *)pbVar5 == _DAT_01941514) {
              pbVar7 = pbVar5 + 4;
              pbVar8 = &DAT_01941518;
              iVar9 = -1;
            }
            bVar10 = *pbVar7 < *pbVar8;
            if ((((*pbVar7 == *pbVar8) && (bVar10 = pbVar7[1] < pbVar8[1], pbVar7[1] == pbVar8[1]))
                && (bVar10 = pbVar7[2] < pbVar8[2], pbVar7[2] == pbVar8[2])) &&
               ((iVar9 == -1 || (bVar10 = pbVar7[3] < pbVar8[3], pbVar7[3] == pbVar8[3])))) {
              uVar6 = 0;
            }
            else {
              uVar6 = -(uint)bVar10 | 1;
            }
            if (uVar6 == 0) {
              iStack_18 = (int)pbVar5 - (int)param_3;
              if (iStack_18 == 0) {
                uStack_14 = 0xf;
                if (uVar1 < 7) {
                  FUN_00554050();
                  goto LAB_00a34f2f;
                }
                FUN_005542c0();
                FUN_005511f0();
                FUN_005507b0();
                iVar2 = iStack_18;
              }
              break;
            }
            iStack_18 = iVar2;
            pbVar5 = (byte *)FUN_0170db20();
            iVar2 = iStack_18;
          }
        }
      }
      iStack_18 = iVar2;
      FUN_009edeb0();
      uStack_8._0_1_ = 10;
      if (iStack_3c == 0) {
        uStack_8._0_1_ = 9;
        *param_1 = 0;
        if (0xf < uStack_38) {
          if ((0xfff < uStack_38 + 1) && (0x1f < (iStack_4c - *(int *)(iStack_4c + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
          FUN_01674ea0();
        }
        if (0xf < uStack_50) {
          if ((0xfff < uStack_50 + 1) && (0x1f < (iStack_64 - *(int *)(iStack_64 + -4)) - 4U)) {
LAB_00a34f2f:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
          FUN_01674ea0();
        }
        if (0xf < uStack_68) {
          if ((0xfff < uStack_68 + 1) && (0x1f < (iStack_7c - *(int *)(iStack_7c + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
          FUN_01674ea0();
        }
        FUN_005507b0();
        uStack_8 = 0xb;
      }
      else {
        FUN_008869b0();
        uStack_8._0_1_ = 0xc;
        *param_1 = 0;
        FUN_008866a0();
        *param_1 = 1;
        FUN_0056e380();
        FUN_0056e380();
        uStack_8 = CONCAT31(uStack_8._1_3_,9);
        if (0xf < uStack_38) {
          if ((0xfff < uStack_38 + 1) && (0x1f < (iStack_4c - *(int *)(iStack_4c + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
          FUN_01674ea0();
        }
        if (0xf < uStack_50) {
          if ((0xfff < uStack_50 + 1) && (0x1f < (iStack_64 - *(int *)(iStack_64 + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
          FUN_01674ea0();
        }
        if (0xf < uStack_68) {
          if ((0xfff < uStack_68 + 1) && (0x1f < (iStack_7c - *(int *)(iStack_7c + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
          FUN_01674ea0();
        }
        FUN_005507b0();
        uStack_8 = 0xd;
      }
    }
    else {
      FUN_00a35300();
      uStack_8._0_1_ = 3;
      if (iStack_a0 == 0) {
        *param_1 = 0;
        FUN_005507b0();
        uStack_8 = 4;
      }
      else {
        uVar4 = FUN_0151a8d0();
        uStack_8._0_1_ = 5;
        FUN_0054f050(uVar4);
        FUN_00a34f50(acStack_1c);
        uStack_8 = CONCAT31(uStack_8._1_3_,7);
        FUN_00550800();
        *param_1 = 0;
        if (acStack_1c[0] != '\0') {
          FUN_008866a0();
          *param_1 = 1;
          if (acStack_1c[0] != '\0') {
            FUN_0056e380();
            FUN_0056e380();
            acStack_1c[0] = '\0';
          }
        }
        FUN_005507b0();
        uStack_8 = 8;
      }
    }
  }
  else {
    FUN_00b9f840();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    *param_1 = 0;
    if (acStack_1c[0] != '\0') {
      FUN_008866a0();
      *param_1 = 1;
      if (acStack_1c[0] != '\0') {
        FUN_0056e380();
        FUN_0056e380();
        acStack_1c[0] = '\0';
      }
    }
    uStack_8 = 2;
  }
  FUN_01675290();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20311 ; VA 0x00a34f50 ; FUN_00a34f50 */

undefined * FUN_00a34f50(undefined *param_1)

{
  int iVar1;
  int iVar2;
  undefined4 ***pppuVar3;
  undefined4 uVar4;
  undefined4 **appuStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  code *pcStack_20;
  int iStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dd4c0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0153ad30(&stack0x00000008);
  pcStack_20 = FUN_01718190;
  iStack_1c = iVar1;
  if (iVar1 == 0) {
    *param_1 = 0;
  }
  else {
    FUN_01718e22(iVar1,0,2);
    iVar2 = FUN_01726462(iVar1);
    FUN_01718e22(iVar1,0,0);
    if (iVar2 < 1) {
      *param_1 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
    }
    else {
      uStack_28 = 0;
      uStack_24 = 0xf;
      appuStack_38[0] = (undefined4 **)((uint)appuStack_38[0] & 0xffffff00);
      uStack_8._0_1_ = 4;
      if (iVar2 == 0) {
                    /* WARNING: Ignoring partial resolution of indirect */
        appuStack_38[0]._0_1_ = 0;
        uStack_28 = 0;
      }
      else {
        FUN_00578160(iVar2,0);
      }
      pppuVar3 = appuStack_38;
      if (0xf < uStack_24) {
        pppuVar3 = (undefined4 ***)appuStack_38[0];
      }
      FUN_017189e9(pppuVar3,1,iVar2,iVar1);
      uVar4 = FUN_00886c00(auStack_18,appuStack_38);
      uStack_8._0_1_ = 5;
      *param_1 = 0;
      FUN_008866a0(uVar4);
      *param_1 = 1;
      FUN_0056e380();
      FUN_0056e380();
      FUN_005507b0();
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
    }
    FUN_01718190(iVar1);
  }
  FUN_00550800();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20312 ; VA 0x00a35080 ; FUN_00a35080 */

uint * FUN_00a35080(uint *param_1,undefined4 param_2)

{
  int iVar1;
  undefined uVar2;
  int *piVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  uint auStack_68 [4];
  undefined4 uStack_58;
  uint uStack_54;
  uint uStack_50;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  undefined4 uStack_40;
  uint uStack_3c;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8._0_1_ = 0xff;
  uStack_8._1_3_ = 0xffffff;
  puStack_c = &LAB_017dd4e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_00b74d10();
  iVar7 = *piVar3;
  iVar1 = piVar3[1];
  do {
    if (iVar7 == iVar1) {
      param_1[4] = 0;
      param_1[5] = 0xf;
      *(undefined *)param_1 = 0;
      ExceptionList = pvStack_10;
      return param_1;
    }
    FUN_005f3cd0(&uStack_50,iVar7,param_2);
    uStack_8 = 0;
    uVar4 = FUN_0151a8d0(auStack_68,&uStack_50);
    uStack_8._0_1_ = 1;
    FUN_0054f050(uVar4);
    uStack_8._0_1_ = 3;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (7 < uStack_54) {
      uVar5 = uStack_54 * 2 + 2;
      uVar6 = auStack_68[0];
      if (0xfff < uVar5) {
        uVar6 = *(uint *)(auStack_68[0] - 4);
        uVar5 = uStack_54 * 2 + 0x25;
        if (0x1f < (auStack_68[0] - uVar6) - 4) goto LAB_00a352d2;
      }
      FUN_01674ea0(uVar6,uVar5);
    }
    uStack_58 = 0;
    auStack_68[0] = auStack_68[0] & 0xffff0000;
    uStack_54 = 7;
    piVar3 = (int *)FUN_0168e1c0(auStack_18,auStack_38,0);
    uVar5 = uStack_50;
    if ((*piVar3 != 0) && (*piVar3 != 1)) {
      uStack_50 = uStack_50 & 0xffffff00;
      param_1[4] = 0;
      param_1[5] = 0;
      *param_1 = uVar5;
      param_1[1] = uStack_4c;
      param_1[2] = uStack_48;
      param_1[3] = uStack_44;
      *(ulonglong *)(param_1 + 4) = CONCAT44(uStack_3c,uStack_40);
      uStack_40 = 0;
      uStack_3c = 0xf;
      if (7 < uStack_24) {
        uVar5 = uStack_24 * 2 + 2;
        uVar6 = auStack_38[0];
        if (0xfff < uVar5) {
          uVar6 = *(uint *)(auStack_38[0] - 4);
          uVar5 = uStack_24 * 2 + 0x25;
          uVar2 = (undefined)uStack_8;
          if (0x1f < (auStack_38[0] - uVar6) - 4) goto LAB_00a352d2;
        }
        FUN_01674ea0(uVar6,uVar5);
      }
      uStack_28 = 0;
      uStack_24 = 7;
      auStack_38[0] = auStack_38[0] & 0xffff0000;
      if (0xf < uStack_3c) {
        uVar5 = uStack_3c + 1;
        uVar6 = uStack_50;
        if (0xfff < uVar5) {
          uVar6 = *(uint *)(uStack_50 - 4);
          uVar5 = uStack_3c + 0x24;
          if (0x1f < (uStack_50 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar6,uVar5);
      }
      ExceptionList = pvStack_10;
      return param_1;
    }
    uStack_8._0_1_ = 0;
    if (7 < uStack_24) {
      uVar5 = uStack_24 * 2 + 2;
      uVar6 = auStack_38[0];
      if (0xfff < uVar5) {
        uVar6 = *(uint *)(auStack_38[0] - 4);
        uVar5 = uStack_24 * 2 + 0x25;
        uVar2 = (undefined)uStack_8;
        if (0x1f < (auStack_38[0] - uVar6) - 4) goto LAB_00a352d2;
      }
      FUN_01674ea0(uVar6,uVar5);
    }
    uStack_28 = 0;
    uStack_24 = 7;
    auStack_38[0] = auStack_38[0] & 0xffff0000;
    uStack_8._0_1_ = 0xff;
    uStack_8._1_3_ = 0xffffff;
    if (0xf < uStack_3c) {
      uVar6 = uStack_3c + 1;
      uVar5 = uStack_50;
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(uStack_50 - 4);
        uVar6 = uStack_3c + 0x24;
        uVar2 = (undefined)uStack_8;
        if (0x1f < (uStack_50 - uVar5) - 4) {
LAB_00a352d2:
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
    iVar7 = iVar7 + 0x18;
  } while( true );
}



/* FUNCTION 20313 ; VA 0x00a352e0 ; FUN_00a352e0 */

void FUN_00a352e0(void)

{
  int iVar1;
  
  if (DAT_01ee72ec == 0) {
    iVar1 = FUN_00a34610();
    DAT_01ee72ec = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 20314 ; VA 0x00a35300 ; FUN_00a35300 */

uint * FUN_00a35300(uint *param_1,undefined4 *param_2,char param_3)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int *piVar4;
  uint *puVar5;
  undefined4 ****ppppuVar6;
  undefined4 *puVar7;
  char *pcVar8;
  uint uVar9;
  char *pcVar10;
  uint uVar11;
  undefined auStack_c4 [24];
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined8 uStack_9c;
  undefined uStack_94;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 ***apppuStack_7c [4];
  int iStack_6c;
  uint uStack_68;
  int iStack_64;
  undefined4 uStack_60;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  undefined8 uStack_50;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  undefined8 uStack_20;
  undefined4 uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd578;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00554b40();
  if (cVar2 == '\0') {
    param_1[4] = 0;
    param_1[5] = 0xf;
    *(undefined *)param_1 = 0;
    ExceptionList = pvStack_10;
    return param_1;
  }
  uStack_50 = 0x700000000;
  uStack_60 = (undefined4 *)((uint)uStack_60._2_2_ << 0x10);
  uStack_8 = 0;
  if (param_2[4] != 0) {
    puVar7 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar7 = (undefined4 *)*param_2;
    }
    iStack_64 = param_2[4] + (int)puVar7;
    puVar7 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar7 = (undefined4 *)*param_2;
    }
    uVar3 = FUN_01686580();
    FUN_01685950(puVar7,iStack_64,&uStack_60,uVar3);
  }
  uStack_8 = 1;
  cStack_11 = FUN_0153d390(&uStack_60);
  uStack_8 = 0xffffffff;
  FUN_00550800();
  if (cStack_11 != '\0') {
    pcVar10 = "hidden";
    iStack_6c = 0;
    if (param_3 == '\0') {
      pcVar10 = "scripts/CoreScripts";
    }
    uStack_68 = 0xf;
    apppuStack_7c[0] = (undefined4 ***)((uint)apppuStack_7c[0] & 0xffffff00);
    pcVar8 = pcVar10;
    do {
      cVar2 = *pcVar8;
      pcVar8 = pcVar8 + 1;
    } while (cVar2 != '\0');
    FUN_005542c0(pcVar10,(int)pcVar8 - (int)(pcVar10 + 1));
    uStack_8 = 3;
    uStack_38 = 0;
    uStack_34 = 0xf;
    auStack_48[0] = auStack_48[0] & 0xffffff00;
    uStack_18 = 2;
    FUN_0058a190(param_2[4] + 1);
    FUN_00554150(&DAT_018c36fc,1);
    puVar7 = param_2 + 4;
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_00554150(param_2,*puVar7);
    piVar4 = (int *)FUN_00554150(&DAT_018bf1c0,4);
    uStack_60 = (undefined4 *)*piVar4;
    iStack_5c = piVar4[1];
    iStack_58 = piVar4[2];
    iStack_54 = piVar4[3];
    uStack_50 = *(undefined8 *)(piVar4 + 4);
    piVar4[4] = 0;
    piVar4[5] = 0xf;
    *(undefined *)piVar4 = 0;
    FUN_005507b0();
    uStack_20 = 0xf00000000;
    uStack_30 = uStack_30 & 0xffffff00;
    uStack_8._0_1_ = 6;
    cVar2 = FUN_00b74e80();
    iVar1 = iStack_6c;
    if (cVar2 == '\0') {
      uStack_8._0_1_ = 7;
      uStack_84 = 0;
      uStack_80 = 0xf;
      uStack_94 = 0;
      uStack_18 = 0xc;
      FUN_0058a190(iStack_6c + 0xb);
      FUN_00554150("rbxasset://",0xb);
      ppppuVar6 = apppuStack_7c;
      if (0xf < uStack_68) {
        ppppuVar6 = (undefined4 ****)apppuStack_7c[0];
      }
      FUN_00554150(ppppuVar6,iVar1);
      puVar7 = &uStack_60;
      if (0xf < uStack_50._4_4_) {
        puVar7 = uStack_60;
      }
      puVar7 = (undefined4 *)FUN_00554150(puVar7,(undefined4)uStack_50);
      uStack_18 = 0x1c;
      uStack_ac = *puVar7;
      uStack_a8 = puVar7[1];
      uStack_a4 = puVar7[2];
      uStack_a0 = puVar7[3];
      uStack_9c = *(undefined8 *)(puVar7 + 4);
      puVar7[4] = 0;
      puVar7[5] = 0xf;
      *(undefined *)puVar7 = 0;
      uStack_8._0_1_ = 8;
      FUN_0054ef60(&uStack_ac);
      uStack_8._0_1_ = 9;
      FUN_009cbbb0(auStack_48);
      uStack_8._0_1_ = 10;
      puVar5 = (uint *)FUN_008cb670(auStack_c4,auStack_48);
      if (&uStack_30 != puVar5) {
        FUN_005507b0();
        uStack_30 = *puVar5;
        uStack_2c = puVar5[1];
        uStack_28 = puVar5[2];
        uStack_24 = puVar5[3];
        uStack_20 = *(undefined8 *)(puVar5 + 4);
        puVar5[4] = 0;
        puVar5[5] = 0xf;
        *(undefined *)puVar5 = 0;
      }
      FUN_005507b0();
      if (0xf < uStack_34) {
        uVar11 = uStack_34 + 1;
        uVar9 = auStack_48[0];
        if (0xfff < uVar11) {
          uVar9 = *(uint *)(auStack_48[0] - 4);
          uVar11 = uStack_34 + 0x24;
          if (0x1f < (auStack_48[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar9,uVar11);
      }
      uStack_38 = 0;
      uStack_34 = 0xf;
      auStack_48[0] = auStack_48[0] & 0xffffff00;
      FUN_005507b0();
    }
    else {
      puVar5 = (uint *)FUN_00a35080(&uStack_ac,&uStack_60);
      if (&uStack_30 != puVar5) {
        FUN_005507b0();
        uStack_30 = *puVar5;
        uStack_2c = puVar5[1];
        uStack_28 = puVar5[2];
        uStack_24 = puVar5[3];
        uStack_20 = *(undefined8 *)(puVar5 + 4);
        puVar5[4] = 0;
        puVar5[5] = 0xf;
        *(undefined *)puVar5 = 0;
      }
    }
    FUN_005507b0();
    uVar9 = uStack_30;
    uStack_30 = uStack_30 & 0xffffff00;
    param_1[4] = 0;
    param_1[5] = 0;
    *param_1 = uVar9;
    param_1[1] = uStack_2c;
    param_1[2] = uStack_28;
    param_1[3] = uStack_24;
    *(undefined8 *)(param_1 + 4) = uStack_20;
    uStack_20 = 0xf00000000;
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return param_1;
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20315 ; VA 0x00a35710 ; FUN_00a35710 */

int FUN_00a35710(undefined4 param_1,int *param_2)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd590;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01674e20(0x18);
  uStack_8 = 0;
  *param_2 = iVar1;
  FUN_008866a0(param_1);
  *(undefined4 *)(iVar1 + 8) = 0;
  *(undefined4 *)(iVar1 + 0xc) = 0;
  ExceptionList = pvStack_10;
  return *param_2;
}



/* FUNCTION 20316 ; VA 0x00a35779 ; Catch_All@00a35779 */

void Catch_All_00a35779(void)

{
  int unaff_EBP;
  undefined4 uVar1;
  
  uVar1 = **(undefined4 **)(unaff_EBP + 0xc);
  FUN_005f1e60(uVar1);
  FUN_005f0c20(uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20317 ; VA 0x00a357a0 ; FUN_00a357a0 */

int * FUN_00a357a0(int *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_28 [8];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int aiStack_18 [2];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd5b0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005f1f00();
  FUN_008866a0(param_2);
  uVar3 = DAT_01ea94d0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_8 = 0;
  EnterCriticalSection(DAT_01ea94d0);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00a346f0(aiStack_18,auStack_28,uVar3);
  *param_1 = aiStack_18[0];
  LOCK();
  piVar1 = (int *)(aiStack_18[0] + 8);
  iVar2 = *piVar1;
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  if (iVar2 == 0) {
    *(int *)(*param_1 + 0xc) = *(int *)(*param_1 + 0xc) + 1;
  }
  LeaveCriticalSection(uVar3);
  FUN_0056e380();
  FUN_0056e380();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20318 ; VA 0x00a35860 ; FUN_00a35860 */

int * FUN_00a35860(int *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_28 [8];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int aiStack_18 [2];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd5d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005f1f00();
  FUN_008866a0(param_2);
  uStack_8 = 0;
  FUN_008866a0(aiStack_18);
  uStack_20 = 0;
  uStack_1c = 0;
  FUN_0056e380();
  FUN_0056e380();
  uVar3 = DAT_01ea94d0;
  EnterCriticalSection(DAT_01ea94d0);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00a346f0(aiStack_18,auStack_28,uVar3);
  *param_1 = aiStack_18[0];
  LOCK();
  piVar1 = (int *)(aiStack_18[0] + 8);
  iVar2 = *piVar1;
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  if (iVar2 == 0) {
    *(int *)(*param_1 + 0xc) = *(int *)(*param_1 + 0xc) + 1;
  }
  LeaveCriticalSection(uVar3);
  FUN_0056e380();
  FUN_0056e380();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20319 ; VA 0x00a35940 ; FUN_00a35940 */

void __thiscall FUN_00a35940(int param_1,undefined *param_2,undefined4 param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined *puStack_48;
  int *piStack_44;
  undefined auStack_34 [4];
  int *piStack_30;
  undefined auStack_2c [4];
  int *piStack_28;
  int iStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd5f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  if ((param_2 != (undefined *)0x0) && (ExceptionList = &pvStack_10, *(int *)(param_1 + 200) == 0))
  {
    piStack_44 = (int *)&LAB_0055d5a0;
    puStack_48 = &DAT_01ea8a80;
    ExceptionList = &pvStack_10;
    FUN_005789c0();
    piStack_44 = (int *)0xa35992;
    piStack_44 = (int *)FUN_00560dc0();
    puStack_48 = (undefined *)0xa3599a;
    piVar2 = (int *)FUN_008aa140();
    if (*piVar2 == 0) {
      piStack_44 = (int *)0xa359a9;
      piStack_44 = (int *)FUN_0093f210();
      puStack_48 = auStack_2c;
      piVar3 = (int *)FUN_008a9ba0();
      iVar1 = *piVar3;
      iVar5 = piVar3[1];
      *piVar3 = 0;
      piVar3[1] = 0;
      *piVar2 = iVar1;
      piVar3 = (int *)piVar2[1];
      piVar2[1] = iVar5;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar1 = piVar3[1] + -1;
        piVar3[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          piStack_44 = (int *)0xa359e2;
          (**(code **)*piVar3)();
          LOCK();
          iVar1 = piVar3[2] + -1;
          piVar3[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            piStack_44 = (int *)0xa359f2;
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_28[1] + -1;
        piStack_28[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          piStack_44 = (int *)0xa35a08;
          (**(code **)*piStack_28)();
          LOCK();
          iVar1 = piStack_28[2] + -1;
          piStack_28[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            piStack_44 = (int *)0xa35a18;
            (**(code **)(*piStack_28 + 4))();
          }
        }
      }
    }
    iStack_24 = *piVar2;
    if (*(char *)(iStack_24 + 0x290) == '\0') {
      piStack_44 = (int *)iStack_18;
      puStack_48 = auStack_34;
      puVar4 = (undefined4 *)FUN_0068f9a0();
      uStack_8 = 0;
      puStack_1c = (undefined *)0x0;
      piVar2 = (int *)0x0;
      iVar1 = puVar4[1];
      if (iVar1 != 0) {
        piVar3 = (int *)(iVar1 + 4);
        iVar1 = *(int *)(iVar1 + 4);
        while (iVar1 != 0) {
          LOCK();
          iVar5 = *piVar3;
          if (iVar1 == iVar5) {
            *piVar3 = iVar1 + 1;
            iVar5 = iVar1;
          }
          UNLOCK();
          if (iVar5 == iVar1) {
            piVar2 = (int *)puVar4[1];
            puStack_1c = (undefined *)*puVar4;
            if (piVar2 != (int *)0x0) {
              LOCK();
              piVar2[2] = piVar2[2] + 1;
              UNLOCK();
            }
            break;
          }
          iVar1 = *piVar3;
        }
      }
      puStack_48 = puStack_1c;
      piStack_44 = piVar2;
      puStack_20 = (undefined *)&puStack_48;
      puStack_14 = puVar4;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar1 = piVar2[1] + -1;
        piVar2[1] = iVar1;
        UNLOCK();
        puStack_20 = (undefined *)&puStack_48;
        if (iVar1 == 0) {
          puStack_20 = (undefined *)&puStack_48;
          (**(code **)*piVar2)();
          LOCK();
          iVar1 = piVar2[2] + -1;
          piVar2[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      *puVar4 = 0;
      piVar2 = (int *)puVar4[1];
      puVar4[1] = 0;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar1 = piVar2[2] + -1;
        piVar2[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
      FUN_00959050();
      uStack_8 = 0xffffffff;
      if (piStack_30 != (int *)0x0) {
        LOCK();
        piVar2 = piStack_30 + 2;
        iVar1 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          piStack_44 = (int *)0xa35afd;
          (**(code **)(*piStack_30 + 4))();
        }
      }
    }
  }
  piStack_44 = (int *)param_3;
  puStack_48 = param_2;
  FUN_00b74fa0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20320 ; VA 0x00a35b40 ; FUN_00a35b40 */

undefined * __thiscall FUN_00a35b40(int param_1,undefined *param_2)

{
  int iVar1;
  undefined4 uVar2;
  char acStack_24 [4];
  undefined auStack_20 [8];
  undefined auStack_18 [4];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd63e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_008f7870(param_1);
  if (iVar1 != 0) {
    FUN_00a34a10(acStack_24,*(undefined4 *)(param_1 + 0x28),iVar1,*(undefined *)(param_1 + 0xe0));
    uStack_8 = 0;
    if (acStack_24[0] != '\0') {
      if (DAT_01d67698 != '\0') {
        *param_2 = 1;
        puStack_14 = param_2 + 4;
        FUN_008866d0();
        uStack_8._0_1_ = 1;
        FUN_00a357a0(param_2 + 4,auStack_18);
        FUN_0056e380();
        FUN_0056e380();
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_008866a0(auStack_20);
        if (acStack_24[0] != '\0') {
          FUN_0056e380();
          FUN_0056e380();
        }
        ExceptionList = pvStack_10;
        return param_2;
      }
      FUN_00a35860(&puStack_14,auStack_20);
      *param_2 = 1;
      *(undefined **)(param_2 + 4) = puStack_14;
      LOCK();
      *(int *)(puStack_14 + 8) = *(int *)(puStack_14 + 8) + 1;
      UNLOCK();
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      FUN_008866d0();
      FUN_009465c0();
      if (acStack_24[0] != '\0') {
        FUN_0056e380();
        FUN_0056e380();
      }
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  FUN_005c8aa0();
  uVar2 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Error loading core script %s",uVar2);
}



/* FUNCTION 20321 ; VA 0x00a35ca0 ; FUN_00a35ca0 */

void __thiscall FUN_00a35ca0(int param_1,uint param_2)

{
  int ***pppiVar1;
  int ****ppppiVar2;
  int ****ppppiVar3;
  int iVar4;
  int iVar5;
  float fVar6;
  int *piVar7;
  uint uVar8;
  int iVar9;
  undefined4 uVar10;
  uint uVar11;
  int *****pppppiVar12;
  int *****pppppiVar13;
  int iVar14;
  undefined4 uStack_68;
  undefined4 uStack_60;
  int iStack_5c;
  int ****ppppiStack_40;
  int ***pppiStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined4 uStack_30;
  int ****ppppiStack_2c;
  int iStack_28;
  int iStack_24;
  uint uStack_20;
  uint uStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd668;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff8c;
  iVar14 = param_1 + -0xc;
  if (param_1 == 0) {
    iVar14 = -0xc;
  }
  piVar7 = (int *)(param_1 + -8);
  if (param_1 == 0) {
    piVar7 = (int *)&DAT_00000004;
  }
  if (*piVar7 == 0) {
    pppppiVar13 = (int *****)0x0;
  }
  else {
    pppppiVar13 = (int *****)(*piVar7 + 0x10);
  }
  ExceptionList = &pvStack_10;
  ppppiStack_2c = (int ****)pppppiVar13;
  iStack_18 = param_1;
  FUN_005ef390((int)&param_2 + 3,&ppppiStack_40,param_2);
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  if (param_1 == 0) {
    iVar14 = 0;
  }
  uStack_38 = *(uint *)(iVar14 + 0x28);
  if (uStack_38 != 0) {
    uVar11 = uStack_38 * 4;
    if (uStack_38 < 0x40000000) {
      if (0xfff < uVar11) goto LAB_00a35d3b;
      if (uVar11 == 0) {
        uStack_20 = 0;
      }
      else {
        uStack_20 = FUN_01674e20(uVar11);
      }
    }
    else {
      uVar11 = 0xffffffff;
LAB_00a35d3b:
      uVar8 = uVar11 + 0x23;
      if (uVar8 <= uVar11) {
        uVar8 = 0xffffffff;
      }
      iVar9 = FUN_01674e20(uVar8);
      if (iVar9 == 0) goto LAB_00a3608e;
      uStack_20 = iVar9 + 0x23U & 0xffffffe0;
      *(int *)(uStack_20 - 4) = iVar9;
    }
    uStack_34 = *(uint *)(iVar14 + 0x28);
    uStack_8._0_1_ = 1;
    if (uStack_34 == 0) {
      uStack_1c = 0;
      iStack_24 = 0;
    }
    else {
      uVar11 = uStack_34 * 4;
      if (uStack_34 < 0x40000000) {
        if (uVar11 < 0x1000) {
          if (uVar11 == 0) {
            iStack_24 = *(int *)(iVar14 + 0x28);
            uStack_1c = 0;
          }
          else {
            uStack_1c = FUN_01674e20(uVar11);
            iStack_24 = *(int *)(iVar14 + 0x28);
          }
          goto LAB_00a35ded;
        }
      }
      else {
        uVar11 = 0xffffffff;
      }
      uVar8 = uVar11 + 0x23;
      if (uVar8 <= uVar11) {
        uVar8 = 0xffffffff;
      }
      iVar9 = FUN_01674e20(uVar8);
      if (iVar9 == 0) goto LAB_00a3608e;
      uStack_1c = iVar9 + 0x23U & 0xffffffe0;
      *(int *)(uStack_1c - 4) = iVar9;
      iStack_24 = *(int *)(iVar14 + 0x28);
    }
LAB_00a35ded:
    iVar14 = 0;
    param_2 = param_2 & 0xffffff;
    uStack_8._0_1_ = 3;
    while (iStack_28 = iVar14, iVar14 != iStack_24) {
      pppppiVar12 = (int *****)*pppppiVar13;
      uStack_30 = FUN_00886e30(-(uint)(pppppiVar12 != (int *****)0x0) & (uint)(pppppiVar12 + -4));
      *(undefined4 *)(uStack_20 + iVar14 * 4) = uStack_30;
      *(int ******)(uStack_1c + iVar14 * 4) = pppppiVar12;
      ppppiVar2 = *pppppiVar13;
      ppppiVar3 = (int ****)(*ppppiVar2)[1];
      if (ppppiVar3 != ppppiVar2) {
        *ppppiVar3 = (int ***)0x0;
        (*ppppiVar2)[1] = (int **)ppppiVar2[1];
        *pppppiVar13 = (int ****)*ppppiVar2;
      }
      else {
        (*ppppiVar2)[1] = (int **)ppppiVar2[1];
        *pppppiVar13 = (int ****)*ppppiVar2;
      }
      param_2 = CONCAT13(ppppiVar3 == ppppiVar2,(undefined3)param_2);
      iVar9 = FUN_008a4250(uStack_30,uStack_68);
      pppiVar1 = (int ***)(iStack_5c + iVar9 * 4);
      if (*pppiVar1 == (int **)0x0) {
        iVar14 = iVar14 + 1;
        *pppppiVar12 = ppppiStack_40;
        pppppiVar12[1] = (int ****)ppppiStack_40[1];
        (*pppppiVar12)[1] = pppiVar1;
        *pppiVar1 = (int **)pppppiVar12;
        ppppiStack_40 = (int ****)pppppiVar12;
      }
      else {
        iVar14 = iVar14 + 1;
        *pppppiVar12 = (int ****)**pppiVar1;
        pppppiVar12[1] = (int ****)*pppiVar1;
        *pppiVar1 = (int **)pppppiVar12;
        *pppppiVar12[1] = (int ***)pppppiVar12;
      }
    }
    if (uStack_34 != 0) {
      uVar11 = uStack_34 * 4;
      uVar8 = uStack_1c;
      if (0xfff < uVar11) {
        uVar8 = *(uint *)(uStack_1c - 4);
        uVar11 = uVar11 + 0x23;
        if (0x1f < (uStack_1c - uVar8) - 4) goto LAB_00a3608e;
      }
      FUN_01674ea0(uVar8,uVar11);
    }
    param_1 = iStack_18;
    if (uStack_38 != 0) {
      uVar8 = uStack_38 * 4;
      uVar11 = uStack_20;
      if (0xfff < uVar8) {
        uVar11 = *(uint *)(uStack_20 - 4);
        uVar8 = uVar8 + 0x23;
        if (0x1f < (uStack_20 - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar8);
      param_1 = iStack_18;
    }
  }
  iVar14 = iStack_18;
  fVar6 = DAT_018c0d80;
  pppppiVar12 = pppppiVar13;
  if ((int *****)ppppiStack_40 != &ppppiStack_40) {
    pppppiVar12 = (int *****)ppppiStack_40;
  }
  *pppppiVar13 = (int ****)pppppiVar12;
  pppppiVar13[1] = (int ****)pppiStack_3c;
  **pppiStack_3c = (int *)pppppiVar13;
  *(*pppppiVar13)[1] = (int **)pppppiVar13;
  *(undefined4 *)(param_1 + 4) = uStack_68;
  iVar9 = *(int *)(param_1 + 0xc);
  *(undefined4 *)(param_1 + 0xc) = uStack_60;
  iVar4 = *(int *)(param_1 + 0x10);
  *(int *)(iStack_18 + 0x10) = iStack_5c;
  iVar5 = *(int *)(&DAT_018be080 + *(int *)(iStack_18 + 4) * 4);
  *(undefined4 *)(iStack_18 + 0x18) = 0xffffffff;
  if ((float)((double)iVar5 + (double)(&DAT_018c0d90)[-(iVar5 >> 0x1f)]) *
      *(float *)(iStack_18 + 0x14) < fVar6) {
    uVar10 = FUN_016f3cd0();
    *(undefined4 *)(iVar14 + 0x18) = uVar10;
  }
  if (iVar9 != 0) {
    uVar11 = iVar9 * 4;
    iVar14 = iVar4;
    if (0xfff < uVar11) {
      iVar14 = *(int *)(iVar4 + -4);
      uVar11 = uVar11 + 0x23;
      if (0x1f < (iVar4 - iVar14) - 4U) {
LAB_00a3608e:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar14,uVar11);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20322 ; VA 0x00a35eb6 ; Catch_All@00a35eb6 */

void Catch_All_00a35eb6(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int unaff_EBP;
  int iVar8;
  
  iVar8 = *(int *)(unaff_EBP + -0x24);
  if (iVar8 != 0) {
    iVar5 = *(int *)(unaff_EBP + -0x14);
    uVar4 = FUN_008a4250(*(undefined4 *)(*(int *)(unaff_EBP + -0x40) + -4 + iVar8 * 4),
                         *(undefined4 *)(iVar5 + 4));
    *(uint *)(unaff_EBP + -0x1c) = uVar4;
    if (*(char *)(unaff_EBP + 0xb) == '\0') {
      *(uint *)(unaff_EBP + -0x1c) = ~uVar4;
    }
    piVar1 = *(int **)(unaff_EBP + -0x28);
    iVar7 = *(int *)(unaff_EBP + -0x40) - *(int *)(unaff_EBP + -0x4c);
    *(int *)(unaff_EBP + -0x2c) = iVar7;
    iVar6 = *(int *)(unaff_EBP + -0x4c) + iVar8 * 4;
    do {
      uVar2 = *(undefined4 *)(iVar5 + 4);
      iVar8 = iVar8 + -1;
      *(int *)(unaff_EBP + 8) = iVar6 + -4;
      iVar5 = FUN_008a4250(*(undefined4 *)(iVar7 + iVar6 + -4),uVar2);
      piVar3 = (int *)**(undefined4 **)(unaff_EBP + 8);
      if (iVar5 == *(int *)(unaff_EBP + -0x1c)) {
        *piVar3 = *piVar1;
        piVar3[1] = *(int *)(*piVar1 + 4);
        *(int **)(*piVar3 + 4) = piVar3;
        *piVar1 = (int)piVar3;
      }
      else {
        FUN_008a37e0(piVar3,*(int *)(*(int *)(unaff_EBP + -0x14) + 0x10) + iVar5 * 4,piVar1);
      }
      iVar6 = *(int *)(unaff_EBP + 8);
      iVar7 = *(int *)(unaff_EBP + -0x2c);
      *(int *)(unaff_EBP + -0x1c) = iVar5;
      iVar5 = *(int *)(unaff_EBP + -0x14);
    } while (iVar8 != 0);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20323 ; VA 0x00a360a0 ; FUN_00a360a0 */

undefined4 * __thiscall
FUN_00a360a0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined param_4,int param_5
            ,int *param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  undefined8 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dd690;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_6 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_5 == 0) {
    iVar2 = 0;
  }
  else {
    iVar2 = param_5 + 8;
  }
  FUN_01522c10(param_2,iVar2,param_6,param_7);
  param_1[0x3e] = param_3;
  *(undefined *)(param_1 + 0x42) = param_4;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = RBX::DataModelJob::vftable;
  *(undefined8 *)(param_1 + 0x40) = 0;
  param_1[0x44] = 0;
  param_1[0x45] = 0;
  *(undefined *)(param_1 + 0x46) = 0;
  param_1[0x47] = param_5;
  *(undefined *)(param_1 + 0x48) = 0;
  uVar3 = FUN_0152dab0(&DAT_018e1178,param_2,0xffffffff);
  *(undefined8 *)(param_1 + 0x44) = uVar3;
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20324 ; VA 0x00a361c0 ; FUN_00a361c0 */

undefined4 __thiscall FUN_00a361c0(undefined4 param_1,byte param_2)

{
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x128);
  }
  return param_1;
}



/* FUNCTION 20325 ; VA 0x00a361f0 ; FUN_00a361f0 */

void __fastcall FUN_00a361f0(int param_1)

{
  if ((DAT_01d7ad40 != '\0') && (*(char *)(param_1 + 0x120) == '\0')) {
    *(undefined *)(param_1 + 0x120) = 1;
    FUN_01532a30(*(undefined4 *)(param_1 + 0x110),*(undefined4 *)(param_1 + 0x114));
  }
  return;
}



/* FUNCTION 20326 ; VA 0x00a36220 ; FUN_00a36220 */

undefined4 __thiscall FUN_00a36220(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  bool bVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd6a8;
  pvStack_10 = ExceptionList;
  if ((*(char *)(param_1 + 0x46) == '\0') && (*(char *)(param_1[0x47] + 0x2fc) != '\0')) {
    return 1;
  }
  if ((DAT_01d7ad40 == '\0') || (*(char *)(param_1 + 0x48) == '\0')) {
    bVar3 = false;
  }
  else {
    bVar3 = true;
  }
  iVar1 = param_1[0x45];
  iVar2 = param_1[0x44];
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01532c80(iVar2,iVar1);
  uStack_8 = 0;
  uVar4 = (**(code **)(*param_1 + 0x10))(param_2);
  uStack_8 = 1;
  FUN_0152dda0(iVar2,iVar1,uVar5);
  if ((bVar3) && (DAT_01d7ad40 != '\0')) {
    FUN_01532d10(iVar2,iVar1,uVar5);
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 20327 ; VA 0x00a36320 ; FUN_00a36320 */

float10 __thiscall
FUN_00a36320(int param_1,undefined4 param_2,undefined4 param_3,double param_4,float param_5,
            float param_6)

{
  float10 fVar1;
  float fVar2;
  
  fVar2 = (float)((double)CONCAT44(param_3,param_2) * param_4 + *(double *)(param_1 + 0x100));
  fVar1 = (float10)FUN_01725280((double)fVar2);
  if ((float)fVar1 <= param_5) {
    param_5 = (float)fVar1;
  }
  fVar2 = fVar2 - param_5;
  if (fVar2 <= param_6) {
    param_6 = fVar2;
  }
  *(double *)(param_1 + 0x100) = (double)param_6;
  if (param_5 <= 0.0) {
    return (float10)0;
  }
  return (float10)param_5;
}



/* FUNCTION 20328 ; VA 0x00a363b0 ; FUN_00a363b0 */

int * __thiscall
FUN_00a363b0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baf8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00a36d80();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::LocalizationService,bool>::
              GetSetImpl<bool_(__thiscall_RBX::LocalizationService::*)(void)const_,void_(__thiscall_RBX::LocalizationService::*)(bool)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::LocalizationService,bool>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::LocalizationService,bool>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20329 ; VA 0x00a364b0 ; FUN_00a364b0 */

undefined4 * __thiscall
FUN_00a364b0(undefined4 *param_1,undefined4 param_2,int param_3,undefined param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7,undefined param_8)

{
  bool bVar1;
  char cVar2;
  undefined4 uVar3;
  undefined **ppuVar4;
  undefined auStack_f4 [56];
  undefined4 uStack_bc;
  int iStack_b8;
  undefined uStack_b4;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined uStack_a4;
  undefined4 uStack_84;
  int iStack_80;
  undefined uStack_7c;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined uStack_6c;
  undefined auStack_68 [28];
  undefined4 uStack_4c;
  int iStack_48;
  undefined uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined uStack_34;
  undefined auStack_30 [28];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017dd715;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_84;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 8) = *(int *)(param_3 + 8) + 1;
    UNLOCK();
  }
  uStack_84 = param_2;
  iStack_80 = param_3;
  uStack_7c = param_4;
  uStack_74 = param_6;
  uStack_70 = param_7;
  uStack_6c = param_8;
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_0054ef60(&stack0x00000020);
  puStack_14 = &uStack_4c;
  if (iStack_80 != 0) {
    LOCK();
    *(int *)(iStack_80 + 8) = *(int *)(iStack_80 + 8) + 1;
    UNLOCK();
  }
  uStack_4c = uStack_84;
  iStack_48 = iStack_80;
  uStack_44 = uStack_7c;
  uStack_3c = uStack_74;
  uStack_38 = uStack_70;
  uStack_34 = uStack_6c;
  uStack_8 = 3;
  FUN_0054ef60(auStack_68);
  puStack_14 = &uStack_bc;
  if (iStack_48 != 0) {
    LOCK();
    *(int *)(iStack_48 + 8) = *(int *)(iStack_48 + 8) + 1;
    UNLOCK();
  }
  uStack_bc = uStack_4c;
  iStack_b8 = iStack_48;
  uStack_b4 = uStack_44;
  uStack_ac = uStack_3c;
  uStack_a8 = uStack_38;
  uStack_a4 = uStack_34;
  uStack_8 = 5;
  FUN_0054ef60(auStack_30);
  uStack_8 = 6;
  cVar2 = FUN_00585a40(&uStack_bc);
  if (cVar2 == '\0') {
    FUN_00a3a820(&uStack_bc);
    uStack_8 = 7;
    puStack_14 = (undefined4 *)FUN_01674e20(0x38);
    uStack_8 = 8;
    if (puStack_14 == (undefined4 *)0x0) {
      uVar3 = 0;
    }
    else {
      uVar3 = FUN_00a3a820(auStack_f4);
    }
    param_1[2] = uVar3;
    FUN_00a3bb40();
    FUN_00a3bb40();
    bVar1 = true;
  }
  else {
    FUN_00a3bb40();
    bVar1 = false;
  }
  FUN_00a3bb40();
  ppuVar4 = &PTR_FUN_01942fe8;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_00a3bb40();
  FUN_00a3bb40();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20330 ; VA 0x00a366b0 ; FUN_00a366b0 */

undefined4 * __thiscall FUN_00a366b0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01943000;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 20331 ; VA 0x00a367e0 ; FUN_00a367e0 */

undefined4 * __thiscall FUN_00a367e0(undefined4 *param_1,undefined4 param_2,int param_3)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined4 uStack_94;
  int iStack_90;
  undefined auStack_8c [24];
  undefined4 uStack_74;
  int iStack_70;
  undefined auStack_6c [24];
  undefined4 uStack_54;
  int iStack_50;
  undefined auStack_4c [24];
  undefined4 uStack_34;
  int iStack_30;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017dd782;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_94;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 8) = *(int *)(param_3 + 8) + 1;
    UNLOCK();
  }
  uStack_94 = param_2;
  iStack_90 = param_3;
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_0054ef60(&stack0x0000000c);
  puStack_14 = &uStack_74;
  if (iStack_90 != 0) {
    LOCK();
    *(int *)(iStack_90 + 8) = *(int *)(iStack_90 + 8) + 1;
    UNLOCK();
  }
  uStack_74 = uStack_94;
  iStack_70 = iStack_90;
  uStack_8 = 3;
  FUN_0054ef60(auStack_8c);
  puStack_14 = &uStack_34;
  if (iStack_70 != 0) {
    LOCK();
    *(int *)(iStack_70 + 8) = *(int *)(iStack_70 + 8) + 1;
    UNLOCK();
  }
  uStack_34 = uStack_74;
  iStack_30 = iStack_70;
  uStack_8 = 5;
  FUN_0054ef60(auStack_6c);
  uStack_8 = 6;
  cVar2 = FUN_00585a40(&uStack_34);
  if (cVar2 == '\0') {
    puStack_14 = &uStack_54;
    if (iStack_30 != 0) {
      LOCK();
      *(int *)(iStack_30 + 8) = *(int *)(iStack_30 + 8) + 1;
      UNLOCK();
    }
    uStack_54 = uStack_34;
    iStack_50 = iStack_30;
    uStack_8 = 7;
    FUN_0054ef60(auStack_2c);
    uStack_8 = 8;
    puVar3 = (undefined4 *)FUN_01674e20(0x20);
    uStack_8 = 9;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = 0;
      puVar3[1] = 0;
      if (iStack_50 != 0) {
        LOCK();
        *(int *)(iStack_50 + 8) = *(int *)(iStack_50 + 8) + 1;
        UNLOCK();
      }
      *puVar3 = uStack_54;
      puVar3[1] = iStack_50;
      uStack_8 = 10;
      FUN_0054ef60(auStack_4c);
    }
    param_1[2] = puVar3;
    FUN_005d11a0();
    FUN_005d11a0();
    bVar1 = true;
  }
  else {
    FUN_005d11a0();
    bVar1 = false;
  }
  FUN_005d11a0();
  ppuVar4 = &PTR_FUN_01942f7c;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_005d11a0();
  FUN_005d11a0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20332 ; VA 0x00a369f0 ; FUN_00a369f0 */

undefined4 * __thiscall
FUN_00a369f0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined4 in_stack_00000028;
  undefined4 uStack_68;
  int iStack_64;
  undefined4 uStack_4c;
  undefined *puStack_48;
  undefined4 uStack_38;
  int iStack_34;
  undefined auStack_30 [24];
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017dd7b0;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_38;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_4 + 8) = *(int *)(param_4 + 8) + 1;
    UNLOCK();
  }
  uStack_38 = param_3;
  iStack_34 = param_4;
  puStack_48 = &stack0x00000010;
  uStack_8 = 1;
  uStack_7 = 0;
  uStack_4c = 0xa36a5a;
  FUN_0054ef60();
  uStack_18 = in_stack_00000028;
  *param_1 = 0;
  puStack_14 = &uStack_68;
  if (iStack_34 != 0) {
    LOCK();
    *(int *)(iStack_34 + 8) = *(int *)(iStack_34 + 8) + 1;
    UNLOCK();
  }
  uStack_68 = uStack_38;
  iStack_64 = iStack_34;
  uStack_8 = 3;
  FUN_0054ef60(auStack_30);
  _uStack_8 = CONCAT31(uStack_7,2);
  puStack_48 = (undefined *)uStack_18;
  FUN_00a39340();
  puStack_48 = (undefined *)0xa36ac5;
  FUN_005d11a0();
  puStack_48 = (undefined *)0xa36acd;
  FUN_005d11a0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20333 ; VA 0x00a36af0 ; FUN_00a36af0 */

undefined4 * __thiscall
FUN_00a36af0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dd7d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_01943008;
  cVar3 = FUN_00a39540(param_2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_5 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20334 ; VA 0x00a36c20 ; FUN_00a36c20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00a36c20(undefined4 *param_1,undefined4 *param_2)

{
  undefined *puVar1;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee7884) {
    FUN_016f3809(&DAT_01ee7884);
    if (DAT_01ee7884 == -1) {
      _DAT_01ee7878 = FUN_005c65e0;
      _DAT_01ee787c = FUN_005c65e0;
      _DAT_01ee7880 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee7884);
    }
  }
  puVar1 = (undefined *)*param_1;
  if (puVar1 == &DAT_01ee7878) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = &DAT_01ee7878;
  return param_1;
}



/* FUNCTION 20335 ; VA 0x00a36cd0 ; FUN_00a36cd0 */

undefined * FUN_00a36cd0(undefined *param_1,undefined4 *param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792429;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  uStack_8 = 0;
  FUN_0058a190(param_2[4] + 1);
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_00554150(param_2,*puVar1);
  FUN_00592760(param_3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20336 ; VA 0x00a36d60 ; thunk_FUN_00fd0780 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00fd0780(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0184e670;
  pvStack_10 = ExceptionList;
  if (DAT_01f2e01c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f2e230) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f2e230);
      if (DAT_01f2e230 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"LocalizationTable",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01f2e228 = RBX::Creator<class_RBX::LocalizationTable>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01f2e020,&DAT_01f2e228);
        FUN_016f3654(FUN_018ab0a0);
        FUN_016f37bf(&DAT_01f2e230);
      }
    }
    DAT_01f2e01c = &DAT_01f2e020;
  }
  ExceptionList = pvStack_10;
  return DAT_01f2e01c;
}



/* FUNCTION 20337 ; VA 0x00a36d80 ; FUN_00a36d80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a36d80(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd810;
  pvStack_10 = ExceptionList;
  if (DAT_01ee73d4 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee75e8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee75e8);
      if (DAT_01ee75e8 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"LocalizationService",1,uStack_20,0,0,9,0,0);
        _DAT_01ee75e0 = RBX::Creator<class_RBX::LocalizationService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ee73d8,&DAT_01ee75e0);
        FUN_016f3654(FUN_01889cb0);
        FUN_016f37bf(&DAT_01ee75e8);
      }
    }
    DAT_01ee73d4 = &DAT_01ee73d8;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee73d4;
}



/* FUNCTION 20338 ; VA 0x00a36e80 ; FUN_00a36e80 */

undefined * FUN_00a36e80(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd82c;
  pvStack_10 = ExceptionList;
  if (DAT_01ee75f8 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee7808) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee7808);
      if (DAT_01ee7808 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Translator",0,uStack_20,0,0,1,0,0);
        FUN_016f3654(&LAB_01889d10);
        FUN_016f37bf(&DAT_01ee7808);
      }
    }
    DAT_01ee75f8 = &DAT_01ee7600;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee75f8;
}



/* FUNCTION 20339 ; VA 0x00a36f60 ; FUN_00a36f60 */

void FUN_00a36f60(void)

{
  int iVar1;
  
  if (DAT_01ee75ec == 0) {
    iVar1 = FUN_00a36d80();
    DAT_01ee75ec = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 20340 ; VA 0x00a36f80 ; FUN_00a36f80 */

int FUN_00a36f80(undefined4 param_1,undefined4 param_2,int param_3)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd848;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_006a8fb0(param_1,param_2);
  uStack_8 = 0;
  FUN_0054ef60(param_3);
  *(undefined4 *)(iVar5 + 0x20) = 0;
  uVar1 = *(uint *)(param_3 + 0x18);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (uVar1 != 0) {
    *(uint *)(iVar5 + 0x20) = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_3 + 0x20,iVar5 + 0x28,0);
    }
    else {
      uVar2 = *(undefined4 *)(param_3 + 0x24);
      uVar3 = *(undefined4 *)(param_3 + 0x28);
      uVar4 = *(undefined4 *)(param_3 + 0x2c);
      *(undefined4 *)(iVar5 + 0x28) = *(undefined4 *)(param_3 + 0x20);
      *(undefined4 *)(iVar5 + 0x2c) = uVar2;
      *(undefined4 *)(iVar5 + 0x30) = uVar3;
      *(undefined4 *)(iVar5 + 0x34) = uVar4;
      *(undefined8 *)(iVar5 + 0x38) = *(undefined8 *)(param_3 + 0x30);
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 20341 ; VA 0x00a37022 ; Catch_All@00a37022 */

void Catch_All_00a37022(void)

{
  int unaff_EBP;
  
  FUN_0089eda0(*(undefined4 *)(unaff_EBP + 0xc),1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20342 ; VA 0x00a37040 ; FUN_00a37040 */

void FUN_00a37040(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar4 = FUN_00970740(param_1,param_2);
  param_4 = (undefined4 *)*param_4;
  *(undefined4 *)(iVar4 + 0x18) = 0;
  *(undefined4 *)(iVar4 + 0x1c) = 0;
  uVar1 = param_4[1];
  uVar2 = param_4[2];
  uVar3 = param_4[3];
  *(undefined4 *)(iVar4 + 8) = *param_4;
  *(undefined4 *)(iVar4 + 0xc) = uVar1;
  *(undefined4 *)(iVar4 + 0x10) = uVar2;
  *(undefined4 *)(iVar4 + 0x14) = uVar3;
  *(undefined8 *)(iVar4 + 0x18) = *(undefined8 *)(param_4 + 4);
  param_4[4] = 0;
  param_4[5] = 0xf;
  *(undefined *)param_4 = 0;
  *(undefined4 *)(iVar4 + 0x30) = 0;
  *(undefined4 *)(iVar4 + 0x34) = 0xf;
  *(undefined *)(iVar4 + 0x20) = 0;
  return;
}



/* FUNCTION 20343 ; VA 0x00a370a0 ; FUN_00a370a0 */

int FUN_00a370a0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd860;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00970740(param_1,param_2);
  uStack_8 = 0;
  FUN_0054ef60(*param_4);
  *(undefined4 *)(iVar1 + 0x30) = 0;
  *(undefined4 *)(iVar1 + 0x34) = 0xf;
  *(undefined *)(iVar1 + 0x20) = 0;
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 20344 ; VA 0x00a3710f ; Catch_All@00a3710f */

void Catch_All_00a3710f(void)

{
  int unaff_EBP;
  
  FUN_00875970(*(undefined4 *)(unaff_EBP + 0xc),1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20345 ; VA 0x00a37130 ; FUN_00a37130 */

void FUN_00a37130(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if (param_1 != param_2) {
    piVar3 = param_1 + 1;
    do {
      FUN_00651cc0();
      piVar1 = (int *)*piVar3;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      piVar1 = piVar3 + 0x11;
      piVar3 = piVar3 + 0x12;
    } while (piVar1 != param_2);
  }
  return;
}



/* FUNCTION 20346 ; VA 0x00a37190 ; FUN_00a37190 */

int __thiscall FUN_00a37190(uint *param_1,uint param_2,undefined4 param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  
  uVar1 = *param_1;
  iVar2 = (int)(param_1[1] - uVar1) / 0x48;
  if (iVar2 == 0x38e38e3) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar6 = iVar2 + 1;
  uVar3 = (int)(param_1[2] - uVar1) / 0x48;
  uVar8 = uVar6;
  if ((uVar3 <= 0x38e38e3 - (uVar3 >> 1)) && (uVar8 = (uVar3 >> 1) + uVar3, uVar8 < uVar6)) {
    uVar8 = uVar6;
  }
  uVar6 = uVar8 * 0x48;
  if (uVar8 < 0x38e38e4) {
    uVar8 = uVar6;
    if (0xfff < uVar6) goto LAB_00a3722b;
    if (uVar6 == 0) {
      uVar8 = 0;
    }
    else {
      uVar8 = FUN_01674e20(uVar6);
    }
  }
  else {
    uVar8 = 0xffffffff;
LAB_00a3722b:
    uVar3 = uVar8 + 0x23;
    if (uVar3 <= uVar8) {
      uVar3 = 0xffffffff;
    }
    iVar4 = FUN_01674e20(uVar3);
    if (iVar4 == 0) goto LAB_00a37360;
    uVar8 = iVar4 + 0x23U & 0xffffffe0;
    *(int *)(uVar8 - 4) = iVar4;
  }
  iVar4 = ((int)(param_2 - uVar1) / 0x48) * 0x48;
  iVar5 = iVar4 + uVar8;
  FUN_00a39cf0(param_1,iVar5,param_3);
  uVar1 = param_1[1];
  uVar3 = *param_1;
  uVar7 = uVar8;
  if (param_2 == uVar1) {
    for (; uVar3 != uVar1; uVar3 = uVar3 + 0x48) {
      FUN_00a39cf0(param_1,uVar7,uVar3);
      uVar7 = uVar7 + 0x48;
    }
    FUN_00a37130(uVar7,uVar7,param_1);
  }
  else {
    FUN_00a3e0d0(uVar3,param_2,uVar8);
    FUN_00a3e0d0(param_2,param_1[1],iVar5 + 0x48);
  }
  if (*param_1 != 0) {
    FUN_00a37130(*param_1,param_1[1],param_1);
    uVar1 = *param_1;
    uVar7 = ((int)(param_1[2] - uVar1) / 0x48) * 0x48;
    uVar3 = uVar1;
    if (0xfff < uVar7) {
      uVar3 = *(uint *)(uVar1 - 4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (uVar1 - uVar3) - 4) {
LAB_00a37360:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar7);
  }
  *param_1 = uVar8;
  param_1[1] = uVar8 + (iVar2 * 9 + 9) * 8;
  param_1[2] = uVar6 + uVar8;
  return *param_1 + iVar4;
}



/* FUNCTION 20347 ; VA 0x00a37370 ; FUN_00a37370 */

int __thiscall FUN_00a37370(uint *param_1,uint param_2,int param_3)

{
  uint uVar1;
  undefined4 *puVar2;
  uint3 uVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = -1;
  puStack_c = &LAB_017dd880;
  pvStack_10 = ExceptionList;
  uVar9 = *param_1;
  iVar6 = (int)(param_1[1] - *param_1) / 0x50;
  if (iVar6 == 0x3333333) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar6 + 1;
  uVar7 = (int)(param_1[2] - *param_1) / 0x50;
  uVar4 = uVar1;
  if ((uVar7 <= 0x3333333 - (uVar7 >> 1)) && (uVar4 = (uVar7 >> 1) + uVar7, uVar4 < uVar1)) {
    uVar4 = uVar1;
  }
  uVar7 = uVar4 * 0x50;
  if (uVar4 < 0x3333334) {
    if (0xfff < uVar7) goto LAB_00a37427;
    if (uVar7 == 0) {
      uVar7 = 0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      uVar7 = FUN_01674e20(uVar7);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_00a37427:
    uVar5 = uVar7 + 0x23;
    if (uVar5 <= uVar7) {
      uVar5 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar6 = FUN_01674e20(uVar5);
    if (iVar6 == 0) goto LAB_00a37602;
    uVar7 = iVar6 + 0x23U & 0xffffffe0;
    *(int *)(uVar7 - 4) = iVar6;
  }
  iVar6 = ((int)(param_2 - uVar9) / 0x50) * 0x50;
  puVar2 = (undefined4 *)(iVar6 + uVar7);
  iStack_8 = 0;
  *puVar2 = 0;
  FUN_005880d0(param_3);
  iStack_8._0_1_ = 1;
  puVar2[8] = 0;
  FUN_005880d0(param_3 + 0x20);
  uVar3 = iStack_8._1_3_;
  puVar2[0x10] = 0;
  puVar2[0x11] = 0;
  puVar2[0x10] = *(undefined4 *)(param_3 + 0x40);
  puVar2[0x11] = *(undefined4 *)(param_3 + 0x44);
  *(undefined4 *)(param_3 + 0x40) = 0;
  *(undefined4 *)(param_3 + 0x44) = 0;
  puVar2[0x12] = *(undefined4 *)(param_3 + 0x48);
  uVar9 = param_1[1];
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (param_2 == uVar9) {
    uVar5 = *param_1;
    iStack_8 = CONCAT31(uVar3,2);
    for (; uVar5 != uVar9; uVar5 = uVar5 + 0x50) {
      FUN_00a3b160(uVar5);
    }
  }
  else {
    FUN_00a3e110(*param_1,param_2,uVar7);
    FUN_00a3e110(param_2,param_1[1],puVar2 + 0x14);
  }
  uVar9 = *param_1;
  if (uVar9 != 0) {
    uVar5 = param_1[1];
    if (uVar9 != uVar5) {
      do {
        FUN_005e6080();
        uVar9 = uVar9 + 0x50;
      } while (uVar9 != uVar5);
      uVar9 = *param_1;
    }
    uVar8 = ((int)(param_1[2] - uVar9) / 0x50) * 0x50;
    uVar5 = uVar9;
    if (0xfff < uVar8) {
      uVar5 = *(uint *)(uVar9 - 4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (uVar9 - uVar5) - 4) {
LAB_00a37602:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar8);
  }
  *param_1 = uVar7;
  param_1[1] = uVar1 * 0x50 + uVar7;
  param_1[2] = uVar4 * 0x50 + uVar7;
  ExceptionList = pvStack_10;
  return *param_1 + iVar6;
}



/* FUNCTION 20348 ; VA 0x00a375d8 ; Catch_All@00a375d8 */

void Catch_All_00a375d8(void)

{
  int unaff_EBP;
  
  FUN_00a3e090(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x20));
  FUN_006fec30(*(undefined4 *)(unaff_EBP + -0x30),*(undefined4 *)(unaff_EBP + -0x1c));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20349 ; VA 0x00a37610 ; FUN_00a37610 */

void FUN_00a37610(undefined4 param_1,undefined4 param_2)

{
  FUN_01674ea0(param_2,0x38);
  return;
}



/* FUNCTION 20350 ; VA 0x00a37630 ; FUN_00a37630 */

void FUN_00a37630(float *param_1,float *param_2,float *param_3)

{
  float fVar1;
  int iVar2;
  float *pfVar3;
  float *pfVar4;
  float fVar5;
  
  iVar2 = (int)param_3 - (int)param_1 >> 2;
  if (iVar2 < 0x29) {
    fVar5 = *param_2;
    if (fVar5 < *param_1) {
      *param_2 = *param_1;
      *param_1 = fVar5;
      fVar5 = *param_2;
    }
    fVar1 = *param_3;
    if (fVar1 < fVar5) {
      *param_3 = fVar5;
      *param_2 = fVar1;
      if (fVar1 < *param_1) {
        *param_2 = *param_1;
        *param_1 = fVar1;
        return;
      }
    }
  }
  else {
    iVar2 = iVar2 + 1 >> 3;
    fVar5 = param_1[iVar2];
    if (fVar5 < *param_1) {
      param_1[iVar2] = *param_1;
      *param_1 = fVar5;
      fVar5 = param_1[iVar2];
    }
    fVar1 = param_1[iVar2 * 2];
    if (fVar1 < fVar5) {
      param_1[iVar2 * 2] = fVar5;
      param_1[iVar2] = fVar1;
      if (fVar1 < *param_1) {
        param_1[iVar2] = *param_1;
        *param_1 = fVar1;
      }
    }
    pfVar3 = param_2 + -iVar2;
    fVar5 = *param_2;
    if (fVar5 < *pfVar3) {
      *param_2 = *pfVar3;
      *pfVar3 = fVar5;
      fVar5 = *param_2;
    }
    fVar1 = param_2[iVar2];
    if (fVar1 < fVar5) {
      param_2[iVar2] = fVar5;
      *param_2 = fVar1;
      if (fVar1 < *pfVar3) {
        *param_2 = *pfVar3;
        *pfVar3 = fVar1;
      }
    }
    pfVar3 = param_3 + iVar2 * -2;
    pfVar4 = param_3 + -iVar2;
    fVar5 = *pfVar4;
    if (fVar5 < *pfVar3) {
      *pfVar4 = *pfVar3;
      *pfVar3 = fVar5;
      fVar5 = *pfVar4;
    }
    fVar1 = *param_3;
    if (fVar1 < fVar5) {
      *param_3 = fVar5;
      *pfVar4 = fVar1;
      if (fVar1 < *pfVar3) {
        *pfVar4 = *pfVar3;
        *pfVar3 = fVar1;
      }
    }
    fVar5 = *param_2;
    if (fVar5 < param_1[iVar2]) {
      *param_2 = param_1[iVar2];
      param_1[iVar2] = fVar5;
      fVar5 = *param_2;
    }
    fVar1 = *pfVar4;
    if (fVar1 < fVar5) {
      *pfVar4 = fVar5;
      *param_2 = fVar1;
      if (fVar1 < param_1[iVar2]) {
        *param_2 = param_1[iVar2];
        param_1[iVar2] = fVar1;
      }
    }
  }
  return;
}



/* FUNCTION 20351 ; VA 0x00a377b0 ; FUN_00a377b0 */

void __thiscall FUN_00a377b0(float *param_1,float *param_2,undefined4 *param_3,float *param_4)

{
  byte *pbVar1;
  float fVar2;
  float *pfVar3;
  undefined *puVar4;
  char cVar5;
  int *piVar6;
  uint uVar7;
  undefined4 *puVar8;
  float fVar9;
  uint uVar10;
  float fVar11;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dd890;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  pfStack_18 = (float *)param_3;
  if (0xf < (uint)param_3[5]) {
    pfStack_18 = (float *)*param_3;
  }
  uVar7 = 0;
  uVar10 = 0x811c9dc5;
  if (param_3[4] != 0) {
    do {
      pbVar1 = (byte *)(uVar7 + (int)pfStack_18);
      uVar7 = uVar7 + 1;
      uVar10 = (*pbVar1 ^ uVar10) * 0x1000193;
    } while (uVar7 < (uint)param_3[4]);
  }
  fVar9 = param_1[3];
  uVar10 = (uint)param_1[6] & uVar10;
  fVar11 = param_1[1];
  ExceptionList = &pvStack_10;
  pfStack_1c = param_1;
  puVar4 = &stack0xffffffd0;
  if (fVar11 != *(float *)((int)fVar9 + uVar10 * 8)) {
    fVar11 = **(float **)((int)fVar9 + 4 + uVar10 * 8);
    ExceptionList = &pvStack_10;
    while (puVar4 = puStack_14, fVar11 != *(float *)((int)fVar9 + uVar10 * 8)) {
      fVar11 = *(float *)((int)fVar11 + 4);
      piVar6 = (int *)((int)fVar11 + 8);
      if (0xf < *(uint *)((int)fVar11 + 0x1c)) {
        piVar6 = (int *)*piVar6;
      }
      puVar8 = param_3;
      if (0xf < (uint)param_3[5]) {
        puVar8 = (undefined4 *)*param_3;
      }
      cVar5 = FUN_0055c360(puVar8,param_3[4],piVar6,*(undefined4 *)((int)fVar11 + 0x18));
      fVar9 = param_1[3];
      if (cVar5 != '\0') {
        *(float *)param_4[1] = *param_4;
        *(float *)((int)*param_4 + 4) = param_4[1];
        param_1[2] = (float)((int)param_1[2] + -1);
        FUN_005509f0();
        FUN_01674ea0(param_4,0x38);
        *param_2 = fVar11;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  puStack_14 = puVar4;
  pfStack_18 = param_4;
  fVar9 = *param_4;
  if (fVar11 != fVar9) {
    *(float *)param_4[1] = fVar9;
    **(float **)((int)fVar9 + 4) = fVar11;
    **(undefined4 **)((int)fVar11 + 4) = param_4;
    fVar2 = *(float *)((int)fVar11 + 4);
    *(undefined4 *)((int)fVar11 + 4) = *(undefined4 *)((int)fVar9 + 4);
    *(float *)((int)fVar9 + 4) = param_4[1];
    param_4[1] = fVar2;
  }
  fVar9 = param_1[3];
  fVar2 = *(float *)((int)fVar9 + uVar10 * 8);
  if (fVar2 == param_1[1]) {
    *(float **)((int)fVar9 + uVar10 * 8) = param_4;
    *(float **)((int)param_1[3] + 4 + uVar10 * 8) = param_4;
  }
  else if (fVar2 == fVar11) {
    *(float **)((int)fVar9 + uVar10 * 8) = param_4;
  }
  else {
    pfVar3 = (float *)**(undefined4 **)((int)fVar9 + 4 + uVar10 * 8);
    *(float **)((int)fVar9 + 4 + uVar10 * 8) = pfVar3;
    if (pfVar3 != param_4) {
      *(undefined4 *)((int)param_1[3] + 4 + uVar10 * 8) =
           *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uVar10 * 8) + 4);
    }
  }
  fVar9 = param_1[7];
  uStack_8 = 2;
  fVar11 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
           (float)((double)(int)fVar9 + (double)(&DAT_018c0d90)[-((int)fVar9 >> 0x1f)]);
  if (*param_1 <= fVar11 && fVar11 != *param_1) {
    if ((uint)fVar9 < 0x200) {
      fVar9 = (float)((int)fVar9 << 3);
    }
    else if ((uint)fVar9 < 0x1fffffff) {
      fVar9 = (float)((int)fVar9 * 2);
    }
    FUN_005cb500(fVar9);
    pfVar3 = (float *)param_1[1];
    if ((float *)*pfVar3 != pfVar3) {
      fVar9 = pfVar3[1];
      do {
        fVar11 = *(float *)param_1[1];
        FUN_00a377b0(auStack_24,(int)fVar11 + 8,fVar11);
      } while (fVar11 != fVar9);
    }
  }
  *param_2 = (float)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20352 ; VA 0x00a379c6 ; Catch_All@00a379c6 */

void Catch_All_00a379c6(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 0xc,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_00a3a310(unaff_EBP + 8,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20353 ; VA 0x00a379f0 ; FUN_00a379f0 */

void __thiscall FUN_00a379f0(float *param_1,float *param_2,undefined4 *param_3,float *param_4)

{
  byte *pbVar1;
  float fVar2;
  float *pfVar3;
  undefined *puVar4;
  char cVar5;
  int *piVar6;
  uint uVar7;
  undefined4 *puVar8;
  float fVar9;
  uint uVar10;
  float fVar11;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dd8a0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  pfStack_18 = (float *)param_3;
  if (0xf < (uint)param_3[5]) {
    pfStack_18 = (float *)*param_3;
  }
  uVar7 = 0;
  uVar10 = 0x811c9dc5;
  if (param_3[4] != 0) {
    do {
      pbVar1 = (byte *)(uVar7 + (int)pfStack_18);
      uVar7 = uVar7 + 1;
      uVar10 = (*pbVar1 ^ uVar10) * 0x1000193;
    } while (uVar7 < (uint)param_3[4]);
  }
  fVar9 = param_1[3];
  uVar10 = (uint)param_1[6] & uVar10;
  fVar11 = param_1[1];
  ExceptionList = &pvStack_10;
  pfStack_1c = param_1;
  puVar4 = &stack0xffffffd0;
  if (fVar11 != *(float *)((int)fVar9 + uVar10 * 8)) {
    fVar11 = **(float **)((int)fVar9 + 4 + uVar10 * 8);
    ExceptionList = &pvStack_10;
    while (puVar4 = puStack_14, fVar11 != *(float *)((int)fVar9 + uVar10 * 8)) {
      fVar11 = *(float *)((int)fVar11 + 4);
      piVar6 = (int *)((int)fVar11 + 8);
      if (0xf < *(uint *)((int)fVar11 + 0x1c)) {
        piVar6 = (int *)*piVar6;
      }
      puVar8 = param_3;
      if (0xf < (uint)param_3[5]) {
        puVar8 = (undefined4 *)*param_3;
      }
      cVar5 = FUN_0055c360(puVar8,param_3[4],piVar6,*(undefined4 *)((int)fVar11 + 0x18));
      fVar9 = param_1[3];
      if (cVar5 != '\0') {
        *(float *)param_4[1] = *param_4;
        *(float *)((int)*param_4 + 4) = param_4[1];
        param_1[2] = (float)((int)param_1[2] + -1);
        FUN_008c3170();
        FUN_01674ea0(param_4,0x40);
        *param_2 = fVar11;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  puStack_14 = puVar4;
  pfStack_18 = param_4;
  fVar9 = *param_4;
  if (fVar11 != fVar9) {
    *(float *)param_4[1] = fVar9;
    **(float **)((int)fVar9 + 4) = fVar11;
    **(undefined4 **)((int)fVar11 + 4) = param_4;
    fVar2 = *(float *)((int)fVar11 + 4);
    *(undefined4 *)((int)fVar11 + 4) = *(undefined4 *)((int)fVar9 + 4);
    *(float *)((int)fVar9 + 4) = param_4[1];
    param_4[1] = fVar2;
  }
  fVar9 = param_1[3];
  fVar2 = *(float *)((int)fVar9 + uVar10 * 8);
  if (fVar2 == param_1[1]) {
    *(float **)((int)fVar9 + uVar10 * 8) = param_4;
    *(float **)((int)param_1[3] + 4 + uVar10 * 8) = param_4;
  }
  else if (fVar2 == fVar11) {
    *(float **)((int)fVar9 + uVar10 * 8) = param_4;
  }
  else {
    pfVar3 = (float *)**(undefined4 **)((int)fVar9 + 4 + uVar10 * 8);
    *(float **)((int)fVar9 + 4 + uVar10 * 8) = pfVar3;
    if (pfVar3 != param_4) {
      *(undefined4 *)((int)param_1[3] + 4 + uVar10 * 8) =
           *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uVar10 * 8) + 4);
    }
  }
  fVar9 = param_1[7];
  uStack_8 = 2;
  fVar11 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
           (float)((double)(int)fVar9 + (double)(&DAT_018c0d90)[-((int)fVar9 >> 0x1f)]);
  if (*param_1 <= fVar11 && fVar11 != *param_1) {
    if ((uint)fVar9 < 0x200) {
      fVar9 = (float)((int)fVar9 << 3);
    }
    else if ((uint)fVar9 < 0x1fffffff) {
      fVar9 = (float)((int)fVar9 * 2);
    }
    FUN_005cb500(fVar9);
    pfVar3 = (float *)param_1[1];
    if ((float *)*pfVar3 != pfVar3) {
      fVar9 = pfVar3[1];
      do {
        fVar11 = *(float *)param_1[1];
        FUN_00a379f0(auStack_24,(int)fVar11 + 8,fVar11);
      } while (fVar11 != fVar9);
    }
  }
  *param_2 = (float)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20354 ; VA 0x00a37c06 ; Catch_All@00a37c06 */

void Catch_All_00a37c06(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 0xc,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_00a3a3c0(unaff_EBP + 8,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20355 ; VA 0x00a37c30 ; FUN_00a37c30 */

uint * FUN_00a37c30(uint *param_1,uint *param_2,uint *param_3)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  int *piVar4;
  int iVar5;
  uint *puVar6;
  uint *puVar7;
  uint auStack_50 [2];
  undefined auStack_48 [24];
  uint auStack_30 [2];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dd8d0;
  pvStack_10 = ExceptionList;
  if (param_1 != param_2) {
    puVar7 = param_3 + 8;
    puVar6 = param_1 + 0x11;
    ExceptionList = &pvStack_10;
    do {
      auStack_30[0] = 0;
      FUN_005880d0(puVar6 + -0x11);
      if (param_3 != auStack_30) {
        auStack_50[0] = 0;
        uStack_8._0_1_ = 1;
        uStack_8._1_3_ = 0;
        FUN_005880d0(auStack_30);
        FUN_005880d0(param_3);
        FUN_005880d0(auStack_50);
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        if (((auStack_50[0] != 0) && ((auStack_50[0] & 1) == 0)) &&
           (*(code **)(auStack_50[0] & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(auStack_50[0] & 0xfffffffe))(auStack_48,auStack_48,2);
        }
      }
      uStack_8 = 3;
      if (((auStack_30[0] != 0) && ((auStack_30[0] & 1) == 0)) &&
         (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_30[0] & 0xfffffffe))(auStack_28,auStack_28,2);
      }
      uStack_8 = 0xffffffff;
      auStack_30[0] = 0;
      FUN_005880d0(puVar6 + -9);
      if (puVar7 != auStack_30) {
        auStack_50[0] = 0;
        uStack_8._0_1_ = 5;
        uStack_8._1_3_ = 0;
        FUN_005880d0(auStack_30);
        FUN_005880d0(puVar7);
        FUN_005880d0(auStack_50);
        uStack_8 = CONCAT31(uStack_8._1_3_,6);
        if (((auStack_50[0] != 0) && ((auStack_50[0] & 1) == 0)) &&
           (*(code **)(auStack_50[0] & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(auStack_50[0] & 0xfffffffe))(auStack_48,auStack_48,2);
        }
      }
      uStack_8 = 7;
      if (((auStack_30[0] != 0) && ((auStack_30[0] & 1) == 0)) &&
         (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_30[0] & 0xfffffffe))(auStack_28,auStack_28,2);
      }
      uVar2 = puVar6[-1];
      uVar3 = *puVar6;
      puVar6[-1] = 0;
      *puVar6 = 0;
      puVar7[8] = uVar2;
      piVar4 = (int *)puVar7[9];
      uStack_8 = 0xffffffff;
      puVar7[9] = uVar3;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
      param_3 = param_3 + 0x14;
      puVar7[10] = puVar6[1];
      puVar7 = puVar7 + 0x14;
      puVar1 = puVar6 + 3;
      puVar6 = puVar6 + 0x14;
    } while (puVar1 != param_2);
    ExceptionList = pvStack_10;
    return param_3;
  }
  return param_3;
}



/* FUNCTION 20356 ; VA 0x00a37e10 ; FUN_00a37e10 */

void FUN_00a37e10(int param_1,int param_2,uint param_3,float *param_4)

{
  float *pfVar1;
  float fVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  iVar5 = (int)(param_3 - 1) >> 1;
  iVar3 = param_2;
  iVar4 = param_2;
  if (param_2 < iVar5) {
    do {
      fVar2 = *(float *)(param_1 + 4 + iVar3 * 8);
      pfVar1 = (float *)(param_1 + 8 + iVar3 * 8);
      iVar4 = iVar3 * 2 + ((*pfVar1 <= fVar2 && fVar2 != *pfVar1) ^ 1) + 1;
      *(undefined4 *)(param_1 + iVar3 * 4) = *(undefined4 *)(param_1 + iVar4 * 4);
      iVar3 = iVar4;
    } while (iVar4 < iVar5);
  }
  if ((iVar4 == iVar5) && ((param_3 & 1) == 0)) {
    *(undefined4 *)(param_1 + iVar4 * 4) = *(undefined4 *)(param_1 + -4 + param_3 * 4);
    iVar4 = param_3 - 1;
  }
  if (iVar4 <= param_2) {
    *(float *)(param_1 + iVar4 * 4) = *param_4;
    return;
  }
  do {
    iVar3 = iVar4 + -1 >> 1;
    fVar2 = *(float *)(param_1 + iVar3 * 4);
    if (*param_4 <= fVar2) break;
    *(float *)(param_1 + iVar4 * 4) = fVar2;
    iVar4 = iVar3;
  } while (param_2 < iVar3);
  *(float *)(param_1 + iVar4 * 4) = *param_4;
  return;
}



/* FUNCTION 20357 ; VA 0x00a37eb0 ; FUN_00a37eb0 */

void __thiscall FUN_00a37eb0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dd8e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_std::runtime_error>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20358 ; VA 0x00a37f1e ; Catch_All@00a37f1e */

void Catch_All_00a37f1e(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20359 ; VA 0x00a37f40 ; FUN_00a37f40 */

int __thiscall FUN_00a37f40(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dd8f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::LocalizationTable*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20360 ; VA 0x00a38012 ; Catch_All@00a38012 */

void Catch_All_00a38012(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20361 ; VA 0x00a38030 ; FUN_00a38030 */

int __thiscall FUN_00a38030(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dd900;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::PlayerLocaleLocalizationServiceTranslatorInstance*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20362 ; VA 0x00a38102 ; Catch_All@00a38102 */

void Catch_All_00a38102(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20363 ; VA 0x00a38120 ; FUN_00a38120 */

void FUN_00a38120(float *param_1,float *param_2,int param_3,undefined4 param_4)

{
  float fVar1;
  float fVar2;
  int iVar3;
  int iVar4;
  float *pfVar5;
  uint uVar6;
  float *pfVar7;
  int iVar8;
  int iVar9;
  float *pfVar10;
  float *pfVar11;
  float *pfVar12;
  int iVar13;
  
  iVar4 = (int)param_2 - (int)param_1;
  pfVar11 = param_2;
  do {
    iVar13 = iVar4 >> 2;
    if (iVar13 < 0x21) {
LAB_00a382fd:
      if (((1 < iVar13) && (param_1 != pfVar11)) && (pfVar10 = param_1 + 1, pfVar10 != pfVar11)) {
        param_2 = (float *)0x4;
        do {
          fVar1 = *pfVar10;
          if (*param_1 <= fVar1) {
            pfVar7 = (float *)((int)param_2 + -4 + (int)param_1);
            fVar2 = *pfVar7;
            pfVar12 = pfVar10;
            while (pfVar5 = pfVar7, fVar1 < fVar2) {
              *pfVar12 = fVar2;
              pfVar7 = pfVar5 + -1;
              pfVar12 = pfVar5;
              fVar2 = pfVar5[-1];
            }
            *pfVar12 = fVar1;
          }
          else {
            FUN_0170cc70(param_1 + 1,param_1,param_2);
            *param_1 = fVar1;
          }
          pfVar10 = pfVar10 + 1;
          param_2 = (float *)((int)param_2 + 4);
        } while (pfVar10 != pfVar11);
      }
      return;
    }
    if (param_3 < 1) {
      if (0x20 < iVar13) {
        iVar13 = (int)pfVar11 - (int)param_1;
        uVar6 = iVar13 >> 2;
        iVar4 = iVar13 >> 3;
        if (0 < iVar4) {
          iVar8 = (int)(uVar6 - 1) >> 1;
          do {
            fVar1 = param_1[iVar4 + -1];
            iVar4 = iVar4 + -1;
            iVar3 = iVar4;
            while (iVar3 < iVar8) {
              iVar9 = iVar3 * 2 +
                      ((param_1[iVar3 * 2 + 2] <= param_1[iVar3 * 2 + 1] &&
                       param_1[iVar3 * 2 + 1] != param_1[iVar3 * 2 + 2]) ^ 1) + 1;
              param_1[iVar3] = param_1[iVar9];
              iVar3 = iVar9;
            }
            if ((iVar3 == iVar8) && ((uVar6 & 1) == 0)) {
              param_1[iVar3] = param_1[uVar6 - 1];
              iVar3 = uVar6 - 1;
            }
            while (iVar4 < iVar3) {
              iVar9 = iVar3 + -1 >> 1;
              if (fVar1 <= param_1[iVar9]) break;
              param_1[iVar3] = param_1[iVar9];
              iVar3 = iVar9;
            }
            param_1[iVar3] = fVar1;
          } while (0 < iVar4);
        }
        if ((int)uVar6 < 2) {
          return;
        }
        do {
          if (1 < (int)uVar6) {
            param_2 = *(float **)((int)param_1 + iVar13 + -4);
            *(float *)((int)param_1 + iVar13 + -4) = *param_1;
            FUN_00a37e10(param_1,0,iVar13 + -4 >> 2,&param_2,param_4);
          }
          iVar13 = iVar13 + -4;
          uVar6 = iVar13 >> 2;
        } while (1 < (int)uVar6);
        return;
      }
      goto LAB_00a382fd;
    }
    pfVar10 = param_1 + (iVar4 >> 3);
    param_2 = pfVar11;
    FUN_00a37630(param_1,pfVar10,pfVar11 + -1,param_4);
    pfVar11 = pfVar10 + 1;
    for (; param_1 < pfVar10; pfVar10 = pfVar10 + -1) {
      if ((pfVar10[-1] < *pfVar10) || (*pfVar10 < pfVar10[-1])) break;
    }
    pfVar12 = pfVar11;
    pfVar7 = pfVar10;
    if (pfVar11 < param_2) {
      do {
        pfVar12 = pfVar11;
        if ((*pfVar11 < *pfVar10) || (*pfVar10 < *pfVar11)) break;
        pfVar11 = pfVar11 + 1;
        pfVar12 = pfVar11;
      } while (pfVar11 < param_2);
    }
joined_r0x00a381b2:
    pfVar5 = pfVar7;
    if (pfVar11 < param_2) {
      fVar1 = *pfVar11;
      if (fVar1 <= *pfVar10) {
        if (fVar1 < *pfVar10) goto joined_r0x00a381e2;
        if (pfVar12 != pfVar11) {
          fVar2 = *pfVar12;
          *pfVar12 = fVar1;
          *pfVar11 = fVar2;
        }
        pfVar12 = pfVar12 + 1;
      }
      pfVar11 = pfVar11 + 1;
      goto joined_r0x00a381b2;
    }
joined_r0x00a381e2:
    for (; param_1 < pfVar7; pfVar7 = pfVar7 + -1) {
      pfVar5 = pfVar5 + -1;
      fVar1 = *pfVar5;
      if (*pfVar10 <= fVar1) {
        if (*pfVar10 < fVar1) break;
        pfVar10 = pfVar10 + -1;
        if (pfVar10 != pfVar5) {
          fVar2 = *pfVar10;
          *pfVar10 = fVar1;
          *pfVar5 = fVar2;
        }
      }
    }
    if (pfVar7 != param_1) {
      pfVar7 = pfVar7 + -1;
      if (pfVar11 == param_2) {
        pfVar10 = pfVar10 + -1;
        if (pfVar7 != pfVar10) {
          fVar1 = *pfVar7;
          *pfVar7 = *pfVar10;
          *pfVar10 = fVar1;
        }
        fVar1 = *pfVar10;
        *pfVar10 = pfVar12[-1];
        pfVar12[-1] = fVar1;
        pfVar12 = pfVar12 + -1;
      }
      else {
        fVar1 = *pfVar11;
        *pfVar11 = *pfVar7;
        pfVar11 = pfVar11 + 1;
        *pfVar7 = fVar1;
      }
      goto joined_r0x00a381b2;
    }
    if (pfVar11 != param_2) {
      if (pfVar12 != pfVar11) {
        fVar1 = *pfVar10;
        *pfVar10 = *pfVar12;
        *pfVar12 = fVar1;
      }
      fVar1 = *pfVar10;
      *pfVar10 = *pfVar11;
      pfVar10 = pfVar10 + 1;
      *pfVar11 = fVar1;
      pfVar11 = pfVar11 + 1;
      pfVar12 = pfVar12 + 1;
      goto joined_r0x00a381b2;
    }
    param_3 = (param_3 >> 1) + (param_3 >> 2);
    if ((int)((int)pfVar10 - (int)param_1 & 0xfffffffcU) <
        (int)((int)param_2 - (int)pfVar12 & 0xfffffffcU)) {
      FUN_00a38120(param_1,pfVar10,param_3,param_4);
      param_1 = pfVar12;
    }
    else {
      FUN_00a38120(pfVar12,param_2,param_3,param_4);
      param_2 = pfVar10;
    }
    iVar4 = (int)param_2 - (int)param_1;
    pfVar11 = param_2;
  } while( true );
}



/* FUNCTION 20364 ; VA 0x00a384a0 ; FUN_00a384a0 */

void __thiscall
FUN_00a384a0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_c = param_6;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_24 = param_3;
  uStack_18 = param_6;
  uStack_28 = param_2;
  uStack_20 = param_4;
  uStack_1c = param_5;
  cVar3 = FUN_00585a40(&uStack_28);
  if (cVar3 == '\0') {
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[2] = piStack_24[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_1c;
    uStack_10 = uStack_18;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[2] = piStack_24[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_28;
    param_1[3] = piStack_24;
    param_1[4] = uStack_20;
    param_1[5] = uStack_1c;
    param_1[6] = uStack_18;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[2] + -1;
      piStack_24[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[2] + -1;
      piStack_24[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[2] + -1;
      piStack_24[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01942fa8;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 20365 ; VA 0x00a385d0 ; FUN_00a385d0 */

void __thiscall FUN_00a385d0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_10 = param_3;
  uStack_14 = param_2;
  uStack_c = param_4;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    param_1[4] = uStack_c;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01942fb8;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 20366 ; VA 0x00a386e0 ; FUN_00a386e0 */

void __thiscall FUN_00a386e0(undefined4 *param_1,undefined4 param_2,int param_3)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined4 in_stack_00000024;
  undefined4 uStack_80;
  int iStack_7c;
  undefined auStack_78 [24];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  int iStack_58;
  undefined auStack_54 [24];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int iStack_34;
  undefined auStack_30 [24];
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017dd95f;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_80;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_3 + 8) = *(int *)(param_3 + 8) + 1;
    UNLOCK();
  }
  uStack_80 = param_2;
  iStack_7c = param_3;
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_0054ef60(&stack0x0000000c);
  uStack_60 = in_stack_00000024;
  puStack_14 = &uStack_38;
  if (iStack_7c != 0) {
    LOCK();
    *(int *)(iStack_7c + 8) = *(int *)(iStack_7c + 8) + 1;
    UNLOCK();
  }
  uStack_38 = uStack_80;
  iStack_34 = iStack_7c;
  uStack_8 = 3;
  FUN_0054ef60(auStack_78);
  uStack_18 = uStack_60;
  uStack_8 = 4;
  cVar2 = FUN_00585a40(&uStack_38);
  if (cVar2 == '\0') {
    puStack_14 = &uStack_5c;
    if (iStack_34 != 0) {
      LOCK();
      *(int *)(iStack_34 + 8) = *(int *)(iStack_34 + 8) + 1;
      UNLOCK();
    }
    uStack_5c = uStack_38;
    iStack_58 = iStack_34;
    uStack_8 = 5;
    FUN_0054ef60(auStack_30);
    uStack_3c = uStack_18;
    uStack_8 = 6;
    puVar3 = (undefined4 *)FUN_01674e20(0x24);
    uStack_8 = 7;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = 0;
      puVar3[1] = 0;
      if (iStack_58 != 0) {
        LOCK();
        *(int *)(iStack_58 + 8) = *(int *)(iStack_58 + 8) + 1;
        UNLOCK();
      }
      *puVar3 = uStack_5c;
      puVar3[1] = iStack_58;
      uStack_8 = 8;
      FUN_0054ef60(auStack_54);
      puVar3[8] = uStack_3c;
    }
    param_1[2] = puVar3;
    FUN_005d11a0();
    FUN_005d11a0();
    bVar1 = true;
  }
  else {
    FUN_005d11a0();
    bVar1 = false;
  }
  FUN_005d11a0();
  ppuVar4 = &PTR_FUN_01942fc8;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_005d11a0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20367 ; VA 0x00a38890 ; FUN_00a38890 */

void __thiscall FUN_00a38890(undefined4 *param_1,undefined param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  char cVar4;
  undefined **ppuVar5;
  undefined auStack_14 [4];
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 *puStack_8;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  auStack_14[0] = param_2;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  piStack_c = param_4;
  uStack_10 = param_3;
  puStack_8 = param_1;
  cVar4 = FUN_00585a40(auStack_14);
  if (cVar4 == '\0') {
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[2] = piStack_c[2] + 1;
      UNLOCK();
    }
    *(undefined *)(param_1 + 2) = auStack_14[0];
    param_1[3] = 0;
    param_1[4] = 0;
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[2] = piStack_c[2] + 1;
      UNLOCK();
    }
    param_1[3] = uStack_10;
    param_1[4] = piStack_c;
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    bVar3 = true;
  }
  else {
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    bVar3 = false;
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  ppuVar5 = &PTR_FUN_01942f84;
  if (!bVar3) {
    ppuVar5 = (undefined **)0x0;
  }
  *puStack_8 = ppuVar5;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return;
}



/* FUNCTION 20368 ; VA 0x00a389a0 ; FUN_00a389a0 */

void __thiscall FUN_00a389a0(undefined4 *param_1,undefined4 param_2,int param_3,undefined param_4)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined4 uStack_80;
  int iStack_7c;
  undefined uStack_78;
  undefined auStack_74 [24];
  undefined4 uStack_5c;
  int iStack_58;
  undefined uStack_54;
  undefined auStack_50 [24];
  undefined4 uStack_38;
  int iStack_34;
  undefined uStack_30;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017dd9bf;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_80;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_3 + 8) = *(int *)(param_3 + 8) + 1;
    UNLOCK();
  }
  uStack_80 = param_2;
  iStack_7c = param_3;
  uStack_78 = param_4;
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_0054ef60(&stack0x00000010);
  puStack_14 = &uStack_38;
  if (iStack_7c != 0) {
    LOCK();
    *(int *)(iStack_7c + 8) = *(int *)(iStack_7c + 8) + 1;
    UNLOCK();
  }
  uStack_38 = uStack_80;
  iStack_34 = iStack_7c;
  uStack_30 = uStack_78;
  uStack_8 = 3;
  FUN_0054ef60(auStack_74);
  uStack_8 = 4;
  cVar2 = FUN_00585a40(&uStack_38);
  if (cVar2 == '\0') {
    puStack_14 = &uStack_5c;
    if (iStack_34 != 0) {
      LOCK();
      *(int *)(iStack_34 + 8) = *(int *)(iStack_34 + 8) + 1;
      UNLOCK();
    }
    uStack_5c = uStack_38;
    iStack_58 = iStack_34;
    uStack_54 = uStack_30;
    uStack_8 = 5;
    FUN_0054ef60(auStack_2c);
    uStack_8 = 6;
    puVar3 = (undefined4 *)FUN_01674e20(0x24);
    uStack_8 = 7;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = 0;
      puVar3[1] = 0;
      if (iStack_58 != 0) {
        LOCK();
        *(int *)(iStack_58 + 8) = *(int *)(iStack_58 + 8) + 1;
        UNLOCK();
      }
      *puVar3 = uStack_5c;
      puVar3[1] = iStack_58;
      *(undefined *)(puVar3 + 2) = uStack_54;
      uStack_8 = 8;
      FUN_0054ef60(auStack_50);
    }
    param_1[2] = puVar3;
    FUN_00a3bbb0();
    FUN_00a3bbb0();
    bVar1 = true;
  }
  else {
    FUN_00a3bbb0();
    bVar1 = false;
  }
  FUN_00a3bbb0();
  ppuVar4 = &PTR_FUN_01942f8c;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_00a3bbb0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20369 ; VA 0x00a38b50 ; FUN_00a38b50 */

void __thiscall FUN_00a38b50(undefined4 *param_1,undefined4 param_2,int param_3)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined4 in_stack_00000024;
  undefined4 uStack_80;
  int iStack_7c;
  undefined auStack_78 [24];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  int iStack_58;
  undefined auStack_54 [24];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int iStack_34;
  undefined auStack_30 [24];
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017dda1f;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_80;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_3 + 8) = *(int *)(param_3 + 8) + 1;
    UNLOCK();
  }
  uStack_80 = param_2;
  iStack_7c = param_3;
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_0054ef60(&stack0x0000000c);
  uStack_60 = in_stack_00000024;
  puStack_14 = &uStack_38;
  if (iStack_7c != 0) {
    LOCK();
    *(int *)(iStack_7c + 8) = *(int *)(iStack_7c + 8) + 1;
    UNLOCK();
  }
  uStack_38 = uStack_80;
  iStack_34 = iStack_7c;
  uStack_8 = 3;
  FUN_0054ef60(auStack_78);
  uStack_18 = uStack_60;
  uStack_8 = 4;
  cVar2 = FUN_00585a40(&uStack_38);
  if (cVar2 == '\0') {
    puStack_14 = &uStack_5c;
    if (iStack_34 != 0) {
      LOCK();
      *(int *)(iStack_34 + 8) = *(int *)(iStack_34 + 8) + 1;
      UNLOCK();
    }
    uStack_5c = uStack_38;
    iStack_58 = iStack_34;
    uStack_8 = 5;
    FUN_0054ef60(auStack_30);
    uStack_3c = uStack_18;
    uStack_8 = 6;
    puVar3 = (undefined4 *)FUN_01674e20(0x24);
    uStack_8 = 7;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = 0;
      puVar3[1] = 0;
      if (iStack_58 != 0) {
        LOCK();
        *(int *)(iStack_58 + 8) = *(int *)(iStack_58 + 8) + 1;
        UNLOCK();
      }
      *puVar3 = uStack_5c;
      puVar3[1] = iStack_58;
      uStack_8 = 8;
      FUN_0054ef60(auStack_54);
      puVar3[8] = uStack_3c;
    }
    param_1[2] = puVar3;
    FUN_005d11a0();
    FUN_005d11a0();
    bVar1 = true;
  }
  else {
    FUN_005d11a0();
    bVar1 = false;
  }
  FUN_005d11a0();
  ppuVar4 = &PTR_FUN_01942fc0;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_005d11a0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20370 ; VA 0x00a38d00 ; FUN_00a38d00 */

void __thiscall FUN_00a38d00(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_10 = param_3;
  uStack_14 = param_2;
  uStack_c = param_4;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    param_1[4] = uStack_c;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01942fb0;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 20371 ; VA 0x00a38e10 ; FUN_00a38e10 */

void __thiscall
FUN_00a38e10(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_c = param_6;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_24 = param_3;
  uStack_18 = param_6;
  uStack_28 = param_2;
  uStack_20 = param_4;
  uStack_1c = param_5;
  cVar3 = FUN_00585a40(&uStack_28);
  if (cVar3 == '\0') {
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[2] = piStack_24[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_1c;
    uStack_10 = uStack_18;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[2] = piStack_24[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_28;
    param_1[3] = piStack_24;
    param_1[4] = uStack_20;
    param_1[5] = uStack_1c;
    param_1[6] = uStack_18;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[2] + -1;
      piStack_24[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[2] + -1;
      piStack_24[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[2] + -1;
      piStack_24[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01942ff0;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 20372 ; VA 0x00a38f40 ; FUN_00a38f40 */

void __thiscall FUN_00a38f40(undefined4 *param_1,undefined4 param_2,int param_3)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined4 in_stack_00000024;
  undefined4 uStack_80;
  int iStack_7c;
  undefined auStack_78 [24];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  int iStack_58;
  undefined auStack_54 [24];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int iStack_34;
  undefined auStack_30 [24];
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017dda7f;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_80;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_3 + 8) = *(int *)(param_3 + 8) + 1;
    UNLOCK();
  }
  uStack_80 = param_2;
  iStack_7c = param_3;
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_0054ef60(&stack0x0000000c);
  uStack_60 = in_stack_00000024;
  puStack_14 = &uStack_38;
  if (iStack_7c != 0) {
    LOCK();
    *(int *)(iStack_7c + 8) = *(int *)(iStack_7c + 8) + 1;
    UNLOCK();
  }
  uStack_38 = uStack_80;
  iStack_34 = iStack_7c;
  uStack_8 = 3;
  FUN_0054ef60(auStack_78);
  uStack_18 = uStack_60;
  uStack_8 = 4;
  cVar2 = FUN_00585a40(&uStack_38);
  if (cVar2 == '\0') {
    puStack_14 = &uStack_5c;
    if (iStack_34 != 0) {
      LOCK();
      *(int *)(iStack_34 + 8) = *(int *)(iStack_34 + 8) + 1;
      UNLOCK();
    }
    uStack_5c = uStack_38;
    iStack_58 = iStack_34;
    uStack_8 = 5;
    FUN_0054ef60(auStack_30);
    uStack_3c = uStack_18;
    uStack_8 = 6;
    puVar3 = (undefined4 *)FUN_01674e20(0x24);
    uStack_8 = 7;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = 0;
      puVar3[1] = 0;
      if (iStack_58 != 0) {
        LOCK();
        *(int *)(iStack_58 + 8) = *(int *)(iStack_58 + 8) + 1;
        UNLOCK();
      }
      *puVar3 = uStack_5c;
      puVar3[1] = iStack_58;
      uStack_8 = 8;
      FUN_0054ef60(auStack_54);
      puVar3[8] = uStack_3c;
    }
    param_1[2] = puVar3;
    FUN_005d11a0();
    FUN_005d11a0();
    bVar1 = true;
  }
  else {
    FUN_005d11a0();
    bVar1 = false;
  }
  FUN_005d11a0();
  ppuVar4 = &PTR_FUN_01942f6c;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_005d11a0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20373 ; VA 0x00a390f0 ; FUN_00a390f0 */

void __thiscall FUN_00a390f0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  undefined uStack_c;
  undefined uStack_b;
  undefined uStack_6;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_10 = param_3;
  uStack_14 = param_2;
  uStack_c = (undefined)param_4;
  uStack_b = (undefined)((uint)param_4 >> 8);
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    cStack_5 = uStack_c;
    uStack_6 = uStack_b;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    *(undefined *)(param_1 + 4) = uStack_c;
    *(undefined *)((int)param_1 + 0x11) = uStack_b;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01942f74;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 20374 ; VA 0x00a39210 ; FUN_00a39210 */

void __thiscall
FUN_00a39210(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_c = param_6;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_24 = param_3;
  uStack_18 = param_6;
  uStack_28 = param_2;
  uStack_20 = param_4;
  uStack_1c = param_5;
  cVar3 = FUN_00585a40(&uStack_28);
  if (cVar3 == '\0') {
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[2] = piStack_24[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_1c;
    uStack_10 = uStack_18;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[2] = piStack_24[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_28;
    param_1[3] = piStack_24;
    param_1[4] = uStack_20;
    param_1[5] = uStack_1c;
    param_1[6] = uStack_18;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[2] + -1;
      piStack_24[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[2] + -1;
      piStack_24[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[2] + -1;
      piStack_24[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01942ff8;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 20375 ; VA 0x00a39340 ; FUN_00a39340 */

void __thiscall FUN_00a39340(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined4 in_stack_00000028;
  undefined4 uStack_8c;
  int iStack_88;
  undefined auStack_84 [24];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  int iStack_60;
  undefined auStack_5c [24];
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  undefined auStack_34 [24];
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017ddae5;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_8c;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_4 + 8) = *(int *)(param_4 + 8) + 1;
    UNLOCK();
  }
  uStack_8c = param_3;
  iStack_88 = param_4;
  uStack_8 = 1;
  uStack_7 = 0;
  puStack_18 = param_1;
  FUN_0054ef60(&stack0x00000010);
  uStack_6c = in_stack_00000028;
  uStack_40 = param_2;
  puStack_14 = &uStack_3c;
  if (iStack_88 != 0) {
    LOCK();
    *(int *)(iStack_88 + 8) = *(int *)(iStack_88 + 8) + 1;
    UNLOCK();
  }
  uStack_3c = uStack_8c;
  iStack_38 = iStack_88;
  uStack_8 = 3;
  FUN_0054ef60(auStack_84);
  uStack_1c = uStack_6c;
  uStack_8 = 4;
  cVar2 = FUN_00585a40(&uStack_40);
  if (cVar2 == '\0') {
    uStack_68 = uStack_40;
    puStack_14 = &uStack_64;
    if (iStack_38 != 0) {
      LOCK();
      *(int *)(iStack_38 + 8) = *(int *)(iStack_38 + 8) + 1;
      UNLOCK();
    }
    uStack_64 = uStack_3c;
    iStack_60 = iStack_38;
    uStack_8 = 5;
    FUN_0054ef60(auStack_34);
    uStack_44 = uStack_1c;
    uStack_8 = 6;
    puVar3 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8 = 7;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uStack_68;
      puVar3[1] = 0;
      puVar3[2] = 0;
      if (iStack_60 != 0) {
        LOCK();
        *(int *)(iStack_60 + 8) = *(int *)(iStack_60 + 8) + 1;
        UNLOCK();
      }
      puVar3[1] = uStack_64;
      puVar3[2] = iStack_60;
      uStack_8 = 8;
      FUN_0054ef60(auStack_5c);
      puVar3[9] = uStack_44;
    }
    param_1[2] = puVar3;
    FUN_005d11a0();
    FUN_005d11a0();
    bVar1 = true;
  }
  else {
    FUN_005d11a0();
    bVar1 = false;
  }
  FUN_005d11a0();
  ppuVar4 = &PTR_FUN_01942fe0;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *puStack_18 = ppuVar4;
  FUN_005d11a0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20376 ; VA 0x00a39540 ; FUN_00a39540 */

undefined FUN_00a39540(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      int *param_9)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  undefined4 *puVar6;
  undefined uVar7;
  undefined4 auStack_3c [2];
  undefined4 uStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017dd7d8;
  pvStack_10 = ExceptionList;
  auStack_3c[0] = param_1;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_34 = param_3;
  uStack_2c = param_5;
  uStack_28 = param_6;
  piStack_30 = param_4;
  uStack_24 = param_7;
  uStack_8 = 1;
  uStack_7 = 0;
  cVar5 = FUN_00585a40(auStack_3c);
  piVar1 = piStack_30;
  uVar4 = uStack_34;
  uVar3 = auStack_3c[0];
  if (cVar5 == '\0') {
    if (piStack_30 != (int *)0x0) {
      LOCK();
      piStack_30[2] = piStack_30[2] + 1;
      UNLOCK();
    }
    uStack_14 = uStack_2c;
    uStack_18 = uStack_28;
    uStack_1c = uStack_24;
    uStack_8 = 2;
    puVar6 = (undefined4 *)FUN_01674e20(0x20);
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      *puVar6 = uVar3;
      puVar6[2] = 0;
      puVar6[3] = 0;
      if (piVar1 != (int *)0x0) {
        LOCK();
        piVar1[2] = piVar1[2] + 1;
        UNLOCK();
      }
      puVar6[2] = uVar4;
      puVar6[3] = piVar1;
      puVar6[4] = uStack_14;
      puVar6[5] = uStack_18;
      puVar6[6] = uStack_1c;
    }
    *param_9 = (int)puVar6;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_30[2] + -1;
      piStack_30[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
    uVar7 = 1;
  }
  else {
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_30[2] + -1;
      piStack_30[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
    uVar7 = 0;
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 20377 ; VA 0x00a396c0 ; FUN_00a396c0 */

void __thiscall
FUN_00a396c0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_18;
  undefined4 uStack_14;
  int *piStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_18 = param_2;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  piStack_10 = param_4;
  uStack_14 = param_3;
  uStack_c = param_5;
  cVar3 = FUN_00585a40(&uStack_18);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_18;
    param_1[3] = 0;
    param_1[4] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[3] = uStack_14;
    param_1[4] = piStack_10;
    param_1[5] = uStack_c;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01942fd8;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return;
}



/* FUNCTION 20378 ; VA 0x00a397e0 ; FUN_00a397e0 */

undefined FUN_00a397e0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      int *param_9)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  undefined4 *puVar6;
  undefined uVar7;
  undefined4 auStack_3c [2];
  undefined4 uStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017ddb08;
  pvStack_10 = ExceptionList;
  auStack_3c[0] = param_1;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_34 = param_3;
  uStack_2c = param_5;
  uStack_28 = param_6;
  piStack_30 = param_4;
  uStack_24 = param_7;
  uStack_8 = 1;
  uStack_7 = 0;
  cVar5 = FUN_00585a40(auStack_3c);
  piVar1 = piStack_30;
  uVar4 = uStack_34;
  uVar3 = auStack_3c[0];
  if (cVar5 == '\0') {
    if (piStack_30 != (int *)0x0) {
      LOCK();
      piStack_30[2] = piStack_30[2] + 1;
      UNLOCK();
    }
    uStack_14 = uStack_2c;
    uStack_18 = uStack_28;
    uStack_1c = uStack_24;
    uStack_8 = 2;
    puVar6 = (undefined4 *)FUN_01674e20(0x20);
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      *puVar6 = uVar3;
      puVar6[2] = 0;
      puVar6[3] = 0;
      if (piVar1 != (int *)0x0) {
        LOCK();
        piVar1[2] = piVar1[2] + 1;
        UNLOCK();
      }
      puVar6[2] = uVar4;
      puVar6[3] = piVar1;
      puVar6[4] = uStack_14;
      puVar6[5] = uStack_18;
      puVar6[6] = uStack_1c;
    }
    *param_9 = (int)puVar6;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_30[2] + -1;
      piStack_30[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
    uVar7 = 1;
  }
  else {
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_30[2] + -1;
      piStack_30[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
    uVar7 = 0;
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 20379 ; VA 0x00a39960 ; FUN_00a39960 */

undefined4 *
FUN_00a39960(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,int param_5)

{
  int *piVar1;
  int iVar2;
  uint in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 *in_stack_00000034;
  undefined auStack_84 [24];
  undefined4 uStack_6c;
  int iStack_68;
  undefined4 *puStack_64;
  undefined4 uStack_54;
  int iStack_50;
  undefined auStack_4c [24];
  undefined4 uStack_34;
  int aiStack_30 [5];
  uint uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ddb50;
  pvStack_10 = ExceptionList;
  puStack_64 = &param_5;
  uStack_8 = 1;
  iStack_68 = 0xa39991;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_18 = param_3;
  piStack_14 = param_4;
  puStack_64 = in_stack_00000034;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  iStack_68 = in_stack_00000030;
  uStack_6c = in_stack_0000002c;
  in_stack_00000034 = (undefined4 *)auStack_84;
  FUN_0054ef60(aiStack_30);
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  FUN_00a3aeb0(param_3,param_4);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_64 = (undefined4 *)0xa39a04;
      (**(code **)(*param_4 + 4))();
    }
  }
  uStack_8._0_1_ = 1;
  if (0xf < uStack_1c) {
    puStack_64 = (undefined4 *)(uStack_1c + 1);
    iVar2 = aiStack_30[0];
    if (0xfff < puStack_64) {
      iVar2 = *(int *)(aiStack_30[0] + -4);
      puStack_64 = (undefined4 *)(uStack_1c + 0x24);
      if (0x1f < (aiStack_30[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_64 = (undefined4 *)0xa39ae7;
        FUN_017167a3();
      }
    }
    uStack_6c = 0xa39a39;
    iStack_68 = iVar2;
    FUN_01674ea0();
  }
  in_stack_00000034 = param_1 + 1;
  *param_1 = param_2;
  *in_stack_00000034 = 0;
  param_1[2] = 0;
  if (iStack_50 != 0) {
    LOCK();
    *(int *)(iStack_50 + 8) = *(int *)(iStack_50 + 8) + 1;
    UNLOCK();
  }
  *in_stack_00000034 = uStack_54;
  param_1[2] = iStack_50;
  puStack_64 = (undefined4 *)auStack_4c;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  iStack_68 = 0xa39a7d;
  FUN_0054ef60();
  param_1[9] = uStack_34;
  puStack_64 = (undefined4 *)0xa39a8b;
  FUN_005d11a0();
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_64 = (undefined4 *)0xa39a9f;
      (**(code **)(*param_4 + 4))();
    }
  }
  if (0xf < in_stack_00000028) {
    puStack_64 = (undefined4 *)(in_stack_00000028 + 1);
    iVar2 = param_5;
    if (0xfff < puStack_64) {
      iVar2 = *(int *)(param_5 + -4);
      puStack_64 = (undefined4 *)(in_stack_00000028 + 0x24);
      if (0x1f < (param_5 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_64 = (undefined4 *)&UNK_00a39aec;
        FUN_017167a3();
      }
    }
    uStack_6c = 0xa39acc;
    iStack_68 = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20380 ; VA 0x00a39af0 ; FUN_00a39af0 */

undefined4 *
FUN_00a39af0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  int *piVar1;
  int iVar2;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
    piVar1 = param_4 + 2;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_4 + 4))();
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_4 + 4))();
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_4 + 4))();
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_4 + 4))();
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_4 + 4))();
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  piVar1 = param_4 + 2;
  *param_1 = param_2;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_3;
  param_1[3] = param_4;
  param_1[4] = param_7;
  param_1[5] = param_8;
  param_1[6] = param_9;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 20381 ; VA 0x00a39bf0 ; FUN_00a39bf0 */

undefined4 *
FUN_00a39bf0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_20;
  int *piStack_1c;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
    piVar1 = param_4 + 2;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  piVar1 = param_4 + 2;
  if (param_4 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00a3acd0(param_3,param_4,param_5,param_6);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_4 + 4))();
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_4 + 4))();
    }
    if (param_4 != (int *)0x0) {
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  *param_1 = param_2;
  param_1[2] = 0;
  param_1[3] = 0;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piStack_1c[2] = piStack_1c[2] + 1;
    UNLOCK();
  }
  param_1[2] = uStack_20;
  param_1[3] = piStack_1c;
  param_1[4] = param_7;
  param_1[5] = param_8;
  param_1[6] = param_9;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[2] + -1;
    piStack_1c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_1c + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 20382 ; VA 0x00a39cf0 ; FUN_00a39cf0 */

void FUN_00a39cf0(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  *param_2 = 0;
  param_2[1] = 0;
  *param_2 = *param_3;
  param_2[1] = param_3[1];
  *param_3 = 0;
  param_3[1] = 0;
  param_2[2] = param_3[2];
  param_2[4] = param_3[4];
  param_2[5] = param_3[5];
  param_2[10] = 0;
  param_2[0xb] = 0;
  uVar1 = param_3[7];
  uVar2 = param_3[8];
  uVar3 = param_3[9];
  param_2[6] = param_3[6];
  param_2[7] = uVar1;
  param_2[8] = uVar2;
  param_2[9] = uVar3;
  *(undefined8 *)(param_2 + 10) = *(undefined8 *)(param_3 + 10);
  param_3[10] = 0;
  param_3[0xb] = 0xf;
  *(undefined *)(param_3 + 6) = 0;
  param_2[0x10] = 0;
  param_2[0x11] = 0;
  uVar1 = param_3[0xd];
  uVar2 = param_3[0xe];
  uVar3 = param_3[0xf];
  param_2[0xc] = param_3[0xc];
  param_2[0xd] = uVar1;
  param_2[0xe] = uVar2;
  param_2[0xf] = uVar3;
  *(undefined8 *)(param_2 + 0x10) = *(undefined8 *)(param_3 + 0x10);
  param_3[0x10] = 0;
  param_3[0x11] = 0xf;
  *(undefined *)(param_3 + 0xc) = 0;
  return;
}



/* FUNCTION 20383 ; VA 0x00a39da0 ; FUN_00a39da0 */

undefined4 * FUN_00a39da0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ddb93;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00fd0780();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x14c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00fd35a0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00a37f40(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20384 ; VA 0x00a39e60 ; FUN_00a39e60 */

undefined4 * FUN_00a39e60(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ddbee;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00a36e80();
  uVar3 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar2 + 0x1dc) != (undefined4 *)0x0) {
    uVar3 = **(undefined4 **)(iVar2 + 0x1dc);
  }
  uVar3 = FUN_01675290(uVar3);
  uStack_8 = 1;
  puVar4 = (undefined4 *)FUN_01674e20(0xc0);
  uStack_8._0_1_ = 2;
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar4 = RBX::Described<class_RBX::TranslatorInstance,class_RBX::Instance>::vftable;
    uVar5 = FUN_00a36e80();
    puVar4[3] = uVar5;
    puVar4[0x15] = RBX::Localization::ParameterTranslator::vftable;
    *(undefined *)((int)puVar4 + 0x22) = 1;
    *puVar4 = RBX::PlayerLocaleLocalizationServiceTranslatorInstance::vftable;
    puVar4[0x15] = RBX::PlayerLocaleLocalizationServiceTranslatorInstance::vftable;
    puVar4[0x1a] = 0;
    puVar4[0x1b] = 0xf;
    *(undefined *)(puVar4 + 0x16) = 0;
    uStack_8._0_1_ = 5;
    FUN_00fc1ff0();
    puVar4[0x26] = 0;
    puVar4[0x27] = 0;
    if (param_3[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_3[1] + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    puVar4[0x26] = *param_3;
    puVar4[0x27] = param_3[1];
    puVar4[0x28] = 0;
    puVar4[0x29] = 0;
    if (param_2[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[1] + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    puVar4[0x28] = *param_2;
    puVar4[0x29] = param_2[1];
    puVar4[0x2e] = 0;
    puVar4[0x2f] = 0xf;
    *(undefined *)(puVar4 + 0x2a) = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00a38030(puVar4,param_1);
  uStack_8 = 9;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20385 ; VA 0x00a3a000 ; FUN_00a3a000 */

undefined4 *
FUN_00a3a000(undefined4 *param_1,undefined4 *param_2,undefined4 param_3,undefined4 *param_4)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int *piVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ddc72;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00a36e80();
  uVar4 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar3 + 0x1dc) != (undefined4 *)0x0) {
    uVar4 = **(undefined4 **)(iVar3 + 0x1dc);
  }
  uVar4 = FUN_01675290(uVar4);
  uStack_8 = 1;
  puVar5 = (undefined4 *)FUN_01674e20(0xc0);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    piVar7 = (int *)param_2[1];
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar7[2] = piVar7[2] + 1;
      UNLOCK();
      piVar7 = (int *)param_2[1];
    }
    uVar2 = *param_2;
    uStack_8._0_1_ = 3;
    FUN_0089a7a0();
    uStack_8._0_1_ = 4;
    *puVar5 = RBX::Described<class_RBX::TranslatorInstance,class_RBX::Instance>::vftable;
    uVar6 = FUN_00a36e80();
    puVar5[3] = uVar6;
    puVar5[0x15] = RBX::Localization::ParameterTranslator::vftable;
    *(undefined *)((int)puVar5 + 0x22) = 1;
    *puVar5 = RBX::PlayerLocaleLocalizationServiceTranslatorInstance::vftable;
    puVar5[0x15] = RBX::PlayerLocaleLocalizationServiceTranslatorInstance::vftable;
    puVar5[0x1a] = 0;
    puVar5[0x1b] = 0xf;
    *(undefined *)(puVar5 + 0x16) = 0;
    uStack_8._0_1_ = 6;
    FUN_00fc1ff0();
    puVar5[0x26] = 0;
    puVar5[0x27] = 0;
    if (param_4[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_4[1] + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    puVar5[0x26] = *param_4;
    puVar5[0x27] = param_4[1];
    puVar5[0x28] = 0;
    puVar5[0x29] = 0;
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar7[2] = piVar7[2] + 1;
      UNLOCK();
    }
    puVar5[0x28] = uVar2;
    puVar5[0x29] = piVar7;
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    FUN_0054ef60(param_3);
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar3 = piVar7[2] + -1;
      piVar7[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00a38030(puVar5,param_1);
  uStack_8 = 0xc;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20386 ; VA 0x00a3a1c0 ; FUN_00a3a1c0 */

void FUN_00a3a1c0(undefined4 param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = param_2[6];
  if (iVar4 != 0) {
    iVar2 = param_2[7];
    if (iVar4 != iVar2) {
      do {
        FUN_005e6080();
        iVar4 = iVar4 + 0x50;
      } while (iVar4 != iVar2);
      iVar4 = param_2[6];
    }
    uVar1 = ((param_2[8] - iVar4) / 0x50) * 0x50;
    iVar2 = iVar4;
    if (0xfff < uVar1) {
      iVar2 = *(int *)(iVar4 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar4 - iVar2) - 4U) goto LAB_00a3a281;
    }
    FUN_01674ea0(iVar2,uVar1);
    param_2[6] = 0;
    param_2[7] = 0;
    param_2[8] = 0;
  }
  uVar1 = param_2[5];
  if (0xf < uVar1) {
    iVar4 = *param_2;
    uVar3 = uVar1 + 1;
    iVar2 = iVar4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar4 + -4);
      uVar3 = uVar1 + 0x24;
      if (0x1f < (iVar4 - iVar2) - 4U) {
LAB_00a3a281:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  return;
}



/* FUNCTION 20387 ; VA 0x00a3a290 ; FUN_00a3a290 */

void FUN_00a3a290(undefined4 param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  
  piVar3 = (int *)(param_2 + 8);
  if (*piVar3 != 0) {
    FUN_00a37130(*piVar3,*(undefined4 *)(param_2 + 0xc),piVar3);
    iVar1 = *piVar3;
    uVar2 = ((*(int *)(param_2 + 0x10) - iVar1) / 0x48) * 0x48;
    iVar4 = iVar1;
    if (0xfff < uVar2) {
      iVar4 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar2);
    *piVar3 = 0;
    *(undefined4 *)(param_2 + 0xc) = 0;
    *(undefined4 *)(param_2 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 20388 ; VA 0x00a3a310 ; FUN_00a3a310 */

void __thiscall FUN_00a3a310(int param_1,int *param_2,int *param_3)

{
  byte *pbVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  uint uVar5;
  int *piVar6;
  
  piVar6 = param_3 + 2;
  if (0xf < (uint)param_3[7]) {
    piVar6 = (int *)param_3[2];
  }
  uVar3 = 0;
  uVar5 = 0x811c9dc5;
  if (param_3[6] != 0) {
    do {
      pbVar1 = (byte *)(uVar3 + (int)piVar6);
      uVar3 = uVar3 + 1;
      uVar5 = (*pbVar1 ^ uVar5) * 0x1000193;
    } while (uVar3 < (uint)param_3[6]);
  }
  iVar2 = (*(uint *)(param_1 + 0x18) & uVar5) * 8;
  piVar6 = *(int **)(*(int *)(param_1 + 0xc) + iVar2);
  piVar4 = (int *)(*(int *)(param_1 + 0xc) + iVar2);
  if ((int *)piVar4[1] == param_3) {
    if (piVar6 == param_3) {
      *piVar4 = *(int *)(param_1 + 4);
      *(undefined4 *)(iVar2 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar4[1] = param_3[1];
    }
  }
  else if (piVar6 == param_3) {
    *piVar4 = *param_3;
  }
  iVar2 = *param_3;
  *(int *)param_3[1] = iVar2;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_005509f0();
  FUN_01674ea0(param_3,0x38);
  *param_2 = iVar2;
  return;
}



/* FUNCTION 20389 ; VA 0x00a3a3c0 ; FUN_00a3a3c0 */

void __thiscall FUN_00a3a3c0(int param_1,int *param_2,int *param_3)

{
  byte *pbVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  uint uVar5;
  int *piVar6;
  
  piVar6 = param_3 + 2;
  if (0xf < (uint)param_3[7]) {
    piVar6 = (int *)param_3[2];
  }
  uVar3 = 0;
  uVar5 = 0x811c9dc5;
  if (param_3[6] != 0) {
    do {
      pbVar1 = (byte *)(uVar3 + (int)piVar6);
      uVar3 = uVar3 + 1;
      uVar5 = (*pbVar1 ^ uVar5) * 0x1000193;
    } while (uVar3 < (uint)param_3[6]);
  }
  iVar2 = (*(uint *)(param_1 + 0x18) & uVar5) * 8;
  piVar6 = *(int **)(*(int *)(param_1 + 0xc) + iVar2);
  piVar4 = (int *)(*(int *)(param_1 + 0xc) + iVar2);
  if ((int *)piVar4[1] == param_3) {
    if (piVar6 == param_3) {
      *piVar4 = *(int *)(param_1 + 4);
      *(undefined4 *)(iVar2 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar4[1] = param_3[1];
    }
  }
  else if (piVar6 == param_3) {
    *piVar4 = *param_3;
  }
  iVar2 = *param_3;
  *(int *)param_3[1] = iVar2;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_008c3170();
  FUN_01674ea0(param_3,0x40);
  *param_2 = iVar2;
  return;
}



/* FUNCTION 20390 ; VA 0x00a3a470 ; FUN_00a3a470 */

int * FUN_00a3a470(int *param_1,int *param_2)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if ((*param_2 == 0) ||
     (iVar7 = *(int *)(*param_2 + 0xc), iVar5 = FUN_00fd0780(),
     (uint)*(ushort *)(iVar5 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
    piStack_c = (int *)0x0;
    puVar6 = &uStack_10;
    bVar3 = false;
    bVar2 = true;
    iVar7 = 0;
  }
  else {
    piStack_14 = (int *)param_2[1];
    iVar7 = *param_2;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = (int *)param_2[1];
    }
    puVar6 = &uStack_18;
    bVar3 = true;
    bVar2 = false;
  }
  iVar5 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  piVar4 = piStack_c;
  param_1[1] = iVar5;
  *param_1 = iVar7;
  if ((bVar2) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_c[1] + -1;
    piStack_c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_14;
  if ((bVar3) && (piStack_14 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_14[1] + -1;
    piStack_14[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 20391 ; VA 0x00a3a560 ; FUN_00a3a560 */

int __fastcall FUN_00a3a560(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  iVar1 = *(int *)(param_1 + 0x34);
  piVar4 = (int *)(param_1 + 0x34);
  while( true ) {
    if (iVar1 == 0) {
      return 0;
    }
    iVar2 = *(int *)(iVar1 + 0xc);
    iVar3 = FUN_00b56db0();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) break;
    piVar4 = (int *)(*piVar4 + 0x34);
    iVar1 = *piVar4;
  }
  return iVar1;
}



/* FUNCTION 20392 ; VA 0x00a3a5b0 ; FUN_00a3a5b0 */

int * __thiscall FUN_00a3a5b0(int *param_1,int *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  iVar4 = *param_1;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0088cbe0();
  if (iVar4 != iVar1) {
    puVar2 = (undefined4 *)param_1[1];
    if (puVar2 != (undefined4 *)0x0) {
      (*(code *)*puVar2)(param_1 + 2,auStack_d8);
      puVar2 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    piVar3 = (int *)FUN_00889d70();
    iVar4 = piVar3[1];
    *param_2 = 0;
    param_2[1] = 0;
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
      UNLOCK();
      iVar4 = piVar3[1];
    }
    *param_2 = *piVar3;
    param_2[1] = iVar4;
    uStack_8 = 1;
    if (puVar2 != (undefined4 *)0x0) {
      (*(code *)puVar2[2])(auStack_d8);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar4 = *param_1;
  iVar1 = FUN_0088cbe0();
  if (iVar4 == iVar1) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    iVar4 = piVar3[1];
    *param_2 = 0;
    param_2[1] = 0;
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
      UNLOCK();
      iVar4 = piVar3[1];
    }
    *param_2 = *piVar3;
    param_2[1] = iVar4;
    ExceptionList = pvStack_10;
    return param_2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 20393 ; VA 0x00a3a6e0 ; FUN_00a3a6e0 */

void FUN_00a3a6e0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  int iVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ddc98;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_2;
  iVar9 = *piVar1;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_0088c8c0();
  if (iVar9 != iVar4) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  piVar5 = piVar1 + 2;
  iVar9 = *param_2;
  if (piVar1[1] == 0) {
    piVar5 = (int *)0x0;
  }
  iVar4 = *(int *)(iVar9 + 0x1a0);
  iVar2 = *piVar5;
  iVar6 = FUN_0088cbe0();
  if (iVar4 == iVar6) {
    puVar7 = (undefined4 *)(iVar9 + 0x1a8);
    if (*(int *)(iVar9 + 0x1a4) == 0) {
      puVar7 = (undefined4 *)0x0;
    }
    iVar9 = puVar7[1];
    if (iVar9 != 0) {
      LOCK();
      *(int *)(iVar9 + 4) = *(int *)(iVar9 + 4) + 1;
      UNLOCK();
      iVar9 = puVar7[1];
    }
    uVar3 = *puVar7;
    iVar4 = *param_2;
    uStack_8 = 0;
    iVar6 = *(int *)(iVar4 + 0xd0);
    iVar8 = FUN_0088cdc0();
    if (iVar6 == iVar8) {
      puVar7 = (undefined4 *)(iVar4 + 0xd8);
      if (*(int *)(iVar4 + 0xd4) == 0) {
        puVar7 = (undefined4 *)0x0;
      }
      iVar4 = puVar7[1];
      if (iVar4 != 0) {
        LOCK();
        *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
        UNLOCK();
        iVar4 = puVar7[1];
      }
      uStack_8 = 2;
      FUN_00a3d5b0(iVar2,*puVar7,iVar4,uVar3,iVar9);
      ExceptionList = pvStack_10;
      return;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 20394 ; VA 0x00a3a820 ; FUN_00a3a820 */

undefined4 * __thiscall FUN_00a3a820(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ddcb8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  *(undefined *)(param_1 + 2) = *(undefined *)(param_2 + 2);
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  *(undefined *)(param_1 + 6) = *(undefined *)(param_2 + 6);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 7);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20395 ; VA 0x00a3a8b0 ; FUN_00a3a8b0 */

undefined4 * __thiscall
FUN_00a3a8b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,int *param_7,undefined4 param_8,undefined8 param_9
            ,undefined4 param_10)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ddd23;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar3 = FUN_00a36d80();
  FUN_009cb790(uVar3,param_4,param_8,param_9,param_10);
  param_1[0xe] = param_2;
  uStack_8._0_1_ = 1;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::LocalizationService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(class_std::shared_ptr<class_RBX::Instance>_const&),1>
             ::vftable;
  param_1[0xf] = param_3;
  puVar4 = (undefined4 *)FUN_01674e20(8);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 0;
    if (param_7 != (int *)0x0) {
      LOCK();
      param_7[1] = param_7[1] + 1;
      UNLOCK();
    }
    *puVar4 = param_6;
    puVar4[1] = param_7;
  }
  param_1[0x10] = puVar4;
  uStack_8._0_1_ = 2;
  uVar3 = FUN_008882f0();
  param_1[9] = uVar3;
  puVar4 = (undefined4 *)param_1[0x10];
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar4 = &uStack_1b8;
    uStack_8 = 4;
    uVar6 = 2;
  }
  else {
    uStack_e8 = FUN_0088cdc0();
    iStack_e4 = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e0 = *puVar4;
    uStack_dc = puVar4[1];
    iStack_e4 = FUN_006309e0();
    puVar4 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    uVar6 = 1;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088cdc0();
  uVar5 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar5,uVar3,puVar4);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 5;
    uStack_14 = uVar6;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  uStack_8 = 2;
  if ((uVar6 & 1) != 0) {
    uStack_8 = 6;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(&uStack_e0);
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20396 ; VA 0x00a3aab0 ; FUN_00a3aab0 */

uint * __thiscall FUN_00a3aab0(uint *param_1,uint param_2)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ddd51;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[1] = 0;
  uVar1 = param_2;
  if (param_2 == 0) {
    uVar1 = 1;
  }
  *param_1 = uVar1;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  if (param_2 == 0) {
    param_2 = 1;
  }
  uStack_8 = 2;
  if ((uint)((int)(param_1[4] - param_1[2]) >> 2) < param_2) {
    if (0x3fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_007cfd20(param_2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20397 ; VA 0x00a3ab70 ; FUN_00a3ab70 */

undefined4 * __thiscall FUN_00a3ab70(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ddd76;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar1 = FUN_00970740(0,0);
  param_1[1] = uVar1;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  uStack_8 = 1;
  *param_1 = 0x3f800000;
  FUN_005cb500(8);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20398 ; VA 0x00a3ac00 ; FUN_00a3ac00 */

undefined4 * __thiscall FUN_00a3ac00(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ddd88;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 3);
  param_1[9] = param_2[9];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20399 ; VA 0x00a3ac80 ; FUN_00a3ac80 */

undefined4 * __thiscall FUN_00a3ac80(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = *param_2;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  param_1[6] = param_2[6];
  return param_1;
}



/* FUNCTION 20400 ; VA 0x00a3acd0 ; FUN_00a3acd0 */

undefined4 * __thiscall FUN_00a3acd0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 2;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 20401 ; VA 0x00a3ad60 ; FUN_00a3ad60 */

undefined4 * __thiscall
FUN_00a3ad60(undefined4 *param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000020;
  int aiStack_34 [5];
  uint uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dddc8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60(&param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_1c = param_2;
  piStack_18 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 2;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_0054ef60(aiStack_34);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (0xf < uStack_20) {
    uVar3 = uStack_20 + 1;
    iVar2 = aiStack_34[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_34[0] + -4);
      uVar3 = uStack_20 + 0x24;
      if (0x1f < (aiStack_34[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    uVar3 = in_stack_00000020 + 1;
    iVar2 = param_4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_4 + -4);
      uVar3 = in_stack_00000020 + 0x24;
      if (0x1f < (param_4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20402 ; VA 0x00a3aeb0 ; FUN_00a3aeb0 */

int __thiscall FUN_00a3aeb0(int param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined4 in_stack_0000002c;
  undefined auStack_5c [16];
  undefined4 uStack_4c;
  int iStack_48;
  undefined4 *puStack_44;
  int aiStack_34 [5];
  uint uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dde00;
  pvStack_10 = ExceptionList;
  puStack_44 = &param_4;
  uStack_8 = 1;
  iStack_48 = 0xa3aee6;
  ExceptionList = &pvStack_10;
  puStack_14 = (undefined *)param_1;
  FUN_0054ef60();
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_1c = param_2;
  piStack_18 = param_3;
  puStack_44 = (undefined4 *)in_stack_00000024;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  puStack_14 = auStack_5c;
  FUN_0054ef60(aiStack_34);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  FUN_00a3ad60(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_44 = (undefined4 *)0xa3af52;
      (**(code **)(*param_3 + 4))();
    }
  }
  if (0xf < uStack_20) {
    puStack_44 = (undefined4 *)(uStack_20 + 1);
    iVar2 = aiStack_34[0];
    if (0xfff < puStack_44) {
      iVar2 = *(int *)(aiStack_34[0] + -4);
      puStack_44 = (undefined4 *)(uStack_20 + 0x24);
      if (0x1f < (aiStack_34[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_44 = (undefined4 *)0xa3afe6;
        FUN_017167a3();
      }
    }
    uStack_4c = 0xa3af7f;
    iStack_48 = iVar2;
    FUN_01674ea0();
  }
  *(undefined4 *)(param_1 + 0x20) = in_stack_0000002c;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_44 = (undefined4 *)0xa3af9c;
      (**(code **)(*param_3 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    puStack_44 = (undefined4 *)(in_stack_00000020 + 1);
    iVar2 = param_4;
    if (0xfff < puStack_44) {
      iVar2 = *(int *)(param_4 + -4);
      puStack_44 = (undefined4 *)(in_stack_00000020 + 0x24);
      if (0x1f < (param_4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_44 = (undefined4 *)&UNK_00a3afeb;
        FUN_017167a3();
      }
    }
    uStack_4c = 0xa3afc9;
    iStack_48 = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20403 ; VA 0x00a3aff0 ; FUN_00a3aff0 */

undefined4 * __fastcall FUN_00a3aff0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ddd76;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar1 = FUN_00970740(0,0);
  param_1[1] = uVar1;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  uStack_8 = 1;
  *param_1 = 0x3f800000;
  FUN_005cb500(8);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20404 ; VA 0x00a3b080 ; FUN_00a3b080 */

undefined4 * __thiscall
FUN_00a3b080(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  int in_stack_00000024;
  uint in_stack_00000038;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dde2b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  param_1[1] = param_3;
  uStack_8 = 1;
  FUN_0054ef60(&param_4);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0054ef60(&stack0x00000024);
  if (0xf < in_stack_00000020) {
    uVar2 = in_stack_00000020 + 1;
    uVar3 = param_4;
    if (0xfff < uVar2) {
      uVar3 = *(uint *)(param_4 - 4);
      uVar2 = in_stack_00000020 + 0x24;
      if (0x1f < (param_4 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar2);
  }
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_4 = param_4 & 0xffffff00;
  if (0xf < in_stack_00000038) {
    uVar3 = in_stack_00000038 + 1;
    iVar1 = in_stack_00000024;
    if (0xfff < uVar3) {
      iVar1 = *(int *)(in_stack_00000024 + -4);
      uVar3 = in_stack_00000038 + 0x24;
      if (0x1f < (in_stack_00000024 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20405 ; VA 0x00a3b160 ; FUN_00a3b160 */

uint * __thiscall FUN_00a3b160(uint *param_1,uint *param_2)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dde48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uVar2 = *param_2;
  if (uVar2 != 0) {
    *param_1 = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
    }
    else {
      uVar2 = param_2[3];
      uVar3 = param_2[4];
      uVar4 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar2;
      param_1[4] = uVar3;
      param_1[5] = uVar4;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
    }
  }
  param_1[8] = 0;
  uVar2 = param_2[8];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[8] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 10,param_1 + 10,0);
    }
    else {
      uVar2 = param_2[0xb];
      uVar3 = param_2[0xc];
      uVar4 = param_2[0xd];
      param_1[10] = param_2[10];
      param_1[0xb] = uVar2;
      param_1[0xc] = uVar3;
      param_1[0xd] = uVar4;
      *(undefined8 *)(param_1 + 0xe) = *(undefined8 *)(param_2 + 0xe);
    }
  }
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  if (param_2[0x11] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0x11] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x10] = param_2[0x10];
  param_1[0x11] = param_2[0x11];
  param_1[0x12] = param_2[0x12];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20406 ; VA 0x00a3b250 ; FUN_00a3b250 */

uint * __thiscall
FUN_00a3b250(uint *param_1,uint param_2,int *param_3,uint param_4,undefined4 param_5,uint param_6,
            uint param_7,uint param_8,uint param_9,undefined8 param_10,uint param_11,
            undefined4 param_12,uint param_13,uint param_14,uint param_15,uint param_16,
            undefined8 param_17,uint param_18)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dde80;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  if (param_4 != 0) {
    *param_1 = param_4;
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,param_1 + 2,0);
    }
    else {
      param_1[2] = param_6;
      param_1[3] = param_7;
      param_1[4] = param_8;
      param_1[5] = param_9;
      *(undefined8 *)(param_1 + 6) = param_10;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  param_1[8] = 0;
  if (param_11 != 0) {
    param_1[8] = param_11;
    if ((param_11 & 1) == 0) {
      (**(code **)(param_11 & 0xfffffffe))(&param_13,param_1 + 10,0);
    }
    else {
      param_1[10] = param_13;
      param_1[0xb] = param_14;
      param_1[0xc] = param_15;
      param_1[0xd] = param_16;
      *(undefined8 *)(param_1 + 0xe) = param_17;
    }
  }
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  param_1[0x10] = param_2;
  param_1[0x11] = (uint)param_3;
  param_1[0x12] = param_18;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_4 & 0xfffffffe))(&param_6,&param_6,2);
  }
  uStack_8 = 5;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_11 & 0xfffffffe))(&param_13,&param_13,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20407 ; VA 0x00a3b3c0 ; FUN_00a3b3c0 */

undefined4 * __fastcall FUN_00a3b3c0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined **ppuVar6;
  int *piVar7;
  undefined **ppuVar8;
  uint uVar9;
  uint uVar10;
  uint auStack_30 [2];
  code *pcStack_28;
  undefined4 uStack_24;
  undefined4 *puStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de092;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::LocalizationService,class_RBX::ServiceInstance>::
             vftable;
  uVar4 = FUN_00a36d80();
  param_1[3] = uVar4;
  *param_1 = RBX::LocalizationService::vftable;
  uStack_8 = 1;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  pcStack_28 = FUN_00a431c0;
  uStack_24 = 0;
  puStack_20 = param_1;
  cVar3 = FUN_00585a40(&pcStack_28);
  if (cVar3 == '\0') {
    param_1[0x1a] = pcStack_28;
    param_1[0x1b] = uStack_24;
    param_1[0x1c] = puStack_20;
    param_1[0x1d] = uStack_1c;
    param_1[0x18] = &DAT_01942f3d;
  }
  else {
    param_1[0x18] = 0;
  }
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = param_1;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  puVar5 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    puVar5[1] = 1;
    puVar5[2] = 1;
    *puVar5 = std::_Ref_count_obj<class_RBX::LocalizationServiceStatReporter>::vftable;
    puVar5[3] = 0;
    puVar5[4] = 0;
    puVar5[5] = 0;
    puVar5[6] = 0;
    *(undefined8 *)(puVar5 + 7) = 0;
    puVar5[9] = 0;
    puVar5[3] = RBX::LocalizationServiceStatReporterBase::vftable;
    *(undefined *)(puVar5 + 4) = 0;
    piStack_14 = (int *)0xb;
    ppuVar6 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&piStack_14);
    ppuVar8 = ppuVar6 + -1;
    if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar8 = ppuVar6;
    }
    puVar5[5] = *ppuVar8;
    puVar5[6] = 0;
    puVar5[7] = 0x3f800000;
    puVar5[8] = 0;
    puVar5[9] = 0;
    puVar5[3] = RBX::LocalizationServiceStatReporter::vftable;
  }
  param_1[0x2c] = puVar5;
  param_1[0x2b] = puVar5 + 3;
  piStack_14 = param_1 + 0x2d;
  uStack_8._0_1_ = 7;
  FUN_00a3aab0(DAT_01d66028);
  uStack_8._0_1_ = 8;
  FUN_00a3aab0(DAT_01d66028);
  param_1[0x41] = 0;
  param_1[0x46] = 0;
  param_1[0x47] = 0xf;
  *(undefined *)(param_1 + 0x42) = 0;
  param_1[0x48] = 0;
  param_1[0x49] = 0;
  piStack_14 = param_1 + 0x4a;
  uStack_8._0_1_ = 10;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0xf;
  *(undefined *)piStack_14 = 0;
  FUN_005542c0("en-us",5);
  piStack_14 = param_1 + 0x50;
  uStack_8._0_1_ = 0xb;
  param_1[0x54] = 0;
  param_1[0x55] = 0xf;
  *(undefined *)piStack_14 = 0;
  FUN_005542c0("en-us",5);
  param_1[0x5a] = 0;
  param_1[0x5b] = 0xf;
  *(undefined *)(param_1 + 0x56) = 0;
  uStack_8._0_1_ = 0xd;
  param_1[0x60] = 0;
  param_1[0x61] = 0xf;
  *(undefined *)(param_1 + 0x5c) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 0xe;
  param_1[0x66] = 0;
  param_1[0x67] = 0xf;
  *(undefined *)(param_1 + 0x62) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 0xf;
  param_1[0x6c] = 0;
  param_1[0x6d] = 0xf;
  *(undefined *)(param_1 + 0x68) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  param_1[0x72] = 0;
  param_1[0x73] = 0xf;
  *(undefined *)(param_1 + 0x6e) = 0;
  param_1[0x78] = 0;
  param_1[0x79] = 0xf;
  *(undefined *)(param_1 + 0x74) = 0;
  param_1[0x7e] = 0;
  param_1[0x7f] = 0xf;
  *(undefined *)(param_1 + 0x7a) = 0;
  param_1[0x84] = 0;
  param_1[0x85] = 0xf;
  *(undefined *)(param_1 + 0x80) = 0;
  uStack_8._0_1_ = 0x14;
  param_1[0x8a] = 0;
  param_1[0x8b] = 0xf;
  *(undefined *)(param_1 + 0x86) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  param_1[0x8c] = 0;
  param_1[0x8d] = 0;
  *(undefined *)(param_1 + 0x8e) = 0;
  piStack_14 = (int *)0xb;
  ppuVar6 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&piStack_14);
  ppuVar8 = ppuVar6 + -1;
  if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar8 = ppuVar6;
  }
  param_1[0x8f] = *ppuVar8;
  param_1[0x90] = 0;
  param_1[0x91] = 0x3f800000;
  param_1[0x92] = 0;
  param_1[0x93] = 0;
  *(undefined *)(param_1 + 0x94) = 0;
  *(undefined *)(param_1 + 0x95) = 0;
  piStack_14 = (int *)0xb;
  ppuVar6 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&piStack_14);
  ppuVar8 = ppuVar6 + -1;
  if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar8 = ppuVar6;
  }
  param_1[0x96] = *ppuVar8;
  param_1[0x97] = 0;
  param_1[0x98] = 0x3f800000;
  param_1[0x99] = 0;
  param_1[0x9a] = 0;
  param_1[0x9f] = 0;
  param_1[0xa0] = 0xf;
  *(undefined *)(param_1 + 0x9b) = 0;
  piVar7 = param_1 + 0xa1;
  uStack_8._0_1_ = 0x19;
  *piVar7 = 0;
  param_1[0xa2] = 0;
  param_1[0xa3] = 0;
  piStack_14 = piVar7;
  uVar4 = FUN_00970740(0,0);
  param_1[0xa2] = uVar4;
  param_1[0xa4] = 0;
  param_1[0xa5] = 0;
  param_1[0xa6] = 0;
  uStack_8._0_1_ = 0x1b;
  *piVar7 = 0x3f800000;
  FUN_005cb500(8);
  puVar5 = puStack_18;
  *(undefined *)(puStack_18 + 0xa9) = 0;
  puStack_18[0xaa] = 0;
  puStack_18[0xab] = 0;
  puStack_18[0xac] = 0;
  puStack_18[0xad] = 0;
  puStack_18[0xae] = 0;
  puStack_18[0xaf] = 0;
  *(undefined2 *)(puStack_18 + 0xb0) = 0;
  *(undefined *)((int)puStack_18 + 0x2c2) = 0;
  puStack_18[0xb1] = 0;
  puStack_18[0xb2] = 0;
  *(undefined *)(puStack_18 + 0xb3) = 0;
  piStack_14 = (int *)0xb;
  ppuVar6 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&piStack_14);
  ppuVar8 = ppuVar6 + -1;
  if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar8 = ppuVar6;
  }
  puVar5[0xb4] = *ppuVar8;
  puVar5[0xb5] = 0;
  puVar5[0xb6] = 0x3f800000;
  puVar5[0xb7] = 0;
  puVar5[0xb8] = 0;
  puVar5[0xb9] = 0;
  puVar5[0xba] = 0;
  puVar5[0xbb] = 0;
  puVar5[0xbc] = 0;
  puVar5[0xbd] = 0;
  uStack_8._0_1_ = 0x24;
  piVar7 = (int *)FUN_01674e20(0xe8);
  uStack_8._0_1_ = 0x25;
  piStack_14 = piVar7;
  if (piVar7 == (int *)0x0) {
    piVar7 = (int *)0x0;
  }
  else {
    piVar7[1] = 1;
    piVar7[2] = 1;
    *piVar7 = (int)std::_Ref_count_obj<class_RBX::TextScraper>::vftable;
    FUN_00fc9f90();
  }
  piVar1 = piVar7 + 3;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x24);
  if ((piVar1 != (int *)0x0) && ((piVar7[4] == 0 || (*(int *)(piVar7[4] + 4) == 0)))) {
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar7[1] = piVar7[1] + 1;
      UNLOCK();
      LOCK();
      piVar7[2] = piVar7[2] + 1;
      UNLOCK();
    }
    *piVar1 = (int)piVar1;
    piVar1 = (int *)piVar7[4];
    piVar7[4] = (int)piVar7;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar2 = piVar7[1] + -1;
      piVar7[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar7)();
        LOCK();
        iVar2 = piVar7[2] + -1;
        piVar7[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
  }
  puVar5[0x48] = piVar7 + 3;
  piVar1 = (int *)puVar5[0x49];
  puVar5[0x49] = piVar7;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[1] + -1;
    piVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar7 = piVar1 + 2;
      iVar2 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  puStack_20 = (undefined4 *)0x0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("LocalizationService",0x13);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x26);
  FUN_008a6520(auStack_30);
  if (0xf < uStack_1c) {
    uVar10 = uStack_1c + 1;
    uVar9 = auStack_30[0];
    if (0xfff < uVar10) {
      uVar9 = *(uint *)(auStack_30[0] - 4);
      uVar10 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar10);
  }
  ExceptionList = pvStack_10;
  return puVar5;
}



/* FUNCTION 20408 ; VA 0x00a3baf0 ; FUN_00a3baf0 */

undefined4 * __fastcall FUN_00a3baf0(undefined4 *param_1)

{
  *param_1 = 0;
  *(undefined *)(param_1 + 1) = 0;
  param_1[6] = 0;
  param_1[7] = 0xf;
  *(undefined *)(param_1 + 2) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  param_1[8] = 0;
  param_1[9] = 0;
  return param_1;
}



/* FUNCTION 20409 ; VA 0x00a3bb40 ; FUN_00a3bb40 */

void __fastcall FUN_00a3bb40(int param_1)

{
  uint uVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  
  uVar1 = *(uint *)(param_1 + 0x30);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x1c);
    uVar5 = uVar1 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0xf;
  *(undefined *)(param_1 + 0x1c) = 0;
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[2] + -1;
    piVar3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
                    /* WARNING: Could not recover jumptable at 0x00a3bb99. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar3 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 20410 ; VA 0x00a3bbb0 ; FUN_00a3bbb0 */

void __fastcall FUN_00a3bbb0(int param_1)

{
  uint uVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  
  uVar1 = *(uint *)(param_1 + 0x20);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0xc);
    uVar5 = uVar1 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[2] + -1;
    piVar3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
                    /* WARNING: Could not recover jumptable at 0x00a3bc09. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar3 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 20411 ; VA 0x00a3bc20 ; FUN_00a3bc20 */

void __fastcall FUN_00a3bc20(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::LocalizationService>::vftable;
  uVar1 = FUN_00a36d80(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20412 ; VA 0x00a3bc60 ; FUN_00a3bc60 */

void __fastcall FUN_00a3bc60(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  LOCK();
  iVar1 = *(int *)(param_1 + 0x24);
  *(int *)(param_1 + 0x24) = 0;
  UNLOCK();
  if (iVar1 != 0) {
    CloseHandle(iVar1);
  }
  iVar1 = *(int *)(param_1 + 0x14);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x1c) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_00a3bd07;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x18) = 0;
    *(undefined4 *)(param_1 + 0x1c) = 0;
  }
  iVar1 = *(int *)(param_1 + 8);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x10) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_00a3bd07:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 8) = 0;
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 20413 ; VA 0x00a3bd10 ; FUN_00a3bd10 */

void __fastcall FUN_00a3bd10(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00a3be00();
  return;
}



/* FUNCTION 20414 ; VA 0x00a3bd70 ; FUN_00a3bd70 */

void __fastcall FUN_00a3bd70(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00a3be50();
  return;
}



/* FUNCTION 20415 ; VA 0x00a3bdd0 ; FUN_00a3bdd0 */

void __fastcall FUN_00a3bdd0(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_1[1];
  for (iVar2 = *param_1; iVar2 != iVar1; iVar2 = iVar2 + 0x50) {
    FUN_005e6080();
  }
  return;
}



/* FUNCTION 20416 ; VA 0x00a3be00 ; FUN_00a3be00 */

void __fastcall FUN_00a3be00(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = (int *)*param_1;
  piVar3 = (int *)*piVar2;
  *piVar2 = (int)piVar2;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar2 = (int *)*param_1;
  if (piVar3 != piVar2) {
    do {
      piVar1 = (int *)*piVar3;
      FUN_005509f0();
      FUN_01674ea0(piVar3,0x38);
      piVar2 = (int *)*param_1;
      piVar3 = piVar1;
    } while (piVar1 != piVar2);
  }
  FUN_01674ea0(piVar2,0x38);
  return;
}



/* FUNCTION 20417 ; VA 0x00a3be50 ; FUN_00a3be50 */

void __fastcall FUN_00a3be50(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = (int *)*param_1;
  piVar3 = (int *)*piVar2;
  *piVar2 = (int)piVar2;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar2 = (int *)*param_1;
  if (piVar3 != piVar2) {
    do {
      piVar1 = (int *)*piVar3;
      FUN_008c3170();
      FUN_01674ea0(piVar3,0x40);
      piVar2 = (int *)*param_1;
      piVar3 = piVar1;
    } while (piVar1 != piVar2);
  }
  FUN_01674ea0(piVar2,0x40);
  return;
}



/* FUNCTION 20418 ; VA 0x00a3bea0 ; FUN_00a3bea0 */

void __fastcall FUN_00a3bea0(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_00a3a1c0(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x2c);
  }
  return;
}



/* FUNCTION 20419 ; VA 0x00a3bed0 ; FUN_00a3bed0 */

void __fastcall FUN_00a3bed0(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_00a3a290(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x20);
  }
  return;
}



/* FUNCTION 20420 ; VA 0x00a3bf00 ; FUN_00a3bf00 */

void __fastcall FUN_00a3bf00(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00a3a1c0(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x2c);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 20421 ; VA 0x00a3bfb0 ; FUN_00a3bfb0 */

void __fastcall FUN_00a3bfb0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00a40750(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 20422 ; VA 0x00a3c030 ; FUN_00a3c030 */

void __fastcall FUN_00a3c030(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00a3be00();
  return;
}



/* FUNCTION 20423 ; VA 0x00a3c040 ; FUN_00a3c040 */

void __fastcall FUN_00a3c040(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00a3a1c0(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x2c);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 20424 ; VA 0x00a3c050 ; FUN_00a3c050 */

void __fastcall FUN_00a3c050(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00a40750(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 20425 ; VA 0x00a3c060 ; FUN_00a3c060 */

int __fastcall FUN_00a3c060(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_00651cc0();
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00a3c093. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar4 = (**(code **)(*piVar3 + 4))();
        return iVar4;
      }
    }
  }
  return iVar4;
}



/* FUNCTION 20426 ; VA 0x00a3c0a0 ; FUN_00a3c0a0 */

void __fastcall FUN_00a3c0a0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bd050;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::LocalizationService::vftable;
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = param_1[0xbd];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar3 = param_1[0xbc];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 2;
  FUN_01679490();
  iVar3 = param_1[0xbb];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 3;
  FUN_01679490();
  iVar3 = param_1[0xba];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 4;
  FUN_01679490();
  iVar3 = param_1[0xb9];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 0xffffffff;
  FUN_00a3bfb0();
  FUN_006d2070();
  FUN_00577ac0();
  FUN_00a3bd10();
  uVar6 = param_1[0xa0];
  if (0xf < uVar6) {
    iVar3 = param_1[0x9b];
    uVar5 = uVar6 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00a3c788;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x9f] = 0;
  param_1[0xa0] = 0xf;
  *(undefined *)(param_1 + 0x9b) = 0;
  FUN_00a3bf00();
  FUN_00612580();
  piVar1 = (int *)param_1[0x8d];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uVar6 = param_1[0x8b];
  if (0xf < uVar6) {
    iVar3 = param_1[0x86];
    uVar5 = uVar6 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00a3c788;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x8a] = 0;
  param_1[0x8b] = 0xf;
  *(undefined *)(param_1 + 0x86) = 0;
  uVar6 = param_1[0x85];
  if (0xf < uVar6) {
    iVar3 = param_1[0x80];
    uVar5 = uVar6 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00a3c788;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x84] = 0;
  param_1[0x85] = 0xf;
  *(undefined *)(param_1 + 0x80) = 0;
  uVar6 = param_1[0x7f];
  if (0xf < uVar6) {
    iVar3 = param_1[0x7a];
    uVar5 = uVar6 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00a3c788;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x7e] = 0;
  param_1[0x7f] = 0xf;
  *(undefined *)(param_1 + 0x7a) = 0;
  uVar6 = param_1[0x79];
  if (0xf < uVar6) {
    iVar3 = param_1[0x74];
    uVar5 = uVar6 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00a3c788;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x78] = 0;
  param_1[0x79] = 0xf;
  *(undefined *)(param_1 + 0x74) = 0;
  uVar6 = param_1[0x73];
  if (0xf < uVar6) {
    iVar3 = param_1[0x6e];
    uVar5 = uVar6 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00a3c788;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x72] = 0;
  param_1[0x73] = 0xf;
  *(undefined *)(param_1 + 0x6e) = 0;
  uVar6 = param_1[0x6d];
  if (0xf < uVar6) {
    iVar3 = param_1[0x68];
    uVar5 = uVar6 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00a3c788;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x6c] = 0;
  param_1[0x6d] = 0xf;
  *(undefined *)(param_1 + 0x68) = 0;
  uVar6 = param_1[0x67];
  if (0xf < uVar6) {
    iVar3 = param_1[0x62];
    uVar5 = uVar6 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00a3c788;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x66] = 0;
  param_1[0x67] = 0xf;
  *(undefined *)(param_1 + 0x62) = 0;
  uVar6 = param_1[0x61];
  if (0xf < uVar6) {
    iVar3 = param_1[0x5c];
    uVar5 = uVar6 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00a3c788;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x60] = 0;
  param_1[0x61] = 0xf;
  *(undefined *)(param_1 + 0x5c) = 0;
  uVar6 = param_1[0x5b];
  if (0xf < uVar6) {
    iVar3 = param_1[0x56];
    uVar5 = uVar6 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00a3c788;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x5a] = 0;
  param_1[0x5b] = 0xf;
  *(undefined *)(param_1 + 0x56) = 0;
  uVar6 = param_1[0x55];
  if (0xf < uVar6) {
    iVar3 = param_1[0x50];
    uVar5 = uVar6 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00a3c788;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x54] = 0;
  param_1[0x55] = 0xf;
  *(undefined *)(param_1 + 0x50) = 0;
  uVar6 = param_1[0x4f];
  if (0xf < uVar6) {
    iVar3 = param_1[0x4a];
    uVar5 = uVar6 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00a3c788;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x4e] = 0;
  param_1[0x4f] = 0xf;
  *(undefined *)(param_1 + 0x4a) = 0;
  piVar1 = (int *)param_1[0x49];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_00a3c790();
  piVar1 = (int *)param_1[0x2c];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  iVar3 = param_1[0x28];
  if (iVar3 != 0) {
    uVar6 = (param_1[0x2a] - iVar3 >> 2) * 4;
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_00a3c788:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
    param_1[0x28] = 0;
    param_1[0x29] = 0;
    param_1[0x2a] = 0;
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  uVar6 = param_1[0x18];
  uStack_8 = 5;
  if (uVar6 != 0) {
    if ((uVar6 & 1) == 0) {
      if (*(code **)(uVar6 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar6 & 0xfffffffe))(param_1 + 0x1a,param_1 + 0x1a,2);
      }
    }
    param_1[0x18] = 0;
  }
  piVar1 = (int *)param_1[0x17];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20427 ; VA 0x00a3c790 ; FUN_00a3c790 */

void __fastcall FUN_00a3c790(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x68);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x54);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 100) = 0;
  *(undefined4 *)(param_1 + 0x68) = 0xf;
  *(undefined *)(param_1 + 0x54) = 0;
  FUN_00a3bc60();
  FUN_00a3bc60();
  return;
}



/* FUNCTION 20428 ; VA 0x00a3c7f0 ; FUN_00a3c7f0 */

void __fastcall FUN_00a3c7f0(undefined4 *param_1)

{
  *param_1 = RBX::Localization::ParameterTranslator::vftable;
  return;
}



/* FUNCTION 20429 ; VA 0x00a3c800 ; FUN_00a3c800 */

void __fastcall FUN_00a3c800(undefined4 *param_1)

{
  *param_1 = RBX::TranslatorInstance::vftable;
  param_1[0x15] = RBX::Localization::ParameterTranslator::vftable;
  FUN_0089b230();
  return;
}



/* FUNCTION 20430 ; VA 0x00a3c820 ; FUN_00a3c820 */

int * __thiscall FUN_00a3c820(byte *param_1,int param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  byte *pbVar9;
  undefined4 *puVar10;
  int aiStack_3c [5];
  uint uStack_28;
  uint uStack_24;
  int *piStack_20;
  undefined2 uStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar5 = param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017de0b0;
  pvStack_10 = ExceptionList;
  pbVar9 = param_1 + *param_1 + 1;
  ExceptionList = &pvStack_10;
  uStack_14 = FUN_0055c740(pbVar9,param_2);
  FUN_00562fc0(&param_2,uStack_14,iVar5,-(uint)(pbVar9 != (byte *)0x0) & (uint)(pbVar9 + 1));
  if (param_2 != 0) {
    ExceptionList = pvStack_10;
    return (int *)(param_2 + 8);
  }
  piStack_20 = (int *)0x0;
  uStack_1c = 0;
  uStack_24 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(iVar5);
  iStack_8._0_1_ = 1;
  FUN_00a3ff00();
  piVar4 = piStack_20;
  piStack_18 = piStack_20 + 2;
  FUN_0054ef60(aiStack_3c);
  piVar4[8] = 0;
  piVar4[9] = 0;
  piVar4[10] = 0;
  uStack_1c = CONCAT11(1,(undefined)uStack_1c);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_28) {
    uVar8 = uStack_28 + 1;
    iVar5 = aiStack_3c[0];
    if (0xfff < uVar8) {
      iVar5 = *(int *)(aiStack_3c[0] + -4);
      uVar8 = uStack_28 + 0x24;
      if (0x1f < (aiStack_3c[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar8);
  }
  uVar2 = *(uint *)(param_1 + 8);
  uVar8 = uVar2 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar8 = FUN_005c9310(uVar8);
    if (uVar8 <= *(uint *)(param_1 + 4)) {
      uVar8 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar8);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar8) {
    param_2 = 1;
    uVar6 = uVar2 >> 1;
    if (uVar2 + (uVar2 >> 1) <= uVar8) {
      uVar6 = 1;
    }
    iVar5 = FUN_005c9310(uVar6 + uVar2);
    if (iVar5 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar5);
      puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar10;
      while (puVar3 != (undefined4 *)0x0) {
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) == 0
           ) {
          *piVar1 = (int)puVar10;
          puVar10 = puVar3;
        }
        else {
          *puVar10 = *puVar3;
          *puVar3 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar3;
        }
        puVar3 = (undefined4 *)*puVar10;
      }
    }
  }
  piVar4[1] = uStack_14;
  uStack_14 = uStack_14 % *(uint *)(param_1 + 4);
  piVar7 = *(int **)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
  piVar1 = (int *)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
  if (piVar7 == (int *)0x0) {
    piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar7 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar4;
    }
    *piVar1 = (int)piVar7;
    *piVar4 = *piVar7;
  }
  else {
    *piVar4 = *piVar7;
    piVar7 = (int *)*piVar1;
  }
  *piVar7 = (int)piVar4;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_18;
}



/* FUNCTION 20431 ; VA 0x00a3ca30 ; FUN_00a3ca30 */

int * __thiscall FUN_00a3ca30(int param_1,int *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  uint uVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017de0c8;
  pvStack_10 = ExceptionList;
  uVar4 = param_2[1];
  iVar5 = *param_2;
  uVar10 = uVar4;
  if (((int)uVar4 < 1) && ((int)uVar4 < 0)) {
    uVar10 = ~uVar4;
  }
  uVar10 = (uVar10 >> 2) + uVar10 * 0x40 + iVar5 ^ uVar10;
  uVar9 = uVar10 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar6 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      puVar6 = (undefined4 *)*puVar6;
    }
    for (; puVar6 != (undefined4 *)0x0; puVar6 = (undefined4 *)*puVar6) {
      if (uVar10 == puVar6[1]) {
        if ((iVar5 == puVar6[2]) && (uVar4 == puVar6[3])) {
          return puVar6 + 2;
        }
      }
      else if ((uint)puVar6[1] % *(uint *)(param_1 + 4) != uVar9) break;
    }
  }
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_01674e20(0x20);
  *piVar3 = 0;
  piVar3[1] = 0;
  piVar3[4] = 0;
  piVar3[5] = 0;
  piVar3[6] = 0;
  piVar3[7] = 0;
  piVar3[2] = iVar5;
  piVar3[3] = uVar4;
  piVar3[4] = 0;
  piVar3[5] = 0;
  piVar3[6] = 0;
  uVar9 = *(uint *)(param_1 + 8);
  uVar4 = uVar9 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar4 = FUN_005c9310(uVar4);
    if (uVar4 <= *(uint *)(param_1 + 4)) {
      uVar4 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar4);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar4) {
    uVar7 = uVar9 >> 1;
    if (uVar9 + (uVar9 >> 1) <= uVar4) {
      uVar7 = 1;
    }
    iVar5 = FUN_005c9310(uVar7 + uVar9);
    if (iVar5 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar5);
      puVar6 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar2 = (undefined4 *)*puVar6;
      while (puVar2 != (undefined4 *)0x0) {
        uVar4 = (uint)puVar2[1] % *(uint *)(param_1 + 4);
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar4 * 4) == 0) {
          *piVar1 = (int)puVar6;
          puVar6 = puVar2;
        }
        else {
          *puVar6 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar2;
        }
        puVar2 = (undefined4 *)*puVar6;
      }
    }
  }
  piVar3[1] = uVar10;
  piVar1 = (int *)(*(int *)(param_1 + 0x14) + (uVar10 % *(uint *)(param_1 + 4)) * 4);
  if ((int *)*piVar1 == (int *)0x0) {
    piVar8 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar8 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar8 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar3;
    }
    *piVar1 = (int)piVar8;
    *piVar3 = *piVar8;
  }
  else {
    *piVar3 = *(int *)*piVar1;
    piVar8 = (int *)*piVar1;
  }
  *piVar8 = (int)piVar3;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piVar3 + 2;
}



/* FUNCTION 20432 ; VA 0x00a3cc40 ; FUN_00a3cc40 */

int * __thiscall FUN_00a3cc40(int param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  int *piStack_10;
  undefined4 *puStack_c;
  int *piStack_8;
  
  piVar2 = param_2;
  FUN_0097be30(&param_2,param_2);
  if (param_2 == *(int **)(param_1 + 4)) {
    piStack_8 = piVar2;
    iVar1 = **(int **)(param_1 + 4);
    puStack_c = *(undefined4 **)(iVar1 + 4);
    uVar3 = FUN_00a37040(iVar1,puStack_c,&DAT_018bdeda,&piStack_8,(int)&param_2 + 3);
    if (*(int *)(param_1 + 8) == 0x4924923) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *(undefined4 *)(iVar1 + 4) = uVar3;
    *puStack_c = uVar3;
    FUN_00a377b0(&piStack_10,**(int **)(param_1 + 4) + 8,**(int **)(param_1 + 4));
    param_2 = piStack_10;
  }
  return param_2 + 8;
}



/* FUNCTION 20433 ; VA 0x00a3ccd0 ; FUN_00a3ccd0 */

int * __thiscall FUN_00a3ccd0(int param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  int *piStack_10;
  undefined4 *puStack_c;
  int *piStack_8;
  
  piVar2 = param_2;
  FUN_0097be30(&param_2,param_2);
  if (param_2 == *(int **)(param_1 + 4)) {
    piStack_8 = piVar2;
    iVar1 = **(int **)(param_1 + 4);
    puStack_c = *(undefined4 **)(iVar1 + 4);
    uVar3 = FUN_00a370a0(iVar1,puStack_c,&DAT_018bdeda,&piStack_8,(int)&param_2 + 3);
    if (*(int *)(param_1 + 8) == 0x4924923) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *(undefined4 *)(iVar1 + 4) = uVar3;
    *puStack_c = uVar3;
    FUN_00a377b0(&piStack_10,**(int **)(param_1 + 4) + 8,**(int **)(param_1 + 4));
    param_2 = piStack_10;
  }
  return param_2 + 8;
}



/* FUNCTION 20434 ; VA 0x00a3cd60 ; FUN_00a3cd60 */

int FUN_00a3cd60(int param_1,int param_2,undefined param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int iStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de0f0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_20);
  uStack_8 = 0;
  if (iStack_20 != 0) {
    iVar3 = FUN_008f7870(iStack_20);
    if (((iVar3 != 0) &&
        (piVar1 = (int *)(iVar3 + 0x440), iVar3 = *(int *)(iVar3 + 0x444), *piVar1 == param_1)) &&
       (iVar3 == param_2)) {
      FUN_0060e0c0(&uStack_18,iStack_20);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (piStack_14 != (int *)0x0) {
        piVar1 = piStack_14 + 2;
        LOCK();
        *piVar1 = *piVar1 + 1;
        UNLOCK();
        LOCK();
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      uVar4 = 0;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        piStack_14[2] = piStack_14[2] + 1;
        UNLOCK();
      }
      FUN_00a38890(param_3,uStack_18,piStack_14);
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_14[2] + -1;
        piStack_14[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_14 + 4))(uVar4);
        }
        LOCK();
        iVar3 = piStack_14[2] + -1;
        piStack_14[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
      iVar3 = FUN_0090ca30(uVar4);
      if (piStack_14 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_14 + 2;
        iVar2 = *piVar1;
        iVar3 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar3 = (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20435 ; VA 0x00a3ceb0 ; FUN_00a3ceb0 */

int FUN_00a3ceb0(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uStack_44;
  int *piStack_40;
  undefined auStack_3c [24];
  int iStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de128;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490();
  uStack_8 = 0;
  if (iStack_24 != 0) {
    iVar3 = FUN_008f7870();
    if (((iVar3 != 0) &&
        (piVar1 = (int *)(iVar3 + 0x440), iVar3 = *(int *)(iVar3 + 0x444), *piVar1 == param_1)) &&
       (iVar3 == param_2)) {
      FUN_0060e0c0();
      puStack_14 = &uStack_44;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[2] = piStack_18[2] + 1;
        UNLOCK();
      }
      uStack_44 = uStack_1c;
      piStack_40 = piStack_18;
      uStack_8._0_1_ = 2;
      FUN_0054ef60();
      if (piStack_40 != (int *)0x0) {
        LOCK();
        piStack_40[2] = piStack_40[2] + 1;
        UNLOCK();
      }
      uStack_8._0_1_ = 4;
      FUN_0054ef60(auStack_3c);
      uStack_8._0_1_ = 3;
      FUN_00a367e0();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_005d11a0();
      iVar3 = FUN_0090ca30();
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_18 + 2;
        iVar2 = *piVar1;
        iVar3 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar3 = (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_20 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20436 ; VA 0x00a3d020 ; FUN_00a3d020 */

int FUN_00a3d020(int param_1,int param_2,undefined param_3,undefined param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 in_stack_ffffffac;
  undefined2 uVar4;
  undefined4 uVar5;
  int iStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar4 = (undefined2)((uint)in_stack_ffffffac >> 0x10);
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de0f0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_20);
  uStack_8 = 0;
  if (iStack_20 != 0) {
    iVar3 = FUN_008f7870(iStack_20);
    if (((iVar3 != 0) &&
        (piVar1 = (int *)(iVar3 + 0x440), iVar3 = *(int *)(iVar3 + 0x444), *piVar1 == param_1)) &&
       (iVar3 == param_2)) {
      FUN_0060e0c0(&uStack_18,iStack_20);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (piStack_14 != (int *)0x0) {
        piVar1 = piStack_14 + 2;
        LOCK();
        *piVar1 = *piVar1 + 1;
        UNLOCK();
        LOCK();
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      uVar5 = 0;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        piStack_14[2] = piStack_14[2] + 1;
        UNLOCK();
      }
      FUN_00a390f0(uStack_18,piStack_14,CONCAT22(uVar4,CONCAT11(param_4,param_3)));
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_14[2] + -1;
        piStack_14[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_14 + 4))(uVar5);
        }
        LOCK();
        iVar3 = piStack_14[2] + -1;
        piStack_14[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
      iVar3 = FUN_0090ca30(uVar5);
      if (piStack_14 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_14 + 2;
        iVar2 = *piVar1;
        iVar3 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar3 = (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20437 ; VA 0x00a3d170 ; FUN_00a3d170 */

int * __fastcall FUN_00a3d170(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined *puStack_48;
  undefined4 uStack_44;
  int **ppiStack_40;
  undefined4 *puStack_3c;
  undefined4 *puStack_38;
  int *piStack_34;
  int iStack_24;
  int *piStack_20;
  undefined4 *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de148;
  pvStack_10 = ExceptionList;
  piStack_34 = &iStack_24;
  puStack_38 = (undefined4 *)0xa3d199;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_00587490();
  uStack_8 = 0;
  if (iStack_24 != 0) {
    puVar4 = (undefined4 *)(iStack_24 + 0x255 + (uint)*(byte *)(iStack_24 + 0x254));
    puStack_38 = puVar4;
    if (*(char *)(param_1 + 8) == '\0') {
      puVar6 = (undefined4 *)(param_1 + 0xc);
      puStack_3c = (undefined4 *)0xa3d2b1;
      piStack_34 = puVar6;
      puStack_3c = (undefined4 *)FUN_0055c740();
      piStack_34 = (int *)(-(uint)(puVar4 != (undefined4 *)0x0) & (int)puVar4 + 1U);
      ppiStack_40 = &puStack_18;
      uStack_44 = 0xa3d2cf;
      puStack_38 = puVar6;
      piVar3 = (int *)FUN_00562fc0();
      if (puStack_18 != (undefined4 *)0x0) {
        puStack_38 = (undefined4 *)0xa3d2e1;
        piStack_34 = puVar6;
        piStack_14 = (int *)FUN_00939b30();
        iVar5 = *piStack_14;
        iVar2 = piStack_14[1];
        if (iVar5 != iVar2) {
          do {
            puVar4 = puVar6;
            if (0xf < *(uint *)(param_1 + 0x20)) {
              puVar4 = (undefined4 *)*puVar6;
            }
            FUN_01675640(&puStack_48,"Failed to load locale: %s",puVar4);
            FUN_005e65e0();
            iVar5 = iVar5 + 0x50;
          } while (iVar5 != iVar2);
          iVar2 = piStack_14[1];
          iVar5 = *piStack_14;
          if (iVar5 != iVar2) {
            do {
              piStack_34 = (int *)0xa3d337;
              FUN_005e6080();
              iVar5 = iVar5 + 0x50;
            } while (iVar5 != iVar2);
            iVar5 = *piStack_14;
          }
        }
        piStack_14[1] = iVar5;
        piVar3 = piStack_14;
      }
    }
    else {
      puVar6 = (undefined4 *)(param_1 + 0xc);
      puStack_3c = (undefined4 *)0xa3d1d1;
      piStack_34 = puVar6;
      puStack_18 = puVar6;
      puStack_3c = (undefined4 *)FUN_0055c740();
      piStack_34 = (int *)(-(uint)(puVar4 != (undefined4 *)0x0) & (int)puVar4 + 1U);
      ppiStack_40 = &piStack_14;
      uStack_44 = 0xa3d1ef;
      puStack_38 = puVar6;
      FUN_00562fc0();
      if (piStack_14 != (int *)0x0) {
        puStack_38 = (undefined4 *)0xa3d205;
        piStack_34 = puVar6;
        piStack_14 = (int *)FUN_00939b30();
        iVar5 = *piStack_14;
        iVar2 = piStack_14[1];
        if (iVar5 != iVar2) {
          do {
            puStack_48 = (undefined *)&puStack_38;
            puStack_3c = puStack_18;
            if (*(int *)(iVar5 + 0x44) != 0) {
              LOCK();
              piVar3 = (int *)(*(int *)(iVar5 + 0x44) + 8);
              *piVar3 = *piVar3 + 1;
              UNLOCK();
            }
            uStack_44 = *(undefined4 *)(iVar5 + 0x40);
            ppiStack_40 = *(int ***)(iVar5 + 0x44);
            FUN_00a44420();
            puStack_3c = (undefined4 *)0xa3d250;
            FUN_0096e490();
            iVar5 = iVar5 + 0x50;
          } while (iVar5 != iVar2);
          iVar2 = piStack_14[1];
          iVar5 = *piStack_14;
          if (iVar5 != iVar2) {
            do {
              piStack_34 = (int *)0xa3d26a;
              FUN_005e6080();
              iVar5 = iVar5 + 0x50;
            } while (iVar5 != iVar2);
            iVar5 = *piStack_14;
          }
        }
        piStack_14[1] = iVar5;
      }
      puVar4 = (undefined4 *)(iStack_24 + 0x2a8);
      *(undefined *)(iStack_24 + 0x2a4) = 0;
      puStack_38 = *(undefined4 **)(iStack_24 + 0x2ac);
      puStack_3c = (undefined4 *)*puVar4;
      ppiStack_40 = (undefined4 **)0xa3d291;
      piStack_34 = puVar4;
      FUN_005596d0();
      *(undefined4 *)(iStack_24 + 0x2ac) = *puVar4;
      piStack_34 = (int *)0x0;
      puStack_38 = (undefined4 *)0xa3d2a2;
      piVar3 = (int *)FUN_00a44780();
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_20 + 1;
    iVar5 = *piVar1;
    piVar3 = (int *)*piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      piStack_34 = (int *)0xa3d35f;
      piVar3 = (int *)(**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        piStack_34 = (int *)0xa3d36e;
        piVar3 = (int *)(**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar3;
}



/* FUNCTION 20438 ; VA 0x00a3d390 ; FUN_00a3d390 */

int __fastcall FUN_00a3d390(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de168;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = FUN_00a4d7d0(*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc),
                         *(int *)(param_1 + 0x10) + 1);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20439 ; VA 0x00a3d410 ; FUN_00a3d410 */

int __fastcall FUN_00a3d410(int param_1)

{
  int *piVar1;
  undefined uVar2;
  int iVar3;
  char *pcVar4;
  char *pcVar5;
  char *pcStack_98;
  int *piStack_94;
  undefined4 uStack_44;
  int iStack_40;
  char *apcStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  int iStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de198;
  pvStack_10 = ExceptionList;
  piStack_94 = &iStack_1c;
  pcStack_98 = (char *)0xa3d439;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  uStack_8 = 0;
  if (iStack_1c != 0) {
    piStack_94 = (int *)(param_1 + 8);
    pcStack_98 = (char *)0xa3d45a;
    iVar3 = FUN_00a3c820();
    pcVar5 = *(char **)(iVar3 + 0x18);
    pcVar4 = *(char **)(iVar3 + 0x1c);
    iStack_1c = iVar3;
    if (pcVar5 != pcVar4) {
      iStack_1c = *(int *)(param_1 + 0x20);
      do {
        if (*(int *)(pcVar5 + 0x48) == iStack_1c) break;
        pcVar5 = pcVar5 + 0x50;
      } while (pcVar5 != pcVar4);
      if (pcVar5 != pcVar4) {
        piStack_94 = (int *)0x28;
        pcStack_98 = "CloudLocalization_HangingRequestDetected";
        uStack_24 = 0;
        uStack_20 = 0xf;
        apcStack_34[0] = (char *)((uint)apcStack_34[0] & 0xffffff00);
        FUN_005542c0();
        piStack_94 = (int *)0x0;
        uStack_8._0_1_ = 1;
        pcStack_98 = (char *)0x1;
        FUN_008783f0(apcStack_34);
        uStack_8._0_1_ = 0;
        uVar2 = (undefined)uStack_8;
        uStack_8._0_1_ = 0;
        if (0xf < uStack_20) {
          piStack_94 = (int *)(uStack_20 + 1);
          pcVar4 = apcStack_34[0];
          if (0xfff < piStack_94) {
            pcVar4 = *(char **)(apcStack_34[0] + -4);
            piStack_94 = (int *)(uStack_20 + 0x24);
            if ((char *)0x1f < apcStack_34[0] + (-4 - (int)pcVar4)) {
                    /* WARNING: Subroutine does not return */
              piStack_94 = (int *)&UNK_00a3d5ac;
              uStack_8._0_1_ = uVar2;
              FUN_017167a3();
            }
          }
          pcStack_98 = pcVar4;
          FUN_01674ea0();
        }
        pcStack_98 = (char *)0xa3d4fa;
        piStack_94 = (int *)pcVar5;
        FUN_00a3b160();
        uStack_14 = uStack_14 & 0xffffff00;
        piStack_94 = (int *)uStack_14;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        pcStack_98 = pcVar5;
        FUN_00a37c30(pcVar5 + 0x50,*(undefined4 *)(iVar3 + 0x1c));
        piStack_94 = (int *)0xa3d520;
        FUN_005e6080();
        *(int *)(iVar3 + 0x1c) = *(int *)(iVar3 + 0x1c) + -0x50;
        if (iStack_40 != 0) {
          LOCK();
          *(int *)(iStack_40 + 8) = *(int *)(iStack_40 + 8) + 1;
          UNLOCK();
        }
        FUN_00a44420(&pcStack_98,uStack_44,iStack_40,param_1 + 8);
        FUN_0096e490();
        piStack_94 = (int *)0xa3d56e;
        iStack_1c = FUN_005e6080();
      }
    }
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar3 = *piVar1;
    iStack_1c = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      piStack_94 = (int *)0xa3d587;
      iStack_1c = (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        piStack_94 = (int *)0xa3d596;
        iStack_1c = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iStack_1c;
}



/* FUNCTION 20440 ; VA 0x00a3d5b0 ; FUN_00a3d5b0 */

/* WARNING: Removing unreachable block (ram,0x00a3d602) */
/* WARNING: Removing unreachable block (ram,0x00a3d612) */
/* WARNING: Removing unreachable block (ram,0x00a3d618) */

void * __thiscall
FUN_00a3d5b0(int *param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 param_5,
            int *param_6)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017de1d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 4;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar4 = (void *)(**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 20441 ; VA 0x00a3d6ba ; Catch@00a3d6ba */

undefined * Catch_00a3d6ba(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00a3d6cb;
}



/* FUNCTION 20442 ; VA 0x00a3d6f0 ; FUN_00a3d6f0 */

void FUN_00a3d6f0(void)

{
  FUN_00a3d860();
  return;
}



/* FUNCTION 20443 ; VA 0x00a3d700 ; FUN_00a3d700 */

int __thiscall FUN_00a3d700(int param_1,byte param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  FUN_005c4ac0();
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 20444 ; VA 0x00a3d770 ; FUN_00a3d770 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00a3d770(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::LocalizationService::Language>::vftable;
  _DAT_01ee75f0 = _DAT_01ee75f0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 20445 ; VA 0x00a3d7a0 ; FUN_00a3d7a0 */

undefined4 __thiscall FUN_00a3d7a0(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xe8);
  }
  return param_1;
}



/* FUNCTION 20446 ; VA 0x00a3d7d0 ; FUN_00a3d7d0 */

undefined4 __thiscall FUN_00a3d7d0(undefined4 param_1,byte param_2)

{
  FUN_00a3c0a0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2f8);
  }
  return param_1;
}



/* FUNCTION 20447 ; VA 0x00a3d800 ; FUN_00a3d800 */

undefined4 * __thiscall FUN_00a3d800(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::LocalizationServiceStatReporter::vftable;
  FUN_005d1280();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1c);
  }
  return param_1;
}



/* FUNCTION 20448 ; VA 0x00a3d830 ; FUN_00a3d830 */

undefined4 * __thiscall FUN_00a3d830(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Localization::ParameterTranslator::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 20449 ; VA 0x00a3d860 ; FUN_00a3d860 */

undefined4 * __thiscall FUN_00a3d860(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  *param_1 = RBX::PlayerLocaleLocalizationServiceTranslatorInstance::vftable;
  param_1[0x15] = RBX::PlayerLocaleLocalizationServiceTranslatorInstance::vftable;
  uVar2 = param_1[0x2f];
  if (0xf < uVar2) {
    iVar3 = param_1[0x2a];
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_00a3d96d;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x2e] = 0;
  param_1[0x2f] = 0xf;
  *(undefined *)(param_1 + 0x2a) = 0;
  piVar4 = (int *)param_1[0x29];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[2] + -1;
    piVar4[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar4 + 4))();
    }
  }
  piVar4 = (int *)param_1[0x27];
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar1 = piVar4 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar4 + 4))();
    }
  }
  uVar2 = param_1[0x1b];
  if (0xf < uVar2) {
    iVar3 = param_1[0x16];
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
LAB_00a3d96d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x1a] = 0;
  param_1[0x1b] = 0xf;
  *(undefined *)(param_1 + 0x16) = 0;
  *param_1 = RBX::TranslatorInstance::vftable;
  param_1[0x15] = RBX::Localization::ParameterTranslator::vftable;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc0);
  }
  return param_1;
}



/* FUNCTION 20450 ; VA 0x00a3d980 ; FUN_00a3d980 */

undefined4 * __thiscall FUN_00a3d980(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Localization::ParameterTranslator::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  return param_1;
}



/* FUNCTION 20451 ; VA 0x00a3d9b0 ; FUN_00a3d9b0 */

undefined4 * __thiscall FUN_00a3d9b0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Localization::ParameterTranslator::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 20452 ; VA 0x00a3d9e0 ; FUN_00a3d9e0 */

undefined4 * __thiscall FUN_00a3d9e0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::TranslatorInstance::vftable;
  param_1[0x15] = RBX::Localization::ParameterTranslator::vftable;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 20453 ; VA 0x00a3da10 ; FUN_00a3da10 */

undefined * FUN_00a3da10(undefined *param_1)

{
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_005542c0("en-us",5);
  return param_1;
}



/* FUNCTION 20454 ; VA 0x00a3da40 ; FUN_00a3da40 */

void FUN_00a3da40(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 ****ppppuVar5;
  code **ppcVar6;
  uint uVar7;
  int iVar8;
  undefined4 uVar9;
  undefined auStack_9c [28];
  int *apiStack_80 [2];
  undefined4 uStack_78;
  undefined4 ***apppuStack_74 [4];
  undefined4 uStack_64;
  uint uStack_60;
  undefined auStack_5c [16];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined auStack_44 [4];
  undefined4 uStack_40;
  int iStack_3c;
  int *piStack_38;
  int iStack_34;
  code *pcStack_30;
  int iStack_2c;
  code *pcStack_28;
  int iStack_24;
  int *apiStack_20 [2];
  code *pcStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de6bf;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffea8;
  uStack_40 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_01ee737c);
  uStack_8 = 0;
  uStack_78 = uVar2;
  if ((DAT_01d660a8 == '\0') && (cVar1 = FUN_008ff0a0(), cVar1 != '\0')) {
    uStack_8 = 1;
  }
  else {
    uVar7 = -(uint)(param_1 != 0) & param_1 + 0xcU;
    if (uVar7 == 0) {
      iStack_2c = 0;
    }
    else {
      iStack_2c = FUN_00635a10();
    }
    if (iStack_2c == 0) {
      uStack_8 = 2;
      goto LAB_00a3dfac;
    }
    if (uVar7 != 0) {
      piVar3 = (int *)FUN_00636a50();
      iStack_24 = *piVar3;
      if (iStack_24 == 0) {
        FUN_008e1d00(&iStack_34);
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        FUN_008a5700(uVar7);
        FUN_005789c0(&DAT_01ead658,&LAB_00634090);
        uVar9 = FUN_006350d0();
        piVar3 = (int *)FUN_008aa140(uVar9);
        if (pcStack_30 != (code *)0x0) {
          LOCK();
          *(int *)(pcStack_30 + 4) = *(int *)(pcStack_30 + 4) + 1;
          UNLOCK();
        }
        *piVar3 = iStack_34;
        pcStack_28 = (code *)piVar3[1];
        piVar3[1] = (int)pcStack_30;
        if (pcStack_28 != (code *)0x0) {
          LOCK();
          iVar4 = *(int *)((int)pcStack_28 + 4) + -1;
          *(int *)((int)pcStack_28 + 4) = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (*(code *)**(undefined4 **)pcStack_28)();
            LOCK();
            iVar4 = *(int *)((int)pcStack_28 + 8) + -1;
            *(int *)((int)pcStack_28 + 8) = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*(int *)pcStack_28 + 4))();
            }
          }
        }
        iStack_24 = iStack_34;
        uStack_8 = uStack_8 & 0xffffff00;
        pcStack_28 = pcStack_30;
        if (pcStack_30 != (code *)0x0) {
          LOCK();
          iVar4 = *(int *)(pcStack_30 + 4) + -1;
          *(int *)(pcStack_30 + 4) = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (*(code *)**(undefined4 **)pcStack_30)();
            LOCK();
            iVar4 = *(int *)(pcStack_28 + 8) + -1;
            *(int *)(pcStack_28 + 8) = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*(int *)pcStack_28 + 4))();
            }
          }
        }
      }
      if (iStack_24 != 0) {
        FUN_00b5efb0(&iStack_3c);
        uStack_8._0_1_ = 5;
        if (iStack_3c == 0) {
          if (piStack_38 != (int *)0x0) {
            LOCK();
            iVar4 = piStack_38[1] + -1;
            piStack_38[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)*piStack_38)();
              LOCK();
              piVar3 = piStack_38 + 2;
              iVar4 = *piVar3;
              *piVar3 = *piVar3 + -1;
              UNLOCK();
              if (iVar4 == 1) {
                (**(code **)(*piStack_38 + 4))();
              }
            }
          }
          uStack_8 = 6;
          goto LAB_00a3dfac;
        }
        cVar1 = FUN_00585a40();
        if ((cVar1 != '\0') && (cVar1 = FUN_00b74e80(), cVar1 == '\0')) {
          uStack_64 = 0;
          uStack_60 = 0xf;
          apppuStack_74[0] = (undefined4 ***)((uint)apppuStack_74[0] & 0xffffff00);
          FUN_005542c0("CoreScriptLocalization",0x16);
          uStack_8._0_1_ = 7;
          FUN_00b9f6d0(auStack_44,apppuStack_74);
          uStack_8._0_1_ = 9;
          FUN_005507b0();
          FUN_00a3a470(apiStack_20,auStack_44);
          uStack_8 = CONCAT31(uStack_8._1_3_,10);
          if (apiStack_20[0] != (int *)0x0) {
            uVar9 = 1;
            uVar2 = 0xa3dcc3;
            FUN_00fdd090(1);
            FUN_00557fc0(apiStack_20);
            FUN_0058bb20(uVar2,uVar9);
            uVar2 = 0;
            iVar4 = iStack_24;
            FUN_008a65e0(iStack_24,0);
            FUN_00557fc0(apiStack_20);
            FUN_00d5e000(iVar4,uVar2);
            FUN_00550b30();
            FUN_00550b30();
            FUN_00a3df77();
            return;
          }
          FUN_00550b30();
          FUN_00550b30();
          if (piStack_38 != (int *)0x0) {
            LOCK();
            iVar4 = piStack_38[1] + -1;
            piStack_38[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)*piStack_38)();
              LOCK();
              piVar3 = piStack_38 + 2;
              iVar4 = *piVar3;
              *piVar3 = *piVar3 + -1;
              UNLOCK();
              if (iVar4 == 1) {
                (**(code **)(*piStack_38 + 4))();
              }
            }
          }
          uStack_8 = 0xb;
          goto LAB_00a3dfac;
        }
        piVar3 = (int *)FUN_005c4070();
        if (*piVar3 == 0) {
          if (piStack_38 != (int *)0x0) {
            LOCK();
            iVar4 = piStack_38[1] + -1;
            piStack_38[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)*piStack_38)();
              LOCK();
              piVar3 = piStack_38 + 2;
              iVar4 = *piVar3;
              *piVar3 = *piVar3 + -1;
              UNLOCK();
              if (iVar4 == 1) {
                (**(code **)(*piStack_38 + 4))();
              }
            }
          }
          uStack_8 = 0x19;
          goto LAB_00a3dfac;
        }
        uStack_8._0_1_ = 0xc;
        uStack_4c = 0;
        uStack_48 = 0xf;
        auStack_5c[0] = 0;
        FUN_005542c0("rbxasset://translations/CoreScriptLocalization.csv",0x32);
        uStack_8._0_1_ = 0xd;
        FUN_009cc590(auStack_9c,auStack_5c);
        uStack_8._0_1_ = 0xf;
        FUN_005507b0();
        uVar2 = FUN_008ccd70();
        FUN_008ce100(apiStack_80,auStack_9c,uVar2,1);
        uStack_8._0_1_ = 0x10;
        iVar4 = FUN_00565940(3,1);
        uStack_8._0_1_ = 0x11;
        FUN_0056f130(*(undefined4 *)(*(int *)(*apiStack_80[0] + 4) + 0x38 + (int)apiStack_80[0]));
        uStack_64 = 0;
        uStack_60 = 0xf;
        apppuStack_74[0] = (undefined4 ***)((uint)apppuStack_74[0] & 0xffffff00);
        uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
        uStack_40 = 2;
        if (((*(uint *)(iVar4 + 0x54) & 2) == 0) &&
           (pcStack_28 = (code *)**(undefined4 **)(iVar4 + 0x38), pcStack_28 != (code *)0x0)) {
          iVar8 = **(int **)(iVar4 + 0x28);
          pcStack_18 = pcStack_28;
          ppcVar6 = &pcStack_18;
          if (pcStack_28 < *(code **)(iVar4 + 0x50)) {
            ppcVar6 = (code **)(iVar4 + 0x50);
          }
          iVar4 = (int)*ppcVar6 - iVar8;
        }
        else {
          if (((*(uint *)(iVar4 + 0x54) & 4) != 0) || (**(int **)(iVar4 + 0x34) == 0))
          goto LAB_00a3de2a;
          iVar8 = **(int **)(iVar4 + 0x24);
          iVar4 = (**(int **)(iVar4 + 0x44) - iVar8) + **(int **)(iVar4 + 0x34);
        }
        FUN_005542c0(iVar8,iVar4);
LAB_00a3de2a:
        uStack_8 = 0x14;
        FUN_005705c0();
        FUN_00a39da0(apiStack_20);
        uStack_8._0_1_ = 0x15;
        uStack_4c = 0;
        uStack_48 = 0xf;
        auStack_5c[0] = 0;
        pcStack_18 = *(code **)(*apiStack_20[0] + 0x38);
        FUN_005542c0("CoreScriptLocalization",0x16);
        uStack_8._0_1_ = 0x16;
        (*pcStack_18)(auStack_5c);
        uStack_8._0_1_ = 0x15;
        FUN_005507b0();
        uStack_4c = 0;
        uStack_48 = 0xf;
        auStack_5c[0] = 0;
        FUN_005542c0("en-us",5);
        uStack_8._0_1_ = 0x17;
        FUN_00fdd1b0(auStack_5c);
        uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
        FUN_005507b0();
        ppppuVar5 = apppuStack_74;
        if (0xf < uStack_60) {
          ppppuVar5 = (undefined4 ****)apppuStack_74[0];
        }
        FUN_00fd6e10(ppppuVar5,uStack_64,1);
        uVar9 = 1;
        uVar2 = 0xa3def3;
        FUN_00fdd090(1);
        FUN_00557fc0(apiStack_20);
        FUN_0058bb20(uVar2,uVar9);
        uVar2 = 0;
        iVar4 = iStack_24;
        FUN_008a65e0(iStack_24,0);
        FUN_00557fc0(apiStack_20);
        FUN_00d5e000(iVar4,uVar2);
        FUN_00550b30();
        FUN_005507b0();
        FUN_00550b30();
        FUN_005507b0();
        FUN_00a3df77();
        return;
      }
    }
    uStack_8 = 4;
  }
LAB_00a3dfac:
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20455 ; VA 0x00a3df53 ; Catch@00a3df53 */

undefined * Catch_00a3df53(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x80) + 4))();
  FUN_0086f2f0(3,"Error in loading CorescriptLocalization.csv file (%s)",uVar1);
  return &DAT_00a3df71;
}



/* FUNCTION 20456 ; VA 0x00a3df77 ; FUN_00a3df77 */

void FUN_00a3df77(void)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int unaff_EBX;
  int unaff_EBP;
  
  piVar2 = *(int **)(unaff_EBP + -0x34);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + unaff_EBX;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + unaff_EBX;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *(undefined4 *)(unaff_EBP + -4) = 0x19;
  FUN_01675290();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 20457 ; VA 0x00a3dfd0 ; FUN_00a3dfd0 */

void __fastcall FUN_00a3dfd0(float *param_1)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  undefined auStack_c [8];
  
  fVar2 = param_1[7];
  fVar3 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
          (float)((double)(int)fVar2 + (double)(&DAT_018c0d90)[-((int)fVar2 >> 0x1f)]);
  if (*param_1 <= fVar3 && fVar3 != *param_1) {
    if ((uint)fVar2 < 0x200) {
      fVar2 = (float)((int)fVar2 << 3);
    }
    else if ((uint)fVar2 < 0x1fffffff) {
      fVar2 = (float)((int)fVar2 * 2);
    }
    FUN_005cb500(fVar2);
    pfVar1 = (float *)param_1[1];
    if ((float *)*pfVar1 != pfVar1) {
      fVar2 = pfVar1[1];
      do {
        fVar3 = *(float *)param_1[1];
        FUN_00a377b0(auStack_c,(int)fVar3 + 8,fVar3);
      } while (fVar3 != fVar2);
    }
  }
  return;
}



/* FUNCTION 20458 ; VA 0x00a3e070 ; FUN_00a3e070 */

void __fastcall FUN_00a3e070(int param_1)

{
  (**(code **)(*(int *)(param_1 + 0xc) + 0xc))(0);
  return;
}



/* FUNCTION 20459 ; VA 0x00a3e080 ; FUN_00a3e080 */

void FUN_00a3e080(void)

{
  FUN_00fca640();
  return;
}



/* FUNCTION 20460 ; VA 0x00a3e090 ; FUN_00a3e090 */

void FUN_00a3e090(int param_1,int param_2)

{
  if (param_1 != param_2) {
    do {
      FUN_005e6080();
      param_1 = param_1 + 0x50;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 20461 ; VA 0x00a3e0c0 ; thunk_FUN_00a4d330 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00a4d330(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017df726;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee7874) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee7874);
    if (DAT_01ee7874 == -1) {
      uStack_8 = 0;
      FUN_009ca470("Language");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee7810 = RBX::Reflection::EnumDesc<enum_RBX::LocalizationService::Language>::vftable;
      FUN_009caf20(&DAT_01d660b0,1);
      FUN_016f3654(&LAB_01889c90);
      FUN_016f37bf(&DAT_01ee7874);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee7810;
}



/* FUNCTION 20462 ; VA 0x00a3e0d0 ; FUN_00a3e0d0 */

int __thiscall FUN_00a3e0d0(undefined4 param_1,int param_2,int param_3,int param_4)

{
  if (param_2 != param_3) {
    do {
      FUN_00a39cf0(param_1,param_4,param_2);
      param_2 = param_2 + 0x48;
      param_4 = param_4 + 0x48;
    } while (param_2 != param_3);
  }
  FUN_00a37130(param_4,param_4,param_1);
  return param_4;
}



/* FUNCTION 20463 ; VA 0x00a3e110 ; FUN_00a3e110 */

undefined4 * FUN_00a3e110(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017de6e0;
  pvStack_10 = ExceptionList;
  uStack_7 = 0;
  if (param_1 != param_2) {
    puVar2 = param_1 + 0x11;
    ExceptionList = &pvStack_10;
    do {
      uStack_8 = 0;
      *param_3 = 0;
      FUN_005880d0(puVar2 + -0x11);
      uStack_8 = 1;
      param_3[8] = 0;
      FUN_005880d0(puVar2 + -9);
      param_3[0x10] = 0;
      param_3[0x11] = 0;
      puVar1 = puVar2 + 3;
      param_3[0x10] = puVar2[-1];
      param_3[0x11] = *puVar2;
      puVar2[-1] = 0;
      *puVar2 = 0;
      param_3[0x12] = puVar2[1];
      param_3 = param_3 + 0x14;
      puVar2 = puVar2 + 0x14;
    } while (puVar1 != param_2);
  }
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 20464 ; VA 0x00a3e1e0 ; FUN_00a3e1e0 */

void FUN_00a3e1e0(void)

{
  FUN_00fcbd10();
  return;
}



/* FUNCTION 20465 ; VA 0x00a3e1f0 ; FUN_00a3e1f0 */

/* WARNING: Removing unreachable block (ram,0x00a3e28a) */
/* WARNING: Removing unreachable block (ram,0x00a3e29d) */
/* WARNING: Removing unreachable block (ram,0x00a3e2a4) */
/* WARNING: Removing unreachable block (ram,0x00a3e2ab) */

void __thiscall FUN_00a3e1f0(uint *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796168;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  puVar1 = (undefined4 *)param_1[3];
  uStack_8 = 0;
  if ((uint)((int)((int)puVar1 - param_1[2]) >> 2) < *param_1) {
    if ((undefined4 *)param_1[4] == puVar1) {
      FUN_007d74c0(puVar1,param_2);
    }
    else {
      *puVar1 = *param_2;
      param_1[3] = (uint)(puVar1 + 1);
    }
  }
  else {
    *(undefined4 *)(param_1[2] + param_1[1] * 4) = *param_2;
    param_1[1] = param_1[1] + 1;
    if (param_1[1] == *param_1) {
      param_1[1] = 0;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20466 ; VA 0x00a3e2d0 ; FUN_00a3e2d0 */

void __thiscall
FUN_00a3e2d0(undefined4 param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4,
            undefined4 param_5,undefined4 param_6)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined auStack_34 [28];
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de6f8;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffc0;
  ExceptionList = &pvStack_10;
  uStack_18 = param_1;
  iVar3 = FUN_008f78c0(param_1);
  if ((((iVar3 != 0) && (cVar2 = FUN_008ff0a0(), cVar2 == '\0')) &&
      (cVar2 = FUN_00fce1e0(), cVar2 != '\0')) && (param_3[4] != 0)) {
    puVar5 = param_3;
    if (0xf < (uint)param_3[5]) {
      puVar5 = (undefined4 *)*param_3;
    }
    cVar2 = FUN_0055c360(puVar5,param_3[4],"Label",5);
    if (cVar2 == '\0') {
      piVar4 = (int *)FUN_00a42940();
      iVar1 = piVar4[1];
      for (iVar3 = *piVar4; iVar3 != iVar1; iVar3 = iVar3 + 8) {
        puVar5 = param_4;
        if (0xf < (uint)param_4[5]) {
          puVar5 = (undefined4 *)*param_4;
        }
        cVar2 = FUN_00fd8c70(puVar5,param_4[4]);
        if (cVar2 != '\0') {
          ExceptionList = pvStack_10;
          return;
        }
      }
      uStack_8 = 0;
      FUN_0054ef60(param_2);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_00fce8c0(param_2,auStack_34);
      FUN_00fcc0e0(auStack_34,param_3,param_4,param_5,param_6);
      FUN_005507b0();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20467 ; VA 0x00a3e3ed ; Catch@00a3e3ed */

undefined4 Catch_00a3e3ed(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x18) + 4))();
  FUN_0086f2f0(3,"Text scraper error %s",uVar1);
  return 0xa3e3da;
}



/* FUNCTION 20468 ; VA 0x00a3e410 ; FUN_00a3e410 */

void FUN_00a3e410(int param_1,undefined4 param_2,undefined4 *param_3)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined auStack_30 [28];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017de718;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffc4;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_008f78c0(param_1);
  if (iVar2 != 0) {
    cVar1 = FUN_008ff0a0();
    if (cVar1 == '\0') {
      cVar1 = FUN_00fce1e0();
      if (cVar1 != '\0') {
        if (param_3[4] != 0) {
          puVar3 = param_3;
          if (0xf < (uint)param_3[5]) {
            puVar3 = (undefined4 *)*param_3;
          }
          cVar1 = FUN_0055c360(puVar3,param_3[4],"Label",5);
          if ((cVar1 == '\0') && (param_1 != 0)) {
            iStack_8 = FUN_00a3a560();
            if (iStack_8 == 0) {
              FUN_0054ef60(param_2);
              iStack_8 = CONCAT31(iStack_8._1_3_,1);
              FUN_00fce8c0(param_2,auStack_30);
              FUN_00fcbf20(auStack_30,param_3);
              FUN_005507b0();
            }
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20469 ; VA 0x00a3e4eb ; Catch@00a3e4eb */

undefined4 Catch_00a3e4eb(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x14) + 4))();
  FUN_0086f2f0(3,"Text scraper error %s",uVar1);
  return 0xa3e4d8;
}



/* FUNCTION 20470 ; VA 0x00a3e509 ; Catch_All@00a3e509 */

undefined4 Catch_All_00a3e509(void)

{
  return 0xa3e4d8;
}



/* FUNCTION 20471 ; VA 0x00a3e510 ; FUN_00a3e510 */

int * __thiscall FUN_00a3e510(undefined4 param_1,int param_2,int *param_3)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  int *piVar9;
  int iStack_34;
  int *piStack_30;
  int iStack_2c;
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de738;
  pvStack_10 = ExceptionList;
  bVar3 = false;
  bVar2 = false;
  piStack_1c = (int *)0x0;
  piVar8 = *(int **)(param_2 + 0x2c);
  if (piVar8 == (int *)0x0) {
    iVar6 = 0;
  }
  else {
    iVar6 = piVar8[1] - *piVar8 >> 3;
  }
  piVar5 = (int *)ExceptionList;
  if (iVar6 != 0) {
    uVar7 = iVar6 + (param_3[1] - *param_3 >> 3);
    ExceptionList = &pvStack_10;
    uStack_18 = param_1;
    if ((uint)(param_3[2] - *param_3 >> 3) < uVar7) {
      if (0x1fffffff < uVar7) {
        ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
        FUN_00577c30();
      }
      ExceptionList = &pvStack_10;
      FUN_00777ed0(uVar7);
      piVar8 = *(int **)(param_2 + 0x2c);
    }
    piVar9 = (int *)*piVar8;
    piVar5 = (int *)piVar8[1];
    piStack_1c = piVar5;
    if (piVar9 != piVar5) {
      do {
        piStack_14 = piVar9;
        if ((*piVar9 == 0) ||
           (iVar6 = *(int *)(*piVar9 + 0xc), iVar4 = FUN_00fd0780(),
           (uint)*(ushort *)(iVar4 + 0x1da) <
           (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) {
          bVar2 = true;
          piStack_28 = (int *)0x0;
          piVar5 = &iStack_2c;
          param_2 = 0;
        }
        else {
          piStack_30 = (int *)piVar9[1];
          param_2 = *piVar9;
          if (piStack_30 != (int *)0x0) {
            LOCK();
            piStack_30[1] = piStack_30[1] + 1;
            UNLOCK();
            piStack_30 = (int *)piVar9[1];
          }
          bVar3 = true;
          piVar5 = &iStack_34;
        }
        piVar8 = (int *)piVar5[1];
        iStack_24 = param_2;
        *piVar5 = 0;
        piVar5[1] = 0;
        piVar9 = piStack_28;
        piStack_20 = piVar8;
        if ((bVar2) && (bVar2 = false, piStack_28 != (int *)0x0)) {
          LOCK();
          piVar1 = piStack_28 + 1;
          iVar6 = *piVar1;
          piVar5 = (int *)*piVar1;
          *piVar1 = iVar6 + -1;
          UNLOCK();
          if (iVar6 + -1 == 0) {
            (**(code **)*piStack_28)();
            LOCK();
            piVar1 = piVar9 + 2;
            iVar6 = *piVar1;
            piVar5 = (int *)*piVar1;
            *piVar1 = iVar6 + -1;
            UNLOCK();
            if (iVar6 + -1 == 0) {
              piVar5 = (int *)(**(code **)(*piVar9 + 4))();
            }
          }
        }
        piVar9 = piStack_30;
        if ((bVar3) && (bVar3 = false, piStack_30 != (int *)0x0)) {
          LOCK();
          piVar1 = piStack_30 + 1;
          iVar6 = *piVar1;
          piVar5 = (int *)*piVar1;
          *piVar1 = iVar6 + -1;
          UNLOCK();
          if (iVar6 + -1 == 0) {
            (**(code **)*piStack_30)();
            LOCK();
            piVar1 = piVar9 + 2;
            iVar6 = *piVar1;
            piVar5 = (int *)*piVar1;
            *piVar1 = iVar6 + -1;
            UNLOCK();
            if (iVar6 + -1 == 0) {
              piVar5 = (int *)(**(code **)(*piVar9 + 4))();
            }
          }
        }
        uStack_8 = 0;
        if (param_2 != 0) {
          FUN_00a3e510(param_2,param_3);
          piVar5 = (int *)param_3[1];
          if ((int *)param_3[2] == piVar5) {
            piVar5 = (int *)FUN_00603260(piVar5,&iStack_24);
            piVar8 = piStack_20;
          }
          else {
            *piVar5 = 0;
            piVar5[1] = 0;
            if (piVar8 != (int *)0x0) {
              LOCK();
              piVar8[1] = piVar8[1] + 1;
              UNLOCK();
            }
            *piVar5 = param_2;
            piVar5[1] = (int)piVar8;
            param_3[1] = param_3[1] + 8;
          }
        }
        uStack_8 = 0xffffffff;
        if (piVar8 != (int *)0x0) {
          LOCK();
          piVar9 = piVar8 + 1;
          iVar6 = *piVar9;
          piVar5 = (int *)*piVar9;
          *piVar9 = iVar6 + -1;
          UNLOCK();
          if (iVar6 + -1 == 0) {
            (**(code **)*piVar8)();
            LOCK();
            piVar9 = piVar8 + 2;
            iVar6 = *piVar9;
            piVar5 = (int *)*piVar9;
            *piVar9 = iVar6 + -1;
            UNLOCK();
            if (iVar6 + -1 == 0) {
              piVar5 = (int *)(**(code **)(*piVar8 + 4))();
            }
          }
        }
        piVar9 = piStack_14 + 2;
      } while (piVar9 != piStack_1c);
    }
  }
  ExceptionList = pvStack_10;
  return piVar5;
}



/* FUNCTION 20472 ; VA 0x00a3e720 ; FUN_00a3e720 */

int __thiscall FUN_00a3e720(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int aiStack_38 [5];
  uint uStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de760;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_20);
  uStack_8 = 0;
  if (iStack_20 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("LocalizationService no longer exists");
  }
  uStack_14 = (**(code **)(*(int *)(param_1 + -0x54) + 0xb0))(aiStack_38);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  piVar1 = (int *)FUN_00a42940();
  iVar4 = *piVar1;
  iStack_18 = piVar1[1];
  if (iVar4 != iStack_18) {
    do {
      iVar2 = FUN_00fd4cf0(param_2,param_3,uStack_14,param_4);
      if ((char)iVar2 != '\0') goto LAB_00a3e7b6;
      iVar4 = iVar4 + 8;
    } while (iVar4 != iStack_18);
  }
  iVar2 = FUN_00554150(param_2,param_3);
LAB_00a3e7b6:
  if (0xf < uStack_24) {
    uVar3 = uStack_24 + 1;
    iVar4 = aiStack_38[0];
    if (0xfff < uVar3) {
      iVar4 = *(int *)(aiStack_38[0] + -4);
      uVar3 = uStack_24 + 0x24;
      if (0x1f < (aiStack_38[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar2 = FUN_01674ea0(iVar4,uVar3);
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar4 = *piVar1;
    iVar2 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar2 = (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar2 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 20473 ; VA 0x00a3e840 ; FUN_00a3e840 */

void __thiscall
FUN_00a3e840(int param_1,char *param_2,undefined4 param_3,undefined4 param_4,char *param_5,
            char *param_6,char *param_7)

{
  int iVar1;
  undefined uVar2;
  void **ppvVar3;
  char cVar4;
  char *pcVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017de790;
  iVar1 = (*(int **)(param_1 + 4))[1];
  ppvVar3 = &pvStack_10;
  pvStack_10 = ExceptionList;
  for (iVar8 = **(int **)(param_1 + 4); ExceptionList = ppvVar3, iVar8 != iVar1; iVar8 = iVar8 + 8)
  {
    cVar4 = FUN_00fd4cf0(param_2,param_3,*(undefined4 *)(param_1 + 8),param_4);
    if (cVar4 != '\0') {
      ExceptionList = pvStack_10;
      return;
    }
    ppvVar3 = (void **)ExceptionList;
  }
  if (param_5 != (char *)0x0) {
    uStack_60 = 0;
    uStack_5c = 0xf;
    auStack_70[0] = auStack_70[0] & 0xffffff00;
    pcVar5 = param_7;
    do {
      cVar4 = *pcVar5;
      pcVar5 = pcVar5 + 1;
    } while (cVar4 != '\0');
    FUN_005542c0(param_7,(int)pcVar5 - (int)(param_7 + 1));
    iStack_8 = 0;
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = auStack_58[0] & 0xffffff00;
    pcVar5 = param_2;
    do {
      cVar4 = *pcVar5;
      pcVar5 = pcVar5 + 1;
    } while (cVar4 != '\0');
    FUN_005542c0(param_2,(int)pcVar5 - (int)(param_2 + 1));
    iStack_8._0_1_ = 1;
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    pcVar5 = param_6;
    do {
      cVar4 = *pcVar5;
      pcVar5 = pcVar5 + 1;
    } while (cVar4 != '\0');
    FUN_005542c0(param_6,(int)pcVar5 - (int)(param_6 + 1));
    iStack_8._0_1_ = 2;
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    pcVar5 = param_5;
    do {
      cVar4 = *pcVar5;
      pcVar5 = pcVar5 + 1;
    } while (cVar4 != '\0');
    FUN_005542c0(param_5,(int)pcVar5 - (int)(param_5 + 1));
    iStack_8._0_1_ = 3;
    FUN_00a3e2d0(auStack_28,auStack_40,auStack_58,auStack_70,&stack0x0000001c);
    iStack_8._0_1_ = 2;
    uVar2 = (undefined)iStack_8;
    iStack_8._0_1_ = 2;
    if (0xf < uStack_14) {
      uVar7 = uStack_14 + 1;
      uVar6 = auStack_28[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_28[0] - 4);
        uVar7 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar6) - 4) {
          iStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    iStack_8._0_1_ = 1;
    uVar2 = (undefined)iStack_8;
    iStack_8._0_1_ = 1;
    if (0xf < uStack_2c) {
      uVar7 = uStack_2c + 1;
      uVar6 = auStack_40[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_40[0] - 4);
        uVar7 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar6) - 4) {
          iStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_44) {
      uVar7 = uStack_44 + 1;
      uVar6 = auStack_58[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_58[0] - 4);
        uVar7 = uStack_44 + 0x24;
        if (0x1f < (auStack_58[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = auStack_58[0] & 0xffffff00;
    iStack_8 = 0xffffffff;
    if (0xf < uStack_5c) {
      uVar7 = uStack_5c + 1;
      uVar6 = auStack_70[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_70[0] - 4);
        uVar7 = uStack_5c + 0x24;
        if (0x1f < (auStack_70[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uStack_60 = 0;
    uStack_5c = 0xf;
    auStack_70[0] = auStack_70[0] & 0xffffff00;
  }
  FUN_00554150(param_2,param_3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20474 ; VA 0x00a3eaf0 ; FUN_00a3eaf0 */

void __thiscall FUN_00a3eaf0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  char cVar1;
  
  cVar1 = FUN_00fd4cf0(param_2,param_3,*(undefined4 *)(param_1 + 8),param_4);
  if (cVar1 == '\0') {
    FUN_00554150(param_2,param_3);
  }
  return;
}



/* FUNCTION 20475 ; VA 0x00a3eb20 ; FUN_00a3eb20 */

bool FUN_00a3eb20(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_008dcf60();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1 != 0xc;
    }
  }
  return false;
}



/* FUNCTION 20476 ; VA 0x00a3eb70 ; FUN_00a3eb70 */

undefined __thiscall
FUN_00a3eb70(int param_1,int param_2,undefined4 *param_3,int param_4,undefined4 param_5,
            char *param_6)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  char *pcVar4;
  char cVar5;
  int iVar6;
  int iVar7;
  undefined4 *puVar8;
  double *pdVar9;
  uint uVar10;
  uint uVar11;
  undefined uVar12;
  undefined4 *puVar13;
  undefined8 uVar14;
  uint auStack_78 [4];
  undefined4 uStack_68;
  uint uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined auStack_50 [4];
  undefined **ppuStack_4c;
  undefined **ppuStack_48;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  double dStack_38;
  undefined auStack_30 [8];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined **ppuStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar13 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de7d4;
  pvStack_10 = ExceptionList;
  if ((uint)param_3[4] < 2) {
    return 0;
  }
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee73d0) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ee73d0), DAT_01ee73d0 == -1)) {
    uStack_8 = 0;
    uVar14 = FUN_0152dab0(&DAT_018fdbdc,"LocalizationService::attemptTranslation",0xffffffff);
    DAT_01ee73cc = (undefined4)((ulonglong)uVar14 >> 0x20);
    DAT_01ee73c8 = (undefined4)uVar14;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01ee73d0);
  }
  uStack_28 = DAT_01ee73c8;
  uStack_60 = DAT_01ee73c8;
  uStack_24 = DAT_01ee73cc;
  uStack_5c = DAT_01ee73cc;
  uStack_58 = FUN_0152d930(DAT_01ee73c8,DAT_01ee73cc);
  uStack_8 = 1;
  FUN_01682800(&dStack_38);
  iStack_14 = FUN_00fc5080(param_4);
  FUN_00a435a0(auStack_78,param_2);
  uStack_8._0_1_ = 2;
  iVar6 = FUN_00a43840(param_2);
  if (iVar6 == 0) {
    iVar6 = FUN_00a3a560();
    if (iVar6 == 0) {
      ppuStack_20 = (undefined **)FUN_00a42940();
      puVar3 = param_3;
      puStack_1c = (undefined4 *)ppuStack_20[1];
      puVar8 = (undefined4 *)*ppuStack_20;
      puVar13 = param_3;
      if (puVar8 != puStack_1c) {
        do {
          ppuStack_4c = RBX::TableListPtrTranslator::vftable;
          iStack_44 = param_4;
          iStack_40 = iStack_14;
          uStack_18 = *puVar8;
          uVar12 = *(undefined *)(param_1 + 0x2c2);
          uStack_8._0_1_ = 5;
          if (*(int *)(param_1 + 0x124) != 0) {
            LOCK();
            piVar1 = (int *)(*(int *)(param_1 + 0x124) + 4);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
          }
          ppuStack_48 = ppuStack_20;
          iStack_3c = param_1;
          cVar5 = FUN_00fd50c0(auStack_78,puVar3,param_4,&ppuStack_4c,param_5,param_6,
                               *(undefined4 *)(param_1 + 0x120),*(undefined4 *)(param_1 + 0x124),
                               CONCAT31((int3)((uint)uStack_18 >> 8),uVar12));
          if (cVar5 != '\0') goto LAB_00a3eef2;
          puVar8 = puVar8 + 2;
          uStack_8._0_1_ = 2;
          puVar13 = param_3;
        } while (puVar8 != puStack_1c);
      }
    }
  }
  else {
    do {
      ppuStack_48 = RBX::TablePtrTranslator::vftable;
      iStack_40 = param_4;
      iStack_3c = iStack_14;
      uVar12 = *(undefined *)(param_1 + 0x2c2);
      uStack_8._0_1_ = 3;
      if (*(int *)(param_1 + 0x124) != 0) {
        LOCK();
        piVar1 = (int *)(*(int *)(param_1 + 0x124) + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      iStack_44 = iVar6;
      cVar5 = FUN_00fd50c0(auStack_78,puVar13,param_4,&ppuStack_48,param_5,param_6,
                           *(undefined4 *)(param_1 + 0x120),*(undefined4 *)(param_1 + 0x124),uVar12)
      ;
      if (cVar5 != '\0') goto LAB_00a3eef2;
      iVar6 = *(int *)(iVar6 + 0x34);
      uStack_8._0_1_ = 2;
      ppuStack_48 = RBX::Localization::ParameterTranslator::vftable;
      if (iVar6 == 0) break;
      iVar2 = *(int *)(iVar6 + 0xc);
      iVar7 = FUN_00fd0780();
      puVar13 = param_3;
    } while ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
             (uint)*(ushort *)(iVar7 + 0x1da));
  }
  pcVar4 = param_6;
  if (*param_6 == '\0') {
    FUN_00a3e410(param_2,auStack_78,puVar13);
  }
  if ((DAT_01d66098 != '\0') && (*(int *)(pcVar4 + 0x18) != 0)) {
    iVar6 = FUN_008f7870(param_1);
    if (iVar6 != 0) {
      cVar5 = FUN_008ff0d0();
      if (cVar5 == '\0') {
        cVar5 = FUN_00fce1e0();
        if ((cVar5 != '\0') && (puVar13[4] != 0)) {
          puVar8 = puVar13;
          if (0xf < (uint)puVar13[5]) {
            puVar8 = (undefined4 *)*puVar13;
          }
          cVar5 = FUN_0055c360(puVar8,puVar13[4],"Label",5);
          if ((cVar5 == '\0') && (param_2 != 0)) {
            iVar6 = FUN_00a3a560();
            if (iVar6 == 0) {
              FUN_0054ef60(auStack_78);
              uStack_8._0_1_ = 7;
              FUN_00fce8c0(auStack_78,auStack_50);
              FUN_00fcbdd0(auStack_78,pcVar4 + 8,puVar13);
              uStack_8._0_1_ = 2;
              FUN_005507b0();
            }
          }
        }
      }
    }
  }
  if (DAT_01d66078 != '\0') {
    pdVar9 = (double *)FUN_01682800(auStack_30);
    param_3 = (undefined4 *)(float)((*pdVar9 - dStack_38) * DAT_018c0d70);
    FUN_00a3e1f0(&param_3);
  }
  uVar12 = 0;
LAB_00a3eec2:
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < uStack_64) {
    uVar11 = uStack_64 + 1;
    uVar10 = auStack_78[0];
    if (0xfff < uVar11) {
      uVar10 = *(uint *)(auStack_78[0] - 4);
      uVar11 = uStack_64 + 0x24;
      if (0x1f < (auStack_78[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar11);
  }
  uStack_68 = 0;
  uStack_64 = 0xf;
  auStack_78[0] = auStack_78[0] & 0xffffff00;
  uStack_8 = 8;
  FUN_0152dda0(uStack_28,uStack_24,uStack_58);
  ExceptionList = pvStack_10;
  return uVar12;
LAB_00a3eef2:
  if (DAT_01d66078 != '\0') {
    pdVar9 = (double *)FUN_01682800(auStack_30);
    param_3 = (undefined4 *)(float)((*pdVar9 - dStack_38) * DAT_018c0d70);
    FUN_00a3e1f0(&param_3);
  }
  uVar12 = 1;
  goto LAB_00a3eec2;
}



/* FUNCTION 20477 ; VA 0x00a3efe0 ; FUN_00a3efe0 */

undefined4 FUN_00a3efe0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined uVar1;
  char cVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  int aiStack_44 [5];
  uint uStack_30;
  int iStack_2c;
  int *piStack_28;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017de7f0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_2c);
  iStack_8 = 0;
  if (iStack_2c == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("LocalizationService no longer exists");
  }
  piVar3 = (int *)FUN_00a42940();
  puVar7 = (undefined4 *)*piVar3;
  puStack_20 = (undefined4 *)piVar3[1];
  if (puVar7 != puStack_20) {
    piStack_18 = piStack_14 + 0x15;
    do {
      uStack_1c = *puVar7;
      uVar1 = *(undefined *)(iStack_2c + 0x2c2);
      uVar4 = (**(code **)(*piStack_14 + 0xb0))(aiStack_44);
      iStack_8._0_1_ = 1;
      if (*(int *)(iStack_2c + 0x124) != 0) {
        LOCK();
        piVar3 = (int *)(*(int *)(iStack_2c + 0x124) + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      cVar2 = FUN_00fd50c0(param_1,param_2,uVar4,piStack_18,param_3,param_4,
                           *(undefined4 *)(iStack_2c + 0x120),*(undefined4 *)(iStack_2c + 0x124),
                           uVar1);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (0xf < uStack_30) {
        uVar6 = uStack_30 + 1;
        iVar5 = aiStack_44[0];
        if (0xfff < uVar6) {
          iVar5 = *(int *)(aiStack_44[0] + -4);
          uVar6 = uStack_30 + 0x24;
          if (0x1f < (aiStack_44[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar5,uVar6);
      }
      if (cVar2 != '\0') {
        if (piStack_28 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_28[1] + -1;
          piStack_28[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piStack_28)();
            LOCK();
            piVar3 = piStack_28 + 2;
            iVar5 = *piVar3;
            *piVar3 = *piVar3 + -1;
            UNLOCK();
            if (iVar5 == 1) {
              (**(code **)(*piStack_28 + 4))();
            }
          }
        }
        ExceptionList = pvStack_10;
        return 1;
      }
      puVar7 = puVar7 + 2;
    } while (puVar7 != puStack_20);
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_28[1] + -1;
    piStack_28[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar3 = piStack_28 + 2;
      iVar5 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 20478 ; VA 0x00a3f190 ; FUN_00a3f190 */

int FUN_00a3f190(undefined4 param_1,int *param_2,char *param_3,undefined4 param_4,undefined4 param_5
                ,undefined4 param_6,int *param_7)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  char *pcVar6;
  undefined8 uVar7;
  undefined4 uStack_18c;
  int *piStack_188;
  undefined uStack_184;
  undefined4 uStack_17c;
  int iStack_178;
  undefined uStack_174;
  undefined4 uStack_16c;
  undefined4 uStack_168;
  int *piStack_164;
  undefined4 uStack_160;
  undefined4 uStack_15c;
  int *piStack_158;
  char **ppcStack_154;
  undefined4 auStack_150 [5];
  undefined4 uStack_13c;
  char **ppcStack_138;
  uint *puStack_134;
  char **ppcStack_130;
  undefined auStack_120 [28];
  undefined auStack_104 [16];
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  char *pcStack_ec;
  undefined4 uStack_e8;
  uint uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  int *piStack_d8;
  undefined uStack_d4;
  undefined4 uStack_cc;
  int iStack_c8;
  undefined uStack_c4;
  undefined auStack_c0 [28];
  undefined auStack_a4 [8];
  int iStack_9c;
  int *piStack_98;
  undefined8 uStack_94;
  char *apcStack_8c [3];
  undefined auStack_80 [4];
  int iStack_7c;
  uint uStack_78;
  undefined auStack_74 [16];
  undefined4 uStack_64;
  undefined4 uStack_60;
  char *pcStack_5c;
  undefined4 uStack_58;
  uint uStack_54;
  undefined4 uStack_50;
  undefined8 uStack_4c;
  undefined4 uStack_44;
  char *pcStack_40;
  undefined4 uStack_3c;
  uint uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined8 uStack_28;
  int iStack_20;
  undefined *puStack_1c;
  undefined uStack_17;
  undefined uStack_16;
  char cStack_15;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017de8ac;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffed4;
  puStack_1c = (undefined *)0x0;
  uStack_8 = 0;
  uStack_30 = 0xf00000000;
  pcStack_40 = (char *)((uint)pcStack_40 & 0xffffff00);
  ppcStack_130 = (char **)&iStack_9c;
  puStack_134 = (uint *)0xa3f1e3;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  uStack_8._0_1_ = 2;
  if (iStack_9c == 0) {
    ppcStack_130 = (char **)0x20;
    puStack_134 = (uint *)0x19428e8;
    iStack_7c = iStack_9c;
    uStack_78 = 0xf;
    apcStack_8c[0] = (char *)((uint)apcStack_8c[0] & 0xffffff00);
    ppcStack_138 = (char **)0xa3f218;
    FUN_005542c0();
    ppcStack_130 = (char **)iStack_9c;
    ppcStack_138 = apcStack_8c;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    puStack_134 = (uint *)0x1;
    uStack_13c = 0xa3f22b;
    iVar4 = FUN_008783f0();
    if (0xf < uStack_78) {
      ppcStack_130 = (char **)(uStack_78 + 1);
      pcVar6 = apcStack_8c[0];
      if (0xfff < ppcStack_130) {
        pcVar6 = *(char **)(apcStack_8c[0] + -4);
        ppcStack_130 = (char **)(uStack_78 + 0x24);
        if ((char *)0x1f < apcStack_8c[0] + (-4 - (int)pcVar6)) {
                    /* WARNING: Subroutine does not return */
          ppcStack_130 = (char **)0xa3f9c4;
          FUN_017167a3();
        }
      }
      ppcStack_138 = (char **)0xa3f262;
      puStack_134 = (uint *)pcVar6;
      iVar4 = FUN_01674ea0();
    }
    if (piStack_98 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_98 + 1;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        ppcStack_130 = (char **)0xa3f281;
        (**(code **)*piStack_98)();
        LOCK();
        piVar1 = piStack_98 + 2;
        iVar2 = *piVar1;
        iVar4 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          ppcStack_130 = (char **)0xa3f291;
          iVar4 = (**(code **)(*piStack_98 + 4))();
        }
      }
    }
    if (uStack_30._4_4_ < 0x10) goto LAB_00a3f988;
    ppcStack_130 = (char **)(uStack_30._4_4_ + 1);
    pcVar6 = pcStack_40;
    if (0xfff < ppcStack_130) {
      pcVar6 = *(char **)(pcStack_40 + -4);
      ppcStack_130 = (char **)(uStack_30._4_4_ + 0x24);
      if ((char *)0x1f < pcStack_40 + (-4 - (int)pcVar6)) {
                    /* WARNING: Subroutine does not return */
        ppcStack_130 = (char **)0xa3f9c9;
        FUN_017167a3();
      }
    }
  }
  else {
    if ((0 < DAT_01ee72fc) && ((int)param_7 < DAT_01ee72fc)) {
      ppcStack_130 = (char **)0xc;
      param_3 = (char *)0x0;
      puStack_134 = (uint *)0xa3f2df;
      iStack_20 = FUN_01674e20();
      if (iStack_20 != 0) {
        ppcStack_130 = (char **)0x194290c;
        puStack_134 = (uint *)0xa3f2f5;
        FUN_00550130();
      }
    }
    cStack_15 = '\0';
    if (param_3 == (char *)0x0) {
      ppcStack_130 = (char **)iStack_9c;
      puStack_134 = (uint *)0xa3f836;
      iStack_20 = FUN_008f7870();
      if (iStack_20 != 0) {
        ppcStack_130 = (char **)0x1;
        if (param_2 != (int *)0x0) {
          LOCK();
          param_2[2] = param_2[2] + 1;
          UNLOCK();
          LOCK();
          param_2[2] = param_2[2] + 1;
          UNLOCK();
        }
        auStack_150[0] = 0;
        if (param_2 != (int *)0x0) {
          LOCK();
          param_2[2] = param_2[2] + 1;
          UNLOCK();
        }
        uStack_168 = param_1;
        piStack_164 = param_2;
        uStack_160 = param_5;
        uStack_15c = param_6;
        piStack_158 = param_7;
        uStack_16c = 0xa3f8a4;
        FUN_00a39210();
        if (param_2 != (int *)0x0) {
          LOCK();
          iVar4 = param_2[2] + -1;
          param_2[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            ppcStack_154 = (char **)0xa3f8bd;
            (**(code **)(*param_2 + 4))();
          }
          LOCK();
          iVar4 = param_2[2] + -1;
          param_2[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            ppcStack_154 = (char **)0xa3f8cf;
            (**(code **)(*param_2 + 4))();
          }
        }
        ppcStack_154 = (char **)0xa3f8d7;
        FUN_0090ca30();
      }
      ppcStack_130 = (char **)0x30;
      puStack_134 = (uint *)0x1942bcc;
      uStack_64 = 0;
      uStack_60 = 0xf;
      auStack_74[0] = 0;
      ppcStack_138 = (char **)0xa3f8fd;
      FUN_005542c0();
      ppcStack_130 = (char **)0x0;
      ppcStack_138 = (char **)auStack_74;
      uStack_8._0_1_ = 0x11;
      puStack_134 = (uint *)0x1;
      uStack_13c = 0xa3f90e;
      FUN_008783f0();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      ppcStack_130 = (char **)0xa3f91d;
      iVar4 = FUN_005507b0();
    }
    else {
      uStack_8._0_1_ = 4;
      if (0xf < *(uint *)(param_3 + 0x14)) {
        param_3 = *(char **)param_3;
      }
      uStack_4c = 0xf00000000;
      pcStack_5c = (char *)((uint)pcStack_5c & 0xffffff00);
      ppcStack_130 = (char **)param_3;
      do {
        cVar3 = *(char *)ppcStack_130;
        ppcStack_130 = (char **)((int)ppcStack_130 + 1);
      } while (cVar3 != '\0');
      ppcStack_130 = (char **)((int)ppcStack_130 - (int)(param_3 + 1));
      ppcStack_138 = (char **)0xa3f343;
      puStack_134 = (uint *)param_3;
      FUN_005542c0();
      ppcStack_130 = &pcStack_5c;
      uStack_8._0_1_ = 5;
      puStack_134 = (uint *)auStack_80;
      ppcStack_138 = (char **)0xa3f354;
      FUN_016819e0();
      uStack_8._0_1_ = 7;
      ppcStack_130 = (char **)0xa3f363;
      FUN_005507b0();
      ppcStack_130 = (char **)0xa3f36b;
      cVar3 = FUN_016816d0();
      if (cVar3 == '\0') {
        ppcStack_130 = (char **)0xa3f43d;
        cVar3 = FUN_01681870();
        if (cVar3 == '\0') {
          ppcStack_130 = (char **)0x3f;
          puStack_134 = (uint *)0x1942b18;
          ppcStack_138 = (char **)0xa3f450;
          FUN_005542c0();
          cStack_15 = '\x01';
        }
        else {
          ppcStack_130 = (char **)0x1942b58;
          puStack_134 = (uint *)auStack_a4;
          ppcStack_138 = (char **)0xa3f46d;
          FUN_0167eea0();
          ppcStack_130 = (char **)0x18c890c;
          puStack_134 = &uStack_e4;
          ppcStack_138 = (char **)0xa3f481;
          FUN_0167eea0();
          ppcStack_130 = (char **)0x1942b74;
          puStack_134 = (uint *)&uStack_94;
          ppcStack_138 = (char **)0xa3f495;
          FUN_0167eea0();
          ppcStack_130 = (char **)0xa3f4a0;
          cVar3 = FUN_0167e5c0();
          if (cVar3 == '\0') {
            uStack_16 = 0;
          }
          else {
            ppcStack_130 = (char **)0x0;
            puStack_134 = (uint *)0xa3f4b1;
            uStack_16 = FUN_0167e3d0();
          }
          ppcStack_130 = (char **)0xa3f4c5;
          cVar3 = FUN_0167e5a0();
          if (cVar3 == '\0') {
            uStack_28 = 0;
            uVar7 = 0;
          }
          else {
            ppcStack_130 = (char **)0x0;
            puStack_134 = (uint *)0x0;
            ppcStack_138 = (char **)0xa3f4d8;
            uVar7 = FUN_0167e380();
          }
          iStack_20 = (int)((ulonglong)uVar7 >> 0x20);
          uStack_44 = (undefined4)uVar7;
          ppcStack_130 = (char **)0xa3f4fc;
          cVar3 = FUN_0167e5c0();
          if (cVar3 == '\0') {
            uStack_17 = 0;
          }
          else {
            ppcStack_130 = (char **)0x0;
            puStack_134 = (uint *)0xa3f50d;
            uStack_17 = FUN_0167e3d0();
          }
          uStack_4c = 0xf00000000;
          pcStack_5c = (char *)((uint)pcStack_5c & 0xffffff00);
          uStack_8._0_1_ = 9;
          if (DAT_01d660a0 != '\0') {
            ppcStack_130 = (char **)0x1942b90;
            puStack_134 = (uint *)&uStack_28;
            ppcStack_138 = (char **)0xa3f54a;
            FUN_0167eea0();
            ppcStack_130 = (char **)0xa3f552;
            cVar3 = FUN_0167e580();
            if (cVar3 == '\0') {
              ppcStack_130 = (char **)0x0;
              puStack_134 = (uint *)&DAT_018bc9b8;
              uStack_64 = 0;
              uStack_60 = 0xf;
              auStack_74[0] = 0;
              ppcStack_138 = (char **)0xa3f5ba;
              FUN_005542c0();
              ppcStack_130 = (char **)auStack_74;
              puStack_1c = &DAT_00000004;
            }
            else {
              uStack_f4 = 0;
              uStack_f0 = 0xf;
              auStack_104[0] = 0;
              ppcStack_130 = (char **)auStack_104;
              uStack_8._0_1_ = 10;
              puStack_134 = (uint *)auStack_120;
              puStack_1c = (undefined *)0x1;
              ppcStack_138 = (char **)0xa3f592;
              ppcStack_130 = (char **)FUN_01681580();
              puStack_1c = (undefined *)0x3;
            }
            puStack_134 = (uint *)0xa3f5ce;
            FUN_005511f0();
            if (((uint)puStack_1c & 4) != 0) {
              puStack_1c = (undefined *)((uint)puStack_1c & 0xfffffffb);
              ppcStack_130 = (char **)0xa3f5e3;
              FUN_005507b0();
            }
            if (((uint)puStack_1c & 2) != 0) {
              puStack_1c = (undefined *)((uint)puStack_1c & 0xfffffffd);
              ppcStack_130 = (char **)0xa3f5fb;
              FUN_005507b0();
            }
            uStack_8._0_1_ = 9;
            uStack_8._1_3_ = 0;
            if (((uint)puStack_1c & 1) != 0) {
              ppcStack_130 = (char **)0xa3f614;
              FUN_005507b0();
            }
          }
          ppcStack_130 = (char **)iStack_9c;
          puStack_134 = (uint *)0xa3f61a;
          iVar4 = FUN_008f7870();
          if (iVar4 != 0) {
            ppcStack_130 = (char **)0x1;
            puStack_1c = (undefined *)auStack_150;
            uStack_28 = CONCAT44(&uStack_dc,(undefined4)uStack_28);
            if (param_2 != (int *)0x0) {
              LOCK();
              param_2[2] = param_2[2] + 1;
              UNLOCK();
            }
            uStack_dc = param_1;
            piStack_d8 = param_2;
            uStack_d4 = uStack_16;
            uStack_cc = uStack_44;
            iStack_c8 = iStack_20;
            uStack_c4 = uStack_17;
            ppcStack_154 = &pcStack_5c;
            uStack_8._0_1_ = 0xc;
            piStack_158 = (int *)0xa3f6a0;
            FUN_0054ef60();
            ppcStack_154 = (char **)0x0;
            uStack_28 = CONCAT44(&uStack_18c,(undefined4)uStack_28);
            if (piStack_d8 != (int *)0x0) {
              LOCK();
              piStack_d8[2] = piStack_d8[2] + 1;
              UNLOCK();
            }
            uStack_18c = uStack_dc;
            piStack_188 = piStack_d8;
            uStack_184 = uStack_d4;
            uStack_17c = uStack_cc;
            iStack_178 = iStack_c8;
            uStack_174 = uStack_c4;
            uStack_8._0_1_ = 0xe;
            FUN_0054ef60(auStack_c0);
            uStack_8._0_1_ = 0xd;
            FUN_00a364b0();
            uStack_8._0_1_ = 9;
            ppcStack_154 = (char **)0xa3f728;
            FUN_00a3bb40();
            ppcStack_154 = (char **)0xa3f72f;
            FUN_0090ca30();
          }
          ppcStack_130 = (char **)0xa3f737;
          FUN_005507b0();
        }
      }
      else {
        ppcStack_130 = (char **)0xa3f37b;
        puStack_134 = (uint *)FUN_016814a0();
        uStack_64 = 0;
        uStack_60 = 0xf;
        auStack_74[0] = 0;
        ppcStack_130 = (char **)puStack_134;
        do {
          cVar3 = *(char *)ppcStack_130;
          ppcStack_130 = (char **)((int)ppcStack_130 + 1);
        } while (cVar3 != '\0');
        ppcStack_130 = (char **)((int)ppcStack_130 - (int)((int)puStack_134 + 1));
        ppcStack_138 = (char **)0xa3f3a7;
        FUN_005542c0();
        ppcStack_130 = (char **)0x2d;
        puStack_134 = (uint *)0x1942ae4;
        ppcStack_138 = (char **)0x0;
        uStack_8._0_1_ = 8;
        uStack_13c = 0xa3f3bc;
        puVar5 = (undefined4 *)FUN_00585d40();
        pcStack_ec = (char *)*puVar5;
        uStack_e8 = puVar5[1];
        uStack_e4 = puVar5[2];
        uStack_e0 = puVar5[3];
        uStack_94 = *(undefined8 *)(puVar5 + 4);
        puVar5[4] = 0;
        puVar5[5] = 0xf;
        *(undefined *)puVar5 = 0;
        ppcStack_130 = (char **)0xa3f3f5;
        pcStack_5c = pcStack_ec;
        uStack_58 = uStack_e8;
        uStack_54 = uStack_e4;
        uStack_50 = uStack_e0;
        uStack_4c = uStack_94;
        FUN_005507b0();
        uStack_4c = 0xf00000000;
        pcStack_40 = pcStack_ec;
        uStack_3c = uStack_e8;
        uStack_38 = uStack_e4;
        uStack_34 = uStack_e0;
        pcStack_5c = (char *)((uint)pcStack_5c & 0xffffff00);
        uStack_30 = uStack_94;
        ppcStack_130 = (char **)0xa3f427;
        FUN_005507b0();
        ppcStack_130 = (char **)0xa3f42f;
        FUN_005507b0();
        cStack_15 = '\x01';
      }
      ppcStack_130 = (char **)0xa3f73f;
      iVar4 = FUN_0167ec40();
      uStack_8 = 2;
      if (cStack_15 != '\0') {
        ppcStack_130 = (char **)iStack_9c;
        puStack_134 = (uint *)0xa3f756;
        iVar4 = FUN_008f7870();
        iStack_20 = iVar4;
        if (iVar4 != 0) {
          ppcStack_130 = (char **)0x1;
          if (param_2 != (int *)0x0) {
            LOCK();
            param_2[2] = param_2[2] + 1;
            UNLOCK();
          }
          ppcStack_154 = (char **)0x0;
          if (param_2 != (int *)0x0) {
            LOCK();
            param_2[2] = param_2[2] + 1;
            UNLOCK();
          }
          uStack_15c = param_1;
          piStack_158 = param_2;
          uStack_160 = 0xa3f7a4;
          FUN_00a366b0();
          if (param_2 != (int *)0x0) {
            LOCK();
            iVar4 = param_2[2] + -1;
            param_2[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              ppcStack_154 = (char **)0xa3f7bd;
              (**(code **)(*param_2 + 4))();
            }
          }
          ppcStack_154 = (char **)0xa3f7c5;
          iVar4 = FUN_0090ca30();
        }
      }
    }
    if ((int)uStack_30 != 0) {
      ppcStack_130 = &pcStack_40;
      puStack_134 = (uint *)0xa3f92c;
      iVar4 = FUN_00a4acd0();
    }
    if (piStack_98 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_98 + 1;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        ppcStack_130 = (char **)0xa3f948;
        (**(code **)*piStack_98)();
        LOCK();
        piVar1 = piStack_98 + 2;
        iVar2 = *piVar1;
        iVar4 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          ppcStack_130 = (char **)0xa3f958;
          iVar4 = (**(code **)(*piStack_98 + 4))();
        }
      }
    }
    if (uStack_30._4_4_ < 0x10) goto LAB_00a3f988;
    ppcStack_130 = (char **)(uStack_30._4_4_ + 1);
    pcVar6 = pcStack_40;
    if (0xfff < ppcStack_130) {
      pcVar6 = *(char **)(pcStack_40 + -4);
      ppcStack_130 = (char **)(uStack_30._4_4_ + 0x24);
      if ((char *)0x1f < pcStack_40 + (-4 - (int)pcVar6)) {
                    /* WARNING: Subroutine does not return */
        ppcStack_130 = (char **)&UNK_00a3f9ce;
        FUN_017167a3();
      }
    }
  }
  ppcStack_138 = (char **)0xa3f985;
  puStack_134 = (uint *)pcVar6;
  iVar4 = FUN_01674ea0();
LAB_00a3f988:
  pcStack_40 = (char *)((uint)pcStack_40 & 0xffffff00);
  uStack_30 = 0xf00000000;
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      ppcStack_130 = (char **)0xa3f9ae;
      iVar4 = (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 20479 ; VA 0x00a3f7ca ; Catch@00a3f7ca */

undefined * Catch_00a3f7ca(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x104) + 4))();
  uVar1 = FUN_0054eff0(uVar1);
  *(undefined *)(unaff_EBP + -4) = 0x10;
  uVar1 = FUN_00558d90(unaff_EBP + -0x11c,"autoLocalizationResponseHandler exception: ",uVar1);
  FUN_005511f0(uVar1);
  FUN_005507b0();
  FUN_005507b0();
  return &DAT_00a3f821;
}



/* FUNCTION 20480 ; VA 0x00a3f9d0 ; FUN_00a3f9d0 */

void FUN_00a3f9d0(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
                 uint *param_5,uint *param_6)

{
  uint uVar1;
  uint *puVar2;
  uint *puVar3;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  undefined8 uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_7c;
  uint *puStack_78;
  uint *puStack_74;
  undefined4 uStack_70;
  uint auStack_6c [2];
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined8 uStack_54;
  uint uStack_3c;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined *puStack_1c;
  undefined *puStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de8d0;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined *)auStack_6c;
  puStack_1c = (undefined *)auStack_6c;
  pcStack_14 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ee730a);
  auStack_6c[0] = 0;
  uVar1 = *param_6;
  ExceptionList = &pvStack_10;
  puVar2 = auStack_6c;
  puVar3 = auStack_6c;
  if (uVar1 != 0) {
    auStack_6c[0] = uVar1;
    if ((uVar1 & 1) == 0) {
      puStack_74 = &uStack_64;
      uStack_70 = 0;
      puStack_78 = param_6 + 2;
      uStack_7c = 0xa3fa47;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))();
      puVar2 = (uint *)puStack_1c;
      puVar3 = (uint *)puStack_18;
    }
    else {
      uStack_64 = param_6[2];
      uStack_60 = param_6[3];
      uStack_5c = param_6[4];
      uStack_58 = param_6[5];
      uStack_54 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
      puVar2 = auStack_6c;
      puVar3 = auStack_6c;
    }
  }
  puStack_18 = (undefined *)puVar3;
  puStack_1c = (undefined *)puVar2;
  uStack_8 = 0;
  uStack_90 = param_1;
  uVar1 = *param_5;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_5 + 2);
    }
    else {
      uStack_a8 = param_5[2];
      uStack_a4 = param_5[3];
      uStack_a0 = param_5[4];
      uStack_9c = param_5[5];
      uStack_98 = *(undefined8 *)(param_5 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_90 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_3c != 0) {
    if ((uStack_3c & 1) == 0) {
      (**(code **)(uStack_3c & 0xfffffffe))(&uStack_34,&uStack_a8,0);
    }
    else {
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
      uStack_98 = uStack_24;
    }
  }
  FUN_008dbe80();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_3c != 0) && ((uStack_3c & 1) == 0)) &&
     (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
    uStack_90 = 2;
    uStack_98 = CONCAT44(&uStack_34,&uStack_34);
    uStack_9c = 0xa3fb29;
    (**(code **)(uStack_3c & 0xfffffffe))();
  }
  uStack_90 = param_4;
  uStack_8 = 0xffffffff;
  uStack_98 = CONCAT44(0xa3fb46,(undefined4)uStack_98);
  (*pcStack_14)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20481 ; VA 0x00a3fb60 ; FUN_00a3fb60 */

void FUN_00a3fb60(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
                 uint *param_5,uint *param_6)

{
  uint uVar1;
  uint uStack_244;
  uint uStack_240;
  uint uStack_23c;
  uint uStack_238;
  undefined8 uStack_234;
  undefined4 uStack_22c;
  undefined4 uStack_228;
  undefined4 uStack_160;
  undefined auStack_15c [236];
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_58;
  uint *puStack_54;
  uint *puStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7e10;
  pvStack_10 = ExceptionList;
  uStack_48 = 0;
  uVar1 = *param_6;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    uStack_48 = uVar1;
    if ((uVar1 & 1) == 0) {
      puStack_50 = &uStack_40;
      uStack_4c = 0;
      puStack_54 = param_6 + 2;
      uStack_58 = 0xa3fbd2;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))();
    }
    else {
      uStack_40 = param_6[2];
      uStack_3c = param_6[3];
      uStack_38 = param_6[4];
      uStack_34 = param_6[5];
      uStack_30 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8 = 0;
  uStack_6c = 0;
  uStack_234 = CONCAT44(0xa3fbff,(undefined4)uStack_234);
  uStack_22c = FUN_00888530();
  uStack_228 = 0;
  iStack_8._0_1_ = 1;
  uVar1 = *param_5;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_5 + 2,&uStack_244,0);
    }
    else {
      uStack_244 = param_5[2];
      uStack_240 = param_5[3];
      uStack_23c = param_5[4];
      uStack_238 = param_5[5];
      uStack_234 = *(undefined8 *)(param_5 + 6);
    }
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_008bf820(auStack_15c);
  uStack_160 = 0xa3fc6b;
  FUN_008bd310();
  uStack_6c = param_4;
  iStack_8 = 0xffffffff;
  uStack_70 = 0xa3fc7b;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20482 ; VA 0x00a3fc90 ; FUN_00a3fc90 */

undefined4 FUN_00a3fc90(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_00a3a560();
  if (iVar1 != 0) {
    FUN_005542c0(&DAT_018bc9b8,0);
    return 1;
  }
  if (DAT_01ee7308 != '\0') {
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_01677520(DAT_01ee7308,"Found zh-cjv for UGC content %s",param_2);
  }
  return 0;
}



/* FUNCTION 20483 ; VA 0x00a3fce0 ; FUN_00a3fce0 */

void __fastcall FUN_00a3fce0(int *param_1)

{
  int *piVar1;
  int *piVar2;
  
  piVar1 = (int *)*param_1;
  piVar2 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar2 != (int *)*param_1) {
    do {
      piVar1 = (int *)*piVar2;
      FUN_005509f0();
      FUN_01674ea0(piVar2,0x38);
      piVar2 = piVar1;
    } while (piVar1 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 20484 ; VA 0x00a3fd20 ; FUN_00a3fd20 */

void __fastcall FUN_00a3fd20(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_1[1];
  iVar2 = *param_1;
  if (iVar2 != iVar1) {
    do {
      FUN_005e6080();
      iVar2 = iVar2 + 0x50;
    } while (iVar2 != iVar1);
    param_1[1] = *param_1;
    return;
  }
  param_1[1] = iVar2;
  return;
}



/* FUNCTION 20485 ; VA 0x00a3fd50 ; FUN_00a3fd50 */

undefined4 * __thiscall
FUN_00a3fd50(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017de911;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00a407b0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20486 ; VA 0x00a3ff00 ; FUN_00a3ff00 */

void __fastcall FUN_00a3ff00(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  if (param_1[1] == 0) {
    *(undefined2 *)(param_1 + 2) = 0;
    puVar1 = (undefined4 *)FUN_01674e20(0x2c);
    param_1[1] = puVar1;
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    puVar1[6] = 0;
    puVar1[7] = 0;
    puVar1[8] = 0;
    puVar1[9] = 0;
    puVar1[10] = 0;
    *(undefined *)(param_1 + 2) = 1;
    return;
  }
  if (*(char *)((int)param_1 + 9) != '\0') {
    FUN_00a3a1c0(*param_1,param_1[1] + 8);
    *(undefined *)((int)param_1 + 9) = 0;
  }
  return;
}



/* FUNCTION 20487 ; VA 0x00a3ff60 ; FUN_00a3ff60 */

void FUN_00a3ff60(undefined4 param_1,undefined4 *param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined auStack_8 [4];
  
  cVar1 = FUN_009cb5f0(param_1,auStack_8);
  if (cVar1 != '\0') {
    uVar2 = FUN_00a4d330();
    *param_2 = uVar2;
    FUN_00a36c20(auStack_8);
  }
  return;
}



/* FUNCTION 20488 ; VA 0x00a3ff90 ; FUN_00a3ff90 */

void FUN_00a3ff90(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00a4d330();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 20489 ; VA 0x00a3ffd0 ; FUN_00a3ffd0 */

void FUN_00a3ffd0(int *param_1,undefined4 *param_2)

{
  byte *pbVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint *puVar5;
  int iVar6;
  int *piVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  
  if (param_1 != (int *)0x0) {
    piVar7 = (int *)param_1[0xd];
    piVar2 = param_1;
    if ((piVar7 != (int *)0x0) && (piVar2 = piVar7, piVar7[0xd] != 0)) {
      piVar2 = (int *)FUN_005c8ac0();
    }
    if (((piVar2 != (int *)0x0) &&
        (iVar4 = piVar2[3], iVar3 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da))) && (iVar4 = FUN_00635a10(), iVar4 != 0)) {
      puVar5 = param_2 + 4;
      if (0xf < (uint)param_2[5]) {
        param_2 = (undefined4 *)*param_2;
      }
      uVar8 = 0;
      uVar9 = 0x811c9dc5;
      if (*puVar5 != 0) {
        do {
          pbVar1 = (byte *)(uVar8 + (int)param_2);
          uVar8 = uVar8 + 1;
          uVar9 = (*pbVar1 ^ uVar9) * 0x1000193;
        } while (uVar8 < *puVar5);
      }
      uVar8 = 0;
      puVar5 = *(uint **)(iVar4 + 0xa0);
      uVar10 = *(int *)(iVar4 + 0xa4) - (int)puVar5 >> 2;
      if (uVar10 != 0) {
        while (*puVar5 != uVar9) {
          uVar8 = uVar8 + 1;
          puVar5 = puVar5 + 1;
          if (uVar10 <= uVar8) {
            return;
          }
        }
        iVar3 = param_1[3];
        iVar6 = FUN_00d59db0();
        if (((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
             (uint)*(ushort *)(iVar6 + 0x1da)) &&
           (piVar7 = (int *)(**(code **)(*param_1 + 0xfc))(), piVar7 != (int *)0x0)) {
          if (*piVar7 == 0) {
            *(int *)(iVar4 + 0x94) = *(int *)(iVar4 + 0x94) + 1;
            *(int *)(iVar4 + 0x90) = *(int *)(iVar4 + 0x90) + 1;
            *piVar7 = 2;
            return;
          }
          if (*piVar7 == 1) {
            *(int *)(iVar4 + 0x90) = *(int *)(iVar4 + 0x90) + 1;
          }
          *piVar7 = 2;
        }
      }
    }
  }
  return;
}



/* FUNCTION 20490 ; VA 0x00a40100 ; FUN_00a40100 */

undefined4 * FUN_00a40100(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_005f4c10(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 20491 ; VA 0x00a40170 ; FUN_00a40170 */

void __fastcall FUN_00a40170(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x230) == 0) {
    ExceptionList = &pvStack_10;
    puVar5 = (undefined4 *)FUN_00a39da0(auStack_18);
    uVar1 = *puVar5;
    uVar2 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    *(undefined4 *)(param_1 + 0x230) = uVar1;
    piVar3 = *(int **)(param_1 + 0x234);
    *(undefined4 *)(param_1 + 0x234) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_14[1] + -1;
      piStack_14[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar3 = piStack_14 + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    puVar5 = (undefined4 *)(param_1 + 0x2a8);
    *(undefined *)(*(int *)(param_1 + 0x230) + 0x129) = 1;
    *(undefined *)(param_1 + 0x2a4) = 0;
    FUN_005596d0(*puVar5,*(undefined4 *)(param_1 + 0x2ac),puVar5);
    *(undefined4 *)(param_1 + 0x2ac) = *puVar5;
    if (DAT_01d660a0 != '\0') {
      if (*(int *)(param_1 + 0x228) != 0) {
        FUN_00fdd1b0(param_1 + 0x218);
        ExceptionList = pvStack_10;
        return;
      }
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = 0;
      FUN_005542c0("LocalizationService_GameSourceLanguageId_EmptyOnCreateCloudTable",0x40);
      uStack_8 = 0;
      FUN_008783f0(auStack_30,1,0);
      FUN_005507b0();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20492 ; VA 0x00a402d0 ; FUN_00a402d0 */

void __thiscall FUN_00a402d0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  undefined4 *puStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088cb40();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = *(undefined4 **)(param_1 + 0x44);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar6 = &uStack_35c;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_1bc = *puVar6;
    puStack_1b8 = (undefined4 *)0x0;
    puVar4 = (undefined4 *)puVar6[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(puVar6 + 2,auStack_1b4);
      puVar4 = (undefined4 *)puVar6[1];
    }
    puVar6 = &uStack_1bc;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
    puStack_1b8 = puVar4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_00888410();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar6);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, puStack_1b8 != (undefined4 *)0x0)) {
    (*(code *)puStack_1b8[2])(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20493 ; VA 0x00a40500 ; FUN_00a40500 */

void __thiscall FUN_00a40500(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_0088cb40();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  puVar6 = *(undefined4 **)(param_1 + 0x40);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uStack_8 = 1;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar6[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar6[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar6;
    uStack_e0 = puVar6[1];
    iStack_e8 = FUN_006309e0();
    puStack_18 = &uStack_ec;
    uStack_8 = 0;
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar3 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar2 = *(int *)(param_1 + 0x44);
  if (iVar2 == 0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar6 = &uStack_35c;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_1bc = FUN_0088cb40();
    iStack_1b8 = 0;
    FUN_0054ef60(iVar2);
    iStack_1b8 = FUN_005c9d30();
    puVar6 = &uStack_1bc;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20494 ; VA 0x00a40750 ; FUN_00a40750 */

int __thiscall FUN_00a40750(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_00a3a290(-(uint)(param_1 != -3) & param_1 + 4U,puVar1 + 2);
    FUN_01674ea0(puVar1,0x20);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    iVar2 = iVar2 + 1;
    puVar1 = (undefined4 *)*param_2;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 20495 ; VA 0x00a407b0 ; FUN_00a407b0 */

int FUN_00a407b0(int param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 param_5,
                int *param_6)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  int *piStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  int *piStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017de96f;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 2;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_290 = FUN_0088c8c0();
  uStack_28c = 0;
  uStack_288 = param_2;
  uStack_28c = FUN_005c9cc0();
  uStack_8._0_1_ = 3;
  uStack_1c0 = FUN_0088cdc0();
  uStack_1bc = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_1b8 = param_3;
  piStack_1b4 = param_4;
  uStack_1bc = FUN_006309e0();
  uStack_8._0_1_ = 4;
  uStack_f0 = FUN_0088cbe0();
  uStack_ec = 0;
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  uStack_e8 = param_5;
  piStack_e4 = param_6;
  uStack_ec = FUN_00630900();
  uStack_8._0_1_ = 5;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_290,&uStack_20,pcVar3);
  uStack_8._0_1_ = 6;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 7;
  FUN_00577b20();
  uStack_8._0_1_ = 2;
  FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  iVar5 = FUN_01675290(uVar4);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 20496 ; VA 0x00a409a0 ; FUN_00a409a0 */

void FUN_00a409a0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_00a3cd60(param_2,param_3,param_4);
  return;
}



/* FUNCTION 20497 ; VA 0x00a409c0 ; FUN_00a409c0 */

void FUN_00a409c0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_00a3ceb0(param_2,param_3,param_4);
  return;
}



/* FUNCTION 20498 ; VA 0x00a409e0 ; FUN_00a409e0 */

void FUN_00a409e0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  FUN_00a3d020(param_2,param_3,param_4,param_5);
  return;
}



/* FUNCTION 20499 ; VA 0x00a40a00 ; FUN_00a40a00 */

int FUN_00a40a00(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                int param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint in_stack_00000028;
  int aiStack_30 [5];
  uint uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017de998;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_5);
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iStack_18 != 0) {
    FUN_0054ef60(aiStack_30);
    iVar3 = FUN_00a47ee0(param_2,param_3,param_4);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (0xf < uStack_1c) {
    uVar4 = uStack_1c + 1;
    iVar3 = aiStack_30[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_30[0] + -4);
      uVar4 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar3 = FUN_01674ea0(iVar3,uVar4);
  }
  if (0xf < in_stack_00000028) {
    uVar4 = in_stack_00000028 + 1;
    iVar3 = param_5;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(param_5 + -4);
      uVar4 = in_stack_00000028 + 0x24;
      if (0x1f < (param_5 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar3 = FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return iVar3;
}


