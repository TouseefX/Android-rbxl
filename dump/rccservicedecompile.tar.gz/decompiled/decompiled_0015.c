/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 3750 ; VA 0x00578020 ; FUN_00578020 */

uint FUN_00578020(uint param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = param_1 * 8;
  if (param_1 < 0x20000000) {
    if (uVar3 < 0x1000) {
      if (uVar3 != 0) {
        uVar3 = FUN_01674e20(uVar3);
        return uVar3;
      }
      return 0;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar3 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar2;
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 3751 ; VA 0x00578090 ; FUN_00578090 */

uint FUN_00578090(uint param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = param_1 * 0xd0;
  if (param_1 < 0x13b13b2) {
    if (uVar3 < 0x1000) {
      if (uVar3 != 0) {
        uVar3 = FUN_01674e20(uVar3);
        return uVar3;
      }
      return 0;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar3 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar2;
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 3752 ; VA 0x00578100 ; FUN_00578100 */

void FUN_00578100(undefined4 param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794ef8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = GetProcessHeap(0,param_1);
  iVar3 = HeapAlloc(uVar2);
  if (iVar3 != 0) {
    ExceptionList = pvStack_10;
    return;
  }
  uVar2 = FUN_0054fbc0();
  uStack_8 = 0;
  FUN_005648a0(uVar2);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 3753 ; VA 0x00578160 ; FUN_00578160 */

int * __thiscall FUN_00578160(int *param_1,uint param_2,char param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  
  uVar2 = param_1[5];
  iVar8 = param_1[4];
  if (param_2 <= uVar2 - iVar8) {
    param_1[4] = iVar8 + param_2;
    piVar4 = param_1;
    if (0xf < uVar2) {
      piVar4 = (int *)*param_1;
    }
    FUN_0170d1f0(iVar8 + (int)piVar4,(int)param_3,param_2);
    *(undefined *)(iVar8 + (int)piVar4 + param_2) = 0;
    return param_1;
  }
  if (0x7fffffffU - iVar8 < param_2) {
    FUN_00554040();
LAB_005782b9:
                    /* WARNING: Subroutine does not return */
    FUN_017167a3();
  }
  uVar7 = iVar8 + param_2 | 0xf;
  if (uVar7 < 0x80000000) {
    if (0x7fffffff - (uVar2 >> 1) < uVar2) {
      uVar7 = 0x7fffffff;
    }
    else {
      uVar5 = (uVar2 >> 1) + uVar2;
      if (uVar7 < uVar5) {
        uVar7 = uVar5;
      }
    }
  }
  else {
    uVar7 = 0x7fffffff;
  }
  iVar6 = FUN_00554060(uVar7 + 1);
  param_1[4] = iVar8 + param_2;
  param_1[5] = uVar7;
  iVar1 = iVar6 + iVar8;
  if (uVar2 < 0x10) {
    FUN_0170c6f0(iVar6,param_1,iVar8);
    FUN_0170d1f0(iVar1,(int)param_3,param_2);
    *(undefined *)(iVar1 + param_2) = 0;
    *param_1 = iVar6;
    return param_1;
  }
  iVar3 = *param_1;
  FUN_0170c6f0(iVar6,iVar3,iVar8);
  FUN_0170d1f0(iVar1,(int)param_3,param_2);
  uVar7 = uVar2 + 1;
  *(undefined *)(iVar1 + param_2) = 0;
  iVar8 = iVar3;
  if (0xfff < uVar7) {
    iVar8 = *(int *)(iVar3 + -4);
    uVar7 = uVar2 + 0x24;
    if (0x1f < (iVar3 - iVar8) - 4U) goto LAB_005782b9;
  }
  FUN_01674ea0(iVar8,uVar7);
  *param_1 = iVar6;
  return param_1;
}



/* FUNCTION 3754 ; VA 0x005782c0 ; FUN_005782c0 */

int * __thiscall FUN_005782c0(int *param_1,uint param_2,char param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  code *pcVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  uint uVar8;
  
  uVar2 = param_1[5];
  if (param_2 <= uVar2) {
    piVar7 = param_1;
    if (0xf < uVar2) {
      piVar7 = (int *)*param_1;
    }
    param_1[4] = param_2;
    FUN_0170d1f0(piVar7,(int)param_3,param_2);
    *(undefined *)((int)piVar7 + param_2) = 0;
    return param_1;
  }
  if (0x7fffffff < param_2) {
    FUN_00554040();
    pcVar4 = (code *)swi(3);
    piVar7 = (int *)(*pcVar4)();
    return piVar7;
  }
  uVar8 = param_2 | 0xf;
  if (uVar8 < 0x80000000) {
    if (0x7fffffff - (uVar2 >> 1) < uVar2) {
      uVar8 = 0x7fffffff;
    }
    else {
      uVar1 = (uVar2 >> 1) + uVar2;
      if (uVar8 < uVar1) {
        uVar8 = uVar1;
      }
    }
  }
  else {
    uVar8 = 0x7fffffff;
  }
  iVar5 = FUN_00554060(uVar8 + 1);
  param_1[5] = uVar8;
  param_1[4] = param_2;
  FUN_0170d1f0(iVar5,(int)param_3,param_2);
  *(undefined *)(iVar5 + param_2) = 0;
  if (0xf < uVar2) {
    uVar8 = uVar2 + 1;
    iVar3 = *param_1;
    iVar6 = iVar3;
    if (0xfff < uVar8) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar8 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  *param_1 = iVar5;
  return param_1;
}



/* FUNCTION 3755 ; VA 0x005783b0 ; FUN_005783b0 */

void FUN_005783b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794f10;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0057efc0(param_1,param_2,param_3,param_4);
  FUN_0057ad10(param_1,0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3756 ; VA 0x0057840d ; Catch@0057840d */

undefined4 Catch_0057840d(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x18) + 4))();
  FUN_0057ad10(*(undefined4 *)(unaff_EBP + 8),uVar1);
  return 0x5783fa;
}



/* FUNCTION 3757 ; VA 0x00578430 ; FUN_00578430 */

int __thiscall FUN_00578430(int *param_1,uint param_2)

{
  code *pcVar1;
  int iVar2;
  
  if (param_2 < (uint)((param_1[1] - *param_1) / 0xd0)) {
    return param_2 * 0xd0 + *param_1;
  }
  FUN_00577c40();
  pcVar1 = (code *)swi(3);
  iVar2 = (*pcVar1)();
  return iVar2;
}



/* FUNCTION 3758 ; VA 0x00578470 ; FUN_00578470 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall
FUN_00578470(int param_1,int param_2,undefined4 *param_3,undefined4 param_4,undefined4 param_5,
            int param_6)

{
  int iVar1;
  undefined4 uVar2;
  char cVar3;
  double *pdVar4;
  double dVar5;
  undefined auStack_fc [4];
  undefined4 uStack_f8;
  char *pcStack_f4;
  undefined4 uStack_f0;
  undefined uStack_ec;
  undefined4 uStack_e4;
  int *piStack_e0;
  int iStack_dc;
  uint *puStack_d8;
  undefined4 **ppuStack_d4;
  undefined4 **ppuStack_d0;
  undefined auStack_c0 [32];
  uint auStack_a0 [2];
  uint auStack_98 [6];
  undefined auStack_80 [12];
  undefined auStack_74 [24];
  undefined4 **appuStack_5c [5];
  uint uStack_48;
  uint auStack_44 [2];
  uint auStack_3c [6];
  undefined4 uStack_24;
  undefined4 uStack_20;
  int aiStack_1c [2];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794f6e;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff34;
  uStack_8 = 0;
  if (0 < *(int *)(param_1 + 0xc4)) {
    ppuStack_d0 = (undefined4 **)0x18bf564;
    ppuStack_d4 = (undefined4 **)0x578734;
    ExceptionList = &pvStack_10;
    FUN_0054eff0();
    ppuStack_d0 = (undefined4 **)0x0;
    puStack_d8 = auStack_3c;
    uStack_8._0_1_ = 1;
    ppuStack_d4 = (undefined4 **)0x1;
    iStack_dc = 0x578745;
    FUN_008783f0();
    uStack_8._0_1_ = 0;
    ppuStack_d0 = (undefined4 **)0x578754;
    FUN_005507b0();
    ppuStack_d0 = (undefined4 **)0x0;
    ppuStack_d4 = (undefined4 **)0x0;
    puStack_d8 = (uint *)0xffffffff;
    iStack_dc = 0x578765;
    FUN_0151f6f0();
    ppuStack_d0 = (undefined4 **)0x18bf584;
    ppuStack_d4 = (undefined4 **)0x18bf590;
    uStack_8._0_1_ = 2;
    puStack_d8 = (uint *)0x57877e;
    FUN_0151f850();
    uVar2 = DAT_01e90d5c;
    ppuStack_d0 = (undefined4 **)0x18bf59c;
    ppuStack_d4 = (undefined4 **)0x578791;
    FUN_0054eff0();
    ppuStack_d0 = (undefined4 **)0x0;
    ppuStack_d4 = (undefined4 **)uVar2;
    puStack_d8 = auStack_3c;
    uStack_8._0_1_ = 3;
    iStack_dc = 0x5787a7;
    FUN_01520d20();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    ppuStack_d0 = (undefined4 **)0x5787b3;
    FUN_005507b0();
    ppuStack_d0 = (undefined4 **)0x18bf5b0;
                    /* WARNING: Subroutine does not return */
    ppuStack_d4 = (undefined4 **)FUN_005787bd;
    FUN_016757c0();
  }
  ppuStack_d0 = (undefined4 **)(param_2 + 8);
  ppuStack_d4 = (undefined4 **)0x5784bf;
  ExceptionList = &pvStack_10;
  puStack_14 = &stack0xffffff34;
  FUN_0054ef60();
  uStack_24 = 0;
  uStack_20 = 0;
  LOCK();
  *(int *)(param_1 + 0xc4) = *(int *)(param_1 + 0xc4) + 1;
  UNLOCK();
  ppuStack_d0 = (undefined4 **)&uStack_24;
  uStack_8._0_1_ = 6;
  ppuStack_d4 = (undefined4 **)0x0;
  puStack_d8 = param_3;
  piStack_e0 = aiStack_1c;
  iStack_dc = param_2;
  uStack_e4 = 0x5784e9;
  FUN_0057bff0();
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (param_6 != 0) {
    ppuStack_d0 = (undefined4 **)0x0;
    ppuStack_d4 = (undefined4 **)0x0;
    uStack_f0 = 0x10;
    iStack_dc = 0;
    puStack_d8 = (uint *)&DAT_0000000f;
    pcStack_f4 = "DataModelCreated";
    uStack_ec = 0;
    uStack_f8 = 0x57851a;
    FUN_005542c0();
    uStack_f0 = 0x578521;
    FUN_005db7a0();
    ppuStack_d0 = (undefined4 **)&param_6;
    ppuStack_d4 = (undefined4 **)0x578530;
    FUN_0056ecd0();
  }
  if (DAT_01d59035 != 0) {
    ppuStack_d0 = appuStack_5c;
    if (0xf < uStack_48) {
      ppuStack_d0 = appuStack_5c[0];
    }
    puStack_d8 = (uint *)(uint)DAT_01d59035;
    ppuStack_d4 = (undefined4 **)0x18bf5f8;
    iStack_dc = 0x578554;
    FUN_01677650();
    if (DAT_01d59035 != 0) {
      ppuStack_d0 = (undefined4 **)uStack_24;
      puStack_d8 = (uint *)(uint)DAT_01d59035;
      ppuStack_d4 = (undefined4 **)0x18bf610;
      iStack_dc = 0x578571;
      FUN_016774b0();
    }
  }
  ppuStack_d0 = (undefined4 **)0x0;
  FUN_0054ef60(appuStack_5c);
  FUN_0055d3f0(auStack_fc,FUN_005783b0,param_1);
  FUN_00558440();
  ppuStack_d0 = (undefined4 **)0x18bf620;
  ppuStack_d4 = (undefined4 **)auStack_a0;
  uStack_8._0_1_ = 8;
  puStack_d8 = auStack_44;
  iStack_dc = 0x5785c5;
  ppuStack_d0 = (undefined4 **)FUN_0151a450();
  uStack_8._0_1_ = 9;
  ppuStack_d4 = (undefined4 **)0x5785d5;
  FUN_00558700();
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  ppuStack_d0 = (undefined4 **)0x5785e1;
  FUN_016899e0();
  if (param_3 != (undefined4 *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      ppuStack_d0 = (undefined4 **)0x0;
      ppuStack_d4 = (undefined4 **)0x5785fa;
      (**(code **)*param_3)();
      ppuStack_d4 = (undefined4 **)param_3;
      puStack_d8 = (uint *)0x0;
      iStack_dc = 0x578603;
      iStack_dc = GetProcessHeap();
      piStack_e0 = (int *)0x57860a;
      HeapFree();
    }
  }
  uStack_8._0_1_ = 0xb;
  if (auStack_44[0] != 0) {
    if (((auStack_44[0] & 1) == 0) && (*(code **)(auStack_44[0] & 0xfffffffe) != (code *)0x0)) {
      puStack_d8 = auStack_3c;
      ppuStack_d0 = (undefined4 **)0x2;
      iStack_dc = 0x57862b;
      ppuStack_d4 = (undefined4 **)puStack_d8;
      (**(code **)(auStack_44[0] & 0xfffffffe))();
    }
    auStack_44[0] = 0;
  }
  uStack_8._0_1_ = 0xc;
  if (((auStack_a0[0] != 0) && ((auStack_a0[0] & 1) == 0)) &&
     (*(code **)(auStack_a0[0] & 0xfffffffe) != (code *)0x0)) {
    puStack_d8 = auStack_98;
    ppuStack_d0 = (undefined4 **)0x2;
    iStack_dc = 0x57865c;
    ppuStack_d4 = (undefined4 **)puStack_d8;
    (**(code **)(auStack_a0[0] & 0xfffffffe))();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  while( true ) {
    iVar1 = aiStack_1c[0];
    ppuStack_d0 = (undefined4 **)auStack_c0;
    ppuStack_d4 = (undefined4 **)0x578672;
    pdVar4 = (double *)FUN_01682800();
    dVar5 = *(double *)(iVar1 + 0x28) - *pdVar4;
    if (dVar5 <= 0.0) break;
    ppuStack_d0 = (undefined4 **)(3 - (int)(dVar5 * _DAT_018c0d88));
    ppuStack_d4 = (undefined4 **)0x5786cd;
    cVar3 = FUN_0151f440();
    if (cVar3 != '\0') {
      if (*(int *)(aiStack_1c[0] + 0x50) != 2) {
        ppuStack_d0 = (undefined4 **)0x0;
        ppuStack_d4 = appuStack_5c;
        puStack_d8 = (uint *)0x5786eb;
        FUN_0057ad10();
        ppuStack_d0 = (undefined4 **)0x5786f3;
        FUN_00550b30();
        ppuStack_d0 = (undefined4 **)0x5786fb;
        FUN_00550b30();
        ppuStack_d0 = (undefined4 **)0x578703;
        FUN_005507b0();
        ppuStack_d0 = (undefined4 **)0x57870b;
        FUN_00550b30();
        ExceptionList = pvStack_10;
        return;
      }
      ppuStack_d0 = (undefined4 **)0x578821;
      FUN_0054db20();
      ppuStack_d0 = (undefined4 **)0x578829;
      ppuStack_d0 = (undefined4 **)FUN_005543f0();
      puStack_d8 = (uint *)auStack_80;
      ppuStack_d4 = (undefined4 **)&DAT_018bd25c;
      iStack_dc = 0x578838;
      FUN_016756b0();
      ppuStack_d4 = (undefined4 **)auStack_80;
      ppuStack_d0 = (undefined4 **)&DAT_01c17198;
                    /* WARNING: Subroutine does not return */
      puStack_d8 = (uint *)&UNK_00578849;
      FUN_0170c2a8();
    }
  }
  ppuStack_d0 = (undefined4 **)0x1;
  ppuStack_d4 = (undefined4 **)0x578694;
  cVar3 = FUN_0151f440();
  if ((cVar3 != '\0') && (*(int *)(aiStack_1c[0] + 0x50) == 2)) {
    FUN_005787bd();
    return;
  }
  ppuStack_d0 = (undefined4 **)0x0;
  ppuStack_d4 = appuStack_5c;
  puStack_d8 = (uint *)0x5787fa;
  FUN_0057ad10();
  ppuStack_d4 = (undefined4 **)auStack_74;
  ppuStack_d0 = (undefined4 **)0x18bf630;
  puStack_d8 = (uint *)0x578808;
  FUN_016756b0();
  ppuStack_d4 = (undefined4 **)auStack_74;
  ppuStack_d0 = (undefined4 **)&DAT_01c17198;
                    /* WARNING: Subroutine does not return */
  puStack_d8 = (uint *)0x578819;
  FUN_0170c2a8();
}



/* FUNCTION 3759 ; VA 0x0057871e ; Catch@0057871e */

void Catch_0057871e(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 3760 ; VA 0x005787bd ; FUN_005787bd */

void FUN_005787bd(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  FUN_0054db20();
  uVar1 = FUN_005543f0();
  FUN_016756b0(unaff_EBP + -100,&DAT_018bd25c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(unaff_EBP + -100,&DAT_01c17198);
}



/* FUNCTION 3761 ; VA 0x00578850 ; FUN_00578850 */

/* WARNING: Removing unreachable block (ram,0x00578976) */
/* WARNING: Removing unreachable block (ram,0x00578989) */
/* WARNING: Removing unreachable block (ram,0x00578990) */
/* WARNING: Removing unreachable block (ram,0x00578997) */

undefined4 __thiscall
FUN_00578850(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  int *piVar6;
  int *piVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794f98;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  piVar7 = *(int **)(param_1 + 0xb4);
  uStack_8 = 0;
  piVar2 = (int *)*piVar7;
  while (piVar2 != piVar7) {
    piVar7 = (int *)piVar2[0xb];
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar7[1] = piVar7[1] + 1;
      UNLOCK();
      piVar7 = (int *)piVar2[0xb];
    }
    iVar3 = piVar2[10];
    piVar6 = *(int **)(iVar3 + 0x1c);
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      piVar6 = *(int **)(iVar3 + 0x1c);
    }
    uVar4 = *(undefined4 *)(iVar3 + 0x18);
    uVar5 = (uint)uStack_8 >> 8;
    uStack_8 = CONCAT31((int3)uVar5,2);
    piVar1 = piVar6 + 2;
    if (piVar6 != (int *)0x0) {
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_005f2ee0(uVar4,piVar6,param_4,param_2,param_3);
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar3 = piVar6[1] + -1;
      piVar6[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        iVar3 = *piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar3 = piVar7[1] + -1;
      piVar7[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar7)();
        LOCK();
        iVar3 = piVar7[2] + -1;
        piVar7[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    FUN_00551320();
    piVar7 = *(int **)(param_1 + 0xb4);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3762 ; VA 0x005789c0 ; FUN_005789c0 */

/* WARNING: Removing unreachable block (ram,0x00578b4c) */
/* WARNING: Removing unreachable block (ram,0x00578b51) */
/* WARNING: Removing unreachable block (ram,0x00578aca) */
/* WARNING: Removing unreachable block (ram,0x00578acf) */
/* WARNING: Removing unreachable block (ram,0x00578a5f) */
/* WARNING: Removing unreachable block (ram,0x00578a64) */

void FUN_005789c0(int *param_1,code *param_2)

{
  bool bVar1;
  int iVar2;
  int iStack_60;
  char acStack_5c [72];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794fb8;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff88;
  bVar1 = false;
  iStack_60 = 0;
  acStack_5c[0] = '\0';
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
LAB_00578a10:
  do {
    if (*param_1 == -0x3ea8cf1e) {
LAB_00578ae5:
      if ((iStack_60 != 0) && (iStack_60 != -1)) {
        CloseHandle(iStack_60);
      }
      ExceptionList = pvStack_10;
      return;
    }
    LOCK();
    iVar2 = *param_1;
    if (iVar2 == 0) {
      *param_1 = 0x7f0725e3;
      iVar2 = 0;
    }
    UNLOCK();
    if (iVar2 == 0) {
      if (iStack_60 == 0) {
        if (acStack_5c[0] == '\0') {
          FUN_005881c0(acStack_5c,param_1);
        }
        iStack_60 = OpenEventA(0x100002,0,acStack_5c);
        if (iStack_60 != 0) goto LAB_00578a6e;
      }
      else {
LAB_00578a6e:
        ResetEvent(iStack_60);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      (*param_2)();
      if (!bVar1) {
        LOCK();
        param_1[1] = param_1[1] + 1;
        UNLOCK();
      }
      LOCK();
      *param_1 = -0x3ea8cf1e;
      UNLOCK();
      if (iStack_60 == 0) {
        if (1 < param_1[1]) {
          if (acStack_5c[0] == '\0') {
            FUN_005881c0(acStack_5c,param_1);
          }
          iStack_60 = CreateEventA(0,1,0,acStack_5c);
        }
        if (iStack_60 == 0) {
          ExceptionList = pvStack_10;
          return;
        }
      }
      SetEvent(iStack_60);
      goto LAB_00578ae5;
    }
    if (!bVar1) {
      LOCK();
      param_1[1] = param_1[1] + 1;
      UNLOCK();
      bVar1 = true;
      if (*param_1 == -0x3ea8cf1e) goto LAB_00578ae5;
      if (iStack_60 == 0) {
        if (acStack_5c[0] == '\0') {
          FUN_005881c0(acStack_5c,param_1);
        }
        iStack_60 = CreateEventA(0,1,0,acStack_5c);
        goto LAB_00578a10;
      }
    }
    WaitForSingleObjectEx(iStack_60,0xffffffff,0);
  } while( true );
}



/* FUNCTION 3763 ; VA 0x00578b6f ; Catch_All@00578b6f */

void Catch_All_00578b6f(void)

{
  int unaff_EBP;
  
  FUN_0058a8e0(*(undefined4 *)(unaff_EBP + 8),unaff_EBP + -0x68);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 3764 ; VA 0x00578b90 ; FUN_00578b90 */

undefined4 FUN_00578b90(int *param_1)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = *param_1;
  piVar1 = (int *)(iVar2 + 0x2c);
  *piVar1 = *piVar1 + -1;
  return CONCAT31((int3)((uint)iVar2 >> 8),*piVar1 == 0);
}



/* FUNCTION 3765 ; VA 0x00578bb0 ; FUN_00578bb0 */

void __fastcall FUN_00578bb0(undefined4 *param_1)

{
  param_1[4] = 0;
  if (0xf < (uint)param_1[5]) {
    *(undefined *)*param_1 = 0;
    return;
  }
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 3766 ; VA 0x00578bc7 ; FUN_00578bc7 */

void FUN_00578bc7(void)

{
  FUN_00578bd0();
  return;
}



/* FUNCTION 3767 ; VA 0x00578bd0 ; FUN_00578bd0 */

int __fastcall FUN_00578bd0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179500b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_018c047c;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = boost::gregorian::bad_day_of_month::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_month>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_month>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_month>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3768 ; VA 0x00578ce7 ; FUN_00578ce7 */

void FUN_00578ce7(void)

{
  FUN_00578cf0();
  return;
}



/* FUNCTION 3769 ; VA 0x00578cf0 ; FUN_00578cf0 */

int __fastcall FUN_00578cf0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179505b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_018c08a0;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = boost::gregorian::bad_month::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_month>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_month>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_month>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3770 ; VA 0x00578e07 ; FUN_00578e07 */

void FUN_00578e07(void)

{
  FUN_00578e10();
  return;
}



/* FUNCTION 3771 ; VA 0x00578e10 ; FUN_00578e10 */

int __fastcall FUN_00578e10(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017950ab;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_018c08e0;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = boost::gregorian::bad_year::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_year>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_year>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_year>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3772 ; VA 0x00578f27 ; FUN_00578f27 */

void FUN_00578f27(void)

{
  FUN_00578f30();
  return;
}



/* FUNCTION 3773 ; VA 0x00578f30 ; FUN_00578f30 */

int __fastcall FUN_00578f30(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017950fb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_018c0600;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = std::bad_alloc::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_std::bad_alloc>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_std::bad_alloc>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<class_std::bad_alloc>_>::
         vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3774 ; VA 0x00579047 ; FUN_00579047 */

void FUN_00579047(void)

{
  FUN_00579050();
  return;
}



/* FUNCTION 3775 ; VA 0x00579050 ; FUN_00579050 */

int __fastcall FUN_00579050(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179514b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x34);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[10] = &DAT_018c06e4;
    puVar3[0xc] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x2c,puVar3 + 1);
    *puVar3 = boost::future_error::vftable;
    puVar3[3] = *(undefined4 *)(param_1 + -0x24);
    puVar3[4] = *(undefined4 *)(param_1 + -0x20);
    *puVar3 = boost::future_already_retrieved::vftable;
    puVar1 = puVar3 + 5;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[6] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[7] = *(undefined4 *)(param_1 + -0x14);
    puVar3[8] = *(undefined4 *)(param_1 + -0x10);
    puVar3[9] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_already_retrieved>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_already_retrieved>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[10] + 4) + 0x28 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_already_retrieved>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[10] + 4) + 0x24 + (int)puVar3) = *(int *)(puVar3[10] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[10] + 4) + 0x28 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3776 ; VA 0x00579179 ; FUN_00579179 */

void FUN_00579179(void)

{
  FUN_00579190();
  return;
}



/* FUNCTION 3777 ; VA 0x00579190 ; FUN_00579190 */

int __fastcall FUN_00579190(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179519b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x34);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[10] = &DAT_018c0860;
    puVar3[0xc] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x2c,puVar3 + 1);
    *puVar3 = boost::future_error::vftable;
    puVar3[3] = *(undefined4 *)(param_1 + -0x24);
    puVar3[4] = *(undefined4 *)(param_1 + -0x20);
    *puVar3 = boost::future_uninitialized::vftable;
    puVar1 = puVar3 + 5;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[6] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[7] = *(undefined4 *)(param_1 + -0x14);
    puVar3[8] = *(undefined4 *)(param_1 + -0x10);
    puVar3[9] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_uninitialized>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_uninitialized>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[10] + 4) + 0x28 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::future_uninitialized>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[10] + 4) + 0x24 + (int)puVar3) = *(int *)(puVar3[10] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[10] + 4) + 0x28 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3778 ; VA 0x005792b9 ; FUN_005792b9 */

void FUN_005792b9(void)

{
  FUN_005792d0();
  return;
}



/* FUNCTION 3779 ; VA 0x005792d0 ; FUN_005792d0 */

int __fastcall FUN_005792d0(int param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017951e3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x4c);
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[0x10] = &DAT_018c0724;
    puVar1[0x12] = boost::exception_detail::clone_base::vftable;
    uStack_8 = 1;
    FUN_005680e0(param_1 + -0x48);
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::lock_error>_>
              ::vftable;
    puVar1[0xb] = boost::exception_detail::
                  clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::lock_error>_>
                  ::vftable;
    uStack_8 = 2;
    *(undefined ***)(*(int *)(puVar1[0x10] + 4) + 0x40 + (int)puVar1) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::lock_error>_>::
         vftable;
    *(int *)(*(int *)(puVar1[0x10] + 4) + 0x3c + (int)puVar1) = *(int *)(puVar1[0x10] + 4) + -8;
    FUN_00554960(puVar1 + 0xb,-(uint)(param_1 + -0x48 != 0) & param_1 - 0x1cU);
    ExceptionList = pvStack_10;
    return *(int *)(puVar1[0x10] + 4) + 0x40 + (int)puVar1;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3780 ; VA 0x005793a9 ; FUN_005793a9 */

void FUN_005793a9(void)

{
  FUN_005793c0();
  return;
}



/* FUNCTION 3781 ; VA 0x005793c0 ; FUN_005793c0 */

int __fastcall FUN_005793c0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179522b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x34);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[10] = &DAT_018c0640;
    puVar3[0xc] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x2c,puVar3 + 1);
    *puVar3 = boost::future_error::vftable;
    puVar3[3] = *(undefined4 *)(param_1 + -0x24);
    puVar3[4] = *(undefined4 *)(param_1 + -0x20);
    *puVar3 = boost::promise_already_satisfied::vftable;
    puVar1 = puVar3 + 5;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[6] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[7] = *(undefined4 *)(param_1 + -0x14);
    puVar3[8] = *(undefined4 *)(param_1 + -0x10);
    puVar3[9] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_already_satisfied>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_already_satisfied>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[10] + 4) + 0x28 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_already_satisfied>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[10] + 4) + 0x24 + (int)puVar3) = *(int *)(puVar3[10] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[10] + 4) + 0x28 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3782 ; VA 0x005794e9 ; FUN_005794e9 */

void FUN_005794e9(void)

{
  FUN_00579500();
  return;
}



/* FUNCTION 3783 ; VA 0x00579500 ; FUN_00579500 */

int __fastcall FUN_00579500(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179527b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x34);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[10] = &DAT_018c06a4;
    puVar3[0xc] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x2c,puVar3 + 1);
    *puVar3 = boost::future_error::vftable;
    puVar3[3] = *(undefined4 *)(param_1 + -0x24);
    puVar3[4] = *(undefined4 *)(param_1 + -0x20);
    *puVar3 = boost::promise_moved::vftable;
    puVar1 = puVar3 + 5;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[6] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[7] = *(undefined4 *)(param_1 + -0x14);
    puVar3[8] = *(undefined4 *)(param_1 + -0x10);
    puVar3[9] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_moved>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_moved>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[10] + 4) + 0x28 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::promise_moved>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[10] + 4) + 0x24 + (int)puVar3) = *(int *)(puVar3[10] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[10] + 4) + 0x28 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3784 ; VA 0x00579629 ; FUN_00579629 */

void FUN_00579629(void)

{
  FUN_00579640();
  return;
}



/* FUNCTION 3785 ; VA 0x00579640 ; FUN_00579640 */

int __fastcall FUN_00579640(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017952cb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_018c0ac4;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = std::bad_alloc::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_alloc>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_alloc>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_alloc>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3786 ; VA 0x00579757 ; FUN_00579757 */

void FUN_00579757(void)

{
  FUN_00579760();
  return;
}



/* FUNCTION 3787 ; VA 0x00579760 ; FUN_00579760 */

int __fastcall FUN_00579760(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179531b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_018c0af0;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = std::bad_cast::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_cast>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_cast>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_cast>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3788 ; VA 0x00579877 ; FUN_00579877 */

void FUN_00579877(void)

{
  FUN_00579880();
  return;
}



/* FUNCTION 3789 ; VA 0x00579880 ; FUN_00579880 */

int __fastcall FUN_00579880(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179536b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_018c0b48;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = std::bad_exception::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_exception>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_exception>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_exception>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3790 ; VA 0x00579997 ; FUN_00579997 */

void FUN_00579997(void)

{
  FUN_005799a0();
  return;
}



/* FUNCTION 3791 ; VA 0x005799a0 ; FUN_005799a0 */

int __fastcall FUN_005799a0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017953bb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_018c0b1c;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = std::bad_typeid::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_typeid>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_typeid>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_typeid>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3792 ; VA 0x00579ab7 ; FUN_00579ab7 */

void FUN_00579ab7(void)

{
  FUN_00579ac0();
  return;
}



/* FUNCTION 3793 ; VA 0x00579ac0 ; FUN_00579ac0 */

int __fastcall FUN_00579ac0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179540b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_018c090c;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = std::domain_error::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::domain_error>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::domain_error>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::domain_error>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3794 ; VA 0x00579bd7 ; FUN_00579bd7 */

void FUN_00579bd7(void)

{
  FUN_00579be0();
  return;
}



/* FUNCTION 3795 ; VA 0x00579be0 ; FUN_00579be0 */

int __fastcall FUN_00579be0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179545b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x34);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[10] = &DAT_018c0a6c;
    puVar3[0xc] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x2c,puVar3 + 1);
    *puVar3 = std::_System_error::vftable;
    puVar3[3] = *(undefined4 *)(param_1 + -0x24);
    puVar3[4] = *(undefined4 *)(param_1 + -0x20);
    *puVar3 = std::ios_base::failure::vftable;
    puVar1 = puVar3 + 5;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[6] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[7] = *(undefined4 *)(param_1 + -0x14);
    puVar3[8] = *(undefined4 *)(param_1 + -0x10);
    puVar3[9] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::ios_base::failure>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::ios_base::failure>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[10] + 4) + 0x28 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::ios_base::failure>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[10] + 4) + 0x24 + (int)puVar3) = *(int *)(puVar3[10] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[10] + 4) + 0x28 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3796 ; VA 0x00579d09 ; FUN_00579d09 */

void FUN_00579d09(void)

{
  FUN_00579d20();
  return;
}



/* FUNCTION 3797 ; VA 0x00579d20 ; FUN_00579d20 */

int __fastcall FUN_00579d20(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017954ab;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_018c0938;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = std::invalid_argument::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::invalid_argument>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::invalid_argument>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::invalid_argument>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3798 ; VA 0x00579e37 ; FUN_00579e37 */

void FUN_00579e37(void)

{
  FUN_00579e40();
  return;
}



/* FUNCTION 3799 ; VA 0x00579e40 ; FUN_00579e40 */

int __fastcall FUN_00579e40(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017954fb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_018c0964;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = std::length_error::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::length_error>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::length_error>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::length_error>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3800 ; VA 0x00579f57 ; FUN_00579f57 */

void FUN_00579f57(void)

{
  FUN_00579f60();
  return;
}



/* FUNCTION 3801 ; VA 0x00579f60 ; FUN_00579f60 */

int __fastcall FUN_00579f60(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179554b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_018c09bc;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = std::logic_error::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::logic_error>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::logic_error>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::logic_error>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3802 ; VA 0x0057a077 ; FUN_0057a077 */

void FUN_0057a077(void)

{
  FUN_0057a080();
  return;
}



/* FUNCTION 3803 ; VA 0x0057a080 ; FUN_0057a080 */

int __fastcall FUN_0057a080(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179559b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_018c0990;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = std::out_of_range::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::out_of_range>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::out_of_range>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::out_of_range>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3804 ; VA 0x0057a197 ; FUN_0057a197 */

void FUN_0057a197(void)

{
  FUN_0057a1a0();
  return;
}



/* FUNCTION 3805 ; VA 0x0057a1a0 ; FUN_0057a1a0 */

int __fastcall FUN_0057a1a0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017955eb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_018c0a14;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = std::overflow_error::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::overflow_error>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::overflow_error>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::overflow_error>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3806 ; VA 0x0057a2b7 ; FUN_0057a2b7 */

void FUN_0057a2b7(void)

{
  FUN_0057a2c0();
  return;
}



/* FUNCTION 3807 ; VA 0x0057a2c0 ; FUN_0057a2c0 */

int __fastcall FUN_0057a2c0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179563b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_018c09e8;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = std::range_error::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::range_error>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::range_error>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::range_error>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3808 ; VA 0x0057a3d7 ; FUN_0057a3d7 */

void FUN_0057a3d7(void)

{
  FUN_0057a3e0();
  return;
}



/* FUNCTION 3809 ; VA 0x0057a3e0 ; FUN_0057a3e0 */

int __fastcall FUN_0057a3e0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179568b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_018c0a98;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = std::runtime_error::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::runtime_error>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::runtime_error>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::runtime_error>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3810 ; VA 0x0057a4f7 ; FUN_0057a4f7 */

void FUN_0057a4f7(void)

{
  FUN_0057a500();
  return;
}



/* FUNCTION 3811 ; VA 0x0057a500 ; FUN_0057a500 */

int __fastcall FUN_0057a500(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017956db;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_018c0a40;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = std::underflow_error::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::underflow_error>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::underflow_error>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<class_boost::exception_detail::current_exception_std_exception_wrapper<class_std::underflow_error>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3812 ; VA 0x0057a617 ; FUN_0057a617 */

void FUN_0057a617(void)

{
  FUN_0057a620();
  return;
}



/* FUNCTION 3813 ; VA 0x0057a620 ; FUN_0057a620 */

int __fastcall FUN_0057a620(int param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[5] = &DAT_018c0664;
    puVar1[7] = boost::exception_detail::clone_base::vftable;
    *puVar1 = std::exception::vftable;
    *(undefined8 *)(puVar1 + 1) = 0;
    FUN_0170c226(param_1 + -0x18,puVar1 + 1);
    *puVar1 = boost::future_error::vftable;
    puVar1[3] = *(undefined4 *)(param_1 + -0x10);
    puVar1[4] = *(undefined4 *)(param_1 + -0xc);
    *puVar1 = boost::exception_detail::clone_impl<class_boost::broken_promise>::vftable;
    *(undefined ***)(*(int *)(puVar1[5] + 4) + 0x14 + (int)puVar1) =
         boost::exception_detail::clone_impl<class_boost::broken_promise>::vftable;
    *(int *)(*(int *)(puVar1[5] + 4) + 0x10 + (int)puVar1) = *(int *)(puVar1[5] + 4) + -8;
    return *(int *)(puVar1[5] + 4) + 0x14 + (int)puVar1;
  }
  return 0;
}



/* FUNCTION 3814 ; VA 0x0057a6b2 ; FUN_0057a6b2 */

void FUN_0057a6b2(void)

{
  FUN_0057a6c0();
  return;
}



/* FUNCTION 3815 ; VA 0x0057a6c0 ; FUN_0057a6c0 */

int __fastcall FUN_0057a6c0(int param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795723;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x34);
  uStack_8 = 0;
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[10] = &DAT_018c07d0;
    puVar1[0xc] = boost::exception_detail::clone_base::vftable;
    *puVar1 = std::exception::vftable;
    *(undefined8 *)(puVar1 + 1) = 0;
    FUN_0170c226(param_1 + -0x2c,puVar1 + 1);
    uStack_8 = 2;
    *puVar1 = RBX::http_status_error::vftable;
    FUN_0054ef60(param_1 + -0x24);
    puVar1[9] = *(undefined4 *)(param_1 + -0xc);
    *puVar1 = boost::exception_detail::clone_impl<class_RBX::http_status_error>::vftable;
    *(undefined ***)(*(int *)(puVar1[10] + 4) + 0x28 + (int)puVar1) =
         boost::exception_detail::clone_impl<class_RBX::http_status_error>::vftable;
    *(int *)(*(int *)(puVar1[10] + 4) + 0x24 + (int)puVar1) = *(int *)(puVar1[10] + 4) + -8;
    ExceptionList = pvStack_10;
    return *(int *)(puVar1[10] + 4) + 0x28 + (int)puVar1;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3816 ; VA 0x0057a7a3 ; FUN_0057a7a3 */

void FUN_0057a7a3(void)

{
  FUN_0057a7b0();
  return;
}



/* FUNCTION 3817 ; VA 0x0057a7b0 ; FUN_0057a7b0 */

int __fastcall FUN_0057a7b0(int param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[3] = &DAT_018c07ac;
    puVar1[5] = boost::exception_detail::clone_base::vftable;
    *puVar1 = std::exception::vftable;
    *(undefined8 *)(puVar1 + 1) = 0;
    FUN_0170c226(param_1 + -0x10,puVar1 + 1);
    *puVar1 = boost::exception_detail::clone_impl<class_std::runtime_error>::vftable;
    *(undefined ***)(*(int *)(puVar1[3] + 4) + 0xc + (int)puVar1) =
         boost::exception_detail::clone_impl<class_std::runtime_error>::vftable;
    *(int *)(*(int *)(puVar1[3] + 4) + 8 + (int)puVar1) = *(int *)(puVar1[3] + 4) + -8;
    return *(int *)(puVar1[3] + 4) + 0xc + (int)puVar1;
  }
  return 0;
}



/* FUNCTION 3818 ; VA 0x0057a830 ; FUN_0057a830 */

void FUN_0057a830(void)

{
  FUN_0057a840();
  return;
}



/* FUNCTION 3819 ; VA 0x0057a840 ; FUN_0057a840 */

int __fastcall FUN_0057a840(int param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795763;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[8] = &DAT_018c04a8;
    puVar1[10] = boost::exception_detail::clone_base::vftable;
    uStack_8 = 1;
    FUN_0056b5e0(param_1 + -0x28);
    *puVar1 = boost::exception_detail::clone_impl<class_boost::unknown_exception>::vftable;
    puVar1[5] = boost::exception_detail::clone_impl<class_boost::unknown_exception>::vftable;
    uStack_8 = 2;
    *(undefined ***)(*(int *)(puVar1[8] + 4) + 0x20 + (int)puVar1) =
         boost::exception_detail::clone_impl<class_boost::unknown_exception>::vftable;
    *(int *)(*(int *)(puVar1[8] + 4) + 0x1c + (int)puVar1) = *(int *)(puVar1[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x28);
    ExceptionList = pvStack_10;
    return *(int *)(puVar1[8] + 4) + 0x20 + (int)puVar1;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3820 ; VA 0x0057a910 ; FUN_0057a910 */

int * __thiscall FUN_0057a910(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  int *piVar5;
  int iVar6;
  undefined4 uVar7;
  int *piVar8;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017957a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  uStack_8 = 0;
  piVar5 = (int *)FUN_01674e20(0x28);
  uStack_8 = 0;
  if (piVar5 == (int *)0x0) {
    piVar5 = (int *)0x0;
  }
  else {
    *piVar5 = (int)boost::exception_detail::error_info_container_impl::vftable;
    uStack_8 = 2;
    piVar5[1] = 0;
    piVar5[2] = 0;
    iVar6 = FUN_00575ad0();
    piVar5[1] = iVar6;
    piVar5[7] = 0;
    piVar5[8] = 0xf;
    *(undefined *)(piVar5 + 3) = 0;
    piVar5[9] = 0;
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (((int *)*param_2 != (int *)0x0) &&
     (cVar4 = (**(code **)(*(int *)*param_2 + 0x10))(), cVar4 != '\0')) {
    *param_2 = 0;
  }
  *param_2 = (int)piVar5;
  if (piVar5 != (int *)0x0) {
    (**(code **)(*piVar5 + 0xc))();
  }
  piVar8 = piVar5 + 1;
  if (piVar8 != (int *)(param_1 + 4)) {
    iVar6 = *piVar8;
    uStack_8 = 3;
    FUN_005765a0(*(undefined4 *)(iVar6 + 4));
    uStack_8 = uStack_8 & 0xffffff00;
    *(int *)(*piVar8 + 4) = iVar6;
    *(int *)*piVar8 = iVar6;
    *(int *)(*piVar8 + 8) = iVar6;
    piVar5[2] = 0;
    uVar7 = FUN_005593c0(*(undefined4 *)(*(int *)(param_1 + 4) + 4),*piVar8,param_2);
    *(undefined4 *)(*piVar8 + 4) = uVar7;
    piVar1 = (int *)*piVar8;
    piVar5[2] = *(int *)(param_1 + 8);
    piVar5 = (int *)piVar1[1];
    if (*(char *)((int)piVar5 + 0xd) == '\0') {
      cVar4 = *(char *)(*piVar5 + 0xd);
      piVar3 = (int *)*piVar5;
      while (cVar4 == '\0') {
        cVar4 = *(char *)(*piVar3 + 0xd);
        piVar5 = piVar3;
        piVar3 = (int *)*piVar3;
      }
      *piVar1 = (int)piVar5;
      iVar6 = *(int *)(*piVar8 + 4);
      iVar2 = *(int *)(iVar6 + 8);
      cVar4 = *(char *)(iVar2 + 0xd);
      while (cVar4 == '\0') {
        cVar4 = *(char *)(*(int *)(iVar2 + 8) + 0xd);
        iVar6 = iVar2;
        iVar2 = *(int *)(iVar2 + 8);
      }
      *(int *)(*piVar8 + 8) = iVar6;
    }
    else {
      *piVar1 = (int)piVar1;
      *(int *)(*piVar8 + 8) = *piVar8;
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 3821 ; VA 0x0057aa90 ; FUN_0057aa90 */

void __fastcall FUN_0057aa90(int *param_1)

{
  int iVar1;
  
  iVar1 = FUN_005548a0();
  if (iVar1 == 0) {
    FUN_00554460((uint)(*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) == 0) * 4 + 2 |
                 *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc),0);
  }
  return;
}



/* FUNCTION 3822 ; VA 0x0057aad0 ; FUN_0057aad0 */

void __fastcall FUN_0057aad0(int *param_1)

{
  int iVar1;
  
  iVar1 = FUN_005548a0();
  if (iVar1 == 0) {
    FUN_00554460((uint)(*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) == 0) * 4 + 2 |
                 *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc),0);
  }
  return;
}



/* FUNCTION 3823 ; VA 0x0057ab10 ; FUN_0057ab10 */

/* WARNING: Removing unreachable block (ram,0x0057abcc) */
/* WARNING: Removing unreachable block (ram,0x0057abdf) */
/* WARNING: Removing unreachable block (ram,0x0057abe6) */
/* WARNING: Removing unreachable block (ram,0x0057abed) */

void __thiscall FUN_0057ab10(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017957c0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01d59035 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01d59035,"Closing all jobs command",0);
  }
  iStack_28 = 0;
  iStack_8 = 0;
  FUN_00587410();
  piVar1 = *(int **)(param_1 + 0xb4);
  iStack_8._0_1_ = 1;
  piVar2 = (int *)*piVar1;
  while (piVar2 != piVar1) {
    iVar3 = (int)(piVar2 + 4);
    if (iStack_28 == 0) {
      FUN_00559960(0,iVar3);
    }
    else {
      FUN_0054ef60(iVar3);
      iStack_28 = iStack_28 + 0x18;
    }
    FUN_00551320();
  }
  iVar3 = 0;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  *param_2 = iStack_28 / 0x18;
  if (iStack_28 != 0) {
    do {
      FUN_0057ad10(iVar3,0);
      iVar3 = iVar3 + 0x18;
    } while (iVar3 != iStack_28);
  }
  FUN_00577a40();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3824 ; VA 0x0057ac50 ; FUN_0057ac50 */

int FUN_0057ac50(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017957e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_01255470(8,0,0,0);
  FUN_01255490();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  FUN_008f1110(param_1,param_2);
  iVar3 = FUN_01255500();
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 3825 ; VA 0x0057ad10 ; FUN_0057ad10 */

/* WARNING: Removing unreachable block (ram,0x0057b2f0) */
/* WARNING: Removing unreachable block (ram,0x0057b2f9) */
/* WARNING: Removing unreachable block (ram,0x0057b307) */
/* WARNING: Removing unreachable block (ram,0x0057b263) */
/* WARNING: Removing unreachable block (ram,0x0057b26c) */
/* WARNING: Removing unreachable block (ram,0x0057b27c) */
/* WARNING: Removing unreachable block (ram,0x0057b1d4) */
/* WARNING: Removing unreachable block (ram,0x0057b1de) */
/* WARNING: Removing unreachable block (ram,0x0057b1e7) */
/* WARNING: Removing unreachable block (ram,0x0057b1e9) */
/* WARNING: Removing unreachable block (ram,0x0057b204) */
/* WARNING: Removing unreachable block (ram,0x0057b216) */
/* WARNING: Removing unreachable block (ram,0x0057b187) */
/* WARNING: Removing unreachable block (ram,0x0057b01b) */
/* WARNING: Removing unreachable block (ram,0x0057b024) */
/* WARNING: Removing unreachable block (ram,0x0057b032) */
/* WARNING: Removing unreachable block (ram,0x0057afd4) */
/* WARNING: Removing unreachable block (ram,0x0057afdd) */
/* WARNING: Removing unreachable block (ram,0x0057afed) */
/* WARNING: Removing unreachable block (ram,0x0057aecb) */
/* WARNING: Removing unreachable block (ram,0x0057aed5) */
/* WARNING: Removing unreachable block (ram,0x0057aede) */
/* WARNING: Removing unreachable block (ram,0x0057aee0) */
/* WARNING: Removing unreachable block (ram,0x0057aefb) */
/* WARNING: Removing unreachable block (ram,0x0057af0d) */
/* WARNING: Removing unreachable block (ram,0x0057af31) */
/* WARNING: Removing unreachable block (ram,0x0057af35) */
/* WARNING: Removing unreachable block (ram,0x0057af5a) */
/* WARNING: Removing unreachable block (ram,0x0057af63) */
/* WARNING: Removing unreachable block (ram,0x0057af73) */
/* WARNING: Removing unreachable block (ram,0x0057af78) */
/* WARNING: Removing unreachable block (ram,0x0057af8e) */
/* WARNING: Removing unreachable block (ram,0x0057ae7e) */
/* WARNING: Removing unreachable block (ram,0x0057ae95) */
/* WARNING: Removing unreachable block (ram,0x0057aea5) */
/* WARNING: Removing unreachable block (ram,0x0057aea9) */
/* WARNING: Removing unreachable block (ram,0x0057aeb0) */
/* WARNING: Removing unreachable block (ram,0x0057afc5) */
/* WARNING: Removing unreachable block (ram,0x0057aff9) */
/* WARNING: Removing unreachable block (ram,0x0057b002) */
/* WARNING: Removing unreachable block (ram,0x0057b012) */
/* WARNING: Removing unreachable block (ram,0x0057b04a) */
/* WARNING: Removing unreachable block (ram,0x0057b19e) */
/* WARNING: Removing unreachable block (ram,0x0057b1ae) */
/* WARNING: Removing unreachable block (ram,0x0057b1b2) */
/* WARNING: Removing unreachable block (ram,0x0057b1b9) */
/* WARNING: Removing unreachable block (ram,0x0057b23a) */
/* WARNING: Removing unreachable block (ram,0x0057b23e) */
/* WARNING: Removing unreachable block (ram,0x0057b281) */
/* WARNING: Removing unreachable block (ram,0x0057b297) */
/* WARNING: Removing unreachable block (ram,0x0057b2ce) */
/* WARNING: Removing unreachable block (ram,0x0057b2d7) */
/* WARNING: Removing unreachable block (ram,0x0057b2e7) */
/* WARNING: Removing unreachable block (ram,0x0057b31b) */
/* WARNING: Removing unreachable block (ram,0x0057b31e) */
/* WARNING: Removing unreachable block (ram,0x0057b32a) */
/* WARNING: Removing unreachable block (ram,0x0057b332) */
/* WARNING: Removing unreachable block (ram,0x0057b339) */

undefined4 __thiscall FUN_0057ad10(int param_1,undefined4 *param_2,char *param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  char *pcVar5;
  undefined4 *puVar6;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795858;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff88;
  iStack_18 = param_1;
  if (DAT_01d59320 == '\0') {
    ExceptionList = &pvStack_10;
    FUN_00587410();
    uStack_8._0_1_ = 0xd;
    uStack_8._1_3_ = 0;
    FUN_00587410();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
    piStack_20 = (int *)(param_1 + 0xb4);
    FUN_005875d0(&piStack_24,param_2);
    piStack_1c = *(int **)(param_1 + 0xb4);
    if (piStack_24 != piStack_1c) {
      piVar4 = piStack_24 + 4;
      if (0xf < (uint)piStack_24[9]) {
        piVar4 = (int *)*piVar4;
      }
      puVar6 = param_2;
      if (0xf < (uint)param_2[5]) {
        puVar6 = (undefined4 *)*param_2;
      }
      iVar2 = FUN_0055c2d0(puVar6,param_2[4],piVar4,piStack_24[8]);
      piVar4 = piStack_24;
      if (-1 < iVar2) goto LAB_0057b0ee;
    }
    piVar4 = piStack_1c;
LAB_0057b0ee:
    if (piVar4 != piStack_1c) {
      if (param_3 == (char *)0x0) {
        *(undefined4 *)(piVar4[10] + 0x50) = 1;
      }
      else {
        pcVar5 = param_3;
        do {
          cVar1 = *pcVar5;
          pcVar5 = pcVar5 + 1;
        } while (cVar1 != '\0');
        FUN_005542c0(param_3,(int)pcVar5 - (int)(param_3 + 1));
        *(undefined4 *)(piVar4[10] + 0x50) = 2;
      }
      FUN_0151f3f0();
      FUN_0056ecd0(piVar4[10] + 0x18);
      FUN_0056ecd0(piVar4[10] + 0x20);
      FUN_01679490();
      uVar3 = FUN_00553830(piVar4);
      FUN_0056cac0();
      FUN_01674ea0(uVar3,0x30);
    }
    uStack_8._0_1_ = 0xd;
    if ((DAT_01d648e4 != '\0') && (DAT_01d648fc != '\0')) {
      FUN_00994e00();
    }
    uVar3 = FUN_008763f0();
    PTR_DAT_01d7a63c = s_CompletedShutdown_018bdec8;
    ExceptionList = pvStack_10;
    return uVar3;
  }
  ExceptionList = &pvStack_10;
  puStack_14 = &stack0xffffff88;
  FUN_00587410();
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  FUN_00587410();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  piStack_24 = (int *)(param_1 + 0xb4);
  FUN_005875d0(&piStack_20,param_2);
  piStack_1c = *(int **)(param_1 + 0xb4);
  if (piStack_20 != piStack_1c) {
    piVar4 = piStack_20 + 4;
    if (0xf < (uint)piStack_20[9]) {
      piVar4 = (int *)*piVar4;
    }
    puVar6 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar6 = (undefined4 *)*param_2;
    }
    iVar2 = FUN_0055c2d0(puVar6,param_2[4],piVar4,piStack_20[8]);
    piVar4 = piStack_20;
    if (-1 < iVar2) goto LAB_0057adeb;
  }
  piVar4 = piStack_1c;
LAB_0057adeb:
  if (piVar4 != piStack_1c) {
    FUN_0056ecd0(piVar4 + 10);
    if (param_3 == (char *)0x0) {
      uRam00000050 = 1;
    }
    else {
      pcVar5 = param_3;
      do {
        cVar1 = *pcVar5;
        pcVar5 = pcVar5 + 1;
      } while (cVar1 != '\0');
      FUN_005542c0(param_3,(int)pcVar5 - (int)(param_3 + 1));
      uRam00000050 = 2;
    }
    FUN_0056ecd0(0x18);
    FUN_0056ecd0(0x20);
    FUN_01679490();
    uVar3 = FUN_00553830(piVar4);
    FUN_0056cac0();
    FUN_01674ea0(uVar3,0x30);
  }
  uStack_8._0_1_ = 3;
  if ((DAT_01d648e4 != '\0') && (DAT_01d648fc != '\0')) {
    FUN_00994e00();
  }
  uVar3 = FUN_008763f0();
  PTR_DAT_01d7a63c = s_CompletedShutdown_018bdec8;
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 3826 ; VA 0x0057b358 ; Catch@0057b358 */

void Catch_0057b358(void)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int unaff_EBP;
  
  if (DAT_01d59035 != '\0') {
    uVar3 = (**(code **)(**(int **)(unaff_EBP + -0x24) + 4))();
    FUN_01677650(DAT_01d59035,"Caught exception closing data model: %s",uVar3);
  }
  *(undefined4 *)(unaff_EBP + -0x58) = 0;
  *(undefined4 *)(unaff_EBP + -0x54) = 0xf;
  *(undefined *)(unaff_EBP + -0x68) = 0;
  FUN_005542c0("RCCCloseDataModelFailure",0x18);
  *(undefined *)(unaff_EBP + -4) = 8;
  FUN_008783f0(unaff_EBP + -0x68,1,0);
  *(undefined *)(unaff_EBP + -4) = 7;
  FUN_005507b0();
  uVar3 = FUN_01675640(unaff_EBP + -0x68,"RCCCloseDataModelFailure_%d",DAT_01d7a884);
  *(undefined *)(unaff_EBP + -4) = 9;
  FUN_008783f0(uVar3,1,0);
  *(undefined *)(unaff_EBP + -4) = 7;
  FUN_005507b0();
  FUN_008763f0();
  LOCK();
  piVar1 = (int *)(*(int *)(unaff_EBP + -0x14) + 0xc4);
  iVar2 = *piVar1 + -1;
  *piVar1 = iVar2;
  UNLOCK();
  if (iVar2 == 0) {
    FUN_00554b10();
  }
  FUN_01675310("CloseJobFailure",&DAT_018bc9b8);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 3827 ; VA 0x0057b426 ; Catch@0057b426 */

void Catch_0057b426(void)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int unaff_EBP;
  
  if (DAT_01d59035 != '\0') {
    uVar3 = (**(code **)(**(int **)(unaff_EBP + -0x28) + 4))();
    FUN_01677650(DAT_01d59035,"Caught exception closing data model: %s",uVar3);
  }
  *(undefined4 *)(unaff_EBP + -0x58) = 0;
  *(undefined4 *)(unaff_EBP + -0x54) = 0xf;
  *(undefined *)(unaff_EBP + -0x68) = 0;
  FUN_005542c0("RCCCloseDataModelFailure",0x18);
  *(undefined *)(unaff_EBP + -4) = 0x12;
  FUN_008783f0(unaff_EBP + -0x68,1,0);
  *(undefined *)(unaff_EBP + -4) = 0x11;
  FUN_005507b0();
  uVar3 = FUN_01675640(unaff_EBP + -0x68,"RCCCloseDataModelFailure_%d",DAT_01d7a884);
  *(undefined *)(unaff_EBP + -4) = 0x13;
  FUN_008783f0(uVar3,1,0);
  *(undefined *)(unaff_EBP + -4) = 0x11;
  FUN_005507b0();
  FUN_008763f0();
  LOCK();
  piVar1 = (int *)(*(int *)(unaff_EBP + -0x14) + 0xc4);
  iVar2 = *piVar1 + -1;
  *piVar1 = iVar2;
  UNLOCK();
  if (iVar2 == 0) {
    FUN_00554b10();
  }
  FUN_01675310("CloseJobFailure",&DAT_018bc9b8);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 3828 ; VA 0x0057b500 ; FUN_0057b500 */

void FUN_0057b500(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  
  if (*(char *)(param_2 + 2) == '\0') {
    LOCK();
    param_1[1] = param_1[1] + 1;
    UNLOCK();
    *(undefined *)(param_2 + 2) = 1;
  }
  LOCK();
  *param_1 = *param_2;
  UNLOCK();
  if ((param_2[3] == 0) && (1 < (int)param_1[1])) {
    if (*(char *)(param_2 + 4) == '\0') {
      FUN_005881c0(param_2 + 4,param_1);
    }
    uVar2 = CreateEventA(0,1,0,param_2 + 4);
    iVar1 = param_2[3];
    if ((iVar1 != 0) && (iVar1 != -1)) {
      CloseHandle(iVar1);
    }
    param_2[3] = uVar2;
  }
  if (param_2[3] != 0) {
    SetEvent(param_2[3]);
  }
  return;
}



/* FUNCTION 3829 ; VA 0x0057b580 ; FUN_0057b580 */

void FUN_0057b580(undefined4 param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 ***pppuVar4;
  undefined auStack_23c [24];
  undefined auStack_224 [24];
  undefined auStack_20c [24];
  undefined auStack_1f4 [24];
  undefined auStack_1dc [24];
  undefined auStack_1c4 [24];
  undefined auStack_1ac [24];
  undefined auStack_194 [24];
  undefined auStack_17c [24];
  undefined auStack_164 [24];
  undefined auStack_14c [24];
  undefined auStack_134 [24];
  undefined4 **appuStack_11c [5];
  uint uStack_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined8 uStack_f4;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined8 uStack_dc;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined8 uStack_c4;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined8 uStack_ac;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined8 uStack_94;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined8 uStack_7c;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined8 uStack_64;
  undefined4 **appuStack_5c [4];
  int iStack_4c;
  uint uStack_48;
  undefined auStack_44 [16];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined auStack_2c [12];
  undefined auStack_20 [8];
  undefined auStack_18 [4];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179597a;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_016819e0(auStack_2c,param_2);
  uStack_8 = 0;
  cVar1 = FUN_016816d0();
  if (cVar1 == '\0') {
    cVar1 = FUN_01681870();
    if (cVar1 == '\0') {
      if (DAT_01d59104 != '\0') {
        FUN_01677520(DAT_01d59104,"LogPrefix: not a JSON object");
      }
    }
    else {
      FUN_0167eea0(auStack_18,&DAT_018bf334);
      uStack_34 = 0;
      uStack_30 = 0xf;
      auStack_44[0] = 0;
      FUN_005542c0("Unknown",7);
      uStack_8._0_1_ = 1;
      FUN_01681330(appuStack_5c,auStack_44);
      uStack_8._0_1_ = 3;
      FUN_005507b0();
      FUN_0167eea0(auStack_20,"Settings");
      FUN_005818c0(auStack_1ac,auStack_20,"PlaceId");
      uStack_8._0_1_ = 4;
      FUN_005818c0(auStack_194,auStack_20,"UniverseId");
      uStack_8._0_1_ = 5;
      FUN_00581930(auStack_17c,auStack_20,"BaseUrl");
      uStack_8._0_1_ = 6;
      FUN_00581930(auStack_164,auStack_20,"GameId");
      uStack_8._0_1_ = 7;
      FUN_00581930(auStack_14c,auStack_20,"MachineAddress");
      uStack_8._0_1_ = 8;
      FUN_005818c0(auStack_134,auStack_20,"DatacenterId");
      uStack_8._0_1_ = 10;
      uStack_34 = 0;
      uStack_30 = 0xf;
      auStack_44[0] = 0;
      uStack_14 = 1;
      FUN_0058a190(iStack_4c + 1);
      FUN_00554150(&DAT_018bf378,1);
      pppuVar4 = appuStack_5c;
      if (0xf < uStack_48) {
        pppuVar4 = (undefined4 ***)appuStack_5c[0];
      }
      FUN_00554150(pppuVar4,iStack_4c);
      puVar3 = (undefined4 *)FUN_00554150(&DAT_018bf378,1);
      uStack_14 = 3;
      uStack_104 = *puVar3;
      uStack_100 = puVar3[1];
      uStack_fc = puVar3[2];
      uStack_f8 = puVar3[3];
      uStack_f4 = *(undefined8 *)(puVar3 + 4);
      puVar3[4] = 0;
      puVar3[5] = 0xf;
      *(undefined *)puVar3 = 0;
      uStack_8._0_1_ = 0xb;
      FUN_00558c20(auStack_23c,&uStack_104,auStack_1ac);
      uStack_8._0_1_ = 0xc;
      puVar3 = (undefined4 *)FUN_00554150(&DAT_018bf378,1);
      uStack_14 = 7;
      uStack_ec = *puVar3;
      uStack_e8 = puVar3[1];
      uStack_e4 = puVar3[2];
      uStack_e0 = puVar3[3];
      uStack_dc = *(undefined8 *)(puVar3 + 4);
      puVar3[4] = 0;
      puVar3[5] = 0xf;
      *(undefined *)puVar3 = 0;
      uStack_8._0_1_ = 0xd;
      FUN_00558c20(auStack_224,&uStack_ec,auStack_194);
      uStack_8._0_1_ = 0xe;
      puVar3 = (undefined4 *)FUN_00554150(&DAT_018bf378,1);
      uStack_d4 = *puVar3;
      uStack_d0 = puVar3[1];
      uStack_cc = puVar3[2];
      uStack_c8 = puVar3[3];
      uStack_c4 = *(undefined8 *)(puVar3 + 4);
      puVar3[4] = 0;
      puVar3[5] = 0xf;
      *(undefined *)puVar3 = 0;
      uStack_14 = 0xf;
      uStack_8._0_1_ = 0xf;
      FUN_00558c20(auStack_20c,&uStack_d4,auStack_17c);
      uStack_8._0_1_ = 0x10;
      puVar3 = (undefined4 *)FUN_00554150(&DAT_018bf378,1);
      uStack_14 = 0x1f;
      uStack_bc = *puVar3;
      uStack_b8 = puVar3[1];
      uStack_b4 = puVar3[2];
      uStack_b0 = puVar3[3];
      uStack_ac = *(undefined8 *)(puVar3 + 4);
      puVar3[4] = 0;
      puVar3[5] = 0xf;
      *(undefined *)puVar3 = 0;
      uStack_8._0_1_ = 0x11;
      FUN_00558c20(auStack_1f4,&uStack_bc,auStack_164);
      uStack_8._0_1_ = 0x12;
      puVar3 = (undefined4 *)FUN_00554150(&DAT_018bf378,1);
      uStack_14 = 0x3f;
      uStack_a4 = *puVar3;
      uStack_a0 = puVar3[1];
      uStack_9c = puVar3[2];
      uStack_98 = puVar3[3];
      uStack_94 = *(undefined8 *)(puVar3 + 4);
      puVar3[4] = 0;
      puVar3[5] = 0xf;
      *(undefined *)puVar3 = 0;
      uStack_8._0_1_ = 0x13;
      FUN_00558c20(auStack_1dc,&uStack_a4,auStack_14c);
      uStack_8._0_1_ = 0x14;
      puVar3 = (undefined4 *)FUN_00554150(&DAT_018bf378,1);
      uStack_8c = *puVar3;
      uStack_88 = puVar3[1];
      uStack_84 = puVar3[2];
      uStack_80 = puVar3[3];
      uStack_7c = *(undefined8 *)(puVar3 + 4);
      puVar3[4] = 0;
      puVar3[5] = 0xf;
      *(undefined *)puVar3 = 0;
      uStack_14 = 0x7f;
      uStack_8._0_1_ = 0x15;
      FUN_00558c20(auStack_1c4,&uStack_8c,auStack_134);
      uStack_8._0_1_ = 0x16;
      puVar3 = (undefined4 *)FUN_00554150(&DAT_018bf378,1);
      uStack_14 = 0xff;
      uStack_74 = *puVar3;
      uStack_70 = puVar3[1];
      uStack_6c = puVar3[2];
      uStack_68 = puVar3[3];
      uStack_64 = *(undefined8 *)(puVar3 + 4);
      puVar3[4] = 0;
      puVar3[5] = 0xf;
      *(undefined *)puVar3 = 0;
      uStack_8._0_1_ = 0x17;
      FUN_00558c20(appuStack_11c,&uStack_74,param_1);
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      uStack_8 = CONCAT31(uStack_8._1_3_,0x26);
      FUN_005507b0();
      pppuVar4 = appuStack_11c;
      if (0xf < uStack_108) {
        pppuVar4 = (undefined4 ***)appuStack_11c[0];
      }
      FUN_01678080(pppuVar4);
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
    }
  }
  else if (DAT_01d59104 != '\0') {
    uVar2 = FUN_016814a0();
    FUN_01677520(DAT_01d59104,"LogPrefix: Parse Error: %s",uVar2);
  }
  FUN_0167ec40();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3830 ; VA 0x0057bbb0 ; FUN_0057bbb0 */

void FUN_0057bbb0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = 0;
  param_2[1] = 0;
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_2 = *param_1;
  param_2[1] = param_1[1];
  return;
}



/* FUNCTION 3831 ; VA 0x0057bbe0 ; FUN_0057bbe0 */

void FUN_0057bbe0(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if ((-(uint)(iVar1 != 0) & iVar1 + 0xcU) != 0) {
    FUN_0055e000();
    iVar1 = *param_1;
  }
  if ((-(uint)(iVar1 != 0) & iVar1 + 0xcU) != 0) {
    FUN_0055e310();
  }
  FUN_0093a3e0();
  return;
}



/* FUNCTION 3832 ; VA 0x0057bc30 ; FUN_0057bc30 */

void FUN_0057bc30(int *param_1,int param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  int iVar8;
  uint uVar9;
  undefined auStack_30 [24];
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795998;
  pvStack_10 = ExceptionList;
  iVar8 = *param_1;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00888530();
  if (iVar8 == iVar5) {
LAB_0057be6e:
    *(undefined4 *)(param_2 + 4) = 0;
    ExceptionList = pvStack_10;
    return;
  }
  iVar8 = *param_1;
  iVar5 = FUN_0088daf0();
  if (iVar8 == iVar5) {
    *(undefined4 *)(param_2 + 4) = 1;
    uVar6 = FUN_005a8870(param_3,0xffffffff);
    *(undefined4 *)(param_2 + 8) = uVar6;
    puVar7 = (undefined4 *)FUN_00563690(auStack_30);
    puVar1 = *(undefined4 **)(param_2 + 8);
    if (puVar1 != puVar7) {
      FUN_005507b0();
      uVar6 = puVar7[1];
      uVar2 = puVar7[2];
      uVar3 = puVar7[3];
      *puVar1 = *puVar7;
      puVar1[1] = uVar6;
      puVar1[2] = uVar2;
      puVar1[3] = uVar3;
      *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(puVar7 + 4);
      puVar7[4] = 0;
      puVar7[5] = 0xf;
      *(undefined *)puVar7 = 0;
    }
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  iVar8 = *param_1;
  if (*(char *)(iVar8 + 0x21) != '\0') {
    *(undefined4 *)(param_2 + 4) = 2;
    uVar6 = FUN_005a8870(param_3,0xffffffff);
    *(undefined4 *)(param_2 + 8) = uVar6;
    uVar6 = FUN_00563690(auStack_30);
    FUN_005511f0(uVar6);
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  iVar5 = FUN_0088cb40();
  if (iVar8 != iVar5) {
    iVar8 = *param_1;
    iVar5 = FUN_0088d190();
    if (iVar8 != iVar5) {
      iVar8 = *param_1;
      iVar5 = FUN_008882f0();
      if (iVar8 == iVar5) {
        uVar6 = FUN_0055d670();
        FUN_00557fc0(uVar6);
        uStack_8 = 0;
        *(undefined4 *)(param_2 + 4) = 4;
        iVar8 = FUN_005a87f0(param_3,0xffffffff);
        piVar4 = piStack_18;
        *(int *)(param_2 + 0xc) = iVar8;
        FUN_0055b820((piStack_18[1] - *piStack_18) / 0xd0,iVar8 + 4);
        iVar5 = piVar4[1] - *piVar4;
        uVar9 = 0;
        iVar8 = iVar5 >> 0x1f;
        if (iVar5 / 0xd0 + iVar8 != iVar8) {
          iVar8 = 0;
          do {
            uVar6 = FUN_005a8830(param_3,0xffffffff);
            *(undefined4 *)(*(int *)(*(int *)(param_2 + 0xc) + 4) + uVar9 * 4) = uVar6;
            FUN_0057bc30(*piStack_18 + iVar8,
                         *(undefined4 *)(*(int *)(*(int *)(param_2 + 0xc) + 4) + uVar9 * 4),param_3)
            ;
            uVar9 = uVar9 + 1;
            iVar8 = iVar8 + 0xd0;
          } while (uVar9 < (uint)((piStack_18[1] - *piStack_18) / 0xd0));
        }
        FUN_00550b30();
        ExceptionList = pvStack_10;
        return;
      }
      goto LAB_0057be6e;
    }
  }
  *(undefined4 *)(param_2 + 4) = 3;
  uVar6 = FUN_005a8870(param_3,0xffffffff);
  *(undefined4 *)(param_2 + 8) = uVar6;
  uVar6 = FUN_00563690(auStack_30);
  FUN_005511f0(uVar6);
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3833 ; VA 0x0057be90 ; FUN_0057be90 */

undefined4 * __fastcall FUN_0057be90(undefined4 param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017959c2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x17658);
  uStack_8 = 0;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    FUN_0170d1f0(puVar1,0,0x17658);
    FUN_005be850();
    *puVar1 = _anon_5DAC6851::ExceptionAwareSoap<class_RCCServiceSoapService>::vftable;
  }
  FUN_005b3080(puVar1,param_1);
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 3834 ; VA 0x0057bf10 ; FUN_0057bf10 */

undefined4 * FUN_0057bf10(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_0055e6f0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 3835 ; VA 0x0057bf80 ; FUN_0057bf80 */

undefined4 * FUN_0057bf80(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_0055ec60(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 3836 ; VA 0x0057bff0 ; FUN_0057bff0 */

int * __thiscall
FUN_0057bff0(int ****param_1,int *param_2,int *****param_3,int ****param_4,int *****param_5,
            int ***param_6)

{
  int *****pppppiVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined uVar5;
  undefined4 uVar6;
  int *piVar7;
  int iVar8;
  undefined4 *puVar9;
  int *piVar10;
  int *****pppppiVar11;
  int ***pppiVar12;
  double *pdVar13;
  int iVar14;
  int ****ppppiVar15;
  uint uVar16;
  int ***pppiVar17;
  int ****ppppiVar18;
  uint uVar19;
  undefined4 *puVar20;
  undefined auStack_110 [24];
  undefined auStack_f8 [16];
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined uStack_e0;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined uStack_c8;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined uStack_b0;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined uStack_98;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined2 uStack_80;
  undefined4 uStack_7c;
  undefined8 uStack_78;
  undefined4 uStack_70;
  undefined uStack_6c;
  undefined2 uStack_6b;
  double dStack_68;
  undefined auStack_60 [4];
  int ***pppiStack_5c;
  int ****appppiStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  undefined8 uStack_40;
  uint auStack_38 [2];
  undefined auStack_30 [4];
  int ***pppiStack_2c;
  int ***pppiStack_28;
  int ***pppiStack_24;
  int ***pppiStack_20;
  undefined8 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795b2d;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  pppiStack_20 = (int ***)param_1;
  FUN_00574e30(param_1 + 3);
  uVar6 = FUN_01679ce0();
  FUN_0171d758(uVar6);
  FUN_0054ef60(param_3 + 2);
  uStack_8 = 1;
  uStack_e8 = 0;
  uStack_e4 = 0xf;
  auStack_f8[0] = 0;
  FUN_005542c0("en-US",5);
  uStack_8._0_1_ = 2;
  uStack_d0 = 0;
  uStack_cc = 0xf;
  uStack_e0 = 0;
  FUN_005542c0("en-US",5);
  uStack_b8 = 0;
  uStack_b4 = 0xf;
  uStack_c8 = 0;
  uStack_a0 = 0;
  uStack_9c = 0xf;
  uStack_b0 = 0;
  uStack_88 = 0;
  uStack_84 = 0xf;
  uStack_98 = 0;
  uStack_80 = 0x101;
  uStack_7c = 0x3f800000;
  uStack_78._0_4_ = 0;
  uStack_78._4_4_ = 0;
  uStack_70 = 6;
  uStack_6c = 1;
  uStack_6b = 0;
  uStack_8._0_1_ = 3;
  FUN_005542c0("en-US",5);
  uStack_78 = CONCAT44(uStack_78._4_4_,(undefined4)uStack_78);
  if ((DAT_01d59330 != '\0') &&
     (uStack_78 = CONCAT44(uStack_78._4_4_,(undefined4)uStack_78), param_4 != (int ****)0x0)) {
    FUN_0054ef60(*(undefined4 *)((int)param_4 + 8));
    uStack_1c = 0.0;
    uStack_8._0_1_ = 5;
    cVar4 = FUN_0098f070(auStack_110,&uStack_1c,0);
    if (cVar4 != '\0') {
      pppiStack_28 = (int ***)0x0;
      pppiStack_24 = (int ***)&DAT_0000000f;
      auStack_38[0] = auStack_38[0] & 0xffffff00;
      FUN_005542c0("Settings",8);
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      uStack_14 = 1;
      piVar7 = (int *)FUN_00580040(&pppiStack_5c,auStack_38);
      iVar14 = *piVar7;
      if (iVar14 == 0) {
        iVar14 = 8;
LAB_0057c1c8:
        param_4 = (int ****)((uint)param_4 & 0xffffff);
        uStack_40 = CONCAT44(iVar14,(undefined4)uStack_40);
      }
      else {
        iVar3 = *(int *)(iVar14 + 0x20);
        iVar14 = iVar14 + 8;
        uStack_40 = CONCAT44(iVar14,(undefined4)uStack_40);
        iVar8 = FUN_008881d0();
        if (iVar3 != iVar8) goto LAB_0057c1c8;
        param_4 = (int ****)CONCAT13(1,param_4._0_3_);
      }
      uStack_8._0_1_ = 5;
      uStack_8._1_3_ = 0;
      FUN_005507b0();
      uStack_14 = 0;
      if (param_4._3_1_ != '\0') {
        uVar6 = FUN_0055d640();
        FUN_00557fc0(uVar6);
        uStack_8._0_1_ = 7;
        uStack_40 = 0;
        pppiStack_28 = (int ***)0x0;
        pppiStack_24 = (int ***)&DAT_0000000f;
        auStack_38[0] = auStack_38[0] & 0xffffff00;
        FUN_005542c0("PlaceId",7);
        uStack_8._0_1_ = 8;
        uStack_78 = FUN_00563880(auStack_60,auStack_38,&uStack_40);
        uStack_8._0_1_ = 7;
        FUN_005507b0();
        if (uStack_78 != 0) {
          FUN_01677200(uStack_78);
        }
        FUN_00550b30();
      }
    }
    piVar7 = uStack_1c._4_4_;
    if (uStack_1c._4_4_ != (int *)0x0) {
      LOCK();
      iVar14 = uStack_1c._4_4_[1] + -1;
      uStack_1c._4_4_[1] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)*uStack_1c._4_4_)();
        LOCK();
        piVar10 = piVar7 + 2;
        iVar14 = *piVar10 + -1;
        *piVar10 = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    uStack_8._0_1_ = 3;
    FUN_005507b0();
    param_1 = (int ****)pppiStack_20;
  }
  uVar19 = 0;
  uVar5 = (undefined)uStack_80;
  if (*(char *)(param_1 + 0x24) != '\0') {
    uVar5 = 0;
  }
  uStack_80 = CONCAT11(uStack_80._1_1_,uVar5);
  if (DAT_01d63584 != '\0') {
    uStack_6b = CONCAT11(1,*(undefined *)(param_1 + 0x2b));
  }
  puVar9 = (undefined4 *)FUN_01674e20(0x10);
  uStack_8._0_1_ = 9;
  if (puVar9 == (undefined4 *)0x0) {
    puVar20 = (undefined4 *)0x0;
    param_4 = (int ****)puVar9;
  }
  else {
    pppiStack_28 = (int ***)0x0;
    pppiStack_24 = (int ***)&DAT_0000000f;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    param_4 = (int ****)puVar9;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    uVar19 = 2;
    uStack_14 = 2;
    FUN_00994fb0(0,auStack_38,0);
    *puVar9 = RBX::NullVerb::vftable;
    puVar20 = puVar9;
  }
  uStack_8 = 0xb;
  piVar10 = (int *)FUN_008f1f70(&uStack_1c,param_5,puVar20,0,2,auStack_f8);
  piVar7 = (int *)param_6;
  iVar14 = *piVar10;
  iVar3 = piVar10[1];
  *piVar10 = 0;
  piVar10[1] = 0;
  *param_6 = (int **)iVar14;
  param_4 = (int ****)((int *)param_6)[1];
  ((int *)param_6)[1] = iVar3;
  if (param_4 != (int ****)0x0) {
    LOCK();
    iVar14 = ((int *)param_4)[1] + -1;
    ((int *)param_4)[1] = iVar14;
    UNLOCK();
    if (iVar14 == 0) {
      (*(code *)**param_4)();
      LOCK();
      iVar14 = ((int *)param_4)[2] + -1;
      ((int *)param_4)[2] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)((int)*param_4 + 4))();
      }
    }
  }
  param_4 = (int ****)uStack_1c._4_4_;
  if (uStack_1c._4_4_ != (int *)0x0) {
    LOCK();
    iVar14 = uStack_1c._4_4_[1] + -1;
    uStack_1c._4_4_[1] = iVar14;
    UNLOCK();
    if (iVar14 == 0) {
      (**(code **)*uStack_1c._4_4_)();
      LOCK();
      iVar14 = ((int *)param_4)[2] + -1;
      ((int *)param_4)[2] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)((int)*param_4 + 4))();
      }
    }
  }
  uStack_8 = 3;
  if (uVar19 != 0) {
    uVar19 = 0;
    uStack_14 = 0;
    if (&DAT_0000000f < pppiStack_24) {
      ppppiVar18 = (int ****)((int)pppiStack_24 + 1);
      uVar16 = auStack_38[0];
      if ((int ****)0xfff < ppppiVar18) {
        uVar16 = *(uint *)(auStack_38[0] - 4);
        ppppiVar18 = (int ****)(pppiStack_24 + 9);
        if (0x1f < (auStack_38[0] - uVar16) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar16,ppppiVar18);
    }
  }
  ppppiVar18 = (int ****)FUN_01674e20(0xfc);
  pppiVar12 = pppiStack_20;
  uStack_8._0_1_ = 0xc;
  uStack_40._4_4_ = ppppiVar18;
  if (ppppiVar18 == (int ****)0x0) {
    param_4 = (int ****)0x0;
  }
  else {
    param_4 = (int ****)DAT_01e90d54;
    if (DAT_01d64858 == '\0') {
      param_4 = (int ****)pppiStack_20[0x16];
    }
    ppppiVar18 = (int ****)(pppiStack_20 + 0xf);
    if ((int ***)0xf < pppiStack_20[0x14]) {
      ppppiVar18 = (int ****)*ppppiVar18;
    }
    pppiStack_28 = (int ***)0x0;
    pppiStack_24 = (int ***)&DAT_0000000f;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    param_5 = (int *****)((int)ppppiVar18 + 1);
    ppppiVar15 = ppppiVar18;
    do {
      cVar4 = *(char *)ppppiVar15;
      ppppiVar15 = (int ****)((int)ppppiVar15 + 1);
    } while (cVar4 != '\0');
    FUN_005542c0(ppppiVar18,(int)ppppiVar15 - (int)param_5);
    uVar19 = uVar19 | 4;
    uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
    uStack_14 = uVar19;
    param_4 = (int ****)FUN_00990660(auStack_38,param_4,0xffffffff);
  }
  uStack_8 = 3;
  if ((uVar19 & 4) != 0) {
    uVar19 = uVar19 & 0xfffffffb;
    uStack_14 = uVar19;
    if (&DAT_0000000f < pppiStack_24) {
      ppppiVar18 = (int ****)((int)pppiStack_24 + 1);
      uVar16 = auStack_38[0];
      if ((int ****)0xfff < ppppiVar18) {
        uVar16 = *(uint *)(auStack_38[0] - 4);
        ppppiVar18 = (int ****)(pppiStack_24 + 9);
        if (0x1f < (auStack_38[0] - uVar16) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar16,ppppiVar18);
    }
    pppiStack_28 = (int ***)0x0;
    pppiStack_24 = (int ***)&DAT_0000000f;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
  }
  FUN_00877860(0,param_4);
  if (DAT_01d593b8 == '\0') {
    param_4 = (int ****)(*piVar7 + 0xa8);
    if (piVar7[1] != 0) {
      LOCK();
      piVar10 = (int *)(piVar7[1] + 4);
      *piVar10 = *piVar10 + 1;
      UNLOCK();
    }
    param_5 = (int *****)FUN_0055d300(auStack_30,FUN_0057bbe0,pppiVar12,*piVar7,piVar7[1]);
    uStack_8._0_1_ = 0x15;
    uVar6 = FUN_01675290(DAT_02110da8);
    uStack_1c = (double)CONCAT44(uVar6,(uint *)uStack_1c);
    uStack_8._0_1_ = 0x16;
    pppiStack_5c = (int ***)FUN_01674e20(0x28);
    if ((int ****)pppiStack_5c == (int ****)0x0) {
      ppppiVar18 = (int ****)0x0;
    }
    else {
      *pppiStack_5c = (int **)0x0;
      ((int ****)pppiStack_5c)[1] = (int ***)0x1;
      ((int ****)pppiStack_5c)[2] = (int ***)FUN_0057df70;
      ((int ****)pppiStack_5c)[3] = (int ***)FUN_0057e0b0;
      ((int ****)pppiStack_5c)[4] = (int ***)0x0;
      ((int ****)pppiStack_5c)[5] = (int ***)param_4;
      ((int ****)pppiStack_5c)[6] = (int ***)*param_5;
      ((int ****)pppiStack_5c)[7] = (int ***)param_5[1];
      ((int ****)pppiStack_5c)[8] = (int ***)0x0;
      ((int ****)pppiStack_5c)[9] = (int ***)0x0;
      if (param_5[3] != (int ****)0x0) {
        LOCK();
        ppppiVar18 = param_5[3] + 1;
        *ppppiVar18 = (int ***)((int)*ppppiVar18 + 1);
        UNLOCK();
      }
      ((int ****)pppiStack_5c)[8] = (int ***)param_5[2];
      ((int ****)pppiStack_5c)[9] = (int ***)param_5[3];
      ppppiVar18 = (int ****)pppiStack_5c;
    }
    FUN_016797d0(ppppiVar18);
    if (ppppiVar18 != (int ****)0x0) {
      LOCK();
      ppppiVar18[1] = (int ***)((int)ppppiVar18[1] + 1);
      UNLOCK();
    }
    uStack_14 = uVar19 | 0x20;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x17);
    param_4 = ppppiVar18;
    FUN_01675290(uVar6);
    uStack_14 = uVar19;
    if (ppppiVar18 != (int ****)0x0) {
      ppppiVar15 = ppppiVar18 + 1;
      LOCK();
      pppiVar12 = *ppppiVar15;
      *ppppiVar15 = (int ***)((int)*ppppiVar15 + -1);
      UNLOCK();
      if (pppiVar12 == (int ***)0x1) {
        FUN_01674ea0(ppppiVar18);
      }
    }
    pppiVar12 = pppiStack_24;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if ((int ****)pppiStack_24 != (int ****)0x0) {
      LOCK();
      pppiVar17 = (int ***)((int)pppiStack_24[1] + -1);
      pppiStack_24[1] = (int **)pppiVar17;
      UNLOCK();
      if (pppiVar17 == (int ***)0x0) {
        (*(code *)**pppiStack_24)();
        LOCK();
        ppppiVar18 = (int ****)(pppiVar12 + 2);
        pppiVar17 = (int ***)((int)*ppppiVar18 + -1);
        *ppppiVar18 = pppiVar17;
        UNLOCK();
        if (pppiVar17 == (int ***)0x0) {
          (*(code *)(*pppiVar12)[1])();
        }
      }
    }
  }
  else {
    param_5 = (int *****)*piVar7;
    uStack_40._4_4_ = (int ****)param_5 + 0x2a;
    param_4 = (int ****)piVar7[1];
    if (param_4 != (int ****)0x0) {
      LOCK();
      param_4[2] = (int ***)((int)param_4[2] + 1);
      UNLOCK();
      param_5 = (int *****)*piVar7;
      param_4 = (int ****)piVar7[1];
    }
    pppiStack_2c = pppiVar12;
    dStack_68 = 0.0;
    uStack_8._0_1_ = 0x11;
    pppiStack_28 = (int ***)param_5;
    pppiStack_24 = (int ***)param_4;
    ppppiVar18 = (int ****)FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 0x12;
    pppiStack_5c = (int ***)ppppiVar18;
    pppppiVar11 = (int *****)FUN_01674e20(0x24);
    uStack_1c = (double)CONCAT44(pppppiVar11,(uint *)uStack_1c);
    if (pppppiVar11 == (int *****)0x0) {
      pppppiVar11 = (int *****)0x0;
    }
    else {
      *pppppiVar11 = (int ****)0x0;
      pppppiVar11[1] = (int ****)0x1;
      pppppiVar11[2] = (int ****)FUN_0057de90;
      pppppiVar11[3] = (int ****)FUN_0057e090;
      pppppiVar11[4] = (int ****)0x0;
      pppppiVar11[5] = uStack_40._4_4_;
      pppppiVar11[6] = (int ****)pppiStack_20;
      pppppiVar11[7] = (int ****)0x0;
      pppppiVar11[8] = (int ****)0x0;
      if (param_4 != (int ****)0x0) {
        LOCK();
        param_4[2] = (int ***)((int)param_4[2] + 1);
        UNLOCK();
      }
      pppppiVar11[7] = (int ****)param_5;
      pppppiVar11[8] = param_4;
    }
    FUN_016797d0(pppppiVar11);
    if (pppppiVar11 != (int *****)0x0) {
      LOCK();
      pppppiVar11[1] = (int ****)((int)pppppiVar11[1] + 1);
      UNLOCK();
    }
    uStack_14 = uVar19 | 0x10;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
    param_5 = pppppiVar11;
    FUN_01675290(ppppiVar18);
    uStack_14 = uVar19;
    if (pppppiVar11 != (int *****)0x0) {
      pppppiVar1 = pppppiVar11 + 1;
      LOCK();
      ppppiVar18 = *pppppiVar1;
      *pppppiVar1 = (int ****)((int)*pppppiVar1 + -1);
      UNLOCK();
      if (ppppiVar18 == (int ****)0x1) {
        FUN_01674ea0(pppppiVar11);
      }
    }
    if (param_4 != (int ****)0x0) {
      LOCK();
      pppiVar12 = (int ***)((int)param_4[2] + -1);
      param_4[2] = pppiVar12;
      UNLOCK();
      if (pppiVar12 == (int ***)0x0) {
        (*(code *)(*param_4)[1])();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
  }
  piVar7 = (int *)param_6;
  if ((int *****)((int)*param_6 + 0x288) != appppiStack_58) {
    pppppiVar11 = appppiStack_58;
    if (0xf < uStack_44) {
      pppppiVar11 = (int *****)appppiStack_58[0];
    }
    FUN_005542c0(pppppiVar11,uStack_48);
  }
  param_6 = (int ***)FUN_01674e20(0x70);
  uStack_8._0_1_ = 0x18;
  if (param_6 == (int ***)0x0) {
    pppiVar12 = (int ***)0x0;
  }
  else {
    param_5 = appppiStack_58;
    if (0xf < uStack_44) {
      param_5 = (int *****)appppiStack_58[0];
    }
    param_6[4] = (int **)0x0;
    param_6[5] = (int **)0xf;
    *(undefined *)param_6 = 0;
    param_4 = (int ****)((int)param_5 + 1);
    pppppiVar11 = param_5;
    do {
      cVar4 = *(char *)pppppiVar11;
      pppppiVar11 = (int *****)((int)pppppiVar11 + 1);
    } while (cVar4 != '\0');
    FUN_005542c0(param_5,(int)pppppiVar11 - (int)param_4);
    param_6[6] = (int **)0x0;
    param_6[7] = (int **)0x0;
    param_6[8] = (int **)0x0;
    param_6[9] = (int **)0x0;
    uStack_8._0_1_ = 0x1b;
    param_6[10] = (int **)0x0;
    param_6[0xb] = (int **)0x0;
    FUN_0151f360(0);
    param_6[0x11] = (int **)0x0;
    param_6[0x12] = (int **)0x0;
    param_6[0x13] = (int **)0x0;
    param_6[0x14] = (int **)0x0;
    param_6[0x19] = (int **)0x0;
    param_6[0x1a] = (int **)0xf;
    *(undefined *)(param_6 + 0x15) = 0;
    pppiVar12 = param_6;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  *param_2 = 0;
  param_2[1] = 0;
  FUN_0055b9a0(pppiVar12,param_2);
  iVar14 = piVar7[1];
  uStack_14 = uVar19 | 8;
  iVar3 = *param_2;
  if (iVar14 != 0) {
    LOCK();
    *(int *)(iVar14 + 4) = *(int *)(iVar14 + 4) + 1;
    UNLOCK();
    iVar14 = piVar7[1];
  }
  *(int *)(iVar3 + 0x18) = *piVar7;
  piVar10 = *(int **)(iVar3 + 0x1c);
  *(int *)(iVar3 + 0x1c) = iVar14;
  if (piVar10 != (int *)0x0) {
    LOCK();
    iVar14 = piVar10[1] + -1;
    piVar10[1] = iVar14;
    UNLOCK();
    if (iVar14 == 0) {
      (**(code **)*piVar10)();
      LOCK();
      piVar2 = piVar10 + 2;
      iVar14 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar14 == 1) {
        (**(code **)(*piVar10 + 4))();
      }
    }
  }
  *(int *****)(*param_2 + 0x30) = param_3[10];
  *(undefined8 *)(*param_2 + 0x38) = *(undefined8 *)(param_3 + 0xc);
  dStack_68 = *(double *)(param_3 + 8);
  iVar14 = *param_2;
  pdVar13 = (double *)FUN_01682800(&uStack_1c);
  pppiVar12 = pppiStack_20;
  uStack_1c = *pdVar13 + dStack_68;
  *(double *)(iVar14 + 0x28) = uStack_1c;
  if (((DAT_01d64ac8 != '\0') && (*(char *)(pppiStack_20 + 0x24) != '\0')) &&
     ((-(uint)(*piVar7 != 0) & *piVar7 + 0xcU) != 0)) {
    iVar14 = FUN_00562f00();
    if (iVar14 != 0) {
      FUN_008e9480(*piVar7,1);
      uStack_8._0_1_ = 0x1c;
      FUN_008bab90(2);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      FUN_008eb110();
    }
  }
  uStack_1c = (double)(CONCAT44((int)((ulonglong)uStack_1c >> 0x20),pppiVar12 + 0x2f) &
                      0xffffff00ffffffff);
  FUN_00587410();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x1d);
  if ((int ***)pppiVar12[0x2e] != (int ***)0x0) {
    FUN_01675310("Attempting to run multiple DMs in Parallel",&DAT_018bc9b8);
  }
  FUN_005875d0(&param_6,appppiStack_58);
  pppiVar12 = (int ***)pppiVar12[0x2d];
  if (param_6 != pppiVar12) {
    pppiVar17 = param_6 + 4;
    if ((int **)0xf < param_6[9]) {
      pppiVar17 = (int ***)*pppiVar17;
    }
    pppppiVar11 = appppiStack_58;
    if (0xf < uStack_44) {
      pppppiVar11 = (int *****)appppiStack_58[0];
    }
    iVar14 = FUN_0055c2d0(pppppiVar11,uStack_48,pppiVar17,param_6[8]);
    if (-1 < iVar14) {
      uVar6 = FUN_005543f0();
      FUN_016756b0(&pppiStack_2c,"JobItem %s already exists",uVar6);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(&pppiStack_2c,&DAT_01c17198);
    }
  }
  FUN_005875d0(&param_6,appppiStack_58);
  pppiVar17 = param_6;
  if (param_6 != pppiVar12) {
    pppiVar12 = param_6 + 4;
    if ((int **)0xf < param_6[9]) {
      pppiVar12 = (int ***)*pppiVar12;
    }
    pppppiVar11 = appppiStack_58;
    if (0xf < uStack_44) {
      pppppiVar11 = (int *****)appppiStack_58[0];
    }
    iVar14 = FUN_0055c2d0(pppppiVar11,uStack_48,pppiVar12,param_6[8]);
    if (-1 < iVar14) goto LAB_0057ca4e;
  }
  param_3 = appppiStack_58;
  iVar14 = FUN_00559280(&DAT_018bdeda,&param_3,(int)&param_6 + 3);
  FUN_0055aa30(&param_6,pppiVar17,iVar14 + 0x10,iVar14);
LAB_0057ca4e:
  FUN_0056ecd0(param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x1e);
  if (uStack_1c._4_1_ != '\0') {
    LOCK();
    uVar19 = *(uint *)uStack_1c;
    *(uint *)uStack_1c = *(uint *)uStack_1c + 0x80000000;
    UNLOCK();
    if (((uVar19 & 0x40000000) == 0) && (-0x80000000 < (int)uVar19)) {
      LOCK();
      uVar19 = *(uint *)uStack_1c;
      *(uint *)uStack_1c = *(uint *)uStack_1c | 0x40000000;
      UNLOCK();
      if ((uVar19 >> 0x1e & 1) == 0) {
        uVar6 = FUN_00554e40();
        SetEvent(uVar6);
      }
    }
  }
  FUN_0056d9d0();
  if (0xf < uStack_44) {
    uVar19 = uStack_44 + 1;
    pppppiVar11 = (int *****)appppiStack_58[0];
    if (0xfff < uVar19) {
      pppppiVar11 = (int *****)appppiStack_58[0][-1];
      uVar19 = uStack_44 + 0x24;
      if ((char *)0x1f < (char *)((int)appppiStack_58[0] + (-4 - (int)pppppiVar11))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppiVar11,uVar19);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 3837 ; VA 0x0057cb20 ; FUN_0057cb20 */

undefined4 * FUN_0057cb20(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795b59;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd4;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  uStack_18 = 1;
  uStack_8 = 1;
  puVar5 = (undefined4 *)FUN_0057cc40(auStack_20);
  uVar1 = *puVar5;
  uVar2 = puVar5[1];
  puVar5[1] = 0;
  *puVar5 = 0;
  *param_1 = uVar1;
  piVar3 = (int *)param_1[1];
  param_1[1] = uVar2;
  uStack_8._0_1_ = 2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar3 + 4))();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 8))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piStack_1c + 4))();
      LOCK();
      piVar3 = piStack_1c + 2;
      iVar4 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_1c + 8))();
        ExceptionList = pvStack_10;
        return param_1;
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3838 ; VA 0x0057cbf6 ; Catch@0057cbf6 */

undefined * Catch_0057cbf6(void)

{
  FUN_0056eee0(&DAT_01e90cbc);
  return &DAT_0057cc1c;
}



/* FUNCTION 3839 ; VA 0x0057cc09 ; Catch_All@0057cc09 */

undefined * Catch_All_0057cc09(void)

{
  FUN_0056eee0(&DAT_01e90cc4);
  return &DAT_0057cc1c;
}



/* FUNCTION 3840 ; VA 0x0057cc40 ; FUN_0057cc40 */

void FUN_0057cc40(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795b70;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 3841 ; VA 0x0057cc71 ; Catch@0057cc71 */

undefined * Catch_0057cc71(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)**(undefined4 **)(unaff_EBP + -0x14))();
  uVar1 = FUN_00557c70(uVar1);
  FUN_0054ff00(uVar1);
  FUN_00550ad0();
  return &LAB_0057cc98;
}



/* FUNCTION 3842 ; VA 0x0057ccac ; Catch@0057ccac */

undefined * Catch_0057ccac(void)

{
  int unaff_EBP;
  
  FUN_0055f680(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + -0x18));
  return &LAB_0057ccc0;
}



/* FUNCTION 3843 ; VA 0x0057ccd4 ; Catch@0057ccd4 */

undefined * Catch_0057ccd4(void)

{
  int unaff_EBP;
  
  FUN_0055fa80(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + -0x1c));
  return &LAB_0057cce8;
}



/* FUNCTION 3844 ; VA 0x0057ccfc ; Catch@0057ccfc */

undefined * Catch_0057ccfc(void)

{
  int unaff_EBP;
  
  FUN_0055fc70(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + -0x20));
  return &LAB_0057cd10;
}



/* FUNCTION 3845 ; VA 0x0057cd24 ; Catch@0057cd24 */

undefined * Catch_0057cd24(void)

{
  int unaff_EBP;
  
  FUN_00560060(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + -0x24));
  return &LAB_0057cd38;
}



/* FUNCTION 3846 ; VA 0x0057cd4c ; Catch@0057cd4c */

undefined * Catch_0057cd4c(void)

{
  int unaff_EBP;
  
  FUN_0055fe70(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + -0x28));
  return &LAB_0057cd60;
}



/* FUNCTION 3847 ; VA 0x0057cd74 ; Catch@0057cd74 */

undefined * Catch_0057cd74(void)

{
  int unaff_EBP;
  
  FUN_00560440(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + -0x2c));
  return &LAB_0057cd88;
}



/* FUNCTION 3848 ; VA 0x0057cd9c ; Catch@0057cd9c */

undefined * Catch_0057cd9c(void)

{
  int unaff_EBP;
  
  FUN_00560250(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + -0x30));
  return &LAB_0057cdb0;
}



/* FUNCTION 3849 ; VA 0x0057cdc4 ; Catch@0057cdc4 */

undefined * Catch_0057cdc4(void)

{
  int unaff_EBP;
  
  FUN_00560820(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + -0x34));
  return &LAB_0057cdd8;
}



/* FUNCTION 3850 ; VA 0x0057cdec ; Catch@0057cdec */

undefined * Catch_0057cdec(void)

{
  int unaff_EBP;
  
  FUN_0055f870(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + -0x38));
  return &LAB_0057ce00;
}



/* FUNCTION 3851 ; VA 0x0057ce14 ; Catch@0057ce14 */

undefined * Catch_0057ce14(void)

{
  int unaff_EBP;
  
  FUN_00560630(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + -0x3c));
  return &LAB_0057ce28;
}



/* FUNCTION 3852 ; VA 0x0057ce3c ; Catch@0057ce3c */

undefined * Catch_0057ce3c(void)

{
  int unaff_EBP;
  
  FUN_0055eec0(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + -0x40));
  return &LAB_0057ce50;
}



/* FUNCTION 3853 ; VA 0x0057ce64 ; Catch@0057ce64 */

undefined * Catch_0057ce64(void)

{
  int unaff_EBP;
  
  FUN_0055f0b0(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + -0x44));
  return &LAB_0057ce78;
}



/* FUNCTION 3854 ; VA 0x0057ce8c ; Catch@0057ce8c */

undefined * Catch_0057ce8c(void)

{
  int unaff_EBP;
  
  FUN_0055f490(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + -0x48));
  return &LAB_0057cea0;
}



/* FUNCTION 3855 ; VA 0x0057ceb4 ; Catch@0057ceb4 */

undefined * Catch_0057ceb4(void)

{
  int unaff_EBP;
  
  FUN_0055f2a0(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + -0x4c));
  return &LAB_0057cec8;
}



/* FUNCTION 3856 ; VA 0x0057cedc ; Catch@0057cedc */

undefined * Catch_0057cedc(void)

{
  int unaff_EBP;
  
  FUN_0057d0d0(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + -0x50));
  return &LAB_0057cef0;
}



/* FUNCTION 3857 ; VA 0x0057cf04 ; Catch@0057cf04 */

undefined * Catch_0057cf04(void)

{
  int unaff_EBP;
  
  FUN_0057cf40(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + -0x54));
  return &LAB_0057cf18;
}



/* FUNCTION 3858 ; VA 0x0057cf2c ; Catch_All@0057cf2c */

undefined * Catch_All_0057cf2c(void)

{
  int unaff_EBP;
  
  FUN_0057d030(*(undefined4 *)(unaff_EBP + 8));
  return &LAB_0057cc98;
}



/* FUNCTION 3859 ; VA 0x0057cf40 ; FUN_0057cf40 */

undefined4 FUN_0057cf40(undefined4 param_1,int param_2)

{
  undefined **ppuStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined **ppuStack_24;
  undefined8 uStack_20;
  undefined **ppuStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795ba0;
  pvStack_10 = ExceptionList;
  ppuStack_38 = boost::exception::vftable;
  piStack_34 = *(int **)(param_2 + 4);
  ExceptionList = &pvStack_10;
  if (piStack_34 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*piStack_34 + 0xc))();
  }
  uStack_30 = *(undefined4 *)(param_2 + 8);
  uStack_2c = *(undefined4 *)(param_2 + 0xc);
  uStack_28 = *(undefined4 *)(param_2 + 0x10);
  uStack_20 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ppuStack_38 = boost::unknown_exception::vftable;
  ppuStack_24 = boost::unknown_exception::vftable;
  uStack_14 = FUN_0170d850(param_2);
  ppuStack_18 = boost::error_info<struct_boost::tag_original_exception_type,class_type_info_const*>
                ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00564620(&ppuStack_38,&ppuStack_18);
  uStack_8 = 3;
  FUN_0055ded0(param_1,&ppuStack_38);
  ppuStack_38 = boost::unknown_exception::vftable;
  ppuStack_24 = std::exception::vftable;
  FUN_0170c289(&uStack_20);
  ppuStack_38 = boost::exception::vftable;
  uStack_8 = 4;
  if (piStack_34 != (int *)0x0) {
    (**(code **)(*piStack_34 + 0x10))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3860 ; VA 0x0057d030 ; FUN_0057d030 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0057d030(undefined4 param_1)

{
  undefined **ppuStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined **ppuStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bb8;
  pvStack_10 = ExceptionList;
  piStack_2c = (int *)PTR_018bd540;
  uStack_28 = _UNK_018bd544;
  uStack_24 = _UNK_018bd548;
  uStack_20 = _UNK_018bd54c;
  ppuStack_30 = boost::unknown_exception::vftable;
  ppuStack_1c = boost::unknown_exception::vftable;
  uStack_18 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0055ded0(param_1,&ppuStack_30);
  ppuStack_30 = boost::unknown_exception::vftable;
  ppuStack_1c = std::exception::vftable;
  FUN_0170c289(&uStack_18);
  ppuStack_30 = boost::exception::vftable;
  uStack_8 = 1;
  if (piStack_2c != (int *)0x0) {
    (**(code **)(*piStack_2c + 0x10))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3861 ; VA 0x0057d0d0 ; FUN_0057d0d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0057d0d0(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined **ppuStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined **ppuStack_24;
  undefined8 uStack_20;
  undefined **ppuStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795ba0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0170d75d(param_2,0,&std::exception::RTTI_Type_Descriptor,
                       &boost::exception::RTTI_Type_Descriptor,0);
  if (iVar1 != 0) {
    FUN_0057cf40(param_1,iVar1);
    ExceptionList = pvStack_10;
    return param_1;
  }
  piStack_34 = (int *)PTR_018bd540;
  uStack_30 = _UNK_018bd544;
  uStack_2c = _UNK_018bd548;
  uStack_28 = _UNK_018bd54c;
  uStack_20 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ppuStack_38 = boost::unknown_exception::vftable;
  ppuStack_24 = boost::unknown_exception::vftable;
  uStack_14 = FUN_0170d850(param_2);
  ppuStack_18 = boost::error_info<struct_boost::tag_original_exception_type,class_type_info_const*>
                ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00564620(&ppuStack_38,&ppuStack_18);
  uStack_8 = 3;
  FUN_0055ded0(param_1,&ppuStack_38);
  ppuStack_38 = boost::unknown_exception::vftable;
  ppuStack_24 = std::exception::vftable;
  FUN_0170c289(&uStack_20);
  ppuStack_38 = boost::exception::vftable;
  uStack_8 = 4;
  if (piStack_34 != (int *)0x0) {
    (**(code **)(*piStack_34 + 0x10))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3862 ; VA 0x0057d1d0 ; FUN_0057d1d0 */

int FUN_0057d1d0(short *param_1)

{
  uint uVar1;
  ushort uVar2;
  uint uVar3;
  
  uVar1 = (int)(0xe - (uint)(ushort)param_1[1]) / 0xc;
  uVar2 = (*param_1 - (short)uVar1) + 0x12c0;
  uVar3 = (uint)uVar2;
  return ((uVar2 >> 2) - 0x7d2d) +
         ((((uVar1 & 0xffff) * 0xc + -3 + (uint)(ushort)param_1[1] & 0xffff) * 0x99 + 2) / 5 -
         uVar3 / 100) + (uint)(ushort)param_1[2] + uVar3 / 400 + uVar3 * 0x16d;
}



/* FUNCTION 3863 ; VA 0x0057d270 ; FUN_0057d270 */

void FUN_0057d270(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 4;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 3864 ; VA 0x0057d2b0 ; FUN_0057d2b0 */

void FUN_0057d2b0(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0x20;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 3865 ; VA 0x0057d2f0 ; FUN_0057d2f0 */

void FUN_0057d2f0(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0x18;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 3866 ; VA 0x0057d330 ; FUN_0057d330 */

void FUN_0057d330(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 8;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 3867 ; VA 0x0057d370 ; FUN_0057d370 */

void FUN_0057d370(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0xd0;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 3868 ; VA 0x0057d3b0 ; FUN_0057d3b0 */

void __fastcall FUN_0057d3b0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(param_1 + 0x14);
  if (iVar2 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      puVar7 = *(undefined4 **)(iVar2 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar2 + *(int *)(param_1 + 4) * 4);
      ExceptionList = &pvStack_10;
      do {
        *puVar1 = *puVar7;
        uStack_8 = 0;
        if (puVar7[9] != 0) {
          (**(code **)(puVar7[9] + 8))(puVar7 + 10);
        }
        uVar6 = puVar7[7];
        uStack_8 = 0xffffffff;
        if (0xf < uVar6) {
          iVar2 = puVar7[2];
          uVar5 = uVar6 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar6 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0057d4c6;
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        puVar7[6] = 0;
        puVar7[7] = 0xf;
        *(undefined *)(puVar7 + 2) = 0;
        FUN_01674ea0(puVar7,0xf0);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar3 = *(int *)(param_1 + 0x14);
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_0057d4c6:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3869 ; VA 0x0057d4d0 ; FUN_0057d4d0 */

int __thiscall FUN_0057d4d0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar6 = 0;
  puVar5 = (undefined4 *)*param_2;
  ExceptionList = &pvStack_10;
  do {
    *param_2 = *puVar5;
    uStack_8 = 0;
    if (puVar5[9] != 0) {
      (**(code **)(puVar5[9] + 8))(puVar5 + 10);
    }
    uVar1 = puVar5[7];
    uStack_8 = 0xffffffff;
    if (0xf < uVar1) {
      iVar2 = puVar5[2];
      uVar4 = uVar1 + 1;
      iVar3 = iVar2;
      if (0xfff < uVar4) {
        iVar3 = *(int *)(iVar2 + -4);
        uVar4 = uVar1 + 0x24;
        if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar4);
    }
    puVar5[6] = 0;
    puVar5[7] = 0xf;
    *(undefined *)(puVar5 + 2) = 0;
    FUN_01674ea0(puVar5,0xf0);
    iVar6 = iVar6 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar5 = (undefined4 *)*param_2;
  } while (puVar5 != param_3);
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 3870 ; VA 0x0057d5a0 ; FUN_0057d5a0 */

int __thiscall FUN_0057d5a0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_01674ea0(puVar1,0x18);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar1 = (undefined4 *)*param_2;
    iVar2 = iVar2 + 1;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 3871 ; VA 0x0057d5e0 ; FUN_0057d5e0 */

int FUN_0057d5e0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    param_1 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      param_1 = (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0057d610. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar3 = (**(code **)(*piVar2 + 4))();
        return iVar3;
      }
    }
  }
  return param_1;
}



/* FUNCTION 3872 ; VA 0x0057d620 ; FUN_0057d620 */

void FUN_0057d620(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Diag soap endpoint is disabled");
}



/* FUNCTION 3873 ; VA 0x0057d650 ; FUN_0057d650 */

/* WARNING: Type propagation algorithm not settling */

int * __thiscall FUN_0057d650(int param_1,int param_2)

{
  undefined8 uVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined8 uVar9;
  undefined4 *puVar10;
  int *piVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  undefined **appuStack_c8 [15];
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_7c;
  undefined **appuStack_78 [18];
  int iStack_30;
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795c27;
  pvStack_10 = ExceptionList;
  if (param_2 != 0) {
    appuStack_c8[0] = &PTR_018be314;
    uStack_8 = 0;
    uStack_2c = 1;
    appuStack_78[0] = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
    uStack_7c = 0x48;
    ExceptionList = &pvStack_10;
    iStack_30 = param_1;
    FUN_00554f20(appuStack_c8 + 1,0);
    uStack_8 = 2;
    *(undefined ***)(appuStack_c8[0][1] + (int)appuStack_c8) =
         std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)(appuStack_c8[0][1] + (int)&stack0xffffff34) = appuStack_c8[0][1] + -0x50;
    FUN_0054ee60();
    appuStack_c8[1] =
         std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    uStack_8c = 0;
    uStack_88 = 4;
    uStack_8 = 3;
    FUN_00558890(appuStack_c8,param_2);
    puVar3 = *(undefined4 **)(param_1 + 4);
    puVar4 = (undefined4 *)*puVar3;
    while (puVar4 != puVar3) {
      puVar10 = (undefined4 *)(*(code *)**(undefined4 **)puVar4[5])(&uStack_28);
      puVar5 = puVar10 + 4;
      uStack_8._0_1_ = 4;
      if (0xf < (uint)puVar10[5]) {
        puVar10 = (undefined4 *)*puVar10;
      }
      FUN_0055b3b0(appuStack_c8,puVar10,*puVar5);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      if (0xf < uStack_18._4_4_) {
        uVar13 = uStack_18._4_4_ + 1;
        uVar12 = uStack_28;
        if (0xfff < uVar13) {
          uVar12 = *(uint *)(uStack_28 - 4);
          uVar13 = uStack_18._4_4_ + 0x24;
          if (0x1f < (uStack_28 - uVar12) - 4) goto LAB_0057d8f5;
        }
        FUN_01674ea0(uVar12,uVar13);
      }
      puVar5 = (undefined4 *)puVar4[2];
      if (*(char *)((int)puVar5 + 0xd) == '\0') {
        cVar2 = *(char *)((int)*puVar5 + 0xd);
        puVar4 = puVar5;
        puVar5 = (undefined4 *)*puVar5;
        while (cVar2 == '\0') {
          cVar2 = *(char *)((int)*puVar5 + 0xd);
          puVar4 = puVar5;
          puVar5 = (undefined4 *)*puVar5;
        }
      }
      else {
        cVar2 = *(char *)((int)puVar4[1] + 0xd);
        puVar10 = (undefined4 *)puVar4[1];
        puVar5 = puVar4;
        while ((puVar4 = puVar10, cVar2 == '\0' && (puVar5 == (undefined4 *)puVar4[2]))) {
          cVar2 = *(char *)((int)puVar4[1] + 0xd);
          puVar10 = (undefined4 *)puVar4[1];
          puVar5 = puVar4;
        }
      }
    }
    FUN_0058c420(&uStack_28);
    uVar9 = uStack_18;
    param_1 = iStack_30;
    uVar12 = *(uint *)(iStack_30 + 0xc);
    uVar6 = *(undefined4 *)(iStack_30 + 0x10);
    uVar7 = *(undefined4 *)(iStack_30 + 0x14);
    uVar8 = *(undefined4 *)(iStack_30 + 0x18);
    uVar1 = *(undefined8 *)(iStack_30 + 0x1c);
    uStack_18._4_4_ = (uint)((ulonglong)uVar1 >> 0x20);
    *(uint *)(iStack_30 + 0xc) = uStack_28;
    *(undefined4 *)(iStack_30 + 0x10) = uStack_24;
    *(undefined4 *)(iStack_30 + 0x14) = uStack_20;
    *(undefined4 *)(iStack_30 + 0x18) = uStack_1c;
    *(undefined8 *)(iStack_30 + 0x1c) = uVar9;
    uStack_28 = uVar12;
    uStack_24 = uVar6;
    uStack_20 = uVar7;
    uStack_1c = uVar8;
    if (0xf < uStack_18._4_4_) {
      uVar14 = uStack_18._4_4_ + 1;
      uVar13 = uVar12;
      uStack_18 = uVar1;
      if (0xfff < uVar14) {
        uVar13 = *(uint *)(uVar12 - 4);
        uVar14 = uStack_18._4_4_ + 0x24;
        if (0x1f < (uVar12 - uVar13) - 4) {
LAB_0057d8f5:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar13,uVar14);
    }
    uStack_18 = 0xf00000000;
    uStack_28 = uStack_28 & 0xffffff00;
    *(undefined ***)(appuStack_c8[0][1] + (int)appuStack_c8) =
         std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)(appuStack_c8[0][1] + (int)&stack0xffffff34) = appuStack_c8[0][1] + -0x50;
    FUN_0056b950();
    *(undefined ***)(appuStack_c8[0][1] + (int)appuStack_c8) =
         std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
    *(undefined **)(appuStack_c8[0][1] + (int)&stack0xffffff34) = appuStack_c8[0][1] + -8;
    uStack_8 = 5;
    appuStack_78[0] = std::ios_base::vftable;
    FUN_016de551(appuStack_78);
  }
  piVar11 = (int *)(param_1 + 0xc);
  if (0xf < *(uint *)(param_1 + 0x20)) {
    piVar11 = (int *)*piVar11;
  }
  ExceptionList = pvStack_10;
  return piVar11;
}



/* FUNCTION 3874 ; VA 0x0057d900 ; FUN_0057d900 */

undefined4 FUN_0057d900(void)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795c48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0151ac40();
  if (iVar1 == 0) {
    iVar1 = FUN_0151ac60();
  }
  if (iVar1 != 0) {
    FUN_0151ab60(iVar1);
  }
  uStack_8._0_1_ = 1;
  uVar2 = FUN_005be9c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iVar1 != 0) {
    FUN_0151ab30(iVar1);
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 3875 ; VA 0x0057d983 ; Catch@0057d983 */

undefined * Catch_0057d983(void)

{
  int *piVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  piVar1 = *(int **)(unaff_EBP + -0x18);
  if (DAT_01d59035 != '\0') {
    uVar2 = (**(code **)(*piVar1 + 4))();
    FUN_01677650(DAT_01d59035,"Exception dispatching soap request: %s",uVar2);
  }
  uVar2 = (**(code **)(*piVar1 + 4))(0);
  uVar2 = FUN_005bac20(*(undefined4 *)(unaff_EBP + -0x14),uVar2);
  *(undefined4 *)(unaff_EBP + -0x14) = uVar2;
  return &LAB_0057d9ca;
}



/* FUNCTION 3876 ; VA 0x0057d9de ; Catch@0057d9de */

undefined * Catch_0057d9de(void)

{
  int *piVar1;
  undefined4 uVar2;
  int unaff_EBP;
  int *piVar3;
  
  piVar3 = *(int **)(unaff_EBP + -0x20);
  piVar1 = piVar3;
  if (0xf < (uint)piVar3[5]) {
    piVar1 = (int *)*piVar3;
  }
  FUN_0171dd10(unaff_EBP + -0x120,piVar1,0x100);
  *(undefined *)(unaff_EBP + -0x21) = 0;
  FUN_01675310("SoapException",&DAT_018bc9b8);
  if (0xf < (uint)piVar3[5]) {
    piVar3 = (int *)*piVar3;
  }
  uVar2 = FUN_005bac20(*(undefined4 *)(unaff_EBP + -0x14),piVar3,0);
  *(undefined4 *)(unaff_EBP + -0x14) = uVar2;
  return &LAB_0057da32;
}



/* FUNCTION 3877 ; VA 0x0057da46 ; Catch_All@0057da46 */

undefined * Catch_All_0057da46(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  FUN_01675310("CaughtException",&DAT_018bc9b8);
  uVar1 = FUN_005bac20(*(undefined4 *)(unaff_EBP + -0x14),"Unexpected C++ exception type",0);
  *(undefined4 *)(unaff_EBP + -0x14) = uVar1;
  return &LAB_0057d9ca;
}



/* FUNCTION 3878 ; VA 0x0057da70 ; FUN_0057da70 */

void __fastcall FUN_0057da70(int param_1)

{
  if (*(int **)(param_1 + 0xc) != (int *)0x0) {
    (**(code **)(**(int **)(param_1 + 0xc) + 8))(1);
  }
  return;
}



/* FUNCTION 3879 ; VA 0x0057da80 ; FUN_0057da80 */

void __fastcall FUN_0057da80(int param_1)

{
  if (*(int **)(param_1 + 0xc) != (int *)0x0) {
    (**(code **)(**(int **)(param_1 + 0xc) + 4))(1);
  }
  return;
}



/* FUNCTION 3880 ; VA 0x0057da90 ; FUN_0057da90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_0057da90(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  double *pdVar3;
  undefined4 uVar4;
  int iVar5;
  double dVar6;
  undefined auStack_38 [16];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined auStack_1c [4];
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795c80;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffbc;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0151ac40();
  if (iVar2 == 0) {
    iVar2 = FUN_0151ac60();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  do {
    pdVar3 = (double *)FUN_01682800(auStack_1c);
    dVar6 = *(double *)(param_1 + 0x28) - *pdVar3;
    if (dVar6 <= 0.0) {
      iStack_18 = iVar2;
      if (iVar2 != 0) {
        FUN_0151ab60(iVar2);
      }
      uStack_8._0_1_ = 2;
      FUN_00556200("Lease expired");
      uStack_28 = 0;
      uStack_24 = 0xf;
      auStack_38[0] = 0;
      FUN_005542c0("RCCLeaseCheckFailure",0x14);
      uStack_8._0_1_ = 3;
      FUN_008783f0(auStack_38,1,0);
      uStack_8._0_1_ = 2;
      FUN_005507b0();
      uVar4 = FUN_01675640(auStack_38,"RCCLeaseCheckFailure_%d",DAT_01d7a884);
      uStack_8._0_1_ = 4;
      FUN_008783f0(uVar4,1,0);
      uStack_8._0_1_ = 2;
      FUN_005507b0();
      FUN_0057ad10(param_1,0);
      FUN_00556200("Requesting RCC shutdown");
      iVar5 = FUN_00556240();
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      if (iVar2 != 0) {
        iVar5 = FUN_0151ab30(iVar2);
      }
      break;
    }
    iVar5 = FUN_0151f440(3 - (int)(dVar6 * _DAT_018c0d88));
  } while ((char)iVar5 == '\0');
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 3881 ; VA 0x0057dc1e ; Catch@0057dc1e */

undefined4 Catch_0057dc1e(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  if (DAT_01d84e8c != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x1c) + 4))();
    FUN_01677520(DAT_01d84e8c,"doCheckLease failure: %s",uVar1);
  }
  return 0x57dbba;
}



/* FUNCTION 3882 ; VA 0x0057dc50 ; FUN_0057dc50 */

int FUN_0057dc50(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined auStack_30 [4];
  undefined4 uStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795ca0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  FUN_005dec20(auStack_30,param_4);
  iVar3 = FUN_0058ba80();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      uStack_2c = 0x57dcbe;
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        uStack_2c = 0x57dcce;
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      uStack_2c = 0x57dce4;
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_2c = 0x57dcf3;
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 3883 ; VA 0x0057dd10 ; FUN_0057dd10 */

int FUN_0057dd10(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,
                undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                undefined4 param_9)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cb8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_0056f790(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 3884 ; VA 0x0057ddb0 ; FUN_0057ddb0 */

int FUN_0057ddb0(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_0056f9c0(&param_2);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 3885 ; VA 0x0057de20 ; FUN_0057de20 */

int FUN_0057de20(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_0056fdf0(&param_2);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 3886 ; VA 0x0057de90 ; FUN_0057de90 */

int FUN_0057de90(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cf8;
  pvStack_10 = ExceptionList;
  iVar2 = 0;
  piVar4 = (int *)0x0;
  iVar3 = *(int *)(param_1 + 0x20);
  ExceptionList = &pvStack_10;
  if (iVar3 != 0) {
    piVar4 = (int *)(iVar3 + 4);
    iVar2 = *(int *)(iVar3 + 4);
    ExceptionList = &pvStack_10;
    while (iVar2 != 0) {
      LOCK();
      iVar3 = *piVar4;
      if (iVar2 == iVar3) {
        *piVar4 = iVar2 + 1;
        iVar3 = iVar2;
      }
      UNLOCK();
      if (iVar3 == iVar2) {
        iVar2 = *(int *)(param_1 + 0x1c);
        piVar4 = *(int **)(param_1 + 0x20);
        goto LAB_0057dee9;
      }
      iVar2 = *piVar4;
    }
    iVar2 = 0;
    piVar4 = (int *)0x0;
  }
LAB_0057dee9:
  uStack_8 = 0;
  if (iVar2 != 0) {
    if (iVar2 != -0xc) {
      FUN_0055e000();
      FUN_0055e310();
    }
    iVar2 = FUN_0093a3e0();
  }
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar1 = piVar4 + 1;
    iVar3 = *piVar1;
    iVar2 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar2 = (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar2 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 3887 ; VA 0x0057df60 ; FUN_0057df60 */

void FUN_0057df60(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0057df6a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(param_1 + 0x18))();
  return;
}



/* FUNCTION 3888 ; VA 0x0057df70 ; FUN_0057df70 */

void FUN_0057df70(int param_1)

{
  (**(code **)(param_1 + 0x18))(param_1 + 0x20);
  return;
}



/* FUNCTION 3889 ; VA 0x0057df90 ; FUN_0057df90 */

void __thiscall FUN_0057df90(int param_1,undefined4 param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  undefined4 uStack_18;
  undefined uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795d28;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x58);
  if ((uVar1 != 0) && (*(char *)(param_1 + 0x18) == '\0')) {
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x60,&uStack_3c,0);
    }
    else {
      uStack_3c = *(undefined4 *)(param_1 + 0x60);
      uStack_38 = *(undefined4 *)(param_1 + 100);
      uStack_34 = *(undefined4 *)(param_1 + 0x68);
      uStack_30 = *(undefined4 *)(param_1 + 0x6c);
      uStack_2c = *(undefined8 *)(param_1 + 0x70);
      ExceptionList = &pvStack_10;
    }
    uStack_8 = 0;
    uStack_18 = param_2;
    FUN_0058c660();
    uStack_14 = 1;
    uStack_8._0_1_ = 1;
    if (uVar1 == 0) {
      uVar2 = FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
      FUN_0054e5e0(uVar2);
    }
    (**(code **)((uVar1 & 0xfffffffe) + 4))(&uStack_3c);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_00587410();
    uStack_8 = 4;
    if (((uVar1 != 0) && ((uVar1 & 1) == 0)) && (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uVar1 & 0xfffffffe))(&uStack_3c,&uStack_3c,2);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3890 ; VA 0x0057e080 ; FUN_0057e080 */

undefined __fastcall FUN_0057e080(int param_1)

{
  return *(undefined *)(param_1 + 0xc);
}



/* FUNCTION 3891 ; VA 0x0057e090 ; FUN_0057e090 */

int FUN_0057e090(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x20);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    param_1 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x0057e0aa. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar3 = (**(code **)(*piVar2 + 4))();
      return iVar3;
    }
  }
  return param_1;
}



/* FUNCTION 3892 ; VA 0x0057e0b0 ; FUN_0057e0b0 */

int FUN_0057e0b0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x24);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    param_1 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      param_1 = (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0057e0e0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar3 = (**(code **)(*piVar2 + 4))();
        return iVar3;
      }
    }
  }
  return param_1;
}



/* FUNCTION 3893 ; VA 0x0057e0f0 ; FUN_0057e0f0 */

undefined * __thiscall FUN_0057e0f0(int param_1,undefined *param_2)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  
  pcVar2 = *(char **)(param_1 + 0x10);
  *(undefined4 *)(param_2 + 0x10) = 0;
  *(undefined4 *)(param_2 + 0x14) = 0xf;
  *param_2 = 0;
  pcVar3 = pcVar2;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar2,(int)pcVar3 - (int)(pcVar2 + 1));
  return param_2;
}



/* FUNCTION 3894 ; VA 0x0057e130 ; FUN_0057e130 */

undefined * __thiscall FUN_0057e130(int param_1,undefined *param_2)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  
  pcVar2 = *(char **)(param_1 + 8);
  *(undefined4 *)(param_2 + 0x10) = 0;
  *(undefined4 *)(param_2 + 0x14) = 0xf;
  *param_2 = 0;
  pcVar3 = pcVar2;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar2,(int)pcVar3 - (int)(pcVar2 + 1));
  return param_2;
}



/* FUNCTION 3895 ; VA 0x0057e170 ; FUN_0057e170 */

undefined4 __thiscall
FUN_0057e170(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5
            ,undefined4 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  undefined auStack_4c [64];
  undefined auStack_c [8];
  
  uVar1 = FUN_00576eb0(param_1,auStack_c,&DAT_018c0400,*(undefined4 *)(param_5 + 0x14),param_7);
  uVar1 = FUN_0058ccc0(auStack_4c,0x40,uVar1);
  FUN_005771c0(param_1,param_2,param_3,param_4,param_5,param_6,auStack_4c,uVar1);
  return param_2;
}



/* FUNCTION 3896 ; VA 0x0057e1d0 ; FUN_0057e1d0 */

undefined4 __thiscall
FUN_0057e1d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5
            ,undefined4 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  undefined auStack_4c [64];
  undefined auStack_c [8];
  
  uVar1 = FUN_00576eb0(param_1,auStack_c,&DAT_018c03fc,*(undefined4 *)(param_5 + 0x14),param_7);
  uVar1 = FUN_0058ccc0(auStack_4c,0x40,uVar1);
  FUN_005771c0(param_1,param_2,param_3,param_4,param_5,param_6,auStack_4c,uVar1);
  return param_2;
}



/* FUNCTION 3897 ; VA 0x0057e230 ; FUN_0057e230 */

undefined4 __thiscall
FUN_0057e230(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            uint param_5,undefined4 param_6,undefined8 param_7)

{
  uint uVar1;
  undefined4 ****ppppuVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  undefined4 ***apppuStack_34 [4];
  uint uStack_24;
  uint uStack_20;
  undefined auStack_1c [4];
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar5 = param_5;
  puStack_c = &LAB_01795d48;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  uStack_20 = 0xf;
  apppuStack_34[0] = (undefined4 ***)((uint)apppuStack_34[0] & 0xffffff00);
  uStack_8 = 0;
  iStack_18 = *(int *)(param_5 + 0x1c);
  uVar1 = *(uint *)(param_5 + 0x14) & 0x3000;
  iVar6 = *(int *)(param_5 + 0x18);
  if ((iStack_18 < 1) && (((iStack_18 < 0 || (iVar6 == 0)) && (uVar1 != 0x2000)))) {
    iVar6 = 6;
    iStack_18 = 0;
  }
  iVar4 = iVar6;
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  if ((uVar1 == 0x2000) &&
     (uVar1 = (uint)((ulonglong)param_7 >> 0x20), ExceptionList = &pvStack_10,
     DAT_018c0d78 < (double)CONCAT44(uVar1 & DAT_018c0da0._4_4_,(uint)param_7 & (uint)DAT_018c0da0))
     ) {
    ExceptionList = &pvStack_10;
    FUN_0171de34((uint)param_7,uVar1,&param_5);
    iVar4 = (int)(((param_5 ^ (int)param_5 >> 0x1f) - ((int)param_5 >> 0x1f)) * 0x7597) / 100000 +
            iVar6;
  }
  uVar1 = iVar4 + 0x32;
  if (uStack_24 < uVar1) {
    FUN_00578160(uVar1 - uStack_24,0);
  }
  else {
    ppppuVar2 = apppuStack_34;
    if (0xf < uStack_20) {
      ppppuVar2 = (undefined4 ****)apppuStack_34[0];
    }
    uStack_24 = uVar1;
    *(undefined *)((int)ppppuVar2 + uVar1) = 0;
  }
  uVar3 = FUN_005767b0(uStack_14,auStack_1c,0,*(undefined4 *)(uVar5 + 0x14));
  ppppuVar2 = apppuStack_34;
  if (0xf < uStack_20) {
    ppppuVar2 = (undefined4 ****)apppuStack_34[0];
  }
  uVar3 = FUN_0058ccc0(ppppuVar2,uStack_24,uVar3,iVar6,(int)param_7,
                       (int)((ulonglong)param_7 >> 0x20));
  ppppuVar2 = apppuStack_34;
  if (0xf < uStack_20) {
    ppppuVar2 = (undefined4 ****)apppuStack_34[0];
  }
  FUN_00576870(uStack_14,param_2,param_3,param_4,uVar5,param_6,ppppuVar2,uVar3);
  if (0xf < uStack_20) {
    uVar5 = uStack_20 + 1;
    ppppuVar2 = (undefined4 ****)apppuStack_34[0];
    if (0xfff < uVar5) {
      ppppuVar2 = (undefined4 ****)apppuStack_34[0][-1];
      uVar5 = uStack_20 + 0x24;
      if (0x1f < (uint)((int)apppuStack_34[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar2,uVar5);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 3898 ; VA 0x0057e3c0 ; FUN_0057e3c0 */

undefined4 __thiscall
FUN_0057e3c0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            uint param_5,undefined4 param_6,undefined8 param_7)

{
  uint uVar1;
  undefined4 ****ppppuVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  undefined4 ***apppuStack_34 [4];
  uint uStack_24;
  uint uStack_20;
  undefined auStack_1c [4];
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar5 = param_5;
  puStack_c = &LAB_01795d48;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  uStack_20 = 0xf;
  apppuStack_34[0] = (undefined4 ***)((uint)apppuStack_34[0] & 0xffffff00);
  uStack_8 = 0;
  iStack_18 = *(int *)(param_5 + 0x1c);
  uVar1 = *(uint *)(param_5 + 0x14) & 0x3000;
  iVar6 = *(int *)(param_5 + 0x18);
  if ((iStack_18 < 1) && (((iStack_18 < 0 || (iVar6 == 0)) && (uVar1 != 0x2000)))) {
    iVar6 = 6;
    iStack_18 = 0;
  }
  iVar4 = iVar6;
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  if ((uVar1 == 0x2000) &&
     (uVar1 = (uint)((ulonglong)param_7 >> 0x20), ExceptionList = &pvStack_10,
     DAT_018c0d78 < (double)CONCAT44(uVar1 & DAT_018c0da0._4_4_,(uint)param_7 & (uint)DAT_018c0da0))
     ) {
    ExceptionList = &pvStack_10;
    FUN_0171de34((uint)param_7,uVar1,&param_5);
    iVar4 = (int)(((param_5 ^ (int)param_5 >> 0x1f) - ((int)param_5 >> 0x1f)) * 0x7597) / 100000 +
            iVar6;
  }
  uVar1 = iVar4 + 0x32;
  if (uStack_24 < uVar1) {
    FUN_00578160(uVar1 - uStack_24,0);
  }
  else {
    ppppuVar2 = apppuStack_34;
    if (0xf < uStack_20) {
      ppppuVar2 = (undefined4 ****)apppuStack_34[0];
    }
    uStack_24 = uVar1;
    *(undefined *)((int)ppppuVar2 + uVar1) = 0;
  }
  uVar3 = FUN_005767b0(uStack_14,auStack_1c,0x4c,*(undefined4 *)(uVar5 + 0x14));
  ppppuVar2 = apppuStack_34;
  if (0xf < uStack_20) {
    ppppuVar2 = (undefined4 ****)apppuStack_34[0];
  }
  uVar3 = FUN_0058ccc0(ppppuVar2,uStack_24,uVar3,iVar6,(int)param_7,
                       (int)((ulonglong)param_7 >> 0x20));
  ppppuVar2 = apppuStack_34;
  if (0xf < uStack_20) {
    ppppuVar2 = (undefined4 ****)apppuStack_34[0];
  }
  FUN_00576870(uStack_14,param_2,param_3,param_4,uVar5,param_6,ppppuVar2,uVar3);
  if (0xf < uStack_20) {
    uVar5 = uStack_20 + 1;
    ppppuVar2 = (undefined4 ****)apppuStack_34[0];
    if (0xfff < uVar5) {
      ppppuVar2 = (undefined4 ****)apppuStack_34[0][-1];
      uVar5 = uStack_20 + 0x24;
      if (0x1f < (uint)((int)apppuStack_34[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar2,uVar5);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 3899 ; VA 0x0057e550 ; FUN_0057e550 */

undefined4 __thiscall
FUN_0057e550(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  undefined auStack_44 [64];
  
  uVar1 = FUN_0058ccc0(auStack_44,0x40,&DAT_018c03f0,param_7);
  FUN_005771c0(param_1,param_2,param_3,param_4,param_5,param_6,auStack_44,uVar1);
  return param_2;
}



/* FUNCTION 3900 ; VA 0x0057e5a0 ; FUN_0057e5a0 */

undefined4 __thiscall
FUN_0057e5a0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5
            ,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined auStack_44 [64];
  
  uVar1 = FUN_00576eb0(param_1,&param_7,&DAT_018c03f8,*(undefined4 *)(param_5 + 0x14),param_7,
                       param_8);
  uVar1 = FUN_0058ccc0(auStack_44,0x40,uVar1);
  FUN_005771c0(param_1,param_2,param_3,param_4,param_5,param_6,auStack_44,uVar1);
  return param_2;
}



/* FUNCTION 3901 ; VA 0x0057e600 ; FUN_0057e600 */

undefined4 __thiscall
FUN_0057e600(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5
            ,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined auStack_44 [64];
  
  uVar1 = FUN_00576eb0(param_1,&param_7,&DAT_018c03f4,*(undefined4 *)(param_5 + 0x14),param_7,
                       param_8);
  uVar1 = FUN_0058ccc0(auStack_44,0x40,uVar1);
  FUN_005771c0(param_1,param_2,param_3,param_4,param_5,param_6,auStack_44,uVar1);
  return param_2;
}



/* FUNCTION 3902 ; VA 0x0057e660 ; FUN_0057e660 */

undefined4 __thiscall
FUN_0057e660(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6,char param_7)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined4 ****ppppuVar6;
  uint uVar7;
  int iVar8;
  undefined4 ***pppuStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 ***pppuStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  undefined auStack_24 [8];
  undefined auStack_1c [4];
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795d70;
  pvStack_10 = ExceptionList;
  piStack_14 = param_1;
  if ((*(uint *)(param_5 + 0x14) & 0x4000) == 0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*param_1 + 0x24))(param_2,param_3,param_4,param_5,param_6,param_7);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar1 = *(int **)(*(int *)(param_5 + 0x30) + 4);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_18 = piVar1;
  (**(code **)(*piVar1 + 4))();
  uStack_8 = 1;
  piVar4 = (int *)FUN_00564bf0(auStack_1c);
  uStack_8 = 2;
  if ((piVar1 != (int *)0x0) &&
     (puVar5 = (undefined4 *)(**(code **)(*piVar1 + 8))(), puVar5 != (undefined4 *)0x0)) {
    (**(code **)*puVar5)(1);
  }
  uStack_2c = 0xf00000000;
  pppuStack_3c = (undefined4 ***)((uint)pppuStack_3c & 0xffffff00);
  uStack_8 = 3;
  if (param_7 == '\0') {
    (**(code **)(*piVar4 + 0x18))(&pppuStack_54);
  }
  else {
    (**(code **)(*piVar4 + 0x1c))();
  }
  FUN_005507b0();
  pppuStack_3c = pppuStack_54;
  pppuStack_54 = (undefined4 ***)((uint)pppuStack_54 & 0xffffff00);
  uStack_38 = uStack_50;
  uStack_34 = uStack_4c;
  uStack_30 = uStack_48;
  uStack_2c = CONCAT44(uStack_40,uStack_44);
  uStack_44 = 0;
  uStack_40 = 0xf;
  FUN_005507b0();
  uVar7 = *(uint *)(param_5 + 0x20);
  if ((*(int *)(param_5 + 0x24) < 0) ||
     (((*(int *)(param_5 + 0x24) < 1 && (uVar7 == 0)) || (uVar7 <= (uint)uStack_2c)))) {
    iVar8 = 0;
  }
  else {
    iVar8 = uVar7 - (uint)uStack_2c;
  }
  if ((*(uint *)(param_5 + 0x14) & 0x1c0) != 0x40) {
    puVar5 = (undefined4 *)FUN_00577870(piStack_14,auStack_1c,param_3,param_4,param_6,iVar8);
    iVar8 = 0;
    param_3 = *puVar5;
    param_4 = puVar5[1];
  }
  ppppuVar6 = &pppuStack_3c;
  if (0xf < uStack_2c._4_4_) {
    ppppuVar6 = (undefined4 ****)pppuStack_3c;
  }
  puVar5 = (undefined4 *)
           FUN_005777f0(piStack_14,auStack_24,param_3,param_4,ppppuVar6,(uint)uStack_2c);
  uVar2 = *puVar5;
  uVar3 = puVar5[1];
  *(undefined4 *)(param_5 + 0x20) = 0;
  *(undefined4 *)(param_5 + 0x24) = 0;
  FUN_00577870(piStack_14,param_2,uVar2,uVar3,param_6,iVar8);
  if (0xf < uStack_2c._4_4_) {
    uVar7 = uStack_2c._4_4_ + 1;
    ppppuVar6 = (undefined4 ****)pppuStack_3c;
    if (0xfff < uVar7) {
      ppppuVar6 = (undefined4 ****)pppuStack_3c[-1];
      uVar7 = uStack_2c._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppuStack_3c + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar6,uVar7);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 3903 ; VA 0x0057e860 ; FUN_0057e860 */

undefined __fastcall FUN_0057e860(int param_1)

{
  return *(undefined *)(param_1 + 0xd);
}



/* FUNCTION 3904 ; VA 0x0057e870 ; FUN_0057e870 */

undefined * __thiscall FUN_0057e870(int param_1,undefined *param_2)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  
  pcVar2 = *(char **)(param_1 + 0x14);
  *(undefined4 *)(param_2 + 0x10) = 0;
  *(undefined4 *)(param_2 + 0x14) = 0xf;
  *param_2 = 0;
  pcVar3 = pcVar2;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar2,(int)pcVar3 - (int)(pcVar2 + 1));
  return param_2;
}



/* FUNCTION 3905 ; VA 0x0057e8b0 ; FUN_0057e8b0 */

/* WARNING: Removing unreachable block (ram,0x0057eacd) */
/* WARNING: Removing unreachable block (ram,0x0057eae0) */
/* WARNING: Removing unreachable block (ram,0x0057eae7) */
/* WARNING: Removing unreachable block (ram,0x0057eaee) */

uint __thiscall FUN_0057e8b0(int param_1,undefined4 *param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  uint *puVar2;
  uint uVar3;
  undefined4 *puVar4;
  int *piVar5;
  int *piVar6;
  int iVar7;
  uint uVar8;
  int *piVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795da2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  puVar10 = param_2;
  uStack_8 = 0;
  FUN_005875d0(&param_2,param_2);
  puVar11 = param_2;
  puVar4 = *(undefined4 **)(param_1 + 0xb4);
  if (param_2 != puVar4) {
    piVar6 = param_2 + 4;
    if (0xf < (uint)param_2[9]) {
      piVar6 = (int *)*piVar6;
    }
    puVar1 = puVar10 + 4;
    if (0xf < (uint)puVar10[5]) {
      puVar10 = (undefined4 *)*puVar10;
    }
    iVar7 = FUN_0055c2d0(puVar10,*puVar1,piVar6,param_2[8]);
    if (-1 < iVar7) goto LAB_0057e93a;
  }
  puVar11 = puVar4;
LAB_0057e93a:
  if (puVar11 == puVar4) {
    uVar8 = (uint)DAT_01d59035;
    if (DAT_01d59035 != 0) {
      uVar8 = FUN_016774b0(DAT_01d59035,"ERROR - Monitoring requested for invalid job ID!",0);
    }
  }
  else {
    piVar6 = (int *)puVar11[0xb];
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      piVar6 = (int *)puVar11[0xb];
    }
    param_2 = (undefined4 *)puVar11[10];
    uStack_8._0_1_ = 1;
    if (*(int *)((int)param_2 + 0x20) == 0) {
      piVar9 = (int *)FUN_01674e20(0xf0);
      uStack_8._0_1_ = 2;
      if (piVar9 == (int *)0x0) {
        piVar9 = (int *)0x0;
      }
      else {
        piVar9[1] = 1;
        piVar9[2] = 1;
        *piVar9 = (int)std::_Ref_count_obj<class_RBX::RCCMonitoring>::vftable;
        FUN_005d0d40((int)param_2 + 0x18,param_3);
      }
      piVar5 = piVar9 + 4;
      uStack_8._0_1_ = 1;
      if ((piVar5 != (int *)0x0) && ((piVar9[5] == 0 || (*(int *)(piVar9[5] + 4) == 0)))) {
        if (piVar9 != (int *)0x0) {
          LOCK();
          piVar9[1] = piVar9[1] + 1;
          UNLOCK();
          LOCK();
          piVar9[2] = piVar9[2] + 1;
          UNLOCK();
        }
        *piVar5 = (int)piVar5;
        piVar5 = (int *)piVar9[5];
        piVar9[5] = (int)piVar9;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar7 = piVar5[2] + -1;
          piVar5[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
        if (piVar9 != (int *)0x0) {
          LOCK();
          iVar7 = piVar9[1] + -1;
          piVar9[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)*piVar9)();
            LOCK();
            iVar7 = piVar9[2] + -1;
            piVar9[2] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)(*piVar9 + 4))();
            }
          }
        }
      }
      *(int **)((int)param_2 + 0x20) = piVar9 + 4;
      piVar5 = *(int **)((int)param_2 + 0x24);
      *(int **)((int)param_2 + 0x24) = piVar9;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar7 = piVar5[1] + -1;
        piVar5[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar7 = piVar5[2] + -1;
          piVar5[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      FUN_005d5c30();
      uVar8 = FUN_005d9a70();
    }
    else {
      uVar8 = (uint)DAT_01d59035;
      if (DAT_01d59035 != 0) {
        uVar8 = FUN_016774b0(DAT_01d59035,"ERROR - Monitoring enabled twice!",0);
      }
    }
    if (piVar6 != (int *)0x0) {
      LOCK();
      puVar2 = (uint *)(piVar6 + 1);
      uVar3 = *puVar2;
      uVar8 = *puVar2;
      *puVar2 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        uVar8 = (**(code **)*piVar6)();
        LOCK();
        piVar9 = piVar6 + 2;
        iVar7 = *piVar9;
        *piVar9 = *piVar9 + -1;
        UNLOCK();
        if (iVar7 == 1) {
          uVar8 = (**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 3906 ; VA 0x0057eb10 ; FUN_0057eb10 */

undefined4 FUN_0057eb10(undefined4 param_1,undefined2 param_2)

{
  char cVar1;
  
  switch(param_2) {
  case 2:
    break;
  default:
    return 0x1f;
  case 4:
  case 6:
  case 9:
  case 0xb:
    return 0x1e;
  }
  cVar1 = FUN_005862f0(param_1);
  if (cVar1 != '\0') {
    return 0x1d;
  }
  return 0x1c;
}



/* FUNCTION 3907 ; VA 0x0057eb70 ; FUN_0057eb70 */

void __thiscall FUN_0057eb70(int *param_1,undefined4 *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  void **ppvVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  ppvVar3 = &pvStack_10;
  if ((param_3 == (int *)*piVar1) && (ppvVar3 = &pvStack_10, param_4 == piVar1)) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_00576500(piVar1[1]);
    *(int **)(*param_1 + 4) = piVar1;
    *(int **)*param_1 = piVar1;
    *(int **)(*param_1 + 8) = piVar1;
    param_1[1] = 0;
    *param_2 = *(undefined4 *)*param_1;
    ExceptionList = pvStack_10;
    return;
  }
  while (ExceptionList = ppvVar3, param_3 != param_4) {
    FUN_00551320();
    FUN_00551320();
    iVar4 = FUN_00553830(param_3);
    piVar1 = *(int **)(iVar4 + 0x18);
    uStack_8 = 1;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[1] + -1;
      piVar1[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 8))();
        }
      }
    }
    uStack_8 = 0xffffffff;
    FUN_01674ea0(iVar4,0x20);
    ppvVar3 = (void **)ExceptionList;
  }
  *param_2 = param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3908 ; VA 0x0057ec70 ; FUN_0057ec70 */

void FUN_0057ec70(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00551320();
  iVar4 = FUN_00553830(param_2);
  piVar2 = *(int **)(iVar4 + 0x18);
  uStack_8 = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 8))();
      }
    }
  }
  FUN_01674ea0(iVar4,0x20);
  *param_1 = param_2;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3909 ; VA 0x0057ed00 ; FUN_0057ed00 */

void __thiscall FUN_0057ed00(int *param_1,undefined4 *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  void **ppvVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  ppvVar2 = &pvStack_10;
  if ((param_3 == (int *)*piVar1) && (ppvVar2 = &pvStack_10, param_4 == piVar1)) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_005766d0(piVar1[1]);
    *(int **)(*param_1 + 4) = piVar1;
    *(int **)*param_1 = piVar1;
    *(int **)(*param_1 + 8) = piVar1;
    param_1[1] = 0;
    *param_2 = *(undefined4 *)*param_1;
    ExceptionList = pvStack_10;
    return;
  }
  while (ExceptionList = ppvVar2, param_3 != param_4) {
    FUN_00551320();
    FUN_00551320();
    uVar3 = FUN_00553830(param_3);
    FUN_0056cac0();
    FUN_01674ea0(uVar3,0x30);
    ppvVar2 = (void **)ExceptionList;
  }
  *param_2 = param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3910 ; VA 0x0057edd0 ; FUN_0057edd0 */

int __thiscall FUN_0057edd0(int *param_1,int *param_2)

{
  char cVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  undefined4 *puVar7;
  int *piVar8;
  undefined4 *puVar9;
  int *piVar10;
  int *piStack_10;
  
  param_1 = (int *)*param_1;
  piVar8 = param_1 + 1;
  piStack_10 = (int *)*piVar8;
  cVar1 = *(char *)((int)piStack_10 + 0xd);
  piVar3 = param_1;
  puVar7 = param_2;
  while (puVar9 = param_2, param_2 = puVar9, cVar1 == '\0') {
    piVar5 = piStack_10 + 4;
    if (0xf < (uint)puVar7[5]) {
      puVar7 = (undefined4 *)*puVar7;
    }
    uVar2 = piStack_10[9];
    iVar6 = piStack_10[8];
    piVar10 = piVar5;
    if (0xf < uVar2) {
      piVar10 = (int *)*piVar5;
    }
    iVar4 = FUN_0055c2d0(piVar10,iVar6,puVar7,puVar9[4]);
    if (iVar4 < 0) {
      piVar5 = (int *)piStack_10[2];
      piStack_10 = piVar3;
    }
    else {
      if (*(char *)((int)param_1 + 0xd) != '\0') {
        if (0xf < uVar2) {
          piVar5 = (int *)*piVar5;
        }
        puVar7 = puVar9;
        if (0xf < (uint)puVar9[5]) {
          puVar7 = (undefined4 *)*puVar9;
        }
        iVar6 = FUN_0055c2d0(puVar7,puVar9[4],piVar5,iVar6);
        if (iVar6 < 0) {
          param_1 = piStack_10;
        }
      }
      piVar5 = (int *)*piStack_10;
    }
    piVar3 = piStack_10;
    piStack_10 = piVar5;
    puVar7 = puVar9;
    cVar1 = *(char *)((int)piVar5 + 0xd);
  }
  if (*(char *)((int)param_1 + 0xd) == '\0') {
    piVar8 = param_1;
  }
  cVar1 = *(char *)(*piVar8 + 0xd);
  piVar8 = (int *)*piVar8;
  while (cVar1 == '\0') {
    piVar5 = piVar8 + 4;
    if (0xf < (uint)piVar8[9]) {
      piVar5 = (int *)*piVar5;
    }
    puVar9 = puVar7;
    if (0xf < (uint)puVar7[5]) {
      puVar9 = (undefined4 *)*puVar7;
    }
    iVar6 = FUN_0055c2d0(puVar9,puVar7[4],piVar5,piVar8[8]);
    if (iVar6 < 0) {
      piVar5 = (int *)*piVar8;
      param_1 = piVar8;
    }
    else {
      piVar5 = (int *)piVar8[2];
    }
    piVar8 = piVar5;
    cVar1 = *(char *)((int)piVar5 + 0xd);
  }
  iVar6 = 0;
  param_2 = piVar3;
  while (param_2 != param_1) {
    iVar6 = iVar6 + 1;
    FUN_00551320();
  }
  FUN_0057ed00(&param_2,piVar3,param_1);
  return iVar6;
}



/* FUNCTION 3911 ; VA 0x0057ef00 ; FUN_0057ef00 */

void __thiscall FUN_0057ef00(uint param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  int *piVar8;
  
  piVar8 = (int *)(-(uint)(param_2 != 0) & param_2 + 0x30U);
  piVar6 = (int *)((-(uint)(param_1 != 0xfffffff4) & param_1) + 0x28);
  *piVar6 = *piVar6 + -1;
  puVar1 = (undefined4 *)piVar8[1];
  piVar6 = *(int **)(*piVar8 + 4);
  piVar2 = (int *)*puVar1;
  if (piVar6 == piVar8) {
    *(undefined4 **)(*piVar8 + 4) = puVar1;
    piVar6 = (int *)piVar8[1];
    if (piVar2 != piVar8) {
      piVar6 = (int *)*piVar6;
    }
  }
  else if (piVar2 == piVar8) {
    *piVar6 = (int)puVar1;
    piVar6 = (int *)piVar8[1];
  }
  else {
    *piVar6 = 0;
    *(int *)(*piVar8 + 4) = piVar8[1];
    piVar6 = *(int **)piVar8[1];
  }
  *piVar6 = *piVar8;
  uVar3 = *(uint *)(param_2 + 0x24);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_2 + 0x10);
    uVar7 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar7) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar7 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar7);
  }
  *(undefined4 *)(param_2 + 0x20) = 0;
  *(undefined4 *)(param_2 + 0x24) = 0xf;
  *(undefined *)(param_2 + 0x10) = 0;
  FUN_01674ea0(param_2,0x38);
  return;
}



/* FUNCTION 3912 ; VA 0x0057efc0 ; FUN_0057efc0 */

uint __thiscall
FUN_0057efc0(int param_1,undefined4 param_2,uint param_3,int *param_4,undefined4 param_5)

{
  uint *puVar1;
  int *piVar2;
  undefined4 ***pppuVar3;
  char cVar4;
  undefined4 uVar5;
  int *piVar6;
  int iVar7;
  int iVar8;
  undefined4 ****ppppuVar9;
  undefined4 *puVar10;
  uint uVar11;
  int iVar12;
  uint uVar13;
  undefined uVar14;
  undefined4 in_stack_ffffff08;
  undefined4 in_stack_ffffff0c;
  undefined4 in_stack_ffffff10;
  undefined4 uVar15;
  undefined4 uVar16;
  undefined4 uVar17;
  undefined auStack_98 [8];
  undefined auStack_90 [16];
  undefined4 uStack_80;
  undefined4 uStack_7c;
  int iStack_78;
  undefined4 uStack_74;
  undefined4 ***apppuStack_70 [5];
  uint uStack_5c;
  int iStack_58;
  int *piStack_54;
  int *piStack_50;
  int *piStack_4c;
  undefined4 uStack_48;
  int *piStack_44;
  undefined4 ***apppuStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  uint *puStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795eb9;
  pvStack_10 = ExceptionList;
  uStack_74 = 0;
  ExceptionList = &pvStack_10;
  iStack_78 = param_1;
  FUN_01682800(auStack_98);
  FUN_0054ef60(*(undefined4 *)(param_3 + 8));
  uVar5 = param_2;
  uStack_8 = 0;
  if (DAT_01d592e8 == '\0') {
    FUN_0057b580(param_2,apppuStack_70);
  }
  if (DAT_01d59104 != '\0') {
    ppppuVar9 = apppuStack_70;
    if (0xf < uStack_5c) {
      ppppuVar9 = (undefined4 ****)apppuStack_70[0];
    }
    FUN_01677520(DAT_01d59104,"RCC Executing: [%s]",ppppuVar9);
  }
  if (DAT_01d593b0 != '\0') {
    FUN_0151f6f0(DAT_01e90d60,0,DAT_01e90d64);
    uStack_8._0_1_ = 1;
    FUN_0151f950("JobID",uVar5);
    FUN_0151f950("RCCScript",apppuStack_70);
    uVar15 = DAT_01e90d60;
    uStack_30 = 0;
    uStack_2c = 0xf;
    apppuStack_40[0] = (undefined4 ***)((uint)apppuStack_40[0] & 0xffffff00);
    FUN_005542c0("RCCJob",6);
    uStack_8._0_1_ = 2;
    FUN_01520d20(apppuStack_40,uVar15,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (0xf < uStack_2c) {
      uVar11 = uStack_2c + 1;
      ppppuVar9 = (undefined4 ****)apppuStack_40[0];
      if (0xfff < uVar11) {
        ppppuVar9 = (undefined4 ****)apppuStack_40[0][-1];
        uVar11 = uStack_2c + 0x24;
        if (0x1f < (uint)((int)apppuStack_40[0] + (-4 - (int)ppppuVar9))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar9,uVar11);
    }
    FUN_0151f7f0();
  }
  uStack_48 = 0;
  piStack_44 = (int *)0x0;
  iStack_58 = 0;
  piStack_54 = (int *)0x0;
  puStack_20 = (uint *)(param_1 + 0xbc);
  uStack_8._0_1_ = 4;
  piStack_1c = (int *)((uint)piStack_1c & 0xffffff00);
  FUN_00587410();
  uStack_8._0_1_ = 5;
  FUN_00581830(&param_3,uVar5);
  iVar12 = *(int *)(param_3 + 0x28);
  piStack_50 = *(int **)(iVar12 + 0x1c);
  puVar10 = (undefined4 *)(iVar12 + 0x18);
  if (piStack_50 != (int *)0x0) {
    LOCK();
    piStack_50[1] = piStack_50[1] + 1;
    UNLOCK();
    piStack_50 = *(int **)(iVar12 + 0x1c);
    iVar12 = *(int *)(param_3 + 0x28);
  }
  uStack_48 = *puVar10;
  piStack_54 = *(int **)(iVar12 + 0x4c);
  if (piStack_54 != (int *)0x0) {
    LOCK();
    piStack_54[1] = piStack_54[1] + 1;
    UNLOCK();
    piStack_54 = *(int **)(iVar12 + 0x4c);
  }
  iVar12 = *(int *)(iVar12 + 0x48);
  uStack_8._0_1_ = 6;
  iStack_58 = iVar12;
  piStack_4c = piStack_54;
  piStack_44 = piStack_50;
  if ((char)piStack_1c != '\0') {
    LOCK();
    uVar11 = *puStack_20;
    *puStack_20 = *puStack_20 + 0x80000000;
    UNLOCK();
    if (((uVar11 & 0x40000000) == 0) && (-0x80000000 < (int)uVar11)) {
      LOCK();
      uVar11 = *puStack_20;
      *puStack_20 = *puStack_20 | 0x40000000;
      UNLOCK();
      if ((uVar11 >> 0x1e & 1) == 0) {
        uVar5 = FUN_00554e40();
        SetEvent(uVar5);
      }
    }
  }
  uStack_8._0_1_ = 4;
  if (iVar12 != 0) {
    uVar17 = 0;
    uVar16 = 0;
    uVar5 = 0;
    uVar15 = 0xf;
    uVar14 = 0;
    FUN_005542c0("JobExecuteStarted",0x11);
    FUN_005db7a0(uVar14,in_stack_ffffff08,in_stack_ffffff0c,in_stack_ffffff10,uVar5,uVar15,uVar16,
                 uVar17);
  }
  puStack_20 = (uint *)0x0;
  piStack_1c = (int *)0x0;
  uStack_28 = 0;
  piStack_24 = (int *)0x0;
  uStack_8._0_1_ = 8;
  cVar4 = FUN_0098f070(apppuStack_70,&uStack_28,0);
  if (cVar4 == '\0') {
    if (DAT_01e90d4c != 0) {
      FUN_0151f6f0(0xffffffff,0,0);
      uStack_8._0_1_ = 0x12;
      FUN_0058c540(apppuStack_40,0,500);
      uStack_8._0_1_ = 0x13;
      FUN_0151f950("Contents",apppuStack_40);
      iVar12 = DAT_01e90d4c;
      FUN_0054eff0("RCCNonJsonExecute");
      uStack_8._0_1_ = 0x14;
      FUN_01520d20(auStack_90,iVar12,0);
      FUN_005507b0();
      FUN_005507b0();
      uStack_8._0_1_ = 8;
      FUN_0151f7f0();
    }
    FUN_0054eff0("RCCNonJsonExecute");
    uStack_8._0_1_ = 0x15;
    FUN_008783f0(auStack_90,1,1);
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    FUN_005507b0();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Attempted to execute with invalid JSON: %s",uVar5);
  }
  uStack_80 = 0;
  uStack_7c = 0xf;
  auStack_90[0] = 0;
  FUN_005542c0(&DAT_018bf334,4);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  uStack_74 = 1;
  piVar6 = (int *)FUN_00580040(&uStack_14,auStack_90);
  iVar12 = *piVar6;
  if (iVar12 == 0) {
LAB_0057f29d:
    param_3 = param_3 & 0xffffff;
  }
  else {
    iVar8 = *(int *)(iVar12 + 0x20);
    iVar7 = FUN_0088cb40();
    param_3 = CONCAT13(1,(undefined3)param_3);
    if (iVar8 != iVar7) goto LAB_0057f29d;
  }
  uStack_8 = 8;
  FUN_005507b0();
  piVar6 = (int *)0x0;
  if (param_3._3_1_ == '\0') goto LAB_0057f66e;
  iVar8 = *(int *)(iVar12 + 0x20);
  iVar7 = FUN_0088cb40();
  if (iVar8 != iVar7) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  iVar8 = iVar12 + 0x28;
  if (*(int *)(iVar12 + 0x24) == 0) {
    iVar8 = 0;
  }
  FUN_0054ef60(iVar8);
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  ppppuVar9 = apppuStack_40;
  if (0xf < uStack_2c) {
    ppppuVar9 = (undefined4 ****)apppuStack_40[0];
  }
  FUN_0151aac0(ppppuVar9);
  if (DAT_01d59104 != '\0') {
    ppppuVar9 = apppuStack_40;
    if (0xf < uStack_2c) {
      ppppuVar9 = (undefined4 ****)apppuStack_40[0];
    }
    FUN_01677520(DAT_01d59104,"Executing job with mode %s",ppppuVar9);
  }
  uVar11 = uStack_2c;
  uVar5 = uStack_30;
  pppuVar3 = apppuStack_40[0];
  ppppuVar9 = apppuStack_40;
  if (0xf < uStack_2c) {
    ppppuVar9 = (undefined4 ****)apppuStack_40[0];
  }
  cVar4 = FUN_0055c360(ppppuVar9,uStack_30,"GameServer",10);
  if (cVar4 == '\0') {
    ppppuVar9 = apppuStack_40;
    if (0xf < uVar11) {
      ppppuVar9 = (undefined4 ****)pppuVar3;
    }
    cVar4 = FUN_0055c360(ppppuVar9,uVar5,"EvictPlayer",0xb);
    if (cVar4 != '\0') {
      FUN_00582880(&uStack_28,&uStack_48);
      uVar11 = FUN_01674e20(0xc);
      uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
      goto LAB_0057f372;
    }
    ppppuVar9 = apppuStack_40;
    if (0xf < uVar11) {
      ppppuVar9 = (undefined4 ****)pppuVar3;
    }
    cVar4 = FUN_0055c360(ppppuVar9,uVar5,"Thumbnail",9);
    if (cVar4 == '\0') {
      ppppuVar9 = apppuStack_40;
      if (0xf < uVar11) {
        ppppuVar9 = (undefined4 ****)pppuVar3;
      }
      cVar4 = FUN_0055c360(ppppuVar9,uVar5,"ExecuteScript",0xd);
      if (cVar4 == '\0') {
        ppppuVar9 = apppuStack_40;
        if (0xf < uVar11) {
          ppppuVar9 = (undefined4 ****)pppuVar3;
        }
        cVar4 = FUN_0055c360(ppppuVar9,uVar5,"ServerAction",0xc);
        uVar15 = param_2;
        if (cVar4 == '\0') {
          ppppuVar9 = apppuStack_40;
          if (0xf < uVar11) {
            ppppuVar9 = (undefined4 ****)pppuVar3;
          }
          cVar4 = FUN_0055c360(ppppuVar9,uVar5,"SetLimits",9);
          if (cVar4 == '\0') {
            ppppuVar9 = apppuStack_40;
            if (0xf < uVar11) {
              ppppuVar9 = (undefined4 ****)pppuVar3;
            }
            cVar4 = FUN_0055c360(ppppuVar9,uVar5,"RunMicroProfiler",0x10);
            if (cVar4 == '\0') {
                    /* WARNING: Subroutine does not return */
              FUN_016757c0("Execute cannot handle this mode");
            }
            if (DAT_01e90d59 != '\0') {
              FUN_01677520(DAT_01e90d59,"Soap Microprofiling request received");
            }
            if (DAT_01d59340 != '\0') {
              if (DAT_01e90d59 != '\0') {
                FUN_01677520(DAT_01e90d59,"Soap Microprofiling Fast Flag set");
              }
              FUN_00584ab0(&uStack_28);
            }
            param_3 = FUN_01674e20(0xc);
            uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
          }
          else {
            if (DAT_01d59036 != '\0') {
              FUN_01677520(DAT_01d59036,"SetLimits SOAP request received");
            }
            FUN_00584e10(&uStack_28);
            param_3 = FUN_01674e20(0xc);
            uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
          }
        }
        else {
          param_3 = param_3 & 0xffffff;
          FUN_00583b80(&uStack_28,param_2,&uStack_48,(int)&param_3 + 3);
          if (param_3._3_1_ != '\0') {
            FUN_0057ad10(uVar15,0);
            FUN_00556200("Requesting RCC shutdown");
            FUN_00556240();
          }
          param_3 = FUN_01674e20(0xc);
          uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
        }
      }
      else {
        if (DAT_01d59310 == '\0') {
          FUN_00557fc0(&iStack_58);
          uVar5 = FUN_00582e90(&uStack_18,&uStack_28,&uStack_48,apppuStack_70);
          FUN_005587e0(uVar5);
          FUN_00550b30();
          goto LAB_0057f65f;
        }
        param_3 = FUN_01674e20(0xc);
        uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
      }
LAB_0057f62c:
      uVar11 = param_3;
      if (param_3 == 0) {
        uVar11 = 0;
      }
      else {
        FUN_00569550(0,(int)&param_2 + 3);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,10);
      puVar10 = (undefined4 *)FUN_00557ff0(uVar11);
      goto LAB_0057f64e;
    }
    if (DAT_01d59308 != '\0') {
      param_3 = FUN_01674e20(0xc);
      uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
      goto LAB_0057f62c;
    }
    FUN_00557fc0(&iStack_58);
    uVar5 = FUN_005850b0(&uStack_18,&uStack_28,&uStack_48,apppuStack_70);
    FUN_005587e0(uVar5);
    FUN_00550b30();
  }
  else {
    FUN_00583f30(&uStack_28,param_2,auStack_98,&uStack_48);
    uVar11 = FUN_01674e20(0xc);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
LAB_0057f372:
    param_3 = uVar11;
    if (uVar11 == 0) {
      uVar11 = 0;
    }
    else {
      FUN_00569550(0,(int)&param_2 + 3);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    uStack_18 = 0;
    uStack_14 = 0;
    FUN_0055ba30(uVar11,param_2);
    puVar10 = &uStack_18;
LAB_0057f64e:
    FUN_005587e0(puVar10);
    FUN_00550b30();
  }
LAB_0057f65f:
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  FUN_005507b0();
  piVar6 = piStack_1c;
LAB_0057f66e:
  puVar1 = puStack_20;
  FUN_0055b820((int)(puStack_20[1] - *puStack_20) / 0xd0,param_4);
  uVar13 = 0;
  uVar11 = (int)(puVar1[1] - *puVar1) / 0xd0;
  if (uVar11 != 0) {
    iVar12 = 0;
    do {
      uVar5 = FUN_005a8830(param_5,0xffffffff);
      *(undefined4 *)(*param_4 + uVar13 * 4) = uVar5;
      FUN_0057bc30(*puVar1 + iVar12,*(undefined4 *)(*param_4 + uVar13 * 4),param_5);
      uVar13 = uVar13 + 1;
      iVar12 = iVar12 + 0xd0;
      uVar11 = (int)(puVar1[1] - *puVar1) / 0xd0;
      piVar6 = piStack_1c;
    } while (uVar13 < uVar11);
  }
  piVar2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_24 + 1);
    uVar13 = *puVar1;
    uVar11 = *puVar1;
    *puVar1 = uVar13 - 1;
    UNLOCK();
    if (uVar13 - 1 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      puVar1 = (uint *)(piVar2 + 2);
      uVar13 = *puVar1;
      uVar11 = *puVar1;
      *puVar1 = uVar13 - 1;
      UNLOCK();
      if (uVar13 - 1 == 0) {
        uVar11 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piVar6 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar6 + 1);
    uVar13 = *puVar1;
    uVar11 = *puVar1;
    *puVar1 = uVar13 - 1;
    UNLOCK();
    if (uVar13 - 1 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      puVar1 = (uint *)(piVar6 + 2);
      uVar13 = *puVar1;
      uVar11 = *puVar1;
      *puVar1 = uVar13 - 1;
      UNLOCK();
      if (uVar13 - 1 == 0) {
        uVar11 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  piVar6 = piStack_4c;
  if (piStack_4c != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_4c + 1);
    uVar13 = *puVar1;
    uVar11 = *puVar1;
    *puVar1 = uVar13 - 1;
    UNLOCK();
    if (uVar13 - 1 == 0) {
      (**(code **)*piStack_4c)();
      LOCK();
      puVar1 = (uint *)(piVar6 + 2);
      uVar13 = *puVar1;
      uVar11 = *puVar1;
      *puVar1 = uVar13 - 1;
      UNLOCK();
      if (uVar13 - 1 == 0) {
        uVar11 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  piVar6 = piStack_50;
  if (piStack_50 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_50 + 1);
    uVar13 = *puVar1;
    uVar11 = *puVar1;
    *puVar1 = uVar13 - 1;
    UNLOCK();
    if (uVar13 - 1 == 0) {
      uVar11 = (**(code **)*piStack_50)();
      LOCK();
      piVar2 = piVar6 + 2;
      iVar12 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar12 == 1) {
        uVar11 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  if (0xf < uStack_5c) {
    uVar11 = uStack_5c + 1;
    ppppuVar9 = (undefined4 ****)apppuStack_70[0];
    if (0xfff < uVar11) {
      ppppuVar9 = (undefined4 ****)apppuStack_70[0][-1];
      uVar11 = uStack_5c + 0x24;
      if (0x1f < (uint)((int)apppuStack_70[0] + (-4 - (int)ppppuVar9))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uVar11 = FUN_01674ea0(ppppuVar9,uVar11);
  }
  ExceptionList = pvStack_10;
  return uVar11;
}



/* FUNCTION 3913 ; VA 0x0057f8e0 ; FUN_0057f8e0 */

int FUN_0057f8e0(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
                undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  undefined **ppuVar6;
  undefined4 auStack_80 [2];
  undefined auStack_78 [8];
  undefined4 uStack_70;
  undefined4 uStack_6c;
  int *piStack_68;
  undefined *puStack_64;
  undefined **ppuStack_60;
  undefined auStack_58 [4];
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined auStack_34 [28];
  undefined4 *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795ed8;
  pvStack_10 = ExceptionList;
  uStack_44 = 0;
  uStack_48 = 0;
  uStack_4c = 0;
  uStack_50 = 8;
  uStack_8 = 0;
  uStack_54 = 0x57f915;
  ExceptionList = &pvStack_10;
  FUN_01255470();
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  piStack_14 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  ppuStack_60 = (undefined **)0x0;
  piVar1 = param_3 + 1;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puStack_64 = auStack_58;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  ppuVar6 = &PTR_FUN_018c0c58;
  uStack_6c = param_2;
  piStack_68 = param_3;
  uStack_70 = 0x57f979;
  cVar4 = FUN_0055c750();
  if (cVar4 == '\0') {
    ppuVar6 = (undefined **)0x0;
  }
  ppuStack_60 = ppuVar6;
  if (param_3 != (int *)0x0) {
    piVar1 = param_3 + 1;
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      puStack_64 = (undefined *)0x57f99a;
      (**(code **)*param_3)();
      LOCK();
      iVar5 = param_3[2] + -1;
      param_3[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        puStack_64 = (undefined *)0x57f9aa;
        (**(code **)(*param_3 + 4))();
      }
    }
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      puStack_64 = (undefined *)0x57f9b8;
      (**(code **)*param_3)();
      LOCK();
      iVar5 = param_3[2] + -1;
      param_3[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        puStack_64 = (undefined *)0x57f9c8;
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  piVar1 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_14[1] + -1;
    piStack_14[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      puStack_64 = (undefined *)0x57f9de;
      (**(code **)*piStack_14)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar5 = *piVar2 + -1;
      *piVar2 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        puStack_64 = (undefined *)0x57f9ee;
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  puStack_18 = auStack_80;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  piStack_14 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  auStack_80[0] = 0;
  piVar1 = param_3 + 1;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  ppuVar6 = &PTR_FUN_018c0c50;
  cVar4 = FUN_0055c750(param_2,param_3,auStack_78);
  if (cVar4 == '\0') {
    ppuVar6 = (undefined **)0x0;
  }
  *puStack_18 = ppuVar6;
  if (param_3 != (int *)0x0) {
    piVar1 = param_3 + 1;
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar5 = param_3[2] + -1;
      param_3[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar5 = param_3[2] + -1;
      param_3[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  piVar1 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_14[1] + -1;
    piStack_14[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar5 = *piVar2 + -1;
      *piVar2 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  iVar5 = FUN_0094ade0(auStack_34,param_4,param_5,param_6);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar3 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      uStack_44 = 0x57faf5;
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        uStack_44 = 0x57fb04;
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 3914 ; VA 0x0057fb20 ; FUN_0057fb20 */

undefined4 FUN_0057fb20(int param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  undefined auStack_4c [16];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  int aiStack_1c [3];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795f08;
  pvStack_10 = ExceptionList;
  if ((DAT_01d593a0 != '\0') && (param_1 == 0 && param_2 == 0)) {
    ExceptionList = &pvStack_10;
    if (DAT_01d59037 != '\0') {
      ExceptionList = &pvStack_10;
      FUN_016774b0(DAT_01d59037,
                   "Error. externalAntiCheatModuleCallback was called with userId of 0!",0);
    }
    uStack_3c = 0;
    uStack_38 = 0xf;
    auStack_4c[0] = 0;
    FUN_005542c0("ExternalAntiCheat_Errors_All,ExternalAntiCheat_Errors_SecurityCallbackFailed",0x4c
                );
    uStack_8 = 0;
    FUN_00878480(auStack_4c,0);
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return 1;
  }
  aiStack_1c[0] = 0;
  aiStack_1c[1] = 0;
  aiStack_1c[2] = 0;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_0055b6c0(param_4,aiStack_1c);
  FUN_0170c6f0(aiStack_1c[0],param_3,param_4);
  if (DAT_01d59037 != '\0') {
    FUN_01677520(DAT_01d59037,"Got anticheat callback for player ID %lld.",param_1,param_2);
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  FUN_005542c0("ExternalAntiCheat_Successful_Callback",0x25);
  uStack_8._0_1_ = 2;
  FUN_008783f0(auStack_34,1,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < uStack_20) {
    uVar3 = uStack_20 + 1;
    uVar2 = auStack_34[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_34[0] - 4);
      uVar3 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uVar1 = FUN_00578850(param_1,param_2,aiStack_1c);
  if (aiStack_1c[0] != 0) {
    uVar2 = aiStack_1c[2] - aiStack_1c[0];
    iVar4 = aiStack_1c[0];
    if (0xfff < uVar2) {
      iVar4 = *(int *)(aiStack_1c[0] + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (aiStack_1c[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar2);
  }
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 3915 ; VA 0x0057fcf0 ; FUN_0057fcf0 */

undefined4 __fastcall FUN_0057fcf0(int param_1)

{
  char cVar1;
  undefined4 ****ppppuVar2;
  undefined4 ****ppppuVar3;
  int iVar4;
  uint uVar5;
  undefined4 ****ppppuVar6;
  int iStack_84;
  uint uStack_70;
  int iStack_50;
  uint uStack_3c;
  undefined4 ***apppuStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795f33;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff58;
  uStack_1c = 0;
  uStack_18 = 0xf;
  apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  FUN_014cc090(param_1 + 4,0,0);
  uStack_8._0_1_ = 2;
  FUN_014cd0a0(apppuStack_2c,0,0);
  ppppuVar6 = (undefined4 ****)(param_1 + 0x1c);
  ppppuVar3 = ppppuVar6;
  if (0xf < *(uint *)(param_1 + 0x30)) {
    ppppuVar3 = (undefined4 ****)*ppppuVar6;
  }
  ppppuVar2 = apppuStack_2c;
  if (0xf < uStack_18) {
    ppppuVar2 = (undefined4 ****)apppuStack_2c[0];
  }
  cVar1 = FUN_0055c360(ppppuVar2,uStack_1c,ppppuVar3,*(undefined4 *)(param_1 + 0x2c));
  if (cVar1 == '\0') {
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (0xf < uStack_3c) {
      uVar5 = uStack_3c + 1;
      iVar4 = iStack_50;
      if (0xfff < uVar5) {
        iVar4 = *(int *)(iStack_50 + -4);
        uVar5 = uStack_3c + 0x24;
        if (0x1f < (iStack_50 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar5);
    }
    FUN_0056cfd0();
    if (0xf < uStack_70) {
      uVar5 = uStack_70 + 1;
      iVar4 = iStack_84;
      if (0xfff < uVar5) {
        iVar4 = *(int *)(iStack_84 + -4);
        uVar5 = uStack_70 + 0x24;
        if (0x1f < (iStack_84 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar5);
    }
    uStack_8 = 0;
    if (ppppuVar6 != apppuStack_2c) {
      ppppuVar3 = apppuStack_2c;
      if (0xf < uStack_18) {
        ppppuVar3 = (undefined4 ****)apppuStack_2c[0];
      }
      FUN_005542c0(ppppuVar3,uStack_1c);
    }
    if (0xf < uStack_18) {
      uVar5 = uStack_18 + 1;
      ppppuVar3 = (undefined4 ****)apppuStack_2c[0];
      if (0xfff < uVar5) {
        ppppuVar3 = (undefined4 ****)apppuStack_2c[0][-1];
        uVar5 = uStack_18 + 0x24;
        if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar3,uVar5);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  if (0xf < uStack_3c) {
    uVar5 = uStack_3c + 1;
    iVar4 = iStack_50;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iStack_50 + -4);
      uVar5 = uStack_3c + 0x24;
      if (0x1f < (iStack_50 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  FUN_0056cfd0();
  if (0xf < uStack_70) {
    uVar5 = uStack_70 + 1;
    iVar4 = iStack_84;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iStack_84 + -4);
      uVar5 = uStack_70 + 0x24;
      if (0x1f < (iStack_84 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  if (0xf < uStack_18) {
    uVar5 = uStack_18 + 1;
    ppppuVar3 = (undefined4 ****)apppuStack_2c[0];
    if (0xfff < uVar5) {
      ppppuVar3 = (undefined4 ****)apppuStack_2c[0][-1];
      uVar5 = uStack_18 + 0x24;
      if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar3,uVar5);
    ExceptionList = pvStack_10;
    return 0;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3916 ; VA 0x0057ff5a ; Catch@0057ff5a */

undefined * Catch_0057ff5a(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  int unaff_EBP;
  
  if (DAT_01d59104 != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x30) + 4))();
    puVar2 = (undefined4 *)(*(int *)(unaff_EBP + -0x2c) + 4);
    if (0xf < *(uint *)(*(int *)(unaff_EBP + -0x2c) + 0x18)) {
      puVar2 = (undefined4 *)*puVar2;
    }
    FUN_01677520(DAT_01d59104,"SecurityDataUpdater failed to fetch data from %s, %s",puVar2,uVar1);
  }
  return &DAT_0057ff96;
}



/* FUNCTION 3917 ; VA 0x0057ffd0 ; FUN_0057ffd0 */

void FUN_0057ffd0(void)

{
  int iVar1;
  char cVar2;
  
  FUN_00556200("Finalizing RCC handler");
  cVar2 = DAT_01d59350;
  if (DAT_01d59348 != '\0') {
    cVar2 = FUN_005df310(*(undefined *)(DAT_01ea84c0 + 0xac));
  }
  if (cVar2 != '\0') {
    FUN_0058be30();
  }
  iVar1 = DAT_01ea84c0;
  DAT_01ea84c0 = 0;
  if (iVar1 != 0) {
    FUN_0056d630();
    FUN_01674ea0(iVar1,0xe8);
  }
  FUN_005c9c90();
  return;
}



/* FUNCTION 3918 ; VA 0x00580040 ; FUN_00580040 */

void __thiscall FUN_00580040(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  uint uVar1;
  char cVar2;
  uint uVar3;
  int *piVar4;
  undefined4 *puVar5;
  uint uVar6;
  int *piVar7;
  
  uVar3 = FUN_005702d0(param_3);
  uVar1 = *(uint *)(param_1 + 4);
  uVar6 = uVar3 % uVar1;
  if (*(int *)(param_1 + 8) == 0) {
    piVar7 = (int *)0x0;
  }
  else {
    puVar5 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    if (puVar5 == (undefined4 *)0x0) {
      piVar7 = (int *)0x0;
    }
    else {
      piVar7 = (int *)*puVar5;
    }
    if (piVar7 != (int *)0x0) {
      do {
        if (uVar3 == piVar7[1]) {
          piVar4 = piVar7 + 2;
          if (0xf < (uint)piVar7[7]) {
            piVar4 = (int *)*piVar4;
          }
          puVar5 = param_3;
          if (0xf < (uint)param_3[5]) {
            puVar5 = (undefined4 *)*param_3;
          }
          cVar2 = FUN_0055c360(puVar5,param_3[4],piVar4,piVar7[6]);
          if (cVar2 != '\0') break;
        }
        else if ((uint)piVar7[1] % uVar1 != uVar6) {
          *param_2 = 0;
          return;
        }
        piVar7 = (int *)*piVar7;
        if (piVar7 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar7;
  return;
}



/* FUNCTION 3919 ; VA 0x00580100 ; FUN_00580100 */

/* WARNING: Type propagation algorithm not settling */

void FUN_00580100(undefined4 param_1,undefined4 param_2,uint param_3,uint param_4,int param_5,
                 undefined4 param_6,double param_7)

{
  char cVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined4 *******pppppppuVar4;
  undefined4 uVar5;
  double *pdVar6;
  int iVar7;
  int *piVar8;
  longlong lVar9;
  undefined8 uVar10;
  undefined8 uVar11;
  undefined auStack_284 [224];
  undefined auStack_1a4 [24];
  undefined auStack_18c [24];
  int iStack_174;
  uint uStack_170;
  uint uStack_16c;
  undefined8 uStack_168;
  undefined4 uStack_160;
  undefined8 uStack_158;
  undefined4 uStack_14c;
  undefined *puStack_148;
  uint uStack_144;
  uint uStack_140;
  uint uStack_13c;
  uint uStack_138;
  undefined8 uStack_134;
  undefined8 uStack_128;
  undefined4 uStack_120;
  uint uStack_11c;
  undefined8 uStack_110;
  int *piStack_108;
  undefined4 *puStack_104;
  double dStack_100;
  undefined8 uStack_f8;
  int *piStack_f0;
  undefined4 *puStack_ec;
  undefined4 uStack_e8;
  double dStack_e0;
  int iStack_d8;
  undefined auStack_d4 [16];
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined **ppuStack_bc;
  int *piStack_b8;
  undefined4 *puStack_b4;
  undefined4 *puStack_b0;
  undefined4 *apuStack_ac [5];
  undefined ***pppuStack_98;
  undefined4 *******apppppppuStack_94 [5];
  uint uStack_80;
  undefined4 uStack_74;
  int *piStack_70;
  undefined8 uStack_6c;
  undefined8 uStack_64;
  undefined4 *puStack_5c;
  undefined4 *puStack_58;
  undefined4 *puStack_54;
  undefined4 *puStack_50;
  int *piStack_4c;
  int *piStack_48;
  uint *puStack_44;
  uint *puStack_40;
  undefined auStack_3c [16];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796134;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffd70;
  uStack_64._4_4_ = (undefined4 *)0x0;
  ExceptionList = &pvStack_10;
  iStack_174 = FUN_0151ac40();
  if (iStack_174 == 0) {
    iStack_d8 = iStack_174;
    iStack_174 = FUN_0151ac60();
  }
  iStack_d8 = iStack_174;
  if (iStack_174 != 0) {
    FUN_0151ab60(iStack_174);
  }
  uStack_8 = 0;
  uStack_e8 = FUN_01675290(DAT_01e90d74);
  uStack_8._0_1_ = 2;
  if (DAT_01d59104 != '\0') {
    FUN_01677520(DAT_01d59104,"Fetching place %lld",param_3,param_4);
  }
  PTR_DAT_01d7a63c = s_SetupGame_018bdea0;
  if (((int)param_4 < 1) && (((int)param_4 < 0 || (param_3 == 0)))) {
    FUN_016756b0();
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8();
  }
  if (*(int *)(param_5 + 0x10) == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("PlaceFetchUrl missing or empty");
  }
  puStack_40 = (uint *)FUN_01674e20(0x24);
  uStack_1c = (double)CONCAT44(puStack_40,(undefined4)uStack_1c);
  if (puStack_40 == (undefined4 *)0x0) {
    puStack_40 = (undefined4 *)0x0;
  }
  else {
    puStack_40[1] = 1;
    puStack_40[2] = 1;
    *puStack_40 = (uint)std::
                        _Ref_count_obj<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                        ::vftable;
    puStack_40[7] = 0;
    puStack_40[8] = 0xf;
    *(undefined *)(puStack_40 + 3) = 0;
  }
  piStack_108 = (int *)(puStack_40 + 3);
  uStack_8._0_1_ = 3;
  puStack_104 = puStack_40;
  FUN_014c9d60();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  puVar2 = &DAT_01d79e78;
  if (0xf < DAT_01d79e8c) {
    puVar2 = DAT_01d79e78;
  }
  FUN_014cb8a0(puVar2,DAT_01d79e88,"Place",5);
  FUN_014cbbc0();
  FUN_014cb890(0);
  if (DAT_01d593d0 != '\0') {
    FUN_0146d260(DAT_01d59184 * 1000);
  }
  uStack_64._4_4_ = (undefined4 *)FUN_01674e20(0x18);
  uStack_1c = (double)CONCAT44(uStack_64._4_4_,(undefined4)uStack_1c);
  if (uStack_64._4_4_ == (undefined4 *)0x0) {
    uStack_64._4_4_ = (undefined4 *)0x0;
  }
  else {
    uStack_64._4_4_[1] = 1;
    uStack_64._4_4_[2] = 1;
    *uStack_64._4_4_ =
         std::
         _Ref_count_obj<class_boost::promise<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>
         ::vftable;
    uStack_64._4_4_[3] = 0;
    uStack_64._4_4_[4] = 0;
    *(undefined *)(uStack_64._4_4_ + 5) = 0;
  }
  piStack_f0 = uStack_64._4_4_ + 3;
  piStack_70 = (int *)0x3;
  uStack_8._0_1_ = 5;
  puStack_ec = uStack_64._4_4_;
  if ((DAT_01d593d8 == '\0') && (DAT_01d593e0 == '\0')) {
    if (uStack_64._4_4_ != (undefined4 *)0x0) {
      LOCK();
      uStack_64._4_4_[1] = uStack_64._4_4_[1] + 1;
      UNLOCK();
    }
    if (puStack_40 != (undefined4 *)0x0) {
      LOCK();
      puStack_40[1] = puStack_40[1] + 1;
      UNLOCK();
    }
    puStack_b0 = puStack_40 + 3;
    pppuStack_98 = &ppuStack_bc;
    apuStack_ac[0] = puStack_40;
    ppuStack_bc = std::
                  _Func_impl_no_alloc<class_<lambda_02fa2349d2109e7fb76f34aa9c25047c>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
                  ::vftable;
    uStack_24 = 0;
    uStack_20 = 0;
    uStack_1c = 0.0;
    piStack_b8 = piStack_f0;
    puStack_b4 = uStack_64._4_4_;
    FUN_0056b650();
    uStack_8._0_1_ = 8;
    FUN_014cb530(&ppuStack_bc);
    uStack_8._0_1_ = 5;
    piVar8 = (int *)0x3;
    if (pppuStack_98 != (undefined ***)0x0) {
      (*(code *)(*pppuStack_98)[4])
                (CONCAT31((int3)((uint)&ppuStack_bc >> 8),pppuStack_98 != &ppuStack_bc));
    }
  }
  else {
    piVar3 = (int *)FUN_01674e20(0x10);
    if (piVar3 == (int *)0x0) {
      piVar3 = (int *)0x0;
    }
    else {
      piVar3[1] = 1;
      piVar3[2] = 1;
      *piVar3 = (int)std::_Ref_count_obj<int>::vftable;
      piVar3[3] = 0;
    }
    piStack_4c = piVar3 + 3;
    piStack_70 = (int *)&DAT_00000007;
    uStack_1c = (double)CONCAT44(piVar3,piStack_4c);
    if (uStack_64._4_4_ != (undefined4 *)0x0) {
      LOCK();
      uStack_64._4_4_[1] = uStack_64._4_4_[1] + 1;
      UNLOCK();
    }
    puStack_5c = uStack_64._4_4_ + 3;
    puStack_58 = uStack_64._4_4_;
    if (puStack_40 != (undefined4 *)0x0) {
      LOCK();
      puStack_40[1] = puStack_40[1] + 1;
      UNLOCK();
    }
    puStack_50 = puStack_40;
    puStack_54 = puStack_40 + 3;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar3[1] = piVar3[1] + 1;
      UNLOCK();
    }
    pppuStack_98 = (undefined ***)0x0;
    piStack_48 = piVar3;
    pppuStack_98 = (undefined ***)FUN_00558020(&puStack_5c);
    FUN_0056b6b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_014cb530(&ppuStack_bc);
    if (pppuStack_98 != (undefined ***)0x0) {
      (*(code *)(*pppuStack_98)[4])
                (CONCAT31((int3)((uint)&ppuStack_bc >> 8),pppuStack_98 != &ppuStack_bc));
    }
    uStack_8._0_1_ = 5;
    piVar8 = piStack_70;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar7 = piVar3[1] + -1;
      piVar3[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar7 = piVar3[2] + -1;
        piVar3[2] = iVar7;
        UNLOCK();
        piVar8 = piStack_70;
        if (iVar7 == 0) {
          (**(code **)(*piVar3 + 4))();
          piVar8 = piStack_70;
        }
      }
    }
  }
  piVar3 = piStack_f0;
  uStack_1c = (double)CONCAT44(piVar8,(undefined4)uStack_1c);
  FUN_005863d0();
  uStack_6c = (double)CONCAT44(*piVar3,(undefined4)uStack_6c);
  if (*piVar3 == 0) {
    uVar5 = FUN_0056b1c0();
    uStack_8._0_1_ = 9;
    FUN_00564a30(uVar5);
  }
  else if (*(char *)(piVar3 + 2) == '\0') {
    *(undefined *)(piVar3 + 2) = 1;
    piVar8 = (int *)piVar3[1];
    piVar3 = piVar8 + 1;
    if (piVar8 != (int *)0x0) {
      LOCK();
      *piVar3 = *piVar3 + 1;
      UNLOCK();
      if (piVar8 != (int *)0x0) {
        LOCK();
        *piVar3 = *piVar3 + 1;
        UNLOCK();
        if (piVar8 != (int *)0x0) {
          LOCK();
          *piVar3 = *piVar3 + 1;
          UNLOCK();
        }
      }
    }
    uStack_8._0_1_ = 0xb;
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar7 = *piVar3;
      *piVar3 = iVar7 + -1;
      UNLOCK();
      if (iVar7 + -1 == 0) {
        (**(code **)(*piVar8 + 4))();
        LOCK();
        iVar7 = piVar8[2] + -1;
        piVar8[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar8 + 8))();
        }
      }
    }
    uStack_8._0_1_ = 0xc;
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar7 = piVar8[1] + -1;
      piVar8[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar8 + 4))();
        LOCK();
        iVar7 = piVar8[2] + -1;
        piVar8[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar8 + 8))();
        }
      }
    }
    piVar3 = piVar8 + 1;
    uStack_64._4_4_ = (undefined4 *)((uint)piStack_70 | 8);
    uStack_74 = uStack_6c._4_4_;
    if (piVar8 != (int *)0x0) {
      LOCK();
      *piVar3 = *piVar3 + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 0xd;
    piStack_70 = piVar8;
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar7 = *piVar3;
      *piVar3 = iVar7 + -1;
      UNLOCK();
      if (iVar7 + -1 == 0) {
        (**(code **)(*piVar8 + 4))();
        LOCK();
        iVar7 = piVar8[2] + -1;
        piVar8[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar8 + 8))();
        }
      }
    }
    uStack_8._0_1_ = 0xe;
    FUN_01682800(&dStack_e0);
    FUN_005f5740();
    uStack_170 = param_3;
    uStack_8._0_1_ = 0x10;
    uStack_16c = param_4;
    piStack_4c = (int *)0x0;
    piStack_48 = (int *)0xf;
    puStack_5c = (undefined4 *)((uint)puStack_5c & 0xffffff00);
    FUN_005542c0();
    uStack_8._0_1_ = 0x11;
    uStack_168 = FUN_005638c0();
    uStack_8._0_1_ = 0x10;
    FUN_005507b0();
    piStack_4c = (int *)0x0;
    piStack_48 = (int *)0xf;
    puStack_5c = (undefined4 *)((uint)puStack_5c & 0xffffff00);
    FUN_005542c0();
    uStack_8._0_1_ = 0x12;
    uStack_160 = FUN_00563a70();
    uStack_8._0_1_ = 0x10;
    FUN_005507b0();
    piStack_4c = (int *)0x0;
    piStack_48 = (int *)0xf;
    puStack_5c = (undefined4 *)((uint)puStack_5c & 0xffffff00);
    FUN_005542c0();
    uStack_8._0_1_ = 0x13;
    uStack_158 = FUN_005638c0();
    uStack_8._0_1_ = 0x10;
    FUN_005507b0();
    piStack_4c = (int *)0x0;
    piStack_48 = (int *)&DAT_0000000f;
    puStack_5c = (undefined4 *)((uint)puStack_5c & 0xffffff00);
    FUN_005542c0();
    uStack_8._0_1_ = 0x14;
    FUN_00563af0(auStack_1a4,param_6,&puStack_5c);
    uStack_8._0_1_ = 0x16;
    FUN_005507b0();
    cVar1 = FUN_008f1d90();
    if (cVar1 != '\0') {
      uStack_c4 = 0;
      uStack_c0 = 0xf;
      auStack_d4[0] = 0;
      FUN_005542c0();
      uStack_8._0_1_ = 0x17;
      uStack_14c = FUN_00563a70();
      uStack_8._0_1_ = 0x16;
      FUN_005507b0();
      uStack_2c = 0;
      uStack_28 = 0xf;
      auStack_3c[0] = 0;
      FUN_005542c0();
      uStack_8._0_1_ = 0x18;
      uStack_c4 = 0;
      uStack_c0 = 0xf;
      auStack_d4[0] = 0;
      FUN_005542c0();
      uStack_8 = CONCAT31(uStack_8._1_3_,0x1a);
      puStack_40 = (uint *)FUN_0054ef60(auStack_3c);
      uStack_64 = CONCAT44(uStack_1c._4_4_,(undefined4)uStack_64) | 0x1800000000;
      FUN_00563920(param_6,auStack_d4,apuStack_ac);
      if (&uStack_144 != puStack_40) {
        FUN_005507b0();
        uStack_144 = *puStack_40;
        uStack_140 = puStack_40[1];
        uStack_13c = puStack_40[2];
        uStack_138 = puStack_40[3];
        uStack_134 = *(undefined8 *)(puStack_40 + 4);
        puStack_40[4] = 0;
        puStack_40[5] = 0xf;
        *(undefined *)puStack_40 = 0;
      }
      FUN_005507b0();
      FUN_005507b0();
      uStack_8._0_1_ = 0x16;
      FUN_005507b0();
      uStack_1c = (double)((ulonglong)uStack_1c & 0xffffffff);
      uStack_2c = 0;
      uStack_28 = 0xf;
      auStack_3c[0] = 0;
      FUN_005542c0();
      uStack_8._0_1_ = 0x1b;
      uStack_120 = FUN_005639a0(param_6,auStack_3c,(int)&uStack_1c + 4);
      uStack_8._0_1_ = 0x16;
      FUN_005507b0();
      uStack_2c = 0;
      uStack_28 = 0xf;
      auStack_3c[0] = 0;
      FUN_005542c0();
      uStack_8 = CONCAT31(uStack_8._1_3_,0x1c);
      uStack_64 = 0;
      FUN_00580040();
      uStack_128 = uStack_64;
      if ((uStack_1c._4_4_ != (uint *)0x0) &&
         (*(char *)(*(int *)((int)uStack_1c._4_4_ + 0x20) + 0x21) != '\0')) {
        uStack_128 = FUN_00563790();
      }
      uStack_8._0_1_ = 0x16;
      FUN_005507b0();
      uStack_1c = (double)CONCAT44(0xffffffff,(undefined4)uStack_1c);
      uStack_2c = 0;
      uStack_28 = 0xf;
      auStack_3c[0] = 0;
      FUN_005542c0();
      uStack_8._0_1_ = 0x1d;
      uStack_11c = FUN_005639a0(param_6,auStack_3c,(int)&uStack_1c + 4);
      uStack_8._0_1_ = 0x16;
      FUN_005507b0();
      DAT_01f6e9ec = uStack_11c;
      uStack_c4 = 0;
      uStack_c0 = 0xf;
      auStack_d4[0] = 0;
      FUN_005542c0();
      uStack_8._0_1_ = 0x1e;
      uStack_2c = 0;
      uStack_28 = 0xf;
      auStack_3c[0] = 0;
      FUN_005542c0();
      uStack_8._0_1_ = 0x1f;
      FUN_00563a00(apppppppuStack_94,param_6,auStack_3c,auStack_d4);
      FUN_005507b0();
      uStack_8._0_1_ = 0x22;
      FUN_005507b0();
      pppppppuVar4 = apppppppuStack_94;
      if (0xf < uStack_80) {
        pppppppuVar4 = apppppppuStack_94[0];
      }
      FUN_0151aae0(pppppppuVar4);
      uStack_1c = (double)((ulonglong)uStack_1c & 0xffffffff);
      piStack_4c = (int *)0x0;
      piStack_48 = (int *)0xf;
      puStack_5c = (undefined4 *)((uint)puStack_5c & 0xffffff00);
      FUN_005542c0();
      uStack_8._0_1_ = 0x23;
      DAT_01f6e614 = FUN_005639a0(param_6,&puStack_5c,(int)&uStack_1c + 4);
      uStack_8._0_1_ = 0x22;
      FUN_005507b0();
      DAT_01d7a884 = uStack_11c;
      if (uStack_6c._4_4_ == (int *)0x0) {
        uVar5 = FUN_0056acb0();
        uStack_8._0_1_ = 0x24;
        FUN_00564940(uVar5);
LAB_00581473:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar5 = (**(code **)(*uStack_6c._4_4_ + 0x14))();
      FUN_00565000(uVar5,1,1);
      puStack_148 = auStack_284;
      uStack_8._0_1_ = 0x25;
      pdVar6 = (double *)FUN_01682800(&uStack_1c);
      uStack_1c = *pdVar6 - dStack_e0;
      uStack_2c = 0;
      uStack_28 = 0xf;
      auStack_3c[0] = 0;
      FUN_005542c0();
      uStack_8._0_1_ = 0x26;
      FUN_00878cf0(auStack_3c,uStack_1c,0);
      uStack_8._0_1_ = 0x25;
      FUN_005507b0();
      pdVar6 = (double *)FUN_01682800(&uStack_1c);
      uStack_1c = *pdVar6 - dStack_e0;
      uVar5 = FUN_01675640(apuStack_ac,"GameServerInitialization_FinishPlaceFetch_%d",uStack_11c);
      uStack_8._0_1_ = 0x27;
      FUN_00878cf0(uVar5,uStack_1c,0);
      uStack_8._0_1_ = 0x25;
      FUN_005507b0();
      pdVar6 = (double *)FUN_01682800(&uStack_1c);
      uStack_6c = *pdVar6 - dStack_e0;
      uStack_1c._4_4_ = (uint *)piStack_108;
      piVar3 = piStack_108;
      if (0xf < (uint)piStack_108[5]) {
        piVar3 = (int *)*piStack_108;
      }
      uVar5 = FUN_01675640(apuStack_ac,"GameServerInitialization_FinishPlaceFetch_CDN_%s",piVar3);
      uStack_8._0_1_ = 0x28;
      FUN_00878cf0(uVar5,uStack_6c,0);
      uStack_8._0_1_ = 0x25;
      FUN_005507b0();
      pdVar6 = (double *)FUN_01682800(&uStack_6c);
      uStack_6c = *pdVar6 - dStack_e0;
      piVar3 = (int *)uStack_1c._4_4_;
      if (0xf < (uint)piStack_108[5]) {
        piVar3 = (int *)*piStack_108;
      }
      uVar5 = FUN_01675640(apuStack_ac,"GameServerInitialization_FinishPlaceFetch_CDN_%s_DC_%d",
                           piVar3,uStack_11c);
      uStack_8._0_1_ = 0x29;
      FUN_00878cf0(uVar5,uStack_6c,0);
      uStack_8._0_1_ = 0x25;
      FUN_005507b0();
      if ((DAT_01d648e4 != '\0') && (DAT_01d648fc != '\0')) {
        uStack_1c._0_4_ = FUN_01679ce0();
        uStack_1c._4_4_ = (uint *)0x0;
        FUN_00994da0(&uStack_1c);
        uVar5 = FUN_0058c590(apuStack_ac,uStack_170,uStack_16c);
        uStack_8._0_1_ = 0x2a;
        FUN_00994ed0(uVar5);
        uStack_8._0_1_ = 0x25;
        FUN_005507b0();
      }
      FUN_01682800(&dStack_100);
      FUN_0151f430();
      FUN_008e9480();
      uStack_8._0_1_ = 0x2b;
      if (DAT_01d592f8 != '\0') {
        do {
          lVar9 = FUN_016de945();
          uVar10 = FUN_016f39b0(lVar9 + 10000000,100,0);
          uVar11 = FUN_016f3900(uVar10,1000000000,0);
          piStack_108 = (int *)((int)uVar10 + (int)uVar11 * -1000000000);
          puStack_104 = puStack_ec;
          piStack_f0 = piStack_108;
          uStack_110 = uVar11;
          uStack_f8 = uVar11;
          FUN_016de839(&uStack_110);
        } while( true );
      }
      FUN_01255470(8,0,0,0);
      FUN_01255490();
      uStack_8 = CONCAT31(uStack_8._1_3_,0x2c);
      FUN_005f63e0();
      iVar7 = FUN_00562e40();
      if ((iVar7 != 0) && (*(int *)(iVar7 + 0x104) != 0)) {
        FUN_015225d0();
      }
      if ((DAT_01d59348 != '\0') || (DAT_01d59350 != '\0')) {
        cVar1 = FUN_00586250();
        if (cVar1 != '\0') {
          FUN_00586580(param_2);
        }
      }
      uStack_1c._4_4_ = (uint *)FUN_01674e20(200);
      uStack_64 = CONCAT44(uStack_1c._4_4_,(undefined4)uStack_64);
      uStack_8._0_1_ = 0x2d;
      if (uStack_1c._4_4_ == (uint *)0x0) {
        puStack_40 = (uint *)0x0;
      }
      else {
        uStack_1c._4_4_[1] = 1;
        uStack_1c._4_4_[2] = 1;
        *uStack_1c._4_4_ = (uint)std::_Ref_count_obj<struct_RBX::RCCMonitorSettings>::vftable;
        FUN_005d0bf0();
        puStack_40 = uStack_1c._4_4_;
      }
      puStack_44 = puStack_40 + 4;
      uStack_8._0_1_ = 0x2e;
      FUN_00586960();
      *puStack_44 = param_3;
      puStack_44[1] = param_4;
      puStack_44[0x27] = uStack_11c;
      FUN_0057e8b0();
      FUN_00550b30();
      FUN_01255500();
      uStack_8._0_1_ = 0x25;
      FUN_008eb110();
      pdVar6 = (double *)FUN_01682800(&uStack_1c);
      uStack_1c = *pdVar6 - dStack_100;
      uStack_2c = 0;
      uStack_28 = 0xf;
      auStack_3c[0] = 0;
      FUN_005542c0();
      uStack_8._0_1_ = 0x2f;
      FUN_00878cf0(auStack_3c,uStack_1c,0);
      uStack_8._0_1_ = 0x25;
      FUN_005507b0();
      pdVar6 = (double *)FUN_01682800(&uStack_1c);
      uStack_1c = *pdVar6 - param_7;
      uStack_2c = 0;
      uStack_28 = 0xf;
      auStack_3c[0] = 0;
      FUN_005542c0();
      uStack_8._0_1_ = 0x30;
      FUN_00878cf0(auStack_3c,uStack_1c,0);
      uStack_8._0_1_ = 0x25;
      FUN_005507b0();
      pdVar6 = (double *)FUN_01682800(&uStack_1c);
      uStack_1c = *pdVar6 - dStack_100;
      uVar5 = FUN_01675640(apuStack_ac,"GameServerInitialization_ConfigureAndMonitorScript_%d",
                           uStack_11c);
      uStack_8._0_1_ = 0x31;
      FUN_00878cf0(uVar5,uStack_1c,0);
      uStack_8._0_1_ = 0x25;
      FUN_005507b0();
      pdVar6 = (double *)FUN_01682800(&uStack_1c);
      uStack_1c = *pdVar6 - param_7;
      uVar5 = FUN_01675640(apuStack_ac,"GameServerInitialization_EndToEnd_%d",uStack_11c);
      uStack_8._0_1_ = 0x32;
      FUN_00878cf0(uVar5,uStack_1c,0);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x25);
      FUN_005507b0();
      if (DAT_01d59104 != '\0') {
        FUN_016774b0(DAT_01d59104,&DAT_018c01fc,0);
        if (DAT_01d59104 != '\0') {
          FUN_016774b0(DAT_01d59104,"Finished initializing game",0);
          if (DAT_01d59104 != '\0') {
            FUN_016774b0(DAT_01d59104,&DAT_018c01fc,0);
          }
        }
      }
      PTR_DAT_01d7a63c = s_StartGame_018bdeac;
      FUN_005703e0();
      FUN_005507b0();
      FUN_005507b0();
      uStack_8._0_1_ = 0xe;
      if (0xf < uStack_134._4_4_) {
        if ((0xfff < uStack_134._4_4_ + 1) && (0x1f < (uStack_144 - *(int *)(uStack_144 - 4)) - 4))
        goto LAB_00581473;
        FUN_01674ea0();
      }
      uStack_134 = 0xf00000000;
      uStack_144 = uStack_144 & 0xffffff00;
      uStack_8 = CONCAT31(uStack_8._1_3_,0x33);
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar7 = piVar8[1] + -1;
        piVar8[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar8 + 4))();
          LOCK();
          piVar3 = piVar8 + 2;
          iVar7 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar7 == 1) {
            (**(code **)(*piVar8 + 8))();
          }
        }
      }
      FUN_00550b30();
      FUN_00550b30();
      FUN_00550b30();
      FUN_0058139b();
      return;
    }
    goto LAB_00581430;
  }
  uVar5 = FUN_0056ab30();
  uStack_8._0_1_ = 10;
  FUN_005648f0(uVar5);
LAB_00581430:
  uVar5 = FUN_005543f0();
  FUN_016756b0(auStack_18c,"Failed to convert value to creator type enum: %s",uVar5);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8();
}



/* FUNCTION 3920 ; VA 0x00581150 ; Catch@00581150 */

undefined * Catch_00581150(void)

{
  undefined4 uVar1;
  double *pdVar2;
  int unaff_EBP;
  int *piVar3;
  
  if (DAT_01d59104 != '\0') {
    FUN_016774b0(DAT_01d59104,&DAT_018c01fc,0);
    if (DAT_01d59104 != '\0') {
      piVar3 = *(int **)(unaff_EBP + -0xe0);
      uVar1 = (**(code **)(*piVar3 + 4))();
      FUN_01677520(DAT_01d59104,"Failed to finish initializing game: %s",uVar1);
      if (DAT_01d59104 != '\0') {
        FUN_016774b0(DAT_01d59104,&DAT_018c01fc,0);
      }
      goto LAB_005811be;
    }
  }
  piVar3 = *(int **)(unaff_EBP + -0xe0);
LAB_005811be:
  *(undefined4 *)(unaff_EBP + -0x80) = 0;
  *(undefined4 *)(unaff_EBP + -0x7c) = 0xf;
  *(undefined *)(unaff_EBP + -0x90) = 0;
  FUN_005542c0("GameServerInitialization_Error",0x1e);
  *(undefined *)(unaff_EBP + -4) = 0x35;
  FUN_008783f0(unaff_EBP + -0x90,1,0);
  *(undefined *)(unaff_EBP + -4) = 0x34;
  FUN_005507b0();
  FUN_0151f6f0(0xffffffff,0,0);
  *(undefined *)(unaff_EBP + -4) = 0x36;
  FUN_0151fbb0("RequestedPlaceId",*(undefined4 *)(unaff_EBP + 0x10),
               *(undefined4 *)(unaff_EBP + 0x14));
  uVar1 = (**(code **)(*piVar3 + 4))();
  FUN_0151f850("ErrorMessage",uVar1);
  *(undefined4 *)(unaff_EBP + -0x28) = 0;
  *(undefined4 *)(unaff_EBP + -0x24) = 0xf;
  *(undefined *)(unaff_EBP + -0x38) = 0;
  FUN_005542c0("[not found in request]",0x16);
  *(undefined *)(unaff_EBP + -4) = 0x37;
  *(undefined4 *)(unaff_EBP + -0x80) = 0;
  *(undefined4 *)(unaff_EBP + -0x7c) = 0xf;
  *(undefined *)(unaff_EBP + -0x90) = 0;
  FUN_005542c0("MachineAddress",0xe);
  *(undefined *)(unaff_EBP + -4) = 0x38;
  uVar1 = FUN_00563a00(unaff_EBP + -0xa8,*(undefined4 *)(unaff_EBP + 0x1c),unaff_EBP + -0x90,
                       unaff_EBP + -0x38);
  *(undefined *)(unaff_EBP + -4) = 0x39;
  FUN_0151f950("MachineAddress",uVar1);
  FUN_005507b0();
  FUN_005507b0();
  *(undefined *)(unaff_EBP + -4) = 0x36;
  FUN_005507b0();
  pdVar2 = (double *)FUN_01682800();
  FUN_0151fb00("EndToEndTimerSeconds",*pdVar2 - *(double *)(unaff_EBP + 0x20));
  uVar1 = DAT_01d590dc;
  *(undefined4 *)(unaff_EBP + -0x80) = 0;
  *(undefined4 *)(unaff_EBP + -0x7c) = 0xf;
  *(undefined *)(unaff_EBP + -0x90) = 0;
  FUN_005542c0("GameServerInitializationError",0x1d);
  *(undefined *)(unaff_EBP + -4) = 0x3a;
  FUN_01520d20(unaff_EBP + -0x90,uVar1,0);
  *(undefined *)(unaff_EBP + -4) = 0x36;
  FUN_005507b0();
  FUN_0057ad10(*(undefined4 *)(unaff_EBP + 8),0);
  FUN_0151f7f0();
  return &DAT_00581395;
}



/* FUNCTION 3921 ; VA 0x0058139b ; FUN_0058139b */

void FUN_0058139b(void)

{
  int unaff_EBP;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  *(undefined *)(unaff_EBP + -4) = 0x3b;
  FUN_01675290();
  *(undefined4 *)(unaff_EBP + -4) = 0x3c;
  if (*(int *)(unaff_EBP + -0xd4) != 0) {
    FUN_0151ab30(*(int *)(unaff_EBP + -0xd4));
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 3922 ; VA 0x00581480 ; FUN_00581480 */

int * __fastcall FUN_00581480(int *param_1)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int *piStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796148;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1) != 0) {
    ExceptionList = &pvStack_10;
    FUN_0056b230(param_1);
    uStack_8 = 0;
    if (cStack_14 != '\0') {
      iVar3 = (**(code **)(**(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1) + 0x34))();
      if (iVar3 == -1) {
        FUN_00554460(*(uint *)(*(int *)(*param_1 + 4) + 0xc + (int)param_1) | 4,0);
      }
    }
    uStack_8 = 1;
    cVar2 = thunk_FUN_0170e3b7();
    if (cVar2 == '\0') {
      FUN_00577770();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    piVar1 = *(int **)(*(int *)(*piStack_18 + 4) + 0x38 + (int)piStack_18);
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 8))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3923 ; VA 0x00581530 ; FUN_00581530 */

void FUN_00581530(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = GetProcessHeap(0,param_1);
  HeapFree(uVar1);
  return;
}



/* FUNCTION 3924 ; VA 0x00581550 ; FUN_00581550 */

undefined4 * __thiscall FUN_00581550(int param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796168;
  pvStack_10 = ExceptionList;
  cStack_14 = '\0';
  puStack_18 = (uint *)(param_1 + 0x24);
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uStack_8 = 0;
  FUN_0058cb00(&puStack_18,1);
  puVar2 = *(undefined4 **)(param_1 + 0x88);
  param_2[4] = 0;
  param_2[5] = 0;
  uVar5 = puVar2[1];
  uVar3 = puVar2[2];
  uVar4 = puVar2[3];
  *param_2 = *puVar2;
  param_2[1] = uVar5;
  param_2[2] = uVar3;
  param_2[3] = uVar4;
  *(undefined8 *)(param_2 + 4) = *(undefined8 *)(puVar2 + 4);
  puVar2[4] = 0;
  puVar2[5] = 0xf;
  *(undefined *)puVar2 = 0;
  uStack_8 = 1;
  if (cStack_14 != '\0') {
    LOCK();
    uVar1 = *puStack_18;
    *puStack_18 = *puStack_18 + 0x80000000;
    UNLOCK();
    if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
      LOCK();
      uVar1 = *puStack_18;
      *puStack_18 = *puStack_18 | 0x40000000;
      UNLOCK();
      if ((uVar1 >> 0x1e & 1) == 0) {
        uVar5 = FUN_00554e40();
        SetEvent(uVar5);
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 3925 ; VA 0x00581620 ; FUN_00581620 */

undefined4 * __thiscall FUN_00581620(int param_1,undefined4 *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  piVar1 = (int *)(param_1 + 4);
  iVar2 = FUN_0055b610(param_3);
  if (iVar2 != *piVar1) {
    iVar3 = FUN_0170d8dd(*param_3 + 4,*(int *)(iVar2 + 0x10) + 4);
    if (-1 < iVar3) {
      iVar3 = *piVar1;
      goto LAB_0058165b;
    }
  }
  iVar3 = *piVar1;
  iVar2 = iVar3;
LAB_0058165b:
  if (iVar3 != iVar2) {
    *param_2 = *(undefined4 *)(iVar2 + 0x14);
    iVar2 = *(int *)(iVar2 + 0x18);
    param_2[1] = iVar2;
    if (iVar2 != 0) {
      LOCK();
      *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
      UNLOCK();
    }
    return param_2;
  }
  *param_2 = 0;
  param_2[1] = 0;
  return param_2;
}



/* FUNCTION 3926 ; VA 0x005816a0 ; FUN_005816a0 */

void __thiscall FUN_005816a0(int param_1,int *param_2,undefined4 param_3)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  double *pdVar6;
  undefined4 uVar7;
  int *piVar8;
  undefined auStack_2c [8];
  uint *puStack_24;
  char cStack_20;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796188;
  pvStack_10 = ExceptionList;
  cStack_20 = '\0';
  puStack_24 = (uint *)(param_1 + 0xbc);
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uStack_8 = 0;
  FUN_0055b820(*(undefined4 *)(param_1 + 0xb8),param_2);
  piVar2 = *(int **)(param_1 + 0xb4);
  piStack_18 = (int *)*piVar2;
  if (piStack_18 != piVar2) {
    iStack_14 = 0;
    do {
      piVar5 = piStack_18;
      iStack_1c = FUN_005a8810(param_3,0xffffffff);
      piVar8 = piVar5 + 4;
      iVar3 = piVar5[10];
      pdVar6 = (double *)FUN_01682800(auStack_2c);
      iVar4 = iStack_1c;
      *(double *)(iStack_1c + 0x20) = *(double *)(iVar3 + 0x28) - *pdVar6;
      *(undefined4 *)(iStack_1c + 0x28) = *(undefined4 *)(piVar5[10] + 0x30);
      *(undefined8 *)(iStack_1c + 0x30) = *(undefined8 *)(piVar5[10] + 0x38);
      if ((int *)(iStack_1c + 8) != piVar8) {
        if (0xf < (uint)piVar5[9]) {
          piVar8 = (int *)*piVar8;
        }
        FUN_005542c0(piVar8,piVar5[8]);
      }
      iVar3 = iStack_14;
      *(int *)(iStack_14 + *param_2) = iVar4;
      FUN_00551320();
      iStack_14 = iVar3 + 4;
    } while (piStack_18 != piVar2);
  }
  uStack_8 = 1;
  if (cStack_20 != '\0') {
    LOCK();
    uVar1 = *puStack_24;
    *puStack_24 = *puStack_24 + 0x80000000;
    UNLOCK();
    if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
      LOCK();
      uVar1 = *puStack_24;
      *puStack_24 = *puStack_24 | 0x40000000;
      UNLOCK();
      if ((uVar1 >> 0x1e & 1) == 0) {
        uVar7 = FUN_00554e40();
        SetEvent(uVar7);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3927 ; VA 0x005817e0 ; FUN_005817e0 */

undefined4 __fastcall FUN_005817e0(int param_1)

{
  return *(undefined4 *)(param_1 + 0xc);
}



/* FUNCTION 3928 ; VA 0x005817f0 ; FUN_005817f0 */

void __thiscall FUN_005817f0(int param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x378);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar1 != 0) {
    LOCK();
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
    iVar1 = *(int *)(param_1 + 0x378);
  }
  *param_2 = *(undefined4 *)(param_1 + 0x374);
  param_2[1] = iVar1;
  return;
}



/* FUNCTION 3929 ; VA 0x00581830 ; FUN_00581830 */

void __thiscall FUN_00581830(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined auStack_10 [12];
  
  puVar2 = param_3;
  FUN_005875d0(&param_3,param_3);
  puVar7 = param_3;
  puVar1 = *(undefined4 **)(param_1 + 0xb4);
  if (param_3 != puVar1) {
    piVar3 = param_3 + 4;
    if (0xf < (uint)param_3[9]) {
      piVar3 = (int *)*piVar3;
    }
    puVar6 = puVar2;
    if (0xf < (uint)puVar2[5]) {
      puVar6 = (undefined4 *)*puVar2;
    }
    iVar4 = FUN_0055c2d0(puVar6,puVar2[4],piVar3,param_3[8]);
    if (-1 < iVar4) goto LAB_00581883;
  }
  puVar7 = puVar1;
LAB_00581883:
  *param_2 = puVar7;
  if (puVar7 != puVar1) {
    return;
  }
  uVar5 = FUN_005543f0();
  FUN_016756b0(auStack_10,"JobItem %s not found",uVar5);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 3930 ; VA 0x005818c0 ; FUN_005818c0 */

undefined * FUN_005818c0(undefined *param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined8 uVar2;
  undefined auStack_c [8];
  
  FUN_0167eea0(auStack_c,param_3);
  cVar1 = FUN_0167e5a0();
  if (cVar1 != '\0') {
    uVar2 = FUN_0167e380(0,0);
    FUN_0058c590(param_1,uVar2);
    return param_1;
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_005542c0(&DAT_018bf2f0,7);
  return param_1;
}



/* FUNCTION 3931 ; VA 0x00581930 ; FUN_00581930 */

undefined * FUN_00581930(undefined *param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0167eea0(auStack_18,param_3);
  cVar1 = FUN_0167e580();
  if (cVar1 == '\0') {
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    FUN_005542c0(&DAT_018bf2f0,7);
  }
  else {
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    uStack_8 = 0;
    FUN_01681330(param_1,auStack_30);
    if (0xf < uStack_1c) {
      uVar3 = uStack_1c + 1;
      uVar2 = auStack_30[0];
      if (0xfff < uVar3) {
        uVar2 = *(uint *)(auStack_30[0] - 4);
        uVar3 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar2,uVar3);
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3932 ; VA 0x00581a10 ; FUN_00581a10 */

/* WARNING: Removing unreachable block (ram,0x00581ae3) */
/* WARNING: Removing unreachable block (ram,0x00581af1) */
/* WARNING: Removing unreachable block (ram,0x00581b1e) */
/* WARNING: Removing unreachable block (ram,0x00581b01) */

undefined4 * __thiscall FUN_00581a10(int param_1,undefined4 *param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char *pcVar5;
  char *pcVar6;
  undefined4 *puVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0xe0) == 0) {
    pcVar6 = "RCCServiceThumbnail";
    if (*(char *)(param_1 + 0x90) == '\0') {
      pcVar6 = "RCCService";
    }
  }
  else {
    pcVar6 = (char *)(param_1 + 0xd0);
    if (0xf < *(uint *)(param_1 + 0xe4)) {
      pcVar6 = *(char **)pcVar6;
    }
  }
  pcVar5 = pcVar6;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(pcVar6,(int)pcVar5 - (int)(pcVar6 + 1));
  puVar7 = (undefined4 *)(param_1 + 0x5c);
  uStack_8 = 0;
  if (0xf < *(uint *)(param_1 + 0x70)) {
    puVar7 = (undefined4 *)*puVar7;
  }
  puVar7 = (undefined4 *)FUN_00554150(puVar7,*(undefined4 *)(param_1 + 0x6c));
  param_2[4] = 0;
  param_2[5] = 0;
  uVar2 = puVar7[1];
  uVar3 = puVar7[2];
  uVar4 = puVar7[3];
  *param_2 = *puVar7;
  param_2[1] = uVar2;
  param_2[2] = uVar3;
  param_2[3] = uVar4;
  *(undefined8 *)(param_2 + 4) = *(undefined8 *)(puVar7 + 4);
  puVar7[4] = 0;
  puVar7[5] = 0xf;
  *(undefined *)puVar7 = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 3933 ; VA 0x00581b30 ; FUN_00581b30 */

void FUN_00581b30(undefined *param_1)

{
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  return;
}



/* FUNCTION 3934 ; VA 0x00581b50 ; FUN_00581b50 */

int * __thiscall FUN_00581b50(int *param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  code *pcVar3;
  undefined4 uVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961d0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005863d0();
  iVar1 = *param_1;
  if (iVar1 == 0) {
    uVar4 = FUN_0056b1c0();
    uStack_8 = 0;
    FUN_00564a30(uVar4);
  }
  else if (*(char *)(param_1 + 2) == '\0') {
    *(undefined *)(param_1 + 2) = 1;
    piVar2 = (int *)param_1[1];
    piVar5 = piVar2 + 1;
    if (piVar2 != (int *)0x0) {
      LOCK();
      *piVar5 = *piVar5 + 1;
      UNLOCK();
      if (piVar2 != (int *)0x0) {
        LOCK();
        *piVar5 = *piVar5 + 1;
        UNLOCK();
      }
    }
    *param_2 = iVar1;
    param_2[1] = (int)piVar2;
    if (piVar2 != (int *)0x0) {
      LOCK();
      *piVar5 = *piVar5 + 1;
      UNLOCK();
    }
    uStack_8 = 2;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = *piVar5;
      *piVar5 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        (**(code **)(*piVar2 + 4))();
        LOCK();
        iVar1 = piVar2[2] + -1;
        piVar2[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar2 + 8))();
        }
      }
    }
    uStack_8 = 3;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = *piVar5;
      *piVar5 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        (**(code **)(*piVar2 + 4))();
        LOCK();
        piVar5 = piVar2 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piVar2 + 8))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  uVar4 = FUN_0056ab30();
  uStack_8 = 1;
  FUN_005648f0(uVar4);
  pcVar3 = (code *)swi(3);
  piVar5 = (int *)(*pcVar3)();
  return piVar5;
}



/* FUNCTION 3935 ; VA 0x00581c50 ; FUN_00581c50 */

undefined4 __fastcall FUN_00581c50(int param_1)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796168;
  pvStack_10 = ExceptionList;
  cStack_14 = '\0';
  puStack_18 = (uint *)(param_1 + 0x24);
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uStack_8 = 0;
  FUN_0058cb00(&puStack_18,1);
  uVar2 = *(undefined4 *)(param_1 + 0x88);
  uStack_8 = 1;
  if (cStack_14 != '\0') {
    LOCK();
    uVar1 = *puStack_18;
    *puStack_18 = *puStack_18 + 0x80000000;
    UNLOCK();
    if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
      LOCK();
      uVar1 = *puStack_18;
      *puStack_18 = *puStack_18 | 0x40000000;
      UNLOCK();
      if ((uVar1 >> 0x1e & 1) == 0) {
        uVar3 = FUN_00554e40();
        SetEvent(uVar3);
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 3936 ; VA 0x00581cf0 ; FUN_00581cf0 */

undefined4 FUN_00581cf0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_005672c0(param_2,param_3);
  return param_1;
}



/* FUNCTION 3937 ; VA 0x00581d10 ; FUN_00581d10 */

int * __thiscall FUN_00581d10(uint *param_1,int *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 uVar5;
  int *piVar6;
  int iVar7;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796222;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005874f0();
  uStack_8 = 0;
  if (param_1[7] == 0) {
    uVar4 = CreateSemaphoreA(0,0,0x7fffffff,0);
    if (uVar4 == 0) {
      uVar5 = FUN_005503c0();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
      FUN_0054e630(uVar5);
    }
    uVar2 = param_1[7];
    if ((uVar2 != 0) && (uVar2 != 0xffffffff)) {
      CloseHandle(uVar2);
    }
    param_1[7] = uVar4;
  }
  param_1[2] = param_1[2] + 1;
  if ((param_1[4] != param_1[5]) &&
     (iVar7 = *(int *)(param_1[5] - 4), *(char *)(iVar7 + 0xc) == '\0')) {
    LOCK();
    piVar6 = (int *)(iVar7 + 8);
    *piVar6 = *piVar6 + 1;
    UNLOCK();
    iVar7 = *(int *)(param_1[5] - 4);
    *param_2 = iVar7;
    if (iVar7 != 0) {
      LOCK();
      *(int *)(iVar7 + 0x10) = *(int *)(iVar7 + 0x10) + 1;
      UNLOCK();
    }
    uStack_8 = 8;
    LOCK();
    uVar4 = *param_1;
    *param_1 = *param_1 + 0x80000000;
    UNLOCK();
    if (((uVar4 & 0x40000000) == 0) && (-0x80000000 < (int)uVar4)) {
      LOCK();
      uVar4 = *param_1;
      *param_1 = *param_1 | 0x40000000;
      UNLOCK();
      if ((uVar4 >> 0x1e & 1) == 0) {
        uVar5 = FUN_00554e40();
        SetEvent(uVar5);
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar6 = (int *)FUN_01674e20(0x14);
  uStack_8._0_1_ = 2;
  if (piVar6 == (int *)0x0) {
    piVar6 = (int *)0x0;
  }
  else {
    piStack_14 = piVar6;
    iVar7 = CreateSemaphoreA(0,0,0x7fffffff,0);
    if (iVar7 == 0) {
      uVar5 = FUN_005503c0();
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
                    /* WARNING: Subroutine does not return */
      FUN_0054e630(uVar5);
    }
    *piVar6 = iVar7;
    uVar4 = param_1[7];
    uStack_8._0_1_ = 4;
    uVar5 = GetCurrentProcess();
    iStack_18 = 0;
    iVar7 = DuplicateHandle(uVar5,uVar4,uVar5,&iStack_18,0,0,2);
    if (iVar7 == 0) {
      uVar5 = FUN_005503c0();
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
                    /* WARNING: Subroutine does not return */
      FUN_0054e630(uVar5);
    }
    piVar6[1] = iStack_18;
    piVar6[2] = 1;
    *(undefined *)(piVar6 + 3) = 0;
    piVar6[4] = 0;
  }
  piVar1 = piVar6 + 4;
  if (piVar6 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puVar3 = (undefined4 *)param_1[5];
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  piStack_14 = piVar6;
  if ((undefined4 *)param_1[6] == puVar3) {
    FUN_00559b20(puVar3,&piStack_14);
  }
  else {
    *puVar3 = piVar6;
    if (piVar6 != (int *)0x0) {
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    param_1[5] = param_1[5] + 4;
  }
  *param_2 = (int)piStack_14;
  uStack_8 = 7;
  LOCK();
  uVar4 = *param_1;
  *param_1 = *param_1 + 0x80000000;
  UNLOCK();
  if (((uVar4 & 0x40000000) == 0) && (-0x80000000 < (int)uVar4)) {
    LOCK();
    uVar4 = *param_1;
    *param_1 = *param_1 | 0x40000000;
    UNLOCK();
    if ((uVar4 >> 0x1e & 1) == 0) {
      uVar5 = FUN_00554e40();
      SetEvent(uVar5);
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 3938 ; VA 0x00581f30 ; FUN_00581f30 */

/* WARNING: Type propagation algorithm not settling */

void FUN_00581f30(uint param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined uVar4;
  char cVar5;
  int *piVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 *******pppppppuVar9;
  int *piVar10;
  uint uVar11;
  uint uVar12;
  undefined4 *puVar13;
  undefined4 *puVar14;
  undefined1 *puVar15;
  uint uVar16;
  char *pcVar17;
  int iStack_1e0;
  uint auStack_1a8 [30];
  undefined auStack_130 [24];
  uint auStack_118 [4];
  undefined4 uStack_108;
  uint uStack_104;
  undefined **appuStack_100 [3];
  uint uStack_f4;
  undefined ***pppuStack_f0;
  uint *puStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 *puStack_e0;
  undefined4 *puStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 *puStack_d0;
  undefined4 *puStack_cc;
  int aiStack_c8 [2];
  undefined uStack_bf;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_9c;
  undefined **appuStack_98 [18];
  undefined4 *******apppppppuStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  uint uStack_38;
  undefined1 *puStack_34;
  uint uStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017962d4;
  pvStack_10 = ExceptionList;
  uStack_38 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_2c = (int *)FUN_016de181(1);
  uVar16 = param_1;
  puVar13 = (undefined4 *)(param_1 + 0x20);
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  piStack_20 = piStack_2c;
  (**(code **)(*piStack_2c + 4))();
  uStack_8._0_1_ = 3;
  puStack_18 = puVar13;
  if (0xf < *(uint *)(uVar16 + 0x34)) {
    puStack_18 = (undefined4 *)*puVar13;
  }
  puStack_18 = (undefined4 *)((int)puStack_18 + *(int *)(uVar16 + 0x30));
  puVar14 = puVar13;
  if (0xf < *(uint *)(uVar16 + 0x34)) {
    puVar14 = (undefined4 *)*puVar13;
  }
  puStack_34 = &DAT_018bfd98;
  do {
    if (puVar14 == puStack_18) goto LAB_00582010;
    uStack_28 = CONCAT31(uStack_28._1_3_,*puStack_34);
    piVar6 = (int *)FUN_0054e7d0(&piStack_24);
    uVar4 = (**(code **)(*piVar6 + 0x18))(uStack_28);
    param_1 = CONCAT13(uVar4,(undefined3)param_1);
    uStack_1c = CONCAT31(uStack_1c._1_3_,*(undefined *)puVar14);
    piVar6 = (int *)FUN_0054e7d0(&piStack_24);
    cVar5 = (**(code **)(*piVar6 + 0x18))(uStack_1c);
    piVar6 = piStack_2c;
    if (param_1._3_1_ != cVar5) {
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      puVar14 = (undefined4 *)(**(code **)(*piStack_2c + 8))();
      if (puVar14 != (undefined4 *)0x0) {
        (**(code **)*puVar14)(1);
      }
      cStack_11 = '\0';
      goto LAB_0058203d;
    }
    puVar14 = (undefined4 *)((int)puVar14 + 1);
    puStack_34 = puStack_34 + 1;
  } while (puStack_34 != &DAT_018bfda1);
  if (puVar14 == puStack_18) {
LAB_00582010:
    cStack_11 = '\x01';
    if (puStack_34 != &DAT_018bfda1) goto LAB_0058201b;
  }
  else {
LAB_0058201b:
    cStack_11 = '\0';
  }
  piVar6 = piStack_2c;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  puVar14 = (undefined4 *)(**(code **)(*piStack_2c + 8))();
  if (puVar14 != (undefined4 *)0x0) {
    (**(code **)*puVar14)(1);
  }
LAB_0058203d:
  uStack_8 = 6;
  puVar14 = (undefined4 *)(**(code **)(*piVar6 + 8))();
  if (puVar14 != (undefined4 *)0x0) {
    (**(code **)*puVar14)(1);
  }
  uStack_8 = 7;
  piStack_2c = (int *)FUN_016de181(1);
  uStack_8._0_1_ = 9;
  uStack_8._1_3_ = 0;
  piStack_20 = piStack_2c;
  (**(code **)(*piStack_2c + 4))();
  uStack_8._0_1_ = 10;
  puStack_18 = puVar13;
  if (0xf < *(uint *)(uVar16 + 0x34)) {
    puStack_18 = (undefined4 *)*puVar13;
  }
  puStack_18 = (undefined4 *)(*(int *)(uVar16 + 0x30) + (int)puStack_18);
  if (0xf < *(uint *)(uVar16 + 0x34)) {
    puVar13 = (undefined4 *)*puVar13;
  }
  puVar15 = &DAT_018bfda4;
  do {
    if (puVar13 == puStack_18) goto LAB_00582103;
    uStack_1c = CONCAT31(uStack_1c._1_3_,*puVar15);
    piVar6 = (int *)FUN_0054e7d0(&piStack_24);
    uVar4 = (**(code **)(*piVar6 + 0x18))(uStack_1c);
    param_1 = CONCAT13(uVar4,(undefined3)param_1);
    uStack_28 = CONCAT31(uStack_28._1_3_,*(undefined *)puVar13);
    piVar6 = (int *)FUN_0054e7d0(&piStack_24);
    cVar5 = (**(code **)(*piVar6 + 0x18))(uStack_28);
    piVar6 = piStack_2c;
    if (param_1._3_1_ != cVar5) {
      uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
      puVar13 = (undefined4 *)(**(code **)(*piStack_2c + 8))();
      if (puVar13 != (undefined4 *)0x0) {
        (**(code **)*puVar13)(1);
      }
      param_1 = param_1 & 0xffffff;
      goto LAB_00582131;
    }
    puVar15 = puVar15 + 1;
    puVar13 = (undefined4 *)((int)puVar13 + 1);
  } while (puVar15 != &DAT_018bfda7);
  if (puVar13 == puStack_18) {
LAB_00582103:
    param_1 = CONCAT13(1,(undefined3)param_1);
    if (puVar15 != &DAT_018bfda7) goto LAB_0058210f;
  }
  else {
LAB_0058210f:
    param_1 = param_1 & 0xffffff;
  }
  piVar6 = piStack_2c;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  puVar13 = (undefined4 *)(**(code **)(*piStack_2c + 8))();
  if (puVar13 != (undefined4 *)0x0) {
    (**(code **)*puVar13)(1);
  }
LAB_00582131:
  uStack_8 = 0xd;
  puVar13 = (undefined4 *)(**(code **)(*piVar6 + 8))();
  if (puVar13 != (undefined4 *)0x0) {
    (**(code **)*puVar13)(1);
  }
  uStack_8 = 0xffffffff;
  uStack_40 = 0;
  uStack_3c = 0xf;
  apppppppuStack_50[0] = (undefined4 *******)((uint)apppppppuStack_50[0] & 0xffffff00);
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 0xe;
  uStack_8._1_3_ = 0;
  if (param_1._3_1_ == '\0') {
    if (cStack_11 == '\0') goto LAB_00582831;
    if (DAT_01d59104 != '\0') {
      FUN_016774b0(DAT_01d59104,"Starting to save thumbnail result to files",0);
    }
    piVar2 = param_2;
    piVar6 = (int *)*param_2;
    if (((param_2[1] - (int)piVar6 >> 2 == 2) && (*(int *)(*piVar6 + 4) == 3)) &&
       (*(int *)(piVar6[1] + 4) == 4)) {
      pppppppuVar9 = apppppppuStack_50;
      if (0xf < uStack_3c) {
        pppppppuVar9 = apppppppuStack_50[0];
      }
      uVar8 = FUN_01675640(auStack_118,"%sthumbnailresult.png",pppppppuVar9);
      uStack_8._0_1_ = 0x1a;
      FUN_00565180(uVar8,0x32,0x40,1);
      uStack_8._0_1_ = 0x1c;
      FUN_005507b0();
      uStack_1c = 0;
      uStack_30 = uStack_30 & 0xffffff00;
      param_1 = *(uint *)((int)auStack_1a8 + *(int *)(iStack_1e0 + 4));
      piVar6 = *(int **)(*(int *)*piVar2 + 8);
      piVar10 = piVar6;
      if (0xf < (uint)piVar6[5]) {
        piVar10 = (int *)*piVar6;
      }
      piVar1 = piVar6 + 4;
      if (0xf < (uint)piVar6[5]) {
        piVar6 = (int *)*piVar6;
      }
      FUN_00563150(&param_1,piVar6,*piVar1 + (int)piVar10,uStack_30,param_1,&uStack_1c);
      FUN_00581480();
      FUN_0057aad0();
      pppppppuVar9 = apppppppuStack_50;
      if (0xf < uStack_3c) {
        pppppppuVar9 = apppppppuStack_50[0];
      }
      uVar8 = FUN_01675640(auStack_130,"%sthumbnaildeps.txt",pppppppuVar9);
      uStack_8._0_1_ = 0x1d;
      FUN_00565180(uVar8,0x12,0x40,1);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x1f);
      FUN_005507b0();
      iVar7 = *piVar2;
      uVar16 = 0;
      iVar3 = *(int *)(*(int *)(iVar7 + 4) + 0xc);
      if (*(int *)(iVar3 + 8) - *(int *)(iVar3 + 4) >> 2 != 0) {
        do {
          iVar7 = *(int *)(*(int *)(*(int *)(*(int *)(iVar7 + 4) + 0xc) + 4) + uVar16 * 4);
          if (*(int *)(iVar7 + 4) == 3) {
            piVar10 = *(int **)(iVar7 + 8);
            piVar6 = piVar10 + 4;
            if (0xf < (uint)piVar10[5]) {
              piVar10 = (int *)*piVar10;
            }
            uVar8 = FUN_0055b3b0(appuStack_100,piVar10,*piVar6);
            FUN_00562ba0(uVar8);
          }
          else if (DAT_01d59104 != '\0') {
            FUN_01677520(DAT_01d59104,"Dependency %zu is not a string",uVar16);
          }
          iVar7 = *piVar2;
          uVar16 = uVar16 + 1;
          iVar3 = *(int *)(*(int *)(iVar7 + 4) + 0xc);
        } while (uVar16 < (uint)(*(int *)(iVar3 + 8) - *(int *)(iVar3 + 4) >> 2));
      }
      FUN_00581480();
      iVar7 = FUN_005548a0();
      if (iVar7 == 0) {
        FUN_00554460((uint)(*(int *)((int)aiStack_c8 + (int)appuStack_100[0][1]) == 0) * 4 + 2 |
                     *(uint *)((int)&uStack_f4 + (int)appuStack_100[0][1]),0);
      }
      FUN_00570460();
      uStack_8._0_1_ = 0xe;
      FUN_00570460();
    }
    else {
      if (DAT_01d59104 == '\0') goto LAB_00582831;
      FUN_016774b0(DAT_01d59104,"Warning: thumbnail output not in expected format",0);
    }
    if (DAT_01d59104 == '\0') goto LAB_00582831;
    pcVar17 = "Finished saving thumbnail output to files";
  }
  else {
    if (DAT_01d59104 != '\0') {
      FUN_016774b0(DAT_01d59104,"Beginning saving raw response data to files...",0);
    }
    uVar16 = 0;
    if (param_2[1] - *param_2 >> 2 != 0) {
      do {
        pppppppuVar9 = apppppppuStack_50;
        if (0xf < uStack_3c) {
          pppppppuVar9 = apppppppuStack_50[0];
        }
        puVar13 = (undefined4 *)FUN_01675640(auStack_118,"%srawoutput.%zu",pppppppuVar9,uVar16);
        if (0xf < (uint)puVar13[5]) {
          puVar13 = (undefined4 *)*puVar13;
        }
        appuStack_100[0] = &PTR_018bfd64;
        uStack_38 = uStack_38 | 1;
        uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
        appuStack_98[0] = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
        uStack_9c = 0x60;
        FUN_00554f20(appuStack_100 + 1,0);
        uStack_8 = 0x12;
        *(undefined ***)((int)appuStack_100 + (int)appuStack_100[0][1]) =
             std::basic_ofstream<char,struct_std::char_traits<char>_>::vftable;
        *(undefined **)((int)&uStack_104 + (int)appuStack_100[0][1]) = appuStack_100[0][1] + -0x68;
        FUN_0054ee60();
        pppuStack_f0 = appuStack_100 + 2;
        appuStack_100[1] = std::basic_filebuf<char,struct_std::char_traits<char>_>::vftable;
        puStack_ec = &uStack_f4;
        puStack_e0 = &uStack_e8;
        puStack_dc = &uStack_e4;
        puStack_d0 = &uStack_d8;
        puStack_cc = &uStack_d4;
        uStack_bc = DAT_01e90d08;
        uStack_b4 = 0;
        uStack_bf = 0;
        uStack_f4 = 0;
        uStack_e4 = 0;
        uStack_d4 = 0;
        appuStack_100[2] = (undefined **)0x0;
        uStack_e8 = 0;
        uStack_d8 = 0;
        uStack_b0 = 0;
        uStack_b8 = DAT_01e90d0c;
        aiStack_c8[1] = 0;
        uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
        iVar7 = FUN_005886c0(puVar13,0x32,0x40);
        if (iVar7 == 0) {
          FUN_00554460((uint)(*(int *)((int)aiStack_c8 + (int)appuStack_100[0][1]) == 0) * 4 + 2 |
                       *(uint *)((int)&uStack_f4 + (int)appuStack_100[0][1]),0);
        }
        *(undefined ***)((int)appuStack_100 + (int)appuStack_100[0][1]) =
             std::basic_ofstream<char,struct_std::char_traits<char>_>::vftable;
        *(undefined **)((int)&uStack_104 + (int)appuStack_100[0][1]) = appuStack_100[0][1] + -0x68;
        uStack_8._0_1_ = 0x15;
        if (0xf < uStack_104) {
          uVar12 = uStack_104 + 1;
          uVar11 = auStack_118[0];
          if (0xfff < uVar12) {
            uVar11 = *(uint *)(auStack_118[0] - 4);
            uVar12 = uStack_104 + 0x24;
            if (0x1f < (auStack_118[0] - uVar11) - 4) goto LAB_00582871;
          }
          FUN_01674ea0(uVar11,uVar12);
        }
        piVar6 = param_2;
        uStack_108 = 0;
        uStack_104 = 0xf;
        auStack_118[0] = auStack_118[0] & 0xffffff00;
        FUN_005895a0(*(undefined4 *)(*param_2 + uVar16 * 4),appuStack_100);
        if (*(int *)((int)aiStack_c8 + (int)appuStack_100[0][1]) != 0) {
          FUN_0056b230(appuStack_100);
          uStack_8._0_1_ = 0x16;
          if (((char)piStack_20 != '\0') &&
             (iVar7 = (**(code **)(**(int **)((int)aiStack_c8 + (int)appuStack_100[0][1]) + 0x34))()
             , iVar7 == -1)) {
            FUN_00554460(*(uint *)((int)&uStack_f4 + (int)appuStack_100[0][1]) | 4,0);
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,0x17);
          cVar5 = thunk_FUN_0170e3b7();
          if (cVar5 == '\0') {
            FUN_00577770();
          }
          uStack_8._0_1_ = 0x18;
          piVar2 = *(int **)(*(int *)(*piStack_24 + 4) + 0x38 + (int)piStack_24);
          if (piVar2 != (int *)0x0) {
            (**(code **)(*piVar2 + 8))();
          }
          uStack_8._0_1_ = 0x15;
        }
        iVar7 = FUN_005548a0();
        if (iVar7 == 0) {
          FUN_00554460((uint)(*(int *)((int)aiStack_c8 + (int)appuStack_100[0][1]) == 0) * 4 + 2 |
                       *(uint *)((int)&uStack_f4 + (int)appuStack_100[0][1]),0);
        }
        *(undefined ***)((int)appuStack_100 + (int)appuStack_100[0][1]) =
             std::basic_ofstream<char,struct_std::char_traits<char>_>::vftable;
        *(undefined **)((int)&uStack_104 + (int)appuStack_100[0][1]) = appuStack_100[0][1] + -0x68;
        FUN_00550570();
        *(undefined ***)((int)appuStack_100 + (int)appuStack_100[0][1]) =
             std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
        *(undefined **)((int)&uStack_104 + (int)appuStack_100[0][1]) = appuStack_100[0][1] + -8;
        uStack_8._0_1_ = 0x19;
        appuStack_98[0] = std::ios_base::vftable;
        FUN_016de551(appuStack_98);
        uVar16 = uVar16 + 1;
        uStack_8._0_1_ = 0xe;
      } while (uVar16 < (uint)(piVar6[1] - *piVar6 >> 2));
    }
    if (DAT_01d59104 == '\0') goto LAB_00582831;
    pcVar17 = "Finished saving raw response data";
  }
  FUN_016774b0(DAT_01d59104,pcVar17,0);
LAB_00582831:
  if (0xf < uStack_3c) {
    uVar16 = uStack_3c + 1;
    pppppppuVar9 = apppppppuStack_50[0];
    if (0xfff < uVar16) {
      pppppppuVar9 = (undefined4 *******)apppppppuStack_50[0][-1];
      uVar16 = uStack_3c + 0x24;
      if (0x1f < (uint)((int)apppppppuStack_50[0] + (-4 - (int)pppppppuVar9))) {
LAB_00582871:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppppuVar9,uVar16);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3939 ; VA 0x00582880 ; FUN_00582880 */

int FUN_00582880(undefined4 param_1,undefined4 *param_2)

{
  int *piVar1;
  bool bVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  int iVar7;
  double *pdVar8;
  undefined1 *puVar9;
  uint uVar10;
  uint uVar11;
  longlong lVar12;
  double dStack_74;
  int iStack_60;
  int *piStack_5c;
  uint auStack_54 [3];
  int *piStack_48;
  int *piStack_44;
  uint uStack_40;
  undefined auStack_3c [4];
  longlong lStack_38;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179635f;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  puStack_14 = &stack0xffffff48;
  piStack_44 = (int *)0x0;
  uStack_40 = 0xf;
  auStack_54[0] = auStack_54[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("Settings",8);
  uStack_8 = 0;
  piStack_18 = (int *)0x1;
  piVar3 = (int *)FUN_00580040(&param_1,auStack_54);
  iVar7 = *piVar3;
  if ((iVar7 == 0) || (iVar5 = *(int *)(iVar7 + 0x20), iVar4 = FUN_008881d0(), iVar5 != iVar4)) {
    bVar2 = false;
  }
  else {
    bVar2 = true;
  }
  uStack_8 = 0xffffffff;
  if (0xf < uStack_40) {
    uVar11 = uStack_40 + 1;
    uVar10 = auStack_54[0];
    if (0xfff < uVar11) {
      uVar10 = *(uint *)(auStack_54[0] - 4);
      uVar11 = uStack_40 + 0x24;
      if (0x1f < (auStack_54[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar11);
  }
  piStack_44 = (int *)0x0;
  uStack_40 = 0xf;
  auStack_54[0] = auStack_54[0] & 0xffffff00;
  if (bVar2) {
    iVar5 = *(int *)(iVar7 + 0x20);
    iVar4 = FUN_008881d0();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    iVar5 = iVar7 + 0x28;
    if (*(int *)(iVar7 + 0x24) == 0) {
      iVar5 = 0;
    }
    piVar3 = *(int **)(iVar5 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar3[1] = piVar3[1] + 1;
      UNLOCK();
      piVar3 = *(int **)(iVar5 + 4);
    }
    uStack_8 = 1;
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    FUN_005542c0("PlayerId",8);
    piVar6 = (int *)FUN_00580040(auStack_3c,auStack_30);
    if ((*piVar6 == 0) ||
       (param_1._3_1_ = '\x01', *(char *)(*(int *)(*piVar6 + 0x20) + 0x21) == '\0')) {
      param_1._3_1_ = '\0';
    }
    FUN_005507b0();
    if (param_1._3_1_ != '\0') {
      lStack_38 = FUN_00563790();
      param_1._3_1_ = '\0';
      uStack_8._0_1_ = 2;
      if (param_2[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_2[1] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      FUN_008e9510(*param_2,param_2[1],1);
      uStack_8._0_1_ = 3;
      FUN_01682800();
      piVar3 = (int *)FUN_00562e40();
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 0x40))();
        uStack_8._0_1_ = 4;
        if (iStack_60 != 0) {
          FUN_00569460();
          uStack_8._0_1_ = 5;
          piStack_18 = piStack_44;
          piVar3 = piStack_44;
          for (piVar6 = piStack_48; piVar6 != piVar3; piVar6 = piVar6 + 2) {
            piVar1 = (int *)*piVar6;
            if (piVar1 != (int *)0x0) {
              iVar7 = piVar1[3];
              iVar5 = FUN_005ee170();
              piVar3 = piStack_18;
              if ((uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
                  (uint)*(ushort *)(iVar5 + 0x1da)) {
                iVar7 = (**(code **)(*piVar1 + 0xb4))();
                piVar3 = piStack_18;
                if (iVar7 != 0) {
                  lVar12 = FUN_00928340();
                  piVar3 = piStack_18;
                  if (lVar12 == lStack_38) {
                    param_1._3_1_ = '\x01';
                    FUN_0062b8c0();
                    FUN_006194b0();
                    piVar3 = piStack_18;
                  }
                }
              }
            }
          }
          FUN_00577ac0();
        }
        uStack_8._0_1_ = 3;
        if (piStack_5c != (int *)0x0) {
          LOCK();
          iVar7 = piStack_5c[1] + -1;
          piStack_5c[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)*piStack_5c)();
            LOCK();
            iVar7 = piStack_5c[2] + -1;
            piStack_5c[2] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)(*piStack_5c + 4))();
            }
          }
        }
      }
      if (DAT_01e90d58 != '\0') {
        pdVar8 = (double *)FUN_01682800();
        FUN_01677520(DAT_01e90d58,"EvictPlayer colse connection cost time: %f",
                     (*pdVar8 - dStack_74) * DAT_018c0d70);
        if (DAT_01e90d58 != '\0') {
          puVar9 = &DAT_018bdf50;
          if (param_1._3_1_ == '\0') {
            puVar9 = &DAT_018bdf48;
          }
          FUN_01677520(DAT_01e90d58,"EvictPlayer playerId:%lld. foundPlayer:%s",lStack_38,puVar9);
        }
      }
      FUN_008eb110();
      iVar7 = FUN_00582c9f();
      return iVar7;
    }
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    FUN_005542c0("[no playerid in request]",0x18);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
    FUN_00589b60();
    iVar7 = FUN_005507b0();
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar6 = piVar3 + 1;
      iVar5 = *piVar6;
      iVar7 = *piVar6;
      *piVar6 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        iVar7 = (**(code **)*piVar3)();
        LOCK();
        piVar6 = piVar3 + 2;
        iVar5 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          iVar7 = (**(code **)(*piVar3 + 4))();
          ExceptionList = pvStack_10;
          return iVar7;
        }
      }
    }
  }
  else {
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    FUN_005542c0("[no settings table in request]",0x1e);
    uStack_8 = 0xe;
    iVar7 = FUN_00589b60();
    if (0xf < uStack_1c) {
      uVar11 = uStack_1c + 1;
      uVar10 = auStack_30[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_30[0] - 4);
        uVar11 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      iVar7 = FUN_01674ea0(uVar10,uVar11);
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 3940 ; VA 0x00582bbe ; Catch@00582bbe */

undefined * Catch_00582bbe(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  *(undefined4 *)(unaff_EBP + -0x1c) = 0;
  *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
  *(undefined *)(unaff_EBP + -0x2c) = 0;
  FUN_005542c0("RCCFailedToEvictPlayer",0x16);
  *(undefined *)(unaff_EBP + -4) = 7;
  FUN_008783f0(unaff_EBP + -0x2c,1,0);
  *(undefined *)(unaff_EBP + -4) = 6;
  FUN_005507b0();
  FUN_0151f6f0(0xffffffff,0,0);
  *(undefined *)(unaff_EBP + -4) = 8;
  FUN_0151fbb0("PlayerId",*(undefined4 *)(unaff_EBP + -0x34),*(undefined4 *)(unaff_EBP + -0x30));
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x68) + 4))();
  FUN_0151f850("Error",uVar1);
  uVar1 = DAT_01e90d40;
  *(undefined4 *)(unaff_EBP + -0x1c) = 0;
  *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
  *(undefined *)(unaff_EBP + -0x2c) = 0;
  FUN_005542c0("RCCFailedToEvictPlayer",0x16);
  *(undefined *)(unaff_EBP + -4) = 9;
  FUN_01520d20(unaff_EBP + -0x2c,uVar1,0);
  FUN_005507b0();
  FUN_0151f7f0();
  return &DAT_00582c99;
}



/* FUNCTION 3941 ; VA 0x00582c9f ; FUN_00582c9f */

void FUN_00582c9f(void)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *unaff_EBX;
  int unaff_EBP;
  int unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  if (*(char *)(unaff_EBP + 0xb) == '\0') {
    *(undefined4 *)(unaff_EBP + -0x1c) = 0;
    *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
    *(undefined *)(unaff_EBP + -0x2c) = 0;
    FUN_005542c0("RCCFailedToFindPlayerToEvict",0x1c);
    *(undefined *)(unaff_EBP + -4) = 10;
    FUN_008783f0(unaff_EBP + -0x2c,1,0);
    *(undefined *)(unaff_EBP + -4) = 1;
    FUN_005507b0();
    FUN_0151f6f0(0xffffffff,0,0);
    *(undefined *)(unaff_EBP + -4) = 0xb;
    FUN_0151fbb0("PlayerId",*(undefined4 *)(unaff_EBP + -0x34),*(undefined4 *)(unaff_EBP + -0x30));
    FUN_0151f850("Error","[did not find player]");
    uVar3 = DAT_01e90d40;
    *(undefined4 *)(unaff_EBP + -0x1c) = 0;
    *(undefined4 *)(unaff_EBP + -0x18) = 0xf;
    *(undefined *)(unaff_EBP + -0x2c) = 0;
    FUN_005542c0("RCCFailedToEvictPlayer",0x16);
    *(undefined *)(unaff_EBP + -4) = 0xc;
    FUN_01520d20(unaff_EBP + -0x2c,uVar3,0);
    FUN_005507b0();
    FUN_0151f7f0();
  }
  if (unaff_EBX != (int *)0x0) {
    LOCK();
    iVar2 = unaff_EBX[1] + unaff_EDI;
    unaff_EBX[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*unaff_EBX)();
      LOCK();
      piVar1 = unaff_EBX + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + unaff_EDI;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*unaff_EBX + 4))();
        ExceptionList = *(void **)(unaff_EBP + -0xc);
        return;
      }
    }
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 3942 ; VA 0x00582e90 ; FUN_00582e90 */

undefined4
FUN_00582e90(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,int param_5)

{
  undefined4 *puVar1;
  bool bVar2;
  undefined uVar3;
  char cVar4;
  int *piVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined4 uVar9;
  undefined4 ****ppppuVar10;
  uint uVar11;
  undefined4 ****ppppuVar12;
  int iVar13;
  undefined4 uVar14;
  char *pcVar15;
  undefined4 uVar16;
  int iStack_22c;
  byte abStack_220 [4];
  undefined auStack_21c [168];
  undefined auStack_174 [24];
  undefined auStack_15c [24];
  undefined auStack_144 [16];
  int iStack_134;
  undefined2 auStack_12c [8];
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined auStack_114 [24];
  undefined auStack_fc [24];
  undefined **ppuStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined uStack_c8;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined auStack_b0 [24];
  undefined4 ***apppuStack_98 [4];
  int iStack_88;
  uint uStack_84;
  undefined4 uStack_80;
  int iStack_7c;
  char acStack_78 [16];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 *puStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 ***apppuStack_54 [4];
  int iStack_44;
  uint uStack_40;
  int *piStack_3c;
  int *piStack_38;
  undefined4 uStack_34;
  int aiStack_30 [2];
  undefined4 ***apppuStack_28 [3];
  undefined auStack_1c [4];
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01796541;
  pvStack_10 = ExceptionList;
  aiStack_30[1] = 0;
  uStack_8 = 0;
  iStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  ExceptionList = &pvStack_10;
  FUN_005542c0("Settings",8);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  aiStack_30[1] = 1;
  piVar5 = (int *)FUN_00580040(&param_2,apppuStack_28);
  iVar13 = *piVar5;
  if ((iVar13 == 0) || (iVar8 = *(int *)(iVar13 + 0x20), iVar6 = FUN_008881d0(), iVar8 != iVar6)) {
    bVar2 = true;
  }
  else {
    bVar2 = false;
  }
  uStack_8 = 0;
  if (0xf < uStack_14) {
    uVar11 = uStack_14 + 1;
    ppppuVar10 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar11) {
      ppppuVar10 = (undefined4 ****)apppuStack_28[0][-1];
      uVar11 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar10))) goto LAB_0058399c;
    }
    FUN_01674ea0(ppppuVar10,uVar11);
  }
  iStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  if (bVar2) {
    FUN_0054eff0("Missing \'Settings\'");
    uStack_8._0_1_ = 2;
    FUN_0054eff0(&DAT_018bc9b8);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_005899f0(auStack_114,auStack_b0,param_4);
LAB_005839df:
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  iVar8 = *(int *)(iVar13 + 0x20);
  iVar6 = FUN_008881d0();
  if (iVar8 != iVar6) goto LAB_005839df;
  puVar7 = (undefined4 *)(iVar13 + 0x28);
  if (*(int *)(iVar13 + 0x24) == 0) {
    puVar7 = (undefined4 *)0x0;
  }
  iStack_7c = puVar7[1];
  if (iStack_7c != 0) {
    LOCK();
    *(int *)(iStack_7c + 4) = *(int *)(iStack_7c + 4) + 1;
    UNLOCK();
    iStack_7c = puVar7[1];
  }
  param_2 = *puVar7;
  uStack_8._0_1_ = 4;
  uStack_68 = 0;
  uStack_64 = 0xf;
  acStack_78[0] = '\0';
  uStack_80 = param_2;
  FUN_005542c0(&DAT_018bf030,4);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  aiStack_30[1] = 2;
  piVar5 = (int *)FUN_00580040(aiStack_30,acStack_78);
  iVar13 = *piVar5;
  if ((iVar13 == 0) || (iVar8 = *(int *)(iVar13 + 0x20), iVar6 = FUN_0088cb40(), iVar8 != iVar6)) {
    cVar4 = '\x01';
  }
  else {
    cVar4 = '\0';
  }
  uStack_8 = 4;
  FUN_005507b0();
  if (cVar4 != '\0') {
    FUN_0054eff0("Missing \'Type\'");
    uStack_8._0_1_ = 6;
    FUN_0054eff0(&DAT_018bc9b8);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_005899f0(auStack_114,auStack_b0,param_4);
LAB_00583a27:
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  iVar8 = *(int *)(iVar13 + 0x20);
  iVar6 = FUN_0088cb40();
  if (iVar8 != iVar6) goto LAB_00583a27;
  iVar8 = iVar13 + 0x28;
  if (*(int *)(iVar13 + 0x24) == 0) {
    iVar8 = 0;
  }
  FUN_0054ef60(iVar8);
  uStack_8._0_1_ = 8;
  uStack_68 = 0;
  uStack_64 = 0xf;
  acStack_78[0] = cVar4;
  FUN_005542c0("Arguments",9);
  piVar5 = (int *)FUN_00580040(aiStack_30,acStack_78);
  iVar13 = *piVar5;
  FUN_005507b0();
  if (iVar13 == 0) {
    FUN_0054eff0("Missing \'Arguments\'");
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    FUN_005899f0(apppuStack_54,auStack_b0,param_4);
    puVar7 = (undefined4 *)0x0;
LAB_00583a58:
    FUN_016f3809(&DAT_01ea8a9c);
    if (DAT_01ea8a9c == -1) {
      DAT_01ea8a90 = FUN_0057bbb0;
      DAT_01ea8a94 = FUN_005880a0;
      DAT_01ea8a98 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ea8a9c);
    }
LAB_0058310f:
    puVar1 = (undefined4 *)puVar7[1];
    if ((code **)puVar1 == &DAT_01ea8a90) {
      FUN_0056ecd0(&uStack_34);
      uStack_8._0_1_ = 10;
      FUN_00550b30();
    }
    else {
      if (puVar1 != (undefined4 *)0x0) {
        (*(code *)puVar1[2])(puVar7 + 2);
        puVar7[1] = 0;
      }
      puVar7[2] = 0;
      puVar7[3] = 0;
      if (aiStack_30[0] != 0) {
        LOCK();
        *(int *)(aiStack_30[0] + 4) = *(int *)(aiStack_30[0] + 4) + 1;
        UNLOCK();
      }
      puVar7[3] = aiStack_30[0];
      puVar7[2] = uStack_34;
      puVar7[1] = &DAT_01ea8a90;
      uStack_8._0_1_ = 10;
      FUN_00550b30();
    }
  }
  else {
    puStack_60 = (undefined4 *)0x0;
    uStack_5c = 0;
    uStack_58 = 0;
    piVar5 = (int *)(iVar13 + 0x20);
    uStack_8._0_1_ = 10;
    iVar13 = *piVar5;
    iVar8 = FUN_008881d0();
    if (iVar13 == iVar8) {
      uVar9 = FUN_0055d640();
      FUN_00557fc0(uVar9);
      uStack_8._0_1_ = 0xb;
      FUN_00569550(1,(int)&param_2 + 3);
      uStack_8._0_1_ = 0xc;
      FUN_0056ed30(auStack_1c);
      uStack_8._0_1_ = 0xd;
      FUN_00577b20();
      puVar7 = puStack_60;
      uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
      uVar9 = FUN_008881d0();
      iVar13 = _tls_index;
      *puVar7 = uVar9;
      if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar13 * 4) + 0x34) < DAT_01ea8a9c)
      goto LAB_00583a58;
      goto LAB_0058310f;
    }
    iVar13 = *piVar5;
    iVar8 = FUN_008882f0();
    if (iVar13 != iVar8) {
      FUN_0054eff0("Invalid \'Arguments\'");
      uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
      FUN_005899f0(apppuStack_54,auStack_fc,param_4);
LAB_0058399c:
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    uVar9 = FUN_0055d670();
    FUN_00557fc0(uVar9);
    piVar5 = piStack_3c;
    uStack_8._0_1_ = 0xe;
    FUN_00569550((piStack_3c[1] - *piStack_3c) / 0xd0,(int)&param_2 + 3);
    uStack_8._0_1_ = 0xf;
    FUN_0056ed30(auStack_1c);
    uStack_8._0_1_ = 0x10;
    FUN_00577b20();
    uVar11 = 0;
    uStack_8._0_1_ = 0xe;
    iVar13 = piVar5[1] - *piVar5 >> 0x1f;
    if ((piVar5[1] - *piVar5) / 0xd0 + iVar13 != iVar13) {
      do {
        uVar9 = FUN_00578430(uVar11);
        FUN_0056ee80(uVar9);
        uVar11 = uVar11 + 1;
      } while (uVar11 < (uint)((piVar5[1] - *piVar5) / 0xd0));
    }
    uStack_8._0_1_ = 10;
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar13 = piStack_38[1] + -1;
      piStack_38[1] = iVar13;
      UNLOCK();
      if (iVar13 == 0) {
        (**(code **)*piStack_38)();
        LOCK();
        piVar5 = piStack_38 + 2;
        iVar13 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar13 == 1) {
          (**(code **)(*piStack_38 + 4))();
        }
      }
    }
  }
  FUN_0054ef60(apppuStack_54);
  cVar4 = FUN_0058c700();
  if (cVar4 == '\0') {
    FUN_0054eff0("Bad character in \'Type\'");
    uStack_8._0_1_ = 0x12;
    FUN_005899f0(apppuStack_54,auStack_b0,param_4);
    uVar3 = (undefined)uStack_8;
LAB_00583ac9:
    uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
    FUN_017167a3();
  }
  if (param_5 != 0) {
    FUN_005542c0("ExecuteScript",0xd);
    if ((undefined4 ****)(param_5 + 0x2c) != apppuStack_54) {
      ppppuVar10 = apppuStack_54;
      if (0xf < uStack_40) {
        ppppuVar10 = (undefined4 ****)apppuStack_54[0];
      }
      FUN_005542c0(ppppuVar10,iStack_44);
    }
  }
  uStack_8._0_1_ = 0x13;
  uStack_68 = 0;
  uStack_64 = 0xf;
  acStack_78[0] = '\0';
  aiStack_30[1] = 8;
  FUN_0058a190(iStack_44 + 4);
  ppppuVar10 = apppuStack_54;
  if (0xf < uStack_40) {
    ppppuVar10 = (undefined4 ****)apppuStack_54[0];
  }
  FUN_00554150(ppppuVar10,iStack_44);
  FUN_00554150(&DAT_018bf1c0,4);
  FUN_00558140(acStack_78,0);
  uStack_11c = 0;
  uStack_118 = 7;
  auStack_12c[0] = 0;
  uStack_8._0_1_ = 0x15;
  iStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  FUN_005542c0("scripts",7);
  uStack_8._0_1_ = 0x16;
  if (iStack_18 != 0) {
    ppppuVar10 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar10 = (undefined4 ****)apppuStack_28[0];
    }
    iVar13 = (int)ppppuVar10 + iStack_18;
    ppppuVar10 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar10 = (undefined4 ****)apppuStack_28[0];
    }
    uVar9 = FUN_01686580();
    FUN_01685950(ppppuVar10,iVar13,auStack_12c,uVar9);
  }
  uStack_8._0_1_ = 0x15;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x15;
  if (0xf < uStack_14) {
    uVar11 = uStack_14 + 1;
    ppppuVar10 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar11) {
      ppppuVar10 = (undefined4 ****)apppuStack_28[0][-1];
      uVar11 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar10))) goto LAB_00583ac9;
    }
    FUN_01674ea0(ppppuVar10,uVar11);
  }
  iStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  uStack_8._0_1_ = 0x17;
  FUN_0054d730("internalscripts",0);
  uStack_8._0_1_ = 0x18;
  uVar9 = FUN_01518d10(auStack_fc,0,3,0);
  uStack_8._0_1_ = 0x19;
  uVar9 = FUN_005514a0(auStack_15c,uVar9,auStack_114);
  uStack_8._0_1_ = 0x1a;
  uVar9 = FUN_005514a0(auStack_174,uVar9,auStack_12c);
  uStack_8._0_1_ = 0x1b;
  FUN_005514a0(apppuStack_98,uVar9,auStack_b0);
  FUN_00550800();
  FUN_00550800();
  FUN_00550800();
  FUN_00550800();
  FUN_00550800();
  FUN_00550800();
  uStack_8._0_1_ = 0x23;
  FUN_005507b0();
  if (DAT_01d59104 != '\0') {
    uStack_8._0_1_ = 0x24;
    iStack_18 = 0;
    uStack_14 = 0xf;
    apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
    aiStack_30[1] = 0x10;
    if (iStack_88 != 0) {
      ppppuVar10 = apppuStack_98;
      if (7 < uStack_84) {
        ppppuVar10 = (undefined4 ****)apppuStack_98[0];
      }
      ppppuVar12 = apppuStack_98;
      if (7 < uStack_84) {
        ppppuVar12 = (undefined4 ****)apppuStack_98[0];
      }
      uVar9 = FUN_01686580();
      FUN_01685a20(ppppuVar12,(int)ppppuVar10 + iStack_88 * 2,apppuStack_28,uVar9);
    }
    ppppuVar10 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar10 = (undefined4 ****)apppuStack_28[0];
    }
    FUN_01677520(DAT_01d59104,"Loading ExecuteScript script file %s",ppppuVar10);
    uStack_8._0_1_ = 0x23;
    if (0xf < uStack_14) {
      uVar11 = uStack_14 + 1;
      ppppuVar10 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar11) {
        ppppuVar10 = (undefined4 ****)apppuStack_28[0][-1];
        uVar11 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar10))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar10,uVar11);
    }
  }
  ppppuVar10 = apppuStack_98;
  if (7 < uStack_84) {
    ppppuVar10 = (undefined4 ****)apppuStack_98[0];
  }
  FUN_0054ebd0(ppppuVar10,1,0x40,1);
  uStack_8._0_1_ = 0x26;
  uVar9 = 0x5835ac;
  FUN_00565940(3,1);
  uStack_8._0_1_ = 0x27;
  if ((abStack_220[*(int *)(iStack_22c + 4)] & 6) == 0) {
    FUN_0056f130(auStack_21c);
    uVar14 = 0x5835eb;
    FUN_0058c420(auStack_144);
    piVar5 = param_3;
    uStack_8._0_1_ = 0x2a;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x2a;
    if (iStack_134 != 0) {
      if (DAT_01d64500 == '\0') {
        uVar16 = 1;
        uStack_8._0_1_ = uVar3;
        FUN_00557fc0(param_3);
        FUN_008e9510(uVar9,uVar14,uVar16);
        uStack_8._0_1_ = 0x31;
        uVar3 = (undefined)uStack_8;
        uStack_8._0_1_ = 0x31;
        if (*(char *)(*piVar5 + 0x1dd) == '\0') {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("The DataModel is closed");
        }
        if (param_5 != 0) {
          ppppuVar10 = apppuStack_54;
          if (0xf < uStack_40) {
            ppppuVar10 = (undefined4 ****)apppuStack_54[0];
          }
          pcVar15 = "TexturePack";
          cVar4 = FUN_0055c360(ppppuVar10,iStack_44,"TexturePack",0xb);
          if (cVar4 != '\0') {
            uVar9 = 0x58383f;
            iVar13 = FUN_0055e7b0();
            if (iVar13 != 0) {
              FUN_00557fc0(&param_5);
              FUN_0058bb20(pcVar15,uVar9);
            }
          }
        }
        uStack_e0 = 0;
        uStack_dc = 0;
        uStack_d4 = 0;
        uStack_d0 = 0;
        ppuStack_e4 = RBX::CorescriptConfigurer::vftable;
        uStack_b8 = 0;
        uStack_b4 = 0xf;
        uStack_c8 = 0;
        uStack_8._0_1_ = 0x32;
        FUN_00638860(*piVar5);
        FUN_0055ea10();
        uVar9 = FUN_00886c00(&iStack_18,auStack_144);
        uStack_8._0_1_ = 0x33;
        FUN_01255470(8,0,0,0);
        uVar9 = FUN_0094ed20(&piStack_3c,auStack_fc,uVar9,"Execute Script",&puStack_60);
        FUN_00557f90(uVar9);
        FUN_00550b30();
        FUN_0056e380();
        FUN_0056e380();
        FUN_0056d930();
        FUN_008eb110();
        FUN_005507b0();
        FUN_005705c0();
        FUN_00551650();
        FUN_00550800();
        uStack_8 = CONCAT31(uStack_8._1_3_,0x34);
LAB_005837b0:
        FUN_00577b20();
        FUN_005507b0();
        FUN_00550b30();
        FUN_00550b30();
        ExceptionList = pvStack_10;
        return param_1;
      }
      uVar14 = 0x583612;
      FUN_00563e30(&piStack_3c);
      piVar5 = param_3;
      uVar16 = 1;
      uStack_8._0_1_ = 0x2c;
      FUN_00557fc0(param_3);
      FUN_008e9510(uVar9,uVar14,uVar16);
      uStack_8._0_1_ = 0x2d;
      uVar3 = (undefined)uStack_8;
      uStack_8._0_1_ = 0x2d;
      if (*(char *)(*piVar5 + 0x1dd) != '\0') {
        if (param_5 != 0) {
          ppppuVar10 = apppuStack_54;
          if (0xf < uStack_40) {
            ppppuVar10 = (undefined4 ****)apppuStack_54[0];
          }
          pcVar15 = "TexturePack";
          cVar4 = FUN_0055c360(ppppuVar10,iStack_44,"TexturePack",0xb);
          if (cVar4 != '\0') {
            uVar9 = 0x583674;
            iVar13 = FUN_0055e7b0();
            if (iVar13 != 0) {
              FUN_00557fc0(&param_5);
              FUN_0058bb20(pcVar15,uVar9);
            }
          }
        }
        uStack_e0 = 0;
        uStack_dc = 0;
        uStack_d4 = 0;
        uStack_d0 = 0;
        ppuStack_e4 = RBX::CorescriptConfigurer::vftable;
        uStack_b8 = 0;
        uStack_b4 = 0xf;
        uStack_c8 = 0;
        uStack_8._0_1_ = 0x2e;
        FUN_00638860(*piVar5);
        uVar9 = FUN_0055ea10();
        FUN_00886c00(&iStack_18,auStack_144);
        uStack_8._0_1_ = 0x2f;
        FUN_00557fc0(&piStack_3c);
        FUN_0057f8e0(uVar9);
        FUN_0056e380();
        FUN_0056e380();
        FUN_0056d930();
        uStack_8._0_1_ = 0x2c;
        FUN_008eb110();
        FUN_0151f430();
        if (*(char *)(piStack_3c + 3) != '\0') {
          FUN_0054db20();
          uVar9 = FUN_00576e70();
          FUN_005500e0(uVar9);
                    /* WARNING: Subroutine does not return */
          FUN_0170c2a8(auStack_1c,&DAT_01c17198);
        }
        FUN_00557fc0(piStack_3c + 1);
        FUN_00550b30();
        FUN_005507b0();
        FUN_005705c0();
        FUN_00551650();
        FUN_00550800();
        uStack_8 = CONCAT31(uStack_8._1_3_,0x30);
        goto LAB_005837b0;
      }
      goto LAB_00583b3d;
    }
  }
  else {
    FUN_005569d0(auStack_fc);
    uStack_8._0_1_ = 0x28;
    uVar9 = FUN_005543f0();
    uVar9 = FUN_01675640(auStack_15c,"Failed to open script file %s",uVar9);
    uStack_8._0_1_ = 0x29;
    FUN_005899f0(apppuStack_54,uVar9,param_4);
    uVar3 = (undefined)uStack_8;
  }
  uStack_8._0_1_ = uVar3;
  FUN_0054eff0("Empty script source");
  uStack_8._0_1_ = 0x2b;
  FUN_005899f0(apppuStack_54,auStack_fc,param_4);
  uVar3 = (undefined)uStack_8;
LAB_00583b3d:
  uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("The DataModel is closed");
}



/* FUNCTION 3943 ; VA 0x00583b80 ; FUN_00583b80 */

/* WARNING: Type propagation algorithm not settling */

int * FUN_00583b80(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined *param_4)

{
  int *piVar1;
  bool bVar2;
  char cVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int *piVar7;
  int iVar8;
  undefined4 *******pppppppuVar9;
  undefined4 *******pppppppuVar10;
  int iVar11;
  uint uVar12;
  char *pcVar13;
  undefined4 uVar14;
  undefined4 *******apppppppuStack_7c [4];
  undefined4 uStack_6c;
  uint uStack_68;
  undefined auStack_64 [16];
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *******apppppppuStack_4c [3];
  undefined4 *puStack_40;
  undefined4 *puStack_3c;
  uint uStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  int iStack_2c;
  undefined auStack_28 [4];
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017965c3;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  *param_4 = 0;
  cStack_11 = '\0';
  uStack_1c = 0xffffffff;
  puStack_3c = (undefined4 *)0x0;
  uStack_38 = 0xf;
  apppppppuStack_4c[0] = (undefined4 *******)((uint)apppppppuStack_4c[0] & 0xffffff00);
  FUN_005542c0("Settings",8);
  uStack_8 = 0;
  uStack_18 = 1;
  piVar4 = (int *)FUN_00580040(&uStack_24,apppppppuStack_4c);
  iVar11 = *piVar4;
  if ((iVar11 == 0) ||
     (piVar7 = *(int **)(iVar11 + 0x20), piVar4 = (int *)FUN_008881d0(), piVar7 != piVar4)) {
    bVar2 = true;
  }
  else {
    bVar2 = false;
  }
  uStack_8 = 0xffffffff;
  if (0xf < uStack_38) {
    uVar12 = uStack_38 + 1;
    pppppppuVar9 = apppppppuStack_4c[0];
    if (0xfff < uVar12) {
      pppppppuVar9 = (undefined4 *******)apppppppuStack_4c[0][-1];
      uVar12 = uStack_38 + 0x24;
      if (0x1f < (uint)((int)apppppppuStack_4c[0] + (-4 - (int)pppppppuVar9))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    piVar4 = (int *)FUN_01674ea0(pppppppuVar9,uVar12);
  }
  puStack_3c = (undefined4 *)0x0;
  uStack_38 = 0xf;
  apppppppuStack_4c[0] = (undefined4 *******)((uint)apppppppuStack_4c[0] & 0xffffff00);
  if (bVar2) {
    ExceptionList = pvStack_10;
    return piVar4;
  }
  iVar8 = *(int *)(iVar11 + 0x20);
  iVar5 = FUN_008881d0();
  if (iVar8 != iVar5) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar6 = (undefined4 *)(iVar11 + 0x28);
  if (*(int *)(iVar11 + 0x24) == 0) {
    puVar6 = (undefined4 *)0x0;
  }
  piVar4 = (int *)puVar6[1];
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar4[1] = piVar4[1] + 1;
    UNLOCK();
    piVar4 = (int *)puVar6[1];
  }
  uStack_34 = *puVar6;
  uStack_8 = 1;
  puStack_3c = (undefined4 *)0x0;
  uStack_38 = 0xf;
  apppppppuStack_4c[0] = (undefined4 *******)((uint)apppppppuStack_4c[0] & 0xffffff00);
  piStack_30 = piVar4;
  uStack_24 = uStack_34;
  piStack_20 = piVar4;
  FUN_005542c0(&DAT_018bee70,6);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uStack_18 = 2;
  piVar7 = (int *)FUN_00580040(auStack_28,apppppppuStack_4c);
  if (*piVar7 == 0) {
LAB_00583cfa:
    param_1._3_1_ = '\x01';
  }
  else {
    iVar11 = *(int *)(*piVar7 + 0x20);
    iVar8 = FUN_0088cb40();
    param_1._3_1_ = '\0';
    if (iVar11 != iVar8) goto LAB_00583cfa;
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  piVar7 = (int *)FUN_005507b0();
  if (param_1._3_1_ != '\0') goto LAB_00583ee7;
  FUN_00563690(apppppppuStack_7c);
  pppppppuVar9 = apppppppuStack_7c;
  if (0xf < uStack_68) {
    pppppppuVar9 = apppppppuStack_7c[0];
  }
  uStack_8._0_1_ = 3;
  cVar3 = FUN_0055c360(pppppppuVar9,uStack_6c,"Shutdown",8);
  if (cVar3 != '\0') {
    uStack_54 = 0;
    uStack_50 = 0xf;
    auStack_64[0] = 0;
    FUN_005542c0("Reason",6);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    uStack_18 = 4;
    piVar7 = (int *)FUN_00580040(auStack_28,auStack_64);
    if (*piVar7 == 0) {
LAB_00583da0:
      param_1._3_1_ = '\0';
    }
    else {
      iVar11 = *(int *)(*piVar7 + 0x20);
      iVar8 = FUN_0088cb40();
      param_1._3_1_ = '\x01';
      if (iVar11 != iVar8) goto LAB_00583da0;
    }
    uStack_8._0_1_ = 3;
    uStack_8._1_3_ = 0;
    FUN_005507b0();
    if (param_1._3_1_ != '\0') {
      FUN_00563690(apppppppuStack_4c);
      uVar12 = uStack_38;
      pppppppuVar9 = apppppppuStack_4c[0];
      pcVar13 = "Developer";
      pppppppuVar10 = apppppppuStack_4c;
      if (0xf < uStack_38) {
        pppppppuVar10 = apppppppuStack_4c[0];
      }
      puVar6 = puStack_3c;
      cVar3 = FUN_0055c360(pppppppuVar10,puStack_3c,"Developer",9);
      if (cVar3 == '\0') {
        pcVar13 = "Roblox";
        pppppppuVar10 = apppppppuStack_4c;
        if (0xf < uVar12) {
          pppppppuVar10 = pppppppuVar9;
        }
        puVar6 = puStack_3c;
        cVar3 = FUN_0055c360(pppppppuVar10,puStack_3c,"Roblox",6);
        if (cVar3 != '\0') {
          uStack_1c = 0x113;
          goto LAB_00583e1e;
        }
      }
      else {
        uStack_1c = 0x112;
LAB_00583e1e:
        cStack_11 = '\x01';
      }
      FUN_005507b0();
      if (cStack_11 != '\0') {
        uVar14 = 1;
        FUN_00557fc0(param_3);
        FUN_008e9510(puVar6,pcVar13,uVar14);
        uStack_8._0_1_ = 5;
        piVar7 = (int *)FUN_00562e40();
        if (piVar7 != (int *)0x0) {
          (**(code **)(*piVar7 + 0x40))(&iStack_2c);
          uStack_8._0_1_ = 6;
          if (iStack_2c != 0) {
            FUN_00569460(iStack_2c);
            uVar14 = uStack_1c;
            uStack_8._0_1_ = 7;
            puVar6 = puStack_40;
            if (puStack_40 != puStack_3c) {
              do {
                piVar4 = (int *)FUN_00562c50(*puVar6);
                if ((piVar4 != (int *)0x0) &&
                   (iVar11 = (**(code **)(*piVar4 + 0xb4))(), iVar11 != 0)) {
                  FUN_0062b8c0(uVar14);
                }
                puVar6 = puVar6 + 2;
                piVar4 = piStack_20;
              } while (puVar6 != puStack_3c);
            }
            FUN_00577ac0();
          }
          FUN_00550b30();
        }
        *param_4 = 1;
        FUN_008eb110();
      }
    }
  }
  piVar7 = (int *)FUN_005507b0();
LAB_00583ee7:
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar1 = piVar4 + 1;
    iVar11 = *piVar1;
    piVar7 = (int *)*piVar1;
    *piVar1 = iVar11 + -1;
    UNLOCK();
    if (iVar11 + -1 == 0) {
      piVar7 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar11 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar11 == 1) {
        piVar7 = (int *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar7;
}



/* FUNCTION 3944 ; VA 0x00583f30 ; FUN_00583f30 */

/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 ******
FUN_00583f30(undefined4 *******param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4)

{
  undefined4 *******pppppppuVar1;
  undefined4 ***pppuVar2;
  undefined4 *****pppppuVar3;
  undefined4 ******ppppppuVar4;
  undefined4 ****ppppuVar5;
  int iVar6;
  int iVar7;
  undefined uVar8;
  char cVar9;
  undefined4 ******ppppppuVar10;
  undefined4 ****ppppuVar11;
  undefined4 uVar12;
  undefined4 *puVar13;
  undefined4 *******pppppppuVar14;
  int *piVar15;
  int iVar16;
  undefined4 *****pppppuVar17;
  uint uVar18;
  longlong lVar19;
  undefined4 uStack_1f0;
  undefined4 uStack_1ec;
  undefined8 uStack_1e8;
  undefined4 uStack_1e0;
  undefined *puStack_1dc;
  undefined4 uStack_1d8;
  char *pcStack_1d4;
  undefined *puStack_1d0;
  undefined4 uStack_1cc;
  undefined4 *******pppppppuStack_1c8;
  undefined4 ******ppppppuStack_1c4;
  undefined8 uStack_1c0;
  undefined auStack_1b0 [32];
  undefined auStack_190 [88];
  undefined auStack_138 [24];
  undefined auStack_120 [24];
  undefined auStack_108 [64];
  undefined4 ******appppppuStack_c8 [6];
  undefined4 *******apppppppuStack_b0 [4];
  int iStack_a0;
  uint uStack_9c;
  undefined4 *******pppppppuStack_98;
  undefined4 ******ppppppuStack_94;
  undefined4 ******ppppppuStack_90;
  undefined4 ******ppppppuStack_8c;
  undefined8 uStack_88;
  undefined4 ******ppppppuStack_80;
  undefined4 ****ppppuStack_7c;
  undefined8 uStack_78;
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  undefined4 *******apppppppuStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  undefined4 *******apppppppuStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 ****ppppuStack_28;
  undefined4 uStack_24;
  undefined4 ******ppppppuStack_20;
  longlong lStack_1c;
  undefined4 *******pppppppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017966cd;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  uStack_1c0._4_4_ = (char *)0x8;
  uStack_1c0._0_4_ = "Settings";
  uStack_48 = 0;
  uStack_44 = 0xf;
  apppppppuStack_58[0] = (undefined4 *******)((uint)apppppppuStack_58[0] & 0xffffff00);
  ppppppuStack_1c4 = (undefined4 ******)0x583f7d;
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  uStack_1c0._4_4_ = (char *)apppppppuStack_58;
  uStack_8 = 0;
  uStack_1c0._0_4_ = (char *)&ppppppuStack_20;
  uStack_24 = 1;
  ppppppuStack_1c4 = (undefined4 ******)0x583f9a;
  ppppppuVar10 = (undefined4 ******)FUN_00580040();
  pppppuVar3 = *ppppppuVar10;
  if (pppppuVar3 == (undefined4 *****)0x0) {
LAB_00583fb0:
    param_1 = (undefined4 *******)((uint)param_1 & 0xffffff);
  }
  else {
    ppppppuVar4 = (undefined4 ******)pppppuVar3[8];
    uStack_1c0._4_4_ = (char *)0x583fa8;
    ppppppuVar10 = (undefined4 ******)FUN_008881d0();
    param_1 = (undefined4 *******)CONCAT13(1,param_1._0_3_);
    if (ppppppuVar4 != ppppppuVar10) goto LAB_00583fb0;
  }
  uStack_8 = 0xffffffff;
  if (0xf < uStack_44) {
    uStack_1c0._4_4_ = (char *)(uStack_44 + 1);
    pppppppuVar14 = apppppppuStack_58[0];
    if (0xfff < uStack_1c0._4_4_) {
      pppppppuVar14 = (undefined4 *******)apppppppuStack_58[0][-1];
      uStack_1c0._4_4_ = (char *)(uStack_44 + 0x24);
      if (0x1f < (uint)((int)apppppppuStack_58[0] + (-4 - (int)pppppppuVar14))) {
                    /* WARNING: Subroutine does not return */
        uStack_1c0._4_4_ = (char *)0x584807;
        FUN_017167a3();
      }
    }
    ppppppuStack_1c4 = (undefined4 ******)0x583fec;
    uStack_1c0._0_4_ = (char *)pppppppuVar14;
    ppppppuVar10 = (undefined4 ******)FUN_01674ea0();
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  apppppppuStack_58[0] = (undefined4 *******)((uint)apppppppuStack_58[0] & 0xffffff00);
  if (param_1._3_1_ == '\0') {
    ExceptionList = pvStack_10;
    return ppppppuVar10;
  }
  ppppuVar5 = pppppuVar3[8];
  uStack_1c0._4_4_ = (char *)0x584013;
  ppppuVar11 = (undefined4 ****)FUN_008881d0();
  if (ppppuVar5 != ppppuVar11) {
    uStack_1c0._4_4_ = "Variant cast failed";
                    /* WARNING: Subroutine does not return */
    uStack_1c0._0_4_ = (char *)0x584811;
    FUN_016757c0();
  }
  pppppuVar17 = pppppuVar3 + 10;
  if (pppppuVar3[9] == (undefined4 ****)0x0) {
    pppppuVar17 = (undefined4 *****)0x0;
  }
  ppppuStack_7c = pppppuVar17[1];
  if (ppppuStack_7c != (undefined4 ****)0x0) {
    LOCK();
    ppppuStack_7c[1] = (undefined4 ***)((int)ppppuStack_7c[1] + 1);
    UNLOCK();
    ppppuStack_7c = pppppuVar17[1];
  }
  ppppppuStack_80 = (undefined4 ******)*pppppuVar17;
  uStack_1c0._4_4_ = (char *)0x0;
  uStack_1c0._0_4_ = &DAT_018bc9b8;
  uStack_8 = 1;
  uStack_30 = 0;
  uStack_2c = 0xf;
  apppppppuStack_40[0] = (undefined4 *******)((uint)apppppppuStack_40[0] & 0xffffff00);
  ppppppuStack_1c4 = (undefined4 ******)0x58406d;
  ppppuStack_28 = ppppuStack_7c;
  ppppppuStack_20 = ppppppuStack_80;
  FUN_005542c0();
  uStack_1c0._4_4_ = (char *)0xc;
  uStack_1c0._0_4_ = "JobSignature";
  uStack_8._0_1_ = 2;
  uStack_48 = 0;
  uStack_44 = 0xf;
  apppppppuStack_58[0] = (undefined4 *******)((uint)apppppppuStack_58[0] & 0xffffff00);
  ppppppuStack_1c4 = (undefined4 ******)0x584092;
  FUN_005542c0();
  uStack_1c0._4_4_ = (char *)apppppppuStack_40;
  uStack_8._0_1_ = 3;
  uStack_1c0._0_4_ = (char *)apppppppuStack_58;
  ppppppuStack_1c4 = &ppppppuStack_80;
  pppppppuStack_1c8 = apppppppuStack_b0;
  uStack_1cc = 0x5840ae;
  FUN_00563a00();
  uStack_8._0_1_ = 5;
  uVar8 = (undefined)uStack_8;
  uStack_8._0_1_ = 5;
  if (0xf < uStack_44) {
    uStack_1c0._4_4_ = (char *)(uStack_44 + 1);
    pppppppuVar14 = apppppppuStack_58[0];
    if (0xfff < uStack_1c0._4_4_) {
      pppppppuVar14 = (undefined4 *******)apppppppuStack_58[0][-1];
      uStack_1c0._4_4_ = (char *)(uStack_44 + 0x24);
      if (0x1f < (uint)((int)apppppppuStack_58[0] + (-4 - (int)pppppppuVar14))) {
                    /* WARNING: Subroutine does not return */
        uStack_1c0._4_4_ = (char *)0x584816;
        uStack_8._0_1_ = uVar8;
        FUN_017167a3();
      }
    }
    ppppppuStack_1c4 = (undefined4 ******)0x5840e6;
    uStack_1c0._0_4_ = (char *)pppppppuVar14;
    FUN_01674ea0();
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  apppppppuStack_58[0] = (undefined4 *******)((uint)apppppppuStack_58[0] & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (0xf < uStack_2c) {
    uStack_1c0._4_4_ = (char *)(uStack_2c + 1);
    pppppppuVar14 = apppppppuStack_40[0];
    if (0xfff < uStack_1c0._4_4_) {
      pppppppuVar14 = (undefined4 *******)apppppppuStack_40[0][-1];
      uStack_1c0._4_4_ = (char *)(uStack_2c + 0x24);
      if (0x1f < (uint)((int)apppppppuStack_40[0] + (-4 - (int)pppppppuVar14))) {
                    /* WARNING: Subroutine does not return */
        uStack_1c0._4_4_ = (char *)0x58481b;
        FUN_017167a3();
      }
    }
    ppppppuStack_1c4 = (undefined4 ******)0x584130;
    uStack_1c0._0_4_ = (char *)pppppppuVar14;
    FUN_01674ea0();
  }
  if (iStack_a0 != 0) {
    uStack_1c0._4_4_ = (char *)iStack_a0;
    uStack_1c0._0_4_ = (char *)apppppppuStack_b0;
    if (0xf < uStack_9c) {
      uStack_1c0._0_4_ = (char *)apppppppuStack_b0[0];
    }
    ppppppuStack_1c4 = (undefined4 ******)0x58415d;
    FUN_005542c0();
  }
  uStack_1c0._4_4_ = (char *)0x7;
  uStack_1c0._0_4_ = "PlaceId";
  uStack_30 = 0;
  uStack_2c = 0xf;
  apppppppuStack_40[0] = (undefined4 *******)((uint)apppppppuStack_40[0] & 0xffffff00);
  ppppppuStack_1c4 = (undefined4 ******)0x58417e;
  FUN_005542c0();
  uStack_1c0._4_4_ = (char *)apppppppuStack_40;
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  uStack_1c0._0_4_ = (char *)&param_1;
  uStack_78 = 0;
  ppppppuStack_1c4 = (undefined4 ******)0x584199;
  FUN_00580040();
  lStack_1c = uStack_78;
  if ((param_1 != (undefined4 *******)0x0) &&
     (*(char *)(*(int *)((int)param_1 + 0x20) + 0x21) != '\0')) {
    uStack_1c0._4_4_ = (char *)0x5841b2;
    lStack_1c = FUN_00563790();
  }
  uStack_8._0_1_ = 6;
  if (0xf < uStack_2c) {
    uStack_1c0._4_4_ = (char *)(uStack_2c + 1);
    pppppppuVar14 = apppppppuStack_40[0];
    if (0xfff < uStack_1c0._4_4_) {
      pppppppuVar14 = (undefined4 *******)apppppppuStack_40[0][-1];
      uStack_1c0._4_4_ = (char *)(uStack_2c + 0x24);
      if (0x1f < (uint)((int)apppppppuStack_40[0] + (-4 - (int)pppppppuVar14))) {
                    /* WARNING: Subroutine does not return */
        uStack_1c0._4_4_ = (char *)0x584820;
        FUN_017167a3();
      }
    }
    ppppppuStack_1c4 = (undefined4 ******)0x5841f8;
    uStack_1c0._0_4_ = (char *)pppppppuVar14;
    FUN_01674ea0();
  }
  uStack_1c0._4_4_ = (char *)0x0;
  uStack_1c0._0_4_ = &DAT_018bc9b8;
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  ppppppuStack_1c4 = (undefined4 ******)0x58421c;
  FUN_005542c0();
  uStack_1c0._4_4_ = (char *)0xd;
  uStack_1c0._0_4_ = "PlaceFetchUrl";
  uStack_8._0_1_ = 8;
  uStack_30 = 0;
  uStack_2c = 0xf;
  apppppppuStack_40[0] = (undefined4 *******)((uint)apppppppuStack_40[0] & 0xffffff00);
  ppppppuStack_1c4 = (undefined4 ******)0x584241;
  FUN_005542c0();
  uStack_1c0._4_4_ = (char *)auStack_70;
  uStack_8._0_1_ = 9;
  uStack_1c0._0_4_ = (char *)apppppppuStack_40;
  ppppppuStack_1c4 = &ppppppuStack_80;
  pppppppuStack_1c8 = &pppppppuStack_98;
  uStack_1cc = 0x58425d;
  FUN_00563a00();
  uStack_8._0_1_ = 0xb;
  uVar8 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xb;
  if (0xf < uStack_2c) {
    uStack_1c0._4_4_ = (char *)(uStack_2c + 1);
    pppppppuVar14 = apppppppuStack_40[0];
    if (0xfff < uStack_1c0._4_4_) {
      pppppppuVar14 = (undefined4 *******)apppppppuStack_40[0][-1];
      uStack_1c0._4_4_ = (char *)(uStack_2c + 0x24);
      if (0x1f < (uint)((int)apppppppuStack_40[0] + (-4 - (int)pppppppuVar14))) {
                    /* WARNING: Subroutine does not return */
        uStack_1c0._4_4_ = (char *)0x584825;
        uStack_8._0_1_ = uVar8;
        FUN_017167a3();
      }
    }
    ppppppuStack_1c4 = (undefined4 ******)0x584295;
    uStack_1c0._0_4_ = (char *)pppppppuVar14;
    FUN_01674ea0();
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  apppppppuStack_40[0] = (undefined4 *******)((uint)apppppppuStack_40[0] & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  if (0xf < uStack_5c) {
    uStack_1c0._4_4_ = (char *)(uStack_5c + 1);
    uVar18 = auStack_70[0];
    if (0xfff < uStack_1c0._4_4_) {
      uVar18 = *(uint *)(auStack_70[0] - 4);
      uStack_1c0._4_4_ = (char *)(uStack_5c + 0x24);
      if (0x1f < (auStack_70[0] - uVar18) - 4) {
                    /* WARNING: Subroutine does not return */
        uStack_1c0._4_4_ = (char *)0x58482a;
        FUN_017167a3();
      }
    }
    ppppppuStack_1c4 = (undefined4 ******)0x5842df;
    uStack_1c0._0_4_ = (char *)uVar18;
    FUN_01674ea0();
  }
  if (DAT_01d592f0 == '\0') {
    uStack_1c0._4_4_ = "PlaceId";
    uStack_1c0._0_4_ = (char *)0x5842f9;
    lVar19 = FUN_01678fc0();
    if (lVar19 != 0) {
      if (DAT_01d59104 != 0) {
        pppppppuStack_1c8 = (undefined4 *******)(uint)DAT_01d59104;
        ppppppuStack_1c4 = (undefined4 ******)0x18bed08;
        uStack_1cc = 0x584324;
        uStack_1c0 = lVar19;
        FUN_01677520();
      }
      pppppppuStack_1c8 = appppppuStack_c8;
      ppppppuStack_1c4 = (undefined4 ******)0x18bed24;
      uStack_1cc = 0x584340;
      uStack_1c0 = lVar19;
      lStack_1c = lVar19;
      uVar12 = FUN_01675640();
      uStack_8._0_1_ = 0xd;
      uStack_1cc = 0x58434b;
      uStack_1cc = FUN_0151b370();
      puStack_1d0 = auStack_138;
      pcStack_1d4 = (char *)0x584358;
      uStack_1d8 = FUN_0151f2f0();
      pcStack_1d4 = "assetdelivery";
      puStack_1dc = auStack_120;
      uStack_8._0_1_ = 0xe;
      uStack_1e0 = 0x58436e;
      uStack_1e8._4_4_ = (undefined4 *******)FUN_0151b590();
      uStack_1e8._0_4_ = apppppppuStack_58;
      uStack_8._0_1_ = 0xf;
      uStack_1ec = 0x58437d;
      uStack_1e0 = uVar12;
      puVar13 = (undefined4 *)FUN_00558ba0();
      uStack_1c0._4_4_ = (char *)puVar13[4];
      uStack_8._0_1_ = 0x10;
      if (0xf < (uint)puVar13[5]) {
        puVar13 = (undefined4 *)*puVar13;
      }
      ppppppuStack_1c4 = (undefined4 ******)auStack_1b0;
      pppppppuStack_1c8 = (undefined4 *******)0x5843a2;
      uStack_1c0._0_4_ = (char *)puVar13;
      FUN_0151bda0();
      uStack_1c0._4_4_ = (char *)auStack_70;
      uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
      uStack_1c0._0_4_ = (char *)0x5843b4;
      pppppppuVar14 = (undefined4 *******)FUN_0151bb70();
      if (&pppppppuStack_98 != (undefined4 ********)pppppppuVar14) {
        uStack_1c0._4_4_ = (char *)0x5843c7;
        FUN_005507b0();
        pppppppuStack_98 = (undefined4 *******)*pppppppuVar14;
        ppppppuStack_94 = pppppppuVar14[1];
        ppppppuStack_90 = pppppppuVar14[2];
        ppppppuStack_8c = pppppppuVar14[3];
        uStack_88 = *(undefined8 *)(pppppppuVar14 + 4);
        pppppppuVar14[4] = (undefined4 ******)0x0;
        pppppppuVar14[5] = (undefined4 ******)0xf;
        *(undefined *)pppppppuVar14 = 0;
      }
      uStack_1c0._4_4_ = (char *)0x5843f7;
      FUN_005507b0();
      uStack_1c0._4_4_ = (char *)0x584402;
      FUN_0056d9d0();
      uStack_1c0._4_4_ = (char *)0x58440a;
      FUN_005507b0();
      uStack_1c0._4_4_ = (char *)0x584415;
      FUN_005507b0();
      uStack_1c0._4_4_ = (char *)0x584420;
      FUN_005507b0();
      uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
      uStack_1c0._4_4_ = (char *)0x58442f;
      FUN_005507b0();
    }
  }
  if (lStack_1c != 0) {
    pppppppuStack_1c8 = appppppuStack_c8;
    ppppppuStack_1c4 = (undefined4 ******)&DAT_018bed48;
    uStack_1cc = 0x584451;
    uStack_1c0 = lStack_1c;
    puVar13 = (undefined4 *)FUN_01675640();
    if (puVar13 != &DAT_01d79c80) {
      uStack_1c0._4_4_ = (char *)0x584468;
      FUN_005507b0();
      DAT_01d79c80 = *puVar13;
      uRam01d79c84 = puVar13[1];
      uRam01d79c88 = puVar13[2];
      uRam01d79c8c = puVar13[3];
      _DAT_01d79c90 = *(undefined8 *)(puVar13 + 4);
      puVar13[4] = 0;
      puVar13[5] = 0xf;
      *(undefined *)puVar13 = 0;
    }
    uStack_1c0._4_4_ = (char *)0x58449b;
    FUN_005507b0();
  }
  if (DAT_01d7a19c != '\0') {
    uStack_1c0._4_4_ = (char *)0x14;
    uStack_1c0._0_4_ = "MatchmakingContextId";
    uStack_60 = 0;
    uStack_5c = 0xf;
    auStack_70[0] = auStack_70[0] & 0xffffff00;
    ppppppuStack_1c4 = (undefined4 ******)0x5844c9;
    FUN_005542c0();
    uStack_1c0._4_4_ = (char *)auStack_70;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
    uStack_1c0._0_4_ = (char *)&param_1;
    uVar12 = 0xffffffff;
    ppppppuStack_1c4 = (undefined4 ******)0x5844df;
    FUN_00580040();
    if ((param_1 != (undefined4 *******)0x0) &&
       (*(char *)(*(int *)((int)param_1 + 0x20) + 0x21) != '\0')) {
      uStack_1c0._4_4_ = (char *)0x5844f8;
      uVar12 = FUN_00563070();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    uStack_1c0._4_4_ = (char *)0x584506;
    FUN_005507b0();
    ppppppuStack_1c4 = appppppuStack_c8;
    uStack_1c0._0_4_ = &DAT_018bed68;
    pppppppuStack_1c8 = (undefined4 *******)0x584518;
    uStack_1c0._4_4_ = (char *)uVar12;
    puVar13 = (undefined4 *)FUN_01675640();
    if (puVar13 != (undefined4 *)&DAT_01d79cc8) {
      uStack_1c0._4_4_ = (char *)0x58452f;
      FUN_005507b0();
      _DAT_01d79cc8 = *puVar13;
      uRam01d79ccc = puVar13[1];
      uRam01d79cd0 = puVar13[2];
      uRam01d79cd4 = puVar13[3];
      _DAT_01d79cd8 = *(undefined8 *)(puVar13 + 4);
      puVar13[4] = 0;
      puVar13[5] = 0xf;
      *(undefined *)puVar13 = 0;
    }
    uStack_1c0._4_4_ = (char *)0x584562;
    FUN_005507b0();
  }
  uStack_1c0._4_4_ = (char *)0x8;
  uStack_1c0._0_4_ = "Metadata";
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  ppppppuStack_1c4 = (undefined4 ******)0x584583;
  FUN_005542c0();
  uStack_1c0._4_4_ = (char *)auStack_70;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
  uStack_1c0._0_4_ = (char *)((int)&uStack_78 + 4);
  uStack_24 = 2;
  ppppppuStack_1c4 = (undefined4 ******)0x58459d;
  piVar15 = (int *)FUN_00580040();
  iVar6 = *piVar15;
  if (iVar6 != 0) {
    iVar7 = *(int *)(iVar6 + 0x20);
    uStack_1c0._4_4_ = (char *)0x5845ab;
    iVar16 = FUN_0088cb40();
    param_1 = (undefined4 *******)CONCAT13(1,param_1._0_3_);
    if (iVar7 == iVar16) goto LAB_005845b7;
  }
  param_1 = (undefined4 *******)((uint)param_1 & 0xffffff);
LAB_005845b7:
  uStack_8 = 0xc;
  uStack_1c0._4_4_ = (char *)0x5845c6;
  FUN_005507b0();
  if (param_1._3_1_ != '\0') {
    iVar7 = *(int *)(iVar6 + 0x20);
    uStack_1c0._4_4_ = (char *)0x5845d4;
    iVar16 = FUN_0088cb40();
    if (iVar7 != iVar16) {
      uStack_1c0._4_4_ = "Variant cast failed";
                    /* WARNING: Subroutine does not return */
      uStack_1c0._0_4_ = (char *)0x584834;
      FUN_016757c0();
    }
    uStack_1c0._4_4_ = (char *)(iVar6 + 0x28);
    if (*(int *)(iVar6 + 0x24) == 0) {
      uStack_1c0._4_4_ = (char *)0x0;
    }
    uStack_1c0._0_4_ = (char *)0x5845ed;
    FUN_00584860();
  }
  ppppuVar5 = ppppuStack_28;
  uStack_1c0._4_4_ = (char *)param_3[1];
  uStack_1c0._0_4_ = (char *)*param_3;
  param_1 = &pppppppuStack_1c8;
  if (ppppuStack_28 != (undefined4 ****)0x0) {
    LOCK();
    ppppuStack_28[1] = (undefined4 ***)((int)ppppuStack_28[1] + 1);
    UNLOCK();
  }
  pppppppuStack_1c8 = (undefined4 *******)ppppppuStack_20;
  ppppppuStack_1c4 = (undefined4 ******)ppppuStack_28;
  uStack_8._0_1_ = 0x14;
  uStack_1e8._4_4_ = &pppppppuStack_98;
  uStack_78 = CONCAT44(&uStack_1e0,(undefined4)uStack_78);
  uStack_1e8._0_4_ = (undefined4 *******)0x584638;
  FUN_0054ef60();
  ppppuStack_28 = (undefined4 ****)&uStack_1f0;
  if (param_4[1] != 0) {
    LOCK();
    piVar15 = (int *)(param_4[1] + 4);
    *piVar15 = *piVar15 + 1;
    UNLOCK();
  }
  uStack_1f0 = *param_4;
  uStack_1ec = param_4[1];
  uStack_8._0_1_ = 0x16;
  uStack_1e8 = lStack_1c;
  FUN_0054ef60(param_2);
  uStack_8._0_1_ = 0xc;
  uStack_1c0._4_4_ = (char *)FUN_0055d0a0(auStack_190,FUN_00580100);
  uStack_1c0._0_4_ = (char *)0x5846a0;
  FUN_00565a80();
  uStack_1c0._4_4_ = auStack_108;
  uStack_8._0_1_ = 0x18;
  uStack_1c0._0_4_ = (char *)0x5846b0;
  pppppppuStack_14 = (undefined4 *******)FUN_0056f390();
  if (pppppppuStack_14 != (undefined4 *******)0x0) {
    LOCK();
    pppppppuStack_14[1] = (undefined4 ******)((int)pppppppuStack_14[1] + 1);
    UNLOCK();
  }
  uStack_8._0_1_ = 0x1a;
  uStack_1c0._4_4_ = (char *)0x5846cd;
  FUN_0056cf50();
  uStack_1c0._4_4_ = (char *)0x5846d5;
  cVar9 = FUN_0168a8f0();
  if (cVar9 != '\0') {
    uStack_8._0_1_ = 0x1d;
    uStack_1c0._4_4_ = (char *)0x5846ec;
    FUN_0056cf50();
    uStack_1c0._4_4_ = (char *)0x5846f4;
    FUN_016899e0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0x1e);
    uStack_1c0._4_4_ = (char *)0x584700;
    ppppppuVar10 = (undefined4 ******)FUN_016899e0();
    pppppppuVar14 = pppppppuStack_14;
    if (pppppppuStack_14 != (undefined4 *******)0x0) {
      LOCK();
      pppppppuVar1 = pppppppuStack_14 + 1;
      ppppppuVar4 = *pppppppuVar1;
      ppppppuVar10 = *pppppppuVar1;
      *pppppppuVar1 = (undefined4 ******)((int)ppppppuVar4 + -1);
      UNLOCK();
      if ((undefined4 ******)((int)ppppppuVar4 + -1) == (undefined4 ******)0x0) {
        uStack_1c0._4_4_ = (char *)0x0;
        uStack_1c0._0_4_ = "Wj";
        (*(code *)**pppppppuStack_14)();
        uStack_1c0._0_4_ = (char *)pppppppuVar14;
        ppppppuStack_1c4 = (undefined4 ******)0x0;
        pppppppuStack_1c8 = (undefined4 *******)0x584722;
        pppppppuStack_1c8 = (undefined4 *******)GetProcessHeap();
        uStack_1cc = 0x584729;
        ppppppuVar10 = (undefined4 ******)HeapFree();
      }
    }
    if (0xf < uStack_88._4_4_) {
      uStack_1c0._4_4_ = (char *)(uStack_88._4_4_ + 1);
      pppppppuVar14 = pppppppuStack_98;
      if (0xfff < uStack_1c0._4_4_) {
        pppppppuVar14 = (undefined4 *******)pppppppuStack_98[-1];
        uStack_1c0._4_4_ = (char *)(uStack_88._4_4_ + 0x24);
        if (0x1f < (uint)((int)pppppppuStack_98 + (-4 - (int)pppppppuVar14))) {
                    /* WARNING: Subroutine does not return */
          uStack_1c0._4_4_ = (char *)0x58484e;
          FUN_017167a3();
        }
      }
      ppppppuStack_1c4 = (undefined4 ******)0x58475d;
      uStack_1c0._0_4_ = (char *)pppppppuVar14;
      ppppppuVar10 = (undefined4 ******)FUN_01674ea0();
    }
    uStack_88 = 0xf00000000;
    pppppppuStack_98 = (undefined4 *******)((uint)pppppppuStack_98 & 0xffffff00);
    if (0xf < uStack_9c) {
      uStack_1c0._4_4_ = (char *)(uStack_9c + 1);
      pppppppuVar14 = apppppppuStack_b0[0];
      if (0xfff < uStack_1c0._4_4_) {
        pppppppuVar14 = (undefined4 *******)apppppppuStack_b0[0][-1];
        uStack_1c0._4_4_ = (char *)(uStack_9c + 0x24);
        if (0x1f < (uint)((int)apppppppuStack_b0[0] + (-4 - (int)pppppppuVar14))) {
                    /* WARNING: Subroutine does not return */
          uStack_1c0._4_4_ = &UNK_00584853;
          FUN_017167a3();
        }
      }
      ppppppuStack_1c4 = (undefined4 ******)0x5847af;
      uStack_1c0._0_4_ = (char *)pppppppuVar14;
      ppppppuVar10 = (undefined4 ******)FUN_01674ea0();
    }
    iStack_a0 = 0;
    uStack_9c = 0xf;
    apppppppuStack_b0[0] = (undefined4 *******)((uint)apppppppuStack_b0[0] & 0xffffff00);
    if (ppppuVar5 != (undefined4 ****)0x0) {
      LOCK();
      ppppuVar11 = ppppuVar5 + 1;
      pppuVar2 = *ppppuVar11;
      ppppppuVar10 = (undefined4 ******)*ppppuVar11;
      *ppppuVar11 = (undefined4 ***)((int)pppuVar2 + -1);
      UNLOCK();
      if ((undefined4 ***)((int)pppuVar2 + -1) == (undefined4 ***)0x0) {
        uStack_1c0._4_4_ = (char *)0x5847e3;
        ppppppuVar10 = (undefined4 ******)(*(code *)**ppppuVar5)();
        LOCK();
        ppppuVar11 = ppppuVar5 + 2;
        pppuVar2 = *ppppuVar11;
        *ppppuVar11 = (undefined4 ***)((int)*ppppuVar11 + -1);
        UNLOCK();
        if (pppuVar2 == (undefined4 ***)0x1) {
          uStack_1c0._4_4_ = (char *)0x5847f2;
          ppppppuVar10 = (undefined4 ******)(*(code *)(*ppppuVar5)[1])();
        }
      }
    }
    ExceptionList = pvStack_10;
    return ppppppuVar10;
  }
  uStack_1c0._4_4_ = (char *)0x58483f;
  uStack_1c0._4_4_ = (char *)FUN_005503c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x1b);
                    /* WARNING: Subroutine does not return */
  uStack_1c0._0_4_ = (char *)0x584849;
  FUN_0054e630();
}



/* FUNCTION 3945 ; VA 0x00584860 ; FUN_00584860 */

uint FUN_00584860(undefined4 *param_1)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  bool bVar6;
  uint uVar7;
  int *piVar8;
  int iVar9;
  undefined4 *puVar10;
  int *piVar11;
  undefined auStack_40 [16];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined auStack_20 [4];
  undefined4 uStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796709;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  ExceptionList = &pvStack_10;
  if (DAT_01d59104 != '\0') {
    puVar10 = param_1;
    if (0xf < (uint)param_1[5]) {
      puVar10 = (undefined4 *)*param_1;
    }
    ExceptionList = &pvStack_10;
    FUN_01677520(DAT_01d59104,"Metadata: [%s]",puVar10);
  }
  uStack_28 = 0;
  piStack_24 = (int *)0x0;
  uStack_8 = 0;
  uVar7 = FUN_0098f070(param_1,&uStack_28,0);
  if ((char)uVar7 == '\0') goto LAB_00584a53;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = 0;
  FUN_005542c0("ResourceLimits",0xe);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  piStack_18 = (int *)0x1;
  piVar8 = (int *)FUN_00580040(auStack_20,auStack_40);
  iVar3 = *piVar8;
  if (iVar3 == 0) {
LAB_00584943:
    bVar6 = false;
  }
  else {
    iVar4 = *(int *)(iVar3 + 0x20);
    iVar9 = FUN_008881d0();
    if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar8 = (int *)(iVar3 + 0x28);
    if (*(int *)(iVar3 + 0x24) == 0) {
      piVar8 = (int *)0x0;
    }
    if (*piVar8 == 0) goto LAB_00584943;
    bVar6 = true;
  }
  uStack_8 = 0;
  uVar7 = FUN_005507b0();
  if (bVar6) {
    iVar4 = *(int *)(iVar3 + 0x20);
    iVar9 = FUN_008881d0();
    if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar10 = (undefined4 *)(iVar3 + 0x28);
    if (*(int *)(iVar3 + 0x24) == 0) {
      puVar10 = (undefined4 *)0x0;
    }
    piVar8 = (int *)puVar10[1];
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar8[1] = piVar8[1] + 1;
      UNLOCK();
      piVar8 = (int *)puVar10[1];
    }
    uStack_1c = *puVar10;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = 0;
    piStack_18 = piVar8;
    FUN_005542c0("MaximumThreads",0xe);
    piVar11 = (int *)FUN_00580040(auStack_20,auStack_40);
    iVar3 = *piVar11;
    if ((iVar3 == 0) || (cStack_11 = '\x01', *(char *)(*(int *)(iVar3 + 0x20) + 0x21) == '\0')) {
      cStack_11 = '\0';
    }
    uVar7 = FUN_005507b0();
    if (cStack_11 != '\0') {
      iVar4 = *(int *)(iVar3 + 0x20);
      iVar9 = FUN_0088c8c0();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar10 = (undefined4 *)(iVar3 + 0x28);
      if (*(int *)(iVar3 + 0x24) == 0) {
        puVar10 = (undefined4 *)0x0;
      }
      uVar5 = *puVar10;
      FUN_0151ddb0(uVar5);
      uVar7 = (uint)DAT_01d59036;
      if (DAT_01d59036 != 0) {
        uVar7 = FUN_01677520(DAT_01d59036,"Maximum threads set to %d via SOAP request GameServer",
                             uVar5);
      }
    }
    if (piVar8 != (int *)0x0) {
      LOCK();
      puVar1 = (uint *)(piVar8 + 1);
      uVar2 = *puVar1;
      uVar7 = *puVar1;
      *puVar1 = uVar2 - 1;
      UNLOCK();
      if (uVar2 - 1 == 0) {
        (**(code **)*piVar8)();
        LOCK();
        puVar1 = (uint *)(piVar8 + 2);
        uVar2 = *puVar1;
        uVar7 = *puVar1;
        *puVar1 = uVar2 - 1;
        UNLOCK();
        if (uVar2 - 1 == 0) {
          uVar7 = (**(code **)(*piVar8 + 4))();
        }
      }
    }
  }
LAB_00584a53:
  piVar8 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_24 + 1);
    uVar2 = *puVar1;
    uVar7 = *puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      uVar7 = (**(code **)*piStack_24)();
      LOCK();
      piVar11 = piVar8 + 2;
      iVar3 = *piVar11;
      *piVar11 = *piVar11 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        uVar7 = (**(code **)(*piVar8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 3946 ; VA 0x00584ab0 ; FUN_00584ab0 */

uint FUN_00584ab0(uint param_1)

{
  byte bVar1;
  uint *puVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 ****ppppuVar9;
  uint uVar10;
  bool bVar11;
  int *piVar12;
  undefined auStack_68 [24];
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  undefined4 ***apppuStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined auStack_18 [4];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01796762;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  piVar12 = (int *)0x0;
  uStack_20 = 0;
  piStack_1c = (int *)0x0;
  uStack_28 = 0;
  uStack_24 = 0xf;
  apppuStack_38[0] = (undefined4 ***)((uint)apppuStack_38[0] & 0xffffff00);
  uStack_8 = 1;
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("MessageVersion",0xe);
  puVar2 = (uint *)FUN_00580040(&uStack_14,auStack_50);
  uVar3 = *puVar2;
  if (uVar3 == 0) {
LAB_00584b3a:
    param_1 = CONCAT13(1,(undefined3)param_1);
  }
  else {
    param_1 = param_1 & 0xffffff;
    bVar1 = *(byte *)(*(int *)(uVar3 + 0x20) + 0x21);
    uVar3 = (uint)bVar1;
    if (bVar1 == 0) goto LAB_00584b3a;
  }
  if (0xf < uStack_3c) {
    uVar10 = uStack_3c + 1;
    uVar3 = auStack_50[0];
    if (0xfff < uVar10) {
      uVar3 = *(uint *)(auStack_50[0] - 4);
      uVar10 = uStack_3c + 0x24;
      if (0x1f < (auStack_50[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uVar3 = FUN_01674ea0(uVar3,uVar10);
  }
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  if (param_1._3_1_ != '\0') goto LAB_00584d78;
  iVar4 = FUN_00563070();
  uVar3 = (uint)DAT_01e90d59;
  if (DAT_01e90d59 != 0) {
    uVar3 = FUN_01677520(DAT_01e90d59,"Soap Microprofiling MessageVersion: %d",iVar4);
  }
  if (iVar4 != 1) goto LAB_00584d78;
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  FUN_005542c0("Settings",8);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uStack_14 = 2;
  piVar5 = (int *)FUN_00580040(auStack_18,auStack_50);
  iVar4 = *piVar5;
  if (iVar4 == 0) {
LAB_00584c0e:
    param_1 = CONCAT13(1,(undefined3)param_1);
  }
  else {
    iVar7 = *(int *)(iVar4 + 0x20);
    iVar6 = FUN_008881d0();
    param_1 = param_1 & 0xffffff;
    if (iVar7 != iVar6) goto LAB_00584c0e;
  }
  uStack_8 = 1;
  uVar3 = FUN_005507b0();
  if (param_1._3_1_ != '\0') goto LAB_00584d78;
  iVar7 = *(int *)(iVar4 + 0x20);
  iVar6 = FUN_008881d0();
  if (iVar7 != iVar6) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  iVar7 = iVar4 + 0x28;
  if (*(int *)(iVar4 + 0x24) == 0) {
    iVar7 = 0;
  }
  FUN_0056ecd0(iVar7);
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  FUN_005542c0("SecondsToRecord",0xf);
  piVar12 = (int *)FUN_00580040(&param_1,auStack_50);
  if ((*piVar12 == 0) || (*(char *)(*(int *)(*piVar12 + 0x20) + 0x21) == '\0')) {
    bVar11 = true;
  }
  else {
    bVar11 = false;
  }
  uVar3 = FUN_005507b0();
  piVar12 = piStack_1c;
  if (bVar11) goto LAB_00584d78;
  param_1 = FUN_00563070();
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  FUN_005542c0("OutputFileName",0xe);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_14 = 8;
  piVar12 = (int *)FUN_00580040(auStack_18,auStack_50);
  if (*piVar12 == 0) {
LAB_00584d02:
    bVar11 = true;
  }
  else {
    iVar4 = *(int *)(*piVar12 + 0x20);
    iVar7 = FUN_0088cb40();
    bVar11 = false;
    if (iVar4 != iVar7) goto LAB_00584d02;
  }
  uStack_8 = 1;
  uVar3 = FUN_005507b0();
  piVar12 = piStack_1c;
  if (!bVar11) {
    uVar8 = FUN_00563690(auStack_68);
    FUN_005511f0(uVar8);
    FUN_005507b0();
    if (DAT_01e90d59 != 0) {
      ppppuVar9 = apppuStack_38;
      if (0xf < uStack_24) {
        ppppuVar9 = (undefined4 ****)apppuStack_38[0];
      }
      FUN_01677520(DAT_01e90d59,"Soap Microprofiling SecondsToRecord: %d, OutputFileName: %s",
                   param_1,ppppuVar9);
    }
    FUN_0054ef60(apppuStack_38);
    uVar3 = FUN_005cdd00();
    piVar12 = piStack_1c;
  }
LAB_00584d78:
  if (0xf < uStack_24) {
    uVar3 = uStack_24 + 1;
    ppppuVar9 = (undefined4 ****)apppuStack_38[0];
    if (0xfff < uVar3) {
      ppppuVar9 = (undefined4 ****)apppuStack_38[0][-1];
      uVar3 = uStack_24 + 0x24;
      if (0x1f < (uint)((int)apppuStack_38[0] + (-4 - (int)ppppuVar9))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uVar3 = FUN_01674ea0(ppppuVar9,uVar3);
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  apppuStack_38[0] = (undefined4 ***)((uint)apppuStack_38[0] & 0xffffff00);
  if (piVar12 != (int *)0x0) {
    LOCK();
    puVar2 = (uint *)(piVar12 + 1);
    uVar10 = *puVar2;
    uVar3 = *puVar2;
    *puVar2 = uVar10 - 1;
    UNLOCK();
    if (uVar10 - 1 == 0) {
      uVar3 = (**(code **)*piVar12)();
      LOCK();
      piVar5 = piVar12 + 2;
      iVar4 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uVar3 = (**(code **)(*piVar12 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 3947 ; VA 0x00584e10 ; FUN_00584e10 */

int * FUN_00584e10(undefined4 *param_1)

{
  uint *puVar1;
  int *piVar2;
  int iVar3;
  code *pcVar4;
  bool bVar5;
  int *piVar6;
  int iVar7;
  undefined4 *puVar8;
  int *piVar9;
  int iVar10;
  undefined4 uVar11;
  uint uVar12;
  uint uVar13;
  undefined auStack_5c [24];
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017967b2;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  puStack_14 = &stack0xffffff98;
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018beea0,6);
  uStack_8 = 0;
  piStack_18 = (int *)0x1;
  piVar6 = (int *)FUN_00580040(&param_1,auStack_44);
  iVar3 = *piVar6;
  if ((iVar3 == 0) ||
     (piVar9 = *(int **)(iVar3 + 0x20), piVar6 = (int *)FUN_008881d0(), piVar9 != piVar6)) {
    bVar5 = true;
  }
  else {
    bVar5 = false;
  }
  uStack_8 = 0xffffffff;
  if (0xf < uStack_30) {
    uVar13 = uStack_30 + 1;
    uVar12 = auStack_44[0];
    if (0xfff < uVar13) {
      uVar12 = *(uint *)(auStack_44[0] - 4);
      uVar13 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar12) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    piVar6 = (int *)FUN_01674ea0(uVar12,uVar13);
  }
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  if (bVar5) {
    ExceptionList = pvStack_10;
    return piVar6;
  }
  iVar10 = *(int *)(iVar3 + 0x20);
  iVar7 = FUN_008881d0();
  if (iVar10 != iVar7) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar8 = (undefined4 *)(iVar3 + 0x28);
  if (*(int *)(iVar3 + 0x24) == 0) {
    puVar8 = (undefined4 *)0x0;
  }
  piVar6 = (int *)puVar8[1];
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar6[1] = piVar6[1] + 1;
    UNLOCK();
    piVar6 = (int *)puVar8[1];
  }
  uStack_2c = *puVar8;
  uStack_8 = 1;
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  piStack_28 = piVar6;
  piStack_1c = piVar6;
  FUN_005542c0("MaximumThreads",0xe);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  piStack_18 = (int *)0x2;
  piVar9 = (int *)FUN_00580040(auStack_20,auStack_44);
  if (*piVar9 == 0) {
LAB_00584f77:
    param_1 = (undefined4 *)((uint)param_1 & 0xffffff);
  }
  else {
    iVar3 = *(int *)(*piVar9 + 0x20);
    iVar10 = FUN_0088cb40();
    param_1 = (undefined4 *)CONCAT13(1,param_1._0_3_);
    if (iVar3 != iVar10) goto LAB_00584f77;
  }
  uStack_8 = 1;
  piVar9 = (int *)FUN_005507b0();
  if (param_1._3_1_ == '\0') {
code_r0x00585048:
    if (piVar6 != (int *)0x0) {
      LOCK();
      puVar1 = (uint *)(piVar6 + 1);
      uVar12 = *puVar1;
      piVar9 = (int *)*puVar1;
      *puVar1 = uVar12 - 1;
      UNLOCK();
      if (uVar12 - 1 == 0) {
        piVar9 = (int *)(**(code **)*piVar6)();
        LOCK();
        piVar2 = piVar6 + 2;
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          piVar9 = (int *)(**(code **)(*piVar6 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return piVar9;
  }
  uStack_8._0_1_ = 3;
  puVar8 = (undefined4 *)FUN_00563690(auStack_5c);
  uStack_8._0_1_ = 4;
  piStack_18 = (int *)FUN_0171689d();
  if (0xf < (uint)puVar8[5]) {
    puVar8 = (undefined4 *)*puVar8;
  }
  *piStack_18 = 0;
  uVar11 = FUN_0171d785(puVar8,&param_1,10);
  if (puVar8 == param_1) {
    FUN_016ddcb9("invalid stoi argument");
  }
  else if (*piStack_18 != 0x22) {
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_005507b0();
    FUN_0151ddb0(uVar11);
    piVar9 = (int *)(uint)DAT_01d59036;
    if (DAT_01d59036 != 0) {
      FUN_01677520(DAT_01d59036,"Maximum threads set to %d via SOAP request",uVar11);
      piVar6 = (int *)FUN_00585048();
      return piVar6;
    }
    goto code_r0x00585048;
  }
  FUN_016ddcf9("stoi argument out of range");
  pcVar4 = (code *)swi(3);
  piVar6 = (int *)(*pcVar4)();
  return piVar6;
}



/* FUNCTION 3948 ; VA 0x00585018 ; Catch@00585018 */

undefined * Catch_00585018(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  if (DAT_01d59036 != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x20) + 4))();
    FUN_01677520(DAT_01d59036,"Failed to set maximum threads, error: %s",uVar1);
  }
  return &DAT_00585045;
}



/* FUNCTION 3949 ; VA 0x00585048 ; FUN_00585048 */

void FUN_00585048(void)

{
  int *piVar1;
  int iVar2;
  int *unaff_EBX;
  int unaff_EBP;
  
  if (unaff_EBX != (int *)0x0) {
    LOCK();
    iVar2 = unaff_EBX[1] + -1;
    unaff_EBX[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*unaff_EBX)();
      LOCK();
      piVar1 = unaff_EBX + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*unaff_EBX + 4))();
      }
    }
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 3950 ; VA 0x005850b0 ; FUN_005850b0 */

undefined4
FUN_005850b0(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,int param_5)

{
  undefined uVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 *****pppppuVar8;
  undefined4 uVar9;
  undefined4 ****ppppuVar10;
  uint uVar11;
  bool bVar12;
  int iVar13;
  undefined4 uVar14;
  int iStack_1fc;
  byte abStack_1f0 [4];
  undefined auStack_1ec [168];
  undefined auStack_144 [24];
  undefined auStack_12c [24];
  undefined auStack_114 [16];
  int iStack_104;
  undefined2 auStack_fc [8];
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined auStack_e4 [24];
  undefined auStack_cc [24];
  undefined4 ****appppuStack_b4 [5];
  uint uStack_a0;
  undefined auStack_9c [24];
  undefined auStack_84 [12];
  undefined4 uStack_78;
  int iStack_74;
  int *piStack_70;
  int iStack_6c;
  undefined4 ****appppuStack_68 [4];
  int iStack_58;
  uint uStack_54;
  char acStack_50 [16];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int aiStack_38 [2];
  undefined auStack_30 [4];
  undefined4 uStack_2c;
  undefined4 ****appppuStack_28 [3];
  undefined auStack_1c [4];
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01796960;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_8 = 0;
  iStack_18 = 0;
  uStack_14 = 0xf;
  appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0] & 0xffffff00);
  ExceptionList = &pvStack_10;
  FUN_005542c0("Settings",8);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_2c = 1;
  piVar3 = (int *)FUN_00580040(&param_2,appppuStack_28);
  iVar13 = *piVar3;
  if ((iVar13 == 0) || (iVar6 = *(int *)(iVar13 + 0x20), iVar4 = FUN_008881d0(), iVar6 != iVar4)) {
    bVar12 = true;
  }
  else {
    bVar12 = false;
  }
  uStack_8 = 0;
  if (0xf < uStack_14) {
    uVar11 = uStack_14 + 1;
    ppppuVar10 = appppuStack_28[0];
    if (0xfff < uVar11) {
      ppppuVar10 = (undefined4 ****)appppuStack_28[0][-1];
      uVar11 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)appppuStack_28[0] + (-4 - (int)ppppuVar10))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar10,uVar11);
  }
  iStack_18 = 0;
  uStack_14 = 0xf;
  appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0] & 0xffffff00);
  if (bVar12) {
    FUN_0054eff0("Missing \'Settings\'");
    uStack_8._0_1_ = 2;
    FUN_0054eff0(&DAT_018bc9b8);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_0058a020(auStack_cc,auStack_9c,param_4);
LAB_005858e7:
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  iVar6 = *(int *)(iVar13 + 0x20);
  iVar4 = FUN_008881d0();
  if (iVar6 != iVar4) goto LAB_005858e7;
  puVar5 = (undefined4 *)(iVar13 + 0x28);
  if (*(int *)(iVar13 + 0x24) == 0) {
    puVar5 = (undefined4 *)0x0;
  }
  iStack_74 = puVar5[1];
  if (iStack_74 != 0) {
    LOCK();
    *(int *)(iStack_74 + 4) = *(int *)(iStack_74 + 4) + 1;
    UNLOCK();
    iStack_74 = puVar5[1];
  }
  param_2 = *puVar5;
  uStack_8._0_1_ = 4;
  uStack_40 = 0;
  uStack_3c = 0xf;
  acStack_50[0] = '\0';
  uStack_78 = param_2;
  FUN_005542c0(&DAT_018bf030,4);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  uStack_2c = 2;
  piVar3 = (int *)FUN_00580040(auStack_30,acStack_50);
  iVar13 = *piVar3;
  if ((iVar13 == 0) || (iVar6 = *(int *)(iVar13 + 0x20), iVar4 = FUN_0088cb40(), iVar6 != iVar4)) {
    cVar2 = '\x01';
  }
  else {
    cVar2 = '\0';
  }
  uStack_8 = 4;
  FUN_005507b0();
  if (cVar2 != '\0') {
    FUN_0054eff0("Missing \'Type\'");
    uStack_8._0_1_ = 6;
    FUN_0054eff0(&DAT_018bc9b8);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_0058a020(auStack_cc,auStack_9c,param_4);
LAB_0058592f:
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  iVar6 = *(int *)(iVar13 + 0x20);
  iVar4 = FUN_0088cb40();
  if (iVar6 != iVar4) goto LAB_0058592f;
  iVar6 = iVar13 + 0x28;
  if (*(int *)(iVar13 + 0x24) == 0) {
    iVar6 = 0;
  }
  FUN_0054ef60(iVar6);
  uStack_8._0_1_ = 8;
  uStack_40 = 0;
  uStack_3c = 0xf;
  acStack_50[0] = cVar2;
  FUN_005542c0("Arguments",9);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  uStack_2c = 4;
  piVar3 = (int *)FUN_00580040(auStack_30,acStack_50);
  iVar13 = *piVar3;
  if (iVar13 == 0) {
LAB_005852a3:
    bVar12 = true;
  }
  else {
    iVar6 = *(int *)(iVar13 + 0x20);
    iVar4 = FUN_008882f0();
    bVar12 = false;
    if (iVar6 != iVar4) goto LAB_005852a3;
  }
  uStack_8 = 8;
  FUN_005507b0();
  if (bVar12) {
    FUN_0054eff0("Missing \'Arguments\'");
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    FUN_0058a020(appppuStack_68,auStack_9c,param_4);
LAB_00585960:
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  iVar6 = *(int *)(iVar13 + 0x20);
  iVar4 = FUN_008882f0();
  if (iVar6 != iVar4) goto LAB_00585960;
  piVar3 = (int *)(iVar13 + 0x28);
  if (*(int *)(iVar13 + 0x24) == 0) {
    piVar3 = (int *)0x0;
  }
  iStack_6c = piVar3[1];
  if (iStack_6c != 0) {
    LOCK();
    *(int *)(iStack_6c + 4) = *(int *)(iStack_6c + 4) + 1;
    UNLOCK();
    iStack_6c = piVar3[1];
  }
  piVar3 = (int *)*piVar3;
  uStack_8._0_1_ = 0xb;
  piStack_70 = piVar3;
  FUN_0054ef60(appppuStack_68);
  cVar2 = FUN_0058c700();
  if (cVar2 == '\0') {
    FUN_0054eff0("Bad character in \'Type\'");
    uStack_8._0_1_ = 0xc;
    FUN_0058a020(appppuStack_68,auStack_9c,param_4);
    uVar1 = (undefined)uStack_8;
LAB_00585991:
    uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
    FUN_017167a3();
  }
  if (param_5 != 0) {
    FUN_005542c0("Thumbnail",9);
    FUN_00551230(appppuStack_68);
  }
  uStack_8._0_1_ = 0xd;
  uStack_40 = 0;
  uStack_3c = 0xf;
  acStack_50[0] = '\0';
  uStack_2c = 0x10;
  FUN_0058a190(iStack_58 + 4);
  pppppuVar8 = appppuStack_68;
  if (0xf < uStack_54) {
    pppppuVar8 = (undefined4 *****)appppuStack_68[0];
  }
  FUN_00554150(pppppuVar8,iStack_58);
  FUN_00554150(&DAT_018bf1c0,4);
  FUN_00558140(acStack_50,0);
  uStack_ec = 0;
  uStack_e8 = 7;
  auStack_fc[0] = 0;
  uStack_8._0_1_ = 0xf;
  iStack_18 = 0;
  uStack_14 = 0xf;
  appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0] & 0xffffff00);
  FUN_005542c0("thumbnails",10);
  uStack_8._0_1_ = 0x10;
  if (iStack_18 != 0) {
    pppppuVar8 = appppuStack_28;
    if (0xf < uStack_14) {
      pppppuVar8 = (undefined4 *****)appppuStack_28[0];
    }
    iVar13 = (int)pppppuVar8 + iStack_18;
    pppppuVar8 = appppuStack_28;
    if (0xf < uStack_14) {
      pppppuVar8 = (undefined4 *****)appppuStack_28[0];
    }
    uVar7 = FUN_01686580();
    FUN_01685950(pppppuVar8,iVar13,auStack_fc,uVar7);
  }
  uStack_8._0_1_ = 0xf;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xf;
  if (0xf < uStack_14) {
    uVar11 = uStack_14 + 1;
    pppppuVar8 = (undefined4 *****)appppuStack_28[0];
    if (0xfff < uVar11) {
      pppppuVar8 = (undefined4 *****)appppuStack_28[0][-1];
      uVar11 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)appppuStack_28[0] + (-4 - (int)pppppuVar8))) goto LAB_00585991;
    }
    FUN_01674ea0(pppppuVar8,uVar11);
  }
  iStack_18 = 0;
  uStack_14 = 0xf;
  appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0] & 0xffffff00);
  uStack_8._0_1_ = 0x11;
  FUN_0054d730("internalscripts",0);
  uStack_8._0_1_ = 0x12;
  uVar7 = FUN_01518d10(auStack_e4,0,3,0);
  uStack_8._0_1_ = 0x13;
  uVar7 = FUN_005514a0(auStack_12c,uVar7,auStack_cc);
  uStack_8._0_1_ = 0x14;
  uVar7 = FUN_005514a0(auStack_144,uVar7,auStack_fc);
  uStack_8._0_1_ = 0x15;
  FUN_005514a0(appppuStack_b4,uVar7,auStack_9c);
  FUN_00550800();
  FUN_00550800();
  FUN_00550800();
  FUN_00550800();
  FUN_00550800();
  FUN_00550800();
  uStack_8._0_1_ = 0x1d;
  FUN_005507b0();
  if (DAT_01d59104 != '\0') {
    puVar5 = (undefined4 *)FUN_005569d0(appppuStack_28);
    uStack_8._0_1_ = 0x1e;
    if (0xf < (uint)puVar5[5]) {
      puVar5 = (undefined4 *)*puVar5;
    }
    FUN_01677520(DAT_01d59104,"Loading thumbnail script file %s",puVar5);
    uStack_8._0_1_ = 0x1d;
    FUN_005507b0();
  }
  pppppuVar8 = appppuStack_b4;
  if (7 < uStack_a0) {
    pppppuVar8 = (undefined4 *****)appppuStack_b4[0];
  }
  FUN_0054ebd0(pppppuVar8,1,0x40,1);
  uStack_8._0_1_ = 0x1f;
  FUN_00565940(3,1);
  uStack_8._0_1_ = 0x20;
  if ((abStack_1f0[*(int *)(iStack_1fc + 4)] & 6) == 0) {
    FUN_0056f130(auStack_1ec);
    FUN_0058c420(auStack_114);
    uStack_8._0_1_ = 0x23;
    uVar1 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x23;
    if (iStack_104 != 0) {
      iVar13 = (piVar3[1] - *piVar3) / 0xd0;
      uVar7 = 0x58560f;
      FUN_00569550(iVar13,(int)&param_2 + 3);
      uVar11 = 0;
      uStack_8._0_1_ = 0x25;
      iVar6 = piVar3[1] - *piVar3 >> 0x1f;
      if ((piVar3[1] - *piVar3) / 0xd0 + iVar6 != iVar6) {
        do {
          uVar9 = FUN_00578430(uVar11);
          iVar13 = 0x585644;
          FUN_0056ee80(uVar9);
          uVar11 = uVar11 + 1;
        } while (uVar11 < (uint)((piVar3[1] - *piVar3) / 0xd0));
      }
      piVar3 = param_3;
      if (DAT_01d64500 == '\0') {
        uVar9 = 1;
        FUN_00557fc0(param_3);
        FUN_008e9510(uVar7,iVar13,uVar9);
        uStack_8._0_1_ = 0x2a;
        uVar1 = (undefined)uStack_8;
        uStack_8._0_1_ = 0x2a;
        if (*(char *)(*piVar3 + 0x1dd) == '\0') {
          uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("The DataModel is closed");
        }
        if (param_5 != 0) {
          uVar7 = 0x5857a0;
          iVar6 = FUN_0055ed20();
          if (iVar6 != 0) {
            FUN_00557fc0(&param_5);
            FUN_0058bba0(iVar13,uVar7);
          }
        }
        FUN_0055ea10();
        uVar7 = FUN_00886c00(&iStack_18,auStack_114);
        uStack_8._0_1_ = 0x2b;
        FUN_01255470(8,0,0,0);
        uVar7 = FUN_0094ed20(aiStack_38,auStack_e4,uVar7,"Thumbnail Script",auStack_84);
        FUN_00557f90(uVar7);
        FUN_00550b30();
        FUN_0056e380();
        FUN_0056e380();
        FUN_008eb110();
        uStack_8 = CONCAT31(uStack_8._1_3_,0x2c);
LAB_0058583c:
        FUN_00577b20();
        FUN_005507b0();
        FUN_005705c0();
        FUN_00551650();
        FUN_00550800();
        FUN_00550b30();
        FUN_005507b0();
        FUN_00550b30();
        FUN_00550b30();
        ExceptionList = pvStack_10;
        return param_1;
      }
      uVar9 = 0x58567b;
      FUN_00563e30(aiStack_38);
      piVar3 = param_3;
      uVar14 = 1;
      uStack_8._0_1_ = 0x26;
      FUN_00557fc0(param_3);
      FUN_008e9510(uVar7,uVar9,uVar14);
      uStack_8._0_1_ = 0x27;
      uVar1 = (undefined)uStack_8;
      uStack_8._0_1_ = 0x27;
      if (*(char *)(*piVar3 + 0x1dd) != '\0') {
        if (param_5 != 0) {
          uVar7 = 0x5856bb;
          iVar13 = FUN_0055ed20();
          if (iVar13 != 0) {
            FUN_00557fc0(&param_5);
            FUN_0058bba0(uVar9,uVar7);
          }
        }
        uVar7 = FUN_0055ea10();
        FUN_00886c00(&iStack_18,auStack_114);
        uStack_8._0_1_ = 0x28;
        FUN_00557fc0(aiStack_38);
        FUN_0057f8e0(uVar7);
        FUN_0056e380();
        FUN_0056e380();
        uStack_8._0_1_ = 0x26;
        FUN_008eb110();
        FUN_0151f430();
        if (*(char *)(aiStack_38[0] + 0xc) != '\0') {
          FUN_0054db20();
          uVar7 = FUN_00576e70();
          FUN_005500e0(uVar7);
                    /* WARNING: Subroutine does not return */
          FUN_0170c2a8(auStack_1c,&DAT_01c17198);
        }
        FUN_00557fc0(aiStack_38[0] + 4);
        FUN_00550b30();
        uStack_8 = CONCAT31(uStack_8._1_3_,0x29);
        goto LAB_0058583c;
      }
      goto LAB_00585a00;
    }
  }
  else {
    FUN_005569d0(auStack_e4);
    uStack_8._0_1_ = 0x21;
    uVar7 = FUN_005543f0();
    uVar7 = FUN_01675640(auStack_12c,"Failed to open script file %s",uVar7);
    uStack_8._0_1_ = 0x22;
    FUN_0058a020(appppuStack_68,uVar7,param_4);
    uVar1 = (undefined)uStack_8;
  }
  uStack_8._0_1_ = uVar1;
  FUN_0054eff0("Empty thumbnail script");
  uStack_8._0_1_ = 0x24;
  FUN_0058a020(appppuStack_68,auStack_e4,param_4);
  uVar1 = (undefined)uStack_8;
LAB_00585a00:
  uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("The DataModel is closed");
}



/* FUNCTION 3951 ; VA 0x00585a40 ; FUN_00585a40 */

undefined FUN_00585a40(void)

{
  return 0;
}



/* FUNCTION 3952 ; VA 0x00585a50 ; FUN_00585a50 */

void FUN_00585a50(void)

{
  FUN_005702d0();
  return;
}



/* FUNCTION 3953 ; VA 0x00585a70 ; FUN_00585a70 */

void FUN_00585a70(int param_1)

{
  *(uint *)(param_1 + 0x14) = *(uint *)(param_1 + 0x14) & 0xfffff9ff | 0x800;
  return;
}



/* FUNCTION 3954 ; VA 0x00585a90 ; FUN_00585a90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00585a90(void)

{
  undefined4 auStack_20 [2];
  undefined *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796987;
  pvStack_10 = ExceptionList;
  if (DAT_01ea8510 == '\0') {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8a6c) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ea8a6c);
      if (DAT_01ea8a6c == -1) {
        uStack_8 = 0;
        puStack_18 = &DAT_01ea8a28;
        auStack_20[0] = 0;
        _DAT_01ea8a2c = FUN_01674e20(0x38);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_00568300(auStack_20,&uStack_11);
        _DAT_01ea8a50 = 0;
        InitializeCriticalSection(&DAT_01ea8a54);
        FUN_016f3654(&LAB_0187b2d0);
        FUN_016f37bf(&DAT_01ea8a6c);
      }
    }
    DAT_01ea8514 = &DAT_01ea8a28;
    DAT_01ea8518 = &DAT_01ea8a54;
    DAT_01ea8510 = '\x01';
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 3955 ; VA 0x00585b80 ; FUN_00585b80 */

void FUN_00585b80(undefined4 param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_00585d40(param_1,param_2,*puVar1);
  return;
}



/* FUNCTION 3956 ; VA 0x00585ba0 ; FUN_00585ba0 */

int * __thiscall FUN_00585ba0(int *param_1,uint param_2,uint param_3,char param_4)

{
  uint uVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  
  uVar7 = param_1[4];
  if (uVar7 < param_2) {
    FUN_00554050();
  }
  else {
    uVar1 = param_1[5];
    if (param_3 <= uVar1 - uVar7) {
      param_1[4] = uVar7 + param_3;
      piVar3 = param_1;
      if (0xf < uVar1) {
        piVar3 = (int *)*param_1;
      }
      iVar9 = (int)piVar3 + param_2;
      FUN_0170cc70(iVar9 + param_3,iVar9,(uVar7 - param_2) + 1);
      FUN_0170d1f0(iVar9,(int)param_4,param_3);
      return param_1;
    }
    if (param_3 <= 0x7fffffff - uVar7) {
      uVar6 = uVar7 + param_3 | 0xf;
      if (uVar6 < 0x80000000) {
        if (0x7fffffff - (uVar1 >> 1) < uVar1) {
          uVar6 = 0x7fffffff;
        }
        else {
          uVar4 = (uVar1 >> 1) + uVar1;
          if (uVar6 < uVar4) {
            uVar6 = uVar4;
          }
        }
      }
      else {
        uVar6 = 0x7fffffff;
      }
      iVar5 = FUN_00554060(uVar6 + 1);
      param_1[5] = uVar6;
      param_1[4] = uVar7 + param_3;
      iVar8 = (uVar7 - param_2) + 1;
      iVar9 = iVar5 + param_2;
      if (uVar1 < 0x10) {
        FUN_0170c6f0(iVar5,param_1,param_2);
        FUN_0170d1f0(iVar9,(int)param_4,param_3);
        FUN_0170c6f0(iVar9 + param_3,param_2 + (int)param_1,iVar8);
        *param_1 = iVar5;
        return param_1;
      }
      iVar2 = *param_1;
      FUN_0170c6f0(iVar5,iVar2,param_2);
      FUN_0170d1f0(iVar9,(int)param_4,param_3);
      FUN_0170c6f0(iVar9 + param_3,param_2 + iVar2,iVar8);
      uVar7 = uVar1 + 1;
      iVar9 = iVar2;
      if (uVar7 < 0x1000) {
LAB_00585cda:
        FUN_01674ea0(iVar9,uVar7);
        *param_1 = iVar5;
        return param_1;
      }
      iVar9 = *(int *)(iVar2 + -4);
      uVar7 = uVar1 + 0x24;
      if ((iVar2 - iVar9) - 4U < 0x20) goto LAB_00585cda;
      goto LAB_00585d33;
    }
  }
  FUN_00554040();
LAB_00585d33:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 3957 ; VA 0x00585d40 ; FUN_00585d40 */

int * __thiscall FUN_00585d40(int *param_1,int *param_2,uint param_3,uint param_4)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  
  uVar5 = (uint)param_2;
  uVar6 = param_1[4];
  if (uVar6 < param_2) {
    FUN_00554050();
  }
  else {
    uVar1 = param_1[5];
    if (param_4 <= uVar1 - uVar6) {
      param_1[4] = uVar6 + param_4;
      param_2 = param_1;
      if (0xf < uVar1) {
        param_2 = (int *)*param_1;
      }
      uVar1 = (int)param_2 + uVar5;
      if ((uVar1 < param_3 + param_4) && (param_3 <= (int)param_2 + uVar6)) {
        if (param_3 < uVar1) {
          param_2 = (int *)(uVar1 - param_3);
        }
        else {
          param_2 = (int *)0x0;
        }
      }
      else {
        param_2 = (int *)param_4;
      }
      FUN_0170cc70(uVar1 + param_4,uVar1,(uVar6 - uVar5) + 1);
      FUN_0170c6f0(uVar1,param_3,param_2);
      FUN_0170c6f0(uVar1 + (int)param_2,param_3 + (int)param_2 + param_4,param_4 - (int)param_2);
      return param_1;
    }
    if (param_4 <= 0x7fffffff - uVar6) {
      uVar5 = uVar6 + param_4 | 0xf;
      if (uVar5 < 0x80000000) {
        if (0x7fffffff - (uVar1 >> 1) < uVar1) {
          uVar5 = 0x7fffffff;
        }
        else {
          uVar3 = (uVar1 >> 1) + uVar1;
          if (uVar5 < uVar3) {
            uVar5 = uVar3;
          }
        }
      }
      else {
        uVar5 = 0x7fffffff;
      }
      iVar4 = FUN_00554060(uVar5 + 1);
      param_1[5] = uVar5;
      param_1[4] = uVar6 + param_4;
      iVar7 = (uVar6 - (int)param_2) + 1;
      iVar8 = iVar4 + (int)param_2;
      if (uVar1 < 0x10) {
        FUN_0170c6f0(iVar4,param_1,param_2);
        FUN_0170c6f0(iVar8,param_3,param_4);
        FUN_0170c6f0(iVar8 + param_4,(int)param_2 + (int)param_1,iVar7);
        *param_1 = iVar4;
        return param_1;
      }
      iVar2 = *param_1;
      FUN_0170c6f0(iVar4,iVar2,param_2);
      FUN_0170c6f0(iVar8,param_3,param_4);
      FUN_0170c6f0(iVar8 + param_4,(int)param_2 + iVar2,iVar7);
      uVar6 = uVar1 + 1;
      iVar8 = iVar2;
      if (uVar6 < 0x1000) {
LAB_00585ec1:
        FUN_01674ea0(iVar8,uVar6);
        *param_1 = iVar4;
        return param_1;
      }
      iVar8 = *(int *)(iVar2 + -4);
      uVar6 = uVar1 + 0x24;
      if ((iVar2 - iVar8) - 4U < 0x20) goto LAB_00585ec1;
      goto LAB_00585f1a;
    }
  }
  FUN_00554040();
LAB_00585f1a:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 3958 ; VA 0x00585f20 ; FUN_00585f20 */

void FUN_00585f20(int param_1)

{
  LOCK();
  *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 1;
  UNLOCK();
  return;
}



/* FUNCTION 3959 ; VA 0x00585f30 ; FUN_00585f30 */

int FUN_00585f30(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  
  LOCK();
  piVar1 = param_1 + 1;
  iVar2 = *piVar1;
  iVar4 = *piVar1;
  *piVar1 = iVar2 + -1;
  UNLOCK();
  if (iVar2 + -1 == 0) {
    (**(code **)*param_1)(0);
    uVar3 = GetProcessHeap(0,param_1);
    iVar4 = HeapFree(uVar3);
  }
  return iVar4;
}



/* FUNCTION 3960 ; VA 0x00585f60 ; FUN_00585f60 */

void FUN_00585f60(int *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)*param_1;
  (*(code *)*puVar1)(puVar1 + 1,puVar1 + 7,puVar1 + 0xd,puVar1[0x13]);
  return;
}



/* FUNCTION 3961 ; VA 0x00585f80 ; FUN_00585f80 */

void FUN_00585f80(undefined4 *param_1)

{
  (*(code *)*param_1)(param_1[1]);
  return;
}



/* FUNCTION 3962 ; VA 0x00585fa0 ; FUN_00585fa0 */

void FUN_00585fa0(undefined4 *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00585fac. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)*param_1)();
  return;
}



/* FUNCTION 3963 ; VA 0x00585fb0 ; FUN_00585fb0 */

int FUN_00585fb0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  code *pcVar4;
  int iVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017969a8;
  pvStack_10 = ExceptionList;
  piVar6 = (int *)param_1[3];
  ExceptionList = &pvStack_10;
  if (piVar6 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar6[1] = piVar6[1] + 1;
    UNLOCK();
    piVar6 = (int *)param_1[3];
  }
  uVar3 = param_1[2];
  pcVar4 = (code *)*param_1;
  piVar1 = piVar6 + 1;
  uStack_8 = 0;
  if (piVar6 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar5 = (*pcVar4)(uVar3,piVar6);
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piVar6)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 3964 ; VA 0x00586050 ; FUN_00586050 */

void FUN_00586050(int *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)*param_1;
  (*(code *)*puVar1)(puVar1 + 2,puVar1[8],puVar1[9],puVar1[10]);
  return;
}



/* FUNCTION 3965 ; VA 0x00586070 ; FUN_00586070 */

/* WARNING: Removing unreachable block (ram,0x0058612d) */
/* WARNING: Removing unreachable block (ram,0x0058613b) */
/* WARNING: Removing unreachable block (ram,0x0058616a) */
/* WARNING: Removing unreachable block (ram,0x0058614b) */

void FUN_00586070(int *param_1,undefined4 ****param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,uint param_7)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***pppuStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017969d0;
  pvStack_10 = ExceptionList;
  pppuStack_28 = param_2;
  uStack_24 = param_3;
  uStack_20 = param_4;
  uStack_1c = param_5;
  uStack_18 = param_6;
  uStack_14 = param_7;
  uStack_8 = 1;
  iVar1 = *param_1;
  if (*(char *)(iVar1 + 0xc) == '\0') {
    ExceptionList = &pvStack_10;
    FUN_0054ef60(&pppuStack_28);
    *(undefined *)(iVar1 + 0xc) = 1;
  }
  else {
    ExceptionList = &pvStack_10;
    if ((undefined4 ****)(iVar1 + 0x10) != &pppuStack_28) {
      ppppuVar2 = &pppuStack_28;
      if (0xf < param_7) {
        ppppuVar2 = param_2;
      }
      ExceptionList = &pvStack_10;
      FUN_005542c0(ppppuVar2,param_6);
    }
  }
  FUN_0151f3f0();
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    ppppuVar2 = (undefined4 ****)pppuStack_28;
    if (0xfff < uVar3) {
      ppppuVar2 = (undefined4 ****)pppuStack_28[-1];
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)pppuStack_28 + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3966 ; VA 0x00586170 ; FUN_00586170 */

void FUN_00586170(undefined4 param_1,int param_2)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_00562e40();
    if (iVar1 != 0) {
      FUN_00643a60();
      return;
    }
  }
  return;
}



/* FUNCTION 3967 ; VA 0x00586190 ; FUN_00586190 */

/* WARNING: Removing unreachable block (ram,0x0058621f) */
/* WARNING: Removing unreachable block (ram,0x00586228) */
/* WARNING: Removing unreachable block (ram,0x00586236) */

int FUN_00586190(int *param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  iVar3 = *param_1;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar3 + 4) = param_2;
  piVar2 = *(int **)(iVar3 + 8);
  *(int **)(iVar3 + 8) = param_3;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar3 = FUN_0151f3f0();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 1;
    iVar1 = *piVar2;
    iVar3 = *piVar2;
    *piVar2 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar1 = *piVar2;
      iVar3 = *piVar2;
      *piVar2 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  return iVar3;
}



/* FUNCTION 3968 ; VA 0x00586250 ; FUN_00586250 */

undefined4 __fastcall FUN_00586250(int param_1)

{
  undefined4 uVar1;
  
  if (DAT_01d59348 != '\0') {
    uVar1 = FUN_005df310(*(undefined *)(param_1 + 0xac));
    return uVar1;
  }
  return 1;
}



/* FUNCTION 3969 ; VA 0x00586270 ; FUN_00586270 */

uint FUN_00586270(void)

{
  int iVar1;
  
  iVar1 = FUN_00558f80();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 3970 ; VA 0x00586290 ; FUN_00586290 */

uint FUN_00586290(void)

{
  int iVar1;
  
  iVar1 = FUN_00559080();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 3971 ; VA 0x005862b0 ; FUN_005862b0 */

uint FUN_005862b0(void)

{
  int iVar1;
  
  iVar1 = FUN_00558f80();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 3972 ; VA 0x005862d0 ; FUN_005862d0 */

uint FUN_005862d0(void)

{
  int iVar1;
  
  iVar1 = FUN_00559080();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 3973 ; VA 0x005862f0 ; FUN_005862f0 */

uint FUN_005862f0(ushort param_1)

{
  ulonglong uVar1;
  uint in_EAX;
  uint uVar2;
  
  uVar2 = (uint)param_1;
  if ((param_1 & 3) == 0) {
    in_EAX = uVar2 / 100;
    if (((int)((ulonglong)uVar2 % 100) != 0) ||
       (uVar1 = (ulonglong)uVar2 % 100 << 0x20 | (ulonglong)uVar2, in_EAX = (uint)(uVar1 / 400),
       (int)(uVar1 % 400) == 0)) {
      return CONCAT31((int3)(in_EAX >> 8),1);
    }
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 3974 ; VA 0x00586330 ; FUN_00586330 */

undefined FUN_00586330(int param_1,int param_2)

{
  if ((param_1 == 0) && (param_2 == -0x80000000)) {
    return 1;
  }
  return 0;
}



/* FUNCTION 3975 ; VA 0x00586350 ; FUN_00586350 */

void FUN_00586350(void)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined auStack_18 [4];
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017969e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar1 = (int *)FUN_01689dd0(auStack_14);
  piVar2 = (int *)FUN_01689df0(auStack_18);
  if (*piVar1 != *piVar2) {
    FUN_0168a200();
    ExceptionList = pvStack_10;
    return;
  }
  uVar3 = FUN_0056b4a0(0x24,"boost thread: trying joining itself");
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  FUN_0054e630(uVar3);
}



/* FUNCTION 3976 ; VA 0x005863d0 ; FUN_005863d0 */

int * __fastcall FUN_005863d0(int *param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  undefined4 *puVar6;
  int *piVar7;
  int iStack_24;
  int *piStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796a1a;
  pvStack_10 = ExceptionList;
  puVar1 = (undefined4 *)(&DAT_01ea8970 + ((uint)param_1 % 0x29) * 4);
  ExceptionList = &pvStack_10;
  piVar5 = (int *)FUN_00587580();
  iVar3 = *param_1;
  piVar4 = (int *)param_1[1];
  piVar7 = piVar4 + 1;
  if (piVar4 != (int *)0x0) {
    LOCK();
    *piVar7 = *piVar7 + 1;
    UNLOCK();
  }
  *puVar1 = 0;
  uStack_8 = 0;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar7;
    piVar5 = (int *)*piVar7;
    *piVar7 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*piVar4 + 4))();
      LOCK();
      piVar7 = piVar4 + 2;
      iVar2 = *piVar7;
      piVar5 = (int *)*piVar7;
      *piVar7 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piVar5 = (int *)(**(code **)(*piVar4 + 8))();
      }
    }
  }
  if (iVar3 == 0) {
    piVar7 = (int *)0x0;
    uStack_8 = 1;
    puVar6 = (undefined4 *)FUN_01674e20(0x90);
    uStack_8._0_1_ = 2;
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      FUN_0056b2c0();
      *puVar6 = boost::detail::
                shared_state<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                ::vftable;
      puVar6[0x22] = 0;
    }
    uStack_8._0_1_ = 1;
    FUN_00557de0(puVar6);
    FUN_00587580();
    piVar5 = (int *)*param_1;
    if ((piVar5 == (int *)0x0) && (param_1[1] == 0)) {
      *param_1 = iStack_24;
      piVar5 = (int *)param_1[1];
      param_1[1] = (int)piStack_20;
      *puVar1 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      piStack_20 = piVar5;
    }
    else {
      piVar7 = (int *)param_1[1];
      if (piVar7 != (int *)0x0) {
        LOCK();
        piVar7[1] = piVar7[1] + 1;
        UNLOCK();
      }
      *puVar1 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piVar4 = piStack_20 + 1;
      iVar3 = *piVar4;
      piVar5 = (int *)*piVar4;
      *piVar4 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)(*piStack_20 + 4))();
        LOCK();
        piVar4 = piStack_20 + 2;
        iVar3 = *piVar4;
        piVar5 = (int *)*piVar4;
        *piVar4 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          piVar5 = (int *)(**(code **)(*piStack_20 + 8))();
        }
      }
    }
    uStack_8 = 6;
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar4 = piVar7 + 1;
      iVar3 = *piVar4;
      piVar5 = (int *)*piVar4;
      *piVar4 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        piVar5 = (int *)(**(code **)(*piVar7 + 4))();
        LOCK();
        piVar4 = piVar7 + 2;
        iVar3 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          piVar5 = (int *)(**(code **)(*piVar7 + 8))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar5;
}



/* FUNCTION 3977 ; VA 0x00586580 ; FUN_00586580 */

void FUN_00586580(void)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined auStack_40 [12];
  undefined auStack_34 [12];
  uint *puStack_28;
  char cStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01796ac4;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  puStack_28 = (uint *)(DAT_01ea84c0 + 0xbc);
  cStack_24 = '\0';
  ExceptionList = &pvStack_10;
  FUN_00587410();
  iStack_8 = 0;
  cVar4 = FUN_005dde50();
  if (cVar4 != '\0') {
    iStack_18 = FUN_0055e560();
    iVar2 = iStack_18 + 0x2a4;
    iStack_8._0_1_ = 2;
    uVar5 = FUN_01675290(DAT_02110da8);
    iStack_8._0_1_ = 3;
    puStack_1c = (undefined4 *)uVar5;
    puStack_20 = (undefined4 *)FUN_01674e20(0x1c);
    if (puStack_20 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      *puStack_20 = 0;
      puStack_20[1] = 1;
      puStack_20[2] = FUN_0057de20;
      puStack_20[3] = _guard_check_icall;
      puStack_20[4] = 0;
      puStack_20[5] = iVar2;
      puVar6 = puStack_20;
    }
    FUN_016797d0(puVar6);
    if (puVar6 != (undefined4 *)0x0) {
      LOCK();
      puVar6[1] = puVar6[1] + 1;
      UNLOCK();
    }
    uStack_14 = 1;
    iStack_8 = CONCAT31(iStack_8._1_3_,4);
    puStack_20 = puVar6;
    FUN_01675290(uVar5);
    uStack_14 = 0;
    if (puVar6 != (undefined4 *)0x0) {
      piVar1 = puVar6 + 1;
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_01674ea0(puVar6);
      }
    }
    iStack_18 = iStack_18 + 0x2b0;
    iStack_8._0_1_ = 5;
    uVar5 = FUN_01675290(DAT_02110da8);
    iStack_8._0_1_ = 6;
    puStack_20 = (undefined4 *)uVar5;
    puStack_1c = (undefined4 *)FUN_01674e20(0x1c);
    if (puStack_1c == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      *puStack_1c = 0;
      puStack_1c[1] = 1;
      puStack_1c[2] = FUN_0057ddb0;
      puStack_1c[3] = _guard_check_icall;
      puStack_1c[4] = 0;
      puStack_1c[5] = iStack_18;
      puVar6 = puStack_1c;
    }
    FUN_016797d0(puVar6);
    if (puVar6 != (undefined4 *)0x0) {
      LOCK();
      puVar6[1] = puVar6[1] + 1;
      UNLOCK();
    }
    uStack_14 = 2;
    iStack_8 = CONCAT31(iStack_8._1_3_,7);
    puStack_1c = puVar6;
    FUN_01675290(uVar5);
    uStack_14 = 0;
    if (puVar6 != (undefined4 *)0x0) {
      piVar1 = puVar6 + 1;
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_01674ea0(puVar6);
      }
    }
    DAT_01ea946c = &DAT_01ea8424;
    iStack_8._0_1_ = 8;
    uVar5 = FUN_01675290(DAT_02110da8);
    iStack_8._0_1_ = 9;
    puStack_20 = (undefined4 *)uVar5;
    puStack_1c = (undefined4 *)FUN_01674e20(0x1c);
    if (puStack_1c == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      *puStack_1c = 0;
      puStack_1c[1] = 1;
      puStack_1c[2] = FUN_0057dd10;
      puStack_1c[3] = _guard_check_icall;
      puStack_1c[4] = 0;
      puStack_1c[5] = &DAT_01ea8424;
      puVar6 = puStack_1c;
    }
    FUN_016797d0(puVar6);
    if (puVar6 != (undefined4 *)0x0) {
      LOCK();
      puVar6[1] = puVar6[1] + 1;
      UNLOCK();
    }
    uStack_14 = 4;
    iStack_8 = CONCAT31(iStack_8._1_3_,10);
    puStack_1c = puVar6;
    FUN_01675290(uVar5);
    uStack_14 = 0;
    if (puVar6 != (undefined4 *)0x0) {
      piVar1 = puVar6 + 1;
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_01674ea0(puVar6);
      }
    }
    DAT_01ea9468 = &DAT_01ea8428;
    iStack_8._0_1_ = 0xb;
    uVar5 = FUN_01675290(DAT_02110da8);
    iStack_8._0_1_ = 0xc;
    puStack_20 = (undefined4 *)uVar5;
    puStack_1c = (undefined4 *)FUN_01674e20(0x1c);
    if (puStack_1c == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      *puStack_1c = 0;
      puStack_1c[1] = 1;
      puStack_1c[2] = FUN_0057dc50;
      puStack_1c[3] = _guard_check_icall;
      puStack_1c[4] = 0;
      puStack_1c[5] = &DAT_01ea8428;
      puVar6 = puStack_1c;
    }
    FUN_016797d0(puVar6);
    if (puVar6 != (undefined4 *)0x0) {
      LOCK();
      puVar6[1] = puVar6[1] + 1;
      UNLOCK();
    }
    uStack_14 = 8;
    iStack_8 = CONCAT31(iStack_8._1_3_,0xd);
    puStack_1c = puVar6;
    FUN_01675290(uVar5);
    if (puVar6 != (undefined4 *)0x0) {
      piVar1 = puVar6 + 1;
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_01674ea0(puVar6);
      }
    }
    iStack_8 = 0xe;
    if (cStack_24 != '\0') {
      LOCK();
      uVar3 = *puStack_28;
      *puStack_28 = *puStack_28 + 0x80000000;
      UNLOCK();
      if (((uVar3 & 0x40000000) == 0) && (-0x80000000 < (int)uVar3)) {
        LOCK();
        uVar3 = *puStack_28;
        *puStack_28 = *puStack_28 | 0x40000000;
        UNLOCK();
        if ((uVar3 >> 0x1e & 1) == 0) {
          uVar5 = FUN_00554e40();
          SetEvent(uVar5);
        }
      }
    }
    ExceptionList = pvStack_10;
    return;
  }
  if (DAT_01d59037 != '\0') {
    FUN_01677520(DAT_01d59037,"Exception raised! Failed to initialize external anticheat module.");
  }
  FUN_0054eff0("ExternalAntiCheat_Errors_All,ExternalAntiCheat_Errors_InitFailed");
  iStack_8._0_1_ = 1;
  FUN_00878480(auStack_40,0);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  FUN_00550130("Unable to initialize ExternalAntiCheatModule");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_34,&DAT_01c17198);
}



/* FUNCTION 3978 ; VA 0x00586960 ; FUN_00586960 */

void FUN_00586960(undefined4 param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined8 uVar9;
  uint auStack_94 [4];
  undefined4 uStack_84;
  uint uStack_80;
  uint auStack_7c [4];
  undefined4 uStack_6c;
  uint uStack_68;
  uint auStack_64 [3];
  undefined auStack_58 [4];
  undefined4 uStack_54;
  uint uStack_50;
  int aiStack_4c [2];
  undefined4 *puStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796b75;
  pvStack_10 = ExceptionList;
  aiStack_4c[1] = 0;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("UniverseId",10);
  uStack_8 = 0;
  FUN_00580040(&puStack_44,auStack_40);
  if ((puStack_44 != (undefined4 *)0x0) && (*(char *)(puStack_44[8] + 0x21) != '\0')) {
    uVar9 = FUN_00563790();
    uStack_8 = 0xffffffff;
    *(undefined8 *)(*param_2 + 8) = uVar9;
    if (0xf < uStack_2c) {
      uVar8 = uStack_2c + 1;
      uVar7 = auStack_40[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_40[0] - 4);
        uVar8 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    FUN_005542c0("MatchmakingContextId",0x14);
    uStack_8 = 1;
    uVar4 = FUN_00563a70(param_1,auStack_40);
    uStack_8 = 0xffffffff;
    *(undefined4 *)(*param_2 + 0x10) = uVar4;
    if (0xf < uStack_2c) {
      uVar8 = uStack_2c + 1;
      uVar7 = auStack_40[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_40[0] - 4);
        uVar8 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8 = 2;
    uStack_54 = 0;
    uStack_50 = 0xf;
    auStack_64[0] = auStack_64[0] & 0xffffff00;
    FUN_005542c0("GameCode",8);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    puVar5 = (undefined4 *)FUN_0054ef60(auStack_28);
    aiStack_4c[1] = 1;
    FUN_00563920(param_1,auStack_64,auStack_40);
    puStack_44 = (undefined4 *)(*param_2 + 0x14);
    if (puStack_44 != puVar5) {
      FUN_005507b0();
      uVar4 = puVar5[1];
      uVar2 = puVar5[2];
      uVar3 = puVar5[3];
      *puStack_44 = *puVar5;
      puStack_44[1] = uVar4;
      puStack_44[2] = uVar2;
      puStack_44[3] = uVar3;
      *(undefined8 *)(puStack_44 + 4) = *(undefined8 *)(puVar5 + 4);
      puVar5[4] = 0;
      puVar5[5] = 0xf;
      *(undefined *)puVar5 = 0;
    }
    aiStack_4c[1] = 0;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_2c) {
      uVar8 = uStack_2c + 1;
      uVar7 = auStack_40[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_40[0] - 4);
        uVar8 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (0xf < uStack_50) {
      uVar8 = uStack_50 + 1;
      uVar7 = auStack_64[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_64[0] - 4);
        uVar8 = uStack_50 + 0x24;
        if (0x1f < (auStack_64[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_54 = 0;
    uStack_50 = 0xf;
    auStack_64[0] = auStack_64[0] & 0xffffff00;
    uStack_8 = 0xffffffff;
    if (0xf < uStack_14) {
      uVar8 = uStack_14 + 1;
      uVar7 = auStack_28[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_28[0] - 4);
        uVar8 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("PreferredPort",0xd);
    uStack_8 = 5;
    puStack_44 = (undefined4 *)0x0;
    FUN_00580040(aiStack_4c,auStack_28);
    if ((aiStack_4c[0] != 0) &&
       (iVar1 = *(int *)(aiStack_4c[0] + 0x20), iVar6 = FUN_0088c8c0(), iVar1 == iVar6)) {
      iVar1 = *(int *)(aiStack_4c[0] + 0x20);
      iVar6 = FUN_0088c8c0();
      if (iVar1 != iVar6) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puStack_44 = (undefined4 *)(aiStack_4c[0] + 0x28);
      if (*(int *)(aiStack_4c[0] + 0x24) == 0) {
        puStack_44 = (undefined4 *)0x0;
      }
      puStack_44 = (undefined4 *)*puStack_44;
    }
    uStack_8 = 0xffffffff;
    *(undefined4 **)(*param_2 + 0x2c) = puStack_44;
    if (0xf < uStack_14) {
      uVar8 = uStack_14 + 1;
      uVar7 = auStack_28[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_28[0] - 4);
        uVar8 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("BaseUrl",7);
    uStack_8 = 6;
    puVar5 = (undefined4 *)FUN_00563af0(auStack_40,param_1,auStack_28);
    iVar1 = *param_2;
    if ((undefined4 *)(iVar1 + 0x30) != puVar5) {
      FUN_005507b0();
      uVar4 = puVar5[1];
      uVar2 = puVar5[2];
      uVar3 = puVar5[3];
      *(undefined4 *)(iVar1 + 0x30) = *puVar5;
      *(undefined4 *)(iVar1 + 0x34) = uVar4;
      *(undefined4 *)(iVar1 + 0x38) = uVar2;
      *(undefined4 *)(iVar1 + 0x3c) = uVar3;
      *(undefined8 *)(iVar1 + 0x40) = *(undefined8 *)(puVar5 + 4);
      puVar5[4] = 0;
      puVar5[5] = 0xf;
      *(undefined *)puVar5 = 0;
    }
    if (0xf < uStack_2c) {
      uVar8 = uStack_2c + 1;
      uVar7 = auStack_40[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_40[0] - 4);
        uVar8 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    uStack_8 = 0xffffffff;
    if (0xf < uStack_14) {
      uVar8 = uStack_14 + 1;
      uVar7 = auStack_28[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_28[0] - 4);
        uVar8 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("GameId",6);
    uStack_8 = 7;
    puVar5 = (undefined4 *)FUN_00563af0(auStack_40,param_1,auStack_28);
    iVar1 = *param_2;
    if ((undefined4 *)(iVar1 + 0x48) != puVar5) {
      FUN_005507b0();
      uVar4 = puVar5[1];
      uVar2 = puVar5[2];
      uVar3 = puVar5[3];
      *(undefined4 *)(iVar1 + 0x48) = *puVar5;
      *(undefined4 *)(iVar1 + 0x4c) = uVar4;
      *(undefined4 *)(iVar1 + 0x50) = uVar2;
      *(undefined4 *)(iVar1 + 0x54) = uVar3;
      *(undefined8 *)(iVar1 + 0x58) = *(undefined8 *)(puVar5 + 4);
      puVar5[4] = 0;
      puVar5[5] = 0xf;
      *(undefined *)puVar5 = 0;
    }
    if (0xf < uStack_2c) {
      uVar8 = uStack_2c + 1;
      uVar7 = auStack_40[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_40[0] - 4);
        uVar8 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    uStack_8 = 0xffffffff;
    if (0xf < uStack_14) {
      uVar8 = uStack_14 + 1;
      uVar7 = auStack_28[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_28[0] - 4);
        uVar8 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("MachineAddress",0xe);
    uStack_8 = 8;
    puVar5 = (undefined4 *)FUN_00563af0(auStack_40,param_1,auStack_28);
    iVar1 = *param_2;
    if ((undefined4 *)(iVar1 + 0x60) != puVar5) {
      FUN_005507b0();
      uVar4 = puVar5[1];
      uVar2 = puVar5[2];
      uVar3 = puVar5[3];
      *(undefined4 *)(iVar1 + 0x60) = *puVar5;
      *(undefined4 *)(iVar1 + 100) = uVar4;
      *(undefined4 *)(iVar1 + 0x68) = uVar2;
      *(undefined4 *)(iVar1 + 0x6c) = uVar3;
      *(undefined8 *)(iVar1 + 0x70) = *(undefined8 *)(puVar5 + 4);
      puVar5[4] = 0;
      puVar5[5] = 0xf;
      *(undefined *)puVar5 = 0;
    }
    if (0xf < uStack_2c) {
      uVar8 = uStack_2c + 1;
      uVar7 = auStack_40[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_40[0] - 4);
        uVar8 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    uStack_8 = 0xffffffff;
    if (0xf < uStack_14) {
      uVar8 = uStack_14 + 1;
      uVar7 = auStack_28[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_28[0] - 4);
        uVar8 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("GsmInterval",0xb);
    uStack_8 = 9;
    uVar4 = FUN_00563a70(param_1,auStack_28);
    uStack_8 = 0xffffffff;
    *(undefined4 *)(*param_2 + 0x78) = uVar4;
    if (0xf < uStack_14) {
      uVar8 = uStack_14 + 1;
      uVar7 = auStack_28[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_28[0] - 4);
        uVar8 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("MaxPlayers",10);
    uStack_8 = 10;
    uVar4 = FUN_00563a70(param_1,auStack_28);
    uStack_8 = 0xffffffff;
    *(undefined4 *)(*param_2 + 0x7c) = uVar4;
    if (0xf < uStack_14) {
      uVar8 = uStack_14 + 1;
      uVar7 = auStack_28[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_28[0] - 4);
        uVar8 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("ApiKey",6);
    uStack_8 = 0xb;
    puVar5 = (undefined4 *)FUN_00563af0(auStack_40,param_1,auStack_28);
    iVar1 = *param_2;
    if ((undefined4 *)(iVar1 + 0x80) != puVar5) {
      FUN_005507b0();
      uVar4 = puVar5[1];
      uVar2 = puVar5[2];
      uVar3 = puVar5[3];
      *(undefined4 *)(iVar1 + 0x80) = *puVar5;
      *(undefined4 *)(iVar1 + 0x84) = uVar4;
      *(undefined4 *)(iVar1 + 0x88) = uVar2;
      *(undefined4 *)(iVar1 + 0x8c) = uVar3;
      *(undefined8 *)(iVar1 + 0x90) = *(undefined8 *)(puVar5 + 4);
      puVar5[4] = 0;
      puVar5[5] = 0xf;
      *(undefined *)puVar5 = 0;
    }
    if (0xf < uStack_2c) {
      uVar8 = uStack_2c + 1;
      uVar7 = auStack_40[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_40[0] - 4);
        uVar8 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    uStack_8 = 0xffffffff;
    if (0xf < uStack_14) {
      uVar8 = uStack_14 + 1;
      uVar7 = auStack_28[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_28[0] - 4);
        uVar8 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("PreferredPlayerCapacity",0x17);
    uStack_8 = 0xc;
    uVar4 = FUN_00563a70(param_1,auStack_28);
    uStack_8 = 0xffffffff;
    *(undefined4 *)(*param_2 + 0x98) = uVar4;
    if (0xf < uStack_14) {
      uVar8 = uStack_14 + 1;
      uVar7 = auStack_28[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_28[0] - 4);
        uVar8 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8 = 0xd;
    uStack_6c = 0;
    uStack_68 = 0xf;
    auStack_7c[0] = auStack_7c[0] & 0xffffff00;
    FUN_005542c0("Metadata",8);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
    puVar5 = (undefined4 *)FUN_0054ef60(auStack_28);
    aiStack_4c[1] = 2;
    FUN_00563920(param_1,auStack_7c,auStack_94);
    iVar1 = *param_2;
    if ((undefined4 *)(iVar1 + 0xa0) != puVar5) {
      FUN_005507b0();
      uVar4 = puVar5[1];
      uVar2 = puVar5[2];
      uVar3 = puVar5[3];
      *(undefined4 *)(iVar1 + 0xa0) = *puVar5;
      *(undefined4 *)(iVar1 + 0xa4) = uVar4;
      *(undefined4 *)(iVar1 + 0xa8) = uVar2;
      *(undefined4 *)(iVar1 + 0xac) = uVar3;
      *(undefined8 *)(iVar1 + 0xb0) = *(undefined8 *)(puVar5 + 4);
      puVar5[4] = 0;
      puVar5[5] = 0xf;
      *(undefined *)puVar5 = 0;
    }
    if (0xf < uStack_80) {
      uVar8 = uStack_80 + 1;
      uVar7 = auStack_94[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_94[0] - 4);
        uVar8 = uStack_80 + 0x24;
        if (0x1f < (auStack_94[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_84 = 0;
    uStack_80 = 0xf;
    auStack_94[0] = auStack_94[0] & 0xffffff00;
    if (0xf < uStack_68) {
      uVar8 = uStack_68 + 1;
      uVar7 = auStack_7c[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_7c[0] - 4);
        uVar8 = uStack_68 + 0x24;
        if (0x1f < (auStack_7c[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_6c = 0;
    uStack_68 = 0xf;
    auStack_7c[0] = auStack_7c[0] & 0xffffff00;
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  uVar4 = FUN_005543f0();
  FUN_016756b0(auStack_58,"missing %s setting",uVar4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_58,&DAT_01c17198);
}



/* FUNCTION 3979 ; VA 0x00587410 ; FUN_00587410 */

void __fastcall FUN_00587410(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796b90;
  pvStack_10 = ExceptionList;
  if (*param_1 == 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_0056aeb0(1,"boost unique_lock has no mutex");
    uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
    FUN_00564990(uVar1);
  }
  if (*(char *)(param_1 + 1) == '\0') {
    ExceptionList = &pvStack_10;
    FUN_005874f0();
    *(undefined *)(param_1 + 1) = 1;
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0056aeb0(0x24,"boost unique_lock owns already the mutex");
  uStack_8 = 1;
                    /* WARNING: Subroutine does not return */
  FUN_00564990(uVar1);
}



/* FUNCTION 3980 ; VA 0x00587490 ; FUN_00587490 */

undefined4 * __thiscall FUN_00587490(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  *param_2 = 0;
  param_2[1] = 0;
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    iVar2 = *(int *)(iVar1 + 4);
    piVar3 = (int *)(iVar1 + 4);
    if (iVar2 != 0) {
      while( true ) {
        LOCK();
        iVar1 = *piVar3;
        if (iVar2 == iVar1) {
          *piVar3 = iVar2 + 1;
          iVar1 = iVar2;
        }
        UNLOCK();
        if (iVar1 == iVar2) break;
        iVar2 = *piVar3;
        if (iVar2 == 0) {
          return param_2;
        }
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
    }
  }
  return param_2;
}



/* FUNCTION 3981 ; VA 0x005874f0 ; FUN_005874f0 */

void __fastcall FUN_005874f0(uint *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uStack_8;
  
  LOCK();
  uVar4 = *param_1;
  *param_1 = *param_1 | 0x80000000;
  UNLOCK();
  if ((int)uVar4 < 0) {
    uStack_8 = *param_1;
    FUN_00588050(&uStack_8);
    uVar4 = uStack_8;
    if ((int)uStack_8 < 0) {
      uVar1 = FUN_00554e40();
      do {
        WaitForSingleObjectEx(uVar1,0xffffffff,0);
        uVar2 = uVar4 & 0x3fffffff | 0x40000000;
        do {
          uVar4 = uVar2;
          uVar3 = uVar4;
          if (-1 < (int)uVar4) {
            uVar3 = uVar4 - 1 | 0x80000000;
          }
          LOCK();
          uVar2 = *param_1;
          if (uVar4 == uVar2) {
            *param_1 = uVar3 & 0xbfffffff;
            uVar2 = uVar4;
          }
          UNLOCK();
        } while (uVar2 != uVar4);
      } while ((int)uVar4 < 0);
    }
  }
  return;
}



/* FUNCTION 3982 ; VA 0x00587580 ; FUN_00587580 */

void __fastcall FUN_00587580(int *param_1)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = 0;
  LOCK();
  iVar1 = *param_1;
  *param_1 = 1;
  UNLOCK();
  while (iVar1 != 0) {
    if ((3 < uVar2) && (0xf < uVar2)) {
      Sleep(0x1f < uVar2);
    }
    uVar2 = uVar2 + 1;
    LOCK();
    iVar1 = *param_1;
    *param_1 = 1;
    UNLOCK();
  }
  return;
}



/* FUNCTION 3983 ; VA 0x005875d0 ; FUN_005875d0 */

void __thiscall FUN_005875d0(int *param_1,int *param_2,undefined4 *param_3)

{
  char cVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  
  puVar6 = (undefined4 *)((undefined4 *)*param_1)[1];
  cVar1 = *(char *)((int)puVar6 + 0xd);
  puVar2 = (undefined4 *)*param_1;
  while (cVar1 == '\0') {
    piVar3 = puVar6 + 4;
    puVar5 = param_3;
    if (0xf < (uint)param_3[5]) {
      puVar5 = (undefined4 *)*param_3;
    }
    if (0xf < (uint)puVar6[9]) {
      piVar3 = (int *)*piVar3;
    }
    iVar4 = FUN_0055c2d0(piVar3,puVar6[8],puVar5,param_3[4]);
    if (iVar4 < 0) {
      puVar5 = (undefined4 *)puVar6[2];
      puVar6 = puVar2;
    }
    else {
      puVar5 = (undefined4 *)*puVar6;
    }
    puVar2 = puVar6;
    puVar6 = puVar5;
    cVar1 = *(char *)((int)puVar5 + 0xd);
  }
  *param_2 = (int)puVar2;
  return;
}



/* FUNCTION 3984 ; VA 0x00587630 ; FUN_00587630 */

int * FUN_00587630(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00587707. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00587686. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1d910ac);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_418ff12f77e425839856db7437ea1b4e>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 3985 ; VA 0x00587720 ; FUN_00587720 */

void FUN_00587720(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      return;
    }
    if (param_3 == 1) {
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d9111c);
      iVar2 = 0;
      if (iVar1 == 0) {
        iVar2 = param_1;
      }
      *param_2 = iVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_64623567add5826fc7d2a45eba0126fe>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 3986 ; VA 0x00587780 ; FUN_00587780 */

int * FUN_00587780(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00587857. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x005877d6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1d910e4);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_8ac8f2724a602bb666e1479f89f1247c>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 3987 ; VA 0x00587870 ; FUN_00587870 */

void FUN_00587870(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796bbf;
  pvStack_10 = ExceptionList;
  if (param_3 == 4) {
    *param_2 = (int)&boost::_bi::
                     bind_t<void,void_(__cdecl*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,int_(__cdecl*)(unsigned___int64,unsigned_char_const*,int)),class_boost::_bi::list4<class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<int_(__cdecl*)(unsigned___int64,unsigned_char_const*,int)>_>_>
                     ::RTTI_Type_Descriptor;
    *(undefined2 *)(param_2 + 1) = 0;
    return;
  }
  if (param_3 == 0) {
    puVar1 = (undefined4 *)*param_1;
    ExceptionList = &pvStack_10;
    puVar2 = (undefined4 *)FUN_01674e20(0x50);
    uStack_8 = 0;
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = *puVar1;
      FUN_0054ef60(puVar1 + 1);
      uStack_8._0_1_ = 1;
      FUN_0054ef60(puVar1 + 7);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_0054ef60(puVar1 + 0xd);
      puVar2[0x13] = puVar1[0x13];
    }
    *param_2 = (int)puVar2;
    ExceptionList = pvStack_10;
    return;
  }
  if (param_3 == 1) {
    *param_2 = *param_1;
    *param_1 = 0;
    return;
  }
  if (param_3 == 2) {
    iVar3 = *param_2;
    if (iVar3 != 0) {
      ExceptionList = &pvStack_10;
      FUN_0056ba50();
      FUN_01674ea0(iVar3,0x50);
    }
    *param_2 = 0;
    ExceptionList = pvStack_10;
    return;
  }
  if (param_3 != 3) {
    *param_2 = (int)&boost::_bi::
                     bind_t<void,void_(__cdecl*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,int_(__cdecl*)(unsigned___int64,unsigned_char_const*,int)),class_boost::_bi::list4<class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<int_(__cdecl*)(unsigned___int64,unsigned_char_const*,int)>_>_>
                     ::RTTI_Type_Descriptor;
    *(undefined2 *)(param_2 + 1) = 0;
    return;
  }
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0170d8dd(*param_2 + 4,0x1d90c44);
  if (iVar3 == 0) {
    *param_2 = *param_1;
    ExceptionList = pvStack_10;
    return;
  }
  *param_2 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3988 ; VA 0x00587a00 ; FUN_00587a00 */

void FUN_00587a00(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d90bbc);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_RCCServiceSoapService*),class_boost::_bi::list1<class_boost::_bi::value<class_RCCServiceSoapService*>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 3989 ; VA 0x00587a70 ; FUN_00587a70 */

void FUN_00587a70(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d90d4c);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf0<void,class_CWebService>,class_boost::_bi::list1<class_boost::_bi::value<class_CWebService*>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 3990 ; VA 0x00587ae0 ; FUN_00587ae0 */

int * FUN_00587ae0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[3] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[3];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00587bc8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[3];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00587b36. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1d90dcc);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf1<void,class_CWebService,class_std::shared_ptr<struct_CWebService::JobItem>_>,class_boost::_bi::list2<class_boost::_bi::value<class_CWebService*>,class_boost::_bi::value<class_std::shared_ptr<struct_CWebService::JobItem>_>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 3991 ; VA 0x00587be0 ; FUN_00587be0 */

void FUN_00587be0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796bdf;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar4 = (undefined4 *)FUN_01674e20(0x2c);
      uStack_8 = 0;
      if (puVar4 == (undefined4 *)0x0) {
        *param_2 = 0;
        ExceptionList = pvStack_10;
        return;
      }
      *puVar4 = *puVar1;
      puVar4[1] = puVar1[1];
      FUN_0054ef60(puVar1 + 2);
      puVar4[8] = puVar1[8];
      puVar4[9] = puVar1[9];
      puVar4[10] = puVar1[10];
      *param_2 = (int)puVar4;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar6 = *param_2;
      if (iVar6 != 0) {
        uVar2 = *(uint *)(iVar6 + 0x1c);
        ExceptionList = &pvStack_10;
        if (0xf < uVar2) {
          iVar3 = *(int *)(iVar6 + 8);
          uVar7 = uVar2 + 1;
          iVar5 = iVar3;
          if (0xfff < uVar7) {
            iVar5 = *(int *)(iVar3 + -4);
            uVar7 = uVar2 + 0x24;
            if (0x1f < (iVar3 - iVar5) - 4U) {
              ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          ExceptionList = &pvStack_10;
          FUN_01674ea0(iVar5,uVar7);
        }
        *(undefined4 *)(iVar6 + 0x18) = 0;
        *(undefined4 *)(iVar6 + 0x1c) = 0xf;
        *(undefined *)(iVar6 + 8) = 0;
        FUN_01674ea0(iVar6,0x2c);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar6 = FUN_0170d8dd(*param_2 + 4,0x1d90eac);
      if (iVar6 != 0) {
        *param_2 = 0;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = *param_1;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf4<void,class_CWebService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_ns1__ScriptExecution*,class_std::vector<class_ns1__LuaValue*,class_std::allocator<class_ns1__LuaValue*>_>*,struct_soap*>,class_boost::_bi::list5<class_boost::_bi::value<class_CWebService*>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<class_ns1__ScriptExecution*>,class_boost::_bi::value<class_std::vector<class_ns1__LuaValue*,class_std::allocator<class_ns1__LuaValue*>_>*>,class_boost::_bi::value<struct_soap*>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 3992 ; VA 0x00587d90 ; FUN_00587d90 */

void __thiscall FUN_00587d90(int param_1,undefined4 *param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uVar2 = *param_2;
  iVar3 = param_2[1];
  ExceptionList = &pvStack_10;
  if (iVar3 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x10) = uVar2;
  piVar4 = *(int **)(param_1 + 0x14);
  *(int *)(param_1 + 0x14) = iVar3;
  uStack_8 = 0;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar4 + 4))();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 8))();
      }
    }
  }
  uStack_8 = 0xffffffff;
  FUN_00587e20(param_3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3993 ; VA 0x00587e20 ; FUN_00587e20 */

uint * __thiscall FUN_00587e20(int param_1,undefined4 param_2)

{
  uint uVar1;
  uint *puVar2;
  uint *puVar3;
  uint *puVar4;
  uint uVar5;
  undefined4 *puVar6;
  int *piVar7;
  int iVar8;
  undefined4 uVar9;
  uint *puVar10;
  int *piVar11;
  code *pcVar12;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796bf8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined *)(param_1 + 0x18) = 1;
  FUN_00588350();
  puVar2 = *(uint **)(param_1 + 0x4c);
  puVar10 = puVar2;
  pcVar12 = SetEvent_exref;
  for (puVar3 = (uint *)*puVar2; puVar3 != puVar2; puVar3 = (uint *)*puVar3) {
    puVar4 = (uint *)puVar3[2];
    puVar10 = (uint *)puVar4[2];
    if (puVar10 != (uint *)0x0) {
      FUN_005874f0();
      uVar5 = puVar4[2];
      if (uVar5 == 0) {
        LOCK();
        puVar10 = (uint *)*puVar4;
        *puVar4 = *puVar4 + 0x80000000;
        UNLOCK();
        if ((((uint)puVar10 & 0x40000000) == 0) && (-0x80000000 < (int)puVar10)) {
          LOCK();
          uVar1 = *puVar4;
          *puVar4 = *puVar4 | 0x40000000;
          UNLOCK();
          if ((uVar1 >> 0x1e & 1) == 0) {
            uStack_8 = uVar5;
            uVar9 = FUN_00554e40();
            puVar10 = (uint *)(*pcVar12)(uVar9);
          }
        }
      }
      else {
        puVar4[2] = 0;
        ReleaseSemaphore(puVar4[7],uVar5,0);
        piVar7 = (int *)puVar4[5];
        for (piVar11 = (int *)puVar4[4]; piVar11 != piVar7; piVar11 = piVar11 + 1) {
          puVar6 = (undefined4 *)*piVar11;
          *(undefined *)(puVar6 + 3) = 1;
          ReleaseSemaphore(*puVar6,puVar6[2],0);
        }
        FUN_005595e0(puVar4[4],puVar4[5],puVar4 + 4);
        puVar4[5] = puVar4[4];
        uVar5 = puVar4[7];
        if ((uVar5 != 0) && (uVar5 != 0xffffffff)) {
          CloseHandle(uVar5);
        }
        puVar4[7] = 0;
        uStack_8 = 1;
        LOCK();
        puVar10 = (uint *)*puVar4;
        *puVar4 = *puVar4 + 0x80000000;
        UNLOCK();
        pcVar12 = SetEvent_exref;
        if ((((uint)puVar10 & 0x40000000) == 0) && (-0x80000000 < (int)puVar10)) {
          LOCK();
          uVar5 = *puVar4;
          *puVar4 = *puVar4 | 0x40000000;
          UNLOCK();
          pcVar12 = SetEvent_exref;
          if ((uVar5 >> 0x1e & 1) == 0) {
            uVar9 = FUN_00554e40();
            pcVar12 = SetEvent_exref;
            puVar10 = (uint *)SetEvent(uVar9);
          }
        }
      }
      uStack_8 = 0xffffffff;
    }
  }
  puVar6 = *(undefined4 **)(param_1 + 0x7c);
  if (puVar6 != (undefined4 *)0x0) {
    piVar7 = *(int **)(param_1 + 0x80);
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar7[1] = piVar7[1] + 1;
      UNLOCK();
    }
    *(undefined4 *)(param_1 + 0x7c) = 0;
    piVar11 = *(int **)(param_1 + 0x80);
    *(undefined4 *)(param_1 + 0x80) = 0;
    uStack_8._0_1_ = 3;
    uStack_8._1_3_ = 0;
    if (piVar11 != (int *)0x0) {
      LOCK();
      iVar8 = piVar11[1] + -1;
      piVar11[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar11 + 4))();
        LOCK();
        iVar8 = piVar11[2] + -1;
        piVar11[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar11 + 8))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    puVar10 = (uint *)(**(code **)*puVar6)(param_2);
    uStack_8 = 4;
    if (piVar7 != (int *)0x0) {
      LOCK();
      puVar2 = (uint *)(piVar7 + 1);
      uVar5 = *puVar2;
      puVar10 = (uint *)*puVar2;
      *puVar2 = uVar5 - 1;
      UNLOCK();
      if (uVar5 - 1 == 0) {
        puVar10 = (uint *)(**(code **)(*piVar7 + 4))();
        LOCK();
        piVar11 = piVar7 + 2;
        iVar8 = *piVar11;
        *piVar11 = *piVar11 + -1;
        UNLOCK();
        if (iVar8 == 1) {
          puVar10 = (uint *)(**(code **)(*piVar7 + 8))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar10;
}



/* FUNCTION 3994 ; VA 0x00588050 ; FUN_00588050 */

void __thiscall FUN_00588050(uint *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  
  uVar1 = *param_2;
  while( true ) {
    uVar3 = uVar1 + 1;
    if (-1 < (int)uVar1) {
      uVar3 = uVar1 | 0x80000000;
    }
    LOCK();
    uVar2 = *param_1;
    if (uVar1 == uVar2) {
      *param_1 = uVar3;
      uVar2 = uVar1;
    }
    UNLOCK();
    if (uVar2 == *param_2) break;
    *param_2 = uVar2;
    uVar1 = uVar2;
  }
  if ((int)uVar1 < 0) {
    *param_2 = uVar3;
  }
  return;
}



/* FUNCTION 3995 ; VA 0x00588090 ; FUN_00588090 */

undefined8 FUN_00588090(void)

{
  return 0x7fffffffffffffff;
}



/* FUNCTION 3996 ; VA 0x005880a0 ; FUN_005880a0 */

void FUN_005880a0(undefined4 *param_1,undefined4 *param_2)

{
  *param_2 = 0;
  param_2[1] = 0;
  *param_2 = *param_1;
  param_2[1] = param_1[1];
  *param_1 = 0;
  param_1[1] = 0;
  return;
}



/* FUNCTION 3997 ; VA 0x005880d0 ; FUN_005880d0 */

void __thiscall FUN_005880d0(uint *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar4 = ExceptionList;
  puStack_c = &LAB_01796c10;
  pvStack_10 = ExceptionList;
  if (param_2 != param_1) {
    uVar1 = *param_2;
    uStack_8 = 0;
    if (uVar1 != 0) {
      ExceptionList = &pvStack_10;
      *param_1 = uVar1;
      if ((uVar1 & 1) != 0) {
        uVar1 = param_2[3];
        uVar2 = param_2[4];
        uVar3 = param_2[5];
        param_1[2] = param_2[2];
        param_1[3] = uVar1;
        param_1[4] = uVar2;
        param_1[5] = uVar3;
        *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
        *param_2 = 0;
        ExceptionList = pvVar4;
        return;
      }
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,param_1 + 2,1);
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    uVar1 = *param_1;
    if (uVar1 != 0) {
      if ((uVar1 & 1) == 0) {
        if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
          ExceptionList = &pvStack_10;
          (**(code **)(uVar1 & 0xfffffffe))(param_1 + 2,param_1 + 2,2);
        }
      }
      *param_1 = 0;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3998 ; VA 0x005881a5 ; Catch_All@005881a5 */

void Catch_All_005881a5(void)

{
  int unaff_EBP;
  
  **(undefined4 **)(unaff_EBP + -0x14) = 0;
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 3999 ; VA 0x005881c0 ; FUN_005881c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005881c0(undefined4 *param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  byte bVar4;
  uint uVar5;
  
  uVar3 = _UNK_018be270;
  uVar2 = _UNK_018be26c;
  uVar1 = _UNK_018be268;
  *param_1 = _DAT_018be264;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  uVar3 = _UNK_018be280;
  uVar2 = _UNK_018be27c;
  uVar1 = _UNK_018be278;
  param_1[4] = _DAT_018be274;
  param_1[5] = uVar1;
  param_1[6] = uVar2;
  param_1[7] = uVar3;
  uVar3 = _UNK_018be290;
  uVar2 = _UNK_018be28c;
  uVar1 = _UNK_018be288;
  param_1[8] = _DAT_018be284;
  param_1[9] = uVar1;
  param_1[10] = uVar2;
  param_1[0xb] = uVar3;
  param_1[0xc] = DAT_018be294;
  *(undefined2 *)(param_1 + 0xd) = DAT_018be298;
  *(byte *)((int)param_1 + 0x36) = ((byte)param_2 & 0xf) + 0x41;
  *(byte *)((int)param_1 + 0x37) = ((byte)(param_2 >> 4) & 0xf) + 0x41;
  *(byte *)(param_1 + 0xe) = ((byte)((uint)param_2 >> 8) & 0xf) + 0x41;
  *(byte *)((int)param_1 + 0x39) = ((byte)(param_2 >> 0xc) & 0xf) + 0x41;
  *(byte *)((int)param_1 + 0x3a) = ((byte)((uint)param_2 >> 0x10) & 0xf) + 0x41;
  *(byte *)((int)param_1 + 0x3b) = ((byte)(param_2 >> 0x14) & 0xf) + 0x41;
  bVar4 = (byte)((uint)param_2 >> 0x18);
  *(byte *)(param_1 + 0xf) = (bVar4 & 0xf) + 0x41;
  *(byte *)((int)param_1 + 0x3d) = ((char)bVar4 >> 4 & 0xfU) + 0x41;
  *(undefined *)((int)param_1 + 0x3e) = 0;
  uVar5 = GetCurrentProcessId();
  *(byte *)(param_1 + 0x10) = ((byte)(uVar5 >> 8) & 0xf) + 0x41;
  *(byte *)((int)param_1 + 0x3e) = ((byte)uVar5 & 0xf) + 0x41;
  *(byte *)((int)param_1 + 0x41) = ((byte)(uVar5 >> 0xc) & 0xf) + 0x41;
  *(byte *)((int)param_1 + 0x3f) = ((byte)(uVar5 >> 4) & 0xf) + 0x41;
  *(byte *)((int)param_1 + 0x42) = ((byte)(uVar5 >> 0x10) & 0xf) + 0x41;
  *(byte *)((int)param_1 + 0x43) = ((byte)(uVar5 >> 0x14) & 0xf) + 0x41;
  bVar4 = (byte)(uVar5 >> 0x18);
  *(byte *)(param_1 + 0x11) = (bVar4 & 0xf) + 0x41;
  *(byte *)((int)param_1 + 0x45) = (bVar4 >> 4) + 0x41;
  *(undefined *)((int)param_1 + 0x46) = 0;
  return;
}


