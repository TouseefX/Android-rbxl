/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 22250 ; VA 0x00ac8540 ; FUN_00ac8540 */

void __fastcall FUN_00ac8540(int param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = *(int **)(param_1 + 0x20);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = *(uint *)(param_1 + 0x18);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 4);
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0xf;
  *(undefined *)(param_1 + 4) = 0;
  return;
}



/* FUNCTION 22251 ; VA 0x00ac85c0 ; FUN_00ac85c0 */

code * __fastcall FUN_00ac85c0(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  code *pcVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  pcVar6 = *(code **)(param_1 + 0x10);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (pcVar6 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      ExceptionList = &pvStack_10;
      if (pcVar6 != (code *)0x0) {
        ExceptionList = &pvStack_10;
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x18,param_1 + 0x18,2);
      }
    }
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  piVar5 = *(int **)(param_1 + 0xc);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      pcVar6 = (code *)(**(code **)*piVar5)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 22252 ; VA 0x00ac8650 ; FUN_00ac8650 */

void __fastcall FUN_00ac8650(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x30);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x28);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00ac8540();
  return;
}



/* FUNCTION 22253 ; VA 0x00ac86b0 ; FUN_00ac86b0 */

void __fastcall FUN_00ac86b0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x38);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00ac8650();
  return;
}



/* FUNCTION 22254 ; VA 0x00ac86f0 ; FUN_00ac86f0 */

void __fastcall FUN_00ac86f0(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x38);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x40,param_1 + 0x40,2);
      }
    }
    *(undefined4 *)(param_1 + 0x38) = 0;
  }
  FUN_00ac8650();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22255 ; VA 0x00ac8750 ; FUN_00ac8750 */

void __fastcall FUN_00ac8750(int param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar2 = *(uint *)(param_1 + 0x40);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x48,param_1 + 0x48,2);
      }
    }
    *(undefined4 *)(param_1 + 0x40) = 0;
  }
  piVar3 = *(int **)(param_1 + 0x38);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_00ac8650();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22256 ; VA 0x00ac87e0 ; FUN_00ac87e0 */

void __fastcall FUN_00ac87e0(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x58);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x60,param_1 + 0x60,2);
      }
    }
    *(undefined4 *)(param_1 + 0x58) = 0;
  }
  uVar1 = *(uint *)(param_1 + 0x38);
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x40,param_1 + 0x40,2);
      }
    }
    *(undefined4 *)(param_1 + 0x38) = 0;
  }
  FUN_00ac8650();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22257 ; VA 0x00ac8870 ; FUN_00ac8870 */

void __fastcall FUN_00ac8870(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00ad3a40(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 22258 ; VA 0x00ac88f0 ; FUN_00ac88f0 */

void * __fastcall FUN_00ac88f0(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  void *pvVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar2 = *(uint *)(param_1 + 0xec);
  pvVar6 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0xd8);
    uVar7 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar7) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar7 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
        ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    ExceptionList = &pvStack_10;
    pvVar6 = (void *)FUN_01674ea0(iVar5,uVar7);
  }
  *(undefined4 *)(param_1 + 0xe8) = 0;
  *(undefined4 *)(param_1 + 0xec) = 0xf;
  *(undefined *)(param_1 + 0xd8) = 0;
  uStack_8 = 0;
  if (*(int *)(param_1 + 0xc) != 0) {
    pvVar6 = (void *)(**(code **)(*(int *)(param_1 + 0xc) + 8))(param_1 + 0x10);
  }
  piVar4 = *(int **)(param_1 + 4);
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar1 = piVar4 + 1;
    iVar3 = *piVar1;
    pvVar6 = (void *)*piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      pvVar6 = (void *)(**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        pvVar6 = (void *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar6;
}



/* FUNCTION 22259 ; VA 0x00ac89c0 ; FUN_00ac89c0 */

void __fastcall FUN_00ac89c0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0xf4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00ac88f0();
  return;
}



/* FUNCTION 22260 ; VA 0x00ac8a00 ; FUN_00ac8a00 */

void * __fastcall FUN_00ac8a00(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar3 = *(int **)(param_1 + 0xdc);
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    ExceptionList = &pvStack_10;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar4 = (void *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = 0;
  if (*(int *)(param_1 + 0xc) != 0) {
    pvVar4 = (void *)(**(code **)(*(int *)(param_1 + 0xc) + 8))(param_1 + 0x10);
  }
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 22261 ; VA 0x00ac8aa0 ; FUN_00ac8aa0 */

void * __fastcall FUN_00ac8aa0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0xc) != 0) {
    ExceptionList = &pvStack_10;
    pvVar4 = (void *)(**(code **)(*(int *)(param_1 + 0xc) + 8))(param_1 + 0x10);
  }
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 22262 ; VA 0x00ac8b10 ; FUN_00ac8b10 */

void __fastcall FUN_00ac8b10(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00ad3a40(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 22263 ; VA 0x00ac8b20 ; FUN_00ac8b20 */

void __fastcall FUN_00ac8b20(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::TeleportService::vftable;
  FUN_00ac8870();
  FUN_00ac8870();
  FUN_00612320();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = param_1[0x29];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 1;
  FUN_0057d3b0();
  piVar1 = (int *)param_1[0x22];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0x20];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0x1e];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uVar4 = param_1[0x1c];
  if (0xf < uVar4) {
    iVar3 = param_1[0x17];
    uVar6 = uVar4 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar4 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x1b] = 0;
  param_1[0x1c] = 0xf;
  *(undefined *)(param_1 + 0x17) = 0;
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22264 ; VA 0x00ac8cd0 ; FUN_00ac8cd0 */

int * __thiscall FUN_00ac8cd0(byte *param_1,uint *param_2)

{
  byte bVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  int aiStack_40 [5];
  uint uStack_2c;
  uint uStack_28;
  int *piStack_24;
  undefined2 uStack_20;
  int *piStack_1c;
  uint uStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e8710;
  pvStack_10 = ExceptionList;
  bVar1 = *param_1;
  ExceptionList = &pvStack_10;
  pbStack_14 = param_1;
  uStack_18 = FUN_005702d0(param_2);
  iVar5 = (int)param_2;
  FUN_008992d0(&param_2,uStack_18,param_2,
               -(uint)(param_1 + bVar1 + 1 != (byte *)0x0) & (uint)(param_1 + bVar1 + 1 + 1));
  if (param_2 != (uint *)0x0) {
    ExceptionList = pvStack_10;
    return (int *)((int)param_2 + 8);
  }
  piStack_24 = (int *)0x0;
  uStack_20 = 0;
  uStack_28 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(iVar5);
  iStack_8._0_1_ = 1;
  uStack_20 = 0;
  piVar4 = (int *)FUN_01674e20(0x28);
  uStack_20 = CONCAT11(uStack_20._1_1_,1);
  piStack_1c = piVar4 + 2;
  *piVar4 = 0;
  piVar4[1] = 0;
  *piStack_1c = 0;
  piVar4[3] = 0;
  piVar4[4] = 0;
  piVar4[5] = 0;
  piVar4[6] = 0;
  piVar4[7] = 0;
  piVar4[8] = 0;
  piVar4[9] = 0;
  piStack_24 = piVar4;
  FUN_0054ef60(aiStack_40);
  piVar4[8] = 0;
  piVar4[9] = 0;
  uStack_20 = CONCAT11(1,(undefined)uStack_20);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_2c) {
    uVar8 = uStack_2c + 1;
    iVar5 = aiStack_40[0];
    if (0xfff < uVar8) {
      iVar5 = *(int *)(aiStack_40[0] + -4);
      uVar8 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar8);
  }
  uVar2 = *(uint *)(param_1 + 8);
  uVar8 = uVar2 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar8 = FUN_005c9310(uVar8);
    if (uVar8 <= *(uint *)(param_1 + 4)) {
      uVar8 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar8);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar8) {
    param_2 = (uint *)0x1;
    uVar6 = uVar2 >> 1;
    if (uVar2 + (uVar2 >> 1) <= uVar8) {
      uVar6 = 1;
    }
    uVar8 = FUN_005c9310(uVar6 + *(int *)(param_1 + 8));
    param_2 = (uint *)(param_1 + 4);
    if (uVar8 != *param_2) {
      FUN_005d2b00(uVar8);
      puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *param_2 * 4);
      puVar3 = (undefined4 *)*puVar9;
      while (piVar4 = piStack_24, puVar3 != (undefined4 *)0x0) {
        piVar4 = (int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar3[1] % *param_2) * 4);
        if (*(int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar3[1] % *param_2) * 4) == 0) {
          *piVar4 = (int)puVar9;
          puVar9 = puVar3;
        }
        else {
          *puVar9 = *puVar3;
          *puVar3 = *(undefined4 *)*piVar4;
          *(undefined4 **)*piVar4 = puVar3;
        }
        param_1 = pbStack_14;
        puVar3 = (undefined4 *)*puVar9;
      }
    }
  }
  piVar4[1] = uStack_18;
  uVar8 = *(uint *)(param_1 + 4);
  piVar4 = (int *)(*(int *)(param_1 + 0x14) + (uStack_18 % uVar8) * 4);
  if ((int *)*piVar4 == (int *)0x0) {
    piVar7 = (int *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (*piVar7 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % uVar8) * 4) = piStack_24;
    }
    *piVar4 = (int)piVar7;
    *piStack_24 = *piVar7;
  }
  else {
    *piStack_24 = *(int *)*piVar4;
    piVar7 = (int *)*piVar4;
  }
  *piVar7 = (int)piStack_24;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_1c;
}



/* FUNCTION 22265 ; VA 0x00ac8f10 ; FUN_00ac8f10 */

int __fastcall FUN_00ac8f10(int param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint *puVar4;
  int iVar5;
  int *piVar6;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  int *piStack_9c;
  int *piStack_98;
  undefined4 uStack_94;
  int iStack_90;
  undefined4 *puStack_8c;
  undefined4 uStack_88;
  uint auStack_84 [2];
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  int iStack_70;
  ulonglong uStack_6c;
  uint auStack_64 [2];
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined8 uStack_4c;
  int iStack_34;
  int *piStack_30;
  undefined *puStack_28;
  undefined *puStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e876f;
  pvStack_10 = ExceptionList;
  uStack_4c = CONCAT44(&iStack_34,0xac8f38);
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00587490();
  uStack_8 = 0;
  if (iStack_34 != 0) {
    uStack_4c = 0x1800ac8f50;
    piVar6 = (int *)FUN_01674e20();
    uStack_8._0_1_ = 1;
    if (piVar6 == (int *)0x0) {
      piVar6 = (int *)0x0;
    }
    else {
      piVar6[1] = 1;
      piVar6[2] = 1;
      *piVar6 = (int)std::_Ref_count_obj<class_RBX::Timer<0>_>::vftable;
      uStack_4c = CONCAT44(piVar6 + 4,0xac8f7d);
      piStack_14 = piVar6;
      FUN_01682800();
    }
    piStack_14 = (int *)auStack_64;
    puStack_18 = (undefined *)auStack_64;
    uStack_8._0_1_ = 2;
    auStack_64[0] = 0;
    uVar3 = *(uint *)(param_1 + 0x58);
    puVar4 = auStack_64;
    if (uVar3 != 0) {
      auStack_64[0] = uVar3;
      if ((uVar3 & 1) == 0) {
        uStack_6c = ZEXT48(&uStack_5c);
        iStack_70 = param_1 + 0x60;
        uStack_74 = 0xac8fd5;
        (**(code **)(uVar3 & 0xfffffffe))();
        puVar4 = (uint *)piStack_14;
      }
      else {
        uStack_5c = *(undefined4 *)(param_1 + 0x60);
        uStack_58 = *(undefined4 *)(param_1 + 100);
        uStack_54 = *(undefined4 *)(param_1 + 0x68);
        uStack_50 = *(undefined4 *)(param_1 + 0x6c);
        uStack_4c = *(undefined8 *)(param_1 + 0x70);
        puVar4 = auStack_64;
      }
    }
    piStack_14 = (int *)puVar4;
    puStack_18 = (undefined *)auStack_84;
    puStack_1c = (undefined *)auStack_84;
    uStack_8._0_1_ = 3;
    auStack_84[0] = 0;
    uVar3 = *(uint *)(param_1 + 0x38);
    puVar4 = auStack_84;
    if (uVar3 != 0) {
      auStack_84[0] = uVar3;
      if ((uVar3 & 1) == 0) {
        puStack_8c = &uStack_7c;
        uStack_88 = 0;
        iStack_90 = param_1 + 0x40;
        uStack_94 = 0xac9020;
        (**(code **)(uVar3 & 0xfffffffe))();
        puVar4 = (uint *)puStack_18;
      }
      else {
        uStack_7c = *(undefined4 *)(param_1 + 0x40);
        uStack_78 = *(undefined4 *)(param_1 + 0x44);
        uStack_74 = *(undefined4 *)(param_1 + 0x48);
        iStack_70 = *(int *)(param_1 + 0x4c);
        uStack_6c = *(ulonglong *)(param_1 + 0x50);
        puVar4 = auStack_84;
      }
    }
    puStack_18 = (undefined *)puVar4;
    puStack_1c = (undefined *)&puStack_8c;
    if (*(int *)(param_1 + 0x34) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(param_1 + 0x34) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    puStack_8c = *(undefined4 **)(param_1 + 0x30);
    uStack_88 = *(undefined4 *)(param_1 + 0x34);
    puStack_20 = (undefined *)&uStack_94;
    if (*(int *)(param_1 + 0x2c) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(param_1 + 0x2c) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_94 = *(undefined4 *)(param_1 + 0x28);
    iStack_90 = *(undefined4 *)(param_1 + 0x2c);
    puStack_24 = (undefined *)&piStack_9c;
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
    }
    piStack_9c = piVar6 + 4;
    puStack_28 = (undefined *)&uStack_a4;
    if (*(int *)(param_1 + 0x24) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(param_1 + 0x24) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_a4 = *(undefined4 *)(param_1 + 0x20);
    uStack_a0 = *(undefined4 *)(param_1 + 0x24);
    uStack_8._0_1_ = 8;
    piStack_98 = piVar6;
    FUN_0054ef60(param_1 + 8);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    iVar5 = FUN_00adaec0();
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar1 = piVar6 + 1;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        uStack_4c = CONCAT44(0xac90fd,(undefined4)uStack_4c);
        (**(code **)*piVar6)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar2 = *piVar1;
        iVar5 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          uStack_4c = CONCAT44(0xac910d,(undefined4)uStack_4c);
          iVar5 = (**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    piVar6 = piStack_30 + 1;
    iVar2 = *piVar6;
    iVar5 = *piVar6;
    *piVar6 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      uStack_4c = CONCAT44(0xac9128,(undefined4)uStack_4c);
      iVar5 = (**(code **)*piStack_30)();
      LOCK();
      piVar6 = piStack_30 + 2;
      iVar2 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_4c = CONCAT44(0xac9137,(undefined4)uStack_4c);
        iVar5 = (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 22266 ; VA 0x00ac9150 ; FUN_00ac9150 */

void __fastcall FUN_00ac9150(undefined8 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined auStack_f0 [136];
  undefined4 uStack_68;
  undefined8 uStack_44;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e87b0;
  pvStack_10 = ExceptionList;
  uStack_44 = CONCAT44(0xac917a,(undefined4)uStack_44);
  ExceptionList = &pvStack_10;
  FUN_005cf2a0();
  uStack_44 = *param_1;
  uVar2 = *(undefined4 *)(param_1 + 1);
  uStack_68 = 0;
  uVar3 = *(uint *)(param_1 + 0xd);
  if ((uVar3 != 0) && ((uVar3 & 1) == 0)) {
    (**(code **)(uVar3 & 0xfffffffe))();
  }
  uStack_8 = 0;
  uVar3 = *(uint *)(param_1 + 9);
  if ((uVar3 != 0) && ((uVar3 & 1) == 0)) {
    (**(code **)(uVar3 & 0xfffffffe))();
  }
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  if (*(int *)(param_1 + 7) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 7) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  if (*(int *)(param_1 + 6) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 6) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  if (*(int *)(param_1 + 5) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 5) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_0054ef60((int)param_1 + 0xc);
  uStack_8 = 0xffffffff;
  FUN_00ac2680(auStack_f0,FUN_00adaec0,0,uVar2);
  FUN_00ac0750();
  uStack_68 = 0xac9321;
  FUN_009eef30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22267 ; VA 0x00ac9340 ; FUN_00ac9340 */

int __thiscall FUN_00ac9340(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  uint in_stack_00000018;
  undefined4 uVar7;
  undefined auStack_44 [4];
  undefined4 uStack_40;
  int iStack_3c;
  undefined4 uStack_38;
  undefined4 *puStack_34;
  int *piStack_30;
  undefined auStack_24 [8];
  int iStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e87e0;
  pvStack_10 = ExceptionList;
  piStack_30 = &iStack_1c;
  uStack_8 = 0;
  puStack_34 = (undefined4 *)0xac936f;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00587490();
  uStack_8._0_1_ = 1;
  if (iStack_1c != 0) {
    if (DAT_01d66670 == '\0') {
      piStack_30 = (int *)(param_1 + 8);
      puStack_34 = &param_2;
      uStack_38 = 1;
      iStack_3c = 0xac9429;
      iVar5 = FUN_00adac20();
    }
    else {
      piStack_30 = (int *)&param_2;
      if (0xf < in_stack_00000018) {
        piStack_30 = param_2;
      }
      puStack_34 = (undefined4 *)&DAT_018bd25c;
      uStack_38 = 2;
      iStack_3c = 0xac93a3;
      FUN_0086f2f0();
      iStack_3c = iStack_1c;
      uStack_40 = 0xac93a9;
      iVar5 = FUN_0097bfc0();
      if (iVar5 != 0) {
        puStack_14 = auStack_44;
        FUN_0054ef60(&param_2);
        uVar7 = 1;
        uStack_8._0_1_ = 2;
        puVar6 = (undefined4 *)FUN_0060dcd0(auStack_24,iVar5,1);
        uVar3 = *puVar6;
        uVar4 = puVar6[1];
        *puVar6 = 0;
        puVar6[1] = 0;
        uStack_8._0_1_ = 4;
        FUN_00ad5040(iStack_1c,uVar3,uVar4,uVar7);
        piStack_30 = (int *)0xac9416;
        iVar5 = FUN_00550b30();
      }
    }
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_30 = (int *)0xac9442;
      iVar5 = (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_30 = (int *)0xac9451;
        iVar5 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000018) {
    piStack_30 = (int *)(in_stack_00000018 + 1);
    puVar6 = param_2;
    if (0xfff < piStack_30) {
      puVar6 = (undefined4 *)param_2[-1];
      piStack_30 = (int *)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar6))) {
                    /* WARNING: Subroutine does not return */
        piStack_30 = (int *)&UNK_00ac9498;
        FUN_017167a3();
      }
    }
    uStack_38 = 0xac947e;
    puStack_34 = puVar6;
    iVar5 = FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 22268 ; VA 0x00ac94a0 ; FUN_00ac94a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint __thiscall FUN_00ac94a0(undefined4 *param_1,undefined **param_2,int *param_3)

{
  int *piVar1;
  uint *puVar2;
  uint uVar3;
  int iVar4;
  double *pdVar5;
  bool bVar6;
  char cVar7;
  uint uVar8;
  int iVar9;
  int *piVar10;
  undefined4 *puVar11;
  undefined **ppuVar12;
  double *pdVar13;
  undefined4 uVar14;
  undefined **ppuVar15;
  undefined4 uStack_5cc;
  undefined4 *puStack_5c8;
  undefined4 uStack_5c4;
  undefined4 *puStack_5c0;
  undefined4 uStack_5bc;
  undefined4 *puStack_5b8;
  undefined auStack_5b4 [24];
  undefined4 uStack_59c;
  undefined4 *puStack_598;
  undefined auStack_594 [4];
  undefined4 uStack_590;
  undefined *puStack_58c;
  code *pcStack_588;
  undefined4 uStack_584;
  undefined **ppuStack_580;
  undefined4 uStack_578;
  undefined auStack_574 [8];
  undefined4 uStack_56c;
  undefined4 *puStack_568;
  code *pcStack_564;
  undefined4 *puStack_560;
  undefined **appuStack_55c [7];
  undefined4 uStack_540;
  undefined4 uStack_53c;
  undefined4 uStack_538;
  undefined4 uStack_534;
  undefined4 uStack_530;
  undefined4 *puStack_52c;
  undefined4 uStack_528;
  char *pcStack_524;
  code *pcStack_520;
  uint uStack_51c;
  undefined4 *puStack_518;
  undefined4 *puStack_514;
  undefined4 uStack_510;
  undefined8 *puStack_50c;
  undefined4 **ppuStack_508;
  char *pcStack_504;
  undefined4 *puStack_500;
  undefined4 *puStack_4fc;
  undefined4 *puStack_4f8;
  undefined4 *puStack_4f4;
  undefined4 *puStack_4f0;
  undefined4 *puStack_4ec;
  undefined **ppuStack_4e8;
  undefined uStack_4e4;
  undefined4 uStack_4e0;
  undefined4 uStack_4dc;
  int *piStack_4d8;
  undefined4 uStack_4d4;
  TypeDescriptor *pTStack_4d0;
  TypeDescriptor *pTStack_4cc;
  int *piStack_4c8;
  undefined auStack_4bc [8];
  undefined4 uStack_4b4;
  undefined4 uStack_4b0;
  undefined auStack_4ac [120];
  undefined auStack_434 [8];
  undefined4 uStack_42c;
  undefined4 uStack_428;
  undefined auStack_424 [120];
  undefined auStack_3ac [8];
  undefined4 uStack_3a4;
  undefined4 uStack_3a0;
  undefined auStack_39c [120];
  undefined auStack_324 [8];
  undefined4 uStack_31c;
  undefined4 uStack_318;
  undefined auStack_314 [120];
  undefined auStack_29c [8];
  undefined4 uStack_294;
  undefined4 uStack_290;
  undefined auStack_28c [120];
  undefined4 uStack_214;
  undefined4 uStack_210;
  undefined auStack_20c [48];
  undefined auStack_1dc [8];
  undefined4 uStack_1d4;
  undefined4 uStack_1d0;
  undefined auStack_1cc [120];
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined auStack_14c [48];
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined auStack_114 [48];
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined auStack_dc [48];
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined auStack_a4 [48];
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined auStack_6c [48];
  undefined *puStack_3c;
  undefined *puStack_38;
  undefined *puStack_34;
  int iStack_30;
  int *piStack_2c;
  undefined4 *puStack_28;
  undefined *puStack_24;
  undefined8 uStack_20;
  undefined4 *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e89b6;
  pvStack_10 = ExceptionList;
  piStack_4c8 = &iStack_30;
  pTStack_4cc = (TypeDescriptor *)0xac94ce;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  FUN_00587490();
  iStack_8 = 0;
  if (iStack_30 == 0) {
    uVar8 = (uint)DAT_01eeb4f0;
    if (DAT_01eeb4f0 != 0) {
      piStack_4c8 = (int *)0x0;
      pTStack_4d0 = (TypeDescriptor *)(uint)DAT_01eeb4f0;
      pTStack_4cc = (TypeDescriptor *)0x194a93c;
      uStack_4d4 = 0xac94f9;
      uVar8 = FUN_016774b0();
    }
  }
  else {
    if (iStack_30 == -0xc) {
      ppuVar15 = (undefined **)0x0;
    }
    else {
      piStack_4c8 = (int *)&LAB_00605b60;
      pTStack_4cc = (TypeDescriptor *)&DAT_01ead2e4;
      pTStack_4d0 = (TypeDescriptor *)0xac951b;
      FUN_005789c0();
      piStack_4c8 = (int *)0xac9523;
      piStack_4c8 = (int *)FUN_00606020();
      pTStack_4cc = (TypeDescriptor *)0xac952b;
      piStack_14 = (int *)FUN_008aa140();
      if (*piStack_14 == 0) {
        if (DAT_01eeb8c4 == 0) {
          piStack_4c8 = (int *)0xac9545;
          iVar9 = FUN_00ac0f70();
          DAT_01eeb8c4 = *(int *)(iVar9 + 4);
        }
        pTStack_4cc = (TypeDescriptor *)&uStack_20;
        pTStack_4d0 = (TypeDescriptor *)0xac9559;
        piStack_4c8 = (int *)DAT_01eeb8c4;
        piVar10 = (int *)FUN_008a9ba0();
        iVar9 = *piVar10;
        iVar4 = piVar10[1];
        *piVar10 = 0;
        piVar10[1] = 0;
        *piStack_14 = iVar9;
        piVar10 = (int *)piStack_14[1];
        piStack_14[1] = iVar4;
        if (piVar10 != (int *)0x0) {
          LOCK();
          iVar9 = piVar10[1] + -1;
          piVar10[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            piStack_4c8 = (int *)0xac958a;
            (**(code **)*piVar10)();
            LOCK();
            iVar9 = piVar10[2] + -1;
            piVar10[2] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              piStack_4c8 = (int *)0xac959b;
              (**(code **)(*piVar10 + 4))();
            }
          }
        }
        piVar10 = uStack_20._4_4_;
        if (uStack_20._4_4_ != (int *)0x0) {
          LOCK();
          iVar9 = uStack_20._4_4_[1] + -1;
          uStack_20._4_4_[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            piStack_4c8 = (int *)0xac95b5;
            (**(code **)*uStack_20._4_4_)();
            LOCK();
            piVar1 = piVar10 + 2;
            iVar9 = *piVar1 + -1;
            *piVar1 = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              piStack_4c8 = (int *)0xac95c6;
              (**(code **)(*piVar10 + 4))();
            }
          }
        }
      }
      ppuVar15 = (undefined **)*piStack_14;
    }
    puStack_28 = ppuVar15;
    piStack_14 = (int *)ppuVar15;
    if (ppuVar15 == (undefined **)0x0) {
      uVar8 = (uint)DAT_01eeb4f0;
      if (DAT_01eeb4f0 != 0) {
        pTStack_4d0 = (TypeDescriptor *)(uint)DAT_01eeb4f0;
        pTStack_4cc = (TypeDescriptor *)0x194a958;
        uStack_4d4 = 0xac95f5;
        piStack_4c8 = (int *)ppuVar15;
        uVar8 = FUN_016774b0();
      }
    }
    else {
      if (param_2 == (undefined **)0x0) {
        piStack_4c8 = (int *)0x0;
        pTStack_4cc = &RBX::http_status_error::RTTI_Type_Descriptor;
        pTStack_4d0 = &std::exception::RTTI_Type_Descriptor;
        uStack_4d4 = 0;
        piStack_4d8 = param_3;
        uStack_4dc = 0xac9930;
        iVar9 = FUN_0170d75d();
        puVar11 = puStack_18;
        if (iVar9 == 0) {
          piStack_4c8 = (int *)0xac9d19;
          uVar14 = (**(code **)(*param_3 + 4))();
          piStack_4c8 = (int *)0x1;
          puStack_18 = &ppuStack_4e8;
          puStack_50c = (undefined8 *)(param_1 + 0x18);
          uStack_510 = 0xac9d31;
          FUN_0054f510();
          puStack_514 = param_1 + 8;
          puStack_518 = (undefined4 *)0xac9d3f;
          FUN_00557fc0();
          puStack_518 = piStack_14;
          pcStack_524 = (char *)&uStack_214;
          uStack_51c = 0;
          pcStack_520 = FUN_00ad9610;
          uStack_528 = 0xac9d56;
          puStack_514 = (undefined4 *)uVar14;
          FUN_00ac22e0();
          uStack_154 = uStack_214;
          uStack_150 = uStack_210;
          puStack_4ec = (undefined4 *)auStack_20c;
          iStack_8._0_1_ = 0x25;
          puStack_4f0 = (undefined4 *)0xac9d87;
          FUN_00ac4f90();
          puVar11 = puStack_18;
          uStack_11c = uStack_154;
          uStack_118 = uStack_150;
          puStack_4ec = (undefined4 *)auStack_14c;
          iStack_8._0_1_ = 0x26;
          *puStack_18 = 0;
          puStack_4f0 = (undefined4 *)0xac9dbe;
          FUN_00ac4f90();
          uStack_e4 = uStack_11c;
          uStack_e0 = uStack_118;
          puStack_4ec = (undefined4 *)auStack_114;
          iStack_8._0_1_ = 0x27;
          puStack_4f0 = (undefined4 *)0xac9dec;
          FUN_00ac4f90();
          uStack_74 = uStack_e4;
          uStack_70 = uStack_e0;
          puStack_4ec = (undefined4 *)auStack_dc;
          iStack_8._0_1_ = 0x28;
          puStack_4f0 = (undefined4 *)0xac9e11;
          FUN_00ac4f90();
          puStack_4ec = &uStack_74;
          iStack_8._0_1_ = 0x29;
          puStack_4f0 = (undefined4 *)0xac9e1e;
          cVar7 = FUN_00585a40();
          if (cVar7 == '\0') {
            uStack_ac = uStack_74;
            uStack_a8 = uStack_70;
            puStack_4ec = (undefined4 *)auStack_6c;
            puStack_4f0 = (undefined4 *)0xac9e4a;
            FUN_00ac4f90();
            puStack_4ec = (undefined4 *)0x38;
            iStack_8._0_1_ = 0x2a;
            puStack_4f0 = (undefined4 *)0xac9e55;
            puVar11 = (undefined4 *)FUN_01674e20();
            iStack_8._0_1_ = 0x2b;
            if (puVar11 == (undefined4 *)0x0) {
              puVar11 = (undefined4 *)0x0;
            }
            else {
              puStack_4ec = (undefined4 *)auStack_a4;
              *puVar11 = uStack_ac;
              puVar11[1] = uStack_a8;
              puStack_4f0 = (undefined4 *)0xac9e85;
              FUN_00ac4f90();
            }
            puStack_18[2] = puVar11;
            puStack_4ec = (undefined4 *)0xac9e9a;
            FUN_00ac85c0();
            puStack_4ec = (undefined4 *)0xac9ea2;
            FUN_00ac85c0();
            bVar6 = true;
            puVar11 = puStack_18;
          }
          else {
            puStack_4ec = (undefined4 *)0xac9eb3;
            FUN_00ac85c0();
            bVar6 = false;
          }
          puStack_4ec = (undefined4 *)0xac9ec2;
          FUN_00ac85c0();
          ppuVar15 = &PTR_FUN_0194b574;
          if (!bVar6) {
            ppuVar15 = (undefined **)0x0;
          }
          *puVar11 = ppuVar15;
          puStack_4ec = (undefined4 *)0xac9edc;
          FUN_00ac85c0();
          puStack_4ec = (undefined4 *)0xac9ee7;
          FUN_00ac85c0();
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          puStack_4ec = (undefined4 *)0xac9ef6;
          FUN_00ac85c0();
          puStack_4ec = (undefined4 *)0xac9efe;
          FUN_0090ca30();
          piStack_4c8 = (int *)0xac9f0a;
          iVar9 = (**(code **)(*param_3 + 4))();
          if (iVar9 == 0) {
            ppuStack_4e8 = (undefined **)&DAT_018bc9b8;
          }
          else {
            piStack_4c8 = (int *)0xac9f1e;
            ppuStack_4e8 = (undefined **)(**(code **)(*param_3 + 4))();
          }
          piStack_4c8 = (int *)0x0;
          pTStack_4cc = (TypeDescriptor *)0x0;
          puStack_4ec = (undefined4 *)0xac9f30;
          FUN_0054eff0();
          iStack_8._0_1_ = 0x2c;
          puStack_500 = (undefined4 *)&DAT_00000007;
          puStack_4ec = (undefined4 *)0x0;
          ppuStack_4e8 = (undefined **)0xf;
          pcStack_504 = "Failure";
          puStack_4fc = (undefined4 *)((uint)puStack_4fc & 0xffffff00);
          ppuStack_508 = (undefined4 **)0xac9f59;
          FUN_005542c0();
          ppuStack_508 = (undefined4 **)(param_1 + 0xc);
          uStack_20 = (double)CONCAT44(&pcStack_504,(undefined4)uStack_20);
          puStack_50c = (undefined8 *)0xac9f6a;
          FUN_00557fc0();
          iStack_8._0_1_ = 0x2e;
        }
        else if (*(int *)(iVar9 + 0x24) == 0xca) {
          if (DAT_01eeb4f0 != 0) {
            piStack_4c8 = (int *)0x0;
            pTStack_4d0 = (TypeDescriptor *)(uint)DAT_01eeb4f0;
            pTStack_4cc = (TypeDescriptor *)0x194a998;
            uStack_4d4 = 0xac9964;
            FUN_016774b0();
          }
          pdVar5 = (double *)param_1[10];
          piStack_4c8 = (int *)&uStack_20;
          pTStack_4cc = (TypeDescriptor *)0xac9979;
          pdVar13 = (double *)FUN_01682800();
          piStack_4c8 = (int *)0x1;
          uStack_20 = ((double)DAT_01d665c4 - (*pdVar13 - *pdVar5) * DAT_018c0d70) / DAT_018c0d70;
          if (uStack_20 <= _PTR_018c6f48) {
            puStack_4ec = (undefined4 *)0x0;
            puStack_598 = puStack_18 + 0x18;
            puStack_38 = auStack_594;
            uStack_59c = 0xac9b37;
            FUN_0054f510();
            puStack_34 = auStack_5b4;
            puStack_5b8 = puStack_18 + 0x10;
            iStack_8._0_1_ = 0x17;
            uStack_5bc = 0xac9b4f;
            FUN_0054f510();
            puStack_3c = (undefined *)&uStack_5bc;
            puStack_5c0 = puStack_18 + 0xe;
            uStack_5c4 = 0xac9b63;
            FUN_00557fc0();
            puStack_28 = &uStack_5c4;
            param_3 = puStack_18 + 0xc;
            uStack_5cc = 0xac9b7a;
            puStack_5c8 = param_3;
            FUN_00557fc0();
            puStack_24 = (undefined *)&uStack_5cc;
            FUN_00557fc0();
            FUN_00557fc0(puStack_18 + 8);
            iStack_8._0_1_ = 0x1c;
            FUN_0054ef60(puStack_18 + 2);
            iStack_8 = (uint)iStack_8._1_3_ << 8;
            FUN_00ac2680(auStack_574,FUN_00adaec0,0,piStack_14);
            uStack_578 = 0xac9bd5;
            FUN_00ac05c0();
          }
          else {
            puStack_4ec = param_1 + 0x18;
            puStack_4f0 = param_1 + 0x10;
            puStack_4f4 = param_1 + 0xe;
            param_3 = param_1 + 0xc;
            puStack_4fc = param_1 + 10;
            puStack_500 = param_1 + 8;
            pcStack_504 = (char *)(param_1 + 2);
            ppuStack_508 = &puStack_28;
            puStack_50c = &uStack_20;
            uStack_510 = 0xac99f0;
            puStack_4f8 = param_3;
            FUN_00ac3ee0();
            puStack_4ec = (undefined4 *)auStack_1dc;
            iStack_8._0_1_ = 0x10;
            puStack_4f0 = (undefined4 *)0xac9a06;
            FUN_00ac4070();
            puStack_4ec = (undefined4 *)auStack_29c;
            iStack_8._0_1_ = 0x11;
            ppuStack_4e8 = (undefined **)0x0;
            puStack_4f0 = (undefined4 *)0xac9a22;
            FUN_00ac4070();
            puStack_4ec = (undefined4 *)auStack_324;
            iStack_8._0_1_ = 0x12;
            puStack_4f0 = (undefined4 *)0xac9a38;
            FUN_00ac4070();
            puStack_4ec = (undefined4 *)auStack_3ac;
            iStack_8._0_1_ = 0x13;
            puStack_4f0 = (undefined4 *)0xac9a4e;
            FUN_00ac4070();
            puStack_4ec = (undefined4 *)auStack_4bc;
            iStack_8._0_1_ = 0x14;
            puStack_4f0 = (undefined4 *)0xac9a5e;
            cVar7 = FUN_00585a40();
            if (cVar7 == '\0') {
              puStack_4ec = (undefined4 *)auStack_4bc;
              puStack_4f0 = (undefined4 *)0xac9a77;
              FUN_00ac4070();
              puStack_4ec = (undefined4 *)0x88;
              iStack_8._0_1_ = 0x15;
              puStack_4f0 = (undefined4 *)0xac9a85;
              iVar9 = FUN_01674e20();
              iStack_8._0_1_ = 0x16;
              if (iVar9 == 0) {
                uStack_4e0 = 0;
              }
              else {
                puStack_4ec = (undefined4 *)auStack_434;
                puStack_4f0 = (undefined4 *)0xac9aa1;
                uStack_4e0 = FUN_00ac4070();
              }
              puStack_4ec = (undefined4 *)0xac9ab3;
              FUN_00ac7c20();
              puStack_4ec = (undefined4 *)0xac9abe;
              FUN_00ac7c20();
              bVar6 = true;
            }
            else {
              puStack_4ec = (undefined4 *)0xac9acf;
              FUN_00ac7c20();
              bVar6 = false;
            }
            puStack_4ec = (undefined4 *)0xac9ade;
            FUN_00ac7c20();
            ppuStack_4e8 = &PTR_FUN_0194b55c;
            if (!bVar6) {
              ppuStack_4e8 = (undefined **)0x0;
            }
            puStack_4ec = (undefined4 *)0xac9af8;
            FUN_00ac7c20();
            puStack_4ec = (undefined4 *)0xac9b03;
            FUN_00ac7c20();
            iStack_8 = (uint)iStack_8._1_3_ << 8;
            puStack_4ec = (undefined4 *)0xac9b12;
            FUN_00ac7c20();
          }
          puStack_4ec = (undefined4 *)0xac9bdd;
          FUN_0090ca30();
          piStack_4c8 = (int *)0x0;
          pTStack_4cc = (TypeDescriptor *)0x0;
          ppuStack_4e8 = (undefined **)0x0;
          uStack_4d4 = 0;
          pTStack_4d0 = (TypeDescriptor *)0xf;
          puStack_4ec = (undefined4 *)&DAT_018bc9b8;
          uStack_4e4 = 0;
          puStack_4f0 = (undefined4 *)0xac9c06;
          FUN_005542c0();
          iStack_8._0_1_ = 0x1d;
          uStack_20 = (double)CONCAT44(&puStack_4fc,(undefined4)uStack_20);
          puStack_500 = (undefined4 *)&DAT_00000007;
          puStack_4ec = (undefined4 *)0x0;
          ppuStack_4e8 = (undefined **)0xf;
          pcStack_504 = "Pending";
          puStack_4fc = (undefined4 *)((uint)puStack_4fc & 0xffffff00);
          ppuStack_508 = (undefined4 **)0xac9c2f;
          FUN_005542c0();
          puStack_24 = (undefined *)&pcStack_504;
          ppuStack_508 = (undefined4 **)param_3;
          puStack_50c = (undefined8 *)0xac9c3f;
          FUN_00557fc0();
          iStack_8._0_1_ = 0x1f;
        }
        else {
          piStack_4c8 = (int *)0x1;
          puStack_560 = puStack_18 + 0x18;
          puStack_4ec = (undefined4 *)0x0;
          uStack_20 = (double)CONCAT44(appuStack_55c,(undefined4)uStack_20);
          pcStack_564 = (code *)0xac9c6b;
          FUN_0054f510();
          puStack_24 = (undefined *)&pcStack_564;
          puStack_568 = puVar11 + 8;
          uStack_56c = 0xac9c7c;
          FUN_00557fc0();
          iStack_8._0_1_ = 0x21;
          uStack_584 = 0xac9c91;
          ppuStack_580 = (undefined **)(iVar9 + 0xc);
          FUN_0054ef60();
          ppuStack_580 = (undefined **)piStack_14;
          iStack_8._0_1_ = 0;
          uStack_584 = 0;
          pcStack_588 = FUN_00ad9610;
          uStack_590 = 0xac9ca5;
          puStack_58c = (undefined *)&uStack_53c;
          FUN_00ac24b0();
          uStack_540 = 0xac9cb0;
          FUN_00ac02c0();
          puStack_4ec = (undefined4 *)0xac9cb8;
          FUN_0090ca30();
          piStack_4c8 = (int *)0x0;
          pTStack_4cc = (TypeDescriptor *)0x0;
          puStack_4ec = (undefined4 *)0xac9cca;
          ppuStack_4e8 = (undefined **)(iVar9 + 0xc);
          FUN_0054ef60();
          iStack_8._0_1_ = 0x22;
          puStack_500 = (undefined4 *)&DAT_00000007;
          puStack_4ec = (undefined4 *)0x0;
          ppuStack_4e8 = (undefined **)0xf;
          pcStack_504 = "Failure";
          puStack_4fc = (undefined4 *)((uint)puStack_4fc & 0xffffff00);
          ppuStack_508 = (undefined4 **)0xac9cf3;
          FUN_005542c0();
          ppuStack_508 = (undefined4 **)(puStack_18 + 0xc);
          uStack_20 = (double)CONCAT44(&pcStack_504,(undefined4)uStack_20);
          puStack_50c = (undefined8 *)0xac9d07;
          FUN_00557fc0();
          iStack_8._0_1_ = 0x24;
        }
      }
      else {
        piStack_4c8 = (int *)0x1;
        piStack_14 = (int *)&ppuStack_4e8;
        puStack_50c = (undefined8 *)(param_1 + 0x18);
        uStack_510 = 0xac9620;
        FUN_0054f510();
        puStack_28 = &uStack_528;
        iStack_8._0_1_ = 1;
        puStack_52c = param_1 + 0x10;
        uStack_530 = 0xac9635;
        FUN_0054f510();
        puStack_18 = &uStack_530;
        if (param_1[0xf] != 0) {
          LOCK();
          piVar10 = (int *)(param_1[0xf] + 4);
          *piVar10 = *piVar10 + 1;
          UNLOCK();
        }
        uStack_530 = param_1[0xe];
        puStack_52c = (undefined4 *)param_1[0xf];
        puStack_3c = (undefined *)&uStack_538;
        if (param_1[0xd] != 0) {
          LOCK();
          piVar10 = (int *)(param_1[0xd] + 4);
          *piVar10 = *piVar10 + 1;
          UNLOCK();
        }
        uStack_538 = param_1[0xc];
        uStack_534 = param_1[0xd];
        puStack_34 = (undefined *)&uStack_540;
        if (param_1[9] != 0) {
          LOCK();
          piVar10 = (int *)(param_1[9] + 4);
          *piVar10 = *piVar10 + 1;
          UNLOCK();
        }
        uStack_540 = param_1[8];
        uStack_53c = param_1[9];
        iStack_8._0_1_ = 5;
        appuStack_55c[0] = param_2;
        puStack_560 = (undefined4 *)0xac96c7;
        FUN_0054ef60();
        puStack_560 = (undefined4 *)0x0;
        puStack_568 = &uStack_4b4;
        iStack_8._0_1_ = 0;
        pcStack_564 = FUN_00ad9b40;
        uStack_56c = 0xac96df;
        appuStack_55c[0] = ppuVar15;
        FUN_00ac29c0();
        uStack_42c = uStack_4b4;
        uStack_428 = uStack_4b0;
        puStack_4ec = (undefined4 *)auStack_4ac;
        iStack_8._0_1_ = 6;
        puStack_4f0 = (undefined4 *)0xac9713;
        FUN_00ac6f20();
        ppuVar15 = (undefined **)piStack_14;
        uStack_3a4 = uStack_42c;
        uStack_3a0 = uStack_428;
        puStack_4ec = (undefined4 *)auStack_424;
        iStack_8._0_1_ = 7;
        *piStack_14 = 0;
        puStack_4f0 = (undefined4 *)0xac974a;
        FUN_00ac6f20();
        uStack_31c = uStack_3a4;
        uStack_318 = uStack_3a0;
        puStack_4ec = (undefined4 *)auStack_39c;
        iStack_8._0_1_ = 8;
        puStack_4f0 = (undefined4 *)0xac9778;
        FUN_00ac6f20();
        uStack_1d4 = uStack_31c;
        uStack_1d0 = uStack_318;
        puStack_4ec = (undefined4 *)auStack_314;
        iStack_8._0_1_ = 9;
        puStack_4f0 = (undefined4 *)0xac97a6;
        FUN_00ac6f20();
        puStack_4ec = &uStack_1d4;
        iStack_8._0_1_ = 10;
        puStack_4f0 = (undefined4 *)0xac97b6;
        cVar7 = FUN_00585a40();
        if (cVar7 == '\0') {
          uStack_294 = uStack_1d4;
          uStack_290 = uStack_1d0;
          puStack_4ec = (undefined4 *)auStack_1cc;
          puStack_4f0 = (undefined4 *)0xac97eb;
          FUN_00ac6f20();
          puStack_4ec = (undefined4 *)0x80;
          iStack_8._0_1_ = 0xb;
          puStack_4f0 = (undefined4 *)0xac97f9;
          puVar11 = (undefined4 *)FUN_01674e20();
          iStack_8._0_1_ = 0xc;
          if (puVar11 == (undefined4 *)0x0) {
            puVar11 = (undefined4 *)0x0;
          }
          else {
            puStack_4ec = (undefined4 *)auStack_28c;
            *puVar11 = uStack_294;
            puVar11[1] = uStack_290;
            puStack_4f0 = (undefined4 *)0xac9829;
            FUN_00ac6f20();
          }
          piStack_14[2] = (int)puVar11;
          puStack_4ec = (undefined4 *)0xac983e;
          FUN_00ac87e0();
          puStack_4ec = (undefined4 *)0xac9849;
          FUN_00ac87e0();
          bVar6 = true;
          ppuVar15 = (undefined **)piStack_14;
        }
        else {
          puStack_4ec = (undefined4 *)0xac985d;
          FUN_00ac87e0();
          bVar6 = false;
        }
        puStack_4ec = (undefined4 *)0xac986c;
        FUN_00ac87e0();
        ppuVar12 = &PTR_FUN_0194b54c;
        if (!bVar6) {
          ppuVar12 = (undefined **)0x0;
        }
        *ppuVar15 = (undefined *)ppuVar12;
        puStack_4ec = (undefined4 *)0xac9886;
        FUN_00ac87e0();
        puStack_4ec = (undefined4 *)0xac9891;
        FUN_00ac87e0();
        iStack_8._0_1_ = 0;
        puStack_4ec = (undefined4 *)0xac98a0;
        FUN_00ac87e0();
        puStack_4ec = (undefined4 *)0xac98a8;
        FUN_0090ca30();
        piStack_4c8 = (int *)0x0;
        pTStack_4cc = (TypeDescriptor *)0x0;
        ppuStack_4e8 = param_2;
        puStack_4ec = (undefined4 *)0xac98bc;
        FUN_0054ef60();
        iStack_8._0_1_ = 0xd;
        puStack_500 = (undefined4 *)0x5;
        puStack_4ec = (undefined4 *)0x0;
        ppuStack_4e8 = (undefined **)0xf;
        pcStack_504 = "Ready";
        puStack_4fc = (undefined4 *)((uint)puStack_4fc & 0xffffff00);
        ppuStack_508 = (undefined4 **)0xac98e5;
        FUN_005542c0();
        puStack_38 = (undefined *)&pcStack_504;
        if (param_1[0xd] != 0) {
          LOCK();
          piVar10 = (int *)(param_1[0xd] + 4);
          *piVar10 = *piVar10 + 1;
          UNLOCK();
        }
        pcStack_504 = (char *)param_1[0xc];
        puStack_500 = (undefined4 *)param_1[0xd];
        iStack_8._0_1_ = 0xf;
      }
      pcStack_520 = (code *)0x13;
      puStack_50c = (undefined8 *)0x0;
      ppuStack_508 = (undefined4 **)&DAT_0000000f;
      pcStack_524 = "GameJoinApiResponse";
      uStack_51c = uStack_51c & 0xffffff00;
      uStack_528 = 0xac9f90;
      FUN_005542c0();
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      pcStack_520 = (code *)0xac9f99;
      uVar8 = FUN_00ad71f0();
    }
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    puVar2 = (uint *)(piStack_2c + 1);
    uVar3 = *puVar2;
    uVar8 = *puVar2;
    *puVar2 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      piStack_4c8 = (int *)0xac9fb5;
      uVar8 = (**(code **)*piStack_2c)();
      LOCK();
      piVar10 = piStack_2c + 2;
      iVar9 = *piVar10;
      *piVar10 = *piVar10 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        piStack_4c8 = (int *)0xac9fc4;
        uVar8 = (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 22269 ; VA 0x00ac9fe0 ; FUN_00ac9fe0 */

void __thiscall FUN_00ac9fe0(undefined4 *param_1,undefined4 param_2,uint param_3)

{
  code *pcVar1;
  undefined uVar2;
  uint *puVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 *in_stack_00000034;
  ulonglong in_stack_00000038;
  uint in_stack_00000040;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined8 in_stack_00000058;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  ulonglong uStack_48;
  uint auStack_40 [2];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e89e8;
  pvStack_10 = ExceptionList;
  param_2 = auStack_40;
  pcVar1 = (code *)*param_1;
  uStack_8 = 2;
  auStack_40[0] = 0;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_40;
  if (in_stack_00000040 != 0) {
    auStack_40[0] = in_stack_00000040;
    if ((in_stack_00000040 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = &stack0x00000048;
      uStack_50 = 0xaca050;
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000040 & 0xfffffffe))();
      puVar3 = param_2;
    }
    else {
      uStack_38 = in_stack_00000048;
      uStack_34 = in_stack_0000004c;
      uStack_30 = in_stack_00000050;
      uStack_2c = in_stack_00000054;
      uStack_28 = in_stack_00000058;
      ExceptionList = &pvStack_10;
      puVar3 = auStack_40;
    }
  }
  param_2 = puVar3;
  uStack_8._0_1_ = 3;
  if (in_stack_00000020 != 0) {
    if ((in_stack_00000020 & 1) == 0) {
      (**(code **)(in_stack_00000020 & 0xfffffffe))(&stack0x00000028,&uStack_58,0);
    }
    else {
      uStack_58 = in_stack_00000028;
      uStack_54 = in_stack_0000002c;
      uStack_50 = in_stack_00000030;
      puStack_4c = in_stack_00000034;
      uStack_48 = in_stack_00000038;
    }
  }
  uStack_8._0_1_ = 4;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 2;
  (*pcVar1)();
  uStack_8._0_1_ = 1;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    uVar4 = param_3;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(param_3 - 4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_3 - uVar4) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (in_stack_00000020 != 0) {
    if (((in_stack_00000020 & 1) == 0) &&
       (*(code **)(in_stack_00000020 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000020 & 0xfffffffe))(&stack0x00000028,&stack0x00000028,2);
    }
    in_stack_00000020 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_00000040 != 0) && ((in_stack_00000040 & 1) == 0)) &&
     (*(code **)(in_stack_00000040 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000040 & 0xfffffffe))(&stack0x00000048,&stack0x00000048,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22270 ; VA 0x00aca170 ; FUN_00aca170 */

void __thiscall FUN_00aca170(undefined4 *param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  int *piVar4;
  uint *puVar5;
  uint uVar6;
  uint uVar7;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  uint in_stack_00000028;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined4 in_stack_0000003c;
  undefined8 in_stack_00000040;
  uint auStack_40 [2];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e8a28;
  pvStack_10 = ExceptionList;
  param_2 = auStack_40;
  pcVar2 = (code *)*param_1;
  uStack_8 = 2;
  auStack_40[0] = 0;
  ExceptionList = &pvStack_10;
  puVar5 = auStack_40;
  if (in_stack_00000028 != 0) {
    auStack_40[0] = in_stack_00000028;
    if ((in_stack_00000028 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000028 & 0xfffffffe))(&stack0x00000030);
      puVar5 = param_2;
    }
    else {
      uStack_38 = in_stack_00000030;
      uStack_34 = in_stack_00000034;
      uStack_30 = in_stack_00000038;
      uStack_2c = in_stack_0000003c;
      uStack_28 = in_stack_00000040;
      ExceptionList = &pvStack_10;
      puVar5 = auStack_40;
    }
  }
  param_2 = puVar5;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    in_stack_00000024[1] = in_stack_00000024[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 4;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 2;
  (*pcVar2)();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < in_stack_0000001c) {
    uVar7 = in_stack_0000001c + 1;
    uVar6 = param_3;
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(param_3 - 4);
      uVar7 = in_stack_0000001c + 0x24;
      if (0x1f < (param_3 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  piVar4 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar3 = in_stack_00000024[1] + -1;
    in_stack_00000024[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  uStack_8 = 5;
  if (((in_stack_00000028 != 0) && ((in_stack_00000028 & 1) == 0)) &&
     (*(code **)(in_stack_00000028 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000028 & 0xfffffffe))(&stack0x00000030,&stack0x00000030,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22271 ; VA 0x00aca2e0 ; FUN_00aca2e0 */

int __thiscall
FUN_00aca2e0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6,int param_7)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_0000002c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e8a58;
  pvStack_10 = ExceptionList;
  pcVar3 = (code *)*param_1;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_7);
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  iVar4 = (*pcVar3)(param_3,param_4,param_5,param_6);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (0xf < in_stack_0000002c) {
    uVar5 = in_stack_0000002c + 1;
    iVar4 = param_7;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_7 + -4);
      uVar5 = in_stack_0000002c + 0x24;
      if (0x1f < (param_7 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 22272 ; VA 0x00aca410 ; FUN_00aca410 */

int __thiscall
FUN_00aca410(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6,undefined4 param_7,int *param_8,int param_9)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_00000034;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e8a90;
  pvStack_10 = ExceptionList;
  pcVar3 = (code *)*param_1;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_9);
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  iVar4 = (*pcVar3)(param_3,param_4,param_5,param_6,param_7,param_8);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar1 = param_8 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_8 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000034) {
    uVar5 = in_stack_00000034 + 1;
    iVar4 = param_9;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_9 + -4);
      uVar5 = in_stack_00000034 + 0x24;
      if (0x1f < (param_9 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 22273 ; VA 0x00aca580 ; FUN_00aca580 */

void __thiscall FUN_00aca580(undefined4 *param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  int *piVar4;
  uint *puVar5;
  uint uVar6;
  uint uVar7;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  undefined4 in_stack_00000028;
  int *in_stack_0000002c;
  undefined4 in_stack_00000030;
  int *in_stack_00000034;
  uint in_stack_00000038;
  undefined4 in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined8 in_stack_00000050;
  uint in_stack_00000058;
  undefined4 in_stack_00000060;
  undefined4 in_stack_00000064;
  undefined4 in_stack_00000068;
  undefined4 in_stack_0000006c;
  undefined8 in_stack_00000070;
  uint auStack_4c [2];
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined8 uStack_34;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e8af8;
  pvStack_10 = ExceptionList;
  param_2 = auStack_4c;
  pcVar2 = (code *)*param_1;
  uStack_8 = 5;
  auStack_4c[0] = 0;
  ExceptionList = &pvStack_10;
  puVar5 = auStack_4c;
  if (in_stack_00000058 != 0) {
    auStack_4c[0] = in_stack_00000058;
    if ((in_stack_00000058 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000058 & 0xfffffffe))();
      puVar5 = param_2;
    }
    else {
      uStack_44 = in_stack_00000060;
      uStack_40 = in_stack_00000064;
      uStack_3c = in_stack_00000068;
      uStack_38 = in_stack_0000006c;
      uStack_34 = in_stack_00000070;
      ExceptionList = &pvStack_10;
      puVar5 = auStack_4c;
    }
  }
  param_2 = puVar5;
  uStack_8._0_1_ = 6;
  if ((in_stack_00000038 != 0) && ((in_stack_00000038 & 1) == 0)) {
    (**(code **)(in_stack_00000038 & 0xfffffffe))();
  }
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    in_stack_00000034[1] = in_stack_00000034[1] + 1;
    UNLOCK();
  }
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    in_stack_0000002c[1] = in_stack_0000002c[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    in_stack_00000024[1] = in_stack_00000024[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 10;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 5;
  (*pcVar2)();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (0xf < in_stack_0000001c) {
    uVar7 = in_stack_0000001c + 1;
    uVar6 = param_3;
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(param_3 - 4);
      uVar7 = in_stack_0000001c + 0x24;
      if (0x1f < (param_3 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  piVar4 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar3 = in_stack_00000024[1] + -1;
    in_stack_00000024[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = in_stack_0000002c;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    iVar3 = in_stack_0000002c[1] + -1;
    in_stack_0000002c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*in_stack_0000002c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = in_stack_00000034;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    iVar3 = in_stack_00000034[1] + -1;
    in_stack_00000034[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*in_stack_00000034)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  if (in_stack_00000038 != 0) {
    if (((in_stack_00000038 & 1) == 0) &&
       (*(code **)(in_stack_00000038 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000038 & 0xfffffffe))(&stack0x00000040,&stack0x00000040,2);
    }
    in_stack_00000038 = 0;
  }
  uStack_8 = 0xc;
  if (((in_stack_00000058 != 0) && ((in_stack_00000058 & 1) == 0)) &&
     (*(code **)(in_stack_00000058 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000058 & 0xfffffffe))(&stack0x00000060,&stack0x00000060,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22274 ; VA 0x00aca810 ; FUN_00aca810 */

void __thiscall FUN_00aca810(undefined4 *param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  int *piVar4;
  uint *puVar5;
  uint uVar6;
  uint uVar7;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  undefined4 in_stack_00000028;
  int *in_stack_0000002c;
  undefined4 in_stack_00000030;
  int *in_stack_00000034;
  undefined4 in_stack_00000038;
  int *in_stack_0000003c;
  uint in_stack_00000040;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined8 in_stack_00000058;
  uint in_stack_00000060;
  undefined4 in_stack_00000068;
  undefined4 in_stack_0000006c;
  undefined4 in_stack_00000070;
  undefined4 in_stack_00000074;
  undefined8 in_stack_00000078;
  uint auStack_50 [2];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e8b78;
  pvStack_10 = ExceptionList;
  param_2 = auStack_50;
  pcVar2 = (code *)*param_1;
  uStack_8 = 6;
  auStack_50[0] = 0;
  ExceptionList = &pvStack_10;
  puVar5 = auStack_50;
  if (in_stack_00000060 != 0) {
    auStack_50[0] = in_stack_00000060;
    if ((in_stack_00000060 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000060 & 0xfffffffe))();
      puVar5 = param_2;
    }
    else {
      uStack_48 = in_stack_00000068;
      uStack_44 = in_stack_0000006c;
      uStack_40 = in_stack_00000070;
      uStack_3c = in_stack_00000074;
      uStack_38 = in_stack_00000078;
      ExceptionList = &pvStack_10;
      puVar5 = auStack_50;
    }
  }
  param_2 = puVar5;
  uStack_8._0_1_ = 7;
  if ((in_stack_00000040 != 0) && ((in_stack_00000040 & 1) == 0)) {
    (**(code **)(in_stack_00000040 & 0xfffffffe))();
  }
  if (in_stack_0000003c != (int *)0x0) {
    LOCK();
    in_stack_0000003c[1] = in_stack_0000003c[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    in_stack_00000034[1] = in_stack_00000034[1] + 1;
    UNLOCK();
  }
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    in_stack_0000002c[1] = in_stack_0000002c[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    in_stack_00000024[1] = in_stack_00000024[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 0xc;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 6;
  (*pcVar2)();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (0xf < in_stack_0000001c) {
    uVar7 = in_stack_0000001c + 1;
    uVar6 = param_3;
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(param_3 - 4);
      uVar7 = in_stack_0000001c + 0x24;
      if (0x1f < (param_3 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  piVar4 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar3 = in_stack_00000024[1] + -1;
    in_stack_00000024[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = in_stack_0000002c;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    iVar3 = in_stack_0000002c[1] + -1;
    in_stack_0000002c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*in_stack_0000002c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = in_stack_00000034;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    iVar3 = in_stack_00000034[1] + -1;
    in_stack_00000034[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*in_stack_00000034)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = in_stack_0000003c;
  if (in_stack_0000003c != (int *)0x0) {
    LOCK();
    iVar3 = in_stack_0000003c[1] + -1;
    in_stack_0000003c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*in_stack_0000003c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  if (in_stack_00000040 != 0) {
    if (((in_stack_00000040 & 1) == 0) &&
       (*(code **)(in_stack_00000040 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000040 & 0xfffffffe))(&stack0x00000048,&stack0x00000048,2);
    }
    in_stack_00000040 = 0;
  }
  uStack_8 = 0xe;
  if (((in_stack_00000060 != 0) && ((in_stack_00000060 & 1) == 0)) &&
     (*(code **)(in_stack_00000060 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000060 & 0xfffffffe))(&stack0x00000068,&stack0x00000068,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22275 ; VA 0x00acaaf0 ; FUN_00acaaf0 */

/* WARNING: Removing unreachable block (ram,0x00acab42) */
/* WARNING: Removing unreachable block (ram,0x00acab52) */
/* WARNING: Removing unreachable block (ram,0x00acab58) */

void * __thiscall
FUN_00acaaf0(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e8bb0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 4;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 22276 ; VA 0x00acabf7 ; Catch@00acabf7 */

undefined * Catch_00acabf7(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00acac08;
}



/* FUNCTION 22277 ; VA 0x00acac20 ; FUN_00acac20 */

/* WARNING: Removing unreachable block (ram,0x00acacce) */
/* WARNING: Removing unreachable block (ram,0x00acacde) */
/* WARNING: Removing unreachable block (ram,0x00acace4) */

void __thiscall
FUN_00acac20(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e8be0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (*param_1 == 0) {
    ExceptionList = &pvStack_10;
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar2 = param_3[1] + -1;
      ExceptionList = &pvStack_10;
      param_3[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_3)();
        LOCK();
        piVar1 = param_3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_3 + 4))();
        }
      }
    }
    uStack_8 = 2;
  }
  else {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 5;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_01675290(uVar3);
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar2 = param_3[1] + -1;
      param_3[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_3)();
        LOCK();
        piVar1 = param_3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_3 + 4))();
        }
      }
    }
    uStack_8 = 8;
  }
  if (param_5 != 0) {
    (**(code **)(param_5 + 8))(&stack0x00000014);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22278 ; VA 0x00acad5c ; Catch@00acad5c */

undefined * Catch_00acad5c(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00acad6d;
}



/* FUNCTION 22279 ; VA 0x00acad80 ; FUN_00acad80 */

/* WARNING: Removing unreachable block (ram,0x00acae41) */
/* WARNING: Removing unreachable block (ram,0x00acae51) */
/* WARNING: Removing unreachable block (ram,0x00acae57) */

void * __thiscall
FUN_00acad80(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int param_5)

{
  int *piVar1;
  void *pvVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_00000024;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e8c10;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 4;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    FUN_01675290(uVar3);
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar4 = param_3[1] + -1;
      param_3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*param_3)();
        LOCK();
        piVar1 = param_3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*param_3 + 4))();
        }
      }
    }
    pvVar2 = (void *)FUN_005507b0();
    ExceptionList = pvStack_10;
    return pvVar2;
  }
  pvVar2 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar4 = *piVar1;
    pvVar2 = (void *)*piVar1;
    ExceptionList = &pvStack_10;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      pvVar2 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        pvVar2 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000024) {
    uVar5 = in_stack_00000024 + 1;
    iVar4 = param_5;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_5 + -4);
      uVar5 = in_stack_00000024 + 0x24;
      if (0x1f < (param_5 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    pvVar2 = (void *)FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return pvVar2;
}



/* FUNCTION 22280 ; VA 0x00acaedb ; Catch@00acaedb */

undefined * Catch_00acaedb(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00acaeec;
}



/* FUNCTION 22281 ; VA 0x00acaf10 ; FUN_00acaf10 */

undefined4 __thiscall FUN_00acaf10(undefined4 param_1,byte param_2)

{
  FUN_00ac7f20();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 22282 ; VA 0x00acaf40 ; FUN_00acaf40 */

undefined4 __thiscall FUN_00acaf40(undefined4 param_1,byte param_2)

{
  FUN_00ac8030();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 22283 ; VA 0x00acaf70 ; FUN_00acaf70 */

undefined4 __thiscall FUN_00acaf70(undefined4 param_1,byte param_2)

{
  FUN_00ac8130();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 22284 ; VA 0x00acafa0 ; FUN_00acafa0 */

undefined4 __thiscall FUN_00acafa0(undefined4 param_1,byte param_2)

{
  FUN_00ac8230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 22285 ; VA 0x00acafd0 ; FUN_00acafd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00acafd0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::TeleportService::TeleportResult>::vftable;
  _DAT_01eeb8e0 = _DAT_01eeb8e0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 22286 ; VA 0x00acb000 ; FUN_00acb000 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00acb000(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::TeleportService_TeleportMethod>::vftable;
  _DAT_01eeb8d8 = _DAT_01eeb8d8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 22287 ; VA 0x00acb030 ; FUN_00acb030 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00acb030(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::TeleportService_TeleportState>::vftable;
  _DAT_01eeb8c8 = _DAT_01eeb8c8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 22288 ; VA 0x00acb060 ; FUN_00acb060 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00acb060(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::TeleportService_TeleportType>::vftable;
  _DAT_01eeb8d0 = _DAT_01eeb8d0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 22289 ; VA 0x00acb090 ; FUN_00acb090 */

undefined4 __thiscall FUN_00acb090(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 22290 ; VA 0x00acb0b0 ; FUN_00acb0b0 */

undefined4 __thiscall FUN_00acb0b0(undefined4 param_1,byte param_2)

{
  FUN_00ac8b20();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10c);
  }
  return param_1;
}



/* FUNCTION 22291 ; VA 0x00acb0e0 ; FUN_00acb0e0 */

void FUN_00acb0e0(undefined4 *param_1)

{
  FUN_0086f2f0(3,"GetArrivingTeleportGui should not be used on the server");
  *param_1 = 0;
  param_1[1] = 0;
  return;
}



/* FUNCTION 22292 ; VA 0x00acb110 ; FUN_00acb110 */

void FUN_00acb110(uint param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  char *pcVar4;
  uint in_stack_0000002c;
  undefined auStack_8e4 [28];
  undefined4 uStack_8c8;
  undefined auStack_8c4 [8];
  undefined4 uStack_8bc;
  undefined *puStack_8b8;
  code *pcStack_8b4;
  undefined4 uStack_8b0;
  int iStack_8ac;
  undefined4 *puStack_8a8;
  undefined4 uStack_898;
  int iStack_894;
  undefined4 uStack_888;
  undefined auStack_884 [12];
  undefined4 uStack_878;
  undefined4 uStack_874;
  undefined4 uStack_860;
  char *pcStack_85c;
  undefined4 uStack_858;
  char *pcStack_854;
  char *pcStack_850;
  int iStack_84c;
  uint uStack_848;
  undefined4 uStack_844;
  undefined4 uStack_840;
  char *pcStack_83c;
  char *pcStack_838;
  int iStack_834;
  char acStack_828 [2048];
  undefined *puStack_28;
  int iStack_20;
  undefined4 uStack_1c;
  undefined *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e9098;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  pcStack_838 = (char *)0xacb142;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_008b9b00();
  if (cVar2 == '\0') {
    iStack_84c = 0x50;
    pcStack_838 = (char *)0x0;
    iStack_834 = 0xf;
    pcStack_850 = "TeleportService::GetPlayerPlaceInstanceAsync can only be called from the server."
    ;
    uStack_848 = uStack_848 & 0xffffff00;
    pcStack_854 = (char *)0xacb16a;
    FUN_005542c0();
    iStack_84c = 0xacb172;
    FUN_005e65e0();
  }
  else {
    pcStack_838 = (char *)0xacb17d;
    iStack_20 = FUN_0064e700();
    if (iStack_20 != 0) {
      iStack_834 = 0x800;
      pcStack_83c = acStack_828;
      pcStack_838 = (char *)0x0;
      uStack_840 = 0xacb19e;
      FUN_0170d1f0();
      uStack_844 = 0xacb1a4;
      iVar3 = FUN_008f7870();
      uStack_844 = param_2;
      uStack_848 = param_1;
      piVar1 = *(int **)(iVar3 + 0x43c);
      iStack_84c = piVar1[1] - (int)piVar1;
      pcStack_850 = (char *)(*piVar1 - (int)piVar1);
      pcStack_85c = acStack_828;
      pcStack_854 = "universes/get-player-place-instance?currentPlaceId=%lld&userId=%lld";
      uStack_858 = 0x800;
      uStack_860 = 0xacb1d1;
      FUN_0058ccc0();
      pcVar4 = acStack_828;
      do {
        cVar2 = *pcVar4;
        pcVar4 = pcVar4 + 1;
      } while (cVar2 != '\0');
      iStack_834 = (int)pcVar4 - (int)(acStack_828 + 1);
      pcStack_838 = acStack_828;
      pcStack_83c = (char *)0xacb1f9;
      FUN_005542c0();
      puStack_28 = (undefined *)&pcStack_850;
      param_2 = CONCAT31(param_2._1_3_,DAT_01eeb670);
      uStack_1c = CONCAT31(uStack_1c._1_3_,DAT_01eeb670);
      puStack_8a8 = &stack0x0000002c;
      pcStack_854 = (char *)0x0;
      iStack_8ac = 0xacb221;
      FUN_0054f510();
      puStack_8a8 = (undefined4 *)param_2;
      iStack_8ac = iStack_14;
      uStack_8b0 = 0;
      pcStack_8b4 = FUN_00acb3c0;
      uStack_8bc = 0xacb235;
      puStack_8b8 = auStack_884;
      FUN_00ac1f70();
      uStack_888 = 0xacb23f;
      FUN_00ac0040();
      uStack_8._0_1_ = 2;
      uStack_874 = 0;
      puStack_18 = auStack_8e4;
      FUN_0054f510(&stack0x0000002c);
      uStack_8._0_1_ = 3;
      FUN_0054f510(&param_3);
      uStack_8._0_1_ = 2;
      FUN_00ac2190(auStack_8c4,FUN_00acb500,0,iStack_14,uStack_1c);
      uStack_8c8 = 0xacb296;
      FUN_00ac0100();
      uStack_874 = 0xc;
      uStack_878 = 1;
      uStack_8._0_1_ = 4;
      iStack_894 = iStack_14 + 0x5c;
      uStack_898 = 0xacb2af;
      FUN_0054ef60();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      iStack_894 = 0xacb2bb;
      FUN_00bcb3b0();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      pcStack_83c = &stack0x00000014;
      iStack_834 = 2;
      uStack_840 = 0xacb2dc;
      pcStack_838 = pcStack_83c;
      (**(code **)(param_3 & 0xfffffffe))();
    }
    param_3 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    pcStack_83c = &stack0x00000034;
    iStack_834 = 2;
    uStack_840 = 0xacb30a;
    pcStack_838 = pcStack_83c;
    (**(code **)(in_stack_0000002c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22293 ; VA 0x00acb320 ; FUN_00acb320 */

undefined * FUN_00acb320(void)

{
  return &DAT_01d66610;
}



/* FUNCTION 22294 ; VA 0x00acb330 ; FUN_00acb330 */

undefined4 * FUN_00acb330(undefined4 *param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0086f2f0(3,"GetTeleportSetting should not be used on the server");
  uVar1 = FUN_00888530();
  *param_1 = uVar1;
  param_1[1] = 0;
  if (0xf < in_stack_0000001c) {
    uVar3 = in_stack_0000001c + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22295 ; VA 0x00acb3c0 ; FUN_00acb3c0 */

void FUN_00acb3c0(uint param_1)

{
  uint uVar1;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined8 in_stack_00000034;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined8 uStack_a4;
  undefined4 uStack_88;
  undefined auStack_84 [56];
  undefined4 uStack_4c;
  undefined4 uStack_34;
  undefined4 *puStack_30;
  undefined4 *puStack_2c;
  undefined *puStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017e90c8;
  pvStack_10 = ExceptionList;
  iStack_8 = 1;
  puStack_2c = (undefined4 *)0xacb3ea;
  ExceptionList = &pvStack_10;
  FUN_008f7870();
  puStack_28 = (undefined *)0x1;
  uStack_4c = 0;
  uStack_a4 = CONCAT44(&param_1,0xacb40f);
  FUN_0054ef60();
  iStack_8._0_1_ = 2;
  if (in_stack_0000001c != 0) {
    if ((in_stack_0000001c & 1) == 0) {
      (**(code **)(in_stack_0000001c & 0xfffffffe))(&stack0x00000024,&uStack_b4,0);
    }
    else {
      uStack_b4 = in_stack_00000024;
      uStack_b0 = in_stack_00000028;
      uStack_ac = in_stack_0000002c;
      uStack_a8 = in_stack_00000030;
      uStack_a4 = in_stack_00000034;
    }
  }
  iStack_8._0_1_ = 1;
  FUN_009645a0(auStack_84);
  uStack_88 = 0xacb46d;
  FUN_0095fcd0();
  uStack_4c = 0xacb474;
  FUN_0090ca30();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < in_stack_00000018) {
    puStack_28 = (undefined *)(in_stack_00000018 + 1);
    uVar1 = param_1;
    if (0xfff < puStack_28) {
      uVar1 = *(uint *)(param_1 - 4);
      puStack_28 = (undefined *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_1 - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_28 = &UNK_00acb4f8;
        FUN_017167a3();
      }
    }
    puStack_30 = (undefined4 *)0xacb4a5;
    puStack_2c = (undefined4 *)uVar1;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = param_1 & 0xffffff00;
  iStack_8 = 3;
  if (((in_stack_0000001c != 0) && ((in_stack_0000001c & 1) == 0)) &&
     (*(code **)(in_stack_0000001c & 0xfffffffe) != (code *)0x0)) {
    puStack_30 = &stack0x00000024;
    puStack_28 = (undefined *)0x2;
    uStack_34 = 0xacb4de;
    puStack_2c = puStack_30;
    (**(code **)(in_stack_0000001c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22296 ; VA 0x00acb500 ; FUN_00acb500 */

void FUN_00acb500(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  byte ***pppbVar3;
  undefined uVar4;
  int **ppiVar5;
  undefined *puVar6;
  undefined *puVar7;
  int iVar8;
  int iVar9;
  uint *puVar10;
  undefined4 uVar11;
  byte *****pppppbVar12;
  uint uVar13;
  undefined4 *puVar14;
  byte *pbVar15;
  bool bVar16;
  int in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined8 in_stack_00000034;
  uint in_stack_0000003c;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 *in_stack_00000050;
  undefined8 in_stack_00000054;
  uint auStack_1e8 [2];
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  undefined4 *puStack_1d4;
  undefined8 uStack_1d0;
  uint auStack_1c8 [2];
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined8 uStack_1b0;
  int *piStack_1a8;
  int *piStack_1a4;
  undefined auStack_1a0 [40];
  undefined4 uStack_178;
  undefined auStack_174 [16];
  undefined4 uStack_164;
  byte ***pppbStack_160;
  undefined4 *puStack_15c;
  byte ****ppppbStack_158;
  byte ****ppppbStack_154;
  undefined auStack_138 [160];
  undefined auStack_98 [24];
  uint auStack_80 [4];
  undefined4 uStack_70;
  uint uStack_6c;
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  undefined8 uStack_58;
  byte ****appppbStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  undefined8 uStack_38;
  int *piStack_30;
  int *piStack_2c;
  byte ***pppbStack_28;
  int *piStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  byte bStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e914a;
  pvStack_10 = ExceptionList;
  ppppbStack_154 = (byte ****)0xc;
  uStack_8 = 2;
  ppppbStack_158 = (byte ****)0xacb531;
  ExceptionList = &pvStack_10;
  iVar8 = FUN_01674e20();
  uStack_8._0_1_ = 3;
  puStack_20 = (undefined *)iVar8;
  if (iVar8 == 0) {
    ppppbStack_158 = (byte ****)0x0;
  }
  else {
    ppppbStack_154 = (byte ****)&bStack_11;
    ppppbStack_158 = (byte ****)0x4;
    puStack_15c = (undefined4 *)0xacb54e;
    FUN_00569550();
    ppppbStack_158 = (byte ****)iVar8;
  }
  ppppbStack_154 = (byte ****)in_stack_00000018;
  uStack_8._0_1_ = 2;
  piStack_30 = (int *)0x0;
  piStack_2c = (int *)0x0;
  puStack_15c = (undefined4 *)0xacb570;
  FUN_0055ba30();
  uStack_58 = 0xf00000000;
  uStack_68 = uStack_68 & 0xffffff00;
  ppppbStack_154 = (byte ****)0x0;
  ppppbStack_158 = (byte ****)&DAT_018bc9b8;
  uStack_8._0_1_ = 5;
  uStack_70 = 0;
  uStack_6c = 0xf;
  auStack_80[0] = auStack_80[0] & 0xffffff00;
  puStack_15c = (undefined4 *)0xacb5a7;
  FUN_005542c0();
  uStack_8._0_1_ = 6;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 6;
  if (in_stack_00000014 == 0) {
    puStack_18 = (undefined *)((uint)puStack_18 & 0xffffff00);
    uStack_8._0_1_ = uVar4;
  }
  else {
    ppppbStack_154 = (byte ****)0x1;
    ppppbStack_158 = (byte ****)0x3;
    puStack_15c = (undefined4 *)0xacb5c7;
    FUN_00565940();
    ppppbStack_154 = (byte ****)in_stack_00000014;
    ppppbStack_158 = (byte ****)&param_1;
    if (0xf < in_stack_00000018) {
      ppppbStack_158 = (byte ****)param_1;
    }
    puStack_15c = (undefined4 *)auStack_138;
    uStack_8._0_1_ = 7;
    pppbStack_160 = (byte ***)0xacb5e6;
    FUN_0055b3b0();
    pppbStack_160 = (byte ***)&pppbStack_28;
    uStack_164 = 0xacb5ef;
    FUN_00563d90();
    ppppbStack_154 = (byte ****)appppbStack_50;
    uStack_8._0_1_ = 8;
    ppppbStack_158 = (byte ****)0xacb605;
    puStack_15c = (undefined4 *)FUN_0058c4d0();
    ppppbStack_154 = (byte ****)0x0;
    ppppbStack_158 = &pppbStack_28;
    uStack_8._0_1_ = 9;
    pppbStack_160 = (byte ***)0xacb615;
    bStack_11 = FUN_0098f070();
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    if (0xf < uStack_3c) {
      ppppbStack_154 = (byte ****)(uStack_3c + 1);
      pppppbVar12 = (byte *****)appppbStack_50[0];
      if (0xfff < ppppbStack_154) {
        pppppbVar12 = (byte *****)appppbStack_50[0][-1];
        ppppbStack_154 = (byte ****)(uStack_3c + 0x24);
        if (0x1f < (uint)((int)appppbStack_50[0] + (-4 - (int)pppppbVar12))) {
                    /* WARNING: Subroutine does not return */
          ppppbStack_154 = (byte ****)0xacbaf2;
          FUN_017167a3();
        }
      }
      puStack_15c = (undefined4 *)0xacb650;
      ppppbStack_158 = (byte ****)pppppbVar12;
      FUN_01674ea0();
    }
    pppbVar3 = pppbStack_28;
    if (bStack_11 == 0) {
LAB_00acb7a8:
      puStack_18 = (undefined *)((uint)puStack_18 & 0xffffff00);
    }
    else {
      ppppbStack_154 = (byte ****)0x7;
      ppppbStack_158 = (byte ****)0x18becf0;
      uStack_40 = 0;
      uStack_3c = 0xf;
      appppbStack_50[0] = (byte ****)((uint)appppbStack_50[0] & 0xffffff00);
      puStack_15c = (undefined4 *)0xacb682;
      FUN_005542c0();
      pbVar15 = (byte *)((int)pppbVar3 + *(byte *)pppbVar3 + 1);
      ppppbStack_154 = (byte ****)appppbStack_50;
      ppppbStack_158 = (byte ****)0xacb695;
      puStack_15c = (undefined4 *)FUN_005702d0();
      ppppbStack_158 = (byte ****)appppbStack_50;
      ppppbStack_154 = (byte ****)(-(uint)(pbVar15 != (byte *)0x0) & (uint)(pbVar15 + 1));
      pppbStack_160 = (byte ***)&puStack_18;
      uStack_164 = 0xacb6af;
      FUN_00562fc0();
      ppppbStack_154 = (byte ****)0xacb6b7;
      FUN_005507b0();
      bStack_11 = puStack_18 != (undefined *)0x0;
      if (*(char *)(*(int *)(puStack_18 + 0x20) + 0x21) == '\0') {
        bStack_11 = 0;
      }
      else {
        ppppbStack_154 = (byte ****)0xacb6d1;
        uStack_38 = FUN_00563790();
      }
      ppppbStack_154 = (byte ****)0x6;
      ppppbStack_158 = (byte ****)0x18bf350;
      uStack_40 = 0;
      uStack_3c = 0xf;
      appppbStack_50[0] = (byte ****)((uint)appppbStack_50[0] & 0xffffff00);
      puStack_15c = (undefined4 *)0xacb701;
      FUN_005542c0();
      pbVar15 = (byte *)((int)pppbStack_28 + *(byte *)pppbStack_28 + 1);
      ppppbStack_154 = (byte ****)appppbStack_50;
      ppppbStack_158 = (byte ****)0xacb714;
      puStack_15c = (undefined4 *)FUN_005702d0();
      ppppbStack_158 = (byte ****)appppbStack_50;
      ppppbStack_154 = (byte ****)(-(uint)(pbVar15 != (byte *)0x0) & (uint)(pbVar15 + 1));
      pppbStack_160 = (byte ***)&puStack_18;
      uStack_164 = 0xacb72e;
      FUN_00562fc0();
      ppppbStack_154 = (byte ****)0xacb736;
      FUN_005507b0();
      iVar8 = *(int *)(puStack_18 + 0x20);
      bVar16 = puStack_18 != (undefined *)0x0;
      puStack_18 = (undefined *)0x0;
      if (bVar16) {
        puStack_18 = (undefined *)(uint)bStack_11;
      }
      ppppbStack_154 = (byte ****)0xacb751;
      iVar9 = FUN_0088cb40();
      if (iVar8 != iVar9) goto LAB_00acb7a8;
      ppppbStack_154 = (byte ****)auStack_98;
      ppppbStack_158 = (byte ****)0xacb763;
      puVar10 = (uint *)FUN_00563690();
      if (&uStack_68 != puVar10) {
        ppppbStack_154 = (byte ****)0xacb773;
        FUN_005507b0();
        uStack_68 = *puVar10;
        uStack_64 = puVar10[1];
        uStack_60 = puVar10[2];
        uStack_5c = puVar10[3];
        uStack_58 = *(undefined8 *)(puVar10 + 4);
        puVar10[4] = 0;
        puVar10[5] = 0xf;
        *(undefined *)puVar10 = 0;
      }
      ppppbStack_154 = (byte ****)0xacb7a0;
      FUN_005507b0();
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar8 = piStack_24[1] + -1;
      piStack_24[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        ppppbStack_154 = (byte ****)0xacb7c2;
        (**(code **)*piStack_24)();
        LOCK();
        iVar8 = piStack_24[2] + -1;
        piStack_24[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          ppppbStack_154 = (byte ****)0xacb7d2;
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    uStack_8._0_1_ = 6;
    ppppbStack_154 = (byte ****)0xacb7e1;
    FUN_005705c0();
    if ((char)puStack_18 != '\0') goto LAB_00acb7fc;
  }
  ppppbStack_154 = (byte ****)0x11;
  ppppbStack_158 = (byte ****)0x194a34c;
  puStack_15c = (undefined4 *)0xacb7fc;
  FUN_005542c0();
LAB_00acb7fc:
  ppppbStack_154 = (byte ****)puStack_1c;
  ppppbStack_158 = (byte ****)0xacb804;
  puStack_20 = (undefined *)FUN_008f7870();
  piVar2 = piStack_2c;
  if ((char)puStack_18 == '\0') {
    ppppbStack_154 = (byte ****)0x1;
    puStack_1c = auStack_174;
    uStack_178 = 0;
    puStack_20 = (undefined *)&uStack_1b0;
    piStack_24 = (int *)auStack_1c8;
    uStack_1d0 = CONCAT44(auStack_80,0xacb944);
    FUN_0054ef60();
    uStack_38._4_4_ = (int **)auStack_1e8;
    uStack_8._0_1_ = 0xb;
    auStack_1e8[0] = 0;
    puVar10 = auStack_1e8;
    if (in_stack_0000003c != 0) {
      auStack_1e8[0] = in_stack_0000003c;
      if ((in_stack_0000003c & 1) == 0) {
        (**(code **)(in_stack_0000003c & 0xfffffffe))(&stack0x00000044,&uStack_1e0,0);
        puVar10 = (uint *)uStack_38._4_4_;
      }
      else {
        uStack_1e0 = in_stack_00000044;
        uStack_1dc = in_stack_00000048;
        uStack_1d8 = in_stack_0000004c;
        puStack_1d4 = in_stack_00000050;
        uStack_1d0 = in_stack_00000054;
        puVar10 = auStack_1e8;
      }
    }
    uStack_38._4_4_ = (int **)puVar10;
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    FUN_009645a0(puStack_20);
    uStack_1b4 = 0xacb9a3;
    FUN_0095fcd0();
  }
  else {
    ppppbStack_158 = (byte ****)&uStack_68;
    ppppbStack_154 = (byte ****)&DAT_01d79c68;
    puStack_15c = (undefined4 *)0xacb827;
    bStack_11 = FUN_00558b30();
    piVar1 = piStack_30;
    ppppbStack_154 = (byte ****)&bStack_11;
    ppppbStack_158 = (byte ****)0xacb83b;
    FUN_005e52b0();
    iVar8 = *piVar1;
    ppppbStack_154 = (byte ****)0xacb842;
    uVar11 = FUN_0088cb40();
    *(undefined4 *)(iVar8 + 0xd0) = uVar11;
    ppppbStack_154 = (byte ****)auStack_80;
    ppppbStack_158 = (byte ****)0xacb857;
    FUN_005c17a0();
    piVar1 = piStack_30;
    ppppbStack_154 = (byte ****)&uStack_38;
    ppppbStack_158 = (byte ****)0xacb86b;
    FUN_00632bc0();
    iVar8 = *piVar1;
    ppppbStack_154 = (byte ****)0xacb872;
    uVar11 = FUN_0088cb40();
    *(undefined4 *)(iVar8 + 0x270) = uVar11;
    ppppbStack_154 = (byte ****)&uStack_68;
    ppppbStack_158 = (byte ****)0xacb887;
    FUN_005c17a0();
    ppppbStack_154 = (byte ****)0x1;
    puStack_18 = auStack_174;
    uStack_178 = 0;
    puStack_1c = auStack_1a0;
    uStack_38._4_4_ = &piStack_1a8;
    if (piVar2 != (int *)0x0) {
      LOCK();
      piVar2[1] = piVar2[1] + 1;
      UNLOCK();
    }
    piStack_1a8 = piStack_30;
    piStack_1a4 = piVar2;
    piStack_24 = (int *)auStack_1c8;
    uStack_8._0_1_ = 10;
    auStack_1c8[0] = 0;
    ppiVar5 = &piStack_1a8;
    puVar10 = auStack_1c8;
    puVar6 = auStack_1a0;
    puVar7 = auStack_174;
    if (in_stack_0000001c != 0) {
      auStack_1c8[0] = in_stack_0000001c;
      if ((in_stack_0000001c & 1) == 0) {
        uStack_1d0 = ZEXT48(&uStack_1c0);
        puStack_1d4 = &stack0x00000024;
        uStack_1d8 = 0xacb901;
        (**(code **)(in_stack_0000001c & 0xfffffffe))();
        ppiVar5 = uStack_38._4_4_;
        puVar10 = (uint *)piStack_24;
        puVar6 = puStack_1c;
        puVar7 = puStack_18;
      }
      else {
        uStack_1c0 = in_stack_00000024;
        uStack_1bc = in_stack_00000028;
        uStack_1b8 = in_stack_0000002c;
        uStack_1b4 = in_stack_00000030;
        uStack_1b0 = in_stack_00000034;
        ppiVar5 = &piStack_1a8;
        puVar10 = auStack_1c8;
        puVar6 = auStack_1a0;
        puVar7 = auStack_174;
      }
    }
    puStack_18 = puVar7;
    puStack_1c = puVar6;
    piStack_24 = (int *)puVar10;
    uStack_38._4_4_ = ppiVar5;
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    uStack_1d0 = CONCAT44(puStack_1c,0xacb910);
    FUN_00ac1d70();
    piStack_1a4 = (int *)0xacb91b;
    FUN_00abfda0();
  }
  uStack_178 = 0xacb9aa;
  FUN_0090ca30();
  uStack_8._0_1_ = 5;
  if (0xf < uStack_6c) {
    ppppbStack_154 = (byte ****)(uStack_6c + 1);
    uVar13 = auStack_80[0];
    if (0xfff < ppppbStack_154) {
      uVar13 = *(uint *)(auStack_80[0] - 4);
      ppppbStack_154 = (byte ****)(uStack_6c + 0x24);
      if (0x1f < (auStack_80[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
        ppppbStack_154 = (byte ****)0xacbaf7;
        FUN_017167a3();
      }
    }
    puStack_15c = (undefined4 *)0xacb9df;
    ppppbStack_158 = (byte ****)uVar13;
    FUN_01674ea0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (0xf < uStack_58._4_4_) {
    ppppbStack_154 = (byte ****)(uStack_58._4_4_ + 1);
    uVar13 = uStack_68;
    if (0xfff < ppppbStack_154) {
      uVar13 = *(uint *)(uStack_68 - 4);
      ppppbStack_154 = (byte ****)(uStack_58._4_4_ + 0x24);
      if (0x1f < (uStack_68 - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
        ppppbStack_154 = (byte ****)0xacbafc;
        FUN_017167a3();
      }
    }
    puStack_15c = (undefined4 *)0xacba17;
    ppppbStack_158 = (byte ****)uVar13;
    FUN_01674ea0();
  }
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar8 = piVar2[1] + -1;
    piVar2[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      ppppbStack_154 = (byte ****)0xacba30;
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar8 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        ppppbStack_154 = (byte ****)0xacba3f;
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    ppppbStack_154 = (byte ****)(in_stack_00000018 + 1);
    puVar14 = param_1;
    if (0xfff < ppppbStack_154) {
      puVar14 = (undefined4 *)param_1[-1];
      ppppbStack_154 = (byte ****)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_1 + (-4 - (int)puVar14))) {
                    /* WARNING: Subroutine does not return */
        ppppbStack_154 = (byte ****)&UNK_00acbb01;
        FUN_017167a3();
      }
    }
    puStack_15c = (undefined4 *)0xacba74;
    ppppbStack_158 = (byte ****)puVar14;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = (undefined4 *)((uint)param_1 & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  if (in_stack_0000001c != 0) {
    if (((in_stack_0000001c & 1) == 0) &&
       (*(code **)(in_stack_0000001c & 0xfffffffe) != (code *)0x0)) {
      puStack_15c = &stack0x00000024;
      ppppbStack_154 = (byte ****)0x2;
      pppbStack_160 = (byte ***)0xacbaaa;
      ppppbStack_158 = (byte ****)puStack_15c;
      (**(code **)(in_stack_0000001c & 0xfffffffe))();
    }
    in_stack_0000001c = 0;
  }
  uStack_8 = 0xd;
  if (((in_stack_0000003c != 0) && ((in_stack_0000003c & 1) == 0)) &&
     (*(code **)(in_stack_0000003c & 0xfffffffe) != (code *)0x0)) {
    puStack_15c = &stack0x00000044;
    ppppbStack_154 = (byte ****)0x2;
    pppbStack_160 = (byte ***)0xacbad8;
    ppppbStack_158 = (byte ****)puStack_15c;
    (**(code **)(in_stack_0000003c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22297 ; VA 0x00acbb10 ; FUN_00acbb10 */

int * FUN_00acbb10(int *param_1,int *param_2,undefined4 param_3,int *param_4,undefined4 *param_5)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  uint in_stack_00000028;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e9180;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("TeleportPrivateServerAccessGrantFailed",0x26);
  uStack_8._0_1_ = 3;
  FUN_008783f0(auStack_2c,1,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (0xf < uStack_18) {
    uVar6 = uStack_18 + 1;
    uVar7 = auStack_2c[0];
    if (0xfff < uVar6) {
      uVar7 = *(uint *)(auStack_2c[0] - 4);
      uVar6 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar6);
  }
  puVar3 = &param_5;
  if (0xf < in_stack_00000028) {
    puVar3 = param_5;
  }
  FUN_0086f2f0(3,"Teleport to ReservedServer failed : %s",puVar3);
  piVar8 = (int *)*param_1;
  if (piVar8 != (int *)param_1[1]) {
    do {
      iVar1 = *piVar8;
      if (iVar1 != 0) {
        iVar2 = *(int *)(iVar1 + 0xc);
        iVar4 = FUN_00913630();
        iVar5 = 0;
        if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
            (uint)*(ushort *)(iVar4 + 0x1da)) {
          iVar5 = iVar1;
        }
        if (iVar5 != 0) {
          if (param_4 != (int *)0x0) {
            LOCK();
            param_4[1] = param_4[1] + 1;
            UNLOCK();
          }
          FUN_0092faa0(3,param_3,param_4,0,0);
        }
      }
      piVar8 = piVar8 + 2;
    } while (piVar8 != (int *)param_1[1]);
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar8 = param_2 + 1;
    iVar1 = *piVar8;
    param_1 = (int *)*piVar8;
    *piVar8 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar8 = param_2 + 2;
      iVar1 = *piVar8;
      param_1 = (int *)*piVar8;
      *piVar8 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        param_1 = (int *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar8 = param_4 + 1;
    iVar1 = *piVar8;
    param_1 = (int *)*piVar8;
    *piVar8 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      param_1 = (int *)(**(code **)*param_4)();
      LOCK();
      piVar8 = param_4 + 2;
      iVar1 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        param_1 = (int *)(**(code **)(*param_4 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000028) {
    uVar7 = in_stack_00000028 + 1;
    puVar3 = param_5;
    if (0xfff < uVar7) {
      puVar3 = (undefined4 *)param_5[-1];
      uVar7 = in_stack_00000028 + 0x24;
      if (0x1f < (uint)((int)param_5 + (-4 - (int)puVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    param_1 = (int *)FUN_01674ea0(puVar3,uVar7);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22298 ; VA 0x00acbce0 ; FUN_00acbce0 */

int * __thiscall
FUN_00acbce0(undefined4 param_1,int *param_2,int *param_3,int *param_4,int *param_5,
            undefined4 param_6,int *param_7,int *param_8)

{
  int *piVar1;
  int **ppiVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined uVar7;
  int iVar8;
  undefined4 *puVar9;
  int *piVar10;
  undefined *puVar11;
  uint in_stack_00000030;
  int *piStack_80;
  int *piStack_7c;
  undefined4 uStack_78;
  int *piStack_74;
  undefined4 **ppuStack_70;
  int **ppiStack_6c;
  int *piStack_68;
  int **ppiStack_64;
  int *apiStack_54 [4];
  undefined4 uStack_44;
  uint uStack_40;
  undefined auStack_3c [4];
  int *piStack_38;
  undefined4 **ppuStack_34;
  int **ppiStack_30;
  int *piStack_2c;
  int *piStack_28;
  undefined *puStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e91f8;
  pvStack_10 = ExceptionList;
  ppiStack_64 = (int **)0x29;
  piStack_68 = (int *)0x194932c;
  uStack_8 = 3;
  uStack_44 = 0;
  uStack_40 = 0xf;
  apiStack_54[0] = (int *)((uint)apiStack_54[0] & 0xffffff00);
  ppiStack_6c = (int **)0xacbd2b;
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  FUN_005542c0();
  ppiStack_64 = (int **)0x0;
  ppiStack_6c = apiStack_54;
  uStack_8._0_1_ = 4;
  piStack_68 = (int *)0x1;
  ppuStack_70 = (undefined4 **)0xacbd3c;
  FUN_008783f0();
  uStack_8._0_1_ = 3;
  uVar7 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_40) {
    ppiStack_64 = (int **)(uStack_40 + 1);
    piVar10 = apiStack_54[0];
    if (0xfff < ppiStack_64) {
      piVar10 = (int *)apiStack_54[0][-1];
      ppiStack_64 = (int **)(uStack_40 + 0x24);
      if (0x1f < (uint)((int)apiStack_54[0] + (-4 - (int)piVar10))) {
                    /* WARNING: Subroutine does not return */
        ppiStack_64 = (int **)0xacc0c7;
        uStack_8._0_1_ = uVar7;
        FUN_017167a3();
      }
    }
    ppiStack_6c = (int **)0xacbd74;
    piStack_68 = piVar10;
    FUN_01674ea0();
  }
  ppiStack_64 = apiStack_54;
  piStack_68 = (int *)0xacbd80;
  piStack_68 = (int *)FUN_00ad55f0();
  ppuStack_70 = &ppuStack_34;
  uStack_8._0_1_ = 5;
  ppiStack_6c = (int **)0x2;
  piStack_74 = (int *)0xacbd90;
  FUN_00ad1a20();
  uStack_8._0_1_ = 7;
  uVar7 = (undefined)uStack_8;
  uStack_8._0_1_ = 7;
  if (0xf < uStack_40) {
    ppiStack_64 = (int **)(uStack_40 + 1);
    piVar10 = apiStack_54[0];
    if (0xfff < ppiStack_64) {
      piVar10 = (int *)apiStack_54[0][-1];
      ppiStack_64 = (int **)(uStack_40 + 0x24);
      if (0x1f < (uint)((int)apiStack_54[0] + (-4 - (int)piVar10))) {
                    /* WARNING: Subroutine does not return */
        ppiStack_64 = (int **)0xacc0cc;
        uStack_8._0_1_ = uVar7;
        FUN_017167a3();
      }
    }
    ppiStack_6c = (int **)0xacbdc8;
    piStack_68 = piVar10;
    FUN_01674ea0();
  }
  uStack_44 = 0;
  uStack_40 = 0xf;
  apiStack_54[0] = (int *)((uint)apiStack_54[0] & 0xffffff00);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  piStack_68 = param_2;
  ppiStack_64 = (int **)param_3;
  ppiStack_6c = &piStack_2c;
  ppuStack_70 = (undefined4 **)0xacbe0e;
  FUN_00ad1c70();
  uStack_8._0_1_ = 8;
  uVar7 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  piVar10 = (int *)*param_2;
  if (piVar10 != (int *)param_2[1]) {
    do {
      puStack_18 = (undefined *)*piVar10;
      if (puStack_18 != (undefined *)0x0) {
        iVar4 = *(int *)(puStack_18 + 0xc);
        ppiStack_64 = (int **)0xacbe3b;
        iVar8 = FUN_00913630();
        puVar11 = (undefined *)0x0;
        if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8) <=
            (uint)*(ushort *)(iVar8 + 0x1da)) {
          puVar11 = puStack_18;
        }
        if (puVar11 != (undefined *)0x0) {
          puStack_18 = (undefined *)&piStack_68;
          if (piStack_28 != (int *)0x0) {
            LOCK();
            piStack_28[1] = piStack_28[1] + 1;
            UNLOCK();
          }
          piStack_68 = piStack_2c;
          ppiStack_64 = (int **)piStack_28;
          puStack_1c = (undefined *)&ppuStack_70;
          if (ppiStack_30 != (int **)0x0) {
            LOCK();
            ppiStack_30[1] = (int *)((int)ppiStack_30[1] + 1);
            UNLOCK();
          }
          ppuStack_70 = ppuStack_34;
          ppiStack_6c = ppiStack_30;
          puStack_20 = (undefined *)&uStack_78;
          if (param_7 != (int *)0x0) {
            LOCK();
            param_7[1] = param_7[1] + 1;
            UNLOCK();
          }
          uStack_78 = param_6;
          piStack_74 = param_7;
          puStack_24 = (undefined *)&piStack_80;
          if (param_5 != (int *)0x0) {
            LOCK();
            param_5[1] = param_5[1] + 1;
            UNLOCK();
          }
          piStack_80 = param_4;
          piStack_7c = param_5;
          uStack_8._0_1_ = 0xc;
          puVar9 = (undefined4 *)FUN_0060dcd0(auStack_3c,puVar11);
          uVar5 = *puVar9;
          uVar6 = puVar9[1];
          *puVar9 = 0;
          puVar9[1] = 0;
          uStack_8._0_1_ = 0xe;
          FUN_00accbe0(uVar5,uVar6);
          piVar3 = piStack_38;
          uStack_8._0_1_ = 8;
          if (piStack_38 != (int *)0x0) {
            LOCK();
            iVar4 = piStack_38[1] + -1;
            piStack_38[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              ppiStack_64 = (int **)0xacbf6e;
              (**(code **)*piStack_38)();
              LOCK();
              piVar1 = piVar3 + 2;
              iVar4 = *piVar1 + -1;
              *piVar1 = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                ppiStack_64 = (int **)0xacbf7e;
                (**(code **)(*piVar3 + 4))();
              }
            }
          }
        }
      }
      piVar10 = piVar10 + 2;
      param_1 = uStack_14;
      uVar7 = (undefined)uStack_8;
    } while (piVar10 != (int *)param_2[1]);
  }
  uStack_8._0_1_ = uVar7;
  piStack_68 = (int *)0xacbf96;
  ppiStack_64 = (int **)param_1;
  piVar10 = (int *)FUN_008f7870();
  if (piVar10 != (int *)0x0) {
    ppiStack_64 = (int **)0xacbfa5;
    piVar10 = (int *)FUN_00ac32c0();
    if (piVar10 != (int *)0x0) {
      ppiStack_64 = (int **)0x1;
      ppiStack_6c = &param_4;
      piStack_68 = (int *)(param_2[1] - *param_2 >> 3);
      ppuStack_70 = (undefined4 **)0xacbfc2;
      piVar10 = (int *)FUN_00b71660();
    }
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piVar3 = piStack_28 + 1;
    iVar4 = *piVar3;
    piVar10 = (int *)*piVar3;
    *piVar3 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      ppiStack_64 = (int **)0xacbfd8;
      (**(code **)*piStack_28)();
      LOCK();
      piVar3 = piStack_28 + 2;
      iVar4 = *piVar3;
      piVar10 = (int *)*piVar3;
      *piVar3 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        ppiStack_64 = (int **)0xacbfe8;
        piVar10 = (int *)(**(code **)(*piStack_28 + 4))();
      }
    }
  }
  if (ppiStack_30 != (int **)0x0) {
    LOCK();
    ppiVar2 = ppiStack_30 + 1;
    piVar3 = *ppiVar2;
    piVar10 = *ppiVar2;
    *ppiVar2 = (int *)((int)piVar3 + -1);
    UNLOCK();
    if ((int *)((int)piVar3 + -1) == (int *)0x0) {
      ppiStack_64 = (int **)0xacbffe;
      (*(code *)**ppiStack_30)();
      LOCK();
      ppiVar2 = ppiStack_30 + 2;
      piVar3 = *ppiVar2;
      piVar10 = *ppiVar2;
      *ppiVar2 = (int *)((int)piVar3 + -1);
      UNLOCK();
      if ((int *)((int)piVar3 + -1) == (int *)0x0) {
        ppiStack_64 = (int **)0xacc00e;
        piVar10 = (int *)(*(code *)(*ppiStack_30)[1])();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar3 = param_3 + 1;
    iVar4 = *piVar3;
    piVar10 = (int *)*piVar3;
    *piVar3 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      ppiStack_64 = (int **)0xacc024;
      (**(code **)*param_3)();
      LOCK();
      piVar3 = param_3 + 2;
      iVar4 = *piVar3;
      piVar10 = (int *)*piVar3;
      *piVar3 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        ppiStack_64 = (int **)0xacc034;
        piVar10 = (int *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  piVar3 = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar4 = *piVar1;
    piVar10 = (int *)*piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      ppiStack_64 = (int **)0xacc04a;
      (**(code **)*param_5)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      piVar10 = (int *)*piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        ppiStack_64 = (int **)0xacc05a;
        piVar10 = (int *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = param_7;
  if (param_7 != (int *)0x0) {
    LOCK();
    piVar1 = param_7 + 1;
    iVar4 = *piVar1;
    piVar10 = (int *)*piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      ppiStack_64 = (int **)0xacc070;
      piVar10 = (int *)(**(code **)*param_7)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        ppiStack_64 = (int **)0xacc07f;
        piVar10 = (int *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000030) {
    ppiStack_64 = (int **)(in_stack_00000030 + 1);
    piVar10 = param_8;
    if (0xfff < ppiStack_64) {
      piVar10 = (int *)param_8[-1];
      ppiStack_64 = (int **)(in_stack_00000030 + 0x24);
      if (0x1f < (uint)((int)param_8 + (-4 - (int)piVar10))) {
                    /* WARNING: Subroutine does not return */
        ppiStack_64 = (int **)&UNK_00acc0d1;
        FUN_017167a3();
      }
    }
    ppiStack_6c = (int **)0xacc0ac;
    piStack_68 = piVar10;
    piVar10 = (int *)FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return piVar10;
}



/* FUNCTION 22299 ; VA 0x00acc0e0 ; FUN_00acc0e0 */

void FUN_00acc0e0(undefined4 *param_1)

{
  byte bVar1;
  int iVar2;
  int *piVar3;
  undefined uVar4;
  int *piVar5;
  uint *puVar6;
  undefined *puVar7;
  int iVar8;
  uint uVar9;
  undefined4 *puVar10;
  byte *pbVar11;
  int in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined8 in_stack_00000034;
  uint in_stack_0000003c;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 *in_stack_00000050;
  undefined8 in_stack_00000054;
  uint auStack_21c [2];
  undefined4 uStack_214;
  undefined4 uStack_210;
  undefined4 uStack_20c;
  undefined4 *puStack_208;
  undefined8 uStack_204;
  uint auStack_1fc [2];
  undefined4 uStack_1f4;
  undefined4 uStack_1f0;
  undefined4 uStack_1ec;
  undefined4 uStack_1e8;
  undefined8 uStack_1e4;
  int iStack_1dc;
  int *piStack_1d8;
  undefined auStack_1d4 [40];
  undefined4 uStack_1ac;
  undefined auStack_1a8 [16];
  undefined4 uStack_198;
  byte **ppbStack_194;
  undefined4 *puStack_190;
  byte **ppbStack_18c;
  uint *puStack_188;
  undefined4 uStack_17c;
  int iStack_178;
  undefined auStack_174 [40];
  undefined auStack_14c [160];
  undefined auStack_ac [24];
  uint auStack_94 [4];
  undefined4 uStack_84;
  uint uStack_80;
  uint auStack_7c [4];
  undefined4 uStack_6c;
  uint uStack_68;
  uint auStack_64 [4];
  int iStack_54;
  uint uStack_50;
  int iStack_4c;
  int *piStack_48;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  undefined *puStack_2c;
  undefined4 *puStack_28;
  byte *pbStack_24;
  int *piStack_20;
  undefined *puStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e928c;
  pvStack_10 = ExceptionList;
  uStack_84 = 0;
  uStack_80 = 0xf;
  auStack_94[0] = auStack_94[0] & 0xffffff00;
  uStack_6c = 0;
  uStack_68 = 0xf;
  auStack_7c[0] = auStack_7c[0] & 0xffffff00;
  puStack_188 = (uint *)0x0;
  ppbStack_18c = (byte **)&DAT_018bc9b8;
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  iStack_54 = 0;
  uStack_50 = 0xf;
  auStack_64[0] = auStack_64[0] & 0xffffff00;
  puStack_190 = (undefined4 *)0xacc156;
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  uStack_8._0_1_ = 5;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 5;
  if (in_stack_00000014 == 0) {
    puStack_188 = (uint *)0x26;
    ppbStack_18c = (byte **)0x194b10c;
    puStack_190 = (undefined4 *)0xacc3c9;
    uStack_8._0_1_ = uVar4;
    FUN_005542c0();
    goto LAB_00acc3c9;
  }
  puStack_188 = (uint *)0x1;
  ppbStack_18c = (byte **)0x3;
  puStack_190 = (undefined4 *)0xacc176;
  FUN_00565940();
  puStack_188 = (uint *)in_stack_00000014;
  ppbStack_18c = (byte **)&param_1;
  if (0xf < in_stack_00000018) {
    ppbStack_18c = (byte **)param_1;
  }
  puStack_190 = (undefined4 *)auStack_14c;
  uStack_8._0_1_ = 6;
  ppbStack_194 = (byte **)0xacc195;
  FUN_0055b3b0();
  ppbStack_194 = &pbStack_24;
  uStack_198 = 0xacc19e;
  FUN_00563d90();
  puStack_188 = auStack_44;
  uStack_8._0_1_ = 7;
  ppbStack_18c = (byte **)0xacc1b4;
  puStack_190 = (undefined4 *)FUN_0058c4d0();
  puStack_188 = (uint *)0x0;
  ppbStack_18c = &pbStack_24;
  uStack_8._0_1_ = 8;
  ppbStack_194 = (byte **)0xacc1c4;
  cStack_11 = FUN_0098f070();
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (0xf < uStack_30) {
    puStack_188 = (uint *)(uStack_30 + 1);
    uVar9 = auStack_44[0];
    if (0xfff < puStack_188) {
      uVar9 = *(uint *)(auStack_44[0] - 4);
      puStack_188 = (uint *)(uStack_30 + 0x24);
      if (0x1f < (auStack_44[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_188 = (uint *)0xacc7d3;
        FUN_017167a3();
      }
    }
    puStack_190 = (undefined4 *)0xacc1ff;
    ppbStack_18c = (byte **)uVar9;
    FUN_01674ea0();
  }
  pbVar11 = pbStack_24;
  if (cStack_11 == '\0') {
    puStack_188 = (uint *)0x30;
    ppbStack_18c = (byte **)0x194afa4;
    puStack_190 = (undefined4 *)0xacc218;
    FUN_005542c0();
  }
  else {
    puStack_188 = (uint *)0x18;
    ppbStack_18c = (byte **)0x194afd8;
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = auStack_44[0] & 0xffffff00;
    puStack_190 = (undefined4 *)0xacc241;
    FUN_005542c0();
    pbVar11 = pbVar11 + *pbVar11 + 1;
    puStack_188 = auStack_44;
    ppbStack_18c = (byte **)0xacc254;
    puStack_190 = (undefined4 *)FUN_005702d0();
    ppbStack_18c = (byte **)auStack_44;
    puStack_188 = (uint *)(-(uint)(pbVar11 != (byte *)0x0) & (uint)(pbVar11 + 1));
    ppbStack_194 = (byte **)&iStack_18;
    uStack_198 = 0xacc26e;
    FUN_00562fc0();
    puStack_188 = (uint *)0xacc276;
    FUN_005507b0();
    if (iStack_18 == 0) {
      puStack_188 = (uint *)0x39;
      ppbStack_18c = (byte **)0x194aff4;
LAB_00acc2c3:
      puStack_190 = (undefined4 *)0xacc2cb;
      FUN_005542c0();
    }
    else {
      iVar2 = *(int *)(iStack_18 + 0x20);
      puStack_188 = (uint *)0xacc291;
      iVar8 = FUN_0088cb40();
      if (iVar2 != iVar8) {
        puStack_188 = (uint *)0x43;
        ppbStack_18c = (byte **)0x194b030;
        goto LAB_00acc2c3;
      }
      puStack_188 = (uint *)auStack_ac;
      ppbStack_18c = (byte **)0xacc2a3;
      puStack_188 = (uint *)FUN_00563690();
      ppbStack_18c = (byte **)0xacc2af;
      FUN_005511f0();
      puStack_188 = (uint *)0xacc2ba;
      FUN_005507b0();
    }
    if (iStack_54 == 0) {
      puStack_188 = (uint *)0x16;
      ppbStack_18c = (byte **)0x194b074;
      uStack_34 = 0;
      uStack_30 = 0xf;
      auStack_44[0] = auStack_44[0] & 0xffffff00;
      puStack_190 = (undefined4 *)0xacc2f9;
      FUN_005542c0();
      bVar1 = *pbStack_24;
      puStack_188 = auStack_44;
      ppbStack_18c = (byte **)0xacc30c;
      puStack_190 = (undefined4 *)FUN_005702d0();
      ppbStack_18c = (byte **)auStack_44;
      puStack_188 = (uint *)(-(uint)(pbStack_24 + bVar1 + 1 != (byte *)0x0) &
                            (uint)(pbStack_24 + bVar1 + 1 + 1));
      ppbStack_194 = (byte **)&iStack_18;
      uStack_198 = 0xacc326;
      FUN_00562fc0();
      puStack_188 = (uint *)0xacc32e;
      FUN_005507b0();
      if (iStack_18 == 0) {
        puStack_188 = (uint *)0x37;
        ppbStack_18c = (byte **)0x194b08c;
      }
      else {
        iVar2 = *(int *)(iStack_18 + 0x20);
        puStack_188 = (uint *)0xacc349;
        iVar8 = FUN_0088cb40();
        if (iVar2 == iVar8) {
          puStack_188 = (uint *)auStack_ac;
          ppbStack_18c = (byte **)0xacc35b;
          puStack_188 = (uint *)FUN_00563690();
          ppbStack_18c = (byte **)0xacc364;
          FUN_005511f0();
          puStack_188 = (uint *)0xacc36f;
          FUN_005507b0();
          goto LAB_00acc383;
        }
        puStack_188 = (uint *)0x41;
        ppbStack_18c = (byte **)0x194b0c8;
      }
      puStack_190 = (undefined4 *)0xacc380;
      FUN_005542c0();
    }
  }
LAB_00acc383:
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_20[1] + -1;
    piStack_20[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_188 = (uint *)0xacc399;
      (**(code **)*piStack_20)();
      LOCK();
      iVar2 = piStack_20[2] + -1;
      piStack_20[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        puStack_188 = (uint *)0xacc3a9;
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 5;
  puStack_188 = (uint *)0xacc3b8;
  FUN_005705c0();
LAB_00acc3c9:
  puStack_188 = (uint *)puStack_1c;
  ppbStack_18c = (byte **)0xacc3d1;
  iStack_18 = FUN_008f7870();
  if (iStack_54 == 0) {
    puStack_188 = (uint *)0xc;
    ppbStack_18c = (byte **)0xacc3e8;
    puStack_28 = (undefined4 *)FUN_01674e20();
    if (puStack_28 == (undefined4 *)0x0) {
      ppbStack_18c = (byte **)0x0;
    }
    else {
      *puStack_28 = 0;
      puStack_28[1] = 0;
      puStack_28[2] = 0;
      ppbStack_18c = (byte **)puStack_28;
    }
    puStack_188 = (uint *)in_stack_00000018;
    iStack_4c = 0;
    piStack_48 = (int *)0x0;
    puStack_190 = (undefined4 *)0xacc424;
    FUN_0055ba30();
    uStack_8._0_1_ = 9;
    puStack_188 = (uint *)0xacc42d;
    uStack_17c = FUN_0088cb40();
    puStack_188 = auStack_94;
    iStack_178 = 0;
    ppbStack_18c = (byte **)0xacc44f;
    FUN_0054ef60();
    puStack_188 = (uint *)0xacc454;
    iStack_178 = FUN_005c9d30();
    iVar2 = iStack_4c;
    puStack_188 = &uStack_17c;
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    ppbStack_18c = *(byte ***)(iStack_4c + 4);
    if ((byte **)*(int *)(iStack_4c + 8) == ppbStack_18c) {
      puStack_190 = (undefined4 *)0xacc488;
      FUN_005ca4f0();
    }
    else {
      ppbStack_18c = (byte **)0xacc477;
      FUN_005caf00();
      *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 0xd0;
    }
    uStack_8._0_1_ = 0xb;
    if (iStack_178 != 0) {
      puStack_188 = (uint *)auStack_174;
      ppbStack_18c = (byte **)0xacc4a2;
      (**(code **)(iStack_178 + 8))();
    }
    uStack_8._0_1_ = 9;
    puStack_188 = (uint *)0xacc4ae;
    uStack_17c = FUN_0088cb40();
    puStack_188 = auStack_7c;
    iStack_178 = 0;
    ppbStack_18c = (byte **)0xacc4cd;
    FUN_0054ef60();
    puStack_188 = (uint *)0xacc4d2;
    iStack_178 = FUN_005c9d30();
    ppbStack_18c = *(byte ***)(iVar2 + 4);
    puStack_188 = &uStack_17c;
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    if ((byte **)*(uint *)(iVar2 + 8) == ppbStack_18c) {
      puStack_190 = (undefined4 *)0xacc503;
      FUN_005ca4f0();
    }
    else {
      ppbStack_18c = (byte **)0xacc4f2;
      FUN_005caf00();
      *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 0xd0;
    }
    uStack_8._0_1_ = 0xd;
    if (iStack_178 != 0) {
      puStack_188 = (uint *)auStack_174;
      ppbStack_18c = (byte **)0xacc51d;
      (**(code **)(iStack_178 + 8))();
    }
    piVar3 = piStack_48;
    puStack_188 = (uint *)0x1;
    puStack_28 = (undefined4 *)auStack_1a8;
    uStack_1ac = 0;
    puStack_1c = auStack_1d4;
    puStack_2c = (undefined *)&iStack_1dc;
    if (piStack_48 != (int *)0x0) {
      LOCK();
      piStack_48[1] = piStack_48[1] + 1;
      UNLOCK();
    }
    iStack_1dc = iVar2;
    piStack_1d8 = piStack_48;
    piStack_20 = (int *)auStack_1fc;
    uStack_8._0_1_ = 0xe;
    auStack_1fc[0] = 0;
    piVar5 = &iStack_1dc;
    puVar10 = (undefined4 *)auStack_1a8;
    puVar6 = auStack_1fc;
    puVar7 = auStack_1d4;
    if (in_stack_0000001c != 0) {
      auStack_1fc[0] = in_stack_0000001c;
      if ((in_stack_0000001c & 1) == 0) {
        uStack_204 = ZEXT48(&uStack_1f4);
        puStack_208 = &stack0x00000024;
        uStack_20c = 0xacc59a;
        (**(code **)(in_stack_0000001c & 0xfffffffe))();
        piVar5 = (int *)puStack_2c;
        puVar10 = puStack_28;
        puVar6 = (uint *)piStack_20;
        puVar7 = puStack_1c;
      }
      else {
        uStack_1f4 = in_stack_00000024;
        uStack_1f0 = in_stack_00000028;
        uStack_1ec = in_stack_0000002c;
        uStack_1e8 = in_stack_00000030;
        uStack_1e4 = in_stack_00000034;
        piVar5 = &iStack_1dc;
        puVar10 = (undefined4 *)auStack_1a8;
        puVar6 = auStack_1fc;
        puVar7 = auStack_1d4;
      }
    }
    puStack_1c = puVar7;
    piStack_20 = (int *)puVar6;
    puStack_28 = puVar10;
    puStack_2c = (undefined *)piVar5;
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    uStack_204 = CONCAT44(puStack_1c,0xacc5a9);
    FUN_00ac1d70();
    piStack_1d8 = (int *)0xacc5b4;
    FUN_00abfda0();
    uStack_1ac = 0xacc5bc;
    FUN_0090ca30();
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar2 = piVar3[1] + -1;
      piVar3[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        puStack_188 = (uint *)0xacc5da;
        (**(code **)*piVar3)();
        LOCK();
        piVar5 = piVar3 + 2;
        iVar2 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          puStack_188 = (uint *)0xacc5ed;
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  else {
    puStack_188 = (uint *)0x1;
    uStack_1ac = 0;
    piStack_20 = (int *)auStack_1fc;
    uStack_204 = CONCAT44(auStack_64,0xacc611);
    FUN_0054ef60();
    puStack_2c = (undefined *)auStack_21c;
    uStack_8._0_1_ = 0xf;
    auStack_21c[0] = 0;
    puVar6 = auStack_21c;
    if (in_stack_0000003c != 0) {
      auStack_21c[0] = in_stack_0000003c;
      if ((in_stack_0000003c & 1) == 0) {
        (**(code **)(in_stack_0000003c & 0xfffffffe))(&stack0x00000044,&uStack_214,0);
        puVar6 = (uint *)puStack_2c;
      }
      else {
        uStack_214 = in_stack_00000044;
        uStack_210 = in_stack_00000048;
        uStack_20c = in_stack_0000004c;
        puStack_208 = in_stack_00000050;
        uStack_204 = in_stack_00000054;
        puVar6 = auStack_21c;
      }
    }
    puStack_2c = (undefined *)puVar6;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_009645a0(&uStack_1e4);
    uStack_1e8 = 0xacc66d;
    FUN_0095fcd0();
    uStack_1ac = 0xacc675;
    FUN_0090ca30();
  }
  uStack_8._0_1_ = 4;
  if (0xf < uStack_50) {
    puStack_188 = (uint *)(uStack_50 + 1);
    uVar9 = auStack_64[0];
    if (0xfff < puStack_188) {
      uVar9 = *(uint *)(auStack_64[0] - 4);
      puStack_188 = (uint *)(uStack_50 + 0x24);
      if (0x1f < (auStack_64[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_188 = (uint *)0xacc7d8;
        FUN_017167a3();
      }
    }
    puStack_190 = (undefined4 *)0xacc6aa;
    ppbStack_18c = (byte **)uVar9;
    FUN_01674ea0();
  }
  uStack_8._0_1_ = 3;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_68) {
    puStack_188 = (uint *)(uStack_68 + 1);
    uVar9 = auStack_7c[0];
    if (0xfff < puStack_188) {
      uVar9 = *(uint *)(auStack_7c[0] - 4);
      puStack_188 = (uint *)(uStack_68 + 0x24);
      if (0x1f < (auStack_7c[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_188 = (uint *)0xacc7dd;
        uStack_8._0_1_ = uVar4;
        FUN_017167a3();
      }
    }
    puStack_190 = (undefined4 *)0xacc6e2;
    ppbStack_18c = (byte **)uVar9;
    FUN_01674ea0();
  }
  uStack_8._0_1_ = 2;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_80) {
    puStack_188 = (uint *)(uStack_80 + 1);
    uVar9 = auStack_94[0];
    if (0xfff < puStack_188) {
      uVar9 = *(uint *)(auStack_94[0] - 4);
      puStack_188 = (uint *)(uStack_80 + 0x24);
      if (0x1f < (auStack_94[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_188 = (uint *)0xacc7e2;
        uStack_8._0_1_ = uVar4;
        FUN_017167a3();
      }
    }
    puStack_190 = (undefined4 *)0xacc71d;
    ppbStack_18c = (byte **)uVar9;
    FUN_01674ea0();
  }
  uStack_8._0_1_ = 1;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    puStack_188 = (uint *)(in_stack_00000018 + 1);
    puVar10 = param_1;
    if (0xfff < puStack_188) {
      puVar10 = (undefined4 *)param_1[-1];
      puStack_188 = (uint *)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_1 + (-4 - (int)puVar10))) {
                    /* WARNING: Subroutine does not return */
        puStack_188 = (uint *)&UNK_00acc7e7;
        uStack_8._0_1_ = uVar4;
        FUN_017167a3();
      }
    }
    puStack_190 = (undefined4 *)0xacc755;
    ppbStack_18c = (byte **)puVar10;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = (undefined4 *)((uint)param_1 & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
  if (in_stack_0000001c != 0) {
    if (((in_stack_0000001c & 1) == 0) &&
       (*(code **)(in_stack_0000001c & 0xfffffffe) != (code *)0x0)) {
      puStack_190 = &stack0x00000024;
      puStack_188 = (uint *)0x2;
      ppbStack_194 = (byte **)0xacc78b;
      ppbStack_18c = (byte **)puStack_190;
      (**(code **)(in_stack_0000001c & 0xfffffffe))();
    }
    in_stack_0000001c = 0;
  }
  uStack_8 = 0x11;
  if (((in_stack_0000003c != 0) && ((in_stack_0000003c & 1) == 0)) &&
     (*(code **)(in_stack_0000003c & 0xfffffffe) != (code *)0x0)) {
    puStack_190 = &stack0x00000044;
    puStack_188 = (uint *)0x2;
    ppbStack_194 = (byte **)0xacc7b9;
    ppbStack_18c = (byte **)puStack_190;
    (**(code **)(in_stack_0000003c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22300 ; VA 0x00acc7f0 ; FUN_00acc7f0 */

void FUN_00acc7f0(int param_1,int param_2)

{
  uint uVar1;
  uint uVar2;
  char *pcVar3;
  undefined4 uVar4;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e92b0;
  pvStack_10 = ExceptionList;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("TeleportInvoked",0xf);
  uStack_8 = 0;
  FUN_008783f0(auStack_40,1,0);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_2c) {
    uVar2 = uStack_2c + 1;
    uVar1 = auStack_40[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_40[0] - 4);
      uVar2 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("ReportTeleportMethodAnalytics_",0x1e);
  uStack_8 = 1;
  if (param_1 == 0) {
    uVar4 = 0x16;
    pcVar3 = "TeleportToSpawnByName_";
LAB_00acc8fe:
    FUN_00554150(pcVar3,uVar4);
  }
  else {
    if (param_1 == 1) {
      uVar4 = 0x18;
      pcVar3 = "TeleportToPlaceInstance_";
      goto LAB_00acc8fe;
    }
    if (param_1 == 2) {
      uVar4 = 0x18;
      pcVar3 = "TeleportToPrivateServer_";
      goto LAB_00acc8fe;
    }
    if (param_1 == 3) {
      uVar4 = 0x13;
      pcVar3 = "TeleportPartyAsync_";
      goto LAB_00acc8fe;
    }
    if (param_1 == 4) {
      uVar4 = 8;
      pcVar3 = "Unknown_";
      goto LAB_00acc8fe;
    }
  }
  if (param_2 == 1) {
    pcVar3 = "Client";
  }
  else {
    if (param_2 != 2) goto LAB_00acc93b;
    pcVar3 = "Server";
  }
  FUN_00554150(pcVar3,6);
  FUN_008783f0(auStack_28,1,0);
LAB_00acc93b:
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22301 ; VA 0x00acc990 ; FUN_00acc990 */

void FUN_00acc990(undefined4 param_1,undefined4 param_2,uint param_3)

{
  char cVar1;
  char *pcVar2;
  uint in_stack_0000002c;
  undefined auStack_8e4 [28];
  undefined4 uStack_8c8;
  undefined auStack_8c4 [8];
  undefined4 uStack_8bc;
  undefined *puStack_8b8;
  code *pcStack_8b4;
  int iStack_8b0;
  int iStack_8ac;
  undefined4 *puStack_8a8;
  undefined4 uStack_8a0;
  undefined1 *puStack_89c;
  undefined4 uStack_898;
  undefined auStack_894 [12];
  undefined4 uStack_888;
  undefined4 uStack_884;
  undefined4 uStack_880;
  undefined4 uStack_87c;
  undefined4 uStack_878;
  undefined4 uStack_874;
  undefined4 uStack_854;
  char *pcStack_850;
  undefined4 uStack_84c;
  char *pcStack_848;
  undefined4 uStack_844;
  undefined4 uStack_840;
  char *pcStack_83c;
  char *pcStack_838;
  int iStack_834;
  char acStack_828 [2048];
  undefined *puStack_28;
  undefined *puStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e92f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  pcStack_838 = (char *)0xacc9c2;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_008b9b00();
  if (cVar1 == '\0') {
    uStack_84c = 0x3f;
    pcStack_838 = (char *)0x0;
    iStack_834 = 0xf;
    pcStack_850 = "TeleportService:ReserveServer can only be called by the server.";
    pcStack_848 = (char *)((uint)pcStack_848 & 0xffffff00);
    uStack_854 = 0xaccb4a;
    FUN_005542c0();
    uStack_84c = 0xaccb52;
    FUN_005e65e0();
  }
  else {
    pcStack_838 = (char *)0xacc9d3;
    iStack_20 = FUN_0064e700();
    if (iStack_20 != 0) {
      iStack_834 = 0x800;
      pcStack_83c = acStack_828;
      pcStack_838 = (char *)0x0;
      uStack_840 = 0xacc9f4;
      FUN_0170d1f0();
      uStack_840 = param_2;
      pcStack_850 = acStack_828;
      uStack_844 = param_1;
      pcStack_848 = "reservedservers/create?placeId=%lld";
      uStack_84c = 0x800;
      uStack_854 = 0xacca10;
      FUN_0058ccc0();
      pcVar2 = acStack_828;
      do {
        cVar1 = *pcVar2;
        pcVar2 = pcVar2 + 1;
      } while (cVar1 != '\0');
      iStack_834 = (int)pcVar2 - (int)(acStack_828 + 1);
      pcStack_838 = acStack_828;
      pcStack_83c = (char *)0xacca39;
      FUN_005542c0();
      puStack_28 = (undefined *)&pcStack_850;
      param_2 = CONCAT31(param_2._1_3_,DAT_01eeb670);
      uStack_1c = CONCAT31(uStack_1c._1_3_,DAT_01eeb670);
      puStack_8a8 = &stack0x0000002c;
      uStack_854 = 0;
      iStack_8ac = 0xacca61;
      FUN_0054f510();
      puStack_8a8 = (undefined4 *)param_2;
      iStack_8ac = iStack_18;
      iStack_8b0 = 0;
      pcStack_8b4 = FUN_00acb3c0;
      uStack_8bc = 0xacca75;
      puStack_8b8 = (undefined *)&uStack_884;
      FUN_00ac1f70();
      uStack_888 = 0xacca7f;
      FUN_00ac0040();
      uStack_8._0_1_ = 2;
      uStack_874 = 0;
      puStack_14 = auStack_8e4;
      FUN_0054f510(&stack0x0000002c);
      uStack_8._0_1_ = 3;
      FUN_0054f510(&param_3);
      uStack_8._0_1_ = 2;
      FUN_00ac2190(auStack_8c4,FUN_00acc0e0,0,iStack_18,uStack_1c);
      uStack_8c8 = 0xaccad6;
      FUN_00ac0100();
      uStack_874 = 0xc;
      uStack_878 = 2;
      uStack_87c = 1;
      puStack_24 = auStack_894;
      uStack_8._0_1_ = 4;
      uStack_898 = 0;
      uStack_884 = 0;
      uStack_880 = 0xf;
      puStack_89c = &DAT_018bc9b8;
      auStack_894[0] = 0;
      uStack_8a0 = 0xaccb05;
      FUN_005542c0();
      uStack_8._0_1_ = 5;
      iStack_8b0 = iStack_18 + 0x5c;
      pcStack_8b4 = (code *)0xaccb1a;
      FUN_0054ef60();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      iStack_8b0 = 0xaccb26;
      FUN_00bd1000();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      pcStack_83c = &stack0x00000014;
      iStack_834 = 2;
      uStack_840 = 0xaccb73;
      pcStack_838 = pcStack_83c;
      (**(code **)(param_3 & 0xfffffffe))();
    }
    param_3 = 0;
  }
  uStack_8 = 7;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    pcStack_83c = &stack0x00000034;
    iStack_834 = 2;
    uStack_840 = 0xaccba1;
    pcStack_838 = pcStack_83c;
    (**(code **)(in_stack_0000002c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22302 ; VA 0x00accbc0 ; FUN_00accbc0 */

void FUN_00accbc0(void)

{
  FUN_005542c0(&DAT_018bc9b8,0);
  return;
}



/* FUNCTION 22303 ; VA 0x00accbe0 ; FUN_00accbe0 */

int FUN_00accbe0(int param_1,int *param_2,int param_3,int *param_4,int param_5,int *param_6,
                int param_7,int *param_8,int param_9,int *param_10)

{
  int *piVar1;
  int *piVar2;
  code *pcVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 uVar9;
  undefined4 *puVar10;
  undefined4 ****ppppuVar11;
  int *piVar12;
  undefined8 uVar13;
  undefined *puVar14;
  undefined8 *puVar15;
  undefined auStack_178 [4];
  int iStack_174;
  undefined auStack_170 [200];
  undefined auStack_a8 [24];
  undefined auStack_90 [24];
  undefined4 uStack_78;
  int *piStack_74;
  undefined4 ***apppuStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  int *piStack_50;
  int iStack_4c;
  int iStack_48;
  int *piStack_44;
  int iStack_40;
  int iStack_3c;
  code *pcStack_38;
  int *piStack_34;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e9437;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  if ((param_3 == 0) && (DAT_01d66660 != '\0')) {
    ExceptionList = &pvStack_10;
    iVar4 = FUN_0086f2f0(3,"Unexpected teleport error.");
    goto LAB_00acd845;
  }
  uStack_58 = 0;
  uStack_78 = 0;
  piStack_50 = (int *)0x0;
  piStack_74 = (int *)0x0;
  uStack_8 = 5;
  if (DAT_01d66660 == '\0') {
    piVar12 = (int *)0x0;
    ExceptionList = &pvStack_10;
  }
  else {
    ExceptionList = &pvStack_10;
    puVar5 = (undefined4 *)FUN_00ac3970(&pcStack_38,param_3);
    piVar2 = piStack_34;
    uStack_78 = *puVar5;
    piVar12 = (int *)puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    piStack_74 = piVar12;
    uStack_58 = uStack_78;
    piStack_50 = piVar12;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_34[1] + -1;
      piStack_34[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  iStack_3c = param_1;
  if (param_1 == 0) {
    iVar4 = FUN_0086f2f0(2,"Invalid player to teleport.");
  }
  else {
    iVar4 = *(int *)(param_1 + 0xc);
    iVar6 = FUN_00913630();
    iStack_4c = 0;
    if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
        (uint)*(ushort *)(iVar6 + 0x1da)) {
      iStack_4c = iStack_3c;
    }
    if (iStack_4c == 0) {
      iStack_4c = FUN_00980070(param_1);
      if (iStack_4c == 0) {
        iVar4 = FUN_0086f2f0(2,"Invalid player to teleport.");
        piVar12 = piStack_50;
        goto LAB_00acd824;
      }
      FUN_0086f2f0(2,
                   "Passing Character instance into teleport functions is deprecated. Please use Player instance instead."
                  );
    }
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = 0;
    FUN_005542c0("teleportType",0xc);
    uStack_8._0_1_ = 6;
    FUN_0091d3d0(auStack_30);
    iVar4 = FUN_00ac3540();
    uStack_8._0_1_ = 5;
    FUN_005507b0();
    if (iVar4 == 0) {
      piStack_34 = &DAT_0194a248;
      puVar14 = &DAT_01eeb698;
LAB_00acce47:
      pcStack_38 = FUN_00adb5d0;
      FUN_0075d260(puVar14,&pcStack_38);
    }
    else {
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = 0;
      FUN_005542c0("teleportType",0xc);
      uStack_8._0_1_ = 7;
      FUN_0091d3d0(auStack_30);
      iVar4 = FUN_00ac3540();
      uStack_8._0_1_ = 5;
      FUN_005507b0();
      if (iVar4 == 1) {
        piStack_34 = (int *)s_ToInstance_0194a250;
        puVar14 = &DAT_01eeb6a0;
        goto LAB_00acce47;
      }
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = 0;
      FUN_005542c0("teleportType",0xc);
      uStack_8._0_1_ = 8;
      FUN_0091d3d0(auStack_30);
      iVar4 = FUN_00ac3540();
      uStack_8._0_1_ = 5;
      FUN_005507b0();
      if (iVar4 == 2) {
        piStack_34 = (int *)0x194a25c;
        puVar14 = &DAT_01eeb6a8;
        goto LAB_00acce47;
      }
    }
    FUN_00888650(&pcStack_38);
    uStack_8._0_1_ = 9;
    if (param_7 == 0) {
      uVar7 = FUN_00888650(&iStack_48);
      FUN_005587e0(uVar7);
      FUN_00550b30();
    }
    iStack_48 = 0;
    piStack_44 = (int *)0x0;
    uStack_8._0_1_ = 10;
    if (DAT_01d66660 == '\0') {
      if (param_9 == 0) {
        uVar7 = FUN_00888650(&uStack_18);
        FUN_005587e0(uVar7);
        FUN_00550b30();
      }
      iVar4 = FUN_008f7870(uStack_54);
      if (iVar4 != 0) {
        piVar12 = *(int **)(iVar4 + 0x43c);
        uStack_18._4_4_ = (int *)(piVar12[1] - (int)piVar12);
        uStack_18._0_4_ = (code *)(*piVar12 - (int)piVar12);
        uStack_20 = 0;
        uStack_1c = 0xf;
        auStack_30[0] = 0;
        FUN_005542c0("SourcePlaceId",0xd);
        puVar15 = &uStack_18;
        uStack_8._0_1_ = 0xe;
        FUN_005c4c00(auStack_30);
        FUN_00632bc0(puVar15);
        uStack_8._0_1_ = 10;
        FUN_005507b0();
      }
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = 0;
      FUN_005542c0("teleportData",0xc);
      FUN_008a0c70(&iStack_3c,auStack_30);
      FUN_005507b0();
      iVar4 = iStack_3c;
      piVar12 = (int *)0x0;
      if (iStack_3c != 0) {
        uStack_20 = 0;
        uStack_1c = 0xf;
        auStack_30[0] = 0;
        FUN_005542c0("TeleportData",0xc);
        uStack_8._0_1_ = 0xf;
        goto LAB_00acd11f;
      }
    }
    else {
      if (param_9 == 0) {
        uVar7 = FUN_00888650(&uStack_18);
      }
      else {
        uVar7 = FUN_00ac3970(&uStack_18,param_9);
      }
      FUN_005587e0(uVar7);
      FUN_00550b30();
      iVar4 = FUN_008f7870(uStack_54);
      if (iVar4 != 0) {
        uStack_18._4_4_ = *(int **)(iVar4 + 0x43c);
        uStack_18._0_4_ = (code *)(*uStack_18._4_4_ - (int)uStack_18._4_4_);
        uStack_18._4_4_ = (int *)(uStack_18._4_4_[1] - (int)uStack_18._4_4_);
        uStack_20 = 0;
        uStack_1c = 0xf;
        auStack_30[0] = 0;
        FUN_005542c0("SourcePlaceId",0xd);
        puVar15 = &uStack_18;
        uStack_8._0_1_ = 0xb;
        FUN_005c4c00(auStack_30);
        FUN_00632bc0(puVar15);
        uStack_8._0_1_ = 10;
        FUN_005507b0();
        uStack_18._0_4_ = *(code **)(iVar4 + 0x440);
        uStack_18._4_4_ = *(int **)(iVar4 + 0x444);
        uStack_20 = 0;
        uStack_1c = 0xf;
        auStack_30[0] = 0;
        FUN_005542c0("SourceGameId",0xc);
        puVar15 = &uStack_18;
        uStack_8._0_1_ = 0xc;
        FUN_005c4c00(auStack_30);
        FUN_00632bc0(puVar15);
        uStack_8._0_1_ = 10;
        FUN_005507b0();
      }
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = 0;
      FUN_005542c0("teleportData",0xc);
      FUN_008a0c70(&iStack_3c,auStack_30);
      FUN_005507b0();
      iVar4 = iStack_3c;
      piVar12 = piStack_44;
      if (iStack_3c != 0) {
        uStack_20 = 0;
        uStack_1c = 0xf;
        auStack_30[0] = 0;
        FUN_005542c0("TeleportData",0xc);
        uStack_8._0_1_ = 0xd;
LAB_00acd11f:
        iVar4 = iVar4 + 0x20;
        FUN_005c4c00(auStack_30);
        FUN_0056ee80(iVar4);
        uStack_8._0_1_ = 10;
        FUN_005507b0();
        piVar12 = piStack_44;
      }
    }
    if (DAT_01d66678 != '\0') {
      uStack_18 = FUN_01682de0();
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = 0;
      FUN_005542c0("teleportStartMsSinceEpoch",0x19);
      puVar15 = &uStack_18;
      uStack_8._0_1_ = 0x10;
      FUN_005c4c00(auStack_30);
      FUN_00632bc0(puVar15);
      uStack_8._0_1_ = 10;
      FUN_005507b0();
    }
    uVar13 = FUN_00928340();
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = 0;
    uStack_18 = uVar13;
    FUN_005542c0("userId",6);
    puVar15 = &uStack_18;
    uStack_8._0_1_ = 0x11;
    FUN_005c4c00(auStack_30);
    FUN_00632bc0(puVar15);
    uStack_8._0_1_ = 10;
    FUN_005507b0();
    uStack_20 = 0;
    iStack_3c = *(int *)(iStack_4c + 0x454);
    uStack_1c = 0xf;
    auStack_30[0] = 0;
    FUN_005542c0("accountAge",10);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
    iVar6 = FUN_005c4c00(auStack_30);
    uVar7 = FUN_0088c8c0();
    *(undefined4 *)(iVar6 + 0x18) = uVar7;
    iVar8 = FUN_005c9cc0();
    iVar4 = *(int *)(iVar6 + 0x1c);
    uStack_18._4_4_ = (int *)iVar8;
    if (iVar4 == iVar8) {
      *(int *)(iVar6 + 0x20) = iStack_3c;
    }
    else {
      if (iVar4 != 0) {
        (**(code **)(iVar4 + 8))(iVar6 + 0x20);
      }
      *(int *)(iVar6 + 0x20) = iStack_3c;
      *(int **)(iVar6 + 0x1c) = uStack_18._4_4_;
    }
    FUN_005507b0();
    if (DAT_01d66660 == '\0') {
      if (param_10 != (int *)0x0) {
        LOCK();
        param_10[1] = param_10[1] + 1;
        UNLOCK();
      }
      uStack_18._0_4_ = (code *)param_9;
      uStack_18._4_4_ = param_10;
      uStack_8._0_1_ = 0x15;
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = 0;
      FUN_005542c0("userData",8);
      uStack_8._0_1_ = 0x16;
    }
    else {
      if (piVar12 != (int *)0x0) {
        LOCK();
        piVar12[1] = piVar12[1] + 1;
        UNLOCK();
      }
      uStack_18._0_4_ = (code *)iStack_48;
      uStack_8._0_1_ = 0x13;
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = 0;
      uStack_18._4_4_ = piVar12;
      FUN_005542c0("userData",8);
      uStack_8._0_1_ = 0x14;
    }
    pcVar3 = pcStack_38;
    puVar15 = &uStack_18;
    FUN_005c4c00(auStack_30);
    FUN_0098dda0(puVar15);
    FUN_005507b0();
    FUN_00550b30();
    if (param_8 != (int *)0x0) {
      LOCK();
      param_8[1] = param_8[1] + 1;
      UNLOCK();
    }
    uStack_18._0_4_ = (code *)param_7;
    uStack_18._4_4_ = param_8;
    uStack_8._0_1_ = 0x17;
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = 0;
    FUN_005542c0("internalData",0xc);
    puVar15 = &uStack_18;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
    FUN_005c4c00(auStack_30);
    FUN_0098dda0(puVar15);
    FUN_005507b0();
    piVar12 = uStack_18._4_4_;
    if (uStack_18._4_4_ != (int *)0x0) {
      LOCK();
      iVar4 = uStack_18._4_4_[1] + -1;
      uStack_18._4_4_[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*uStack_18._4_4_)();
        LOCK();
        piVar2 = piVar12 + 2;
        iVar4 = *piVar2 + -1;
        *piVar2 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar12 + 4))();
        }
      }
    }
    uStack_60 = 0;
    uStack_5c = 0xf;
    apppuStack_70[0] = (undefined4 ***)((uint)apppuStack_70[0] & 0xffffff00);
    if (piStack_34 != (int *)0x0) {
      LOCK();
      piStack_34[1] = piStack_34[1] + 1;
      UNLOCK();
    }
    uStack_18._0_4_ = pcVar3;
    uStack_18._4_4_ = piStack_34;
    uStack_8._0_1_ = 0x1a;
    FUN_005c15a0(&uStack_18);
    uStack_8._0_1_ = 0x1b;
    FUN_0098fc00(auStack_178,apppuStack_70,1);
    uStack_8._0_1_ = 0x1c;
    if (iStack_174 != 0) {
      (**(code **)(iStack_174 + 8))(auStack_170);
    }
    piVar12 = uStack_18._4_4_;
    uStack_8._0_1_ = 0x19;
    if (uStack_18._4_4_ != (int *)0x0) {
      LOCK();
      iVar4 = uStack_18._4_4_[1] + -1;
      uStack_18._4_4_[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*uStack_18._4_4_)();
        LOCK();
        piVar2 = piVar12 + 2;
        iVar4 = *piVar2 + -1;
        *piVar2 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar12 + 4))();
        }
      }
    }
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = 0;
    if (DAT_01d66660 == '\0') {
      FUN_005542c0("joinData",8);
      uStack_8._0_1_ = 0x21;
      iVar4 = FUN_005c4c00(auStack_30);
      uVar7 = FUN_0088cb40();
      *(undefined4 *)(iVar4 + 0x18) = uVar7;
      FUN_005c17a0(apppuStack_70);
      uStack_8._0_1_ = 0x19;
      FUN_005507b0();
      puVar10 = (undefined4 *)FUN_00ad5a70(auStack_90);
      puVar5 = puVar10 + 4;
      uStack_8._0_1_ = 0x22;
      if (0xf < (uint)puVar10[5]) {
        puVar10 = (undefined4 *)*puVar10;
      }
      ppppuVar11 = apppuStack_70;
      if (0xf < uStack_5c) {
        ppppuVar11 = (undefined4 ****)apppuStack_70[0];
      }
      uVar7 = FUN_01530cc0(auStack_a8,ppppuVar11,uStack_60,puVar10,*puVar5);
      uStack_8._0_1_ = 0x23;
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = 0;
      FUN_005542c0(&DAT_0194a144,4);
      uStack_8._0_1_ = 0x24;
      FUN_005c4c00(auStack_30);
      FUN_00632ce0(uVar7);
      FUN_005507b0();
      FUN_005507b0();
      uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
      FUN_005507b0();
      uVar7 = uStack_58;
    }
    else {
      FUN_005542c0("joinData",8);
      uVar7 = uStack_58;
      uStack_8._0_1_ = 0x1d;
      iVar4 = FUN_005c4c00(auStack_30);
      uVar9 = FUN_0088cb40();
      *(undefined4 *)(iVar4 + 0x18) = uVar9;
      FUN_005c17a0(apppuStack_70);
      uStack_8._0_1_ = 0x19;
      FUN_005507b0();
      puVar10 = (undefined4 *)FUN_00ad5a70(auStack_a8);
      puVar5 = puVar10 + 4;
      uStack_8._0_1_ = 0x1e;
      if (0xf < (uint)puVar10[5]) {
        puVar10 = (undefined4 *)*puVar10;
      }
      ppppuVar11 = apppuStack_70;
      if (0xf < uStack_5c) {
        ppppuVar11 = (undefined4 ****)apppuStack_70[0];
      }
      uVar9 = FUN_01530cc0(auStack_90,ppppuVar11,uStack_60,puVar10,*puVar5);
      uStack_8._0_1_ = 0x1f;
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = 0;
      FUN_005542c0(&DAT_0194a144,4);
      uStack_8._0_1_ = 0x20;
      FUN_005c4c00(auStack_30);
      FUN_00632ce0(uVar9);
      FUN_005507b0();
      FUN_005507b0();
      uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
      FUN_005507b0();
    }
    if (DAT_01d66660 == '\0') {
      if (param_6 != (int *)0x0) {
        LOCK();
        param_6[1] = param_6[1] + 1;
        UNLOCK();
      }
      uVar7 = FUN_00adb500(&uStack_18,param_5,param_6);
      FUN_005587e0(uVar7);
      FUN_00550b30();
      if (param_5 != 0) {
        uVar7 = FUN_00671a30(uStack_54);
        FUN_008a65e0(uVar7,0);
      }
      if (param_6 != (int *)0x0) {
        LOCK();
        param_6[1] = param_6[1] + 1;
        UNLOCK();
      }
      if (param_4 != (int *)0x0) {
        LOCK();
        param_4[1] = param_4[1] + 1;
        UNLOCK();
      }
      FUN_0092faa0(0,param_3,param_4,param_5,param_6);
      piVar12 = piStack_50;
      if (param_5 != 0) {
        FUN_008a65e0(0,0);
        piVar12 = piStack_50;
      }
    }
    else {
      if (param_6 != (int *)0x0) {
        LOCK();
        param_6[1] = param_6[1] + 1;
        UNLOCK();
      }
      FUN_00adb500(&iStack_40,param_5,param_6);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x25);
      if (iStack_40 != 0) {
        uVar9 = FUN_00671a30(uStack_54);
        FUN_008a65e0(uVar9,0);
      }
      piVar12 = piStack_50;
      if (iStack_3c != 0) {
        LOCK();
        *(int *)(iStack_3c + 4) = *(int *)(iStack_3c + 4) + 1;
        UNLOCK();
      }
      if (piStack_50 != (int *)0x0) {
        LOCK();
        piStack_50[1] = piStack_50[1] + 1;
        UNLOCK();
      }
      FUN_0092faa0(0,uVar7,piStack_50,iStack_40,iStack_3c);
      if (iStack_40 != 0) {
        FUN_008a65e0(0,0);
      }
      FUN_00550b30();
    }
    iVar4 = FUN_005507b0();
    piVar2 = piStack_44;
    if (piStack_44 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_44 + 1;
      iVar6 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        (**(code **)*piStack_44)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar6 = *piVar1;
        iVar4 = *piVar1;
        *piVar1 = iVar6 + -1;
        UNLOCK();
        if (iVar6 + -1 == 0) {
          iVar4 = (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_34;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_34 + 1;
      iVar6 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar6 = *piVar1;
        iVar4 = *piVar1;
        *piVar1 = iVar6 + -1;
        UNLOCK();
        if (iVar6 + -1 == 0) {
          iVar4 = (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
LAB_00acd824:
  if (piVar12 != (int *)0x0) {
    LOCK();
    piVar2 = piVar12 + 1;
    iVar6 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      (**(code **)*piVar12)();
      LOCK();
      piVar2 = piVar12 + 2;
      iVar6 = *piVar2;
      iVar4 = *piVar2;
      *piVar2 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        iVar4 = (**(code **)(*piVar12 + 4))();
      }
    }
  }
LAB_00acd845:
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar12 = param_2 + 1;
    iVar6 = *piVar12;
    iVar4 = *piVar12;
    *piVar12 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar12 = param_2 + 2;
      iVar6 = *piVar12;
      iVar4 = *piVar12;
      *piVar12 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        iVar4 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar12 = param_4 + 1;
    iVar6 = *piVar12;
    iVar4 = *piVar12;
    *piVar12 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar12 = param_4 + 2;
      iVar6 = *piVar12;
      iVar4 = *piVar12;
      *piVar12 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        iVar4 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar12 = param_6 + 1;
    iVar6 = *piVar12;
    iVar4 = *piVar12;
    *piVar12 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar12 = param_6 + 2;
      iVar6 = *piVar12;
      iVar4 = *piVar12;
      *piVar12 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        iVar4 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar12 = param_8 + 1;
    iVar6 = *piVar12;
    iVar4 = *piVar12;
    *piVar12 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar12 = param_8 + 2;
      iVar6 = *piVar12;
      iVar4 = *piVar12;
      *piVar12 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        iVar4 = (**(code **)(*param_8 + 4))();
      }
    }
  }
  if (param_10 != (int *)0x0) {
    LOCK();
    piVar12 = param_10 + 1;
    iVar6 = *piVar12;
    iVar4 = *piVar12;
    *piVar12 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      iVar4 = (**(code **)*param_10)();
      LOCK();
      piVar12 = param_10 + 2;
      iVar6 = *piVar12;
      *piVar12 = *piVar12 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        iVar4 = (**(code **)(*param_10 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 22304 ; VA 0x00acd920 ; FUN_00acd920 */

int FUN_00acd920(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0086f2f0(3,"SetTeleportGui should not be used on the server");
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 22305 ; VA 0x00acd990 ; FUN_00acd990 */

void FUN_00acd990(int param_1)

{
  int iVar1;
  uint uVar2;
  uint in_stack_00000018;
  int in_stack_00000020;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017e9460;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_0086f2f0(3,"SetTeleportSetting should not be used on the server");
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < in_stack_00000018) {
    uVar2 = in_stack_00000018 + 1;
    iVar1 = param_1;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_1 + -4);
      uVar2 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  uStack_8 = 2;
  if (in_stack_00000020 != 0) {
    (**(code **)(in_stack_00000020 + 8))(&stack0x00000024);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22306 ; VA 0x00acda40 ; FUN_00acda40 */

undefined4 *
FUN_00acda40(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,undefined4 *param_6)

{
  int *piVar1;
  int iVar2;
  int *in_stack_000000e8;
  undefined uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017e94a3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_000000e8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_000000e8[1] = in_stack_000000e8[1] + 1;
    UNLOCK();
  }
  uStack_8 = 3;
  uStack_7 = 0;
  if (param_6 != (undefined4 *)0x0) {
    (*(code *)*param_6)();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 5;
  uVar3 = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  _uStack_8 = CONCAT31(uStack_7,2);
  FUN_00acfcf0(param_1,param_2,uVar3);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  _uStack_8 = CONCAT31(uStack_7,6);
  if (param_6 != (undefined4 *)0x0) {
    param_6 = (undefined4 *)(*(code *)param_6[2])();
  }
  if (in_stack_000000e8 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_000000e8 + 1;
    iVar2 = *piVar1;
    param_6 = (undefined4 *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_6 = (undefined4 *)(**(code **)*in_stack_000000e8)();
      LOCK();
      piVar1 = in_stack_000000e8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_6 = (undefined4 *)(**(code **)(*in_stack_000000e8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_6;
}



/* FUNCTION 22307 ; VA 0x00acdbd0 ; FUN_00acdbd0 */

void FUN_00acdbd0(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 ****ppppuVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int aiStack_74 [5];
  uint uStack_60;
  undefined auStack_5c [16];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 ***apppuStack_44 [4];
  int iStack_34;
  uint uStack_30;
  uint auStack_2c [4];
  int iStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e9529;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  if (param_1 == 1) {
    iStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    ExceptionList = &pvStack_10;
    FUN_005542c0("TeleportFailedGameClient",0x18);
    uStack_8 = 0;
    FUN_008783f0(auStack_2c,1,0);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar5 = auStack_2c[0];
      if (0xfff < uVar4) {
        uVar5 = *(uint *)(auStack_2c[0] - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar4);
    }
    uVar1 = FUN_01530500(aiStack_74);
    uStack_8 = 1;
    uVar1 = FUN_00558d90(auStack_2c,"TeleportFailedClientOs_",uVar1);
    uStack_8._0_1_ = 2;
    FUN_008783f0(uVar1,1,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar5 = auStack_2c[0];
      if (0xfff < uVar4) {
        uVar5 = *(uint *)(auStack_2c[0] - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar4);
    }
    iStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    uStack_8 = 0xffffffff;
    if (0xf < uStack_60) {
      uVar5 = uStack_60 + 1;
      iVar3 = aiStack_74[0];
      if (0xfff < uVar5) {
        iVar3 = *(int *)(aiStack_74[0] + -4);
        uVar5 = uStack_60 + 0x24;
        if (0x1f < (aiStack_74[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar5);
    }
    FUN_015301f0(apppuStack_44);
    uStack_8 = 3;
    if (iStack_34 == 0) {
      iStack_1c = iStack_34;
      uStack_18 = 0xf;
      auStack_2c[0] = (uint)auStack_2c[0]._1_3_ << 8;
      FUN_005542c0("TeleportFailedClientNetworkType_Unknown",0x27);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
    }
    else {
      uStack_8 = 5;
      iStack_1c = 0;
      uStack_18 = 0xf;
      auStack_2c[0] = (uint)auStack_2c[0]._1_3_ << 8;
      uStack_14 = 1;
      FUN_0058a190(iStack_34 + 0x20);
      FUN_00554150("TeleportFailedClientNetworkType_",0x20);
      ppppuVar2 = apppuStack_44;
      if (0xf < uStack_30) {
        ppppuVar2 = (undefined4 ****)apppuStack_44[0];
      }
      FUN_00554150(ppppuVar2,iStack_34);
    }
    FUN_008783f0(auStack_2c,1,0);
    FUN_005507b0();
    uStack_8 = 0xffffffff;
    if (0xf < uStack_30) {
      uVar5 = uStack_30 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_44[0];
      if (0xfff < uVar5) {
        ppppuVar2 = (undefined4 ****)apppuStack_44[0][-1];
        uVar5 = uStack_30 + 0x24;
        if (0x1f < (uint)((int)apppuStack_44[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar2,uVar5);
    }
  }
  else {
    iStack_34 = 0;
    uStack_30 = 0xf;
    apppuStack_44[0] = (undefined4 ***)((uint)apppuStack_44[0] & 0xffffff00);
    if (param_1 == 2) {
      ExceptionList = &pvStack_10;
      FUN_005542c0("TeleportFailedGameServer",0x18);
      uStack_8 = 6;
    }
    else {
      ExceptionList = &pvStack_10;
      FUN_005542c0("TeleportFailedUnknownSystem",0x1b);
      uStack_8 = 7;
    }
    FUN_008783f0(apppuStack_44,1,0);
    uStack_8 = 0xffffffff;
    FUN_005507b0();
  }
  switch(param_2) {
  case 0:
    iStack_34 = 0;
    uStack_30 = 0xf;
    apppuStack_44[0] = (undefined4 ***)((uint)apppuStack_44[0]._1_3_ << 8);
    FUN_005542c0("TeleportFailedEvent-TeleportToSpawnByName",0x29);
    uStack_8 = 8;
    break;
  case 1:
    iStack_34 = 0;
    uStack_30 = 0xf;
    apppuStack_44[0] = (undefined4 ***)((uint)apppuStack_44[0]._1_3_ << 8);
    FUN_005542c0("TeleportFailedEvent-TeleportToPlaceInstance",0x2b);
    uStack_8 = 9;
    break;
  case 2:
    iStack_34 = 0;
    uStack_30 = 0xf;
    apppuStack_44[0] = (undefined4 ***)((uint)apppuStack_44[0]._1_3_ << 8);
    FUN_005542c0("TeleportFailedEvent-TeleportToPrivateServer",0x2b);
    uStack_8 = 10;
    break;
  case 3:
    iStack_34 = 0;
    uStack_30 = 0xf;
    apppuStack_44[0] = (undefined4 ***)((uint)apppuStack_44[0]._1_3_ << 8);
    FUN_005542c0("TeleportFailedEvent-TeleportPartyAsync",0x26);
    uStack_8 = 0xb;
    break;
  case 4:
    uStack_4c = 0;
    uStack_48 = 0xf;
    auStack_5c[0] = 0;
    FUN_005542c0("TeleportFailedEvent-Unknown",0x1b);
    uStack_8 = 0xc;
    FUN_008783f0(auStack_5c,1,0);
    goto LAB_00acdf74;
  default:
    goto switchD_00acde77_caseD_5;
  }
  FUN_008783f0(apppuStack_44,1,0);
LAB_00acdf74:
  FUN_005507b0();
switchD_00acde77_caseD_5:
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22308 ; VA 0x00acdfc0 ; FUN_00acdfc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __thiscall FUN_00acdfc0(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined uVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 uVar7;
  uint uVar8;
  uint uVar9;
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  undefined4 uStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  int iStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017e9580;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff84;
  uStack_8 = 1;
  uStack_7 = 0;
  LOCK();
  ExceptionList = &pvStack_10;
  *(undefined *)(param_1 + 0x58) = 1;
  UNLOCK();
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  iStack_1c = param_1;
  FUN_005542c0("spawnName",9);
  _uStack_8 = CONCAT31(uStack_7,2);
  FUN_0091d3d0(auStack_58);
  puVar5 = (undefined4 *)FUN_00563690(auStack_70);
  if (puVar5 != (undefined4 *)&DAT_01d66610) {
    FUN_005507b0();
    _DAT_01d66610 = *puVar5;
    uRam01d66614 = puVar5[1];
    uRam01d66618 = puVar5[2];
    uRam01d6661c = puVar5[3];
    _DAT_01d66620 = *(undefined8 *)(puVar5 + 4);
    puVar5[4] = 0;
    puVar5[5] = 0xf;
    *(undefined *)puVar5 = 0;
  }
  if (0xf < uStack_5c) {
    uVar9 = uStack_5c + 1;
    uVar8 = auStack_70[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_70[0] - 4);
      uVar9 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  uStack_8 = 1;
  if (0xf < uStack_44) {
    uVar9 = uStack_44 + 1;
    uVar8 = auStack_58[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_58[0] - 4);
      uVar9 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0("TeleportThreadImpl-InvokingTeleportThread",0x29);
  uStack_8 = 3;
  FUN_008783f0(auStack_58,1,0);
  uStack_8 = 1;
  uVar4 = uStack_8;
  uStack_8 = 1;
  if (0xf < uStack_44) {
    uVar9 = uStack_44 + 1;
    uVar8 = auStack_58[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_58[0] - 4);
      uVar9 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar8) - 4) {
        uStack_8 = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_18 = param_2;
  uStack_34 = param_2;
  piStack_30 = param_3;
  uStack_8 = 4;
  FUN_0060dcd0(&uStack_2c,param_1);
  piVar2 = piStack_28;
  uVar7 = uStack_2c;
  uStack_8 = 6;
  if (DAT_01eeb550 != 0) {
    uStack_34 = 0;
    piStack_30 = (int *)0x0;
    uStack_2c = 0;
    piStack_28 = (int *)0x0;
    iVar6 = (**(code **)((DAT_01eeb550 & 0xfffffffe) + 4))
                      (&DAT_01eeb558,uVar7,piVar2,uStack_18,param_3,&DAT_018bc9b8);
    piVar2 = piStack_28;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_28 + 1;
      iVar3 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        iVar6 = *piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          iVar6 = (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = DAT_01eeb584;
    DAT_01eeb580 = 0;
    DAT_01eeb584 = (int *)0x0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      piVar1 = piVar2 + 1;
      iVar3 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        iVar6 = *piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          iVar6 = (**(code **)(*piVar2 + 4))();
        }
      }
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      piVar2 = param_3 + 1;
      iVar3 = *piVar2;
      iVar6 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar6 = (**(code **)*param_3)();
        LOCK();
        piVar2 = param_3 + 2;
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          iVar6 = (**(code **)(*param_3 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return iVar6;
  }
  uVar7 = FUN_0054fda0();
  _uStack_8 = CONCAT31(uStack_7,7);
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar7);
}



/* FUNCTION 22309 ; VA 0x00ace294 ; Catch@00ace294 */

void Catch_00ace294(void)

{
  int *piVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  FUN_005c4bf0(0);
  piVar1 = *(int **)(unaff_EBP + -0x20);
  uVar2 = (**(code **)(*piVar1 + 4))();
  uVar2 = FUN_01675640(unaff_EBP + -0x6c,"Unknown exception: %s",uVar2);
  *(undefined *)(unaff_EBP + -4) = 9;
  FUN_00adac20(1,uVar2,unaff_EBP + 8);
  *(undefined *)(unaff_EBP + -4) = 8;
  FUN_005507b0();
  FUN_0054fe90(piVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(unaff_EBP + -0x3c,&DAT_01c243ac);
}



/* FUNCTION 22310 ; VA 0x00ace320 ; FUN_00ace320 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __thiscall FUN_00ace320(int param_1,byte *param_2,int *param_3,int param_4,int *param_5)

{
  int *piVar1;
  int *piVar2;
  undefined *puVar3;
  void *pvVar4;
  char cVar5;
  int iVar6;
  int iVar7;
  undefined4 uVar8;
  uint uVar9;
  uint uVar10;
  byte *pbVar11;
  undefined8 uVar12;
  char *pcVar13;
  undefined auStack_2a8 [4];
  int iStack_2a4;
  undefined auStack_2a0 [200];
  undefined auStack_1d8 [24];
  undefined auStack_1c0 [24];
  undefined auStack_1a8 [16];
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined auStack_190 [16];
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined auStack_178 [16];
  undefined4 uStack_168;
  undefined4 uStack_164;
  undefined auStack_160 [16];
  undefined4 uStack_150;
  undefined4 uStack_14c;
  uint uStack_148;
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined auStack_130 [16];
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined auStack_118 [16];
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined auStack_100 [4];
  int *piStack_fc;
  undefined auStack_f8 [16];
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint auStack_e0 [4];
  undefined4 uStack_d0;
  uint uStack_cc;
  undefined4 uStack_c8;
  int *piStack_c4;
  byte *pbStack_c0;
  int *piStack_bc;
  undefined4 uStack_b8;
  int *piStack_b4;
  byte *pbStack_b0;
  int *piStack_ac;
  uint uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined8 uStack_98;
  uint auStack_90 [4];
  undefined4 uStack_80;
  uint uStack_7c;
  uint auStack_78 [4];
  undefined4 uStack_68;
  uint uStack_64;
  undefined4 uStack_60;
  int *piStack_5c;
  int iStack_58;
  int *piStack_54;
  uint auStack_50 [2];
  uint uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  uint uStack_3c;
  uint uStack_38;
  int iStack_34;
  int *piStack_30;
  int iStack_2c;
  undefined8 uStack_28;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar7 = DAT_01eeb4ec;
  puStack_c = &LAB_017e9647;
  pvStack_10 = ExceptionList;
  uStack_38 = 0;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  if ((DAT_01d66698 == '\0') ||
     (ExceptionList = &pvStack_10, iVar6 = FUN_0171d737(), iVar7 <= iVar6 % 100)) {
    if (*(char *)(iStack_18 + 0x58) != '\0') {
      uStack_120 = 0;
      uStack_11c = 0xf;
      auStack_130[0] = 0;
      FUN_005542c0("The previous teleport is in processing",0x26);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      FUN_00adac20(7,auStack_130,&param_2);
      iVar7 = FUN_005507b0();
      goto LAB_00acedc2;
    }
  }
  else {
    LOCK();
    cVar5 = *(char *)(iStack_18 + 0x58);
    if (cVar5 == '\0') {
      *(char *)(iStack_18 + 0x58) = '\x01';
      cVar5 = '\0';
    }
    UNLOCK();
    if (cVar5 != '\0') {
      uStack_108 = 0;
      uStack_104 = 0xf;
      auStack_118[0] = 0;
      FUN_005542c0("The previous teleport is in processing",0x26);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_00adac20(7,auStack_118,&param_2);
      iVar7 = FUN_005507b0();
      goto LAB_00acedc2;
    }
  }
  uStack_d0 = 0;
  uStack_cc = 0xf;
  auStack_e0[0] = auStack_e0[0] & 0xffffff00;
  FUN_005542c0("teleportData",0xc);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  iVar7 = FUN_0091d3d0(auStack_e0);
  DAT_01eeb588 = *(undefined4 *)(iVar7 + 0x18);
  piVar1 = (int *)(iVar7 + 0x1c);
  if (piVar1 != &DAT_01eeb58c) {
    if (DAT_01eeb58c != 0) {
      (**(code **)(DAT_01eeb58c + 8))(&DAT_01eeb590);
      DAT_01eeb58c = 0;
    }
    if ((undefined4 *)*piVar1 != (undefined4 *)0x0) {
      (**(code **)*piVar1)(iVar7 + 0x20,&DAT_01eeb590);
      DAT_01eeb58c = *piVar1;
    }
  }
  uStack_8._0_1_ = 1;
  if (0xf < uStack_cc) {
    uVar10 = uStack_cc + 1;
    uVar9 = auStack_e0[0];
    if (0xfff < uVar10) {
      uVar9 = *(uint *)(auStack_e0[0] - 4);
      uVar10 = uStack_cc + 0x24;
      if (0x1f < (auStack_e0[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar10);
  }
  FUN_005542c0(&DAT_018bc9b8,0);
  FUN_00888650(&iStack_34);
  pbVar11 = param_2;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  FUN_005542c0(&DAT_0194a144,4);
  pbVar11 = pbVar11 + *pbVar11 + 1;
  uVar8 = FUN_005702d0(auStack_50);
  FUN_00562fc0((int)&uStack_28 + 4,uVar8,auStack_50,
               -(uint)(pbVar11 != (byte *)0x0) & (uint)(pbVar11 + 1));
  if (0xf < uStack_3c) {
    uVar10 = uStack_3c + 1;
    uVar9 = auStack_50[0];
    if (0xfff < uVar10) {
      uVar9 = *(uint *)(auStack_50[0] - 4);
      uVar10 = uStack_3c + 0x24;
      if (0x1f < (auStack_50[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar10);
  }
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  if ((uStack_28._4_4_ != 0) &&
     (iVar7 = *(int *)(uStack_28._4_4_ + 0x20), iVar6 = FUN_0088cb40(), iVar7 == iVar6)) {
    FUN_00563690(&uStack_148);
    uStack_48 = uStack_148;
    uStack_148 = uStack_148 & 0xffffff00;
    uStack_44 = uStack_144;
    uStack_40 = uStack_140;
    uStack_3c = uStack_13c;
    uStack_a8 = uStack_48;
    uStack_a4 = uStack_144;
    uStack_a0 = uStack_140;
    uStack_9c = uStack_13c;
    uStack_98 = CONCAT44(uStack_134,uStack_138);
    uStack_138 = 0;
    uStack_134 = 0xf;
    uStack_8._0_1_ = 6;
    uStack_150 = 0;
    uStack_14c = 0xf;
    auStack_160[0] = 0;
    uStack_28 = uStack_98;
    FUN_005542c0(&DAT_0194a144,4);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    iVar6 = FUN_005c4c00(auStack_160);
    uVar8 = FUN_0088cf00();
    pvVar4 = ThreadLocalStoragePointer;
    iVar7 = _tls_index;
    *(undefined4 *)(iVar6 + 0x18) = uVar8;
    if ((*(int *)(*(int *)((int)pvVar4 + iVar7 * 4) + 0x34) < DAT_01ead2d8) &&
       (FUN_016f3809(&DAT_01ead2d8), DAT_01ead2d8 == -1)) {
      _DAT_01ead2cc = FUN_005c65f0;
      _DAT_01ead2d0 = FUN_005c93a0;
      _DAT_01ead2d4 = FUN_005c77b0;
      FUN_016f37bf(&DAT_01ead2d8);
    }
    puVar3 = *(undefined **)(iVar6 + 0x1c);
    if (puVar3 == &DAT_01ead2cc) {
      if ((uint *)(iVar6 + 0x20) != &uStack_a8) {
        FUN_005507b0();
        *(uint *)(iVar6 + 0x20) = uStack_48;
        *(undefined4 *)(iVar6 + 0x24) = uStack_44;
        *(undefined4 *)(iVar6 + 0x28) = uStack_40;
        *(uint *)(iVar6 + 0x2c) = uStack_3c;
        *(undefined8 *)(iVar6 + 0x30) = uStack_28;
        goto LAB_00ace710;
      }
    }
    else {
      if (puVar3 != (undefined *)0x0) {
        (**(code **)(puVar3 + 8))(iVar6 + 0x20);
      }
      *(undefined4 *)(iVar6 + 0x30) = 0;
      *(undefined4 *)(iVar6 + 0x34) = 0;
      *(uint *)(iVar6 + 0x20) = uStack_48;
      *(undefined4 *)(iVar6 + 0x24) = uStack_44;
      *(undefined4 *)(iVar6 + 0x28) = uStack_40;
      *(uint *)(iVar6 + 0x2c) = uStack_3c;
      *(undefined8 *)(iVar6 + 0x30) = uStack_28;
      *(undefined **)(iVar6 + 0x1c) = &DAT_01ead2cc;
LAB_00ace710:
      uStack_a8 = uStack_a8 & 0xffffff00;
      uStack_98 = 0xf00000000;
    }
    FUN_005507b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_005507b0();
  }
  pbVar11 = param_2;
  uStack_68 = 0;
  uStack_64 = 0xf;
  auStack_78[0] = auStack_78[0] & 0xffffff00;
  FUN_005542c0("partyData",9);
  pbVar11 = pbVar11 + *pbVar11 + 1;
  uVar8 = FUN_005702d0(auStack_78);
  FUN_00562fc0(&iStack_2c,uVar8,auStack_78,-(uint)(pbVar11 != (byte *)0x0) & (uint)(pbVar11 + 1));
  if (0xf < uStack_64) {
    uVar10 = uStack_64 + 1;
    uVar9 = auStack_78[0];
    if (0xfff < uVar10) {
      uVar9 = *(uint *)(auStack_78[0] - 4);
      uVar10 = uStack_64 + 0x24;
      if (0x1f < (auStack_78[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar10);
  }
  uStack_68 = 0;
  uStack_64 = 0xf;
  auStack_78[0] = auStack_78[0] & 0xffffff00;
  if ((iStack_2c != 0) &&
     (iVar7 = *(int *)(iStack_2c + 0x20), iVar6 = FUN_0088cb40(), iVar7 == iVar6)) {
    uVar8 = FUN_00563690(auStack_1c0);
    uStack_8._0_1_ = 8;
    uStack_168 = 0;
    uStack_164 = 0xf;
    auStack_178[0] = 0;
    FUN_005542c0("partyData",9);
    uStack_8._0_1_ = 9;
    FUN_005c4c00(auStack_178);
    FUN_00632ce0(uVar8);
    FUN_005507b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_005507b0();
  }
  pbVar11 = param_2;
  uStack_80 = 0;
  uStack_7c = 0xf;
  auStack_90[0] = auStack_90[0] & 0xffffff00;
  FUN_005542c0("joinData",8);
  pbVar11 = pbVar11 + *pbVar11 + 1;
  uVar8 = FUN_005702d0(auStack_90);
  FUN_00562fc0(&iStack_1c,uVar8,auStack_90,-(uint)(pbVar11 != (byte *)0x0) & (uint)(pbVar11 + 1));
  if (0xf < uStack_7c) {
    uVar10 = uStack_7c + 1;
    uVar9 = auStack_90[0];
    if (0xfff < uVar10) {
      uVar9 = *(uint *)(auStack_90[0] - 4);
      uVar10 = uStack_7c + 0x24;
      if (0x1f < (auStack_90[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar10);
  }
  uStack_80 = 0;
  uStack_7c = 0xf;
  auStack_90[0] = auStack_90[0] & 0xffffff00;
  if ((iStack_1c != 0) &&
     (iVar7 = *(int *)(iStack_1c + 0x20), iVar6 = FUN_0088cb40(), iVar7 == iVar6)) {
    uVar8 = FUN_00563690(auStack_1d8);
    uStack_8._0_1_ = 10;
    uStack_180 = 0;
    uStack_17c = 0xf;
    auStack_190[0] = 0;
    FUN_005542c0("joinData",8);
    uStack_8._0_1_ = 0xb;
    FUN_005c4c00(auStack_190);
    FUN_00632ce0(uVar8);
    FUN_005507b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_005507b0();
  }
  if (*(int *)(iStack_34 + 8) != 0) {
    if (piStack_30 != (int *)0x0) {
      LOCK();
      piStack_30[1] = piStack_30[1] + 1;
      UNLOCK();
    }
    iStack_58 = iStack_34;
    piStack_54 = piStack_30;
    uStack_8._0_1_ = 0xc;
    FUN_005c15a0(&iStack_58);
    uStack_8._0_1_ = 0xd;
    cStack_11 = FUN_0098fc00(auStack_2a8,&DAT_01d66628,1);
    uStack_8._0_1_ = 0xe;
    if (iStack_2a4 != 0) {
      (**(code **)(iStack_2a4 + 8))(auStack_2a0);
    }
    piVar1 = piStack_54;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (piStack_54 != (int *)0x0) {
      LOCK();
      iVar7 = piStack_54[1] + -1;
      piStack_54[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_54)();
        LOCK();
        piVar2 = piVar1 + 2;
        iVar7 = *piVar2 + -1;
        *piVar2 = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    if (cStack_11 == '\0') {
      if (DAT_01eeb4f0 != '\0') {
        pcVar13 = "joinData writeJSON failed";
        goto LAB_00acea62;
      }
    }
    else if (DAT_01eeb4f0 != '\0') {
      pcVar13 = "Save joinData";
LAB_00acea62:
      FUN_016774b0(DAT_01eeb4f0,pcVar13,0);
    }
  }
  piVar1 = param_5;
  if (DAT_01eeb580 != 0) {
    if (DAT_01eeb584 != (int *)0x0) {
      LOCK();
      DAT_01eeb584[1] = DAT_01eeb584[1] + 1;
      UNLOCK();
    }
    param_4 = DAT_01eeb580;
    param_5 = DAT_01eeb584;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar7 = piVar1[1] + -1;
      piVar1[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar7 = piVar1[2] + -1;
        piVar1[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
  }
  if (param_4 != 0) {
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    uVar8 = FUN_00adb500(auStack_100,param_4,param_5);
    FUN_005587e0(uVar8);
    if (piStack_fc != (int *)0x0) {
      LOCK();
      iVar7 = piStack_fc[1] + -1;
      piStack_fc[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_fc)();
        LOCK();
        iVar7 = piStack_fc[2] + -1;
        piStack_fc[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piStack_fc + 4))();
        }
      }
    }
    if (DAT_01eeb578 != 0) {
      FUN_008a65e0(0,0);
    }
  }
  if ((DAT_01eeb4f8 != (int *)0x0) && (cVar5 = (**(code **)(*DAT_01eeb4f8 + 8))(), cVar5 == '\0')) {
    iVar7 = FUN_00550b30();
    goto LAB_00acedc2;
  }
  pbVar11 = param_2;
  if (DAT_01d66668 == '\0') {
LAB_00acebe7:
    cStack_11 = '\0';
  }
  else {
    uStack_e8 = 0;
    uStack_e4 = 0xf;
    auStack_f8[0] = 0;
    FUN_005542c0("placeId",7);
    pbVar11 = pbVar11 + *pbVar11 + 1;
    uStack_38 = 1;
    uVar8 = FUN_005702d0(auStack_f8);
    FUN_00562fc0(&iStack_20,uVar8,auStack_f8,-(uint)(pbVar11 != (byte *)0x0) & (uint)(pbVar11 + 1));
    cStack_11 = '\x01';
    if (iStack_20 == 0) goto LAB_00acebe7;
  }
  if ((uStack_38 & 1) != 0) {
    FUN_005507b0();
  }
  iVar7 = iStack_18;
  if (cStack_11 == '\0') {
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    iVar7 = FUN_00acdfc0(param_2,param_3);
  }
  else {
    iStack_2c = FUN_00672490(iStack_18);
    uStack_198 = 0;
    uStack_194 = 0xf;
    auStack_1a8[0] = 0;
    FUN_005542c0("placeId",7);
    uStack_8._0_1_ = 0xf;
    FUN_0091d3d0(auStack_1a8);
    uVar12 = FUN_00563790();
    iStack_20 = (int)((ulonglong)uVar12 >> 0x20);
    iStack_1c = (int)uVar12;
    uStack_8._0_1_ = 5;
    FUN_005507b0();
    FUN_0060e0c0(&uStack_60,iVar7);
    piVar1 = piStack_5c;
    if (piStack_5c != (int *)0x0) {
      LOCK();
      piStack_5c[2] = piStack_5c[2] + 1;
      UNLOCK();
    }
    uStack_c8 = uStack_60;
    piStack_c4 = piStack_5c;
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    pbStack_c0 = param_2;
    piStack_bc = param_3;
    if (piStack_5c != (int *)0x0) {
      LOCK();
      piStack_5c[2] = piStack_5c[2] + 1;
      UNLOCK();
    }
    uStack_b8 = uStack_60;
    piStack_b4 = piStack_5c;
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    pbStack_b0 = param_2;
    piStack_ac = param_3;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
    FUN_00ac3e80(&uStack_b8);
    FUN_00abfca0();
    FUN_00ac3e80(&uStack_c8);
    FUN_00abf9e0();
    FUN_00bfcc70(iStack_1c,iStack_20);
    FUN_0096bfc0();
    iVar7 = FUN_0096bfc0();
    if (piVar1 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_5c + 2;
      iVar6 = *piVar1;
      iVar7 = *piVar1;
      *piVar1 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        iVar7 = (**(code **)(*piStack_5c + 4))();
      }
    }
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_30 + 1;
    iVar6 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar1 = piStack_30 + 2;
      iVar6 = *piVar1;
      iVar7 = *piVar1;
      *piVar1 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        iVar7 = (**(code **)(*piStack_30 + 4))();
      }
    }
  }
LAB_00acedc2:
  piVar1 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 1;
    iVar6 = *piVar2;
    iVar7 = *piVar2;
    *piVar2 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar6 = *piVar2;
      iVar7 = *piVar2;
      *piVar2 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        iVar7 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar2 = param_5 + 1;
    iVar6 = *piVar2;
    iVar7 = *piVar2;
    *piVar2 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      iVar7 = (**(code **)*param_5)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar6 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        iVar7 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 22311 ; VA 0x00acee80 ; FUN_00acee80 */

int FUN_00acee80(undefined4 param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  uint in_stack_0000002c;
  undefined4 in_stack_0000003c;
  uint in_stack_00000040;
  int in_stack_00000048;
  undefined4 in_stack_00000114;
  int *in_stack_00000118;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e968b;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  if (in_stack_0000001c == 0) {
    ExceptionList = &pvStack_10;
    FUN_0086ed30(2,&DAT_01d666b0,6);
    FUN_00ada860(2,&DAT_01d666b0,1);
  }
  else {
    ExceptionList = &pvStack_10;
    if (in_stack_00000118 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      in_stack_00000118[1] = in_stack_00000118[1] + 1;
      UNLOCK();
    }
    if (in_stack_00000028 != (int *)0x0) {
      LOCK();
      in_stack_00000028[1] = in_stack_00000028[1] + 1;
      UNLOCK();
    }
    FUN_00adcb50(param_1,param_2,&param_3,in_stack_00000024,in_stack_00000028,&stack0x0000002c,
                 &stack0x00000044,in_stack_00000114,in_stack_00000118,1,1);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (0xf < in_stack_00000020) {
    uVar6 = in_stack_00000020 + 1;
    uVar5 = param_3;
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(param_3 - 4);
      uVar6 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  piVar3 = in_stack_00000028;
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    iVar4 = in_stack_00000028[1] + -1;
    in_stack_00000028[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1 + -1;
      *piVar1 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000040) {
    uVar6 = in_stack_00000040 + 1;
    uVar5 = in_stack_0000002c;
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(in_stack_0000002c - 4);
      uVar6 = in_stack_00000040 + 0x24;
      if (0x1f < (in_stack_0000002c - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  in_stack_0000003c = 0;
  in_stack_00000040 = 0xf;
  in_stack_0000002c = in_stack_0000002c & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  iVar4 = in_stack_00000048;
  if (in_stack_00000048 != 0) {
    iVar4 = (**(code **)(in_stack_00000048 + 8))(&stack0x0000004c);
  }
  piVar3 = in_stack_00000118;
  if (in_stack_00000118 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000118 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*in_stack_00000118)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 22312 ; VA 0x00acf060 ; FUN_00acf060 */

undefined4 * FUN_00acf060(undefined4 param_1,undefined4 *param_2,undefined4 *****param_3)

{
  int *piVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  undefined *puVar6;
  undefined **ppuVar7;
  undefined4 uVar8;
  int iVar9;
  undefined **ppuVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  uint uVar13;
  undefined4 ****ppppuVar14;
  undefined4 *****pppppuVar15;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 *in_stack_00000024;
  int *in_stack_00000028;
  undefined4 *****in_stack_0000002c;
  undefined4 in_stack_0000003c;
  uint in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined4 *in_stack_00000048;
  undefined4 in_stack_00000114;
  int *in_stack_00000118;
  int *piVar16;
  int *piVar17;
  undefined4 uVar18;
  undefined4 uStack_a1c;
  undefined *puStack_a18;
  undefined auStack_a14 [24];
  undefined4 uStack_9fc;
  undefined4 uStack_9f8;
  undefined4 uStack_9f4;
  undefined4 uStack_9f0;
  undefined4 uStack_9ec;
  int iStack_9e8;
  undefined4 *puStack_9e4;
  int *piStack_9e0;
  undefined4 uStack_9dc;
  int *piStack_9d8;
  undefined4 ****ppppuStack_9d4;
  undefined4 auStack_9d0 [3];
  undefined4 uStack_9c4;
  char *pcStack_9c0;
  uint *puStack_9bc;
  undefined8 uStack_9b8;
  char acStack_9a8 [2064];
  undefined auStack_198 [160];
  code *pcStack_f8;
  undefined4 uStack_f4;
  undefined auStack_f0 [24];
  code *pcStack_d8;
  undefined4 uStack_d4;
  undefined auStack_d0 [24];
  code *pcStack_b8;
  undefined4 uStack_b4;
  undefined auStack_b0 [24];
  code *pcStack_98;
  undefined4 uStack_94;
  undefined auStack_90 [24];
  undefined *puStack_78;
  int iStack_74;
  code *pcStack_70;
  undefined4 uStack_6c;
  uint auStack_68 [4];
  undefined4 uStack_58;
  uint uStack_54;
  int iStack_50;
  undefined *puStack_4c;
  int iStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  code *pcStack_38;
  undefined4 uStack_34;
  undefined4 ****appppuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e9782;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  uStack_9b8._0_4_ = (undefined **)0xacf092;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_008f7870();
  if (iVar4 != 0) {
    uStack_9b8._4_4_ = *(char **)(iVar4 + 0x4a0);
    uStack_9b8._0_4_ = (undefined **)0x2;
    puStack_9bc = (uint *)0xacf0a6;
    FUN_00acc7f0();
  }
  uStack_9b8._0_4_ = (undefined **)0xacf0af;
  cVar3 = FUN_008b9b00();
  if (cVar3 == '\0') {
    uStack_9b8._4_4_ = (char *)0x6;
    uStack_9b8._0_4_ = (undefined **)0x194a4f0;
    puStack_9bc = (uint *)0x3;
    pcStack_9c0 = (char *)0xacfb2c;
    FUN_0086edd0();
    uStack_20 = 0;
    uStack_1c = 0xf;
    appppuStack_30[0] = (undefined4 ****)((uint)appppuStack_30[0] & 0xffffff00);
    uStack_9b8._4_4_ = (char *)0x3a;
    uStack_9b8._0_4_ = (undefined **)0x194a53c;
    puStack_9bc = (uint *)0xacfb50;
    FUN_005542c0();
    uStack_9b8._4_4_ = (char *)0x2;
    uStack_9b8._0_4_ = (undefined **)appppuStack_30;
    uStack_8._0_1_ = 0x19;
    puStack_9bc = (uint *)0x1;
    pcStack_9c0 = (char *)0xacfb63;
    FUN_00ada860();
    uStack_8._0_1_ = 4;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 4;
    if (0xf < uStack_1c) {
      uStack_9b8._4_4_ = (char *)(uStack_1c + 1);
      pppppuVar15 = (undefined4 *****)appppuStack_30[0];
      if (0xfff < uStack_9b8._4_4_) {
        pppppuVar15 = (undefined4 *****)appppuStack_30[0][-1];
        uStack_9b8._4_4_ = (char *)(uStack_1c + 0x24);
        if (0x1f < (uint)((int)appppuStack_30[0] + (-4 - (int)pppppuVar15))) {
                    /* WARNING: Subroutine does not return */
          uStack_9b8._4_4_ = (char *)0xacfcdd;
          uStack_8._0_1_ = uVar2;
          FUN_017167a3();
        }
      }
      puStack_9bc = (uint *)0xacfb98;
      uStack_9b8._0_4_ = (undefined **)pppppuVar15;
      FUN_01674ea0();
    }
  }
  else {
    uStack_9b8._4_4_ = (char *)0x1;
    uStack_9b8._0_4_ = (undefined **)0x3;
    puStack_9bc = (uint *)0xacf0cc;
    FUN_00565940();
    uStack_8._0_1_ = 5;
    cStack_11 = '\0';
    puVar11 = (undefined4 *)*in_stack_00000024;
    if (puVar11 != (undefined4 *)in_stack_00000024[1]) {
      do {
        puStack_18 = (undefined4 *)*puVar11;
        if (puStack_18 != (undefined4 *)0x0) {
          iVar4 = puStack_18[3];
          uStack_9b8._4_4_ = (char *)0xacf0f3;
          iVar5 = FUN_00913630();
          puVar12 = (undefined4 *)0x0;
          if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
              (uint)*(ushort *)(iVar5 + 0x1da)) {
            puVar12 = puStack_18;
          }
          puStack_18 = puVar12;
          if (puVar12 != (undefined4 *)0x0) {
            uStack_9b8._0_4_ = (undefined **)&DAT_0191bfa0;
            if (cStack_11 == '\0') {
              uStack_9b8._0_4_ = (undefined **)&DAT_018bc9b8;
            }
            uStack_9b8._4_4_ = "playerIds=";
            puStack_9bc = (uint *)auStack_198;
            pcStack_9c0 = (char *)0xacf13c;
            uStack_9b8._0_4_ = (undefined **)FUN_00558890();
            puStack_9bc = (uint *)0xacf145;
            FUN_00558890();
            uStack_9b8._4_4_ = (char *)0xacf152;
            uStack_9b8 = FUN_00928340();
            puStack_9bc = (uint *)0xacf15b;
            FUN_00872bd0();
            cStack_11 = '\x01';
          }
        }
        puVar11 = puVar11 + 2;
      } while (puVar11 != (undefined4 *)in_stack_00000024[1]);
    }
    uStack_9b8._4_4_ = (char *)0x800;
    puStack_9bc = (uint *)acStack_9a8;
    uStack_9b8._0_4_ = (undefined **)0x0;
    pcStack_9c0 = (char *)0xacf181;
    FUN_0170d1f0();
    uStack_9b8._0_4_ = (undefined **)&param_3;
    if (0xf < in_stack_00000020) {
      uStack_9b8._0_4_ = (undefined **)param_3;
    }
    puStack_9bc = auStack_68;
    uStack_9b8._4_4_ = (char *)in_stack_0000001c;
    pcStack_9c0 = (char *)0xacf1a2;
    uStack_9b8._4_4_ = (char *)FUN_0151d700();
    if (0xf < *(uint *)((int)uStack_9b8._4_4_ + 0x14)) {
      uStack_9b8._4_4_ = *(char **)uStack_9b8._4_4_;
    }
    uStack_9b8._0_4_ = (undefined **)0x194a430;
    pcStack_9c0 = acStack_9a8;
    puStack_9bc = (uint *)0x800;
    uStack_9c4 = 0xacf1c4;
    FUN_0058ccc0();
    if (0xf < uStack_54) {
      uStack_9b8._4_4_ = (char *)(uStack_54 + 1);
      uVar13 = auStack_68[0];
      if (0xfff < uStack_9b8._4_4_) {
        uVar13 = *(uint *)(auStack_68[0] - 4);
        uStack_9b8._4_4_ = (char *)(uStack_54 + 0x24);
        if (0x1f < (auStack_68[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
          uStack_9b8._4_4_ = (char *)0xacfcab;
          FUN_017167a3();
        }
      }
      puStack_9bc = (uint *)0xacf1f8;
      uStack_9b8._0_4_ = (undefined **)uVar13;
      FUN_01674ea0();
    }
    iVar4 = iStack_48;
    uStack_9b8._4_4_ = acStack_9a8;
    do {
      cVar3 = *uStack_9b8._4_4_;
      uStack_9b8._4_4_ = uStack_9b8._4_4_ + 1;
    } while (cVar3 != '\0');
    uStack_9b8._4_4_ = (char *)((int)uStack_9b8._4_4_ - (int)(acStack_9a8 + 1));
    uStack_9b8._0_4_ = (undefined **)acStack_9a8;
    iStack_74 = iStack_48 + 0x5c;
    puStack_9bc = (uint *)0xacf225;
    FUN_005542c0();
    if (cStack_11 == '\0') {
      uStack_9b8._4_4_ = (char *)0x6;
      uStack_9b8._0_4_ = (undefined **)0x194a468;
      puStack_9bc = (uint *)0x3;
      pcStack_9c0 = (char *)0xacfa9c;
      FUN_0086edd0();
      uStack_20 = 0;
      uStack_1c = 0xf;
      appppuStack_30[0] = (undefined4 ****)((uint)appppuStack_30[0] & 0xffffff00);
      uStack_9b8._4_4_ = (char *)0x3a;
      uStack_9b8._0_4_ = (undefined **)0x194a4b4;
      puStack_9bc = (uint *)0xacfac0;
      FUN_005542c0();
      uStack_9b8._4_4_ = (char *)0x2;
      uStack_9b8._0_4_ = (undefined **)appppuStack_30;
      uStack_8._0_1_ = 0x18;
      puStack_9bc = (uint *)0x1;
      pcStack_9c0 = (char *)0xacfad3;
      FUN_00ada860();
      uStack_8._0_1_ = 5;
      uVar2 = (undefined)uStack_8;
      uStack_8._0_1_ = 5;
      if (0xf < uStack_1c) {
        uStack_9b8._4_4_ = (char *)(uStack_1c + 1);
        pppppuVar15 = (undefined4 *****)appppuStack_30[0];
        if (0xfff < uStack_9b8._4_4_) {
          pppppuVar15 = (undefined4 *****)appppuStack_30[0][-1];
          uStack_9b8._4_4_ = (char *)(uStack_1c + 0x24);
          if (0x1f < (uint)((int)appppuStack_30[0] + (-4 - (int)pppppuVar15))) {
                    /* WARNING: Subroutine does not return */
            uStack_9b8._4_4_ = (char *)0xacfcd8;
            uStack_8._0_1_ = uVar2;
            FUN_017167a3();
          }
        }
        puStack_9bc = (uint *)0xacfb08;
        uStack_9b8._0_4_ = (undefined **)pppppuVar15;
        FUN_01674ea0();
      }
    }
    else {
      uStack_9b8._4_4_ = (char *)iVar4;
      uStack_9b8._0_4_ = (undefined **)0xacf235;
      iStack_50 = FUN_0064e700();
      if (iStack_50 != 0) {
        uStack_9b8._4_4_ = (char *)0x18;
        uStack_9b8._0_4_ = (undefined **)0xacf24a;
        puVar6 = (undefined *)FUN_01674e20();
        puStack_4c = puVar6;
        if (puVar6 == (undefined *)0x0) {
          uStack_9b8._0_4_ = (undefined **)0x0;
        }
        else {
          uStack_9b8._4_4_ = (char *)&puStack_18;
          *puVar6 = 0;
          uStack_9b8._0_4_ = &boost::lock_error::vftable_meta_ptr;
          puStack_9bc = (uint *)&DAT_018be100;
          puStack_18 = (undefined4 *)&DAT_0000000b;
          pcStack_9c0 = (char *)0xacf273;
          ppuVar7 = (undefined **)FUN_00563d40();
          ppuVar10 = ppuVar7 + -1;
          if (ppuVar7 != &boost::lock_error::vftable_meta_ptr) {
            ppuVar10 = ppuVar7;
          }
          *(undefined **)(puVar6 + 4) = *ppuVar10;
          *(undefined4 *)(puVar6 + 8) = 0;
          *(undefined4 *)(puVar6 + 0xc) = 0x3f800000;
          *(undefined4 *)(puVar6 + 0x10) = 0;
          *(undefined4 *)(puVar6 + 0x14) = 0;
          uStack_9b8._0_4_ = (undefined **)puVar6;
        }
        uStack_9b8._4_4_ = (char *)in_stack_00000028;
        uStack_44 = 0;
        piStack_40 = (int *)0x0;
        puStack_9bc = (uint *)0xacf2c0;
        FUN_005c1af0();
        uStack_9b8._4_4_ = (char *)0x7;
        uStack_9b8._0_4_ = (undefined **)0x18c5e18;
        uStack_8._0_1_ = 6;
        uStack_20 = 0;
        uStack_1c = 0xf;
        appppuStack_30[0] = (undefined4 ****)((uint)appppuStack_30[0] & 0xffffff00);
        puStack_9bc = (uint *)0xacf2e5;
        FUN_005542c0();
        uStack_9b8._4_4_ = (char *)&param_1;
        uStack_9b8._0_4_ = (undefined **)appppuStack_30;
        uStack_8._0_1_ = 7;
        puStack_9bc = (uint *)0xacf2fb;
        FUN_005c4c00();
        uStack_9b8._0_4_ = (undefined **)0xacf303;
        FUN_00632bc0();
        uStack_8._0_1_ = 6;
        uVar2 = (undefined)uStack_8;
        uStack_8._0_1_ = 6;
        if (0xf < uStack_1c) {
          uStack_9b8._4_4_ = (char *)(uStack_1c + 1);
          ppppuVar14 = appppuStack_30[0];
          if (0xfff < uStack_9b8._4_4_) {
            ppppuVar14 = (undefined4 ****)appppuStack_30[0][-1];
            uStack_9b8._4_4_ = (char *)(uStack_1c + 0x24);
            if (0x1f < (uint)((int)appppuStack_30[0] + (-4 - (int)ppppuVar14))) {
                    /* WARNING: Subroutine does not return */
              uStack_9b8._4_4_ = (char *)0xacfcb0;
              uStack_8._0_1_ = uVar2;
              FUN_017167a3();
            }
          }
          puStack_9bc = (uint *)0xacf338;
          uStack_9b8._0_4_ = (undefined **)ppppuVar14;
          FUN_01674ea0();
        }
        uStack_9b8._4_4_ = (char *)0x9;
        uStack_9b8._0_4_ = (undefined **)0x1931e0c;
        uStack_20 = 0;
        uStack_1c = 0xf;
        appppuStack_30[0] = (undefined4 ****)((uint)appppuStack_30[0] & 0xffffff00);
        puStack_9bc = (uint *)0xacf35c;
        FUN_005542c0();
        uStack_9b8._4_4_ = (char *)appppuStack_30;
        uStack_8._0_1_ = 8;
        uStack_9b8._0_4_ = (undefined **)0xacf36b;
        iVar4 = FUN_005c4c00();
        uStack_9b8._4_4_ = (char *)0xacf372;
        uVar8 = FUN_0088cb40();
        *(undefined4 *)(iVar4 + 0x18) = uVar8;
        uStack_9b8._4_4_ = (char *)&stack0x0000002c;
        uStack_9b8._0_4_ = (undefined **)0xacf381;
        FUN_005c17a0();
        uStack_8._0_1_ = 6;
        uVar2 = (undefined)uStack_8;
        uStack_8._0_1_ = 6;
        if (0xf < uStack_1c) {
          uStack_9b8._4_4_ = (char *)(uStack_1c + 1);
          ppppuVar14 = appppuStack_30[0];
          if (0xfff < uStack_9b8._4_4_) {
            ppppuVar14 = (undefined4 ****)appppuStack_30[0][-1];
            uStack_9b8._4_4_ = (char *)(uStack_1c + 0x24);
            if (0x1f < (uint)((int)appppuStack_30[0] + (-4 - (int)ppppuVar14))) {
                    /* WARNING: Subroutine does not return */
              uStack_9b8._4_4_ = (char *)0xacfcb5;
              uStack_8._0_1_ = uVar2;
              FUN_017167a3();
            }
          }
          puStack_9bc = (uint *)0xacf3b6;
          uStack_9b8._0_4_ = (undefined **)ppppuVar14;
          FUN_01674ea0();
        }
        uStack_58 = 0;
        uStack_54 = 0xf;
        auStack_68[0] = auStack_68[0] & 0xffffff00;
        uStack_9b8._4_4_ = (char *)0xa;
        uStack_9b8._0_4_ = (undefined **)0x194a324;
        uStack_8._0_1_ = 9;
        uStack_20 = 0;
        uStack_1c = 0xf;
        appppuStack_30[0] = (undefined4 ****)((uint)appppuStack_30[0] & 0xffffff00);
        puStack_9bc = (uint *)0xacf3f0;
        FUN_005542c0();
        uStack_9b8._4_4_ = (char *)auStack_68;
        uStack_8._0_1_ = 10;
        uStack_9b8._0_4_ = (undefined **)appppuStack_30;
        puStack_9bc = (uint *)0xacf403;
        FUN_005c4c00();
        uStack_9b8._0_4_ = (undefined **)0xacf40b;
        FUN_00632ce0();
        uStack_8._0_1_ = 9;
        uVar2 = (undefined)uStack_8;
        uStack_8._0_1_ = 9;
        if (0xf < uStack_1c) {
          uStack_9b8._4_4_ = (char *)(uStack_1c + 1);
          ppppuVar14 = appppuStack_30[0];
          if (0xfff < uStack_9b8._4_4_) {
            ppppuVar14 = (undefined4 ****)appppuStack_30[0][-1];
            uStack_9b8._4_4_ = (char *)(uStack_1c + 0x24);
            if (0x1f < (uint)((int)appppuStack_30[0] + (-4 - (int)ppppuVar14))) {
                    /* WARNING: Subroutine does not return */
              uStack_9b8._4_4_ = (char *)0xacfcba;
              uStack_8._0_1_ = uVar2;
              FUN_017167a3();
            }
          }
          puStack_9bc = (uint *)0xacf440;
          uStack_9b8._0_4_ = (undefined **)ppppuVar14;
          FUN_01674ea0();
        }
        uStack_20 = 0;
        uStack_1c = 0xf;
        appppuStack_30[0] = (undefined4 ****)((uint)appppuStack_30[0] & 0xffffff00);
        uStack_8._0_1_ = 6;
        uVar2 = (undefined)uStack_8;
        uStack_8._0_1_ = 6;
        if (0xf < uStack_54) {
          uStack_9b8._4_4_ = (char *)(uStack_54 + 1);
          uVar13 = auStack_68[0];
          if (0xfff < uStack_9b8._4_4_) {
            uVar13 = *(uint *)(auStack_68[0] - 4);
            uStack_9b8._4_4_ = (char *)(uStack_54 + 0x24);
            if (0x1f < (auStack_68[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
              uStack_9b8._4_4_ = (char *)0xacfcbf;
              uStack_8._0_1_ = uVar2;
              FUN_017167a3();
            }
          }
          puStack_9bc = (uint *)0xacf48a;
          uStack_9b8._0_4_ = (undefined **)uVar13;
          FUN_01674ea0();
        }
        uStack_9b8._4_4_ = (char *)0x18;
        uStack_9b8._0_4_ = (undefined **)0x194a330;
        uStack_20 = 0;
        uStack_1c = 0xf;
        appppuStack_30[0] = (undefined4 ****)((uint)appppuStack_30[0] & 0xffffff00);
        puStack_9bc = (uint *)0xacf4ae;
        FUN_005542c0();
        uStack_9b8._4_4_ = (char *)appppuStack_30;
        uStack_8._0_1_ = 0xb;
        uStack_9b8._0_4_ = (undefined **)0xacf4bd;
        iVar4 = FUN_005c4c00();
        uStack_9b8._4_4_ = (char *)0xacf4c4;
        uVar8 = FUN_0088cb40();
        *(undefined4 *)(iVar4 + 0x18) = uVar8;
        uStack_9b8._4_4_ = (char *)&param_3;
        uStack_9b8._0_4_ = (undefined **)0xacf4d3;
        FUN_005c17a0();
        uStack_8._0_1_ = 6;
        uVar2 = (undefined)uStack_8;
        uStack_8._0_1_ = 6;
        if (0xf < uStack_1c) {
          uStack_9b8._4_4_ = (char *)(uStack_1c + 1);
          ppppuVar14 = appppuStack_30[0];
          if (0xfff < uStack_9b8._4_4_) {
            ppppuVar14 = (undefined4 ****)appppuStack_30[0][-1];
            uStack_9b8._4_4_ = (char *)(uStack_1c + 0x24);
            if (0x1f < (uint)((int)appppuStack_30[0] + (-4 - (int)ppppuVar14))) {
                    /* WARNING: Subroutine does not return */
              uStack_9b8._4_4_ = (char *)0xacfcc4;
              uStack_8._0_1_ = uVar2;
              FUN_017167a3();
            }
          }
          puStack_9bc = (uint *)0xacf508;
          uStack_9b8._0_4_ = (undefined **)ppppuVar14;
          FUN_01674ea0();
        }
        uStack_9b8._4_4_ = (char *)0xc;
        uStack_9b8._0_4_ = (undefined **)0x1949380;
        uStack_20 = 0;
        uStack_1c = 0xf;
        appppuStack_30[0] = (undefined4 ****)((uint)appppuStack_30[0] & 0xffffff00);
        puStack_9bc = (uint *)0xacf52c;
        FUN_005542c0();
        uStack_9b8._4_4_ = (char *)appppuStack_30;
        uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
        uStack_9b8._0_4_ = (undefined **)0xacf53b;
        iVar5 = FUN_005c4c00();
        uStack_9b8._4_4_ = (char *)0xacf542;
        uVar8 = FUN_00adb880();
        *(undefined4 *)(iVar5 + 0x18) = uVar8;
        uStack_9b8._4_4_ = (char *)0xacf54a;
        param_2 = (undefined4 *)FUN_00adba10();
        iVar4 = *(int *)(iVar5 + 0x1c);
        if ((undefined4 *)iVar4 == param_2) {
          *(undefined4 *)(iVar5 + 0x20) = 2;
        }
        else {
          if (iVar4 != 0) {
            uStack_9b8._4_4_ = (char *)(iVar5 + 0x20);
            uStack_9b8._0_4_ = (undefined **)0xacf56a;
            (**(code **)(iVar4 + 8))();
          }
          *(undefined4 *)(iVar5 + 0x20) = 2;
          *(undefined4 **)(iVar5 + 0x1c) = param_2;
        }
        uStack_8._0_1_ = 6;
        if (0xf < uStack_1c) {
          uStack_9b8._4_4_ = (char *)(uStack_1c + 1);
          ppppuVar14 = appppuStack_30[0];
          if (0xfff < uStack_9b8._4_4_) {
            ppppuVar14 = (undefined4 ****)appppuStack_30[0][-1];
            uStack_9b8._4_4_ = (char *)(uStack_1c + 0x24);
            if (0x1f < (uint)((int)appppuStack_30[0] + (-4 - (int)ppppuVar14))) {
                    /* WARNING: Subroutine does not return */
              uStack_9b8._4_4_ = (char *)0xacfcc9;
              FUN_017167a3();
            }
          }
          puStack_9bc = (uint *)0xacf5af;
          uStack_9b8._0_4_ = (undefined **)ppppuVar14;
          FUN_01674ea0();
        }
        uStack_9b8._4_4_ = (char *)0xc;
        uStack_9b8._0_4_ = (undefined **)0x194a134;
        uStack_20 = 0;
        uStack_1c = 0xf;
        appppuStack_30[0] = (undefined4 ****)((uint)appppuStack_30[0] & 0xffffff00);
        puStack_9bc = (uint *)0xacf5d3;
        FUN_005542c0();
        uStack_9b8._4_4_ = (char *)appppuStack_30;
        uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
        uStack_9b8._0_4_ = (undefined **)0xacf5e2;
        iVar4 = FUN_005c4c00();
        piVar16 = (int *)(iVar4 + 0x1c);
        *(undefined4 *)(iVar4 + 0x18) = in_stack_00000044;
        if (&stack0x00000048 != (undefined4 **)piVar16) {
          if (*piVar16 != 0) {
            uStack_9b8._0_4_ = (undefined **)0xacf601;
            uStack_9b8._4_4_ = (char *)(iVar4 + 0x20);
            (**(code **)(*piVar16 + 8))();
            *piVar16 = 0;
          }
          if (in_stack_00000048 != (undefined4 *)0x0) {
            uStack_9b8._0_4_ = (undefined **)&stack0x0000004c;
            puStack_9bc = (uint *)0xacf61a;
            uStack_9b8._4_4_ = (char *)(iVar4 + 0x20);
            (*(code *)*in_stack_00000048)();
            *piVar16 = (int)in_stack_00000048;
          }
        }
        uStack_8._0_1_ = 6;
        if (0xf < uStack_1c) {
          uStack_9b8._4_4_ = (char *)(uStack_1c + 1);
          ppppuVar14 = appppuStack_30[0];
          if (0xfff < uStack_9b8._4_4_) {
            ppppuVar14 = (undefined4 ****)appppuStack_30[0][-1];
            uStack_9b8._4_4_ = (char *)(uStack_1c + 0x24);
            if (0x1f < (uint)((int)appppuStack_30[0] + (-4 - (int)ppppuVar14))) {
                    /* WARNING: Subroutine does not return */
              uStack_9b8._4_4_ = (char *)0xacfcce;
              FUN_017167a3();
            }
          }
          puStack_9bc = (uint *)0xacf65a;
          uStack_9b8._0_4_ = (undefined **)ppppuVar14;
          FUN_01674ea0();
        }
        uStack_9b8._4_4_ = (char *)0xe;
        uStack_9b8._0_4_ = (undefined **)0x19492d0;
        uStack_20 = 0;
        uStack_1c = 0xf;
        appppuStack_30[0] = (undefined4 ****)((uint)appppuStack_30[0] & 0xffffff00);
        puStack_9bc = (uint *)0xacf67e;
        FUN_005542c0();
        uStack_9b8._4_4_ = (char *)appppuStack_30;
        uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
        uStack_9b8._0_4_ = (undefined **)0xacf68d;
        iVar5 = FUN_005c4c00();
        uStack_9b8._4_4_ = (char *)0xacf694;
        uVar8 = FUN_00adb720();
        *(undefined4 *)(iVar5 + 0x18) = uVar8;
        uStack_9b8._4_4_ = (char *)0xacf69c;
        iVar9 = FUN_00adb9a0();
        iVar4 = *(int *)(iVar5 + 0x1c);
        if (iVar4 == iVar9) {
          *(undefined4 *)(iVar5 + 0x20) = 2;
        }
        else {
          if (iVar4 != 0) {
            uStack_9b8._4_4_ = (char *)(iVar5 + 0x20);
            uStack_9b8._0_4_ = (undefined **)0xacf6bb;
            (**(code **)(iVar4 + 8))();
          }
          *(undefined4 *)(iVar5 + 0x20) = 2;
          *(int *)(iVar5 + 0x1c) = iVar9;
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,6);
        if (0xf < uStack_1c) {
          uStack_9b8._4_4_ = (char *)(uStack_1c + 1);
          pppppuVar15 = (undefined4 *****)appppuStack_30[0];
          if (0xfff < uStack_9b8._4_4_) {
            pppppuVar15 = (undefined4 *****)appppuStack_30[0][-1];
            uStack_9b8._4_4_ = (char *)(uStack_1c + 0x24);
            if (0x1f < (uint)((int)appppuStack_30[0] + (-4 - (int)pppppuVar15))) {
                    /* WARNING: Subroutine does not return */
              uStack_9b8._4_4_ = (char *)0xacfcd3;
              FUN_017167a3();
            }
          }
          puStack_9bc = (uint *)0xacf6fd;
          uStack_9b8._0_4_ = (undefined **)pppppuVar15;
          FUN_01674ea0();
        }
        piVar1 = piStack_40;
        piVar16 = in_stack_00000028;
        puStack_78 = (undefined *)auStack_9d0;
        puStack_18 = auStack_9d0;
        param_2 = (undefined4 *)CONCAT31(param_2._1_3_,DAT_01eeb670);
        puStack_4c = (undefined *)CONCAT31(puStack_4c._1_3_,DAT_01eeb670);
        if (piStack_40 != (int *)0x0) {
          LOCK();
          piStack_40[1] = piStack_40[1] + 1;
          UNLOCK();
        }
        if (in_stack_00000028 != (int *)0x0) {
          LOCK();
          in_stack_00000028[1] = in_stack_00000028[1] + 1;
          UNLOCK();
        }
        ppppuStack_9d4 = (undefined4 ****)param_2;
        if (piStack_40 != (int *)0x0) {
          LOCK();
          piStack_40[1] = piStack_40[1] + 1;
          UNLOCK();
        }
        uStack_9dc = uStack_44;
        piStack_9d8 = piStack_40;
        if (in_stack_00000028 != (int *)0x0) {
          LOCK();
          in_stack_00000028[1] = in_stack_00000028[1] + 1;
          UNLOCK();
        }
        puStack_9e4 = in_stack_00000024;
        piStack_9e0 = in_stack_00000028;
        iStack_9e8 = iStack_48;
        uStack_9ec = 0xacf786;
        ppppuStack_9d4 = (undefined4 ****)FUN_00ac52a0();
        pcStack_f8 = FUN_00acbb10;
        uStack_f4 = 0;
        piStack_9d8 = (int *)0xacf7a6;
        FUN_00a66ab0();
        ppppuStack_9d4 = (undefined4 ****)0xacf7ae;
        FUN_00a678e0();
        if (piVar16 != (int *)0x0) {
          LOCK();
          iVar4 = piVar16[1] + -1;
          piVar16[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            ppppuStack_9d4 = (undefined4 ****)0xacf7c4;
            (**(code **)*piVar16)();
            LOCK();
            iVar4 = piVar16[2] + -1;
            piVar16[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              ppppuStack_9d4 = (undefined4 ****)0xacf7d5;
              (**(code **)(*piVar16 + 4))();
            }
          }
        }
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar4 = piVar1[1] + -1;
          piVar1[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            ppppuStack_9d4 = (undefined4 ****)0xacf7eb;
            (**(code **)*piVar1)();
            LOCK();
            iVar4 = piVar1[2] + -1;
            piVar1[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              ppppuStack_9d4 = (undefined4 ****)0xacf7fb;
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        pcStack_d8 = pcStack_f8;
        uStack_d4 = uStack_f4;
        ppppuStack_9d4 = (undefined4 ****)auStack_f0;
        piStack_9d8 = (int *)0xacf825;
        FUN_00a66ab0();
        *puStack_18 = 0;
        pcStack_b8 = pcStack_d8;
        uStack_b4 = uStack_d4;
        ppppuStack_9d4 = (undefined4 ****)auStack_d0;
        piStack_9d8 = (int *)0xacf858;
        FUN_00a66ab0();
        pcStack_98 = pcStack_b8;
        uStack_94 = uStack_b4;
        ppppuStack_9d4 = (undefined4 ****)auStack_b0;
        piStack_9d8 = (int *)0xacf882;
        FUN_00a66ab0();
        pcStack_70 = pcStack_98;
        uStack_6c = uStack_94;
        ppppuStack_9d4 = (undefined4 ****)auStack_90;
        piStack_9d8 = (int *)0xacf8a3;
        FUN_00a66ab0();
        ppppuStack_9d4 = (undefined4 ****)&pcStack_70;
        piStack_9d8 = (int *)0xacf8ac;
        cVar3 = FUN_00585a40();
        if (cVar3 == '\0') {
          pcStack_38 = pcStack_70;
          uStack_34 = uStack_6c;
          ppppuStack_9d4 = (undefined4 ****)auStack_68;
          piStack_9d8 = (int *)0xacf8cb;
          FUN_00a66ab0();
          ppppuStack_9d4 = (undefined4 ****)0x20;
          uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
          piStack_9d8 = (int *)0xacf8d6;
          param_2 = (undefined4 *)FUN_01674e20();
          if (param_2 == (undefined4 *)0x0) {
            puVar11 = (undefined4 *)0x0;
          }
          else {
            *param_2 = pcStack_38;
            param_2[1] = uStack_34;
            ppppuStack_9d4 = appppuStack_30;
            piStack_9d8 = (int *)0xacf8f7;
            FUN_00a66ab0();
            puVar11 = param_2;
          }
          puStack_18[2] = puVar11;
          ppppuStack_9d4 = (undefined4 ****)0xacf90c;
          FUN_00a678e0();
          ppppuStack_9d4 = (undefined4 ****)0xacf914;
          FUN_00a678e0();
          param_2 = (undefined4 *)CONCAT13(1,param_2._0_3_);
        }
        else {
          ppppuStack_9d4 = (undefined4 ****)0xacf922;
          FUN_00a678e0();
          param_2 = (undefined4 *)((uint)param_2 & 0xffffff);
        }
        ppppuStack_9d4 = (undefined4 ****)0xacf931;
        FUN_00a678e0();
        ppuVar10 = &PTR_FUN_0194b53c;
        if (param_2._3_1_ == '\0') {
          ppuVar10 = (undefined **)0x0;
        }
        *puStack_18 = ppuVar10;
        ppppuStack_9d4 = (undefined4 ****)0xacf94e;
        FUN_00a678e0();
        ppppuStack_9d4 = (undefined4 ****)0xacf959;
        FUN_00a678e0();
        ppppuStack_9d4 = (undefined4 ****)0xacf964;
        FUN_00a678e0();
        puStack_18 = &uStack_9f0;
        param_2 = &uStack_9f0;
        uStack_8._0_1_ = 0x15;
        uStack_9f4 = 0;
        if (in_stack_00000118 != (int *)0x0) {
          LOCK();
          in_stack_00000118[1] = in_stack_00000118[1] + 1;
          UNLOCK();
        }
        if (piVar1 != (int *)0x0) {
          LOCK();
          piVar1[1] = piVar1[1] + 1;
          UNLOCK();
        }
        if (in_stack_00000028 != (int *)0x0) {
          LOCK();
          in_stack_00000028[1] = in_stack_00000028[1] + 1;
          UNLOCK();
        }
        piVar16 = piVar1;
        uVar8 = in_stack_00000114;
        piVar17 = in_stack_00000118;
        FUN_00ac2c80(&uStack_a1c,FUN_00acbce0,0,iStack_48,in_stack_00000024,in_stack_00000028,
                     uStack_44,piVar1,in_stack_00000114,in_stack_00000118,puStack_4c);
        uVar18 = 0xacfa11;
        FUN_00ac0430();
        uStack_9f4 = 0xc;
        uStack_9f8 = 2;
        uStack_9fc = 1;
        param_2 = (undefined4 *)auStack_a14;
        puStack_a18 = auStack_a14;
        uStack_8._0_1_ = 0x16;
        uStack_a1c = 0xacfa2f;
        FUN_0058c4d0();
        uStack_8._0_1_ = 0x17;
        FUN_0054ef60(iStack_74);
        uStack_8._0_1_ = 6;
        FUN_00bd1000(piVar16,uVar8,piVar17,uVar18);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar4 = piVar1[1] + -1;
          piVar1[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            uStack_9b8._4_4_ = (char *)0xacfa67;
            (**(code **)*piVar1)();
            LOCK();
            iVar4 = piVar1[2] + -1;
            piVar1[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              uStack_9b8._4_4_ = (char *)0xacfa7b;
              (**(code **)(*piVar1 + 4))();
              uStack_9b8._4_4_ = (char *)0xacfa86;
              FUN_005705c0();
              goto LAB_00acfb9b;
            }
          }
        }
      }
    }
    uStack_9b8._4_4_ = (char *)0xacfb16;
    FUN_005705c0();
  }
LAB_00acfb9b:
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (0xf < in_stack_00000020) {
    uStack_9b8._4_4_ = (char *)(in_stack_00000020 + 1);
    pppppuVar15 = param_3;
    if (0xfff < uStack_9b8._4_4_) {
      pppppuVar15 = (undefined4 *****)param_3[-1];
      uStack_9b8._4_4_ = (char *)(in_stack_00000020 + 0x24);
      if (0x1f < (uint)((int)param_3 + (-4 - (int)pppppuVar15))) {
                    /* WARNING: Subroutine does not return */
        uStack_9b8._4_4_ = (char *)0xacfce2;
        FUN_017167a3();
      }
    }
    puStack_9bc = (uint *)0xacfbd0;
    uStack_9b8._0_4_ = (undefined **)pppppuVar15;
    FUN_01674ea0();
  }
  piVar16 = in_stack_00000028;
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_3 = (undefined4 *****)((uint)param_3 & 0xffffff00);
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    iVar4 = in_stack_00000028[1] + -1;
    in_stack_00000028[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      uStack_9b8._4_4_ = (char *)0xacfbfb;
      (**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar16 + 2;
      iVar4 = *piVar1 + -1;
      *piVar1 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        uStack_9b8._4_4_ = (char *)0xacfc0b;
        (**(code **)(*piVar16 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000040) {
    uStack_9b8._4_4_ = (char *)(in_stack_00000040 + 1);
    pppppuVar15 = in_stack_0000002c;
    if (0xfff < uStack_9b8._4_4_) {
      pppppuVar15 = (undefined4 *****)in_stack_0000002c[-1];
      uStack_9b8._4_4_ = (char *)(in_stack_00000040 + 0x24);
      if (0x1f < (uint)((int)in_stack_0000002c + (-4 - (int)pppppuVar15))) {
                    /* WARNING: Subroutine does not return */
        uStack_9b8._4_4_ = &UNK_00acfce7;
        FUN_017167a3();
      }
    }
    puStack_9bc = (uint *)0xacfc40;
    uStack_9b8._0_4_ = (undefined **)pppppuVar15;
    FUN_01674ea0();
  }
  in_stack_0000003c = 0;
  in_stack_00000040 = 0xf;
  in_stack_0000002c = (undefined4 *****)((uint)in_stack_0000002c & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x1a);
  puVar11 = in_stack_00000048;
  if (in_stack_00000048 != (undefined4 *)0x0) {
    uStack_9b8._4_4_ = &stack0x0000004c;
    uStack_9b8._0_4_ = (undefined **)0xacfc69;
    puVar11 = (undefined4 *)(*(code *)in_stack_00000048[2])();
  }
  piVar16 = in_stack_00000118;
  if (in_stack_00000118 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000118 + 1;
    iVar4 = *piVar1;
    puVar11 = (undefined4 *)*piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      uStack_9b8._4_4_ = (char *)0xacfc85;
      puVar11 = (undefined4 *)(**(code **)*in_stack_00000118)();
      LOCK();
      piVar1 = piVar16 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uStack_9b8._4_4_ = (char *)0xacfc94;
        puVar11 = (undefined4 *)(**(code **)(*piVar16 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar11;
}



/* FUNCTION 22313 ; VA 0x00acfcf0 ; FUN_00acfcf0 */

int FUN_00acfcf0(undefined4 param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  int *piVar2;
  undefined uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  int in_stack_00000030;
  undefined4 in_stack_000000fc;
  int *in_stack_00000100;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar5 = DAT_01eeb4f4;
  puStack_c = &LAB_017e97cb;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  if (DAT_01d666a8 != '\0') {
    ExceptionList = &pvStack_10;
    iVar4 = FUN_0171d737();
    if (iVar4 % 100 < iVar5) {
      uStack_1c = 0;
      uStack_18 = 0xf;
      auStack_2c[0] = auStack_2c[0] & 0xffffff00;
      if (in_stack_0000001c == 0) {
        FUN_005542c0("TeleportEmptySpawnLocation",0x1a);
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
      }
      else {
        FUN_005542c0("TeleportNonEmptySpawnLocation",0x1d);
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
      }
      FUN_008783f0(auStack_2c,1,0);
      FUN_005507b0();
    }
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_8._0_1_ = 6;
  if (in_stack_00000100 != (int *)0x0) {
    LOCK();
    in_stack_00000100[1] = in_stack_00000100[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  FUN_00adcb50(param_1,param_2,auStack_2c,in_stack_00000024,in_stack_00000028,&param_3,
               &stack0x0000002c,in_stack_000000fc,in_stack_00000100,0,0);
  uStack_8._0_1_ = 3;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_18) {
    uVar7 = uStack_18 + 1;
    uVar6 = auStack_2c[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_2c[0] - 4);
      uVar7 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar6) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (0xf < in_stack_00000020) {
    uVar7 = in_stack_00000020 + 1;
    uVar6 = param_3;
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(param_3 - 4);
      uVar7 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  piVar2 = in_stack_00000028;
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    iVar5 = in_stack_00000028[1] + -1;
    in_stack_00000028[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  iVar5 = in_stack_00000030;
  if (in_stack_00000030 != 0) {
    iVar5 = (**(code **)(in_stack_00000030 + 8))(&stack0x00000034);
  }
  piVar2 = in_stack_00000100;
  if (in_stack_00000100 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000100 + 1;
    iVar4 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar5 = (**(code **)*in_stack_00000100)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar5 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 22314 ; VA 0x00acff20 ; FUN_00acff20 */

void __fastcall FUN_00acff20(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = *(uint *)(param_1 + 0x44);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x30);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined4 *)(param_1 + 0x44) = 0xf;
  *(undefined *)(param_1 + 0x30) = 0;
  piVar4 = *(int **)(param_1 + 0x1c);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00acff8d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar4 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 22315 ; VA 0x00acffa0 ; FUN_00acffa0 */

void __fastcall FUN_00acffa0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  return;
}



/* FUNCTION 22316 ; VA 0x00ad0000 ; FUN_00ad0000 */

uint FUN_00ad0000(undefined4 param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4,
                 int param_5,undefined4 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 *puVar7;
  byte *pbVar8;
  double in_XMM0_Qa;
  undefined8 uVar9;
  undefined auStack_64 [16];
  undefined4 uStack_54;
  undefined4 uStack_50;
  uint auStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  int *piStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puVar5 = param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e9809;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  pbVar8 = (byte *)*param_2;
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  pbVar8 = pbVar8 + *pbVar8 + 1;
  uVar1 = FUN_005702d0(auStack_4c);
  FUN_00562fc0(&param_2,uVar1,auStack_4c,-(uint)(pbVar8 != (byte *)0x0) & (uint)(pbVar8 + 1));
  if (0xf < uStack_38) {
    if ((0xfff < uStack_38 + 1) && (0x1f < (auStack_4c[0] - *(int *)(auStack_4c[0] - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  if ((param_2 == (undefined4 *)0x0) || (*(char *)(param_2[8] + 0x21) == '\0')) {
    FUN_0086f2f0();
    ExceptionList = pvStack_10;
    return 0;
  }
  uVar9 = FUN_00563790();
  uStack_28 = (undefined4)((ulonglong)uVar9 >> 0x20);
  uStack_24 = (undefined4)uVar9;
  pbVar8 = (byte *)*puVar5;
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  FUN_005542c0();
  pbVar8 = pbVar8 + *pbVar8 + 1;
  uVar1 = FUN_005702d0(auStack_4c);
  FUN_00562fc0(&param_2,uVar1,auStack_4c,-(uint)(pbVar8 != (byte *)0x0) & (uint)(pbVar8 + 1));
  if (0xf < uStack_38) {
    if ((0xfff < uStack_38 + 1) && (0x1f < (auStack_4c[0] - *(int *)(auStack_4c[0] - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  puVar5 = param_2;
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  if (param_2 == (undefined4 *)0x0) {
LAB_00ad01ee:
    piStack_34 = (int *)0x0;
    piStack_30 = (int *)0x0;
  }
  else {
    iVar6 = param_2[8];
    piVar4 = param_2 + 8;
    iVar2 = FUN_008882f0();
    if (iVar6 != iVar2) goto LAB_00ad01ee;
    iVar6 = *piVar4;
    iVar2 = FUN_008882f0();
    if (iVar6 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar3 = puVar5 + 10;
    if (puVar5[9] == 0) {
      piVar3 = (int *)0x0;
    }
    if (*piVar3 == 0) goto LAB_00ad01ee;
    iVar6 = *piVar4;
    iVar2 = FUN_008882f0();
    if (iVar6 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar4 = puVar5 + 10;
    if (puVar5[9] == 0) {
      piVar4 = (int *)0x0;
    }
    iVar2 = ((int *)*piVar4)[1] - *(int *)*piVar4;
    iVar6 = iVar2 >> 0x1f;
    if (iVar2 / 0xd0 + iVar6 == iVar6) goto LAB_00ad01ee;
    FUN_00636130(&piStack_34);
  }
  piVar4 = piStack_30;
  iStack_8 = 0;
  if (piStack_34 == (int *)0x0) {
    FUN_0086f2f0();
    param_2 = (undefined4 *)((uint)param_2 & 0xffffff);
  }
  else {
    FUN_00ad9470(1,(piStack_34[1] - *piStack_34) / 0xd0,param_6);
    uStack_54 = 0;
    uStack_50 = 0xf;
    auStack_64[0] = 0;
    pbVar8 = (byte *)*param_3;
    FUN_005542c0();
    pbVar8 = pbVar8 + *pbVar8 + 1;
    uVar1 = FUN_005702d0(auStack_64);
    FUN_00562fc0(&param_2,uVar1,auStack_64,-(uint)(pbVar8 != (byte *)0x0) & (uint)(pbVar8 + 1));
    FUN_005507b0();
    if (param_2 == (undefined4 *)0x0) {
      if (DAT_01eeb4f0 != '\0') {
        FUN_016774b0(DAT_01eeb4f0,"Group Teleport Analytics startTime error",0);
        param_2 = (undefined4 *)((uint)param_2 & 0xffffff);
        goto LAB_00ad04be;
      }
    }
    else {
      uVar9 = FUN_00563790();
      puStack_1c = (undefined4 *)((ulonglong)uVar9 >> 0x20);
      uStack_18 = (undefined4)uVar9;
      uVar9 = FUN_01682de0();
      param_2 = (undefined4 *)((ulonglong)uVar9 >> 0x20);
      uStack_2c = (undefined4)uVar9;
      iStack_8._0_1_ = 1;
      uStack_54 = 0;
      uStack_50 = 0xf;
      auStack_64[0] = 0;
      uStack_14 = 3;
      FUN_0058a190(*(int *)(param_5 + 0x10) + 0x1f);
      FUN_00554150();
      FUN_00554150();
      FUN_016f4020(0);
      FUN_00878cf0(auStack_64,in_XMM0_Qa / DAT_018c0d70);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_005507b0();
      if ((piStack_34[1] - *piStack_34) / 0xd0 != 1) {
        puVar5 = (undefined4 *)FUN_01674e20(0x48);
        if (puVar5 == (undefined4 *)0x0) {
          puVar5 = (undefined4 *)0x0;
        }
        else {
          puVar5[1] = 1;
          puVar5[2] = 1;
          *puVar5 = std::_Ref_count_obj<struct_RBX::TeleportService::PartyInfo>::vftable;
          puStack_1c = puVar5;
          FUN_0170d1f0(puVar5 + 4,0,0x38);
          puVar5[6] = 0;
          puVar5[7] = 0;
          puVar5[0x10] = 0;
          puVar5[0x11] = 0xf;
          *(undefined *)(puVar5 + 0xc) = 0;
        }
        puStack_20 = puVar5 + 4;
        *puStack_20 = uStack_24;
        puVar5[5] = uStack_28;
        iStack_8 = CONCAT31(iStack_8._1_3_,2);
        puStack_1c = puVar5;
        FUN_0056ecd0(&piStack_34);
        puVar5[8] = 1;
        puVar5[10] = uStack_2c;
        puVar5[0xb] = param_2;
        FUN_00551230(param_1);
        iVar6 = FUN_00ac8cd0(param_1);
        if (puVar5 != (undefined4 *)0x0) {
          LOCK();
          puVar5[1] = puVar5[1] + 1;
          UNLOCK();
        }
        puVar7 = puVar5 + 4;
        *(undefined4 **)(iVar6 + 0x18) = puVar7;
        piVar3 = *(int **)(iVar6 + 0x1c);
        *(undefined4 **)(iVar6 + 0x1c) = puVar5;
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar6 = piVar3[1] + -1;
          piVar3[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar6 = piVar3[2] + -1;
            piVar3[2] = iVar6;
            UNLOCK();
            puVar7 = puStack_20;
            if (iVar6 == 0) {
              (**(code **)(*piVar3 + 4))();
              puVar7 = puStack_20;
            }
          }
        }
        if (DAT_01eeb4f0 != '\0') {
          piVar3 = puVar7 + 8;
          if (0xf < (uint)puVar7[0xd]) {
            piVar3 = (int *)*piVar3;
          }
          FUN_01677650(DAT_01eeb4f0,"Group Teleport Analytics added party:%s",piVar3);
        }
        param_2 = (undefined4 *)CONCAT13(1,param_2._0_3_);
        FUN_00550b30();
        goto LAB_00ad04be;
      }
      FUN_008783f0(param_7,1,0);
    }
    param_2 = (undefined4 *)((uint)param_2 & 0xffffff);
  }
LAB_00ad04be:
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar6 = piVar4[1] + -1;
    piVar4[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar6 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return (uint)param_2 >> 0x18;
}



/* FUNCTION 22317 ; VA 0x00ad0540 ; FUN_00ad0540 */

void FUN_00ad0540(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 uint *param_5,uint *param_6)

{
  undefined4 uVar1;
  uint uVar2;
  uint *puVar3;
  uint *puVar4;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  undefined8 uStack_9c;
  undefined4 uStack_94;
  undefined4 uStack_80;
  uint *puStack_7c;
  uint *puStack_78;
  undefined4 uStack_74;
  uint auStack_70 [2];
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  undefined8 uStack_58;
  uint uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  undefined *puStack_20;
  undefined *puStack_1c;
  code *pcStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cef70;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)auStack_70;
  puStack_20 = (undefined *)auStack_70;
  pcStack_18 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01eeb670);
  uStack_14 = *param_4;
  uVar1 = param_4[1];
  auStack_70[0] = 0;
  uVar2 = *param_6;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_70;
  puVar4 = auStack_70;
  if (uVar2 != 0) {
    auStack_70[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_78 = &uStack_68;
      uStack_74 = 0;
      puStack_7c = param_6 + 2;
      uStack_80 = 0xad05c5;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
      puVar3 = (uint *)puStack_20;
      puVar4 = (uint *)puStack_1c;
    }
    else {
      uStack_68 = param_6[2];
      uStack_64 = param_6[3];
      uStack_60 = param_6[4];
      uStack_5c = param_6[5];
      uStack_58 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
      puVar3 = auStack_70;
      puVar4 = auStack_70;
    }
  }
  puStack_1c = (undefined *)puVar4;
  puStack_20 = (undefined *)puVar3;
  uStack_8 = 0;
  uStack_94 = param_1;
  uVar2 = *param_5;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_5 + 2);
    }
    else {
      uStack_ac = param_5[2];
      uStack_a8 = param_5[3];
      uStack_a4 = param_5[4];
      uStack_a0 = param_5[5];
      uStack_9c = *(undefined8 *)(param_5 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_94 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_40 != 0) {
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_ac,0);
    }
    else {
      uStack_ac = uStack_38;
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
    }
  }
  FUN_00960050();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
     (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
    uStack_94 = 2;
    uStack_9c = CONCAT44(&uStack_38,&uStack_38);
    uStack_a0 = 0xad06a7;
    (**(code **)(uStack_40 & 0xfffffffe))();
  }
  uStack_8 = 0xffffffff;
  uStack_9c = CONCAT44(uStack_14,0xad06c7);
  uStack_94 = uVar1;
  (*pcStack_18)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22318 ; VA 0x00ad06e0 ; FUN_00ad06e0 */

void FUN_00ad06e0(int param_1,code *param_2,int param_3,undefined4 *param_4,undefined4 *param_5,
                 int param_6,undefined4 *param_7,uint *param_8,uint *param_9)

{
  int *piVar1;
  undefined4 uVar2;
  uint uVar3;
  uint *puVar4;
  uint *puVar5;
  undefined auStack_164 [148];
  undefined4 uStack_d0;
  uint *puStack_cc;
  uint *puStack_c8;
  uint *puStack_c4;
  uint *puStack_c0;
  code *pcStack_bc;
  uint uStack_b8;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  undefined8 uStack_a0;
  undefined4 uStack_98;
  undefined4 uStack_84;
  uint *puStack_80;
  uint *puStack_7c;
  undefined4 uStack_78;
  uint auStack_74 [2];
  uint uStack_6c;
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  undefined8 uStack_5c;
  undefined4 auStack_4c [2];
  uint uStack_44;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  undefined8 uStack_2c;
  undefined *puStack_24;
  undefined *puStack_20;
  code *pcStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e9840;
  pvStack_10 = ExceptionList;
  iStack_18 = param_3 + param_1;
  pcStack_1c = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01eeb670);
  puStack_20 = (undefined *)auStack_74;
  puStack_24 = (undefined *)auStack_74;
  uStack_14 = *param_4;
  uVar2 = param_4[1];
  auStack_74[0] = 0;
  uVar3 = *param_9;
  ExceptionList = &pvStack_10;
  puVar4 = auStack_74;
  puVar5 = auStack_74;
  if (uVar3 != 0) {
    auStack_74[0] = uVar3;
    if ((uVar3 & 1) == 0) {
      puStack_7c = &uStack_6c;
      uStack_78 = 0;
      puStack_80 = param_9 + 2;
      uStack_84 = 0xad0768;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar3 & 0xfffffffe))();
      puVar4 = (uint *)puStack_24;
      puVar5 = (uint *)puStack_20;
    }
    else {
      uStack_6c = param_9[2];
      uStack_68 = param_9[3];
      uStack_64 = param_9[4];
      uStack_60 = param_9[5];
      uStack_5c = *(undefined8 *)(param_9 + 6);
      ExceptionList = &pvStack_10;
      puVar4 = auStack_74;
      puVar5 = auStack_74;
    }
  }
  puStack_20 = (undefined *)puVar5;
  puStack_24 = (undefined *)puVar4;
  uStack_8 = 0;
  uStack_98 = param_1;
  uStack_b8 = 0;
  uVar3 = *param_8;
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      puStack_c0 = &uStack_b0;
      pcStack_bc = (code *)0x0;
      puStack_c4 = param_8 + 2;
      puStack_c8 = (uint *)0xad07c3;
      uStack_b8 = uVar3;
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    else {
      uStack_b0 = param_8[2];
      uStack_ac = param_8[3];
      uStack_a8 = param_8[4];
      uStack_a4 = param_8[5];
      uStack_a0 = *(undefined8 *)(param_8 + 6);
      uStack_b8 = uVar3;
    }
  }
  pcStack_bc = FUN_008e5f10;
  puStack_c4 = (uint *)0xad07d1;
  puStack_c0 = auStack_4c;
  FUN_008bfbf0();
  uStack_98 = 0;
  uStack_8._0_1_ = 1;
  puStack_c0 = (uint *)auStack_4c[0];
  uStack_b8 = 0;
  if (uStack_44 != 0) {
    uStack_b8 = uStack_44;
    if ((uStack_44 & 1) == 0) {
      puStack_c8 = &uStack_b0;
      puStack_c4 = (uint *)0x0;
      puStack_cc = &uStack_3c;
      uStack_d0 = 0xad0822;
      (**(code **)(uStack_44 & 0xfffffffe))();
    }
    else {
      uStack_b0 = uStack_3c;
      uStack_ac = uStack_38;
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
    }
  }
  puStack_c4 = (uint *)0xad082c;
  FUN_008dbe80();
  uStack_8._0_1_ = 2;
  if (uStack_44 != 0) {
    if (((uStack_44 & 1) == 0) && (*(code **)(uStack_44 & 0xfffffffe) != (code *)0x0)) {
      uStack_98 = 2;
      uStack_a0 = CONCAT44(&uStack_3c,&uStack_3c);
      uStack_a4 = 0xad084d;
      (**(code **)(uStack_44 & 0xfffffffe))();
    }
    uStack_44 = 0;
  }
  if (param_7[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_7[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_a0 = CONCAT44(*param_7,(int)uStack_a0);
  uStack_98 = param_7[1];
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (*(undefined4 **)(param_6 + 4) != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)(param_6 + 4))(param_6 + 8,auStack_164);
  }
  if (param_5[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  (*pcStack_1c)(uStack_14,uVar2,*param_5,param_5[1]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22319 ; VA 0x00ad0910 ; FUN_00ad0910 */

undefined4 * FUN_00ad0910(undefined4 param_1,byte *param_2,undefined4 param_3,int *param_4)

{
  byte bVar1;
  uint uVar2;
  int *piVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 *puVar8;
  int *piVar9;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e9860;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_00587490(&iStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_28 != 0) {
    bVar1 = *param_2;
    uVar6 = FUN_005702d0(param_1);
    FUN_008992d0(&puStack_18,uVar6,param_1,
                 -(uint)(param_2 + bVar1 + 1 != (byte *)0x0) & (uint)(param_2 + bVar1 + 1 + 1));
    puVar5 = puStack_18;
    if ((puStack_18 != (undefined4 *)0x0) && (puStack_18[8] != 0)) {
      iVar7 = FUN_00ac8cd0(param_1);
      puVar5 = *(undefined4 **)(iVar7 + 0x18);
      if (puVar5[2] != 0) {
        if (*(int *)(param_2 + 8) != 0) {
          uStack_1c = FUN_005702d0(param_1);
          puStack_18 = (undefined4 *)(uStack_1c % *(uint *)(param_2 + 4));
          iStack_20 = (int)puStack_18 * 4;
          puVar5 = *(undefined4 **)(param_2 + 0x14);
          piStack_14 = (int *)puVar5[(int)puStack_18];
          if ((piStack_14 != (int *)0x0) &&
             (piVar3 = (int *)*piStack_14, (int *)*piStack_14 != (int *)0x0)) {
            do {
              piVar9 = piVar3;
              uVar2 = piVar9[1];
              puVar5 = (undefined4 *)(uVar2 / *(uint *)(param_2 + 4));
              if ((undefined4 *)(uVar2 % *(uint *)(param_2 + 4)) != puStack_18) goto LAB_00ad0a5a;
              if (uVar2 == uStack_1c) {
                cVar4 = FUN_00558b30(param_1,piVar9 + 2);
                piVar3 = piStack_14;
                if (cVar4 != '\0') {
                  FUN_00ad3a40(piStack_14,*piVar9);
                  if (*piVar3 != 0) {
                    uVar2 = *(uint *)(*piVar3 + 4);
                    puVar5 = (undefined4 *)(uVar2 / *(uint *)(param_2 + 4));
                    puVar8 = (undefined4 *)(uVar2 % *(uint *)(param_2 + 4));
                    if (puStack_18 == puVar8) goto LAB_00ad0a5a;
                    *(int **)(*(int *)(param_2 + 0x14) + (int)puVar8 * 4) = piVar3;
                  }
                  puVar5 = (undefined4 *)(*(int *)(param_2 + 0x14) + iStack_20);
                  if ((int *)*puVar5 == piVar3) {
                    *puVar5 = 0;
                  }
                  goto LAB_00ad0a5a;
                }
              }
              piVar3 = (int *)*piVar9;
              piStack_14 = piVar9;
            } while ((int *)*piVar9 != (int *)0x0);
            puVar5 = (undefined4 *)0x0;
          }
        }
LAB_00ad0a5a:
        puVar5 = (undefined4 *)CONCAT31((int3)((uint)puVar5 >> 8),DAT_01eeb4f0);
        if (DAT_01eeb4f0 != '\0') {
          puVar5 = (undefined4 *)
                   FUN_016774b0(DAT_01eeb4f0,"Group Teleport Analytics removed party",0);
        }
      }
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar3 = piStack_24 + 1;
    iVar7 = *piVar3;
    puVar5 = (undefined4 *)*piVar3;
    *piVar3 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar3 = piStack_24 + 2;
      iVar7 = *piVar3;
      puVar5 = (undefined4 *)*piVar3;
      *piVar3 = iVar7 + -1;
      UNLOCK();
      if (iVar7 + -1 == 0) {
        puVar5 = (undefined4 *)(**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar3 = param_4 + 2;
    iVar7 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if (iVar7 == 1) {
      puVar5 = (undefined4 *)(**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return puVar5;
}



/* FUNCTION 22320 ; VA 0x00ad0ad0 ; FUN_00ad0ad0 */

undefined4 * __thiscall
FUN_00ad0ad0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e98a1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00ad3aa0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 22321 ; VA 0x00ad0c80 ; FUN_00ad0c80 */

undefined4 * __thiscall
FUN_00ad0c80(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e98e1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00ad3e50;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 22322 ; VA 0x00ad0e20 ; FUN_00ad0e20 */

undefined4 * __thiscall
FUN_00ad0e20(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e9921;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00ad3c70;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 22323 ; VA 0x00ad0fd0 ; FUN_00ad0fd0 */

void FUN_00ad0fd0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00adb5f0();
    *param_2 = uVar3;
    iVar4 = FUN_00adb930();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 22324 ; VA 0x00ad1030 ; FUN_00ad1030 */

void FUN_00ad1030(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00adb720();
    *param_2 = uVar3;
    iVar4 = FUN_00adb9a0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 22325 ; VA 0x00ad1090 ; FUN_00ad1090 */

void FUN_00ad1090(undefined4 param_1,undefined4 *param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined auStack_8 [4];
  
  cVar1 = FUN_009cb5f0(param_1,auStack_8);
  if (cVar1 != '\0') {
    uVar2 = FUN_00adb7d0();
    *param_2 = uVar2;
    FUN_00ac0990(auStack_8);
  }
  return;
}



/* FUNCTION 22326 ; VA 0x00ad10c0 ; FUN_00ad10c0 */

void FUN_00ad10c0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00adb880();
    *param_2 = uVar3;
    iVar4 = FUN_00adba10();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 22327 ; VA 0x00ad1120 ; FUN_00ad1120 */

undefined4 * FUN_00ad1120(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  byte *pbVar8;
  undefined4 *puVar9;
  uint auStack_60 [4];
  undefined4 uStack_50;
  uint uStack_4c;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e9988;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00888650(&uStack_30);
  uStack_8 = 0;
  FUN_00888650(&uStack_28);
  uStack_8._0_1_ = 1;
  FUN_00888650(&uStack_20);
  uStack_8._0_1_ = 2;
  pbVar8 = (byte *)*param_2;
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  FUN_005542c0("members",7);
  pbVar8 = pbVar8 + *pbVar8 + 1;
  uVar4 = FUN_005702d0(auStack_48);
  FUN_00562fc0(&piStack_14,uVar4,auStack_48,-(uint)(pbVar8 != (byte *)0x0) & (uint)(pbVar8 + 1));
  if (0xf < uStack_34) {
    uVar7 = uStack_34 + 1;
    uVar6 = auStack_48[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_48[0] - 4);
      uVar7 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  piVar3 = piStack_14;
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  if (piStack_14 != (int *)0x0) {
    uStack_50 = 0;
    uStack_4c = 0xf;
    auStack_60[0] = auStack_60[0] & 0xffffff00;
    FUN_005542c0("Members",7);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    iVar5 = FUN_005c4c00(auStack_60);
    piVar2 = piVar3 + 9;
    piVar1 = (int *)(iVar5 + 0x1c);
    *(int *)(iVar5 + 0x18) = piVar3[8];
    if (piVar2 != piVar1) {
      if (*piVar1 != 0) {
        (**(code **)(*piVar1 + 8))(iVar5 + 0x20);
        *piVar1 = 0;
      }
      if ((undefined4 *)*piVar2 != (undefined4 *)0x0) {
        (**(code **)*piVar2)(piVar3 + 10,iVar5 + 0x20);
        *piVar1 = *piVar2;
      }
    }
    uStack_8._0_1_ = 2;
    if (0xf < uStack_4c) {
      uVar7 = uStack_4c + 1;
      uVar6 = auStack_60[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_60[0] - 4);
        uVar7 = uStack_4c + 0x24;
        if (0x1f < (auStack_60[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
  }
  uStack_38 = 0;
  pbVar8 = (byte *)*param_2;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  FUN_005542c0("sourcePlaceId",0xd);
  pbVar8 = pbVar8 + *pbVar8 + 1;
  uVar4 = FUN_005702d0(auStack_48);
  FUN_00562fc0(&piStack_14,uVar4,auStack_48,-(uint)(pbVar8 != (byte *)0x0) & (uint)(pbVar8 + 1));
  if (0xf < uStack_34) {
    uVar7 = uStack_34 + 1;
    uVar6 = auStack_48[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_48[0] - 4);
      uVar7 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  piVar3 = piStack_14;
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  if (piStack_14 != (int *)0x0) {
    uStack_50 = 0;
    uStack_4c = 0xf;
    auStack_60[0] = auStack_60[0] & 0xffffff00;
    FUN_005542c0("SourcePlaceId",0xd);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    iVar5 = FUN_005c4c00(auStack_60);
    piVar2 = piVar3 + 9;
    piVar1 = (int *)(iVar5 + 0x1c);
    *(int *)(iVar5 + 0x18) = piVar3[8];
    if (piVar2 != piVar1) {
      if (*piVar1 != 0) {
        (**(code **)(*piVar1 + 8))(iVar5 + 0x20);
        *piVar1 = 0;
      }
      if ((undefined4 *)*piVar2 != (undefined4 *)0x0) {
        (**(code **)*piVar2)(piVar3 + 10,iVar5 + 0x20);
        *piVar1 = *piVar2;
      }
    }
    uStack_8._0_1_ = 2;
    if (0xf < uStack_4c) {
      uVar7 = uStack_4c + 1;
      uVar6 = auStack_60[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_60[0] - 4);
        uVar7 = uStack_4c + 0x24;
        if (0x1f < (auStack_60[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
  }
  uStack_38 = 0;
  pbVar8 = (byte *)*param_2;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  FUN_005542c0("startTime",9);
  pbVar8 = pbVar8 + *pbVar8 + 1;
  uVar4 = FUN_005702d0(auStack_48);
  FUN_00562fc0(&piStack_14,uVar4,auStack_48,-(uint)(pbVar8 != (byte *)0x0) & (uint)(pbVar8 + 1));
  if (0xf < uStack_34) {
    uVar7 = uStack_34 + 1;
    uVar6 = auStack_48[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_48[0] - 4);
      uVar7 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  if (piStack_14 != (int *)0x0) {
    uStack_50 = 0;
    uStack_4c = 0xf;
    auStack_60[0] = auStack_60[0] & 0xffffff00;
    FUN_005542c0("startTime",9);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    iVar5 = FUN_005c4c00(auStack_60);
    piVar3 = piStack_14 + 9;
    piVar2 = (int *)(iVar5 + 0x1c);
    *(int *)(iVar5 + 0x18) = piStack_14[8];
    if (piVar3 != piVar2) {
      if (*piVar2 != 0) {
        (**(code **)(*piVar2 + 8))(iVar5 + 0x20);
        *piVar2 = 0;
      }
      if ((undefined4 *)*piVar3 != (undefined4 *)0x0) {
        (**(code **)*piVar3)(piStack_14 + 10,iVar5 + 0x20);
        *piVar2 = *piVar3;
      }
    }
    uStack_8._0_1_ = 2;
    if (0xf < uStack_4c) {
      uVar7 = uStack_4c + 1;
      uVar6 = auStack_60[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_60[0] - 4);
        uVar7 = uStack_4c + 0x24;
        if (0x1f < (auStack_60[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
  }
  uStack_38 = 0;
  pbVar8 = (byte *)*param_2;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  FUN_005542c0(&DAT_018cdcc0,4);
  pbVar8 = pbVar8 + *pbVar8 + 1;
  uVar4 = FUN_005702d0(auStack_48);
  FUN_00562fc0(&param_2,uVar4,auStack_48,-(uint)(pbVar8 != (byte *)0x0) & (uint)(pbVar8 + 1));
  if (0xf < uStack_34) {
    uVar7 = uStack_34 + 1;
    uVar6 = auStack_48[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_48[0] - 4);
      uVar7 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  puVar9 = param_2;
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  if (param_2 != (undefined4 *)0x0) {
    uStack_50 = 0;
    uStack_4c = 0xf;
    auStack_60[0] = auStack_60[0] & 0xffffff00;
    FUN_005542c0(&DAT_018d2348,4);
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    iVar5 = FUN_005c4c00(auStack_60);
    piVar3 = puVar9 + 9;
    piVar2 = (int *)(iVar5 + 0x1c);
    *(undefined4 *)(iVar5 + 0x18) = puVar9[8];
    if (piVar3 != piVar2) {
      if (*piVar2 != 0) {
        (**(code **)(*piVar2 + 8))(iVar5 + 0x20);
        *piVar2 = 0;
      }
      if ((undefined4 *)*piVar3 != (undefined4 *)0x0) {
        (**(code **)*piVar3)(puVar9 + 10,iVar5 + 0x20);
        *piVar2 = *piVar3;
      }
    }
    uStack_8._0_1_ = 2;
    if (0xf < uStack_4c) {
      uVar7 = uStack_4c + 1;
      uVar6 = auStack_60[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_60[0] - 4);
        uVar7 = uStack_4c + 0x24;
        if (0x1f < (auStack_60[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piStack_24[1] = piStack_24[1] + 1;
    UNLOCK();
  }
  uStack_18 = uStack_28;
  piStack_14 = piStack_24;
  uStack_8._0_1_ = 7;
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  FUN_005542c0("userData",8);
  puVar9 = &uStack_18;
  uStack_8._0_1_ = 8;
  FUN_005c4c00(auStack_48);
  FUN_0098dda0(puVar9);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (0xf < uStack_34) {
    uVar7 = uStack_34 + 1;
    uVar6 = auStack_48[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_48[0] - 4);
      uVar7 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  piVar3 = piStack_14;
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_14[1] + -1;
    piStack_14[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar2 = piVar3 + 2;
      iVar5 = *piVar2 + -1;
      *piVar2 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piStack_1c[1] = piStack_1c[1] + 1;
    UNLOCK();
  }
  uStack_18 = uStack_20;
  piStack_14 = piStack_1c;
  uStack_8._0_1_ = 9;
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  FUN_005542c0("internalData",0xc);
  puVar9 = &uStack_18;
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  FUN_005c4c00(auStack_48);
  FUN_0098dda0(puVar9);
  if (0xf < uStack_34) {
    uVar7 = uStack_34 + 1;
    uVar6 = auStack_48[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_48[0] - 4);
      uVar7 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  piVar3 = piStack_14;
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_14[1] + -1;
    piStack_14[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar2 = piVar3 + 2;
      iVar5 = *piVar2 + -1;
      *piVar2 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  *param_1 = 0;
  param_1[1] = 0;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piStack_2c[1] = piStack_2c[1] + 1;
    UNLOCK();
  }
  *param_1 = uStack_30;
  param_1[1] = piStack_2c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar5 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar5 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_24[1] + -1;
    piStack_24[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar5 = piStack_24[2] + -1;
      piStack_24[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar5 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar3 = piStack_2c + 2;
      iVar5 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22328 ; VA 0x00ad1920 ; FUN_00ad1920 */

void FUN_00ad1920(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00adb5f0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22329 ; VA 0x00ad1960 ; FUN_00ad1960 */

void FUN_00ad1960(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00adb720();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22330 ; VA 0x00ad19a0 ; FUN_00ad19a0 */

void FUN_00ad19a0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00adb7d0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22331 ; VA 0x00ad19e0 ; FUN_00ad19e0 */

void FUN_00ad19e0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00adb880();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22332 ; VA 0x00ad1a20 ; FUN_00ad1a20 */

undefined4 FUN_00ad1a20(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  undefined8 *puVar5;
  int *piVar6;
  int aiStack_4c [5];
  uint uStack_38;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined8 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017e99d9;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00888650(param_1);
  uStack_8 = 0;
  uStack_14 = 1;
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  FUN_005542c0(&DAT_018d2348,4);
  uStack_8 = 1;
  iVar1 = FUN_005c4c00(auStack_34);
  uVar2 = FUN_0088cb40();
  *(undefined4 *)(iVar1 + 0x18) = uVar2;
  FUN_005c17a0(param_3);
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_20) {
    uVar3 = uStack_20 + 1;
    uVar4 = auStack_34[0];
    if (0xfff < uVar3) {
      uVar4 = *(uint *)(auStack_34[0] - 4);
      uVar3 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar3);
  }
  uStack_1c = FUN_01682de0();
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  FUN_005542c0("startTime",9);
  puVar5 = &uStack_1c;
  uStack_8 = 2;
  FUN_005c4c00(auStack_34);
  FUN_00632bc0(puVar5);
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_20) {
    uVar3 = uStack_20 + 1;
    uVar4 = auStack_34[0];
    if (0xfff < uVar3) {
      uVar4 = *(uint *)(auStack_34[0] - 4);
      uVar3 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar3);
  }
  FUN_00adb720();
  FUN_009cb090(aiStack_4c,param_2);
  uStack_14 = 3;
  uStack_8 = 3;
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  FUN_005542c0("teleportType",0xc);
  piVar6 = aiStack_4c;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_005c4c00(auStack_34);
  FUN_00632ce0(piVar6);
  if (0xf < uStack_20) {
    uVar3 = uStack_20 + 1;
    uVar4 = auStack_34[0];
    if (0xfff < uVar3) {
      uVar4 = *(uint *)(auStack_34[0] - 4);
      uVar3 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar3);
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  if (0xf < uStack_38) {
    uVar4 = uStack_38 + 1;
    iVar1 = aiStack_4c[0];
    if (0xfff < uVar4) {
      iVar1 = *(int *)(aiStack_4c[0] + -4);
      uVar4 = uStack_38 + 0x24;
      if (0x1f < (aiStack_4c[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar4);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22333 ; VA 0x00ad1c70 ; FUN_00ad1c70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_00ad1c70(undefined4 *param_1,int *param_2,int *param_3)

{
  undefined *puVar1;
  int *piVar2;
  int iVar3;
  void *pvVar4;
  undefined uVar5;
  int iVar6;
  int *piVar7;
  int iVar8;
  undefined4 uVar9;
  int iVar10;
  uint uVar11;
  uint uVar12;
  undefined8 uVar13;
  undefined4 uStack_10c;
  int iStack_108;
  undefined8 uStack_104;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017e9a1b;
  uStack_8 = 0;
  if (param_2 == (int *)0x0) {
    ExceptionList = &pvStack_10;
    *param_1 = 0;
    param_1[1] = 0;
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_00888650(&uStack_24);
    uStack_8._0_1_ = 1;
    FUN_005cac50(&iStack_1c);
    uStack_8._0_1_ = 2;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 2;
    piVar7 = (int *)param_2[1];
    param_2 = (int *)*param_2;
    piStack_14 = piVar7;
    if (param_2 != piVar7) {
      do {
        iVar3 = *param_2;
        if (iVar3 != 0) {
          iVar8 = *(int *)(iVar3 + 0xc);
          iVar6 = FUN_00913630();
          iVar10 = 0;
          if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
              (uint)*(ushort *)(iVar6 + 0x1da)) {
            iVar10 = iVar3;
          }
          piVar7 = piStack_14;
          if (iVar10 != 0) {
            uVar13 = FUN_00928340();
            uStack_10c = FUN_0088da50();
            iStack_108 = 0;
            uStack_104 = uVar13;
            iStack_108 = FUN_005c9e80();
            iVar3 = iStack_1c;
            uStack_8 = CONCAT31(uStack_8._1_3_,3);
            if (*(int *)(iStack_1c + 8) == *(int *)(iStack_1c + 4)) {
              FUN_005ca4f0(*(int *)(iStack_1c + 4),&uStack_10c);
            }
            else {
              FUN_005caf00(&uStack_10c);
              *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 0xd0;
            }
            uStack_8._0_1_ = 4;
            if (iStack_108 != 0) {
              (**(code **)(iStack_108 + 8))(&uStack_104);
            }
            uStack_8._0_1_ = 2;
            piVar7 = piStack_14;
          }
        }
        param_2 = param_2 + 2;
        uVar5 = (undefined)uStack_8;
      } while (param_2 != piVar7);
    }
    uStack_8._0_1_ = uVar5;
    uStack_2c = 0;
    uStack_28 = 0xf;
    auStack_3c[0] = auStack_3c[0] & 0xffffff00;
    FUN_005542c0("Members",7);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    iVar8 = FUN_005c4c00(auStack_3c);
    uVar9 = FUN_008882f0();
    pvVar4 = ThreadLocalStoragePointer;
    iVar3 = _tls_index;
    *(undefined4 *)(iVar8 + 0x18) = uVar9;
    if (*(int *)(*(int *)((int)pvVar4 + iVar3 * 4) + 0x34) < DAT_01ea8cd0) {
      FUN_016f3809(&DAT_01ea8cd0);
      if (DAT_01ea8cd0 == -1) {
        _DAT_01ea8cc4 = FUN_0057bbb0;
        _DAT_01ea8cc8 = FUN_005880a0;
        DAT_01ea8ccc = FUN_0057d5e0;
        FUN_016f37bf(&DAT_01ea8cd0);
      }
    }
    puVar1 = *(undefined **)(iVar8 + 0x1c);
    if (puVar1 == &DAT_01ea8cc4) {
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *(int *)(iVar8 + 0x20) = iStack_1c;
      piVar2 = *(int **)(iVar8 + 0x24);
      *(int **)(iVar8 + 0x24) = piStack_18;
      piVar7 = piStack_18;
      piStack_14 = piVar2;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar3 = piVar2[1] + -1;
        piVar2[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar3 = piVar2[2] + -1;
          piVar2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
    }
    else {
      if (puVar1 != (undefined *)0x0) {
        (**(code **)(puVar1 + 8))(iVar8 + 0x20);
        *(undefined4 *)(iVar8 + 0x1c) = 0;
      }
      *(undefined4 *)(iVar8 + 0x20) = 0;
      *(undefined4 *)(iVar8 + 0x24) = 0;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *(int *)(iVar8 + 0x20) = iStack_1c;
      *(int **)(iVar8 + 0x24) = piStack_18;
      *(undefined **)(iVar8 + 0x1c) = &DAT_01ea8cc4;
      piVar7 = piStack_18;
    }
    if (0xf < uStack_28) {
      uVar12 = uStack_28 + 1;
      uVar11 = auStack_3c[0];
      if (0xfff < uVar12) {
        uVar11 = *(uint *)(auStack_3c[0] - 4);
        uVar12 = uStack_28 + 0x24;
        if (0x1f < (auStack_3c[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar12);
    }
    *param_1 = uStack_24;
    param_1[1] = uStack_20;
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar3 = piVar7[1] + -1;
      piVar7[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar7)();
        LOCK();
        iVar3 = piVar7[2] + -1;
        piVar7[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar7 = param_3 + 2;
      iVar3 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22334 ; VA 0x00ad1fa0 ; FUN_00ad1fa0 */

void __thiscall
FUN_00ad1fa0(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 uStack_284;
  undefined4 uStack_280;
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798d19;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  puVar6 = *(undefined4 **)(param_1 + 0x40);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar7 = 2;
  }
  else {
    uStack_ec = FUN_0088da50();
    puStack_e8 = (undefined4 *)0x0;
    uStack_e4 = *puVar6;
    uStack_e0 = puVar6[1];
    puStack_e8 = (undefined4 *)FUN_005c9e80();
    puStack_18 = &uStack_ec;
    uVar7 = 1;
  }
  uStack_8 = (uint)(puVar6 == (undefined4 *)0x0);
  uStack_14 = uVar7;
  uVar3 = FUN_0088da50();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar7 & 2) != 0) {
    uVar7 = uVar7 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar7;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar7 & 1) != 0) {
    uVar7 = uVar7 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar7;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar2 = *(int *)(param_1 + 0x44);
  if (iVar2 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar6 = &uStack_1bc;
    uStack_8 = 5;
    uVar7 = uVar7 | 8;
  }
  else {
    uStack_ec = FUN_0088cb40();
    puStack_e8 = (undefined4 *)0x0;
    FUN_0054ef60(iVar2);
    puStack_e8 = (undefined4 *)FUN_005c9d30();
    puVar6 = &uStack_ec;
    uStack_8 = 4;
    uVar7 = uVar7 | 4;
  }
  uStack_14 = uVar7;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar7 & 8) != 0) {
    uVar7 = uVar7 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar7;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar7 & 4) != 0) {
    uVar7 = uVar7 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar7;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x48) == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    param_2 = &uStack_1bc;
    uStack_8 = 9;
    uVar7 = uVar7 | 0x20;
  }
  else {
    param_2 = (undefined4 *)FUN_008aa360(*(int *)(param_1 + 0x48));
    uStack_8 = 8;
    uVar7 = uVar7 | 0x10;
  }
  uStack_14 = uVar7;
  uVar3 = FUN_0088cc80();
  uVar4 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar4,uVar3,param_2);
  if ((uVar7 & 0x20) != 0) {
    uVar7 = uVar7 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar7;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar7 & 0x10) != 0) {
    uVar7 = uVar7 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar7;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar2 = *(int *)(param_1 + 0x4c);
  if (iVar2 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar6 = &uStack_1bc;
    uStack_8 = 0xd;
    uVar7 = uVar7 | 0x80;
  }
  else {
    uStack_ec = FUN_0088cb40();
    puStack_e8 = (undefined4 *)0x0;
    FUN_0054ef60(iVar2);
    puStack_e8 = (undefined4 *)FUN_005c9d30();
    puVar6 = &uStack_ec;
    uStack_8 = 0xc;
    uVar7 = uVar7 | 0x40;
  }
  uStack_14 = uVar7;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((char)uVar7 < '\0') {
    uVar7 = uVar7 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar7;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar7 & 0x40) != 0) {
    uVar7 = uVar7 & 0xffffffbf;
    uStack_8 = 0xf;
    uStack_14 = uVar7;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = *(undefined4 **)(param_1 + 0x50);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar6 = &uStack_1bc;
    uStack_8 = 0x11;
    uVar7 = uVar7 | 0x200;
  }
  else {
    uStack_ec = *puVar6;
    puStack_e8 = (undefined4 *)0x0;
    puVar5 = (undefined4 *)puVar6[1];
    if (puVar5 != (undefined4 *)0x0) {
      (*(code *)*puVar5)(puVar6 + 2,&uStack_e4);
      puVar5 = (undefined4 *)puVar6[1];
    }
    puVar6 = &uStack_ec;
    uStack_8 = 0x10;
    uVar7 = uVar7 | 0x100;
    puStack_e8 = puVar5;
  }
  uStack_14 = uVar7;
  uVar3 = FUN_00888410();
  uVar4 = FUN_0086e3d0(param_6);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar7 & 0x200) != 0) {
    uVar7 = uVar7 & 0xfffffdff;
    uStack_8 = 0x12;
    uStack_14 = uVar7;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar7 & 0x100) != 0) {
    uVar7 = uVar7 & 0xfffffeff;
    uStack_8 = 0x13;
    uStack_14 = uVar7;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = *(undefined4 **)(param_1 + 0x54);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar6 = &uStack_35c;
    uStack_8 = 0x15;
    uVar7 = uVar7 | 0x800;
  }
  else {
    uStack_28c = FUN_0088cdc0();
    iStack_288 = 0;
    if (puVar6[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar6[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_284 = *puVar6;
    uStack_280 = puVar6[1];
    iStack_288 = FUN_006309e0();
    puVar6 = &uStack_28c;
    uStack_8 = 0x14;
    uVar7 = uVar7 | 0x400;
  }
  uStack_14 = uVar7;
  uVar3 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_7);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar7 & 0x800) != 0) {
    uVar7 = uVar7 & 0xfffff7ff;
    uStack_8 = 0x16;
    uStack_14 = uVar7;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar7 & 0x400) != 0) && (uStack_8 = 0x17, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(&uStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22335 ; VA 0x00ad25d0 ; FUN_00ad25d0 */

void __thiscall
FUN_00ad25d0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 uStack_284;
  undefined4 uStack_280;
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798d19;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  puVar6 = *(undefined4 **)(param_1 + 0x40);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar7 = 2;
  }
  else {
    uStack_ec = FUN_0088da50();
    puStack_e8 = (undefined4 *)0x0;
    uStack_e4 = *puVar6;
    uStack_e0 = puVar6[1];
    puStack_e8 = (undefined4 *)FUN_005c9e80();
    puStack_18 = &uStack_ec;
    uVar7 = 1;
  }
  uStack_8 = (uint)(puVar6 == (undefined4 *)0x0);
  uStack_14 = uVar7;
  uVar3 = FUN_0088da50();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar7 & 2) != 0) {
    uVar7 = uVar7 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar7;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar7 & 1) != 0) {
    uVar7 = uVar7 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar7;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar2 = *(int *)(param_1 + 0x44);
  if (iVar2 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar6 = &uStack_1bc;
    uStack_8 = 5;
    uVar7 = uVar7 | 8;
  }
  else {
    uStack_ec = FUN_0088cb40();
    puStack_e8 = (undefined4 *)0x0;
    FUN_0054ef60(iVar2);
    puStack_e8 = (undefined4 *)FUN_005c9d30();
    puVar6 = &uStack_ec;
    uStack_8 = 4;
    uVar7 = uVar7 | 4;
  }
  uStack_14 = uVar7;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar7 & 8) != 0) {
    uVar7 = uVar7 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar7;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar7 & 4) != 0) {
    uVar7 = uVar7 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar7;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = *(undefined4 **)(param_1 + 0x48);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar6 = &uStack_1bc;
    uStack_8 = 9;
    uVar7 = uVar7 | 0x20;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    puStack_e8 = (undefined4 *)0x0;
    if (puVar6[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar6[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar6;
    uStack_e0 = puVar6[1];
    puStack_e8 = (undefined4 *)FUN_006309e0();
    puVar6 = &uStack_ec;
    uStack_8 = 8;
    uVar7 = uVar7 | 0x10;
  }
  uStack_14 = uVar7;
  uVar3 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar7 & 0x20) != 0) {
    uVar7 = uVar7 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar7;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar7 & 0x10) != 0) {
    uVar7 = uVar7 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar7;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar2 = *(int *)(param_1 + 0x4c);
  if (iVar2 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar6 = &uStack_1bc;
    uStack_8 = 0xd;
    uVar7 = uVar7 | 0x80;
  }
  else {
    uStack_ec = FUN_0088cb40();
    puStack_e8 = (undefined4 *)0x0;
    FUN_0054ef60(iVar2);
    puStack_e8 = (undefined4 *)FUN_005c9d30();
    puVar6 = &uStack_ec;
    uStack_8 = 0xc;
    uVar7 = uVar7 | 0x40;
  }
  uStack_14 = uVar7;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((char)uVar7 < '\0') {
    uVar7 = uVar7 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar7;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar7 & 0x40) != 0) {
    uVar7 = uVar7 & 0xffffffbf;
    uStack_8 = 0xf;
    uStack_14 = uVar7;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = *(undefined4 **)(param_1 + 0x50);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar6 = &uStack_1bc;
    uStack_8 = 0x11;
    uVar7 = uVar7 | 0x200;
  }
  else {
    uStack_ec = *puVar6;
    puStack_e8 = (undefined4 *)0x0;
    puVar5 = (undefined4 *)puVar6[1];
    if (puVar5 != (undefined4 *)0x0) {
      (*(code *)*puVar5)(puVar6 + 2,&uStack_e4);
      puVar5 = (undefined4 *)puVar6[1];
    }
    puVar6 = &uStack_ec;
    uStack_8 = 0x10;
    uVar7 = uVar7 | 0x100;
    puStack_e8 = puVar5;
  }
  uStack_14 = uVar7;
  uVar3 = FUN_00888410();
  uVar4 = FUN_0086e3d0(param_6);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar7 & 0x200) != 0) {
    uVar7 = uVar7 & 0xfffffdff;
    uStack_8 = 0x12;
    uStack_14 = uVar7;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar7 & 0x100) != 0) {
    uVar7 = uVar7 & 0xfffffeff;
    uStack_8 = 0x13;
    uStack_14 = uVar7;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = *(undefined4 **)(param_1 + 0x54);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar6 = &uStack_35c;
    uStack_8 = 0x15;
    uVar7 = uVar7 | 0x800;
  }
  else {
    uStack_28c = FUN_0088cdc0();
    iStack_288 = 0;
    if (puVar6[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar6[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_284 = *puVar6;
    uStack_280 = puVar6[1];
    iStack_288 = FUN_006309e0();
    puVar6 = &uStack_28c;
    uStack_8 = 0x14;
    uVar7 = uVar7 | 0x400;
  }
  uStack_14 = uVar7;
  uVar3 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_7);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar7 & 0x800) != 0) {
    uVar7 = uVar7 & 0xfffff7ff;
    uStack_8 = 0x16;
    uStack_14 = uVar7;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar7 & 0x400) != 0) && (uStack_8 = 0x17, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(&uStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22336 ; VA 0x00ad2c40 ; FUN_00ad2c40 */

void __thiscall
FUN_00ad2c40(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 uStack_284;
  undefined4 uStack_280;
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cf757;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  puVar6 = *(undefined4 **)(param_1 + 0x40);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar7 = 2;
  }
  else {
    uStack_ec = FUN_0088da50();
    puStack_e8 = (undefined4 *)0x0;
    uStack_e4 = *puVar6;
    uStack_e0 = puVar6[1];
    puStack_e8 = (undefined4 *)FUN_005c9e80();
    puStack_18 = &uStack_ec;
    uVar7 = 1;
  }
  uStack_8 = (uint)(puVar6 == (undefined4 *)0x0);
  uStack_14 = uVar7;
  uVar3 = FUN_0088da50();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar7 & 2) != 0) {
    uVar7 = uVar7 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar7;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar7 & 1) != 0) {
    uVar7 = uVar7 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar7;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar2 = *(int *)(param_1 + 0x44);
  if (iVar2 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar6 = &uStack_1bc;
    uStack_8 = 5;
    uVar7 = uVar7 | 8;
  }
  else {
    uStack_ec = FUN_0088cb40();
    puStack_e8 = (undefined4 *)0x0;
    FUN_0054ef60(iVar2);
    puStack_e8 = (undefined4 *)FUN_005c9d30();
    puVar6 = &uStack_ec;
    uStack_8 = 4;
    uVar7 = uVar7 | 4;
  }
  uStack_14 = uVar7;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar7 & 8) != 0) {
    uVar7 = uVar7 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar7;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar7 & 4) != 0) {
    uVar7 = uVar7 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar7;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = *(undefined4 **)(param_1 + 0x48);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar6 = &uStack_1bc;
    uStack_8 = 9;
    uVar7 = uVar7 | 0x20;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    puStack_e8 = (undefined4 *)0x0;
    if (puVar6[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar6[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar6;
    uStack_e0 = puVar6[1];
    puStack_e8 = (undefined4 *)FUN_006309e0();
    puVar6 = &uStack_ec;
    uStack_8 = 8;
    uVar7 = uVar7 | 0x10;
  }
  uStack_14 = uVar7;
  uVar3 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar7 & 0x20) != 0) {
    uVar7 = uVar7 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar7;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar7 & 0x10) != 0) {
    uVar7 = uVar7 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar7;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar6 = &uStack_1bc;
    uStack_8 = 0xd;
    uVar7 = uVar7 | 0x80;
  }
  else {
    uStack_ec = *puVar6;
    puStack_e8 = (undefined4 *)0x0;
    puVar5 = (undefined4 *)puVar6[1];
    if (puVar5 != (undefined4 *)0x0) {
      (*(code *)*puVar5)(puVar6 + 2,&uStack_e4);
      puVar5 = (undefined4 *)puVar6[1];
    }
    puVar6 = &uStack_ec;
    uStack_8 = 0xc;
    uVar7 = uVar7 | 0x40;
    puStack_e8 = puVar5;
  }
  uStack_14 = uVar7;
  uVar3 = FUN_00888410();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((char)uVar7 < '\0') {
    uVar7 = uVar7 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar7;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar7 & 0x40) != 0) {
    uVar7 = uVar7 & 0xffffffbf;
    uStack_8 = 0xf;
    uStack_14 = uVar7;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = *(undefined4 **)(param_1 + 0x50);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar6 = &uStack_35c;
    uStack_8 = 0x11;
    uVar7 = uVar7 | 0x200;
  }
  else {
    uStack_28c = FUN_0088cdc0();
    iStack_288 = 0;
    if (puVar6[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar6[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_284 = *puVar6;
    uStack_280 = puVar6[1];
    iStack_288 = FUN_006309e0();
    puVar6 = &uStack_28c;
    uStack_8 = 0x10;
    uVar7 = uVar7 | 0x100;
  }
  uStack_14 = uVar7;
  uVar3 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_6);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar7 & 0x200) != 0) {
    uVar7 = uVar7 & 0xfffffdff;
    uStack_8 = 0x12;
    uStack_14 = uVar7;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar7 & 0x100) != 0) && (uStack_8 = 0x13, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(&uStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22337 ; VA 0x00ad31b0 ; FUN_00ad31b0 */

void __thiscall
FUN_00ad31b0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 uStack_284;
  undefined4 uStack_280;
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ba5;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar5 = *(undefined4 **)(param_1 + 0x40);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar6 = 2;
  }
  else {
    uStack_ec = FUN_0088da50();
    puStack_e8 = (undefined4 *)0x0;
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    puStack_e8 = (undefined4 *)FUN_005c9e80();
    puStack_18 = &uStack_ec;
    uVar6 = 1;
  }
  uStack_8 = (uint)(puVar5 == (undefined4 *)0x0);
  uStack_14 = uVar6;
  uVar2 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 1) != 0) {
    uVar6 = uVar6 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 5;
    uVar6 = uVar6 | 8;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    puStack_e8 = (undefined4 *)0x0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    puStack_e8 = (undefined4 *)FUN_006309e0();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar6 = uVar6 | 4;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar6 & 8) != 0) {
    uVar6 = uVar6 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 4) != 0) {
    uVar6 = uVar6 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x48);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 9;
    uVar6 = uVar6 | 0x20;
  }
  else {
    uStack_ec = *puVar5;
    puStack_e8 = (undefined4 *)0x0;
    puVar4 = (undefined4 *)puVar5[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(puVar5 + 2,&uStack_e4);
      puVar4 = (undefined4 *)puVar5[1];
    }
    puVar5 = &uStack_ec;
    uStack_8 = 8;
    uVar6 = uVar6 | 0x10;
    puStack_e8 = puVar4;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_00888410();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar6 & 0x20) != 0) {
    uVar6 = uVar6 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 0x10) != 0) {
    uVar6 = uVar6 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 0xd;
    uVar6 = uVar6 | 0x80;
  }
  else {
    uStack_28c = FUN_0088cdc0();
    iStack_288 = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_284 = *puVar5;
    uStack_280 = puVar5[1];
    iStack_288 = FUN_006309e0();
    puVar5 = &uStack_28c;
    uStack_8 = 0xc;
    uVar6 = uVar6 | 0x40;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((char)uVar6 < '\0') {
    uVar6 = uVar6 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar6;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar6 & 0x40) != 0) && (uStack_8 = 0xf, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(&uStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22338 ; VA 0x00ad3620 ; FUN_00ad3620 */

void __thiscall
FUN_00ad3620(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 uStack_284;
  undefined4 uStack_280;
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ba5;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088cb40();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar5 = *(undefined4 **)(param_1 + 0x40);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar6 = 2;
  }
  else {
    uStack_ec = FUN_0088da50();
    puStack_e8 = (undefined4 *)0x0;
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    puStack_e8 = (undefined4 *)FUN_005c9e80();
    puStack_18 = &uStack_ec;
    uVar6 = 1;
  }
  uStack_8 = (uint)(puVar5 == (undefined4 *)0x0);
  uStack_14 = uVar6;
  uVar2 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 1) != 0) {
    uVar6 = uVar6 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x44) == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    param_2 = &uStack_1bc;
    uStack_8 = 5;
    uVar6 = uVar6 | 8;
  }
  else {
    param_2 = (undefined4 *)FUN_008aa360(*(int *)(param_1 + 0x44));
    uStack_8 = 4;
    uVar6 = uVar6 | 4;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_0088cc80();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,param_2);
  if ((uVar6 & 8) != 0) {
    uVar6 = uVar6 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 4) != 0) {
    uVar6 = uVar6 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x48);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 9;
    uVar6 = uVar6 | 0x20;
  }
  else {
    uStack_ec = *puVar5;
    puStack_e8 = (undefined4 *)0x0;
    puVar4 = (undefined4 *)puVar5[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(puVar5 + 2,&uStack_e4);
      puVar4 = (undefined4 *)puVar5[1];
    }
    puVar5 = &uStack_ec;
    uStack_8 = 8;
    uVar6 = uVar6 | 0x10;
    puStack_e8 = puVar4;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_00888410();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar6 & 0x20) != 0) {
    uVar6 = uVar6 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 0x10) != 0) {
    uVar6 = uVar6 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 0xd;
    uVar6 = uVar6 | 0x80;
  }
  else {
    uStack_28c = FUN_0088cdc0();
    iStack_288 = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_284 = *puVar5;
    uStack_280 = puVar5[1];
    iStack_288 = FUN_006309e0();
    puVar5 = &uStack_28c;
    uStack_8 = 0xc;
    uVar6 = uVar6 | 0x40;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((char)uVar6 < '\0') {
    uVar6 = uVar6 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar6;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar6 & 0x40) != 0) && (uStack_8 = 0xf, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(&uStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22339 ; VA 0x00ad3a40 ; FUN_00ad3a40 */

int __thiscall FUN_00ad3a40(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_005f53f0(-(uint)(param_1 != -3) & param_1 + 4U,puVar1 + 2);
    FUN_01674ea0(puVar1,0x28);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    iVar2 = iVar2 + 1;
    puVar1 = (undefined4 *)*param_2;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 22340 ; VA 0x00ad3aa0 ; FUN_00ad3aa0 */

int FUN_00ad3aa0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  int *piStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  int *piStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e9a74;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 2;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_1c0 = FUN_0088cdc0();
  uStack_1bc = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_1b8 = param_2;
  piStack_1b4 = param_3;
  uStack_1bc = FUN_006309e0();
  uStack_8._0_1_ = 3;
  uStack_f0 = FUN_008881d0();
  uStack_ec = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_e8 = param_4;
  piStack_e4 = param_5;
  uStack_ec = FUN_0058c000();
  uStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,pcVar3);
  uStack_8._0_1_ = 5;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8._0_1_ = 2;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  iVar5 = FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 22341 ; VA 0x00ad3c70 ; FUN_00ad3c70 */

int FUN_00ad3c70(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int param_5)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint in_stack_00000028;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  int *piStack_284;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e9acf;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 2;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_290 = FUN_0088cdc0();
  uStack_28c = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_288 = param_2;
  piStack_284 = param_3;
  uStack_28c = FUN_006309e0();
  uStack_8._0_1_ = 3;
  uStack_1c0 = FUN_00adb5f0();
  uStack_1bc = 0;
  uStack_1b8 = param_4;
  uStack_1bc = FUN_00adb930();
  uStack_8._0_1_ = 4;
  uStack_f0 = FUN_0088cb40();
  uStack_ec = 0;
  FUN_0054ef60(&param_5);
  uStack_ec = FUN_005c9d30();
  uStack_8._0_1_ = 5;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_290,&uStack_20,pcVar3);
  uStack_8._0_1_ = 6;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 7;
  FUN_00577b20();
  uStack_8._0_1_ = 2;
  FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  iVar5 = FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000028) {
    uVar6 = in_stack_00000028 + 1;
    iVar5 = param_5;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(param_5 + -4);
      uVar6 = in_stack_00000028 + 0x24;
      if (0x1f < (param_5 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar5 = FUN_01674ea0(iVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 22342 ; VA 0x00ad3e50 ; FUN_00ad3e50 */

void FUN_00ad3e50(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 *param_5
                 )

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  int *piStack_1b4;
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined auStack_e8 [200];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e9b24;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 2;
  pcVar2 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_1c0 = FUN_0088cdc0();
  uStack_1bc = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_1b8 = param_2;
  piStack_1b4 = param_3;
  uStack_1bc = FUN_006309e0();
  uStack_f0 = param_4;
  uStack_8._0_1_ = 3;
  puStack_ec = (undefined4 *)0x0;
  if (param_5 != (undefined4 *)0x0) {
    (*(code *)*param_5)(&stack0x00000018,auStack_e8);
  }
  puStack_ec = param_5;
  uStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,pcVar2);
  uStack_8._0_1_ = 5;
  (*pcVar2)(&uStack_1c);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8._0_1_ = 2;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = 8;
  if (param_5 != (undefined4 *)0x0) {
    (*(code *)param_5[2])(&stack0x00000018);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22343 ; VA 0x00ad3ff0 ; FUN_00ad3ff0 */

/* WARNING: Removing unreachable block (ram,0x00ad41a6) */
/* WARNING: Removing unreachable block (ram,0x00ad41e5) */

void __thiscall FUN_00ad3ff0(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int iVar1;
  char cVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  uint in_stack_0000002c;
  undefined4 uStack_37c;
  undefined4 *puStack_378;
  undefined auStack_374 [200];
  undefined4 uStack_2ac;
  int iStack_2a8;
  undefined auStack_2a4 [200];
  undefined4 uStack_1dc;
  int iStack_1d8;
  undefined auStack_1d4 [200];
  undefined4 uStack_10c;
  int iStack_108;
  undefined auStack_104 [200];
  undefined auStack_3c [12];
  undefined4 uStack_30;
  int *piStack_2c;
  undefined auStack_28 [4];
  undefined8 uStack_24;
  int iStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e9b97;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  uVar3 = (**(code **)*param_3)();
  if (uVar3 < 4) {
LAB_00ad40e2:
    puVar4 = *(undefined4 **)(param_1 + 0x4c);
    if (puVar4 == (undefined4 *)0x0) {
      uVar5 = 4;
      goto LAB_00ad4444;
    }
    piVar6 = (int *)puVar4[1];
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      piVar6 = (int *)puVar4[1];
    }
    uStack_30 = *puVar4;
    piStack_2c = piVar6;
  }
  else {
    uStack_18 = 0;
    piStack_14 = (undefined4 *)0x0;
    uStack_8._0_1_ = 2;
    uStack_10c = FUN_00888530();
    iStack_108 = 0;
    uStack_8._0_1_ = 3;
    cVar2 = (**(code **)(*param_3 + 4))(4,&uStack_10c);
    if (cVar2 == '\0') {
      uStack_8._0_1_ = 5;
      if (iStack_108 != 0) {
        (**(code **)(iStack_108 + 8))(auStack_104);
      }
      uStack_8._0_1_ = 1;
      FUN_00550b30();
      goto LAB_00ad40e2;
    }
    puVar4 = (undefined4 *)FUN_0088a3d0();
    piVar6 = (int *)puVar4[1];
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      piVar6 = (int *)puVar4[1];
    }
    uStack_30 = *puVar4;
    uStack_8._0_1_ = 4;
    piStack_2c = piVar6;
    if (iStack_108 != 0) {
      (**(code **)(iStack_108 + 8))(auStack_104);
    }
    FUN_00550b30();
  }
  uStack_8._0_1_ = 6;
  uVar3 = (**(code **)*param_3)();
  if (uVar3 < 3) {
LAB_00ad41f8:
    piStack_14 = *(int **)(iStack_1c + 0x48);
    if (piStack_14 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_28,"Argument %d missing or nil",3);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_28,&DAT_01c17198);
    }
    uStack_37c = *piStack_14;
    puStack_378 = (undefined4 *)0x0;
    puVar4 = (undefined4 *)piStack_14[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(piStack_14 + 2,auStack_374);
      puVar4 = (undefined4 *)piStack_14[1];
    }
  }
  else {
    FUN_00888530();
    uStack_8._0_1_ = 7;
    uStack_1dc = FUN_00888530();
    iStack_1d8 = 0;
    uStack_8._0_1_ = 9;
    cVar2 = (**(code **)(*param_3 + 4))(3,&uStack_1dc);
    if (cVar2 == '\0') {
      uStack_8._0_1_ = 0xc;
      if (iStack_1d8 != 0) {
        (**(code **)(iStack_1d8 + 8))(auStack_1d4);
      }
      uStack_8._0_1_ = 6;
      goto LAB_00ad41f8;
    }
    uVar5 = FUN_0054eb90();
    FUN_0056a440(uVar5);
    uStack_8._0_1_ = 10;
    puVar4 = puStack_378;
    if (iStack_1d8 != 0) {
      (**(code **)(iStack_1d8 + 8))(auStack_1d4);
      puVar4 = puStack_378;
    }
  }
  puStack_378 = puVar4;
  uStack_8._0_1_ = 0xe;
  uVar3 = (**(code **)*param_3)();
  if (1 < uVar3) {
    uStack_24._0_4_ = 0;
    uStack_24._4_4_ = 0;
    uStack_8._0_1_ = 0xf;
    uStack_2ac = FUN_00888530();
    iStack_2a8 = 0;
    uStack_8._0_1_ = 0x10;
    cVar2 = (**(code **)(*param_3 + 4))(2,&uStack_2ac);
    if (cVar2 != '\0') {
      puVar4 = (undefined4 *)FUN_00889fa0();
      piVar7 = (int *)puVar4[1];
      if (piVar7 != (int *)0x0) {
        LOCK();
        piVar7[1] = piVar7[1] + 1;
        UNLOCK();
        piVar7 = (int *)puVar4[1];
      }
      uStack_18 = *puVar4;
      uStack_8._0_1_ = 0x11;
      piStack_14 = piVar7;
      if (iStack_2a8 != 0) {
        (**(code **)(iStack_2a8 + 8))(auStack_2a4);
      }
      FUN_00550b30();
      goto LAB_00ad432b;
    }
    uStack_8._0_1_ = 0x12;
    if (iStack_2a8 != 0) {
      (**(code **)(iStack_2a8 + 8))(auStack_2a4);
    }
    uStack_8._0_1_ = 0xe;
    FUN_00550b30();
  }
  puVar4 = *(undefined4 **)(iStack_1c + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    uVar5 = 2;
LAB_00ad4444:
    FUN_016756b0(auStack_3c,"Argument %d missing or nil",uVar5);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_3c,&DAT_01c17198);
  }
  piVar7 = (int *)puVar4[1];
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar7[1] = piVar7[1] + 1;
    UNLOCK();
    piVar7 = (int *)puVar4[1];
  }
  uStack_18 = *puVar4;
  piStack_14 = piVar7;
LAB_00ad432b:
  uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
  uStack_24 = FUN_009269c0(param_3,iStack_1c + 0x40);
  FUN_00ad06e0(param_2,*(undefined4 *)(iStack_1c + 0x38),*(undefined4 *)(iStack_1c + 0x3c),
               &uStack_24,&uStack_18,&uStack_37c,&uStack_30,&param_4,&stack0x0000002c);
  if (piVar7 != (int *)0x0) {
    LOCK();
    iVar1 = piVar7[1] + -1;
    piVar7[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piVar7)();
      LOCK();
      iVar1 = piVar7[2] + -1;
      piVar7[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
  if (puStack_378 != (undefined4 *)0x0) {
    (*(code *)puStack_378[2])(auStack_374);
  }
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar1 = piVar6[1] + -1;
    piVar6[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      piVar7 = piVar6 + 2;
      iVar1 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 0x16;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22344 ; VA 0x00ad4490 ; FUN_00ad4490 */

void __thiscall FUN_00ad4490(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  uint in_stack_0000002c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3d80;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uStack_18 = FUN_009269c0(param_3,param_1 + 0x40);
  FUN_00ad0540(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_18,
               &param_4,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 3;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22345 ; VA 0x00ad4550 ; FUN_00ad4550 */

undefined4 __thiscall FUN_00ad4550(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined auStack_e0 [4];
  int iStack_dc;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = (**(code **)(param_1 + 0x38))(auStack_e0);
  uStack_8 = 0;
  uVar1 = FUN_009d5a20(param_3,uVar1);
  uStack_8 = 1;
  if (iStack_dc != 0) {
    (**(code **)(iStack_dc + 8))(auStack_d8);
  }
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 22346 ; VA 0x00ad45d0 ; FUN_00ad45d0 */

undefined4 FUN_00ad45d0(int param_1,undefined4 param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  undefined4 uStack_200;
  undefined4 *puStack_1fc;
  undefined auStack_1f8 [144];
  undefined4 uStack_168;
  uint *puStack_164;
  undefined4 uStack_160;
  int iStack_15c;
  undefined4 uStack_158;
  int iStack_154;
  int iStack_150;
  undefined *puStack_14c;
  undefined4 uStack_148;
  int iStack_144;
  undefined4 uStack_140;
  int iStack_13c;
  int iStack_138;
  undefined4 uStack_134;
  undefined auStack_128 [4];
  int iStack_124;
  undefined auStack_120 [200];
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  undefined *puStack_40;
  undefined *puStack_3c;
  code *pcStack_38;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_017e9bcb;
  pvStack_1c = ExceptionList;
  uStack_134 = param_2;
  iStack_138 = 0xad460f;
  ExceptionList = &pvStack_1c;
  iVar4 = FUN_01256300();
  puStack_14c = auStack_128;
  iStack_138 = iStack_24 + 0x44;
  uStack_140 = 2;
  iStack_144 = param_3;
  uStack_148 = param_2;
  iStack_150 = 0xad4630;
  iStack_13c = iVar4 - param_3;
  puStack_28 = (undefined4 *)FUN_009d1540();
  puStack_164 = auStack_58;
  iStack_150 = iStack_24 + 0x40;
  iStack_14 = 0;
  uStack_158 = 1;
  iStack_15c = param_3;
  uStack_160 = param_2;
  uStack_168 = 0xad4651;
  iStack_154 = iVar4 - param_3;
  uStack_2c = FUN_009d09d0();
  puVar1 = puStack_28;
  puStack_40 = (undefined *)&uStack_200;
  puStack_3c = (undefined *)&uStack_200;
  iStack_14._0_1_ = 1;
  pcStack_38 = *(code **)(iStack_24 + 0x38);
  iStack_24 = *(int *)(iStack_24 + 0x3c) + param_1;
  uStack_200 = *puStack_28;
  puStack_1fc = (undefined4 *)0x0;
  puVar5 = (undefined4 *)puStack_28[1];
  puVar2 = &uStack_200;
  puVar3 = &uStack_200;
  if (puVar5 != (undefined4 *)0x0) {
    (*(code *)*puVar5)(puStack_28 + 2,auStack_1f8);
    puVar5 = (undefined4 *)puVar1[1];
    puVar2 = (undefined4 *)puStack_40;
    puVar3 = (undefined4 *)puStack_3c;
  }
  puStack_3c = (undefined *)puVar3;
  puStack_40 = (undefined *)puVar2;
  iStack_14._0_1_ = 2;
  puStack_1fc = puVar5;
  FUN_0054ef60(uStack_2c);
  iStack_14._0_1_ = 1;
  (*pcStack_38)();
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  if (0xf < uStack_44) {
    uVar7 = uStack_44 + 1;
    uVar6 = auStack_58[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_58[0] - 4);
      uVar7 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  iStack_14 = 3;
  if (iStack_124 != 0) {
    (**(code **)(iStack_124 + 8))(auStack_120);
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 22347 ; VA 0x00ad4740 ; FUN_00ad4740 */

undefined4 FUN_00ad4740(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  undefined auStack_138 [4];
  int iStack_134;
  undefined auStack_130 [200];
  uint auStack_68 [4];
  undefined4 uStack_58;
  uint uStack_54;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e9c0b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_2);
  iVar2 = iVar2 - param_3;
  uStack_1c._4_4_ = iVar2;
  uStack_20 = FUN_009d1340(auStack_38,param_2,param_3,6,iVar2,iStack_14 + 0x54);
  uStack_8 = 0;
  uStack_24 = FUN_009d1540(auStack_138,param_2,param_3,5,iVar2,iStack_14 + 0x50);
  uStack_8._0_1_ = 1;
  uStack_28 = FUN_009d09d0(auStack_68,param_2,param_3,4,iVar2,iStack_14 + 0x4c);
  uStack_8._0_1_ = 2;
  uVar3 = FUN_009d1050(auStack_30,param_2,param_3,3,iVar2,iStack_14 + 0x48);
  uStack_8._0_1_ = 3;
  uVar4 = FUN_009d09d0(auStack_50,param_2,param_3,2,iVar2,iStack_14 + 0x44);
  uStack_8._0_1_ = 4;
  uStack_1c = FUN_009d1940(param_2,param_3,1,uStack_1c._4_4_,iStack_14 + 0x40);
  uVar3 = FUN_00ac2e00(param_1,*(undefined4 *)(iStack_14 + 0x38),*(undefined4 *)(iStack_14 + 0x3c),
                       param_2,&uStack_1c,uVar4,uVar3,uStack_28,uStack_24,uStack_20,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (0xf < uStack_3c) {
    uVar6 = uStack_3c + 1;
    uVar5 = auStack_50[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_50[0] - 4);
      uVar6 = uStack_3c + 0x24;
      if (0x1f < (auStack_50[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      iVar2 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  uStack_8._0_1_ = 1;
  if (0xf < uStack_54) {
    uVar6 = uStack_54 + 1;
    uVar5 = auStack_68[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_68[0] - 4);
      uVar6 = uStack_54 + 0x24;
      if (0x1f < (auStack_68[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  uStack_58 = 0;
  uStack_54 = 0xf;
  auStack_68[0] = auStack_68[0] & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (iStack_134 != 0) {
    (**(code **)(iStack_134 + 8))(auStack_130);
  }
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_34[1] + -1;
    piStack_34[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piStack_34 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 22348 ; VA 0x00ad4980 ; FUN_00ad4980 */

undefined4 FUN_00ad4980(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  undefined auStack_138 [4];
  int iStack_134;
  undefined auStack_130 [200];
  uint auStack_68 [4];
  undefined4 uStack_58;
  uint uStack_54;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e9c4b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_2);
  iVar2 = iVar2 - param_3;
  uStack_1c._4_4_ = iVar2;
  uStack_20 = FUN_009d1340(auStack_38,param_2,param_3,6,iVar2,iStack_14 + 0x54);
  uStack_8 = 0;
  uStack_24 = FUN_009d1540(auStack_138,param_2,param_3,5,iVar2,iStack_14 + 0x50);
  uStack_8._0_1_ = 1;
  uStack_28 = FUN_009d09d0(auStack_68,param_2,param_3,4,iVar2,iStack_14 + 0x4c);
  uStack_8._0_1_ = 2;
  uVar3 = FUN_009d1340(auStack_30,param_2,param_3,3,iVar2,iStack_14 + 0x48);
  uStack_8._0_1_ = 3;
  uVar4 = FUN_009d09d0(auStack_50,param_2,param_3,2,iVar2,iStack_14 + 0x44);
  uStack_8._0_1_ = 4;
  uStack_1c = FUN_009d1940(param_2,param_3,1,uStack_1c._4_4_,iStack_14 + 0x40);
  uVar3 = FUN_00ac2f20(param_1,*(undefined4 *)(iStack_14 + 0x38),*(undefined4 *)(iStack_14 + 0x3c),
                       param_2,&uStack_1c,uVar4,uVar3,uStack_28,uStack_24,uStack_20,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (0xf < uStack_3c) {
    uVar6 = uStack_3c + 1;
    uVar5 = auStack_50[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_50[0] - 4);
      uVar6 = uStack_3c + 0x24;
      if (0x1f < (auStack_50[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      iVar2 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  uStack_8._0_1_ = 1;
  if (0xf < uStack_54) {
    uVar6 = uStack_54 + 1;
    uVar5 = auStack_68[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_68[0] - 4);
      uVar6 = uStack_54 + 0x24;
      if (0x1f < (auStack_68[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  uStack_58 = 0;
  uStack_54 = 0xf;
  auStack_68[0] = auStack_68[0] & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (iStack_134 != 0) {
    (**(code **)(iStack_134 + 8))(auStack_130);
  }
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_34[1] + -1;
    piStack_34[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piStack_34 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 22349 ; VA 0x00ad4bc0 ; FUN_00ad4bc0 */

undefined4 FUN_00ad4bc0(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puStack_230;
  undefined *puStack_22c;
  undefined4 uStack_228;
  undefined4 *puStack_224;
  undefined auStack_220 [128];
  undefined4 uStack_1a0;
  undefined *puStack_19c;
  undefined4 uStack_198;
  int iStack_194;
  undefined4 uStack_190;
  int iStack_18c;
  int iStack_188;
  undefined *puStack_184;
  undefined4 uStack_180;
  int iStack_17c;
  int iStack_178;
  int iStack_174;
  int iStack_170;
  undefined *puStack_16c;
  uint *puStack_168;
  int iStack_164;
  int iStack_160;
  int iStack_15c;
  int iStack_158;
  int iStack_154;
  undefined auStack_148 [4];
  int iStack_144;
  undefined auStack_140 [200];
  uint auStack_78 [4];
  undefined4 uStack_68;
  uint uStack_64;
  undefined auStack_60 [4];
  int *piStack_5c;
  undefined auStack_58 [4];
  int *piStack_54;
  undefined *puStack_50;
  undefined *puStack_4c;
  code *pcStack_48;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  undefined4 *puStack_30;
  undefined4 *puStack_2c;
  int *piStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017e9c9b;
  pvStack_1c = ExceptionList;
  iStack_154 = param_2;
  iStack_158 = 0xad4bff;
  ExceptionList = &pvStack_1c;
  iVar4 = FUN_01256300();
  puStack_16c = auStack_60;
  iStack_158 = iStack_24 + 0x50;
  iVar4 = iVar4 - param_3;
  iStack_160 = 5;
  iStack_164 = param_3;
  puStack_168 = (uint *)param_2;
  iStack_170 = 0xad4c1d;
  iStack_15c = iVar4;
  piStack_28 = (int *)FUN_009d1340();
  puStack_184 = auStack_148;
  iStack_170 = iStack_24 + 0x4c;
  uStack_14 = 0;
  iStack_178 = 4;
  iStack_17c = param_3;
  uStack_180 = param_2;
  iStack_188 = 0xad4c41;
  iStack_174 = iVar4;
  puStack_30 = (undefined4 *)FUN_009d1540();
  puStack_19c = auStack_58;
  iStack_188 = iStack_24 + 0x48;
  uStack_14._0_1_ = 1;
  uStack_190 = 3;
  iStack_194 = param_3;
  uStack_198 = param_2;
  uStack_1a0 = 0xad4c5f;
  iStack_18c = iVar4;
  puStack_2c = (undefined4 *)FUN_009d1340();
  puStack_168 = auStack_78;
  iStack_154 = iStack_24 + 0x44;
  uStack_14._0_1_ = 2;
  iStack_15c = 2;
  iStack_160 = param_3;
  iStack_164 = param_2;
  puStack_16c = (undefined *)0xad4c80;
  iStack_158 = iVar4;
  uStack_34 = FUN_009d09d0();
  puStack_16c = (undefined *)(iStack_24 + 0x40);
  uStack_14._0_1_ = 3;
  iStack_174 = 1;
  iStack_178 = param_3;
  iStack_17c = param_2;
  uStack_180 = 0xad4c9a;
  iStack_170 = iVar4;
  uStack_3c = FUN_009d1940();
  puVar2 = puStack_30;
  pcStack_48 = *(code **)(iStack_24 + 0x38);
  iStack_24 = *(int *)(iStack_24 + 0x3c) + param_1;
  puStack_50 = (undefined *)&iStack_158;
  if (piStack_28[1] != 0) {
    LOCK();
    piVar1 = (int *)(piStack_28[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iStack_158 = *piStack_28;
  iStack_154 = piStack_28[1];
  puStack_4c = (undefined *)&uStack_228;
  piStack_28 = &uStack_228;
  uStack_14._0_1_ = 4;
  uStack_228 = *puStack_30;
  puStack_224 = (undefined4 *)0x0;
  puVar5 = (undefined4 *)puStack_30[1];
  piVar1 = &iStack_158;
  piVar3 = &uStack_228;
  if (puVar5 != (undefined4 *)0x0) {
    puStack_22c = auStack_220;
    puStack_230 = puStack_30 + 2;
    (*(code *)*puVar5)();
    puVar5 = (undefined4 *)puVar2[1];
    piVar1 = (int *)puStack_50;
    piVar3 = piStack_28;
  }
  piStack_28 = piVar3;
  puStack_50 = (undefined *)piVar1;
  puStack_4c = (undefined *)&puStack_230;
  if (puStack_2c[1] != 0) {
    LOCK();
    piVar1 = (int *)(puStack_2c[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puStack_230 = (undefined4 *)*puStack_2c;
  puStack_22c = (undefined *)puStack_2c[1];
  uStack_14._0_1_ = 6;
  puStack_224 = puVar5;
  FUN_0054ef60(uStack_34);
  uStack_14._0_1_ = 3;
  (*pcStack_48)(uStack_3c);
  uStack_14 = CONCAT31(uStack_14._1_3_,2);
  if (0xf < uStack_64) {
    uVar7 = uStack_64 + 1;
    uVar6 = auStack_78[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_78[0] - 4);
      uVar7 = uStack_64 + 0x24;
      if (0x1f < (auStack_78[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_68 = 0;
  uStack_64 = 0xf;
  auStack_78[0] = auStack_78[0] & 0xffffff00;
  if (piStack_54 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_54[1] + -1;
    piStack_54[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_54)();
      LOCK();
      iVar4 = piStack_54[2] + -1;
      piStack_54[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_54 + 4))();
      }
    }
  }
  uStack_14 = CONCAT31(uStack_14._1_3_,7);
  if (iStack_144 != 0) {
    (**(code **)(iStack_144 + 8))(auStack_140);
  }
  if (piStack_5c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_5c[1] + -1;
    piStack_5c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_5c)();
      LOCK();
      piVar1 = piStack_5c + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_5c + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 22350 ; VA 0x00ad4e40 ; FUN_00ad4e40 */

undefined4 FUN_00ad4e40(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uStack_208;
  undefined4 *puStack_204;
  undefined auStack_200 [128];
  undefined4 uStack_180;
  undefined *puStack_17c;
  undefined4 uStack_178;
  int iStack_174;
  undefined4 uStack_170;
  int iStack_16c;
  int iStack_168;
  undefined *puStack_164;
  undefined4 uStack_160;
  int iStack_15c;
  undefined4 uStack_158;
  int iStack_154;
  int iStack_150;
  undefined *puStack_14c;
  undefined4 uStack_148;
  int iStack_144;
  int iStack_140;
  int iStack_13c;
  int iStack_138;
  int iStack_134;
  undefined auStack_124 [4];
  int iStack_120;
  undefined auStack_11c [200];
  undefined auStack_54 [4];
  int *piStack_50;
  undefined auStack_4c [4];
  int *piStack_48;
  undefined *puStack_44;
  code *pcStack_40;
  undefined8 uStack_38;
  undefined4 *puStack_30;
  undefined4 *puStack_2c;
  int *piStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017e9cd3;
  pvStack_1c = ExceptionList;
  iStack_134 = param_2;
  iStack_138 = 0xad4e7f;
  ExceptionList = &pvStack_1c;
  iVar4 = FUN_01256300();
  puStack_14c = auStack_54;
  iStack_138 = iStack_24 + 0x4c;
  iVar4 = iVar4 - param_3;
  iStack_140 = 4;
  iStack_144 = param_3;
  uStack_148 = param_2;
  iStack_150 = 0xad4e9d;
  iStack_13c = iVar4;
  piStack_28 = (int *)FUN_009d1340();
  puStack_164 = auStack_124;
  iStack_150 = iStack_24 + 0x48;
  uStack_14 = 0;
  uStack_158 = 3;
  iStack_15c = param_3;
  uStack_160 = param_2;
  iStack_168 = 0xad4ec1;
  iStack_154 = iVar4;
  puStack_2c = (undefined4 *)FUN_009d1540();
  puStack_17c = auStack_4c;
  iStack_168 = iStack_24 + 0x44;
  uStack_14._0_1_ = 1;
  uStack_170 = 2;
  iStack_174 = param_3;
  uStack_178 = param_2;
  uStack_180 = 0xad4edf;
  iStack_16c = iVar4;
  puStack_30 = (undefined4 *)FUN_009d1340();
  iStack_134 = iStack_24 + 0x40;
  uStack_14._0_1_ = 2;
  iStack_13c = 1;
  iStack_140 = param_3;
  iStack_144 = param_2;
  uStack_148 = 0xad4efc;
  iStack_138 = iVar4;
  uStack_38 = FUN_009d1940();
  puVar2 = puStack_2c;
  puStack_44 = (undefined *)&iStack_138;
  pcStack_40 = *(code **)(iStack_24 + 0x38);
  iStack_24 = *(int *)(iStack_24 + 0x3c) + param_1;
  if (piStack_28[1] != 0) {
    LOCK();
    piVar1 = (int *)(piStack_28[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iStack_138 = *piStack_28;
  iStack_134 = piStack_28[1];
  piStack_28 = &uStack_208;
  uStack_14._0_1_ = 3;
  uStack_208 = *puStack_2c;
  puStack_204 = (undefined4 *)0x0;
  puVar5 = (undefined4 *)puStack_2c[1];
  piVar1 = &iStack_138;
  piVar3 = &uStack_208;
  if (puVar5 != (undefined4 *)0x0) {
    (*(code *)*puVar5)(puStack_2c + 2,auStack_200);
    puVar5 = (undefined4 *)puVar2[1];
    piVar1 = (int *)puStack_44;
    piVar3 = piStack_28;
  }
  piStack_28 = piVar3;
  puStack_44 = (undefined *)piVar1;
  if (puStack_30[1] != 0) {
    LOCK();
    piVar1 = (int *)(puStack_30[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_14 = CONCAT31(uStack_14._1_3_,2);
  puStack_204 = puVar5;
  (*pcStack_40)(uStack_38,*puStack_30,puStack_30[1]);
  if (piStack_48 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_48[1] + -1;
    piStack_48[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_48)();
      LOCK();
      iVar4 = piStack_48[2] + -1;
      piStack_48[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_48 + 4))();
      }
    }
  }
  uStack_14 = CONCAT31(uStack_14._1_3_,4);
  if (iStack_120 != 0) {
    (**(code **)(iStack_120 + 8))(auStack_11c);
  }
  if (piStack_50 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_50[1] + -1;
    piStack_50[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_50)();
      LOCK();
      piVar1 = piStack_50 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_50 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 22351 ; VA 0x00ad5040 ; FUN_00ad5040 */

/* WARNING: Removing unreachable block (ram,0x00ad5116) */
/* WARNING: Removing unreachable block (ram,0x00ad50ed) */
/* WARNING: Removing unreachable block (ram,0x00ad50f9) */
/* WARNING: Removing unreachable block (ram,0x00ad5107) */
/* WARNING: Removing unreachable block (ram,0x00ad5124) */
/* WARNING: Removing unreachable block (ram,0x00ad5150) */
/* WARNING: Removing unreachable block (ram,0x00ad5134) */

undefined4
FUN_00ad5040(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e9cf0;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ad5160(param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8,
                       CONCAT44(param_10,param_9),&uStack_1c);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 22352 ; VA 0x00ad5160 ; FUN_00ad5160 */

/* WARNING: Removing unreachable block (ram,0x00ad5242) */
/* WARNING: Removing unreachable block (ram,0x00ad524e) */
/* WARNING: Removing unreachable block (ram,0x00ad525c) */

undefined4
FUN_00ad5160(undefined4 param_1,undefined4 param_2,int param_3,undefined4 param_4,uint param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            uint param_10,undefined4 param_11)

{
  undefined8 uVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 in_stack_ffffffc8;
  undefined4 in_stack_ffffffcc;
  undefined4 in_stack_ffffffd0;
  undefined8 in_stack_ffffffd4;
  undefined4 in_stack_ffffffdc;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e9cf0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_5);
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
    UNLOCK();
  }
  FUN_00ad52b0(param_1,param_2,param_3,param_4,in_stack_ffffffc8,in_stack_ffffffcc,in_stack_ffffffd0
               ,in_stack_ffffffd4,in_stack_ffffffdc);
  uVar2 = param_5;
  uVar1 = CONCAT44(param_10,param_9);
  param_9 = 0;
  param_10 = 0xf;
  param_5 = param_5 & 0xffffff00;
  uVar3 = FUN_00adacf0(param_1,param_2,param_3,param_4,uVar2,param_6,param_7,param_8,uVar1,param_11)
  ;
  if (0xf < param_10) {
    if ((0xfff < param_10 + 1) && (0x1f < (param_5 - *(int *)(param_5 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    uVar3 = FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 22353 ; VA 0x00ad52b0 ; FUN_00ad52b0 */

/* WARNING: Removing unreachable block (ram,0x00ad5370) */
/* WARNING: Removing unreachable block (ram,0x00ad5347) */
/* WARNING: Removing unreachable block (ram,0x00ad5353) */
/* WARNING: Removing unreachable block (ram,0x00ad5361) */
/* WARNING: Removing unreachable block (ram,0x00ad537e) */
/* WARNING: Removing unreachable block (ram,0x00ad53aa) */
/* WARNING: Removing unreachable block (ram,0x00ad538e) */

undefined4
FUN_00ad52b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e9cf0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00acad80(param_2,param_3,param_4,param_5,param_6,param_7,param_8,
                       CONCAT44(param_10,param_9));
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 22354 ; VA 0x00ad53b0 ; FUN_00ad53b0 */

void FUN_00ad53b0(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e9d18;
  pvStack_10 = ExceptionList;
  iVar6 = *param_2;
  iVar5 = *(int *)(iVar6 + 0xd0);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_008881d0();
  if (iVar5 != iVar2) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar3 = (undefined4 *)(iVar6 + 0xd8);
  if (*(int *)(iVar6 + 0xd4) == 0) {
    puVar3 = (undefined4 *)0x0;
  }
  iVar6 = puVar3[1];
  if (iVar6 != 0) {
    LOCK();
    *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
    UNLOCK();
    iVar6 = puVar3[1];
  }
  uVar1 = *puVar3;
  param_2 = (int *)*param_2;
  uStack_8 = 0;
  iVar5 = *param_2;
  iVar2 = FUN_0088cdc0();
  if (iVar5 == iVar2) {
    piVar4 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar4 = (int *)0x0;
    }
    iVar5 = piVar4[1];
    if (iVar5 != 0) {
      LOCK();
      *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
      UNLOCK();
      iVar5 = piVar4[1];
    }
    uStack_8 = 2;
    FUN_00acaaf0(*piVar4,iVar5,uVar1,iVar6);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22355 ; VA 0x00ad54c0 ; FUN_00ad54c0 */

void FUN_00ad54c0(undefined4 param_1,undefined4 param_2)

{
  FUN_00ac3a30(param_1,param_2,param_2);
  return;
}



/* FUNCTION 22356 ; VA 0x00ad54e0 ; FUN_00ad54e0 */

void FUN_00ad54e0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  undefined4 uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e9d38;
  pvStack_10 = ExceptionList;
  iVar4 = *param_2;
  iVar5 = *(int *)(iVar4 + 0xd0);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00adb5f0();
  if (iVar5 != iVar2) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  puVar3 = (undefined4 *)(iVar4 + 0xd8);
  iVar5 = *param_2;
  if (*(int *)(iVar4 + 0xd4) == 0) {
    puVar3 = (undefined4 *)0x0;
  }
  iVar4 = *(int *)(iVar5 + 0x1a0);
  uVar7 = *puVar3;
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    iVar4 = iVar5 + 0x1a8;
    if (*(int *)(iVar5 + 0x1a4) == 0) {
      iVar4 = 0;
    }
    FUN_0054ef60(iVar4);
    param_2 = (int *)*param_2;
    uStack_8 = 0;
    iVar4 = *param_2;
    iVar5 = FUN_0088cdc0(uVar7);
    if (iVar4 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
      if (piVar6[1] != 0) {
        LOCK();
        piVar1 = (int *)(piVar6[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      uStack_8 = 0xffffffff;
      FUN_00ad52b0(param_1,*piVar6,piVar6[1],uVar7);
      ExceptionList = pvStack_10;
      return;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0();
}



/* FUNCTION 22357 ; VA 0x00ad55f0 ; FUN_00ad55f0 */

uint * FUN_00ad55f0(uint *param_1)

{
  code *pcVar1;
  undefined4 ****ppppuVar2;
  uint *puVar3;
  uint uVar4;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined4 ***apppuStack_28 [4];
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_01531f50(apppuStack_28);
  if (2 < uStack_18) {
    uStack_40 = uStack_40 & 0xffffff00;
    if (uStack_18 != 0) {
      uVar4 = uStack_18 - 2;
      if (uStack_18 - 1 < uStack_18 - 2) {
        uVar4 = uStack_18 - 1;
      }
      ppppuVar2 = apppuStack_28;
      if (0xf < uStack_14) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      }
      FUN_005542c0((int)ppppuVar2 + 1,uVar4);
      FUN_005507b0();
      param_1[4] = 0;
      param_1[5] = 0;
      *param_1 = uStack_40;
      param_1[1] = uStack_3c;
      param_1[2] = uStack_38;
      param_1[3] = uStack_34;
      param_1[4] = 0;
      param_1[5] = 0xf;
      ExceptionList = pvStack_10;
      return param_1;
    }
    FUN_00554050();
    pcVar1 = (code *)swi(3);
    puVar3 = (uint *)(*pcVar1)();
    return puVar3;
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar4) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22358 ; VA 0x00ad5720 ; FUN_00ad5720 */

undefined4 * FUN_00ad5720(undefined4 *param_1,int *param_2,int *param_3)

{
  char cVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [4];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c88f3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = (**(code **)*param_2)();
  if (3 < uVar2) {
    uStack_18 = 0;
    uStack_14 = 0;
    uStack_8 = 0;
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8._0_1_ = 1;
    cVar1 = (**(code **)(*param_2 + 4))(4,&uStack_ec);
    if (cVar1 != '\0') {
      puVar3 = (undefined4 *)FUN_0088a3d0();
      iVar4 = puVar3[1];
      *param_1 = 0;
      param_1[1] = 0;
      if (iVar4 != 0) {
        LOCK();
        *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
        UNLOCK();
        iVar4 = puVar3[1];
      }
      *param_1 = *puVar3;
      param_1[1] = iVar4;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return param_1;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8 = 0xffffffff;
    FUN_00550b30();
  }
  puVar3 = (undefined4 *)*param_3;
  if (puVar3 != (undefined4 *)0x0) {
    iVar4 = puVar3[1];
    *param_1 = 0;
    param_1[1] = 0;
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
      UNLOCK();
      iVar4 = puVar3[1];
    }
    *param_1 = *puVar3;
    param_1[1] = iVar4;
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 22359 ; VA 0x00ad5890 ; FUN_00ad5890 */

undefined * FUN_00ad5890(undefined *param_1,uint param_2,undefined4 param_3)

{
  int iVar1;
  uint uVar2;
  uint *puVar3;
  int iVar4;
  undefined *puVar5;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e9d58;
  pvStack_10 = ExceptionList;
  if (param_2 == 0) {
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    return param_1;
  }
  iVar4 = 0;
  puVar3 = &DAT_01d666c8;
  ExceptionList = &pvStack_10;
  do {
    uVar2 = *puVar3;
    FUN_0054ef60(puVar3 + 1);
    uStack_8 = 0;
    if (uVar2 == param_2) {
      FUN_005f3cd0(param_1,aiStack_28,param_3);
      if (0xf < uStack_14) {
        uVar2 = uStack_14 + 1;
        iVar4 = aiStack_28[0];
        if (0xfff < uVar2) {
          iVar4 = *(int *)(aiStack_28[0] + -4);
          uVar2 = uStack_14 + 0x24;
          if (0x1f < (aiStack_28[0] - iVar4) - 4U) goto LAB_00ad5a0d;
        }
        FUN_01674ea0(iVar4,uVar2);
      }
      ExceptionList = pvStack_10;
      return param_1;
    }
    if (param_2 <= uVar2 && uVar2 != param_2) {
      if (iVar4 == 0) {
        puVar5 = &DAT_01d666cc;
      }
      else {
        puVar5 = &DAT_01d666b0 + iVar4 * 0x1c;
      }
      FUN_005f3cd0(param_1,puVar5,param_3);
      FUN_0056c780();
      ExceptionList = pvStack_10;
      return param_1;
    }
    iVar4 = iVar4 + 1;
    uStack_8 = 0xffffffff;
    if (0xf < uStack_14) {
      uVar2 = uStack_14 + 1;
      iVar1 = aiStack_28[0];
      if (0xfff < uVar2) {
        iVar1 = *(int *)(aiStack_28[0] + -4);
        uVar2 = uStack_14 + 0x24;
        if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
LAB_00ad5a0d:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar1,uVar2);
    }
    puVar3 = puVar3 + 7;
    if (puVar3 == &DAT_01d66834) {
      FUN_005f3cd0(param_1,&DAT_01d6681c,param_3);
      ExceptionList = pvStack_10;
      return param_1;
    }
  } while( true );
}



/* FUNCTION 22360 ; VA 0x00ad5a20 ; FUN_00ad5a20 */

undefined4 * FUN_00ad5a20(undefined4 *param_1)

{
  *param_1 = DAT_01eeb588;
  param_1[1] = 0;
  if (DAT_01eeb58c != (undefined4 *)0x0) {
    (*(code *)*DAT_01eeb58c)(&DAT_01eeb590,param_1 + 2);
    param_1[1] = DAT_01eeb58c;
    return param_1;
  }
  param_1[1] = 0;
  return param_1;
}



/* FUNCTION 22361 ; VA 0x00ad5a70 ; FUN_00ad5a70 */

undefined4 FUN_00ad5a70(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e9d7c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeb694) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeb694);
    if (DAT_01eeb694 == -1) {
      uStack_8 = 0;
      FUN_005542c0("KYe5@CMC6^}1ZV5U]B#I^~lDRK$o~UoA6ig}a*NBH^tW!]cQVe}J0q$T=gQLl8FT5FyifOzXZJb9mz0v[=a3y~Diw6@FHWh`No^kFBDL{pe3X-e9^`@y4|N-Im![xC&Z"
                   ,0x80);
      FUN_016f3654(&LAB_0188b600);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eeb694);
    }
  }
  FUN_0054ef60(&DAT_01d66834);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22362 ; VA 0x00ad5b20 ; FUN_00ad5b20 */

undefined * FUN_00ad5b20(void)

{
  return &DAT_01d66628;
}



/* FUNCTION 22363 ; VA 0x00ad5b30 ; FUN_00ad5b30 */

void FUN_00ad5b30(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  byte *pbVar4;
  undefined8 in_XMM0_Qa;
  longlong lVar5;
  longlong lVar6;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  pbVar4 = (byte *)*param_1;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("teleportStartMsSinceEpoch",0x19);
  pbVar4 = pbVar4 + *pbVar4 + 1;
  uVar1 = FUN_005702d0(auStack_40);
  FUN_00562fc0(&param_1,uVar1,auStack_40,-(uint)(pbVar4 != (byte *)0x0) & (uint)(pbVar4 + 1));
  if (0xf < uStack_2c) {
    uVar3 = uStack_2c + 1;
    uVar2 = auStack_40[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_40[0] - 4);
      uVar3 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  if ((param_1 == (undefined4 *)0x0) || (*(char *)(param_1[8] + 0x21) == '\0')) {
    if (DAT_01eeb4f0 != '\0') {
      FUN_016774b0();
    }
    ExceptionList = pvStack_10;
    return;
  }
  lVar5 = FUN_00563790();
  lVar6 = FUN_01682de0();
  param_1 = (undefined4 *)((ulonglong)(lVar6 - lVar5) >> 0x20);
  if (DAT_01eeb4f0 != '\0') {
    FUN_01677520(DAT_01eeb4f0,"Teleport completed in %lld ms",lVar6 - lVar5);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = 0;
  uStack_8 = 0;
  FUN_0058a190(0x3c);
  switch(param_2) {
  case 0:
    break;
  case 1:
    break;
  case 2:
    break;
  case 3:
    break;
  case 4:
    break;
  default:
    goto switchD_00ad5c63_caseD_5;
  }
  FUN_00554150();
switchD_00ad5c63_caseD_5:
  FUN_00554150();
  FUN_016f4020(0);
  FUN_00878cf0(auStack_28,in_XMM0_Qa);
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22364 ; VA 0x00ad5d30 ; FUN_00ad5d30 */

uint FUN_00ad5d30(undefined4 param_1,byte *param_2,byte *param_3,uint *param_4,byte *param_5,
                 byte *param_6)

{
  int *piVar1;
  byte *pbVar2;
  byte *pbVar3;
  uint uVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  byte *pbVar9;
  byte *pbVar10;
  double in_XMM0_Qa;
  byte abStack_fc [24];
  byte *pbStack_e4;
  undefined4 uStack_e0;
  int *piStack_dc;
  undefined *puStack_d8;
  byte abStack_d4 [8];
  undefined4 uStack_cc;
  byte *pbStack_c8;
  uint *puStack_c4;
  byte *pbStack_c0;
  byte *pbStack_bc;
  uint *puStack_b8;
  undefined8 uStack_b4;
  int aiStack_a0 [5];
  uint uStack_8c;
  undefined auStack_88 [24];
  byte *pbStack_70;
  undefined4 uStack_6c;
  int *piStack_68;
  byte abStack_64 [4];
  int *piStack_60;
  undefined auStack_5c [24];
  byte *pbStack_44;
  undefined4 uStack_40;
  int *piStack_3c;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pbVar2 = param_5;
  pbVar10 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e9dc6;
  pvStack_10 = ExceptionList;
  pbVar9 = param_5 + *param_5 + 1;
  uStack_b4 = (double)CONCAT44(param_2,0xad5d6a);
  ExceptionList = &pvStack_10;
  puStack_b8 = (uint *)FUN_005702d0();
  uStack_b4 = (double)CONCAT44(-(uint)(pbVar9 != (byte *)0x0) & (uint)(pbVar9 + 1),pbVar10);
  pbStack_bc = (byte *)&param_2;
  pbStack_c0 = (byte *)0xad5d81;
  FUN_008992d0();
  pbVar9 = param_6;
  puStack_b8 = (uint *)aiStack_a0;
  uStack_b4 = (double)CONCAT44("PercentageSuccesful_%d",param_6);
  pbStack_bc = (byte *)0xad5d96;
  FUN_00558ce0();
  pbStack_bc = (byte *)0x1949238;
  puStack_c4 = auStack_38;
  uStack_8 = 0;
  pbStack_c0 = pbVar9;
  pbStack_c8 = (byte *)0xad5dac;
  FUN_00558ce0();
  pbVar9 = param_2;
  uStack_8._0_1_ = 1;
  if ((param_2 == (byte *)0x0) || (*(int *)(param_2 + 0x20) == 0)) {
    uStack_b4 = (double)CONCAT44(auStack_38,aiStack_a0);
    puStack_b8 = (uint *)param_6;
    pbStack_bc = pbVar2;
    pbStack_c0 = param_3;
    puStack_c4 = param_4;
    pbStack_c8 = pbVar10;
    uStack_cc = 0xad5ee5;
    uVar4 = FUN_00ad0000();
    piVar1 = piStack_14;
    if ((char)uVar4 != '\0') {
      uStack_b4 = (double)CONCAT44(piStack_14,&uStack_18);
      puStack_b8 = (uint *)0xad5efd;
      FUN_0060e0c0();
      param_5 = (byte *)((int)DAT_01d665bc >> 0x1f);
      uStack_8._0_1_ = 2;
      param_6 = DAT_01d665bc;
      uStack_b4 = (double)CONCAT44(pbVar10,0xad5f1c);
      FUN_0054ef60();
      pbStack_70 = pbVar2;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        piStack_14[2] = piStack_14[2] + 1;
        UNLOCK();
      }
      uStack_6c = uStack_18;
      piStack_68 = piStack_14;
      uStack_8._0_1_ = 3;
      uStack_b4._4_4_ = piVar1;
      uStack_b4._0_4_ = 0xad5f3d;
      uVar5 = FUN_008f7870();
      uStack_b4 = (double)CONCAT44(uStack_b4._4_4_,uVar5);
      puStack_b8 = (uint *)abStack_64;
      pbStack_bc = (byte *)0xad5f47;
      FUN_005e5de0();
      uStack_b4 = (double)CONCAT44(&iStack_20,0xad5f55);
      FUN_00587490();
      uStack_8._0_1_ = 4;
      if (piStack_60 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_60[2] + -1;
        piStack_60[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          uStack_b4 = (double)CONCAT44(0xad5f71,(undefined4)uStack_b4);
          (**(code **)(*piStack_60 + 4))();
        }
      }
      if (iStack_20 == 0) {
        if (DAT_01eeb4f0 != 0) {
          puStack_b8 = (uint *)(uint)DAT_01eeb4f0;
          uStack_b4 = 1.31033442398154e-316;
          pbStack_bc = (byte *)0xad604f;
          FUN_016774b0();
        }
      }
      else {
        uStack_b4 = (double)CONCAT44(0xad5f84,(undefined4)uStack_b4);
        param_2 = (byte *)FUN_005cf2a0();
        uStack_b4 = (double)CONCAT44(0xad5f92,(undefined4)uStack_b4);
        FUN_016f4020();
        param_5 = abStack_d4;
        puStack_d8 = auStack_88;
        uStack_b4 = (double)((float)in_XMM0_Qa / DAT_018ce324);
        piStack_dc = (int *)0xad5fbd;
        FUN_0054ef60();
        pbStack_44 = pbStack_70;
        if (piStack_68 != (int *)0x0) {
          LOCK();
          piStack_68[2] = piStack_68[2] + 1;
          UNLOCK();
        }
        uStack_40 = uStack_6c;
        piStack_3c = piStack_68;
        puStack_d8 = (undefined *)0x0;
        param_6 = abStack_fc;
        uStack_8._0_1_ = 5;
        FUN_0054ef60(auStack_5c);
        pbStack_e4 = pbStack_44;
        if (piStack_3c != (int *)0x0) {
          LOCK();
          piStack_3c[2] = piStack_3c[2] + 1;
          UNLOCK();
        }
        piStack_dc = piStack_3c;
        uStack_e0 = uStack_40;
        FUN_00abfae0();
        uStack_8._0_1_ = 4;
        puStack_d8 = (undefined *)0xad602c;
        FUN_00ac7bb0();
        puStack_d8 = (undefined *)0xad6034;
        FUN_009eef30();
      }
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar6 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          uStack_b4 = (double)CONCAT44(0xad6068,(undefined4)uStack_b4);
          (**(code **)*piStack_1c)();
          LOCK();
          iVar6 = piStack_1c[2] + -1;
          piStack_1c[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            uStack_b4 = (double)CONCAT44(0xad6078,(undefined4)uStack_b4);
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
      uStack_b4 = (double)CONCAT44(0xad6083,(undefined4)uStack_b4);
      uVar4 = FUN_00ac7bb0();
      if (piStack_14 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_14 + 2;
        iVar6 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          uStack_b4 = (double)CONCAT44(0xad6096,(undefined4)uStack_b4);
          uVar4 = (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  else {
    piVar1 = (int *)(*(int *)(param_2 + 0x20) + 0x10);
    *piVar1 = *piVar1 + 1;
    piVar1 = *(int **)(*(int *)(param_2 + 0x20) + 8);
    uStack_b4 = (double)CONCAT44(aiStack_a0,(piVar1[1] - *piVar1) / 0xd0);
    puStack_b8 = *(uint **)(*(int *)(param_2 + 0x20) + 0x10);
    pbStack_bc = (byte *)0xad5df8;
    FUN_00ad9470();
    piVar1 = *(int **)(*(int *)(pbVar9 + 0x20) + 8);
    uVar4 = (piVar1[1] - *piVar1) / 0xd0;
    if (*(uint *)(*(int *)(pbVar9 + 0x20) + 0x10) == uVar4) {
      puStack_b8 = auStack_38;
      uStack_b4 = 4.94065645841247e-324;
      pbStack_bc = (byte *)0xad5e2d;
      FUN_008783f0();
      pbVar3 = param_5;
      param_2 = *(byte **)pbVar9;
      param_6 = *(byte **)(*(int *)(param_5 + 0x14) +
                          (*(uint *)(pbVar9 + 4) % *(uint *)(pbVar2 + 4)) * 4);
      for (pbVar10 = *(byte **)param_6; pbVar10 != pbVar9; pbVar10 = *(byte **)pbVar10) {
        param_6 = pbVar10;
      }
      param_5 = (byte *)(-(uint)(param_5 != (byte *)0xfffffffd) & (uint)(param_5 + 4));
      uVar8 = *(uint *)(pbVar9 + 4) % *(uint *)(pbVar2 + 4);
      do {
        *(undefined4 *)param_6 = *(undefined4 *)pbVar10;
        uStack_b4 = (double)CONCAT44(pbVar10 + 8,param_5);
        puStack_b8 = (uint *)0xad5e7e;
        FUN_005f53f0();
        puStack_b8 = (uint *)0x28;
        pbStack_c0 = (byte *)0xad5e86;
        pbStack_bc = pbVar10;
        FUN_01674ea0();
        *(int *)(pbVar3 + 8) = *(int *)(pbVar3 + 8) + -1;
        uVar7 = uVar8;
        if (*(int *)param_6 == 0) {
LAB_00ad5ea9:
          uVar4 = *(uint *)(pbVar3 + 0x14);
          if (*(byte **)(uVar4 + uVar8 * 4) == param_6) {
            *(undefined4 *)(uVar4 + uVar8 * 4) = 0;
          }
        }
        else {
          uVar7 = *(uint *)(*(int *)param_6 + 4);
          uVar4 = uVar7 / *(uint *)(pbVar3 + 4);
          uVar7 = uVar7 % *(uint *)(pbVar3 + 4);
          if (uVar8 != uVar7) {
            *(byte **)(*(int *)(pbVar3 + 0x14) + uVar7 * 4) = param_6;
            goto LAB_00ad5ea9;
          }
        }
        pbVar10 = *(byte **)param_6;
        uVar8 = uVar7;
      } while (pbVar10 != param_2);
    }
  }
  if (0xf < uStack_24) {
    uVar8 = uStack_24 + 1;
    uVar4 = auStack_38[0];
    if (0xfff < uVar8) {
      uVar4 = *(uint *)(auStack_38[0] - 4);
      uVar8 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar4) - 4) {
        uStack_b4 = (double)CONCAT44(0xad6126,(undefined4)uStack_b4);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_b4 = (double)CONCAT44(uVar8,uVar4);
    puStack_b8 = (uint *)0xad60c3;
    uVar4 = FUN_01674ea0();
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  if (0xf < uStack_8c) {
    uVar4 = uStack_8c + 1;
    iVar6 = aiStack_a0[0];
    if (0xfff < uVar4) {
      iVar6 = *(int *)(aiStack_a0[0] + -4);
      uVar4 = uStack_8c + 0x24;
      if (0x1f < (aiStack_a0[0] - iVar6) - 4U) {
        uStack_b4 = (double)CONCAT44(&UNK_00ad612b,(undefined4)uStack_b4);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_b4 = (double)CONCAT44(uVar4,iVar6);
    puStack_b8 = (uint *)0xad610b;
    uVar4 = FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 22365 ; VA 0x00ad6130 ; FUN_00ad6130 */

/* WARNING: Removing unreachable block (ram,0x00ad6190) */

void * FUN_00ad6130(undefined4 *param_1,int *param_2,undefined4 param_3,int *param_4,int param_5)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined uVar3;
  undefined4 *puVar4;
  void *pvVar5;
  undefined4 *****pppppuVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 ****ppppuVar9;
  uint uVar10;
  uint uVar11;
  longlong lVar12;
  undefined8 uVar13;
  undefined4 *puVar14;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  undefined4 ****ppppuStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 ****ppppuStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017e9e23;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_7 = 0;
  pvVar5 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_5 != 0) {
    ExceptionList = &pvStack_10;
    FUN_016799d0();
    lVar12 = FUN_01679e20(0,0,10000,0);
    pvVar5 = DAT_01eeb4e4;
    if (lVar12 <= (int)DAT_01eeb4e4) {
      uStack_48 = 0;
      uStack_44 = 0xf;
      auStack_58[0] = auStack_58[0] & 0xffffff00;
      uStack_8 = 2;
      puVar14 = (undefined4 *)param_1[1];
      for (param_1 = (undefined4 *)*param_1; param_1 != puVar14; param_1 = param_1 + 2) {
        puVar4 = (undefined4 *)FUN_01675640(&ppppuStack_28,"%lld, ",*param_1,param_1[1]);
        puVar1 = puVar4 + 4;
        uStack_8 = 3;
        if (0xf < (uint)puVar4[5]) {
          puVar4 = (undefined4 *)*puVar4;
        }
        FUN_00554150(puVar4,*puVar1);
        uStack_8 = 2;
        if (0xf < uStack_14) {
          uVar10 = uStack_14 + 1;
          ppppuVar9 = ppppuStack_28;
          if (0xfff < uVar10) {
            ppppuVar9 = (undefined4 ****)ppppuStack_28[-1];
            uVar10 = uStack_14 + 0x24;
            if (0x1f < (uint)((int)ppppuStack_28 + (-4 - (int)ppppuVar9))) goto LAB_00ad6628;
          }
          FUN_01674ea0(ppppuVar9,uVar10);
        }
      }
      uStack_30 = 0xf00000000;
      ppppuStack_40 = (undefined4 ****)((uint)ppppuStack_40 & 0xffffff00);
      uStack_8 = 4;
      pvVar5 = (void *)FUN_01531f50(&ppppuStack_40);
      if (2 < (uint)uStack_30) {
        uStack_18 = 0;
        uStack_14 = 0xf;
        ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
        if ((uint)uStack_30 == 0) {
          FUN_00554050();
LAB_00ad6637:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
        pppppuVar6 = &ppppuStack_40;
        if (0xf < uStack_30._4_4_) {
          pppppuVar6 = (undefined4 *****)ppppuStack_40;
        }
        FUN_005542c0((int)pppppuVar6 + 1,
                     (uint)uStack_30 - (2 - (uint)((uint)uStack_30 - 1 < (uint)uStack_30 - 2)));
        FUN_005507b0();
        ppppuStack_40 = ppppuStack_28;
        uStack_3c = uStack_24;
        uStack_38 = uStack_20;
        uStack_34 = uStack_1c;
        uStack_30 = CONCAT44(uStack_14,uStack_18);
        uStack_60 = *(undefined4 *)(param_5 + 0x440);
        uStack_5c = *(undefined4 *)(param_5 + 0x444);
        uStack_18 = 0;
        uStack_14 = 0xf;
        ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
        FUN_005542c0("UniverseId",10);
        puVar14 = &uStack_60;
        uStack_8 = 5;
        FUN_005c4c00(&ppppuStack_28);
        FUN_00632bc0(puVar14);
        uStack_8 = 4;
        if (0xf < uStack_14) {
          uVar10 = uStack_14 + 1;
          pppppuVar6 = (undefined4 *****)ppppuStack_28;
          if (0xfff < uVar10) {
            pppppuVar6 = (undefined4 *****)ppppuStack_28[-1];
            uVar10 = uStack_14 + 0x24;
            if (0x1f < (uint)((int)ppppuStack_28 + (-4 - (int)pppppuVar6))) goto LAB_00ad6637;
          }
          FUN_01674ea0(pppppuVar6,uVar10);
        }
        uStack_18 = 0;
        uStack_14 = 0xf;
        ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
        FUN_005542c0("groupTeleportGuid",0x11);
        uStack_8 = 6;
        iVar7 = FUN_005c4c00(&ppppuStack_28);
        uVar8 = FUN_0088cb40();
        *(undefined4 *)(iVar7 + 0x18) = uVar8;
        FUN_005c17a0(&ppppuStack_40);
        uStack_8 = 4;
        uVar3 = uStack_8;
        uStack_8 = 4;
        if (0xf < uStack_14) {
          uVar10 = uStack_14 + 1;
          ppppuVar9 = ppppuStack_28;
          if (0xfff < uVar10) {
            ppppuVar9 = (undefined4 ****)ppppuStack_28[-1];
            uVar10 = uStack_14 + 0x24;
            if (0x1f < (uint)((int)ppppuStack_28 + (-4 - (int)ppppuVar9))) {
              uStack_8 = uVar3;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(ppppuVar9,uVar10);
        }
        FUN_0151f6f0(0xffffffff,0,0);
        uStack_8 = 7;
        FUN_0151f850(&DAT_0194b310,"InitGroupTeleport");
        FUN_0151f950(&DAT_018cdcc0,&ppppuStack_40);
        FUN_0151fbb0("UniverseId",*(undefined4 *)(param_5 + 0x440),*(undefined4 *)(param_5 + 0x444))
        ;
        uStack_18 = 0;
        uStack_14 = 0xf;
        ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
        FUN_005542c0("placeId",7);
        uStack_8 = 8;
        FUN_0091d3d0(&ppppuStack_28);
        uVar13 = FUN_00563790();
        FUN_0151fbb0("DestinationPlaceId",uVar13);
        uStack_8 = 7;
        uVar3 = uStack_8;
        uStack_8 = 7;
        if (0xf < uStack_14) {
          uVar10 = uStack_14 + 1;
          ppppuVar9 = ppppuStack_28;
          if (0xfff < uVar10) {
            ppppuVar9 = (undefined4 ****)ppppuStack_28[-1];
            uVar10 = uStack_14 + 0x24;
            if (0x1f < (uint)((int)ppppuStack_28 + (-4 - (int)ppppuVar9))) {
              uStack_8 = uVar3;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(ppppuVar9,uVar10);
        }
        FUN_0151f950("UserId",auStack_58);
        uStack_18 = 0;
        uStack_14 = 0xf;
        ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
        FUN_005542c0("GroupTeleportLog",0x10);
        uStack_8 = 9;
        FUN_01520d20(&ppppuStack_28,10000,0);
        if (0xf < uStack_14) {
          uVar10 = uStack_14 + 1;
          ppppuVar9 = ppppuStack_28;
          if (0xfff < uVar10) {
            ppppuVar9 = (undefined4 ****)ppppuStack_28[-1];
            uVar10 = uStack_14 + 0x24;
            if (0x1f < (uint)((int)ppppuStack_28 + (-4 - (int)ppppuVar9))) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(ppppuVar9,uVar10);
        }
        pvVar5 = (void *)FUN_0151f7f0();
      }
      if (0xf < uStack_30._4_4_) {
        uVar10 = uStack_30._4_4_ + 1;
        pppppuVar6 = (undefined4 *****)ppppuStack_40;
        if (0xfff < uVar10) {
          pppppuVar6 = (undefined4 *****)ppppuStack_40[-1];
          uVar10 = uStack_30._4_4_ + 0x24;
          if (0x1f < (uint)((int)ppppuStack_40 + (-4 - (int)pppppuVar6))) {
LAB_00ad6628:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        pvVar5 = (void *)FUN_01674ea0(pppppuVar6,uVar10);
      }
      uStack_30 = 0xf00000000;
      ppppuStack_40 = (undefined4 ****)((uint)ppppuStack_40 & 0xffffff00);
      if (0xf < uStack_44) {
        uVar11 = uStack_44 + 1;
        uVar10 = auStack_58[0];
        if (0xfff < uVar11) {
          uVar10 = *(uint *)(auStack_58[0] - 4);
          uVar11 = uStack_44 + 0x24;
          if (0x1f < (auStack_58[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        pvVar5 = (void *)FUN_01674ea0(uVar10,uVar11);
      }
      auStack_58[0] = auStack_58[0] & 0xffffff00;
      uStack_44 = 0xf;
      uStack_48 = 0;
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar2 = param_2 + 1;
    iVar7 = *piVar2;
    pvVar5 = (void *)*piVar2;
    *piVar2 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar2 = param_2 + 2;
      iVar7 = *piVar2;
      pvVar5 = (void *)*piVar2;
      *piVar2 = iVar7 + -1;
      UNLOCK();
      if (iVar7 + -1 == 0) {
        pvVar5 = (void *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar2 = param_4 + 1;
    iVar7 = *piVar2;
    pvVar5 = (void *)*piVar2;
    *piVar2 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      pvVar5 = (void *)(**(code **)*param_4)();
      LOCK();
      piVar2 = param_4 + 2;
      iVar7 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        pvVar5 = (void *)(**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 22366 ; VA 0x00ad6650 ; FUN_00ad6650 */

void FUN_00ad6650(undefined4 *param_1)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  undefined uVar6;
  int aiStack_1c [5];
  uint uStack_8;
  
  uVar1 = *param_1;
  uVar3 = FUN_00b97eb0(aiStack_1c);
  cVar2 = FUN_00558b30(uVar3,uVar1);
  if (0xf < uStack_8) {
    uVar5 = uStack_8 + 1;
    iVar4 = aiStack_1c[0];
    if (0xfff < uVar5) {
      iVar4 = *(int *)(aiStack_1c[0] + -4);
      uVar5 = uStack_8 + 0x24;
      if (0x1f < (aiStack_1c[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  if (cVar2 != '\0') {
    uVar6 = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    FUN_00b9c950(uVar6);
  }
  return;
}



/* FUNCTION 22367 ; VA 0x00ad66f0 ; FUN_00ad66f0 */

void FUN_00ad66f0(void)

{
  FUN_00ac8f10();
  return;
}



/* FUNCTION 22368 ; VA 0x00ad6700 ; FUN_00ad6700 */

int FUN_00ad6700(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e9e38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    if (*(int *)(param_1 + 0xc) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(param_1 + 0xc) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    iVar3 = FUN_00acdfc0(*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc));
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 22369 ; VA 0x00ad67a0 ; FUN_00ad67a0 */

void FUN_00ad67a0(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  
  iVar2 = *param_1;
  uVar3 = *(undefined4 *)(iVar2 + 0x18);
  if (*(int *)(iVar2 + 0x20) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar2 + 0x20) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00ad0910(iVar2,uVar3,*(undefined4 *)(iVar2 + 0x1c),*(undefined4 *)(iVar2 + 0x20));
  return;
}



/* FUNCTION 22370 ; VA 0x00ad67f0 ; FUN_00ad67f0 */

void FUN_00ad67f0(undefined4 *param_1)

{
  FUN_00ac0dd0(param_1,*param_1,(int)&param_1 + 3,0);
  return;
}



/* FUNCTION 22371 ; VA 0x00ad6810 ; FUN_00ad6810 */

void FUN_00ad6810(undefined4 param_1,undefined4 param_2)

{
  FUN_00ac9150(param_2);
  return;
}



/* FUNCTION 22372 ; VA 0x00ad6830 ; FUN_00ad6830 */

/* WARNING: Removing unreachable block (ram,0x00ad6896) */
/* WARNING: Removing unreachable block (ram,0x00ad68a4) */
/* WARNING: Removing unreachable block (ram,0x00ad68cc) */
/* WARNING: Removing unreachable block (ram,0x00ad68b4) */

void FUN_00ad6830(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00ac9340(param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22373 ; VA 0x00ad68e0 ; FUN_00ad68e0 */

void FUN_00ad68e0(int *param_1)

{
  uint *puVar1;
  undefined4 uVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e9e60;
  pvStack_10 = ExceptionList;
  puVar1 = (uint *)*param_1;
  uVar3 = puVar1[9];
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(uVar3 + 4) = *(int *)(uVar3 + 4) + 1;
    UNLOCK();
    uVar3 = puVar1[9];
  }
  uStack_8 = 0;
  if (*puVar1 != 0) {
    (**(code **)((*puVar1 & 0xfffffffe) + 4))(puVar1 + 2,puVar1[8],uVar3);
    ExceptionList = pvStack_10;
    return;
  }
  uVar2 = FUN_0054fda0();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar2);
}



/* FUNCTION 22374 ; VA 0x00ad6970 ; FUN_00ad6970 */

void FUN_00ad6970(undefined4 *param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar1 = *param_1;
  param_1 = &param_2;
  ExceptionList = &pvStack_10;
  FUN_00ac0af0(param_1,uVar1,&param_1,0);
  if (0xf < in_stack_0000001c) {
    uVar3 = in_stack_0000001c + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22375 ; VA 0x00ad69f0 ; FUN_00ad69f0 */

void FUN_00ad69f0(int *param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_0000001c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  int iStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017e9e88;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  iVar2 = *param_1;
  uVar1 = *(undefined4 *)(iVar2 + 8);
  uStack_40 = 0;
  uVar3 = *(uint *)(iVar2 + 0x30);
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    uStack_40 = uVar3;
    if ((uVar3 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      iStack_4c = iVar2 + 0x38;
      uStack_50 = 0xad6a60;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    else {
      uStack_38 = *(undefined4 *)(iVar2 + 0x38);
      uStack_34 = *(undefined4 *)(iVar2 + 0x3c);
      uStack_30 = *(undefined4 *)(iVar2 + 0x40);
      uStack_2c = *(undefined4 *)(iVar2 + 0x44);
      uStack_28 = *(undefined8 *)(iVar2 + 0x48);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8._0_1_ = 1;
  uVar3 = *(uint *)(iVar2 + 0x10);
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(iVar2 + 0x18,&uStack_58,0);
    }
    else {
      uStack_58 = *(undefined4 *)(iVar2 + 0x18);
      uStack_54 = *(undefined4 *)(iVar2 + 0x1c);
      uStack_50 = *(undefined4 *)(iVar2 + 0x20);
      iStack_4c = *(int *)(iVar2 + 0x24);
      uStack_48 = *(ulonglong *)(iVar2 + 0x28);
    }
  }
  iStack_8._0_1_ = 2;
  FUN_0054ef60(&param_2);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_00ac9fe0(uVar1);
  if (0xf < in_stack_0000001c) {
    uVar3 = in_stack_0000001c + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
        uStack_28 = CONCAT44(&UNK_00ad6b11,(undefined4)uStack_28);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_28 = CONCAT44(uVar3,iVar2);
    uStack_2c = 0xad6af9;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22376 ; VA 0x00ad6b20 ; FUN_00ad6b20 */

void FUN_00ad6b20(int *param_1)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  char *pcVar6;
  char *pcVar7;
  undefined uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e9eb0;
  pvStack_10 = ExceptionList;
  iVar3 = *param_1;
  uVar4 = *(undefined4 *)(iVar3 + 8);
  uVar5 = *(uint *)(iVar3 + 0x18);
  ExceptionList = &pvStack_10;
  if ((uVar5 != 0) && (ExceptionList = &pvStack_10, (uVar5 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(uVar5 & 0xfffffffe))(iVar3 + 0x20);
  }
  if (*(int *)(iVar3 + 0x14) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar3 + 0x14) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  pcVar6 = *(char **)(iVar3 + 0xc);
  uStack_8 = 1;
  uVar8 = 0;
  pcVar7 = pcVar6;
  do {
    cVar2 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(pcVar6,(int)pcVar7 - (int)(pcVar6 + 1));
  uStack_8 = 0xffffffff;
  FUN_00aca170(uVar4,uVar8);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22377 ; VA 0x00ad6c20 ; FUN_00ad6c20 */

void FUN_00ad6c20(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e9ed0;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  uVar3 = *(undefined4 *)(iVar2 + 8);
  uVar4 = *(uint *)(iVar2 + 0x30);
  ExceptionList = &pvStack_10;
  if ((uVar4 != 0) && (ExceptionList = &pvStack_10, (uVar4 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(uVar4 & 0xfffffffe))(iVar2 + 0x38);
  }
  if (*(int *)(iVar2 + 0x28) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar2 + 0x28) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  FUN_0054ef60(iVar2 + 0xc);
  uStack_8 = 0xffffffff;
  FUN_00aca170(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22378 ; VA 0x00ad6cf0 ; FUN_00ad6cf0 */

void FUN_00ad6cf0(int *param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  iVar5 = *param_1;
  uVar2 = *(undefined4 *)(iVar5 + 8);
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  if (*(int *)(iVar5 + 0x18) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar5 + 0x18) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar3 = *(undefined4 *)(iVar5 + 0x14);
  uVar4 = *(undefined4 *)(iVar5 + 0x18);
  if (*(int *)(iVar5 + 0x10) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar5 + 0x10) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00aca2e0(uVar2,*(undefined4 *)(iVar5 + 0xc),*(undefined4 *)(iVar5 + 0x10),uVar3,uVar4);
  if (0xf < in_stack_0000001c) {
    uVar6 = in_stack_0000001c + 1;
    iVar5 = param_2;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(param_2 + -4);
      uVar6 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22379 ; VA 0x00ad6dd0 ; FUN_00ad6dd0 */

void FUN_00ad6dd0(int *param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  uint uVar8;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  iVar7 = *param_1;
  uVar2 = *(undefined4 *)(iVar7 + 8);
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  if (*(int *)(iVar7 + 0x20) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar7 + 0x20) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar3 = *(undefined4 *)(iVar7 + 0x1c);
  uVar4 = *(undefined4 *)(iVar7 + 0x20);
  if (*(int *)(iVar7 + 0x18) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar7 + 0x18) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar5 = *(undefined4 *)(iVar7 + 0x14);
  uVar6 = *(undefined4 *)(iVar7 + 0x18);
  if (*(int *)(iVar7 + 0x10) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar7 + 0x10) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00aca410(uVar2,*(undefined4 *)(iVar7 + 0xc),*(undefined4 *)(iVar7 + 0x10),uVar5,uVar6,uVar3,
               uVar4);
  if (0xf < in_stack_0000001c) {
    uVar8 = in_stack_0000001c + 1;
    iVar7 = param_2;
    if (0xfff < uVar8) {
      iVar7 = *(int *)(param_2 + -4);
      uVar8 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22380 ; VA 0x00ad6ed0 ; FUN_00ad6ed0 */

void FUN_00ad6ed0(undefined4 *param_1)

{
  FUN_00ac0c60(param_1,*param_1,&param_1,0);
  return;
}



/* FUNCTION 22381 ; VA 0x00ad6ef0 ; FUN_00ad6ef0 */

void FUN_00ad6ef0(undefined4 *param_1)

{
  FUN_00ac0dd0(param_1,*param_1,&param_1,0);
  return;
}



/* FUNCTION 22382 ; VA 0x00ad6f10 ; FUN_00ad6f10 */

void FUN_00ad6f10(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00ac94a0(param_2,param_3);
  return;
}



/* FUNCTION 22383 ; VA 0x00ad6f30 ; FUN_00ad6f30 */

void FUN_00ad6f30(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 *puVar8;
  uint uVar9;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 *in_stack_0000001c;
  int in_stack_0000002c;
  uint in_stack_00000030;
  undefined4 *in_stack_00000034;
  int in_stack_00000044;
  uint in_stack_00000048;
  undefined4 *in_stack_0000004c;
  int in_stack_0000005c;
  uint in_stack_00000060;
  int in_stack_00000064;
  int in_stack_00000068;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e9f18;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  if (in_stack_0000002c != 0) {
    ExceptionList = &pvStack_10;
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_0151f950(&DAT_018cdcc0,&stack0x0000001c);
    FUN_0151f950(&DAT_0194b310,&param_1);
    if (in_stack_00000044 != 0) {
      FUN_0151f950(&DAT_018c3d40,&stack0x00000034);
    }
    if (in_stack_0000005c != 0) {
      FUN_0151f950(&DAT_0194b318,&stack0x0000004c);
    }
    iVar2 = in_stack_00000068;
    iVar1 = in_stack_00000064;
    if (in_stack_00000064 != 0 || in_stack_00000068 != 0) {
      uVar3 = FUN_01675640(auStack_28,&DAT_018bed48,in_stack_00000064,in_stack_00000068);
      uStack_8._0_1_ = 5;
      FUN_0151f950("UserId",uVar3);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      FUN_005507b0();
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("GroupTeleportLog",0x10);
    uStack_8._0_1_ = 6;
    FUN_01520d20(auStack_28,10000,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (0xf < uStack_14) {
      uVar7 = uStack_14 + 1;
      uVar9 = auStack_28[0];
      if (0xfff < uVar7) {
        uVar9 = *(uint *)(auStack_28[0] - 4);
        uVar7 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar7);
    }
    if (DAT_01eeb4f0 != '\0') {
      puVar6 = &stack0x0000004c;
      if (0xf < in_stack_00000060) {
        puVar6 = in_stack_0000004c;
      }
      puVar8 = &stack0x00000034;
      if (0xf < in_stack_00000048) {
        puVar8 = in_stack_00000034;
      }
      puVar5 = &param_1;
      if (0xf < in_stack_00000018) {
        puVar5 = param_1;
      }
      puVar4 = &stack0x0000001c;
      if (0xf < in_stack_00000030) {
        puVar4 = in_stack_0000001c;
      }
      FUN_01677520(DAT_01eeb4f0,"GTInfluxDB guid:%s step:%s status:%s response:%s userId:%lld",
                   puVar4,puVar5,puVar8,puVar6,iVar1,iVar2);
    }
    FUN_0151f7f0();
  }
  if (0xf < in_stack_00000018) {
    uVar9 = in_stack_00000018 + 1;
    puVar6 = param_1;
    if (0xfff < uVar9) {
      puVar6 = (undefined4 *)param_1[-1];
      uVar9 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_1 + (-4 - (int)puVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar6,uVar9);
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = (undefined4 *)((uint)param_1 & 0xffffff00);
  if (0xf < in_stack_00000030) {
    uVar9 = in_stack_00000030 + 1;
    puVar6 = in_stack_0000001c;
    if (0xfff < uVar9) {
      puVar6 = (undefined4 *)in_stack_0000001c[-1];
      uVar9 = in_stack_00000030 + 0x24;
      if (0x1f < (uint)((int)in_stack_0000001c + (-4 - (int)puVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar6,uVar9);
  }
  in_stack_0000002c = 0;
  in_stack_00000030 = 0xf;
  in_stack_0000001c = (undefined4 *)((uint)in_stack_0000001c & 0xffffff00);
  if (0xf < in_stack_00000048) {
    uVar9 = in_stack_00000048 + 1;
    puVar6 = in_stack_00000034;
    if (0xfff < uVar9) {
      puVar6 = (undefined4 *)in_stack_00000034[-1];
      uVar9 = in_stack_00000048 + 0x24;
      if (0x1f < (uint)((int)in_stack_00000034 + (-4 - (int)puVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar6,uVar9);
  }
  in_stack_00000044 = 0;
  in_stack_00000048 = 0xf;
  in_stack_00000034 = (undefined4 *)((uint)in_stack_00000034 & 0xffffff00);
  if (0xf < in_stack_00000060) {
    uVar9 = in_stack_00000060 + 1;
    puVar6 = in_stack_0000004c;
    if (0xfff < uVar9) {
      puVar6 = (undefined4 *)in_stack_0000004c[-1];
      uVar9 = in_stack_00000060 + 0x24;
      if (0x1f < (uint)((int)in_stack_0000004c + (-4 - (int)puVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar6,uVar9);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22384 ; VA 0x00ad71f0 ; FUN_00ad71f0 */

undefined * FUN_00ad71f0(undefined4 ****param_1)

{
  int *piVar1;
  int *piVar2;
  undefined *puVar3;
  undefined4 ****ppppuVar4;
  int iVar5;
  byte *pbVar6;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  byte *in_stack_0000001c;
  int *in_stack_00000020;
  undefined4 ****in_stack_00000024;
  undefined4 in_stack_00000034;
  uint in_stack_00000038;
  int in_stack_0000003c;
  uint in_stack_00000050;
  undefined4 ****in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined auStack_90 [16];
  undefined4 uStack_80;
  undefined4 *puStack_7c;
  undefined auStack_78 [16];
  undefined4 uStack_68;
  undefined4 *puStack_64;
  undefined auStack_60 [12];
  undefined4 uStack_54;
  undefined **ppuStack_50;
  undefined4 uStack_4c;
  undefined4 ***pppuStack_48;
  undefined4 ***pppuStack_44;
  undefined4 ***apppuStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pbVar6 = in_stack_0000001c;
  puStack_c = &LAB_017e9f68;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  puVar3 = (undefined *)ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_0000001c != (byte *)0x0) {
    pppuStack_44 = (undefined4 ***)0x11;
    pppuStack_48 = (undefined4 ***)0x194a91c;
    uStack_28 = 0;
    uStack_24 = 0xf;
    apppuStack_38[0] = (undefined4 ***)((uint)apppuStack_38[0] & 0xffffff00);
    uStack_4c = 0xad7240;
    ExceptionList = &pvStack_10;
    FUN_005542c0();
    pbVar6 = pbVar6 + *pbVar6 + 1;
    pppuStack_44 = apppuStack_38;
    pppuStack_48 = (undefined4 ***)0xad7253;
    uStack_4c = FUN_005702d0();
    pppuStack_48 = apppuStack_38;
    pppuStack_44 = (undefined4 ***)(-(uint)(pbVar6 != (byte *)0x0) & (uint)(pbVar6 + 1));
    ppuStack_50 = &puStack_14;
    uStack_54 = 0xad726d;
    FUN_00562fc0();
    if (0xf < uStack_24) {
      pppuStack_44 = (undefined4 ***)(uStack_24 + 1);
      ppppuVar4 = (undefined4 ****)apppuStack_38[0];
      if (0xfff < pppuStack_44) {
        ppppuVar4 = (undefined4 ****)apppuStack_38[0][-1];
        pppuStack_44 = (undefined4 ***)(uStack_24 + 0x24);
        if (0x1f < (uint)((int)apppuStack_38[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
          pppuStack_44 = (undefined4 ***)0xad73fe;
          FUN_017167a3();
        }
      }
      uStack_4c = 0xad729e;
      pppuStack_48 = ppppuVar4;
      FUN_01674ea0();
    }
    puVar3 = puStack_14;
    if (puStack_14 != (undefined *)0x0) {
      pppuStack_44 = (undefined4 ***)in_stack_00000058;
      pppuStack_48 = in_stack_00000054;
      puStack_64 = &stack0x0000003c;
      puStack_14 = auStack_60;
      uStack_68 = 0xad72c2;
      FUN_0054ef60();
      puStack_18 = auStack_78;
      uStack_8._0_1_ = 4;
      puStack_7c = &stack0x00000024;
      uStack_80 = 0xad72d7;
      FUN_0054ef60();
      puStack_1c = auStack_90;
      uStack_8._0_1_ = 5;
      FUN_00563690(auStack_90);
      uStack_8._0_1_ = 6;
      FUN_0054ef60(&param_1);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      puVar3 = (undefined *)FUN_00ad6f30();
    }
  }
  if (0xf < in_stack_00000018) {
    pppuStack_44 = (undefined4 ***)(in_stack_00000018 + 1);
    ppppuVar4 = param_1;
    if (0xfff < pppuStack_44) {
      ppppuVar4 = (undefined4 ****)param_1[-1];
      pppuStack_44 = (undefined4 ***)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_1 + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
        pppuStack_44 = (undefined4 ***)0xad7403;
        FUN_017167a3();
      }
    }
    uStack_4c = 0xad733a;
    pppuStack_48 = ppppuVar4;
    puVar3 = (undefined *)FUN_01674ea0();
  }
  piVar2 = in_stack_00000020;
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = (undefined4 ****)((uint)param_1 & 0xffffff00);
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000020 + 1;
    iVar5 = *piVar1;
    puVar3 = (undefined *)*piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      pppuStack_44 = (undefined4 ***)0xad7368;
      puVar3 = (undefined *)(**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        pppuStack_44 = (undefined4 ***)0xad7377;
        puVar3 = (undefined *)(**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000038) {
    pppuStack_44 = (undefined4 ***)(in_stack_00000038 + 1);
    ppppuVar4 = in_stack_00000024;
    if (0xfff < pppuStack_44) {
      ppppuVar4 = (undefined4 ****)in_stack_00000024[-1];
      pppuStack_44 = (undefined4 ***)(in_stack_00000038 + 0x24);
      if (0x1f < (uint)((int)in_stack_00000024 + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
        pppuStack_44 = (undefined4 ***)0xad7408;
        FUN_017167a3();
      }
    }
    uStack_4c = 0xad73a4;
    pppuStack_48 = ppppuVar4;
    puVar3 = (undefined *)FUN_01674ea0();
  }
  in_stack_00000034 = 0;
  in_stack_00000038 = 0xf;
  in_stack_00000024 = (undefined4 ****)((uint)in_stack_00000024 & 0xffffff00);
  if (0xf < in_stack_00000050) {
    pppuStack_44 = (undefined4 ***)(in_stack_00000050 + 1);
    iVar5 = in_stack_0000003c;
    if (0xfff < pppuStack_44) {
      iVar5 = *(int *)(in_stack_0000003c + -4);
      pppuStack_44 = (undefined4 ***)(in_stack_00000050 + 0x24);
      if (0x1f < (in_stack_0000003c - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        pppuStack_44 = (undefined4 ***)&UNK_00ad740d;
        FUN_017167a3();
      }
    }
    uStack_4c = 0xad73e6;
    pppuStack_48 = (undefined4 ***)iVar5;
    puVar3 = (undefined *)FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return puVar3;
}



/* FUNCTION 22385 ; VA 0x00ad7410 ; FUN_00ad7410 */

void FUN_00ad7410(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00adb5f0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22386 ; VA 0x00ad7450 ; FUN_00ad7450 */

void FUN_00ad7450(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00adb720();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22387 ; VA 0x00ad7490 ; FUN_00ad7490 */

void FUN_00ad7490(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00adb7d0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22388 ; VA 0x00ad74d0 ; FUN_00ad74d0 */

void FUN_00ad74d0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00adb880();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22389 ; VA 0x00ad7510 ; FUN_00ad7510 */

void FUN_00ad7510(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ad57f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar4 = *param_1;
      ExceptionList = &pvStack_10;
      iVar3 = FUN_01674e20(0x1c);
      uStack_8 = 0;
      if (iVar3 == 0) {
        *param_2 = 0;
        ExceptionList = pvStack_10;
        return;
      }
      FUN_0054ef60(iVar4);
      *(undefined4 *)(iVar3 + 0x18) = *(undefined4 *)(iVar4 + 0x18);
      *param_2 = iVar3;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      piVar1 = (int *)*param_2;
      if (piVar1 != (int *)0x0) {
        uVar2 = piVar1[5];
        ExceptionList = &pvStack_10;
        if (0xf < uVar2) {
          iVar4 = *piVar1;
          uVar5 = uVar2 + 1;
          iVar3 = iVar4;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar4 + -4);
            uVar5 = uVar2 + 0x24;
            if (0x1f < (iVar4 - iVar3) - 4U) {
              ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          ExceptionList = &pvStack_10;
          FUN_01674ea0(iVar3,uVar5);
        }
        piVar1[4] = 0;
        piVar1[5] = 0xf;
        *(undefined *)piVar1 = 0;
        FUN_01674ea0(piVar1,0x1c);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dd2cb4);
      if (iVar4 != 0) {
        *param_2 = 0;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = *param_1;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_298c88fe0c3b3db72967872b108ea645>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 22390 ; VA 0x00ad76a0 ; FUN_00ad76a0 */

void FUN_00ad76a0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ad59f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x78);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00ac3b80(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00ac7a50();
        FUN_01674ea0(iVar2,0x78);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dd3e68);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_3be7f7301e600e8a5715d11cfded35bb>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 22391 ; VA 0x00ad77f0 ; FUN_00ad77f0 */

int * FUN_00ad77f0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[3] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 == 1) {
        piVar4 = (int *)param_1[3];
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar1 = piVar4 + 1;
          iVar2 = *piVar1;
          piVar3 = (int *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            piVar1 = piVar4 + 2;
            iVar2 = *piVar1;
            piVar3 = (int *)*piVar1;
            *piVar1 = iVar2 + -1;
            UNLOCK();
            if (iVar2 + -1 == 0) {
              piVar3 = (int *)(**(code **)(*piVar4 + 4))();
            }
          }
        }
        piVar4 = (int *)param_1[1];
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar1 = piVar4 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00ad78d9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
            piVar3 = (int *)(**(code **)(*piVar4 + 4))();
            return piVar3;
          }
        }
      }
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)FUN_0096efe0(0);
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dd4e2c);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_424a1149a94862a0056ae4e8bf82e871>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 22392 ; VA 0x00ad7900 ; FUN_00ad7900 */

void FUN_00ad7900(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4a6f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x24);
      uStack_8 = 0;
      if (iVar2 != 0) {
        FUN_0054ef60(iVar3);
        *(undefined4 *)(iVar2 + 0x18) = *(undefined4 *)(iVar3 + 0x18);
        *(undefined4 *)(iVar2 + 0x1c) = 0;
        *(undefined4 *)(iVar2 + 0x20) = 0;
        if (*(int *)(iVar3 + 0x20) != 0) {
          LOCK();
          piVar1 = (int *)(*(int *)(iVar3 + 0x20) + 8);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        *(undefined4 *)(iVar2 + 0x1c) = *(undefined4 *)(iVar3 + 0x1c);
        *(undefined4 *)(iVar2 + 0x20) = *(undefined4 *)(iVar3 + 0x20);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00ac7bb0();
        FUN_01674ea0(iVar3,0x24);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dd2cec);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_975cbeef57bf8444383415b381e962d8>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 22393 ; VA 0x00ad7a70 ; FUN_00ad7a70 */

void FUN_00ad7a70(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0462;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x88);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00ac4070(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00ac7c20();
        FUN_01674ea0(iVar2,0x88);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dd31d4);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_9d5455985c089d80b888c11af12dd352>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 22394 ; VA 0x00ad7bc0 ; FUN_00ad7bc0 */

int * FUN_00ad7bc0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[3] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 == 1) {
        piVar4 = (int *)param_1[3];
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar1 = piVar4 + 1;
          iVar2 = *piVar1;
          piVar3 = (int *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            piVar1 = piVar4 + 2;
            iVar2 = *piVar1;
            piVar3 = (int *)*piVar1;
            *piVar1 = iVar2 + -1;
            UNLOCK();
            if (iVar2 + -1 == 0) {
              piVar3 = (int *)(**(code **)(*piVar4 + 4))();
            }
          }
        }
        piVar4 = (int *)param_1[1];
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar1 = piVar4 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00ad7ca9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
            piVar3 = (int *)(**(code **)(*piVar4 + 4))();
            return piVar3;
          }
        }
      }
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)FUN_0096efe0(0);
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dd4df4);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_ed29e506bb03b159360c689b8407e0a1>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 22395 ; VA 0x00ad7cd0 ; FUN_00ad7cd0 */

void FUN_00ad7cd0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e9f92;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x80);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00ac4200(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00ac7d90();
        FUN_01674ea0(iVar2,0x80);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dd2d24);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_f05512fc1d86d43aff52fc4fdb4da510>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 22396 ; VA 0x00ad7e20 ; FUN_00ad7e20 */

void FUN_00ad7e20(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a17f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008c1490(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c3670();
        FUN_01674ea0(iVar2,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dd4d24);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<struct_boost::_bi::unspecified,class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::_bi::list1<class_boost::_bi::value<class_std::shared_ptr<struct_RBX::Reflection::Tuple>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 22397 ; VA 0x00ad7f70 ; FUN_00ad7f70 */

void FUN_00ad7f70(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c49af;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x30);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_008e72f0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uVar1 = *(uint *)(iVar3 + 0x10);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar3 + 0x18,iVar3 + 0x18,2);
            }
          }
          *(undefined4 *)(iVar3 + 0x10) = 0;
        }
        FUN_01674ea0(iVar3,0x30);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dd4954);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf2<void,class_RBX::TeleportService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::list3<class_boost::_bi::value<class_RBX::TeleportService*>,struct_boost::arg<1>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 22398 ; VA 0x00ad80e0 ; FUN_00ad80e0 */

void FUN_00ad80e0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a13f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x50);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        puVar2[1] = puVar1[1];
        FUN_00ac4d90(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0096ca80();
        FUN_01674ea0(iVar3,0x50);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dd4aec);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf3<void,class_RBX::TeleportService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::list4<class_boost::_bi::value<class_RBX::TeleportService*>,struct_boost::arg<1>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 22399 ; VA 0x00ad8240 ; FUN_00ad8240 */

void FUN_00ad8240(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b7ff;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x38);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        puVar2[1] = puVar1[1];
        FUN_00ac4f90(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00ac85c0();
        FUN_01674ea0(iVar3,0x38);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dd2d5c);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf3<void,class_RBX::TeleportService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_std::vector<__int64,class_std::allocator<__int64>_>_>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::list4<class_boost::_bi::value<class_RBX::TeleportService*>,class_boost::_bi::value<char_const*>,class_boost::_bi::value<class_std::shared_ptr<class_std::vector<__int64,class_std::allocator<__int64>_>_>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 22400 ; VA 0x00ad83a0 ; FUN_00ad83a0 */

void FUN_00ad83a0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cbc3f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_01674e20(0x50);
      uStack_8 = 0;
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = *puVar1;
        puVar3[1] = puVar1[1];
        FUN_00ac5050(puVar1 + 2);
        *param_2 = (int)puVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        uVar2 = *(uint *)(iVar4 + 0x30);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(iVar4 + 0x38,iVar4 + 0x38,2);
            }
          }
          *(undefined4 *)(iVar4 + 0x30) = 0;
        }
        FUN_00ac8540();
        FUN_01674ea0(iVar4,0x50);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dd2f7c);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf3<void,class_RBX::TeleportService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_std::vector<__int64,class_std::allocator<__int64>_>_>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::list4<class_boost::_bi::value<class_RBX::TeleportService*>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<class_std::shared_ptr<class_std::vector<__int64,class_std::allocator<__int64>_>_>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 22401 ; VA 0x00ad8530 ; FUN_00ad8530 */

void FUN_00ad8530(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      puVar2 = (undefined4 *)FUN_01674e20(0x20);
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        puVar2[1] = puVar1[1];
        FUN_00a66ab0(puVar1 + 2);
        *param_2 = (int)puVar2;
        return;
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        FUN_00a678e0();
        FUN_01674ea0(iVar3,0x20);
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dd3ea4);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        return;
      }
      *param_2 = 0;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf3<void,class_RBX::TeleportService,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::list4<class_boost::_bi::value<class_RBX::TeleportService*>,class_boost::_bi::value<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>_>,class_boost::_bi::value<class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 22402 ; VA 0x00ad8610 ; FUN_00ad8610 */

void FUN_00ad8610(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      iVar2 = FUN_01674e20(0x28);
      if (iVar2 != 0) {
        iVar3 = FUN_00ac4d40(iVar3);
        *param_2 = iVar3;
        return;
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        piVar1 = *(int **)(iVar3 + 0x20);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[1] + -1;
          piVar1[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar2 = piVar1[2] + -1;
            piVar1[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        FUN_00a678e0();
        FUN_01674ea0(iVar3,0x28);
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dd43d4);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        return;
      }
      *param_2 = 0;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf4<void,class_RBX::TeleportService,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>,class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::list5<class_boost::_bi::value<class_RBX::TeleportService*>,class_boost::_bi::value<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>_>,class_boost::_bi::value<class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>_>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::Instance>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 22403 ; VA 0x00ad8710 ; FUN_00ad8710 */

void FUN_00ad8710(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e9f92;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x80);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        puVar2[1] = puVar1[1];
        FUN_00ac6f20(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00ac87e0();
        FUN_01674ea0(iVar3,0x80);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dd386c);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf6<void,class_RBX::TeleportService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_std::vector<__int64,class_std::allocator<__int64>_>_>,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>,class_std::shared_ptr<class_RBX::Instance>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_boost::function<voi...decl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 22404 ; VA 0x00ad8870 ; FUN_00ad8870 */

void FUN_00ad8870(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e9fb2;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_01674e20(0x88);
      uStack_8 = 0;
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = *puVar1;
        puVar3[1] = puVar1[1];
        FUN_00ac7310(puVar1 + 2);
        *param_2 = (int)puVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        uVar2 = *(uint *)(iVar4 + 0x68);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(iVar4 + 0x70,iVar4 + 0x70,2);
            }
          }
          *(undefined4 *)(iVar4 + 0x68) = 0;
        }
        FUN_00ac8750();
        FUN_01674ea0(iVar4,0x88);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dd320c);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf7<void,class_RBX::TeleportService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_std::vector<__int64,class_std::allocator<__int64>_>_>,class_std::shared_ptr<class_RBX::Timer<0>_>,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>,class_std::shared_ptr<class_RBX::Instance>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::a...decl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 22405 ; VA 0x00ad8a00 ; FUN_00ad8a00 */

/* WARNING: Removing unreachable block (ram,0x00ad8b5c) */
/* WARNING: Removing unreachable block (ram,0x00ad8b0b) */
/* WARNING: Removing unreachable block (ram,0x00ad8b2e) */
/* WARNING: Removing unreachable block (ram,0x00ad8b82) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00ad8a00(int param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined *puVar4;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined uStack_12;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e9fd3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((((param_2 != 0) && (ExceptionList = &pvStack_10, *(char *)(param_1 + 0x58) == '\0')) &&
      (ExceptionList = &pvStack_10, iVar3 = FUN_008f7870(param_2), iVar1 = DAT_01eeb54c, iVar3 != 0)
      ) && (*(int *)(iVar3 + 0x4a0) == 1)) {
    uStack_1c = 0;
    uStack_18 = 0;
    *(int *)DAT_01eeb54c = DAT_01eeb54c;
    *(int *)(iVar1 + 4) = iVar1;
    iVar1 = DAT_01eeb570;
    *(int *)DAT_01eeb570 = DAT_01eeb570;
    *(int *)(iVar1 + 4) = iVar1;
    *(undefined4 *)DAT_01eeb574 = DAT_01eeb574;
    DAT_01eeb4f1 = 0;
    FUN_005587e0(&uStack_1c);
    FUN_00550b30();
    uStack_24 = 0;
    uStack_20 = 0;
    FUN_005587e0(&uStack_24);
    FUN_00550b30();
    DAT_01eeb588 = FUN_00888530();
    uStack_8 = 0;
    if (DAT_01eeb58c != 0) {
      (**(code **)(DAT_01eeb58c + 8))(&DAT_01eeb590);
      DAT_01eeb58c = 0;
    }
    FUN_00888530();
    uStack_8 = 1;
    puVar4 = (undefined *)FUN_005693e0(0xb,&uStack_12,&uStack_11,(int)&param_2 + 3);
    uStack_8 = 2;
    if (puVar4 != &DAT_01eeb658) {
      FUN_0057d3b0();
      _DAT_01eeb664 = *(undefined4 *)(puVar4 + 0xc);
      _DAT_01eeb668 = *(undefined4 *)(puVar4 + 0x10);
      _DAT_01eeb66c = *(undefined4 *)(puVar4 + 0x14);
      _DAT_01eeb65c = *(undefined4 *)(puVar4 + 4);
      _DAT_01eeb660 = *(undefined4 *)(puVar4 + 8);
      *(undefined4 *)(puVar4 + 0x14) = 0;
      *(undefined4 *)(puVar4 + 8) = 0;
      *(undefined4 *)(puVar4 + 0x10) = 0;
    }
    uStack_8 = 3;
    FUN_0057d3b0();
    uStack_8 = 0xffffffff;
    FUN_005542c0(&DAT_018bc9b8,0);
    FUN_005542c0(&DAT_018bc9b8,0);
  }
  FUN_008a4210(iVar2,param_3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22406 ; VA 0x00ad8c60 ; FUN_00ad8c60 */

int * FUN_00ad8c60(int *param_1,int param_2)

{
  uint *puVar1;
  uint uVar2;
  byte bVar3;
  bool bVar4;
  char cVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 ****ppppuVar9;
  int *piVar10;
  undefined4 *puVar11;
  int *piVar12;
  int iVar13;
  int *piVar14;
  undefined4 extraout_ECX;
  longlong lVar15;
  longlong lVar16;
  char *pcVar17;
  undefined auStack_164 [200];
  undefined auStack_9c [24];
  undefined auStack_84 [8];
  undefined auStack_7c [24];
  undefined4 ***apppuStack_64 [4];
  undefined4 uStack_54;
  uint uStack_50;
  undefined auStack_4c [8];
  byte *pbStack_44;
  int *piStack_40;
  undefined auStack_3c [8];
  int iStack_34;
  undefined auStack_30 [8];
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar13 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ea03e;
  pvStack_10 = ExceptionList;
  if (*param_1 == 0) {
    return param_1;
  }
  if (*(int *)(param_2 + 0x10) == 0) {
    return param_1;
  }
  ExceptionList = &pvStack_10;
  FUN_00563d90(&pbStack_44);
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  cVar5 = FUN_0098f070(iVar13,&pbStack_44,0);
  if (cVar5 == '\0') {
    piVar14 = (int *)(uint)DAT_01eeb4f0;
    if (DAT_01eeb4f0 == 0) goto LAB_00ad9424;
    pcVar17 = "onUserJoin parse teleportData failed";
  }
  else {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = 0;
    FUN_005542c0(&DAT_0194a144,4);
    bVar3 = *pbStack_44;
    uVar6 = FUN_005702d0(auStack_28);
    FUN_00562fc0(&param_2,uVar6,auStack_28,
                 -(uint)(pbStack_44 + bVar3 + 1 != (byte *)0x0) & (uint)(pbStack_44 + bVar3 + 1 + 1)
                );
    FUN_005507b0();
    if ((param_2 != 0) &&
       (iVar13 = *(int *)(param_2 + 0x20), iVar7 = FUN_0088cb40(), iVar13 == iVar7)) {
      FUN_00563690(auStack_9c);
      bVar4 = false;
      uStack_54 = 0;
      uStack_50 = 0xf;
      apppuStack_64[0] = (undefined4 ***)((uint)apppuStack_64[0] & 0xffffff00);
      uStack_8._0_1_ = 2;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("joinData",8);
      FUN_00580040(&param_2,auStack_28);
      FUN_005507b0();
      if ((param_2 == 0) ||
         (iVar13 = *(int *)(param_2 + 0x20), iVar7 = FUN_0088cb40(), iVar13 != iVar7)) {
        uStack_18 = 0;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        FUN_005542c0("partyData",9);
        FUN_00580040(&param_2,auStack_28);
        FUN_005507b0();
        if ((param_2 != 0) &&
           (iVar13 = *(int *)(param_2 + 0x20), iVar7 = FUN_0088cb40(), iVar13 == iVar7)) {
          uVar6 = FUN_00563690(auStack_7c);
          FUN_005511f0(uVar6);
          FUN_005507b0();
          bVar4 = true;
          goto LAB_00ad8e56;
        }
        if (DAT_01eeb4f0 != 0) {
          pcVar17 = "onUserJoin no joinData";
          goto LAB_00ad93e7;
        }
      }
      else {
        uVar6 = FUN_00563690(auStack_7c);
        FUN_005511f0(uVar6);
        FUN_005507b0();
LAB_00ad8e56:
        uVar8 = FUN_00ad5a70(auStack_28);
        uStack_8._0_1_ = 3;
        uVar6 = extraout_ECX;
        FUN_0056a3e0(uVar8);
        ppppuVar9 = apppuStack_64;
        if (0xf < uStack_50) {
          ppppuVar9 = (undefined4 ****)apppuStack_64[0];
        }
        uVar6 = FUN_01530cc0(auStack_7c,ppppuVar9,uStack_54,uVar6);
        cVar5 = FUN_00558b30(auStack_9c,uVar6);
        FUN_005507b0();
        uStack_8._0_1_ = 2;
        FUN_005507b0();
        if (cVar5 == '\0') {
          if (DAT_01eeb4f0 != 0) {
            pcVar17 = "onUserJoin failed in verifying joinData";
LAB_00ad93e7:
            FUN_016774b0(DAT_01eeb4f0,pcVar17,0);
          }
        }
        else {
          FUN_00563d90(auStack_30);
          uStack_8._0_1_ = 4;
          cVar5 = FUN_0098f070(apppuStack_64,auStack_30,0);
          if (cVar5 == '\0') {
            if (DAT_01eeb4f0 != 0) {
              pcVar17 = "onUserJoin parse joinData error";
LAB_00ad93c1:
              FUN_016774b0(DAT_01eeb4f0,pcVar17,0);
            }
          }
          else {
            if (bVar4) {
              uVar6 = FUN_00ad1120(auStack_84,auStack_30);
              FUN_005587e0(uVar6);
              FUN_00550b30();
            }
            uStack_18 = 0;
            uStack_14 = 0xf;
            auStack_28[0] = 0;
            FUN_005542c0("userId",6);
            FUN_00580040(&param_2,auStack_28);
            FUN_005507b0();
            if ((param_2 == 0) || (*(char *)(*(int *)(param_2 + 0x20) + 0x21) == '\0')) {
              if (DAT_01eeb4f0 != 0) {
                pcVar17 = "onUserJoin no userId";
                goto LAB_00ad93c1;
              }
            }
            else {
              lVar15 = FUN_00563790();
              piVar14 = param_1;
              lVar16 = FUN_00928340();
              if (lVar15 == lVar16) {
                uStack_18 = 0;
                uStack_14 = 0xf;
                auStack_28[0] = 0;
                FUN_005542c0("accountAge",10);
                FUN_00580040(&param_1,auStack_28);
                FUN_005507b0();
                piVar12 = param_1;
                if ((param_1 == (int *)0x0) || (*(char *)(param_1[8] + 0x21) == '\0')) {
                  if (DAT_01eeb4f0 != 0) {
                    pcVar17 = "onUserJoin no accountAge";
                    goto LAB_00ad93c1;
                  }
                }
                else {
                  iVar13 = param_1[8];
                  iVar7 = FUN_0088c8c0();
                  if (iVar13 == iVar7) {
                    iVar13 = piVar12[8];
                    iVar7 = FUN_0088c8c0();
                    if (iVar13 != iVar7) {
                    /* WARNING: Subroutine does not return */
                      FUN_016757c0("Variant cast failed");
                    }
                    piVar10 = piVar12 + 10;
                    if (piVar12[9] == 0) {
                      piVar10 = (int *)0x0;
                    }
                    iVar13 = *piVar10;
                  }
                  else {
                    puVar11 = (undefined4 *)piVar12[9];
                    if (puVar11 != (undefined4 *)0x0) {
                      (*(code *)*puVar11)(piVar12 + 10,auStack_164);
                      puVar11 = (undefined4 *)piVar12[9];
                    }
                    uStack_8._0_1_ = 5;
                    piVar12 = (int *)FUN_00889220();
                    iVar13 = *piVar12;
                    uStack_8._0_1_ = 6;
                    if (puVar11 != (undefined4 *)0x0) {
                      (*(code *)puVar11[2])(auStack_164);
                    }
                    uStack_8._0_1_ = 4;
                  }
                  iVar7 = *(int *)(*piVar14 + 0x454);
                  if ((iVar13 == iVar7) || (iVar13 == iVar7 + -1)) {
                    uStack_18 = 0;
                    uStack_14 = 0xf;
                    auStack_28[0] = 0;
                    FUN_005542c0("userData",8);
                    FUN_00580040(&param_1,auStack_28);
                    FUN_005507b0();
                    if ((param_1 != (int *)0x0) &&
                       (iVar13 = param_1[8], iVar7 = FUN_008881d0(), iVar13 == iVar7)) {
                      uVar6 = FUN_0055d640();
                      FUN_00557fc0(uVar6);
                      uStack_8._0_1_ = 7;
                      uStack_18 = 0;
                      uStack_14 = 0xf;
                      auStack_28[0] = 0;
                      FUN_005542c0("internalData",0xc);
                      FUN_00580040(&param_1,auStack_28);
                      FUN_005507b0();
                      if ((param_1 == (int *)0x0) ||
                         (iVar13 = param_1[8], iVar7 = FUN_008881d0(), iVar13 != iVar7)) {
                        if (DAT_01eeb4f0 != 0) {
                          FUN_016774b0(DAT_01eeb4f0,"onUserJoin no internalData",0);
                        }
                        FUN_00550b30();
                        FUN_00550b30();
                        goto LAB_00ad93f3;
                      }
                      uVar6 = FUN_0055d640();
                      FUN_00557fc0(uVar6);
                      uStack_8._0_1_ = 8;
                      FUN_00933b50(auStack_3c,auStack_4c);
                      uStack_18 = 0;
                      uStack_14 = 0xf;
                      auStack_28[0] = 0;
                      FUN_005542c0("teleportType",0xc);
                      FUN_00580040(&param_1,auStack_28);
                      FUN_005507b0();
                      if (param_1 != (int *)0x0) {
                        uStack_18 = 0;
                        uStack_14 = 0xf;
                        auStack_28[0] = 0;
                        FUN_005542c0(&DAT_018d2348,4);
                        FUN_00580040(&param_1,auStack_28);
                        FUN_005507b0();
                        if (param_1 == (int *)0x0) {
                          if (DAT_01eeb4f0 != 0) {
                            FUN_016774b0(DAT_01eeb4f0,
                                         "guid is missing. cannot record group teleport metrics.",0)
                            ;
                            FUN_00550b30();
                            FUN_00550b30();
                            FUN_00550b30();
                            goto LAB_00ad93f3;
                          }
                        }
                        else {
                          FUN_00563690(auStack_7c);
                          uStack_8._0_1_ = 9;
                          iVar13 = FUN_00ac3380();
                          if (iVar13 == 2) {
                            uStack_18 = 0;
                            uStack_14 = 0xf;
                            auStack_28[0] = 0;
                            FUN_005542c0("TeleportPrivateServer",0x15);
                            uStack_8._0_1_ = 10;
                            iStack_34 = iStack_34 + 0xf4;
LAB_00ad92f3:
                            FUN_00ad5d30(piVar14,auStack_7c,auStack_3c,auStack_4c,iStack_34,
                                         auStack_28);
                            uStack_8._0_1_ = 9;
                            FUN_005507b0();
                          }
                          else if (iVar13 == 3) {
                            uStack_18 = 0;
                            uStack_14 = 0xf;
                            auStack_28[0] = 0;
                            FUN_005542c0("TeleportPartyAsync",0x12);
                            uStack_8._0_1_ = 0xb;
                            iStack_34 = iStack_34 + 0xdc;
                            goto LAB_00ad92f3;
                          }
                          if (DAT_01d66678 != '\0') {
                            FUN_00ad5b30(auStack_30,iVar13);
                          }
                          FUN_005507b0();
                        }
                      }
                      FUN_00550b30();
                      FUN_00550b30();
                      FUN_00550b30();
                      goto LAB_00ad93f3;
                    }
                    if (DAT_01eeb4f0 != 0) {
                      pcVar17 = "onUserJoin no userData";
                      goto LAB_00ad93c1;
                    }
                  }
                  else if (DAT_01eeb4f0 != 0) {
                    pcVar17 = "onUserJoin invalid accountAge";
                    goto LAB_00ad93c1;
                  }
                }
              }
              else if (DAT_01eeb4f0 != 0) {
                pcVar17 = "onUserJoin invalid userId";
                goto LAB_00ad93c1;
              }
            }
          }
          FUN_00550b30();
        }
      }
LAB_00ad93f3:
      FUN_005507b0();
      piVar14 = (int *)FUN_005507b0();
      goto LAB_00ad9424;
    }
    piVar14 = (int *)(uint)DAT_01eeb4f0;
    if (DAT_01eeb4f0 == 0) goto LAB_00ad9424;
    pcVar17 = "onUserJoin corrupted auth token";
  }
  piVar14 = (int *)FUN_016774b0(piVar14,pcVar17,0);
LAB_00ad9424:
  if (piStack_40 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_40 + 1);
    uVar2 = *puVar1;
    piVar14 = (int *)*puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      piVar14 = (int *)(**(code **)*piStack_40)();
      LOCK();
      piVar12 = piStack_40 + 2;
      iVar13 = *piVar12;
      *piVar12 = *piVar12 + -1;
      UNLOCK();
      if (iVar13 == 1) {
        piVar14 = (int *)(**(code **)(*piStack_40 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar14;
}



/* FUNCTION 22407 ; VA 0x00ad9470 ; FUN_00ad9470 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00ad9470(int param_1,int param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  double *pdVar4;
  float10 fVar5;
  int aiStack_44 [5];
  uint uStack_30;
  undefined8 uStack_2c;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  double dStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8af8;
  pvStack_10 = ExceptionList;
  if (0xf < (uint)param_3[5]) {
    param_3 = (undefined4 *)*param_3;
  }
  pdVar4 = (double *)&uStack_2c;
  uStack_2c._0_4_ = _DAT_0194b5a0;
  uStack_2c._4_4_ = _UNK_0194b5a4;
  uStack_24 = _UNK_0194b5a8;
  uStack_20 = _UNK_0194b5ac;
  uStack_1c = 100;
  ExceptionList = &pvStack_10;
  do {
    iVar2 = *(int *)pdVar4;
    dStack_18 = ((double)iVar2 / DAT_018ce318) * (double)param_2;
    fVar5 = (float10)FUN_01725160(dStack_18);
    dStack_18 = (double)fVar5;
    if ((int)fVar5 == param_1) {
      uVar1 = FUN_01675640(aiStack_44,param_3,iVar2);
      uStack_8 = 0;
      FUN_008783f0(uVar1,1,0);
      uStack_8 = 0xffffffff;
      if (0xf < uStack_30) {
        uVar3 = uStack_30 + 1;
        iVar2 = aiStack_44[0];
        if (0xfff < uVar3) {
          iVar2 = *(int *)(aiStack_44[0] + -4);
          uVar3 = uStack_30 + 0x24;
          if (0x1f < (aiStack_44[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar2,uVar3);
      }
    }
    pdVar4 = (double *)((int)pdVar4 + 4);
  } while (pdVar4 != &dStack_18);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22408 ; VA 0x00ad9570 ; FUN_00ad9570 */

void FUN_00ad9570(undefined *param_1,int *param_2,undefined4 param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  
  if (param_1 == &DAT_021281e0) {
    if (0xcf < (param_2[1] - *param_2) - 0x270U) {
      return;
    }
    iVar1 = *(int *)*param_2;
    iVar3 = FUN_0088cdc0();
    if (iVar1 != iVar3) {
      return;
    }
    cVar2 = FUN_00c60280(*param_2,param_3);
    if (cVar2 == '\0') {
      return;
    }
  }
  if (param_1 == &DAT_02128258) {
    if (0xcf < (param_2[1] - *param_2) - 0x1a0U) {
      return;
    }
    iVar1 = *(int *)*param_2;
    iVar3 = FUN_0088cdc0();
    if (iVar1 != iVar3) {
      return;
    }
    cVar2 = FUN_00c60280(*param_2,param_3);
    if (cVar2 == '\0') {
      return;
    }
  }
  FUN_009cba80(param_1,param_2,param_3);
  return;
}



/* FUNCTION 22409 ; VA 0x00ad9610 ; FUN_00ad9610 */

void FUN_00ad9610(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  byte bVar3;
  int iVar4;
  undefined uVar5;
  char cVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 *puVar9;
  uint uVar10;
  uint uVar11;
  int *piVar12;
  byte *pbVar13;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 *in_stack_0000001c;
  int *in_stack_00000020;
  uint in_stack_00000024;
  undefined auStack_140 [200];
  undefined auStack_78 [24];
  uint auStack_60 [4];
  int iStack_50;
  uint uStack_4c;
  int *piStack_48;
  int *piStack_44;
  byte *pbStack_40;
  int *piStack_3c;
  int *piStack_38;
  byte *pbStack_34;
  int *piStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ea09b;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("GroupTeleportInitiatedFailed",0x1c);
  uStack_8._0_1_ = 3;
  FUN_008783f0(auStack_2c,1,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (0xf < uStack_18) {
    uVar10 = uStack_18 + 1;
    uVar11 = auStack_2c[0];
    if (0xfff < uVar10) {
      uVar11 = *(uint *)(auStack_2c[0] - 4);
      uVar10 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar10);
  }
  if (in_stack_0000001c != (undefined4 *)0x0) {
    puVar9 = (undefined4 *)*in_stack_0000001c;
    uVar10 = 0;
    uVar11 = (uint)((int)in_stack_0000001c[1] + (7 - (int)puVar9)) >> 3;
    if ((undefined4 *)in_stack_0000001c[1] < puVar9) {
      uVar11 = 0;
    }
    if (uVar11 != 0) {
      iStack_14 = iStack_14 + 0xc4;
      do {
        pbStack_34 = (byte *)*puVar9;
        piStack_30 = (int *)puVar9[1];
        FUN_009b12c0(&pbStack_34);
        puVar9 = puVar9 + 2;
        uVar10 = uVar10 + 1;
      } while (uVar10 != uVar11);
    }
  }
  iStack_50 = 0;
  uStack_4c = 0xf;
  auStack_60[0] = auStack_60[0] & 0xffffff00;
  uStack_8._0_1_ = 4;
  FUN_00563d90(&pbStack_40);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  cVar6 = FUN_0098f070(&param_1,&pbStack_40,0);
  if (cVar6 != '\0') {
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("errors",6);
    bVar3 = *pbStack_40;
    uVar7 = FUN_005702d0(auStack_2c);
    FUN_00562fc0(&iStack_14,uVar7,auStack_2c,
                 -(uint)(pbStack_40 + bVar3 + 1 != (byte *)0x0) & (uint)(pbStack_40 + bVar3 + 1 + 1)
                );
    if (0xf < uStack_18) {
      uVar10 = uStack_18 + 1;
      uVar11 = auStack_2c[0];
      if (0xfff < uVar10) {
        uVar11 = *(uint *)(auStack_2c[0] - 4);
        uVar10 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar10);
    }
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    if ((iStack_14 != 0) &&
       (iVar4 = *(int *)(iStack_14 + 0x20), iVar8 = FUN_008882f0(), iVar4 == iVar8)) {
      FUN_00636130(&piStack_48);
      if (piStack_48 != (int *)0x0) {
        piVar12 = (int *)*piStack_48;
        piStack_38 = (int *)piStack_48[1];
        if (piVar12 != piStack_38) {
          do {
            uStack_8._0_1_ = 6;
            puVar9 = (undefined4 *)piVar12[1];
            iVar4 = *piVar12;
            if (puVar9 != (undefined4 *)0x0) {
              (*(code *)*puVar9)(piVar12 + 2,auStack_140);
              puVar9 = (undefined4 *)piVar12[1];
            }
            uStack_8._0_1_ = 7;
            iVar8 = FUN_008881d0();
            if (iVar4 == iVar8) {
              FUN_00636000(&pbStack_34);
              piVar2 = piStack_30;
              pbVar13 = pbStack_34;
              uStack_8._0_1_ = 9;
              uVar5 = (undefined)uStack_8;
              uStack_8._0_1_ = 9;
              if (pbStack_34 == (byte *)0x0) {
                if (piStack_30 != (int *)0x0) {
                  LOCK();
                  iVar4 = piStack_30[1] + -1;
                  piStack_30[1] = iVar4;
                  UNLOCK();
                  if (iVar4 == 0) {
                    (**(code **)*piStack_30)();
                    LOCK();
                    piVar1 = piVar2 + 2;
                    iVar4 = *piVar1 + -1;
                    *piVar1 = iVar4;
                    UNLOCK();
                    if (iVar4 == 0) {
                      (**(code **)(*piVar2 + 4))();
                    }
                  }
                }
                uStack_8 = CONCAT31(uStack_8._1_3_,10);
              }
              else {
                uStack_1c = 0;
                uStack_18 = 0xf;
                auStack_2c[0] = auStack_2c[0] & 0xffffff00;
                uStack_8._0_1_ = uVar5;
                FUN_005542c0("message",7);
                pbVar13 = pbVar13 + *pbVar13 + 1;
                uVar7 = FUN_005702d0(auStack_2c);
                FUN_00562fc0(&iStack_14,uVar7,auStack_2c,
                             -(uint)(pbVar13 != (byte *)0x0) & (uint)(pbVar13 + 1));
                FUN_005507b0();
                if ((iStack_14 != 0) &&
                   (iVar4 = *(int *)(iStack_14 + 0x20), iVar8 = FUN_0088cb40(), iVar4 == iVar8)) {
                  uVar7 = FUN_00563690(auStack_78);
                  FUN_005511f0(uVar7);
                  FUN_005507b0();
                  FUN_00550b30();
                  uStack_8._0_1_ = 0xb;
                  if (puVar9 != (undefined4 *)0x0) {
                    (*(code *)puVar9[2])(auStack_140);
                  }
                  break;
                }
                piVar2 = piStack_30;
                if (piStack_30 != (int *)0x0) {
                  LOCK();
                  iVar4 = piStack_30[1] + -1;
                  piStack_30[1] = iVar4;
                  UNLOCK();
                  if (iVar4 == 0) {
                    (**(code **)*piStack_30)();
                    LOCK();
                    piVar1 = piVar2 + 2;
                    iVar4 = *piVar1 + -1;
                    *piVar1 = iVar4;
                    UNLOCK();
                    if (iVar4 == 0) {
                      (**(code **)(*piVar2 + 4))();
                    }
                  }
                }
                uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
              }
            }
            else {
              uStack_8 = CONCAT31(uStack_8._1_3_,8);
            }
            if (puVar9 != (undefined4 *)0x0) {
              (*(code *)puVar9[2])(auStack_140);
            }
            piVar12 = piVar12 + 0x34;
          } while (piVar12 != piStack_38);
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      if (piStack_44 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_44[1] + -1;
        piStack_44[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_44)();
          LOCK();
          iVar4 = piStack_44[2] + -1;
          piStack_44[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piStack_44 + 4))();
          }
        }
      }
      if (iStack_50 != 0) goto LAB_00ad9a01;
    }
  }
  puVar9 = &param_1;
  if (0xf < in_stack_00000018) {
    puVar9 = param_1;
  }
  FUN_005542c0(puVar9,in_stack_00000014);
LAB_00ad9a01:
  FUN_0054ef60(auStack_60);
  FUN_005e65e0();
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      iVar4 = piStack_3c[2] + -1;
      piStack_3c[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
  }
  uStack_8._0_1_ = 2;
  if (0xf < uStack_4c) {
    uVar10 = uStack_4c + 1;
    uVar11 = auStack_60[0];
    if (0xfff < uVar10) {
      uVar11 = *(uint *)(auStack_60[0] - 4);
      uVar10 = uStack_4c + 0x24;
      if (0x1f < (auStack_60[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar10);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < in_stack_00000018) {
    uVar11 = in_stack_00000018 + 1;
    puVar9 = param_1;
    if (0xfff < uVar11) {
      puVar9 = (undefined4 *)param_1[-1];
      uVar11 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_1 + (-4 - (int)puVar9))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar9,uVar11);
  }
  piVar12 = in_stack_00000020;
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = (undefined4 *)((uint)param_1 & 0xffffff00);
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    iVar4 = in_stack_00000020[1] + -1;
    in_stack_00000020[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*in_stack_00000020)();
      LOCK();
      piVar2 = piVar12 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar12 + 4))();
      }
    }
  }
  uStack_8 = 0xd;
  if (((in_stack_00000024 != 0) && ((in_stack_00000024 & 1) == 0)) &&
     (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000024 & 0xfffffffe))(&stack0x0000002c,&stack0x0000002c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22410 ; VA 0x00ad9b40 ; FUN_00ad9b40 */

void __thiscall FUN_00ad9b40(int param_1,uint param_2)

{
  byte bVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  uint *puVar6;
  int *piVar7;
  int iVar8;
  uint uVar9;
  undefined4 *puVar10;
  byte *pbVar11;
  uint uVar12;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint *in_stack_0000001c;
  int *in_stack_00000020;
  int *in_stack_00000028;
  int *in_stack_00000030;
  uint in_stack_00000034;
  uint in_stack_00000054;
  undefined *puVar13;
  undefined *puVar14;
  uint in_stack_ffffff18;
  undefined4 in_stack_ffffff1c;
  undefined4 *puVar15;
  undefined4 uVar16;
  int *piVar17;
  undefined4 uVar18;
  byte **ppbVar19;
  undefined4 uVar20;
  undefined4 uVar21;
  undefined4 uVar22;
  undefined4 uVar23;
  undefined auStack_c8 [16];
  int iStack_b8;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  undefined8 uStack_a0;
  undefined auStack_98 [16];
  undefined4 uStack_88;
  undefined4 uStack_84;
  uint auStack_80 [4];
  undefined4 uStack_70;
  uint uStack_6c;
  int iStack_68;
  uint auStack_64 [3];
  undefined auStack_58 [4];
  undefined4 uStack_54;
  int *piStack_50;
  byte *pbStack_4c;
  int *piStack_48;
  undefined4 uStack_44;
  uint uStack_40;
  int *piStack_3c;
  uint uStack_38;
  undefined auStack_34 [16];
  undefined4 uStack_24;
  undefined4 uStack_20;
  char cStack_19;
  undefined auStack_18 [4];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ea18a;
  pvStack_10 = ExceptionList;
  uStack_38 = 0;
  uStack_8 = 5;
  uStack_70 = 0;
  uStack_6c = 0xf;
  auStack_80[0] = auStack_80[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  iStack_68 = param_1;
  FUN_005542c0("GroupTeleportInitiatedSuccess",0x1d);
  uStack_8._0_1_ = 6;
  uVar16 = 0xad9ba5;
  FUN_008783f0(auStack_80,1,0);
  uStack_8._0_1_ = 5;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 5;
  if (0xf < uStack_6c) {
    uVar9 = uStack_6c + 1;
    uVar12 = auStack_80[0];
    if (0xfff < uVar9) {
      uVar12 = *(uint *)(auStack_80[0] - 4);
      uVar9 = uStack_6c + 0x24;
      if (0x1f < (auStack_80[0] - uVar12) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar12,uVar9);
  }
  uStack_a0 = 0xf00000000;
  uStack_b0 = uStack_b0 & 0xffffff00;
  uStack_8._0_1_ = 7;
  uStack_70 = 0;
  uStack_6c = 0xf;
  auStack_80[0] = auStack_80[0] & 0xffffff00;
  uVar18 = 0xad9c20;
  FUN_005542c0("TeleportService:TeleportPartyAsync error: Unknown error when processing success response."
               ,0x59);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  uVar20 = 0xad9c2a;
  iVar4 = FUN_008f7870(param_1);
  if (iVar4 == 0) {
    FUN_016756b0(auStack_58,"DataModel null when processing group teleporting success response");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_58,&DAT_01c17198);
  }
  if (in_stack_0000001c == (uint *)0x0) {
    FUN_0054ef60(auStack_80);
    FUN_005e65e0(in_stack_ffffff18,in_stack_ffffff1c,uVar16,uVar18,uVar20,param_1);
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    piVar17 = in_stack_00000020;
    if (in_stack_00000020 != (int *)0x0) {
      LOCK();
      iVar4 = in_stack_00000020[1] + -1;
      in_stack_00000020[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*in_stack_00000020)();
        LOCK();
        piVar7 = piVar17 + 2;
        iVar4 = *piVar7 + -1;
        *piVar7 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar17 + 4))();
        }
      }
    }
    piVar17 = in_stack_00000028;
    if (in_stack_00000028 != (int *)0x0) {
      LOCK();
      iVar4 = in_stack_00000028[1] + -1;
      in_stack_00000028[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*in_stack_00000028)();
        LOCK();
        piVar7 = piVar17 + 2;
        iVar4 = *piVar7 + -1;
        *piVar7 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar17 + 4))();
        }
      }
    }
    piVar17 = in_stack_00000030;
    if (in_stack_00000030 != (int *)0x0) {
      LOCK();
      iVar4 = in_stack_00000030[1] + -1;
      in_stack_00000030[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*in_stack_00000030)();
        LOCK();
        piVar7 = piVar17 + 2;
        iVar4 = *piVar7;
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar17 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    if (in_stack_00000034 != 0) {
      if (((in_stack_00000034 & 1) == 0) &&
         (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(in_stack_00000034 & 0xfffffffe))(&stack0x0000003c,&stack0x0000003c,2);
      }
      in_stack_00000034 = 0;
    }
    uStack_8 = 10;
    goto LAB_00ada7f5;
  }
  puVar10 = (undefined4 *)*in_stack_0000001c;
  uStack_40 = 0;
  uVar12 = (uint)((int)in_stack_0000001c[1] + (7 - (int)puVar10)) >> 3;
  if ((undefined4 *)in_stack_0000001c[1] < puVar10) {
    uVar12 = 0;
  }
  if (uVar12 != 0) {
    iStack_14 = iStack_68 + 0xc4;
    do {
      uStack_54 = *puVar10;
      piStack_50 = (int *)puVar10[1];
      FUN_009b12c0(&uStack_54);
      puVar10 = puVar10 + 2;
      uStack_40 = uStack_40 + 1;
    } while (uStack_40 != uVar12);
  }
  FUN_00563d90(&pbStack_4c);
  ppbVar19 = &pbStack_4c;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  puVar10 = &param_2;
  uVar16 = 0xad9d91;
  cVar3 = FUN_0098f070(puVar10,ppbVar19,0);
  pbVar11 = pbStack_4c;
  if (cVar3 == '\0') {
    uVar18 = 0;
    uVar20 = 0xf;
    in_stack_ffffff18 = in_stack_ffffff18 & 0xffffff00;
    FUN_005542c0("TeleportService:TeleportPartyAsync error: Could not parse JSON result.",0x46);
    FUN_005e65e0(in_stack_ffffff18,uVar16,puVar10,ppbVar19,uVar18,uVar20);
    if (piStack_48 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_48[1] + -1;
      piStack_48[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_48)();
        LOCK();
        iVar4 = piStack_48[2] + -1;
        piStack_48[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_48 + 4))();
        }
      }
    }
    uStack_8._0_1_ = 7;
    if (0xf < uStack_6c) {
      uVar9 = uStack_6c + 1;
      uVar12 = auStack_80[0];
      if (0xfff < uVar9) {
        uVar12 = *(uint *)(auStack_80[0] - 4);
        uVar9 = uStack_6c + 0x24;
        if (0x1f < (auStack_80[0] - uVar12) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar12,uVar9);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (0xf < in_stack_00000018) {
      uVar9 = in_stack_00000018 + 1;
      uVar12 = param_2;
      if (0xfff < uVar9) {
        uVar12 = *(uint *)(param_2 - 4);
        uVar9 = in_stack_00000018 + 0x24;
        if (0x1f < (param_2 - uVar12) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar12,uVar9);
    }
    piVar17 = in_stack_00000020;
    in_stack_00000014 = 0;
    in_stack_00000018 = 0xf;
    param_2 = param_2 & 0xffffff00;
    if (in_stack_00000020 != (int *)0x0) {
      LOCK();
      iVar4 = in_stack_00000020[1] + -1;
      in_stack_00000020[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*in_stack_00000020)();
        LOCK();
        piVar7 = piVar17 + 2;
        iVar4 = *piVar7 + -1;
        *piVar7 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar17 + 4))();
        }
      }
    }
    piVar17 = in_stack_00000028;
    if (in_stack_00000028 != (int *)0x0) {
      LOCK();
      iVar4 = in_stack_00000028[1] + -1;
      in_stack_00000028[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*in_stack_00000028)();
        LOCK();
        piVar7 = piVar17 + 2;
        iVar4 = *piVar7 + -1;
        *piVar7 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar17 + 4))();
        }
      }
    }
    piVar17 = in_stack_00000030;
    if (in_stack_00000030 != (int *)0x0) {
      LOCK();
      iVar4 = in_stack_00000030[1] + -1;
      in_stack_00000030[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*in_stack_00000030)();
        LOCK();
        piVar7 = piVar17 + 2;
        iVar4 = *piVar7;
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar17 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    if (in_stack_00000034 != 0) {
      if (((in_stack_00000034 & 1) == 0) &&
         (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(in_stack_00000034 & 0xfffffffe))(&stack0x0000003c,&stack0x0000003c,2);
      }
      in_stack_00000034 = 0;
    }
    uStack_8 = 0xd;
    goto LAB_00ada7f5;
  }
  uStack_54 = 0;
  piStack_50 = (int *)0xf;
  auStack_64[0] = auStack_64[0] & 0xffffff00;
  FUN_005542c0("gameId",6);
  pbVar11 = pbVar11 + *pbVar11 + 1;
  uVar16 = FUN_005702d0(auStack_64);
  piVar17 = &iStack_14;
  uVar18 = 0xad9f69;
  FUN_00562fc0(piVar17,uVar16,auStack_64,-(uint)(pbVar11 != (byte *)0x0) & (uint)(pbVar11 + 1));
  if (0xf < piStack_50) {
    uVar9 = (int)piStack_50 + 1;
    uVar12 = auStack_64[0];
    if (0xfff < uVar9) {
      uVar12 = *(uint *)(auStack_64[0] - 4);
      uVar9 = (int)piStack_50 + 0x24;
      if (0x1f < (auStack_64[0] - uVar12) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uVar16 = 0xad9f9a;
    FUN_01674ea0(uVar12,uVar9);
  }
  uStack_54 = 0;
  piStack_50 = (int *)&DAT_0000000f;
  auStack_64[0] = auStack_64[0] & 0xffffff00;
  uVar12 = uStack_38;
  if ((iStack_14 == 0) ||
     (iVar4 = *(int *)(iStack_14 + 0x20), iVar5 = FUN_0088cb40(), uVar12 = uStack_38, iVar4 != iVar5
     )) {
LAB_00ad9fe5:
    cStack_19 = '\x01';
  }
  else {
    iVar4 = FUN_00563690(auStack_98);
    uVar12 = 1;
    if (*(int *)(iVar4 + 0x10) == 0) goto LAB_00ad9fe5;
    cStack_19 = '\0';
  }
  if ((uVar12 & 1) != 0) {
    FUN_005507b0();
  }
  if (cStack_19 == '\0') {
    puVar6 = (uint *)FUN_00563690(auStack_98);
    if (&uStack_b0 != puVar6) {
      FUN_005507b0();
      uStack_b0 = *puVar6;
      uStack_ac = puVar6[1];
      uStack_a8 = puVar6[2];
      uStack_a4 = puVar6[3];
      uStack_a0 = *(undefined8 *)(puVar6 + 4);
      puVar6[4] = 0;
      puVar6[5] = 0xf;
      *(undefined *)puVar6 = 0;
    }
    FUN_005507b0();
    FUN_00888650(&uStack_54);
    uStack_8._0_1_ = 0x10;
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = 0;
    FUN_005542c0("members",7);
    bVar1 = *pbStack_4c;
    uVar16 = FUN_005702d0(auStack_34);
    piVar17 = &iStack_14;
    uVar18 = 0xada1cf;
    FUN_00562fc0(piVar17,uVar16,auStack_34,
                 -(uint)(pbStack_4c + bVar1 + 1 != (byte *)0x0) & (uint)(pbStack_4c + bVar1 + 1 + 1)
                );
    FUN_005507b0();
    if (((iStack_14 != 0) &&
        (iVar4 = *(int *)(iStack_14 + 0x20), iVar5 = FUN_008882f0(), iVar4 == iVar5)) &&
       (piVar7 = (int *)FUN_0055d670(), iVar5 = ((int *)*piVar7)[1] - *(int *)*piVar7,
       iVar4 = iVar5 >> 0x1f, iVar5 / 0xd0 + iVar4 != iVar4)) {
      uVar16 = FUN_0055d670();
      FUN_00557fc0(uVar16);
      uStack_8._0_1_ = 0x13;
      uStack_24 = 0;
      uStack_20 = 0xf;
      auStack_34[0] = 0;
      FUN_005542c0("Members",7);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
      iVar5 = FUN_005c4c00(auStack_34);
      uVar16 = FUN_008882f0();
      *(undefined4 *)(iVar5 + 0x18) = uVar16;
      iVar8 = FUN_005c9da0();
      iVar4 = *(int *)(iVar5 + 0x1c);
      if (iVar4 == iVar8) {
        FUN_0056ecd0(&piStack_3c);
      }
      else {
        if (iVar4 != 0) {
          (**(code **)(iVar4 + 8))(iVar5 + 0x20);
          *(undefined4 *)(iVar5 + 0x1c) = 0;
        }
        *(undefined4 *)(iVar5 + 0x20) = 0;
        *(undefined4 *)(iVar5 + 0x24) = 0;
        if (uStack_38 != 0) {
          LOCK();
          *(int *)(uStack_38 + 4) = *(int *)(uStack_38 + 4) + 1;
          UNLOCK();
        }
        *(int **)(iVar5 + 0x20) = piStack_3c;
        *(uint *)(iVar5 + 0x24) = uStack_38;
        *(int *)(iVar5 + 0x1c) = iVar8;
      }
      FUN_005507b0();
      uStack_44 = 0;
      uStack_40 = 0;
      uStack_8._0_1_ = 0x15;
      uStack_24 = 0;
      uStack_20 = 0xf;
      auStack_34[0] = 0;
      FUN_005542c0("groupTeleportGuid",0x11);
      FUN_008a0c70(&iStack_14,auStack_34);
      FUN_005507b0();
      if ((iStack_14 == 0) ||
         (iVar4 = *(int *)(iStack_14 + 0x20), iVar5 = FUN_0088cb40(), iVar4 != iVar5)) {
        uVar16 = FUN_00ad55f0(auStack_98);
        uStack_8 = CONCAT31(uStack_8._1_3_,0x17);
        uVar18 = 0xada369;
        uVar16 = FUN_00ad1a20(auStack_18,3,uVar16);
      }
      else {
        uVar16 = FUN_00563690(auStack_98);
        uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
        uVar16 = FUN_00ad1a20(auStack_18,3,uVar16);
      }
      FUN_005587e0(uVar16);
      FUN_00550b30();
      uStack_8._0_1_ = 0x15;
      FUN_005507b0();
      uStack_24 = 0;
      uStack_20 = 0xf;
      auStack_34[0] = 0;
      FUN_005542c0("InitiatedSuccess",0x10);
      uStack_8._0_1_ = 0x18;
      uVar16 = 0xada3db;
      FUN_00ad5890(auStack_c8,(piStack_3c[1] - *piStack_3c) / 0xd0,auStack_34);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x1a);
      FUN_005507b0();
      if (iStack_b8 != 0) {
        uVar16 = 0xada403;
        FUN_008783f0(auStack_c8,1,0);
      }
      uStack_88 = 0;
      uStack_84 = 0xf;
      auStack_98[0] = 0;
      uStack_8._0_1_ = 0x1b;
      uStack_24 = 0;
      uStack_20 = 0xf;
      auStack_34[0] = 0;
      FUN_005542c0("spawnName",9);
      puVar14 = auStack_98;
      uStack_8._0_1_ = 0x1c;
      FUN_005c4c00(auStack_34);
      FUN_00632ce0(puVar14);
      FUN_005507b0();
      FUN_005507b0();
      uStack_88 = 0;
      uStack_84 = 0xf;
      auStack_98[0] = 0;
      uStack_8._0_1_ = 0x1d;
      uStack_24 = 0;
      uStack_20 = 0xf;
      auStack_34[0] = 0;
      FUN_005542c0("reservedServerAccessCode",0x18);
      puVar14 = auStack_98;
      uStack_8._0_1_ = 0x1e;
      FUN_005c4c00(auStack_34);
      FUN_00632ce0(puVar14);
      FUN_005507b0();
      uStack_8._0_1_ = 0x1a;
      FUN_005507b0();
      uStack_24 = 0;
      uStack_20 = 0xf;
      auStack_34[0] = 0;
      FUN_005542c0("instanceId",10);
      uStack_8._0_1_ = 0x1f;
      iVar4 = FUN_005c4c00(auStack_34);
      uVar20 = FUN_0088cb40();
      *(undefined4 *)(iVar4 + 0x18) = uVar20;
      FUN_005c17a0(&uStack_b0);
      uStack_8._0_1_ = 0x1a;
      FUN_005507b0();
      iStack_14 = 1;
      uStack_24 = 0;
      uStack_20 = 0xf;
      auStack_34[0] = 0;
      FUN_005542c0("teleportType",0xc);
      piVar17 = &iStack_14;
      uStack_8._0_1_ = 0x20;
      uVar20 = 0xada582;
      FUN_005c4c00(auStack_34);
      uVar21 = 0xada58a;
      FUN_00ac0a40(piVar17);
      uStack_8._0_1_ = 0x1a;
      uVar22 = 0xada596;
      FUN_005507b0();
      FUN_0054ef60(&uStack_b0);
      FUN_005e65e0(in_stack_ffffff18,uVar18,uVar16,uVar20,uVar21,uVar22);
      uStack_24 = 0;
      uStack_20 = 0xf;
      auStack_34[0] = 0;
      FUN_005542c0("GroupTeleportStarted",0x14);
      uStack_8._0_1_ = 0x21;
      uVar22 = 1;
      FUN_008783f0(auStack_34,1,0);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x1a);
      uVar23 = 0xada5f0;
      FUN_005507b0();
      puVar10 = &uStack_54;
      uVar21 = 0xada5fe;
      FUN_00557fc0(puVar10);
      puVar15 = &uStack_44;
      uVar20 = 0xada60c;
      FUN_00557fc0(puVar15);
      puVar14 = &stack0x0000002c;
      uVar18 = 0xada61a;
      FUN_00557fc0(puVar14);
      puVar13 = &stack0x00000024;
      uVar16 = 0xada628;
      FUN_00557fc0(puVar13);
      FUN_00557fc0(&piStack_3c);
      FUN_00adc7d0(uVar16,puVar13,uVar18,puVar14,uVar20,puVar15,uVar21,puVar10,uVar22,uVar23);
      FUN_005507b0();
      FUN_00550b30();
      FUN_00550b30();
      FUN_00550b30();
      FUN_00550b30();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_00550b30();
      FUN_00550b30();
      FUN_00550b30();
      FUN_00550990();
      FUN_00550990();
      ExceptionList = pvStack_10;
      return;
    }
    uVar20 = 0;
    uVar21 = 0xf;
    in_stack_ffffff18 = in_stack_ffffff18 & 0xffffff00;
    FUN_005542c0("TeleportService:TeleportPartyAsync error: No members returned from backend.",0x4b)
    ;
    FUN_005e65e0(in_stack_ffffff18,uVar18,piVar17,uVar16,uVar20,uVar21);
    piVar17 = piStack_50;
    if (piStack_50 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_50[1] + -1;
      piStack_50[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_50)();
        LOCK();
        piVar7 = piVar17 + 2;
        iVar4 = *piVar7 + -1;
        *piVar7 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar17 + 4))();
        }
      }
    }
    if (piStack_48 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_48[1] + -1;
      piStack_48[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_48)();
        LOCK();
        iVar4 = piStack_48[2] + -1;
        piStack_48[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_48 + 4))();
        }
      }
    }
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    piVar17 = in_stack_00000020;
    if (in_stack_00000020 != (int *)0x0) {
      LOCK();
      iVar4 = in_stack_00000020[1] + -1;
      in_stack_00000020[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*in_stack_00000020)();
        LOCK();
        piVar7 = piVar17 + 2;
        iVar4 = *piVar7 + -1;
        *piVar7 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar17 + 4))();
        }
      }
    }
    piVar17 = in_stack_00000028;
    if (in_stack_00000028 != (int *)0x0) {
      LOCK();
      iVar4 = in_stack_00000028[1] + -1;
      in_stack_00000028[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*in_stack_00000028)();
        LOCK();
        piVar7 = piVar17 + 2;
        iVar4 = *piVar7 + -1;
        *piVar7 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar17 + 4))();
        }
      }
    }
    piVar17 = in_stack_00000030;
    if (in_stack_00000030 != (int *)0x0) {
      LOCK();
      iVar4 = in_stack_00000030[1] + -1;
      in_stack_00000030[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*in_stack_00000030)();
        LOCK();
        piVar7 = piVar17 + 2;
        iVar4 = *piVar7;
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar17 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
    if (in_stack_00000034 != 0) {
      if (((in_stack_00000034 & 1) == 0) &&
         (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(in_stack_00000034 & 0xfffffffe))(&stack0x0000003c,&stack0x0000003c,2);
      }
      in_stack_00000034 = 0;
    }
    uStack_8 = 0x12;
  }
  else {
    uVar20 = 0;
    uVar21 = 0xf;
    in_stack_ffffff18 = in_stack_ffffff18 & 0xffffff00;
    FUN_005542c0("TeleportService:TeleportPartyAsync error: No gameId returned.",0x3d);
    FUN_005e65e0(in_stack_ffffff18,uVar18,piVar17,uVar16,uVar20,uVar21);
    if (piStack_48 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_48[1] + -1;
      piStack_48[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_48)();
        LOCK();
        iVar4 = piStack_48[2] + -1;
        piStack_48[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_48 + 4))();
        }
      }
    }
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    piVar17 = in_stack_00000020;
    if (in_stack_00000020 != (int *)0x0) {
      LOCK();
      iVar4 = in_stack_00000020[1] + -1;
      in_stack_00000020[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*in_stack_00000020)();
        LOCK();
        piVar7 = piVar17 + 2;
        iVar4 = *piVar7 + -1;
        *piVar7 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar17 + 4))();
        }
      }
    }
    piVar17 = in_stack_00000028;
    if (in_stack_00000028 != (int *)0x0) {
      LOCK();
      iVar4 = in_stack_00000028[1] + -1;
      in_stack_00000028[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*in_stack_00000028)();
        LOCK();
        piVar7 = piVar17 + 2;
        iVar4 = *piVar7 + -1;
        *piVar7 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar17 + 4))();
        }
      }
    }
    piVar17 = in_stack_00000030;
    if (in_stack_00000030 != (int *)0x0) {
      LOCK();
      iVar4 = in_stack_00000030[1] + -1;
      in_stack_00000030[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*in_stack_00000030)();
        LOCK();
        piVar7 = piVar17 + 2;
        iVar4 = *piVar7;
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar17 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
    if (in_stack_00000034 != 0) {
      if (((in_stack_00000034 & 1) == 0) &&
         (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(in_stack_00000034 & 0xfffffffe))(&stack0x0000003c,&stack0x0000003c,2);
      }
      in_stack_00000034 = 0;
    }
    uStack_8 = 0xf;
  }
LAB_00ada7f5:
  if (((in_stack_00000054 != 0) && ((in_stack_00000054 & 1) == 0)) &&
     (*(code **)(in_stack_00000054 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000054 & 0xfffffffe))(&stack0x0000005c,&stack0x0000005c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22411 ; VA 0x00ada6be ; FUN_00ada6be */

void FUN_00ada6be(void)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int unaff_EBP;
  undefined uVar5;
  
  uVar5 = 0;
  FUN_005542c0("TeleportService:TeleportPartyAsync error: No members returned from backend.",0x4b);
  FUN_005e65e0(uVar5);
  piVar2 = *(int **)(unaff_EBP + -0x4c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(unaff_EBP + -0x44);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  piVar2 = *(int **)(unaff_EBP + 0x24);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(unaff_EBP + 0x2c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(unaff_EBP + 0x34);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = *(uint *)(unaff_EBP + 0x38);
  *(undefined *)(unaff_EBP + -4) = 0x11;
  if (uVar3 != 0) {
    if (((uVar3 & 1) == 0) && (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uVar3 & 0xfffffffe))(unaff_EBP + 0x40,unaff_EBP + 0x40,2);
    }
    *(undefined4 *)(unaff_EBP + 0x38) = 0;
  }
  *(undefined4 *)(unaff_EBP + -4) = 0x12;
  uVar3 = *(uint *)(unaff_EBP + 0x58);
  if (((uVar3 != 0) && ((uVar3 & 1) == 0)) && (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uVar3 & 0xfffffffe))(unaff_EBP + 0x60,unaff_EBP + 0x60,2);
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 22412 ; VA 0x00ada860 ; FUN_00ada860 */

void __thiscall FUN_00ada860(undefined4 param_1,int param_2,undefined4 *param_3,undefined4 param_4)

{
  int *piVar1;
  uint *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *****pppppuVar5;
  undefined4 ****ppppuVar6;
  uint uVar7;
  undefined4 uVar8;
  undefined auStack_8c [4];
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 ****ppppuStack_80;
  undefined8 uStack_7c;
  undefined auStack_6c [24];
  undefined auStack_54 [4];
  int aiStack_50 [5];
  uint uStack_3c;
  undefined4 ****ppppuStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  int *piStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ea1e0;
  pvStack_10 = ExceptionList;
  uStack_7c = (double)CONCAT44(0xada887,(undefined4)uStack_7c);
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  FUN_00adb5f0();
  uStack_7c = (double)CONCAT44(param_2,aiStack_50);
  ppppuStack_80 = (undefined4 ****)0xada896;
  FUN_009cb090();
  uStack_7c = 4.24530194619609e-313;
  ppppuStack_80 = (undefined4 ****)0x0;
  iStack_8 = 0;
  uStack_84 = 0xada8ae;
  puVar2 = (uint *)FUN_00585d40();
  ppppuStack_38 = (undefined4 ****)*puVar2;
  uStack_34 = puVar2[1];
  uStack_30 = puVar2[2];
  uStack_2c = puVar2[3];
  uStack_28 = *(undefined8 *)(puVar2 + 4);
  puVar2[4] = 0;
  puVar2[5] = 0xf;
  *(undefined *)puVar2 = 0;
  ppppuStack_80 = &ppppuStack_38;
  iStack_8._0_1_ = 1;
  uStack_7c = 4.94065645841247e-324;
  uStack_84 = 0xada8ef;
  FUN_008783f0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_28._4_4_) {
    uVar7 = uStack_28._4_4_ + 1;
    ppppuVar6 = ppppuStack_38;
    if (0xfff < uVar7) {
      ppppuVar6 = (undefined4 ****)ppppuStack_38[-1];
      uVar7 = uStack_28._4_4_ + 0x24;
      if (0x1f < (uint)((int)ppppuStack_38 + (-4 - (int)ppppuVar6))) {
        uStack_7c = (double)CONCAT44(0xadac0f,(undefined4)uStack_7c);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_7c = (double)CONCAT44(uVar7,ppppuVar6);
    ppppuStack_80 = (undefined4 *****)0xada927;
    FUN_01674ea0();
  }
  uStack_28 = 0xf00000000;
  ppppuStack_38 = (undefined4 ****)((uint)ppppuStack_38 & 0xffffff00);
  iStack_8 = 0xffffffff;
  if (0xf < uStack_3c) {
    uVar7 = uStack_3c + 1;
    iVar3 = aiStack_50[0];
    if (0xfff < uVar7) {
      iVar3 = *(int *)(aiStack_50[0] + -4);
      uVar7 = uStack_3c + 0x24;
      if (0x1f < (aiStack_50[0] - iVar3) - 4U) {
        uStack_7c = (double)CONCAT44(0xadac14,(undefined4)uStack_7c);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_7c = (double)CONCAT44(uVar7,iVar3);
    ppppuStack_80 = (undefined4 *****)0xada974;
    FUN_01674ea0();
  }
  uStack_7c = (double)CONCAT44(param_1,0xada97d);
  iVar3 = FUN_0097bfc0();
  if (iVar3 != 0) {
    puStack_18 = auStack_8c;
    FUN_0054ef60();
    iStack_8 = 2;
    puVar4 = (undefined4 *)FUN_0060dcd0();
    uVar8 = uStack_14;
    *puVar4 = 0;
    puVar4[1] = 0;
    iStack_8 = CONCAT31((int3)((uint)iStack_8 >> 8),4);
    FUN_00ad5040();
    iStack_8 = 0xffffffff;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar3;
      UNLOCK();
      uVar8 = uStack_14;
      if (iVar3 == 0) {
        uStack_7c = (double)CONCAT44(0xadaa0a,(undefined4)uStack_7c);
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piStack_1c + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        uVar8 = uStack_14;
        if (iVar3 == 1) {
          uStack_7c = (double)CONCAT44(0xadaa19,(undefined4)uStack_7c);
          (**(code **)(*piStack_1c + 4))();
          uVar8 = uStack_14;
        }
      }
    }
    uStack_7c = (double)CONCAT44(0xadaa21,(undefined4)uStack_7c);
    FUN_00adb5f0();
    uStack_7c = (double)CONCAT44(param_2,&ppppuStack_38);
    ppppuStack_80 = (undefined4 ****)0xadaa30;
    FUN_009cb090();
    iStack_8 = 5;
    pppppuVar5 = &ppppuStack_38;
    if (0xf < uStack_28._4_4_) {
      pppppuVar5 = (undefined4 *****)ppppuStack_38;
    }
    puVar4 = param_3;
    if (0xf < (uint)param_3[5]) {
      puVar4 = (undefined4 *)*param_3;
    }
    uStack_7c = (double)CONCAT44(pppppuVar5,puVar4);
    ppppuStack_80 = (undefined4 ****)0x194b1ec;
    uStack_84 = 3;
    uStack_88 = 0xadaa5d;
    FUN_0086f2f0();
    iStack_8 = 0xffffffff;
    if (0xf < uStack_28._4_4_) {
      uVar7 = uStack_28._4_4_ + 1;
      pppppuVar5 = (undefined4 *****)ppppuStack_38;
      if (0xfff < uVar7) {
        pppppuVar5 = (undefined4 *****)ppppuStack_38[-1];
        uVar7 = uStack_28._4_4_ + 0x24;
        if (0x1f < (uint)((int)ppppuStack_38 + (-4 - (int)pppppuVar5))) {
          uStack_7c = (double)CONCAT44(&UNK_00adac19,(undefined4)uStack_7c);
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_7c = (double)CONCAT44(uVar7,pppppuVar5);
      ppppuStack_80 = (undefined4 ****)0xadaa98;
      FUN_01674ea0();
    }
    if ((param_2 != 7) && (param_2 != 0)) {
      uStack_7c = 1.28152525854628e-316;
      ppppuStack_80 = (undefined4 ****)0xadaabd;
      FUN_005542c0();
      uStack_7c = (double)CONCAT44(uVar8,0xadaac3);
      iVar3 = FUN_008f7870();
      if (iVar3 != 0) {
        uStack_7c = (double)CONCAT44(param_4,*(undefined4 *)(iVar3 + 0x4a0));
        ppppuStack_80 = (undefined4 ****)0xadaade;
        FUN_00acdbd0();
        uStack_7c = (double)CONCAT44(0xadaaee,(undefined4)uStack_7c);
        uVar7 = FUN_006348f0();
        if (uVar7 != 0) {
          ppppuStack_80 = (undefined4 ****)auStack_6c;
          uStack_7c = (double)CONCAT44(param_3,"Teleport Failed: ");
          uStack_84 = 0xadab09;
          FUN_00558df0();
          iStack_8 = 6;
          uStack_7c = (double)CONCAT44(param_2 + 0x300,(undefined4)uStack_7c);
          FUN_0054ef60();
          FUN_00b9c950();
          uStack_7c = 4.03310202224174e-313;
          uStack_28 = 0xf00000000;
          ppppuStack_38 = (undefined4 ****)((uint)ppppuStack_38 & 0xffffff00);
          ppppuStack_80 = (undefined4 ****)0xadab52;
          FUN_005542c0();
          ppppuStack_80 = &ppppuStack_38;
          iStack_8._0_1_ = 7;
          uStack_7c = 4.94065645841247e-324;
          uStack_84 = 0xadab63;
          FUN_008783f0();
          iStack_8._0_1_ = 6;
          uStack_7c = (double)CONCAT44(0xadab72,(undefined4)uStack_7c);
          FUN_005507b0();
          if (DAT_01d678d8 == '\0') {
            uStack_7c = (double)CONCAT44(auStack_6c,0xadab87);
            FUN_0054ef60();
            iStack_8._0_1_ = 8;
            uStack_7c = (double)CONCAT44(0xadab96,(undefined4)uStack_7c);
            uStack_3c = uVar7;
            iVar3 = FUN_005cf2a0();
            if (iVar3 != 0) {
              uStack_7c = (double)((float)DAT_01d665b4 / DAT_018ce324);
              FUN_0054ef60(auStack_54);
              FUN_00abf890();
              FUN_009eef30();
            }
            uStack_7c = (double)CONCAT44(0xadabf0,(undefined4)uStack_7c);
            FUN_005507b0();
          }
          uStack_7c = (double)CONCAT44(0xadabf8,(undefined4)uStack_7c);
          FUN_005507b0();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22413 ; VA 0x00adac20 ; FUN_00adac20 */

void FUN_00adac20(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  byte *pbVar4;
  uint auStack_1c [4];
  undefined4 uStack_c;
  uint uStack_8;
  
  pbVar4 = (byte *)*param_3;
  uStack_c = 0;
  uStack_8 = 0xf;
  auStack_1c[0] = auStack_1c[0] & 0xffffff00;
  FUN_005542c0("teleportMethod",0xe);
  pbVar4 = pbVar4 + *pbVar4 + 1;
  uVar1 = FUN_005702d0(auStack_1c);
  FUN_00562fc0(&param_3,uVar1,auStack_1c,-(uint)(pbVar4 != (byte *)0x0) & (uint)(pbVar4 + 1));
  if (0xf < uStack_8) {
    uVar3 = uStack_8 + 1;
    uVar2 = auStack_1c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_1c[0] - 4);
      uVar3 = uStack_8 + 0x24;
      if (0x1f < (auStack_1c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_c = 0;
  uStack_8 = 0xf;
  auStack_1c[0] = auStack_1c[0] & 0xffffff00;
  if (param_3 == (undefined4 *)0x0) {
    uVar1 = 4;
  }
  else {
    uVar1 = FUN_00ac3380();
  }
  FUN_00ada860(param_1,param_2,uVar1);
  return;
}



/* FUNCTION 22414 ; VA 0x00adacf0 ; FUN_00adacf0 */

/* WARNING: Removing unreachable block (ram,0x00adae78) */
/* WARNING: Removing unreachable block (ram,0x00adae4d) */
/* WARNING: Removing unreachable block (ram,0x00adae59) */
/* WARNING: Removing unreachable block (ram,0x00adae67) */
/* WARNING: Removing unreachable block (ram,0x00adae86) */
/* WARNING: Removing unreachable block (ram,0x00adaeb0) */
/* WARNING: Removing unreachable block (ram,0x00adae96) */

undefined4
FUN_00adacf0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined8 uStack_d8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ea237;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  pcVar1 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_290 = FUN_0088cdc0();
  uStack_288 = param_2;
  uStack_28c = 0;
  uStack_284 = param_3;
  uStack_28c = FUN_006309e0();
  uStack_8._0_1_ = 2;
  uStack_1c0 = FUN_00adb5f0();
  uStack_1bc = 0;
  uStack_1b8 = param_4;
  uStack_1bc = FUN_00adb930();
  uStack_8._0_1_ = 3;
  uStack_f0 = FUN_0088cb40();
  uStack_ec = 0;
  uStack_e8 = param_5;
  uStack_e4 = param_6;
  uStack_e0 = param_7;
  uStack_dc = param_8;
  uStack_d8 = CONCAT44(param_10,param_9);
  uStack_ec = FUN_005c9d30();
  uStack_8._0_1_ = 4;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_290,&uStack_20,param_1);
  uStack_8._0_1_ = 5;
  (*pcVar1)(uStack_14,&uStack_20,param_11);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar2 = FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 22415 ; VA 0x00adaec0 ; FUN_00adaec0 */

void FUN_00adaec0(uint param_1)

{
  int *piVar1;
  bool bVar2;
  int *piVar3;
  undefined4 *puVar4;
  char cVar5;
  int iVar6;
  undefined4 uVar7;
  uint uVar8;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  int *in_stack_00000020;
  undefined4 *in_stack_00000024;
  int *in_stack_00000028;
  undefined1 *in_stack_0000002c;
  int *in_stack_00000030;
  int *in_stack_00000038;
  uint in_stack_0000003c;
  uint in_stack_0000005c;
  undefined uVar9;
  undefined1 *puStack_568;
  int *piStack_564;
  undefined auStack_560 [4];
  undefined4 uStack_55c;
  undefined4 *puStack_558;
  undefined4 *puStack_554;
  undefined1 *puStack_550;
  undefined **ppuStack_54c;
  char *pcStack_548;
  undefined4 *puStack_544;
  undefined *puStack_540;
  undefined4 *puStack_53c;
  undefined4 *puStack_538;
  undefined *puStack_534;
  char *pcStack_530;
  undefined4 *puStack_52c;
  undefined auStack_51c [128];
  undefined auStack_49c [128];
  undefined auStack_41c [128];
  undefined auStack_39c [128];
  undefined auStack_31c [128];
  undefined auStack_29c [128];
  undefined auStack_21c [120];
  undefined auStack_1a4 [128];
  undefined auStack_124 [24];
  undefined auStack_10c [48];
  uint uStack_dc;
  undefined4 uStack_cc;
  uint uStack_c8;
  uint uStack_a8;
  undefined4 uStack_98;
  uint uStack_94;
  undefined auStack_8c [16];
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined auStack_74 [16];
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined auStack_5c [16];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined auStack_44 [16];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined *puStack_2c;
  undefined *puStack_28;
  undefined *puStack_24;
  char acStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ea356;
  pvStack_10 = ExceptionList;
  uStack_8 = 6;
  pcStack_530 = (char *)0xadaeee;
  ExceptionList = &pvStack_10;
  iVar6 = FUN_008f7870();
  if ((iVar6 == 0) || (in_stack_00000024 == (undefined4 *)0x0)) {
    puStack_544 = (undefined4 *)0x55;
    pcStack_530 = (char *)0x0;
    puStack_52c = (undefined4 *)0xf;
    pcStack_548 = 
    "TeleportService:TeleportPartyAsync error: Unknown error when requesting the endpoint.";
    puStack_540 = (undefined *)((uint)puStack_540 & 0xffffff00);
    ppuStack_54c = (undefined **)0xadb39b;
    FUN_005542c0();
    puStack_544 = (undefined4 *)0xadb3a3;
    FUN_005e65e0();
  }
  else {
    puStack_52c = (undefined4 *)0x0;
    pcStack_530 = "";
    uStack_7c = 0;
    uStack_78 = 0xf;
    auStack_8c[0] = 0;
    puStack_534 = (undefined *)0xadaf2f;
    FUN_005542c0();
    puStack_52c = (undefined4 *)0x0;
    pcStack_530 = "";
    uStack_8._0_1_ = 7;
    uStack_64 = 0;
    uStack_60 = 0xf;
    auStack_74[0] = 0;
    puStack_534 = (undefined *)0xadaf54;
    FUN_005542c0();
    puStack_52c = (undefined4 *)0xc;
    pcStack_530 = "/v1/teleport";
    uStack_8._0_1_ = 8;
    uStack_4c = 0;
    uStack_48 = 0xf;
    auStack_5c[0] = 0;
    puStack_534 = (undefined *)0xadaf79;
    FUN_005542c0();
    puStack_52c = (undefined4 *)auStack_10c;
    uStack_8._0_1_ = 9;
    pcStack_530 = (char *)0xadaf89;
    uVar7 = FUN_0151ee90();
    puStack_52c = (undefined4 *)0x5;
    pcStack_530 = "https";
    uStack_8._0_1_ = 10;
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = 0;
    puStack_534 = (undefined *)0xadafb3;
    FUN_005542c0();
    puStack_52c = (undefined4 *)auStack_8c;
    uStack_8._0_1_ = 0xb;
    pcStack_530 = auStack_74;
    puStack_534 = auStack_5c;
    puStack_53c = (undefined4 *)auStack_44;
    puStack_540 = auStack_21c;
    puStack_544 = (undefined4 *)0xadafd7;
    puStack_538 = (undefined4 *)uVar7;
    FUN_0151bcc0();
    puStack_52c = (undefined4 *)0xadafe2;
    FUN_005507b0();
    puStack_52c = (undefined4 *)0xadafed;
    FUN_005507b0();
    puStack_52c = (undefined4 *)0xadaff5;
    FUN_005507b0();
    puStack_52c = (undefined4 *)0xadaffd;
    FUN_005507b0();
    uStack_8._0_1_ = 0x11;
    puStack_52c = (undefined4 *)0xadb00c;
    FUN_005507b0();
    puStack_52c = (undefined4 *)auStack_124;
    pcStack_530 = "j";
    puStack_534 = (undefined *)FUN_0151bb70();
    puStack_52c = (undefined4 *)0x0;
    uStack_8._0_1_ = 0x12;
    pcStack_530 = (char *)0xc;
    puStack_538 = (undefined4 *)0xadb032;
    FUN_014cc090();
    uStack_8._0_1_ = 0x14;
    puStack_52c = (undefined4 *)0xadb041;
    FUN_005507b0();
    pcStack_530 = acStack_20;
    puStack_534 = (undefined *)0xadb04b;
    puStack_52c = (undefined4 *)iVar6;
    FUN_005e5de0();
    puStack_52c = &stack0x0000005c;
    uStack_8._0_1_ = 0x15;
    pcStack_530 = (char *)&stack0x0000003c;
    puStack_534 = &stack0x00000034;
    puStack_538 = &stack0x0000002c;
    puStack_53c = &stack0x00000024;
    puStack_540 = &stack0x0000001c;
    puStack_544 = &param_1;
    pcStack_548 = acStack_20;
    ppuStack_54c = (undefined **)0xadb07d;
    FUN_00ac43a0();
    puStack_52c = (undefined4 *)0x0;
    pcStack_530 = (char *)0x0;
    puStack_24 = (undefined *)&pcStack_548;
    uStack_8._0_1_ = 0x16;
    ppuStack_54c = (undefined **)0x0;
    puStack_538 = (undefined4 *)0x0;
    puStack_534 = (undefined *)0xf;
    puStack_550 = &DAT_018bc9b8;
    pcStack_548 = (char *)((uint)pcStack_548 & 0xffffff00);
    puStack_554 = (undefined4 *)0xadb0aa;
    FUN_005542c0();
    puStack_28 = auStack_560;
    uStack_8._0_1_ = 0x17;
    piStack_564 = (int *)0x0;
    puStack_550 = (undefined1 *)0x0;
    ppuStack_54c = (undefined **)0xf;
    puStack_568 = &DAT_018bc9b8;
    auStack_560[0] = 0;
    FUN_005542c0();
    puStack_2c = (undefined *)&puStack_568;
    if (in_stack_00000030 != (int *)0x0) {
      LOCK();
      in_stack_00000030[1] = in_stack_00000030[1] + 1;
      UNLOCK();
    }
    puStack_568 = in_stack_0000002c;
    piStack_564 = in_stack_00000030;
    uStack_8._0_1_ = 0x19;
    uVar9 = 0;
    FUN_005542c0("CallGameJoinApi",0xf);
    uStack_8._0_1_ = 0x16;
    FUN_00ad71f0(uVar9);
    puVar4 = in_stack_00000024;
    FUN_01682800(&uStack_18);
    *puVar4 = uStack_18;
    puVar4[1] = iStack_14;
    puStack_550 = auStack_51c;
    puStack_52c = (undefined4 *)0x0;
    puStack_554 = (undefined4 *)0xadb160;
    FUN_00ac4200();
    puStack_550 = auStack_49c;
    uStack_8._0_1_ = 0x1a;
    puStack_554 = (undefined4 *)0xadb176;
    FUN_00ac4200();
    puStack_550 = auStack_41c;
    uStack_8._0_1_ = 0x1b;
    ppuStack_54c = (undefined **)0x0;
    puStack_554 = (undefined4 *)0xadb192;
    FUN_00ac4200();
    puStack_550 = auStack_39c;
    uStack_8._0_1_ = 0x1c;
    puStack_554 = (undefined4 *)0xadb1a8;
    FUN_00ac4200();
    puStack_550 = auStack_31c;
    uStack_8._0_1_ = 0x1d;
    puStack_554 = (undefined4 *)0xadb1be;
    FUN_00ac4200();
    puStack_550 = auStack_1a4;
    uStack_8._0_1_ = 0x1e;
    puStack_554 = (undefined4 *)0xadb1ce;
    cVar5 = FUN_00585a40();
    if (cVar5 == '\0') {
      puStack_550 = auStack_1a4;
      puStack_554 = (undefined4 *)0xadb1e7;
      FUN_00ac4200();
      puStack_550 = (undefined1 *)0x80;
      uStack_8._0_1_ = 0x1f;
      puStack_554 = (undefined4 *)0xadb1f5;
      iStack_14 = FUN_01674e20();
      uStack_8._0_1_ = 0x20;
      if (iStack_14 == 0) {
        puStack_544 = (undefined4 *)0x0;
      }
      else {
        puStack_550 = auStack_29c;
        puStack_554 = (undefined4 *)0xadb211;
        puStack_544 = (undefined4 *)FUN_00ac4200();
      }
      puStack_550 = (undefined1 *)0xadb223;
      FUN_00ac7d90();
      puStack_550 = (undefined1 *)0xadb22e;
      FUN_00ac7d90();
      bVar2 = true;
    }
    else {
      puStack_550 = (undefined1 *)0xadb23d;
      FUN_00ac7d90();
      bVar2 = false;
    }
    puStack_550 = (undefined1 *)0xadb24a;
    FUN_00ac7d90();
    ppuStack_54c = &PTR_FUN_0194b57c;
    if (!bVar2) {
      ppuStack_54c = (undefined **)0x0;
    }
    puStack_550 = (undefined1 *)0xadb263;
    FUN_00ac7d90();
    puStack_550 = (undefined1 *)0xadb26e;
    FUN_00ac7d90();
    uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
    puStack_550 = (undefined1 *)0xadb27d;
    FUN_00ac7d90();
    puStack_550 = (undefined1 *)0x0;
    puStack_554 = &DAT_01d79f98;
    puStack_558 = &param_1;
    uStack_55c = 0xadb293;
    FUN_014cd990();
    puStack_52c = (undefined4 *)0xadb29e;
    FUN_00ac7d90();
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar6 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        puStack_52c = (undefined4 *)0xadb2b3;
        (**(code **)(*piStack_1c + 4))();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
    if (0xf < uStack_94) {
      puStack_52c = (undefined4 *)(uStack_94 + 1);
      uVar8 = uStack_a8;
      if (0xfff < puStack_52c) {
        uVar8 = *(uint *)(uStack_a8 - 4);
        puStack_52c = (undefined4 *)(uStack_94 + 0x24);
        if (0x1f < (uStack_a8 - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          puStack_52c = (undefined4 *)0xadb4ee;
          FUN_017167a3();
        }
      }
      puStack_534 = (undefined *)0xadb2ee;
      pcStack_530 = (char *)uVar8;
      FUN_01674ea0();
    }
    uStack_98 = 0;
    uStack_94 = 0xf;
    uStack_a8 = uStack_a8 & 0xffffff00;
    puStack_52c = (undefined4 *)0xadb317;
    FUN_0056cfd0();
    if (0xf < uStack_c8) {
      puStack_52c = (undefined4 *)(uStack_c8 + 1);
      uVar8 = uStack_dc;
      if (0xfff < puStack_52c) {
        uVar8 = *(uint *)(uStack_dc - 4);
        puStack_52c = (undefined4 *)(uStack_c8 + 0x24);
        if (0x1f < (uStack_dc - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          puStack_52c = (undefined4 *)0xadb4f3;
          FUN_017167a3();
        }
      }
      puStack_534 = (undefined *)0xadb34e;
      pcStack_530 = (char *)uVar8;
      FUN_01674ea0();
    }
    uStack_cc = 0;
    uStack_c8 = 0xf;
    uStack_dc = uStack_dc & 0xffffff00;
    puStack_52c = (undefined4 *)0xadb377;
    FUN_0056d9d0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (0xf < in_stack_00000018) {
    puStack_52c = (undefined4 *)(in_stack_00000018 + 1);
    uVar8 = param_1;
    if (0xfff < puStack_52c) {
      uVar8 = *(uint *)(param_1 - 4);
      puStack_52c = (undefined4 *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_1 - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_52c = (undefined4 *)&UNK_00adb4f8;
        FUN_017167a3();
      }
    }
    puStack_534 = (undefined *)0xadb3d8;
    pcStack_530 = (char *)uVar8;
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000020;
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = param_1 & 0xffffff00;
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    iVar6 = in_stack_00000020[1] + -1;
    in_stack_00000020[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      puStack_52c = (undefined4 *)0xadb403;
      (**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        puStack_52c = (undefined4 *)0xadb413;
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000028;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    iVar6 = in_stack_00000028[1] + -1;
    in_stack_00000028[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      puStack_52c = (undefined4 *)0xadb429;
      (**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        puStack_52c = (undefined4 *)0xadb439;
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000030;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    iVar6 = in_stack_00000030[1] + -1;
    in_stack_00000030[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      puStack_52c = (undefined4 *)0xadb44f;
      (**(code **)*in_stack_00000030)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        puStack_52c = (undefined4 *)0xadb45f;
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000038;
  if (in_stack_00000038 != (int *)0x0) {
    LOCK();
    iVar6 = in_stack_00000038[1] + -1;
    in_stack_00000038[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      puStack_52c = (undefined4 *)0xadb475;
      (**(code **)*in_stack_00000038)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        puStack_52c = (undefined4 *)0xadb484;
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x21);
  if (in_stack_0000003c != 0) {
    if (((in_stack_0000003c & 1) == 0) &&
       (*(code **)(in_stack_0000003c & 0xfffffffe) != (code *)0x0)) {
      puStack_534 = &stack0x00000044;
      puStack_52c = (undefined4 *)0x2;
      puStack_538 = (undefined4 *)0xadb4a5;
      pcStack_530 = puStack_534;
      (**(code **)(in_stack_0000003c & 0xfffffffe))();
    }
    in_stack_0000003c = 0;
  }
  uStack_8 = 0x22;
  if (((in_stack_0000005c != 0) && ((in_stack_0000005c & 1) == 0)) &&
     (*(code **)(in_stack_0000005c & 0xfffffffe) != (code *)0x0)) {
    puStack_534 = &stack0x00000064;
    puStack_52c = (undefined4 *)0x2;
    puStack_538 = (undefined4 *)0xadb4d3;
    pcStack_530 = puStack_534;
    (**(code **)(in_stack_0000005c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22416 ; VA 0x00adb500 ; FUN_00adb500 */

int * FUN_00adb500(int *param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined auStack_24 [12];
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b5e40;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_2 == 0) {
    ExceptionList = &pvStack_10;
    *param_1 = 0;
    param_1[1] = 0;
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_0089d950(&iStack_18,3);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (iStack_18 == 0) {
      FUN_016756b0(auStack_24,"Failed to clone custom loading gui");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_24,&DAT_01c17198);
    }
    FUN_00ac3110();
    iVar2 = iStack_18;
    iStack_18 = 0;
    *param_1 = iVar2;
    param_1[1] = iStack_14;
    iStack_14 = 0;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22417 ; VA 0x00adb5d0 ; FUN_00adb5d0 */

void FUN_00adb5d0(undefined4 param_1)

{
  FUN_0087c450(&DAT_018c5f98,"Teleport",param_1,0,0,0);
  return;
}



/* FUNCTION 22418 ; VA 0x00adb5f0 ; FUN_00adb5f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00adb5f0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ea376;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeba1c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeba1c);
    if (DAT_01eeba1c == -1) {
      uStack_8 = 0;
      FUN_009ca470("TeleportResult");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eeb9b8 = RBX::Reflection::EnumDesc<enum_RBX::TeleportService::TeleportResult>::vftable;
      FUN_009cada0(0,"Success");
      FUN_009cada0(1,"Failure");
      FUN_009cada0(2,"GameNotFound");
      FUN_009cada0(3,"GameEnded");
      FUN_009cada0(4,"GameFull");
      FUN_009cada0(5,"Unauthorized");
      FUN_009cada0(6,"Flooded");
      FUN_009cada0(7,"IsTeleporting");
      FUN_016f3654(&LAB_0188b580);
      FUN_016f37bf(&DAT_01eeba1c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeb9b8;
}



/* FUNCTION 22419 ; VA 0x00adb720 ; FUN_00adb720 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00adb720(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ea396;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeba84) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeba84);
    if (DAT_01eeba84 == -1) {
      uStack_8 = 0;
      FUN_009ca470("TeleportMethod");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eeba20 = RBX::Reflection::EnumDesc<enum_RBX::TeleportService_TeleportMethod>::vftable;
      FUN_009caf20(&DAT_01d6688c,5);
      FUN_016f3654(&LAB_0188b5a0);
      FUN_016f37bf(&DAT_01eeba84);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeba20;
}



/* FUNCTION 22420 ; VA 0x00adb7d0 ; FUN_00adb7d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00adb7d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ea3b6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeb9b4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeb9b4);
    if (DAT_01eeb9b4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("TeleportState");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eeb950 = RBX::Reflection::EnumDesc<enum_RBX::TeleportService_TeleportState>::vftable;
      FUN_009caf20(&DAT_01d6684c,5);
      FUN_016f3654(&LAB_0188b5c0);
      FUN_016f37bf(&DAT_01eeb9b4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeb950;
}



/* FUNCTION 22421 ; VA 0x00adb880 ; FUN_00adb880 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00adb880(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ea3d6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeb94c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeb94c);
    if (DAT_01eeb94c == -1) {
      uStack_8 = 0;
      FUN_009ca470("TeleportType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eeb8e8 = RBX::Reflection::EnumDesc<enum_RBX::TeleportService_TeleportType>::vftable;
      FUN_009caf20(&DAT_01d66874,3);
      FUN_016f3654(&LAB_0188b5e0);
      FUN_016f37bf(&DAT_01eeb94c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeb8e8;
}



/* FUNCTION 22422 ; VA 0x00adb930 ; FUN_00adb930 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00adb930(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eebab4) {
    FUN_016f3809(&DAT_01eebab4);
    if (DAT_01eebab4 == -1) {
      _DAT_01eebaa8 = FUN_005c65e0;
      _DAT_01eebaac = FUN_005c65e0;
      _DAT_01eebab0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eebab4);
    }
  }
  return &DAT_01eebaa8;
}



/* FUNCTION 22423 ; VA 0x00adb9a0 ; FUN_00adb9a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00adb9a0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeba94) {
    FUN_016f3809(&DAT_01eeba94);
    if (DAT_01eeba94 == -1) {
      _DAT_01eeba88 = FUN_005c65e0;
      _DAT_01eeba8c = FUN_005c65e0;
      _DAT_01eeba90 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eeba94);
    }
  }
  return &DAT_01eeba88;
}



/* FUNCTION 22424 ; VA 0x00adba10 ; FUN_00adba10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00adba10(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eebaa4) {
    FUN_016f3809(&DAT_01eebaa4);
    if (DAT_01eebaa4 == -1) {
      _DAT_01eeba98 = FUN_005c65e0;
      _DAT_01eeba9c = FUN_005c65e0;
      _DAT_01eebaa0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eebaa4);
    }
  }
  return &DAT_01eeba98;
}



/* FUNCTION 22425 ; VA 0x00adba80 ; FUN_00adba80 */

void FUN_00adba80(char *param_1,undefined8 *param_2,int *param_3,int *param_4,undefined4 param_5,
                 int param_6)

{
  bool bVar1;
  undefined uVar2;
  char cVar3;
  undefined *puVar4;
  int iVar5;
  int *piVar6;
  undefined4 uVar7;
  uint uVar8;
  int iVar9;
  int *piVar10;
  longlong lVar11;
  undefined8 uVar12;
  int *in_stack_000000e8;
  uint in_stack_000000ec;
  uint in_stack_0000010c;
  int iStack_4d8;
  undefined8 *puStack_4d4;
  undefined4 uStack_4d0;
  undefined **ppuStack_4cc;
  undefined4 uStack_4c8;
  undefined *puStack_4c4;
  char *pcStack_4c0;
  undefined4 *puStack_4bc;
  undefined **appuStack_4b8 [2];
  undefined4 uStack_4b0;
  undefined4 uStack_4a4;
  undefined *puStack_4a0;
  char *pcStack_49c;
  undefined8 uStack_498;
  int **ppiStack_490;
  int **ppiStack_48c;
  undefined **ppuStack_488;
  undefined8 *puStack_484;
  undefined8 uStack_480;
  undefined auStack_46c [120];
  undefined auStack_3f4 [120];
  undefined auStack_37c [120];
  undefined auStack_304 [120];
  undefined auStack_28c [120];
  undefined auStack_214 [120];
  undefined auStack_19c [88];
  undefined auStack_144 [120];
  undefined auStack_cc [16];
  undefined auStack_bc [16];
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined auStack_a4 [16];
  int iStack_94;
  undefined8 uStack_8c;
  undefined8 uStack_84;
  undefined *puStack_7c;
  undefined *puStack_78;
  int *piStack_74;
  undefined4 *puStack_70;
  uint uStack_6c;
  int iStack_68;
  undefined2 uStack_64;
  int *piStack_60;
  undefined4 *puStack_5c;
  undefined8 uStack_58;
  undefined auStack_50 [8];
  int *piStack_48;
  int iStack_44;
  int iStack_40;
  undefined *puStack_3c;
  undefined auStack_38 [16];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  int iStack_1c;
  undefined uStack_15;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ea584;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  uStack_480._0_4_ = (char *)0xadbab3;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined *)FUN_008f7870();
  puStack_484 = (undefined8 *)0xadbabe;
  puStack_3c = puVar4;
  puStack_7c = (undefined *)FUN_0064e810();
  if ((puVar4 == (undefined *)0x0) || (puStack_7c == (undefined *)0x0)) {
    uStack_498._4_4_ = (char *)0x3f;
    uStack_498._0_4_ = "TeleportService:TeleportPartyAsync error: Players Service null.";
LAB_00adc6d0:
    uStack_480._0_4_ = (char *)0x0;
    uStack_480._4_4_ = (int **)0xf;
    ppiStack_490 = (int **)((uint)ppiStack_490 & 0xffffff00);
    pcStack_49c = (char *)0xadc6e6;
    FUN_005542c0();
  }
  else {
    uStack_480._4_4_ = *(int ***)(puVar4 + 0x4a0);
    uStack_480._0_4_ = (char *)0x3;
    puStack_484 = (undefined8 *)0xadbae4;
    FUN_00acc7f0();
    if (*(int *)(puVar4 + 0x4a0) != 2) {
      uStack_498._4_4_ = (char *)0x35;
      uStack_498._0_4_ = "TeleportPartyAsync can only be called from the server";
      goto LAB_00adc6d0;
    }
    if (((int)param_2 < 1) && (((int)param_2 < 0 || (param_1 == (char *)0x0)))) {
      puStack_4a0 = (undefined *)&ppiStack_490;
      uStack_498._4_4_ = (char *)param_2;
      uStack_498._0_4_ = param_1;
      pcStack_49c = 
      "TeleportService:TeleportPartyAsync error: Cannot teleport to invalid place id %lld. Aborting teleport."
      ;
      uStack_4a4 = 0xadbb23;
      FUN_01675640();
    }
    else {
      if ((param_3 != (int *)0x0) && (7 < (uint)(param_3[1] - *param_3))) {
        uStack_480._4_4_ = &piStack_48;
        uStack_480._0_4_ = (char *)0xadbb4d;
        FUN_005cac50();
        uStack_480._0_4_ = (char *)0x18;
        uStack_8._0_1_ = 5;
        puStack_484 = (undefined8 *)0xadbb58;
        puStack_5c = (undefined4 *)FUN_01674e20();
        if (puStack_5c == (undefined4 *)0x0) {
          puStack_5c = (undefined4 *)0x0;
        }
        else {
          puStack_5c[1] = 1;
          puStack_5c[2] = 1;
          *puStack_5c = std::
                        _Ref_count_obj<class_std::vector<__int64,class_std::allocator<__int64>_>_>::
                        vftable;
          puStack_5c[3] = 0;
          puStack_5c[4] = 0;
          puStack_5c[5] = 0;
        }
        piVar6 = puStack_5c + 3;
        uStack_480._4_4_ = (int **)(param_3[1] - *param_3 >> 3);
        uStack_8._0_1_ = 6;
        uVar2 = (undefined)uStack_8;
        uStack_8._0_1_ = 6;
        piStack_74 = piVar6;
        puStack_70 = puStack_5c;
        if ((uint)(puStack_5c[5] - *piVar6 >> 3) < uStack_480._4_4_) {
          if (0x1fffffff < uStack_480._4_4_) {
                    /* WARNING: Subroutine does not return */
            uStack_480._4_4_ = (int **)&UNK_00adc7cf;
            uStack_8._0_1_ = uVar2;
            FUN_00577c30();
          }
          uStack_480._0_4_ = (char *)0xadbbca;
          FUN_00a20300();
        }
        uStack_480._4_4_ = (int **)*param_3;
        piStack_14 = (int *)param_3[1];
        piVar10 = piStack_48;
        piStack_60 = (int *)uStack_480._4_4_;
        if (uStack_480._4_4_ != (int **)piStack_14) {
          do {
            uStack_480._0_4_ = (char *)0xadbbe9;
            piStack_60 = (int *)uStack_480._4_4_;
            FUN_00557fc0();
            puVar4 = puStack_20;
            uStack_8._0_1_ = 7;
            if (puStack_20 == (undefined *)0x0) {
              uStack_498._4_4_ = (char *)0x46;
              uStack_498._0_4_ =
                   "TeleportService:TeleportPartyAsync error: A supplied instance is null.";
LAB_00adbf0f:
              uStack_480._0_4_ = (char *)0x0;
              uStack_480._4_4_ = (int **)0xf;
              ppiStack_490 = (int **)((uint)ppiStack_490 & 0xffffff00);
              pcStack_49c = (char *)0xadbf25;
              FUN_005542c0();
LAB_00adbf25:
              uStack_498._4_4_ = (char *)0xadbf30;
              FUN_005e65e0();
              uStack_480._4_4_ = (int **)0xadbf38;
              FUN_00550b30();
              goto LAB_00adc69a;
            }
            uStack_480._4_4_ = (int **)0xadbbff;
            iVar5 = FUN_0068f340();
            iVar9 = iStack_40;
            if (iVar5 == 0) {
              uStack_498._4_4_ = *(char **)(puVar4 + 0x28);
              if (0xf < *(uint *)((int)uStack_498._4_4_ + 0x14)) {
                uStack_498._4_4_ = *(char **)uStack_498._4_4_;
              }
              pcStack_49c = (char *)&ppiStack_490;
              uStack_498._0_4_ =
                   "TeleportService:TeleportPartyAsync error: Supplied Player is not valid. Invalid instance name is %s"
              ;
              puStack_4a0 = (undefined *)0xadbefe;
              FUN_01675640();
              goto LAB_00adbf25;
            }
            uStack_480._4_4_ = (int **)0xadbc13;
            lVar11 = FUN_00928340();
            uVar8 = (uint)((ulonglong)lVar11 >> 0x20);
            iVar9 = iVar9 + 0xc5 + (uint)*(byte *)(iVar9 + 0xc4);
            uStack_480._4_4_ = (int **)(-(uint)(iVar9 != 0) & iVar9 + 1U);
            if ((lVar11 < 0x100000000) && (lVar11 < 0)) {
              uVar8 = -uVar8 - 1;
            }
            uStack_480._0_4_ = (char *)&uStack_84;
            puStack_484 = (undefined8 *)((uVar8 >> 2) + uVar8 * 0x40 + (int)lVar11 ^ uVar8);
            ppuStack_488 = &puStack_78;
            ppiStack_48c = (int **)0xadbc78;
            uStack_84 = lVar11;
            FUN_00606ff0();
            if (puStack_78 != (undefined *)0x0) {
              uStack_498._4_4_ = (char *)0xadbed0;
              uStack_498 = FUN_00928340();
              pcStack_49c = 
              "TeleportService:TeleportPartyAsync error: The player[%lld] already in another teleporting party."
              ;
              uStack_4a4 = 0xadbedd;
              puStack_4a0 = (undefined *)&ppiStack_490;
              FUN_01675640();
              goto LAB_00adbf25;
            }
            uStack_480._4_4_ = (int **)0xadbc89;
            uStack_480 = FUN_00928340();
            puStack_484 = (undefined8 *)auStack_cc;
            ppuStack_488 = (undefined **)0xadbc9a;
            piVar6 = (int *)FUN_0097fc00();
            iVar9 = *piVar6;
            uStack_480._4_4_ = (int **)0xadbca7;
            FUN_00550b30();
            if (iVar9 == 0) {
              uStack_498._0_4_ = (char *)&ppiStack_490;
              uStack_498._4_4_ =
                   "TeleportService:TeleportPartyAsync error: A specified Player is not a valid User."
              ;
              pcStack_49c = (char *)0xadbec1;
              FUN_01675640();
              goto LAB_00adbf25;
            }
            if (*(int *)(iVar5 + 0xf4) < 0) {
              uStack_498._4_4_ = (char *)0x42;
              uStack_498._0_4_ =
                   "TeleportService:TeleportPartyAsync error: Doesn\'t support a guest.";
              goto LAB_00adbf0f;
            }
            uStack_480._4_4_ = (int **)(iVar5 + 0x2a8);
            uStack_480._0_4_ = (char *)0xadbcdd;
            FUN_0054ef60();
            uStack_8._0_1_ = 8;
            if (iStack_94 == 0) {
              uStack_498._4_4_ = (char *)0xadbe70;
              uStack_498 = FUN_00928340();
              pcStack_49c = 
              "TeleportService:TeleportPartyAsync error: The player[%lld] with wrong session.";
              uStack_4a4 = 0xadbe7d;
              puStack_4a0 = (undefined *)&ppiStack_490;
              FUN_01675640();
              uStack_498._4_4_ = (char *)0xadbe8b;
              FUN_005e65e0();
              uStack_480._4_4_ = (int **)0xadbe96;
              FUN_005507b0();
              uStack_480._4_4_ = (int **)0xadbe9e;
              FUN_00550b30();
              goto LAB_00adc69a;
            }
            uStack_480._4_4_ = (int **)auStack_50;
            uStack_480._0_4_ = (char *)0xadbcf7;
            FUN_00888650();
            uStack_8._0_1_ = 9;
            uStack_480._4_4_ = (int **)0xadbd05;
            uVar12 = FUN_00928340();
            uStack_480._4_4_ = (int **)0x6;
            uStack_480._0_4_ = "userId";
            uStack_28 = 0;
            uStack_24 = 0xf;
            auStack_38[0] = 0;
            puStack_484 = (undefined8 *)0xadbd32;
            uStack_8c = uVar12;
            FUN_005542c0();
            uStack_480._4_4_ = (int **)&uStack_8c;
            uStack_480._0_4_ = auStack_38;
            uStack_8._0_1_ = 10;
            puStack_484 = (undefined8 *)0xadbd49;
            FUN_005c4c00();
            uStack_480._0_4_ = (char *)0xadbd51;
            FUN_00632bc0();
            uStack_8._0_1_ = 9;
            uStack_480._4_4_ = (int **)0xadbd5d;
            FUN_005507b0();
            uStack_480._4_4_ = (int **)0xb;
            uStack_480._0_4_ = "gameSession";
            uStack_28 = 0;
            uStack_24 = 0xf;
            auStack_38[0] = 0;
            puStack_484 = (undefined8 *)0xadbd7e;
            FUN_005542c0();
            uStack_480._4_4_ = (int **)auStack_38;
            uStack_8._0_1_ = 0xb;
            uStack_480._0_4_ = (char *)0xadbd8e;
            iVar9 = FUN_005c4c00();
            uStack_480._4_4_ = (int **)0xadbd95;
            uVar7 = FUN_0088cb40();
            *(undefined4 *)(iVar9 + 0x18) = uVar7;
            uStack_480._4_4_ = (int **)auStack_a4;
            uStack_480._0_4_ = (char *)0xadbda7;
            FUN_005c17a0();
            uStack_8 = CONCAT31(uStack_8._1_3_,9);
            uStack_480._4_4_ = (int **)0xadbdb3;
            FUN_005507b0();
            uStack_480._4_4_ = (int **)0xadbdba;
            uVar12 = FUN_00928340();
            piVar6 = puStack_5c + 3;
            uStack_480._0_4_ = (char *)puStack_5c[4];
            uStack_58 = uVar12;
            if ((char *)puStack_5c[5] == (char *)uStack_480) {
              uStack_480._4_4_ = (int **)&uStack_58;
              puStack_484 = (undefined8 *)0xadbde7;
              FUN_006c6ad0();
            }
            else {
              *(undefined8 *)(char *)uStack_480 = uVar12;
              puStack_5c[4] = puStack_5c[4] + 8;
            }
            uStack_480._4_4_ = (int **)auStack_50;
            uStack_480._0_4_ = (char *)0xadbdf3;
            uStack_480._4_4_ = (int **)FUN_00557fc0();
            uStack_8._0_1_ = 0xc;
            uStack_480._0_4_ = (char *)0xadbe03;
            FUN_005c15a0();
            piVar10 = piStack_48;
            uStack_480._4_4_ = (int **)auStack_19c;
            uStack_8._0_1_ = 0xd;
            uStack_480._0_4_ = (char *)0xadbe18;
            FUN_005cd7a0();
            uStack_480._4_4_ = (int **)0xadbe23;
            FUN_0056e5b0();
            uStack_480._4_4_ = (int **)0xadbe2b;
            FUN_00550b30();
            uStack_480._4_4_ = (int **)0xadbe33;
            FUN_00550b30();
            uStack_480._4_4_ = (int **)0xadbe3e;
            FUN_005507b0();
            uStack_8._0_1_ = 6;
            uStack_480._4_4_ = (int **)0xadbe4a;
            FUN_00550b30();
            uStack_480._4_4_ = (int **)(piStack_60 + 2);
            piStack_60 = (int *)uStack_480._4_4_;
          } while (uStack_480._4_4_ != (int **)piStack_14);
        }
        uStack_480._0_4_ = (char *)((piVar10[1] - *piVar10) / 0xd0);
        if ((char *)uStack_480 == (char *)0x0) {
          uStack_498._4_4_ = (char *)0x50;
          uStack_480._4_4_ = (int **)0xf;
          uStack_498._0_4_ =
               "TeleportService:TeleportPartyAsync error: The requested Teleport Group is empty.";
          ppiStack_490 = (int **)((uint)ppiStack_490 & 0xffffff00);
          pcStack_49c = (char *)0xadbf75;
          FUN_005542c0();
          uStack_498._4_4_ = (char *)0xadbf80;
          FUN_005e65e0();
        }
        else {
          uStack_480._4_4_ = (int **)auStack_50;
          uStack_480._0_4_ = (char *)0xadbf8e;
          FUN_00888650();
          uStack_480._4_4_ = (int **)0x7;
          uStack_480._0_4_ = "placeId";
          uStack_8._0_1_ = 0xe;
          uStack_28 = 0;
          uStack_24 = 0xf;
          auStack_38[0] = 0;
          puStack_484 = (undefined8 *)0xadbfb6;
          FUN_005542c0();
          uStack_480._4_4_ = (int **)&param_1;
          uStack_480._0_4_ = auStack_38;
          uStack_8._0_1_ = 0xf;
          puStack_484 = (undefined8 *)0xadbfca;
          FUN_005c4c00();
          uStack_480._0_4_ = (char *)0xadbfd2;
          FUN_00632bc0();
          uStack_480._4_4_ = (int **)0xadbfda;
          FUN_005507b0();
          if (iStack_44 != 0) {
            LOCK();
            *(int *)(iStack_44 + 4) = *(int *)(iStack_44 + 4) + 1;
            UNLOCK();
          }
          iStack_1c = iStack_44;
          uStack_480._4_4_ = (int **)0x7;
          uStack_480._0_4_ = "members";
          uStack_8._0_1_ = 0x10;
          uStack_28 = 0;
          uStack_24 = 0xf;
          auStack_38[0] = 0;
          puStack_484 = (undefined8 *)0xadc010;
          FUN_005542c0();
          uStack_480._4_4_ = (int **)auStack_38;
          uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
          uStack_480._0_4_ = (char *)0xadc020;
          iVar9 = FUN_005c4c00();
          uStack_480._4_4_ = (int **)0xadc027;
          uVar7 = FUN_008882f0();
          *(undefined4 *)(iVar9 + 0x18) = uVar7;
          uStack_480._4_4_ = (int **)0xadc02f;
          piStack_14 = (int *)FUN_005c9da0();
          piVar10 = *(int **)(iVar9 + 0x1c);
          if (piVar10 == piStack_14) {
            *(int **)(iVar9 + 0x20) = piStack_48;
            piVar10 = *(int **)(iVar9 + 0x24);
            *(int *)(iVar9 + 0x24) = iStack_44;
            puStack_20 = (undefined *)0x0;
            iStack_1c = 0;
            piStack_14 = piVar10;
            if (piVar10 != (int *)0x0) {
              LOCK();
              iVar9 = piVar10[1] + -1;
              piVar10[1] = iVar9;
              UNLOCK();
              if (iVar9 == 0) {
                uStack_480._4_4_ = (int **)0xadc06f;
                (**(code **)*piVar10)();
                LOCK();
                iVar9 = piVar10[2] + -1;
                piVar10[2] = iVar9;
                UNLOCK();
                if (iVar9 == 0) {
                  uStack_480._4_4_ = (int **)0xadc07f;
                  (**(code **)(*piVar10 + 4))();
                }
              }
            }
          }
          else {
            if (piVar10 != (int *)0x0) {
              uStack_480._4_4_ = (int **)(iVar9 + 0x20);
              uStack_480._0_4_ = (char *)0xadc08e;
              (*(code *)piVar10[2])();
            }
            *(int **)(iVar9 + 0x20) = piStack_48;
            *(int *)(iVar9 + 0x24) = iStack_44;
            puStack_20 = (undefined *)0x0;
            iStack_1c = 0;
            *(int **)(iVar9 + 0x1c) = piStack_14;
          }
          uStack_480._4_4_ = (int **)0xadc0b9;
          FUN_005507b0();
          uStack_480._4_4_ = (int **)0xadc0c1;
          FUN_00550b30();
          uStack_ac = 0;
          uStack_a8 = 0xf;
          auStack_bc[0] = 0;
          uStack_480._4_4_ = (int **)auStack_50;
          uStack_480._0_4_ = (char *)0xadc0e8;
          uStack_480._4_4_ = (int **)FUN_00557fc0();
          uStack_8._0_1_ = 0x13;
          uStack_480._0_4_ = (char *)0xadc0f8;
          FUN_005c15a0();
          uStack_480._4_4_ = (int **)0x1;
          uStack_480._0_4_ = auStack_bc;
          uStack_8._0_1_ = 0x14;
          puStack_484 = (undefined8 *)auStack_19c;
          ppuStack_488 = (undefined **)0xadc111;
          FUN_0098fc00();
          uStack_480._4_4_ = (int **)0xadc11f;
          FUN_0056e5b0();
          uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
          uStack_480._4_4_ = (int **)0xadc12b;
          FUN_00550b30();
          uStack_480._4_4_ = (int **)0x18;
          uStack_480._0_4_ = (char *)0xadc132;
          piStack_14 = (int *)FUN_01674e20();
          if (piStack_14 == (int *)0x0) {
            uStack_480._0_4_ = (char *)0x0;
          }
          else {
            uStack_480._4_4_ = (int **)&uStack_15;
            uStack_480._0_4_ = &uStack_15;
            puStack_484 = (undefined8 *)&uStack_15;
            ppuStack_488 = (undefined **)0xb;
            ppiStack_48c = (int **)0xadc151;
            uStack_480._0_4_ = (char *)FUN_005693e0();
          }
          uStack_480._4_4_ = (int **)param_2;
          puStack_20 = (undefined *)0x0;
          iStack_1c = 0;
          puStack_484 = (undefined8 *)0xadc16f;
          FUN_005c1af0();
          uStack_480._4_4_ = (int **)0x7;
          uStack_480._0_4_ = "placeId";
          uStack_8._0_1_ = 0x15;
          uStack_28 = 0;
          uStack_24 = 0xf;
          auStack_38[0] = 0;
          puStack_484 = (undefined8 *)0xadc194;
          FUN_005542c0();
          uStack_480._4_4_ = (int **)&param_1;
          uStack_480._0_4_ = auStack_38;
          uStack_8._0_1_ = 0x16;
          puStack_484 = (undefined8 *)0xadc1aa;
          FUN_005c4c00();
          uStack_480._0_4_ = (char *)0xadc1b2;
          FUN_00632bc0();
          uStack_8._0_1_ = 0x15;
          uStack_480._4_4_ = (int **)0xadc1be;
          FUN_005507b0();
          uStack_480._4_4_ = (int **)0xc;
          uStack_480._0_4_ = "teleportData";
          uStack_28 = 0;
          uStack_24 = 0xf;
          auStack_38[0] = 0;
          puStack_484 = (undefined8 *)0xadc1df;
          FUN_005542c0();
          uStack_480._4_4_ = (int **)&param_5;
          uStack_8._0_1_ = 0x17;
          uStack_480._0_4_ = auStack_38;
          puStack_484 = (undefined8 *)0xadc1f2;
          FUN_005c4c00();
          uStack_480._0_4_ = (char *)0xadc1fa;
          FUN_0056ee80();
          uStack_8._0_1_ = 0x15;
          uStack_480._4_4_ = (int **)0xadc206;
          FUN_005507b0();
          uStack_480._4_4_ = (int **)0xe;
          uStack_480._0_4_ = "teleportMethod";
          piStack_14 = (int *)0x3;
          uStack_28 = 0;
          uStack_24 = 0xf;
          auStack_38[0] = 0;
          puStack_484 = (undefined8 *)0xadc22e;
          FUN_005542c0();
          uStack_480._4_4_ = &piStack_14;
          uStack_8._0_1_ = 0x18;
          uStack_480._0_4_ = auStack_38;
          puStack_484 = (undefined8 *)0xadc241;
          FUN_005c4c00();
          uStack_480._0_4_ = (char *)0xadc249;
          FUN_00ac08e0();
          uStack_8._0_1_ = 0x15;
          uStack_480._4_4_ = (int **)0xadc255;
          FUN_005507b0();
          iVar9 = piVar6[1];
          iVar5 = *piVar6;
          if (iVar5 != iVar9) {
            iStack_68 = 0;
            uStack_64 = 0;
            uStack_6c = -(uint)(iStack_40 != -199) & iStack_40 + 200U;
            ppuStack_488 = (undefined **)&uStack_6c;
            uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
            ppiStack_48c = (int **)0xadc295;
            puStack_484 = (undefined8 *)iVar5;
            uStack_480._0_4_ = (char *)iVar5;
            uStack_480._4_4_ = (int **)iVar9;
            FUN_00ac3720();
            while (iVar5 = iVar5 + 8, iVar5 != iVar9) {
              ppuStack_488 = (undefined **)&uStack_6c;
              ppiStack_48c = (int **)0xadc2ae;
              puStack_484 = (undefined8 *)iVar5;
              uStack_480._0_4_ = (char *)iVar5;
              uStack_480._4_4_ = (int **)iVar9;
              FUN_00ac3720();
            }
            uStack_8._1_3_ = (undefined3)((uint)uStack_8 >> 8);
            uStack_8._0_1_ = 0x15;
            if (iStack_68 != 0) {
              uStack_480._4_4_ = (int **)0x10;
              puStack_484 = (undefined8 *)0xadc2c8;
              uStack_480._0_4_ = (char *)iStack_68;
              FUN_01674ea0();
            }
          }
          uStack_480._4_4_ = (int **)puStack_3c;
          ppuStack_488 = &puStack_20;
          ppiStack_48c = (int **)0xadc2dc;
          FUN_00557fc0();
          ppiStack_490 = &piStack_74;
          uStack_498._4_4_ = (char *)0xadc2ea;
          FUN_00557fc0();
          ppiStack_490 = (int **)0xadc2ef;
          FUN_00ad6130();
          if (DAT_01d66658 != '\0') {
            uStack_480._4_4_ = (int **)0x11;
            uStack_480._0_4_ = "groupTeleportGuid";
            uStack_28 = 0;
            uStack_24 = 0xf;
            auStack_38[0] = 0;
            puStack_484 = (undefined8 *)0xadc320;
            FUN_005542c0();
            uStack_480._4_4_ = (int **)auStack_38;
            uStack_480._0_4_ = (char *)&puStack_3c;
            puStack_484 = (undefined8 *)0xadc330;
            FUN_008a0c70();
            uStack_480._4_4_ = (int **)0xadc338;
            FUN_005507b0();
            if (puStack_3c != (undefined *)0x0) {
              iVar9 = *(int *)(puStack_3c + 0x20);
              uStack_480._4_4_ = (int **)0xadc34b;
              iVar5 = FUN_0088cb40();
              if (iVar9 == iVar5) {
                uStack_480._4_4_ = (int **)auStack_a4;
                uStack_480._0_4_ = (char *)0xadc35e;
                FUN_00563690();
                uStack_480._4_4_ = (int **)0xa;
                uStack_480._0_4_ = "teleportId";
                uStack_8._0_1_ = 0x1a;
                uStack_28 = 0;
                uStack_24 = 0xf;
                auStack_38[0] = 0;
                puStack_484 = (undefined8 *)0xadc383;
                FUN_005542c0();
                uStack_480._4_4_ = (int **)auStack_38;
                uStack_8._0_1_ = 0x1b;
                uStack_480._0_4_ = (char *)0xadc393;
                iVar9 = FUN_005c4c00();
                uStack_480._4_4_ = (int **)0xadc39a;
                uVar7 = FUN_0088cb40();
                *(undefined4 *)(iVar9 + 0x18) = uVar7;
                uStack_480._4_4_ = (int **)auStack_a4;
                uStack_480._0_4_ = (char *)0xadc3ac;
                FUN_005c17a0();
                uStack_480._4_4_ = (int **)0xadc3b4;
                FUN_005507b0();
                uStack_8._0_1_ = 0x15;
                uStack_480._4_4_ = (int **)0xadc3c3;
                FUN_005507b0();
              }
            }
          }
          uStack_480._4_4_ = (int **)0x29;
          uStack_480._0_4_ = "TeleportPartyAsyncRequestingGroupTeleport";
          uStack_28 = 0;
          uStack_24 = 0xf;
          auStack_38[0] = 0;
          puStack_484 = (undefined8 *)0xadc3e4;
          FUN_005542c0();
          uStack_480._4_4_ = (int **)0x0;
          puStack_484 = (undefined8 *)auStack_38;
          uStack_8._0_1_ = 0x1c;
          uStack_480._0_4_ = (char *)0x1;
          ppuStack_488 = (undefined **)0xadc3f5;
          FUN_008783f0();
          uStack_8._0_1_ = 0x15;
          uStack_480._4_4_ = (int **)0xadc404;
          FUN_005507b0();
          if (DAT_01d66668 == '\0') {
            uStack_480._4_4_ = (int **)&uStack_58;
            uStack_480._0_4_ = (char *)0xadc5df;
            FUN_00ac38f0();
            param_2 = &uStack_498;
            uStack_8._0_1_ = 0x27;
            pcStack_49c = (char *)&stack0x0000010c;
            puStack_4a0 = (undefined *)0xadc5f7;
            FUN_0054f510();
            puStack_3c = (undefined *)appuStack_4b8;
            uStack_8._0_1_ = 0x28;
            puStack_4bc = &stack0x000000ec;
            pcStack_4c0 = (char *)0xadc60f;
            FUN_0054f510();
            piStack_14 = (int *)&pcStack_4c0;
            puStack_4c4 = &stack0x000000e4;
            uStack_4c8 = 0xadc623;
            FUN_00557fc0();
            puStack_7c = (undefined *)&uStack_4c8;
            ppuStack_4cc = &puStack_20;
            uStack_4d0 = 0xadc634;
            FUN_00557fc0();
            puStack_78 = (undefined *)&uStack_4d0;
            puStack_4d4 = &uStack_58;
            iStack_4d8 = 0xadc645;
            FUN_00557fc0();
            piStack_60 = &iStack_4d8;
            FUN_00557fc0(&piStack_74);
            uStack_8._0_1_ = 0x2d;
            FUN_0054ef60(auStack_bc);
            uStack_8._0_1_ = 0x27;
            FUN_00adaec0();
            uStack_480._4_4_ = (int **)0xadc67f;
            FUN_00550b30();
          }
          else {
            uStack_480._4_4_ = (int **)iStack_40;
            uStack_480._0_4_ = (char *)0xadc41a;
            FUN_00672490();
            puStack_484 = &uStack_58;
            uStack_480._0_4_ = (char *)iStack_40;
            ppuStack_488 = (undefined **)0xadc426;
            FUN_0060e0c0();
            uStack_480._4_4_ = (int **)&stack0x0000010c;
            uStack_8._0_1_ = 0x1d;
            uStack_480._0_4_ = (char *)&stack0x000000ec;
            puStack_484 = (undefined8 *)&stack0x000000e4;
            ppuStack_488 = &puStack_20;
            ppiStack_48c = &piStack_74;
            ppiStack_490 = (int **)auStack_bc;
            uStack_498._4_4_ = (char *)&uStack_58;
            uStack_498._0_4_ = (char *)0xadc460;
            FUN_00ac3d00();
            puStack_3c = (undefined *)&uStack_498;
            uStack_8._0_1_ = 0x1e;
            pcStack_49c = (char *)&stack0x0000010c;
            puStack_4a0 = (undefined *)0xadc478;
            FUN_0054f510();
            uStack_8._0_1_ = 0x1f;
            puStack_4bc = (undefined4 *)auStack_144;
            pcStack_4c0 = (char *)0xadc493;
            FUN_00ac3b80();
            puStack_4bc = (undefined4 *)auStack_46c;
            uStack_8._0_1_ = 0x20;
            pcStack_4c0 = (char *)0xadc4a9;
            FUN_00ac3b80();
            puStack_4bc = (undefined4 *)auStack_3f4;
            uStack_8._0_1_ = 0x21;
            appuStack_4b8[0] = (undefined **)0x0;
            pcStack_4c0 = (char *)0xadc4c5;
            FUN_00ac3b80();
            puStack_4bc = (undefined4 *)auStack_37c;
            uStack_8._0_1_ = 0x22;
            pcStack_4c0 = (char *)0xadc4db;
            FUN_00ac3b80();
            puStack_4bc = (undefined4 *)auStack_304;
            uStack_8._0_1_ = 0x23;
            pcStack_4c0 = (char *)0xadc4f1;
            FUN_00ac3b80();
            puStack_4bc = (undefined4 *)auStack_214;
            uStack_8._0_1_ = 0x24;
            pcStack_4c0 = (char *)0xadc501;
            cVar3 = FUN_00585a40();
            if (cVar3 == '\0') {
              puStack_4bc = (undefined4 *)auStack_214;
              pcStack_4c0 = (char *)0xadc51a;
              FUN_00ac3b80();
              puStack_4bc = (undefined4 *)0x78;
              uStack_8._0_1_ = 0x25;
              pcStack_4c0 = (char *)0xadc525;
              piStack_14 = (int *)FUN_01674e20();
              uStack_8._0_1_ = 0x26;
              if (piStack_14 == (int *)0x0) {
                uStack_4b0 = 0;
              }
              else {
                puStack_4bc = (undefined4 *)auStack_28c;
                pcStack_4c0 = (char *)0xadc541;
                uStack_4b0 = FUN_00ac3b80();
              }
              puStack_4bc = (undefined4 *)0xadc553;
              FUN_00ac7a50();
              puStack_4bc = (undefined4 *)0xadc55e;
              FUN_00ac7a50();
              bVar1 = true;
            }
            else {
              puStack_4bc = (undefined4 *)0xadc56d;
              FUN_00ac7a50();
              bVar1 = false;
            }
            puStack_4bc = (undefined4 *)0xadc57a;
            FUN_00ac7a50();
            appuStack_4b8[0] = &PTR_FUN_0194b544;
            if (!bVar1) {
              appuStack_4b8[0] = (undefined **)0x0;
            }
            puStack_4bc = (undefined4 *)0xadc593;
            FUN_00ac7a50();
            puStack_4bc = (undefined4 *)0xadc59e;
            FUN_00ac7a50();
            uStack_8._0_1_ = 0x1f;
            puStack_4bc = (undefined4 *)0xadc5ad;
            FUN_00ac7a50();
            puStack_4bc = (undefined4 *)param_2;
            uStack_8._0_1_ = 0x1e;
            pcStack_4c0 = param_1;
            puStack_4c4 = (undefined *)0xadc5be;
            FUN_00bfcc70();
            uStack_480._4_4_ = (int **)0xadc5c9;
            FUN_00ac7a50();
            uStack_480._4_4_ = (int **)0xadc5d1;
            FUN_0056c200();
          }
          uStack_480._4_4_ = (int **)0xadc687;
          FUN_00550b30();
          uStack_480._4_4_ = (int **)0xadc692;
          FUN_005507b0();
          uStack_480._4_4_ = (int **)0xadc69a;
          FUN_00550b30();
        }
LAB_00adc69a:
        uStack_480._4_4_ = (int **)0xadc6a2;
        FUN_00550b30();
        uStack_480._4_4_ = (int **)0xadc6aa;
        FUN_00550b30();
        goto LAB_00adc6f1;
      }
      uStack_498._0_4_ = (char *)&ppiStack_490;
      uStack_498._4_4_ =
           "TeleportService:TeleportPartyAsync error: Must be passed an array of players";
      pcStack_49c = (char *)0xadc6bf;
      FUN_01675640();
    }
  }
  uStack_498._4_4_ = (char *)0xadc6f1;
  FUN_005e65e0();
LAB_00adc6f1:
  piVar6 = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar9 = param_4[1] + -1;
    param_4[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      uStack_480._4_4_ = (int **)0xadc707;
      (**(code **)*param_4)();
      LOCK();
      piVar10 = piVar6 + 2;
      iVar9 = *piVar10 + -1;
      *piVar10 = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        uStack_480._4_4_ = (int **)0xadc717;
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x2e);
  if (param_6 != 0) {
    uStack_480._4_4_ = (int **)&stack0x0000001c;
    uStack_480._0_4_ = (char *)0xadc72b;
    (**(code **)(param_6 + 8))();
  }
  piVar6 = in_stack_000000e8;
  if (in_stack_000000e8 != (int *)0x0) {
    LOCK();
    iVar9 = in_stack_000000e8[1] + -1;
    in_stack_000000e8[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      uStack_480._4_4_ = (int **)0xadc747;
      (**(code **)*in_stack_000000e8)();
      LOCK();
      piVar10 = piVar6 + 2;
      iVar9 = *piVar10;
      *piVar10 = *piVar10 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        uStack_480._4_4_ = (int **)0xadc756;
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x2f);
  if (in_stack_000000ec != 0) {
    if (((in_stack_000000ec & 1) == 0) &&
       (*(code **)(in_stack_000000ec & 0xfffffffe) != (code *)0x0)) {
      puStack_484 = (undefined8 *)&stack0x000000f4;
      uStack_480._4_4_ = (int **)0x2;
      ppuStack_488 = (undefined **)0xadc77d;
      uStack_480._0_4_ = (char *)puStack_484;
      (**(code **)(in_stack_000000ec & 0xfffffffe))();
    }
    in_stack_000000ec = 0;
  }
  uStack_8 = 0x30;
  if (((in_stack_0000010c != 0) && ((in_stack_0000010c & 1) == 0)) &&
     (*(code **)(in_stack_0000010c & 0xfffffffe) != (code *)0x0)) {
    puStack_484 = (undefined8 *)&stack0x00000114;
    uStack_480._4_4_ = (int **)0x2;
    ppuStack_488 = (undefined **)0xadc7b4;
    uStack_480._0_4_ = (char *)puStack_484;
    (**(code **)(in_stack_0000010c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22426 ; VA 0x00adc7d0 ; FUN_00adc7d0 */

int FUN_00adc7d0(int *param_1,int *param_2,int param_3,int *param_4,undefined4 param_5,int *param_6,
                undefined4 param_7,int *param_8,undefined4 param_9,int *param_10)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piVar5;
  undefined uVar6;
  undefined1 *puStack_148;
  undefined4 uStack_144;
  undefined auStack_140 [8];
  undefined4 uStack_138;
  int *piStack_134;
  undefined1 *puStack_130;
  undefined4 *puStack_12c;
  uint uStack_128;
  undefined *puStack_124;
  undefined4 uStack_120;
  undefined *puStack_11c;
  undefined4 uStack_118;
  int *piStack_114;
  undefined8 uStack_110;
  undefined auStack_f4 [204];
  undefined *puStack_28;
  undefined *puStack_24;
  int aiStack_20 [3];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ea5e3;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  uStack_110._0_4_ = (int *)0xadc803;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0064e810();
  if ((iVar2 != 0) && (param_1 != (int *)0x0)) {
    piVar1 = (int *)param_1[1];
    piVar5 = (int *)*param_1;
    iVar4 = (int)piVar1 - (int)piVar5;
    iVar2 = iVar4 >> 0x1f;
    if ((iVar4 / 0xd0 + iVar2 != iVar2) && (param_3 != 0)) {
      for (; piVar5 != piVar1; piVar5 = piVar5 + 0x34) {
        puVar3 = (undefined4 *)piVar5[1];
        iVar2 = *piVar5;
        if (puVar3 != (undefined4 *)0x0) {
          uStack_110._4_4_ = auStack_f4;
          uStack_110._0_4_ = piVar5 + 2;
          piStack_114 = (int *)0xadc878;
          (*(code *)*puVar3)();
          puVar3 = (undefined4 *)piVar5[1];
        }
        uStack_8._0_1_ = 5;
        if (*(char *)(iVar2 + 0x21) == '\0') {
          uStack_110._4_4_ = "TeleportService:TeleportPartyAsync error: A playerId isn\'t a number."
          ;
          uStack_110._0_4_ = (int *)0x3;
          piStack_114 = (int *)0xadc8a0;
          FUN_0086f2f0();
          uStack_8 = CONCAT31(uStack_8._1_3_,6);
        }
        else {
          uStack_110._4_4_ = (char *)0xadc8b7;
          uStack_110 = FUN_00563790();
          piStack_114 = aiStack_20;
          uStack_118 = 0xadc8c4;
          FUN_0097fc00();
          uStack_8._0_1_ = 7;
          uVar6 = (undefined)uStack_8;
          uStack_8._0_1_ = 7;
          if (aiStack_20[0] == 0) {
            uStack_110._4_4_ = (char *)0xadc8d9;
            uStack_110 = FUN_00563790();
            piStack_114 = (int *)0x194acb0;
            uStack_118 = 3;
            puStack_11c = (undefined *)0xadc8e7;
            FUN_0086f2f0();
            uStack_110._4_4_ = (char *)0xadc8f2;
            FUN_00550b30();
            uStack_8 = CONCAT31(uStack_8._1_3_,8);
          }
          else {
            piStack_114 = &param_9;
            uStack_118 = 0xadc909;
            uStack_8._0_1_ = uVar6;
            FUN_00557fc0();
            puStack_11c = (undefined *)&param_7;
            uStack_120 = 0xadc917;
            FUN_00557fc0();
            puStack_124 = (undefined *)&param_5;
            uStack_128 = 0xadc925;
            FUN_00557fc0();
            puStack_12c = &param_3;
            puStack_130 = (undefined1 *)0xadc933;
            FUN_00557fc0();
            piStack_134 = aiStack_20;
            uStack_138 = 0xadc941;
            FUN_00557fc0();
            piStack_134 = (int *)0xadc949;
            FUN_00accbe0();
            uStack_110._4_4_ = (char *)0xadc951;
            uStack_110 = FUN_00928340();
            puStack_14 = (undefined *)&uStack_128;
            puStack_12c = (undefined4 *)0x0;
            uStack_118 = 0;
            piStack_114 = (int *)&DAT_0000000f;
            puStack_130 = &DAT_018bc9b8;
            uStack_128 = uStack_128 & 0xffffff00;
            piStack_134 = (int *)0xadc978;
            FUN_005542c0();
            puStack_24 = auStack_140;
            uStack_8._0_1_ = 9;
            uStack_144 = 0;
            puStack_130 = (undefined1 *)0x0;
            puStack_12c = (undefined4 *)0xf;
            puStack_148 = &DAT_018bc9b8;
            auStack_140[0] = 0;
            FUN_005542c0();
            puStack_28 = (undefined *)&puStack_148;
            FUN_00557fc0(&param_3);
            uStack_8._0_1_ = 0xb;
            uVar6 = 0;
            FUN_005542c0("InitGroupTeleportForUser",0x18);
            uStack_8._0_1_ = 7;
            FUN_00ad71f0(uVar6);
            uStack_110._4_4_ = (char *)0xadc9ec;
            FUN_00550b30();
            uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
          }
        }
        if (puVar3 != (undefined4 *)0x0) {
          uStack_110._4_4_ = auStack_f4;
          uStack_110._0_4_ = (int *)0xadca06;
          (*(code *)puVar3[2])();
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
      }
      uStack_110._0_4_ = (int *)0xadca23;
      iVar2 = FUN_008f7870();
      if (iVar2 != 0) {
        uStack_110._4_4_ = (char *)0xadca32;
        iVar2 = FUN_00ac32c0();
        if (iVar2 != 0) {
          uStack_110._4_4_ = (char *)0x0;
          uStack_110._0_4_ = (int *)((param_1[1] - *param_1) / 0xd0);
          piStack_114 = &param_3;
          uStack_118 = 0xadca5f;
          iVar2 = FUN_00b71660();
        }
      }
      goto LAB_00adca70;
    }
  }
  uStack_110._4_4_ =
       "TeleportService:TeleportPartyAsync error: Unknown error when teleport players.";
  uStack_110._0_4_ = (int *)0x3;
  piStack_114 = (int *)0xadca6d;
  iVar2 = FUN_0086f2f0();
LAB_00adca70:
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar4 = *piVar1;
    iVar2 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      uStack_110._4_4_ = (char *)0xadca89;
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar4 = *piVar1;
      iVar2 = *piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        uStack_110._4_4_ = (char *)0xadca99;
        iVar2 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  piVar1 = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar5 = param_4 + 1;
    iVar4 = *piVar5;
    iVar2 = *piVar5;
    *piVar5 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      uStack_110._4_4_ = (char *)0xadcaaf;
      (**(code **)*param_4)();
      LOCK();
      piVar5 = piVar1 + 2;
      iVar4 = *piVar5;
      iVar2 = *piVar5;
      *piVar5 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        uStack_110._4_4_ = (char *)0xadcabf;
        iVar2 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = param_6;
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar5 = param_6 + 1;
    iVar4 = *piVar5;
    iVar2 = *piVar5;
    *piVar5 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      uStack_110._4_4_ = (char *)0xadcad5;
      (**(code **)*param_6)();
      LOCK();
      piVar5 = piVar1 + 2;
      iVar4 = *piVar5;
      iVar2 = *piVar5;
      *piVar5 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        uStack_110._4_4_ = (char *)0xadcae5;
        iVar2 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = param_8;
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar5 = param_8 + 1;
    iVar4 = *piVar5;
    iVar2 = *piVar5;
    *piVar5 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      uStack_110._4_4_ = (char *)0xadcafb;
      (**(code **)*param_8)();
      LOCK();
      piVar5 = piVar1 + 2;
      iVar4 = *piVar5;
      iVar2 = *piVar5;
      *piVar5 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        uStack_110._4_4_ = (char *)0xadcb0b;
        iVar2 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = param_10;
  if (param_10 != (int *)0x0) {
    LOCK();
    piVar5 = param_10 + 1;
    iVar4 = *piVar5;
    iVar2 = *piVar5;
    *piVar5 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      uStack_110._4_4_ = (char *)0xadcb21;
      iVar2 = (**(code **)*param_10)();
      LOCK();
      piVar5 = piVar1 + 2;
      iVar4 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uStack_110._4_4_ = (char *)0xadcb30;
        iVar2 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 22427 ; VA 0x00adcb50 ; FUN_00adcb50 */

int __thiscall
FUN_00adcb50(undefined4 param_1,int param_2,int param_3,undefined4 param_4,undefined4 param_5,
            int *param_6,undefined4 param_7,undefined4 *param_8,undefined4 param_9,int *param_10,
            undefined4 param_11,int *param_12)

{
  int *piVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  int *piVar10;
  undefined4 *puVar11;
  uint *puVar12;
  uint auStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ea650;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  iVar4 = FUN_008f7870(param_1);
  uVar5 = param_11;
  if (iVar4 != 0) {
    FUN_00acc7f0(param_11,*(undefined4 *)(iVar4 + 0x4a0));
  }
  if ((param_3 < 1) && ((param_3 < 0 || (param_2 == 0)))) {
    FUN_0086f2f0(2,"Cannot teleport to invalid place id %lld. Aborting teleport.",param_2,param_3);
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005542c0("Cannot teleport to invalid place id. Aborting teleport.",0x37);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    iVar4 = FUN_00ada860(2,auStack_34,uVar5);
    if (0xf < uStack_20) {
      uVar9 = uStack_20 + 1;
      uVar8 = auStack_34[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_34[0] - 4);
        uVar9 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      iVar4 = FUN_01674ea0(uVar8,uVar9);
    }
  }
  else {
    FUN_00888650(&uStack_1c);
    uStack_8._0_1_ = 3;
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005542c0("placeId",7);
    puVar11 = &param_2;
    uStack_8._0_1_ = 4;
    FUN_005c4c00(auStack_34);
    FUN_00632bc0(puVar11);
    uStack_8._0_1_ = 3;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_20) {
      uVar9 = uStack_20 + 1;
      uVar8 = auStack_34[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_34[0] - 4);
        uVar9 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005542c0("spawnName",9);
    uStack_8._0_1_ = 5;
    iVar4 = FUN_005c4c00(auStack_34);
    uVar5 = FUN_0088cb40();
    *(undefined4 *)(iVar4 + 0x18) = uVar5;
    FUN_005c17a0(param_7);
    uStack_8._0_1_ = 3;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_20) {
      uVar9 = uStack_20 + 1;
      uVar8 = auStack_34[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_34[0] - 4);
        uVar9 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005542c0("instanceId",10);
    uStack_8._0_1_ = 6;
    iVar4 = FUN_005c4c00(auStack_34);
    uVar5 = FUN_0088cb40();
    *(undefined4 *)(iVar4 + 0x18) = uVar5;
    FUN_005c17a0(param_4);
    uStack_8._0_1_ = 3;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_20) {
      uVar9 = uStack_20 + 1;
      uVar8 = auStack_34[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_34[0] - 4);
        uVar9 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_3c = 0;
    uStack_38 = 0xf;
    auStack_4c[0] = auStack_4c[0] & 0xffffff00;
    uStack_8._0_1_ = 7;
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005542c0("reservedServerAccessCode",0x18);
    puVar12 = auStack_4c;
    uStack_8._0_1_ = 8;
    FUN_005c4c00(auStack_34);
    FUN_00632ce0(puVar12);
    uStack_8._0_1_ = 7;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 7;
    if (0xf < uStack_20) {
      uVar9 = uStack_20 + 1;
      uVar8 = auStack_34[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_34[0] - 4);
        uVar9 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    uStack_8._0_1_ = 3;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_38) {
      uVar9 = uStack_38 + 1;
      uVar8 = auStack_4c[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_4c[0] - 4);
        uVar9 = uStack_38 + 0x24;
        if (0x1f < (auStack_4c[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005542c0("teleportType",0xc);
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    iVar6 = FUN_005c4c00(auStack_34);
    uVar5 = FUN_00adb880();
    *(undefined4 *)(iVar6 + 0x18) = uVar5;
    iVar7 = FUN_00adba10();
    iVar4 = *(int *)(iVar6 + 0x1c);
    if (iVar4 == iVar7) {
      *(int **)(iVar6 + 0x20) = param_12;
    }
    else {
      if (iVar4 != 0) {
        (**(code **)(iVar4 + 8))(iVar6 + 0x20);
      }
      *(int **)(iVar6 + 0x20) = param_12;
      *(int *)(iVar6 + 0x1c) = iVar7;
    }
    uStack_8._0_1_ = 3;
    if (0xf < uStack_20) {
      uVar9 = uStack_20 + 1;
      uVar8 = auStack_34[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_34[0] - 4);
        uVar9 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005542c0("teleportData",0xc);
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    iVar4 = FUN_005c4c00(auStack_34);
    piVar10 = (int *)(iVar4 + 0x1c);
    param_12 = param_8 + 1;
    *(undefined4 *)(iVar4 + 0x18) = *param_8;
    if (param_12 != piVar10) {
      if (*piVar10 != 0) {
        (**(code **)(*piVar10 + 8))(iVar4 + 0x20);
        *piVar10 = 0;
      }
      if ((undefined4 *)*param_12 != (undefined4 *)0x0) {
        (**(code **)*param_12)(param_12 + 1,iVar4 + 0x20);
        *piVar10 = *param_12;
      }
    }
    uStack_8._0_1_ = 3;
    if (0xf < uStack_20) {
      uVar9 = uStack_20 + 1;
      uVar8 = auStack_34[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_34[0] - 4);
        uVar9 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005542c0("teleportMethod",0xe);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    iVar6 = FUN_005c4c00(auStack_34);
    uVar5 = FUN_00adb720();
    *(undefined4 *)(iVar6 + 0x18) = uVar5;
    iVar7 = FUN_00adb9a0();
    iVar4 = *(int *)(iVar6 + 0x1c);
    if (iVar4 == iVar7) {
      *(undefined4 *)(iVar6 + 0x20) = param_11;
    }
    else {
      if (iVar4 != 0) {
        (**(code **)(iVar4 + 8))(iVar6 + 0x20);
      }
      *(undefined4 *)(iVar6 + 0x20) = param_11;
      *(int *)(iVar6 + 0x1c) = iVar7;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (0xf < uStack_20) {
      uVar9 = uStack_20 + 1;
      uVar8 = auStack_34[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_34[0] - 4);
        uVar9 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    cVar3 = FUN_008b9b00(uStack_14);
    if (cVar3 == '\0') {
      FUN_01677ff0();
      if (param_10 != (int *)0x0) {
        LOCK();
        param_10[1] = param_10[1] + 1;
        UNLOCK();
      }
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      iVar4 = FUN_00ace320(uStack_1c,piStack_18,param_9,param_10);
      piVar10 = piStack_18;
    }
    else {
      if (param_10 != (int *)0x0) {
        LOCK();
        param_10[1] = param_10[1] + 1;
        UNLOCK();
      }
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      if (param_6 != (int *)0x0) {
        LOCK();
        param_6[1] = param_6[1] + 1;
        UNLOCK();
      }
      iVar4 = FUN_00accbe0(param_5,param_6,uStack_1c,piStack_18,param_9,param_10,0,0,0,0);
      piVar10 = piStack_18;
    }
    if (piVar10 != (int *)0x0) {
      LOCK();
      piVar1 = piVar10 + 1;
      iVar6 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        (**(code **)*piVar10)();
        LOCK();
        piVar1 = piVar10 + 2;
        iVar6 = *piVar1;
        iVar4 = *piVar1;
        *piVar1 = iVar6 + -1;
        UNLOCK();
        if (iVar6 + -1 == 0) {
          iVar4 = (**(code **)(*piVar10 + 4))();
        }
      }
    }
  }
  piVar10 = param_6;
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar6 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = piVar10 + 2;
      iVar6 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        iVar4 = (**(code **)(*piVar10 + 4))();
      }
    }
  }
  piVar10 = param_10;
  if (param_10 != (int *)0x0) {
    LOCK();
    piVar1 = param_10 + 1;
    iVar6 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      iVar4 = (**(code **)*param_10)();
      LOCK();
      piVar1 = piVar10 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        iVar4 = (**(code **)(*piVar10 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 22428 ; VA 0x00add250 ; FUN_00add250 */

int * __thiscall
FUN_00add250(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d64cb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00add460();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Soundscape::Sound,float>::
              GetSetImpl<float_(__thiscall_RBX::Soundscape::Sound::*)(void)const_,void_(__thiscall_RBX::Soundscape::Sound::*)(float)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::Soundscape::Sound,float>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::Soundscape::Sound,float>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22429 ; VA 0x00add350 ; FUN_00add350 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00add350(undefined4 *param_1,undefined4 *param_2)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eebd94) {
    FUN_016f3809(&DAT_01eebd94);
    if (DAT_01eebd94 == -1) {
      _DAT_01eebd88 = FUN_005c65f0;
      _DAT_01eebd8c = FUN_005c93a0;
      _DAT_01eebd90 = FUN_005c77b0;
      FUN_016f37bf(&DAT_01eebd94);
    }
  }
  puVar1 = (undefined *)*param_1;
  if (puVar1 == &DAT_01eebd88) {
    if (param_1 + 1 != param_2) {
      FUN_005507b0();
      uVar2 = param_2[1];
      uVar3 = param_2[2];
      uVar4 = param_2[3];
      param_1[1] = *param_2;
      param_1[2] = uVar2;
      param_1[3] = uVar3;
      param_1[4] = uVar4;
      *(undefined8 *)(param_1 + 5) = *(undefined8 *)(param_2 + 4);
      param_2[4] = 0;
      param_2[5] = 0xf;
      *(undefined *)param_2 = 0;
    }
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[5] = 0;
  param_1[6] = 0;
  uVar2 = param_2[1];
  uVar3 = param_2[2];
  uVar4 = param_2[3];
  param_1[1] = *param_2;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  param_1[4] = uVar4;
  *(undefined8 *)(param_1 + 5) = *(undefined8 *)(param_2 + 4);
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  *param_1 = &DAT_01eebd88;
  return param_1;
}



/* FUNCTION 22430 ; VA 0x00add460 ; FUN_00add460 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00add460(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ea680;
  pvStack_10 = ExceptionList;
  if (DAT_01eebacc == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eebce0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eebce0);
      if (DAT_01eebce0 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Sound",0,uStack_20,0,0,0x1b,0,&DAT_01ef904c);
        _DAT_01eebcd8 = RBX::Creator<class_RBX::Soundscape::Sound>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01eebad0,&DAT_01eebcd8);
        FUN_016f3654(FUN_0188b850);
        FUN_016f37bf(&DAT_01eebce0);
      }
    }
    DAT_01eebacc = &DAT_01eebad0;
  }
  ExceptionList = pvStack_10;
  return DAT_01eebacc;
}



/* FUNCTION 22431 ; VA 0x00add560 ; FUN_00add560 */

int __thiscall FUN_00add560(uint *param_1,uint param_2,undefined4 *param_3)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  
  uVar4 = *param_1;
  iVar3 = (int)(param_1[1] - uVar4) / 0xc;
  if (iVar3 == 0x15555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar7 = iVar3 + 1;
  uVar5 = (int)(param_1[2] - uVar4) / 0xc;
  uVar8 = uVar7;
  if ((uVar5 <= 0x15555555 - (uVar5 >> 1)) && (uVar8 = (uVar5 >> 1) + uVar5, uVar8 < uVar7)) {
    uVar8 = uVar7;
  }
  uVar5 = uVar8 * 0xc;
  if (uVar8 < 0x15555556) {
    uVar8 = uVar5;
    if (0xfff < uVar5) goto LAB_00add5f7;
    if (uVar5 == 0) {
      uVar8 = 0;
    }
    else {
      uVar8 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar8 = 0xffffffff;
LAB_00add5f7:
    uVar2 = uVar8 + 0x23;
    if (uVar2 <= uVar8) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_00add71c;
    uVar8 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar8 - 4) = iVar3;
  }
  iVar3 = ((int)(param_2 - uVar4) / 0xc) * 0xc;
  *(undefined4 *)(iVar3 + uVar8) = *param_3;
  *(undefined4 *)(iVar3 + 4 + uVar8) = 0;
  *(undefined4 *)(iVar3 + 8 + uVar8) = 0;
  if (param_3[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar3 + 4 + uVar8) = param_3[1];
  *(undefined4 *)(iVar3 + 8 + uVar8) = param_3[2];
  uVar2 = param_1[1];
  uVar4 = *param_1;
  uVar6 = uVar8;
  if (param_2 != uVar2) {
    FUN_00add820(uVar4,param_2,uVar8,param_1);
    uVar2 = param_1[1];
    uVar4 = param_2;
    uVar6 = iVar3 + 0xc + uVar8;
  }
  FUN_00add820(uVar4,uVar2,uVar6,param_1);
  if (*param_1 != 0) {
    FUN_00602e00(*param_1,param_1[1],param_1);
    uVar4 = *param_1;
    uVar6 = ((int)(param_1[2] - uVar4) / 0xc) * 0xc;
    uVar2 = uVar4;
    if (0xfff < uVar6) {
      uVar2 = *(uint *)(uVar4 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar4 - uVar2) - 4) {
LAB_00add71c:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar6);
  }
  *param_1 = uVar8;
  param_1[1] = uVar8 + uVar7 * 0xc;
  param_1[2] = uVar5 + uVar8;
  return *param_1 + iVar3;
}



/* FUNCTION 22432 ; VA 0x00add730 ; FUN_00add730 */

int __thiscall FUN_00add730(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ea690;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Soundscape::Sound*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 22433 ; VA 0x00add802 ; Catch_All@00add802 */

void Catch_All_00add802(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 22434 ; VA 0x00add820 ; FUN_00add820 */

undefined4 *
FUN_00add820(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  
  puVar5 = param_3;
  if (param_1 != param_2) {
    puVar3 = param_1 + 1;
    puVar4 = param_3 + 2;
    do {
      puVar1 = puVar3 + 3;
      *puVar5 = puVar3[-1];
      *(undefined4 *)((int)param_3 + (-0xc - (int)param_1) + (int)puVar1) = 0;
      puVar5 = puVar5 + 3;
      *puVar4 = 0;
      *(undefined4 *)((int)param_3 + (-0xc - (int)param_1) + (int)puVar1) = *puVar3;
      *puVar4 = puVar3[1];
      puVar2 = puVar3 + 2;
      *puVar3 = 0;
      puVar3[1] = 0;
      puVar3 = puVar1;
      puVar4 = puVar4 + 3;
    } while (puVar2 != param_2);
  }
  FUN_00602e00(puVar5,puVar5,param_4);
  return puVar5;
}



/* FUNCTION 22435 ; VA 0x00add8a0 ; FUN_00add8a0 */

undefined4 * FUN_00add8a0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ea6d3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00add460();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x1b0);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00adde80();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00add730(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22436 ; VA 0x00add960 ; FUN_00add960 */

undefined4 __thiscall FUN_00add960(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = thunk_FUN_0088d190();
  if (iVar1 != iVar2) {
    puVar4 = (undefined4 *)param_1[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_1 + 2,auStack_d8);
      puVar4 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    uVar5 = FUN_00e38920();
    FUN_0054ef60(uVar5);
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_d8);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar1 = *param_1;
  iVar2 = thunk_FUN_0088d190();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_0054ef60(piVar3);
    ExceptionList = pvStack_10;
    return param_2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22437 ; VA 0x00adda60 ; FUN_00adda60 */

undefined4 * __thiscall
FUN_00adda60(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ea701;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  uVar1 = FUN_00add460();
  FUN_009cb970(uVar1,param_3,0,CONCAT44(uStack_28,uStack_2c),0);
  param_1[0xd] = param_2;
  iStack_8 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::Soundscape::Sound,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::Soundscape::Sound::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,param_3);
  iStack_8._0_1_ = 2;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = uStack_1c;
    param_1[0xb] = uStack_18;
    param_1[0xc] = uStack_14;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
  }
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::Soundscape::Sound,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::Soundscape::Sound::*>
             ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22438 ; VA 0x00addba0 ; FUN_00addba0 */

undefined4 * __thiscall
FUN_00addba0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10)

{
  undefined4 uVar1;
  undefined auStack_1e8 [432];
  undefined8 uStack_38;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_017ea73c;
  pvStack_1c = ExceptionList;
  uStack_38 = param_7;
  ExceptionList = &pvStack_1c;
  puStack_30 = param_1;
  uVar1 = FUN_00add460();
  FUN_009cb970(uVar1,param_3,param_6,uStack_38,param_8);
  param_1[0xd] = param_2;
  iStack_14 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::Soundscape::Sound,void___cdecl(double,double),class_rbx::remote_signal<void___cdecl(double,double)>,class_rbx::remote_signal<void___cdecl(double,double)>_RBX::Soundscape::Sound::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088ca00();
  FUN_00888740();
  iStack_14._0_1_ = 1;
  FUN_0086e3d0(param_5);
  FUN_0088ca00();
  FUN_00888740();
  iStack_14._0_1_ = 2;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00687810(auStack_1e8,&uStack_38,puStack_30);
  iStack_14._0_1_ = 3;
  if (param_1 + 10 != &uStack_2c) {
    FUN_0068a760();
    param_1[10] = uStack_2c;
    param_1[0xb] = uStack_28;
    param_1[0xc] = uStack_24;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
  }
  iStack_14._0_1_ = 4;
  FUN_0068a760();
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  FUN_016f32d1(auStack_1e8,0xd8,2,FUN_00688b10);
  param_1[0xe] = param_10;
  param_1[0xf] = param_9;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::Soundscape::Sound,void___cdecl(double,double),class_rbx::remote_signal<void___cdecl(double,double)>,class_rbx::remote_signal<void___cdecl(double,double)>_RBX::Soundscape::Sound::*>
             ::vftable;
  ExceptionList = pvStack_1c;
  return param_1;
}



/* FUNCTION 22439 ; VA 0x00addd20 ; FUN_00addd20 */

undefined4 * __thiscall
FUN_00addd20(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 uVar1;
  undefined auStack_110 [216];
  undefined8 uStack_38;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_017ea771;
  pvStack_1c = ExceptionList;
  uStack_38 = param_6;
  ExceptionList = &pvStack_1c;
  puStack_30 = param_1;
  uVar1 = FUN_00add460();
  FUN_009cb970(uVar1,param_3,param_5,uStack_38,param_7);
  param_1[0xd] = param_2;
  iStack_14 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::Soundscape::Sound,void___cdecl(bool),class_rbx::remote_signal<void___cdecl(bool)>,class_rbx::remote_signal<void___cdecl(bool)>_RBX::Soundscape::Sound::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088daf0();
  FUN_00888740();
  iStack_14._0_1_ = 1;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00687810(auStack_110,&uStack_38,puStack_30);
  iStack_14._0_1_ = 2;
  if (param_1 + 10 != &uStack_2c) {
    FUN_0068a760();
    param_1[10] = uStack_2c;
    param_1[0xb] = uStack_28;
    param_1[0xc] = uStack_24;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
  }
  iStack_14._0_1_ = 3;
  FUN_0068a760();
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  FUN_016f32d1(auStack_110,0xd8,1,FUN_00688b10);
  param_1[0xe] = param_9;
  param_1[0xf] = param_8;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::Soundscape::Sound,void___cdecl(bool),class_rbx::remote_signal<void___cdecl(bool)>,class_rbx::remote_signal<void___cdecl(bool)>_RBX::Soundscape::Sound::*>
             ::vftable;
  ExceptionList = pvStack_1c;
  return param_1;
}



/* FUNCTION 22440 ; VA 0x00adde80 ; FUN_00adde80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __fastcall FUN_00adde80(undefined4 *param_1)

{
  undefined8 uVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ea8c0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::Soundscape::Sound,class_RBX::Instance>::vftable;
  uVar2 = FUN_00add460();
  param_1[3] = uVar2;
  LOCK();
  _DAT_01eebab8 = _DAT_01eebab8 + 1;
  UNLOCK();
  param_1[0x15] = RBX::Soundscape::PlaybackChannelOwner::vftable;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  FUN_00fea5d0();
  uStack_8._0_1_ = 4;
  *param_1 = RBX::Soundscape::Sound::vftable;
  param_1[0x15] = RBX::Soundscape::Sound::vftable;
  param_1[0x16] = RBX::Soundscape::Sound::vftable;
  FUN_00fe8c00();
  param_1[0x44] = 0;
  param_1[0x45] = 0xf;
  *(undefined *)(param_1 + 0x40) = 0;
  param_1[0x46] = 0;
  *(undefined8 *)(param_1 + 0x4a) = 0;
  uVar1 = _PTR_018dab58;
  param_1[0x47] = 0;
  param_1[0x48] = 0;
  param_1[0x49] = 0xffffffff;
  *(undefined8 *)(param_1 + 0x4c) = uVar1;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  param_1[0x50] = 0;
  *(undefined2 *)(param_1 + 0x51) = 0x100;
  *(undefined *)((int)param_1 + 0x146) = 0;
  param_1[0x52] = 0;
  param_1[0x53] = 0;
  param_1[0x54] = 0;
  param_1[0x55] = 0;
  param_1[0x56] = 0;
  param_1[0x57] = 0;
  param_1[0x58] = 0;
  param_1[0x59] = 0;
  param_1[0x5a] = 0;
  param_1[0x5b] = 0;
  param_1[0x5c] = 0;
  param_1[0x5d] = 0;
  param_1[0x5e] = 0;
  param_1[0x5f] = 0;
  param_1[0x60] = 0;
  param_1[0x61] = 0;
  param_1[0x62] = 0;
  param_1[99] = 0;
  param_1[100] = 0;
  param_1[0x65] = 0;
  param_1[0x66] = 0;
  param_1[0x67] = 0;
  param_1[0x68] = 0;
  param_1[0x69] = 0;
  uStack_8._0_1_ = 0x17;
  *(undefined2 *)(param_1 + 0x6a) = 0;
  FUN_00fe9d20(0,param_1);
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("Sound",5);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    uVar3 = auStack_2c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_2c[0] - 4);
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22441 ; VA 0x00ade110 ; FUN_00ade110 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00ade110(void)

{
  LOCK();
  _DAT_01eebab8 = _DAT_01eebab8 + -1;
  UNLOCK();
  return;
}



/* FUNCTION 22442 ; VA 0x00ade120 ; FUN_00ade120 */

void __fastcall FUN_00ade120(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Soundscape::Sound>::vftable;
  uVar1 = FUN_00add460(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22443 ; VA 0x00ade160 ; FUN_00ade160 */

void __fastcall FUN_00ade160(undefined4 *param_1)

{
  *param_1 = RBX::Soundscape::PlaybackChannelOwner::vftable;
  return;
}



/* FUNCTION 22444 ; VA 0x00ade170 ; FUN_00ade170 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00ade170(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Soundscape::Sound::vftable;
  param_1[0x15] = RBX::Soundscape::Sound::vftable;
  param_1[0x16] = RBX::Soundscape::Sound::vftable;
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = param_1[0x69];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  iVar3 = param_1[0x61];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  iVar3 = param_1[0x5a];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  iVar3 = param_1[0x57];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  piVar1 = (int *)param_1[0x54];
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar2 = piVar1 + 2;
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  uVar4 = param_1[0x45];
  if (0xf < uVar4) {
    iVar3 = param_1[0x40];
    uVar6 = uVar4 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar4 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x44] = 0;
  param_1[0x45] = 0xf;
  *(undefined *)(param_1 + 0x40) = 0;
  FUN_00fe8cf0();
  FUN_00fea5e0();
  param_1[0x15] = RBX::Soundscape::PlaybackChannelOwner::vftable;
  LOCK();
  _DAT_01eebab8 = _DAT_01eebab8 + -1;
  UNLOCK();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22445 ; VA 0x00ade3a1 ; FUN_00ade3a1 */

void FUN_00ade3a1(void)

{
  FUN_00ade540();
  return;
}



/* FUNCTION 22446 ; VA 0x00ade3a9 ; FUN_00ade3a9 */

void FUN_00ade3a9(void)

{
  FUN_00ade540();
  return;
}



/* FUNCTION 22447 ; VA 0x00ade3c0 ; FUN_00ade3c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00ade3c0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Soundscape::RollOffMode>::vftable;
  _DAT_01ef9b28 = _DAT_01ef9b28 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 22448 ; VA 0x00ade3f0 ; FUN_00ade3f0 */

undefined4 * __thiscall FUN_00ade3f0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Soundscape::RollOffMode>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 22449 ; VA 0x00ade420 ; FUN_00ade420 */

undefined4 * __thiscall FUN_00ade420(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Soundscape::SoundId>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 22450 ; VA 0x00ade450 ; FUN_00ade450 */

undefined4 * __thiscall FUN_00ade450(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Soundscape::SoundGroup*>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 22451 ; VA 0x00ade480 ; FUN_00ade480 */

undefined4 * __thiscall FUN_00ade480(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Soundscape::SoundGroup*>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 22452 ; VA 0x00ade4b0 ; FUN_00ade4b0 */

undefined4 * __thiscall FUN_00ade4b0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Soundscape::SoundId>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 22453 ; VA 0x00ade4e0 ; FUN_00ade4e0 */

undefined4 * __thiscall FUN_00ade4e0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Soundscape::RollOffMode>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 22454 ; VA 0x00ade510 ; FUN_00ade510 */

undefined4 * __thiscall FUN_00ade510(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Soundscape::PlaybackChannelOwner::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 22455 ; VA 0x00ade540 ; FUN_00ade540 */

undefined4 __thiscall FUN_00ade540(undefined4 param_1,byte param_2)

{
  FUN_00ade170();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1b0);
  }
  return param_1;
}



/* FUNCTION 22456 ; VA 0x00ade570 ; FUN_00ade570 */

int * FUN_00ade570(int *param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  undefined4 uStack_30;
  int iStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eaad8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(*param_1 + 0x40))(&piStack_24);
  uStack_8 = 0;
  if ((piStack_24 != (int *)0x0) && (piVar5 = (int *)*piStack_24, piVar5 != (int *)piStack_24[1])) {
    do {
      if ((*piVar5 != 0) &&
         (iVar2 = *(int *)(*piVar5 + 0xc), iVar4 = FUN_00cb6a80(),
         (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
         (uint)*(ushort *)(iVar4 + 0x1da))) {
        FUN_00cb9420(&iStack_1c,param_2);
        piVar6 = piStack_18;
        iStack_14 = iStack_1c;
        if (iStack_1c != 0) {
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          if (piStack_18 != (int *)0x0) {
            LOCK();
            piStack_18[1] = piStack_18[1] + 1;
            UNLOCK();
          }
          iStack_2c = iStack_1c;
          piStack_28 = piStack_18;
          uStack_30 = FUN_00cb9250();
          puVar3 = *(undefined4 **)(param_3 + 4);
          if (*(undefined4 **)(param_3 + 8) == puVar3) {
            FUN_00add560(puVar3,&uStack_30);
            piVar6 = piStack_28;
          }
          else {
            *puVar3 = uStack_30;
            puVar3[1] = 0;
            puVar3[2] = 0;
            if (piVar6 != (int *)0x0) {
              LOCK();
              piVar6[1] = piVar6[1] + 1;
              UNLOCK();
            }
            puVar3[1] = iStack_14;
            puVar3[2] = piVar6;
            *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 0xc;
          }
          if (piVar6 != (int *)0x0) {
            LOCK();
            iVar2 = piVar6[1] + -1;
            piVar6[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piVar6)();
              LOCK();
              iVar2 = piVar6[2] + -1;
              piVar6[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piVar6 + 4))();
              }
            }
          }
        }
        piVar6 = piStack_18;
        uStack_8 = uStack_8 & 0xffffff00;
        if (piStack_18 != (int *)0x0) {
          LOCK();
          iVar2 = piStack_18[1] + -1;
          piStack_18[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_18)();
            LOCK();
            piVar1 = piVar6 + 2;
            iVar2 = *piVar1 + -1;
            *piVar1 = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
      }
      piVar5 = piVar5 + 2;
    } while (piVar5 != (int *)piStack_24[1]);
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar5 = piStack_20 + 1;
    iVar2 = *piVar5;
    piStack_24 = (int *)*piVar5;
    *piVar5 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_24 = (int *)(**(code **)*piStack_20)();
      LOCK();
      piVar5 = piStack_20 + 2;
      iVar2 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_24 = (int *)(**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piStack_24;
}



/* FUNCTION 22457 ; VA 0x00ade710 ; FUN_00ade710 */

undefined4 FUN_00ade710(int param_1)

{
  int iVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  int *piVar6;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    iVar3 = param_1;
    if ((iVar1 != 0) && (iVar3 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      iVar3 = FUN_005c8ac0();
    }
    if (iVar3 != 0) {
      iVar1 = *(int *)(iVar3 + 0xc);
      iVar3 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da)) {
        FUN_005789c0(&DAT_01ea8ad8,&LAB_0055d5d0);
        uVar4 = FUN_00560f40();
        piVar5 = (int *)FUN_008aa140(uVar4);
        if (*piVar5 == 0) {
          uVar4 = FUN_008aa950();
          piVar6 = (int *)FUN_008a9ba0(auStack_c,uVar4);
          iVar1 = *piVar6;
          iVar3 = piVar6[1];
          *piVar6 = 0;
          piVar6[1] = 0;
          *piVar5 = iVar1;
          piVar6 = (int *)piVar5[1];
          piVar5[1] = iVar3;
          if (piVar6 != (int *)0x0) {
            LOCK();
            iVar1 = piVar6[1] + -1;
            piVar6[1] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)*piVar6)();
              LOCK();
              iVar1 = piVar6[2] + -1;
              piVar6[2] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)(*piVar6 + 4))();
              }
            }
          }
          if (piStack_8 != (int *)0x0) {
            LOCK();
            iVar1 = piStack_8[1] + -1;
            piStack_8[1] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)*piStack_8)();
              LOCK();
              piVar6 = piStack_8 + 2;
              iVar1 = *piVar6;
              *piVar6 = *piVar6 + -1;
              UNLOCK();
              if (iVar1 == 1) {
                (**(code **)(*piStack_8 + 4))();
              }
            }
          }
        }
        iVar1 = *piVar5;
        if ((iVar1 != 0) &&
           ((iVar1 == *(int *)(param_1 + 0x34) ||
            ((*(int *)(param_1 + 0x34) != 0 && (cVar2 = FUN_00620ec0(iVar1), cVar2 != '\0')))))) {
          return 1;
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 22458 ; VA 0x00ade840 ; FUN_00ade840 */

undefined4 * __thiscall
FUN_00ade840(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eab21;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00998900;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 22459 ; VA 0x00ade9f0 ; FUN_00ade9f0 */

undefined4 * __thiscall
FUN_00ade9f0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eab61;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00aded30;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 22460 ; VA 0x00adeb90 ; FUN_00adeb90 */

void FUN_00adeb90(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_00ae1680();
    *param_2 = uVar3;
    iVar4 = FUN_00ae1780();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 22461 ; VA 0x00adebf0 ; FUN_00adebf0 */

void FUN_00adebf0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00ae1680();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22462 ; VA 0x00adec30 ; FUN_00adec30 */

void __thiscall FUN_00adec30(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  uint uVar2;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eab78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(aiStack_28,param_2);
  uStack_8 = 0;
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_3,aiStack_28);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    iVar1 = aiStack_28[0];
    if (0xfff < uVar2) {
      iVar1 = *(int *)(aiStack_28[0] + -4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22463 ; VA 0x00adecc0 ; FUN_00adecc0 */

undefined4 * FUN_00adecc0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00add8a0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 22464 ; VA 0x00aded30 ; FUN_00aded30 */

void FUN_00aded30(int param_1,int param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  undefined auStack_1c0 [208];
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c83dc;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  FUN_005c13e0(&param_2);
  uStack_8._0_1_ = 2;
  uStack_f0 = FUN_0088c8c0();
  uStack_ec = 0;
  uStack_e8 = in_stack_00000020;
  uStack_ec = FUN_005c9cc0();
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(auStack_1c0,&uStack_20,piVar1);
  uStack_8._0_1_ = 4;
  (*pcVar2)(&uStack_1c);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(auStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_01675290(uVar3);
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    iVar4 = param_2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_2 + -4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22465 ; VA 0x00adee70 ; FUN_00adee70 */

int FUN_00adee70(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b8250;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 3;
  iVar3 = FUN_00ae1900();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 22466 ; VA 0x00adef80 ; FUN_00adef80 */

void FUN_00adef80(int param_1,undefined4 param_2)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = *(int *)(param_1 + 0x18);
  switch(param_2) {
  case 0:
    piVar2 = (int *)(iVar1 + 0x100);
    *(undefined4 *)(iVar1 + 0x120) = 0;
    if (0xf < *(uint *)(iVar1 + 0x114)) {
      piVar2 = (int *)*piVar2;
    }
    FUN_0054eff0(piVar2);
    FUN_00925c80(iVar1);
    return;
  case 1:
    piVar2 = (int *)(iVar1 + 0x100);
    if (0xf < *(uint *)(iVar1 + 0x114)) {
      piVar2 = (int *)*piVar2;
    }
    FUN_0054eff0(piVar2);
    FUN_00925c80(iVar1);
    return;
  case 2:
    piVar2 = (int *)(iVar1 + 0x100);
    if (0xf < *(uint *)(iVar1 + 0x114)) {
      piVar2 = (int *)*piVar2;
    }
    FUN_0054eff0(piVar2);
    FUN_00925c80(iVar1);
    return;
  case 3:
    piVar2 = (int *)(iVar1 + 0x100);
    *(undefined4 *)(iVar1 + 0x120) = 0;
    if (0xf < *(uint *)(iVar1 + 0x114)) {
      piVar2 = (int *)*piVar2;
    }
    FUN_0054eff0(piVar2);
    FUN_00925c80(iVar1);
  }
  return;
}



/* FUNCTION 22467 ; VA 0x00adf070 ; FUN_00adf070 */

void FUN_00adf070(undefined4 param_1,undefined4 param_2)

{
  FUN_00ae0c60(param_2);
  return;
}



/* FUNCTION 22468 ; VA 0x00adf090 ; FUN_00adf090 */

void FUN_00adf090(int param_1,double param_2,undefined8 param_3)

{
  double dVar1;
  int iVar2;
  
  iVar2 = *(int *)(param_1 + 0x18);
  *(undefined8 *)(iVar2 + 0x128) = param_3;
  dVar1 = *(double *)(iVar2 + 0x88);
  if ((NAN(dVar1) || NAN(param_2)) == (dVar1 == param_2)) {
    FUN_00fe9d60(param_2);
    FUN_008a4940();
  }
  return;
}



/* FUNCTION 22469 ; VA 0x00adf0e0 ; FUN_00adf0e0 */

void FUN_00adf0e0(int *param_1,undefined4 param_2)

{
  code *pcVar1;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d53a1;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  uStack_24 = 0;
  ExceptionList = &pvStack_10;
  FUN_005e6780(param_2);
  pcVar1 = *(code **)(*param_1 + 8);
  uStack_f8 = FUN_0088c8c0();
  uStack_f4 = 0;
  uStack_f0 = param_2;
  uStack_f4 = FUN_005c9cc0();
  uStack_8 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_f8,&uStack_28,param_1);
  uStack_8._0_1_ = 1;
  (*pcVar1)(uStack_14,&uStack_20,&uStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00577b20();
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_f8,0xd0,1,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22470 ; VA 0x00adf1e0 ; FUN_00adf1e0 */

/* WARNING: Removing unreachable block (ram,0x00adf2ac) */
/* WARNING: Removing unreachable block (ram,0x00adf2ba) */
/* WARNING: Removing unreachable block (ram,0x00adf2fa) */
/* WARNING: Removing unreachable block (ram,0x00adf2ca) */

void FUN_00adf1e0(undefined4 param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  iVar1 = *param_2;
  iVar5 = *(int *)(iVar1 + 0xd0);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088c8c0();
  if (iVar5 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar4 = (undefined4 *)(iVar1 + 0xd8);
  if (*(int *)(iVar1 + 0xd4) == 0) {
    puVar4 = (undefined4 *)0x0;
  }
  uVar2 = *puVar4;
  param_2 = (int *)*param_2;
  iVar1 = *param_2;
  iVar5 = FUN_0088cb40();
  if (iVar1 != iVar5) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  piVar6 = param_2 + 2;
  if (param_2[1] == 0) {
    piVar6 = (int *)0x0;
  }
  FUN_0054ef60(piVar6);
  uStack_8 = 0;
  FUN_009f1b60(uStack_30,uStack_2c,uStack_28,uStack_24,CONCAT44(uStack_1c,uStack_20),uVar2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22471 ; VA 0x00adf300 ; FUN_00adf300 */

void FUN_00adf300(void)

{
  int iVar1;
  
  if (DAT_01eebce4 == 0) {
    iVar1 = FUN_00add460();
    DAT_01eebce4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 22472 ; VA 0x00adf320 ; FUN_00adf320 */

void __thiscall FUN_00adf320(int param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x140);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar1 != 0) {
    LOCK();
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
    iVar1 = *(int *)(param_1 + 0x140);
  }
  *param_2 = *(undefined4 *)(param_1 + 0x13c);
  param_2[1] = iVar1;
  return;
}



/* FUNCTION 22473 ; VA 0x00adf390 ; FUN_00adf390 */

float10 __fastcall FUN_00adf390(int param_1)

{
  return (float10)(float)*(double *)(param_1 + 0x130);
}



/* FUNCTION 22474 ; VA 0x00adf3b0 ; FUN_00adf3b0 */

float10 __fastcall FUN_00adf3b0(int param_1)

{
  return (float10)(float)*(double *)(param_1 + 0xa0);
}



/* FUNCTION 22475 ; VA 0x00adf3d0 ; FUN_00adf3d0 */

float10 __fastcall FUN_00adf3d0(int param_1)

{
  return (float10)(float)*(double *)(param_1 + 0x98);
}



/* FUNCTION 22476 ; VA 0x00adf410 ; FUN_00adf410 */

bool __thiscall FUN_00adf410(int param_1,char param_2,float *param_3)

{
  float fVar1;
  int iVar2;
  int iVar3;
  double dVar4;
  float fStack_44;
  float fStack_40;
  undefined auStack_38 [52];
  
  if (((param_2 != '\0') || ((DAT_01d668ec != '\0' && (*(char *)(param_1 + 0x146) != '\0')))) &&
     (*(char *)(param_1 + 0x145) != '\0')) {
    switch(*(undefined4 *)(param_1 + 0x118)) {
    case 1:
    case 3:
    case 4:
    case 5:
    case 6:
      if ((*(int *)(param_1 + 0x34) == 0) ||
         (iVar3 = *(int *)(*(int *)(param_1 + 0x34) + 0xc), iVar2 = FUN_00aff8c0(),
         (uint)*(ushort *)(iVar2 + 0x1da) <
         (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))) {
        iVar3 = FUN_00836510(*(undefined4 *)(param_1 + 0x34));
        if (iVar3 == 0) {
          return true;
        }
        iVar3 = FUN_00d6c6c0(auStack_38);
        fStack_44 = *(float *)(iVar3 + 0x24);
        fStack_40 = *(float *)(iVar3 + 0x28);
        fVar1 = *(float *)(iVar3 + 0x2c);
      }
      else {
        iVar3 = FUN_00b077e0();
        fVar1 = *(float *)(iVar3 + 0x2c);
        fStack_44 = (float)*(undefined8 *)(iVar3 + 0x24);
        fStack_40 = (float)((ulonglong)*(undefined8 *)(iVar3 + 0x24) >> 0x20);
      }
      dVar4 = (double)((fStack_40 - param_3[1]) * (fStack_40 - param_3[1]) +
                       (fStack_44 - *param_3) * (fStack_44 - *param_3) +
                      (fVar1 - param_3[2]) * (fVar1 - param_3[2]));
      FUN_017267a0();
      return (double)(float)dVar4 <= *(double *)(param_1 + 0x130);
    }
  }
  return false;
}



/* FUNCTION 22477 ; VA 0x00adf570 ; FUN_00adf570 */

undefined4 FUN_00adf570(void)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00587490(auStack_c);
  uVar2 = *puVar4;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return uVar2;
  }
  return uVar2;
}



/* FUNCTION 22478 ; VA 0x00adf5d0 ; FUN_00adf5d0 */

int __fastcall FUN_00adf5d0(int param_1)

{
  return param_1 + 0x100;
}



/* FUNCTION 22479 ; VA 0x00adf5e0 ; FUN_00adf5e0 */

void __thiscall FUN_00adf5e0(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0xbc);
  *param_2 = *(undefined8 *)(param_1 + 0xb4);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 22480 ; VA 0x00adf600 ; FUN_00adf600 */

float10 __fastcall FUN_00adf600(int param_1)

{
  return (float10)*(double *)(param_1 + 0x88);
}



/* FUNCTION 22481 ; VA 0x00adf610 ; FUN_00adf610 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00adf610(int param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eab78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(aiStack_28,param_2);
  uStack_8 = 0;
  uVar5 = thunk_FUN_0088d190();
  iVar6 = _tls_index;
  *param_3 = uVar5;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar6 * 4) + 0x34) < DAT_01eebd94) {
    FUN_016f3809(&DAT_01eebd94);
    if (DAT_01eebd94 == -1) {
      _DAT_01eebd88 = FUN_005c65f0;
      _DAT_01eebd8c = FUN_005c93a0;
      _DAT_01eebd90 = FUN_005c77b0;
      FUN_016f37bf(&DAT_01eebd94);
    }
  }
  puVar1 = (undefined *)param_3[1];
  if (puVar1 == &DAT_01eebd88) {
    if (param_3 + 2 != puVar4) {
      FUN_005507b0();
      uVar5 = puVar4[1];
      uVar2 = puVar4[2];
      uVar3 = puVar4[3];
      param_3[2] = *puVar4;
      param_3[3] = uVar5;
      param_3[4] = uVar2;
      param_3[5] = uVar3;
      *(undefined8 *)(param_3 + 6) = *(undefined8 *)(puVar4 + 4);
      puVar4[4] = 0;
      puVar4[5] = 0xf;
      *(undefined *)puVar4 = 0;
    }
  }
  else {
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_3 + 2);
      param_3[1] = 0;
    }
    param_3[6] = 0;
    param_3[7] = 0;
    uVar5 = puVar4[1];
    uVar2 = puVar4[2];
    uVar3 = puVar4[3];
    param_3[2] = *puVar4;
    param_3[3] = uVar5;
    param_3[4] = uVar2;
    param_3[5] = uVar3;
    *(undefined8 *)(param_3 + 6) = *(undefined8 *)(puVar4 + 4);
    puVar4[4] = 0;
    puVar4[5] = 0xf;
    *(undefined *)puVar4 = 0;
    param_3[1] = &DAT_01eebd88;
  }
  if (0xf < uStack_14) {
    uVar7 = uStack_14 + 1;
    iVar6 = aiStack_28[0];
    if (0xfff < uVar7) {
      iVar6 = *(int *)(aiStack_28[0] + -4);
      uVar7 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar7);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22482 ; VA 0x00adf790 ; FUN_00adf790 */

void __thiscall FUN_00adf790(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_00ae1680();
  *param_3 = uVar3;
  iVar4 = FUN_00ae1780();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 22483 ; VA 0x00adf7f0 ; FUN_00adf7f0 */

float10 __fastcall FUN_00adf7f0(int param_1)

{
  return (float10)(float)*(double *)(param_1 + 0x90);
}



/* FUNCTION 22484 ; VA 0x00adf810 ; FUN_00adf810 */

uint __fastcall FUN_00adf810(int param_1)

{
  return *(uint *)(param_1 + 0x124) >> 0x1f ^ 1;
}



/* FUNCTION 22485 ; VA 0x00adf820 ; FUN_00adf820 */

uint FUN_00adf820(void)

{
  int iVar1;
  
  iVar1 = FUN_00add460();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 22486 ; VA 0x00adf840 ; FUN_00adf840 */

uint FUN_00adf840(void)

{
  int iVar1;
  
  iVar1 = FUN_00add460();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 22487 ; VA 0x00adf860 ; FUN_00adf860 */

/* WARNING: Removing unreachable block (ram,0x00adf91e) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint __fastcall FUN_00adf860(int param_1)

{
  uint *puVar1;
  uint uVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  int iVar7;
  float10 fVar8;
  undefined auStack_4c [8];
  undefined4 uStack_44;
  uint uStack_40;
  int *piStack_3c;
  undefined8 *puStack_38;
  undefined auStack_28 [4];
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eaba8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 == 0) {
LAB_00adf8cd:
    puStack_38 = (undefined8 *)0x0;
  }
  else {
    iVar7 = *(int *)(param_1 + 0x34);
    iVar4 = param_1;
    ExceptionList = &pvStack_10;
    if ((iVar7 != 0) && (iVar4 = iVar7, ExceptionList = &pvStack_10, *(int *)(iVar7 + 0x34) != 0)) {
      puStack_38 = (undefined8 *)0xadf897;
      ExceptionList = &pvStack_10;
      iVar4 = FUN_005c8ac0();
    }
    if (iVar4 == 0) goto LAB_00adf8cd;
    iVar7 = *(int *)(iVar4 + 0xc);
    puStack_38 = (undefined8 *)0xadf8a9;
    iVar4 = FUN_008a8c30();
    if ((uint)*(ushort *)(iVar4 + 0x1da) <
        (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) goto LAB_00adf8cd;
    puStack_38 = (undefined8 *)0xadf8cb;
    puStack_38 = (undefined8 *)FUN_0068f660();
  }
  piStack_3c = &iStack_20;
  uStack_40 = 0xadf8d9;
  FUN_0060dcd0();
  puStack_38 = *(undefined8 **)(param_1 + 0x118);
  uStack_8 = 0;
  if (puStack_38 == (undefined8 *)0x3) {
    *(undefined4 *)(param_1 + 0x118) = 4;
    if (iStack_20 == 0) {
      iVar7 = *(int *)(param_1 + 0x118);
      if (((iVar7 != 6) && (*(undefined4 *)(param_1 + 0x118) = 6, DAT_01d668e4 != '\0')) &&
         (iVar7 == 5)) {
        puStack_38 = (undefined8 *)&DAT_021289f0;
        piStack_3c = (int *)0xadf960;
        FUN_008a4940();
      }
      uVar5 = (uint)DAT_01ef8f4b;
      if (DAT_01ef8f4b != 0) {
        puStack_38 = (undefined8 *)0x0;
        uStack_40 = (uint)DAT_01ef8f4b;
        piStack_3c = (int *)0x194bb1c;
        uStack_44 = 0xadf97d;
        uVar5 = FUN_016774b0();
      }
    }
    else {
      puStack_38 = (undefined8 *)0xadf98c;
      cVar3 = FUN_00c20be0();
      if (cVar3 == '\0') {
        uStack_18 = (double)CONCAT44(auStack_4c,(undefined4)uStack_18);
        FUN_0054ef60((int *)(param_1 + 0x100));
        fVar8 = (float10)FUN_00c23520();
        uStack_18 = (double)fVar8;
        if ((NAN(uStack_18) || NAN(_PTR_018c6f48)) == (uStack_18 == _PTR_018c6f48)) {
          *(double *)(param_1 + 0x80) = uStack_18;
          if ((*(int *)(param_1 + 0x118) != 5) &&
             (*(undefined4 *)(param_1 + 0x118) = 5, DAT_01d668e4 != '\0')) {
            puStack_38 = (undefined8 *)&DAT_021289f0;
            piStack_3c = (int *)0xadf9f6;
            FUN_008a4940();
          }
          puStack_38 = (undefined8 *)&DAT_021286c0;
          piStack_3c = (int *)0xadfa02;
          FUN_008a4940();
          FUN_0054ef60(param_1 + 0x100);
          uVar5 = FUN_006ecaa0();
          goto LAB_00adfac5;
        }
      }
      piStack_3c = (int *)auStack_28;
      uStack_40 = 0xadfa2d;
      puStack_38 = (undefined8 *)param_1;
      piVar6 = (int *)FUN_0060dcd0();
      if (*piVar6 == 0) {
        iVar7 = 0;
      }
      else {
        iVar7 = *piVar6 + 0x54;
      }
      uStack_18 = (double)CONCAT44(piVar6[1],iVar7);
      *piVar6 = 0;
      piVar6[1] = 0;
      puStack_38 = &uStack_18;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      uStack_40 = 0xadfa79;
      piStack_3c = (int *)(param_1 + 0x100);
      uVar5 = FUN_00c24fa0();
      piVar6 = uStack_18._4_4_;
      if (uStack_18._4_4_ != (int *)0x0) {
        LOCK();
        puVar1 = (uint *)(uStack_18._4_4_ + 1);
        uVar2 = *puVar1;
        uVar5 = *puVar1;
        *puVar1 = uVar2 - 1;
        UNLOCK();
        if (uVar2 - 1 == 0) {
          puStack_38 = (undefined8 *)0xadfa8f;
          (**(code **)*uStack_18._4_4_)();
          LOCK();
          puVar1 = (uint *)(piVar6 + 2);
          uVar2 = *puVar1;
          uVar5 = *puVar1;
          *puVar1 = uVar2 - 1;
          UNLOCK();
          if (uVar2 - 1 == 0) {
            puStack_38 = (undefined8 *)0xadfa9f;
            uVar5 = (**(code **)(*piVar6 + 4))();
          }
        }
      }
      if (piStack_24 != (int *)0x0) {
        LOCK();
        puVar1 = (uint *)(piStack_24 + 1);
        uVar2 = *puVar1;
        uVar5 = *puVar1;
        *puVar1 = uVar2 - 1;
        UNLOCK();
        if (uVar2 - 1 == 0) {
          puStack_38 = (undefined8 *)0xadfab5;
          (**(code **)*piStack_24)();
          LOCK();
          puVar1 = (uint *)(piStack_24 + 2);
          uVar2 = *puVar1;
          uVar5 = *puVar1;
          *puVar1 = uVar2 - 1;
          UNLOCK();
          if (uVar2 - 1 == 0) {
            puStack_38 = (undefined8 *)0xadfac5;
            uVar5 = (**(code **)(*piStack_24 + 4))();
          }
        }
      }
    }
  }
  else {
    piStack_3c = (int *)0x194bae8;
    uStack_40 = 3;
    uStack_44 = 0xadf8fe;
    uVar5 = FUN_0086f2f0();
  }
LAB_00adfac5:
  if (piStack_1c != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_1c + 1);
    uVar2 = *puVar1;
    uVar5 = *puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      puStack_38 = (undefined8 *)0xadfadb;
      uVar5 = (**(code **)*piStack_1c)();
      LOCK();
      piVar6 = piStack_1c + 2;
      iVar7 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        puStack_38 = (undefined8 *)0xadfaea;
        uVar5 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 22488 ; VA 0x00adfb00 ; FUN_00adfb00 */

void FUN_00adfb00(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00ae1680();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22489 ; VA 0x00adfb50 ; FUN_00adfb50 */

int * __thiscall FUN_00adfb50(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined uVar3;
  char cVar4;
  int *piVar5;
  int iVar6;
  int iVar7;
  undefined8 *puVar8;
  undefined4 *puVar9;
  undefined4 uVar10;
  undefined8 uVar11;
  undefined4 uVar12;
  undefined auStack_80 [52];
  int *piStack_4c;
  undefined8 uStack_48;
  int *piStack_40;
  undefined4 uStack_38;
  int *piStack_34;
  undefined8 uStack_30;
  undefined4 *puStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  uint uStack_18;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eac53;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  FUN_008a3ee0();
  if (DAT_01d668ec != '\0') {
    piVar5 = (int *)FUN_00817fa0();
    if (piVar5 == (int *)0x0) {
      *(undefined *)(param_1 + 0x146) = 0;
    }
    else {
      uVar3 = (**(code **)(*piVar5 + 0x108))();
      *(undefined *)(param_1 + 0x146) = uVar3;
    }
  }
  uStack_30 = 0;
  if (*param_2 == param_1) {
    piStack_1c = (int *)param_2[2];
    if ((piStack_1c == (int *)0x0) ||
       (iVar7 = *(int *)((int)piStack_1c + 0xc), iVar6 = FUN_00aff8c0(),
       (uint)*(ushort *)(iVar6 + 0x1da) <
       (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
      piStack_1c = (int *)param_2[2];
      if ((piStack_1c != (int *)0x0) &&
         (iVar7 = *(int *)((int)piStack_1c + 0xc), iVar6 = FUN_00d6bbd0(),
         (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
         (uint)*(ushort *)(iVar6 + 0x1da))) {
        piStack_40 = (int *)0x0;
        iVar7 = FUN_00d6c6c0(auStack_80);
        goto LAB_00adfc0f;
      }
      piStack_40 = (int *)0x0;
      piStack_34 = (int *)0x0;
      uVar10 = 0;
      uVar11 = CONCAT44((int)uStack_30,(int)uStack_30);
      uVar12 = 0;
    }
    else {
      piStack_40 = (int *)0x0;
      iVar7 = FUN_00b077e0();
LAB_00adfc0f:
      uVar11 = *(undefined8 *)(iVar7 + 0x24);
      uVar10 = *(undefined4 *)(iVar7 + 0x2c);
      uVar12 = 1;
    }
    FUN_00fe9780(uVar12,uVar11,uVar10);
  }
  *(undefined *)(param_1 + 0x144) = 0;
  if (param_2[2] == 0) {
    FUN_00fe95b0();
  }
  FUN_01679490();
  FUN_01679490();
  piStack_24 = (int *)(param_1 + 0x184);
  FUN_01679490();
  piStack_1c = (int *)FUN_005f7790();
  if ((param_2[2] == 0) || (piStack_1c == (int *)0x0)) {
    *(undefined4 *)(param_1 + 0x11c) = 6;
    iVar7 = 6;
    goto LAB_00adfdff;
  }
  cStack_11 = FUN_0098c5a0();
  cStack_12 = FUN_00973950(param_2[2]);
  uVar3 = FUN_00983210();
  *(undefined *)(param_1 + 0x1a9) = uVar3;
  iVar7 = FUN_008f7870(param_2[2]);
  if (iVar7 != 0) {
    if (*(int *)(iVar7 + 0x4a0) == 1) {
      cStack_12 = '\x01';
    }
    else {
      cStack_12 = '\0';
      cStack_11 = '\x01';
      if (*(int *)(iVar7 + 0x4a0) == 2) goto LAB_00adfd79;
    }
    cStack_11 = '\0';
  }
LAB_00adfd79:
  cVar4 = FUN_00ade710();
  if (cVar4 == '\0') {
    if (cStack_11 == '\0') {
      if (cStack_12 == '\0') {
        iVar6 = 5;
      }
      else {
        iVar6 = 1;
      }
    }
    else {
      iVar6 = 2;
    }
  }
  else if (cStack_11 == '\0') {
    if (cStack_12 == '\0') {
      iVar6 = 5;
    }
    else {
      iVar6 = 3;
    }
  }
  else {
    iVar6 = 4;
  }
  iVar7 = *(int *)(param_1 + 0x11c);
  if (((iVar7 != 3) && (iVar7 != 4)) && ((iVar7 != 5 || (*(char *)(param_1 + 0x1a9) == '\0')))) {
    *(int *)(param_1 + 0x11c) = iVar6;
    iVar7 = iVar6;
  }
LAB_00adfdff:
  if ((iVar7 == 6 || iVar7 == 0) || (cVar4 = FUN_00c20be0(), cVar4 == '\0')) {
    uVar3 = 0;
  }
  else {
    uVar3 = 1;
  }
  *(undefined *)(param_1 + 0x145) = uVar3;
  if ((param_2[1] != 0) && (param_2[2] == 0)) {
    FUN_00fe96c0();
    FUN_00fe95b0();
  }
  FUN_00fea670();
  uStack_48 = 0;
  piStack_40 = (int *)0x0;
  if (piStack_1c != (int *)0x0) {
    puVar8 = (undefined8 *)FUN_00c22d40();
    uStack_48 = *puVar8;
    piStack_40 = *(int **)(puVar8 + 1);
  }
  FUN_00adf410();
  piVar5 = (int *)FUN_00fe9d20();
  if (piStack_1c != (int *)0x0) {
    FUN_0060dcd0();
    piVar5 = (int *)FUN_00c26170();
  }
  if (param_2[2] != 0) {
    if ((*(int *)(param_1 + 0x11c) == 3) ||
       ((*(int *)(param_1 + 0x11c) == 5 && (*(char *)(param_1 + 0x1a9) != '\0')))) {
      puVar9 = (undefined4 *)FUN_0060dcd0();
      uStack_38 = *puVar9;
      piStack_34 = (int *)puVar9[1];
      *puVar9 = 0;
      puVar9[1] = 0;
      uStack_8._0_1_ = 1;
      uStack_8._1_3_ = 0;
      uStack_20 = uStack_38;
      piStack_1c = piStack_34;
      FUN_006eccd0();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      puStack_28 = (undefined4 *)FUN_01675290();
      uStack_8 = 3;
      param_2 = (int *)FUN_01674e20();
      if (param_2 == (undefined4 *)0x0) {
        param_2 = (undefined4 *)0x0;
      }
      else {
        *param_2 = 0;
        param_2[1] = 1;
        param_2[2] = (int)FUN_00adf090;
        param_2[3] = (int)FUN_0068b170;
        param_2[4] = 0;
        param_2[5] = param_1 + 0x160;
        param_2[6] = 0;
        param_2[7] = 0;
        if (piStack_1c != (int *)0x0) {
          LOCK();
          piStack_1c[1] = piStack_1c[1] + 1;
          UNLOCK();
        }
        param_2[6] = uStack_20;
        param_2[7] = (int)piStack_1c;
      }
      FUN_016797d0();
      uStack_30 = CONCAT44(param_2,(undefined4)uStack_30);
      if (param_2 != (undefined4 *)0x0) {
        LOCK();
        param_2[1] = param_2[1] + 1;
        UNLOCK();
      }
      uStack_18 = 2;
      uStack_8 = 4;
      FUN_01675290();
      iVar7 = *(int *)(param_1 + 0x168);
      uStack_18 = 1;
      *(int **)(param_1 + 0x168) = param_2;
      if (iVar7 != 0) {
        piVar5 = (int *)(iVar7 + 4);
        LOCK();
        iVar7 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar7 == 1) {
          FUN_01674ea0();
        }
      }
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar7 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          iVar7 = piStack_1c[2] + -1;
          piStack_1c[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
      piVar5 = piStack_40;
      uStack_8 = 0xffffffff;
      if (piStack_40 != (int *)0x0) {
        LOCK();
        iVar7 = piStack_40[1] + -1;
        piStack_40[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piStack_40)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar7 = *piVar1 + -1;
          *piVar1 = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      puVar9 = (undefined4 *)FUN_0060dcd0();
      uStack_20 = *puVar9;
      uStack_48 = CONCAT44(uStack_20,(undefined4)uStack_48);
      piStack_40 = (int *)puVar9[1];
      *puVar9 = 0;
      puVar9[1] = 0;
      uStack_8._0_1_ = 6;
      uStack_8._1_3_ = 0;
      piStack_1c = piStack_40;
      FUN_006eccd0();
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      uVar10 = FUN_01675290();
      uStack_30 = CONCAT44(uVar10,(undefined4)uStack_30);
      uStack_8 = 8;
      param_2 = (int *)FUN_01674e20();
      if (param_2 == (undefined4 *)0x0) {
        param_2 = (undefined4 *)0x0;
      }
      else {
        *param_2 = 0;
        param_2[1] = 1;
        param_2[2] = (int)FUN_00adf070;
        param_2[3] = (int)FUN_0068b170;
        param_2[4] = 0;
        param_2[5] = param_1 + 0x154;
        param_2[6] = 0;
        param_2[7] = 0;
        if (piStack_1c != (int *)0x0) {
          LOCK();
          piStack_1c[1] = piStack_1c[1] + 1;
          UNLOCK();
        }
        param_2[6] = uStack_20;
        param_2[7] = (int)piStack_1c;
      }
      FUN_016797d0();
      puStack_28 = param_2;
      if (param_2 != (undefined4 *)0x0) {
        LOCK();
        param_2[1] = param_2[1] + 1;
        UNLOCK();
      }
      uStack_18 = 9;
      uStack_8 = 9;
      FUN_01675290();
      iVar7 = *(int *)(param_1 + 0x15c);
      uStack_18 = 5;
      *(int **)(param_1 + 0x15c) = param_2;
      if (iVar7 != 0) {
        piVar5 = (int *)(iVar7 + 4);
        LOCK();
        iVar7 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar7 == 1) {
          FUN_01674ea0();
        }
      }
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar7 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          iVar7 = piStack_1c[2] + -1;
          piStack_1c[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
      piVar5 = piStack_34;
      uStack_8 = 0xffffffff;
      if (piStack_34 != (int *)0x0) {
        LOCK();
        iVar7 = piStack_34[1] + -1;
        piStack_34[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piStack_34)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar7 = *piVar1 + -1;
          *piVar1 = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
    puVar9 = (undefined4 *)FUN_0060dcd0();
    uStack_20 = *puVar9;
    uStack_48 = CONCAT44(uStack_20,(undefined4)uStack_48);
    piStack_40 = (int *)puVar9[1];
    *puVar9 = 0;
    puVar9[1] = 0;
    uStack_8._0_1_ = 0xb;
    uStack_8._1_3_ = 0;
    piStack_1c = piStack_40;
    FUN_006eccd0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    uVar10 = FUN_01675290();
    uStack_30 = CONCAT44(uVar10,(undefined4)uStack_30);
    uStack_8 = 0xd;
    puStack_28 = (undefined4 *)FUN_01674e20();
    if (puStack_28 == (undefined4 *)0x0) {
      puVar9 = (undefined4 *)0x0;
    }
    else {
      *puStack_28 = 0;
      puStack_28[1] = 1;
      puStack_28[2] = FUN_00adef80;
      puStack_28[3] = FUN_0068b170;
      puStack_28[4] = 0;
      puStack_28[5] = param_1 + 0x17c;
      puStack_28[6] = 0;
      puStack_28[7] = 0;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piStack_1c[1] = piStack_1c[1] + 1;
        UNLOCK();
      }
      puStack_28[6] = uStack_20;
      puStack_28[7] = piStack_1c;
      puVar9 = puStack_28;
    }
    FUN_016797d0();
    if (puVar9 != (undefined4 *)0x0) {
      LOCK();
      puVar9[1] = puVar9[1] + 1;
      UNLOCK();
    }
    uStack_18 = uStack_18 | 0x20;
    uStack_8 = 0xe;
    puStack_28 = puVar9;
    FUN_01675290();
    iVar7 = *piStack_24;
    *piStack_24 = (int)puVar9;
    piVar5 = piStack_24;
    if (iVar7 != 0) {
      piVar5 = (int *)(iVar7 + 4);
      LOCK();
      iVar7 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      piVar5 = (int *)(iVar7 + -1);
      if (piVar5 == (int *)0x0) {
        piVar5 = (int *)FUN_01674ea0();
      }
    }
    piVar1 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar2 = piStack_1c + 1;
      iVar7 = *piVar2;
      piVar5 = (int *)*piVar2;
      *piVar2 = iVar7 + -1;
      UNLOCK();
      if (iVar7 + -1 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar2 = piVar1 + 2;
        iVar7 = *piVar2;
        piVar5 = (int *)*piVar2;
        *piVar2 = iVar7 + -1;
        UNLOCK();
        if (iVar7 + -1 == 0) {
          piVar5 = (int *)(**(code **)(*piVar1 + 4))();
        }
      }
    }
    if (piStack_4c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_4c + 1;
      iVar7 = *piVar1;
      piVar5 = (int *)*piVar1;
      *piVar1 = iVar7 + -1;
      UNLOCK();
      if (iVar7 + -1 == 0) {
        piVar5 = (int *)(**(code **)*piStack_4c)();
        LOCK();
        piVar1 = piStack_4c + 2;
        iVar7 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar7 == 1) {
          piVar5 = (int *)(**(code **)(*piStack_4c + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar5;
}



/* FUNCTION 22490 ; VA 0x00ae0390 ; FUN_00ae0390 */

void __fastcall FUN_00ae0390(int param_1)

{
  if (DAT_01ef8f4b != '\0') {
    FUN_01677490(DAT_01ef8f4b,"Sound::onChildAdded(%p) fmodChannel %p",param_1,
                 *(undefined4 *)(param_1 + 0x70),0);
  }
  FUN_00ae1830();
  FUN_00ae1900();
  return;
}



/* FUNCTION 22491 ; VA 0x00ae03d0 ; FUN_00ae03d0 */

void __fastcall FUN_00ae03d0(int param_1)

{
  if (DAT_01ef8f4b != '\0') {
    FUN_01677490(DAT_01ef8f4b,"Sound::onChildRemoved(%p) fmodChannel %p",param_1,
                 *(undefined4 *)(param_1 + 0x70),0);
  }
  FUN_00ae1830();
  FUN_00ae1900();
  return;
}



/* FUNCTION 22492 ; VA 0x00ae0410 ; FUN_00ae0410 */

void __fastcall FUN_00ae0410(int param_1)

{
  if (DAT_01ef8f4b != '\0') {
    FUN_01677490(DAT_01ef8f4b,"Sound::onClosingFmod(%p) fmodChannel %p",param_1 + -0x58,
                 *(undefined4 *)(param_1 + 0x18),0);
  }
  FUN_00fe96c0();
  FUN_00fe9720();
  return;
}



/* FUNCTION 22493 ; VA 0x00ae0450 ; FUN_00ae0450 */

void __fastcall FUN_00ae0450(int param_1)

{
  if (DAT_01ef8f4b != '\0') {
    FUN_01677490(DAT_01ef8f4b,"Sound::onOpenFmod(%p) fmodChannel %p",param_1 + -0x58,
                 *(undefined4 *)(param_1 + 0x18),0);
  }
  FUN_00ae1830();
  FUN_00ae1900();
  return;
}



/* FUNCTION 22494 ; VA 0x00ae0490 ; FUN_00ae0490 */

void __thiscall FUN_00ae0490(int param_1,int param_2,int param_3)

{
  undefined uVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int iStack_94;
  undefined *puStack_90;
  undefined4 *puStack_8c;
  undefined auStack_30 [24];
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eac78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01d668ec != '\0') {
    puStack_8c = (undefined4 *)0xae04be;
    ExceptionList = &pvStack_10;
    piVar2 = (int *)FUN_00817fa0();
    if (piVar2 == (int *)0x0) {
      *(undefined *)(param_1 + 0x146) = 0;
    }
    else {
      puStack_8c = (undefined4 *)0xae04ce;
      uVar1 = (**(code **)(*piVar2 + 0x108))();
      *(undefined *)(param_1 + 0x146) = uVar1;
    }
  }
  puStack_8c = (undefined4 *)0xae04e5;
  iVar3 = FUN_005f7790();
  if (iVar3 != 0) {
    puStack_8c = (undefined4 *)0x0;
    FUN_0060dcd0(&iStack_94,param_1);
    FUN_00c26170();
    puStack_8c = (undefined4 *)0xae050c;
    (**(code **)(*(int *)(param_1 + 0x58) + 8))();
  }
  puStack_8c = (undefined4 *)param_3;
  puStack_90 = (undefined *)param_2;
  iStack_94 = 0xae051a;
  FUN_008a4210();
  if (param_3 == 0) {
    if (((*(char *)(param_1 + 0x1a8) != '\0') && (param_2 != 0)) &&
       (*(char *)(param_1 + 0x145) != '\0')) {
      puStack_8c = (undefined4 *)0xae05a3;
      iVar3 = FUN_0068f660();
      if (iVar3 != 0) {
        puStack_90 = auStack_18;
        iStack_94 = 0xae05b3;
        puStack_8c = (undefined4 *)param_1;
        puStack_8c = (undefined4 *)FUN_0060dcd0();
        uStack_8 = 0;
        puStack_90 = (undefined *)0xae05c5;
        FUN_00c1ece0();
        uStack_8 = 0xffffffff;
        puStack_8c = (undefined4 *)0xae05d4;
        FUN_00550b30();
      }
    }
  }
  else {
    puStack_8c = (undefined4 *)0xae0525;
    iVar3 = FUN_0068f660();
    puStack_90 = (undefined *)0xae0532;
    puStack_8c = (undefined4 *)iVar3;
    uVar4 = (**(code **)(*(int *)(param_1 + 0x58) + 4))();
    if (iVar3 != 0) {
      if ((*(char *)(param_1 + 0x78) != '\0') ||
         (puStack_8c = (undefined4 *)CONCAT31((int3)((uint)uVar4 >> 8),*(char *)(param_1 + 0xce)),
         *(char *)(param_1 + 0xce) != '\0')) {
        puStack_8c = (undefined4 *)0x1;
      }
      FUN_0060dcd0(&iStack_94,param_1);
      FUN_00c26170();
    }
    if (DAT_01ef8f4b != '\0') {
      puStack_8c = (undefined4 *)0x0;
      puStack_90 = (undefined *)param_3;
      iStack_94 = param_1;
      FUN_01677490(DAT_01ef8f4b,"Sound::onServiceProvider(%p) newProvider %p");
    }
  }
  iVar3 = *(int *)(param_1 + 0x118);
  switch(iVar3) {
  case 0:
    if (param_3 == 0) {
      ExceptionList = pvStack_10;
      return;
    }
    *(undefined4 *)(param_1 + 0x118) = 1;
    break;
  case 1:
    if (param_3 != 0) {
      ExceptionList = pvStack_10;
      return;
    }
    *(undefined4 *)(param_1 + 0x118) = 0;
    break;
  case 2:
    if (param_3 == 0) {
      ExceptionList = pvStack_10;
      return;
    }
    *(undefined4 *)(param_1 + 0x118) = 3;
    if ((DAT_01d668e4 != '\0') && (iVar3 == 5)) {
      puStack_8c = (undefined4 *)&DAT_021289f0;
      puStack_90 = (undefined *)0xae0640;
      FUN_008a4940();
    }
    puStack_8c = DAT_0212848c;
    if (0xf < (uint)DAT_0212848c[5]) {
      puStack_8c = (undefined4 *)*DAT_0212848c;
    }
    puStack_90 = (undefined *)0xae0656;
    FUN_0054eff0();
    puStack_8c = (undefined4 *)auStack_30;
    uStack_8 = 1;
    iStack_94 = 0xae066a;
    puStack_90 = (undefined *)param_1;
    puStack_8c = (undefined4 *)FUN_00d10320();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    puStack_90 = (undefined *)0xae0676;
    FUN_00adf860();
    puStack_8c = (undefined4 *)0xae067e;
    FUN_00637950();
    puStack_8c = (undefined4 *)0xae0686;
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  case 3:
  case 4:
  case 5:
  case 6:
    if (param_3 != 0) {
      ExceptionList = pvStack_10;
      return;
    }
    if (iVar3 == 2) {
      ExceptionList = pvStack_10;
      return;
    }
    *(undefined4 *)(param_1 + 0x118) = 2;
    break;
  default:
    goto switchD_00ae05e3_caseD_7;
  }
  if ((DAT_01d668e4 != '\0') && (iVar3 == 5)) {
    puStack_8c = (undefined4 *)&DAT_021289f0;
    puStack_90 = (undefined *)0xae06c6;
    FUN_008a4940();
  }
switchD_00ae05e3_caseD_7:
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22495 ; VA 0x00ae0700 ; FUN_00ae0700 */

void __fastcall FUN_00ae0700(int param_1)

{
  if (*(char *)(param_1 + 0x78) != '\0') {
    FUN_00adf0e0(param_1,1);
    FUN_00ae0cd0(0);
  }
  return;
}



/* FUNCTION 22496 ; VA 0x00ae0730 ; FUN_00ae0730 */

void __fastcall FUN_00ae0730(int param_1)

{
  double dVar1;
  double dVar2;
  char cVar3;
  
  cVar3 = *(char *)(param_1 + 0x78);
  *(undefined4 *)(param_1 + 0x120) = 0;
  if (cVar3 == '\0') {
    FUN_00adf0e0(param_1,0);
  }
  dVar1 = *(double *)(param_1 + 0x128);
  dVar2 = *(double *)(param_1 + 0x88);
  if (((NAN(dVar2) || NAN(dVar1)) == (dVar2 == dVar1)) &&
     (((double)CONCAT44((uint)((ulonglong)dVar2 >> 0x20) & DAT_018c0da0._4_4_,
                        SUB84(dVar2,0) & (uint)DAT_018c0da0) + DAT_018c0d60) * DAT_018e0008 <
      (double)CONCAT44((uint)((ulonglong)(dVar2 - dVar1) >> 0x20) & DAT_018c0da0._4_4_,
                       SUB84(dVar2 - dVar1,0) & (uint)DAT_018c0da0))) {
    FUN_00ae13d0(dVar1);
  }
  if (cVar3 == '\0') {
    FUN_00ae0cd0();
  }
  return;
}



/* FUNCTION 22497 ; VA 0x00ae07c0 ; FUN_00ae07c0 */

void __thiscall FUN_00ae07c0(int param_1,undefined *param_2,int *param_3,undefined4 param_4)

{
  undefined8 uVar1;
  undefined8 uVar2;
  undefined uVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  undefined *puVar7;
  undefined8 *puVar8;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  if (param_2 == &DAT_02128cb0) {
    if (((*(char *)(param_1 + 0x1a9) == '\0') && (*(int *)(param_1 + 0x11c) == 4)) &&
       ((iVar5 = FUN_0068f720(param_1), iVar5 != 0 && (cVar4 = FUN_00c23510(), cVar4 != '\0')))) {
      return;
    }
    if (((param_3[1] - *param_3) - 0xd0U < 0xd0) &&
       (iVar5 = *(int *)*param_3, iVar6 = FUN_0088daf0(), iVar5 == iVar6)) {
      puVar7 = (undefined *)FUN_00605c60();
      uVar3 = *puVar7;
      FUN_00ae0c60(uVar3);
      uStack_c = param_4;
      uStack_8 = 1;
      FUN_0098a470(param_1,uVar3,&uStack_c);
      return;
    }
  }
  else if (param_2 == &DAT_02128c70) {
    if ((((*(char *)(param_1 + 0x1a9) == '\0') && (*(int *)(param_1 + 0x11c) == 4)) &&
        (iVar5 = FUN_0068f720(param_1), iVar5 != 0)) && (cVar4 = FUN_00c23510(), cVar4 != '\0')) {
      return;
    }
    if ((((param_3[1] - *param_3) - 0x1a0U < 0xd0) &&
        (iVar5 = *(int *)*param_3, iVar6 = FUN_0088ca00(), iVar5 == iVar6)) &&
       (iVar5 = *(int *)(*param_3 + 0xd0), iVar6 = FUN_0088ca00(), iVar5 == iVar6)) {
      puVar8 = (undefined8 *)FUN_00605ba0();
      uVar1 = *puVar8;
      puVar8 = (undefined8 *)FUN_00605ba0();
      uVar2 = *puVar8;
      *(undefined8 *)(param_1 + 0x128) = uVar2;
      FUN_00fe9d60((int)uVar1,(int)((ulonglong)uVar1 >> 0x20));
      uStack_c = param_4;
      uStack_8 = 1;
      FUN_00ae0980(param_1,uVar1,(int)uVar2,(int)((ulonglong)uVar2 >> 0x20),&uStack_c);
      return;
    }
  }
  else {
    FUN_009cba80(param_2,param_3,param_4);
  }
  return;
}



/* FUNCTION 22498 ; VA 0x00ae0980 ; FUN_00ae0980 */

void FUN_00ae0980(int *param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4)

{
  code *pcVar1;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined8 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined8 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eacbc;
  pvStack_10 = ExceptionList;
  pcVar1 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_1c0 = FUN_0088ca00();
  uStack_1bc = 0;
  uStack_1b8 = param_2;
  uStack_1bc = FUN_00630890();
  uStack_8 = 0;
  uStack_f0 = FUN_0088ca00();
  uStack_ec = 0;
  uStack_e8 = param_3;
  uStack_ec = FUN_00630890();
  uStack_8 = 1;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,param_1);
  uStack_8._0_1_ = 2;
  (*pcVar1)(uStack_14,&uStack_20,param_4);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00577b20();
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22499 ; VA 0x00ae0a90 ; FUN_00ae0a90 */

void __fastcall FUN_00ae0a90(int param_1)

{
  if (*(char *)(param_1 + 0x78) == '\0') {
    FUN_00adf0e0(param_1,2);
    FUN_00ae0cd0(1);
  }
  return;
}


