/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 9500 ; VA 0x006e7090 ; FUN_006e7090 */

int * FUN_006e7090(int *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  undefined8 *puVar3;
  undefined4 uVar4;
  float10 fVar5;
  undefined auStack_20 [4];
  undefined8 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a97a9;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puVar2 = (undefined4 *)FUN_01674e20(0x30);
  uStack_1c = (double)CONCAT44(puVar2,(undefined4)uStack_1c);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    puVar2[1] = 0x19;
    puVar2[2] = 1;
    puVar2[3] = 0;
    *puVar2 = RBX::Network::DeserializedStreamPrefetchRequestItem::vftable;
    puVar2[4] = 0;
    puVar2[5] = 0;
    puVar2[6] = 0;
    *(undefined8 *)(puVar2 + 8) = 0;
    puVar2[10] = 0;
  }
  *param_1 = 0;
  param_1[1] = 0;
  FUN_006e11f0(puVar2,param_1);
  uStack_8 = 0;
  uStack_14 = 1;
  puVar3 = (undefined8 *)FUN_006abea0(auStack_20);
  uVar4 = *(undefined4 *)(puVar3 + 1);
  iVar1 = *param_1;
  *(undefined8 *)(iVar1 + 0x10) = *puVar3;
  *(undefined4 *)(iVar1 + 0x18) = uVar4;
  fVar5 = (float10)FUN_006ac2c0();
  uStack_1c = (double)fVar5;
  *(double *)(*param_1 + 0x20) = uStack_1c;
  uVar4 = FUN_006ac4d0();
  *(undefined4 *)(*param_1 + 0x28) = uVar4;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9501 ; VA 0x006e7190 ; FUN_006e7190 */

void FUN_006e7190(undefined4 param_1)

{
  undefined auStack_c [8];
  
  FUN_006b8fd0(auStack_c,param_1);
  FUN_006e7320(auStack_c);
  return;
}



/* FUNCTION 9502 ; VA 0x006e71c0 ; FUN_006e71c0 */

void FUN_006e71c0(void)

{
  undefined4 uVar1;
  float10 fVar2;
  undefined8 uStack_18;
  undefined4 uStack_10;
  double dStack_c;
  
  FUN_006abea0(&uStack_18);
  fVar2 = (float10)FUN_006ac2c0();
  dStack_c = (double)fVar2;
  uVar1 = FUN_006ac4d0();
  FUN_006e7cf0(uStack_18,uStack_10,dStack_c,uVar1,0);
  return;
}



/* FUNCTION 9503 ; VA 0x006e7230 ; FUN_006e7230 */

void FUN_006e7230(undefined *param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  undefined auStack_4c [12];
  int iStack_40;
  int iStack_38;
  undefined auStack_24 [12];
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a97c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006acb50(auStack_24);
  FUN_006e7960(auStack_24);
  iVar2 = FUN_006ace40();
  cVar1 = FUN_006abd90();
  FUN_006ab530();
  uStack_8 = 0;
  if (cVar1 != '\0') {
    FUN_0061a740(param_1,auStack_4c);
    param_1 = auStack_4c;
  }
  for (; iVar2 != 0; iVar2 = iVar2 + -1) {
    FUN_006b8fd0(auStack_18,param_1);
    FUN_006e7320(auStack_18);
  }
  if (iStack_40 != 0) {
    uVar3 = iStack_38 - iStack_40;
    iVar2 = iStack_40;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iStack_40 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iStack_40 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9504 ; VA 0x006e7320 ; FUN_006e7320 */

ushort * __thiscall FUN_006e7320(ushort *param_1,ushort *param_2)

{
  int *piVar1;
  undefined8 uVar2;
  int *piVar3;
  char cVar4;
  ushort *puVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  ushort *puStack_64;
  int *piStack_60;
  int iStack_5c;
  int iStack_58;
  undefined8 uStack_54;
  undefined auStack_4c [8];
  ushort **ppuStack_44;
  ushort *puStack_40;
  int *piStack_3c;
  int iStack_38;
  ushort *puStack_34;
  int *piStack_30;
  int iStack_2c;
  ushort *puStack_28;
  int *piStack_24;
  undefined auStack_20 [4];
  ushort *puStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a97f0;
  pvStack_10 = ExceptionList;
  puStack_28 = (ushort *)0x0;
  piStack_24 = (int *)0x0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00621ac0(param_2,&puStack_28);
  puVar5 = (ushort *)FUN_00621090(puStack_28);
  if (((char)puVar5 == '\0') ||
     ((DAT_01d5b988 != '\0' &&
      ((puVar5 = puStack_28, puStack_28 == (ushort *)0x0 || (*(int *)(puStack_28 + 0x1a) == 0))))))
  goto LAB_006e777e;
  if (DAT_01d5b9a8 == '\0') {
    iVar6 = FUN_006e5b60(puStack_28,0);
    cVar4 = iVar6 == 0;
    if (iVar6 != 0) {
      uVar7 = FUN_00c15960();
      puVar8 = (undefined4 *)FUN_006e77c0(auStack_4c,uVar7);
      param_2 = (ushort *)((uint)param_2 & 0xffffff);
      puStack_64 = (ushort *)*puVar8;
      piStack_60 = (int *)puVar8[1];
      iStack_5c = puVar8[2];
      iStack_58 = puVar8[3];
      uVar2 = *(undefined8 *)(puVar8 + 4);
      ppuStack_44 = &puStack_64;
      uStack_54._4_4_ = (int)((ulonglong)uVar2 >> 0x20);
      uStack_54._0_4_ = (int)uVar2;
      iVar6 = uStack_54._4_4_ + 1;
      piStack_14 = (int *)((int)uStack_54 + 1);
      puStack_1c = (ushort *)(iStack_58 + 1);
      uStack_54 = uVar2;
      puStack_40 = puStack_64;
      piStack_3c = piStack_60;
      iStack_38 = iStack_5c;
      do {
        if (((puStack_40 == puStack_1c) && (piStack_3c == piStack_14)) && (iStack_38 == iVar6)) {
          cVar4 = param_2._3_1_;
          break;
        }
        puStack_34 = puStack_40;
        piStack_30 = piStack_3c;
        iStack_2c = iStack_38;
        if (*(char *)(*(int *)(param_1 + 0x94) + 0x1db8) == '\0') {
          FUN_006d9080();
          cVar4 = FUN_0071c520(*(undefined4 *)(param_1 + 0x94),&puStack_34);
          if (cVar4 != '\0') goto LAB_006e757d;
        }
        FUN_00ca2620();
      } while( true );
    }
    goto LAB_006e7584;
  }
  FUN_006e7be0(puStack_28);
  param_2 = param_1;
  FUN_006e1780(&param_2);
  puVar5 = *(ushort **)(param_1 + 0x94);
  if (*(char *)(puVar5 + 0xedc) != '\0') goto LAB_006e777e;
  if (DAT_01d5b990 != '\0') {
    param_2 = puStack_28;
    FUN_006e5160(&param_2);
  }
  if ((DAT_01d5b9b8 != '\0') &&
     (piStack_14 = (int *)FUN_006e16a0(puStack_28), piStack_14 != (int *)0x0)) {
    iVar6 = FUN_00c155c0();
    if ((iVar6 != 0) && (cVar4 = FUN_00ca0f40(), cVar4 == '\0')) goto LAB_006e7743;
    if (DAT_01d5b9c8 != '\0') {
      uVar7 = FUN_00c160f0();
      param_2 = (ushort *)FUN_00b06640(uVar7);
      if (param_2 != (ushort *)0x0) {
        FUN_006e2b20(&param_2);
        FUN_006e5160(&piStack_14);
        iVar6 = FUN_006e2b20(&param_2);
        if (*(int *)(iVar6 + 0xc) == 0) {
          FUN_006e5080(&param_2);
        }
      }
    }
  }
LAB_006e7765:
  puVar5 = (ushort *)FUN_006d66a0(*(undefined4 *)(param_1 + 0x94),&puStack_28);
LAB_006e777e:
  piVar3 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_24 + 1;
    iVar6 = *piVar1;
    puVar5 = (ushort *)*piVar1;
    *piVar1 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      puVar5 = (ushort *)(**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        puVar5 = (ushort *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar5;
LAB_006e757d:
  cVar4 = '\x01';
LAB_006e7584:
  puVar5 = *(ushort **)(param_1 + 0x94);
  if (cVar4 != '\0') {
    param_2 = *(ushort **)(puVar5 + 0xcfa);
    puStack_1c = puVar5;
    puVar5 = (ushort *)FUN_006193f0(*(undefined4 *)(puStack_28 + 6));
    if (puVar5 != (ushort *)0x0) {
      if ((uint)*puVar5 < (uint)((*(int *)(param_2 + 0x2e) - *(int *)(param_2 + 0x2c)) / 0x3c)) {
        param_2 = (ushort *)(*(int *)(param_2 + 0x2c) + (uint)*puVar5 * 0x3c);
      }
      else {
        param_2 = (ushort *)0x0;
      }
      uStack_18 = 0;
      piStack_14 = (int *)0x0;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (*(char *)(puStack_1c + 0xedc) == '\0') {
        puVar8 = (undefined4 *)FUN_006d88d0(auStack_20,puStack_28);
        piVar1 = piStack_14;
        uStack_18 = *puVar8;
        piVar3 = (int *)puVar8[1];
        *puVar8 = 0;
        puVar8[1] = 0;
        if (piStack_14 != (int *)0x0) {
          LOCK();
          iVar6 = piStack_14[1] + -1;
          piStack_14[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            puVar8 = (undefined4 *)*piStack_14;
            piStack_14 = piVar3;
            (*(code *)*puVar8)();
            LOCK();
            piVar3 = piVar1 + 2;
            iVar6 = *piVar3 + -1;
            *piVar3 = iVar6;
            UNLOCK();
            piVar3 = piStack_14;
            if (iVar6 == 0) {
              (**(code **)(*piVar1 + 4))();
              piVar3 = piStack_14;
            }
          }
        }
        piStack_14 = piVar3;
        FUN_00550b30();
      }
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piStack_24[1] = piStack_24[1] + 1;
        UNLOCK();
      }
      puVar5 = (ushort *)FUN_00617ec0(puStack_28,piStack_24,param_2,&uStack_18,0);
      piVar3 = piStack_14;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_14 + 1;
        iVar6 = *piVar1;
        puVar5 = (ushort *)*piVar1;
        *piVar1 = iVar6 + -1;
        UNLOCK();
        if (iVar6 + -1 == 0) {
          (**(code **)*piStack_14)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar6 = *piVar1;
          puVar5 = (ushort *)*piVar1;
          *piVar1 = iVar6 + -1;
          UNLOCK();
          if (iVar6 + -1 == 0) {
            puVar5 = (ushort *)(**(code **)(*piVar3 + 4))();
          }
        }
      }
    }
    goto LAB_006e777e;
  }
  if (*(char *)(puVar5 + 0xedc) != '\0') goto LAB_006e777e;
  if (DAT_01d5b990 != '\0') {
    param_2 = puStack_28;
    FUN_006e5160(&param_2);
  }
  if (((DAT_01d5b9b8 != '\0') && (iVar6 = FUN_006e16a0(puStack_28), iVar6 != 0)) &&
     ((iVar6 = FUN_00c155c0(), iVar6 != 0 && (cVar4 = FUN_00ca0f40(), cVar4 == '\0')))) {
LAB_006e7743:
    uVar7 = FUN_00c15700();
    param_2 = (ushort *)FUN_00b06640(uVar7);
    FUN_006e5160(&param_2);
  }
  goto LAB_006e7765;
}



/* FUNCTION 9505 ; VA 0x006e77c0 ; FUN_006e77c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_006e77c0(undefined8 *param_1,undefined (*param_2) [12])

{
  undefined8 uVar1;
  float fVar2;
  int iVar3;
  int iVar4;
  float fVar6;
  int iVar7;
  int iVar8;
  float fVar9;
  int iVar10;
  int iVar11;
  undefined in_XMM1 [16];
  undefined auVar5 [16];
  undefined auVar12 [16];
  undefined auVar13 [16];
  float fVar14;
  uint uVar15;
  float fVar17;
  uint uVar18;
  float fVar19;
  uint uVar20;
  undefined auVar16 [16];
  float fVar21;
  float fVar22;
  float fVar23;
  
  fVar21 = SUB164(_DAT_018e0060,0);
  fVar22 = SUB164(_DAT_018e0060,4);
  fVar23 = SUB164(_DAT_018e0060,8);
  auVar5 = rcpps(in_XMM1,_DAT_018e0060);
  fVar2 = auVar5._0_4_;
  fVar6 = auVar5._4_4_;
  fVar9 = auVar5._8_4_;
  fVar14 = (_DAT_018e0050 - fVar21 * fVar2) * fVar2;
  fVar17 = (_UNK_018e0054 - fVar22 * fVar6) * fVar6;
  fVar19 = (_UNK_018e0058 - fVar23 * fVar9) * fVar9;
  uVar15 = ((uint)fVar14 ^ (uint)fVar2) &
           -(uint)((float)(~DAT_018c4ea0 & (uint)fVar14) < _DAT_018e0080) ^ (uint)fVar2;
  uVar18 = ((uint)fVar17 ^ (uint)fVar6) &
           -(uint)((float)(~_UNK_018c4ea4 & (uint)fVar17) < _UNK_018e0084) ^ (uint)fVar6;
  uVar20 = ((uint)fVar19 ^ (uint)fVar9) &
           -(uint)((float)(~_UNK_018c4ea8 & (uint)fVar19) < _UNK_018e0088) ^ (uint)fVar9;
  auVar12._12_4_ = 0;
  auVar12._0_12_ = *param_2;
  fVar21 = (float)((DAT_018c4ea0 & (uint)fVar21 ^ uVar15) &
                   -(uint)((float)(~DAT_018c4ea0 & (uint)fVar21) == _DAT_018e0080) ^ uVar15);
  fVar22 = (float)((_UNK_018c4ea4 & (uint)fVar22 ^ uVar18) &
                   -(uint)((float)(~_UNK_018c4ea4 & (uint)fVar22) == _UNK_018e0084) ^ uVar18);
  fVar23 = (float)((_UNK_018c4ea8 & (uint)fVar23 ^ uVar20) &
                   -(uint)((float)(~_UNK_018c4ea8 & (uint)fVar23) == _UNK_018e0088) ^ uVar20);
  auVar16._0_8_ = CONCAT44(0.0 - SUB164(_DAT_018e0070,4),0.0 - SUB164(_DAT_018e0070,0));
  auVar16._8_4_ = 0.0 - SUB164(_DAT_018e0070,8);
  auVar16._12_4_ = 0.0 - SUB164(_DAT_018e0070,0xc);
  auVar5._8_4_ = auVar16._8_4_;
  auVar5._0_8_ = auVar16._0_8_;
  auVar5._12_4_ = auVar16._12_4_;
  auVar5 = maxps(auVar5,auVar12);
  auVar5 = minps(_DAT_018e0070,auVar5);
  fVar14 = auVar5._0_4_ * fVar21;
  fVar17 = auVar5._4_4_ * fVar22;
  fVar19 = auVar5._8_4_ * fVar23;
  fVar2 = (float)(int)fVar14;
  fVar6 = (float)(int)fVar17;
  fVar9 = (float)(int)fVar19;
  iVar3 = (int)(fVar2 - (float)(_DAT_018e0040 & -(uint)(fVar14 < fVar2)));
  iVar7 = (int)(fVar6 - (float)(_UNK_018e0044 & -(uint)(fVar17 < fVar6)));
  iVar10 = (int)(fVar9 - (float)(_UNK_018e0048 & -(uint)(fVar19 < fVar9)));
  auVar13._12_4_ = 0;
  auVar13._0_12_ = param_2[1];
  auVar5 = maxps(auVar16,auVar13);
  auVar5 = minps(_DAT_018e0070,auVar5);
  fVar21 = auVar5._0_4_ * fVar21;
  fVar22 = auVar5._4_4_ * fVar22;
  fVar23 = auVar5._8_4_ * fVar23;
  fVar2 = (float)(int)fVar21;
  fVar6 = (float)(int)fVar22;
  fVar9 = (float)(int)fVar23;
  iVar4 = (int)((float)(_DAT_018e0040 & -(uint)(fVar2 < fVar21)) + fVar2);
  iVar8 = (int)((float)(_UNK_018e0044 & -(uint)(fVar6 < fVar22)) + fVar6);
  iVar11 = (int)((float)(_UNK_018e0048 & -(uint)(fVar9 < fVar23)) + fVar9);
  if (((iVar3 < iVar4) && (iVar7 < iVar8)) && (iVar10 < iVar11)) {
    iVar11 = iVar11 + -1;
    uVar1 = CONCAT44(iVar8 + -1,iVar4 + -1);
  }
  else {
    uVar1 = CONCAT44(iVar8,iVar4);
  }
  *(undefined4 *)(param_1 + 2) = 0;
  *(undefined4 *)((int)param_1 + 0x14) = 0;
  *param_1 = CONCAT44(iVar7,iVar3);
  *(int *)(param_1 + 1) = iVar10;
  *(undefined8 *)((int)param_1 + 0xc) = uVar1;
  *(int *)((int)param_1 + 0x14) = iVar11;
  return;
}



/* FUNCTION 9506 ; VA 0x006e7960 ; FUN_006e7960 */

void __thiscall FUN_006e7960(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  int iVar8;
  undefined8 uVar9;
  int iStack_34;
  int iStack_30;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9808;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(char *)(*(int *)(param_1 + 0x128) + 0x1db8) == '\0') {
    ExceptionList = &pvStack_10;
    FUN_006d9080();
    FUN_0071db40(*(undefined4 *)(param_1 + 0x128),param_2,0);
  }
  iVar2 = *(int *)(param_1 + 0x198);
  iVar5 = -iVar2;
  if ((((((float)(*(int *)(param_1 + 0x184) + iVar5) <= (float)*param_2) &&
        ((float)(*(int *)(param_1 + 0x188) + iVar5) <= (float)param_2[1])) &&
       ((float)(*(int *)(param_1 + 0x18c) + iVar5) <= (float)param_2[2])) &&
      (((float)*param_2 <= (float)(*(int *)(param_1 + 0x184) + iVar2) &&
       ((float)param_2[1] <= (float)(*(int *)(param_1 + 0x188) + iVar2))))) &&
     ((float)param_2[2] <= (float)(*(int *)(param_1 + 0x18c) + iVar2))) {
    uVar4 = param_2[2] - *(int *)(param_1 + 0x18c);
    uStack_28._0_4_ = (int)*(undefined8 *)param_2;
    iStack_34 = (int)*(undefined8 *)(param_1 + 0x184);
    uVar6 = (int)uStack_28 - iStack_34 >> 0x1f;
    uStack_28._4_4_ = (int)((ulonglong)*(undefined8 *)param_2 >> 0x20);
    iStack_30 = (int)((ulonglong)*(undefined8 *)(param_1 + 0x184) >> 0x20);
    iVar8 = ((int)uStack_28 - iStack_34 ^ uVar6) - uVar6;
    uVar6 = uStack_28._4_4_ - iStack_30 >> 0x1f;
    iVar5 = (uStack_28._4_4_ - iStack_30 ^ uVar6) - uVar6;
    uVar6 = (int)uVar4 >> 0x1f;
    iVar2 = (uVar4 ^ uVar6) - uVar6;
    if (iVar5 <= iVar8) {
      iVar5 = iVar8;
    }
    if (iVar2 <= iVar5) {
      iVar2 = iVar5;
    }
    iVar5 = iVar2 + -1;
    if (*(int *)(param_1 + 0x198) <= iVar2 + -1) {
      iVar5 = *(int *)(param_1 + 0x198);
    }
    if (iVar5 < 1) {
      iVar5 = 0;
    }
    *(int *)(param_1 + 0x198) = iVar5;
    if (DAT_01eaf208 != 0) {
      *(int *)(param_1 + 0x1a8) = iVar5;
    }
    iVar2 = *(int *)(param_1 + 0x184) - iVar5;
    iVar8 = *(int *)(param_1 + 0x18c) - iVar5;
    uVar9 = *(undefined8 *)(param_1 + 0x16c);
    iVar5 = *(int *)(param_1 + 0x188) - iVar5;
    uStack_28 = CONCAT44(iVar5,iVar2);
    iStack_34 = (int)uVar9;
    if (((iStack_34 < iVar2) || (iStack_30 = (int)((ulonglong)uVar9 >> 0x20), iStack_30 < iVar5)) ||
       (iVar2 = *(int *)(param_1 + 0x174), *(int *)(param_1 + 0x174) < iVar8)) {
      iVar2 = iVar8;
      uVar9 = uStack_28;
    }
    *(undefined8 *)(param_1 + 0x16c) = uVar9;
    *(int *)(param_1 + 0x174) = iVar2;
  }
  if (*(int *)(param_1 + 0x1d0) != 0) {
    uVar3 = FUN_01675290(DAT_01eaf294);
    uStack_8 = 0;
    piVar7 = (int *)**(int **)(param_1 + 0x1cc);
    if (piVar7 != *(int **)(param_1 + 0x1cc)) {
      do {
        FUN_006e45f0(piVar7 + 2);
        if (piVar7[0x1c] != 0) {
          (**(code **)((piVar7[0x1c] & 0xfffffffeU) + 4))(piVar7 + 0x1e);
        }
        piVar1 = (int *)*piVar7;
        *(int **)piVar7[1] = piVar1;
        *(int *)(*piVar7 + 4) = piVar7[1];
        *(int *)(param_1 + 0x1d0) = *(int *)(param_1 + 0x1d0) + -1;
        FUN_006e3220(piVar7);
        piVar7 = piVar1;
      } while (piVar1 != (int *)*(int *)(param_1 + 0x1cc));
    }
    uStack_8 = 2;
    FUN_01675290(uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9507 ; VA 0x006e7be0 ; FUN_006e7be0 */

void __thiscall FUN_006e7be0(int param_1,int param_2)

{
  undefined8 uVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  int iVar7;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  undefined8 uStack_30;
  undefined auStack_28 [8];
  int *piStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  int iStack_8;
  
  if ((param_2 != 0) &&
     (iVar6 = *(int *)(param_2 + 0xc), iVar3 = FUN_00aff8c0(),
     (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
     (uint)*(ushort *)(iVar3 + 0x1da))) {
    uVar4 = FUN_00c15960();
    piVar5 = (int *)FUN_006e77c0(auStack_28,uVar4);
    iStack_40 = *piVar5;
    iStack_3c = piVar5[1];
    iStack_38 = piVar5[2];
    iStack_34 = piVar5[3];
    uVar1 = *(undefined8 *)(piVar5 + 4);
    piStack_20 = &iStack_40;
    uStack_30._0_4_ = (int)uVar1;
    iVar3 = (int)uStack_30 + 1;
    uStack_30._4_4_ = (int)((ulonglong)uVar1 >> 0x20);
    iVar7 = iStack_34 + 1;
    iVar6 = uStack_30._4_4_ + 1;
    uStack_30 = uVar1;
    iStack_1c = iStack_40;
    iStack_18 = iStack_3c;
    iStack_14 = iStack_38;
    while (((iStack_1c != iVar7 || (iStack_18 != iVar3)) || (iStack_14 != iVar6))) {
      iStack_10 = iStack_1c;
      iStack_c = iStack_18;
      iStack_8 = iStack_14;
      if (*(char *)(*(int *)(param_1 + 0x128) + 0x1db8) == '\0') {
        FUN_006d9080();
        cVar2 = FUN_0071c520(*(undefined4 *)(param_1 + 0x128),&iStack_10);
        if (cVar2 != '\0') {
          FUN_006e7960(&iStack_10);
        }
      }
      FUN_00ca2620();
    }
  }
  return;
}



/* FUNCTION 9508 ; VA 0x006e7cf0 ; FUN_006e7cf0 */

void __thiscall FUN_006e7cf0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  uint in_stack_0000001c;
  undefined4 uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a9830;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar6 = FUN_01675290(DAT_01eaf294);
  iVar2 = *(int *)(param_1 + 0x1cc);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  puVar3 = *(undefined4 **)(iVar2 + 4);
  puVar1 = (undefined4 *)(param_1 + 0x1cc);
  uVar8 = uVar6;
  uVar7 = FUN_006e0b80(iVar2,puVar3,*(undefined4 *)(param_1 + 0x128),&stack0x00000004,
                       &stack0x00000010,&stack0x0000001c,&stack0x00000018);
  if (*(undefined **)(param_1 + 0x1d0) != &DAT_01999998) {
    *(undefined **)(param_1 + 0x1d0) = *(undefined **)(param_1 + 0x1d0) + 1;
    *(undefined4 *)(iVar2 + 4) = uVar7;
    *puVar3 = uVar7;
    if (DAT_01d5b90c < *(uint *)(param_1 + 0x1d0)) {
      FUN_006e45f0(*(int *)*puVar1 + 8);
      uVar4 = *(uint *)(*(int *)*puVar1 + 0x70);
      if (uVar4 != 0) {
        (**(code **)((uVar4 & 0xfffffffe) + 4))(*(int *)*puVar1 + 0x78);
      }
      piVar5 = *(int **)*puVar1;
      *(int *)piVar5[1] = *piVar5;
      *(int *)(*piVar5 + 4) = piVar5[1];
      *(int *)(param_1 + 0x1d0) = *(int *)(param_1 + 0x1d0) + -1;
      FUN_006e3220(piVar5);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_01675290(uVar6);
    uStack_8 = 4;
    if (((in_stack_0000001c != 0) && ((in_stack_0000001c & 1) == 0)) &&
       (*(code **)(in_stack_0000001c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000001c & 0xfffffffe))(&stack0x00000024,&stack0x00000024,2,uVar8);
    }
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("list<T> too long");
}



/* FUNCTION 9509 ; VA 0x006e7e30 ; FUN_006e7e30 */

void __thiscall
FUN_006e7e30(int param_1,undefined8 param_2,undefined4 param_3,undefined8 param_4,uint param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined8 param_11)

{
  undefined4 *puVar1;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017a9857;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  uStack_24 = 0x50006e7e5b;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20();
  iStack_8._0_1_ = 1;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    uStack_24 = CONCAT44(*(undefined4 *)(param_1 + -8),0x6e7e75);
    FUN_006b1a30();
    *puVar1 = RBX::Network::Replicator::StreamJob::StreamPrefetchRequestItem::vftable;
    *(undefined8 *)(puVar1 + 0xc) = param_2;
    puVar1[0xe] = param_3;
    *(undefined8 *)(puVar1 + 0x10) = param_4;
    puVar1[0x12] = 0;
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  uStack_24 = CONCAT44(puVar1,0x6e7eb3);
  FUN_006b1f50();
  if (param_5 != 0) {
    if ((param_5 & 1) == 0) {
      (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_34,0);
    }
    else {
      uStack_34 = param_7;
      uStack_30 = param_8;
      uStack_2c = param_9;
      puStack_28 = (undefined4 *)param_10;
      uStack_24 = param_11;
    }
  }
  FUN_006e7cf0(param_2,param_3,param_4,0);
  iStack_8 = 2;
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    puStack_28 = &param_7;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0x6e7f47;
    (**(code **)(param_5 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9510 ; VA 0x006e7f60 ; FUN_006e7f60 */

undefined4 __thiscall FUN_006e7f60(undefined8 *param_1,float *param_2,char param_3)

{
  undefined8 uVar1;
  bool bVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  float10 fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  double dVar12;
  undefined8 uStack_68;
  undefined8 uStack_58;
  
  fVar8 = (float10)FUN_01725280((double)param_2[2]);
  fVar9 = (float)fVar8;
  if (fVar9 < 0.0) {
    fVar9 = fVar9 - DAT_018ce2f4;
  }
  else {
    fVar9 = fVar9 + DAT_018ce2f4;
  }
  fVar8 = (float10)FUN_01725280((double)param_2[1]);
  fVar10 = (float)fVar8;
  if (fVar10 < 0.0) {
    fVar10 = fVar10 - DAT_018ce2f4;
  }
  else {
    fVar10 = fVar10 + DAT_018ce2f4;
  }
  fVar8 = (float10)FUN_01725280((double)*param_2);
  fVar11 = (float)fVar8;
  if (fVar11 < 0.0) {
    fVar11 = fVar11 - DAT_018ce2f4;
  }
  else {
    fVar11 = fVar11 + DAT_018ce2f4;
  }
  iVar6 = (int)fVar9 >> ((byte)DAT_01d5b944 & 0x1f);
  iVar3 = (int)fVar10 >> ((byte)DAT_01d5b940 & 0x1f);
  iVar7 = (int)fVar11 >> ((byte)DAT_01d5b93c & 0x1f);
  uStack_58 = CONCAT44(iVar3,iVar7);
  if ((((*(int *)(param_1 + 3) == iVar7) && (*(int *)((int)param_1 + 0x1c) == iVar3)) &&
      (*(int *)(param_1 + 4) == iVar6)) && (param_3 == '\0')) {
    return 0;
  }
  iVar5 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  if ((*(int *)(iVar5 + 0x34) < DAT_01eaf2a8) && (FUN_016f3809(), DAT_01eaf2a8 == -1)) {
    DAT_01eaf29c = 0x40;
    DAT_01eaf2a0 = 0x40;
    DAT_01eaf2a4 = 0x40;
    FUN_016f37bf();
  }
  iVar3 = DAT_01eaf2a0 * iVar3;
  iVar7 = iVar7 * DAT_01eaf29c;
  iVar4 = DAT_01eaf2a4 * iVar6;
  if ((*(int *)(iVar5 + 0x34) < DAT_01eaf2b8) && (FUN_016f3809(), DAT_01eaf2b8 == -1)) {
    DAT_01eaf2ac = 0x20;
    DAT_01eaf2b0 = 0x20;
    DAT_01eaf2b4 = 0x20;
    FUN_016f37bf();
  }
  iVar5 = *(int *)(param_1 + 4);
  iVar4 = DAT_01eaf2b4 + iVar4;
  bVar2 = false;
  uVar1 = param_1[3];
  *(ulonglong *)((int)param_1 + 0xc) =
       CONCAT44((float)(DAT_01eaf2b0 + iVar3),(float)(DAT_01eaf2ac + iVar7));
  param_1[3] = uStack_58;
  *(float *)((int)param_1 + 0x14) = (float)iVar4;
  *(int *)(param_1 + 4) = iVar6;
  if (param_3 == '\0') {
    uStack_68._4_4_ = (int)((ulonglong)uVar1 >> 0x20);
    uStack_68._4_4_ = *(int *)((int)param_1 + 0x1c) - uStack_68._4_4_;
    uStack_68._0_4_ = (int)uVar1;
    dVar12 = (double)((iVar6 - iVar5) * (iVar6 - iVar5) + uStack_68._4_4_ * uStack_68._4_4_ +
                     (*(int *)(param_1 + 3) - (int)uStack_68) *
                     (*(int *)(param_1 + 3) - (int)uStack_68));
    FUN_017267a0();
    fVar8 = (float10)FUN_01725160((double)(float)dVar12);
    iVar7 = *(int *)((int)param_1 + 0x2c) - (int)fVar8;
    iVar3 = 0;
    if (-1 < iVar7) {
      iVar3 = iVar7;
    }
    *(int *)((int)param_1 + 0x2c) = iVar3;
    if (DAT_01eaf208 != 0) {
      iVar5 = *(int *)((int)param_1 + 0x3c) - (int)fVar8;
      iVar7 = 0;
      if (-1 < iVar5) {
        iVar7 = iVar5;
      }
      *(int *)((int)param_1 + 0x3c) = iVar7;
    }
    bVar2 = iVar3 <= *(int *)(param_1 + 7);
    if (iVar3 != 0) {
      uVar1 = *param_1;
      iVar7 = *(int *)((int)param_1 + 0x1c) - iVar3;
      uStack_68 = CONCAT44(iVar7,*(int *)(param_1 + 3) - iVar3);
      uStack_58._0_4_ = (int)uVar1;
      if ((((int)uStack_58 < *(int *)(param_1 + 3) - iVar3) ||
          (uStack_58._4_4_ = (int)((ulonglong)uVar1 >> 0x20), uStack_58._4_4_ < iVar7)) ||
         (iVar7 = *(int *)(param_1 + 1), *(int *)(param_1 + 1) < iVar6 - iVar3)) {
        iVar7 = iVar6 - iVar3;
        uVar1 = uStack_68;
      }
      *param_1 = uVar1;
      *(int *)(param_1 + 1) = iVar7;
      goto LAB_006e8282;
    }
  }
  else {
    *(undefined4 *)((int)param_1 + 0x2c) = 0;
    if (DAT_01eaf208 != 0) {
      *param_1 = uStack_58;
      *(undefined4 *)((int)param_1 + 0x3c) = 0;
      *(int *)(param_1 + 1) = iVar6;
      goto LAB_006e8282;
    }
  }
  *param_1 = uStack_58;
  *(int *)(param_1 + 1) = iVar6;
LAB_006e8282:
  if ((DAT_01eaf35c != '\0') &&
     (FUN_016774d0(DAT_01eaf35c,"centerPosition: (%f,%f,%f)",*(undefined4 *)((int)param_1 + 0xc),
                   *(undefined4 *)(param_1 + 2),*(undefined4 *)((int)param_1 + 0x14),0),
     DAT_01eaf35c != '\0')) {
    FUN_01677490(DAT_01eaf35c,"centerRegion: (%d,%d,%d)",*(undefined4 *)(param_1 + 3),
                 *(undefined4 *)((int)param_1 + 0x1c),*(undefined4 *)(param_1 + 4));
  }
  if ((!bVar2) && (*(int *)((int)param_1 + 0x2c) != 0)) {
    return 0;
  }
  return 1;
}



/* FUNCTION 9511 ; VA 0x006e83a0 ; FUN_006e83a0 */

undefined4 __fastcall FUN_006e83a0(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  undefined4 *puVar5;
  int *piVar6;
  int iStack_28;
  int *piStack_24;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a9878;
  pvStack_10 = ExceptionList;
  puStack_1c = *(undefined4 **)(param_1 + 0x150);
  puVar5 = *(undefined4 **)(param_1 + 0x14c);
  if (puVar5 != puStack_1c) {
    piVar6 = puVar5 + 5;
    ExceptionList = &pvStack_10;
    iStack_14 = param_1;
    do {
      iStack_28 = 0;
      piStack_24 = (int *)0x0;
      uStack_18 = *(undefined4 *)(iStack_14 + 0x128);
      iVar2 = piVar6[-2];
      uStack_8 = 0;
      if (piVar6[-4] != 0) {
        LOCK();
        piVar1 = (int *)(piVar6[-4] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_00617d00(iVar2,*puVar5,piVar6[-4],1,1,0,&iStack_28,0);
      cVar4 = FUN_00621710();
      if (cVar4 != '\0') {
        FUN_006209c0(*puVar5);
      }
      iVar2 = piVar6[-1];
      piVar6[-1] = iStack_28;
      piVar1 = (int *)*piVar6;
      *piVar6 = (int)piStack_24;
      uStack_8 = 0xffffffff;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar3 = piVar1[1] + -1;
        piVar1[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          iStack_28 = iVar2;
          piStack_24 = piVar1;
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      puVar5 = puVar5 + 6;
      piVar6 = piVar6 + 6;
    } while (puVar5 != puStack_1c);
    puStack_1c = *(undefined4 **)(iStack_14 + 0x150);
    param_1 = iStack_14;
  }
  ExceptionList = pvStack_10;
  return CONCAT31((int3)((uint)puStack_1c >> 8),*(undefined4 **)(param_1 + 0x14c) != puStack_1c);
}



/* FUNCTION 9512 ; VA 0x006e84d0 ; FUN_006e84d0 */

undefined4 __thiscall FUN_006e84d0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char cVar3;
  undefined8 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a98a4;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 0x1d4) == '\0') {
    return 0;
  }
  ExceptionList = &pvStack_10;
  cVar3 = FUN_006e7f60(param_2,param_3);
  if (cVar3 == '\0') {
    ExceptionList = pvStack_10;
    return 0;
  }
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaf358) &&
     (FUN_016f3809(&DAT_01eaf358), DAT_01eaf358 == -1)) {
    uStack_8 = 0;
    uVar4 = FUN_0152dab0(&DAT_018c5904,"Collect Parts For Min Area",0xffffffff);
    DAT_01eaf354 = (undefined4)((ulonglong)uVar4 >> 0x20);
    DAT_01eaf350 = (undefined4)uVar4;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eaf358);
  }
  uVar2 = DAT_01eaf354;
  uVar1 = DAT_01eaf350;
  uVar4 = FUN_0152d930(DAT_01eaf350,DAT_01eaf354);
  uStack_8 = 1;
  if (*(int *)(param_1 + 0x198) <= *(int *)(param_1 + 0x1a4)) {
    do {
      cVar3 = FUN_006e47a0(param_1 + 0x16c);
      if (cVar3 == '\0') break;
    } while (*(int *)(param_1 + 0x198) <= *(int *)(param_1 + 0x1a4));
  }
  uStack_8 = 2;
  FUN_0152dda0(uVar1,uVar2,uVar4);
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 9513 ; VA 0x006e8640 ; FUN_006e8640 */

bool __thiscall FUN_006e8640(int param_1,short *param_2)

{
  undefined4 uVar1;
  int iVar2;
  int iStack_10;
  int iStack_c;
  int iStack_8;
  
  _iStack_10 = CONCAT44((int)param_2[2] >> (DAT_01d5b934 & 0x1f),
                        (int)*param_2 >> (DAT_01d5b930 & 0x1f));
  iStack_8 = (int)param_2[4] >> (DAT_01d5b938 & 0x1f);
  iVar2 = param_1 + 0x1f5 + (uint)*(byte *)(param_1 + 500);
  uVar1 = FUN_00ca2680(&iStack_10);
  FUN_006e16e0(&param_2,uVar1,&iStack_10,-(uint)(iVar2 != 0) & iVar2 + 1U);
  return param_2 == (short *)0x0;
}



/* FUNCTION 9514 ; VA 0x006e86d0 ; FUN_006e86d0 */

float10 FUN_006e86d0(float param_1)

{
  double dVar1;
  
  dVar1 = (double)param_1;
  FUN_017267a0();
  return (float10)(float)dVar1;
}



/* FUNCTION 9515 ; VA 0x006e8700 ; FUN_006e8700 */

float10 __fastcall FUN_006e8700(float *param_1)

{
  return (float10)(*param_1 * *param_1 + param_1[1] * param_1[1] + param_1[2] * param_1[2]);
}



/* FUNCTION 9516 ; VA 0x006e8740 ; FUN_006e8740 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_006e8740(undefined4 *param_1,int *param_2,char *param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  char cVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  undefined4 *puVar14;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined8 uStack_8c;
  int iStack_84;
  int iStack_80;
  int iStack_7c;
  int iStack_78;
  int iStack_74;
  int iStack_70;
  undefined4 *puStack_68;
  undefined4 *puStack_64;
  int iStack_60;
  int iStack_5c;
  int iStack_54;
  int iStack_50;
  int iStack_48;
  undefined8 uStack_44;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  undefined4 *puStack_30;
  int iStack_2c;
  int iStack_28;
  undefined4 *puStack_24;
  int *piStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a98d2;
  pvStack_10 = ExceptionList;
  puStack_24 = param_1;
  iStack_28 = DAT_01d5b924;
  uVar3 = param_2[2] - DAT_01d5b924;
  uVar12 = param_2[2] + DAT_01d5b924;
  iStack_ec = _DAT_018e0030;
  uStack_e8 = _UNK_018e0034;
  uStack_e4 = _UNK_018e0038;
  uStack_e0 = _UNK_018e003c;
  uVar9 = param_2[1] + DAT_01d5b924;
  uVar13 = param_2[1] - DAT_01d5b924;
  uVar11 = *param_2 - DAT_01d5b924;
  uVar4 = *param_2 + DAT_01d5b924;
  uStack_dc = _DAT_018e00b0;
  uStack_d8 = _UNK_018e00b4;
  uStack_d4 = _UNK_018e00b8;
  uStack_d0 = _UNK_018e00bc;
  uStack_cc = _DAT_018e00c0;
  uStack_c8 = _UNK_018e00c4;
  uStack_c4 = _UNK_018e00c8;
  uStack_c0 = _UNK_018e00cc;
  uStack_bc = _DAT_018e00a0;
  uStack_b8 = _UNK_018e00a4;
  uStack_b4 = _UNK_018e00a8;
  uStack_b0 = _UNK_018e00ac;
  uStack_ac = _DAT_018e00d0;
  uStack_a8 = _UNK_018e00d4;
  uStack_a4 = _UNK_018e00d8;
  uStack_a0 = _UNK_018e00dc;
  uStack_9c = _DAT_018e00d0;
  uStack_98 = _UNK_018e00d4;
  uStack_94 = _UNK_018e00d8;
  uStack_90 = _UNK_018e00dc;
  uVar10 = (uVar3 ^ (int)uVar3 >> 0x1f) - ((int)uVar3 >> 0x1f) & 0x80000001;
  if ((int)uVar10 < 0) {
    uVar10 = (uVar10 - 1 | 0xfffffffe) + 1;
  }
  uVar5 = (uVar13 ^ (int)uVar13 >> 0x1f) - ((int)uVar13 >> 0x1f) & 0x80000001;
  if ((int)uVar5 < 0) {
    uVar5 = (uVar5 - 1 | 0xfffffffe) + 1;
  }
  iStack_34 = uVar10 + uVar3;
  iStack_38 = uVar13 + uVar5;
  uVar3 = (uVar11 ^ (int)uVar11 >> 0x1f) - ((int)uVar11 >> 0x1f) & 0x80000001;
  if ((int)uVar3 < 0) {
    uVar3 = (uVar3 - 1 | 0xfffffffe) + 1;
  }
  iStack_54 = uVar3 + uVar11;
  iStack_50 = iStack_38;
  iStack_84 = iStack_34;
  uStack_8c = CONCAT44(iStack_38,iStack_54);
  uVar11 = (uVar12 ^ (int)uVar12 >> 0x1f) - ((int)uVar12 >> 0x1f) & 0x80000001;
  if ((int)uVar11 < 0) {
    uVar11 = (uVar11 - 1 | 0xfffffffe) + 1;
  }
  uVar3 = (uVar9 ^ (int)uVar9 >> 0x1f) - ((int)uVar9 >> 0x1f) & 0x80000001;
  if ((int)uVar3 < 0) {
    uVar3 = (uVar3 - 1 | 0xfffffffe) + 1;
  }
  iStack_2c = uVar11 + (uVar12 - 1);
  iStack_48 = (uVar9 - 1) + uVar3;
  uVar11 = (uVar4 ^ (int)uVar4 >> 0x1f) - ((int)uVar4 >> 0x1f) & 0x80000001;
  if ((int)uVar11 < 0) {
    uVar11 = (uVar11 - 1 | 0xfffffffe) + 1;
  }
  iStack_60 = (uVar4 - 1) + uVar11;
  iStack_5c = iStack_48;
  iStack_80 = iStack_60;
  iStack_7c = iStack_48;
  iStack_78 = iStack_2c;
  if (((((iStack_54 < (int)param_1[0xa7]) || ((int)param_1[0xaa] < iStack_54)) ||
       (iStack_38 < (int)param_1[0xa8])) ||
      ((((int)param_1[0xab] < iStack_38 || (iStack_34 < (int)param_1[0xa9])) ||
       (((int)param_1[0xac] < iStack_34 ||
        ((iStack_60 < (int)param_1[0xa7] || ((int)param_1[0xaa] < iStack_60)))))))) ||
     ((iStack_48 < (int)param_1[0xa8] ||
      ((((int)param_1[0xab] < iStack_48 || (iStack_2c < (int)param_1[0xa9])) ||
       ((int)param_1[0xac] < iStack_2c)))))) {
    iStack_1c = 0;
    ExceptionList = &pvStack_10;
    if (-1 < DAT_01d5b924) {
      do {
        iStack_14 = 0;
        do {
          iStack_18 = 0;
          do {
            piStack_20 = &iStack_ec;
            do {
              iStack_3c = param_2[2] + piStack_20[2] * iStack_18;
              iStack_70 = param_2[1] + piStack_20[1] * iStack_14;
              iStack_74 = *param_2 + *piStack_20 * iStack_1c;
              uStack_44 = CONCAT44(iStack_70,iStack_74);
              if ((((iStack_54 <= iStack_74) && (iStack_74 <= iStack_60)) &&
                  ((iStack_38 <= iStack_70 && ((iStack_70 <= iStack_48 && (iStack_34 <= iStack_3c)))
                   ))) && ((iStack_3c <= iStack_2c &&
                           (((((iStack_74 < (int)param_1[0xa7] || ((int)param_1[0xaa] < iStack_74))
                              || (iStack_70 < (int)param_1[0xa8])) ||
                             (((int)param_1[0xab] < iStack_70 || (iStack_3c < (int)param_1[0xa9]))))
                            || ((int)param_1[0xac] < iStack_3c)))))) {
                if (*(char *)(param_1[0x4a] + 0x1db8) == '\0') {
                  FUN_006d9080();
                  cVar2 = FUN_0071c520(param_1[0x4a],&uStack_44);
                  if (cVar2 != '\0') goto LAB_006e8b91;
                }
                FUN_006d9080();
                cVar2 = FUN_0071d790(param_1[0x4a],&uStack_44);
                if (cVar2 != '\0') {
                  param_1[0x59] = param_1[0x59] + 1;
                  iVar6 = FUN_006e2950(&uStack_44);
                  *(int *)(iVar6 + 0xc) = *(int *)(iVar6 + 0xc) + 1;
                  iVar6 = param_1[0x4a];
                  puVar14 = (undefined4 *)(iVar6 + 0x1dec);
                  if (*param_3 == '\0') {
                    puStack_68 = *(undefined4 **)(iVar6 + 0x196c);
                    puVar8 = *(undefined4 **)*puStack_68;
                    puStack_30 = puStack_68;
                    puStack_24 = puVar14;
                    if (puVar8 == (undefined4 *)0x0) {
                      puVar8 = (undefined4 *)FUN_00621d50();
                    }
                    else {
                      *(undefined4 *)*puStack_68 = *puVar8;
                    }
                    *puVar8 = puStack_30;
                    puVar14 = puVar8 + 1;
                    uStack_8 = 1;
                    puStack_30 = puVar14;
                    if (puVar14 == (undefined4 *)0x0) {
                      puVar14 = (undefined4 *)0x0;
                    }
                    else {
                      FUN_006b1a30(param_1[0x4a]);
                      *puVar14 = RBX::Network::Replicator::StreamJob::StreamTerrainItem::vftable;
                      puVar8[0xd] = param_1;
                      *(undefined8 *)(puVar8 + 0xe) = uStack_44;
                      puVar8[0x10] = iStack_3c;
                      *(undefined *)(puVar8 + 0x11) = 4;
                      puVar8[0x12] = 0xffffffff;
                    }
                  }
                  else {
                    puVar8 = *(undefined4 **)(iVar6 + 0x196c);
                    puVar7 = *(undefined4 **)*puVar8;
                    puStack_64 = puVar8;
                    puStack_30 = puVar14;
                    if (puVar7 == (undefined4 *)0x0) {
                      puVar7 = (undefined4 *)FUN_00621d50();
                    }
                    else {
                      *(undefined4 *)*puVar8 = *puVar7;
                    }
                    *puVar7 = puVar8;
                    puStack_24 = puVar7 + 1;
                    uStack_8 = 0;
                    if (puStack_24 == (undefined4 *)0x0) {
                      puVar14 = (undefined4 *)0x0;
                    }
                    else {
                      uVar1 = *param_4;
                      FUN_006b1a30(param_1[0x4a]);
                      *puStack_24 = RBX::Network::Replicator::StreamJob::StreamTerrainItem::vftable;
                      puStack_24[0xc] = param_1;
                      *(undefined8 *)(puStack_24 + 0xd) = uStack_44;
                      puStack_24[0xf] = iStack_3c;
                      *(undefined *)(puStack_24 + 0x10) = 5;
                      puStack_24[0x11] = uVar1;
                      puVar14 = puStack_24;
                    }
                  }
                  uStack_8 = 0xffffffff;
                  FUN_006b1f50(puVar14);
                }
              }
LAB_006e8b91:
              piStack_20 = piStack_20 + 3;
            } while (piStack_20 != (int *)&uStack_8c);
            iStack_18 = iStack_18 + 1;
          } while (iStack_18 <= iStack_28);
          iStack_14 = iStack_14 + 1;
        } while (iStack_14 <= iStack_28);
        iStack_1c = iStack_1c + 1;
      } while (iStack_1c <= iStack_28);
    }
    if (*param_3 == '\0') {
      param_1[0xa7] = (int)uStack_8c;
      param_1[0xa8] = uStack_8c._4_4_;
      param_1[0xa9] = iStack_84;
      param_1[0xaa] = iStack_80;
      *(ulonglong *)(param_1 + 0xab) = CONCAT44(iStack_78,iStack_7c);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9517 ; VA 0x006e8c10 ; FUN_006e8c10 */

void __thiscall FUN_006e8c10(int param_1,int param_2,short param_3)

{
  int iVar1;
  
  iVar1 = (int)param_3;
  *(int *)(param_1 + 0x160) = *(int *)(param_1 + 0x160) + param_2;
  *(int *)(param_1 + 0x19c) = iVar1;
  if (DAT_01eaf35c != '\0') {
    FUN_01677490(DAT_01eaf35c,"Received new client instance quota: %d, max region radius: %d",
                 *(undefined4 *)(param_1 + 0x160),iVar1,0);
  }
  if (*(char *)(*(int *)(*(int *)(param_1 + 0x128) + 0x1f70) + 0x59) != '\0') {
    FUN_0086f2f0(1,"Received new client instance quota: %d, max region radius: %d",
                 *(undefined4 *)(param_1 + 0x160),iVar1);
    if (iVar1 < *(int *)(param_1 + 0x1a4)) {
      FUN_0086f2f0(1,
                   "Client max region radius %d is less than server min region radius %d, using server min."
                   ,iVar1,*(int *)(param_1 + 0x1a4));
    }
  }
  return;
}



/* FUNCTION 9518 ; VA 0x006e8ca0 ; FUN_006e8ca0 */

undefined4 __thiscall FUN_006e8ca0(int param_1,double param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined *puVar3;
  char cVar4;
  undefined uVar5;
  char cVar6;
  int iVar7;
  undefined8 *puVar8;
  int *piVar9;
  undefined4 uVar10;
  double *pdVar11;
  int iVar12;
  undefined4 *puVar13;
  int iVar14;
  int *piVar15;
  uint uVar16;
  float10 fVar17;
  double dVar18;
  float fVar19;
  undefined8 uVar20;
  char *pcVar21;
  undefined1 *puVar22;
  undefined8 uVar23;
  undefined4 uStack_c0;
  char cStack_bc;
  int iStack_b4;
  undefined4 uStack_b0;
  undefined8 uStack_ac;
  undefined4 uStack_a0;
  int iStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  int iStack_90;
  undefined4 uStack_8c;
  undefined8 uStack_88;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  uint uStack_78;
  undefined4 uStack_74;
  undefined8 uStack_70;
  float fStack_68;
  double dStack_64;
  double dStack_5c;
  int iStack_54;
  uint uStack_50;
  undefined8 uStack_4c;
  int iStack_44;
  undefined8 uStack_40;
  float fStack_38;
  undefined8 uStack_34;
  undefined8 uStack_2c;
  double dStack_24;
  uint uStack_1c;
  undefined uStack_16;
  char cStack_15;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9997;
  pvStack_10 = ExceptionList;
  uStack_80 = 0;
  puStack_14 = &stack0xffffff10;
  if (*(char *)(param_1 + 0x1d4) == '\0') {
    return 1;
  }
  if (*(int *)(param_1 + 0x128) == 0) {
    return 0;
  }
  ExceptionList = &pvStack_10;
  iStack_9c = param_1;
  puVar3 = &stack0xffffff10;
  if ((DAT_01d5b970 != '\0') &&
     (ExceptionList = &pvStack_10, cVar4 = FUN_00618c40(), puVar3 = puStack_14, cVar4 == '\0')) {
    ExceptionList = pvStack_10;
    return 1;
  }
  puStack_14 = puVar3;
  iVar7 = (**(code **)(**(int **)(param_1 + 0x128) + 0xb4))();
  if (iVar7 == 0) {
    ExceptionList = pvStack_10;
    return 1;
  }
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaf2c8) &&
     (FUN_016f3809(), DAT_01eaf2c8 == -1)) {
    uVar23 = 0xffffffff018dfb90;
    uStack_8 = 0;
    puVar22 = &DAT_018c5904;
    uVar20 = FUN_0152dab0();
    DAT_01eaf2c4 = (undefined4)((ulonglong)uVar20 >> 0x20);
    DAT_01eaf2c0 = (uint)uVar20;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eaf2c8,puVar22,uVar23);
  }
  uStack_50 = DAT_01eaf2c0;
  uStack_78 = DAT_01eaf2c0;
  iStack_44 = DAT_01eaf2c4;
  uStack_74 = DAT_01eaf2c4;
  uStack_70 = (double)FUN_0152d930(DAT_01eaf2c0,DAT_01eaf2c4);
  uStack_8 = 1;
  FUN_0060efa0();
  uStack_40 = *(undefined8 *)(iVar7 + 0x194);
  fStack_38 = *(float *)(iVar7 + 0x19c);
  cStack_15 = '\0';
  cVar4 = FUN_01160820();
  if (((cVar4 == '\0') || (cVar4 = FUN_01160820(), cVar4 == '\0')) ||
     (cVar4 = FUN_01160820(), cVar4 == '\0')) {
LAB_006e8e83:
    iVar12 = FUN_00927e40();
    if (iVar12 != 0) {
      puVar8 = (undefined8 *)&uStack_c0;
      goto LAB_006e8e9b;
    }
  }
  else {
    uVar20 = *(undefined8 *)(iVar7 + 0x194);
    fStack_38 = *(float *)(iVar7 + 0x19c);
    uStack_40._0_4_ = (float)uVar20;
    if ((((NAN((float)uStack_40) || NAN(DAT_018c45c4)) != ((float)uStack_40 == DAT_018c45c4)) &&
        (uStack_40._4_4_ = (float)((ulonglong)uVar20 >> 0x20),
        (NAN(uStack_40._4_4_) || NAN(DAT_018c45c4)) != (uStack_40._4_4_ == DAT_018c45c4))) &&
       (uStack_40 = uVar20, (NAN(fStack_38) || NAN(DAT_018c45c4)) != (fStack_38 == DAT_018c45c4)))
    goto LAB_006e8e83;
    uStack_40._0_4_ = (float)*(undefined8 *)(iVar7 + 0x194);
    uStack_40._4_4_ = (float)((ulonglong)*(undefined8 *)(iVar7 + 0x194) >> 0x20);
    puVar8 = &uStack_40;
    fStack_38 = *(float *)(iVar7 + 0x19c) * DAT_018df584;
    uStack_40 = CONCAT44(uStack_40._4_4_ * DAT_018df584,(float)uStack_40 * DAT_018df584);
LAB_006e8e9b:
    FUN_006e84d0(puVar8,0);
    cStack_15 = '\x01';
  }
  piVar9 = (int *)FUN_00927d50();
  iVar12 = *piVar9;
  uStack_16 = iVar12 != 0;
  FUN_00550b30();
  uStack_4c = 0.0;
  uStack_8._0_1_ = 2;
  if (iVar12 == 0) {
    piVar9 = *(int **)(iVar7 + 100);
    iVar7 = FUN_009ba880();
    if (iVar7 == 0) {
      uVar5 = 0;
    }
    else {
      cVar4 = FUN_009b4a80();
      uStack_16 = cVar4 == '\0';
      uVar5 = uStack_16;
      if (DAT_01eaf208 != 0) {
        cVar4 = FUN_009b4a80();
        if (cVar4 == '\0') {
          uVar10 = (**(code **)(*piVar9 + 0xa8))();
          FUN_0060dcd0(&dStack_24,uVar10);
          uStack_1c = 1;
        }
        else {
          uStack_34._0_4_ = 0;
          uStack_34._4_4_ = 0;
          uStack_1c = 2;
        }
        FUN_005587e0();
        if ((uStack_1c & 2) != 0) {
          uStack_1c = uStack_1c & 0xfffffffd;
          FUN_00550b30();
        }
        uVar5 = uStack_16;
        if ((uStack_1c & 1) != 0) {
          FUN_00550b30();
          uVar5 = uStack_16;
        }
      }
    }
  }
  else {
    uVar5 = uStack_16;
    if (DAT_01eaf208 != 0) {
      FUN_00927d50();
      uStack_8._0_1_ = 3;
      cVar4 = FUN_006c7f70();
      if (cVar4 == '\0') {
        uStack_34._0_4_ = 0;
        uStack_34._4_4_ = 0;
        uStack_1c = 0x10;
      }
      else {
        puVar13 = (undefined4 *)FUN_00927d50();
        uStack_8._0_1_ = 4;
        iVar7 = FUN_0170d75d(*puVar13,0,&RBX::Instance::RTTI_Type_Descriptor,
                             &RBX::PartInstance::RTTI_Type_Descriptor,0);
        if (iVar7 == 0) {
          uStack_2c = 0.0;
          uStack_1c = 0xc;
        }
        else {
          iVar12 = puVar13[1];
          if (iVar12 != 0) {
            LOCK();
            *(int *)(iVar12 + 4) = *(int *)(iVar12 + 4) + 1;
            UNLOCK();
            iVar12 = puVar13[1];
          }
          uStack_1c = 0xc;
          uStack_2c = (double)CONCAT44(iVar12,iVar7);
        }
      }
      FUN_005587e0();
      if ((uStack_1c & 0x10) != 0) {
        uStack_1c = uStack_1c & 0xffffffef;
        FUN_00550b30();
      }
      if ((uStack_1c & 8) != 0) {
        uStack_1c = uStack_1c & 0xfffffff7;
        FUN_00550b30();
      }
      if ((uStack_1c & 4) != 0) {
        FUN_00550b30();
      }
      FUN_00550b30();
      uVar5 = uStack_16;
    }
  }
  *(undefined *)(param_1 + 0x1bc) = uVar5;
  if (DAT_01eaf208 != 0) {
    FUN_00557fc0();
    if (uStack_2c._4_4_ != (int *)0x0) {
      LOCK();
      uStack_2c._4_4_[2] = uStack_2c._4_4_[2] + 1;
      UNLOCK();
    }
    *(undefined4 *)(param_1 + 400) = (undefined4)uStack_2c;
    piVar9 = *(int **)(param_1 + 0x194);
    *(int **)(param_1 + 0x194) = uStack_2c._4_4_;
    piVar15 = uStack_2c._4_4_;
    if (piVar9 != (int *)0x0) {
      LOCK();
      iVar7 = piVar9[2] + -1;
      piVar9[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar9 + 4))();
      }
      piVar15 = uStack_2c._4_4_;
    }
    if (piVar15 != (int *)0x0) {
      LOCK();
      iVar7 = piVar15[1] + -1;
      piVar15[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar15)();
        LOCK();
        piVar9 = piVar15 + 2;
        iVar7 = *piVar9;
        *piVar9 = *piVar9 + -1;
        UNLOCK();
        if (iVar7 == 1) {
          (**(code **)(*piVar15 + 4))();
        }
      }
    }
  }
  FUN_00550b30();
  if (cStack_15 == '\0') {
    uStack_8 = 5;
    FUN_0152dda0(uStack_50,iStack_44,(undefined4)uStack_70,uStack_70._4_4_);
    ExceptionList = pvStack_10;
    return 1;
  }
  uStack_8 = 6;
  FUN_0152dda0(uStack_50,iStack_44,(undefined4)uStack_70,uStack_70._4_4_);
  iVar7 = *(int *)(param_1 + 0x128);
  uStack_8 = 7;
  pdVar11 = (double *)FUN_016827a0(&dStack_24);
  dVar18 = *(double *)(iVar7 + 0x688);
  uStack_70 = *pdVar11 - *(double *)(iVar7 + 0x668);
  if (((*(char **)(iVar7 + 0x6a0) == (char *)0x0) ||
      (uStack_34 = (double)CONCAT44(uStack_34._4_4_,(undefined4)uStack_34),
      **(char **)(iVar7 + 0x6a0) == '\0')) &&
     (uStack_34 = (double)CONCAT44(uStack_34._4_4_,(undefined4)uStack_34),
     dVar18 + dVar18 < uStack_70)) {
    dVar18 = uStack_70;
    uStack_34 = uStack_70;
  }
  if (dVar18 < DAT_018c0d60) {
    fVar17 = (float10)FUN_01725160((double)*(int *)(param_1 + 0x160) * param_2);
    uVar16 = (uint)fVar17;
    uStack_1c = uVar16;
    iVar7 = FUN_0061e980();
    uStack_50 = (uint)(((longlong)(iVar7 * DAT_01d5b8d8) * (longlong)DAT_01d59d80 & 0xffffffffU) /
                      100);
    if ((DAT_01d5b9c8 != '\0') && (uVar16 == 0)) {
      uVar16 = *(int *)(param_1 + 0x274) + *(int *)(param_1 + 0x25c) + *(int *)(param_1 + 0x28c);
      uStack_1c = uVar16;
    }
    if ((*(int *)(param_1 + 0x164) < (int)uVar16) &&
       ((uint)(*(int *)(param_1 + 0x168) * 7) < uStack_50)) {
      if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaf2d8)
      {
        FUN_016f3809();
        cVar4 = DAT_01d7ad48;
        if (DAT_01eaf2d8 == -1) {
          uStack_8 = CONCAT31(uStack_8._1_3_,8);
          uVar20 = FUN_0152dab0();
          if ((cVar4 != '\0') && (DAT_01d7ad40 != '\0')) {
            FUN_01532a30(uVar20);
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,7);
          DAT_01eaf2d0 = (int)uVar20;
          DAT_01eaf2d4 = (int)((ulonglong)uVar20 >> 0x20);
          FUN_016f37bf();
        }
      }
      cVar4 = DAT_01d7ad48;
      uStack_80 = DAT_01eaf2d0;
      uStack_98 = DAT_01eaf2d4;
      uVar20 = FUN_01532c80(DAT_01eaf2d0,DAT_01eaf2d4);
      uStack_c0 = (undefined4)((ulonglong)uVar20 >> 0x20);
      uStack_94 = (undefined4)uVar20;
      cStack_bc = cVar4;
      iStack_90 = *(int *)(param_1 + 0x164);
      uStack_8._0_1_ = 9;
      iStack_44 = 0;
      uStack_7c = uStack_c0;
      FUN_01682800();
      if (DAT_01eaf204 == 0) {
        fStack_68 = (float)(*(int *)(param_1 + 0x158) - (param_1 + 0x158));
        uStack_2c = DAT_018dbcc8 / (double)fStack_68 + uStack_34;
      }
      else {
        FUN_008f7870();
        iVar7 = FUN_008fba30();
        iVar12 = FUN_0151da90();
        uStack_2c = (((double)(iVar12 * DAT_01eaf204) +
                     (double)(&DAT_018c0d90)[-(iVar12 * DAT_01eaf204 >> 0x1f)]) * DAT_018e0008) /
                    (double)iVar7 + uStack_34;
      }
      uStack_70 = uStack_2c;
      dStack_64 = DAT_018e0008;
      if ((*(int *)(param_1 + 0x1d0) == 0) || (*(int *)(param_1 + 0x160) < 1)) {
        dStack_24 = DAT_018c0d70;
      }
      else {
        uVar10 = FUN_01675290();
        uStack_8._0_1_ = 10;
        uStack_4c = uStack_2c;
        uStack_a0 = uVar10;
        if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
            DAT_01eaf2e8) {
          FUN_016f3809();
          uStack_4c = uStack_2c;
          if (DAT_01eaf2e8 == -1) {
            uStack_8._0_1_ = 0xb;
            uVar20 = FUN_0152dab0();
            DAT_01eaf2e4 = (undefined4)((ulonglong)uVar20 >> 0x20);
            DAT_01eaf2e0 = (int)uVar20;
            uStack_8._0_1_ = 10;
            FUN_016f37bf();
          }
        }
        iStack_54 = DAT_01eaf2e0;
        iStack_b4 = DAT_01eaf2e0;
        uStack_8c = DAT_01eaf2e4;
        uStack_b0 = DAT_01eaf2e4;
        uStack_4c = uStack_2c;
        uStack_ac = FUN_0152d930(DAT_01eaf2e0,DAT_01eaf2e4);
        iVar7 = *(int *)(param_1 + 0x1a4);
        iVar12 = *(int *)(param_1 + 0x1a0);
        if (*(int *)(param_1 + 0x19c) <= *(int *)(param_1 + 0x1a0)) {
          iVar12 = *(int *)(param_1 + 0x19c);
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
        iVar14 = iVar7;
        if (iVar7 <= iVar12) {
          iVar14 = iVar12;
        }
        fVar19 = DAT_018ce2f8;
        if ((0 < iVar14 - iVar7) &&
           (fVar19 = (float)(*(int *)(param_1 + 0x198) - iVar7) / (float)(iVar14 - iVar7),
           fVar19 <= DAT_018ce2f0)) {
          fVar19 = DAT_018ce2f0;
        }
        iVar7 = **(int **)(param_1 + 0x1cc);
        fVar19 = ((float)DAT_01d5b904 * fVar19) / DAT_018ce320;
        fStack_68 = (float)(int)((float)(int)uStack_1c * fVar19);
        dStack_24 = DAT_018c0d70;
        dStack_64 = (double)fVar19 * (uStack_4c - uStack_34) * DAT_018c0d70 * dStack_64 + uStack_34;
        uStack_88 = uStack_ac;
        FUN_01682800();
        while (iVar7 != *(int *)(param_1 + 0x1cc)) {
          while( true ) {
            if ((((int)fStack_68 <= *(int *)(param_1 + 0x164)) || (dStack_64 < dStack_5c)) ||
               (uStack_50 <= (uint)(*(int *)(param_1 + 0x168) * 7))) goto LAB_006e95f7;
            iStack_44 = iStack_44 + 1;
            if (*(double *)(iVar7 + 0x68) <= dStack_5c && dStack_5c != *(double *)(iVar7 + 0x68))
            goto LAB_006e9599;
            cVar6 = FUN_006e47a0();
            if (cVar6 == '\0') break;
            pdVar11 = (double *)FUN_01682800();
            dStack_5c = *pdVar11;
          }
          if (*(double *)(iVar7 + 0x68) <= dStack_5c && dStack_5c != *(double *)(iVar7 + 0x68)) {
LAB_006e9599:
            cVar6 = FUN_0061f4d0();
            if ((cVar6 != '\0') && (*(int *)(iVar7 + 0x34) < DAT_01d5b924)) {
              cStack_15 = '\x01';
              FUN_006e8740();
            }
            FUN_006e45f0();
          }
          FUN_006e5000();
          piVar9 = (int *)FUN_006e5040((int)&uStack_4c + 4,iVar7);
          iVar7 = *piVar9;
        }
LAB_006e95f7:
        uStack_8._0_1_ = 0xd;
        FUN_0152dda0(iStack_54,uStack_8c,uStack_88);
        uStack_8._0_1_ = 0xe;
        FUN_01675290(uVar10);
        uStack_8._0_1_ = 9;
      }
      dVar18 = uStack_70;
      iVar7 = iStack_44;
      uVar16 = uStack_50;
      if (DAT_01d5b9c8 != '\0') {
        FUN_006e5540();
        FUN_006e5240();
        dStack_64 = dVar18;
        iVar7 = iStack_44;
        uVar16 = uStack_50;
        if (*(int *)(param_1 + 0x25c) != 0) {
          iVar7 = FUN_01674e20();
          uStack_4c = (double)CONCAT44(iVar7,(undefined4)uStack_4c);
          uStack_8._0_1_ = 0xf;
          if (iVar7 == 0) {
            puVar13 = (undefined4 *)0x0;
          }
          else {
            puVar13 = (undefined4 *)FUN_006e1de0();
          }
          iStack_54 = *(int *)(param_1 + 0x164);
          uStack_8._0_1_ = 9;
          while( true ) {
            if (*(int *)(param_1 + 0x25c) == 0) {
              iVar7 = 0;
            }
            else {
              iVar7 = *(int *)(*(int *)(param_1 + 0x268) + *(int *)(param_1 + 600) * 4);
            }
            if ((iVar7 == 0) || ((int)uStack_1c <= *(int *)(param_1 + 0x164))) break;
            pdVar11 = (double *)FUN_01682800();
            if (dStack_64 < *pdVar11) break;
            iVar7 = FUN_006e32f0(*(undefined4 *)(iVar7 + 8),puVar13);
            *(int *)(param_1 + 0x164) = *(int *)(param_1 + 0x164) + iVar7;
            FUN_006e5160();
          }
          if (iStack_54 < *(int *)(param_1 + 0x164)) {
            if (DAT_01eaf1fc != '\0') {
              FUN_01677520();
            }
            FUN_006b1f50();
            *(int *)(param_1 + 0x168) = *(int *)(param_1 + 0x168) + 1;
            iVar7 = iStack_44;
            uVar16 = uStack_50;
          }
          else {
            iVar7 = iStack_44;
            uVar16 = uStack_50;
            if (puVar13 != (undefined4 *)0x0) {
              (**(code **)*puVar13)();
              iVar7 = iStack_44;
              uVar16 = uStack_50;
            }
          }
        }
      }
      do {
        if ((int)uStack_1c <= *(int *)(param_1 + 0x164)) goto LAB_006e97f1;
        pdVar11 = (double *)FUN_01682800();
        if ((uStack_2c < *pdVar11) || (uVar16 <= (uint)(*(int *)(param_1 + 0x168) * 7)))
        goto LAB_006e97f1;
        iVar7 = iVar7 + 1;
        cVar6 = FUN_006e47a0();
      } while (cVar6 != '\0');
      if (DAT_01d5a508 != '\0') {
        iVar12 = *(int *)(param_1 + 0x1a0);
        if (*(int *)(param_1 + 0x19c) <= *(int *)(param_1 + 0x1a0)) {
          iVar12 = *(int *)(param_1 + 0x19c);
        }
        iVar14 = *(int *)(param_1 + 0x1a4);
        if (*(int *)(param_1 + 0x1a4) <= iVar12) {
          iVar14 = iVar12;
        }
        if (iVar14 <= *(int *)(param_1 + 0x198)) {
          *(undefined *)(*(int *)(param_1 + 0x128) + 0x18ed) = 1;
        }
      }
LAB_006e97f1:
      cVar6 = FUN_0061f4d0();
      if ((cVar6 != '\0') && (*(int *)(param_1 + 0x198) + -1 < DAT_01d5b924)) {
        iStack_54 = -1;
        cStack_15 = '\0';
        FUN_006e8740();
      }
      if (DAT_01d5b980 != '\0') {
        pdVar11 = (double *)FUN_01682800();
        dStack_5c = (*pdVar11 - uStack_34) * dStack_24;
        if (*(int *)(param_1 + 0x164) < (int)uStack_1c) {
          pdVar11 = (double *)FUN_01682800();
          if (*pdVar11 <= uStack_2c) {
            if ((uint)(*(int *)(param_1 + 0x168) * 7) < uVar16) {
              if (*(int *)(param_1 + 0x164) == 0) goto LAB_006e9b34;
              if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
                  DAT_01eaf328) {
                FUN_016f3809();
                if (DAT_01eaf328 == -1) {
                  uStack_8._0_1_ = 0x13;
                  uVar20 = FUN_0152da50();
                  DAT_01eaf324 = (undefined4)((ulonglong)uVar20 >> 0x20);
                  DAT_01eaf320 = (undefined4)uVar20;
                  uStack_8._0_1_ = 9;
                  FUN_016f37bf();
                }
              }
              FUN_0152d740();
              if (DAT_01eaf1fd == '\0') goto LAB_006e9b34;
              iVar12 = (**(code **)(**(int **)(param_1 + 0x128) + 0xb4))();
              if (iVar12 == 0) {
                dStack_24 = 0.0;
                uVar20 = 0;
              }
              else {
                (**(code **)(**(int **)(param_1 + 0x128) + 0xb4))();
                uVar20 = FUN_00928340();
              }
              uVar10 = *(undefined4 *)(param_1 + 0x164);
              pcVar21 = "All Regions Collected, Instances: %d, Time = %f, PlayerId %lld";
            }
            else {
              if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
                  DAT_01eaf318) {
                FUN_016f3809();
                if (DAT_01eaf318 == -1) {
                  uStack_8._0_1_ = 0x12;
                  uVar20 = FUN_0152da50();
                  DAT_01eaf314 = (undefined4)((ulonglong)uVar20 >> 0x20);
                  DAT_01eaf310 = (undefined4)uVar20;
                  uStack_8._0_1_ = 9;
                  FUN_016f37bf();
                }
              }
              FUN_0152d740();
              if (DAT_01eaf1fd == '\0') goto LAB_006e9b34;
              iVar12 = (**(code **)(**(int **)(param_1 + 0x128) + 0xb4))();
              if (iVar12 == 0) {
                dStack_24 = 0.0;
                uVar20 = 0;
              }
              else {
                (**(code **)(**(int **)(param_1 + 0x128) + 0xb4))();
                uVar20 = FUN_00928340();
              }
              uVar10 = *(undefined4 *)(param_1 + 0x164);
              pcVar21 = "Queue Size Limit Reached, Instances: %d, Time = %f, PlayerId %lld";
            }
          }
          else {
            if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
                DAT_01eaf308) {
              FUN_016f3809();
              if (DAT_01eaf308 == -1) {
                uStack_8._0_1_ = 0x11;
                uVar20 = FUN_0152da50();
                DAT_01eaf304 = (undefined4)((ulonglong)uVar20 >> 0x20);
                DAT_01eaf300 = (undefined4)uVar20;
                uStack_8._0_1_ = 9;
                FUN_016f37bf();
              }
            }
            FUN_0152d740();
            if (DAT_01eaf1fd == '\0') goto LAB_006e9b34;
            iVar12 = (**(code **)(**(int **)(param_1 + 0x128) + 0xb4))();
            if (iVar12 == 0) {
              dStack_24 = 0.0;
              uVar20 = 0;
            }
            else {
              (**(code **)(**(int **)(param_1 + 0x128) + 0xb4))();
              uVar20 = FUN_00928340();
            }
            uVar10 = *(undefined4 *)(param_1 + 0x164);
            pcVar21 = "Max Time Reached, Instances: %d, Time = %f, PlayerId %lld";
          }
          FUN_01677520(DAT_01eaf1fd,pcVar21,uVar10,dStack_5c,uVar20);
        }
        else {
          if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
              DAT_01eaf2f8) {
            FUN_016f3809();
            if (DAT_01eaf2f8 == -1) {
              uStack_8._0_1_ = 0x10;
              uVar20 = FUN_0152da50();
              DAT_01eaf2f4 = (undefined4)((ulonglong)uVar20 >> 0x20);
              DAT_01eaf2f0 = (undefined4)uVar20;
              uStack_8._0_1_ = 9;
              FUN_016f37bf();
            }
          }
          FUN_0152d740();
          if (DAT_01eaf1fd != '\0') {
            iVar12 = (**(code **)(**(int **)(param_1 + 0x128) + 0xb4))();
            if (iVar12 == 0) {
              dStack_24 = 0.0;
              uVar20 = 0;
            }
            else {
              (**(code **)(**(int **)(param_1 + 0x128) + 0xb4))();
              uVar20 = FUN_00928340();
            }
            FUN_01677520(DAT_01eaf1fd,
                         "Collected Max Instances, Instances: %d, Max: %d, Time = %f, PlayerId %lld"
                         ,*(undefined4 *)(param_1 + 0x164),uStack_1c,dStack_5c,uVar20);
          }
        }
      }
LAB_006e9b34:
      iVar12 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
      if (*(int *)(iVar12 + 0x34) < DAT_01eaf338) {
        FUN_016f3809();
        if (DAT_01eaf338 == -1) {
          uStack_8._0_1_ = 0x14;
          uVar20 = FUN_0152da50();
          DAT_01eaf334 = (undefined4)((ulonglong)uVar20 >> 0x20);
          DAT_01eaf330 = (undefined4)uVar20;
          uStack_8._0_1_ = 9;
          FUN_016f37bf();
        }
      }
      FUN_0152d760(DAT_01eaf330,DAT_01eaf334,"Collected Instances : %d (Wanted %d)",
                   *(int *)(param_1 + 0x164) - iStack_90,uStack_1c);
      if (*(int *)(iVar12 + 0x34) < DAT_01eaf348) {
        FUN_016f3809();
        if (DAT_01eaf348 == -1) {
          uStack_8._0_1_ = 0x15;
          uVar20 = FUN_0152da50();
          DAT_01eaf344 = (undefined4)((ulonglong)uVar20 >> 0x20);
          DAT_01eaf340 = (undefined4)uVar20;
          uStack_8._0_1_ = 9;
          FUN_016f37bf();
        }
      }
      FUN_0152d760(DAT_01eaf340,DAT_01eaf344,"Regions Scanned : %d",iVar7);
      uVar2 = uStack_80;
      uVar1 = uStack_94;
      uVar10 = uStack_98;
      uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
      FUN_0152dda0(uStack_80,uStack_98,uStack_94,uStack_7c);
      if (cVar4 == '\0') {
        ExceptionList = pvStack_10;
        return 1;
      }
      if (DAT_01d7ad40 == '\0') {
        ExceptionList = pvStack_10;
        return 1;
      }
      FUN_01532d10(uVar2,uVar10,uVar1,uStack_7c);
      ExceptionList = pvStack_10;
      return 1;
    }
  }
  if ((DAT_01d5b9b0 != '\0') && (*(int *)(param_1 + 0x1d0) != 0)) {
    FUN_006e46f0();
    ExceptionList = pvStack_10;
    return 1;
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 9519 ; VA 0x006e9c29 ; Catch@006e9c29 */

undefined4 Catch_006e9c29(void)

{
  char *pcVar1;
  char *pcVar2;
  int unaff_EBP;
  
  FUN_0062b370(0x106);
  pcVar1 = (char *)(**(code **)(**(int **)(unaff_EBP + -0xa0) + 4))();
  pcVar2 = "empty error string";
  if (pcVar1 != (char *)0x0) {
    pcVar2 = pcVar1;
  }
  FUN_0086f2f0(3,"Network Data stream: %s",pcVar2);
  return 0x6e9c6a;
}



/* FUNCTION 9520 ; VA 0x006e9f80 ; FUN_006e9f80 */

undefined4 __thiscall FUN_006e9f80(int param_1,undefined4 param_2)

{
  int iStack_8;
  
  iStack_8 = param_1;
  FUN_006b2070(param_2,0x14);
  FUN_006ae3b0(param_1 + 0x30);
  param_2 = *(undefined4 *)(param_1 + 0x3c);
  FUN_006a5c10(&param_2,&iStack_8,4);
  FUN_006ad5e0(&iStack_8,4);
  return 1;
}



/* FUNCTION 9521 ; VA 0x006e9fd0 ; FUN_006e9fd0 */

undefined4 __thiscall FUN_006e9fd0(int param_1,int param_2)

{
  double *pdVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  bool bVar5;
  uint uStack_c;
  undefined auStack_8 [4];
  
  if (*(char *)(param_1 + 0xc4) == '\0') {
    pdVar1 = (double *)FUN_016830f0();
    FUN_00617ea0(*pdVar1 - *(double *)(param_1 + 0x28));
    *(undefined *)(param_1 + 0xc4) = 1;
  }
  FUN_006b2070(param_2,0xd);
  iVar3 = *(int *)(param_1 + 0xbc);
  piVar4 = (int *)(iVar3 + 0x358);
  uStack_c = 0;
  if (*(int *)(param_1 + 0xb4) == *(int *)(iVar3 + 0x35c) + 1) {
    if ((*(int *)(param_1 + 0xb0) == *piVar4) &&
       (*(int *)(param_1 + 0xb8) == *(int *)(iVar3 + 0x360))) {
      uStack_c = 1;
    }
  }
  else if (*(int *)(param_1 + 0xb8) == *(int *)(iVar3 + 0x360) + 1) {
    if ((*(int *)(param_1 + 0xb0) == *piVar4) &&
       (*(int *)(param_1 + 0xb4) == *(int *)(iVar3 + 0x35c))) {
      uStack_c = 2;
    }
  }
  else if (((*(int *)(param_1 + 0xb0) == *piVar4 + 1) &&
           (*(int *)(param_1 + 0xb4) == *(int *)(iVar3 + 0x35c))) &&
          (uStack_c = 0, *(int *)(param_1 + 0xb8) == *(int *)(iVar3 + 0x360))) {
    uStack_c = 3;
  }
  auStack_8[0] = (uStack_c & 1) != 0;
  FUN_006ad5e0(auStack_8,1);
  auStack_8[0] = (uStack_c & 2) != 0;
  FUN_006ad5e0(auStack_8,1);
  if (uStack_c == 0) {
    FUN_006ae3b0();
  }
  *(undefined8 *)piVar4 = *(undefined8 *)(param_1 + 0xb0);
  *(undefined4 *)(iVar3 + 0x360) = *(undefined4 *)(param_1 + 0xb8);
  if (*(int *)(*(int *)(param_1 + 0xbc) + 0x1f0) < 1) {
    iVar3 = *(int *)(param_2 + 0x18);
    iVar2 = FUN_0061e980();
    iVar2 = iVar2 - iVar3;
  }
  else {
    iVar2 = (uint)DAT_01d6520c * 1000;
  }
  *(int *)(param_1 + 0x38) = iVar2;
  iVar3 = FUN_006c3940();
  *(int *)(param_1 + 0xc0) = iVar3;
  piVar4 = (int *)(*(int *)(param_1 + 0xbc) + 0x164);
  *piVar4 = *piVar4 - iVar3;
  iVar3 = *(int *)(param_1 + 0x34);
  bVar5 = iVar3 == 0;
  if (bVar5) {
    piVar4 = (int *)(*(int *)(param_1 + 0xbc) + 0x168);
    *piVar4 = *piVar4 + -1;
    iVar3 = *(int *)(param_1 + 0x34);
    bVar5 = iVar3 == 0;
  }
  return CONCAT31((int3)((uint)iVar3 >> 8),bVar5);
}



/* FUNCTION 9522 ; VA 0x006ea1f0 ; FUN_006ea1f0 */

undefined4 __thiscall FUN_006ea1f0(int param_1,undefined4 param_2)

{
  int iStack_8;
  
  iStack_8 = param_1;
  FUN_006b2070(param_2,0x18);
  FUN_006ae3b0(param_1 + 0x30);
  param_2 = *(undefined4 *)(param_1 + 0x3c);
  FUN_006a5c10(&param_2,&iStack_8,4);
  FUN_006ad5e0(&iStack_8,4);
  param_2 = *(undefined4 *)(param_1 + 0x40);
  FUN_006a5c10(&param_2,&iStack_8,4);
  FUN_006ad5e0(&iStack_8,4);
  return 1;
}



/* FUNCTION 9523 ; VA 0x006ea270 ; FUN_006ea270 */

undefined4 __thiscall FUN_006ea270(int param_1,undefined4 param_2)

{
  undefined auStack_14 [8];
  undefined8 uStack_c;
  
  FUN_006b2070(param_2,0x19);
  FUN_006ad640(param_1 + 0x30);
  uStack_c = *(undefined8 *)(param_1 + 0x40);
  FUN_006a5c10(&uStack_c,auStack_14,8);
  FUN_006ad5e0(auStack_14,8);
  param_2 = *(undefined4 *)(param_1 + 0x48);
  FUN_006a5c10(&param_2,(int)&uStack_c + 4,4);
  FUN_006ad5e0((int)&uStack_c + 4,4);
  return 1;
}



/* FUNCTION 9524 ; VA 0x006ea2f0 ; FUN_006ea2f0 */

undefined4 __fastcall FUN_006ea2f0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  int *piVar8;
  int *piStack_8;
  
  iVar7 = *(int *)(param_1 + 0x30) + 0x1f5 + (uint)*(byte *)(*(int *)(param_1 + 0x30) + 500);
  uVar4 = FUN_00ca2680(param_1 + 0x34);
  FUN_006e16e0(&piStack_8,uVar4,param_1 + 0x34,-(uint)(iVar7 != 0) & iVar7 + 1U);
  if ((piStack_8 == (int *)0x0) || (piStack_8[5] < 1)) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("invalid terrain streaming state");
  }
  iVar7 = piStack_8[5] + -1;
  piStack_8[5] = iVar7;
  if (iVar7 == 0) {
    piVar1 = *(int **)(param_1 + 0x30);
    piVar2 = (int *)*piStack_8;
    piVar3 = *(int **)(piVar1[0x82] + ((uint)piStack_8[1] % (uint)piVar1[0x7e]) * 4);
    for (piVar8 = (int *)*piVar3; uVar6 = (uint)piStack_8[1] % (uint)piVar1[0x7e],
        piVar8 != piStack_8; piVar8 = (int *)*piVar8) {
      piVar3 = piVar8;
    }
    do {
      piStack_8 = piVar1;
      *piVar3 = *piVar8;
      FUN_01674ea0(piVar8,0x18);
      piStack_8[0x7f] = piStack_8[0x7f] + -1;
      uVar5 = uVar6;
      if (*piVar3 == 0) {
LAB_006ea3c8:
        if (*(int **)(piStack_8[0x82] + uVar6 * 4) == piVar3) {
          *(undefined4 *)(piStack_8[0x82] + uVar6 * 4) = 0;
        }
      }
      else {
        uVar5 = *(uint *)(*piVar3 + 4) % (uint)piStack_8[0x7e];
        if (uVar6 != uVar5) {
          *(int **)(piStack_8[0x82] + uVar5 * 4) = piVar3;
          goto LAB_006ea3c8;
        }
      }
      piVar8 = (int *)*piVar3;
      uVar6 = uVar5;
      piVar1 = piStack_8;
    } while (piVar8 != piVar2);
  }
  piVar1 = (int *)(*(int *)(param_1 + 0x30) + 0x164);
  *piVar1 = *piVar1 + -1;
  if ((*(uint *)(*(int *)(param_1 + 0x10) + 0x380c) & 2) == 0) {
    piStack_8 = (int *)CONCAT31(piStack_8._1_3_,3);
    uVar4 = 0xffffffff;
  }
  else {
    piStack_8 = (int *)CONCAT31(piStack_8._1_3_,*(undefined *)(param_1 + 0x40));
    uVar4 = *(undefined4 *)(param_1 + 0x44);
  }
  FUN_0062cf10(param_1 + 0x34,piStack_8,uVar4);
  return 1;
}



/* FUNCTION 9525 ; VA 0x006ea440 ; FUN_006ea440 */

undefined4 * __thiscall FUN_006ea440(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = FUN_0088c960();
  *param_1 = uVar1;
  param_1[1] = 0;
  param_1[2] = *param_2;
  uVar1 = FUN_00630820();
  param_1[1] = uVar1;
  return param_1;
}



/* FUNCTION 9526 ; VA 0x006ea480 ; FUN_006ea480 */

undefined * __thiscall FUN_006ea480(undefined *param_1,undefined4 *param_2)

{
  char cVar1;
  char *pcVar2;
  undefined4 uVar3;
  char *pcVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  pcVar2 = (char *)*param_2;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  pcVar4 = pcVar2;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar2,(int)pcVar4 - (int)(pcVar2 + 1));
  uStack_8 = 0;
  uVar3 = FUN_0088c960();
  *(undefined4 *)(param_1 + 0x18) = uVar3;
  uVar3 = param_2[1];
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = uVar3;
  uVar3 = FUN_00630820();
  *(undefined4 *)(param_1 + 0x1c) = uVar3;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9527 ; VA 0x006ea510 ; FUN_006ea510 */

undefined * __thiscall FUN_006ea510(undefined *param_1,undefined4 *param_2)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  pcVar2 = (char *)*param_2;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  pcVar3 = pcVar2;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar2,(int)pcVar3 - (int)(pcVar2 + 1));
  uStack_8 = 0;
  uVar4 = FUN_008881d0();
  *(undefined4 *)(param_1 + 0x18) = uVar4;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x20) = param_2[1];
  *(undefined4 *)(param_1 + 0x24) = param_2[2];
  param_2[1] = 0;
  param_2[2] = 0;
  uVar4 = FUN_0058c000();
  *(undefined4 *)(param_1 + 0x1c) = uVar4;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9528 ; VA 0x006ea5d0 ; FUN_006ea5d0 */

int __thiscall
FUN_006ea5d0(int *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  int iVar9;
  undefined4 *puVar10;
  
  iVar1 = *param_1;
  iVar9 = (int)param_2 - iVar1 >> 3;
  iVar2 = param_1[1] - iVar1 >> 3;
  if (iVar2 == 0x1fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar3 = iVar2 + 1;
  uVar6 = param_1[2] - iVar1 >> 3;
  uVar4 = uVar3;
  if ((uVar6 <= 0x1fffffff - (uVar6 >> 1)) && (uVar4 = (uVar6 >> 1) + uVar6, uVar4 < uVar3)) {
    uVar4 = uVar3;
  }
  puVar5 = (undefined4 *)FUN_00578020(uVar4);
  puVar5[iVar9 * 2] = *param_3;
  puVar5[iVar9 * 2 + 1] = *param_4;
  puVar10 = (undefined4 *)param_1[1];
  puVar7 = (undefined4 *)*param_1;
  puVar8 = puVar5;
  if (param_2 == puVar10) {
    for (; puVar7 != puVar10; puVar7 = puVar7 + 2) {
      *puVar8 = *puVar7;
      puVar8[1] = puVar7[1];
      puVar8 = puVar8 + 2;
    }
  }
  else {
    if (puVar7 != param_2) {
      do {
        *puVar8 = *puVar7;
        puVar10 = puVar7 + 1;
        puVar7 = puVar7 + 2;
        puVar8[1] = *puVar10;
        puVar8 = puVar8 + 2;
      } while (puVar7 != param_2);
      puVar10 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar10) {
      puVar7 = puVar5 + iVar9 * 2 + 2;
      do {
        *puVar7 = *param_2;
        puVar8 = param_2 + 1;
        param_2 = param_2 + 2;
        puVar7[1] = *puVar8;
        puVar7 = puVar7 + 2;
      } while (param_2 != puVar10);
    }
  }
  FUN_00654980(puVar5,uVar3,uVar4);
  return *param_1 + iVar9 * 8;
}



/* FUNCTION 9529 ; VA 0x006ea6e0 ; FUN_006ea6e0 */

void FUN_006ea6e0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  
  fVar9 = (float)param_1[1];
  iVar4 = (int)param_3 - (int)param_1 >> 3;
  if (iVar4 < 0x29) {
    fVar7 = (float)param_2[1];
    fVar8 = fVar7;
    if ((fVar9 < fVar7) && (param_2 != param_1)) {
      uVar2 = *param_2;
      uVar3 = *param_1;
      param_2[1] = fVar9;
      *param_2 = uVar3;
      param_1[1] = fVar7;
      fVar8 = (float)param_2[1];
      *param_1 = uVar2;
      fVar9 = fVar7;
    }
    fVar7 = (float)param_3[1];
    if (fVar8 < fVar7) {
      if (param_3 != param_2) {
        uVar2 = *param_3;
        uVar3 = *param_2;
        param_3[1] = fVar8;
        *param_3 = uVar3;
        param_2[1] = fVar7;
        fVar9 = (float)param_1[1];
        *param_2 = uVar2;
        fVar8 = fVar7;
      }
      if ((fVar9 < fVar8) && (param_2 != param_1)) {
        uVar2 = *param_2;
        *param_2 = *param_1;
        param_2[1] = fVar9;
        *param_1 = uVar2;
        param_1[1] = fVar8;
        return;
      }
    }
  }
  else {
    iVar4 = iVar4 + 1 >> 3;
    fVar7 = (float)param_1[iVar4 * 2 + 1];
    puVar1 = param_1 + iVar4 * 2;
    puVar5 = param_1 + iVar4 * 4;
    fVar8 = fVar7;
    if ((fVar9 < fVar7) && (puVar1 != param_1)) {
      uVar2 = *puVar1;
      uVar3 = *param_1;
      puVar1[1] = fVar9;
      *puVar1 = uVar3;
      param_1[1] = fVar7;
      fVar8 = (float)puVar1[1];
      *param_1 = uVar2;
      fVar9 = fVar7;
    }
    fVar7 = (float)puVar5[1];
    if (fVar8 < fVar7) {
      if (puVar5 != puVar1) {
        uVar2 = *puVar5;
        uVar3 = *puVar1;
        puVar5[1] = fVar8;
        *puVar5 = uVar3;
        puVar1[1] = fVar7;
        fVar9 = (float)param_1[1];
        *puVar1 = uVar2;
        fVar8 = fVar7;
      }
      if ((fVar9 < fVar8) && (puVar1 != param_1)) {
        uVar2 = *puVar1;
        *puVar1 = *param_1;
        puVar1[1] = fVar9;
        *param_1 = uVar2;
        param_1[1] = fVar8;
      }
    }
    puVar6 = param_2 + iVar4 * -2;
    fVar9 = (float)param_2[1];
    fVar8 = (float)puVar6[1];
    puVar5 = param_2 + iVar4 * 2;
    fVar7 = fVar9;
    if ((fVar8 < fVar9) && (param_2 != puVar6)) {
      uVar2 = *puVar6;
      uVar3 = *param_2;
      param_2[1] = fVar8;
      *param_2 = uVar2;
      puVar6[1] = fVar9;
      fVar7 = (float)param_2[1];
      *puVar6 = uVar3;
      fVar8 = fVar9;
    }
    fVar9 = (float)puVar5[1];
    if (fVar7 < fVar9) {
      if (puVar5 != param_2) {
        uVar2 = *puVar5;
        param_2[iVar4 * 2] = *param_2;
        *param_2 = uVar2;
        param_2[iVar4 * 2 + 1] = fVar7;
        param_2[1] = fVar9;
        fVar8 = (float)puVar6[1];
        fVar7 = fVar9;
      }
      if ((fVar8 < fVar7) && (param_2 != puVar6)) {
        uVar2 = *param_2;
        *param_2 = *puVar6;
        param_2[1] = fVar8;
        *puVar6 = uVar2;
        puVar6[1] = fVar7;
      }
    }
    puVar5 = param_3 + iVar4 * -4;
    puVar6 = param_3 + iVar4 * -2;
    fVar8 = (float)puVar5[1];
    fVar9 = (float)puVar6[1];
    fVar7 = fVar9;
    if ((fVar8 < fVar9) && (puVar6 != puVar5)) {
      uVar2 = *puVar6;
      uVar3 = *puVar5;
      puVar6[1] = fVar8;
      *puVar6 = uVar3;
      puVar5[1] = fVar9;
      fVar7 = (float)puVar6[1];
      *puVar5 = uVar2;
      fVar8 = fVar9;
    }
    fVar9 = (float)param_3[1];
    if (fVar7 < fVar9) {
      if (param_3 != puVar6) {
        uVar2 = *param_3;
        *param_3 = *puVar6;
        *puVar6 = uVar2;
        param_3[1] = fVar7;
        puVar6[1] = fVar9;
        fVar8 = (float)puVar5[1];
        fVar7 = fVar9;
      }
      if ((fVar8 < fVar7) && (puVar6 != puVar5)) {
        uVar2 = *puVar6;
        *puVar6 = *puVar5;
        puVar6[1] = fVar8;
        *puVar5 = uVar2;
        puVar5[1] = fVar7;
      }
    }
    fVar9 = (float)param_2[1];
    fVar8 = (float)puVar1[1];
    fVar7 = fVar9;
    if ((fVar8 < fVar9) && (param_2 != puVar1)) {
      uVar2 = *param_2;
      uVar3 = *puVar1;
      param_2[1] = fVar8;
      *param_2 = uVar3;
      puVar1[1] = fVar9;
      fVar7 = (float)param_2[1];
      *puVar1 = uVar2;
      fVar8 = fVar9;
    }
    fVar9 = (float)puVar6[1];
    if (fVar7 < fVar9) {
      if (puVar6 != param_2) {
        uVar2 = *puVar6;
        uVar3 = *param_2;
        puVar6[1] = fVar7;
        *puVar6 = uVar3;
        param_2[1] = fVar9;
        fVar8 = (float)puVar1[1];
        *param_2 = uVar2;
        fVar7 = fVar9;
      }
      if ((fVar8 < fVar7) && (param_2 != puVar1)) {
        uVar2 = *param_2;
        *param_2 = *puVar1;
        param_2[1] = fVar8;
        *puVar1 = uVar2;
        puVar1[1] = fVar7;
      }
    }
  }
  return;
}



/* FUNCTION 9530 ; VA 0x006ea9b0 ; FUN_006ea9b0 */

void FUN_006ea9b0(uint *param_1,float *param_2,float *param_3,undefined4 param_4)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float *pfVar4;
  float *pfVar5;
  float *pfVar6;
  float *pfVar7;
  float *pfVar8;
  float *pfVar9;
  float *pfVar10;
  float *pfStack_8;
  
  pfVar8 = param_2 + ((int)param_3 - (int)param_2 >> 4) * 2;
  FUN_006ea6e0(param_2,pfVar8,param_3 + -2,param_4);
  pfVar5 = pfVar8 + 2;
  for (; param_2 < pfVar8; pfVar8 = pfVar8 + -2) {
    if ((pfVar8[1] < pfVar8[-1]) || (pfVar8[-1] < pfVar8[1])) break;
  }
  pfVar4 = pfVar5;
  pfStack_8 = pfVar5;
  pfVar6 = pfVar8;
  if (pfVar5 < param_3) {
    do {
      pfVar4 = pfVar5;
      pfStack_8 = pfVar5;
      if ((pfVar8[1] < pfVar5[1]) || (pfVar5[1] < pfVar8[1])) break;
      pfVar5 = pfVar5 + 2;
      pfVar4 = pfVar5;
      pfStack_8 = pfVar5;
    } while (pfVar5 < param_3);
  }
joined_r0x006eaa32:
  do {
    pfVar10 = pfVar4;
    if (param_3 <= pfVar5) {
LAB_006eaa82:
      pfVar9 = pfVar8;
      if (param_2 < pfVar6) {
        pfVar4 = pfVar6 + -1;
        do {
          fVar1 = *pfVar4;
          pfVar9 = pfVar8;
          pfVar5 = pfStack_8;
          if (fVar1 <= pfVar8[1]) {
            if (fVar1 < pfVar8[1]) break;
            pfVar9 = pfVar8 + -2;
            if (pfVar9 != pfVar4 + -1) {
              fVar3 = *pfVar9;
              fVar2 = pfVar8[-1];
              *pfVar9 = pfVar4[-1];
              pfVar4[-1] = fVar3;
              pfVar8[-1] = fVar1;
              *pfVar4 = fVar2;
            }
          }
          pfVar6 = pfVar6 + -2;
          pfVar4 = pfVar4 + -2;
          pfVar8 = pfVar9;
        } while (param_2 < pfVar6);
      }
      if (pfVar6 == param_2) {
        if (pfVar5 == param_3) {
          param_1[1] = (uint)pfVar10;
          *param_1 = (uint)pfVar9;
          return;
        }
        if ((pfVar10 != pfVar5) && (pfVar9 != pfVar10)) {
          fVar2 = *pfVar9;
          fVar1 = pfVar9[1];
          *pfVar9 = *pfVar10;
          pfVar9[1] = pfVar10[1];
          *pfVar10 = fVar2;
          pfVar10[1] = fVar1;
        }
        if (pfVar9 != pfVar5) {
          fVar2 = *pfVar9;
          fVar1 = pfVar9[1];
          *pfVar9 = *pfVar5;
          pfVar9[1] = pfVar5[1];
          *pfVar5 = fVar2;
          pfVar5[1] = fVar1;
        }
        pfVar5 = pfVar5 + 2;
        pfVar4 = pfVar10 + 2;
        pfStack_8 = pfVar5;
        pfVar8 = pfVar9 + 2;
      }
      else {
        pfVar7 = pfVar6 + -2;
        if (pfVar5 == param_3) {
          pfVar8 = pfVar9 + -2;
          if (pfVar7 != pfVar8) {
            fVar2 = *pfVar7;
            fVar1 = pfVar6[-1];
            *pfVar7 = *pfVar8;
            pfVar6[-1] = pfVar9[-1];
            *pfVar8 = fVar2;
            pfVar9[-1] = fVar1;
          }
          pfVar4 = pfVar10 + -2;
          pfVar6 = pfVar7;
          if (pfVar8 != pfVar4) {
            fVar2 = *pfVar8;
            fVar1 = pfVar9[-1];
            *pfVar8 = *pfVar4;
            pfVar9[-1] = pfVar10[-1];
            *pfVar4 = fVar2;
            pfVar10[-1] = fVar1;
          }
        }
        else {
          if (pfVar5 != pfVar7) {
            fVar2 = *pfVar5;
            fVar1 = pfVar5[1];
            *pfVar5 = *pfVar7;
            pfVar5[1] = pfVar6[-1];
            *pfVar7 = fVar2;
            pfVar6[-1] = fVar1;
          }
          pfVar5 = pfVar5 + 2;
          pfVar4 = pfVar10;
          pfStack_8 = pfVar5;
          pfVar8 = pfVar9;
          pfVar6 = pfVar7;
        }
      }
      goto joined_r0x006eaa32;
    }
    fVar1 = pfVar5[1];
    if (pfVar8[1] <= fVar1) {
      pfStack_8 = pfVar5;
      if (pfVar8[1] < fVar1) goto LAB_006eaa82;
      if (pfVar10 != pfVar5) {
        fVar3 = *pfVar10;
        fVar2 = pfVar10[1];
        *pfVar10 = *pfVar5;
        pfVar10[1] = fVar1;
        *pfVar5 = fVar3;
        pfVar5[1] = fVar2;
      }
      pfVar10 = pfVar10 + 2;
    }
    pfVar5 = pfVar5 + 2;
    pfVar4 = pfVar10;
    pfStack_8 = pfVar5;
  } while( true );
}



/* FUNCTION 9531 ; VA 0x006eabd0 ; FUN_006eabd0 */

void FUN_006eabd0(int param_1,int param_2,uint param_3,undefined4 *param_4)

{
  float *pfVar1;
  float fVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  iVar5 = (int)(param_3 - 1) >> 1;
  iVar4 = param_2;
  iVar3 = param_2;
  if (param_2 < iVar5) {
    do {
      fVar2 = *(float *)(param_1 + 0x14 + iVar4 * 0x10);
      pfVar1 = (float *)(param_1 + 0xc + iVar4 * 0x10);
      iVar3 = iVar4 * 2 + ((*pfVar1 <= fVar2 && fVar2 != *pfVar1) ^ 1) + 1;
      *(undefined4 *)(param_1 + iVar4 * 8) = *(undefined4 *)(param_1 + iVar3 * 8);
      *(undefined4 *)(param_1 + 4 + iVar4 * 8) = *(undefined4 *)(param_1 + 4 + iVar3 * 8);
      iVar4 = iVar3;
    } while (iVar3 < iVar5);
  }
  if ((iVar3 == iVar5) && ((param_3 & 1) == 0)) {
    *(undefined4 *)(param_1 + iVar3 * 8) = *(undefined4 *)(param_1 + -8 + param_3 * 8);
    *(undefined4 *)(param_1 + 4 + iVar3 * 8) = *(undefined4 *)(param_1 + -4 + param_3 * 8);
    iVar3 = param_3 - 1;
  }
  while ((param_2 < iVar3 &&
         (iVar4 = iVar3 + -1 >> 1, fVar2 = *(float *)(param_1 + 4 + iVar4 * 8),
         (float)param_4[1] <= fVar2 && fVar2 != (float)param_4[1]))) {
    *(undefined4 *)(param_1 + iVar3 * 8) = *(undefined4 *)(param_1 + iVar4 * 8);
    *(undefined4 *)(param_1 + 4 + iVar3 * 8) = *(undefined4 *)(param_1 + 4 + iVar4 * 8);
    iVar3 = iVar4;
  }
  *(undefined4 *)(param_1 + iVar3 * 8) = *param_4;
  *(undefined4 *)(param_1 + 4 + iVar3 * 8) = param_4[1];
  return;
}



/* FUNCTION 9532 ; VA 0x006eac80 ; FUN_006eac80 */

int __thiscall FUN_006eac80(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a99b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::Network::ClientReplicator::GCJob>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0xc) == 0 || (*(int *)(*(int *)(param_2 + 0xc) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 8) = param_2;
    piVar3 = *(int **)(param_2 + 0xc);
    *(int **)(param_2 + 0xc) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9533 ; VA 0x006ead54 ; Catch_All@006ead54 */

void Catch_All_006ead54(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9534 ; VA 0x006ead70 ; FUN_006ead70 */

int __thiscall FUN_006ead70(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a99c0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Network::ClientReplicator::ClientStatsItem*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9535 ; VA 0x006eae42 ; Catch_All@006eae42 */

void Catch_All_006eae42(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9536 ; VA 0x006eae60 ; FUN_006eae60 */

void FUN_006eae60(undefined4 *param_1,undefined4 *param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  float *pfVar2;
  undefined4 uVar3;
  float fVar4;
  bool bVar5;
  undefined4 *puVar6;
  int iVar7;
  int iVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  uint uVar11;
  int iVar12;
  undefined4 *puVar13;
  undefined4 *puVar14;
  int iVar15;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  undefined4 *puStack_10;
  undefined4 uStack_c;
  uint uStack_8;
  
  iVar7 = (int)param_2 - (int)param_1;
  puVar14 = param_2;
  do {
    iVar7 = iVar7 >> 3;
    if (iVar7 < 0x21) {
LAB_006eaee7:
      if ((1 < iVar7) && (puVar9 = param_1, param_1 != puVar14)) {
        while (puVar6 = puVar9 + 2, puVar6 != puVar14) {
          uVar3 = *puVar6;
          fVar4 = (float)puVar9[3];
          if (fVar4 < (float)param_1[1] || fVar4 == (float)param_1[1]) {
            puVar10 = puVar6;
            puVar13 = puVar6;
            if ((float)puVar9[1] <= fVar4 && fVar4 != (float)puVar9[1]) {
              do {
                puVar13 = puVar10 + -2;
                *puVar10 = *puVar13;
                puVar10[1] = puVar10[-1];
                pfVar2 = (float *)(puVar10 + -3);
                puVar10 = puVar13;
              } while (*pfVar2 <= fVar4 && fVar4 != *pfVar2);
            }
            *puVar13 = uVar3;
            puVar13[1] = fVar4;
            puVar9 = puVar6;
          }
          else {
            if (puVar6 != param_1) {
              puVar10 = puVar9 + 1;
              puVar9 = puVar9 + 4;
              do {
                puVar9[-2] = puVar10[-1];
                puVar9[-1] = *puVar10;
                puVar13 = puVar10 + -1;
                puVar10 = puVar10 + -2;
                puVar9 = puVar9 + -2;
              } while (puVar13 != param_1);
            }
            *param_1 = uVar3;
            param_1[1] = fVar4;
            puVar9 = puVar6;
          }
        }
      }
      return;
    }
    if (param_3 < 1) {
      if (0x20 < iVar7) {
        iVar7 = (int)puVar14 - (int)param_1;
        uVar11 = iVar7 >> 3;
        iVar15 = iVar7 >> 4;
        if (0 < iVar15) {
          iVar8 = (int)(uVar11 - 1) >> 1;
          puVar9 = param_1 + iVar15 * 2;
          do {
            uStack_c = puVar9[-2];
            puStack_10 = puVar9 + -2;
            iVar15 = iVar15 + -1;
            fVar4 = (float)puVar9[-1];
            iVar1 = iVar15;
            while (iVar1 < iVar8) {
              iVar12 = iVar1 * 2 +
                       (((float)param_1[iVar1 * 4 + 3] <= (float)param_1[iVar1 * 4 + 5] &&
                        (float)param_1[iVar1 * 4 + 5] != (float)param_1[iVar1 * 4 + 3]) ^ 1) + 1;
              param_1[iVar1 * 2] = param_1[iVar12 * 2];
              param_1[iVar1 * 2 + 1] = param_1[iVar12 * 2 + 1];
              iVar1 = iVar12;
            }
            if ((iVar1 == iVar8) && ((uVar11 & 1) == 0)) {
              param_1[iVar1 * 2] = param_1[uVar11 * 2 + -2];
              param_1[iVar1 * 2 + 1] = param_1[uVar11 * 2 + -1];
              iVar1 = uVar11 - 1;
            }
            while ((iVar15 < iVar1 &&
                   (iVar12 = iVar1 + -1 >> 1, fVar4 < (float)param_1[iVar12 * 2 + 1]))) {
              param_1[iVar1 * 2] = param_1[iVar12 * 2];
              param_1[iVar1 * 2 + 1] = param_1[iVar12 * 2 + 1];
              iVar1 = iVar12;
            }
            param_1[iVar1 * 2] = uStack_c;
            param_1[iVar1 * 2 + 1] = fVar4;
            puVar9 = puStack_10;
            puVar14 = param_2;
          } while (0 < iVar15);
        }
        uStack_8 = uVar11;
        if ((int)uVar11 < 2) {
          return;
        }
        do {
          puVar9 = puVar14 + -2;
          bVar5 = 1 < (int)uVar11;
          uVar11 = iVar7 + -8 >> 3;
          if (bVar5) {
            puStack_18 = (undefined4 *)*puVar9;
            puStack_14 = (undefined4 *)puVar14[-1];
            *puVar9 = *param_1;
            *(undefined4 *)(iVar7 + -4 + (int)param_1) = param_1[1];
            FUN_006eabd0(param_1,0,uVar11,&puStack_18,param_4);
          }
          puVar14 = puVar9;
          iVar7 = iVar7 + -8;
        } while (1 < (int)uVar11);
        return;
      }
      goto LAB_006eaee7;
    }
    FUN_006ea9b0(&puStack_18,param_1,puVar14,param_4);
    param_3 = (param_3 >> 1) + (param_3 >> 2);
    if ((int)((int)puStack_18 - (int)param_1 & 0xfffffff8U) <
        (int)((int)puVar14 - (int)puStack_14 & 0xfffffff8U)) {
      FUN_006eae60(param_1,puStack_18,param_3,param_4);
      param_1 = puStack_14;
    }
    else {
      FUN_006eae60(puStack_14,puVar14,param_3,param_4);
      param_2 = puStack_18;
      puVar14 = puStack_18;
    }
    iVar7 = (int)puVar14 - (int)param_1;
  } while( true );
}



/* FUNCTION 9537 ; VA 0x006eb0e0 ; FUN_006eb0e0 */

undefined4 * FUN_006eb0e0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a9a24;
  pvStack_10 = ExceptionList;
  uVar5 = 0;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_009fb200();
  uVar3 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar2 + 0x1dc) != (undefined4 *)0x0) {
    uVar3 = **(undefined4 **)(iVar2 + 0x1dc);
  }
  uVar3 = FUN_01675290(uVar3);
  uStack_8 = 1;
  uStack_20 = uVar3;
  puStack_1c = (undefined4 *)FUN_01674e20(0x218);
  if (puStack_1c == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    uStack_28 = *param_2;
    piStack_2c = (int *)param_2[1];
    *param_2 = 0;
    param_2[1] = 0;
    uVar5 = 1;
    uStack_14 = 1;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      piStack_2c[1] = piStack_2c[1] + 1;
      UNLOCK();
    }
    uStack_8 = 4;
    piStack_24 = piStack_2c;
    FUN_006fe020(&uStack_28);
    piStack_18 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[1] + -1;
      piStack_24[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar2 = piStack_18[2] + -1;
        piStack_18[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    *puStack_1c = RBX::Network::ClientReplicator::ClientStatsItem::vftable;
    puStack_1c[0x7c] = 0;
    puStack_1c[0x7d] = 0;
    puStack_1c[0x7e] = 0;
    puStack_1c[0x7f] = 0;
    puStack_1c[0x80] = 0;
    puStack_1c[0x81] = 0;
    puStack_1c[0x82] = 0;
    puStack_1c[0x83] = 0;
    puStack_1c[0x84] = 0;
    puStack_1c[0x85] = 0;
    puVar4 = puStack_1c;
  }
  uStack_8 = 5;
  *param_1 = 0;
  param_1[1] = 0;
  FUN_006ead70(puVar4,param_1);
  uStack_14 = uVar5 | 2;
  if ((uVar5 != 0) && (uStack_14 = 2, piStack_2c != (int *)0x0)) {
    LOCK();
    iVar2 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piStack_2c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  uStack_8 = 9;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9538 ; VA 0x006eb2c0 ; FUN_006eb2c0 */

int * __thiscall FUN_006eb2c0(byte *param_1,int *param_2,int param_3,int param_4,int *param_5)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  int *piVar9;
  uint uVar10;
  uint uVar11;
  undefined4 *puVar12;
  byte *pbVar13;
  int iStack_1c;
  byte *pbStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9a38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  pbStack_18 = param_1;
  uStack_14 = FUN_005702d0(param_3);
  FUN_009c91c0(&uStack_14,param_3 + 0x18);
  uVar8 = (uStack_14 >> 2) + 0x9e3779b9 + uStack_14 * 0x40 + *(int *)(param_3 + 0x1c) ^ uStack_14;
  uStack_14 = uVar8;
  FUN_006ebd40(&iStack_1c,uVar8,param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (iStack_1c == 0) {
    uStack_8 = 0;
    piVar9 = (int *)FUN_01674e20(0x40);
    *piVar9 = 0;
    piVar9[1] = 0;
    FUN_0170d1f0(piVar9 + 2,0,0x38);
    FUN_0054ef60(param_4);
    pbVar13 = pbStack_18;
    piVar9[8] = *(int *)(param_4 + 0x18);
    piVar9[9] = *(int *)(param_4 + 0x1c);
    iVar5 = param_5[1];
    iVar6 = param_5[2];
    iVar7 = param_5[3];
    piVar9[10] = *param_5;
    piVar9[0xb] = iVar5;
    piVar9[0xc] = iVar6;
    piVar9[0xd] = iVar7;
    *(undefined8 *)(piVar9 + 0xe) = *(undefined8 *)(param_5 + 4);
    uVar3 = *(uint *)(pbStack_18 + 8);
    uVar10 = uVar3 + 1;
    if (*(int *)(pbStack_18 + 0x14) == 0) {
      uVar10 = FUN_005c9310(uVar10);
      if (uVar10 <= *(uint *)(pbVar13 + 4)) {
        uVar10 = *(uint *)(pbVar13 + 4);
      }
      FUN_005d2b00(uVar10);
    }
    else if (*(uint *)(pbStack_18 + 0x10) < uVar10) {
      uVar11 = uVar3 >> 1;
      if (uVar3 + (uVar3 >> 1) <= uVar10) {
        uVar11 = 1;
      }
      uVar10 = FUN_005c9310(uVar11 + uVar3);
      puVar1 = (uint *)(pbVar13 + 4);
      if (uVar10 != *puVar1) {
        FUN_005d2b00(uVar10);
        puVar12 = (undefined4 *)(*(int *)(pbVar13 + 0x14) + *puVar1 * 4);
        puVar4 = (undefined4 *)*puVar12;
        while (puVar4 != (undefined4 *)0x0) {
          piVar2 = (int *)(*(int *)(pbStack_18 + 0x14) + ((uint)puVar4[1] % *puVar1) * 4);
          if (*(int *)(*(int *)(pbStack_18 + 0x14) + ((uint)puVar4[1] % *puVar1) * 4) == 0) {
            *piVar2 = (int)puVar12;
            puVar12 = puVar4;
          }
          else {
            *puVar12 = *puVar4;
            *puVar4 = *(undefined4 *)*piVar2;
            *(undefined4 **)*piVar2 = puVar4;
          }
          pbVar13 = pbStack_18;
          puVar4 = (undefined4 *)*puVar12;
        }
      }
    }
    piVar9[1] = uVar8;
    uVar10 = *(uint *)(pbVar13 + 4);
    iVar5 = *(int *)(pbVar13 + 0x14);
    puVar12 = (undefined4 *)(iVar5 + (uVar8 % uVar10) * 4);
    if (*(int *)(iVar5 + (uVar8 % uVar10) * 4) == 0) {
      piVar2 = (int *)(iVar5 + uVar10 * 4);
      if (*piVar2 != 0) {
        *(int **)(*(int *)(pbVar13 + 0x14) + (*(uint *)(*piVar2 + 4) % uVar10) * 4) = piVar9;
      }
      *puVar12 = piVar2;
      *piVar9 = *piVar2;
      *piVar2 = (int)piVar9;
    }
    else {
      *piVar9 = *(int *)*puVar12;
      *(int **)*puVar12 = piVar9;
    }
    *(int *)(pbVar13 + 8) = *(int *)(pbVar13 + 8) + 1;
    *param_2 = (int)piVar9;
    *(undefined *)(param_2 + 1) = 1;
    ExceptionList = pvStack_10;
    return param_2;
  }
  *param_2 = iStack_1c;
  *(undefined *)(param_2 + 1) = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9539 ; VA 0x006eb500 ; FUN_006eb500 */

void __thiscall FUN_006eb500(int param_1,undefined4 *param_2,undefined4 param_3,int param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  char cVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  undefined4 *puVar10;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9a60;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_005702d0(param_3);
  uVar5 = *(uint *)(param_1 + 4);
  uVar8 = uVar4 % uVar5;
  if (*(int *)(param_1 + 8) == 0) {
    piVar9 = (int *)0x0;
  }
  else {
    puVar10 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (puVar10 == (undefined4 *)0x0) {
      piVar9 = (int *)0x0;
    }
    else {
      piVar9 = (int *)*puVar10;
    }
    if (piVar9 == (int *)0x0) goto LAB_006eb5ae;
    do {
      if (uVar4 == piVar9[1]) {
        cVar3 = FUN_00558b30(param_3,piVar9 + 2);
        if (cVar3 != '\0') break;
        uVar5 = *(uint *)(param_1 + 4);
      }
      else if ((uint)piVar9[1] % uVar5 != uVar8) goto LAB_006eb5ae;
      piVar9 = (int *)*piVar9;
    } while (piVar9 != (int *)0x0);
  }
  if (piVar9 != (int *)0x0) {
    *param_2 = piVar9;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_006eb5ae:
  iStack_8 = 0;
  piVar9 = (int *)FUN_01674e20(0xf0);
  *piVar9 = 0;
  piVar9[1] = 0;
  FUN_0170d1f0(piVar9 + 2,0,0xe8);
  FUN_0054ef60(param_4);
  iStack_8._0_1_ = 1;
  FUN_005caf00(param_4 + 0x18);
  uVar8 = *(uint *)(param_1 + 8);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  uVar5 = uVar8 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar5 = FUN_005c9310(uVar5);
    if (uVar5 <= *(uint *)(param_1 + 4)) {
      uVar5 = *(uint *)(param_1 + 4);
    }
    FUN_005c6680(uVar5);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar5) {
    uVar7 = uVar8 >> 1;
    if (uVar8 + uVar7 <= uVar5) {
      uVar7 = 1;
    }
    iVar6 = FUN_005c9310(uVar7 + uVar8);
    if (iVar6 != *(int *)(param_1 + 4)) {
      FUN_005c6680(iVar6);
      puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)*puVar10;
      while (puVar1 != (undefined4 *)0x0) {
        uVar5 = (uint)puVar1[1] % *(uint *)(param_1 + 4);
        piVar2 = (int *)(*(int *)(param_1 + 0x14) + uVar5 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar5 * 4) == 0) {
          *piVar2 = (int)puVar10;
          puVar10 = puVar1;
        }
        else {
          *puVar10 = *puVar1;
          *puVar1 = *(undefined4 *)*piVar2;
          *(undefined4 **)*piVar2 = puVar1;
        }
        puVar1 = (undefined4 *)*puVar10;
      }
    }
  }
  piVar9[1] = uVar4;
  uVar4 = uVar4 % *(uint *)(param_1 + 4);
  piVar2 = *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  if (piVar2 == (int *)0x0) {
    piVar2 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar2 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar2 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar9;
    }
    *puVar10 = piVar2;
    *piVar9 = *piVar2;
    *piVar2 = (int)piVar9;
  }
  else {
    *piVar9 = *piVar2;
    *(int **)*puVar10 = piVar9;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = piVar9;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9540 ; VA 0x006eb730 ; FUN_006eb730 */

int * __thiscall FUN_006eb730(byte *param_1,int *param_2,uint *param_3,uint *param_4)

{
  uint *puVar1;
  int *piVar2;
  int *piVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  uint *puVar9;
  int *piVar10;
  uint uVar11;
  uint uVar12;
  undefined4 *puVar13;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar9 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9a78;
  pvStack_10 = ExceptionList;
  puVar1 = param_3 + 1;
  ExceptionList = &pvStack_10;
  param_3 = (uint *)*param_3;
  FUN_009c91c0(&param_3,puVar1);
  param_3 = (uint *)(((uint)param_3 >> 2) + 0x9e3779b9 + (int)param_3 * 0x40 + puVar9[2] ^
                    (uint)param_3);
  uStack_14 = (uint)param_3;
  FUN_00676f40(&iStack_18,param_3,puVar9,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (iStack_18 != 0) {
    *param_2 = iStack_18;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return param_2;
  }
  uStack_8 = 0;
  piVar10 = (int *)FUN_01674e20(0x30);
  *piVar10 = 0;
  piVar10[1] = 0;
  piVar10[2] = 0;
  piVar10[3] = 0;
  piVar10[4] = 0;
  piVar10[5] = 0;
  piVar10[6] = 0;
  piVar10[7] = 0;
  piVar10[8] = 0;
  piVar10[9] = 0;
  piVar10[10] = 0;
  piVar10[0xb] = 0;
  iVar6 = ((int *)param_4)[1];
  iVar7 = ((int *)param_4)[2];
  iVar8 = ((int *)param_4)[3];
  piVar10[2] = *param_4;
  piVar10[3] = iVar6;
  piVar10[4] = iVar7;
  piVar10[5] = iVar8;
  iVar6 = ((int *)param_4)[5];
  iVar7 = ((int *)param_4)[6];
  iVar8 = ((int *)param_4)[7];
  piVar10[6] = ((int *)param_4)[4];
  piVar10[7] = iVar6;
  piVar10[8] = iVar7;
  piVar10[9] = iVar8;
  *(undefined8 *)(piVar10 + 10) = *(undefined8 *)((int *)param_4 + 8);
  uVar4 = *(uint *)(param_1 + 8);
  uVar11 = uVar4 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar11 = FUN_005c9310(uVar11);
    if (uVar11 <= *(uint *)(param_1 + 4)) {
      uVar11 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar11);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar11) {
    param_4 = (uint *)0x1;
    uVar12 = uVar4 >> 1;
    if (uVar4 + (uVar4 >> 1) <= uVar11) {
      uVar12 = 1;
    }
    uVar11 = FUN_005c9310(uVar12 + *(int *)(param_1 + 8));
    param_4 = (uint *)(param_1 + 4);
    if (uVar11 != *param_4) {
      FUN_005d2b00(uVar11);
      puVar13 = (undefined4 *)(*(int *)(param_1 + 0x14) + *param_4 * 4);
      puVar5 = (undefined4 *)*puVar13;
      while (puVar5 != (undefined4 *)0x0) {
        piVar2 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar5[1] % *param_4) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar5[1] % *param_4) * 4) == 0) {
          *piVar2 = (int)puVar13;
          puVar13 = puVar5;
        }
        else {
          *puVar13 = *puVar5;
          *puVar5 = *(undefined4 *)*piVar2;
          *(undefined4 **)*piVar2 = puVar5;
        }
        puVar5 = (undefined4 *)*puVar13;
      }
    }
  }
  piVar10[1] = uStack_14;
  uVar11 = *(uint *)(param_1 + 4);
  piVar2 = (int *)(*(int *)(param_1 + 0x14) + (uStack_14 % uVar11) * 4);
  if ((int *)*piVar2 == (int *)0x0) {
    piVar3 = (int *)(*(int *)(param_1 + 0x14) + uVar11 * 4);
    if (*piVar3 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar3 + 4) % uVar11) * 4) = piVar10;
    }
    *piVar2 = (int)piVar3;
    *piVar10 = *piVar3;
    *piVar3 = (int)piVar10;
  }
  else {
    *piVar10 = *(int *)*piVar2;
    *(int **)*piVar2 = piVar10;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = (int)piVar10;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9541 ; VA 0x006eb960 ; FUN_006eb960 */

int __fastcall FUN_006eb960(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_005edc10();
  iVar3 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar3 = param_1;
  }
  return iVar3;
}



/* FUNCTION 9542 ; VA 0x006eb990 ; FUN_006eb990 */

void FUN_006eb990(int *param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  uint uVar5;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a9ab9;
  pvStack_10 = ExceptionList;
  piStack_14 = (int *)(*(int *)(param_2 + 0x14) + *(int *)(param_2 + 4) * 4);
  ExceptionList = &pvStack_10;
  if (param_1 != (int *)0x0) {
    do {
      uStack_8 = 0xffffffff;
      if (*(int *)(param_3 + 4) == 0) {
        *(undefined2 *)(param_3 + 8) = 0;
        puVar4 = (undefined4 *)FUN_01674e20(100);
        *(undefined4 **)(param_3 + 4) = puVar4;
        *puVar4 = 0;
        puVar4[1] = 0;
        FUN_0170d1f0(puVar4 + 2,0,0x5c);
        *(undefined *)(param_3 + 8) = 1;
      }
      else if (*(char *)(param_3 + 9) != '\0') {
        FUN_00613010();
        *(undefined *)(param_3 + 9) = 0;
      }
      iVar2 = *(int *)(param_3 + 4);
      *(int *)(iVar2 + 8) = param_1[2];
      *(undefined4 *)(iVar2 + 0xc) = RBX::Network::DeserializedItem::vftable;
      *(int *)(iVar2 + 0x10) = param_1[4];
      *(int *)(iVar2 + 0x14) = param_1[5];
      *(int *)(iVar2 + 0x18) = param_1[6];
      uStack_8 = 0;
      *(undefined4 *)(iVar2 + 0xc) = RBX::Network::DeserializedNewInstanceItem::vftable;
      FUN_0060eaf0(param_1 + 7);
      *(int *)(iVar2 + 0x28) = param_1[10];
      *(int *)(iVar2 + 0x2c) = param_1[0xb];
      *(int *)(iVar2 + 0x30) = param_1[0xc];
      *(int *)(iVar2 + 0x34) = param_1[0xd];
      *(int *)(iVar2 + 0x38) = param_1[0xe];
      *(int *)(iVar2 + 0x3c) = param_1[0xf];
      *(int *)(iVar2 + 0x40) = param_1[0x10];
      *(undefined4 *)(iVar2 + 0x44) = 0;
      *(undefined4 *)(iVar2 + 0x48) = 0;
      if (param_1[0x12] != 0) {
        LOCK();
        piVar1 = (int *)(param_1[0x12] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      *(int *)(iVar2 + 0x44) = param_1[0x11];
      *(int *)(iVar2 + 0x48) = param_1[0x12];
      *(undefined4 *)(iVar2 + 0x4c) = 0;
      *(undefined4 *)(iVar2 + 0x50) = 0;
      if (param_1[0x14] != 0) {
        LOCK();
        piVar1 = (int *)(param_1[0x14] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      *(int *)(iVar2 + 0x4c) = param_1[0x13];
      *(int *)(iVar2 + 0x50) = param_1[0x14];
      *(undefined *)(iVar2 + 0x54) = *(undefined *)(param_1 + 0x15);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      *(undefined *)(iVar2 + 0x55) = *(undefined *)((int)param_1 + 0x55);
      FUN_0060ea20(param_1 + 0x16);
      *(undefined *)(param_3 + 9) = 1;
      iVar2 = *(int *)(param_3 + 4);
      *(undefined4 *)(param_3 + 4) = 0;
      *(int *)(iVar2 + 4) = param_1[1];
      *piStack_14 = iVar2;
      *(int *)(param_2 + 8) = *(int *)(param_2 + 8) + 1;
      param_1 = (int *)*param_1;
      piVar3 = (int *)*piStack_14;
      uVar5 = (uint)piVar3[1] % *(uint *)(param_2 + 4);
      piVar1 = (int *)(*(int *)(param_2 + 0x14) + uVar5 * 4);
      if (*(int *)(*(int *)(param_2 + 0x14) + uVar5 * 4) == 0) {
        *piVar1 = (int)piStack_14;
        piStack_14 = piVar3;
      }
      else {
        *piStack_14 = *piVar3;
        *piVar3 = *(int *)*piVar1;
        *(int **)*piVar1 = piVar3;
      }
    } while (param_1 != (int *)0x0);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9543 ; VA 0x006ebb70 ; FUN_006ebb70 */

int FUN_006ebb70(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ead5f8,&LAB_006340d0);
  uVar3 = FUN_006352d0();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00b8c410();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return *piVar4;
  }
  return *piVar4;
}



/* FUNCTION 9544 ; VA 0x006ebc30 ; FUN_006ebc30 */

int FUN_006ebc30(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01ead5f8,&LAB_006340d0);
      uVar3 = FUN_006352d0();
      piVar4 = (int *)FUN_008aa140(uVar3);
      if (*piVar4 == 0) {
        uVar3 = FUN_00b8c410();
        piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar4 = iVar1;
        piVar5 = (int *)piVar4[1];
        piVar4[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_8[1] + -1;
          piStack_8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar5 = piStack_8 + 2;
            iVar1 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      return *piVar4;
    }
  }
  return 0;
}



/* FUNCTION 9545 ; VA 0x006ebd40 ; FUN_006ebd40 */

void __thiscall FUN_006ebd40(int param_1,undefined4 *param_2,uint param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  char cVar2;
  uint uVar3;
  int *piVar4;
  
  uVar3 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar4 = (int *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
    if (puVar1 == (undefined4 *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      piVar4 = (int *)*puVar1;
    }
    if (piVar4 != (int *)0x0) {
      do {
        if (param_3 == piVar4[1]) {
          cVar2 = FUN_009c8f50(piVar4 + 8);
          if ((cVar2 != '\0') && (cVar2 = FUN_00558b30(param_4,piVar4 + 2), cVar2 != '\0')) break;
        }
        else if ((uint)piVar4[1] % *(uint *)(param_1 + 4) != uVar3) {
          *param_2 = 0;
          return;
        }
        piVar4 = (int *)*piVar4;
        if (piVar4 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar4;
  return;
}



/* FUNCTION 9546 ; VA 0x006ebdf0 ; FUN_006ebdf0 */

undefined4 * FUN_006ebdf0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  bool bVar4;
  bool bVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  int *piVar9;
  undefined auStack_24 [12];
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if (param_2 == 0) {
    puVar8 = &uStack_10;
    piStack_c = (int *)0x0;
    bVar5 = false;
    bVar4 = false;
    bVar3 = true;
    uVar7 = 0;
    piVar9 = (int *)0x0;
LAB_006ebe68:
    *puVar8 = 0;
    *param_1 = uVar7;
    param_1[1] = puVar8[1];
    puVar8[1] = 0;
    if ((bVar3) && (piStack_c != (int *)0x0)) {
      LOCK();
      iVar2 = piStack_c[1] + -1;
      piStack_c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        iVar2 = piStack_c[2] + -1;
        piStack_c[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_c + 4))();
        }
      }
    }
    if ((bVar4) && (piStack_14 != (int *)0x0)) {
      LOCK();
      iVar2 = piStack_14[1] + -1;
      piStack_14[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        iVar2 = piStack_14[2] + -1;
        piStack_14[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    if ((bVar5) && (piVar9 != (int *)0x0)) {
      LOCK();
      iVar2 = piVar9[1] + -1;
      piVar9[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar9)();
        LOCK();
        piVar1 = piVar9 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar9 + 4))();
        }
      }
    }
    return param_1;
  }
  iVar2 = *(int *)(param_2 + 8);
  if (iVar2 != 0) {
    piVar9 = (int *)(iVar2 + 4);
    iVar2 = *(int *)(iVar2 + 4);
    while (iVar2 != 0) {
      LOCK();
      iVar6 = *piVar9;
      if (iVar2 == iVar6) {
        *piVar9 = iVar2 + 1;
        iVar6 = iVar2;
      }
      UNLOCK();
      if (iVar6 == iVar2) {
        piVar9 = *(int **)(param_2 + 8);
        uVar7 = *(undefined4 *)(param_2 + 4);
        if (piVar9 != (int *)0x0) {
          LOCK();
          piVar9[1] = piVar9[1] + 1;
          UNLOCK();
        }
        piStack_14 = piVar9;
        puVar8 = &uStack_18;
        bVar5 = true;
        bVar4 = true;
        bVar3 = false;
        goto LAB_006ebe68;
      }
      iVar2 = *piVar9;
    }
  }
  FUN_005c47d0();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_24,&DAT_01c21d80);
}



/* FUNCTION 9547 ; VA 0x006ebf30 ; FUN_006ebf30 */

void * __thiscall FUN_006ebf30(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  void *pvVar7;
  int *piVar8;
  int *piVar9;
  undefined4 *puVar10;
  int *piVar11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a9ae0;
  puVar10 = *(undefined4 **)(param_1 + 0x2c);
  pvVar7 = ExceptionList;
  if (puVar10 != (undefined4 *)0x0) {
    piVar9 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar9 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar9[1] = piVar9[1] + 1;
      UNLOCK();
      piVar9 = *(int **)(param_1 + 0x30);
      puVar10 = *(undefined4 **)(param_1 + 0x2c);
    }
    piVar1 = (int *)puVar10[1];
    piVar11 = (int *)*puVar10;
    iStack_8 = 0;
    pvVar7 = pvStack_10;
    for (; piVar11 != piVar1; piVar11 = piVar11 + 2) {
      iVar2 = *piVar11;
      if ((iVar2 != 0) &&
         (iVar3 = *(int *)(iVar2 + 0xc), iVar4 = FUN_00c391f0(),
         (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
         (uint)*(ushort *)(iVar4 + 0x1da))) {
        iVar3 = *param_2;
        iVar4 = param_2[3];
        iVar5 = FUN_00c3c010();
        if (iVar5 == iVar4) {
          piVar8 = &DAT_02134d38;
        }
        else {
          iVar5 = FUN_00c3c020();
          if (iVar5 != iVar4) goto LAB_006ec025;
          piVar8 = &DAT_02134d74;
        }
        piVar6 = (int *)(iVar3 + 0x98);
        iVar4 = *piVar6;
        *piVar6 = iVar2;
        iStack_8._0_1_ = 1;
        (**(code **)(*piVar8 + 0x48))(iVar2,0);
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        *(int *)(iVar3 + 0x98) = iVar4;
      }
LAB_006ec025:
      pvVar7 = (void *)FUN_006ebf30(param_2);
    }
    if (piVar9 != (int *)0x0) {
      LOCK();
      piVar1 = piVar9 + 1;
      iVar2 = *piVar1;
      pvVar7 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar7 = (void *)(**(code **)*piVar9)();
        LOCK();
        piVar1 = piVar9 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar7 = (void *)(**(code **)(*piVar9 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar7;
}



/* FUNCTION 9548 ; VA 0x006ec080 ; FUN_006ec080 */

void * __thiscall FUN_006ec080(int param_1,undefined4 param_2)

{
  int iVar1;
  int *piVar2;
  void *pvVar3;
  int *piVar4;
  int *piVar5;
  undefined4 *puVar6;
  int *piVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a0698;
  puVar6 = *(undefined4 **)(param_1 + 0x2c);
  pvVar3 = ExceptionList;
  if (puVar6 != (undefined4 *)0x0) {
    piVar5 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar5 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
      piVar5 = *(int **)(param_1 + 0x30);
      puVar6 = *(undefined4 **)(param_1 + 0x2c);
    }
    piVar2 = (int *)puVar6[1];
    piVar7 = (int *)*puVar6;
    uStack_8 = 0;
    pvVar3 = pvStack_10;
    for (; piVar7 != piVar2; piVar7 = piVar7 + 2) {
      piVar4 = (int *)(-(uint)(*piVar7 != 0) & *piVar7 + 0x14U);
      if (*piVar4 != 0) {
        FUN_00631de0(piVar4);
      }
      pvVar3 = (void *)FUN_006ec080(param_2);
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar2 = piVar5 + 1;
      iVar1 = *piVar2;
      pvVar3 = (void *)*piVar2;
      *piVar2 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        pvVar3 = (void *)(**(code **)*piVar5)();
        LOCK();
        piVar2 = piVar5 + 2;
        iVar1 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          pvVar3 = (void *)(**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar3;
}



/* FUNCTION 9549 ; VA 0x006ec150 ; FUN_006ec150 */

/* WARNING: Removing unreachable block (ram,0x006ec2bf) */
/* WARNING: Removing unreachable block (ram,0x006ec30b) */
/* WARNING: Removing unreachable block (ram,0x006ec306) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * __thiscall FUN_006ec150(undefined *param_1,undefined *param_2)

{
  int iVar1;
  int iVar2;
  undefined **ppuVar3;
  int iVar4;
  undefined4 uVar5;
  undefined **ppuVar6;
  uint uVar7;
  float10 fVar8;
  uint uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar2 = (int)param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9b08;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_18 = ((double)*(int *)((int)param_2 + 8) +
              (double)(&DAT_018c0d90)[-(*(int *)((int)param_2 + 8) >> 0x1f)]) /
              (double)*(float *)((int)param_2 + 0xc);
  fVar8 = (float10)FUN_01725280(uStack_18);
  uStack_18 = (double)fVar8;
  if (uStack_18 + DAT_018c0d60 < _DAT_018c4e98) {
    param_2 = (undefined *)FUN_016f3eb1();
  }
  else {
    param_2 = (undefined *)0xffffffff;
  }
  ppuVar3 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2);
  ppuVar6 = ppuVar3 + -1;
  if (ppuVar3 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar6 = ppuVar3;
  }
  param_2 = *ppuVar6;
  *(undefined **)(param_1 + 4) = param_2;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)(iVar2 + 0xc);
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  if (*(int *)(iVar2 + 8) != 0) {
    uStack_8 = 1;
    uStack_18 = (double)((ulonglong)uStack_18 & 0xffffffff);
    FUN_005c24c0((int)&uStack_18 + 4,param_2 + 1);
    if (*(int *)(param_1 + 0x14) != 0) {
      *(undefined4 *)((int)param_2 * 4) =
           *(undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      uVar7 = *(int *)(param_1 + 4) * 4 + 4;
      iVar1 = *(int *)(param_1 + 0x14);
      iVar4 = iVar1;
      if (0xfff < uVar7) {
        iVar4 = *(int *)(iVar1 + -4);
        uVar7 = *(int *)(param_1 + 4) * 4 + 0x27;
        if (0x1f < (iVar1 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar7);
    }
    *(undefined **)(param_1 + 4) = param_2;
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    uStack_18 = (double)((ulonglong)uStack_18 & 0xffff000000000000);
    uStack_1c = -(uint)(param_1 != (undefined *)0xfffffffd) & (uint)(param_1 + 4);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (*(int *)(iVar2 + 8) == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = *(undefined4 *)(*(int *)(iVar2 + 0x14) + *(int *)(iVar2 + 4) * 4);
    }
    FUN_006eb990(uVar5,param_1,&uStack_1c);
    iVar2 = (int)uStack_18;
    if ((int)uStack_18 != 0) {
      if (uStack_18._5_1_ != '\0') {
        FUN_00613010();
      }
      FUN_01674ea0(iVar2,100);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9550 ; VA 0x006ec390 ; FUN_006ec390 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall
FUN_006ec390(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,int *param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15)

{
  int iVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined uVar8;
  undefined4 uVar9;
  undefined **ppuVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  int *piVar13;
  undefined **ppuVar14;
  uint uVar15;
  uint uVar16;
  undefined4 in_stack_0000005c;
  int *in_stack_00000060;
  undefined4 in_stack_ffffffb4;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a9bdd;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_12 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_12[1] = param_12[1] + 1;
    UNLOCK();
  }
  puStack_14 = param_1;
  FUN_0060f2e0(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11,
               param_12,in_stack_ffffffb4,param_14,param_15,in_stack_0000005c,1,in_stack_00000060);
  uStack_8._0_1_ = 1;
  *param_1 = RBX::Described<class_RBX::Network::ClientReplicator,class_RBX::Network::Replicator>::
             vftable;
  param_1[0x17] =
       RBX::Described<class_RBX::Network::ClientReplicator,class_RBX::Network::Replicator>::vftable;
  param_1[0x19] =
       RBX::Described<class_RBX::Network::ClientReplicator,class_RBX::Network::Replicator>::vftable;
  param_1[0x1a] =
       RBX::Described<class_RBX::Network::ClientReplicator,class_RBX::Network::Replicator>::vftable;
  uVar9 = FUN_005edd10();
  param_1[3] = uVar9;
  *param_1 = RBX::Network::ClientReplicator::vftable;
  param_1[0x17] = RBX::Network::ClientReplicator::vftable;
  param_1[0x19] = RBX::Network::ClientReplicator::vftable;
  param_1[0x1a] = RBX::Network::ClientReplicator::vftable;
  *(undefined8 *)(param_1 + 0xec0) = DAT_018cf100;
  *(undefined *)(param_1 + 0xec2) = 0;
  in_stack_00000060 = (int *)0xb;
  ppuVar10 = (undefined **)
             FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&stack0x00000060);
  ppuVar14 = ppuVar10 + -1;
  if (ppuVar10 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar14 = ppuVar10;
  }
  param_1[0xec3] = *ppuVar14;
  param_1[0xec4] = 0;
  param_1[0xec5] = 0x3f800000;
  param_1[0xec6] = 0;
  param_1[0xec7] = 0;
  puVar12 = param_1 + 0xec8;
  uStack_8._0_1_ = 3;
  *puVar12 = 0;
  param_1[0xec9] = 0;
  param_1[0xeca] = 0;
  param_1[0xecb] = 0;
  param_1[0xecc] = 0;
  in_stack_00000060 = puVar12;
  puVar11 = (undefined4 *)FUN_01674e20(8);
  puVar7 = puStack_14;
  *puVar12 = puVar11;
  *puVar11 = 0;
  puVar11[1] = 0;
  *(undefined4 **)*puVar12 = puVar12;
  param_1[0xecd] = 0;
  param_1[0xed0] = 0;
  *(undefined8 *)(puStack_14 + 0xed2) = DAT_018cf100;
  *(undefined *)(puStack_14 + 0xed4) = 0;
  in_stack_00000060 = (int *)0xb;
  ppuVar10 = (undefined **)
             FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&stack0x00000060);
  ppuVar14 = ppuVar10 + -1;
  if (ppuVar10 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar14 = ppuVar10;
  }
  puVar7[0xed5] = *ppuVar14;
  puVar7[0xed6] = 0;
  puVar7[0xed7] = 0x3f800000;
  puVar7[0xed8] = 0;
  puVar7[0xed9] = 0;
  puVar11 = puVar7 + 0xeda;
  uStack_8._0_1_ = 5;
  *puVar11 = 0;
  puVar7[0xedb] = 0;
  puVar7[0xedc] = 0;
  puVar7[0xedd] = 0;
  puVar7[0xede] = 0;
  in_stack_00000060 = puVar11;
  puVar12 = (undefined4 *)FUN_01674e20(8);
  *puVar11 = puVar12;
  *puVar12 = 0;
  puVar12[1] = 0;
  *(undefined4 **)*puVar11 = puVar11;
  puVar7[0xedf] = 0;
  puVar7[0xee2] = 0xffffffff;
  *(undefined *)(puVar7 + 0xee3) = 0;
  puVar7[0xee4] = 0;
  puVar7[0xee5] = 0;
  puVar7[0xee6] = 0;
  uVar6 = _UNK_018e136c;
  uVar5 = _UNK_018e1368;
  uVar9 = _UNK_018e1364;
  uVar4 = _UNK_018e1358;
  uVar3 = _DAT_018e1350;
  puVar7[0xeea] = _DAT_018e1360;
  puVar7[0xeeb] = uVar9;
  puVar7[0xeec] = uVar5;
  puVar7[0xeed] = uVar6;
  *(undefined *)(puVar7 + 0xef0) = 1;
  uVar2 = DAT_018db070;
  *(undefined8 *)(puVar7 + 0xee8) = uVar3;
  *(undefined8 *)(puVar7 + 0xeee) = 0;
  uStack_8._0_1_ = 8;
  *(undefined8 *)(puVar7 + 0xef2) = uVar2;
  *(undefined8 *)(puVar7 + 0xef4) = uVar3;
  *(undefined8 *)(puVar7 + 0xef6) = uVar4;
  *(undefined *)(puVar7 + 0xefa) = 1;
  *(undefined8 *)(puVar7 + 0xef8) = 0;
  FUN_016827a0(puVar7 + 0xefc);
  *(undefined8 *)(puVar7 + 0xefe) = DAT_018c0d60;
  uVar2 = DAT_018ce300;
  puVar7[0xf00] = 0;
  puVar7[0xf01] = 0;
  *(undefined8 *)(puVar7 + 0xf02) = uVar2;
  puVar7[0xf04] = 0;
  puVar7[0xf05] = 0;
  puVar7[0xf06] = 0;
  puVar7[0xf07] = 0;
  *(undefined *)(puVar7 + 0xf0a) = 1;
  *(undefined8 *)(puVar7 + 0xf08) = 0;
  FUN_016827a0(puVar7 + 0xf0c);
  *(undefined8 *)(puVar7 + 0xf0e) = DAT_018c0d60;
  uVar2 = DAT_018db070;
  puVar7[0xf10] = 0;
  puVar7[0xf11] = 0;
  *(undefined8 *)(puVar7 + 0xf12) = uVar2;
  puVar7[0xf14] = 0;
  puVar7[0xf16] = 0;
  puVar7[0xf17] = 0;
  puVar7[0xf18] = 0;
  puVar7[0xf19] = 0;
  *(undefined *)(puVar7 + 0xf1a) = 1;
  puVar7[0xf1c] = 5;
  FUN_016827a0(puVar7 + 0xf1e);
  *(undefined8 *)(puVar7 + 0xf20) = DAT_018c0d60;
  puVar7[0xf22] = 0;
  puVar7[0xf23] = 0;
  FUN_016827a0(puVar7 + 0xf24);
  *(undefined8 *)(puVar7 + 0xf26) = DAT_018c0d60;
  puVar7[0xf28] = 0;
  uVar2 = DAT_018ce330;
  puVar7[0xf29] = 0;
  puVar7[0xf2a] = 0;
  *(undefined8 *)(puVar7 + 0xf2c) = uVar2;
  puVar7[0xf2e] = 0;
  puVar7[0xf2f] = 0;
  puVar7[0xf30] = 0;
  puVar7[0xf31] = 0;
  puVar7[0xf32] = 0;
  puVar7[0xf33] = 0;
  *(undefined *)(puVar7 + 0xf34) = 0;
  puVar7[0xf35] = 0;
  puVar7[0xf36] = 0;
  puVar7[0xf37] = 0;
  puVar7[0xf38] = 0;
  puVar7[0xf39] = 0;
  uStack_8._0_1_ = 0xc;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("ClientReplicator",0x10);
  uStack_8._0_1_ = 0xd;
  FUN_008a6520(auStack_2c);
  uStack_8._0_1_ = 0xc;
  uVar8 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xc;
  if (0xf < uStack_18) {
    uVar16 = uStack_18 + 1;
    uVar15 = auStack_2c[0];
    if (0xfff < uVar16) {
      uVar15 = *(uint *)(auStack_2c[0] - 4);
      uVar16 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar15) - 4) {
        uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar15,uVar16);
  }
  piVar13 = (int *)FUN_01674e20(4);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  if (piVar13 == (int *)0x0) {
    piVar13 = (int *)0x0;
  }
  else {
    *piVar13 = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
    in_stack_00000060 = piVar13;
    in_stack_00000060 = (int *)FUN_01674e20(0x1c);
    if (in_stack_00000060 == (undefined4 *)0x0) {
      puVar12 = (undefined4 *)0x0;
    }
    else {
      *in_stack_00000060 = 0;
      in_stack_00000060[1] = 0;
      in_stack_00000060[2] = 0;
      in_stack_00000060[3] = 0x44;
      in_stack_00000060[4] = 0x20;
      in_stack_00000060[5] = 0x20;
      in_stack_00000060[6] = 0;
      puVar12 = in_stack_00000060;
    }
    iVar1 = *piVar13;
    *piVar13 = (int)puVar12;
    if (iVar1 != 0) {
      FUN_00615040(iVar1);
    }
  }
  in_stack_00000060 = (int *)puVar7[0xee4];
  puVar7[0xee4] = piVar13;
  if (in_stack_00000060 != (int *)0x0) {
    if (*in_stack_00000060 != 0) {
      FUN_00615040(*in_stack_00000060);
    }
    FUN_01674ea0(in_stack_00000060,4);
  }
  *(undefined *)(puVar7 + 0x7d6) = 1;
  *(undefined *)(puVar7 + 0xe00) = 0;
  if (param_12 != (int *)0x0) {
    LOCK();
    iVar1 = param_12[1] + -1;
    param_12[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_12)();
      LOCK();
      iVar1 = param_12[2] + -1;
      param_12[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_12 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar7;
}



/* FUNCTION 9551 ; VA 0x006ec930 ; FUN_006ec930 */

void __fastcall FUN_006ec930(undefined4 *param_1)

{
  if ((undefined *)*param_1 != (undefined *)0x0) {
    *(undefined *)*param_1 = *(undefined *)(param_1 + 1);
  }
  return;
}



/* FUNCTION 9552 ; VA 0x006ec940 ; FUN_006ec940 */

void __fastcall FUN_006ec940(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Network::ClientReplicator::vftable;
  param_1[0x17] = RBX::Network::ClientReplicator::vftable;
  param_1[0x19] = RBX::Network::ClientReplicator::vftable;
  param_1[0x1a] = RBX::Network::ClientReplicator::vftable;
  FUN_005542c0(&DAT_018bc9b8,0);
  uVar4 = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  FUN_0062db20(uVar4);
  FUN_006b1d60();
  FUN_006b1d60();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  piVar2 = (int *)param_1[0xee6];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0xee4];
  if (piVar2 != (int *)0x0) {
    if (*piVar2 != 0) {
      FUN_00615040(*piVar2);
    }
    FUN_01674ea0(piVar2,4);
  }
  FUN_00611300();
  FUN_006784e0();
  FUN_00678330();
  FUN_006785b0();
  FUN_006133f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9553 ; VA 0x006ecaa0 ; FUN_006ecaa0 */

/* WARNING: Removing unreachable block (ram,0x006ecb3e) */
/* WARNING: Removing unreachable block (ram,0x006ecb4e) */
/* WARNING: Removing unreachable block (ram,0x006ecb54) */

void __thiscall FUN_006ecaa0(int *param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a9c08;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_01675290(uVar1);
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
        ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9554 ; VA 0x006ecb9f ; Catch@006ecb9f */

undefined * Catch_006ecb9f(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_006ecbb0;
}



/* FUNCTION 9555 ; VA 0x006ecbd0 ; FUN_006ecbd0 */

/* WARNING: Removing unreachable block (ram,0x006ecc22) */
/* WARNING: Removing unreachable block (ram,0x006ecc32) */
/* WARNING: Removing unreachable block (ram,0x006ecc38) */

void * __thiscall FUN_006ecbd0(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a9c38;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 9556 ; VA 0x006ecca3 ; Catch@006ecca3 */

undefined * Catch_006ecca3(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_006eccb4;
}



/* FUNCTION 9557 ; VA 0x006eccd0 ; FUN_006eccd0 */

/* WARNING: Removing unreachable block (ram,0x006ecd22) */
/* WARNING: Removing unreachable block (ram,0x006ecd32) */
/* WARNING: Removing unreachable block (ram,0x006ecd38) */

void __fastcall FUN_006eccd0(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9c60;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8 = 2;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = 4;
    FUN_01675290(uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9558 ; VA 0x006ecd6e ; Catch@006ecd6e */

undefined * Catch_006ecd6e(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x20));
  return &DAT_006ecd7f;
}



/* FUNCTION 9559 ; VA 0x006ecd90 ; FUN_006ecd90 */

/* WARNING: Removing unreachable block (ram,0x006ece2e) */
/* WARNING: Removing unreachable block (ram,0x006ece3e) */
/* WARNING: Removing unreachable block (ram,0x006ece44) */

void __thiscall FUN_006ecd90(int *param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a9c88;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_01675290(uVar1);
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  if (0xf < in_stack_0000001c) {
    uVar3 = in_stack_0000001c + 1;
    iVar2 = param_3;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_3 + -4);
      uVar3 = in_stack_0000001c + 0x24;
      if (0x1f < (param_3 - iVar2) - 4U) {
        ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9560 ; VA 0x006ece92 ; Catch@006ece92 */

undefined * Catch_006ece92(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_006ecea3;
}



/* FUNCTION 9561 ; VA 0x006ecebb ; FUN_006ecebb */

void FUN_006ecebb(void)

{
  FUN_006ed010();
  return;
}



/* FUNCTION 9562 ; VA 0x006ecec3 ; FUN_006ecec3 */

void FUN_006ecec3(void)

{
  FUN_006ed010();
  return;
}



/* FUNCTION 9563 ; VA 0x006ececb ; FUN_006ececb */

void FUN_006ececb(void)

{
  FUN_006ed010();
  return;
}



/* FUNCTION 9564 ; VA 0x006ecee0 ; FUN_006ecee0 */

int __thiscall FUN_006ecee0(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),4);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 9565 ; VA 0x006ecf30 ; FUN_006ecf30 */

int __thiscall FUN_006ecf30(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),1);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 9566 ; VA 0x006ecf70 ; FUN_006ecf70 */

undefined4 __thiscall FUN_006ecf70(undefined4 param_1,byte param_2)

{
  FUN_009cba00();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x38);
  }
  return param_1;
}



/* FUNCTION 9567 ; VA 0x006ecfa0 ; FUN_006ecfa0 */

undefined4 * __thiscall FUN_006ecfa0(undefined4 *param_1,uint param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = (int *)param_1[0xe];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *param_1 = RBX::Network::Item::vftable;
  if ((param_2 & 1) != 0) {
    if ((param_2 & 4) == 0) {
      piVar2 = *(int **)param_1[-1];
      param_1[-1] = *piVar2;
      *piVar2 = (int)(param_1 + -1);
      return param_1;
    }
    _guard_check_icall(param_1,0x40);
  }
  return param_1;
}



/* FUNCTION 9568 ; VA 0x006ed010 ; FUN_006ed010 */

undefined4 __thiscall FUN_006ed010(undefined4 param_1,byte param_2)

{
  FUN_006ec940();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x3ce8);
  }
  return param_1;
}



/* FUNCTION 9569 ; VA 0x006ed040 ; FUN_006ed040 */

void FUN_006ed040(undefined4 param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int aiStack_40 [5];
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9db8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01ee4215 != '\0') {
    uVar1 = param_2[1];
    uVar2 = *param_2;
    ExceptionList = &pvStack_10;
    puVar3 = (undefined4 *)FUN_009c9510(auStack_28);
    uStack_8 = 0;
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    FUN_01677490(DAT_01ee4215,"Parent Key : %s , numberOfChild = %d, nextChildIndex = %d",puVar3,
                 uVar2,uVar1);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_14) {
      uVar7 = uStack_14 + 1;
      uVar8 = auStack_28[0];
      if (0xfff < uVar7) {
        uVar8 = *(uint *)(auStack_28[0] - 4);
        uVar7 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar8) - 4) {
LAB_006ed1f8:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar7);
    }
  }
  if (param_2[4] == 0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    puVar3 = *(undefined4 **)(param_2[7] + param_2[3] * 4);
  }
  do {
    if (puVar3 == (undefined4 *)0x0) {
      ExceptionList = pvStack_10;
      return;
    }
    if (DAT_01ee4215 != '\0') {
      puVar4 = (undefined4 *)FUN_008a2380(aiStack_40);
      uStack_8 = 1;
      if (0xf < (uint)puVar4[5]) {
        puVar4 = (undefined4 *)*puVar4;
      }
      puVar5 = (undefined4 *)FUN_009c9510(auStack_28);
      uStack_8._0_1_ = 2;
      if (0xf < (uint)puVar5[5]) {
        puVar5 = (undefined4 *)*puVar5;
      }
      FUN_01677520(DAT_01ee4215,"    Value : [%d] Instance %s[%s]",puVar3[2],puVar5,puVar4);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (0xf < uStack_14) {
        uVar7 = uStack_14 + 1;
        uVar8 = auStack_28[0];
        if (0xfff < uVar7) {
          uVar8 = *(uint *)(auStack_28[0] - 4);
          uVar7 = uStack_14 + 0x24;
          if (0x1f < (auStack_28[0] - uVar8) - 4) goto LAB_006ed1f8;
        }
        FUN_01674ea0(uVar8,uVar7);
      }
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = auStack_28[0] & 0xffffff00;
      uStack_8 = 0xffffffff;
      if (0xf < uStack_2c) {
        uVar8 = uStack_2c + 1;
        iVar6 = aiStack_40[0];
        if (0xfff < uVar8) {
          iVar6 = *(int *)(aiStack_40[0] + -4);
          uVar8 = uStack_2c + 0x24;
          if (0x1f < (aiStack_40[0] - iVar6) - 4U) goto LAB_006ed1f8;
        }
        FUN_01674ea0(iVar6,uVar8);
      }
    }
    puVar3 = (undefined4 *)*puVar3;
  } while( true );
}



/* FUNCTION 9570 ; VA 0x006ed200 ; FUN_006ed200 */

void FUN_006ed200(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  FUN_006159a0(param_1,param_2,param_3,param_4,param_5,param_6);
  return;
}



/* FUNCTION 9571 ; VA 0x006ed220 ; FUN_006ed220 */

undefined4 __thiscall FUN_006ed220(int param_1,undefined **param_2)

{
  byte bVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  int *piVar8;
  int *piVar9;
  undefined4 *puVar10;
  undefined *puVar11;
  undefined uVar12;
  uint uStack_5c0;
  undefined *puStack_5bc;
  int *piStack_5b8;
  undefined4 uStack_5b4;
  char *pcStack_5b0;
  undefined4 uStack_5ac;
  uint uStack_5a8;
  undefined *puStack_5a4;
  undefined4 ***pppuStack_5a0;
  int *piStack_59c;
  undefined4 ***pppuStack_598;
  undefined4 ***pppuStack_594;
  undefined *puStack_590;
  undefined8 *puStack_58c;
  undefined4 ***pppuStack_588;
  undefined4 ***pppuStack_584;
  undefined4 ***pppuStack_580;
  undefined4 ***pppuStack_57c;
  int aiStack_56c [257];
  int aiStack_168 [16];
  undefined auStack_128 [24];
  undefined auStack_110 [16];
  int aiStack_100 [2];
  uint uStack_f8;
  uint uStack_f0;
  undefined4 uStack_e8;
  undefined auStack_e4 [40];
  int aiStack_bc [10];
  undefined4 ***apppuStack_94 [4];
  int iStack_84;
  uint uStack_80;
  undefined auStack_7c [8];
  undefined4 uStack_74;
  undefined4 uStack_64;
  uint uStack_60;
  undefined4 uStack_5c;
  undefined *puStack_58;
  undefined auStack_54 [4];
  int iStack_50;
  undefined4 auStack_4c [4];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 ***apppuStack_34 [4];
  undefined *puStack_24;
  uint uStack_20;
  undefined8 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9f24;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  pppuStack_57c = (undefined4 ***)DAT_01eadc98;
  pppuStack_580 = (undefined4 ***)0x6ed258;
  ExceptionList = &pvStack_10;
  iStack_50 = param_1;
  uVar3 = FUN_01675290();
  piVar7 = (int *)param_2;
  pppuStack_57c = (undefined4 ***)(param_1 + 0x18);
  uStack_8 = 0;
  pppuStack_580 = (undefined4 ***)0x6ed278;
  uStack_e8 = uVar3;
  cVar2 = FUN_005f7260();
  if (cVar2 != '\0') {
    pppuStack_57c = (undefined4 ***)piVar7;
    pppuStack_580 = (undefined4 ***)0x6ed284;
    uVar4 = FUN_00615a90();
    goto LAB_006ede9b;
  }
  pppuStack_57c = (undefined4 ***)0x6ed293;
  FUN_008866d0();
  puVar11 = (undefined *)piVar7[0xe];
  uStack_8._0_1_ = 2;
  switch(*puVar11) {
  case 0x10:
    if (*(int *)(param_1 + 0x1d68) == 0) goto LAB_006ed32f;
    pppuStack_57c = (undefined4 ***)0x0;
    pppuStack_580 = (undefined4 ***)0x6ed2ca;
    FUN_00687220();
    uVar4 = 1;
    break;
  default:
    pppuStack_57c = (undefined4 ***)piVar7;
    pppuStack_580 = (undefined4 ***)0x6ede89;
    uVar4 = FUN_00615a90();
    break;
  case 0x8e:
    pppuStack_57c = (undefined4 ***)0x7c;
    pppuStack_580 = (undefined4 ***)0x1;
    pppuStack_588 = (undefined4 ***)auStack_4c;
    pppuStack_584 = (undefined4 ***)piVar7;
    puStack_58c = (undefined8 *)0x6ed347;
    pppuStack_57c = (undefined4 ***)FUN_006b1620();
    uStack_8._0_1_ = 6;
    if (0xf < pppuStack_57c[5]) {
      pppuStack_57c = (undefined4 ***)*pppuStack_57c;
    }
    pppuStack_584 = apppuStack_34;
    pppuStack_580 = (undefined4 ***)0x18e0a44;
    pppuStack_588 = (undefined4 ***)0x6ed365;
    FUN_01675640();
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    pppuStack_57c = (undefined4 ***)0x6ed374;
    FUN_005507b0();
    pppuStack_57c = (undefined4 ***)0x6;
    pppuStack_580 = apppuStack_34;
    if (0xf < uStack_20) {
      pppuStack_580 = apppuStack_34[0];
    }
    pppuStack_584 = (undefined4 ***)0x4;
    pppuStack_588 = (undefined4 ****)0x6ed389;
    FUN_0086edd0();
    if (DAT_01ee420a != 0) {
      pppuStack_57c = apppuStack_34;
      if (0xf < uStack_20) {
        pppuStack_57c = apppuStack_34[0];
      }
      pppuStack_584 = (undefined4 ***)(uint)DAT_01ee420a;
      pppuStack_580 = (undefined4 ***)0x18e0a60;
      pppuStack_588 = (undefined4 ****)0x6ed3b0;
      FUN_01677650();
    }
    pppuStack_57c = (undefined4 ***)0x6ed3bb;
    uStack_14 = FUN_006eb960();
    puStack_58 = (undefined *)&puStack_590;
    bVar1 = *(byte *)piVar7[0xe];
    pppuStack_594 = (undefined4 ***)0x2a;
    pppuStack_598 = (undefined4 ***)0x18e0a78;
    pppuStack_580 = (undefined4 ***)0x0;
    pppuStack_57c = (undefined4 ***)0xf;
    puStack_590 = (undefined *)((uint)puStack_590 & 0xffffff00);
    piStack_59c = (int *)0x6ed3ef;
    FUN_005542c0();
    puStack_5bc = (undefined *)&uStack_5ac;
    uStack_8._0_1_ = 9;
    pcStack_5b0 = (char *)0x7c;
    uStack_5b4 = 1;
    piStack_5b8 = (int *)param_2;
    uStack_5c0 = 0x6ed407;
    pppuStack_594 = (undefined4 ***)(uint)bVar1;
    FUN_006b1620();
    uStack_8._0_1_ = 8;
    pcStack_5b0 = (undefined *)0x6ed415;
    FUN_00688bd0();
    pppuStack_57c = (undefined4 ***)0x103;
    pppuStack_580 = (undefined4 ***)0x6ed425;
    FUN_0062b370();
    if (DAT_01d5b038 == '\0') {
      pppuStack_57c = (undefined4 ***)0x1;
      pppuStack_580 = (undefined4 ***)0x18ccc14;
      pppuStack_584 = (undefined4 ***)0x6ed46e;
      FUN_0068cab0();
    }
    else {
      pppuStack_57c = (undefined4 ***)0x7c;
      pppuStack_580 = (undefined4 ***)0x401;
      pppuStack_584 = (undefined4 ***)aiStack_56c;
      pppuStack_588 = (undefined4 ***)0x1;
      puStack_58c = (undefined8 *)0x6ed445;
      FUN_005f7b20();
      pppuStack_580 = (undefined4 ***)aiStack_56c;
      pppuStack_57c = (undefined4 ***)0x3;
      pppuStack_584 = (undefined4 ***)0x1;
      pppuStack_588 = (undefined4 ***)0x18ccc14;
      puStack_58c = (undefined8 *)0x6ed45d;
      FUN_0068b590();
    }
    if (DAT_01d5ba64 != '\0') {
      pppuStack_57c = (undefined4 ***)((int)&param_2 + 3);
      pppuStack_580 = (undefined4 ***)((int)&param_2 + 3);
      pppuStack_584 = (undefined4 ***)((int)&param_2 + 3);
      pppuStack_588 = (undefined4 ***)&DAT_0000000b;
      puStack_58c = (undefined8 *)0x6ed494;
      FUN_005d0b40();
      pppuStack_57c = (undefined4 ***)0x15;
      pppuStack_580 = (undefined4 ***)0x18d767c;
      uStack_8._0_1_ = 10;
      uStack_3c = 0;
      uStack_38 = 0xf;
      auStack_4c[0]._0_1_ = 0;
      pppuStack_584 = (undefined4 ***)0x6ed4b9;
      FUN_005542c0();
      pppuStack_57c = (undefined4 ***)auStack_4c;
      uStack_8._0_1_ = 0xb;
      pppuStack_580 = (undefined4 ***)0x6ed4cc;
      FUN_005d15d0();
      pppuStack_57c = (undefined4 ***)0x11;
      pppuStack_580 = (undefined4 ***)0x18e0aa4;
      pppuStack_584 = (undefined4 ***)0x6ed4db;
      FUN_005542c0();
      uStack_8._0_1_ = 10;
      pppuStack_57c = (undefined4 ***)0x6ed4e7;
      FUN_005507b0();
      param_2 = &puStack_590;
      uStack_1c._4_4_ = &puStack_590;
      pppuStack_594 = apppuStack_94;
      pppuStack_598 = (undefined4 ***)0x6ed4fe;
      FUN_0060e660();
      uStack_1c._4_4_ = (undefined **)&uStack_5a8;
      uStack_8._0_1_ = 0xc;
      uStack_5ac = 0xf;
      pppuStack_598 = (undefined4 ***)0x0;
      pppuStack_594 = (undefined4 ***)0xf;
      pcStack_5b0 = "GameJoinFailure";
      uStack_5a8 = uStack_5a8 & 0xffffff00;
      uStack_5b4 = 0x6ed527;
      FUN_005542c0();
      puStack_58 = (undefined *)&uStack_5c0;
      uStack_8._0_1_ = 0xd;
      pcStack_5b0 = (undefined *)0x0;
      uStack_5ac = 0xf;
      uStack_5c0 = uStack_5c0 & 0xffffff00;
      FUN_005542c0("report",6);
      uStack_8._0_1_ = 0xe;
      uVar12 = 0;
      FUN_005542c0("client",6);
      uStack_8._0_1_ = 10;
      FUN_0087a540(uVar12);
      pppuStack_57c = (undefined4 ***)0x6ed58d;
      FUN_0056cfd0();
    }
    pppuStack_57c = (undefined4 ***)0x6ed595;
    FUN_005507b0();
    uVar4 = 1;
    break;
  case 0x92:
    pppuStack_57c = (undefined4 ***)0x0;
    pppuStack_580 = (undefined4 ***)piVar7[0xc];
    pppuStack_588 = (undefined4 ****)0x6ed5b0;
    pppuStack_584 = (undefined4 ***)puVar11;
    FUN_006ab380();
    pppuStack_57c = (undefined4 ***)0x1;
    uStack_8._0_1_ = 0x10;
    pppuStack_580 = (undefined4 ***)0x6ed5c1;
    FUN_006ab660();
    pppuStack_57c = (undefined4 ***)0x6ed5cc;
    cVar2 = FUN_006abd90();
    if (cVar2 == '\0') {
      pppuStack_57c = (undefined4 ***)0x18e0afc;
      pppuStack_580 = (undefined4 ***)0x3;
      pppuStack_584 = (undefined4 ***)0x6ed636;
      FUN_0086f2f0();
      pppuStack_57c = (undefined4 ***)0x6ed641;
      uStack_14 = FUN_006eb960();
      uStack_1c._4_4_ = &puStack_590;
      bVar1 = *(byte *)piVar7[0xe];
      pppuStack_594 = (undefined4 ***)0x1d;
      pppuStack_598 = (undefined4 ***)0x18e0b1c;
      pppuStack_580 = (undefined4 ***)0x0;
      pppuStack_57c = (undefined4 ***)0xf;
      puStack_590 = (undefined *)((uint)puStack_590 & 0xffffff00);
      piStack_59c = (int *)0x6ed675;
      FUN_005542c0();
      puStack_5bc = (undefined *)&uStack_5ac;
      uStack_8._0_1_ = 0x12;
      pcStack_5b0 = (char *)0x7c;
      uStack_5b4 = 1;
      piStack_5b8 = (int *)param_2;
      uStack_5c0 = 0x6ed68d;
      pppuStack_594 = (undefined4 ***)(uint)bVar1;
      FUN_006b1620();
      uStack_8._0_1_ = 0x10;
      pcStack_5b0 = (undefined *)0x6ed69b;
      FUN_00688bd0();
      pppuStack_57c = (undefined4 ***)0x107;
      pppuStack_580 = (undefined4 ***)0x6ed6ab;
      FUN_0062b370();
      if (DAT_01d5b038 == '\0') {
        pppuStack_57c = (undefined4 ***)0x1;
        pppuStack_580 = (undefined4 ***)0x18e0b3c;
        pppuStack_584 = (undefined4 ***)0x6ed6f4;
        FUN_0068cab0();
      }
      else {
        pppuStack_57c = (undefined4 ***)0x7c;
        pppuStack_580 = (undefined4 ***)0x401;
        pppuStack_584 = (undefined4 ***)aiStack_56c;
        pppuStack_588 = (undefined4 ***)0x1;
        puStack_58c = (undefined8 *)0x6ed6cb;
        FUN_005f7b20();
        pppuStack_580 = (undefined4 ***)aiStack_56c;
        pppuStack_57c = (undefined4 ***)0x3;
        pppuStack_584 = (undefined4 ***)0x1;
        pppuStack_588 = (undefined4 ***)0x18e0b3c;
        puStack_58c = (undefined8 *)0x6ed6e3;
        FUN_0068b590();
      }
      if (DAT_01d5ba64 != '\0') {
        pppuStack_57c = (undefined4 ***)((int)&param_2 + 3);
        pppuStack_580 = (undefined4 ***)((int)&param_2 + 3);
        pppuStack_584 = (undefined4 ***)((int)&param_2 + 3);
        pppuStack_588 = (undefined4 ***)&DAT_0000000b;
        puStack_58c = (undefined8 *)0x6ed717;
        FUN_005d0b40();
        pppuStack_57c = (undefined4 ***)0x15;
        pppuStack_580 = (undefined4 ***)0x18d767c;
        uStack_8._0_1_ = 0x13;
        uStack_3c = 0;
        uStack_38 = 0xf;
        auStack_4c[0]._0_1_ = 0;
        pppuStack_584 = (undefined4 ***)0x6ed73c;
        FUN_005542c0();
        pppuStack_57c = (undefined4 ***)auStack_4c;
        uStack_8._0_1_ = 0x14;
        pppuStack_580 = (undefined4 ***)0x6ed74c;
        FUN_005d15d0();
        pppuStack_57c = (undefined4 ***)0x19;
        pppuStack_580 = (undefined4 ***)0x18e0b3c;
        pppuStack_584 = (undefined4 ***)0x6ed75b;
        FUN_005542c0();
        uStack_8._0_1_ = 0x13;
        pppuStack_57c = (undefined4 ***)0x6ed767;
        FUN_005507b0();
        param_2 = &puStack_590;
        uStack_1c._4_4_ = &puStack_590;
        pppuStack_594 = apppuStack_34;
        pppuStack_598 = (undefined4 ***)0x6ed77b;
        FUN_0060e660();
        uStack_1c._4_4_ = (undefined **)&uStack_5a8;
        uStack_8._0_1_ = 0x15;
        uStack_5ac = 0xf;
        pppuStack_598 = (undefined4 ***)0x0;
        pppuStack_594 = (undefined4 ***)0xf;
        pcStack_5b0 = "GameJoinFailure";
        uStack_5a8 = uStack_5a8 & 0xffffff00;
        uStack_5b4 = 0x6ed7a4;
        FUN_005542c0();
        puStack_58 = (undefined *)&uStack_5c0;
        uStack_8._0_1_ = 0x16;
        pcStack_5b0 = (undefined *)0x0;
        uStack_5ac = 0xf;
        uStack_5c0 = uStack_5c0 & 0xffffff00;
        FUN_005542c0("report",6);
        uStack_8._0_1_ = 0x17;
        uVar12 = 0;
        FUN_005542c0("client",6);
        uStack_8._0_1_ = 0x13;
        FUN_0087a540(uVar12);
        pppuStack_57c = (undefined4 ***)0x6ed807;
        FUN_0056cfd0();
      }
      pppuStack_57c = (undefined4 ***)0x6ed812;
      FUN_00613200();
      uVar4 = 0;
    }
    else {
      pppuStack_57c = (undefined4 ***)0x18e0ab8;
      pppuStack_580 = (undefined4 ***)0x1;
      pppuStack_584 = (undefined4 ***)0x6ed5dc;
      FUN_0086f2f0();
      pppuStack_584 = (undefined4 ***)0x30;
      pppuStack_588 = (undefined4 ****)0x6ed5e3;
      piVar7 = (int *)FUN_01674e20();
      uStack_8._0_1_ = 0x11;
      param_2 = (undefined **)piVar7;
      if (piVar7 == (int *)0x0) {
        pppuStack_57c = (undefined4 ***)0x0;
      }
      else {
        pppuStack_57c = (undefined4 ***)(param_1 + -0x5c);
        pppuStack_580 = (undefined4 ***)0x6ed5fe;
        FUN_006b1a30();
        *piVar7 = (int)RBX::Network::ClientReplicator::RequestCharacterItem::vftable;
        pppuStack_57c = (undefined4 ***)piVar7;
      }
      uStack_8._0_1_ = 0x10;
      pppuStack_580 = (undefined4 ***)0x6ed618;
      FUN_006b1f50();
      pppuStack_57c = (undefined4 ***)0x6ed623;
      FUN_00613200();
      uVar4 = 0;
    }
    break;
  case 0x93:
    pppuStack_57c = (undefined4 ***)0x0;
    pppuStack_580 = (undefined4 ***)piVar7[0xc];
    pppuStack_588 = (undefined4 ****)0x6ed2e5;
    pppuStack_584 = (undefined4 ***)puVar11;
    FUN_006ab380();
    pppuStack_57c = (undefined4 ***)0x1;
    uStack_8._0_1_ = 4;
    pppuStack_580 = (undefined4 ***)0x6ed2f6;
    FUN_006ab660();
    pppuStack_57c = (undefined4 ***)0x1;
    pppuStack_580 = (undefined4 ***)0x6ed303;
    FUN_006ab660();
    if (uStack_f0 < uStack_f8) {
      pppuStack_57c = (undefined4 ***)auStack_110;
      pppuStack_580 = (undefined4 ***)0x6ed324;
      (**(code **)(*(int *)(param_1 + -0x5c) + 0x1b4))();
    }
    pppuStack_57c = (undefined4 ***)0x6ed32f;
    FUN_00613200();
LAB_006ed32f:
    uVar4 = 1;
    break;
  case 0x98:
    pppuStack_57c = (undefined4 ***)0x0;
    pppuStack_580 = (undefined4 ***)piVar7[0xc];
    pppuStack_588 = (undefined4 ***)0x6ed82a;
    pppuStack_584 = (undefined4 ***)puVar11;
    FUN_006ab380();
    pppuStack_57c = (undefined4 ***)0x1;
    uStack_8._0_1_ = 0x19;
    pppuStack_580 = (undefined4 ***)0x6ed83b;
    FUN_006ab660();
    pppuStack_57c = apppuStack_34;
    pppuStack_580 = (undefined4 ***)0x6ed84a;
    FUN_006acbd0();
    uStack_8._0_1_ = 0x1a;
    if (DAT_01d651d1 != 0) {
      pppuStack_57c = apppuStack_34;
      if (0xf < uStack_20) {
        pppuStack_57c = apppuStack_34[0];
      }
      pppuStack_584 = (undefined4 ***)(uint)DAT_01d651d1;
      pppuStack_580 = (undefined4 ***)0x18e0b58;
      pppuStack_588 = (undefined4 ***)0x6ed872;
      FUN_016774b0();
    }
    pppuStack_57c = apppuStack_34;
    if (0xf < uStack_20) {
      pppuStack_57c = apppuStack_34[0];
    }
    pppuStack_580 = (undefined4 ***)0x18e0b58;
    pppuStack_584 = (undefined4 ***)0x3;
    pppuStack_588 = (undefined4 ****)0x6ed88d;
    FUN_0086f2f0();
    iVar6 = param_1 + -0x5c;
    pppuStack_57c = (undefined4 ***)0x6ed89e;
    iVar5 = (**(code **)(*(int *)(param_1 + -0x5c) + 0xb4))();
    if (iVar5 == 0) {
      if (iVar6 != 0) {
        iVar5 = *(int *)(param_1 + -0x28);
        if ((iVar5 != 0) && (iVar6 = iVar5, *(int *)(iVar5 + 0x34) != 0)) {
          pppuStack_57c = (undefined4 ***)0x6ed8dd;
          iVar6 = FUN_005c8ac0();
        }
        if (iVar6 != 0) {
          iVar6 = *(int *)(iVar6 + 0xc);
          pppuStack_57c = (undefined4 ***)0x6ed8f3;
          iVar5 = FUN_008a8c30();
          if ((uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
              (uint)*(ushort *)(iVar5 + 0x1da)) {
            pppuStack_57c = (undefined4 ***)&LAB_006340d0;
            pppuStack_580 = (undefined4 ***)&DAT_01ead5f8;
            pppuStack_584 = (undefined4 ***)0x6ed921;
            FUN_005789c0();
            pppuStack_57c = (undefined4 ***)0x6ed929;
            pppuStack_57c = (undefined4 ***)FUN_006352d0();
            pppuStack_580 = (undefined4 ***)0x6ed931;
            param_2 = (undefined **)FUN_008aa140();
            if (*param_2 == (undefined *)0x0) {
              pppuStack_57c = (undefined4 ***)0x6ed93e;
              pppuStack_57c = (undefined4 ***)FUN_00b8c410();
              pppuStack_580 = (undefined4 ***)&uStack_1c;
              pppuStack_584 = (undefined4 ***)0x6ed94a;
              piVar7 = (int *)FUN_008a9ba0();
              iVar6 = *piVar7;
              iVar5 = piVar7[1];
              *piVar7 = 0;
              piVar7[1] = 0;
              *param_2 = (undefined *)iVar6;
              piVar7 = (int *)((int *)param_2)[1];
              ((int *)param_2)[1] = iVar5;
              if (piVar7 != (int *)0x0) {
                LOCK();
                iVar6 = piVar7[1] + -1;
                piVar7[1] = iVar6;
                UNLOCK();
                if (iVar6 == 0) {
                  pppuStack_57c = (undefined4 ***)0x6ed97d;
                  (**(code **)*piVar7)();
                  LOCK();
                  iVar6 = piVar7[2] + -1;
                  piVar7[2] = iVar6;
                  UNLOCK();
                  if (iVar6 == 0) {
                    pppuStack_57c = (undefined4 ***)0x6ed98d;
                    (**(code **)(*piVar7 + 4))();
                  }
                }
              }
              piVar7 = (int *)uStack_1c._4_4_;
              if (uStack_1c._4_4_ != (undefined **)0x0) {
                LOCK();
                iVar6 = ((int *)uStack_1c._4_4_)[1] + -1;
                ((int *)uStack_1c._4_4_)[1] = iVar6;
                UNLOCK();
                if (iVar6 == 0) {
                  pppuStack_57c = (undefined4 ***)0x6ed9a3;
                  (**(code **)*uStack_1c._4_4_)();
                  LOCK();
                  piVar8 = piVar7 + 2;
                  iVar6 = *piVar8;
                  *piVar8 = *piVar8 + -1;
                  UNLOCK();
                  if (iVar6 == 1) {
                    pppuStack_57c = (undefined4 ***)0x6ed9b2;
                    (**(code **)(*piVar7 + 4))();
                  }
                }
              }
            }
            if (*param_2 != (undefined *)0x0) {
              pppuStack_57c = (undefined4 ***)0x10b;
              pppuStack_598 = apppuStack_34;
              piStack_59c = (int *)0x6ed9ce;
              FUN_0054ef60();
              pppuStack_598 = (undefined4 ***)0x6ed9d5;
              FUN_00b9c950();
            }
          }
        }
      }
    }
    else {
      pppuStack_594 = apppuStack_34;
      pppuStack_598 = (undefined4 ***)0x6ed8b6;
      FUN_0054ef60();
      pppuStack_594 = (undefined4 ***)0x6ed8bd;
      FUN_006ecaa0();
    }
    pppuStack_57c = (undefined4 ***)0x6ed9dd;
    FUN_005507b0();
    pppuStack_57c = (undefined4 ***)0x6ed9e8;
    FUN_00613200();
LAB_006ed9e8:
    uVar4 = 0;
    break;
  case 0x9a:
    if ((DAT_01d5ba74 == '\0') || (*(char *)(param_1 + 0x37e8) == '\0')) goto LAB_006ed9e8;
    pppuStack_57c = (undefined4 ***)0x0;
    *(undefined *)(param_1 + 0x37e8) = 0;
    pppuStack_580 = (undefined4 ***)piVar7[0xc];
    pppuStack_584 = (undefined4 ***)piVar7[0xe];
    pppuStack_588 = (undefined4 ***)0x6eda1b;
    FUN_006ab380();
    pppuStack_57c = (undefined4 ***)0x1;
    uStack_8._0_1_ = 0x1d;
    pppuStack_580 = (undefined4 ***)0x6eda2c;
    FUN_006ab660();
    pppuStack_57c = (undefined4 ***)0x6eda37;
    FUN_006ac4d0();
    pppuStack_57c = (undefined4 ***)0x6eda42;
    puVar11 = (undefined *)FUN_006ac4d0();
    pppuStack_57c = (undefined4 ***)0x6eda4f;
    FUN_006ab530();
    pppuStack_57c = (undefined4 ***)auStack_e4;
    uStack_8._0_1_ = 0x1e;
    pppuStack_580 = (undefined4 ***)aiStack_bc;
    pppuStack_584 = (undefined4 ***)0x6eda66;
    FUN_0061a740();
    puStack_24 = (undefined *)0x0;
    uStack_20 = 0xf;
    apppuStack_34[0] = (undefined4 ***)((uint)apppuStack_34[0] & 0xffffff00);
    pppuStack_584 = (undefined4 ***)auStack_e4;
    uStack_8._0_1_ = 0x1f;
    pppuStack_588 = apppuStack_34;
    puStack_58c = (undefined8 *)0x6eda8c;
    FUN_006ab8e0();
    if (puVar11 == puStack_24) {
      pppuStack_57c = (undefined4 ***)0x0;
      pppuStack_580 = (undefined4 ***)0x6eda9f;
      uStack_1c = FUN_0171e1b0();
      pppuStack_580 = (undefined4 ***)0x40;
      pppuStack_588 = (undefined4 ***)aiStack_168;
      pppuStack_584 = (undefined4 ***)0x0;
      puStack_58c = (undefined8 *)0x6edab5;
      FUN_0170d1f0();
      puStack_58c = &uStack_1c;
      puStack_590 = (undefined *)0x6edabe;
      puStack_590 = (undefined *)FUN_0172468b();
      pppuStack_594 = (undefined4 ***)0x18c6ac4;
      piStack_59c = aiStack_168;
      pppuStack_598 = (undefined4 ***)0x40;
      pppuStack_5a0 = (undefined4 ***)0x6edad2;
      FUN_01724efb();
      iStack_84 = 0;
      uStack_80 = 0xf;
      apppuStack_94[0] = (undefined4 ***)((uint)apppuStack_94[0] & 0xffffff00);
      pppuStack_5a0 = apppuStack_94;
      uStack_8._0_1_ = 0x21;
      puStack_5a4 = (undefined *)0x6edaf7;
      FUN_009c9100();
      uStack_64 = 0;
      uStack_60 = 7;
      uStack_74 = (undefined4 *)((uint)uStack_74._2_2_ << 0x10);
      puStack_5a4 = &DAT_018c0e28;
      uStack_5a8 = 0;
      pcStack_5b0 = auStack_128;
      uStack_8._0_1_ = 0x22;
      uStack_5ac = 1;
      uStack_5b4 = 0x6edb23;
      FUN_01518d10();
      pppuStack_57c = (undefined4 ***)auStack_4c;
      uStack_8._0_1_ = 0x23;
      pppuStack_580 = (undefined4 ***)0x6edb35;
      piVar7 = (int *)FUN_005569d0();
      uStack_64 = 0;
      puVar10 = &uStack_74;
      if (7 < uStack_60) {
        puVar10 = uStack_74;
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,0x24);
      *(undefined2 *)puVar10 = 0;
      if (piVar7[4] != 0) {
        piVar8 = piVar7;
        if (0xf < (uint)piVar7[5]) {
          piVar8 = (int *)*piVar7;
        }
        param_2 = (undefined **)((int)piVar8 + piVar7[4]);
        if (0xf < (uint)piVar7[5]) {
          piVar7 = (int *)*piVar7;
        }
        pppuStack_57c = (undefined4 ***)0x6edb76;
        pppuStack_57c = (undefined4 ***)FUN_01686580();
        pppuStack_580 = (undefined4 ***)&uStack_74;
        pppuStack_584 = (undefined4 ***)param_2;
        puStack_58c = (undefined8 *)0x6edb84;
        pppuStack_588 = (undefined4 ***)piVar7;
        FUN_01685950();
      }
      pppuStack_57c = (undefined4 ***)0x6edb8f;
      FUN_005507b0();
      pppuStack_57c = (undefined4 ***)0x6edb9a;
      FUN_00550800();
      pppuStack_57c = (undefined4 ***)(iStack_84 + 4);
      uStack_8._0_1_ = 0x25;
      uStack_3c = 0;
      uStack_38 = 0xf;
      auStack_4c[0]._0_1_ = 0;
      uStack_14 = 1;
      pppuStack_580 = (undefined4 ***)0x6edbc6;
      FUN_0058a190();
      pppuStack_57c = (undefined4 ***)0x4;
      pppuStack_580 = (undefined4 ***)&DAT_018c0e58;
      pppuStack_584 = (undefined4 ***)0x6edbd5;
      FUN_00554150();
      pppuStack_57c = (undefined4 ***)iStack_84;
      pppuStack_580 = apppuStack_94;
      if (0xf < uStack_80) {
        pppuStack_580 = apppuStack_94[0];
      }
      pppuStack_584 = (undefined4 ***)0x6edbf2;
      FUN_00554150();
      pppuStack_57c = (undefined4 ***)&DAT_018c6ae4;
      pppuStack_580 = (undefined4 ***)auStack_4c;
      pppuStack_584 = (undefined4 ***)aiStack_100;
      pppuStack_588 = (undefined4 ***)0x6edc07;
      puStack_58c = (undefined8 *)FUN_00558c80();
      pppuStack_588 = (undefined4 ***)aiStack_168;
      uStack_8._0_1_ = 0x26;
      puStack_590 = auStack_128;
      pppuStack_594 = (undefined4 ***)0x6edc1f;
      piVar9 = (int *)FUN_00558c80();
      uStack_8._0_1_ = 0x27;
      piVar8 = piVar9;
      piVar7 = piVar9;
      if (0xf < (uint)piVar9[5]) {
        piVar7 = (int *)*piVar9;
        piVar8 = (int *)*piVar9;
      }
      if (piVar7 != (int *)(piVar9[4] + (int)piVar8)) {
        pppuStack_57c = (undefined4 ***)0x6edc49;
        iStack_50 = FUN_01687bc0();
        if (piVar9[4] != 0) {
          piVar7 = piVar9;
          if (0xf < (uint)piVar9[5]) {
            piVar7 = (int *)*piVar9;
          }
          param_2 = (undefined **)((int)piVar7 + piVar9[4]);
          if (0xf < (uint)piVar9[5]) {
            piVar9 = (int *)*piVar9;
          }
          pppuStack_57c = (undefined4 ***)0x6edc70;
          pppuStack_57c = (undefined4 ***)FUN_01686580();
          pppuStack_580 = (undefined4 ***)&uStack_74;
          pppuStack_584 = (undefined4 ***)param_2;
          puStack_58c = (undefined8 *)0x6edc7e;
          pppuStack_588 = (undefined4 ***)piVar9;
          FUN_01685950();
        }
        if (iStack_50 != 0) {
          pppuStack_580 = (undefined4 ***)0x6edc91;
          pppuStack_57c = (undefined4 ***)iStack_50;
          FUN_01687c10();
        }
      }
      pppuStack_57c = (undefined4 ***)0x6edc9c;
      FUN_005507b0();
      pppuStack_57c = (undefined4 ***)0x6edca7;
      FUN_005507b0();
      uStack_8._0_1_ = 0x22;
      pppuStack_57c = (undefined4 ***)0x6edcb3;
      FUN_005507b0();
      uStack_5c = 0;
      pppuStack_57c = (undefined4 ***)0x6edcbf;
      puStack_58 = (undefined *)FUN_01685730();
      pppuStack_57c = (undefined4 ***)&uStack_5c;
      pppuStack_580 = (undefined4 ***)&uStack_74;
      pppuStack_584 = (undefined4 ***)auStack_54;
      pppuStack_588 = (undefined4 ****)0x6edcd3;
      piVar7 = (int *)FUN_0168e1c0();
      if ((*piVar7 == 0) || (*piVar7 == 1)) {
        pppuStack_57c = (undefined4 ***)&uStack_74;
        pppuStack_580 = (undefined4 ***)0x6edcf3;
        puVar10 = (undefined4 *)FUN_0153ad70();
        if (puVar10 != (undefined4 *)0x0) {
          pppuStack_588 = apppuStack_34;
          if (0xf < uStack_20) {
            pppuStack_588 = apppuStack_34[0];
          }
          pppuStack_580 = (undefined4 ***)0x1;
          pppuStack_584 = (undefined4 ***)puStack_24;
          puStack_58c = (undefined8 *)0x6edd13;
          pppuStack_57c = (undefined4 ***)puVar10;
          FUN_01719056();
          puStack_590 = (undefined *)0x6edd19;
          puStack_58c = (undefined8 *)puVar10;
          FUN_01718190();
        }
        if (DAT_01d5ba74 != '\0') {
          pppuStack_594 = (undefined4 ***)&puStack_590;
          pppuStack_598 = (undefined4 ***)0x6edd31;
          FUN_005569d0();
          pppuStack_594 = (undefined4 ***)0x1;
          pppuStack_598 = (undefined4 ***)(param_1 + -0x5c);
          piStack_59c = (int *)0x6edd41;
          FUN_006ef970();
        }
      }
      else {
        *(undefined *)(param_1 + 0x37e8) = 0;
      }
      pppuStack_57c = (undefined4 ***)0x6edd49;
      FUN_00550800();
      pppuStack_57c = (undefined4 ***)0x6edd54;
      FUN_005507b0();
    }
    pppuStack_57c = (undefined4 ***)0x6edd5c;
    FUN_005507b0();
    pppuStack_57c = (undefined4 ***)0x6edd67;
    FUN_00613200();
    pppuStack_57c = (undefined4 ***)0x6edd72;
    FUN_00613200();
    uVar4 = 0;
    break;
  case 0x9b:
    pppuStack_57c = (undefined4 ***)0x0;
    pppuStack_580 = (undefined4 ***)piVar7[0xc];
    pppuStack_588 = (undefined4 ***)0x6edd8a;
    pppuStack_584 = (undefined4 ***)puVar11;
    FUN_006ab380();
    pppuStack_57c = (undefined4 ***)0x1;
    uStack_8._0_1_ = 0x2a;
    pppuStack_580 = (undefined4 ***)0x6edd9b;
    FUN_006ab660();
    pppuStack_57c = (undefined4 ***)0x6edda6;
    puVar11 = (undefined *)FUN_006ace40();
    pppuStack_57c = (undefined4 ***)0x6eddb3;
    param_2 = (undefined **)FUN_006ace40();
    pppuStack_57c = (undefined4 ***)auStack_4c;
    pppuStack_580 = (undefined4 ***)0x6eddc5;
    FUN_006acbd0();
    uStack_8._0_1_ = 0x2b;
    uVar12 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x2b;
    if (*(int *)(param_1 + 0x1d68) == 0) {
      pppuStack_57c = (undefined4 ***)0x18e119c;
                    /* WARNING: Subroutine does not return */
      pppuStack_580 = (undefined4 ***)&switchD_006ed2b2::switchdataD_006eded4;
      uStack_8._0_1_ = uVar12;
      FUN_016757c0();
    }
    if ((*(uint *)(param_1 + 0x37ac) & 0x80000000) == 0) {
      pppuStack_57c = apppuStack_34;
      pppuStack_580 = (undefined4 ***)0x6eddf5;
      FUN_006acbd0();
      pppuStack_57c = (undefined4 ***)auStack_4c;
      pppuStack_580 = apppuStack_34;
      uStack_8._0_1_ = 0x2c;
      pppuStack_584 = (undefined4 ***)0x6ede0c;
      cVar2 = FUN_006862e0();
      if (cVar2 == '\0') {
        pppuStack_57c = (undefined4 ***)0x18cb4ac;
                    /* WARNING: Subroutine does not return */
        pppuStack_580 = (undefined4 ***)0x6edeca;
        FUN_016757c0();
      }
      uStack_8._0_1_ = 0x2b;
      pppuStack_57c = (undefined4 ***)0x6ede20;
      FUN_005507b0();
      uVar12 = (undefined)uStack_8;
    }
    uStack_8._0_1_ = uVar12;
    pppuStack_57c = (undefined4 ***)auStack_4c;
    pppuStack_580 = (undefined4 ***)&uStack_1c;
    pppuStack_584 = (undefined4 ***)0x6ede2d;
    pppuStack_57c = (undefined4 ***)FUN_008869b0();
    uStack_8._0_1_ = 0x2d;
    pppuStack_580 = (undefined4 ***)0x6ede3d;
    FUN_00886840();
    pppuStack_57c = (undefined4 ***)0x6ede45;
    FUN_0056cd30();
    pppuStack_57c = (undefined4 ***)0x6ede4d;
    FUN_0056cd30();
    pppuStack_57c = (undefined4 ***)0x6ede55;
    FUN_005507b0();
    uStack_8._0_1_ = 2;
    pppuStack_57c = (undefined4 ***)0x6ede64;
    FUN_00613200();
    pppuStack_57c = (undefined4 ***)auStack_7c;
    *(undefined **)(param_1 + 0x3c84) = puVar11;
    pppuStack_580 = (undefined4 ***)param_2;
    pppuStack_588 = (undefined4 ****)0x6ede7a;
    pppuStack_584 = (undefined4 ***)puVar11;
    FUN_006ee0c0();
    uVar4 = 1;
  }
  pppuStack_57c = (undefined4 ***)0x6ede93;
  FUN_0056cd30();
  pppuStack_57c = (undefined4 ***)0x6ede9b;
  FUN_0056cd30();
LAB_006ede9b:
  uStack_8 = 0x2f;
  pppuStack_580 = (undefined4 ***)0x6edea8;
  pppuStack_57c = (undefined4 ***)uVar3;
  FUN_01675290();
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 9572 ; VA 0x006edf80 ; FUN_006edf80 */

void __thiscall FUN_006edf80(int *param_1,int param_2)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  
  iVar2 = param_1[1];
  iVar3 = *param_1;
  puVar4 = (undefined4 *)FUN_00578020(param_2);
  puVar7 = (undefined4 *)param_1[1];
  puVar6 = (undefined4 *)*param_1;
  puVar8 = puVar4;
  if (puVar6 != puVar7) {
    do {
      *puVar8 = *puVar6;
      puVar1 = puVar6 + 1;
      puVar6 = puVar6 + 2;
      puVar8[1] = *puVar1;
      puVar8 = puVar8 + 2;
    } while (puVar6 != puVar7);
    puVar6 = (undefined4 *)*param_1;
  }
  if (puVar6 != (undefined4 *)0x0) {
    uVar5 = param_1[2] - (int)puVar6 & 0xfffffff8;
    puVar7 = puVar6;
    if (0xfff < uVar5) {
      puVar7 = (undefined4 *)puVar6[-1];
      uVar5 = uVar5 + 0x23;
      if (0x1f < (uint)((int)puVar6 + (-4 - (int)puVar7))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar7,uVar5);
  }
  *param_1 = (int)puVar4;
  param_1[1] = (int)(puVar4 + (iVar2 - iVar3 >> 3) * 2);
  param_1[2] = (int)(puVar4 + param_2 * 2);
  return;
}



/* FUNCTION 9573 ; VA 0x006ee020 ; FUN_006ee020 */

uint __fastcall FUN_006ee020(int param_1)

{
  int iVar1;
  int iVar2;
  uint in_EAX;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0x34);
  if (iVar1 != 0) {
    iVar2 = *(int *)(iVar1 + 0xc);
    iVar3 = FUN_005edc10();
    in_EAX = (uint)*(ushort *)(iVar3 + 0x1da);
    if (((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <= in_EAX) &&
       ((in_EAX = *(uint *)(iVar1 + 0x43c), in_EAX == 2 || (in_EAX == 1)))) {
      return CONCAT31((int3)(in_EAX >> 8),1);
    }
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 9574 ; VA 0x006ee070 ; FUN_006ee070 */

undefined __fastcall FUN_006ee070(int param_1)

{
  return *(undefined *)(param_1 + 0x3b8c);
}



/* FUNCTION 9575 ; VA 0x006ee080 ; FUN_006ee080 */

bool FUN_006ee080(int param_1)

{
  return param_1 < 0x25;
}



/* FUNCTION 9576 ; VA 0x006ee090 ; FUN_006ee090 */

bool __fastcall FUN_006ee090(int param_1)

{
  char cVar1;
  int iStack_8;
  
  iStack_8 = param_1;
  FUN_00b07ca0(&iStack_8);
  cVar1 = FUN_00a33d60(param_1 + 0x3b88);
  return cVar1 == '\0';
}



/* FUNCTION 9577 ; VA 0x006ee0c0 ; FUN_006ee0c0 */

void __thiscall FUN_006ee0c0(int param_1,int *param_2,int param_3,undefined4 param_4)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  undefined4 uVar8;
  undefined2 uVar9;
  undefined auStack_74 [40];
  undefined auStack_4c [24];
  undefined auStack_34 [12];
  undefined auStack_28 [4];
  int *piStack_24;
  undefined8 uStack_20;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9f48;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff80;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  iVar5 = FUN_005ef0f0(param_1);
  if (iVar5 == 0) {
    ExceptionList = pvStack_10;
    return;
  }
  iVar5 = (int)param_2;
  if ((DAT_01d5b288 == '\0') && (cVar4 = FUN_0094a8c0(), iVar5 = (int)param_2, cVar4 == '\0')) {
    FUN_0095c640(param_2,1);
  }
  uStack_8 = 0;
  FUN_00569550(2,(int)&param_2 + 3);
  iVar3 = param_3;
  uStack_8._0_1_ = 1;
  uStack_20 = (double)param_3 + (double)(&DAT_018c0d90)[-(param_3 >> 0x1f)];
  FUN_0063d540(&uStack_20);
  uStack_20 = (double)iVar5 + (double)(&DAT_018c0d90)[-(iVar5 >> 0x1f)];
  FUN_0063d540(&uStack_20);
  uStack_20 = 0.0;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (DAT_01d64500 == '\0') {
    FUN_01255470(2,0,0,0);
    uVar6 = FUN_0094ed20(auStack_28,auStack_4c,param_4,"challenge",auStack_34);
    FUN_005587e0(uVar6);
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_24[1] + -1;
      piStack_24[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar5 = piStack_24[2] + -1;
        piStack_24[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
  }
  else {
    FUN_01255470(2,0,0,0);
    uVar6 = FUN_0094b5d0(auStack_28,auStack_4c,param_4,"challenge",auStack_34);
    FUN_005587e0(uVar6);
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_24[1] + -1;
      piStack_24[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar5 = piStack_24[2] + -1;
        piStack_24[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
  }
  piVar7 = (int *)*(int *)uStack_20;
  if (piVar7 != (int *)((int *)uStack_20)[1]) {
    param_2 = (int *)*piVar7;
    iVar5 = FUN_0088ca00();
    if ((param_2 == (int *)iVar5) && (piVar7[1] != 0)) {
      piVar7 = piVar7 + 2;
      goto LAB_006ee284;
    }
  }
  piVar7 = (int *)0x0;
LAB_006ee284:
  if (piVar7 == (int *)0x0) {
    piVar7 = uStack_20._4_4_;
    if (uStack_20._4_4_ != (int *)0x0) {
      LOCK();
      iVar5 = uStack_20._4_4_[1] + -1;
      uStack_20._4_4_[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*uStack_20._4_4_)();
        LOCK();
        piVar1 = piVar7 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_00577b20();
    ExceptionList = pvStack_10;
    return;
  }
  param_3 = FUN_016f3eb1();
  piVar7 = uStack_20._4_4_;
  if (uStack_20._4_4_ != (int *)0x0) {
    LOCK();
    iVar5 = uStack_20._4_4_[1] + -1;
    uStack_20._4_4_[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*uStack_20._4_4_)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00577b20();
  uStack_8 = 0xffffffff;
  FUN_006ab530();
  uStack_8 = 6;
  param_2 = (int *)CONCAT31(param_2._1_3_,0x9b);
  FUN_006ad5e0(&param_2,1);
  param_2 = (int *)iVar3;
  FUN_006a5c10(&param_2,&param_4,4);
  FUN_006ad5e0(&param_4,4);
  param_4 = param_3;
  FUN_006a5c10(&param_4,&param_3,4);
  FUN_006ad5e0(&param_3,4);
  param_2 = (int *)FUN_0054db20();
  pcVar2 = *(code **)(*param_2 + 0x4c);
  FUN_005f70a0();
  FUN_005f7140();
  uVar6 = DAT_01d5ba38;
  uVar8 = DAT_01d5ba3c;
  uVar9 = DAT_01d5ba40;
  FUN_005f7170(iStack_18 + 0x74);
  (*pcVar2)(auStack_74,2,3,0,uVar6,uVar8,uVar9);
  FUN_00613200();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9578 ; VA 0x006ee3f7 ; Catch_All@006ee3f7 */

undefined4 Catch_All_006ee3f7(void)

{
  return 0x6ee2b9;
}



/* FUNCTION 9579 ; VA 0x006ee400 ; FUN_006ee400 */

void __thiscall FUN_006ee400(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9f6f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_005efdb0(param_2);
  iVar2 = FUN_01674e20(0x38);
  uStack_8 = 0;
  if (iVar2 == 0) {
    uVar1 = 0;
  }
  else {
    uVar1 = FUN_0071a1c0(param_1,param_2,uVar1);
  }
  uStack_8 = 0xffffffff;
  FUN_006b1f50(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9580 ; VA 0x006ee480 ; FUN_006ee480 */

undefined4 * __thiscall
FUN_006ee480(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a9fb1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_006ef180;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9581 ; VA 0x006ee620 ; FUN_006ee620 */

undefined4 * __thiscall
FUN_006ee620(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a9ff1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_006ef2d0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9582 ; VA 0x006ee7c0 ; FUN_006ee7c0 */

void FUN_006ee7c0(int *param_1)

{
  undefined8 uStack_1c;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  int iStack_8;
  
  uStack_1c = CONCAT44(param_1[1] * 0x10,*param_1 * 0x10);
  iStack_10 = *param_1 * 0x10 + 0x10;
  iStack_c = param_1[1] * 0x10 + 0x10;
  iStack_14 = param_1[2] * 0x10;
  iStack_8 = iStack_14 + 0x10;
  FUN_00a71530(&uStack_1c);
  return;
}



/* FUNCTION 9583 ; VA 0x006ee820 ; FUN_006ee820 */

undefined4 * __thiscall FUN_006ee820(undefined4 param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa008;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_0060dcd0(auStack_20,param_1);
  uStack_8 = 0;
  puVar4 = (undefined4 *)FUN_006eb0e0(auStack_18,uVar3);
  *param_2 = *puVar4;
  uVar3 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_2[1] = uVar3;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar2 = piStack_14[2] + -1;
      piStack_14[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9584 ; VA 0x006ee8e0 ; FUN_006ee8e0 */

undefined4 __thiscall FUN_006ee8e0(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c3f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675290(DAT_01eadc98);
  uStack_8 = 0;
  FUN_0067bd30();
  if ((*(uint *)(param_1 + 0x3808) & 2) != 0) {
    FUN_006ef540();
  }
  uVar2 = FUN_0061a360(param_2);
  uStack_8 = 1;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 9585 ; VA 0x006ee970 ; FUN_006ee970 */

void __thiscall FUN_006ee970(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 auStack_1b4 [50];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar1 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  puVar4 = *(undefined4 **)(param_1 + 0x40);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar3 = 2;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar4;
    iStack_e8 = FUN_005c9cc0();
    puStack_18 = &uStack_ec;
    uVar3 = 1;
  }
  uStack_8 = (uint)(puVar4 == (undefined4 *)0x0);
  uStack_14 = uVar3;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar2,uVar1,puStack_18);
  if ((uVar3 & 2) != 0) {
    uVar3 = uVar3 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar3;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar3 & 1) != 0) {
    uVar3 = uVar3 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar3;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 5;
    uVar3 = uVar3 | 8;
  }
  else {
    uStack_1bc = FUN_0088c8c0();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar4;
    iStack_1b8 = FUN_005c9cc0();
    puVar4 = &uStack_1bc;
    uStack_8 = 4;
    uVar3 = uVar3 | 4;
  }
  uStack_14 = uVar3;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar2,uVar1,puVar4);
  if ((uVar3 & 8) != 0) {
    uVar3 = uVar3 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar3;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar3 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9586 ; VA 0x006eeb90 ; FUN_006eeb90 */

undefined4 * __thiscall
FUN_006eeb90(undefined4 param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined8 uVar6;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017aa04d;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaf3e8) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eaf3e8), DAT_01eaf3e8 == -1)) {
    uStack_8 = 1;
    uVar6 = FUN_0152dab0(&DAT_018c5904,"deserializeItem",0xffffffff);
    DAT_01eaf3e4 = (undefined4)((ulonglong)uVar6 >> 0x20);
    DAT_01eaf3e0 = (undefined4)uVar6;
    uStack_8 = uStack_8 & 0xffffff00;
    FUN_016f37bf(&DAT_01eaf3e8);
  }
  uStack_1c = DAT_01eaf3e0;
  uStack_18 = DAT_01eaf3e4;
  uVar6 = FUN_0152d930(DAT_01eaf3e0,DAT_01eaf3e4);
  uStack_8 = 2;
  *param_2 = 0;
  param_2[1] = 0;
  uStack_14 = 1;
  switch(param_4) {
  case 9:
    uVar4 = FUN_0071a6d0(auStack_24,param_1,param_3);
    break;
  default:
    puVar5 = (undefined4 *)FUN_0061b020(auStack_24,param_3,param_4);
    goto LAB_006eed2d;
  case 0xb:
    if (DAT_01d5af48 == '\0') {
LAB_006eed00:
      uVar4 = FUN_0061b020(auStack_24,param_3,param_4);
    }
    else {
      uVar4 = FUN_006c30d0(auStack_24,param_1,param_3);
    }
    break;
  case 0xd:
    puVar5 = (undefined4 *)FUN_006e6e20(auStack_24,param_1,param_3);
    goto LAB_006eed2d;
  case 0x10:
    uVar4 = FUN_00703400(auStack_24,param_1,param_3);
    break;
  case 0x11:
    uVar4 = FUN_00700ed0(auStack_24,param_1,param_3);
    break;
  case 0x14:
    puVar5 = (undefined4 *)FUN_006e6d30(auStack_24,param_1,param_3);
    goto LAB_006eed2d;
  case 0x16:
    if (DAT_01d5af48 == '\0') goto LAB_006eed00;
    uVar4 = FUN_006f9b40(auStack_24,param_1,param_3);
    break;
  case 0x18:
    puVar5 = (undefined4 *)FUN_006e6fa0(auStack_24,param_1,param_3);
    goto LAB_006eed2d;
  case 0x19:
    puVar5 = (undefined4 *)FUN_006e7090(auStack_24,param_1,param_3);
LAB_006eed2d:
    uVar4 = *puVar5;
    uVar1 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    *param_2 = uVar4;
    piVar2 = (int *)param_2[1];
    param_2[1] = uVar1;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_20[1] + -1;
      piStack_20[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar2 = piStack_20 + 2;
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    goto LAB_006eed92;
  }
  FUN_005587e0(uVar4);
  FUN_00550b30();
LAB_006eed92:
  uStack_8 = 3;
  FUN_0152dda0(uStack_1c,uStack_18,uVar6);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9587 ; VA 0x006eee60 ; FUN_006eee60 */

void FUN_006eee60(undefined4 param_1,undefined *param_2)

{
  undefined uVar1;
  
  uVar1 = FUN_006abd90();
  *param_2 = uVar1;
  return;
}



/* FUNCTION 9588 ; VA 0x006eee80 ; FUN_006eee80 */

void __thiscall FUN_006eee80(int param_1,int param_2)

{
  char cVar1;
  char *pcVar2;
  undefined uVar3;
  short sVar4;
  char *pcVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint auStack_54 [4];
  undefined4 uStack_44;
  uint uStack_40;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined auStack_24 [8];
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa080;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  sVar4 = FUN_006acdc0();
  if (sVar4 != 0) {
    iStack_18 = param_1 + 0x19fc;
    do {
      sVar4 = sVar4 + -1;
      FUN_0071e090();
      uStack_8 = 0;
      FUN_0071e090();
      uStack_8._0_1_ = 1;
      FUN_006ac870(&iStack_14);
      FUN_006ac870(&param_2);
      pcVar2 = *(char **)(iStack_14 + 0x10);
      uStack_2c = 0;
      uStack_28 = 0xf;
      auStack_3c[0] = auStack_3c[0] & 0xffffff00;
      pcVar5 = pcVar2;
      do {
        cVar1 = *pcVar5;
        pcVar5 = pcVar5 + 1;
      } while (cVar1 != '\0');
      FUN_005542c0(pcVar2,(int)pcVar5 - (int)(pcVar2 + 1));
      uStack_8._0_1_ = 2;
      pcVar2 = *(char **)(param_2 + 0x10);
      uStack_44 = 0;
      uStack_40 = 0xf;
      auStack_54[0] = auStack_54[0] & 0xffffff00;
      pcVar5 = pcVar2;
      do {
        cVar1 = *pcVar5;
        pcVar5 = pcVar5 + 1;
      } while (cVar1 != '\0');
      FUN_005542c0(pcVar2,(int)pcVar5 - (int)(pcVar2 + 1));
      uStack_8._0_1_ = 3;
      FUN_01678450(auStack_3c,auStack_54);
      FUN_00676530(auStack_24,auStack_3c,auStack_3c);
      uStack_8._0_1_ = 2;
      uVar3 = (undefined)uStack_8;
      uStack_8._0_1_ = 2;
      if (0xf < uStack_40) {
        uVar8 = uStack_40 + 1;
        uVar7 = auStack_54[0];
        if (0xfff < uVar8) {
          uVar7 = *(uint *)(auStack_54[0] - 4);
          uVar8 = uStack_40 + 0x24;
          if (0x1f < (auStack_54[0] - uVar7) - 4) goto LAB_006ef070;
        }
        FUN_01674ea0(uVar7,uVar8);
      }
      uStack_44 = 0;
      uStack_40 = 0xf;
      auStack_54[0] = auStack_54[0] & 0xffffff00;
      uStack_8._0_1_ = 1;
      if (0xf < uStack_28) {
        uVar8 = uStack_28 + 1;
        uVar7 = auStack_3c[0];
        if (0xfff < uVar8) {
          uVar7 = *(uint *)(auStack_3c[0] - 4);
          uVar8 = uStack_28 + 0x24;
          uVar3 = (undefined)uStack_8;
          if (0x1f < (auStack_3c[0] - uVar7) - 4) {
LAB_006ef070:
            uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar7,uVar8);
      }
      uStack_2c = 0;
      uStack_28 = 0xf;
      auStack_3c[0] = auStack_3c[0] & 0xffffff00;
      FUN_0071e0a0();
      uStack_8 = 0xffffffff;
      FUN_0071e0a0();
      param_1 = iStack_1c;
    } while (sVar4 != 0);
  }
  *(undefined *)(param_1 + 0x19f8) = 1;
  FUN_016780d0();
  iVar6 = FUN_008f7870(param_1);
  if (iVar6 != 0) {
    FUN_0090afc0(1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9589 ; VA 0x006ef080 ; FUN_006ef080 */

void __thiscall FUN_006ef080(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0x34) + param_2 != 0) {
    FUN_016795b0();
  }
  return;
}



/* FUNCTION 9590 ; VA 0x006ef0a0 ; FUN_006ef0a0 */

int FUN_006ef0a0(undefined4 param_1,int *param_2,uint param_3,uint param_4,uint param_5,uint param_6
                ,undefined4 param_7,uint param_8,uint param_9)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined4 uVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017aa0a7;
  pvStack_10 = ExceptionList;
  uVar3 = param_3 & 0xff;
  iStack_8 = 0;
  param_4 = param_4 ^ *(uint *)(&DAT_02153020 + uVar3 * 0x18);
  param_5 = param_5 ^ *(uint *)(&DAT_02153024 + uVar3 * 0x18);
  param_6 = param_6 ^ *(uint *)(&DAT_02153028 + uVar3 * 0x18);
  param_8 = param_8 ^ *(uint *)(&DAT_02153030 + uVar3 * 0x18);
  param_9 = param_9 ^ *(uint *)(&DAT_02153034 + uVar3 * 0x18);
  ExceptionList = &pvStack_10;
  uVar4 = FUN_00718860(&param_4);
  iVar5 = FUN_01674e20(0x48);
  iStack_8._0_1_ = 1;
  if (iVar5 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_0071a220(param_1,uVar4,param_8,param_9,param_3);
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  iVar5 = FUN_006b1f50(uVar4);
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 9591 ; VA 0x006ef180 ; FUN_006ef180 */

int FUN_006ef180(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  int *piStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aa0f1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 1;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_f0 = FUN_008881d0();
  uStack_ec = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_e8 = param_2;
  piStack_e4 = param_3;
  uStack_ec = FUN_0058c000();
  uStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,pcVar3);
  uStack_8._0_1_ = 3;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 4;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  iVar5 = FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 9592 ; VA 0x006ef2d0 ; FUN_006ef2d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_006ef2d0(int param_1,undefined param_2,int param_3)

{
  code *pcVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  uint in_stack_00000020;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined uStack_1b8;
  undefined4 uStack_f0;
  undefined *puStack_ec;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aa13c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 1;
  pcVar1 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar2;
  uStack_1c0 = FUN_0088daf0();
  uStack_1bc = 0;
  uStack_1b8 = param_2;
  uStack_1bc = FUN_005c9ef0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uStack_f0 = FUN_0088cb40();
  puStack_ec = (undefined *)0x0;
  FUN_0054ef60(&param_3);
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c48) {
    FUN_016f3809(&DAT_01ea8c48);
    if (DAT_01ea8c48 == -1) {
      _DAT_01ea8c3c = FUN_005c65f0;
      _DAT_01ea8c40 = FUN_005c93a0;
      DAT_01ea8c44 = FUN_005c77b0;
      FUN_016f37bf(&DAT_01ea8c48);
    }
  }
  puStack_ec = &DAT_01ea8c3c;
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,pcVar1);
  uStack_8._0_1_ = 4;
  (*pcVar1)(&uStack_1c);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_01675290(uVar2);
  if (0xf < in_stack_00000020) {
    uVar4 = in_stack_00000020 + 1;
    iVar3 = param_3;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(param_3 + -4);
      uVar4 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9593 ; VA 0x006ef4a0 ; FUN_006ef4a0 */

undefined4 __thiscall FUN_006ef4a0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  iVar1 = FUN_01256300(param_3);
  uVar2 = FUN_009d05b0(param_3,param_4,2,iVar1 - param_4,param_1 + 0x44);
  uVar3 = FUN_009d05b0(param_3,param_4,1,iVar1 - param_4,param_1 + 0x40);
  (**(code **)(param_1 + 0x38))(uVar3,uVar2);
  return 0;
}



/* FUNCTION 9594 ; VA 0x006ef500 ; FUN_006ef500 */

undefined4 __thiscall FUN_006ef500(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined uVar1;
  int iVar2;
  
  iVar2 = FUN_01256300(param_3);
  uVar1 = FUN_009d1aa0(param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  (**(code **)(param_1 + 0x38))(uVar1);
  return 0;
}



/* FUNCTION 9595 ; VA 0x006ef540 ; FUN_006ef540 */

void __fastcall FUN_006ef540(undefined4 *param_1)

{
  uint *puVar1;
  int *piVar2;
  byte bVar3;
  undefined4 *puVar4;
  double *pdVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  byte *pbVar12;
  int *piVar13;
  double dVar14;
  undefined8 uVar15;
  undefined auStack_44 [8];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  uint *puStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  undefined4 *puStack_20;
  uint uStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017a4908;
  pvStack_10 = ExceptionList;
  piStack_2c = param_1 + 8;
  puVar1 = param_1 + 0xd;
  ExceptionList = &pvStack_10;
  puStack_30 = puVar1;
  puStack_20 = param_1;
  while( true ) {
    puVar4 = puStack_20;
    piVar13 = piStack_2c;
    uStack_3c = *puStack_20;
    uStack_38 = puStack_20[1];
    do {
      LOCK();
      uVar10 = *puVar1;
      *puVar1 = *puVar1 | 1;
      UNLOCK();
      uStack_8 = (uint)((uVar10 & 1) != 0);
    } while (uStack_8 != 0);
    if (piStack_2c[4] == 0) break;
    pdVar5 = (double *)FUN_01682800(auStack_44);
    if ((piVar13 == (int *)0x0) || ((int *)*piVar13 == (int *)0x0)) {
      iVar6 = 0;
    }
    else {
      iVar6 = *(int *)*piVar13;
    }
    dVar14 = *(double *)
              (*(int *)(*(int *)(iVar6 + 4) + (*(int *)(iVar6 + 8) - 1U & piVar13[3]) * 4) + 8) +
             (double)CONCAT44(uStack_38,uStack_3c);
    if (*pdVar5 <= dVar14 && dVar14 != *pdVar5) break;
    if ((piVar13 == (int *)0x0) || ((int *)*piVar13 == (int *)0x0)) {
      iVar6 = 0;
    }
    else {
      iVar6 = *(int *)*piVar13;
    }
    piStack_18 = (int *)**(int **)(*(int *)(iVar6 + 4) + (*(int *)(iVar6 + 8) - 1U & piVar13[3]) * 4
                                  );
    piVar2 = piVar13 + 4;
    *piVar2 = *piVar2 + -1;
    if (*piVar2 == 0) {
      piVar13[3] = 0;
      uVar10 = 0;
    }
    else {
      piVar13[3] = piVar13[3] + 1;
      uVar10 = piVar13[3];
    }
    if (piVar13[4] == 0) {
      uVar15 = 0;
    }
    else {
      puVar7 = (undefined4 *)*piVar13;
      if (puVar7 != (undefined4 *)0x0) {
        puVar7 = (undefined4 *)*puVar7;
      }
      uVar15 = *(undefined8 *)(*(int *)(puVar7[1] + (puVar7[2] - 1 & uVar10) * 4) + 8);
    }
    *(undefined8 *)(piVar13 + 6) = uVar15;
    uStack_8 = 0xffffffff;
    pbVar12 = (byte *)(puVar4 + 2);
    *puVar1 = 0;
    bVar3 = *pbVar12;
    uStack_1c = FUN_005702d0(piStack_18);
    FUN_009c91c0(&uStack_1c,(int)piStack_18 + 0x18);
    uStack_1c = uStack_1c ^
                *(int *)((int)piStack_18 + 0x1c) + -0x61c88647 + uStack_1c * 0x40 + (uStack_1c >> 2)
    ;
    FUN_006ebd40(&piStack_24,uStack_1c,piStack_18,
                 -(uint)(pbVar12 + bVar3 + 1 != (byte *)0x0) & (uint)(pbVar12 + bVar3 + 1 + 1));
    piStack_34 = piStack_24;
    piStack_28 = (int *)*piStack_24;
    uVar10 = (uint)piStack_24[1] % (uint)puStack_20[3];
    piStack_18 = *(int **)(puStack_20[7] + uVar10 * 4);
    for (piVar13 = (int *)*piStack_18; piVar13 != piStack_24; piVar13 = (int *)*piVar13) {
      piStack_18 = piVar13;
    }
    do {
      *piStack_18 = *piVar13;
      uVar11 = piVar13[7];
      if (0xf < uVar11) {
        iVar6 = piVar13[2];
        uVar9 = uVar11 + 1;
        iVar8 = iVar6;
        if (0xfff < uVar9) {
          iVar8 = *(int *)(iVar6 + -4);
          uVar9 = uVar11 + 0x24;
          if (0x1f < (iVar6 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar8,uVar9);
      }
      piVar13[6] = 0;
      piVar13[7] = 0xf;
      *(undefined *)(piVar13 + 2) = 0;
      FUN_01674ea0(piVar13,0x40);
      puStack_20[4] = puStack_20[4] + -1;
      uVar11 = uVar10;
      if (*piStack_18 == 0) {
LAB_006ef768:
        if (*(int **)(puStack_20[7] + uVar10 * 4) == piStack_18) {
          *(undefined4 *)(puStack_20[7] + uVar10 * 4) = 0;
        }
      }
      else {
        uVar11 = *(uint *)(*piStack_18 + 4) % (uint)puStack_20[3];
        if (uVar10 != uVar11) {
          *(int **)(puStack_20[7] + uVar11 * 4) = piStack_18;
          goto LAB_006ef768;
        }
      }
      piVar13 = (int *)*piStack_18;
      uVar10 = uVar11;
    } while (piVar13 != piStack_28);
  }
  *puVar1 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9596 ; VA 0x006ef7b0 ; FUN_006ef7b0 */

int __thiscall FUN_006ef7b0(int param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar1 = FUN_0061d9f0(param_2,param_3);
  if ((*(char *)(param_1 + 0x37f8) != '\0') && (iVar1 == 0)) {
    iVar3 = *(int *)(param_2 + 0xc);
    iVar2 = FUN_0099be20();
    iVar4 = 0;
    if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      iVar4 = param_2;
    }
    if ((iVar4 != 0) && (iVar3 = FUN_009b7250(), iVar3 == 0)) {
      return 1;
    }
  }
  return iVar1;
}



/* FUNCTION 9597 ; VA 0x006ef820 ; FUN_006ef820 */

undefined4 __thiscall FUN_006ef820(int *param_1,int param_2,undefined4 *param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  
  if ((DAT_01d65718 != '\0') &&
     (((param_3 == &DAT_01ef0a50 || (param_3 == &DAT_01ee5728)) && (param_2 != 0)))) {
    iVar1 = *(int *)(param_2 + 0xc);
    iVar3 = FUN_00ae2430();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) {
      cVar2 = (**(code **)(*param_1 + 0x11c))();
      if ((cVar2 != '\0') && (param_1[0x770] != 0)) {
        iVar1 = *(int *)(param_1[0x770] + 0xf4);
        iVar3 = FUN_00ae43a0();
        if (iVar3 == iVar1) {
          return 1;
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 9598 ; VA 0x006ef8b0 ; FUN_006ef8b0 */

undefined4 FUN_006ef8b0(int param_1)

{
  if (*(char *)(param_1 + 0x22) != '\0') {
    FUN_0086f2f0(2,"trying to set locked parent!");
    return 1;
  }
  return 0;
}



/* FUNCTION 9599 ; VA 0x006ef8e0 ; FUN_006ef8e0 */

undefined4 __thiscall FUN_006ef8e0(byte *param_1,undefined4 param_2,int param_3)

{
  byte bVar1;
  byte *pbStack_8;
  
  bVar1 = *param_1;
  pbStack_8 = param_1;
  pbStack_8 = (byte *)FUN_005702d0(param_3);
  FUN_009c91c0(&pbStack_8,param_3 + 0x18);
  FUN_006ebd40(param_2,*(int *)(param_3 + 0x1c) + -0x61c88647 +
                       (int)pbStack_8 * 0x40 + ((uint)pbStack_8 >> 2) ^ (uint)pbStack_8,param_3,
               -(uint)(param_1 + bVar1 + 1 != (byte *)0x0) & (uint)(param_1 + bVar1 + 1 + 1));
  return param_2;
}



/* FUNCTION 9600 ; VA 0x006ef950 ; FUN_006ef950 */

undefined4 __fastcall FUN_006ef950(int param_1)

{
  if (*(int *)(param_1 + 0x1dc0) != 0) {
    return *(undefined4 *)(*(int *)(param_1 + 0x1dc0) + 0xf4);
  }
  return 0;
}



/* FUNCTION 9601 ; VA 0x006ef970 ; FUN_006ef970 */

/* WARNING: Removing unreachable block (ram,0x006ef9db) */
/* WARNING: Removing unreachable block (ram,0x006ef9e9) */
/* WARNING: Removing unreachable block (ram,0x006efa13) */
/* WARNING: Removing unreachable block (ram,0x006ef9f9) */

void FUN_006ef970(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aa158;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_006ecd90(param_2,param_3,param_4,param_5,param_6,CONCAT44(param_8,param_7));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9602 ; VA 0x006efa20 ; FUN_006efa20 */

void FUN_006efa20(undefined4 param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa178;
  pvStack_10 = ExceptionList;
  param_2 = (int *)*param_2;
  iVar3 = *param_2;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_008881d0();
  if (iVar3 == iVar1) {
    piVar2 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar2 = (int *)0x0;
    }
    iVar3 = piVar2[1];
    if (iVar3 != 0) {
      LOCK();
      *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
      UNLOCK();
      iVar3 = piVar2[1];
    }
    uStack_8 = 0;
    FUN_006ecbd0(*piVar2,iVar3);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 9603 ; VA 0x006efac0 ; FUN_006efac0 */

void FUN_006efac0(undefined4 param_1,int *param_2)

{
  undefined uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  
  piVar2 = (int *)*param_2;
  iVar3 = *piVar2;
  iVar4 = FUN_0088daf0();
  if (iVar3 == iVar4) {
    piVar5 = piVar2 + 2;
    iVar3 = *param_2;
    if (piVar2[1] == 0) {
      piVar5 = (int *)0x0;
    }
    iVar4 = *(int *)(iVar3 + 0xd0);
    uVar1 = *(undefined *)piVar5;
    iVar6 = FUN_0088cb40();
    if (iVar4 == iVar6) {
      iVar4 = iVar3 + 0xd8;
      if (*(int *)(iVar3 + 0xd4) == 0) {
        iVar4 = 0;
      }
      FUN_0054ef60(iVar4);
      FUN_006ef970(param_1,CONCAT31((int3)((uint)piVar5 >> 8),uVar1));
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 9604 ; VA 0x006efb40 ; thunk_FUN_005ee450 */

void thunk_FUN_005ee450(void)

{
  int iVar1;
  
  if (DAT_01eaa59c == 0) {
    iVar1 = FUN_005edd10();
    DAT_01eaa59c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 9605 ; VA 0x006efb50 ; FUN_006efb50 */

undefined2 __fastcall FUN_006efb50(int param_1)

{
  if (*(int *)(param_1 + 0x3b94) != 0) {
    return *(undefined2 *)(*(int *)(param_1 + 0x3b94) + 0x1d4);
  }
  return 0;
}



/* FUNCTION 9606 ; VA 0x006efb70 ; FUN_006efb70 */

int __fastcall FUN_006efb70(int param_1)

{
  int iVar1;
  uint3 uVar2;
  
  iVar1 = *(int *)(param_1 + 0x3b94);
  uVar2 = (uint3)((uint)iVar1 >> 8);
  if (iVar1 != 0) {
    return CONCAT31(uVar2,*(undefined *)(iVar1 + 0x17b));
  }
  return (uint)uVar2 << 8;
}



/* FUNCTION 9607 ; VA 0x006efb90 ; FUN_006efb90 */

void __thiscall FUN_006efb90(int param_1,undefined4 *param_2)

{
  *param_2 = *(undefined4 *)(param_1 + 0x3b88);
  return;
}



/* FUNCTION 9608 ; VA 0x006efbb0 ; FUN_006efbb0 */

int __fastcall FUN_006efbb0(int param_1)

{
  int iVar1;
  uint3 uVar2;
  
  iVar1 = *(int *)(param_1 + 0x3b94);
  uVar2 = (uint3)((uint)iVar1 >> 8);
  if ((((DAT_01d5ba7c != '\0') || (*(int *)(iVar1 + 0x1b8) < 1)) &&
      (*(char *)(iVar1 + 0x1fc) == '\0')) && (4 < *(int *)(param_1 + 0x3c70))) {
    return CONCAT31(uVar2,1);
  }
  return (uint)uVar2 << 8;
}



/* FUNCTION 9609 ; VA 0x006efbe0 ; FUN_006efbe0 */

uint __fastcall FUN_006efbe0(int param_1)

{
  int iVar1;
  uint in_EAX;
  int iVar2;
  uint uVar3;
  
  if (*(int *)(param_1 + 0x34) != 0) {
    iVar1 = *(int *)(*(int *)(param_1 + 0x34) + 0xc);
    iVar2 = FUN_005edc10();
    in_EAX = (uint)*(ushort *)(iVar2 + 0x1da);
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <= in_EAX) {
      uVar3 = FUN_0068ba60();
      return uVar3;
    }
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 9610 ; VA 0x006efc20 ; FUN_006efc20 */

uint __fastcall FUN_006efc20(int param_1)

{
  int iVar1;
  int iVar2;
  uint in_EAX;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0x34);
  if (iVar1 != 0) {
    iVar2 = *(int *)(iVar1 + 0xc);
    iVar3 = FUN_005edc10();
    in_EAX = (uint)*(ushort *)(iVar3 + 0x1da);
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <= in_EAX) {
      return (uint)CONCAT11((char)(*(ushort *)(iVar3 + 0x1da) >> 8),*(int *)(iVar1 + 0x43c) == 1);
    }
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 9611 ; VA 0x006efc60 ; FUN_006efc60 */

undefined4 __thiscall FUN_006efc60(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x1a14) != 0) {
    iVar1 = FUN_00690650(param_2,param_3);
    if (iVar1 == 1) {
      return 0;
    }
  }
  return 1;
}



/* FUNCTION 9612 ; VA 0x006efc90 ; FUN_006efc90 */

undefined __thiscall FUN_006efc90(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined uVar3;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa198;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    iVar2 = *(int *)(param_2 + 0xc);
    ExceptionList = &pvStack_10;
    iVar1 = FUN_00c37c00();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
        (uint)*(ushort *)(iVar1 + 0x1da)) {
      ExceptionList = pvStack_10;
      return 0;
    }
  }
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  if (*(int *)(param_1 + 0x1a14) != 0) {
    iVar2 = FUN_00690930(param_2,*(undefined4 *)(param_2 + 0x34),&uStack_1c,0,0);
    if (iVar2 == 1) {
      uVar3 = 0;
      goto LAB_006efd31;
    }
  }
  uVar3 = 1;
LAB_006efd31:
  uStack_8 = 2;
  FUN_00617b40();
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 9613 ; VA 0x006efd60 ; FUN_006efd60 */

bool __thiscall FUN_006efd60(int *param_1,int param_2,undefined4 *param_3)

{
  char cVar1;
  int iVar2;
  int iVar3;
  
  if (param_1[0x685] != 0) {
    if (param_3 != &DAT_0211a3d8) {
      iVar2 = FUN_00690040(param_2,param_3);
      return iVar2 == 0;
    }
    iVar2 = FUN_00690ff0(param_2,*(undefined4 *)(param_2 + 0x34));
    return iVar2 == 0;
  }
  if ((((param_3 == &DAT_0211a3d8) && (param_2 != 0)) &&
      (iVar2 = *(int *)(param_2 + 0xc), iVar3 = FUN_00913630(),
      (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
      (uint)*(ushort *)(iVar3 + 0x1da))) && (*(int *)(param_2 + 0x34) != 0)) {
    return false;
  }
  if (((param_3 == &DAT_01ef0a50) || (param_3 == &DAT_01ee5728)) &&
     ((cVar1 = (**(code **)(*param_1 + 0x11c))(), cVar1 != '\0' &&
      (iVar2 = FUN_00606af0(param_2), iVar2 != 0)))) {
    iVar2 = FUN_00ae43a0();
    return iVar2 == 0;
  }
  return true;
}



/* FUNCTION 9614 ; VA 0x006efe40 ; FUN_006efe40 */

undefined FUN_006efe40(void)

{
  int iVar1;
  
  iVar1 = FUN_0061f4a0();
  if (iVar1 != 0) {
    return *(undefined *)(iVar1 + 0x88);
  }
  return 1;
}



/* FUNCTION 9615 ; VA 0x006efe60 ; FUN_006efe60 */

/* WARNING: Removing unreachable block (ram,0x006efed0) */

undefined * __thiscall
FUN_006efe60(int *param_1,undefined4 param_2,int *param_3,undefined *param_4,undefined *param_5)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  longlong lVar4;
  longlong lVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aa1b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  lVar4 = FUN_00928340();
  if (DAT_01d5aee0 == '\0') {
    iVar2 = (**(code **)(*param_1 + 0xb4))();
    *param_4 = 0;
    if (((iVar2 == 0) || (lVar4 < 1)) || (lVar5 = FUN_00928340(), lVar5 != lVar4)) {
      uVar3 = 0;
    }
    else {
      uVar3 = 1;
    }
    *param_5 = uVar3;
  }
  else {
    *param_4 = 0;
    param_5 = (undefined *)(**(code **)(*param_1 + 0xe8))(lVar4,param_4,param_5);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    param_5 = (undefined *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_5 = (undefined *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_5 = (undefined *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_5;
}



/* FUNCTION 9616 ; VA 0x006eff30 ; FUN_006eff30 */

void __thiscall
FUN_006eff30(int *param_1,int param_2,int param_3,undefined *param_4,undefined *param_5)

{
  int iVar1;
  longlong lVar2;
  
  iVar1 = (**(code **)(*param_1 + 0xb4))();
  *param_4 = 0;
  if ((((iVar1 != 0) && (-1 < param_3)) && ((0 < param_3 || (param_2 != 0)))) &&
     (lVar2 = FUN_00928340(), lVar2 == CONCAT44(param_3,param_2))) {
    *param_5 = 1;
    return;
  }
  *param_5 = 0;
  return;
}



/* FUNCTION 9617 ; VA 0x006eff80 ; FUN_006eff80 */

int __fastcall FUN_006eff80(int param_1)

{
  int iVar1;
  uint3 uVar2;
  
  iVar1 = *(int *)(param_1 + 0x3b94);
  uVar2 = (uint3)((uint)iVar1 >> 8);
  if (((*(int *)(iVar1 + 0x1b8) < 1) && (*(char *)(iVar1 + 0x1fc) == '\0')) &&
     (2 < *(int *)(param_1 + 0x3c70))) {
    return (uint)uVar2 << 8;
  }
  return CONCAT31(uVar2,1);
}



/* FUNCTION 9618 ; VA 0x006effb0 ; FUN_006effb0 */

void __thiscall FUN_006effb0(int param_1,int param_2)

{
  if (param_2 == 0xe) {
    *(undefined *)(param_1 + 0x1ec8) = 0;
  }
  return;
}



/* FUNCTION 9619 ; VA 0x006effd0 ; FUN_006effd0 */

void __thiscall FUN_006effd0(int *param_1,undefined4 param_2,undefined *param_3)

{
  int *piVar1;
  undefined *puVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined uVar7;
  undefined auStack_bc [12];
  undefined4 uStack_b0;
  char *pcStack_ac;
  undefined4 uStack_a8;
  uint uStack_a4;
  int iStack_a0;
  int *piStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined *puStack_90;
  undefined auStack_8c [4];
  undefined4 uStack_88;
  undefined *puStack_84;
  undefined *puStack_80;
  undefined8 uStack_7c;
  undefined auStack_68 [24];
  undefined auStack_50 [16];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined auStack_38 [24];
  int iStack_20;
  int *piStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa238;
  pvStack_10 = ExceptionList;
  iVar4 = param_1[0xee5];
  ExceptionList = &pvStack_10;
  if (iVar4 != 0) {
    piVar6 = (int *)param_1[0xee6];
    ExceptionList = &pvStack_10;
    if (piVar6 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      iVar4 = param_1[0xee5];
      piVar6 = (int *)param_1[0xee6];
    }
    uStack_8 = 0;
    uStack_98 = 0;
    uStack_94 = 0;
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
    }
    uStack_a4 = 0x6f0058;
    iStack_a0 = iVar4;
    piStack_9c = piVar6;
    iStack_20 = iVar4;
    piStack_1c = piVar6;
    FUN_0151dac0();
    uStack_8 = 0xffffffff;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar4 = piVar6[1] + -1;
      piVar6[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        uStack_7c._4_4_ = (int *)0x6f007a;
        (**(code **)*piVar6)();
        LOCK();
        iVar4 = piVar6[2] + -1;
        piVar6[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          uStack_7c._4_4_ = (int *)0x6f008a;
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    uStack_7c._4_4_ = (int *)0x6f0095;
    FUN_00712190();
    param_1[0xee5] = 0;
    piVar6 = (int *)param_1[0xee6];
    param_1[0xee6] = 0;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar4 = piVar6[1] + -1;
      piVar6[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        uStack_7c._4_4_ = (int *)0x6f00c2;
        (**(code **)*piVar6)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          uStack_7c._4_4_ = (int *)0x6f00d1;
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    uStack_7c._4_4_ = (int *)0x6f00db;
    iVar4 = (**(code **)(*param_1 + 0xb4))();
    if (iVar4 != 0) {
      uStack_7c._0_4_ = (char *)0x0;
      uStack_7c._4_4_ = (int *)0x0;
      puStack_80 = (undefined *)0x6f00f8;
      FUN_00934890();
    }
  }
  puVar2 = param_3;
  if ((DAT_01d5ba8c != '\0') && (param_3 == (undefined *)0x0)) {
    uStack_7c._4_4_ = (int *)0x6f011c;
    cVar3 = (**(code **)(*param_1 + 0x11c))();
    if (cVar3 != '\0') {
      uStack_7c._4_4_ = (int *)0x6f012e;
      iVar4 = (**(code **)(*param_1 + 0xb4))();
      if (iVar4 != 0) {
        uStack_7c._4_4_ = (int *)0x6f0143;
        puStack_14 = (undefined *)FUN_0054db20();
        uStack_7c._4_4_ = (int *)0x6f014d;
        puStack_18 = (undefined *)FUN_0061ec10();
        if ((0 < (int)puStack_14) || (0 < (int)puStack_18)) {
          uStack_7c._4_4_ = (int *)((int)&param_3 + 3);
          uStack_7c._0_4_ = (char *)((int)&param_3 + 3);
          puStack_80 = (undefined *)((int)&param_3 + 3);
          puStack_84 = (undefined *)0xb;
          uStack_88 = 0x6f0173;
          FUN_005d0b40();
          uStack_8 = 1;
          uStack_7c._4_4_ = (int *)0x6f0181;
          uStack_7c = FUN_00928340();
          puStack_84 = auStack_68;
          puStack_80 = &DAT_018bed48;
          uStack_88 = 0x6f0191;
          uVar5 = FUN_01675640();
          uStack_7c._4_4_ = (int *)0x6;
          uStack_7c._0_4_ = "userId";
          uStack_8._0_1_ = 2;
          uStack_40 = 0;
          uStack_3c = 0xf;
          auStack_50[0] = 0;
          puStack_80 = (undefined *)0x6f01bb;
          FUN_005542c0();
          uStack_7c._0_4_ = auStack_50;
          uStack_8._0_1_ = 3;
          puStack_80 = (undefined *)0x6f01cc;
          uStack_7c._4_4_ = (int *)uVar5;
          FUN_005d15d0();
          uStack_7c._0_4_ = (char *)0x6f01d4;
          FUN_005511f0();
          uStack_7c._4_4_ = (int *)0x6f01dc;
          FUN_005507b0();
          uStack_8._0_1_ = 1;
          uStack_7c._4_4_ = (int *)0x6f01e8;
          FUN_005507b0();
          uStack_7c._0_4_ = (char *)0x6f01ee;
          uStack_7c._4_4_ = param_1;
          iVar4 = FUN_008f7870();
          if (iVar4 != 0) {
            piVar6 = *(int **)(iVar4 + 0x43c);
            uStack_7c._4_4_ = (int *)(piVar6[1] - (int)piVar6);
            uStack_7c._0_4_ = (char *)(*piVar6 - (int)piVar6);
            puStack_84 = auStack_68;
            puStack_80 = &DAT_018bed48;
            uStack_88 = 0x6f0214;
            uVar5 = FUN_01675640();
            uStack_7c._4_4_ = (int *)0x7;
            uStack_7c._0_4_ = "placeId";
            uStack_8._0_1_ = 4;
            uStack_40 = 0;
            uStack_3c = 0xf;
            auStack_50[0] = 0;
            puStack_80 = (undefined *)0x6f023e;
            FUN_005542c0();
            uStack_7c._0_4_ = auStack_50;
            uStack_8._0_1_ = 5;
            puStack_80 = (undefined *)0x6f024f;
            uStack_7c._4_4_ = (int *)uVar5;
            FUN_005d15d0();
            uStack_7c._0_4_ = (char *)0x6f0257;
            FUN_005511f0();
            uStack_7c._4_4_ = (int *)0x6f025f;
            FUN_005507b0();
            uStack_8._0_1_ = 1;
            uStack_7c._4_4_ = (int *)0x6f026b;
            FUN_005507b0();
          }
          uStack_7c._4_4_ = (int *)puStack_14;
          puStack_80 = auStack_68;
          uStack_7c._0_4_ = &DAT_018bed68;
          puStack_84 = (undefined *)0x6f027c;
          uVar5 = FUN_01675640();
          uStack_7c._4_4_ = (int *)0xc;
          uStack_7c._0_4_ = "pendingItems";
          uStack_8._0_1_ = 6;
          uStack_40 = 0;
          uStack_3c = 0xf;
          auStack_50[0] = 0;
          puStack_80 = (undefined *)0x6f02a6;
          FUN_005542c0();
          uStack_7c._0_4_ = auStack_50;
          uStack_8._0_1_ = 7;
          puStack_80 = (undefined *)0x6f02b7;
          uStack_7c._4_4_ = (int *)uVar5;
          FUN_005d15d0();
          uStack_7c._0_4_ = (char *)0x6f02bf;
          FUN_005511f0();
          uStack_7c._4_4_ = (int *)0x6f02c7;
          FUN_005507b0();
          uStack_8._0_1_ = 1;
          uStack_7c._4_4_ = (int *)0x6f02d3;
          FUN_005507b0();
          uStack_7c._4_4_ = (int *)puStack_18;
          puStack_80 = auStack_68;
          uStack_7c._0_4_ = &DAT_018bed68;
          puStack_84 = (undefined *)0x6f02e4;
          uVar5 = FUN_01675640();
          uStack_7c._4_4_ = (int *)0x14;
          uStack_7c._0_4_ = "pendingClusterDeltas";
          uStack_8._0_1_ = 8;
          uStack_40 = 0;
          uStack_3c = 0xf;
          auStack_50[0] = 0;
          puStack_80 = (undefined *)0x6f030e;
          FUN_005542c0();
          uStack_7c._0_4_ = auStack_50;
          uStack_8._0_1_ = 9;
          puStack_80 = (undefined *)0x6f031f;
          uStack_7c._4_4_ = (int *)uVar5;
          FUN_005d15d0();
          uStack_7c._0_4_ = (char *)0x6f0327;
          FUN_005511f0();
          uStack_7c._4_4_ = (int *)0x6f032f;
          FUN_005507b0();
          uStack_8._0_1_ = 1;
          uStack_7c._4_4_ = (int *)0x6f033b;
          FUN_005507b0();
          param_3 = auStack_8c;
          puStack_18 = auStack_8c;
          puStack_90 = auStack_38;
          uStack_94 = 0x6f034f;
          FUN_0060e660();
          puStack_18 = (undefined *)&uStack_a4;
          uStack_8._0_1_ = 10;
          uStack_a8 = 0x12;
          uStack_94 = 0;
          puStack_90 = (undefined *)0xf;
          pcStack_ac = "ReplicationPending";
          uStack_a4 = uStack_a4 & 0xffffff00;
          uStack_b0 = 0x6f0378;
          FUN_005542c0();
          uStack_8._0_1_ = 0xb;
          puStack_14 = auStack_bc;
          pcStack_ac = (char *)0x0;
          uStack_a8 = 0xf;
          auStack_bc[0] = 0;
          FUN_005542c0("TeamCreate",10);
          uStack_8._0_1_ = 0xc;
          uVar7 = 0;
          FUN_005542c0("studio",6);
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          FUN_0087a540(uVar7);
          uStack_8 = 0xffffffff;
          uStack_7c._4_4_ = (int *)0x6f03e2;
          FUN_0056cfd0();
        }
      }
    }
  }
  uStack_7c._4_4_ = (int *)0x6f03ed;
  FUN_006ddde0();
  uStack_7c._4_4_ = (int *)puVar2;
  uStack_7c._0_4_ = (char *)param_2;
  puStack_80 = (undefined *)0x6f03f8;
  FUN_006229b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9620 ; VA 0x006f0410 ; FUN_006f0410 */

int * FUN_006f0410(int *param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  code *pcVar4;
  undefined uVar5;
  int *piVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  uint uVar10;
  uint uVar11;
  uint auStack_68 [4];
  undefined4 uStack_58;
  uint uStack_54;
  undefined auStack_50 [4];
  int *piStack_4c;
  int *piStack_48;
  int *piStack_44;
  int iStack_40;
  int *piStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  int *piStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar3 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa291;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  piVar6 = (int *)FUN_00700dd0(param_1,param_2);
  if (iVar3 != 0) {
    piVar6 = (int *)FUN_00587490(auStack_24);
    uStack_8 = 0;
    if ((*piVar6 == 0) ||
       (iVar3 = *(int *)(*piVar6 + 0xc), iVar7 = FUN_005edd10(),
       (uint)*(ushort *)(iVar7 + 0x1da) <
       (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8))) {
      piStack_34 = (int *)0x0;
      puVar9 = &uStack_38;
      param_2 = 0;
      uVar10 = 2;
    }
    else {
      piStack_2c = (int *)piVar6[1];
      param_2 = *piVar6;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        piStack_2c[1] = piStack_2c[1] + 1;
        UNLOCK();
        piStack_2c = (int *)piVar6[1];
      }
      puVar9 = &uStack_30;
      uVar10 = 1;
    }
    piStack_3c = (int *)puVar9[1];
    uVar11 = uVar10 | 4;
    *puVar9 = 0;
    piStack_28 = piStack_3c;
    puVar9[1] = 0;
    piVar2 = piStack_34;
    piVar6 = piStack_3c;
    iStack_40 = param_2;
    uStack_14 = uVar11;
    if (((uVar10 & 2) != 0) &&
       (uVar11 = uVar10 & 0xfffffffd | 4, uStack_14 = uVar11, piStack_34 != (int *)0x0)) {
      LOCK();
      piVar1 = piStack_34 + 1;
      iVar3 = *piVar1;
      piVar6 = (int *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        piVar6 = (int *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          piVar6 = (int *)(**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_2c;
    if (((uVar11 & 1) != 0) &&
       (uVar11 = uVar11 & 0xfffffffe, uStack_14 = uVar11, piStack_2c != (int *)0x0)) {
      LOCK();
      piVar1 = piStack_2c + 1;
      iVar3 = *piVar1;
      piVar6 = (int *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        piVar6 = (int *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          piVar6 = (int *)(**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_20;
    uStack_8._0_1_ = 2;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_20 + 1;
      iVar3 = *piVar1;
      piVar6 = (int *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        piVar6 = (int *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          piVar6 = (int *)(**(code **)(*piVar2 + 4))();
        }
      }
    }
    if (param_2 != 0) {
      FUN_009ff040(&uStack_38,"PropSync");
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      uVar8 = FUN_009ff040(auStack_24,"ItemCount");
      FUN_005587e0(uVar8);
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_20[1] + -1;
        piStack_20[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          iVar3 = piStack_20[2] + -1;
          piStack_20[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_20 + 4))();
          }
        }
      }
      uStack_1c = uStack_38;
      param_1 = (int *)(param_2 + 0x3b40);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      puVar9 = (undefined4 *)FUN_00670ee0(auStack_50,&param_1);
      piVar6 = piStack_4c;
      uStack_14 = uVar11 | 8;
      param_1 = (int *)*puVar9;
      piStack_44 = (int *)puVar9[1];
      *puVar9 = 0;
      puVar9[1] = 0;
      piStack_48 = param_1;
      piStack_20 = piStack_44;
      if (piStack_4c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_4c[1] + -1;
        piStack_4c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_4c)();
          LOCK();
          piVar2 = piVar6 + 2;
          iVar3 = *piVar2 + -1;
          *piVar2 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      uStack_58 = 0;
      uStack_54 = 0xf;
      auStack_68[0] = auStack_68[0] & 0xffffff00;
      pcVar4 = *(code **)(*param_1 + 0x38);
      FUN_005542c0("AckCount",8);
      uStack_8._0_1_ = 5;
      (*pcVar4)(auStack_68);
      uStack_8._0_1_ = 4;
      uVar5 = (undefined)uStack_8;
      uStack_8._0_1_ = 4;
      if (0xf < uStack_54) {
        uVar11 = uStack_54 + 1;
        uVar10 = auStack_68[0];
        if (0xfff < uVar11) {
          uVar10 = *(uint *)(auStack_68[0] - 4);
          uVar11 = uStack_54 + 0x24;
          if (0x1f < (auStack_68[0] - uVar10) - 4) {
            uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar10,uVar11);
      }
      uStack_58 = 0;
      uStack_54 = 0xf;
      auStack_68[0] = auStack_68[0] & 0xffffff00;
      FUN_008a65e0(uStack_1c,0);
      piVar6 = piStack_20;
      uStack_8._0_1_ = 3;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_20[1] + -1;
        piStack_20[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar2 = piVar6 + 2;
          iVar3 = *piVar2 + -1;
          *piVar2 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      FUN_009ff040(&uStack_30,"Received Stream Data");
      iVar3 = param_2;
      uStack_8._0_1_ = 6;
      FUN_009fdc90(auStack_50,"AvgReadTimePerItem",param_2 + 0x3bc8);
      piVar6 = piStack_4c;
      if (piStack_4c != (int *)0x0) {
        LOCK();
        iVar7 = piStack_4c[1] + -1;
        piStack_4c[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piStack_4c)();
          LOCK();
          piVar2 = piVar6 + 2;
          iVar7 = *piVar2 + -1;
          *piVar2 = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      FUN_009fdc90(auStack_50,"AvgInstancesPerItem",iVar3 + 0x3ba0);
      piVar6 = piStack_4c;
      if (piStack_4c != (int *)0x0) {
        LOCK();
        iVar7 = piStack_4c[1] + -1;
        piStack_4c[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piStack_4c)();
          LOCK();
          piVar2 = piVar6 + 2;
          iVar7 = *piVar2 + -1;
          *piVar2 = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      FUN_009fdb40(auStack_50,"RequestedInstanceAvg",iVar3 + 0x3c48);
      piVar6 = piStack_4c;
      if (piStack_4c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_4c[1] + -1;
        piStack_4c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_4c)();
          LOCK();
          piVar2 = piVar6 + 2;
          iVar3 = *piVar2 + -1;
          *piVar2 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      uVar8 = FUN_009ff040(auStack_50,"PendingRequestCount");
      FUN_005587e0(uVar8);
      piVar6 = piStack_4c;
      if (piStack_4c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_4c[1] + -1;
        piStack_4c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_4c)();
          LOCK();
          piVar2 = piVar6 + 2;
          iVar3 = *piVar2 + -1;
          *piVar2 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      uVar8 = FUN_009ff040(auStack_50,"NumRegionsToGC");
      FUN_005587e0(uVar8);
      piVar6 = piStack_4c;
      if (piStack_4c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_4c[1] + -1;
        piStack_4c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_4c)();
          LOCK();
          piVar2 = piVar6 + 2;
          iVar3 = *piVar2 + -1;
          *piVar2 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      uVar8 = FUN_009ff040(auStack_50,"GCDistance");
      FUN_005587e0(uVar8);
      piVar6 = piStack_4c;
      if (piStack_4c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_4c[1] + -1;
        piStack_4c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_4c)();
          LOCK();
          piVar2 = piVar6 + 2;
          iVar3 = *piVar2 + -1;
          *piVar2 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      uVar8 = FUN_009ff040(auStack_50,"NumRegions");
      piVar6 = (int *)FUN_005587e0(uVar8);
      if (piStack_4c != (int *)0x0) {
        LOCK();
        piVar2 = piStack_4c + 1;
        iVar3 = *piVar2;
        piVar6 = (int *)*piVar2;
        *piVar2 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          (**(code **)*piStack_4c)();
          LOCK();
          piVar2 = piStack_4c + 2;
          iVar3 = *piVar2;
          piVar6 = (int *)*piVar2;
          *piVar2 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            piVar6 = (int *)(**(code **)(*piStack_4c + 4))();
          }
        }
      }
      piVar2 = piStack_2c;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        piVar1 = piStack_2c + 1;
        iVar3 = *piVar1;
        piVar6 = (int *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          (**(code **)*piStack_2c)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar3 = *piVar1;
          piVar6 = (int *)*piVar1;
          *piVar1 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            piVar6 = (int *)(**(code **)(*piVar2 + 4))();
          }
        }
      }
      piVar2 = piStack_34;
      if (piStack_34 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_34 + 1;
        iVar3 = *piVar1;
        piVar6 = (int *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          (**(code **)*piStack_34)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar3 = *piVar1;
          piVar6 = (int *)*piVar1;
          *piVar1 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            piVar6 = (int *)(**(code **)(*piVar2 + 4))();
          }
        }
      }
    }
    piVar2 = piStack_28;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_28 + 1;
      iVar3 = *piVar1;
      piVar6 = (int *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        piVar6 = (int *)(**(code **)*piStack_28)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          piVar6 = (int *)(**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar6;
}



/* FUNCTION 9621 ; VA 0x006f0970 ; FUN_006f0970 */

void __thiscall FUN_006f0970(int param_1,undefined4 param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  
  if (param_3 == 0) {
    if (((*(char *)(param_1 + 0x1d49) == '\0') && (*(int *)(param_1 + 0x19ac) != 0)) &&
       (iVar1 = FUN_00554b50(), iVar1 == 1)) {
      return;
    }
    FUN_00623b90(param_2,0,param_4);
  }
  return;
}



/* FUNCTION 9622 ; VA 0x006f09b0 ; FUN_006f09b0 */

undefined4 FUN_006f09b0(void)

{
  undefined4 *puVar1;
  float fVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  int iVar9;
  float10 fVar10;
  int *piStack_30;
  int *piStack_2c;
  int iStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 uStack_1c;
  float fStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa2a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_1c = FUN_00554ed0();
  piVar3 = (int *)FUN_0061f420(auStack_24);
  iVar6 = *piVar3;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_20[1] + -1;
    piStack_20[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar3 = piStack_20 + 2;
      iVar9 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  if (iVar6 != 0) {
    iVar9 = *(int *)(iVar6 + 0xc);
    iVar4 = FUN_00913630();
    iVar5 = 0;
    if ((uint)*(ushort *)(iVar9 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da)) {
      iVar5 = iVar6;
    }
    if (((iVar5 != 0) && (*(int *)(iVar5 + 100) != 0)) &&
       (puVar1 = *(undefined4 **)(*(int *)(iVar5 + 100) + 0x2c), puVar1 != (undefined4 *)0x0)) {
      piVar3 = (int *)puVar1[1];
      for (piVar8 = (int *)*puVar1; piVar8 != piVar3; piVar8 = piVar8 + 2) {
        iStack_14 = *piVar8;
        if ((iStack_14 != 0) &&
           (iVar6 = *(int *)(iStack_14 + 0xc), iVar5 = FUN_0099be20(), iVar9 = iStack_14,
           (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
           (uint)*(ushort *)(iVar5 + 0x1da))) goto LAB_006f0a8e;
      }
    }
  }
  iVar9 = 0;
LAB_006f0a8e:
  iVar6 = FUN_005c3ac0(fStack_18);
  if ((iVar6 != 0) && (iVar9 != 0)) {
    fVar10 = (float10)FUN_008b3810();
    fStack_18 = (float)fVar10;
    piStack_30 = (int *)0x0;
    piStack_2c = (int *)0x0;
    iStack_28 = 0;
    uStack_8 = 0;
    FUN_009b67f0(&piStack_30);
    fVar2 = fStack_18;
    for (piVar3 = piStack_30; piVar3 != piStack_2c; piVar3 = piVar3 + 1) {
      iVar6 = *piVar3;
      if (((*(int *)(iVar6 + 0x1a8) != 0) &&
          (*(int *)(iVar6 + 0x68) != 0 || *(int *)(iVar6 + 0x6c) != 0)) &&
         ((NAN(*(float *)(iVar6 + 0xfc)) || NAN(fVar2)) == (*(float *)(iVar6 + 0xfc) == fVar2))) {
        fStack_18 = 2.7112751e-18;
        iStack_14 = 0x80;
        DAT_01f02658 = DAT_01f02658 | 0x80;
      }
    }
    if (piStack_30 != (int *)0x0) {
      uVar7 = iStack_28 - (int)piStack_30 & 0xfffffffc;
      piVar3 = piStack_30;
      if (0xfff < uVar7) {
        piVar3 = (int *)piStack_30[-1];
        uVar7 = uVar7 + 0x23;
        if (0x1f < (uint)((int)piStack_30 + (-4 - (int)piVar3))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(piVar3,uVar7);
    }
    ExceptionList = pvStack_10;
    return uStack_1c;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 9623 ; VA 0x006f0bb0 ; FUN_006f0bb0 */

void __fastcall FUN_006f0bb0(int param_1)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_008f7870(param_1);
  iVar2 = FUN_00ca82e0(uVar1);
  if (iVar2 != 0) {
    FUN_00ca8790((float)*(double *)(param_1 + 0x620));
    FUN_00ca8810((float)*(double *)(param_1 + 0x980));
  }
  if ((*(uint *)(param_1 + 0x380c) & 1) != 0) {
    FUN_006dc960();
    return;
  }
  return;
}



/* FUNCTION 9624 ; VA 0x006f0c20 ; FUN_006f0c20 */

void __fastcall FUN_006f0c20(int param_1)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_008f7870(param_1);
  iVar2 = FUN_00ca82e0(uVar1);
  if (iVar2 != 0) {
    FUN_00ca87d0((float)*(double *)(param_1 + 0x808));
  }
  return;
}



/* FUNCTION 9625 ; VA 0x006f0c60 ; thunk_FUN_00625d80 */

void __fastcall thunk_FUN_00625d80(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  void **ppvVar4;
  char cVar5;
  int iVar6;
  undefined4 uVar7;
  ushort *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  int iVar11;
  int *piVar12;
  undefined4 *puVar13;
  undefined auStack_64 [16];
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  undefined4 *puStack_48;
  int *piStack_44;
  int *piStack_40;
  int iStack_3c;
  int *piStack_38;
  int iStack_34;
  int iStack_30;
  undefined uStack_29;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined4 *puStack_1c;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e92a;
  pvStack_10 = ExceptionList;
  if ((*(char *)(param_1 + 0x1ec8) == '\0') && (*(int *)(param_1 + 0x1eb8) != 0)) {
    ppvVar4 = &pvStack_10;
    iStack_18 = param_1;
    for (puVar2 = *(undefined4 **)(*(int *)(param_1 + 0x1ec4) + *(int *)(param_1 + 0x1eb4) * 4);
        ExceptionList = ppvVar4, puVar2 != (undefined4 *)0x0; puVar2 = (undefined4 *)*puVar2) {
      iVar11 = puVar2[2];
      if ((iVar11 == 0) ||
         (iVar3 = *(int *)(iVar11 + 0xc), iVar6 = FUN_00ae6b40(), param_1 = iStack_18,
         (uint)*(ushort *)(iVar6 + 0x1da) <
         (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
        iVar11 = 0;
      }
      if ((*(char *)(param_1 + 0x1db8) == '\0') &&
         (cVar5 = FUN_006da1c0(param_1,iVar11), cVar5 != '\0')) {
        iVar11 = puVar2[7];
        if ((DAT_01ead114 == '\0') && (DAT_01d59e04 < iVar11)) {
          if (DAT_01ee420a != '\0') {
            FUN_01677520(DAT_01ee420a,"Limiting Animation Track, total tracks attempted %zu",iVar11)
            ;
          }
          FUN_0151f6f0(0xffffffff,0,0);
          uStack_8 = 0;
          FUN_0151f9c0("AnimationTracks",iVar11);
          uVar7 = DAT_01eace4c;
          uStack_54 = 0;
          uStack_50 = 0xf;
          auStack_64[0] = 0;
          FUN_005542c0("AnimationSpamSender",0x13);
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          FUN_01520d20(auStack_64,uVar7,0);
          FUN_005507b0();
          DAT_01ead114 = '\x01';
          uStack_8 = 0xffffffff;
          FUN_0151f7f0();
        }
        iStack_30 = 0;
        if (puVar2[7] == 0) {
          puVar13 = (undefined4 *)0x0;
        }
        else {
          puVar13 = *(undefined4 **)(puVar2[10] + puVar2[6] * 4);
        }
        for (; param_1 = iStack_18, puVar13 != (undefined4 *)0x0; puVar13 = (undefined4 *)*puVar13)
        {
          piVar12 = puVar13 + 2;
          puStack_1c = puVar13 + 8;
          iStack_34 = FUN_01674e20(0xc);
          uStack_8 = 2;
          if (iStack_34 == 0) {
            uVar7 = 0;
          }
          else {
            uVar7 = FUN_00569550(7,&uStack_29);
          }
          uStack_8 = 0xffffffff;
          piStack_28 = (int *)0x0;
          piStack_24 = (int *)0x0;
          FUN_006047e0(uVar7,iStack_34);
          uStack_8 = 3;
          piStack_20 = (int *)*piStack_28;
          uVar7 = FUN_0088d190();
          *piStack_20 = uVar7;
          puStack_14 = (undefined4 *)FUN_00630cf0();
          iVar11 = piStack_20[1];
          puVar10 = piStack_20 + 2;
          if ((undefined4 *)iVar11 == puStack_14) {
            if (puVar10 != piVar12) {
              if (0xf < (uint)puVar13[7]) {
                piVar12 = (int *)*piVar12;
              }
              FUN_005542c0(piVar12,puVar13[6]);
            }
          }
          else {
            if (iVar11 != 0) {
              puStack_48 = puVar10;
              (**(code **)(iVar11 + 8))(puVar10);
              piStack_20[1] = 0;
            }
            FUN_0054ef60(piVar12);
            piStack_20[1] = (int)puStack_14;
          }
          iVar11 = *piStack_28;
          uVar7 = FUN_0088daf0();
          *(undefined4 *)(iVar11 + 0xd0) = uVar7;
          puStack_14 = (undefined4 *)FUN_005c9ef0();
          iVar3 = *(int *)(iVar11 + 0xd4);
          if ((undefined4 *)iVar3 == puStack_14) {
            *(undefined *)(iVar11 + 0xd8) = *(undefined *)puStack_1c;
          }
          else {
            if (iVar3 != 0) {
              (**(code **)(iVar3 + 8))(iVar11 + 0xd8);
              *(undefined4 *)(iVar11 + 0xd4) = 0;
            }
            *(undefined *)(iVar11 + 0xd8) = *(undefined *)puStack_1c;
            *(undefined4 **)(iVar11 + 0xd4) = puStack_14;
          }
          iVar11 = *piStack_28;
          uVar7 = FUN_0088c960();
          *(undefined4 *)(iVar11 + 0x1a0) = uVar7;
          puStack_14 = (undefined4 *)FUN_00630820();
          iVar3 = *(int *)(iVar11 + 0x1a4);
          if ((undefined4 *)iVar3 == puStack_14) {
            *(undefined4 *)(iVar11 + 0x1a8) = puStack_1c[1];
          }
          else {
            if (iVar3 != 0) {
              (**(code **)(iVar3 + 8))(iVar11 + 0x1a8);
              *(undefined4 *)(iVar11 + 0x1a4) = 0;
            }
            *(undefined4 *)(iVar11 + 0x1a8) = puStack_1c[1];
            *(undefined4 **)(iVar11 + 0x1a4) = puStack_14;
          }
          iVar11 = *piStack_28;
          uVar7 = FUN_0088c960();
          *(undefined4 *)(iVar11 + 0x270) = uVar7;
          puStack_14 = (undefined4 *)FUN_00630820();
          iVar3 = *(int *)(iVar11 + 0x274);
          if ((undefined4 *)iVar3 == puStack_14) {
            *(undefined4 *)(iVar11 + 0x278) = puStack_1c[2];
          }
          else {
            if (iVar3 != 0) {
              (**(code **)(iVar3 + 8))(iVar11 + 0x278);
              *(undefined4 *)(iVar11 + 0x274) = 0;
            }
            *(undefined4 *)(iVar11 + 0x278) = puStack_1c[2];
            *(undefined4 **)(iVar11 + 0x274) = puStack_14;
          }
          iVar11 = *piStack_28;
          uVar7 = FUN_0088c960();
          *(undefined4 *)(iVar11 + 0x340) = uVar7;
          puStack_14 = (undefined4 *)FUN_00630820();
          iVar3 = *(int *)(iVar11 + 0x344);
          if ((undefined4 *)iVar3 == puStack_14) {
            *(undefined4 *)(iVar11 + 0x348) = puStack_1c[3];
          }
          else {
            if (iVar3 != 0) {
              (**(code **)(iVar3 + 8))(iVar11 + 0x348);
              *(undefined4 *)(iVar11 + 0x344) = 0;
            }
            *(undefined4 *)(iVar11 + 0x348) = puStack_1c[3];
            *(undefined4 **)(iVar11 + 0x344) = puStack_14;
          }
          iVar11 = *piStack_28;
          uVar7 = FUN_0088c960();
          *(undefined4 *)(iVar11 + 0x410) = uVar7;
          puStack_14 = (undefined4 *)FUN_00630820();
          iVar3 = *(int *)(iVar11 + 0x414);
          if ((undefined4 *)iVar3 == puStack_14) {
            *(undefined4 *)(iVar11 + 0x418) = puStack_1c[4];
          }
          else {
            if (iVar3 != 0) {
              (**(code **)(iVar3 + 8))(iVar11 + 0x418);
              *(undefined4 *)(iVar11 + 0x414) = 0;
            }
            *(undefined4 *)(iVar11 + 0x418) = puStack_1c[4];
            *(undefined4 **)(iVar11 + 0x414) = puStack_14;
          }
          iVar11 = *piStack_28;
          uVar7 = FUN_0088c8c0();
          *(undefined4 *)(iVar11 + 0x4e0) = uVar7;
          puStack_14 = (undefined4 *)FUN_005c9cc0();
          puVar10 = *(undefined4 **)(iVar11 + 0x4e4);
          if (puVar10 == puStack_14) {
            *(undefined4 *)(iVar11 + 0x4e8) = puStack_1c[5];
          }
          else {
            if (puVar10 != (undefined4 *)0x0) {
              (*(code *)puVar10[2])(iVar11 + 0x4e8);
              *(undefined4 *)(iVar11 + 0x4e4) = 0;
            }
            *(undefined4 *)(iVar11 + 0x4e8) = puStack_1c[5];
            *(undefined4 **)(iVar11 + 0x4e4) = puStack_14;
          }
          if (piStack_24 != (int *)0x0) {
            LOCK();
            piStack_24[1] = piStack_24[1] + 1;
            UNLOCK();
          }
          piStack_44 = piStack_28;
          piStack_40 = piStack_24;
          piVar12 = (int *)puVar2[4];
          if (piVar12 != (int *)0x0) {
            LOCK();
            piVar12[1] = piVar12[1] + 1;
            UNLOCK();
            piVar12 = (int *)puVar2[4];
          }
          iStack_3c = puVar2[3];
          uStack_8 = CONCAT31(uStack_8._1_3_,5);
          piStack_38 = piVar12;
          piStack_20 = piVar12;
          iVar11 = FUN_006193f0(*(undefined4 *)(iStack_3c + 0xc));
          if (iVar11 != 0) {
            puStack_14 = *(undefined4 **)(*(int *)(iStack_18 + 0x19f4) + 0x58);
            puVar8 = (ushort *)FUN_0061d780(&DAT_021291e0);
            piVar12 = piStack_20;
            if (puVar8 != (ushort *)0x0) {
              puStack_14 = *(undefined4 **)(*(int *)(iStack_18 + 0x19f4) + 0x70);
              if ((uint)*puVar8 <
                  (uint)((*(int *)(*(int *)(iStack_18 + 0x19f4) + 0x74) - (int)puStack_14) / 0x14))
              {
                piStack_20 = (int *)((int)puStack_14 + (uint)*puVar8 * 0x14);
              }
              else {
                piStack_20 = (int *)0x0;
              }
              puVar10 = *(undefined4 **)(iStack_18 + 0x195c);
              puVar9 = *(undefined4 **)*puVar10;
              puStack_4c = puVar10;
              if (puVar9 == (undefined4 *)0x0) {
                puVar9 = (undefined4 *)FUN_00621d50();
              }
              else {
                *(undefined4 *)*puVar10 = *puVar9;
              }
              *puVar9 = puVar10;
              puStack_14 = puVar9 + 1;
              uStack_8._0_1_ = 6;
              if (puStack_14 == (undefined4 *)0x0) {
                uVar7 = 0;
              }
              else {
                uVar7 = FUN_006f71c0(iStack_18,&iStack_3c,&DAT_021291e0,piStack_20,&piStack_44);
              }
              uStack_8 = CONCAT31(uStack_8._1_3_,5);
              FUN_006b1f50(uVar7);
              piVar12 = piStack_38;
            }
          }
          if (piVar12 != (int *)0x0) {
            LOCK();
            iVar11 = piVar12[1] + -1;
            piVar12[1] = iVar11;
            UNLOCK();
            if (iVar11 == 0) {
              (**(code **)*piVar12)();
              LOCK();
              iVar11 = piVar12[2] + -1;
              piVar12[2] = iVar11;
              UNLOCK();
              if (iVar11 == 0) {
                (**(code **)(*piVar12 + 4))();
              }
            }
          }
          piVar12 = piStack_40;
          if (piStack_40 != (int *)0x0) {
            LOCK();
            iVar11 = piStack_40[1] + -1;
            piStack_40[1] = iVar11;
            UNLOCK();
            if (iVar11 == 0) {
              (**(code **)*piStack_40)();
              LOCK();
              piVar1 = piVar12 + 2;
              iVar11 = *piVar1 + -1;
              *piVar1 = iVar11;
              UNLOCK();
              if (iVar11 == 0) {
                (**(code **)(*piVar12 + 4))();
              }
            }
          }
          piVar12 = piStack_24;
          iStack_30 = iStack_30 + 1;
          uStack_8 = 0xffffffff;
          if (DAT_01d59e04 <= iStack_30) {
            param_1 = iStack_18;
            if (piStack_24 != (int *)0x0) {
              LOCK();
              iVar11 = piStack_24[1] + -1;
              piStack_24[1] = iVar11;
              UNLOCK();
              if (iVar11 == 0) {
                (**(code **)*piStack_24)();
                LOCK();
                iVar11 = piVar12[2] + -1;
                piVar12[2] = iVar11;
                UNLOCK();
                param_1 = iStack_18;
                if (iVar11 == 0) {
                  (**(code **)(*piVar12 + 4))();
                  param_1 = iStack_18;
                }
              }
            }
            break;
          }
          if (piStack_24 != (int *)0x0) {
            LOCK();
            iVar11 = piStack_24[1] + -1;
            piStack_24[1] = iVar11;
            UNLOCK();
            if (iVar11 == 0) {
              (**(code **)*piStack_24)();
              LOCK();
              iVar11 = piVar12[2] + -1;
              piVar12[2] = iVar11;
              UNLOCK();
              if (iVar11 == 0) {
                (**(code **)(*piVar12 + 4))();
              }
            }
          }
        }
      }
      ppvVar4 = (void **)ExceptionList;
    }
    puStack_4c = (undefined4 *)FUN_01674e20(0x58);
    uStack_8 = 7;
    if (puStack_4c == (undefined4 *)0x0) {
      uVar7 = 0;
    }
    else {
      uVar7 = FUN_00703220(param_1,0xe,0);
    }
    uStack_8 = 0xffffffff;
    FUN_006b1f50(uVar7);
    if (*(int *)(param_1 + 0x1eb8) != 0) {
      FUN_0061ad50(*(int *)(param_1 + 0x1ec4) + *(int *)(param_1 + 0x1eb4) * 4,0);
      puVar13 = *(undefined4 **)(param_1 + 0x1ec4);
      puVar2 = puVar13 + *(int *)(param_1 + 0x1eb4);
      for (; puVar13 != puVar2; puVar13 = puVar13 + 1) {
        *puVar13 = 0;
      }
    }
    *(undefined *)(iStack_18 + 0x1ec8) = 1;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9626 ; VA 0x006f0c70 ; FUN_006f0c70 */

undefined4 __thiscall FUN_006f0c70(int *param_1,int *param_2,int *param_3)

{
  char *pcVar1;
  char cVar2;
  undefined uVar3;
  undefined uVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  int *piVar8;
  int *piVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  int *piStack_8c;
  int *piStack_88;
  undefined auStack_78 [40];
  undefined auStack_50 [40];
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa321;
  pvStack_10 = ExceptionList;
  pcVar1 = (char *)param_2[0xe];
  if (*pcVar1 == -0x7f) {
    piStack_88 = (int *)0x0;
    piStack_8c = (int *)param_2[0xc];
    ExceptionList = &pvStack_10;
    FUN_006ab380(pcVar1);
    piStack_88 = (int *)0x1;
    uStack_8 = 1;
    piStack_8c = (int *)0x6f0d0e;
    FUN_006ab660();
    uVar5 = FUN_008f7870(param_1);
    FUN_005c4330(&piStack_8c,uVar5);
    FUN_006de1a0();
    piStack_88 = (int *)0x6f0d3c;
    cVar2 = (**(code **)(*param_1 + 0x11c))();
    if (cVar2 == '\0') {
      piStack_88 = (int *)0xb0;
      piStack_8c = (int *)0x6f0d51;
      iVar6 = FUN_01674e20();
      uStack_8._0_1_ = 2;
      if (iVar6 == 0) {
        piStack_8c = (int *)0x0;
      }
      else {
        piStack_8c = (int *)0x6f0d67;
        piStack_88 = param_1;
        piStack_8c = (int *)FUN_0071ef50();
      }
      piStack_88 = param_2;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      iStack_28 = 0;
      iStack_24 = 0;
      FUN_0066e250();
      param_1[0xe12] = iStack_28;
      piVar8 = (int *)param_1[0xe13];
      param_1[0xe13] = iStack_24;
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar6 = piVar8[1] + -1;
        piVar8[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          piStack_88 = (int *)0x6f0db4;
          (**(code **)*piVar8)();
          LOCK();
          iVar6 = piVar8[2] + -1;
          piVar8[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            piStack_88 = (int *)0x6f0dc4;
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      piStack_88 = (int *)0x28;
      piStack_8c = (int *)0x6f0dcb;
      iVar6 = FUN_01674e20();
      uStack_8._0_1_ = 3;
      if (iVar6 == 0) {
        piStack_8c = (int *)0x0;
      }
      else {
        piStack_88 = (int *)0x0;
        piStack_8c = param_1;
        piStack_8c = (int *)FUN_00703e40();
      }
      piStack_88 = param_2;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      iStack_28 = 0;
      iStack_24 = 0;
      FUN_0066e1c0();
      param_1[0xe16] = iStack_28;
      piVar8 = (int *)param_1[0xe17];
      param_1[0xe17] = iStack_24;
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar6 = piVar8[1] + -1;
        piVar8[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          piStack_88 = (int *)0x6f0e30;
          (**(code **)*piVar8)();
          LOCK();
          iVar6 = piVar8[2] + -1;
          piVar8[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            piStack_88 = (int *)0x6f0e40;
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      piStack_88 = (int *)0x60;
      piStack_8c = (int *)0x6f0e47;
      param_3 = (int *)FUN_01674e20();
      uStack_8._0_1_ = 4;
      if (param_3 == (int *)0x0) {
        piStack_8c = (int *)0x0;
      }
      else {
        piStack_8c = (int *)0x6f0e5d;
        piStack_88 = param_1;
        piStack_8c = (int *)FUN_00721e30();
      }
      piStack_88 = param_2;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      iStack_28 = 0;
      iStack_24 = 0;
      FUN_0066e2e0();
      param_1[0xe14] = iStack_28;
      piVar8 = (int *)param_1[0xe15];
      param_1[0xe15] = iStack_24;
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar6 = piVar8[1] + -1;
        piVar8[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          piStack_88 = (int *)0x6f0eaa;
          (**(code **)*piVar8)();
          LOCK();
          iVar6 = piVar8[2] + -1;
          piVar8[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            piStack_88 = (int *)0x6f0eba;
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
    }
    piStack_88 = (int *)0x6f0ec2;
    cVar2 = FUN_006abd90();
    *(char *)(param_1 + 0xdfe) = cVar2;
    if (cVar2 != '\0') {
      piStack_88 = (int *)0x310;
      piStack_8c = (int *)0x6f0eda;
      param_3 = (int *)FUN_01674e20();
      uStack_8._0_1_ = 5;
      if (param_3 == (int *)0x0) {
        piStack_8c = (int *)0x0;
      }
      else {
        piStack_8c = (int *)0x6f0ef0;
        piStack_88 = param_1;
        piStack_8c = (int *)FUN_00709e00();
      }
      piStack_88 = param_2;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      iStack_28 = 0;
      iStack_24 = 0;
      FUN_006eac80();
      param_1[0xee5] = iStack_28;
      piVar8 = (int *)param_1[0xee6];
      param_1[0xee6] = iStack_24;
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar6 = piVar8[1] + -1;
        piVar8[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          piStack_88 = (int *)0x6f0f3d;
          (**(code **)*piVar8)();
          LOCK();
          iVar6 = piVar8[2] + -1;
          piVar8[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            piStack_88 = (int *)0x6f0f4d;
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      if (param_1[0xee6] != 0) {
        LOCK();
        piVar8 = (int *)(param_1[0xee6] + 4);
        *piVar8 = *piVar8 + 1;
        UNLOCK();
      }
      piStack_8c = (int *)param_1[0xee5];
      piStack_88 = (int *)param_1[0xee6];
      FUN_0151d950();
      if ((param_1[0xe02] & 0x2000000U) == 0) {
        param_1[0x640] = 4;
      }
    }
    piStack_88 = (int *)0x6f0fa8;
    cVar2 = FUN_006abd90();
    if (cVar2 != '\0') {
      piVar8 = (int *)param_1[0xd];
      param_3 = param_1;
      if ((piVar8 != (int *)0x0) && (param_3 = piVar8, piVar8[0xd] != 0)) {
        piStack_88 = (int *)0x6f0fc6;
        param_3 = (int *)FUN_005c8ac0();
      }
      if (param_3 != (int *)0x0) {
        iVar6 = param_3[3];
        piStack_88 = (int *)0x6f0fe0;
        iVar7 = FUN_008a8c30();
        if ((uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
            (uint)*(ushort *)(iVar7 + 0x1da)) {
          piStack_88 = (int *)&LAB_005ee910;
          piStack_8c = (int *)&DAT_01eaad00;
          FUN_005789c0();
          piStack_88 = (int *)0x6f1018;
          piStack_88 = (int *)FUN_005eec80();
          piStack_8c = (int *)0x6f1023;
          param_3 = (int *)FUN_008aa140();
          if (*param_3 == 0) {
            piStack_88 = (int *)0x6f1030;
            piStack_88 = (int *)FUN_005ee430();
            piStack_8c = &iStack_20;
            piVar8 = (int *)FUN_008a9ba0();
            iVar6 = *piVar8;
            iVar7 = piVar8[1];
            *piVar8 = 0;
            piVar8[1] = 0;
            *param_3 = iVar6;
            piVar8 = (int *)param_3[1];
            param_3[1] = iVar7;
            if (piVar8 != (int *)0x0) {
              LOCK();
              iVar6 = piVar8[1] + -1;
              piVar8[1] = iVar6;
              UNLOCK();
              if (iVar6 == 0) {
                piStack_88 = (int *)0x6f106c;
                (**(code **)*piVar8)();
                LOCK();
                iVar6 = piVar8[2] + -1;
                piVar8[2] = iVar6;
                UNLOCK();
                if (iVar6 == 0) {
                  piStack_88 = (int *)0x6f107c;
                  (**(code **)(*piVar8 + 4))();
                }
              }
            }
            piVar8 = piStack_1c;
            if (piStack_1c != (int *)0x0) {
              LOCK();
              iVar6 = piStack_1c[1] + -1;
              piStack_1c[1] = iVar6;
              UNLOCK();
              if (iVar6 == 0) {
                piStack_88 = (int *)0x6f1095;
                (**(code **)*piStack_1c)();
                LOCK();
                piVar9 = piVar8 + 2;
                iVar6 = *piVar9;
                *piVar9 = *piVar9 + -1;
                UNLOCK();
                if (iVar6 == 1) {
                  piStack_88 = (int *)0x6f10a4;
                  (**(code **)(*piVar8 + 4))();
                }
              }
            }
          }
          iVar6 = *param_3;
          if (iVar6 != 0) {
            piStack_88 = (int *)0x38;
            piStack_8c = (int *)0x6f10b8;
            param_3 = (int *)FUN_01674e20();
            uStack_8._0_1_ = 6;
            if (param_3 == (int *)0x0) {
              iVar6 = 0;
            }
            else {
              if (*(int *)(iVar6 + 0xf4) != 0) {
                LOCK();
                piVar8 = (int *)(*(int *)(iVar6 + 0xf4) + 4);
                *piVar8 = *piVar8 + 1;
                UNLOCK();
              }
              piStack_8c = *(int **)(iVar6 + 0xf0);
              piStack_88 = *(int **)(iVar6 + 0xf4);
              if (*(int *)(iVar6 + 0xec) != 0) {
                LOCK();
                piVar8 = (int *)(*(int *)(iVar6 + 0xec) + 4);
                *piVar8 = *piVar8 + 1;
                UNLOCK();
              }
              iVar6 = FUN_0068fb60(param_1,*(undefined4 *)(iVar6 + 0xe8),
                                   *(undefined4 *)(iVar6 + 0xec));
            }
            iVar7 = param_1[0x685];
            uStack_8 = CONCAT31(uStack_8._1_3_,1);
            param_1[0x685] = iVar6;
            if (iVar7 != 0) {
              piStack_88 = (int *)0x1;
              piStack_8c = (int *)0x6f114f;
              FUN_006157e0();
            }
          }
        }
      }
    }
    piStack_8c = (int *)0x6f1155;
    piStack_88 = param_1;
    iVar6 = FUN_005c3ac0();
    iStack_24 = iVar6;
    if ((param_1[0xe02] & 0x10000000U) == 0) {
      piStack_88 = (int *)0x6f1175;
      piStack_88._0_1_ = FUN_006abd90();
      piStack_88._1_3_ = param_3._1_3_;
      piStack_8c = (int *)0x6f1182;
      FUN_008b9b20();
    }
    else {
      piStack_88 = (int *)0x6f118c;
      uVar4 = FUN_006abd90();
      piStack_88 = (int *)0x6f1197;
      uVar3 = FUN_006abd90();
      uStack_18 = CONCAT31(uStack_18._1_3_,uVar3);
      piStack_88 = (int *)0x6f11a2;
      uVar3 = FUN_006abd90();
      piVar8 = (int *)param_1[0xd];
      piStack_1c = (int *)CONCAT31(piStack_1c._1_3_,uVar3);
      piVar9 = param_1;
      if ((piVar8 != (int *)0x0) && (piVar9 = piVar8, piVar8[0xd] != 0)) {
        piStack_88 = (int *)0x6f11b8;
        piVar9 = (int *)FUN_005c8ac0();
      }
      if (piVar9 != (int *)0x0) {
        iVar6 = piVar9[3];
        piStack_88 = (int *)0x6f11ca;
        iVar7 = FUN_008a8c30();
        if ((uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
            (uint)*(ushort *)(iVar7 + 0x1da)) {
          piStack_88 = (int *)0x6f11ee;
          FUN_00672300();
        }
      }
      piStack_88._1_3_ = param_3._1_3_;
      piStack_8c = (int *)0x6f11fe;
      piStack_88._0_1_ = uVar4;
      FUN_007d4d80();
      piStack_88 = (int *)uStack_18;
      piStack_8c = (int *)0x6f1208;
      FUN_00bfeed0();
      piStack_88 = piStack_1c;
      piStack_8c = (int *)0x6f1212;
      FUN_00bfeee0();
      iVar6 = iStack_24;
    }
    piStack_88 = (int *)0x6f121d;
    uVar4 = FUN_006abd90();
    param_3 = (int *)CONCAT31(param_3._1_3_,uVar4);
    if (param_1[0x770] != 0) {
      piStack_88 = param_3;
      piStack_8c = (int *)0x6f1232;
      FUN_0098c750();
    }
    piStack_88 = (int *)auStack_50;
    piStack_8c = &iStack_14;
    FUN_006abc60();
    if (DAT_01ee420a != '\0') {
      piStack_88 = (int *)iStack_14;
      piStack_8c = (int *)0x18e0b70;
      FUN_016774b0(DAT_01ee420a);
    }
    *(int *)(*(int *)(iVar6 + 0x1b4) + 0x6f4) = iStack_14;
    param_1[0x16] = iStack_14;
    param_1[0xe10] = iStack_14;
    param_1[0xee2] = iStack_14;
    piStack_88 = (int *)0x6f1285;
    cVar2 = FUN_00554b40();
    if ((cVar2 != '\0') && ((param_1[0xe02] & 0x80U) == 0)) {
      piStack_88 = (int *)0x6f12a1;
      uVar10 = FUN_006ace40();
      piStack_88 = (int *)0x6f12ab;
      uVar11 = FUN_006ace40();
      piStack_8c = (int *)0x6f12b4;
      piStack_88 = param_1;
      iVar6 = FUN_005ef0f0();
      if (iVar6 != 0) {
        piStack_8c = (int *)0x6f12c3;
        piStack_88 = param_1;
        iVar6 = FUN_008f7870();
        uVar12 = **(int **)(iVar6 + 0x43c) - (int)*(int **)(iVar6 + 0x43c);
        if (DAT_01d5b288 == '\0') {
          piStack_8c = (int *)(uVar12 ^ uVar10);
          piStack_88 = (int *)(uVar12 ^ uVar11);
          FUN_0095c640();
        }
      }
    }
    piStack_88 = (int *)auStack_50;
    piStack_8c = (int *)0x6f12f4;
    FUN_0062bef0();
    param_1[0xe04] = 1;
    param_1[0xe05] = 0;
    *(undefined *)(param_1 + 0xee3) = 1;
    piStack_88 = (int *)0x6f131a;
    FUN_006eccd0();
    piStack_88 = (int *)0x6f1321;
    FUN_0061c640();
  }
  else {
    if (*pcVar1 != -0x69) {
      piStack_88 = param_3;
      piStack_8c = param_2;
      ExceptionList = &pvStack_10;
      uVar5 = FUN_00625580();
      ExceptionList = pvStack_10;
      return uVar5;
    }
    piStack_88 = (int *)0x0;
    piStack_8c = (int *)param_2[0xc];
    ExceptionList = &pvStack_10;
    FUN_006ab380(pcVar1);
    piStack_88 = (int *)auStack_78;
    uStack_8 = 0;
    piStack_8c = (int *)0x6f0ce7;
    FUN_006d98e0();
  }
  piStack_88 = (int *)0x6f1329;
  FUN_00613200();
  ExceptionList = pvStack_10;
  return param_2[0xd];
}



/* FUNCTION 9627 ; VA 0x006f1350 ; FUN_006f1350 */

/* WARNING: Type propagation algorithm not settling */

int * __thiscall FUN_006f1350(int *param_1,int *param_2)

{
  code *pcVar1;
  float *pfVar2;
  char cVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  int iVar10;
  double *pdVar11;
  int iVar12;
  undefined4 *puVar13;
  int *piVar14;
  undefined4 *******pppppppuVar15;
  float *pfVar16;
  uint uVar17;
  double dVar18;
  undefined4 uVar19;
  undefined2 uVar20;
  int aiStack_64 [2];
  int iStack_5c;
  uint uStack_50;
  undefined4 *******apppppppuStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  undefined4 *******apppppppuStack_34 [3];
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa370;
  pvStack_10 = ExceptionList;
  piStack_14 = param_1;
  if (param_2 == (int *)&DAT_0000000c) {
    if (param_1 == (int *)0x0) {
      return param_2;
    }
    piVar7 = (int *)param_1[0xd];
    piVar4 = param_2;
    ExceptionList = &pvStack_10;
    if ((piVar7 != (int *)0x0) && (param_1 = piVar7, ExceptionList = &pvStack_10, piVar7[0xd] != 0))
    {
      ExceptionList = &pvStack_10;
      piVar4 = (int *)FUN_005c8ac0();
      param_1 = piVar4;
    }
    if (param_1 == (int *)0x0) {
      ExceptionList = pvStack_10;
      return piVar4;
    }
    iVar12 = param_1[3];
    iVar5 = FUN_008a8c30();
    if ((int *)(uint)*(ushort *)(iVar5 + 0x1da) <
        (int *)((uint)*(ushort *)(iVar12 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
      ExceptionList = pvStack_10;
      return (int *)(uint)*(ushort *)(iVar5 + 0x1da);
    }
    FUN_005789c0();
    uVar6 = FUN_00675e30();
    piVar4 = (int *)FUN_008aa140(uVar6);
    piVar7 = piVar4;
    param_2 = piVar4;
    if (*piVar4 == 0) {
      FUN_00be7aa0();
      piVar7 = (int *)FUN_008a9ba0();
      iVar12 = *piVar7;
      iVar5 = piVar7[1];
      *piVar7 = 0;
      piVar7[1] = 0;
      *piVar4 = iVar12;
      piVar14 = (int *)piVar4[1];
      piVar4[1] = iVar5;
      if (piVar14 != (int *)0x0) {
        LOCK();
        piVar4 = piVar14 + 1;
        iVar12 = *piVar4;
        piVar7 = (int *)*piVar4;
        *piVar4 = iVar12 + -1;
        UNLOCK();
        if (iVar12 + -1 == 0) {
          (**(code **)*piVar14)();
          LOCK();
          piVar4 = piVar14 + 2;
          iVar12 = *piVar4;
          piVar7 = (int *)*piVar4;
          *piVar4 = iVar12 + -1;
          UNLOCK();
          if (iVar12 + -1 == 0) {
            piVar7 = (int *)(**(code **)(*piVar14 + 4))();
          }
        }
      }
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piVar4 = piStack_18 + 1;
        iVar12 = *piVar4;
        piVar7 = (int *)*piVar4;
        *piVar4 = iVar12 + -1;
        UNLOCK();
        if (iVar12 + -1 == 0) {
          piVar7 = (int *)(**(code **)*piStack_18)();
          LOCK();
          piVar4 = piStack_18 + 2;
          iVar12 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar12 == 1) {
            piVar7 = (int *)(**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
    if (*param_2 == 0) {
      ExceptionList = pvStack_10;
      return piVar7;
    }
    piVar7 = (int *)FUN_00be82a0();
    ExceptionList = pvStack_10;
    return piVar7;
  }
  if (param_2 != (int *)&DAT_0000000d) {
    return param_2;
  }
  ExceptionList = &pvStack_10;
  if (DAT_01ee4215 == '\0') {
LAB_006f1706:
    if (DAT_01d5a098 == '\0') goto LAB_006f180d;
  }
  else {
    ExceptionList = &pvStack_10;
    if ((DAT_01d5a090 != '\0') && (ExceptionList = &pvStack_10, param_1[0xdfa] != 0)) {
      ExceptionList = &pvStack_10;
      FUN_016774b0(DAT_01ee4215,
                   "childrenWaitingForTheirTurn Not empty at the end of Join. Dumping items in the map. Assert coming up..."
                   ,0);
      if (param_1[0xdfa] == 0) {
        puVar13 = (undefined4 *)0x0;
      }
      else {
        puVar13 = *(undefined4 **)(param_1[0xdfd] + param_1[0xdf9] * 4);
      }
      for (; puVar13 != (undefined4 *)0x0; puVar13 = (undefined4 *)*puVar13) {
        if (DAT_01ee4215 != '\0') {
          puVar8 = (undefined4 *)FUN_009c9510(apppppppuStack_34);
          uStack_8 = 0;
          if (0xf < (uint)puVar8[5]) {
            puVar8 = (undefined4 *)*puVar8;
          }
          FUN_01677520(DAT_01ee4215,"Parent Key : %s",puVar8);
          uStack_8 = 0xffffffff;
          if (&DAT_0000000f < piStack_20) {
            if (((undefined *)0xfff < (undefined *)((int)piStack_20 + 1)) &&
               (0x1f < (uint)((int)apppppppuStack_34[0] + (-4 - (int)apppppppuStack_34[0][-1]))))
            goto LAB_006f1e04;
            FUN_01674ea0();
          }
        }
        piVar7 = (int *)puVar13[5];
        piVar4 = (int *)puVar13[4];
        param_2 = piVar7;
        if (piVar4 != piVar7) {
          do {
            if (DAT_01ee4215 != '\0') {
              puVar8 = (undefined4 *)FUN_008a2380(aiStack_64);
              uStack_8 = 1;
              if (0xf < (uint)puVar8[5]) {
                puVar8 = (undefined4 *)*puVar8;
              }
              puVar9 = (undefined4 *)FUN_009c9510(apppppppuStack_34);
              uStack_8._0_1_ = 2;
              if (0xf < (uint)puVar9[5]) {
                puVar9 = (undefined4 *)*puVar9;
              }
              FUN_01677520(DAT_01ee4215,"    Instance %s[%s]",puVar9,puVar8);
              uStack_8 = CONCAT31(uStack_8._1_3_,1);
              if (&DAT_0000000f < piStack_20) {
                if (((undefined *)0xfff < (undefined *)((int)piStack_20 + 1)) &&
                   (0x1f < (uint)((int)apppppppuStack_34[0] + (-4 - (int)apppppppuStack_34[0][-1])))
                   ) goto LAB_006f1e04;
                FUN_01674ea0();
              }
              piStack_24 = (int *)0x0;
              piStack_20 = (int *)&DAT_0000000f;
              apppppppuStack_34[0] = (undefined4 *******)((uint)apppppppuStack_34[0] & 0xffffff00);
              uStack_8 = 0xffffffff;
              piVar7 = param_2;
              if (0xf < uStack_50) {
                if ((0xfff < uStack_50 + 1) &&
                   (0x1f < (aiStack_64[0] - *(int *)(aiStack_64[0] + -4)) - 4U)) goto LAB_006f1e04;
                FUN_01674ea0();
                piVar7 = param_2;
              }
            }
            piVar4 = piVar4 + 0x16;
          } while (piVar4 != piVar7);
        }
        param_1 = piStack_14;
      }
    }
    if (DAT_01ee4215 == '\0') goto LAB_006f1706;
    if (DAT_01d5a098 == '\0') {
      if (DAT_01d5a090 != '\0') goto LAB_006f180d;
      cVar3 = FUN_0061ef20();
      if ((cVar3 == '\0') && (param_1[0xdf4] != 0)) {
        if (DAT_01ee4215 != '\0') {
          FUN_016774b0(DAT_01ee4215,
                       "orderedChildrenWaitingForTheirTurn Not empty at the end of Join. Dumping items in the map. Assert coming up..."
                       ,0);
        }
        FUN_00618a80(&param_2);
        for (piVar7 = param_2; piVar7 != (int *)0x0; piVar7 = (int *)*piVar7) {
          FUN_006ed040();
        }
      }
      goto LAB_006f1706;
    }
  }
  if ((DAT_01d5a090 == '\0') && (cVar3 = FUN_0061ef20(), cVar3 == '\0')) {
    FUN_00618a80(&param_2);
    for (piVar7 = param_2; piVar7 != (int *)0x0; piVar7 = (int *)*piVar7) {
      FUN_006ec150(piVar7 + 6);
      uStack_8 = 4;
      if ((iStack_5c != 0) && (DAT_01ee4215 != '\0')) {
        FUN_006ed040();
      }
      uStack_8 = 0xffffffff;
      FUN_00611ed0();
    }
    if (param_1[0xdf4] != 0) {
      param_2 = (int *)param_1[0xdf7];
      iVar12 = param_1[0xdf3];
      piVar7 = (int *)param_2[iVar12];
      do {
        param_2[iVar12] = *piVar7;
        FUN_00611ed0();
        FUN_01674ea0();
        param_1[0xdf4] = param_1[0xdf4] + -1;
        piVar7 = (int *)param_2[iVar12];
      } while (piVar7 != (int *)0x0);
      puVar8 = (undefined4 *)param_1[0xdf7];
      puVar13 = puVar8 + param_1[0xdf3];
      for (; puVar8 != puVar13; puVar8 = puVar8 + 1) {
        *puVar8 = 0;
      }
    }
  }
LAB_006f180d:
  if (DAT_01eace54 != 0) {
    param_2 = (int *)FUN_0054db20();
    pcVar1 = *(code **)(*param_2 + 0x164);
    FUN_005f70a0();
    FUN_005f7140();
    uVar6 = DAT_01d5ba38;
    uVar19 = DAT_01d5ba3c;
    uVar20 = DAT_01d5ba40;
    FUN_005f7170(piStack_14 + 0x1d);
    (*pcVar1)(uVar6,uVar19,uVar20);
    param_1 = piStack_14;
    FUN_006f3720();
  }
  iVar12 = param_1[0xd];
  if ((iVar12 != 0) &&
     (iVar5 = *(int *)(iVar12 + 0xc), iVar10 = FUN_005edc10(),
     (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar10 + 0x1d8) <=
     (uint)*(ushort *)(iVar10 + 0x1da))) {
    if (DAT_01d5b038 == '\0') {
      FUN_0068cab0();
    }
    else {
      FUN_0068b2d0(apppppppuStack_34);
      pppppppuVar15 = apppppppuStack_34;
      if (&DAT_0000000f < piStack_20) {
        pppppppuVar15 = apppppppuStack_34[0];
      }
      uStack_8 = 5;
      FUN_0068b590("FinishedReceivingInitialGameData",0,pppppppuVar15,2);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
    }
    FUN_0068ee70();
    iVar5 = FUN_008f7870(iVar12);
    pdVar11 = (double *)FUN_016830f0();
    param_2 = (int *)(float)(*pdVar11 - *(double *)(iVar5 + 0x300));
    iVar12 = FUN_008f7870(iVar12);
    *(int **)(iVar12 + 0x310) = param_2;
  }
  iVar12 = FUN_008f7870(param_1);
  if (iVar12 != 0) {
    FUN_008f7180();
  }
  *(undefined *)(param_1 + 0x7d6) = 0;
  FUN_006eccd0();
  if (param_1[0xee5] != 0) {
    FUN_00710700();
    (**(code **)(*param_1 + 0xb4))();
    if (param_1[0xee6] != 0) {
      LOCK();
      piVar7 = (int *)(param_1[0xee6] + 4);
      *piVar7 = *piVar7 + 1;
      UNLOCK();
    }
    FUN_00934890();
  }
  if (DAT_01d5b208 != '\0') {
    iVar12 = (**(code **)(*param_1 + 0xb4))();
    *(bool *)(iVar12 + 0x4c7) = (param_1[0xe02] & 0x40U) != 0;
  }
  cVar3 = (**(code **)(*param_1 + 0x124))();
  *(bool *)(param_1 + 0xe00) = cVar3 == '\0';
  iVar12 = FUN_006a6900();
  param_1[0x41c] = iVar12;
  piVar7 = (int *)param_1[0x7dc];
  param_1[0x41d] = 0;
  if (*(char *)((int)piVar7 + 0x5a) != '\0') {
    uStack_3c = 0;
    uStack_38 = 0xf;
    apppppppuStack_4c[0] = (undefined4 *******)((uint)apppppppuStack_4c[0] & 0xffffff00);
    FUN_005542c0();
    uStack_8 = 6;
    FUN_01675460(apppppppuStack_4c,"Top %d Instances by Size:\n",DAT_01d59f38);
    pfVar2 = (float *)param_1[0x5fb];
    for (pfVar16 = (float *)param_1[0x5fa]; pfVar16 != pfVar2; pfVar16 = pfVar16 + 3) {
      puVar13 = (undefined4 *)FUN_008a2380(aiStack_64);
      uStack_8._0_1_ = 7;
      if (0xf < (uint)puVar13[5]) {
        puVar13 = (undefined4 *)*puVar13;
      }
      FUN_01675460(apppppppuStack_4c,"%.3f%% %s\n",
                   (double)((*pfVar16 * DAT_018ce320) /
                           (float)((double)param_1[0x603] +
                                  (double)(&DAT_018c0d90)[-(param_1[0x603] >> 0x1f)])),puVar13);
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      if (0xf < uStack_50) {
        if ((0xfff < uStack_50 + 1) && (0x1f < (aiStack_64[0] - *(int *)(aiStack_64[0] + -4)) - 4U))
        goto LAB_006f1e04;
        FUN_01674ea0();
      }
    }
    piStack_28 = (int *)0x0;
    piStack_18 = (int *)0x0;
    piStack_24 = (int *)0x0;
    piStack_20 = (int *)0x0;
    uVar17 = param_1[0x600];
    uStack_8._1_3_ = (undefined3)((uint)uStack_8 >> 8);
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    if (uVar17 != 0) {
      if (0x1fffffff < uVar17) {
                    /* WARNING: Subroutine does not return */
        FUN_00577c30();
      }
      FUN_006edf80(uVar17);
      piStack_18 = piStack_20;
    }
    uVar17 = 0;
    piVar7 = (int *)param_1[0x5fd];
    param_2 = (int *)(param_1[0x5fe] - (int)piVar7 >> 3);
    piStack_20 = piStack_18;
    if (param_2 != (int *)0x0) {
      do {
        if (*piVar7 != param_1[0x601]) break;
        uVar17 = uVar17 + 1;
        piVar7 = piVar7 + 2;
      } while (uVar17 < param_2);
    }
LAB_006f1ba3:
    piVar4 = piStack_24;
    piVar7 = piStack_28;
    if ((int *)uVar17 != param_2) {
      piVar7 = (int *)(param_1[0x5fd] + uVar17 * 8);
      if (piStack_18 == piStack_24) {
        FUN_006ea5d0(piStack_24,piVar7,piVar7 + 1);
        piStack_18 = piStack_20;
      }
      else {
        *piStack_24 = *piVar7;
        piStack_24[1] = piVar7[1];
        piStack_24 = piStack_24 + 2;
      }
      piVar7 = (int *)(param_1[0x5fd] + uVar17 * 8);
      do {
        uVar17 = uVar17 + 1;
        piVar7 = piVar7 + 2;
        if ((uint)(param_1[0x5fe] - param_1[0x5fd] >> 3) <= uVar17) break;
      } while (*piVar7 == param_1[0x601]);
      goto LAB_006f1ba3;
    }
    FUN_006eae60(piStack_28,piStack_24,(int)piStack_24 - (int)piStack_28 >> 3,param_2);
    FUN_00554150();
    param_2 = (int *)0x0;
    if (piVar7 != piVar4) {
      do {
        dVar18 = (double)(((float)piVar7[1] * DAT_018ce320) /
                         (float)((double)param_1[0x603] +
                                (double)(&DAT_018c0d90)[-(param_1[0x603] >> 0x1f)]));
        if (DAT_018db070 <= dVar18) {
          piVar14 = *(int **)(*piVar7 + 4);
          if (0xf < (uint)piVar14[5]) {
            piVar14 = (int *)*piVar14;
          }
          FUN_01675460(apppppppuStack_4c,"%.3f%% %s\n",dVar18,piVar14);
        }
        else {
          param_2 = (int *)((int)param_2 + 1);
        }
        piVar7 = piVar7 + 2;
      } while (piVar7 != piVar4);
      if (param_2 != (int *)0x0) {
        FUN_01675460(apppppppuStack_4c,"[Skipped %d types with < 0.1%%]\n",param_2);
      }
    }
    FUN_01675460(apppppppuStack_4c,
                 "\nTotal Transmitted Join Bytes (Instance + Terrain) : %u (%u + %u)",
                 param_1[0x603] + param_1[0x604],param_1[0x603],param_1[0x604]);
    pppppppuVar15 = apppppppuStack_4c;
    if (0xf < uStack_38) {
      pppppppuVar15 = apppppppuStack_4c[0];
    }
    FUN_0086f2f0(1,&DAT_018bd25c,pppppppuVar15);
    piVar7 = (int *)param_1[0x5fb];
    piVar4 = (int *)param_1[0x5fa];
    param_2 = piVar7;
    if (piVar4 != piVar7) {
      do {
        piVar14 = (int *)piVar4[2];
        if (piVar14 != (int *)0x0) {
          LOCK();
          iVar12 = piVar14[1] + -1;
          piVar14[1] = iVar12;
          UNLOCK();
          piVar7 = param_2;
          if (iVar12 == 0) {
            (**(code **)*piVar14)();
            LOCK();
            iVar12 = piVar14[2] + -1;
            piVar14[2] = iVar12;
            UNLOCK();
            piVar7 = param_2;
            if (iVar12 == 0) {
              (**(code **)(*piVar14 + 4))();
              piVar7 = param_2;
            }
          }
        }
        piVar4 = piVar4 + 3;
      } while (piVar4 != piVar7);
      piVar4 = (int *)piStack_14[0x5fa];
      param_1 = piStack_14;
    }
    param_1[0x5fb] = (int)piVar4;
    piVar7 = (int *)param_1[0x5fd];
    param_1[0x5fe] = (int)piVar7;
    param_1[0x600] = 0;
    param_1[0x603] = 0;
    param_1[0x604] = 0;
    if (piStack_28 != (int *)0x0) {
      if ((0xfff < ((int)piStack_18 - (int)piStack_28 & 0xfffffff8U)) &&
         ((undefined *)0x1f < (undefined *)((int)piStack_28 + (-4 - piStack_28[-1])))) {
LAB_006f1e04:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      piVar7 = (int *)FUN_01674ea0();
    }
    if (0xf < uStack_38) {
      if ((0xfff < uStack_38 + 1) &&
         (0x1f < (uint)((int)apppppppuStack_4c[0] + (-4 - (int)apppppppuStack_4c[0][-1])))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      piVar7 = (int *)FUN_01674ea0();
    }
  }
  ExceptionList = pvStack_10;
  return piVar7;
}



/* FUNCTION 9628 ; VA 0x006f1e10 ; FUN_006f1e10 */

void __thiscall FUN_006f1e10(int *param_1,undefined4 param_2,undefined *param_3)

{
  char cVar1;
  undefined uVar2;
  
  if ((param_1[0xe02] & 2U) != 0) {
    cVar1 = (**(code **)(*param_1 + 0x11c))();
    if (cVar1 != '\0') {
      uVar2 = FUN_006abd90();
      *param_3 = uVar2;
    }
  }
  return;
}



/* FUNCTION 9629 ; VA 0x006f1e40 ; FUN_006f1e40 */

void __thiscall FUN_006f1e40(int *param_1,int param_2)

{
  int iVar1;
  char cVar2;
  
  if (((param_1[0xe02] & 2U) != 0) && (cVar2 = (**(code **)(*param_1 + 0x11c))(), cVar2 != '\0')) {
    iVar1 = *(int *)(param_2 + 0x18);
    if (iVar1 == 0) {
      return;
    }
    FUN_0054ef60(param_2 + 0x20);
    FUN_00677b30(iVar1);
    FUN_006f4150();
  }
  FUN_00626b10(param_2);
  return;
}



/* FUNCTION 9630 ; VA 0x006f1ec0 ; FUN_006f1ec0 */

void __thiscall FUN_006f1ec0(int *param_1,int param_2,undefined4 *param_3,int *param_4)

{
  int iVar1;
  double *pdVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  short *psVar7;
  uint uVar8;
  int *piVar9;
  bool bVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined8 uStack_7c;
  undefined4 uStack_74;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined8 uStack_5c;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined8 uStack_4c;
  undefined8 uStack_44;
  uint uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  int *piStack_28;
  undefined4 *puStack_24;
  int iStack_20;
  int *piStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa399;
  pvStack_10 = ExceptionList;
  uStack_50 = 0;
  cStack_11 = *(char *)(param_2 + 0x100);
  uStack_3c = (uint)*(ushort *)(param_2 + 0x24);
  piStack_18 = (int *)(param_2 + 0x18);
  puStack_24 = (undefined4 *)*piStack_18;
  uStack_44 = 0;
  uStack_54 = 0;
  uStack_4c = 0;
  if (puStack_24 == (undefined4 *)0x0) {
    uStack_30 = 2.12199579047121e-314;
  }
  else {
    uStack_30 = *(double *)(puStack_24 + 6);
  }
  uStack_38 = (int)uStack_30;
  uStack_7c = CONCAT44((int)uStack_30,uStack_3c);
  uStack_74 = uStack_30._4_4_;
  uStack_6c = 0;
  uStack_68 = 0;
  uStack_64 = 0;
  uStack_60 = 0;
  uStack_5c = 0;
  ExceptionList = &pvStack_10;
  piStack_28 = param_1;
  piStack_1c = (int *)uStack_3c;
  FUN_006eb730(&uStack_30,&uStack_7c,&uStack_7c);
  iVar1 = (int)uStack_30;
  if (uStack_30._4_1_ == '\0') {
    uVar11 = 0x6f1ffb;
    pdVar2 = (double *)FUN_01682800(&uStack_30);
    uStack_30 = *(double *)(param_1 + 0xec0) + *pdVar2;
    *(double *)(iVar1 + 0x20) = uStack_30;
  }
  else {
    pdVar2 = (double *)FUN_01682800(&uStack_30);
    *(double *)(iVar1 + 0x20) = *(double *)(param_1 + 0xec0) + *pdVar2;
    uStack_3c = (uint)piStack_1c;
    if (puStack_24 == (undefined4 *)0x0) {
      uStack_30 = 2.12199579047121e-314;
    }
    else {
      uStack_30 = *(double *)(puStack_24 + 6);
    }
    uStack_38 = (int)uStack_30;
    uStack_34 = uStack_30._4_4_;
    uVar11 = 0x6f1ff4;
    FUN_006805f0(&uStack_3c);
  }
  if (cStack_11 == '\0') {
    *(int *)(iVar1 + 0x18) = *(int *)(iVar1 + 0x18) + 1;
  }
  else {
    *(undefined4 *)(iVar1 + 0x18) = 0;
  }
  *(undefined *)(iVar1 + 0x28) = 0;
  iVar1 = param_1[0x67d];
  cStack_11 = 0;
  piStack_1c = (int *)*piStack_18;
  piVar5 = *(int **)(iVar1 + 0x34);
  uVar3 = piStack_1c[3];
  if ((piVar5 != *(int **)(iVar1 + 0x38)) && (uVar3 != *(uint *)(iVar1 + 0x44))) {
    puStack_24 = (undefined4 *)((int)*(int **)(iVar1 + 0x38) - (int)piVar5 >> 3);
    uVar3 = (uVar3 >> 3) + uVar3 & (int)puStack_24 - 1U;
    uVar8 = 0;
    do {
      piVar6 = piVar5 + uVar3 * 2;
      param_1 = piStack_28;
      if (*piVar6 == piStack_1c[3]) goto LAB_006f209e;
      if (*piVar6 == *(int *)(piStack_28[0x67d] + 0x44)) break;
      uVar3 = uVar3 + 1 + uVar8;
      uVar8 = uVar8 + 1;
      uVar3 = uVar3 & (int)puStack_24 - 1U;
    } while (uVar8 <= (int)puStack_24 - 1U);
  }
  piVar6 = (int *)0x0;
LAB_006f209e:
  psVar7 = (short *)(-(uint)(piVar6 != (int *)0x0) & (uint)(piVar6 + 1));
  if (psVar7 == (short *)0x0) {
    bVar10 = false;
  }
  else {
    bVar10 = *psVar7 == *(short *)(param_2 + 0x24);
  }
  uStack_30._4_4_ = piVar5;
  if ((*(char *)(param_1 + 0xdfe) == '\0') || (param_3 != &DAT_0211a3d8)) {
    if (bVar10) {
      uStack_30._4_4_ = param_4;
      if (param_4 != (int *)0x0) {
        piStack_28 = (int *)param_1[0xee4];
        piVar5 = *(int **)*piStack_28;
        puStack_24 = piStack_28;
        if (piVar5 == (int *)0x0) {
          piVar5 = (int *)FUN_00621d50();
        }
        else {
          *(int *)*piStack_28 = *piVar5;
        }
        piVar6 = uStack_30._4_4_;
        *piVar5 = (int)piStack_28;
        piVar9 = piVar5 + 1;
        uStack_8 = 0;
        piStack_28 = piVar9;
        if (piVar9 == (int *)0x0) {
          piVar9 = (int *)0x0;
        }
        else {
          uStack_30 = (double)(ulonglong)CONCAT24(*(undefined2 *)(param_2 + 0x24),(int)uStack_30);
          FUN_006ebdf0(&iStack_20,piVar6);
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          FUN_006b1a30(param_1);
          *piVar9 = (int)RBX::Network::CFrameAcknowledgementItem::vftable;
          piVar5[0xd] = (int)param_1;
          piVar5[0xe] = 0;
          piVar5[0xf] = 0;
          if (piStack_1c != (int *)0x0) {
            LOCK();
            piStack_1c[1] = piStack_1c[1] + 1;
            UNLOCK();
          }
          piVar5[0xe] = iStack_20;
          piVar5[0xf] = (int)piStack_1c;
          *(short *)(piVar5 + 0x10) = (short)((ulonglong)uStack_30 >> 0x20);
          uStack_30._4_4_ = piStack_1c;
          if (piStack_1c != (int *)0x0) {
            LOCK();
            iVar1 = piStack_1c[1] + -1;
            piStack_1c[1] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)*piStack_1c)();
              LOCK();
              iVar1 = uStack_30._4_4_[2] + -1;
              uStack_30._4_4_[2] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)(*uStack_30._4_4_ + 4))();
              }
            }
          }
        }
        uStack_8 = 0xffffffff;
        FUN_006b1f50(piVar9);
      }
    }
  }
  else if ((param_1[0xee5] != 0) && (piStack_1c != (int *)0x0)) {
    iVar1 = *(int *)(param_2 + 0x28);
    uVar12 = 0x6f20ef;
    iVar4 = FUN_00888530();
    if (iVar1 == iVar4) {
      FUN_00557fc0(piStack_18);
      FUN_0070e420(uVar11,uVar12);
      FUN_006f4440(*piStack_18,1);
      ExceptionList = pvStack_10;
      return;
    }
  }
  FUN_00626c60(param_2,param_3,param_4);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9631 ; VA 0x006f2250 ; FUN_006f2250 */

void FUN_006f2250(undefined4 param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = FUN_006ace40();
  *param_2 = uVar1;
  return;
}



/* FUNCTION 9632 ; VA 0x006f2270 ; FUN_006f2270 */

void FUN_006f2270(undefined4 param_1,undefined *param_2,undefined4 *param_3)

{
  undefined uVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  
  uVar1 = FUN_006abe40();
  *param_2 = uVar1;
  uVar2 = FUN_006ace40();
  *param_3 = uVar2;
  uVar2 = FUN_006ace40();
  param_3[1] = uVar2;
  uVar2 = FUN_006ace40();
  param_3[2] = uVar2;
  uVar3 = FUN_006ace60();
  *(undefined8 *)(param_3 + 4) = uVar3;
  return;
}



/* FUNCTION 9633 ; VA 0x006f22c0 ; FUN_006f22c0 */

void FUN_006f22c0(undefined4 param_1,undefined *param_2,undefined4 *param_3)

{
  undefined uVar1;
  undefined4 uVar2;
  
  uVar1 = FUN_006abe40();
  *param_2 = uVar1;
  uVar2 = FUN_006ace40();
  *param_3 = uVar2;
  return;
}



/* FUNCTION 9634 ; VA 0x006f22f0 ; FUN_006f22f0 */

undefined4 * FUN_006f22f0(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 uVar2;
  float fVar3;
  undefined uVar4;
  char cVar5;
  undefined *puVar6;
  undefined **ppuVar7;
  int *piVar8;
  undefined4 *puVar9;
  float fVar10;
  int iVar11;
  undefined **ppuVar12;
  uint uVar13;
  uint uVar14;
  float10 fVar15;
  int aiStack_188 [5];
  uint uStack_174;
  uint uStack_170;
  undefined4 uStack_16c;
  undefined4 uStack_168;
  undefined4 uStack_164;
  undefined8 uStack_160;
  undefined4 uStack_158;
  undefined4 *puStack_154;
  float fStack_150;
  int *piStack_14c;
  uint uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  float fStack_70;
  int *piStack_6c;
  undefined4 uStack_68;
  int *piStack_64;
  undefined4 uStack_60;
  int *piStack_5c;
  undefined4 uStack_58;
  int *piStack_54;
  float fStack_50;
  undefined4 uStack_4c;
  int *piStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  float fStack_3c;
  uint uStack_38;
  char *pcStack_34;
  float fStack_30;
  int *piStack_2c;
  float fStack_28;
  int *piStack_24;
  char *pcStack_20;
  float fStack_1c;
  float fStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aa543;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_38 = 0;
  ExceptionList = &pvStack_10;
  puVar6 = (undefined *)FUN_01674e20(0x18);
  piStack_24 = (int *)puVar6;
  if (puVar6 == (undefined *)0x0) {
    puVar6 = (undefined *)0x0;
  }
  else {
    *puVar6 = 0;
    fStack_18 = 1.54143e-44;
    ppuVar7 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&fStack_18);
    ppuVar12 = ppuVar7 + -1;
    if (ppuVar7 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar12 = ppuVar7;
    }
    *(undefined **)(puVar6 + 4) = *ppuVar12;
    *(undefined4 *)(puVar6 + 8) = 0;
    *(undefined4 *)(puVar6 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar6 + 0x10) = 0;
    *(undefined4 *)(puVar6 + 0x14) = 0;
  }
  uStack_58 = 0;
  piStack_54 = (int *)0x0;
  FUN_005c1af0(puVar6,param_1);
  uStack_8 = 1;
  puVar6 = (undefined *)FUN_01674e20(0x18);
  piStack_24 = (int *)puVar6;
  if (puVar6 == (undefined *)0x0) {
    puVar6 = (undefined *)0x0;
  }
  else {
    *puVar6 = 0;
    fStack_18 = 1.54143e-44;
    ppuVar7 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&fStack_18);
    ppuVar12 = ppuVar7 + -1;
    if (ppuVar7 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar12 = ppuVar7;
    }
    *(undefined **)(puVar6 + 4) = *ppuVar12;
    *(undefined4 *)(puVar6 + 8) = 0;
    *(undefined4 *)(puVar6 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar6 + 0x10) = 0;
    *(undefined4 *)(puVar6 + 0x14) = 0;
  }
  uStack_60 = 0;
  piStack_5c = (int *)0x0;
  FUN_005c1af0(puVar6,param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puVar6 = (undefined *)FUN_01674e20(0x18);
  piStack_24 = (int *)puVar6;
  if (puVar6 == (undefined *)0x0) {
    puVar6 = (undefined *)0x0;
  }
  else {
    *puVar6 = 0;
    fStack_18 = 1.54143e-44;
    ppuVar7 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&fStack_18);
    ppuVar12 = ppuVar7 + -1;
    if (ppuVar7 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar12 = ppuVar7;
    }
    *(undefined **)(puVar6 + 4) = *ppuVar12;
    *(undefined4 *)(puVar6 + 8) = 0;
    *(undefined4 *)(puVar6 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar6 + 0x10) = 0;
    *(undefined4 *)(puVar6 + 0x14) = 0;
  }
  uStack_4c = 0;
  piStack_48 = (int *)0x0;
  FUN_005c1af0(puVar6,param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  puVar6 = (undefined *)FUN_01674e20(0x18);
  piStack_24 = (int *)puVar6;
  if (puVar6 == (undefined *)0x0) {
    puVar6 = (undefined *)0x0;
  }
  else {
    *puVar6 = 0;
    fStack_18 = 1.54143e-44;
    ppuVar7 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&fStack_18);
    ppuVar12 = ppuVar7 + -1;
    if (ppuVar7 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar12 = ppuVar7;
    }
    *(undefined **)(puVar6 + 4) = *ppuVar12;
    *(undefined4 *)(puVar6 + 8) = 0;
    *(undefined4 *)(puVar6 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar6 + 0x10) = 0;
    *(undefined4 *)(puVar6 + 0x14) = 0;
  }
  uStack_44 = 0;
  piStack_40 = (int *)0x0;
  FUN_005c1af0(puVar6,param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  piVar8 = (int *)FUN_01674e20(0x18);
  piStack_24 = piVar8;
  if (piVar8 == (int *)0x0) {
    piVar8 = (int *)0x0;
  }
  else {
    *(undefined *)piVar8 = 0;
    fStack_18 = 1.54143e-44;
    ppuVar7 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&fStack_18);
    ppuVar12 = ppuVar7 + -1;
    if (ppuVar7 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar12 = ppuVar7;
    }
    piVar8[1] = (int)*ppuVar12;
    piVar8[2] = 0;
    piVar8[3] = 0x3f800000;
    piVar8[4] = 0;
    piVar8[5] = 0;
  }
  uStack_68 = 0;
  piStack_64 = (int *)0x0;
  FUN_005c1af0(piVar8,param_1);
  uVar2 = param_2;
  uStack_8._0_1_ = 5;
  fStack_18 = (float)FUN_006ac4d0();
  if (4 < (int)fStack_18) {
    if (piStack_40 != (int *)0x0) {
      LOCK();
      piStack_40[1] = piStack_40[1] + 1;
      UNLOCK();
    }
    FUN_00701290(uVar2,uStack_44,piStack_40);
  }
  if (2 < (int)fStack_18) {
    if (piStack_48 != (int *)0x0) {
      LOCK();
      piStack_48[1] = piStack_48[1] + 1;
      UNLOCK();
    }
    FUN_00701040(uVar2,uStack_4c,piStack_48);
  }
  cVar5 = FUN_006abd90();
  uVar14 = 0;
  while (cVar5 == '\0') {
    FUN_006acbd0(aiStack_188);
    uStack_8._0_1_ = 6;
    fVar15 = (float10)FUN_006ac3c0();
    fStack_18 = (float)fVar15;
    fVar15 = (float10)FUN_006ac3c0();
    fStack_50 = (float)fVar15;
    fVar15 = (float10)FUN_006ac3c0();
    fStack_3c = (float)fVar15;
    puVar9 = (undefined4 *)FUN_01674e20(0xc);
    if (puVar9 == (undefined4 *)0x0) {
      puVar9 = (undefined4 *)0x0;
    }
    else {
      *puVar9 = 0;
      puVar9[1] = 0;
      puVar9[2] = 0;
    }
    fStack_28 = 0.0;
    piStack_24 = (int *)0x0;
    FUN_006047e0(puVar9,param_1);
    uStack_8._0_1_ = 7;
    uStack_158 = FUN_0088c960();
    puStack_154 = (undefined4 *)0x0;
    fStack_150 = fStack_18;
    puStack_154 = (undefined4 *)FUN_00630820();
    fVar10 = fStack_28;
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    if (*(int *)((int)fStack_28 + 8) == *(int *)((int)fStack_28 + 4)) {
      FUN_005ca4f0(*(int *)((int)fStack_28 + 4),&uStack_158);
    }
    else {
      FUN_005caf00(&uStack_158);
      *(int *)((int)fVar10 + 4) = *(int *)((int)fVar10 + 4) + 0xd0;
    }
    uStack_8._0_1_ = 9;
    if (puStack_154 != (undefined4 *)0x0) {
      (**(code **)((int)puStack_154 + 8))(&fStack_150);
    }
    uStack_8._0_1_ = 7;
    uStack_158 = FUN_0088c960();
    puStack_154 = (undefined4 *)0x0;
    fStack_150 = fStack_50;
    puStack_154 = (undefined4 *)FUN_00630820();
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    if (*(int *)((int)fVar10 + 8) == *(int *)((int)fVar10 + 4)) {
      FUN_005ca4f0(*(int *)((int)fVar10 + 4),&uStack_158);
    }
    else {
      FUN_005caf00(&uStack_158);
      *(int *)((int)fVar10 + 4) = *(int *)((int)fVar10 + 4) + 0xd0;
    }
    uStack_8._0_1_ = 0xb;
    if (puStack_154 != (undefined4 *)0x0) {
      (**(code **)((int)puStack_154 + 8))(&fStack_150);
    }
    uStack_8._0_1_ = 7;
    uStack_158 = FUN_0088c960();
    puStack_154 = (undefined4 *)0x0;
    fStack_150 = fStack_3c;
    puStack_154 = (undefined4 *)FUN_00630820();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    if (*(int *)((int)fVar10 + 8) == *(int *)((int)fVar10 + 4)) {
      FUN_005ca4f0(*(int *)((int)fVar10 + 4),&uStack_158);
    }
    else {
      FUN_005caf00(&uStack_158);
      *(int *)((int)fVar10 + 4) = *(int *)((int)fVar10 + 4) + 0xd0;
    }
    uStack_8._0_1_ = 0xd;
    if (puStack_154 != (undefined4 *)0x0) {
      (**(code **)((int)puStack_154 + 8))(&fStack_150);
    }
    piVar8 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[1] = piStack_24[1] + 1;
      UNLOCK();
    }
    fStack_30 = fVar10;
    piStack_2c = piStack_24;
    uStack_8._0_1_ = 0xe;
    FUN_0054ef60(aiStack_188);
    uStack_170 = uStack_88;
    uStack_38 = uStack_38 | 2;
    fStack_70 = fVar10;
    piStack_6c = piVar8;
    fStack_30 = 0.0;
    piStack_2c = (int *)0x0;
    uStack_88 = uStack_88 & 0xffffff00;
    uStack_16c = uStack_84;
    uStack_168 = uStack_80;
    uStack_164 = uStack_7c;
    uStack_160 = CONCAT44(uStack_74,uStack_78);
    uStack_78 = 0;
    uStack_74 = 0xf;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
    uStack_158 = FUN_008882f0();
    fStack_150 = fVar10;
    puStack_154 = (undefined4 *)0x0;
    piStack_14c = piVar8;
    fStack_70 = 0.0;
    piStack_6c = (int *)0x0;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c38)
       && (FUN_016f3809(&DAT_01ea8c38), DAT_01ea8c38 == -1)) {
      DAT_01ea8c2c = FUN_0057bbb0;
      DAT_01ea8c30 = FUN_005880a0;
      DAT_01ea8c34 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ea8c38);
    }
    puStack_154 = &DAT_01ea8c2c;
    uStack_8._0_1_ = 0x11;
    FUN_006eb500(&pcStack_20,&uStack_170,&uStack_170);
    uStack_8._0_1_ = 0x12;
    if (puStack_154 != (undefined4 *)0x0) {
      (*(code *)puStack_154[2])(&fStack_150);
    }
    uStack_8._0_1_ = 0xf;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xf;
    if (0xf < uStack_160._4_4_) {
      uVar13 = uStack_160._4_4_ + 1;
      uVar14 = uStack_170;
      if (0xfff < uVar13) {
        uVar14 = *(uint *)(uStack_170 - 4);
        uVar13 = uStack_160._4_4_ + 0x24;
        if (0x1f < (uStack_170 - uVar14) - 4) goto LAB_006f3236;
      }
      FUN_01674ea0(uVar14,uVar13);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    cStack_11 = FUN_006abd90();
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar11 = piVar8[1] + -1;
      piVar8[1] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        (**(code **)*piVar8)();
        LOCK();
        iVar11 = piVar8[2] + -1;
        piVar8[2] = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    uStack_8._0_1_ = 5;
    uVar14 = uStack_38;
    cVar5 = cStack_11;
    if (0xf < uStack_174) {
      uVar14 = uStack_174 + 1;
      iVar11 = aiStack_188[0];
      if (0xfff < uVar14) {
        iVar11 = *(int *)(aiStack_188[0] + -4);
        uVar14 = uStack_174 + 0x24;
        uVar4 = (undefined)uStack_8;
        if (0x1f < (aiStack_188[0] - iVar11) - 4U) goto LAB_006f3236;
      }
      FUN_01674ea0(iVar11,uVar14);
      uVar14 = uStack_38;
      cVar5 = cStack_11;
    }
  }
  cVar5 = FUN_006abd90();
  do {
    if (cVar5 != '\0') {
      fVar15 = (float10)FUN_006ac3c0();
      fStack_3c = (float)fVar15;
      fVar15 = (float10)FUN_006ac3c0();
      fStack_50 = (float)fVar15;
      fVar15 = (float10)FUN_006ac3c0();
      fStack_18 = (float)fVar15;
      fVar15 = (float10)FUN_006ac3c0();
      piStack_2c = (int *)(float)fVar15;
      fVar15 = (float10)FUN_006ac3c0();
      piStack_24 = (int *)(float)fVar15;
      puVar6 = (undefined *)FUN_01674e20(0x18);
      if (puVar6 == (undefined *)0x0) {
        puVar6 = (undefined *)0x0;
        param_2 = 0;
      }
      else {
        *puVar6 = 0;
        param_2 = 0xb;
        ppuVar7 = (undefined **)
                  FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2);
        ppuVar12 = ppuVar7 + -1;
        if (ppuVar7 != &boost::lock_error::vftable_meta_ptr) {
          ppuVar12 = ppuVar7;
        }
        *(undefined **)(puVar6 + 4) = *ppuVar12;
        *(undefined4 *)(puVar6 + 8) = 0;
        *(undefined4 *)(puVar6 + 0xc) = 0x3f800000;
        *(undefined4 *)(puVar6 + 0x10) = 0;
        *(undefined4 *)(puVar6 + 0x14) = 0;
      }
      *param_1 = 0;
      param_1[1] = 0;
      FUN_005c1af0(puVar6,param_1);
      uStack_38 = uVar14 | 1;
      pcStack_20 = "Avg Ping ms";
      fStack_1c = fStack_3c;
      FUN_006ea480(&pcStack_20);
      uStack_8._0_1_ = 0x1e;
      FUN_006eb500(&pcStack_20,&uStack_170,&uStack_170);
      uStack_8._0_1_ = 5;
      FUN_0056cb40();
      pcStack_20 = "Avg Physics Sender Pkt/s";
      fStack_1c = fStack_50;
      FUN_006ea480(&pcStack_20);
      uStack_8._0_1_ = 0x1f;
      FUN_006eb500(&pcStack_20,&uStack_170,&uStack_170);
      uStack_8._0_1_ = 5;
      FUN_0056cb40();
      pcStack_20 = "Total Data KB/s";
      fStack_1c = fStack_18;
      FUN_006ea480(&pcStack_20);
      uStack_8._0_1_ = 0x20;
      FUN_006eb500(&pcStack_20,&uStack_170,&uStack_170);
      uStack_8._0_1_ = 5;
      FUN_0056cb40();
      pcStack_20 = "Total Physics KB/s";
      fStack_1c = (float)piStack_2c;
      FUN_006ea480(&pcStack_20);
      uStack_8._0_1_ = 0x21;
      FUN_006eb500(&pcStack_20,&uStack_170,&uStack_170);
      uStack_8._0_1_ = 5;
      FUN_0056cb40();
      pcStack_20 = "Data Throughput ratio";
      fStack_1c = (float)piStack_24;
      FUN_006ea480(&pcStack_20);
      uStack_8._0_1_ = 0x22;
      FUN_006eb500(&pcStack_20,&uStack_170,&uStack_170);
      FUN_0056cb40();
      if (piStack_48 != (int *)0x0) {
        LOCK();
        piStack_48[1] = piStack_48[1] + 1;
        UNLOCK();
      }
      pcStack_34 = "DataStoreBudget";
      fStack_30 = (float)uStack_4c;
      piStack_2c = piStack_48;
      pcStack_20 = (char *)0x0;
      fStack_1c = 0.0;
      uStack_8._0_1_ = 0x24;
      FUN_006ea510(&pcStack_34);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x25);
      FUN_006eb500(&fStack_28,&uStack_170,&uStack_170);
      FUN_0056cb40();
      piVar8 = piStack_2c;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar11 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          (**(code **)*piStack_2c)();
          LOCK();
          piVar1 = piVar8 + 2;
          iVar11 = *piVar1 + -1;
          *piVar1 = iVar11;
          UNLOCK();
          if (iVar11 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      if (piStack_54 != (int *)0x0) {
        LOCK();
        piStack_54[1] = piStack_54[1] + 1;
        UNLOCK();
      }
      pcStack_34 = "Jobs";
      fStack_30 = (float)uStack_58;
      piStack_2c = piStack_54;
      pcStack_20 = (char *)0x0;
      fStack_1c = 0.0;
      uStack_8._0_1_ = 0x27;
      FUN_006ea510(&pcStack_34);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x28);
      FUN_006eb500(&fStack_28,&uStack_170,&uStack_170);
      FUN_0056cb40();
      piVar8 = piStack_2c;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar11 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          (**(code **)*piStack_2c)();
          LOCK();
          piVar1 = piVar8 + 2;
          iVar11 = *piVar1 + -1;
          *piVar1 = iVar11;
          UNLOCK();
          if (iVar11 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      piVar8 = piStack_5c;
      param_2 = *param_1;
      if (piStack_5c != (int *)0x0) {
        LOCK();
        piStack_5c[1] = piStack_5c[1] + 1;
        UNLOCK();
      }
      pcStack_34 = "Scripts";
      fStack_30 = (float)uStack_60;
      piStack_2c = piStack_5c;
      pcStack_20 = (char *)0x0;
      fStack_1c = 0.0;
      uStack_8._0_1_ = 0x2a;
      FUN_006ea510(&pcStack_34);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x2b);
      FUN_006eb500(&fStack_28,&uStack_170,&uStack_170);
      FUN_0056cb40();
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar11 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          (**(code **)*piStack_2c)();
          LOCK();
          iVar11 = piStack_2c[2] + -1;
          piStack_2c[2] = iVar11;
          UNLOCK();
          if (iVar11 == 0) {
            (**(code **)(*piStack_2c + 4))();
          }
        }
      }
      param_2 = *param_1;
      if (piStack_40 != (int *)0x0) {
        LOCK();
        piStack_40[1] = piStack_40[1] + 1;
        UNLOCK();
      }
      pcStack_34 = "ServerMemoryTree";
      fStack_30 = (float)uStack_44;
      piStack_2c = piStack_40;
      pcStack_20 = (char *)0x0;
      fStack_1c = 0.0;
      uStack_8._0_1_ = 0x2d;
      FUN_006ea510(&pcStack_34);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x2e);
      FUN_006eb500(&fStack_28,&uStack_170,&uStack_170);
      FUN_0056cb40();
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar11 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          (**(code **)*piStack_2c)();
          LOCK();
          iVar11 = piStack_2c[2] + -1;
          piStack_2c[2] = iVar11;
          UNLOCK();
          if (iVar11 == 0) {
            (**(code **)(*piStack_2c + 4))();
          }
        }
      }
      if (piStack_64 != (int *)0x0) {
        LOCK();
        iVar11 = piStack_64[1] + -1;
        piStack_64[1] = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          (**(code **)*piStack_64)();
          LOCK();
          iVar11 = piStack_64[2] + -1;
          piStack_64[2] = iVar11;
          UNLOCK();
          if (iVar11 == 0) {
            (**(code **)(*piStack_64 + 4))();
          }
        }
      }
      if (piStack_40 != (int *)0x0) {
        LOCK();
        iVar11 = piStack_40[1] + -1;
        piStack_40[1] = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          (**(code **)*piStack_40)();
          LOCK();
          iVar11 = piStack_40[2] + -1;
          piStack_40[2] = iVar11;
          UNLOCK();
          if (iVar11 == 0) {
            (**(code **)(*piStack_40 + 4))();
          }
        }
      }
      if (piStack_48 != (int *)0x0) {
        LOCK();
        iVar11 = piStack_48[1] + -1;
        piStack_48[1] = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          (**(code **)*piStack_48)();
          LOCK();
          iVar11 = piStack_48[2] + -1;
          piStack_48[2] = iVar11;
          UNLOCK();
          if (iVar11 == 0) {
            (**(code **)(*piStack_48 + 4))();
          }
        }
      }
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar11 = piVar8[1] + -1;
        piVar8[1] = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          (**(code **)*piVar8)();
          LOCK();
          iVar11 = piVar8[2] + -1;
          piVar8[2] = iVar11;
          UNLOCK();
          if (iVar11 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      piVar8 = piStack_54;
      if (piStack_54 != (int *)0x0) {
        LOCK();
        iVar11 = piStack_54[1] + -1;
        piStack_54[1] = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          (**(code **)*piStack_54)();
          LOCK();
          piVar1 = piVar8 + 2;
          iVar11 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar11 == 1) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return param_1;
    }
    FUN_006acbd0(aiStack_188);
    uStack_8._0_1_ = 0x13;
    fVar15 = (float10)FUN_006ac3c0();
    fStack_3c = (float)fVar15;
    fVar10 = (float)FUN_006ac4d0();
    puVar9 = (undefined4 *)FUN_01674e20(0xc);
    if (puVar9 == (undefined4 *)0x0) {
      puVar9 = (undefined4 *)0x0;
    }
    else {
      *puVar9 = 0;
      puVar9[1] = 0;
      puVar9[2] = 0;
    }
    fStack_28 = 0.0;
    piStack_24 = (int *)0x0;
    FUN_006047e0(puVar9,param_1);
    uStack_8._0_1_ = 0x14;
    uStack_158 = FUN_0088c960();
    puStack_154 = (undefined4 *)0x0;
    fStack_150 = fStack_3c;
    puStack_154 = (undefined4 *)FUN_00630820();
    fVar3 = fStack_28;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
    if (*(int *)((int)fStack_28 + 8) == *(int *)((int)fStack_28 + 4)) {
      FUN_005ca4f0(*(int *)((int)fStack_28 + 4),&uStack_158);
    }
    else {
      FUN_005caf00(&uStack_158);
      *(int *)((int)fVar3 + 4) = *(int *)((int)fVar3 + 4) + 0xd0;
    }
    uStack_8._0_1_ = 0x16;
    if (puStack_154 != (undefined4 *)0x0) {
      (**(code **)((int)puStack_154 + 8))(&fStack_150);
    }
    uStack_8._0_1_ = 0x14;
    uStack_158 = FUN_0088c8c0();
    puStack_154 = (undefined4 *)0x0;
    fStack_150 = fVar10;
    puStack_154 = (undefined4 *)FUN_005c9cc0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0x17);
    if (*(int *)((int)fVar3 + 8) == *(int *)((int)fVar3 + 4)) {
      FUN_005ca4f0(*(int *)((int)fVar3 + 4),&uStack_158);
    }
    else {
      FUN_005caf00(&uStack_158);
      *(int *)((int)fVar3 + 4) = *(int *)((int)fVar3 + 4) + 0xd0;
    }
    uStack_8._0_1_ = 0x18;
    if (puStack_154 != (undefined4 *)0x0) {
      (**(code **)((int)puStack_154 + 8))(&fStack_150);
    }
    piVar8 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[1] = piStack_24[1] + 1;
      UNLOCK();
    }
    fStack_30 = fVar3;
    piStack_2c = piStack_24;
    uStack_8._0_1_ = 0x19;
    FUN_0054ef60(aiStack_188);
    uStack_170 = uStack_88;
    uStack_38 = uStack_38 | 4;
    fStack_70 = fVar3;
    piStack_6c = piVar8;
    fStack_30 = 0.0;
    piStack_2c = (int *)0x0;
    uStack_88 = uStack_88 & 0xffffff00;
    uStack_16c = uStack_84;
    uStack_168 = uStack_80;
    uStack_164 = uStack_7c;
    uStack_160 = CONCAT44(uStack_74,uStack_78);
    uStack_78 = 0;
    uStack_74 = 0xf;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x1b);
    uStack_158 = FUN_008882f0();
    fStack_150 = fVar3;
    puStack_154 = (undefined4 *)0x0;
    piStack_14c = piVar8;
    fStack_70 = 0.0;
    piStack_6c = (int *)0x0;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c38)
       && (FUN_016f3809(&DAT_01ea8c38), DAT_01ea8c38 == -1)) {
      DAT_01ea8c2c = FUN_0057bbb0;
      DAT_01ea8c30 = FUN_005880a0;
      DAT_01ea8c34 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ea8c38);
    }
    puStack_154 = &DAT_01ea8c2c;
    uStack_8._0_1_ = 0x1c;
    FUN_006eb500(&pcStack_20,&uStack_170,&uStack_170);
    uStack_8._0_1_ = 0x1d;
    if (puStack_154 != (undefined4 *)0x0) {
      (*(code *)puStack_154[2])(&fStack_150);
    }
    uStack_8._0_1_ = 0x1a;
    if (0xf < uStack_160._4_4_) {
      uVar13 = uStack_160._4_4_ + 1;
      uVar14 = uStack_170;
      if (0xfff < uVar13) {
        uVar14 = *(uint *)(uStack_170 - 4);
        uVar13 = uStack_160._4_4_ + 0x24;
        uVar4 = (undefined)uStack_8;
        if (0x1f < (uStack_170 - uVar14) - 4) {
LAB_006f3236:
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar14,uVar13);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
    cStack_11 = FUN_006abd90();
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar11 = piVar8[1] + -1;
      piVar8[1] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        (**(code **)*piVar8)();
        LOCK();
        iVar11 = piVar8[2] + -1;
        piVar8[2] = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    uStack_8._0_1_ = 5;
    uVar14 = uStack_38;
    cVar5 = cStack_11;
    if (0xf < uStack_174) {
      uVar14 = uStack_174 + 1;
      iVar11 = aiStack_188[0];
      if (0xfff < uVar14) {
        iVar11 = *(int *)(aiStack_188[0] + -4);
        uVar14 = uStack_174 + 0x24;
        uVar4 = (undefined)uStack_8;
        if (0x1f < (aiStack_188[0] - iVar11) - 4U) goto LAB_006f3236;
      }
      FUN_01674ea0(iVar11,uVar14);
      uVar14 = uStack_38;
      cVar5 = cStack_11;
    }
  } while( true );
}



/* FUNCTION 9635 ; VA 0x006f3290 ; FUN_006f3290 */

void __thiscall FUN_006f3290(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0x3b94) != 0) {
    FUN_007107d0(param_2 + 0x10,param_2 + 0x1c);
  }
  return;
}



/* FUNCTION 9636 ; VA 0x006f32c0 ; FUN_006f32c0 */

void __thiscall FUN_006f32c0(int *param_1,int param_2)

{
  double dVar1;
  short sVar2;
  int iVar3;
  double *pdVar4;
  double dVar5;
  double dVar6;
  double dVar7;
  undefined8 uStack_2c;
  int iStack_24;
  int iStack_20;
  double dStack_1c;
  double dStack_14;
  undefined8 uStack_c;
  
  FUN_016827e0(&dStack_14);
  uStack_2c = *(undefined8 *)(param_2 + 0x10);
  iVar3 = *(int *)(param_2 + 0x24);
  iStack_24 = *(int *)(param_2 + 0x18);
  if (iVar3 == 3) {
    iStack_20 = param_1[0xf2f] + 1;
    dStack_1c._0_4_ = param_1[0xf30];
    iStack_24 = param_1[0xf31];
  }
  else if (iVar3 == 1) {
    iStack_20 = param_1[0xf2f];
    dStack_1c._0_4_ = param_1[0xf30] + 1;
    iStack_24 = param_1[0xf31];
  }
  else {
    if (iVar3 != 2) goto LAB_006f3357;
    iStack_20 = param_1[0xf2f];
    dStack_1c._0_4_ = param_1[0xf30];
    iStack_24 = param_1[0xf31] + 1;
  }
  uStack_2c = CONCAT44(dStack_1c._0_4_,iStack_20);
LAB_006f3357:
  *(undefined8 *)(param_1 + 0xf2f) = uStack_2c;
  param_1[0xf31] = iStack_24;
  if (param_1[0xee5] != 0) {
    FUN_0070df00(&uStack_2c,1);
  }
  if (*(int *)(param_2 + 0x1c) != 0) {
    iVar3 = (**(code **)(*param_1 + 0x1b8))(*(int *)(param_2 + 0x1c));
    param_1[0xf33] = param_1[0xf33] + iVar3;
    if (0 < iVar3) {
      pdVar4 = (double *)FUN_016827a0(&dStack_1c);
      if (*(double *)(param_1 + 0xefe) <= *pdVar4 - *(double *)(param_1 + 0xefc)) {
        param_1[0xf00] = param_1[0xf01];
        param_1[0xf01] = 0;
        FUN_016827a0(&uStack_c);
        param_1[0xefc] = (int)uStack_c;
        param_1[0xefd] = uStack_c._4_4_;
      }
      param_1[0xf01] = param_1[0xf01] + 1;
      uStack_c = (double)iVar3;
      sVar2 = FUN_017265ed(&uStack_c);
      if (sVar2 < 1) {
        dVar1 = *(double *)(param_1 + 0xee8);
        dVar7 = DAT_018c0d60 - dVar1;
        dVar5 = (double)iVar3;
        dVar6 = dVar5;
        if (*(char *)(param_1 + 0xef0) == '\0') {
          dVar6 = *(double *)(param_1 + 0xeec) * dVar7 + dVar1 * dVar5;
        }
        *(double *)(param_1 + 0xeea) = dVar5;
        *(undefined *)(param_1 + 0xef0) = 0;
        *(double *)(param_1 + 0xeec) = dVar6;
        *(double *)(param_1 + 0xeee) =
             (dVar5 - dVar6) * (dVar5 - dVar6) * dVar1 + *(double *)(param_1 + 0xeee) * dVar7;
      }
      pdVar4 = (double *)FUN_016827e0((int)&uStack_2c + 4);
      uStack_c = *pdVar4 - dStack_14;
      dStack_1c = uStack_c;
      sVar2 = FUN_017265ed(&dStack_1c);
      if (sVar2 < 1) {
        dVar1 = *(double *)(param_1 + 0xef2);
        dVar5 = DAT_018c0d60 - dVar1;
        dVar6 = uStack_c;
        if (*(char *)(param_1 + 0xefa) == '\0') {
          dVar6 = *(double *)(param_1 + 0xef6) * dVar5 + dVar1 * uStack_c;
        }
        *(double *)(param_1 + 0xef4) = uStack_c;
        *(undefined *)(param_1 + 0xefa) = 0;
        *(double *)(param_1 + 0xef6) = dVar6;
        *(double *)(param_1 + 0xef8) =
             (uStack_c - dVar6) * (uStack_c - dVar6) * dVar1 + *(double *)(param_1 + 0xef8) * dVar5;
      }
    }
  }
  return;
}



/* FUNCTION 9637 ; VA 0x006f3550 ; FUN_006f3550 */

void __thiscall FUN_006f3550(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0x3b94) != 0) {
    FUN_007108a0(param_2 + 0x10,param_2 + 0x1c,*(undefined *)(param_2 + 0x20));
  }
  return;
}



/* FUNCTION 9638 ; VA 0x006f3580 ; FUN_006f3580 */

void __fastcall FUN_006f3580(int param_1)

{
  if (*(int *)(param_1 + 0x3b94) != 0) {
    FUN_007107c0();
  }
  return;
}



/* FUNCTION 9639 ; VA 0x006f35a0 ; FUN_006f35a0 */

void FUN_006f35a0(int param_1)

{
  FUN_006f1350(*(undefined4 *)(param_1 + 0x10));
  return;
}



/* FUNCTION 9640 ; VA 0x006f35c0 ; FUN_006f35c0 */

void __thiscall FUN_006f35c0(int param_1,double param_2)

{
  double dVar1;
  short sVar2;
  double *pdVar3;
  double dVar4;
  double dVar5;
  undefined8 uStack_c;
  
  pdVar3 = (double *)FUN_016827a0(&uStack_c);
  if (*(double *)(param_1 + 0x3c38) <= *pdVar3 - *(double *)(param_1 + 0x3c30)) {
    *(undefined4 *)(param_1 + 0x3c40) = *(undefined4 *)(param_1 + 0x3c44);
    *(undefined4 *)(param_1 + 0x3c44) = 0;
    FUN_016827a0(&uStack_c);
    *(undefined4 *)(param_1 + 0x3c30) = (undefined4)uStack_c;
    *(undefined4 *)(param_1 + 0x3c34) = uStack_c._4_4_;
  }
  *(int *)(param_1 + 0x3c44) = *(int *)(param_1 + 0x3c44) + 1;
  uStack_c = param_2;
  sVar2 = FUN_017265ed(&uStack_c);
  if (sVar2 < 1) {
    dVar1 = *(double *)(param_1 + 0x3c08);
    dVar5 = DAT_018c0d60 - dVar1;
    dVar4 = param_2;
    if (*(char *)(param_1 + 0x3c28) == '\0') {
      dVar4 = *(double *)(param_1 + 0x3c18) * dVar5 + dVar1 * param_2;
    }
    *(double *)(param_1 + 0x3c10) = param_2;
    *(undefined *)(param_1 + 0x3c28) = 0;
    *(double *)(param_1 + 0x3c18) = dVar4;
    *(double *)(param_1 + 0x3c20) =
         (param_2 - dVar4) * (param_2 - dVar4) * dVar1 + *(double *)(param_1 + 0x3c20) * dVar5;
  }
  return;
}



/* FUNCTION 9641 ; VA 0x006f36c0 ; FUN_006f36c0 */

void __fastcall FUN_006f36c0(int param_1)

{
  if (*(int *)(param_1 + 0x3b94) != 0) {
    FUN_0070f440();
    return;
  }
  return;
}



/* FUNCTION 9642 ; VA 0x006f36e0 ; FUN_006f36e0 */

void __thiscall FUN_006f36e0(int param_1,undefined4 param_2)

{
  if (*(int *)(param_1 + 0x3b94) != 0) {
    FUN_0070e5b0(param_2);
  }
  return;
}



/* FUNCTION 9643 ; VA 0x006f3700 ; FUN_006f3700 */

void __fastcall FUN_006f3700(int param_1)

{
  if (*(int *)(param_1 + 0x3b94) != 0) {
    FUN_0070e6a0();
    return;
  }
  return;
}



/* FUNCTION 9644 ; VA 0x006f3720 ; FUN_006f3720 */

/* WARNING: Removing unreachable block (ram,0x006f39cd) */
/* WARNING: Removing unreachable block (ram,0x006f39db) */
/* WARNING: Removing unreachable block (ram,0x006f3ace) */
/* WARNING: Removing unreachable block (ram,0x006f39ef) */

void __fastcall FUN_006f3720(int param_1)

{
  code *pcVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined2 uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa560;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar2 = (int *)FUN_0054db20();
  pcVar1 = *(code **)(*piVar2 + 0x168);
  FUN_005f70a0();
  FUN_005f7140();
  uVar5 = DAT_01d5ba38;
  uVar6 = DAT_01d5ba3c;
  uVar7 = DAT_01d5ba40;
  FUN_005f7170(param_1 + 0x74);
  iVar3 = (*pcVar1)(uVar5,uVar6,uVar7);
  iVar4 = *(int *)(param_1 + 0x381c) - iVar3;
  *(float *)(param_1 + 0x3820) = (float)((double)iVar4 + (double)(&DAT_018c0d90)[-(iVar4 >> 0x1f)]);
  iVar4 = FUN_006a6900();
  *(float *)(param_1 + 0x3824) =
       (float)((double)(iVar4 - iVar3) + (double)(&DAT_018c0d90)[-(iVar4 - iVar3 >> 0x1f)]);
  piVar2 = (int *)FUN_0054db20();
  pcVar1 = *(code **)(*piVar2 + 0x94);
  FUN_005f70a0();
  FUN_005f7140();
  uVar5 = DAT_01d5ba38;
  uVar6 = DAT_01d5ba3c;
  uVar7 = DAT_01d5ba40;
  FUN_005f7170();
  (*pcVar1)(uVar5,uVar6,uVar7);
  FUN_0151f6f0();
  iStack_8 = 0;
  FUN_0151fb00();
  FUN_0151fb00();
  FUN_0151fb00();
  FUN_0151fb00();
  FUN_0151fa60("totalBlobBytesRxDuringJoin",*(undefined4 *)(param_1 + 0x3830));
  FUN_0151fa60("totalBlobRxDuringJoin",*(undefined4 *)(param_1 + 0x3834));
  FUN_0151fa60("totalMetaBytesRxInJoin",*(undefined4 *)(param_1 + 0x3838));
  FUN_0151fa60("totalWasteBytesRxInJoin",*(undefined4 *)(param_1 + 0x383c));
  FUN_0151fa60("totalRxBytes",0);
  FUN_0151fa60("totalRxPackets",0);
  FUN_0151fa60("totalRxIgnoredBytes",0);
  FUN_0151fa60("totalRxIgnoredPackets",0);
  FUN_005542c0("ClientJoinRxStats",0x11);
  iStack_8._0_1_ = 1;
  FUN_01520d20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (((DAT_01eaf35d != '\0') &&
      (FUN_01677520(DAT_01eaf35d,
                    "Join Rx Times : deltaTimeBetweenJoinRequestAndFirstBlobArrival=%fms, deltaTimeBetweenJoinRequestAndJoinProcessingComplete=%fms, joinDataReadTime=%fms, joinDataProcessTime=%fms"
                    ,(double)*(float *)(param_1 + 0x3820),(double)*(float *)(param_1 + 0x3824),
                    (double)*(float *)(param_1 + 0x3828),(double)*(float *)(param_1 + 0x382c)),
      DAT_01eaf35d != '\0')) &&
     (FUN_01677520(DAT_01eaf35d,
                   "Join Rx Blob Stats : totalBlobBytesRxDuringJoin=%d, totalBlobRxDuringJoin=%d, totalMetaBytesRxInJoin=%d, totalWasteBytesRxInJoin=%d"
                   ,*(undefined4 *)(param_1 + 0x3830),*(undefined4 *)(param_1 + 0x3834),
                   *(undefined4 *)(param_1 + 0x3838),*(undefined4 *)(param_1 + 0x383c)),
     DAT_01eaf35d != '\0')) {
    FUN_01677520(DAT_01eaf35d,
                 "Join Rx Packet Stats : totalRxBytes=%d, totalRxPackets=%d, totalRxIgnoredBytes=%d, totalRxIgnoredPackets=%d"
                 ,0,0,0,0);
  }
  FUN_0151f7f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9645 ; VA 0x006f3ae0 ; FUN_006f3ae0 */

void __thiscall FUN_006f3ae0(int param_1,int *param_2,int param_3)

{
  code *pcVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined2 uVar6;
  undefined auStack_3c [40];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4e78;
  pvStack_10 = ExceptionList;
  if ((DAT_01d5ba74 != '\0') && (*(char *)(param_1 + 0x3844) == '\0')) {
    ExceptionList = &pvStack_10;
    *(undefined *)(param_1 + 0x3844) = 1;
    iVar2 = (int)param_2;
    if ((int)param_2 < 1) {
      iVar2 = 0;
    }
    iVar3 = param_3;
    if (param_3 < 1) {
      iVar3 = 0;
    }
    iStack_14 = param_1;
    FUN_006ab530();
    uStack_8 = 0;
    param_2 = (int *)CONCAT31(param_2._1_3_,0x99);
    FUN_006ad5e0(&param_2,1);
    param_2 = (int *)0x1;
    FUN_006a5c10(&param_2,&param_3,4);
    FUN_006ad5e0(&param_3,4);
    param_2 = (int *)DAT_01eaf364;
    if (0 < iVar2) {
      param_2 = (int *)iVar2;
    }
    FUN_006a5c10(&param_2,&param_3,4);
    FUN_006ad5e0(&param_3,4);
    param_2 = (int *)DAT_01eaf368;
    if (0 < iVar3) {
      param_2 = (int *)iVar3;
    }
    FUN_006a5c10(&param_2,&param_3,4);
    FUN_006ad5e0(&param_3,4);
    param_2 = (int *)FUN_0054db20();
    pcVar1 = *(code **)(*param_2 + 0x4c);
    FUN_005f70a0();
    FUN_005f7140();
    uVar4 = DAT_01d5ba38;
    uVar5 = DAT_01d5ba3c;
    uVar6 = DAT_01d5ba40;
    FUN_005f7170(iStack_14 + 0x74);
    (*pcVar1)(auStack_3c,2,3,0,uVar4,uVar5,uVar6);
    FUN_00613200();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9646 ; VA 0x006f3c60 ; FUN_006f3c60 */

void FUN_006f3c60(int *param_1)

{
  code *pcVar1;
  char cVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined2 uVar7;
  undefined auStack_44 [12];
  int iStack_38;
  int iStack_30;
  int iStack_1c;
  undefined auStack_18 [4];
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa578;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006ab530();
  uStack_8 = 0;
  auStack_14[0] = 0x96;
  FUN_006ad5e0(auStack_14,1);
  cVar2 = (char)param_1;
  FUN_006ad5e0(&param_1,1);
  if (cVar2 != '\0') {
    param_1 = (int *)0x5;
    FUN_006a5c10(&param_1,auStack_18,4);
    FUN_006ad5e0(auStack_18,4);
  }
  param_1 = (int *)FUN_0054db20();
  pcVar1 = *(code **)(*param_1 + 0x4c);
  FUN_005f70a0();
  FUN_005f7140();
  uVar5 = DAT_01d5ba38;
  uVar6 = DAT_01d5ba3c;
  uVar7 = DAT_01d5ba40;
  FUN_005f7170(iStack_1c + 0x74);
  (*pcVar1)(auStack_44,2,3,0,uVar5,uVar6,uVar7);
  if (iStack_38 != 0) {
    uVar3 = iStack_30 - iStack_38;
    iVar4 = iStack_38;
    if (0xfff < uVar3) {
      iVar4 = *(int *)(iStack_38 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iStack_38 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9647 ; VA 0x006f3d90 ; FUN_006f3d90 */

void FUN_006f3d90(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = *(int *)(param_2 + 4);
  *param_1 = iVar2;
  LOCK();
  piVar1 = (int *)(iVar2 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  return;
}



/* FUNCTION 9648 ; VA 0x006f3db0 ; FUN_006f3db0 */

void __thiscall FUN_006f3db0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  char cVar1;
  int iVar2;
  int iVar3;
  char *pcVar4;
  undefined4 ****ppppuVar5;
  undefined4 ****ppppuVar6;
  char *pcVar7;
  uint uVar8;
  undefined4 ***apppuStack_40 [5];
  uint uStack_2c;
  undefined4 ***apppuStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa5a0;
  pvStack_10 = ExceptionList;
  if ((*(int *)(param_1 + 0x34) != 0) &&
     (iVar2 = *(int *)(*(int *)(param_1 + 0x34) + 0xc), ExceptionList = &pvStack_10,
     iVar3 = FUN_005edc10(),
     (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
     (uint)*(ushort *)(iVar3 + 0x1da))) {
    if (0xf < (uint)param_3[5]) {
      param_3 = (undefined4 *)*param_3;
    }
    FUN_01675640(apppuStack_28,"LocalDisconnect_%d_%s",param_2,param_3);
    uStack_8 = 0;
    if (DAT_01d5b038 == '\0') {
      ppppuVar6 = apppuStack_28;
      if (0xf < uStack_14) {
        ppppuVar6 = (undefined4 ****)apppuStack_28[0];
      }
      FUN_0068de80(ppppuVar6,1);
    }
    else {
      FUN_0068b2d0(apppuStack_40);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      pcVar4 = (char *)FUN_0068b4e0();
      pcVar7 = pcVar4;
      do {
        cVar1 = *pcVar7;
        pcVar7 = pcVar7 + 1;
      } while (cVar1 != '\0');
      FUN_00554150(pcVar4,(int)pcVar7 - (int)(pcVar4 + 1));
      ppppuVar6 = apppuStack_40;
      if (0xf < uStack_2c) {
        ppppuVar6 = (undefined4 ****)apppuStack_40[0];
      }
      ppppuVar5 = apppuStack_28;
      if (0xf < uStack_14) {
        ppppuVar5 = (undefined4 ****)apppuStack_28[0];
      }
      FUN_0068b590(ppppuVar5,1,ppppuVar6,4);
      FUN_005507b0();
    }
    if (0xf < uStack_14) {
      uVar8 = uStack_14 + 1;
      ppppuVar6 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar8) {
        ppppuVar6 = (undefined4 ****)apppuStack_28[0][-1];
        uVar8 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar6,uVar8);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9649 ; VA 0x006f3ef0 ; FUN_006f3ef0 */

void __thiscall FUN_006f3ef0(int param_1,undefined4 param_2,int param_3,ushort param_4)

{
  char cVar1;
  int iVar2;
  uint uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  undefined4 uStack_10;
  int iStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  _param_4 = (uint)param_4;
  if (param_3 == 0) {
    uStack_10 = 0xffffffff;
    iStack_c = 0;
  }
  else {
    uStack_10 = *(undefined4 *)(param_3 + 0x18);
    iStack_c = *(int *)(param_3 + 0x1c);
  }
  uStack_18 = uStack_10;
  iStack_14 = iStack_c;
  iVar2 = param_1 + 0x3b09 + (uint)*(byte *)(param_1 + 0x3b08);
  uStack_1c = _param_4;
  FUN_009c91c0(&param_4,&uStack_18);
  _param_4 = _param_4 ^ (_param_4 >> 2) + 0x9e3779b9 + _param_4 * 0x40 + iStack_14;
  FUN_00676f40(&param_3,_param_4,&uStack_1c,-(uint)(iVar2 != 0) & iVar2 + 1U);
  if (param_3 == 0) {
    cVar1 = '\0';
  }
  else if (*(char *)(param_3 + 0x28) == '\0') {
    *(undefined *)(param_3 + 0x28) = 1;
    cVar1 = '\x01';
    uStack_8 = *(undefined4 *)(param_3 + 0x18);
    *(int *)(param_1 + 0x3b40) = *(int *)(param_1 + 0x3b40) + 1;
  }
  else {
    cVar1 = '\0';
  }
  _param_4 = CONCAT31(stack0x0000000d,cVar1);
  FUN_006ad5e0(&param_4,1);
  if (cVar1 != '\0') {
    FUN_006ad340(uStack_8,param_2);
  }
  return;
}



/* FUNCTION 9650 ; VA 0x006f3ff0 ; FUN_006f3ff0 */

void __thiscall FUN_006f3ff0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x1db4);
  *(undefined4 *)(iVar1 + 0x25c) = param_2;
  *(undefined4 *)(iVar1 + 0x260) = param_3;
  return;
}



/* FUNCTION 9651 ; VA 0x006f4020 ; FUN_006f4020 */

undefined4 __thiscall FUN_006f4020(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  float fVar2;
  float fVar3;
  undefined auStack_20 [8];
  undefined auStack_18 [8];
  double dStack_10;
  char cStack_6;
  char cStack_5;
  
  cStack_6 = '\0';
  cStack_5 = '\0';
  FUN_006266b0(param_2,&cStack_6,&cStack_5);
  if ((cStack_5 != '\0') || (cStack_6 != '\0')) {
    if (NAN(*(float *)(param_1 + 0x19c8)) == (*(float *)(param_1 + 0x19c8) == 0.0)) {
      if (NAN(*(float *)(param_1 + 0x19c4)) == (*(float *)(param_1 + 0x19c4) == 0.0)) {
        FUN_016830f0(&dStack_10);
        fVar3 = *(float *)(param_1 + 0x19c4);
        fVar2 = *(float *)(param_1 + 0x19c0) -
                (float)(dStack_10 - *(double *)(param_1 + 0x19b8)) *
                (fVar3 / *(float *)(param_1 + 0x19c8));
        if (fVar2 <= 0.0) {
          *(undefined4 *)(param_1 + 0x19c0) = 0;
          puVar1 = (undefined4 *)FUN_016830f0(auStack_18);
          fVar3 = *(float *)(param_1 + 0x19c4);
          fVar2 = 0.0;
          *(undefined4 *)(param_1 + 0x19b8) = *puVar1;
          *(undefined4 *)(param_1 + 0x19bc) = puVar1[1];
        }
        if (fVar3 < fVar2 + DAT_018ce2f8) {
          if (DAT_01d5ba6c != '\0') {
            return 1;
          }
        }
        else {
          *(float *)(param_1 + 0x19c0) = fVar2 + DAT_018ce2f8;
          puVar1 = (undefined4 *)FUN_016830f0(auStack_20);
          *(undefined4 *)(param_1 + 0x19b8) = *puVar1;
          *(undefined4 *)(param_1 + 0x19bc) = puVar1[1];
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 9652 ; VA 0x006f4150 ; FUN_006f4150 */

void __thiscall FUN_006f4150(double *param_1,int param_2)

{
  uint *puVar1;
  int *piVar2;
  double *pdVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint in_stack_00000018;
  char in_stack_00000024;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined8 uStack_54;
  undefined8 uStack_4c;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  undefined auStack_34 [8];
  int iStack_2c;
  char cStack_28;
  undefined8 uStack_24;
  int iStack_1c;
  double *pdStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aa5c0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_58 = 0;
  uStack_5c = 0;
  uStack_4c = 0;
  uStack_54 = 0;
  ExceptionList = &pvStack_10;
  pdStack_18 = param_1;
  FUN_006eb2c0(&iStack_2c,&param_2,&param_2,&uStack_5c);
  iStack_1c = iStack_2c;
  pdVar3 = (double *)FUN_01682800(auStack_34);
  uStack_24 = *pdVar3 + *param_1;
  *(double *)(iStack_2c + 0x30) = uStack_24;
  if (cStack_28 != '\0') {
    iStack_44 = iStack_2c + 8;
    FUN_01682800(&iStack_3c);
    puVar1 = (uint *)((int)param_1 + 0x34);
    uStack_24 = (double)CONCAT44(puVar1,(undefined4)uStack_24);
    do {
      LOCK();
      uVar6 = *puVar1;
      *puVar1 = *puVar1 | 1;
      UNLOCK();
    } while ((uVar6 & 1) != 0);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (*(int *)(param_1 + 6) == 0) {
      param_1[7] = (double)CONCAT44(iStack_38,iStack_3c);
    }
    uVar6 = *(uint *)(param_1 + 5);
    if (uVar6 <= *(int *)(param_1 + 6) + 1U) {
      FUN_00617300(1);
      uVar6 = *(uint *)(param_1 + 5);
    }
    *(uint *)((int)param_1 + 0x2c) = *(uint *)((int)param_1 + 0x2c) & uVar6 - 1;
    uStack_14 = *(int *)(param_1 + 6) + *(int *)((int)param_1 + 0x2c) & *(int *)(param_1 + 5) - 1U;
    iVar5 = *(int *)((int)param_1 + 0x24);
    if (*(int *)(iVar5 + uStack_14 * 4) == 0) {
      uVar4 = FUN_01674e20(0x10);
      *(undefined4 *)(*(int *)((int)param_1 + 0x24) + uStack_14 * 4) = uVar4;
      iVar5 = *(int *)((int)pdStack_18 + 0x24);
    }
    piVar2 = *(int **)(iVar5 + uStack_14 * 4);
    *piVar2 = iStack_44;
    piVar2[1] = iStack_40;
    piVar2[2] = iStack_3c;
    piVar2[3] = iStack_38;
    *(int *)(param_1 + 6) = *(int *)(param_1 + 6) + 1;
    *puVar1 = 0;
    iStack_2c = iStack_1c;
  }
  if (in_stack_00000024 == '\0') {
    *(int *)(iStack_2c + 0x28) = *(int *)(iStack_2c + 0x28) + 1;
  }
  else {
    *(undefined4 *)(iStack_2c + 0x28) = 0;
  }
  *(undefined *)(iStack_2c + 0x38) = 0;
  if (0xf < in_stack_00000018) {
    uVar6 = in_stack_00000018 + 1;
    iVar5 = param_2;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(param_2 + -4);
      uVar6 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9653 ; VA 0x006f42e0 ; FUN_006f42e0 */

void __thiscall FUN_006f42e0(int param_1,int *param_2,int *param_3,int param_4,int *param_5)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  int *piVar7;
  int *piVar8;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017aa5e0;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  iVar1 = *param_5;
  ExceptionList = &pvStack_10;
  if ((iVar1 != 0) &&
     (iVar4 = *(int *)(iVar1 + 0xc), ExceptionList = &pvStack_10, iVar3 = FUN_00c391f0(),
     (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
     (uint)*(ushort *)(iVar3 + 0x1da))) {
    iVar4 = FUN_00c3c010();
    iVar3 = FUN_00c3c020();
    if (((iVar4 != 0) || (iVar3 != 0)) && (piVar8 = param_2, param_2 != param_3)) {
      do {
        iVar2 = *piVar8;
        if (iVar2 != 0) {
          if (iVar4 == iVar2) {
            piVar5 = &DAT_02134d38;
          }
          else {
            if (iVar3 != iVar2) goto LAB_006f43b0;
            piVar5 = &DAT_02134d74;
          }
          piVar7 = (int *)(param_1 + 0x98);
          iVar2 = *piVar7;
          *piVar7 = iVar1;
          iStack_8._0_1_ = 1;
          (**(code **)(*piVar5 + 0x48))(iVar1,0);
          *piVar7 = iVar2;
          iStack_8 = (uint)iStack_8._1_3_ << 8;
        }
LAB_006f43b0:
        piVar8 = piVar8 + 2;
      } while (piVar8 != param_3);
    }
  }
  if (param_2 != (int *)0x0) {
    piVar8 = param_2;
    if (param_2 != param_3) {
      do {
        piVar5 = (int *)piVar8[1];
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        piVar8 = piVar8 + 2;
      } while (piVar8 != param_3);
    }
    uVar6 = param_4 - (int)param_2 & 0xfffffff8;
    piVar8 = param_2;
    if (0xfff < uVar6) {
      piVar8 = (int *)param_2[-1];
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)piVar8))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar8,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9654 ; VA 0x006f4440 ; FUN_006f4440 */

void __thiscall FUN_006f4440(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  undefined4 uVar4;
  double *pdVar5;
  int iVar6;
  int *piVar7;
  int iVar8;
  int *piVar9;
  undefined4 *puVar10;
  undefined4 *puStack_4c;
  int *piStack_48;
  int iStack_44;
  int iStack_40;
  undefined4 *puStack_3c;
  int *piStack_38;
  undefined4 *puStack_34;
  int *piStack_30;
  undefined auStack_2c [4];
  int *piStack_28;
  int iStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa618;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uVar4 = FUN_0060dcd0(auStack_2c,param_2);
  uStack_8 = 0;
  FUN_0061c150(uVar4);
  uStack_8 = 0xffffffff;
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_28[1] + -1;
    piStack_28[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      iVar8 = piStack_28[2] + -1;
      piStack_28[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  iStack_24 = piVar2[6];
  piStack_28 = (int *)piVar2[7];
  if (DAT_01d5ba9c == '\0') {
    param_2 = *(int **)(param_1 + 0x54);
    FUN_006ec080(&param_2);
    if (piVar2[5] != 0) {
      FUN_00631de0(piVar2 + 5);
    }
  }
  pdVar5 = (double *)FUN_016827a0(&puStack_4c);
  if (*(double *)(param_1 + 0x3c98) <= *pdVar5 - *(double *)(param_1 + 0x3c90)) {
    *(undefined4 *)(param_1 + 0x3ca0) = *(undefined4 *)(param_1 + 0x3ca4);
    *(undefined4 *)(param_1 + 0x3ca4) = 0;
    FUN_016827a0(&uStack_20);
    *(undefined4 *)(param_1 + 0x3c90) = uStack_20;
    *(int *)(param_1 + 0x3c94) = iStack_1c;
  }
  *(int *)(param_1 + 0x3ca4) = *(int *)(param_1 + 0x3ca4) + 1;
  iVar8 = piVar2[3];
  iVar6 = FUN_00aff8c0();
  if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
      (uint)*(ushort *)(iVar6 + 0x1da)) {
    FUN_00b0dbd0();
    iStack_1c = piVar2[0x2a];
    iStack_18 = 0;
    if (0 < *(int *)(iStack_1c + 0x1d4) - *(int *)(iStack_1c + 0x1d0) >> 3) {
      do {
        piVar7 = (int *)FUN_00c156d0(iStack_18);
        iVar8 = (**(code **)(*piVar7 + 0x10))();
        if ((iVar8 - 1U < 0xb) && (iVar8 != 4)) {
          iVar8 = FUN_00ca12e0();
          if (iVar8 == 0) {
            param_2 = (int *)0x0;
          }
          else {
            param_2 = (int *)(iVar8 + -0x70);
          }
          if ((piVar2 != (int *)param_2[0xd]) &&
             (((int *)param_2[0xd] == (int *)0x0 || (cVar3 = FUN_00620ec0(piVar2), cVar3 == '\0'))))
          {
            piVar7 = (int *)FUN_00c3c010();
            if (piVar7 == piVar2) {
              piVar7 = &DAT_02134d38;
            }
            else {
              piVar7 = (int *)FUN_00c3c020();
              if (piVar7 != piVar2) goto LAB_006f4756;
              piVar7 = &DAT_02134d74;
            }
            piVar9 = *(int **)(param_1 + 0x98);
            puStack_34 = (undefined4 *)(param_1 + 0x98);
            *puStack_34 = param_2;
            uStack_8 = 1;
            piStack_30 = piVar9;
LAB_006f4742:
            (**(code **)(*piVar7 + 0x48))(param_2,0);
            *(int **)(param_1 + 0x98) = piVar9;
            uStack_8 = 0xffffffff;
            param_1 = iStack_14;
          }
        }
        else {
          iVar8 = (**(code **)(*piVar7 + 0x10))();
          if (iVar8 - 0xcU < 0xe) {
            iVar8 = FUN_00ca12e0();
            if (iVar8 == 0) {
              param_2 = (int *)0x0;
            }
            else {
              param_2 = (int *)(iVar8 + -0x54);
            }
            if ((piVar2 != (int *)param_2[0xd]) &&
               (((int *)param_2[0xd] == (int *)0x0 || (cVar3 = FUN_00620ec0(piVar2), cVar3 == '\0'))
               )) {
              iVar8 = FUN_00ca5a50();
              if ((iVar8 == 0) || (*(int **)(iVar8 + 0x34) != piVar2)) {
                iVar8 = FUN_00ca5ab0();
                if ((iVar8 == 0) || (*(int **)(iVar8 + 0x34) != piVar2)) goto LAB_006f4756;
                piVar7 = (int *)&DAT_0213aaac;
              }
              else {
                piVar7 = (int *)&DAT_0213aa70;
              }
              piVar9 = *(int **)(param_1 + 0x98);
              puStack_3c = (undefined4 *)(param_1 + 0x98);
              *puStack_3c = param_2;
              uStack_8 = 2;
              piStack_38 = piVar9;
              goto LAB_006f4742;
            }
          }
          else {
            iVar8 = (**(code **)(*piVar7 + 0x10))();
            if (iVar8 == 4) {
              iVar8 = FUN_00ca12e0();
              if (iVar8 == 0) {
                param_2 = (int *)0x0;
              }
              else {
                param_2 = (int *)(iVar8 + -0x54);
              }
              if ((piVar2 != (int *)param_2[0xd]) &&
                 (((int *)param_2[0xd] == (int *)0x0 ||
                  (cVar3 = FUN_00620ec0(piVar2), cVar3 == '\0')))) {
                piVar7 = (int *)FUN_00b4c020();
                if (piVar7 == piVar2) {
                  piVar7 = (int *)&DAT_0212c024;
                }
                else {
                  piVar7 = (int *)FUN_00b4c070();
                  if (piVar7 != piVar2) goto LAB_006f4756;
                  piVar7 = (int *)&DAT_0212c060;
                }
                piVar9 = *(int **)(param_1 + 0x98);
                puStack_4c = (undefined4 *)(param_1 + 0x98);
                *puStack_4c = param_2;
                uStack_8 = 3;
                piStack_48 = piVar9;
                goto LAB_006f4742;
              }
            }
          }
        }
LAB_006f4756:
        iStack_18 = iStack_18 + 1;
      } while (iStack_18 < *(int *)(iStack_1c + 0x1d4) - *(int *)(iStack_1c + 0x1d0) >> 3);
    }
    if ((char)param_3 == '\0') {
      ExceptionList = pvStack_10;
      return;
    }
    iVar8 = *(int *)(param_1 + 0x34);
    iVar6 = iStack_14;
    if ((iVar8 != 0) && (iVar6 = iVar8, *(int *)(iVar8 + 0x34) != 0)) {
      iVar6 = FUN_005c8ac0();
    }
    param_1 = iStack_14;
    if ((iVar6 != 0) &&
       (iVar8 = *(int *)(iVar6 + 0xc), iVar6 = FUN_008a8c30(), param_1 = iStack_14,
       (uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
       (uint)*(ushort *)(iVar6 + 0x1da))) {
      FUN_005789c0(&DAT_01eadd54,&LAB_00670c30);
      uVar4 = FUN_00675a30();
      piVar7 = (int *)FUN_008aa140(uVar4);
      param_3 = piVar7;
      if (*piVar7 == 0) {
        uVar4 = FUN_00be8560();
        piVar9 = (int *)FUN_008a9ba0(&puStack_4c,uVar4);
        piVar7 = param_3;
        iVar8 = *piVar9;
        iVar6 = piVar9[1];
        *piVar9 = 0;
        piVar9[1] = 0;
        *param_3 = iVar8;
        piVar9 = (int *)param_3[1];
        param_3[1] = iVar6;
        if (piVar9 != (int *)0x0) {
          LOCK();
          iVar8 = piVar9[1] + -1;
          piVar9[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piVar9)();
            LOCK();
            iVar8 = piVar9[2] + -1;
            piVar9[2] = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)(*piVar9 + 4))();
            }
          }
        }
        piVar9 = piStack_48;
        if (piStack_48 != (int *)0x0) {
          LOCK();
          iVar8 = piStack_48[1] + -1;
          piStack_48[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piStack_48)();
            LOCK();
            piVar1 = piVar9 + 2;
            iVar8 = *piVar1 + -1;
            *piVar1 = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)(*piVar9 + 4))();
            }
          }
        }
      }
      param_1 = iStack_14;
      if (*piVar7 != 0) {
        iStack_40 = iStack_24;
        puStack_3c = piStack_28;
        iStack_44 = iStack_14;
        piStack_38 = piVar2;
        FUN_006ebf30(&iStack_44);
      }
    }
  }
  uVar4 = *(undefined4 *)(param_1 + 0x98);
  puVar10 = (undefined4 *)(param_1 + 0x98);
  *puVar10 = piVar2;
  uStack_8 = 4;
  puStack_4c = puVar10;
  piStack_48 = (int *)uVar4;
  FUN_008a65e0(0,0);
  *puVar10 = uVar4;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9655 ; VA 0x006f48e0 ; FUN_006f48e0 */

void __thiscall FUN_006f48e0(int param_1,int *param_2)

{
  undefined *puVar1;
  double *pdVar2;
  undefined8 uStack_40;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  undefined *puStack_28;
  undefined uStack_24;
  int iStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aa638;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x1a18) != 0) {
    uStack_24 = *(undefined *)(param_1 + 0x1db1);
    puVar1 = (undefined *)(param_1 + 0x1db1);
    ExceptionList = &pvStack_10;
    *puVar1 = 1;
    uStack_8 = 0;
    iStack_20 = *param_2 * 0x10;
    iStack_1c = param_2[1] * 0x10;
    iStack_38 = param_2[2] * 0x10;
    iStack_34 = iStack_20 + 0x10;
    iStack_30 = iStack_1c + 0x10;
    iStack_2c = iStack_38 + 0x10;
    uStack_40 = CONCAT44(iStack_1c,iStack_20);
    puStack_28 = puVar1;
    uStack_11 = uStack_24;
    FUN_00a70110(&uStack_40,3);
    pdVar2 = (double *)FUN_016827a0(&iStack_1c);
    if (*(double *)(param_1 + 0x3c80) <= *pdVar2 - *(double *)(param_1 + 0x3c78)) {
      *(undefined4 *)(param_1 + 0x3c88) = *(undefined4 *)(param_1 + 0x3c8c);
      *(undefined4 *)(param_1 + 0x3c8c) = 0;
      FUN_016827a0(&iStack_1c);
      *(int *)(param_1 + 0x3c78) = iStack_1c;
      *(undefined4 *)(param_1 + 0x3c7c) = uStack_18;
    }
    *(int *)(param_1 + 0x3c8c) = *(int *)(param_1 + 0x3c8c) + 1;
    if (puVar1 != (undefined *)0x0) {
      *puVar1 = uStack_11;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9656 ; VA 0x006f4a00 ; FUN_006f4a00 */

void __thiscall FUN_006f4a00(int param_1,undefined8 param_2)

{
  if ((*(uint *)(param_1 + 0x3808) & 2) != 0) {
    *(undefined4 *)(param_1 + 0x3b00) = (undefined4)param_2;
    *(undefined4 *)(param_1 + 0x3b04) = param_2._4_4_;
    *(undefined4 *)(param_1 + 0x3b48) = (undefined4)param_2;
    *(undefined4 *)(param_1 + 0x3b4c) = param_2._4_4_;
    return;
  }
  *(undefined8 *)(param_1 + 0x3b00) = param_2;
  return;
}



/* FUNCTION 9657 ; VA 0x006f4a50 ; FUN_006f4a50 */

void __fastcall FUN_006f4a50(int param_1)

{
  int iVar1;
  short sVar2;
  int *piVar3;
  undefined auStack_24 [8];
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa658;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00701a80();
  if ((((*(int *)(param_1 + 0x1f8) != 0) && (*(int *)(param_1 + 0x1f0) != 0)) &&
      (*(int *)(param_1 + 0x200) != 0)) &&
     ((*(int *)(param_1 + 0x208) != 0 && (*(int *)(param_1 + 0x210) != 0)))) {
    piVar3 = (int *)FUN_00587490(auStack_24);
    iStack_18 = piVar3[1];
    iVar1 = *piVar3;
    if (iStack_18 != 0) {
      LOCK();
      *(int *)(iStack_18 + 4) = *(int *)(iStack_18 + 4) + 1;
      UNLOCK();
      iStack_18 = piVar3[1];
    }
    uStack_8 = 0;
    iStack_1c = iVar1;
    FUN_00550b30();
    if (iVar1 != 0) {
      iStack_14 = *(int *)(iVar1 + 0x3cc8) - *(int *)(iVar1 + 0x3ccc);
      FUN_009fdde0(&iStack_14);
      iStack_14 = *(int *)(iVar1 + 0x3b10);
      FUN_009fde10(&iStack_14);
      if (*(int *)(iVar1 + 0x3b94) == 0) {
        iStack_14 = 0;
      }
      else {
        iStack_14 = *(int *)(*(int *)(iVar1 + 0x3b94) + 0x1b8);
      }
      FUN_009fdde0(&iStack_14);
      if (*(int *)(iVar1 + 0x3b94) == 0) {
        sVar2 = 0;
      }
      else {
        sVar2 = *(short *)(*(int *)(iVar1 + 0x3b94) + 0x1d4);
      }
      iStack_14 = (int)sVar2;
      FUN_009fdde0(&iStack_14);
      if (*(int *)(iVar1 + 0x3b94) == 0) {
        iStack_14 = 0;
      }
      else {
        iStack_14 = FUN_0070ddc0();
      }
      FUN_009fdde0(&iStack_14);
    }
    FUN_00550b30();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9658 ; VA 0x006f4bc0 ; FUN_006f4bc0 */

void __fastcall FUN_006f4bc0(int param_1)

{
  double dVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  double dVar4;
  bool bVar5;
  bool bVar6;
  char cVar7;
  undefined2 uVar8;
  short sVar9;
  double *pdVar10;
  int iVar11;
  int iVar12;
  undefined4 uVar13;
  undefined4 *puVar14;
  int iVar15;
  float10 fVar16;
  float fVar17;
  double dVar18;
  float fVar19;
  int iVar20;
  double dVar21;
  float fStack_2c;
  float fStack_24;
  float fStack_1c;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa67f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  fVar16 = (float10)FUN_01683110();
  if ((double)fVar16 - *(double *)(param_1 + 0x3cb0) <= DAT_018e1348) {
    ExceptionList = pvStack_10;
    return;
  }
  iVar12 = *(int *)(param_1 + 0x3b94);
  *(double *)(param_1 + 0x3cb0) = (double)fVar16;
  if (DAT_01d5ba7c == '\0') {
    if (*(int *)(iVar12 + 0x1b8) < 1) {
      cVar7 = *(char *)(iVar12 + 0x1fc);
      goto LAB_006f4c37;
    }
LAB_006f4c4f:
    bVar6 = false;
    if (*(char *)(param_1 + 0x3cd0) == '\0') {
      if (DAT_01eaf35c != '\0') {
        FUN_015228f0();
        FUN_015228f0();
        FUN_01677490();
      }
      *(undefined *)(param_1 + 0x3cd0) = 1;
      bVar6 = true;
    }
    bVar5 = false;
  }
  else {
    cVar7 = *(char *)(iVar12 + 0x1fc);
LAB_006f4c37:
    if ((cVar7 != '\0') || (*(int *)(param_1 + 0x3c70) < 5)) goto LAB_006f4c4f;
    *(undefined *)(param_1 + 0x3cd0) = 0;
    bVar5 = true;
    bVar6 = false;
  }
  iVar12 = *(int *)(param_1 + 0x3cb8);
  fStack_1c = 0.0;
  if ((bVar5) || (!bVar6)) {
    if (*(char *)(param_1 + 0x3be8) == '\0') {
      fStack_2c = 0.0;
      fVar17 = (float)(*(double *)(param_1 + 0x3bd8) / *(double *)(param_1 + 0x3bb0));
      if (*(char *)(param_1 + 0x3c28) == '\0') {
        fStack_2c = (float)*(double *)(param_1 + 0x3c18);
      }
      pdVar10 = (double *)FUN_016827a0();
      if ((*(double *)(param_1 + 0x1f48) < *pdVar10 - *(double *)(param_1 + 8000)) ||
         (*(int *)(param_1 + 0x1f50) < 1)) {
        fStack_14 = 0.0;
      }
      else {
        pdVar10 = (double *)FUN_016827a0();
        if (*(double *)(param_1 + 0x3bf8) < *pdVar10 - *(double *)(param_1 + 0x3bf0)) {
          iVar15 = 0;
        }
        else {
          iVar15 = *(int *)(param_1 + 0x3c00);
        }
        pdVar10 = (double *)FUN_016827a0();
        if (*(double *)(param_1 + 0x1f48) < *pdVar10 - *(double *)(param_1 + 8000)) {
          iVar11 = 0;
        }
        else {
          iVar11 = *(int *)(param_1 + 0x1f50);
        }
        fStack_14 = (float)iVar15 / (float)iVar11;
      }
      dVar1 = *(double *)(param_1 + 0x3bb0);
      iVar15 = FUN_00620890();
      fStack_1c = (float)(((double)iVar15 + (double)(&DAT_018c0d90)[-(iVar15 >> 0x1f)]) * dVar1 *
                         (double)fStack_14) * fVar17;
      pdVar10 = (double *)FUN_016827a0();
      if ((*(double *)(param_1 + 0x1f48) < *pdVar10 - *(double *)(param_1 + 8000)) ||
         (*(int *)(param_1 + 0x1f50) < 1)) {
        fStack_24 = 0.0;
      }
      else {
        pdVar10 = (double *)FUN_016827a0();
        if (*(double *)(param_1 + 0x3c38) < *pdVar10 - *(double *)(param_1 + 0x3c30)) {
          iVar15 = 0;
        }
        else {
          iVar15 = *(int *)(param_1 + 0x3c40);
        }
        pdVar10 = (double *)FUN_016827a0();
        if (*(double *)(param_1 + 0x1f48) < *pdVar10 - *(double *)(param_1 + 8000)) {
          iVar11 = 0;
        }
        else {
          iVar11 = *(int *)(param_1 + 0x1f50);
        }
        fStack_24 = (float)iVar15 / (float)iVar11;
      }
      iVar11 = FUN_00620890();
      iVar15 = DAT_01d5b9d8;
      if ((((fStack_24 <= 0.0) && (fStack_14 <= 0.0)) || (NAN(fVar17) != (fVar17 == 0.0))) ||
         (NAN(fStack_2c) != (fStack_2c == 0.0))) {
        *(int *)(param_1 + 0x3cb8) = DAT_01d5b9d8;
      }
      else {
        fVar19 = (DAT_018e1340 - fStack_1c) -
                 (float)((double)iVar11 + (double)(&DAT_018c0d90)[-(iVar11 >> 0x1f)]) * fStack_24 *
                 fStack_2c;
        iVar15 = (int)((fVar19 * fStack_24) / fStack_2c + (fVar19 * fStack_14) / fVar17);
        *(int *)(param_1 + 0x3cb8) = iVar15;
      }
      if (iVar15 < 1) {
        *(undefined4 *)(param_1 + 0x3cb8) = 1;
      }
      else if (DAT_01d5b9d0 < iVar15) {
        *(int *)(param_1 + 0x3cb8) = DAT_01d5b9d0;
      }
    }
    else {
      *(int *)(param_1 + 0x3cb8) = DAT_01d5b9d8;
    }
    if (bVar5) goto LAB_006f5056;
    pdVar10 = (double *)FUN_016827a0();
    if (*(double *)(param_1 + 0x3c98) < *pdVar10 - *(double *)(param_1 + 0x3c90)) {
      iVar15 = 0;
    }
    else {
      iVar15 = *(int *)(param_1 + 0x3ca0);
    }
    pdVar10 = (double *)FUN_016827a0();
    if (*(double *)(param_1 + 0x3c80) < *pdVar10 - *(double *)(param_1 + 0x3c78)) {
      iVar11 = 0;
    }
    else {
      iVar11 = *(int *)(param_1 + 0x3c88);
    }
    iVar20 = DAT_01d5ba0c;
    if (((*(int *)(*(int *)(param_1 + 0x3b94) + 0x1b8) < 1) &&
        (*(char *)(*(int *)(param_1 + 0x3b94) + 0x1fc) == '\0')) && (2 < *(int *)(param_1 + 0x3c70))
       ) {
      iVar20 = DAT_01d5ba14;
    }
    if ((0.0 < (float)iVar20 / DAT_018ce320) && (DAT_01d5ba04 < iVar11 + iVar15)) {
      iVar15 = (int)((float)(iVar11 + iVar15) * ((float)iVar20 / DAT_018ce320));
      if (*(int *)(param_1 + 0x3cb8) <= iVar15) {
        iVar15 = *(int *)(param_1 + 0x3cb8);
      }
      *(int *)(param_1 + 0x3cb8) = iVar15;
      goto LAB_006f5056;
    }
  }
  *(undefined4 *)(param_1 + 0x3cb8) = 0;
LAB_006f5056:
  cVar7 = FUN_00712320();
  iVar12 = *(int *)(param_1 + 0x3cb8) - iVar12;
  if ((iVar12 != 0) || (cVar7 != '\0')) {
    if (*(char *)(*(int *)(param_1 + 0x1f70) + 0x59) != '\0') {
      uVar2 = *(undefined8 *)(param_1 + 0x3bb0);
      uVar3 = *(undefined8 *)(param_1 + 0x3bd8);
      uVar13 = FUN_00620890();
      FUN_0086f2f0(1,
                   "clientInstanceQuota %d, packet in queue %d, predictedTotalInstanceProcessTime %f, avgStreamDataReadTime %f, avgInstancesPerStreamData %f"
                   ,*(undefined4 *)(param_1 + 0x3cb8),uVar13,(double)fStack_1c,uVar3,uVar2);
    }
    puVar14 = (undefined4 *)FUN_01674e20();
    uStack_8 = 0;
    if (puVar14 != (undefined4 *)0x0) {
      uVar8 = FUN_0070dd40();
      FUN_006b1a30();
      *puVar14 = RBX::Network::ClientReplicator::ClientCapacityUpdateItem::vftable;
      puVar14[0xc] = iVar12;
      *(undefined2 *)(puVar14 + 0xd) = uVar8;
    }
    uStack_8 = 0xffffffff;
    FUN_006b1f50();
  }
  iVar12 = *(int *)(param_1 + 0x3cb8);
  *(undefined4 *)(param_1 + 0x3ccc) = 0;
  dVar18 = (double)iVar12;
  sVar9 = FUN_017265ed();
  dVar1 = DAT_018c0d60;
  if (sVar9 < 1) {
    dVar4 = *(double *)(param_1 + 0x3c48);
    dVar21 = dVar18;
    if (*(char *)(param_1 + 0x3c68) == '\0') {
      dVar21 = (DAT_018c0d60 - dVar4) * *(double *)(param_1 + 0x3c58) + dVar18 * dVar4;
    }
    *(double *)(param_1 + 0x3c58) = dVar21;
    *(int *)(param_1 + 0x3c50) = iVar12;
    *(undefined *)(param_1 + 0x3c68) = 0;
    *(double *)(param_1 + 0x3c60) =
         (dVar18 - dVar21) * (dVar18 - dVar21) * dVar4 +
         (dVar1 - dVar4) * *(double *)(param_1 + 0x3c60);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9659 ; VA 0x006f5200 ; FUN_006f5200 */

/* WARNING: Removing unreachable block (ram,0x006f52fa) */
/* WARNING: Removing unreachable block (ram,0x006f530d) */
/* WARNING: Removing unreachable block (ram,0x006f5314) */
/* WARNING: Removing unreachable block (ram,0x006f531b) */

void __fastcall FUN_006f5200(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined8 uVar7;
  int *piStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa6b4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaf3f8) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eaf3f8), DAT_01eaf3f8 == -1)) {
    uStack_8 = 0;
    uVar7 = FUN_0152dab0(&DAT_018c5904,"updateMemoryStats",0xffffffff);
    DAT_01eaf3f4 = (undefined4)((ulonglong)uVar7 >> 0x20);
    DAT_01eaf3f0 = (undefined4)uVar7;
    uStack_8 = 0xffffffff;
    FUN_016f37bf();
  }
  uVar4 = DAT_01eaf3f4;
  uVar3 = DAT_01eaf3f0;
  uVar7 = FUN_0152d930(DAT_01eaf3f0,DAT_01eaf3f4);
  uStack_8 = 1;
  if (DAT_01ea94c4 == 0) {
    puVar5 = (undefined4 *)FUN_00910d90();
    uVar6 = *puVar5;
    FUN_00587410();
    uStack_8._0_1_ = 2;
    if (DAT_01ea94c4 == 0) {
      FUN_005eeb00();
      uStack_8._0_1_ = 3;
      FUN_008a65e0(uVar6,0);
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_24[1] + -1;
        piStack_24[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          piVar1 = piStack_24 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piStack_24 + 4))();
          }
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
  }
  uVar6 = FUN_01533fb0((longlong)*(int *)(DAT_01ea94c4 + 0xc4) << 0x14);
  *(undefined4 *)(param_1 + 0x3c70) = uVar6;
  uStack_8 = 5;
  FUN_0152dda0(uVar3,uVar4,uVar7);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9660 ; VA 0x006f53d0 ; FUN_006f53d0 */

char __thiscall FUN_006f53d0(int *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  
  iVar5 = param_1[0x685];
  cVar4 = FUN_00632220(param_2);
  if (iVar5 != 0) {
    if (cVar4 != '\0') {
      iVar5 = (**(code **)(*param_1 + 0xb4))();
      if (iVar5 == 0) {
        return '\x01';
      }
      puVar1 = *(undefined4 **)(iVar5 + 0x2c);
      if (puVar1 != (undefined4 *)0x0) {
        piVar2 = (int *)puVar1[1];
        for (piVar7 = (int *)*puVar1; piVar7 != piVar2; piVar7 = piVar7 + 2) {
          iVar5 = *piVar7;
          if ((iVar5 != 0) &&
             (iVar3 = *(int *)(iVar5 + 0xc), iVar6 = FUN_00b56e90(),
             (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
             (uint)*(ushort *)(iVar6 + 0x1da))) {
            if (iVar5 == 0) {
              return '\x01';
            }
            cVar4 = FUN_00620ec0(iVar5);
            if (cVar4 == '\0') {
              return '\x01';
            }
            return '\0';
          }
        }
      }
      return '\x01';
    }
    cVar4 = '\0';
  }
  return cVar4;
}



/* FUNCTION 9661 ; VA 0x006f5490 ; FUN_006f5490 */

undefined4 __thiscall FUN_006f5490(uint param_1,undefined4 param_2)

{
  undefined4 uVar1;
  uint uStack_8;
  
  uVar1 = param_2;
  uStack_8 = param_1;
  FUN_006b2070(param_2,10);
  FUN_006b9320(uVar1,*(undefined4 *)(param_1 + 0x34));
  uStack_8 = (uint)*(ushort *)(param_1 + 0x3c);
  FUN_006a5c10(&uStack_8,&param_2,2);
  FUN_006ad5e0(&param_2,2);
  (**(code **)(**(int **)(param_1 + 0x30) + 0x134))
            (uVar1,*(undefined4 *)(param_1 + 0x34),*(undefined2 *)(param_1 + 0x3c),0);
  return 1;
}



/* FUNCTION 9662 ; VA 0x006f5500 ; FUN_006f5500 */

undefined4 __thiscall FUN_006f5500(uint param_1,undefined4 param_2)

{
  uint uStack_8;
  
  uStack_8 = param_1;
  FUN_006b2070(param_2,0xc);
  param_2 = *(undefined4 *)(param_1 + 0x30);
  FUN_006a5c10(&param_2,&uStack_8,4);
  FUN_006ad5e0(&uStack_8,4);
  uStack_8 = (uint)*(ushort *)(param_1 + 0x34);
  FUN_006a5c10(&uStack_8,&param_2,2);
  FUN_006ad5e0(&param_2,2);
  return 1;
}



/* FUNCTION 9663 ; VA 0x006f5570 ; FUN_006f5570 */

undefined4 __thiscall FUN_006f5570(int param_1,uint param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_14 [12];
  undefined auStack_8 [4];
  
  iVar2 = (**(code **)(**(int **)(param_1 + 0x10) + 0xb4))();
  uVar1 = param_2;
  if (iVar2 != 0) {
    FUN_006b2070(param_2,8);
    FUN_008f7870(*(undefined4 *)(param_1 + 0x10));
    param_2 = FUN_008ee4a0();
    param_2 = param_2 | DAT_01ee04b4;
    FUN_006a5c10(&param_2,auStack_8,4);
    FUN_006ad5e0(auStack_8,4);
    uVar3 = FUN_00acb320();
    FUN_006ae570(uVar3);
    FUN_006b9320(uVar1,iVar2);
    return 1;
  }
  FUN_00550130("Attempting to send a Character request without a local Player");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_14,&DAT_01c17198);
}



/* FUNCTION 9664 ; VA 0x006f5620 ; FUN_006f5620 */

void __thiscall FUN_006f5620(int *param_1,undefined4 param_2,int param_3,uint param_4)

{
  char cVar1;
  undefined4 uVar2;
  uint uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_38;
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4948;
  pvStack_10 = ExceptionList;
  if ((param_1[0xe02] & 2U) != 0) {
    ExceptionList = &pvStack_10;
    cVar1 = (**(code **)(*param_1 + 0x11c))();
    if (cVar1 != '\0') {
      uVar2 = 0;
      FUN_0054ef60(param_4);
      uStack_50 = uStack_30;
      uStack_4c = uStack_2c;
      uStack_48 = uStack_28;
      uStack_44 = uStack_24;
      if (param_3 == 0) {
        uStack_18 = 0xffffffff;
        uStack_14 = 0;
      }
      else {
        uStack_18 = *(undefined4 *)(param_3 + 0x18);
        uStack_14 = *(undefined4 *)(param_3 + 0x1c);
      }
      uStack_20 = 0;
      uStack_38 = uStack_18;
      uStack_34 = uStack_14;
      uStack_1c = 0xf;
      uStack_30 = uStack_30 & 0xffffff00;
      uStack_8 = 0;
      FUN_006ef8e0(&param_4,&uStack_50);
      if (param_4 == 0) {
        param_4 = 0;
      }
      else if (*(char *)(param_4 + 0x38) == '\0') {
        *(undefined *)(param_4 + 0x38) = 1;
        uVar2 = *(undefined4 *)(param_4 + 0x28);
        param_4 = CONCAT13(1,(undefined3)param_4);
      }
      else {
        param_4 = param_4 & 0xffffff;
      }
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      param_3 = CONCAT31(param_3._1_3_,param_4._3_1_);
      FUN_006ad5e0(&param_3,1);
      if (param_4._3_1_ != '\0') {
        FUN_006ad340(uVar2,param_2);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9665 ; VA 0x006f5750 ; FUN_006f5750 */

void __thiscall FUN_006f5750(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aa6c0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::DeserializedChangePropertyItem>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9666 ; VA 0x006f57be ; Catch_All@006f57be */

void Catch_All_006f57be(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9667 ; VA 0x006f57e0 ; FUN_006f57e0 */

undefined4 * __thiscall
FUN_006f57e0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 *param_5)

{
  int *piVar1;
  
  FUN_006b1a30(param_2);
  param_1[0xc] = param_3;
  *param_1 = RBX::Network::Replicator::ChangePropertyItem::vftable;
  param_1[0xd] = param_4;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  if (param_5[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0xe] = *param_5;
  param_1[0xf] = param_5[1];
  return param_1;
}



/* FUNCTION 9668 ; VA 0x006f5840 ; FUN_006f5840 */

undefined4 * __thiscall
FUN_006f5840(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 *param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  
  FUN_006b1a80(param_2,param_6,param_7);
  param_1[0xc] = param_3;
  *param_1 = RBX::Network::Replicator::ChangePropertyItem::vftable;
  param_1[0xd] = param_4;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  if (param_5[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0xe] = *param_5;
  param_1[0xf] = param_5[1];
  return param_1;
}



/* FUNCTION 9669 ; VA 0x006f58a0 ; FUN_006f58a0 */

int __fastcall FUN_006f58a0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int in_EAX;
  int iVar4;
  
  piVar3 = (int *)param_1[0xf];
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
    *param_1 = RBX::Network::Item::vftable;
    return iVar4;
  }
  *param_1 = RBX::Network::Item::vftable;
  return in_EAX;
}



/* FUNCTION 9670 ; VA 0x006f58e0 ; FUN_006f58e0 */

undefined4 * __thiscall FUN_006f58e0(undefined4 *param_1,uint param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = (int *)param_1[0xf];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *param_1 = RBX::Network::Item::vftable;
  if ((param_2 & 1) != 0) {
    if ((param_2 & 4) == 0) {
      piVar2 = *(int **)param_1[-1];
      param_1[-1] = *piVar2;
      *piVar2 = (int)(param_1 + -1);
      return param_1;
    }
    _guard_check_icall(param_1,0x40);
  }
  return param_1;
}



/* FUNCTION 9671 ; VA 0x006f5950 ; FUN_006f5950 */

undefined4 * __thiscall FUN_006f5950(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Network::DeserializedChangePropertyItem::vftable;
  uStack_8 = 0;
  if (param_1[0xb] != 0) {
    (**(code **)(param_1[0xb] + 8))(param_1 + 0xc);
  }
  piVar2 = (int *)param_1[7];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *param_1 = RBX::Network::DeserializedItem::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x108);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9672 ; VA 0x006f59f0 ; FUN_006f59f0 */

undefined4 FUN_006f59f0(void)

{
  return 3;
}



/* FUNCTION 9673 ; VA 0x006f5a00 ; FUN_006f5a00 */

undefined __fastcall FUN_006f5a00(undefined4 param_1)

{
  FUN_00626bf0(param_1);
  return 1;
}



/* FUNCTION 9674 ; VA 0x006f5a20 ; FUN_006f5a20 */

int * FUN_006f5a20(int *param_1,int *param_2,undefined4 param_3)

{
  int *piVar1;
  undefined2 *puVar2;
  int iVar3;
  int *piVar4;
  char cVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  undefined **ppuVar8;
  int iVar9;
  undefined **ppuVar10;
  undefined auStack_98 [36];
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined auStack_64 [4];
  undefined *puStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined auStack_4c [12];
  undefined auStack_40 [4];
  undefined auStack_3c [4];
  undefined4 *puStack_38;
  undefined2 *puStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  undefined2 uStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa70d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar6 = (undefined4 *)FUN_01674e20(0x108);
  puStack_38 = puVar6;
  if (puVar6 == (undefined4 *)0x0) {
    puVar6 = (undefined4 *)0x0;
  }
  else {
    puVar6[1] = 3;
    puVar6[2] = 1;
    puVar6[3] = 0;
    *puVar6 = RBX::Network::DeserializedChangePropertyItem::vftable;
    puVar6[4] = 0xffffffff;
    puVar6[5] = 0;
    puVar6[6] = 0;
    puVar6[7] = 0;
    uStack_8 = 2;
    piStack_1c = puVar6 + 10;
    uVar7 = FUN_00888530();
    puVar6[10] = uVar7;
    puVar6[0xb] = 0;
    puVar6[0x3e] = 0xffffffff;
    puVar6[0x3f] = 0;
  }
  uStack_8 = 0xffffffff;
  iStack_18 = 0;
  piStack_14 = (int *)0x0;
  FUN_006f5750(puVar6,param_2);
  uStack_8 = 3;
  puVar6 = (undefined4 *)FUN_006b8fd0(auStack_3c,param_3);
  iVar9 = iStack_18;
  *(undefined4 *)(iStack_18 + 0x10) = *puVar6;
  *(undefined4 *)(iStack_18 + 0x14) = puVar6[1];
  piStack_1c = (int *)(iStack_18 + 0x18);
  FUN_00621ac0((undefined4 *)(iStack_18 + 0x10),piStack_1c);
  cVar5 = FUN_006abe60(iVar9 + 0x24,2);
  if (cVar5 == '\0') {
    FUN_0054eff0("readFast past end for uint16_t");
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_005f8ef0(auStack_4c);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_98,&DAT_01c27108);
  }
  *(ushort *)(iVar9 + 0x24) = *(ushort *)(iVar9 + 0x24) << 8 | *(ushort *)(iVar9 + 0x24) >> 8;
  (**(code **)(*param_2 + 0x138))(param_3,iVar9 + 0x100);
  iVar3 = *(int *)(param_2[0x67d] + 100);
  if (((uint)((*(int *)(param_2[0x67d] + 0x68) - iVar3) / 0x14) <= (uint)*(ushort *)(iVar9 + 0x24))
     || (puVar2 = (undefined2 *)(iVar3 + (uint)*(ushort *)(iVar9 + 0x24) * 0x14),
        puVar2 == (undefined2 *)0x0)) {
    iVar9 = FUN_00615990();
    FUN_016756b0(auStack_40,"Invalid property network id. Read offset=%X",iVar9 << 3);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_40,&DAT_01c17198);
  }
  if ((*piStack_1c != 0) && (*(int *)(puVar2 + 8) != 0)) {
    cVar5 = FUN_00893260(*(undefined4 *)(*piStack_1c + 0xc));
    if (cVar5 == '\0') {
      iVar9 = FUN_00615990();
      FUN_016756b0(auStack_40,
                   "Received property update for property not belonging to referenced class. Read offset=%X"
                   ,iVar9 << 3);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_40,&DAT_01c17198);
    }
  }
  puStack_38 = (undefined4 *)0xb;
  *(undefined4 *)(iStack_18 + 0x20) = *(undefined4 *)(puVar2 + 8);
  iStack_24 = iStack_18 + 0xf8;
  uStack_20 = *puVar2;
  iStack_30 = iStack_18 + 0x28;
  uStack_28 = *(undefined4 *)(iStack_18 + 0x18);
  uStack_2c = *(undefined4 *)(puVar2 + 8);
  auStack_64[0] = 0;
  puStack_34 = puVar2 + 2;
  ppuVar8 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_38);
  ppuVar10 = ppuVar8 + -1;
  if (ppuVar8 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar10 = ppuVar8;
  }
  puStack_60 = *ppuVar10;
  uStack_5c = 0;
  uStack_58 = 0x3f800000;
  uStack_54 = 0;
  uStack_50 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  uStack_74 = 0;
  uStack_70 = 0;
  uStack_6c = 0;
  uStack_68 = 0;
  FUN_00609060(param_3,puVar2 + 2,1,&puStack_34,0,auStack_64,&uStack_74);
  FUN_00627d20(param_3,auStack_64);
  iVar9 = iStack_18;
  if ((*piStack_1c != 0) && (*(int *)(puVar2 + 8) != 0)) {
    iStack_18 = 0;
    param_1[1] = (int)piStack_14;
    *param_1 = iVar9;
    piStack_14 = (int *)0x0;
    FUN_006bf690();
    FUN_00550b30();
    ExceptionList = pvStack_10;
    return param_1;
  }
  *param_1 = 0;
  param_1[1] = 0;
  FUN_006bf690();
  piVar4 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_14[1] + -1;
    piStack_14[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar9 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9675 ; VA 0x006f5dc0 ; FUN_006f5dc0 */

void __thiscall FUN_006f5dc0(int param_1,undefined4 param_2)

{
  FUN_006f5de0(*(undefined4 *)(param_1 + 0x10),param_2,*(undefined4 *)(param_1 + 0x30),
               *(undefined4 *)(param_1 + 0x34),param_1 + 0x38);
  return;
}



/* FUNCTION 9676 ; VA 0x006f5de0 ; FUN_006f5de0 */

undefined4 FUN_006f5de0(int *param_1,int *param_2,int param_3,ushort *param_4,int *param_5)

{
  int *piVar1;
  int *piVar2;
  ushort *puVar3;
  char cVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  int *piVar8;
  int iVar9;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  int iStack_34;
  ushort uStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa728;
  pvStack_10 = ExceptionList;
  iStack_1c = *param_5;
  iStack_20 = param_3;
  ExceptionList = &pvStack_10;
  if (param_1[0x78a] != 0) {
    ExceptionList = &pvStack_10;
    uStack_14 = FUN_008a2fa0(&iStack_20);
    param_1 = (int *)(uStack_14 % (uint)piVar2[0x789]);
    iStack_18 = (int)param_1 * 4;
    piVar8 = *(int **)(iStack_18 + piVar2[0x78d]);
    if (piVar8 != (int *)0x0) {
      for (piVar1 = (int *)*piVar8;
          (piVar1 != (int *)0x0 && ((int *)((uint)piVar1[1] % (uint)piVar2[0x789]) == param_1));
          piVar1 = (int *)*piVar1) {
        if ((piVar1[1] == uStack_14) && ((iStack_20 == piVar1[2] && (iStack_1c == piVar1[3])))) {
          piVar1 = (int *)*piVar1;
          piVar6 = (int *)*piVar8;
          do {
            *piVar8 = *piVar6;
            FUN_0061a630(piVar6,1);
            piVar2[0x78a] = piVar2[0x78a] + -1;
            piVar6 = (int *)*piVar8;
          } while (piVar6 != piVar1);
          if (piVar6 != (int *)0x0) {
            if (param_1 == (int *)((uint)piVar6[1] % (uint)piVar2[0x789])) break;
            *(int **)(piVar2[0x78d] + (int)((uint)piVar6[1] % (uint)piVar2[0x789]) * 4) = piVar8;
          }
          if (*(int **)(piVar2[0x78d] + iStack_18) == piVar8) {
            *(undefined4 *)(piVar2[0x78d] + iStack_18) = 0;
          }
          break;
        }
        piVar8 = piVar1;
      }
    }
  }
  cVar4 = FUN_00621090(*param_5);
  piVar8 = param_2;
  if (cVar4 != '\0') {
    uStack_14 = (**(code **)(*param_2 + 8))();
    uStack_30 = *param_4;
    iVar9 = *param_5;
    iStack_34 = param_3;
    iStack_38 = iVar9;
    FUN_006b20a0(piVar2,piVar8,3);
    iStack_18 = piVar8[6];
    FUN_006b9320(piVar8,iVar9);
    param_1 = (int *)(uint)*param_4;
    FUN_006a5c10(&param_1,&param_5,2);
    FUN_006ad5e0(&param_5,2);
    (**(code **)(*piVar2 + 0x134))(piVar8,iVar9,*param_4,*(undefined4 *)(param_4 + 8));
    puVar3 = param_4;
    iStack_2c = 0;
    iStack_28 = 0;
    iStack_24 = 0;
    uStack_8 = 0;
    uStack_48 = 0;
    uStack_44 = 0;
    uStack_40 = 0;
    uStack_3c = 0;
    FUN_0060b720(piVar8,param_4 + 2,1,&iStack_38,0,&iStack_2c,&uStack_48);
    FUN_00632400(piVar8,&iStack_2c);
    if (DAT_01d59fb8 != '\0') {
      FUN_006283d0(*(undefined4 *)(puVar3 + 8),piVar8[6] - iStack_18);
    }
    iVar5 = iStack_28;
    uStack_8 = 0xffffffff;
    iVar9 = iStack_2c;
    if (iStack_2c != 0) {
      for (; iVar9 != iVar5; iVar9 = iVar9 + 4) {
        FUN_00615780(0);
      }
      uVar7 = iStack_24 - iStack_2c & 0xfffffffc;
      iVar9 = iStack_2c;
      if (0xfff < uVar7) {
        iVar9 = *(int *)(iStack_2c + -4);
        uVar7 = uVar7 + 0x23;
        if (0x1f < (iStack_2c - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar9,uVar7);
      iStack_2c = 0;
      iStack_28 = 0;
      iStack_24 = 0;
      piVar8 = param_2;
    }
    iVar9 = param_3;
    if (*(char *)(piVar2[0x7dc] + 0x5b) != '\0') {
      FUN_006b8740(*(undefined4 *)(param_3 + 0x18));
      iVar5 = (**(code **)(*piVar8 + 8))();
      FUN_006b89d0(*(undefined4 *)(iVar9 + 0x18),iVar5 - uStack_14);
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 9677 ; VA 0x006f60c0 ; FUN_006f60c0 */

undefined4 * __thiscall
FUN_006f60c0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa748;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006b1a30(param_2);
  uStack_8 = 0;
  *param_1 = RBX::Network::Replicator::ChangeAttributeItem::vftable;
  FUN_0054ef60(param_3);
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  if (param_4[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x12] = *param_4;
  param_1[0x13] = param_4[1];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9678 ; VA 0x006f6140 ; FUN_006f6140 */

undefined4 __thiscall FUN_006f6140(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x11c);
  }
  return param_1;
}



/* FUNCTION 9679 ; VA 0x006f6170 ; FUN_006f6170 */

undefined4 * __thiscall FUN_006f6170(undefined4 *param_1,uint param_2)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = (int *)param_1[0x13];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = param_1[0x11];
  if (0xf < uVar3) {
    iVar4 = param_1[0xc];
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x10] = 0;
  param_1[0x11] = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  *param_1 = RBX::Network::Item::vftable;
  if ((param_2 & 1) != 0) {
    if ((param_2 & 4) == 0) {
      piVar2 = *(int **)param_1[-1];
      param_1[-1] = *piVar2;
      *piVar2 = (int)(param_1 + -1);
      return param_1;
    }
    _guard_check_icall(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 9680 ; VA 0x006f6230 ; FUN_006f6230 */

undefined4 * __thiscall FUN_006f6230(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Network::DeserializedChangeAttributeItem::vftable;
  uStack_8 = 0;
  if (param_1[0xf] != 0) {
    (**(code **)(param_1[0xf] + 8))(param_1 + 0x10);
  }
  uVar2 = param_1[0xd];
  if (0xf < uVar2) {
    iVar3 = param_1[8];
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0xc] = 0;
  param_1[0xd] = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  piVar4 = (int *)param_1[7];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  *param_1 = RBX::Network::DeserializedItem::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x110);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9681 ; VA 0x006f6310 ; FUN_006f6310 */

int __thiscall FUN_006f6310(int param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined4 *puVar9;
  uint uVar10;
  uint uVar11;
  
  if (*(int *)(param_1 + 8) != 0) {
    iVar5 = FUN_005702d0(param_2);
    uVar6 = iVar5 + 0x9e3779b9;
    uVar10 = *(uint *)(param_1 + 4);
    uVar6 = (uVar6 >> 2) +
            uVar6 * 0x40 + *(int *)(param_2 + 0x18) + (*(uint *)(param_2 + 0x18) >> 3) + 0x9e3779b9
            ^ uVar6;
    uVar11 = uVar6 % uVar10;
    puVar1 = *(undefined4 **)(uVar11 * 4 + *(int *)(param_1 + 0x14));
    if (puVar1 != (undefined4 *)0x0) {
      for (puVar9 = (undefined4 *)*puVar1;
          (puVar9 != (undefined4 *)0x0 && ((uint)puVar9[1] % uVar10 == uVar11));
          puVar9 = (undefined4 *)*puVar9) {
        if ((puVar9[1] == uVar6) &&
           ((cVar4 = FUN_00558b30(param_2,puVar9 + 2), cVar4 != '\0' &&
            (*(int *)(param_2 + 0x18) == puVar9[8])))) {
          puVar2 = (undefined4 *)*puVar9;
          iVar5 = 0;
          puVar7 = puVar2;
          while( true ) {
            *puVar1 = puVar7;
            uVar6 = puVar9[7];
            if (0xf < uVar6) {
              iVar3 = puVar9[2];
              uVar10 = uVar6 + 1;
              iVar8 = iVar3;
              if (0xfff < uVar10) {
                iVar8 = *(int *)(iVar3 + -4);
                uVar10 = uVar6 + 0x24;
                if (0x1f < (iVar3 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
                  FUN_017167a3();
                }
              }
              FUN_01674ea0(iVar8,uVar10);
            }
            puVar9[6] = 0;
            puVar9[7] = 0xf;
            *(undefined *)(puVar9 + 2) = 0;
            FUN_0061a520(puVar9,1);
            iVar5 = iVar5 + 1;
            *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
            puVar9 = (undefined4 *)*puVar1;
            if (puVar9 == puVar2) break;
            puVar7 = (undefined4 *)*puVar9;
          }
          if (puVar9 != (undefined4 *)0x0) {
            uVar6 = (uint)puVar9[1] % *(uint *)(param_1 + 4);
            if (uVar11 == uVar6) {
              return iVar5;
            }
            *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar6 * 4) = puVar1;
          }
          puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar11 * 4);
          if ((undefined4 *)*puVar9 == puVar1) {
            *puVar9 = 0;
          }
          return iVar5;
        }
        puVar1 = puVar9;
      }
    }
  }
  return 0;
}



/* FUNCTION 9682 ; VA 0x006f6480 ; FUN_006f6480 */

undefined4 __thiscall FUN_006f6480(undefined4 param_1,int *param_2)

{
  (**(code **)(*param_2 + 0x160))(param_1);
  return 1;
}



/* FUNCTION 9683 ; VA 0x006f64a0 ; FUN_006f64a0 */

int * FUN_006f64a0(int *param_1,int *param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined4 ****ppppuVar5;
  int *piVar6;
  undefined auStack_ec [36];
  uint *puStack_c8;
  uint *puStack_c4;
  uint *puStack_b8;
  uint *puStack_b4;
  uint *puStack_a8;
  int *piStack_a4;
  uint uStack_9c;
  uint uStack_98;
  int *piStack_3c;
  int *piStack_38;
  undefined4 ***apppuStack_34 [4];
  uint uStack_24;
  uint uStack_20;
  undefined auStack_1c [4];
  undefined4 ***pppuStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa7ab;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar1 = (int *)FUN_01674e20(0x11c);
  if (piVar1 == (int *)0x0) {
    piVar6 = (int *)0x0;
    pppuStack_18 = (undefined4 ***)piVar1;
  }
  else {
    piStack_14 = piVar1 + 3;
    piVar1[1] = 1;
    piVar1[2] = 1;
    *piVar1 = (int)std::_Ref_count_obj<class_RBX::Network::DeserializedChangeAttributeItem>::vftable
    ;
    piVar1[4] = 0x15;
    piVar1[5] = 1;
    piVar1[6] = 0;
    *piStack_14 = (int)RBX::Network::DeserializedChangeAttributeItem::vftable;
    piVar1[7] = -1;
    piVar1[8] = 0;
    piVar1[9] = 0;
    piVar1[10] = 0;
    piVar1[0xf] = 0;
    piVar1[0x10] = 0xf;
    *(undefined *)(piVar1 + 0xb) = 0;
    uStack_8 = 3;
    piStack_38 = piVar1 + 0x11;
    pppuStack_18 = (undefined4 ***)piVar1;
    iVar2 = FUN_00888530();
    piVar1[0x11] = iVar2;
    piVar1[0x12] = 0;
    piVar6 = piVar1;
  }
  piStack_3c = piVar6 + 3;
  uStack_8 = 4;
  piStack_38 = piVar6;
  piVar1 = (int *)FUN_006b8fd0(auStack_1c,param_3);
  piVar6[7] = *piVar1;
  piVar6[8] = piVar1[1];
  FUN_00621ac0(piVar6 + 7,piVar6 + 9);
  uStack_24 = 0;
  uStack_20 = 0xf;
  apppuStack_34[0] = (undefined4 ***)((uint)apppuStack_34[0] & 0xffffff00);
  uStack_8._0_1_ = 5;
  FUN_006ab8e0(piVar6 + 0xb,param_3);
  FUN_006ab8e0(apppuStack_34,param_3);
  FUN_00565940(3,1);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_00577980();
  pppuStack_18 = apppuStack_34;
  if (0xf < uStack_20) {
    pppuStack_18 = apppuStack_34[0];
  }
  piStack_14 = (int *)uStack_24;
  if (uStack_24 < 0x80000000) {
    if ((uStack_24 == 0) || (((byte)uStack_98 & 6) == 6)) {
      uStack_9c = 0;
    }
    else {
      uVar3 = FUN_00554060(uStack_24);
      FUN_0170c6f0(uVar3,pppuStack_18,piStack_14);
      pppuStack_18 = (undefined4 ***)(uStack_98 & 4);
      uStack_9c = (int)piStack_14 + uVar3;
      if ((undefined4 ****)pppuStack_18 == (undefined4 ****)0x0) {
        *puStack_c8 = uVar3;
        *puStack_b8 = uVar3;
        *puStack_a8 = (uint)piStack_14;
      }
      if ((uStack_98 & 2) == 0) {
        uVar4 = uVar3;
        if ((uStack_98 & 0x18) != 0) {
          uVar4 = uStack_9c;
        }
        *puStack_c4 = uVar3;
        *puStack_b4 = uVar4;
        *piStack_a4 = uStack_9c - uVar4;
        if ((undefined4 ****)pppuStack_18 != (undefined4 ****)0x0) {
          *puStack_c8 = uVar3;
          *puStack_b8 = 0;
          *puStack_a8 = uVar3;
        }
      }
      uStack_98 = uStack_98 | 1;
    }
    FUN_00cb1c50(auStack_ec,piVar6 + 0x11,0);
    if ((param_2[0xe02] & 2U) != 0) {
      (**(code **)(*param_2 + 0x140))(param_3,piVar6 + 0x45);
    }
    if (piVar6[9] == 0) {
      *param_1 = 0;
      param_1[1] = 0;
      FUN_005705c0();
      if (0xf < uStack_20) {
        uVar3 = uStack_20 + 1;
        ppppuVar5 = (undefined4 ****)apppuStack_34[0];
        if (0xfff < uVar3) {
          ppppuVar5 = (undefined4 ****)apppuStack_34[0][-1];
          uVar3 = uStack_20 + 0x24;
          if (0x1f < (uint)((int)apppuStack_34[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar5,uVar3);
      }
      uStack_24 = 0;
      uStack_20 = 0xf;
      apppuStack_34[0] = (undefined4 ***)((uint)apppuStack_34[0] & 0xffffff00);
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar2 = piVar6[1] + -1;
        piVar6[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          piVar1 = piVar6 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return param_1;
    }
    *param_1 = (int)(piVar6 + 3);
    param_1[1] = (int)piVar6;
    FUN_005705c0();
    if (0xf < uStack_20) {
      uVar3 = uStack_20 + 1;
      ppppuVar5 = (undefined4 ****)apppuStack_34[0];
      if (0xfff < uVar3) {
        ppppuVar5 = (undefined4 ****)apppuStack_34[0][-1];
        uVar3 = uStack_20 + 0x24;
        if (0x1f < (uint)((int)apppuStack_34[0] + (-4 - (int)ppppuVar5))) goto LAB_006f6803;
      }
      FUN_01674ea0(ppppuVar5,uVar3);
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_010c5e30();
LAB_006f6803:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 9684 ; VA 0x006f6810 ; FUN_006f6810 */

void __thiscall FUN_006f6810(int param_1,undefined4 *param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  code *pcVar4;
  int iVar5;
  int iVar6;
  
  FUN_00577980();
  uVar1 = *(uint *)(param_1 + 0x54);
  uVar2 = param_2[4];
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  if (uVar2 < 0x80000000) {
    if ((uVar2 != 0) && (((byte)uVar1 & 6) != 6)) {
      iVar5 = FUN_00554060(uVar2);
      FUN_0170c6f0(iVar5,param_2,uVar2);
      *(uint *)(param_1 + 0x50) = uVar2 + iVar5;
      if ((uVar1 & 4) == 0) {
        **(int **)(param_1 + 0x24) = iVar5;
        **(int **)(param_1 + 0x34) = iVar5;
        **(uint **)(param_1 + 0x44) = uVar2;
      }
      if ((uVar1 & 2) == 0) {
        iVar3 = *(int *)(param_1 + 0x50);
        iVar6 = iVar5;
        if ((uVar1 & 0x18) != 0) {
          iVar6 = iVar3;
        }
        **(int **)(param_1 + 0x28) = iVar5;
        **(int **)(param_1 + 0x38) = iVar6;
        **(int **)(param_1 + 0x48) = iVar3 - iVar6;
        if ((uVar1 & 4) != 0) {
          **(int **)(param_1 + 0x24) = iVar5;
          **(undefined4 **)(param_1 + 0x34) = 0;
          **(int **)(param_1 + 0x44) = iVar5;
        }
      }
      *(uint *)(param_1 + 0x54) = uVar1 | 1;
      return;
    }
    *(uint *)(param_1 + 0x54) = uVar1;
    *(undefined4 *)(param_1 + 0x50) = 0;
    return;
  }
  FUN_010c5e30();
  pcVar4 = (code *)swi(3);
  (*pcVar4)();
  return;
}



/* FUNCTION 9685 ; VA 0x006f6900 ; FUN_006f6900 */

void __thiscall FUN_006f6900(int param_1,undefined4 param_2)

{
  FUN_006f6920(*(undefined4 *)(param_1 + 0x10),param_2,param_1 + 0x30,param_1 + 0x48);
  return;
}



/* FUNCTION 9686 ; VA 0x006f6920 ; FUN_006f6920 */

undefined4 FUN_006f6920(int *param_1,int *param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  undefined4 in_stack_fffffdfc;
  undefined4 in_stack_fffffe00;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined auStack_1e0 [4];
  int iStack_1dc;
  undefined auStack_1d8 [216];
  undefined auStack_100 [20];
  int *piStack_ec;
  int *piStack_e8;
  int *piStack_dc;
  uint *puStack_d8;
  int *piStack_cc;
  uint uStack_c0;
  uint uStack_bc;
  int aiStack_48 [5];
  uint uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa817;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uVar1 = *param_4;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_3);
  uStack_8 = 0;
  uStack_30 = uVar1;
  FUN_006f6310(aiStack_48);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_34) {
    uVar5 = uStack_34 + 1;
    iVar3 = aiStack_48[0];
    if (0xfff < uVar5) {
      iVar3 = *(int *)(aiStack_48[0] + -4);
      uVar5 = uStack_34 + 0x24;
      if (0x1f < (aiStack_48[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  cVar2 = FUN_00621090(uVar1);
  if (cVar2 == '\0') {
    ExceptionList = pvStack_10;
    return 1;
  }
  iVar3 = (**(code **)(*param_2 + 8))();
  uVar8 = 0x6f69d5;
  FUN_006b20a0(param_1,param_2,0x15);
  FUN_006b9320(param_2,uVar1);
  uVar11 = 1;
  uVar10 = 3;
  uVar9 = 0x6f69f0;
  FUN_00565940(3,1);
  uStack_8 = 1;
  FUN_01255470(9,0,0,0);
  FUN_01255490(in_stack_fffffdfc,in_stack_fffffe00,uVar8,uVar9,uVar10,uVar11);
  uStack_8._0_1_ = 2;
  FUN_008a1ac0(auStack_1e0,param_3);
  uStack_8._0_1_ = 3;
  FUN_00cb4b80(auStack_100,auStack_1e0,0);
  FUN_006ad360(param_3,param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  uStack_2c = 2;
  if (((uStack_bc & 2) == 0) && (uVar5 = *puStack_d8, uVar5 != 0)) {
    if (uVar5 < uStack_c0) {
      uVar5 = uStack_c0;
    }
    iVar4 = *piStack_e8;
    iVar6 = uVar5 - iVar4;
  }
  else {
    if (((uStack_bc & 4) != 0) || (*piStack_dc == 0)) goto LAB_006f6ac6;
    iVar4 = *piStack_ec;
    iVar6 = (*piStack_dc - iVar4) + *piStack_cc;
  }
  FUN_005542c0(iVar4,iVar6);
LAB_006f6ac6:
  uStack_8 = 5;
  FUN_006ad360(auStack_28,param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (0xf < uStack_14) {
    uVar7 = uStack_14 + 1;
    uVar5 = auStack_28[0];
    if (0xfff < uVar7) {
      uVar5 = *(uint *)(auStack_28[0] - 4);
      uVar7 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar7);
  }
  if ((param_1[0xe02] & 2U) != 0) {
    (**(code **)(*param_1 + 0x13c))(param_2,uVar1,param_3);
  }
  if (*(char *)(param_1[0x7dc] + 0x5b) != '\0') {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("Attributes",10);
    uStack_8._0_1_ = 6;
    FUN_006b8740(auStack_28);
    uStack_8._0_1_ = 3;
    FUN_005507b0();
    iVar4 = (**(code **)(*param_2 + 8))();
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("Attributes",10);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_006b89d0(auStack_28,iVar4 - iVar3);
    FUN_005507b0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (iStack_1dc != 0) {
    (**(code **)(iStack_1dc + 8))(auStack_1d8);
  }
  FUN_01255500();
  FUN_005705c0();
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 9687 ; VA 0x006f6c20 ; FUN_006f6c20 */

void __thiscall FUN_006f6c20(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aa830;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::DeserializedDeleteInstanceItem>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9688 ; VA 0x006f6c8e ; Catch_All@006f6c8e */

void Catch_All_006f6c8e(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9689 ; VA 0x006f6cb0 ; FUN_006f6cb0 */

undefined4 * __thiscall FUN_006f6cb0(undefined4 *param_1,undefined4 param_2,undefined4 *param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa748;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006b1a30(param_2);
  *param_1 = RBX::Network::Replicator::DeleteInstanceItem::vftable;
  uStack_8 = 0;
  FUN_006b91d0(param_1 + 0xc,*param_3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9690 ; VA 0x006f6d10 ; FUN_006f6d10 */

undefined4 * __fastcall FUN_006f6d10(undefined4 *param_1)

{
  param_1[1] = 1;
  param_1[2] = 1;
  param_1[3] = 0;
  *param_1 = RBX::Network::DeserializedDeleteInstanceItem::vftable;
  param_1[4] = 0xffffffff;
  param_1[5] = 0;
  return param_1;
}



/* FUNCTION 9691 ; VA 0x006f6d50 ; FUN_006f6d50 */

undefined4 * __thiscall FUN_006f6d50(undefined4 *param_1,uint param_2)

{
  int *piVar1;
  
  *param_1 = RBX::Network::Item::vftable;
  if ((param_2 & 1) != 0) {
    if ((param_2 & 4) == 0) {
      piVar1 = *(int **)param_1[-1];
      param_1[-1] = *piVar1;
      *piVar1 = (int)(param_1 + -1);
      return param_1;
    }
    _guard_check_icall(param_1,0x40);
  }
  return param_1;
}



/* FUNCTION 9692 ; VA 0x006f6d90 ; FUN_006f6d90 */

undefined4 * __thiscall FUN_006f6d90(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Network::DeserializedItem::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 9693 ; VA 0x006f6dc0 ; FUN_006f6dc0 */

undefined4 __thiscall FUN_006f6dc0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  undefined4 uVar5;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa850;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01d59fb8 != '\0') {
    ExceptionList = &pvStack_10;
    uVar5 = FUN_016f3cd0();
    FUN_006283d0(&DAT_0211a3d8,uVar5);
  }
  iStack_18 = 0;
  piStack_14 = (int *)0x0;
  uStack_8 = 0;
  if (*(char *)(param_2 + 0x76e) == '\0') {
    cVar4 = FUN_00621ac0(param_1 + 0x10,&iStack_18);
    if (cVar4 != '\0') {
      cVar4 = (**(code **)(*param_2 + 0xfc))(iStack_18);
      if (cVar4 != '\0') {
        cVar4 = FUN_0061c150(&iStack_18);
        if (cVar4 != '\0') {
          if (DAT_01ee420e != '\0') {
            FUN_016774b0(DAT_01ee420e,"Replicating unparenting instance %p",iStack_18);
          }
          iVar2 = param_2[0x26];
          param_2[0x26] = iStack_18;
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          FUN_008a65e0(0,0);
          param_2[0x26] = iVar2;
        }
      }
    }
    piVar3 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_14[1] + -1;
      piStack_14[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 9694 ; VA 0x006f6ee0 ; FUN_006f6ee0 */

int * FUN_006f6ee0(int *param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined auStack_20 [8];
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa868;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    puVar5[1] = 1;
    puVar5[2] = 1;
    puVar5[3] = 0;
    *puVar5 = RBX::Network::DeserializedDeleteInstanceItem::vftable;
    puVar5[4] = 0xffffffff;
    puVar5[5] = 0;
  }
  iStack_18 = 0;
  piStack_14 = (int *)0x0;
  FUN_006f6c20(puVar5,param_3);
  uStack_8 = 0;
  iVar2 = *(int *)(param_3 + 0x20);
  puVar5 = (undefined4 *)FUN_006b8fd0(auStack_20,param_3);
  iVar3 = iStack_18;
  *(undefined4 *)(iStack_18 + 0x10) = *puVar5;
  *(undefined4 *)(iStack_18 + 0x14) = puVar5[1];
  if (*(char *)(*(int *)(param_2 + 0x1f70) + 0x5b) != '\0') {
    FUN_006b86c0(1);
    FUN_006b8900(1,*(int *)(param_3 + 0x20) - iVar2);
  }
  piVar4 = piStack_14;
  if (*(int *)(iVar3 + 0x10) == -1) {
    *param_1 = 0;
    param_1[1] = 0;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_14[1] + -1;
      piStack_14[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  *param_1 = iVar3;
  param_1[1] = (int)piStack_14;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9695 ; VA 0x006f7020 ; FUN_006f7020 */

undefined4 __thiscall FUN_006f7020(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  
  if (*(char *)(param_1 + 0x30) != '\0') {
    iVar1 = *(int *)(param_1 + 0x10);
    FUN_006b20a0(iVar1,param_2,1);
    iVar2 = *(int *)(param_2 + 0x18);
    FUN_006b9280(param_2,param_1 + 0x30);
    if (DAT_01d59fb8 != '\0') {
      FUN_006283d0(&DAT_0211a3d8,*(int *)(param_2 + 0x18) - iVar2);
    }
    if (*(char *)(*(int *)(iVar1 + 0x1f70) + 0x5b) != '\0') {
      FUN_006b87f0(1);
      FUN_006b8ae0(1,*(int *)(param_2 + 0x18) - iVar2);
    }
    return 1;
  }
  return 1;
}



/* FUNCTION 9696 ; VA 0x006f70b0 ; FUN_006f70b0 */

undefined4 FUN_006f70b0(int param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  
  FUN_006b20a0(param_1,param_2,1);
  iVar1 = *(int *)(param_2 + 0x18);
  FUN_006b9280(param_2,param_3);
  if (DAT_01d59fb8 != '\0') {
    FUN_006283d0(&DAT_0211a3d8,*(int *)(param_2 + 0x18) - iVar1);
  }
  if (*(char *)(*(int *)(param_1 + 0x1f70) + 0x5b) != '\0') {
    FUN_006b87f0(1);
    FUN_006b8ae0(1,*(int *)(param_2 + 0x18) - iVar1);
  }
  return 1;
}



/* FUNCTION 9697 ; VA 0x006f7130 ; FUN_006f7130 */

void __thiscall FUN_006f7130(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aa880;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::DeserializedEventInvocationItem>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9698 ; VA 0x006f719e ; Catch_All@006f719e */

void Catch_All_006f719e(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9699 ; VA 0x006f71c0 ; FUN_006f71c0 */

undefined4 * __thiscall
FUN_006f71c0(undefined4 *param_1,undefined4 param_2,undefined4 *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 *param_6)

{
  int *piVar1;
  
  FUN_006b1a30(param_2);
  *param_1 = RBX::Network::Replicator::EventInvocationItem::vftable;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0xc] = *param_3;
  param_1[0xd] = param_3[1];
  param_1[0xe] = param_4;
  param_1[0xf] = param_5;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  if (param_6[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_6[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x10] = *param_6;
  param_1[0x11] = param_6[1];
  return param_1;
}



/* FUNCTION 9700 ; VA 0x006f7240 ; FUN_006f7240 */

undefined4 * __thiscall FUN_006f7240(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *param_1 = RBX::Network::DeserializedEventInvocationItem::vftable;
  FUN_0056d600();
  piVar2 = (int *)param_1[6];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *param_1 = RBX::Network::DeserializedItem::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 9701 ; VA 0x006f72a0 ; FUN_006f72a0 */

undefined4 * __thiscall FUN_006f72a0(undefined4 *param_1,uint param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = (int *)param_1[0x11];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0xd];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *param_1 = RBX::Network::Item::vftable;
  if ((param_2 & 1) != 0) {
    if ((param_2 & 4) == 0) {
      piVar2 = *(int **)param_1[-1];
      param_1[-1] = *piVar2;
      *piVar2 = (int)(param_1 + -1);
      return param_1;
    }
    _guard_check_icall(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 9702 ; VA 0x006f7340 ; FUN_006f7340 */

undefined4 FUN_006f7340(void)

{
  return 7;
}



/* FUNCTION 9703 ; VA 0x006f7350 ; FUN_006f7350 */

void __fastcall FUN_006f7350(undefined4 param_1)

{
  FUN_00626f00(param_1);
  return;
}



/* FUNCTION 9704 ; VA 0x006f7360 ; FUN_006f7360 */

int * FUN_006f7360(int *param_1,int *param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined **ppuVar6;
  undefined4 uVar7;
  undefined **ppuVar8;
  int iVar9;
  char *pcVar10;
  int *piVar11;
  undefined auStack_c8 [36];
  undefined auStack_a4 [12];
  undefined auStack_98 [24];
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined auStack_78 [4];
  undefined *puStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  char *pcStack_50;
  int iStack_4c;
  undefined4 uStack_48;
  undefined4 *puStack_44;
  undefined4 uStack_40;
  undefined2 uStack_3c;
  int iStack_38;
  int *piStack_34;
  int iStack_30;
  uint uStack_2c;
  uint uStack_28;
  int iStack_24;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa8bb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_1c = (int *)FUN_01674e20(0x2c);
  if (piStack_1c == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    piStack_1c[1] = 7;
    piStack_1c[2] = 1;
    piStack_1c[3] = 0;
    *piStack_1c = (int)RBX::Network::DeserializedEventInvocationItem::vftable;
    piStack_1c[4] = 0;
    piStack_1c[5] = 0;
    piStack_1c[6] = 0;
    piStack_1c[8] = 0;
    piStack_1c[9] = 0;
    piStack_1c[10] = 0;
    puVar5 = piStack_1c;
  }
  iStack_24 = 0;
  piStack_20 = (int *)0x0;
  FUN_006f7130(puVar5,piStack_1c);
  iStack_38 = 0;
  piStack_34 = (int *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uStack_80 = 0xffffffff;
  uStack_7c = 0;
  FUN_006b9040(param_3,&iStack_38,&uStack_80);
  uStack_28 = 0;
  cVar4 = FUN_006abe60(&uStack_28,2);
  if (cVar4 == '\0') {
    FUN_0054eff0("readFast past end for uint16_t");
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_005f8ef0(&pcStack_50);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_a4,&DAT_01c27108);
  }
  uStack_28 = (uint)(ushort)((ushort)uStack_28 << 8 | (ushort)uStack_28 >> 8);
  iStack_18 = *(int *)(param_2[0x67d] + 0x70);
  if (((uint)((*(int *)(param_2[0x67d] + 0x74) - iStack_18) / 0x14) <= uStack_28) ||
     (iVar2 = iStack_18 + uStack_28 * 0x14, iVar2 == 0)) {
    uVar7 = FUN_00615990();
    FUN_016756b0(&puStack_44,
                 "Received invalid event id in event invocation item. Read offset=%X bytes",uVar7);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(&puStack_44,&DAT_01c17198);
  }
  if (((iStack_38 != 0) && (*(int *)(iVar2 + 0x10) != 0)) &&
     (cVar4 = FUN_00893260(*(undefined4 *)(iStack_38 + 0xc)), cVar4 == '\0')) {
    uVar7 = FUN_00615990();
    FUN_016756b0(&puStack_44,
                 "Received event does not belong to referenced instance. Read offset=%X bytes",uVar7
                );
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(&puStack_44,&DAT_01c17198);
  }
  iVar3 = iStack_24;
  FUN_0056ecd0(&iStack_38);
  *(undefined4 *)(iVar3 + 0x1c) = *(undefined4 *)(iVar2 + 0x10);
  FUN_006045c0((*(int *)(iVar2 + 8) - *(int *)(iVar2 + 4)) / 0xc,iVar3 + 0x20);
  cStack_11 = '\0';
  auStack_78[0] = 0;
  iStack_18 = 0xb;
  ppuVar6 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&iStack_18);
  ppuVar8 = ppuVar6 + -1;
  if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar8 = ppuVar6;
  }
  puStack_74 = *ppuVar8;
  uStack_70 = 0;
  uStack_6c = 0x3f800000;
  uStack_68 = 0;
  uStack_64 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_60 = 0;
  uStack_5c = 0;
  uStack_58 = 0;
  uStack_54 = 0;
  if (((DAT_01d5bb88 != '\0') || (DAT_01d5a0c0 != '\0')) &&
     ((cVar4 = (**(code **)(*param_2 + 0x11c))(), cVar4 == '\0' &&
      (cVar4 = (**(code **)(*param_2 + 0xd4))(), cVar4 != '\0')))) {
    uStack_58 = DAT_01eaf464;
    uStack_54 = DAT_01eaf468;
  }
  uStack_2c = 0;
  iVar9 = *(int *)(iVar2 + 8) - *(int *)(iVar2 + 4);
  iVar3 = iVar9 >> 0x1f;
  if (iVar9 / 0xc + iVar3 != iVar3) {
    iStack_30 = 0;
    iStack_18 = 0;
    do {
      piStack_1c = *(int **)(iStack_24 + 0x14);
      pcVar10 = (char *)(*(int *)(iVar2 + 4) + iStack_30);
      if (*pcVar10 == '\x03') {
        FUN_0054eff0("Invalid variant type");
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
        FUN_005f8ef0(auStack_98);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_c8,&DAT_01c27108);
      }
      uStack_3c = (ushort)uStack_28;
      uStack_48 = 0;
      uStack_40 = 0;
      pcStack_50 = pcVar10;
      iStack_4c = *(int *)(iStack_24 + 0x20) + iStack_18;
      puStack_44 = piStack_1c;
      FUN_00609060(param_3,pcVar10,1,&pcStack_50,0,auStack_78,&uStack_60);
      uStack_2c = uStack_2c + 1;
      iStack_18 = iStack_18 + 0xd0;
      iStack_30 = iStack_30 + 0xc;
    } while (uStack_2c < (uint)((*(int *)(iVar2 + 8) - *(int *)(iVar2 + 4)) / 0xc));
  }
  FUN_00627d20(param_3,auStack_78);
  piStack_1c = *(int **)(iStack_24 + 0x24);
  piVar11 = *(int **)(iStack_24 + 0x20);
  cVar4 = cStack_11;
  if (piVar11 != piStack_1c) {
    do {
      iVar3 = *piVar11;
      iVar9 = FUN_00888530();
      if (iVar3 == iVar9) {
        cVar4 = '\x01';
        break;
      }
      piVar11 = piVar11 + 0x34;
      cVar4 = cStack_11;
    } while (piVar11 != piStack_1c);
  }
  if (((*(int *)(iStack_24 + 0x14) == 0) || (*(int *)(iVar2 + 0x10) == 0)) || (cVar4 != '\0')) {
    *param_1 = 0;
    param_1[1] = 0;
    FUN_006bf690();
    piVar1 = piStack_34;
    piVar11 = piStack_20;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_34[1] + -1;
      piStack_34[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        piVar11 = piVar1 + 2;
        iVar2 = *piVar11 + -1;
        *piVar11 = iVar2;
        UNLOCK();
        piVar11 = piStack_20;
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
          piVar11 = piStack_20;
        }
      }
    }
  }
  else {
    *(undefined4 *)(iStack_24 + 0x10) = uStack_60;
    *param_1 = iStack_24;
    param_1[1] = (int)piStack_20;
    FUN_006bf690();
    piVar11 = piStack_34;
  }
  if (piVar11 != (int *)0x0) {
    LOCK();
    iVar2 = piVar11[1] + -1;
    piVar11[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar11)();
      LOCK();
      piVar1 = piVar11 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar11 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9705 ; VA 0x006f7810 ; FUN_006f7810 */

void __fastcall FUN_006f7810(int param_1)

{
  (**(code **)(**(int **)(param_1 + 0x10) + 0xd8))
            (*(undefined4 *)(param_1 + 0x30),*(undefined4 *)(param_1 + 0x38),
             *(undefined4 *)(param_1 + 0x40));
  return;
}



/* FUNCTION 9706 ; VA 0x006f7830 ; FUN_006f7830 */

void __thiscall FUN_006f7830(int param_1,undefined4 param_2)

{
  FUN_006f7850(param_2,*(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x3c),
               *(undefined4 *)(param_1 + 0x30),*(undefined4 *)(param_1 + 0x40));
  return;
}



/* FUNCTION 9707 ; VA 0x006f7850 ; FUN_006f7850 */

undefined4 FUN_006f7850(uint param_1,int *param_2,ushort *param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  int *piVar2;
  ushort *puVar3;
  char cVar4;
  uint uVar5;
  int iVar6;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa728;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00620990(7);
  iVar6 = param_1;
  auStack_14[0] = 7;
  FUN_006ad5e0(auStack_14,1);
  iStack_20 = *(int *)(iVar6 + 0x18);
  FUN_006b9320(iVar6,param_4);
  puVar3 = param_3;
  param_3 = (ushort *)(uint)*param_3;
  FUN_006a5c10(&param_3,&param_1,2);
  FUN_006ad5e0(&param_1,2);
  iStack_2c = 0;
  iStack_28 = 0;
  iStack_24 = 0;
  uStack_8 = 0;
  uStack_3c = 0;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  if ((((DAT_01d5bb80 != '\0') || (DAT_01d5a0c0 != '\0')) &&
      (cVar4 = (**(code **)(*piVar2 + 0x11c))(), cVar4 == '\0')) &&
     (cVar4 = (**(code **)(*piVar2 + 0xd4))(), cVar4 == '\0')) {
    uStack_34 = DAT_01eaf45c;
    uStack_30 = DAT_01eaf460;
  }
  param_1 = 0;
  iVar1 = *(int *)(puVar3 + 4) - *(int *)(puVar3 + 2) >> 0x1f;
  if ((*(int *)(puVar3 + 4) - *(int *)(puVar3 + 2)) / 0xc + iVar1 != iVar1) {
    param_3 = (ushort *)0x0;
    iStack_18 = 0;
    do {
      iStack_1c = *param_5 + iStack_18;
      FUN_0060c670(iVar6,*(int *)(puVar3 + 2) + (int)param_3,1,&iStack_1c,0,&iStack_2c,&uStack_3c);
      iStack_18 = iStack_18 + 0xd0;
      param_3 = (ushort *)((int)param_3 + 0xc);
      param_1 = param_1 + 1;
    } while (param_1 < (uint)((*(int *)(puVar3 + 4) - *(int *)(puVar3 + 2)) / 0xc));
  }
  FUN_00632400(iVar6,&iStack_2c);
  if (DAT_01d59fb8 != '\0') {
    FUN_006281a0(*(undefined4 *)(puVar3 + 8),*(int *)(iVar6 + 0x18) - iStack_20);
  }
  iVar1 = iStack_28;
  iVar6 = iStack_2c;
  if (iStack_2c != 0) {
    for (; iVar6 != iVar1; iVar6 = iVar6 + 4) {
      FUN_00615780(0);
    }
    uVar5 = iStack_24 - iStack_2c & 0xfffffffc;
    iVar6 = iStack_2c;
    if (0xfff < uVar5) {
      iVar6 = *(int *)(iStack_2c + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iStack_2c - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar5);
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 9708 ; VA 0x006f7a50 ; FUN_006f7a50 */

undefined4 * __thiscall
FUN_006f7a50(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[5] = param_4;
  param_1[4] = 2;
  *(undefined2 *)(param_1 + 6) = 0;
  return param_1;
}



/* FUNCTION 9709 ; VA 0x006f7a90 ; FUN_006f7a90 */

int __fastcall FUN_006f7a90(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_006f7b20();
  piVar3 = *(int **)(param_1 + 0xc);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 9710 ; VA 0x006f7af0 ; FUN_006f7af0 */

int __thiscall FUN_006f7af0(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = FUN_0170d8dd(param_2 + 4,0x1d9d274);
  if (iVar1 == 0) {
    return param_1 + 0xc;
  }
  return 0;
}



/* FUNCTION 9711 ; VA 0x006f7b20 ; FUN_006f7b20 */

void __fastcall FUN_006f7b20(int *param_1)

{
  int *piVar1;
  double dVar2;
  undefined uVar3;
  undefined uVar4;
  int iVar5;
  short sVar6;
  int iVar7;
  undefined *puVar8;
  double *pdVar9;
  int *piVar10;
  double dVar11;
  double dVar12;
  double dVar13;
  undefined4 in_stack_ffffff94;
  undefined4 in_stack_ffffff98;
  int iVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  undefined4 uVar17;
  undefined4 uVar18;
  undefined4 uVar19;
  undefined4 uVar20;
  undefined4 uVar21;
  undefined4 uVar22;
  undefined4 uVar23;
  undefined4 uVar24;
  undefined4 uVar25;
  double dStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  int iStack_10;
  int *piStack_c;
  undefined auStack_8 [4];
  
  uStack_18 = (double)CONCAT44(param_1,(undefined4)uStack_18);
  piVar10 = param_1 + 2;
  if ((int *)param_1[2] != (int *)0x0) {
    piStack_c = piVar10;
    iStack_10 = (**(code **)(*(int *)param_1[2] + 8))();
    if ((int)(uint)(DAT_01d59fc0 != '\0') < iStack_10) {
      auStack_8[0] = 0;
      FUN_006ad5e0(auStack_8,1);
      if (DAT_01ee4215 != '\0') {
        iVar7 = (**(code **)(*(int *)*piVar10 + 4))();
        uVar3 = *(undefined *)(iVar7 + 2);
        iVar7 = (**(code **)(*(int *)*piVar10 + 4))();
        uVar4 = *(undefined *)(iVar7 + 1);
        puVar8 = (undefined *)(**(code **)(*(int *)*piStack_c + 4))();
        FUN_01677490(DAT_01ee4215,
                     "Replicator::ItemSender::closePacket() : sending packet ID=%d, Type=%d, SubType=%d"
                     ,*puVar8,uVar4,uVar3);
        piVar10 = piStack_c;
        param_1 = uStack_18._4_4_;
      }
      if ((DAT_01d5aed0 == '\0') || (*(char *)(param_1 + 6) == '\0')) {
        iVar7 = *param_1;
        uStack_18 = (double)CONCAT44(param_1[1],(undefined4)uStack_18);
        uVar17 = *(undefined4 *)(iVar7 + 0x74);
        uVar18 = *(undefined4 *)(iVar7 + 0x78);
        uVar19 = *(undefined4 *)(iVar7 + 0x7c);
        uVar20 = *(undefined4 *)(iVar7 + 0x80);
        iVar5 = param_1[4];
        uVar21 = *(undefined4 *)(iVar7 + 0x84);
        uVar22 = *(undefined4 *)(iVar7 + 0x88);
        uVar23 = *(undefined4 *)(iVar7 + 0x8c);
        uVar24 = *(undefined4 *)(iVar7 + 0x90);
        if (param_1[3] != 0) {
          LOCK();
          piVar1 = (int *)(param_1[3] + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        FUN_006afb30(*piVar10,param_1[3],iVar5,3,0,uVar17,uVar18,uVar19,uVar20,uVar21,uVar22,uVar23,
                     uVar24,0,iVar7 + 0x17a8);
      }
      else {
        iVar5 = *param_1;
        uVar17 = *(undefined4 *)(iVar5 + 0x74);
        uVar18 = *(undefined4 *)(iVar5 + 0x78);
        uVar19 = *(undefined4 *)(iVar5 + 0x7c);
        uVar20 = *(undefined4 *)(iVar5 + 0x80);
        iVar7 = iVar5 + 0x17a8;
        uVar25 = 0;
        uVar16 = 0;
        uVar15 = 7;
        iVar14 = param_1[4];
        uVar21 = *(undefined4 *)(iVar5 + 0x84);
        uVar22 = *(undefined4 *)(iVar5 + 0x88);
        uVar23 = *(undefined4 *)(iVar5 + 0x8c);
        uVar24 = *(undefined4 *)(iVar5 + 0x90);
        FUN_00557fc0(param_1 + 2);
        FUN_006afb30(in_stack_ffffff94,in_stack_ffffff98,iVar14,uVar15,uVar16,uVar17,uVar18,uVar19,
                     uVar20,uVar21,uVar22,uVar23,uVar24,uVar25,iVar7);
        *(undefined *)(param_1 + 6) = 0;
      }
      iVar7 = *param_1;
      pdVar9 = (double *)(iVar7 + 0x818);
      if (*(char *)(iVar7 + 0x820) == '\0') {
        FUN_016827a0(&uStack_20);
        dStack_28 = (double)CONCAT44(uStack_1c,uStack_20) - *pdVar9;
        *(undefined4 *)pdVar9 = uStack_20;
        *(undefined4 *)(iVar7 + 0x81c) = uStack_1c;
        uStack_18 = dStack_28;
        sVar6 = FUN_017265ed(&dStack_28);
        if (sVar6 < 1) {
          dVar2 = *(double *)(iVar7 + 0x828);
          dVar11 = DAT_018c0d60 - dVar2;
          dVar12 = uStack_18;
          if (*(char *)(iVar7 + 0x848) == '\0') {
            dVar12 = *(double *)(iVar7 + 0x838) * dVar11 + dVar2 * uStack_18;
          }
          *(double *)(iVar7 + 0x830) = uStack_18;
          *(undefined *)(iVar7 + 0x848) = 0;
          *(double *)(iVar7 + 0x838) = dVar12;
          *(double *)(iVar7 + 0x840) =
               (uStack_18 - dVar12) * (uStack_18 - dVar12) * dVar2 +
               *(double *)(iVar7 + 0x840) * dVar11;
        }
      }
      else {
        FUN_016827a0(&uStack_20);
        *(undefined4 *)pdVar9 = uStack_20;
        *(undefined4 *)(iVar7 + 0x81c) = uStack_1c;
        *(undefined *)(iVar7 + 0x820) = 0;
      }
      iVar7 = *param_1;
      dStack_28 = (double)iStack_10;
      sVar6 = FUN_017265ed(&dStack_28);
      piVar10 = piStack_c;
      if (sVar6 < 1) {
        dVar2 = *(double *)(iVar7 + 0x880);
        dVar13 = DAT_018c0d60 - dVar2;
        dVar11 = (double)iStack_10;
        dVar12 = dVar11;
        if (*(char *)(iVar7 + 0x8a0) == '\0') {
          dVar12 = *(double *)(iVar7 + 0x890) * dVar13 + dVar11 * dVar2;
        }
        *(int *)(iVar7 + 0x888) = iStack_10;
        *(double *)(iVar7 + 0x890) = dVar12;
        *(undefined *)(iVar7 + 0x8a0) = 0;
        *(double *)(iVar7 + 0x898) =
             (dVar11 - dVar12) * (dVar11 - dVar12) * dVar2 + *(double *)(iVar7 + 0x898) * dVar13;
      }
    }
    *piVar10 = 0;
    piVar10 = (int *)piVar10[1];
    param_1[3] = 0;
    if (piVar10 != (int *)0x0) {
      LOCK();
      iVar7 = piVar10[1] + -1;
      piVar10[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar10)();
        LOCK();
        piVar1 = piVar10 + 2;
        iVar7 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar7 == 1) {
          (**(code **)(*piVar10 + 4))();
        }
      }
    }
  }
  return;
}



/* FUNCTION 9712 ; VA 0x006f7e00 ; FUN_006f7e00 */

undefined4 __fastcall FUN_006f7e00(int param_1)

{
  undefined4 uVar1;
  
  if (*(int **)(param_1 + 8) != (int *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x006f7e09. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (**(code **)(**(int **)(param_1 + 8) + 8))();
    return uVar1;
  }
  return 0;
}



/* FUNCTION 9713 ; VA 0x006f7e10 ; FUN_006f7e10 */

void __fastcall FUN_006f7e10(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa8df;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 8) == 0) {
    ExceptionList = &pvStack_10;
    iVar3 = FUN_01674e20(0x28);
    uStack_8 = 0;
    if (iVar3 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_006ab530();
    }
    uStack_8 = 0xffffffff;
    FUN_00604a80(uVar4,0);
    *(undefined4 *)(param_1 + 8) = 0;
    piVar2 = *(int **)(param_1 + 0xc);
    *(undefined4 *)(param_1 + 0xc) = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    auStack_14[0] = 0x83;
    FUN_006ad5e0(auStack_14,1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9714 ; VA 0x006f7ee0 ; FUN_006f7ee0 */

undefined4 __thiscall FUN_006f7ee0(int *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  char cVar4;
  uint uVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa8f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (((int *)param_1[2] != (int *)0x0) &&
     (ExceptionList = &pvStack_10, uVar5 = (**(code **)(*(int *)param_1[2] + 8))(),
     (uint)param_1[5] <= uVar5)) {
    ExceptionList = pvStack_10;
    return 0;
  }
  if (((*(uint *)(*param_1 + 0x3808) & 0x20000) == 0) ||
     (cVar4 = (**(code **)(*param_2 + 0x10))(), cVar4 == '\0')) {
    FUN_006f7e10();
    cVar4 = (**(code **)(*param_2 + 4))(param_1[2]);
    if (cVar4 == '\0') {
      ExceptionList = pvStack_10;
      return 0;
    }
    goto LAB_006f807d;
  }
  if (param_1[2] == 0) {
    if (DAT_01d5bb90 < 1) {
      param_2 = (int *)0xea60;
    }
    else {
      param_2 = (int *)(DAT_01d5bb90 * 1000);
      if ((int)param_2 < 1) goto LAB_006f8045;
    }
    do {
      cVar4 = (**(code **)(*piVar2 + 0x10))();
      if (cVar4 == '\0') break;
      (**(code **)(*piVar2 + 0x14))(&puStack_14);
      puVar3 = puStack_14;
      puVar6 = (undefined4 *)0x0;
      uStack_8 = 0;
      puVar8 = (undefined4 *)0x0;
      if (puStack_14 != (undefined4 *)0x0) {
        puVar6 = (undefined4 *)FUN_01674e20(0x10);
        if (puVar6 == (undefined4 *)0x0) {
          puVar6 = (undefined4 *)0x0;
        }
        else {
          puVar6[1] = 1;
          puVar6[2] = 1;
          *puVar6 = std::
                    _Ref_count_resource<class_RBX::Network::NetworkStream*,struct_std::default_delete<class_RBX::Network::NetworkStream>_>
                    ::vftable;
          puVar6[3] = puVar3;
        }
        puStack_14 = (undefined4 *)0x0;
        puVar8 = puVar3;
      }
      param_1[2] = (int)puVar8;
      piVar1 = (int *)param_1[3];
      param_1[3] = (int)puVar6;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar7 = piVar1[1] + -1;
        piVar1[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar7 = piVar1[2] + -1;
          piVar1[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      iVar7 = (**(code **)(*(int *)param_1[2] + 8))();
      param_2 = (int *)((int)param_2 - iVar7);
      FUN_006f7b20();
      uStack_8 = 0xffffffff;
      if (puStack_14 != (undefined4 *)0x0) {
        (**(code **)*puStack_14)(1);
      }
    } while (0 < (int)param_2);
  }
LAB_006f8045:
  cVar4 = (**(code **)(*piVar2 + 0x10))();
  if (cVar4 != '\0') {
    ExceptionList = pvStack_10;
    return 0;
  }
LAB_006f807d:
  if ((DAT_01d5aed0 != '\0') && (*(char *)(piVar2 + 8) != '\0')) {
    *(undefined *)(param_1 + 6) = 1;
  }
  *(undefined *)((int)param_1 + 0x19) = 1;
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 9715 ; VA 0x006f80b0 ; FUN_006f80b0 */

undefined4 __thiscall FUN_006f80b0(int param_1,undefined4 param_2,int *param_3)

{
  char cVar1;
  uint uVar2;
  
  if ((*(int **)(param_1 + 8) != (int *)0x0) &&
     (uVar2 = (**(code **)(**(int **)(param_1 + 8) + 8))(), *(uint *)(param_1 + 0x14) <= uVar2)) {
    return 0;
  }
  FUN_006f7e10();
  cVar1 = (**(code **)(*param_3 + 8))(param_2,param_1 + 8);
  if (cVar1 == '\0') {
    return 0;
  }
  *(undefined *)(param_1 + 0x19) = 1;
  return 1;
}



/* FUNCTION 9716 ; VA 0x006f8100 ; FUN_006f8100 */

void FUN_006f8100(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  int iVar2;
  
  iVar2 = FUN_00575b50(param_1,param_2);
  uVar1 = *param_3;
  *param_3 = 0;
  *(undefined4 *)(iVar2 + 8) = uVar1;
  return;
}



/* FUNCTION 9717 ; VA 0x006f8120 ; FUN_006f8120 */

void FUN_006f8120(uint *param_1,uint *param_2,uint *param_3)

{
  uint uVar1;
  uint uVar2;
  
  uVar2 = *param_2;
  if (uVar2 < *param_1) {
    uVar1 = param_2[1];
    *param_2 = *param_1;
    param_2[1] = param_1[1];
    *param_1 = uVar2;
    param_1[1] = uVar1;
    uVar2 = *param_2;
  }
  if (*param_3 < uVar2) {
    uVar2 = *param_3;
    *param_3 = *param_2;
    uVar1 = param_3[1];
    param_3[1] = param_2[1];
    *param_2 = uVar2;
    param_2[1] = uVar1;
    if (uVar2 < *param_1) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      *param_1 = uVar2;
      param_1[1] = uVar1;
    }
  }
  return;
}



/* FUNCTION 9718 ; VA 0x006f8180 ; FUN_006f8180 */

void FUN_006f8180(undefined4 *param_1,uint *param_2,uint *param_3,undefined4 param_4)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint *puVar4;
  uint *puVar5;
  uint *puVar6;
  uint *puVar7;
  uint *puVar8;
  uint *puVar9;
  uint *puStack_10;
  uint *puStack_c;
  uint *puStack_8;
  
  puVar5 = param_3 + -2;
  puStack_8 = param_2 + ((int)param_3 - (int)param_2 >> 4) * 2;
  iVar3 = (int)puVar5 - (int)param_2 >> 3;
  if (iVar3 < 0x29) {
    FUN_006f8120(param_2,puStack_8,puVar5,param_4);
  }
  else {
    iVar3 = iVar3 + 1 >> 3;
    FUN_006f8120(param_2,param_2 + iVar3 * 2,param_2 + iVar3 * 4,param_4);
    FUN_006f8120(puStack_8 + iVar3 * -2,puStack_8,puStack_8 + iVar3 * 2,param_4);
    FUN_006f8120(puVar5 + iVar3 * -4,puVar5 + iVar3 * -2,puVar5,param_4);
    FUN_006f8120(param_2 + iVar3 * 2,puStack_8,puVar5 + iVar3 * -2,param_4);
  }
  puVar5 = puStack_8 + 2;
  for (; param_2 < puStack_8; puStack_8 = puStack_8 + -2) {
    uVar1 = *puStack_8;
    uVar2 = puStack_8[-2];
    if ((uVar2 < uVar1) || (uVar2 >= uVar1 && uVar2 != uVar1)) break;
  }
  puVar8 = puVar5;
  puStack_10 = puVar5;
  puStack_c = puVar5;
  puVar7 = puStack_8;
  if (puVar5 < param_3) {
    uVar1 = *puStack_8;
    do {
      uVar2 = *puVar5;
      puVar8 = puVar5;
      puStack_10 = puVar5;
      puStack_c = puVar5;
      if ((uVar2 < uVar1) || (uVar2 >= uVar1 && uVar2 != uVar1)) break;
      puVar5 = puVar5 + 2;
      puVar8 = puVar5;
      puStack_10 = puVar5;
      puStack_c = puVar5;
    } while (puVar5 < param_3);
  }
joined_r0x006f8272:
  do {
    puVar6 = puStack_8;
    if (param_3 <= puVar5) {
joined_r0x006f82af:
      for (; puVar9 = puVar8, param_2 < puStack_8; puStack_8 = puStack_8 + -2) {
        puVar4 = puVar6 + -2;
        puVar8 = puVar7;
        if (*puVar7 <= *puVar4) {
          puVar5 = puStack_10;
          puVar9 = puStack_c;
          if (*puVar7 < *puVar4) break;
          puVar8 = puVar7 + -2;
          if (puVar8 != puVar4) {
            uVar1 = *puVar8;
            uVar2 = puVar7[-1];
            *puVar8 = *puVar4;
            puVar7[-1] = puVar6[-1];
            *puVar4 = uVar1;
            puVar6[-1] = uVar2;
          }
        }
        puVar5 = puStack_10;
        puVar7 = puVar8;
        puVar8 = puStack_c;
        puVar6 = puVar4;
      }
      if (puStack_8 == param_2) {
        if (puVar5 == param_3) {
          param_1[1] = puVar9;
          *param_1 = puVar7;
          return;
        }
        if (puVar9 != puVar5) {
          uVar1 = *puVar7;
          uVar2 = puVar7[1];
          *puVar7 = *puVar9;
          puVar7[1] = puVar9[1];
          *puVar9 = uVar1;
          puVar9[1] = uVar2;
        }
        uVar1 = *puVar7;
        uVar2 = puVar7[1];
        *puVar7 = *puVar5;
        puVar7[1] = puVar5[1];
        puVar5[1] = uVar2;
        *puVar5 = uVar1;
        puVar5 = puVar5 + 2;
        puVar8 = puVar9 + 2;
        puStack_10 = puVar5;
        puStack_c = puVar9 + 2;
        puVar7 = puVar7 + 2;
      }
      else {
        puVar6 = puStack_8 + -2;
        if (puVar5 == param_3) {
          puVar4 = puVar7 + -2;
          if (puVar6 != puVar4) {
            uVar1 = *puVar6;
            uVar2 = puStack_8[-1];
            *puVar6 = *puVar4;
            puStack_8[-1] = puVar7[-1];
            *puVar4 = uVar1;
            puVar7[-1] = uVar2;
            puVar5 = puStack_10;
          }
          puVar8 = puVar9 + -2;
          uVar1 = *puVar4;
          uVar2 = puVar7[-1];
          *puVar4 = puVar9[-2];
          puVar7[-1] = puVar9[-1];
          puVar9[-1] = uVar2;
          *puVar8 = uVar1;
          puStack_c = puVar8;
          puStack_8 = puVar6;
          puVar7 = puVar4;
        }
        else {
          uVar1 = *puVar5;
          uVar2 = puVar5[1];
          *puVar5 = *puVar6;
          puVar5[1] = puStack_8[-1];
          puVar5 = puVar5 + 2;
          puStack_8[-1] = uVar2;
          *puVar6 = uVar1;
          puVar8 = puVar9;
          puStack_10 = puVar5;
          puStack_8 = puVar6;
        }
      }
      goto joined_r0x006f8272;
    }
    if (*puVar5 <= *puVar7) {
      puStack_c = puVar8;
      puStack_10 = puVar5;
      if (*puVar5 < *puVar7) goto joined_r0x006f82af;
      if (puVar8 != puVar5) {
        uVar1 = *puVar8;
        uVar2 = puVar8[1];
        *puVar8 = *puVar5;
        puVar8[1] = puVar5[1];
        puVar5[1] = uVar2;
        *puVar5 = uVar1;
      }
      puVar8 = puVar8 + 2;
    }
    puVar5 = puVar5 + 2;
    puStack_10 = puVar5;
    puStack_c = puVar8;
  } while( true );
}



/* FUNCTION 9719 ; VA 0x006f83d0 ; FUN_006f83d0 */

void FUN_006f83d0(int param_1,int param_2,uint param_3,uint *param_4)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar3 = (int)(param_3 - 1) >> 1;
  iVar2 = param_2;
  iVar4 = param_2;
  if (param_2 < iVar3) {
    do {
      iVar4 = (2 - (uint)(*(uint *)(param_1 + 0x10 + iVar2 * 0x10) <
                         *(uint *)(param_1 + 8 + iVar2 * 0x10))) + iVar2 * 2;
      *(undefined4 *)(param_1 + iVar2 * 8) = *(undefined4 *)(param_1 + iVar4 * 8);
      *(undefined4 *)(param_1 + 4 + iVar2 * 8) = *(undefined4 *)(param_1 + 4 + iVar4 * 8);
      iVar2 = iVar4;
    } while (iVar4 < iVar3);
  }
  if ((iVar4 == iVar3) && ((param_3 & 1) == 0)) {
    *(undefined4 *)(param_1 + iVar4 * 8) = *(undefined4 *)(param_1 + -8 + param_3 * 8);
    *(undefined4 *)(param_1 + 4 + iVar4 * 8) = *(undefined4 *)(param_1 + -4 + param_3 * 8);
    iVar4 = param_3 - 1;
  }
  while (param_2 < iVar4) {
    iVar2 = iVar4 + -1 >> 1;
    uVar1 = *(uint *)(param_1 + iVar2 * 8);
    if (*param_4 <= uVar1) break;
    *(uint *)(param_1 + iVar4 * 8) = uVar1;
    *(undefined4 *)(param_1 + 4 + iVar4 * 8) = *(undefined4 *)(param_1 + 4 + iVar2 * 8);
    iVar4 = iVar2;
  }
  *(uint *)(param_1 + iVar4 * 8) = *param_4;
  *(uint *)(param_1 + 4 + iVar4 * 8) = param_4[1];
  return;
}



/* FUNCTION 9720 ; VA 0x006f8470 ; FUN_006f8470 */

void FUN_006f8470(uint *param_1,uint *param_2,int param_3,undefined4 param_4)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint *puVar5;
  uint *puVar6;
  uint *puVar7;
  int iVar8;
  uint *puVar9;
  uint *puStack_1c;
  uint *puStack_18;
  uint uStack_14;
  uint *puStack_10;
  uint uStack_c;
  uint uStack_8;
  
  iVar3 = (int)param_2 - (int)param_1;
  puVar6 = param_2;
  puVar7 = param_1;
  iVar8 = param_3;
  do {
    iVar3 = iVar3 >> 3;
    if (iVar3 < 0x21) {
LAB_006f84f7:
      if (((1 < iVar3) && (puVar7 != puVar6)) && (puVar5 = puVar7 + 2, puVar5 != puVar6)) {
        do {
          uVar4 = *puVar5;
          uStack_c = puVar5[1];
          if (uVar4 < *puVar7) {
            FUN_0055b6b0((int)&param_1 + 3,&puStack_18,&puStack_18);
            FUN_0170cc70((int)puVar5 + (8 - ((int)puVar5 - (int)puVar7)),puVar7,
                         (int)puVar5 - (int)puVar7);
            *puVar7 = uVar4;
            puVar7[1] = uStack_c;
          }
          else {
            uVar2 = puVar5[-2];
            puVar1 = puVar5 + -2;
            puVar6 = puVar5;
            while (puVar9 = puVar1, uVar4 < uVar2) {
              *puVar6 = *puVar9;
              puVar6[1] = puVar9[1];
              puVar1 = puVar9 + -2;
              puVar6 = puVar9;
              uVar2 = puVar9[-2];
            }
            *puVar6 = uVar4;
            puVar6[1] = uStack_c;
          }
          puVar5 = puVar5 + 2;
        } while (puVar5 != param_2);
      }
      return;
    }
    if (iVar8 < 1) {
      if (0x20 < iVar3) {
        uVar4 = (int)puVar6 - (int)puVar7 >> 3;
        puVar6 = (uint *)((int)puVar6 - (int)puVar7 >> 4);
        if (0 < (int)puVar6) {
          param_1 = (uint *)((int)(uVar4 - 1) >> 1);
          puVar5 = puVar7 + (int)puVar6 * 2;
          do {
            uStack_c = puVar5[-2];
            puVar6 = (uint *)((int)puVar6 + -1);
            uStack_14 = puVar5[-1];
            puVar1 = puVar6;
            while ((int)puVar1 < (int)param_1) {
              puVar9 = (uint *)((2 - (uint)(puVar7[(int)puVar1 * 4 + 4] <
                                           puVar7[(int)puVar1 * 4 + 2])) + (int)puVar1 * 2);
              puVar7[(int)puVar1 * 2] = puVar7[(int)puVar9 * 2];
              puVar7[(int)puVar1 * 2 + 1] = puVar7[(int)puVar9 * 2 + 1];
              puVar1 = puVar9;
            }
            if ((puVar1 == param_1) && ((uVar4 & 1) == 0)) {
              puVar7[(int)puVar1 * 2] = puVar7[uVar4 * 2 + -2];
              puVar7[(int)puVar1 * 2 + 1] = puVar7[uVar4 * 2 + -1];
              puVar1 = (uint *)(uVar4 - 1);
            }
            while (((int)puVar6 < (int)puVar1 &&
                   (puVar9 = (uint *)((int)puVar1 + -1 >> 1), puVar7[(int)puVar9 * 2] < uStack_c)))
            {
              puVar7[(int)puVar1 * 2] = puVar7[(int)puVar9 * 2];
              puVar7[(int)puVar1 * 2 + 1] = puVar7[(int)puVar9 * 2 + 1];
              puVar1 = puVar9;
            }
            puVar7[(int)puVar1 * 2] = uStack_c;
            puVar7[(int)puVar1 * 2 + 1] = uStack_14;
            puVar5 = puVar5 + -2;
            puStack_10 = puVar6;
          } while (0 < (int)puVar6);
        }
        if ((int)uVar4 < 2) {
          return;
        }
        puVar6 = param_2 + -2;
        uStack_8 = uVar4;
        do {
          if (1 < (int)uVar4) {
            puStack_1c = (uint *)*puVar6;
            puStack_18 = (uint *)puVar6[1];
            *puVar6 = *puVar7;
            puVar6[1] = puVar7[1];
            FUN_006f83d0(puVar7,0,(int)puVar6 - (int)puVar7 >> 3,&puStack_1c,param_4);
          }
          puVar6 = puVar6 + -2;
          uVar4 = (int)puVar6 + (8 - (int)puVar7) >> 3;
        } while (1 < (int)uVar4);
        return;
      }
      goto LAB_006f84f7;
    }
    FUN_006f8180(&puStack_1c,puVar7,puVar6,param_4);
    iVar8 = (iVar8 >> 1) + (iVar8 >> 2);
    if ((int)((int)puStack_1c - (int)puVar7 & 0xfffffff8U) <
        (int)((int)puVar6 - (int)puStack_18 & 0xfffffff8U)) {
      FUN_006f8470(puVar7,puStack_1c,iVar8,param_4);
      puVar7 = puStack_18;
    }
    else {
      FUN_006f8470(puStack_18,puVar6,iVar8,param_4);
      param_2 = puStack_1c;
      puVar6 = puStack_1c;
    }
    iVar3 = (int)puVar6 - (int)puVar7;
  } while( true );
}



/* FUNCTION 9721 ; VA 0x006f86d0 ; FUN_006f86d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_006f86d0(int param_1,undefined4 *param_2,byte *param_3,int param_4)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  byte *pbVar9;
  byte *pbVar10;
  undefined4 *puVar11;
  bool bVar12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa918;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_005702d0(param_3);
  uVar8 = uVar3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar6 = (int *)0x0;
  }
  else {
    puVar11 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (puVar11 == (undefined4 *)0x0) {
      piVar6 = (int *)0x0;
    }
    else {
      piVar6 = (int *)*puVar11;
    }
    if (piVar6 == (int *)0x0) goto LAB_006f8800;
    do {
      if (uVar3 == piVar6[1]) {
        pbVar9 = (byte *)(piVar6 + 2);
        if (0xf < (uint)piVar6[7]) {
          pbVar9 = *(byte **)pbVar9;
        }
        uVar4 = *(uint *)(param_3 + 0x10);
        pbVar10 = param_3;
        if (0xf < *(uint *)(param_3 + 0x14)) {
          pbVar10 = *(byte **)param_3;
        }
        if (uVar4 == piVar6[6]) {
          while (uVar7 = uVar4 - 4, 3 < uVar4) {
            if (*(int *)pbVar10 != *(int *)pbVar9) goto LAB_006f878d;
            pbVar10 = pbVar10 + 4;
            pbVar9 = pbVar9 + 4;
            uVar4 = uVar7;
          }
          if (uVar7 == 0xfffffffc) {
LAB_006f87c1:
            uVar4 = 0;
          }
          else {
LAB_006f878d:
            bVar12 = *pbVar10 < *pbVar9;
            if ((*pbVar10 == *pbVar9) &&
               ((uVar7 == 0xfffffffd ||
                ((bVar12 = pbVar10[1] < pbVar9[1], pbVar10[1] == pbVar9[1] &&
                 ((uVar7 == 0xfffffffe ||
                  ((bVar12 = pbVar10[2] < pbVar9[2], pbVar10[2] == pbVar9[2] &&
                   ((uVar7 == 0xffffffff ||
                    (bVar12 = pbVar10[3] < pbVar9[3], pbVar10[3] == pbVar9[3]))))))))))))
            goto LAB_006f87c1;
            uVar4 = -(uint)bVar12 | 1;
          }
          if (uVar4 == 0) break;
        }
      }
      else if ((uint)piVar6[1] % *(uint *)(param_1 + 4) != uVar8) goto LAB_006f8800;
      piVar6 = (int *)*piVar6;
    } while (piVar6 != (int *)0x0);
  }
  if (piVar6 != (int *)0x0) {
    *param_2 = piVar6;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_006f8800:
  uStack_8 = 0;
  FUN_00619cd0();
  FUN_0054ef60(param_4);
  _DAT_00000020 = *(int *)(param_4 + 0x18);
  LOCK();
  *(int *)(_DAT_00000020 + 0x28) = *(int *)(_DAT_00000020 + 0x28) + 1;
  UNLOCK();
  uVar4 = *(uint *)(param_1 + 8);
  uVar8 = uVar4 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar8 = FUN_005c9310(uVar8);
    if (uVar8 <= *(uint *)(param_1 + 4)) {
      uVar8 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar8);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar8) {
    uVar7 = uVar4 >> 1;
    if (uVar4 + (uVar4 >> 1) <= uVar8) {
      uVar7 = 1;
    }
    iVar5 = FUN_005c9310(uVar7 + uVar4);
    if (iVar5 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar5);
      puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)*puVar11;
      while (puVar1 != (undefined4 *)0x0) {
        uVar8 = (uint)puVar1[1] % *(uint *)(param_1 + 4);
        piVar6 = (int *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar8 * 4) == 0) {
          *piVar6 = (int)puVar11;
          puVar11 = puVar1;
        }
        else {
          *puVar11 = *puVar1;
          *puVar1 = *(undefined4 *)*piVar6;
          *(undefined4 **)*piVar6 = puVar1;
        }
        puVar1 = (undefined4 *)*puVar11;
      }
    }
  }
  uVar8 = *(uint *)(param_1 + 4);
  iVar5 = *(int *)(param_1 + 0x14);
  puVar1 = *(undefined4 **)(iVar5 + (uVar3 % uVar8) * 4);
  puVar11 = (undefined4 *)(iVar5 + (uVar3 % uVar8) * 4);
  _DAT_00000004 = uVar3;
  if (puVar1 == (undefined4 *)0x0) {
    iVar2 = *(int *)(iVar5 + uVar8 * 4);
    puVar1 = (undefined4 *)(iVar5 + uVar8 * 4);
    if (iVar2 != 0) {
      *(undefined4 *)(iVar5 + (*(uint *)(iVar2 + 4) % uVar8) * 4) = 0;
    }
    *puVar11 = puVar1;
    _DAT_00000000 = *puVar1;
    *puVar1 = 0;
  }
  else {
    _DAT_00000000 = *puVar1;
    *(undefined4 *)*puVar11 = 0;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = 0;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9722 ; VA 0x006f8950 ; FUN_006f8950 */

uint * __thiscall FUN_006f8950(uint *param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x1fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar1 = param_2 * 8;
    if (uVar1 < 0x1000) {
      if (uVar1 == 0) {
        uVar2 = 0;
      }
      else {
        uVar2 = FUN_01674e20(uVar1);
      }
    }
    else {
      uVar2 = uVar1 + 0x23;
      if (uVar2 <= uVar1) {
        uVar2 = 0xffffffff;
      }
      iVar3 = FUN_01674e20(uVar2);
      if (iVar3 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar2 = iVar3 + 0x23U & 0xffffffe0;
      *(int *)(uVar2 - 4) = iVar3;
    }
    *param_1 = uVar2;
    param_1[1] = uVar2;
    param_1[2] = *param_1 + uVar1;
    puVar4 = (undefined4 *)*param_1;
    if (param_2 != 0) {
      do {
        *puVar4 = 0;
        puVar4[1] = 0;
        puVar4 = puVar4 + 2;
        param_2 = param_2 - 1;
      } while (param_2 != 0);
    }
    param_1[1] = (uint)puVar4;
  }
  return param_1;
}



/* FUNCTION 9723 ; VA 0x006f8a10 ; FUN_006f8a10 */

undefined4 * __thiscall FUN_006f8a10(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined **ppuVar3;
  undefined **ppuVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa938;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006b1a30(param_2);
  *param_1 = RBX::Network::Replicator::JoinDataItemV2::vftable;
  puVar1 = param_1 + 0x23;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  uStack_8 = 0;
  *puVar1 = 0;
  param_1[0x24] = 0;
  param_2 = puVar1;
  uVar2 = FUN_00575b50(0,0);
  *puVar1 = uVar2;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  *(undefined *)(param_1 + 0x27) = 0;
  param_2 = (undefined4 *)0xb;
  ppuVar3 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2);
  ppuVar4 = ppuVar3 + -1;
  if (ppuVar3 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar4 = ppuVar3;
  }
  param_1[0x28] = *ppuVar4;
  param_1[0x29] = 0;
  param_1[0x2a] = 0x3f800000;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9724 ; VA 0x006f8bd0 ; FUN_006f8bd0 */

void __fastcall FUN_006f8bd0(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = (int *)*param_1;
  piVar3 = (int *)*piVar2;
  *piVar2 = (int)piVar2;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar2 = (int *)*param_1;
  if (piVar3 != piVar2) {
    do {
      piVar1 = (int *)*piVar3;
      if ((undefined4 *)piVar3[2] != (undefined4 *)0x0) {
        (*(code *)**(undefined4 **)piVar3[2])(1);
      }
      FUN_01674ea0(piVar3,0xc);
      piVar2 = (int *)*param_1;
      piVar3 = piVar1;
    } while (piVar1 != piVar2);
  }
  FUN_01674ea0(piVar2,0xc);
  return;
}



/* FUNCTION 9725 ; VA 0x006f8c30 ; FUN_006f8c30 */

void __fastcall FUN_006f8c30(int param_1)

{
  if (*(int *)(param_1 + 4) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 4),0x20);
  }
  return;
}



/* FUNCTION 9726 ; VA 0x006f8c50 ; FUN_006f8c50 */

void __fastcall FUN_006f8c50(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar3;
        FUN_01674ea0(puVar3,0x20);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar3 = (undefined4 *)*puVar1;
      } while (puVar3 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 9727 ; VA 0x006f8cd0 ; FUN_006f8cd0 */

void __fastcall FUN_006f8cd0(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  char cVar8;
  undefined4 *puVar9;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Network::Replicator::JoinDataItemV2::vftable;
  puStack_14 = param_1;
  if (DAT_01d5bc08 != '\0') {
    FUN_0151f6f0(0xffffffff,0,0);
    FUN_0151fb00("JoinSnapShotTime",(double)*(float *)(param_1[4] + 0x3818));
    FUN_0151fa60("numOfPacketsSent",param_1[0x1c]);
    uVar4 = DAT_01eaf4c8;
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    FUN_005542c0("ReplicatorJoinDataItemV2Stats",0x1d);
    FUN_01520d20(auStack_38,uVar4,0);
    if (0xf < uStack_24) {
      uVar7 = uStack_24 + 1;
      uVar5 = auStack_38[0];
      if (0xfff < uVar7) {
        uVar5 = *(uint *)(auStack_38[0] - 4);
        uVar7 = uStack_24 + 0x24;
        if (0x1f < (auStack_38[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar7);
    }
    FUN_0151f7f0();
  }
  if (0 < DAT_01eaf4cc) {
    iStack_18 = param_1[0x18] + param_1[0x10];
    iVar1 = param_1[0xc];
    iVar2 = param_1[0x14];
    iStack_20 = param_1[0x1b] + param_1[0x13];
    iStack_1c = param_1[0xf];
    iVar3 = param_1[0x17];
    FUN_0151f6f0(0xffffffff,0,0);
    FUN_0151fa60("InstanceHits",((puStack_14[0x1d] - iVar1) - iVar2) - iStack_18);
    param_1 = puStack_14;
    FUN_0151fa60("InstanceTotal",puStack_14[0x1d] - iStack_18);
    FUN_0151fa60("BlobHits",((param_1[0x1c] - iVar3) - iStack_1c) - iStack_20);
    FUN_0151fa60("BlobTotal",param_1[0x1c] - iStack_20);
    iVar1 = DAT_01eaf4cc;
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    FUN_005542c0("ReplicatorJoinDataItemV2CacheEfficiency",0x27);
    FUN_01520d20(auStack_38,iVar1,0);
    if (0xf < uStack_24) {
      uVar7 = uStack_24 + 1;
      uVar5 = auStack_38[0];
      if (0xfff < uVar7) {
        uVar5 = *(uint *)(auStack_38[0] - 4);
        uVar7 = uStack_24 + 0x24;
        if (0x1f < (auStack_38[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar7);
    }
    FUN_0151f7f0();
  }
  if ((((DAT_01ee4213 != '\0') &&
       (FUN_01677520(DAT_01ee4213,
                     "~JoinDataItemV2 : Cache Update Stats (CacheableInstances) : %u instances added, %u blob(s) added, %u raw bytes added, %u compressed bytes added"
                     ,param_1[0xc],param_1[0xf],param_1[0xd],param_1[0xe]), DAT_01ee4213 != '\0'))
      && (FUN_01677520(DAT_01ee4213,
                       "~JoinDataItemV2 : Cache Update Stats (NotCacheableInstances) : %u instances added, %u blob(s) added, %u raw bytes added, %u compressed bytes added"
                       ,param_1[0x10],param_1[0x13],param_1[0x11],param_1[0x12]),
         DAT_01ee4213 != '\0')) &&
     ((FUN_01677520(DAT_01ee4213,
                    "~JoinDataItemV2 : Cache Update Stats (PartInstances) : %u instances added, %u blob(s) added, %u raw bytes added, %u compressed bytes added"
                    ,param_1[0x14],param_1[0x17],param_1[0x15],param_1[0x16]), DAT_01ee4213 != '\0'
      && (FUN_01677520(DAT_01ee4213,
                       "~JoinDataItemV2 : sharedStringsInstanceCounters : %u instances added, %u blob(s) added, %u raw bytes added, %u compressed bytes added, took %f ms"
                       ,param_1[0x18],param_1[0x1b],param_1[0x19],param_1[0x1a],
                       (double)(float)param_1[0x22]), DAT_01ee4213 != '\0')))) {
    FUN_01677520(DAT_01ee4213,
                 "~JoinDataItemV2 : Total Join Stats : %u instances, %u blob(s), %u total bytes, %u compressed bytes, %u uncompressed bytes, %u useful uncompressed bytes"
                 ,param_1[0x1d],param_1[0x1c],param_1[0x1e],param_1[0x1f],param_1[0x20],
                 param_1[0x21]);
  }
  if (DAT_01ee4214 != '\0') {
    FUN_01677520(DAT_01ee4214,
                 "InstanceTypePtr,InstanceTypeName,BlobType,Count,minSize,maxSize,avgSize");
    cVar8 = DAT_01ee4214;
    if (param_1[0x29] == 0) {
      puVar9 = (undefined4 *)0x0;
    }
    else {
      puVar9 = *(undefined4 **)(param_1[0x2c] + param_1[0x28] * 4);
    }
    for (; puVar9 != (undefined4 *)0x0; puVar9 = (undefined4 *)*puVar9) {
      if (cVar8 != '\0') {
        piVar6 = *(int **)(puVar9[2] + 4);
        if (0xf < (uint)piVar6[5]) {
          piVar6 = (int *)*piVar6;
        }
        FUN_01677520(cVar8,"%p,%s,%d,%d,%d,%d,%d",puVar9[2],piVar6,puVar9[3],puVar9[4],puVar9[5],
                     puVar9[6],(uint)puVar9[7] / (uint)puVar9[4]);
        cVar8 = DAT_01ee4214;
      }
      param_1 = puStack_14;
    }
  }
  FUN_00612dd0();
  FUN_006f8c50();
  FUN_006f8bd0();
  *param_1 = RBX::Network::Item::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9728 ; VA 0x006f9090 ; FUN_006f9090 */

uint * __thiscall FUN_006f9090(int param_1,uint *param_2)

{
  uint *puVar1;
  uint *puVar2;
  int *piVar3;
  undefined4 *puVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  undefined4 *puVar8;
  uint uVar9;
  int *piVar10;
  uint uVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aa958;
  pvStack_10 = ExceptionList;
  uVar7 = *param_2;
  uVar5 = (uVar7 >> 3) + uVar7;
  puVar1 = (uint *)(param_1 + 4);
  uVar11 = uVar5 % *puVar1;
  if (*(int *)(param_1 + 8) != 0) {
    puVar8 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar11 * 4);
    if (puVar8 == (undefined4 *)0x0) {
      puVar8 = (undefined4 *)0x0;
    }
    else {
      puVar8 = (undefined4 *)*puVar8;
    }
    for (; puVar8 != (undefined4 *)0x0; puVar8 = (undefined4 *)*puVar8) {
      if (uVar5 == puVar8[1]) {
        if (uVar7 == puVar8[2]) {
          if (puVar8 != (undefined4 *)0x0) {
            return puVar8 + 2;
          }
          break;
        }
      }
      else if ((uint)puVar8[1] % *puVar1 != uVar11) break;
    }
  }
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar6 = (int *)FUN_01674e20(0x20);
  puVar2 = (uint *)(piVar6 + 2);
  *piVar6 = 0;
  piVar6[1] = 0;
  *puVar2 = 0;
  piVar6[3] = 0;
  piVar6[4] = 0;
  piVar6[5] = 0;
  piVar6[6] = 0;
  piVar6[7] = 0;
  *puVar2 = uVar7;
  piVar6[3] = 0;
  piVar6[4] = 0;
  piVar6[5] = -1;
  piVar6[6] = 0;
  piVar6[7] = 0;
  uVar11 = *(uint *)(param_1 + 8);
  uVar7 = uVar11 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar7 = FUN_005c9310(uVar7);
    if (uVar7 <= *puVar1) {
      uVar7 = *puVar1;
    }
    FUN_005d2b00(uVar7);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    uVar9 = uVar11 >> 1;
    if (uVar11 + (uVar11 >> 1) <= uVar7) {
      uVar9 = 1;
    }
    uVar7 = FUN_005c9310(uVar9 + *(int *)(param_1 + 8));
    if (uVar7 != *puVar1) {
      FUN_005d2b00(uVar7);
      puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *puVar1 * 4);
      puVar4 = (undefined4 *)*puVar8;
      while (puVar4 != (undefined4 *)0x0) {
        piVar3 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *puVar1) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *puVar1) * 4) == 0) {
          *piVar3 = (int)puVar8;
          puVar8 = puVar4;
        }
        else {
          *puVar8 = *puVar4;
          *puVar4 = *(undefined4 *)*piVar3;
          *(undefined4 **)*piVar3 = puVar4;
        }
        puVar4 = (undefined4 *)*puVar8;
      }
    }
  }
  piVar6[1] = uVar5;
  uVar7 = *puVar1;
  piVar3 = (int *)(*(int *)(param_1 + 0x14) + (uVar5 % uVar7) * 4);
  if ((int *)*piVar3 == (int *)0x0) {
    piVar10 = (int *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (*piVar10 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar10 + 4) % uVar7) * 4) = piVar6;
    }
    *piVar3 = (int)piVar10;
    *piVar6 = *piVar10;
  }
  else {
    *piVar6 = *(int *)*piVar3;
    piVar10 = (int *)*piVar3;
  }
  *piVar10 = (int)piVar6;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return puVar2;
}



/* FUNCTION 9729 ; VA 0x006f92c0 ; FUN_006f92c0 */

undefined4 __thiscall FUN_006f92c0(undefined4 param_1,byte param_2)

{
  FUN_006f8cd0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,200);
  }
  return param_1;
}



/* FUNCTION 9730 ; VA 0x006f92f0 ; FUN_006f92f0 */

void __thiscall FUN_006f92f0(int param_1,int *param_2,undefined4 param_3)

{
  int *piVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  int iVar8;
  char cVar9;
  uint uVar10;
  uint uVar11;
  int *piVar12;
  undefined4 *puVar13;
  int *piVar14;
  int aiStack_80 [5];
  uint uStack_6c;
  uint auStack_68 [4];
  undefined4 uStack_58;
  uint uStack_54;
  int iStack_50;
  undefined4 *puStack_4c;
  undefined4 *puStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined auStack_34 [4];
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  uint uStack_24;
  uint uStack_20;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aa99f;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  uStack_20 = uStack_20 & 0xffffff00;
  piStack_30 = (int *)*param_2;
  piVar14 = (int *)*piStack_30;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (piVar14 != piStack_30) {
    do {
      uStack_8 = 0xffffffff;
      piStack_1c = piVar14 + 7;
      iVar4 = (**(code **)(piVar14[7] + 8))();
      param_2 = (int *)(iVar4 + 3);
      iVar4 = piVar14[0x13] - piVar14[0x12] >> 0x1f;
      if ((piVar14[0x13] - piVar14[0x12]) / 0x18 + iVar4 != iVar4) {
        param_2 = (int *)((int)param_2 + piVar14[5] * 0xc + 4);
      }
      piStack_2c = (int *)0x0;
      uStack_8 = 0;
      iStack_50 = FUN_01674e20(0x28);
      uStack_8._0_1_ = 1;
      if (iStack_50 == 0) {
        piStack_2c = (int *)0x0;
      }
      else {
        piStack_2c = (int *)FUN_006ab2f0(param_2);
      }
      uStack_8._0_1_ = 0;
      param_2._0_1_ = 0x83;
      piStack_18 = piStack_2c;
      FUN_006ad5e0(&param_2,1);
      FUN_006b2070(piStack_18,0x16);
      param_2 = (int *)CONCAT31(param_2._1_3_,(char)param_3);
      FUN_006ad5e0(&param_2,1);
      uVar5 = (**(code **)(*piStack_1c + 8))();
      uVar6 = (**(code **)(*piStack_1c + 4))();
      FUN_006ad5e0(uVar6,uVar5);
      iVar4 = iStack_14;
      if (DAT_01ee4215 != '\0') {
        param_2 = (int *)piVar14[5];
        uVar5 = (**(code **)(*piStack_1c + 8))();
        piStack_28 = (int *)piVar14[3];
        uVar6 = (**(code **)(*piStack_1c + 4))();
        iVar4 = iStack_14;
        FUN_01677520(DAT_01ee4215,
                     "ReplicationDataCache::Copying blob#%d [%p],  compressedStream=%p, numOfRawBytes=%d, numOfCompressedBytes=%d, numOfInstances=%d"
                     ,*(undefined4 *)(iStack_14 + 0x70),piVar14 + 2,uVar6,piStack_28,uVar5,param_2);
      }
      iVar8 = piVar14[0x13] - piVar14[0x12] >> 0x1f;
      if ((piVar14[0x13] - piVar14[0x12]) / 0x18 + iVar8 != iVar8) {
        param_2 = (int *)piVar14[5];
        FUN_006a5c10(&param_2,auStack_34,4);
        FUN_006ad5e0(auStack_34,4);
        if ((*(uint *)(*(int *)(iVar4 + 0x10) + 0x3808) & 8) != 0) {
          FUN_006ad4e0(piVar14[0x16] - piVar14[0x15] >> 3,piStack_18);
          if (DAT_01ee4215 != '\0') {
            FUN_016774b0(DAT_01ee4215,"ReplicationDataCache::Num invalidated cache in blob : %zu",
                         piVar14[0x16] - piVar14[0x15] >> 3);
          }
          piVar1 = piStack_18;
          param_2 = (int *)piVar14[0x16];
          piVar12 = (int *)piVar14[0x15];
          if (piVar12 != param_2) {
            do {
              if (DAT_01ee4215 != '\0') {
                FUN_01677490(DAT_01ee4215,
                             "ReplicationDataCache::Invalidated Instance : offset %u  length %u",
                             *piVar12,piVar12[1],0);
              }
              FUN_006ad4e0(*piVar12,piVar1);
              FUN_006ad4e0(piVar12[1],piVar1);
              piVar12 = piVar12 + 2;
            } while (piVar12 != param_2);
          }
        }
        puStack_48 = (undefined4 *)FUN_008aa870();
        if ((((DAT_01ee4214 != '\0') || ((*(uint *)(*(int *)(iStack_14 + 0x10) + 0x3808) & 8) == 0))
            || (cVar3 = FUN_0061ef20(), cVar3 == '\0')) || (DAT_01d5bc10 == '\0')) {
          puStack_4c = (undefined4 *)piVar14[0x13];
          puVar13 = (undefined4 *)piVar14[0x12];
          if (puVar13 != puStack_4c) {
            do {
              if (puVar13[2] != 0) {
                if (DAT_01ee4214 != '\0') {
                  param_2 = *(int **)(*(int *)(puVar13[2] + 4) + 0xc);
                  iVar4 = FUN_006f9090(&param_2);
                  *(undefined4 *)(iVar4 + 4) = param_3;
                  param_2 = *(int **)(*(int *)(puVar13[2] + 4) + 0xc);
                  iVar4 = FUN_006f9090(&param_2);
                  *(int *)(iVar4 + 8) = *(int *)(iVar4 + 8) + 1;
                  param_2 = *(int **)(*(int *)(puVar13[2] + 4) + 0xc);
                  iVar4 = FUN_006f9090(&param_2);
                  piStack_28 = (int *)puVar13[1];
                  if (*(uint *)(iVar4 + 0xc) <= (uint)puVar13[1]) {
                    piStack_28 = (int *)*(uint *)(iVar4 + 0xc);
                  }
                  param_2 = *(int **)(*(int *)(puVar13[2] + 4) + 0xc);
                  iVar4 = FUN_006f9090(&param_2);
                  *(int **)(iVar4 + 0xc) = piStack_28;
                  param_2 = *(int **)(*(int *)(puVar13[2] + 4) + 0xc);
                  iVar4 = FUN_006f9090(&param_2);
                  piStack_28 = (int *)puVar13[1];
                  if ((uint)puVar13[1] <= *(uint *)(iVar4 + 0x10)) {
                    piStack_28 = (int *)*(uint *)(iVar4 + 0x10);
                  }
                  param_2 = *(int **)(*(int *)(puVar13[2] + 4) + 0xc);
                  iVar4 = FUN_006f9090(&param_2);
                  *(int **)(iVar4 + 0x10) = piStack_28;
                  piStack_28 = (int *)puVar13[1];
                  param_2 = *(int **)(*(int *)(puVar13[2] + 4) + 0xc);
                  iVar4 = FUN_006f9090(&param_2);
                  *(int *)(iVar4 + 0x14) = *(int *)(iVar4 + 0x14) + (int)piStack_28;
                }
                if (DAT_01ee4215 != '\0') {
                  uStack_38 = *(undefined4 *)(iStack_14 + 0x70);
                  uStack_3c = puVar13[3];
                  uStack_40 = puVar13[4];
                  uStack_44 = *puVar13;
                  param_2 = (int *)FUN_009c9510(aiStack_80);
                  uStack_8._0_1_ = 2;
                  if (0xf < (uint)param_2[5]) {
                    param_2 = (int *)*param_2;
                  }
                  piStack_28 = *(int **)(*(int *)(*(int *)(puVar13[2] + 4) + 0xc) + 4);
                  if (0xf < (uint)piStack_28[5]) {
                    piStack_28 = (int *)*piStack_28;
                  }
                  puVar7 = (undefined4 *)FUN_008a2380(auStack_68);
                  uStack_8._0_1_ = 3;
                  if (0xf < (uint)puVar7[5]) {
                    puVar7 = (undefined4 *)*puVar7;
                  }
                  FUN_01677520(DAT_01ee4215,
                               "Pushing instance %s[type=%s][guid=%s] with metaDataOffset=%d, indexInParent=%d, numOfChildren=%d into blobIndex=%d"
                               ,puVar7,piStack_28,param_2,uStack_44,uStack_40,uStack_3c,uStack_38);
                  uStack_8._0_1_ = 2;
                  uVar2 = (undefined)uStack_8;
                  uStack_8._0_1_ = 2;
                  if (0xf < uStack_54) {
                    uVar10 = uStack_54 + 1;
                    uVar11 = auStack_68[0];
                    if (0xfff < uVar10) {
                      uVar11 = *(uint *)(auStack_68[0] - 4);
                      uVar10 = uStack_54 + 0x24;
                      if (0x1f < (auStack_68[0] - uVar11) - 4) goto LAB_006f9971;
                    }
                    FUN_01674ea0(uVar11,uVar10);
                  }
                  uStack_58 = 0;
                  uStack_54 = 0xf;
                  auStack_68[0] = auStack_68[0] & 0xffffff00;
                  uStack_8._0_1_ = 0;
                  if (0xf < uStack_6c) {
                    uVar11 = uStack_6c + 1;
                    iVar4 = aiStack_80[0];
                    if (0xfff < uVar11) {
                      iVar4 = *(int *)(aiStack_80[0] + -4);
                      uVar11 = uStack_6c + 0x24;
                      uVar2 = (undefined)uStack_8;
                      if (0x1f < (aiStack_80[0] - iVar4) - 4U) {
LAB_006f9971:
                        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
                        FUN_017167a3();
                      }
                    }
                    FUN_01674ea0(iVar4,uVar11);
                  }
                }
                if ((*(uint *)(*(int *)(iStack_14 + 0x10) + 0x3808) & 8) == 0) {
                  FUN_006ad4e0(*puVar13,piStack_18);
                }
                cVar3 = FUN_0061ef20();
                if (cVar3 == '\0') {
                  FUN_006ad4e0(puVar13[3],piStack_18);
                  FUN_006ad4e0(puVar13[4],piStack_18);
                }
                if (DAT_01d5bc10 == '\0') {
                  cVar3 = FUN_00620fb0(*(undefined4 *)(puVar13[2] + 4));
                  uStack_24 = uStack_24 & 0xff;
                  if (cVar3 != '\0') {
                    uStack_24 = 1;
                  }
                  puVar7 = (undefined4 *)thunk_FUN_00897b90();
                  uStack_20 = uStack_20 & 0xff;
                  if (puVar7 == puStack_48) {
                    uStack_20 = 1;
                  }
                }
              }
              puVar13 = puVar13 + 6;
            } while (puVar13 != puStack_4c);
          }
        }
      }
      iVar4 = iStack_14;
      *(int *)(iStack_14 + 0x74) = *(int *)(iStack_14 + 0x74) + piVar14[5];
      iVar8 = (**(code **)(*piStack_1c + 8))();
      *(int *)(iVar4 + 0x7c) = *(int *)(iVar4 + 0x7c) + iVar8;
      *(int *)(iVar4 + 0x80) = *(int *)(iVar4 + 0x80) + piVar14[4];
      *(int *)(iVar4 + 0x84) = *(int *)(iVar4 + 0x84) + piVar14[3];
      iVar8 = (**(code **)(*piStack_18 + 8))();
      *(int *)(iVar4 + 0x70) = *(int *)(iVar4 + 0x70) + 1;
      *(int *)(iVar4 + 0x78) = iVar8 + *(int *)(iVar4 + 0x78);
      if (DAT_01d5bc10 == '\0') {
        cVar3 = (char)uStack_20;
        cVar9 = (char)uStack_24;
      }
      else {
        cVar3 = *(char *)((int)piVar14 + 0x19);
        cVar9 = *(char *)(piVar14 + 6);
      }
      piStack_2c = (int *)0x0;
      param_2 = piStack_18;
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      *(undefined *)(piStack_18 + 1) = 1;
      if (cVar9 != '\0') {
        *(undefined4 *)(iVar4 + 0x94) = *(undefined4 *)(iVar4 + 0x90);
      }
      if (cVar3 != '\0') {
        *(undefined4 *)(iVar4 + 0x98) = *(undefined4 *)(iVar4 + 0x90);
      }
      puStack_4c = *(undefined4 **)(iVar4 + 0x8c);
      puStack_48 = (undefined4 *)puStack_4c[1];
      uVar5 = FUN_006f8100(puStack_4c,puStack_48,&param_2);
      piVar12 = piStack_30;
      if (*(int *)(iVar4 + 0x90) == 0x15555554) {
                    /* WARNING: Subroutine does not return */
        FUN_016ddcd9("list<T> too long");
      }
      *(int *)(iVar4 + 0x90) = *(int *)(iVar4 + 0x90) + 1;
      puStack_4c[1] = uVar5;
      *puStack_48 = uVar5;
      if (param_2 != (int *)0x0) {
        (**(code **)*param_2)(1);
      }
      piVar14 = (int *)*piVar14;
    } while (piVar14 != piVar12);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9731 ; VA 0x006f9980 ; FUN_006f9980 */

int * __thiscall FUN_006f9980(int param_1,int *param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aa9c9;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01ee4215 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ee4215,"JoinDataItemV2::getReadyBitStream: readyBitstreamList size: %d",
                 *(undefined4 *)(param_1 + 0x90));
  }
  *param_2 = 0;
  uStack_8 = 0;
  uStack_14 = 1;
  if (*(uint *)(param_1 + 0xc0) < (uint)(*(int *)(param_1 + 0xb8) - *(int *)(param_1 + 0xb4) >> 2))
  {
    if (DAT_01ee4215 != '\0') {
      FUN_016774b0(DAT_01ee4215,
                   "ReplicationDataCache::generateDataBlobs : serializing and creating blob for sharedStrings"
                   ,0);
    }
    piVar2 = (int *)FUN_006fa900(&puStack_18);
    if (param_2 != piVar2) {
      iVar3 = *piVar2;
      *piVar2 = 0;
      puVar1 = (undefined4 *)*param_2;
      *param_2 = iVar3;
      if (puVar1 != (undefined4 *)0x0) {
        (**(code **)*puVar1)(1);
      }
    }
    if (puStack_18 != (undefined4 *)0x0) {
      (**(code **)*puStack_18)(1);
    }
  }
  if (*param_2 != 0) {
    *(int *)(param_1 + 0x6c) = *(int *)(param_1 + 0x6c) + 1;
    ExceptionList = pvStack_10;
    return param_2;
  }
  if (*(int *)(param_1 + 0x90) != 0) {
    piVar2 = (int *)(**(int **)(param_1 + 0x8c) + 8);
    if (param_2 != piVar2) {
      iVar3 = *piVar2;
      *piVar2 = 0;
      puVar1 = (undefined4 *)*param_2;
      *param_2 = iVar3;
      if (puVar1 != (undefined4 *)0x0) {
        (**(code **)*puVar1)(1);
      }
    }
    piVar2 = (int *)**(int **)(param_1 + 0x8c);
    *(int *)piVar2[1] = *piVar2;
    *(int *)(*piVar2 + 4) = piVar2[1];
    *(int *)(param_1 + 0x90) = *(int *)(param_1 + 0x90) + -1;
    if ((undefined4 *)piVar2[2] != (undefined4 *)0x0) {
      (*(code *)**(undefined4 **)piVar2[2])(1);
    }
    FUN_01674ea0(piVar2,0xc);
    iVar3 = *(int *)(param_1 + 0x94);
    if ((iVar3 == 0) && (*(int *)(param_1 + 0x98) == 0)) {
      *(undefined *)(*(int *)(param_1 + 0x10) + 0x3802) = 1;
      iVar3 = *(int *)(param_1 + 0x94);
    }
    if (*(int *)(param_1 + 0x98) != 0) {
      *(int *)(param_1 + 0x98) = *(int *)(param_1 + 0x98) + -1;
    }
    if (iVar3 != 0) {
      *(int *)(param_1 + 0x94) = iVar3 + -1;
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9732 ; VA 0x006f9b30 ; FUN_006f9b30 */

bool __fastcall FUN_006f9b30(int param_1)

{
  return *(int *)(param_1 + 0x90) != 0;
}



/* FUNCTION 9733 ; VA 0x006f9b40 ; FUN_006f9b40 */

void FUN_006f9b40(undefined4 *param_1,int param_2,undefined4 param_3)

{
  undefined uVar1;
  uint uVar2;
  undefined4 uVar3;
  double *pdVar4;
  int iVar5;
  uint uVar6;
  undefined auStack_6c [12];
  int iStack_60;
  int iStack_58;
  int iStack_54;
  int iStack_4c;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  double dStack_2c;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined auStack_1c [4];
  int iStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aaa0f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016827e0(&dStack_2c);
  if (DAT_01ee4215 != '\0') {
    FUN_016774b0(DAT_01ee4215,"Parsing JoinDataItemV2",0);
  }
  uVar2 = FUN_006abe40();
  iVar5 = DAT_01eaf508;
  if (DAT_01ee4215 != '\0') {
    DAT_01eaf508 = DAT_01eaf508 + 1;
    FUN_016774b0(DAT_01ee4215,"Parsing blobIndex=%d",iVar5);
  }
  iStack_18 = FUN_01674e20(0x1c);
  uStack_8 = 0;
  if (iStack_18 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00723fd0(0x16);
  }
  uStack_8 = 0xffffffff;
  uStack_24 = 0;
  uStack_20 = 0;
  FUN_006c2a50(uVar3,iStack_18);
  uStack_8 = 1;
  if ((uVar2 & 0xff) == 1) {
    FUN_006ab530();
    uStack_8._0_1_ = 2;
    FUN_0061a740(param_3,auStack_6c);
    uStack_11 = 0;
    FUN_00565660(0x10,0);
    uStack_8._0_1_ = 3;
    if (iStack_54 != iStack_4c) {
      do {
        FUN_00a33c70();
        uStack_8._0_1_ = 4;
        FUN_00626870(auStack_6c,&iStack_18,auStack_44,&uStack_11);
        uStack_8._0_1_ = 3;
        FUN_0056cd30();
      } while (iStack_54 != iStack_4c);
    }
    uStack_8._0_1_ = 2;
    uVar1 = (undefined)uStack_8;
    uStack_8._0_1_ = 2;
    if (0xf < uStack_30) {
      uVar6 = uStack_30 + 1;
      uVar2 = auStack_44[0];
      if (0xfff < uVar6) {
        uVar2 = *(uint *)(auStack_44[0] - 4);
        uVar6 = uStack_30 + 0x24;
        if (0x1f < (auStack_44[0] - uVar2) - 4) {
          uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar2,uVar6);
    }
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = auStack_44[0] & 0xffffff00;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (iStack_60 != 0) {
      uVar2 = iStack_58 - iStack_60;
      iVar5 = iStack_60;
      if (0xfff < uVar2) {
        iVar5 = *(int *)(iStack_60 + -4);
        uVar2 = uVar2 + 0x23;
        if (0x1f < (iStack_60 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar2);
    }
  }
  else if ((uVar2 & 0xff) - 2 < 3) {
    FUN_006fa190(param_2,param_3,&uStack_24);
  }
  if (DAT_01eace54 != 0) {
    pdVar4 = (double *)FUN_016827e0(auStack_1c);
    *(float *)(param_2 + 0x3828) =
         (float)((*pdVar4 - dStack_2c) * DAT_018c0d70) + *(float *)(param_2 + 0x3828);
  }
  *param_1 = uStack_24;
  param_1[1] = uStack_20;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9734 ; VA 0x006f9d80 ; FUN_006f9d80 */

undefined4 FUN_006f9d80(int param_1,int param_2,undefined4 *param_3)

{
  int iVar1;
  int iVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined **ppuVar6;
  int *piVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined **ppuVar11;
  undefined auStack_7c [12];
  undefined auStack_70 [24];
  undefined auStack_58 [4];
  undefined *puStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined auStack_40 [8];
  undefined auStack_38 [8];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aaa58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01ee4215 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ee4215,"Begin reading join instance offset=%X bytes",
                 *(undefined4 *)(param_2 + 0x20));
  }
  puVar4 = (undefined4 *)FUN_006b8fd0(&uStack_28,param_2);
  iVar2 = (int)param_3;
  *(undefined4 *)((int)param_3 + 0x1c) = *puVar4;
  *(undefined4 *)((int)param_3 + 0x20) = puVar4[1];
  param_3 = (undefined4 *)((int)param_3 + 0x1c);
  cVar3 = FUN_006abe60(&uStack_14,2);
  if (cVar3 == '\0') {
    FUN_0054eff0("readFast past end for uint16_t");
    uStack_8 = 0;
    FUN_005f8ef0(auStack_58);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_7c,&DAT_01c27108);
  }
  uStack_14 = (uint)(ushort)((ushort)uStack_14 << 8 | (ushort)uStack_14 >> 8);
  iStack_20 = *(int *)(*(int *)(param_1 + 0x19f4) + 0x58);
  if (((uint)((*(int *)(*(int *)(param_1 + 0x19f4) + 0x5c) - iStack_20) / 0x3c) <= uStack_14) ||
     (iStack_20 = iStack_20 + uStack_14 * 0x3c, iStack_20 == 0)) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Join data contained invalid class network id");
  }
  *(int *)(iVar2 + 0x2c) = iStack_20;
  iStack_18 = *(int *)(iStack_20 + 8);
  cVar3 = FUN_00621ac0(iVar2 + 0x1c,(int *)(iVar2 + 0x38));
  if (cVar3 == '\0') {
    if (iStack_18 != 0) {
      puVar4 = (undefined4 *)FUN_00892e40(*(undefined4 *)(iStack_18 + 4));
      if (puVar4 == (undefined4 *)0x0) {
        uStack_1c = 0;
        iStack_18 = 0;
      }
      else {
        puVar4 = (undefined4 *)(**(code **)*puVar4)(&uStack_28,0);
        iStack_18 = puVar4[1];
        uStack_1c = *puVar4;
        if (iStack_18 != 0) {
          LOCK();
          *(int *)(iStack_18 + 4) = *(int *)(iStack_18 + 4) + 1;
          UNLOCK();
          iStack_18 = puVar4[1];
        }
        if (piStack_24 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_24[1] + -1;
          piStack_24[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_24)();
            LOCK();
            iVar1 = piStack_24[2] + -1;
            piStack_24[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piStack_24 + 4))();
            }
          }
        }
      }
      FUN_005587e0(&uStack_1c);
      FUN_00550b30();
      if (*(int *)(iVar2 + 0x38) == 0) {
        uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Replication: Can\'t create object of type %s",uVar5);
      }
      FUN_006188a0(*(int *)(iVar2 + 0x38),iVar2 + 0x1c);
      *(undefined *)(iVar2 + 0x48) = 1;
    }
  }
  else {
    iVar1 = *(int *)(iVar2 + 0x38);
    if (iVar1 == 0) {
      FUN_009c93d0(auStack_58,0x20);
      uStack_8 = 1;
      uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("read join instance got a null object (guid %s)",uVar5);
    }
    if (*(int *)(iVar1 + 0xc) != *(int *)(iStack_20 + 8)) {
      FUN_009c93d0(auStack_58,4);
      uStack_8 = 2;
      iStack_20 = FUN_005543f0();
      piVar7 = (int *)FUN_0054db20();
      (**(code **)(*piVar7 + 0x10))();
      uVar5 = FUN_005543f0();
      FUN_006b1620(auStack_38,param_1 + 0x74,1,0x7c);
      uStack_8._0_1_ = 3;
      uVar8 = FUN_005543f0();
      FUN_009c93d0(auStack_70,4);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      uVar9 = FUN_005543f0();
      uVar10 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Replication: Bad re-binding in deserialize new instance %s-%s << %s, %s-%s",
                   uVar10,uVar9,uVar8,uVar5,iStack_20);
    }
  }
  uVar5 = DAT_01eadc98;
  if (((*(char *)(iVar2 + 0x48) != '\0') && (*(int *)(iVar2 + 0x38) != 0)) &&
     (puVar4 = *(undefined4 **)(*(int *)(*(int *)(iVar2 + 0x38) + 0xc) + 0x1dc),
     uVar5 = DAT_01edf5b0, puVar4 != (undefined4 *)0x0)) {
    uVar5 = *puVar4;
  }
  uVar5 = FUN_01675290(uVar5);
  uStack_8 = 5;
  auStack_58[0] = 0;
  param_3 = (undefined4 *)0xb;
  iStack_18 = uVar5;
  ppuVar6 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_3);
  ppuVar11 = ppuVar6 + -1;
  if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar11 = ppuVar6;
  }
  puStack_54 = *ppuVar11;
  uStack_50 = 0;
  uStack_4c = 0x3f800000;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_28 = 0;
  piStack_24 = (int *)0x0;
  FUN_006c1890(param_1,param_2,0,0,auStack_58,&uStack_30);
  FUN_006bf690();
  uStack_8 = 7;
  FUN_01675290(uVar5);
  uStack_8 = 0xffffffff;
  puVar4 = (undefined4 *)FUN_006b8fd0(auStack_40,param_2);
  *(undefined4 *)(iVar2 + 0x24) = *puVar4;
  *(undefined4 *)(iVar2 + 0x28) = puVar4[1];
  if (*(int *)(iStack_20 + 8) == 0) {
    if (DAT_01ee4215 != '\0') {
      FUN_016774b0(DAT_01ee4215,
                   "Discarding join instance due to null local descriptor (schema diff)",0);
    }
    ExceptionList = pvStack_10;
    return 0;
  }
  FUN_00621ac0((undefined4 *)(iVar2 + 0x24),iVar2 + 0x40);
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 9735 ; VA 0x006fa190 ; FUN_006fa190 */

void FUN_006fa190(int param_1,int param_2,int *param_3)

{
  uint *puVar1;
  undefined4 uVar2;
  char cVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puVar6;
  uint *puVar7;
  int iVar8;
  int iVar9;
  undefined auStack_9c [36];
  int aiStack_78 [5];
  uint uStack_64;
  undefined auStack_60 [12];
  int iStack_54;
  int iStack_4c;
  uint uStack_48;
  uint uStack_40;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  undefined uStack_25;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017aaaa0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006ab530();
  iStack_8 = 0;
  FUN_0061a740(param_2,auStack_60);
  uVar4 = FUN_006ace40();
  if (DAT_01eace54 != 0) {
    *(int *)(param_1 + 0x3838) = *(int *)(param_1 + 0x3838) + 4;
  }
  uStack_1c = uVar4;
  if (DAT_01ee4215 != '\0') {
    FUN_016774b0(DAT_01ee4215,"Expecting %d instances",uVar4);
  }
  FUN_006c2720(uVar4,*param_3 + 0x10);
  if ((*(uint *)(param_1 + 0x3808) & 8) == 0) {
    uVar4 = 0;
    uStack_14 = 0;
    if (uStack_1c != 0) {
      iVar9 = 0;
      do {
        uStack_24 = *(uint *)(param_2 + 0x20);
        FUN_006abc60(&uStack_14,param_2);
        if ((DAT_01d5bc18 != '\0') && (uStack_48 < uStack_14)) {
          FUN_0054eff0("Offset index of JDIv2 larger than bitstream length");
          iStack_8 = CONCAT31(iStack_8._1_3_,4);
          FUN_005f8ef0(aiStack_78);
                    /* WARNING: Subroutine does not return */
          FUN_0170c2a8(auStack_9c,&DAT_01c27108);
        }
        cVar3 = FUN_0061ef20();
        if (cVar3 == '\0') {
          FUN_006abc60(*(int *)(*param_3 + 0x10) + 0x30 + iVar9,param_2);
          FUN_006abc60(*(int *)(*param_3 + 0x10) + 0x34 + iVar9,param_2);
        }
        if (DAT_01eace54 != 0) {
          *(uint *)(param_1 + 0x3838) =
               *(int *)(param_1 + 0x3838) + (*(int *)(param_2 + 0x20) - uStack_24);
          *(uint *)(param_1 + 0x383c) =
               *(int *)(param_1 + 0x383c) + (uStack_14 - *(int *)(param_2 + 0x20));
        }
        if (DAT_01ee4215 != '\0') {
          FUN_016774b0(DAT_01ee4215,"Expect instance @ offset=%d",uStack_14);
        }
        FUN_006ab690(uStack_14);
        FUN_006f9d80(param_1,auStack_60,*(int *)(*param_3 + 0x10) + iVar9);
        if (DAT_01ee4215 != '\0') {
          uStack_24 = *(uint *)(*(int *)(*param_3 + 0x10) + 0x34 + iVar9);
          uStack_2c = *(undefined4 *)(*(int *)(*param_3 + 0x10) + 0x30 + iVar9);
          uStack_20 = uStack_40;
          puVar6 = (undefined4 *)FUN_009c93d0(aiStack_78,4);
          iStack_8._0_1_ = 5;
          if (0xf < (uint)puVar6[5]) {
            puVar6 = (undefined4 *)*puVar6;
          }
          FUN_016773b0(DAT_01ee4215,
                       "Done reading join instance %s offset=%X bytes with numOfChildren=%d, indexInParent=%d"
                       ,puVar6,uStack_20,uStack_2c,uStack_24,0);
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          if (0xf < uStack_64) {
            uVar5 = uStack_64 + 1;
            iVar8 = aiStack_78[0];
            if (0xfff < uVar5) {
              iVar8 = *(int *)(aiStack_78[0] + -4);
              uVar5 = uStack_64 + 0x24;
              if (0x1f < (aiStack_78[0] - iVar8) - 4U) goto LAB_006fa7a7;
            }
            FUN_01674ea0(iVar8,uVar5);
          }
        }
        uVar4 = uVar4 + 1;
        iVar9 = iVar9 + 0x58;
      } while (uVar4 < uStack_1c);
    }
    if (DAT_01eace54 != 0) {
      *(uint *)(param_1 + 0x383c) = uStack_48 - uStack_40;
    }
  }
  else {
    uStack_20 = *(int *)(param_2 + 0x20);
    uStack_18 = 0;
    FUN_006abc60(&uStack_18,param_2);
    FUN_006f8950(uStack_18,&uStack_25);
    iStack_8 = CONCAT31(iStack_8._1_3_,1);
    if (DAT_01ee4215 != '\0') {
      FUN_016774b0(DAT_01ee4215,"Expecting #%d invalid metaData in this blob",uStack_18);
    }
    iVar9 = iStack_38;
    if (uStack_18 != 0) {
      uStack_14 = 0;
      puVar7 = (uint *)(iStack_38 + 4);
      do {
        puVar1 = puVar7 + -1;
        FUN_006abc60(puVar1,param_2);
        FUN_006abc60(puVar7,param_2);
        if (DAT_01ee4215 != '\0') {
          FUN_01677490(DAT_01ee4215,"Invalid offset %d  length %d",*puVar1,*puVar7,0);
        }
        iVar9 = iStack_38;
        if (DAT_01eace54 != 0) {
          *(int *)(param_1 + 0x383c) = *(int *)(param_1 + 0x383c) + *puVar7;
        }
        if ((DAT_01d5bc18 != '\0') &&
           (((uStack_48 < *puVar1 || (uStack_48 < *puVar7)) || (uStack_48 < *puVar7 + *puVar1)))) {
          FUN_0054eff0("Offset index of JDIv2 larger than bitstream length");
          iStack_8 = CONCAT31(iStack_8._1_3_,2);
          FUN_005f8ef0(aiStack_78);
                    /* WARNING: Subroutine does not return */
          FUN_0170c2a8(auStack_9c,&DAT_01c27108);
        }
        puVar7 = puVar7 + 2;
        uStack_14 = uStack_14 + 1;
      } while (uStack_14 < uStack_18);
      FUN_006f8470(iStack_38,iStack_34,iStack_34 - iStack_38 >> 3,param_1);
    }
    cVar3 = FUN_0061ef20();
    if ((cVar3 == '\0') && (uStack_1c != 0)) {
      iVar8 = 0;
      uVar4 = uStack_1c;
      do {
        FUN_006abc60(*(int *)(*param_3 + 0x10) + 0x30 + iVar8,param_2);
        FUN_006abc60(*(int *)(*param_3 + 0x10) + 0x34 + iVar8,param_2);
        iVar8 = iVar8 + 0x58;
        uVar4 = uVar4 - 1;
        iVar9 = iStack_38;
      } while (uVar4 != 0);
    }
    if (DAT_01eace54 != 0) {
      *(uint *)(param_1 + 0x3838) =
           *(int *)(param_1 + 0x3838) + (*(int *)(param_2 + 0x20) - uStack_20);
    }
    uVar4 = 0;
    uStack_20 = 0;
    if (uStack_1c != 0) {
      uStack_14 = 0;
      do {
        if (uVar4 < uStack_18) {
          puVar6 = (undefined4 *)(uVar4 * 8 + 4 + iVar9);
          do {
            if (uStack_40 != puVar6[-1]) break;
            if (DAT_01ee4215 != '\0') {
              FUN_01677490(DAT_01ee4215,"Skipping offset %u  length : %u",puVar6[-1],*puVar6,0);
            }
            FUN_006ab660(*puVar6);
            uVar4 = uVar4 + 1;
            puVar6 = puVar6 + 2;
            if (uVar4 < (uint)(iStack_34 - iVar9 >> 3)) {
              if (DAT_01ee4215 != '\0') {
                FUN_01677490(DAT_01ee4215,
                             "Next anticipated read at offset %d  (unless invalid),  next invalid offset : %u"
                             ,uStack_40,*puVar6,0);
              }
            }
            else if (DAT_01ee4215 != '\0') {
              FUN_016774b0(DAT_01ee4215,"No more invalid caches in blob",0);
            }
          } while (uVar4 < uStack_18);
        }
        if (DAT_01ee4215 != '\0') {
          FUN_016774b0(DAT_01ee4215,"Reading instance @ offset=%d",uStack_40);
        }
        FUN_006f9d80(param_1,auStack_60,*(int *)(*param_3 + 0x10) + uStack_14);
        if (DAT_01ee4215 != '\0') {
          uStack_2c = *(undefined4 *)(uStack_14 + 0x30 + *(int *)(*param_3 + 0x10));
          uVar2 = *(undefined4 *)(uStack_14 + 0x34 + *(int *)(*param_3 + 0x10));
          uStack_24 = uStack_40;
          puVar6 = (undefined4 *)FUN_009c93d0(aiStack_78,4);
          iStack_8._0_1_ = 3;
          if (0xf < (uint)puVar6[5]) {
            puVar6 = (undefined4 *)*puVar6;
          }
          FUN_016773b0(DAT_01ee4215,
                       "Done reading join instance %s offset=%X bytes with numOfChildren=%d, indexInParent=%d"
                       ,puVar6,uStack_24,uStack_2c,uVar2,0);
          iStack_8 = CONCAT31(iStack_8._1_3_,1);
          if (0xf < uStack_64) {
            uVar5 = uStack_64 + 1;
            iVar8 = aiStack_78[0];
            if (0xfff < uVar5) {
              iVar8 = *(int *)(aiStack_78[0] + -4);
              uVar5 = uStack_64 + 0x24;
              if (0x1f < (aiStack_78[0] - iVar8) - 4U) goto LAB_006fa7a7;
            }
            FUN_01674ea0(iVar8,uVar5);
          }
        }
        uStack_14 = uStack_14 + 0x58;
        uStack_20 = uStack_20 + 1;
      } while (uStack_20 < uStack_1c);
    }
    if (iVar9 != 0) {
      uVar4 = iStack_30 - iVar9 & 0xfffffff8;
      iVar8 = iVar9;
      if (0xfff < uVar4) {
        iVar8 = *(int *)(iVar9 + -4);
        uVar4 = uVar4 + 0x23;
        if (0x1f < (iVar9 - iVar8) - 4U) {
LAB_006fa7a7:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar8,uVar4);
    }
  }
  if (iStack_54 != 0) {
    uVar4 = iStack_4c - iStack_54;
    iVar9 = iStack_54;
    if (0xfff < uVar4) {
      iVar9 = *(int *)(iStack_54 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iStack_54 - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar9,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9736 ; VA 0x006fa7f0 ; FUN_006fa7f0 */

void __thiscall FUN_006fa7f0(int param_1,undefined4 param_2,int param_3,undefined4 param_4)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined4 uVar5;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aaab8;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  piStack_18 = (int *)FUN_006c8d20(0,0);
  uStack_8 = 0;
  FUN_006c9e80(param_2,&piStack_18,param_1 + 0xb4,param_4);
  uVar3 = *(undefined4 *)(param_3 + 0xd8);
  uVar5 = *(undefined4 *)(param_3 + 0xdc);
  uVar2 = *(undefined4 *)(param_3 + 0xe0);
  *(undefined4 *)(param_1 + 0x30) = *(undefined4 *)(param_3 + 0xd4);
  *(undefined4 *)(param_1 + 0x34) = uVar3;
  *(undefined4 *)(param_1 + 0x38) = uVar5;
  *(undefined4 *)(param_1 + 0x3c) = uVar2;
  uVar3 = *(undefined4 *)(param_3 + 0xe8);
  uVar5 = *(undefined4 *)(param_3 + 0xec);
  uVar2 = *(undefined4 *)(param_3 + 0xf0);
  *(undefined4 *)(param_1 + 0x40) = *(undefined4 *)(param_3 + 0xe4);
  *(undefined4 *)(param_1 + 0x44) = uVar3;
  *(undefined4 *)(param_1 + 0x48) = uVar5;
  *(undefined4 *)(param_1 + 0x4c) = uVar2;
  uVar3 = *(undefined4 *)(param_3 + 0xf8);
  uVar5 = *(undefined4 *)(param_3 + 0xfc);
  uVar2 = *(undefined4 *)(param_3 + 0x100);
  *(undefined4 *)(param_1 + 0x50) = *(undefined4 *)(param_3 + 0xf4);
  *(undefined4 *)(param_1 + 0x54) = uVar3;
  *(undefined4 *)(param_1 + 0x58) = uVar5;
  *(undefined4 *)(param_1 + 0x5c) = uVar2;
  FUN_006f92f0(&piStack_18,3);
  uVar5 = 2;
  uVar3 = FUN_006cb060(2);
  FUN_006f92f0(uVar3,uVar5);
  uVar5 = 4;
  uVar3 = FUN_006cb070(4);
  FUN_006f92f0(uVar3,uVar5);
  piVar4 = (int *)*piStack_18;
  *piStack_18 = (int)piStack_18;
  piStack_18[1] = (int)piStack_18;
  uStack_14 = 0;
  if (piVar4 != piStack_18) {
    do {
      piVar1 = (int *)*piVar4;
      (**(code **)(piVar4[2] + 0x14))(0);
      FUN_01674ea0(piVar4,0x60);
      piVar4 = piVar1;
    } while (piVar1 != piStack_18);
  }
  FUN_01674ea0(piStack_18,0x60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9737 ; VA 0x006fa900 ; FUN_006fa900 */

int * __thiscall FUN_006fa900(int param_1,int *param_2)

{
  int iVar1;
  double *pdVar2;
  undefined4 *puVar3;
  uint uVar4;
  int *piVar5;
  undefined auStack_98 [4];
  char cStack_94;
  undefined auStack_90 [8];
  double dStack_88;
  uint uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  uint uStack_6c;
  int iStack_68;
  uint uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined8 uStack_54;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  int *piStack_3c;
  undefined4 *puStack_38;
  undefined4 uStack_28;
  uint uStack_24;
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017aab27;
  pvStack_10 = ExceptionList;
  piVar5 = (int *)0x0;
  iStack_18 = 0;
  piStack_3c = (int *)0x0;
  uStack_8 = 1;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  uStack_20 = 1;
  iStack_44 = param_1;
  FUN_016827e0();
  if (*(uint *)(param_1 + 0xc0) < (uint)(*(int *)(param_1 + 0xb8) - *(int *)(param_1 + 0xb4) >> 2))
  {
    do {
      if (piVar5 == (int *)0x0) {
        iStack_48 = FUN_01674e20();
        uStack_8 = 2;
        if (iStack_48 == 0) {
          piVar5 = (int *)0x0;
        }
        else {
          FUN_016f3cd0();
          piVar5 = (int *)FUN_006ab2f0();
        }
        uStack_8 = 1;
        piStack_3c = piVar5;
      }
      uStack_28 = 0;
      uStack_24 = 0xf;
      puStack_38 = (undefined4 *)((uint)puStack_38 & 0xffffff00);
      puStack_38 = (undefined4 *)FUN_01674e20();
      uStack_28 = 0x10;
      uStack_24 = 0x1f;
      *puStack_38 = 0;
      puStack_38[1] = 0;
      puStack_38[2] = 0;
      puStack_38[3] = 0;
      *(undefined *)(puStack_38 + 4) = 0;
      uStack_8 = 3;
      FUN_00a33fb0();
      iStack_40 = *(int *)(param_1 + 0x10) + 0x3798;
      iStack_1c = *(int *)(param_1 + 0xc0);
      iVar1 = *(int *)(param_1 + 0xb4);
      FUN_0054ef60();
      uStack_64 = uStack_80;
      iStack_68 = *(int *)(iVar1 + iStack_1c * 4);
      LOCK();
      *(int *)(iStack_68 + 0x28) = *(int *)(iStack_68 + 0x28) + 1;
      UNLOCK();
      uStack_20 = uStack_20 | 2;
      uStack_80 = uStack_80 & 0xffffff00;
      uStack_60 = uStack_7c;
      uStack_5c = uStack_78;
      uStack_58 = uStack_74;
      uStack_54 = CONCAT44(uStack_6c,uStack_70);
      uStack_70 = 0;
      uStack_6c = 0xf;
      LOCK();
      *(int *)(iStack_68 + 0x28) = *(int *)(iStack_68 + 0x28) + 1;
      UNLOCK();
      uStack_8 = 5;
      iStack_4c = iStack_68;
      FUN_006f86d0(auStack_90,&uStack_64,&uStack_64);
      uStack_8 = 4;
      FUN_0056cd30();
      if (0xf < uStack_54._4_4_) {
        uVar4 = uStack_64;
        if ((0xfff < uStack_54._4_4_ + 1) &&
           (uVar4 = *(uint *)(uStack_64 - 4), 0x1f < (uStack_64 - uVar4) - 4)) goto LAB_006fae15;
        FUN_01674ea0(uVar4);
      }
      uStack_54 = 0xf00000000;
      uStack_64 = uStack_64 & 0xffffff00;
      uStack_8 = 3;
      FUN_0056cd30();
      if (0xf < uStack_6c) {
        uVar4 = uStack_80;
        if ((0xfff < uStack_6c + 1) &&
           (uVar4 = *(uint *)(uStack_80 - 4), 0x1f < (uStack_80 - uVar4) - 4)) goto LAB_006fae15;
        FUN_01674ea0(uVar4);
      }
      param_1 = iStack_44;
      iVar1 = *(int *)(iStack_44 + 0xb4) + *(int *)(iStack_44 + 0xc0) * 4;
      FUN_00606470(auStack_98,iVar1,iVar1);
      if (cStack_94 != '\0') {
        FUN_006322b0(*(undefined4 *)(param_1 + 0x10),piVar5);
        iStack_18 = iStack_18 + 1;
      }
      *(int *)(param_1 + 0xc0) = *(int *)(param_1 + 0xc0) + 1;
      iVar1 = (**(code **)(*piVar5 + 8))();
      uStack_8 = 1;
      if ((float)((uint)DAT_01d6520c * 1000) * ((float)DAT_01d5b6e4 / DAT_018ce320) <=
          (float)((double)iVar1 + (double)(&DAT_018c0d90)[-(iVar1 >> 0x1f)])) {
        if (0xf < uStack_24) {
          uVar4 = uStack_24 + 1;
          puVar3 = puStack_38;
          if (0xfff < uVar4) {
            puVar3 = (undefined4 *)puStack_38[-1];
            uVar4 = uStack_24 + 0x24;
            if (0x1f < (uint)((int)puStack_38 + (-4 - (int)puVar3))) goto LAB_006fae15;
          }
          FUN_01674ea0(puVar3,uVar4);
        }
        break;
      }
      if (0xf < uStack_24) {
        puVar3 = puStack_38;
        if ((0xfff < uStack_24 + 1) &&
           (puVar3 = (undefined4 *)puStack_38[-1],
           0x1f < (uint)((int)puStack_38 + (-4 - (int)puVar3)))) {
LAB_006fae15:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
        FUN_01674ea0(puVar3);
      }
    } while (*(uint *)(param_1 + 0xc0) <
             (uint)(*(int *)(param_1 + 0xb8) - *(int *)(param_1 + 0xb4) >> 2));
    if (piVar5 != (int *)0x0) {
      iStack_48 = FUN_01674e20();
      uStack_8 = 6;
      if (iStack_48 == 0) {
        iVar1 = 0;
      }
      else {
        iVar1 = FUN_006ab530();
      }
      uStack_8 = 1;
      puVar3 = (undefined4 *)*param_2;
      *param_2 = iVar1;
      if (puVar3 != (undefined4 *)0x0) {
        (**(code **)*puVar3)();
      }
      auStack_14[0] = 0x83;
      FUN_006ad5e0(auStack_14,1);
      FUN_006b2070(*param_2,0x16);
      auStack_14[0] = 1;
      FUN_006ad5e0(auStack_14,1);
      iStack_1c = *(int *)(*param_2 + 0x18);
      FUN_00619a10(piVar5,*param_2,DAT_01d5be5c);
      iVar1 = (**(code **)(*piVar5 + 8))();
      *(int *)(param_1 + 100) = *(int *)(param_1 + 100) + iVar1;
      *(int *)(param_1 + 0x68) = *(int *)(param_1 + 0x68) + (*(int *)(*param_2 + 0x18) - iStack_1c);
      *(int *)(param_1 + 0x60) = *(int *)(param_1 + 0x60) + iStack_18;
      if (DAT_01d5b710 != '\0') {
        iVar1 = (**(code **)(*piVar5 + 8))();
        *(int *)(param_1 + 0x80) = *(int *)(param_1 + 0x80) + iVar1;
        iVar1 = (**(code **)(*piVar5 + 8))();
        *(int *)(param_1 + 0x84) = *(int *)(param_1 + 0x84) + iVar1;
        *(int *)(param_1 + 0x7c) =
             *(int *)(param_1 + 0x7c) + (*(int *)(*param_2 + 0x18) - iStack_1c);
        iVar1 = (**(code **)(*(int *)*param_2 + 8))();
        *(int *)(param_1 + 0x78) = *(int *)(param_1 + 0x78) + iVar1;
        *(int *)(param_1 + 0x74) = *(int *)(param_1 + 0x74) + iStack_18;
        *(int *)(param_1 + 0x70) = *(int *)(param_1 + 0x70) + 1;
      }
      FUN_006ab670();
    }
  }
  pdVar2 = (double *)FUN_016827e0();
  *(float *)(param_1 + 0x88) =
       (float)((*pdVar2 - dStack_88) * DAT_018c0d70) + *(float *)(param_1 + 0x88);
  if (DAT_01ee4213 != '\0') {
    pdVar2 = (double *)FUN_016827e0();
    FUN_01677520(DAT_01ee4213,"SharedString Blob: %u sharedStrings, took %f ms to serlialize",
                 iStack_18,(double)(float)((*pdVar2 - dStack_88) * DAT_018c0d70));
  }
  if (piVar5 != (int *)0x0) {
    (**(code **)*piVar5)();
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9738 ; VA 0x006fae20 ; FUN_006fae20 */

void __thiscall FUN_006fae20(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aab40;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::DeserializedMarkerItem>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9739 ; VA 0x006fae8e ; Catch_All@006fae8e */

void Catch_All_006fae8e(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9740 ; VA 0x006faeb0 ; FUN_006faeb0 */

undefined4 * __thiscall FUN_006faeb0(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_006b1a30(param_2);
  param_1[0xc] = param_3;
  *param_1 = RBX::Network::Replicator::MarkerItem::vftable;
  return param_1;
}



/* FUNCTION 9741 ; VA 0x006faee0 ; FUN_006faee0 */

undefined4 * __thiscall FUN_006faee0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Network::DeserializedItem::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  return param_1;
}



/* FUNCTION 9742 ; VA 0x006faf10 ; FUN_006faf10 */

undefined4 FUN_006faf10(void)

{
  return 4;
}



/* FUNCTION 9743 ; VA 0x006faf20 ; FUN_006faf20 */

undefined __fastcall FUN_006faf20(undefined4 param_1)

{
  FUN_00627c40(param_1);
  return 1;
}



/* FUNCTION 9744 ; VA 0x006faf40 ; FUN_006faf40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_006faf40(undefined4 *param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aab58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x14);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 4;
    puVar1[2] = 1;
    puVar1[3] = 0;
    *puVar1 = RBX::Network::DeserializedMarkerItem::vftable;
  }
  FUN_006fae20(puVar1,param_1);
  uStack_8 = 0;
  _DAT_00000010 = FUN_006ac4d0();
  *param_1 = 0;
  param_1[1] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9745 ; VA 0x006fafe0 ; FUN_006fafe0 */

undefined4 __thiscall FUN_006fafe0(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined3 uVar2;
  undefined3 extraout_var;
  undefined auStack_c [4];
  undefined4 uStack_8;
  
  uVar1 = FUN_00620ef0();
  if ((char)uVar1 == '\0') {
    return uVar1;
  }
  FUN_006b2070(param_2,4);
  uStack_8 = *(undefined4 *)(param_1 + 0x30);
  FUN_006a5c10(&uStack_8,auStack_c,4);
  FUN_006ad5e0(auStack_c,4);
  uVar1 = (**(code **)(**(int **)(param_1 + 0x10) + 0x180))(*(undefined4 *)(param_1 + 0x30));
  uVar2 = (undefined3)((uint)uVar1 >> 8);
  if (DAT_01ee4213 != '\0') {
    FUN_016774b0(DAT_01ee4213,"MarkerItem %ld sent",*(undefined4 *)(param_1 + 0x30));
    uVar2 = extraout_var;
  }
  return CONCAT31(uVar2,1);
}



/* FUNCTION 9746 ; VA 0x006fb070 ; FUN_006fb070 */

undefined4 * __thiscall
FUN_006fb070(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  FUN_006b1a30(param_2);
  param_1[0xc] = param_3;
  param_1[0xd] = param_4;
  param_1[0xe] = param_5;
  *param_1 = RBX::Network::Replicator::PingBackItem::vftable;
  return param_1;
}



/* FUNCTION 9747 ; VA 0x006fb0b0 ; FUN_006fb0b0 */

undefined4 FUN_006fb0b0(void)

{
  return 6;
}



/* FUNCTION 9748 ; VA 0x006fb0c0 ; FUN_006fb0c0 */

undefined4 __thiscall FUN_006fb0c0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined auStack_14 [8];
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_2;
  iVar2 = (**(code **)(*param_2 + 8))();
  FUN_006b2070(piVar1,6);
  param_2 = (int *)CONCAT31(param_2._1_3_,1);
  FUN_006ad5e0(&param_2,1);
  uStack_c = *(undefined4 *)(param_1 + 0x30);
  uStack_8 = *(undefined4 *)(param_1 + 0x34);
  FUN_006a5c10(&uStack_c,auStack_14,8);
  FUN_006ad5e0(auStack_14,8);
  FUN_008f7870(*(undefined4 *)(param_1 + 0x10));
  uVar3 = FUN_008ee4a0();
  param_2 = (int *)(uVar3 | DAT_01ee04b4);
  FUN_006a5c10(&param_2,&uStack_8,4);
  FUN_006ad5e0(&uStack_8,4);
  param_2 = *(int **)(param_1 + 0x38);
  FUN_006a5c10(&param_2,&uStack_8,4);
  FUN_006ad5e0(&uStack_8,4);
  if (*(char *)(*(int *)(*(int *)(param_1 + 0x10) + 0x1f70) + 0x5b) != '\0') {
    FUN_006b87f0(2);
    iVar4 = (**(code **)(*piVar1 + 8))();
    FUN_006b8ae0(2,iVar4 - iVar2);
  }
  return 1;
}



/* FUNCTION 9749 ; VA 0x006fb1c0 ; thunk_FUN_009fb580 */

undefined * thunk_FUN_009fb580(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d972c;
  pvStack_10 = ExceptionList;
  if (DAT_01ee6500 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee6710) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee6710);
      if (DAT_01ee6710 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Stats",1,uStack_20,0,0,0x13,0,0);
        FUN_016f3654(&LAB_01888860);
        FUN_016f37bf(&DAT_01ee6710);
      }
    }
    DAT_01ee6500 = &DAT_01ee6508;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee6500;
}


