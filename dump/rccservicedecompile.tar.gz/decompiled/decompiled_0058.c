/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 14500 ; VA 0x008ab5c2 ; Catch_All@008ab5c2 */

void Catch_All_008ab5c2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14501 ; VA 0x008ab5e0 ; FUN_008ab5e0 */

int __thiscall
FUN_008ab5e0(int *param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,int *param_7)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_7;
  puStack_c = &LAB_017bc9c8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x30);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    param_7 = (int *)0x0;
    puVar3[1] = 1;
    puVar3[2] = 1;
    *puVar3 = std::
              _Ref_count_resource<bool*,class_boost::_bi::bind_t<void,class_boost::_mfi::mf1<void,class_RBX::Mouse,class_std::shared_ptr<class_RBX::InputObject>_const&>,class_boost::_bi::list2<class_boost::_bi::value<class_RBX::PluginMouse*>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::InputObject>_>_>_>_>
              ::vftable;
    puVar3[4] = param_3;
    puVar3[5] = param_4;
    puVar3[6] = param_5;
    puVar3[7] = param_6;
    puVar3[8] = piVar1;
    puVar3[10] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)puVar3;
  if (param_7 != (int *)0x0) {
    LOCK();
    piVar1 = param_7 + 1;
    iVar2 = *piVar1;
    param_2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_2 = (**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_2 = (**(code **)(*param_7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14502 ; VA 0x008ab6b1 ; Catch_All@008ab6b1 */

void Catch_All_008ab6b1(void)

{
  int unaff_EBP;
  
  FUN_008aa840(unaff_EBP + 8);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14503 ; VA 0x008ab6d0 ; FUN_008ab6d0 */

undefined4 *
FUN_008ab6d0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
    piVar1 = param_6 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  piVar1 = param_6 + 1;
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = param_4;
  param_1[3] = 0;
  param_1[4] = 0;
  if (param_6 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[3] = param_5;
  param_1[4] = param_6;
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_6 + 4))();
      }
      return param_1;
    }
  }
  return param_1;
}



/* FUNCTION 14504 ; VA 0x008ab7d0 ; FUN_008ab7d0 */

void FUN_008ab7d0(int *param_1,undefined4 *param_2)

{
  int iVar1;
  code *pcVar2;
  int iStack_6c;
  int iStack_68;
  char cStack_64;
  int iStack_60;
  char acStack_5c [72];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pcVar2 = CloseHandle_exref;
  puStack_c = &LAB_017bc9e8;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff88;
  iStack_6c = -0x3ea8cf1e;
  iStack_68 = 0x7f0725e3;
  cStack_64 = '\0';
  iStack_60 = 0;
  acStack_5c[0] = '\0';
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = iStack_60;
  do {
    iStack_60 = iVar1;
    if (*param_1 == iStack_6c) {
LAB_008ab8b9:
      if ((iStack_60 != 0) && (iStack_60 != -1)) {
        (*pcVar2)(iStack_60);
      }
      ExceptionList = pvStack_10;
      return;
    }
    LOCK();
    iVar1 = *param_1;
    if (iVar1 == 0) {
      *param_1 = iStack_68;
      iVar1 = 0;
    }
    UNLOCK();
    if (iVar1 == 0) {
      if (iStack_60 == 0) {
        if (acStack_5c[0] == '\0') {
          FUN_005881c0(acStack_5c,param_1);
        }
        iVar1 = OpenEventA(0x100002,0,acStack_5c);
        if ((iStack_60 != 0) && (iStack_60 != -1)) {
          CloseHandle(iStack_60);
        }
        iStack_60 = iVar1;
        if (iVar1 != 0) goto LAB_008ab87e;
      }
      else {
LAB_008ab87e:
        ResetEvent(iStack_60);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      (*(code *)*param_2)(param_2[1],param_2[2],param_2[3],param_2[4],(int)param_2[4] >> 0x1f,
                          *(undefined *)(param_2 + 5));
      FUN_0057b500(param_1,&iStack_6c);
      pcVar2 = CloseHandle_exref;
      goto LAB_008ab8b9;
    }
    if (cStack_64 == '\0') {
      LOCK();
      param_1[1] = param_1[1] + 1;
      UNLOCK();
      cStack_64 = '\x01';
      if (*param_1 == iStack_6c) goto LAB_008ab8b9;
      if (iStack_60 != 0) goto LAB_008ab933;
      if (acStack_5c[0] == '\0') {
        FUN_005881c0(acStack_5c,param_1);
      }
      iVar1 = CreateEventA(0,1,0,acStack_5c);
      if ((iStack_60 != 0) && (iStack_60 != -1)) {
        CloseHandle(iStack_60);
      }
    }
    else {
LAB_008ab933:
      WaitForSingleObjectEx(iStack_60,0xffffffff,0);
      iVar1 = iStack_60;
    }
  } while( true );
}



/* FUNCTION 14505 ; VA 0x008ab943 ; Catch_All@008ab943 */

void Catch_All_008ab943(void)

{
  int unaff_EBP;
  
  FUN_0058a8e0(*(undefined4 *)(unaff_EBP + 8),unaff_EBP + -0x68);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14506 ; VA 0x008ab960 ; FUN_008ab960 */

undefined4 * __thiscall FUN_008ab960(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6248;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0;
  puVar5 = (undefined4 *)FUN_01674e20(0x30);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_008b2350;
    puVar5[3] = _guard_check_icall;
    puVar5[4] = 0;
    puVar5[5] = param_1;
    uVar1 = param_3[1];
    uVar2 = param_3[2];
    uVar3 = param_3[3];
    puVar5[6] = *param_3;
    puVar5[7] = uVar1;
    puVar5[8] = uVar2;
    puVar5[9] = uVar3;
    *(undefined8 *)(puVar5 + 10) = *(undefined8 *)(param_3 + 4);
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14507 ; VA 0x008aba30 ; FUN_008aba30 */

int * __fastcall FUN_008aba30(int *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  int *piStack_8;
  
  iVar3 = *param_1;
  piStack_8 = param_1;
  iVar2 = FUN_008bbc30();
  if (iVar3 == iVar2) {
    piVar6 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar6 = (int *)0x0;
    }
    if (piVar6 != (int *)0x0) {
      return piVar6;
    }
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 != iVar2) {
LAB_008abacb:
    thunk_FUN_008bbc30();
    uVar4 = FUN_005543f0();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar5,uVar4);
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 == iVar2) {
    iVar3 = param_1[1];
    FUN_008bbc30();
    piVar7 = param_1 + 2;
    piVar6 = piVar7;
    if (iVar3 == 0) {
      piVar6 = (int *)0x0;
    }
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    cVar1 = FUN_009cb180(piVar6,&piStack_8);
    if (cVar1 == '\0') goto LAB_008abacb;
    FUN_008aa7f0(&piStack_8);
    iVar3 = FUN_008bbc30();
    *param_1 = iVar3;
    iVar2 = FUN_008bbc30();
    if (iVar3 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14508 ; VA 0x008abb00 ; FUN_008abb00 */

undefined4 * FUN_008abb00(undefined4 *param_1,uint *param_2)

{
  uint uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  uint uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bca4b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_009fb200();
  uVar3 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar2 + 0x1dc) != (undefined4 *)0x0) {
    uVar3 = **(undefined4 **)(iVar2 + 0x1dc);
  }
  uVar3 = FUN_01675290(uVar3);
  uStack_8 = 1;
  uStack_1c = uVar3;
  puVar4 = (undefined4 *)FUN_01674e20(0x98);
  uStack_8._0_1_ = 2;
  puStack_14 = puVar4;
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    uStack_40 = 0;
    uVar1 = *param_2;
    if (uVar1 != 0) {
      uStack_40 = uVar1;
      if ((uVar1 & 1) == 0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,&uStack_38,0);
      }
      else {
        uStack_38 = param_2[2];
        uStack_34 = param_2[3];
        uStack_30 = param_2[4];
        uStack_2c = param_2[5];
        uStack_28 = *(undefined8 *)(param_2 + 6);
      }
    }
    uStack_8._0_1_ = 3;
    FUN_0089a7a0();
    uStack_8._0_1_ = 4;
    *puVar4 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar5 = FUN_009fb200();
    puVar4[3] = uVar5;
    *(undefined8 *)(puVar4 + 0x16) = 0;
    puVar4[0x1c] = 0;
    puVar4[0x1d] = 0xf;
    *(undefined *)(puVar4 + 0x18) = 0;
    *puVar4 = RBX::Stats::TypedStatsItem<int>::vftable;
    puVar4[0x1e] = 0;
    uStack_8._0_1_ = 5;
    if (uStack_40 != 0) {
      puVar4[0x1e] = uStack_40;
      if ((uStack_40 & 1) == 0) {
        (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,puVar4 + 0x20,0);
      }
      else {
        puVar4[0x20] = uStack_38;
        puVar4[0x21] = uStack_34;
        puVar4[0x22] = uStack_30;
        puVar4[0x23] = uStack_2c;
        *(undefined8 *)(puVar4 + 0x24) = uStack_28;
      }
    }
    uStack_8._0_1_ = 6;
    puVar4 = puStack_14;
    if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
       (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_38,2);
      puVar4 = puStack_14;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0066e460(puVar4,param_1);
  uStack_18 = 1;
  uStack_8 = 10;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14509 ; VA 0x008abcc0 ; FUN_008abcc0 */

undefined4 * FUN_008abcc0(undefined4 *param_1,uint *param_2)

{
  uint uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  uint uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bcaab;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_009fb200();
  uVar3 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar2 + 0x1dc) != (undefined4 *)0x0) {
    uVar3 = **(undefined4 **)(iVar2 + 0x1dc);
  }
  uVar3 = FUN_01675290(uVar3);
  uStack_8 = 1;
  uStack_1c = uVar3;
  puVar4 = (undefined4 *)FUN_01674e20(0x98);
  uStack_8._0_1_ = 2;
  puStack_14 = puVar4;
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    uStack_40 = 0;
    uVar1 = *param_2;
    if (uVar1 != 0) {
      uStack_40 = uVar1;
      if ((uVar1 & 1) == 0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,&uStack_38,0);
      }
      else {
        uStack_38 = param_2[2];
        uStack_34 = param_2[3];
        uStack_30 = param_2[4];
        uStack_2c = param_2[5];
        uStack_28 = *(undefined8 *)(param_2 + 6);
      }
    }
    uStack_8._0_1_ = 3;
    FUN_0089a7a0();
    uStack_8._0_1_ = 4;
    *puVar4 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar5 = FUN_009fb200();
    puVar4[3] = uVar5;
    *(undefined8 *)(puVar4 + 0x16) = 0;
    puVar4[0x1c] = 0;
    puVar4[0x1d] = 0xf;
    *(undefined *)(puVar4 + 0x18) = 0;
    *puVar4 = RBX::Stats::TypedStatsItem<float>::vftable;
    puVar4[0x1e] = 0;
    uStack_8._0_1_ = 5;
    if (uStack_40 != 0) {
      puVar4[0x1e] = uStack_40;
      if ((uStack_40 & 1) == 0) {
        (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,puVar4 + 0x20,0);
      }
      else {
        puVar4[0x20] = uStack_38;
        puVar4[0x21] = uStack_34;
        puVar4[0x22] = uStack_30;
        puVar4[0x23] = uStack_2c;
        *(undefined8 *)(puVar4 + 0x24) = uStack_28;
      }
    }
    uStack_8._0_1_ = 6;
    puVar4 = puStack_14;
    if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
       (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_38,2);
      puVar4 = puStack_14;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_006fccc0(puVar4,param_1);
  uStack_18 = 1;
  uStack_8 = 10;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14510 ; VA 0x008abe80 ; FUN_008abe80 */

undefined4 * FUN_008abe80(undefined4 *param_1,uint *param_2)

{
  uint uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  uint uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bcb0b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_009fb200();
  uVar3 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar2 + 0x1dc) != (undefined4 *)0x0) {
    uVar3 = **(undefined4 **)(iVar2 + 0x1dc);
  }
  uVar3 = FUN_01675290(uVar3);
  uStack_8 = 1;
  uStack_1c = uVar3;
  puVar4 = (undefined4 *)FUN_01674e20(0x98);
  uStack_8._0_1_ = 2;
  puStack_14 = puVar4;
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    uStack_40 = 0;
    uVar1 = *param_2;
    if (uVar1 != 0) {
      uStack_40 = uVar1;
      if ((uVar1 & 1) == 0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,&uStack_38,0);
      }
      else {
        uStack_38 = param_2[2];
        uStack_34 = param_2[3];
        uStack_30 = param_2[4];
        uStack_2c = param_2[5];
        uStack_28 = *(undefined8 *)(param_2 + 6);
      }
    }
    uStack_8._0_1_ = 3;
    FUN_0089a7a0();
    uStack_8._0_1_ = 4;
    *puVar4 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar5 = FUN_009fb200();
    puVar4[3] = uVar5;
    *(undefined8 *)(puVar4 + 0x16) = 0;
    puVar4[0x1c] = 0;
    puVar4[0x1d] = 0xf;
    *(undefined *)(puVar4 + 0x18) = 0;
    *puVar4 = RBX::Stats::TypedStatsItem<double>::vftable;
    puVar4[0x1e] = 0;
    uStack_8._0_1_ = 5;
    if (uStack_40 != 0) {
      puVar4[0x1e] = uStack_40;
      if ((uStack_40 & 1) == 0) {
        (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,puVar4 + 0x20,0);
      }
      else {
        puVar4[0x20] = uStack_38;
        puVar4[0x21] = uStack_34;
        puVar4[0x22] = uStack_30;
        puVar4[0x23] = uStack_2c;
        *(undefined8 *)(puVar4 + 0x24) = uStack_28;
      }
    }
    uStack_8._0_1_ = 6;
    puVar4 = puStack_14;
    if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
       (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_38,2);
      puVar4 = puStack_14;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_006fcdb0(puVar4,param_1);
  uStack_18 = 1;
  uStack_8 = 10;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14511 ; VA 0x008ac040 ; FUN_008ac040 */

undefined4 * FUN_008ac040(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017bcb4b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01674e20(0x7b4);
  uStack_8 = 1;
  if (iVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_008ad780(*param_2);
  }
  uStack_8 = uStack_8 & 0xffffff00;
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008ab040(uVar2,param_1);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14512 ; VA 0x008ac0d0 ; FUN_008ac0d0 */

undefined4 * FUN_008ac0d0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bcb93;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00d1e830();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x200);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00d1f200();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008ab130(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14513 ; VA 0x008ac190 ; FUN_008ac190 */

undefined4 * FUN_008ac190(undefined4 *param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bcbd3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00d7fd90();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xdc);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00d80700(param_2);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008ab220(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14514 ; VA 0x008ac260 ; FUN_008ac260 */

undefined4 *
FUN_008ac260(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined8 *param_4,
            undefined8 *param_5,undefined4 *param_6)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bcc13;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00d7fd90();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xdc);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00d80ac0(*param_2,*param_3,*param_4,*(undefined4 *)(param_4 + 1),*param_5,
                         *(undefined4 *)(param_5 + 1),*param_6);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008ab220(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14515 ; VA 0x008ac370 ; FUN_008ac370 */

undefined4 * FUN_008ac370(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bcc53;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00af0010();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x1c8);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00af1b80(1);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008ab310(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14516 ; VA 0x008ac440 ; FUN_008ac440 */

undefined4 * FUN_008ac440(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bcca8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009fb200();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  uStack_18 = uVar2;
  puVar3 = (undefined4 *)FUN_01674e20(0x78);
  uStack_8._0_1_ = 2;
  puStack_1c = puVar3;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar4 = FUN_009fb200();
    puVar3[3] = uVar4;
    *(undefined8 *)(puVar3 + 0x16) = 0;
    puVar3[0x1c] = 0;
    puVar3[0x1d] = 0xf;
    *(undefined *)(puVar3 + 0x18) = 0;
    uStack_8._0_1_ = 4;
    *puVar3 = RBX::WorkspaceStatsItem::vftable;
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005542c0("Workspace",9);
    uStack_8._0_1_ = 5;
    FUN_008a6520(auStack_34);
    uStack_8._0_1_ = 4;
    if (0xf < uStack_20) {
      uVar6 = uStack_20 + 1;
      uVar5 = auStack_34[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_34[0] - 4);
        uVar6 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008ab4f0(puVar3,puStack_1c);
  uStack_14 = 1;
  uStack_8 = 9;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14517 ; VA 0x008ac5b0 ; FUN_008ac5b0 */

undefined4 * FUN_008ac5b0(undefined4 *param_1,char *param_2,uint param_3)

{
  int *piVar1;
  char cVar2;
  code *pcVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  char *pcVar7;
  uint uVar8;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bcce9;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_008abb00(auStack_20,&param_3);
  *param_1 = 0;
  param_1[1] = 0;
  *param_1 = *puVar5;
  param_1[1] = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  uStack_14 = 1;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  pcVar3 = *(code **)(*(int *)*param_1 + 0x38);
  pcVar7 = param_2;
  do {
    cVar2 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(param_2,(int)pcVar7 - (int)(param_2 + 1));
  uStack_8._0_1_ = 2;
  (*pcVar3)(auStack_38);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < uStack_24) {
    uVar8 = uStack_24 + 1;
    uVar6 = auStack_38[0];
    if (0xfff < uVar8) {
      uVar6 = *(uint *)(auStack_38[0] - 4);
      uVar8 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar8);
  }
  FUN_008a65e0(uStack_18,0);
  uStack_8 = 3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14518 ; VA 0x008ac720 ; FUN_008ac720 */

undefined4 * FUN_008ac720(undefined4 *param_1,char *param_2,uint param_3)

{
  int *piVar1;
  char cVar2;
  code *pcVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  char *pcVar7;
  uint uVar8;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bcd29;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_008abe80(auStack_20,&param_3);
  *param_1 = 0;
  param_1[1] = 0;
  *param_1 = *puVar5;
  param_1[1] = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  uStack_14 = 1;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  pcVar3 = *(code **)(*(int *)*param_1 + 0x38);
  pcVar7 = param_2;
  do {
    cVar2 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(param_2,(int)pcVar7 - (int)(param_2 + 1));
  uStack_8._0_1_ = 2;
  (*pcVar3)(auStack_38);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < uStack_24) {
    uVar8 = uStack_24 + 1;
    uVar6 = auStack_38[0];
    if (0xfff < uVar8) {
      uVar6 = *(uint *)(auStack_38[0] - 4);
      uVar8 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar8);
  }
  FUN_008a65e0(uStack_18,0);
  uStack_8 = 3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14519 ; VA 0x008ac890 ; FUN_008ac890 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_008ac890(int param_1,undefined4 *param_2,uint *param_3,undefined4 *param_4)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bcd48;
  pvStack_10 = ExceptionList;
  uVar2 = *param_3;
  uVar7 = (uVar2 >> 3) + uVar2;
  uVar6 = uVar7 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar4 = (int *)0x0;
  }
  else {
    puVar8 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    if (puVar8 == (undefined4 *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      piVar4 = (int *)*puVar8;
    }
    if (piVar4 == (int *)0x0) goto LAB_008ac92e;
    do {
      if (uVar7 == piVar4[1]) {
        if (uVar2 == piVar4[2]) break;
      }
      else if ((uint)piVar4[1] % *(uint *)(param_1 + 4) != uVar6) goto LAB_008ac92e;
      piVar4 = (int *)*piVar4;
    } while (piVar4 != (int *)0x0);
  }
  if (piVar4 != (int *)0x0) {
    *param_2 = piVar4;
    *(undefined *)(param_2 + 1) = 0;
    return;
  }
LAB_008ac92e:
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_008b0490();
  if (param_4[1] != 0) {
    LOCK();
    piVar4 = (int *)(param_4[1] + 4);
    *piVar4 = *piVar4 + 1;
    UNLOCK();
  }
  _DAT_00000008 = *param_4;
  _DAT_0000000c = param_4[1];
  uVar6 = *(uint *)(param_1 + 8);
  uVar2 = uVar6 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar2 = FUN_005c9310(uVar2);
    if (uVar2 <= *(uint *)(param_1 + 4)) {
      uVar2 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar2);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar2) {
    uVar5 = uVar6 >> 1;
    if (uVar6 + (uVar6 >> 1) <= uVar2) {
      uVar5 = 1;
    }
    iVar3 = FUN_005c9310(uVar5 + uVar6);
    if (iVar3 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar3);
      puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)*puVar8;
      while (puVar1 != (undefined4 *)0x0) {
        uVar2 = (uint)puVar1[1] % *(uint *)(param_1 + 4);
        piVar4 = (int *)(*(int *)(param_1 + 0x14) + uVar2 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar2 * 4) == 0) {
          *piVar4 = (int)puVar8;
          puVar8 = puVar1;
        }
        else {
          *puVar8 = *puVar1;
          *puVar1 = *(undefined4 *)*piVar4;
          *(undefined4 **)*piVar4 = puVar1;
        }
        puVar1 = (undefined4 *)*puVar8;
      }
    }
  }
  uVar2 = uVar7 % *(uint *)(param_1 + 4);
  piVar4 = *(int **)(*(int *)(param_1 + 0x14) + uVar2 * 4);
  puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar2 * 4);
  _DAT_00000004 = uVar7;
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar4 != 0) {
      *(undefined4 *)
       (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar4 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
    }
    *puVar8 = piVar4;
    _DAT_00000000 = *piVar4;
    *piVar4 = 0;
  }
  else {
    _DAT_00000000 = *piVar4;
    *(undefined4 *)*puVar8 = 0;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = 0;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14520 ; VA 0x008aca90 ; FUN_008aca90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_008aca90(int param_1,undefined4 *param_2,uint *param_3,undefined4 *param_4)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bcd68;
  pvStack_10 = ExceptionList;
  uVar2 = *param_3;
  uVar7 = (uVar2 >> 3) + uVar2;
  uVar6 = uVar7 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar4 = (int *)0x0;
  }
  else {
    puVar8 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    if (puVar8 == (undefined4 *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      piVar4 = (int *)*puVar8;
    }
    if (piVar4 == (int *)0x0) goto LAB_008acb2e;
    do {
      if (uVar7 == piVar4[1]) {
        if (uVar2 == piVar4[2]) break;
      }
      else if ((uint)piVar4[1] % *(uint *)(param_1 + 4) != uVar6) goto LAB_008acb2e;
      piVar4 = (int *)*piVar4;
    } while (piVar4 != (int *)0x0);
  }
  if (piVar4 != (int *)0x0) {
    *param_2 = piVar4;
    *(undefined *)(param_2 + 1) = 0;
    return;
  }
LAB_008acb2e:
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_008b0490();
  _DAT_00000008 = *param_4;
  _DAT_0000000c = param_4[1];
  *param_4 = 0;
  param_4[1] = 0;
  uVar6 = *(uint *)(param_1 + 8);
  uVar2 = uVar6 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar2 = FUN_005c9310(uVar2);
    if (uVar2 <= *(uint *)(param_1 + 4)) {
      uVar2 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar2);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar2) {
    uVar5 = uVar6 >> 1;
    if (uVar6 + (uVar6 >> 1) <= uVar2) {
      uVar5 = 1;
    }
    iVar3 = FUN_005c9310(uVar5 + uVar6);
    if (iVar3 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar3);
      puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)*puVar8;
      while (puVar1 != (undefined4 *)0x0) {
        uVar2 = (uint)puVar1[1] % *(uint *)(param_1 + 4);
        piVar4 = (int *)(*(int *)(param_1 + 0x14) + uVar2 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar2 * 4) == 0) {
          *piVar4 = (int)puVar8;
          puVar8 = puVar1;
        }
        else {
          *puVar8 = *puVar1;
          *puVar1 = *(undefined4 *)*piVar4;
          *(undefined4 **)*piVar4 = puVar1;
        }
        puVar1 = (undefined4 *)*puVar8;
      }
    }
  }
  uVar2 = uVar7 % *(uint *)(param_1 + 4);
  piVar4 = *(int **)(*(int *)(param_1 + 0x14) + uVar2 * 4);
  puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar2 * 4);
  _DAT_00000004 = uVar7;
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar4 != 0) {
      *(undefined4 *)
       (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar4 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
    }
    *puVar8 = piVar4;
    _DAT_00000000 = *piVar4;
    *piVar4 = 0;
  }
  else {
    _DAT_00000000 = *piVar4;
    *(undefined4 *)*puVar8 = 0;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = 0;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14521 ; VA 0x008acc90 ; FUN_008acc90 */

int __fastcall FUN_008acc90(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = thunk_FUN_00897b90();
  iVar3 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar3 = param_1;
  }
  return iVar3;
}



/* FUNCTION 14522 ; VA 0x008accc0 ; FUN_008accc0 */

int FUN_008accc0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01ead658,&LAB_00634090);
      uVar3 = FUN_006350d0();
      piVar4 = (int *)FUN_008aa140(uVar3);
      if (*piVar4 == 0) {
        uVar3 = FUN_00b57070();
        piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar4 = iVar1;
        piVar5 = (int *)piVar4[1];
        piVar4[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_8[1] + -1;
          piStack_8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar5 = piStack_8 + 2;
            iVar1 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      return *piVar4;
    }
  }
  return 0;
}



/* FUNCTION 14523 ; VA 0x008acdd0 ; FUN_008acdd0 */

int FUN_008acdd0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01ead638,&LAB_006340f0);
      uVar3 = FUN_006353d0();
      piVar4 = (int *)FUN_008aa140(uVar3);
      if (*piVar4 == 0) {
        uVar3 = FUN_00b774a0();
        piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar4 = iVar1;
        piVar5 = (int *)piVar4[1];
        piVar4[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_8[1] + -1;
          piStack_8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar5 = piStack_8 + 2;
            iVar1 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      return *piVar4;
    }
  }
  return 0;
}



/* FUNCTION 14524 ; VA 0x008acee0 ; FUN_008acee0 */

int FUN_008acee0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01ead600,&LAB_00634100);
      uVar3 = FUN_00635450();
      piVar4 = (int *)FUN_008aa140(uVar3);
      if (*piVar4 == 0) {
        uVar3 = FUN_00b7a190();
        piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar4 = iVar1;
        piVar5 = (int *)piVar4[1];
        piVar4[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_8[1] + -1;
          piStack_8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar5 = piStack_8 + 2;
            iVar1 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      return *piVar4;
    }
  }
  return 0;
}



/* FUNCTION 14525 ; VA 0x008acff0 ; FUN_008acff0 */

int FUN_008acff0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01ead670,&LAB_00634110);
      uVar3 = FUN_006354d0();
      piVar4 = (int *)FUN_008aa140(uVar3);
      if (*piVar4 == 0) {
        uVar3 = FUN_00baf450();
        piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar4 = iVar1;
        piVar5 = (int *)piVar4[1];
        piVar4[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_8[1] + -1;
          piStack_8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar5 = piStack_8 + 2;
            iVar1 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      return *piVar4;
    }
  }
  return 0;
}



/* FUNCTION 14526 ; VA 0x008ad100 ; FUN_008ad100 */

int __fastcall FUN_008ad100(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
      iVar3 = *piVar6;
      if ((iVar3 != 0) &&
         (iVar4 = *(int *)(iVar3 + 0xc), iVar5 = FUN_00c46280(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        return iVar3;
      }
    }
  }
  return 0;
}



/* FUNCTION 14527 ; VA 0x008ad160 ; FUN_008ad160 */

code * FUN_008ad160(undefined4 *param_1,undefined4 *param_2,code *param_3)

{
  int *piVar1;
  
  if (param_1 == param_2) {
    return param_3;
  }
  do {
    if (param_1[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_1[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    (*param_3)(*param_1,param_1[1]);
    param_1 = param_1 + 2;
  } while (param_1 != param_2);
  return param_3;
}



/* FUNCTION 14528 ; VA 0x008ad1c0 ; FUN_008ad1c0 */

undefined4 * FUN_008ad1c0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  bool bVar4;
  bool bVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  int *piVar9;
  undefined auStack_24 [12];
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if (param_2 == 0) {
    puVar8 = &uStack_10;
    piStack_c = (int *)0x0;
    bVar5 = false;
    bVar4 = false;
    bVar3 = true;
    uVar7 = 0;
    piVar9 = (int *)0x0;
LAB_008ad238:
    *puVar8 = 0;
    *param_1 = uVar7;
    param_1[1] = puVar8[1];
    puVar8[1] = 0;
    if ((bVar3) && (piStack_c != (int *)0x0)) {
      LOCK();
      iVar2 = piStack_c[1] + -1;
      piStack_c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        iVar2 = piStack_c[2] + -1;
        piStack_c[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_c + 4))();
        }
      }
    }
    if ((bVar4) && (piStack_14 != (int *)0x0)) {
      LOCK();
      iVar2 = piStack_14[1] + -1;
      piStack_14[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        iVar2 = piStack_14[2] + -1;
        piStack_14[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    if ((bVar5) && (piVar9 != (int *)0x0)) {
      LOCK();
      iVar2 = piVar9[1] + -1;
      piVar9[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar9)();
        LOCK();
        piVar1 = piVar9 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar9 + 4))();
        }
      }
    }
    return param_1;
  }
  iVar2 = *(int *)(param_2 + 0x20);
  if (iVar2 != 0) {
    piVar9 = (int *)(iVar2 + 4);
    iVar2 = *(int *)(iVar2 + 4);
    while (iVar2 != 0) {
      LOCK();
      iVar6 = *piVar9;
      if (iVar2 == iVar6) {
        *piVar9 = iVar2 + 1;
        iVar6 = iVar2;
      }
      UNLOCK();
      if (iVar6 == iVar2) {
        piVar9 = *(int **)(param_2 + 0x20);
        uVar7 = *(undefined4 *)(param_2 + 0x1c);
        if (piVar9 != (int *)0x0) {
          LOCK();
          piVar9[1] = piVar9[1] + 1;
          UNLOCK();
        }
        piStack_14 = piVar9;
        puVar8 = &uStack_18;
        bVar5 = true;
        bVar4 = true;
        bVar3 = false;
        goto LAB_008ad238;
      }
      iVar2 = *piVar9;
    }
  }
  FUN_005c47d0();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_24,&DAT_01c21d80);
}



/* FUNCTION 14529 ; VA 0x008ad300 ; thunk_FUN_008bbaf0 */

undefined * thunk_FUN_008bbaf0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bdb8c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee005c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee005c);
    if (DAT_01ee005c == -1) {
      uStack_8 = 0;
      FUN_00f35810();
      FUN_016f3654(&LAB_01881740);
      FUN_016f37bf(&DAT_01ee005c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edfff8;
}



/* FUNCTION 14530 ; VA 0x008ad310 ; thunk_FUN_008bbc30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_008bbc30(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bdbd6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edfebc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edfebc);
    if (DAT_01edfebc == -1) {
      uStack_8 = 0;
      FUN_009ca470("MeshPartHeads");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01edfe58 = RBX::Reflection::EnumDesc<enum_RBX::Workspace::MeshPartHeads>::vftable;
      FUN_009caf20(&DAT_01d62df4,3);
      FUN_016f3654(&LAB_01881780);
      FUN_016f37bf(&DAT_01edfebc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edfe58;
}



/* FUNCTION 14531 ; VA 0x008ad320 ; FUN_008ad320 */

void * __thiscall FUN_008ad320(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  code *pcVar4;
  void *pvVar5;
  int *piVar6;
  undefined4 *puVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a0698;
  puVar7 = *(undefined4 **)(param_1 + 0x2c);
  pvVar5 = ExceptionList;
  if (puVar7 != (undefined4 *)0x0) {
    piVar6 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar6 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      piVar6 = *(int **)(param_1 + 0x30);
      puVar7 = *(undefined4 **)(param_1 + 0x2c);
    }
    puVar3 = (undefined4 *)puVar7[1];
    puVar7 = (undefined4 *)*puVar7;
    uStack_8 = 0;
    pvVar5 = pvStack_10;
    for (; puVar7 != puVar3; puVar7 = puVar7 + 2) {
      pcVar4 = (code *)*param_2;
      if (puVar7[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar7[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      pvVar5 = (void *)(*pcVar4)(*puVar7,puVar7[1]);
    }
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar1 = piVar6 + 1;
      iVar2 = *piVar1;
      pvVar5 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar5 = (void *)(**(code **)*piVar6)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar5 = (void *)(**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 14532 ; VA 0x008ad3f0 ; FUN_008ad3f0 */

void FUN_008ad3f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 int param_5,int param_6)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  FUN_008af010(param_5);
  iVar3 = 0;
  if (0 < *(int *)(param_5 + 0x14)) {
    do {
      iVar1 = *(int *)(*(int *)(param_5 + 0x10) + iVar3 * 4);
      uVar2 = -(uint)(iVar1 != 0) & iVar1 - 8U;
      if (uVar2 != 0) {
        iVar1 = FUN_00c15700();
        if (iVar1 == param_6) {
          FUN_008ad3f0(param_1,param_2,param_3,param_4,uVar2,param_6);
        }
      }
      iVar3 = iVar3 + 1;
    } while (iVar3 < *(int *)(param_5 + 0x14));
  }
  return;
}



/* FUNCTION 14533 ; VA 0x008ad460 ; FUN_008ad460 */

void FUN_008ad460(undefined4 param_1,undefined4 param_2,int param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  FUN_008af200(param_3);
  iVar3 = 0;
  if (0 < *(int *)(param_3 + 0x14)) {
    do {
      iVar1 = *(int *)(*(int *)(param_3 + 0x10) + iVar3 * 4);
      uVar2 = -(uint)(iVar1 != 0) & iVar1 - 8U;
      if ((uVar2 != 0) && (iVar1 = FUN_00c15700(), iVar1 == param_4)) {
        FUN_008ad460(param_1,param_2,uVar2,param_4);
      }
      iVar3 = iVar3 + 1;
    } while (iVar3 < *(int *)(param_3 + 0x14));
  }
  return;
}



/* FUNCTION 14534 ; VA 0x008ad4c0 ; FUN_008ad4c0 */

int FUN_008ad4c0(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if ((param_1 == (int *)0x0) ||
     (iVar3 = param_1[3], ExceptionList = &pvStack_10, iVar2 = FUN_00aff8c0(),
     (uint)*(ushort *)(iVar2 + 0x1da) <
     (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))) {
    pcStack_14 = FUN_008ad4c0;
    iVar3 = FUN_008ad320(&pcStack_14);
  }
  else {
    iVar3 = (**(code **)(*param_1 + 300))(1);
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 14535 ; VA 0x008ad570 ; FUN_008ad570 */

int FUN_008ad570(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if ((param_1 == (int *)0x0) ||
     (iVar3 = param_1[3], ExceptionList = &pvStack_10, iVar2 = FUN_00aff8c0(),
     (uint)*(ushort *)(iVar2 + 0x1da) <
     (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))) {
    pcStack_14 = FUN_008ad570;
    iVar3 = FUN_008ad320(&pcStack_14);
  }
  else {
    iVar3 = (**(code **)(*param_1 + 0x134))();
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 14536 ; VA 0x008ad620 ; FUN_008ad620 */

undefined4 * __thiscall
FUN_008ad620(undefined4 *param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 *param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bcdcb;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar1 = FUN_008aa870();
  FUN_009cb790(uVar1,param_4,param_6,param_7,param_8);
  *(undefined8 *)(param_1 + 0xe) = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::Workspace,void___cdecl(class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>),1>
             ::vftable;
  param_1[0x10] = param_3;
  param_1[0x11] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar1 = FUN_00888530();
  param_1[9] = uVar1;
  if (param_1[0x11] == 0) {
    uStack_e8 = FUN_00888530();
    iStack_e4 = 0;
    param_6 = &uStack_e8;
    uStack_8 = 3;
    uVar3 = 2;
  }
  else {
    param_6 = (undefined4 *)FUN_008aa360(param_1[0x11]);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar3 = 1;
  }
  uStack_14 = uVar3;
  uVar1 = FUN_0088cc80();
  uVar2 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar2,uVar1,param_6);
  if ((uVar3 & 2) != 0) {
    uVar3 = uVar3 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar3;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  if ((uVar3 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14537 ; VA 0x008ad780 ; FUN_008ad780 */

undefined4 * __thiscall FUN_008ad780(undefined4 *param_1,undefined4 param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bce09;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00f29ce0(param_2);
  *param_1 = RBX::ArrowToolBase::vftable;
  *(undefined *)(param_1 + 0x11) = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  uStack_8 = 0;
  *(undefined *)(param_1 + 0x16) = 1;
  FUN_00f2d480();
  param_1[0x1d3] = 0;
  param_1[0x1d4] = 0;
  param_1[0x1d5] = 0;
  param_1[0x1d6] = 0;
  param_1[0x1d7] = 0;
  param_1[0x1d8] = 0;
  param_1[0x1d9] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (DAT_01ee41f0 != '\0') {
    FUN_016774b0(DAT_01ee41f0,"ArrowTool created: %p",param_1);
  }
  uStack_8 = 3;
  *param_1 = RBX::AdvArrowToolBase::vftable;
  FUN_00f31db0(param_2);
  param_1[0x1ea] = 0;
  param_1[0x1eb] = 0;
  param_1[0x1ec] = 0;
  *param_1 = RBX::AdvArrowTool::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14538 ; VA 0x008ad8a0 ; FUN_008ad8a0 */

undefined4 * __thiscall FUN_008ad8a0(undefined4 *param_1,undefined4 param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bce09;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00f29ce0(param_2);
  *param_1 = RBX::ArrowToolBase::vftable;
  *(undefined *)(param_1 + 0x11) = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  uStack_8 = 0;
  *(undefined *)(param_1 + 0x16) = 1;
  FUN_00f2d480();
  param_1[0x1d3] = 0;
  param_1[0x1d4] = 0;
  param_1[0x1d5] = 0;
  param_1[0x1d6] = 0;
  param_1[0x1d7] = 0;
  param_1[0x1d8] = 0;
  param_1[0x1d9] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (DAT_01ee41f0 != '\0') {
    FUN_016774b0(DAT_01ee41f0,"ArrowTool created: %p",param_1);
  }
  uStack_8 = 3;
  *param_1 = RBX::AdvArrowToolBase::vftable;
  FUN_00f31db0(param_2);
  param_1[0x1ea] = 0;
  param_1[0x1eb] = 0;
  param_1[0x1ec] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14539 ; VA 0x008ad9c0 ; FUN_008ad9c0 */

undefined4 * __thiscall FUN_008ad9c0(undefined4 *param_1,undefined4 *param_2)

{
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_2[3] = 0;
  param_2[4] = 0;
  return param_1;
}



/* FUNCTION 14540 ; VA 0x008ada10 ; FUN_008ada10 */

undefined4 * __thiscall FUN_008ada10(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = 0;
  param_1[5] = 0;
  if (param_2[5] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[5] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  param_1[6] = param_2[6];
  return param_1;
}



/* FUNCTION 14541 ; VA 0x008ada80 ; FUN_008ada80 */

undefined4 * __thiscall FUN_008ada80(undefined4 *param_1,int param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined8 uVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined **ppuVar6;
  int iVar7;
  undefined **ppuVar8;
  code *pcVar9;
  uint uVar10;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 *puStack_40;
  uint uStack_3c;
  code *pcStack_2c;
  undefined4 *puStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd045;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (undefined4 *)0x0) {
    ExceptionList = &pvStack_10;
    param_1[0x15] = &DAT_0191f11c;
    param_1[0x1e] = &DAT_0191f124;
    param_1[0xd5] = RBX::IHasLocation::vftable;
    uStack_8 = 0;
  }
  uStack_14 = (uint)(param_3 != (undefined4 *)0x0);
  puStack_1c = param_1;
  FUN_00a967f0(DAT_01d67be8,DAT_01d62c94,DAT_01d62c9c,DAT_01d62ca4,0);
  *param_1 = RBX::Described<class_RBX::Workspace,class_RBX::WorldRoot>::vftable;
  param_1[0x16] = RBX::Described<class_RBX::Workspace,class_RBX::WorldRoot>::vftable;
  param_1[0x1d] = RBX::Described<class_RBX::Workspace,class_RBX::WorldRoot>::vftable;
  param_1[0x51] = RBX::Described<class_RBX::Workspace,class_RBX::WorldRoot>::vftable;
  param_1[0x52] = RBX::Described<class_RBX::Workspace,class_RBX::WorldRoot>::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::Described<class_RBX::Workspace,class_RBX::WorldRoot>::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0x198
  ;
  uVar4 = FUN_008aa870();
  param_1[3] = uVar4;
  *(undefined *)(param_1 + 0x7b) = 1;
  param_1[0x7a] = RBX::IScriptFilter::vftable;
  *param_1 = RBX::Workspace::vftable;
  param_1[0x16] = RBX::Workspace::vftable;
  param_1[0x1d] = RBX::Workspace::vftable;
  param_1[0x51] = RBX::Workspace::vftable;
  param_1[0x52] = RBX::Workspace::vftable;
  param_1[0x7a] = RBX::Workspace::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) = RBX::Workspace::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0x300
  ;
  param_1[0x7c] = 0;
  param_1[0x7d] = 0;
  param_1[0x7e] = 0;
  param_1[0x7f] = 0;
  param_1[0x80] = 0;
  param_1[0x81] = 0;
  param_3 = param_1 + 0x82;
  param_1[0x83] = 0;
  param_1[0x84] = 0;
  *param_3 = 0;
  uStack_8._0_1_ = 10;
  uStack_8._1_3_ = 0;
  param_1[0x85] = 0;
  puVar5 = (undefined4 *)FUN_01674e20(0x24);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
    param_3 = (undefined4 *)0x0;
  }
  else {
    puVar5[1] = 0;
    puVar5[2] = 0;
    *puVar5 = 0;
    puVar5[4] = 0;
    puVar5[5] = 0;
    puVar5[3] = 0;
    param_3 = puVar5 + 6;
    puVar5[7] = 0;
    puVar5[8] = 0;
    *param_3 = 0;
  }
  uStack_8._0_1_ = 10;
  param_1[0x86] = 0;
  param_1[0x87] = 0;
  FUN_008aafb0(puVar5,param_3);
  uStack_24 = 0;
  *(undefined8 *)(param_1 + 0x88) = 0;
  uVar2 = DAT_018c45d8;
  param_1[0x8a] = 0;
  *(undefined8 *)(param_1 + 0x8b) = 0;
  uStack_3c = 0;
  param_1[0x8d] = 0;
  *(undefined8 *)(param_1 + 0x8e) = uVar2;
  param_1[0x90] = 0;
  param_1[0x91] = 0;
  param_1[0x92] = param_2;
  *(undefined *)(param_1 + 0x93) = 0;
  param_1[0x94] = 0;
  param_1[0x95] = 0;
  param_1[0x96] = 0;
  param_1[0x97] = 0;
  param_1[0x98] = 0;
  param_1[0x99] = 0;
  uStack_8._0_1_ = 0x12;
  param_3 = (undefined4 *)FUN_01674e20(0x38);
  uStack_8._0_1_ = 0x13;
  if (param_3 == (undefined4 *)0x0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00995130(0);
  }
  param_1[0x9a] = uVar4;
  param_1[0x9b] = 0;
  param_1[0x9c] = 0;
  *(undefined2 *)(param_1 + 0x9d) = 0;
  param_1[0x9e] = 0;
  param_1[0x9f] = 0;
  param_1[0xa0] = 0;
  param_1[0xa1] = 0;
  param_1[0xa2] = 0;
  uStack_8._0_1_ = 0x16;
  FUN_008ac0d0(param_1 + 0xa3);
  param_1[0xa5] = 0;
  param_1[0xa6] = 0;
  param_1[0xa7] = 0;
  param_1[0xa9] = 0;
  param_1[0xaa] = 0;
  param_1[0xa8] = 0;
  param_1[0xab] = 0;
  *(undefined *)(param_1 + 0xac) = 0;
  param_3 = (undefined4 *)0xb;
  ppuVar6 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_3);
  ppuVar8 = ppuVar6 + -1;
  if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar8 = ppuVar6;
  }
  param_1[0xad] = *ppuVar8;
  param_1[0xae] = 0;
  param_1[0xaf] = 0x3f800000;
  param_1[0xb0] = 0;
  param_1[0xb1] = 0;
  *(undefined *)(param_1 + 0xb2) = 0;
  param_3 = (undefined4 *)0xb;
  ppuVar6 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_3);
  ppuVar8 = ppuVar6 + -1;
  if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar8 = ppuVar6;
  }
  param_1[0xb3] = *ppuVar8;
  param_1[0xb4] = 0;
  param_1[0xb5] = 0x3f800000;
  param_1[0xb6] = 0;
  param_1[0xb7] = 0;
  *(undefined *)(param_1 + 0xc0) = 0;
  param_1[0xb8] = 0;
  param_1[0xb9] = 0;
  param_1[0xba] = 0;
  param_1[0xbb] = 0;
  param_1[0xc1] = 0x400;
  param_1[0xbc] = 0;
  param_1[0xbd] = 0;
  param_1[0xbe] = 0;
  param_1[0xbf] = 0;
  param_1[0xc2] = 0x40;
  param_1[0xc3] = 0;
  param_1[0xc4] = 0;
  param_1[0xc5] = 0;
  param_1[0xc6] = 0x10000;
  param_1[199] = 0;
  param_1[200] = 0;
  param_1[0xc9] = 0;
  *(undefined *)(param_1 + 0xca) = 0;
  param_1[0xcb] = 0;
  param_1[0xcc] = 0;
  uStack_8._0_1_ = 0x1d;
  iVar7 = FUN_01674e20(4);
  if (iVar7 == 0) {
    iVar7 = 0;
  }
  else {
    *(int *)iVar7 = iVar7;
  }
  param_3 = (undefined4 *)0x0;
  param_1[0xcd] = iVar7;
  param_1[0xce] = 0;
  param_1[0xcf] = 0;
  param_1[0xd0] = 0;
  param_1[0xd1] = 0;
  uStack_8._0_1_ = 0x22;
  param_1[0xd2] = 0;
  puStack_40 = (undefined4 *)0x0;
  uStack_3c = 0xf;
  pcStack_50 = (code *)((uint)pcStack_50 & 0xffffff00);
  FUN_005542c0("Workspace",9);
  uStack_8._0_1_ = 0x23;
  FUN_00b66d70(&pcStack_50);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x22);
  if (0xf < uStack_3c) {
    uVar10 = uStack_3c + 1;
    pcVar9 = pcStack_50;
    if (0xfff < uVar10) {
      pcVar9 = *(code **)(pcStack_50 + -4);
      uVar10 = uStack_3c + 0x24;
      if ((code *)0x1f < pcStack_50 + (-4 - (int)pcVar9)) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pcVar9,uVar10);
  }
  if (DAT_01ee41ef != '\0') {
    FUN_016774b0(DAT_01ee41ef,"Workspace created: %p",param_1);
  }
  *(undefined *)(param_1 + 0x6e) = 0;
  FUN_00bbcb20();
  param_3 = *(undefined4 **)(param_1[0x6d] + 0xc4);
  *(int *)param_1[0xcd] = (int)param_3 + (int)param_1[0xcd];
  param_3 = (undefined4 *)FUN_01674e20(0x778);
  uStack_8._0_1_ = 0x24;
  if (param_3 == (undefined4 *)0x0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00f2eae0(param_1);
  }
  param_1[0xab] = uVar4;
  if (DAT_01d62da4 != '\0') {
    param_2 = param_1[0x6d] + 0x14;
    pcStack_2c = FUN_008b48f0;
    uStack_48 = 0x8b48f0;
    puStack_40 = (undefined4 *)0x0;
    uStack_8._0_1_ = 0x25;
    puStack_28 = param_1;
    uVar4 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 0x26;
    uStack_20 = uVar4;
    puStack_18 = (undefined4 *)FUN_01674e20(0x30);
    if (puStack_18 == (undefined4 *)0x0) {
      puStack_18 = (undefined4 *)0x0;
    }
    else {
      *puStack_18 = 0;
      puStack_18[1] = 1;
      puStack_18[2] = FUN_008b2320;
      puStack_18[3] = _guard_check_icall;
      puStack_18[4] = 0;
      puStack_18[6] = (undefined4)uStack_48;
      puStack_18[7] = uStack_48._4_4_;
      puStack_18[8] = puStack_40;
      puStack_18[9] = uStack_3c;
      puStack_18[5] = param_2;
      *(ulonglong *)(puStack_18 + 10) = CONCAT44(uStack_24,puStack_28);
    }
    FUN_016797d0(puStack_18);
    param_3 = puStack_18;
    if (puStack_18 != (undefined4 *)0x0) {
      LOCK();
      puStack_18[1] = puStack_18[1] + 1;
      UNLOCK();
    }
    uStack_14 = uStack_14 | 4;
    uStack_8._0_1_ = 0x27;
    FUN_01675290(uVar4);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x25);
    cVar3 = FUN_01679300(&param_3);
    if (cVar3 != '\0') {
      FUN_01679490();
      FUN_016791c0(&param_3);
    }
    uStack_14 = uStack_14 & 0xfffffffb;
    uStack_8._0_1_ = 0x22;
    if (param_3 != (undefined4 *)0x0) {
      piVar1 = param_3 + 1;
      LOCK();
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        FUN_01674ea0(param_3);
      }
    }
    pcStack_2c = FUN_008b48c0;
    puStack_28 = (undefined4 *)0x0;
    pcStack_50 = FUN_008b48c0;
    uStack_4c = 0;
    uStack_48 = (ulonglong)uStack_3c << 0x20;
    puStack_40 = param_1;
    param_3 = (undefined4 *)FUN_008ab960(&param_2,&pcStack_50);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x28);
    cVar3 = FUN_01679300(param_3);
    if (cVar3 != '\0') {
      FUN_01679490();
      FUN_016791c0(param_3);
    }
    uStack_8._0_1_ = 0x22;
    if (param_2 != 0) {
      piVar1 = (int *)(param_2 + 4);
      LOCK();
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        FUN_01674ea0(param_2);
      }
    }
    pcStack_2c = FUN_008b4920;
    puStack_28 = (undefined4 *)0x0;
    pcStack_50 = FUN_008b4920;
    uStack_4c = 0;
    uStack_48 = (ulonglong)uStack_3c << 0x20;
    puStack_40 = param_1;
    param_3 = (undefined4 *)FUN_008ab960(&param_2,&pcStack_50);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x29);
    cVar3 = FUN_01679300(param_3);
    if (cVar3 != '\0') {
      FUN_01679490();
      FUN_016791c0(param_3);
    }
    if (param_2 != 0) {
      piVar1 = (int *)(param_2 + 4);
      LOCK();
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        FUN_01674ea0(param_2);
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14542 ; VA 0x008ae320 ; FUN_008ae320 */

void __fastcall FUN_008ae320(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 14543 ; VA 0x008ae380 ; thunk_FUN_00a970a0 */

void __fastcall thunk_FUN_00a970a0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::WorldRoot::vftable;
  param_1[0x16] = RBX::WorldRoot::vftable;
  param_1[0x1d] = RBX::WorldRoot::vftable;
  param_1[0x51] = RBX::WorldRoot::vftable;
  param_1[0x52] = RBX::WorldRoot::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) = RBX::WorldRoot::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0x198
  ;
  uStack_8 = 0;
  FUN_01679490();
  iVar4 = param_1[0x79];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  FUN_00577ac0();
  piVar1 = (int *)param_1[0x75];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0x73];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uStack_8 = 1;
  FUN_01674ea0(param_1[0x6f]);
  param_1[0x6f] = 0;
  param_1[0x70] = 0;
  param_1[0x71] = 0;
  iVar4 = param_1[0x6d];
  if (iVar4 != 0) {
    FUN_00bbad20();
    FUN_01674ea0(iVar4,0x760);
  }
  FUN_00577ac0();
  FUN_00577ac0();
  FUN_00c3e210();
  param_1[0x51] = RBX::ICameraOwner::vftable;
  FUN_00b648f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14544 ; VA 0x008ae390 ; FUN_008ae390 */

void __fastcall FUN_008ae390(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x10);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x008ae3b9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 14545 ; VA 0x008ae3c0 ; FUN_008ae3c0 */

void __fastcall FUN_008ae3c0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 4) != 0) {
    if ((*(char *)(param_1 + 9) != '\0') &&
       (piVar2 = *(int **)(*(int *)(param_1 + 4) + 0xc), piVar2 != (int *)0x0)) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x10);
  }
  return;
}



/* FUNCTION 14546 ; VA 0x008ae410 ; FUN_008ae410 */

void __fastcall FUN_008ae410(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_008b20f0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 14547 ; VA 0x008ae490 ; FUN_008ae490 */

void __fastcall FUN_008ae490(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_008b20f0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 14548 ; VA 0x008ae4a0 ; FUN_008ae4a0 */

void __fastcall FUN_008ae4a0(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  iVar4 = *param_1;
  if (iVar4 != 0) {
    iVar5 = param_1[1];
    if (iVar4 != iVar5) {
      piVar6 = (int *)(iVar4 + 0x38);
      do {
        iVar1 = piVar6[-2];
        if (iVar1 != 0) {
          uVar3 = ((*piVar6 - iVar1) / 0x1c) * 0x1c;
          iVar2 = iVar1;
          if (0xfff < uVar3) {
            iVar2 = *(int *)(iVar1 + -4);
            uVar3 = uVar3 + 0x23;
            if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_008ae59e;
          }
          FUN_01674ea0(iVar2,uVar3);
          piVar6[-2] = 0;
          piVar6[-1] = 0;
          *piVar6 = 0;
        }
        iVar4 = iVar4 + 0x3c;
        piVar6 = piVar6 + 0xf;
      } while (iVar4 != iVar5);
      iVar4 = *param_1;
    }
    uVar3 = ((param_1[2] - iVar4) / 0x3c) * 0x3c;
    iVar5 = iVar4;
    if (0xfff < uVar3) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar5) - 4U) {
LAB_008ae59e:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 14549 ; VA 0x008ae5b0 ; FUN_008ae5b0 */

void __fastcall FUN_008ae5b0(int *param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint *puVar5;
  int iVar6;
  int iVar7;
  
  iVar6 = *param_1;
  if (iVar6 != 0) {
    iVar7 = param_1[1];
    if (iVar6 != iVar7) {
      puVar5 = (uint *)(iVar6 + 0x50);
      do {
        uVar4 = *puVar5;
        if (0xf < uVar4) {
          uVar1 = puVar5[-5];
          uVar3 = uVar4 + 1;
          uVar2 = uVar1;
          if (0xfff < uVar3) {
            uVar2 = *(uint *)(uVar1 - 4);
            uVar3 = uVar4 + 0x24;
            if (0x1f < (uVar1 - uVar2) - 4) goto LAB_008ae6cc;
          }
          FUN_01674ea0(uVar2,uVar3);
        }
        puVar5[-1] = 0;
        *puVar5 = 0xf;
        *(undefined *)(puVar5 + -5) = 0;
        uVar4 = puVar5[-6];
        if (0xf < uVar4) {
          uVar1 = puVar5[-0xb];
          uVar3 = uVar4 + 1;
          uVar2 = uVar1;
          if (0xfff < uVar3) {
            uVar2 = *(uint *)(uVar1 - 4);
            uVar3 = uVar4 + 0x24;
            if (0x1f < (uVar1 - uVar2) - 4) goto LAB_008ae6cc;
          }
          FUN_01674ea0(uVar2,uVar3);
        }
        puVar5[-7] = 0;
        iVar6 = iVar6 + 0x54;
        puVar5[-6] = 0xf;
        *(undefined *)(puVar5 + -0xb) = 0;
        puVar5 = puVar5 + 0x15;
      } while (iVar6 != iVar7);
      iVar6 = *param_1;
    }
    uVar4 = ((param_1[2] - iVar6) / 0x54) * 0x54;
    iVar7 = iVar6;
    if (0xfff < uVar4) {
      iVar7 = *(int *)(iVar6 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar6 - iVar7) - 4U) {
LAB_008ae6cc:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar4);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 14550 ; VA 0x008ae6e0 ; FUN_008ae6e0 */

void __fastcall FUN_008ae6e0(undefined4 *param_1)

{
  *param_1 = RBX::AdvArrowToolBase::vftable;
  FUN_00777020();
  FUN_00f31fb0();
  FUN_008ae710();
  return;
}



/* FUNCTION 14551 ; VA 0x008ae710 ; FUN_008ae710 */

void __fastcall FUN_008ae710(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::ArrowToolBase::vftable;
  if (DAT_01ee41f0 != '\0') {
    FUN_016774b0(DAT_01ee41f0,"ArrowTool destroyed: %p",param_1);
  }
  FUN_008ae7f0();
  FUN_008600a0();
  FUN_008600a0();
  FUN_008600a0();
  FUN_008600a0();
  FUN_008600a0();
  FUN_008600a0();
  FUN_00f29d90();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14552 ; VA 0x008ae7b0 ; FUN_008ae7b0 */

void FUN_008ae7b0(void)

{
  FUN_008afe50();
  FUN_00617ad0();
  FUN_008afdc0();
  return;
}



/* FUNCTION 14553 ; VA 0x008ae7d0 ; FUN_008ae7d0 */

void __fastcall FUN_008ae7d0(int param_1)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 0x10);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
                    /* WARNING: Could not recover jumptable at 0x008ae7e3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar1 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 14554 ; VA 0x008ae7f0 ; FUN_008ae7f0 */

void __fastcall FUN_008ae7f0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_008ae5b0();
  return;
}



/* FUNCTION 14555 ; VA 0x008ae850 ; FUN_008ae850 */

void FUN_008ae850(void)

{
  FUN_008600a0();
  FUN_008600a0();
  FUN_008600a0();
  FUN_008600a0();
  FUN_008600a0();
  FUN_008600a0();
  return;
}



/* FUNCTION 14556 ; VA 0x008ae8a0 ; FUN_008ae8a0 */

void __fastcall FUN_008ae8a0(undefined4 *param_1)

{
  *param_1 = RBX::IHasLocation::vftable;
  return;
}



/* FUNCTION 14557 ; VA 0x008ae8b0 ; FUN_008ae8b0 */

void __fastcall FUN_008ae8b0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x50);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x3c);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_008ae939;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x4c) = 0;
  *(undefined4 *)(param_1 + 0x50) = 0xf;
  *(undefined *)(param_1 + 0x3c) = 0;
  uVar1 = *(uint *)(param_1 + 0x38);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x24);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_008ae939:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 0x38) = 0xf;
  *(undefined *)(param_1 + 0x24) = 0;
  return;
}



/* FUNCTION 14558 ; VA 0x008ae940 ; FUN_008ae940 */

void __fastcall FUN_008ae940(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0x28);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x30) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_008aea21;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x28) = 0;
    *(undefined4 *)(param_1 + 0x2c) = 0;
    *(undefined4 *)(param_1 + 0x30) = 0;
  }
  iVar1 = *(int *)(param_1 + 0x1c);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x24) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_008aea21;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x1c) = 0;
    *(undefined4 *)(param_1 + 0x20) = 0;
    *(undefined4 *)(param_1 + 0x24) = 0;
  }
  iVar1 = *(int *)(param_1 + 0x10);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x18) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_008aea21:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x18) = 0;
  }
  return;
}



/* FUNCTION 14559 ; VA 0x008aea30 ; FUN_008aea30 */

void __fastcall FUN_008aea30(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0152dda0(*param_1,param_1[1],param_1[2],param_1[3]);
  if (DAT_01d7ad40 != '\0') {
    FUN_01532d10(*param_1,param_1[1],param_1[2],param_1[3]);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14560 ; VA 0x008aea90 ; FUN_008aea90 */

void __fastcall FUN_008aea90(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd050;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Workspace::vftable;
  param_1[0x16] = RBX::Workspace::vftable;
  param_1[0x1d] = RBX::Workspace::vftable;
  param_1[0x51] = RBX::Workspace::vftable;
  param_1[0x52] = RBX::Workspace::vftable;
  param_1[0x7a] = RBX::Workspace::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) = RBX::Workspace::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0x300
  ;
  iVar3 = param_1[0xab];
  if (iVar3 != 0) {
    FUN_00f2ec60();
    FUN_01674ea0(iVar3,0x778);
  }
  iVar3 = param_1[0x85];
  if (iVar3 != 0) {
    FUN_00617ad0();
    FUN_008b2160();
    FUN_01674ea0(iVar3,0x3c);
    param_1[0x85] = 0;
  }
  if (DAT_01ee41ef != '\0') {
    FUN_016774b0(DAT_01ee41ef,"Workspace destroyed: %p",param_1);
  }
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = param_1[0xd1];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  if (param_1[0xcd] != 0) {
    FUN_01674ea0(param_1[0xcd],4);
  }
  piVar1 = (int *)param_1[0xcc];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[2] + -1;
    piVar1[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  piVar1 = (int *)param_1[0xc9];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_008ae410();
  FUN_008ae410();
  uStack_8 = 1;
  FUN_01674ea0(param_1[0xa8]);
  param_1[0xa8] = 0;
  param_1[0xa9] = 0;
  param_1[0xaa] = 0;
  FUN_00641040();
  piVar1 = (int *)param_1[0xa4];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0xa2];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0xa0];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if ((undefined4 *)param_1[0x9a] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x9a])(1);
  }
  piVar1 = (int *)param_1[0x99];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0x97];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0x95];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0x91];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0x87];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uStack_8 = 2;
  FUN_01674ea0(param_1[0x82]);
  param_1[0x82] = 0;
  param_1[0x83] = 0;
  param_1[0x84] = 0;
  uStack_8 = 3;
  FUN_01679490();
  iVar3 = param_1[0x81];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 4;
  FUN_01679490();
  iVar3 = param_1[0x80];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 5;
  FUN_01679490();
  iVar3 = param_1[0x7f];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_00a970a0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14561 ; VA 0x008aeed0 ; FUN_008aeed0 */

int __fastcall FUN_008aeed0(int *param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1[1] != 0) {
    return param_1[1];
  }
  iVar1 = *param_1;
  if (iVar1 != 0) {
    iVar2 = *(int *)(iVar1 + 0x34);
    if ((iVar2 != 0) && (iVar1 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
      iVar1 = FUN_005c8ac0();
    }
    if ((iVar1 != 0) &&
       (iVar1 = *(int *)(iVar1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_005c3230();
      goto LAB_008aef32;
    }
  }
  uVar3 = 0;
LAB_008aef32:
  piVar4 = (int *)FUN_0060dcd0(auStack_c,uVar3);
  iVar1 = *piVar4;
  iVar2 = piVar4[1];
  *piVar4 = 0;
  piVar4[1] = 0;
  param_1[1] = iVar1;
  piVar4 = (int *)param_1[2];
  param_1[2] = iVar2;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar1 = piVar4[1] + -1;
    piVar4[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar1 = piVar4[2] + -1;
      piVar4[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_8[1] + -1;
    piStack_8[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar4 = piStack_8 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  return param_1[1];
}



/* FUNCTION 14562 ; VA 0x008aefc0 ; FUN_008aefc0 */

undefined4 * __thiscall FUN_008aefc0(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  undefined4 uVar1;
  
  uVar1 = *param_1;
  if (param_3 != 0) {
    do {
      *param_2 = 0;
      param_2[1] = 0;
      param_2[2] = 0;
      param_2[3] = 0;
      param_2[5] = 0xffffffff;
      param_2 = param_2 + 6;
      param_3 = param_3 + -1;
    } while (param_3 != 0);
  }
  FUN_00602f40(param_2,param_2,uVar1);
  return param_2;
}



/* FUNCTION 14563 ; VA 0x008af010 ; FUN_008af010 */

void __thiscall FUN_008af010(int *param_1,int param_2)

{
  char cVar1;
  undefined4 *puVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  bool bVar11;
  int *piStack_c;
  int *piStack_8;
  
  iVar8 = *param_1;
  piStack_8 = param_1;
  piStack_c = (int *)FUN_00b06640(param_2);
  puVar2 = *(undefined4 **)(iVar8 + 4);
  if (*(undefined4 **)(iVar8 + 8) == puVar2) {
    FUN_0063d9b0(puVar2,&piStack_c);
  }
  else {
    *puVar2 = piStack_c;
    *(int *)(iVar8 + 4) = *(int *)(iVar8 + 4) + 4;
  }
  piVar5 = (int *)FUN_00c15a50();
  piStack_c = piVar5;
joined_r0x008af059:
  if (piVar5 == (int *)0x0) {
    return;
  }
  piVar3 = (int *)param_1[1];
  iVar8 = *piVar3;
  if ((iVar8 != piVar3[1]) && (piVar5 != (int *)piVar3[4])) {
    uVar6 = ((uint)piVar5 >> 3) + (int)piVar5;
    uVar9 = (piVar3[1] - iVar8 >> 2) - 1;
    uVar10 = 0;
    do {
      uVar6 = uVar6 & uVar9;
      piVar4 = *(int **)(iVar8 + uVar6 * 4);
      if (piVar4 == piVar5) goto LAB_008af1dc;
      if (piVar4 == (int *)piVar3[4]) break;
      iVar8 = *piVar3;
      uVar6 = uVar6 + 1 + uVar10;
      uVar10 = uVar10 + 1;
    } while (uVar10 <= uVar9);
  }
  if ((uint)((piVar3[1] - *piVar3 >> 2) * 3) >> 2 <= (uint)piVar3[3]) {
    FUN_006286d0();
  }
  FUN_00620c30(&piStack_c);
  iVar8 = piVar5[0xb];
  if (param_2 == iVar8) {
    iVar8 = piVar5[0xc];
  }
  cVar1 = *(char *)(piStack_8 + 2);
  iVar7 = FUN_00c15700();
  if (cVar1 == '\0') {
    bVar11 = iVar7 == piStack_8[3];
  }
  else {
    bVar11 = iVar7 == 0;
  }
  if ((iVar8 != 0) && (bVar11)) goto code_r0x008af0fc;
  goto LAB_008af1dc;
code_r0x008af0fc:
  iVar8 = FUN_00ca12e0();
  param_1 = piStack_8;
  if (iVar8 == 0) goto joined_r0x008af059;
  iVar7 = (**(code **)(*piVar5 + 0x10))();
  if ((iVar7 - 1U < 0xb) && (iVar7 != 4)) {
    piStack_c = (int *)(iVar8 + -0x70);
    iVar8 = *piStack_8;
  }
  else {
    iVar7 = (**(code **)(*piVar5 + 0x10))();
    if (iVar7 != 4) {
      iVar7 = (**(code **)(*piVar5 + 0x10))();
      if (iVar7 - 0xcU < 0xe) {
        piStack_c = (int *)(iVar8 + -0x54);
        iVar8 = *piStack_8;
        puVar2 = *(undefined4 **)(iVar8 + 4);
        if (*(undefined4 **)(iVar8 + 8) == puVar2) {
          FUN_006030d0(puVar2,&piStack_c);
        }
        else {
          *puVar2 = piStack_c;
          *(int *)(iVar8 + 4) = *(int *)(iVar8 + 4) + 4;
        }
        iVar8 = FUN_00ca5a50();
        if (iVar8 != 0) {
          piStack_c = (int *)FUN_00ca5a50();
          FUN_00646760(&piStack_c);
        }
        iVar8 = FUN_00ca5ab0();
        if (iVar8 != 0) {
          piStack_c = (int *)FUN_00ca5ab0();
          FUN_00646760(&piStack_c);
        }
      }
      goto LAB_008af1dc;
    }
    piStack_c = (int *)(iVar8 + -0x54);
    iVar8 = *piStack_8;
  }
  puVar2 = *(undefined4 **)(iVar8 + 4);
  if (*(undefined4 **)(iVar8 + 8) == puVar2) {
    FUN_0063d9b0(puVar2,&piStack_c);
  }
  else {
    *puVar2 = piStack_c;
    *(int *)(iVar8 + 4) = *(int *)(iVar8 + 4) + 4;
  }
LAB_008af1dc:
  piVar5 = (int *)FUN_00c16250(piVar5);
  piStack_c = piVar5;
  param_1 = piStack_8;
  goto joined_r0x008af059;
}



/* FUNCTION 14564 ; VA 0x008af200 ; FUN_008af200 */

void __thiscall FUN_008af200(int *param_1,int param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  char cVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  int *piVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  int *piStack_c;
  int *piStack_8;
  
  piStack_8 = param_1;
  piVar4 = (int *)FUN_00c15a50();
  piStack_c = piVar4;
joined_r0x008af21c:
  if (piVar4 == (int *)0x0) {
    return;
  }
  piVar1 = (int *)param_1[1];
  iVar8 = *piVar1;
  if ((iVar8 != piVar1[1]) && (piVar4 != (int *)piVar1[4])) {
    uVar5 = ((uint)piVar4 >> 3) + (int)piVar4;
    uVar9 = (piVar1[1] - iVar8 >> 2) - 1;
    uVar10 = 0;
    do {
      uVar5 = uVar5 & uVar9;
      piVar7 = *(int **)(iVar8 + uVar5 * 4);
      if (piVar7 == piVar4) goto LAB_008af3ac;
      if (piVar7 == (int *)piVar1[4]) break;
      iVar8 = *piVar1;
      uVar5 = uVar5 + 1 + uVar10;
      uVar10 = uVar10 + 1;
    } while (uVar10 <= uVar9);
  }
  if ((uint)((piVar1[1] - *piVar1 >> 2) * 3) >> 2 <= (uint)piVar1[3]) {
    FUN_006286d0();
  }
  FUN_00620c30(&piStack_c);
  iVar8 = piVar4[0xb];
  if (param_2 == iVar8) {
    iVar8 = piVar4[0xc];
  }
  if ((iVar8 != 0) && (cVar3 = FUN_00c14800(), cVar3 != '\0')) goto code_r0x008af2a8;
  goto LAB_008af3ac;
code_r0x008af2a8:
  iVar6 = FUN_00ca12e0();
  param_1 = piStack_8;
  if (iVar6 == 0) goto joined_r0x008af21c;
  piVar7 = (int *)FUN_00b06640(iVar8);
  piVar1 = piStack_8;
  if (piVar7 != (int *)0x0) {
    iVar8 = *piStack_8;
    puVar2 = *(undefined4 **)(iVar8 + 4);
    piStack_c = piVar7;
    if (*(undefined4 **)(iVar8 + 8) == puVar2) {
      FUN_006030d0(puVar2,&piStack_c);
    }
    else {
      *puVar2 = piVar7;
      *(int *)(iVar8 + 4) = *(int *)(iVar8 + 4) + 4;
    }
  }
  iVar8 = (**(code **)(*piVar4 + 0x10))();
  if ((iVar8 - 1U < 0xb) && (iVar8 != 4)) {
    piStack_c = (int *)(iVar6 + -0x70);
  }
  else {
    iVar8 = (**(code **)(*piVar4 + 0x10))();
    if (iVar8 != 4) {
      iVar8 = (**(code **)(*piVar4 + 0x10))();
      if (iVar8 - 0xcU < 0xe) {
        iVar8 = *piVar1;
        piStack_c = (int *)(iVar6 + -0x54);
        puVar2 = *(undefined4 **)(iVar8 + 4);
        if (*(undefined4 **)(iVar8 + 8) == puVar2) {
          FUN_006030d0(puVar2,&piStack_c);
        }
        else {
          *puVar2 = piStack_c;
          *(int *)(iVar8 + 4) = *(int *)(iVar8 + 4) + 4;
        }
        iVar8 = FUN_00ca5a50();
        if (iVar8 != 0) {
          piStack_c = (int *)FUN_00ca5a50();
          FUN_00646760(&piStack_c);
        }
        iVar8 = FUN_00ca5ab0();
        if (iVar8 != 0) {
          piStack_c = (int *)FUN_00ca5ab0();
          FUN_00646760(&piStack_c);
        }
      }
      goto LAB_008af3ac;
    }
    piStack_c = (int *)(iVar6 + -0x54);
  }
  iVar8 = *piVar1;
  puVar2 = *(undefined4 **)(iVar8 + 4);
  if (*(undefined4 **)(iVar8 + 8) == puVar2) {
    FUN_0063d9b0(puVar2,&piStack_c);
  }
  else {
    *puVar2 = piStack_c;
    *(int *)(iVar8 + 4) = *(int *)(iVar8 + 4) + 4;
  }
LAB_008af3ac:
  piVar4 = (int *)FUN_00c16250(piVar4);
  piStack_c = piVar4;
  param_1 = piStack_8;
  goto joined_r0x008af21c;
}



/* FUNCTION 14565 ; VA 0x008af3d0 ; FUN_008af3d0 */

/* WARNING: Removing unreachable block (ram,0x008af422) */
/* WARNING: Removing unreachable block (ram,0x008af432) */
/* WARNING: Removing unreachable block (ram,0x008af438) */

void * __thiscall FUN_008af3d0(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bd078;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 14566 ; VA 0x008af4a3 ; Catch@008af4a3 */

undefined * Catch_008af4a3(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_008af4b4;
}



/* FUNCTION 14567 ; VA 0x008af4d0 ; FUN_008af4d0 */

void FUN_008af4d0(int *param_1)

{
  if (param_1 != (int *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x008af4e4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*param_1 + 0x68))();
    return;
  }
  return;
}



/* FUNCTION 14568 ; VA 0x008af4f3 ; FUN_008af4f3 */

void FUN_008af4f3(void)

{
  FUN_008af710();
  return;
}



/* FUNCTION 14569 ; VA 0x008af501 ; FUN_008af501 */

void FUN_008af501(void)

{
  FUN_008af710();
  return;
}



/* FUNCTION 14570 ; VA 0x008af50c ; FUN_008af50c */

void FUN_008af50c(void)

{
  FUN_008af710();
  return;
}



/* FUNCTION 14571 ; VA 0x008af517 ; FUN_008af517 */

void FUN_008af517(void)

{
  FUN_008afc70();
  return;
}



/* FUNCTION 14572 ; VA 0x008af525 ; FUN_008af525 */

void FUN_008af525(void)

{
  FUN_008afc70();
  return;
}



/* FUNCTION 14573 ; VA 0x008af530 ; FUN_008af530 */

void FUN_008af530(void)

{
  FUN_008afc70();
  return;
}



/* FUNCTION 14574 ; VA 0x008af540 ; FUN_008af540 */

int __thiscall FUN_008af540(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 14575 ; VA 0x008af590 ; FUN_008af590 */

int __thiscall FUN_008af590(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 14576 ; VA 0x008af5f0 ; FUN_008af5f0 */

int __thiscall FUN_008af5f0(int param_1,byte param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 14577 ; VA 0x008af660 ; FUN_008af660 */

undefined4 __thiscall FUN_008af660(undefined4 param_1,byte param_2)

{
  FUN_008ae320();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 14578 ; VA 0x008af690 ; FUN_008af690 */

int __thiscall FUN_008af690(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 14579 ; VA 0x008af6d0 ; FUN_008af6d0 */

int __thiscall FUN_008af6d0(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),1);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 14580 ; VA 0x008af710 ; FUN_008af710 */

int __thiscall FUN_008af710(int param_1,byte param_2)

{
  FUN_00a970a0();
  *(undefined ***)(param_1 + 0x1ec) = RBX::IHasLocation::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1f0);
  }
  return param_1;
}



/* FUNCTION 14581 ; VA 0x008af740 ; FUN_008af740 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_008af740(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::AdvArrowToolJointCreationMode>::vftable;
  _DAT_01f2ccd4 = _DAT_01f2ccd4 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 14582 ; VA 0x008af770 ; FUN_008af770 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_008af770(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Workspace::InterpolationThrottlingMode>::vftable;
  _DAT_01edfe48 = _DAT_01edfe48 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 14583 ; VA 0x008af7a0 ; FUN_008af7a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_008af7a0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Workspace::MeshPartHeads>::vftable;
  _DAT_01edfe50 = _DAT_01edfe50 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 14584 ; VA 0x008af7d0 ; FUN_008af7d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_008af7d0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::PhysicsSimulationRate>::vftable;
  _DAT_01edfe40 = _DAT_01edfe40 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 14585 ; VA 0x008af800 ; FUN_008af800 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_008af800(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Workspace::StreamingPauseMode>::vftable;
  _DAT_01edfe38 = _DAT_01edfe38 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 14586 ; VA 0x008af830 ; FUN_008af830 */

int __thiscall FUN_008af830(int param_1,byte param_2)

{
  if (*(undefined4 **)(param_1 + 0x38) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x38))(1);
  }
  FUN_009ca940();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x40);
  }
  return param_1;
}



/* FUNCTION 14587 ; VA 0x008af870 ; FUN_008af870 */

undefined4 * __thiscall FUN_008af870(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
             ::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 14588 ; VA 0x008af8a0 ; FUN_008af8a0 */

undefined4 * __thiscall FUN_008af8a0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<enum_RBX::Workspace::InterpolationThrottlingMode>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 14589 ; VA 0x008af8d0 ; FUN_008af8d0 */

undefined4 * __thiscall FUN_008af8d0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Workspace::MeshPartHeads>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 14590 ; VA 0x008af900 ; FUN_008af900 */

undefined4 * __thiscall FUN_008af900(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::PhysicsSimulationRate>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 14591 ; VA 0x008af930 ; FUN_008af930 */

undefined4 * __thiscall FUN_008af930(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Workspace::StreamingPauseMode>::
             GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 14592 ; VA 0x008af960 ; FUN_008af960 */

undefined4 * __thiscall FUN_008af960(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<int>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 14593 ; VA 0x008af990 ; FUN_008af990 */

undefined4 * __thiscall FUN_008af990(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<float>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 14594 ; VA 0x008af9c0 ; FUN_008af9c0 */

undefined4 * __thiscall FUN_008af9c0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<double>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 14595 ; VA 0x008af9f0 ; FUN_008af9f0 */

undefined4 * __thiscall FUN_008af9f0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Camera*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 14596 ; VA 0x008afa20 ; FUN_008afa20 */

undefined4 * __thiscall FUN_008afa20(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<bool>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 14597 ; VA 0x008afa50 ; FUN_008afa50 */

int __thiscall FUN_008afa50(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x20);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x30);
  }
  return param_1;
}



/* FUNCTION 14598 ; VA 0x008afaa0 ; FUN_008afaa0 */

undefined4 * __thiscall FUN_008afaa0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::AdvArrowToolBase::vftable;
  FUN_00777020();
  FUN_00f31fb0();
  FUN_008ae710();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x7b4);
  }
  return param_1;
}



/* FUNCTION 14599 ; VA 0x008afaf0 ; FUN_008afaf0 */

undefined4 __thiscall FUN_008afaf0(undefined4 param_1,byte param_2)

{
  FUN_008ae710();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x768);
  }
  return param_1;
}



/* FUNCTION 14600 ; VA 0x008afb20 ; FUN_008afb20 */

undefined4 * __thiscall FUN_008afb20(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Camera*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 14601 ; VA 0x008afb50 ; FUN_008afb50 */

undefined4 * __thiscall FUN_008afb50(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<enum_RBX::Workspace::InterpolationThrottlingMode>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 14602 ; VA 0x008afb80 ; FUN_008afb80 */

undefined4 * __thiscall FUN_008afb80(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Workspace::MeshPartHeads>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 14603 ; VA 0x008afbb0 ; FUN_008afbb0 */

undefined4 * __thiscall FUN_008afbb0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::PhysicsSimulationRate>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 14604 ; VA 0x008afbe0 ; FUN_008afbe0 */

undefined4 * __thiscall FUN_008afbe0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Workspace::StreamingPauseMode>::
             GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 14605 ; VA 0x008afc10 ; FUN_008afc10 */

undefined4 __thiscall FUN_008afc10(undefined4 param_1,byte param_2)

{
  FUN_0115a840();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x24);
  }
  return param_1;
}



/* FUNCTION 14606 ; VA 0x008afc40 ; FUN_008afc40 */

undefined4 * __thiscall FUN_008afc40(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::IHasLocation::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 14607 ; VA 0x008afc70 ; FUN_008afc70 */

int __thiscall FUN_008afc70(int param_1,byte param_2)

{
  FUN_008aea90();
  *(undefined ***)(param_1 + 0x354) = RBX::IHasLocation::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x358);
  }
  return param_1;
}



/* FUNCTION 14608 ; VA 0x008afcb0 ; FUN_008afcb0 */

void __fastcall FUN_008afcb0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    thunk_FUN_00577ac0();
    FUN_01674ea0(iVar1,0xc);
  }
  return;
}



/* FUNCTION 14609 ; VA 0x008afcd0 ; FUN_008afcd0 */

void __fastcall FUN_008afcd0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_0115a840();
    FUN_01674ea0(iVar1,0x24);
  }
  return;
}



/* FUNCTION 14610 ; VA 0x008afcf0 ; FUN_008afcf0 */

void __fastcall FUN_008afcf0(int param_1)

{
  if (*(int **)(param_1 + 0xc) != (int *)0x0) {
    (**(code **)(**(int **)(param_1 + 0xc) + 0x68))(1);
  }
  return;
}



/* FUNCTION 14611 ; VA 0x008afd00 ; FUN_008afd00 */

void __fastcall FUN_008afd00(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(param_1 + 0x10))(param_1 + 0x1c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14612 ; VA 0x008afd40 ; thunk_FUN_008bbd90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_008bbd90(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bdc16;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edfff4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edfff4);
    if (DAT_01edfff4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("StreamingPauseMode");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01edff90 = RBX::Reflection::EnumDesc<enum_RBX::Workspace::StreamingPauseMode>::vftable;
      FUN_009caf20(&DAT_01d62ddc,3);
      FUN_016f3654(&LAB_018817c0);
      FUN_016f37bf(&DAT_01edfff4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edff90;
}



/* FUNCTION 14613 ; VA 0x008afd50 ; FUN_008afd50 */

int __thiscall FUN_008afd50(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = FUN_0170d8dd(param_2 + 4,0x1da5e58);
  if (iVar1 == 0) {
    return param_1 + 0xc;
  }
  return 0;
}



/* FUNCTION 14614 ; VA 0x008afd80 ; FUN_008afd80 */

int __thiscall FUN_008afd80(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = FUN_0170d8dd(param_2 + 4,0x1da596c);
  if (iVar1 == 0) {
    return param_1 + 0x10;
  }
  return 0;
}



/* FUNCTION 14615 ; VA 0x008afdb0 ; FUN_008afdb0 */

void __fastcall FUN_008afdb0(undefined4 param_1)

{
  code *pcVar1;
  
  FUN_016dfddb(param_1);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 14616 ; VA 0x008afdc0 ; FUN_008afdc0 */

void __fastcall FUN_008afdc0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_0072a1c0();
        iVar2 = iVar2 + 0x1c;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x1c) * 0x1c;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 14617 ; VA 0x008afe50 ; FUN_008afe50 */

void __fastcall FUN_008afe50(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_008aab80(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x34) * 0x34;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 14618 ; VA 0x008afed0 ; FUN_008afed0 */

void __thiscall FUN_008afed0(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  
  uVar1 = *(undefined4 *)(param_1 + 0x20c);
  puVar2 = (undefined4 *)FUN_008b3820();
  *puVar2 = uVar1;
  FUN_007c5360(&param_2);
  return;
}



/* FUNCTION 14619 ; VA 0x008aff10 ; FUN_008aff10 */

bool FUN_008aff10(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_0170d75d(param_1,0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::IAdornable::RTTI_Type_Descriptor,0);
  return iVar1 != 0;
}



/* FUNCTION 14620 ; VA 0x008aff40 ; FUN_008aff40 */

undefined FUN_008aff40(undefined4 param_1)

{
  char cVar1;
  undefined uVar2;
  
  cVar1 = FUN_008a9600(param_1);
  if (cVar1 != '\0') {
    uVar2 = FUN_009a8870(param_1);
    return uVar2;
  }
  return 0;
}



/* FUNCTION 14621 ; VA 0x008aff70 ; FUN_008aff70 */

void FUN_008aff70(void)

{
  FUN_00bbbe60();
  return;
}



/* FUNCTION 14622 ; VA 0x008aff80 ; FUN_008aff80 */

void __thiscall FUN_008aff80(int *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  
  uVar2 = 0;
  piVar1 = (int *)*param_1;
  uVar3 = param_1[1] - (int)piVar1 >> 3;
  if (uVar3 != 0) {
    do {
      if (*piVar1 != param_1[4]) break;
      uVar2 = uVar2 + 1;
      piVar1 = piVar1 + 2;
    } while (uVar2 < uVar3);
  }
  *param_2 = param_1;
  param_2[1] = uVar2;
  return;
}



/* FUNCTION 14623 ; VA 0x008affc0 ; FUN_008affc0 */

int FUN_008affc0(undefined4 *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bd468;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_008ad160(*param_1,param_1[1],FUN_008ad570);
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 14624 ; VA 0x008b0030 ; FUN_008b0030 */

void __fastcall FUN_008b0030(int *param_1)

{
  if (*(char *)(param_1 + 9) != '\0') {
                    /* WARNING: Could not recover jumptable at 0x008b0038. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*param_1 + 0x60))();
    return;
  }
  return;
}



/* FUNCTION 14625 ; VA 0x008b0040 ; FUN_008b0040 */

void __fastcall FUN_008b0040(int param_1)

{
  int iVar1;
  
  *(undefined *)(param_1 + 0x271) = 0;
  iVar1 = FUN_008acdd0(param_1);
  if ((iVar1 != 0) && (*(char *)(param_1 + 0x270) == '\0')) {
    *(undefined4 *)(iVar1 + 0x5c) = 0;
  }
  return;
}



/* FUNCTION 14626 ; VA 0x008b0070 ; FUN_008b0070 */

void __thiscall FUN_008b0070(int param_1,int *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  iVar1 = *param_2;
  if (iVar1 != param_1) {
    if ((((iVar1 != 0) &&
         (iVar5 = *(int *)(iVar1 + 0xc), iVar4 = FUN_00b63e30(),
         (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
         (uint)*(ushort *)(iVar4 + 0x1da))) && (iVar5 = FUN_009ba880(iVar1), iVar5 == 0)) &&
       (iVar5 = FUN_0075d640(), iVar5 == 0)) {
      puVar2 = *(undefined4 **)(iVar1 + 0x2c);
      if (puVar2 != (undefined4 *)0x0) {
        piVar3 = (int *)puVar2[1];
        for (piVar6 = (int *)*puVar2; piVar6 != piVar3; piVar6 = piVar6 + 2) {
          if ((*piVar6 != 0) &&
             (iVar5 = *(int *)(*piVar6 + 0xc), iVar4 = FUN_00b63e30(),
             (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
             (uint)*(ushort *)(iVar4 + 0x1da))) goto LAB_008b0137;
        }
      }
      iVar5 = FUN_00980070(iVar1);
      if (iVar5 != 0) {
        FUN_0092e970();
      }
      FUN_008b2290(iVar1);
    }
LAB_008b0137:
    iVar1 = *param_2;
    if (((iVar1 != 0) &&
        (iVar5 = *(int *)(iVar1 + 0xc), iVar4 = FUN_00c8dce0(),
        (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da))) && (iVar5 = FUN_0075d640(), iVar5 == 0)) {
      FUN_008b2290(iVar1);
    }
    iVar1 = *param_2;
    if (((iVar1 != 0) &&
        (iVar5 = *(int *)(iVar1 + 0xc), iVar4 = FUN_00bd36f0(),
        (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da))) && (iVar5 = FUN_0075d640(), iVar5 == 0)) {
      FUN_008b2290(iVar1);
    }
  }
  return;
}



/* FUNCTION 14627 ; VA 0x008b01d0 ; FUN_008b01d0 */

int __fastcall FUN_008b01d0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x1c8);
  if (iVar4 != 0) {
    if (DAT_01d6517b != '\0') {
      FUN_016774b0(DAT_01d6517b,"Clearing terrain (from client replicator?)",0);
      iVar4 = *(int *)(param_1 + 0x1c8);
    }
    *(undefined *)(iVar4 + 0x22) = 0;
    iVar4 = FUN_008a65e0(0,0);
    *(undefined4 *)(param_1 + 0x1c8) = 0;
    piVar3 = *(int **)(param_1 + 0x1cc);
    *(undefined4 *)(param_1 + 0x1cc) = 0;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 1;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x008b0252. Too many branches */
                    /* WARNING: Treating indirect jump as call */
          iVar4 = (**(code **)(*piVar3 + 4))();
          return iVar4;
        }
      }
    }
  }
  return iVar4;
}



/* FUNCTION 14628 ; VA 0x008b0260 ; FUN_008b0260 */

void FUN_008b0260(undefined4 param_1)

{
  FUN_00973950(param_1,0);
  return;
}



/* FUNCTION 14629 ; VA 0x008b0280 ; FUN_008b0280 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float * __thiscall FUN_008b0280(int param_1,float *param_2)

{
  float fVar1;
  int iVar2;
  int *piVar3;
  float *pfVar4;
  int iVar5;
  float fVar6;
  float fVar7;
  undefined auStack_28 [20];
  undefined4 uStack_14;
  float fStack_8;
  
  iVar2 = *(int *)(param_1 + 0x1b4);
  *param_2 = 3.4028235e+38;
  param_2[1] = 3.4028235e+38;
  param_2[2] = 3.4028235e+38;
  param_2[3] = -3.4028235e+38;
  param_2[4] = -3.4028235e+38;
  param_2[5] = -3.4028235e+38;
  if (DAT_01d69070 == '\0') {
    pfVar4 = (float *)(**(code **)(**(int **)(*(int *)(iVar2 + 0x6ac) + 0x154) + 0x68))(auStack_28);
  }
  else {
    pfVar4 = (float *)FUN_00cdfe10(auStack_28);
  }
  fVar6 = pfVar4[1];
  fVar7 = pfVar4[2];
  fVar1 = pfVar4[3];
  *param_2 = *pfVar4;
  param_2[1] = fVar6;
  param_2[2] = fVar7;
  param_2[3] = fVar1;
  *(undefined8 *)(param_2 + 4) = *(undefined8 *)(pfVar4 + 4);
  piVar3 = *(int **)(param_1 + 0x1c8);
  if (piVar3 != (int *)0x0) {
    iVar2 = piVar3[3];
    iVar5 = FUN_00af0010();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
        (uint)*(ushort *)(iVar5 + 0x1da)) {
      pfVar4 = (float *)(**(code **)(*piVar3 + 0xa4))(auStack_28);
      fVar6 = param_2[2];
      if (pfVar4[2] <= param_2[2]) {
        fVar6 = pfVar4[2];
      }
      fVar7 = param_2[1];
      if (pfVar4[1] <= param_2[1]) {
        fVar7 = pfVar4[1];
      }
      fVar1 = *param_2;
      if (*pfVar4 <= *param_2) {
        fVar1 = *pfVar4;
      }
      *(ulonglong *)param_2 = CONCAT44(fVar7,fVar1);
      param_2[2] = fVar6;
      fStack_8 = param_2[5];
      if (param_2[5] <= pfVar4[5]) {
        fStack_8 = pfVar4[5];
      }
      fVar6 = param_2[4];
      if (param_2[4] <= pfVar4[4]) {
        fVar6 = pfVar4[4];
      }
      fVar7 = param_2[3];
      if (param_2[3] <= pfVar4[3]) {
        fVar7 = pfVar4[3];
      }
      *(ulonglong *)(param_2 + 3) = CONCAT44(fVar6,fVar7);
      param_2[5] = fStack_8;
    }
  }
  if (((param_2[3] < *param_2) || (param_2[4] < param_2[1])) || (param_2[5] < param_2[2])) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaf0a8) {
      FUN_016f3809(&DAT_01eaf0a8);
      if (DAT_01eaf0a8 == -1) {
        fStack_8 = 0.0;
        _DAT_01eaf098 = 0.0;
        uStack_14 = 0;
        _DAT_01eaf090 = 0;
        _DAT_01eaf09c = 0.0;
        DAT_01eaf0a0._0_4_ = 0;
        DAT_01eaf0a0._4_4_ = 0;
        FUN_016f37bf(&DAT_01eaf0a8);
      }
    }
    fVar1 = _DAT_01eaf09c;
    fVar7 = _DAT_01eaf098;
    fVar6 = DAT_01eaf090_4;
    *param_2 = _DAT_01eaf090;
    param_2[1] = fVar6;
    param_2[2] = fVar7;
    param_2[3] = fVar1;
    *(ulonglong *)(param_2 + 4) = CONCAT44(DAT_01eaf0a0._4_4_,(undefined4)DAT_01eaf0a0);
  }
  return param_2;
}



/* FUNCTION 14630 ; VA 0x008b0490 ; FUN_008b0490 */

void __fastcall FUN_008b0490(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  
  if (*(int *)(param_1 + 4) != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      piVar2 = *(int **)(*(int *)(param_1 + 4) + 0xc);
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar3 = piVar2[1] + -1;
        piVar2[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      *(undefined *)(param_1 + 9) = 0;
    }
    return;
  }
  *(undefined2 *)(param_1 + 8) = 0;
  puVar4 = (undefined4 *)FUN_01674e20(0x10);
  *(undefined4 **)(param_1 + 4) = puVar4;
  *puVar4 = 0;
  puVar4[1] = 0;
  *(undefined8 *)(puVar4 + 2) = 0;
  *(undefined *)(param_1 + 8) = 1;
  return;
}



/* FUNCTION 14631 ; VA 0x008b0500 ; FUN_008b0500 */

uint FUN_008b0500(uint param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  
  uVar2 = FUN_00a9d0e0(param_1);
  uVar4 = uVar2;
  if (uVar2 != 0) {
    iVar1 = *(int *)(uVar2 + 0xc);
    iVar3 = FUN_008aa870();
    uVar4 = (uint)*(ushort *)(iVar3 + 0x1da);
    uVar5 = 0;
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <= uVar4) {
      uVar5 = uVar2;
    }
    if ((uVar5 != 0) && (uVar5 != param_1)) {
      return CONCAT31((uint3)(byte)(*(ushort *)(iVar3 + 0x1da) >> 8),1);
    }
  }
  return uVar4 & 0xffffff00;
}



/* FUNCTION 14632 ; VA 0x008b0550 ; FUN_008b0550 */

void FUN_008b0550(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_008bbaf0();
    *param_2 = uVar3;
    iVar4 = FUN_008bbe40();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 14633 ; VA 0x008b05b0 ; FUN_008b05b0 */

void FUN_008b05b0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_008bbb80();
    *param_2 = uVar3;
    iVar4 = FUN_008bbeb0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 14634 ; VA 0x008b0610 ; FUN_008b0610 */

void FUN_008b0610(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_008bbc30();
    *param_2 = uVar3;
    iVar4 = FUN_008bbf20();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 14635 ; VA 0x008b0670 ; FUN_008b0670 */

void FUN_008b0670(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_008bbce0();
    *param_2 = uVar3;
    iVar4 = FUN_008bbf90();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 14636 ; VA 0x008b06d0 ; FUN_008b06d0 */

void FUN_008b06d0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_008bbd90();
    *param_2 = uVar3;
    iVar4 = FUN_008bc000();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 14637 ; VA 0x008b0730 ; FUN_008b0730 */

void FUN_008b0730(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_008bbaf0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14638 ; VA 0x008b0770 ; FUN_008b0770 */

void FUN_008b0770(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_008bbb80();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14639 ; VA 0x008b07b0 ; FUN_008b07b0 */

void FUN_008b07b0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_008bbc30();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14640 ; VA 0x008b07f0 ; FUN_008b07f0 */

void FUN_008b07f0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_008bbce0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14641 ; VA 0x008b0830 ; FUN_008b0830 */

void FUN_008b0830(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_008bbd90();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14642 ; VA 0x008b0870 ; FUN_008b0870 */

uint * FUN_008b0870(uint *param_1,code *param_2,code *param_3,code ***param_4)

{
  int *piVar1;
  code *pcVar2;
  code *pcVar3;
  int *piVar4;
  int iVar5;
  undefined uVar6;
  char cVar7;
  undefined4 *puVar8;
  uint uVar9;
  code *pcVar10;
  code **ppcStack_c0;
  undefined *puStack_bc;
  code *pcStack_b8;
  code *pcStack_b4;
  code *pcStack_b0;
  code **ppcStack_ac;
  undefined8 uStack_a8;
  code **ppcStack_a0;
  uint auStack_94 [2];
  code *pcStack_8c;
  code *pcStack_88;
  undefined4 uStack_74;
  int *piStack_70;
  undefined auStack_6c [4];
  int *piStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  int *piStack_5c;
  undefined4 uStack_58;
  int *piStack_54;
  code *pcStack_50;
  code *pcStack_4c;
  code *pcStack_48;
  code *pcStack_44;
  code *pcStack_40;
  code *pcStack_3c;
  undefined auStack_38 [4];
  int *piStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  uint auStack_28 [2];
  code *pcStack_20;
  code *pcStack_1c;
  code *pcStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017bd4e5;
  pvStack_10 = ExceptionList;
  uStack_64 = 0;
  ppcStack_a0 = (code **)param_1;
  iStack_8 = 0;
  uStack_a8._4_4_ = 0x8b08a7;
  ExceptionList = &pvStack_10;
  FUN_008ac440();
  ppcStack_c0 = &pcStack_20;
  iStack_8 = 0;
  uStack_64 = 1;
  pcStack_20 = FUN_00999e90;
  pcStack_1c = (code *)0x0;
  pcStack_18 = (code *)param_4;
  cVar7 = FUN_00585a40();
  if (cVar7 == '\0') {
    pcStack_b4 = pcStack_20;
    pcStack_b0 = pcStack_1c;
    ppcStack_ac = (code **)pcStack_18;
    uStack_a8._0_4_ = (int *)pcStack_14;
    puStack_bc = &DAT_01920389;
  }
  else {
    puStack_bc = (undefined *)0x0;
  }
  ppcStack_c0 = (code **)&DAT_018e42c8;
  FUN_008ac720(auStack_38);
  piVar4 = piStack_34;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_34[1] + -1;
    piStack_34[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      ppcStack_a0 = (code **)0x8b092b;
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppcStack_a0 = (code **)0x8b093b;
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  pcStack_2c = (code *)*param_1;
  ppcStack_c0 = &pcStack_20;
  pcStack_20 = FUN_009994d0;
  pcStack_1c = (code *)0x0;
  pcStack_18 = (code *)param_4;
  cVar7 = FUN_00585a40();
  if (cVar7 == '\0') {
    pcStack_b4 = pcStack_20;
    pcStack_b0 = pcStack_1c;
    ppcStack_ac = (code **)pcStack_18;
    uStack_a8._0_4_ = (int *)pcStack_14;
    puStack_bc = &DAT_01920389;
  }
  else {
    puStack_bc = (undefined *)0x0;
  }
  ppcStack_c0 = (code **)0x191ff68;
  FUN_008ac720(auStack_38);
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_34[1] + -1;
    piStack_34[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      ppcStack_a0 = (code **)0x8b09b5;
      (**(code **)*piStack_34)();
      LOCK();
      iVar5 = piStack_34[2] + -1;
      piStack_34[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppcStack_a0 = (code **)0x8b09c5;
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  pcStack_30 = (code *)&LAB_008b37d0;
  pcStack_2c = param_3;
  piStack_34 = (int *)*param_1;
  ppcStack_a0 = &pcStack_30;
  uStack_a8 = CONCAT44(0x8b09e3,(int *)uStack_a8);
  cVar7 = FUN_00585a40();
  if (cVar7 == '\0') {
    pcStack_8c = pcStack_30;
    pcStack_88 = pcStack_2c;
    auStack_94[0] = 0x1920391;
  }
  else {
    auStack_94[0] = 0;
  }
  ppcStack_a0 = (code **)auStack_94;
  iStack_8 = 2;
  uStack_a8 = CONCAT44(&pcStack_18,0x8b0a2d);
  puVar8 = (undefined4 *)FUN_008abcc0();
  uStack_64 = 3;
  param_4 = (code ***)*puVar8;
  piVar4 = (int *)puVar8[1];
  *puVar8 = 0;
  puVar8[1] = 0;
  pcStack_2c = pcStack_14;
  pcStack_40 = (code *)param_4;
  pcStack_3c = (code *)piVar4;
  if (pcStack_14 != (code *)0x0) {
    LOCK();
    iVar5 = *(int *)((int)pcStack_14 + 4) + -1;
    *(int *)((int)pcStack_14 + 4) = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      ppcStack_a0 = (code **)0x8b0a6c;
      (*(code *)**(undefined4 **)pcStack_14)();
      LOCK();
      iVar5 = *(int *)((int)pcStack_2c + 8) + -1;
      *(int *)((int)pcStack_2c + 8) = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppcStack_a0 = (code **)0x8b0a7d;
        (**(code **)(*(int *)pcStack_2c + 4))();
      }
    }
  }
  ppcStack_a0 = (code **)0x13;
  pcStack_18 = (code *)0x0;
  pcStack_14 = (code *)&DAT_0000000f;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  pcVar10 = *(code **)((int)*param_4 + 0x38);
  uStack_a8 = 0x18e42cc008b0aa6;
  FUN_005542c0();
  ppcStack_a0 = (code **)auStack_28;
  iStack_8._0_1_ = 3;
  uStack_a8 = CONCAT44(0x8b0ab3,(int *)uStack_a8);
  (*pcVar10)();
  iStack_8._0_1_ = 2;
  uVar6 = (undefined)iStack_8;
  iStack_8._0_1_ = 2;
  if (&DAT_0000000f < pcStack_14) {
    pcVar10 = pcStack_14 + 1;
    uVar9 = auStack_28[0];
    if ((code *)0xfff < pcVar10) {
      uVar9 = *(uint *)(auStack_28[0] - 4);
      pcVar10 = pcStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar9) - 4) {
        uStack_a8 = CONCAT44(&UNK_008b178b,(int *)uStack_a8);
        iStack_8._0_1_ = uVar6;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_a8 = CONCAT44(pcVar10,uVar9);
    ppcStack_ac = (code **)0x8b0ae8;
    FUN_01674ea0();
  }
  uStack_a8 = ZEXT48(piStack_34);
  ppcStack_ac = (code **)0x8b0af8;
  FUN_008a65e0();
  iStack_8._0_1_ = 4;
  if (auStack_94[0] != 0) {
    if (((auStack_94[0] & 1) == 0) && (*(code **)(auStack_94[0] & 0xfffffffe) != (code *)0x0)) {
      ppcStack_ac = &pcStack_8c;
      uStack_a8 = CONCAT44(2,ppcStack_ac);
      pcStack_b0 = (code *)0x8b0b1f;
      (**(code **)(auStack_94[0] & 0xfffffffe))();
    }
    auStack_94[0] = 0;
  }
  uStack_64 = 1;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar5 = piVar4[1] + -1;
    piVar4[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_a8 = CONCAT44(0x8b0b4e,(int *)uStack_a8);
      (**(code **)*piVar4)();
      LOCK();
      iVar5 = piVar4[2] + -1;
      piVar4[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b0b5f,(int *)uStack_a8);
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  uStack_a8 = CONCAT44("World",&uStack_60);
  ppcStack_ac = (code **)0x8b0b72;
  FUN_009ff040();
  param_4 = &ppcStack_c0;
  piStack_34 = (int *)uStack_60;
  iStack_8 = 5;
  pcStack_30 = FUN_00712f20;
  pcStack_2c = param_3;
  cVar7 = FUN_00585a40(&pcStack_30);
  puVar8 = param_4;
  if (cVar7 == '\0') {
    param_4[2] = (code **)pcStack_30;
    puVar8[3] = pcStack_2c;
    *puVar8 = &DAT_01920399;
  }
  else {
    *param_4 = (code **)0x0;
  }
  FUN_008ac5b0(&pcStack_18,"Primitives");
  param_4 = (code ***)pcStack_14;
  if (pcStack_14 != (code *)0x0) {
    LOCK();
    iVar5 = *(int *)(pcStack_14 + 4) + -1;
    *(int *)(pcStack_14 + 4) = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_a8 = CONCAT44(0x8b0bf6,(int *)uStack_a8);
      (*(code *)**(undefined4 **)pcStack_14)();
      LOCK();
      iVar5 = *(int *)((int)param_4 + 8) + -1;
      *(int *)((int)param_4 + 8) = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b0c07,(int *)uStack_a8);
        (**(code **)((int)*param_4 + 4))();
      }
    }
  }
  param_4 = &ppcStack_c0;
  piStack_34 = (int *)uStack_60;
  pcStack_30 = (code *)&LAB_008b3c60;
  pcStack_2c = param_3;
  cVar7 = FUN_00585a40(&pcStack_30);
  puVar8 = param_4;
  if (cVar7 == '\0') {
    param_4[2] = (code **)pcStack_30;
    puVar8[3] = pcStack_2c;
    *puVar8 = &DAT_01920399;
  }
  else {
    *param_4 = (code **)0x0;
  }
  FUN_008ac5b0(&pcStack_18,"Joints");
  param_4 = (code ***)pcStack_14;
  if (pcStack_14 != (code *)0x0) {
    LOCK();
    iVar5 = *(int *)(pcStack_14 + 4) + -1;
    *(int *)(pcStack_14 + 4) = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_a8 = CONCAT44(0x8b0c79,(int *)uStack_a8);
      (*(code *)**(undefined4 **)pcStack_14)();
      LOCK();
      iVar5 = *(int *)((int)param_4 + 8) + -1;
      *(int *)((int)param_4 + 8) = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b0c8a,(int *)uStack_a8);
        (**(code **)((int)*param_4 + 4))();
      }
    }
  }
  param_4 = &ppcStack_c0;
  piStack_34 = (int *)uStack_60;
  pcStack_30 = FUN_00bbdd30;
  pcStack_2c = param_3;
  cVar7 = FUN_00585a40(&pcStack_30);
  puVar8 = param_4;
  if (cVar7 == '\0') {
    param_4[2] = (code **)pcStack_30;
    puVar8[3] = pcStack_2c;
    *puVar8 = &DAT_01920399;
  }
  else {
    *param_4 = (code **)0x0;
  }
  FUN_008ac5b0(&pcStack_18,"Contacts");
  param_4 = (code ***)pcStack_14;
  if (pcStack_14 != (code *)0x0) {
    LOCK();
    iVar5 = *(int *)(pcStack_14 + 4) + -1;
    *(int *)(pcStack_14 + 4) = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_a8 = CONCAT44(0x8b0cf7,(int *)uStack_a8);
      (*(code *)**(undefined4 **)pcStack_14)();
      LOCK();
      iVar5 = *(int *)((int)param_4 + 8) + -1;
      *(int *)((int)param_4 + 8) = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b0d08,(int *)uStack_a8);
        (**(code **)((int)*param_4 + 4))();
      }
    }
  }
  if (DAT_01d62d74 != '\0') {
    piStack_34 = (int *)uStack_60;
    param_4 = (code ***)param_3;
    cVar7 = FUN_00585a40(&param_4);
    if (cVar7 == '\0') {
      pcStack_b8 = (code *)param_4;
      ppcStack_c0 = (code **)&DAT_019203a1;
    }
    else {
      ppcStack_c0 = (code **)0x0;
    }
    FUN_008ac5b0(&pcStack_18,"Non-Anchored Assemblies");
    param_4 = (code ***)pcStack_14;
    if (pcStack_14 != (code *)0x0) {
      LOCK();
      iVar5 = *(int *)(pcStack_14 + 4) + -1;
      *(int *)(pcStack_14 + 4) = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b0d77,(int *)uStack_a8);
        (*(code *)**(undefined4 **)pcStack_14)();
        LOCK();
        iVar5 = *(int *)((int)param_4 + 8) + -1;
        *(int *)((int)param_4 + 8) = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          uStack_a8 = CONCAT44(0x8b0d88,(int *)uStack_a8);
          (**(code **)((int)*param_4 + 4))();
        }
      }
    }
    piStack_34 = (int *)uStack_60;
    param_4 = (code ***)param_3;
    cVar7 = FUN_00585a40(&param_4);
    if (cVar7 == '\0') {
      pcStack_b8 = (code *)param_4;
      ppcStack_c0 = (code **)&DAT_019203a9;
    }
    else {
      ppcStack_c0 = (code **)0x0;
    }
    FUN_008ac5b0(&pcStack_18,"Sleeping Assemblies");
    param_4 = (code ***)pcStack_14;
    if (pcStack_14 != (code *)0x0) {
      LOCK();
      iVar5 = *(int *)(pcStack_14 + 4) + -1;
      *(int *)(pcStack_14 + 4) = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b0dea,(int *)uStack_a8);
        (*(code *)**(undefined4 **)pcStack_14)();
        LOCK();
        iVar5 = *(int *)((int)param_4 + 8) + -1;
        *(int *)((int)param_4 + 8) = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          uStack_a8 = CONCAT44(0x8b0dfb,(int *)uStack_a8);
          (**(code **)((int)*param_4 + 4))();
        }
      }
    }
    piStack_34 = (int *)uStack_60;
    param_4 = (code ***)param_3;
    cVar7 = FUN_00585a40(&param_4);
    if (cVar7 == '\0') {
      pcStack_b8 = (code *)param_4;
      ppcStack_c0 = (code **)&DAT_019203b1;
    }
    else {
      ppcStack_c0 = (code **)0x0;
    }
    FUN_008ac5b0(&pcStack_18,"Sleep Checking Assemblies");
    param_4 = (code ***)pcStack_14;
    if (pcStack_14 != (code *)0x0) {
      LOCK();
      iVar5 = *(int *)(pcStack_14 + 4) + -1;
      *(int *)(pcStack_14 + 4) = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b0e5d,(int *)uStack_a8);
        (*(code *)**(undefined4 **)pcStack_14)();
        LOCK();
        iVar5 = *(int *)((int)param_4 + 8) + -1;
        *(int *)((int)param_4 + 8) = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          uStack_a8 = CONCAT44(0x8b0e6e,(int *)uStack_a8);
          (**(code **)((int)*param_4 + 4))();
        }
      }
    }
    piStack_34 = (int *)uStack_60;
    param_4 = (code ***)param_3;
    cVar7 = FUN_00585a40(&param_4);
    if (cVar7 == '\0') {
      pcStack_b8 = (code *)param_4;
      ppcStack_c0 = (code **)&DAT_019203b9;
    }
    else {
      ppcStack_c0 = (code **)0x0;
    }
    FUN_008ac5b0(&pcStack_18,"Awake Assemblies");
    param_4 = (code ***)pcStack_14;
    if (pcStack_14 != (code *)0x0) {
      LOCK();
      iVar5 = *(int *)(pcStack_14 + 4) + -1;
      *(int *)(pcStack_14 + 4) = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b0ed0,(int *)uStack_a8);
        (*(code *)**(undefined4 **)pcStack_14)();
        LOCK();
        iVar5 = *(int *)((int)param_4 + 8) + -1;
        *(int *)((int)param_4 + 8) = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          uStack_a8 = CONCAT44(0x8b0ee1,(int *)uStack_a8);
          (**(code **)((int)*param_4 + 4))();
        }
      }
    }
  }
  uStack_a8 = CONCAT44("Contacts",&uStack_58);
  ppcStack_ac = (code **)0x8b0ef4;
  FUN_009ff040();
  param_4 = &ppcStack_c0;
  pcStack_1c = FUN_00bbdc60;
  pcStack_18 = param_3;
  iStack_8 = CONCAT31(iStack_8._1_3_,6);
  pcStack_44 = FUN_00bbdc60;
  pcStack_40 = param_3;
  pcStack_3c = (code *)0x0;
  cVar7 = FUN_00585a40(&pcStack_44);
  pcVar10 = pcStack_3c;
  if (cVar7 == '\0') {
    *(ulonglong *)(param_4 + 2) = CONCAT44(pcStack_40,pcStack_44);
    param_4[4] = (code **)pcVar10;
    *param_4 = (code **)&DAT_019203c1;
  }
  else {
    *param_4 = (code **)0x0;
  }
  param_4 = (code ***)&DAT_019203c1;
  FUN_008ac5b0(&pcStack_18,"CtctStageCtcts");
  pcVar10 = pcStack_14;
  if (pcStack_14 != (code *)0x0) {
    LOCK();
    iVar5 = *(int *)(pcStack_14 + 4) + -1;
    *(int *)(pcStack_14 + 4) = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_a8 = CONCAT44(0x8b0f8a,(int *)uStack_a8);
      (*(code *)**(undefined4 **)pcStack_14)();
      LOCK();
      pcVar2 = pcVar10 + 8;
      iVar5 = *(int *)pcVar2 + -1;
      *(int *)pcVar2 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b0f9b,(int *)uStack_a8);
        (**(code **)(*(int *)pcVar10 + 4))();
      }
    }
  }
  piStack_34 = (int *)uStack_58;
  pcStack_1c = FUN_00bbdc60;
  pcStack_18 = param_3;
  pcStack_44 = FUN_00bbdc60;
  pcStack_40 = param_3;
  pcStack_3c = (code *)0x1;
  cVar7 = FUN_00585a40(&pcStack_44);
  if (cVar7 == '\0') {
    pcStack_b4 = pcStack_40;
    pcStack_b8 = pcStack_44;
    pcStack_b0 = pcStack_3c;
    ppcStack_c0 = (code **)&DAT_019203c1;
  }
  else {
    ppcStack_c0 = (code **)0x0;
  }
  FUN_008ac5b0(&pcStack_18,"SteppingCtcts");
  pcVar10 = pcStack_14;
  if (pcStack_14 != (code *)0x0) {
    LOCK();
    iVar5 = *(int *)(pcStack_14 + 4) + -1;
    *(int *)(pcStack_14 + 4) = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_a8 = CONCAT44(0x8b1022,(int *)uStack_a8);
      (*(code *)**(undefined4 **)pcStack_14)();
      LOCK();
      pcVar2 = pcVar10 + 8;
      iVar5 = *(int *)pcVar2 + -1;
      *(int *)pcVar2 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b1033,(int *)uStack_a8);
        (**(code **)(*(int *)pcVar10 + 4))();
      }
    }
  }
  piStack_34 = (int *)uStack_58;
  pcStack_1c = FUN_00bbdc60;
  pcStack_18 = param_3;
  pcStack_44 = FUN_00bbdc60;
  pcStack_40 = param_3;
  pcStack_3c = (code *)0x2;
  cVar7 = FUN_00585a40(&pcStack_44);
  if (cVar7 == '\0') {
    pcStack_b4 = pcStack_40;
    pcStack_b8 = pcStack_44;
    pcStack_b0 = pcStack_3c;
    ppcStack_c0 = (code **)param_4;
  }
  else {
    ppcStack_c0 = (code **)0x0;
  }
  FUN_008ac5b0(&pcStack_18,"TouchingCtcts");
  pcVar10 = pcStack_14;
  if (pcStack_14 != (code *)0x0) {
    LOCK();
    iVar5 = *(int *)(pcStack_14 + 4) + -1;
    *(int *)(pcStack_14 + 4) = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_a8 = CONCAT44(0x8b10b5,(int *)uStack_a8);
      (*(code *)**(undefined4 **)pcStack_14)();
      LOCK();
      pcVar2 = pcVar10 + 8;
      iVar5 = *(int *)pcVar2 + -1;
      *(int *)pcVar2 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b10c6,(int *)uStack_a8);
        (**(code **)(*(int *)pcVar10 + 4))();
      }
    }
  }
  piStack_34 = (int *)uStack_58;
  pcStack_1c = FUN_00bbdc60;
  pcStack_18 = param_3;
  pcStack_44 = FUN_00bbdc60;
  pcStack_40 = param_3;
  pcStack_3c = (code *)0x3;
  cVar7 = FUN_00585a40(&pcStack_44);
  if (cVar7 == '\0') {
    pcStack_b4 = pcStack_40;
    pcStack_b8 = pcStack_44;
    pcStack_b0 = pcStack_3c;
    ppcStack_c0 = (code **)param_4;
  }
  else {
    ppcStack_c0 = (code **)0x0;
  }
  FUN_008ac5b0(&pcStack_18,"MaxTreeDepth");
  param_4 = (code ***)pcStack_14;
  if (pcStack_14 != (code *)0x0) {
    LOCK();
    iVar5 = *(int *)(pcStack_14 + 4) + -1;
    *(int *)(pcStack_14 + 4) = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_a8 = CONCAT44(0x8b1148,(int *)uStack_a8);
      (*(code *)**(undefined4 **)pcStack_14)();
      LOCK();
      iVar5 = *(int *)((int)param_4 + 8) + -1;
      *(int *)((int)param_4 + 8) = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b1159,(int *)uStack_a8);
        (**(code **)((int)*param_4 + 4))();
      }
    }
  }
  param_4 = &ppcStack_c0;
  piStack_34 = (int *)uStack_58;
  pcStack_30 = (code *)&LAB_008b3c70;
  pcStack_2c = param_3;
  cVar7 = FUN_00585a40(&pcStack_30);
  puVar8 = param_4;
  if (cVar7 == '\0') {
    param_4[2] = (code **)pcStack_30;
    puVar8[3] = pcStack_2c;
    *puVar8 = &DAT_01920399;
  }
  else {
    *param_4 = (code **)0x0;
  }
  FUN_008ac5b0(&pcStack_18,"# link(p)");
  param_4 = (code ***)pcStack_14;
  if (pcStack_14 != (code *)0x0) {
    LOCK();
    iVar5 = *(int *)(pcStack_14 + 4) + -1;
    *(int *)(pcStack_14 + 4) = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_a8 = CONCAT44(0x8b11d6,(int *)uStack_a8);
      (*(code *)**(undefined4 **)pcStack_14)();
      LOCK();
      iVar5 = *(int *)((int)param_4 + 8) + -1;
      *(int *)((int)param_4 + 8) = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b11e7,(int *)uStack_a8);
        (**(code **)((int)*param_4 + 4))();
      }
    }
  }
  param_4 = &ppcStack_c0;
  piStack_34 = (int *)uStack_58;
  pcStack_30 = FUN_00bbdd40;
  pcStack_2c = param_3;
  cVar7 = FUN_00585a40(&pcStack_30);
  puVar8 = param_4;
  if (cVar7 == '\0') {
    param_4[2] = (code **)pcStack_30;
    puVar8[3] = pcStack_2c;
    *puVar8 = &DAT_01920399;
  }
  else {
    *param_4 = (code **)0x0;
  }
  FUN_008ac5b0(&pcStack_18,"Hash Nodes Out");
  param_4 = (code ***)pcStack_14;
  if (pcStack_14 != (code *)0x0) {
    LOCK();
    iVar5 = *(int *)(pcStack_14 + 4) + -1;
    *(int *)(pcStack_14 + 4) = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_a8 = CONCAT44(0x8b1259,(int *)uStack_a8);
      (*(code *)**(undefined4 **)pcStack_14)();
      LOCK();
      iVar5 = *(int *)((int)param_4 + 8) + -1;
      *(int *)((int)param_4 + 8) = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b126a,(int *)uStack_a8);
        (**(code **)((int)*param_4 + 4))();
      }
    }
  }
  param_4 = &ppcStack_c0;
  piStack_34 = (int *)uStack_58;
  pcStack_30 = FUN_00bbdc40;
  pcStack_2c = param_3;
  cVar7 = FUN_00585a40(&pcStack_30);
  puVar8 = param_4;
  if (cVar7 == '\0') {
    param_4[2] = (code **)pcStack_30;
    puVar8[3] = pcStack_2c;
    *puVar8 = &DAT_01920399;
  }
  else {
    *param_4 = (code **)0x0;
  }
  FUN_008ac5b0(&pcStack_18,"Max Bucket Size");
  param_4 = (code ***)pcStack_14;
  if (pcStack_14 != (code *)0x0) {
    LOCK();
    iVar5 = *(int *)(pcStack_14 + 4) + -1;
    *(int *)(pcStack_14 + 4) = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_a8 = CONCAT44(0x8b12d7,(int *)uStack_a8);
      (*(code *)**(undefined4 **)pcStack_14)();
      LOCK();
      iVar5 = *(int *)((int)param_4 + 8) + -1;
      *(int *)((int)param_4 + 8) = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b12e8,(int *)uStack_a8);
        (**(code **)((int)*param_4 + 4))();
      }
    }
  }
  uStack_a8 = CONCAT44("Kernel",&uStack_74);
  ppcStack_ac = (code **)0x8b12fb;
  FUN_009ff040();
  pcVar10 = *(code **)(param_3 + 0x6f0);
  param_4 = (code ***)uStack_74;
  iStack_8 = CONCAT31(iStack_8._1_3_,7);
  pcStack_20 = FUN_00554ed0;
  pcStack_1c = (code *)0x0;
  pcStack_18 = pcVar10;
  cVar7 = FUN_00585a40(&pcStack_20);
  if (cVar7 == '\0') {
    pcStack_b8 = pcStack_20;
    pcStack_b4 = pcStack_1c;
    pcStack_b0 = pcStack_18;
    ppcStack_ac = (code **)pcStack_14;
    ppcStack_c0 = (code **)&DAT_019203c9;
  }
  else {
    ppcStack_c0 = (code **)0x0;
  }
  FUN_008ac5b0(&pcStack_18,"Bodies");
  pcVar2 = pcStack_14;
  if (pcStack_14 != (code *)0x0) {
    LOCK();
    iVar5 = *(int *)(pcStack_14 + 4) + -1;
    *(int *)(pcStack_14 + 4) = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_a8 = CONCAT44(0x8b137d,(int *)uStack_a8);
      (*(code *)**(undefined4 **)pcStack_14)();
      LOCK();
      pcVar3 = pcVar2 + 8;
      iVar5 = *(int *)pcVar3 + -1;
      *(int *)pcVar3 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b138d,(int *)uStack_a8);
        (**(code **)(*(int *)pcVar2 + 4))();
      }
    }
  }
  param_4 = (code ***)uStack_74;
  pcStack_20 = FUN_00f38210;
  pcStack_1c = (code *)0x0;
  pcStack_18 = pcVar10;
  cVar7 = FUN_00585a40(&pcStack_20);
  if (cVar7 == '\0') {
    pcStack_b8 = pcStack_20;
    pcStack_b4 = pcStack_1c;
    pcStack_b0 = pcStack_18;
    ppcStack_ac = (code **)pcStack_14;
    ppcStack_c0 = (code **)&DAT_019203c9;
  }
  else {
    ppcStack_c0 = (code **)0x0;
  }
  FUN_008ac5b0(&pcStack_18,"Constraints");
  pcVar10 = pcStack_14;
  if (pcStack_14 != (code *)0x0) {
    LOCK();
    iVar5 = *(int *)(pcStack_14 + 4) + -1;
    *(int *)(pcStack_14 + 4) = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_a8 = CONCAT44(0x8b1405,(int *)uStack_a8);
      (*(code *)**(undefined4 **)pcStack_14)();
      LOCK();
      pcVar2 = pcVar10 + 8;
      iVar5 = *(int *)pcVar2 + -1;
      *(int *)pcVar2 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b1415,(int *)uStack_a8);
        (**(code **)(*(int *)pcVar10 + 4))();
      }
    }
  }
  uStack_a8 = CONCAT44("File Operations",auStack_6c);
  ppcStack_ac = (code **)0x8b1428;
  FUN_009ff040();
  pcStack_20 = (code *)&LAB_008b4110;
  pcStack_1c = (code *)0x0;
  pcStack_18 = param_2;
  pcStack_50 = (code *)&LAB_008b4110;
  pcStack_4c = (code *)0x0;
  pcStack_48 = (code *)0x0;
  pcStack_44 = pcStack_14;
  iStack_8 = CONCAT31(iStack_8._1_3_,8);
  pcStack_40 = param_2;
  pcStack_3c = pcStack_14;
  cVar7 = FUN_00585a40(&pcStack_50);
  if (cVar7 == '\0') {
    pcStack_b8 = pcStack_50;
    pcStack_b4 = pcStack_4c;
    pcStack_b0 = pcStack_48;
    ppcStack_ac = (code **)pcStack_44;
    uStack_a8 = CONCAT44(pcStack_3c,pcStack_40);
    ppcStack_c0 = (code **)&DAT_019203d1;
  }
  else {
    ppcStack_c0 = (code **)0x0;
  }
  param_4 = (code ***)&DAT_019203d1;
  FUN_008ac720(&pcStack_18,"Total Load Time");
  pcVar10 = pcStack_14;
  if (pcStack_14 != (code *)0x0) {
    LOCK();
    iVar5 = *(int *)(pcStack_14 + 4) + -1;
    *(int *)(pcStack_14 + 4) = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_a8 = CONCAT44(0x8b14cf,(int *)uStack_a8);
      (*(code *)**(undefined4 **)pcStack_14)();
      LOCK();
      pcVar2 = pcVar10 + 8;
      iVar5 = *(int *)pcVar2 + -1;
      *(int *)pcVar2 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b14df,(int *)uStack_a8);
        (**(code **)(*(int *)pcVar10 + 4))();
      }
    }
  }
  pcStack_20 = (code *)&LAB_008b4140;
  pcStack_1c = (code *)0x0;
  pcStack_18 = param_2;
  pcStack_50 = (code *)&LAB_008b4140;
  pcStack_4c = (code *)0x0;
  pcStack_48 = (code *)0x0;
  pcStack_44 = pcStack_14;
  pcStack_40 = param_2;
  pcStack_3c = pcStack_14;
  cVar7 = FUN_00585a40(&pcStack_50);
  if (cVar7 == '\0') {
    pcStack_b8 = pcStack_50;
    pcStack_b4 = pcStack_4c;
    pcStack_b0 = pcStack_48;
    ppcStack_ac = (code **)pcStack_44;
    uStack_a8 = CONCAT44(pcStack_3c,pcStack_40);
    ppcStack_c0 = (code **)&DAT_019203d1;
  }
  else {
    ppcStack_c0 = (code **)0x0;
  }
  FUN_008ac720(&pcStack_18,"SyncHttpGet Time");
  pcVar10 = pcStack_14;
  if (pcStack_14 != (code *)0x0) {
    LOCK();
    iVar5 = *(int *)(pcStack_14 + 4) + -1;
    *(int *)(pcStack_14 + 4) = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_a8 = CONCAT44(0x8b157c,(int *)uStack_a8);
      (*(code *)**(undefined4 **)pcStack_14)();
      LOCK();
      pcVar2 = pcVar10 + 8;
      iVar5 = *(int *)pcVar2 + -1;
      *(int *)pcVar2 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b158c,(int *)uStack_a8);
        (**(code **)(*(int *)pcVar10 + 4))();
      }
    }
  }
  pcStack_20 = (code *)&LAB_008b4150;
  pcStack_1c = (code *)0x0;
  pcStack_18 = param_2;
  pcStack_50 = (code *)&LAB_008b4150;
  pcStack_4c = (code *)0x0;
  pcStack_48 = (code *)0x0;
  pcStack_44 = pcStack_14;
  pcStack_40 = param_2;
  pcStack_3c = pcStack_14;
  cVar7 = FUN_00585a40(&pcStack_50);
  if (cVar7 == '\0') {
    pcStack_b8 = pcStack_50;
    pcStack_b4 = pcStack_4c;
    pcStack_b0 = pcStack_48;
    ppcStack_ac = (code **)pcStack_44;
    uStack_a8 = CONCAT44(pcStack_3c,pcStack_40);
    ppcStack_c0 = (code **)param_4;
  }
  else {
    ppcStack_c0 = (code **)0x0;
  }
  FUN_008ac720(&pcStack_18,"XML Load Time");
  pcVar10 = pcStack_14;
  if (pcStack_14 != (code *)0x0) {
    LOCK();
    iVar5 = *(int *)(pcStack_14 + 4) + -1;
    *(int *)(pcStack_14 + 4) = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_a8 = CONCAT44(0x8b1624,(int *)uStack_a8);
      (*(code *)**(undefined4 **)pcStack_14)();
      LOCK();
      pcVar2 = pcVar10 + 8;
      iVar5 = *(int *)pcVar2 + -1;
      *(int *)pcVar2 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b1634,(int *)uStack_a8);
        (**(code **)(*(int *)pcVar10 + 4))();
      }
    }
  }
  pcStack_20 = (code *)&LAB_008b4130;
  pcStack_1c = (code *)0x0;
  pcStack_18 = param_2;
  pcStack_50 = (code *)&LAB_008b4130;
  pcStack_4c = (code *)0x0;
  pcStack_48 = (code *)0x0;
  pcStack_44 = pcStack_14;
  pcStack_40 = param_2;
  pcStack_3c = pcStack_14;
  cVar7 = FUN_00585a40(&pcStack_50);
  if (cVar7 == '\0') {
    pcStack_b8 = pcStack_50;
    pcStack_b4 = pcStack_4c;
    pcStack_b0 = pcStack_48;
    ppcStack_ac = (code **)pcStack_44;
    uStack_a8 = CONCAT44(pcStack_3c,pcStack_40);
    ppcStack_c0 = (code **)param_4;
  }
  else {
    ppcStack_c0 = (code **)0x0;
  }
  FUN_008ac720(&pcStack_18,"Join All Time");
  pcVar10 = pcStack_14;
  if (pcStack_14 != (code *)0x0) {
    LOCK();
    iVar5 = *(int *)(pcStack_14 + 4) + -1;
    *(int *)(pcStack_14 + 4) = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_a8 = CONCAT44(0x8b16cc,(int *)uStack_a8);
      (*(code *)**(undefined4 **)pcStack_14)();
      LOCK();
      pcVar2 = pcVar10 + 8;
      iVar5 = *(int *)pcVar2 + -1;
      *(int *)pcVar2 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b16dc,(int *)uStack_a8);
        (**(code **)(*(int *)pcVar10 + 4))();
      }
    }
  }
  if (piStack_68 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_68[1] + -1;
    piStack_68[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_a8 = CONCAT44(0x8b16f2,(int *)uStack_a8);
      (**(code **)*piStack_68)();
      LOCK();
      iVar5 = piStack_68[2] + -1;
      piStack_68[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b1702,(int *)uStack_a8);
        (**(code **)(*piStack_68 + 4))();
      }
    }
  }
  if (piStack_70 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_70[1] + -1;
    piStack_70[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_a8 = CONCAT44(0x8b1718,(int *)uStack_a8);
      (**(code **)*piStack_70)();
      LOCK();
      iVar5 = piStack_70[2] + -1;
      piStack_70[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b1728,(int *)uStack_a8);
        (**(code **)(*piStack_70 + 4))();
      }
    }
  }
  if (piStack_54 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_54[1] + -1;
    piStack_54[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_a8 = CONCAT44(0x8b173e,(int *)uStack_a8);
      (**(code **)*piStack_54)();
      LOCK();
      iVar5 = piStack_54[2] + -1;
      piStack_54[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_a8 = CONCAT44(0x8b174e,(int *)uStack_a8);
        (**(code **)(*piStack_54 + 4))();
      }
    }
  }
  if (piStack_5c != (int *)0x0) {
    LOCK();
    iVar5 = piStack_5c[1] + -1;
    piStack_5c[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_a8 = CONCAT44(0x8b1764,(int *)uStack_a8);
      (**(code **)*piStack_5c)();
      LOCK();
      piVar4 = piStack_5c + 2;
      iVar5 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        uStack_a8 = CONCAT44(0x8b1773,(int *)uStack_a8);
        (**(code **)(*piStack_5c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14643 ; VA 0x008b1790 ; FUN_008b1790 */

void __fastcall FUN_008b1790(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ad84f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01674e20(0x3c);
  uStack_8 = 0;
  if (iVar1 != 0) {
    uVar2 = FUN_00cc5390();
    *(undefined4 *)(param_1 + 0x214) = uVar2;
    ExceptionList = pvStack_10;
    return;
  }
  *(undefined4 *)(param_1 + 0x214) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14644 ; VA 0x008b1800 ; FUN_008b1800 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __fastcall FUN_008b1800(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined8 *puVar5;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined4 uStack_38;
  undefined8 uStack_34;
  undefined4 uStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc228;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x1c8) == 0) {
    ExceptionList = &pvStack_10;
    iStack_18 = param_1;
    if (DAT_01d6517b != '\0') {
      ExceptionList = &pvStack_10;
      FUN_016774b0(DAT_01d6517b,"Terrain doesn\'t exist - creating terrain instance explicitly",0);
    }
    puVar4 = (undefined4 *)FUN_008ac370(auStack_28);
    piStack_20 = (int *)*puVar4;
    piVar2 = (int *)puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    uStack_8 = 0;
    piStack_1c = piVar2;
    piStack_14 = piStack_20;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_24[1] + -1;
      piStack_24[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar3 = piStack_24[2] + -1;
        piStack_24[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    piVar1 = piStack_14;
    puVar5 = (undefined8 *)FUN_00b08320();
    uStack_34._4_4_ = (float)((ulonglong)*puVar5 >> 0x20);
    uStack_64 = _DAT_018e3fb0;
    uStack_60 = _UNK_018e3fb4;
    uStack_5c = _UNK_018e3fb8;
    uStack_58 = _UNK_018e3fbc;
    uStack_2c = 0xc0000000;
    uStack_54 = _DAT_018e3fb0;
    uStack_50 = _UNK_018e3fb4;
    uStack_4c = _UNK_018e3fb8;
    uStack_48 = _UNK_018e3fbc;
    uStack_44 = 0x3f800000;
    uStack_40 = CONCAT44(uStack_34._4_4_ * DAT_018ce2f4,DAT_0191a364);
    uStack_38 = 0xc0000000;
    uStack_34 = *puVar5;
    (**(code **)(*piVar1 + 0x108))(&uStack_64);
    param_1 = FUN_008a5700(iStack_18);
    if (piVar2 != (int *)0x0) {
      LOCK();
      piVar1 = piVar2 + 1;
      iVar3 = *piVar1;
      param_1 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        param_1 = (**(code **)*piVar2)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          param_1 = (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14645 ; VA 0x008b1950 ; FUN_008b1950 */

void FUN_008b1950(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  if (param_1 != 0) {
    uVar2 = param_2 * 0x24;
    iVar1 = param_1;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  return;
}



/* FUNCTION 14646 ; VA 0x008b19a0 ; FUN_008b19a0 */

void __thiscall FUN_008b19a0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 auStack_1b4 [50];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar1 = FUN_0088c960();
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  puVar4 = *(undefined4 **)(param_1 + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar3 = 2;
  }
  else {
    uStack_ec = FUN_0088c960();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar4;
    iStack_e8 = FUN_00630820();
    puStack_18 = &uStack_ec;
    uVar3 = 1;
  }
  uStack_8 = (uint)(puVar4 == (undefined4 *)0x0);
  uStack_14 = uVar3;
  uVar1 = FUN_0088c960();
  uVar2 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar2,uVar1,puStack_18);
  if ((uVar3 & 2) != 0) {
    uVar3 = uVar3 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar3;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar3 & 1) != 0) {
    uVar3 = uVar3 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar3;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x48);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 5;
    uVar3 = uVar3 | 8;
  }
  else {
    uStack_1bc = FUN_0088c960();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar4;
    iStack_1b8 = FUN_00630820();
    puVar4 = &uStack_1bc;
    uStack_8 = 4;
    uVar3 = uVar3 | 4;
  }
  uStack_14 = uVar3;
  uVar1 = FUN_0088c960();
  uVar2 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar2,uVar1,puVar4);
  if ((uVar3 & 8) != 0) {
    uVar3 = uVar3 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar3;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar3 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14647 ; VA 0x008b1bd0 ; FUN_008b1bd0 */

void __thiscall FUN_008b1bd0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798aa8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar1 = FUN_0088c960();
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  puVar3 = *(undefined4 **)(param_1 + 0x44);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088c960();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_00630820();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(puVar3 == (undefined4 *)0x0);
  uStack_14 = uVar4;
  uVar1 = FUN_0088c960();
  uVar2 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar2,uVar1,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x48);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar3 = &uStack_1bc;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_ec = FUN_0088c960();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_00630820();
    puVar3 = &uStack_ec;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088c960();
  uVar2 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 4) != 0) {
    uVar4 = uVar4 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar3 = &uStack_35c;
    uStack_8 = 9;
    uVar4 = uVar4 | 0x20;
  }
  else {
    uStack_28c = FUN_0088c960();
    iStack_288 = 0;
    auStack_284[0] = *puVar3;
    iStack_288 = FUN_00630820();
    puVar3 = &uStack_28c;
    uStack_8 = 8;
    uVar4 = uVar4 | 0x10;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088c960();
  uVar2 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 0x20) != 0) {
    uVar4 = uVar4 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 0x10) != 0) && (uStack_8 = 0xb, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14648 ; VA 0x008b1ef0 ; FUN_008b1ef0 */

void __thiscall FUN_008b1ef0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd560;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar4 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_008aa360(iVar1);
    uVar4 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar4;
  uVar2 = FUN_0088cc80();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x48);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar5 = &uStack_28c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_ec = thunk_FUN_008bbaf0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar5;
    iStack_e8 = FUN_008bbe40();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = thunk_FUN_008bbaf0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_e8 != 0)) {
    (**(code **)(iStack_e8 + 8))(auStack_e4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14649 ; VA 0x008b20f0 ; FUN_008b20f0 */

int __thiscall FUN_008b20f0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  
  iVar3 = 0;
  puVar4 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar4;
    piVar1 = (int *)puVar4[3];
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[1] + -1;
      piVar1[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    FUN_01674ea0(puVar4,0x10);
    iVar3 = iVar3 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar4 = (undefined4 *)*param_2;
  } while (puVar4 != param_3);
  return iVar3;
}



/* FUNCTION 14650 ; VA 0x008b2160 ; FUN_008b2160 */

void __fastcall FUN_008b2160(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  uVar2 = 0;
  if (param_1[4] != 0) {
    do {
      FUN_008afe50();
      FUN_00617ad0();
      FUN_008afdc0();
      iVar1 = param_1[2];
      uVar2 = uVar2 + 1;
      param_1[2] = iVar1 + 0x24;
      if (iVar1 + 0x24 == param_1[1]) {
        param_1[2] = *param_1;
      }
    } while (uVar2 < (uint)param_1[4]);
  }
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[1] - iVar1) / 0x24) * 0x24;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  return;
}



/* FUNCTION 14651 ; VA 0x008b21f0 ; FUN_008b21f0 */

void * FUN_008b21f0(int param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0xc);
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00d1e830();
    pvVar4 = (void *)(uint)*(ushort *)(iVar3 + 0x1da);
    if (((void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) <= pvVar4) &&
       (param_1 != param_3)) {
      pvVar4 = (void *)FUN_008a65e0(0,0);
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 14652 ; VA 0x008b2290 ; FUN_008b2290 */

int FUN_008b2290(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0060dcd0(auStack_18,*(undefined4 *)(param_1 + 0x34));
  uStack_8 = 0;
  FUN_008a65e0(0,0);
  iVar3 = FUN_008b0070(auStack_18);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 14653 ; VA 0x008b2320 ; FUN_008b2320 */

void FUN_008b2320(int param_1,undefined4 param_2)

{
  (**(code **)(param_1 + 0x18))(param_2);
  return;
}



/* FUNCTION 14654 ; VA 0x008b2350 ; FUN_008b2350 */

void FUN_008b2350(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(param_1 + 0x18))(param_2,param_3);
  return;
}



/* FUNCTION 14655 ; VA 0x008b2380 ; FUN_008b2380 */

bool __fastcall FUN_008b2380(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = (**(code **)(param_1 + 8))();
  iVar2 = (**(code **)(param_1 + 8))();
  return iVar2 == iVar1;
}



/* FUNCTION 14656 ; VA 0x008b23d0 ; FUN_008b23d0 */

undefined __fastcall FUN_008b23d0(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int aiStack_40 [5];
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794d38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)(**(code **)(param_1 + 8))(aiStack_40);
  uStack_8 = 0;
  puVar5 = (undefined4 *)(**(code **)(param_1 + 8))(auStack_28);
  puVar1 = puVar4 + 4;
  if (0xf < (uint)puVar4[5]) {
    puVar4 = (undefined4 *)*puVar4;
  }
  puVar2 = puVar5 + 4;
  if (0xf < (uint)puVar5[5]) {
    puVar5 = (undefined4 *)*puVar5;
  }
  uVar3 = FUN_0055c360(puVar5,*puVar2,puVar4,*puVar1);
  if (0xf < uStack_14) {
    uVar7 = uStack_14 + 1;
    uVar8 = auStack_28[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_28[0] - 4);
      uVar7 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (0xf < uStack_2c) {
    uVar8 = uStack_2c + 1;
    iVar6 = aiStack_40[0];
    if (0xfff < uVar8) {
      iVar6 = *(int *)(aiStack_40[0] + -4);
      uVar8 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 14657 ; VA 0x008b24f0 ; FUN_008b24f0 */

int __fastcall FUN_008b24f0(int param_1)

{
  float fVar1;
  float fVar2;
  uint3 uVar3;
  undefined2 extraout_var;
  float10 fVar4;
  
  fVar4 = (float10)(**(code **)(param_1 + 8))();
  fVar1 = (float)fVar4;
  fVar4 = (float10)(**(code **)(param_1 + 8))();
  fVar2 = (float)fVar4;
  uVar3 = CONCAT21(extraout_var,
                   (fVar1 == fVar2) << 6 | (NAN(fVar1) || NAN(fVar2)) << 2 | 2U | fVar1 < fVar2);
  if ((NAN(fVar1) || NAN(fVar2)) != (fVar1 == fVar2)) {
    return CONCAT31(uVar3,1);
  }
  return (uint)uVar3 << 8;
}



/* FUNCTION 14658 ; VA 0x008b2550 ; FUN_008b2550 */

int __fastcall FUN_008b2550(int param_1)

{
  double dVar1;
  double dVar2;
  uint3 uVar3;
  undefined2 extraout_var;
  float10 fVar4;
  
  fVar4 = (float10)(**(code **)(param_1 + 8))();
  dVar1 = (double)fVar4;
  fVar4 = (float10)(**(code **)(param_1 + 8))();
  dVar2 = (double)fVar4;
  uVar3 = CONCAT21(extraout_var,
                   (dVar1 == dVar2) << 6 | (NAN(dVar1) || NAN(dVar2)) << 2 | 2U | dVar1 < dVar2);
  if ((NAN(dVar1) || NAN(dVar2)) != (dVar1 == dVar2)) {
    return CONCAT31(uVar3,1);
  }
  return (uint)uVar3 << 8;
}



/* FUNCTION 14659 ; VA 0x008b25c0 ; FUN_008b25c0 */

bool __fastcall FUN_008b25c0(int param_1)

{
  char cVar1;
  char cVar2;
  
  cVar1 = (**(code **)(param_1 + 8))();
  cVar2 = (**(code **)(param_1 + 8))();
  return cVar2 == cVar1;
}



/* FUNCTION 14660 ; VA 0x008b2610 ; FUN_008b2610 */

void __thiscall FUN_008b2610(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uStack_20;
  
  uStack_20 = (code *)*(undefined8 *)(param_1 + 0x38);
  uVar1 = (*uStack_20)();
  FUN_009d5650(param_3,uVar1);
  return;
}



/* FUNCTION 14661 ; VA 0x008b2660 ; FUN_008b2660 */

void __thiscall FUN_008b2660(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  float10 fVar2;
  float10 fVar3;
  undefined4 uStack_30;
  
  iVar1 = FUN_01256300(param_3);
  fVar2 = (float10)FUN_009d0730(param_3,param_4,2,iVar1 - param_4,param_1 + 0x48);
  fVar3 = (float10)FUN_009d0730(param_3,param_4,1,iVar1 - param_4,param_1 + 0x44);
  uStack_30 = (code *)*(undefined8 *)(param_1 + 0x38);
  fVar2 = (float10)(*uStack_30)((float)fVar3,(float)fVar2);
  FUN_009d5680(param_3,(float)fVar2);
  return;
}



/* FUNCTION 14662 ; VA 0x008b2720 ; FUN_008b2720 */

void __thiscall FUN_008b2720(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  float10 fVar2;
  float10 fVar3;
  float10 fVar4;
  undefined4 uStack_30;
  
  iVar1 = FUN_01256300(param_3);
  iVar1 = iVar1 - param_4;
  fVar2 = (float10)FUN_009d0730(param_3,param_4,3,iVar1,param_1 + 0x4c);
  fVar3 = (float10)FUN_009d0730(param_3,param_4,2,iVar1,param_1 + 0x48);
  fVar4 = (float10)FUN_009d0730(param_3,param_4,1,iVar1,param_1 + 0x44);
  uStack_30 = (code *)*(undefined8 *)(param_1 + 0x38);
  fVar2 = (float10)(*uStack_30)((float)fVar4,(float)fVar3,(float)fVar2);
  FUN_009d5680(param_3,(float)fVar2);
  return;
}



/* FUNCTION 14663 ; VA 0x008b2800 ; FUN_008b2800 */

void __thiscall FUN_008b2800(int param_1,undefined4 param_2,undefined4 param_3)

{
  float10 fVar1;
  undefined4 uStack_20;
  
  uStack_20 = (code *)*(undefined8 *)(param_1 + 0x38);
  fVar1 = (float10)(*uStack_20)();
  FUN_009d56b0(param_3,(double)fVar1);
  return;
}



/* FUNCTION 14664 ; VA 0x008b2860 ; FUN_008b2860 */

undefined4 __thiscall FUN_008b2860(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  undefined8 uVar2;
  int iVar3;
  undefined4 *puVar4;
  code *pcStack_40;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017a9308;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar3 = FUN_01256300(param_3);
  puVar4 = (undefined4 *)FUN_009d1050(auStack_2c,param_3,param_4,1,iVar3 - param_4,param_1 + 0x44);
  uVar2 = *(undefined8 *)(param_1 + 0x38);
  uStack_14 = 0;
  if (puVar4[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  pcStack_40 = (code *)uVar2;
  (*pcStack_40)(*puVar4,puVar4[1]);
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_28[1] + -1;
    piStack_28[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piStack_28 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 14665 ; VA 0x008b2950 ; FUN_008b2950 */

undefined4 FUN_008b2950(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 uStack_110;
  int iStack_10c;
  undefined auStack_108 [200];
  undefined auStack_40 [4];
  int *piStack_3c;
  undefined8 auStack_38 [2];
  undefined4 uStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017bd58f;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar3 = FUN_01256300(param_2);
  iVar3 = iVar3 - param_3;
  if (1 < iVar3) {
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee005c)
       && (FUN_016f3809(&DAT_01ee005c), DAT_01ee005c == -1)) {
      uStack_14 = 0;
      FUN_00f35810();
      FUN_016f3654(&LAB_01881740);
      uStack_14 = 0xffffffff;
      FUN_016f37bf(&DAT_01ee005c);
    }
    cVar2 = FUN_009d1e20(&DAT_01edfff8,param_2,param_3 + 2,&uStack_28);
    uVar5 = uStack_28;
    if (cVar2 != '\0') goto LAB_008b2a96;
  }
  if (1 < iVar3) {
    uStack_110 = FUN_00888530();
    iStack_10c = 0;
    uStack_14 = 1;
    cVar2 = FUN_009d1bf0(param_2,param_3 + 2,&uStack_110,1);
    if (cVar2 != '\0') {
      puVar4 = (undefined4 *)FUN_00f34dc0();
      uVar5 = *puVar4;
      uStack_14 = 2;
      if (iStack_10c != 0) {
        (**(code **)(iStack_10c + 8))(auStack_108);
      }
      uStack_14 = 0xffffffff;
      goto LAB_008b2a96;
    }
    uStack_14 = 3;
    if (iStack_10c != 0) {
      (**(code **)(iStack_10c + 8))(auStack_108);
    }
    uStack_14 = 0xffffffff;
  }
  if (*(undefined4 **)(iStack_24 + 0x48) == (undefined4 *)0x0) {
    FUN_016756b0(auStack_38,"Argument %d missing or nil",2);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_38,&DAT_01c17198);
  }
  uVar5 = **(undefined4 **)(iStack_24 + 0x48);
LAB_008b2a96:
  puVar4 = (undefined4 *)FUN_009d1050(auStack_40,param_2,param_3,1,iVar3,iStack_24 + 0x44);
  uStack_14 = 4;
  auStack_38[0] = *(undefined8 *)(iStack_24 + 0x38);
  if (puVar4[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*(code *)auStack_38[0])(*puVar4,puVar4[1],uVar5);
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar1 = piStack_3c + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 14666 ; VA 0x008b2bc0 ; FUN_008b2bc0 */

undefined4 FUN_008b2bc0(undefined4 param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_118;
  int iStack_114;
  undefined auStack_110 [204];
  undefined auStack_44 [12];
  undefined8 uStack_38;
  undefined4 uStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017bd5ab;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar2 = FUN_01256300(param_2);
  if (0 < iVar2 - param_3) {
    uVar3 = FUN_008bbc30();
    cVar1 = FUN_009d1e20(uVar3,param_2,param_3 + 1,&uStack_28);
    if (cVar1 != '\0') goto LAB_008b2cd9;
  }
  if (0 < iVar2 - param_3) {
    uStack_118 = FUN_00888530();
    iStack_114 = 0;
    uStack_14 = 0;
    cVar1 = FUN_009d1bf0(param_2,param_3 + 1,&uStack_118,1);
    if (cVar1 != '\0') {
      puVar4 = (undefined4 *)FUN_008aba30();
      uStack_28 = *puVar4;
      uStack_14 = 1;
      if (iStack_114 != 0) {
        (**(code **)(iStack_114 + 8))(auStack_110);
      }
      uStack_14 = 0xffffffff;
      goto LAB_008b2cd9;
    }
    uStack_14 = 2;
    if (iStack_114 != 0) {
      (**(code **)(iStack_114 + 8))(auStack_110);
    }
    uStack_14 = 0xffffffff;
  }
  if (*(undefined4 **)(iStack_24 + 0x44) == (undefined4 *)0x0) {
    FUN_016756b0(auStack_44,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_44,&DAT_01c17198);
  }
  uStack_28 = **(undefined4 **)(iStack_24 + 0x44);
LAB_008b2cd9:
  uStack_38 = *(undefined8 *)(iStack_24 + 0x38);
  (*(code *)uStack_38)(uStack_28);
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 14667 ; VA 0x008b2d40 ; FUN_008b2d40 */

undefined4 __fastcall FUN_008b2d40(int param_1)

{
  undefined4 uStack_20;
  
  uStack_20 = (code *)*(undefined8 *)(param_1 + 0x38);
  (*uStack_20)();
  return 0;
}



/* FUNCTION 14668 ; VA 0x008b2d90 ; FUN_008b2d90 */

undefined4 __thiscall FUN_008b2d90(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined uVar1;
  int iVar2;
  undefined4 uStack_28;
  
  iVar2 = FUN_01256300(param_3);
  uVar1 = FUN_009d1aa0(param_3,param_4,1,iVar2 - param_4,param_1 + 0x44);
  uStack_28 = (code *)*(undefined8 *)(param_1 + 0x38);
  (*uStack_28)(uVar1);
  return 0;
}



/* FUNCTION 14669 ; VA 0x008b2e00 ; FUN_008b2e00 */

void __thiscall FUN_008b2e00(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined uVar1;
  code *pcStack_20;
  
  pcStack_20 = (code *)*(undefined8 *)(param_1 + 0x38);
  uVar1 = (*pcStack_20)();
  FUN_009d5ac0(param_3,uVar1);
  return;
}



/* FUNCTION 14670 ; VA 0x008b2e60 ; FUN_008b2e60 */

int FUN_008b2e60(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar1 = FUN_00a9d0e0(param_1);
  if (iVar1 != 0) {
    iVar4 = *(int *)(iVar1 + 0xc);
    iVar2 = FUN_008aa870();
    iVar3 = 0;
    if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      iVar3 = iVar1;
    }
    return iVar3;
  }
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar4 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
       (uint)*(ushort *)(iVar4 + 0x1da))) {
      iVar1 = FUN_00562f00();
      return iVar1;
    }
  }
  return 0;
}



/* FUNCTION 14671 ; VA 0x008b2f00 ; FUN_008b2f00 */

int __fastcall FUN_008b2f00(int param_1)

{
  return param_1 + -0x144;
}



/* FUNCTION 14672 ; VA 0x008b2f20 ; FUN_008b2f20 */

undefined * __thiscall FUN_008b2f20(int param_1,undefined *param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 ***pppuVar4;
  undefined4 ****ppppuVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  uint *puVar10;
  int iVar11;
  undefined **appuStack_ec [4];
  undefined *apuStack_dc [2];
  undefined **appuStack_d4 [3];
  int *piStack_c8;
  int *piStack_c4;
  int *piStack_b8;
  uint *puStack_b4;
  int *piStack_a8;
  uint uStack_9c;
  uint uStack_98;
  undefined **ppuStack_84;
  uint uStack_3c;
  undefined4 uStack_38;
  undefined4 ***pppuStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  int iStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bd618;
  pvStack_10 = ExceptionList;
  appuStack_ec[0] = &PTR_018bf148;
  apuStack_dc[0] = &DAT_018bf150;
  ppuStack_84 = std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
  uStack_8 = 0;
  uStack_38 = 2;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  FUN_00564f30(appuStack_d4,0);
  uStack_8 = 1;
  *(undefined ***)((int)appuStack_ec + (int)appuStack_ec[0][1]) =
       std::basic_stringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)((int)appuStack_d4 + (int)(appuStack_ec[0][1] + -0x1c)) =
       appuStack_ec[0][1] + -0x68;
  FUN_0054ee60();
  uVar9 = 0;
  appuStack_d4[0] =
       std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::vftable
  ;
  uStack_9c = 0;
  uStack_98 = 0;
  iVar11 = *(int *)(param_1 + 0x1b4);
  uStack_8 = 2;
  if (DAT_01d66528 == '\0') {
    if (*(int *)(iVar11 + 0x21c) == 0) {
      piVar8 = (int *)0x0;
    }
    else {
      piVar8 = *(int **)(*(int *)(iVar11 + 0x228) + *(int *)(iVar11 + 0x218) * 4);
    }
    while (piVar8 != (int *)0x0) {
      puVar10 = (uint *)(piVar8 + 2);
      uStack_24 = 0;
      uStack_20 = 0;
      uStack_14 = piVar8[6];
      if (0xf < (uint)piVar8[7]) {
        puVar10 = (uint *)*puVar10;
      }
      if (uStack_14 < 0x10) {
        pppuStack_34 = (undefined4 ***)*puVar10;
        uStack_30 = puVar10[1];
        uStack_2c = puVar10[2];
        uStack_28 = puVar10[3];
        uStack_20 = 0xf;
      }
      else {
        uStack_18 = uStack_14 | 0xf;
        if (0x7fffffff < uStack_18) {
          uStack_18 = 0x7fffffff;
        }
        uVar9 = uStack_18 + 1;
        if (uVar9 < 0x1000) {
          if (uVar9 == 0) {
            pppuStack_34 = (undefined4 ****)0x0;
          }
          else {
            pppuStack_34 = (undefined4 ***)FUN_01674e20(uVar9);
          }
        }
        else {
          uVar7 = uStack_18 + 0x24;
          if (uVar7 <= uVar9) {
            uVar7 = 0xffffffff;
          }
          pppuVar4 = (undefined4 ***)FUN_01674e20(uVar7);
          if (pppuVar4 == (undefined4 ***)0x0) goto LAB_008b3350;
          pppuStack_34 = (undefined4 ***)((int)pppuVar4 + 0x23U & 0xffffffe0);
          ((undefined4 ****)pppuStack_34)[-1] = pppuVar4;
        }
        FUN_0170c6f0(pppuStack_34,puVar10,uStack_14 + 1);
        uStack_20 = uStack_18;
      }
      cVar1 = *(char *)(piVar8 + 8);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      uStack_24 = uStack_14;
      uStack_18 = FUN_00bbd8a0(cVar1);
      ppppuVar5 = &pppuStack_34;
      if (0xf < uStack_20) {
        ppppuVar5 = (undefined4 ****)pppuStack_34;
      }
      uVar2 = FUN_0055b3b0(apuStack_dc,ppppuVar5,uStack_24);
      FUN_00558890(uVar2,&DAT_018c8ed0);
      uVar2 = FUN_005af260((int)cVar1,&DAT_018c8ed0);
      FUN_00558890(uVar2);
      FUN_005af260(uStack_18);
      piVar8 = (int *)*piVar8;
      if (piVar8 != (int *)0x0) {
        FUN_00558890(apuStack_dc,&DAT_018bd1cc);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (0xf < uStack_20) {
        uVar9 = uStack_20 + 1;
        ppppuVar5 = (undefined4 ****)pppuStack_34;
        if (0xfff < uVar9) {
          ppppuVar5 = (undefined4 ****)pppuStack_34[-1];
          uVar9 = uStack_20 + 0x24;
          if (0x1f < (uint)((int)pppuStack_34 + (-4 - (int)ppppuVar5))) goto LAB_008b3350;
        }
        FUN_01674ea0(ppppuVar5,uVar9);
      }
    }
  }
  else {
    uStack_18 = *(uint *)(iVar11 + 0x5c4);
    uStack_14 = 0;
    do {
      uStack_3c = uStack_14;
      FUN_00bbda40(&pppuStack_34,uStack_14);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      if (uStack_24 == 0) {
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        if (0xf < uStack_20) {
          uVar7 = uStack_20 + 1;
          ppppuVar5 = (undefined4 ****)pppuStack_34;
          if (0xfff < uVar7) {
            ppppuVar5 = (undefined4 ****)pppuStack_34[-1];
            uVar7 = uStack_20 + 0x24;
            if (0x1f < (uint)((int)pppuStack_34 + (-4 - (int)ppppuVar5))) goto LAB_008b3350;
          }
          FUN_01674ea0(ppppuVar5,uVar7);
        }
      }
      else {
        uVar2 = FUN_00bbd8a0(uStack_3c);
        ppppuVar5 = &pppuStack_34;
        if (0xf < uStack_20) {
          ppppuVar5 = (undefined4 ****)pppuStack_34;
        }
        uVar3 = FUN_0055b3b0(apuStack_dc,ppppuVar5,uStack_24);
        FUN_00558890(uVar3,&DAT_018c8ed0);
        uVar3 = FUN_005af260(uStack_14,&DAT_018c8ed0);
        FUN_00558890(uVar3);
        FUN_005af260(uVar2);
        uVar9 = uVar9 + 1;
        if (uVar9 < uStack_18) {
          FUN_00558890(apuStack_dc,&DAT_018bd1cc);
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        if (0xf < uStack_20) {
          uVar7 = uStack_20 + 1;
          ppppuVar5 = (undefined4 ****)pppuStack_34;
          if (0xfff < uVar7) {
            ppppuVar5 = (undefined4 ****)pppuStack_34[-1];
            uVar7 = uStack_20 + 0x24;
            if (0x1f < (uint)((int)pppuStack_34 + (-4 - (int)ppppuVar5))) {
LAB_008b3350:
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(ppppuVar5,uVar7);
        }
      }
      uStack_14 = uStack_14 + 1;
    } while ((int)uStack_14 < 0x20);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  uStack_38 = 10;
  *(undefined4 *)(param_2 + 0x10) = 0;
  *(undefined4 *)(param_2 + 0x14) = 0xf;
  *param_2 = 0;
  if (((uStack_98 & 2) == 0) && (uVar9 = *puStack_b4, uVar9 != 0)) {
    if (uVar9 < uStack_9c) {
      uVar9 = uStack_9c;
    }
    iVar11 = *piStack_c4;
    iVar6 = uVar9 - iVar11;
  }
  else {
    if (((uStack_98 & 4) != 0) || (*piStack_b8 == 0)) goto LAB_008b3331;
    iVar11 = *piStack_c8;
    iVar6 = (*piStack_b8 - iVar11) + *piStack_a8;
  }
  FUN_005542c0(iVar11,iVar6);
LAB_008b3331:
  FUN_005705c0();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14673 ; VA 0x008b3360 ; FUN_008b3360 */

int __fastcall FUN_008b3360(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x138);
  if ((iVar1 == 0) && (iVar1 = *(int *)(param_1 + 0x140), iVar1 == 0)) {
    iVar1 = *(int *)(param_1 + 0x148);
  }
  return iVar1;
}



/* FUNCTION 14674 ; VA 0x008b3380 ; FUN_008b3380 */

int FUN_008b3380(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  if (param_1 != 0) {
    do {
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_008aa870();
      iVar3 = 0;
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
          (uint)*(ushort *)(iVar2 + 0x1da)) {
        iVar3 = param_1;
      }
      if (iVar3 != 0) {
        return iVar3;
      }
      param_1 = *(int *)(param_1 + 0x34);
    } while (param_1 != 0);
  }
  return 0;
}



/* FUNCTION 14675 ; VA 0x008b33d0 ; FUN_008b33d0 */

int FUN_008b33d0(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar2 = FUN_00a9d0e0(param_1);
  if (iVar2 != 0) {
    iVar1 = *(int *)(iVar2 + 0xc);
    iVar3 = FUN_008aa870();
    iVar4 = 0;
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) {
      iVar4 = iVar2;
    }
    return iVar4;
  }
  return 0;
}



/* FUNCTION 14676 ; VA 0x008b3420 ; FUN_008b3420 */

undefined4 __fastcall FUN_008b3420(int param_1)

{
  return *(undefined4 *)(param_1 + 0x2ac);
}



/* FUNCTION 14677 ; VA 0x008b3430 ; FUN_008b3430 */

undefined4 FUN_008b3430(void)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00587490(auStack_c);
  uVar2 = *puVar4;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return uVar2;
  }
  return uVar2;
}



/* FUNCTION 14678 ; VA 0x008b3490 ; FUN_008b3490 */

undefined4 FUN_008b3490(void)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00587490(auStack_c);
  uVar2 = *puVar4;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return uVar2;
  }
  return uVar2;
}



/* FUNCTION 14679 ; VA 0x008b3500 ; FUN_008b3500 */

void __thiscall FUN_008b3500(int param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x6c);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar1 != 0) {
    LOCK();
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
    iVar1 = *(int *)(param_1 + 0x6c);
  }
  *param_2 = *(undefined4 *)(param_1 + 0x68);
  param_2[1] = iVar1;
  return;
}



/* FUNCTION 14680 ; VA 0x008b3530 ; FUN_008b3530 */

uint * __thiscall FUN_008b3530(int param_1,uint *param_2)

{
  uint uVar1;
  int iVar2;
  uint *puVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_60 [4];
  undefined4 uStack_50;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  undefined8 uStack_38;
  undefined auStack_30 [8];
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd638;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_008acdd0(param_1);
  if (iVar2 == 0) {
    puVar3 = (uint *)(**(code **)(**(int **)(param_1 + 0x250) + 0x74))(&uStack_48);
    param_2[4] = 0;
    param_2[5] = 0;
    uVar4 = puVar3[1];
    uVar5 = puVar3[2];
    uVar1 = puVar3[3];
    *param_2 = *puVar3;
    param_2[1] = uVar4;
    param_2[2] = uVar5;
    param_2[3] = uVar1;
    *(undefined8 *)(param_2 + 4) = *(undefined8 *)(puVar3 + 4);
    puVar3[4] = 0;
    puVar3[5] = 0xf;
    *(undefined *)puVar3 = 0;
    if (0xf < uStack_38._4_4_) {
      uVar5 = uStack_38._4_4_ + 1;
      uVar4 = uStack_48;
      if (0xfff < uVar5) {
        uVar4 = *(uint *)(uStack_48 - 4);
        uVar5 = uStack_38._4_4_ + 0x24;
        if (0x1f < (uStack_48 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar4,uVar5);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  puVar3 = (uint *)FUN_00b78450(auStack_60);
  uStack_48 = *puVar3;
  uStack_44 = puVar3[1];
  uStack_40 = puVar3[2];
  uStack_3c = puVar3[3];
  uStack_38 = *(undefined8 *)(puVar3 + 4);
  puVar3[4] = 0;
  puVar3[5] = 0xf;
  *(undefined *)puVar3 = 0;
  uStack_8 = 0;
  uStack_28 = uStack_48;
  uStack_24 = uStack_44;
  uStack_20 = uStack_40;
  uStack_1c = uStack_3c;
  uStack_18 = uStack_38;
  if (0xf < uStack_4c) {
    uVar5 = uStack_4c + 1;
    uVar4 = auStack_60[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_60[0] - 4);
      uVar5 = uStack_4c + 0x24;
      if (0x1f < (auStack_60[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  uStack_50 = 0;
  uStack_4c = 0xf;
  auStack_60[0] = auStack_60[0] & 0xffffff00;
  if ((int)uStack_38 == 0) {
    puVar3 = (uint *)(**(code **)(**(int **)(param_1 + 0x250) + 0x74))(auStack_30);
    param_2[4] = 0;
    param_2[5] = 0;
    uVar4 = puVar3[1];
    uVar5 = puVar3[2];
    uVar1 = puVar3[3];
    *param_2 = *puVar3;
    param_2[1] = uVar4;
    param_2[2] = uVar5;
    param_2[3] = uVar1;
    *(undefined8 *)(param_2 + 4) = *(undefined8 *)(puVar3 + 4);
    puVar3[4] = 0;
    puVar3[5] = 0xf;
    *(undefined *)puVar3 = 0;
    FUN_005507b0();
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return param_2;
  }
  uStack_38 = 0xf00000000;
  uStack_48 = uStack_48 & 0xffffff00;
  param_2[4] = 0;
  param_2[5] = 0;
  *param_2 = uStack_28;
  param_2[1] = uStack_24;
  param_2[2] = uStack_20;
  param_2[3] = uStack_1c;
  *(undefined8 *)(param_2 + 4) = uStack_18;
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14681 ; VA 0x008b3730 ; FUN_008b3730 */

undefined * FUN_008b3730(undefined *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ee88;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  FUN_009cbbb0(param_1);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14682 ; VA 0x008b37b0 ; FUN_008b37b0 */

void __thiscall FUN_008b37b0(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  uVar1 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  FUN_009cb050(uVar1);
  return;
}



/* FUNCTION 14683 ; VA 0x008b37f0 ; FUN_008b37f0 */

float10 __fastcall FUN_008b37f0(int param_1)

{
  int *piVar1;
  
  piVar1 = *(int **)(*(int *)(param_1 + 0x1b4) + 0xc0);
  return (float10)(float)(*piVar1 - (int)piVar1);
}



/* FUNCTION 14684 ; VA 0x008b3810 ; FUN_008b3810 */

float10 __fastcall FUN_008b3810(int param_1)

{
  return (float10)*(float *)(*(int *)(param_1 + 0x1b4) + 0xc4);
}



/* FUNCTION 14685 ; VA 0x008b3820 ; FUN_008b3820 */

int __fastcall FUN_008b3820(int param_1)

{
  return param_1 + 0x1e8;
}



/* FUNCTION 14686 ; VA 0x008b3830 ; FUN_008b3830 */

undefined4 FUN_008b3830(int param_1,int param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  int *piVar7;
  
  iVar2 = param_2;
  if (param_1 == 0) {
    uVar6 = 0;
  }
  else {
    uVar6 = *(uint *)(param_1 + 0xa8);
  }
  uVar3 = -(uint)(*(int *)(uVar6 + 0xc) != 0) & *(int *)(uVar6 + 0xc) - 8U;
  do {
    uVar1 = uVar3;
    if (uVar1 == 0) {
      if (DAT_01d5b9c0 != '\0') {
        uVar5 = FUN_00b06640(uVar6);
        return uVar5;
      }
      return 0;
    }
    iVar4 = FUN_00b06640(uVar1);
    if (iVar4 != 0) {
      piVar7 = *(int **)(iVar2 + 4);
      param_1 = iVar4;
      if (*(int **)(iVar2 + 8) == piVar7) {
        FUN_006030d0(piVar7,&param_1);
      }
      else {
        *piVar7 = iVar4;
        *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 4;
      }
    }
    piVar7 = (int *)(-(uint)(*(int *)(uVar6 + 0x2c) != 0) & *(int *)(uVar6 + 0x2c) - 8U);
    if ((piVar7 == (int *)0x0) || (param_1 = FUN_00ca12e0(), param_1 == 0)) goto LAB_008b3998;
    iVar4 = (**(code **)(*piVar7 + 0x10))();
    if ((iVar4 - 1U < 0xb) && (iVar4 != 4)) {
      param_1 = param_1 + -0x70;
LAB_008b38ca:
      piVar7 = *(int **)(iVar2 + 4);
      if (*(int **)(iVar2 + 8) == piVar7) {
LAB_008b3991:
        FUN_0063d9b0(piVar7,&param_1);
      }
      else {
        *piVar7 = param_1;
        *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 4;
      }
    }
    else {
      iVar4 = (**(code **)(*piVar7 + 0x10))();
      if (iVar4 == 4) {
        param_1 = param_1 + -0x54;
        goto LAB_008b38ca;
      }
      iVar4 = (**(code **)(*piVar7 + 0x10))();
      if (iVar4 - 0xcU < 0xe) {
        piVar7 = *(int **)(iVar2 + 4);
        param_1 = param_1 + -0x54;
        if (*(int **)(iVar2 + 8) == piVar7) {
          FUN_006030d0(piVar7,&param_1);
        }
        else {
          *piVar7 = param_1;
          *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 4;
        }
        iVar4 = FUN_00ca5a50();
        if (iVar4 != 0) {
          param_1 = FUN_00ca5a50();
          piVar7 = *(int **)(iVar2 + 4);
          if (*(int **)(iVar2 + 8) == piVar7) {
            FUN_0063d9b0(piVar7,&param_1);
          }
          else {
            *piVar7 = param_1;
            *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 4;
          }
        }
        iVar4 = FUN_00ca5ab0();
        if (iVar4 == 0) goto LAB_008b3998;
        param_1 = FUN_00ca5ab0();
        piVar7 = *(int **)(iVar2 + 4);
        if (*(int **)(iVar2 + 8) != piVar7) {
          *piVar7 = param_1;
          *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 4;
          goto LAB_008b3998;
        }
        goto LAB_008b3991;
      }
    }
LAB_008b3998:
    uVar3 = -(uint)(*(int *)(uVar1 + 0xc) != 0) & *(int *)(uVar1 + 0xc) - 8U;
    uVar6 = uVar1;
  } while( true );
}



/* FUNCTION 14687 ; VA 0x008b39d7 ; FUN_008b39d7 */

void FUN_008b39d7(void)

{
  FUN_00b659b0();
  return;
}



/* FUNCTION 14688 ; VA 0x008b39e5 ; FUN_008b39e5 */

void FUN_008b39e5(void)

{
  FUN_00b659b0();
  return;
}



/* FUNCTION 14689 ; VA 0x008b3a10 ; FUN_008b3a10 */

void __thiscall FUN_008b3a10(int param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x498);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar1 != 0) {
    LOCK();
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
    iVar1 = *(int *)(param_1 + 0x498);
  }
  *param_2 = *(undefined4 *)(param_1 + 0x494);
  param_2[1] = iVar1;
  return;
}



/* FUNCTION 14690 ; VA 0x008b3a50 ; FUN_008b3a50 */

void FUN_008b3a50(int param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined auStack_2c [12];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd658;
  pvStack_10 = ExceptionList;
  if ((((param_1 != 0) && (*(int *)(param_1 + 0xa8) != 0)) &&
      (ExceptionList = &pvStack_10, iVar2 = FUN_00c155c0(), iVar2 != 0)) &&
     (cVar1 = FUN_00ca0f40(), cVar1 == '\0')) {
    uStack_14 = 0;
    FUN_0060e810(0,&uStack_14,(int)&param_1 + 3);
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_8 = 0;
    uVar3 = FUN_00ca1550();
    uVar4 = FUN_00c15700();
    FUN_008ad460(param_2,auStack_2c,uVar3,uVar4);
    FUN_0056d320();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14691 ; VA 0x008b3b00 ; FUN_008b3b00 */

undefined4 * FUN_008b3b00(undefined4 *param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_1c [24];
  
  *param_1 = 0x7f7fffff;
  param_1[1] = 0x7f7fffff;
  param_1[2] = 0x7f7fffff;
  param_1[3] = 0xff7fffff;
  param_1[4] = 0xff7fffff;
  param_1[5] = 0xff7fffff;
  if ((param_2 != 0) && (*(int *)(param_2 + 0xa8) != 0)) {
    iVar4 = FUN_00c155c0();
    if (iVar4 != 0) {
      puVar5 = (undefined4 *)FUN_00ca12f0(auStack_1c);
      uVar1 = puVar5[1];
      uVar2 = puVar5[2];
      uVar3 = puVar5[3];
      *param_1 = *puVar5;
      param_1[1] = uVar1;
      param_1[2] = uVar2;
      param_1[3] = uVar3;
      *(undefined8 *)(param_1 + 4) = *(undefined8 *)(puVar5 + 4);
    }
  }
  return param_1;
}



/* FUNCTION 14692 ; VA 0x008b3b70 ; FUN_008b3b70 */

void FUN_008b3b70(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined auStack_3c [12];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd678;
  pvStack_10 = ExceptionList;
  if ((param_1 != 0) && (iVar1 = *(int *)(param_1 + 0xa8), iVar1 != 0)) {
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00c155c0();
    if (iVar3 != 0) {
      uStack_14 = 0;
      FUN_0060e810(0,&uStack_14,(int)&param_1 + 3);
      uStack_30 = 0;
      uStack_2c = 0;
      uStack_24 = param_2;
      puStack_20 = auStack_3c;
      uStack_8 = 0;
      uVar2 = FUN_00ca0f40();
      uStack_1c = CONCAT31(uStack_1c._1_3_,uVar2);
      iStack_18 = iVar1;
      uVar4 = FUN_00ca1550();
      uVar5 = FUN_00c15700();
      FUN_008ad3f0(uStack_24,puStack_20,uStack_1c,iStack_18,uVar4,uVar5);
      FUN_0056d320();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14693 ; VA 0x008b3c80 ; FUN_008b3c80 */

undefined4 __fastcall FUN_008b3c80(int param_1)

{
  return *(undefined4 *)(param_1 + 0x48);
}



/* FUNCTION 14694 ; VA 0x008b3c90 ; FUN_008b3c90 */

int FUN_008b3c90(void)

{
  int iVar1;
  
  iVar1 = FUN_008a2610();
  return iVar1 + 6;
}



/* FUNCTION 14695 ; VA 0x008b3ca0 ; FUN_008b3ca0 */

undefined4 __fastcall FUN_008b3ca0(int param_1)

{
  undefined auStack_10 [12];
  
  if (DAT_01d67c88 != '\0') {
    return *(undefined4 *)(param_1 + 0x310);
  }
  FUN_00550130("PhysicsSimulationRate is not a valid member of Workspace");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 14696 ; VA 0x008b3cf0 ; FUN_008b3cf0 */

int __fastcall FUN_008b3cf0(undefined4 param_1)

{
  float10 fVar1;
  
  fVar1 = (float10)FUN_00bbd8f0(param_1);
  return (int)(fVar1 * (float10)DAT_018ce320);
}



/* FUNCTION 14697 ; VA 0x008b3d20 ; FUN_008b3d20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 __fastcall FUN_008b3d20(int param_1)

{
  int *piVar1;
  float fVar2;
  int iVar3;
  int iVar4;
  float10 fVar5;
  undefined auStack_84 [24];
  undefined auStack_6c [24];
  code *pcStack_54;
  undefined1 *puStack_50;
  char *pcStack_4c;
  undefined4 *puStack_48;
  undefined4 uStack_44;
  uint uStack_40;
  undefined1 *puStack_3c;
  char *pcStack_38;
  undefined4 *puStack_34;
  undefined4 uStack_30;
  uint uStack_2c;
  double dStack_28;
  double dStack_20;
  int iStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd6c0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  fStack_14 = (float)param_1;
  if (param_1 != 0) {
    iVar4 = *(int *)(param_1 + 0x34);
    ExceptionList = &pvStack_10;
    if ((iVar4 != 0) && (param_1 = iVar4, ExceptionList = &pvStack_10, *(int *)(iVar4 + 0x34) != 0))
    {
      ExceptionList = &pvStack_10;
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar4 = *(int *)(param_1 + 0xc), iVar3 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
       (uint)*(ushort *)(iVar3 + 0x1da))) {
      FUN_005f5170();
    }
  }
  fVar2 = fStack_14;
  fVar5 = (float10)FUN_00bbd8f0();
  fStack_14 = (float)fVar5;
  fVar5 = (float10)FUN_00999e90();
  dStack_20 = (double)(fVar5 * (float10)fStack_14);
  dStack_28 = dStack_20;
  if ((DAT_01d62d5c != '\0') && ((double)DAT_01d62c7c / DAT_018d8a10 < dStack_20)) {
    if (DAT_01d62d54 != '\0') {
      dStack_28 = DAT_018cf108;
    }
    iVar4 = FUN_008f7870(fVar2);
    if (iVar4 != 0) {
      piVar1 = *(int **)(iVar4 + 0x43c);
      iStack_18 = *piVar1 - (int)piVar1;
      fStack_14 = (float)(piVar1[1] - (int)piVar1);
      if (dStack_20 <= DAT_018ce318) {
        if (dStack_20 <= _DAT_019203f0) {
          if (dStack_20 <= _DAT_019203e8) {
            if (dStack_20 <= _DAT_019203e0) {
              if (dStack_20 <= _DAT_019203d8) {
                puStack_48 = (undefined4 *)FUN_0063fc10(auStack_84,&iStack_18);
                uStack_8 = 5;
                if (0xf < (uint)puStack_48[5]) {
                  puStack_48 = (undefined4 *)*puStack_48;
                }
                uStack_2c = uStack_2c & 0xffffff00;
                uStack_40 = uStack_2c;
                puStack_3c = &DAT_018c5f98;
                pcStack_38 = "ElevatedPhysicsFPSDetected_SetMinimum";
                uStack_30 = 0;
                pcStack_54 = FUN_0087c450;
                puStack_50 = &DAT_018c5f98;
                pcStack_4c = "ElevatedPhysicsFPSDetected_SetMinimum";
                uStack_44 = 0;
                puStack_34 = puStack_48;
                FUN_008ab7d0(&DAT_01edfbe4,&pcStack_54);
              }
              else {
                puStack_48 = (undefined4 *)FUN_0063fc10(auStack_6c,&iStack_18);
                uStack_8 = 4;
                if (0xf < (uint)puStack_48[5]) {
                  puStack_48 = (undefined4 *)*puStack_48;
                }
                uStack_2c = uStack_2c & 0xffffff00;
                uStack_40 = uStack_2c;
                puStack_3c = &DAT_018c5f98;
                pcStack_38 = "ElevatedPhysicsFPSDetected_65";
                uStack_30 = 0;
                pcStack_54 = FUN_0087c450;
                puStack_50 = &DAT_018c5f98;
                pcStack_4c = "ElevatedPhysicsFPSDetected_65";
                uStack_44 = 0;
                puStack_34 = puStack_48;
                FUN_008ab7d0(&DAT_01edfbdc,&pcStack_54);
              }
            }
            else {
              puStack_48 = (undefined4 *)FUN_0063fc10(auStack_6c,&iStack_18);
              uStack_8 = 3;
              if (0xf < (uint)puStack_48[5]) {
                puStack_48 = (undefined4 *)*puStack_48;
              }
              uStack_2c = uStack_2c & 0xffffff00;
              uStack_40 = uStack_2c;
              puStack_3c = &DAT_018c5f98;
              pcStack_38 = "ElevatedPhysicsFPSDetected_70";
              uStack_30 = 0;
              pcStack_54 = FUN_0087c450;
              puStack_50 = &DAT_018c5f98;
              pcStack_4c = "ElevatedPhysicsFPSDetected_70";
              uStack_44 = 0;
              puStack_34 = puStack_48;
              FUN_008ab7d0(&DAT_01edfbd4,&pcStack_54);
            }
          }
          else {
            puStack_48 = (undefined4 *)FUN_0063fc10(auStack_6c,&iStack_18);
            uStack_8 = 2;
            if (0xf < (uint)puStack_48[5]) {
              puStack_48 = (undefined4 *)*puStack_48;
            }
            uStack_2c = uStack_2c & 0xffffff00;
            uStack_40 = uStack_2c;
            puStack_3c = &DAT_018c5f98;
            pcStack_38 = "ElevatedPhysicsFPSDetected_80";
            uStack_30 = 0;
            pcStack_54 = FUN_0087c450;
            puStack_50 = &DAT_018c5f98;
            pcStack_4c = "ElevatedPhysicsFPSDetected_80";
            uStack_44 = 0;
            puStack_34 = puStack_48;
            FUN_008ab7d0(&DAT_01edfbcc,&pcStack_54);
          }
        }
        else {
          puStack_48 = (undefined4 *)FUN_0063fc10(auStack_6c,&iStack_18);
          uStack_8 = 1;
          if (0xf < (uint)puStack_48[5]) {
            puStack_48 = (undefined4 *)*puStack_48;
          }
          uStack_2c = uStack_2c & 0xffffff00;
          uStack_40 = uStack_2c;
          puStack_3c = &DAT_018c5f98;
          pcStack_38 = "ElevatedPhysicsFPSDetected_90";
          uStack_30 = 0;
          pcStack_54 = FUN_0087c450;
          puStack_50 = &DAT_018c5f98;
          pcStack_4c = "ElevatedPhysicsFPSDetected_90";
          uStack_44 = 0;
          puStack_34 = puStack_48;
          FUN_008ab7d0(&DAT_01edfbc4,&pcStack_54);
        }
      }
      else {
        puStack_48 = (undefined4 *)FUN_0063fc10(auStack_6c,&iStack_18);
        uStack_8 = 0;
        if (0xf < (uint)puStack_48[5]) {
          puStack_48 = (undefined4 *)*puStack_48;
        }
        uStack_2c = uStack_2c & 0xffffff00;
        uStack_40 = uStack_2c;
        puStack_3c = &DAT_018c5f98;
        pcStack_38 = "ElevatedPhysicsFPSDetected_100";
        uStack_30 = 0;
        pcStack_54 = FUN_0087c450;
        puStack_50 = &DAT_018c5f98;
        pcStack_4c = "ElevatedPhysicsFPSDetected_100";
        uStack_44 = 0;
        puStack_34 = puStack_48;
        FUN_008ab7d0(&DAT_01edfbbc,&pcStack_54);
      }
      FUN_005507b0();
    }
  }
  ExceptionList = pvStack_10;
  return (float10)dStack_28;
}



/* FUNCTION 14698 ; VA 0x008b40d0 ; thunk_FUN_00897b90 */

undefined * thunk_FUN_00897b90(void)

{
  int iVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017baff8;
  pvStack_10 = ExceptionList;
  if (DAT_01edf5cc == (undefined *)0x0) {
    iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    if (*(int *)(iVar1 + 0x34) < DAT_01edf7d8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01edf7d8);
      if (DAT_01edf7d8 == -1) {
        iStack_8 = 0;
        if (*(int *)(iVar1 + 0x34) < DAT_01edefb0) {
          FUN_016f3809(&DAT_01edefb0);
          if (DAT_01edefb0 == -1) {
            iStack_8._0_1_ = 1;
            FUN_00891e30();
            FUN_016f3654(&LAB_01880b80);
            iStack_8 = (uint)iStack_8._1_3_ << 8;
            FUN_016f37bf(&DAT_01edefb0);
          }
        }
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(&DAT_01ededa8,&DAT_0191cd78,0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_018813b0);
        FUN_016f37bf(&DAT_01edf7d8);
      }
    }
    DAT_01edf5cc = &DAT_01edf5d0;
  }
  ExceptionList = pvStack_10;
  return DAT_01edf5cc;
}



/* FUNCTION 14699 ; VA 0x008b40e0 ; FUN_008b40e0 */

undefined4 __thiscall FUN_008b40e0(int param_1,undefined4 param_2)

{
  (*(code *)**(undefined4 **)(param_1 + -0x20 + *(int *)(*(int *)(param_1 + -0x20) + 4)))(param_2);
  return param_2;
}



/* FUNCTION 14700 ; VA 0x008b4100 ; FUN_008b4100 */

undefined4 __fastcall FUN_008b4100(int param_1)

{
  return CONCAT31((int3)((uint)*(int *)(param_1 + 0x2ac) >> 8),
                  *(undefined *)(*(int *)(param_1 + 0x2ac) + 100));
}



/* FUNCTION 14701 ; VA 0x008b4160 ; FUN_008b4160 */

undefined4 __thiscall FUN_008b4160(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  
  uVar1 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_3);
  FUN_009cb090(param_2,uVar1);
  return param_2;
}



/* FUNCTION 14702 ; VA 0x008b4190 ; FUN_008b4190 */

undefined4 * __thiscall FUN_008b4190(int param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  *param_2 = 0;
  param_2[1] = 0;
  iVar1 = *(int *)(param_1 + 0x10);
  if (iVar1 != 0) {
    iVar2 = *(int *)(iVar1 + 4);
    piVar3 = (int *)(iVar1 + 4);
    if (iVar2 != 0) {
      while( true ) {
        LOCK();
        iVar1 = *piVar3;
        if (iVar2 == iVar1) {
          *piVar3 = iVar2 + 1;
          iVar1 = iVar2;
        }
        UNLOCK();
        if (iVar1 == iVar2) break;
        iVar2 = *piVar3;
        if (iVar2 == 0) {
          return param_2;
        }
      }
      *param_2 = *(undefined4 *)(param_1 + 0xc);
      param_2[1] = *(undefined4 *)(param_1 + 0x10);
    }
  }
  return param_2;
}



/* FUNCTION 14703 ; VA 0x008b4230 ; FUN_008b4230 */

undefined __fastcall FUN_008b4230(int param_1)

{
  return *(undefined *)(param_1 + 0x6c);
}



/* FUNCTION 14704 ; VA 0x008b4240 ; FUN_008b4240 */

void __fastcall FUN_008b4240(int param_1)

{
  (**(code **)(param_1 + 8))();
  return;
}



/* FUNCTION 14705 ; VA 0x008b4270 ; FUN_008b4270 */

undefined4 * __thiscall FUN_008b4270(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  int aiStack_1c [5];
  uint uStack_8;
  
  puVar4 = (undefined4 *)(**(code **)(param_1 + 8))(aiStack_1c);
  param_2[4] = 0;
  param_2[5] = 0;
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *param_2 = *puVar4;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  *(undefined8 *)(param_2 + 4) = *(undefined8 *)(puVar4 + 4);
  puVar4[4] = 0;
  puVar4[5] = 0xf;
  *(undefined *)puVar4 = 0;
  if (0xf < uStack_8) {
    uVar6 = uStack_8 + 1;
    iVar5 = aiStack_1c[0];
    if (0xfff < uVar6) {
      iVar5 = *(int *)(aiStack_1c[0] + -4);
      uVar6 = uStack_8 + 0x24;
      if (0x1f < (aiStack_1c[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  return param_2;
}



/* FUNCTION 14706 ; VA 0x008b4310 ; FUN_008b4310 */

void __thiscall FUN_008b4310(int *param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(*param_1 + 0x44))(param_2);
  uVar3 = FUN_0088c8c0();
  *param_3 = uVar3;
  iVar4 = FUN_005c9cc0();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 14707 ; VA 0x008b4360 ; FUN_008b4360 */

int __thiscall FUN_008b4360(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bba58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  puVar5 = (undefined4 *)FUN_0060dcd0(auStack_20,uVar4);
  uStack_18 = *puVar5;
  piStack_14 = (int *)puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  uStack_8 = 0;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar6 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  iVar6 = FUN_008979b0(&uStack_18);
  piVar3 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 14708 ; VA 0x008b4420 ; FUN_008b4420 */

void __thiscall FUN_008b4420(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_008bbb80();
  *param_3 = uVar3;
  iVar4 = FUN_008bbeb0();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 14709 ; VA 0x008b4480 ; FUN_008b4480 */

void __thiscall FUN_008b4480(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_008bbc30();
  *param_3 = uVar3;
  iVar4 = FUN_008bbf20();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 14710 ; VA 0x008b44e0 ; FUN_008b44e0 */

void __thiscall FUN_008b44e0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_008bbce0();
  *param_3 = uVar3;
  iVar4 = FUN_008bbf90();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 14711 ; VA 0x008b4540 ; FUN_008b4540 */

void __thiscall FUN_008b4540(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_008bbd90();
  *param_3 = uVar3;
  iVar4 = FUN_008bc000();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 14712 ; VA 0x008b45a0 ; FUN_008b45a0 */

undefined4 FUN_008b45a0(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar2 = FUN_00a9d0e0(param_1);
  if (iVar2 != 0) {
    iVar1 = *(int *)(iVar2 + 0xc);
    iVar3 = FUN_008aa870();
    iVar4 = 0;
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) {
      iVar4 = iVar2;
    }
    if (iVar4 != 0) {
      return *(undefined4 *)(iVar4 + 0x1b4);
    }
  }
  return 0;
}



/* FUNCTION 14713 ; VA 0x008b45f0 ; FUN_008b45f0 */

void __fastcall FUN_008b45f0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  int *piVar9;
  int iVar10;
  undefined8 uVar11;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd6fc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edfbb8) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01edfbb8), DAT_01edfbb8 == -1)) {
    uStack_8 = 0;
    uVar11 = FUN_0152dab0(&DAT_018cb3fc,"handleFallenParts",0xffffffff);
    if (DAT_01d7ad40 != '\0') {
      FUN_01532a30(uVar11);
    }
    uStack_8 = 0xffffffff;
    DAT_01edfbb0 = (int)uVar11;
    DAT_01edfbb4 = (int)((ulonglong)uVar11 >> 0x20);
    FUN_016f37bf(&DAT_01edfbb8);
  }
  uStack_24 = DAT_01edfbb0;
  uStack_20 = DAT_01edfbb4;
  uVar11 = FUN_01532c80(DAT_01edfbb0,DAT_01edfbb4);
  iVar10 = param_1 + 0x2a0;
  uStack_8 = 1;
  iStack_18 = iVar10;
  FUN_00bbc4b0(iVar10);
  piVar2 = (int *)(param_1 + 0x294);
  FUN_00b0a360(iVar10,piVar2);
  iVar6 = FUN_0097ee20(param_1);
  iVar7 = *piVar2;
  if (iVar6 == 1) {
    uVar8 = 0;
    if (*(int *)(param_1 + 0x298) - iVar7 >> 3 != 0) {
      do {
        piVar9 = *(int **)(iVar7 + 4 + uVar8 * 8);
        if (piVar9 != (int *)0x0) {
          LOCK();
          piVar9[1] = piVar9[1] + 1;
          UNLOCK();
          piVar9 = *(int **)(iVar7 + 4 + uVar8 * 8);
        }
        uStack_2c = *(undefined4 *)(iVar7 + uVar8 * 8);
        uStack_8._0_1_ = 2;
        piStack_28 = piVar9;
        FUN_00b0df50(1);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        if (piVar9 != (int *)0x0) {
          LOCK();
          iVar10 = piVar9[1] + -1;
          piVar9[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piVar9)();
            LOCK();
            iVar10 = piVar9[2] + -1;
            piVar9[2] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar9 + 4))();
            }
          }
        }
        uVar8 = uVar8 + 1;
        iVar7 = *piVar2;
        iVar10 = iStack_18;
      } while (uVar8 < (uint)(*(int *)(param_1 + 0x298) - iVar7 >> 3));
    }
  }
  else {
    uStack_14 = 0;
    if (*(int *)(param_1 + 0x298) - iVar7 >> 3 != 0) {
      do {
        piVar9 = *(int **)(iVar7 + 4 + uStack_14 * 8);
        if (piVar9 != (int *)0x0) {
          LOCK();
          piVar9[1] = piVar9[1] + 1;
          UNLOCK();
          piVar9 = *(int **)(iVar7 + 4 + uStack_14 * 8);
        }
        uStack_8._0_1_ = 3;
        FUN_0060dcd0(&uStack_2c,*(undefined4 *)(*(int *)(iVar7 + uStack_14 * 8) + 0x34));
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
        FUN_008a65e0(0,0);
        FUN_008b0070(&uStack_2c);
        piVar3 = piStack_28;
        if (piStack_28 != (int *)0x0) {
          LOCK();
          iVar10 = piStack_28[1] + -1;
          piStack_28[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piStack_28)();
            LOCK();
            piVar1 = piVar3 + 2;
            iVar10 = *piVar1 + -1;
            *piVar1 = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        if (piVar9 != (int *)0x0) {
          LOCK();
          iVar10 = piVar9[1] + -1;
          piVar9[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piVar9)();
            LOCK();
            iVar10 = piVar9[2] + -1;
            piVar9[2] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar9 + 4))();
            }
          }
        }
        iVar7 = *piVar2;
        uStack_14 = uStack_14 + 1;
        iVar10 = iStack_18;
      } while (uStack_14 < (uint)(*(int *)(param_1 + 0x298) - iVar7 >> 3));
    }
  }
  FUN_00843670(0,piVar2);
  iVar7 = *(int *)(iVar10 + 4);
  if (iVar7 != 0) {
    *(undefined4 *)(iVar10 + 4) = 0;
    if (*(int *)(iVar10 + 8) < 0) {
      if (*(int *)(iVar10 + 8) == 0) {
        *(undefined4 *)(iVar10 + 8) = 0;
      }
      else {
        *(undefined4 *)(iVar10 + 8) = 10;
      }
      FUN_0078c480(iVar7);
    }
  }
  uVar5 = uStack_20;
  uVar4 = uStack_24;
  uStack_8 = 5;
  FUN_0152dda0(uStack_24,uStack_20,uVar11);
  if (DAT_01d7ad40 != '\0') {
    FUN_01532d10(uVar4,uVar5,uVar11);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14714 ; VA 0x008b48c0 ; FUN_008b48c0 */

void FUN_008b48c0(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = FUN_00b06640(param_1);
  if (iVar1 != 0) {
    FUN_005e66b0(iVar1,param_2);
  }
  return;
}



/* FUNCTION 14715 ; VA 0x008b48f0 ; FUN_008b48f0 */

void FUN_008b48f0(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_00b06640(param_1);
  if (iVar1 != 0) {
    FUN_005e6780(iVar1);
  }
  return;
}



/* FUNCTION 14716 ; VA 0x008b4920 ; FUN_008b4920 */

void FUN_008b4920(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = FUN_00b06640(param_1);
  if (iVar1 != 0) {
    FUN_005e66b0(iVar1,param_2);
  }
  return;
}



/* FUNCTION 14717 ; VA 0x008b4950 ; FUN_008b4950 */

undefined4 * __thiscall FUN_008b4950(int param_1,undefined4 *param_2,undefined4 param_3)

{
  ulonglong uVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  uint *puVar5;
  int iVar6;
  undefined4 *puVar7;
  uint uVar8;
  int *piVar9;
  undefined auStack_12c [24];
  undefined auStack_114 [36];
  ulonglong uStack_f0;
  undefined4 uStack_e8;
  undefined auStack_e4 [12];
  undefined auStack_d8 [16];
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  uint uStack_bc;
  undefined8 uStack_b8;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  uint uStack_a4;
  int *piStack_a0;
  undefined4 uStack_9c;
  undefined auStack_94 [4];
  int *piStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  int iStack_80;
  undefined8 uStack_7c;
  undefined4 uStack_74;
  uint uStack_70;
  uint uStack_6c;
  int *piStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  uint uStack_58;
  int *piStack_54;
  int aiStack_50 [2];
  int iStack_48;
  undefined4 uStack_44;
  int iStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int *apiStack_30 [2];
  undefined4 uStack_28;
  int iStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd72b;
  pvStack_10 = ExceptionList;
  uStack_9c = 0;
  cStack_11 = '\0';
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uStack_18 = (**(code **)(*(int *)(param_1 + 0x144) + 8))();
  iStack_24 = FUN_008acff0(param_1);
  iVar3 = FUN_008accc0(param_1);
  iStack_20 = FUN_0097bfc0(param_1);
  if (((uStack_18 != 0) && (iVar3 != 0)) && (iStack_20 != 0)) {
    iStack_80 = *(int *)(iVar3 + 0x9c);
    if (iStack_80 != 0) {
      LOCK();
      *(int *)(iStack_80 + 4) = *(int *)(iStack_80 + 4) + 1;
      UNLOCK();
      iStack_80 = *(int *)(iVar3 + 0x9c);
    }
    uStack_84 = *(undefined4 *)(iVar3 + 0x98);
    uStack_8 = 0;
    iVar4 = FUN_006e16a0(uStack_84);
    uStack_8 = 0xffffffff;
    FUN_00550b30();
    if (iVar4 != 0) {
      FUN_00b08340(auStack_d8,*(undefined4 *)(iVar3 + 0xa0),1);
      FUN_00d814c0(&uStack_8c);
      FUN_0060f290();
      if ((iStack_24 == 0) || (*(char *)(iStack_24 + 0x6c) == '\0')) {
        puVar7 = (undefined4 *)FUN_00d27140(auStack_12c,uStack_8c,uStack_88,0);
        uStack_c8 = *puVar7;
        uStack_c4 = puVar7[1];
        uStack_c0 = puVar7[2];
        uStack_bc = puVar7[3];
        uStack_b8 = *(undefined8 *)(puVar7 + 4);
      }
      else {
        FUN_0071f260(auStack_114,*(int *)(iStack_24 + 0x104) * 0x30 + iStack_24 + 0x70);
        puVar5 = (uint *)FUN_011612d0(auStack_e4,2);
        uStack_bc = *puVar5 ^ DAT_018c4ea0;
        uStack_6c = puVar5[1] ^ DAT_018c4ea0;
        piStack_90 = (int *)(puVar5[2] ^ DAT_018c4ea0);
        uStack_7c = uStack_f0;
        uVar1 = uStack_7c;
        uStack_74 = uStack_e8;
        uStack_7c._0_4_ = (undefined4)uStack_f0;
        uStack_7c._4_4_ = (undefined4)(uStack_f0 >> 0x20);
        uStack_c8 = (undefined4)uStack_7c;
        uStack_c4 = uStack_7c._4_4_;
        uStack_c0 = uStack_e8;
        uStack_b8 = CONCAT44(piStack_90,uStack_6c);
        uStack_7c = uVar1;
        uStack_70 = uStack_bc;
        piStack_68 = piStack_90;
      }
      FUN_0115cc20(&uStack_3c,auStack_d8);
      iVar3 = FUN_00676e20();
      if (((iVar3 != 0) && (cVar2 = FUN_01160820(uStack_3c), cVar2 != '\0')) &&
         ((cVar2 = FUN_01160820(uStack_38), cVar2 != '\0' &&
          (cVar2 = FUN_01160820(uStack_34), cVar2 != '\0')))) {
        FUN_005c9430(apiStack_30);
        uStack_8 = 1;
        if (apiStack_30[0] != (int *)0x0) {
          iStack_20 = *apiStack_30[0];
          iVar3 = apiStack_30[0][1];
          if (apiStack_30[0][1] != iStack_20) {
            do {
              iVar4 = *(int *)(iVar3 + -8);
              iStack_24 = iVar3 + -8;
              if ((iVar4 == 0) ||
                 (iVar3 = *(int *)(iVar4 + 0xc), iVar6 = FUN_00c68a10(),
                 (uint)*(ushort *)(iVar6 + 0x1da) <
                 (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
                iVar4 = 0;
              }
              if (iVar4 != 0) {
                FUN_00c6a030(aiStack_50,param_3,uStack_3c,uStack_38,uStack_34);
                if (aiStack_50[0] == 1) {
                  iStack_48 = 1;
                  FUN_008ad9c0(aiStack_50);
                  FUN_008ae7d0();
                  FUN_00550b30();
                  ExceptionList = pvStack_10;
                  return param_2;
                }
                if (iStack_48 == 1) {
                  uStack_1c = 0;
                  uStack_18 = 0;
                  if (iStack_40 != 0) {
                    piVar9 = (int *)(iStack_40 + 4);
                    iVar3 = *(int *)(iStack_40 + 4);
                    while (iVar3 != 0) {
                      LOCK();
                      iVar4 = *piVar9;
                      if (iVar3 == iVar4) {
                        *piVar9 = iVar3 + 1;
                        iVar4 = iVar3;
                      }
                      UNLOCK();
                      if (iVar4 == iVar3) {
                        uStack_1c = uStack_44;
                        uStack_18 = iStack_40;
                        break;
                      }
                      iVar3 = *piVar9;
                    }
                  }
                  uStack_28 = uStack_1c;
                  FUN_00550b30();
                  cStack_11 = '\x01';
                }
                FUN_008ae7d0();
              }
              iVar3 = iStack_24;
            } while (iStack_24 != iStack_20);
          }
        }
        uStack_8 = 0xffffffff;
        FUN_00550b30();
        if (cStack_11 != '\0') {
          uStack_64 = 0;
          uStack_60 = 0;
          uStack_5c = 1;
          FUN_0060e0c0(&uStack_58,0);
          puVar5 = &uStack_58;
          uVar8 = 10;
          param_3 = uStack_64;
          uStack_18 = uStack_58;
          uStack_ac = uStack_60;
          uStack_a8 = uStack_5c;
          goto LAB_008b4d78;
        }
      }
    }
  }
  piStack_68 = (int *)0x0;
  param_3 = 0;
  uStack_ac = 0;
  uStack_18 = 0;
  uStack_7c = uStack_7c & 0xffffffff;
  uStack_74 = 0;
  uStack_70 = 0;
  uStack_6c = 0;
  uVar8 = 4;
  puVar5 = &uStack_6c;
  uStack_a8 = 0;
LAB_008b4d78:
  piVar9 = (int *)puVar5[1];
  uStack_a4 = uStack_18;
  *puVar5 = 0;
  puVar5[1] = 0;
  uStack_8 = 2;
  uStack_b0 = param_3;
  piStack_a0 = piVar9;
  iStack_24 = uStack_a8;
  iStack_20 = uStack_ac;
  if (((uVar8 & 4) != 0) &&
     (uStack_18 = uVar8 & 0xfffffffb, uVar8 = uStack_18, piStack_68 != (int *)0x0)) {
    LOCK();
    iVar3 = piStack_68[2] + -1;
    piStack_68[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piStack_68 + 4))();
      uVar8 = uStack_18;
    }
  }
  if (((uVar8 & 2) != 0) && (piStack_54 != (int *)0x0)) {
    LOCK();
    iVar3 = piStack_54[2] + -1;
    piStack_54[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piStack_54 + 4))();
    }
  }
  puVar7 = (undefined4 *)FUN_0060e0c0(auStack_94,uStack_28);
  uStack_28 = *puVar7;
  uStack_18 = puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  if (piVar9 != (int *)0x0) {
    LOCK();
    iVar3 = piVar9[2] + -1;
    piVar9[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar9 + 4))();
    }
  }
  if (piStack_90 != (int *)0x0) {
    LOCK();
    piVar9 = piStack_90 + 2;
    iVar3 = *piVar9;
    *piVar9 = *piVar9 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piStack_90 + 4))();
    }
  }
  *param_2 = param_3;
  param_2[1] = iStack_20;
  param_2[2] = iStack_24;
  param_2[3] = uStack_28;
  param_2[4] = uStack_18;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14718 ; VA 0x008b4e80 ; FUN_008b4e80 */

undefined4 * __thiscall FUN_008b4e80(int param_1,undefined4 *param_2,int *param_3)

{
  undefined8 uVar1;
  int iVar2;
  undefined3 uVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 *puVar8;
  uint *puVar9;
  undefined8 *puVar10;
  int *piVar11;
  undefined auStack_13c [24];
  undefined auStack_124 [36];
  undefined8 uStack_100;
  undefined4 uStack_f8;
  undefined auStack_f4 [12];
  undefined auStack_e8 [12];
  undefined auStack_dc [8];
  undefined auStack_d4 [8];
  undefined auStack_cc [8];
  undefined auStack_c4 [4];
  undefined4 *puStack_c0;
  undefined auStack_bc [4];
  int *piStack_b8;
  undefined8 uStack_b4;
  undefined4 uStack_ac;
  float fStack_a8;
  float fStack_a4;
  int *piStack_a0;
  undefined auStack_98 [4];
  int *piStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined auStack_7c [4];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  float fStack_6c;
  undefined8 uStack_68;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  int iStack_54;
  int iStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  int iStack_40;
  undefined4 uStack_3c;
  int *piStack_38;
  undefined auStack_34 [4];
  int iStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd789;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_50 = param_1;
  iStack_14 = (**(code **)(*(int *)(param_1 + 0x144) + 4))();
  iStack_40 = FUN_008acff0(param_1);
  iStack_18 = 0;
  iStack_30 = 0;
  iVar4 = FUN_006ebc30(param_1);
  uStack_24 = CONCAT44(iVar4,(undefined4)uStack_24);
  if (iVar4 != 0) {
    piVar5 = (int *)FUN_00587490(auStack_bc);
    iStack_18 = *piVar5;
    piStack_1c = piStack_b8;
    if (piStack_b8 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_b8[1] + -1;
      piStack_b8[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_b8)();
        LOCK();
        iVar4 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    piVar5 = (int *)FUN_00587490(auStack_c4);
    iStack_30 = *piVar5;
    uStack_24 = CONCAT44(puStack_c0,(undefined4)uStack_24);
    if (puStack_c0 != (undefined4 *)0x0) {
      LOCK();
      iVar4 = puStack_c0[1] + -1;
      puStack_c0[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*puStack_c0)();
        LOCK();
        iVar4 = uStack_24._4_4_[2] + -1;
        uStack_24._4_4_[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*uStack_24._4_4_ + 4))();
        }
      }
    }
  }
  if ((DAT_01f22888 == 0) ||
     (((4 < *(uint *)(*param_3 + 0x54) && (*(uint *)(*param_3 + 0x54) != 7)) || (iStack_14 == 0))))
  goto LAB_008b552b;
  piStack_38 = (int *)FUN_0097bfc0(param_1);
  if (((piStack_38 != (int *)0x0) && (piStack_38[0x19] != 0)) &&
     (puVar8 = *(undefined4 **)(piStack_38[0x19] + 0x2c), puVar8 != (undefined4 *)0x0)) {
    piVar5 = (int *)puVar8[1];
    for (piVar11 = (int *)*puVar8; piVar11 != piVar5; piVar11 = piVar11 + 2) {
      if (*piVar11 != 0) {
        uStack_24 = CONCAT44(*(undefined4 *)(*piVar11 + 0xc),(undefined4)uStack_24);
        iVar4 = FUN_00c46280();
        if ((uint)*(ushort *)((int)uStack_24._4_4_ + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
            (uint)*(ushort *)(iVar4 + 0x1da)) {
          piStack_1c = (int *)((uint)piStack_1c & 0xffffff00);
          goto LAB_008b4ffe;
        }
      }
    }
  }
  piStack_1c = (int *)CONCAT31(piStack_1c._1_3_,1);
LAB_008b4ffe:
  iVar4 = iStack_18;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_60 = 0;
  uStack_5c = 0;
  uStack_58 = 0;
  uStack_8._1_3_ = 0;
  uVar3 = uStack_8._1_3_;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  if (iStack_18 != 0) {
    uVar6 = FUN_008acc90();
    uVar6 = FUN_0060dcd0(auStack_cc,uVar6);
    uStack_8._0_1_ = 2;
    FUN_008a4660(uVar6);
    uStack_8._0_1_ = 1;
    FUN_00550b30();
    uVar3 = uStack_8._1_3_;
  }
  uStack_8._1_3_ = uVar3;
  if (iStack_30 != 0) {
    uVar6 = FUN_008acc90();
    uVar6 = FUN_0060dcd0(auStack_34,uVar6);
    uStack_8._0_1_ = 3;
    FUN_008a4660(uVar6);
    uStack_8._0_1_ = 1;
    FUN_00550b30();
  }
  iVar2 = iStack_50;
  iVar7 = FUN_00a9d3e0();
  if (iVar7 != 0) {
    uVar6 = FUN_0060dcd0(auStack_d4,iVar7);
    uStack_8._0_1_ = 4;
    FUN_008a4660(uVar6);
    uStack_8._0_1_ = 1;
    FUN_00550b30();
  }
  if ((piStack_38 != (int *)0x0) && (piStack_38[0x19] != 0)) {
    puVar8 = (undefined4 *)FUN_0060dcd0(auStack_dc,piStack_38[0x19]);
    uStack_3c = *puVar8;
    piStack_38 = (int *)puVar8[1];
    *puVar8 = 0;
    puVar8[1] = 0;
    uStack_8._0_1_ = 6;
    FUN_008a4660(&uStack_3c);
    FUN_00550b30();
    uStack_8._0_1_ = 1;
    FUN_00550b30();
  }
  FUN_00d814c0(&uStack_90);
  if ((iStack_40 == 0) || (*(char *)(iStack_40 + 0x6c) == '\0')) {
    puVar8 = (undefined4 *)FUN_00d27140(auStack_13c,uStack_90,uStack_8c,0);
    uStack_78 = *puVar8;
    uStack_74 = puVar8[1];
    uStack_70 = puVar8[2];
    uStack_68._0_4_ = (float)*(undefined8 *)(puVar8 + 4);
    fStack_6c = (float)puVar8[3] * DAT_018ce324;
    uStack_68._4_4_ = (float)((ulonglong)*(undefined8 *)(puVar8 + 4) >> 0x20);
    uStack_68 = CONCAT44(uStack_68._4_4_ * DAT_018ce324,(float)uStack_68 * DAT_018ce324);
  }
  else {
    FUN_0071f260(auStack_124,*(int *)(iStack_40 + 0x104) * 0x30 + iStack_40 + 0x70);
    puVar9 = (uint *)FUN_011612d0(auStack_e8,2);
    fStack_a8 = (float)(*puVar9 ^ DAT_018c4ea0) * DAT_018ce324;
    uStack_ac = uStack_f8;
    fStack_a4 = (float)(puVar9[1] ^ DAT_018c4ea0) * DAT_018ce324;
    piStack_a0 = (int *)((float)(puVar9[2] ^ DAT_018c4ea0) * DAT_018ce324);
    uStack_b4 = uStack_100;
    uVar1 = uStack_b4;
    uStack_b4._0_4_ = (undefined4)uStack_100;
    uStack_b4._4_4_ = (undefined4)((ulonglong)uStack_100 >> 0x20);
    uStack_68 = CONCAT44(piStack_a0,fStack_a4);
    uStack_78 = (undefined4)uStack_b4;
    uStack_74 = uStack_b4._4_4_;
    uStack_70 = uStack_f8;
    uStack_b4 = uVar1;
    piStack_94 = piStack_a0;
    fStack_6c = fStack_a8;
  }
  piStack_2c = (int *)0x0;
  uStack_28 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  uStack_88 = 0;
  uStack_84 = 0;
  uStack_80 = 0;
  if (iVar4 == 0) {
LAB_008b532b:
    puVar10 = (undefined8 *)
              FUN_00a95450(&fStack_a8,&uStack_4c,uStack_78,uStack_74,uStack_70,fStack_6c,uStack_68,
                           &piStack_2c,&uStack_88,auStack_7c,0,0,0);
    uStack_24 = *puVar10;
    iStack_18 = *(int *)(puVar10 + 1);
  }
  else {
    puVar10 = (undefined8 *)
              FUN_00a95450(auStack_f4,&uStack_60,uStack_78,uStack_74,uStack_70,fStack_6c,uStack_68,
                           &piStack_2c,&uStack_88,auStack_7c,0,0,1);
    uStack_24 = *puVar10;
    iStack_18 = *(int *)(puVar10 + 1);
    if (piStack_2c == (int *)0x0) goto LAB_008b532b;
  }
  iStack_14 = 0;
  if (piStack_2c != (int *)0x0) {
    iStack_40 = 0;
    (**(code **)(*piStack_2c + 0x120))();
    if (iStack_54 != 0) {
      iStack_14 = FUN_00e98dd0(piStack_2c,iStack_50);
    }
  }
  iVar4 = *(int *)(iVar2 + 0x330);
  if (iVar4 != 0) {
    piVar5 = (int *)(iVar4 + 4);
    iVar4 = *(int *)(iVar4 + 4);
    while (iVar4 != 0) {
      LOCK();
      iVar7 = *piVar5;
      if (iVar4 == iVar7) {
        *piVar5 = iVar4 + 1;
        iVar7 = iVar4;
      }
      UNLOCK();
      if (iVar7 == iVar4) {
        iStack_30 = *(int *)(iVar2 + 0x32c);
        piStack_38 = *(int **)(iVar2 + 0x330);
        if (piStack_38 != (int *)0x0) {
          LOCK();
          iVar4 = piStack_38[1] + -1;
          piStack_38[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piStack_38)();
            LOCK();
            iVar4 = piStack_38[2] + -1;
            piStack_38[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piStack_38 + 4))();
            }
          }
        }
        if (((iStack_30 != 0) && (iStack_14 != iStack_30)) &&
           (iVar4 = FUN_008f7870(iStack_30), iVar4 != 0)) {
          FUN_00e9a840(param_3);
        }
        break;
      }
      iVar4 = *piVar5;
    }
  }
  puVar8 = (undefined4 *)FUN_0060dcd0(auStack_98,iStack_14);
  iVar4 = puVar8[1];
  if (iVar4 != 0) {
    LOCK();
    *(int *)(iVar4 + 8) = *(int *)(iVar4 + 8) + 1;
    UNLOCK();
    iVar4 = puVar8[1];
  }
  *(undefined4 *)(iVar2 + 0x32c) = *puVar8;
  piVar5 = *(int **)(iVar2 + 0x330);
  *(int *)(iVar2 + 0x330) = iVar4;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar4 = piVar5[2] + -1;
    piVar5[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar5 + 4))();
    }
  }
  piVar5 = piStack_94;
  if (piStack_94 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_94[1] + -1;
    piStack_94[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_94)();
      LOCK();
      piVar11 = piVar5 + 2;
      iVar4 = *piVar11;
      *piVar11 = *piVar11 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  if (iStack_14 != 0) {
    FUN_00e99750(param_2,param_3,uStack_24,iStack_18,piStack_1c);
    FUN_00550b30();
    thunk_FUN_00577ac0();
    thunk_FUN_00577ac0();
    ExceptionList = pvStack_10;
    return param_2;
  }
  FUN_00550b30();
  thunk_FUN_00577ac0();
  thunk_FUN_00577ac0();
LAB_008b552b:
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14719 ; VA 0x008b5570 ; FUN_008b5570 */

/* WARNING: Removing unreachable block (ram,0x008b5635) */
/* WARNING: Removing unreachable block (ram,0x008b5689) */
/* WARNING: Removing unreachable block (ram,0x008b567e) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_008b5570(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 *puVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bd7b0;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_2 + 8) != 0) {
    iVar2 = *(int *)(param_1 + 4);
    uStack_8 = 0;
    uStack_18 = (ulonglong)(uint)uStack_18;
    ExceptionList = &pvStack_10;
    FUN_005c24c0((int)&uStack_18 + 4,iVar2 + 1);
    if (*(int *)(param_1 + 0x14) != 0) {
      *(undefined4 *)(iVar2 * 4) =
           *(undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      iVar1 = *(int *)(param_1 + 4) * 4;
      uVar8 = iVar1 + 4;
      iVar3 = *(int *)(param_1 + 0x14);
      iVar6 = iVar3;
      if (0xfff < uVar8) {
        iVar6 = *(int *)(iVar3 + -4);
        uVar8 = iVar1 + 0x27;
        if (0x1f < (iVar3 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar6,uVar8);
    }
    *(int *)(param_1 + 4) = iVar2;
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    uStack_18 = uStack_18 >> 0x30;
    uStack_8 = 2;
    if (*(int *)(param_2 + 8) == 0) {
      puVar9 = (undefined4 *)0x0;
    }
    else {
      puVar9 = *(undefined4 **)(*(int *)(param_2 + 0x14) + *(int *)(param_2 + 4) * 4);
    }
    puVar5 = (undefined4 *)(iVar2 * 4);
    while (puVar9 != (undefined4 *)0x0) {
      uStack_18._6_2_ = (ushort)uStack_18;
      uStack_18._0_6_ = 0;
      puVar7 = (undefined4 *)FUN_01674e20();
      uStack_18 = (ulonglong)uStack_18._6_2_;
      *puVar7 = 0;
      puVar7[1] = 0;
      puVar7[2] = 0;
      puVar7[2] = puVar9[2];
      puVar7[1] = puVar9[1];
      *puVar5 = puVar7;
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
      puVar4 = (undefined4 *)*puVar5;
      puVar9 = (undefined4 *)*puVar9;
      uVar8 = (uint)puVar4[1] % *(uint *)(param_1 + 4);
      puVar7 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
      if (*(int *)(*(int *)(param_1 + 0x14) + uVar8 * 4) == 0) {
        *puVar7 = puVar5;
        puVar5 = puVar4;
      }
      else {
        *puVar5 = *puVar4;
        *puVar4 = *(undefined4 *)*puVar7;
        *(undefined4 **)*puVar7 = puVar4;
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14720 ; VA 0x008b5770 ; FUN_008b5770 */

void FUN_008b5770(void)

{
  FUN_00bbdc60(7);
  return;
}



/* FUNCTION 14721 ; VA 0x008b5790 ; FUN_008b5790 */

void FUN_008b5790(void)

{
  FUN_00bbdc60(6);
  return;
}



/* FUNCTION 14722 ; VA 0x008b57b0 ; FUN_008b57b0 */

void FUN_008b57b0(void)

{
  FUN_00bbdc60(5);
  return;
}



/* FUNCTION 14723 ; VA 0x008b57d0 ; FUN_008b57d0 */

void FUN_008b57d0(void)

{
  FUN_00bbdc60(4);
  return;
}



/* FUNCTION 14724 ; VA 0x008b57f0 ; FUN_008b57f0 */

void FUN_008b57f0(undefined4 *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x008b57fc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)*param_1)();
  return;
}



/* FUNCTION 14725 ; VA 0x008b5800 ; FUN_008b5800 */

void FUN_008b5800(undefined4 *param_1)

{
  (*(code *)*param_1)(param_1[2]);
  return;
}



/* FUNCTION 14726 ; VA 0x008b5820 ; FUN_008b5820 */

void FUN_008b5820(undefined4 *param_1)

{
  (*(code *)*param_1)();
  return;
}



/* FUNCTION 14727 ; VA 0x008b5840 ; FUN_008b5840 */

void FUN_008b5840(undefined4 *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x008b5860. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)*param_1)();
  return;
}



/* FUNCTION 14728 ; VA 0x008b5870 ; FUN_008b5870 */

bool __thiscall FUN_008b5870(int param_1,undefined4 *param_2)

{
  if ((((param_2 != &DAT_0211b270) && (param_2 != &DAT_0212ccf0)) &&
      ((*(char *)(param_1 + 0x300) != '\0' ||
       (((param_2 != (undefined4 *)&DAT_0211afb0 && (param_2 != (undefined4 *)&DAT_0211af78)) &&
        (param_2 != &DAT_0211afe8)))))) &&
     (((param_2 != &DAT_0211b028 || (DAT_01d6f4e8 != '\0')) || (DAT_01d6f4f0 != '\0')))) {
    if (param_2 == &DAT_0211b2e0) {
      return DAT_01d62dac == '\0';
    }
    return false;
  }
  return true;
}



/* FUNCTION 14729 ; VA 0x008b58e0 ; FUN_008b58e0 */

undefined4 * __thiscall FUN_008b58e0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_008ac040(auStack_c,param_1 + 0x28);
  *param_2 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_2[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_2;
  }
  return param_2;
}



/* FUNCTION 14730 ; VA 0x008b5950 ; FUN_008b5950 */

void FUN_008b5950(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  return;
}



/* FUNCTION 14731 ; VA 0x008b5970 ; FUN_008b5970 */

void __thiscall FUN_008b5970(int param_1,int param_2,int param_3)

{
  undefined4 *puVar1;
  undefined uVar2;
  char cVar3;
  undefined4 ****ppppuVar4;
  int iVar5;
  int iVar6;
  undefined4 *puVar7;
  code ****ppppcVar8;
  undefined4 ****ppppuVar9;
  undefined4 uVar10;
  char *pcVar11;
  int iVar12;
  uint uVar13;
  int *piVar14;
  int *piVar15;
  undefined4 uVar16;
  undefined4 uVar17;
  undefined4 uVar18;
  undefined auStack_d8 [8];
  undefined4 ***apppuStack_d0 [5];
  uint uStack_bc;
  undefined4 ***apppuStack_b8 [4];
  int iStack_a8;
  uint uStack_a4;
  undefined4 ***apppuStack_a0 [4];
  undefined4 uStack_90;
  uint uStack_8c;
  code *pcStack_88;
  undefined1 *puStack_84;
  undefined4 ***pppuStack_80;
  undefined4 ***pppuStack_7c;
  ulonglong uStack_78;
  int iStack_70;
  int *piStack_6c;
  undefined auStack_68 [8];
  code ***pppcStack_60;
  undefined1 *puStack_5c;
  char *pcStack_58;
  undefined4 ***pppuStack_54;
  int iStack_50;
  uint uStack_4c;
  code *pcStack_48;
  undefined1 *puStack_44;
  undefined4 ***pppuStack_40;
  undefined4 ***pppuStack_3c;
  undefined8 uStack_38;
  int iStack_30;
  int iStack_2c;
  int *piStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd812;
  pvStack_10 = ExceptionList;
  iStack_20 = 0;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  if (DAT_01d62d6c != '\0') {
    uVar10 = (undefined4)(uStack_38 >> 0x20);
    puStack_44 = &DAT_018c5f98;
    iVar12 = *(int *)(param_1 + 0x278) - *(int *)(*(int *)(param_1 + 0x1b4) + 0x648);
    uStack_38 = CONCAT44(uVar10,iVar12) & 0xffffff00ffffffff;
    pppuStack_7c = &DAT_01d7a8e8;
    if (0xf < DAT_01d7a8fc) {
      pppuStack_7c = DAT_01d7a8e8;
    }
    pppuStack_40 = (undefined4 ***)0x191fdcc;
    pcStack_88 = FUN_0087c450;
    puStack_84 = &DAT_018c5f98;
    pppuStack_80 = (undefined4 ***)0x191fdcc;
    uStack_78 = CONCAT44(uVar10,iVar12) & 0xffffff00ffffffff;
    ExceptionList = &pvStack_10;
    pppuStack_3c = pppuStack_7c;
    FUN_008ab7d0(&DAT_01edfc0c,&pcStack_88);
  }
  cStack_11 = *(char *)(*(int *)(param_1 + 0x1b4) + 0xe8);
  if (cStack_11 != '\x01') {
    *(undefined *)(*(int *)(param_1 + 0x1b4) + 0xe8) = 1;
    FUN_008a4940(&DAT_0211b0e8);
  }
  if (DAT_01d62d24 != '\0') {
    pcVar11 = "JoinAllExplicitAutoJoints";
    if (cStack_11 == '\0') {
      pcVar11 = "JoinAllImplicitAutoJoints";
    }
    ppppuVar4 = &DAT_01d7a8e8;
    if (0xf < DAT_01d7a8fc) {
      ppppuVar4 = DAT_01d7a8e8;
    }
    FUN_0087c450(&DAT_018c5f98,pcVar11,ppppuVar4,0,0,0);
  }
  if ((DAT_01d69070 == '\0') && (cStack_11 == '\0')) {
    piStack_18 = *(int **)(param_1 + 0x1b4);
    iVar12 = 0;
    if (0 < piStack_18[0x33]) {
      do {
        iStack_20 = *(int *)(piStack_18[0x32] + iVar12 * 4);
        if ((*(int **)(iStack_20 + 0x1ac) == (int *)0x0) ||
           (iVar5 = (**(code **)(**(int **)(iStack_20 + 0x1ac) + 8))(), iVar5 != 10)) {
          iVar5 = 0;
          do {
            cVar3 = *(char *)(iStack_20 + 0x22f + iVar5);
            if ((cVar3 != '\0') && (cVar3 != '\n')) {
              uVar18 = 0;
              uVar17 = 0;
              uVar16 = 0;
              uVar10 = FUN_00b06640(iStack_20,0,0,0);
              FUN_00a97a80(uVar10,uVar16,uVar17,uVar18);
              break;
            }
            iVar5 = iVar5 + 1;
          } while (iVar5 < 6);
        }
        iVar12 = iVar12 + 1;
      } while (iVar12 < piStack_18[0x33]);
    }
  }
  iStack_30 = *(int *)(param_1 + 0x1b4);
  piStack_28 = (int *)0x0;
  if (0 < *(int *)(iStack_30 + 0xcc)) {
    do {
      iVar12 = FUN_00b06640(*(undefined4 *)(*(int *)(iStack_30 + 200) + (int)piStack_28 * 4));
      if ((iVar12 != 0) &&
         (iVar5 = *(int *)(iVar12 + 0xc), iVar6 = FUN_00b50240(),
         (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
         (uint)*(ushort *)(iVar6 + 0x1da))) {
        FUN_00b4e030();
        puVar7 = (undefined4 *)FUN_00a33fa0();
        puVar1 = puVar7 + 4;
        if (0xf < (uint)puVar7[5]) {
          puVar7 = (undefined4 *)*puVar7;
        }
        cVar3 = FUN_0055c360(puVar7,*puVar1,&DAT_018bc9b8,0);
        if (cVar3 != '\0') {
          iVar5 = *(int *)(iVar12 + 0xc);
          iVar6 = FUN_00b50240();
          if ((uint)*(ushort *)(iVar6 + 0x1da) <
              (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)) {
            iVar12 = *(int *)(iVar12 + 0xc);
            iVar5 = FUN_00cfb1a0();
            if ((uint)*(ushort *)(iVar12 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
                (uint)*(ushort *)(iVar5 + 0x1da)) {
              FUN_00cfd9b0();
            }
          }
          else {
            FUN_00b54df0();
          }
        }
      }
      piStack_28 = (int *)((int)piStack_28 + 1);
      param_1 = iStack_1c;
    } while ((int)piStack_28 < *(int *)(iStack_30 + 0xcc));
  }
  if (*(int *)(param_1 + 0x2b8) != 0) {
    iVar12 = FUN_008f7870(param_1);
    if (iVar12 == 0) {
      iVar5 = 0;
    }
    else {
      iVar5 = iVar12 + 0xc;
    }
    iVar5 = FUN_008f7870(iVar5);
    if ((iVar5 == 0) || (iVar5 == -0xc)) {
      piStack_18 = (int *)0x0;
    }
    else {
      piStack_18 = (int *)FUN_0055e000();
    }
    if (DAT_01d62d44 != '\0') {
      piVar14 = *(int **)(iVar12 + 0x43c);
      iStack_24 = *piVar14 - (int)piVar14;
      iStack_20 = piVar14[1] - (int)piVar14;
      FUN_009ee550(apppuStack_d0,&iStack_24);
      puStack_44 = &DAT_018bee70;
      pppuStack_7c = apppuStack_d0;
      if (0xf < uStack_bc) {
        pppuStack_7c = apppuStack_d0[0];
      }
      pppuStack_40 = (undefined4 ***)0x191fe20;
      uStack_38 = uStack_38 & 0xffffff0000000000;
      puStack_5c = &DAT_018bee70;
      pcStack_58 = "MigrateTriangleMeshData_PLACE";
      iStack_50 = 0;
      pppcStack_60 = (code ***)FUN_0087c450;
      uStack_4c = uStack_38._4_4_;
      pcStack_88 = FUN_0087c450;
      puStack_84 = &DAT_018bee70;
      pppuStack_80 = (undefined4 ***)0x191fe20;
      uStack_78 = (ulonglong)uStack_38._4_4_ << 0x20;
      iStack_8 = 0;
      pppuStack_54 = pppuStack_7c;
      pppuStack_3c = pppuStack_7c;
      FUN_008ab7d0(&DAT_01edfc14,&pcStack_88);
      iStack_50 = 0;
      uStack_4c = 0xf;
      pppcStack_60 = (code ***)((uint)pppcStack_60 & 0xffffff00);
      FUN_005542c0("MigrateTriangleMeshData_COUNT_",0x1e);
      iVar12 = *(int *)(param_1 + 0x2b8);
      piStack_28 = (int *)0x0;
      iStack_8._0_1_ = 1;
      if ((int)DAT_01d62c68 < iVar12) {
        piStack_28 = DAT_01d62c68;
      }
      else if ((int)DAT_01d62c60 < iVar12) {
        piStack_28 = DAT_01d62c60;
      }
      else if ((int)DAT_01d62c58 < iVar12) {
        piStack_28 = DAT_01d62c58;
      }
      FUN_009ee270(apppuStack_b8,&piStack_28);
      iVar12 = iStack_50;
      ppppuVar4 = apppuStack_d0;
      if (0xf < uStack_bc) {
        ppppuVar4 = (undefined4 ****)apppuStack_d0[0];
      }
      iStack_8._0_1_ = 3;
      uStack_90 = 0;
      uStack_8c = 0xf;
      apppuStack_a0[0] = (undefined4 ***)((uint)apppuStack_a0[0] & 0xffffff00);
      iStack_20 = 1;
      FUN_0058a190(iStack_a8 + iStack_50);
      ppppcVar8 = &pppcStack_60;
      if (0xf < uStack_4c) {
        ppppcVar8 = (code ****)pppcStack_60;
      }
      FUN_00554150(ppppcVar8,iVar12);
      ppppuVar9 = apppuStack_b8;
      if (0xf < uStack_a4) {
        ppppuVar9 = (undefined4 ****)apppuStack_b8[0];
      }
      FUN_00554150(ppppuVar9,iStack_a8);
      pppuStack_80 = apppuStack_a0;
      if (0xf < uStack_8c) {
        pppuStack_80 = apppuStack_a0[0];
      }
      uStack_38 = uStack_38 & 0xffffff0000000000;
      puStack_84 = &DAT_018bee70;
      pcStack_88 = FUN_0087c450;
      uStack_78 = uStack_38;
      pcStack_48 = FUN_0087c450;
      puStack_44 = &DAT_018bee70;
      pppuStack_7c = ppppuVar4;
      pppuStack_40 = pppuStack_80;
      pppuStack_3c = ppppuVar4;
      FUN_008ab7d0(&DAT_01edfc1c,&pcStack_48);
      iStack_8._0_1_ = 2;
      uVar2 = (undefined)iStack_8;
      iStack_8._0_1_ = 2;
      if (0xf < uStack_8c) {
        uVar13 = uStack_8c + 1;
        ppppuVar4 = (undefined4 ****)apppuStack_a0[0];
        if (0xfff < uVar13) {
          ppppuVar4 = (undefined4 ****)apppuStack_a0[0][-1];
          uVar13 = uStack_8c + 0x24;
          if (0x1f < (uint)((int)apppuStack_a0[0] + (-4 - (int)ppppuVar4))) {
            iStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar4,uVar13);
      }
      iStack_8._0_1_ = 1;
      uVar2 = (undefined)iStack_8;
      iStack_8._0_1_ = 1;
      if (0xf < uStack_a4) {
        uVar13 = uStack_a4 + 1;
        ppppuVar4 = (undefined4 ****)apppuStack_b8[0];
        if (0xfff < uVar13) {
          ppppuVar4 = (undefined4 ****)apppuStack_b8[0][-1];
          uVar13 = uStack_a4 + 0x24;
          if (0x1f < (uint)((int)apppuStack_b8[0] + (-4 - (int)ppppuVar4))) {
            iStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar4,uVar13);
      }
      iStack_a8 = 0;
      uStack_a4 = 0xf;
      apppuStack_b8[0] = (undefined4 ***)((uint)apppuStack_b8[0] & 0xffffff00);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (0xf < uStack_4c) {
        uVar13 = uStack_4c + 1;
        ppppcVar8 = (code ****)pppcStack_60;
        if (0xfff < uVar13) {
          ppppcVar8 = (code ****)pppcStack_60[-1];
          uVar13 = uStack_4c + 0x24;
          if (0x1f < (uint)((int)pppcStack_60 + (-4 - (int)ppppcVar8))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppcVar8,uVar13);
      }
      iStack_8 = 0xffffffff;
      param_1 = iStack_1c;
      if (0xf < uStack_bc) {
        uVar13 = uStack_bc + 1;
        ppppuVar4 = (undefined4 ****)apppuStack_d0[0];
        if (0xfff < uVar13) {
          ppppuVar4 = (undefined4 ****)apppuStack_d0[0][-1];
          uVar13 = uStack_bc + 0x24;
          if (0x1f < (uint)((int)apppuStack_d0[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar4,uVar13);
        param_1 = iStack_1c;
      }
    }
    iStack_20 = param_1 + 0x2b0;
    if (*(int *)(param_1 + 0x2b8) == 0) {
      piVar14 = (int *)0x0;
      iVar12 = 0;
    }
    else {
      piVar14 = *(int **)(*(int *)(param_1 + 0x2c4) + *(int *)(param_1 + 0x2b4) * 4);
      iVar12 = *(int *)(param_1 + 0x2b8);
    }
    if (piVar14 != (int *)0x0) {
      do {
        piVar15 = (int *)piVar14[3];
        if (piVar15 != (int *)0x0) {
          LOCK();
          piVar15[1] = piVar15[1] + 1;
          UNLOCK();
          piVar15 = (int *)piVar14[3];
        }
        iStack_2c = piVar14[2];
        iStack_8 = 4;
        piStack_28 = piVar15;
        FUN_00b4e260(piStack_18);
        iStack_8 = 0xffffffff;
        if (piVar15 != (int *)0x0) {
          LOCK();
          iVar12 = piVar15[1] + -1;
          piVar15[1] = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            (**(code **)*piVar15)();
            LOCK();
            iVar12 = piVar15[2] + -1;
            piVar15[2] = iVar12;
            UNLOCK();
            if (iVar12 == 0) {
              (**(code **)(*piVar15 + 4))();
            }
          }
        }
        piVar14 = (int *)*piVar14;
      } while (piVar14 != (int *)0x0);
      iVar12 = *(int *)(iStack_20 + 8);
      param_1 = iStack_1c;
    }
    if (iVar12 != 0) {
      FUN_008b20f0(*(int *)(iStack_20 + 0x14) + *(int *)(iStack_20 + 4) * 4,0);
      puVar7 = *(undefined4 **)(param_1 + 0x2c4);
      puVar1 = puVar7 + *(int *)(param_1 + 0x2b4);
      for (; puVar7 != puVar1; puVar7 = puVar7 + 1) {
        *puVar7 = 0;
      }
    }
  }
  if (DAT_01d62dcc != '\0') {
    iVar12 = FUN_008f7870(param_1);
    if (iVar12 == 0) {
      iVar5 = 0;
    }
    else {
      iVar5 = iVar12 + 0xc;
    }
    iVar5 = FUN_008f7870(iVar5);
    if ((iVar5 == 0) || (iVar5 == -0xc)) {
      iStack_20 = 0;
    }
    else {
      iStack_20 = FUN_0055e000();
    }
    if ((iVar12 == 0) || (iVar12 == -0xc)) {
      piStack_28 = (int *)0x0;
    }
    else {
      piStack_28 = (int *)FUN_0055e310();
    }
    piStack_18 = (int *)0x0;
    if (0 < *(int *)(iStack_30 + 0xcc)) {
      do {
        iVar12 = FUN_00b06640(*(undefined4 *)(*(int *)(iStack_30 + 200) + (int)piStack_18 * 4));
        if (((iVar12 != 0) &&
            (iVar5 = *(int *)(iVar12 + 0xc), iVar6 = FUN_00b50240(),
            (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
            (uint)*(ushort *)(iVar6 + 0x1da))) && (*(char *)(iVar12 + 0x1a0) == '\0')) {
          FUN_00b53a50();
          iVar5 = FUN_00a33fa0();
          if (*(int *)(iVar5 + 0x10) != 0) {
            uVar10 = FUN_0060dcd0(&iStack_70,iVar12);
            iStack_8 = 5;
            FUN_008aca90(auStack_d8,uVar10,uVar10);
            piVar14 = piStack_6c;
            iStack_8 = 0xffffffff;
            if (piStack_6c != (int *)0x0) {
              LOCK();
              iVar12 = piStack_6c[1] + -1;
              piStack_6c[1] = iVar12;
              UNLOCK();
              if (iVar12 == 0) {
                (**(code **)*piStack_6c)();
                LOCK();
                piVar15 = piVar14 + 2;
                iVar12 = *piVar15 + -1;
                *piVar15 = iVar12;
                UNLOCK();
                if (iVar12 == 0) {
                  (**(code **)(*piVar14 + 4))();
                }
              }
            }
          }
        }
        piStack_18 = (int *)((int)piStack_18 + 1);
        param_1 = iStack_1c;
      } while ((int)piStack_18 < *(int *)(iStack_30 + 0xcc));
    }
    if (*(int *)(param_1 + 0x2d0) != 0) {
      piStack_18 = (int *)(param_1 + 0x2c8);
      if (*(int *)(param_1 + 0x2d0) == 0) {
        piVar14 = (int *)0x0;
        iVar12 = 0;
      }
      else {
        piVar14 = *(int **)(*(int *)(param_1 + 0x2dc) + *(int *)(param_1 + 0x2cc) * 4);
        iVar12 = *(int *)(param_1 + 0x2d0);
      }
      if (piVar14 != (int *)0x0) {
        do {
          piVar15 = (int *)piVar14[3];
          if (piVar15 != (int *)0x0) {
            LOCK();
            piVar15[1] = piVar15[1] + 1;
            UNLOCK();
            piVar15 = (int *)piVar14[3];
          }
          iStack_70 = piVar14[2];
          iStack_8 = 6;
          piStack_6c = piVar15;
          FUN_00b54510(iStack_20,piStack_28,0);
          iStack_8 = 0xffffffff;
          if (piVar15 != (int *)0x0) {
            LOCK();
            iVar12 = piVar15[1] + -1;
            piVar15[1] = iVar12;
            UNLOCK();
            if (iVar12 == 0) {
              (**(code **)*piVar15)();
              LOCK();
              iVar12 = piVar15[2] + -1;
              piVar15[2] = iVar12;
              UNLOCK();
              if (iVar12 == 0) {
                (**(code **)(*piVar15 + 4))();
              }
            }
          }
          piVar14 = (int *)*piVar14;
        } while (piVar14 != (int *)0x0);
        iVar12 = piStack_18[2];
        param_1 = iStack_1c;
      }
      if (iVar12 != 0) {
        FUN_008b20f0(piStack_18[5] + piStack_18[1] * 4,0);
        puVar7 = *(undefined4 **)(param_1 + 0x2dc);
        puVar1 = puVar7 + *(int *)(param_1 + 0x2cc);
        for (; puVar7 != puVar1; puVar7 = puVar7 + 1) {
          *puVar7 = 0;
        }
      }
    }
  }
  FUN_00bbea60();
  if ((DAT_01d69070 != '\0') && (cStack_11 == '\0')) {
    iVar12 = 0;
    piStack_18 = (int *)(*(int *)(param_1 + 0x1b4) + 200);
    if (0 < *(int *)(*(int *)(param_1 + 0x1b4) + 0xcc)) {
      do {
        iStack_20 = *(int *)(*piStack_18 + iVar12 * 4);
        if ((*(int **)(iStack_20 + 0x1ac) == (int *)0x0) ||
           (iVar5 = (**(code **)(**(int **)(iStack_20 + 0x1ac) + 8))(), iVar5 != 10)) {
          iVar5 = 0;
          do {
            cVar3 = *(char *)(iStack_20 + 0x22f + iVar5);
            if ((cVar3 != '\0') && (cVar3 != '\n')) {
              uVar18 = 0;
              uVar17 = 0;
              uVar16 = 0;
              uVar10 = FUN_00b06640(iStack_20,0,0,0);
              FUN_00a97a80(uVar10,uVar16,uVar17,uVar18);
              break;
            }
            iVar5 = iVar5 + 1;
          } while (iVar5 < 6);
        }
        iVar12 = iVar12 + 1;
      } while (iVar12 < piStack_18[1]);
    }
  }
  if (*(char *)(param_1 + 0x1b8) != '\x01') {
    *(undefined *)(param_1 + 0x1b8) = 1;
    FUN_008a4940(&DAT_0211b120);
  }
  if (((DAT_01d62d2c != '\0') && (-1 < param_3)) && ((0 < param_3 || (param_2 != 0)))) {
    FUN_005bde90(auStack_68,&DAT_018bed48,param_2,param_3);
    iVar12 = *(int *)(*(int *)(param_1 + 0x1b4) + 0x6f8);
    if (0 < iVar12) {
      FUN_0087c450(&DAT_018c5f98,"AutoJoinJoinAll",auStack_68,iVar12,iVar12 >> 0x1f,0);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14732 ; VA 0x008b6390 ; FUN_008b6390 */

int FUN_008b6390(undefined4 param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  code *pcStack_3c;
  undefined1 *puStack_38;
  char *pcStack_34;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  uint uStack_28;
  undefined1 *puStack_24;
  char *pcStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bd830;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01d62d4c != '\0') {
    uStack_14 = uStack_14 & 0xffffff00;
    puStack_30 = &DAT_01d7a8e8;
    if (0xf < DAT_01d7a8fc) {
      puStack_30 = DAT_01d7a8e8;
    }
    uStack_28 = uStack_14;
    puStack_24 = &DAT_018c5f98;
    pcStack_20 = "UseWorkspaceJoinToOutsiders";
    uStack_18 = 0;
    pcStack_3c = FUN_0087c450;
    puStack_38 = &DAT_018c5f98;
    pcStack_34 = "UseWorkspaceJoinToOutsiders";
    uStack_2c = 0;
    ExceptionList = &pvStack_10;
    puStack_1c = puStack_30;
    FUN_008ab7d0(&DAT_01edfb9c,&pcStack_3c);
  }
  iVar3 = FUN_00a9e590();
  if (param_3 != 2) {
    puStack_1c = (undefined4 *)0x0;
    uStack_18 = 0;
    uStack_14 = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00f284a0(param_1,&puStack_1c);
    FUN_00f284f0(&puStack_1c,1);
    iVar3 = FUN_00777020();
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 14733 ; VA 0x008b64a0 ; FUN_008b64a0 */

void FUN_008b64a0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_008bbaf0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14734 ; VA 0x008b64e0 ; FUN_008b64e0 */

void FUN_008b64e0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_008bbb80();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14735 ; VA 0x008b6520 ; FUN_008b6520 */

void FUN_008b6520(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_008bbc30();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14736 ; VA 0x008b6560 ; FUN_008b6560 */

void FUN_008b6560(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_008bbce0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14737 ; VA 0x008b65a0 ; FUN_008b65a0 */

void FUN_008b65a0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_008bbd90();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14738 ; VA 0x008b65e0 ; FUN_008b65e0 */

void FUN_008b65e0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_009aa810(param_1,param_2,param_3);
  return;
}



/* FUNCTION 14739 ; VA 0x008b6620 ; FUN_008b6620 */

void FUN_008b6620(undefined4 param_1,undefined4 param_2)

{
  FUN_009aa870(param_1,param_2);
  return;
}



/* FUNCTION 14740 ; VA 0x008b6650 ; FUN_008b6650 */

void FUN_008b6650(undefined4 param_1,undefined4 param_2)

{
  FUN_009aa970(param_1,param_2);
  return;
}



/* FUNCTION 14741 ; VA 0x008b6680 ; FUN_008b6680 */

void __thiscall FUN_008b6680(int param_1,int param_2)

{
  if (((DAT_01d62dd4 != '\0') && (param_2 != *(int *)(param_1 + 0x31c))) && (DAT_01d62dac != '\0'))
  {
    *(int *)(param_1 + 0x31c) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 14742 ; VA 0x008b66c0 ; FUN_008b66c0 */

int FUN_008b66c0(undefined4 *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bd468;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_008ad160(*param_1,param_1[1],FUN_008ad4c0);
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 14743 ; VA 0x008b6730 ; FUN_008b6730 */

void FUN_008b6730(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1da5c04);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_1b25cfba96218b415fc39398ca0c464f>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 14744 ; VA 0x008b6790 ; FUN_008b6790 */

void FUN_008b6790(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1da5c3c);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_8b7ae93a0e2b7a7b12829747eb82507b>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 14745 ; VA 0x008b67f0 ; FUN_008b67f0 */

void FUN_008b67f0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1da5c74);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_9ba7076f2398d8279561e993d133bed9>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 14746 ; VA 0x008b6850 ; FUN_008b6850 */

void FUN_008b6850(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1da5cac);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_f4d0f7cbf9af5b2b6b4f5cd728d44be9>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 14747 ; VA 0x008b68b0 ; FUN_008b68b0 */

void FUN_008b68b0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar3 = param_1[1];
      iVar1 = param_1[2];
      iVar2 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar3;
      param_2[2] = iVar1;
      param_2[3] = iVar2;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1da5ac4);
      piVar4 = (int *)0x0;
      if (iVar3 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<int,class_boost::_mfi::cmf0<int,class_RBX::Kernel>,class_boost::_bi::list1<class_boost::_bi::value<class_RBX::Kernel_const*>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 14748 ; VA 0x008b6920 ; FUN_008b6920 */

void FUN_008b6920(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1da5ce4);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<int,class_boost::_mfi::cmf0<int,class_RBX::World>,class_boost::_bi::list1<class_boost::_bi::value<class_RBX::World_const*>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 14749 ; VA 0x008b6990 ; FUN_008b6990 */

void FUN_008b6990(undefined8 *param_1,int *param_2,int param_3)

{
  int iVar1;
  undefined8 *puVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *(undefined8 *)param_2 = *param_1;
      param_2[2] = *(int *)(param_1 + 1);
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1da5b44);
      puVar2 = (undefined8 *)0x0;
      if (iVar1 == 0) {
        puVar2 = param_1;
      }
      *param_2 = (int)puVar2;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<int,class_boost::_mfi::cmf1<int,class_RBX::World,enum_RBX::IWorldStage::MetricType>,class_boost::_bi::list2<class_boost::_bi::value<class_RBX::World_const*>,class_boost::_bi::value<enum_RBX::IWorldStage::MetricType>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}


