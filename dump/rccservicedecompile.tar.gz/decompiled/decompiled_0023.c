/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 5750 ; VA 0x005e584b ; Catch_All@005e584b */

void Catch_All_005e584b(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_005e9f40(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5751 ; VA 0x005e5880 ; FUN_005e5880 */

undefined FUN_005e5880(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 *param_8)

{
  char cVar1;
  undefined4 *puVar2;
  undefined uVar3;
  undefined4 *puStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 *apuStack_34 [2];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179b0a7;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  apuStack_34[0] = (undefined4 *)0x0;
  puStack_14 = param_1;
  ExceptionList = &pvStack_10;
  if (param_1 != (undefined4 *)0x0) {
    apuStack_34[0] = param_1;
    if (((uint)param_1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)((uint)param_1 & 0xfffffffe))(&param_3,&uStack_2c,0);
    }
    else {
      uStack_2c = param_3;
      uStack_28 = param_4;
      uStack_24 = param_5;
      uStack_20 = param_6;
      uStack_1c = param_7;
      ExceptionList = &pvStack_10;
    }
  }
  puStack_14 = param_1;
  uStack_8._0_1_ = 1;
  cVar1 = FUN_00585a40(apuStack_34);
  if (cVar1 == '\0') {
    puStack_54 = (undefined4 *)0x0;
    if (apuStack_34[0] != (undefined4 *)0x0) {
      puStack_54 = apuStack_34[0];
      if (((uint)apuStack_34[0] & 1) == 0) {
        (**(code **)((uint)apuStack_34[0] & 0xfffffffe))(&uStack_2c,&uStack_4c,0);
      }
      else {
        uStack_4c = uStack_2c;
        uStack_48 = uStack_28;
        uStack_44 = uStack_24;
        uStack_40 = uStack_20;
        uStack_3c = uStack_1c;
      }
    }
    uStack_8._0_1_ = 2;
    puVar2 = (undefined4 *)FUN_01674e20(0x20);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar2;
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = 0;
      if (puStack_54 != (undefined4 *)0x0) {
        *puVar2 = puStack_54;
        if (((uint)puStack_54 & 1) == 0) {
          (**(code **)((uint)puStack_54 & 0xfffffffe))(&uStack_4c,puVar2 + 2,0);
        }
        else {
          puVar2[2] = uStack_4c;
          puVar2[3] = uStack_48;
          puVar2[4] = uStack_44;
          puVar2[5] = uStack_40;
          *(undefined8 *)(puVar2 + 6) = uStack_3c;
        }
      }
    }
    *param_8 = puVar2;
    uStack_8._0_1_ = 4;
    if (((puStack_54 != (undefined4 *)0x0) && (((uint)puStack_54 & 1) == 0)) &&
       (*(code **)((uint)puStack_54 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)((uint)puStack_54 & 0xfffffffe))(&uStack_4c,&uStack_4c,2);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (apuStack_34[0] != (undefined4 *)0x0) {
      if ((((uint)apuStack_34[0] & 1) == 0) &&
         (*(code **)((uint)apuStack_34[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)((uint)apuStack_34[0] & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
      }
      apuStack_34[0] = (undefined4 *)0x0;
    }
    uVar3 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (apuStack_34[0] != (undefined4 *)0x0) {
      if ((((uint)apuStack_34[0] & 1) == 0) &&
         (*(code **)((uint)apuStack_34[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)((uint)apuStack_34[0] & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
        puStack_14 = param_1;
      }
      apuStack_34[0] = (undefined4 *)0x0;
    }
    uVar3 = 0;
    param_1 = puStack_14;
  }
  uStack_8 = 7;
  if (((param_1 != (undefined4 *)0x0) && (((uint)param_1 & 1) == 0)) &&
     (*(code **)((uint)param_1 & 0xfffffffe) != (code *)0x0)) {
    param_8._3_1_ = uVar3;
    (**(code **)((uint)param_1 & 0xfffffffe))(&param_3,&param_3,2);
    ExceptionList = pvStack_10;
    return param_8._3_1_;
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 5752 ; VA 0x005e5ab0 ; FUN_005e5ab0 */

undefined4 FUN_005e5ab0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b0cc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea93f0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ea93f0);
    if (DAT_01ea93f0 == -1) {
      uStack_8 = 0;
      DAT_01ea93ec = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ea93f0);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ea93ec;
}



/* FUNCTION 5753 ; VA 0x005e5b30 ; FUN_005e5b30 */

undefined4 FUN_005e5b30(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b0ec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea93e8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ea93e8);
    if (DAT_01ea93e8 == -1) {
      uStack_8 = 0;
      DAT_01ea93e4 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ea93e8);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ea93e4;
}



/* FUNCTION 5754 ; VA 0x005e5bb0 ; FUN_005e5bb0 */

int FUN_005e5bb0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 == 0) {
    return 0;
  }
  FUN_005789c0(&DAT_01ea93d4,&LAB_005e5aa0);
  uVar3 = FUN_005e5b30();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00a287f0();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return *piVar4;
}



/* FUNCTION 5755 ; VA 0x005e5c70 ; FUN_005e5c70 */

int FUN_005e5c70(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 == 0) {
    return 0;
  }
  FUN_005789c0(&DAT_01ea8a70,&LAB_0055d570);
  uVar3 = FUN_00560c40();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00961660();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return *piVar4;
}



/* FUNCTION 5756 ; VA 0x005e5d30 ; FUN_005e5d30 */

int * FUN_005e5d30(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ea93d4,&LAB_005e5aa0);
  uVar3 = FUN_005e5b30();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00a287f0();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 5757 ; VA 0x005e5de0 ; FUN_005e5de0 */

uint * FUN_005e5de0(uint *param_1,int param_2)

{
  int iVar1;
  bool bVar2;
  bool bVar3;
  bool bVar4;
  int *piVar5;
  undefined auStack_18 [4];
  int *piStack_14;
  uint uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if (param_2 == 0) {
    uStack_10 = 0;
    piStack_c = (int *)0x0;
    bVar4 = false;
    bVar3 = false;
    bVar2 = true;
  }
  else {
    piVar5 = (int *)FUN_005c9c10(auStack_18);
    piStack_c = (int *)piVar5[1];
    uStack_10 = -(uint)(*piVar5 != 0) & *piVar5 - 0xcU;
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[1] = piStack_c[1] + 1;
      UNLOCK();
      piStack_c = (int *)piVar5[1];
    }
    bVar4 = true;
    bVar3 = true;
    bVar2 = false;
  }
  piVar5 = piStack_c;
  *param_1 = 0;
  param_1[1] = 0;
  if (piStack_c != (int *)0x0) {
    LOCK();
    piStack_c[2] = piStack_c[2] + 1;
    UNLOCK();
  }
  *param_1 = uStack_10;
  param_1[1] = (uint)piStack_c;
  if ((bVar2) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar1 = piStack_c[1] + -1;
    piStack_c[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      iVar1 = piStack_c[2] + -1;
      piStack_c[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
  }
  if ((bVar3) && (piVar5 != (int *)0x0)) {
    LOCK();
    iVar1 = piVar5[1] + -1;
    piVar5[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar1 = piVar5[2] + -1;
      piVar5[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  if ((bVar4) && (piStack_14 != (int *)0x0)) {
    LOCK();
    iVar1 = piStack_14[1] + -1;
    piStack_14[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar5 = piStack_14 + 2;
      iVar1 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 5758 ; VA 0x005e5f00 ; FUN_005e5f00 */

uint * __thiscall FUN_005e5f00(uint *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  
  *param_1 = 0;
  uVar1 = *param_2;
  if (uVar1 != 0) {
    *param_1 = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar1 = param_2[3];
      uVar2 = param_2[4];
      uVar3 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar1;
      param_1[4] = uVar2;
      param_1[5] = uVar3;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
  }
  return param_1;
}



/* FUNCTION 5759 ; VA 0x005e5f60 ; FUN_005e5f60 */

uint * __thiscall FUN_005e5f60(uint *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b108;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uVar1 = *param_2;
  if (uVar1 != 0) {
    *param_1 = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
    }
    else {
      uVar1 = param_2[3];
      uVar2 = param_2[4];
      uVar3 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar1;
      param_1[4] = uVar2;
      param_1[5] = uVar3;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
    }
  }
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 8);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5760 ; VA 0x005e5ff0 ; FUN_005e5ff0 */

undefined4 * __fastcall FUN_005e5ff0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b136;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar1 = FUN_005e9aa0(0,0);
  param_1[1] = uVar1;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  uStack_8 = 1;
  *param_1 = 0x3f800000;
  FUN_005cb500(8);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5761 ; VA 0x005e6080 ; FUN_005e6080 */

void __fastcall FUN_005e6080(uint *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)param_1[0x11];
  ExceptionList = &pvStack_10;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[2] + -1;
    ExceptionList = &pvStack_10;
    piVar1[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  uVar2 = param_1[8];
  uStack_8 = 0;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 10,param_1 + 10,2);
      }
    }
    param_1[8] = 0;
  }
  uVar2 = *param_1;
  uStack_8 = 1;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 2,param_1 + 2,2);
      }
    }
    *param_1 = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5762 ; VA 0x005e6120 ; FUN_005e6120 */

void __fastcall FUN_005e6120(uint *param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = param_1[0xd];
  ExceptionList = &pvStack_10;
  if (0xf < uVar1) {
    uVar2 = param_1[8];
    uVar4 = uVar1 + 1;
    uVar3 = uVar2;
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(uVar2 - 4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (uVar2 - uVar3) - 4) {
        ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0(uVar3,uVar4);
  }
  param_1[0xc] = 0;
  param_1[0xd] = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  uVar1 = *param_1;
  uStack_8 = 0;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 2,param_1 + 2,2);
      }
    }
    *param_1 = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5763 ; VA 0x005e61c0 ; FUN_005e61c0 */

void __fastcall FUN_005e61c0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_005e6220();
  return;
}



/* FUNCTION 5764 ; VA 0x005e6220 ; FUN_005e6220 */

void __fastcall FUN_005e6220(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = (int *)*param_1;
  piVar3 = (int *)*piVar2;
  *piVar2 = (int)piVar2;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar2 = (int *)*param_1;
  if (piVar3 != piVar2) {
    do {
      piVar1 = (int *)*piVar3;
      FUN_01674ea0(piVar3,0x10);
      piVar2 = (int *)*param_1;
      piVar3 = piVar1;
    } while (piVar1 != piVar2);
  }
  FUN_01674ea0(piVar2,0x10);
  return;
}



/* FUNCTION 5765 ; VA 0x005e6270 ; FUN_005e6270 */

void __fastcall FUN_005e6270(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_005e6220();
  return;
}



/* FUNCTION 5766 ; VA 0x005e6280 ; FUN_005e6280 */

void __fastcall FUN_005e6280(int *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  iVar4 = *param_1;
  if (iVar4 != 0) {
    iVar5 = param_1[1];
    if (iVar4 != iVar5) {
      do {
        piVar1 = *(int **)(iVar4 + 4);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        iVar4 = iVar4 + 8;
      } while (iVar4 != iVar5);
      iVar4 = *param_1;
    }
    uVar3 = param_1[2] - iVar4 & 0xfffffff8;
    iVar5 = iVar4;
    if (0xfff < uVar3) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 5767 ; VA 0x005e6300 ; FUN_005e6300 */

undefined4 * __thiscall FUN_005e6300(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  piVar2 = (int *)*param_2;
  ExceptionList = &pvStack_10;
  if (piVar2 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  piVar3 = (int *)*param_1;
  *param_1 = piVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iStack_8 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    iStack_8 = iStack_8 + -1;
    if (iStack_8 == 0) {
      if ((code *)piVar3[3] != (code *)0x0) {
        (*(code *)piVar3[3])(piVar3);
      }
      FUN_0056c630();
      piVar2 = piVar3 + 1;
      LOCK();
      iVar1 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        FUN_01674ea0(piVar3);
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5768 ; VA 0x005e6390 ; FUN_005e6390 */

int __thiscall FUN_005e6390(uint *param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  ulonglong uVar4;
  int iVar5;
  uint uStack_c8;
  uint *puStack_c4;
  uint *puStack_c0;
  uint uStack_bc;
  ulonglong uStack_b8;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  undefined8 uStack_a0;
  undefined *puStack_98;
  undefined4 uStack_78;
  int *piStack_74;
  uint uStack_68;
  uint uStack_60;
  uint *puStack_5c;
  uint *puStack_58;
  uint uStack_54;
  ulonglong uStack_50;
  undefined auStack_48 [24];
  undefined auStack_30 [24];
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b168;
  pvStack_10 = ExceptionList;
  piStack_74 = &iStack_18;
  uStack_78 = 0x5e63bb;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00587490();
  uVar4 = uStack_b8;
  uStack_8 = 0;
  if (iStack_18 != 0) {
    if (param_2 == 0) {
      piStack_74 = (int *)0x1;
      puStack_98 = (undefined *)0x0;
      uStack_b8 = uStack_b8 & 0xffffffff00000000;
      uVar3 = *param_1;
      if (uVar3 != 0) {
        uStack_b8 = CONCAT44(SUB84(uVar4,4),uVar3);
        if ((uVar3 & 1) != 0) {
          uStack_b0 = param_1[2];
          uStack_ac = param_1[3];
          uStack_a8 = param_1[4];
          uStack_a4 = param_1[5];
          uStack_a0 = *(undefined8 *)(param_1 + 6);
          uStack_bc = 0x5e6412;
          FUN_005e4e10();
          puStack_98 = (undefined *)0x5e6419;
          iVar5 = FUN_0090ca30();
          goto LAB_005e6536;
        }
        puStack_c0 = &uStack_b0;
        uStack_bc = 0;
        puStack_c4 = param_1 + 2;
        uStack_c8 = 0x5e642f;
        (**(code **)(uVar3 & 0xfffffffe))();
      }
      uStack_bc = 0x5e643a;
      FUN_005e4e10();
      puStack_98 = (undefined *)0x5e6441;
      iVar5 = FUN_0090ca30();
    }
    else {
      piStack_74 = (int *)(param_3 + 0x10);
      uStack_78 = 0x5e6455;
      FUN_0054ef60();
      uVar3 = param_1[8];
      piStack_74 = (int *)0x1;
      uStack_8._0_1_ = 1;
      uStack_68 = 0;
      if (uVar3 != 0) {
        uStack_68 = uVar3;
        if ((uVar3 & 1) == 0) {
          puStack_98 = (undefined *)0x0;
          uStack_a0 = CONCAT44(&uStack_60,param_1 + 10);
          uStack_a4 = 0x5e64a2;
          (**(code **)(uVar3 & 0xfffffffe))();
        }
        else {
          uStack_60 = param_1[10];
          puStack_5c = (uint *)param_1[0xb];
          puStack_58 = (uint *)param_1[0xc];
          uStack_54 = param_1[0xd];
          uStack_50 = *(ulonglong *)(param_1 + 0xe);
        }
      }
      puStack_98 = auStack_30;
      uStack_8._0_1_ = 2;
      uStack_a0 = CONCAT44(0x5e64b5,(undefined4)uStack_a0);
      FUN_0054ef60();
      puStack_98 = (undefined *)0x0;
      uStack_8._0_1_ = 3;
      if (uStack_68 != 0) {
        if ((uStack_68 & 1) == 0) {
          (**(code **)(uStack_68 & 0xfffffffe))(&uStack_60,&uStack_c8,0);
        }
        else {
          uStack_c8 = uStack_60;
          puStack_c4 = puStack_5c;
          puStack_c0 = puStack_58;
          uStack_bc = uStack_54;
          uStack_b8 = uStack_50;
        }
      }
      uStack_8._0_1_ = 4;
      FUN_0054ef60(auStack_48);
      uStack_8._0_1_ = 3;
      FUN_005e4fc0();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      puStack_98 = (undefined *)0x5e6527;
      FUN_005e6120();
      puStack_98 = (undefined *)0x5e652e;
      FUN_0090ca30();
      piStack_74 = (int *)0x5e6536;
      iVar5 = FUN_005507b0();
    }
  }
LAB_005e6536:
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_74 = (int *)0x5e654f;
      iVar5 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_74 = (int *)0x5e655e;
        iVar5 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 5769 ; VA 0x005e6570 ; FUN_005e6570 */

int FUN_005e6570(byte *param_1)

{
  return ((((((((*param_1 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_1[1]) * 0x1000193 ^
              (uint)param_1[2]) * 0x1000193 ^ (uint)param_1[3]) * 0x1000193 ^ (uint)param_1[4]) *
            0x1000193 ^ (uint)param_1[5]) * 0x1000193 ^ (uint)param_1[6]) * 0x1000193 ^
         (uint)param_1[7]) * 0x1000193;
}



/* FUNCTION 5770 ; VA 0x005e65e0 ; FUN_005e65e0 */

/* WARNING: Removing unreachable block (ram,0x005e665b) */
/* WARNING: Removing unreachable block (ram,0x005e6669) */
/* WARNING: Removing unreachable block (ram,0x005e66a5) */
/* WARNING: Removing unreachable block (ram,0x005e6679) */

void __thiscall
FUN_005e65e0(uint *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179b190;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)((*param_1 & 0xfffffffe) + 4))
              (param_1 + 2,param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6));
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  FUN_0054fda0();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0();
}



/* FUNCTION 5771 ; VA 0x005e66b0 ; FUN_005e66b0 */

/* WARNING: Removing unreachable block (ram,0x005e670a) */
/* WARNING: Removing unreachable block (ram,0x005e671a) */
/* WARNING: Removing unreachable block (ram,0x005e6720) */

void __fastcall FUN_005e66b0(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b1b0;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8 = 2;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = 4;
    FUN_01675290(uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5772 ; VA 0x005e675c ; Catch@005e675c */

undefined * Catch_005e675c(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x20));
  return &DAT_005e676d;
}



/* FUNCTION 5773 ; VA 0x005e6780 ; FUN_005e6780 */

/* WARNING: Removing unreachable block (ram,0x005e67da) */
/* WARNING: Removing unreachable block (ram,0x005e67ea) */
/* WARNING: Removing unreachable block (ram,0x005e67f0) */

void __fastcall FUN_005e6780(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b1d0;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8 = 2;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = 4;
    FUN_01675290(uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5774 ; VA 0x005e6829 ; Catch@005e6829 */

undefined * Catch_005e6829(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x20));
  return &DAT_005e683a;
}



/* FUNCTION 5775 ; VA 0x005e6850 ; FUN_005e6850 */

undefined4 __thiscall FUN_005e6850(int param_1,char param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined uVar5;
  undefined3 uVar6;
  undefined3 uVar7;
  char cVar8;
  char *****pppppcVar9;
  undefined4 *****pppppuVar10;
  char *pcVar11;
  undefined **ppuVar12;
  int *piVar13;
  undefined4 *puVar14;
  int iVar15;
  undefined4 *puVar16;
  undefined4 uVar17;
  char *****pppppcVar18;
  undefined **ppuVar19;
  char ****ppppcVar20;
  char *pcVar21;
  uint uVar22;
  uint uVar23;
  uint uVar24;
  int *piVar25;
  undefined auStack_170 [56];
  undefined **ppuStack_138;
  int *piStack_134;
  uint *puStack_130;
  undefined ***pppuStack_114;
  undefined4 uStack_110;
  undefined4 ****ppppuStack_dc;
  undefined4 ***pppuStack_d8;
  undefined4 ***pppuStack_d4;
  undefined4 ***pppuStack_d0;
  undefined8 uStack_cc;
  char ****ppppcStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined8 uStack_b4;
  int iStack_a8;
  uint auStack_a4 [4];
  int iStack_94;
  uint uStack_90;
  uint auStack_8c [4];
  undefined4 uStack_7c;
  uint uStack_78;
  undefined auStack_74 [4];
  undefined *puStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  int *piStack_64;
  undefined4 uStack_60;
  undefined auStack_5c [24];
  int iStack_44;
  undefined auStack_40 [4];
  int *piStack_3c;
  int iStack_38;
  int *piStack_34;
  char ****ppppcStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  char cStack_15;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b492;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffe6c;
  piVar25 = (int *)(-(uint)(param_1 != 0) & param_1 + 0xcU);
  ExceptionList = &pvStack_10;
  iStack_a8 = param_1;
  piStack_3c = piVar25;
  iStack_38 = FUN_005e5c70(piVar25);
  if (DAT_01d59a78 != '\0') {
    uStack_20 = 0xf00000000;
    ppppcStack_30 = (char ****)((uint)ppppcStack_30 & 0xffffff00);
    FUN_005542c0("TeamCreate.Publish.Attempt",0x1a);
    uStack_8 = 0;
    FUN_008783f0(&ppppcStack_30,1,0);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_20._4_4_) {
      uVar22 = uStack_20._4_4_ + 1;
      pppppcVar9 = (char *****)ppppcStack_30;
      if (0xfff < uVar22) {
        pppppcVar9 = (char *****)ppppcStack_30[-1];
        uVar22 = uStack_20._4_4_ + 0x24;
        if (0x1f < (uint)((int)ppppcStack_30 + (-4 - (int)pppppcVar9))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppcVar9,uVar22);
    }
  }
  uStack_b4 = 0xf00000000;
  ppppcStack_c4 = (char ****)((uint)ppppcStack_c4 & 0xffffff00);
  uStack_8._1_3_ = 0;
  uVar6 = uStack_8._1_3_;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  uVar7 = uVar6;
  if ((iStack_38 != 0) && (uVar7 = uStack_8._1_3_, param_2 != '\0')) {
    if (DAT_01d65cf0 == '\0') {
      uStack_8._1_3_ = uVar6;
      cVar8 = FUN_00a161b0(param_1);
      uVar7 = uStack_8._1_3_;
      if (cVar8 != '\0') {
        uStack_20 = 0xf00000000;
        ppppcStack_30 = (char ****)((uint)ppppcStack_30 & 0xffffff00);
        FUN_005542c0("Error: Cannot publish place to Roblox while there are packages with unpublished changes."
                     ,0x58);
        uStack_8._0_1_ = 5;
        FUN_0098c2c0(3,&ppppcStack_30);
        uStack_8._0_1_ = 2;
        FUN_005507b0();
        uStack_20 = 0xf00000000;
        ppppcStack_30 = (char ****)((uint)ppppcStack_30 & 0xffffff00);
        FUN_005542c0("CloudEditAbortPublishDueToUnpublishedPackage",0x2c);
        uStack_8._0_1_ = 6;
        FUN_008783f0(&ppppcStack_30,1,0);
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_005507b0();
        FUN_0087c450("Studio","PlacePublishBlockedByPackage","PublishBlockedByUnverifiedPackage",0,0
                     ,0);
LAB_005e6a0c:
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return 0;
      }
    }
    else {
      cVar8 = FUN_00a16240();
      uVar7 = uStack_8._1_3_;
      if ((cVar8 != '\0') &&
         (iStack_44 = FUN_005e5bb0(piVar25), uVar7 = uStack_8._1_3_, iStack_44 != 0)) {
        FUN_00a15e60(&uStack_68,param_1);
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        cStack_15 = FUN_00a155c0(iStack_44,&uStack_68,1);
        piStack_34 = (int *)CONCAT31(piStack_34._1_3_,cStack_15);
        if (DAT_01d65cf8 != '\0') {
          FUN_00a19180(iStack_44,piStack_34,&uStack_68);
        }
        if (cStack_15 != '\0') {
          uStack_20 = 0xf00000000;
          ppppcStack_30 = (char ****)((uint)ppppcStack_30 & 0xffffff00);
          FUN_005542c0("Error: There are one or more packages preventing this place from being published. Please try again."
                       ,99);
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          FUN_0098c2c0(3,&ppppcStack_30);
          FUN_005507b0();
          FUN_005e6280();
          goto LAB_005e6a0c;
        }
        uStack_8._0_1_ = 2;
        FUN_005e6280();
        uVar7 = uStack_8._1_3_;
      }
    }
  }
  uStack_8._1_3_ = uVar7;
  if ((((DAT_01d65cf0 == '\0') && (iStack_38 != 0)) && (param_2 != '\0')) &&
     (cVar8 = FUN_00a16240(param_1), cVar8 != '\0')) {
    FUN_0087c450("Studio","PlacePublishBlockedByPackage",
                 "PublishWasNotBlockedByPendingOrModifiedPackages",0,0,0);
  }
  piVar13 = *(int **)(param_1 + 0x43c);
  FUN_00a19ae0(*piVar13 - (int)piVar13,piVar13[1] - (int)piVar13,param_1);
  FUN_00a24b20(&ppppcStack_c4,piVar25,0,0);
  uStack_110 = (int)uStack_b4;
  uStack_cc = 0xf00000000;
  ppppuStack_dc = (undefined4 ****)((uint)ppppuStack_dc & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (((DAT_01ea937d != '\0') || (DAT_01d64710 != '\0')) || (DAT_01ea937e != '\0')) {
    pppppcVar9 = &ppppcStack_c4;
    if (0xf < uStack_b4._4_4_) {
      pppppcVar9 = (char *****)ppppcStack_c4;
    }
    pppppuVar10 = (undefined4 *****)FUN_01531190(auStack_8c,pppppcVar9,(int)uStack_b4);
    if (&ppppuStack_dc != pppppuVar10) {
      FUN_005507b0();
      ppppuStack_dc = *pppppuVar10;
      pppuStack_d8 = pppppuVar10[1];
      pppuStack_d4 = pppppuVar10[2];
      pppuStack_d0 = pppppuVar10[3];
      uStack_cc = *(undefined8 *)(pppppuVar10 + 4);
      pppppuVar10[4] = (undefined4 ****)0x0;
      pppppuVar10[5] = (undefined4 ****)0xf;
      *(undefined *)pppppuVar10 = 0;
    }
    if (0xf < uStack_78) {
      uVar23 = uStack_78 + 1;
      uVar22 = auStack_8c[0];
      if (0xfff < uVar23) {
        uVar22 = *(uint *)(auStack_8c[0] - 4);
        uVar23 = uStack_78 + 0x24;
        if (0x1f < (auStack_8c[0] - uVar22) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar22,uVar23);
    }
  }
  if (DAT_01ea937c != '\0') {
    pppppcVar9 = &ppppcStack_c4;
    if (0xf < uStack_b4._4_4_) {
      pppppcVar9 = (char *****)ppppcStack_c4;
    }
    pppppcVar18 = &ppppcStack_c4;
    if (0xf < uStack_b4._4_4_) {
      pppppcVar18 = (char *****)ppppcStack_c4;
    }
    uVar22 = 0;
    piStack_34 = (int *)(((int)pppppcVar9 + (int)uStack_b4) - (int)pppppcVar18);
    iStack_44 = 0;
    if ((char *****)((int)pppppcVar9 + (int)uStack_b4) < pppppcVar18) {
      piStack_34 = (int *)0x0;
    }
    if (piStack_34 != (int *)0x0) {
      do {
        cVar8 = *(char *)pppppcVar18;
        pppppcVar18 = (char *****)((int)pppppcVar18 + 1);
        uVar22 = uVar22 ^ (uVar22 >> 2) + 0x9e3779b9 + uVar22 * 0x40 + (int)cVar8;
        iStack_44 = iStack_44 + 1;
      } while ((int *)iStack_44 != piStack_34);
    }
    FUN_016774b0(DAT_01ea937c,"Saving place with hash: %lu",uVar22);
    piVar25 = piStack_3c;
  }
  if (DAT_01ea937d != '\0') {
    pcVar11 = "Publishing";
    pppppuVar10 = &ppppuStack_dc;
    if (0xf < uStack_cc._4_4_) {
      pppppuVar10 = (undefined4 *****)ppppuStack_dc;
    }
    puVar14 = &DAT_01d79c80;
    if (0xf < DAT_01d79c94) {
      puVar14 = DAT_01d79c80;
    }
    if (param_2 == '\0') {
      pcVar11 = "Saving";
    }
    FUN_01677520(DAT_01ea937d,"%s place (placeID = %s) with hash: %s",pcVar11,puVar14,pppppuVar10);
  }
  if (DAT_01d64710 != '\0') {
    auStack_74[0] = 0;
    piStack_3c = (int *)0xb;
    ppuVar12 = (undefined **)
               FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&piStack_3c);
    ppuVar19 = ppuVar12 + -1;
    if (ppuVar12 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar19 = ppuVar12;
    }
    puStack_70 = *ppuVar19;
    uStack_6c = 0;
    uStack_68 = 0x3f800000;
    piStack_64 = (int *)0x0;
    uStack_60 = 0;
    uStack_8._0_1_ = 8;
    piVar13 = (int *)FUN_0152fd20(auStack_8c);
    uStack_8._0_1_ = 9;
    iStack_94 = 0;
    uStack_90 = 0xf;
    auStack_a4[0] = auStack_a4[0] & 0xffffff00;
    FUN_005542c0("device",6);
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    piStack_3c = (int *)FUN_005d15d0(auStack_a4);
    if (piStack_3c + 6 != piVar13) {
      FUN_005507b0();
      iVar15 = piVar13[1];
      iVar1 = piVar13[2];
      iVar2 = piVar13[3];
      piStack_3c[6] = *piVar13;
      piStack_3c[7] = iVar15;
      piStack_3c[8] = iVar1;
      piStack_3c[9] = iVar2;
      *(undefined8 *)(piStack_3c + 10) = *(undefined8 *)(piVar13 + 4);
      piVar13[4] = 0;
      piVar13[5] = 0xf;
      *(undefined *)piVar13 = 0;
    }
    uStack_8._0_1_ = 9;
    if (0xf < uStack_90) {
      uVar23 = uStack_90 + 1;
      uVar22 = auStack_a4[0];
      if (0xfff < uVar23) {
        uVar22 = *(uint *)(auStack_a4[0] - 4);
        uVar23 = uStack_90 + 0x24;
        if (0x1f < (auStack_a4[0] - uVar22) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar22,uVar23);
    }
    iStack_94 = 0;
    uStack_90 = 0xf;
    auStack_a4[0] = auStack_a4[0] & 0xffffff00;
    uStack_8._0_1_ = 8;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (0xf < uStack_78) {
      uVar23 = uStack_78 + 1;
      uVar22 = auStack_8c[0];
      if (0xfff < uVar23) {
        uVar22 = *(uint *)(auStack_8c[0] - 4);
        uVar23 = uStack_78 + 0x24;
        if (0x1f < (auStack_8c[0] - uVar22) - 4) {
          uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar22,uVar23);
    }
    uStack_20 = 0xf00000000;
    ppppcStack_30 = (char ****)((uint)ppppcStack_30 & 0xffffff00);
    FUN_005542c0("RobloxPlaceIdHeader",0x13);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    puVar14 = (undefined4 *)FUN_005d15d0(&ppppcStack_30);
    if ((undefined4 **)puVar14 != &DAT_01d79c68) {
      puVar14 = &DAT_01d79c80;
      if (0xf < DAT_01d79c94) {
        puVar14 = DAT_01d79c80;
      }
      FUN_005542c0(puVar14,DAT_01d79c90);
    }
    uStack_8._0_1_ = 8;
    if (0xf < uStack_20._4_4_) {
      uVar22 = uStack_20._4_4_ + 1;
      ppppcVar20 = ppppcStack_30;
      if (0xfff < uVar22) {
        ppppcVar20 = (char ****)ppppcStack_30[-1];
        uVar22 = uStack_20._4_4_ + 0x24;
        if (0x1f < (uint)((int)ppppcStack_30 + (-4 - (int)ppppcVar20))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppcVar20,uVar22);
    }
    uStack_20 = 0xf00000000;
    ppppcStack_30 = (char ****)((uint)ppppcStack_30 & 0xffffff00);
    FUN_005542c0("RobloxGameIdHeader",0x12);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    puVar14 = (undefined4 *)FUN_005d15d0(&ppppcStack_30);
    if (puVar14 != &DAT_01d79c50) {
      puVar14 = &DAT_01d79c68;
      if (0xf < DAT_01d79c7c) {
        puVar14 = DAT_01d79c68;
      }
      FUN_005542c0(puVar14,DAT_01d79c78);
    }
    uStack_8._0_1_ = 8;
    if (0xf < uStack_20._4_4_) {
      uVar22 = uStack_20._4_4_ + 1;
      ppppcVar20 = ppppcStack_30;
      if (0xfff < uVar22) {
        ppppcVar20 = (char ****)ppppcStack_30[-1];
        uVar22 = uStack_20._4_4_ + 0x24;
        if (0x1f < (uint)((int)ppppcStack_30 + (-4 - (int)ppppcVar20))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppcVar20,uVar22);
    }
    uStack_20 = 0xf00000000;
    uVar22 = 4;
    if ((uint)uStack_cc < 4) {
      uVar22 = (uint)uStack_cc;
    }
    pppppuVar10 = &ppppuStack_dc;
    if (0xf < uStack_cc._4_4_) {
      pppppuVar10 = (undefined4 *****)ppppuStack_dc;
    }
    ppppcStack_30 = (char ****)((uint)ppppcStack_30 & 0xffffff00);
    FUN_005542c0(pppppuVar10,uVar22);
    uStack_8._0_1_ = 0xd;
    iStack_94 = 0;
    uStack_90 = 0xf;
    auStack_a4[0] = auStack_a4[0] & 0xffffff00;
    FUN_005542c0("md5FirstSixteenBits",0x13);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
    iVar15 = FUN_005d15d0(auStack_a4);
    if ((char *****)(iVar15 + 0x18) == &ppppcStack_30) {
      uVar22 = uStack_20._4_4_;
    }
    else {
      FUN_005507b0();
      ppppcVar20 = ppppcStack_30;
      ppppcStack_30 = (char ****)((uint)ppppcStack_30 & 0xffffff00);
      *(char *****)(iVar15 + 0x18) = ppppcVar20;
      *(undefined4 *)(iVar15 + 0x1c) = uStack_2c;
      *(undefined4 *)(iVar15 + 0x20) = uStack_28;
      *(undefined4 *)(iVar15 + 0x24) = uStack_24;
      *(undefined8 *)(iVar15 + 0x28) = uStack_20;
      uVar22 = 0xf;
    }
    uStack_8._0_1_ = 0xd;
    if (0xf < uStack_90) {
      uVar24 = uStack_90 + 1;
      uVar23 = auStack_a4[0];
      if (0xfff < uVar24) {
        uVar23 = *(uint *)(auStack_a4[0] - 4);
        uVar24 = uStack_90 + 0x24;
        if (0x1f < (auStack_a4[0] - uVar23) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar23,uVar24);
    }
    iStack_94 = 0;
    uStack_90 = 0xf;
    auStack_a4[0] = auStack_a4[0] & 0xffffff00;
    uStack_8._0_1_ = 8;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (0xf < uVar22) {
      uVar23 = uVar22 + 1;
      ppppcVar20 = ppppcStack_30;
      if (0xfff < uVar23) {
        ppppcVar20 = (char ****)ppppcStack_30[-1];
        uVar23 = uVar22 + 0x24;
        if (0x1f < (uint)((int)ppppcStack_30 + (-4 - (int)ppppcVar20))) {
          uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppcVar20,uVar23);
    }
    piVar13 = (int *)FUN_009ee570(auStack_8c,&param_2);
    uStack_8._0_1_ = 0xf;
    uStack_20 = 0xf00000000;
    ppppcStack_30 = (char ****)((uint)ppppcStack_30 & 0xffffff00);
    FUN_005542c0("isPublish",9);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
    piStack_3c = (int *)FUN_005d15d0(&ppppcStack_30);
    if (piStack_3c + 6 != piVar13) {
      FUN_005507b0();
      iVar15 = piVar13[1];
      iVar1 = piVar13[2];
      iVar2 = piVar13[3];
      piStack_3c[6] = *piVar13;
      piStack_3c[7] = iVar15;
      piStack_3c[8] = iVar1;
      piStack_3c[9] = iVar2;
      *(undefined8 *)(piStack_3c + 10) = *(undefined8 *)(piVar13 + 4);
      piVar13[4] = 0;
      piVar13[5] = 0xf;
      *(undefined *)piVar13 = 0;
    }
    uStack_8._0_1_ = 0xf;
    if (0xf < uStack_20._4_4_) {
      uVar22 = uStack_20._4_4_ + 1;
      ppppcVar20 = ppppcStack_30;
      if (0xfff < uVar22) {
        ppppcVar20 = (char ****)ppppcStack_30[-1];
        uVar22 = uStack_20._4_4_ + 0x24;
        if (0x1f < (uint)((int)ppppcStack_30 + (-4 - (int)ppppcVar20))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppcVar20,uVar22);
    }
    uStack_20 = 0xf00000000;
    ppppcStack_30 = (char ****)((uint)ppppcStack_30 & 0xffffff00);
    uStack_8._0_1_ = 8;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (0xf < uStack_78) {
      uVar23 = uStack_78 + 1;
      uVar22 = auStack_8c[0];
      if (0xfff < uVar23) {
        uVar22 = *(uint *)(auStack_8c[0] - 4);
        uVar23 = uStack_78 + 0x24;
        if (0x1f < (auStack_8c[0] - uVar22) - 4) {
          uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar22,uVar23);
    }
    piVar13 = (int *)FUN_01675640(auStack_8c,&DAT_018bed48,param_3,param_4);
    uStack_8._0_1_ = 0x11;
    uStack_20 = 0xf00000000;
    ppppcStack_30 = (char ****)((uint)ppppcStack_30 & 0xffffff00);
    FUN_005542c0("userid",6);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
    piStack_3c = (int *)FUN_005d15d0(&ppppcStack_30);
    if (piStack_3c + 6 != piVar13) {
      FUN_005507b0();
      iVar15 = piVar13[1];
      iVar1 = piVar13[2];
      iVar2 = piVar13[3];
      piStack_3c[6] = *piVar13;
      piStack_3c[7] = iVar15;
      piStack_3c[8] = iVar1;
      piStack_3c[9] = iVar2;
      *(undefined8 *)(piStack_3c + 10) = *(undefined8 *)(piVar13 + 4);
      piVar13[4] = 0;
      piVar13[5] = 0xf;
      *(undefined *)piVar13 = 0;
    }
    uStack_8._0_1_ = 0x11;
    if (0xf < uStack_20._4_4_) {
      uVar22 = uStack_20._4_4_ + 1;
      ppppcVar20 = ppppcStack_30;
      if (0xfff < uVar22) {
        ppppcVar20 = (char ****)ppppcStack_30[-1];
        uVar22 = uStack_20._4_4_ + 0x24;
        if (0x1f < (uint)((int)ppppcStack_30 + (-4 - (int)ppppcVar20))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppcVar20,uVar22);
    }
    uStack_20 = 0xf00000000;
    ppppcStack_30 = (char ****)((uint)ppppcStack_30 & 0xffffff00);
    uStack_8._0_1_ = 8;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (0xf < uStack_78) {
      uVar23 = uStack_78 + 1;
      uVar22 = auStack_8c[0];
      if (0xfff < uVar23) {
        uVar22 = *(uint *)(auStack_8c[0] - 4);
        uVar23 = uStack_78 + 0x24;
        if (0x1f < (auStack_8c[0] - uVar22) - 4) {
          uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar22,uVar23);
    }
    uStack_7c = 0;
    uStack_78 = 0xf;
    auStack_8c[0] = auStack_8c[0] & 0xffffff00;
    FUN_005542c0("SaveOrPublish",0xd);
    uStack_8._0_1_ = 0x13;
    iStack_94 = 0;
    uStack_90 = 0xf;
    auStack_a4[0] = auStack_a4[0] & 0xffffff00;
    FUN_005542c0("TeamCreate",10);
    uStack_8._0_1_ = 0x14;
    uStack_20 = 0xf00000000;
    ppppcStack_30 = (char ****)((uint)ppppcStack_30 & 0xffffff00);
    FUN_005542c0(&DAT_018bde9c,3);
    uStack_8._0_1_ = 0x15;
    FUN_00879580(&ppppcStack_30,auStack_a4,auStack_8c,auStack_74);
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_0056cfd0();
  }
  if (DAT_01ea937e != '\0') {
    uVar22 = 4;
    if ((uint)uStack_cc < 4) {
      uVar22 = (uint)uStack_cc;
    }
    pppppuVar10 = &ppppuStack_dc;
    if (0xf < uStack_cc._4_4_) {
      pppppuVar10 = (undefined4 *****)ppppuStack_dc;
    }
    uStack_20 = 0xf00000000;
    ppppcStack_30 = (char ****)((uint)ppppcStack_30 & 0xffffff00);
    FUN_005542c0(pppppuVar10,uVar22);
    pppppcVar9 = &ppppcStack_30;
    if (0xf < uStack_20._4_4_) {
      pppppcVar9 = (char *****)ppppcStack_30;
    }
    puVar14 = &DAT_01d79c68;
    if (0xf < DAT_01d79c7c) {
      puVar14 = DAT_01d79c68;
    }
    puVar16 = &DAT_01d79c80;
    if (0xf < DAT_01d79c94) {
      puVar16 = DAT_01d79c80;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
    FUN_01677520(DAT_01ea937e,
                 "TeamCreate SaveOrPublish Roblox-Place-Id: [%s] Roblox-Game-Id: [%s] isPublish: [%d] first 16 bits of md5: [%s]"
                 ,puVar16,puVar14,param_2,pppppcVar9);
    FUN_005507b0();
  }
  FUN_005507b0();
  uStack_8._0_1_ = 0x2c;
  uStack_8._1_3_ = 0;
  FUN_014c9d60(&piStack_64,0);
  puVar14 = (undefined4 *)(iStack_a8 + 0x424);
  uStack_8._0_1_ = 0x2d;
  if (0xf < *(uint *)(iStack_a8 + 0x438)) {
    puVar14 = (undefined4 *)*puVar14;
  }
  FUN_014cbbc0(puVar14,*(undefined4 *)(iStack_a8 + 0x434));
  piStack_64[0x2c] = 0;
  FUN_014cb780(&ppppcStack_c4,1);
  piStack_34 = piStack_64;
  if (PTR_DAT_01d79bfc == (undefined *)0x0) {
    iVar15 = 0;
  }
  else {
    piStack_3c = (int *)(PTR_DAT_01d79bfc + 1);
    pcVar11 = PTR_DAT_01d79bfc;
    do {
      cVar8 = *pcVar11;
      pcVar11 = pcVar11 + 1;
    } while (cVar8 != '\0');
    iVar15 = (int)pcVar11 - (int)piStack_3c;
  }
  puVar14 = &DAT_01d79d70;
  if (0xf < DAT_01d79d84) {
    puVar14 = DAT_01d79d70;
  }
  FUN_014cb8a0(puVar14,DAT_01d79d80,PTR_DAT_01d79bfc,iVar15);
  pcVar11 = "False";
  piStack_34 = piStack_64;
  if (param_2 == '\0') {
    pcVar11 = "True";
  }
  piStack_3c = (int *)(pcVar11 + 1);
  pcVar21 = pcVar11;
  do {
    cVar8 = *pcVar21;
    pcVar21 = pcVar21 + 1;
  } while (cVar8 != '\0');
  puVar14 = &DAT_01d79ed8;
  if (0xf < DAT_01d79eec) {
    puVar14 = DAT_01d79ed8;
  }
  FUN_014cb8a0(puVar14,DAT_01d79ee8,pcVar11,(int)pcVar21 - (int)piStack_3c);
  iVar15 = iStack_38;
  if (DAT_01d64710 != '\0') {
    piStack_3c = piStack_64;
    puVar16 = (undefined4 *)FUN_01675640(auStack_5c,&DAT_018bed48,param_3,param_4);
    puVar14 = puVar16 + 4;
    uStack_8._0_1_ = 0x2e;
    if (0xf < (uint)puVar16[5]) {
      puVar16 = (undefined4 *)*puVar16;
    }
    FUN_014cb8a0("X-Roblox-Author-ID",0x12,puVar16,*puVar14);
    uStack_8._0_1_ = 0x2d;
    FUN_005507b0();
    iVar15 = iStack_38;
    piStack_3c = piStack_64;
    puVar16 = (undefined4 *)FUN_005ea020(auStack_5c,iStack_38);
    puVar14 = puVar16 + 4;
    uStack_8._0_1_ = 0x2f;
    if (0xf < (uint)puVar16[5]) {
      puVar16 = (undefined4 *)*puVar16;
    }
    FUN_014cb8a0("X-Roblox-Players-Log",0x14,puVar16,*puVar14);
    uStack_8._0_1_ = 0x2d;
    FUN_005507b0();
  }
  uVar4 = uStack_24;
  uVar3 = uStack_28;
  uVar17 = uStack_2c;
  ppppcStack_30 = (char ****)((uint)ppppcStack_30 & 0xffffff00);
  ppppcVar20 = ppppcStack_30;
  ppppcStack_30 = ppppcStack_c4;
  uStack_2c = uStack_c0;
  uStack_28 = uStack_bc;
  uStack_24 = uStack_b8;
  uStack_20 = uStack_b4;
  ppppcStack_c4 = ppppcVar20;
  uStack_c0 = uVar17;
  uStack_bc = uVar3;
  uStack_b8 = uVar4;
  uStack_b4 = 0xf00000000;
  FUN_005507b0();
  FUN_0151f360(1);
  iStack_94 = 0;
  uStack_90 = 0xf;
  auStack_a4[0] = auStack_a4[0] & 0xffffff00;
  uStack_8._0_1_ = 0x31;
  FUN_014cba60();
  piStack_134 = &iStack_44;
  ppuStack_138 = std::
                 _Func_impl_no_alloc<class_<lambda_409bc24c56ce02a163c697b3de501aed>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
                 ::vftable;
  puStack_130 = auStack_a4;
  pppuStack_114 = &ppuStack_138;
  uStack_8._0_1_ = 0x32;
  FUN_014cb530(pppuStack_114);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x31);
  if (pppuStack_114 != (undefined ***)0x0) {
    (*(code *)(*pppuStack_114)[4])
              (CONCAT31((int3)((uint)&ppuStack_138 >> 8),pppuStack_114 != &ppuStack_138));
  }
  FUN_0151f430();
  if (iStack_94 != 0) {
    FUN_005500e0(auStack_a4);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_170,&DAT_01c17198);
  }
  if ((param_2 != '\0') && (piVar25 != (int *)0x0)) {
    FUN_005789c0(&DAT_01ea93dc,&LAB_005e5a90);
    uVar17 = FUN_005e5ab0();
    piStack_34 = (int *)FUN_008aa140(uVar17);
    if (*piStack_34 == 0) {
      uVar17 = FUN_00a1a140();
      uVar17 = FUN_008a9ba0(auStack_40,uVar17);
      FUN_005587e0(uVar17);
      piVar25 = piStack_3c;
      if (piStack_3c != (int *)0x0) {
        LOCK();
        iVar1 = piStack_3c[1] + -1;
        piStack_3c[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_3c)();
          LOCK();
          piVar13 = piVar25 + 2;
          iVar1 = *piVar13 + -1;
          *piVar13 = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar25 + 4))();
          }
        }
      }
    }
    if (*piStack_34 != 0) {
      FUN_00a1b330(param_3,param_4);
    }
  }
  if (iVar15 != 0) {
    uStack_7c = 0;
    uStack_78 = 0xf;
    auStack_8c[0] = auStack_8c[0] & 0xffffff00;
    FUN_005542c0("Save Level Complete",0x13);
    uStack_8._0_1_ = 0x33;
    FUN_0097c9e0(auStack_8c);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x31);
    FUN_005507b0();
    if (DAT_01d64710 != '\0') {
      FUN_005ea7b0();
    }
  }
  FUN_005507b0();
  FUN_0151f390();
  FUN_00550b30();
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 5776 ; VA 0x005e789e ; Catch@005e789e */

undefined * Catch_005e789e(void)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int unaff_EBP;
  int *piVar6;
  undefined4 *puVar7;
  
  if (*(int *)(unaff_EBP + -0xa4) == 0) {
    iVar2 = 0;
  }
  else {
    iVar2 = *(int *)(unaff_EBP + -0xa4) + 0xc;
  }
  cVar1 = FUN_00983210(iVar2);
  if (cVar1 != '\0') {
    *(undefined4 *)(unaff_EBP + -0x60) = 0;
    *(undefined4 *)(unaff_EBP + -0x5c) = 0xf;
    *(undefined *)(unaff_EBP + -0x70) = 0;
    piVar6 = *(int **)(unaff_EBP + -0xa8);
    *(undefined *)(unaff_EBP + -4) = 0x35;
    if (*(char *)(unaff_EBP + 8) == '\0') {
      uVar3 = (**(code **)(*piVar6 + 4))();
      uVar4 = FUN_0054eff0("Server Save Failure: ");
      *(undefined *)(unaff_EBP + -4) = 0x37;
    }
    else {
      uVar3 = (**(code **)(*piVar6 + 4))();
      uVar4 = FUN_0054eff0("Server Publish Failure: ");
      *(undefined *)(unaff_EBP + -4) = 0x36;
    }
    uVar3 = FUN_00558c80(unaff_EBP + -0x58,uVar4,uVar3);
    FUN_005511f0(uVar3);
    FUN_005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x35;
    FUN_005507b0();
    iVar2 = FUN_0170d75d(piVar6,0,&std::runtime_error::RTTI_Type_Descriptor,
                         &RBX::http_status_error::RTTI_Type_Descriptor,0);
    if (iVar2 != 0) {
      FUN_0151f6f0(0xffffffff,0,0);
      *(undefined *)(unaff_EBP + -4) = 0x38;
      uVar3 = FUN_005543f0();
      FUN_0151f850(&DAT_018c8720,uVar3);
      uVar3 = (**(code **)(*piVar6 + 4))();
      FUN_0151f850("ExceptionStr",uVar3);
      FUN_0151f9c0("HTTPErrorCode",*(undefined4 *)(iVar2 + 0x24));
      uVar3 = FUN_005543f0();
      FUN_0151f850(&DAT_018c3bf4,uVar3);
      FUN_0151f9c0("PostDataSize",*(undefined4 *)(unaff_EBP + -0x10c));
      uVar3 = DAT_01d598c8;
      FUN_0054eff0("TeamCreateServerPublishFailure");
      *(undefined *)(unaff_EBP + -4) = 0x39;
      FUN_01520d20(unaff_EBP + -0x88,uVar3,0);
      FUN_005507b0();
      *(undefined *)(unaff_EBP + -4) = 0x35;
      FUN_0151f7f0();
    }
    if (*(int *)(unaff_EBP + -0x34) != 0) {
      FUN_0098c2c0(3,unaff_EBP + -0x70);
    }
    if (DAT_01d59a70 != '\0') {
      uVar3 = FUN_0054eff0(" url: ");
      *(undefined *)(unaff_EBP + -4) = 0x3a;
      uVar4 = (**(code **)(**(int **)(unaff_EBP + -0xa8) + 4))();
      uVar5 = FUN_0054eff0("ServerSaveFailure ");
      *(undefined *)(unaff_EBP + -4) = 0x3b;
      uVar4 = FUN_00558c80(unaff_EBP + -0x108,uVar5,uVar4);
      *(undefined *)(unaff_EBP + -4) = 0x3c;
      uVar3 = FUN_00558ba0(unaff_EBP + -0xf0,uVar4,uVar3);
      *(undefined *)(unaff_EBP + -4) = 0x3d;
      uVar3 = FUN_00558c20(unaff_EBP + -0x58,uVar3,*(int *)(unaff_EBP + -0xa4) + 0x424);
      FUN_005511f0(uVar3);
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      *(undefined *)(unaff_EBP + -4) = 0x35;
      FUN_005507b0();
      iVar2 = unaff_EBP + -0x70;
      if (0xf < *(uint *)(unaff_EBP + -0x5c)) {
        iVar2 = *(int *)(unaff_EBP + -0x70);
      }
      FUN_0087c6f0(&DAT_018c5f98,"Team Create",iVar2,0,0,0,3);
      piVar6 = *(int **)(unaff_EBP + -0xa8);
    }
    if (DAT_01d64710 != '\0') {
      FUN_005d0b40(0xb,unaff_EBP + -0x11,unaff_EBP + -0x11,unaff_EBP + -0x11);
      *(undefined *)(unaff_EBP + -4) = 0x3e;
      uVar3 = FUN_0152fd20(unaff_EBP + -0x184);
      *(undefined *)(unaff_EBP + -4) = 0x3f;
      FUN_0054eff0("device");
      *(undefined *)(unaff_EBP + -4) = 0x40;
      FUN_005d15d0(unaff_EBP + -0x88);
      FUN_005511f0(uVar3);
      FUN_005507b0();
      *(undefined *)(unaff_EBP + -4) = 0x3e;
      FUN_005507b0();
      FUN_0054eff0("RobloxPlaceIdHeader");
      puVar7 = &DAT_01d79c80;
      *(undefined *)(unaff_EBP + -4) = 0x41;
      FUN_005d15d0(unaff_EBP + -0xa0);
      FUN_00551230(puVar7);
      *(undefined *)(unaff_EBP + -4) = 0x3e;
      FUN_005507b0();
      FUN_0054eff0("RobloxGameIdHeader");
      puVar7 = &DAT_01d79c68;
      *(undefined *)(unaff_EBP + -4) = 0x42;
      FUN_005d15d0(unaff_EBP + -0x108);
      FUN_00551230(puVar7);
      *(undefined *)(unaff_EBP + -4) = 0x3e;
      FUN_005507b0();
      uVar3 = FUN_009ee570(unaff_EBP + -0x15c,unaff_EBP + 8);
      *(undefined *)(unaff_EBP + -4) = 0x43;
      FUN_0054eff0("isPublish");
      *(undefined *)(unaff_EBP + -4) = 0x44;
      FUN_005d15d0(unaff_EBP + -0x108);
      FUN_005511f0(uVar3);
      FUN_005507b0();
      *(undefined *)(unaff_EBP + -4) = 0x3e;
      FUN_005507b0();
      uVar3 = FUN_01675640(unaff_EBP + -0x124,&DAT_018bed48,*(undefined4 *)(unaff_EBP + 0xc),
                           *(undefined4 *)(unaff_EBP + 0x10));
      *(undefined *)(unaff_EBP + -4) = 0x45;
      FUN_0054eff0("userid");
      *(undefined *)(unaff_EBP + -4) = 0x46;
      FUN_005d15d0(unaff_EBP + -0x108);
      FUN_005511f0(uVar3);
      FUN_005507b0();
      *(undefined *)(unaff_EBP + -4) = 0x3e;
      FUN_005507b0();
      FUN_0054eff0("context");
      *(undefined *)(unaff_EBP + -4) = 0x47;
      FUN_005d15d0(unaff_EBP + -0xf0);
      FUN_005542c0("DataModel Save",0xe);
      *(undefined *)(unaff_EBP + -4) = 0x3e;
      FUN_005507b0();
      uVar3 = (**(code **)(*piVar6 + 4))();
      FUN_0054eff0("error");
      *(undefined *)(unaff_EBP + -4) = 0x48;
      FUN_005d15d0(unaff_EBP + -0xf0);
      FUN_00551260(uVar3);
      *(undefined *)(unaff_EBP + -4) = 0x3e;
      FUN_005507b0();
      FUN_0054eff0("BlockingSaveOrPublishFailure");
      *(undefined *)(unaff_EBP + -4) = 0x49;
      FUN_0054eff0("TeamCreate");
      *(undefined *)(unaff_EBP + -4) = 0x4a;
      FUN_0054eff0(&DAT_018bde9c);
      *(undefined *)(unaff_EBP + -4) = 0x4b;
      FUN_00879580(unaff_EBP + -0xf0,unaff_EBP + -0x108,unaff_EBP + -0x58,unaff_EBP + -0x2c);
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      *(undefined *)(unaff_EBP + -4) = 0x35;
      FUN_0056cfd0();
    }
    if (DAT_01d59a78 != '\0') {
      FUN_0054eff0("TeamCreate.Publish.Failed.Request");
      *(undefined *)(unaff_EBP + -4) = 0x4c;
      FUN_008783f0(unaff_EBP + -0x58,1,0);
      FUN_005507b0();
    }
    FUN_005507b0();
    return &DAT_005e7e50;
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5777 ; VA 0x005e7e55 ; Catch@005e7e55 */

undefined4 Catch_005e7e55(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  int unaff_EBP;
  undefined4 *puVar5;
  
  piVar1 = *(int **)(unaff_EBP + -0x160);
  uVar2 = (**(code **)(*piVar1 + 4))();
  uVar3 = FUN_0054eff0("Server Save Failure: Failed to serialize dataModel because ");
  *(undefined *)(unaff_EBP + -4) = 0x18;
  FUN_00558c80(unaff_EBP + -0x88,uVar3,uVar2);
  *(undefined *)(unaff_EBP + -4) = 0x1a;
  FUN_005507b0();
  iVar4 = unaff_EBP + -0x88;
  if (0xf < *(uint *)(unaff_EBP + -0x74)) {
    iVar4 = *(int *)(unaff_EBP + -0x88);
  }
  FUN_0087c6f0(&DAT_018c5f98,"Team Create",iVar4,0,0,0,3);
  if (DAT_01d64710 != '\0') {
    FUN_005d0b40(0xb,unaff_EBP + -0x11,unaff_EBP + -0x11,unaff_EBP + -0x11);
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    uVar2 = FUN_0152fd20(unaff_EBP + -0x15c);
    *(undefined *)(unaff_EBP + -4) = 0x1c;
    FUN_0054eff0("device");
    *(undefined *)(unaff_EBP + -4) = 0x1d;
    FUN_005d15d0(unaff_EBP + -0x58);
    FUN_005511f0(uVar2);
    FUN_005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    FUN_005507b0();
    FUN_0054eff0("RobloxPlaceIdHeader");
    puVar5 = &DAT_01d79c80;
    *(undefined *)(unaff_EBP + -4) = 0x1e;
    FUN_005d15d0(unaff_EBP + -0x58);
    FUN_00551230(puVar5);
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    FUN_005507b0();
    FUN_0054eff0("RobloxGameIdHeader");
    puVar5 = &DAT_01d79c68;
    *(undefined *)(unaff_EBP + -4) = 0x1f;
    FUN_005d15d0(unaff_EBP + -0x58);
    FUN_00551230(puVar5);
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    FUN_005507b0();
    uVar2 = FUN_009ee570(unaff_EBP + -0x15c,unaff_EBP + 8);
    *(undefined *)(unaff_EBP + -4) = 0x20;
    FUN_0054eff0("isPublish");
    *(undefined *)(unaff_EBP + -4) = 0x21;
    FUN_005d15d0(unaff_EBP + -0x58);
    FUN_005511f0(uVar2);
    FUN_005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    FUN_005507b0();
    uVar2 = FUN_01675640(unaff_EBP + -0x15c,&DAT_018bed48,*(undefined4 *)(unaff_EBP + 0xc),
                         *(undefined4 *)(unaff_EBP + 0x10));
    *(undefined *)(unaff_EBP + -4) = 0x22;
    FUN_0054eff0("userid");
    *(undefined *)(unaff_EBP + -4) = 0x23;
    FUN_005d15d0(unaff_EBP + -0x58);
    FUN_005511f0(uVar2);
    FUN_005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    FUN_005507b0();
    FUN_0054eff0("context");
    *(undefined *)(unaff_EBP + -4) = 0x24;
    FUN_005d15d0(unaff_EBP + -0x58);
    FUN_005542c0("DataModel Serialization",0x17);
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    FUN_005507b0();
    uVar2 = (**(code **)(*piVar1 + 4))();
    FUN_0054eff0("exception");
    *(undefined *)(unaff_EBP + -4) = 0x25;
    FUN_005d15d0(unaff_EBP + -0x58);
    FUN_00551260(uVar2);
    *(undefined *)(unaff_EBP + -4) = 0x1b;
    FUN_005507b0();
    FUN_0054eff0("BlockingSaveOrPublishFailure");
    *(undefined *)(unaff_EBP + -4) = 0x26;
    FUN_0054eff0("TeamCreate");
    *(undefined *)(unaff_EBP + -4) = 0x27;
    FUN_0054eff0(&DAT_018bde9c);
    *(undefined *)(unaff_EBP + -4) = 0x28;
    FUN_00879580(unaff_EBP + -0x58,unaff_EBP + -0xf0,unaff_EBP + -0x108,unaff_EBP + -0x2c);
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    *(undefined *)(unaff_EBP + -4) = 0x1a;
    FUN_0056cfd0();
  }
  if (*(int *)(unaff_EBP + -0x34) != 0) {
    if (*(char *)(unaff_EBP + 8) == '\0') {
      FUN_0054eff0("Failed to serialize dataModel when saving place.");
      *(undefined *)(unaff_EBP + -4) = 0x2a;
    }
    else {
      FUN_0054eff0("Failed to serialize dataModel when publishing place.");
      *(undefined *)(unaff_EBP + -4) = 0x29;
    }
    FUN_0098c2c0(3,unaff_EBP + -0x58);
    *(undefined *)(unaff_EBP + -4) = 0x1a;
    FUN_005507b0();
  }
  if (DAT_01d59a78 != '\0') {
    FUN_0054eff0("TeamCreate.Publish.Failed.Serialize");
    *(undefined *)(unaff_EBP + -4) = 0x2b;
    FUN_008783f0(unaff_EBP + -0x58,1,0);
    FUN_005507b0();
  }
  FUN_005507b0();
  return 0x5e6a0c;
}



/* FUNCTION 5778 ; VA 0x005e8250 ; FUN_005e8250 */

uint __thiscall
FUN_005e8250(int param_1,char *param_2,uint param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 ******ppppppuVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  code *pcVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 *****pppppuVar8;
  undefined8 uVar9;
  char cVar10;
  undefined uVar11;
  int iVar12;
  undefined4 ******ppppppuVar13;
  char *pcVar14;
  undefined **ppuVar15;
  undefined4 *puVar16;
  undefined *puVar17;
  undefined4 *puVar18;
  undefined4 *puVar19;
  int *piVar20;
  undefined4 uVar21;
  undefined4 ****ppppuVar22;
  undefined **ppuVar23;
  undefined4 *****pppppuVar24;
  uint uVar25;
  uint uVar26;
  undefined auStack_230 [4];
  int iStack_22c;
  undefined auStack_228 [80];
  undefined auStack_1d8 [120];
  undefined auStack_160 [16];
  undefined4 uStack_150;
  undefined4 uStack_14c;
  int *apiStack_148 [2];
  undefined4 *****pppppuStack_140;
  undefined4 ****ppppuStack_13c;
  undefined4 ****ppppuStack_138;
  undefined4 ****ppppuStack_134;
  undefined8 uStack_130;
  undefined4 *****pppppuStack_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined8 uStack_118;
  undefined4 uStack_110;
  int *piStack_10c;
  undefined4 *****pppppuStack_108;
  undefined4 ****ppppuStack_104;
  undefined4 ****ppppuStack_100;
  undefined4 ****ppppuStack_fc;
  undefined8 uStack_f8;
  undefined4 *****pppppuStack_f0;
  undefined4 ****ppppuStack_ec;
  undefined4 ****ppppuStack_e8;
  undefined4 ****ppppuStack_e4;
  undefined8 uStack_e0;
  undefined auStack_d8 [4];
  undefined *puStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined auStack_c0 [16];
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  int iStack_a4;
  undefined4 ****ppppuStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined8 uStack_90;
  undefined auStack_88 [24];
  int iStack_70;
  int *piStack_6c;
  undefined4 *****apppppuStack_68 [4];
  undefined4 uStack_58;
  uint uStack_54;
  undefined uStack_4d;
  int iStack_4c;
  char cStack_45;
  undefined4 *****pppppuStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined8 uStack_34;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b6fa;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_2 != '\0') {
    ExceptionList = &pvStack_10;
    *param_2 = '\0';
  }
  uVar26 = -(uint)(param_1 != 0) & param_1 + 0xcU;
  iStack_4c = param_1;
  iVar12 = FUN_005e5c70(uVar26);
  iStack_a4 = iVar12;
  if (DAT_01d59a78 != '\0') {
    uStack_90 = 0xf00000000;
    ppppuStack_a0 = (undefined4 ****)((uint)ppppuStack_a0 & 0xffffff00);
    FUN_005542c0("TeamCreate.Publish.Attempt",0x1a);
    uStack_8 = 0;
    FUN_008783f0(&ppppuStack_a0,1,0);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_90._4_4_) {
      uVar25 = uStack_90._4_4_ + 1;
      ppppuVar22 = ppppuStack_a0;
      if (0xfff < uVar25) {
        ppppuVar22 = (undefined4 ****)ppppuStack_a0[-1];
        uVar25 = uStack_90._4_4_ + 0x24;
        if (0x1f < (uint)((int)ppppuStack_a0 + (-4 - (int)ppppuVar22))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar22,uVar25);
    }
  }
  if ((iVar12 != 0) && ((char)param_3 != '\0')) {
    cVar10 = FUN_00a161b0(iStack_4c);
    if (cVar10 != '\0') {
      uStack_90 = 0xf00000000;
      ppppuStack_a0 = (undefined4 ****)((uint)ppppuStack_a0 & 0xffffff00);
      FUN_005542c0("Error: Cannot publish place to Roblox while there are packages with unpublished changes."
                   ,0x58);
      uStack_8 = 1;
      FUN_0098c2c0(3,&ppppuStack_a0);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      uStack_90 = 0xf00000000;
      ppppuStack_a0 = (undefined4 ****)((uint)ppppuStack_a0 & 0xffffff00);
      FUN_005542c0("CloudEditAbortPublishDueToUnpublishedPackage",0x2c);
      uStack_8 = 2;
      FUN_008783f0(&ppppuStack_a0,1,0);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      FUN_0087c450("Studio","PlacePublishBlockedByPackage","PublishBlockedByUnverifiedPackage",0,0,0
                  );
      ExceptionList = pvStack_10;
      return 0;
    }
    if (((char)param_3 != '\0') && (cVar10 = FUN_00a16240(iStack_4c), cVar10 != '\0')) {
      FUN_0087c450("Studio","PlacePublishBlockedByPackage",
                   "PublishWasNotBlockedByPendingOrModifiedPackages",0,0,0);
    }
  }
  piVar20 = *(int **)(iStack_4c + 0x43c);
  FUN_00a19ae0(*piVar20 - (int)piVar20,piVar20[1] - (int)piVar20,iStack_4c);
  uStack_118._0_4_ = 0;
  uStack_118._4_4_ = 0xf;
  pppppuStack_128 = (undefined4 *****)((uint)pppppuStack_128 & 0xffffff00);
  uStack_90 = 0xf00000000;
  ppppuStack_a0 = (undefined4 ****)((uint)ppppuStack_a0 & 0xffffff00);
  uStack_e0 = 0xf00000000;
  pppppuStack_f0 = (undefined4 *****)((uint)pppppuStack_f0 & 0xffffff00);
  uStack_8 = 5;
  FUN_00a24b20(&pppppuStack_128,uVar26,0,0);
  ppppppuVar13 = &pppppuStack_128;
  if (0xf < uStack_118._4_4_) {
    ppppppuVar13 = (undefined4 ******)pppppuStack_128;
  }
  ppppppuVar13 = (undefined4 ******)FUN_01531190(auStack_2c,ppppppuVar13,(undefined4)uStack_118);
  if (&pppppuStack_f0 != ppppppuVar13) {
    FUN_005507b0();
    pppppuStack_f0 = *ppppppuVar13;
    ppppuStack_ec = ppppppuVar13[1];
    ppppuStack_e8 = ppppppuVar13[2];
    ppppuStack_e4 = ppppppuVar13[3];
    uStack_e0 = *(undefined8 *)(ppppppuVar13 + 4);
    ppppppuVar13[4] = (undefined4 *****)0x0;
    ppppppuVar13[5] = (undefined4 *****)0xf;
    *(undefined *)ppppppuVar13 = 0;
  }
  if (0xf < uStack_18) {
    uVar25 = uStack_18 + 1;
    uVar26 = auStack_2c[0];
    if (0xfff < uVar25) {
      uVar26 = *(uint *)(auStack_2c[0] - 4);
      uVar25 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar26) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar26,uVar25);
  }
  ppppppuVar13 = &pppppuStack_128;
  if (0xf < uStack_118._4_4_) {
    ppppppuVar13 = (undefined4 ******)pppppuStack_128;
  }
  FUN_005c39d0(ppppppuVar13,(undefined4)uStack_118,&ppppuStack_a0,param_3);
  uVar7 = uStack_38;
  uVar6 = uStack_3c;
  uVar21 = uStack_40;
  uVar26 = uStack_118._4_4_;
  pppppuVar24 = pppppuStack_128;
  pppppuStack_44 = (undefined4 *****)((uint)pppppuStack_44 & 0xffffff00);
  pppppuVar8 = pppppuStack_44;
  pppppuStack_44 = pppppuStack_128;
  uStack_40 = uStack_124;
  uStack_3c = uStack_120;
  uStack_38 = uStack_11c;
  uStack_34._0_4_ = (undefined4)uStack_118;
  uStack_34._4_4_ = uStack_118._4_4_;
  uStack_118 = 0xf00000000;
  pppppuStack_128 = pppppuVar8;
  uStack_124 = uVar21;
  uStack_120 = uVar6;
  uStack_11c = uVar7;
  if (0xf < uVar26) {
    uVar25 = uVar26 + 1;
    ppppppuVar13 = (undefined4 ******)pppppuVar24;
    if (0xfff < uVar25) {
      ppppppuVar13 = (undefined4 ******)pppppuVar24[-1];
      uVar25 = uVar26 + 0x24;
      if (0x1f < (uint)((int)pppppuVar24 + (-4 - (int)ppppppuVar13))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppppuVar13,uVar25);
  }
  if (DAT_01ea937d != '\0') {
    pcVar14 = "Publishing";
    ppppppuVar13 = &pppppuStack_f0;
    if (0xf < uStack_e0._4_4_) {
      ppppppuVar13 = (undefined4 ******)pppppuStack_f0;
    }
    puVar16 = &DAT_01d79c80;
    if (0xf < DAT_01d79c94) {
      puVar16 = DAT_01d79c80;
    }
    if ((char)param_3 == '\0') {
      pcVar14 = "Saving";
    }
    FUN_01677520(DAT_01ea937d,"%s place (placeID = %s) with hash: %s",pcVar14,puVar16,ppppppuVar13);
  }
  if (DAT_01d64710 != '\0') {
    auStack_d8[0] = 0;
    piStack_14 = (int *)0xb;
    ppuVar15 = (undefined **)
               FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&piStack_14);
    ppuVar23 = ppuVar15 + -1;
    if (ppuVar15 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar23 = ppuVar15;
    }
    puStack_d4 = *ppuVar23;
    uStack_d0 = 0;
    uStack_cc = 0x3f800000;
    uStack_c8 = 0;
    uStack_c4 = 0;
    uStack_8._0_1_ = 6;
    puVar16 = (undefined4 *)FUN_0152fd20(auStack_2c);
    uStack_8._0_1_ = 7;
    uStack_34 = 0xf00000000;
    pppppuStack_44 = (undefined4 *****)((uint)pppppuStack_44 & 0xffffff00);
    FUN_005542c0("device",6);
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    iVar12 = FUN_005d15d0(&pppppuStack_44);
    if ((undefined4 *)(iVar12 + 0x18) != puVar16) {
      FUN_005507b0();
      uVar21 = puVar16[1];
      uVar6 = puVar16[2];
      uVar7 = puVar16[3];
      *(undefined4 *)(iVar12 + 0x18) = *puVar16;
      *(undefined4 *)(iVar12 + 0x1c) = uVar21;
      *(undefined4 *)(iVar12 + 0x20) = uVar6;
      *(undefined4 *)(iVar12 + 0x24) = uVar7;
      *(undefined8 *)(iVar12 + 0x28) = *(undefined8 *)(puVar16 + 4);
      puVar16[4] = 0;
      puVar16[5] = 0xf;
      *(undefined *)puVar16 = 0;
    }
    FUN_005507b0();
    uStack_8._0_1_ = 6;
    FUN_005507b0();
    uStack_34 = 0xf00000000;
    pppppuStack_44 = (undefined4 *****)((uint)pppppuStack_44 & 0xffffff00);
    FUN_005542c0("RobloxPlaceIdHeader",0x13);
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    puVar16 = (undefined4 *)FUN_005d15d0(&pppppuStack_44);
    if ((undefined4 **)puVar16 != &DAT_01d79c68) {
      puVar16 = &DAT_01d79c80;
      if (0xf < DAT_01d79c94) {
        puVar16 = DAT_01d79c80;
      }
      FUN_005542c0(puVar16,DAT_01d79c90);
    }
    uStack_8._0_1_ = 6;
    FUN_005507b0();
    uStack_34 = 0xf00000000;
    pppppuStack_44 = (undefined4 *****)((uint)pppppuStack_44 & 0xffffff00);
    FUN_005542c0("RobloxGameIdHeader",0x12);
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    puVar16 = (undefined4 *)FUN_005d15d0(&pppppuStack_44);
    if (puVar16 != &DAT_01d79c50) {
      puVar16 = &DAT_01d79c68;
      if (0xf < DAT_01d79c7c) {
        puVar16 = DAT_01d79c68;
      }
      FUN_005542c0(puVar16,DAT_01d79c78);
    }
    uStack_8._0_1_ = 6;
    FUN_005507b0();
    uStack_34 = 0xf00000000;
    uVar26 = 4;
    if ((uint)uStack_e0 < 4) {
      uVar26 = (uint)uStack_e0;
    }
    ppppppuVar13 = &pppppuStack_f0;
    if (0xf < uStack_e0._4_4_) {
      ppppppuVar13 = (undefined4 ******)pppppuStack_f0;
    }
    pppppuStack_44 = (undefined4 *****)((uint)pppppuStack_44 & 0xffffff00);
    FUN_005542c0(ppppppuVar13,uVar26);
    uStack_8._0_1_ = 0xb;
    uStack_58 = 0;
    uStack_54 = 0xf;
    apppppuStack_68[0] = (undefined4 *****)((uint)apppppuStack_68[0] & 0xffffff00);
    FUN_005542c0("md5FirstSixteenBits",0x13);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    iVar12 = FUN_005d15d0(apppppuStack_68);
    if ((undefined4 ******)(iVar12 + 0x18) != &pppppuStack_44) {
      FUN_005507b0();
      pppppuVar24 = pppppuStack_44;
      pppppuStack_44 = (undefined4 *****)((uint)pppppuStack_44 & 0xffffff00);
      *(undefined4 ******)(iVar12 + 0x18) = pppppuVar24;
      *(undefined4 *)(iVar12 + 0x1c) = uStack_40;
      *(undefined4 *)(iVar12 + 0x20) = uStack_3c;
      *(undefined4 *)(iVar12 + 0x24) = uStack_38;
      *(undefined8 *)(iVar12 + 0x28) = uStack_34;
      uStack_34 = 0xf00000000;
    }
    FUN_005507b0();
    uStack_8._0_1_ = 6;
    FUN_005507b0();
    puVar16 = (undefined4 *)FUN_009ee570(auStack_2c,&param_3);
    uStack_8._0_1_ = 0xd;
    uStack_58 = 0;
    uStack_54 = 0xf;
    apppppuStack_68[0] = (undefined4 *****)((uint)apppppuStack_68[0] & 0xffffff00);
    FUN_005542c0("isPublish",9);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
    iVar12 = FUN_005d15d0(apppppuStack_68);
    if ((undefined4 *)(iVar12 + 0x18) != puVar16) {
      FUN_005507b0();
      uVar21 = puVar16[1];
      uVar6 = puVar16[2];
      uVar7 = puVar16[3];
      *(undefined4 *)(iVar12 + 0x18) = *puVar16;
      *(undefined4 *)(iVar12 + 0x1c) = uVar21;
      *(undefined4 *)(iVar12 + 0x20) = uVar6;
      *(undefined4 *)(iVar12 + 0x24) = uVar7;
      *(undefined8 *)(iVar12 + 0x28) = *(undefined8 *)(puVar16 + 4);
      puVar16[4] = 0;
      puVar16[5] = 0xf;
      *(undefined *)puVar16 = 0;
    }
    FUN_005507b0();
    uStack_8._0_1_ = 6;
    FUN_005507b0();
    puVar16 = (undefined4 *)FUN_01675640(auStack_2c,&DAT_018bed48,param_4,param_5);
    uStack_8._0_1_ = 0xf;
    uStack_58 = 0;
    uStack_54 = 0xf;
    apppppuStack_68[0] = (undefined4 *****)((uint)apppppuStack_68[0] & 0xffffff00);
    FUN_005542c0("userid",6);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
    iVar12 = FUN_005d15d0(apppppuStack_68);
    if ((undefined4 *)(iVar12 + 0x18) != puVar16) {
      FUN_005507b0();
      uVar21 = puVar16[1];
      uVar6 = puVar16[2];
      uVar7 = puVar16[3];
      *(undefined4 *)(iVar12 + 0x18) = *puVar16;
      *(undefined4 *)(iVar12 + 0x1c) = uVar21;
      *(undefined4 *)(iVar12 + 0x20) = uVar6;
      *(undefined4 *)(iVar12 + 0x24) = uVar7;
      *(undefined8 *)(iVar12 + 0x28) = *(undefined8 *)(puVar16 + 4);
      puVar16[4] = 0;
      puVar16[5] = 0xf;
      *(undefined *)puVar16 = 0;
    }
    FUN_005507b0();
    uStack_8._0_1_ = 6;
    FUN_005507b0();
    uStack_b0 = 0;
    uStack_ac = 0xf;
    auStack_c0[0] = 0;
    FUN_005542c0("BlockingSaveOrPublish",0x15);
    uStack_8._0_1_ = 0x11;
    uStack_34._0_4_ = 0;
    uStack_34._4_4_ = 0xf;
    pppppuStack_44 = (undefined4 *****)((uint)pppppuStack_44 & 0xffffff00);
    FUN_005542c0("TeamCreate",10);
    uStack_8._0_1_ = 0x12;
    uStack_58 = 0;
    uStack_54 = 0xf;
    apppppuStack_68[0] = (undefined4 *****)((uint)apppppuStack_68[0] & 0xffffff00);
    FUN_005542c0(&DAT_018bde9c,3);
    uStack_8._0_1_ = 0x13;
    FUN_00879580(apppppuStack_68,&pppppuStack_44,auStack_c0,auStack_d8);
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_0056cfd0();
  }
  if (DAT_01ea937e != '\0') {
    uVar26 = 4;
    if ((uint)uStack_e0 < 4) {
      uVar26 = (uint)uStack_e0;
    }
    ppppppuVar13 = &pppppuStack_f0;
    if (0xf < uStack_e0._4_4_) {
      ppppppuVar13 = (undefined4 ******)pppppuStack_f0;
    }
    uStack_34._0_4_ = 0;
    uStack_34._4_4_ = 0xf;
    pppppuStack_44 = (undefined4 *****)((uint)pppppuStack_44 & 0xffffff00);
    FUN_005542c0(ppppppuVar13,uVar26);
    ppppppuVar13 = &pppppuStack_44;
    if (0xf < uStack_34._4_4_) {
      ppppppuVar13 = (undefined4 ******)pppppuStack_44;
    }
    puVar16 = &DAT_01d79c68;
    if (0xf < DAT_01d79c7c) {
      puVar16 = DAT_01d79c68;
    }
    puVar18 = &DAT_01d79c80;
    if (0xf < DAT_01d79c94) {
      puVar18 = DAT_01d79c80;
    }
    uStack_8._0_1_ = 0x14;
    FUN_01677520(DAT_01ea937e,
                 "TeamCreate BlockingSaveOrPublish Roblox-Place-Id: [%s] Roblox-Game-Id: [%s] isPublish: [%d] first 16 bits of md5: [%s] authorId: [%lld]"
                 ,puVar18,puVar16,param_3 & 0xff,ppppppuVar13,param_4,param_5);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (0xf < uStack_34._4_4_) {
      uVar26 = uStack_34._4_4_ + 1;
      ppppppuVar13 = (undefined4 ******)pppppuStack_44;
      if (0xfff < uVar26) {
        ppppppuVar13 = (undefined4 ******)pppppuStack_44[-1];
        uVar26 = uStack_34._4_4_ + 0x24;
        if (0x1f < (uint)((int)pppppuStack_44 + (-4 - (int)ppppppuVar13))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppppuVar13,uVar26);
    }
  }
  if ((DAT_01d658cc < 1) || (cStack_45 = '\x01', DAT_01d658f8 < DAT_01d658cc)) {
    cStack_45 = '\0';
  }
  puVar17 = (undefined *)FUN_01674e20(0x18);
  if (puVar17 == (undefined *)0x0) {
    puVar17 = (undefined *)0x0;
    piStack_14 = (int *)0x0;
  }
  else {
    *puVar17 = 0;
    piStack_14 = (int *)0xb;
    ppuVar15 = (undefined **)
               FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&piStack_14);
    ppuVar23 = ppuVar15 + -1;
    if (ppuVar15 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar23 = ppuVar15;
    }
    *(undefined **)(puVar17 + 4) = *ppuVar23;
    *(undefined4 *)(puVar17 + 8) = 0;
    *(undefined4 *)(puVar17 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar17 + 0x10) = 0;
    *(undefined4 *)(puVar17 + 0x14) = 0;
  }
  uStack_110 = 0;
  piStack_10c = (int *)0x0;
  FUN_005c1af0(puVar17,param_3);
  uStack_4d = (char)param_3 == '\0';
  puVar17 = &uStack_4d;
  uStack_8._0_1_ = 0x15;
  FUN_005c4c00(&DAT_01d59a08);
  FUN_005e52b0(puVar17);
  pppppuVar24 = &ppppuStack_a0;
  FUN_005c4c00(&DAT_01d59a38);
  FUN_005c16d0(pppppuVar24);
  ppppppuVar13 = &pppppuStack_f0;
  FUN_005c4c00(&DAT_01d59a50);
  FUN_005c16d0(ppppppuVar13);
  uStack_150 = 0;
  uStack_14c = 0xf;
  auStack_160[0] = 0;
  uStack_8._0_1_ = 0x16;
  FUN_005e4d60(&uStack_110);
  uStack_8._0_1_ = 0x17;
  FUN_0098fc00(auStack_230,auStack_160,1);
  uStack_8._0_1_ = 0x18;
  if (iStack_22c != 0) {
    (**(code **)(iStack_22c + 8))(auStack_228);
  }
  uVar7 = uStack_38;
  uVar6 = uStack_3c;
  uVar21 = uStack_40;
  ppppuVar22 = ppppuStack_a0;
  pppppuStack_44 = (undefined4 *****)((uint)pppppuStack_44 & 0xffffff00);
  pppppuVar24 = pppppuStack_44;
  pppppuStack_44 = (undefined4 *****)ppppuStack_a0;
  uStack_40 = uStack_9c;
  uStack_3c = uStack_98;
  uStack_38 = uStack_94;
  uStack_8._0_1_ = 0x16;
  uVar11 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x16;
  uStack_34 = uStack_90;
  uVar9 = uStack_34;
  uStack_34._4_4_ = (uint)((ulonglong)uStack_90 >> 0x20);
  uStack_90 = 0xf00000000;
  ppppuStack_a0 = pppppuVar24;
  uStack_9c = uVar21;
  uStack_98 = uVar6;
  uStack_94 = uVar7;
  if (0xf < uStack_34._4_4_) {
    uVar26 = uStack_34._4_4_ + 1;
    pppppuVar24 = (undefined4 *****)ppppuVar22;
    uStack_34 = uVar9;
    if (0xfff < uVar26) {
      pppppuVar24 = (undefined4 *****)ppppuVar22[-1];
      uVar26 = uStack_34._4_4_ + 0x24;
      if (0x1f < (uint)((int)ppppuVar22 + (-4 - (int)pppppuVar24))) {
        uStack_8._0_1_ = uVar11;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar24,uVar26);
    uVar9 = uStack_34;
  }
  uStack_34 = uVar9;
  uVar11 = DAT_01d65a38;
  if (cStack_45 != '\0') {
    uVar11 = 0;
  }
  uStack_130 = 0xf00000000;
  piStack_14 = (int *)CONCAT31(piStack_14._1_3_,uVar11);
  pppppuStack_140 = (undefined4 *****)((uint)pppppuStack_140 & 0xffffff00);
  uStack_8._0_1_ = 0x19;
  uVar11 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x19;
  if (cStack_45 == '\0') {
    piVar20 = *(int **)(iStack_4c + 0x43c);
    uStack_8._0_1_ = uVar11;
    ppppppuVar13 = (undefined4 ******)
                   FUN_00a27b10(auStack_88,*piVar20 - (int)piVar20,piVar20[1] - (int)piVar20);
    uStack_8._0_1_ = 0x20;
    if (&pppppuStack_140 != ppppppuVar13) {
      ppppppuVar1 = ppppppuVar13 + 4;
      if ((undefined4 *****)0xf < ppppppuVar13[5]) {
        ppppppuVar13 = (undefined4 ******)*ppppppuVar13;
      }
      FUN_005542c0(ppppppuVar13,*ppppppuVar1);
    }
  }
  else {
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 0x1a;
    uStack_c8 = 0;
    uStack_c4 = 0xf;
    auStack_d8[0] = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 0x1b;
    uStack_34 = 0xf00000000;
    pppppuStack_44 = (undefined4 *****)((uint)pppppuStack_44 & 0xffffff00);
    FUN_005542c0("/publish-mock/v1/Places/200",0x1b);
    uStack_8._0_1_ = 0x1c;
    uStack_58 = 0;
    uStack_54 = 0xf;
    apppppuStack_68[0] = (undefined4 *****)((uint)apppppuStack_68[0] & 0xffffff00);
    FUN_005542c0("apis.simulpong.com",0x12);
    uStack_8._0_1_ = 0x1d;
    uStack_b0 = 0;
    uStack_ac = 0xf;
    auStack_c0[0] = 0;
    FUN_005542c0(&DAT_018c71bc,4);
    uStack_8._0_1_ = 0x1e;
    FUN_0151bcc0(auStack_1d8,auStack_c0,apppppuStack_68,&pppppuStack_44,auStack_d8,auStack_2c);
    uStack_8._0_1_ = 0x1f;
    ppppppuVar13 = (undefined4 ******)FUN_0151bb70(auStack_88);
    if (&pppppuStack_140 != ppppppuVar13) {
      FUN_005507b0();
      pppppuStack_140 = *ppppppuVar13;
      ppppuStack_13c = ppppppuVar13[1];
      ppppuStack_138 = ppppppuVar13[2];
      ppppuStack_134 = ppppppuVar13[3];
      uStack_130 = *(undefined8 *)(ppppppuVar13 + 4);
      ppppppuVar13[4] = (undefined4 *****)0x0;
      ppppppuVar13[5] = (undefined4 *****)0xf;
      *(undefined *)ppppppuVar13 = 0;
    }
    FUN_005507b0();
    FUN_0056d9d0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
  }
  uStack_8._0_1_ = 0x19;
  FUN_005507b0();
  FUN_014c9d60(&iStack_70,0);
  ppppppuVar13 = &pppppuStack_140;
  if (0xf < uStack_130._4_4_) {
    ppppppuVar13 = (undefined4 ******)pppppuStack_140;
  }
  uStack_8._0_1_ = 0x21;
  FUN_014cbbc0(ppppppuVar13,(undefined4)uStack_130);
  *(undefined4 *)(iStack_70 + 0xb0) = 0;
  puVar16 = &DAT_01d79f98;
  if (0xf < DAT_01d79fac) {
    puVar16 = DAT_01d79f98;
  }
  puVar18 = &DAT_01d79d70;
  if (0xf < DAT_01d79d84) {
    puVar18 = DAT_01d79d70;
  }
  FUN_014cb8a0(puVar18,DAT_01d79d80,puVar16,DAT_01d79fa8);
  puVar18 = (undefined4 *)FUN_01675640(auStack_88,&DAT_018bed48,param_4,param_5);
  puVar16 = puVar18 + 4;
  uStack_8._0_1_ = 0x22;
  if (0xf < (uint)puVar18[5]) {
    puVar18 = (undefined4 *)*puVar18;
  }
  puVar19 = &DAT_01d79ef0;
  if (0xf < DAT_01d79f04) {
    puVar19 = DAT_01d79ef0;
  }
  FUN_014cb8a0(puVar19,DAT_01d79f00,puVar18,*puVar16);
  uStack_8._0_1_ = 0x21;
  FUN_005507b0();
  FUN_014cba10(&DAT_018c88a0,3);
  FUN_014cb780(auStack_160,piStack_14);
  iVar12 = iStack_a4;
  if (DAT_01d64710 != '\0') {
    puVar18 = (undefined4 *)FUN_01675640(auStack_88,&DAT_018bed48,param_4,param_5);
    puVar16 = puVar18 + 4;
    uStack_8._0_1_ = 0x23;
    if (0xf < (uint)puVar18[5]) {
      puVar18 = (undefined4 *)*puVar18;
    }
    FUN_014cb8a0("X-Roblox-Author-ID",0x12,puVar18,*puVar16);
    uStack_8._0_1_ = 0x21;
    FUN_005507b0();
    iVar12 = iStack_a4;
    puVar18 = (undefined4 *)FUN_005ea020(auStack_88,iStack_a4);
    puVar16 = puVar18 + 4;
    uStack_8._0_1_ = 0x24;
    if (0xf < (uint)puVar18[5]) {
      puVar18 = (undefined4 *)*puVar18;
    }
    FUN_014cb8a0("X-Roblox-Players-Log",0x14,puVar18,*puVar16);
    uStack_8._0_1_ = 0x21;
    FUN_005507b0();
  }
  FUN_014cb340(apiStack_148);
  uStack_8._0_1_ = 0x25;
  uVar11 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x25;
  if (apiStack_148[0] == (int *)0x0) {
    uStack_8._0_1_ = uVar11;
    uVar21 = FUN_0056acb0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0x26);
    FUN_00564940(uVar21);
    pcVar5 = (code *)swi(3);
    uVar26 = (*pcVar5)();
    return uVar26;
  }
  piStack_14 = (int *)(**(code **)(*apiStack_148[0] + 0x14))();
  uStack_f8 = 0xf00000000;
  pppppuStack_108 = (undefined4 *****)((uint)pppppuStack_108 & 0xffffff00);
  iVar3 = *piStack_14;
  uStack_8._0_1_ = 0x27;
  uVar11 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x27;
  if (*(int *)(iVar3 + 0x70) == 0) {
    iVar4 = *(int *)(iVar3 + 0xc);
    if ((99 < iVar4 - 200U) || (iVar4 == 0xca)) {
      piVar20 = (int *)(iVar3 + 0x10);
      if (0xf < *(uint *)(iVar3 + 0x24)) {
        piVar20 = (int *)*piVar20;
      }
      uStack_8._0_1_ = uVar11;
      uVar21 = FUN_01675640(auStack_88,"HTTP (%d): %s",iVar4,piVar20);
      FUN_005511f0(uVar21);
      goto LAB_005e9426;
    }
    uStack_a8 = 0;
    iStack_a4 = 0;
    uStack_8._0_1_ = 0x29;
    cVar10 = FUN_0098f070(iVar3 + 0x40,&uStack_a8,0);
    if (cVar10 == '\0') {
      uVar21 = FUN_005543f0();
      pcVar14 = "can\'t parse JSON response: `%s`";
    }
    else {
      FUN_00580040(&piStack_14,&DAT_01d599f0);
      if (piStack_14 != (int *)0x0) {
        puVar16 = (undefined4 *)FUN_0055d5e0();
        *(undefined4 *)(param_2 + 4) = *puVar16;
        if (*param_2 == '\0') {
          *param_2 = '\x01';
        }
        if (iVar12 != 0) {
          FUN_0054eff0("Save Level Complete");
          uStack_8._0_1_ = 0x2a;
          FUN_0097c9e0(auStack_2c);
          uStack_8._0_1_ = 0x29;
          FUN_005507b0();
          if (DAT_01d64710 != '\0') {
            FUN_005ea7b0();
          }
        }
        FUN_00550b30();
        param_2 = (char *)CONCAT13(1,param_2._0_3_);
        goto LAB_005e99b2;
      }
      uVar21 = FUN_005543f0();
      pcVar14 = "saved place version number is missing: `%s`";
    }
    uVar21 = FUN_01675640(auStack_88,pcVar14,uVar21);
    FUN_005511f0(uVar21);
    FUN_005507b0();
    uStack_8._0_1_ = 0x27;
    FUN_00550b30();
  }
  else {
    ppppppuVar13 = (undefined4 ******)
                   FUN_01675640(auStack_88,"HTTP transport error (%d)",*(int *)(iVar3 + 0x70));
    if (&pppppuStack_108 != ppppppuVar13) {
      FUN_005507b0();
      pppppuStack_108 = *ppppppuVar13;
      ppppuStack_104 = ppppppuVar13[1];
      ppppuStack_100 = ppppppuVar13[2];
      ppppuStack_fc = ppppppuVar13[3];
      uStack_f8 = *(undefined8 *)(ppppppuVar13 + 4);
      ppppppuVar13[4] = (undefined4 *****)0x0;
      ppppppuVar13[5] = (undefined4 *****)0xf;
      *(undefined *)ppppppuVar13 = 0;
    }
    FUN_005507b0();
    if (*(int *)(*piStack_14 + 0x84) != 0) {
      puVar18 = (undefined4 *)FUN_00558df0(auStack_88,&DAT_018bcaac,*piStack_14 + 0x74);
      puVar16 = puVar18 + 4;
      uStack_8._0_1_ = 0x28;
      if (0xf < (uint)puVar18[5]) {
        puVar18 = (undefined4 *)*puVar18;
      }
      FUN_00554150(puVar18,*puVar16);
      uStack_8._0_1_ = 0x27;
LAB_005e9426:
      FUN_005507b0();
    }
  }
  if (iVar12 != 0) {
    uStack_34 = 0xf00000000;
    pppppuStack_44 = (undefined4 *****)((uint)pppppuStack_44 & 0xffffff00);
    uStack_8._0_1_ = 0x2b;
    uVar11 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x2b;
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    if ((char)param_3 == '\0') {
      uStack_8._0_1_ = uVar11;
      FUN_005542c0("Server Save Failure: ",0x15);
      uStack_8._0_1_ = 0x2d;
    }
    else {
      FUN_005542c0("Server Publish Failure: ",0x18);
      uStack_8._0_1_ = 0x2c;
    }
    uVar21 = FUN_00558c20(auStack_88,auStack_2c,&pppppuStack_108);
    FUN_005511f0(uVar21);
    FUN_005507b0();
    uStack_8._0_1_ = 0x2b;
    FUN_005507b0();
    FUN_0098c2c0(3,&pppppuStack_44);
    uStack_8._0_1_ = 0x27;
    FUN_005507b0();
  }
  if (DAT_01d59a70 != '\0') {
    uStack_b0 = 0;
    uStack_ac = 0xf;
    auStack_c0[0] = 0;
    FUN_005542c0(" url: ",6);
    uStack_8._0_1_ = 0x2e;
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("ServerSaveFailure ",0x12);
    uStack_8._0_1_ = 0x2f;
    uVar21 = FUN_00558ba0(auStack_88,auStack_2c,auStack_c0);
    uStack_8._0_1_ = 0x30;
    FUN_00558c20(apppppuStack_68,uVar21,&pppppuStack_140);
    FUN_005507b0();
    FUN_005507b0();
    uStack_8._0_1_ = 0x34;
    FUN_005507b0();
    ppppppuVar13 = apppppuStack_68;
    if (0xf < uStack_54) {
      ppppppuVar13 = (undefined4 ******)apppppuStack_68[0];
    }
    FUN_0087c6f0(&DAT_018c5f98,"Team Create",ppppppuVar13,0,0,0,3);
    uStack_8._0_1_ = 0x27;
    FUN_005507b0();
  }
  if (DAT_01d64710 != '\0') {
    FUN_005d0b40(0xb,(int)&param_2 + 3,(int)&param_2 + 3,(int)&param_2 + 3);
    uStack_8._0_1_ = 0x35;
    uVar21 = FUN_0152fd20(auStack_88);
    uStack_8._0_1_ = 0x36;
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("device",6);
    uStack_8._0_1_ = 0x37;
    FUN_005d15d0(auStack_2c);
    FUN_005511f0(uVar21);
    FUN_005507b0();
    uStack_8._0_1_ = 0x35;
    FUN_005507b0();
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("RobloxPlaceIdHeader",0x13);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x38);
    puVar16 = (undefined4 *)FUN_005d15d0(auStack_2c);
    if ((undefined4 **)puVar16 != &DAT_01d79c68) {
      puVar16 = &DAT_01d79c80;
      if (0xf < DAT_01d79c94) {
        puVar16 = DAT_01d79c80;
      }
      FUN_005542c0(puVar16,DAT_01d79c90);
    }
    uStack_8._0_1_ = 0x35;
    FUN_005507b0();
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("RobloxGameIdHeader",0x12);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x39);
    puVar16 = (undefined4 *)FUN_005d15d0(auStack_2c);
    if (puVar16 != &DAT_01d79c50) {
      puVar16 = &DAT_01d79c68;
      if (0xf < DAT_01d79c7c) {
        puVar16 = DAT_01d79c68;
      }
      FUN_005542c0(puVar16,DAT_01d79c78);
    }
    uStack_8._0_1_ = 0x35;
    FUN_005507b0();
    uVar21 = FUN_009ee570(auStack_88,&param_3);
    uStack_8._0_1_ = 0x3a;
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("isPublish",9);
    uStack_8._0_1_ = 0x3b;
    FUN_005d15d0(auStack_2c);
    FUN_005511f0(uVar21);
    FUN_005507b0();
    uStack_8._0_1_ = 0x35;
    FUN_005507b0();
    uVar21 = FUN_01675640(auStack_c0,&DAT_018bed48,param_4,param_5);
    uStack_8._0_1_ = 0x3c;
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("userid",6);
    uStack_8._0_1_ = 0x3d;
    FUN_005d15d0(auStack_2c);
    FUN_005511f0(uVar21);
    FUN_005507b0();
    uStack_8._0_1_ = 0x35;
    FUN_005507b0();
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("context",7);
    uStack_8._0_1_ = 0x3e;
    FUN_005d15d0(auStack_2c);
    FUN_005542c0("DataModel Save",0xe);
    uStack_8._0_1_ = 0x35;
    FUN_005507b0();
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("error",5);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x3f);
    iVar12 = FUN_005d15d0(auStack_2c);
    if ((undefined4 ******)(iVar12 + 0x18) != &pppppuStack_108) {
      ppppppuVar13 = &pppppuStack_108;
      if (0xf < uStack_f8._4_4_) {
        ppppppuVar13 = (undefined4 ******)pppppuStack_108;
      }
      FUN_005542c0(ppppppuVar13,(undefined4)uStack_f8);
    }
    uStack_8._0_1_ = 0x35;
    FUN_005507b0();
    uStack_58 = 0;
    uStack_54 = 0xf;
    apppppuStack_68[0] = (undefined4 *****)((uint)apppppuStack_68[0] & 0xffffff00);
    FUN_005542c0("BlockingSaveOrPublishFailure",0x1c);
    uStack_8._0_1_ = 0x40;
    uStack_b0 = 0;
    uStack_ac = 0xf;
    auStack_c0[0] = 0;
    FUN_005542c0("TeamCreate",10);
    uStack_8._0_1_ = 0x41;
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bde9c,3);
    uStack_8._0_1_ = 0x42;
    FUN_00879580(auStack_2c,auStack_c0,apppppuStack_68,&pppppuStack_44);
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    uStack_8._0_1_ = 0x27;
    FUN_0056cfd0();
  }
  if (DAT_01d59a78 != '\0') {
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("TeamCreate.Publish.Failed.Request",0x21);
    uStack_8._0_1_ = 0x43;
    FUN_008783f0(auStack_2c,1,0);
    FUN_005507b0();
  }
  param_2 = (char *)((uint)param_2 & 0xffffff);
LAB_005e99b2:
  FUN_005507b0();
  FUN_00550ad0();
  if (piStack_6c != (int *)0x0) {
    LOCK();
    iVar12 = piStack_6c[1] + -1;
    piStack_6c[1] = iVar12;
    UNLOCK();
    if (iVar12 == 0) {
      (**(code **)*piStack_6c)();
      LOCK();
      iVar12 = piStack_6c[2] + -1;
      piStack_6c[2] = iVar12;
      UNLOCK();
      if (iVar12 == 0) {
        (**(code **)(*piStack_6c + 4))();
      }
    }
  }
  FUN_005507b0();
  FUN_005507b0();
  piVar20 = piStack_10c;
  if (piStack_10c != (int *)0x0) {
    LOCK();
    iVar12 = piStack_10c[1] + -1;
    piStack_10c[1] = iVar12;
    UNLOCK();
    if (iVar12 == 0) {
      (**(code **)*piStack_10c)();
      LOCK();
      piVar2 = piVar20 + 2;
      iVar12 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar12 == 1) {
        (**(code **)(*piVar20 + 4))();
      }
    }
  }
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return (uint)param_2 >> 0x18;
}



/* FUNCTION 5779 ; VA 0x005e9aa0 ; FUN_005e9aa0 */

void FUN_005e9aa0(int param_1,int param_2)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_01674e20(0x10);
  if (param_1 == 0) {
    *piVar1 = (int)piVar1;
    piVar1[1] = (int)piVar1;
    return;
  }
  *piVar1 = param_1;
  piVar1[1] = param_2;
  return;
}



/* FUNCTION 5780 ; VA 0x005e9ad0 ; FUN_005e9ad0 */

void __fastcall FUN_005e9ad0(float *param_1)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  undefined auStack_c [8];
  
  fVar2 = param_1[7];
  fVar3 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
          (float)((double)(int)fVar2 + (double)(&DAT_018c0d90)[-((int)fVar2 >> 0x1f)]);
  if (*param_1 <= fVar3 && fVar3 != *param_1) {
    if ((uint)fVar2 < 0x200) {
      fVar2 = (float)((int)fVar2 << 3);
    }
    else if ((uint)fVar2 < 0x1fffffff) {
      fVar2 = (float)((int)fVar2 * 2);
    }
    FUN_005cb500(fVar2);
    pfVar1 = (float *)param_1[1];
    if ((float *)*pfVar1 != pfVar1) {
      fVar2 = pfVar1[1];
      do {
        fVar3 = *(float *)param_1[1];
        FUN_005e5710(auStack_c,(int)fVar3 + 8,fVar3);
      } while (fVar3 != fVar2);
    }
  }
  return;
}



/* FUNCTION 5781 ; VA 0x005e9b70 ; FUN_005e9b70 */

void __thiscall FUN_005e9b70(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_409bc24c56ce02a163c697b3de501aed>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  return;
}



/* FUNCTION 5782 ; VA 0x005e9b90 ; FUN_005e9b90 */

void __fastcall FUN_005e9b90(int param_1)

{
  FUN_005e5390(param_1 + 8);
  return;
}



/* FUNCTION 5783 ; VA 0x005e9ba0 ; FUN_005e9ba0 */

void __thiscall FUN_005e9ba0(undefined4 param_1,char param_2)

{
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0xc);
  }
  return;
}



/* FUNCTION 5784 ; VA 0x005e9bc0 ; FUN_005e9bc0 */

void __thiscall FUN_005e9bc0(undefined4 param_1,char param_2)

{
  FUN_005e6080();
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0x50);
  }
  return;
}



/* FUNCTION 5785 ; VA 0x005e9bf0 ; FUN_005e9bf0 */

void __thiscall FUN_005e9bf0(int param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int *piVar6;
  int iVar7;
  uint uVar8;
  undefined auStack_44 [24];
  int aiStack_2c [5];
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  iStack_14 = param_1;
  if (*param_2 == 0) {
    iVar7 = *(int *)(param_3 + 0xc);
    if ((iVar7 - 200U < 100) && (ExceptionList = &pvStack_10, iVar7 != 0xca)) goto LAB_005e9d53;
    piVar6 = (int *)(param_3 + 0x10);
    if (0xf < *(uint *)(param_3 + 0x24)) {
      piVar6 = (int *)*piVar6;
    }
    ExceptionList = &pvStack_10;
    puVar5 = (undefined4 *)FUN_01675640(auStack_44,"HTTP (%d): %s",iVar7,piVar6);
    puVar1 = *(undefined4 **)(iStack_14 + 8);
    if (puVar1 != puVar5) {
      FUN_005507b0();
      uVar2 = puVar5[1];
      uVar3 = puVar5[2];
      uVar4 = puVar5[3];
      *puVar1 = *puVar5;
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(puVar5 + 4);
      puVar5[4] = 0;
      puVar5[5] = 0xf;
      *(undefined *)puVar5 = 0;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    puVar5 = (undefined4 *)FUN_01675640(aiStack_2c,"Http transport error (%d)",*param_2);
    puVar1 = *(undefined4 **)(iStack_14 + 8);
    if (puVar1 != puVar5) {
      FUN_005507b0();
      uVar2 = puVar5[1];
      uVar3 = puVar5[2];
      uVar4 = puVar5[3];
      *puVar1 = *puVar5;
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(puVar5 + 4);
      puVar5[4] = 0;
      puVar5[5] = 0xf;
      *(undefined *)puVar5 = 0;
    }
    if (0xf < uStack_18) {
      uVar8 = uStack_18 + 1;
      iVar7 = aiStack_2c[0];
      if (0xfff < uVar8) {
        iVar7 = *(int *)(aiStack_2c[0] + -4);
        uVar8 = uStack_18 + 0x24;
        if (0x1f < (aiStack_2c[0] - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar7,uVar8);
    }
    if (*(int *)(param_3 + 0x84) == 0) goto LAB_005e9d53;
    puVar5 = (undefined4 *)FUN_00558df0(aiStack_2c,&DAT_018bcaac,param_3 + 0x74);
    puVar1 = puVar5 + 4;
    uStack_8 = 0;
    if (0xf < (uint)puVar5[5]) {
      puVar5 = (undefined4 *)*puVar5;
    }
    FUN_00554150(puVar5,*puVar1);
  }
  FUN_005507b0();
LAB_005e9d53:
  FUN_0151f3f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5786 ; VA 0x005e9d80 ; FUN_005e9d80 */

void FUN_005e9d80(undefined4 *param_1,undefined4 param_2)

{
  FUN_005e6390(*param_1,param_2);
  return;
}



/* FUNCTION 5787 ; VA 0x005e9da0 ; FUN_005e9da0 */

int __fastcall FUN_005e9da0(int param_1)

{
  return param_1 + 8;
}



/* FUNCTION 5788 ; VA 0x005e9db0 ; FUN_005e9db0 */

uint __thiscall FUN_005e9db0(int param_1,undefined4 param_2)

{
  uint uVar1;
  
  uVar1 = FUN_005e6570(param_2);
  return uVar1 & *(uint *)(param_1 + 0x18);
}



/* FUNCTION 5789 ; VA 0x005e9dd0 ; FUN_005e9dd0 */

undefined4 * __thiscall FUN_005e9dd0(int param_1,undefined4 *param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b718;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_59109c2698aa89ec6a40db0777bffc40>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[2] = 0;
  FUN_005880d0(param_1 + 8);
  uStack_8 = 0;
  param_2[10] = 0;
  FUN_005880d0(param_1 + 0x28);
  param_2[0x12] = 0;
  param_2[0x13] = 0;
  param_2[0x12] = *(undefined4 *)(param_1 + 0x48);
  param_2[0x13] = *(undefined4 *)(param_1 + 0x4c);
  *(undefined4 *)(param_1 + 0x48) = 0;
  *(undefined4 *)(param_1 + 0x4c) = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5790 ; VA 0x005e9e70 ; FUN_005e9e70 */

TypeDescriptor * FUN_005e9e70(void)

{
  return &<lambda_409bc24c56ce02a163c697b3de501aed>::RTTI_Type_Descriptor;
}



/* FUNCTION 5791 ; VA 0x005e9e80 ; FUN_005e9e80 */

TypeDescriptor * FUN_005e9e80(void)

{
  return &<lambda_59109c2698aa89ec6a40db0777bffc40>::RTTI_Type_Descriptor;
}



/* FUNCTION 5792 ; VA 0x005e9e90 ; FUN_005e9e90 */

void __fastcall FUN_005e9e90(int param_1)

{
  int *piVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(param_1 + 4);
  piVar2 = (int *)*piVar1;
  ExceptionList = &pvStack_10;
  *piVar1 = (int)piVar1;
  *(int *)(*(int *)(param_1 + 4) + 4) = *(int *)(param_1 + 4);
  *(undefined4 *)(param_1 + 8) = 0;
  if (piVar2 != *(int **)(param_1 + 4)) {
    do {
      piVar1 = (int *)*piVar2;
      FUN_01674ea0(piVar2,0x10);
      piVar2 = piVar1;
    } while (piVar1 != (int *)*(int *)(param_1 + 4));
  }
  FUN_005cb500(8);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5793 ; VA 0x005e9f00 ; FUN_005e9f00 */

void __fastcall FUN_005e9f00(int *param_1)

{
  int *piVar1;
  int *piVar2;
  
  piVar1 = (int *)*param_1;
  piVar2 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar2 != (int *)*param_1) {
    do {
      piVar1 = (int *)*piVar2;
      FUN_01674ea0(piVar2,0x10);
      piVar2 = piVar1;
    } while (piVar1 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 5794 ; VA 0x005e9f40 ; FUN_005e9f40 */

void __thiscall FUN_005e9f40(int param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  int *piVar4;
  
  uVar3 = FUN_005e6570(param_3 + 2);
  iVar1 = (uVar3 & *(uint *)(param_1 + 0x18)) * 8;
  piVar2 = *(int **)(*(int *)(param_1 + 0xc) + iVar1);
  piVar4 = (int *)(*(int *)(param_1 + 0xc) + iVar1);
  if ((int *)piVar4[1] == param_3) {
    if (piVar2 == param_3) {
      *piVar4 = *(int *)(param_1 + 4);
      *(undefined4 *)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar4[1] = param_3[1];
    }
  }
  else if (piVar2 == param_3) {
    *piVar4 = *param_3;
  }
  iVar1 = *param_3;
  *(int *)param_3[1] = iVar1;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_01674ea0(param_3,0x10);
  *param_2 = iVar1;
  return;
}



/* FUNCTION 5795 ; VA 0x005e9fc0 ; FUN_005e9fc0 */

void __fastcall FUN_005e9fc0(int *param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b738;
  pvStack_10 = ExceptionList;
  if ((int *)*param_1 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*(int *)*param_1 + 0x14))();
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0056acb0();
  uStack_8 = 0;
  FUN_00564940(uVar2);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 5796 ; VA 0x005ea010 ; FUN_005ea010 */

undefined8 __fastcall FUN_005ea010(int param_1)

{
  int *piVar1;
  
  piVar1 = *(int **)(param_1 + 0x43c);
  return CONCAT44(piVar1[1] - (int)piVar1,*piVar1 - (int)piVar1);
}



/* FUNCTION 5797 ; VA 0x005ea020 ; FUN_005ea020 */

uint * FUN_005ea020(uint *param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined3 uVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  uint uVar9;
  int iVar10;
  uint uVar11;
  int *piVar12;
  undefined8 uVar13;
  int aiStack_c0 [5];
  uint uStack_ac;
  uint auStack_a8 [4];
  undefined4 uStack_98;
  uint uStack_94;
  undefined auStack_90 [8];
  int iStack_88;
  int *piStack_84;
  int *piStack_80;
  int *piStack_7c;
  uint uStack_78;
  uint uStack_74;
  uint uStack_70;
  uint uStack_6c;
  int iStack_68;
  undefined4 uStack_64;
  undefined8 uStack_60;
  undefined4 uStack_58;
  int *piStack_54;
  undefined4 uStack_50;
  int *piStack_4c;
  undefined4 uStack_48;
  undefined4 *puStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int *piStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b7bb;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0;
  if (param_2 == 0) {
    param_1[4] = 0;
    param_1[5] = 0xf;
    *(undefined *)param_1 = 0;
    return param_1;
  }
  uStack_48 = 0;
  puStack_44 = (undefined4 *)0x0;
  uStack_40 = 0;
  ExceptionList = &pvStack_10;
  puStack_44 = (undefined4 *)FUN_005e9aa0(0,0);
  uStack_3c = 0;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_8 = 1;
  uStack_48 = 0x3f800000;
  FUN_005cb500(8);
  iStack_68 = 0;
  uStack_64 = 0xf;
  uStack_78 = uStack_78 & 0xffffff00;
  piStack_7c = *(int **)(param_2 + 0xbc);
  if (piStack_7c != (int *)0x0) {
    LOCK();
    piStack_7c[1] = piStack_7c[1] + 1;
    UNLOCK();
    piStack_7c = *(int **)(param_2 + 0xbc);
  }
  piStack_80 = *(int **)(param_2 + 0xb8);
  uStack_8._1_3_ = 0;
  uVar5 = uStack_8._1_3_;
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  piStack_1c = piStack_7c;
  if (piStack_80 != (int *)0x0) {
    piVar12 = (int *)*piStack_80;
    piStack_28 = (int *)piStack_80[1];
    piStack_24 = piVar12;
    uVar5 = uStack_8._1_3_;
    if (piVar12 != piStack_28) {
      do {
        piStack_24 = piVar12;
        if (*piVar12 == 0) {
LAB_005ea162:
          puVar7 = &uStack_50;
          uVar9 = uStack_14 | 0x10;
          piStack_4c = (int *)0x0;
          iStack_20 = 0;
        }
        else {
          iVar10 = *(int *)(*piVar12 + 0xc);
          iVar6 = FUN_00913630();
          if ((uint)*(ushort *)(iVar6 + 0x1da) <
              (uint)*(ushort *)(iVar10 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))
          goto LAB_005ea162;
          piStack_54 = (int *)piVar12[1];
          iStack_20 = *piVar12;
          if (piStack_54 != (int *)0x0) {
            LOCK();
            piStack_54[1] = piStack_54[1] + 1;
            UNLOCK();
            piStack_54 = (int *)piVar12[1];
          }
          uVar9 = uStack_14 | 8;
          puVar7 = &uStack_58;
        }
        piVar12 = (int *)puVar7[1];
        uStack_18 = uVar9 | 0x20;
        *puVar7 = 0;
        puVar7[1] = 0;
        piVar2 = piStack_4c;
        iStack_88 = iStack_20;
        piStack_84 = piVar12;
        uStack_14 = uStack_18;
        if (((uVar9 & 0x10) != 0) &&
           (uStack_18 = uVar9 & 0xffffffef | 0x20, uStack_14 = uStack_18, piStack_4c != (int *)0x0))
        {
          LOCK();
          iVar10 = piStack_4c[1] + -1;
          piStack_4c[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piStack_4c)();
            LOCK();
            piVar1 = piVar2 + 2;
            iVar10 = *piVar1 + -1;
            *piVar1 = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        piVar2 = piStack_54;
        if (((uStack_14 & 8) != 0) &&
           (uStack_18 = uStack_14 & 0xfffffff7, uStack_14 = uStack_18, piStack_54 != (int *)0x0)) {
          LOCK();
          iVar10 = piStack_54[1] + -1;
          piStack_54[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piStack_54)();
            LOCK();
            piVar1 = piVar2 + 2;
            iVar10 = *piVar1 + -1;
            *piVar1 = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        uStack_8._0_1_ = 5;
        if (iStack_20 != 0) {
          uVar13 = FUN_00928340();
          uStack_60 = uVar13;
          FUN_005e5570(auStack_90,&uStack_60,param_2);
        }
        uStack_8._0_1_ = 4;
        if (piVar12 != (int *)0x0) {
          LOCK();
          iVar10 = piVar12[1] + -1;
          piVar12[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piVar12)();
            LOCK();
            iVar10 = piVar12[2] + -1;
            piVar12[2] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar12 + 4))();
            }
          }
        }
        piVar12 = piStack_24 + 2;
        piStack_24 = piVar12;
        uVar5 = uStack_8._1_3_;
      } while (piVar12 != piStack_28);
    }
  }
  uStack_8._1_3_ = uVar5;
  piVar12 = piStack_1c;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar10 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar2 = piVar12 + 2;
      iVar10 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar10 == 1) {
        (**(code **)(*piVar12 + 4))();
      }
    }
  }
  puVar7 = *(undefined4 **)(param_2 + 200);
  puVar4 = puStack_44;
  for (puVar8 = (undefined4 *)*puVar7; puStack_44 = puVar4, puVar8 != puVar7;
      puVar8 = (undefined4 *)*puVar8) {
    FUN_005e5570(auStack_90,puVar8 + 2,param_2);
    puVar4 = puStack_44;
  }
  puVar7 = (undefined4 *)*puVar4;
  do {
    if (puVar7 == puVar4) {
      param_1[4] = 0;
      param_1[5] = 0;
      *param_1 = uStack_78;
      param_1[1] = uStack_74;
      param_1[2] = uStack_70;
      param_1[3] = uStack_6c;
      *(ulonglong *)(param_1 + 4) = CONCAT44(uStack_64,iStack_68);
      FUN_005e61c0();
      ExceptionList = pvStack_10;
      return param_1;
    }
    if (iStack_68 == 0) {
      puVar8 = (undefined4 *)FUN_01675640(aiStack_c0,&DAT_018bed48,puVar7[2],puVar7[3]);
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      uStack_18 = uStack_14 | 2;
    }
    else {
      puVar8 = (undefined4 *)FUN_01675640(auStack_a8,",%lld",puVar7[2],puVar7[3]);
      uStack_8 = 7;
      uStack_18 = uStack_14 | 4;
    }
    puVar3 = puVar8 + 4;
    if (0xf < (uint)puVar8[5]) {
      puVar8 = (undefined4 *)*puVar8;
    }
    uStack_14 = uStack_18;
    FUN_00554150(puVar8,*puVar3);
    uStack_8 = 6;
    if ((uStack_14 & 4) != 0) {
      uStack_18 = uStack_14 & 0xfffffffb;
      uStack_14 = uStack_18;
      if (0xf < uStack_94) {
        uVar11 = uStack_94 + 1;
        uVar9 = auStack_a8[0];
        if (0xfff < uVar11) {
          uVar9 = *(uint *)(auStack_a8[0] - 4);
          uVar11 = uStack_94 + 0x24;
          if (0x1f < (auStack_a8[0] - uVar9) - 4) goto LAB_005ea44d;
        }
        FUN_01674ea0(uVar9,uVar11);
      }
      uStack_98 = 0;
      uStack_94 = 0xf;
      auStack_a8[0] = auStack_a8[0] & 0xffffff00;
    }
    uStack_8 = 3;
    if (((uStack_14 & 2) != 0) &&
       (uStack_18 = uStack_14 & 0xfffffffd, uStack_14 = uStack_18, 0xf < uStack_ac)) {
      uVar9 = uStack_ac + 1;
      iVar10 = aiStack_c0[0];
      if (0xfff < uVar9) {
        iVar10 = *(int *)(aiStack_c0[0] + -4);
        uVar9 = uStack_ac + 0x24;
        if (0x1f < (aiStack_c0[0] - iVar10) - 4U) {
LAB_005ea44d:
          uStack_18 = uStack_14;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar10,uVar9);
    }
    puVar7 = (undefined4 *)*puVar7;
  } while( true );
}



/* FUNCTION 5798 ; VA 0x005ea460 ; FUN_005ea460 */

void FUN_005ea460(int *param_1)

{
  uint uVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792078;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)*param_1;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)((uVar1 & 0xfffffffe) + 4))((uint *)*param_1 + 2);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0054fda0();
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar2);
}



/* FUNCTION 5799 ; VA 0x005ea4c0 ; FUN_005ea4c0 */

void FUN_005ea4c0(int *param_1)

{
  FUN_0054ef60(*param_1 + 0x20);
  FUN_005e65e0();
  return;
}



/* FUNCTION 5800 ; VA 0x005ea4f0 ; FUN_005ea4f0 */

void FUN_005ea4f0(int *param_1,int *param_2,int param_3)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b7df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar4 = *param_1;
      ExceptionList = &pvStack_10;
      iVar3 = FUN_01674e20(0x20);
      uStack_8 = 0;
      if (iVar3 != 0) {
        iVar4 = FUN_005e5f00(iVar4);
        *param_2 = iVar4;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      puVar1 = (uint *)*param_2;
      if (puVar1 != (uint *)0x0) {
        uVar2 = *puVar1;
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(puVar1 + 2,puVar1 + 2,2);
            }
          }
          *puVar1 = 0;
        }
        FUN_01674ea0(puVar1,0x20);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1d9566c);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_b44e4370a68cf5c524e66584e5d7fc02>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 5801 ; VA 0x005ea660 ; FUN_005ea660 */

void FUN_005ea660(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b7ff;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x38);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_005e5f60(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_005e6120();
        FUN_01674ea0(iVar2,0x38);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1d95634);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_f6592b4d62f4ac86587c3fd7d6fcf1d7>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 5802 ; VA 0x005ea7b0 ; FUN_005ea7b0 */

void __fastcall FUN_005ea7b0(int param_1)

{
  int *piVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(param_1 + 200);
  uStack_8 = 0;
  piVar2 = (int *)*piVar1;
  ExceptionList = &pvStack_10;
  *piVar1 = (int)piVar1;
  *(int *)(*(int *)(param_1 + 200) + 4) = *(int *)(param_1 + 200);
  *(undefined4 *)(param_1 + 0xcc) = 0;
  if (piVar2 != *(int **)(param_1 + 200)) {
    do {
      piVar1 = (int *)*piVar2;
      FUN_01674ea0(piVar2,0x10);
      piVar2 = piVar1;
    } while (piVar1 != (int *)*(int *)(param_1 + 200));
  }
  FUN_005cb500(8);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5803 ; VA 0x005ea820 ; FUN_005ea820 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_005ea820(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea93d0) {
    FUN_016f3809(&DAT_01ea93d0);
    if (DAT_01ea93d0 == -1) {
      _DAT_01ea93c4 = FUN_0057bbb0;
      _DAT_01ea93c8 = FUN_005880a0;
      DAT_01ea93cc = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ea93d0);
    }
  }
  return &DAT_01ea93c4;
}



/* FUNCTION 5804 ; VA 0x005ea890 ; FUN_005ea890 */

undefined4 FUN_005ea890(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_005ea8b0(param_1,0,param_2,param_3,1);
  return param_1;
}



/* FUNCTION 5805 ; VA 0x005ea8b0 ; FUN_005ea8b0 */

undefined8 * __thiscall
FUN_005ea8b0(int param_1,undefined8 *param_2,uint param_3,int param_4,int param_5,undefined4 param_6
            )

{
  undefined4 *****pppppuVar1;
  int iVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  undefined4 ****ppppuVar5;
  char cVar6;
  undefined uVar7;
  int iVar8;
  undefined4 *****pppppuVar9;
  char *pcVar10;
  undefined **ppuVar11;
  undefined4 *puVar12;
  int iVar13;
  undefined4 uVar14;
  undefined4 *puVar15;
  int *piVar16;
  undefined **ppuVar17;
  undefined4 ****ppppuVar18;
  uint uVar19;
  uint uVar20;
  undefined4 uVar21;
  uint uVar22;
  undefined *puVar23;
  undefined auStack_238 [4];
  int iStack_234;
  undefined auStack_230 [80];
  undefined auStack_1e0 [120];
  undefined auStack_168 [16];
  undefined4 uStack_158;
  undefined4 uStack_154;
  undefined4 ***pppuStack_150;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined4 uStack_144;
  undefined8 uStack_140;
  undefined auStack_138 [8];
  undefined4 ****appppuStack_130 [4];
  undefined4 uStack_120;
  uint uStack_11c;
  int iStack_118;
  undefined4 ****ppppuStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined8 uStack_104;
  undefined auStack_fc [16];
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 ****ppppuStack_e4;
  undefined4 ***pppuStack_e0;
  undefined4 ***pppuStack_dc;
  undefined4 ***pppuStack_d8;
  undefined8 uStack_d4;
  undefined4 ****appppuStack_cc [4];
  undefined4 uStack_bc;
  uint uStack_b8;
  undefined auStack_b4 [24];
  int iStack_9c;
  uint auStack_98 [3];
  undefined auStack_8c [4];
  undefined4 uStack_88;
  uint uStack_84;
  int aiStack_80 [2];
  int iStack_78;
  undefined4 ****ppppuStack_74;
  undefined *puStack_70;
  undefined8 uStack_6c;
  undefined4 uStack_64;
  uint uStack_60;
  int *piStack_5c;
  undefined4 *puStack_58;
  int iStack_54;
  int aiStack_50 [2];
  char cStack_45;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  undefined uStack_29;
  undefined4 ****ppppuStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ba8a;
  pvStack_10 = ExceptionList;
  uVar22 = -(uint)(param_1 != 0) & param_1 + 0xcU;
  ExceptionList = &pvStack_10;
  iStack_54 = param_1;
  iVar8 = FUN_005e5c70(uVar22);
  iStack_118 = iVar8;
  if (DAT_01d59a78 != '\0') {
    uStack_18 = 0xf00000000;
    ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
    FUN_005542c0("TeamCreate.Publish.Attempt",0x1a);
    uStack_8 = 0;
    FUN_008783f0(&ppppuStack_28,1,0);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_18._4_4_) {
      uVar19 = uStack_18._4_4_ + 1;
      ppppuVar18 = ppppuStack_28;
      if (0xfff < uVar19) {
        ppppuVar18 = (undefined4 ****)ppppuStack_28[-1];
        uVar19 = uStack_18._4_4_ + 0x24;
        if (0x1f < (uint)((int)ppppuStack_28 + (-4 - (int)ppppuVar18))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar18,uVar19);
    }
  }
  if ((iVar8 != 0) && ((char)param_3 != '\0')) {
    if (DAT_01d65cf0 == '\0') {
      cVar6 = FUN_00a161b0(iStack_54);
      if (cVar6 != '\0') {
        uStack_18 = 0xf00000000;
        ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
        FUN_005542c0("Error: Cannot publish place to Roblox while there are packages with unpublished changes."
                     ,0x58);
        uStack_8 = 3;
        FUN_0098c2c0(3,&ppppuStack_28);
        uStack_8 = 0xffffffff;
        FUN_005507b0();
        uStack_18 = 0xf00000000;
        ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
        FUN_005542c0("CloudEditAbortPublishDueToUnpublishedPackage",0x2c);
        uStack_8 = 4;
        FUN_008783f0(&ppppuStack_28,1,0);
        uStack_8 = 0xffffffff;
        FUN_005507b0();
        FUN_0087c450("Studio","PlacePublishBlockedByPackage","PublishBlockedByUnverifiedPackage",0,0
                     ,0);
        *param_2 = 0;
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    else {
      cVar6 = FUN_00a16240();
      if ((cVar6 != '\0') &&
         (puStack_58 = (undefined4 *)FUN_005e5bb0(uVar22), puStack_58 != (undefined4 *)0x0)) {
        FUN_00a15e60(auStack_8c,iStack_54);
        uStack_8 = 1;
        cVar6 = FUN_00a155c0(puStack_58,auStack_8c,1);
        iStack_78 = CONCAT31(iStack_78._1_3_,cVar6);
        if (DAT_01d65cf8 != '\0') {
          FUN_00a19180(puStack_58,iStack_78,auStack_8c);
          cVar6 = (char)iStack_78;
        }
        if (cVar6 != '\0') {
          uStack_18 = 0xf00000000;
          ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
          FUN_005542c0("Error: There are one or more packages preventing this place from being published. Please try again."
                       ,99);
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          FUN_0098c2c0(3,&ppppuStack_28);
          FUN_005507b0();
          *(undefined4 *)param_2 = 0;
          *(undefined *)((int)param_2 + 4) = 1;
          FUN_005e6280();
          ExceptionList = pvStack_10;
          return param_2;
        }
        uStack_8 = 0xffffffff;
        FUN_005e6280();
      }
    }
  }
  if ((((DAT_01d65cf0 == '\0') && (iVar8 != 0)) && ((char)param_3 != '\0')) &&
     (cVar6 = FUN_00a16240(iStack_54), cVar6 != '\0')) {
    FUN_0087c450("Studio","PlacePublishBlockedByPackage",
                 "PublishWasNotBlockedByPendingOrModifiedPackages",0,0,0);
  }
  piVar16 = *(int **)(iStack_54 + 0x43c);
  FUN_00a19ae0(*piVar16 - (int)piVar16,piVar16[1] - (int)piVar16,iStack_54);
  uStack_104._0_4_ = 0;
  uStack_104._4_4_ = 0xf;
  ppppuStack_114 = (undefined4 ****)((uint)ppppuStack_114 & 0xffffff00);
  uStack_140 = 0xf00000000;
  pppuStack_150 = (undefined4 ***)((uint)pppuStack_150 & 0xffffff00);
  uStack_d4 = 0xf00000000;
  ppppuStack_e4 = (undefined4 ****)((uint)ppppuStack_e4 & 0xffffff00);
  uStack_8 = 7;
  FUN_00a24b20(&ppppuStack_114,uVar22,0,0);
  pppppuVar9 = &ppppuStack_114;
  if (0xf < uStack_104._4_4_) {
    pppppuVar9 = (undefined4 *****)ppppuStack_114;
  }
  pppppuVar9 = (undefined4 *****)FUN_01531190(auStack_44,pppppuVar9,(undefined4)uStack_104);
  if (&ppppuStack_e4 != pppppuVar9) {
    FUN_005507b0();
    ppppuStack_e4 = *pppppuVar9;
    pppuStack_e0 = pppppuVar9[1];
    pppuStack_dc = pppppuVar9[2];
    pppuStack_d8 = pppppuVar9[3];
    uStack_d4 = *(undefined8 *)(pppppuVar9 + 4);
    pppppuVar9[4] = (undefined4 ****)0x0;
    pppppuVar9[5] = (undefined4 ****)0xf;
    *(undefined *)pppppuVar9 = 0;
  }
  if (0xf < uStack_30) {
    uVar19 = uStack_30 + 1;
    uVar22 = auStack_44[0];
    if (0xfff < uVar19) {
      uVar22 = *(uint *)(auStack_44[0] - 4);
      uVar19 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar22) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar22,uVar19);
  }
  pppppuVar9 = &ppppuStack_114;
  if (0xf < uStack_104._4_4_) {
    pppppuVar9 = (undefined4 *****)ppppuStack_114;
  }
  FUN_005c39d0(pppppuVar9,(undefined4)uStack_104,&pppuStack_150,param_3);
  uVar3 = uStack_1c;
  uVar21 = uStack_20;
  uVar14 = uStack_24;
  uVar22 = uStack_104._4_4_;
  ppppuVar18 = ppppuStack_114;
  ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
  ppppuVar5 = ppppuStack_28;
  ppppuStack_28 = ppppuStack_114;
  uStack_24 = uStack_110;
  uStack_20 = uStack_10c;
  uStack_1c = uStack_108;
  uStack_18._0_4_ = (undefined4)uStack_104;
  uStack_18._4_4_ = uStack_104._4_4_;
  uStack_104 = 0xf00000000;
  ppppuStack_114 = ppppuVar5;
  uStack_110 = uVar14;
  uStack_10c = uVar21;
  uStack_108 = uVar3;
  if (0xf < uVar22) {
    uVar19 = uVar22 + 1;
    pppppuVar9 = (undefined4 *****)ppppuVar18;
    if (0xfff < uVar19) {
      pppppuVar9 = (undefined4 *****)ppppuVar18[-1];
      uVar19 = uVar22 + 0x24;
      if (0x1f < (uint)((int)ppppuVar18 + (-4 - (int)pppppuVar9))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar9,uVar19);
  }
  if (DAT_01ea937d != '\0') {
    pcVar10 = "Publishing";
    pppppuVar9 = &ppppuStack_e4;
    if (0xf < uStack_d4._4_4_) {
      pppppuVar9 = (undefined4 *****)ppppuStack_e4;
    }
    puVar12 = &DAT_01d79c80;
    if (0xf < DAT_01d79c94) {
      puVar12 = DAT_01d79c80;
    }
    if ((char)param_3 == '\0') {
      pcVar10 = "Saving";
    }
    FUN_01677520(DAT_01ea937d,"%s place (placeID = %s) with hash: %s",pcVar10,puVar12,pppppuVar9);
  }
  if (DAT_01d64710 != '\0') {
    ppppuStack_74 = (undefined4 ****)((uint)ppppuStack_74 & 0xffffff00);
    puStack_58 = (undefined4 *)0xb;
    ppuVar11 = (undefined **)
               FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_58);
    ppuVar17 = ppuVar11 + -1;
    if (ppuVar11 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar17 = ppuVar11;
    }
    puStack_70 = *ppuVar17;
    uStack_6c._0_4_ = (undefined4 *)0x0;
    uStack_6c._4_4_ = 0x3f800000;
    uStack_64 = 0;
    uStack_60 = 0;
    uStack_8._0_1_ = 8;
    puVar12 = (undefined4 *)FUN_0152fd20(auStack_44);
    uStack_8._0_1_ = 9;
    uStack_88 = 0;
    uStack_84 = 0xf;
    auStack_98[0] = auStack_98[0] & 0xffffff00;
    FUN_005542c0("device",6);
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    iVar13 = FUN_005d15d0(auStack_98);
    puStack_58 = (undefined4 *)(iVar13 + 0x18);
    if (puStack_58 != puVar12) {
      FUN_005507b0();
      uVar14 = puVar12[1];
      uVar21 = puVar12[2];
      uVar3 = puVar12[3];
      *puStack_58 = *puVar12;
      puStack_58[1] = uVar14;
      puStack_58[2] = uVar21;
      puStack_58[3] = uVar3;
      *(undefined8 *)(puStack_58 + 4) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    uStack_8._0_1_ = 9;
    if (0xf < uStack_84) {
      uVar19 = uStack_84 + 1;
      uVar22 = auStack_98[0];
      if (0xfff < uVar19) {
        uVar22 = *(uint *)(auStack_98[0] - 4);
        uVar19 = uStack_84 + 0x24;
        if (0x1f < (auStack_98[0] - uVar22) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar22,uVar19);
    }
    uStack_88 = 0;
    uStack_84 = 0xf;
    auStack_98[0] = auStack_98[0] & 0xffffff00;
    uStack_8._0_1_ = 8;
    uVar7 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (0xf < uStack_30) {
      uVar19 = uStack_30 + 1;
      uVar22 = auStack_44[0];
      if (0xfff < uVar19) {
        uVar22 = *(uint *)(auStack_44[0] - 4);
        uVar19 = uStack_30 + 0x24;
        if (0x1f < (auStack_44[0] - uVar22) - 4) {
          uStack_8._0_1_ = uVar7;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar22,uVar19);
    }
    uStack_18 = 0xf00000000;
    ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
    FUN_005542c0("RobloxPlaceIdHeader",0x13);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    puVar12 = (undefined4 *)FUN_005d15d0(&ppppuStack_28);
    if ((undefined4 **)puVar12 != &DAT_01d79c68) {
      puVar12 = &DAT_01d79c80;
      if (0xf < DAT_01d79c94) {
        puVar12 = DAT_01d79c80;
      }
      FUN_005542c0(puVar12,DAT_01d79c90);
    }
    uStack_8._0_1_ = 8;
    if (0xf < uStack_18._4_4_) {
      uVar22 = uStack_18._4_4_ + 1;
      ppppuVar18 = ppppuStack_28;
      if (0xfff < uVar22) {
        ppppuVar18 = (undefined4 ****)ppppuStack_28[-1];
        uVar22 = uStack_18._4_4_ + 0x24;
        if (0x1f < (uint)((int)ppppuStack_28 + (-4 - (int)ppppuVar18))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar18,uVar22);
    }
    uStack_18 = 0xf00000000;
    ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
    FUN_005542c0("RobloxGameIdHeader",0x12);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    puVar12 = (undefined4 *)FUN_005d15d0(&ppppuStack_28);
    if (puVar12 != &DAT_01d79c50) {
      puVar12 = &DAT_01d79c68;
      if (0xf < DAT_01d79c7c) {
        puVar12 = DAT_01d79c68;
      }
      FUN_005542c0(puVar12,DAT_01d79c78);
    }
    uStack_8._0_1_ = 8;
    if (0xf < uStack_18._4_4_) {
      uVar22 = uStack_18._4_4_ + 1;
      ppppuVar18 = ppppuStack_28;
      if (0xfff < uVar22) {
        ppppuVar18 = (undefined4 ****)ppppuStack_28[-1];
        uVar22 = uStack_18._4_4_ + 0x24;
        if (0x1f < (uint)((int)ppppuStack_28 + (-4 - (int)ppppuVar18))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar18,uVar22);
    }
    uStack_18 = 0xf00000000;
    uVar22 = 4;
    if ((uint)uStack_d4 < 4) {
      uVar22 = (uint)uStack_d4;
    }
    pppppuVar9 = &ppppuStack_e4;
    if (0xf < uStack_d4._4_4_) {
      pppppuVar9 = (undefined4 *****)ppppuStack_e4;
    }
    ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
    FUN_005542c0(pppppuVar9,uVar22);
    uStack_8._0_1_ = 0xd;
    uStack_88 = 0;
    uStack_84 = 0xf;
    auStack_98[0] = auStack_98[0] & 0xffffff00;
    FUN_005542c0("md5FirstSixteenBits",0x13);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
    iVar13 = FUN_005d15d0(auStack_98);
    if ((undefined4 *****)(iVar13 + 0x18) == &ppppuStack_28) {
      uVar22 = uStack_18._4_4_;
    }
    else {
      FUN_005507b0();
      ppppuVar18 = ppppuStack_28;
      ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
      *(undefined4 *****)(iVar13 + 0x18) = ppppuVar18;
      *(undefined4 *)(iVar13 + 0x1c) = uStack_24;
      *(undefined4 *)(iVar13 + 0x20) = uStack_20;
      *(undefined4 *)(iVar13 + 0x24) = uStack_1c;
      *(undefined8 *)(iVar13 + 0x28) = uStack_18;
      uVar22 = 0xf;
    }
    uStack_8._0_1_ = 0xd;
    if (0xf < uStack_84) {
      uVar20 = uStack_84 + 1;
      uVar19 = auStack_98[0];
      if (0xfff < uVar20) {
        uVar19 = *(uint *)(auStack_98[0] - 4);
        uVar20 = uStack_84 + 0x24;
        if (0x1f < (auStack_98[0] - uVar19) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar19,uVar20);
    }
    uStack_88 = 0;
    uStack_84 = 0xf;
    auStack_98[0] = auStack_98[0] & 0xffffff00;
    uStack_8._0_1_ = 8;
    uVar7 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (0xf < uVar22) {
      uVar19 = uVar22 + 1;
      ppppuVar18 = ppppuStack_28;
      if (0xfff < uVar19) {
        ppppuVar18 = (undefined4 ****)ppppuStack_28[-1];
        uVar19 = uVar22 + 0x24;
        if (0x1f < (uint)((int)ppppuStack_28 + (-4 - (int)ppppuVar18))) {
          uStack_8._0_1_ = uVar7;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar18,uVar19);
    }
    puVar12 = (undefined4 *)FUN_009ee570(auStack_44,&param_3);
    uStack_8._0_1_ = 0xf;
    uStack_18 = 0xf00000000;
    ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
    FUN_005542c0("isPublish",9);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
    iVar13 = FUN_005d15d0(&ppppuStack_28);
    puStack_58 = (undefined4 *)(iVar13 + 0x18);
    if (puStack_58 != puVar12) {
      FUN_005507b0();
      uVar14 = puVar12[1];
      uVar21 = puVar12[2];
      uVar3 = puVar12[3];
      *puStack_58 = *puVar12;
      puStack_58[1] = uVar14;
      puStack_58[2] = uVar21;
      puStack_58[3] = uVar3;
      *(undefined8 *)(puStack_58 + 4) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    uStack_8._0_1_ = 0xf;
    if (0xf < uStack_18._4_4_) {
      uVar22 = uStack_18._4_4_ + 1;
      ppppuVar18 = ppppuStack_28;
      if (0xfff < uVar22) {
        ppppuVar18 = (undefined4 ****)ppppuStack_28[-1];
        uVar22 = uStack_18._4_4_ + 0x24;
        if (0x1f < (uint)((int)ppppuStack_28 + (-4 - (int)ppppuVar18))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar18,uVar22);
    }
    uStack_18 = 0xf00000000;
    ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
    uStack_8._0_1_ = 8;
    uVar7 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (0xf < uStack_30) {
      uVar19 = uStack_30 + 1;
      uVar22 = auStack_44[0];
      if (0xfff < uVar19) {
        uVar22 = *(uint *)(auStack_44[0] - 4);
        uVar19 = uStack_30 + 0x24;
        if (0x1f < (auStack_44[0] - uVar22) - 4) {
          uStack_8._0_1_ = uVar7;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar22,uVar19);
    }
    puVar12 = (undefined4 *)FUN_01675640(auStack_44,&DAT_018bed48,param_4,param_5);
    uStack_8._0_1_ = 0x11;
    uStack_18 = 0xf00000000;
    ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
    FUN_005542c0("userid",6);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
    iVar13 = FUN_005d15d0(&ppppuStack_28);
    puStack_58 = (undefined4 *)(iVar13 + 0x18);
    if (puStack_58 != puVar12) {
      FUN_005507b0();
      uVar14 = puVar12[1];
      uVar21 = puVar12[2];
      uVar3 = puVar12[3];
      *puStack_58 = *puVar12;
      puStack_58[1] = uVar14;
      puStack_58[2] = uVar21;
      puStack_58[3] = uVar3;
      *(undefined8 *)(puStack_58 + 4) = *(undefined8 *)(puVar12 + 4);
      puVar12[4] = 0;
      puVar12[5] = 0xf;
      *(undefined *)puVar12 = 0;
    }
    uStack_8._0_1_ = 0x11;
    if (0xf < uStack_18._4_4_) {
      uVar22 = uStack_18._4_4_ + 1;
      ppppuVar18 = ppppuStack_28;
      if (0xfff < uVar22) {
        ppppuVar18 = (undefined4 ****)ppppuStack_28[-1];
        uVar22 = uStack_18._4_4_ + 0x24;
        if (0x1f < (uint)((int)ppppuStack_28 + (-4 - (int)ppppuVar18))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar18,uVar22);
    }
    uStack_18 = 0xf00000000;
    ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
    uStack_8._0_1_ = 8;
    uVar7 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (0xf < uStack_30) {
      uVar19 = uStack_30 + 1;
      uVar22 = auStack_44[0];
      if (0xfff < uVar19) {
        uVar22 = *(uint *)(auStack_44[0] - 4);
        uVar19 = uStack_30 + 0x24;
        if (0x1f < (auStack_44[0] - uVar22) - 4) {
          uStack_8._0_1_ = uVar7;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar22,uVar19);
    }
    uStack_bc = 0;
    uStack_b8 = 0xf;
    appppuStack_cc[0] = (undefined4 ****)((uint)appppuStack_cc[0] & 0xffffff00);
    FUN_005542c0("BlockingSaveOrPublish",0x15);
    uStack_8._0_1_ = 0x13;
    uStack_88 = 0;
    uStack_84 = 0xf;
    auStack_98[0] = auStack_98[0] & 0xffffff00;
    FUN_005542c0("TeamCreate",10);
    uStack_8._0_1_ = 0x14;
    uStack_18._0_4_ = 0;
    uStack_18._4_4_ = 0xf;
    ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
    FUN_005542c0(&DAT_018bde9c,3);
    uStack_8._0_1_ = 0x15;
    FUN_00879580(&ppppuStack_28,auStack_98,appppuStack_cc,&ppppuStack_74);
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_0056cfd0();
  }
  if (DAT_01ea937e != '\0') {
    uVar22 = 4;
    if ((uint)uStack_d4 < 4) {
      uVar22 = (uint)uStack_d4;
    }
    pppppuVar9 = &ppppuStack_e4;
    if (0xf < uStack_d4._4_4_) {
      pppppuVar9 = (undefined4 *****)ppppuStack_e4;
    }
    uStack_18._0_4_ = 0;
    uStack_18._4_4_ = 0xf;
    ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
    FUN_005542c0(pppppuVar9,uVar22);
    pppppuVar9 = &ppppuStack_28;
    if (0xf < uStack_18._4_4_) {
      pppppuVar9 = (undefined4 *****)ppppuStack_28;
    }
    puVar12 = &DAT_01d79c68;
    if (0xf < DAT_01d79c7c) {
      puVar12 = DAT_01d79c68;
    }
    puVar15 = &DAT_01d79c80;
    if (0xf < DAT_01d79c94) {
      puVar15 = DAT_01d79c80;
    }
    uStack_8._0_1_ = 0x16;
    FUN_01677520(DAT_01ea937e,
                 "TeamCreate BlockingSaveOrPublish Roblox-Place-Id: [%s] Roblox-Game-Id: [%s] isPublish: [%d] first 16 bits of md5: [%s] authorId: [%lld]"
                 ,puVar15,puVar12,param_3 & 0xff,pppppuVar9,param_4,param_5);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_005507b0();
  }
  if ((DAT_01d658cc < 1) || (cStack_45 = '\x01', DAT_01d658f8 < DAT_01d658cc)) {
    cStack_45 = '\0';
  }
  iStack_9c = FUN_01674e20(0x18);
  if (iStack_9c == 0) {
    uVar14 = 0;
  }
  else {
    uVar14 = FUN_005693e0(0xb,&uStack_29,&uStack_29,&uStack_29);
  }
  uStack_88 = 0;
  uStack_84 = 0;
  FUN_005c1af0(uVar14,param_3);
  uStack_29 = (char)param_3 == '\0';
  puVar23 = &uStack_29;
  uStack_8._0_1_ = 0x17;
  FUN_005c4c00(&DAT_01d59a08);
  FUN_005e52b0(puVar23);
  ppppuVar18 = &pppuStack_150;
  FUN_005c4c00(&DAT_01d59a38);
  FUN_005c16d0(ppppuVar18);
  pppppuVar9 = &ppppuStack_e4;
  FUN_005c4c00(&DAT_01d59a50);
  FUN_005c16d0(pppppuVar9);
  uVar3 = uStack_1c;
  uVar21 = uStack_20;
  uVar14 = uStack_24;
  ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
  ppppuVar18 = ppppuStack_28;
  ppppuStack_28 = (undefined4 ****)pppuStack_150;
  uStack_24 = uStack_14c;
  uStack_20 = uStack_148;
  uStack_1c = uStack_144;
  uStack_18 = uStack_140;
  pppuStack_150 = ppppuVar18;
  uStack_14c = uVar14;
  uStack_148 = uVar21;
  uStack_144 = uVar3;
  uStack_140 = 0xf00000000;
  FUN_005507b0();
  uStack_158 = 0;
  uStack_154 = 0xf;
  auStack_168[0] = 0;
  uStack_8._0_1_ = 0x18;
  FUN_005e4d60(&uStack_88);
  uStack_8._0_1_ = 0x19;
  FUN_0098fc00(auStack_238,auStack_168,1);
  uStack_8._0_1_ = 0x1a;
  if (iStack_234 != 0) {
    (**(code **)(iStack_234 + 8))(auStack_230);
  }
  iVar13 = iStack_54;
  uStack_120 = 0;
  uVar7 = DAT_01d65a38;
  if (cStack_45 != '\0') {
    uVar7 = 0;
  }
  uStack_11c = 0xf;
  iStack_9c = CONCAT31(iStack_9c._1_3_,uVar7);
  appppuStack_130[0] = (undefined4 ****)((uint)appppuStack_130[0] & 0xffffff00);
  uStack_8._0_1_ = 0x1b;
  uVar7 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x1b;
  if (cStack_45 == '\0') {
    piVar16 = *(int **)(iStack_54 + 0x43c);
    uStack_8._0_1_ = uVar7;
    pppppuVar9 = (undefined4 *****)
                 FUN_00a27b10(auStack_b4,*piVar16 - (int)piVar16,piVar16[1] - (int)piVar16);
    uStack_8._0_1_ = 0x22;
    if (appppuStack_130 != pppppuVar9) {
      pppppuVar1 = pppppuVar9 + 4;
      if ((undefined4 ****)0xf < pppppuVar9[5]) {
        pppppuVar9 = (undefined4 *****)*pppppuVar9;
      }
      FUN_005542c0(pppppuVar9,*pppppuVar1);
    }
    uStack_8._0_1_ = 0x1b;
    FUN_005507b0();
  }
  else {
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = auStack_44[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 0x1c;
    uStack_ec = 0;
    uStack_e8 = 0xf;
    auStack_fc[0] = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 0x1d;
    uStack_64 = 0;
    uStack_60 = 0xf;
    ppppuStack_74 = (undefined4 ****)((uint)ppppuStack_74 & 0xffffff00);
    FUN_005542c0("/publish-mock/v1/Places/200",0x1b);
    uStack_8._0_1_ = 0x1e;
    uStack_18 = 0xf00000000;
    ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
    FUN_005542c0("apis.simulpong.com",0x12);
    uStack_8._0_1_ = 0x1f;
    uStack_bc = 0;
    uStack_b8 = 0xf;
    appppuStack_cc[0] = (undefined4 ****)((uint)appppuStack_cc[0] & 0xffffff00);
    FUN_005542c0(&DAT_018c71bc,4);
    uStack_8._0_1_ = 0x20;
    FUN_0151bcc0(auStack_1e0,appppuStack_cc,&ppppuStack_28,&ppppuStack_74,auStack_fc,auStack_44);
    uStack_8._0_1_ = 0x21;
    uVar14 = FUN_0151bb70(auStack_b4);
    FUN_005511f0(uVar14);
    FUN_005507b0();
    FUN_0056d9d0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    uStack_8._0_1_ = 0x1b;
    FUN_005507b0();
    iVar13 = iStack_54;
  }
  uStack_6c._0_4_ = (undefined4 *)0x0;
  uStack_6c._4_4_ = 0;
  uStack_6c = 0;
  uVar4 = 0;
  uStack_64 = 0;
  uStack_60 = 0;
  if (param_4 == 0 && param_5 == 0) {
    if (*(int *)(iVar13 + 0x458) != 0) {
      if (iVar8 != 0) {
        FUN_005d57a0(&piStack_5c);
        uStack_8._0_1_ = 0x23;
        uStack_6c = CONCAT44(uStack_6c._4_4_,(undefined4 *)uStack_6c);
        if ((piStack_5c != (int *)0x0) &&
           (uStack_6c = CONCAT44(uStack_6c._4_4_,(undefined4 *)uStack_6c),
           *piStack_5c != piStack_5c[1])) {
          FUN_00562c90(aiStack_50,*piStack_5c);
          uStack_8._0_1_ = 0x24;
          if (aiStack_50[0] != 0) {
            uStack_6c = FUN_00928340();
            uStack_64 = CONCAT31(uStack_64._1_3_,1);
          }
          FUN_00550b30();
        }
        uStack_8._0_1_ = 0x1b;
        FUN_00550b30();
        uVar4 = uStack_6c;
        goto LAB_005eb930;
      }
      goto LAB_005ec349;
    }
    piVar16 = *(int **)(iVar13 + 0x454);
    puStack_58 = (undefined4 *)(*piVar16 - (int)piVar16);
    iStack_78 = piVar16[1] - (int)piVar16;
  }
  else {
    uStack_64 = 1;
    uStack_60 = 0;
    uVar4 = CONCAT44(param_5,param_4);
LAB_005eb930:
    uStack_6c._4_4_ = (int)((ulonglong)uVar4 >> 0x20);
    uStack_6c._0_4_ = (undefined4 *)uVar4;
    if ((char)uStack_64 == '\0') {
LAB_005ec349:
      *param_2 = 0;
      goto LAB_005ec353;
    }
    iStack_78 = uStack_6c._4_4_;
    puStack_58 = (undefined4 *)uStack_6c;
    uStack_6c = uVar4;
  }
  FUN_014c9d60(aiStack_80,0);
  pppppuVar9 = appppuStack_130;
  if (0xf < uStack_11c) {
    pppppuVar9 = (undefined4 *****)appppuStack_130[0];
  }
  uStack_8._0_1_ = 0x25;
  FUN_014cbbc0(pppppuVar9,uStack_120);
  *(undefined4 *)(aiStack_80[0] + 0xb0) = 0;
  puVar12 = &DAT_01d79f98;
  if (0xf < DAT_01d79fac) {
    puVar12 = DAT_01d79f98;
  }
  puVar15 = &DAT_01d79d70;
  if (0xf < DAT_01d79d84) {
    puVar15 = DAT_01d79d70;
  }
  FUN_014cb8a0(puVar15,DAT_01d79d80,puVar12,DAT_01d79fa8);
  puVar12 = (undefined4 *)FUN_01675640(auStack_b4,&DAT_018bed48,puStack_58,iStack_78);
  if ((char)param_6 == '\0') {
    uVar14 = puVar12[4];
    uStack_8._0_1_ = 0x27;
    if (0xf < (uint)puVar12[5]) {
      puVar12 = (undefined4 *)*puVar12;
    }
    puVar15 = &DAT_01d79f08;
    uVar21 = DAT_01d79f18;
    if (0xf < DAT_01d79f1c) {
      puVar15 = DAT_01d79f08;
    }
  }
  else {
    uVar14 = puVar12[4];
    uStack_8._0_1_ = 0x26;
    if (0xf < (uint)puVar12[5]) {
      puVar12 = (undefined4 *)*puVar12;
    }
    puVar15 = &DAT_01d79f20;
    uVar21 = DAT_01d79f30;
    if (0xf < DAT_01d79f34) {
      puVar15 = DAT_01d79f20;
    }
  }
  FUN_014cb8a0(puVar15,uVar21,puVar12,uVar14);
  uStack_8._0_1_ = 0x25;
  FUN_005507b0();
  FUN_014cba10(&DAT_018c88a0,3);
  FUN_014cb780(auStack_168,iStack_9c);
  iVar8 = iStack_118;
  if (DAT_01d64710 != '\0') {
    puVar15 = (undefined4 *)FUN_01675640(auStack_b4,&DAT_018bed48,param_4,param_5);
    puVar12 = puVar15 + 4;
    uStack_8._0_1_ = 0x28;
    if (0xf < (uint)puVar15[5]) {
      puVar15 = (undefined4 *)*puVar15;
    }
    FUN_014cb8a0("X-Roblox-Author-ID",0x12,puVar15,*puVar12);
    uStack_8._0_1_ = 0x25;
    FUN_005507b0();
    iVar8 = iStack_118;
    puVar15 = (undefined4 *)FUN_005ea020(auStack_b4,iStack_118);
    puVar12 = puVar15 + 4;
    uStack_8._0_1_ = 0x29;
    if (0xf < (uint)puVar15[5]) {
      puVar15 = (undefined4 *)*puVar15;
    }
    FUN_014cb8a0("X-Roblox-Players-Log",0x14,puVar15,*puVar12);
    uStack_8._0_1_ = 0x25;
    FUN_005507b0();
  }
  FUN_014cb340(auStack_138);
  uStack_8._0_1_ = 0x2a;
  piVar16 = (int *)FUN_005e9fc0();
  uStack_64 = 0;
  uStack_60 = 0xf;
  ppppuStack_74 = (undefined4 ****)((uint)ppppuStack_74 & 0xffffff00);
  iVar13 = *piVar16;
  uStack_8._0_1_ = 0x2b;
  uVar7 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x2b;
  if (*(int *)(iVar13 + 0x70) == 0) {
    iVar2 = *(int *)(iVar13 + 0xc);
    if ((99 < iVar2 - 200U) || (iVar2 == 0xca)) {
      piVar16 = (int *)(iVar13 + 0x10);
      if (0xf < *(uint *)(iVar13 + 0x24)) {
        piVar16 = (int *)*piVar16;
      }
      uStack_8._0_1_ = uVar7;
      uVar14 = FUN_01675640(auStack_b4,"HTTP (%d): %s",iVar2,piVar16);
      FUN_005511f0(uVar14);
      goto LAB_005ebda0;
    }
    aiStack_50[0] = 0;
    aiStack_50[1] = 0;
    uStack_8._0_1_ = 0x2d;
    cVar6 = FUN_0098f070(iVar13 + 0x40,aiStack_50,0);
    if (cVar6 == '\0') {
      uVar14 = FUN_005543f0();
      pcVar10 = "can\'t parse JSON response: `%s`";
LAB_005ebd45:
      uVar14 = FUN_01675640(auStack_b4,pcVar10,uVar14);
      FUN_005511f0(uVar14);
      FUN_005507b0();
      uStack_8._0_1_ = 0x2b;
      FUN_00550b30();
      goto LAB_005ebdab;
    }
    FUN_00580040(&iStack_9c,&DAT_01d599f0);
    if (iStack_9c == 0) {
      uVar14 = FUN_005543f0();
      pcVar10 = "saved place version number is missing: `%s`";
      goto LAB_005ebd45;
    }
    puVar12 = (undefined4 *)FUN_0055d5e0();
    param_5 = CONCAT31(param_5._1_3_,1);
    uVar14 = *puVar12;
    if (iVar8 != 0) {
      FUN_0054eff0("Save Level Complete");
      uStack_8._0_1_ = 0x2e;
      FUN_0097c9e0(auStack_44);
      uStack_8._0_1_ = 0x2d;
      FUN_005507b0();
      if (DAT_01d64710 != '\0') {
        FUN_005ea7b0();
      }
    }
    FUN_005e66b0(uVar14,param_6);
    *(undefined4 *)param_2 = uVar14;
    *(int *)((int)param_2 + 4) = param_5;
    FUN_00550b30();
  }
  else {
    uVar14 = FUN_01675640(auStack_b4,"HTTP transport error (%d)",*(int *)(iVar13 + 0x70));
    FUN_005511f0(uVar14);
    FUN_005507b0();
    if (*(int *)(*piVar16 + 0x84) != 0) {
      puVar15 = (undefined4 *)FUN_00558df0(auStack_b4,&DAT_018bcaac,*piVar16 + 0x74);
      puVar12 = puVar15 + 4;
      uStack_8._0_1_ = 0x2c;
      if (0xf < (uint)puVar15[5]) {
        puVar15 = (undefined4 *)*puVar15;
      }
      FUN_00554150(puVar15,*puVar12);
      uStack_8._0_1_ = 0x2b;
LAB_005ebda0:
      FUN_005507b0();
    }
LAB_005ebdab:
    if (iVar8 != 0) {
      uStack_18 = 0xf00000000;
      ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
      uStack_8._0_1_ = 0x2f;
      uVar7 = (undefined)uStack_8;
      uStack_8._0_1_ = 0x2f;
      uStack_34 = 0;
      uStack_30 = 0xf;
      auStack_44[0] = auStack_44[0] & 0xffffff00;
      if ((char)param_3 == '\0') {
        uStack_8._0_1_ = uVar7;
        FUN_005542c0("Server Save Failure: ",0x15);
        uStack_8._0_1_ = 0x31;
      }
      else {
        FUN_005542c0("Server Publish Failure: ",0x18);
        uStack_8._0_1_ = 0x30;
      }
      uVar14 = FUN_00558c20(auStack_b4,auStack_44,&ppppuStack_74);
      FUN_005511f0(uVar14);
      FUN_005507b0();
      uStack_8._0_1_ = 0x2f;
      FUN_005507b0();
      FUN_0098c2c0(3,&ppppuStack_28);
      uStack_8._0_1_ = 0x2b;
      FUN_005507b0();
    }
    if (DAT_01d59a70 != '\0') {
      uStack_ec = 0;
      uStack_e8 = 0xf;
      auStack_fc[0] = 0;
      FUN_005542c0(" url: ",6);
      uStack_8._0_1_ = 0x32;
      uStack_34 = 0;
      uStack_30 = 0xf;
      auStack_44[0] = auStack_44[0] & 0xffffff00;
      FUN_005542c0("ServerSaveFailure ",0x12);
      uStack_8._0_1_ = 0x33;
      uVar14 = FUN_00558ba0(auStack_b4,auStack_44,auStack_fc);
      uStack_8._0_1_ = 0x34;
      FUN_00558c20(appppuStack_cc,uVar14,appppuStack_130);
      FUN_005507b0();
      FUN_005507b0();
      uStack_8._0_1_ = 0x38;
      FUN_005507b0();
      pppppuVar9 = appppuStack_cc;
      if (0xf < uStack_b8) {
        pppppuVar9 = (undefined4 *****)appppuStack_cc[0];
      }
      FUN_0087c6f0(&DAT_018c5f98,"Team Create",pppppuVar9,0,0,0,3);
      uStack_8._0_1_ = 0x2b;
      FUN_005507b0();
    }
    if (DAT_01d64710 != '\0') {
      FUN_005d0b40(0xb,(int)&param_6 + 3,(int)&param_6 + 3,(int)&param_6 + 3);
      uStack_8._0_1_ = 0x39;
      uVar14 = FUN_0152fd20(auStack_b4);
      uStack_8._0_1_ = 0x3a;
      uStack_34 = 0;
      uStack_30 = 0xf;
      auStack_44[0] = auStack_44[0] & 0xffffff00;
      FUN_005542c0("device",6);
      uStack_8._0_1_ = 0x3b;
      FUN_005d15d0(auStack_44);
      FUN_005511f0(uVar14);
      FUN_005507b0();
      uStack_8._0_1_ = 0x39;
      FUN_005507b0();
      uStack_34 = 0;
      uStack_30 = 0xf;
      auStack_44[0] = auStack_44[0] & 0xffffff00;
      FUN_005542c0("RobloxPlaceIdHeader",0x13);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x3c);
      puVar12 = (undefined4 *)FUN_005d15d0(auStack_44);
      if ((undefined4 **)puVar12 != &DAT_01d79c68) {
        puVar12 = &DAT_01d79c80;
        if (0xf < DAT_01d79c94) {
          puVar12 = DAT_01d79c80;
        }
        FUN_005542c0(puVar12,DAT_01d79c90);
      }
      uStack_8._0_1_ = 0x39;
      FUN_005507b0();
      uStack_34 = 0;
      uStack_30 = 0xf;
      auStack_44[0] = auStack_44[0] & 0xffffff00;
      FUN_005542c0("RobloxGameIdHeader",0x12);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x3d);
      puVar12 = (undefined4 *)FUN_005d15d0(auStack_44);
      if (puVar12 != &DAT_01d79c50) {
        puVar12 = &DAT_01d79c68;
        if (0xf < DAT_01d79c7c) {
          puVar12 = DAT_01d79c68;
        }
        FUN_005542c0(puVar12,DAT_01d79c78);
      }
      uStack_8._0_1_ = 0x39;
      FUN_005507b0();
      uVar14 = FUN_009ee570(auStack_b4,&param_3);
      uStack_8._0_1_ = 0x3e;
      uStack_34 = 0;
      uStack_30 = 0xf;
      auStack_44[0] = auStack_44[0] & 0xffffff00;
      FUN_005542c0("isPublish",9);
      uStack_8._0_1_ = 0x3f;
      FUN_005d15d0(auStack_44);
      FUN_005511f0(uVar14);
      FUN_005507b0();
      uStack_8._0_1_ = 0x39;
      FUN_005507b0();
      uVar14 = FUN_01675640(auStack_fc,&DAT_018bed48,param_4,param_5);
      uStack_8._0_1_ = 0x40;
      uStack_34 = 0;
      uStack_30 = 0xf;
      auStack_44[0] = auStack_44[0] & 0xffffff00;
      FUN_005542c0("userid",6);
      uStack_8._0_1_ = 0x41;
      FUN_005d15d0(auStack_44);
      FUN_005511f0(uVar14);
      FUN_005507b0();
      uStack_8._0_1_ = 0x39;
      FUN_005507b0();
      uStack_34 = 0;
      uStack_30 = 0xf;
      auStack_44[0] = auStack_44[0] & 0xffffff00;
      FUN_005542c0("context",7);
      uStack_8._0_1_ = 0x42;
      FUN_005d15d0(auStack_44);
      FUN_005542c0("DataModel Save",0xe);
      uStack_8._0_1_ = 0x39;
      FUN_005507b0();
      uStack_34 = 0;
      uStack_30 = 0xf;
      auStack_44[0] = auStack_44[0] & 0xffffff00;
      FUN_005542c0("error",5);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x43);
      iVar8 = FUN_005d15d0(auStack_44);
      if ((undefined4 *****)(iVar8 + 0x18) != &ppppuStack_74) {
        pppppuVar9 = &ppppuStack_74;
        if (0xf < uStack_60) {
          pppppuVar9 = (undefined4 *****)ppppuStack_74;
        }
        FUN_005542c0(pppppuVar9,uStack_64);
      }
      uStack_8._0_1_ = 0x39;
      FUN_005507b0();
      uStack_bc = 0;
      uStack_b8 = 0xf;
      appppuStack_cc[0] = (undefined4 ****)((uint)appppuStack_cc[0] & 0xffffff00);
      FUN_005542c0("BlockingSaveOrPublishFailure",0x1c);
      uStack_8._0_1_ = 0x44;
      uStack_ec = 0;
      uStack_e8 = 0xf;
      auStack_fc[0] = 0;
      FUN_005542c0("TeamCreate",10);
      uStack_8._0_1_ = 0x45;
      uStack_34 = 0;
      uStack_30 = 0xf;
      auStack_44[0] = auStack_44[0] & 0xffffff00;
      FUN_005542c0(&DAT_018bde9c,3);
      uStack_8._0_1_ = 0x46;
      FUN_00879580(auStack_44,auStack_fc,appppuStack_cc,&ppppuStack_28);
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      uStack_8._0_1_ = 0x2b;
      FUN_0056cfd0();
    }
    if (DAT_01d59a78 != '\0') {
      uStack_34 = 0;
      uStack_30 = 0xf;
      auStack_44[0] = auStack_44[0] & 0xffffff00;
      FUN_005542c0("TeamCreate.Publish.Failed.Request",0x21);
      uStack_8._0_1_ = 0x47;
      FUN_008783f0(auStack_44,1,0);
      FUN_005507b0();
    }
    *param_2 = 0;
  }
  FUN_005507b0();
  FUN_00550ad0();
  FUN_00550b30();
  uVar4 = uStack_6c;
LAB_005ec353:
  uStack_6c = uVar4;
  FUN_005507b0();
  FUN_005507b0();
  FUN_00550b30();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5806 ; VA 0x005ec3f0 ; FUN_005ec3f0 */

void __thiscall
FUN_005ec3f0(int *param_1,undefined4 *param_2,uint param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined8 param_9,
            uint param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined8 param_16)

{
  int iVar1;
  uint uVar2;
  char cVar3;
  undefined4 *puVar4;
  int *piVar5;
  undefined uVar6;
  undefined4 in_stack_ffffff28;
  undefined4 in_stack_ffffff2c;
  uint *puVar7;
  undefined4 in_stack_ffffff30;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  uint auStack_b8 [2];
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined8 uStack_a0;
  uint uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 uStack_78;
  int *piStack_74;
  undefined auStack_70 [12];
  int aiStack_64 [4];
  uint uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  uint uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  ulonglong uStack_2c;
  undefined4 uStack_24;
  int *piStack_20;
  int aiStack_1c [2];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179baeb;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff3c;
  uStack_8 = 1;
  piStack_20 = param_1;
  if (param_2[4] == 0) {
    uVar8 = 0;
    uVar9 = 0xf;
    uVar6 = 0;
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffff3c;
    FUN_005542c0("Url is empty",0xc);
    FUN_005e65e0(uVar6,in_stack_ffffff28,in_stack_ffffff2c,in_stack_ffffff30,uVar8,uVar9);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (((param_3 != 0) && ((param_3 & 1) == 0)) &&
       (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
    }
    uStack_8 = 3;
  }
  else {
    uStack_8._0_1_ = 4;
    uStack_8._1_3_ = 0;
    puVar4 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar4 = (undefined4 *)*param_2;
    }
    uVar8 = 0x5ec4de;
    ExceptionList = &pvStack_10;
    cVar3 = FUN_014cd610(puVar4,0);
    if (cVar3 == '\0') {
      uVar9 = 0;
      uVar10 = 0xf;
      FUN_005542c0("Url is invalid",0xe);
      FUN_005e65e0(cVar3,in_stack_ffffff28,in_stack_ffffff2c,uVar8,uVar9,uVar10);
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      if (((param_3 != 0) && ((param_3 & 1) == 0)) &&
         (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
      }
      uStack_8 = 6;
    }
    else {
      piVar5 = (int *)param_1[0x10f];
      FUN_00a19ae0(*piVar5 - (int)piVar5,piVar5[1] - (int)piVar5,param_1);
      uStack_2c = 0xf00000000;
      uStack_3c = uStack_3c & 0xffffff00;
      param_1 = param_1 + 3;
      uStack_8._0_1_ = 7;
      puVar7 = &uStack_3c;
      uVar8 = 0x5ec586;
      FUN_00a24b20(puVar7,param_1,0,0);
      if ((int)uStack_2c == 0) {
        uVar9 = 0;
        uVar10 = 0xf;
        uVar6 = 0;
        FUN_005542c0("No data to save",0xf);
        FUN_005e65e0(uVar6,uVar8,puVar7,param_1,uVar9,uVar10);
        FUN_005507b0();
        uStack_8 = CONCAT31(uStack_8._1_3_,8);
        if (((param_3 != 0) && ((param_3 & 1) == 0)) &&
           (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
        }
        uStack_8 = 9;
      }
      else {
        FUN_014c9d60(aiStack_1c,0);
        puVar4 = param_2 + 4;
        uStack_8._0_1_ = 10;
        if (0xf < (uint)param_2[5]) {
          param_2 = (undefined4 *)*param_2;
        }
        FUN_014cbbc0(param_2,*puVar4);
        uVar8 = 1;
        *(undefined4 *)(aiStack_1c[0] + 0xb0) = 0;
        puVar7 = &uStack_3c;
        FUN_014cb780(puVar7,1);
        FUN_0056a400(PTR_DAT_01d79bfc);
        puVar4 = &DAT_01d79d70;
        if (0xf < DAT_01d79d84) {
          puVar4 = DAT_01d79d70;
        }
        FUN_014cb8a0(puVar4,DAT_01d79d80,puVar7,uVar8);
        uVar10 = uStack_48;
        uVar9 = uStack_4c;
        uVar8 = uStack_50;
        uStack_54 = uStack_54 & 0xffffff00;
        uVar2 = uStack_54;
        uStack_54 = uStack_3c;
        uStack_50 = uStack_38;
        uStack_4c = uStack_34;
        uStack_48 = uStack_30;
        uStack_44 = uStack_2c;
        uStack_3c = uVar2;
        uStack_38 = uVar8;
        uStack_34 = uVar9;
        uStack_30 = uVar10;
        uStack_2c = 0xf00000000;
        FUN_005507b0();
        FUN_014cba60();
        puVar4 = (undefined4 *)FUN_005c4330(auStack_70,piStack_20);
        piVar5 = (int *)puVar4[1];
        if (piVar5 != (int *)0x0) {
          LOCK();
          piVar5[2] = piVar5[2] + 1;
          UNLOCK();
          piVar5 = (int *)puVar4[1];
        }
        uVar8 = *puVar4;
        uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
        uStack_24 = uVar8;
        piStack_20 = piVar5;
        FUN_00550b30();
        auStack_b8[0] = 0;
        if (param_3 != 0) {
          auStack_b8[0] = param_3;
          if ((param_3 & 1) == 0) {
            (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_b0,0);
          }
          else {
            uStack_b0 = param_5;
            uStack_ac = param_6;
            uStack_a8 = param_7;
            uStack_a4 = param_8;
            uStack_a0 = param_9;
          }
        }
        uStack_8._0_1_ = 0xc;
        uStack_98 = 0;
        if (param_10 != 0) {
          uStack_98 = param_10;
          if ((param_10 & 1) == 0) {
            (**(code **)(param_10 & 0xfffffffe))(&param_12,&uStack_90,0);
          }
          else {
            uStack_90 = param_12;
            uStack_8c = param_13;
            uStack_88 = param_14;
            uStack_84 = param_15;
            uStack_80 = param_16;
          }
        }
        if (piVar5 != (int *)0x0) {
          LOCK();
          piVar5[2] = piVar5[2] + 1;
          UNLOCK();
        }
        uStack_44 = uStack_44 & 0xffffffff;
        uStack_8._0_1_ = 0xe;
        uStack_78 = uVar8;
        piStack_74 = piVar5;
        uVar8 = FUN_005e54b0(auStack_b8);
        uStack_44 = CONCAT44(uVar8,(undefined4)uStack_44);
        FUN_005e6080();
        uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
        FUN_014cb530(aiStack_64);
        if (uStack_44._4_4_ != (int *)0x0) {
          (**(code **)(*uStack_44._4_4_ + 0x10))
                    (CONCAT31((int3)((uint)aiStack_64 >> 8),uStack_44._4_4_ != aiStack_64));
        }
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[2] + -1;
          piVar5[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
        FUN_00550b30();
        FUN_005507b0();
        uStack_8 = 0x11;
        if (((param_3 != 0) && ((param_3 & 1) == 0)) &&
           (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
        }
        uStack_8 = 0x12;
      }
    }
  }
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_10 & 0xfffffffe))(&param_12,&param_12,2);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5807 ; VA 0x005ec862 ; Catch@005ec862 */

undefined * Catch_005ec862(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -100) + 4))();
  FUN_0054eff0(uVar1);
  FUN_005e65e0();
  return &DAT_005ec887;
}



/* FUNCTION 5808 ; VA 0x005ec8b0 ; FUN_005ec8b0 */

void __fastcall FUN_005ec8b0(int param_1)

{
  if (*(int *)(param_1 + 0x70) != 0) {
    FUN_01718190(*(int *)(param_1 + 0x70));
    *(undefined4 *)(param_1 + 0x70) = 0;
  }
  return;
}



/* FUNCTION 5809 ; VA 0x005ec8d0 ; FUN_005ec8d0 */

undefined4 FUN_005ec8d0(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  if (0xf < (uint)param_3[5]) {
    param_3 = (undefined4 *)*param_3;
  }
  FUN_01675640(param_1,"%s_%s.log",param_2,param_3);
  return param_1;
}



/* FUNCTION 5810 ; VA 0x005ec900 ; FUN_005ec900 */

void FUN_005ec900(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bb60;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((DAT_020c0b1c != '\0') && (ExceptionList = &pvStack_10, DAT_01d7a7a8 != '\0')) {
    ExceptionList = &pvStack_10;
    FUN_0151f6f0(DAT_01ea93fc,3,DAT_01d59a94);
    uStack_8 = 0;
    FUN_0151f850("fastlogmessage",uVar2);
    uVar1 = DAT_01ea93fc;
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = 0;
    FUN_005542c0("fastlogreport",0xd);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_01520d20(auStack_28,uVar1,0);
    FUN_005507b0();
    uStack_8 = 0xffffffff;
    FUN_0151f7f0();
  }
  if (DAT_01ea9418 != 0) {
    FUN_005ed2e0(&param_1,uVar2);
  }
  if (DAT_01ea941c != (code *)0x0) {
    (*DAT_01ea941c)(param_1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5811 ; VA 0x005ec9f0 ; FUN_005ec9f0 */

void __thiscall FUN_005ec9f0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 ****ppppuVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  undefined4 ****ppppuVar9;
  int iVar10;
  uint *puStack_94;
  char cStack_90;
  undefined4 ***apppuStack_8c [4];
  int iStack_7c;
  uint uStack_78;
  undefined4 uStack_74;
  undefined4 ***apppuStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  undefined4 ***apppuStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bbf3;
  pvStack_10 = ExceptionList;
  uStack_74 = 0;
  ExceptionList = &pvStack_10;
  FUN_005693c0(param_1 + 0x13);
  iStack_8 = 0;
  if (param_1 != param_2) {
    puVar3 = param_2 + 4;
    if (7 < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_0058ed10(param_2,*puVar3);
  }
  piVar8 = param_1 + 6;
  if (piVar8 != param_3) {
    puVar3 = param_3 + 4;
    if (0xf < (uint)param_3[5]) {
      param_3 = (undefined4 *)*param_3;
    }
    FUN_005542c0(param_3,*puVar3);
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  apppuStack_58[0] = (undefined4 ***)((uint)apppuStack_58[0] & 0xffffff00);
  FUN_005542c0(&DAT_018c8a5c,4);
  iStack_8._0_1_ = 1;
  if (0xf < (uint)param_1[0xb]) {
    piVar8 = (int *)*piVar8;
  }
  ppppuVar5 = apppuStack_58;
  if (0xf < uStack_44) {
    ppppuVar5 = (undefined4 ****)apppuStack_58[0];
  }
  FUN_01675640(apppuStack_8c,"%s_%s.log",piVar8,ppppuVar5);
  uStack_30 = 0;
  uStack_2c = 7;
  uStack_40 = (uint)uStack_40._2_2_ << 0x10;
  iStack_8._0_1_ = 3;
  if (iStack_7c != 0) {
    ppppuVar5 = apppuStack_8c;
    if (0xf < uStack_78) {
      ppppuVar5 = (undefined4 ****)apppuStack_8c[0];
    }
    ppppuVar9 = apppuStack_8c;
    if (0xf < uStack_78) {
      ppppuVar9 = (undefined4 ****)apppuStack_8c[0];
    }
    uVar2 = FUN_01686580();
    FUN_01685950(ppppuVar9,(int)ppppuVar5 + iStack_7c,&uStack_40,uVar2);
  }
  iStack_8._0_1_ = 4;
  puVar3 = (undefined4 *)FUN_005514a0(auStack_28,param_1,&uStack_40);
  iStack_8 = CONCAT31(iStack_8._1_3_,6);
  uStack_60 = 0;
  uStack_5c = 0xf;
  apppuStack_70[0] = (undefined4 ***)((uint)apppuStack_70[0] & 0xffffff00);
  iVar10 = puVar3[4];
  uStack_74 = 3;
  if (iVar10 != 0) {
    puVar4 = puVar3;
    if (7 < (uint)puVar3[5]) {
      puVar4 = (undefined4 *)*puVar3;
    }
    if (7 < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    uVar2 = FUN_01686580();
    FUN_01685a20(puVar3,(int)puVar4 + iVar10 * 2,apppuStack_70,uVar2);
  }
  if ((undefined4 ****)(param_1 + 0xc) != apppuStack_70) {
    ppppuVar5 = apppuStack_70;
    if (0xf < uStack_5c) {
      ppppuVar5 = (undefined4 ****)apppuStack_70[0];
    }
    FUN_005542c0(ppppuVar5,uStack_60);
  }
  iStack_8._0_1_ = 5;
  if (0xf < uStack_5c) {
    uVar7 = uStack_5c + 1;
    ppppuVar5 = (undefined4 ****)apppuStack_70[0];
    if (0xfff < uVar7) {
      ppppuVar5 = (undefined4 ****)apppuStack_70[0][-1];
      uVar7 = uStack_5c + 0x24;
      if (0x1f < (uint)((int)apppuStack_70[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar5,uVar7);
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  apppuStack_70[0] = (undefined4 ***)((uint)apppuStack_70[0] & 0xffffff00);
  iStack_8._0_1_ = 4;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 4;
  if (7 < uStack_14) {
    uVar7 = uStack_14 * 2 + 2;
    uVar6 = auStack_28[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_28[0] - 4);
      uVar7 = uStack_14 * 2 + 0x25;
      if (0x1f < (auStack_28[0] - uVar6) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_18 = 0;
  uStack_14 = 7;
  auStack_28[0] = auStack_28[0] & 0xffff0000;
  iStack_8._0_1_ = 2;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 2;
  if (7 < uStack_2c) {
    uVar7 = uStack_2c * 2 + 2;
    uVar6 = uStack_40;
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(uStack_40 - 4);
      uVar7 = uStack_2c * 2 + 0x25;
      if (0x1f < (uStack_40 - uVar6) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_30 = 0;
  uStack_2c = 7;
  uStack_40 = uStack_40 & 0xffff0000;
  iStack_8._0_1_ = 1;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 1;
  if (0xf < uStack_78) {
    uVar7 = uStack_78 + 1;
    ppppuVar5 = (undefined4 ****)apppuStack_8c[0];
    if (0xfff < uVar7) {
      ppppuVar5 = (undefined4 ****)apppuStack_8c[0][-1];
      uVar7 = uStack_78 + 0x24;
      if (0x1f < (uint)((int)apppuStack_8c[0] + (-4 - (int)ppppuVar5))) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar5,uVar7);
  }
  iStack_7c = 0;
  uStack_78 = 0xf;
  apppuStack_8c[0] = (undefined4 ***)((uint)apppuStack_8c[0] & 0xffffff00);
  iStack_8._0_1_ = 0;
  if (0xf < uStack_44) {
    uVar7 = uStack_44 + 1;
    ppppuVar5 = (undefined4 ****)apppuStack_58[0];
    if (0xfff < uVar7) {
      ppppuVar5 = (undefined4 ****)apppuStack_58[0][-1];
      uVar7 = uStack_44 + 0x24;
      if (0x1f < (uint)((int)apppuStack_58[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar5,uVar7);
  }
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea9438) {
    FUN_016f3809(&DAT_01ea9438);
    if (DAT_01ea9438 == -1) {
      iStack_8._0_1_ = 7;
      uStack_48 = 0;
      uStack_44 = 0xf;
      apppuStack_58[0] = (undefined4 ***)((uint)apppuStack_58[0] & 0xffffff00);
      FUN_005542c0(&DAT_018c8a88,4);
      iStack_8._0_1_ = 8;
      uVar2 = FUN_00a33850();
      ppppuVar5 = apppuStack_58;
      if (0xf < uStack_44) {
        ppppuVar5 = (undefined4 ****)apppuStack_58[0];
      }
      FUN_01675640(&DAT_01ea9420,"%s_%s.log",uVar2,ppppuVar5);
      FUN_005507b0();
      FUN_016f3654(&LAB_0187bdd0);
      FUN_016f37bf(&DAT_01ea9438);
    }
  }
  uStack_30 = 0;
  uStack_2c = 7;
  uStack_40 = uStack_40 & 0xffff0000;
  iStack_8._0_1_ = 9;
  if (DAT_01ea9430 != 0) {
    puVar3 = &DAT_01ea9420;
    if (0xf < DAT_01ea9434) {
      puVar3 = DAT_01ea9420;
    }
    iVar10 = (int)puVar3 + DAT_01ea9430;
    puVar3 = &DAT_01ea9420;
    if (0xf < DAT_01ea9434) {
      puVar3 = DAT_01ea9420;
    }
    uVar2 = FUN_01686580();
    FUN_01685950(puVar3,iVar10,&uStack_40,uVar2);
  }
  iStack_8._0_1_ = 10;
  puVar3 = (undefined4 *)FUN_005514a0(auStack_28,param_1,&uStack_40);
  iStack_8._0_1_ = 0xb;
  if (param_1 + 0x16 != puVar3) {
    puVar4 = puVar3 + 4;
    if (7 < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    FUN_0058ed10(puVar3,*puVar4);
  }
  iStack_8._0_1_ = 10;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 10;
  if (7 < uStack_14) {
    uVar7 = uStack_14 * 2 + 2;
    uVar6 = auStack_28[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_28[0] - 4);
      uVar7 = uStack_14 * 2 + 0x25;
      if (0x1f < (auStack_28[0] - uVar6) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_18 = 0;
  uStack_14 = 7;
  auStack_28[0] = auStack_28[0] & 0xffff0000;
  iStack_8._0_1_ = 0;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 0;
  if (7 < uStack_2c) {
    uVar7 = uStack_2c * 2 + 2;
    uVar6 = uStack_40;
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(uStack_40 - 4);
      uVar7 = uStack_2c * 2 + 0x25;
      if (0x1f < (uStack_40 - uVar6) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uVar2 = FUN_01688660(auStack_28);
  iStack_8._0_1_ = 0xc;
  FUN_0168bc20(uVar2,0);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (7 < uStack_14) {
    uVar7 = uStack_14 * 2 + 2;
    uVar6 = auStack_28[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_28[0] - 4);
      uVar7 = uStack_14 * 2 + 0x25;
      if (0x1f < (auStack_28[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_18 = 0;
  uStack_14 = 7;
  auStack_28[0] = auStack_28[0] & 0xffff0000;
  *(undefined *)(param_1 + 0x12) = 1;
  iStack_8 = 0xd;
  if (cStack_90 != '\0') {
    LOCK();
    uVar7 = *puStack_94;
    *puStack_94 = *puStack_94 + 0x80000000;
    UNLOCK();
    if (((uVar7 & 0x40000000) == 0) && (-0x80000000 < (int)uVar7)) {
      LOCK();
      uVar7 = *puStack_94;
      *puStack_94 = *puStack_94 | 0x40000000;
      UNLOCK();
      if ((uVar7 >> 0x1e & 1) == 0) {
        uVar2 = FUN_00554e40();
        SetEvent(uVar2);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5812 ; VA 0x005ecfc0 ; FUN_005ecfc0 */

void FUN_005ecfc0(undefined4 param_1)

{
  DAT_01ea941c = param_1;
  return;
}



/* FUNCTION 5813 ; VA 0x005ecfd0 ; FUN_005ecfd0 */

void FUN_005ecfd0(void)

{
  char cVar1;
  char *pcVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 ****ppppuVar6;
  char *pcVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  undefined2 auStack_7c [8];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  uint auStack_64 [4];
  undefined4 uStack_54;
  uint uStack_50;
  uint auStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  undefined4 ***apppuStack_34 [4];
  int iStack_24;
  uint uStack_20;
  undefined8 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bc41;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  pcVar2 = (char *)FUN_00a33850();
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  pcVar7 = pcVar2;
  do {
    cVar1 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar2,(int)pcVar7 - (int)(pcVar2 + 1));
  uStack_8 = 0;
  FUN_01522600(auStack_4c);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_38) {
    uVar8 = uStack_38 + 1;
    uVar9 = auStack_4c[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_4c[0] - 4);
      uVar8 = uStack_38 + 0x24;
      if (0x1f < (auStack_4c[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  puVar3 = (undefined4 *)FUN_01518d10(auStack_64,1,0,&DAT_018c0e28);
  iStack_24 = 0;
  uStack_20 = 0xf;
  apppuStack_34[0] = (undefined4 ***)((uint)apppuStack_34[0] & 0xffffff00);
  iVar10 = puVar3[4];
  uStack_8 = 2;
  uStack_14 = 1;
  if (iVar10 != 0) {
    puVar4 = puVar3;
    if (7 < (uint)puVar3[5]) {
      puVar4 = (undefined4 *)*puVar3;
    }
    if (7 < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    uVar5 = FUN_01686580();
    FUN_01685a20(puVar3,(int)puVar4 + iVar10 * 2,apppuStack_34,uVar5);
  }
  uStack_8._0_1_ = 3;
  if (7 < uStack_50) {
    uVar9 = uStack_50 * 2 + 2;
    uVar8 = auStack_64[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_64[0] - 4);
      uVar9 = uStack_50 * 2 + 0x25;
      if (0x1f < (auStack_64[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_54 = 0;
  uStack_50 = 7;
  auStack_64[0] = auStack_64[0] & 0xffff0000;
  if (DAT_01ea9418 != 0) {
    uStack_3c = 0;
    uStack_38 = 0xf;
    auStack_4c[0] = auStack_4c[0] & 0xffffff00;
    pcVar7 = pcVar2;
    do {
      cVar1 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0(pcVar2,(int)pcVar7 - (int)(pcVar2 + 1));
    uStack_6c = 0;
    uStack_68 = 7;
    auStack_7c[0] = 0;
    uStack_8._0_1_ = 5;
    if (iStack_24 != 0) {
      ppppuVar6 = apppuStack_34;
      if (0xf < uStack_20) {
        ppppuVar6 = (undefined4 ****)apppuStack_34[0];
      }
      iVar10 = (int)ppppuVar6 + iStack_24;
      ppppuVar6 = apppuStack_34;
      if (0xf < uStack_20) {
        ppppuVar6 = (undefined4 ****)apppuStack_34[0];
      }
      uVar5 = FUN_01686580();
      FUN_01685950(ppppuVar6,iVar10,auStack_7c,uVar5);
    }
    uStack_8._0_1_ = 6;
    FUN_005ec9f0(auStack_7c,auStack_4c);
    FUN_00550800();
    uStack_8._0_1_ = 3;
    if (0xf < uStack_38) {
      uVar8 = uStack_38 + 1;
      uVar9 = auStack_4c[0];
      if (0xfff < uVar8) {
        uVar9 = *(uint *)(auStack_4c[0] - 4);
        uVar8 = uStack_38 + 0x24;
        if (0x1f < (auStack_4c[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar8);
    }
  }
  uStack_1c = 0;
  FUN_0171e1b0(&uStack_1c);
  FUN_01677ae0(FUN_01683110,(undefined4)uStack_1c,uStack_1c._4_4_);
  FUN_01678060(FUN_005ec900);
  ppppuVar6 = apppuStack_34;
  if (0xf < uStack_20) {
    ppppuVar6 = (undefined4 ****)apppuStack_34[0];
  }
  _guard_check_icall(ppppuVar6);
  if (0xf < uStack_20) {
    uVar9 = uStack_20 + 1;
    ppppuVar6 = (undefined4 ****)apppuStack_34[0];
    if (0xfff < uVar9) {
      ppppuVar6 = (undefined4 ****)apppuStack_34[0][-1];
      uVar9 = uStack_20 + 0x24;
      if (0x1f < (uint)((int)apppuStack_34[0] + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar6,uVar9);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5814 ; VA 0x005ed290 ; FUN_005ed290 */

undefined * FUN_005ed290(undefined *param_1,undefined4 param_2)

{
  undefined *puVar1;
  undefined auStack_7 [3];
  
  puVar1 = (undefined *)FUN_00591870(auStack_7,param_2);
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  if (puVar1 != auStack_7) {
    FUN_005542c0(puVar1,(int)auStack_7 - (int)puVar1);
  }
  return param_1;
}



/* FUNCTION 5815 ; VA 0x005ed2e0 ; FUN_005ed2e0 */

void __thiscall FUN_005ed2e0(int param_1,undefined4 param_2,undefined4 param_3)

{
  uint uVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined *puVar6;
  int *piVar7;
  undefined auStack_98 [24];
  undefined auStack_80 [45];
  undefined auStack_53 [27];
  undefined auStack_38 [16];
  undefined4 uStack_28;
  undefined4 uStack_24;
  uint *puStack_20;
  char cStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bc83;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005693c0(param_1 + 0x4c);
  iStack_8 = 0;
  if (*(int *)(param_1 + 0x70) == 0) {
    iVar5 = param_1 + 0x58;
    if (7 < *(uint *)(param_1 + 0x6c)) {
      iVar5 = *(int *)(param_1 + 0x58);
    }
    uVar3 = FUN_01721ff3(iVar5,&DAT_018c8a64);
    pcVar2 = *(code **)(param_1 + 0x54);
    *(undefined4 *)(param_1 + 0x70) = uVar3;
    if (pcVar2 != (code *)0x0) {
      puVar4 = (undefined4 *)FUN_005569d0(auStack_53 + 3);
      iStack_8._0_1_ = 1;
      if (0xf < (uint)puVar4[5]) {
        puVar4 = (undefined4 *)*puVar4;
      }
      (*pcVar2)(puVar4);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_005507b0();
    }
  }
  if (*(int *)(param_1 + 0x70) != 0) {
    FUN_01725cf2(param_3,*(int *)(param_1 + 0x70));
    FUN_01725cf2(&DAT_018bcfa8,*(undefined4 *)(param_1 + 0x70));
    FUN_017184e1(*(undefined4 *)(param_1 + 0x70));
    if ((((DAT_020c0b1c != '\0') && (DAT_01d59ab4 != '\0')) && (0 < DAT_01ea93f4)) &&
       (iVar5 = FUN_01726462(*(undefined4 *)(param_1 + 0x70)), DAT_01ea93f4 <= iVar5)) {
      FUN_005ec8b0();
      puVar6 = (undefined *)FUN_00591870(auStack_53,*(undefined4 *)(param_1 + 0x74));
      uStack_28 = 0;
      uStack_24 = 0xf;
      auStack_38[0] = 0;
      if (puVar6 != auStack_53) {
        FUN_005542c0(puVar6,(int)auStack_53 - (int)puVar6);
      }
      piVar7 = (int *)(param_1 + 0x18);
      iStack_8._0_1_ = 2;
      if (0xf < *(uint *)(param_1 + 0x2c)) {
        piVar7 = (int *)*piVar7;
      }
      uVar3 = FUN_005ec8d0(auStack_98,piVar7,auStack_38);
      iStack_8._0_1_ = 3;
      FUN_00558140(uVar3,0);
      iStack_8._0_1_ = 4;
      FUN_005514a0(auStack_53 + 3,param_1,auStack_80);
      FUN_00550800();
      FUN_005507b0();
      iStack_8 = CONCAT31(iStack_8._1_3_,8);
      FUN_005507b0();
      iStack_18 = 0;
      uStack_14 = FUN_01685730();
      FUN_0168df40(param_1 + 0x58,auStack_53 + 3,&iStack_18);
      if (iStack_18 != 0) {
        FUN_0168da40(param_1 + 0x58,&iStack_18);
      }
      *(int *)(param_1 + 0x74) = *(int *)(param_1 + 0x74) + 1;
      FUN_00550800();
    }
  }
  iStack_8 = 9;
  if (cStack_1c != '\0') {
    LOCK();
    uVar1 = *puStack_20;
    *puStack_20 = *puStack_20 + 0x80000000;
    UNLOCK();
    if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
      LOCK();
      uVar1 = *puStack_20;
      *puStack_20 = *puStack_20 | 0x40000000;
      UNLOCK();
      if ((uVar1 >> 0x1e & 1) == 0) {
        uVar3 = FUN_00554e40();
        SetEvent(uVar3);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5816 ; VA 0x005ed510 ; FUN_005ed510 */

undefined4 * __thiscall FUN_005ed510(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  
  uVar3 = FUN_0088c8c0();
  iVar2 = _tls_index;
  *param_1 = uVar3;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01ea8c18) {
    FUN_016f3809(&DAT_01ea8c18);
    if (DAT_01ea8c18 == -1) {
      DAT_01ea8c0c = FUN_005c65e0;
      DAT_01ea8c10 = FUN_005c65e0;
      DAT_01ea8c14 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ea8c18);
    }
  }
  puVar1 = (undefined4 *)param_1[1];
  if ((code **)puVar1 == &DAT_01ea8c0c) {
    param_1[2] = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined4 *)0x0) {
    (*(code *)puVar1[2])(param_1 + 2);
    param_1[1] = 0;
  }
  param_1[2] = *param_2;
  param_1[1] = &DAT_01ea8c0c;
  return param_1;
}



/* FUNCTION 5817 ; VA 0x005ed5d0 ; FUN_005ed5d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_005ed5d0(undefined4 *param_1,undefined4 *param_2)

{
  undefined *puVar1;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaaccc) {
    FUN_016f3809(&DAT_01eaaccc);
    if (DAT_01eaaccc == -1) {
      _DAT_01eaacc0 = FUN_005c65e0;
      _DAT_01eaacc4 = FUN_005c65e0;
      _DAT_01eaacc8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eaaccc);
    }
  }
  puVar1 = (undefined *)*param_1;
  if (puVar1 == &DAT_01eaacc0) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = &DAT_01eaacc0;
  return param_1;
}



/* FUNCTION 5818 ; VA 0x005ed680 ; FUN_005ed680 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_005ed680(undefined4 *param_1,undefined4 *param_2)

{
  undefined *puVar1;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaacfc) {
    FUN_016f3809(&DAT_01eaacfc);
    if (DAT_01eaacfc == -1) {
      _DAT_01eaacf0 = FUN_005c65e0;
      _DAT_01eaacf4 = FUN_005c65e0;
      _DAT_01eaacf8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eaacfc);
    }
  }
  puVar1 = (undefined *)*param_1;
  if (puVar1 == &DAT_01eaacf0) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = &DAT_01eaacf0;
  return param_1;
}



/* FUNCTION 5819 ; VA 0x005ed730 ; FUN_005ed730 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_005ed730(undefined4 *param_1,undefined4 *param_2)

{
  undefined *puVar1;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaac8c) {
    FUN_016f3809(&DAT_01eaac8c);
    if (DAT_01eaac8c == -1) {
      _DAT_01eaac80 = FUN_005c65e0;
      _DAT_01eaac84 = FUN_005c65e0;
      _DAT_01eaac88 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eaac8c);
    }
  }
  puVar1 = (undefined *)*param_1;
  if (puVar1 == &DAT_01eaac80) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = &DAT_01eaac80;
  return param_1;
}



/* FUNCTION 5820 ; VA 0x005ed7e0 ; FUN_005ed7e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_005ed7e0(undefined4 *param_1,undefined4 *param_2)

{
  undefined *puVar1;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaacec) {
    FUN_016f3809(&DAT_01eaacec);
    if (DAT_01eaacec == -1) {
      _DAT_01eaace0 = FUN_005c65e0;
      _DAT_01eaace4 = FUN_005c65e0;
      _DAT_01eaace8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eaacec);
    }
  }
  puVar1 = (undefined *)*param_1;
  if (puVar1 == &DAT_01eaace0) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = &DAT_01eaace0;
  return param_1;
}



/* FUNCTION 5821 ; VA 0x005ed890 ; FUN_005ed890 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_005ed890(undefined4 *param_1,undefined4 *param_2)

{
  undefined *puVar1;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaacdc) {
    FUN_016f3809(&DAT_01eaacdc);
    if (DAT_01eaacdc == -1) {
      _DAT_01eaacd0 = FUN_005c65e0;
      _DAT_01eaacd4 = FUN_005c65e0;
      _DAT_01eaacd8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eaacdc);
    }
  }
  puVar1 = (undefined *)*param_1;
  if (puVar1 == &DAT_01eaacd0) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = &DAT_01eaacd0;
  return param_1;
}



/* FUNCTION 5822 ; VA 0x005ed940 ; FUN_005ed940 */

int * FUN_005ed940(int *param_1,byte param_2)

{
  byte bVar1;
  int iVar2;
  int *piVar3;
  byte *pbVar4;
  char cVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  bool bVar9;
  int iStack_2c;
  int iStack_28;
  int *piStack_24;
  char cStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bc98;
  pvStack_10 = ExceptionList;
  uVar8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0056b230(param_1);
  if (cStack_20 == '\0') goto LAB_005edb17;
  iVar7 = *param_1;
  iVar2 = *(int *)(iVar7 + 4);
  iStack_28 = *(int *)(iVar2 + 0x24 + (int)param_1);
  uVar6 = *(uint *)(iVar2 + 0x20 + (int)param_1);
  if ((iStack_28 < 1) && ((iStack_28 < 0 || (uVar6 < 2)))) {
    iStack_28 = 0;
    iStack_2c = 0;
  }
  else {
    iStack_2c = uVar6 - 1;
    iStack_28 = iStack_28 - (uint)(uVar6 == 0);
  }
  uStack_8 = 1;
  if ((*(uint *)(iVar2 + 0x14 + (int)param_1) & 0x1c0) != 0x40) {
    while (uVar8 == 0) {
      if ((iStack_28 < 0) || ((iStack_28 < 1 && (iStack_2c == 0)))) {
        iVar7 = *param_1;
        goto LAB_005eda36;
      }
      piVar3 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
      bVar1 = *(byte *)(*(int *)(*param_1 + 4) + 0x40 + (int)param_1);
      if (*(int *)piVar3[8] == 0) {
LAB_005eda0b:
        uVar6 = (**(code **)(*piVar3 + 0xc))(bVar1);
      }
      else {
        iVar7 = *(int *)piVar3[0xc];
        if (iVar7 < 1) goto LAB_005eda0b;
        *(int *)piVar3[0xc] = iVar7 + -1;
        pbVar4 = *(byte **)piVar3[8];
        *(byte **)piVar3[8] = pbVar4 + 1;
        *pbVar4 = bVar1;
        uVar6 = (uint)bVar1;
      }
      bVar9 = iStack_2c != 0;
      iStack_2c = iStack_2c + -1;
      uVar8 = 4;
      iStack_28 = iStack_28 + -1 + (uint)bVar9;
      if (uVar6 != 0xffffffff) {
        uVar8 = 0;
      }
    }
    goto LAB_005edb17;
  }
LAB_005eda36:
  piVar3 = *(int **)(*(int *)(iVar7 + 4) + 0x38 + (int)param_1);
  if (*(int *)piVar3[8] == 0) {
LAB_005eda65:
    uVar6 = (**(code **)(*piVar3 + 0xc))(param_2);
  }
  else {
    iVar7 = *(int *)piVar3[0xc];
    if (iVar7 < 1) goto LAB_005eda65;
    *(int *)piVar3[0xc] = iVar7 + -1;
    pbVar4 = *(byte **)piVar3[8];
    *(byte **)piVar3[8] = pbVar4 + 1;
    *pbVar4 = param_2;
    uVar6 = (uint)param_2;
  }
  if (uVar6 == 0xffffffff) {
    uVar8 = 4;
  }
  while (((uVar8 == 0 && (-1 < iStack_28)) && ((0 < iStack_28 || (iStack_2c != 0))))) {
    piVar3 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
    bVar1 = *(byte *)(*(int *)(*param_1 + 4) + 0x40 + (int)param_1);
    if (*(int *)piVar3[8] == 0) {
LAB_005edad0:
      uVar6 = (**(code **)(*piVar3 + 0xc))(bVar1);
    }
    else {
      iVar7 = *(int *)piVar3[0xc];
      if (iVar7 < 1) goto LAB_005edad0;
      *(int *)piVar3[0xc] = iVar7 + -1;
      pbVar4 = *(byte **)piVar3[8];
      *(byte **)piVar3[8] = pbVar4 + 1;
      *pbVar4 = bVar1;
      uVar6 = (uint)bVar1;
    }
    bVar9 = iStack_2c != 0;
    iStack_2c = iStack_2c + -1;
    uVar8 = 4;
    iStack_28 = iStack_28 + -1 + (uint)bVar9;
    if (uVar6 != 0xffffffff) {
      uVar8 = 0;
    }
  }
LAB_005edb17:
  uStack_8 = 0;
  iVar7 = *(int *)(*param_1 + 4);
  *(undefined4 *)(iVar7 + 0x20 + (int)param_1) = 0;
  *(undefined4 *)(iVar7 + 0x24 + (int)param_1) = 0;
  uVar8 = *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc) | uVar8;
  uVar6 = uVar8 | 4;
  if (*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) != 0) {
    uVar6 = uVar8;
  }
  FUN_00554460(uVar6,0);
  uStack_8 = 3;
  cVar5 = thunk_FUN_0170e3b7();
  if (cVar5 == '\0') {
    FUN_00577770();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  piVar3 = *(int **)(*(int *)(*piStack_24 + 4) + 0x38 + (int)piStack_24);
  if (piVar3 != (int *)0x0) {
    (**(code **)(*piVar3 + 8))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5823 ; VA 0x005edaf1 ; Catch_All@005edaf1 */

undefined * Catch_All_005edaf1(void)

{
  FUN_005565b0(4,1);
  return &DAT_005edb0a;
}



/* FUNCTION 5824 ; VA 0x005edc10 ; FUN_005edc10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_005edc10(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bcd0;
  pvStack_10 = ExceptionList;
  if (DAT_01ea94d4 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea96e8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ea96e8);
      if (DAT_01ea96e8 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_005ee090();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"NetworkClient",1,uStack_20,0,0,1,0,0);
        _DAT_01ea96e0 = RBX::Creator<class_RBX::Network::Client>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ea94d8,&DAT_01ea96e0);
        FUN_016f3654(FUN_0187c180);
        FUN_016f37bf(&DAT_01ea96e8);
      }
    }
    DAT_01ea94d4 = &DAT_01ea94d8;
  }
  ExceptionList = pvStack_10;
  return DAT_01ea94d4;
}



/* FUNCTION 5825 ; VA 0x005edd10 ; FUN_005edd10 */

undefined * FUN_005edd10(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bcec;
  pvStack_10 = ExceptionList;
  if (DAT_01eaa388 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaa598) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eaa598);
      if (DAT_01eaa598 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_005ee170();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ClientReplicator",0,uStack_20,0,0,1,0,0);
        FUN_016f3654(&LAB_0187c1e0);
        FUN_016f37bf(&DAT_01eaa598);
      }
    }
    DAT_01eaa388 = &DAT_01eaa390;
  }
  ExceptionList = pvStack_10;
  return DAT_01eaa388;
}



/* FUNCTION 5826 ; VA 0x005eddf0 ; FUN_005eddf0 */

undefined * FUN_005eddf0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bd0c;
  pvStack_10 = ExceptionList;
  if (DAT_01eaa5a0 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaa7b0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eaa7b0);
      if (DAT_01eaa7b0 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"GuidRegistryService",1,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_0187c1f0);
        FUN_016f37bf(&DAT_01eaa7b0);
      }
    }
    DAT_01eaa5a0 = &DAT_01eaa5a8;
  }
  ExceptionList = pvStack_10;
  return DAT_01eaa5a0;
}



/* FUNCTION 5827 ; VA 0x005eded0 ; FUN_005eded0 */

undefined * FUN_005eded0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bd2c;
  pvStack_10 = ExceptionList;
  if (DAT_01ea9d40 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea9f50) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ea9f50);
      if (DAT_01ea9f50 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"NetworkMarker",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_0187c200);
        FUN_016f37bf(&DAT_01ea9f50);
      }
    }
    DAT_01ea9d40 = &DAT_01ea9d48;
  }
  ExceptionList = pvStack_10;
  return DAT_01ea9d40;
}



/* FUNCTION 5828 ; VA 0x005edfb0 ; FUN_005edfb0 */

undefined * FUN_005edfb0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bd4c;
  pvStack_10 = ExceptionList;
  if (DAT_01ea9910 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea9b20) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ea9b20);
      if (DAT_01ea9b20 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"NetworkSettings",1,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_0187c210);
        FUN_016f37bf(&DAT_01ea9b20);
      }
    }
    DAT_01ea9910 = &DAT_01ea9918;
  }
  ExceptionList = pvStack_10;
  return DAT_01ea9910;
}



/* FUNCTION 5829 ; VA 0x005ee090 ; FUN_005ee090 */

undefined * FUN_005ee090(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bd6c;
  pvStack_10 = ExceptionList;
  if (DAT_01ea9b28 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea9d38) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ea9d38);
      if (DAT_01ea9d38 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"NetworkPeer",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_0187c220);
        FUN_016f37bf(&DAT_01ea9d38);
      }
    }
    DAT_01ea9b28 = &DAT_01ea9b30;
  }
  ExceptionList = pvStack_10;
  return DAT_01ea9b28;
}



/* FUNCTION 5830 ; VA 0x005ee170 ; FUN_005ee170 */

undefined * FUN_005ee170(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bd8c;
  pvStack_10 = ExceptionList;
  if (DAT_01ea9f58 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaa168) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eaa168);
      if (DAT_01eaa168 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"NetworkReplicator",0,uStack_20,0,0,1,0,0);
        FUN_016f3654(&LAB_0187c230);
        FUN_016f37bf(&DAT_01eaa168);
      }
    }
    DAT_01ea9f58 = &DAT_01ea9f60;
  }
  ExceptionList = pvStack_10;
  return DAT_01ea9f58;
}



/* FUNCTION 5831 ; VA 0x005ee250 ; FUN_005ee250 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_005ee250(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bdc0;
  pvStack_10 = ExceptionList;
  if (DAT_01ea96f0 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea9908) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ea9908);
      if (DAT_01ea9908 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_005ee090();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"NetworkServer",1,uStack_20,0,0,1,0,0);
        _DAT_01ea9900 = RBX::Creator<class_RBX::Network::Server>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ea96f8,&DAT_01ea9900);
        FUN_016f3654(FUN_0187c240);
        FUN_016f37bf(&DAT_01ea9908);
      }
    }
    DAT_01ea96f0 = &DAT_01ea96f8;
  }
  ExceptionList = pvStack_10;
  return DAT_01ea96f0;
}



/* FUNCTION 5832 ; VA 0x005ee350 ; FUN_005ee350 */

undefined * FUN_005ee350(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bddc;
  pvStack_10 = ExceptionList;
  if (DAT_01eaa170 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaa380) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eaa380);
      if (DAT_01eaa380 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_005ee170();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ServerReplicator",0,uStack_20,0,0,1,0,0);
        FUN_016f3654(&LAB_0187c2a0);
        FUN_016f37bf(&DAT_01eaa380);
      }
    }
    DAT_01eaa170 = &DAT_01eaa178;
  }
  ExceptionList = pvStack_10;
  return DAT_01eaa170;
}



/* FUNCTION 5833 ; VA 0x005ee430 ; FUN_005ee430 */

void FUN_005ee430(void)

{
  int iVar1;
  
  if (DAT_01ea96ec == 0) {
    iVar1 = FUN_005edc10();
    DAT_01ea96ec = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 5834 ; VA 0x005ee450 ; FUN_005ee450 */

void FUN_005ee450(void)

{
  int iVar1;
  
  if (DAT_01eaa59c == 0) {
    iVar1 = FUN_005edd10();
    DAT_01eaa59c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 5835 ; VA 0x005ee470 ; FUN_005ee470 */

void FUN_005ee470(void)

{
  int iVar1;
  
  if (DAT_01eaa7b4 == 0) {
    iVar1 = FUN_005eddf0();
    DAT_01eaa7b4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 5836 ; VA 0x005ee490 ; FUN_005ee490 */

void FUN_005ee490(void)

{
  int iVar1;
  
  if (DAT_01ea9f54 == 0) {
    iVar1 = FUN_005eded0();
    DAT_01ea9f54 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 5837 ; VA 0x005ee4b0 ; FUN_005ee4b0 */

void FUN_005ee4b0(void)

{
  int iVar1;
  
  if (DAT_01ea9b24 == 0) {
    iVar1 = FUN_005edfb0();
    DAT_01ea9b24 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 5838 ; VA 0x005ee4d0 ; FUN_005ee4d0 */

void FUN_005ee4d0(void)

{
  int iVar1;
  
  if (DAT_01ea9d3c == 0) {
    iVar1 = FUN_005ee090();
    DAT_01ea9d3c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 5839 ; VA 0x005ee4f0 ; FUN_005ee4f0 */

void FUN_005ee4f0(void)

{
  int iVar1;
  
  if (DAT_01eaa16c == 0) {
    iVar1 = FUN_005ee170();
    DAT_01eaa16c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 5840 ; VA 0x005ee510 ; FUN_005ee510 */

void FUN_005ee510(void)

{
  int iVar1;
  
  if (DAT_01ea990c == 0) {
    iVar1 = FUN_005ee250();
    DAT_01ea990c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 5841 ; VA 0x005ee530 ; FUN_005ee530 */

void FUN_005ee530(void)

{
  int iVar1;
  
  if (DAT_01eaa384 == 0) {
    iVar1 = FUN_005ee350();
    DAT_01eaa384 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 5842 ; VA 0x005ee550 ; FUN_005ee550 */

int __thiscall FUN_005ee550(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179bdf0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Network::CheatHandlingServerReplicator*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5843 ; VA 0x005ee622 ; Catch_All@005ee622 */

void Catch_All_005ee622(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5844 ; VA 0x005ee640 ; FUN_005ee640 */

int __thiscall FUN_005ee640(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179be00;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Network::Client*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5845 ; VA 0x005ee712 ; Catch_All@005ee712 */

void Catch_All_005ee712(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5846 ; VA 0x005ee730 ; FUN_005ee730 */

int __thiscall FUN_005ee730(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179be10;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::NetworkSettings*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5847 ; VA 0x005ee802 ; Catch_All@005ee802 */

void Catch_All_005ee802(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5848 ; VA 0x005ee820 ; FUN_005ee820 */

int __thiscall FUN_005ee820(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179be20;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Network::Server*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5849 ; VA 0x005ee8f2 ; Catch_All@005ee8f2 */

void Catch_All_005ee8f2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5850 ; VA 0x005ee920 ; FUN_005ee920 */

undefined4 * FUN_005ee920(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  int iVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179be63;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar10 = FUN_005ee350();
  uVar11 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar10 + 0x1dc) != (undefined4 *)0x0) {
    uVar11 = **(undefined4 **)(iVar10 + 0x1dc);
  }
  uVar11 = FUN_01675290(uVar11);
  uStack_8 = 1;
  iVar10 = FUN_01674e20(0x3f88);
  uStack_8._0_1_ = 2;
  if (iVar10 == 0) {
    uVar12 = 0;
  }
  else {
    uVar12 = *param_2;
    uVar2 = param_2[1];
    uVar3 = param_2[2];
    uVar4 = param_2[3];
    uVar5 = param_2[4];
    uVar6 = param_2[5];
    uVar7 = param_2[6];
    uVar8 = param_2[7];
    uVar9 = param_2[8];
    if (param_2[10] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[10] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uVar12 = FUN_00650560(uVar12,uVar2,uVar3,uVar4,uVar5,uVar6,uVar7,uVar8,uVar9,param_2[9],
                          param_2[10]);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_005ee550(uVar12,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar11);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5851 ; VA 0x005eea40 ; FUN_005eea40 */

undefined4 * FUN_005eea40(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179bea3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005edc10();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x450);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00688450();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_005ee640(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5852 ; VA 0x005eeb00 ; FUN_005eeb00 */

undefined4 * FUN_005eeb00(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179bee3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005edfb0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(200);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_006848d0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_005ee730(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5853 ; VA 0x005eebc0 ; FUN_005eebc0 */

undefined4 * FUN_005eebc0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179bf23;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005ee250();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x490);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00640650();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_005ee820(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5854 ; VA 0x005eec80 ; FUN_005eec80 */

undefined4 FUN_005eec80(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bf3c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaad0c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaad0c);
    if (DAT_01eaad0c == -1) {
      uStack_8 = 0;
      DAT_01eaad08 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eaad0c);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eaad08;
}



/* FUNCTION 5855 ; VA 0x005eed00 ; FUN_005eed00 */

undefined4 * FUN_005eed00(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bf7c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_018c8c88;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::runtime_error::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_std::runtime_error>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<struct_boost::exception_detail::error_info_injector<class_std::runtime_error>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_std::runtime_error>_>::
       vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5856 ; VA 0x005eede0 ; FUN_005eede0 */

undefined4 * FUN_005eede0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  param_1[3] = boost::exception::vftable;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0xffffffff;
  *param_1 = boost::exception_detail::error_info_injector<class_std::runtime_error>::vftable;
  param_1[3] = boost::exception_detail::error_info_injector<class_std::runtime_error>::vftable;
  return param_1;
}



/* FUNCTION 5857 ; VA 0x005eee40 ; FUN_005eee40 */

int FUN_005eee40(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01eaad00,&LAB_005ee910);
  uVar2 = FUN_005eec80();
  piVar3 = (int *)FUN_008aa140(uVar2);
  if (*piVar3 == 0) {
    if (DAT_01ea96ec == 0) {
      iVar4 = FUN_005edc10();
      DAT_01ea96ec = *(int *)(iVar4 + 4);
    }
    piVar5 = (int *)FUN_008a9ba0(auStack_c,DAT_01ea96ec);
    iVar4 = *piVar5;
    iVar1 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar3 = iVar4;
    piVar5 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar4 = piVar5[1] + -1;
      piVar5[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar4 = piVar5[2] + -1;
        piVar5[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_8[1] + -1;
      piStack_8[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar4 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return *piVar3;
  }
  return *piVar3;
}



/* FUNCTION 5858 ; VA 0x005eef10 ; FUN_005eef10 */

int FUN_005eef10(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar4 = *(int *)(param_1 + 0x34);
    if ((iVar4 != 0) && (param_1 = iVar4, *(int *)(iVar4 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar4 = *(int *)(param_1 + 0xc), iVar1 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
       (uint)*(ushort *)(iVar1 + 0x1da))) {
      FUN_005789c0(&DAT_01eaad00,&LAB_005ee910);
      uVar2 = FUN_005eec80();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (*piVar3 == 0) {
        if (DAT_01ea96ec == 0) {
          iVar4 = FUN_005edc10();
          DAT_01ea96ec = *(int *)(iVar4 + 4);
        }
        piVar5 = (int *)FUN_008a9ba0(auStack_c,DAT_01ea96ec);
        iVar4 = *piVar5;
        iVar1 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar3 = iVar4;
        piVar5 = (int *)piVar3[1];
        piVar3[1] = iVar1;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar4 = piVar5[1] + -1;
          piVar5[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar4 = piVar5[2] + -1;
            piVar5[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar4 = piStack_8[1] + -1;
          piStack_8[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar5 = piStack_8 + 2;
            iVar4 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar4 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      return *piVar3;
    }
  }
  return 0;
}



/* FUNCTION 5859 ; VA 0x005ef030 ; FUN_005ef030 */

int FUN_005ef030(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ea8a80,&LAB_0055d5a0);
  uVar3 = FUN_00560dc0();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_0093f210();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return *piVar4;
  }
  return *piVar4;
}



/* FUNCTION 5860 ; VA 0x005ef0f0 ; FUN_005ef0f0 */

int FUN_005ef0f0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01ea8a80,&LAB_0055d5a0);
      uVar3 = FUN_00560dc0();
      piVar4 = (int *)FUN_008aa140(uVar3);
      if (*piVar4 == 0) {
        uVar3 = FUN_0093f210();
        piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar4 = iVar1;
        piVar5 = (int *)piVar4[1];
        piVar4[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_8[1] + -1;
          piStack_8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar5 = piStack_8 + 2;
            iVar1 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      return *piVar4;
    }
  }
  return 0;
}



/* FUNCTION 5861 ; VA 0x005ef200 ; thunk_FUN_005f3000 */

undefined * thunk_FUN_005f3000(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c1cc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaaadc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaaadc);
    if (DAT_01eaaadc == -1) {
      uStack_8 = 0;
      FUN_009187f0();
      FUN_016f3654(&LAB_0187c040);
      FUN_016f37bf(&DAT_01eaaadc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eaaa78;
}



/* FUNCTION 5862 ; VA 0x005ef210 ; thunk_FUN_005f3090 */

undefined * thunk_FUN_005f3090(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c1ec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaa9a4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaa9a4);
    if (DAT_01eaa9a4 == -1) {
      uStack_8 = 0;
      FUN_00967bf0();
      FUN_016f3654(&LAB_0187c060);
      FUN_016f37bf(&DAT_01eaa9a4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eaa940;
}



/* FUNCTION 5863 ; VA 0x005ef220 ; thunk_FUN_005f3120 */

undefined * thunk_FUN_005f3120(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c20c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaaa74) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaaa74);
    if (DAT_01eaaa74 == -1) {
      uStack_8 = 0;
      FUN_00918850();
      FUN_016f3654(&LAB_0187c080);
      FUN_016f37bf(&DAT_01eaaa74);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eaaa10;
}



/* FUNCTION 5864 ; VA 0x005ef230 ; thunk_FUN_005f31b0 */

undefined * thunk_FUN_005f31b0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c22c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaa86c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaa86c);
    if (DAT_01eaa86c == -1) {
      uStack_8 = 0;
      FUN_009fe3d0();
      FUN_016f3654(&LAB_0187c0a0);
      FUN_016f37bf(&DAT_01eaa86c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eaa808;
}



/* FUNCTION 5865 ; VA 0x005ef240 ; thunk_FUN_005f32d0 */

undefined * thunk_FUN_005f32d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c26c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaab44) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaab44);
    if (DAT_01eaab44 == -1) {
      uStack_8 = 0;
      FUN_009188b0();
      FUN_016f3654(&LAB_0187c0e0);
      FUN_016f37bf(&DAT_01eaab44);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eaaae0;
}



/* FUNCTION 5866 ; VA 0x005ef250 ; thunk_FUN_005f33f0 */

undefined * thunk_FUN_005f33f0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c2ac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaaa0c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaaa0c);
    if (DAT_01eaaa0c == -1) {
      uStack_8 = 0;
      FUN_00967c50();
      FUN_016f3654(&LAB_0187c120);
      FUN_016f37bf(&DAT_01eaaa0c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eaa9a8;
}



/* FUNCTION 5867 ; VA 0x005ef260 ; thunk_FUN_005f3480 */

undefined * thunk_FUN_005f3480(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c2cc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaa8d4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaa8d4);
    if (DAT_01eaa8d4 == -1) {
      uStack_8 = 0;
      FUN_00967cb0();
      FUN_016f3654(&LAB_0187c140);
      FUN_016f37bf(&DAT_01eaa8d4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eaa870;
}



/* FUNCTION 5868 ; VA 0x005ef270 ; thunk_FUN_005f3510 */

undefined * thunk_FUN_005f3510(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c2ec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaa93c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaa93c);
    if (DAT_01eaa93c == -1) {
      uStack_8 = 0;
      FUN_00967d10();
      FUN_016f3654(&LAB_0187c160);
      FUN_016f37bf(&DAT_01eaa93c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eaa8d8;
}



/* FUNCTION 5869 ; VA 0x005ef280 ; FUN_005ef280 */

undefined4 * FUN_005ef280(undefined4 *param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bf98;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = GetProcessHeap(0,0x48);
  puVar3 = (undefined4 *)HeapAlloc(uVar2);
  if (puVar3 != (undefined4 *)0x0) {
    uStack_8 = 1;
    FUN_0056b3c0();
    *puVar3 = boost::detail::
              thread_data<class_boost::_bi::bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::DataModel>),class_boost::_bi::list1<class_boost::_bi::value<class_std::weak_ptr<class_RBX::DataModel>_>_>_>_>
              ::vftable;
    puVar3[0xf] = *param_1;
    puVar3[0x10] = 0;
    puVar3[0x11] = 0;
    puVar3[0x10] = param_1[1];
    puVar3[0x11] = param_1[2];
    param_1[1] = 0;
    param_1[2] = 0;
    ExceptionList = pvStack_10;
    return puVar3;
  }
  uVar2 = FUN_0054fbc0();
  uStack_8 = 0;
  FUN_005648a0(uVar2);
  pcVar1 = (code *)swi(3);
  puVar3 = (undefined4 *)(*pcVar1)();
  return puVar3;
}



/* FUNCTION 5870 ; VA 0x005ef312 ; Catch_All@005ef312 */

void Catch_All_005ef312(void)

{
  int unaff_EBP;
  
  FUN_00581530(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5871 ; VA 0x005ef340 ; FUN_005ef340 */

void FUN_005ef340(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_5c [44];
  undefined auStack_30 [32];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bfb8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_005eede0(auStack_30,param_1);
  uStack_8 = 0;
  FUN_005eed00(auStack_5c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_5c,&DAT_01c26488);
}



/* FUNCTION 5872 ; VA 0x005ef390 ; FUN_005ef390 */

int * __thiscall FUN_005ef390(int *param_1,undefined4 param_2,int param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined **ppuVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined **ppuVar5;
  
  ppuVar2 = (undefined **)
            FUN_00563d40(&DAT_018be080,
                         &std::basic_ostream<char,struct_std::char_traits<char>_>::vftable_meta_ptr,
                         &param_4);
  ppuVar5 = (undefined **)&DAT_018be0ec;
  if (ppuVar2 != &std::basic_ostream<char,struct_std::char_traits<char>_>::vftable_meta_ptr) {
    ppuVar5 = ppuVar2;
  }
  *param_1 = (int)(ppuVar5 + -0x62f820) >> 2;
  iVar3 = *(int *)(&DAT_018be080 + ((int)(ppuVar5 + -0x62f820) >> 2) * 4) + 1;
  param_1[2] = iVar3;
  if (iVar3 == 0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    puVar4 = (undefined4 *)FUN_00577ed0(iVar3);
  }
  param_1[3] = (int)puVar4;
  puVar1 = puVar4 + *(int *)(&DAT_018be080 + *param_1 * 4);
  for (; puVar4 != puVar1; puVar4 = puVar4 + 1) {
    *puVar4 = 0;
  }
  *(int *)param_3 = param_3;
  *(int *)(param_1[3] + *(int *)(&DAT_018be080 + *param_1 * 4) * 4) = param_3;
  *(int *)(param_3 + 4) = param_1[3] + *(int *)(&DAT_018be080 + *param_1 * 4) * 4;
  return param_1;
}



/* FUNCTION 5873 ; VA 0x005ef440 ; FUN_005ef440 */

undefined4 * __thiscall FUN_005ef440(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794104;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_018c8c88;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::runtime_error::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_std::runtime_error>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_std::runtime_error>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_std::runtime_error>_>::
       vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5874 ; VA 0x005ef520 ; FUN_005ef520 */

undefined4 * __thiscall FUN_005ef520(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791ff8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::runtime_error::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::error_info_injector<class_std::runtime_error>::vftable;
  param_1[3] = boost::exception_detail::error_info_injector<class_std::runtime_error>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5875 ; VA 0x005ef5c0 ; FUN_005ef5c0 */

undefined4 * __thiscall FUN_005ef5c0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  *param_1 = *param_2;
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  uVar4 = param_2[4];
  param_1[1] = param_2[1];
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  param_1[4] = uVar4;
  uVar2 = param_2[6];
  uVar3 = param_2[7];
  uVar4 = param_2[8];
  param_1[5] = param_2[5];
  param_1[6] = uVar2;
  param_1[7] = uVar3;
  param_1[8] = uVar4;
  param_1[9] = 0;
  param_1[10] = 0;
  if (param_2[10] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[10] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[9] = param_2[9];
  param_1[10] = param_2[10];
  param_1[0xc] = param_2[0xc];
  param_1[0xd] = param_2[0xd];
  return param_1;
}



/* FUNCTION 5876 ; VA 0x005ef620 ; FUN_005ef620 */

undefined4 * __thiscall FUN_005ef620(undefined4 *param_1,undefined4 *param_2)

{
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  return param_1;
}



/* FUNCTION 5877 ; VA 0x005ef640 ; FUN_005ef640 */

void __thiscall
FUN_005ef640(longlong *param_1,uint param_2,uint param_3,uint param_4,uint param_5,uint param_6)

{
  longlong lVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  undefined8 uVar7;
  
  if ((((-1 < (int)param_2) && (-1 < (int)param_3)) && (-1 < (int)param_4)) && (-1 < (int)param_6))
  {
    lVar1 = FUN_016f39b0((longlong)(int)param_3 * 0x3c + (longlong)(int)param_2 * 0xe10,1000000,0);
    *param_1 = (longlong)(int)param_4 * 1000000 + lVar1 + CONCAT44(param_6,param_5);
    return;
  }
  uVar7 = FUN_016f39b0((longlong)(int)((param_3 ^ (int)param_3 >> 0x1f) - ((int)param_3 >> 0x1f)) *
                       0x3c + (longlong)
                              (int)((param_2 ^ (int)param_2 >> 0x1f) - ((int)param_2 >> 0x1f)) *
                              0xe10,1000000,0);
  lVar1 = (longlong)(int)((param_4 ^ (int)param_4 >> 0x1f) - ((int)param_4 >> 0x1f)) * 1000000;
  iVar2 = (int)lVar1;
  uVar5 = -iVar2;
  uVar4 = (int)param_6 >> 0x1f;
  uVar6 = uVar5 - (uint)uVar7;
  uVar3 = (param_5 ^ uVar4) - uVar4;
  *(uint *)((int)param_1 + 4) =
       (((-(int)((ulonglong)uVar7 >> 0x20) - ((int)((ulonglong)lVar1 >> 0x20) + (uint)(iVar2 != 0)))
        - (uint)(uVar5 < (uint)uVar7)) -
       (((param_6 ^ uVar4) - uVar4) - (uint)((param_5 ^ uVar4) < uVar4))) - (uint)(uVar6 < uVar3);
  *(uint *)param_1 = uVar6 - uVar3;
  return;
}



/* FUNCTION 5878 ; VA 0x005ef740 ; FUN_005ef740 */

undefined4 * __thiscall FUN_005ef740(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  code *pcVar2;
  undefined8 uVar3;
  
  if (DAT_01ea94c0 == (code *)0x0) {
    uVar1 = GetModuleHandleA("KERNEL32.DLL","GetTickCount64");
    pcVar2 = (code *)GetProcAddress(uVar1);
    DAT_01ea94c0 = FUN_005efd30;
    if (pcVar2 != (code *)0x0) {
      DAT_01ea94c0 = pcVar2;
    }
  }
  uVar3 = (*DAT_01ea94c0)();
  *param_1 = (int)uVar3;
  param_1[2] = param_2;
  param_1[3] = param_3;
  param_1[1] = (int)((ulonglong)uVar3 >> 0x20);
  *(undefined *)(param_1 + 4) = 1;
  FUN_005f0a90(param_1 + 6,FUN_005f1e70);
  return param_1;
}



/* FUNCTION 5879 ; VA 0x005ef7b0 ; FUN_005ef7b0 */

void __fastcall FUN_005ef7b0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Network::Client>::vftable;
  uVar1 = FUN_005edc10(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5880 ; VA 0x005ef7f0 ; FUN_005ef7f0 */

void __fastcall FUN_005ef7f0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Network::Server>::vftable;
  uVar1 = FUN_005ee250(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5881 ; VA 0x005ef830 ; FUN_005ef830 */

void __fastcall FUN_005ef830(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_std::runtime_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5882 ; VA 0x005ef8a0 ; FUN_005ef8a0 */

void __fastcall FUN_005ef8a0(undefined4 *param_1)

{
  FUN_01674ea0(*param_1,0x18);
  return;
}



/* FUNCTION 5883 ; VA 0x005ef8b0 ; FUN_005ef8b0 */

void __fastcall FUN_005ef8b0(uint param_1)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar1 = *(int *)((-(uint)(param_1 != 0xfffffff4) & param_1) + 4);
  puVar6 = (undefined4 *)(-(uint)(iVar1 != 0) & iVar1 + 0x10U);
  puVar3 = (undefined4 *)*puVar6;
  while (puVar3 != puVar6) {
    puVar2 = (undefined4 *)*puVar3;
    FUN_0056e380();
    FUN_0056e380();
    FUN_01674ea0(puVar3 + -4,0x18);
    puVar3 = puVar2;
  }
  if (*(int *)(param_1 + 0x18) != 0) {
    iVar1 = *(int *)(param_1 + 0x1c);
    uVar5 = *(int *)(param_1 + 0x18) * 4;
    iVar4 = iVar1;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar1 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar1 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x18);
  return;
}



/* FUNCTION 5884 ; VA 0x005ef950 ; FUN_005ef950 */

void __fastcall FUN_005ef950(char *param_1)

{
  if (*param_1 != '\0') {
    FUN_0056e380();
    FUN_0056e380();
    *param_1 = '\0';
  }
  return;
}



/* FUNCTION 5885 ; VA 0x005ef970 ; FUN_005ef970 */

void __fastcall FUN_005ef970(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x28);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x005ef999. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 5886 ; VA 0x005ef9a0 ; FUN_005ef9a0 */

void __fastcall FUN_005ef9a0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_std::runtime_error>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_std::runtime_error>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_std::runtime_error>_>::
       vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::error_info_injector<class_std::runtime_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5887 ; VA 0x005efa38 ; FUN_005efa38 */

void FUN_005efa38(void)

{
  FUN_005efc40();
  return;
}



/* FUNCTION 5888 ; VA 0x005efa43 ; FUN_005efa43 */

void FUN_005efa43(void)

{
  FUN_005efc40();
  return;
}



/* FUNCTION 5889 ; VA 0x005efa4b ; FUN_005efa4b */

void FUN_005efa4b(void)

{
  FUN_005efc70();
  return;
}



/* FUNCTION 5890 ; VA 0x005efa60 ; FUN_005efa60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_005efa60(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Player::ChatMode>::vftable;
  _DAT_01eaa7d0 = _DAT_01eaa7d0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 5891 ; VA 0x005efa90 ; FUN_005efa90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_005efa90(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Players::ChatOption>::vftable;
  _DAT_01eaa7e8 = _DAT_01eaa7e8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 5892 ; VA 0x005efac0 ; FUN_005efac0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_005efac0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Player::ChatPrivacyMode>::vftable;
  _DAT_01eaa7d8 = _DAT_01eaa7d8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 5893 ; VA 0x005efaf0 ; FUN_005efaf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_005efaf0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Memory::DeveloperTag>::vftable;
  _DAT_01eaa800 = _DAT_01eaa800 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 5894 ; VA 0x005efb20 ; FUN_005efb20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_005efb20(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Network::FilterResult>::vftable;
  _DAT_01eaa7c0 = _DAT_01eaa7c0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 5895 ; VA 0x005efb50 ; FUN_005efb50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_005efb50(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::MembershipType>::vftable;
  _DAT_01eaa7c8 = _DAT_01eaa7c8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 5896 ; VA 0x005efb80 ; FUN_005efb80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_005efb80(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_PacketPriority>::vftable;
  _DAT_01eaa7b8 = _DAT_01eaa7b8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 5897 ; VA 0x005efbb0 ; FUN_005efbb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_005efbb0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Players::PlayerChatType>::vftable;
  _DAT_01eaa7e0 = _DAT_01eaa7e0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 5898 ; VA 0x005efbe0 ; FUN_005efbe0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_005efbe0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Players::ThumbnailSize>::vftable;
  _DAT_01eaa7f8 = _DAT_01eaa7f8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 5899 ; VA 0x005efc10 ; FUN_005efc10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_005efc10(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Players::ThumbnailType>::vftable;
  _DAT_01eaa7f0 = _DAT_01eaa7f0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 5900 ; VA 0x005efc40 ; FUN_005efc40 */

undefined4 __thiscall FUN_005efc40(undefined4 param_1,byte param_2)

{
  FUN_005ef9a0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 5901 ; VA 0x005efc70 ; FUN_005efc70 */

undefined4 * __thiscall FUN_005efc70(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_std::runtime_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5902 ; VA 0x005efcf0 ; FUN_005efcf0 */

int __thiscall FUN_005efcf0(int param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 0x44);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_016894b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 5903 ; VA 0x005efd30 ; FUN_005efd30 */

longlong FUN_005efd30(void)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  
  LOCK();
  if (DAT_01d59b80 == 0) {
    DAT_01d59b80 = 0;
  }
  uVar2 = DAT_01d59b80;
  UNLOCK();
  uVar1 = GetTickCount();
  uVar4 = uVar1 >> 0x1c;
  if (uVar2 == 0xffffffff) {
    LOCK();
    uVar2 = uVar4;
    if (DAT_01d59b80 != 0xffffffff) {
      uVar2 = DAT_01d59b80;
    }
    DAT_01d59b80 = uVar2;
    UNLOCK();
    uVar2 = uVar4;
  }
  else {
    uVar3 = uVar2 & 0xf;
    if (uVar4 != uVar3) {
      if ((uVar4 != uVar3 + 1) && ((0xfffffff < uVar1 || (uVar3 != 0xf)))) {
        return 0xffffffff;
      }
      LOCK();
      uVar4 = uVar2 + 1;
      if (uVar2 != DAT_01d59b80) {
        uVar4 = DAT_01d59b80;
      }
      DAT_01d59b80 = uVar4;
      UNLOCK();
      uVar2 = uVar2 + 1;
    }
  }
  return (ulonglong)uVar2 * 0x10000000 + (ulonglong)(uVar1 & 0xfffffff);
}



/* FUNCTION 5904 ; VA 0x005efdb0 ; FUN_005efdb0 */

int FUN_005efdb0(int param_1)

{
  return -0x4a1620bd - param_1;
}



/* FUNCTION 5905 ; VA 0x005efdbd ; FUN_005efdbd */

void FUN_005efdbd(void)

{
  FUN_005efdd0();
  return;
}



/* FUNCTION 5906 ; VA 0x005efdd0 ; FUN_005efdd0 */

int __fastcall FUN_005efdd0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c00b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_018c8c88;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = std::runtime_error::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_std::runtime_error>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_std::runtime_error>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<class_std::runtime_error>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 5907 ; VA 0x005efef0 ; FUN_005efef0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005efef0(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_005f3000();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01eaac9c) {
      FUN_016f3809(&DAT_01eaac9c);
      if (DAT_01eaac9c == -1) {
        _DAT_01eaac90 = FUN_005c65e0;
        _DAT_01eaac94 = FUN_005c65e0;
        _DAT_01eaac98 = _guard_check_icall;
        FUN_016f37bf(&DAT_01eaac9c);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01eaac90) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01eaac90;
  }
  return;
}



/* FUNCTION 5908 ; VA 0x005effb0 ; FUN_005effb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005effb0(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_005f3090();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01eaaccc) {
      FUN_016f3809(&DAT_01eaaccc);
      if (DAT_01eaaccc == -1) {
        _DAT_01eaacc0 = FUN_005c65e0;
        _DAT_01eaacc4 = FUN_005c65e0;
        _DAT_01eaacc8 = _guard_check_icall;
        FUN_016f37bf(&DAT_01eaaccc);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01eaacc0) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01eaacc0;
  }
  return;
}



/* FUNCTION 5909 ; VA 0x005f0070 ; FUN_005f0070 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005f0070(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_005f3120();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01eaacac) {
      FUN_016f3809(&DAT_01eaacac);
      if (DAT_01eaacac == -1) {
        _DAT_01eaaca0 = FUN_005c65e0;
        _DAT_01eaaca4 = FUN_005c65e0;
        _DAT_01eaaca8 = _guard_check_icall;
        FUN_016f37bf(&DAT_01eaacac);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01eaaca0) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01eaaca0;
  }
  return;
}



/* FUNCTION 5910 ; VA 0x005f0130 ; FUN_005f0130 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005f0130(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_005f31b0();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01eaacfc) {
      FUN_016f3809(&DAT_01eaacfc);
      if (DAT_01eaacfc == -1) {
        _DAT_01eaacf0 = FUN_005c65e0;
        _DAT_01eaacf4 = FUN_005c65e0;
        _DAT_01eaacf8 = _guard_check_icall;
        FUN_016f37bf(&DAT_01eaacfc);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01eaacf0) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01eaacf0;
  }
  return;
}



/* FUNCTION 5911 ; VA 0x005f01f0 ; FUN_005f01f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005f01f0(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_005f3240();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01eaac7c) {
      FUN_016f3809(&DAT_01eaac7c);
      if (DAT_01eaac7c == -1) {
        _DAT_01eaac70 = FUN_005c65e0;
        _DAT_01eaac74 = FUN_005c65e0;
        _DAT_01eaac78 = _guard_check_icall;
        FUN_016f37bf(&DAT_01eaac7c);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01eaac70) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01eaac70;
  }
  return;
}



/* FUNCTION 5912 ; VA 0x005f02b0 ; FUN_005f02b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005f02b0(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_005f32d0();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01eaac8c) {
      FUN_016f3809(&DAT_01eaac8c);
      if (DAT_01eaac8c == -1) {
        _DAT_01eaac80 = FUN_005c65e0;
        _DAT_01eaac84 = FUN_005c65e0;
        _DAT_01eaac88 = _guard_check_icall;
        FUN_016f37bf(&DAT_01eaac8c);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01eaac80) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01eaac80;
  }
  return;
}



/* FUNCTION 5913 ; VA 0x005f0370 ; FUN_005f0370 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005f0370(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_005f3360();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01eaac6c) {
      FUN_016f3809(&DAT_01eaac6c);
      if (DAT_01eaac6c == -1) {
        _DAT_01eaac60 = FUN_005c65e0;
        _DAT_01eaac64 = FUN_005c65e0;
        _DAT_01eaac68 = _guard_check_icall;
        FUN_016f37bf(&DAT_01eaac6c);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01eaac60) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01eaac60;
  }
  return;
}



/* FUNCTION 5914 ; VA 0x005f0430 ; FUN_005f0430 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005f0430(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_005f33f0();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01eaacbc) {
      FUN_016f3809(&DAT_01eaacbc);
      if (DAT_01eaacbc == -1) {
        _DAT_01eaacb0 = FUN_005c65e0;
        _DAT_01eaacb4 = FUN_005c65e0;
        _DAT_01eaacb8 = _guard_check_icall;
        FUN_016f37bf(&DAT_01eaacbc);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01eaacb0) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01eaacb0;
  }
  return;
}



/* FUNCTION 5915 ; VA 0x005f04f0 ; FUN_005f04f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005f04f0(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_005f3480();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01eaacec) {
      FUN_016f3809(&DAT_01eaacec);
      if (DAT_01eaacec == -1) {
        _DAT_01eaace0 = FUN_005c65e0;
        _DAT_01eaace4 = FUN_005c65e0;
        _DAT_01eaace8 = _guard_check_icall;
        FUN_016f37bf(&DAT_01eaacec);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01eaace0) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01eaace0;
  }
  return;
}



/* FUNCTION 5916 ; VA 0x005f05b0 ; FUN_005f05b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005f05b0(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_005f3510();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01eaacdc) {
      FUN_016f3809(&DAT_01eaacdc);
      if (DAT_01eaacdc == -1) {
        _DAT_01eaacd0 = FUN_005c65e0;
        _DAT_01eaacd4 = FUN_005c65e0;
        _DAT_01eaacd8 = _guard_check_icall;
        FUN_016f37bf(&DAT_01eaacdc);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01eaacd0) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01eaacd0;
  }
  return;
}



/* FUNCTION 5917 ; VA 0x005f0670 ; FUN_005f0670 */

void FUN_005f0670(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_005f3000();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 5918 ; VA 0x005f06b0 ; FUN_005f06b0 */

void FUN_005f06b0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_005f3090();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 5919 ; VA 0x005f06f0 ; FUN_005f06f0 */

void FUN_005f06f0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_005f3120();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 5920 ; VA 0x005f0730 ; FUN_005f0730 */

void FUN_005f0730(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_005f31b0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 5921 ; VA 0x005f0770 ; FUN_005f0770 */

void FUN_005f0770(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_005f3240();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 5922 ; VA 0x005f07b0 ; FUN_005f07b0 */

void FUN_005f07b0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_005f32d0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 5923 ; VA 0x005f07f0 ; FUN_005f07f0 */

void FUN_005f07f0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_005f3360();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 5924 ; VA 0x005f0830 ; FUN_005f0830 */

void FUN_005f0830(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_005f33f0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 5925 ; VA 0x005f0870 ; FUN_005f0870 */

void FUN_005f0870(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_005f3480();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 5926 ; VA 0x005f08b0 ; FUN_005f08b0 */

void FUN_005f08b0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_005f3510();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 5927 ; VA 0x005f08f0 ; FUN_005f08f0 */

undefined4 * FUN_005f08f0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_005eea40(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 5928 ; VA 0x005f0960 ; FUN_005f0960 */

undefined4 * FUN_005f0960(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_005eebc0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 5929 ; VA 0x005f09d0 ; FUN_005f09d0 */

undefined4 * FUN_005f09d0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  int *in_stack_00000030;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c028;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_005ee920(auStack_18,&stack0x00000008,&stack0x00000040,&stack0x00000044)
  ;
  *param_1 = *puVar5;
  uVar2 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  param_1[1] = uVar2;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar3 = piStack_14[2] + -1;
      piStack_14[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  piVar4 = in_stack_00000030;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    iVar3 = in_stack_00000030[1] + -1;
    in_stack_00000030[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*in_stack_00000030)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5930 ; VA 0x005f0a90 ; FUN_005f0a90 */

undefined4 FUN_005f0a90(undefined4 param_1,code *param_2)

{
  code *pcVar1;
  ushort uVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uVar5;
  uint extraout_ECX;
  uint extraout_ECX_00;
  uint extraout_ECX_01;
  uint extraout_ECX_02;
  uint uVar6;
  uint extraout_EDX;
  undefined8 uVar7;
  uint uVar8;
  uint uVar9;
  undefined auStack_48 [36];
  undefined8 uStack_24;
  uint uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  GetSystemTimeAsFileTime(&uStack_1c);
  uVar7 = FUN_016f3c60(uStack_1c + 0x2ac18000,
                       iStack_18 + -0x19db1df + (uint)(0xd53e7fff < uStack_1c),10,0);
  uStack_24 = FUN_016f3c60(uVar7,1000000,0);
  uStack_8 = (undefined4)((ulonglong)uStack_24 >> 0x20);
  uStack_10 = (undefined4)uStack_24;
  puVar3 = (undefined4 *)(*param_2)(&uStack_24,auStack_48);
  uVar6 = (uint)*(ushort *)(puVar3 + 3);
  uVar9 = 1;
  if (uVar6 + 1 < 2) {
    FUN_00588600(1,uVar6,0,1);
    uVar6 = extraout_EDX;
LAB_005f0bdf:
    uVar8 = 1;
    FUN_00588600(1,uVar6,1,uVar9);
    uVar6 = extraout_ECX;
LAB_005f0be9:
    FUN_00588640(1,uVar6,0,uVar8,uVar9);
    uVar6 = extraout_ECX_00;
LAB_005f0bf3:
    uVar5 = 1;
    FUN_00588640(1,uVar6,1,uVar8,uVar9);
    uVar6 = extraout_ECX_01;
  }
  else {
    if (0x1f < uVar6) goto LAB_005f0bdf;
    uVar9 = (uint)*(ushort *)(puVar3 + 3);
    uVar6 = (uint)(ushort)(*(short *)(puVar3 + 4) + 1U);
    uVar8 = 1;
    if (uVar6 + 1 < 2) goto LAB_005f0be9;
    if (0xc < uVar6) goto LAB_005f0bf3;
    uVar8 = (uint)(ushort)(*(short *)(puVar3 + 4) + 1U);
    uVar2 = *(short *)(puVar3 + 5) + 0x76c;
    uVar6 = (uint)uVar2;
    uVar5 = 0x578;
    if (0x578 < uVar6 + 1) {
      if (uVar2 < 0x2711) {
        FUN_0056a920(uVar2,uVar8,uVar9);
        iVar4 = FUN_016f39b0(uStack_10,uStack_8,1000000,0);
        FUN_005ef640(puVar3[2],puVar3[1],*puVar3,(int)uVar7 - iVar4,0);
        uStack_c = uStack_14;
        uStack_8 = uStack_10;
        FUN_005672c0(&param_2,&uStack_c);
        return param_1;
      }
      goto LAB_005f0c0a;
    }
  }
  FUN_00588680(0x578,uVar6,0,uVar5,uVar8);
  uVar6 = extraout_ECX_02;
LAB_005f0c0a:
  FUN_00588680(0x578,uVar6,1,uVar5,uVar8);
  pcVar1 = (code *)swi(3);
  uVar5 = (*pcVar1)();
  return uVar5;
}



/* FUNCTION 5931 ; VA 0x005f0c20 ; FUN_005f0c20 */

void FUN_005f0c20(undefined4 param_1)

{
  FUN_01674ea0(param_1,0x18);
  return;
}



/* FUNCTION 5932 ; VA 0x005f0c40 ; FUN_005f0c40 */

/* WARNING: Type propagation algorithm not settling */

undefined FUN_005f0c40(undefined4 *******param_1,undefined4 *******param_2,uint *param_3,
                      int *param_4,uint *param_5,undefined4 *******param_6,byte *param_7,
                      undefined *param_8,undefined4 *******param_9,uint *param_10,uint *param_11)

{
  int iVar1;
  undefined4 ******ppppppuVar2;
  uint uVar3;
  undefined4 *******pppppppuVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  byte bVar8;
  undefined4 ******ppppppuVar9;
  uint uVar10;
  undefined4 ******ppppppuVar11;
  char *pcVar12;
  undefined auStack_100 [160];
  int iStack_60;
  uint uStack_5c;
  undefined uStack_55;
  int iStack_54;
  undefined4 ******ppppppuStack_50;
  undefined4 *******pppppppuStack_4c;
  uint uStack_48;
  undefined4 *******pppppppuStack_44;
  undefined4 *******pppppppuStack_40;
  undefined4 ******ppppppuStack_3c;
  undefined4 ******ppppppuStack_38;
  undefined4 ******ppppppuStack_34;
  undefined4 ******ppppppuStack_30;
  undefined4 ******ppppppuStack_2c;
  undefined4 *******pppppppuStack_28;
  undefined4 ******ppppppuStack_24;
  undefined4 ******ppppppuStack_20;
  undefined4 ******ppppppuStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c05b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_3 = 0;
  *param_4 = 0;
  *param_5 = 0;
  iStack_60 = 0;
  *param_6 = (undefined4 ******)0x0;
  iStack_54 = 0;
  *param_7 = 0;
  *param_8 = 0;
  if (DAT_01d59b78 == '\0') {
    ppppppuStack_50 = param_1[4];
    param_6 = param_1;
    if ((undefined4 ******)0xf < param_1[5]) {
      param_6 = (undefined4 *******)*param_1;
    }
    if ((ppppppuStack_50 == (undefined4 ******)0x0) ||
       (iVar1 = FUN_0170db20(param_6,0x21,ppppppuStack_50), iVar1 == 0)) {
      ppppppuVar11 = (undefined4 ******)0xffffffff;
    }
    else {
      ppppppuVar11 = (undefined4 ******)(iVar1 - (int)param_6);
    }
    if (ppppppuVar11 == (undefined4 ******)0xffffffff) {
      if (param_2 == param_1) {
        ExceptionList = pvStack_10;
        return 2;
      }
      ppppppuVar11 = ppppppuStack_50;
      if ((undefined4 ******)0xf < param_1[5]) {
        param_1 = (undefined4 *******)*param_1;
      }
      goto LAB_005f0d35;
    }
    ppppppuStack_30 = (undefined4 ******)0x0;
    ppppppuStack_2c = (undefined4 ******)0xf;
    pppppppuStack_40 = (undefined4 *******)((uint)pppppppuStack_40 & 0xffffff00);
    ppppppuVar9 = ppppppuVar11;
    if (ppppppuStack_50 < ppppppuVar11) {
      ppppppuVar9 = ppppppuStack_50;
    }
    pppppppuVar4 = param_1;
    if ((undefined4 ******)0xf < param_1[5]) {
      pppppppuVar4 = (undefined4 *******)*param_1;
    }
    ppppppuStack_50 = (undefined4 ******)((int)ppppppuStack_50 + (-1 - (int)ppppppuVar11));
    FUN_005542c0(pppppppuVar4,ppppppuVar9);
    if ((undefined4 ********)param_2 != &pppppppuStack_40) {
      FUN_005507b0();
      pppppppuVar4 = pppppppuStack_40;
      pppppppuStack_40 = (undefined4 *******)((uint)pppppppuStack_40 & 0xffffff00);
      *param_2 = pppppppuVar4;
      param_2[1] = ppppppuStack_3c;
      param_2[2] = ppppppuStack_38;
      param_2[3] = ppppppuStack_34;
      param_2[4] = ppppppuStack_30;
      param_2[5] = ppppppuStack_2c;
      ppppppuStack_30 = (undefined4 ******)0x0;
      ppppppuStack_2c = (undefined4 ******)0xf;
    }
    FUN_005507b0();
    if (ppppppuStack_50 < 0x20) {
      ExceptionList = pvStack_10;
      return true;
    }
    FUN_00565610(param_1,(int)ppppppuVar11 + 1,0x20,(int)&param_6 + 3);
    uStack_8 = 1;
    ppppppuVar11 = (undefined4 ******)0x4;
    do {
      ppppppuVar9 = ppppppuVar11 + -1;
      uStack_18 = 0;
      uStack_14 = 0xf;
      pppppppuStack_28 = (undefined4 *******)((uint)pppppppuStack_28 & 0xffffff00);
      if (ppppppuStack_30 < ppppppuVar9) goto LAB_005f17f5;
      uVar10 = 2;
      if ((uint)((int)ppppppuStack_30 - (int)ppppppuVar9) < 2) {
        uVar10 = (int)ppppppuStack_30 - (int)ppppppuVar9;
      }
      pppppppuVar4 = &pppppppuStack_40;
      if ((undefined4 ******)0xf < ppppppuStack_2c) {
        pppppppuVar4 = pppppppuStack_40;
      }
      FUN_005542c0((int)pppppppuVar4 + (int)(ppppppuVar11 + -1),uVar10);
      pppppppuVar4 = &pppppppuStack_28;
      if (0xf < uStack_14) {
        pppppppuVar4 = pppppppuStack_28;
      }
      iVar1 = FUN_0171d7dd(pppppppuVar4,0,0x10);
      bVar8 = (byte)ppppppuVar9;
      *param_3 = *param_3 + (iVar1 << (bVar8 & 0x1f));
      if (0xf < uStack_14) {
        uVar10 = uStack_14 + 1;
        pppppppuVar4 = pppppppuStack_28;
        if (0xfff < uVar10) {
          pppppppuVar4 = (undefined4 *******)pppppppuStack_28[-1];
          uVar10 = uStack_14 + 0x24;
          if (0x1f < (uint)((int)pppppppuStack_28 + (-4 - (int)pppppppuVar4))) goto LAB_005f17ff;
        }
        FUN_01674ea0(pppppppuVar4,uVar10);
      }
      uStack_18 = 0;
      uStack_14 = 0xf;
      pppppppuStack_28 = (undefined4 *******)((uint)pppppppuStack_28 & 0xffffff00);
      if (ppppppuStack_30 < (undefined4 ******)((int)ppppppuVar11 - 2U)) goto LAB_005f17f5;
      uVar3 = (int)ppppppuStack_30 - (int)((int)ppppppuVar11 - 2U);
      uVar10 = 2;
      if (uVar3 < 2) {
        uVar10 = uVar3;
      }
      pppppppuVar4 = &pppppppuStack_40;
      if ((undefined4 ******)0xf < ppppppuStack_2c) {
        pppppppuVar4 = pppppppuStack_40;
      }
      FUN_005542c0((int)pppppppuVar4 + (int)ppppppuVar11 + -2,uVar10);
      pppppppuVar4 = &pppppppuStack_28;
      if (0xf < uStack_14) {
        pppppppuVar4 = pppppppuStack_28;
      }
      iVar1 = FUN_0171d7dd(pppppppuVar4,0,0x10);
      *param_4 = *param_4 + (iVar1 << (bVar8 & 0x1f));
      if (0xf < uStack_14) {
        uVar10 = uStack_14 + 1;
        pppppppuVar4 = pppppppuStack_28;
        if (0xfff < uVar10) {
          pppppppuVar4 = (undefined4 *******)pppppppuStack_28[-1];
          uVar10 = uStack_14 + 0x24;
          if (0x1f < (uint)((int)pppppppuStack_28 + (-4 - (int)pppppppuVar4))) goto LAB_005f17ff;
        }
        FUN_01674ea0(pppppppuVar4,uVar10);
      }
      uStack_18 = 0;
      uStack_14 = 0xf;
      pppppppuStack_28 = (undefined4 *******)((uint)pppppppuStack_28 & 0xffffff00);
      if (ppppppuStack_30 < ppppppuVar11) goto LAB_005f17f5;
      uVar10 = 2;
      if ((uint)((int)ppppppuStack_30 - (int)ppppppuVar11) < 2) {
        uVar10 = (int)ppppppuStack_30 - (int)ppppppuVar11;
      }
      pppppppuVar4 = &pppppppuStack_40;
      if ((undefined4 ******)0xf < ppppppuStack_2c) {
        pppppppuVar4 = pppppppuStack_40;
      }
      FUN_005542c0((int)pppppppuVar4 + (int)ppppppuVar11,uVar10);
      pppppppuVar4 = &pppppppuStack_28;
      if (0xf < uStack_14) {
        pppppppuVar4 = pppppppuStack_28;
      }
      iVar1 = FUN_0171d7dd(pppppppuVar4,0,0x10);
      *param_5 = *param_5 + (iVar1 << (bVar8 & 0x1f));
      if (0xf < uStack_14) {
        uVar10 = uStack_14 + 1;
        pppppppuVar4 = pppppppuStack_28;
        if (0xfff < uVar10) {
          pppppppuVar4 = (undefined4 *******)pppppppuStack_28[-1];
          uVar10 = uStack_14 + 0x24;
          if (0x1f < (uint)((int)pppppppuStack_28 + (-4 - (int)pppppppuVar4))) goto LAB_005f17ff;
        }
        FUN_01674ea0(pppppppuVar4,uVar10);
      }
      ppppppuVar9 = (undefined4 ******)((int)ppppppuVar11 + 2);
      uStack_18 = 0;
      uStack_14 = 0xf;
      pppppppuStack_28 = (undefined4 *******)((uint)pppppppuStack_28 & 0xffffff00);
      if (ppppppuStack_30 < ppppppuVar9) goto LAB_005f17f5;
      uVar10 = 2;
      if ((uint)((int)ppppppuStack_30 - (int)ppppppuVar9) < 2) {
        uVar10 = (int)ppppppuStack_30 - (int)ppppppuVar9;
      }
      pppppppuVar4 = &pppppppuStack_40;
      if ((undefined4 ******)0xf < ppppppuStack_2c) {
        pppppppuVar4 = pppppppuStack_40;
      }
      FUN_005542c0((int)pppppppuVar4 + (int)ppppppuVar9,uVar10);
      pppppppuVar4 = &pppppppuStack_28;
      if (0xf < uStack_14) {
        pppppppuVar4 = pppppppuStack_28;
      }
      iVar1 = FUN_0171d7dd(pppppppuVar4,0,0x10);
      iStack_54 = iStack_54 + (iVar1 << (bVar8 & 0x1f));
      if (0xf < uStack_14) {
        uVar10 = uStack_14 + 1;
        pppppppuVar4 = pppppppuStack_28;
        if (0xfff < uVar10) {
          pppppppuVar4 = (undefined4 *******)pppppppuStack_28[-1];
          uVar10 = uStack_14 + 0x24;
          if (0x1f < (uint)((int)pppppppuStack_28 + (-4 - (int)pppppppuVar4))) goto LAB_005f17ff;
        }
        FUN_01674ea0(pppppppuVar4,uVar10);
      }
      ppppppuVar11 = ppppppuVar11 + 2;
    } while (ppppppuVar11 < (undefined4 ******)0x24);
    iVar1 = FUN_005f2500(*param_3);
    *param_3 = iVar1 * 0x615aff1;
    iVar1 = FUN_005f2870(iVar1 * 0x615aff1,0,0,1);
    iVar5 = FUN_005f2500(*param_4);
    *param_4 = iVar5 * iVar1;
    iVar5 = FUN_005f2500(*param_5);
    *param_5 = iVar5 * iVar1;
    iVar6 = FUN_005f2500(iStack_54);
    param_4 = (int *)(iVar6 - *param_3 * iVar5 * iVar1 * *param_4);
    *param_7 = (byte)param_4 & 1;
    if ((DAT_01d5b030 != '\0') && (0x20 < ppppppuStack_50)) {
      ppppppuVar11 = (undefined4 ******)((int)param_1[4] - 1);
      if (ppppppuVar11 < param_1[4]) {
        if ((undefined4 ******)0xf < param_1[5]) {
          param_1 = (undefined4 *******)*param_1;
        }
        *param_8 = *(undefined *)((int)param_1 + (int)ppppppuVar11);
        goto LAB_005f1626;
      }
      goto LAB_005f17fa;
    }
LAB_005f1626:
    uStack_8 = 0xffffffff;
    if ((undefined4 ******)0xf < ppppppuStack_2c) {
      ppppppuVar11 = (undefined4 ******)((int)ppppppuStack_2c + 1);
      pppppppuVar4 = pppppppuStack_40;
      if ((undefined4 ******)0xfff < ppppppuVar11) {
        pppppppuVar4 = (undefined4 *******)pppppppuStack_40[-1];
        ppppppuVar11 = ppppppuStack_2c + 9;
        if (0x1f < (uint)((int)pppppppuStack_40 + (-4 - (int)pppppppuVar4))) goto LAB_005f17ff;
      }
      FUN_01674ea0(pppppppuVar4,ppppppuVar11);
    }
  }
  else {
    ppppppuVar11 = param_1[4];
    pppppppuStack_4c = param_1;
    if ((undefined4 ******)0xf < param_1[5]) {
      pppppppuStack_4c = (undefined4 *******)*param_1;
    }
    if ((ppppppuVar11 == (undefined4 ******)0x0) ||
       (iVar1 = FUN_0170db20(pppppppuStack_4c,0x60,ppppppuVar11), iVar1 == 0)) {
      pppppppuStack_4c = (undefined4 *******)0xffffffff;
LAB_005f0ceb:
      pppppppuStack_44 = param_1;
      if ((undefined4 ******)0xf < param_1[5]) {
        pppppppuStack_44 = (undefined4 *******)*param_1;
      }
      if ((ppppppuVar11 == (undefined4 ******)0x0) ||
         (iVar1 = FUN_0170db20(pppppppuStack_44,0x21,ppppppuVar11), iVar1 == 0)) {
        ppppppuVar9 = (undefined4 ******)0xffffffff;
      }
      else {
        ppppppuVar9 = (undefined4 ******)(iVar1 - (int)pppppppuStack_44);
      }
    }
    else {
      ppppppuVar9 = (undefined4 ******)(iVar1 - (int)pppppppuStack_4c);
      pppppppuStack_4c = (undefined4 *******)ppppppuVar9;
      if (ppppppuVar9 == (undefined4 ******)0xffffffff) goto LAB_005f0ceb;
    }
    if (ppppppuVar9 == (undefined4 ******)0xffffffff) {
      if (param_2 == param_1) {
        ExceptionList = pvStack_10;
        return 2;
      }
      if ((undefined4 ******)0xf < param_1[5]) {
        param_1 = (undefined4 *******)*param_1;
      }
LAB_005f0d35:
      FUN_005542c0(param_1,ppppppuVar11);
      ExceptionList = pvStack_10;
      return 2;
    }
    ppppppuStack_30 = (undefined4 ******)0x0;
    ppppppuStack_2c = (undefined4 ******)0xf;
    pppppppuStack_40 = (undefined4 *******)((uint)pppppppuStack_40 & 0xffffff00);
    iStack_60 = (uint)(pppppppuStack_4c != (undefined4 *******)0xffffffff) * 2 + 8;
    uStack_5c = iStack_60 * 4;
    ppppppuStack_50 = (undefined4 ******)((int)ppppppuVar11 + (-1 - (int)ppppppuVar9));
    ppppppuVar2 = ppppppuVar9;
    if (ppppppuVar11 < ppppppuVar9) {
      ppppppuVar2 = ppppppuVar11;
    }
    pppppppuVar4 = param_1;
    if ((undefined4 ******)0xf < param_1[5]) {
      pppppppuVar4 = (undefined4 *******)*param_1;
    }
    FUN_005542c0(pppppppuVar4,ppppppuVar2);
    pppppppuStack_44 = (undefined4 *******)0x2;
    if ((undefined4 ********)param_2 != &pppppppuStack_40) {
      FUN_005507b0();
      pppppppuVar4 = pppppppuStack_40;
      pppppppuStack_40 = (undefined4 *******)((uint)pppppppuStack_40 & 0xffffff00);
      *param_2 = pppppppuVar4;
      param_2[1] = ppppppuStack_3c;
      param_2[2] = ppppppuStack_38;
      param_2[3] = ppppppuStack_34;
      param_2[4] = ppppppuStack_30;
      param_2[5] = ppppppuStack_2c;
      ppppppuStack_30 = (undefined4 ******)0x0;
      ppppppuStack_2c = (undefined4 ******)0xf;
    }
    FUN_005507b0();
    if (ppppppuStack_50 < uStack_5c) {
      ExceptionList = pvStack_10;
      return true;
    }
    FUN_00565610(param_1,(int)ppppppuVar9 + 1,uStack_5c,&uStack_55);
    uStack_8 = 0;
    ppppppuVar11 = (undefined4 ******)0x4;
    uStack_48 = 0;
    do {
      uStack_18 = 0;
      uStack_14 = 0xf;
      pppppppuStack_28 = (undefined4 *******)((uint)pppppppuStack_28 & 0xffffff00);
      if (ppppppuStack_30 < ppppppuVar11 + -1) goto LAB_005f17f5;
      uVar3 = (int)ppppppuStack_30 - (int)(ppppppuVar11 + -1);
      uVar10 = 2;
      if (uVar3 < 2) {
        uVar10 = uVar3;
      }
      pppppppuVar4 = &pppppppuStack_40;
      if ((undefined4 ******)0xf < ppppppuStack_2c) {
        pppppppuVar4 = pppppppuStack_40;
      }
      FUN_005542c0((int)pppppppuVar4 + (int)(ppppppuVar11 + -1),uVar10);
      pppppppuVar4 = &pppppppuStack_28;
      if (0xf < uStack_14) {
        pppppppuVar4 = pppppppuStack_28;
      }
      iVar1 = FUN_0171d7dd(pppppppuVar4,0,0x10);
      *param_3 = *param_3 + (iVar1 << ((byte)uStack_48 & 0x1f));
      if (0xf < uStack_14) {
        uVar10 = uStack_14 + 1;
        pppppppuVar4 = pppppppuStack_28;
        if (0xfff < uVar10) {
          pppppppuVar4 = (undefined4 *******)pppppppuStack_28[-1];
          uVar10 = uStack_14 + 0x24;
          if (0x1f < (uint)((int)pppppppuStack_28 + (-4 - (int)pppppppuVar4))) goto LAB_005f17ff;
        }
        FUN_01674ea0(pppppppuVar4,uVar10);
      }
      uStack_18 = 0;
      uStack_14 = 0xf;
      pppppppuStack_28 = (undefined4 *******)((uint)pppppppuStack_28 & 0xffffff00);
      if (ppppppuStack_30 < (undefined4 ******)((int)ppppppuVar11 - 2U)) goto LAB_005f17f5;
      uVar3 = (int)ppppppuStack_30 - (int)((int)ppppppuVar11 - 2U);
      uVar10 = 2;
      if (uVar3 < 2) {
        uVar10 = uVar3;
      }
      pppppppuVar4 = &pppppppuStack_40;
      if ((undefined4 ******)0xf < ppppppuStack_2c) {
        pppppppuVar4 = pppppppuStack_40;
      }
      FUN_005542c0((int)pppppppuVar4 + (int)ppppppuVar11 + -2,uVar10);
      pppppppuVar4 = &pppppppuStack_28;
      if (0xf < uStack_14) {
        pppppppuVar4 = pppppppuStack_28;
      }
      iVar1 = FUN_0171d7dd(pppppppuVar4,0,0x10);
      *param_4 = *param_4 + (iVar1 << ((byte)uStack_48 & 0x1f));
      if (0xf < uStack_14) {
        uVar10 = uStack_14 + 1;
        pppppppuVar4 = pppppppuStack_28;
        if (0xfff < uVar10) {
          pppppppuVar4 = (undefined4 *******)pppppppuStack_28[-1];
          uVar10 = uStack_14 + 0x24;
          if (0x1f < (uint)((int)pppppppuStack_28 + (-4 - (int)pppppppuVar4))) goto LAB_005f17ff;
        }
        FUN_01674ea0(pppppppuVar4,uVar10);
      }
      uStack_18 = 0;
      uStack_14 = 0xf;
      pppppppuStack_28 = (undefined4 *******)((uint)pppppppuStack_28 & 0xffffff00);
      if (ppppppuStack_30 < ppppppuVar11) goto LAB_005f17f5;
      uVar10 = 2;
      if ((uint)((int)ppppppuStack_30 - (int)ppppppuVar11) < 2) {
        uVar10 = (int)ppppppuStack_30 - (int)ppppppuVar11;
      }
      pppppppuVar4 = &pppppppuStack_40;
      if ((undefined4 ******)0xf < ppppppuStack_2c) {
        pppppppuVar4 = pppppppuStack_40;
      }
      FUN_005542c0((int)pppppppuVar4 + (int)ppppppuVar11,uVar10);
      pppppppuVar4 = &pppppppuStack_28;
      if (0xf < uStack_14) {
        pppppppuVar4 = pppppppuStack_28;
      }
      iVar1 = FUN_0171d7dd(pppppppuVar4,0,0x10);
      *param_5 = *param_5 + (iVar1 << ((byte)uStack_48 & 0x1f));
      if (0xf < uStack_14) {
        uVar10 = uStack_14 + 1;
        pppppppuVar4 = pppppppuStack_28;
        if (0xfff < uVar10) {
          pppppppuVar4 = (undefined4 *******)pppppppuStack_28[-1];
          uVar10 = uStack_14 + 0x24;
          if (0x1f < (uint)((int)pppppppuStack_28 + (-4 - (int)pppppppuVar4))) goto LAB_005f17ff;
        }
        FUN_01674ea0(pppppppuVar4,uVar10);
      }
      ppppppuVar9 = (undefined4 ******)((int)ppppppuVar11 + 2);
      uStack_18 = 0;
      uStack_14 = 0xf;
      pppppppuStack_28 = (undefined4 *******)((uint)pppppppuStack_28 & 0xffffff00);
      if (ppppppuStack_30 < ppppppuVar9) goto LAB_005f17f5;
      uVar10 = 2;
      if ((uint)((int)ppppppuStack_30 - (int)ppppppuVar9) < 2) {
        uVar10 = (int)ppppppuStack_30 - (int)ppppppuVar9;
      }
      pppppppuVar4 = &pppppppuStack_40;
      if ((undefined4 ******)0xf < ppppppuStack_2c) {
        pppppppuVar4 = pppppppuStack_40;
      }
      FUN_005542c0((int)pppppppuVar4 + (int)ppppppuVar9,uVar10);
      pppppppuStack_44 = (undefined4 *******)((uint)pppppppuStack_44 | 0x3c);
      pppppppuVar4 = &pppppppuStack_28;
      if (0xf < uStack_14) {
        pppppppuVar4 = pppppppuStack_28;
      }
      iVar1 = FUN_0171d7dd(pppppppuVar4,0,0x10);
      iStack_54 = iStack_54 + (iVar1 << ((byte)uStack_48 & 0x1f));
      if (0xf < uStack_14) {
        uVar10 = uStack_14 + 1;
        pppppppuVar4 = pppppppuStack_28;
        if (0xfff < uVar10) {
          pppppppuVar4 = (undefined4 *******)pppppppuStack_28[-1];
          uVar10 = uStack_14 + 0x24;
          if (0x1f < (uint)((int)pppppppuStack_28 + (-4 - (int)pppppppuVar4))) goto LAB_005f17ff;
        }
        FUN_01674ea0(pppppppuVar4,uVar10);
      }
      if (pppppppuStack_4c == (undefined4 *******)0xffffffff) {
        iVar1 = 0;
      }
      else {
        ppppppuVar9 = ppppppuVar11 + 1;
        uStack_18 = 0;
        uStack_14 = 0xf;
        pppppppuStack_28 = (undefined4 *******)((uint)pppppppuStack_28 & 0xffffff00);
        if (ppppppuStack_30 < ppppppuVar9) goto LAB_005f17f5;
        uVar10 = 2;
        if ((uint)((int)ppppppuStack_30 - (int)ppppppuVar9) < 2) {
          uVar10 = (int)ppppppuStack_30 - (int)ppppppuVar9;
        }
        pppppppuVar4 = &pppppppuStack_40;
        if ((undefined4 ******)0xf < ppppppuStack_2c) {
          pppppppuVar4 = pppppppuStack_40;
        }
        FUN_005542c0((int)pppppppuVar4 + (int)ppppppuVar9,uVar10);
        pppppppuStack_44 = (undefined4 *******)((uint)pppppppuStack_44 | 0x41);
        pppppppuVar4 = &pppppppuStack_28;
        if (0xf < uStack_14) {
          pppppppuVar4 = pppppppuStack_28;
        }
        iVar1 = FUN_0171d7dd(pppppppuVar4,0,0x10);
        iVar1 = iVar1 << ((byte)uStack_48 & 0x1f);
      }
      *param_6 = (undefined4 ******)((int)*param_6 + iVar1);
      if (((uint)pppppppuStack_44 & 1) != 0) {
        pppppppuStack_44 = (undefined4 *******)((uint)pppppppuStack_44 & 0xfffffffe);
        FUN_005507b0();
      }
      ppppppuVar11 = (undefined4 ******)((int)ppppppuVar11 + iStack_60);
      uStack_48 = uStack_48 + 8;
    } while (uStack_48 < 0x20);
    iVar1 = FUN_005f2500(*param_3);
    *param_3 = iVar1 * 0x615aff1;
    iVar1 = FUN_005f2870(iVar1 * 0x615aff1,0,0,1);
    iVar5 = FUN_005f2500(*param_4);
    *param_4 = iVar5 * iVar1;
    iVar5 = FUN_005f2500(*param_5);
    *param_5 = iVar5 * iVar1;
    if (pppppppuStack_4c == (undefined4 *******)0xffffffff) {
      ppppppuVar11 = (undefined4 ******)0x0;
    }
    else {
      iVar5 = FUN_005f2500(*param_6);
      ppppppuVar11 = (undefined4 ******)(iVar5 * iVar1);
    }
    *param_6 = ppppppuVar11;
    uVar10 = *param_5;
    uVar3 = *param_3;
    iVar1 = *param_4;
    ppppppuVar9 = (undefined4 ******)0x1;
    if (pppppppuStack_4c != (undefined4 *******)0xffffffff) {
      ppppppuVar9 = ppppppuVar11;
    }
    iVar5 = FUN_005f2500(iStack_54);
    param_4 = (int *)(iVar5 - (int)ppppppuVar9 * uVar10 * uVar3 * iVar1);
    *param_7 = (byte)param_4 & 1;
    if (ppppppuStack_50 <= uStack_5c) {
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return true;
    }
    ppppppuVar11 = (undefined4 ******)((int)param_1[4] - 1);
    if (param_1[4] <= ppppppuVar11) {
LAB_005f17f5:
      FUN_00554050();
LAB_005f17fa:
      FUN_00554050();
LAB_005f17ff:
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    if ((undefined4 ******)0xf < param_1[5]) {
      param_1 = (undefined4 *******)*param_1;
    }
    uStack_8 = 0xffffffff;
    *param_8 = *(undefined *)((int)param_1 + (int)ppppppuVar11);
    FUN_005507b0();
  }
  *param_11 = (uint)*(ushort *)((int)param_3 + 2);
  uVar3 = *param_3 >> 1 & 0x7fff;
  *param_10 = uVar3;
  uVar10 = *param_5;
  if (uVar10 < 0x752fab0c) {
    if (uVar10 == 0x752fab0b) {
      pcVar12 = "Osx";
      goto LAB_005f1711;
    }
    if (uVar10 < 0x4beda922) {
      if (uVar10 == 0x4beda921) {
        pcVar12 = "Win32";
        goto LAB_005f1711;
      }
      if (uVar10 == 0xc57b823) {
        pcVar12 = "Ios";
        goto LAB_005f1711;
      }
      if (uVar10 == 0x443921d5) {
        pcVar12 = "Uwp";
        goto LAB_005f1711;
      }
    }
    else if (uVar10 == 0x71375635) {
      pcVar12 = "Android";
      goto LAB_005f1711;
    }
  }
  else if (uVar10 < 0xeff3f3e6) {
    if (uVar10 == 0xeff3f3e5) {
      pcVar12 = "Linux";
      goto LAB_005f1711;
    }
    if (uVar10 == 0x9d49834b) {
      pcVar12 = "Xbox";
      goto LAB_005f1711;
    }
    if (uVar10 == 0xe74bdb5b) {
      pcVar12 = "PlatformDev";
      goto LAB_005f1711;
    }
  }
  else if (uVar10 == 0xf938d287) {
    pcVar12 = "SecurityDev";
    goto LAB_005f1711;
  }
  pcVar12 = "Invalid";
LAB_005f1711:
  uVar10 = *param_11;
  FUN_00565940(3,1);
  uStack_8 = 2;
  uVar7 = FUN_00558890(auStack_100,pcVar12,0x2e);
  FUN_005ed940(uVar7);
  uVar7 = FUN_0056ef60(uVar3,0x2e);
  FUN_005ed940(uVar7);
  uVar7 = FUN_0056ef60(uVar10,&DAT_018c8cbc);
  FUN_00558890(uVar7);
  FUN_0058c420(&pppppppuStack_28);
  pppppppuVar4 = param_9;
  if ((undefined4 ********)param_9 == &pppppppuStack_28) {
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      pppppppuVar4 = pppppppuStack_28;
      if (0xfff < uVar10) {
        pppppppuVar4 = (undefined4 *******)pppppppuStack_28[-1];
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)pppppppuStack_28 + (-4 - (int)pppppppuVar4))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppppuVar4,uVar10);
    }
  }
  else {
    FUN_005507b0();
    *pppppppuVar4 = pppppppuStack_28;
    pppppppuVar4[1] = ppppppuStack_24;
    pppppppuVar4[2] = ppppppuStack_20;
    pppppppuVar4[3] = ppppppuStack_1c;
    *(ulonglong *)(pppppppuVar4 + 4) = CONCAT44(uStack_14,uStack_18);
  }
  FUN_005705c0();
  ExceptionList = pvStack_10;
  return ((uint)param_4 & 0xfffffffe) != 0;
}



/* FUNCTION 5933 ; VA 0x005f1810 ; FUN_005f1810 */

undefined4 FUN_005f1810(undefined4 param_1,undefined4 *param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  byte bVar2;
  uint uVar3;
  undefined auStack_110 [16];
  undefined auStack_100 [16];
  undefined auStack_f0 [16];
  undefined auStack_e0 [16];
  undefined auStack_d0 [32];
  int aiStack_b0 [16];
  undefined auStack_70 [96];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c07b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00565940(3,1);
  uStack_8 = 0;
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_0055b3b0(aiStack_b0,param_2,*puVar1);
  if (DAT_01d59b70 == '\0') {
    FUN_00558890(aiStack_b0,&DAT_018c8d18);
    uVar3 = 0;
    do {
      FUN_00585a70((int)aiStack_b0 + *(int *)(aiStack_b0[0] + 4));
      puVar1 = (undefined4 *)FUN_016df519(auStack_100,2,0);
      (*(code *)*puVar1)((int)aiStack_b0 + *(int *)(aiStack_b0[0] + 4),puVar1[2],puVar1[3]);
      auStack_70[*(int *)(aiStack_b0[0] + 4)] = 0x30;
      bVar2 = (byte)uVar3;
      FUN_0056ef60(0x409dcfe6U >> (bVar2 & 0x1f) & 0xff);
      FUN_00585a70((int)aiStack_b0 + *(int *)(aiStack_b0[0] + 4));
      puVar1 = (undefined4 *)FUN_016df519(auStack_f0,2,0);
      (*(code *)*puVar1)((int)aiStack_b0 + *(int *)(aiStack_b0[0] + 4),puVar1[2],puVar1[3]);
      auStack_70[*(int *)(aiStack_b0[0] + 4)] = 0x30;
      FUN_0056ef60(0xe68b15a8U >> (bVar2 & 0x1f) & 0xff);
      FUN_00585a70((int)aiStack_b0 + *(int *)(aiStack_b0[0] + 4));
      puVar1 = (undefined4 *)FUN_016df519(auStack_e0,2,0);
      (*(code *)*puVar1)((int)aiStack_b0 + *(int *)(aiStack_b0[0] + 4),puVar1[2],puVar1[3]);
      auStack_70[*(int *)(aiStack_b0[0] + 4)] = 0x30;
      FUN_0056ef60(0x8c22d8e5U >> (bVar2 & 0x1f) & 0xff);
      FUN_00585a70((int)aiStack_b0 + *(int *)(aiStack_b0[0] + 4));
      puVar1 = (undefined4 *)FUN_016df519(auStack_d0,2,0);
      (*(code *)*puVar1)((int)aiStack_b0 + *(int *)(aiStack_b0[0] + 4),puVar1[2],puVar1[3]);
      auStack_70[*(int *)(aiStack_b0[0] + 4)] = 0x30;
      FUN_0056ef60(0xe021e6d6U >> (bVar2 & 0x1f) & 0xff);
      uVar3 = uVar3 + 8;
    } while (uVar3 < 0x20);
  }
  else {
    FUN_00558890(aiStack_b0,&DAT_018c8d14);
    uVar3 = 0;
    do {
      FUN_00585a70((int)aiStack_b0 + *(int *)(aiStack_b0[0] + 4));
      puVar1 = (undefined4 *)FUN_016df519(auStack_110,2,0);
      (*(code *)*puVar1)((int)aiStack_b0 + *(int *)(aiStack_b0[0] + 4),puVar1[2],puVar1[3]);
      auStack_70[*(int *)(aiStack_b0[0] + 4)] = 0x30;
      bVar2 = (byte)uVar3;
      FUN_0056ef60(0x409dcfe6U >> (bVar2 & 0x1f) & 0xff);
      FUN_00585a70((int)aiStack_b0 + *(int *)(aiStack_b0[0] + 4));
      puVar1 = (undefined4 *)FUN_016df519(auStack_d0,2,0);
      (*(code *)*puVar1)((int)aiStack_b0 + *(int *)(aiStack_b0[0] + 4),puVar1[2],puVar1[3]);
      auStack_70[*(int *)(aiStack_b0[0] + 4)] = 0x30;
      FUN_0056ef60(0xe68b15a8U >> (bVar2 & 0x1f) & 0xff);
      FUN_00585a70((int)aiStack_b0 + *(int *)(aiStack_b0[0] + 4));
      puVar1 = (undefined4 *)FUN_016df519(auStack_e0,2,0);
      (*(code *)*puVar1)((int)aiStack_b0 + *(int *)(aiStack_b0[0] + 4),puVar1[2],puVar1[3]);
      auStack_70[*(int *)(aiStack_b0[0] + 4)] = 0x30;
      FUN_0056ef60(0x8c22d8e5U >> (bVar2 & 0x1f) & 0xff);
      FUN_00585a70((int)aiStack_b0 + *(int *)(aiStack_b0[0] + 4));
      puVar1 = (undefined4 *)FUN_016df519(auStack_f0,2,0);
      (*(code *)*puVar1)((int)aiStack_b0 + *(int *)(aiStack_b0[0] + 4),puVar1[2],puVar1[3]);
      auStack_70[*(int *)(aiStack_b0[0] + 4)] = 0x30;
      FUN_0056ef60(0x2b509597U >> (bVar2 & 0x1f) & 0xff);
      FUN_00585a70((int)aiStack_b0 + *(int *)(aiStack_b0[0] + 4));
      puVar1 = (undefined4 *)FUN_016df519(auStack_100,2,0);
      (*(code *)*puVar1)((int)aiStack_b0 + *(int *)(aiStack_b0[0] + 4),puVar1[2],puVar1[3]);
      auStack_70[*(int *)(aiStack_b0[0] + 4)] = 0x30;
      FUN_0056ef60(0xc26bde65U >> (bVar2 & 0x1f) & 0xff);
      uVar3 = uVar3 + 8;
    } while (uVar3 < 0x20);
  }
  if ((char)param_3 != '\0') {
    FUN_005ed940(aiStack_b0,param_3);
  }
  FUN_0058c420(param_1);
  FUN_005705c0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5934 ; VA 0x005f1cd0 ; FUN_005f1cd0 */

undefined4 __fastcall FUN_005f1cd0(int param_1)

{
  int iVar1;
  
  if (*(int *)(param_1 + 4) != 0) {
    iVar1 = *(int *)(*(int *)(param_1 + 4) + 4);
    return CONCAT31((int3)((uint)iVar1 >> 8),iVar1 == 0);
  }
  return 1;
}



/* FUNCTION 5935 ; VA 0x005f1cf0 ; FUN_005f1cf0 */

void FUN_005f1cf0(undefined4 *param_1,uint param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uVar4 = 0;
  uStack_14 = 0;
  uStack_10 = 0;
  uStack_c = 0;
  uStack_8 = 0;
  uVar2 = param_2;
  iVar3 = param_3;
  do {
    *(char *)((int)&uStack_24 + uVar4 * 2) = (char)uVar2;
    *(char *)((int)&uStack_24 + uVar4 * 2 + 1) = (char)iVar3;
    uVar2 = (uVar2 >> 8) + iVar3;
    uVar4 = uVar4 + 1;
    iVar3 = iVar3 * 0x100 + uVar2;
  } while (uVar4 < 0x10);
  puVar1 = param_1 + 4;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  FUN_015318b0(param_1,*puVar1,0,&uStack_24,param_2,param_3);
  return;
}



/* FUNCTION 5936 ; VA 0x005f1d60 ; FUN_005f1d60 */

undefined4 FUN_005f1d60(undefined4 param_1,undefined4 param_2)

{
  uint uVar1;
  uint uVar2;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  char acStack_1c [4];
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c0a0;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("common/challenge",0x10);
  uStack_8 = 0;
  FUN_00a34a10(acStack_1c,auStack_34,param_2,1);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (0xf < uStack_20) {
    uVar2 = uStack_20 + 1;
    uVar1 = auStack_34[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_34[0] - 4);
      uVar2 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  if (acStack_1c[0] == '\0') {
    ExceptionList = pvStack_10;
    return 0;
  }
  FUN_00886840(auStack_18);
  if (acStack_1c[0] != '\0') {
    FUN_0056e380();
    FUN_0056e380();
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 5937 ; VA 0x005f1e60 ; FUN_005f1e60 */

uint __fastcall FUN_005f1e60(int param_1)

{
  return param_1 - 0xcU & -(uint)(param_1 != 0);
}



/* FUNCTION 5938 ; VA 0x005f1e70 ; FUN_005f1e70 */

void FUN_005f1e70(undefined4 param_1)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c0b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_017243c8(param_1);
  if (iVar2 != 0) {
    ExceptionList = pvStack_10;
    return;
  }
  uVar3 = FUN_00550130("could not convert calendar time to UTC time");
  uStack_8 = 0;
  FUN_005ef340(uVar3);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 5939 ; VA 0x005f1f00 ; FUN_005f1f00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_005f1f00(void)

{
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c0e7;
  pvStack_10 = ExceptionList;
  if (DAT_01ea94c8 == '\0') {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaac5c) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eaac5c);
      if (DAT_01eaac5c == -1) {
        uStack_8 = 0;
        _DAT_01eaac1c = FUN_01674e20(0x18,&DAT_01eaac18);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_005ef390(&uStack_11,-(uint)(_DAT_01eaac1c != 0) & _DAT_01eaac1c + 0x10U,0);
        _DAT_01eaac38 = 0x3f800000;
        _DAT_01eaac3c = 0xffffffff;
        if ((float)((double)*(int *)(&DAT_018be080 + DAT_01eaac28 * 4) +
                   (double)(&DAT_018c0d90)[-(*(int *)(&DAT_018be080 + DAT_01eaac28 * 4) >> 0x1f)]) <
            DAT_018c0d80) {
          _DAT_01eaac3c = FUN_016f3cd0();
        }
        _DAT_01eaac40 = 0;
        InitializeCriticalSection(&DAT_01eaac44);
        FUN_016f3654(&LAB_0187bf60);
        FUN_016f37bf(&DAT_01eaac5c);
      }
    }
    DAT_01ea94cc = &DAT_01eaac18;
    DAT_01ea94d0 = &DAT_01eaac44;
    DAT_01ea94c8 = '\x01';
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 5940 ; VA 0x005f2040 ; FUN_005f2040 */

void FUN_005f2040(void)

{
  FUN_005542c0(&DAT_018bc9b8,0);
  FUN_00554150(&DAT_018c8ed0,1);
  FUN_00592760(0x11);
  return;
}



/* FUNCTION 5941 ; VA 0x005f2070 ; FUN_005f2070 */

void FUN_005f2070(void)

{
  uint auStack_50 [2];
  undefined auStack_48 [24];
  uint auStack_30 [2];
  code *apcStack_28 [6];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c110;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018c8ec8,1);
  FUN_00592760(0x4f);
  FUN_005f21a0();
  DAT_01ea94bd = 1;
  auStack_30[0] = 0;
  FUN_005f27f0(apcStack_28,apcStack_28,2);
  apcStack_28[0] = FUN_005f09d0;
  auStack_30[0] = 0x18c8f41;
  auStack_50[0] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_005880d0(auStack_30);
  FUN_005880d0(&DAT_01ead770);
  FUN_005880d0(auStack_50);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (auStack_50[0] != 0) {
    if (((auStack_50[0] & 1) == 0) && (*(code **)(auStack_50[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_50[0] & 0xfffffffe))(auStack_48,auStack_48,2);
    }
    auStack_50[0] = 0;
  }
  uStack_8 = 3;
  if (auStack_30[0] != 0) {
    if (((auStack_30[0] & 1) == 0) && (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_30[0] & 0xfffffffe))(apcStack_28,apcStack_28,2);
    }
    auStack_30[0] = 0;
  }
  uStack_8 = 0xffffffff;
  FUN_00554150(&DAT_018c8ecc,1);
  FUN_00592760(0x45);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5942 ; VA 0x005f21a0 ; FUN_005f21a0 */

uint FUN_005f21a0(void)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined auStack_20 [4];
  int *piStack_1c;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c130;
  pvStack_10 = ExceptionList;
  DAT_01ea94bd = 0;
  ExceptionList = &pvStack_10;
  FUN_005edc10();
  FUN_005ee250();
  FUN_00554150(&DAT_018c8ed0,1);
  FUN_00913630();
  FUN_00961580();
  FUN_0090de90();
  FUN_005edfb0();
  uVar4 = FUN_00592760(0x11);
  if (DAT_01ea94c4 == 0) {
    piVar5 = (int *)FUN_00910d90();
    cStack_14 = '\0';
    iVar3 = *piVar5;
    puStack_18 = (uint *)(iVar3 + 0x94);
    uVar4 = FUN_00587410();
    uStack_8 = 0;
    if (DAT_01ea94c4 == 0) {
      FUN_005eeb00(auStack_20);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      uVar4 = FUN_008a65e0(iVar3,0);
      if (piStack_1c != (int *)0x0) {
        LOCK();
        puVar1 = (uint *)(piStack_1c + 1);
        uVar2 = *puVar1;
        uVar4 = *puVar1;
        *puVar1 = uVar2 - 1;
        UNLOCK();
        if (uVar2 - 1 == 0) {
          uVar4 = (**(code **)*piStack_1c)();
          LOCK();
          piVar5 = piStack_1c + 2;
          iVar3 = *piVar5;
          *piVar5 = *piVar5 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            uVar4 = (**(code **)(*piStack_1c + 4))();
          }
        }
      }
    }
    uStack_8 = 2;
    if (cStack_14 != '\0') {
      LOCK();
      uVar4 = *puStack_18;
      *puStack_18 = *puStack_18 + 0x80000000;
      UNLOCK();
      if (((uVar4 & 0x40000000) == 0) && (-0x80000000 < (int)uVar4)) {
        LOCK();
        uVar2 = *puStack_18;
        *puStack_18 = *puStack_18 | 0x40000000;
        UNLOCK();
        if ((uVar2 >> 0x1e & 1) == 0) {
          uVar6 = FUN_00554e40();
          uVar4 = SetEvent(uVar6);
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 5943 ; VA 0x005f22d0 ; FUN_005f22d0 */

/* WARNING: Removing unreachable block (ram,0x005f23a3) */
/* WARNING: Removing unreachable block (ram,0x005f23ac) */
/* WARNING: Removing unreachable block (ram,0x005f23ba) */
/* WARNING: Removing unreachable block (ram,0x005f23c1) */

undefined4 *
FUN_005f22d0(undefined4 *param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c148;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)
           (*(code *)*param_2)(auStack_18,param_3,param_4,param_5,param_6,param_7,param_8,param_9,
                               param_10,param_11,param_12,param_13);
  *param_1 = *puVar3;
  uVar1 = puVar3[1];
  *puVar3 = 0;
  puVar3[1] = 0;
  param_1[1] = uVar1;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar2 = piStack_14[2] + -1;
      piStack_14[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5944 ; VA 0x005f23f0 ; FUN_005f23f0 */

int FUN_005f23f0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c168;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_005f1cd0();
  cVar3 = (char)iVar4;
  while (cVar3 == '\0') {
    FUN_005ef740(0x5dc,0);
    FUN_01689e80(0xffffffff);
    iVar4 = FUN_005f1cd0();
    cVar3 = (char)iVar4;
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 5945 ; VA 0x005f2470 ; FUN_005f2470 */

undefined FUN_005f2470(void)

{
  return DAT_01ea94bd;
}



/* FUNCTION 5946 ; VA 0x005f2480 ; FUN_005f2480 */

uint FUN_005f2480(void)

{
  int iVar1;
  
  iVar1 = FUN_005edc10();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 5947 ; VA 0x005f24a0 ; FUN_005f24a0 */

uint FUN_005f24a0(void)

{
  int iVar1;
  
  iVar1 = FUN_005ee250();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 5948 ; VA 0x005f24c0 ; FUN_005f24c0 */

uint FUN_005f24c0(void)

{
  int iVar1;
  
  iVar1 = FUN_005edc10();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 5949 ; VA 0x005f24e0 ; FUN_005f24e0 */

uint FUN_005f24e0(void)

{
  int iVar1;
  
  iVar1 = FUN_005ee250();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 5950 ; VA 0x005f2500 ; FUN_005f2500 */

uint FUN_005f2500(uint param_1)

{
  byte bVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  
  uVar4 = 0;
  uVar2 = 0;
  do {
    uVar3 = ((&DAT_018c8b38)[uVar2] & param_1) -
            (((&DAT_018c8b38)[uVar2] & param_1) >> 1 & 0x55555555);
    uVar3 = (uVar3 >> 2 & 0x33333333) + (uVar3 & 0x33333333);
    bVar1 = (byte)uVar2;
    uVar2 = uVar2 + 1;
    uVar4 = uVar4 | (((uVar3 >> 4) + uVar3 & 0xff0f0f0f) * -0xfefeff >> 0x18 & 1) << (bVar1 & 0x1f);
  } while (uVar2 < 0x20);
  return uVar4;
}



/* FUNCTION 5951 ; VA 0x005f2560 ; FUN_005f2560 */

void FUN_005f2560(void)

{
  FUN_009cb1c0();
  return;
}



/* FUNCTION 5952 ; VA 0x005f2570 ; FUN_005f2570 */

void FUN_005f2570(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_005f3000();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 5953 ; VA 0x005f25b0 ; FUN_005f25b0 */

void FUN_005f25b0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_005f3090();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 5954 ; VA 0x005f25f0 ; FUN_005f25f0 */

void FUN_005f25f0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_005f3120();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 5955 ; VA 0x005f2630 ; FUN_005f2630 */

void FUN_005f2630(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_005f31b0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 5956 ; VA 0x005f2670 ; FUN_005f2670 */

void FUN_005f2670(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_005f3240();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 5957 ; VA 0x005f26b0 ; FUN_005f26b0 */

void FUN_005f26b0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_005f32d0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 5958 ; VA 0x005f26f0 ; FUN_005f26f0 */

void FUN_005f26f0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_005f3360();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 5959 ; VA 0x005f2730 ; FUN_005f2730 */

void FUN_005f2730(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_005f33f0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 5960 ; VA 0x005f2770 ; FUN_005f2770 */

void FUN_005f2770(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_005f3480();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 5961 ; VA 0x005f27b0 ; FUN_005f27b0 */

void FUN_005f27b0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_005f3510();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 5962 ; VA 0x005f27f0 ; FUN_005f27f0 */

void FUN_005f27f0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      *param_2 = *param_1;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d9586c);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&TypeDescriptor_01d95868;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 5963 ; VA 0x005f2870 ; FUN_005f2870 */

undefined8 FUN_005f2870(uint param_1,int param_2,uint param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  bool bVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  uint uStack_28;
  int iStack_24;
  int iStack_1c;
  uint uStack_18;
  int iStack_14;
  uint uStack_10;
  uint uStack_c;
  int iStack_8;
  
  iStack_8 = param_4;
  uStack_28 = 0;
  uStack_10 = 1;
  iStack_14 = 0;
  uStack_c = param_3;
  uStack_18 = param_1;
  iStack_1c = param_2;
  iStack_24 = 0;
  iVar1 = iStack_14;
  uVar4 = uStack_10;
  if (param_1 == 0 && param_2 == 0) {
    iStack_14 = 0;
    uStack_10 = 0;
  }
  else {
    do {
      uStack_10 = uVar4;
      iStack_14 = iVar1;
      iVar3 = iStack_8;
      uVar2 = uStack_c;
      uVar6 = FUN_016f3900(uStack_c,iStack_8,uStack_18,iStack_1c);
      uVar7 = FUN_016f39b0(uVar6,uStack_10,iStack_14);
      bVar5 = uStack_28 < (uint)uVar7;
      uVar4 = uStack_28 - (uint)uVar7;
      iVar1 = iStack_24 - (int)((ulonglong)uVar7 >> 0x20);
      uStack_c = uStack_18;
      iStack_8 = iStack_1c;
      uVar6 = FUN_016f39b0(uVar6,uStack_18,iStack_1c);
      uStack_18 = uVar2 - (uint)uVar6;
      iStack_1c = (iVar3 - (int)((ulonglong)uVar6 >> 0x20)) - (uint)(uVar2 < (uint)uVar6);
      iStack_24 = iStack_14;
      uStack_28 = uStack_10;
      iVar1 = iVar1 - (uint)bVar5;
    } while (uStack_18 != 0 || iStack_1c != 0);
    if ((iStack_14 < 1) && (iStack_14 < 0)) {
      return CONCAT44(iStack_14 + param_4 + (uint)CARRY4(uStack_10,param_3),uStack_10 + param_3);
    }
  }
  return CONCAT44(iStack_14,uStack_10);
}



/* FUNCTION 5964 ; VA 0x005f2960 ; FUN_005f2960 */

undefined FUN_005f2960(undefined8 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                      int param_5)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  bool bVar6;
  undefined8 uVar7;
  undefined auStack_50 [24];
  undefined auStack_38 [12];
  undefined auStack_2c [8];
  undefined auStack_24 [4];
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c190;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00a33fa0();
  if ((*(int *)(iVar1 + 0x10) == 0) && (iVar1 = FUN_00a33fa0(), *(int *)(iVar1 + 0x10) == 0)) {
    ExceptionList = pvStack_10;
    return 0;
  }
  if (param_5 != 0) {
    iVar1 = *(int *)(param_5 + 0x34);
    iVar2 = param_5;
    if ((iVar1 != 0) && (iVar2 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      iVar2 = FUN_005c8ac0();
    }
    if (iVar2 != 0) {
      iVar1 = *(int *)(iVar2 + 0xc);
      iVar2 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
          (uint)*(ushort *)(iVar2 + 0x1da)) {
        FUN_005789c0(&DAT_01ea8a80,&LAB_0055d5a0);
        uVar3 = FUN_00560dc0();
        piVar4 = (int *)FUN_008aa140(uVar3);
        piStack_18 = piVar4;
        if (*piVar4 == 0) {
          uVar3 = FUN_0093f210();
          piVar5 = (int *)FUN_008a9ba0(auStack_24,uVar3);
          piVar4 = piStack_18;
          iVar1 = *piVar5;
          iVar2 = piVar5[1];
          *piVar5 = 0;
          piVar5[1] = 0;
          *piStack_18 = iVar1;
          piVar5 = (int *)piStack_18[1];
          piStack_18[1] = iVar2;
          if (piVar5 != (int *)0x0) {
            LOCK();
            iVar1 = piVar5[1] + -1;
            piVar5[1] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)*piVar5)();
              LOCK();
              iVar1 = piVar5[2] + -1;
              piVar5[2] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)(*piVar5 + 4))();
              }
            }
          }
          if (piStack_20 != (int *)0x0) {
            LOCK();
            iVar1 = piStack_20[1] + -1;
            piStack_20[1] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)*piStack_20)();
              LOCK();
              iVar1 = piStack_20[2] + -1;
              piStack_20[2] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)(*piStack_20 + 4))();
              }
            }
          }
        }
        if (*piVar4 != 0) {
          FUN_00569550(2,&uStack_11);
          uStack_8 = 0;
          FUN_005ed510(&param_2);
          FUN_005ed510(&param_3);
          piStack_1c = (int *)0x0;
          piStack_18 = (int *)0x0;
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          if (DAT_01d64500 == '\0') {
            FUN_01255470(3,0,0,0);
            uVar3 = FUN_0094ed20(auStack_2c,auStack_50,param_4,"challenge",auStack_38);
          }
          else {
            FUN_01255470(3,0,0,0);
            uVar3 = FUN_0094b5d0(auStack_2c,auStack_50,param_4,"challenge",auStack_38);
          }
          FUN_005587e0(uVar3);
          FUN_00550b30();
          piVar4 = (int *)*piStack_1c;
          if (piVar4 == (int *)piStack_1c[1]) {
            piVar5 = (int *)0x0;
          }
          else {
            iVar1 = *piVar4;
            iVar2 = FUN_0088ca00();
            if (iVar1 == iVar2) {
              piVar5 = piVar4 + 2;
              if (piVar4[1] == 0) {
                piVar5 = (int *)0x0;
              }
            }
            else {
              piVar5 = (int *)0x0;
            }
          }
          piVar4 = piStack_18;
          if (piVar5 == (int *)0x0) {
            uVar7 = 0;
          }
          else {
            uVar7 = *(undefined8 *)piVar5;
          }
          bVar6 = piVar5 != (int *)0x0;
          *param_1 = uVar7;
          param_4._3_1_ = bVar6;
          if (piStack_18 != (int *)0x0) {
            LOCK();
            iVar1 = piStack_18[1] + -1;
            piStack_18[1] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)*piStack_18)();
              LOCK();
              piVar5 = piVar4 + 2;
              iVar1 = *piVar5;
              *piVar5 = *piVar5 + -1;
              UNLOCK();
              if (iVar1 == 1) {
                (**(code **)(*piVar4 + 4))();
              }
            }
          }
          uStack_8 = 2;
          FUN_00577b20();
          ExceptionList = pvStack_10;
          return param_4._3_1_;
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 5965 ; VA 0x005f2c00 ; FUN_005f2c00 */

char * FUN_005f2c00(uint param_1)

{
  if (param_1 < 0x752fab0c) {
    if (param_1 == 0x752fab0b) {
      return "Osx";
    }
    if (param_1 < 0x4beda922) {
      if (param_1 == 0x4beda921) {
        return "Win32";
      }
      if (param_1 == 0xc57b823) {
        return "Ios";
      }
      if (param_1 == 0x443921d5) {
        return "Uwp";
      }
    }
    else if (param_1 == 0x71375635) {
      return "Android";
    }
  }
  else if (param_1 < 0xeff3f3e6) {
    if (param_1 == 0xeff3f3e5) {
      return "Linux";
    }
    if (param_1 == 0x9d49834b) {
      return "Xbox";
    }
    if (param_1 == 0xe74bdb5b) {
      return "PlatformDev";
    }
  }
  else if (param_1 == 0xf938d287) {
    return "SecurityDev";
  }
  return "Invalid";
}



/* FUNCTION 5966 ; VA 0x005f2ca0 ; FUN_005f2ca0 */

char * FUN_005f2ca0(uint param_1)

{
  if (param_1 < 0x644bcfde) {
    if (param_1 == 0x644bcfdd) {
      return "Studio";
    }
    if (param_1 == 0x4c2398a1) {
      return "Test";
    }
    if (param_1 == 0x557bb5d7) {
      return "Client";
    }
  }
  else if (param_1 == 0x76114cfb) {
    return "Rcc";
  }
  return "Invalid";
}



/* FUNCTION 5967 ; VA 0x005f2ce7 ; FUN_005f2ce7 */

void FUN_005f2ce7(void)

{
  FUN_005f2cf0();
  return;
}



/* FUNCTION 5968 ; VA 0x005f2cf0 ; FUN_005f2cf0 */

void __fastcall FUN_005f2cf0(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_005ef440(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c26488);
}



/* FUNCTION 5969 ; VA 0x005f2d20 ; FUN_005f2d20 */

void __fastcall FUN_005f2d20(int param_1)

{
  int *piVar1;
  code *pcVar2;
  
  pcVar2 = *(code **)(param_1 + 0x3c);
  if (*(int *)(param_1 + 0x44) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x44) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar2)(*(undefined4 *)(param_1 + 0x40),*(undefined4 *)(param_1 + 0x44));
  return;
}



/* FUNCTION 5970 ; VA 0x005f2d60 ; FUN_005f2d60 */

uint FUN_005f2d60(int param_1,uint param_2,uint param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  
  uVar4 = (param_4 + param_3) * param_2;
  uVar2 = param_2;
  if ((uVar4 & 1) == 0) {
    uVar2 = param_3;
  }
  uVar2 = uVar2 + param_1;
  if ((uVar4 & 2) == 0) {
    uVar2 = uVar2 >> 7 | uVar2 * 0x2000000;
  }
  else {
    uVar2 = uVar2 * 0x80 | uVar2 >> 0x19;
  }
  uVar5 = param_2;
  if ((uVar4 & 4) == 0) {
    uVar5 = param_3;
  }
  uVar3 = param_2;
  if ((uVar4 & 8) == 0) {
    uVar3 = param_3;
  }
  uVar3 = (uVar2 - uVar5) * uVar3;
  if ((uVar4 & 0x10) == 0) {
    uVar2 = uVar3 >> 0xd | uVar3 * 0x80000;
  }
  else {
    uVar2 = uVar3 * 0x2000 | uVar3 >> 0x13;
  }
  uVar5 = param_2 - uVar2;
  if ((uVar4 & 0x20) == 0) {
    uVar5 = param_3 - uVar2;
  }
  uVar2 = param_2;
  if ((uVar4 & 0x40) == 0) {
    uVar2 = param_3;
  }
  uVar5 = uVar5 ^ uVar2;
  if ((char)uVar4 < '\0') {
    uVar2 = uVar5 << 0x11 | uVar5 >> 0xf;
  }
  else {
    uVar2 = uVar5 >> 0x11 | uVar5 << 0xf;
  }
  uVar5 = param_2;
  if ((uVar4 & 0x100) == 0) {
    uVar5 = -param_2;
  }
  uVar3 = param_3;
  if ((uVar4 & 0x200) == 0) {
    uVar3 = -param_3;
  }
  uVar3 = uVar3 + uVar2 + uVar5;
  if ((uVar4 & 0x400) == 0) {
    uVar2 = uVar3 >> 0x17 | uVar3 * 0x200;
  }
  else {
    uVar2 = uVar3 * 0x800000 | uVar3 >> 9;
  }
  uVar5 = -uVar2;
  if ((uVar4 & 0x800) == 0) {
    uVar5 = uVar2;
  }
  iVar1 = -(param_2 + uVar5);
  if ((uVar4 & 0x1000) == 0) {
    iVar1 = param_2 + uVar5;
  }
  uVar2 = param_3 + iVar1;
  if ((uVar4 & 0x2000) == 0) {
    uVar2 = uVar2 >> 0x1d | uVar2 * 8;
  }
  else {
    uVar2 = uVar2 * 0x20000000 | uVar2 >> 3;
  }
  if ((uVar4 & 0x4000) == 0) {
    param_2 = param_3;
  }
  uVar5 = param_2 ^ uVar2;
  if ((uVar4 & 0x8000) == 0) {
    uVar5 = -(param_2 ^ uVar2);
  }
  return uVar5;
}



/* FUNCTION 5971 ; VA 0x005f2e60 ; FUN_005f2e60 */

int FUN_005f2e60(int param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  
  uVar2 = (param_3 + param_4) * param_2;
  iVar3 = param_2 + param_1;
  if ((uVar2 & 2) == 0) {
    iVar3 = param_1 - param_2;
  }
  iVar1 = param_3;
  if ((uVar2 & 4) == 0) {
    iVar1 = -param_3;
  }
  uVar4 = -(iVar3 + iVar1);
  if ((uVar2 & 8) == 0) {
    uVar4 = ~(iVar3 + iVar1);
  }
  iVar3 = param_2 * param_3;
  if ((uVar2 & 0x10) == 0) {
    iVar3 = -(param_2 * param_3);
  }
  iVar1 = param_2 * param_4;
  if ((uVar2 & 0x20) == 0) {
    iVar1 = -(param_2 * param_4);
  }
  return iVar1 + iVar3 + uVar4;
}



/* FUNCTION 5972 ; VA 0x005f2ee0 ; FUN_005f2ee0 */

int FUN_005f2ee0(int param_1,int *param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c1b0;
  pvStack_10 = ExceptionList;
  iVar4 = 0;
  piVar5 = (int *)0x0;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    piVar1 = param_2 + 1;
    iVar2 = param_2[1];
    ExceptionList = &pvStack_10;
    while (iVar2 != 0) {
      LOCK();
      iVar3 = *piVar1;
      if (iVar2 == iVar3) {
        *piVar1 = iVar2 + 1;
        iVar3 = iVar2;
      }
      UNLOCK();
      iVar4 = param_1;
      piVar5 = param_2;
      if (iVar3 == iVar2) goto LAB_005f2f3d;
      iVar2 = *piVar1;
    }
    iVar4 = 0;
    piVar5 = (int *)0x0;
  }
LAB_005f2f3d:
  uStack_8 = 1;
  if ((iVar4 != 0) && (*(int *)(iVar4 + 0x4a0) == 2)) {
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar5[2] = piVar5[2] + 1;
      UNLOCK();
    }
    iVar4 = FUN_0064a7d0(iVar4,piVar5,param_4,param_5,param_3);
  }
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar1 = piVar5 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piVar5 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar5 = param_2 + 2;
    iVar2 = *piVar5;
    *piVar5 = *piVar5 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      iVar4 = (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 5973 ; VA 0x005f2fe0 ; FUN_005f2fe0 */

void FUN_005f2fe0(undefined4 param_1,undefined4 param_2)

{
  FUN_00687380(param_1,param_2);
  return;
}



/* FUNCTION 5974 ; VA 0x005f3000 ; FUN_005f3000 */

undefined * FUN_005f3000(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c1cc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaaadc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaaadc);
    if (DAT_01eaaadc == -1) {
      uStack_8 = 0;
      FUN_009187f0();
      FUN_016f3654(&LAB_0187c040);
      FUN_016f37bf(&DAT_01eaaadc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eaaa78;
}



/* FUNCTION 5975 ; VA 0x005f3090 ; FUN_005f3090 */

undefined * FUN_005f3090(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c1ec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaa9a4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaa9a4);
    if (DAT_01eaa9a4 == -1) {
      uStack_8 = 0;
      FUN_00967bf0();
      FUN_016f3654(&LAB_0187c060);
      FUN_016f37bf(&DAT_01eaa9a4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eaa940;
}



/* FUNCTION 5976 ; VA 0x005f3120 ; FUN_005f3120 */

undefined * FUN_005f3120(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c20c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaaa74) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaaa74);
    if (DAT_01eaaa74 == -1) {
      uStack_8 = 0;
      FUN_00918850();
      FUN_016f3654(&LAB_0187c080);
      FUN_016f37bf(&DAT_01eaaa74);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eaaa10;
}



/* FUNCTION 5977 ; VA 0x005f31b0 ; FUN_005f31b0 */

undefined * FUN_005f31b0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c22c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaa86c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaa86c);
    if (DAT_01eaa86c == -1) {
      uStack_8 = 0;
      FUN_009fe3d0();
      FUN_016f3654(&LAB_0187c0a0);
      FUN_016f37bf(&DAT_01eaa86c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eaa808;
}



/* FUNCTION 5978 ; VA 0x005f3240 ; FUN_005f3240 */

undefined * FUN_005f3240(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c24c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaabac) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaabac);
    if (DAT_01eaabac == -1) {
      uStack_8 = 0;
      FUN_0068fb00();
      FUN_016f3654(&LAB_0187c0c0);
      FUN_016f37bf(&DAT_01eaabac);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eaab48;
}



/* FUNCTION 5979 ; VA 0x005f32d0 ; FUN_005f32d0 */

undefined * FUN_005f32d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c26c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaab44) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaab44);
    if (DAT_01eaab44 == -1) {
      uStack_8 = 0;
      FUN_009188b0();
      FUN_016f3654(&LAB_0187c0e0);
      FUN_016f37bf(&DAT_01eaab44);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eaaae0;
}



/* FUNCTION 5980 ; VA 0x005f3360 ; FUN_005f3360 */

undefined * FUN_005f3360(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c28c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaac14) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaac14);
    if (DAT_01eaac14 == -1) {
      uStack_8 = 0;
      FUN_00684660();
      FUN_016f3654(&LAB_0187c100);
      FUN_016f37bf(&DAT_01eaac14);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eaabb0;
}



/* FUNCTION 5981 ; VA 0x005f33f0 ; FUN_005f33f0 */

undefined * FUN_005f33f0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c2ac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaaa0c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaaa0c);
    if (DAT_01eaaa0c == -1) {
      uStack_8 = 0;
      FUN_00967c50();
      FUN_016f3654(&LAB_0187c120);
      FUN_016f37bf(&DAT_01eaaa0c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eaa9a8;
}



/* FUNCTION 5982 ; VA 0x005f3480 ; FUN_005f3480 */

undefined * FUN_005f3480(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c2cc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaa8d4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaa8d4);
    if (DAT_01eaa8d4 == -1) {
      uStack_8 = 0;
      FUN_00967cb0();
      FUN_016f3654(&LAB_0187c140);
      FUN_016f37bf(&DAT_01eaa8d4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eaa870;
}



/* FUNCTION 5983 ; VA 0x005f3510 ; FUN_005f3510 */

undefined * FUN_005f3510(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c2ec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaa93c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaa93c);
    if (DAT_01eaa93c == -1) {
      uStack_8 = 0;
      FUN_00967d10();
      FUN_016f3654(&LAB_0187c160);
      FUN_016f37bf(&DAT_01eaa93c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eaa8d8;
}



/* FUNCTION 5984 ; VA 0x005f35a0 ; FUN_005f35a0 */

int FUN_005f35a0(void)

{
  uint uVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  undefined auStack_20 [4];
  int *piStack_1c;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c130;
  pvStack_10 = ExceptionList;
  iVar4 = DAT_01ea94c4;
  if (DAT_01ea94c4 == 0) {
    ExceptionList = &pvStack_10;
    piVar2 = (int *)FUN_00910d90();
    cStack_14 = '\0';
    iVar4 = *piVar2;
    puStack_18 = (uint *)(iVar4 + 0x94);
    FUN_00587410();
    uStack_8 = 0;
    if (DAT_01ea94c4 == 0) {
      FUN_005eeb00(auStack_20);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_008a65e0(iVar4,0);
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar4 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          piVar2 = piStack_1c + 2;
          iVar4 = *piVar2;
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
    }
    iVar4 = DAT_01ea94c4;
    uStack_8 = 2;
    if (cStack_14 != '\0') {
      LOCK();
      uVar1 = *puStack_18;
      *puStack_18 = *puStack_18 + 0x80000000;
      UNLOCK();
      if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
        LOCK();
        uVar1 = *puStack_18;
        *puStack_18 = *puStack_18 | 0x40000000;
        UNLOCK();
        if ((uVar1 >> 0x1e & 1) == 0) {
          uVar3 = FUN_00554e40();
          SetEvent(uVar3);
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 5985 ; VA 0x005f3690 ; FUN_005f3690 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_005f3690(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaac9c) {
    FUN_016f3809(&DAT_01eaac9c);
    if (DAT_01eaac9c == -1) {
      _DAT_01eaac90 = FUN_005c65e0;
      _DAT_01eaac94 = FUN_005c65e0;
      _DAT_01eaac98 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eaac9c);
    }
  }
  return &DAT_01eaac90;
}



/* FUNCTION 5986 ; VA 0x005f3700 ; FUN_005f3700 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_005f3700(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaaccc) {
    FUN_016f3809(&DAT_01eaaccc);
    if (DAT_01eaaccc == -1) {
      _DAT_01eaacc0 = FUN_005c65e0;
      _DAT_01eaacc4 = FUN_005c65e0;
      _DAT_01eaacc8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eaaccc);
    }
  }
  return &DAT_01eaacc0;
}



/* FUNCTION 5987 ; VA 0x005f3770 ; FUN_005f3770 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_005f3770(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaacac) {
    FUN_016f3809(&DAT_01eaacac);
    if (DAT_01eaacac == -1) {
      _DAT_01eaaca0 = FUN_005c65e0;
      _DAT_01eaaca4 = FUN_005c65e0;
      _DAT_01eaaca8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eaacac);
    }
  }
  return &DAT_01eaaca0;
}



/* FUNCTION 5988 ; VA 0x005f37e0 ; FUN_005f37e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_005f37e0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaacfc) {
    FUN_016f3809(&DAT_01eaacfc);
    if (DAT_01eaacfc == -1) {
      _DAT_01eaacf0 = FUN_005c65e0;
      _DAT_01eaacf4 = FUN_005c65e0;
      _DAT_01eaacf8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eaacfc);
    }
  }
  return &DAT_01eaacf0;
}



/* FUNCTION 5989 ; VA 0x005f3850 ; FUN_005f3850 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_005f3850(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaac8c) {
    FUN_016f3809(&DAT_01eaac8c);
    if (DAT_01eaac8c == -1) {
      _DAT_01eaac80 = FUN_005c65e0;
      _DAT_01eaac84 = FUN_005c65e0;
      _DAT_01eaac88 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eaac8c);
    }
  }
  return &DAT_01eaac80;
}



/* FUNCTION 5990 ; VA 0x005f38c0 ; FUN_005f38c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_005f38c0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaacbc) {
    FUN_016f3809(&DAT_01eaacbc);
    if (DAT_01eaacbc == -1) {
      _DAT_01eaacb0 = FUN_005c65e0;
      _DAT_01eaacb4 = FUN_005c65e0;
      _DAT_01eaacb8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eaacbc);
    }
  }
  return &DAT_01eaacb0;
}



/* FUNCTION 5991 ; VA 0x005f3930 ; FUN_005f3930 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_005f3930(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaacec) {
    FUN_016f3809(&DAT_01eaacec);
    if (DAT_01eaacec == -1) {
      _DAT_01eaace0 = FUN_005c65e0;
      _DAT_01eaace4 = FUN_005c65e0;
      _DAT_01eaace8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eaacec);
    }
  }
  return &DAT_01eaace0;
}



/* FUNCTION 5992 ; VA 0x005f39a0 ; FUN_005f39a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_005f39a0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaacdc) {
    FUN_016f3809(&DAT_01eaacdc);
    if (DAT_01eaacdc == -1) {
      _DAT_01eaacd0 = FUN_005c65e0;
      _DAT_01eaacd4 = FUN_005c65e0;
      _DAT_01eaacd8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eaacdc);
    }
  }
  return &DAT_01eaacd0;
}



/* FUNCTION 5993 ; VA 0x005f3a10 ; FUN_005f3a10 */

int FUN_005f3a10(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  code *pcStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c328;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_2[2] = param_2[2] + 1;
    UNLOCK();
  }
  uStack_18 = param_1;
  if (param_2 != (int *)0x0) {
    piVar1 = param_2 + 2;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)(*param_2 + 4))();
    }
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)(*param_2 + 4))();
    }
  }
  if (param_2 != (int *)0x0) {
    piVar1 = param_2 + 2;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)(*param_2 + 4))();
    }
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)(*param_2 + 4))();
    }
  }
  pcStack_24 = FUN_005f23f0;
  uStack_20 = uStack_18;
  piStack_1c = param_2;
  uStack_8._0_1_ = 2;
  puStack_14 = (undefined4 *)FUN_005ef280(&pcStack_24);
  if (puStack_14 != (undefined4 *)0x0) {
    LOCK();
    puStack_14[1] = puStack_14[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 4;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar5 = piStack_1c[2] + -1;
    piStack_1c[2] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)(*piStack_1c + 4))();
    }
  }
  cVar4 = FUN_0168a8f0();
  if (cVar4 != '\0') {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    iVar5 = FUN_016899e0();
    puVar3 = puStack_14;
    if (puStack_14 != (undefined4 *)0x0) {
      LOCK();
      piVar1 = puStack_14 + 1;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*puStack_14)(0);
        uVar6 = GetProcessHeap(0,puVar3);
        iVar5 = HeapFree(uVar6);
      }
    }
    if (param_2 != (int *)0x0) {
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_2 + 4))();
      }
    }
    ExceptionList = pvStack_10;
    return iVar5;
  }
  uVar6 = FUN_005503c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
                    /* WARNING: Subroutine does not return */
  FUN_0054e630(uVar6);
}



/* FUNCTION 5994 ; VA 0x005f3b80 ; FUN_005f3b80 */

undefined4 * __thiscall FUN_005f3b80(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c370;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[1] = 1;
  param_1[2] = 1;
  *param_1 = std::_Ref_count_obj<class_RBX::ModelMeshJob>::vftable;
  piVar5 = (int *)param_2[1];
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
    piVar5 = (int *)param_2[1];
  }
  uVar2 = *param_2;
  uStack_8 = 0;
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
  }
  FUN_00a360a0("ModelMesh",1,0,uVar2,piVar5,4);
  param_1[4] = RBX::ModelMeshJob::vftable;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
  }
  param_1[0x4e] = uVar2;
  param_1[0x4f] = piVar5;
  uStack_8._0_1_ = 2;
  iVar3 = FUN_01674e20(0xa8);
  uStack_8._0_1_ = 3;
  if (iVar3 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00729a20(uVar2);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  param_1[0x50] = 0;
  param_1[0x51] = 0;
  FUN_005f3e00(uVar4,uVar2);
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar3 = piVar5[1] + -1;
    piVar5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5995 ; VA 0x005f3cd0 ; FUN_005f3cd0 */

undefined * FUN_005f3cd0(undefined *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792429;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  uStack_8 = 0;
  FUN_0058a190(param_3[4] + param_2[4]);
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_00554150(param_2,*puVar1);
  puVar1 = param_3 + 4;
  if (0xf < (uint)param_3[5]) {
    param_3 = (undefined4 *)*param_3;
  }
  FUN_00554150(param_3,*puVar1);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5996 ; VA 0x005f3dd0 ; FUN_005f3dd0 */

void FUN_005f3dd0(int param_1,int param_2)

{
  if (param_1 != param_2) {
    do {
      FUN_005f5f30();
      param_1 = param_1 + 0x48;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 5997 ; VA 0x005f3e00 ; FUN_005f3e00 */

void __thiscall FUN_005f3e00(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c380;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::ModelMeshComputer>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5998 ; VA 0x005f3e6e ; Catch_All@005f3e6e */

void Catch_All_005f3e6e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_005f6120(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5999 ; VA 0x005f3e90 ; FUN_005f3e90 */

int __thiscall FUN_005f3e90(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c390;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::AssetCounterService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}


