/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 3500 ; VA 0x005717ab ; FUN_005717ab */

void FUN_005717ab(void)

{
  FUN_00571fe0();
  return;
}



/* FUNCTION 3501 ; VA 0x005717b6 ; FUN_005717b6 */

void FUN_005717b6(void)

{
  FUN_00571fe0();
  return;
}



/* FUNCTION 3502 ; VA 0x005717be ; FUN_005717be */

void FUN_005717be(void)

{
  FUN_00572010();
  return;
}



/* FUNCTION 3503 ; VA 0x005717c9 ; FUN_005717c9 */

void FUN_005717c9(void)

{
  FUN_00572010();
  return;
}



/* FUNCTION 3504 ; VA 0x005717d1 ; FUN_005717d1 */

void FUN_005717d1(void)

{
  FUN_00572040();
  return;
}



/* FUNCTION 3505 ; VA 0x005717dc ; FUN_005717dc */

void FUN_005717dc(void)

{
  FUN_00572040();
  return;
}



/* FUNCTION 3506 ; VA 0x005717e4 ; FUN_005717e4 */

void FUN_005717e4(void)

{
  FUN_00572070();
  return;
}



/* FUNCTION 3507 ; VA 0x005717ef ; FUN_005717ef */

void FUN_005717ef(void)

{
  FUN_00572070();
  return;
}



/* FUNCTION 3508 ; VA 0x005717f7 ; FUN_005717f7 */

void FUN_005717f7(void)

{
  FUN_005720a0();
  return;
}



/* FUNCTION 3509 ; VA 0x00571802 ; FUN_00571802 */

void FUN_00571802(void)

{
  FUN_005720a0();
  return;
}



/* FUNCTION 3510 ; VA 0x0057180a ; FUN_0057180a */

void FUN_0057180a(void)

{
  FUN_005720d0();
  return;
}



/* FUNCTION 3511 ; VA 0x00571815 ; FUN_00571815 */

void FUN_00571815(void)

{
  FUN_005720d0();
  return;
}



/* FUNCTION 3512 ; VA 0x0057181d ; FUN_0057181d */

void FUN_0057181d(void)

{
  FUN_00572100();
  return;
}



/* FUNCTION 3513 ; VA 0x00571828 ; FUN_00571828 */

void FUN_00571828(void)

{
  FUN_00572160();
  return;
}



/* FUNCTION 3514 ; VA 0x00571833 ; FUN_00571833 */

void FUN_00571833(void)

{
  FUN_005721b0();
  return;
}



/* FUNCTION 3515 ; VA 0x0057183e ; FUN_0057183e */

void FUN_0057183e(void)

{
  FUN_00572210();
  return;
}



/* FUNCTION 3516 ; VA 0x00571849 ; FUN_00571849 */

void FUN_00571849(void)

{
  FUN_00572210();
  return;
}



/* FUNCTION 3517 ; VA 0x00571851 ; FUN_00571851 */

void FUN_00571851(void)

{
  FUN_00572240();
  return;
}



/* FUNCTION 3518 ; VA 0x00571859 ; FUN_00571859 */

void FUN_00571859(void)

{
  FUN_005722c0();
  return;
}



/* FUNCTION 3519 ; VA 0x00571861 ; FUN_00571861 */

void FUN_00571861(void)

{
  FUN_00572340();
  return;
}



/* FUNCTION 3520 ; VA 0x00571869 ; FUN_00571869 */

void FUN_00571869(void)

{
  FUN_005723c0();
  return;
}



/* FUNCTION 3521 ; VA 0x00571871 ; FUN_00571871 */

void FUN_00571871(void)

{
  FUN_00572440();
  return;
}



/* FUNCTION 3522 ; VA 0x00571879 ; FUN_00571879 */

void FUN_00571879(void)

{
  FUN_005724c0();
  return;
}



/* FUNCTION 3523 ; VA 0x00571881 ; FUN_00571881 */

void FUN_00571881(void)

{
  FUN_00572540();
  return;
}



/* FUNCTION 3524 ; VA 0x00571889 ; FUN_00571889 */

void FUN_00571889(void)

{
  FUN_005725c0();
  return;
}



/* FUNCTION 3525 ; VA 0x00571891 ; FUN_00571891 */

void FUN_00571891(void)

{
  FUN_00572640();
  return;
}



/* FUNCTION 3526 ; VA 0x00571899 ; FUN_00571899 */

void FUN_00571899(void)

{
  FUN_005726c0();
  return;
}



/* FUNCTION 3527 ; VA 0x005718a1 ; FUN_005718a1 */

void FUN_005718a1(void)

{
  FUN_00572740();
  return;
}



/* FUNCTION 3528 ; VA 0x005718a9 ; FUN_005718a9 */

void FUN_005718a9(void)

{
  FUN_005727c0();
  return;
}



/* FUNCTION 3529 ; VA 0x005718b1 ; FUN_005718b1 */

void FUN_005718b1(void)

{
  FUN_00572840();
  return;
}



/* FUNCTION 3530 ; VA 0x005718b9 ; FUN_005718b9 */

void FUN_005718b9(void)

{
  FUN_005728c0();
  return;
}



/* FUNCTION 3531 ; VA 0x005718c1 ; FUN_005718c1 */

void FUN_005718c1(void)

{
  FUN_00572970();
  return;
}



/* FUNCTION 3532 ; VA 0x005718c9 ; FUN_005718c9 */

void FUN_005718c9(void)

{
  FUN_005729f0();
  return;
}



/* FUNCTION 3533 ; VA 0x005718d1 ; FUN_005718d1 */

void FUN_005718d1(void)

{
  FUN_00572a70();
  return;
}



/* FUNCTION 3534 ; VA 0x005718d9 ; FUN_005718d9 */

void FUN_005718d9(void)

{
  FUN_00572af0();
  return;
}



/* FUNCTION 3535 ; VA 0x005718e1 ; FUN_005718e1 */

void FUN_005718e1(void)

{
  FUN_00572b70();
  return;
}



/* FUNCTION 3536 ; VA 0x005718e9 ; FUN_005718e9 */

void FUN_005718e9(void)

{
  FUN_00572bf0();
  return;
}



/* FUNCTION 3537 ; VA 0x005718f1 ; FUN_005718f1 */

void FUN_005718f1(void)

{
  FUN_00572c70();
  return;
}



/* FUNCTION 3538 ; VA 0x005718f9 ; FUN_005718f9 */

void FUN_005718f9(void)

{
  FUN_00572cf0();
  return;
}



/* FUNCTION 3539 ; VA 0x00571901 ; FUN_00571901 */

void FUN_00571901(void)

{
  FUN_00572d70();
  return;
}



/* FUNCTION 3540 ; VA 0x00571909 ; FUN_00571909 */

void FUN_00571909(void)

{
  FUN_00573430();
  return;
}



/* FUNCTION 3541 ; VA 0x00571920 ; FUN_00571920 */

undefined4 __thiscall FUN_00571920(undefined4 param_1,byte param_2)

{
  FUN_005be890();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x17658);
  }
  return param_1;
}



/* FUNCTION 3542 ; VA 0x00571950 ; FUN_00571950 */

undefined4 __thiscall FUN_00571950(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 3543 ; VA 0x00571970 ; FUN_00571970 */

undefined4 __thiscall FUN_00571970(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x24);
  }
  return param_1;
}



/* FUNCTION 3544 ; VA 0x00571990 ; FUN_00571990 */

undefined4 __thiscall FUN_00571990(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,200);
  }
  return param_1;
}



/* FUNCTION 3545 ; VA 0x005719c0 ; FUN_005719c0 */

undefined4 __thiscall FUN_005719c0(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x34);
  }
  return param_1;
}



/* FUNCTION 3546 ; VA 0x005719e0 ; FUN_005719e0 */

undefined4 __thiscall FUN_005719e0(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 3547 ; VA 0x00571a00 ; FUN_00571a00 */

undefined4 __thiscall FUN_00571a00(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xf0);
  }
  return param_1;
}



/* FUNCTION 3548 ; VA 0x00571a30 ; FUN_00571a30 */

int * __thiscall FUN_00571a30(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar1 = param_1 + -8;
  ExceptionList = &pvStack_10;
  *(undefined ***)(*(int *)(param_1[-8] + 4) + -0x20 + (int)param_1) =
       std::basic_iostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*piVar1 + 4) + -0x24 + (int)param_1) = *(int *)(*piVar1 + 4) + -0x20;
  *(undefined ***)(*(int *)(param_1[-4] + 4) + -0x10 + (int)param_1) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(param_1[-4] + 4) + -0x14 + (int)param_1) = *(int *)(param_1[-4] + 4) + -8;
  *(undefined ***)(*(int *)(param_1[-8] + 4) + -0x20 + (int)param_1) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(param_1[-8] + 4) + -0x24 + (int)param_1) = *(int *)(param_1[-8] + 4) + -0x18;
  uStack_8 = 0;
  *param_1 = std::ios_base::vftable;
  FUN_016de551(param_1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(piVar1,0x68);
  }
  ExceptionList = pvStack_10;
  return piVar1;
}



/* FUNCTION 3549 ; VA 0x00571ae0 ; FUN_00571ae0 */

int __thiscall FUN_00571ae0(int param_1,byte param_2)

{
  FUN_005703e0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1 + -0x60,0xa8);
  }
  return param_1 + -0x60;
}



/* FUNCTION 3550 ; VA 0x00571b10 ; FUN_00571b10 */

int __thiscall FUN_00571b10(int param_1,byte param_2)

{
  FUN_00570460();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1 + -0x68,0xb0);
  }
  return param_1 + -0x68;
}



/* FUNCTION 3551 ; VA 0x00571b40 ; FUN_00571b40 */

int * __thiscall FUN_00571b40(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar1 = param_1 + -2;
  ExceptionList = &pvStack_10;
  *(undefined ***)(*(int *)(param_1[-2] + 4) + -8 + (int)param_1) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*piVar1 + 4) + -0xc + (int)param_1) = *(int *)(*piVar1 + 4) + -8;
  uStack_8 = 0;
  *param_1 = std::ios_base::vftable;
  FUN_016de551(param_1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(piVar1,0x50);
  }
  ExceptionList = pvStack_10;
  return piVar1;
}



/* FUNCTION 3552 ; VA 0x00571bb0 ; FUN_00571bb0 */

int __thiscall FUN_00571bb0(int param_1,byte param_2)

{
  FUN_00570540();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1 + -0x50,0x98);
  }
  return param_1 + -0x50;
}



/* FUNCTION 3553 ; VA 0x00571be0 ; FUN_00571be0 */

int * __thiscall FUN_00571be0(int *param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 3554 ; VA 0x00571c50 ; FUN_00571c50 */

undefined4 __thiscall FUN_00571c50(undefined4 param_1,byte param_2)

{
  FUN_0056b950();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x44);
  }
  return param_1;
}



/* FUNCTION 3555 ; VA 0x00571c80 ; FUN_00571c80 */

int __thiscall FUN_00571c80(int param_1,byte param_2)

{
  FUN_005705c0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1 + -0x68,0xb0);
  }
  return param_1 + -0x68;
}



/* FUNCTION 3556 ; VA 0x00571cb0 ; FUN_00571cb0 */

undefined4 __thiscall FUN_00571cb0(undefined4 param_1,byte param_2)

{
  FUN_00570680();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 3557 ; VA 0x00571ce0 ; FUN_00571ce0 */

undefined4 __thiscall FUN_00571ce0(undefined4 param_1,byte param_2)

{
  FUN_00570720();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 3558 ; VA 0x00571d10 ; FUN_00571d10 */

undefined4 __thiscall FUN_00571d10(undefined4 param_1,byte param_2)

{
  FUN_005707c0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 3559 ; VA 0x00571d40 ; FUN_00571d40 */

undefined4 __thiscall FUN_00571d40(undefined4 param_1,byte param_2)

{
  FUN_00570860();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 3560 ; VA 0x00571d70 ; FUN_00571d70 */

undefined4 __thiscall FUN_00571d70(undefined4 param_1,byte param_2)

{
  FUN_00570900();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x34);
  }
  return param_1;
}



/* FUNCTION 3561 ; VA 0x00571da0 ; FUN_00571da0 */

undefined4 __thiscall FUN_00571da0(undefined4 param_1,byte param_2)

{
  FUN_005709a0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x34);
  }
  return param_1;
}



/* FUNCTION 3562 ; VA 0x00571dd0 ; FUN_00571dd0 */

undefined4 __thiscall FUN_00571dd0(undefined4 param_1,byte param_2)

{
  FUN_00570a40();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x4c);
  }
  return param_1;
}



/* FUNCTION 3563 ; VA 0x00571e00 ; FUN_00571e00 */

undefined4 __thiscall FUN_00571e00(undefined4 param_1,byte param_2)

{
  FUN_00570ae0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x34);
  }
  return param_1;
}



/* FUNCTION 3564 ; VA 0x00571e30 ; FUN_00571e30 */

undefined4 __thiscall FUN_00571e30(undefined4 param_1,byte param_2)

{
  FUN_00570b80();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x34);
  }
  return param_1;
}



/* FUNCTION 3565 ; VA 0x00571e60 ; FUN_00571e60 */

undefined4 __thiscall FUN_00571e60(undefined4 param_1,byte param_2)

{
  FUN_00570c20();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 3566 ; VA 0x00571e90 ; FUN_00571e90 */

undefined4 __thiscall FUN_00571e90(undefined4 param_1,byte param_2)

{
  FUN_00570cc0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 3567 ; VA 0x00571ec0 ; FUN_00571ec0 */

undefined4 __thiscall FUN_00571ec0(undefined4 param_1,byte param_2)

{
  FUN_00570d60();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 3568 ; VA 0x00571ef0 ; FUN_00571ef0 */

undefined4 __thiscall FUN_00571ef0(undefined4 param_1,byte param_2)

{
  FUN_00570e00();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 3569 ; VA 0x00571f20 ; FUN_00571f20 */

undefined4 __thiscall FUN_00571f20(undefined4 param_1,byte param_2)

{
  FUN_00570ea0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 3570 ; VA 0x00571f50 ; FUN_00571f50 */

undefined4 __thiscall FUN_00571f50(undefined4 param_1,byte param_2)

{
  FUN_00570f40();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x34);
  }
  return param_1;
}



/* FUNCTION 3571 ; VA 0x00571f80 ; FUN_00571f80 */

undefined4 __thiscall FUN_00571f80(undefined4 param_1,byte param_2)

{
  FUN_00570fe0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 3572 ; VA 0x00571fb0 ; FUN_00571fb0 */

undefined4 __thiscall FUN_00571fb0(undefined4 param_1,byte param_2)

{
  FUN_00571080();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 3573 ; VA 0x00571fe0 ; FUN_00571fe0 */

undefined4 __thiscall FUN_00571fe0(undefined4 param_1,byte param_2)

{
  FUN_00571120();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 3574 ; VA 0x00572010 ; FUN_00572010 */

undefined4 __thiscall FUN_00572010(undefined4 param_1,byte param_2)

{
  FUN_005711c0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 3575 ; VA 0x00572040 ; FUN_00572040 */

undefined4 __thiscall FUN_00572040(undefined4 param_1,byte param_2)

{
  FUN_00571260();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 3576 ; VA 0x00572070 ; FUN_00572070 */

undefined4 __thiscall FUN_00572070(undefined4 param_1,byte param_2)

{
  FUN_00571300();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 3577 ; VA 0x005720a0 ; FUN_005720a0 */

undefined4 __thiscall FUN_005720a0(undefined4 param_1,byte param_2)

{
  FUN_005713a0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 3578 ; VA 0x005720d0 ; FUN_005720d0 */

undefined4 __thiscall FUN_005720d0(undefined4 param_1,byte param_2)

{
  FUN_00571440();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 3579 ; VA 0x00572100 ; FUN_00572100 */

undefined4 * __thiscall FUN_00572100(undefined4 *param_1,byte param_2)

{
  *param_1 = boost::exception_detail::clone_impl<class_boost::broken_promise>::vftable;
  *(undefined ***)(*(int *)(param_1[5] + 4) + 0x14 + (int)param_1) =
       boost::exception_detail::clone_impl<class_boost::broken_promise>::vftable;
  *(int *)(*(int *)(param_1[5] + 4) + 0x10 + (int)param_1) = *(int *)(param_1[5] + 4) + -8;
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[7] = boost::exception_detail::clone_base::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  return param_1;
}



/* FUNCTION 3580 ; VA 0x00572160 ; FUN_00572160 */

undefined4 * __thiscall FUN_00572160(undefined4 *param_1,byte param_2)

{
  *param_1 = boost::exception_detail::clone_impl<class_RBX::http_status_error>::vftable;
  *(undefined ***)(*(int *)(param_1[10] + 4) + 0x28 + (int)param_1) =
       boost::exception_detail::clone_impl<class_RBX::http_status_error>::vftable;
  *(int *)(*(int *)(param_1[10] + 4) + 0x24 + (int)param_1) = *(int *)(param_1[10] + 4) + -8;
  FUN_0056e860();
  param_1[0xc] = boost::exception_detail::clone_base::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x34);
  }
  return param_1;
}



/* FUNCTION 3581 ; VA 0x005721b0 ; FUN_005721b0 */

undefined4 * __thiscall FUN_005721b0(undefined4 *param_1,byte param_2)

{
  *param_1 = boost::exception_detail::clone_impl<class_std::runtime_error>::vftable;
  *(undefined ***)(*(int *)(param_1[3] + 4) + 0xc + (int)param_1) =
       boost::exception_detail::clone_impl<class_std::runtime_error>::vftable;
  *(int *)(*(int *)(param_1[3] + 4) + 8 + (int)param_1) = *(int *)(param_1[3] + 4) + -8;
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[5] = boost::exception_detail::clone_base::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 3582 ; VA 0x00572210 ; FUN_00572210 */

undefined4 __thiscall FUN_00572210(undefined4 param_1,byte param_2)

{
  FUN_005715a0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 3583 ; VA 0x00572240 ; FUN_00572240 */

undefined4 * __thiscall FUN_00572240(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_alloc>
             ::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3584 ; VA 0x005722c0 ; FUN_005722c0 */

undefined4 * __thiscall FUN_005722c0(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_cast>::
             vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3585 ; VA 0x00572340 ; FUN_00572340 */

undefined4 * __thiscall FUN_00572340(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::bad_exception>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3586 ; VA 0x005723c0 ; FUN_005723c0 */

undefined4 * __thiscall FUN_005723c0(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::current_exception_std_exception_wrapper<class_std::bad_typeid>
             ::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3587 ; VA 0x00572440 ; FUN_00572440 */

undefined4 * __thiscall FUN_00572440(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::domain_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3588 ; VA 0x005724c0 ; FUN_005724c0 */

undefined4 * __thiscall FUN_005724c0(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::ios_base::failure>::vftable;
  param_1[5] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[6] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[6] + 0x10))();
    if (cVar1 != '\0') {
      param_1[6] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3589 ; VA 0x00572540 ; FUN_00572540 */

undefined4 * __thiscall FUN_00572540(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::invalid_argument>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3590 ; VA 0x005725c0 ; FUN_005725c0 */

undefined4 * __thiscall FUN_005725c0(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::length_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3591 ; VA 0x00572640 ; FUN_00572640 */

undefined4 * __thiscall FUN_00572640(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::logic_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3592 ; VA 0x005726c0 ; FUN_005726c0 */

undefined4 * __thiscall FUN_005726c0(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::out_of_range>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3593 ; VA 0x00572740 ; FUN_00572740 */

undefined4 * __thiscall FUN_00572740(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::overflow_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3594 ; VA 0x005727c0 ; FUN_005727c0 */

undefined4 * __thiscall FUN_005727c0(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::range_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3595 ; VA 0x00572840 ; FUN_00572840 */

undefined4 * __thiscall FUN_00572840(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::runtime_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3596 ; VA 0x005728c0 ; FUN_005728c0 */

undefined4 * __thiscall FUN_005728c0(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             current_exception_std_exception_wrapper<class_std::underflow_error>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3597 ; VA 0x00572940 ; FUN_00572940 */

undefined4 * __thiscall FUN_00572940(undefined4 *param_1,byte param_2)

{
  *param_1 = boost::exception_detail::error_info_base::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,8);
  }
  return param_1;
}



/* FUNCTION 3598 ; VA 0x00572970 ; FUN_00572970 */

undefined4 * __thiscall FUN_00572970(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_month>
             ::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3599 ; VA 0x005729f0 ; FUN_005729f0 */

undefined4 * __thiscall FUN_005729f0(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_month>::
             vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3600 ; VA 0x00572a70 ; FUN_00572a70 */

undefined4 * __thiscall FUN_00572a70(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_year>::
             vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3601 ; VA 0x00572af0 ; FUN_00572af0 */

undefined4 * __thiscall FUN_00572af0(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_std::bad_alloc>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3602 ; VA 0x00572b70 ; FUN_00572b70 */

undefined4 * __thiscall FUN_00572b70(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::future_already_retrieved>::
             vftable;
  param_1[5] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[6] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[6] + 0x10))();
    if (cVar1 != '\0') {
      param_1[6] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3603 ; VA 0x00572bf0 ; FUN_00572bf0 */

undefined4 * __thiscall FUN_00572bf0(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::future_uninitialized>::
             vftable;
  param_1[5] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[6] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[6] + 0x10))();
    if (cVar1 != '\0') {
      param_1[6] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3604 ; VA 0x00572c70 ; FUN_00572c70 */

undefined4 * __thiscall FUN_00572c70(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::lock_error>::vftable;
  param_1[0xb] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[0xc] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[0xc] + 0x10))();
    if (cVar1 != '\0') {
      param_1[0xc] = 0;
    }
  }
  *param_1 = boost::thread_exception::vftable;
  FUN_00551150();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x40);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3605 ; VA 0x00572cf0 ; FUN_00572cf0 */

undefined4 * __thiscall FUN_00572cf0(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::promise_already_satisfied>::
             vftable;
  param_1[5] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[6] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[6] + 0x10))();
    if (cVar1 != '\0') {
      param_1[6] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3606 ; VA 0x00572d70 ; FUN_00572d70 */

undefined4 * __thiscall FUN_00572d70(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::promise_moved>::vftable;
  param_1[5] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[6] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[6] + 0x10))();
    if (cVar1 != '\0') {
      param_1[6] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3607 ; VA 0x00572df0 ; FUN_00572df0 */

undefined4 * __thiscall FUN_00572df0(undefined4 *param_1,byte param_2)

{
  *param_1 = std::numpunct<char>::vftable;
  FUN_017168b0(param_1[2]);
  FUN_017168b0(param_1[4]);
  FUN_017168b0(param_1[5]);
  *param_1 = std::_Facet_base::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 3608 ; VA 0x00572e40 ; FUN_00572e40 */

int * __thiscall FUN_00572e40(int *param_1,byte param_2)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined **ppuStack_34;
  undefined auStack_30 [16];
  undefined auStack_20 [8];
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_01794b50;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    puStack_18 = (uint *)(*param_1 + 0x24);
    cStack_14 = '\0';
    ExceptionList = &pvStack_10;
    FUN_00587410();
    if ((*(char *)(*param_1 + 0x18) == '\0') && (*(char *)(*param_1 + 0x20) == '\0')) {
      uVar5 = FUN_0168a9f0();
      FUN_0056abb0(1,uVar5);
      ppuStack_34 = boost::broken_promise::vftable;
      uVar5 = FUN_0055dd80(auStack_20,&ppuStack_34);
      FUN_00587d90(uVar5,&puStack_18);
      FUN_00550ad0();
      ppuStack_34 = std::exception::vftable;
      FUN_0170c289(auStack_30);
    }
    uStack_8 = 1;
    if (cStack_14 != '\0') {
      LOCK();
      uVar2 = *puStack_18;
      *puStack_18 = *puStack_18 + 0x80000000;
      UNLOCK();
      if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
        LOCK();
        uVar2 = *puStack_18;
        *puStack_18 = *puStack_18 | 0x40000000;
        UNLOCK();
        if ((uVar2 >> 0x1e & 1) == 0) {
          uVar5 = FUN_00554e40();
          SetEvent(uVar5);
        }
      }
    }
  }
  piVar3 = (int *)param_1[1];
  _uStack_8 = CONCAT31(uStack_7,2);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar3 + 4))();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar3 + 8))();
      }
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3609 ; VA 0x00572f70 ; FUN_00572f70 */

undefined4 * __thiscall FUN_00572f70(undefined4 *param_1,byte param_2)

{
  *param_1 = boost::detail::
             shared_state<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
             ::vftable;
  FUN_0056cee0();
  FUN_0056ea40();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x90);
  }
  return param_1;
}



/* FUNCTION 3610 ; VA 0x00572fb0 ; FUN_00572fb0 */

undefined4 __thiscall FUN_00572fb0(undefined4 param_1,byte param_2)

{
  FUN_0056cf50();
  FUN_016894b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x98);
  }
  return param_1;
}



/* FUNCTION 3611 ; VA 0x00572fe0 ; FUN_00572fe0 */

int __thiscall FUN_00572fe0(int param_1,byte param_2)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x40);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x48,param_1 + 0x48,2);
      }
    }
    *(undefined4 *)(param_1 + 0x40) = 0;
  }
  FUN_016894b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x60);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3612 ; VA 0x00573060 ; FUN_00573060 */

undefined4 __thiscall FUN_00573060(undefined4 param_1,byte param_2)

{
  FUN_0056d080();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 3613 ; VA 0x00573090 ; FUN_00573090 */

undefined4 __thiscall FUN_00573090(undefined4 param_1,byte param_2)

{
  FUN_0056d930();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x34);
  }
  return param_1;
}



/* FUNCTION 3614 ; VA 0x005730c0 ; FUN_005730c0 */

undefined4 * __thiscall FUN_005730c0(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *param_1 = RBX::GameConfigurer::vftable;
  piVar2 = (int *)param_1[5];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[2];
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 3615 ; VA 0x00573130 ; FUN_00573130 */

undefined4 __thiscall FUN_00573130(undefined4 param_1,byte param_2)

{
  FUN_0056dbe0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x70);
  }
  return param_1;
}



/* FUNCTION 3616 ; VA 0x00573160 ; FUN_00573160 */

undefined4 * __thiscall FUN_00573160(undefined4 *param_1,byte param_2)

{
  *param_1 = MD5Updater::vftable;
  FUN_0056e200();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x34);
  }
  return param_1;
}



/* FUNCTION 3617 ; VA 0x00573190 ; FUN_00573190 */

undefined4 __thiscall FUN_00573190(undefined4 param_1,byte param_2)

{
  FUN_009951b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 3618 ; VA 0x005731c0 ; FUN_005731c0 */

int __thiscall FUN_005731c0(int param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x40);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x2c);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00573280;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 0x40) = 0xf;
  *(undefined *)(param_1 + 0x2c) = 0;
  uVar1 = *(uint *)(param_1 + 0x28);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x14);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00573280:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x28) = 0xf;
  *(undefined *)(param_1 + 0x14) = 0;
  FUN_0056d440();
  LOCK();
  iVar2 = *(int *)(param_1 + 4);
  *(int *)(param_1 + 4) = 0;
  UNLOCK();
  if (iVar2 != 0) {
    CloseHandle(iVar2);
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x44);
  }
  return param_1;
}



/* FUNCTION 3619 ; VA 0x00573290 ; FUN_00573290 */

undefined4 __thiscall FUN_00573290(undefined4 param_1,byte param_2)

{
  FUN_0056e160();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 3620 ; VA 0x005732c0 ; FUN_005732c0 */

undefined4 __thiscall FUN_005732c0(undefined4 param_1,byte param_2)

{
  FUN_0056e200();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x34);
  }
  return param_1;
}



/* FUNCTION 3621 ; VA 0x005732f0 ; FUN_005732f0 */

undefined4 __thiscall FUN_005732f0(undefined4 param_1,byte param_2)

{
  FUN_0056e4b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 3622 ; VA 0x00573320 ; FUN_00573320 */

undefined4 __thiscall FUN_00573320(undefined4 param_1,byte param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00577b20();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3623 ; VA 0x00573370 ; FUN_00573370 */

undefined4 * __thiscall FUN_00573370(undefined4 *param_1,byte param_2)

{
  *param_1 = boost::exception_detail::error_info_base::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 3624 ; VA 0x005733a0 ; FUN_005733a0 */

undefined4 __thiscall FUN_005733a0(undefined4 param_1,byte param_2)

{
  FUN_0056e860();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 3625 ; VA 0x005733d0 ; FUN_005733d0 */

undefined4 __thiscall FUN_005733d0(undefined4 param_1,byte param_2)

{
  FUN_0056ea40();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x88);
  }
  return param_1;
}



/* FUNCTION 3626 ; VA 0x00573400 ; FUN_00573400 */

undefined4 __thiscall FUN_00573400(undefined4 param_1,byte param_2)

{
  FUN_016894b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x3c);
  }
  return param_1;
}



/* FUNCTION 3627 ; VA 0x00573430 ; FUN_00573430 */

undefined4 * __thiscall FUN_00573430(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::unknown_exception::vftable;
  param_1[5] = std::exception::vftable;
  FUN_0170c289(param_1 + 6);
  *param_1 = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[1] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[1] + 0x10))();
    if (cVar1 != '\0') {
      param_1[1] = 0;
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3628 ; VA 0x005734b0 ; FUN_005734b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_005734b0(int param_1,int param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  uint uVar3;
  int *piVar4;
  int iVar5;
  uint in_stack_ffffff58;
  uint uVar6;
  undefined4 in_stack_ffffff5c;
  undefined4 uVar7;
  undefined4 in_stack_ffffff60;
  undefined4 uVar8;
  undefined4 in_stack_ffffff64;
  undefined4 in_stack_ffffff68;
  undefined4 uVar9;
  undefined4 in_stack_ffffff6c;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  double *pdVar13;
  undefined4 uVar14;
  uint auStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  double dStack_34;
  int iStack_2c;
  int *piStack_28;
  undefined8 uStack_20;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794b88;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff78;
  pdVar13 = &dStack_34;
  uVar11 = 0x5734dd;
  ExceptionList = &pvStack_10;
  FUN_01682800(pdVar13);
  iVar5 = 0;
  piVar4 = (int *)0x0;
  iStack_2c = 0;
  piStack_28 = (int *)0x0;
  uStack_8 = 0;
  if (DAT_01d59328 != '\0') {
    puVar2 = (undefined4 *)FUN_01674e20(0x44);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = 0;
      puVar2[1] = 0;
      puVar2[2] = 0;
      puVar2[3] = 0;
      puVar2[4] = 0;
      puVar2[9] = 0;
      puVar2[10] = 0xf;
      *(undefined *)(puVar2 + 5) = 0;
      puVar2[0xf] = 0;
      puVar2[0x10] = 0xf;
      *(undefined *)(puVar2 + 0xb) = 0;
    }
    uStack_20 = 0.0;
    FUN_0055bac0(puVar2,param_1);
    iVar5 = (int)uStack_20;
    piVar4 = uStack_20._4_4_;
    pdVar13 = (double *)0x0;
    uVar11 = 0;
    iStack_2c = (int)uStack_20;
    piStack_28 = uStack_20._4_4_;
    in_stack_ffffff68 = 0;
    in_stack_ffffff6c = 0xf;
    in_stack_ffffff58 = in_stack_ffffff58 & 0xffffff00;
    FUN_005542c0("JobStarted",10);
    FUN_005db7a0(in_stack_ffffff58,in_stack_ffffff5c,in_stack_ffffff60,in_stack_ffffff64,
                 in_stack_ffffff68,in_stack_ffffff6c,uVar11,pdVar13);
  }
  LOCK();
  _DAT_01ea8440 = _DAT_01ea8440 + 1;
  UNLOCK();
  uVar6 = 0;
  FUN_01255470(8,0,0,0);
  FUN_01255490(in_stack_ffffff60,in_stack_ffffff64,in_stack_ffffff68,in_stack_ffffff6c,uVar11,
               pdVar13);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar11 = *(undefined4 *)(param_1 + 8);
  uVar8 = *(undefined4 *)(param_1 + 4);
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar4[1] = piVar4[1] + 1;
    UNLOCK();
  }
  uVar7 = 0x5735e9;
  FUN_00578470(uVar8,uVar11,param_2 + 4,uStack_18,iVar5,piVar4);
  uStack_8 = 1;
  LOCK();
  _DAT_01ea8440 = _DAT_01ea8440 + -1;
  UNLOCK();
  if (iVar5 != 0) {
    uVar14 = 0;
    uVar12 = 0;
    uVar9 = 0;
    uVar10 = 0xf;
    uVar6 = uVar6 & 0xffffff00;
    FUN_005542c0("JobFinished",0xb);
    FUN_005db7a0(uVar6,uVar7,uVar8,uVar11,uVar9,uVar10,uVar12,uVar14);
    if (DAT_01d59300 != '\0') {
      FUN_005db8c0();
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
    }
    FUN_00589740(iVar5,piVar4);
  }
  pdVar13 = (double *)FUN_01682800(&uStack_20);
  uStack_20 = *pdVar13 - dStack_34;
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  FUN_005542c0("BatchJob",8);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_00589ca0(auStack_4c,&uStack_20);
  if (0xf < uStack_38) {
    uVar3 = uStack_38 + 1;
    uVar6 = auStack_4c[0];
    if (0xfff < uVar3) {
      uVar6 = *(uint *)(auStack_4c[0] - 4);
      uVar3 = uStack_38 + 0x24;
      if (0x1f < (auStack_4c[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar3);
  }
  FUN_01255500();
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar5 = piVar4[1] + -1;
    piVar4[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3629 ; VA 0x00573724 ; Catch@00573724 */

void Catch_00573724(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  FUN_0056f5f0(0);
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x20) + 4))();
  FUN_0054eff0(uVar1);
  *(undefined *)(unaff_EBP + -4) = 4;
  FUN_0054eff0("BatchJob");
  *(undefined *)(unaff_EBP + -4) = 5;
  FUN_00589e10(unaff_EBP + -0x48,unaff_EBP + -0x60);
  FUN_005507b0();
  *(undefined *)(unaff_EBP + -4) = 3;
  FUN_005507b0();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 3630 ; VA 0x00573790 ; FUN_00573790 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00573790(int param_1,int param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  int iVar6;
  uint in_stack_ffffff54;
  uint uVar7;
  undefined4 in_stack_ffffff58;
  undefined4 uVar8;
  undefined4 in_stack_ffffff5c;
  undefined4 uVar9;
  undefined4 in_stack_ffffff60;
  undefined4 in_stack_ffffff64;
  undefined4 uVar10;
  undefined4 in_stack_ffffff68;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  double *pdVar14;
  undefined4 uVar15;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  double dStack_38;
  int iStack_30;
  int *piStack_2c;
  undefined8 uStack_24;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794bc8;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff74;
  pdVar14 = &dStack_38;
  uVar12 = 0x5737bd;
  ExceptionList = &pvStack_10;
  FUN_01682800(pdVar14);
  iVar6 = 0;
  piVar5 = (int *)0x0;
  iStack_30 = 0;
  piStack_2c = (int *)0x0;
  uStack_8 = 0;
  if (DAT_01d59328 != '\0') {
    puStack_1c = (undefined4 *)FUN_01674e20(0x44);
    if (puStack_1c == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puStack_1c = 0;
      puStack_1c[1] = 0;
      puStack_1c[2] = 0;
      puStack_1c[3] = 0;
      puStack_1c[4] = 0;
      puStack_1c[9] = 0;
      puStack_1c[10] = 0xf;
      *(undefined *)(puStack_1c + 5) = 0;
      puStack_1c[0xf] = 0;
      puStack_1c[0x10] = 0xf;
      *(undefined *)(puStack_1c + 0xb) = 0;
      puVar2 = puStack_1c;
    }
    uStack_24 = 0.0;
    FUN_0055bac0(puVar2,param_2);
    iVar6 = (int)uStack_24;
    piVar5 = uStack_24._4_4_;
    pdVar14 = (double *)0x0;
    uVar12 = 0;
    iStack_30 = (int)uStack_24;
    piStack_2c = uStack_24._4_4_;
    in_stack_ffffff64 = 0;
    in_stack_ffffff68 = 0xf;
    in_stack_ffffff54 = in_stack_ffffff54 & 0xffffff00;
    FUN_005542c0("JobStarted",10);
    FUN_005db7a0(in_stack_ffffff54,in_stack_ffffff58,in_stack_ffffff5c,in_stack_ffffff60,
                 in_stack_ffffff64,in_stack_ffffff68,uVar12,pdVar14);
  }
  LOCK();
  _DAT_01ea8440 = _DAT_01ea8440 + 1;
  UNLOCK();
  uVar7 = 0;
  FUN_01255470(8,0,0,0);
  FUN_01255490(in_stack_ffffff5c,in_stack_ffffff60,in_stack_ffffff64,in_stack_ffffff68,uVar12,
               pdVar14);
  uStack_8._0_1_ = 1;
  iVar3 = FUN_005a87f0(uStack_18,0xffffffff);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  *(int *)(param_2 + 4) = iVar3;
  uVar12 = *(undefined4 *)(param_1 + 8);
  uVar9 = *(undefined4 *)(param_1 + 4);
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
  }
  uVar8 = 0x5738e2;
  puStack_1c = (undefined4 *)uVar9;
  FUN_00578470(uVar9,uVar12,iVar3 + 4,uStack_18,iVar6,piVar5);
  uStack_8 = 1;
  LOCK();
  _DAT_01ea8440 = _DAT_01ea8440 + -1;
  UNLOCK();
  if (iVar6 != 0) {
    uVar15 = 0;
    uVar13 = 0;
    uVar10 = 0;
    uVar11 = 0xf;
    uVar7 = uVar7 & 0xffffff00;
    FUN_005542c0("JobFinished",0xb);
    FUN_005db7a0(uVar7,uVar8,uVar9,uVar12,uVar10,uVar11,uVar13,uVar15);
    if (DAT_01d59300 != '\0') {
      FUN_005db8c0();
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
    }
    FUN_00589740(iVar6,piVar5);
  }
  pdVar14 = (double *)FUN_01682800(&uStack_24);
  uStack_24 = *pdVar14 - dStack_38;
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  FUN_005542c0("BatchJobEx",10);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_00589ca0(auStack_50,&uStack_24);
  if (0xf < uStack_3c) {
    uVar4 = uStack_3c + 1;
    uVar7 = auStack_50[0];
    if (0xfff < uVar4) {
      uVar7 = *(uint *)(auStack_50[0] - 4);
      uVar4 = uStack_3c + 0x24;
      if (0x1f < (auStack_50[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar4);
  }
  FUN_01255500();
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar6 = piVar5[1] + -1;
    piVar5[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3631 ; VA 0x00573a1d ; Catch@00573a1d */

void Catch_00573a1d(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  FUN_0056f5f0(0);
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x24) + 4))();
  FUN_0054eff0(uVar1);
  *(undefined *)(unaff_EBP + -4) = 4;
  FUN_0054eff0("BatchJobEx");
  *(undefined *)(unaff_EBP + -4) = 5;
  FUN_00589e10(unaff_EBP + -0x4c,unaff_EBP + -100);
  FUN_005507b0();
  *(undefined *)(unaff_EBP + -4) = 3;
  FUN_005507b0();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 3632 ; VA 0x00573a90 ; FUN_00573a90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00573a90(undefined4 param_1,int param_2)

{
  double *pdVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined auStack_28 [8];
  double dStack_20;
  double dStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794bf0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01682800(&dStack_20);
  LOCK();
  _DAT_01ea850c = _DAT_01ea850c + 1;
  UNLOCK();
  FUN_01255470(8,0,0,0);
  FUN_01255490();
  uStack_8 = 0;
  FUN_0057ab10(param_2 + 4);
  LOCK();
  _DAT_01ea850c = _DAT_01ea850c + -1;
  UNLOCK();
  pdVar1 = (double *)FUN_01682800(auStack_28);
  dStack_18 = *pdVar1 - dStack_20;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0("CloseAllJobs",0xc);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00589ca0(auStack_40,&dStack_18);
  if (0xf < uStack_2c) {
    uVar3 = uStack_2c + 1;
    uVar2 = auStack_40[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_40[0] - 4);
      uVar3 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  FUN_01255500();
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3633 ; VA 0x00573ba0 ; FUN_00573ba0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00573ba0(undefined4 param_1,int param_2)

{
  int *piVar1;
  double *pdVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  uint auStack_4c [3];
  int iStack_40;
  int iStack_3c;
  uint uStack_38;
  undefined auStack_34 [8];
  double dStack_2c;
  undefined8 uStack_24;
  int iStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794c20;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01682800(&dStack_2c);
  LOCK();
  _DAT_01ea841c = _DAT_01ea841c + 1;
  UNLOCK();
  FUN_01255470(8,0,0,0);
  FUN_01255490();
  iVar6 = DAT_01ea84c0;
  iVar7 = 0;
  iStack_1c = DAT_01ea84c0;
  iStack_40 = 0;
  iStack_3c = 0;
  uStack_38 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uStack_24._0_5_ = (uint5)(DAT_01ea84c0 + 0xbc);
  FUN_00587410();
  piVar1 = *(int **)(iVar6 + 0xb4);
  uStack_8._0_1_ = 2;
  piStack_18 = (int *)*piVar1;
  if (piStack_18 == piVar1) {
    iVar6 = 0;
  }
  else {
    do {
      iVar6 = piStack_18[10];
      piStack_14 = piStack_18 + 4;
      pdVar2 = (double *)FUN_01682800(auStack_34);
      iVar7 = iStack_3c;
      if (*(double *)(iVar6 + 0x28) - *pdVar2 <= 0.0) {
        if (uStack_38 == iStack_3c) {
          FUN_00559960(iStack_3c,piStack_14);
        }
        else {
          FUN_0054ef60(piStack_14);
          iStack_3c = iVar7 + 0x18;
        }
      }
      iVar7 = iStack_3c;
      FUN_00551320();
      iVar6 = iStack_40;
    } while (piStack_18 != piVar1);
  }
  uStack_8._0_1_ = 3;
  if (uStack_24._4_1_ != '\0') {
    LOCK();
    uVar4 = *(uint *)uStack_24;
    *(uint *)uStack_24 = *(uint *)uStack_24 + 0x80000000;
    UNLOCK();
    if (((uVar4 & 0x40000000) == 0) && (-0x80000000 < (int)uVar4)) {
      LOCK();
      uVar4 = *(uint *)uStack_24;
      *(uint *)uStack_24 = *(uint *)uStack_24 | 0x40000000;
      UNLOCK();
      if ((uVar4 >> 0x1e & 1) == 0) {
        uVar3 = FUN_00554e40();
        SetEvent(uVar3);
      }
    }
  }
  uStack_8._0_1_ = 1;
  *(int *)(param_2 + 4) = (iVar7 - iVar6) / 0x18;
  for (; iVar6 != iVar7; iVar6 = iVar6 + 0x18) {
    FUN_0057ad10(iVar6,0);
  }
  uStack_8._0_1_ = 0;
  FUN_00577a40();
  LOCK();
  _DAT_01ea841c = _DAT_01ea841c + -1;
  UNLOCK();
  pdVar2 = (double *)FUN_01682800(auStack_34);
  uStack_24 = *pdVar2 - dStack_2c;
  iStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  FUN_005542c0("CloseExpiredJobs",0x10);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00589ca0(auStack_4c,&uStack_24);
  if (0xf < uStack_38) {
    uVar5 = uStack_38 + 1;
    uVar4 = auStack_4c[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_4c[0] - 4);
      uVar5 = uStack_38 + 0x24;
      if (0x1f < (auStack_4c[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  FUN_01255500();
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3634 ; VA 0x00573dc0 ; FUN_00573dc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00573dc0(int param_1)

{
  double *pdVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined auStack_30 [8];
  double dStack_28;
  double dStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794c50;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff7c;
  ExceptionList = &pvStack_10;
  FUN_01682800(&dStack_28);
  LOCK();
  _DAT_01ea8400 = _DAT_01ea8400 + 1;
  UNLOCK();
  uStack_8 = 0;
  FUN_01255470(8,0,0,0);
  FUN_01255490();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0057ad10(param_1 + 4,0);
  FUN_01255500();
  uStack_8 = 0xffffffff;
  LOCK();
  _DAT_01ea8400 = _DAT_01ea8400 + -1;
  UNLOCK();
  pdVar1 = (double *)FUN_01682800(auStack_30);
  dStack_1c = *pdVar1 - dStack_28;
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  FUN_005542c0("CloseJob",8);
  uStack_8 = 5;
  FUN_00589ca0(auStack_48,&dStack_1c);
  if (0xf < uStack_34) {
    uVar3 = uStack_34 + 1;
    uVar2 = auStack_48[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_48[0] - 4);
      uVar3 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3635 ; VA 0x00573ed7 ; Catch@00573ed7 */

void Catch_00573ed7(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  FUN_0056f5f0(0);
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x1c) + 4))();
  FUN_0054eff0(uVar1);
  *(undefined *)(unaff_EBP + -4) = 3;
  FUN_0054eff0("CloseJob");
  *(undefined *)(unaff_EBP + -4) = 4;
  FUN_00589e10(unaff_EBP + -0x5c,unaff_EBP + -0x74);
  FUN_005507b0();
  *(undefined *)(unaff_EBP + -4) = 2;
  FUN_005507b0();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 3636 ; VA 0x00573f40 ; FUN_00573f40 */

undefined FUN_00573f40(void)

{
  return 0;
}



/* FUNCTION 3637 ; VA 0x00573f50 ; FUN_00573f50 */

void FUN_00573f50(int param_1)

{
  undefined4 uVar1;
  code *pcVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794c68;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00564d60();
  FUN_0056f550(0);
  FUN_01255470(8,0,0,0);
  FUN_01255490();
  uStack_8 = 0;
  FUN_0054db20();
  uVar1 = *(undefined4 *)(param_1 + 4);
  FUN_0054ef60(*(undefined4 *)(param_1 + 8));
  FUN_0057d620(uVar1);
  pcVar2 = (code *)swi(3);
  (*pcVar2)();
  return;
}



/* FUNCTION 3638 ; VA 0x00573fe0 ; FUN_00573fe0 */

void __thiscall FUN_00573fe0(undefined4 param_1,int param_2,int param_3)

{
  code *pcVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794c68;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00564d60();
  FUN_0056f550(0);
  FUN_01255470(8,0,0,0);
  FUN_01255490();
  uStack_8 = 0;
  uVar2 = FUN_005a87f0(param_1,0xffffffff);
  *(undefined4 *)(param_3 + 4) = uVar2;
  FUN_0054db20();
  uVar2 = *(undefined4 *)(param_2 + 4);
  FUN_0054ef60(*(undefined4 *)(param_2 + 8));
  FUN_0057d620(uVar2);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 3639 ; VA 0x00574080 ; FUN_00574080 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall FUN_00574080(undefined4 param_1,int param_2,int param_3)

{
  double *pdVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined auStack_30 [8];
  double dStack_28;
  double dStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794ca0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff7c;
  ExceptionList = &pvStack_10;
  FUN_01682800(&dStack_28);
  LOCK();
  _DAT_01e90d7c = _DAT_01e90d7c + 1;
  UNLOCK();
  uStack_8 = 0;
  FUN_01255470(8,0,0,0);
  FUN_01255490();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0057efc0(param_2 + 4,*(undefined4 *)(param_2 + 0x1c),param_3 + 4,param_1);
  FUN_01255500();
  uStack_8 = 0xffffffff;
  LOCK();
  _DAT_01e90d7c = _DAT_01e90d7c + -1;
  UNLOCK();
  pdVar1 = (double *)FUN_01682800(auStack_30);
  dStack_1c = *pdVar1 - dStack_28;
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  FUN_005542c0("Execute",7);
  uStack_8 = 5;
  FUN_00589ca0(auStack_48,&dStack_1c);
  if (0xf < uStack_34) {
    uVar3 = uStack_34 + 1;
    uVar2 = auStack_48[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_48[0] - 4);
      uVar3 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3640 ; VA 0x005741a2 ; Catch@005741a2 */

void Catch_005741a2(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  FUN_0056f5f0(0);
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x1c) + 4))();
  FUN_0054eff0(uVar1);
  *(undefined *)(unaff_EBP + -4) = 3;
  FUN_0054eff0("Execute");
  *(undefined *)(unaff_EBP + -4) = 4;
  FUN_00589e10(unaff_EBP + -0x5c,unaff_EBP + -0x74);
  FUN_005507b0();
  *(undefined *)(unaff_EBP + -4) = 2;
  FUN_005507b0();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 3641 ; VA 0x00574210 ; FUN_00574210 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall FUN_00574210(undefined4 param_1,int param_2,int param_3)

{
  int iVar1;
  double *pdVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined auStack_30 [8];
  double dStack_28;
  double dStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794cd0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff7c;
  ExceptionList = &pvStack_10;
  FUN_01682800(&dStack_28);
  LOCK();
  _DAT_01e90d7c = _DAT_01e90d7c + 1;
  UNLOCK();
  uStack_8 = 0;
  FUN_01255470(8,0,0,0);
  FUN_01255490();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar1 = FUN_005a87f0(param_1,0xffffffff);
  *(int *)(param_3 + 4) = iVar1;
  FUN_0057efc0(param_2 + 4,*(undefined4 *)(param_2 + 0x1c),iVar1 + 4,param_1);
  FUN_01255500();
  uStack_8 = 0xffffffff;
  LOCK();
  _DAT_01e90d7c = _DAT_01e90d7c + -1;
  UNLOCK();
  pdVar2 = (double *)FUN_01682800(auStack_30);
  dStack_1c = *pdVar2 - dStack_28;
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  FUN_005542c0("ExecuteEx",9);
  uStack_8 = 5;
  FUN_00589ca0(auStack_48,&dStack_1c);
  if (0xf < uStack_34) {
    uVar4 = uStack_34 + 1;
    uVar3 = auStack_48[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_48[0] - 4);
      uVar4 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3642 ; VA 0x00574340 ; Catch@00574340 */

void Catch_00574340(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  FUN_0056f5f0(0);
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x1c) + 4))();
  FUN_0054eff0(uVar1);
  *(undefined *)(unaff_EBP + -4) = 3;
  FUN_0054eff0("ExecuteEx");
  *(undefined *)(unaff_EBP + -4) = 4;
  FUN_00589e10(unaff_EBP + -0x5c,unaff_EBP + -0x74);
  FUN_005507b0();
  *(undefined *)(unaff_EBP + -4) = 2;
  FUN_005507b0();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 3643 ; VA 0x005743b0 ; FUN_005743b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall FUN_005743b0(undefined4 param_1,undefined4 param_2,int param_3)

{
  double *pdVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined auStack_28 [8];
  double dStack_20;
  double dStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794bf0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01682800(&dStack_20);
  LOCK();
  _DAT_01ea8420 = _DAT_01ea8420 + 1;
  UNLOCK();
  FUN_01255470(8,0,0,0);
  FUN_01255490();
  uStack_8 = 0;
  FUN_005816a0(param_3 + 4,param_1);
  LOCK();
  _DAT_01ea8420 = _DAT_01ea8420 + -1;
  UNLOCK();
  pdVar1 = (double *)FUN_01682800(auStack_28);
  dStack_18 = *pdVar1 - dStack_20;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0("GetAllJobs",10);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00589ca0(auStack_40,&dStack_18);
  if (0xf < uStack_2c) {
    uVar3 = uStack_2c + 1;
    uVar2 = auStack_40[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_40[0] - 4);
      uVar3 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  FUN_01255500();
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3644 ; VA 0x005744c0 ; FUN_005744c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall FUN_005744c0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  double *pdVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined auStack_28 [8];
  double dStack_20;
  double dStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794bf0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01682800(&dStack_20);
  LOCK();
  _DAT_01ea8420 = _DAT_01ea8420 + 1;
  UNLOCK();
  FUN_01255470(8,0,0,0);
  FUN_01255490();
  uStack_8 = 0;
  iVar1 = FUN_005a87d0(param_1,0xffffffff);
  *(int *)(param_3 + 4) = iVar1;
  FUN_005816a0(iVar1 + 4,param_1);
  LOCK();
  _DAT_01ea8420 = _DAT_01ea8420 + -1;
  UNLOCK();
  pdVar2 = (double *)FUN_01682800(auStack_28);
  dStack_18 = *pdVar2 - dStack_20;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0("GetAllJobsEx",0xc);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00589ca0(auStack_40,&dStack_18);
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    uVar3 = auStack_40[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_40[0] - 4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  FUN_01255500();
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3645 ; VA 0x005745e0 ; FUN_005745e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_005745e0(int param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  double *pdVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined auStack_30 [8];
  double dStack_28;
  undefined8 uStack_20;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794d00;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff7c;
  ExceptionList = &pvStack_10;
  FUN_01682800(&dStack_28);
  LOCK();
  _DAT_01ea8414 = _DAT_01ea8414 + 1;
  UNLOCK();
  uStack_8 = 0;
  uStack_20 = (double)(CONCAT44(uStack_20._4_4_,DAT_01ea84c0 + 0xbc) & 0xffffff00ffffffff);
  FUN_00587410();
  uStack_8._0_1_ = 1;
  piVar2 = (int *)FUN_00581830(&param_1,param_1 + 4);
  iVar1 = *(int *)(*piVar2 + 0x28);
  pdVar3 = (double *)FUN_01682800(auStack_30);
  *(double *)(param_2 + 8) = *(double *)(iVar1 + 0x28) - *pdVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (uStack_20._4_1_ != '\0') {
    LOCK();
    uVar5 = *(uint *)uStack_20;
    *(uint *)uStack_20 = *(uint *)uStack_20 + 0x80000000;
    UNLOCK();
    if (((uVar5 & 0x40000000) == 0) && (-0x80000000 < (int)uVar5)) {
      LOCK();
      uVar5 = *(uint *)uStack_20;
      *(uint *)uStack_20 = *(uint *)uStack_20 | 0x40000000;
      UNLOCK();
      if ((uVar5 >> 0x1e & 1) == 0) {
        uVar4 = FUN_00554e40();
        SetEvent(uVar4);
      }
    }
  }
  uStack_8 = 0xffffffff;
  LOCK();
  _DAT_01ea8414 = _DAT_01ea8414 + -1;
  UNLOCK();
  pdVar3 = (double *)FUN_01682800(auStack_30);
  uStack_20 = *pdVar3 - dStack_28;
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  FUN_005542c0("GetExpiration",0xd);
  uStack_8 = 6;
  FUN_00589ca0(auStack_48,&uStack_20);
  if (0xf < uStack_34) {
    uVar6 = uStack_34 + 1;
    uVar5 = auStack_48[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_48[0] - 4);
      uVar6 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3646 ; VA 0x0057474a ; Catch@0057474a */

void Catch_0057474a(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  FUN_0056f5f0(0);
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x14) + 4))();
  FUN_0054eff0(uVar1);
  *(undefined *)(unaff_EBP + -4) = 4;
  FUN_0054eff0("GetExpiration");
  *(undefined *)(unaff_EBP + -4) = 5;
  FUN_00589e10(unaff_EBP + -0x5c,unaff_EBP + -0x74);
  FUN_005507b0();
  *(undefined *)(unaff_EBP + -4) = 3;
  FUN_005507b0();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 3647 ; VA 0x005747b0 ; FUN_005747b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall FUN_005747b0(undefined4 param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  undefined4 uVar2;
  char *pcVar3;
  double *pdVar4;
  int iVar5;
  char *pcVar6;
  uint uVar7;
  uint uVar8;
  int aiStack_58 [5];
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined auStack_28 [8];
  double dStack_20;
  double dStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794d20;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01682800(&dStack_18);
  LOCK();
  _DAT_01ea8504 = _DAT_01ea8504 + 1;
  UNLOCK();
  uVar2 = FUN_005a8850(param_1,0xffffffff);
  *(undefined4 *)(param_3 + 4) = uVar2;
  uVar2 = FUN_005a8870(param_1,0xffffffff);
  *(undefined4 *)(*(int *)(param_3 + 4) + 4) = uVar2;
  pcVar3 = (char *)FUN_00912100(aiStack_58);
  uStack_8 = 0;
  if (0xf < *(uint *)(pcVar3 + 0x14)) {
    pcVar3 = *(char **)pcVar3;
  }
  pcVar6 = pcVar3;
  do {
    cVar1 = *pcVar6;
    pcVar6 = pcVar6 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar3,(int)pcVar6 - (int)(pcVar3 + 1));
  uStack_8 = 0xffffffff;
  if (0xf < uStack_44) {
    uVar7 = uStack_44 + 1;
    iVar5 = aiStack_58[0];
    if (0xfff < uVar7) {
      iVar5 = *(int *)(aiStack_58[0] + -4);
      uVar7 = uStack_44 + 0x24;
      if (0x1f < (aiStack_58[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar7);
  }
  *(undefined4 *)(*(int *)(param_3 + 4) + 8) = *(undefined4 *)(DAT_01ea84c0 + 0xb8);
  LOCK();
  _DAT_01ea8504 = _DAT_01ea8504 + -1;
  UNLOCK();
  pdVar4 = (double *)FUN_01682800(auStack_28);
  dStack_20 = *pdVar4 - dStack_18;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0("GetStatus",9);
  uStack_8 = 1;
  FUN_00589ca0(auStack_40,&dStack_20);
  if (0xf < uStack_2c) {
    uVar8 = uStack_2c + 1;
    uVar7 = auStack_40[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_40[0] - 4);
      uVar8 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3648 ; VA 0x00574930 ; FUN_00574930 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00574930(void)

{
  char cVar1;
  char *pcVar2;
  double *pdVar3;
  char *pcVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int aiStack_58 [5];
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined auStack_28 [8];
  double dStack_20;
  double dStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794d20;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01682800(&dStack_18);
  LOCK();
  _DAT_01ea84fc = _DAT_01ea84fc + 1;
  UNLOCK();
  pcVar2 = (char *)FUN_00912100(aiStack_58);
  uStack_8 = 0;
  if (0xf < *(uint *)(pcVar2 + 0x14)) {
    pcVar2 = *(char **)pcVar2;
  }
  pcVar4 = pcVar2;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar2,(int)pcVar4 - (int)(pcVar2 + 1));
  uStack_8 = 0xffffffff;
  if (0xf < uStack_44) {
    uVar6 = uStack_44 + 1;
    iVar5 = aiStack_58[0];
    if (0xfff < uVar6) {
      iVar5 = *(int *)(aiStack_58[0] + -4);
      uVar6 = uStack_44 + 0x24;
      if (0x1f < (aiStack_58[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  LOCK();
  _DAT_01ea84fc = _DAT_01ea84fc + -1;
  UNLOCK();
  pdVar3 = (double *)FUN_01682800(auStack_28);
  dStack_20 = *pdVar3 - dStack_18;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0("GetVersion",10);
  uStack_8 = 1;
  FUN_00589ca0(auStack_40,&dStack_20);
  if (0xf < uStack_2c) {
    uVar7 = uStack_2c + 1;
    uVar6 = auStack_40[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_40[0] - 4);
      uVar7 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3649 ; VA 0x00574a80 ; FUN_00574a80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall FUN_00574a80(undefined4 param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  double *pdVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined auStack_28 [8];
  double dStack_20;
  double dStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794d38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01682800(&dStack_18);
  LOCK();
  _DAT_01ea83f0 = _DAT_01ea83f0 + 1;
  UNLOCK();
  uVar1 = FUN_005a8870(param_1,0xffffffff);
  *(undefined4 *)(param_3 + 4) = uVar1;
  FUN_005542c0("Hello World",0xb);
  LOCK();
  _DAT_01ea83f0 = _DAT_01ea83f0 + -1;
  UNLOCK();
  pdVar2 = (double *)FUN_01682800(auStack_28);
  dStack_20 = *pdVar2 - dStack_18;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0("HelloWorld",10);
  uStack_8 = 0;
  FUN_00589ca0(auStack_40,&dStack_20);
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    uVar3 = auStack_40[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_40[0] - 4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3650 ; VA 0x00574b70 ; FUN_00574b70 */

void __fastcall FUN_00574b70(int param_1)

{
  undefined4 *puVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794d78;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x28) = 300;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("SecurityDataTimer",0x11);
  uStack_8 = 0;
  puVar1 = (undefined4 *)FUN_0056f450(auStack_28);
  uStack_8 = 0xffffffff;
  *puVar1 = FUN_005756b0;
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  *(undefined4 *)(param_1 + 0x2c) = 0x78;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("ClientSettingsTimer",0x13);
  uStack_8 = 1;
  puVar1 = (undefined4 *)FUN_0056f450(auStack_28);
  uStack_8 = 0xffffffff;
  *puVar1 = FUN_005755b0;
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  FUN_005542c0("UA-43420590-13",0xe);
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("GoogleAnalyticsAccountPropertyID",0x20);
  uStack_8 = 2;
  puVar1 = (undefined4 *)FUN_0056f450(auStack_28);
  uStack_8 = 0xffffffff;
  *puVar1 = FUN_005755d0;
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  *(undefined4 *)(param_1 + 0x48) = 500;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("GoogleAnalyticsThreadPoolMaxScheduleSize",0x28);
  uStack_8 = 3;
  puVar1 = (undefined4 *)FUN_0056f450(auStack_28);
  uStack_8 = 0xffffffff;
  *puVar1 = FUN_00575690;
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  *(undefined4 *)(param_1 + 0x4c) = 10;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0("GoogleAnalyticsLoad",0x13);
  uStack_8 = 4;
  puVar1 = (undefined4 *)FUN_0056f450(auStack_40);
  *puVar1 = FUN_00575670;
  if (0xf < uStack_2c) {
    uVar3 = uStack_2c + 1;
    uVar2 = auStack_40[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_40[0] - 4);
      uVar3 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3651 ; VA 0x00574e30 ; FUN_00574e30 */

void __thiscall FUN_00574e30(int param_1,undefined4 param_2)

{
  double dVar1;
  undefined uVar2;
  undefined4 uVar3;
  char *pcVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  undefined auStack_88 [24];
  int iStack_70;
  uint uStack_6c;
  undefined4 uStack_5c;
  uint uStack_58;
  uint uStack_54;
  undefined4 uStack_44;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794e02;
  pvStack_10 = ExceptionList;
  uStack_5c = 0;
  uStack_58 = 0xf;
  uStack_6c = uStack_6c & 0xffffff00;
  uStack_44 = 0;
  uStack_40 = 0xf;
  uStack_54 = uStack_54 & 0xffffff00;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_8 = 0;
  if (*(char *)(param_1 + 0x91) == '\0') {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_0151b520();
    puVar5 = (undefined4 *)FUN_00581a10(auStack_28);
    uStack_8._0_1_ = 7;
    if (0xf < (uint)puVar5[5]) {
      puVar5 = (undefined4 *)*puVar5;
    }
    FUN_00937030(puVar5,"RCCFlagOverride",param_2,&iStack_70,uVar3);
    uStack_8._0_1_ = 0;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 0;
    if (0xf < uStack_14) {
      if ((0xfff < uStack_14 + 1) && (0x1f < (auStack_28[0] - *(int *)(auStack_28[0] - 4)) - 4)) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      FUN_01674ea0();
    }
    if (iStack_70 == 0) {
      dVar1 = (double)CONCAT44(uStack_34,uStack_38) * DAT_018c0d70;
      if (*(int *)(param_1 + 0xe0) == 0) {
        pcVar4 = "RCCServiceThumbnail";
        if (*(char *)(param_1 + 0x90) == '\0') {
          pcVar4 = "RCCService";
        }
      }
      else {
        pcVar4 = (char *)(param_1 + 0xd0);
        if (0xf < *(uint *)(param_1 + 0xe4)) {
          pcVar4 = *(char **)pcVar4;
        }
      }
      uVar3 = FUN_01675640(auStack_88,"SettingsLoadSuccess-%s",pcVar4);
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      FUN_00878cf0(uVar3,dVar1,0);
      FUN_005507b0();
      goto LAB_005752c4;
    }
    FUN_01678ee0();
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0();
    uStack_8._0_1_ = 9;
    FUN_008783f0(auStack_28,1,1);
    uStack_8._0_1_ = 0;
    FUN_005507b0();
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8._0_1_ = 10;
    FUN_0151f950();
    FUN_0151fcf0();
    FUN_0151f850();
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0();
    uStack_8._0_1_ = 0xb;
    FUN_01520d20(auStack_28,10000,1);
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
  }
  else {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_0151a8d0();
    uStack_8._0_1_ = 1;
    FUN_0054f050(uVar3);
    uStack_8._0_1_ = 2;
    FUN_00937360(auStack_28,"RCCFlagOverride",param_2,&iStack_70);
    FUN_00550800();
    uStack_8._0_1_ = 0;
    FUN_00550800();
    if (iStack_70 == 0) {
      if (*(int *)(param_1 + 0xe0) == 0) {
        pcVar4 = "RCCServiceThumbnail";
        if (*(char *)(param_1 + 0x90) == '\0') {
          pcVar4 = "RCCService";
        }
      }
      else {
        pcVar4 = (char *)(param_1 + 0xd0);
        if (0xf < *(uint *)(param_1 + 0xe4)) {
          pcVar4 = *(char **)pcVar4;
        }
      }
      uVar3 = FUN_01675640(auStack_88,"SettingsLoadSuccessFile-%s",pcVar4);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      FUN_008783f0(uVar3,1,0);
      FUN_005507b0();
      goto LAB_005752c4;
    }
    FUN_01678ee0();
    if (*(int *)(param_1 + 0xe0) == 0) {
      pcVar4 = "RCCServiceThumbnail";
      if (*(char *)(param_1 + 0x90) == '\0') {
        pcVar4 = "RCCService";
      }
    }
    else {
      pcVar4 = (char *)(param_1 + 0xd0);
      if (0xf < *(uint *)(param_1 + 0xe4)) {
        pcVar4 = *(char **)pcVar4;
      }
    }
    uVar3 = FUN_01675640(auStack_88,"SettingsLoadFailureFile-%s",pcVar4);
    uStack_8._0_1_ = 4;
    FUN_008783f0(uVar3,1,1);
    uStack_8._0_1_ = 0;
    FUN_005507b0();
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8._0_1_ = 5;
    FUN_0151f950();
    FUN_0151fcf0();
    FUN_0151f850();
    FUN_0151f950();
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0();
    uStack_8._0_1_ = 6;
    FUN_01520d20(auStack_28,10000,1);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
  }
  FUN_005507b0();
  FUN_01675310();
  FUN_0151f7f0();
LAB_005752c4:
  if (0xf < uStack_40) {
    uVar7 = uStack_40 + 1;
    uVar6 = uStack_54;
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(uStack_54 - 4);
      uVar7 = uStack_40 + 0x24;
      if (0x1f < (uStack_54 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_44 = 0;
  uStack_40 = 0xf;
  uStack_54 = uStack_54 & 0xffffff00;
  if (0xf < uStack_58) {
    uVar7 = uStack_58 + 1;
    uVar6 = uStack_6c;
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(uStack_6c - 4);
      uVar7 = uStack_58 + 0x24;
      if (0x1f < (uStack_6c - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3652 ; VA 0x00575360 ; FUN_00575360 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall FUN_00575360(undefined4 param_1,int param_2,int param_3)

{
  double *pdVar1;
  uint uVar2;
  uint uVar3;
  undefined4 in_stack_ffffff8c;
  undefined4 in_stack_ffffff90;
  undefined4 in_stack_ffffff94;
  undefined4 in_stack_ffffff98;
  undefined4 uVar4;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined auStack_28 [8];
  double dStack_20;
  double dStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794bf0;
  pvStack_10 = ExceptionList;
  pdVar1 = &dStack_20;
  uVar4 = 0x575387;
  ExceptionList = &pvStack_10;
  FUN_01682800(pdVar1);
  LOCK();
  _DAT_01ea84d0 = _DAT_01ea84d0 + 1;
  UNLOCK();
  FUN_01255470(8,0,0,0);
  FUN_01255490(in_stack_ffffff8c,in_stack_ffffff90,in_stack_ffffff94,in_stack_ffffff98,uVar4,pdVar1)
  ;
  uStack_8 = 0;
  FUN_005887a0(*(undefined4 *)(param_2 + 4),*(undefined4 *)(param_2 + 8),param_3 + 4,param_1,1);
  LOCK();
  _DAT_01ea84d0 = _DAT_01ea84d0 + -1;
  UNLOCK();
  pdVar1 = (double *)FUN_01682800(auStack_28);
  dStack_18 = *pdVar1 - dStack_20;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0("OpenJob",7);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00589ca0(auStack_40,&dStack_18);
  if (0xf < uStack_2c) {
    uVar3 = uStack_2c + 1;
    uVar2 = auStack_40[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_40[0] - 4);
      uVar3 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  FUN_01255500();
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3653 ; VA 0x00575480 ; FUN_00575480 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall FUN_00575480(undefined4 param_1,int param_2,int param_3)

{
  int iVar1;
  double *pdVar2;
  uint uVar3;
  uint uVar4;
  undefined4 in_stack_ffffff8c;
  undefined4 in_stack_ffffff90;
  undefined4 in_stack_ffffff94;
  undefined4 in_stack_ffffff98;
  undefined4 uVar5;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined auStack_28 [8];
  double dStack_20;
  double dStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794bf0;
  pvStack_10 = ExceptionList;
  pdVar2 = &dStack_20;
  uVar5 = 0x5754a7;
  ExceptionList = &pvStack_10;
  FUN_01682800(pdVar2);
  LOCK();
  _DAT_01ea84d0 = _DAT_01ea84d0 + 1;
  UNLOCK();
  FUN_01255470(8,0,0,0);
  FUN_01255490(in_stack_ffffff8c,in_stack_ffffff90,in_stack_ffffff94,in_stack_ffffff98,uVar5,pdVar2)
  ;
  uStack_8 = 0;
  iVar1 = FUN_005a87f0(param_1,0xffffffff);
  *(int *)(param_3 + 4) = iVar1;
  FUN_005887a0(*(undefined4 *)(param_2 + 4),*(undefined4 *)(param_2 + 8),iVar1 + 4,param_1,1);
  LOCK();
  _DAT_01ea84d0 = _DAT_01ea84d0 + -1;
  UNLOCK();
  pdVar2 = (double *)FUN_01682800(auStack_28);
  dStack_18 = *pdVar2 - dStack_20;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0("OpenJobEx",9);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00589ca0(auStack_40,&dStack_18);
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    uVar3 = auStack_40[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_40[0] - 4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  FUN_01255500();
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3654 ; VA 0x005755b0 ; FUN_005755b0 */

void FUN_005755b0(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_01717832(param_1);
  *(undefined4 *)(DAT_01e90d68 + 0x2c) = uVar1;
  return;
}



/* FUNCTION 3655 ; VA 0x005755d0 ; FUN_005755d0 */

void FUN_005755d0(char *param_1)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  uint uVar4;
  uint uVar5;
  uint *puVar6;
  uint uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  uint uStack_8;
  
  uStack_c = 0;
  uStack_8 = 0xf;
  uStack_1c = uStack_1c & 0xffffff00;
  pcVar3 = param_1;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_1,(int)pcVar3 - (int)(param_1 + 1));
  iVar2 = DAT_01e90d68;
  puVar6 = (uint *)(DAT_01e90d68 + 0x30);
  if (puVar6 != &uStack_1c) {
    FUN_005507b0();
    *puVar6 = uStack_1c;
    *(undefined4 *)(iVar2 + 0x34) = uStack_18;
    *(undefined4 *)(iVar2 + 0x38) = uStack_14;
    *(undefined4 *)(iVar2 + 0x3c) = uStack_10;
    *(ulonglong *)(iVar2 + 0x40) = CONCAT44(uStack_8,uStack_c);
    return;
  }
  if (0xf < uStack_8) {
    uVar5 = uStack_8 + 1;
    uVar4 = uStack_1c;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(uStack_1c - 4);
      uVar5 = uStack_8 + 0x24;
      if (0x1f < (uStack_1c - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  return;
}



/* FUNCTION 3656 ; VA 0x00575670 ; FUN_00575670 */

void FUN_00575670(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_01717832(param_1);
  *(undefined4 *)(DAT_01e90d68 + 0x4c) = uVar1;
  return;
}



/* FUNCTION 3657 ; VA 0x00575690 ; FUN_00575690 */

void FUN_00575690(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_01717832(param_1);
  *(undefined4 *)(DAT_01e90d68 + 0x48) = uVar1;
  return;
}



/* FUNCTION 3658 ; VA 0x005756b0 ; FUN_005756b0 */

void FUN_005756b0(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_01717832(param_1);
  *(undefined4 *)(DAT_01e90d68 + 0x28) = uVar1;
  return;
}



/* FUNCTION 3659 ; VA 0x005756d0 ; FUN_005756d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_005756d0(int param_1)

{
  int iVar1;
  int *piVar2;
  double *pdVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  undefined auStack_38 [8];
  double dStack_30;
  double dStack_28;
  uint *puStack_1c;
  char cStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794e38;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff74;
  ExceptionList = &pvStack_10;
  FUN_01682800(&dStack_30);
  LOCK();
  _DAT_01ea8500 = _DAT_01ea8500 + 1;
  UNLOCK();
  uStack_8 = 0;
  FUN_01255470(8,0,0,0);
  FUN_01255490();
  iVar1 = param_1;
  uStack_8._0_1_ = 1;
  cStack_18 = '\0';
  puStack_1c = (uint *)(DAT_01ea84c0 + 0xbc);
  dStack_28 = *(double *)(param_1 + 0x20);
  FUN_00587410();
  uStack_8._0_1_ = 2;
  piVar2 = (int *)FUN_00581830(&param_1,iVar1 + 8);
  iVar1 = *(int *)(*piVar2 + 0x28);
  pdVar3 = (double *)FUN_01682800(auStack_38);
  dStack_28 = dStack_28 + *pdVar3;
  *(double *)(iVar1 + 0x28) = dStack_28;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (cStack_18 != '\0') {
    LOCK();
    uVar5 = *puStack_1c;
    *puStack_1c = *puStack_1c + 0x80000000;
    UNLOCK();
    if (((uVar5 & 0x40000000) == 0) && (-0x80000000 < (int)uVar5)) {
      LOCK();
      uVar5 = *puStack_1c;
      *puStack_1c = *puStack_1c | 0x40000000;
      UNLOCK();
      if ((uVar5 >> 0x1e & 1) == 0) {
        uVar4 = FUN_00554e40();
        SetEvent(uVar4);
      }
    }
  }
  FUN_01255500();
  uStack_8 = 0xffffffff;
  LOCK();
  _DAT_01ea8500 = _DAT_01ea8500 + -1;
  UNLOCK();
  pdVar3 = (double *)FUN_01682800(auStack_38);
  dStack_28 = *pdVar3 - dStack_30;
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  FUN_005542c0("RenewLease",10);
  uStack_8 = 7;
  FUN_00589ca0(auStack_50,&dStack_28);
  if (0xf < uStack_3c) {
    uVar6 = uStack_3c + 1;
    uVar5 = auStack_50[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_50[0] - 4);
      uVar6 = uStack_3c + 0x24;
      if (0x1f < (auStack_50[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 3660 ; VA 0x00575870 ; Catch@00575870 */

void Catch_00575870(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  FUN_0056f5f0(0);
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x1c) + 4))();
  FUN_0054eff0(uVar1);
  *(undefined *)(unaff_EBP + -4) = 5;
  FUN_0054eff0("RenewLease");
  *(undefined *)(unaff_EBP + -4) = 6;
  FUN_00589e10(unaff_EBP + -100,unaff_EBP + -0x7c);
  FUN_005507b0();
  *(undefined *)(unaff_EBP + -4) = 4;
  FUN_005507b0();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 3661 ; VA 0x005758e0 ; FUN_005758e0 */

void __fastcall FUN_005758e0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  FUN_0170c6f0(param_1,iVar1,param_1[4] + 1);
  uVar2 = param_1[5] + 1;
  iVar3 = iVar1;
  if (0xfff < uVar2) {
    iVar3 = *(int *)(iVar1 + -4);
    uVar2 = param_1[5] + 0x24;
    if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar3,uVar2);
  param_1[5] = 0xf;
  return;
}



/* FUNCTION 3662 ; VA 0x00575930 ; FUN_00575930 */

uint __thiscall FUN_00575930(uint *param_1,uint param_2)

{
  uint in_EAX;
  uint uVar1;
  int iVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 == 0) {
    return in_EAX & 0xffffff00;
  }
  if (0x1fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  param_2 = param_2 * 8;
  if (param_2 < 0x1000) {
    if (param_2 != 0) {
      uVar1 = FUN_01674e20(param_2);
      *param_1 = uVar1;
      param_1[1] = uVar1;
      param_1[2] = *param_1 + param_2;
      return CONCAT31((int3)(*param_1 + param_2 >> 8),1);
    }
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = *param_1;
    return CONCAT31((int3)(*param_1 >> 8),1);
  }
  uVar1 = param_2 + 0x23;
  if (uVar1 <= param_2) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar1 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar1 - 4) = iVar2;
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + param_2;
    return CONCAT31((int3)(*param_1 + param_2 >> 8),1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 3663 ; VA 0x005759f0 ; FUN_005759f0 */

undefined4 __thiscall FUN_005759f0(uint *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 == 0) {
    return 0;
  }
  if (0x13b13b1 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  param_2 = param_2 * 0xd0;
  if (param_2 < 0x1000) {
    if (param_2 != 0) {
      uVar1 = FUN_01674e20(param_2);
      *param_1 = uVar1;
      param_1[1] = uVar1;
      param_1[2] = *param_1 + param_2;
      return CONCAT31((int3)(*param_1 + param_2 >> 8),1);
    }
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = *param_1;
    return CONCAT31((int3)(*param_1 >> 8),1);
  }
  uVar1 = param_2 + 0x23;
  if (uVar1 <= param_2) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar1 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar1 - 4) = iVar2;
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + param_2;
    return CONCAT31((int3)(*param_1 + param_2 >> 8),1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 3664 ; VA 0x00575ab0 ; FUN_00575ab0 */

void FUN_00575ab0(void)

{
  int iVar1;
  
  iVar1 = FUN_01674e20(0x20);
  *(int *)iVar1 = iVar1;
  *(int *)(iVar1 + 4) = iVar1;
  *(int *)(iVar1 + 8) = iVar1;
  *(undefined2 *)(iVar1 + 0xc) = 0x101;
  return;
}



/* FUNCTION 3665 ; VA 0x00575ad0 ; FUN_00575ad0 */

void FUN_00575ad0(void)

{
  int iVar1;
  
  iVar1 = FUN_01674e20(0x1c);
  *(int *)iVar1 = iVar1;
  *(int *)(iVar1 + 4) = iVar1;
  *(int *)(iVar1 + 8) = iVar1;
  *(undefined2 *)(iVar1 + 0xc) = 0x101;
  return;
}



/* FUNCTION 3666 ; VA 0x00575af0 ; FUN_00575af0 */

void FUN_00575af0(void)

{
  int iVar1;
  
  iVar1 = FUN_01674e20(0x2c);
  *(int *)iVar1 = iVar1;
  *(int *)(iVar1 + 4) = iVar1;
  *(int *)(iVar1 + 8) = iVar1;
  *(undefined2 *)(iVar1 + 0xc) = 0x101;
  return;
}



/* FUNCTION 3667 ; VA 0x00575b10 ; FUN_00575b10 */

void FUN_00575b10(void)

{
  int iVar1;
  
  iVar1 = FUN_01674e20(0x30);
  *(int *)iVar1 = iVar1;
  *(int *)(iVar1 + 4) = iVar1;
  *(int *)(iVar1 + 8) = iVar1;
  *(undefined2 *)(iVar1 + 0xc) = 0x101;
  return;
}



/* FUNCTION 3668 ; VA 0x00575b30 ; FUN_00575b30 */

void FUN_00575b30(void)

{
  int iVar1;
  
  iVar1 = FUN_01674e20(0x28);
  *(int *)iVar1 = iVar1;
  *(int *)(iVar1 + 4) = iVar1;
  *(int *)(iVar1 + 8) = iVar1;
  *(undefined2 *)(iVar1 + 0xc) = 0x101;
  return;
}



/* FUNCTION 3669 ; VA 0x00575b50 ; FUN_00575b50 */

void FUN_00575b50(int param_1,int param_2)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_01674e20(0xc);
  if (param_1 == 0) {
    *piVar1 = (int)piVar1;
    piVar1[1] = (int)piVar1;
    return;
  }
  *piVar1 = param_1;
  piVar1[1] = param_2;
  return;
}



/* FUNCTION 3670 ; VA 0x00575b80 ; FUN_00575b80 */

void __fastcall FUN_00575b80(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x1c);
  *puVar1 = *param_1;
  puVar1[1] = *param_1;
  puVar1[2] = *param_1;
  return;
}



/* FUNCTION 3671 ; VA 0x00575ba0 ; FUN_00575ba0 */

void __fastcall FUN_00575ba0(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x2c);
  *puVar1 = *param_1;
  puVar1[1] = *param_1;
  puVar1[2] = *param_1;
  return;
}



/* FUNCTION 3672 ; VA 0x00575bc0 ; FUN_00575bc0 */

void __fastcall FUN_00575bc0(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x30);
  *puVar1 = *param_1;
  puVar1[1] = *param_1;
  puVar1[2] = *param_1;
  return;
}



/* FUNCTION 3673 ; VA 0x00575be0 ; FUN_00575be0 */

void __fastcall FUN_00575be0(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x28);
  *puVar1 = *param_1;
  puVar1[1] = *param_1;
  puVar1[2] = *param_1;
  return;
}



/* FUNCTION 3674 ; VA 0x00575c00 ; FUN_00575c00 */

void __thiscall FUN_00575c00(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[2] - iVar1;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  *param_1 = param_2;
  param_1[1] = param_3 + param_2;
  param_1[2] = param_4 + param_2;
  return;
}



/* FUNCTION 3675 ; VA 0x00575c60 ; FUN_00575c60 */

void __thiscall FUN_00575c60(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if (*param_1 != 0) {
    FUN_00559500(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar3 = param_1[2] - iVar1 & 0xffffffe0;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  *param_1 = param_2;
  param_1[1] = param_3 * 0x20 + param_2;
  param_1[2] = param_4 * 0x20 + param_2;
  return;
}



/* FUNCTION 3676 ; VA 0x00575cd0 ; FUN_00575cd0 */

void __thiscall FUN_00575cd0(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_00559570(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x18) * 0x18;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  *param_1 = param_2;
  param_1[1] = param_2 + param_3 * 0x18;
  param_1[2] = param_2 + param_4 * 0x18;
  return;
}



/* FUNCTION 3677 ; VA 0x00575d60 ; FUN_00575d60 */

void __thiscall FUN_00575d60(int param_1,undefined4 *param_2)

{
  *param_2 = std::_Func_impl_no_alloc<void_(__cdecl*)(void),void>::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  return;
}



/* FUNCTION 3678 ; VA 0x00575d80 ; FUN_00575d80 */

undefined4 * __thiscall FUN_00575d80(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_02fa2349d2109e7fb76f34aa9c25047c>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  param_2[3] = 0;
  param_2[4] = 0;
  if (*(int *)(param_1 + 0x10) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x10) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[3] = *(undefined4 *)(param_1 + 0xc);
  param_2[4] = *(undefined4 *)(param_1 + 0x10);
  return param_2;
}



/* FUNCTION 3679 ; VA 0x00575de0 ; FUN_00575de0 */

undefined4 * __thiscall FUN_00575de0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_7850e3f498f96950946230d03482994b>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  param_2[3] = 0;
  param_2[4] = 0;
  if (*(int *)(param_1 + 0x10) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x10) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[3] = *(undefined4 *)(param_1 + 0xc);
  param_2[4] = *(undefined4 *)(param_1 + 0x10);
  param_2[5] = 0;
  param_2[6] = 0;
  if (*(int *)(param_1 + 0x18) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x18) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[5] = *(undefined4 *)(param_1 + 0x14);
  param_2[6] = *(undefined4 *)(param_1 + 0x18);
  return param_2;
}



/* FUNCTION 3680 ; VA 0x00575e70 ; FUN_00575e70 */

undefined4 * __thiscall FUN_00575e70(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_ce3ec86729cff41111bf35de00f2a9a5>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  param_2[3] = 0;
  param_2[4] = 0;
  if (*(int *)(param_1 + 0x10) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x10) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[3] = *(undefined4 *)(param_1 + 0xc);
  param_2[4] = *(undefined4 *)(param_1 + 0x10);
  param_2[5] = 0;
  param_2[6] = 0;
  if (*(int *)(param_1 + 0x18) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x18) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[5] = *(undefined4 *)(param_1 + 0x14);
  param_2[6] = *(undefined4 *)(param_1 + 0x18);
  return param_2;
}



/* FUNCTION 3681 ; VA 0x00575f00 ; FUN_00575f00 */

void __thiscall FUN_00575f00(undefined4 param_1,char param_2)

{
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,8);
  }
  return;
}



/* FUNCTION 3682 ; VA 0x00575f20 ; FUN_00575f20 */

void __thiscall FUN_00575f20(undefined4 param_1,char param_2)

{
  FUN_0056b650();
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0x14);
  }
  return;
}



/* FUNCTION 3683 ; VA 0x00575f50 ; FUN_00575f50 */

void __thiscall FUN_00575f50(undefined4 param_1,char param_2)

{
  FUN_0056b6b0();
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0x1c);
  }
  return;
}



/* FUNCTION 3684 ; VA 0x00575f80 ; FUN_00575f80 */

void __fastcall FUN_00575f80(int *param_1)

{
  if (param_1 != (int *)0x0) {
    (**(code **)(*param_1 + 8))(1);
  }
  return;
}



/* FUNCTION 3685 ; VA 0x00575f90 ; FUN_00575f90 */

void __fastcall FUN_00575f90(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_0056dbe0();
    FUN_01674ea0(iVar1,0x70);
  }
  return;
}



/* FUNCTION 3686 ; VA 0x00575fb0 ; FUN_00575fb0 */

void __fastcall FUN_00575fb0(int param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_00577b20();
    FUN_01674ea0(iVar1,0xc);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3687 ; VA 0x00576000 ; FUN_00576000 */

void __fastcall FUN_00576000(int param_1)

{
  if (*(int *)(param_1 + 0xc) != 0) {
    FUN_005731c0(1);
  }
  return;
}



/* FUNCTION 3688 ; VA 0x00576010 ; FUN_00576010 */

void FUN_00576010(void)

{
  FUN_0056d080();
  return;
}



/* FUNCTION 3689 ; VA 0x00576020 ; FUN_00576020 */

void FUN_00576020(void)

{
  FUN_0056dd40();
  return;
}



/* FUNCTION 3690 ; VA 0x00576030 ; FUN_00576030 */

void __fastcall FUN_00576030(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  FUN_0056ca60();
  piVar2 = *(int **)(param_1 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_0151f390();
  return;
}



/* FUNCTION 3691 ; VA 0x00576070 ; FUN_00576070 */

void __fastcall FUN_00576070(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x20);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0xc);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  return;
}



/* FUNCTION 3692 ; VA 0x005760c0 ; FUN_005760c0 */

uint __fastcall FUN_005760c0(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  undefined4 uVar7;
  undefined **ppuStack_34;
  undefined auStack_30 [16];
  undefined auStack_20 [8];
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_01794b50;
  pvStack_10 = ExceptionList;
  uVar6 = *(uint *)(param_1 + 0xc);
  uStack_8 = 0;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  if (uVar6 != 0) {
    puStack_18 = (uint *)(uVar6 + 0x24);
    cStack_14 = '\0';
    ExceptionList = &pvStack_10;
    uVar6 = FUN_00587410();
    if ((*(char *)(*(int *)(param_1 + 0xc) + 0x18) == '\0') &&
       (*(char *)(*(int *)(param_1 + 0xc) + 0x20) == '\0')) {
      uVar7 = FUN_0168a9f0();
      FUN_0056abb0(1,uVar7);
      ppuStack_34 = boost::broken_promise::vftable;
      uVar7 = FUN_0055dd80(auStack_20,&ppuStack_34);
      FUN_00587d90(uVar7,&puStack_18);
      FUN_00550ad0();
      ppuStack_34 = std::exception::vftable;
      uVar6 = FUN_0170c289(auStack_30);
    }
    uStack_8 = 1;
    if (cStack_14 != '\0') {
      LOCK();
      uVar6 = *puStack_18;
      *puStack_18 = *puStack_18 + 0x80000000;
      UNLOCK();
      if (((uVar6 & 0x40000000) == 0) && (-0x80000000 < (int)uVar6)) {
        LOCK();
        uVar3 = *puStack_18;
        *puStack_18 = *puStack_18 | 0x40000000;
        UNLOCK();
        if ((uVar3 >> 0x1e & 1) == 0) {
          uVar7 = FUN_00554e40();
          uVar6 = SetEvent(uVar7);
        }
      }
    }
  }
  piVar5 = *(int **)(param_1 + 0x10);
  _uStack_8 = CONCAT31(uStack_7,2);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar3 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar6 = (**(code **)(*piVar5 + 4))();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uVar6 = (**(code **)(*piVar5 + 8))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 3693 ; VA 0x005761e0 ; FUN_005761e0 */

void FUN_005761e0(void)

{
  FUN_0056df10();
  return;
}



/* FUNCTION 3694 ; VA 0x005761f0 ; FUN_005761f0 */

void __fastcall FUN_005761f0(int param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  puVar1 = *(undefined4 **)(param_1 + 0xc);
  ExceptionList = &pvStack_10;
  FUN_008a45f0(puVar1);
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3695 ; VA 0x00576230 ; FUN_00576230 */

void __thiscall FUN_00576230(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00559500(param_2,param_3,param_1);
  return;
}



/* FUNCTION 3696 ; VA 0x00576250 ; FUN_00576250 */

void FUN_00576250(int *param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  if (param_1 != param_2) {
    do {
      uVar1 = param_1[5];
      if (0xf < uVar1) {
        iVar2 = *param_1;
        uVar4 = uVar1 + 1;
        iVar3 = iVar2;
        if (0xfff < uVar4) {
          iVar3 = *(int *)(iVar2 + -4);
          uVar4 = uVar1 + 0x24;
          if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar3,uVar4);
      }
      param_1[4] = 0;
      param_1[5] = 0xf;
      *(undefined *)param_1 = 0;
      param_1 = param_1 + 8;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 3697 ; VA 0x005762c0 ; FUN_005762c0 */

void __thiscall FUN_005762c0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00559570(param_2,param_3,param_1);
  return;
}



/* FUNCTION 3698 ; VA 0x005762e0 ; FUN_005762e0 */

void __thiscall FUN_005762e0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00559720(param_2,param_3,param_1);
  return;
}



/* FUNCTION 3699 ; VA 0x00576300 ; FUN_00576300 */

void FUN_00576300(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  piVar2 = *(int **)(param_1 + 0x18);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    ExceptionList = &pvStack_10;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 8))();
      }
    }
  }
  FUN_01674ea0(param_1,0x1c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3700 ; VA 0x00576370 ; FUN_00576370 */

void FUN_00576370(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x24);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x10);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0xf;
  *(undefined *)(param_1 + 0x10) = 0;
  FUN_01674ea0(param_1,0x2c);
  return;
}



/* FUNCTION 3701 ; VA 0x005763d0 ; FUN_005763d0 */

void FUN_005763d0(undefined4 param_1)

{
  FUN_0056cac0();
  FUN_01674ea0(param_1,0x30);
  return;
}



/* FUNCTION 3702 ; VA 0x005763f0 ; FUN_005763f0 */

void __fastcall FUN_005763f0(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x005763f3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(param_1 + 4))();
  return;
}



/* FUNCTION 3703 ; VA 0x00576400 ; FUN_00576400 */

void FUN_00576400(undefined4 *param_1,undefined4 param_2)

{
  FUN_0056f600(*param_1,param_2);
  return;
}



/* FUNCTION 3704 ; VA 0x00576420 ; FUN_00576420 */

void __thiscall FUN_00576420(int param_1,undefined4 *param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  
  uVar2 = *param_2;
  if (*(int *)(param_1 + 0x18) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x18) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar3 = *(undefined4 *)(param_1 + 0x14);
  uVar4 = *(undefined4 *)(param_1 + 0x18);
  if (*(int *)(param_1 + 0x10) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x10) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar5 = *(undefined4 *)(param_1 + 0xc);
  uVar6 = *(undefined4 *)(param_1 + 0x10);
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00588ee0(uVar2,param_3,*(undefined4 *)(param_1 + 4),*(undefined4 *)(param_1 + 8),uVar5,uVar6,
               uVar3,uVar4);
  return;
}



/* FUNCTION 3705 ; VA 0x005764c0 ; FUN_005764c0 */

void __thiscall FUN_005764c0(undefined4 *param_1,char *param_2)

{
  undefined4 *puVar1;
  char cVar2;
  char *pcVar3;
  
  pcVar3 = param_2;
  do {
    cVar2 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar2 != '\0');
  puVar1 = param_1 + 4;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  FUN_0055c360(param_1,*puVar1,param_2,(int)pcVar3 - (int)(param_2 + 1));
  return;
}



/* FUNCTION 3706 ; VA 0x00576500 ; FUN_00576500 */

undefined4 __thiscall FUN_00576500(undefined4 param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  void **ppvVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  cVar1 = *(char *)((int)param_2 + 0xd);
  ppvVar5 = &pvStack_10;
  pvStack_10 = ExceptionList;
  while (ExceptionList = ppvVar5, cVar1 == '\0') {
    FUN_00576500(param_2[2]);
    piVar2 = (int *)*param_2;
    piVar3 = (int *)param_2[6];
    uStack_8 = 0;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 8))();
        }
      }
    }
    uStack_8 = 0xffffffff;
    FUN_01674ea0(param_2,0x20);
    ppvVar5 = (void **)ExceptionList;
    param_2 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3707 ; VA 0x005765a0 ; FUN_005765a0 */

undefined4 __thiscall FUN_005765a0(undefined4 param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  void **ppvVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  cVar1 = *(char *)((int)param_2 + 0xd);
  ppvVar5 = &pvStack_10;
  pvStack_10 = ExceptionList;
  while (ExceptionList = ppvVar5, cVar1 == '\0') {
    FUN_005765a0(param_2[2]);
    piVar2 = (int *)*param_2;
    piVar3 = (int *)param_2[6];
    uStack_8 = 0;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 8))();
        }
      }
    }
    uStack_8 = 0xffffffff;
    FUN_01674ea0(param_2,0x1c);
    ppvVar5 = (void **)ExceptionList;
    param_2 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 3708 ; VA 0x00576640 ; FUN_00576640 */

void FUN_00576640(int *param_1)

{
  char cVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  do {
    if (cVar1 != '\0') {
      return;
    }
    FUN_00576640(param_1[2]);
    uVar2 = param_1[9];
    piVar3 = (int *)*param_1;
    if (0xf < uVar2) {
      iVar4 = param_1[4];
      uVar6 = uVar2 + 1;
      iVar5 = iVar4;
      if (0xfff < uVar6) {
        iVar5 = *(int *)(iVar4 + -4);
        uVar6 = uVar2 + 0x24;
        if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar6);
    }
    param_1[8] = 0;
    param_1[9] = 0xf;
    *(undefined *)(param_1 + 4) = 0;
    FUN_01674ea0(param_1,0x2c);
    cVar1 = *(char *)((int)piVar3 + 0xd);
    param_1 = piVar3;
  } while( true );
}



/* FUNCTION 3709 ; VA 0x005766d0 ; FUN_005766d0 */

void FUN_005766d0(int *param_1)

{
  char cVar1;
  int *piVar2;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  while (cVar1 == '\0') {
    FUN_005766d0(param_1[2]);
    piVar2 = (int *)*param_1;
    FUN_0056cac0();
    FUN_01674ea0(param_1,0x30);
    param_1 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  return;
}



/* FUNCTION 3710 ; VA 0x00576720 ; FUN_00576720 */

void FUN_00576720(int *param_1)

{
  char cVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  do {
    if (cVar1 != '\0') {
      return;
    }
    FUN_00576720(param_1[2]);
    uVar2 = param_1[9];
    piVar3 = (int *)*param_1;
    if (0xf < uVar2) {
      iVar4 = param_1[4];
      uVar6 = uVar2 + 1;
      iVar5 = iVar4;
      if (0xfff < uVar6) {
        iVar5 = *(int *)(iVar4 + -4);
        uVar6 = uVar2 + 0x24;
        if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar6);
    }
    param_1[8] = 0;
    param_1[9] = 0xf;
    *(undefined *)(param_1 + 4) = 0;
    FUN_01674ea0(param_1,0x28);
    cVar1 = *(char *)((int)piVar3 + 0xd);
    param_1 = piVar3;
  } while( true );
}



/* FUNCTION 3711 ; VA 0x005767b0 ; FUN_005767b0 */

undefined * FUN_005767b0(undefined4 param_1,undefined *param_2,char param_3,uint param_4)

{
  undefined2 *puVar1;
  char *pcVar2;
  uint uVar3;
  
  *param_2 = 0x25;
  puVar1 = (undefined2 *)(param_2 + 1);
  if ((param_4 & 0x20) != 0) {
    *(undefined *)puVar1 = 0x2b;
    puVar1 = (undefined2 *)(param_2 + 2);
  }
  if ((param_4 & 0x10) != 0) {
    *(undefined *)puVar1 = 0x23;
    puVar1 = (undefined2 *)((int)puVar1 + 1);
  }
  *puVar1 = 0x2a2e;
  pcVar2 = (char *)(puVar1 + 1);
  if (param_3 != '\0') {
    *pcVar2 = param_3;
    pcVar2 = (char *)((int)puVar1 + 3);
  }
  uVar3 = param_4 & 0x3000;
  if ((param_4 & 4) == 0) {
    if (uVar3 != 0x2000) {
      if (uVar3 == 0x3000) {
        *pcVar2 = 'a';
        pcVar2[1] = '\0';
        return param_2;
      }
      *pcVar2 = (uVar3 != 0x1000) * '\x02' + 'e';
      pcVar2[1] = '\0';
      return param_2;
    }
  }
  else if (uVar3 != 0x2000) {
    if (uVar3 == 0x3000) {
      *pcVar2 = 'A';
      pcVar2[1] = '\0';
      return param_2;
    }
    *pcVar2 = (uVar3 != 0x1000) * '\x02' + 'E';
    pcVar2[1] = '\0';
    return param_2;
  }
  *pcVar2 = 'f';
  pcVar2[1] = '\0';
  return param_2;
}



/* FUNCTION 3712 ; VA 0x00576870 ; FUN_00576870 */

undefined4
FUN_00576870(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5
            ,undefined4 param_6,char *param_7,int *param_8)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char *pcVar4;
  undefined uVar5;
  undefined4 *puVar6;
  int *piVar7;
  int *piVar8;
  int *****pppppiVar9;
  int ****ppppiVar10;
  char *****pppppcVar11;
  uint uVar12;
  undefined *puVar13;
  int *piVar14;
  int iVar15;
  char ****appppcStack_60 [4];
  undefined4 uStack_50;
  uint uStack_4c;
  int ****appppiStack_48 [4];
  int *piStack_38;
  int *piStack_34;
  undefined auStack_30 [4];
  char ****ppppcStack_2c;
  int *piStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined auStack_1c [4];
  int ****ppppiStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar14 = param_8;
  pcVar4 = param_7;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794e70;
  pvStack_10 = ExceptionList;
  if ((param_8 == (int *)0x0) || ((*param_7 != '+' && (*param_7 != '-')))) {
    piStack_14 = (int *)0x0;
  }
  else {
    piStack_14 = (int *)0x1;
  }
  if ((*(uint *)(param_5 + 0x14) & 0x3000) == 0x3000) {
    puVar13 = &DAT_018c0440;
    if ((((int *)((int)piStack_14 + 2) <= param_8) &&
        (*(char *)((int)piStack_14 + (int)param_7) == '0')) &&
       ((param_7[(int)((int)piStack_14 + 1)] == 'x' || (param_7[(int)((int)piStack_14 + 1)] == 'X'))
       )) {
      piStack_14 = (int *)((int)piStack_14 + 2);
    }
  }
  else {
    puVar13 = &DAT_018c043c;
  }
  ExceptionList = &pvStack_10;
  piStack_28 = (int *)FUN_0171dcc0(param_7,puVar13);
  param_7 = (char *)CONCAT22(param_7._2_2_,0x2e);
  puVar6 = (undefined4 *)FUN_0171df30();
  param_7 = (char *)CONCAT31(param_7._1_3_,*(undefined *)*puVar6);
  piVar7 = (int *)FUN_0171dcc0(pcVar4,&param_7);
  ppppcStack_2c = *(char *****)(*(int *)(param_5 + 0x30) + 4);
  uStack_8 = 0;
  piStack_20 = (int *)ppppcStack_2c;
  (**(code **)((int)*ppppcStack_2c + 4))();
  uStack_8 = 1;
  param_8 = (int *)FUN_0054e7d0(auStack_24);
  uStack_8 = 2;
  if ((ppppcStack_2c != (char ****)0x0) &&
     (puVar6 = (undefined4 *)(**(code **)((int)*ppppcStack_2c + 8))(), puVar6 != (undefined4 *)0x0))
  {
    (**(code **)*puVar6)(1);
  }
  uStack_8 = 0xffffffff;
  FUN_00565660(piVar14,0);
  uStack_8 = 3;
  pppppiVar9 = appppiStack_48;
  if (&DAT_0000000f < piStack_34) {
    pppppiVar9 = (int *****)appppiStack_48[0];
  }
  (**(code **)(*param_8 + 0x1c))(pcVar4,pcVar4 + (int)piVar14,pppppiVar9);
  param_8 = *(int **)(*(int *)(param_5 + 0x30) + 4);
  uStack_8._0_1_ = 4;
  ppppcStack_2c = (char ****)param_8;
  (**(code **)(*param_8 + 4))();
  uStack_8._0_1_ = 5;
  piVar8 = (int *)FUN_00564bf0(auStack_30);
  uStack_8._0_1_ = 6;
  if ((param_8 != (int *)0x0) &&
     (puVar6 = (undefined4 *)(**(code **)(*param_8 + 8))(), puVar6 != (undefined4 *)0x0)) {
    (**(code **)*puVar6)(1);
  }
  uStack_8._0_1_ = 3;
  (**(code **)(*piVar8 + 0x14))(appppcStack_60);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  uVar5 = (**(code **)(*piVar8 + 0x10))();
  param_8 = (int *)CONCAT13(uVar5,param_8._0_3_);
  if (piVar7 != piVar14) {
    uVar5 = (**(code **)(*piVar8 + 0xc))();
    pppppiVar9 = appppiStack_48;
    if (&DAT_0000000f < piStack_34) {
      pppppiVar9 = (int *****)appppiStack_48[0];
    }
    *(undefined *)((int)pppppiVar9 + (int)piVar7) = uVar5;
  }
  if (piVar7 == piVar14) {
    piVar7 = piStack_28;
  }
  ppppcStack_2c = (char ****)appppcStack_60;
  if (0xf < uStack_4c) {
    ppppcStack_2c = appppcStack_60[0];
  }
  cVar1 = *(char *)ppppcStack_2c;
  piVar14 = piStack_38;
  while (((piStack_38 = piVar14, cVar1 != '\x7f' && ('\0' < cVar1)) &&
         ((uint)(int)cVar1 < (uint)((int)piVar7 - (int)piStack_14)))) {
    piVar7 = (int *)((int)piVar7 - (int)cVar1);
    if (piVar14 < piVar7) {
LAB_00576dff:
      FUN_00554050();
      goto LAB_00576e04;
    }
    piStack_28 = piStack_34;
    if (piStack_34 == piVar14) {
      if (piVar14 == (int *)0x7fffffff) {
        FUN_00554040();
        goto LAB_00576dff;
      }
      piStack_20 = (int *)((uint)((int)piVar14 + 1) | 0xf);
      if (piStack_20 < &DAT_80000000) {
        if ((int *)(0x7fffffff - ((uint)piStack_34 >> 1)) < piStack_34) {
          piStack_20 = (int *)0x7fffffff;
        }
        else {
          piVar8 = (int *)(((uint)piStack_34 >> 1) + (int)piStack_34);
          if (piStack_20 < piVar8) {
            piStack_20 = piVar8;
          }
        }
      }
      else {
        piStack_20 = (int *)0x7fffffff;
      }
      ppppiStack_18 = (int ****)((int)piStack_20 + 1);
      if (ppppiStack_18 < &DAT_00001000) {
        if ((int *****)ppppiStack_18 == (int *****)0x0) {
          ppppiStack_18 = (int ****)0x0;
        }
        else {
          ppppiStack_18 = (int ****)FUN_01674e20(ppppiStack_18);
        }
      }
      else {
        pppppiVar9 = (int *****)(piStack_20 + 9);
        if (pppppiVar9 <= ppppiStack_18) {
          pppppiVar9 = (int *****)0xffffffff;
        }
        ppppiVar10 = (int ****)FUN_01674e20(pppppiVar9);
        if (ppppiVar10 == (int ****)0x0) goto LAB_00576e04;
        ppppiStack_18 = (int ****)((int)ppppiVar10 + 0x23U & 0xffffffe0);
        ((int *****)ppppiStack_18)[-1] = ppppiVar10;
      }
      ppppiVar10 = appppiStack_48[0];
      piStack_38 = (int *)((int)piVar14 + 1);
      piStack_34 = piStack_20;
      if (piStack_28 < &DAT_00000010) {
        FUN_0170c6f0(ppppiStack_18,appppiStack_48,piVar7);
        ppppiVar10 = ppppiStack_18;
        *(undefined *)((int)ppppiStack_18 + (int)piVar7) = param_8._3_1_;
        FUN_0170c6f0((undefined *)((int)ppppiStack_18 + 1) + (int)piVar7,
                     (undefined *)((int)appppiStack_48 + (int)piVar7),
                     (undefined *)((int)piVar14 + (1 - (int)piVar7)));
        appppiStack_48[0] = ppppiVar10;
      }
      else {
        FUN_0170c6f0(ppppiStack_18,appppiStack_48[0],piVar7);
        *(undefined *)((int)ppppiStack_18 + (int)piVar7) = param_8._3_1_;
        FUN_0170c6f0((undefined *)((int)ppppiStack_18 + 1) + (int)piVar7,
                     (undefined *)((int)ppppiVar10 + (int)piVar7),
                     (undefined *)((int)piVar14 + (1 - (int)piVar7)));
        piVar14 = (int *)((int)piStack_28 + 1);
        pppppiVar9 = (int *****)ppppiVar10;
        if ((int *)0xfff < piVar14) {
          pppppiVar9 = (int *****)ppppiVar10[-1];
          piVar14 = piStack_28 + 9;
          if ((undefined *)0x1f < (undefined *)((int)ppppiVar10 + (-4 - (int)pppppiVar9)))
          goto LAB_00576e04;
        }
        FUN_01674ea0(pppppiVar9,piVar14);
        appppiStack_48[0] = ppppiStack_18;
      }
    }
    else {
      piStack_38 = (int *)((int)piVar14 + 1);
      pppppiVar9 = appppiStack_48;
      if (&DAT_0000000f < piStack_34) {
        pppppiVar9 = (int *****)appppiStack_48[0];
      }
      puVar13 = (undefined *)((int)pppppiVar9 + (int)piVar7);
      FUN_0170cc70(puVar13 + 1,puVar13,(undefined *)((int)piVar14 + (1 - (int)piVar7)));
      *puVar13 = param_8._3_1_;
    }
    pppppcVar11 = (char *****)((int)ppppcStack_2c + 1);
    if (*(char *)((int)ppppcStack_2c + 1) < '\x01') {
      pppppcVar11 = (char *****)ppppcStack_2c;
    }
    ppppcStack_2c = (char ****)pppppcVar11;
    piVar14 = piStack_38;
    cVar1 = *(char *)pppppcVar11;
  }
  piVar7 = *(int **)(param_5 + 0x20);
  if (((*(int *)(param_5 + 0x24) < 0) || ((*(int *)(param_5 + 0x24) < 1 && (piVar7 == (int *)0x0))))
     || (piVar7 <= piVar14)) {
    iVar15 = 0;
  }
  else {
    iVar15 = (int)piVar7 - (int)piVar14;
  }
  uVar12 = *(uint *)(param_5 + 0x14) & 0x1c0;
  if (uVar12 == 0x40) {
    pppppiVar9 = appppiStack_48;
    if (&DAT_0000000f < piStack_34) {
      pppppiVar9 = (int *****)appppiStack_48[0];
    }
    puVar6 = (undefined4 *)FUN_005777f0(param_1,auStack_30,param_3,param_4,pppppiVar9,piStack_14);
  }
  else if (uVar12 == 0x100) {
    pppppiVar9 = appppiStack_48;
    if (&DAT_0000000f < piStack_34) {
      pppppiVar9 = (int *****)appppiStack_48[0];
    }
    puVar6 = (undefined4 *)FUN_005777f0(param_1,auStack_30,param_3,param_4,pppppiVar9,piStack_14);
    puVar6 = (undefined4 *)FUN_00577870(param_1,auStack_30,*puVar6,puVar6[1],param_6,iVar15);
    iVar15 = 0;
  }
  else {
    puVar6 = (undefined4 *)FUN_00577870(param_1,auStack_30,param_3,param_4,param_6,iVar15);
    iVar15 = 0;
    pppppiVar9 = appppiStack_48;
    if (&DAT_0000000f < piStack_34) {
      pppppiVar9 = (int *****)appppiStack_48[0];
    }
    puVar6 = (undefined4 *)FUN_005777f0(param_1,auStack_30,*puVar6,puVar6[1],pppppiVar9,piStack_14);
  }
  pppppiVar9 = appppiStack_48;
  if (&DAT_0000000f < piStack_34) {
    pppppiVar9 = (int *****)appppiStack_48[0];
  }
  puVar6 = (undefined4 *)
           FUN_005777f0(param_1,auStack_1c,*puVar6,puVar6[1],
                        (undefined *)((int)pppppiVar9 + (int)piStack_14),
                        (int)piVar14 - (int)piStack_14);
  uVar2 = *puVar6;
  uVar3 = puVar6[1];
  *(undefined4 *)(param_5 + 0x20) = 0;
  *(undefined4 *)(param_5 + 0x24) = 0;
  FUN_00577870(param_1,param_2,uVar2,uVar3,param_6,iVar15);
  if (0xf < uStack_4c) {
    uVar12 = uStack_4c + 1;
    pppppcVar11 = (char *****)appppcStack_60[0];
    if (0xfff < uVar12) {
      pppppcVar11 = (char *****)appppcStack_60[0][-1];
      uVar12 = uStack_4c + 0x24;
      if ((char *)0x1f < (char *)((int)appppcStack_60[0] + (-4 - (int)pppppcVar11))) {
LAB_00576e04:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppcVar11,uVar12);
  }
  uStack_50 = 0;
  uStack_4c = 0xf;
  appppcStack_60[0] = (char ****)((uint)appppcStack_60[0] & 0xffffff00);
  if (&DAT_0000000f < piStack_34) {
    piVar14 = (int *)((int)piStack_34 + 1);
    pppppiVar9 = (int *****)appppiStack_48[0];
    if ((int *)0xfff < piVar14) {
      pppppiVar9 = (int *****)appppiStack_48[0][-1];
      piVar14 = piStack_34 + 9;
      if ((undefined *)0x1f < (undefined *)((int)appppiStack_48[0] + (-4 - (int)pppppiVar9))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppiVar9,piVar14);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 3713 ; VA 0x00576e10 ; FUN_00576e10 */

void FUN_00576e10(undefined4 param_1)

{
  FUN_01674ea0(param_1,0x2c);
  return;
}



/* FUNCTION 3714 ; VA 0x00576e30 ; FUN_00576e30 */

void FUN_00576e30(undefined4 param_1)

{
  FUN_01674ea0(param_1,0x30);
  return;
}



/* FUNCTION 3715 ; VA 0x00576e50 ; FUN_00576e50 */

void FUN_00576e50(undefined4 param_1)

{
  FUN_01674ea0(param_1,0x28);
  return;
}



/* FUNCTION 3716 ; VA 0x00576e70 ; FUN_00576e70 */

int __fastcall FUN_00576e70(int param_1)

{
  return param_1 + 4;
}



/* FUNCTION 3717 ; VA 0x00576e80 ; FUN_00576e80 */

int __thiscall FUN_00576e80(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = FUN_0170d8dd(param_2 + 4,0x1d90b80);
  if (iVar1 == 0) {
    return param_1 + 0xc;
  }
  return 0;
}



/* FUNCTION 3718 ; VA 0x00576eb0 ; FUN_00576eb0 */

undefined * FUN_00576eb0(undefined4 param_1,undefined *param_2,char *param_3,uint param_4)

{
  char *pcVar1;
  byte *pbVar2;
  
  *param_2 = 0x25;
  pcVar1 = param_2 + 1;
  if ((param_4 & 0x20) != 0) {
    *pcVar1 = '+';
    pcVar1 = param_2 + 2;
  }
  if ((param_4 & 8) != 0) {
    *pcVar1 = '#';
    pcVar1 = pcVar1 + 1;
  }
  pbVar2 = (byte *)(pcVar1 + 1);
  if (*param_3 == 'L') {
    *pcVar1 = 'I';
    pbVar2[0] = 0x36;
    pbVar2[1] = 0x34;
    pbVar2 = (byte *)(pcVar1 + 3);
  }
  else {
    *pcVar1 = *param_3;
  }
  if ((param_4 & 0xe00) == 0x400) {
    *pbVar2 = 0x6f;
    pbVar2[1] = 0;
    return param_2;
  }
  if ((param_4 & 0xe00) != 0x800) {
    *pbVar2 = param_3[1];
    pbVar2[1] = 0;
    return param_2;
  }
  *pbVar2 = ~((char)param_4 << 3) & 0x20U | 0x58;
  pbVar2[1] = 0;
  return param_2;
}



/* FUNCTION 3719 ; VA 0x00576f40 ; FUN_00576f40 */

uint __fastcall FUN_00576f40(int param_1)

{
  uint *puVar1;
  uint uVar2;
  uint in_EAX;
  
  puVar1 = (uint *)(param_1 + 4);
  uVar2 = *puVar1;
  while( true ) {
    if (uVar2 == 0) {
      return in_EAX & 0xffffff00;
    }
    LOCK();
    in_EAX = *puVar1;
    if (uVar2 == in_EAX) {
      *puVar1 = uVar2 + 1;
      in_EAX = uVar2;
    }
    UNLOCK();
    if (in_EAX == uVar2) break;
    uVar2 = *puVar1;
  }
  return CONCAT31((int3)(in_EAX >> 8),1);
}



/* FUNCTION 3720 ; VA 0x00576f70 ; FUN_00576f70 */

void __thiscall FUN_00576f70(int param_1,undefined4 param_2,uint param_3,uint param_4)

{
  int iVar1;
  code *pcVar2;
  int iVar3;
  int iVar4;
  
  if (0x7fffffff < param_3) {
    FUN_010c5e30();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
  }
  if ((param_3 != 0) && (((byte)param_4 & 6) != 6)) {
    iVar3 = FUN_00554060(param_3);
    FUN_0170c6f0(iVar3,param_2,param_3);
    *(uint *)(param_1 + 0x38) = iVar3 + param_3;
    if ((param_4 & 4) == 0) {
      **(int **)(param_1 + 0xc) = iVar3;
      **(int **)(param_1 + 0x1c) = iVar3;
      **(uint **)(param_1 + 0x2c) = param_3;
    }
    if ((param_4 & 2) == 0) {
      iVar1 = *(int *)(param_1 + 0x38);
      iVar4 = iVar3;
      if ((param_4 & 0x18) != 0) {
        iVar4 = iVar1;
      }
      **(int **)(param_1 + 0x10) = iVar3;
      **(int **)(param_1 + 0x20) = iVar4;
      **(int **)(param_1 + 0x30) = iVar1 - iVar4;
      if ((param_4 & 4) != 0) {
        **(int **)(param_1 + 0xc) = iVar3;
        **(undefined4 **)(param_1 + 0x1c) = 0;
        **(int **)(param_1 + 0x2c) = iVar3;
      }
    }
    *(uint *)(param_1 + 0x3c) = param_4 | 1;
    return;
  }
  *(uint *)(param_1 + 0x3c) = param_4;
  *(undefined4 *)(param_1 + 0x38) = 0;
  return;
}



/* FUNCTION 3721 ; VA 0x00577040 ; FUN_00577040 */

void __thiscall FUN_00577040(int param_1,undefined4 param_2,char param_3)

{
  char cVar1;
  undefined uVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  char *pcVar6;
  undefined1 *puVar7;
  char *pcVar8;
  undefined auStack_48 [44];
  undefined4 *puStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794e80;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffac;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  puVar3 = (undefined4 *)FUN_0171df30();
  puStack_1c = puVar3;
  FUN_016df430(auStack_48);
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  uStack_8 = 0;
  FUN_016df430(auStack_48);
  if (param_3 == '\0') {
    pcVar6 = (char *)puVar3[2];
  }
  else {
    pcVar6 = "";
  }
  pcVar8 = pcVar6;
  do {
    cVar1 = *pcVar8;
    pcVar8 = pcVar8 + 1;
  } while (cVar1 != '\0');
  pcVar8 = pcVar8 + (1 - (int)(pcVar6 + 1));
  iVar4 = FUN_0171d6c7(pcVar8,1);
  if (iVar4 == 0) {
    FUN_010c5e30();
  }
  else {
    if (pcVar8 != (char *)0x0) {
      iVar5 = iVar4 - (int)pcVar6;
      do {
        cVar1 = *pcVar6;
        pcVar6 = pcVar6 + 1;
        pcVar6[iVar5 + -1] = cVar1;
        pcVar8 = pcVar8 + -1;
      } while (pcVar8 != (char *)0x0);
    }
    iVar5 = 6;
    *(int *)(param_1 + 8) = iVar4;
    puVar7 = &DAT_018bdf48;
    iVar4 = FUN_0171d6c7(6,1);
    if (iVar4 != 0) {
      do {
        uVar2 = *puVar7;
        puVar7 = puVar7 + 1;
        puVar7[iVar4 + -0x18bdf49] = uVar2;
        iVar5 = iVar5 + -1;
      } while (iVar5 != 0);
      iVar5 = 5;
      *(int *)(param_1 + 0x10) = iVar4;
      puVar7 = &DAT_018bdf50;
      iVar4 = FUN_0171d6c7(5,1);
      if (iVar4 != 0) {
        do {
          uVar2 = *puVar7;
          puVar7 = puVar7 + 1;
          puVar7[iVar4 + -0x18bdf51] = uVar2;
          iVar5 = iVar5 + -1;
        } while (iVar5 != 0);
        *(int *)(param_1 + 0x14) = iVar4;
        if (param_3 == '\0') {
          *(undefined *)(param_1 + 0xc) = *(undefined *)*puStack_1c;
          *(undefined *)(param_1 + 0xd) = *(undefined *)puStack_1c[1];
          ExceptionList = pvStack_10;
          return;
        }
        *(undefined2 *)(param_1 + 0xc) = 0x2c2e;
        ExceptionList = pvStack_10;
        return;
      }
      goto LAB_005771a5;
    }
  }
  FUN_010c5e30();
LAB_005771a5:
  FUN_010c5e30();
  FUN_00577a20();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 3722 ; VA 0x005771aa ; Catch_All@005771aa */

void Catch_All_005771aa(void)

{
  FUN_00577a20();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 3723 ; VA 0x005771c0 ; FUN_005771c0 */

undefined4
FUN_005771c0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5
            ,undefined4 param_6,char *param_7,uint param_8)

{
  undefined *puVar1;
  uint uVar2;
  char cVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 *****pppppuVar7;
  undefined uVar8;
  int *piVar9;
  undefined4 *puVar10;
  undefined4 ******ppppppuVar11;
  char ******ppppppcVar12;
  uint uVar13;
  uint uVar14;
  uint uVar15;
  int iVar16;
  char *****apppppcStack_54 [4];
  undefined4 uStack_44;
  uint uStack_40;
  undefined4 *****apppppuStack_3c [4];
  uint uStack_2c;
  uint uStack_28;
  undefined auStack_24 [4];
  char *****pppppcStack_20;
  undefined auStack_1c [4];
  uint uStack_18;
  undefined4 *****pppppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar13 = param_8;
  puStack_c = &LAB_01794eb0;
  pvStack_10 = ExceptionList;
  if ((param_8 == 0) || ((*param_7 != '+' && (*param_7 != '-')))) {
    uVar15 = 0;
  }
  else {
    uVar15 = 1;
  }
  if (((((*(uint *)(param_5 + 0x14) & 0xe00) == 0x800) && (uVar15 + 2 <= param_8)) &&
      (param_7[uVar15] == '0')) && ((param_7[uVar15 + 1] == 'x' || (param_7[uVar15 + 1] == 'X')))) {
    uVar15 = uVar15 + 2;
  }
  param_8 = uVar15;
  piVar4 = *(int **)(*(int *)(param_5 + 0x30) + 4);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  pppppcStack_20 = (char *****)piVar4;
  (**(code **)(*piVar4 + 4))();
  uStack_8 = 1;
  piVar9 = (int *)FUN_0054e7d0(auStack_24);
  uStack_8 = 2;
  if ((piVar4 != (int *)0x0) &&
     (puVar10 = (undefined4 *)(**(code **)(*piVar4 + 8))(), puVar10 != (undefined4 *)0x0)) {
    (**(code **)*puVar10)(1);
  }
  uStack_8 = 0xffffffff;
  FUN_00565660(uVar13,0);
  ppppppuVar11 = apppppuStack_3c;
  if (0xf < uStack_28) {
    ppppppuVar11 = (undefined4 ******)apppppuStack_3c[0];
  }
  uStack_8 = 3;
  (**(code **)(*piVar9 + 0x1c))(param_7,param_7 + uVar13,ppppppuVar11);
  piVar4 = *(int **)(*(int *)(param_5 + 0x30) + 4);
  uStack_8._0_1_ = 4;
  pppppcStack_20 = (char *****)piVar4;
  (**(code **)(*piVar4 + 4))();
  uStack_8._0_1_ = 5;
  piVar9 = (int *)FUN_00564bf0(auStack_24);
  uStack_8._0_1_ = 6;
  if ((piVar4 != (int *)0x0) &&
     (puVar10 = (undefined4 *)(**(code **)(*piVar4 + 8))(), puVar10 != (undefined4 *)0x0)) {
    (**(code **)*puVar10)(1);
  }
  uStack_8._0_1_ = 3;
  (**(code **)(*piVar9 + 0x14))(apppppcStack_54);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  ppppppcVar12 = apppppcStack_54;
  if (0xf < uStack_40) {
    ppppppcVar12 = (char ******)apppppcStack_54[0];
  }
  pppppcStack_20 = (char *****)ppppppcVar12;
  if ((*(char *)ppppppcVar12 != '\x7f') && ('\0' < *(char *)ppppppcVar12)) {
    uVar8 = (**(code **)(*piVar9 + 0x10))();
    cVar3 = *(char *)ppppppcVar12;
    uVar15 = uStack_2c;
    while (((uStack_2c = uVar15, cVar3 != '\x7f' && ('\0' < cVar3)) &&
           ((uint)(int)cVar3 < uVar13 - param_8))) {
      uVar13 = uVar13 - (int)cVar3;
      if (uVar15 < uVar13) {
LAB_005776a1:
        FUN_00554050();
        goto LAB_005776a6;
      }
      uStack_18 = uStack_28;
      if (uStack_28 == uVar15) {
        if (uVar15 == 0x7fffffff) {
          FUN_00554040();
          goto LAB_005776a1;
        }
        uVar14 = uVar15 + 1 | 0xf;
        if (uVar14 < 0x80000000) {
          if (0x7fffffff - (uStack_28 >> 1) < uStack_28) {
            uVar14 = 0x7fffffff;
          }
          else {
            uVar2 = (uStack_28 >> 1) + uStack_28;
            if (uVar14 < uVar2) {
              uVar14 = uVar2;
            }
          }
        }
        else {
          uVar14 = 0x7fffffff;
        }
        ppppppuVar11 = (undefined4 ******)FUN_00554060(uVar14 + 1);
        pppppuVar7 = apppppuStack_3c[0];
        uStack_2c = uVar15 + 1;
        uStack_28 = uVar14;
        pppppuStack_14 = ppppppuVar11;
        if (uStack_18 < 0x10) {
          FUN_0170c6f0(ppppppuVar11,apppppuStack_3c,uVar13);
          *(undefined *)((int)ppppppuVar11 + uVar13) = uVar8;
          FUN_0170c6f0((int)ppppppuVar11 + uVar13 + 1,(int)apppppuStack_3c + uVar13,
                       (uVar15 - uVar13) + 1);
          apppppuStack_3c[0] = ppppppuVar11;
        }
        else {
          FUN_0170c6f0(ppppppuVar11,apppppuStack_3c[0],uVar13);
          *(undefined *)((int)pppppuStack_14 + uVar13) = uVar8;
          FUN_0170c6f0((int)pppppuStack_14 + uVar13 + 1,(int)pppppuVar7 + uVar13,
                       (uVar15 - uVar13) + 1);
          uVar15 = uStack_18 + 1;
          ppppppuVar11 = (undefined4 ******)pppppuVar7;
          if (0xfff < uVar15) {
            ppppppuVar11 = (undefined4 ******)pppppuVar7[-1];
            uVar15 = uStack_18 + 0x24;
            if (0x1f < (uint)((int)pppppuVar7 + (-4 - (int)ppppppuVar11))) goto LAB_005776a6;
          }
          FUN_01674ea0(ppppppuVar11,uVar15);
          apppppuStack_3c[0] = pppppuStack_14;
        }
      }
      else {
        uStack_2c = uVar15 + 1;
        ppppppuVar11 = apppppuStack_3c;
        if (0xf < uStack_28) {
          ppppppuVar11 = (undefined4 ******)apppppuStack_3c[0];
        }
        puVar1 = (undefined *)((int)ppppppuVar11 + uVar13);
        FUN_0170cc70(puVar1 + 1,puVar1,(uVar15 - uVar13) + 1);
        *puVar1 = uVar8;
      }
      ppppppcVar12 = (char ******)((int)pppppcStack_20 + 1);
      if (*(char *)((int)pppppcStack_20 + 1) < '\x01') {
        ppppppcVar12 = (char ******)pppppcStack_20;
      }
      uVar15 = uStack_2c;
      pppppcStack_20 = (char *****)ppppppcVar12;
      cVar3 = *(char *)ppppppcVar12;
    }
  }
  uVar15 = uStack_2c;
  uVar13 = *(uint *)(param_5 + 0x20);
  if (((*(int *)(param_5 + 0x24) < 0) || ((*(int *)(param_5 + 0x24) < 1 && (uVar13 == 0)))) ||
     (uVar13 <= uStack_2c)) {
    iVar16 = 0;
  }
  else {
    iVar16 = uVar13 - uStack_2c;
  }
  uVar13 = *(uint *)(param_5 + 0x14) & 0x1c0;
  if (uVar13 == 0x40) {
    ppppppuVar11 = apppppuStack_3c;
    if (0xf < uStack_28) {
      ppppppuVar11 = (undefined4 ******)apppppuStack_3c[0];
    }
    puVar10 = (undefined4 *)FUN_005777f0(param_1,auStack_24,param_3,param_4,ppppppuVar11,param_8);
  }
  else if (uVar13 == 0x100) {
    ppppppuVar11 = apppppuStack_3c;
    if (0xf < uStack_28) {
      ppppppuVar11 = (undefined4 ******)apppppuStack_3c[0];
    }
    puVar10 = (undefined4 *)FUN_005777f0(param_1,auStack_24,param_3,param_4,ppppppuVar11,param_8);
    puVar10 = (undefined4 *)FUN_00577870(param_1,auStack_24,*puVar10,puVar10[1],param_6,iVar16);
    iVar16 = 0;
  }
  else {
    puVar10 = (undefined4 *)FUN_00577870(param_1,auStack_24,param_3,param_4,param_6,iVar16);
    iVar16 = 0;
    ppppppuVar11 = apppppuStack_3c;
    if (0xf < uStack_28) {
      ppppppuVar11 = (undefined4 ******)apppppuStack_3c[0];
    }
    puVar10 = (undefined4 *)
              FUN_005777f0(param_1,auStack_24,*puVar10,puVar10[1],ppppppuVar11,param_8);
  }
  ppppppuVar11 = apppppuStack_3c;
  if (0xf < uStack_28) {
    ppppppuVar11 = (undefined4 ******)apppppuStack_3c[0];
  }
  puVar10 = (undefined4 *)
            FUN_005777f0(param_1,auStack_1c,*puVar10,puVar10[1],(int)ppppppuVar11 + param_8,
                         uVar15 - param_8);
  uVar5 = *puVar10;
  uVar6 = puVar10[1];
  *(undefined4 *)(param_5 + 0x20) = 0;
  *(undefined4 *)(param_5 + 0x24) = 0;
  FUN_00577870(param_1,param_2,uVar5,uVar6,param_6,iVar16);
  if (0xf < uStack_40) {
    uVar13 = uStack_40 + 1;
    ppppppcVar12 = (char ******)apppppcStack_54[0];
    if (0xfff < uVar13) {
      ppppppcVar12 = (char ******)apppppcStack_54[0][-1];
      uVar13 = uStack_40 + 0x24;
      if ((char *)0x1f < (char *)((int)apppppcStack_54[0] + (-4 - (int)ppppppcVar12))) {
LAB_005776a6:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppppcVar12,uVar13);
  }
  uStack_44 = 0;
  uStack_40 = 0xf;
  apppppcStack_54[0] = (char *****)((uint)apppppcStack_54[0] & 0xffffff00);
  if (0xf < uStack_28) {
    uVar13 = uStack_28 + 1;
    ppppppuVar11 = (undefined4 ******)apppppuStack_3c[0];
    if (0xfff < uVar13) {
      ppppppuVar11 = (undefined4 ******)apppppuStack_3c[0][-1];
      uVar13 = uStack_28 + 0x24;
      if (0x1f < (uint)((int)apppppuStack_3c[0] + (-4 - (int)ppppppuVar11))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppppuVar11,uVar13);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 3724 ; VA 0x005776c0 ; FUN_005776c0 */

undefined4 * __thiscall FUN_005776c0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_02fa2349d2109e7fb76f34aa9c25047c>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  param_2[3] = 0;
  param_2[4] = 0;
  param_2[3] = *(undefined4 *)(param_1 + 0xc);
  param_2[4] = *(undefined4 *)(param_1 + 0x10);
  *(undefined4 *)(param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  return param_2;
}



/* FUNCTION 3725 ; VA 0x00577730 ; FUN_00577730 */

void __fastcall FUN_00577730(int param_1)

{
  FUN_00558020(param_1 + 4);
  return;
}



/* FUNCTION 3726 ; VA 0x00577750 ; FUN_00577750 */

void __fastcall FUN_00577750(int param_1)

{
  FUN_005580b0(param_1 + 4);
  return;
}



/* FUNCTION 3727 ; VA 0x00577770 ; FUN_00577770 */

void __fastcall FUN_00577770(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794ec0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  iVar1 = *(int *)(*param_1 + 4);
  if ((*(int *)(iVar1 + 0xc + (int)param_1) == 0) &&
     ((*(byte *)(iVar1 + 0x14 + (int)param_1) & 2) != 0)) {
    ExceptionList = &pvStack_10;
    iVar1 = (**(code **)(**(int **)(iVar1 + 0x38 + (int)param_1) + 0x34))();
    if (iVar1 == -1) {
      FUN_00554460(*(uint *)(*(int *)(*param_1 + 4) + 0xc + (int)param_1) | 4,0);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3728 ; VA 0x005777e0 ; Catch_All@005777e0 */

undefined4 Catch_All_005777e0(void)

{
  return 0x5777cf;
}



/* FUNCTION 3729 ; VA 0x005777f0 ; FUN_005777f0 */

void FUN_005777f0(undefined4 param_1,undefined4 *param_2,undefined4 param_3,int *param_4,
                 byte *param_5,int param_6)

{
  byte bVar1;
  int iVar2;
  byte *pbVar3;
  uint uVar4;
  
  if (param_6 != 0) {
    do {
      if (param_4 == (int *)0x0) {
LAB_00577849:
        param_3 = CONCAT31(param_3._1_3_,1);
      }
      else {
        bVar1 = *param_5;
        if (*(int *)param_4[8] == 0) {
LAB_00577834:
          uVar4 = (**(code **)(*param_4 + 0xc))(bVar1);
        }
        else {
          iVar2 = *(int *)param_4[0xc];
          if (iVar2 < 1) goto LAB_00577834;
          *(int *)param_4[0xc] = iVar2 + -1;
          pbVar3 = *(byte **)param_4[8];
          *(byte **)param_4[8] = pbVar3 + 1;
          *pbVar3 = bVar1;
          uVar4 = (uint)bVar1;
        }
        if (uVar4 == 0xffffffff) goto LAB_00577849;
      }
      param_5 = param_5 + 1;
      param_6 = param_6 + -1;
    } while (param_6 != 0);
  }
  param_2[1] = param_4;
  *param_2 = param_3;
  return;
}



/* FUNCTION 3730 ; VA 0x00577870 ; FUN_00577870 */

void FUN_00577870(undefined4 param_1,undefined4 *param_2,undefined4 param_3,int *param_4,
                 byte param_5,int param_6)

{
  int iVar1;
  byte *pbVar2;
  uint uVar3;
  
  if (param_6 != 0) {
    do {
      if (param_4 == (int *)0x0) {
LAB_005778c1:
        param_3 = CONCAT31(param_3._1_3_,1);
      }
      else {
        if (*(int *)param_4[8] == 0) {
LAB_005778ac:
          uVar3 = (**(code **)(*param_4 + 0xc))(param_5);
        }
        else {
          iVar1 = *(int *)param_4[0xc];
          if (iVar1 < 1) goto LAB_005778ac;
          *(int *)param_4[0xc] = iVar1 + -1;
          pbVar2 = *(byte **)param_4[8];
          *(byte **)param_4[8] = pbVar2 + 1;
          *pbVar2 = param_5;
          uVar3 = (uint)param_5;
        }
        if (uVar3 == 0xffffffff) goto LAB_005778c1;
      }
      param_6 = param_6 + -1;
    } while (param_6 != 0);
  }
  param_2[1] = param_4;
  *param_2 = param_3;
  return;
}



/* FUNCTION 3731 ; VA 0x005778e0 ; FUN_005778e0 */

TypeDescriptor * FUN_005778e0(void)

{
  return &TypeDescriptor_01d90b14;
}



/* FUNCTION 3732 ; VA 0x005778f0 ; FUN_005778f0 */

TypeDescriptor * FUN_005778f0(void)

{
  return &<lambda_02fa2349d2109e7fb76f34aa9c25047c>::RTTI_Type_Descriptor;
}



/* FUNCTION 3733 ; VA 0x00577900 ; FUN_00577900 */

TypeDescriptor * FUN_00577900(void)

{
  return &<lambda_7850e3f498f96950946230d03482994b>::RTTI_Type_Descriptor;
}



/* FUNCTION 3734 ; VA 0x00577910 ; FUN_00577910 */

TypeDescriptor * FUN_00577910(void)

{
  return &<lambda_ce3ec86729cff41111bf35de00f2a9a5>::RTTI_Type_Descriptor;
}



/* FUNCTION 3735 ; VA 0x00577920 ; FUN_00577920 */

void __fastcall FUN_00577920(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00576720(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3736 ; VA 0x00577980 ; FUN_00577980 */

void __fastcall FUN_00577980(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if ((*(byte *)(param_1 + 0x3c) & 1) != 0) {
    if (**(int **)(param_1 + 0x20) == 0) {
      iVar2 = **(int **)(param_1 + 0x2c) + **(int **)(param_1 + 0x1c);
    }
    else {
      iVar2 = **(int **)(param_1 + 0x30) + **(int **)(param_1 + 0x20);
    }
    iVar1 = **(int **)(param_1 + 0xc);
    uVar3 = iVar2 - iVar1;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  **(undefined4 **)(param_1 + 0xc) = 0;
  **(undefined4 **)(param_1 + 0x1c) = 0;
  **(undefined4 **)(param_1 + 0x2c) = 0;
  **(undefined4 **)(param_1 + 0x10) = 0;
  **(undefined4 **)(param_1 + 0x20) = 0;
  **(undefined4 **)(param_1 + 0x30) = 0;
  *(uint *)(param_1 + 0x3c) = *(uint *)(param_1 + 0x3c) & 0xfffffffe;
  *(undefined4 *)(param_1 + 0x38) = 0;
  return;
}



/* FUNCTION 3737 ; VA 0x00577a20 ; FUN_00577a20 */

void __fastcall FUN_00577a20(int param_1)

{
  FUN_017168b0(*(undefined4 *)(param_1 + 8));
  FUN_017168b0(*(undefined4 *)(param_1 + 0x10));
  FUN_017168b0(*(undefined4 *)(param_1 + 0x14));
  return;
}



/* FUNCTION 3738 ; VA 0x00577a40 ; FUN_00577a40 */

void __fastcall FUN_00577a40(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_00559570(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x18) * 0x18;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 3739 ; VA 0x00577ac0 ; FUN_00577ac0 */

void __fastcall FUN_00577ac0(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if (*param_1 != 0) {
    FUN_005596d0(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar3 = param_1[2] - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 3740 ; VA 0x00577b20 ; FUN_00577b20 */

void __fastcall FUN_00577b20(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_00559720(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0xd0) * 0xd0;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 3741 ; VA 0x00577ba0 ; FUN_00577ba0 */

undefined4 * __thiscall FUN_00577ba0(undefined4 param_1,undefined4 *param_2,int param_3)

{
  void **ppvVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792828;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  ppvVar1 = &pvStack_10;
  if (param_3 != 0) {
    do {
      ExceptionList = ppvVar1;
      uVar2 = FUN_00888530();
      *param_2 = uVar2;
      param_2[1] = 0;
      param_2 = param_2 + 0x34;
      param_3 = param_3 + -1;
      ppvVar1 = (void **)ExceptionList;
    } while (param_3 != 0);
  }
  uStack_8 = 1;
  FUN_00559720(param_2,param_2,param_1);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 3742 ; VA 0x00577c30 ; FUN_00577c30 */

void FUN_00577c30(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("vector<T> too long");
}



/* FUNCTION 3743 ; VA 0x00577c40 ; FUN_00577c40 */

void FUN_00577c40(void)

{
  code *pcVar1;
  
  FUN_016ddcf9("invalid vector<T> subscript");
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 3744 ; VA 0x00577c50 ; FUN_00577c50 */

int FUN_00577c50(int param_1)

{
  if (DAT_01d59298 == param_1) {
    return 0x3e;
  }
  if (DAT_01d5929c == param_1) {
    return 0x3f;
  }
  if ((DAT_01d591a0 <= param_1) && (param_1 <= DAT_01d59204)) {
    return param_1 - DAT_01d591a0;
  }
  if ((DAT_01d59208 <= param_1) && (param_1 <= DAT_01d5926c)) {
    return (param_1 - DAT_01d59208) + 0x1a;
  }
  if ((DAT_01d59270 <= param_1) && (param_1 <= DAT_01d59294)) {
    return (param_1 - DAT_01d59270) + 0x34;
  }
  return (param_1 == 0x3d) - 2;
}



/* FUNCTION 3745 ; VA 0x00577ce0 ; FUN_00577ce0 */

void FUN_00577ce0(void)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined *puVar8;
  undefined auStack_64 [24];
  undefined auStack_4c [12];
  code *pcStack_40;
  int iStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794ed8;
  pvStack_10 = ExceptionList;
  if (100 < DAT_01e90d80) {
    ExceptionList = &pvStack_10;
    uStack_14 = FUN_0054db20();
    uStack_18 = FUN_0054db20();
    uStack_1c = FUN_0054db20();
    uStack_20 = FUN_0054db20();
    uStack_24 = FUN_0054db20();
    uStack_28 = FUN_0054db20();
    uStack_2c = FUN_0054db20();
    uStack_30 = FUN_0054db20();
    uStack_34 = FUN_0054db20();
    uStack_38 = FUN_0054db20();
    uVar3 = FUN_0054db20();
    uVar4 = FUN_0054db20();
    uVar5 = FUN_0054db20();
    uVar6 = FUN_0054db20();
    uVar3 = FUN_01675640(auStack_64,
                         "%d outstanding requests, execute=%d, openJob=%d, batchJob=%d, diag=%d, getVersion=%d, renewLease=%d, getAllJobs=%d, getStatusCount=%d, closeExpiredJobs=%d, closeJob=%d, helloWorld=%d, getExpiration=%d, closeAllJobs=%d"
                         ,uVar6,uVar5,uVar4,uVar3,uStack_38,uStack_34,uStack_30,uStack_2c,uStack_28,
                         uStack_24,uStack_20,uStack_1c,uStack_18,uStack_14);
    uStack_8 = 0;
    FUN_005500e0(uVar3);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_4c,&DAT_01c17198);
  }
  ExceptionList = &pvStack_10;
  iVar2 = FUN_005be900();
  if (iVar2 == -1) {
    if (DAT_01ea6ee8 != 0) {
LAB_00577e92:
      puVar7 = (undefined4 *)FUN_005ace30(&DAT_01e90d84);
      FUN_00550130(*puVar7);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_4c,&DAT_01c17198);
    }
  }
  else {
    iStack_3c = FUN_0057be90();
    if (iStack_3c == 0) goto LAB_00577e92;
    pcStack_40 = FUN_00589380;
    cVar1 = FUN_00585a40(&pcStack_40);
    if (cVar1 == '\0') {
      puVar8 = &DAT_018c0c81;
    }
    else {
      puVar8 = (undefined *)0x0;
    }
    FUN_005559b0(puVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 3746 ; VA 0x00577ec0 ; FUN_00577ec0 */

void __fastcall FUN_00577ec0(int param_1)

{
  *(int *)(param_1 + 0x24) = *(int *)(param_1 + 0x24) + 1;
  return;
}



/* FUNCTION 3747 ; VA 0x00577ed0 ; FUN_00577ed0 */

uint FUN_00577ed0(uint param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = param_1 * 4;
  if (param_1 < 0x40000000) {
    if (uVar3 < 0x1000) {
      if (uVar3 != 0) {
        uVar3 = FUN_01674e20(uVar3);
        return uVar3;
      }
      return 0;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar3 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar2;
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 3748 ; VA 0x00577f40 ; FUN_00577f40 */

uint FUN_00577f40(uint param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = param_1 << 5;
  if (param_1 < 0x8000000) {
    if (uVar3 < 0x1000) {
      if (uVar3 != 0) {
        uVar3 = FUN_01674e20(uVar3);
        return uVar3;
      }
      return 0;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar3 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar2;
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 3749 ; VA 0x00577fb0 ; FUN_00577fb0 */

uint FUN_00577fb0(uint param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = param_1 * 0x18;
  if (param_1 < 0xaaaaaab) {
    if (uVar3 < 0x1000) {
      if (uVar3 != 0) {
        uVar3 = FUN_01674e20(uVar3);
        return uVar3;
      }
      return 0;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar3 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar2;
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}


