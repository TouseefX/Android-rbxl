/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 18000 ; VA 0x00994fb0 ; FUN_00994fb0 */

undefined4 * __thiscall
FUN_00994fb0(undefined4 *param_1,int param_2,undefined4 *param_3,undefined4 param_4)

{
  byte bVar1;
  undefined4 ****ppppuVar2;
  undefined4 uVar3;
  int iVar4;
  byte bVar5;
  uint uVar6;
  char cVar7;
  undefined4 *puVar8;
  undefined4 ***apppuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 ***pppuStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Verb::vftable;
  if ((char)param_4 == '\0') {
    if (0xf < (uint)param_3[5]) {
      param_3 = (undefined4 *)*param_3;
    }
    uVar3 = FUN_0086e3d0(param_3);
    cVar7 = '\0';
  }
  else {
    uStack_20 = 0;
    uStack_1c = 0xf;
    apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
    uStack_8 = 0;
    FUN_00578160(0x1e,0x20);
    pppuStack_18 = apppuStack_30;
    if (0xf < uStack_1c) {
      pppuStack_18 = apppuStack_30[0];
    }
    uStack_14 = 0;
    do {
      puVar8 = param_3;
      if (0xf < (uint)param_3[5]) {
        puVar8 = (undefined4 *)*param_3;
      }
      *(byte *)((int)pppuStack_18 + uStack_14) =
           (*(char *)(uStack_14 % (uint)param_3[4] + (int)puVar8) -
           ((char)uStack_14 * -0x25 & 0x7fU)) + '\x1e';
      uStack_14 = uStack_14 + 1;
    } while (uStack_14 < 0x1e);
    ppppuVar2 = apppuStack_30;
    if (0xf < uStack_1c) {
      ppppuVar2 = (undefined4 ****)apppuStack_30[0];
    }
    uVar3 = FUN_0086e3d0(ppppuVar2);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_1c) {
      uVar6 = uStack_1c + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_30[0];
      if (0xfff < uVar6) {
        ppppuVar2 = (undefined4 ****)apppuStack_30[0][-1];
        uVar6 = uStack_1c + 0x24;
        if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar2,uVar6);
    }
    cVar7 = (char)param_4;
  }
  param_1[1] = uVar3;
  param_1[2] = param_2;
  bVar1 = FUN_01679ce0();
  if (cVar7 == '\0') {
    bVar5 = 1;
    if ((bVar1 & 0x7f) != 0) {
      bVar5 = bVar1 & 0x7f;
    }
    bVar5 = -bVar5;
  }
  else {
    bVar5 = 1;
    if ((bVar1 & 0x7f) != 0) {
      bVar5 = bVar1 & 0x7f;
    }
  }
  *(byte *)(param_1 + 3) = bVar5;
  if (param_2 != 0) {
    param_4 = param_1[1];
    iVar4 = FUN_009951f0(&param_4);
    *(undefined4 **)(iVar4 + 4) = param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18001 ; VA 0x00995130 ; FUN_00995130 */

undefined4 * __thiscall FUN_00995130(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  *param_1 = RBX::VerbContainer::vftable;
  *(undefined *)(param_1 + 1) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[2] = uVar1;
  param_1[3] = 0;
  param_1[4] = 0x3f800000;
  param_1[5] = 0;
  param_1[6] = 0;
  *(undefined *)(param_1 + 7) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[8] = uVar1;
  param_1[9] = 0;
  param_1[10] = 0x3f800000;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = param_2;
  return param_1;
}



/* FUNCTION 18002 ; VA 0x009951b0 ; FUN_009951b0 */

void __fastcall FUN_009951b0(undefined4 *param_1)

{
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  *param_1 = RBX::Verb::vftable;
  if (param_1[2] != 0) {
    uStack_c = param_1[1];
    uStack_8 = uStack_c;
    FUN_006c9730(&uStack_8);
    FUN_006c9730(&uStack_c);
  }
  return;
}



/* FUNCTION 18003 ; VA 0x009951f0 ; FUN_009951f0 */

uint * __thiscall FUN_009951f0(byte *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  undefined4 *puVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1828;
  pvStack_10 = ExceptionList;
  uVar5 = *param_2;
  uVar9 = (uVar5 >> 3) + uVar5;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&param_2,uVar9,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (uint *)0x0) {
    uStack_8 = 0;
    piVar4 = (int *)FUN_01674e20(0x10);
    puVar1 = (uint *)(piVar4 + 2);
    *piVar4 = 0;
    piVar4[1] = 0;
    puVar1[0] = 0;
    puVar1[1] = 0;
    *puVar1 = uVar5;
    if (piVar4 + 3 != (int *)0x0) {
      piVar4[3] = 0;
    }
    uVar2 = *(uint *)(param_1 + 8);
    uVar5 = uVar2 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar5 = FUN_005d6bb0(uVar5);
      if (uVar5 <= *(uint *)(param_1 + 4)) {
        uVar5 = *(uint *)(param_1 + 4);
      }
      FUN_00780ee0(uVar5);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar5) {
      param_2 = (uint *)0x1;
      uVar7 = uVar2 >> 1;
      if ((uVar2 >> 1) + uVar2 <= uVar5) {
        uVar7 = 1;
      }
      iVar6 = FUN_005d6bb0(uVar7 + uVar2);
      if (iVar6 != *(int *)(param_1 + 4)) {
        FUN_00780ee0(iVar6);
        puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar3 = (undefined4 *)*puVar10;
        while (puVar3 != (undefined4 *)0x0) {
          piVar8 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar8 = (int)puVar10;
            puVar10 = puVar3;
          }
          else {
            *puVar10 = *puVar3;
            *puVar3 = *(undefined4 *)*piVar8;
            *(undefined4 **)*piVar8 = puVar3;
          }
          puVar3 = (undefined4 *)*puVar10;
        }
      }
    }
    piVar4[1] = uVar9;
    uVar9 = uVar9 % *(uint *)(param_1 + 4);
    piVar8 = *(int **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    if (piVar8 == (int *)0x0) {
      piVar8 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar8 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar8 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar4;
      }
      *puVar10 = piVar8;
      *piVar4 = *piVar8;
    }
    else {
      *piVar4 = *piVar8;
      piVar8 = (int *)*puVar10;
    }
    *piVar8 = (int)piVar4;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return puVar1;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 18004 ; VA 0x009953b0 ; FUN_009953b0 */

undefined4 * __thiscall FUN_009953b0(undefined4 *param_1,byte param_2)

{
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  *param_1 = RBX::Verb::vftable;
  if (param_1[2] != 0) {
    uStack_c = param_1[1];
    uStack_8 = uStack_c;
    FUN_006c9730(&uStack_8);
    FUN_006c9730(&uStack_c);
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 18005 ; VA 0x00995410 ; FUN_00995410 */

undefined4 * __thiscall FUN_00995410(undefined4 *param_1,byte param_2)

{
  int iVar1;
  undefined4 *puVar2;
  
  *param_1 = RBX::VerbContainer::vftable;
  while ((param_1[3] != 0 && (iVar1 = *(int *)(param_1[6] + param_1[2] * 4), iVar1 != 0))) {
    puVar2 = *(undefined4 **)(iVar1 + 0xc);
    if (puVar2 != (undefined4 *)0x0) {
      (**(code **)*puVar2)(1);
    }
  }
  while (param_1[9] != 0) {
    if (*(int *)(param_1[0xc] + param_1[8] * 4) == 0) break;
    puVar2 = *(undefined4 **)(*(int *)(param_1[0xc] + param_1[8] * 4) + 0xc);
    if (puVar2 != (undefined4 *)0x0) {
      (**(code **)*puVar2)(1);
    }
  }
  FUN_00612320();
  FUN_00612320();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x38);
  }
  return param_1;
}



/* FUNCTION 18006 ; VA 0x00995490 ; FUN_00995490 */

undefined4 __thiscall FUN_00995490(byte *param_1,undefined4 param_2,uint *param_3)

{
  FUN_00606ea0(param_2,(*param_3 >> 3) + *param_3,param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  return param_2;
}



/* FUNCTION 18007 ; VA 0x009954d0 ; FUN_009954d0 */

undefined4 FUN_009954d0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  uint *puVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int aiStack_40 [5];
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ee70;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005f3cd0(aiStack_40,param_1,param_2);
  uStack_8 = 0;
  puVar1 = (uint *)FUN_00554130(param_3);
  uStack_28 = *puVar1;
  uStack_24 = puVar1[1];
  uStack_20 = puVar1[2];
  uStack_1c = puVar1[3];
  uStack_18 = *(undefined8 *)(puVar1 + 4);
  puVar1[4] = 0;
  puVar1[5] = 0xf;
  *(undefined *)puVar1 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar2 = FUN_0086e830(&uStack_28);
  uVar2 = FUN_00995610(uVar2);
  if (0xf < uStack_18._4_4_) {
    uVar4 = uStack_18._4_4_ + 1;
    uVar5 = uStack_28;
    if (0xfff < uVar4) {
      uVar5 = *(uint *)(uStack_28 - 4);
      uVar4 = uStack_18._4_4_ + 0x24;
      if (0x1f < (uStack_28 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar4);
  }
  uStack_18 = 0xf00000000;
  uStack_28 = uStack_28 & 0xffffff00;
  if (0xf < uStack_2c) {
    uVar5 = uStack_2c + 1;
    iVar3 = aiStack_40[0];
    if (0xfff < uVar5) {
      iVar3 = *(int *)(aiStack_40[0] + -4);
      uVar5 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 18008 ; VA 0x009955f0 ; FUN_009955f0 */

void FUN_009955f0(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_0086e830(param_1);
  FUN_00995610(uVar1);
  return;
}



/* FUNCTION 18009 ; VA 0x00995610 ; FUN_00995610 */

undefined4 __thiscall FUN_00995610(int param_1,uint param_2)

{
  int iVar1;
  int iVar2;
  int iStack_8;
  
  if (*(int *)(param_2 + 0x10) != 0) {
    iVar2 = (param_2 >> 3) + param_2;
    iStack_8 = param_1;
    do {
      iVar1 = (uint)*(byte *)(param_1 + 4) + param_1 + 5;
      FUN_00606ea0(&iStack_8,iVar2,&param_2,-(uint)(iVar1 != 0) & iVar1 + 1U);
      if (iStack_8 != 0) {
        return *(undefined4 *)(iStack_8 + 0xc);
      }
      param_1 = *(int *)(param_1 + 0x34);
    } while (param_1 != 0);
  }
  return 0;
}



/* FUNCTION 18010 ; VA 0x00995680 ; FUN_00995680 */

void __thiscall FUN_00995680(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x34) = param_2;
  return;
}



/* FUNCTION 18011 ; VA 0x00995690 ; FUN_00995690 */

undefined * FUN_00995690(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d184c;
  pvStack_10 = ExceptionList;
  if (DAT_01ee351c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee3728) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee3728);
      if (DAT_01ee3728 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"RunService",1,uStack_20,0,0,0x11,0,0);
        FUN_016f3654(&LAB_018862b0);
        FUN_016f37bf(&DAT_01ee3728);
      }
    }
    DAT_01ee351c = &DAT_01ee3520;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee351c;
}



/* FUNCTION 18012 ; VA 0x00995770 ; FUN_00995770 */

void FUN_00995770(void)

{
  int iVar1;
  
  if (DAT_01ee372c == 0) {
    iVar1 = FUN_00995690();
    DAT_01ee372c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 18013 ; VA 0x00995790 ; FUN_00995790 */

void FUN_00995790(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_009707a0();
  *(undefined2 *)(iVar1 + 0xc) = 0;
  *(undefined4 *)(iVar1 + 0x10) = *(undefined4 *)*param_2;
  *(undefined4 *)(iVar1 + 0x14) = 0;
  *(undefined4 *)(iVar1 + 0x18) = 0;
  *(undefined4 *)(iVar1 + 0x1c) = 0;
  return;
}



/* FUNCTION 18014 ; VA 0x009957d0 ; FUN_009957d0 */

void FUN_009957d0(uint *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint *puVar6;
  
  if (param_1 != param_2) {
    puVar6 = param_1 + 5;
    do {
      FUN_00d88a30();
      uVar2 = *puVar6;
      if (0xf < uVar2) {
        uVar3 = puVar6[-5];
        uVar5 = uVar2 + 1;
        uVar4 = uVar3;
        if (0xfff < uVar5) {
          uVar4 = *(uint *)(uVar3 - 4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (uVar3 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar4,uVar5);
      }
      puVar6[-1] = 0;
      *puVar6 = 0xf;
      *(undefined *)(puVar6 + -5) = 0;
      puVar1 = puVar6 + 9;
      puVar6 = puVar6 + 0xe;
    } while (puVar1 != param_2);
  }
  return;
}



/* FUNCTION 18015 ; VA 0x00995840 ; FUN_00995840 */

void FUN_00995840(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  if (param_1 != param_2) {
    piVar5 = param_1 + 8;
    ExceptionList = &pvStack_10;
    do {
      uStack_8 = 0xffffffff;
      iVar2 = piVar5[-2];
      if (iVar2 != 0) {
        uVar4 = (*piVar5 - iVar2 >> 2) * 4;
        iVar3 = iVar2;
        if (0xfff < uVar4) {
          iVar3 = *(int *)(iVar2 + -4);
          uVar4 = uVar4 + 0x23;
          if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar3,uVar4);
        piVar5[-2] = 0;
        piVar5[-1] = 0;
        *piVar5 = 0;
      }
      uStack_8 = 0;
      FUN_01674ea0(piVar5[-5]);
      piVar5[-5] = 0;
      piVar5[-4] = 0;
      piVar5[-3] = 0;
      uStack_8 = 1;
      FUN_01674ea0(piVar5[-8]);
      piVar5[-8] = 0;
      piVar5[-7] = 0;
      piVar5[-6] = 0;
      piVar1 = piVar5 + 1;
      piVar5 = piVar5 + 9;
    } while (piVar1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18016 ; VA 0x00995940 ; FUN_00995940 */

void FUN_00995940(undefined4 *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    do {
      uVar1 = param_1[3];
      uStack_8 = 0;
      if ((uVar1 & 0xfffffff8) != 0) {
        if ((~(byte)((int)uVar1 >> 2) & 1) == 0) {
          puVar2 = param_1;
          if (((int)uVar1 >> 1 & 1U) == 0) {
            puVar2 = (undefined4 *)*param_1;
          }
          (**(code **)((uVar1 & 0xfffffff8) + 8))(puVar2);
        }
        if (((int)uVar1 >> 1 & 1U) == 0) {
          FUN_01674ee0(*param_1);
        }
      }
      param_1 = param_1 + 4;
    } while (param_1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18017 ; VA 0x009959d0 ; FUN_009959d0 */

void FUN_009959d0(int *param_1,int *param_2)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (param_1 != param_2) {
    do {
      iVar1 = *param_1;
      if (iVar1 != 0) {
        uVar2 = ((param_1[2] - iVar1) / 0x2c) * 0x2c;
        iVar3 = iVar1;
        if (0xfff < uVar2) {
          iVar3 = *(int *)(iVar1 + -4);
          uVar2 = uVar2 + 0x23;
          if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar3,uVar2);
        *param_1 = 0;
        param_1[1] = 0;
        param_1[2] = 0;
      }
      param_1 = param_1 + 3;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 18018 ; VA 0x00995a50 ; FUN_00995a50 */

void FUN_00995a50(int *param_1,int *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    do {
      puVar3 = (undefined4 *)*param_1;
      if (puVar3 != (undefined4 *)0x0) {
        puVar4 = (undefined4 *)param_1[1];
        if (puVar3 != puVar4) {
          do {
            uVar2 = puVar3[3];
            uStack_8 = 0;
            if ((uVar2 & 0xfffffff8) != 0) {
              if ((~(byte)((int)uVar2 >> 2) & 1) == 0) {
                puVar1 = puVar3;
                if (((int)uVar2 >> 1 & 1U) == 0) {
                  puVar1 = (undefined4 *)*puVar3;
                }
                (**(code **)((uVar2 & 0xfffffff8) + 8))(puVar1);
              }
              if (((int)uVar2 >> 1 & 1U) == 0) {
                FUN_01674ee0(*puVar3);
              }
            }
            puVar3 = puVar3 + 4;
            uStack_8 = 0xffffffff;
          } while (puVar3 != puVar4);
          puVar3 = (undefined4 *)*param_1;
        }
        uVar2 = param_1[2] - (int)puVar3 & 0xfffffff0;
        puVar4 = puVar3;
        if (0xfff < uVar2) {
          puVar4 = (undefined4 *)puVar3[-1];
          uVar2 = uVar2 + 0x23;
          if (0x1f < (uint)((int)puVar3 + (-4 - (int)puVar4))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(puVar4,uVar2);
        *param_1 = 0;
        param_1[1] = 0;
        param_1[2] = 0;
      }
      param_1 = param_1 + 3;
    } while (param_1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18019 ; VA 0x00995b60 ; FUN_00995b60 */

int __thiscall FUN_00995b60(int *param_1,int param_2,undefined4 *param_3)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  undefined4 *puVar9;
  uint uVar10;
  uint uVar11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1868;
  pvStack_10 = ExceptionList;
  iVar8 = *param_1;
  iVar2 = (param_1[1] - *param_1) / 0x38;
  if (iVar2 == 0x4924924) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar10 = (param_1[2] - *param_1) / 0x38;
  uVar11 = iVar2 + 1;
  if (uVar10 <= 0x4924924 - (uVar10 >> 1)) {
    uVar11 = (uVar10 >> 1) + uVar10;
    if (uVar11 < iVar2 + 1U) {
      uVar11 = iVar2 + 1U;
    }
  }
  ExceptionList = &pvStack_10;
  iVar6 = FUN_0082c100(uVar11);
  iVar8 = ((param_2 - iVar8) / 0x38) * 0x38;
  puVar9 = (undefined4 *)(iVar8 + iVar6);
  puVar9[4] = 0;
  puVar9[5] = 0;
  uVar3 = param_3[1];
  uVar4 = param_3[2];
  uVar5 = param_3[3];
  *puVar9 = *param_3;
  puVar9[1] = uVar3;
  puVar9[2] = uVar4;
  puVar9[3] = uVar5;
  *(undefined8 *)(puVar9 + 4) = *(undefined8 *)(param_3 + 4);
  param_3[4] = 0;
  param_3[5] = 0xf;
  *(undefined *)param_3 = 0;
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  FUN_00d88580(param_3 + 6);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (param_2 == param_1[1]) {
    FUN_009963f0(*param_1,param_1[1],iVar6,param_1);
  }
  else {
    FUN_00997cc0(*param_1,param_2,iVar6);
    FUN_00997cc0(param_2,param_1[1],puVar9 + 0xe);
  }
  if (*param_1 != 0) {
    FUN_009957d0(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar10 = ((param_1[2] - *param_1) / 0x38) * 0x38;
    iVar7 = iVar1;
    if (0xfff < uVar10) {
      iVar7 = *(int *)(iVar1 + -4);
      uVar10 = uVar10 + 0x23;
      if (0x1f < (iVar1 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar10);
  }
  *param_1 = iVar6;
  param_1[1] = iVar6 + (iVar2 + 1) * 0x38;
  param_1[2] = iVar6 + uVar11 * 0x38;
  ExceptionList = pvStack_10;
  return *param_1 + iVar8;
}



/* FUNCTION 18020 ; VA 0x00995d5b ; Catch_All@00995d5b */

void Catch_All_00995d5b(void)

{
  int unaff_EBP;
  
  FUN_00997780(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x20));
  FUN_00875970(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x24));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18021 ; VA 0x00995d90 ; FUN_00995d90 */

void __thiscall
FUN_00995d90(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x7fffffd < (uint)param_1[1]) {
    FUN_00997a40(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00995e42:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00995e42;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 18022 ; VA 0x00995ef0 ; FUN_00995ef0 */

undefined4 * __thiscall
FUN_00995ef0(undefined4 *param_1,undefined4 *param_2,int *param_3,int *param_4,undefined4 param_5)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined *puVar4;
  int *piVar5;
  undefined4 *puVar6;
  bool bVar7;
  undefined auStack_20 [4];
  undefined4 *puStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d1880;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd4;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  puStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_00995d90(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar5 = (int *)*param_1;
  if (param_3 == (int *)*piVar5) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*param_4 < param_3[4]) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_00995d90(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar5) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*(int *)(piVar5[2] + 0x10) < *param_4) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_00995d90(param_2,0,piVar5[2],param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    iVar1 = *param_4;
    iVar2 = param_3[4];
    bVar7 = SBORROW4(iVar2,iVar1);
    iVar3 = iVar2 - iVar1;
    ExceptionList = &pvStack_10;
    puVar4 = &stack0xffffffd4;
    if (iVar1 < iVar2) {
      piStack_18 = param_3;
      ExceptionList = &pvStack_10;
      piVar5 = (int *)FUN_0056f560();
      iVar3 = *param_4;
      if (*(int *)(*piVar5 + 0x10) < iVar3) {
        if (*(char *)(piStack_18[2] + 0xd) != '\0') {
          FUN_00995d90(param_2,0,piStack_18,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00995d90(param_2,1,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
      bVar7 = SBORROW4(param_3[4],iVar3);
      iVar3 = param_3[4] - iVar3;
      puVar4 = puStack_14;
    }
    puStack_14 = puVar4;
    if (bVar7 != iVar3 < 0) {
      piStack_18 = param_3;
      FUN_00551320();
      if ((piStack_18 == (int *)*param_1) || (*param_4 < piStack_18[4])) {
        if (*(char *)(param_3[2] + 0xd) != '\0') {
          FUN_00995d90(param_2,0,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00995d90(param_2,1,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = (undefined4 *)FUN_009960f0(auStack_20,0,param_4,param_5);
  *param_2 = *puVar6;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18023 ; VA 0x009960db ; Catch_All@009960db */

void Catch_All_009960db(void)

{
  int unaff_EBP;
  
  FUN_00997a40(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18024 ; VA 0x009960f0 ; FUN_009960f0 */

void __thiscall
FUN_009960f0(undefined4 *param_1,undefined4 *param_2,char param_3,int *param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int *piVar2;
  undefined4 *puVar3;
  int *piVar4;
  bool bVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d1890;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piVar2 = (int *)*param_1;
  bVar5 = true;
  piVar4 = piVar2;
  if (*(char *)(piVar2[1] + 0xd) == '\0') {
    piVar2 = (int *)piVar2[1];
    do {
      piVar4 = piVar2;
      if (param_3 == '\0') {
        bVar5 = *param_4 < piVar4[4];
      }
      else {
        bVar5 = *param_4 <= piVar4[4];
      }
      if (bVar5 == false) {
        piVar2 = (int *)piVar4[2];
      }
      else {
        piVar2 = (int *)*piVar4;
      }
    } while (*(char *)((int)piVar2 + 0xd) == '\0');
    piVar2 = (int *)*param_1;
  }
  ExceptionList = &pvStack_10;
  _param_3 = piVar4;
  if (bVar5) {
    if (piVar4 == (int *)*piVar2) {
      bVar5 = true;
      ExceptionList = &pvStack_10;
      goto LAB_00996177;
    }
    ExceptionList = &pvStack_10;
    FUN_0056f560();
  }
  uVar1 = param_5;
  piVar2 = _param_3;
  if (*param_4 <= _param_3[4]) {
    FUN_00997ac0();
    FUN_01674ea0(uVar1,0x20);
    *param_2 = piVar2;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00996177:
  puVar3 = (undefined4 *)FUN_00995d90(&param_3,bVar5,piVar4,param_4,param_5);
  *param_2 = *puVar3;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18025 ; VA 0x009961f1 ; Catch_All@009961f1 */

void Catch_All_009961f1(void)

{
  int unaff_EBP;
  
  FUN_00997a40(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18026 ; VA 0x00996210 ; FUN_00996210 */

int __thiscall FUN_00996210(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d18a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::HeartbeatTask>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0xc) == 0 || (*(int *)(*(int *)(param_2 + 0xc) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 8) = param_2;
    piVar3 = *(int **)(param_2 + 0xc);
    *(int **)(param_2 + 0xc) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18027 ; VA 0x009962e4 ; Catch_All@009962e4 */

void Catch_All_009962e4(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18028 ; VA 0x00996300 ; FUN_00996300 */

int __thiscall FUN_00996300(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d18b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::PhysicsJob>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0xc) == 0 || (*(int *)(*(int *)(param_2 + 0xc) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 8) = param_2;
    piVar3 = *(int **)(param_2 + 0xc);
    *(int **)(param_2 + 0xc) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18029 ; VA 0x009963d4 ; Catch_All@009963d4 */

void Catch_All_009963d4(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18030 ; VA 0x009963f0 ; FUN_009963f0 */

int FUN_009963f0(int param_1,int param_2,int param_3,undefined4 param_4)

{
  void **ppvVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d18d0;
  pvStack_10 = ExceptionList;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  ppvVar1 = &pvStack_10;
  if (param_1 != param_2) {
    do {
      uStack_8 = 0;
      FUN_0054ef60(param_1);
      uStack_8 = 1;
      FUN_00d88580(param_1 + 0x18);
      param_3 = param_3 + 0x38;
      param_1 = param_1 + 0x38;
      ppvVar1 = (void **)ExceptionList;
    } while (param_1 != param_2);
  }
  ExceptionList = ppvVar1;
  uStack_8 = 0;
  FUN_009957d0(param_3,param_3,param_4);
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 18031 ; VA 0x00996480 ; FUN_00996480 */

undefined4 * __thiscall
FUN_00996480(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  undefined4 *puStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d192b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_00995690();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::BoundFuncDesc<class_RBX::RunService,void___cdecl(bool),1>::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8 = 1;
  uVar2 = FUN_00888530();
  param_1[9] = uVar2;
  puVar1 = (undefined *)param_1[0x10];
  if (puVar1 == (undefined *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088daf0();
    puStack_e4 = (undefined4 *)0x0;
    auStack_e0[0] = *puVar1;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8bf8) {
      FUN_016f3809(&DAT_01ea8bf8);
      if (DAT_01ea8bf8 == -1) {
        DAT_01ea8bec = FUN_005c6640;
        DAT_01ea8bf0 = FUN_005c6640;
        DAT_01ea8bf4 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ea8bf8);
      }
    }
    puStack_e4 = &DAT_01ea8bec;
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088daf0();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_e4 != (undefined4 *)0x0) {
      (*(code *)puStack_e4[2])(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18032 ; VA 0x00996660 ; FUN_00996660 */

undefined4 * __thiscall FUN_00996660(undefined4 *param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uStack_34;
  undefined *puStack_30;
  uint uStack_2c;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d195e;
  pvStack_10 = ExceptionList;
  uStack_2c = 6;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00944080(&uStack_34,-(uint)(*(int *)(param_2 + 0x34) != 0) & *(int *)(param_2 + 0x34) + 4U);
  FUN_00a360a0("Heartbeat",1,0);
  *param_1 = RBX::HeartbeatTask::vftable;
  param_1[0x4a] = 0;
  param_1[0x4b] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  param_1[0x4a] = param_2;
  param_1[0x4b] = param_3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uStack_2c = -(uint)(*(int *)(param_2 + 0x34) != 0) & *(int *)(param_2 + 0x34) + 4U;
  puStack_30 = auStack_1c;
  uStack_34 = 0x99670b;
  puVar3 = (undefined4 *)FUN_00944080();
  param_1[0x4c] = 0;
  param_1[0x4d] = 0;
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x4c] = *puVar3;
  param_1[0x4d] = puVar3[1];
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_2c = 0x996759;
      (**(code **)*piStack_18)();
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_2c = 0x996769;
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_2c = 0x99677f;
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_2c = 0x99678e;
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18033 ; VA 0x009967b0 ; FUN_009967b0 */

undefined4 * __fastcall FUN_009967b0(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1a54;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::RunService,class_RBX::ServiceInstance>::vftable;
  uVar2 = FUN_00995690();
  param_1[3] = uVar2;
  *param_1 = RBX::RunService::vftable;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  puVar1 = param_1 + 0x22;
  param_1[0x1a] = 0;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  *(undefined8 *)(param_1 + 0x20) = 0;
  *puVar1 = 0;
  param_1[0x23] = 0;
  puStack_18 = puVar1;
  uVar2 = FUN_00575ab0();
  *puVar1 = uVar2;
  uStack_8._0_1_ = 4;
  *(undefined2 *)(param_1 + 0x24) = 0;
  *(undefined *)((int)param_1 + 0x92) = 0;
  FUN_01682800(param_1 + 0x26);
  *(undefined2 *)(param_1 + 0x2a) = 1;
  *(undefined8 *)(param_1 + 0x28) = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  *(undefined *)(param_1 + 0x2d) = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  uStack_8._0_1_ = 0x10;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("Run Service",0xb);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
  FUN_008a6520(auStack_30);
  if (0xf < uStack_1c) {
    uVar4 = uStack_1c + 1;
    uVar3 = auStack_30[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_30[0] - 4);
      uVar4 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18034 ; VA 0x009969b0 ; FUN_009969b0 */

void __fastcall FUN_009969b0(undefined4 *param_1)

{
  FUN_009957d0(*param_1,param_1[1],param_1[2]);
  return;
}



/* FUNCTION 18035 ; VA 0x009969d0 ; thunk_FUN_00998890 */

void __fastcall thunk_FUN_00998890(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  uVar2 = 0;
  if (param_1[4] != 0) {
    do {
      param_1[2] = param_1[2] + 0x18;
      uVar2 = uVar2 + 1;
      if (param_1[2] == param_1[1]) {
        param_1[2] = *param_1;
      }
    } while (uVar2 < (uint)param_1[4]);
  }
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[1] - iVar1) / 0x18) * 0x18;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  return;
}



/* FUNCTION 18036 ; VA 0x009969e0 ; FUN_009969e0 */

void __fastcall FUN_009969e0(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00997a70(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18037 ; VA 0x00996a40 ; FUN_00996a40 */

void __fastcall FUN_00996a40(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  FUN_00d88a30();
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 18038 ; VA 0x00996aa0 ; FUN_00996aa0 */

void __fastcall FUN_00996aa0(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  puVar5 = (undefined4 *)*param_1;
  if (puVar5 != (undefined4 *)0x0) {
    puVar6 = (undefined4 *)param_1[1];
    ExceptionList = &pvStack_10;
    if (puVar5 != puVar6) {
      piVar4 = puVar5 + 8;
      ExceptionList = &pvStack_10;
      do {
        uStack_8 = 0xffffffff;
        iVar1 = piVar4[-2];
        if (iVar1 != 0) {
          uVar3 = (*piVar4 - iVar1 >> 2) * 4;
          iVar2 = iVar1;
          if (0xfff < uVar3) {
            iVar2 = *(int *)(iVar1 + -4);
            uVar3 = uVar3 + 0x23;
            if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_00996bfa;
          }
          FUN_01674ea0(iVar2,uVar3);
          piVar4[-2] = 0;
          piVar4[-1] = 0;
          *piVar4 = 0;
        }
        uStack_8 = 0;
        FUN_01674ea0(piVar4[-5]);
        piVar4[-5] = 0;
        piVar4[-4] = 0;
        piVar4[-3] = 0;
        uStack_8 = 1;
        FUN_01674ea0(*puVar5);
        *puVar5 = 0;
        piVar4[-7] = 0;
        puVar5 = puVar5 + 9;
        piVar4[-6] = 0;
        piVar4 = piVar4 + 9;
      } while (puVar5 != puVar6);
      puVar5 = (undefined4 *)*param_1;
    }
    uStack_8 = 0xffffffff;
    uVar3 = ((param_1[2] - (int)puVar5) / 0x24) * 0x24;
    puVar6 = puVar5;
    if (0xfff < uVar3) {
      puVar6 = (undefined4 *)puVar5[-1];
      uVar3 = uVar3 + 0x23;
      if (0x1f < (uint)((int)puVar5 + (-4 - (int)puVar6))) {
LAB_00996bfa:
        uStack_8 = 0xffffffff;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar6,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18039 ; VA 0x00996c00 ; FUN_00996c00 */

void __fastcall FUN_00996c00(undefined4 *param_1)

{
  int iVar1;
  uint uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  
  piVar3 = (int *)*param_1;
  if (piVar3 != (int *)0x0) {
    piVar4 = (int *)param_1[1];
    if (piVar3 != piVar4) {
      do {
        iVar1 = *piVar3;
        if (iVar1 != 0) {
          uVar2 = ((piVar3[2] - iVar1) / 0x2c) * 0x2c;
          iVar5 = iVar1;
          if (0xfff < uVar2) {
            iVar5 = *(int *)(iVar1 + -4);
            uVar2 = uVar2 + 0x23;
            if (0x1f < (iVar1 - iVar5) - 4U) goto LAB_00996ce0;
          }
          FUN_01674ea0(iVar5,uVar2);
          *piVar3 = 0;
          piVar3[1] = 0;
          piVar3[2] = 0;
        }
        piVar3 = piVar3 + 3;
      } while (piVar3 != piVar4);
      piVar3 = (int *)*param_1;
    }
    uVar2 = ((param_1[2] - (int)piVar3) / 0xc) * 0xc;
    piVar4 = piVar3;
    if (0xfff < uVar2) {
      piVar4 = (int *)piVar3[-1];
      uVar2 = uVar2 + 0x23;
      if (0x1f < (uint)((int)piVar3 + (-4 - (int)piVar4))) {
LAB_00996ce0:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar4,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 18040 ; VA 0x00996cf0 ; FUN_00996cf0 */

void FUN_00996cf0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00997b40();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18041 ; VA 0x00996d20 ; FUN_00996d20 */

int __fastcall FUN_00996d20(int param_1)

{
  int iVar1;
  void **ppvVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  int *piVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  int iVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794990;
  pvStack_10 = ExceptionList;
  piVar6 = *(int **)(param_1 + 0x30);
  ExceptionList = &pvStack_10;
  if (piVar6 != (int *)0x0) {
    piVar5 = *(int **)(param_1 + 0x34);
    ExceptionList = &pvStack_10;
    ppvVar2 = &pvStack_10;
    if (piVar6 != piVar5) {
      do {
        iVar3 = *piVar6;
        if (iVar3 != 0) {
          uVar4 = ((piVar6[2] - iVar3) / 0x2c) * 0x2c;
          iVar9 = iVar3;
          if (0xfff < uVar4) {
            iVar9 = *(int *)(iVar3 + -4);
            uVar4 = uVar4 + 0x23;
            if (0x1f < (iVar3 - iVar9) - 4U) goto LAB_00997017;
          }
          FUN_01674ea0(iVar9,uVar4);
          *piVar6 = 0;
          piVar6[1] = 0;
          piVar6[2] = 0;
        }
        piVar6 = piVar6 + 3;
      } while (piVar6 != piVar5);
      piVar6 = *(int **)(param_1 + 0x30);
      ppvVar2 = (void **)ExceptionList;
    }
    ExceptionList = ppvVar2;
    uVar4 = ((*(int *)(param_1 + 0x38) - (int)piVar6) / 0xc) * 0xc;
    piVar5 = piVar6;
    if (0xfff < uVar4) {
      piVar5 = (int *)piVar6[-1];
      uVar4 = uVar4 + 0x23;
      if (0x1f < (uint)((int)piVar6 + (-4 - (int)piVar5))) goto LAB_00997017;
    }
    FUN_01674ea0(piVar5,uVar4);
    *(undefined4 *)(param_1 + 0x30) = 0;
    *(undefined4 *)(param_1 + 0x34) = 0;
    *(undefined4 *)(param_1 + 0x38) = 0;
  }
  puVar7 = *(undefined4 **)(param_1 + 0x24);
  if (puVar7 != (undefined4 *)0x0) {
    puVar8 = *(undefined4 **)(param_1 + 0x28);
    if (puVar7 != puVar8) {
      piVar6 = puVar7 + 8;
      do {
        iVar3 = piVar6[-2];
        if (iVar3 != 0) {
          uVar4 = (*piVar6 - iVar3 >> 2) * 4;
          iVar9 = iVar3;
          if (0xfff < uVar4) {
            iVar9 = *(int *)(iVar3 + -4);
            uVar4 = uVar4 + 0x23;
            if (0x1f < (iVar3 - iVar9) - 4U) goto LAB_00997017;
          }
          FUN_01674ea0(iVar9,uVar4);
          piVar6[-2] = 0;
          piVar6[-1] = 0;
          *piVar6 = 0;
        }
        uStack_8 = 0;
        FUN_01674ea0(piVar6[-5]);
        piVar6[-5] = 0;
        piVar6[-4] = 0;
        piVar6[-3] = 0;
        uStack_8 = 1;
        FUN_01674ea0(*puVar7);
        *puVar7 = 0;
        piVar6[-7] = 0;
        puVar7 = puVar7 + 9;
        piVar6[-6] = 0;
        piVar6 = piVar6 + 9;
        uStack_8 = 0xffffffff;
      } while (puVar7 != puVar8);
      puVar7 = *(undefined4 **)(param_1 + 0x24);
    }
    uVar4 = ((*(int *)(param_1 + 0x2c) - (int)puVar7) / 0x24) * 0x24;
    puVar8 = puVar7;
    if (0xfff < uVar4) {
      puVar8 = (undefined4 *)puVar7[-1];
      uVar4 = uVar4 + 0x23;
      if (0x1f < (uint)((int)puVar7 + (-4 - (int)puVar8))) goto LAB_00997017;
    }
    FUN_01674ea0(puVar8,uVar4);
    *(undefined4 *)(param_1 + 0x24) = 0;
    *(undefined4 *)(param_1 + 0x28) = 0;
    *(undefined4 *)(param_1 + 0x2c) = 0;
  }
  uStack_8 = 2;
  iVar3 = FUN_00997b40();
  piVar6 = *(int **)(param_1 + 0x14);
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar5 = piVar6 + 1;
    iVar9 = *piVar5;
    iVar3 = *piVar5;
    *piVar5 = iVar9 + -1;
    UNLOCK();
    if (iVar9 + -1 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      piVar5 = piVar6 + 2;
      iVar9 = *piVar5;
      iVar3 = *piVar5;
      *piVar5 = iVar9 + -1;
      UNLOCK();
      if (iVar9 + -1 == 0) {
        iVar3 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  iVar9 = *(int *)(param_1 + 4);
  if (iVar9 != 0) {
    iVar3 = *(int *)(param_1 + 8);
    if (iVar9 != iVar3) {
      do {
        piVar6 = *(int **)(iVar9 + 4);
        if (piVar6 != (int *)0x0) {
          LOCK();
          iVar1 = piVar6[1] + -1;
          piVar6[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar6)();
            LOCK();
            iVar1 = piVar6[2] + -1;
            piVar6[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
        iVar9 = iVar9 + 8;
      } while (iVar9 != iVar3);
      iVar9 = *(int *)(param_1 + 4);
    }
    uVar4 = *(int *)(param_1 + 0xc) - iVar9 & 0xfffffff8;
    iVar3 = iVar9;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar9 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar9 - iVar3) - 4U) {
LAB_00997017:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar3 = FUN_01674ea0(iVar3,uVar4);
    *(undefined4 *)(param_1 + 4) = 0;
    *(undefined4 *)(param_1 + 8) = 0;
    *(undefined4 *)(param_1 + 0xc) = 0;
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 18042 ; VA 0x00997020 ; FUN_00997020 */

void __fastcall FUN_00997020(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  iVar1 = param_1[6];
  ExceptionList = &pvStack_10;
  if (iVar1 != 0) {
    uVar3 = (param_1[8] - iVar1 >> 2) * 4;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
        ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0(iVar2,uVar3);
    param_1[6] = 0;
    param_1[7] = 0;
    param_1[8] = 0;
  }
  uStack_8 = 0;
  FUN_01674ea0(param_1[3]);
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  uStack_8 = 1;
  FUN_01674ea0(*param_1);
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18043 ; VA 0x009970f0 ; FUN_009970f0 */

void __fastcall FUN_009970f0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  iVar2 = param_1[0x2e];
  ExceptionList = &pvStack_10;
  *param_1 = RBX::RunService::vftable;
  if (iVar2 != 0) {
    FUN_00996d20();
    FUN_01674ea0(iVar2,0x3c);
    param_1[0x2e] = 0;
  }
  if ((DAT_01d6fc20 != '\0') && (iVar2 = param_1[0x2f], iVar2 != 0)) {
    uStack_8 = 0;
    FUN_00997b40();
    piVar3 = *(int **)(iVar2 + 0x14);
    uStack_8 = 0xffffffff;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar6 = piVar3[1] + -1;
      piVar3[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar6 = piVar3[2] + -1;
        piVar3[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    iVar6 = *(int *)(iVar2 + 4);
    if (iVar6 != 0) {
      iVar7 = *(int *)(iVar2 + 8);
      if (iVar6 != iVar7) {
        do {
          piVar3 = *(int **)(iVar6 + 4);
          if (piVar3 != (int *)0x0) {
            LOCK();
            iVar4 = piVar3[1] + -1;
            piVar3[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)*piVar3)();
              LOCK();
              iVar4 = piVar3[2] + -1;
              piVar3[2] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)(*piVar3 + 4))();
              }
            }
          }
          iVar6 = iVar6 + 8;
        } while (iVar6 != iVar7);
        iVar6 = *(int *)(iVar2 + 4);
      }
      uVar5 = (*(int *)(iVar2 + 0xc) - iVar6 >> 3) * 8;
      iVar7 = iVar6;
      if (0xfff < uVar5) {
        iVar7 = *(int *)(iVar6 + -4);
        uVar5 = uVar5 + 0x23;
        if (0x1f < (iVar6 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar7,uVar5);
      *(undefined4 *)(iVar2 + 4) = 0;
      *(undefined4 *)(iVar2 + 8) = 0;
      *(undefined4 *)(iVar2 + 0xc) = 0;
    }
    FUN_01674ea0(iVar2,0x24);
    param_1[0x2f] = 0;
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  piVar3 = (int *)param_1[0x2c];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[2] + -1;
    piVar3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar3 + 4))();
    }
  }
  piVar3 = param_1 + 0x22;
  iVar2 = *piVar3;
  uStack_8 = 1;
  FUN_00997a70(*(undefined4 *)(iVar2 + 4));
  *(int *)(*piVar3 + 4) = iVar2;
  *(int *)*piVar3 = iVar2;
  *(int *)(*piVar3 + 8) = iVar2;
  param_1[0x23] = 0;
  FUN_01674ea0(*piVar3,0x20);
  piVar3 = (int *)param_1[0x19];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = (int *)param_1[0x17];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18044 ; VA 0x00997390 ; FUN_00997390 */

/* WARNING: Removing unreachable block (ram,0x009973e2) */
/* WARNING: Removing unreachable block (ram,0x009973f2) */
/* WARNING: Removing unreachable block (ram,0x009973f8) */

void __fastcall FUN_00997390(int *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1a70;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_01675290();
    uStack_8 = 2;
    FUN_005e6300();
    FUN_0056c630();
    uStack_8 = 4;
    FUN_01675290();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18045 ; VA 0x00997448 ; Catch@00997448 */

undefined * Catch_00997448(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x20));
  return &DAT_00997459;
}



/* FUNCTION 18046 ; VA 0x00997470 ; FUN_00997470 */

/* WARNING: Removing unreachable block (ram,0x009974c2) */
/* WARNING: Removing unreachable block (ram,0x009974d2) */
/* WARNING: Removing unreachable block (ram,0x009974d8) */

void __fastcall FUN_00997470(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1a90;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8 = 2;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = 4;
    FUN_01675290(uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18047 ; VA 0x00997516 ; Catch@00997516 */

undefined * Catch_00997516(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x20));
  return &DAT_00997527;
}



/* FUNCTION 18048 ; VA 0x00997540 ; FUN_00997540 */

int * __thiscall FUN_00997540(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  if (param_2 < 1) {
    if (param_2 < 0) {
      iVar5 = -param_2;
      if (iVar5 != 0 && 0 >= param_2) {
        iVar4 = param_1[1];
        if (iVar4 == 0) {
          iVar4 = ((int *)*param_1)[3];
        }
        iVar2 = *(int *)*param_1;
        iVar3 = (iVar4 - iVar2) / 0x18;
        if (-iVar3 != param_2 && iVar3 <= iVar5) {
          iVar5 = iVar5 - (*(int *)(*param_1 + 4) - iVar2) / 0x18;
        }
        param_1[1] = iVar4 + iVar5 * -0x18;
        return param_1;
      }
      if (0 < param_2) {
        FUN_00997540(param_2);
      }
    }
  }
  else {
    piVar1 = (int *)*param_1;
    if ((piVar1[1] - param_1[1]) / 0x18 <= param_2) {
      param_2 = param_2 - (piVar1[1] - *piVar1) / 0x18;
    }
    iVar5 = param_1[1] + param_2 * 0x18;
    param_1[1] = iVar5;
    if (iVar5 == piVar1[3]) {
      param_1[1] = 0;
      return param_1;
    }
  }
  return param_1;
}



/* FUNCTION 18049 ; VA 0x00997620 ; FUN_00997620 */

int __thiscall FUN_00997620(int param_1,byte param_2)

{
  if (*(int **)(param_1 + 0x48) != (int *)0x0) {
    (**(code **)(**(int **)(param_1 + 0x48) + 4))(1);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  FUN_005c4ac0();
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 18050 ; VA 0x00997670 ; FUN_00997670 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00997670(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::RunService::RenderPriority>::vftable;
  _DAT_01ee3730 = _DAT_01ee3730 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 18051 ; VA 0x009976a0 ; FUN_009976a0 */

int __thiscall FUN_009976a0(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x134);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 300);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x138);
  }
  return param_1;
}



/* FUNCTION 18052 ; VA 0x00997700 ; FUN_00997700 */

int __thiscall FUN_00997700(int param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 0x144);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_00998890();
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x148);
  }
  return param_1;
}



/* FUNCTION 18053 ; VA 0x00997750 ; FUN_00997750 */

undefined4 __thiscall FUN_00997750(undefined4 param_1,byte param_2)

{
  FUN_009970f0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xf0);
  }
  return param_1;
}



/* FUNCTION 18054 ; VA 0x00997780 ; FUN_00997780 */

void __thiscall FUN_00997780(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_009957d0(param_2,param_3,param_1);
  return;
}



/* FUNCTION 18055 ; VA 0x009977a0 ; FUN_009977a0 */

void FUN_009977a0(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  if (param_1 != param_2) {
    piVar5 = param_1 + 8;
    ExceptionList = &pvStack_10;
    do {
      uStack_8 = 0xffffffff;
      iVar2 = piVar5[-2];
      if (iVar2 != 0) {
        uVar4 = (*piVar5 - iVar2 >> 2) * 4;
        iVar3 = iVar2;
        if (0xfff < uVar4) {
          iVar3 = *(int *)(iVar2 + -4);
          uVar4 = uVar4 + 0x23;
          if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar3,uVar4);
        piVar5[-2] = 0;
        piVar5[-1] = 0;
        *piVar5 = 0;
      }
      uStack_8 = 0;
      FUN_01674ea0(piVar5[-5]);
      piVar5[-5] = 0;
      piVar5[-4] = 0;
      piVar5[-3] = 0;
      uStack_8 = 1;
      FUN_01674ea0(piVar5[-8]);
      piVar5[-8] = 0;
      piVar5[-7] = 0;
      piVar5[-6] = 0;
      piVar1 = piVar5 + 1;
      piVar5 = piVar5 + 9;
    } while (piVar1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18056 ; VA 0x009978a0 ; FUN_009978a0 */

void FUN_009978a0(undefined4 *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    do {
      uVar1 = param_1[3];
      uStack_8 = 0;
      if ((uVar1 & 0xfffffff8) != 0) {
        if ((~(byte)((int)uVar1 >> 2) & 1) == 0) {
          puVar2 = param_1;
          if (((int)uVar1 >> 1 & 1U) == 0) {
            puVar2 = (undefined4 *)*param_1;
          }
          (**(code **)((uVar1 & 0xfffffff8) + 8))(puVar2);
        }
        if (((int)uVar1 >> 1 & 1U) == 0) {
          FUN_01674ee0(*param_1);
        }
      }
      param_1 = param_1 + 4;
    } while (param_1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18057 ; VA 0x00997930 ; FUN_00997930 */

void FUN_00997930(int *param_1,int *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    do {
      puVar3 = (undefined4 *)*param_1;
      if (puVar3 != (undefined4 *)0x0) {
        puVar4 = (undefined4 *)param_1[1];
        if (puVar3 != puVar4) {
          do {
            uVar2 = puVar3[3];
            uStack_8 = 0;
            if ((uVar2 & 0xfffffff8) != 0) {
              if ((~(byte)((int)uVar2 >> 2) & 1) == 0) {
                puVar1 = puVar3;
                if (((int)uVar2 >> 1 & 1U) == 0) {
                  puVar1 = (undefined4 *)*puVar3;
                }
                (**(code **)((uVar2 & 0xfffffff8) + 8))(puVar1);
              }
              if (((int)uVar2 >> 1 & 1U) == 0) {
                FUN_01674ee0(*puVar3);
              }
            }
            puVar3 = puVar3 + 4;
            uStack_8 = 0xffffffff;
          } while (puVar3 != puVar4);
          puVar3 = (undefined4 *)*param_1;
        }
        uVar2 = param_1[2] - (int)puVar3 & 0xfffffff0;
        puVar4 = puVar3;
        if (0xfff < uVar2) {
          puVar4 = (undefined4 *)puVar3[-1];
          uVar2 = uVar2 + 0x23;
          if (0x1f < (uint)((int)puVar3 + (-4 - (int)puVar4))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(puVar4,uVar2);
        *param_1 = 0;
        param_1[1] = 0;
        param_1[2] = 0;
      }
      param_1 = param_1 + 3;
    } while (param_1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18058 ; VA 0x00997a40 ; FUN_00997a40 */

void FUN_00997a40(undefined4 param_1)

{
  FUN_00997ac0();
  FUN_01674ea0(param_1,0x20);
  return;
}



/* FUNCTION 18059 ; VA 0x00997a60 ; thunk_FUN_00999de0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00999de0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d2016;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee379c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee379c);
    if (DAT_01ee379c == -1) {
      uStack_8 = 0;
      FUN_009ca470("RenderPriority");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee3738 = RBX::Reflection::EnumDesc<enum_RBX::RunService::RenderPriority>::vftable;
      FUN_009caf20(&DAT_01d64950,5);
      FUN_016f3654(&LAB_01886280);
      FUN_016f37bf(&DAT_01ee379c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee3738;
}



/* FUNCTION 18060 ; VA 0x00997a70 ; FUN_00997a70 */

void FUN_00997a70(int *param_1)

{
  char cVar1;
  int *piVar2;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  while (cVar1 == '\0') {
    FUN_00997a70(param_1[2]);
    piVar2 = (int *)*param_1;
    FUN_00997ac0();
    FUN_01674ea0(param_1,0x20);
    param_1 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  return;
}



/* FUNCTION 18061 ; VA 0x00997ac0 ; FUN_00997ac0 */

void __fastcall FUN_00997ac0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_009957d0(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x38) * 0x38;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 18062 ; VA 0x00997b40 ; FUN_00997b40 */

void __fastcall FUN_00997b40(undefined4 *param_1)

{
  void **ppvVar1;
  undefined4 *puVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int *piVar6;
  int *piVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  piVar6 = (int *)*param_1;
  if (piVar6 != (int *)0x0) {
    piVar7 = (int *)param_1[1];
    ExceptionList = &pvStack_10;
    ppvVar1 = &pvStack_10;
    if (piVar6 != piVar7) {
      do {
        puVar4 = (undefined4 *)*piVar6;
        if (puVar4 != (undefined4 *)0x0) {
          puVar5 = (undefined4 *)piVar6[1];
          if (puVar4 != puVar5) {
            do {
              uVar3 = puVar4[3];
              uStack_8 = 0;
              if ((uVar3 & 0xfffffff8) != 0) {
                if ((~(byte)((int)uVar3 >> 2) & 1) == 0) {
                  puVar2 = puVar4;
                  if (((int)uVar3 >> 1 & 1U) == 0) {
                    puVar2 = (undefined4 *)*puVar4;
                  }
                  (**(code **)((uVar3 & 0xfffffff8) + 8))(puVar2);
                }
                if (((int)uVar3 >> 1 & 1U) == 0) {
                  FUN_01674ee0(*puVar4);
                }
              }
              puVar4 = puVar4 + 4;
              uStack_8 = 0xffffffff;
            } while (puVar4 != puVar5);
            puVar4 = (undefined4 *)*piVar6;
          }
          uVar3 = piVar6[2] - (int)puVar4 & 0xfffffff0;
          puVar5 = puVar4;
          if (0xfff < uVar3) {
            puVar5 = (undefined4 *)puVar4[-1];
            uVar3 = uVar3 + 0x23;
            if (0x1f < (uint)((int)puVar4 + (-4 - (int)puVar5))) goto LAB_00997cac;
          }
          FUN_01674ea0(puVar5,uVar3);
          *piVar6 = 0;
          piVar6[1] = 0;
          piVar6[2] = 0;
        }
        piVar6 = piVar6 + 3;
      } while (piVar6 != piVar7);
      piVar6 = (int *)*param_1;
      ppvVar1 = (void **)ExceptionList;
    }
    ExceptionList = ppvVar1;
    uVar3 = ((param_1[2] - (int)piVar6) / 0xc) * 0xc;
    piVar7 = piVar6;
    if (0xfff < uVar3) {
      piVar7 = (int *)piVar6[-1];
      uVar3 = uVar3 + 0x23;
      if (0x1f < (uint)((int)piVar6 + (-4 - (int)piVar7))) {
LAB_00997cac:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar7,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18063 ; VA 0x00997cc0 ; FUN_00997cc0 */

undefined4 * __thiscall
FUN_00997cc0(undefined4 param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void **ppvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d1d70;
  pvStack_10 = ExceptionList;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  ppvVar4 = &pvStack_10;
  if (param_2 != param_3) {
    do {
      param_4[4] = 0;
      param_4[5] = 0;
      uVar1 = param_2[1];
      uVar2 = param_2[2];
      uVar3 = param_2[3];
      *param_4 = *param_2;
      param_4[1] = uVar1;
      param_4[2] = uVar2;
      param_4[3] = uVar3;
      *(undefined8 *)(param_4 + 4) = *(undefined8 *)(param_2 + 4);
      param_2[4] = 0;
      param_2[5] = 0xf;
      *(undefined *)param_2 = 0;
      uStack_8 = 1;
      FUN_00d88580(param_2 + 6);
      param_4 = param_4 + 0xe;
      param_2 = param_2 + 0xe;
      ppvVar4 = (void **)ExceptionList;
    } while (param_2 != param_3);
  }
  ExceptionList = ppvVar4;
  uStack_8 = 0;
  FUN_009957d0(param_4,param_4,param_1);
  ExceptionList = pvStack_10;
  return param_4;
}



/* FUNCTION 18064 ; VA 0x00997d80 ; FUN_00997d80 */

float10 __fastcall FUN_00997d80(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  double dVar4;
  float fVar5;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  
  fVar5 = 0.0;
  piVar1 = (int *)(param_1 + 0x128);
  if ((*(int *)(param_1 + 0x138) == 0) || (*(int *)(param_1 + 0x130) == 0)) {
    uStack_1c = 0;
    uStack_18 = 0;
  }
  else {
    if ((*(int *)(param_1 + 0x134) - *piVar1) / 0x18 < 1) {
      iVar3 = 1 - (*(int *)(param_1 + 300) - *piVar1) / 0x18;
    }
    else {
      iVar3 = 1;
    }
    iVar3 = *(int *)(param_1 + 0x134) + iVar3 * -0x18;
    uStack_1c = *(undefined4 *)(iVar3 + 8);
    uStack_18 = *(undefined4 *)(iVar3 + 0xc);
  }
  dVar4 = DAT_018c0d60;
  if ((*(int *)(param_1 + 0x138) != 0) && (iVar3 = *(int *)(param_1 + 0x130), iVar3 != 0)) {
    iVar2 = iVar3;
    do {
      fVar5 = fVar5 + *(float *)(iVar2 + 0x10);
      iVar2 = iVar2 + 0x18;
      if (iVar2 == *(int *)(param_1 + 300)) {
        iVar2 = *piVar1;
      }
    } while ((iVar2 != *(int *)(param_1 + 0x134)) && (iVar2 != 0));
    if (iVar3 != 0) {
      dVar4 = (double)CONCAT44(uStack_18,uStack_1c) - **(double **)(param_1 + 0x130);
    }
  }
  if (DAT_01d67c90 == '\0') {
    return (float10)((fVar5 / (float)dVar4) * DAT_018c0ff0);
  }
  return (float10)((float)*(int *)(*(int *)(*(int *)(*(int *)(param_1 + 0x11c) + 0x1b8) + 0x1b4) +
                                  0x5fc) * (fVar5 / (float)dVar4));
}



/* FUNCTION 18065 ; VA 0x00997ed0 ; FUN_00997ed0 */

void __thiscall FUN_00997ed0(int param_1,uint param_2)

{
  uint *puVar1;
  uint *puVar2;
  uint *puVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint *puVar7;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  uint uStack_50;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  undefined4 uStack_40;
  uint uStack_3c;
  undefined auStack_38 [32];
  uint *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d1da8;
  pvStack_10 = ExceptionList;
  puVar1 = *(uint **)(param_1 + 0x88);
  uStack_8 = 1;
  puVar2 = (uint *)puVar1[1];
  puVar7 = puVar1;
  if (*(char *)((int)puVar2 + 0xd) == '\0') {
    do {
      if ((int)puVar2[4] < (int)in_stack_0000001c) {
        puVar3 = (uint *)puVar2[2];
      }
      else {
        puVar3 = (uint *)*puVar2;
        puVar7 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((int)puVar3 + 0xd) == '\0');
    if ((puVar7 != puVar1) &&
       (ExceptionList = &pvStack_10, (int)puVar7[4] <= (int)in_stack_0000001c)) goto LAB_00997f5b;
  }
  puStack_18 = &stack0x0000001c;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00995790(&DAT_018bdeda,&puStack_18,&uStack_11);
  FUN_00995ef0(&puStack_18,puVar7,iVar4 + 0x10,iVar4);
  puVar7 = puStack_18;
LAB_00997f5b:
  FUN_0054ef60(&param_2);
  uStack_8._0_1_ = 2;
  FUN_00d88580(&stack0x00000020);
  puVar1 = (uint *)puVar7[6];
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if ((uint *)puVar7[7] == puVar1) {
    FUN_00995b60(puVar1,&uStack_50);
  }
  else {
    puVar1[4] = 0;
    puVar1[5] = 0;
    *puVar1 = uStack_50;
    puVar1[1] = uStack_4c;
    puVar1[2] = uStack_48;
    puVar1[3] = uStack_44;
    *(ulonglong *)(puVar1 + 4) = CONCAT44(uStack_3c,uStack_40);
    uStack_40 = 0;
    uStack_3c = 0xf;
    uStack_50 = uStack_50 & 0xffffff00;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    puStack_18 = puVar1;
    FUN_00d88580(auStack_38);
    puVar7[6] = puVar7[6] + 0x38;
  }
  FUN_00d88a30();
  if (0xf < uStack_3c) {
    uVar6 = uStack_3c + 1;
    uVar5 = uStack_50;
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(uStack_50 - 4);
      uVar6 = uStack_3c + 0x24;
      if (0x1f < (uStack_50 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  if (0xf < in_stack_00000018) {
    uVar6 = in_stack_00000018 + 1;
    uVar5 = param_2;
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(param_2 - 4);
      uVar6 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  FUN_00d88a30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18066 ; VA 0x00998080 ; FUN_00998080 */

undefined4 * __thiscall
FUN_00998080(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017d1dd0;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
  }
  else {
    ExceptionList = &pvStack_10;
    (**(code **)(param_1 + 0x38))(1);
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    uStack_18 = param_4;
    piStack_14 = param_5;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00915c50(param_2,&uStack_18);
    piVar2 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_14[1] + -1;
      piStack_14[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar2 = param_5 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18067 ; VA 0x00998160 ; FUN_00998160 */

undefined4 * FUN_00998160(undefined4 *param_1,int param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017d1dd0;
  uStack_8 = 0;
  if (param_2 == 0) {
    ExceptionList = &pvStack_10;
    *param_1 = 0;
  }
  else {
    ExceptionList = &pvStack_10;
    if (param_4 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    uStack_18 = param_3;
    piStack_14 = param_4;
    uStack_8 = 1;
    FUN_00915c50(param_1,&uStack_18);
    piVar2 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_14[1] + -1;
      piStack_14[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar3 = param_4[1] + -1;
    param_4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar2 = param_4 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18068 ; VA 0x00998240 ; FUN_00998240 */

undefined4 * __thiscall
FUN_00998240(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d1e11;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00998900;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18069 ; VA 0x009983e0 ; FUN_009983e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_009983e0(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_00999de0();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01ee37ac) {
      FUN_016f3809(&DAT_01ee37ac);
      if (DAT_01ee37ac == -1) {
        _DAT_01ee37a0 = FUN_005c65e0;
        _DAT_01ee37a4 = FUN_005c65e0;
        _DAT_01ee37a8 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ee37ac);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01ee37a0) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01ee37a0;
  }
  return;
}



/* FUNCTION 18070 ; VA 0x009984a0 ; FUN_009984a0 */

void FUN_009984a0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00999de0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18071 ; VA 0x009984e0 ; FUN_009984e0 */

void FUN_009984e0(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  if (param_1 != 0) {
    uVar2 = param_2 * 0x18;
    iVar1 = param_1;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  return;
}



/* FUNCTION 18072 ; VA 0x00998530 ; FUN_00998530 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00998530(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  undefined *puStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1ec8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_005c13e0(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar4;
    iStack_e8 = FUN_005c9cc0();
    puVar4 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088c8c0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x48);
  if (iVar1 == 0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    uStack_28c = FUN_00d88470();
    puStack_288 = (undefined *)0x0;
    FUN_00d88580(iVar1);
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee047c)
       && (FUN_016f3809(&DAT_01ee047c), DAT_01ee047c == -1)) {
      _DAT_01ee0470 = FUN_008c9370;
      _DAT_01ee0474 = FUN_008c9370;
      DAT_01ee0478 = FUN_008ca540;
      FUN_016f37bf(&DAT_01ee047c);
    }
    puStack_288 = &DAT_01ee0470;
    puVar4 = &uStack_28c;
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_00d88470();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 0x10) != 0) && (uStack_8 = 0xb, puStack_288 != (undefined *)0x0)) {
    (**(code **)(puStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18073 ; VA 0x00998890 ; FUN_00998890 */

void __fastcall FUN_00998890(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  uVar2 = 0;
  if (param_1[4] != 0) {
    do {
      param_1[2] = param_1[2] + 0x18;
      uVar2 = uVar2 + 1;
      if (param_1[2] == param_1[1]) {
        param_1[2] = *param_1;
      }
    } while (uVar2 < (uint)param_1[4]);
  }
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[1] - iVar1) / 0x18) * 0x18;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  return;
}



/* FUNCTION 18074 ; VA 0x00998900 ; FUN_00998900 */

void FUN_00998900(int param_1,undefined8 param_2,undefined8 param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined8 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined8 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8524;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_1c0 = FUN_0088ca00();
  uStack_1bc = 0;
  uStack_1b8 = param_2;
  uStack_1bc = FUN_00630890();
  iStack_8._0_1_ = 1;
  uStack_f0 = FUN_0088ca00();
  uStack_ec = 0;
  uStack_e8 = param_3;
  uStack_ec = FUN_00630890();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,piVar1);
  iStack_8._0_1_ = 3;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 4;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  iStack_8 = 5;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18075 ; VA 0x00998a30 ; FUN_00998a30 */

undefined4 FUN_00998a30(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  int iStack_98;
  undefined *puStack_94;
  undefined4 uStack_90;
  int iStack_8c;
  undefined4 uStack_88;
  int iStack_84;
  int iStack_80;
  undefined4 uStack_7c;
  undefined auStack_6c [32];
  uint auStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  undefined *puStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017d1ef8;
  pvStack_1c = ExceptionList;
  uStack_7c = param_2;
  iStack_80 = 0x998a6c;
  ExceptionList = &pvStack_1c;
  iVar1 = FUN_01256300();
  puStack_94 = auStack_6c;
  iStack_80 = (int)pcStack_28 + 0x48;
  iVar1 = iVar1 - param_3;
  uStack_88 = 3;
  iStack_8c = param_3;
  uStack_90 = param_2;
  iStack_98 = 0x998a8a;
  iStack_84 = iVar1;
  uStack_2c = FUN_009d1820();
  iStack_98 = (int)pcStack_28 + 0x44;
  uStack_14 = 0;
  uStack_30 = FUN_009d05b0(param_2,param_3,2,iVar1);
  uVar2 = FUN_009d09d0(auStack_4c,param_2,param_3,1,iVar1,(int)pcStack_28 + 0x40);
  puStack_34 = (undefined *)&iStack_98;
  uStack_14._0_1_ = 1;
  pcStack_28 = *(code **)((int)pcStack_28 + 0x38);
  FUN_00d88580(uStack_2c);
  uStack_14._0_1_ = 2;
  FUN_0054ef60(uVar2);
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  (*pcStack_28)();
  if (0xf < uStack_38) {
    uVar4 = uStack_38 + 1;
    uVar3 = auStack_4c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_4c[0] - 4);
      uVar4 = uStack_38 + 0x24;
      if (0x1f < (auStack_4c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  FUN_00d88a30();
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 18076 ; VA 0x00998b70 ; FUN_00998b70 */

void __thiscall FUN_00998b70(int param_1,undefined4 param_2,int *param_3)

{
  undefined8 uVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  param_3 = (int *)*param_3;
  iVar2 = *param_3;
  iVar3 = FUN_0088ca00();
  if (iVar2 == iVar3) {
    piVar4 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar4 = (int *)0x0;
    }
    uVar1 = *(undefined8 *)piVar4;
    (**(code **)(param_1 + 0x38))(1);
    FUN_008ec650(uVar1);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18077 ; VA 0x00998be0 ; FUN_00998be0 */

void FUN_00998be0(undefined4 param_1,int *param_2)

{
  undefined8 uVar1;
  int iVar2;
  int iVar3;
  undefined8 *puVar4;
  int iVar5;
  int *piVar6;
  
  iVar2 = *param_2;
  iVar5 = *(int *)(iVar2 + 0xd0);
  iVar3 = FUN_0088ca00();
  if (iVar5 == iVar3) {
    puVar4 = (undefined8 *)(iVar2 + 0xd8);
    param_2 = (int *)*param_2;
    if (*(int *)(iVar2 + 0xd4) == 0) {
      puVar4 = (undefined8 *)0x0;
    }
    iVar2 = *param_2;
    uVar1 = *puVar4;
    iVar5 = FUN_0088ca00();
    if (iVar2 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
      FUN_00997390(*(undefined8 *)piVar6,uVar1);
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0();
}



/* FUNCTION 18078 ; VA 0x00998c80 ; FUN_00998c80 */

void __thiscall FUN_00998c80(int param_1,double param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined uVar6;
  char cVar7;
  int iVar8;
  int *piVar9;
  undefined4 uVar10;
  int *piVar11;
  double dVar12;
  undefined8 uVar13;
  undefined8 uVar14;
  undefined1 *puVar15;
  undefined8 uVar16;
  undefined8 uStack_24;
  int iStack_1c;
  int iStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1f88;
  pvStack_10 = ExceptionList;
  iStack_1c = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  if ((*(int *)(iStack_1c + 0x34) < DAT_01ee34c8) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(), DAT_01ee34c8 == -1)) {
    uVar14 = 0xffffffff01937614;
    uStack_8 = 0;
    puVar15 = &DAT_018cb3fc;
    uVar13 = FUN_0152dab0();
    DAT_01ee34c4 = (undefined4)((ulonglong)uVar13 >> 0x20);
    DAT_01ee34c0 = (undefined4)uVar13;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01ee34c8,puVar15,uVar14);
  }
  uVar3 = DAT_01ee34c4;
  uVar2 = DAT_01ee34c0;
  uVar13 = FUN_0152d930(DAT_01ee34c0,DAT_01ee34c4);
  dVar12 = *(double *)(param_1 + 0x70) + param_2;
  uStack_8 = 1;
  *(double *)(param_1 + 0x70) = dVar12;
  fStack_14 = (float)dVar12;
  if (DAT_01d6e9b0 != '\0') {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar8 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8) <=
       (uint)*(ushort *)(iVar8 + 0x1da))) {
      FUN_005789c0(&DAT_01ee0be0,&LAB_008e0ef0);
      FUN_008e4120();
      piVar9 = (int *)FUN_008aa140();
      if (*piVar9 == 0) {
        uVar10 = FUN_00e8c140();
        piVar11 = (int *)FUN_008a9ba0(&uStack_24,uVar10);
        iVar1 = *piVar11;
        iVar8 = piVar11[1];
        *piVar11 = 0;
        piVar11[1] = 0;
        *piVar9 = iVar1;
        piVar11 = (int *)piVar9[1];
        piVar9[1] = iVar8;
        if (piVar11 != (int *)0x0) {
          LOCK();
          iVar1 = piVar11[1] + -1;
          piVar11[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar11)();
            LOCK();
            iVar1 = piVar11[2] + -1;
            piVar11[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar11 + 4))();
            }
          }
        }
        if (uStack_24._4_4_ != (int *)0x0) {
          LOCK();
          iVar1 = uStack_24._4_4_[1] + -1;
          uStack_24._4_4_[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*uStack_24._4_4_)();
            LOCK();
            piVar11 = uStack_24._4_4_ + 2;
            iVar1 = *piVar11;
            *piVar11 = *piVar11 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*uStack_24._4_4_ + 4))();
            }
          }
        }
      }
      if (*piVar9 != 0) {
        FUN_00e944a0(param_2);
      }
    }
  }
  if ((*(int *)(iStack_1c + 0x34) < DAT_01ee34d8) && (FUN_016f3809(), DAT_01ee34d8 == -1)) {
    uVar16 = 0xffffffff01937620;
    uStack_8._0_1_ = 2;
    puVar15 = &DAT_018cb3fc;
    uVar14 = FUN_0152dab0();
    DAT_01ee34d4 = (undefined4)((ulonglong)uVar14 >> 0x20);
    DAT_01ee34d0 = (undefined4)uVar14;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_016f37bf(&DAT_01ee34d8,puVar15,uVar16);
  }
  uVar10 = DAT_01ee34d4;
  uStack_24._4_4_ = (int *)DAT_01ee34d0;
  uVar14 = FUN_0152d930(DAT_01ee34d0,DAT_01ee34d4);
  uStack_8._0_1_ = 3;
  FUN_005e6780();
  uStack_8._0_1_ = 4;
  FUN_0152dda0(uStack_24._4_4_,uVar10,uVar14);
  iVar1 = iStack_1c;
  uStack_8._0_1_ = 1;
  uVar6 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if ((*(int *)(iStack_1c + 0x34) < DAT_01ee34e8) &&
     (uStack_8._0_1_ = uVar6, FUN_016f3809(), DAT_01ee34e8 == -1)) {
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    uVar14 = FUN_0152dab0();
    if (DAT_01d7ad40 != '\0') {
      FUN_01532a30(uVar14);
    }
    uStack_8._0_1_ = 1;
    DAT_01ee34e0 = (int)uVar14;
    DAT_01ee34e4 = (int)((ulonglong)uVar14 >> 0x20);
    FUN_016f37bf();
  }
  uVar10 = DAT_01ee34e0;
  iStack_1c = DAT_01ee34e4;
  uStack_24 = FUN_01532c80(DAT_01ee34e0,DAT_01ee34e4);
  uStack_8._0_1_ = 6;
  FUN_00f94340();
  iVar8 = iStack_18;
  FUN_005e6780();
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_0152dda0(uVar10,iStack_1c,uStack_24);
  if (DAT_01d7ad40 != '\0') {
    FUN_01532d10(uVar10,iStack_1c,uStack_24);
  }
  uStack_8._0_1_ = 1;
  if (*(int *)(iVar1 + 0x34) < DAT_01ee34f8) {
    FUN_016f3809();
    if (DAT_01ee34f8 == -1) {
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      uVar14 = FUN_0152dab0();
      uStack_24._4_4_ = (int *)((ulonglong)uVar14 >> 0x20);
      if (DAT_01d7ad40 != '\0') {
        FUN_01532a30(uVar14);
      }
      uStack_8._0_1_ = 1;
      DAT_01ee34f0 = (int)uVar14;
      DAT_01ee34f4 = uStack_24._4_4_;
      FUN_016f37bf();
    }
  }
  uVar10 = DAT_01ee34f0;
  iStack_1c = DAT_01ee34f4;
  uVar14 = FUN_01532c80(DAT_01ee34f0,DAT_01ee34f4);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  uStack_24 = uVar14;
  cVar7 = FUN_00f94340();
  if ((cVar7 == '\0') || (*(int *)(iVar8 + 0xb8) == 0)) {
    FUN_005e6780();
  }
  else {
    FUN_00f93b90();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  FUN_0152dda0(uVar10,iStack_1c,uStack_24);
  if (DAT_01d7ad40 != '\0') {
    FUN_01532d10(uVar10,iStack_1c,uStack_24);
  }
  uStack_8._0_1_ = 1;
  if (*(int *)(iVar1 + 0x34) < DAT_01ee3508) {
    FUN_016f3809();
    if (DAT_01ee3508 == -1) {
      uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
      uVar14 = FUN_0152dab0();
      uStack_24._4_4_ = (int *)((ulonglong)uVar14 >> 0x20);
      if (DAT_01d7ad40 != '\0') {
        FUN_01532a30(uVar14);
      }
      uStack_8._0_1_ = 1;
      DAT_01ee3500 = (int)uVar14;
      DAT_01ee3504 = uStack_24._4_4_;
      FUN_016f37bf();
    }
  }
  uVar10 = DAT_01ee3500;
  iStack_1c = DAT_01ee3504;
  uVar14 = FUN_01532c80(DAT_01ee3500,DAT_01ee3504);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  uStack_24 = uVar14;
  if ((DAT_01d6fc20 == '\0') || (*(int *)(iVar8 + 0xbc) == 0)) {
    FUN_005e6780();
  }
  else {
    FUN_00f947d0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  FUN_0152dda0(uVar10,iStack_1c,uStack_24);
  if (DAT_01d7ad40 != '\0') {
    FUN_01532d10(uVar10,iStack_1c,uStack_24);
  }
  uStack_8._0_1_ = 1;
  if (*(int *)(iVar1 + 0x34) < DAT_01ee3518) {
    FUN_016f3809();
    if (DAT_01ee3518 == -1) {
      uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
      uVar14 = FUN_0152dab0();
      if (DAT_01d7ad40 != '\0') {
        FUN_01532a30(uVar14);
      }
      uStack_8._0_1_ = 1;
      DAT_01ee3510 = (int)uVar14;
      DAT_01ee3514 = (int)((ulonglong)uVar14 >> 0x20);
      FUN_016f37bf();
    }
  }
  uVar4 = DAT_01ee3514;
  uVar10 = DAT_01ee3510;
  uVar14 = FUN_01532c80(DAT_01ee3510,DAT_01ee3514);
  uStack_8._0_1_ = 0xf;
  uStack_24 = uVar14;
  FUN_00997390((double)fStack_14,param_2);
  uVar5 = (undefined4)uStack_24;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
  FUN_0152dda0(uVar10,uVar4,uStack_24);
  if (DAT_01d7ad40 != '\0') {
    FUN_01532d10(uVar10,uVar4,uVar5,uStack_24._4_4_);
  }
  uStack_8 = 0x11;
  FUN_0152dda0(uVar2,uVar3,uVar13);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18079 ; VA 0x009993d0 ; FUN_009993d0 */

undefined4 FUN_009993d0(undefined4 param_1)

{
  FUN_00f90c30(param_1);
  return param_1;
}



/* FUNCTION 18080 ; VA 0x009993f0 ; FUN_009993f0 */

undefined __fastcall FUN_009993f0(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_008f7870(param_1);
  if (iVar1 == 0) {
    return false;
  }
  if (DAT_01d64948 == '\0') {
    iVar2 = FUN_008fbd40();
    if (iVar2 == 1) {
      return *(undefined *)(iVar1 + 0x448);
    }
  }
  iVar1 = FUN_008fbd40();
  return iVar1 == 3;
}



/* FUNCTION 18081 ; VA 0x00999430 ; FUN_00999430 */

int __thiscall FUN_00999430(int param_1,char param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined auStack_10 [12];
  
  uVar2 = FUN_01255560();
  cVar1 = FUN_01255580(uVar2,1);
  if ((cVar1 == '\0') && (param_2 != '\0')) {
    cVar1 = FUN_0097c970(param_1,1);
    if (cVar1 == '\0') {
      FUN_00550130("RenderStepped event can only be used from local scripts");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_10,&DAT_01c17198);
    }
  }
  return param_1 + 0xe4;
}



/* FUNCTION 18082 ; VA 0x00999490 ; FUN_00999490 */

undefined4 FUN_00999490(undefined4 param_1)

{
  FUN_00912100(param_1);
  return param_1;
}



/* FUNCTION 18083 ; VA 0x009994b0 ; FUN_009994b0 */

float10 __fastcall FUN_009994b0(int param_1)

{
  if (*(int *)(param_1 + 0x60) == 0) {
    return (float10)0;
  }
  return (float10)*(double *)(*(int *)(param_1 + 0x60) + 0x70);
}



/* FUNCTION 18084 ; VA 0x009994c0 ; FUN_009994c0 */

float10 __fastcall FUN_009994c0(int param_1)

{
  int iVar1;
  double *pdVar2;
  double dVar3;
  double dVar4;
  undefined auStack_14 [16];
  
  iVar1 = *(int *)(param_1 + 0x60);
  if (iVar1 == 0) {
    return (float10)0;
  }
  pdVar2 = (double *)FUN_016827a0(auStack_14);
  dVar3 = *(double *)(iVar1 + 0xa8);
  dVar4 = *pdVar2 - *(double *)(iVar1 + 0x88);
  if (((*(char **)(iVar1 + 0xc0) == (char *)0x0) || (**(char **)(iVar1 + 0xc0) == '\0')) &&
     (dVar3 + dVar3 < dVar4)) {
    dVar3 = dVar4;
  }
  if (NAN(dVar3) == (dVar3 == 0.0)) {
    return (float10)(*(double *)(iVar1 + 0x70) / dVar3);
  }
  return (float10)(0.0 < *(double *)(iVar1 + 0x70));
}



/* FUNCTION 18085 ; VA 0x009994d0 ; FUN_009994d0 */

float10 __fastcall FUN_009994d0(int param_1)

{
  int iVar1;
  double *pdVar2;
  double dVar3;
  double dVar4;
  undefined auStack_14 [16];
  
  iVar1 = *(int *)(param_1 + 0x60);
  if (iVar1 == 0) {
    return (float10)0;
  }
  pdVar2 = (double *)FUN_016827a0(auStack_14);
  dVar3 = *(double *)(iVar1 + 0xa8);
  dVar4 = *pdVar2 - *(double *)(iVar1 + 0x88);
  if (((*(char **)(iVar1 + 0xc0) == (char *)0x0) || (**(char **)(iVar1 + 0xc0) == '\0')) &&
     (dVar3 + dVar3 < dVar4)) {
    dVar3 = dVar4;
  }
  dVar4 = 0.0;
  if (0.0 < dVar3) {
    dVar4 = DAT_018c0d60 / dVar3;
  }
  return (float10)dVar4;
}



/* FUNCTION 18086 ; VA 0x009994f0 ; FUN_009994f0 */

undefined4 __fastcall FUN_009994f0(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_008f7870(param_1);
  if (iVar1 != 0) {
    uVar2 = FUN_008ff0a0();
    return uVar2;
  }
  return 0;
}



/* FUNCTION 18087 ; VA 0x00999530 ; FUN_00999530 */

void FUN_00999530(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00999de0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18088 ; VA 0x00999570 ; FUN_00999570 */

undefined4 * __thiscall FUN_00999570(int param_1,int param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 uVar6;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 0x58) != 0) {
      ExceptionList = &pvStack_10;
      if (*(int *)(param_1 + 0x5c) != 0) {
        LOCK();
        piVar1 = (int *)(*(int *)(param_1 + 0x5c) + 4);
        ExceptionList = &pvStack_10;
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_00628870(*(undefined4 *)(param_1 + 0x58),*(undefined4 *)(param_1 + 0x5c));
      *(undefined4 *)(param_1 + 0x58) = 0;
      piVar1 = *(int **)(param_1 + 0x5c);
      *(undefined4 *)(param_1 + 0x5c) = 0;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar5 = piVar1[1] + -1;
        piVar1[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar5 = piVar1[2] + -1;
          piVar1[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
    }
    if (*(int *)(param_1 + 0x60) != 0) {
      if (*(int *)(param_1 + 100) != 0) {
        LOCK();
        piVar1 = (int *)(*(int *)(param_1 + 100) + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_00628870(*(undefined4 *)(param_1 + 0x60),*(undefined4 *)(param_1 + 100));
      *(undefined4 *)(param_1 + 0x60) = 0;
      piVar1 = *(int **)(param_1 + 100);
      *(undefined4 *)(param_1 + 100) = 0;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar5 = piVar1[1] + -1;
        piVar1[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar5 = piVar1[2] + -1;
          piVar1[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
    }
    piVar1 = (int *)(param_1 + 0x88);
    iVar5 = *piVar1;
    uStack_8 = 0;
    FUN_00997a70(*(undefined4 *)(iVar5 + 4));
    uStack_8 = 0xffffffff;
    *(int *)(*piVar1 + 4) = iVar5;
    *(int *)*piVar1 = iVar5;
    *(int *)(*piVar1 + 8) = iVar5;
    *(undefined4 *)(param_1 + 0x8c) = 0;
    *(undefined4 *)(param_1 + 0xac) = 0;
    piVar1 = *(int **)(param_1 + 0xb0);
    *(undefined4 *)(param_1 + 0xb0) = 0;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar5 = piVar1[2] + -1;
      piVar1[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  puVar4 = (undefined4 *)FUN_008a4210(param_2,param_3);
  if (param_3 != 0) {
    iVar5 = FUN_008f7870(param_3);
    if (iVar5 != 0) {
      *(bool *)(param_1 + 0xb4) = *(int *)(iVar5 + 0x4a0) != 2;
    }
    uVar6 = FUN_006348f0();
    puVar4 = (undefined4 *)FUN_0060e0c0(auStack_18,uVar6);
    uVar6 = *puVar4;
    uVar3 = puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    *(undefined4 *)(param_1 + 0xac) = uVar6;
    piVar1 = *(int **)(param_1 + 0xb0);
    *(undefined4 *)(param_1 + 0xb0) = uVar3;
    if (piVar1 != (int *)0x0) {
      LOCK();
      piVar2 = piVar1 + 2;
      iVar5 = *piVar2;
      puVar4 = (undefined4 *)*piVar2;
      *piVar2 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        puVar4 = (undefined4 *)(**(code **)(*piVar1 + 4))();
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        puVar4 = (undefined4 *)(**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 18089 ; VA 0x00999780 ; FUN_00999780 */

void __fastcall FUN_00999780(int param_1)

{
  char cVar1;
  
  cVar1 = FUN_00983210(param_1);
  if ((cVar1 == '\0') && (*(int *)(param_1 + 0x68) == 1)) {
    *(undefined4 *)(param_1 + 0x68) = 2;
    FUN_00997470(1,2);
  }
  return;
}



/* FUNCTION 18090 ; VA 0x009997b0 ; FUN_009997b0 */

float10 __fastcall FUN_009997b0(int param_1)

{
  if (*(int *)(param_1 + 0x58) == 0) {
    return (float10)0;
  }
  return (float10)*(double *)(*(int *)(param_1 + 0x58) + 0x70);
}



/* FUNCTION 18091 ; VA 0x009997c0 ; FUN_009997c0 */

float10 __fastcall FUN_009997c0(int param_1)

{
  int iVar1;
  double *pdVar2;
  double dVar3;
  double dVar4;
  undefined auStack_14 [16];
  
  iVar1 = *(int *)(param_1 + 0x58);
  if (iVar1 == 0) {
    return (float10)0;
  }
  pdVar2 = (double *)FUN_016827a0(auStack_14);
  dVar3 = *(double *)(iVar1 + 0xa8);
  dVar4 = *pdVar2 - *(double *)(iVar1 + 0x88);
  if (((*(char **)(iVar1 + 0xc0) == (char *)0x0) || (**(char **)(iVar1 + 0xc0) == '\0')) &&
     (dVar3 + dVar3 < dVar4)) {
    dVar3 = dVar4;
  }
  if (NAN(dVar3) == (dVar3 == 0.0)) {
    return (float10)(*(double *)(iVar1 + 0x70) / dVar3);
  }
  return (float10)(0.0 < *(double *)(iVar1 + 0x70));
}



/* FUNCTION 18092 ; VA 0x009997d0 ; FUN_009997d0 */

float10 __fastcall FUN_009997d0(undefined4 param_1)

{
  int iVar1;
  float10 fVar2;
  
  iVar1 = FUN_008f78c0(param_1);
  if (((iVar1 != 0) && (*(int *)(iVar1 + 0x1b8) != 0)) &&
     (*(int *)(*(int *)(iVar1 + 0x1b8) + 0x1b4) != 0)) {
    fVar2 = (float10)FUN_00bbd8f0();
    return fVar2;
  }
  return (float10)0;
}



/* FUNCTION 18093 ; VA 0x00999800 ; FUN_00999800 */

float10 __fastcall FUN_00999800(undefined4 param_1)

{
  int iVar1;
  float10 fVar2;
  
  iVar1 = FUN_008f78c0(param_1);
  if (iVar1 != 0) {
    fVar2 = (float10)FUN_008f7ba0();
    return fVar2 * (float10)DAT_018dbcc8;
  }
  return (float10)0;
}



/* FUNCTION 18094 ; VA 0x00999820 ; FUN_00999820 */

int __thiscall FUN_00999820(int param_1,double param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvVar6;
  int iVar7;
  undefined8 uVar8;
  int iStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1fd0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01ee347c != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774d0(DAT_01ee347c,"Heartbeat stepping: %4.4f",(float)param_2,0,0,0);
  }
  pvVar6 = ThreadLocalStoragePointer;
  iVar7 = _tls_index;
  *(double *)(param_1 + 0x80) = *(double *)(param_1 + 0x80) + param_2;
  piVar3 = *(int **)((int)pvVar6 + iVar7 * 4);
  if (piVar3[0xd] < DAT_01ee34a8) {
    FUN_016f3809();
    if (DAT_01ee34a8 == -1) {
      uStack_8 = 0;
      uVar8 = FUN_0152dab0("Heartbeat","heartbeatInternal",0xffffffff);
      DAT_01ee34a4 = (undefined4)((ulonglong)uVar8 >> 0x20);
      DAT_01ee34a0 = (undefined4)uVar8;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ee34a8);
    }
  }
  uVar5 = DAT_01ee34a4;
  uVar4 = DAT_01ee34a0;
  uVar8 = FUN_0152d930(DAT_01ee34a0,DAT_01ee34a4);
  uStack_8 = 1;
  FUN_005e6780();
  uStack_8 = 2;
  FUN_0152dda0(uVar4,uVar5,uVar8);
  uStack_8 = 0xffffffff;
  if (piVar3[0xd] < DAT_01ee34b8) {
    FUN_016f3809();
    if (DAT_01ee34b8 == -1) {
      uStack_8 = 3;
      uVar8 = FUN_0152dab0("Heartbeat","RunService.Heartbeat",0xffffffff);
      if (DAT_01d7ad40 != '\0') {
        FUN_01532a30(uVar8);
      }
      uStack_8 = 0xffffffff;
      DAT_01ee34b0 = (int)uVar8;
      DAT_01ee34b4 = (int)((ulonglong)uVar8 >> 0x20);
      FUN_016f37bf();
    }
  }
  uVar5 = DAT_01ee34b4;
  uVar4 = DAT_01ee34b0;
  uVar8 = FUN_01532c80(DAT_01ee34b0,DAT_01ee34b4);
  uStack_8 = 4;
  FUN_008ec650(param_2);
  uStack_8 = 5;
  iVar7 = FUN_0152dda0(uVar4,uVar5,uVar8);
  if (DAT_01d7ad40 != '\0') {
    iVar7 = FUN_01532d10(uVar4,uVar5,uVar8);
  }
  uStack_8 = 0xffffffff;
  if (*(char *)(param_1 + 0xb4) == '\0') {
    iVar7 = FUN_00587490();
    uStack_8 = 6;
    if (iStack_20 != 0) {
      iVar7 = FUN_00b9dd90();
    }
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 1;
      iVar2 = *piVar1;
      iVar7 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar7 = (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar7 = (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  *(undefined8 *)(param_1 + 0x78) = *(undefined8 *)(param_1 + 0x70);
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 18095 ; VA 0x00999b30 ; FUN_00999b30 */

void __fastcall FUN_00999b30(int param_1)

{
  *(undefined *)(param_1 + 0x90) = 1;
  return;
}



/* FUNCTION 18096 ; VA 0x00999b40 ; FUN_00999b40 */

void __thiscall FUN_00999b40(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0xa9) = param_2;
  return;
}



/* FUNCTION 18097 ; VA 0x00999b50 ; FUN_00999b50 */

void __thiscall FUN_00999b50(int param_1,int param_2)

{
  int iVar1;
  char cVar2;
  
  cVar2 = FUN_00983210(param_1);
  if (cVar2 == '\0') {
    if (param_2 == 1) {
      if ((*(int *)(param_1 + 0x68) != 0) && (*(int *)(param_1 + 0x68) != 2)) {
        return;
      }
      if (*(int *)(param_1 + 0x58) == 0) {
        FUN_00999ec0();
      }
    }
    else if (param_2 == 2) {
      if (*(int *)(param_1 + 0x68) != 1) {
        return;
      }
    }
    else if (param_2 == 0) {
      *(undefined8 *)(param_1 + 0x80) = 0;
      *(undefined4 *)(param_1 + 0x70) = 0;
      *(undefined4 *)(param_1 + 0x74) = 0;
      *(undefined4 *)(param_1 + 0x78) = 0;
      *(undefined4 *)(param_1 + 0x7c) = 0;
    }
    iVar1 = *(int *)(param_1 + 0x68);
    if (iVar1 != param_2) {
      *(int *)(param_1 + 0x68) = param_2;
      FUN_00997470(iVar1,param_2);
    }
  }
  return;
}



/* FUNCTION 18098 ; VA 0x00999bd0 ; FUN_00999bd0 */

void __thiscall FUN_00999bd0(int param_1,char param_2)

{
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  *(char *)(param_1 + 0x91) = param_2;
  if ((param_2 != '\0') && (*(char *)(param_1 + 0x92) != '\0')) {
    FUN_01682800(&uStack_c);
    *(undefined4 *)(param_1 + 0x98) = uStack_c;
    *(undefined4 *)(param_1 + 0x9c) = uStack_8;
  }
  return;
}



/* FUNCTION 18099 ; VA 0x00999c20 ; FUN_00999c20 */

void __thiscall FUN_00999c20(int *param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  undefined4 uVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 *puStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1fe8;
  pvStack_10 = ExceptionList;
  if (param_2 == (param_1[1] - *param_1) / 0x18) {
    return;
  }
  if (param_2 < 0xaaaaaab) {
    if (param_2 == 0) {
      puStack_1c = (undefined4 *)0x0;
      ExceptionList = &pvStack_10;
    }
    else {
      uVar7 = param_2 * 0x18;
      if (param_2 < 0xaaaaaab) {
        if (uVar7 < 0x1000) {
          if (uVar7 == 0) {
            puStack_1c = (undefined4 *)0x0;
            ExceptionList = &pvStack_10;
          }
          else {
            ExceptionList = &pvStack_10;
            puStack_1c = (undefined4 *)FUN_01674e20(uVar7);
          }
          goto LAB_00999ce1;
        }
      }
      else {
        uVar7 = 0xffffffff;
      }
      uVar4 = uVar7 + 0x23;
      if (uVar4 <= uVar7) {
        uVar4 = 0xffffffff;
      }
      ExceptionList = &pvStack_10;
      iVar5 = FUN_01674e20(uVar4);
      if (iVar5 == 0) goto LAB_00999dcf;
      puStack_1c = (undefined4 *)(iVar5 + 0x23U & 0xffffffe0);
      puStack_1c[-1] = iVar5;
    }
LAB_00999ce1:
    if (param_1[4] == 0) {
      puVar8 = (undefined4 *)0x0;
    }
    else {
      puVar8 = (undefined4 *)param_1[2];
    }
    uVar7 = param_2;
    if ((uint)param_1[4] < param_2) {
      uVar7 = param_1[4];
    }
    uStack_8 = 1;
    iVar5 = FUN_00997540(uVar7);
    puVar1 = *(undefined4 **)(iVar5 + 4);
    puVar10 = puStack_1c;
    while (puVar8 != puVar1) {
      if (puVar10 != (undefined4 *)0x0) {
        uVar6 = puVar8[1];
        uVar2 = puVar8[2];
        uVar3 = puVar8[3];
        *puVar10 = *puVar8;
        puVar10[1] = uVar6;
        puVar10[2] = uVar2;
        puVar10[3] = uVar3;
        uVar6 = puVar8[5];
        puVar10[4] = puVar8[4];
        puVar10[5] = uVar6;
      }
      puVar9 = puVar8 + 6;
      if (puVar9 == (undefined4 *)param_1[1]) {
        puVar9 = (undefined4 *)*param_1;
      }
      puVar8 = (undefined4 *)0x0;
      if (puVar9 != (undefined4 *)param_1[3]) {
        puVar8 = puVar9;
      }
      puVar10 = puVar10 + 6;
    }
    FUN_00998890();
    *param_1 = (int)puStack_1c;
    param_1[4] = ((int)puVar10 - (int)puStack_1c) / 0x18;
    param_1[2] = (int)puStack_1c;
    param_1[1] = (int)(puStack_1c + param_2 * 6);
    if (puVar10 != puStack_1c + param_2 * 6) {
      puStack_1c = puVar10;
    }
    param_1[3] = (int)puStack_1c;
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar6 = FUN_005e07c0("circular_buffer");
  uStack_8 = 0;
  FUN_005dffd0(uVar6);
LAB_00999dcf:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 18100 ; VA 0x00999d9e ; Catch_All@00999d9e */

void Catch_All_00999d9e(void)

{
  int unaff_EBP;
  
  FUN_009984e0(*(undefined4 *)(unaff_EBP + -0x1c),*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18101 ; VA 0x00999de0 ; FUN_00999de0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00999de0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d2016;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee379c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee379c);
    if (DAT_01ee379c == -1) {
      uStack_8 = 0;
      FUN_009ca470("RenderPriority");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee3738 = RBX::Reflection::EnumDesc<enum_RBX::RunService::RenderPriority>::vftable;
      FUN_009caf20(&DAT_01d64950,5);
      FUN_016f3654(&LAB_01886280);
      FUN_016f37bf(&DAT_01ee379c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee3738;
}



/* FUNCTION 18102 ; VA 0x00999e90 ; FUN_00999e90 */

float10 __fastcall FUN_00999e90(int param_1)

{
  float10 fVar1;
  
  if (*(int **)(param_1 + 0x58) != (int *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00999e9c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    fVar1 = (float10)(**(code **)(**(int **)(param_1 + 0x58) + 0x14))();
    return fVar1;
  }
  return (float10)0;
}



/* FUNCTION 18103 ; VA 0x00999eb0 ; FUN_00999eb0 */

float10 __fastcall FUN_00999eb0(int param_1)

{
  double dVar1;
  double dVar2;
  
  if (*(int *)(param_1 + 0x60) == 0) {
    return (float10)0;
  }
  dVar1 = *(double *)(*(int *)(param_1 + 0x60) + 0xa8);
  dVar2 = 0.0;
  if (0.0 < dVar1) {
    dVar2 = DAT_018c0d60 / dVar1;
  }
  return (float10)dVar2;
}



/* FUNCTION 18104 ; VA 0x00999ec0 ; FUN_00999ec0 */

int __fastcall FUN_00999ec0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piStack_40;
  undefined4 *puStack_3c;
  int iStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d20a6;
  pvStack_10 = ExceptionList;
  piStack_40 = (int *)0x999ee6;
  ExceptionList = &pvStack_10;
  puStack_3c = (undefined4 *)param_1;
  iVar2 = FUN_008f7870();
  if (iVar2 != 0) {
    if (DAT_01d635fc == '\0') {
      if (*(char *)(iVar2 + 0x249) != '\0') {
        puStack_3c = &iStack_24;
        piStack_40 = (int *)0x999f1d;
        FUN_00876b60();
        uStack_8 = 0;
        puStack_3c = (undefined4 *)0x999f2b;
        FUN_0090dcf0();
        uStack_8 = 0xffffffff;
        puStack_3c = (undefined4 *)0x999f3a;
        FUN_00550ad0();
      }
      if (*(char *)(iVar2 + 0x24a) != '\0') {
        puStack_3c = &iStack_24;
        piStack_40 = (int *)0x999f52;
        FUN_00876b60();
        uStack_8 = 1;
        puStack_3c = (undefined4 *)0x999f60;
        FUN_0090dcf0();
        uStack_8 = 0xffffffff;
        puStack_3c = (undefined4 *)0x999f6f;
        FUN_00550ad0();
      }
    }
    else {
      puStack_3c = (undefined4 *)0x999f03;
      FUN_0090dd40();
    }
    puStack_3c = (undefined4 *)0x3c;
    piStack_40 = (int *)0x999f76;
    piStack_14 = (int *)FUN_01674e20();
    uStack_8 = 2;
    if (piStack_14 == (int *)0x0) {
      uVar3 = 0;
    }
    else {
      puStack_3c = (undefined4 *)0x999f8e;
      uVar3 = FUN_00f935b0();
    }
    *(undefined4 *)(param_1 + 0xb8) = uVar3;
    uStack_8 = 0xffffffff;
    if (DAT_01d6fc20 != '\0') {
      puStack_3c = (undefined4 *)0x24;
      piStack_40 = (int *)0x999faf;
      piStack_14 = (int *)FUN_01674e20();
      uStack_8 = 3;
      if (piStack_14 == (int *)0x0) {
        uVar3 = 0;
      }
      else {
        puStack_3c = (undefined4 *)0x999fc7;
        uVar3 = FUN_00f943c0();
      }
      uStack_8 = 0xffffffff;
      *(undefined4 *)(param_1 + 0xbc) = uVar3;
    }
  }
  puStack_3c = (undefined4 *)
               (-(uint)(*(int *)(param_1 + 0x34) != 0) & *(int *)(param_1 + 0x34) + 4U);
  piStack_40 = &iStack_24;
  FUN_00944080();
  uStack_8 = 4;
  piStack_14 = (int *)FUN_01674e20(0x148);
  if (piStack_14 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piStack_20[1] = piStack_20[1] + 1;
      UNLOCK();
    }
    puStack_3c = (undefined4 *)0x5;
    uStack_8._0_1_ = 6;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piStack_20[1] = piStack_20[1] + 1;
      UNLOCK();
    }
    piStack_40 = piStack_20;
    FUN_00a360a0("Simulation",3,0,iStack_24);
    *piStack_14 = (int)RBX::PhysicsJob::vftable;
    piStack_14[0x4a] = 0;
    piStack_14[0x4b] = 0;
    piStack_14[0x4c] = 0;
    piStack_14[0x4d] = 0;
    piStack_14[0x4e] = 0;
    piStack_14[0x50] = 0;
    piStack_14[0x51] = 0;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piStack_20[2] = piStack_20[2] + 1;
      UNLOCK();
    }
    piStack_14[0x50] = iStack_24;
    piStack_14[0x51] = (int)piStack_20;
    puStack_3c = (undefined4 *)0x64;
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    piStack_40 = (int *)0x99a0c0;
    FUN_00999c20();
    piVar4 = piStack_14;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_20[1] + -1;
      piStack_20[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        puStack_3c = (undefined4 *)0x99a0d3;
        (**(code **)*piStack_20)();
        LOCK();
        iVar2 = piStack_20[2] + -1;
        piStack_20[2] = iVar2;
        UNLOCK();
        piVar4 = piStack_14;
        if (iVar2 == 0) {
          puStack_3c = (undefined4 *)0x99a0e3;
          (**(code **)(*piStack_20 + 4))();
          piVar4 = piStack_14;
        }
      }
    }
  }
  uStack_18 = 0;
  puStack_3c = (undefined4 *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  uStack_1c = 0;
  piStack_40 = piVar4;
  FUN_00996300();
  *(undefined4 *)(param_1 + 0x58) = uStack_1c;
  piStack_14 = *(int **)(param_1 + 0x5c);
  *(undefined4 *)(param_1 + 0x5c) = uStack_18;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_3c = (undefined4 *)0x99a12b;
      (**(code **)*piStack_14)();
      LOCK();
      iVar2 = piStack_14[2] + -1;
      piStack_14[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        puStack_3c = (undefined4 *)0x99a13c;
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  puStack_3c = (undefined4 *)0x138;
  piStack_40 = (int *)0x99a146;
  piStack_14 = (int *)FUN_01674e20();
  uStack_8._0_1_ = 10;
  if (piStack_14 == (int *)0x0) {
    piStack_40 = (int *)0x0;
  }
  else {
    FUN_0060dcd0(&piStack_40,param_1);
    piStack_40 = (int *)FUN_00996660();
  }
  uStack_18 = 0;
  puStack_3c = (undefined4 *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  uStack_1c = 0;
  FUN_00996210();
  *(undefined4 *)(param_1 + 0x60) = uStack_1c;
  piStack_14 = *(int **)(param_1 + 100);
  *(undefined4 *)(param_1 + 100) = uStack_18;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_3c = (undefined4 *)0x99a1b0;
      (**(code **)*piStack_14)();
      LOCK();
      iVar2 = piStack_14[2] + -1;
      piStack_14[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        puStack_3c = (undefined4 *)0x99a1c1;
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (*(int *)(param_1 + 0x5c) != 0) {
    LOCK();
    piVar4 = (int *)(*(int *)(param_1 + 0x5c) + 4);
    *piVar4 = *piVar4 + 1;
    UNLOCK();
  }
  piStack_40 = *(int **)(param_1 + 0x58);
  puStack_3c = *(undefined4 **)(param_1 + 0x5c);
  FUN_0151d950();
  if (*(int *)(param_1 + 100) != 0) {
    LOCK();
    piVar4 = (int *)(*(int *)(param_1 + 100) + 4);
    *piVar4 = *piVar4 + 1;
    UNLOCK();
  }
  piStack_40 = *(int **)(param_1 + 0x60);
  puStack_3c = *(undefined4 **)(param_1 + 100);
  iVar2 = FUN_0151d950();
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar4 = piStack_20 + 1;
    iVar1 = *piVar4;
    iVar2 = *piVar4;
    *piVar4 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      puStack_3c = (undefined4 *)0x99a22e;
      iVar2 = (**(code **)*piStack_20)();
      LOCK();
      piVar4 = piStack_20 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        puStack_3c = (undefined4 *)0x99a23d;
        iVar2 = (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 18105 ; VA 0x0099a250 ; FUN_0099a250 */

int FUN_0099a250(int param_1)

{
  int *piVar1;
  int iVar2;
  int iStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d20c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  if (iStack_24 != 0) {
    FUN_00587490();
    uStack_8._0_1_ = 1;
    if (iStack_1c == 0) {
      iStack_24 = 0;
    }
    else {
      if (DAT_01d6514b != '\0') {
        FUN_016774b0(DAT_01d6514b,"Heartbeat start, data model: %p",iStack_24);
      }
      FUN_008e9840();
      uStack_8._0_1_ = 2;
      FUN_00999820((double)(float)*(double *)(param_1 + 8));
      if (DAT_01d6514b != '\0') {
        FUN_016774b0(DAT_01d6514b,"Heartbeat finish, data model: %p",iStack_24);
      }
      iStack_24 = 1;
      FUN_008eb130();
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[1] + -1;
      piStack_18[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar2 = piStack_18[2] + -1;
        piStack_18[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_20[1] + -1;
    piStack_20[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iStack_24;
}



/* FUNCTION 18106 ; VA 0x0099a390 ; FUN_0099a390 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __thiscall FUN_0099a390(int *param_1,int param_2)

{
  int *piVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  float fVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  double dVar7;
  double *pdVar8;
  undefined4 *puVar9;
  int iVar10;
  float10 fVar11;
  double dVar12;
  undefined4 uStack_64;
  float fStack_58;
  float fStack_54;
  float fStack_4c;
  float fStack_48;
  int iStack_34;
  int *piStack_30;
  int iStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d2118;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01675290();
  uStack_8 = 0;
  FUN_00587490();
  uStack_8._0_1_ = 1;
  if (iStack_1c == 0) {
    param_2 = iStack_1c;
  }
  else {
    if (DAT_01d6514b != '\0') {
      FUN_016774b0();
    }
    FUN_008e9840();
    uStack_8._0_1_ = 3;
    uVar2 = *(undefined8 *)(param_2 + 8);
    uVar3 = *(undefined8 *)(param_2 + 0x10);
    pdVar8 = (double *)FUN_01682800();
    dVar12 = *pdVar8 - *(double *)(param_2 + 8);
    fVar11 = (float10)FUN_00902650(uVar2,uVar3);
    dVar7 = DAT_018ce308;
    iVar10 = param_1[0x4e];
    fVar4 = (float)fVar11;
    while ((iVar10 != 0 && (dVar7 < dVar12 - *(double *)param_1[0x4c]))) {
      param_1[0x4c] = param_1[0x4c] + 0x18;
      if (param_1[0x4c] == param_1[0x4b]) {
        param_1[0x4c] = param_1[0x4a];
      }
      param_1[0x4e] = param_1[0x4e] + -1;
      iVar10 = param_1[0x4e];
    }
    iStack_24 = SUB84(dVar12,0);
    piStack_20 = (int *)((ulonglong)dVar12 >> 0x20);
    if (0.0 < fVar4) {
      piVar1 = param_1 + 0x4a;
      if ((param_1[0x4b] - *piVar1) / 0x18 == param_1[0x4e]) {
        FUN_00999c20();
      }
      puVar9 = (undefined4 *)FUN_01682800();
      uVar5 = *puVar9;
      uVar6 = puVar9[1];
      if ((param_1[0x4b] - *piVar1) / 0x18 == param_1[0x4e]) {
        if (param_1[0x4e] != 0) {
          pdVar8 = (double *)param_1[0x4d];
          *pdVar8 = dVar12;
          *(undefined4 *)(pdVar8 + 1) = uVar5;
          *(undefined4 *)((int)pdVar8 + 0xc) = uVar6;
          pdVar8[2] = (double)CONCAT44(uStack_64,fVar4);
          iVar10 = param_1[0x4d] + 0x18;
          param_1[0x4d] = iVar10;
          if (iVar10 == param_1[0x4b]) {
            iVar10 = *piVar1;
            param_1[0x4d] = iVar10;
          }
          param_1[0x4c] = iVar10;
        }
      }
      else {
        pdVar8 = (double *)param_1[0x4d];
        if (pdVar8 != (double *)0x0) {
          *pdVar8 = dVar12;
          *(undefined4 *)(pdVar8 + 1) = uVar5;
          *(undefined4 *)((int)pdVar8 + 0xc) = uVar6;
          pdVar8[2] = (double)CONCAT44(uStack_64,fVar4);
        }
        param_1[0x4d] = param_1[0x4d] + 0x18;
        if (param_1[0x4d] == param_1[0x4b]) {
          param_1[0x4d] = *piVar1;
        }
        param_1[0x4e] = param_1[0x4e] + 1;
      }
    }
    if (DAT_01ee347d != '\0') {
      fVar11 = (float10)(**(code **)(*param_1 + 0x14))();
      FUN_016774d0(DAT_01ee347d,"averageStepsPerSecond: %f",(float)fVar11,0,0,0);
    }
    if (DAT_01d6514b != '\0') {
      FUN_016774b0();
    }
    if (((((_DAT_01937750 < *(double *)(param_1 + 0x26)) ||
          (*(double *)(param_1 + 0x26) < DAT_01937748)) ||
         (fStack_4c = (float)DAT_019373a0, fStack_4c < DAT_01937758)) ||
        ((fStack_48 = (float)((ulonglong)DAT_019373a0 >> 0x20), fStack_48 < DAT_0193775c ||
         (DAT_019373a8 < DAT_01937760)))) ||
       ((fStack_58 = (float)DAT_01937394, _DAT_01937764 < fStack_58 ||
        ((fStack_54 = (float)((ulonglong)DAT_01937394 >> 0x20), _DAT_01937768 < fStack_54 ||
         (_DAT_0193776c < DAT_0193739c)))))) {
      FUN_00587490();
      iStack_34 = (int)uVar3;
      uStack_8._0_1_ = 4;
      if (iStack_34 != 0) {
        iVar10 = FUN_016dee6d();
        if (iVar10 != 0) {
          FUN_016df3c9();
        }
        uStack_8._0_1_ = 5;
        FUN_00687eb0();
        DAT_01ee04b4 = DAT_01ee04b4 | 0x80;
        uStack_8._0_1_ = 6;
        iVar10 = FUN_016deec8();
        if (iVar10 != 0) {
          FUN_016df3c9();
        }
      }
      piStack_30 = (int *)((ulonglong)uVar3 >> 0x20);
      if (piStack_30 != (int *)0x0) {
        LOCK();
        iVar10 = piStack_30[1] + -1;
        piStack_30[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)*piStack_30)();
          LOCK();
          iVar10 = piStack_30[2] + -1;
          piStack_30[2] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)(*piStack_30 + 4))();
          }
        }
      }
    }
    if (DAT_01d633d0 == '\0') {
      FUN_00587490();
      uStack_8._0_1_ = 7;
      if (iStack_24 != 0) {
        iVar10 = FUN_016dee6d();
        if (iVar10 != 0) {
          FUN_016df3c9();
        }
        uStack_8._0_1_ = 8;
        FUN_00687eb0();
        DAT_01ee04b4 = DAT_01ee04b4 | 0x200000;
        uStack_8._0_1_ = 9;
        iVar10 = FUN_016deec8();
        if (iVar10 != 0) {
          FUN_016df3c9();
        }
      }
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar10 = piStack_20[1] + -1;
        piStack_20[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          iVar10 = piStack_20[2] + -1;
          piStack_20[2] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)(*piStack_20 + 4))();
          }
        }
      }
    }
    param_2 = 1;
    FUN_008eb130();
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar10 = piStack_18[1] + -1;
    piStack_18[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar10 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar10 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  uStack_8 = 10;
  FUN_01675290();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18107 ; VA 0x0099a8d0 ; FUN_0099a8d0 */

void __fastcall FUN_0099a8d0(int param_1)

{
  int iVar1;
  char cVar2;
  
  cVar2 = FUN_00983210(param_1);
  if (cVar2 == '\0') {
    iVar1 = *(int *)(param_1 + 0x68);
    *(undefined8 *)(param_1 + 0x80) = 0;
    *(undefined4 *)(param_1 + 0x70) = 0;
    *(undefined4 *)(param_1 + 0x74) = 0;
    *(undefined4 *)(param_1 + 0x78) = 0;
    *(undefined4 *)(param_1 + 0x7c) = 0;
    if (iVar1 != 0) {
      *(undefined4 *)(param_1 + 0x68) = 0;
      FUN_00997470(iVar1,0);
    }
  }
  return;
}



/* FUNCTION 18108 ; VA 0x0099a910 ; FUN_0099a910 */

void __fastcall FUN_0099a910(int param_1)

{
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  *(undefined *)(param_1 + 0x92) = 1;
  if (*(char *)(param_1 + 0x91) != '\0') {
    FUN_01682800(&uStack_c);
    *(undefined4 *)(param_1 + 0x98) = uStack_c;
    *(undefined4 *)(param_1 + 0x9c) = uStack_8;
  }
  return;
}



/* FUNCTION 18109 ; VA 0x0099a950 ; FUN_0099a950 */

void __thiscall FUN_0099a950(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  void **ppvVar7;
  char cVar8;
  int iVar9;
  int *piVar10;
  undefined4 *puVar11;
  uint uVar12;
  int iVar13;
  uint uVar14;
  int *piVar15;
  uint in_stack_00000018;
  int iStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(param_1 + 0x88);
  uStack_8 = 0;
  iStack_20 = 0;
  piVar2 = (int *)*piVar1;
  ExceptionList = &pvStack_10;
  ppvVar7 = &pvStack_10;
  if (piVar2 != piVar1) {
    do {
      ExceptionList = ppvVar7;
      piVar15 = (int *)piVar2[5];
      iVar13 = piVar2[6] - (int)piVar15;
      piVar10 = (int *)piVar2[6];
      if (piVar15 != piVar10) {
        do {
          cVar8 = FUN_00558b30(piVar15,&param_2);
          if (cVar8 != '\0') break;
          piVar15 = piVar15 + 0xe;
        } while (piVar15 != piVar10);
        piVar4 = piVar15;
        if (piVar15 != piVar10) {
          while (piVar6 = piVar4, piVar4 = piVar6 + 0xe, piVar4 != piVar10) {
            cVar8 = FUN_00558b30(piVar4,&param_2);
            if (cVar8 == '\0') {
              if (piVar15 != piVar4) {
                uVar14 = piVar15[5];
                if (0xf < uVar14) {
                  iVar3 = *piVar15;
                  uVar12 = uVar14 + 1;
                  iVar9 = iVar3;
                  if (0xfff < uVar12) {
                    iVar9 = *(int *)(iVar3 + -4);
                    uVar12 = uVar14 + 0x24;
                    if (0x1f < (iVar3 - iVar9) - 4U) goto LAB_0099ac03;
                  }
                  FUN_01674ea0(iVar9,uVar12);
                }
                piVar15[4] = 0;
                piVar15[5] = 0xf;
                *(undefined *)piVar15 = 0;
                iVar3 = piVar6[0xf];
                iVar9 = piVar6[0x10];
                iVar5 = piVar6[0x11];
                *piVar15 = *piVar4;
                piVar15[1] = iVar3;
                piVar15[2] = iVar9;
                piVar15[3] = iVar5;
                iVar3 = piVar6[0x13];
                piVar15[4] = piVar6[0x12];
                piVar15[5] = iVar3;
                piVar6[0x12] = 0;
                piVar6[0x13] = 0xf;
                *(undefined *)piVar4 = 0;
              }
              FUN_00d88b50(piVar6 + 0x14);
              piVar15 = piVar15 + 0xe;
            }
          }
          if (piVar15 != piVar10) {
            piVar4 = (int *)piVar2[6];
            for (; piVar10 != piVar4; piVar10 = piVar10 + 0xe) {
              if (piVar15 != piVar10) {
                uVar14 = piVar15[5];
                if (0xf < uVar14) {
                  iVar3 = *piVar15;
                  uVar12 = uVar14 + 1;
                  iVar9 = iVar3;
                  if (0xfff < uVar12) {
                    iVar9 = *(int *)(iVar3 + -4);
                    uVar12 = uVar14 + 0x24;
                    if (0x1f < (iVar3 - iVar9) - 4U) goto LAB_0099ac03;
                  }
                  FUN_01674ea0(iVar9,uVar12);
                }
                piVar15[4] = 0;
                piVar15[5] = 0xf;
                *(undefined *)piVar15 = 0;
                iVar3 = piVar10[1];
                iVar9 = piVar10[2];
                iVar5 = piVar10[3];
                *piVar15 = *piVar10;
                piVar15[1] = iVar3;
                piVar15[2] = iVar9;
                piVar15[3] = iVar5;
                iVar3 = piVar10[5];
                piVar15[4] = piVar10[4];
                piVar15[5] = iVar3;
                piVar10[4] = 0;
                piVar10[5] = 0xf;
                *(undefined *)piVar10 = 0;
              }
              FUN_00d88b50(piVar10 + 6);
              piVar15 = piVar15 + 0xe;
            }
            FUN_009957d0(piVar15,piVar2[6],piVar2 + 5);
            piVar2[6] = (int)piVar15;
          }
        }
      }
      iStack_20 = iStack_20 + (iVar13 / 0x38 - (piVar2[6] - piVar2[5]) / 0x38);
      FUN_00551320();
      ppvVar7 = (void **)ExceptionList;
    } while (piVar2 != piVar1);
    if (1 < iStack_20) {
      puVar11 = &param_2;
      if (0xf < in_stack_00000018) {
        puVar11 = param_2;
      }
      FUN_0086f2f0(2,
                   "RunService:UnbindFromRenderStep removed different functions with same reference name %s %i times."
                   ,puVar11,iStack_20);
    }
  }
  if (0xf < in_stack_00000018) {
    uVar14 = in_stack_00000018 + 1;
    puVar11 = param_2;
    if (0xfff < uVar14) {
      puVar11 = (undefined4 *)param_2[-1];
      uVar14 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar11))) {
LAB_0099ac03:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar11,uVar14);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18110 ; VA 0x0099ac10 ; FUN_0099ac10 */

undefined4 * __thiscall
FUN_0099ac10(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  
  uVar1 = FUN_0099be20();
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar2 != (undefined4 *)0x0) {
    *puVar2 = RBX::Reflection::PropDescriptor<class_RBX::Humanoid,class_G3D::Vector3>::
              GetSetImpl<class_G3D::Vector3_(__thiscall_RBX::Humanoid::*)(void)const_,void_(__thiscall_RBX::Humanoid::*)(class_G3D::Vector3_const&)>
              ::vftable;
    *(undefined8 *)(puVar2 + 2) = param_4;
    puVar2[4] = param_5;
    *(undefined8 *)(puVar2 + 6) = param_6;
    puVar2[8] = param_7;
  }
  FUN_00918e80(uVar1,param_2,param_3);
  *param_1 = RBX::Reflection::PropDescriptor<class_RBX::Humanoid,class_G3D::Vector3>::vftable;
  return param_1;
}



/* FUNCTION 18111 ; VA 0x0099aca0 ; FUN_0099aca0 */

undefined4 * __thiscall
FUN_0099aca0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  
  uVar1 = FUN_0099be20();
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar2 != (undefined4 *)0x0) {
    *puVar2 = RBX::Reflection::PropDescriptor<class_RBX::Humanoid,class_G3D::Vector3>::
              GetSetImpl<class_G3D::Vector3_const&_(__thiscall_RBX::Humanoid::*)(void)const_,void_(__thiscall_RBX::Humanoid::*)(class_G3D::Vector3_const&)>
              ::vftable;
    *(undefined8 *)(puVar2 + 2) = param_4;
    puVar2[4] = param_5;
    *(undefined8 *)(puVar2 + 6) = param_6;
    puVar2[8] = param_7;
  }
  FUN_00918e80(uVar1,param_2,param_3);
  *param_1 = RBX::Reflection::PropDescriptor<class_RBX::Humanoid,class_G3D::Vector3>::vftable;
  return param_1;
}



/* FUNCTION 18112 ; VA 0x0099ad30 ; FUN_0099ad30 */

undefined4 * __thiscall
FUN_0099ad30(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  
  uVar1 = FUN_0099be20();
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar2 != (undefined4 *)0x0) {
    *puVar2 = RBX::Reflection::PropDescriptor<class_RBX::Humanoid,float>::
              GetSetImpl<float_(__thiscall_RBX::Humanoid::*)(void)const_,void_(__thiscall_RBX::Humanoid::*)(float)>
              ::vftable;
    *(undefined8 *)(puVar2 + 2) = param_4;
    puVar2[4] = param_5;
    *(undefined8 *)(puVar2 + 6) = param_6;
    puVar2[8] = param_7;
  }
  FUN_006846c0(uVar1,param_2,param_3);
  *param_1 = RBX::Reflection::PropDescriptor<class_RBX::Humanoid,float>::vftable;
  return param_1;
}



/* FUNCTION 18113 ; VA 0x0099adc0 ; FUN_0099adc0 */

int * __thiscall
FUN_0099adc0(int *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d2143;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009c6980();
  uVar3 = FUN_0099be20();
  FUN_009ca670(uVar3,uVar2,param_2,param_3,param_7,param_8,param_9,param_10,param_11,param_11,0);
  param_1[0xd] = (int)RBX::IIDREF::vftable;
  uStack_8 = 0;
  *param_1 = (int)RBX::Reflection::RefPropDescriptor<class_RBX::Humanoid,class_RBX::PartInstance>::
                  vftable;
  param_1[0xd] = (int)RBX::Reflection::
                      RefPropDescriptor<class_RBX::Humanoid,class_RBX::PartInstance>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::PropDescriptor<class_RBX::Humanoid,class_RBX::PartInstance*>::
              GetImpl<class_RBX::PartInstance*_(__thiscall_RBX::Humanoid::*)(void)const_>::vftable;
    *(undefined8 *)(puVar4 + 2) = param_4;
    puVar4[4] = param_5;
  }
  param_1[0xe] = (int)puVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  cVar1 = (**(code **)(*param_1 + 0xc))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar1 = (**(code **)(*param_1 + 8))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18114 ; VA 0x0099aea0 ; FUN_0099aea0 */

int * __thiscall
FUN_0099aea0(int *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d2143;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009c6980();
  uVar3 = FUN_0099be20();
  FUN_009ca670(uVar3,uVar2,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  param_1[0xd] = (int)RBX::IIDREF::vftable;
  uStack_8 = 0;
  *param_1 = (int)RBX::Reflection::RefPropDescriptor<class_RBX::Humanoid,class_RBX::PartInstance>::
                  vftable;
  param_1[0xd] = (int)RBX::Reflection::
                      RefPropDescriptor<class_RBX::Humanoid,class_RBX::PartInstance>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::PropDescriptor<class_RBX::Humanoid,class_RBX::PartInstance*>::
              GetSetImpl<class_RBX::PartInstance*_(__thiscall_RBX::Humanoid::*)(void)const_,void_(__thiscall_RBX::Humanoid::*)(class_RBX::PartInstance*)>
              ::vftable;
    *(undefined8 *)(puVar4 + 2) = param_4;
    puVar4[4] = param_5;
    *(undefined8 *)(puVar4 + 6) = param_6;
    puVar4[8] = param_7;
  }
  param_1[0xe] = (int)puVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  cVar1 = (**(code **)(*param_1 + 0xc))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar1 = (**(code **)(*param_1 + 8))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18115 ; VA 0x0099af90 ; FUN_0099af90 */

int * __thiscall
FUN_0099af90(int *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baf8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0099be20();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Humanoid,bool>::
              GetSetImpl<bool_(__thiscall_RBX::Humanoid::*)(void)const_,void_(__thiscall_RBX::Humanoid::*)(bool)>
              ::vftable;
    *(undefined8 *)(puVar3 + 2) = param_4;
    puVar3[4] = param_5;
    *(undefined8 *)(puVar3 + 6) = param_6;
    puVar3[8] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::Humanoid,bool>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::Humanoid,bool>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18116 ; VA 0x0099b0a0 ; FUN_0099b0a0 */

undefined4 * __thiscall
FUN_0099b0a0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  
  uVar1 = FUN_0099be20();
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar2 != (undefined4 *)0x0) {
    *puVar2 = RBX::Reflection::PropDescriptor<class_RBX::Humanoid,float>::
              GetSetImpl<float_(__thiscall_RBX::ICharacterSubject::*)(void)const_,void_(__thiscall_RBX::ICharacterSubject::*)(float)>
              ::vftable;
    *(undefined8 *)(puVar2 + 2) = param_4;
    puVar2[4] = param_5;
    *(undefined8 *)(puVar2 + 6) = param_6;
    puVar2[8] = param_7;
  }
  FUN_006846c0(uVar1,param_2,param_3);
  *param_1 = RBX::Reflection::PropDescriptor<class_RBX::Humanoid,float>::vftable;
  return param_1;
}



/* FUNCTION 18117 ; VA 0x0099b130 ; FUN_0099b130 */

undefined4 * __thiscall
FUN_0099b130(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  FUN_0099d3a0(param_2,param_3,param_4,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 18118 ; VA 0x0099b230 ; FUN_0099b230 */

undefined4 * __thiscall FUN_0099b230(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_01939830;
  cVar3 = FUN_0055c750(param_2,param_3,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 18119 ; VA 0x0099b320 ; FUN_0099b320 */

undefined4 * __thiscall
FUN_0099b320(undefined4 *param_1,uint param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined8 param_8)

{
  uint *puVar1;
  char cVar2;
  undefined **ppuVar3;
  uint auStack_80 [2];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 uStack_68;
  undefined4 *puStack_60;
  uint uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d2168;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_34 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_2 != 0) {
    uStack_34 = param_2;
    if ((param_2 & 1) == 0) {
      puStack_60 = (undefined4 *)0x0;
      uStack_68 = CONCAT44(&uStack_2c,&param_4);
      uStack_6c = 0x99b384;
      ExceptionList = &pvStack_10;
      (**(code **)(param_2 & 0xfffffffe))();
    }
    else {
      uStack_2c = param_4;
      uStack_28 = param_5;
      uStack_24 = param_6;
      uStack_20 = param_7;
      uStack_1c = param_8;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  uStack_54 = 0;
  if (uStack_34 != 0) {
    uStack_54 = uStack_34;
    if ((uStack_34 & 1) == 0) {
      puStack_60 = (undefined4 *)0x0;
      uStack_68 = CONCAT44(&uStack_4c,&uStack_2c);
      uStack_6c = 0x99b3cd;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    else {
      uStack_4c = uStack_2c;
      uStack_48 = uStack_28;
      uStack_44 = uStack_24;
      uStack_40 = uStack_20;
      uStack_3c = uStack_1c;
    }
  }
  puStack_60 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = auStack_80;
  auStack_80[0] = 0;
  puVar1 = auStack_80;
  if (uStack_54 != 0) {
    auStack_80[0] = uStack_54;
    if ((uStack_54 & 1) == 0) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,&uStack_78,0);
      puVar1 = puStack_14;
    }
    else {
      uStack_78 = uStack_4c;
      uStack_74 = uStack_48;
      uStack_70 = uStack_44;
      uStack_6c = uStack_40;
      uStack_68 = uStack_3c;
      puVar1 = auStack_80;
    }
  }
  puStack_14 = puVar1;
  ppuVar3 = &PTR_FUN_01939810;
  cVar2 = FUN_0099d4b0();
  if (cVar2 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8._0_1_ = 3;
  if (((uStack_54 != 0) && ((uStack_54 & 1) == 0)) &&
     (*(code **)(uStack_54 & 0xfffffffe) != (code *)0x0)) {
    puStack_60 = (undefined4 *)0x2;
    uStack_68 = CONCAT44(&uStack_4c,&uStack_4c);
    uStack_6c = 0x99b456;
    (**(code **)(uStack_54 & 0xfffffffe))();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      puStack_60 = (undefined4 *)0x2;
      uStack_68 = CONCAT44(&uStack_2c,&uStack_2c);
      uStack_6c = 0x99b485;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  uStack_8 = 5;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    puStack_60 = (undefined4 *)0x2;
    uStack_68 = CONCAT44(&param_4,&param_4);
    uStack_6c = 0x99b4b3;
    (**(code **)(param_2 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18120 ; VA 0x0099b4d0 ; FUN_0099b4d0 */

undefined4 * __thiscall FUN_0099b4d0(undefined4 *param_1,undefined4 param_2)

{
  char cVar1;
  undefined **ppuVar2;
  uint in_stack_00000054;
  undefined4 auStack_170 [25];
  undefined4 uStack_10c;
  undefined *puStack_108;
  undefined *puStack_104;
  undefined4 *puStack_100;
  undefined auStack_ec [72];
  uint uStack_a4;
  undefined auStack_9c [24];
  undefined4 uStack_84;
  undefined auStack_7c [72];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d219b;
  pvStack_10 = ExceptionList;
  puStack_100 = (undefined4 *)&stack0x0000000c;
  uStack_8 = 0;
  puStack_104 = (undefined *)0x99b514;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_009a1b20();
  uStack_84 = param_2;
  puStack_100 = (undefined4 *)auStack_ec;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  puStack_104 = (undefined *)0x99b536;
  FUN_009a1b20();
  puStack_100 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = auStack_170;
  auStack_170[0] = uStack_84;
  FUN_009a1b20(auStack_7c);
  ppuVar2 = &PTR_FUN_01939828;
  cVar1 = FUN_0099d6c0();
  if (cVar1 == '\0') {
    ppuVar2 = (undefined **)0x0;
  }
  *param_1 = ppuVar2;
  uStack_8._0_1_ = 3;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      puStack_108 = auStack_2c;
      puStack_100 = (undefined4 *)0x2;
      uStack_10c = 0x99b58d;
      puStack_104 = puStack_108;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  puStack_100 = (undefined4 *)0x99b59f;
  FUN_009a39a0();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_a4 != 0) {
    if (((uStack_a4 & 1) == 0) && (*(code **)(uStack_a4 & 0xfffffffe) != (code *)0x0)) {
      puStack_108 = auStack_9c;
      puStack_100 = (undefined4 *)0x2;
      uStack_10c = 0x99b5c6;
      puStack_104 = puStack_108;
      (**(code **)(uStack_a4 & 0xfffffffe))();
    }
    uStack_a4 = 0;
  }
  puStack_100 = (undefined4 *)0x99b5de;
  FUN_009a39a0();
  uStack_8 = 5;
  if (in_stack_00000054 != 0) {
    if (((in_stack_00000054 & 1) == 0) &&
       (*(code **)(in_stack_00000054 & 0xfffffffe) != (code *)0x0)) {
      puStack_108 = &stack0x0000005c;
      puStack_100 = (undefined4 *)0x2;
      uStack_10c = 0x99b602;
      puStack_104 = puStack_108;
      (**(code **)(in_stack_00000054 & 0xfffffffe))();
    }
    in_stack_00000054 = 0;
  }
  puStack_100 = (undefined4 *)0x99b614;
  FUN_009a39a0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18121 ; VA 0x0099b630 ; FUN_0099b630 */

undefined4 * __thiscall
FUN_0099b630(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,int *param_8)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d21c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_01939870;
  cVar3 = FUN_0099d860(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      iVar2 = param_8[2] + -1;
      param_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_8 + 4))();
      }
    }
    if (param_8 != (int *)0x0) {
      LOCK();
      iVar2 = param_8[1] + -1;
      param_8[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_8)();
        LOCK();
        iVar2 = param_8[2] + -1;
        param_8[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_8 + 4))();
        }
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18122 ; VA 0x0099b770 ; FUN_0099b770 */

int __thiscall FUN_0099b770(int param_1,uint param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d21f0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x24) = 0;
  uStack_8 = 1;
  uVar1 = FUN_0099c740(&param_2);
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  uStack_8 = 2;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18123 ; VA 0x0099b7f0 ; FUN_0099b7f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_0099b7f0(undefined4 *param_1,undefined4 *param_2)

{
  undefined *puVar1;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee415c) {
    FUN_016f3809(&DAT_01ee415c);
    if (DAT_01ee415c == -1) {
      _DAT_01ee4150 = FUN_005c65e0;
      _DAT_01ee4154 = FUN_005c65e0;
      _DAT_01ee4158 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee415c);
    }
  }
  puVar1 = (undefined *)*param_1;
  if (puVar1 == &DAT_01ee4150) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = &DAT_01ee4150;
  return param_1;
}



/* FUNCTION 18124 ; VA 0x0099b8a0 ; FUN_0099b8a0 */

int * __thiscall FUN_0099b8a0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_009c6bf0();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 18125 ; VA 0x0099b8f0 ; FUN_0099b8f0 */

int * __thiscall FUN_0099b8f0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_009c6c60();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 18126 ; VA 0x0099b940 ; FUN_0099b940 */

int * __thiscall FUN_0099b940(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_009c6cd0();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 18127 ; VA 0x0099b990 ; FUN_0099b990 */

void __thiscall
FUN_0099b990(undefined4 *param_1,undefined4 param_2,undefined4 *param_3,int *param_4)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b108;
  pvStack_10 = ExceptionList;
  pcVar2 = (code *)*param_3;
  uVar3 = param_1[8];
  uStack_40 = 0;
  uVar4 = param_1[0x12];
  ExceptionList = &pvStack_10;
  if (uVar4 != 0) {
    uStack_40 = uVar4;
    if ((uVar4 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = param_1 + 0x14;
      uStack_50 = 0x99b9fe;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar4 & 0xfffffffe))();
    }
    else {
      uStack_38 = param_1[0x14];
      uStack_34 = param_1[0x15];
      uStack_30 = param_1[0x16];
      uStack_2c = param_1[0x17];
      uStack_28 = *(undefined8 *)(param_1 + 0x18);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uVar4 = param_1[10];
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      (**(code **)(uVar4 & 0xfffffffe))(param_1 + 0xc,&uStack_58,0);
    }
    else {
      uStack_58 = param_1[0xc];
      uStack_54 = param_1[0xd];
      uStack_50 = param_1[0xe];
      puStack_4c = (undefined4 *)param_1[0xf];
      uStack_48 = *(ulonglong *)(param_1 + 0x10);
    }
  }
  if (param_1[7] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[7] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar5 = param_1[6];
  uVar6 = param_1[7];
  if (param_1[5] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[5] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar7 = param_1[4];
  uVar8 = param_1[5];
  puVar9 = (undefined4 *)*param_4;
  if (puVar9[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar9[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar10 = *puVar9;
  uVar11 = puVar9[1];
  if (param_1[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar12 = param_1[2];
  uVar13 = param_1[3];
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  (*pcVar2)(*param_1,param_1[1],uVar12,uVar13,uVar10,uVar11,uVar7,uVar8,uVar5,uVar6,uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18128 ; VA 0x0099bb40 ; FUN_0099bb40 */

void FUN_0099bb40(undefined4 *param_1)

{
  FUN_008a4940(*param_1);
  return;
}



/* FUNCTION 18129 ; VA 0x0099bb60 ; FUN_0099bb60 */

void FUN_0099bb60(undefined4 *param_1)

{
  FUN_005e6780(*param_1);
  return;
}



/* FUNCTION 18130 ; VA 0x0099bb80 ; FUN_0099bb80 */

int FUN_0099bb80(void)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    FUN_0054ef60(*(undefined4 *)(iStack_18 + 0x28));
    iVar3 = FUN_006ecaa0();
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 18131 ; VA 0x0099bc10 ; FUN_0099bc10 */

void FUN_0099bc10(undefined4 *param_1)

{
  FUN_005e6780(*param_1);
  return;
}



/* FUNCTION 18132 ; VA 0x0099bc30 ; FUN_0099bc30 */

void FUN_0099bc30(undefined4 *param_1)

{
  FUN_0091b810(*param_1);
  return;
}



/* FUNCTION 18133 ; VA 0x0099bc50 ; FUN_0099bc50 */

void FUN_0099bc50(undefined4 *param_1)

{
  int *piVar1;
  
  piVar1 = param_1 + 2;
  if (((int)param_1[5] >> 1 & 1U) == 0) {
    piVar1 = (int *)*piVar1;
  }
  (**(code **)(param_1[5] & 0xfffffff8))(piVar1,*param_1);
  return;
}



/* FUNCTION 18134 ; VA 0x0099bc80 ; FUN_0099bc80 */

void FUN_0099bc80(void)

{
  FUN_009addb0();
  return;
}



/* FUNCTION 18135 ; VA 0x0099bc90 ; FUN_0099bc90 */

void FUN_0099bc90(void)

{
  FUN_009a6aa0();
  return;
}



/* FUNCTION 18136 ; VA 0x0099bca0 ; FUN_0099bca0 */

void FUN_0099bca0(void)

{
  FUN_005e6780(1);
  return;
}



/* FUNCTION 18137 ; VA 0x0099bcc0 ; FUN_0099bcc0 */

void FUN_0099bcc0(void)

{
  FUN_005e6780(0);
  return;
}



/* FUNCTION 18138 ; VA 0x0099bce0 ; FUN_0099bce0 */

int FUN_0099bce0(void)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    FUN_0054ef60(*(undefined4 *)(iStack_18 + 0x28));
    iVar3 = FUN_006ecaa0();
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 18139 ; VA 0x0099bd70 ; FUN_0099bd70 */

int FUN_0099bd70(void)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abb78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = FUN_00c18540(0x3dcccccd);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 18140 ; VA 0x0099be00 ; FUN_0099be00 */

void FUN_0099be00(undefined4 *param_1)

{
  FUN_005e66b0(*param_1,*(undefined *)(param_1 + 1));
  return;
}



/* FUNCTION 18141 ; VA 0x0099be20 ; FUN_0099be20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0099be20(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d2220;
  pvStack_10 = ExceptionList;
  if (DAT_01ee3b48 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee3d60) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee3d60);
      if (DAT_01ee3d60 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Humanoid",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01ee3d58 = RBX::Creator<class_RBX::Humanoid>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ee3b50,&DAT_01ee3d58);
        FUN_016f3654(FUN_01887270);
        FUN_016f37bf(&DAT_01ee3d60);
      }
    }
    DAT_01ee3b48 = &DAT_01ee3b50;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee3b48;
}



/* FUNCTION 18142 ; VA 0x0099bf20 ; FUN_0099bf20 */

int FUN_0099bf20(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    param_1 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x0099bf3a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar3 = (**(code **)(*piVar2 + 4))();
      return iVar3;
    }
  }
  return param_1;
}



/* FUNCTION 18143 ; VA 0x0099bf40 ; FUN_0099bf40 */

void FUN_0099bf40(void)

{
  FUN_009a33c0();
  return;
}



/* FUNCTION 18144 ; VA 0x0099bf50 ; FUN_0099bf50 */

void FUN_0099bf50(undefined4 *param_1,undefined4 *param_2)

{
  *param_1 = 0;
  param_1[1] = 0;
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  return;
}



/* FUNCTION 18145 ; VA 0x0099bf80 ; FUN_0099bf80 */

void FUN_0099bf80(undefined4 *param_1,undefined4 *param_2)

{
  *param_1 = 0;
  param_1[1] = 0;
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  FUN_006d0690(param_2 + 2);
  return;
}



/* FUNCTION 18146 ; VA 0x0099bfc0 ; FUN_0099bfc0 */

int FUN_0099bfc0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d2230;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009a6cf0(param_1,param_2);
  uStack_8 = 0;
  FUN_0054ef60(param_3);
  *(undefined8 *)(iVar1 + 0x20) = *(undefined8 *)(param_3 + 0x18);
  *(undefined4 *)(iVar1 + 0x28) = *(undefined4 *)(param_3 + 0x20);
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 18147 ; VA 0x0099c02c ; Catch_All@0099c02c */

void Catch_All_0099c02c(void)

{
  int unaff_EBP;
  
  FUN_009aeb50(*(undefined4 *)(unaff_EBP + 0xc),1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18148 ; VA 0x0099c050 ; FUN_0099c050 */

void FUN_0099c050(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  
  if (param_1 != param_2) {
    do {
      piVar1 = *(int **)(param_1 + 0x48);
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      param_1 = param_1 + 0x78;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 18149 ; VA 0x0099c0a0 ; FUN_0099c0a0 */

void FUN_0099c0a0(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  
  if (param_1 != param_2) {
    do {
      piVar1 = (int *)*param_1;
      if (piVar1 != (int *)0x0) {
        iVar2 = *piVar1;
        if (iVar2 != 0) {
          FUN_00617bc0();
          FUN_01674ea0(iVar2,0x1c);
        }
        FUN_01674ea0(piVar1,8);
      }
      param_1 = param_1 + 1;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 18150 ; VA 0x0099c0f0 ; FUN_0099c0f0 */

int __thiscall FUN_0099c0f0(uint *param_1,uint param_2,undefined4 param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d2240;
  pvStack_10 = ExceptionList;
  uVar8 = *param_1;
  iVar2 = (int)(param_1[1] - uVar8) >> 4;
  if (iVar2 == 0xfffffff) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar2 + 1;
  uVar4 = (int)(param_1[2] - uVar8) >> 4;
  uVar7 = uVar1;
  if ((uVar4 <= 0xfffffff - (uVar4 >> 1)) && (uVar7 = (uVar4 >> 1) + uVar4, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  uVar4 = uVar7 * 0x10;
  if (uVar7 < 0x10000000) {
    uVar7 = uVar4;
    if (0xfff < uVar4) goto LAB_0099c17b;
    if (uVar4 == 0) {
      uVar7 = 0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      uVar7 = FUN_01674e20(uVar4);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_0099c17b:
    uVar3 = uVar7 + 0x23;
    if (uVar3 <= uVar7) {
      uVar3 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar2 = FUN_01674e20(uVar3);
    if (iVar2 == 0) goto LAB_0099c2b3;
    uVar7 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar7 - 4) = iVar2;
  }
  uVar6 = param_2 - uVar8 & 0xfffffff0;
  uStack_8 = 0;
  iVar2 = uVar6 + uVar7;
  uVar8 = iVar2 + 0x10;
  FUN_0099e8e0(param_1,iVar2,param_3);
  uVar3 = param_1[1];
  if (param_2 == uVar3) {
    param_2 = *param_1;
    uVar8 = uVar7;
  }
  else {
    FUN_0099d320(*param_1,param_2,uVar7,param_1);
    uVar3 = param_1[1];
  }
  FUN_0099d320(param_2,uVar3,uVar8,param_1);
  uStack_8 = 0xffffffff;
  if (*param_1 != 0) {
    FUN_00995940(*param_1,param_1[1],param_1);
    uVar8 = *param_1;
    uVar5 = param_1[2] - uVar8 & 0xfffffff0;
    uVar3 = uVar8;
    if (0xfff < uVar5) {
      uVar3 = *(uint *)(uVar8 - 4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (uVar8 - uVar3) - 4) {
LAB_0099c2b3:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar5);
  }
  *param_1 = uVar7;
  param_1[1] = uVar1 * 0x10 + uVar7;
  param_1[2] = uVar4 + uVar7;
  ExceptionList = pvStack_10;
  return *param_1 + uVar6;
}



/* FUNCTION 18151 ; VA 0x0099c289 ; Catch_All@0099c289 */

void Catch_All_0099c289(void)

{
  int unaff_EBP;
  
  FUN_009978a0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x1c));
  FUN_0061a3e0(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18152 ; VA 0x0099c2c0 ; FUN_0099c2c0 */

undefined4 * FUN_0099c2c0(uint *param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d2250;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_01674e20(0x28);
  uStack_8 = 0;
  *puVar4 = std::
            _Func_impl_no_alloc<class_<lambda_4dd444fc3bc9f580bc95870b96003314>,void,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>_>
            ::vftable;
  puVar4[2] = 0;
  uVar1 = *param_1;
  if (uVar1 != 0) {
    puVar4[2] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_1 + 2,puVar4 + 4,0);
      ExceptionList = pvStack_10;
      return puVar4;
    }
    uVar1 = param_1[3];
    uVar2 = param_1[4];
    uVar3 = param_1[5];
    puVar4[4] = param_1[2];
    puVar4[5] = uVar1;
    puVar4[6] = uVar2;
    puVar4[7] = uVar3;
    *(undefined8 *)(puVar4 + 8) = *(undefined8 *)(param_1 + 6);
  }
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 18153 ; VA 0x0099c361 ; Catch_All@0099c361 */

void Catch_All_0099c361(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x28);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18154 ; VA 0x0099c380 ; FUN_0099c380 */

undefined4 * FUN_0099c380(undefined4 param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d2260;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x28);
  uStack_8 = 0;
  *puVar1 = std::
            _Func_impl_no_alloc<class_<lambda_4dd444fc3bc9f580bc95870b96003314>,void,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>_>
            ::vftable;
  puVar1[2] = 0;
  FUN_005880d0(param_1);
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 18155 ; VA 0x0099c3e1 ; Catch_All@0099c3e1 */

void Catch_All_0099c3e1(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x28);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18156 ; VA 0x0099c400 ; FUN_0099c400 */

undefined4 * FUN_0099c400(uint *param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d2270;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_01674e20(0x28);
  uStack_8 = 0;
  *puVar4 = std::
            _Func_impl_no_alloc<class_<lambda_5fc0ede2d0ae68360350b7320687fc49>,void,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>_>
            ::vftable;
  puVar4[2] = 0;
  uVar1 = *param_1;
  if (uVar1 != 0) {
    puVar4[2] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_1 + 2,puVar4 + 4,0);
      ExceptionList = pvStack_10;
      return puVar4;
    }
    uVar1 = param_1[3];
    uVar2 = param_1[4];
    uVar3 = param_1[5];
    puVar4[4] = param_1[2];
    puVar4[5] = uVar1;
    puVar4[6] = uVar2;
    puVar4[7] = uVar3;
    *(undefined8 *)(puVar4 + 8) = *(undefined8 *)(param_1 + 6);
  }
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 18157 ; VA 0x0099c4a1 ; Catch_All@0099c4a1 */

void Catch_All_0099c4a1(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x28);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18158 ; VA 0x0099c4c0 ; FUN_0099c4c0 */

undefined4 * FUN_0099c4c0(undefined4 param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d2280;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x28);
  uStack_8 = 0;
  *puVar1 = std::
            _Func_impl_no_alloc<class_<lambda_5fc0ede2d0ae68360350b7320687fc49>,void,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>_>
            ::vftable;
  puVar1[2] = 0;
  FUN_005880d0(param_1);
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 18159 ; VA 0x0099c521 ; Catch_All@0099c521 */

void Catch_All_0099c521(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x28);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18160 ; VA 0x0099c540 ; FUN_0099c540 */

undefined4 * FUN_0099c540(uint *param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d2290;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_01674e20(0x28);
  uStack_8 = 0;
  *puVar4 = std::
            _Func_impl_no_alloc<class_<lambda_95bcb670a0e1b2e0928fabe058461903>,void,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>_>
            ::vftable;
  puVar4[2] = 0;
  uVar1 = *param_1;
  if (uVar1 != 0) {
    puVar4[2] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_1 + 2,puVar4 + 4,0);
      ExceptionList = pvStack_10;
      return puVar4;
    }
    uVar1 = param_1[3];
    uVar2 = param_1[4];
    uVar3 = param_1[5];
    puVar4[4] = param_1[2];
    puVar4[5] = uVar1;
    puVar4[6] = uVar2;
    puVar4[7] = uVar3;
    *(undefined8 *)(puVar4 + 8) = *(undefined8 *)(param_1 + 6);
  }
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 18161 ; VA 0x0099c5e1 ; Catch_All@0099c5e1 */

void Catch_All_0099c5e1(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x28);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18162 ; VA 0x0099c600 ; FUN_0099c600 */

undefined4 * FUN_0099c600(undefined4 param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d22a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x28);
  uStack_8 = 0;
  *puVar1 = std::
            _Func_impl_no_alloc<class_<lambda_95bcb670a0e1b2e0928fabe058461903>,void,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>_>
            ::vftable;
  puVar1[2] = 0;
  FUN_005880d0(param_1);
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 18163 ; VA 0x0099c661 ; Catch_All@0099c661 */

void Catch_All_0099c661(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x28);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18164 ; VA 0x0099c680 ; FUN_0099c680 */

undefined4 * FUN_0099c680(uint *param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d22b0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_01674e20(0x28);
  uStack_8 = 0;
  *puVar4 = std::
            _Func_impl_no_alloc<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,void,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
            ::vftable;
  puVar4[2] = 0;
  uVar1 = *param_1;
  if (uVar1 != 0) {
    puVar4[2] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_1 + 2,puVar4 + 4,0);
      ExceptionList = pvStack_10;
      return puVar4;
    }
    uVar1 = param_1[3];
    uVar2 = param_1[4];
    uVar3 = param_1[5];
    puVar4[4] = param_1[2];
    puVar4[5] = uVar1;
    puVar4[6] = uVar2;
    puVar4[7] = uVar3;
    *(undefined8 *)(puVar4 + 8) = *(undefined8 *)(param_1 + 6);
  }
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 18165 ; VA 0x0099c721 ; Catch_All@0099c721 */

void Catch_All_0099c721(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x28);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18166 ; VA 0x0099c740 ; FUN_0099c740 */

undefined4 * FUN_0099c740(undefined4 param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d22c0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x28);
  uStack_8 = 0;
  *puVar1 = std::
            _Func_impl_no_alloc<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,void,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
            ::vftable;
  puVar1[2] = 0;
  FUN_005880d0(param_1);
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 18167 ; VA 0x0099c7a1 ; Catch_All@0099c7a1 */

void Catch_All_0099c7a1(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x28);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18168 ; VA 0x0099c7c0 ; FUN_0099c7c0 */

void __thiscall FUN_0099c7c0(float *param_1,float *param_2,undefined4 *param_3,float *param_4)

{
  byte *pbVar1;
  float fVar2;
  float *pfVar3;
  undefined *puVar4;
  char cVar5;
  int *piVar6;
  uint uVar7;
  undefined4 *puVar8;
  float fVar9;
  uint uVar10;
  float fVar11;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d22d0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  pfStack_18 = (float *)param_3;
  if (0xf < (uint)param_3[5]) {
    pfStack_18 = (float *)*param_3;
  }
  uVar7 = 0;
  uVar10 = 0x811c9dc5;
  if (param_3[4] != 0) {
    do {
      pbVar1 = (byte *)(uVar7 + (int)pfStack_18);
      uVar7 = uVar7 + 1;
      uVar10 = (*pbVar1 ^ uVar10) * 0x1000193;
    } while (uVar7 < (uint)param_3[4]);
  }
  fVar9 = param_1[3];
  uVar10 = (uint)param_1[6] & uVar10;
  fVar11 = param_1[1];
  ExceptionList = &pvStack_10;
  pfStack_1c = param_1;
  puVar4 = &stack0xffffffd0;
  if (fVar11 != *(float *)((int)fVar9 + uVar10 * 8)) {
    fVar11 = **(float **)((int)fVar9 + 4 + uVar10 * 8);
    ExceptionList = &pvStack_10;
    while (puVar4 = puStack_14, fVar11 != *(float *)((int)fVar9 + uVar10 * 8)) {
      fVar11 = *(float *)((int)fVar11 + 4);
      piVar6 = (int *)((int)fVar11 + 8);
      if (0xf < *(uint *)((int)fVar11 + 0x1c)) {
        piVar6 = (int *)*piVar6;
      }
      puVar8 = param_3;
      if (0xf < (uint)param_3[5]) {
        puVar8 = (undefined4 *)*param_3;
      }
      cVar5 = FUN_0055c360(puVar8,param_3[4],piVar6,*(undefined4 *)((int)fVar11 + 0x18));
      fVar9 = param_1[3];
      if (cVar5 != '\0') {
        *(float *)param_4[1] = *param_4;
        *(float *)((int)*param_4 + 4) = param_4[1];
        param_1[2] = (float)((int)param_1[2] + -1);
        FUN_009a6fc0(param_4);
        *param_2 = fVar11;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  puStack_14 = puVar4;
  pfStack_18 = param_4;
  fVar9 = *param_4;
  if (fVar11 != fVar9) {
    *(float *)param_4[1] = fVar9;
    **(float **)((int)fVar9 + 4) = fVar11;
    **(undefined4 **)((int)fVar11 + 4) = param_4;
    fVar2 = *(float *)((int)fVar11 + 4);
    *(undefined4 *)((int)fVar11 + 4) = *(undefined4 *)((int)fVar9 + 4);
    *(float *)((int)fVar9 + 4) = param_4[1];
    param_4[1] = fVar2;
  }
  fVar9 = param_1[3];
  fVar2 = *(float *)((int)fVar9 + uVar10 * 8);
  if (fVar2 == param_1[1]) {
    *(float **)((int)fVar9 + uVar10 * 8) = param_4;
    *(float **)((int)param_1[3] + 4 + uVar10 * 8) = param_4;
  }
  else if (fVar2 == fVar11) {
    *(float **)((int)fVar9 + uVar10 * 8) = param_4;
  }
  else {
    pfVar3 = (float *)**(undefined4 **)((int)fVar9 + 4 + uVar10 * 8);
    *(float **)((int)fVar9 + 4 + uVar10 * 8) = pfVar3;
    if (pfVar3 != param_4) {
      *(undefined4 *)((int)param_1[3] + 4 + uVar10 * 8) =
           *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uVar10 * 8) + 4);
    }
  }
  fVar9 = param_1[7];
  uStack_8 = 2;
  fVar11 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
           (float)((double)(int)fVar9 + (double)(&DAT_018c0d90)[-((int)fVar9 >> 0x1f)]);
  if (*param_1 <= fVar11 && fVar11 != *param_1) {
    if ((uint)fVar9 < 0x200) {
      fVar9 = (float)((int)fVar9 << 3);
    }
    else if ((uint)fVar9 < 0x1fffffff) {
      fVar9 = (float)((int)fVar9 * 2);
    }
    FUN_005cb500(fVar9);
    pfVar3 = (float *)param_1[1];
    if ((float *)*pfVar3 != pfVar3) {
      fVar9 = pfVar3[1];
      do {
        fVar11 = *(float *)param_1[1];
        FUN_0099c7c0(auStack_24,(int)fVar11 + 8,fVar11);
      } while (fVar11 != fVar9);
    }
  }
  *param_2 = (float)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18169 ; VA 0x0099c9c8 ; Catch_All@0099c9c8 */

void Catch_All_0099c9c8(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 0xc,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_0099f780(unaff_EBP + 8,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18170 ; VA 0x0099c9f0 ; FUN_0099c9f0 */

void __thiscall FUN_0099c9f0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d22e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::GfxGui>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18171 ; VA 0x0099ca5e ; Catch_All@0099ca5e */

void Catch_All_0099ca5e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_009a68d0(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18172 ; VA 0x0099ca80 ; FUN_0099ca80 */

void __thiscall FUN_0099ca80(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d22f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::HUMAN::HumanoidState>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18173 ; VA 0x0099caee ; Catch_All@0099caee */

void Catch_All_0099caee(void)

{
  int unaff_EBP;
  
  if (*(int **)(unaff_EBP + 8) != (int *)0x0) {
    (**(code **)(**(int **)(unaff_EBP + 8) + 4))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18174 ; VA 0x0099cb10 ; FUN_0099cb10 */

void __thiscall FUN_0099cb10(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d2300;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_G3D::Plane>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18175 ; VA 0x0099cb7e ; Catch_All@0099cb7e */

void Catch_All_0099cb7e(void)

{
  int unaff_EBP;
  
  FUN_01674ea0(*(undefined4 *)(unaff_EBP + 8),0x10);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18176 ; VA 0x0099cba0 ; FUN_0099cba0 */

int __thiscall FUN_0099cba0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d2310;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::FilteredSelection<class_RBX::PartInstance>*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18177 ; VA 0x0099cc72 ; Catch_All@0099cc72 */

void Catch_All_0099cc72(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18178 ; VA 0x0099cc90 ; FUN_0099cc90 */

int __thiscall FUN_0099cc90(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d2320;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Value<class_G3D::Vector3>*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18179 ; VA 0x0099cd62 ; Catch_All@0099cd62 */

void Catch_All_0099cd62(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18180 ; VA 0x0099cd80 ; FUN_0099cd80 */

int __thiscall FUN_0099cd80(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d2330;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Animator*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18181 ; VA 0x0099ce52 ; Catch_All@0099ce52 */

void Catch_All_0099ce52(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18182 ; VA 0x0099ce70 ; FUN_0099ce70 */

int __thiscall FUN_0099ce70(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d2340;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Humanoid*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18183 ; VA 0x0099cf42 ; Catch_All@0099cf42 */

void Catch_All_0099cf42(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18184 ; VA 0x0099cf60 ; FUN_0099cf60 */

int __thiscall FUN_0099cf60(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d2350;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::HumanoidDescription*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18185 ; VA 0x0099d032 ; Catch_All@0099d032 */

void Catch_All_0099d032(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18186 ; VA 0x0099d050 ; FUN_0099d050 */

int __thiscall FUN_0099d050(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d2360;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Motor6D*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18187 ; VA 0x0099d122 ; Catch_All@0099d122 */

void Catch_All_0099d122(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18188 ; VA 0x0099d140 ; FUN_0099d140 */

int __thiscall FUN_0099d140(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d2370;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::StatusInstance*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18189 ; VA 0x0099d212 ; Catch_All@0099d212 */

void Catch_All_0099d212(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18190 ; VA 0x0099d230 ; FUN_0099d230 */

int __thiscall FUN_0099d230(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d2380;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::StringValue*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18191 ; VA 0x0099d302 ; Catch_All@0099d302 */

void Catch_All_0099d302(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 18192 ; VA 0x0099d320 ; FUN_0099d320 */

int FUN_0099d320(int param_1,int param_2,int param_3,undefined4 param_4)

{
  void **ppvVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d2398;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  ppvVar1 = &pvStack_10;
  if (param_1 != param_2) {
    do {
      FUN_0099e8e0(param_4,param_3,param_1);
      param_3 = param_3 + 0x10;
      param_1 = param_1 + 0x10;
      ppvVar1 = (void **)ExceptionList;
    } while (param_1 != param_2);
  }
  ExceptionList = ppvVar1;
  uStack_8 = 1;
  FUN_00995940(param_3,param_3,param_4);
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 18193 ; VA 0x0099d3a0 ; FUN_0099d3a0 */

undefined ** __thiscall
FUN_0099d3a0(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  cVar3 = FUN_00963340(param_2,param_3,param_4,param_5,param_1 + 2,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_019397a8;
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = (int)ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    ppuVar4 = (undefined **)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      ppuVar4 = (undefined **)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        ppuVar4 = (undefined **)(**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      ppuVar4 = (undefined **)(**(code **)(*param_3 + 4))();
    }
  }
  return ppuVar4;
}



/* FUNCTION 18194 ; VA 0x0099d4b0 ; FUN_0099d4b0 */

undefined FUN_0099d4b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 *param_8)

{
  char cVar1;
  undefined4 *puVar2;
  undefined uVar3;
  undefined4 *puStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 *apuStack_34 [2];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d23d7;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  apuStack_34[0] = (undefined4 *)0x0;
  puStack_14 = param_1;
  ExceptionList = &pvStack_10;
  if (param_1 != (undefined4 *)0x0) {
    apuStack_34[0] = param_1;
    if (((uint)param_1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)((uint)param_1 & 0xfffffffe))(&param_3,&uStack_2c,0);
    }
    else {
      uStack_2c = param_3;
      uStack_28 = param_4;
      uStack_24 = param_5;
      uStack_20 = param_6;
      uStack_1c = param_7;
      ExceptionList = &pvStack_10;
    }
  }
  puStack_14 = param_1;
  uStack_8._0_1_ = 1;
  cVar1 = FUN_00585a40(apuStack_34);
  if (cVar1 == '\0') {
    puStack_54 = (undefined4 *)0x0;
    if (apuStack_34[0] != (undefined4 *)0x0) {
      puStack_54 = apuStack_34[0];
      if (((uint)apuStack_34[0] & 1) == 0) {
        (**(code **)((uint)apuStack_34[0] & 0xfffffffe))(&uStack_2c,&uStack_4c,0);
      }
      else {
        uStack_4c = uStack_2c;
        uStack_48 = uStack_28;
        uStack_44 = uStack_24;
        uStack_40 = uStack_20;
        uStack_3c = uStack_1c;
      }
    }
    uStack_8._0_1_ = 2;
    puVar2 = (undefined4 *)FUN_01674e20(0x20);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar2;
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = 0;
      if (puStack_54 != (undefined4 *)0x0) {
        *puVar2 = puStack_54;
        if (((uint)puStack_54 & 1) == 0) {
          (**(code **)((uint)puStack_54 & 0xfffffffe))(&uStack_4c,puVar2 + 2,0);
        }
        else {
          puVar2[2] = uStack_4c;
          puVar2[3] = uStack_48;
          puVar2[4] = uStack_44;
          puVar2[5] = uStack_40;
          *(undefined8 *)(puVar2 + 6) = uStack_3c;
        }
      }
    }
    *param_8 = puVar2;
    uStack_8._0_1_ = 4;
    if (((puStack_54 != (undefined4 *)0x0) && (((uint)puStack_54 & 1) == 0)) &&
       (*(code **)((uint)puStack_54 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)((uint)puStack_54 & 0xfffffffe))(&uStack_4c,&uStack_4c,2);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (apuStack_34[0] != (undefined4 *)0x0) {
      if ((((uint)apuStack_34[0] & 1) == 0) &&
         (*(code **)((uint)apuStack_34[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)((uint)apuStack_34[0] & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
      }
      apuStack_34[0] = (undefined4 *)0x0;
    }
    uVar3 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (apuStack_34[0] != (undefined4 *)0x0) {
      if ((((uint)apuStack_34[0] & 1) == 0) &&
         (*(code **)((uint)apuStack_34[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)((uint)apuStack_34[0] & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
        puStack_14 = param_1;
      }
      apuStack_34[0] = (undefined4 *)0x0;
    }
    uVar3 = 0;
    param_1 = puStack_14;
  }
  uStack_8 = 7;
  if (((param_1 != (undefined4 *)0x0) && (((uint)param_1 & 1) == 0)) &&
     (*(code **)((uint)param_1 & 0xfffffffe) != (code *)0x0)) {
    param_8._3_1_ = uVar3;
    (**(code **)((uint)param_1 & 0xfffffffe))(&param_3,&param_3,2);
    ExceptionList = pvStack_10;
    return param_8._3_1_;
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 18195 ; VA 0x0099d6c0 ; FUN_0099d6c0 */

undefined FUN_0099d6c0(undefined4 param_1)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined uVar4;
  uint in_stack_00000054;
  int *in_stack_00000074;
  undefined auStack_ec [72];
  uint uStack_a4;
  undefined auStack_9c [24];
  undefined4 auStack_84 [2];
  undefined auStack_7c [72];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d241a;
  pvStack_10 = ExceptionList;
  auStack_84[0] = param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_009a1b20(&stack0x0000000c);
  uStack_8._0_1_ = 1;
  cVar2 = FUN_00585a40(auStack_84);
  uVar1 = auStack_84[0];
  if (cVar2 == '\0') {
    FUN_009a1b20(auStack_7c);
    uStack_8._0_1_ = 2;
    puVar3 = (undefined4 *)FUN_01674e20(0x70);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uVar1;
      FUN_009a1b20(auStack_ec);
    }
    *in_stack_00000074 = (int)puVar3;
    uStack_8._0_1_ = 4;
    if (uStack_a4 != 0) {
      if (((uStack_a4 & 1) == 0) && (*(code **)(uStack_a4 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_a4 & 0xfffffffe))(auStack_9c,auStack_9c,2);
      }
      uStack_a4 = 0;
    }
    FUN_009a39a0();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_009a39a0();
    uVar4 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_009a39a0();
    uVar4 = 0;
  }
  uStack_8 = 7;
  if (in_stack_00000054 != 0) {
    if (((in_stack_00000054 & 1) == 0) &&
       (*(code **)(in_stack_00000054 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000054 & 0xfffffffe))(&stack0x0000005c,&stack0x0000005c,2);
    }
    in_stack_00000054 = 0;
  }
  FUN_009a39a0();
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 18196 ; VA 0x0099d860 ; FUN_0099d860 */

undefined FUN_0099d860(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,int *param_7,undefined4 param_8,
                      int *param_9)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  char cVar5;
  undefined4 *puVar6;
  undefined uVar7;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d2448;
  pvStack_10 = ExceptionList;
  uStack_34 = param_5;
  uStack_44 = param_1;
  uStack_40 = param_2;
  uStack_3c = param_3;
  uStack_38 = param_4;
  ExceptionList = &pvStack_10;
  if (param_7 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_7[1] = param_7[1] + 1;
    UNLOCK();
  }
  uStack_30 = param_6;
  piStack_2c = param_7;
  uStack_8 = 1;
  uStack_7 = 0;
  cVar5 = FUN_00585a40(&uStack_44);
  piVar2 = piStack_2c;
  uVar4 = uStack_34;
  if (cVar5 == '\0') {
    uStack_24 = uStack_44;
    uStack_20 = uStack_40;
    uStack_1c = uStack_3c;
    uStack_18 = uStack_38;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      piStack_2c[1] = piStack_2c[1] + 1;
      UNLOCK();
    }
    uStack_14 = uStack_30;
    uStack_8 = 2;
    puVar6 = (undefined4 *)FUN_01674e20(0x20);
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      *puVar6 = uStack_24;
      puVar6[1] = uStack_20;
      puVar6[2] = uStack_1c;
      puVar6[3] = uStack_18;
      puVar6[4] = uVar4;
      puVar6[5] = 0;
      puVar6[6] = 0;
      if (piVar2 != (int *)0x0) {
        LOCK();
        piVar2[1] = piVar2[1] + 1;
        UNLOCK();
      }
      puVar6[5] = uStack_14;
      puVar6[6] = piVar2;
    }
    *param_9 = (int)puVar6;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_2c;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar7 = 1;
  }
  else {
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar7 = 0;
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar3 = param_7[1] + -1;
    param_7[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_7)();
      LOCK();
      piVar2 = param_7 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_7 + 4))();
      }
      ExceptionList = pvStack_10;
      return uVar7;
    }
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 18197 ; VA 0x0099da20 ; FUN_0099da20 */

void __thiscall FUN_0099da20(undefined4 *param_1)

{
  bool bVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  undefined **ppuVar5;
  int *piVar6;
  int *in_stack_00000028;
  int aiStack_90 [9];
  int *piStack_6c;
  int aiStack_68 [9];
  int *piStack_44;
  int aiStack_40 [9];
  int *piStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d24b2;
  pvStack_10 = ExceptionList;
  piStack_18 = aiStack_90;
  piStack_6c = (int *)0x0;
  uStack_8 = 1;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (in_stack_00000028 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    piStack_6c = (int *)(**(code **)*in_stack_00000028)(aiStack_90);
  }
  piStack_18 = aiStack_40;
  piStack_1c = (int *)0x0;
  uStack_8 = 3;
  if (piStack_6c != (int *)0x0) {
    piStack_1c = (int *)(**(code **)*piStack_6c)(aiStack_40);
  }
  piVar6 = piStack_6c;
  piVar3 = in_stack_00000028;
  uStack_8 = 4;
  cVar2 = FUN_00585a40(aiStack_40);
  if (cVar2 == '\0') {
    piStack_18 = aiStack_68;
    piStack_44 = (int *)0x0;
    uStack_8 = 5;
    if (piStack_1c != (int *)0x0) {
      piStack_44 = (int *)(**(code **)*piStack_1c)(aiStack_68);
    }
    uStack_8 = 6;
    piVar3 = (int *)FUN_01674e20(0x28);
    uStack_8 = 7;
    piStack_18 = piVar3;
    if (piVar3 == (int *)0x0) {
      piVar3 = (int *)0x0;
    }
    else {
      piVar3[9] = 0;
      uStack_8 = 8;
      if (piStack_44 != (int *)0x0) {
        iVar4 = (**(code **)*piStack_44)(piVar3);
        piVar3[9] = iVar4;
      }
    }
    param_1[2] = piVar3;
    if (piStack_44 != (int *)0x0) {
      (**(code **)(*piStack_44 + 0x10))(piStack_44 != aiStack_68);
      piStack_44 = (int *)0x0;
    }
    if (piStack_1c != (int *)0x0) {
      (**(code **)(*piStack_1c + 0x10))(piStack_1c != aiStack_40);
      piStack_1c = (int *)0x0;
    }
    bVar1 = true;
    piVar6 = piStack_6c;
    piVar3 = in_stack_00000028;
  }
  else {
    if (piStack_1c != (int *)0x0) {
      (**(code **)(*piStack_1c + 0x10))(piStack_1c != aiStack_40);
      piStack_1c = (int *)0x0;
      piVar6 = piStack_6c;
      piVar3 = in_stack_00000028;
    }
    bVar1 = false;
  }
  if (piVar6 != (int *)0x0) {
    (**(code **)(*piVar6 + 0x10))(piVar6 != aiStack_90);
    piVar3 = in_stack_00000028;
  }
  ppuVar5 = &PTR_FUN_01939808;
  if (!bVar1) {
    ppuVar5 = (undefined **)0x0;
  }
  *puStack_14 = ppuVar5;
  if (piVar3 != (int *)0x0) {
    (**(code **)(*piVar3 + 0x10))(piVar3 != (int *)&stack0x00000004);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18198 ; VA 0x0099dbf0 ; FUN_0099dbf0 */

void __thiscall FUN_0099dbf0(undefined4 *param_1)

{
  bool bVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  undefined **ppuVar5;
  int *piVar6;
  int *in_stack_00000028;
  int aiStack_90 [9];
  int *piStack_6c;
  int aiStack_68 [9];
  int *piStack_44;
  int aiStack_40 [9];
  int *piStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d2512;
  pvStack_10 = ExceptionList;
  piStack_18 = aiStack_90;
  piStack_6c = (int *)0x0;
  uStack_8 = 1;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (in_stack_00000028 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    piStack_6c = (int *)(**(code **)*in_stack_00000028)(aiStack_90);
  }
  piStack_18 = aiStack_40;
  piStack_1c = (int *)0x0;
  uStack_8 = 3;
  if (piStack_6c != (int *)0x0) {
    piStack_1c = (int *)(**(code **)*piStack_6c)(aiStack_40);
  }
  piVar6 = piStack_6c;
  piVar3 = in_stack_00000028;
  uStack_8 = 4;
  cVar2 = FUN_00585a40(aiStack_40);
  if (cVar2 == '\0') {
    piStack_18 = aiStack_68;
    piStack_44 = (int *)0x0;
    uStack_8 = 5;
    if (piStack_1c != (int *)0x0) {
      piStack_44 = (int *)(**(code **)*piStack_1c)(aiStack_68);
    }
    uStack_8 = 6;
    piVar3 = (int *)FUN_01674e20(0x28);
    uStack_8 = 7;
    piStack_18 = piVar3;
    if (piVar3 == (int *)0x0) {
      piVar3 = (int *)0x0;
    }
    else {
      piVar3[9] = 0;
      uStack_8 = 8;
      if (piStack_44 != (int *)0x0) {
        iVar4 = (**(code **)*piStack_44)(piVar3);
        piVar3[9] = iVar4;
      }
    }
    param_1[2] = piVar3;
    if (piStack_44 != (int *)0x0) {
      (**(code **)(*piStack_44 + 0x10))(piStack_44 != aiStack_68);
      piStack_44 = (int *)0x0;
    }
    if (piStack_1c != (int *)0x0) {
      (**(code **)(*piStack_1c + 0x10))(piStack_1c != aiStack_40);
      piStack_1c = (int *)0x0;
    }
    bVar1 = true;
    piVar6 = piStack_6c;
    piVar3 = in_stack_00000028;
  }
  else {
    if (piStack_1c != (int *)0x0) {
      (**(code **)(*piStack_1c + 0x10))(piStack_1c != aiStack_40);
      piStack_1c = (int *)0x0;
      piVar6 = piStack_6c;
      piVar3 = in_stack_00000028;
    }
    bVar1 = false;
  }
  if (piVar6 != (int *)0x0) {
    (**(code **)(*piVar6 + 0x10))(piVar6 != aiStack_90);
    piVar3 = in_stack_00000028;
  }
  ppuVar5 = &PTR_FUN_01939800;
  if (!bVar1) {
    ppuVar5 = (undefined **)0x0;
  }
  *puStack_14 = ppuVar5;
  if (piVar3 != (int *)0x0) {
    (**(code **)(*piVar3 + 0x10))(piVar3 != (int *)&stack0x00000004);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18199 ; VA 0x0099ddc0 ; FUN_0099ddc0 */

undefined4 *
FUN_0099ddc0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6,undefined4 param_7,undefined4 param_8,int *param_9,
            undefined4 param_10,int *param_11,undefined4 param_12,uint param_13,undefined4 param_14,
            undefined4 param_15,undefined4 param_16,undefined4 param_17,undefined4 *param_18,
            ulonglong param_19,uint param_20,undefined4 param_21,undefined4 param_22,
            undefined4 param_23,undefined4 param_24,undefined *param_25,undefined8 param_26)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  undefined4 uVar4;
  uint auStack_c8 [2];
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 *puStack_b4;
  ulonglong uStack_b0;
  uint auStack_a8 [2];
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 *puStack_94;
  undefined8 uStack_90;
  uint uStack_38;
  undefined auStack_30 [24];
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d2560;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined *)auStack_a8;
  puStack_18 = (undefined *)auStack_a8;
  uStack_8 = 5;
  auStack_a8[0] = 0;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_a8;
  if (param_20 != 0) {
    auStack_a8[0] = param_20;
    if ((param_20 & 1) == 0) {
      uStack_b0 = ZEXT48(&uStack_a0);
      puStack_b4 = &param_22;
      uStack_b8 = 0x99de28;
      ExceptionList = &pvStack_10;
      (**(code **)(param_20 & 0xfffffffe))();
      puVar3 = (uint *)puStack_14;
    }
    else {
      uStack_a0 = param_22;
      uStack_9c = param_23;
      uStack_98 = param_24;
      puStack_94 = (undefined4 *)param_25;
      uStack_90 = param_26;
      ExceptionList = &pvStack_10;
      puVar3 = auStack_a8;
    }
  }
  puStack_14 = (undefined *)puVar3;
  puStack_18 = (undefined *)auStack_c8;
  uStack_8._0_1_ = 6;
  auStack_c8[0] = 0;
  puVar3 = auStack_c8;
  if (param_13 != 0) {
    auStack_c8[0] = param_13;
    if ((param_13 & 1) == 0) {
      (**(code **)(param_13 & 0xfffffffe))(&param_15,&uStack_c0,0);
      puVar3 = (uint *)puStack_18;
    }
    else {
      uStack_c0 = param_15;
      uStack_bc = param_16;
      uStack_b8 = param_17;
      puStack_b4 = param_18;
      uStack_b0 = param_19;
      puVar3 = auStack_c8;
    }
  }
  puStack_18 = (undefined *)puVar3;
  if (param_11 != (int *)0x0) {
    LOCK();
    param_11[1] = param_11[1] + 1;
    UNLOCK();
  }
  if (param_9 != (int *)0x0) {
    LOCK();
    param_9[1] = param_9[1] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[2] = param_6[2] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 5;
  uVar4 = FUN_009a12f0(param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11,
                       param_12);
  uStack_8._0_1_ = 7;
  *param_1 = param_2;
  uStack_90 = CONCAT44(uVar4,0x99df3f);
  FUN_009a1b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (((uStack_38 != 0) && ((uStack_38 & 1) == 0)) &&
     (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
    puStack_94 = (undefined4 *)auStack_30;
    uStack_90 = CONCAT44(2,puStack_94);
    uStack_98 = 0x99df60;
    (**(code **)(uStack_38 & 0xfffffffe))();
  }
  uStack_90 = CONCAT44(0x99df72,(undefined4)uStack_90);
  FUN_009a39a0();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_90 = CONCAT44(0x99df8a,(undefined4)uStack_90);
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[2] + -1;
    param_6[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_90 = CONCAT44(0x99df9f,(undefined4)uStack_90);
      (**(code **)(*param_6 + 4))();
    }
  }
  if (param_9 != (int *)0x0) {
    LOCK();
    iVar2 = param_9[1] + -1;
    param_9[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_90 = CONCAT44(0x99dfb5,(undefined4)uStack_90);
      (**(code **)*param_9)();
      LOCK();
      iVar2 = param_9[2] + -1;
      param_9[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_90 = CONCAT44(0x99dfc5,(undefined4)uStack_90);
        (**(code **)(*param_9 + 4))();
      }
    }
  }
  if (param_11 != (int *)0x0) {
    LOCK();
    iVar2 = param_11[1] + -1;
    param_11[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_90 = CONCAT44(0x99dfdb,(undefined4)uStack_90);
      (**(code **)*param_11)();
      LOCK();
      piVar1 = param_11 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_90 = CONCAT44(0x99dfea,(undefined4)uStack_90);
        (**(code **)(*param_11 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  if (((param_13 != 0) && ((param_13 & 1) == 0)) &&
     (*(code **)(param_13 & 0xfffffffe) != (code *)0x0)) {
    puStack_94 = &param_15;
    uStack_90 = CONCAT44(2,puStack_94);
    uStack_98 = 0x99e00b;
    (**(code **)(param_13 & 0xfffffffe))();
  }
  uStack_8 = 10;
  if (((param_20 != 0) && ((param_20 & 1) == 0)) &&
     (*(code **)(param_20 & 0xfffffffe) != (code *)0x0)) {
    puStack_94 = &param_22;
    uStack_90 = CONCAT44(2,puStack_94);
    uStack_98 = 0x99e039;
    (**(code **)(param_20 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18200 ; VA 0x0099e050 ; FUN_0099e050 */

undefined4 *
FUN_0099e050(undefined4 *param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_24;
  
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
    piVar1 = param_6 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  piVar1 = param_6 + 1;
  uStack_30 = (undefined4)param_2;
  uStack_2c = (undefined4)((ulonglong)param_2 >> 0x20);
  *param_1 = uStack_30;
  param_1[1] = uStack_2c;
  param_1[2] = param_3;
  param_1[3] = uStack_24;
  param_1[4] = param_4;
  param_1[5] = 0;
  param_1[6] = 0;
  if (param_6 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[5] = param_5;
  param_1[6] = param_6;
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_6 + 4))();
      }
      return param_1;
    }
  }
  return param_1;
}



/* FUNCTION 18201 ; VA 0x0099e180 ; FUN_0099e180 */

undefined4 *
FUN_0099e180(undefined4 *param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,int *param_7)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_24;
  
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[1] = param_7[1] + 1;
    UNLOCK();
    piVar1 = param_7 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_7)();
      LOCK();
      iVar2 = param_7[2] + -1;
      param_7[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_7 + 4))();
      }
    }
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_7)();
      LOCK();
      iVar2 = param_7[2] + -1;
      param_7[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  piVar1 = param_7 + 1;
  uStack_30 = (undefined4)param_2;
  uStack_2c = (undefined4)((ulonglong)param_2 >> 0x20);
  *param_1 = uStack_30;
  param_1[1] = uStack_2c;
  param_1[2] = param_3;
  param_1[3] = uStack_24;
  param_1[4] = param_4;
  param_1[5] = 0;
  param_1[6] = 0;
  if (param_7 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[5] = param_6;
  param_1[6] = param_7;
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_7)();
      LOCK();
      iVar2 = param_7[2] + -1;
      param_7[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_7 + 4))();
      }
      return param_1;
    }
  }
  return param_1;
}



/* FUNCTION 18202 ; VA 0x0099e2b0 ; FUN_0099e2b0 */

undefined4 *
FUN_0099e2b0(undefined4 *param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_24;
  
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
    piVar1 = param_6 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  piVar1 = param_6 + 1;
  uStack_30 = (undefined4)param_2;
  uStack_2c = (undefined4)((ulonglong)param_2 >> 0x20);
  *param_1 = uStack_30;
  param_1[1] = uStack_2c;
  param_1[2] = param_3;
  param_1[3] = uStack_24;
  param_1[4] = param_4;
  param_1[5] = 0;
  param_1[6] = 0;
  if (param_6 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[5] = param_5;
  param_1[6] = param_6;
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_6 + 4))();
      }
      return param_1;
    }
  }
  return param_1;
}



/* FUNCTION 18203 ; VA 0x0099e410 ; FUN_0099e410 */

undefined4 * __thiscall FUN_0099e410(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6248;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0;
  puVar5 = (undefined4 *)FUN_01674e20(0x30);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_009b0500;
    puVar5[3] = _guard_check_icall;
    puVar5[4] = 0;
    puVar5[5] = param_1;
    uVar1 = param_3[1];
    uVar2 = param_3[2];
    uVar3 = param_3[3];
    puVar5[6] = *param_3;
    puVar5[7] = uVar1;
    puVar5[8] = uVar2;
    puVar5[9] = uVar3;
    *(undefined8 *)(puVar5 + 10) = *(undefined8 *)(param_3 + 4);
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18204 ; VA 0x0099e4e0 ; FUN_0099e4e0 */

undefined4 __thiscall
FUN_0099e4e0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7,undefined4 param_8,int *param_9)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 in_stack_ffffff88;
  uint auStack_68 [2];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined4 uStack_48;
  undefined4 uStack_44;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d2598;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_9 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_9[1] = param_9[1] + 1;
    UNLOCK();
  }
  iStack_18 = param_1;
  FUN_0099b630(param_3,param_4,param_5,param_6,param_7,param_8,param_9,in_stack_ffffff88,0);
  uVar2 = *(undefined4 *)(param_1 + 4);
  uStack_8._0_1_ = 1;
  auStack_68[0] = 0;
  uStack_14 = uVar2;
  if (uStack_40 != 0) {
    auStack_68[0] = uStack_40;
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_60,0);
    }
    else {
      uStack_60 = uStack_38;
      uStack_5c = uStack_34;
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
    }
  }
  uStack_8._0_1_ = 2;
  puVar4 = (undefined4 *)FUN_0060dcd0(auStack_20,uVar2);
  if (puVar4[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar4[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_48 = *puVar4;
  uStack_44 = puVar4[1];
  uStack_8._0_1_ = 3;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar3 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  FUN_00b09010();
  uStack_8._0_1_ = 4;
  FUN_0099e760(param_2,auStack_68);
  FUN_009a4a10();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (uStack_40 != 0) {
    if (((uStack_40 & 1) == 0) && (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_38,2);
    }
    uStack_40 = 0;
  }
  if (param_9 != (int *)0x0) {
    LOCK();
    iVar3 = param_9[1] + -1;
    param_9[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_9)();
      LOCK();
      piVar1 = param_9 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_9 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18205 ; VA 0x0099e690 ; FUN_0099e690 */

undefined4 * __thiscall FUN_0099e690(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6248;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0;
  puVar5 = (undefined4 *)FUN_01674e20(0x30);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_009b05f0;
    puVar5[3] = _guard_check_icall;
    puVar5[4] = 0;
    puVar5[5] = param_1;
    uVar1 = param_3[1];
    uVar2 = param_3[2];
    uVar3 = param_3[3];
    puVar5[6] = *param_3;
    puVar5[7] = uVar1;
    puVar5[8] = uVar2;
    puVar5[9] = uVar3;
    *(undefined8 *)(puVar5 + 10) = *(undefined8 *)(param_3 + 4);
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 18206 ; VA 0x0099e760 ; FUN_0099e760 */

undefined4 * FUN_0099e760(undefined4 *param_1,uint *param_2)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  int iStack_28;
  int *piStack_24;
  uint *puStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d25ea;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar6 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0;
  uStack_18 = uVar6;
  puVar7 = (undefined4 *)FUN_01674e20(0x40);
  puStack_1c = puVar7;
  if (puVar7 == (undefined4 *)0x0) {
    puVar7 = (undefined4 *)0x0;
  }
  else {
    *puVar7 = 0;
    puVar7[1] = 1;
    puVar7[2] = FUN_009b06e0;
    puVar7[3] = FUN_009b0810;
    puVar7[4] = 0;
    puVar7[5] = uStack_14;
    puStack_20 = puVar7 + 6;
    *puStack_20 = 0;
    uStack_8._0_1_ = 2;
    uVar2 = *param_2;
    if (uVar2 != 0) {
      *puStack_20 = uVar2;
      if ((uVar2 & 1) == 0) {
        (**(code **)(uVar2 & 0xfffffffe))(param_2 + 2,puVar7 + 8,0);
      }
      else {
        uVar2 = param_2[3];
        uVar4 = param_2[4];
        uVar5 = param_2[5];
        puVar7[8] = param_2[2];
        puVar7[9] = uVar2;
        puVar7[10] = uVar4;
        puVar7[0xb] = uVar5;
        *(undefined8 *)(puVar7 + 0xc) = *(undefined8 *)(param_2 + 6);
      }
    }
    puVar7[0xe] = 0;
    puVar7[0xf] = 0;
    if (param_2[9] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[9] + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    puVar7[0xe] = param_2[8];
    puVar7[0xf] = param_2[9];
    FUN_00587490(&iStack_28);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (iStack_28 != 0) {
      FUN_00b09010();
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_24[1] + -1;
      piStack_24[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar3 = piStack_24[2] + -1;
        piStack_24[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
  }
  uStack_8 = uStack_8 & 0xffffff00;
  FUN_016797d0(puVar7);
  *param_1 = puVar7;
  if (puVar7 != (undefined4 *)0x0) {
    LOCK();
    puVar7[1] = puVar7[1] + 1;
    UNLOCK();
  }
  uStack_8 = 6;
  FUN_01675290(uVar6);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18207 ; VA 0x0099e8e0 ; FUN_0099e8e0 */

void FUN_0099e8e0(undefined4 param_1,undefined8 *param_2,undefined8 *param_3)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *(undefined4 *)((int)param_2 + 0xc) = 0;
  uVar1 = *(uint *)((int)param_3 + 0xc);
  *(uint *)((int)param_2 + 0xc) = uVar1;
  if ((*(uint *)((int)param_3 + 0xc) & 0xfffffff8) != 0) {
    if ((((int)uVar1 >> 1 & 1U) == 0) || ((~(byte)((int)uVar1 >> 2) & 1) != 0)) {
      *param_2 = *param_3;
      *(undefined4 *)(param_2 + 1) = *(undefined4 *)(param_3 + 1);
    }
    else {
      (**(code **)((uVar1 & 0xfffffff8) + 4))(param_2,param_3);
    }
    *(undefined4 *)((int)param_3 + 0xc) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18208 ; VA 0x0099e970 ; FUN_0099e970 */

int * __fastcall FUN_0099e970(int *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  int *piStack_8;
  
  iVar3 = *param_1;
  piStack_8 = param_1;
  iVar2 = FUN_0098d050();
  if (iVar3 == iVar2) {
    piVar6 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar6 = (int *)0x0;
    }
    if (piVar6 != (int *)0x0) {
      return piVar6;
    }
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 != iVar2) {
LAB_0099ea0b:
    thunk_FUN_0098d050();
    uVar4 = FUN_005543f0();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar5,uVar4);
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 == iVar2) {
    iVar3 = param_1[1];
    FUN_0098d050();
    piVar7 = param_1 + 2;
    piVar6 = piVar7;
    if (iVar3 == 0) {
      piVar6 = (int *)0x0;
    }
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    cVar1 = FUN_009cb180(piVar6,&piStack_8);
    if (cVar1 == '\0') goto LAB_0099ea0b;
    FUN_00960eb0(&piStack_8);
    iVar3 = FUN_0098d050();
    *param_1 = iVar3;
    iVar2 = FUN_0098d050();
    if (iVar3 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18209 ; VA 0x0099ea40 ; FUN_0099ea40 */

int * __fastcall FUN_0099ea40(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int *piVar7;
  int *piStack_8;
  
  iVar4 = *param_1;
  piStack_8 = param_1;
  iVar2 = thunk_FUN_009c67e0();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar7 = (int *)0x0;
    }
    if (piVar7 != (int *)0x0) {
      return piVar7;
    }
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 != iVar2) {
LAB_0099eac6:
    thunk_FUN_009c67e0();
    uVar5 = FUN_005543f0();
    uVar6 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar6,uVar5);
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    piVar3 = piVar7;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    cVar1 = FUN_009ae1a0(piVar3,&piStack_8);
    if (cVar1 == '\0') goto LAB_0099eac6;
    FUN_0099b8f0(&piStack_8);
    iVar4 = thunk_FUN_009c67e0();
    *param_1 = iVar4;
    iVar2 = thunk_FUN_009c67e0();
    if (iVar4 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18210 ; VA 0x0099eb00 ; FUN_0099eb00 */

void FUN_0099eb00(undefined4 *param_1,int param_2,uint param_3)

{
  undefined4 *puVar1;
  
  if (param_3 < 0x11) {
    if (param_3 != 0) {
      puVar1 = param_1;
      do {
        *puVar1 = *(undefined4 *)((param_2 - (int)param_1) + (int)puVar1);
        param_3 = param_3 - 1;
        puVar1 = puVar1 + 1;
      } while (param_3 != 0);
    }
    return;
  }
  FUN_0170c6f0();
  return;
}



/* FUNCTION 18211 ; VA 0x0099eb50 ; FUN_0099eb50 */

void FUN_0099eb50(int param_1,int param_2,uint param_3)

{
  uint uVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  
  if (param_3 < 0x11) {
    uVar1 = 0;
    if (3 < param_3) {
      iVar3 = (param_3 - 4 >> 2) + 1;
      uVar1 = iVar3 * 4;
      puVar2 = (undefined4 *)(param_1 + 4);
      puVar4 = (undefined4 *)(param_2 + 0xc);
      do {
        puVar2[-1] = puVar4[-3];
        *puVar2 = *(undefined4 *)((param_2 - param_1) + -0x10 + (int)(puVar2 + 4));
        puVar2[1] = puVar4[-1];
        puVar2[2] = *puVar4;
        iVar3 = iVar3 + -1;
        puVar2 = puVar2 + 4;
        puVar4 = puVar4 + 4;
      } while (iVar3 != 0);
    }
    if (uVar1 < param_3) {
      iVar3 = param_3 - uVar1;
      puVar2 = (undefined4 *)(param_1 + uVar1 * 4);
      do {
        *puVar2 = *(undefined4 *)((int)puVar2 + (param_2 - param_1));
        iVar3 = iVar3 + -1;
        puVar2 = puVar2 + 1;
      } while (iVar3 != 0);
    }
    return;
  }
  FUN_0170c6f0(param_1,param_2,param_3 * 4);
  return;
}



/* FUNCTION 18212 ; VA 0x0099ec10 ; FUN_0099ec10 */

undefined4 * FUN_0099ec10(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d2656;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = thunk_FUN_00897b90();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  uStack_18 = uVar2;
  puVar3 = (undefined4 *)FUN_01674e20(0x70);
  uStack_8._0_1_ = 2;
  puStack_1c = puVar3;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0089a7a0();
    *(undefined *)(puVar3 + 0x15) = 1;
    puVar3[0x16] = RBX::ISelectionBase::vftable;
    *puVar3 = RBX::FilteredSelection<class_RBX::PartInstance>::vftable;
    puVar3[0x16] = RBX::FilteredSelection<class_RBX::PartInstance>::vftable;
    puVar3[0x17] = 0;
    puVar3[0x18] = 0;
    puVar3[0x19] = 0;
    puVar3[0x1a] = 0;
    puVar3[0x1b] = 0;
    uStack_8._0_1_ = 5;
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005542c0("FilteredSelection",0x11);
    uStack_8._0_1_ = 6;
    FUN_008a6520(auStack_34);
    uStack_8._0_1_ = 5;
    if (0xf < uStack_20) {
      uVar5 = uStack_20 + 1;
      uVar4 = auStack_34[0];
      if (0xfff < uVar5) {
        uVar4 = *(uint *)(auStack_34[0] - 4);
        uVar5 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar4,uVar5);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0099cba0(puVar3,puStack_1c);
  uStack_14 = 1;
  uStack_8 = 10;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18213 ; VA 0x0099ed80 ; FUN_0099ed80 */

int FUN_0099ed80(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d2668;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ee4190,&LAB_0099e400);
  uVar2 = FUN_0099f700();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_0086e640();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_0099ec10(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ee4190,&LAB_0099e400);
      uVar2 = FUN_0099f700();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 18214 ; VA 0x0099ef10 ; FUN_0099ef10 */

undefined4 * FUN_0099ef10(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d26b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00dafce0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(100);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00db26d0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0099cc90(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18215 ; VA 0x0099efd0 ; FUN_0099efd0 */

undefined4 * FUN_0099efd0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d26f3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00ae6b40();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x108);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00ae82a0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0099cd80(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18216 ; VA 0x0099f090 ; FUN_0099f090 */

undefined4 * FUN_0099f090(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d2733;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0099be20();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x7e8);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_009a20d0(1);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0099ce70(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18217 ; VA 0x0099f160 ; FUN_0099f160 */

undefined4 * FUN_0099f160(undefined4 *param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d2733;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0099be20();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x7e8);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    iVar1 = *param_2;
    FUN_009a20d0(1);
    *puVar3 = RBX::Humanoid::vftable;
    puVar3[0x15] = RBX::Humanoid::vftable;
    puVar3[0x17] = RBX::Humanoid::vftable;
    puVar3[0x3f] = RBX::Humanoid::vftable;
    puVar3[0x46] = RBX::Humanoid::vftable;
    puVar3[0x4d] = RBX::Humanoid::vftable;
    puVar3[0x53] = RBX::Humanoid::vftable;
    puVar3[0x54] = RBX::Humanoid::vftable;
    *(undefined ***)(*(int *)(puVar3[0x4e] + 4) + 0x138 + (int)puVar3) = RBX::Humanoid::vftable;
    *(int *)(*(int *)(puVar3[0x4e] + 4) + 0x134 + (int)puVar3) = *(int *)(puVar3[0x4e] + 4) + -0x6ac
    ;
    *(bool *)((int)puVar3 + 0x291) = iVar1 == 2;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0099ce70(puVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18218 ; VA 0x0099f2b0 ; FUN_0099f2b0 */

undefined4 * FUN_0099f2b0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d2773;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00e2c3f0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x240);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00e2cd40();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0099cf60(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18219 ; VA 0x0099f370 ; FUN_0099f370 */

undefined4 * FUN_0099f370(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d27b3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c395b0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x9c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c3a9b0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0099d050(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18220 ; VA 0x0099f430 ; FUN_0099f430 */

undefined4 * FUN_0099f430(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d27f3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00e44030();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x14c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00e44130(1);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0099d140(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18221 ; VA 0x0099f500 ; FUN_0099f500 */

undefined4 * FUN_0099f500(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d2830;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00daffe0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x70);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00db28e0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0099d230(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18222 ; VA 0x0099f5c0 ; FUN_0099f5c0 */

void FUN_0099f5c0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_01679490();
  iVar2 = param_2[6];
  if (iVar2 != 0) {
    piVar1 = (int *)(iVar2 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar2);
    }
  }
  uVar3 = param_2[5];
  if (0xf < uVar3) {
    iVar2 = *param_2;
    uVar5 = uVar3 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar3 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 18223 ; VA 0x0099f670 ; FUN_0099f670 */

int FUN_0099f670(undefined4 param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_01679490();
  iVar3 = *(int *)(param_2 + 8);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    iVar4 = iVar4 + -1;
    if (iVar4 == 0) {
      iVar4 = FUN_01674ea0(iVar3);
    }
  }
  piVar1 = *(int **)(param_2 + 4);
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar2 = piVar1 + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar4 = (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar4 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 18224 ; VA 0x0099f700 ; FUN_0099f700 */

undefined4 FUN_0099f700(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d284c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee419c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee419c);
    if (DAT_01ee419c == -1) {
      uStack_8 = 0;
      DAT_01ee4198 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ee419c);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ee4198;
}



/* FUNCTION 18225 ; VA 0x0099f780 ; FUN_0099f780 */

void __thiscall FUN_0099f780(int param_1,int *param_2,int *param_3)

{
  byte *pbVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  int *piVar5;
  uint uVar6;
  
  piVar5 = param_3 + 2;
  if (0xf < (uint)param_3[7]) {
    piVar5 = (int *)*piVar5;
  }
  uVar3 = 0;
  uVar6 = 0x811c9dc5;
  if (param_3[6] != 0) {
    do {
      pbVar1 = (byte *)(uVar3 + (int)piVar5);
      uVar3 = uVar3 + 1;
      uVar6 = (*pbVar1 ^ uVar6) * 0x1000193;
    } while (uVar3 < (uint)param_3[6]);
  }
  iVar2 = (*(uint *)(param_1 + 0x18) & uVar6) * 8;
  piVar5 = *(int **)(*(int *)(param_1 + 0xc) + iVar2);
  piVar4 = (int *)(*(int *)(param_1 + 0xc) + iVar2);
  if ((int *)piVar4[1] == param_3) {
    if (piVar5 == param_3) {
      *piVar4 = *(int *)(param_1 + 4);
      *(undefined4 *)(iVar2 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar4[1] = param_3[1];
    }
  }
  else if (piVar5 == param_3) {
    *piVar4 = *param_3;
  }
  iVar2 = *param_3;
  *(int *)param_3[1] = iVar2;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_009a6fc0(param_3);
  *param_2 = iVar2;
  return;
}



/* FUNCTION 18226 ; VA 0x0099f830 ; FUN_0099f830 */

int FUN_0099f830(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00dafce0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 18227 ; VA 0x0099f870 ; FUN_0099f870 */

int __fastcall FUN_0099f870(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_00d6bbd0();
  iVar3 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar3 = param_1;
  }
  return iVar3;
}



/* FUNCTION 18228 ; VA 0x0099f8a0 ; FUN_0099f8a0 */

int FUN_0099f8a0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00ec3600();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 18229 ; VA 0x0099f8e0 ; FUN_0099f8e0 */

int FUN_0099f8e0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00daffe0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 18230 ; VA 0x0099f920 ; FUN_0099f920 */

int * FUN_0099f920(int *param_1,int *param_2)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if ((*param_2 == 0) ||
     (iVar7 = *(int *)(*param_2 + 0xc), iVar5 = thunk_FUN_00897b90(),
     (uint)*(ushort *)(iVar5 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
    piStack_c = (int *)0x0;
    puVar6 = &uStack_10;
    bVar3 = false;
    bVar2 = true;
    iVar7 = 0;
  }
  else {
    piStack_14 = (int *)param_2[1];
    iVar7 = *param_2;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = (int *)param_2[1];
    }
    puVar6 = &uStack_18;
    bVar3 = true;
    bVar2 = false;
  }
  iVar5 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  piVar4 = piStack_c;
  param_1[1] = iVar5;
  *param_1 = iVar7;
  if ((bVar2) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_c[1] + -1;
    piStack_c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_14;
  if ((bVar3) && (piStack_14 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_14[1] + -1;
    piStack_14[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 18231 ; VA 0x0099fa10 ; FUN_0099fa10 */

int __fastcall FUN_0099fa10(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
      iVar3 = *piVar6;
      if ((iVar3 != 0) &&
         (iVar4 = *(int *)(iVar3 + 0xc), iVar5 = FUN_00ae6b40(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        return iVar3;
      }
    }
  }
  return 0;
}



/* FUNCTION 18232 ; VA 0x0099fa70 ; FUN_0099fa70 */

int __fastcall FUN_0099fa70(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
      iVar3 = *piVar6;
      if ((iVar3 != 0) &&
         (iVar4 = *(int *)(iVar3 + 0xc), iVar5 = FUN_00d6bbd0(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        return iVar3;
      }
    }
  }
  return 0;
}



/* FUNCTION 18233 ; VA 0x0099fad0 ; FUN_0099fad0 */

int __fastcall FUN_0099fad0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
      iVar3 = *piVar6;
      if ((iVar3 != 0) &&
         (iVar4 = *(int *)(iVar3 + 0xc), iVar5 = FUN_00a697d0(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        return iVar3;
      }
    }
  }
  return 0;
}



/* FUNCTION 18234 ; VA 0x0099fb30 ; FUN_0099fb30 */

int __fastcall FUN_0099fb30(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
      iVar3 = *piVar6;
      if ((iVar3 != 0) &&
         (iVar4 = *(int *)(iVar3 + 0xc), iVar5 = FUN_00db9c60(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        return iVar3;
      }
    }
  }
  return 0;
}



/* FUNCTION 18235 ; VA 0x0099fb90 ; FUN_0099fb90 */

int __fastcall FUN_0099fb90(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
      iVar3 = *piVar6;
      if ((iVar3 != 0) &&
         (iVar4 = *(int *)(iVar3 + 0xc), iVar5 = FUN_00cffc50(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        return iVar3;
      }
    }
  }
  return 0;
}



/* FUNCTION 18236 ; VA 0x0099fbf0 ; FUN_0099fbf0 */

int __fastcall FUN_0099fbf0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
      iVar3 = *piVar6;
      if ((iVar3 != 0) &&
         (iVar4 = *(int *)(iVar3 + 0xc), iVar5 = FUN_00d0f2a0(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        return iVar3;
      }
    }
  }
  return 0;
}



/* FUNCTION 18237 ; VA 0x0099fc50 ; thunk_FUN_0098d050 */

undefined * thunk_FUN_0098d050(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d0e2c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee33b4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee33b4);
    if (DAT_01ee33b4 == -1) {
      uStack_8 = 0;
      FUN_009a0d40();
      FUN_016f3654(&LAB_01885bf0);
      FUN_016f37bf(&DAT_01ee33b4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee3350;
}



/* FUNCTION 18238 ; VA 0x0099fc60 ; FUN_0099fc60 */

void __thiscall FUN_0099fc60(undefined4 param_1,int *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x18,param_1);
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count_obj<class_std::vector<class_std::shared_ptr<class_RBX::HumanoidAssetRequirement>,class_std::allocator<class_std::shared_ptr<class_RBX::HumanoidAssetRequirement>_>_>_>
              ::vftable;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    *param_2 = (int)(puVar1 + 3);
    param_2[1] = (int)puVar1;
    return;
  }
  param_2[1] = 0;
  *param_2 = 0xc;
  return;
}



/* FUNCTION 18239 ; VA 0x0099fcc0 ; FUN_0099fcc0 */

int __thiscall FUN_0099fcc0(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  FUN_0099c9f0(param_2,param_2);
  *param_1 = 0;
  piVar3 = (int *)param_1[1];
  iVar4 = 0;
  param_1[1] = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  return iVar4;
}



/* FUNCTION 18240 ; VA 0x0099fd30 ; thunk_FUN_009c6730 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_009c6730(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5636;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee3e0c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee3e0c);
    if (DAT_01ee3e0c == -1) {
      uStack_8 = 0;
      FUN_009ca470("BodyPartR15");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee3da8 = RBX::Reflection::EnumDesc<enum_RBX::Humanoid::R15PartType>::vftable;
      FUN_009caf20(&DAT_01d64fb0,0x11);
      FUN_016f3654(&LAB_01886d50);
      FUN_016f37bf(&DAT_01ee3e0c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee3da8;
}



/* FUNCTION 18241 ; VA 0x0099fd40 ; thunk_FUN_009c67e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * __fastcall thunk_FUN_009c67e0(undefined4 param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5656;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee40e4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee40e4,param_1);
    if (DAT_01ee40e4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("HumanoidStateType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      puVar4 = &DAT_019386a0;
      _DAT_01ee4080 = RBX::Reflection::EnumDesc<enum_RBX::HUMAN::StateType>::vftable;
      iVar3 = 0;
      iVar5 = 0x10;
      do {
        uVar1 = *puVar4;
        uVar2 = FUN_00dc3b10(uVar1);
        FUN_009cada0(uVar1,uVar2);
        iVar3 = iVar3 + 1;
        puVar4 = puVar4 + 1;
      } while (iVar3 != iVar5);
      FUN_009cada0(0x12,&DAT_0192ff80);
      FUN_016f3654(&LAB_01886d70);
      FUN_016f37bf(&DAT_01ee40e4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee4080;
}



/* FUNCTION 18242 ; VA 0x0099fd50 ; thunk_FUN_009c68d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_009c68d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5676;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee3edc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee3edc);
    if (DAT_01ee3edc == -1) {
      uStack_8 = 0;
      FUN_009ca470(&DAT_018c3d40);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee3e78 = RBX::Reflection::EnumDesc<enum_RBX::Humanoid::Status>::vftable;
      FUN_009caf20(&DAT_01d65038,2);
      FUN_016f3654(&LAB_01886d90);
      FUN_016f37bf(&DAT_01ee3edc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee3e78;
}



/* FUNCTION 18243 ; VA 0x0099fd60 ; FUN_0099fd60 */

void __thiscall FUN_0099fd60(int param_1,undefined4 param_2,int *param_3)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  code *pcStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d2878;
  pvStack_10 = ExceptionList;
  iVar6 = *param_3;
  iVar4 = *(int *)(iVar6 + 0xd0);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088cdc0();
  if (iVar4 != iVar2) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar3 = (undefined4 *)(iVar6 + 0xd8);
  if (*(int *)(iVar6 + 0xd4) == 0) {
    puVar3 = (undefined4 *)0x0;
  }
  iVar6 = puVar3[1];
  if (iVar6 != 0) {
    LOCK();
    *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
    UNLOCK();
    iVar6 = puVar3[1];
  }
  uVar1 = *puVar3;
  param_3 = (int *)*param_3;
  uStack_8 = 0;
  iVar4 = *param_3;
  iVar2 = FUN_0088cdc0();
  if (iVar4 == iVar2) {
    piVar5 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar5 = (int *)0x0;
    }
    iVar4 = piVar5[1];
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
      UNLOCK();
      iVar4 = piVar5[1];
    }
    iVar2 = *piVar5;
    uStack_8 = 2;
    pcStack_30 = (code *)*(undefined8 *)(param_1 + 0x38);
    (*pcStack_30)(1);
    FUN_0089bce0(iVar2,iVar4,uVar1,iVar6);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 18244 ; VA 0x0099fea0 ; FUN_0099fea0 */

undefined4 FUN_0099fea0(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 < param_3) {
LAB_009a001d:
    uStack_8 = 0xffffffff;
    if ((undefined4 *)*param_5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar4);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_5;
  }
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar1 = FUN_009d1bf0(param_1,param_2,&iStack_ec,1);
  iVar5 = iStack_ec;
  if (cVar1 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    goto LAB_009a001d;
  }
  iVar2 = FUN_009c6730();
  iVar4 = iStack_ec;
  if (iVar5 == iVar2) {
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    if (puVar3 != (undefined4 *)0x0) goto LAB_0099ffc8;
  }
  iVar2 = FUN_0088cb40();
  iVar5 = iStack_ec;
  if (iVar4 == iVar2) {
    iVar4 = FUN_0088cb40();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    FUN_009c6730();
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    cVar1 = FUN_009cb180(puVar3,&param_3);
    if (cVar1 != '\0') {
      FUN_0099b8a0(&param_3);
      iVar4 = FUN_009c6730();
      iStack_ec = iVar4;
      iVar5 = FUN_009c6730();
      if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar3 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
LAB_0099ffc8:
      uVar6 = *puVar3;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
  }
  thunk_FUN_009c6730();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 18245 ; VA 0x009a00a0 ; FUN_009a00a0 */

undefined4 FUN_009a00a0(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 < param_3) {
LAB_009a0233:
    uStack_8 = 0xffffffff;
    if ((undefined4 *)*param_5 != (undefined4 *)0x0) {
      ExceptionList = pvStack_10;
      return *(undefined4 *)*param_5;
    }
    FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar4);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar1 = FUN_009d1bf0(param_1,param_2,&iStack_ec,1);
  iVar5 = iStack_ec;
  if (cVar1 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    goto LAB_009a0233;
  }
  iVar2 = FUN_009c68d0();
  iVar4 = iStack_ec;
  if (iVar5 == iVar2) {
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    if (puVar3 != (undefined4 *)0x0) goto LAB_009a01de;
  }
  iVar2 = FUN_0088cb40();
  iVar5 = iStack_ec;
  if (iVar4 == iVar2) {
    iVar4 = FUN_0088cb40();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    iVar4 = FUN_0058eea0("Poison",0);
    if (iVar4 == 0) {
      iVar4 = FUN_0058eea0("Confusion",0);
      if (iVar4 == 0) goto LAB_009a0282;
      param_3 = 1;
    }
    else {
      param_3 = 0;
    }
    FUN_0099b940(&param_3);
    iVar4 = FUN_009c68d0();
    iStack_ec = iVar4;
    iVar5 = FUN_009c68d0();
    if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
LAB_009a01de:
    uVar6 = *puVar3;
    uStack_8 = 1;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    ExceptionList = pvStack_10;
    return uVar6;
  }
LAB_009a0282:
  thunk_FUN_009c68d0();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 18246 ; VA 0x009a02b0 ; FUN_009a02b0 */

void * __thiscall FUN_009a02b0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  code *pcVar5;
  void *pvVar6;
  int *piVar7;
  undefined4 *puVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a0698;
  puVar8 = *(undefined4 **)(param_1 + 0x2c);
  pvVar6 = ExceptionList;
  if (puVar8 != (undefined4 *)0x0) {
    piVar7 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar7 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar7[1] = piVar7[1] + 1;
      UNLOCK();
      piVar7 = *(int **)(param_1 + 0x30);
      puVar8 = *(undefined4 **)(param_1 + 0x2c);
    }
    puVar4 = (undefined4 *)puVar8[1];
    puVar8 = (undefined4 *)*puVar8;
    uStack_8 = 0;
    pvVar6 = pvStack_10;
    for (; puVar8 != puVar4; puVar8 = puVar8 + 2) {
      pcVar5 = (code *)*param_2;
      uVar2 = param_2[1];
      if (puVar8[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar8[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      (*pcVar5)(*puVar8,puVar8[1],uVar2);
      pvVar6 = (void *)FUN_009a02b0(param_2);
    }
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar1 = piVar7 + 1;
      iVar3 = *piVar1;
      pvVar6 = (void *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        pvVar6 = (void *)(**(code **)*piVar7)();
        LOCK();
        piVar1 = piVar7 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          pvVar6 = (void *)(**(code **)(*piVar7 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar6;
}



/* FUNCTION 18247 ; VA 0x009a03a0 ; FUN_009a03a0 */

undefined4 * __thiscall FUN_009a03a0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d28b3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[0xb] = 0;
  uStack_8 = 1;
  uStack_7 = 0;
  if ((undefined4 *)param_2[0xb] != (undefined4 *)0x0) {
    uVar2 = (*(code *)**(undefined4 **)param_2[0xb])(param_1 + 2);
    param_1[0xb] = uVar2;
  }
  param_1[0x15] = 0;
  _uStack_8 = CONCAT31(uStack_7,3);
  if ((undefined4 *)param_2[0x15] != (undefined4 *)0x0) {
    uVar2 = (*(code *)**(undefined4 **)param_2[0x15])(param_1 + 0xc);
    param_1[0x15] = uVar2;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18248 ; VA 0x009a0450 ; FUN_009a0450 */

undefined4 * __thiscall FUN_009a0450(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d28d3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  uVar2 = param_2[2];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[2] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar3 = param_2[5];
      uVar4 = param_2[6];
      uVar5 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar3;
      param_1[6] = uVar4;
      param_1[7] = uVar5;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = 0;
  uVar2 = param_2[10];
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (uVar2 != 0) {
    param_1[10] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0xd];
      uVar4 = param_2[0xe];
      uVar5 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar3;
      param_1[0xe] = uVar4;
      param_1[0xf] = uVar5;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 18249 ; VA 0x009a0550 ; FUN_009a0550 */

undefined4 * __thiscall
FUN_009a0550(undefined4 *param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d292b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_0099be20();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  *(undefined8 *)(param_1 + 0xe) = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::Humanoid,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
             ::vftable;
  param_1[0x10] = param_3;
  param_1[0x11] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_0088cdc0();
  param_1[9] = uVar2;
  puVar3 = (undefined4 *)param_1[0x11];
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088cdc0();
    iStack_e4 = 0;
    if (puVar3[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar3[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e0 = *puVar3;
    uStack_dc = puVar3[1];
    iStack_e4 = FUN_006309e0();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(&uStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}


