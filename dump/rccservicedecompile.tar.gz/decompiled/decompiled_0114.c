/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 28500 ; VA 0x00c4ebc0 ; FUN_00c4ebc0 */

void FUN_00c4ebc0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00c51570();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28501 ; VA 0x00c4ec00 ; FUN_00c4ec00 */

void FUN_00c4ec00(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00c51600();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28502 ; VA 0x00c4ec40 ; FUN_00c4ec40 */

void FUN_00c4ec40(undefined4 param_1,undefined4 param_2)

{
  char cVar1;
  int *piVar2;
  int **ppiVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  int *piStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int **ppiStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180aa50;
  pvStack_10 = ExceptionList;
  piStack_20 = (int *)0x0;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  piStack_20 = (int *)FUN_00575ad0();
  ppiStack_14 = &piStack_20;
  iStack_8 = 0;
  FUN_00c4c9a0(&ppiStack_14);
  uVar8 = 0;
  iVar5 = FUN_005d6c30();
  if (iVar5 != 0) {
    do {
      FUN_0089d950(&iStack_18,3);
      iStack_8._0_1_ = 1;
      if (iStack_18 != 0) {
        FUN_008a65e0(param_2,0);
      }
      ppiVar3 = ppiStack_14;
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (ppiStack_14 != (int **)0x0) {
        LOCK();
        piVar7 = (int *)((int)ppiStack_14[1] + -1);
        ppiStack_14[1] = piVar7;
        UNLOCK();
        if (piVar7 == (int *)0x0) {
          (*(code *)**ppiVar3)();
          LOCK();
          piVar7 = (int *)((int)ppiVar3[2] + -1);
          ppiVar3[2] = piVar7;
          UNLOCK();
          if (piVar7 == (int *)0x0) {
            (*(code *)(*ppiVar3)[1])();
          }
        }
      }
      uVar8 = uVar8 + 1;
      uVar6 = FUN_005d6c30();
    } while (uVar8 < uVar6);
  }
  piVar7 = (int *)*piStack_20;
  if (piVar7 != piStack_20) {
    do {
      (**(code **)(*(int *)piVar7[4] + 0x1c))
                (CONCAT31((int3)((uint)*(int *)piVar7[4] >> 8),*(undefined *)(piVar7 + 6)));
      piVar2 = (int *)piVar7[2];
      if (*(char *)((int)piVar2 + 0xd) == '\0') {
        cVar1 = *(char *)(*piVar2 + 0xd);
        piVar7 = piVar2;
        piVar2 = (int *)*piVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*piVar2 + 0xd);
          piVar7 = piVar2;
          piVar2 = (int *)*piVar2;
        }
      }
      else {
        cVar1 = *(char *)(piVar7[1] + 0xd);
        piVar4 = (int *)piVar7[1];
        piVar2 = piVar7;
        while ((piVar7 = piVar4, cVar1 == '\0' && (piVar2 == (int *)piVar7[2]))) {
          cVar1 = *(char *)(piVar7[1] + 0xd);
          piVar4 = (int *)piVar7[1];
          piVar2 = piVar7;
        }
      }
    } while (piVar7 != piStack_20);
  }
  piVar7 = piStack_20;
  iStack_8 = 2;
  FUN_00882a90(piStack_20[1]);
  piStack_20[1] = (int)piVar7;
  *piStack_20 = (int)piVar7;
  piStack_20[2] = (int)piVar7;
  uStack_1c = 0;
  FUN_01674ea0(piStack_20,0x1c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28503 ; VA 0x00c4edb0 ; FUN_00c4edb0 */

undefined4 * FUN_00c4edb0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00916720(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 28504 ; VA 0x00c4ee20 ; FUN_00c4ee20 */

undefined4 * FUN_00c4ee20(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00bb28e0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 28505 ; VA 0x00c4ee90 ; FUN_00c4ee90 */

undefined4 * FUN_00c4ee90(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00bb29a0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 28506 ; VA 0x00c4ef00 ; FUN_00c4ef00 */

undefined4 *
FUN_00c4ef00(undefined4 *param_1,int param_2,int *param_3,undefined4 *param_4,int *param_5,
            undefined4 param_6,int *param_7)

{
  int *piVar1;
  undefined4 uVar2;
  char cVar3;
  int iVar4;
  undefined4 *puStack_4c;
  int *piStack_48;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined auStack_18 [4];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180aa98;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  piStack_48 = (int *)0xc4ef2a;
  ExceptionList = &pvStack_10;
  cVar3 = FUN_00554b40();
  if (cVar3 == '\0') {
    piStack_48 = (int *)param_6;
    puStack_4c = (undefined4 *)0xc4ef96;
    iVar4 = FUN_008f7870();
    if (iVar4 != 0) {
      piStack_48 = (int *)0xc4efa9;
      iVar4 = FUN_0055ea10();
      if (iVar4 != 0) {
        puStack_14 = (undefined *)&puStack_4c;
        if (param_5 != (int *)0x0) {
          LOCK();
          param_5[1] = param_5[1] + 1;
          UNLOCK();
        }
        puStack_4c = param_4;
        piStack_48 = param_5;
        uStack_8._0_1_ = 5;
        FUN_0054ef60(param_2 + 4);
        uStack_8._0_1_ = 2;
        FUN_0094a3b0();
        piStack_48 = (int *)(param_2 + 4);
        puStack_4c = (undefined4 *)0xc4f010;
        piStack_48 = (int *)FUN_0054ef60();
        uStack_8._0_1_ = 6;
        puStack_4c = (undefined4 *)0xc4f01c;
        iVar4 = FUN_008a1240();
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        piStack_48 = (int *)0xc4f02a;
        FUN_005507b0();
        if (iVar4 != 0) {
          puStack_4c = param_1;
          piStack_48 = (int *)iVar4;
          FUN_0060dcd0();
          piStack_48 = (int *)0xc4f043;
          FUN_00550b30();
          piStack_48 = (int *)0xc4f04b;
          FUN_00550b30();
          piStack_48 = (int *)0xc4f053;
          FUN_00550b30();
          ExceptionList = pvStack_10;
          return param_1;
        }
      }
    }
    *param_1 = 0;
    param_1[1] = 0;
  }
  else {
    piStack_48 = &uStack_20;
    puStack_4c = (undefined4 *)0xc4ef37;
    FUN_00b73ec0();
    puStack_4c = (undefined4 *)(param_2 + 0x34);
    uStack_8._0_1_ = 3;
    piStack_48 = (int *)FUN_00886c00(auStack_18);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    puStack_4c = (undefined4 *)0xc4ef5d;
    FUN_00b75530();
    piStack_48 = (int *)0xc4ef65;
    FUN_0056e380();
    piStack_48 = (int *)0xc4ef6d;
    FUN_0056e380();
    uVar2 = uStack_20;
    uStack_20 = 0;
    *param_1 = uVar2;
    param_1[1] = uStack_1c;
    uStack_1c = 0;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar4 = param_3[1] + -1;
    param_3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      piStack_48 = (int *)0xc4f08f;
      (**(code **)*param_3)();
      LOCK();
      iVar4 = param_3[2] + -1;
      param_3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        piStack_48 = (int *)0xc4f09f;
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar4 = param_5[1] + -1;
    param_5[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      piStack_48 = (int *)0xc4f0b5;
      (**(code **)*param_5)();
      LOCK();
      iVar4 = param_5[2] + -1;
      param_5[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        piStack_48 = (int *)0xc4f0c5;
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar4 = param_7[1] + -1;
    param_7[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      piStack_48 = (int *)0xc4f0db;
      (**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        piStack_48 = (int *)0xc4f0ea;
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28507 ; VA 0x00c4f100 ; FUN_00c4f100 */

void FUN_00c4f100(undefined4 param_1,int param_2,int param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c3f8;
  pvStack_10 = ExceptionList;
  param_1 = param_2;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675290(DAT_01efcd28);
  uStack_8 = 0;
  if ((param_3 == 1) && (param_1 == 0)) {
    FUN_00c4d6d0();
    FUN_01679490();
  }
  uStack_8 = 1;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28508 ; VA 0x00c4f180 ; FUN_00c4f180 */

void FUN_00c4f180(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  
  iVar1 = *(int *)(param_1 + 0x18);
  cVar4 = FUN_00983210(iVar1);
  if (((cVar4 == '\0') && (iVar5 = FUN_0097bfc0(iVar1), iVar5 != 0)) &&
     (piVar7 = *(int **)(iVar5 + 0x2c), piVar7 != (int *)0x0)) {
    piVar2 = (int *)piVar7[1];
    piVar7 = (int *)*piVar7;
    if (piVar7 != piVar2) {
      while ((iVar5 = *piVar7, iVar5 == 0 ||
             (iVar3 = *(int *)(iVar5 + 0xc), iVar6 = FUN_00c4b770(),
             (uint)*(ushort *)(iVar6 + 0x1da) <
             (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)))) {
        piVar7 = piVar7 + 2;
        if (piVar7 == piVar2) {
          return;
        }
      }
      if ((iVar5 != 0) && (iVar1 != 0)) {
        FUN_00c4ec40(iVar1,iVar5);
      }
    }
  }
  return;
}



/* FUNCTION 28509 ; VA 0x00c4f220 ; FUN_00c4f220 */

undefined4 FUN_00c4f220(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  undefined auStack_20 [12];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180aac7;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01256300(param_2);
  iVar1 = param_3;
  iVar3 = iVar3 - param_3;
  if (0 < iVar3) {
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd3fc)
       && (FUN_016f3809(&DAT_01efd3fc), DAT_01efd3fc == -1)) {
      uStack_8 = 0;
      FUN_00cbe0b0();
      FUN_016f3654(&LAB_01895180);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01efd3fc);
    }
    cVar2 = FUN_009d1e20(&DAT_01efd398,param_2,iVar1 + 1,&param_3);
    iVar5 = param_3;
    if (cVar2 != '\0') goto LAB_00c4f344;
  }
  if (0 < iVar3) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    uStack_8 = 1;
    cVar2 = FUN_009d1bf0(param_2,iVar1 + 1,&uStack_f0,1);
    if (cVar2 != '\0') {
      piVar4 = (int *)FUN_00cbd5c0();
      iVar5 = *piVar4;
      uStack_8 = 2;
      if (iStack_ec != 0) {
        (**(code **)(iStack_ec + 8))(auStack_e8);
      }
      uStack_8 = 0xffffffff;
      goto LAB_00c4f344;
    }
    uStack_8 = 3;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
    uStack_8 = 0xffffffff;
  }
  if (*(int **)(iStack_14 + 0x40) == (int *)0x0) {
    FUN_016756b0(auStack_20,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_20,&DAT_01c17198);
  }
  iVar5 = **(int **)(iStack_14 + 0x40);
LAB_00c4f344:
  (**(code **)(iStack_14 + 0x38))(iVar5);
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 28510 ; VA 0x00c4f3e0 ; FUN_00c4f3e0 */

undefined4 FUN_00c4f3e0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  undefined auStack_20 [12];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180aaf7;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01256300(param_2);
  iVar1 = param_3;
  iVar3 = iVar3 - param_3;
  if (0 < iVar3) {
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd4cc)
       && (FUN_016f3809(&DAT_01efd4cc), DAT_01efd4cc == -1)) {
      uStack_8 = 0;
      FUN_00cbe110();
      FUN_016f3654(&LAB_018951a0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01efd4cc);
    }
    cVar2 = FUN_009d1e20(&DAT_01efd468,param_2,iVar1 + 1,&param_3);
    iVar5 = param_3;
    if (cVar2 != '\0') goto LAB_00c4f504;
  }
  if (0 < iVar3) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    uStack_8 = 1;
    cVar2 = FUN_009d1bf0(param_2,iVar1 + 1,&uStack_f0,1);
    if (cVar2 != '\0') {
      piVar4 = (int *)FUN_00cbd690();
      iVar5 = *piVar4;
      uStack_8 = 2;
      if (iStack_ec != 0) {
        (**(code **)(iStack_ec + 8))(auStack_e8);
      }
      uStack_8 = 0xffffffff;
      goto LAB_00c4f504;
    }
    uStack_8 = 3;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
    uStack_8 = 0xffffffff;
  }
  if (*(int **)(iStack_14 + 0x40) == (int *)0x0) {
    FUN_016756b0(auStack_20,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_20,&DAT_01c17198);
  }
  iVar5 = **(int **)(iStack_14 + 0x40);
LAB_00c4f504:
  (**(code **)(iStack_14 + 0x38))(iVar5);
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 28511 ; VA 0x00c4f5a0 ; FUN_00c4f5a0 */

undefined4 FUN_00c4f5a0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  undefined auStack_20 [12];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ab27;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01256300(param_2);
  iVar1 = param_3;
  iVar3 = iVar3 - param_3;
  if (0 < iVar3) {
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd464)
       && (FUN_016f3809(&DAT_01efd464), DAT_01efd464 == -1)) {
      uStack_8 = 0;
      FUN_00cbe170();
      FUN_016f3654(&LAB_018951c0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01efd464);
    }
    cVar2 = FUN_009d1e20(&DAT_01efd400,param_2,iVar1 + 1,&param_3);
    iVar5 = param_3;
    if (cVar2 != '\0') goto LAB_00c4f6c4;
  }
  if (0 < iVar3) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    uStack_8 = 1;
    cVar2 = FUN_009d1bf0(param_2,iVar1 + 1,&uStack_f0,1);
    if (cVar2 != '\0') {
      piVar4 = (int *)FUN_00cbd760();
      iVar5 = *piVar4;
      uStack_8 = 2;
      if (iStack_ec != 0) {
        (**(code **)(iStack_ec + 8))(auStack_e8);
      }
      uStack_8 = 0xffffffff;
      goto LAB_00c4f6c4;
    }
    uStack_8 = 3;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
    uStack_8 = 0xffffffff;
  }
  if (*(int **)(iStack_14 + 0x40) == (int *)0x0) {
    FUN_016756b0(auStack_20,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_20,&DAT_01c17198);
  }
  iVar5 = **(int **)(iStack_14 + 0x40);
LAB_00c4f6c4:
  (**(code **)(iStack_14 + 0x38))(iVar5);
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 28512 ; VA 0x00c4f760 ; FUN_00c4f760 */

undefined4 FUN_00c4f760(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  undefined auStack_20 [12];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ab57;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01256300(param_2);
  iVar1 = param_3;
  iVar3 = iVar3 - param_3;
  if (0 < iVar3) {
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd534)
       && (FUN_016f3809(&DAT_01efd534), DAT_01efd534 == -1)) {
      uStack_8 = 0;
      FUN_00cbe1d0();
      FUN_016f3654(&LAB_018951e0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01efd534);
    }
    cVar2 = FUN_009d1e20(&DAT_01efd4d0,param_2,iVar1 + 1,&param_3);
    iVar5 = param_3;
    if (cVar2 != '\0') goto LAB_00c4f884;
  }
  if (0 < iVar3) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    uStack_8 = 1;
    cVar2 = FUN_009d1bf0(param_2,iVar1 + 1,&uStack_f0,1);
    if (cVar2 != '\0') {
      piVar4 = (int *)FUN_00cbd830();
      iVar5 = *piVar4;
      uStack_8 = 2;
      if (iStack_ec != 0) {
        (**(code **)(iStack_ec + 8))(auStack_e8);
      }
      uStack_8 = 0xffffffff;
      goto LAB_00c4f884;
    }
    uStack_8 = 3;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
    uStack_8 = 0xffffffff;
  }
  if (*(int **)(iStack_14 + 0x40) == (int *)0x0) {
    FUN_016756b0(auStack_20,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_20,&DAT_01c17198);
  }
  iVar5 = **(int **)(iStack_14 + 0x40);
LAB_00c4f884:
  (**(code **)(iStack_14 + 0x38))(iVar5);
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 28513 ; VA 0x00c4f920 ; FUN_00c4f920 */

void __thiscall FUN_00c4f920(byte *param_1,undefined4 *param_2,undefined4 param_3)

{
  undefined4 uVar1;
  uint uVar2;
  undefined4 uVar3;
  
  uVar2 = -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1);
  uVar3 = param_3;
  uVar1 = FUN_005702d0(param_3);
  FUN_009da8d0(&param_3,uVar1,uVar3,uVar2);
  *param_2 = param_3;
  return;
}



/* FUNCTION 28514 ; VA 0x00c4f960 ; FUN_00c4f960 */

void FUN_00c4f960(void)

{
  int iVar1;
  
  if (DAT_01efcf54 == 0) {
    iVar1 = FUN_00c4b770();
    DAT_01efcf54 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28515 ; VA 0x00c4f980 ; FUN_00c4f980 */

void FUN_00c4f980(void)

{
  int iVar1;
  
  if (DAT_01efd394 == 0) {
    iVar1 = FUN_00c4b870();
    DAT_01efd394 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28516 ; VA 0x00c4f9a0 ; FUN_00c4f9a0 */

void FUN_00c4f9a0(void)

{
  int iVar1;
  
  if (DAT_01efd174 == 0) {
    iVar1 = FUN_00c4b970();
    DAT_01efd174 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28517 ; VA 0x00c4f9c0 ; FUN_00c4f9c0 */

int * FUN_00c4f9c0(int *param_1,byte *param_2,int *param_3,int param_4,undefined4 param_5,
                  int *param_6)

{
  byte bVar1;
  code *pcVar2;
  void *pvVar3;
  undefined uVar4;
  char cVar5;
  undefined4 *******pppppppuVar6;
  undefined4 uVar7;
  int *******pppppppiVar8;
  int *piVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  int iVar13;
  int *piVar14;
  undefined auStack_e8 [48];
  undefined auStack_b8 [8];
  int ******ppppppiStack_b0;
  undefined4 *****pppppuStack_ac;
  undefined4 *****pppppuStack_a8;
  undefined4 *****pppppuStack_a4;
  undefined8 uStack_a0;
  undefined auStack_98 [8];
  undefined4 ******ppppppuStack_90;
  undefined4 *****pppppuStack_8c;
  undefined4 *****pppppuStack_88;
  undefined4 *****pppppuStack_84;
  undefined8 uStack_80;
  undefined2 auStack_78 [8];
  undefined4 uStack_68;
  undefined4 uStack_64;
  int iStack_60;
  int *piStack_5c;
  undefined4 ******appppppuStack_58 [4];
  int iStack_48;
  uint uStack_44;
  int iStack_40;
  int *piStack_3c;
  int aiStack_38 [2];
  int *piStack_30;
  undefined2 *puStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined2 *puStack_1c;
  int *piStack_18;
  undefined2 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar9 = param_6;
  pvVar3 = ExceptionList;
  puStack_c = &LAB_0180ac04;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*(int *)(param_4 + 0x10) == 0) {
    ExceptionList = &pvStack_10;
    *param_1 = 0;
    param_1[1] = 0;
    if (param_6 == (int *)0x0) {
      ExceptionList = pvVar3;
      return param_1;
    }
    LOCK();
    iVar13 = param_6[1] + -1;
    param_6[1] = iVar13;
    UNLOCK();
    if (iVar13 != 0) {
      ExceptionList = pvVar3;
      return param_1;
    }
    (**(code **)*param_6)();
    LOCK();
    piVar14 = piVar9 + 2;
    iVar13 = *piVar14;
    *piVar14 = *piVar14 + -1;
    UNLOCK();
    if (iVar13 != 1) {
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(*piVar9 + 4))();
    ExceptionList = pvStack_10;
    return param_1;
  }
  uStack_80 = 0xf00000000;
  ppppppuStack_90 = (undefined4 ******)((uint)ppppppuStack_90 & 0xffffff00);
  uStack_a0 = 0xf00000000;
  ppppppiStack_b0 = (int ******)((uint)ppppppiStack_b0 & 0xffffff00);
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  pppppppuVar6 = (undefined4 *******)FUN_00c51850(auStack_e8,param_4);
  if (&ppppppuStack_90 != pppppppuVar6) {
    FUN_005507b0();
    ppppppuStack_90 = *pppppppuVar6;
    pppppuStack_8c = pppppppuVar6[1];
    pppppuStack_88 = pppppppuVar6[2];
    pppppuStack_84 = pppppppuVar6[3];
    uStack_80 = *(undefined8 *)(pppppppuVar6 + 4);
    pppppppuVar6[4] = (undefined4 ******)0x0;
    pppppppuVar6[5] = (undefined4 ******)0xf;
    *(undefined *)pppppppuVar6 = 0;
  }
  pppppppiVar8 = pppppppuVar6 + 6;
  if (&ppppppiStack_b0 != pppppppiVar8) {
    FUN_005507b0();
    ppppppiStack_b0 = *pppppppiVar8;
    pppppuStack_ac = pppppppuVar6[7];
    pppppuStack_a8 = pppppppuVar6[8];
    pppppuStack_a4 = pppppppuVar6[9];
    uStack_a0 = *(undefined8 *)(pppppppuVar6 + 10);
    pppppppuVar6[10] = (undefined4 ******)0x0;
    pppppppuVar6[0xb] = (undefined4 ******)0xf;
    *(undefined *)pppppppiVar8 = 0;
  }
  FUN_005509f0();
  iVar13 = param_4;
  iStack_60 = 0;
  piStack_24 = (int *)0x0;
  piStack_5c = (int *)0x0;
  iStack_48 = 0;
  uStack_44 = 0xf;
  appppppuStack_58[0] = (undefined4 ******)((uint)appppppuStack_58[0] & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  bVar1 = *param_2;
  uVar7 = FUN_005702d0(param_4);
  FUN_009da8d0(&puStack_1c,uVar7,iVar13,
               -(uint)(param_2 + bVar1 + 1 != (byte *)0x0) & (uint)(param_2 + bVar1 + 1 + 1));
  if (puStack_1c == (undefined2 *)0x0) {
    pppppppiVar8 = &ppppppiStack_b0;
    uVar7 = (undefined4)uStack_a0;
    if (0xf < uStack_a0._4_4_) {
      pppppppiVar8 = (int *******)ppppppiStack_b0;
    }
LAB_00c4fbab:
    FUN_005542c0(pppppppiVar8,uVar7);
  }
  else {
    piVar9 = (int *)FUN_00c4e8b0(iVar13);
    piStack_5c = (int *)piVar9[1];
    if (piStack_5c != (int *)0x0) {
      LOCK();
      piStack_5c[1] = piStack_5c[1] + 1;
      UNLOCK();
      piStack_5c = (int *)piVar9[1];
    }
    iStack_60 = *piVar9;
    pppppppiVar8 = (int *******)(iStack_60 + 0x1c);
    piStack_24 = piStack_5c;
    if (appppppuStack_58 != pppppppiVar8) {
      uVar7 = *(undefined4 *)(iStack_60 + 0x2c);
      if (0xf < *(uint *)(iStack_60 + 0x30)) {
        pppppppiVar8 = (int *******)*pppppppiVar8;
      }
      goto LAB_00c4fbab;
    }
  }
  uStack_68 = 0;
  uStack_64 = 7;
  auStack_78[0] = 0;
  uStack_8._0_1_ = 5;
  if ((int)uStack_80 != 0) {
    pppppppuVar6 = &ppppppuStack_90;
    if (0xf < uStack_80._4_4_) {
      pppppppuVar6 = (undefined4 *******)ppppppuStack_90;
    }
    iVar13 = (int)pppppppuVar6 + (int)uStack_80;
    pppppppuVar6 = &ppppppuStack_90;
    if (0xf < uStack_80._4_4_) {
      pppppppuVar6 = (undefined4 *******)ppppppuStack_90;
    }
    uVar7 = FUN_01686580();
    FUN_01685950(pppppppuVar6,iVar13,auStack_78,uVar7);
  }
  pppppppuVar6 = appppppuStack_58;
  if (0xf < uStack_44) {
    pppppppuVar6 = (undefined4 *******)appppppuStack_58[0];
  }
  uStack_8._0_1_ = 6;
  if (pppppppuVar6 != (undefined4 *******)(iStack_48 + (int)pppppppuVar6)) {
    puStack_14 = (undefined2 *)FUN_01687bc0();
    if (iStack_48 != 0) {
      pppppppuVar6 = appppppuStack_58;
      if (0xf < uStack_44) {
        pppppppuVar6 = (undefined4 *******)appppppuStack_58[0];
      }
      puStack_1c = (undefined2 *)((int)pppppppuVar6 + iStack_48);
      pppppppuVar6 = appppppuStack_58;
      if (0xf < uStack_44) {
        pppppppuVar6 = (undefined4 *******)appppppuStack_58[0];
      }
      uVar7 = FUN_01686580();
      FUN_01685950(pppppppuVar6,puStack_1c,auStack_78,uVar7);
    }
    if (puStack_14 != (undefined2 *)0x0) {
      FUN_01687c10(puStack_14);
    }
  }
  FUN_01688610();
  piVar9 = (int *)FUN_00ba4a90(&puStack_14,auStack_78);
  puVar10 = (undefined4 *)*param_3;
  if ((undefined4 *)*piVar9 != puVar10) {
    puVar11 = (undefined4 *)puVar10[1];
    puVar12 = puVar10;
    if (*(char *)((int)puVar10[1] + 0xd) == '\0') {
      do {
        iVar13 = FUN_01686710(auStack_78);
        if (iVar13 < 0) {
          puVar10 = (undefined4 *)puVar11[2];
        }
        else {
          puVar10 = (undefined4 *)*puVar11;
          puVar12 = puVar11;
        }
        puVar11 = puVar10;
      } while (*(char *)((int)puVar10 + 0xd) == '\0');
      puVar10 = (undefined4 *)*param_3;
    }
    if ((puVar12 != puVar10) && (iVar13 = FUN_01686710(puVar12 + 4), -1 < iVar13)) {
      iVar13 = puVar12[0xb];
      *param_1 = 0;
      param_1[1] = 0;
      if (iVar13 != 0) {
        LOCK();
        *(int *)(iVar13 + 4) = *(int *)(iVar13 + 4) + 1;
        UNLOCK();
        iVar13 = puVar12[0xb];
      }
      *param_1 = puVar12[10];
      param_1[1] = iVar13;
      FUN_00550800();
      FUN_005507b0();
      piVar9 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar13 = piStack_24[1] + -1;
        piStack_24[1] = iVar13;
        UNLOCK();
        if (iVar13 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          piVar14 = piVar9 + 2;
          iVar13 = *piVar14 + -1;
          *piVar14 = iVar13;
          UNLOCK();
          if (iVar13 == 0) {
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
      FUN_005507b0();
      FUN_005507b0();
      piVar9 = param_6;
      if (param_6 != (int *)0x0) {
        LOCK();
        iVar13 = param_6[1] + -1;
        param_6[1] = iVar13;
        UNLOCK();
        if (iVar13 == 0) {
          (**(code **)*param_6)();
          LOCK();
          piVar14 = piVar9 + 2;
          iVar13 = *piVar14;
          *piVar14 = *piVar14 + -1;
          UNLOCK();
          if (iVar13 == 1) {
            (**(code **)(*piVar9 + 4))();
            ExceptionList = pvStack_10;
            return param_1;
          }
        }
      }
      ExceptionList = pvStack_10;
      return param_1;
    }
    FUN_016ddcf9("invalid map<K, T> key");
    pcVar2 = (code *)swi(3);
    piVar9 = (int *)(*pcVar2)();
    return piVar9;
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  FUN_00c4f9c0(aiStack_38,param_2,param_3,&ppppppuStack_90,param_5,param_6);
  uStack_8._0_1_ = 7;
  if ((aiStack_38[0] == 0) ||
     ((piVar9 = (int *)FUN_00ba4a90(&puStack_14,auStack_78), *piVar9 == *param_3 &&
      (iVar13 = FUN_008a1240(appppppuStack_58), iVar13 != 0)))) {
    *param_1 = 0;
    param_1[1] = 0;
    goto LAB_00c50151;
  }
  iVar13 = param_4;
  piStack_30 = (int *)0x0;
  puStack_2c = (undefined2 *)0x0;
  uStack_8._0_1_ = 8;
  piVar9 = (int *)FUN_00c4f920(&param_4,param_4);
  if (*piVar9 == 0) {
    FUN_00634770(&piStack_18);
    piVar9 = piStack_18;
    if (puStack_14 != (undefined2 *)0x0) {
      LOCK();
      *(int *)(puStack_14 + 2) = *(int *)(puStack_14 + 2) + 1;
      UNLOCK();
    }
    puStack_1c = puStack_14;
    piStack_24 = piStack_18;
    piStack_30 = piStack_18;
    puStack_2c = puStack_14;
    FUN_00550b30();
  }
  else {
    uVar7 = FUN_00c4e8b0(iVar13);
    FUN_00557fc0(uVar7);
    uStack_8._0_1_ = 9;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 9;
    if (*piStack_28 == 0) {
      uStack_8._0_1_ = uVar4;
      FUN_00557fc0(&piStack_28);
      uStack_8._0_1_ = 10;
      FUN_005c30b0(&piStack_18);
      uStack_8._0_1_ = 0xb;
      cVar5 = FUN_00554b40();
      if (cVar5 == '\0') {
        uVar7 = FUN_008869b0(auStack_98,iStack_40 + 0x34);
        uStack_8._0_1_ = 0xd;
        FUN_009ed830(uVar7);
        FUN_0056e380();
      }
      else {
        uVar7 = FUN_00886c00(auStack_b8,iStack_40 + 0x34);
        uStack_8._0_1_ = 0xc;
        FUN_009ed830(uVar7);
        FUN_0056e380();
      }
LAB_00c4fffd:
      FUN_0056e380();
      puStack_1c = puStack_14;
      piStack_20 = piStack_18;
      puStack_14 = (undefined2 *)0x0;
      piStack_18 = (int *)0x0;
LAB_00c5001c:
      if (piStack_3c != (int *)0x0) {
        LOCK();
        iVar13 = piStack_3c[1] + -1;
        piStack_3c[1] = iVar13;
        UNLOCK();
        if (iVar13 == 0) {
          (**(code **)*piStack_3c)();
          LOCK();
          piVar9 = piStack_3c + 2;
          iVar13 = *piVar9;
          *piVar9 = *piVar9 + -1;
          UNLOCK();
          if (iVar13 == 1) {
            (**(code **)(*piStack_3c + 4))();
          }
        }
      }
      FUN_005587e0(&piStack_20);
    }
    else {
      if (*piStack_28 == 1) {
        FUN_00557fc0(&piStack_28);
        uStack_8._0_1_ = 0xe;
        cVar5 = FUN_00554b40();
        if (cVar5 != '\0') {
          FUN_00b742d0(&piStack_18);
          uStack_8._0_1_ = 0xf;
          uVar7 = FUN_00886c00(&piStack_20,iStack_40 + 0x34);
          uStack_8._0_1_ = 0x10;
          FUN_00b75530(uVar7);
          FUN_0056e380();
          goto LAB_00c4fffd;
        }
        piStack_20 = (int *)0x0;
        puStack_1c = (undefined2 *)0x0;
        goto LAB_00c5001c;
      }
      FUN_00557fc0(&param_5);
      FUN_00557fc0(aiStack_38);
      FUN_00557fc0(&piStack_28);
      uVar7 = FUN_00c4ef00(auStack_98);
      FUN_005587e0(uVar7);
    }
    FUN_00550b30();
    uStack_8._0_1_ = 8;
    FUN_00550b30();
    puStack_1c = puStack_2c;
    piStack_24 = piStack_30;
    piVar9 = piStack_30;
  }
  piVar14 = piStack_24;
  if (piVar9 != (int *)0x0) {
    (**(code **)(*piVar9 + 0x38))(appppppuStack_58);
    (**(code **)(*piVar9 + 0x1c))(0);
    puVar11 = (undefined4 *)*param_3;
    puVar12 = puVar11;
    puVar10 = (undefined4 *)puVar11[1];
    if (*(char *)((int)puVar11[1] + 0xd) == '\0') {
      do {
        puVar12 = puVar10;
        iVar13 = FUN_01686710(auStack_78);
        if (iVar13 < 0) {
          puVar10 = (undefined4 *)puVar12[2];
          puVar12 = puVar11;
        }
        else {
          puVar10 = (undefined4 *)*puVar12;
        }
        puVar11 = puVar12;
      } while (*(char *)((int)puVar10 + 0xd) == '\0');
      puVar11 = (undefined4 *)*param_3;
    }
    if ((puVar12 == puVar11) || (iVar13 = FUN_01686710(puVar12 + 4), iVar13 < 0)) {
      puStack_14 = auStack_78;
      iVar13 = FUN_00c4ba70(&DAT_018bdeda,&puStack_14,(int)&param_4 + 3);
      FUN_00c4c0c0(&param_4,puVar12,iVar13 + 0x10,iVar13);
    }
    FUN_0056ecd0(&piStack_30);
    piVar14 = piStack_24;
    if (aiStack_38[0] != 0) {
      FUN_008a65e0(aiStack_38[0],0);
    }
  }
  piStack_30 = (int *)0x0;
  puStack_2c = (undefined2 *)0x0;
  *param_1 = (int)piVar14;
  param_1[1] = (int)puStack_1c;
  FUN_00550b30();
LAB_00c50151:
  FUN_00550b30();
  FUN_00550800();
  FUN_005507b0();
  FUN_00550b30();
  FUN_005507b0();
  FUN_005507b0();
  FUN_00550b30();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28518 ; VA 0x00c501b0 ; FUN_00c501b0 */

int * __thiscall FUN_00c501b0(int param_1,int *param_2)

{
  char cVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 uStack_f4;
  int iStack_f0;
  int aiStack_ec [50];
  int iStack_24;
  int iStack_20;
  undefined4 *puStack_1c;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ac2b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00c4b280(param_1 + 0x90,&uStack_11);
  uStack_8 = 0;
  FUN_005cac50(&iStack_24);
  puVar5 = puStack_1c;
  puVar2 = (undefined4 *)*puStack_1c;
  iVar3 = iStack_24;
  while (puVar2 != puVar5) {
    uStack_8._0_1_ = 1;
    iVar3 = puVar2[4];
    uStack_f4 = thunk_FUN_00c51450();
    iStack_f0 = 0;
    aiStack_ec[0] = iVar3;
    iStack_f0 = FUN_00c51690();
    iVar3 = iStack_24;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (*(int *)(iStack_24 + 8) == *(int *)(iStack_24 + 4)) {
      FUN_005ca4f0(*(int *)(iStack_24 + 4),&uStack_f4);
    }
    else {
      FUN_005caaf0(iStack_24);
      *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 0xd0;
    }
    uStack_8._0_1_ = 3;
    if (iStack_f0 != 0) {
      (**(code **)(iStack_f0 + 8))(aiStack_ec);
    }
    puVar4 = (undefined4 *)puVar2[2];
    if (*(char *)((int)puVar4 + 0xd) == '\0') {
      cVar1 = *(char *)((int)*puVar4 + 0xd);
      puVar2 = puVar4;
      puVar4 = (undefined4 *)*puVar4;
      while (cVar1 == '\0') {
        cVar1 = *(char *)((int)*puVar4 + 0xd);
        puVar2 = puVar4;
        puVar4 = (undefined4 *)*puVar4;
      }
    }
    else {
      cVar1 = *(char *)((int)puVar2[1] + 0xd);
      puVar6 = (undefined4 *)puVar2[1];
      puVar4 = puVar2;
      while ((puVar2 = puVar6, cVar1 == '\0' && (puVar4 == (undefined4 *)puVar2[2]))) {
        cVar1 = *(char *)((int)puVar2[1] + 0xd);
        puVar6 = (undefined4 *)puVar2[1];
        puVar4 = puVar2;
      }
    }
  }
  uStack_8._0_1_ = 1;
  param_2[1] = iStack_20;
  *param_2 = iVar3;
  FUN_009abb30();
  FUN_01674ea0(puStack_1c,0x14);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28519 ; VA 0x00c50300 ; FUN_00c50300 */

int * __thiscall FUN_00c50300(int param_1,int *param_2)

{
  char cVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 uStack_f4;
  int iStack_f0;
  int aiStack_ec [50];
  int iStack_24;
  int iStack_20;
  undefined4 *puStack_1c;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ac5b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00c4b350(param_1 + 0x78,&uStack_11);
  uStack_8 = 0;
  FUN_005cac50(&iStack_24);
  puVar5 = puStack_1c;
  puVar2 = (undefined4 *)*puStack_1c;
  iVar3 = iStack_24;
  while (puVar2 != puVar5) {
    uStack_8._0_1_ = 1;
    iVar3 = puVar2[4];
    uStack_f4 = thunk_FUN_00c514e0();
    iStack_f0 = 0;
    aiStack_ec[0] = iVar3;
    iStack_f0 = FUN_00c51700();
    iVar3 = iStack_24;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (*(int *)(iStack_24 + 8) == *(int *)(iStack_24 + 4)) {
      FUN_005ca4f0(*(int *)(iStack_24 + 4),&uStack_f4);
    }
    else {
      FUN_005caaf0(iStack_24);
      *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 0xd0;
    }
    uStack_8._0_1_ = 3;
    if (iStack_f0 != 0) {
      (**(code **)(iStack_f0 + 8))(aiStack_ec);
    }
    puVar4 = (undefined4 *)puVar2[2];
    if (*(char *)((int)puVar4 + 0xd) == '\0') {
      cVar1 = *(char *)((int)*puVar4 + 0xd);
      puVar2 = puVar4;
      puVar4 = (undefined4 *)*puVar4;
      while (cVar1 == '\0') {
        cVar1 = *(char *)((int)*puVar4 + 0xd);
        puVar2 = puVar4;
        puVar4 = (undefined4 *)*puVar4;
      }
    }
    else {
      cVar1 = *(char *)((int)puVar2[1] + 0xd);
      puVar6 = (undefined4 *)puVar2[1];
      puVar4 = puVar2;
      while ((puVar2 = puVar6, cVar1 == '\0' && (puVar4 == (undefined4 *)puVar2[2]))) {
        cVar1 = *(char *)((int)puVar2[1] + 0xd);
        puVar6 = (undefined4 *)puVar2[1];
        puVar4 = puVar2;
      }
    }
  }
  uStack_8._0_1_ = 1;
  param_2[1] = iStack_20;
  *param_2 = iVar3;
  FUN_009abb30();
  FUN_01674ea0(puStack_1c,0x14);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28520 ; VA 0x00c50450 ; FUN_00c50450 */

int * __thiscall FUN_00c50450(int param_1,int *param_2)

{
  char cVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 uStack_f4;
  int iStack_f0;
  int aiStack_ec [50];
  int iStack_24;
  int iStack_20;
  undefined4 *puStack_1c;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ac8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00c4b420(param_1 + 0x84,&uStack_11);
  uStack_8 = 0;
  FUN_005cac50(&iStack_24);
  puVar5 = puStack_1c;
  puVar2 = (undefined4 *)*puStack_1c;
  iVar3 = iStack_24;
  while (puVar2 != puVar5) {
    uStack_8._0_1_ = 1;
    iVar3 = puVar2[4];
    uStack_f4 = thunk_FUN_00c51570();
    iStack_f0 = 0;
    aiStack_ec[0] = iVar3;
    iStack_f0 = FUN_00c51770();
    iVar3 = iStack_24;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (*(int *)(iStack_24 + 8) == *(int *)(iStack_24 + 4)) {
      FUN_005ca4f0(*(int *)(iStack_24 + 4),&uStack_f4);
    }
    else {
      FUN_005caaf0(iStack_24);
      *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 0xd0;
    }
    uStack_8._0_1_ = 3;
    if (iStack_f0 != 0) {
      (**(code **)(iStack_f0 + 8))(aiStack_ec);
    }
    puVar4 = (undefined4 *)puVar2[2];
    if (*(char *)((int)puVar4 + 0xd) == '\0') {
      cVar1 = *(char *)((int)*puVar4 + 0xd);
      puVar2 = puVar4;
      puVar4 = (undefined4 *)*puVar4;
      while (cVar1 == '\0') {
        cVar1 = *(char *)((int)*puVar4 + 0xd);
        puVar2 = puVar4;
        puVar4 = (undefined4 *)*puVar4;
      }
    }
    else {
      cVar1 = *(char *)((int)puVar2[1] + 0xd);
      puVar6 = (undefined4 *)puVar2[1];
      puVar4 = puVar2;
      while ((puVar2 = puVar6, cVar1 == '\0' && (puVar4 == (undefined4 *)puVar2[2]))) {
        cVar1 = *(char *)((int)puVar2[1] + 0xd);
        puVar6 = (undefined4 *)puVar2[1];
        puVar4 = puVar2;
      }
    }
  }
  uStack_8._0_1_ = 1;
  param_2[1] = iStack_20;
  *param_2 = iVar3;
  FUN_009abb30();
  FUN_01674ea0(puStack_1c,0x14);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28521 ; VA 0x00c505a0 ; FUN_00c505a0 */

int * __thiscall FUN_00c505a0(int param_1,int *param_2)

{
  char cVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 uStack_f4;
  int iStack_f0;
  int aiStack_ec [50];
  int iStack_24;
  int iStack_20;
  undefined4 *puStack_1c;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180acbb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00c4b4f0(param_1 + 0x6c,&uStack_11);
  uStack_8 = 0;
  FUN_005cac50(&iStack_24);
  puVar5 = puStack_1c;
  puVar2 = (undefined4 *)*puStack_1c;
  iVar3 = iStack_24;
  while (puVar2 != puVar5) {
    uStack_8._0_1_ = 1;
    iVar3 = puVar2[4];
    uStack_f4 = thunk_FUN_00c51600();
    iStack_f0 = 0;
    aiStack_ec[0] = iVar3;
    iStack_f0 = FUN_00c517e0();
    iVar3 = iStack_24;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (*(int *)(iStack_24 + 8) == *(int *)(iStack_24 + 4)) {
      FUN_005ca4f0(*(int *)(iStack_24 + 4),&uStack_f4);
    }
    else {
      FUN_005caaf0(iStack_24);
      *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 0xd0;
    }
    uStack_8._0_1_ = 3;
    if (iStack_f0 != 0) {
      (**(code **)(iStack_f0 + 8))(aiStack_ec);
    }
    puVar4 = (undefined4 *)puVar2[2];
    if (*(char *)((int)puVar4 + 0xd) == '\0') {
      cVar1 = *(char *)((int)*puVar4 + 0xd);
      puVar2 = puVar4;
      puVar4 = (undefined4 *)*puVar4;
      while (cVar1 == '\0') {
        cVar1 = *(char *)((int)*puVar4 + 0xd);
        puVar2 = puVar4;
        puVar4 = (undefined4 *)*puVar4;
      }
    }
    else {
      cVar1 = *(char *)((int)puVar2[1] + 0xd);
      puVar6 = (undefined4 *)puVar2[1];
      puVar4 = puVar2;
      while ((puVar2 = puVar6, cVar1 == '\0' && (puVar4 == (undefined4 *)puVar2[2]))) {
        cVar1 = *(char *)((int)puVar2[1] + 0xd);
        puVar6 = (undefined4 *)puVar2[1];
        puVar4 = puVar2;
      }
    }
  }
  uStack_8._0_1_ = 1;
  param_2[1] = iStack_20;
  *param_2 = iVar3;
  FUN_009abb30();
  FUN_01674ea0(puStack_1c,0x14);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28522 ; VA 0x00c506f0 ; FUN_00c506f0 */

undefined * FUN_00c506f0(undefined *param_1,undefined4 param_2,undefined4 *param_3)

{
  bool bVar1;
  char cVar2;
  undefined4 ****ppppuVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  undefined auStack_5c [24];
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 ***apppuStack_2c [4];
  uint uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180acf9;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_01686c70(auStack_44);
  uStack_8 = 0;
  FUN_005569d0(apppuStack_2c);
  uStack_8._0_1_ = 2;
  if (7 < uStack_30) {
    uVar7 = uStack_30 * 2 + 2;
    uVar6 = auStack_44[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_44[0] - 4);
      uVar7 = uStack_30 * 2 + 0x25;
      if (0x1f < (auStack_44[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_34 = 0;
  uStack_30 = 7;
  auStack_44[0] = auStack_44[0] & 0xffff0000;
  uVar7 = FUN_00c512e0(&DAT_0195a7e4,0xffffffff);
  if (uVar7 != 0xffffffff) {
    if (uStack_1c < uVar7) {
      uVar7 = uStack_1c;
    }
    ppppuVar3 = apppuStack_2c;
    if (0xf < uStack_18) {
      ppppuVar3 = (undefined4 ****)apppuStack_2c[0];
    }
    *param_3 = 1;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    FUN_005542c0(ppppuVar3,uVar7);
    if (0xf < uStack_18) {
      uVar7 = uStack_18 + 1;
      ppppuVar3 = (undefined4 ****)apppuStack_2c[0];
      if (0xfff < uVar7) {
        ppppuVar3 = (undefined4 ****)apppuStack_2c[0][-1];
        uVar7 = uStack_18 + 0x24;
        if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar3,uVar7);
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  uVar7 = FUN_00c512e0(".client",0xffffffff);
  if (uVar7 != 0xffffffff) {
    if (uStack_1c < uVar7) {
      uVar7 = uStack_1c;
    }
    *param_3 = 2;
    ppppuVar3 = apppuStack_2c;
    if (0xf < uStack_18) {
      ppppuVar3 = (undefined4 ****)apppuStack_2c[0];
    }
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    FUN_005542c0(ppppuVar3,uVar7);
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return param_1;
  }
  iVar4 = FUN_00c512e0(".module",0xffffffff);
  uVar5 = FUN_005569d0(auStack_5c);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_14 = 2;
  cVar2 = FUN_00c50940(uVar5);
  if ((cVar2 == '\0') && (iVar4 == -1)) {
    bVar1 = false;
  }
  else {
    bVar1 = true;
  }
  uStack_8 = 2;
  FUN_005507b0();
  if (bVar1) {
    *param_3 = 0;
    FUN_0058c540(param_1,0,iVar4);
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return param_1;
  }
  *param_3 = 2;
  FUN_0054ef60(apppuStack_2c);
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28523 ; VA 0x00c50940 ; FUN_00c50940 */

/* WARNING: Removing unreachable block (ram,0x00c50bdd) */

undefined FUN_00c50940(undefined4 *param_1)

{
  bool bVar1;
  bool bVar2;
  bool bVar3;
  bool bVar4;
  bool bVar5;
  bool bVar6;
  bool bVar7;
  undefined *puVar8;
  int iVar9;
  undefined4 uVar10;
  undefined4 *puVar11;
  int iVar12;
  uint uVar13;
  undefined auStack_108 [24];
  undefined auStack_f0 [24];
  undefined auStack_d8 [24];
  undefined auStack_c0 [24];
  undefined auStack_a8 [24];
  int aiStack_90 [5];
  uint uStack_7c;
  undefined2 auStack_78 [8];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined2 auStack_60 [8];
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined2 auStack_48 [8];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined2 auStack_30 [8];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ae14;
  pvStack_10 = ExceptionList;
  bVar7 = false;
  bVar6 = false;
  bVar5 = false;
  bVar4 = false;
  bVar3 = false;
  bVar2 = false;
  bVar1 = false;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  iVar9 = FUN_00c512e0(".module",0xffffffff);
  if (iVar9 != -1) {
    ExceptionList = pvStack_10;
    return 1;
  }
  uStack_20 = 0;
  uStack_1c = 7;
  auStack_30[0] = 0;
  uStack_8 = 0;
  iVar9 = param_1[4];
  if (iVar9 != 0) {
    puVar11 = param_1;
    if (0xf < (uint)param_1[5]) {
      puVar11 = (undefined4 *)*param_1;
    }
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    uVar10 = FUN_01686580();
    FUN_01685950(param_1,iVar9 + (int)puVar11,auStack_30,uVar10);
  }
  uStack_8 = 1;
  iVar9 = FUN_01688660(aiStack_90);
  iVar9 = *(int *)(iVar9 + 0x10);
  if (7 < uStack_7c) {
    uVar13 = uStack_7c * 2 + 2;
    iVar12 = aiStack_90[0];
    if (0xfff < uVar13) {
      iVar12 = *(int *)(aiStack_90[0] + -4);
      uVar13 = uStack_7c * 2 + 0x25;
      if (0x1f < (aiStack_90[0] - iVar12) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar12,uVar13);
  }
  puVar8 = PTR_s_StarterPlayerScripts_0196ae98;
  if (iVar9 != 0) {
    uStack_68 = 0;
    uStack_64 = 7;
    auStack_78[0] = 0;
    uStack_8._0_1_ = 2;
    uVar10 = FUN_01686580();
    FUN_01685950(puVar8,0,auStack_78,uVar10);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    uStack_18 = 1;
    FUN_01688660(auStack_108);
    uStack_8 = 4;
    bVar7 = true;
    bVar6 = false;
    bVar5 = false;
    bVar4 = false;
    bVar3 = false;
    bVar2 = false;
    bVar1 = true;
    uStack_18 = 3;
    iVar9 = FUN_01686710(auStack_78);
    puVar8 = PTR_s_StarterPlayerScripts_NewStructur_0196ae9c;
    if (iVar9 != 0) {
      uStack_50 = 0;
      uStack_4c = 7;
      auStack_60[0] = 0;
      uStack_8 = 5;
      uVar10 = FUN_01686580();
      FUN_01685950(puVar8,0,auStack_60,uVar10);
      uStack_8 = 6;
      uStack_18 = 7;
      FUN_01688660(auStack_f0);
      uStack_8 = 7;
      bVar7 = true;
      bVar6 = true;
      bVar5 = true;
      bVar4 = false;
      bVar3 = false;
      bVar2 = false;
      bVar1 = true;
      uStack_18 = 0xf;
      iVar9 = FUN_01686710(auStack_60);
      puVar8 = PTR_s_StarterPlayerScriptsCommon_0196aea0;
      if (iVar9 != 0) {
        uStack_38 = 0;
        uStack_34 = 7;
        auStack_48[0] = 0;
        uStack_8 = 8;
        uVar10 = FUN_01686580();
        FUN_01685950(puVar8,0,auStack_48,uVar10);
        uStack_8 = 9;
        uStack_18 = 0x1f;
        FUN_01688660(auStack_d8);
        uStack_8 = 10;
        bVar7 = true;
        bVar6 = true;
        bVar5 = true;
        bVar4 = true;
        bVar3 = true;
        bVar2 = false;
        bVar1 = true;
        uStack_18 = 0x3f;
        iVar9 = FUN_01686710(auStack_48);
        if (iVar9 != 0) {
          FUN_0054d730("StarterCharacterScripts",0);
          uStack_8 = 0xb;
          uStack_18 = 0x7f;
          FUN_01688660(auStack_c0);
          uStack_8 = 0xc;
          bVar7 = true;
          bVar6 = true;
          bVar5 = true;
          bVar4 = true;
          bVar3 = true;
          bVar2 = true;
          bVar1 = true;
          uStack_18 = 0xff;
          iVar9 = FUN_01686710(auStack_a8);
          uStack_11 = 1;
          if (iVar9 != 0) goto LAB_00c50bd9;
        }
      }
    }
  }
  uStack_11 = 0;
LAB_00c50bd9:
  if (bVar2) {
    FUN_00550800();
  }
  if (bVar3) {
    FUN_00550800();
  }
  if (bVar4) {
    FUN_00550800();
  }
  if (bVar5) {
    FUN_00550800();
  }
  if (bVar6) {
    FUN_00550800();
  }
  if (bVar7) {
    FUN_00550800();
  }
  if (bVar1) {
    FUN_00550800();
  }
  FUN_00550800();
  ExceptionList = pvStack_10;
  return uStack_11;
}



/* FUNCTION 28524 ; VA 0x00c50c90 ; FUN_00c50c90 */

uint FUN_00c50c90(void)

{
  int iVar1;
  
  iVar1 = FUN_00c4b770();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 28525 ; VA 0x00c50cb0 ; FUN_00c50cb0 */

uint FUN_00c50cb0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c4b870();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 28526 ; VA 0x00c50cd0 ; FUN_00c50cd0 */

uint FUN_00c50cd0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c4b970();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 28527 ; VA 0x00c50cf0 ; FUN_00c50cf0 */

uint FUN_00c50cf0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c4b770();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 28528 ; VA 0x00c50d10 ; FUN_00c50d10 */

uint FUN_00c50d10(void)

{
  int iVar1;
  
  iVar1 = FUN_00c4b870();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 28529 ; VA 0x00c50d30 ; FUN_00c50d30 */

uint FUN_00c50d30(void)

{
  int iVar1;
  
  iVar1 = FUN_00c4b970();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 28530 ; VA 0x00c50d50 ; FUN_00c50d50 */

void FUN_00c50d50(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00c51450();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28531 ; VA 0x00c50d90 ; FUN_00c50d90 */

void FUN_00c50d90(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00c514e0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28532 ; VA 0x00c50dd0 ; FUN_00c50dd0 */

void FUN_00c50dd0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00c51570();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28533 ; VA 0x00c50e10 ; FUN_00c50e10 */

void FUN_00c50e10(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00c51600();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28534 ; VA 0x00c50e50 ; FUN_00c50e50 */

void __thiscall FUN_00c50e50(int param_1,undefined4 *param_2,int param_3)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  undefined auStack_38 [24];
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar4 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ae6a;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != (undefined4 *)0x0) {
    ExceptionList = &pvStack_10;
    FUN_01679490();
  }
  iVar6 = param_3;
  FUN_008a4210(puVar4,param_3);
  if (iVar6 != 0) {
    param_2 = *(undefined4 **)(param_1 + 0x34);
    if (param_2 != (undefined4 *)0x0) {
      iVar5 = param_2[3];
      iVar3 = FUN_00bb25e0();
      puVar4 = (undefined4 *)0x0;
      if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da)) {
        puVar4 = param_2;
      }
      if (puVar4 != (undefined4 *)0x0) goto LAB_00c50f47;
    }
    puVar4 = (undefined4 *)FUN_008a2380(auStack_38);
    uStack_8 = 0;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    FUN_0086f2f0(2,"StarterPlayerScripts must be a child of StarterPlayer.  %s is not.",puVar4);
    uStack_8 = 0xffffffff;
    FUN_005507b0();
    iVar5 = FUN_008f7870(iVar6);
    if ((iVar5 != 0) && (*(int *)(iVar5 + 0x4a0) != 3)) {
      FUN_0086f2f0(2,"Children removed from StarterPlayerScripts not parented to StarterPlayer.");
      FUN_008a50b0();
      ExceptionList = pvStack_10;
      return;
    }
  }
LAB_00c50f47:
  iVar5 = FUN_008f7870(iVar6);
  if (iVar5 != 0) {
    if ((*(int *)(iVar5 + 0x4a0) == 2) && (iVar6 != 0)) {
      param_3 = iVar5;
      iVar6 = FUN_005f5170();
      if (iVar6 != 0) {
        if (*(int *)(iVar6 + 0x68) == 1) {
          FUN_00c4d6d0();
        }
        else {
          iStack_18 = iVar6 + 0xd8;
          uStack_8 = 1;
          uVar7 = FUN_01675290(DAT_02110da8);
          uStack_8._0_1_ = 2;
          puStack_1c = (undefined4 *)uVar7;
          puStack_20 = (undefined4 *)FUN_01674e20(0x1c);
          if (puStack_20 == (undefined4 *)0x0) {
            puVar4 = (undefined4 *)0x0;
          }
          else {
            *puStack_20 = 0;
            puStack_20[1] = 1;
            puStack_20[2] = FUN_00c4f100;
            puStack_20[3] = _guard_check_icall;
            puStack_20[4] = 0;
            puStack_20[5] = iStack_18;
            puStack_20[6] = param_1;
            puVar4 = puStack_20;
          }
          FUN_016797d0(puVar4);
          if (puVar4 != (undefined4 *)0x0) {
            LOCK();
            puVar4[1] = puVar4[1] + 1;
            UNLOCK();
          }
          uStack_14 = 1;
          uStack_8._0_1_ = 3;
          param_2 = puVar4;
          FUN_01675290(uVar7);
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          cVar2 = FUN_01679300(&param_2);
          if (cVar2 != '\0') {
            FUN_01679490();
            FUN_016791c0(&param_2);
          }
          if (param_2 != (undefined4 *)0x0) {
            piVar1 = param_2 + 1;
            LOCK();
            iVar6 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            uStack_14 = 0;
            if (iVar6 == 1) {
              FUN_01674ea0(param_2);
            }
          }
          uStack_14 = 0;
          iVar5 = param_3;
        }
      }
    }
    param_3 = iVar5 + 0xac;
    uStack_8 = 4;
    uVar7 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 5;
    puStack_20 = (undefined4 *)uVar7;
    puStack_1c = (undefined4 *)FUN_01674e20(0x1c);
    if (puStack_1c == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puStack_1c = 0;
      puStack_1c[1] = 1;
      puStack_1c[2] = FUN_00c4f180;
      puStack_1c[3] = _guard_check_icall;
      puStack_1c[4] = 0;
      puStack_1c[5] = param_3;
      puStack_1c[6] = param_1;
      puVar4 = puStack_1c;
    }
    FUN_016797d0(puVar4);
    if (puVar4 != (undefined4 *)0x0) {
      LOCK();
      puVar4[1] = puVar4[1] + 1;
      UNLOCK();
    }
    uStack_14 = 2;
    uStack_8._0_1_ = 6;
    param_2 = puVar4;
    FUN_01675290(uVar7);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    cVar2 = FUN_01679300(&param_2);
    if (cVar2 != '\0') {
      FUN_01679490();
      FUN_016791c0(&param_2);
    }
    if (param_2 != (undefined4 *)0x0) {
      piVar1 = param_2 + 1;
      LOCK();
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        FUN_01674ea0(param_2);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28535 ; VA 0x00c51180 ; FUN_00c51180 */

void __thiscall FUN_00c51180(int param_1,undefined4 param_2)

{
  undefined auStack_c [4];
  char cStack_8;
  
  if (*(char *)(param_1 + 0x8c) == '\0') {
    *(undefined *)(param_1 + 0x8c) = 1;
    FUN_009abb30();
  }
  FUN_00c4c4b0(auStack_c,0,&param_2,param_2);
  if (cStack_8 != '\0') {
    FUN_006eccd0();
  }
  return;
}



/* FUNCTION 28536 ; VA 0x00c511e0 ; FUN_00c511e0 */

void __thiscall FUN_00c511e0(int param_1,undefined4 param_2)

{
  undefined auStack_c [4];
  char cStack_8;
  
  if (*(char *)(param_1 + 0x74) == '\0') {
    *(undefined *)(param_1 + 0x74) = 1;
    FUN_009abb30();
  }
  FUN_00c4c4b0(auStack_c,0,&param_2,param_2);
  if (cStack_8 != '\0') {
    FUN_006eccd0();
  }
  return;
}



/* FUNCTION 28537 ; VA 0x00c51230 ; FUN_00c51230 */

void __thiscall FUN_00c51230(int param_1,undefined4 param_2)

{
  undefined auStack_c [4];
  char cStack_8;
  
  if (*(char *)(param_1 + 0x80) == '\0') {
    *(undefined *)(param_1 + 0x80) = 1;
    FUN_009abb30();
  }
  FUN_00c4c4b0(auStack_c,0,&param_2,param_2);
  if (cStack_8 != '\0') {
    FUN_006eccd0();
  }
  return;
}



/* FUNCTION 28538 ; VA 0x00c51290 ; FUN_00c51290 */

void __thiscall FUN_00c51290(int param_1,undefined4 param_2)

{
  undefined auStack_c [4];
  char cStack_8;
  
  if (*(char *)(param_1 + 0x68) == '\0') {
    *(undefined *)(param_1 + 0x68) = 1;
    FUN_009abb30();
  }
  FUN_00c4c4b0(auStack_c,0,&param_2,param_2);
  if (cStack_8 != '\0') {
    FUN_006eccd0();
  }
  return;
}



/* FUNCTION 28539 ; VA 0x00c512e0 ; FUN_00c512e0 */

uint __thiscall FUN_00c512e0(byte *param_1,byte *param_2,uint param_3)

{
  byte bVar1;
  uint uVar2;
  byte *pbVar3;
  byte *pbVar4;
  uint uVar5;
  byte *pbVar6;
  uint uVar7;
  bool bVar8;
  byte *pbStack_8;
  
  pbVar6 = param_2;
  do {
    bVar1 = *pbVar6;
    pbVar6 = pbVar6 + 1;
  } while (bVar1 != 0);
  uVar5 = *(uint *)(param_1 + 0x10);
  uVar7 = (int)pbVar6 - (int)(param_2 + 1);
  pbStack_8 = param_1;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    pbStack_8 = *(byte **)param_1;
  }
  if (uVar7 == 0) {
    if (uVar5 < param_3) {
      param_3 = uVar5;
    }
    return param_3;
  }
  if (uVar5 < uVar7) {
    return 0xffffffff;
  }
  if (uVar5 - uVar7 < param_3) {
    param_3 = uVar5 - uVar7;
  }
  pbVar6 = pbStack_8 + param_3;
  do {
    pbVar3 = pbVar6;
    pbVar4 = param_2;
    uVar5 = uVar7;
    if (*pbVar6 == *param_2) {
      while (uVar2 = uVar5 - 4, 3 < uVar5) {
        if (*(int *)pbVar3 != *(int *)pbVar4) goto LAB_00c51366;
        pbVar3 = pbVar3 + 4;
        pbVar4 = pbVar4 + 4;
        uVar5 = uVar2;
      }
      if (uVar2 == 0xfffffffc) {
LAB_00c5139a:
        uVar5 = 0;
      }
      else {
LAB_00c51366:
        bVar8 = *pbVar3 < *pbVar4;
        if ((*pbVar3 == *pbVar4) &&
           ((uVar2 == 0xfffffffd ||
            ((bVar8 = pbVar3[1] < pbVar4[1], pbVar3[1] == pbVar4[1] &&
             ((uVar2 == 0xfffffffe ||
              ((bVar8 = pbVar3[2] < pbVar4[2], pbVar3[2] == pbVar4[2] &&
               ((uVar2 == 0xffffffff || (bVar8 = pbVar3[3] < pbVar4[3], pbVar3[3] == pbVar4[3]))))))
             )))))) goto LAB_00c5139a;
        uVar5 = -(uint)bVar8 | 1;
      }
      if (uVar5 == 0) {
        return (int)pbVar6 - (int)pbStack_8;
      }
    }
    if (pbVar6 == pbStack_8) {
      return 0xffffffff;
    }
    pbVar6 = pbVar6 + -1;
  } while( true );
}



/* FUNCTION 28540 ; VA 0x00c513d0 ; FUN_00c513d0 */

undefined2 __thiscall FUN_00c513d0(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *(int *)(param_2 + 0xc);
  iVar1 = FUN_00b739e0();
  iVar3 = 0;
  if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
      (uint)*(ushort *)(iVar1 + 0x1da)) {
    iVar3 = param_2;
  }
  if (iVar3 != 0) {
    iVar2 = FUN_0097bfc0(param_1 + -0x54);
    if ((iVar2 != 0) && (*(int *)(param_1 + -0x20) == iVar2)) {
      return 1;
    }
    return 0;
  }
  return 0;
}



/* FUNCTION 28541 ; VA 0x00c51450 ; FUN_00c51450 */

undefined * FUN_00c51450(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ae8c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd3fc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efd3fc);
    if (DAT_01efd3fc == -1) {
      uStack_8 = 0;
      FUN_00cbe0b0();
      FUN_016f3654(&LAB_01895180);
      FUN_016f37bf(&DAT_01efd3fc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01efd398;
}



/* FUNCTION 28542 ; VA 0x00c514e0 ; FUN_00c514e0 */

undefined * FUN_00c514e0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180aeac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd4cc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efd4cc);
    if (DAT_01efd4cc == -1) {
      uStack_8 = 0;
      FUN_00cbe110();
      FUN_016f3654(&LAB_018951a0);
      FUN_016f37bf(&DAT_01efd4cc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01efd468;
}



/* FUNCTION 28543 ; VA 0x00c51570 ; FUN_00c51570 */

undefined * FUN_00c51570(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180aecc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd464) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efd464);
    if (DAT_01efd464 == -1) {
      uStack_8 = 0;
      FUN_00cbe170();
      FUN_016f3654(&LAB_018951c0);
      FUN_016f37bf(&DAT_01efd464);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01efd400;
}



/* FUNCTION 28544 ; VA 0x00c51600 ; FUN_00c51600 */

undefined * FUN_00c51600(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180aeec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd534) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efd534);
    if (DAT_01efd534 == -1) {
      uStack_8 = 0;
      FUN_00cbe1d0();
      FUN_016f3654(&LAB_018951e0);
      FUN_016f37bf(&DAT_01efd534);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01efd4d0;
}



/* FUNCTION 28545 ; VA 0x00c51690 ; FUN_00c51690 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c51690(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd574) {
    FUN_016f3809(&DAT_01efd574);
    if (DAT_01efd574 == -1) {
      _DAT_01efd568 = FUN_005c65e0;
      _DAT_01efd56c = FUN_005c65e0;
      _DAT_01efd570 = _guard_check_icall;
      FUN_016f37bf(&DAT_01efd574);
    }
  }
  return &DAT_01efd568;
}



/* FUNCTION 28546 ; VA 0x00c51700 ; FUN_00c51700 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c51700(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd554) {
    FUN_016f3809(&DAT_01efd554);
    if (DAT_01efd554 == -1) {
      _DAT_01efd548 = FUN_005c65e0;
      _DAT_01efd54c = FUN_005c65e0;
      _DAT_01efd550 = _guard_check_icall;
      FUN_016f37bf(&DAT_01efd554);
    }
  }
  return &DAT_01efd548;
}



/* FUNCTION 28547 ; VA 0x00c51770 ; FUN_00c51770 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c51770(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd564) {
    FUN_016f3809(&DAT_01efd564);
    if (DAT_01efd564 == -1) {
      _DAT_01efd558 = FUN_005c65e0;
      _DAT_01efd55c = FUN_005c65e0;
      _DAT_01efd560 = _guard_check_icall;
      FUN_016f37bf(&DAT_01efd564);
    }
  }
  return &DAT_01efd558;
}



/* FUNCTION 28548 ; VA 0x00c517e0 ; FUN_00c517e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c517e0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd544) {
    FUN_016f3809(&DAT_01efd544);
    if (DAT_01efd544 == -1) {
      _DAT_01efd538 = FUN_005c65e0;
      _DAT_01efd53c = FUN_005c65e0;
      _DAT_01efd540 = _guard_check_icall;
      FUN_016f37bf(&DAT_01efd544);
    }
  }
  return &DAT_01efd538;
}



/* FUNCTION 28549 ; VA 0x00c51850 ; FUN_00c51850 */

undefined4 * FUN_00c51850(undefined4 *param_1,byte *param_2)

{
  byte *pbVar1;
  char cVar2;
  byte bVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  byte *pbVar10;
  int iVar11;
  byte *pbVar12;
  char acStack_140 [256];
  undefined auStack_40 [24];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180af18;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_2 + 0x10);
  pbVar12 = param_2;
  if (0xf < *(uint *)(param_2 + 0x14)) {
    pbVar12 = *(byte **)param_2;
  }
  ExceptionList = &pvStack_10;
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    FUN_0170d1f0(acStack_140,0,0x100);
    pbVar10 = &DAT_0195e5b8;
    iVar11 = 2;
    do {
      bVar3 = *pbVar10;
      pbVar10 = pbVar10 + 1;
      acStack_140[bVar3] = '\x01';
      iVar11 = iVar11 + -1;
    } while (iVar11 != 0);
    iVar4 = iVar4 + -1;
    iVar11 = -1;
    if (iVar4 != -1) {
      iVar11 = iVar4;
    }
    pbVar10 = pbVar12 + iVar11;
    cVar2 = acStack_140[*pbVar10];
    while (cVar2 == '\0') {
      if (pbVar10 == pbVar12) goto LAB_00c51a03;
      pbVar1 = pbVar10 + -1;
      pbVar10 = pbVar10 + -1;
      cVar2 = acStack_140[*pbVar1];
    }
    iVar11 = (int)pbVar10 - (int)pbVar12;
    if ((iVar11 != -1) && (iVar11 != 0)) {
      if (iVar11 != iVar4) {
        puVar8 = (undefined4 *)FUN_0058c540(auStack_40,iVar11 + 1,0xffffffff);
        uStack_8 = 2;
        puVar9 = (undefined4 *)FUN_0058c540(auStack_28,0,iVar11);
        param_1[4] = 0;
        param_1[5] = 0;
        uVar5 = puVar9[1];
        uVar6 = puVar9[2];
        uVar7 = puVar9[3];
        *param_1 = *puVar9;
        param_1[1] = uVar5;
        param_1[2] = uVar6;
        param_1[3] = uVar7;
        *(undefined8 *)(param_1 + 4) = *(undefined8 *)(puVar9 + 4);
        puVar9[4] = 0;
        puVar9[5] = 0xf;
        *(undefined *)puVar9 = 0;
        param_1[10] = 0;
        param_1[0xb] = 0;
        uVar5 = puVar8[1];
        uVar6 = puVar8[2];
        uVar7 = puVar8[3];
        param_1[6] = *puVar8;
        param_1[7] = uVar5;
        param_1[8] = uVar6;
        param_1[9] = uVar7;
        *(undefined8 *)(param_1 + 10) = *(undefined8 *)(puVar8 + 4);
        puVar8[4] = 0;
        puVar8[5] = 0xf;
        *(undefined *)puVar8 = 0;
        FUN_005507b0();
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return param_1;
      }
      FUN_0054ef60(param_2);
      uStack_8 = 1;
      param_1[10] = 0;
      param_1[0xb] = 0xf;
      *(undefined *)(param_1 + 6) = 0;
      FUN_005542c0(&DAT_018bc9b8,0);
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
LAB_00c51a03:
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  FUN_0054ef60(param_2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28550 ; VA 0x00c51a50 ; FUN_00c51a50 */

int * __thiscall
FUN_00c51a50(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180af43;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00896d50();
  uVar3 = FUN_00c51e00();
  FUN_009ca670(uVar3,iVar2,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,1);
  param_1[0xd] = iVar2;
  uStack_8 = 0;
  *param_1 = (int)RBX::Reflection::EnumPropDescriptor<class_RBX::ProximityPrompt,enum_RBX::KeyCode>
                  ::vftable;
  puVar4 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::PropDescriptor<class_RBX::ProximityPrompt,enum_RBX::KeyCode>::
              GetSetImpl<enum_RBX::KeyCode_(__thiscall_RBX::ProximityPrompt::*)(void)const_,void_(__thiscall_RBX::ProximityPrompt::*)(enum_RBX::KeyCode)>
              ::vftable;
    puVar4[2] = param_4;
    puVar4[3] = param_5;
    puVar4[4] = param_6;
    puVar4[5] = param_7;
  }
  param_1[0xe] = (int)puVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar2 = FUN_00896d50();
  param_1[0xf] = iVar2;
  cVar1 = (**(code **)(*param_1 + 0xc))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar1 = (**(code **)(*param_1 + 8))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28551 ; VA 0x00c51b30 ; FUN_00c51b30 */

int * __thiscall
FUN_00c51b30(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018066d3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c51e00();
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar3,uVar4,param_2,param_3,param_5,param_6,param_7,param_8,param_9,param_9,0);
  param_1[0xd] = 0;
  uStack_8 = 3;
  *param_1 = (int)RBX::Reflection::BoundProp<float,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<float,1>::BoundPropGetSet<class_RBX::ProximityPrompt>::
              vftable;
    puVar5[1] = param_1;
    puVar5[2] = param_4;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  puVar1 = (undefined4 *)param_1[0xd];
  param_1[0xd] = (int)puVar5;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  cVar2 = (**(code **)(*param_1 + 0xc))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar2 = (**(code **)(*param_1 + 8))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28552 ; VA 0x00c51c20 ; FUN_00c51c20 */

int * __thiscall
FUN_00c51c20(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180af73;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c51e00();
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar3,uVar4,param_2,param_3,param_5,param_6,param_7,param_8,param_9,param_9,0);
  param_1[0xd] = 0;
  uStack_8 = 3;
  *param_1 = (int)RBX::Reflection::
                  BoundProp<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,1>
                  ::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::
              BoundProp<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,1>
              ::BoundPropGetSet<class_RBX::ProximityPrompt>::vftable;
    puVar5[1] = param_1;
    puVar5[2] = param_4;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  puVar1 = (undefined4 *)param_1[0xd];
  param_1[0xd] = (int)puVar5;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  cVar2 = (**(code **)(*param_1 + 0xc))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar2 = (**(code **)(*param_1 + 8))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28553 ; VA 0x00c51d10 ; FUN_00c51d10 */

int * __thiscall
FUN_00c51d10(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5e23;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c51e00();
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar3,uVar4,param_2,param_3,param_5,param_6,param_7,param_8,param_9,param_9,0);
  param_1[0xd] = 0;
  uStack_8 = 3;
  *param_1 = (int)RBX::Reflection::BoundProp<bool,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::ProximityPrompt>::
              vftable;
    puVar5[1] = param_1;
    puVar5[2] = param_4;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  puVar1 = (undefined4 *)param_1[0xd];
  param_1[0xd] = (int)puVar5;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  cVar2 = (**(code **)(*param_1 + 0xc))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar2 = (**(code **)(*param_1 + 8))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28554 ; VA 0x00c51e00 ; FUN_00c51e00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c51e00(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180afa0;
  pvStack_10 = ExceptionList;
  if (DAT_01efd59c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd7b0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efd7b0);
      if (DAT_01efd7b0 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ProximityPrompt",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01efd7a8 = RBX::Creator<class_RBX::ProximityPrompt>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efd5a0,&DAT_01efd7a8);
        FUN_016f3654(FUN_01895640);
        FUN_016f37bf(&DAT_01efd7b0);
      }
    }
    DAT_01efd59c = &DAT_01efd5a0;
  }
  ExceptionList = pvStack_10;
  return DAT_01efd59c;
}



/* FUNCTION 28555 ; VA 0x00c51f00 ; FUN_00c51f00 */

int __thiscall FUN_00c51f00(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180afb0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ProximityPrompt*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28556 ; VA 0x00c51fd2 ; Catch_All@00c51fd2 */

void Catch_All_00c51fd2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28557 ; VA 0x00c51ff0 ; FUN_00c51ff0 */

undefined4 * FUN_00c51ff0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180aff3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c51e00();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xf8);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c52350();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c51f00(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28558 ; VA 0x00c520b0 ; FUN_00c520b0 */

undefined4 * __thiscall
FUN_00c520b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b021;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  uVar1 = FUN_00c51e00();
  FUN_009cb970(uVar1,param_3,0,CONCAT44(uStack_28,uStack_2c),0);
  param_1[0xd] = param_2;
  iStack_8 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::ProximityPrompt,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::ProximityPrompt::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,param_3);
  iStack_8._0_1_ = 2;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = uStack_1c;
    param_1[0xb] = uStack_18;
    param_1[0xc] = uStack_14;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
  }
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::ProximityPrompt,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::ProximityPrompt::*>
             ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28559 ; VA 0x00c521f0 ; FUN_00c521f0 */

undefined4 * __thiscall
FUN_00c521f0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 uVar1;
  undefined auStack_110 [216];
  undefined8 uStack_38;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_0180b051;
  pvStack_1c = ExceptionList;
  uStack_38 = param_6;
  ExceptionList = &pvStack_1c;
  puStack_30 = param_1;
  uVar1 = FUN_00c51e00();
  FUN_009cb970(uVar1,param_3,param_5,uStack_38,param_7);
  param_1[0xd] = param_2;
  iStack_14 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::ProximityPrompt,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::ProximityPrompt::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_14._0_1_ = 1;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00687810(auStack_110,&uStack_38,puStack_30);
  iStack_14._0_1_ = 2;
  if (param_1 + 10 != &uStack_2c) {
    FUN_0068a760();
    param_1[10] = uStack_2c;
    param_1[0xb] = uStack_28;
    param_1[0xc] = uStack_24;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
  }
  iStack_14._0_1_ = 3;
  FUN_0068a760();
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  FUN_016f32d1(auStack_110,0xd8,1,FUN_00688b10);
  param_1[0xe] = param_9;
  param_1[0xf] = param_8;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::ProximityPrompt,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::ProximityPrompt::*>
             ::vftable;
  ExceptionList = pvStack_1c;
  return param_1;
}



/* FUNCTION 28560 ; VA 0x00c52350 ; FUN_00c52350 */

undefined4 * __fastcall FUN_00c52350(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b160;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::ProximityPrompt,class_RBX::Instance>::vftable;
  uVar1 = FUN_00c51e00();
  param_1[3] = uVar1;
  *param_1 = RBX::ProximityPrompt::vftable;
  param_1[0x15] = 0x41200000;
  param_1[0x16] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0xf;
  uStack_8 = 1;
  *(undefined *)(param_1 + 0x17) = 0;
  FUN_005542c0("Interact",8);
  param_1[0x21] = 0;
  param_1[0x22] = 0xf;
  *(undefined *)(param_1 + 0x1d) = 0;
  param_1[0x23] = 0x1010101;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0x65;
  param_1[0x27] = 1000;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  uStack_8._0_1_ = 0x12;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("ProximityPrompt",0xf);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28561 ; VA 0x00c52570 ; FUN_00c52570 */

void __fastcall FUN_00c52570(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::ProximityPrompt>::vftable;
  uVar1 = FUN_00c51e00(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28562 ; VA 0x00c525b0 ; FUN_00c525b0 */

void __fastcall FUN_00c525b0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = (int *)param_1[4];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[2];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *param_1 = RBX::HitTestFilter::vftable;
  return;
}



/* FUNCTION 28563 ; VA 0x00c52610 ; FUN_00c52610 */

void __fastcall FUN_00c52610(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  
  iVar3 = *(int *)(param_1 + 0xf4);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  iVar3 = *(int *)(param_1 + 0xe8);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  iVar3 = *(int *)(param_1 + 0xdc);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  iVar3 = *(int *)(param_1 + 0xd0);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  piVar1 = *(int **)(param_1 + 0xac);
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar2 = piVar1 + 2;
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  uVar4 = *(uint *)(param_1 + 0x88);
  if (0xf < uVar4) {
    iVar3 = *(int *)(param_1 + 0x74);
    uVar6 = uVar4 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar4 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_00c527ec;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x84) = 0;
  *(undefined4 *)(param_1 + 0x88) = 0xf;
  *(undefined *)(param_1 + 0x74) = 0;
  uVar4 = *(uint *)(param_1 + 0x70);
  if (0xf < uVar4) {
    iVar3 = *(int *)(param_1 + 0x5c);
    uVar6 = uVar4 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar4 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
LAB_00c527ec:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x6c) = 0;
  *(undefined4 *)(param_1 + 0x70) = 0xf;
  *(undefined *)(param_1 + 0x5c) = 0;
  FUN_0089b230();
  return;
}



/* FUNCTION 28564 ; VA 0x00c52800 ; FUN_00c52800 */

undefined4 * __thiscall FUN_00c52800(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector2>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 28565 ; VA 0x00c52830 ; FUN_00c52830 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c52830(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::ProximityPrompt::ProximityPromptExclusivity>::
             vftable;
  _DAT_01efd7c0 = _DAT_01efd7c0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 28566 ; VA 0x00c52860 ; FUN_00c52860 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c52860(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::ProximityPrompt::ProximityPromptStyle>::vftable;
  _DAT_01efd7b8 = _DAT_01efd7b8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 28567 ; VA 0x00c52890 ; FUN_00c52890 */

undefined4 * __thiscall FUN_00c52890(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::KeyCode>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 28568 ; VA 0x00c528c0 ; FUN_00c528c0 */

undefined4 * __thiscall FUN_00c528c0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<enum_RBX::ProximityPrompt::ProximityPromptExclusivity>::GetSet
             ::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 28569 ; VA 0x00c528f0 ; FUN_00c528f0 */

undefined4 * __thiscall FUN_00c528f0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<enum_RBX::ProximityPrompt::ProximityPromptStyle>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 28570 ; VA 0x00c52920 ; FUN_00c52920 */

undefined4 * __thiscall FUN_00c52920(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::LocalizationTable*>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 28571 ; VA 0x00c52950 ; FUN_00c52950 */

undefined4 * __thiscall FUN_00c52950(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::LocalizationTable*>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 28572 ; VA 0x00c52980 ; FUN_00c52980 */

undefined4 * __thiscall FUN_00c52980(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::KeyCode>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 28573 ; VA 0x00c529b0 ; FUN_00c529b0 */

undefined4 * __thiscall FUN_00c529b0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<enum_RBX::ProximityPrompt::ProximityPromptExclusivity>::GetSet
             ::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 28574 ; VA 0x00c529e0 ; FUN_00c529e0 */

undefined4 * __thiscall FUN_00c529e0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<enum_RBX::ProximityPrompt::ProximityPromptStyle>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 28575 ; VA 0x00c52a10 ; FUN_00c52a10 */

undefined4 __thiscall FUN_00c52a10(undefined4 param_1,byte param_2)

{
  FUN_00c52610();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xf8);
  }
  return param_1;
}



/* FUNCTION 28576 ; VA 0x00c52a40 ; thunk_FUN_00c551a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00c551a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b496;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd894) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efd894);
    if (DAT_01efd894 == -1) {
      uStack_8 = 0;
      FUN_009ca470("ProximityPromptStyle");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01efd830 =
           RBX::Reflection::EnumDesc<enum_RBX::ProximityPrompt::ProximityPromptStyle>::vftable;
      FUN_009caf20(&DAT_01d6882c,2);
      FUN_016f3654(&LAB_018955a0);
      FUN_016f37bf(&DAT_01efd894);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01efd830;
}



/* FUNCTION 28577 ; VA 0x00c52a50 ; FUN_00c52a50 */

uint FUN_00c52a50(int param_1)

{
  int iVar1;
  uint in_EAX;
  int iVar2;
  uint uVar3;
  
  if (DAT_01d68804 == '\0') {
    uVar3 = FUN_005c92d0();
    return uVar3;
  }
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00aff8c0();
    in_EAX = (uint)*(ushort *)(iVar2 + 0x1da);
    if (in_EAX < (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) {
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_00b63e30();
      in_EAX = (uint)*(ushort *)(iVar2 + 0x1da);
      if (in_EAX < (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) {
        iVar1 = *(int *)(param_1 + 0xc);
        iVar2 = FUN_00d6bbd0();
        in_EAX = (uint)*(ushort *)(iVar2 + 0x1da);
        if (in_EAX < (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))
        goto LAB_00c52ada;
      }
    }
    return CONCAT31((int3)(in_EAX >> 8),1);
  }
LAB_00c52ada:
  return in_EAX & 0xffffff00;
}



/* FUNCTION 28578 ; VA 0x00c52af0 ; FUN_00c52af0 */

uint __thiscall FUN_00c52af0(uint param_1,undefined4 param_2,int *param_3)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_0180b290;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_2c = param_2;
  piStack_28 = param_3;
  uStack_34 = 0xc52b4a;
  uStack_30 = param_1;
  uVar5 = FUN_00925d30();
  if (param_1 != 0) {
    uVar3 = *(uint *)(param_1 + 0x34);
    uVar7 = param_1;
    if ((uVar3 != 0) && (uVar7 = uVar3, *(int *)(uVar3 + 0x34) != 0)) {
      piStack_28 = (int *)0xc52b65;
      uVar5 = FUN_005c8ac0();
      uVar7 = uVar5;
    }
    if (uVar7 != 0) {
      iVar4 = *(int *)(uVar7 + 0xc);
      piStack_28 = (int *)0xc52b77;
      iVar6 = FUN_008a8c30();
      uVar5 = (uint)*(ushort *)(iVar6 + 0x1da);
      if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <= uVar5) {
        piStack_28 = (int *)0xc52b99;
        uVar5 = FUN_00672d00();
        if (uVar5 != 0) {
          if (param_3 != (int *)0x0) {
            LOCK();
            param_3[1] = param_3[1] + 1;
            UNLOCK();
          }
          uStack_2c = param_2;
          piStack_28 = param_3;
          iStack_8._0_1_ = 1;
          FUN_0060dcd0(&uStack_34,param_1);
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          uVar5 = FUN_00c10960();
        }
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_3 + 1);
    uVar3 = *puVar1;
    uVar5 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      piStack_28 = (int *)0xc52c01;
      uVar5 = (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        piStack_28 = (int *)0xc52c10;
        uVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 28579 ; VA 0x00c52c30 ; FUN_00c52c30 */

uint __thiscall FUN_00c52c30(uint param_1,undefined4 param_2,int *param_3)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_0180b290;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_2c = param_2;
  piStack_28 = param_3;
  uStack_34 = 0xc52c8a;
  uStack_30 = param_1;
  uVar5 = FUN_00925d30();
  if (param_1 != 0) {
    uVar3 = *(uint *)(param_1 + 0x34);
    uVar7 = param_1;
    if ((uVar3 != 0) && (uVar7 = uVar3, *(int *)(uVar3 + 0x34) != 0)) {
      piStack_28 = (int *)0xc52ca5;
      uVar5 = FUN_005c8ac0();
      uVar7 = uVar5;
    }
    if (uVar7 != 0) {
      iVar4 = *(int *)(uVar7 + 0xc);
      piStack_28 = (int *)0xc52cb7;
      iVar6 = FUN_008a8c30();
      uVar5 = (uint)*(ushort *)(iVar6 + 0x1da);
      if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <= uVar5) {
        piStack_28 = (int *)0xc52cd9;
        uVar5 = FUN_00672d00();
        if (uVar5 != 0) {
          if (param_3 != (int *)0x0) {
            LOCK();
            param_3[1] = param_3[1] + 1;
            UNLOCK();
          }
          uStack_2c = param_2;
          piStack_28 = param_3;
          iStack_8._0_1_ = 1;
          FUN_0060dcd0(&uStack_34,param_1);
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          uVar5 = FUN_00c10a40();
        }
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_3 + 1);
    uVar3 = *puVar1;
    uVar5 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      piStack_28 = (int *)0xc52d41;
      uVar5 = (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        piStack_28 = (int *)0xc52d50;
        uVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 28580 ; VA 0x00c52d70 ; FUN_00c52d70 */

undefined __fastcall FUN_00c52d70(float param_1)

{
  int iVar1;
  undefined4 *puVar2;
  undefined *puVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  undefined4 *puVar7;
  int *piVar8;
  float10 fVar9;
  double dVar10;
  float fVar11;
  float fVar12;
  undefined8 uVar13;
  undefined8 uStack_128;
  undefined auStack_114 [48];
  undefined auStack_e4 [4];
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined auStack_c4 [20];
  undefined8 uStack_b0;
  int *piStack_a8;
  undefined8 uStack_a4;
  float fStack_9c;
  undefined **appuStack_98 [3];
  undefined **appuStack_8c [3];
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined8 uStack_78;
  undefined **appuStack_70 [2];
  int *piStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  int iStack_5c;
  undefined8 uStack_58;
  int *piStack_50;
  undefined8 uStack_4c;
  float fStack_44;
  undefined8 uStack_40;
  int *piStack_38;
  float fStack_30;
  undefined **ppuStack_2c;
  undefined4 *puStack_28;
  undefined uStack_21;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_0180b2e2;
  pvStack_1c = ExceptionList;
  if (*(char *)((int)param_1 + 0x8e) == '\0') {
    return 1;
  }
  ExceptionList = &pvStack_1c;
  fStack_30 = param_1;
  puVar3 = &stack0xfffffffc;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd598) {
    uStack_128._4_4_ = (undefined ***)&DAT_01efd598;
    uStack_128._0_4_ = (char *)0xc5326e;
    ExceptionList = &pvStack_1c;
    FUN_016f3809();
    puVar3 = puStack_20;
    if (DAT_01efd598 == -1) {
      uStack_128._4_4_ = (undefined ***)0xffffffff;
      uStack_128._0_4_ = "checkIfLineOfSightClear";
      uStack_14 = 0;
      uVar13 = FUN_0152dab0(&DAT_018fdbdc);
      DAT_01efd594 = (undefined4)((ulonglong)uVar13 >> 0x20);
      DAT_01efd590 = (undefined4)uVar13;
      uStack_14 = 0xffffffff;
      FUN_016f37bf(&DAT_01efd598);
      puVar3 = puStack_20;
    }
  }
  puStack_20 = puVar3;
  uStack_128._4_4_ = (undefined ***)DAT_01efd594;
  uStack_128._0_4_ = (char *)DAT_01efd590;
  uStack_64 = DAT_01efd590;
  uStack_80 = DAT_01efd590;
  uStack_60 = DAT_01efd594;
  uStack_7c = DAT_01efd594;
  uStack_78 = FUN_0152d930();
  uStack_14 = 1;
  iVar5 = FUN_008f7870(param_1);
  if (iVar5 != 0) {
    iVar5 = *(int *)(iVar5 + 0x1b8);
    iStack_5c = iVar5;
    if (iVar5 != 0) {
      uStack_128._4_4_ = (undefined ***)0xc52e3c;
      FUN_00f9ba20();
      uStack_14._0_1_ = 2;
      uStack_128._0_4_ = (char *)0xc52e4c;
      uStack_128._4_4_ = (undefined ***)iVar5;
      FUN_00f9bab0();
      uStack_128._4_4_ = &ppuStack_2c;
      uStack_14._0_1_ = 3;
      uStack_128._0_4_ = auStack_c4;
      FUN_00f9ba80();
      iVar5 = *(int *)((int)param_1 + 0x34);
      puStack_28 = (undefined4 *)&uStack_128;
      uStack_14 = CONCAT31(uStack_14._1_3_,4);
      for (; iVar5 != 0; iVar5 = *(int *)(iVar5 + 0x34)) {
        iVar1 = *(int *)(iVar5 + 0xc);
        iVar6 = FUN_00d6bbd0();
        if ((uint)*(ushort *)(iVar6 + 0x1da) <
            (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)) {
          if (iVar5 == 0) break;
          iVar1 = *(int *)(iVar5 + 0xc);
          iVar6 = FUN_00aff8c0();
          if ((uint)*(ushort *)(iVar6 + 0x1da) <
              (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)) {
            iVar1 = *(int *)(iVar5 + 0xc);
            iVar6 = FUN_00b63e30();
            if ((uint)*(ushort *)(iVar6 + 0x1da) <
                (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)) break;
            puVar7 = (undefined4 *)FUN_0060dcd0((int)&uStack_40 + 4,iVar5);
            puVar2 = puStack_28;
            *puStack_28 = 0;
            puVar2[1] = 0;
            *puVar2 = *puVar7;
            puVar2[1] = puVar7[1];
            *puVar7 = 0;
            puVar7[1] = 0;
            piVar8 = piStack_38;
          }
          else {
            puVar7 = (undefined4 *)FUN_0060dcd0((int)&uStack_58 + 4,iVar5);
            puVar2 = puStack_28;
            *puStack_28 = 0;
            puVar2[1] = 0;
            *puVar2 = *puVar7;
            puVar2[1] = puVar7[1];
            *puVar7 = 0;
            puVar7[1] = 0;
            piVar8 = piStack_50;
          }
          if (piVar8 != (int *)0x0) {
            LOCK();
            iVar5 = piVar8[1] + -1;
            piVar8[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)*piVar8)();
              LOCK();
              iVar5 = piVar8[2] + -1;
              piVar8[2] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)(*piVar8 + 4))();
              }
            }
          }
          goto LAB_00c52fa4;
        }
      }
      puVar2 = puStack_28;
      *puStack_28 = 0;
      puVar2[1] = 0;
LAB_00c52fa4:
      FUN_00f9b8c0();
      uStack_128._4_4_ = appuStack_70;
      uStack_14._0_1_ = 5;
      uStack_128._0_4_ = (char *)appuStack_98;
      FUN_00f9ba80();
      uStack_14 = CONCAT31(uStack_14._1_3_,6);
      uStack_128._4_4_ = (undefined ***)0xc52fd7;
      iVar5 = (**(code **)(*(int *)(iStack_5c + 0x144) + 4))();
      uStack_128._4_4_ = (undefined ***)auStack_114;
      piStack_50 = *(int **)(iVar5 + 0x98);
      uStack_58 = *(ulonglong *)(iVar5 + 0x90);
      uStack_128._0_4_ = (char *)0xc52ffe;
      iVar5 = FUN_00c53ca0();
      uStack_40 = uStack_58 & 0xffffffff;
      fStack_44 = *(float *)(iVar5 + 0x2c) - (float)piStack_50;
      uStack_4c = CONCAT44(*(float *)(iVar5 + 0x28) - uStack_58._4_4_,
                           *(float *)(iVar5 + 0x24) - (float)uStack_58);
      uStack_128._4_4_ = (undefined ***)0xc5303b;
      fVar9 = (float10)FUN_00d22f10();
      puStack_28 = (undefined4 *)(float)fVar9;
      dVar10 = (double)(uStack_4c._4_4_ * uStack_4c._4_4_ + (float)uStack_4c * (float)uStack_4c +
                       fStack_44 * fStack_44);
      uStack_128._4_4_ = (undefined ***)0xc53069;
      FUN_017267a0();
      fStack_30 = (float)dVar10 - (float)puStack_28;
      if (0.0 < fStack_30) {
        uStack_128._4_4_ = (undefined ***)0x358637bd;
        uStack_128._0_4_ = (char *)0xc5309b;
        FUN_01165610();
        uStack_d0 = 0;
        uStack_cc = 0;
        piStack_a8 = (int *)((float)piStack_50 + fStack_44 * (float)puStack_28);
        fVar12 = (float)uStack_4c * fStack_30;
        fVar11 = uStack_4c._4_4_ * fStack_30;
        fStack_9c = fStack_44 * fStack_30;
        uStack_b0 = CONCAT44(uStack_58._4_4_ + uStack_4c._4_4_ * (float)puStack_28,
                             (float)uStack_40 + (float)uStack_4c * (float)puStack_28);
        uStack_4c = CONCAT44(fVar11,fVar12);
        uStack_a4 = CONCAT44(fVar11,fVar12);
        uStack_e0 = 0;
        uStack_dc = 0;
        uStack_d8 = 0;
        uStack_d4 = 0;
        uStack_128._4_4_ = (undefined ***)auStack_e4;
        uStack_128._0_4_ = (char *)&uStack_40;
        uStack_40._0_7_ = ZEXT47(appuStack_8c);
        piStack_38 = (int *)0x0;
        piStack_50 = piStack_a8;
        fStack_44 = fStack_9c;
        cVar4 = FUN_00ce2b90(&uStack_b0);
        if (cVar4 == '\0') {
          appuStack_8c[0] = RBX::HitTestFilter::vftable;
          if (piStack_68 != (int *)0x0) {
            LOCK();
            iVar5 = piStack_68[1] + -1;
            piStack_68[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              uStack_128._4_4_ = (undefined ***)0xc531fd;
              (**(code **)*piStack_68)();
              LOCK();
              piVar8 = piStack_68 + 2;
              iVar5 = *piVar8;
              *piVar8 = *piVar8 + -1;
              UNLOCK();
              if (iVar5 == 1) {
                uStack_128._4_4_ = (undefined ***)0xc5320c;
                (**(code **)(*piStack_68 + 4))();
              }
            }
          }
          appuStack_70[0] = RBX::HitTestFilter::vftable;
          appuStack_98[0] = RBX::HitTestFilter::vftable;
          uStack_128._4_4_ = (undefined ***)0xc53228;
          FUN_00c525b0();
          ppuStack_2c = RBX::HitTestFilter::vftable;
          goto LAB_00c5322f;
        }
        uStack_21 = 0;
      }
      else {
        uStack_21 = 1;
      }
      appuStack_8c[0] = RBX::HitTestFilter::vftable;
      if (piStack_68 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_68[1] + -1;
        piStack_68[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          uStack_128._4_4_ = (undefined ***)0xc531ac;
          (**(code **)*piStack_68)();
          LOCK();
          piVar8 = piStack_68 + 2;
          iVar5 = *piVar8;
          *piVar8 = *piVar8 + -1;
          UNLOCK();
          if (iVar5 == 1) {
            uStack_128._4_4_ = (undefined ***)0xc531bb;
            (**(code **)(*piStack_68 + 4))();
          }
        }
      }
      appuStack_70[0] = RBX::HitTestFilter::vftable;
      appuStack_98[0] = RBX::HitTestFilter::vftable;
      uStack_128._4_4_ = (undefined ***)0xc531d7;
      FUN_00c525b0();
      ppuStack_2c = RBX::HitTestFilter::vftable;
      goto LAB_00c53233;
    }
  }
LAB_00c5322f:
  uStack_21 = 1;
LAB_00c53233:
  uStack_14 = 9;
  uStack_128 = uStack_78;
  FUN_0152dda0(uStack_64,uStack_60);
  ExceptionList = pvStack_1c;
  return uStack_21;
}



/* FUNCTION 28581 ; VA 0x00c532c0 ; FUN_00c532c0 */

undefined4 * __thiscall
FUN_00c532c0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180b321;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00c53610;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28582 ; VA 0x00c53460 ; FUN_00c53460 */

void FUN_00c53460(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00c550f0();
    *param_2 = uVar3;
    iVar4 = FUN_00c55250();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 28583 ; VA 0x00c534c0 ; FUN_00c534c0 */

void FUN_00c534c0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00c551a0();
    *param_2 = uVar3;
    iVar4 = FUN_00c552c0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 28584 ; VA 0x00c53520 ; FUN_00c53520 */

void FUN_00c53520(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c550f0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28585 ; VA 0x00c53560 ; FUN_00c53560 */

void FUN_00c53560(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c551a0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28586 ; VA 0x00c535a0 ; FUN_00c535a0 */

undefined4 * FUN_00c535a0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c51ff0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 28587 ; VA 0x00c53610 ; FUN_00c53610 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00c53610(int param_1,undefined4 param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uStack_f0;
  undefined *puStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbcf9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_02110da8);
  iStack_8 = 0;
  pcVar1 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar2;
  uStack_f0 = thunk_FUN_00c12520();
  uStack_e8 = param_2;
  puStack_ec = (undefined *)0x0;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8e04) {
    FUN_016f3809(&DAT_01ef8e04);
    if (DAT_01ef8e04 == -1) {
      _DAT_01ef8df8 = FUN_005c65e0;
      _DAT_01ef8dfc = FUN_005c65e0;
      _DAT_01ef8e00 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef8e04);
    }
  }
  puStack_ec = &DAT_01ef8df8;
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,pcVar1);
  iStack_8._0_1_ = 2;
  (*pcVar1)(&uStack_1c);
  iStack_8._0_1_ = 3;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  iStack_8 = 4;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28588 ; VA 0x00c53770 ; FUN_00c53770 */

int FUN_00c53770(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00c52af0(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 28589 ; VA 0x00c53800 ; FUN_00c53800 */

int FUN_00c53800(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00c55660(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 28590 ; VA 0x00c53890 ; FUN_00c53890 */

int FUN_00c53890(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00c52c30(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 28591 ; VA 0x00c53920 ; FUN_00c53920 */

int FUN_00c53920(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00c55520(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 28592 ; VA 0x00c539b0 ; FUN_00c539b0 */

undefined __thiscall FUN_00c539b0(int param_1,int param_2,int param_3)

{
  float *pfVar1;
  float fVar2;
  int iVar3;
  
  iVar3 = *(int *)(param_1 + 8);
  if (((NAN(*(float *)(iVar3 + param_2)) || NAN(*(float *)(iVar3 + param_3))) !=
       (*(float *)(iVar3 + param_2) == *(float *)(iVar3 + param_3))) &&
     (fVar2 = *(float *)(iVar3 + 4 + param_2), pfVar1 = (float *)(iVar3 + 4 + param_3),
     (NAN(fVar2) || NAN(*pfVar1)) != (fVar2 == *pfVar1))) {
    return 1;
  }
  return 0;
}



/* FUNCTION 28593 ; VA 0x00c539f0 ; FUN_00c539f0 */

void FUN_00c539f0(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_2 = (int *)*param_2;
  iVar1 = *param_2;
  iVar2 = thunk_FUN_00c12520();
  if (iVar1 == iVar2) {
    piVar3 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_005e6780(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28594 ; VA 0x00c53a40 ; FUN_00c53a40 */

int __fastcall FUN_00c53a40(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d00a8;
  pvStack_10 = ExceptionList;
  if (DAT_01d68824 == '\0') {
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00925d30(param_1,0,0);
    ExceptionList = pvStack_10;
    return iVar3;
  }
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0097bfc0(param_1);
  if (iVar3 != 0) {
    FUN_0060dcd0(&uStack_1c,iVar3);
    uStack_8 = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
    }
    FUN_009253f0(param_1,uStack_1c,piStack_18);
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
    }
    iVar3 = FUN_00c52af0(uStack_1c,piStack_18);
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_18 + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piStack_18 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar3 = (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 28595 ; VA 0x00c53b50 ; FUN_00c53b50 */

int __fastcall FUN_00c53b50(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d00a8;
  pvStack_10 = ExceptionList;
  if (DAT_01d68824 == '\0') {
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00925d30(param_1,0,0);
    ExceptionList = pvStack_10;
    return iVar3;
  }
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0097bfc0(param_1);
  if (iVar3 != 0) {
    FUN_0060dcd0(&uStack_1c,iVar3);
    uStack_8 = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
    }
    FUN_009253f0(param_1,uStack_1c,piStack_18);
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
    }
    iVar3 = FUN_00c52c30(uStack_1c,piStack_18);
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_18 + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piStack_18 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar3 = (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 28596 ; VA 0x00c53c60 ; FUN_00c53c60 */

void FUN_00c53c60(void)

{
  FUN_006eccd0();
  return;
}



/* FUNCTION 28597 ; VA 0x00c53c70 ; FUN_00c53c70 */

void FUN_00c53c70(void)

{
  FUN_005e6780();
  return;
}



/* FUNCTION 28598 ; VA 0x00c53c80 ; FUN_00c53c80 */

void FUN_00c53c80(void)

{
  int iVar1;
  
  if (DAT_01efd7b4 == 0) {
    iVar1 = FUN_00c51e00();
    DAT_01efd7b4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28599 ; VA 0x00c53ca0 ; FUN_00c53ca0 */

undefined4 * __thiscall FUN_00c53ca0(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  
  if ((*(int *)(param_1 + 0x34) != 0) &&
     (iVar6 = *(int *)(*(int *)(param_1 + 0x34) + 0xc), iVar4 = FUN_00aff8c0(),
     (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
     (uint)*(ushort *)(iVar4 + 0x1da))) {
LAB_00c53cd4:
    puVar5 = (undefined4 *)FUN_00b077e0();
    uVar1 = puVar5[1];
    uVar2 = puVar5[2];
    uVar3 = puVar5[3];
    *param_2 = *puVar5;
    param_2[1] = uVar1;
    param_2[2] = uVar2;
    param_2[3] = uVar3;
    uVar1 = puVar5[5];
    uVar2 = puVar5[6];
    uVar3 = puVar5[7];
    param_2[4] = puVar5[4];
    param_2[5] = uVar1;
    param_2[6] = uVar2;
    param_2[7] = uVar3;
    uVar1 = puVar5[9];
    uVar2 = puVar5[10];
    uVar3 = puVar5[0xb];
    param_2[8] = puVar5[8];
    param_2[9] = uVar1;
    param_2[10] = uVar2;
    param_2[0xb] = uVar3;
    return param_2;
  }
  if ((*(int *)(param_1 + 0x34) != 0) &&
     (iVar6 = *(int *)(*(int *)(param_1 + 0x34) + 0xc), iVar4 = FUN_00d6bbd0(),
     (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
     (uint)*(ushort *)(iVar4 + 0x1da))) {
    FUN_00d6c6c0(param_2);
    return param_2;
  }
  if ((*(int *)(param_1 + 0x34) != 0) &&
     (iVar6 = *(int *)(*(int *)(param_1 + 0x34) + 0xc), iVar4 = FUN_00b63e30(),
     (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
     (uint)*(ushort *)(iVar4 + 0x1da))) {
    if (DAT_01d6881c == '\0') {
      FUN_00b65c40(param_2);
      return param_2;
    }
    iVar6 = FUN_00b65ea0();
    if (iVar6 != 0) goto LAB_00c53cd4;
  }
  FUN_0060efa0();
  return param_2;
}



/* FUNCTION 28600 ; VA 0x00c53db0 ; FUN_00c53db0 */

undefined4 FUN_00c53db0(void)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00587490(auStack_c);
  uVar2 = *puVar4;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return uVar2;
  }
  return uVar2;
}



/* FUNCTION 28601 ; VA 0x00c53e10 ; FUN_00c53e10 */

float10 __fastcall FUN_00c53e10(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  int *piVar6;
  float fVar7;
  double dVar8;
  float fVar9;
  float fVar10;
  float fStack_70;
  float fStack_6c;
  float fStack_58;
  float fStack_54;
  undefined auStack_50 [4];
  int *piStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_3c;
  undefined auStack_38 [52];
  
  iVar1 = FUN_008f7870(param_1);
  if ((iVar1 != 0) && (*(int *)(iVar1 + 0x1b8) != 0)) {
    iVar1 = (**(code **)(*(int *)(*(int *)(iVar1 + 0x1b8) + 0x144) + 4))();
    iVar2 = FUN_00c53ca0(auStack_38);
    FUN_00d23ff0(&fStack_48,iVar2 + 0x24);
    fStack_6c = fStack_48;
    fStack_70 = fStack_44;
    if (param_1 != 0) {
      iVar2 = *(int *)(param_1 + 0x34);
      if ((iVar2 != 0) && (param_1 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
        param_1 = FUN_005c8ac0();
      }
      if ((param_1 != 0) &&
         (iVar2 = *(int *)(param_1 + 0xc), iVar3 = FUN_008a8c30(),
         (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
         (uint)*(ushort *)(iVar3 + 0x1da))) {
        FUN_005789c0(&DAT_01ead5f8,&LAB_006340d0);
        uVar4 = FUN_006352d0();
        piVar5 = (int *)FUN_008aa140(uVar4);
        if (*piVar5 == 0) {
          uVar4 = FUN_00b8c410();
          piVar6 = (int *)FUN_008a9ba0(auStack_50,uVar4);
          iVar2 = *piVar6;
          iVar3 = piVar6[1];
          *piVar6 = 0;
          piVar6[1] = 0;
          *piVar5 = iVar2;
          piVar6 = (int *)piVar5[1];
          piVar5[1] = iVar3;
          if (piVar6 != (int *)0x0) {
            LOCK();
            iVar2 = piVar6[1] + -1;
            piVar6[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piVar6)();
              LOCK();
              iVar2 = piVar6[2] + -1;
              piVar6[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piVar6 + 4))();
              }
            }
          }
          if (piStack_4c != (int *)0x0) {
            LOCK();
            iVar2 = piStack_4c[1] + -1;
            piStack_4c[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piStack_4c)();
              LOCK();
              piVar6 = piStack_4c + 2;
              iVar2 = *piVar6;
              *piVar6 = *piVar6 + -1;
              UNLOCK();
              if (iVar2 == 1) {
                (**(code **)(*piStack_4c + 4))();
              }
            }
          }
        }
        iVar2 = *piVar5;
        if (iVar2 != 0) {
          fStack_6c = fStack_48 - *(float *)(iVar2 + 0xf8);
          fStack_70 = fStack_44 - *(float *)(iVar2 + 0xfc);
        }
      }
    }
    fVar7 = 0.0;
    if (0.0 <= fStack_70) {
      fVar7 = fStack_70;
    }
    fVar10 = (float)(int)(short)*(undefined4 *)(iVar1 + 0x1cc);
    fVar9 = (float)(int)(short)((uint)*(undefined4 *)(iVar1 + 0x1cc) >> 0x10);
    if (fVar7 <= fVar9) {
      fVar9 = fVar7;
    }
    fVar7 = 0.0;
    if (0.0 <= fStack_6c) {
      fVar7 = fStack_6c;
    }
    if (fVar7 <= fVar10) {
      fVar10 = fVar7;
    }
    if (((0.0 < fStack_3c) && ((NAN(fVar10) || NAN(fStack_6c)) != (fVar10 == fStack_6c))) &&
       ((NAN(fVar9) || NAN(fStack_70)) != (fVar9 == fStack_70))) {
      FUN_01163100(&fStack_58,0x40000000);
      dVar8 = (double)((fVar9 - fStack_54) * (fVar9 - fStack_54) +
                      (fVar10 - fStack_58) * (fVar10 - fStack_58));
      FUN_017267a0();
      return (float10)(float)dVar8;
    }
  }
  return (float10)DAT_018f7864;
}



/* FUNCTION 28602 ; VA 0x00c54090 ; FUN_00c54090 */

undefined4 __fastcall FUN_00c54090(int param_1)

{
  return *(undefined4 *)(param_1 + 0xa0);
}



/* FUNCTION 28603 ; VA 0x00c540a0 ; FUN_00c540a0 */

void __thiscall FUN_00c540a0(int param_1,undefined4 *param_2,int param_3)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 8);
  *param_2 = *(undefined4 *)(iVar1 + param_3);
  param_2[1] = *(undefined4 *)(iVar1 + 4 + param_3);
  return;
}



/* FUNCTION 28604 ; VA 0x00c540c0 ; FUN_00c540c0 */

void __thiscall FUN_00c540c0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_00896d50();
  *param_3 = uVar3;
  iVar4 = FUN_00897340();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 28605 ; VA 0x00c54120 ; FUN_00c54120 */

void __thiscall FUN_00c54120(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_00c550f0();
  *param_3 = uVar3;
  iVar4 = FUN_00c55250();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 28606 ; VA 0x00c54180 ; FUN_00c54180 */

void __thiscall FUN_00c54180(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_00c551a0();
  *param_3 = uVar3;
  iVar4 = FUN_00c552c0();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 28607 ; VA 0x00c541e0 ; FUN_00c541e0 */

void __fastcall FUN_00c541e0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined auStack_1c [4];
  undefined4 uStack_18;
  
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0x34);
    iVar1 = param_1;
    if ((iVar2 != 0) && (iVar1 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
      uStack_18 = 0xc54200;
      iVar1 = FUN_005c8ac0();
    }
    if (iVar1 != 0) {
      iVar2 = *(int *)(iVar1 + 0xc);
      uStack_18 = 0xc54212;
      iVar1 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
          (uint)*(ushort *)(iVar1 + 0x1da)) {
        uStack_18 = 0xc54234;
        iVar2 = FUN_00672d00();
        if (iVar2 != 0) {
          FUN_0060dcd0(auStack_1c,param_1);
          FUN_00c11850();
        }
      }
    }
  }
  return;
}



/* FUNCTION 28608 ; VA 0x00c54260 ; FUN_00c54260 */

void __fastcall FUN_00c54260(int param_1)

{
  int iVar1;
  int iVar2;
  undefined auStack_1c [4];
  undefined4 uStack_18;
  
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0x34);
    iVar1 = param_1;
    if ((iVar2 != 0) && (iVar1 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
      uStack_18 = 0xc54280;
      iVar1 = FUN_005c8ac0();
    }
    if (iVar1 != 0) {
      iVar2 = *(int *)(iVar1 + 0xc);
      uStack_18 = 0xc54292;
      iVar1 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
          (uint)*(ushort *)(iVar1 + 0x1da)) {
        uStack_18 = 0xc542b4;
        iVar2 = FUN_00672d00();
        if (iVar2 != 0) {
          FUN_0060dcd0(auStack_1c,param_1);
          FUN_00c11990();
        }
      }
    }
  }
  return;
}



/* FUNCTION 28609 ; VA 0x00c542e0 ; FUN_00c542e0 */

uint FUN_00c542e0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c51e00();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 28610 ; VA 0x00c54300 ; FUN_00c54300 */

uint FUN_00c54300(void)

{
  int iVar1;
  
  iVar1 = FUN_00c51e00();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 28611 ; VA 0x00c54320 ; FUN_00c54320 */

void FUN_00c54320(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c550f0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28612 ; VA 0x00c54360 ; FUN_00c54360 */

void FUN_00c54360(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c551a0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28613 ; VA 0x00c543a0 ; FUN_00c543a0 */

void __thiscall FUN_00c543a0(undefined4 param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined *puStack_34;
  int iStack_30;
  undefined auStack_20 [8];
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b340;
  pvStack_10 = ExceptionList;
  iStack_30 = param_2;
  puStack_34 = (undefined *)0xc543c9;
  ExceptionList = &pvStack_10;
  FUN_008a3ee0();
  if (DAT_01d68814 != '\0') {
    iStack_30 = *(undefined4 *)(param_2 + 4);
    puStack_34 = (undefined *)0xc543de;
    iVar1 = FUN_008b3380();
    puStack_34 = *(undefined **)(param_2 + 8);
    iVar2 = FUN_008b3380();
    if (iVar1 != iVar2) {
      if (iVar1 != 0) {
        puStack_34 = (undefined *)0xc543ff;
        iStack_30 = iVar1;
        iVar3 = FUN_008991d0();
        if (iVar3 != 0) {
          puStack_34 = auStack_20;
          iStack_30 = param_1;
          uVar4 = FUN_0060dcd0();
          uStack_8 = 0;
          FUN_00557f90(uVar4);
          FUN_00d14680();
          uStack_8 = 0xffffffff;
          iStack_30 = 0xc54439;
          FUN_00550b30();
          if (DAT_01d6880c != '\0') {
            puStack_34 = (undefined *)0xc54448;
            iStack_30 = iVar1;
            iVar1 = FUN_00672e90();
            if (iVar1 != 0) {
              FUN_0060dcd0(&puStack_34,param_1);
              FUN_00c12090();
            }
          }
        }
      }
      if (iVar2 != 0) {
        puStack_34 = (undefined *)0xc54471;
        iStack_30 = iVar2;
        iVar1 = FUN_008991d0();
        if (iVar1 != 0) {
          puStack_34 = auStack_18;
          iStack_30 = param_1;
          uVar4 = FUN_0060dcd0();
          uStack_8 = 1;
          FUN_00557f90(uVar4);
          FUN_00d120f0();
          iStack_30 = 0xc544a2;
          FUN_00550b30();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28614 ; VA 0x00c544c0 ; FUN_00c544c0 */

int * __thiscall FUN_00c544c0(int *param_1,int *param_2,int *param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  undefined4 uVar6;
  int iVar7;
  int *piStack_50;
  int *piStack_4c;
  int aiStack_3c [2];
  int iStack_34;
  int *piStack_30;
  int iStack_2c;
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  undefined4 *puStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b429;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  if ((DAT_01d68814 == '\0') && (ExceptionList = &pvStack_10, param_2 != (int *)0x0)) {
    piStack_4c = (int *)0xc54506;
    ExceptionList = &pvStack_10;
    FUN_00899040();
    piStack_50 = &iStack_2c;
    piStack_4c = param_1;
    puVar2 = (undefined4 *)FUN_0060dcd0();
    uStack_8 = 0;
    piStack_50 = (int *)*puVar2;
    piStack_4c = (int *)puVar2[1];
    *puVar2 = 0;
    puVar2[1] = 0;
    FUN_00d14680();
    piVar4 = piStack_28;
    uStack_8 = 0xffffffff;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_28[1] + -1;
      piStack_28[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        piStack_4c = (int *)0xc54568;
        (**(code **)*piStack_28)();
        LOCK();
        piVar5 = piVar4 + 2;
        iVar3 = *piVar5 + -1;
        *piVar5 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          piStack_4c = (int *)0xc54578;
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (DAT_01d6880c != '\0') {
      piStack_50 = (int *)0xc54587;
      piStack_4c = param_1;
      iVar3 = FUN_00672e90();
      if (iVar3 != 0) {
        FUN_0060dcd0(&piStack_50,param_1);
        FUN_00c12090();
      }
    }
  }
  piStack_4c = param_3;
  piStack_50 = param_2;
  piVar4 = (int *)FUN_008a4210();
  if (DAT_01d68814 == '\0') {
    if (param_3 != (int *)0x0) {
      piStack_4c = (int *)0xc545d1;
      FUN_00899040();
      piStack_50 = &iStack_2c;
      piStack_4c = param_1;
      piVar4 = (int *)FUN_0060dcd0();
      uStack_8 = 1;
      piStack_50 = (int *)*piVar4;
      piStack_4c = (int *)piVar4[1];
      *piVar4 = 0;
      piVar4[1] = 0;
      piVar4 = (int *)FUN_00d120f0();
      piVar5 = piStack_28;
      uStack_8 = 0xffffffff;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_28 + 1;
        iVar3 = *piVar1;
        piVar4 = (int *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          piStack_4c = (int *)0xc54633;
          (**(code **)*piStack_28)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar3 = *piVar1;
          piVar4 = (int *)*piVar1;
          *piVar1 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            piStack_4c = (int *)0xc54643;
            piVar4 = (int *)(**(code **)(*piVar5 + 4))();
          }
        }
      }
      goto LAB_00c54649;
    }
LAB_00c54652:
    if (param_2 == (int *)0x0) goto LAB_00c54c36;
    piStack_50 = param_2;
  }
  else {
LAB_00c54649:
    if (param_3 == (int *)0x0) goto LAB_00c54652;
    piStack_50 = param_3;
  }
  piStack_4c = (int *)0x1;
  piVar4 = (int *)FUN_0098c5a0();
  if ((char)piVar4 != '\0') {
    if (param_2 != (int *)0x0) {
      piStack_4c = (int *)0xc5467c;
      FUN_01679490();
      piStack_4c = (int *)0xc54687;
      piVar4 = (int *)FUN_01679490();
      if (DAT_01d68824 != '\0') {
        piStack_4c = (int *)0xc5469b;
        FUN_01679490();
        piStack_4c = (int *)0xc546a6;
        piVar4 = (int *)FUN_01679490();
      }
    }
    if (param_3 != (int *)0x0) {
      piStack_50 = &iStack_24;
      piStack_4c = param_1;
      piVar5 = (int *)FUN_0060dcd0();
      iVar3 = *piVar5;
      piVar4 = (int *)piVar5[1];
      *piVar5 = 0;
      piVar5[1] = 0;
      uStack_8._0_1_ = 3;
      uStack_8._1_3_ = 0;
      piStack_4c = (int *)0xc546ef;
      iStack_2c = iVar3;
      piStack_28 = piVar4;
      FUN_006eccd0();
      piStack_4c = (int *)DAT_02110da8;
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      piStack_50 = (int *)0xc546fe;
      uVar6 = FUN_01675290();
      piStack_50 = (int *)0x20;
      uStack_8 = 5;
      iStack_18 = uVar6;
      puStack_1c = (undefined4 *)FUN_01674e20();
      if (puStack_1c == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puStack_1c = 0;
        puStack_1c[1] = 1;
        puStack_1c[2] = FUN_00c53800;
        puStack_1c[3] = FUN_0068b170;
        puStack_1c[4] = 0;
        puStack_1c[5] = param_1 + 0x32;
        puStack_1c[6] = 0;
        puStack_1c[7] = 0;
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar4[1] = piVar4[1] + 1;
          UNLOCK();
        }
        puStack_1c[6] = iVar3;
        puStack_1c[7] = piVar4;
        puVar2 = puStack_1c;
      }
      piStack_50 = (int *)0xc54774;
      piStack_4c = puVar2;
      FUN_016797d0();
      if (puVar2 != (undefined4 *)0x0) {
        LOCK();
        puVar2[1] = puVar2[1] + 1;
        UNLOCK();
      }
      uStack_14 = 2;
      uStack_8 = 6;
      piStack_50 = (int *)0xc5479b;
      piStack_4c = (int *)uVar6;
      puStack_1c = puVar2;
      FUN_01675290();
      piStack_4c = (int *)param_1[0x34];
      param_1[0x34] = (int)puVar2;
      uStack_14 = 1;
      if (piStack_4c != (int *)0x0) {
        piVar5 = (int *)((int)piStack_4c + 4);
        LOCK();
        iVar3 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          piStack_50 = (int *)0xc547ce;
          FUN_01674ea0();
        }
      }
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar3 = piVar4[1] + -1;
        piVar4[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          piStack_4c = (int *)0xc547e7;
          (**(code **)*piVar4)();
          LOCK();
          iVar3 = piVar4[2] + -1;
          piVar4[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            piStack_4c = (int *)0xc547f7;
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      uStack_8 = 0xffffffff;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_20[1] + -1;
        piStack_20[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          piStack_4c = (int *)0xc54814;
          (**(code **)*piStack_20)();
          LOCK();
          iVar3 = piStack_20[2] + -1;
          piStack_20[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            piStack_4c = (int *)0xc54824;
            (**(code **)(*piStack_20 + 4))();
          }
        }
      }
      piStack_50 = &iStack_34;
      piStack_4c = param_1;
      piVar4 = (int *)FUN_0060dcd0();
      iStack_2c = *piVar4;
      piVar5 = (int *)piVar4[1];
      *piVar4 = 0;
      piVar4[1] = 0;
      uStack_8._0_1_ = 8;
      uStack_8._1_3_ = 0;
      piStack_4c = (int *)0xc54865;
      piStack_28 = piVar5;
      iStack_18 = iStack_2c;
      FUN_006eccd0();
      piStack_4c = (int *)DAT_02110da8;
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
      piStack_50 = (int *)0xc54874;
      puVar2 = (undefined4 *)FUN_01675290();
      piStack_50 = (int *)0x20;
      uStack_8 = 10;
      puStack_1c = puVar2;
      param_2 = (int *)FUN_01674e20();
      if (param_2 == (int *)0x0) {
        param_2 = (int *)0x0;
      }
      else {
        *param_2 = 0;
        param_2[1] = 1;
        param_2[2] = (int)FUN_00c53920;
        param_2[3] = (int)FUN_0068b170;
        param_2[4] = 0;
        param_2[5] = (int)(param_1 + 0x35);
        param_2[6] = 0;
        param_2[7] = 0;
        if (piVar5 != (int *)0x0) {
          LOCK();
          piVar5[1] = piVar5[1] + 1;
          UNLOCK();
        }
        param_2[6] = iStack_18;
        param_2[7] = (int)piVar5;
      }
      piStack_50 = (int *)0xc548f3;
      piStack_4c = param_2;
      FUN_016797d0();
      piStack_20 = param_2;
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[1] = param_2[1] + 1;
        UNLOCK();
      }
      uStack_14 = 9;
      uStack_8 = 0xb;
      piStack_50 = (int *)0xc5491d;
      piStack_4c = puVar2;
      FUN_01675290();
      piStack_4c = (int *)param_1[0x37];
      uStack_14 = 5;
      param_1[0x37] = (int)param_2;
      piVar4 = param_2;
      if (piStack_4c != (int *)0x0) {
        piVar4 = (int *)((int)piStack_4c + 4);
        LOCK();
        iVar3 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        piVar4 = (int *)(iVar3 + -1);
        if (piVar4 == (int *)0x0) {
          piStack_50 = (int *)0xc54950;
          piVar4 = (int *)FUN_01674ea0();
        }
      }
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar1 = piVar5 + 1;
        iVar3 = *piVar1;
        piVar4 = (int *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          piStack_4c = (int *)0xc54969;
          (**(code **)*piVar5)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar3 = *piVar1;
          piVar4 = (int *)*piVar1;
          *piVar1 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            piStack_4c = (int *)0xc54979;
            piVar4 = (int *)(**(code **)(*piVar5 + 4))();
          }
        }
      }
      uStack_8 = 0xffffffff;
      if (piStack_30 != (int *)0x0) {
        LOCK();
        piVar5 = piStack_30 + 1;
        iVar3 = *piVar5;
        piVar4 = (int *)*piVar5;
        *piVar5 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          piStack_4c = (int *)0xc54996;
          (**(code **)*piStack_30)();
          LOCK();
          piVar5 = piStack_30 + 2;
          iVar3 = *piVar5;
          piVar4 = (int *)*piVar5;
          *piVar5 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            piStack_4c = (int *)0xc549a6;
            piVar4 = (int *)(**(code **)(*piStack_30 + 4))();
          }
        }
      }
      if (DAT_01d68824 != '\0') {
        piStack_50 = &iStack_34;
        piStack_4c = param_1;
        piVar4 = (int *)FUN_0060dcd0();
        iStack_2c = *piVar4;
        iVar3 = piVar4[1];
        *piVar4 = 0;
        piVar4[1] = 0;
        uStack_8._0_1_ = 0xd;
        uStack_8._1_3_ = 0;
        piStack_4c = (int *)0xc549f4;
        piStack_28 = (int *)iVar3;
        iStack_18 = iStack_2c;
        FUN_006eccd0();
        piStack_4c = (int *)DAT_02110da8;
        uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
        piStack_50 = (int *)0xc54a03;
        uVar6 = FUN_01675290();
        piStack_50 = (int *)0x20;
        uStack_8 = 0xf;
        piStack_20 = (int *)uVar6;
        param_2 = (int *)FUN_01674e20();
        if (param_2 == (undefined4 *)0x0) {
          param_2 = (undefined4 *)0x0;
        }
        else {
          *param_2 = 0;
          param_2[1] = 1;
          param_2[2] = (int)FUN_00c53770;
          param_2[3] = (int)FUN_0068b170;
          param_2[4] = 0;
          param_2[5] = (int)(param_1 + 0x38);
          param_2[6] = 0;
          param_2[7] = 0;
          if (iVar3 != 0) {
            LOCK();
            *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
            UNLOCK();
          }
          param_2[6] = iStack_18;
          param_2[7] = iVar3;
        }
        piStack_50 = (int *)0xc54a82;
        piStack_4c = param_2;
        FUN_016797d0();
        puStack_1c = param_2;
        if (param_2 != (undefined4 *)0x0) {
          LOCK();
          param_2[1] = param_2[1] + 1;
          UNLOCK();
        }
        uStack_14 = 0x25;
        uStack_8 = 0x10;
        piStack_50 = (int *)0xc54aac;
        piStack_4c = (int *)uVar6;
        FUN_01675290();
        piStack_4c = (int *)param_1[0x3a];
        uStack_14 = 0x15;
        param_1[0x3a] = (int)param_2;
        if (piStack_4c != (int *)0x0) {
          piVar4 = (int *)((int)piStack_4c + 4);
          LOCK();
          iVar3 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            piStack_50 = (int *)0xc54adf;
            FUN_01674ea0();
          }
        }
        piStack_4c = (int *)0xc54aea;
        FUN_00550b30();
        uStack_8 = 0xffffffff;
        piStack_4c = (int *)0xc54af9;
        FUN_00550b30();
        piStack_50 = aiStack_3c;
        piStack_4c = param_1;
        piVar5 = (int *)FUN_0060dcd0();
        iStack_2c = *piVar5;
        piVar4 = (int *)piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        uStack_8._0_1_ = 0x12;
        uStack_8._1_3_ = 0;
        piStack_4c = (int *)0xc54b3a;
        piStack_28 = piVar4;
        iStack_18 = iStack_2c;
        FUN_006eccd0();
        piStack_4c = (int *)DAT_02110da8;
        uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
        piStack_50 = (int *)0xc54b49;
        piVar5 = (int *)FUN_01675290();
        piStack_50 = (int *)0x20;
        uStack_8 = 0x14;
        piStack_20 = piVar5;
        param_2 = (int *)FUN_01674e20();
        if (param_2 == (undefined4 *)0x0) {
          param_2 = (undefined4 *)0x0;
        }
        else {
          *param_2 = 0;
          param_2[1] = 1;
          param_2[2] = (int)FUN_00c53890;
          param_2[3] = (int)FUN_0068b170;
          param_2[4] = 0;
          param_2[5] = (int)(param_1 + 0x3b);
          param_2[6] = 0;
          param_2[7] = 0;
          if (piVar4 != (int *)0x0) {
            LOCK();
            piVar4[1] = piVar4[1] + 1;
            UNLOCK();
          }
          param_2[6] = iStack_18;
          param_2[7] = (int)piVar4;
        }
        piStack_50 = (int *)0xc54bc8;
        piStack_4c = param_2;
        FUN_016797d0();
        puStack_1c = param_2;
        if (param_2 != (undefined4 *)0x0) {
          LOCK();
          param_2[1] = param_2[1] + 1;
          UNLOCK();
        }
        uStack_14 = 0x95;
        uStack_8 = 0x15;
        piStack_50 = (int *)0xc54bf2;
        piStack_4c = piVar5;
        FUN_01675290();
        piStack_4c = (int *)param_1[0x3d];
        param_1[0x3d] = (int)param_2;
        if (piStack_4c != (int *)0x0) {
          piVar4 = (int *)((int)piStack_4c + 4);
          LOCK();
          iVar3 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            piStack_50 = (int *)0xc54c1c;
            FUN_01674ea0();
          }
        }
        piStack_4c = (int *)0xc54c27;
        FUN_00550b30();
        uStack_8 = 0xffffffff;
        piStack_4c = (int *)0xc54c36;
        piVar4 = (int *)FUN_00550b30();
      }
    }
  }
LAB_00c54c36:
  if (param_1 != (int *)0x0) {
    piVar5 = (int *)param_1[0xd];
    if ((piVar5 != (int *)0x0) && (param_1 = piVar5, piVar5[0xd] != 0)) {
      piStack_4c = (int *)0xc54c4d;
      piVar4 = (int *)FUN_005c8ac0();
      param_1 = piVar4;
    }
    if (param_1 != (int *)0x0) {
      iVar3 = param_1[3];
      piStack_4c = (int *)0xc54c5f;
      iVar7 = FUN_008a8c30();
      piVar4 = (int *)(uint)*(ushort *)(iVar7 + 0x1da);
      if ((int *)((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8)) <= piVar4) {
        piStack_4c = (int *)0xc54c81;
        piVar4 = (int *)FUN_00672d00();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 28615 ; VA 0x00c54ca0 ; FUN_00c54ca0 */

void FUN_00c54ca0(undefined *param_1,int *param_2,undefined4 param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  
  if (((param_1 != &DAT_02136a68) &&
      ((DAT_01d68824 == '\0' ||
       (((param_1 != &DAT_02136aa8 && (param_1 != &DAT_02136ae8)) && (param_1 != &DAT_02136b28))))))
     || ((((param_2[1] - *param_2) - 0xd0U < 0xd0 &&
          (iVar1 = *(int *)*param_2, iVar3 = FUN_0088cdc0(), iVar1 == iVar3)) &&
         (cVar2 = FUN_00c60280(*param_2,param_3), cVar2 != '\0')))) {
    FUN_009cba80(param_1,param_2,param_3);
  }
  return;
}



/* FUNCTION 28616 ; VA 0x00c54d30 ; FUN_00c54d30 */

void __thiscall FUN_00c54d30(int param_1,int param_2)

{
  if (param_2 != *(int *)(param_1 + 0xa4)) {
    *(int *)(param_1 + 0xa4) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 28617 ; VA 0x00c54d60 ; FUN_00c54d60 */

void __thiscall FUN_00c54d60(int param_1,int param_2)

{
  if (param_2 != *(int *)(param_1 + 0x9c)) {
    *(int *)(param_1 + 0x9c) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 28618 ; VA 0x00c54d90 ; FUN_00c54d90 */

void __thiscall FUN_00c54d90(int param_1,int param_2)

{
  if (param_2 != *(int *)(param_1 + 0x98)) {
    *(int *)(param_1 + 0x98) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 28619 ; VA 0x00c54dc0 ; FUN_00c54dc0 */

int * __thiscall FUN_00c54dc0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  bool bVar4;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b448;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_0060dcd0(&iStack_1c,param_2);
  uStack_8 = 0;
  piVar3 = (int *)FUN_00587490(auStack_24);
  bVar4 = *piVar3 != iStack_1c;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_20 + 1;
    iVar2 = *piVar1;
    piVar3 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar2 = *piVar1;
      piVar3 = (int *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piVar3 = (int *)(**(code **)(*piStack_20 + 4))();
      }
    }
  }
  if (bVar4) {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    *(int *)(param_1 + 0xa8) = iStack_1c;
    piVar3 = *(int **)(param_1 + 0xac);
    *(int **)(param_1 + 0xac) = piStack_18;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    piVar3 = (int *)FUN_008a4940(&DAT_02136ee0);
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    piVar3 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piVar3 = (int *)(**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piVar3 = (int *)(**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar3;
}



/* FUNCTION 28620 ; VA 0x00c54ec0 ; FUN_00c54ec0 */

void __thiscall FUN_00c54ec0(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  
  piVar2 = param_3;
  if ((param_3 != (int *)0x0) &&
     (iVar1 = param_3[3], iVar3 = FUN_00fd0780(),
     (uint)*(ushort *)(iVar3 + 0x1da) <
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    piVar6 = (int *)param_1[1];
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    if (param_2 == (int *)0x0) {
      param_2 = (int *)&DAT_018e3e8c;
    }
    else {
      (**(code **)(*param_2 + 0x10))();
      param_2 = (int *)FUN_005543f0();
    }
    (**(code **)(*piVar2 + 0x10))();
    uVar4 = FUN_005543f0();
    (**(code **)(*param_1 + 0x4c))();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Expected %s got %s for %s:%s.",uVar5,uVar4,param_2,piVar6);
  }
  param_3 = piVar2;
  (**(code **)(*(int *)param_1[0xe] + 0x10))(param_2,&param_3);
  return;
}



/* FUNCTION 28621 ; VA 0x00c54f70 ; FUN_00c54f70 */

void __thiscall FUN_00c54f70(int param_1,int param_2)

{
  if (param_2 != *(int *)(param_1 + 0xa0)) {
    *(int *)(param_1 + 0xa0) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 28622 ; VA 0x00c54fa0 ; FUN_00c54fa0 */

void __thiscall FUN_00c54fa0(int param_1,int param_2,float *param_3)

{
  float fVar1;
  float fVar2;
  int iVar3;
  
  fVar1 = *param_3;
  iVar3 = *(int *)(param_1 + 8);
  if (((NAN(*(float *)(iVar3 + param_2)) || NAN(fVar1)) == (*(float *)(iVar3 + param_2) == fVar1))
     || (fVar2 = *(float *)(iVar3 + 4 + param_2),
        (NAN(fVar2) || NAN(param_3[1])) == (fVar2 == param_3[1]))) {
    *(float *)(iVar3 + param_2) = fVar1;
    *(float *)(iVar3 + 4 + param_2) = param_3[1];
    if (*(code **)(param_1 + 0x10) != (code *)0x0) {
      (**(code **)(param_1 + 0x10))(*(undefined4 *)(param_1 + 4));
    }
    FUN_008a4940(*(undefined4 *)(param_1 + 4));
  }
  return;
}



/* FUNCTION 28623 ; VA 0x00c55000 ; FUN_00c55000 */

void __thiscall FUN_00c55000(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_00896d50();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28624 ; VA 0x00c55050 ; FUN_00c55050 */

void __thiscall FUN_00c55050(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_00c550f0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28625 ; VA 0x00c550a0 ; FUN_00c550a0 */

void __thiscall FUN_00c550a0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_00c551a0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28626 ; VA 0x00c550f0 ; FUN_00c550f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c550f0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b476;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd82c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efd82c);
    if (DAT_01efd82c == -1) {
      uStack_8 = 0;
      FUN_009ca470("ProximityPromptExclusivity");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01efd7c8 =
           RBX::Reflection::EnumDesc<enum_RBX::ProximityPrompt::ProximityPromptExclusivity>::vftable
      ;
      FUN_009caf20(&DAT_01d6883c,3);
      FUN_016f3654(&LAB_01895580);
      FUN_016f37bf(&DAT_01efd82c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01efd7c8;
}



/* FUNCTION 28627 ; VA 0x00c551a0 ; FUN_00c551a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c551a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b496;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd894) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efd894);
    if (DAT_01efd894 == -1) {
      uStack_8 = 0;
      FUN_009ca470("ProximityPromptStyle");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01efd830 =
           RBX::Reflection::EnumDesc<enum_RBX::ProximityPrompt::ProximityPromptStyle>::vftable;
      FUN_009caf20(&DAT_01d6882c,2);
      FUN_016f3654(&LAB_018955a0);
      FUN_016f37bf(&DAT_01efd894);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01efd830;
}



/* FUNCTION 28628 ; VA 0x00c55250 ; FUN_00c55250 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c55250(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd8dc) {
    FUN_016f3809(&DAT_01efd8dc);
    if (DAT_01efd8dc == -1) {
      _DAT_01efd8d0 = FUN_005c65e0;
      _DAT_01efd8d4 = FUN_005c65e0;
      _DAT_01efd8d8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01efd8dc);
    }
  }
  return &DAT_01efd8d0;
}



/* FUNCTION 28629 ; VA 0x00c552c0 ; FUN_00c552c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c552c0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efd8cc) {
    FUN_016f3809(&DAT_01efd8cc);
    if (DAT_01efd8cc == -1) {
      _DAT_01efd8c0 = FUN_005c65e0;
      _DAT_01efd8c4 = FUN_005c65e0;
      _DAT_01efd8c8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01efd8cc);
    }
  }
  return &DAT_01efd8c0;
}



/* FUNCTION 28630 ; VA 0x00c55330 ; FUN_00c55330 */

int __fastcall FUN_00c55330(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 *puStack_38;
  int *piStack_34;
  undefined4 *puStack_24;
  int *piStack_20;
  undefined *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b4b0;
  pvStack_10 = ExceptionList;
  puStack_38 = (undefined4 *)0xc55356;
  ExceptionList = &pvStack_10;
  piStack_34 = (int *)param_1;
  iVar3 = FUN_0097bfc0();
  if (iVar3 != 0) {
    puStack_38 = &puStack_24;
    uStack_3c = 0xc5536b;
    piStack_34 = (int *)iVar3;
    FUN_0060dcd0();
    iStack_8 = 0;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piStack_20[1] = piStack_20[1] + 1;
      UNLOCK();
    }
    puStack_38 = puStack_24;
    piStack_34 = piStack_20;
    uStack_40 = 0xc5539f;
    uStack_3c = param_1;
    FUN_00925d30();
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piStack_20[1] = piStack_20[1] + 1;
      UNLOCK();
    }
    puStack_38 = puStack_24;
    piStack_34 = piStack_20;
    uStack_40 = 0xc553c9;
    uStack_3c = param_1;
    FUN_009253f0();
    puStack_38 = (undefined4 *)0xc553cf;
    piStack_34 = (int *)param_1;
    iVar3 = FUN_00672e90();
    iStack_14 = iVar3;
    if (iVar3 != 0) {
      if (piStack_20 != (int *)0x0) {
        LOCK();
        piStack_20[1] = piStack_20[1] + 1;
        UNLOCK();
      }
      puStack_38 = puStack_24;
      piStack_34 = piStack_20;
      iStack_8._0_1_ = 1;
      puStack_18 = (undefined *)&puStack_38;
      FUN_0060dcd0(&uStack_40,param_1);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      iVar3 = FUN_00c10c00();
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_20 + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piStack_34 = (int *)0xc55430;
        iVar3 = (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piStack_20 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          piStack_34 = (int *)0xc5543f;
          iVar3 = (**(code **)(*piStack_20 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 28631 ; VA 0x00c55450 ; FUN_00c55450 */

int __fastcall FUN_00c55450(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d00a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0097bfc0(param_1);
  if (iVar3 != 0) {
    FUN_0060dcd0(&uStack_1c,iVar3);
    uStack_8 = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
    }
    FUN_009253f0(param_1,uStack_1c,piStack_18);
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
    }
    iVar3 = FUN_00c55520(uStack_1c,piStack_18);
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_18 + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piStack_18 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar3 = (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 28632 ; VA 0x00c55520 ; FUN_00c55520 */

uint __thiscall FUN_00c55520(uint param_1,undefined4 param_2,int *param_3)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_0180b290;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_2c = param_2;
  piStack_28 = param_3;
  uStack_34 = 0xc5557a;
  uStack_30 = param_1;
  uVar5 = FUN_00925d30();
  if (param_1 != 0) {
    uVar3 = *(uint *)(param_1 + 0x34);
    uVar7 = param_1;
    if ((uVar3 != 0) && (uVar7 = uVar3, *(int *)(uVar3 + 0x34) != 0)) {
      piStack_28 = (int *)0xc55595;
      uVar5 = FUN_005c8ac0();
      uVar7 = uVar5;
    }
    if (uVar7 != 0) {
      iVar4 = *(int *)(uVar7 + 0xc);
      piStack_28 = (int *)0xc555a7;
      iVar6 = FUN_008a8c30();
      uVar5 = (uint)*(ushort *)(iVar6 + 0x1da);
      if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <= uVar5) {
        piStack_28 = (int *)0xc555c9;
        uVar5 = FUN_00672d00();
        if (uVar5 != 0) {
          if (param_3 != (int *)0x0) {
            LOCK();
            param_3[1] = param_3[1] + 1;
            UNLOCK();
          }
          uStack_2c = param_2;
          piStack_28 = param_3;
          iStack_8._0_1_ = 1;
          FUN_0060dcd0(&uStack_34,param_1);
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          uVar5 = FUN_00c10b20();
        }
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_3 + 1);
    uVar3 = *puVar1;
    uVar5 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      piStack_28 = (int *)0xc55631;
      uVar5 = (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        piStack_28 = (int *)0xc55640;
        uVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 28633 ; VA 0x00c55660 ; FUN_00c55660 */

uint __thiscall FUN_00c55660(uint param_1,undefined *param_2,int *param_3)

{
  int *piVar1;
  uint *puVar2;
  uint uVar3;
  int *piVar4;
  int *piVar5;
  undefined *puVar6;
  int iVar7;
  undefined4 *puVar8;
  int iVar9;
  uint uVar10;
  float fVar11;
  double dVar12;
  float fVar13;
  float fVar14;
  undefined4 uStack_80;
  uint uStack_7c;
  undefined *puStack_78;
  int *piStack_74;
  undefined auStack_64 [48];
  undefined *puStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined *puStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180b4d8;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)0x0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  if (param_2 == (undefined *)0x0) {
LAB_00c556da:
    piStack_20 = (int *)0x0;
    puVar8 = &uStack_24;
    puStack_1c = (undefined *)0x0;
    uVar10 = 6;
  }
  else {
    iVar9 = *(int *)(param_2 + 0xc);
    piStack_74 = (int *)0xc5569e;
    ExceptionList = &pvStack_10;
    iVar7 = FUN_00913630();
    if ((uint)*(ushort *)(iVar7 + 0x1da) <
        (uint)*(ushort *)(iVar9 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8)) goto LAB_00c556da;
    puStack_1c = param_2;
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    piStack_28 = param_3;
    uVar10 = 5;
    puVar8 = &uStack_2c;
  }
  puStack_34 = puStack_1c;
  piVar4 = (int *)puVar8[1];
  *puVar8 = 0;
  puVar8[1] = 0;
  piVar5 = piStack_20;
  piStack_30 = piVar4;
  if (((uVar10 & 2) != 0) &&
     (uStack_18 = uVar10 & 0xfffffffd, uVar10 = uStack_18, piStack_20 != (int *)0x0)) {
    LOCK();
    iVar9 = piStack_20[1] + -1;
    piStack_20[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      piStack_74 = (int *)0xc55728;
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar9 = *piVar1 + -1;
      *piVar1 = iVar9;
      UNLOCK();
      uVar10 = uStack_18;
      if (iVar9 == 0) {
        piStack_74 = (int *)0xc55738;
        (**(code **)(*piVar5 + 4))();
        uVar10 = uStack_18;
      }
    }
  }
  piVar5 = piStack_28;
  if (((uVar10 & 1) != 0) && (piStack_28 != (int *)0x0)) {
    LOCK();
    iVar9 = piStack_28[1] + -1;
    piStack_28[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      piStack_74 = (int *)0xc55756;
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar9 = *piVar1 + -1;
      *piVar1 = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        piStack_74 = (int *)0xc55766;
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  puVar6 = puStack_1c;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if ((puStack_1c != (undefined *)0x0) && (*(int **)(puStack_1c + 100) != (int *)0x0)) {
    piStack_74 = (int *)0xc55788;
    iVar9 = (**(code **)(**(int **)(puStack_1c + 100) + 0xa8))();
    if (iVar9 != 0) {
      piStack_74 = (int *)0xc55797;
      (**(code **)(**(int **)(puVar6 + 100) + 0xa8))();
      piStack_74 = (int *)0xc5579e;
      iVar9 = FUN_00b077e0();
      piStack_74 = (int *)auStack_64;
      puStack_78 = (undefined *)0xc557ac;
      iVar7 = FUN_00c53ca0();
      fVar14 = *(float *)(iVar7 + 0x28) - *(float *)(iVar9 + 0x28);
      fVar13 = *(float *)(iVar7 + 0x24) - *(float *)(iVar9 + 0x24);
      fVar11 = *(float *)(iVar7 + 0x2c) - *(float *)(iVar9 + 0x2c);
      dVar12 = (double)(fVar14 * fVar14 + fVar13 * fVar13 + fVar11 * fVar11);
      piStack_74 = (int *)0xc557e6;
      FUN_017267a0();
      if (*(float *)(uStack_14 + 0x54) + *(float *)(uStack_14 + 0x54) < (float)dVar12) {
        piStack_74 = (int *)0xc55806;
        uVar10 = FUN_00550b30();
        goto LAB_00c5590c;
      }
    }
  }
  uVar3 = uStack_14;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  puStack_78 = param_2;
  piStack_74 = param_3;
  uStack_7c = uStack_14;
  uStack_80 = 0xc55841;
  uVar10 = FUN_00925d30();
  if (uVar3 != 0) {
    uStack_18 = *(uint *)(uVar3 + 0x34);
    if (uStack_18 == 0) {
      uStack_18 = uVar3;
    }
    else if (*(int *)(uStack_18 + 0x34) != 0) {
      piStack_74 = (int *)0xc5585f;
      uStack_18 = FUN_005c8ac0();
    }
    uVar10 = uStack_18;
    if (uStack_18 != 0) {
      iVar9 = *(int *)(uStack_18 + 0xc);
      piStack_74 = (int *)0xc55875;
      iVar7 = FUN_008a8c30();
      uVar10 = (uint)*(ushort *)(iVar7 + 0x1da);
      if ((uint)*(ushort *)(iVar9 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <= uVar10) {
        piStack_74 = (int *)0xc55898;
        uVar10 = FUN_00672d00();
        if (uVar10 != 0) {
          puStack_1c = (undefined *)&puStack_78;
          if (param_3 != (int *)0x0) {
            LOCK();
            param_3[1] = param_3[1] + 1;
            UNLOCK();
          }
          puStack_78 = param_2;
          piStack_74 = param_3;
          uStack_8._0_1_ = 2;
          FUN_0060dcd0(&uStack_80,uStack_14);
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          uVar10 = FUN_00c10c00();
        }
      }
    }
  }
  if (piVar4 != (int *)0x0) {
    LOCK();
    puVar2 = (uint *)(piVar4 + 1);
    uVar3 = *puVar2;
    uVar10 = *puVar2;
    *puVar2 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      piStack_74 = (int *)0xc558fc;
      (**(code **)*piVar4)();
      LOCK();
      puVar2 = (uint *)(piVar4 + 2);
      uVar3 = *puVar2;
      uVar10 = *puVar2;
      *puVar2 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        piStack_74 = (int *)0xc5590c;
        uVar10 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
LAB_00c5590c:
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar2 = (uint *)(param_3 + 1);
    uVar3 = *puVar2;
    uVar10 = *puVar2;
    *puVar2 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      piStack_74 = (int *)0xc55922;
      uVar10 = (**(code **)*param_3)();
      LOCK();
      piVar4 = param_3 + 2;
      iVar9 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        piStack_74 = (int *)0xc55931;
        uVar10 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar10;
}



/* FUNCTION 28634 ; VA 0x00c55950 ; FUN_00c55950 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c55950(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b510;
  pvStack_10 = ExceptionList;
  if (DAT_01efd8e8 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efdb00) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efdb00);
      if (DAT_01efdb00 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ClickDetector",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01efdaf8 = RBX::Creator<class_RBX::ClickDetector>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efd8f0,&DAT_01efdaf8);
        FUN_016f3654(FUN_018957b0);
        FUN_016f37bf(&DAT_01efdb00);
      }
    }
    DAT_01efd8e8 = &DAT_01efd8f0;
  }
  ExceptionList = pvStack_10;
  return DAT_01efd8e8;
}



/* FUNCTION 28635 ; VA 0x00c55a50 ; FUN_00c55a50 */

int __thiscall FUN_00c55a50(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180b520;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ClickDetector*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28636 ; VA 0x00c55b22 ; Catch_All@00c55b22 */

void Catch_All_00c55b22(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28637 ; VA 0x00c55b40 ; FUN_00c55b40 */

undefined4 * FUN_00c55b40(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180b563;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c55950();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xb4);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c55d30();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c55a50(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28638 ; VA 0x00c55c00 ; FUN_00c55c00 */

undefined4 * __thiscall
FUN_00c55c00(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  undefined auStack_f8 [216];
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b591;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  uVar1 = FUN_00c55950();
  FUN_009cb970(uVar1,param_3,param_5,param_6,param_7);
  param_1[0xd] = param_2;
  iStack_8 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::ClickDetector,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::ClickDetector::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_f8,&puStack_20,param_5);
  iStack_8._0_1_ = 2;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = uStack_1c;
    param_1[0xb] = uStack_18;
    param_1[0xc] = uStack_14;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
  }
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_f8,0xd8,1,FUN_00688b10);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28639 ; VA 0x00c55d30 ; FUN_00c55d30 */

undefined4 * __fastcall FUN_00c55d30(undefined4 *param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b638;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::ClickDetector,class_RBX::Instance>::vftable;
  uVar5 = FUN_00c55950();
  param_1[3] = uVar5;
  param_1[0x15] = RBX::IAdornable::vftable;
  param_1[0x16] = 0xffffffff;
  param_1[0x17] = 0xffffffff;
  param_1[0x18] = 0xffffffff;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  puVar1 = param_1 + 0x1e;
  *param_1 = RBX::ClickDetector::vftable;
  param_1[0x15] = RBX::ClickDetector::vftable;
  param_1[0x1c] = 0x42000000;
  *(undefined2 *)(param_1 + 0x1d) = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0xf;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  *(undefined *)puVar1 = 0;
  puStack_18 = puVar1;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 3;
  FUN_009cbbb0(puVar1);
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  uStack_8._0_1_ = 0xb;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("ClickDetector",0xd);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  FUN_008a6520(auStack_30);
  if (0xf < uStack_1c) {
    uVar7 = uStack_1c + 1;
    uVar6 = auStack_30[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_30[0] - 4);
      uVar7 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  param_1[0x24] = 0;
  piVar3 = (int *)param_1[0x25];
  param_1[0x25] = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar2 = piVar3 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28640 ; VA 0x00c55f10 ; FUN_00c55f10 */

void __fastcall FUN_00c55f10(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::ClickDetector>::vftable;
  uVar1 = FUN_00c55950(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28641 ; VA 0x00c55f50 ; FUN_00c55f50 */

undefined4 * __thiscall FUN_00c55f50(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  
  *param_1 = RBX::ClickDetector::vftable;
  param_1[0x15] = RBX::ClickDetector::vftable;
  iVar3 = param_1[0x2c];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  piVar1 = (int *)param_1[0x25];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uVar4 = param_1[0x23];
  if (0xf < uVar4) {
    iVar3 = param_1[0x1e];
    uVar6 = uVar4 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar4 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x22] = 0;
  param_1[0x23] = 0xf;
  *(undefined *)(param_1 + 0x1e) = 0;
  FUN_0115a710();
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xb4);
  }
  return param_1;
}



/* FUNCTION 28642 ; VA 0x00c56080 ; FUN_00c56080 */

uint FUN_00c56080(int param_1)

{
  int iVar1;
  uint in_EAX;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00aff8c0();
    in_EAX = (uint)*(ushort *)(iVar2 + 0x1da);
    if (in_EAX < (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) {
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_00b63e30();
      in_EAX = (uint)*(ushort *)(iVar2 + 0x1da);
      if (in_EAX < (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))
      goto LAB_00c560da;
    }
    return CONCAT31((int3)(in_EAX >> 8),1);
  }
LAB_00c560da:
  return in_EAX & 0xffffff00;
}



/* FUNCTION 28643 ; VA 0x00c560f0 ; FUN_00c560f0 */

undefined4 * __thiscall
FUN_00c560f0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180b721;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00c56310;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28644 ; VA 0x00c562a0 ; FUN_00c562a0 */

undefined4 * FUN_00c562a0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c55b40(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 28645 ; VA 0x00c56310 ; FUN_00c56310 */

int FUN_00c56310(int param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  int *piStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3c7c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 1;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_1c0 = FUN_0088cdc0();
  uStack_1bc = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_1b8 = param_2;
  piStack_1b4 = param_3;
  uStack_1bc = FUN_006309e0();
  uStack_8._0_1_ = 2;
  uStack_f0 = FUN_0088c8c0();
  uStack_ec = 0;
  uStack_e8 = param_4;
  uStack_ec = FUN_005c9cc0();
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,pcVar3);
  uStack_8._0_1_ = 4;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  iVar5 = FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 28646 ; VA 0x00c56490 ; FUN_00c56490 */

int FUN_00c56490(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00c57090(param_2,param_3,param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 28647 ; VA 0x00c56520 ; FUN_00c56520 */

/* WARNING: Removing unreachable block (ram,0x00c566a9) */
/* WARNING: Removing unreachable block (ram,0x00c566b5) */
/* WARNING: Removing unreachable block (ram,0x00c566c3) */

undefined4 FUN_00c56520(int *param_1,undefined4 param_2,int param_3,undefined4 param_4)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  int iStack_1d4;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017f0454;
  pvStack_10 = ExceptionList;
  uStack_40 = 0;
  uStack_3c = 0;
  uStack_14 = param_2;
  uStack_2c = param_2;
  iStack_20 = param_3;
  iStack_28 = param_3;
  uStack_8 = 1;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
    UNLOCK();
  }
  FUN_00b25690(param_1,param_2,param_3,param_4);
  uStack_1c = uStack_14;
  iStack_18 = param_3;
  uStack_2c = 0;
  iStack_28 = 0;
  uStack_8 = 2;
  pcVar1 = *(code **)(*param_1 + 8);
  uStack_1e0 = FUN_0088cdc0();
  uStack_1d8 = uStack_14;
  uStack_1dc = 0;
  iStack_1d4 = iStack_20;
  uStack_1c = 0;
  iStack_18 = 0;
  uStack_1dc = FUN_006309e0();
  uStack_8 = 3;
  uStack_110 = FUN_0088c8c0();
  uStack_10c = 0;
  uStack_108 = param_4;
  uStack_10c = FUN_005c9cc0();
  uStack_8 = 4;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  FUN_00687980(&uStack_1e0,&uStack_40,param_4);
  uStack_8 = 5;
  (*pcVar1)(uStack_24,&uStack_38,&uStack_40);
  uStack_8 = 6;
  FUN_00577b20();
  _uStack_8 = CONCAT31(uStack_7,2);
  uVar2 = FUN_016f32d1(&uStack_1e0,0xd0,2,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 28648 ; VA 0x00c566e0 ; FUN_00c566e0 */

void FUN_00c566e0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  undefined4 uVar7;
  
  iVar2 = *param_2;
  iVar5 = *(int *)(iVar2 + 0xd0);
  iVar3 = FUN_0088c8c0();
  if (iVar5 == iVar3) {
    puVar4 = (undefined4 *)(iVar2 + 0xd8);
    param_2 = (int *)*param_2;
    if (*(int *)(iVar2 + 0xd4) == 0) {
      puVar4 = (undefined4 *)0x0;
    }
    iVar2 = *param_2;
    uVar7 = *puVar4;
    iVar5 = FUN_0088cdc0(uVar7);
    if (iVar2 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
      if (piVar6[1] != 0) {
        LOCK();
        piVar1 = (int *)(piVar6[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_00b25690(param_1,*piVar6,piVar6[1],uVar7);
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28649 ; VA 0x00c56770 ; FUN_00c56770 */

void * __thiscall FUN_00c56770(int param_1,float param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  void *pvVar6;
  undefined4 uVar7;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b740;
  pvStack_10 = ExceptionList;
  pvVar6 = ExceptionList;
  if (param_2 < *(float *)(param_1 + 0x70)) {
    ExceptionList = &pvStack_10;
    puVar5 = (undefined4 *)FUN_0060dcd0(auStack_18,param_3);
    uStack_8 = 0;
    uVar2 = *puVar5;
    uVar3 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    FUN_00925d30(param_1,uVar2,uVar3);
    uStack_8 = 0xffffffff;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_14[1] + -1;
      piStack_14[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        iVar4 = piStack_14[2] + -1;
        piStack_14[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    uVar7 = 0;
    puVar5 = (undefined4 *)FUN_0060dcd0(auStack_20,param_3,0);
    uStack_8 = 1;
    uVar2 = *puVar5;
    uVar3 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    pvVar6 = (void *)FUN_00c56520(param_1,uVar2,uVar3,uVar7);
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_1c + 1;
      iVar4 = *piVar1;
      pvVar6 = (void *)*piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        pvVar6 = (void *)(**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piStack_1c + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          pvVar6 = (void *)(**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar6;
}



/* FUNCTION 28650 ; VA 0x00c568a0 ; FUN_00c568a0 */

int __thiscall FUN_00c568a0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uVar8;
  undefined auStack_1c [4];
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b760;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined2 *)(param_1 + 0x74) = 0;
  puVar6 = (undefined4 *)FUN_0060dcd0(auStack_1c,param_2);
  uStack_8 = 0;
  uVar3 = *puVar6;
  uVar4 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  FUN_00925d30(param_1,uVar3,uVar4);
  piVar5 = piStack_18;
  uStack_8 = 0xffffffff;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_18[1] + -1;
    piStack_18[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  uVar8 = 2;
  puVar6 = (undefined4 *)FUN_0060dcd0(auStack_1c,param_2,2);
  uStack_8 = 1;
  uVar3 = *puVar6;
  uVar4 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  iVar7 = FUN_00c56520(param_1,uVar3,uVar4,uVar8);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar5 = piStack_18 + 1;
    iVar2 = *piVar5;
    iVar7 = *piVar5;
    *piVar5 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar5 = piStack_18 + 2;
      iVar2 = *piVar5;
      iVar7 = *piVar5;
      *piVar5 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar7 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  *(undefined4 *)(param_1 + 0x90) = 0;
  piVar5 = *(int **)(param_1 + 0x94);
  *(undefined4 *)(param_1 + 0x94) = 0;
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar1 = piVar5 + 1;
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar7 = (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar7 = (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 28651 ; VA 0x00c56a00 ; FUN_00c56a00 */

void FUN_00c56a00(void)

{
  int iVar1;
  
  if (DAT_01efdb04 == 0) {
    iVar1 = FUN_00c55950();
    DAT_01efdb04 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28652 ; VA 0x00c56a20 ; FUN_00c56a20 */

undefined4 __thiscall FUN_00c56a20(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x78);
  return param_2;
}



/* FUNCTION 28653 ; VA 0x00c56a40 ; FUN_00c56a40 */

undefined FUN_00c56a40(int param_1,int *param_2,float param_3,char param_4,undefined4 param_5,
                      int *param_6)

{
  int iVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  undefined uVar7;
  uint uVar8;
  uint uVar9;
  undefined auStack_50 [4];
  int *piStack_4c;
  int iStack_48;
  int *piStack_44;
  int iStack_40;
  int *piStack_3c;
  int iStack_38;
  int *piStack_34;
  int iStack_30;
  int *piStack_2c;
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  uint uStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180b788;
  pvStack_10 = ExceptionList;
  uVar8 = 0;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  piStack_20 = param_2;
  iStack_18 = param_1;
  iStack_38 = param_1;
  piStack_34 = param_2;
  uStack_8 = 1;
  do {
    if (iStack_18 == 0) {
LAB_00c56b70:
      cStack_11 = '\0';
    }
    else {
      iVar1 = *(int *)(iStack_18 + 0xc);
      iVar3 = FUN_008aa870();
      if ((uint)*(ushort *)(iVar3 + 0x1da) <
          (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
        piStack_44 = (int *)0x0;
        piVar4 = &iStack_48;
        uVar8 = uVar8 | 4;
        iStack_24 = 0;
      }
      else {
        if (piStack_20 != (int *)0x0) {
          LOCK();
          piStack_20[1] = piStack_20[1] + 1;
          UNLOCK();
        }
        uVar8 = uVar8 | 2;
        piStack_2c = piStack_20;
        piVar4 = &iStack_30;
        iStack_30 = iStack_18;
        iStack_24 = iStack_18;
      }
      piStack_28 = (int *)piVar4[1];
      uVar9 = uVar8 | 8;
      *piVar4 = 0;
      piVar4[1] = 0;
      piVar4 = piStack_44;
      if (((uVar8 & 4) != 0) && (uVar9 = uVar8 & 0xfffffffb | 8, piStack_44 != (int *)0x0)) {
        LOCK();
        iVar1 = piStack_44[1] + -1;
        piStack_44[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_44)();
          LOCK();
          piVar6 = piVar4 + 2;
          iVar1 = *piVar6 + -1;
          *piVar6 = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      piVar4 = piStack_2c;
      if (((uVar9 & 2) != 0) && (uVar9 = uVar9 & 0xfffffffd, piStack_2c != (int *)0x0)) {
        LOCK();
        iVar1 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_2c)();
          LOCK();
          piVar6 = piVar4 + 2;
          iVar1 = *piVar6 + -1;
          *piVar6 = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      uVar8 = uVar9 | 1;
      cStack_11 = '\x01';
      uStack_1c = uVar8;
      if (iStack_24 != 0) goto LAB_00c56b70;
    }
    piVar4 = piStack_28;
    if (((uVar8 & 1) != 0) && (uStack_1c = uVar8 & 0xfffffffe, piStack_28 != (int *)0x0)) {
      LOCK();
      iVar1 = piStack_28[1] + -1;
      piStack_28[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        piVar6 = piVar4 + 2;
        iVar1 = *piVar6 + -1;
        *piVar6 = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (cStack_11 == '\0') {
      uVar7 = 0;
      goto LAB_00c56d40;
    }
    puVar2 = *(undefined4 **)(iStack_18 + 0x2c);
    if (puVar2 != (undefined4 *)0x0) {
      piVar4 = (int *)puVar2[1];
      for (piVar6 = (int *)*puVar2; piVar6 != piVar4; piVar6 = piVar6 + 2) {
        iStack_24 = *piVar6;
        if ((iStack_24 != 0) &&
           (iVar1 = *(int *)(iStack_24 + 0xc), iVar5 = FUN_00c55950(), iVar3 = iStack_24,
           (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
           (uint)*(ushort *)(iVar5 + 0x1da))) goto LAB_00c56bfb;
      }
    }
    iVar3 = 0;
LAB_00c56bfb:
    FUN_0060dcd0(&iStack_40,iVar3);
    piVar4 = piStack_3c;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if ((iStack_40 != 0) && (param_3 < *(float *)(iStack_40 + 0x70))) {
      if (param_4 != '\0') {
        FUN_00c56770(param_3,param_5);
      }
      *param_6 = iStack_40;
      if (piStack_3c != (int *)0x0) {
        LOCK();
        iVar1 = piStack_3c[1] + -1;
        piStack_3c[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_3c)();
          LOCK();
          iVar1 = piStack_3c[2] + -1;
          piStack_3c[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piStack_3c + 4))();
          }
        }
      }
      uVar7 = 1;
LAB_00c56d40:
      piVar4 = piStack_20;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_20[1] + -1;
        piStack_20[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar6 = piVar4 + 2;
          iVar1 = *piVar6 + -1;
          *piVar6 = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      if (param_2 != (int *)0x0) {
        LOCK();
        iVar1 = param_2[1] + -1;
        param_2[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*param_2)();
          LOCK();
          piVar4 = param_2 + 2;
          iVar1 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*param_2 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return uVar7;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (piStack_3c != (int *)0x0) {
      LOCK();
      iVar1 = piStack_3c[1] + -1;
      piStack_3c[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_3c)();
        LOCK();
        piVar6 = piVar4 + 2;
        iVar1 = *piVar6 + -1;
        *piVar6 = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    piVar6 = (int *)FUN_0060dcd0(auStack_50,*(undefined4 *)(iStack_18 + 0x34));
    piVar4 = piStack_20;
    iStack_38 = *piVar6;
    piStack_34 = (int *)piVar6[1];
    *piVar6 = 0;
    piVar6[1] = 0;
    piVar6 = piStack_34;
    iStack_18 = iStack_38;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_20[1] + -1;
      piStack_20[1] = iVar1;
      UNLOCK();
      piVar6 = piStack_34;
      if (iVar1 == 0) {
        puVar2 = (undefined4 *)*piStack_20;
        piStack_20 = piStack_34;
        (*(code *)*puVar2)();
        LOCK();
        piVar6 = piVar4 + 2;
        iVar1 = *piVar6 + -1;
        *piVar6 = iVar1;
        UNLOCK();
        piVar6 = piStack_20;
        if (iVar1 == 0) {
          (**(code **)(*piVar4 + 4))();
          piVar6 = piStack_20;
        }
      }
    }
    piStack_20 = piVar6;
    uVar8 = uStack_1c;
    piVar4 = piStack_4c;
    if (piStack_4c != (int *)0x0) {
      LOCK();
      iVar1 = piStack_4c[1] + -1;
      piStack_4c[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_4c)();
        LOCK();
        piVar6 = piVar4 + 2;
        iVar1 = *piVar6 + -1;
        *piVar6 = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
  } while( true );
}



/* FUNCTION 28654 ; VA 0x00c56da0 ; FUN_00c56da0 */

int FUN_00c56da0(int param_1,float param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  int *piVar7;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b7b0;
  pvStack_10 = ExceptionList;
  if (param_1 != 0) {
    ExceptionList = &pvStack_10;
    piVar2 = (int *)FUN_0060dcd0(auStack_30,param_1);
    param_1 = *piVar2;
    piStack_1c = (int *)piVar2[1];
    *piVar2 = 0;
    piVar2[1] = 0;
    iStack_8 = 0;
    iVar3 = param_1;
    iStack_20 = param_1;
    piStack_14 = piStack_1c;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar5 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        iVar5 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_2c + 4))();
        }
      }
    }
    do {
      puVar1 = *(undefined4 **)(iVar3 + 0x2c);
      if (puVar1 != (undefined4 *)0x0) {
        piVar2 = (int *)puVar1[1];
        for (piVar7 = (int *)*puVar1; piVar7 != piVar2; piVar7 = piVar7 + 2) {
          iStack_18 = *piVar7;
          if ((iStack_18 != 0) &&
             (iVar3 = *(int *)(iStack_18 + 0xc), iVar4 = FUN_00c55950(), iVar5 = iStack_18,
             (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
             (uint)*(ushort *)(iVar4 + 0x1da))) goto LAB_00c56e6f;
        }
      }
      iVar5 = 0;
LAB_00c56e6f:
      FUN_0060dcd0(&iStack_28,iVar5);
      piVar2 = piStack_24;
      iStack_8 = CONCAT31(iStack_8._1_3_,1);
      if ((iStack_28 != 0) && (param_2 < *(float *)(iStack_28 + 0x70))) {
        if (piStack_14 != (int *)0x0) {
          LOCK();
          piStack_14[1] = piStack_14[1] + 1;
          UNLOCK();
        }
        FUN_00c57930(param_1,piStack_14,param_4);
        if (piStack_24 != (int *)0x0) {
          LOCK();
          iVar3 = piStack_24[1] + -1;
          piStack_24[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piStack_24)();
            LOCK();
            iVar3 = piStack_24[2] + -1;
            piStack_24[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piStack_24 + 4))();
            }
          }
        }
        piVar2 = piStack_14;
        if (piStack_14 != (int *)0x0) {
          LOCK();
          iVar3 = piStack_14[1] + -1;
          piStack_14[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piStack_14)();
            LOCK();
            piVar7 = piVar2 + 2;
            iVar3 = *piVar7;
            *piVar7 = *piVar7 + -1;
            UNLOCK();
            if (iVar3 == 1) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        ExceptionList = pvStack_10;
        return iStack_28;
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_24[1] + -1;
        piStack_24[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          piVar7 = piVar2 + 2;
          iVar3 = *piVar7 + -1;
          *piVar7 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      piVar6 = (int *)FUN_0060dcd0(auStack_38,*(undefined4 *)(param_1 + 0x34));
      piVar7 = piStack_14;
      param_1 = *piVar6;
      piVar2 = (int *)piVar6[1];
      *piVar6 = 0;
      piVar6[1] = 0;
      iStack_20 = param_1;
      piStack_1c = piVar2;
      iStack_18 = param_1;
      piVar6 = piVar2;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_14[1] + -1;
        piStack_14[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          puVar1 = (undefined4 *)*piStack_14;
          piStack_14 = piVar2;
          (*(code *)*puVar1)();
          LOCK();
          piVar6 = piVar7 + 2;
          iVar3 = *piVar6 + -1;
          *piVar6 = iVar3;
          UNLOCK();
          piVar6 = piStack_14;
          if (iVar3 == 0) {
            (**(code **)(*piVar7 + 4))();
            piVar6 = piStack_14;
          }
        }
      }
      piStack_14 = piVar6;
      piVar7 = piStack_34;
      if (piStack_34 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_34[1] + -1;
        piStack_34[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_34)();
          LOCK();
          piVar6 = piVar7 + 2;
          iVar3 = *piVar6 + -1;
          *piVar6 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
    } while ((param_1 != 0) &&
            (iVar5 = *(int *)(param_1 + 0xc), iVar4 = FUN_008aa870(), iVar3 = iStack_18,
            (uint)*(ushort *)(iVar4 + 0x1da) <
            (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)));
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar7 = piVar2 + 2;
        iVar3 = *piVar7;
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 28655 ; VA 0x00c57050 ; FUN_00c57050 */

uint FUN_00c57050(void)

{
  int iVar1;
  
  iVar1 = FUN_00c55950();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 28656 ; VA 0x00c57070 ; FUN_00c57070 */

uint FUN_00c57070(void)

{
  int iVar1;
  
  iVar1 = FUN_00c55950();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 28657 ; VA 0x00c57090 ; FUN_00c57090 */

int __thiscall FUN_00c57090(undefined4 param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 in_stack_ffffffe0;
  int *in_stack_ffffffe4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_4 == 0) {
    ExceptionList = &pvStack_10;
    in_stack_ffffffe0 = param_2;
    in_stack_ffffffe4 = param_3;
    if (param_3 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
  }
  else if (param_4 == 1) {
    ExceptionList = &pvStack_10;
    in_stack_ffffffe0 = param_2;
    in_stack_ffffffe4 = param_3;
    if (param_3 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
  }
  else if (param_4 == 2) {
    ExceptionList = &pvStack_10;
    in_stack_ffffffe0 = param_2;
    in_stack_ffffffe4 = param_3;
    if (param_3 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
  }
  else {
    iVar4 = param_4;
    ExceptionList = &pvStack_10;
    if (param_4 != 3) goto LAB_00c5716a;
    ExceptionList = &pvStack_10;
    FUN_00557fc0(&param_2);
  }
  iVar4 = FUN_00925d30(param_1,in_stack_ffffffe0,in_stack_ffffffe4);
LAB_00c5716a:
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 28658 ; VA 0x00c571b0 ; FUN_00c571b0 */

undefined FUN_00c571b0(int param_1,int *param_2,float param_3,undefined4 param_4,undefined4 param_5)

{
  int iVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  undefined auStack_50 [4];
  int *piStack_4c;
  int iStack_48;
  int *piStack_44;
  int iStack_40;
  int *piStack_3c;
  int iStack_38;
  int *piStack_34;
  int iStack_30;
  int *piStack_2c;
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  uint uStack_1c;
  int iStack_18;
  char cStack_12;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180b7d8;
  pvStack_10 = ExceptionList;
  uVar7 = 0;
  uStack_1c = 0;
  uStack_11 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  piStack_20 = param_2;
  iStack_18 = param_1;
  iStack_38 = param_1;
  piStack_34 = param_2;
  uStack_8 = 1;
  do {
    if (iStack_18 == 0) {
LAB_00c572e4:
      cStack_12 = '\0';
    }
    else {
      iVar1 = *(int *)(iStack_18 + 0xc);
      iVar3 = FUN_008aa870();
      if ((uint)*(ushort *)(iVar3 + 0x1da) <
          (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
        piStack_3c = (int *)0x0;
        piVar4 = &iStack_40;
        uVar7 = uVar7 | 4;
        iStack_24 = 0;
      }
      else {
        if (piStack_20 != (int *)0x0) {
          LOCK();
          piStack_20[1] = piStack_20[1] + 1;
          UNLOCK();
        }
        uVar7 = uVar7 | 2;
        piStack_2c = piStack_20;
        piVar4 = &iStack_30;
        iStack_30 = iStack_18;
        iStack_24 = iStack_18;
      }
      piStack_28 = (int *)piVar4[1];
      uVar8 = uVar7 | 8;
      *piVar4 = 0;
      piVar4[1] = 0;
      piVar4 = piStack_3c;
      if (((uVar7 & 4) != 0) && (uVar8 = uVar7 & 0xfffffffb | 8, piStack_3c != (int *)0x0)) {
        LOCK();
        iVar1 = piStack_3c[1] + -1;
        piStack_3c[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_3c)();
          LOCK();
          piVar6 = piVar4 + 2;
          iVar1 = *piVar6 + -1;
          *piVar6 = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      piVar4 = piStack_2c;
      if (((uVar8 & 2) != 0) && (uVar8 = uVar8 & 0xfffffffd, piStack_2c != (int *)0x0)) {
        LOCK();
        iVar1 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_2c)();
          LOCK();
          piVar6 = piVar4 + 2;
          iVar1 = *piVar6 + -1;
          *piVar6 = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      uVar7 = uVar8 | 1;
      cStack_12 = '\x01';
      uStack_1c = uVar7;
      if (iStack_24 != 0) goto LAB_00c572e4;
    }
    piVar4 = piStack_28;
    if (((uVar7 & 1) != 0) && (uStack_1c = uVar7 & 0xfffffffe, piStack_28 != (int *)0x0)) {
      LOCK();
      iVar1 = piStack_28[1] + -1;
      piStack_28[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        piVar6 = piVar4 + 2;
        iVar1 = *piVar6 + -1;
        *piVar6 = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    piVar4 = piStack_20;
    if (cStack_12 == '\0') {
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_20[1] + -1;
        piStack_20[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar6 = piVar4 + 2;
          iVar1 = *piVar6 + -1;
          *piVar6 = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      if (param_2 != (int *)0x0) {
        LOCK();
        iVar1 = param_2[1] + -1;
        param_2[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*param_2)();
          LOCK();
          piVar4 = param_2 + 2;
          iVar1 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*param_2 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return uStack_11;
    }
    puVar2 = *(undefined4 **)(iStack_18 + 0x2c);
    if (puVar2 != (undefined4 *)0x0) {
      piVar4 = (int *)puVar2[1];
      for (piVar6 = (int *)*puVar2; piVar6 != piVar4; piVar6 = piVar6 + 2) {
        iStack_24 = *piVar6;
        if ((iStack_24 != 0) &&
           (iVar1 = *(int *)(iStack_24 + 0xc), iVar5 = FUN_00c55950(), iVar3 = iStack_24,
           (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
           (uint)*(ushort *)(iVar5 + 0x1da))) goto LAB_00c57371;
      }
    }
    iVar3 = 0;
LAB_00c57371:
    FUN_0060dcd0(&iStack_48,iVar3);
    uStack_8._0_1_ = 2;
    if ((iStack_48 != 0) && (param_3 < *(float *)(iStack_48 + 0x70))) {
      uStack_11 = FUN_00c57ae0(param_3,param_5,param_4);
    }
    piVar4 = piStack_44;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (piStack_44 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_44[1] + -1;
      piStack_44[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_44)();
        LOCK();
        piVar6 = piVar4 + 2;
        iVar1 = *piVar6 + -1;
        *piVar6 = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    piVar6 = (int *)FUN_0060dcd0(auStack_50,*(undefined4 *)(iStack_18 + 0x34));
    piVar4 = piStack_20;
    iStack_38 = *piVar6;
    piStack_34 = (int *)piVar6[1];
    *piVar6 = 0;
    piVar6[1] = 0;
    piVar6 = piStack_34;
    iStack_18 = iStack_38;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_20[1] + -1;
      piStack_20[1] = iVar1;
      UNLOCK();
      piVar6 = piStack_34;
      if (iVar1 == 0) {
        puVar2 = (undefined4 *)*piStack_20;
        piStack_20 = piStack_34;
        (*(code *)*puVar2)();
        LOCK();
        piVar6 = piVar4 + 2;
        iVar1 = *piVar6 + -1;
        *piVar6 = iVar1;
        UNLOCK();
        piVar6 = piStack_20;
        if (iVar1 == 0) {
          (**(code **)(*piVar4 + 4))();
          piVar6 = piStack_20;
        }
      }
    }
    piStack_20 = piVar6;
    uVar7 = uStack_1c;
    piVar4 = piStack_4c;
    if (piStack_4c != (int *)0x0) {
      LOCK();
      iVar1 = piStack_4c[1] + -1;
      piStack_4c[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_4c)();
        LOCK();
        piVar6 = piVar4 + 2;
        iVar1 = *piVar6 + -1;
        *piVar6 = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
  } while( true );
}



/* FUNCTION 28659 ; VA 0x00c574e0 ; FUN_00c574e0 */

int __thiscall FUN_00c574e0(int param_1,int param_2,int param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int iVar7;
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b821;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  iVar4 = FUN_008a4210(param_2,param_3);
  if ((param_3 != 0) && (iVar4 = FUN_0085ff70(param_3), iVar4 != 0)) {
    iVar4 = FUN_00b839c0(1);
  }
  if ((param_2 != 0) && (iVar4 = FUN_0085ff70(param_2), iVar4 != 0)) {
    iVar4 = FUN_00b839c0(0xffffffff);
  }
  iVar7 = param_3;
  if (((param_3 != 0) || (iVar7 = param_2, param_2 != 0)) &&
     (iVar4 = FUN_0098c5a0(iVar7,1), (char)iVar4 != '\0')) {
    if (param_2 != 0) {
      iVar4 = FUN_01679490();
    }
    if (param_3 != 0) {
      puVar5 = (undefined4 *)FUN_0060dcd0(auStack_30,param_1);
      uVar2 = *puVar5;
      piVar3 = (int *)puVar5[1];
      *puVar5 = 0;
      puVar5[1] = 0;
      uStack_8._0_1_ = 1;
      uStack_8._1_3_ = 0;
      uStack_28 = uVar2;
      piStack_24 = piVar3;
      FUN_006eccd0();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      uVar6 = FUN_01675290(DAT_02110da8);
      uStack_8 = 3;
      uStack_1c = uVar6;
      puStack_20 = (undefined4 *)FUN_01674e20(0x20);
      if (puStack_20 == (undefined4 *)0x0) {
        puVar5 = (undefined4 *)0x0;
      }
      else {
        *puStack_20 = 0;
        puStack_20[1] = 1;
        puStack_20[2] = FUN_00c56490;
        puStack_20[3] = FUN_0068b170;
        puStack_20[4] = 0;
        puStack_20[5] = param_1 + 0xa8;
        puStack_20[6] = 0;
        puStack_20[7] = 0;
        if (piVar3 != (int *)0x0) {
          LOCK();
          piVar3[1] = piVar3[1] + 1;
          UNLOCK();
        }
        puStack_20[6] = uVar2;
        puStack_20[7] = piVar3;
        puVar5 = puStack_20;
      }
      FUN_016797d0(puVar5);
      if (puVar5 != (undefined4 *)0x0) {
        LOCK();
        puVar5[1] = puVar5[1] + 1;
        UNLOCK();
      }
      uStack_14 = 2;
      uStack_8 = 4;
      puStack_20 = puVar5;
      FUN_01675290(uVar6);
      iVar7 = *(int *)(iStack_18 + 0xb0);
      *(undefined4 **)(iStack_18 + 0xb0) = puVar5;
      iVar4 = iStack_18;
      if (iVar7 != 0) {
        piVar1 = (int *)(iVar7 + 4);
        LOCK();
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        iVar4 = iVar4 + -1;
        if (iVar4 == 0) {
          iVar4 = FUN_01674ea0(iVar7);
        }
      }
      if (piVar3 != (int *)0x0) {
        LOCK();
        piVar1 = piVar3 + 1;
        iVar7 = *piVar1;
        iVar4 = *piVar1;
        *piVar1 = iVar7 + -1;
        UNLOCK();
        if (iVar7 + -1 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar7 = *piVar1;
          iVar4 = *piVar1;
          *piVar1 = iVar7 + -1;
          UNLOCK();
          if (iVar7 + -1 == 0) {
            iVar4 = (**(code **)(*piVar3 + 4))();
          }
        }
      }
      if (piStack_2c != (int *)0x0) {
        LOCK();
        piVar3 = piStack_2c + 1;
        iVar7 = *piVar3;
        iVar4 = *piVar3;
        *piVar3 = iVar7 + -1;
        UNLOCK();
        if (iVar7 + -1 == 0) {
          iVar4 = (**(code **)*piStack_2c)();
          LOCK();
          piVar3 = piStack_2c + 2;
          iVar7 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar7 == 1) {
            iVar4 = (**(code **)(*piStack_2c + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 28660 ; VA 0x00c57700 ; FUN_00c57700 */

void FUN_00c57700(undefined *param_1,int *param_2,undefined4 param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  
  if ((param_1 != &DAT_021371b8) ||
     ((((param_2[1] - *param_2) - 0x1a0U < 0xd0 &&
       (iVar1 = *(int *)*param_2, iVar3 = FUN_0088cdc0(), iVar1 == iVar3)) &&
      (cVar2 = FUN_00c60280(*param_2,param_3), cVar2 != '\0')))) {
    FUN_009cba80(param_1,param_2,param_3);
  }
  return;
}



/* FUNCTION 28661 ; VA 0x00c57760 ; FUN_00c57760 */

void __thiscall FUN_00c57760(int param_1,undefined4 *param_2)

{
  char cVar1;
  undefined4 *puVar2;
  uint uVar3;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2748;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01d68874 != '\0') {
    ExceptionList = &pvStack_10;
    cVar1 = FUN_00684460(&param_2,(undefined4 *)(param_1 + 0x78));
    if ((cVar1 != '\0') && ((undefined4 **)(param_1 + 0x78) != &param_2)) {
      puVar2 = &param_2;
      if (0xf < in_stack_00000018) {
        puVar2 = param_2;
      }
      FUN_005542c0(puVar2,in_stack_00000014);
    }
  }
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    puVar2 = param_2;
    if (0xfff < uVar3) {
      puVar2 = (undefined4 *)param_2[-1];
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28662 ; VA 0x00c57800 ; FUN_00c57800 */

void * FUN_00c57800(int param_1,int *param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  void *pvVar5;
  int iVar6;
  int *piVar7;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180b838;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  iStack_14 = param_1;
  pvVar5 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    ExceptionList = &pvStack_10;
    iVar4 = thunk_FUN_00897b90();
    pvVar5 = (void *)(uint)*(ushort *)(iVar4 + 0x1da);
    if ((void *)((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) <= pvVar5) {
      do {
        puVar2 = *(undefined4 **)(iStack_14 + 0x2c);
        if (puVar2 != (undefined4 *)0x0) {
          piVar3 = (int *)puVar2[1];
          for (piVar7 = (int *)*puVar2; piVar7 != piVar3; piVar7 = piVar7 + 2) {
            iVar1 = *piVar7;
            if (iVar1 != 0) {
              iVar4 = *(int *)(iVar1 + 0xc);
              iVar6 = FUN_00c55950();
              pvVar5 = (void *)(uint)*(ushort *)(iVar6 + 0x1da);
              if ((void *)((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)) <=
                  pvVar5) {
                if (iVar1 != 0) {
                  pvVar5 = (void *)FUN_00c568a0(param_3);
                }
                break;
              }
            }
          }
        }
        iStack_14 = *(int *)(iStack_14 + 0x34);
        if (iStack_14 == 0) break;
        iVar1 = *(int *)(iStack_14 + 0xc);
        iVar4 = FUN_008aa870();
        pvVar5 = (void *)(uint)*(ushort *)(iVar4 + 0x1da);
      } while (pvVar5 < (void *)((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)
                                ));
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar3 = param_2 + 1;
    iVar1 = *piVar3;
    pvVar5 = (void *)*piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      pvVar5 = (void *)(**(code **)*param_2)();
      LOCK();
      piVar3 = param_2 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        pvVar5 = (void *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 28663 ; VA 0x00c57930 ; FUN_00c57930 */

undefined __thiscall FUN_00c57930(int param_1,int param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined uVar7;
  undefined4 uVar8;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180b868;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  iStack_14 = param_1;
  if (param_2 == *(int *)(param_1 + 0x90)) {
    uVar7 = 0;
    ExceptionList = &pvStack_10;
  }
  else {
    ExceptionList = &pvStack_10;
    if (param_2 != 0) {
      ExceptionList = &pvStack_10;
      puVar6 = (undefined4 *)FUN_0060dcd0(auStack_20,param_4);
      uStack_8._0_1_ = 1;
      uVar2 = *puVar6;
      uVar3 = puVar6[1];
      *puVar6 = 0;
      puVar6[1] = 0;
      FUN_00925d30(param_1,uVar2,uVar3);
      piVar4 = piStack_1c;
      uStack_8._0_1_ = 0;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar5 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          piVar1 = piVar4 + 2;
          iVar5 = *piVar1 + -1;
          *piVar1 = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      uVar8 = 1;
      puVar6 = (undefined4 *)FUN_0060dcd0(auStack_20,param_4,1);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      uVar2 = *puVar6;
      uVar3 = puVar6[1];
      *puVar6 = 0;
      puVar6[1] = 0;
      FUN_00c56520(param_1,uVar2,uVar3,uVar8);
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar5 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          iVar5 = piStack_1c[2] + -1;
          piStack_1c[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    *(int *)(param_1 + 0x90) = param_2;
    piVar4 = *(int **)(param_1 + 0x94);
    *(int **)(iStack_14 + 0x94) = param_3;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    uVar7 = 1;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar5 = param_3[1] + -1;
    param_3[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar4 = param_3 + 2;
      iVar5 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 28664 ; VA 0x00c57ae0 ; FUN_00c57ae0 */

undefined4 __thiscall FUN_00c57ae0(int param_1,float param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b740;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x90) != 0) {
    switch(param_3) {
    case 0:
      *(undefined *)(param_1 + 0x74) = 1;
      break;
    case 1:
      if (*(char *)(param_1 + 0x74) != '\0') {
        ExceptionList = &pvStack_10;
        FUN_00c56770(param_2,param_4);
      }
      break;
    case 2:
      *(undefined *)(param_1 + 0x75) = 1;
      break;
    case 3:
      if ((*(char *)(param_1 + 0x75) != '\0') && (param_2 < *(float *)(param_1 + 0x70))) {
        ExceptionList = &pvStack_10;
        puVar5 = (undefined4 *)FUN_0060dcd0(auStack_18,param_4);
        uStack_8 = 0;
        uVar2 = *puVar5;
        uVar3 = puVar5[1];
        *puVar5 = 0;
        puVar5[1] = 0;
        FUN_00925d30(param_1,uVar2,uVar3);
        uStack_8 = 0xffffffff;
        if (piStack_14 != (int *)0x0) {
          LOCK();
          iVar4 = piStack_14[1] + -1;
          piStack_14[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piStack_14)();
            LOCK();
            iVar4 = piStack_14[2] + -1;
            piStack_14[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piStack_14 + 4))();
            }
          }
        }
        uVar6 = 3;
        puVar5 = (undefined4 *)FUN_0060dcd0(auStack_20,param_4,3);
        uStack_8 = 1;
        uVar2 = *puVar5;
        uVar3 = puVar5[1];
        *puVar5 = 0;
        puVar5[1] = 0;
        FUN_00c56520(param_1,uVar2,uVar3,uVar6);
        if (piStack_1c != (int *)0x0) {
          LOCK();
          iVar4 = piStack_1c[1] + -1;
          piStack_1c[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piStack_1c)();
            LOCK();
            piVar1 = piStack_1c + 2;
            iVar4 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar4 == 1) {
              (**(code **)(*piStack_1c + 4))();
            }
          }
        }
      }
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  return 0;
}



/* FUNCTION 28665 ; VA 0x00c57c90 ; FUN_00c57c90 */

undefined4 * __thiscall
FUN_00c57c90(undefined4 *param_1,undefined4 param_2,int param_3,undefined4 param_4,int param_5)

{
  bool bVar1;
  char cVar2;
  undefined **ppuVar3;
  undefined4 uStack_14;
  int iStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  *param_1 = 0;
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
    UNLOCK();
  }
  if (param_5 != 0) {
    LOCK();
    *(int *)(param_5 + 4) = *(int *)(param_5 + 4) + 1;
    UNLOCK();
  }
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
    UNLOCK();
  }
  if (param_5 != 0) {
    LOCK();
    *(int *)(param_5 + 4) = *(int *)(param_5 + 4) + 1;
    UNLOCK();
  }
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  iStack_10 = param_3;
  if (param_5 != 0) {
    LOCK();
    *(int *)(param_5 + 4) = *(int *)(param_5 + 4) + 1;
    UNLOCK();
  }
  uStack_c = param_4;
  iStack_8 = param_5;
  cVar2 = FUN_00585a40(&uStack_14);
  if (cVar2 == '\0') {
    if (iStack_10 != 0) {
      LOCK();
      *(int *)(iStack_10 + 4) = *(int *)(iStack_10 + 4) + 1;
      UNLOCK();
    }
    if (iStack_8 != 0) {
      LOCK();
      *(int *)(iStack_8 + 4) = *(int *)(iStack_8 + 4) + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (iStack_10 != 0) {
      LOCK();
      *(int *)(iStack_10 + 4) = *(int *)(iStack_10 + 4) + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = iStack_10;
    param_1[4] = 0;
    param_1[5] = 0;
    if (iStack_8 != 0) {
      LOCK();
      *(int *)(iStack_8 + 4) = *(int *)(iStack_8 + 4) + 1;
      UNLOCK();
    }
    param_1[5] = iStack_8;
    param_1[4] = uStack_c;
    FUN_0056b650();
    bVar1 = true;
  }
  else {
    bVar1 = false;
  }
  FUN_0056b650();
  FUN_0056b650();
  ppuVar3 = &PTR_FUN_0196c8a4;
  if (!bVar1) {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  FUN_0056b650();
  FUN_0056b650();
  return param_1;
}



/* FUNCTION 28666 ; VA 0x00c57dd0 ; FUN_00c57dd0 */

undefined4 * __thiscall
FUN_00c57dd0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_0196c88c;
  cVar3 = FUN_005918b0(param_2,param_3,param_4,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 28667 ; VA 0x00c57ec0 ; FUN_00c57ec0 */

undefined4 * __thiscall
FUN_00c57ec0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_0196c894;
  cVar3 = FUN_005918b0(param_2,param_3,param_4,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 28668 ; VA 0x00c57fb0 ; FUN_00c57fb0 */

undefined4 * __thiscall
FUN_00c57fb0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_0196c8ac;
  cVar3 = FUN_008e0150(param_2,param_3,param_4,param_5,param_6);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
    if (param_6 != (int *)0x0) {
      LOCK();
      iVar2 = param_6[1] + -1;
      param_6[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_6)();
        LOCK();
        iVar2 = param_6[2] + -1;
        param_6[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_6 + 4))();
        }
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 28669 ; VA 0x00c580b0 ; FUN_00c580b0 */

undefined4 FUN_00c580b0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined auStack_30 [28];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180b890;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_2[1] = param_2[1] + 1;
    UNLOCK();
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  piVar1 = param_2 + 1;
  if (param_2 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_0196c8b4;
  cVar3 = FUN_0055c750(param_1,param_2,auStack_30);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar2 = param_2[2] + -1;
      param_2[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar2 = param_2[2] + -1;
      param_2[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar2 = param_2[2] + -1;
      param_2[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 1;
  FUN_00c62f90(uStack_14);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if ((ppuVar4 != (undefined **)0x0) && ((code *)*ppuVar4 != (code *)0x0)) {
    (*(code *)*ppuVar4)(auStack_30,auStack_30,2);
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uStack_14;
}



/* FUNCTION 28670 ; VA 0x00c58220 ; FUN_00c58220 */

void __thiscall
FUN_00c58220(undefined4 *param_1,undefined4 param_2,undefined4 *param_3,int *param_4)

{
  int *piVar1;
  code *pcVar2;
  uint *puVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  uint uStack_54;
  uint uStack_50;
  uint uStack_4c;
  uint *puStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017edf48;
  pvStack_10 = ExceptionList;
  pcVar2 = (code *)*param_3;
  puVar3 = (uint *)param_4[3];
  uStack_3c = 0;
  uVar4 = *puVar3;
  ExceptionList = &pvStack_10;
  if (uVar4 != 0) {
    uStack_3c = uVar4;
    if ((uVar4 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = puVar3 + 2;
      uStack_4c = 0xc5828e;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar4 & 0xfffffffe))();
    }
    else {
      uStack_34 = puVar3[2];
      uStack_30 = puVar3[3];
      uStack_2c = puVar3[4];
      uStack_28 = puVar3[5];
      uStack_24 = *(undefined8 *)(puVar3 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  puVar3 = (uint *)param_4[2];
  uStack_8 = 0;
  uVar4 = *puVar3;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      (**(code **)(uVar4 & 0xfffffffe))(puVar3 + 2,&uStack_54,0);
    }
    else {
      uStack_54 = puVar3[2];
      uStack_50 = puVar3[3];
      uStack_4c = puVar3[4];
      puStack_48 = (uint *)puVar3[5];
      uStack_44 = *(ulonglong *)(puVar3 + 6);
    }
  }
  puVar5 = (undefined4 *)param_4[1];
  if (puVar5[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar6 = *puVar5;
  uVar7 = puVar5[1];
  puVar5 = (undefined4 *)*param_4;
  if (puVar5[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar8 = *puVar5;
  uVar9 = puVar5[1];
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  (*pcVar2)(*param_1,param_1[1],uVar8,uVar9,uVar6,uVar7);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28671 ; VA 0x00c58380 ; FUN_00c58380 */

int __thiscall FUN_00c58380(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  code *pcVar5;
  int iVar6;
  int *piVar7;
  int *piVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180b8b0;
  pvStack_10 = ExceptionList;
  piVar7 = *(int **)(param_1 + 0x10);
  ExceptionList = &pvStack_10;
  if (piVar7 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar7[1] = piVar7[1] + 1;
    UNLOCK();
    piVar7 = *(int **)(param_1 + 0x10);
  }
  piVar8 = *(int **)(param_1 + 8);
  uVar3 = *(undefined4 *)(param_1 + 0xc);
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
    piVar8 = *(int **)(param_1 + 8);
  }
  uVar4 = *(undefined4 *)(param_1 + 4);
  uStack_8 = 1;
  pcVar5 = (code *)*param_3;
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar7[1] = piVar7[1] + 1;
    UNLOCK();
  }
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
  }
  iVar6 = (*pcVar5)(uVar4,piVar8,uVar3,piVar7);
  if (piVar8 != (int *)0x0) {
    piVar1 = piVar8 + 1;
    LOCK();
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      piVar1 = piVar8 + 2;
      iVar2 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar6 = (**(code **)(*piVar8 + 4))();
      }
    }
  }
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar8 = piVar7 + 1;
    iVar2 = *piVar8;
    iVar6 = *piVar8;
    *piVar8 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*piVar7)();
      LOCK();
      piVar8 = piVar7 + 2;
      iVar2 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 28672 ; VA 0x00c58490 ; FUN_00c58490 */

int FUN_00c58490(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d3288;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00c59be0(param_1,param_2);
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 28673 ; VA 0x00c58520 ; FUN_00c58520 */

int FUN_00c58520(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180b8d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00c59f00(param_1,param_2,param_3,param_4);
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 28674 ; VA 0x00c58600 ; FUN_00c58600 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c58600(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b900;
  pvStack_10 = ExceptionList;
  if (DAT_01efdd58 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efdf70) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efdf70);
      if (DAT_01efdf70 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"RemoteEvent",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01efdf68 = RBX::Creator<class_RBX::RemoteEvent>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efdd60,&DAT_01efdf68);
        FUN_016f3654(FUN_018959a0);
        FUN_016f37bf(&DAT_01efdf70);
      }
    }
    DAT_01efdd58 = &DAT_01efdd60;
  }
  ExceptionList = pvStack_10;
  return DAT_01efdd58;
}



/* FUNCTION 28675 ; VA 0x00c58700 ; FUN_00c58700 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c58700(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b930;
  pvStack_10 = ExceptionList;
  if (DAT_01efdb3c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efdd50) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efdd50);
      if (DAT_01efdd50 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"RemoteFunction",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01efdd48 = RBX::Creator<class_RBX::RemoteFunction>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efdb40,&DAT_01efdd48);
        FUN_016f3654(FUN_01895a00);
        FUN_016f37bf(&DAT_01efdd50);
      }
    }
    DAT_01efdb3c = &DAT_01efdb40;
  }
  ExceptionList = pvStack_10;
  return DAT_01efdb3c;
}



/* FUNCTION 28676 ; VA 0x00c58800 ; FUN_00c58800 */

int FUN_00c58800(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_00c5c220();
  *(undefined2 *)(iVar1 + 0xc) = 0;
  *(undefined4 *)(iVar1 + 0x10) = *(undefined4 *)*param_2;
  FUN_0170d1f0(iVar1 + 0x18,0,0x48);
  *(undefined4 *)(iVar1 + 0x1c) = 0;
  *(undefined4 *)(iVar1 + 0x20) = 0;
  *(undefined4 *)(iVar1 + 0x40) = 0;
  return iVar1;
}



/* FUNCTION 28677 ; VA 0x00c58850 ; FUN_00c58850 */

int __thiscall FUN_00c58850(int *param_1,uint *param_2,uint *param_3)

{
  uint uVar1;
  int iVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint *puVar10;
  uint *puVar11;
  uint *puVar12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180b948;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  iVar5 = (int)param_2 - iVar2 >> 5;
  iVar6 = param_1[1] - iVar2 >> 5;
  if (iVar6 == 0x7ffffff) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar6 + 1;
  uVar9 = param_1[2] - iVar2 >> 5;
  uVar7 = uVar1;
  if ((uVar9 <= 0x7ffffff - (uVar9 >> 1)) && (uVar7 = (uVar9 >> 1) + uVar9, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  uVar9 = uVar7 << 5;
  if (uVar7 < 0x8000000) {
    if (0xfff < uVar9) goto LAB_00c588e1;
    if (uVar9 == 0) {
      puVar11 = (uint *)0x0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      puVar11 = (uint *)FUN_01674e20(uVar9);
    }
  }
  else {
    uVar9 = 0xffffffff;
LAB_00c588e1:
    uVar8 = uVar9 + 0x23;
    if (uVar8 <= uVar9) {
      uVar8 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    uVar9 = FUN_01674e20(uVar8);
    if (uVar9 == 0) goto LAB_00c58ae2;
    puVar11 = (uint *)(uVar9 + 0x23 & 0xffffffe0);
    puVar11[-1] = uVar9;
  }
  puVar12 = puVar11 + iVar5 * 8;
  *puVar12 = 0;
  uVar9 = *param_3;
  uStack_8 = 0;
  if (uVar9 != 0) {
    *puVar12 = uVar9;
    if ((uVar9 & 1) == 0) {
      (**(code **)(uVar9 & 0xfffffffe))(param_3 + 2,puVar12 + 2,0);
    }
    else {
      uVar9 = param_3[3];
      uVar8 = param_3[4];
      uVar4 = param_3[5];
      puVar12[2] = param_3[2];
      puVar12[3] = uVar9;
      puVar12[4] = uVar8;
      puVar12[5] = uVar4;
      uVar9 = param_3[7];
      puVar12[6] = param_3[6];
      puVar12[7] = uVar9;
    }
  }
  puVar3 = (uint *)param_1[1];
  if (param_2 == puVar3) {
    puVar12 = (uint *)*param_1;
    uStack_8._0_1_ = 1;
    puVar10 = puVar11;
    while (puVar12 != puVar3) {
      *puVar10 = 0;
      uVar9 = *puVar12;
      if (uVar9 == 0) {
LAB_00c589fb:
        puVar10 = puVar10 + 8;
        puVar12 = puVar12 + 8;
      }
      else {
        *puVar10 = uVar9;
        if ((uVar9 & 1) == 0) {
          (**(code **)(uVar9 & 0xfffffffe))(puVar12 + 2,puVar10 + 2,0);
          goto LAB_00c589fb;
        }
        uVar9 = puVar12[3];
        uVar8 = puVar12[4];
        uVar4 = puVar12[5];
        puVar10[2] = puVar12[2];
        puVar10[3] = uVar9;
        puVar10[4] = uVar8;
        puVar10[5] = uVar4;
        uVar9 = puVar12[7];
        puVar10[6] = puVar12[6];
        puVar10[7] = uVar9;
        puVar10 = puVar10 + 8;
        puVar12 = puVar12 + 8;
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_006ce110(puVar10,puVar10,param_1);
  }
  else {
    FUN_006d4080(*param_1,param_2,puVar11);
    FUN_006d4080(param_2,param_1[1],puVar12 + 8);
  }
  uStack_8 = 0xffffffff;
  if (*param_1 != 0) {
    FUN_006ce110(*param_1,param_1[1],param_1);
    iVar2 = *param_1;
    uVar9 = param_1[2] - iVar2 & 0xffffffe0;
    iVar6 = iVar2;
    if (0xfff < uVar9) {
      iVar6 = *(int *)(iVar2 + -4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (iVar2 - iVar6) - 4U) {
LAB_00c58ae2:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar9);
  }
  *param_1 = (int)puVar11;
  param_1[1] = (int)(puVar11 + uVar1 * 8);
  param_1[2] = (int)(puVar11 + uVar7 * 8);
  ExceptionList = pvStack_10;
  return *param_1 + iVar5 * 0x20;
}



/* FUNCTION 28678 ; VA 0x00c58ab8 ; Catch_All@00c58ab8 */

void Catch_All_00c58ab8(void)

{
  int unaff_EBP;
  
  FUN_006d3e10(*(undefined4 *)(unaff_EBP + -0x20),*(undefined4 *)(unaff_EBP + -0x28));
  FUN_0057d2b0(*(undefined4 *)(unaff_EBP + -0x34),*(undefined4 *)(unaff_EBP + -0x24));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28679 ; VA 0x00c58af0 ; FUN_00c58af0 */

void __thiscall
FUN_00c58af0(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x2aaaaa8 < (uint)param_1[1]) {
    FUN_00c5c240(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00c58ba2:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00c58ba2;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 28680 ; VA 0x00c58c50 ; FUN_00c58c50 */

undefined4 * __thiscall
FUN_00c58c50(int *param_1,undefined4 *param_2,int *param_3,int *param_4,undefined4 param_5)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined *puVar4;
  int *piVar5;
  undefined4 *puVar6;
  bool bVar7;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180b960;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd4;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  piStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_00c58af0(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar5 = (int *)*param_1;
  if (param_3 == (int *)*piVar5) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*param_4 < param_3[4]) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_00c58af0(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar5) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*(int *)(piVar5[2] + 0x10) < *param_4) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_00c58af0(param_2,0,piVar5[2],param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    iVar1 = *param_4;
    iVar2 = param_3[4];
    bVar7 = SBORROW4(iVar2,iVar1);
    iVar3 = iVar2 - iVar1;
    ExceptionList = &pvStack_10;
    puVar4 = &stack0xffffffd4;
    if (iVar1 < iVar2) {
      piStack_18 = param_3;
      ExceptionList = &pvStack_10;
      piVar5 = (int *)FUN_0056f560();
      iVar3 = *param_4;
      if (*(int *)(*piVar5 + 0x10) < iVar3) {
        if (*(char *)(piStack_18[2] + 0xd) != '\0') {
          FUN_00c58af0(param_2,0,piStack_18,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00c58af0(param_2,1,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
      bVar7 = SBORROW4(param_3[4],iVar3);
      iVar3 = param_3[4] - iVar3;
      puVar4 = puStack_14;
    }
    puStack_14 = puVar4;
    if (bVar7 != iVar3 < 0) {
      piStack_18 = param_3;
      piVar5 = (int *)FUN_00551320();
      if ((*piVar5 == *param_1) || (*param_4 < piStack_18[4])) {
        if (*(char *)(param_3[2] + 0xd) != '\0') {
          FUN_00c58af0(param_2,0,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00c58af0(param_2,1,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = (undefined4 *)FUN_00c58e60(auStack_20,0,param_4,param_5);
  *param_2 = *puVar6;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28681 ; VA 0x00c58e3d ; Catch_All@00c58e3d */

void Catch_All_00c58e3d(void)

{
  int unaff_EBP;
  
  FUN_00c5c240(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28682 ; VA 0x00c58e60 ; FUN_00c58e60 */

void __thiscall
FUN_00c58e60(undefined4 *param_1,undefined4 *param_2,char param_3,int *param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int *piVar2;
  undefined4 *puVar3;
  int *piVar4;
  bool bVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180b970;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piVar2 = (int *)*param_1;
  bVar5 = true;
  piVar4 = piVar2;
  if (*(char *)(piVar2[1] + 0xd) == '\0') {
    piVar2 = (int *)piVar2[1];
    do {
      piVar4 = piVar2;
      if (param_3 == '\0') {
        bVar5 = *param_4 < piVar4[4];
      }
      else {
        bVar5 = *param_4 <= piVar4[4];
      }
      if (bVar5 == false) {
        piVar2 = (int *)piVar4[2];
      }
      else {
        piVar2 = (int *)*piVar4;
      }
    } while (*(char *)((int)piVar2 + 0xd) == '\0');
    piVar2 = (int *)*param_1;
  }
  ExceptionList = &pvStack_10;
  _param_3 = piVar4;
  if (bVar5) {
    if (piVar4 == (int *)*piVar2) {
      bVar5 = true;
      ExceptionList = &pvStack_10;
      goto LAB_00c58ee7;
    }
    ExceptionList = &pvStack_10;
    FUN_0056f560();
  }
  uVar1 = param_5;
  piVar2 = _param_3;
  if (*param_4 <= _param_3[4]) {
    FUN_008e9ba0();
    FUN_01674ea0(uVar1,0x60);
    *param_2 = piVar2;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00c58ee7:
  puVar3 = (undefined4 *)FUN_00c58af0(&param_3,bVar5,piVar4,param_4,param_5);
  *param_2 = *puVar3;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28683 ; VA 0x00c58f61 ; Catch_All@00c58f61 */

void Catch_All_00c58f61(void)

{
  int unaff_EBP;
  
  FUN_00c5c240(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28684 ; VA 0x00c58f80 ; FUN_00c58f80 */

int __thiscall FUN_00c58f80(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180b980;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::RemoteEvent*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28685 ; VA 0x00c59052 ; Catch_All@00c59052 */

void Catch_All_00c59052(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28686 ; VA 0x00c59070 ; FUN_00c59070 */

int __thiscall FUN_00c59070(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180b990;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::RemoteFunction*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28687 ; VA 0x00c59142 ; Catch_All@00c59142 */

void Catch_All_00c59142(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28688 ; VA 0x00c59160 ; FUN_00c59160 */

void FUN_00c59160(int *param_1)

{
  int iVar1;
  int iStack_6c;
  int iStack_68;
  char cStack_64;
  int iStack_60;
  char acStack_5c [72];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180b9a8;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff88;
  iStack_6c = -0x3ea8cf1e;
  iStack_68 = 0x7f0725e3;
  cStack_64 = '\0';
  iStack_60 = 0;
  acStack_5c[0] = '\0';
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = iStack_60;
  do {
    iStack_60 = iVar1;
    if (*param_1 == iStack_6c) {
LAB_00c59243:
      if ((iStack_60 != 0) && (iStack_60 != -1)) {
        CloseHandle(iStack_60);
      }
      ExceptionList = pvStack_10;
      return;
    }
    LOCK();
    iVar1 = *param_1;
    if (iVar1 == 0) {
      *param_1 = iStack_68;
      iVar1 = 0;
    }
    UNLOCK();
    if (iVar1 == 0) {
      if (iStack_60 == 0) {
        if (acStack_5c[0] == '\0') {
          FUN_005881c0(acStack_5c,param_1);
        }
        iVar1 = OpenEventA(0x100002,0,acStack_5c);
        if ((iStack_60 != 0) && (iStack_60 != -1)) {
          CloseHandle(iStack_60);
        }
        iStack_60 = iVar1;
        if (iVar1 != 0) goto LAB_00c5920e;
      }
      else {
LAB_00c5920e:
        ResetEvent(iStack_60);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_0087c450(&DAT_018c5f98,"RemoteFunction","invokeServer",0,0,0);
      FUN_0057b500(param_1,&iStack_6c);
      goto LAB_00c59243;
    }
    if (cStack_64 == '\0') {
      LOCK();
      param_1[1] = param_1[1] + 1;
      UNLOCK();
      cStack_64 = '\x01';
      if (*param_1 == iStack_6c) goto LAB_00c59243;
      if (iStack_60 != 0) goto LAB_00c592bd;
      if (acStack_5c[0] == '\0') {
        FUN_005881c0(acStack_5c,param_1);
      }
      iVar1 = CreateEventA(0,1,0,acStack_5c);
      if ((iStack_60 != 0) && (iStack_60 != -1)) {
        CloseHandle(iStack_60);
      }
    }
    else {
LAB_00c592bd:
      WaitForSingleObjectEx(iStack_60,0xffffffff,0);
      iVar1 = iStack_60;
    }
  } while( true );
}



/* FUNCTION 28689 ; VA 0x00c592cd ; Catch_All@00c592cd */

void Catch_All_00c592cd(void)

{
  int unaff_EBP;
  
  FUN_0058a8e0(*(undefined4 *)(unaff_EBP + 8),unaff_EBP + -0x68);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28690 ; VA 0x00c592f0 ; FUN_00c592f0 */

void FUN_00c592f0(int *param_1)

{
  int iVar1;
  int iStack_6c;
  int iStack_68;
  char cStack_64;
  int iStack_60;
  char acStack_5c [72];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180b9c8;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff88;
  iStack_6c = -0x3ea8cf1e;
  iStack_68 = 0x7f0725e3;
  cStack_64 = '\0';
  iStack_60 = 0;
  acStack_5c[0] = '\0';
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = iStack_60;
  do {
    iStack_60 = iVar1;
    if (*param_1 == iStack_6c) {
LAB_00c593d3:
      if ((iStack_60 != 0) && (iStack_60 != -1)) {
        CloseHandle(iStack_60);
      }
      ExceptionList = pvStack_10;
      return;
    }
    LOCK();
    iVar1 = *param_1;
    if (iVar1 == 0) {
      *param_1 = iStack_68;
      iVar1 = 0;
    }
    UNLOCK();
    if (iVar1 == 0) {
      if (iStack_60 == 0) {
        if (acStack_5c[0] == '\0') {
          FUN_005881c0(acStack_5c,param_1);
        }
        iVar1 = OpenEventA(0x100002,0,acStack_5c);
        if ((iStack_60 != 0) && (iStack_60 != -1)) {
          CloseHandle(iStack_60);
        }
        iStack_60 = iVar1;
        if (iVar1 != 0) goto LAB_00c5939e;
      }
      else {
LAB_00c5939e:
        ResetEvent(iStack_60);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_0087c450(&DAT_018c5f98,"RemoteEvent","fireServer",0,0,0);
      FUN_0057b500(param_1,&iStack_6c);
      goto LAB_00c593d3;
    }
    if (cStack_64 == '\0') {
      LOCK();
      param_1[1] = param_1[1] + 1;
      UNLOCK();
      cStack_64 = '\x01';
      if (*param_1 == iStack_6c) goto LAB_00c593d3;
      if (iStack_60 != 0) goto LAB_00c5944d;
      if (acStack_5c[0] == '\0') {
        FUN_005881c0(acStack_5c,param_1);
      }
      iVar1 = CreateEventA(0,1,0,acStack_5c);
      if ((iStack_60 != 0) && (iStack_60 != -1)) {
        CloseHandle(iStack_60);
      }
    }
    else {
LAB_00c5944d:
      WaitForSingleObjectEx(iStack_60,0xffffffff,0);
      iVar1 = iStack_60;
    }
  } while( true );
}



/* FUNCTION 28691 ; VA 0x00c5945d ; Catch_All@00c5945d */

void Catch_All_00c5945d(void)

{
  int unaff_EBP;
  
  FUN_0058a8e0(*(undefined4 *)(unaff_EBP + 8),unaff_EBP + -0x68);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28692 ; VA 0x00c59480 ; FUN_00c59480 */

void FUN_00c59480(int *param_1)

{
  int iVar1;
  int iStack_6c;
  int iStack_68;
  char cStack_64;
  int iStack_60;
  char acStack_5c [72];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180b9e8;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff88;
  iStack_6c = -0x3ea8cf1e;
  iStack_68 = 0x7f0725e3;
  cStack_64 = '\0';
  iStack_60 = 0;
  acStack_5c[0] = '\0';
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = iStack_60;
  do {
    iStack_60 = iVar1;
    if (*param_1 == iStack_6c) {
LAB_00c59563:
      if ((iStack_60 != 0) && (iStack_60 != -1)) {
        CloseHandle(iStack_60);
      }
      ExceptionList = pvStack_10;
      return;
    }
    LOCK();
    iVar1 = *param_1;
    if (iVar1 == 0) {
      *param_1 = iStack_68;
      iVar1 = 0;
    }
    UNLOCK();
    if (iVar1 == 0) {
      if (iStack_60 == 0) {
        if (acStack_5c[0] == '\0') {
          FUN_005881c0(acStack_5c,param_1);
        }
        iVar1 = OpenEventA(0x100002,0,acStack_5c);
        if ((iStack_60 != 0) && (iStack_60 != -1)) {
          CloseHandle(iStack_60);
        }
        iStack_60 = iVar1;
        if (iVar1 != 0) goto LAB_00c5952e;
      }
      else {
LAB_00c5952e:
        ResetEvent(iStack_60);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_0087c450(&DAT_018c5f98,"RemoteEvent","fireAllClients",0,0,0);
      FUN_0057b500(param_1,&iStack_6c);
      goto LAB_00c59563;
    }
    if (cStack_64 == '\0') {
      LOCK();
      param_1[1] = param_1[1] + 1;
      UNLOCK();
      cStack_64 = '\x01';
      if (*param_1 == iStack_6c) goto LAB_00c59563;
      if (iStack_60 != 0) goto LAB_00c595dd;
      if (acStack_5c[0] == '\0') {
        FUN_005881c0(acStack_5c,param_1);
      }
      iVar1 = CreateEventA(0,1,0,acStack_5c);
      if ((iStack_60 != 0) && (iStack_60 != -1)) {
        CloseHandle(iStack_60);
      }
    }
    else {
LAB_00c595dd:
      WaitForSingleObjectEx(iStack_60,0xffffffff,0);
      iVar1 = iStack_60;
    }
  } while( true );
}



/* FUNCTION 28693 ; VA 0x00c595ed ; Catch_All@00c595ed */

void Catch_All_00c595ed(void)

{
  int unaff_EBP;
  
  FUN_0058a8e0(*(undefined4 *)(unaff_EBP + 8),unaff_EBP + -0x68);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28694 ; VA 0x00c59610 ; FUN_00c59610 */

void FUN_00c59610(int *param_1)

{
  int iVar1;
  int iStack_6c;
  int iStack_68;
  char cStack_64;
  int iStack_60;
  char acStack_5c [72];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180ba08;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff88;
  iStack_6c = -0x3ea8cf1e;
  iStack_68 = 0x7f0725e3;
  cStack_64 = '\0';
  iStack_60 = 0;
  acStack_5c[0] = '\0';
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = iStack_60;
  do {
    iStack_60 = iVar1;
    if (*param_1 == iStack_6c) {
LAB_00c596f3:
      if ((iStack_60 != 0) && (iStack_60 != -1)) {
        CloseHandle(iStack_60);
      }
      ExceptionList = pvStack_10;
      return;
    }
    LOCK();
    iVar1 = *param_1;
    if (iVar1 == 0) {
      *param_1 = iStack_68;
      iVar1 = 0;
    }
    UNLOCK();
    if (iVar1 == 0) {
      if (iStack_60 == 0) {
        if (acStack_5c[0] == '\0') {
          FUN_005881c0(acStack_5c,param_1);
        }
        iVar1 = OpenEventA(0x100002,0,acStack_5c);
        if ((iStack_60 != 0) && (iStack_60 != -1)) {
          CloseHandle(iStack_60);
        }
        iStack_60 = iVar1;
        if (iVar1 != 0) goto LAB_00c596be;
      }
      else {
LAB_00c596be:
        ResetEvent(iStack_60);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_0087c450(&DAT_018c5f98,"RemoteEvent","fireClient",0,0,0);
      FUN_0057b500(param_1,&iStack_6c);
      goto LAB_00c596f3;
    }
    if (cStack_64 == '\0') {
      LOCK();
      param_1[1] = param_1[1] + 1;
      UNLOCK();
      cStack_64 = '\x01';
      if (*param_1 == iStack_6c) goto LAB_00c596f3;
      if (iStack_60 != 0) goto LAB_00c5976d;
      if (acStack_5c[0] == '\0') {
        FUN_005881c0(acStack_5c,param_1);
      }
      iVar1 = CreateEventA(0,1,0,acStack_5c);
      if ((iStack_60 != 0) && (iStack_60 != -1)) {
        CloseHandle(iStack_60);
      }
    }
    else {
LAB_00c5976d:
      WaitForSingleObjectEx(iStack_60,0xffffffff,0);
      iVar1 = iStack_60;
    }
  } while( true );
}



/* FUNCTION 28695 ; VA 0x00c5977d ; Catch_All@00c5977d */

void Catch_All_00c5977d(void)

{
  int unaff_EBP;
  
  FUN_0058a8e0(*(undefined4 *)(unaff_EBP + 8),unaff_EBP + -0x68);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28696 ; VA 0x00c597a0 ; FUN_00c597a0 */

void FUN_00c597a0(int *param_1)

{
  int iVar1;
  int iStack_6c;
  int iStack_68;
  char cStack_64;
  int iStack_60;
  char acStack_5c [72];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180ba28;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff88;
  iStack_6c = -0x3ea8cf1e;
  iStack_68 = 0x7f0725e3;
  cStack_64 = '\0';
  iStack_60 = 0;
  acStack_5c[0] = '\0';
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = iStack_60;
  do {
    iStack_60 = iVar1;
    if (*param_1 == iStack_6c) {
LAB_00c59883:
      if ((iStack_60 != 0) && (iStack_60 != -1)) {
        CloseHandle(iStack_60);
      }
      ExceptionList = pvStack_10;
      return;
    }
    LOCK();
    iVar1 = *param_1;
    if (iVar1 == 0) {
      *param_1 = iStack_68;
      iVar1 = 0;
    }
    UNLOCK();
    if (iVar1 == 0) {
      if (iStack_60 == 0) {
        if (acStack_5c[0] == '\0') {
          FUN_005881c0(acStack_5c,param_1);
        }
        iVar1 = OpenEventA(0x100002,0,acStack_5c);
        if ((iStack_60 != 0) && (iStack_60 != -1)) {
          CloseHandle(iStack_60);
        }
        iStack_60 = iVar1;
        if (iVar1 != 0) goto LAB_00c5984e;
      }
      else {
LAB_00c5984e:
        ResetEvent(iStack_60);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_0087c450(&DAT_018c5f98,"RemoteFunction","invokeClient",0,0,0);
      FUN_0057b500(param_1,&iStack_6c);
      goto LAB_00c59883;
    }
    if (cStack_64 == '\0') {
      LOCK();
      param_1[1] = param_1[1] + 1;
      UNLOCK();
      cStack_64 = '\x01';
      if (*param_1 == iStack_6c) goto LAB_00c59883;
      if (iStack_60 != 0) goto LAB_00c598fd;
      if (acStack_5c[0] == '\0') {
        FUN_005881c0(acStack_5c,param_1);
      }
      iVar1 = CreateEventA(0,1,0,acStack_5c);
      if ((iStack_60 != 0) && (iStack_60 != -1)) {
        CloseHandle(iStack_60);
      }
    }
    else {
LAB_00c598fd:
      WaitForSingleObjectEx(iStack_60,0xffffffff,0);
      iVar1 = iStack_60;
    }
  } while( true );
}



/* FUNCTION 28697 ; VA 0x00c5990d ; Catch_All@00c5990d */

void Catch_All_00c5990d(void)

{
  int unaff_EBP;
  
  FUN_0058a8e0(*(undefined4 *)(unaff_EBP + 8),unaff_EBP + -0x68);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28698 ; VA 0x00c59930 ; FUN_00c59930 */

undefined4 * FUN_00c59930(undefined4 *param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 *puStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180baa4;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00c58600();
  uVar3 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar2 + 0x1dc) != (undefined4 *)0x0) {
    uVar3 = **(undefined4 **)(iVar2 + 0x1dc);
  }
  uVar3 = FUN_01675290(uVar3);
  uStack_8 = 1;
  puVar4 = (undefined4 *)FUN_01674e20(0xb4);
  uStack_8._0_1_ = 2;
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    FUN_0089a650("RemoteEvent");
    uStack_8._0_1_ = 3;
    *puVar4 = RBX::DescribedCreatable<class_RBX::RemoteEvent,class_RBX::Instance>::vftable;
    uVar5 = FUN_00c58600();
    puVar4[3] = uVar5;
    *puVar4 = RBX::RemoteEvent::vftable;
    uVar5 = DAT_01d6887c;
    puVar4[0x16] = 0;
    puVar4[0x17] = 0;
    puVar4[0x18] = puVar4;
    puVar1 = puVar4 + 0x1a;
    puVar4[0x15] = RBX::
                   LatchedSignal<class_rbx::remote_signal,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>
                   ::vftable;
    puVar4[0x19] = "OnServerEvent";
    uStack_8._0_1_ = 5;
    *puVar1 = 0;
    puVar4[0x1b] = 0;
    puVar4[0x1c] = 0;
    puVar4[0x1d] = 0;
    puVar4[0x1e] = 0;
    puVar6 = (undefined4 *)FUN_01674e20(8);
    *puVar1 = puVar6;
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 **)*puVar1 = puVar1;
    puVar4[0x1f] = uVar5;
    puVar4[0x20] = 0;
    uVar5 = DAT_01d6887c;
    puStack_24 = puVar4 + 0x21;
    puVar4[0x22] = 0;
    puVar4[0x23] = 0;
    puVar1 = puVar4 + 0x26;
    *puStack_24 = RBX::
                  LatchedSignal<class_rbx::remote_signal,void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>
                  ::vftable;
    puVar4[0x24] = puVar4;
    puVar4[0x25] = "OnClientEvent";
    uStack_8._0_1_ = 7;
    *puVar1 = 0;
    puVar4[0x27] = 0;
    puVar4[0x28] = 0;
    puVar4[0x29] = 0;
    puVar4[0x2a] = 0;
    puVar6 = (undefined4 *)FUN_01674e20(8);
    *puVar1 = puVar6;
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 **)*puVar1 = puVar1;
    puVar4[0x2b] = uVar5;
    puVar4[0x2c] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c58f80(puVar4,puStack_24);
  uStack_8 = 0xb;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28699 ; VA 0x00c59b20 ; FUN_00c59b20 */

undefined4 * FUN_00c59b20(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180bae3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c58700();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xd8);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c5b170();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c59070(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28700 ; VA 0x00c59be0 ; FUN_00c59be0 */

int __thiscall FUN_00c59be0(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  char cVar4;
  undefined4 *puVar5;
  int *piVar6;
  undefined4 ***pppuVar7;
  int iVar8;
  uint uVar9;
  undefined4 uVar10;
  undefined4 auStack_b0 [8];
  undefined4 uStack_90;
  uint auStack_70 [2];
  undefined auStack_68 [24];
  uint uStack_50;
  undefined auStack_48 [16];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 **ppuStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  undefined8 uStack_20;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180bb3c;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  if (*(int *)(param_1 + 4) == 0) {
    auStack_b0[0] = 0;
    uStack_90 = 0;
    ExceptionList = &pvStack_10;
    if (param_3 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    uVar10 = param_2;
    FUN_008ab6d0(&ppuStack_30,FUN_00c59be0,0,param_1,param_2,param_3);
    if ((int *)uStack_20 != (int *)0x0) {
      LOCK();
      *(int *)((int)(int *)uStack_20 + 4) = *(int *)((int)(int *)uStack_20 + 4) + 1;
      UNLOCK();
    }
    puVar5 = (undefined4 *)
             FUN_00c57fb0(ppuStack_30,iStack_2c,iStack_28,iStack_24,(int *)uStack_20,uVar10,0);
    if (auStack_b0 != puVar5) {
      auStack_70[0] = 0;
      uStack_8._0_1_ = 4;
      FUN_005880d0(puVar5);
      FUN_005880d0(auStack_b0);
      FUN_005880d0(auStack_70);
      uStack_8._0_1_ = 5;
      if (((auStack_70[0] != 0) && ((auStack_70[0] & 1) == 0)) &&
         (*(code **)(auStack_70[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_70[0] & 0xfffffffe))(auStack_68,auStack_68,2);
      }
    }
    uStack_8._0_1_ = 6;
    if (((uStack_50 != 0) && ((uStack_50 & 1) == 0)) &&
       (*(code **)(uStack_50 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_50 & 0xfffffffe))(auStack_48,auStack_48,2);
    }
    piVar6 = (int *)uStack_20;
    uStack_8._0_1_ = 1;
    if ((int *)uStack_20 != (int *)0x0) {
      LOCK();
      iVar8 = ((int *)uStack_20)[1] + -1;
      ((int *)uStack_20)[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*(int *)uStack_20)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar8 = *piVar1 + -1;
        *piVar1 = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    FUN_00c580b0(param_2,param_3);
    cVar4 = FUN_00c62790(auStack_b0);
    if ((cVar4 == '\0') &&
       (uVar3 = *(uint *)(param_1 + 0x2c), uVar9 = uVar3 + 1, *(uint *)(param_1 + 0x2c) = uVar9,
       (uVar9 & uVar3) == 0)) {
      if (*(int *)(param_1 + 0xc) == 0) {
        uStack_38 = 0;
        uStack_34 = 0xf;
        auStack_48[0] = 0;
        FUN_005542c0("unknown instance",0x10);
        piVar6 = (int *)auStack_48;
        uVar9 = 2;
      }
      else {
        piVar6 = (int *)FUN_008a2380(auStack_68);
        uVar9 = 1;
      }
      uStack_20 = 0;
      ppuStack_30 = (undefined4 ***)*piVar6;
      iStack_2c = piVar6[1];
      iStack_28 = piVar6[2];
      iStack_24 = piVar6[3];
      uStack_20 = *(undefined8 *)(piVar6 + 4);
      piVar6[4] = 0;
      piVar6[5] = 0xf;
      *(undefined *)piVar6 = 0;
      uStack_8 = 8;
      if ((uVar9 & 2) != 0) {
        uStack_18 = uVar9 & 0xfffffffd;
        FUN_005507b0();
        uVar9 = uStack_18;
      }
      uStack_8._0_1_ = 9;
      if ((uVar9 & 1) != 0) {
        FUN_005507b0();
      }
      pppuVar7 = &ppuStack_30;
      if (0xf < uStack_20._4_4_) {
        pppuVar7 = (undefined4 ***)ppuStack_30;
      }
      FUN_0086f2f0(3,
                   "Remote event invocation queue exhausted for %s; did you forget to implement %s? (%u events dropped)"
                   ,pppuVar7,*(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x2c));
      FUN_005507b0();
    }
    iVar8 = FUN_008c3510();
  }
  else {
    ExceptionList = &pvStack_10;
    if (param_3 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    iVar8 = FUN_00b1b780(param_2,param_3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar6 = param_3 + 1;
    iVar2 = *piVar6;
    iVar8 = *piVar6;
    *piVar6 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar8 = (**(code **)*param_3)();
      LOCK();
      piVar6 = param_3 + 2;
      iVar2 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar8 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar8;
}



/* FUNCTION 28701 ; VA 0x00c59f00 ; FUN_00c59f00 */

int __thiscall FUN_00c59f00(uint param_1,int param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  char cVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined4 ***pppuVar7;
  int iVar8;
  uint uVar9;
  undefined4 auStack_164 [8];
  undefined4 auStack_144 [8];
  code *pcStack_124;
  undefined4 *puStack_120;
  undefined auStack_11c [24];
  code *pcStack_104;
  undefined4 *puStack_100;
  undefined auStack_fc [24];
  code *pcStack_e4;
  undefined4 *puStack_e0;
  undefined auStack_dc [24];
  undefined4 uStack_c4;
  code *pcStack_c0;
  undefined4 *puStack_bc;
  undefined auStack_b8 [24];
  code *pcStack_a0;
  undefined4 *puStack_9c;
  undefined auStack_98 [24];
  code *pcStack_80;
  undefined4 *puStack_7c;
  undefined auStack_78 [8];
  int iStack_70;
  int *piStack_6c;
  undefined4 uStack_68;
  int *piStack_64;
  code *pcStack_60;
  undefined4 *puStack_5c;
  undefined auStack_58 [24];
  undefined **appuStack_40 [2];
  undefined4 **ppuStack_38;
  int iStack_34;
  int iStack_30;
  int *piStack_2c;
  undefined8 uStack_28;
  uint uStack_20;
  int iStack_1c;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180bc07;
  pvStack_10 = ExceptionList;
  uStack_c4 = 0;
  uStack_8 = 1;
  uStack_20 = param_1;
  if (*(int *)(param_1 + 4) == 0) {
    auStack_164[0] = 0;
    auStack_144[0] = 0;
    ExceptionList = &pvStack_10;
    if (param_5 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    iStack_1c = param_2;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    uVar5 = FUN_00c5b020(param_1,param_2,param_3,param_4,param_5);
    pcStack_a0 = FUN_00c59f00;
    puStack_9c = (undefined4 **)0x0;
    FUN_00a66ab0(uVar5);
    FUN_00a678e0();
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar8 = param_3[1] + -1;
      param_3[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*param_3)();
        LOCK();
        iVar8 = param_3[2] + -1;
        param_3[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*param_3 + 4))();
        }
      }
    }
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar8 = param_5[1] + -1;
      param_5[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*param_5)();
        LOCK();
        iVar8 = param_5[2] + -1;
        param_5[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    pcStack_60 = pcStack_a0;
    puStack_5c = puStack_9c;
    FUN_00a66ab0(auStack_98);
    pcStack_124 = pcStack_60;
    puStack_120 = puStack_5c;
    FUN_00a66ab0(auStack_58);
    pcStack_104 = pcStack_124;
    puStack_100 = puStack_120;
    appuStack_40[0] = (undefined **)0x0;
    FUN_00a66ab0(auStack_11c);
    pcStack_e4 = pcStack_104;
    puStack_e0 = puStack_100;
    FUN_00a66ab0(auStack_fc);
    pcStack_c0 = pcStack_e4;
    puStack_bc = puStack_e0;
    FUN_00a66ab0(auStack_dc);
    cVar4 = FUN_00585a40(&pcStack_c0);
    if (cVar4 == '\0') {
      pcStack_80 = pcStack_c0;
      puStack_7c = puStack_bc;
      FUN_00a66ab0(auStack_b8);
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
      ppuStack_38 = (undefined4 **)FUN_01674e20(0x20);
      if ((undefined4 ***)ppuStack_38 == (undefined4 ***)0x0) {
        ppuStack_38 = (undefined4 ***)0x0;
      }
      else {
        *ppuStack_38 = (undefined4 *)pcStack_80;
        ((undefined4 ***)ppuStack_38)[1] = (undefined4 **)puStack_7c;
        FUN_00a66ab0(auStack_78);
      }
      FUN_00a678e0();
      FUN_00a678e0();
      cStack_11 = '\x01';
    }
    else {
      FUN_00a678e0();
      cStack_11 = '\0';
    }
    FUN_00a678e0();
    appuStack_40[0] = &PTR_FUN_0196c89c;
    if (cStack_11 == '\0') {
      appuStack_40[0] = (undefined **)0x0;
    }
    FUN_00a678e0();
    FUN_00a678e0();
    FUN_00a678e0();
    pcStack_60 = (code *)0x0;
    uStack_8._0_1_ = 0xb;
    FUN_005880d0(appuStack_40);
    FUN_005880d0(auStack_164);
    FUN_005880d0(&pcStack_60);
    uStack_8._0_1_ = 0xc;
    if (((pcStack_60 != (code *)0x0) && (((uint)pcStack_60 & 1) == 0)) &&
       (*(code **)((uint)pcStack_60 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)((uint)pcStack_60 & 0xfffffffe))(auStack_58,auStack_58,2);
    }
    uStack_8._0_1_ = 0xd;
    if (((appuStack_40[0] != (undefined **)0x0) && (((uint)appuStack_40[0] & 1) == 0)) &&
       (*(code **)((uint)appuStack_40[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)((uint)appuStack_40[0] & 0xfffffffe))(&ppuStack_38,&ppuStack_38,2);
    }
    FUN_00a678e0();
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    iStack_30 = param_2;
    piStack_2c = param_3;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    iStack_1c = param_4;
    uStack_28 = CONCAT44(param_5,param_4);
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    iStack_70 = param_2;
    piStack_6c = param_3;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    uStack_68 = param_4;
    piStack_64 = param_5;
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    FUN_00c57c90(param_2,param_3,param_4,param_5,0);
    FUN_0056b650();
    pcStack_a0 = (code *)0x0;
    uStack_8._0_1_ = 0x10;
    FUN_005880d0(&pcStack_60);
    FUN_005880d0(auStack_144);
    FUN_005880d0(&pcStack_a0);
    uStack_8._0_1_ = 0x11;
    if (((pcStack_a0 != (code *)0x0) && (((uint)pcStack_a0 & 1) == 0)) &&
       (*(code **)((uint)pcStack_a0 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)((uint)pcStack_a0 & 0xfffffffe))(auStack_98,auStack_98,2);
    }
    uStack_8._0_1_ = 0x12;
    if (((pcStack_60 != (code *)0x0) && (((uint)pcStack_60 & 1) == 0)) &&
       (*(code **)((uint)pcStack_60 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)((uint)pcStack_60 & 0xfffffffe))(auStack_58,auStack_58,2);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_0056b650();
    uVar3 = uStack_20;
    cVar4 = FUN_00c62790(auStack_164);
    if ((cVar4 == '\0') &&
       (uVar2 = *(uint *)(uVar3 + 0x2c), uVar9 = uVar2 + 1, *(uint *)(uVar3 + 0x2c) = uVar9,
       (uVar9 & uVar2) == 0)) {
      if (*(int *)(uVar3 + 0xc) == 0) {
        uStack_68 = 0;
        piStack_64 = (int *)&DAT_0000000f;
        auStack_78[0] = 0;
        FUN_005542c0("unknown instance",0x10);
        piVar6 = (int *)auStack_78;
        uVar9 = 2;
      }
      else {
        piVar6 = (int *)FUN_008a2380(auStack_b8);
        uVar9 = 1;
      }
      uStack_28 = 0;
      ppuStack_38 = (undefined4 ***)*piVar6;
      iStack_34 = piVar6[1];
      iStack_30 = piVar6[2];
      piStack_2c = (int *)piVar6[3];
      uStack_28 = *(undefined8 *)(piVar6 + 4);
      piVar6[4] = 0;
      piVar6[5] = 0xf;
      *(undefined *)piVar6 = 0;
      uStack_8 = 0x14;
      if ((uVar9 & 2) != 0) {
        uStack_20 = uVar9 & 0xfffffffd;
        FUN_005507b0();
        uVar9 = uStack_20;
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
      if ((uVar9 & 1) != 0) {
        FUN_005507b0();
      }
      pppuVar7 = &ppuStack_38;
      if (0xf < uStack_28._4_4_) {
        pppuVar7 = (undefined4 ***)ppuStack_38;
      }
      FUN_0086f2f0(3,
                   "Remote event invocation queue exhausted for %s; did you forget to implement %s? (%u events dropped)"
                   ,pppuVar7,*(undefined4 *)(uVar3 + 0x10),*(undefined4 *)(uVar3 + 0x2c));
      FUN_005507b0();
    }
    iVar8 = FUN_008c3510();
  }
  else {
    ExceptionList = &pvStack_10;
    if (param_5 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    iVar8 = FUN_00c5c000(param_2,param_3,param_4,param_5);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar6 = param_3 + 1;
    iVar1 = *piVar6;
    iVar8 = *piVar6;
    *piVar6 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar6 = param_3 + 2;
      iVar1 = *piVar6;
      iVar8 = *piVar6;
      *piVar6 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar8 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar6 = param_5 + 1;
    iVar1 = *piVar6;
    iVar8 = *piVar6;
    *piVar6 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar8 = (**(code **)*param_5)();
      LOCK();
      piVar6 = param_5 + 2;
      iVar1 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar8 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar8;
}



/* FUNCTION 28702 ; VA 0x00c5a550 ; FUN_00c5a550 */

code * FUN_00c5a550(code *param_1)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int *piVar4;
  undefined uVar5;
  undefined4 uVar6;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 uStack_1c0;
  undefined4 *puStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined4 uStack_e8;
  int *piStack_e4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180bc4e;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uStack_f0 = FUN_0088cbe0();
  puStack_ec = (undefined4 *)0x0;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_e8 = in_stack_00000024;
  piStack_e4 = in_stack_00000028;
  puStack_ec = (undefined4 *)FUN_00630900();
  uStack_8._0_1_ = 2;
  uStack_1c0 = uStack_f0;
  puStack_1bc = (undefined4 *)0x0;
  if (puStack_ec != (undefined4 *)0x0) {
    (*(code *)*puStack_ec)(&uStack_e8,auStack_1b8);
  }
  uStack_8._0_1_ = 3;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  puStack_1bc = puStack_ec;
  if (param_1 == (code *)0x0) {
    uStack_8._0_1_ = uVar5;
    uVar6 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar6);
  }
  pcVar3 = *(code **)(((uint)param_1 & 0xfffffffe) + 4);
  FUN_005caf00(&uStack_1c0);
  (*pcVar3)(&stack0x0000000c);
  uStack_8._0_1_ = 5;
  if (puStack_1bc != (undefined4 *)0x0) {
    (*(code *)puStack_1bc[2])(auStack_1b8);
  }
  uStack_8._0_1_ = 6;
  if (puStack_ec != (undefined4 *)0x0) {
    (*(code *)puStack_ec[2])(&uStack_e8);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (((param_1 != (code *)0x0) && (((uint)param_1 & 1) == 0)) &&
     (param_1 = *(code **)((uint)param_1 & 0xfffffffe), param_1 != (code *)0x0)) {
    param_1 = (code *)(*param_1)(&stack0x0000000c,&stack0x0000000c,2);
  }
  piVar4 = in_stack_00000028;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000028 + 1;
    iVar2 = *piVar1;
    param_1 = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_1 = (code *)(**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_1 = (code *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28703 ; VA 0x00c5a6f0 ; FUN_00c5a6f0 */

void FUN_00c5a6f0(int param_1,int param_2,code *param_3,undefined4 param_4,undefined4 *param_5)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  uint *puVar5;
  uint uStack_5c;
  undefined auStack_54 [24];
  uint auStack_3c [2];
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180bc78;
  pvStack_10 = ExceptionList;
  puVar5 = (uint *)(param_1 + param_2);
  auStack_3c[0] = 0;
  uVar2 = *puVar5;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    auStack_3c[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))(puVar5 + 2,&uStack_34,0);
    }
    else {
      uStack_34 = puVar5[2];
      uStack_30 = puVar5[3];
      uStack_2c = puVar5[4];
      uStack_28 = puVar5[5];
      uStack_24 = *(undefined8 *)(puVar5 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8 = 0;
  piVar4 = (int *)param_5[2];
  uStack_1c = *param_5;
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar4[1] = piVar4[1] + 1;
    UNLOCK();
    piVar4 = (int *)param_5[2];
  }
  uStack_18 = param_5[1];
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar4[1] = piVar4[1] + 1;
    UNLOCK();
  }
  piStack_14 = piVar4;
  FUN_00c57dd0(uStack_1c,uStack_18,piVar4,0);
  iStack_8._0_1_ = 2;
  FUN_00c63020(puVar5);
  iStack_8._0_1_ = 3;
  if (((uStack_5c != 0) && ((uStack_5c & 1) == 0)) &&
     (*(code **)(uStack_5c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_5c & 0xfffffffe))(auStack_54,auStack_54,2);
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  if (param_3 != (code *)0x0) {
    (*param_3)(auStack_3c);
  }
  iStack_8 = 4;
  if (((auStack_3c[0] != 0) && ((auStack_3c[0] & 1) == 0)) &&
     (*(code **)(auStack_3c[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_3c[0] & 0xfffffffe))(&uStack_34,&uStack_34,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28704 ; VA 0x00c5a850 ; FUN_00c5a850 */

void FUN_00c5a850(int param_1,int param_2,code *param_3,undefined4 param_4,undefined4 *param_5)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  uint *puVar5;
  uint uStack_5c;
  undefined auStack_54 [24];
  uint auStack_3c [2];
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180bca8;
  pvStack_10 = ExceptionList;
  puVar5 = (uint *)(param_1 + param_2);
  auStack_3c[0] = 0;
  uVar2 = *puVar5;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    auStack_3c[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))(puVar5 + 2,&uStack_34,0);
    }
    else {
      uStack_34 = puVar5[2];
      uStack_30 = puVar5[3];
      uStack_2c = puVar5[4];
      uStack_28 = puVar5[5];
      uStack_24 = *(undefined8 *)(puVar5 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8 = 0;
  piVar4 = (int *)param_5[2];
  uStack_1c = *param_5;
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar4[1] = piVar4[1] + 1;
    UNLOCK();
    piVar4 = (int *)param_5[2];
  }
  uStack_18 = param_5[1];
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar4[1] = piVar4[1] + 1;
    UNLOCK();
  }
  piStack_14 = piVar4;
  FUN_00c57ec0(uStack_1c,uStack_18,piVar4,0);
  iStack_8._0_1_ = 2;
  FUN_00c630b0(puVar5);
  iStack_8._0_1_ = 3;
  if (((uStack_5c != 0) && ((uStack_5c & 1) == 0)) &&
     (*(code **)(uStack_5c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_5c & 0xfffffffe))(auStack_54,auStack_54,2);
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  if (param_3 != (code *)0x0) {
    (*param_3)(auStack_3c);
  }
  iStack_8 = 4;
  if (((auStack_3c[0] != 0) && ((auStack_3c[0] & 1) == 0)) &&
     (*(code **)(auStack_3c[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_3c[0] & 0xfffffffe))(&uStack_34,&uStack_34,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28705 ; VA 0x00c5a9b0 ; FUN_00c5a9b0 */

void __thiscall FUN_00c5a9b0(int param_1,undefined4 param_2,int *param_3)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180bcd8;
  pvStack_10 = ExceptionList;
  iVar6 = *param_3;
  iVar4 = *(int *)(iVar6 + 0xd0);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088cbe0();
  if (iVar4 != iVar2) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar3 = (undefined4 *)(iVar6 + 0xd8);
  if (*(int *)(iVar6 + 0xd4) == 0) {
    puVar3 = (undefined4 *)0x0;
  }
  iVar6 = puVar3[1];
  if (iVar6 != 0) {
    LOCK();
    *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
    UNLOCK();
    iVar6 = puVar3[1];
  }
  uVar1 = *puVar3;
  param_3 = (int *)*param_3;
  uStack_8 = 0;
  iVar4 = *param_3;
  iVar2 = FUN_0088cdc0();
  if (iVar4 == iVar2) {
    piVar5 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar5 = (int *)0x0;
    }
    iVar4 = piVar5[1];
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
      UNLOCK();
      iVar4 = piVar5[1];
    }
    iVar2 = *piVar5;
    uStack_8 = 2;
    (**(code **)(param_1 + 0x38))(1);
    FUN_00c58520(iVar2,iVar4,uVar1,iVar6);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28706 ; VA 0x00c5aad0 ; FUN_00c5aad0 */

undefined4 * __thiscall FUN_00c5aad0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180bd06;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[4] = 0;
  uVar2 = param_2[4];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[4] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 6,param_1 + 6,0);
    }
    else {
      uVar3 = param_2[7];
      uVar4 = param_2[8];
      uVar5 = param_2[9];
      param_1[6] = param_2[6];
      param_1[7] = uVar3;
      param_1[8] = uVar4;
      param_1[9] = uVar5;
      *(undefined8 *)(param_1 + 10) = *(undefined8 *)(param_2 + 10);
    }
  }
  param_1[0xc] = 0;
  uVar2 = param_2[0xc];
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (uVar2 != 0) {
    param_1[0xc] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0xf];
      uVar4 = param_2[0x10];
      uVar5 = param_2[0x11];
      param_1[0xe] = param_2[0xe];
      param_1[0xf] = uVar3;
      param_1[0x10] = uVar4;
      param_1[0x11] = uVar5;
      *(undefined8 *)(param_1 + 0x12) = *(undefined8 *)(param_2 + 0x12);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xe,param_1 + 0xe,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28707 ; VA 0x00c5abd0 ; FUN_00c5abd0 */

undefined4 * __thiscall FUN_00c5abd0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_0180bd31;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = 0;
  param_1[4] = 0;
  if (param_2[4] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[4] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[6] = 0;
  uVar2 = param_2[6];
  uStack_8 = 1;
  uStack_7 = 0;
  if (uVar2 != 0) {
    param_1[6] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 8,param_1 + 8,0);
    }
    else {
      uVar3 = param_2[9];
      uVar4 = param_2[10];
      uVar5 = param_2[0xb];
      param_1[8] = param_2[8];
      param_1[9] = uVar3;
      param_1[10] = uVar4;
      param_1[0xb] = uVar5;
      *(undefined8 *)(param_1 + 0xc) = *(undefined8 *)(param_2 + 0xc);
    }
  }
  param_1[0xe] = 0;
  uVar2 = param_2[0xe];
  _uStack_8 = CONCAT31(uStack_7,2);
  if (uVar2 != 0) {
    param_1[0xe] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0x11];
      uVar4 = param_2[0x12];
      uVar5 = param_2[0x13];
      param_1[0x10] = param_2[0x10];
      param_1[0x11] = uVar3;
      param_1[0x12] = uVar4;
      param_1[0x13] = uVar5;
      *(undefined8 *)(param_1 + 0x14) = *(undefined8 *)(param_2 + 0x14);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x10,param_1 + 0x10,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28708 ; VA 0x00c5ad00 ; FUN_00c5ad00 */

undefined4 * __thiscall
FUN_00c5ad00(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180bd8b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_00c58600();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::RemoteEvent,void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_00888530();
  param_1[9] = uVar2;
  puVar3 = (undefined4 *)param_1[0x10];
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088cbe0();
    iStack_e4 = 0;
    if (puVar3[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar3[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e0 = *puVar3;
    uStack_dc = puVar3[1];
    iStack_e4 = FUN_00630900();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cbe0();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(&uStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28709 ; VA 0x00c5aea0 ; FUN_00c5aea0 */

undefined4 * __thiscall
FUN_00c5aea0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10)

{
  undefined4 uVar1;
  undefined auStack_1e8 [432];
  undefined8 uStack_38;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_0180bdcc;
  pvStack_1c = ExceptionList;
  uStack_38 = param_7;
  ExceptionList = &pvStack_1c;
  puStack_30 = param_1;
  uVar1 = FUN_00c58700();
  FUN_009cb970(uVar1,param_3,param_6,uStack_38,param_8);
  param_1[0xd] = param_2;
  iStack_14 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::RemoteFunction,void___cdecl(int,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),class_rbx::remote_signal<void___cdecl(int,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_rbx::remote_signal<void___cdecl(int,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>_RBX::RemoteFunction::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_14._0_1_ = 1;
  FUN_0086e3d0(param_5);
  FUN_0088cbe0();
  FUN_00888740();
  iStack_14._0_1_ = 2;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00687810(auStack_1e8,&uStack_38,puStack_30);
  iStack_14._0_1_ = 3;
  if (param_1 + 10 != &uStack_2c) {
    FUN_0068a760();
    param_1[10] = uStack_2c;
    param_1[0xb] = uStack_28;
    param_1[0xc] = uStack_24;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
  }
  iStack_14._0_1_ = 4;
  FUN_0068a760();
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  FUN_016f32d1(auStack_1e8,0xd8,2,FUN_00688b10);
  param_1[0xe] = param_10;
  param_1[0xf] = param_9;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::RemoteFunction,void___cdecl(int,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),class_rbx::remote_signal<void___cdecl(int,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_rbx::remote_signal<void___cdecl(int,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>_RBX::RemoteFunction::*>
             ::vftable;
  ExceptionList = pvStack_1c;
  return param_1;
}



/* FUNCTION 28710 ; VA 0x00c5b020 ; FUN_00c5b020 */

undefined4 * __thiscall
FUN_00c5b020(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  piVar1 = param_4 + 1;
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_3;
  param_1[2] = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  param_1[3] = 0;
  param_1[4] = 0;
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  param_1[3] = param_5;
  param_1[4] = param_6;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 28711 ; VA 0x00c5b170 ; FUN_00c5b170 */

undefined4 * __fastcall FUN_00c5b170(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180beaa;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0089a650("RemoteFunction");
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::RemoteFunction,class_RBX::Instance>::vftable;
  uVar3 = FUN_00c58700();
  param_1[3] = uVar3;
  *param_1 = RBX::RemoteFunction::vftable;
  param_1[0x16] = 0;
  param_1[0x1e] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  uVar3 = DAT_01d6887c;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = uVar3;
  uStack_8._0_1_ = 8;
  uStack_8._1_3_ = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  uVar3 = FUN_00c5c200();
  param_1[0x32] = uVar3;
  param_1[0x34] = 0;
  uStack_8._0_1_ = 10;
  param_1[0x35] = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0xc;
  puVar4 = (undefined4 *)FUN_01674e20(0x1c);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00c5e1c0;
    puVar4[3] = _guard_check_icall;
    puVar4[4] = 0;
    puVar4[5] = param_1 + 0x2a;
    puVar4[6] = param_1;
  }
  FUN_016797d0(puVar4);
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 0xd;
  FUN_01675290(uVar3);
  uStack_8 = 10;
  if (puVar4 != (undefined4 *)0x0) {
    piVar1 = puVar4 + 1;
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(puVar4);
    }
  }
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0xf;
  puVar4 = (undefined4 *)FUN_01674e20(0x1c);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00c5e380;
    puVar4[3] = _guard_check_icall;
    puVar4[4] = 0;
    puVar4[5] = param_1 + 0x2c;
    puVar4[6] = param_1;
  }
  FUN_016797d0(puVar4);
  if (puVar4 == (undefined4 *)0x0) {
    piStack_18 = (int *)&DAT_00000004;
  }
  else {
    piStack_18 = puVar4 + 1;
    LOCK();
    *piStack_18 = *piStack_18 + 1;
    UNLOCK();
  }
  uStack_8 = 0x10;
  FUN_01675290(uVar3);
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    iVar2 = *piStack_18;
    *piStack_18 = *piStack_18 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(puVar4);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28712 ; VA 0x00c5b430 ; FUN_00c5b430 */

code * __fastcall FUN_00c5b430(int param_1)

{
  uint *puVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  code *pcVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar4 = *(uint *)(param_1 + 0x30);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar4 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar4 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar4 & 0xfffffffe))(param_1 + 0x38,param_1 + 0x38,2);
      }
    }
    *(undefined4 *)(param_1 + 0x30) = 0;
  }
  pcVar6 = *(code **)(param_1 + 0x10);
  uStack_8 = 1;
  if (pcVar6 != (code *)0x0) {
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      if (pcVar6 != (code *)0x0) {
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x18,param_1 + 0x18,2);
      }
    }
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  piVar5 = *(int **)(param_1 + 8);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar4 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar4 - 1;
    UNLOCK();
    if (uVar4 - 1 == 0) {
      pcVar6 = (code *)(**(code **)*piVar5)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 28713 ; VA 0x00c5b4e0 ; FUN_00c5b4e0 */

code * __fastcall FUN_00c5b4e0(int param_1)

{
  uint *puVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  code *pcVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar4 = *(uint *)(param_1 + 0x38);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar4 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar4 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar4 & 0xfffffffe))(param_1 + 0x40,param_1 + 0x40,2);
      }
    }
    *(undefined4 *)(param_1 + 0x38) = 0;
  }
  pcVar6 = *(code **)(param_1 + 0x18);
  uStack_8 = 1;
  if (pcVar6 != (code *)0x0) {
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      if (pcVar6 != (code *)0x0) {
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x20,param_1 + 0x20,2);
      }
    }
    *(undefined4 *)(param_1 + 0x18) = 0;
  }
  piVar5 = *(int **)(param_1 + 0x10);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar4 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar4 - 1;
    UNLOCK();
    if (uVar4 - 1 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      puVar1 = (uint *)(piVar5 + 2);
      uVar4 = *puVar1;
      pcVar6 = (code *)*puVar1;
      *puVar1 = uVar4 - 1;
      UNLOCK();
      if (uVar4 - 1 == 0) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = *(int **)(param_1 + 8);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar4 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar4 - 1;
    UNLOCK();
    if (uVar4 - 1 == 0) {
      pcVar6 = (code *)(**(code **)*piVar5)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 28714 ; VA 0x00c5b5c0 ; FUN_00c5b5c0 */

void __fastcall FUN_00c5b5c0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar2 = *(int *)(param_1 + 0x44);
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,8);
  }
  iVar2 = *(int *)(param_1 + 0x40);
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,8);
  }
  FUN_009cb8d0();
  return;
}



/* FUNCTION 28715 ; VA 0x00c5b660 ; FUN_00c5b660 */

void __fastcall FUN_00c5b660(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::RemoteEvent>::vftable;
  uVar1 = FUN_00c58600(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28716 ; VA 0x00c5b6a0 ; FUN_00c5b6a0 */

void __fastcall FUN_00c5b6a0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::RemoteFunction>::vftable;
  uVar1 = FUN_00c58700(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28717 ; VA 0x00c5b6e0 ; FUN_00c5b6e0 */

void FUN_00c5b6e0(void)

{
  FUN_00c0a180();
  FUN_016790b0();
  FUN_016790b0();
  return;
}



/* FUNCTION 28718 ; VA 0x00c5b700 ; FUN_00c5b700 */

void __fastcall FUN_00c5b700(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00c5c260(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28719 ; VA 0x00c5b760 ; thunk_FUN_006d2070 */

void __fastcall thunk_FUN_006d2070(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_006ce110(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar3 = param_1[2] - iVar1 & 0xffffffe0;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28720 ; VA 0x00c5b770 ; FUN_00c5b770 */

void __fastcall FUN_00c5b770(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017949a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0xd0);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  iVar3 = *(int *)(param_1 + 200);
  piVar1 = (int *)(param_1 + 200);
  uStack_8 = 1;
  FUN_00c5c260(*(undefined4 *)(iVar3 + 4));
  *(int *)(*piVar1 + 4) = iVar3;
  *(int *)*piVar1 = iVar3;
  *(int *)(*piVar1 + 8) = iVar3;
  *(undefined4 *)(param_1 + 0xcc) = 0;
  FUN_01674ea0(*piVar1,0x60);
  FUN_006d2070();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  uVar4 = *(uint *)(param_1 + 0x78);
  uStack_8 = 2;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      if (*(code **)(uVar4 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar4 & 0xfffffffe))(param_1 + 0x80,param_1 + 0x80,2);
      }
    }
    *(undefined4 *)(param_1 + 0x78) = 0;
  }
  uVar4 = *(uint *)(param_1 + 0x58);
  uStack_8 = 3;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      if (*(code **)(uVar4 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar4 & 0xfffffffe))(param_1 + 0x60,param_1 + 0x60,2);
      }
    }
    *(undefined4 *)(param_1 + 0x58) = 0;
  }
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28721 ; VA 0x00c5b8e0 ; FUN_00c5b8e0 */

undefined4 * __thiscall FUN_00c5b8e0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  uint auStack_70 [2];
  undefined auStack_68 [24];
  uint auStack_50 [2];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  uint auStack_30 [2];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180bee0;
  pvStack_10 = ExceptionList;
  iVar3 = param_2[1];
  ExceptionList = &pvStack_10;
  if (iVar3 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(iVar3 + 8) = *(int *)(iVar3 + 8) + 1;
    UNLOCK();
    iVar3 = param_2[1];
  }
  *param_1 = *param_2;
  piVar1 = (int *)param_1[1];
  param_1[1] = iVar3;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[2] + -1;
    piVar1[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  uVar2 = param_2[2];
  auStack_30[0] = 0;
  if (uVar2 != 0) {
    auStack_30[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,&uStack_28,0);
    }
    else {
      uStack_28 = param_2[4];
      uStack_24 = param_2[5];
      uStack_20 = param_2[6];
      uStack_1c = param_2[7];
      uStack_18 = *(undefined8 *)(param_2 + 8);
    }
  }
  if (param_1 + 2 != auStack_30) {
    auStack_70[0] = 0;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    FUN_005880d0(auStack_30);
    FUN_005880d0(param_1 + 2);
    FUN_005880d0(auStack_70);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (((auStack_70[0] != 0) && ((auStack_70[0] & 1) == 0)) &&
       (*(code **)(auStack_70[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_70[0] & 0xfffffffe))(auStack_68,auStack_68,2);
    }
  }
  uStack_8 = 3;
  if (((auStack_30[0] != 0) && ((auStack_30[0] & 1) == 0)) &&
     (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_30[0] & 0xfffffffe))(&uStack_28,&uStack_28,2);
  }
  uVar2 = param_2[10];
  uStack_8 = 0xffffffff;
  auStack_50[0] = 0;
  if (uVar2 != 0) {
    auStack_50[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xc,&uStack_48,0);
    }
    else {
      uStack_48 = param_2[0xc];
      uStack_44 = param_2[0xd];
      uStack_40 = param_2[0xe];
      uStack_3c = param_2[0xf];
      uStack_38 = *(undefined8 *)(param_2 + 0x10);
    }
  }
  if (param_1 + 10 != auStack_50) {
    auStack_70[0] = 0;
    uStack_8._0_1_ = 5;
    uStack_8._1_3_ = 0;
    FUN_005880d0(auStack_50);
    FUN_005880d0(param_1 + 10);
    FUN_005880d0(auStack_70);
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (auStack_70[0] != 0) {
      if (((auStack_70[0] & 1) == 0) && (*(code **)(auStack_70[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_70[0] & 0xfffffffe))(auStack_68,auStack_68,2);
      }
      auStack_70[0] = 0;
    }
  }
  uStack_8 = 7;
  if (((auStack_50[0] != 0) && ((auStack_50[0] & 1) == 0)) &&
     (*(code **)(auStack_50[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_50[0] & 0xfffffffe))(&uStack_48,&uStack_48,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28722 ; VA 0x00c5bae0 ; FUN_00c5bae0 */

void __fastcall FUN_00c5bae0(int param_1)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  int iStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b108;
  pvStack_10 = ExceptionList;
  uStack_40 = 0;
  uVar2 = *(uint *)(param_1 + 0x38);
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_40 = uVar2;
    if ((uVar2 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      iStack_4c = param_1 + 0x40;
      uStack_50 = 0xc5bb45;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_38 = *(undefined4 *)(param_1 + 0x40);
      uStack_34 = *(undefined4 *)(param_1 + 0x44);
      uStack_30 = *(undefined4 *)(param_1 + 0x48);
      uStack_2c = *(undefined4 *)(param_1 + 0x4c);
      uStack_28 = *(undefined8 *)(param_1 + 0x50);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uVar2 = *(uint *)(param_1 + 0x18);
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x20,&uStack_58,0);
    }
    else {
      uStack_58 = *(undefined4 *)(param_1 + 0x20);
      uStack_54 = *(undefined4 *)(param_1 + 0x24);
      uStack_50 = *(undefined4 *)(param_1 + 0x28);
      iStack_4c = *(int *)(param_1 + 0x2c);
      uStack_48 = *(ulonglong *)(param_1 + 0x30);
    }
  }
  if (*(int *)(param_1 + 0x10) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x10) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar3 = *(undefined4 *)(param_1 + 0xc);
  uVar4 = *(undefined4 *)(param_1 + 0x10);
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  FUN_00c60870(*(undefined4 *)(param_1 + 4),*(undefined4 *)(param_1 + 8),uVar3,uVar4);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28723 ; VA 0x00c5bc10 ; FUN_00c5bc10 */

/* WARNING: Removing unreachable block (ram,0x00c5bcba) */
/* WARNING: Removing unreachable block (ram,0x00c5bcc6) */
/* WARNING: Removing unreachable block (ram,0x00c5bcd4) */

void __thiscall FUN_00c5bc10(uint *param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  code *pcVar1;
  uint in_stack_0000002c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180bf18;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if (*param_1 == 0) {
    ExceptionList = &pvStack_10;
    FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0();
  }
  pcVar1 = *(code **)((*param_1 & 0xfffffffe) + 4);
  ExceptionList = &pvStack_10;
  FUN_005880d0();
  uStack_8._0_1_ = 4;
  FUN_005880d0(&param_4);
  uStack_8._0_1_ = 2;
  (*pcVar1)(param_1 + 2,param_2,param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))();
    }
    param_4 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28724 ; VA 0x00c5bd60 ; FUN_00c5bd60 */

/* WARNING: Removing unreachable block (ram,0x00c5be38) */
/* WARNING: Removing unreachable block (ram,0x00c5be41) */
/* WARNING: Removing unreachable block (ram,0x00c5be50) */
/* WARNING: Removing unreachable block (ram,0x00c5be5e) */
/* WARNING: Removing unreachable block (ram,0x00c5be67) */
/* WARNING: Removing unreachable block (ram,0x00c5be75) */

void __thiscall
FUN_00c5bd60(uint *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,uint param_6)

{
  code *pcVar1;
  uint in_stack_00000034;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180bf60;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  if (*param_1 == 0) {
    ExceptionList = &pvStack_10;
    FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0();
  }
  pcVar1 = *(code **)((*param_1 & 0xfffffffe) + 4);
  ExceptionList = &pvStack_10;
  FUN_005880d0();
  uStack_8._0_1_ = 5;
  FUN_005880d0(&param_6);
  uStack_8._0_1_ = 3;
  (*pcVar1)(param_1 + 2,param_2,param_3,param_4,param_5);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (param_6 != 0) {
    if (((param_6 & 1) == 0) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_6 & 0xfffffffe))();
    }
    param_6 = 0;
  }
  uStack_8 = 7;
  if (((in_stack_00000034 != 0) && ((in_stack_00000034 & 1) == 0)) &&
     (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000034 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28725 ; VA 0x00c5bf00 ; FUN_00c5bf00 */

/* WARNING: Removing unreachable block (ram,0x00c5bf52) */
/* WARNING: Removing unreachable block (ram,0x00c5bf62) */
/* WARNING: Removing unreachable block (ram,0x00c5bf68) */

void * __thiscall FUN_00c5bf00(int *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180bf88;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 28726 ; VA 0x00c5bfd6 ; Catch@00c5bfd6 */

undefined * Catch_00c5bfd6(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00c5bfe7;
}



/* FUNCTION 28727 ; VA 0x00c5c000 ; FUN_00c5c000 */

/* WARNING: Removing unreachable block (ram,0x00c5c052) */
/* WARNING: Removing unreachable block (ram,0x00c5c062) */
/* WARNING: Removing unreachable block (ram,0x00c5c068) */

void * __thiscall
FUN_00c5c000(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180bfc0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 4;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 28728 ; VA 0x00c5c107 ; Catch@00c5c107 */

undefined * Catch_00c5c107(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00c5c118;
}



/* FUNCTION 28729 ; VA 0x00c5c130 ; FUN_00c5c130 */

undefined4 __thiscall FUN_00c5c130(undefined4 param_1,byte param_2)

{
  FUN_00c5b5c0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 28730 ; VA 0x00c5c160 ; FUN_00c5c160 */

undefined4 __thiscall FUN_00c5c160(undefined4 param_1,byte param_2)

{
  FUN_00c0a180();
  FUN_016790b0();
  FUN_016790b0();
  FUN_00c0a180();
  FUN_016790b0();
  FUN_016790b0();
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xb4);
  }
  return param_1;
}



/* FUNCTION 28731 ; VA 0x00c5c1d0 ; FUN_00c5c1d0 */

undefined4 __thiscall FUN_00c5c1d0(undefined4 param_1,byte param_2)

{
  FUN_00c5b770();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xd8);
  }
  return param_1;
}



/* FUNCTION 28732 ; VA 0x00c5c200 ; FUN_00c5c200 */

void FUN_00c5c200(void)

{
  int iVar1;
  
  iVar1 = FUN_01674e20(0x60);
  *(int *)iVar1 = iVar1;
  *(int *)(iVar1 + 4) = iVar1;
  *(int *)(iVar1 + 8) = iVar1;
  *(undefined2 *)(iVar1 + 0xc) = 0x101;
  return;
}



/* FUNCTION 28733 ; VA 0x00c5c220 ; FUN_00c5c220 */

void __fastcall FUN_00c5c220(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x60);
  *puVar1 = *param_1;
  puVar1[1] = *param_1;
  puVar1[2] = *param_1;
  return;
}



/* FUNCTION 28734 ; VA 0x00c5c240 ; FUN_00c5c240 */

void FUN_00c5c240(undefined4 param_1)

{
  FUN_008e9ba0();
  FUN_01674ea0(param_1,0x60);
  return;
}



/* FUNCTION 28735 ; VA 0x00c5c260 ; FUN_00c5c260 */

void FUN_00c5c260(int *param_1)

{
  char cVar1;
  int *piVar2;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  while (cVar1 == '\0') {
    FUN_00c5c260(param_1[2]);
    piVar2 = (int *)*param_1;
    FUN_008e9ba0();
    FUN_01674ea0(param_1,0x60);
    param_1 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  return;
}



/* FUNCTION 28736 ; VA 0x00c5c2b0 ; FUN_00c5c2b0 */

void FUN_00c5c2b0(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 uint *param_5,uint *param_6)

{
  int *piVar1;
  uint uVar2;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  undefined8 uStack_a0;
  undefined4 uStack_98;
  undefined auStack_94 [32];
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_58;
  uint *puStack_54;
  uint *puStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cef48;
  pvStack_10 = ExceptionList;
  param_1 = CONCAT31(param_1._1_3_,DAT_01efdb10);
  uStack_48 = 0;
  uVar2 = *param_6;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_48 = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_50 = &uStack_40;
      uStack_4c = 0;
      puStack_54 = param_6 + 2;
      uStack_58 = 0xc5c32a;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_40 = param_6[2];
      uStack_3c = param_6[3];
      uStack_38 = param_6[4];
      uStack_34 = param_6[5];
      uStack_30 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uStack_6c = 0;
  uStack_98 = param_1;
  uVar2 = *param_5;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_5 + 2,&uStack_b0,0);
    }
    else {
      uStack_b0 = param_5[2];
      uStack_ac = param_5[3];
      uStack_a8 = param_5[4];
      uStack_a4 = param_5[5];
      uStack_a0 = *(undefined8 *)(param_5 + 6);
    }
  }
  FUN_008bfbf0(auStack_94,FUN_00c5a550);
  uStack_98 = 0xc5c39e;
  FUN_00960220();
  if (param_4[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_70 = *param_4;
  uStack_6c = param_4[1];
  uStack_8 = 0xffffffff;
  uStack_74 = 0xc5c3d5;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28737 ; VA 0x00c5c3f0 ; FUN_00c5c3f0 */

void FUN_00c5c3f0(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 undefined4 *param_5,uint *param_6,uint *param_7)

{
  int *piVar1;
  uint uVar2;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  undefined8 uStack_a0;
  undefined4 uStack_98;
  undefined auStack_94 [24];
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_58;
  uint *puStack_54;
  uint *puStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cef48;
  pvStack_10 = ExceptionList;
  param_1 = CONCAT31(param_1._1_3_,DAT_01efdb10);
  uStack_48 = 0;
  uVar2 = *param_7;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_48 = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_50 = &uStack_40;
      uStack_4c = 0;
      puStack_54 = param_7 + 2;
      uStack_58 = 0xc5c46a;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_40 = param_7[2];
      uStack_3c = param_7[3];
      uStack_38 = param_7[4];
      uStack_34 = param_7[5];
      uStack_30 = *(undefined8 *)(param_7 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uStack_6c = 0;
  uStack_98 = param_1;
  uVar2 = *param_6;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_6 + 2,&uStack_b0,0);
    }
    else {
      uStack_b0 = param_6[2];
      uStack_ac = param_6[3];
      uStack_a8 = param_6[4];
      uStack_a4 = param_6[5];
      uStack_a0 = *(undefined8 *)(param_6 + 6);
    }
  }
  FUN_008bfbf0(auStack_94,FUN_00c5a550);
  uStack_98 = 0xc5c4de;
  FUN_00960220();
  if (param_5[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_70 = *param_5;
  uStack_6c = param_5[1];
  if (param_4[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_78 = *param_4;
  uStack_74 = param_4[1];
  uStack_8 = 0xffffffff;
  uStack_7c = 0xc5c53f;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28738 ; VA 0x00c5c550 ; FUN_00c5c550 */

void FUN_00c5c550(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
                 undefined4 *param_10,ulonglong param_11,uint param_12,undefined4 param_13,
                 undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
                 undefined8 param_18)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  uint auStack_138 [2];
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 *puStack_124;
  ulonglong uStack_120;
  uint auStack_118 [2];
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 *puStack_104;
  undefined8 uStack_100;
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  int *piStack_e4;
  undefined *puStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180c20b;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  uStack_100 = CONCAT44(&iStack_1c,0xc5c580);
  ExceptionList = &pvStack_10;
  FUN_008c05f0();
  uStack_8._0_1_ = 4;
  uStack_100 = CONCAT44(0xc5c58c,(undefined4)uStack_100);
  uStack_f0 = FUN_0088cbe0();
  iStack_ec = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_e8 = param_3;
  piStack_e4 = param_4;
  uStack_100 = CONCAT44(0xc5c5d2,(undefined4)uStack_100);
  iStack_ec = FUN_00630900();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (*(int *)(iStack_1c + 8) == *(int *)(iStack_1c + 4)) {
    uStack_100 = CONCAT44(&uStack_f0,*(int *)(iStack_1c + 4));
    puStack_104 = (undefined4 *)0xc5c606;
    FUN_005ca4f0();
  }
  else {
    uStack_100 = CONCAT44(&uStack_f0,0xc5c5f5);
    FUN_005caf00();
    *(int *)(iStack_1c + 4) = *(int *)(iStack_1c + 4) + 0xd0;
  }
  uStack_8._0_1_ = 6;
  if (iStack_ec != 0) {
    uStack_100 = CONCAT44(&uStack_e8,0xc5c620);
    (**(code **)(iStack_ec + 8))();
  }
  puStack_20 = (undefined *)auStack_118;
  puStack_14 = (undefined *)auStack_118;
  uStack_8._0_1_ = 4;
  auStack_118[0] = 0;
  puVar3 = auStack_118;
  if (param_12 != 0) {
    auStack_118[0] = param_12;
    if ((param_12 & 1) == 0) {
      uStack_120 = ZEXT48(&uStack_110);
      puStack_124 = &param_14;
      uStack_128 = 0xc5c66b;
      (**(code **)(param_12 & 0xfffffffe))();
      puVar3 = (uint *)puStack_20;
    }
    else {
      uStack_110 = param_14;
      uStack_10c = param_15;
      uStack_108 = param_16;
      puStack_104 = (undefined4 *)param_17;
      uStack_100 = param_18;
      puVar3 = auStack_118;
    }
  }
  puStack_20 = (undefined *)puVar3;
  puStack_14 = (undefined *)auStack_138;
  uStack_8._0_1_ = 7;
  auStack_138[0] = 0;
  puVar3 = auStack_138;
  if (param_5 != 0) {
    auStack_138[0] = param_5;
    if ((param_5 & 1) == 0) {
      (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_130,0);
      puVar3 = (uint *)puStack_14;
    }
    else {
      uStack_130 = param_7;
      uStack_12c = param_8;
      uStack_128 = param_9;
      puStack_124 = param_10;
      uStack_120 = param_11;
      puVar3 = auStack_138;
    }
  }
  puStack_14 = (undefined *)puVar3;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piStack_18[1] = piStack_18[1] + 1;
    UNLOCK();
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00f50180(param_1,param_2,iStack_1c,piStack_18);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_100 = CONCAT44(0xc5c722,(undefined4)uStack_100);
      (**(code **)*piStack_18)();
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_100 = CONCAT44(0xc5c732,(undefined4)uStack_100);
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_100 = CONCAT44(0xc5c748,(undefined4)uStack_100);
      (**(code **)*param_2)();
      LOCK();
      iVar2 = param_2[2] + -1;
      param_2[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_100 = CONCAT44(0xc5c758,(undefined4)uStack_100);
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_100 = CONCAT44(0xc5c76e,(undefined4)uStack_100);
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_100 = CONCAT44(0xc5c77d,(undefined4)uStack_100);
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    puStack_104 = &param_7;
    uStack_100 = CONCAT44(2,puStack_104);
    uStack_108 = 0xc5c79e;
    (**(code **)(param_5 & 0xfffffffe))();
  }
  uStack_8 = 9;
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    puStack_104 = &param_14;
    uStack_100 = CONCAT44(2,puStack_104);
    uStack_108 = 0xc5c7cc;
    (**(code **)(param_12 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28739 ; VA 0x00c5c7e0 ; FUN_00c5c7e0 */

void FUN_00c5c7e0(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4,undefined4 param_5
                 ,int *param_6,uint param_7,undefined4 param_8,undefined4 param_9,
                 undefined4 param_10,undefined4 param_11,undefined4 *param_12,ulonglong param_13,
                 uint param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
                 undefined4 param_18,undefined4 param_19,undefined8 param_20)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  uint auStack_138 [2];
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 *puStack_124;
  ulonglong uStack_120;
  uint auStack_118 [2];
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 *puStack_104;
  undefined8 uStack_100;
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  int *piStack_e4;
  undefined *puStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180c26e;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  uStack_100 = CONCAT44(&iStack_1c,0xc5c810);
  ExceptionList = &pvStack_10;
  FUN_008c05f0();
  uStack_8._0_1_ = 5;
  uStack_100 = CONCAT44(0xc5c81c,(undefined4)uStack_100);
  uStack_f0 = FUN_0088cdc0();
  iStack_ec = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_e8 = param_3;
  piStack_e4 = param_4;
  uStack_100 = CONCAT44(0xc5c862,(undefined4)uStack_100);
  iStack_ec = FUN_006309e0();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (*(int *)(iStack_1c + 8) == *(int *)(iStack_1c + 4)) {
    uStack_100 = CONCAT44(&uStack_f0,*(int *)(iStack_1c + 4));
    puStack_104 = (undefined4 *)0xc5c896;
    FUN_005ca4f0();
  }
  else {
    uStack_100 = CONCAT44(&uStack_f0,0xc5c885);
    FUN_005caf00();
    *(int *)(iStack_1c + 4) = *(int *)(iStack_1c + 4) + 0xd0;
  }
  uStack_8._0_1_ = 7;
  if (iStack_ec != 0) {
    uStack_100 = CONCAT44(&uStack_e8,0xc5c8b0);
    (**(code **)(iStack_ec + 8))();
  }
  uStack_8._0_1_ = 5;
  uStack_100 = CONCAT44(0xc5c8bc,(undefined4)uStack_100);
  uStack_f0 = FUN_0088cbe0();
  iStack_ec = 0;
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  uStack_e8 = param_5;
  piStack_e4 = param_6;
  uStack_100 = CONCAT44(0xc5c902,(undefined4)uStack_100);
  iStack_ec = FUN_00630900();
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (*(int *)(iStack_1c + 8) == *(int *)(iStack_1c + 4)) {
    uStack_100 = CONCAT44(&uStack_f0,*(int *)(iStack_1c + 4));
    puStack_104 = (undefined4 *)0xc5c933;
    FUN_005ca4f0();
  }
  else {
    uStack_100 = CONCAT44(&uStack_f0,0xc5c922);
    FUN_005caf00();
    *(int *)(iStack_1c + 4) = *(int *)(iStack_1c + 4) + 0xd0;
  }
  uStack_8._0_1_ = 9;
  if (iStack_ec != 0) {
    uStack_100 = CONCAT44(&uStack_e8,0xc5c94d);
    (**(code **)(iStack_ec + 8))();
  }
  puStack_20 = (undefined *)auStack_118;
  puStack_14 = (undefined *)auStack_118;
  uStack_8._0_1_ = 5;
  auStack_118[0] = 0;
  puVar3 = auStack_118;
  if (param_14 != 0) {
    auStack_118[0] = param_14;
    if ((param_14 & 1) == 0) {
      uStack_120 = ZEXT48(&uStack_110);
      puStack_124 = &param_16;
      uStack_128 = 0xc5c998;
      (**(code **)(param_14 & 0xfffffffe))();
      puVar3 = (uint *)puStack_20;
    }
    else {
      uStack_110 = param_16;
      uStack_10c = param_17;
      uStack_108 = param_18;
      puStack_104 = (undefined4 *)param_19;
      uStack_100 = param_20;
      puVar3 = auStack_118;
    }
  }
  puStack_20 = (undefined *)puVar3;
  puStack_14 = (undefined *)auStack_138;
  uStack_8._0_1_ = 10;
  auStack_138[0] = 0;
  puVar3 = auStack_138;
  if (param_7 != 0) {
    auStack_138[0] = param_7;
    if ((param_7 & 1) == 0) {
      (**(code **)(param_7 & 0xfffffffe))(&param_9,&uStack_130,0);
      puVar3 = (uint *)puStack_14;
    }
    else {
      uStack_130 = param_9;
      uStack_12c = param_10;
      uStack_128 = param_11;
      puStack_124 = param_12;
      uStack_120 = param_13;
      puVar3 = auStack_138;
    }
  }
  puStack_14 = (undefined *)puVar3;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piStack_18[1] = piStack_18[1] + 1;
    UNLOCK();
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_00f50180(param_1,param_2,iStack_1c,piStack_18);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_100 = CONCAT44(0xc5ca4f,(undefined4)uStack_100);
      (**(code **)*piStack_18)();
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_100 = CONCAT44(0xc5ca5f,(undefined4)uStack_100);
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_100 = CONCAT44(0xc5ca75,(undefined4)uStack_100);
      (**(code **)*param_2)();
      LOCK();
      iVar2 = param_2[2] + -1;
      param_2[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_100 = CONCAT44(0xc5ca85,(undefined4)uStack_100);
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_100 = CONCAT44(0xc5ca9b,(undefined4)uStack_100);
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_100 = CONCAT44(0xc5caab,(undefined4)uStack_100);
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_100 = CONCAT44(0xc5cac1,(undefined4)uStack_100);
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_100 = CONCAT44(0xc5cad0,(undefined4)uStack_100);
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  if (((param_7 != 0) && ((param_7 & 1) == 0)) && (*(code **)(param_7 & 0xfffffffe) != (code *)0x0))
  {
    puStack_104 = &param_9;
    uStack_100 = CONCAT44(2,puStack_104);
    uStack_108 = 0xc5caf1;
    (**(code **)(param_7 & 0xfffffffe))();
  }
  uStack_8 = 0xc;
  if (((param_14 != 0) && ((param_14 & 1) == 0)) &&
     (*(code **)(param_14 & 0xfffffffe) != (code *)0x0)) {
    puStack_104 = &param_16;
    uStack_100 = CONCAT44(2,puStack_104);
    uStack_108 = 0xc5cb1f;
    (**(code **)(param_14 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28740 ; VA 0x00c5cb40 ; FUN_00c5cb40 */

/* WARNING: Removing unreachable block (ram,0x00c5cbbf) */
/* WARNING: Removing unreachable block (ram,0x00c5cbdb) */
/* WARNING: Removing unreachable block (ram,0x00c5cbc7) */
/* WARNING: Removing unreachable block (ram,0x00c5cc76) */
/* WARNING: Removing unreachable block (ram,0x00c5cc7a) */
/* WARNING: Removing unreachable block (ram,0x00c5cc83) */

void __thiscall FUN_00c5cb40(int param_1,int param_2)

{
  code *pcVar1;
  uint uVar2;
  uint *puVar3;
  uint auStack_54 [2];
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180c298;
  pvStack_10 = ExceptionList;
  puVar3 = (uint *)(*(int *)(param_1 + 0x38) + param_2);
  uStack_14 = *(undefined4 *)(param_1 + 0x44);
  pcVar1 = *(code **)(param_1 + 0x40);
  uStack_8 = 0;
  uVar2 = *puVar3;
  auStack_54[0] = 0;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    auStack_54[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))(puVar3 + 2,&uStack_4c,0);
    }
    else {
      uStack_4c = puVar3[2];
      uStack_48 = puVar3[3];
      uStack_44 = puVar3[4];
      uStack_40 = puVar3[5];
      uStack_3c = *(undefined8 *)(puVar3 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_34 = 0;
  uStack_8._0_1_ = 2;
  FUN_00c63020(puVar3);
  uStack_8._0_1_ = 3;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
    }
    uStack_34 = 0;
  }
  uStack_8._0_1_ = 1;
  if (pcVar1 != (code *)0x0) {
    (*pcVar1)(auStack_54);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((auStack_54[0] != 0) && ((auStack_54[0] & 1) == 0)) &&
     (*(code **)(auStack_54[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_54[0] & 0xfffffffe))(&uStack_4c,&uStack_4c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28741 ; VA 0x00c5cca0 ; FUN_00c5cca0 */

/* WARNING: Removing unreachable block (ram,0x00c5cd1f) */
/* WARNING: Removing unreachable block (ram,0x00c5cd3b) */
/* WARNING: Removing unreachable block (ram,0x00c5cd27) */
/* WARNING: Removing unreachable block (ram,0x00c5cdd6) */
/* WARNING: Removing unreachable block (ram,0x00c5cdda) */
/* WARNING: Removing unreachable block (ram,0x00c5cde3) */

void __thiscall FUN_00c5cca0(int param_1,int param_2)

{
  code *pcVar1;
  uint uVar2;
  uint *puVar3;
  uint auStack_54 [2];
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180c2c8;
  pvStack_10 = ExceptionList;
  puVar3 = (uint *)(*(int *)(param_1 + 0x38) + param_2);
  uStack_14 = *(undefined4 *)(param_1 + 0x44);
  pcVar1 = *(code **)(param_1 + 0x40);
  uStack_8 = 0;
  uVar2 = *puVar3;
  auStack_54[0] = 0;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    auStack_54[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))(puVar3 + 2,&uStack_4c,0);
    }
    else {
      uStack_4c = puVar3[2];
      uStack_48 = puVar3[3];
      uStack_44 = puVar3[4];
      uStack_40 = puVar3[5];
      uStack_3c = *(undefined8 *)(puVar3 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_34 = 0;
  uStack_8._0_1_ = 2;
  FUN_00c630b0(puVar3);
  uStack_8._0_1_ = 3;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
    }
    uStack_34 = 0;
  }
  uStack_8._0_1_ = 1;
  if (pcVar1 != (code *)0x0) {
    (*pcVar1)(auStack_54);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((auStack_54[0] != 0) && ((auStack_54[0] & 1) == 0)) &&
     (*(code **)(auStack_54[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_54[0] & 0xfffffffe))(&uStack_4c,&uStack_4c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28742 ; VA 0x00c5ce00 ; FUN_00c5ce00 */

undefined4 * __thiscall
FUN_00c5ce00(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180c32a;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  ExceptionList = &pvStack_10;
  iVar2 = (**(code **)(param_1 + 0x38))(1);
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_006eccd0();
  uStack_8 = 3;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 4;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b218c0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + 4;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 5;
  FUN_01675290(uVar3);
  uStack_8 = 2;
  FUN_00c62030();
  *(undefined4 *)(iVar2 + 0x2c) = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28743 ; VA 0x00c5cfe0 ; FUN_00c5cfe0 */

undefined4 * __thiscall
FUN_00c5cfe0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180c38a;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  ExceptionList = &pvStack_10;
  iVar2 = (**(code **)(param_1 + 0x38))(1);
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_006eccd0();
  uStack_8 = 3;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 4;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00c5dd10;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + 4;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 5;
  FUN_01675290(uVar3);
  uStack_8 = 2;
  FUN_00c62030();
  *(undefined4 *)(iVar2 + 0x2c) = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28744 ; VA 0x00c5d1c0 ; FUN_00c5d1c0 */

undefined4 * __thiscall
FUN_00c5d1c0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180c3d1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00c5dee0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28745 ; VA 0x00c5d370 ; FUN_00c5d370 */

undefined4 * __thiscall
FUN_00c5d370(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180c411;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00c5e040;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28746 ; VA 0x00c5d520 ; FUN_00c5d520 */

undefined4 __thiscall FUN_00c5d520(int param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  
  puVar1 = *(undefined4 **)(param_1 + 200);
  puVar2 = (undefined4 *)puVar1[1];
  puVar5 = puVar1;
  if (*(char *)((int)puVar2 + 0xd) == '\0') {
    do {
      if ((int)puVar2[4] < param_2) {
        puVar3 = (undefined4 *)puVar2[2];
      }
      else {
        puVar3 = (undefined4 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((int)puVar3 + 0xd) == '\0');
    if ((puVar5 != puVar1) && ((int)puVar5[4] <= param_2)) goto LAB_00c5d55f;
  }
  puVar5 = puVar1;
LAB_00c5d55f:
  if (puVar5 != puVar1) {
    FUN_00c5b8e0(puVar5 + 6);
    uVar4 = FUN_00553830(puVar5);
    FUN_008e9ba0();
    FUN_01674ea0(uVar4,0x60);
    return 1;
  }
  return 0;
}



/* FUNCTION 28747 ; VA 0x00c5d5a0 ; FUN_00c5d5a0 */

undefined4 * FUN_00c5d5a0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c59930(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 28748 ; VA 0x00c5d610 ; FUN_00c5d610 */

undefined4 * FUN_00c5d610(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c59b20(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 28749 ; VA 0x00c5d680 ; FUN_00c5d680 */

uint __thiscall FUN_00c5d680(int param_1,undefined4 *param_2,uint *param_3,uint *param_4)

{
  uint uVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 uStack_5c;
  int iStack_58;
  uint uStack_54;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined8 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180c438;
  pvStack_10 = ExceptionList;
  iVar3 = *(int *)(param_1 + 0xd4);
  if (iVar3 == 0x7fffffff) {
    iVar3 = 0;
  }
  uStack_14 = iVar3 + 1;
  ExceptionList = &pvStack_10;
  *(uint *)(param_1 + 0xd4) = uStack_14;
  iStack_58 = param_2[1];
  if (iStack_58 != 0) {
    LOCK();
    *(int *)(iStack_58 + 8) = *(int *)(iStack_58 + 8) + 1;
    UNLOCK();
    iStack_58 = param_2[1];
  }
  uStack_5c = *param_2;
  uStack_8 = 0;
  uStack_54 = 0;
  uVar1 = *param_3;
  if (uVar1 != 0) {
    uStack_54 = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_3 + 2,&uStack_4c,0);
    }
    else {
      uStack_4c = param_3[2];
      uStack_48 = param_3[3];
      uStack_44 = param_3[4];
      uStack_40 = param_3[5];
      uStack_3c = *(undefined8 *)(param_3 + 6);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_34 = 0;
  uVar1 = *param_4;
  if (uVar1 != 0) {
    uStack_34 = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_4 + 2,&uStack_2c,0);
    }
    else {
      uStack_2c = param_4[2];
      uStack_28 = param_4[3];
      uStack_24 = param_4[4];
      uStack_20 = param_4[5];
      uStack_1c = *(undefined8 *)(param_4 + 6);
    }
  }
  puVar2 = *(undefined4 **)(param_1 + 200);
  uStack_8 = 2;
  puVar4 = (undefined4 *)puVar2[1];
  puVar6 = puVar2;
  if (*(char *)((int)puVar2[1] + 0xd) == '\0') {
    do {
      if ((int)puVar4[4] < (int)uStack_14) {
        puVar5 = (undefined4 *)puVar4[2];
      }
      else {
        puVar5 = (undefined4 *)*puVar4;
        puVar6 = puVar4;
      }
      puVar4 = puVar5;
    } while (*(char *)((int)puVar5 + 0xd) == '\0');
    if ((puVar6 != puVar2) && ((int)puVar6[4] <= (int)uStack_14)) goto LAB_00c5d7e3;
  }
  param_3 = &uStack_14;
  iVar3 = FUN_00c58800(&DAT_018bdeda,&param_3,(int)&param_2 + 3);
  FUN_00c58c50(&param_2,puVar6,iVar3 + 0x10,iVar3);
LAB_00c5d7e3:
  FUN_00c5b8e0(&uStack_5c);
  uVar1 = uStack_14;
  FUN_008e9ba0();
  ExceptionList = pvStack_10;
  return uVar1;
}


