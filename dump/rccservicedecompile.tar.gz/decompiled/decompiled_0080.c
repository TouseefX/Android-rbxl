/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 20000 ; VA 0x00a16a40 ; FUN_00a16a40 */

void FUN_00a16a40(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00a149f0(param_2,param_3);
  return;
}



/* FUNCTION 20001 ; VA 0x00a16a60 ; FUN_00a16a60 */

void FUN_00a16a60(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1dc8864);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_86ba71023c993c276ae4db42e1031cde>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 20002 ; VA 0x00a16ac0 ; FUN_00a16ac0 */

void FUN_00a16ac0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      iVar2 = FUN_01674e20(0x20);
      if (iVar2 != 0) {
        iVar3 = FUN_00a14270(iVar3);
        *param_2 = iVar3;
        return;
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        piVar1 = *(int **)(iVar3 + 4);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        FUN_01674ea0(iVar3,0x20);
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dc87f4);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        return;
      }
      *param_2 = 0;
      return;
    }
  }
  *param_2 = (int)&<lambda_8db1fa4d86fd27c9b807ae4d224a979a>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 20003 ; VA 0x00a16ba0 ; FUN_00a16ba0 */

int * FUN_00a16ba0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a16c57. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a16bde. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc874c);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_af0dcc3c9d992b99bed7adb66d4734da>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 20004 ; VA 0x00a16c70 ; FUN_00a16c70 */

int * FUN_00a16c70(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a16d27. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a16cae. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc8784);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_c83a6d41cd1dd5b7486e11ddb5fce6de>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 20005 ; VA 0x00a16d40 ; FUN_00a16d40 */

int * FUN_00a16d40(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      param_2[4] = param_1[4];
      piVar3 = (int *)param_1[5];
      param_2[5] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a16e07. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a16d7e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc8714);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_e8a0f22da9461ee8e5bf5badd470a6cd>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 20006 ; VA 0x00a16e20 ; FUN_00a16e20 */

int * FUN_00a16e20(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      param_2[3] = 0;
      param_2[4] = 0;
      if (param_1[4] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[4] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[3] = param_1[3];
      piVar3 = (int *)param_1[4];
      param_2[4] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[4];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a16f0e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[4];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a16e76. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc882c);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_ea6b76bad24b9ee8dcdc2a0d27b4dc30>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 20007 ; VA 0x00a16f30 ; FUN_00a16f30 */

int * FUN_00a16f30(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a16fe7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a16f6e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc87bc);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_fc6589e092bf3854e40fd9b0bb8a0119>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 20008 ; VA 0x00a17010 ; FUN_00a17010 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_00a17010(int *param_1,int *param_2,char param_3,char *param_4,int param_5)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  char *pcVar17;
  int *piVar18;
  undefined uVar19;
  char cVar20;
  int iVar21;
  int *piVar22;
  undefined4 *puVar23;
  undefined4 uVar24;
  float *pfVar25;
  int iVar26;
  int **ppiVar27;
  float fVar28;
  int *piVar29;
  uint uVar30;
  undefined4 ****ppppuVar31;
  uint uVar32;
  float10 fVar33;
  float fVar34;
  float fVar35;
  float fStack_144;
  float fStack_140;
  float fStack_13c;
  float fStack_138;
  float fStack_134;
  float fStack_130;
  float fStack_12c;
  float fStack_128;
  float fStack_124;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  float fStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  int *piStack_ec;
  undefined4 uStack_e8;
  int *piStack_e4;
  int *piStack_e0;
  int *piStack_dc;
  int *piStack_d8;
  float afStack_d4 [4];
  float fStack_c4;
  float fStack_c0;
  float fStack_bc;
  float fStack_b8;
  float fStack_b4;
  undefined8 uStack_b0;
  float fStack_a8;
  undefined4 ***apppuStack_a4 [3];
  undefined4 uStack_98;
  int *piStack_94;
  int *piStack_90;
  int *piStack_8c;
  int *piStack_88;
  undefined auStack_84 [12];
  uint uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 uStack_68;
  undefined auStack_60 [12];
  uint uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  int *piStack_3c;
  int *piStack_38;
  int *piStack_34;
  int *piStack_30;
  float fStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017db612;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  iStack_8 = 0;
  fVar28 = (float)param_1[3];
  ExceptionList = &pvStack_10;
  fStack_2c = fVar28;
  iVar21 = FUN_00c391f0();
  if ((uint)*(ushort *)(iVar21 + 0x1da) <
      (uint)*(ushort *)((int)fVar28 + 0x1d8) - (uint)*(ushort *)(iVar21 + 0x1d8)) {
    piStack_24 = (int *)0x0;
    ppiVar27 = &piStack_28;
    uVar30 = 0x10;
    piVar22 = (int *)0x0;
  }
  else {
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    piStack_38 = param_2;
    ppiVar27 = &piStack_3c;
    uVar30 = 8;
    piVar22 = param_1;
  }
  piStack_d8 = ppiVar27[1];
  piStack_88 = piStack_d8;
  *ppiVar27 = (int *)0x0;
  ppiVar27[1] = (int *)0x0;
  piStack_14 = (int *)(uVar30 | 0x20);
  piStack_dc = piVar22;
  if (((uVar30 & 0x10) != 0) &&
     (piStack_14 = (int *)(uVar30 & 0xffffffef | 0x20), piStack_24 != (int *)0x0)) {
    LOCK();
    iVar21 = piStack_24[1] + -1;
    piStack_24[1] = iVar21;
    UNLOCK();
    if (iVar21 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar21 = piStack_24[2] + -1;
      piStack_24[2] = iVar21;
      UNLOCK();
      if (iVar21 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if ((((uint)piStack_14 & 8) != 0) &&
     (piStack_14 = (int *)((uint)piStack_14 & 0xfffffff7), piStack_38 != (int *)0x0)) {
    LOCK();
    iVar21 = piStack_38[1] + -1;
    piStack_38[1] = iVar21;
    UNLOCK();
    if (iVar21 == 0) {
      (**(code **)*piStack_38)();
      LOCK();
      iVar21 = piStack_38[2] + -1;
      piStack_38[2] = iVar21;
      UNLOCK();
      if (iVar21 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
  }
  iStack_8._0_1_ = 1;
  if (piVar22 == (int *)0x0) {
    if ((param_1 == (int *)0x0) ||
       (iVar21 = param_1[3], iVar26 = FUN_00b63e30(),
       (uint)*(ushort *)(iVar26 + 0x1da) <
       (uint)*(ushort *)(iVar21 + 0x1d8) - (uint)*(ushort *)(iVar26 + 0x1d8))) {
      ppiVar27 = &piStack_28;
      uVar30 = (uint)piStack_14 | 0x80;
      piStack_24 = (int *)0x0;
      piVar22 = (int *)0x0;
    }
    else {
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[1] = param_2[1] + 1;
        UNLOCK();
      }
      ppiVar27 = &piStack_3c;
      piStack_38 = param_2;
      uVar30 = (uint)piStack_14 | 0x40;
      piVar22 = param_1;
    }
    piStack_e0 = ppiVar27[1];
    piStack_20 = piStack_e0;
    *ppiVar27 = (int *)0x0;
    ppiVar27[1] = (int *)0x0;
    piStack_14 = (int *)(uVar30 | 0x100);
    piStack_e4 = piVar22;
    if (((char)uVar30 < '\0') &&
       (piStack_14 = (int *)(uVar30 & 0xffffff7f | 0x100), piStack_24 != (int *)0x0)) {
      LOCK();
      iVar21 = piStack_24[1] + -1;
      piStack_24[1] = iVar21;
      UNLOCK();
      if (iVar21 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar21 = piStack_24[2] + -1;
        piStack_24[2] = iVar21;
        UNLOCK();
        if (iVar21 == 0) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    if ((((uint)piStack_14 & 0x40) != 0) &&
       (piStack_14 = (int *)((uint)piStack_14 & 0xffffffbf), piStack_38 != (int *)0x0)) {
      LOCK();
      iVar21 = piStack_38[1] + -1;
      piStack_38[1] = iVar21;
      UNLOCK();
      if (iVar21 == 0) {
        (**(code **)*piStack_38)();
        LOCK();
        iVar21 = piStack_38[2] + -1;
        piStack_38[2] = iVar21;
        UNLOCK();
        if (iVar21 == 0) {
          (**(code **)(*piStack_38 + 4))();
        }
      }
    }
    iStack_8._0_1_ = 2;
    if (piVar22 == (int *)0x0) {
      if ((param_1 == (int *)0x0) ||
         (iVar21 = param_1[3], iVar26 = FUN_00aff8c0(),
         (uint)*(ushort *)(iVar26 + 0x1da) <
         (uint)*(ushort *)(iVar21 + 0x1d8) - (uint)*(ushort *)(iVar26 + 0x1d8))) {
        ppiVar27 = &piStack_28;
        uVar30 = (uint)piStack_14 | 0x400;
        piStack_24 = (int *)0x0;
        piStack_18 = (int *)0x0;
      }
      else {
        piStack_18 = param_1;
        if (param_2 != (int *)0x0) {
          LOCK();
          param_2[1] = param_2[1] + 1;
          UNLOCK();
        }
        ppiVar27 = &piStack_34;
        piStack_30 = param_2;
        uVar30 = (uint)piStack_14 | 0x200;
      }
      piStack_94 = piStack_18;
      piStack_38 = ppiVar27[1];
      piStack_90 = ppiVar27[1];
      *ppiVar27 = (int *)0x0;
      ppiVar27[1] = (int *)0x0;
      piVar22 = piStack_24;
      piStack_14 = (int *)(uVar30 | 0x800);
      if (((uVar30 & 0x400) != 0) &&
         (piStack_14 = (int *)(uVar30 & 0xfffffbff | 0x800), piStack_24 != (int *)0x0)) {
        LOCK();
        iVar21 = piStack_24[1] + -1;
        piStack_24[1] = iVar21;
        UNLOCK();
        if (iVar21 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          piVar29 = piVar22 + 2;
          iVar21 = *piVar29 + -1;
          *piVar29 = iVar21;
          UNLOCK();
          if (iVar21 == 0) {
            (**(code **)(*piVar22 + 4))();
          }
        }
      }
      piVar22 = piStack_30;
      if ((((uint)piStack_14 & 0x200) != 0) &&
         (piStack_14 = (int *)((uint)piStack_14 & 0xfffffdff), piStack_30 != (int *)0x0)) {
        LOCK();
        iVar21 = piStack_30[1] + -1;
        piStack_30[1] = iVar21;
        UNLOCK();
        if (iVar21 == 0) {
          (**(code **)*piStack_30)();
          LOCK();
          piVar29 = piVar22 + 2;
          iVar21 = *piVar29 + -1;
          *piVar29 = iVar21;
          UNLOCK();
          if (iVar21 == 0) {
            (**(code **)(*piVar22 + 4))();
          }
        }
      }
      pcVar17 = param_4;
      iStack_8 = CONCAT31(iStack_8._1_3_,4);
      if (piStack_18 == (int *)0x0) {
        if ((param_1 == (int *)0x0) ||
           (iVar21 = param_1[3], iVar26 = FUN_00ae2430(),
           (uint)*(ushort *)(iVar26 + 0x1da) <
           (uint)*(ushort *)(iVar21 + 0x1d8) - (uint)*(ushort *)(iVar26 + 0x1d8))) {
          ppiVar27 = (int **)&uStack_68;
          uVar30 = (uint)piStack_14 | 0x80000;
          uStack_68 = uStack_68 & 0xffffffff;
          piStack_18 = (int *)0x0;
        }
        else {
          piStack_18 = param_1;
          if (param_2 != (int *)0x0) {
            LOCK();
            param_2[1] = param_2[1] + 1;
            UNLOCK();
          }
          ppiVar27 = &piStack_34;
          piStack_30 = param_2;
          uVar30 = (uint)piStack_14 | 0x40000;
        }
        uStack_44 = CONCAT44(ppiVar27[1],piStack_18);
        *ppiVar27 = (int *)0x0;
        ppiVar27[1] = (int *)0x0;
        piStack_14 = (int *)(uVar30 | 0x100000);
        if ((uVar30 & 0x80000) != 0) {
          piVar22 = uStack_68._4_4_;
          piStack_14 = (int *)(uVar30 & 0xfff7ffff | 0x100000);
          if (uStack_68._4_4_ != (int *)0x0) {
            LOCK();
            iVar21 = uStack_68._4_4_[1] + -1;
            uStack_68._4_4_[1] = iVar21;
            UNLOCK();
            if (iVar21 == 0) {
              (**(code **)*uStack_68._4_4_)();
              LOCK();
              piVar29 = piVar22 + 2;
              iVar21 = *piVar29 + -1;
              *piVar29 = iVar21;
              UNLOCK();
              if (iVar21 == 0) {
                (**(code **)(*piVar22 + 4))();
              }
            }
          }
        }
        piVar22 = piStack_30;
        if ((((uint)piStack_14 & 0x40000) != 0) &&
           (piStack_14 = (int *)((uint)piStack_14 & 0xfffbffff), piStack_30 != (int *)0x0)) {
          LOCK();
          iVar21 = piStack_30[1] + -1;
          piStack_30[1] = iVar21;
          UNLOCK();
          if (iVar21 == 0) {
            (**(code **)*piStack_30)();
            LOCK();
            piVar29 = piVar22 + 2;
            iVar21 = *piVar29 + -1;
            *piVar29 = iVar21;
            UNLOCK();
            if (iVar21 == 0) {
              (**(code **)(*piVar22 + 4))();
            }
          }
        }
        iStack_8._0_1_ = 0xb;
        if (piStack_18 == (int *)0x0) {
          if ((param_1 == (int *)0x0) ||
             (iVar21 = param_1[3], iVar26 = FUN_00c6de80(),
             (uint)*(ushort *)(iVar26 + 0x1da) <
             (uint)*(ushort *)(iVar21 + 0x1d8) - (uint)*(ushort *)(iVar26 + 0x1d8))) {
            ppiVar27 = (int **)&uStack_68;
            uVar30 = (uint)piStack_14 | 0x400000;
            uStack_68 = uStack_68 & 0xffffffff;
            piStack_18 = (int *)0x0;
          }
          else {
            piStack_18 = param_1;
            if (param_2 != (int *)0x0) {
              LOCK();
              param_2[1] = param_2[1] + 1;
              UNLOCK();
            }
            piStack_30 = param_2;
            ppiVar27 = &piStack_34;
            uVar30 = (uint)piStack_14 | 0x200000;
          }
          piStack_14 = (int *)(uVar30 | 0x800000);
          piStack_28 = piStack_18;
          piStack_24 = ppiVar27[1];
          *ppiVar27 = (int *)0x0;
          ppiVar27[1] = (int *)0x0;
          if ((uVar30 & 0x400000) != 0) {
            piVar22 = uStack_68._4_4_;
            piStack_14 = (int *)(uVar30 & 0xffbfffff | 0x800000);
            if (uStack_68._4_4_ != (int *)0x0) {
              LOCK();
              iVar21 = uStack_68._4_4_[1] + -1;
              uStack_68._4_4_[1] = iVar21;
              UNLOCK();
              if (iVar21 == 0) {
                (**(code **)*uStack_68._4_4_)();
                LOCK();
                piVar29 = piVar22 + 2;
                iVar21 = *piVar29 + -1;
                *piVar29 = iVar21;
                UNLOCK();
                if (iVar21 == 0) {
                  (**(code **)(*piVar22 + 4))();
                }
              }
            }
          }
          piVar22 = piStack_30;
          if ((((uint)piStack_14 & 0x200000) != 0) &&
             (piStack_14 = (int *)((uint)piStack_14 & 0xffdfffff), piStack_30 != (int *)0x0)) {
            LOCK();
            iVar21 = piStack_30[1] + -1;
            piStack_30[1] = iVar21;
            UNLOCK();
            if (iVar21 == 0) {
              (**(code **)*piStack_30)();
              LOCK();
              piVar29 = piVar22 + 2;
              iVar21 = *piVar29 + -1;
              *piVar29 = iVar21;
              UNLOCK();
              if (iVar21 == 0) {
                (**(code **)(*piVar22 + 4))();
              }
            }
          }
          iStack_8._0_1_ = 0xd;
          if ((piStack_18 != (int *)0x0) && (param_3 != '\0')) {
            FUN_00c7c480(0);
            puVar23 = (undefined4 *)FUN_00da7df0(0,0,0,0);
            FUN_00c7c400(*puVar23,puVar23[1],puVar23[2],puVar23[3]);
          }
          FUN_00550b30();
        }
        else {
          uStack_68 = 0xf00000000;
          uStack_78 = uStack_78 & 0xffffff00;
          FUN_005542c0(&DAT_018bc9b8,0);
          iStack_8._0_1_ = 0xc;
          FUN_00ae6630(&uStack_78);
          FUN_005507b0();
        }
        FUN_00550b30();
      }
      else {
        if (*param_4 != '\0') {
          iVar21 = FUN_00b077e0();
          afStack_d4[0] = _DAT_018e3fb0;
          afStack_d4[1] = (float)_UNK_018e3fb4;
          afStack_d4[2] = (float)_UNK_018e3fb8;
          afStack_d4[3] = (float)_UNK_018e3fbc;
          fStack_c4 = _DAT_018e3fb0;
          fStack_c0 = (float)_UNK_018e3fb4;
          fStack_bc = (float)_UNK_018e3fb8;
          fStack_b8 = (float)_UNK_018e3fbc;
          fStack_b4 = _DAT_018e3fb0;
          uStack_b0 = CONCAT44(_UNK_018e3fb8,_UNK_018e3fb4);
          fStack_a8 = (float)_UNK_018e3fbc;
          pfVar25 = (float *)FUN_011630b0(auStack_60);
          afStack_d4[0] = *pfVar25;
          afStack_d4[1] = pfVar25[1];
          afStack_d4[2] = pfVar25[2];
          afStack_d4[3] = pfVar25[3];
          fStack_c4 = pfVar25[4];
          fStack_c0 = pfVar25[5];
          fStack_bc = pfVar25[6];
          fStack_b8 = pfVar25[7];
          fStack_b4 = pfVar25[8];
          pfVar25 = (float *)FUN_01160de0(auStack_84);
          fVar28 = *(float *)(pcVar17 + 0x2c);
          fVar1 = *(float *)(pcVar17 + 0x28);
          fVar2 = *(float *)(pcVar17 + 0x30);
          fVar3 = *(float *)(iVar21 + 0x24);
          fVar35 = pfVar25[1] * fVar28 + *pfVar25 * fVar1 + pfVar25[2] * fVar2;
          fVar4 = *(float *)(iVar21 + 0x2c);
          fVar34 = pfVar25[3] * fVar1 + pfVar25[4] * fVar28 + pfVar25[5] * fVar2;
          fVar5 = *(float *)(iVar21 + 0x28);
          fStack_a8 = pfVar25[6] * fVar1 + pfVar25[7] * fVar28 + pfVar25[8] * fVar2;
          uStack_b0 = CONCAT44(fVar34,fVar35);
          piStack_24 = (int *)(fVar3 * afStack_d4[3] + fVar5 * fStack_c4 + fVar4 * fStack_c0 +
                              fVar34);
          uStack_68 = CONCAT44(fVar3 * fStack_bc + fVar5 * fStack_b8 + fVar4 * fStack_b4 + fStack_a8
                               ,(int *)uStack_68);
          uStack_44 = (ulonglong)
                      (uint)(fVar3 * afStack_d4[0] + fVar5 * afStack_d4[1] + fVar4 * afStack_d4[2] +
                            fVar35);
          puVar23 = (undefined4 *)FUN_01160c20(&fStack_138,iVar21);
          uStack_114 = *puVar23;
          uStack_110 = puVar23[1];
          uStack_10c = puVar23[2];
          uStack_108 = puVar23[3];
          uStack_104 = puVar23[4];
          uStack_100 = puVar23[5];
          uStack_fc = puVar23[6];
          uStack_f8 = puVar23[7];
          uStack_f4 = puVar23[8];
          uStack_f0 = (undefined4)uStack_44;
          piStack_ec = piStack_24;
          uStack_e8 = uStack_68._4_4_;
          (**(code **)(*piStack_18 + 0x108))(&uStack_114);
        }
        if ((param_1 == (int *)0x0) ||
           (iVar21 = param_1[3], iVar26 = FUN_00b50240(),
           (uint)*(ushort *)(iVar26 + 0x1da) <
           (uint)*(ushort *)(iVar21 + 0x1d8) - (uint)*(ushort *)(iVar26 + 0x1d8))) {
          ppiVar27 = &piStack_28;
          uVar30 = (uint)piStack_14 | 0x2000;
          piStack_24 = (int *)0x0;
          piVar22 = (int *)0x0;
        }
        else {
          if (param_2 != (int *)0x0) {
            LOCK();
            param_2[1] = param_2[1] + 1;
            UNLOCK();
          }
          ppiVar27 = &piStack_1c;
          piStack_18 = param_2;
          uVar30 = (uint)piStack_14 | 0x1000;
          piVar22 = param_1;
        }
        piStack_30 = ppiVar27[1];
        piStack_14 = (int *)(uVar30 | 0x4000);
        *ppiVar27 = (int *)0x0;
        ppiVar27[1] = (int *)0x0;
        piStack_34 = piVar22;
        if (((uVar30 & 0x2000) != 0) &&
           (piStack_14 = (int *)(uVar30 & 0xffffdfff | 0x4000), piStack_24 != (int *)0x0)) {
          LOCK();
          iVar21 = piStack_24[1] + -1;
          piStack_24[1] = iVar21;
          UNLOCK();
          if (iVar21 == 0) {
            (**(code **)*piStack_24)();
            LOCK();
            iVar21 = piStack_24[2] + -1;
            piStack_24[2] = iVar21;
            UNLOCK();
            if (iVar21 == 0) {
              (**(code **)(*piStack_24 + 4))();
            }
          }
        }
        if ((((uint)piStack_14 & 0x1000) != 0) &&
           (piStack_14 = (int *)((uint)piStack_14 & 0xffffefff), piStack_18 != (int *)0x0)) {
          LOCK();
          iVar21 = piStack_18[1] + -1;
          piStack_18[1] = iVar21;
          UNLOCK();
          if (iVar21 == 0) {
            (**(code **)*piStack_18)();
            LOCK();
            iVar21 = piStack_18[2] + -1;
            piStack_18[2] = iVar21;
            UNLOCK();
            if (iVar21 == 0) {
              (**(code **)(*piStack_18 + 4))();
            }
          }
        }
        iStack_8._0_1_ = 5;
        if (piVar22 != (int *)0x0) {
          uVar24 = FUN_00b53a60();
          FUN_00a15e20(&uStack_54,uVar24);
          uStack_78 = uStack_54;
          uStack_54 = uStack_54 & 0xffffff00;
          uStack_74 = uStack_50;
          uStack_70 = uStack_4c;
          uStack_6c = uStack_48;
          uStack_68 = uStack_44;
          uStack_44._0_4_ = (undefined4 *)0x0;
          uStack_44._4_4_ = (int *)0xf;
          iStack_8._0_1_ = 6;
          FUN_00b550f0(&uStack_78);
          iStack_8._0_1_ = 5;
          FUN_005507b0();
          FUN_00a15e20(&uStack_54,piVar22 + 0x5a);
          uStack_78 = uStack_54;
          uStack_54 = uStack_54 & 0xffffff00;
          uStack_74 = uStack_50;
          uStack_70 = uStack_4c;
          uStack_6c = uStack_48;
          uStack_68 = CONCAT44(uStack_44._4_4_,(undefined4 *)uStack_44);
          uStack_44 = 0xf00000000;
          iStack_8._0_1_ = 7;
          FUN_00b554b0(&uStack_78);
          FUN_005507b0();
          uStack_44 = 0xf00000000;
          uStack_54 = uStack_54 & 0xffffff00;
          iStack_8._0_1_ = 8;
          (**(code **)(*piVar22 + 0x154))(&uStack_54);
          FUN_005507b0();
        }
        iStack_8._0_1_ = 4;
        FUN_00550b30();
        if ((param_1 == (int *)0x0) ||
           (iVar21 = param_1[3], iVar26 = FUN_00cfb1a0(),
           (uint)*(ushort *)(iVar26 + 0x1da) <
           (uint)*(ushort *)(iVar21 + 0x1d8) - (uint)*(ushort *)(iVar26 + 0x1d8))) {
          ppiVar27 = &piStack_34;
          uVar30 = (uint)piStack_14 | 0x10000;
          piStack_30 = (int *)0x0;
          piStack_18 = (int *)0x0;
        }
        else {
          piStack_18 = param_1;
          if (param_2 != (int *)0x0) {
            LOCK();
            param_2[1] = param_2[1] + 1;
            UNLOCK();
          }
          piStack_24 = param_2;
          ppiVar27 = &piStack_28;
          uVar30 = (uint)piStack_14 | 0x8000;
        }
        piStack_14 = (int *)(uVar30 | 0x20000);
        uStack_68 = CONCAT44(uStack_68._4_4_,piStack_18);
        uStack_68 = CONCAT44(ppiVar27[1],piStack_18);
        *ppiVar27 = (int *)0x0;
        ppiVar27[1] = (int *)0x0;
        piVar22 = piStack_30;
        if (((uVar30 & 0x10000) != 0) &&
           (piStack_14 = (int *)(uVar30 & 0xfffeffff | 0x20000), piStack_30 != (int *)0x0)) {
          LOCK();
          iVar21 = piStack_30[1] + -1;
          piStack_30[1] = iVar21;
          UNLOCK();
          if (iVar21 == 0) {
            (**(code **)*piStack_30)();
            LOCK();
            piVar29 = piVar22 + 2;
            iVar21 = *piVar29 + -1;
            *piVar29 = iVar21;
            UNLOCK();
            if (iVar21 == 0) {
              (**(code **)(*piVar22 + 4))();
            }
          }
        }
        piVar22 = piStack_24;
        if ((((uint)piStack_14 & 0x8000) != 0) &&
           (piStack_14 = (int *)((uint)piStack_14 & 0xffff7fff), piStack_24 != (int *)0x0)) {
          LOCK();
          iVar21 = piStack_24[1] + -1;
          piStack_24[1] = iVar21;
          UNLOCK();
          if (iVar21 == 0) {
            (**(code **)*piStack_24)();
            LOCK();
            piVar29 = piVar22 + 2;
            iVar21 = *piVar29 + -1;
            *piVar29 = iVar21;
            UNLOCK();
            if (iVar21 == 0) {
              (**(code **)(*piVar22 + 4))();
            }
          }
        }
        if (piStack_18 != (int *)0x0) {
          uStack_44 = 0xf00000000;
          uStack_54 = uStack_54 & 0xffffff00;
          iStack_8._0_1_ = 10;
          (**(code **)(*piStack_18 + 0x154))(&uStack_54);
          FUN_005507b0();
        }
        FUN_00550b30();
      }
      piVar22 = piStack_38;
      if (piStack_38 != (int *)0x0) {
        LOCK();
        iVar21 = piStack_38[1] + -1;
        piStack_38[1] = iVar21;
        UNLOCK();
        if (iVar21 == 0) {
          (**(code **)*piStack_38)();
          LOCK();
          piVar29 = piVar22 + 2;
          iVar21 = *piVar29 + -1;
          *piVar29 = iVar21;
          UNLOCK();
          if (iVar21 == 0) {
            (**(code **)(*piVar22 + 4))();
          }
        }
      }
    }
    else {
      if ((param_3 != '\0') && (iVar21 = (**(code **)(*piVar22 + 0xa8))(), iVar21 != 0)) {
        puVar23 = (undefined4 *)FUN_00b077e0();
        uVar24 = puVar23[1];
        uVar7 = puVar23[2];
        uVar8 = puVar23[3];
        if (*param_4 == '\0') {
          *(undefined4 *)(param_4 + 4) = *puVar23;
          *(undefined4 *)(param_4 + 8) = uVar24;
          *(undefined4 *)(param_4 + 0xc) = uVar7;
          *(undefined4 *)(param_4 + 0x10) = uVar8;
          uVar24 = puVar23[5];
          uVar7 = puVar23[6];
          uVar8 = puVar23[7];
          *(undefined4 *)(param_4 + 0x14) = puVar23[4];
          *(undefined4 *)(param_4 + 0x18) = uVar24;
          *(undefined4 *)(param_4 + 0x1c) = uVar7;
          *(undefined4 *)(param_4 + 0x20) = uVar8;
          uVar24 = puVar23[9];
          uVar7 = puVar23[10];
          uVar8 = puVar23[0xb];
          *(undefined4 *)(param_4 + 0x24) = puVar23[8];
          *(undefined4 *)(param_4 + 0x28) = uVar24;
          *(undefined4 *)(param_4 + 0x2c) = uVar7;
          *(undefined4 *)(param_4 + 0x30) = uVar8;
          *param_4 = '\x01';
        }
        else {
          uVar9 = puVar23[4];
          uVar10 = puVar23[5];
          uVar11 = puVar23[6];
          uVar12 = puVar23[7];
          uVar13 = puVar23[8];
          uVar14 = puVar23[9];
          uVar15 = puVar23[10];
          uVar16 = puVar23[0xb];
          *(undefined4 *)(param_4 + 4) = *puVar23;
          *(undefined4 *)(param_4 + 8) = uVar24;
          *(undefined4 *)(param_4 + 0xc) = uVar7;
          *(undefined4 *)(param_4 + 0x10) = uVar8;
          *(undefined4 *)(param_4 + 0x14) = uVar9;
          *(undefined4 *)(param_4 + 0x18) = uVar10;
          *(undefined4 *)(param_4 + 0x1c) = uVar11;
          *(undefined4 *)(param_4 + 0x20) = uVar12;
          *(undefined4 *)(param_4 + 0x24) = uVar13;
          *(undefined4 *)(param_4 + 0x28) = uVar14;
          *(undefined4 *)(param_4 + 0x2c) = uVar15;
          *(undefined4 *)(param_4 + 0x30) = uVar16;
        }
      }
      uVar24 = FUN_00a33c70();
      iStack_8._0_1_ = 3;
      FUN_00b66cc0(uVar24);
      iStack_8._0_1_ = 2;
      FUN_0056cd30();
      uStack_98 = 0;
      piStack_94 = (int *)0x0;
      piStack_90 = (int *)0x0;
      FUN_00b66d00(&uStack_98);
      uVar24 = FUN_0060efa0();
      FUN_00b66c40(uVar24);
    }
    piVar22 = piStack_20;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar21 = piStack_20[1] + -1;
      piStack_20[1] = iVar21;
      UNLOCK();
      if (iVar21 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar29 = piVar22 + 2;
        iVar21 = *piVar29 + -1;
        *piVar29 = iVar21;
        UNLOCK();
        if (iVar21 == 0) {
          (**(code **)(*piVar22 + 4))();
        }
      }
    }
  }
  else if (piVar22[0xd] != 0) {
    piStack_20 = (int *)FUN_00c3c010();
    piStack_18 = (int *)FUN_00c3c020();
    if (piStack_20 == (int *)0x0) {
      piStack_20 = (int *)0x0;
    }
    else if (piStack_20[0xd] != 0) {
      piStack_20 = (int *)FUN_005c8ac0();
    }
    if (piStack_18 == (int *)0x0) {
      piStack_18 = (int *)0x0;
    }
    else if (piStack_18[0xd] != 0) {
      piStack_18 = (int *)FUN_005c8ac0();
    }
    if (piVar22[0xd] != 0) {
      piVar22 = (int *)FUN_005c8ac0();
    }
    if (((piStack_20 != (int *)0x0) && (piStack_20 != piVar22)) ||
       ((piStack_18 != (int *)0x0 && (piStack_18 != piVar22)))) {
      FUN_008a65e0(0,0);
      iVar21 = FUN_00550b30();
      goto LAB_00a18267;
    }
  }
  piVar22 = piStack_88;
  iStack_8._0_1_ = 0;
  if (piStack_88 != (int *)0x0) {
    LOCK();
    iVar21 = piStack_88[1] + -1;
    piStack_88[1] = iVar21;
    UNLOCK();
    if (iVar21 == 0) {
      (**(code **)*piStack_88)();
      LOCK();
      piVar29 = piVar22 + 2;
      iVar21 = *piVar29 + -1;
      *piVar29 = iVar21;
      UNLOCK();
      if (iVar21 == 0) {
        (**(code **)(*piVar22 + 4))();
      }
    }
  }
  if ((param_1 == (int *)0x0) ||
     (iVar21 = param_1[3], iVar26 = FUN_00d17fd0(),
     (uint)*(ushort *)(iVar26 + 0x1da) <
     (uint)*(ushort *)(iVar21 + 0x1d8) - (uint)*(ushort *)(iVar26 + 0x1d8))) {
    ppiVar27 = &piStack_8c;
    uVar30 = (uint)piStack_14 | 0x2000000;
    piStack_88 = (int *)0x0;
    piStack_18 = (int *)0x0;
  }
  else {
    piStack_18 = param_1;
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    piStack_24 = param_2;
    uVar30 = (uint)piStack_14 | 0x1000000;
    ppiVar27 = &piStack_28;
  }
  piVar22 = ppiVar27[1];
  piStack_14 = (int *)(uVar30 | 0x4000000);
  *ppiVar27 = (int *)0x0;
  ppiVar27[1] = (int *)0x0;
  piStack_94 = piStack_18;
  piStack_90 = piVar22;
  if (((uVar30 & 0x2000000) != 0) &&
     (piStack_14 = (int *)(uVar30 & 0xfdffffff | 0x4000000), piStack_88 != (int *)0x0)) {
    LOCK();
    iVar21 = piStack_88[1] + -1;
    piStack_88[1] = iVar21;
    UNLOCK();
    if (iVar21 == 0) {
      (**(code **)*piStack_88)();
      LOCK();
      iVar21 = piStack_88[2] + -1;
      piStack_88[2] = iVar21;
      UNLOCK();
      if (iVar21 == 0) {
        (**(code **)(*piStack_88 + 4))();
      }
    }
  }
  if ((((uint)piStack_14 & 0x1000000) != 0) &&
     (piStack_14 = (int *)((uint)piStack_14 & 0xfeffffff), piStack_24 != (int *)0x0)) {
    LOCK();
    iVar21 = piStack_24[1] + -1;
    piStack_24[1] = iVar21;
    UNLOCK();
    if (iVar21 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar21 = piStack_24[2] + -1;
      piStack_24[2] = iVar21;
      UNLOCK();
      if (iVar21 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (piStack_18 != (int *)0x0) {
    uStack_44 = 0xf00000000;
    uStack_54 = uStack_54 & 0xffffff00;
    iStack_8._0_1_ = 0xf;
    (**(code **)(*DAT_0213d40c + 0x10))(piStack_18,&uStack_54);
    iStack_8._0_1_ = 0xe;
    uVar19 = (undefined)iStack_8;
    iStack_8._0_1_ = 0xe;
    if (0xf < uStack_44._4_4_) {
      uVar32 = (int)uStack_44._4_4_ + 1;
      uVar30 = uStack_54;
      if (0xfff < uVar32) {
        uVar30 = *(uint *)(uStack_54 - 4);
        uVar32 = (int)uStack_44._4_4_ + 0x24;
        if (0x1f < (uStack_54 - uVar30) - 4) {
          iStack_8._0_1_ = uVar19;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar30,uVar32);
    }
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (piVar22 != (int *)0x0) {
    LOCK();
    iVar21 = piVar22[1] + -1;
    piVar22[1] = iVar21;
    UNLOCK();
    if (iVar21 == 0) {
      (**(code **)*piVar22)();
      LOCK();
      iVar21 = piVar22[2] + -1;
      piVar22[2] = iVar21;
      UNLOCK();
      if (iVar21 == 0) {
        (**(code **)(*piVar22 + 4))();
      }
    }
  }
  FUN_008a6f80(0xffffffff,0xffffffff);
  piVar22 = *(int **)((int)fStack_2c + 0x18);
  piVar29 = *(int **)((int)fStack_2c + 0x1c);
  iVar21 = param_5;
  piStack_38 = piVar29;
  piStack_24 = piVar22;
  if (piVar22 != piVar29) {
    do {
      piStack_20 = (int *)*piVar22;
      if (iVar21 != 3) {
        piStack_24 = piVar22;
        if ((iVar21 == 1) || (iVar21 == 2)) {
          piStack_94 = (int *)0x0;
          piStack_90 = (int *)&DAT_0000000f;
          apppuStack_a4[0] = (undefined4 ***)((uint)apppuStack_a4[0] & 0xffffff00);
          FUN_005542c0(&DAT_018bc9b8,0);
          piStack_18 = (int *)((uint)piStack_14 | 1);
          iStack_8 = CONCAT31(iStack_8._1_3_,0x10);
          fStack_2c = (float)piStack_20[10];
          piStack_14 = piStack_18;
          fVar28 = (float)FUN_00b00260();
          piVar18 = piStack_38;
          if (fStack_2c == fVar28) {
            if (piStack_94 != (int *)0x0) {
              ppppuVar31 = apppuStack_a4;
              if (&DAT_0000000f < piStack_90) {
                ppppuVar31 = (undefined4 ****)apppuStack_a4[0];
              }
              piVar29 = (int *)piStack_20[1];
              fStack_2c = (float)piVar29[4];
              if (0xf < (uint)piVar29[5]) {
                piVar29 = (int *)*piVar29;
              }
              cVar20 = FUN_0055c360(piVar29,fStack_2c,ppppuVar31,piStack_94);
              piVar29 = piVar18;
              if (cVar20 == '\0') goto LAB_00a180f1;
            }
            if (((uint)piStack_20[9] >> 4 & 1) == 0) goto LAB_00a180f1;
            (**(code **)(*(int *)piStack_20[0xd] + 0xc))(&uStack_114,param_1);
            FUN_00a13b60(&uStack_114,param_5);
            (**(code **)(*(int *)piStack_20[0xd] + 0x10))(param_1,&uStack_114);
          }
          else {
LAB_00a180f1:
            uStack_68 = 0xf00000000;
            uStack_78 = uStack_78 & 0xffffff00;
            FUN_005542c0("Velocity",8);
            piStack_18 = (int *)((uint)piStack_14 | 2);
            iStack_8 = 0x11;
            piStack_14 = piStack_18;
            cVar20 = FUN_00a13a10(&param_1,piStack_20,&uStack_78,param_5);
            if (cVar20 == '\0') {
              uStack_44 = 0xf00000000;
              uStack_54 = uStack_54 & 0xffffff00;
              FUN_005542c0("RotVelocity",0xb);
              piStack_18 = (int *)((uint)piStack_14 | 4);
              iStack_8 = 0x12;
              piStack_14 = piStack_18;
              FUN_00a13a10(&param_1,piStack_20,&uStack_54,param_5);
            }
          }
          if (((uint)piStack_14 & 4) != 0) {
            piStack_14 = (int *)((uint)piStack_14 & 0xfffffffb);
            FUN_005507b0();
          }
          if (((uint)piStack_14 & 2) != 0) {
            piStack_14 = (int *)((uint)piStack_14 & 0xfffffffd);
            FUN_005507b0();
          }
          piStack_14 = (int *)((uint)piStack_14 & 0xfffffffe);
          iStack_8 = 0;
          FUN_005507b0();
          iVar21 = param_5;
        }
        else {
          fStack_2c = (float)piStack_20[10];
          fVar28 = (float)FUN_00b00260();
          iVar21 = param_5;
          if ((fStack_2c == fVar28) && (((uint)piStack_20[9] >> 4 & 1) != 0)) {
            (**(code **)(*(int *)piStack_20[0xd] + 0xc))(&fStack_144,param_1);
            piStack_18 = (int *)0x0;
            afStack_d4[0] = fStack_144;
            afStack_d4[1] = fStack_140;
            afStack_d4[2] = fStack_13c;
            afStack_d4[3] = fStack_138;
            fStack_c4 = fStack_134;
            fStack_c0 = fStack_130;
            fStack_bc = fStack_12c;
            fStack_b8 = fStack_128;
            fStack_b4 = fStack_124;
            uStack_b0 = CONCAT44(uStack_11c,uStack_120);
            fStack_a8 = fStack_118;
            do {
              fVar33 = (float10)FUN_017268ab(*(float *)((int)&uStack_b0 + (int)piStack_18 * 4) *
                                             DAT_018ce320);
              fVar28 = (float)fVar33;
              fStack_2c = fVar28;
              if ((NAN(fVar28) != (fVar28 == 0.0)) ||
                 ((NAN(fVar28) || NAN(DAT_018f9988)) != (fVar28 == DAT_018f9988))) {
                fVar28 = 0.0;
              }
              *(float *)((int)&uStack_b0 + (int)piStack_18 * 4) = fVar28;
              piStack_18 = (int *)((int)piStack_18 + 1);
            } while ((int)piStack_18 < 3);
            pfVar25 = afStack_d4;
            piStack_18 = (int *)0x3;
            do {
              iVar21 = 3;
              do {
                fVar33 = (float10)FUN_017268ab(*pfVar25 * DAT_018ce320);
                fVar28 = (float)fVar33;
                fStack_2c = fVar28;
                if ((NAN(fVar28) != (fVar28 == 0.0)) ||
                   ((NAN(fVar28) || NAN(DAT_018f9988)) != (fVar28 == DAT_018f9988))) {
                  fVar28 = 0.0;
                }
                *pfVar25 = fVar28;
                pfVar25 = pfVar25 + 1;
                iVar21 = iVar21 + -1;
              } while (iVar21 != 0);
              piStack_18 = (int *)((int)piStack_18 + -1);
            } while (piStack_18 != (int *)0x0);
            fStack_144 = afStack_d4[0];
            fStack_140 = afStack_d4[1];
            fStack_13c = afStack_d4[2];
            fStack_138 = afStack_d4[3];
            fStack_134 = fStack_c4;
            fStack_130 = fStack_c0;
            fStack_12c = fStack_bc;
            fStack_128 = fStack_b8;
            fStack_124 = fStack_b4;
            uStack_120 = (undefined4)uStack_b0;
            uStack_11c = uStack_b0._4_4_;
            fStack_118 = fStack_a8;
            (**(code **)(*(int *)piStack_20[0xd] + 0x10))(param_1,&fStack_144);
            iVar21 = param_5;
            piVar22 = piStack_24;
            piVar29 = piStack_38;
          }
        }
      }
      piVar22 = piVar22 + 1;
      piStack_24 = piVar22;
    } while (piVar22 != piVar29);
  }
  iVar21 = (**(code **)(*param_1 + 0x40))(&uStack_44);
  iStack_8._0_1_ = 0x13;
  if ((undefined4 *)uStack_44 != (undefined4 *)0x0) {
    puVar6 = (undefined4 *)((undefined4 *)uStack_44)[1];
    for (puVar23 = (undefined4 *)*(undefined4 *)uStack_44; puVar23 != puVar6; puVar23 = puVar23 + 2)
    {
      if (puVar23[1] != 0) {
        LOCK();
        piVar22 = (int *)(puVar23[1] + 4);
        *piVar22 = *piVar22 + 1;
        UNLOCK();
      }
      iVar21 = FUN_00a17010(*puVar23,puVar23[1],0,param_4,param_5);
    }
  }
  piVar22 = uStack_44._4_4_;
  if (uStack_44._4_4_ != (int *)0x0) {
    LOCK();
    piVar29 = uStack_44._4_4_ + 1;
    iVar26 = *piVar29;
    iVar21 = *piVar29;
    *piVar29 = iVar26 + -1;
    UNLOCK();
    if (iVar26 + -1 == 0) {
      (**(code **)*uStack_44._4_4_)();
      LOCK();
      piVar29 = piVar22 + 2;
      iVar26 = *piVar29;
      iVar21 = *piVar29;
      *piVar29 = iVar26 + -1;
      UNLOCK();
      if (iVar26 + -1 == 0) {
        iVar21 = (**(code **)(*piVar22 + 4))();
      }
    }
  }
LAB_00a18267:
  piVar22 = param_2;
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar29 = param_2 + 1;
    iVar26 = *piVar29;
    iVar21 = *piVar29;
    *piVar29 = iVar26 + -1;
    UNLOCK();
    if (iVar26 + -1 == 0) {
      iVar21 = (**(code **)*param_2)();
      LOCK();
      piVar29 = piVar22 + 2;
      iVar26 = *piVar29;
      *piVar29 = *piVar29 + -1;
      UNLOCK();
      if (iVar26 == 1) {
        iVar21 = (**(code **)(*piVar22 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar21;
}



/* FUNCTION 20009 ; VA 0x00a182b0 ; FUN_00a182b0 */

void FUN_00a182b0(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  undefined auStack_44 [52];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017db628;
  pvStack_10 = ExceptionList;
  auStack_44[0] = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a18330(param_1);
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00a17010(*param_1,param_1[1],1,auStack_44,param_2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20010 ; VA 0x00a18330 ; FUN_00a18330 */

void FUN_00a18330(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 uVar6;
  int **ppiVar7;
  uint uVar8;
  uint uVar9;
  int *piVar10;
  undefined auStack_90 [8];
  undefined4 uStack_88;
  undefined4 *puStack_84;
  undefined8 uStack_80;
  int **appiStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  int *piStack_54;
  int *piStack_50;
  undefined4 uStack_4c;
  int iStack_48;
  int *piStack_44;
  undefined4 uStack_40;
  int *piStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017db693;
  pvStack_10 = ExceptionList;
  uVar8 = 0;
  uStack_14 = 0;
  uStack_80._4_4_ = (int ***)0xb;
  uStack_80._0_4_ = "PackageLink";
  uStack_5c = 0;
  uStack_58 = 0xf;
  appiStack_6c[0] = (int **)((uint)appiStack_6c[0] & 0xffffff00);
  puStack_84 = (undefined4 *)0xa18374;
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  uStack_80._4_4_ = appiStack_6c;
  uStack_8 = 0;
  uStack_80._0_4_ = (char *)&piStack_30;
  puStack_84 = (undefined4 *)0xa18386;
  FUN_008a1410();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (0xf < uStack_58) {
    uStack_80._4_4_ = (int ***)(uStack_58 + 1);
    ppiVar7 = appiStack_6c[0];
    if (0xfff < uStack_80._4_4_) {
      ppiVar7 = (int **)appiStack_6c[0][-1];
      uStack_80._4_4_ = (int ***)(uStack_58 + 0x24);
      if (0x1f < (uint)((int)appiStack_6c[0] + (-4 - (int)ppiVar7))) {
                    /* WARNING: Subroutine does not return */
        uStack_80._4_4_ = (int ***)&UNK_00a186bc;
        FUN_017167a3();
      }
    }
    puStack_84 = (undefined4 *)0xa183bb;
    uStack_80._0_4_ = (char *)ppiVar7;
    FUN_01674ea0();
  }
  uStack_5c = 0;
  uStack_58 = 0xf;
  appiStack_6c[0] = (int **)((uint)appiStack_6c[0] & 0xffffff00);
  if (piStack_30 != (int *)0x0) {
    uStack_80._4_4_ = (int ***)0xa183dc;
    (**(code **)(*piStack_30 + 0x2c))();
  }
  piVar10 = piStack_2c;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar5 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_80._4_4_ = (int ***)0xa183f3;
      (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piVar10 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_80._4_4_ = (int ***)0xa18404;
        (**(code **)(*piVar10 + 4))();
      }
    }
  }
  piStack_54 = (int *)0x0;
  piStack_50 = (int *)0x0;
  uStack_4c = 0;
  uStack_80._4_4_ = (int ***)&piStack_54;
  uStack_8 = 3;
  if (param_1[1] != 0) {
    LOCK();
    piVar10 = (int *)(param_1[1] + 4);
    *piVar10 = *piVar10 + 1;
    UNLOCK();
  }
  puStack_84 = (undefined4 *)*param_1;
  uStack_80._0_4_ = (char *)param_1[1];
  uStack_88 = 0xa18450;
  FUN_00a153d0();
  piStack_18 = piStack_54;
  piStack_24 = piStack_50;
  piVar10 = piStack_54;
  if (piStack_54 != piStack_50) {
    do {
      piStack_18 = piVar10;
      if (*piVar10 == 0) {
LAB_00a184b1:
        uVar9 = uVar8 | 2;
        piStack_34 = (int *)0x0;
        puVar4 = &uStack_38;
        param_1 = (undefined4 *)0x0;
      }
      else {
        iVar5 = *(int *)(*piVar10 + 0xc);
        uStack_80._4_4_ = (int ***)0xa18475;
        iVar3 = FUN_00eb3a50();
        param_1 = (undefined4 *)*piVar10;
        if ((uint)*(ushort *)(iVar3 + 0x1da) <
            (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) goto LAB_00a184b1;
        piStack_3c = (int *)piVar10[1];
        if (piStack_3c != (int *)0x0) {
          LOCK();
          piStack_3c[1] = piStack_3c[1] + 1;
          UNLOCK();
          piStack_3c = (int *)piVar10[1];
        }
        uVar9 = uVar8 | 1;
        puVar4 = &uStack_40;
      }
      piVar10 = (int *)puVar4[1];
      uVar8 = uVar9 | 4;
      *puVar4 = 0;
      puVar4[1] = 0;
      piVar1 = piStack_34;
      iStack_48 = (int)param_1;
      piStack_44 = piVar10;
      uStack_14 = uVar8;
      if (((uVar9 & 2) != 0) &&
         (uVar8 = uVar9 & 0xfffffffd | 4, uStack_14 = uVar8, piStack_34 != (int *)0x0)) {
        LOCK();
        iVar5 = piStack_34[1] + -1;
        piStack_34[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          uStack_80._4_4_ = (int ***)0xa18501;
          (**(code **)*piStack_34)();
          LOCK();
          piVar2 = piVar1 + 2;
          iVar5 = *piVar2 + -1;
          *piVar2 = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            uStack_80._4_4_ = (int ***)0xa18512;
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      piVar1 = piStack_3c;
      if (((uVar8 & 1) != 0) &&
         (uVar8 = uVar8 & 0xfffffffe, uStack_14 = uVar8, piStack_3c != (int *)0x0)) {
        LOCK();
        iVar5 = piStack_3c[1] + -1;
        piStack_3c[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          uStack_80._4_4_ = (int ***)0xa18534;
          (**(code **)*piStack_3c)();
          LOCK();
          piVar2 = piVar1 + 2;
          iVar5 = *piVar2 + -1;
          *piVar2 = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            uStack_80._4_4_ = (int ***)0xa18545;
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      uStack_20 = uVar8;
      if (param_1 != (undefined4 *)0x0) {
        uStack_8._0_1_ = 5;
        uStack_80._4_4_ = (int ***)0xa1855b;
        iVar5 = FUN_00eb3a50();
        uStack_80._4_4_ = (int ***)DAT_01edf5b0;
        if (*(undefined4 **)(iVar5 + 0x1dc) != (undefined4 *)0x0) {
          uStack_80._4_4_ = (int ***)**(undefined4 **)(iVar5 + 0x1dc);
        }
        uStack_80._0_4_ = (char *)0xa18574;
        uVar6 = FUN_01675290();
        uStack_80._0_4_ = (char *)0x80;
        uStack_8._0_1_ = 6;
        puStack_84 = (undefined4 *)0xa18587;
        uStack_28 = uVar6;
        puStack_84 = (undefined4 *)FUN_01674e20();
        uStack_8._0_1_ = 7;
        puStack_1c = puStack_84;
        if (puStack_84 == (undefined4 *)0x0) {
          uStack_80._0_4_ = (char *)0x0;
        }
        else {
          uStack_80._4_4_ = (int ***)0x80;
          uStack_80._0_4_ = (char *)0x0;
          uStack_88 = 0xa185a2;
          FUN_0170d1f0();
          uStack_80._4_4_ = (int ***)0xa185ad;
          FUN_00eb3b70();
          *puStack_1c = RBX::PackageLinkDummy::vftable;
          uStack_80._0_4_ = (char *)puStack_1c;
        }
        uStack_80._4_4_ = (int ***)param_1;
        uStack_8._0_1_ = 6;
        piStack_30 = (int *)0x0;
        piStack_2c = (int *)0x0;
        puStack_84 = (undefined4 *)0xa185d8;
        FUN_00a12b00();
        uStack_14 = uVar8 | 8;
        uStack_8._0_1_ = 0xb;
        uStack_80._0_4_ = (char *)0xa185e8;
        uStack_80._4_4_ = (int ***)uVar6;
        FUN_01675290();
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
        FUN_00eb3da0(auStack_90);
        FUN_00eb3e70();
        uStack_80._4_4_ = (int ***)0xa1860a;
        uStack_80 = FUN_00eb3de0();
        puStack_84 = (undefined4 *)0xa18613;
        FUN_00eb3f40();
        uStack_80._4_4_ = (int ***)0x0;
        uStack_80._0_4_ = *(char **)(*(int *)(*piStack_18 + 0x34) + 0x34);
        puStack_84 = (undefined4 *)0xa18627;
        FUN_008a65e0();
        piVar1 = piStack_2c;
        uVar8 = uStack_20 & 0xfffffff7;
        if (piStack_2c != (int *)0x0) {
          LOCK();
          iVar5 = piStack_2c[1] + -1;
          piStack_2c[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            uStack_80._4_4_ = (int ***)0xa18644;
            (**(code **)*piStack_2c)();
            LOCK();
            piVar2 = piVar1 + 2;
            iVar5 = *piVar2 + -1;
            *piVar2 = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              uStack_80._4_4_ = (int ***)0xa18655;
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      if (piVar10 != (int *)0x0) {
        LOCK();
        iVar5 = piVar10[1] + -1;
        piVar10[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          uStack_80._4_4_ = (int ***)0xa1866d;
          (**(code **)*piVar10)();
          LOCK();
          iVar5 = piVar10[2] + -1;
          piVar10[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            uStack_80._4_4_ = (int ***)0xa1867e;
            (**(code **)(*piVar10 + 4))();
          }
        }
      }
      piVar10 = piStack_18;
      uStack_80._4_4_ = (int ***)0x0;
      uStack_80._0_4_ = (char *)0x0;
      puStack_84 = (undefined4 *)0xa1868f;
      FUN_008a65e0();
      piVar10 = piVar10 + 2;
      piStack_18 = piVar10;
    } while (piVar10 != piStack_24);
  }
  uStack_80._4_4_ = (int ***)0xa186a6;
  FUN_00577ac0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20011 ; VA 0x00a186c0 ; FUN_00a186c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_00a186c0(undefined4 param_1,int *param_2,uint param_3,undefined4 param_4,undefined4 param_5,
                undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int *piVar2;
  void *pvVar3;
  undefined4 uVar4;
  undefined uVar5;
  undefined *puVar6;
  undefined **ppuVar7;
  int iVar8;
  undefined4 uVar9;
  int iVar10;
  undefined4 ****ppppuVar11;
  undefined4 *puVar12;
  undefined4 *puVar13;
  int iVar14;
  undefined **ppuVar15;
  uint uVar16;
  uint uVar17;
  undefined4 uStack_174;
  undefined4 *puStack_170;
  undefined4 uStack_16c;
  int *piStack_168;
  int aiStack_a4 [4];
  uint auStack_94 [4];
  undefined4 uStack_84;
  int *piStack_80;
  undefined4 ***apppuStack_7c [4];
  undefined4 uStack_6c;
  uint uStack_68;
  undefined4 uStack_64;
  int *piStack_60;
  undefined4 ***apppuStack_5c [4];
  undefined4 uStack_4c;
  uint uStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  uint uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017db70c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar6 = (undefined *)FUN_01674e20(0x18);
  if (puVar6 == (undefined *)0x0) {
    puVar6 = (undefined *)0x0;
    iStack_14 = 0;
  }
  else {
    *puVar6 = 0;
    iStack_14 = 0xb;
    ppuVar7 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&iStack_14);
    ppuVar15 = ppuVar7 + -1;
    if (ppuVar7 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar15 = ppuVar7;
    }
    *(undefined **)(puVar6 + 4) = *ppuVar15;
    *(undefined4 *)(puVar6 + 8) = 0;
    *(undefined4 *)(puVar6 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar6 + 0x10) = 0;
    *(undefined4 *)(puVar6 + 0x14) = 0;
  }
  uStack_24 = 0;
  piStack_20 = (int *)0x0;
  FUN_005c1af0(puVar6,iStack_14);
  uVar4 = uStack_24;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar8 = FUN_005c4c00(&DAT_01d65d00);
  uVar9 = FUN_0088da50();
  pvVar3 = ThreadLocalStoragePointer;
  iVar14 = _tls_index;
  *(undefined4 *)(iVar8 + 0x18) = uVar9;
  iStack_14 = *(int *)((int)pvVar3 + iVar14 * 4);
  if (*(int *)(iStack_14 + 0x34) < DAT_01ea8c28) {
    FUN_016f3809(&DAT_01ea8c28);
    if (DAT_01ea8c28 == -1) {
      DAT_01ea8c1c = FUN_005c6620;
      _DAT_01ea8c20 = FUN_005c6620;
      DAT_01ea8c24 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ea8c28);
    }
  }
  puVar12 = *(undefined4 **)(iVar8 + 0x1c);
  if ((code **)puVar12 == &DAT_01ea8c1c) {
    *(undefined4 *)(iVar8 + 0x20) = param_5;
    *(undefined4 *)(iVar8 + 0x24) = param_6;
  }
  else {
    if (puVar12 != (undefined4 *)0x0) {
      (*(code *)puVar12[2])(iVar8 + 0x20);
    }
    *(undefined4 *)(iVar8 + 0x20) = param_5;
    *(undefined4 *)(iVar8 + 0x24) = param_6;
    *(code ***)(iVar8 + 0x1c) = &DAT_01ea8c1c;
  }
  iVar8 = FUN_005c4c00(&DAT_01d65d18);
  uVar9 = FUN_0088c8c0();
  *(undefined4 *)(iVar8 + 0x18) = uVar9;
  iVar10 = FUN_005c9cc0();
  iVar14 = *(int *)(iVar8 + 0x1c);
  if (iVar14 == iVar10) {
    *(undefined4 *)(iVar8 + 0x20) = 1;
  }
  else {
    if (iVar14 != 0) {
      (**(code **)(iVar14 + 8))(iVar8 + 0x20);
    }
    *(undefined4 *)(iVar8 + 0x20) = 1;
    *(int *)(iVar8 + 0x1c) = iVar10;
  }
  piVar2 = piStack_20;
  uStack_4c = 0;
  uStack_48 = 0xf;
  apppuStack_5c[0] = (undefined4 ***)((uint)apppuStack_5c[0] & 0xffffff00);
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piStack_20[1] = piStack_20[1] + 1;
    UNLOCK();
  }
  uStack_64 = uVar4;
  piStack_60 = piStack_20;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_174 = FUN_008881d0();
  puStack_170 = (undefined4 *)0x0;
  uStack_16c = uVar4;
  piStack_168 = piVar2;
  uStack_64 = 0;
  piStack_60 = (int *)0x0;
  if (*(int *)(iStack_14 + 0x34) < DAT_01ea8a9c) {
    FUN_016f3809(&DAT_01ea8a9c);
    if (DAT_01ea8a9c == -1) {
      DAT_01ea8a90 = FUN_0057bbb0;
      DAT_01ea8a94 = FUN_005880a0;
      DAT_01ea8a98 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ea8a9c);
    }
  }
  puStack_170 = &DAT_01ea8a90;
  uStack_8._0_1_ = 4;
  FUN_0098fc00(&uStack_174,apppuStack_5c,1);
  uStack_8._0_1_ = 5;
  if (puStack_170 != (undefined4 *)0x0) {
    (*(code *)puStack_170[2])(&uStack_16c);
  }
  uStack_8._0_1_ = 2;
  uStack_2c = 0;
  uStack_28 = 0xf;
  uStack_3c = uStack_3c & 0xffffff00;
  FUN_005542c0(&DAT_0193fa6c,4);
  uStack_8._0_1_ = 6;
  uStack_84 = 0;
  piStack_80 = (int *)0xf;
  auStack_94[0] = auStack_94[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 7;
  FUN_00fb9490(apppuStack_7c,param_3,param_4,auStack_94,&uStack_3c);
  uStack_8._0_1_ = 9;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 9;
  if (0xf < piStack_80) {
    uVar16 = (int)piStack_80 + 1;
    uVar17 = auStack_94[0];
    if (0xfff < uVar16) {
      uVar17 = *(uint *)(auStack_94[0] - 4);
      uVar16 = (int)piStack_80 + 0x24;
      if (0x1f < (auStack_94[0] - uVar17) - 4) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar17,uVar16);
  }
  uStack_84 = 0;
  piStack_80 = (int *)0xf;
  auStack_94[0] = auStack_94[0] & 0xffffff00;
  uStack_8._0_1_ = 10;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 10;
  if (0xf < uStack_28) {
    uVar16 = uStack_28 + 1;
    uVar17 = uStack_3c;
    if (0xfff < uVar16) {
      uVar17 = *(uint *)(uStack_3c - 4);
      uVar16 = uStack_28 + 0x24;
      if (0x1f < (uStack_3c - uVar17) - 4) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar17,uVar16);
  }
  uStack_2c = 0;
  uStack_28 = 0xf;
  uStack_3c = uStack_3c & 0xffffff00;
  FUN_014c9d60(auStack_1c,0);
  ppppuVar11 = apppuStack_7c;
  if (0xf < uStack_68) {
    ppppuVar11 = (undefined4 ****)apppuStack_7c[0];
  }
  uStack_8._0_1_ = 0xb;
  FUN_014cbbc0(ppppuVar11,uStack_6c);
  FUN_014cba60();
  ppppuVar11 = apppuStack_5c;
  if (0xf < uStack_48) {
    ppppuVar11 = (undefined4 ****)apppuStack_5c[0];
  }
  FUN_014cb7a0(ppppuVar11,uStack_4c);
  puVar12 = &DAT_01d79f98;
  if (0xf < DAT_01d79fac) {
    puVar12 = DAT_01d79f98;
  }
  puVar13 = &DAT_01d79d70;
  if (0xf < DAT_01d79d84) {
    puVar13 = DAT_01d79d70;
  }
  FUN_014cb8a0(puVar13,DAT_01d79d80,puVar12,DAT_01d79fa8);
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[2] = param_2[2] + 1;
    UNLOCK();
  }
  uStack_44 = param_1;
  uStack_3c = param_3;
  uStack_34 = param_5;
  uStack_30 = param_6;
  piStack_40 = param_2;
  uStack_38 = param_4;
  uStack_2c = param_7;
  piStack_80 = (int *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  piStack_80 = (int *)FUN_00a126a0(&uStack_44);
  if (piStack_40 != (int *)0x0) {
    LOCK();
    iVar14 = piStack_40[2] + -1;
    piStack_40[2] = iVar14;
    UNLOCK();
    if (iVar14 == 0) {
      (**(code **)(*piStack_40 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  iVar14 = FUN_014cb530(aiStack_a4);
  if (piStack_80 != (int *)0x0) {
    iVar14 = (**(code **)(*piStack_80 + 0x10))(piStack_80 != aiStack_a4);
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar8 = *piVar1;
    iVar14 = *piVar1;
    *piVar1 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar8 = *piVar1;
      iVar14 = *piVar1;
      *piVar1 = iVar8 + -1;
      UNLOCK();
      if (iVar8 + -1 == 0) {
        iVar14 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (0xf < uStack_68) {
    uVar17 = uStack_68 + 1;
    ppppuVar11 = (undefined4 ****)apppuStack_7c[0];
    if (0xfff < uVar17) {
      ppppuVar11 = (undefined4 ****)apppuStack_7c[0][-1];
      uVar17 = uStack_68 + 0x24;
      if (0x1f < (uint)((int)apppuStack_7c[0] + (-4 - (int)ppppuVar11))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar14 = FUN_01674ea0(ppppuVar11,uVar17);
  }
  uStack_6c = 0;
  uStack_68 = 0xf;
  apppuStack_7c[0] = (undefined4 ***)((uint)apppuStack_7c[0] & 0xffffff00);
  if (0xf < uStack_48) {
    uVar17 = uStack_48 + 1;
    ppppuVar11 = (undefined4 ****)apppuStack_5c[0];
    if (0xfff < uVar17) {
      ppppuVar11 = (undefined4 ****)apppuStack_5c[0][-1];
      uVar17 = uStack_48 + 0x24;
      if (0x1f < (uint)((int)apppuStack_5c[0] + (-4 - (int)ppppuVar11))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar14 = FUN_01674ea0(ppppuVar11,uVar17);
  }
  uStack_4c = 0;
  uStack_48 = 0xf;
  apppuStack_5c[0] = (undefined4 ***)((uint)apppuStack_5c[0] & 0xffffff00);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar8 = *piVar1;
    iVar14 = *piVar1;
    *piVar1 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar8 = *piVar1;
      iVar14 = *piVar1;
      *piVar1 = iVar8 + -1;
      UNLOCK();
      if (iVar8 + -1 == 0) {
        iVar14 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar2 = param_2 + 2;
    iVar8 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar8 == 1) {
      iVar14 = (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar14;
}



/* FUNCTION 20012 ; VA 0x00a18cc0 ; FUN_00a18cc0 */

int FUN_00a18cc0(undefined4 *param_1,int param_2,int *param_3,undefined4 param_4,int *param_5)

{
  code *pcVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  undefined4 *puVar6;
  int *piVar7;
  uint uVar8;
  uint uVar9;
  uint auStack_4c [4];
  int iStack_3c;
  uint uStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017db758;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_7 = 0;
  if (param_2 == 0) {
    iStack_3c = param_2;
    auStack_4c[0] = auStack_4c[0] & 0xffffff00;
    uStack_38 = 0xf;
    ExceptionList = &pvStack_10;
    FUN_005542c0(&DAT_0193f83c,0xe);
    _uStack_8 = CONCAT31(uStack_7,2);
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    iVar2 = FUN_00a19080(param_1,auStack_4c,param_4,param_5);
    if (0xf < uStack_38) {
      uVar9 = uStack_38 + 1;
      uVar8 = auStack_4c[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_4c[0] - 4);
        uVar9 = uStack_38 + 0x24;
        if (0x1f < (auStack_4c[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      iVar2 = FUN_01674ea0(uVar8,uVar9);
    }
  }
  else {
    ExceptionList = &pvStack_10;
    piVar3 = (int *)FUN_0091d440(&DAT_01d65d48);
    iVar2 = *piVar3;
    iVar4 = FUN_008882f0();
    if (iVar2 != iVar4) {
LAB_00a1905e:
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piStack_2c = piVar3 + 2;
    if (piVar3[1] == 0) {
      piStack_2c = (int *)0x0;
    }
    piVar3 = (int *)piStack_2c[1];
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar3[1] = piVar3[1] + 1;
      UNLOCK();
      piVar3 = (int *)piStack_2c[1];
    }
    piStack_2c = (int *)*piStack_2c;
    uStack_8 = 3;
    iVar2 = piStack_2c[1] - *piStack_2c >> 0x1f;
    piStack_28 = piVar3;
    piStack_24 = piStack_2c;
    piStack_1c = piVar3;
    if ((piStack_2c[1] - *piStack_2c) / 0xd0 + iVar2 == iVar2) {
      iStack_3c = 0;
      uStack_38 = 0xf;
      auStack_4c[0] = auStack_4c[0] & 0xffffff00;
      FUN_005542c0(&DAT_0193f83c,0xe);
      _uStack_8 = CONCAT31(uStack_7,6);
      if (param_5 != (int *)0x0) {
        LOCK();
        param_5[1] = param_5[1] + 1;
        UNLOCK();
      }
      FUN_00a19080(param_1,auStack_4c,param_4,param_5);
      iVar2 = FUN_005507b0();
    }
    else {
      uStack_18 = 0;
      iStack_14 = 0;
      do {
        iVar2 = *piStack_24;
        if ((uint)((piStack_24[1] - iVar2) / 0xd0) <= uStack_18) {
          FUN_00577c40();
          pcVar1 = (code *)swi(3);
          iVar2 = (*pcVar1)();
          return iVar2;
        }
        iVar4 = *(int *)(iStack_14 + iVar2);
        iVar5 = FUN_008881d0();
        if (iVar4 != iVar5) goto LAB_00a1905e;
        puVar6 = (undefined4 *)(iStack_14 + 8 + iVar2);
        if (*(int *)(iStack_14 + 4 + iVar2) == 0) {
          puVar6 = (undefined4 *)0x0;
        }
        piVar3 = (int *)puVar6[1];
        if (piVar3 != (int *)0x0) {
          LOCK();
          piVar3[1] = piVar3[1] + 1;
          UNLOCK();
          piVar3 = (int *)puVar6[1];
        }
        uStack_34 = *puVar6;
        uStack_8 = 4;
        piStack_30 = piVar3;
        piStack_20 = (int *)FUN_0091d440(&DAT_01d65d60);
        iVar2 = *piStack_20;
        iVar4 = FUN_0088cb40();
        if (iVar2 != iVar4) goto LAB_00a1905e;
        piVar7 = piStack_20 + 2;
        if (piStack_20[1] == 0) {
          piVar7 = (int *)0x0;
        }
        if (0xf < (uint)piVar7[5]) {
          piVar7 = (int *)*piVar7;
        }
        puVar6 = param_1;
        if (0xf < (uint)param_1[5]) {
          puVar6 = (undefined4 *)*param_1;
        }
        FUN_0086f2f0(3,"%s failed with error: %s",puVar6,piVar7);
        uStack_8 = 3;
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar2 = piVar3[1] + -1;
          piVar3[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar2 = piVar3[2] + -1;
            piVar3[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        iStack_14 = iStack_14 + 0xd0;
        uStack_18 = uStack_18 + 1;
      } while (uStack_18 < (uint)((piStack_24[1] - *piStack_24) / 0xd0));
      iStack_3c = 0;
      uStack_38 = 0xf;
      auStack_4c[0] = auStack_4c[0] & 0xffffff00;
      FUN_005542c0("Failure",7);
      _uStack_8 = CONCAT31(uStack_7,5);
      iVar2 = FUN_0058bd10(auStack_4c);
      piVar3 = piStack_1c;
      if (0xf < uStack_38) {
        uVar9 = uStack_38 + 1;
        uVar8 = auStack_4c[0];
        if (0xfff < uVar9) {
          uVar8 = *(uint *)(auStack_4c[0] - 4);
          uVar9 = uStack_38 + 0x24;
          if (0x1f < (auStack_4c[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        iVar2 = FUN_01674ea0(uVar8,uVar9);
        piVar3 = piStack_1c;
      }
    }
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar7 = piVar3 + 1;
      iVar4 = *piVar7;
      iVar2 = *piVar7;
      *piVar7 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar7 = piVar3 + 2;
        iVar4 = *piVar7;
        iVar2 = *piVar7;
        *piVar7 = iVar4 + -1;
        UNLOCK();
        if (iVar4 + -1 == 0) {
          iVar2 = (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar3 = param_3 + 1;
    iVar4 = *piVar3;
    iVar2 = *piVar3;
    *piVar3 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar3 = param_3 + 2;
      iVar4 = *piVar3;
      iVar2 = *piVar3;
      *piVar3 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        iVar2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar3 = param_5 + 1;
    iVar4 = *piVar3;
    iVar2 = *piVar3;
    *piVar3 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar2 = (**(code **)*param_5)();
      LOCK();
      piVar3 = param_5 + 2;
      iVar4 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar2 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 20013 ; VA 0x00a19080 ; FUN_00a19080 */

int FUN_00a19080(undefined4 *param_1,undefined4 *param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017db780;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_2[4] == 0) {
    param_2 = (undefined4 *)&DAT_0193f83c;
  }
  else if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  ExceptionList = &pvStack_10;
  FUN_0086f2f0(3,"%s failed with error: %s",param_1,param_2);
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("Failure",7);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar3 = FUN_0058bd10(auStack_28);
  if (0xf < uStack_14) {
    uVar5 = uStack_14 + 1;
    uVar4 = auStack_28[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_28[0] - 4);
      uVar5 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar3 = FUN_01674ea0(uVar4,uVar5);
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20014 ; VA 0x00a19180 ; FUN_00a19180 */

void FUN_00a19180(int param_1,char param_2,int *param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  undefined **ppuVar7;
  undefined *puVar8;
  int iVar9;
  uint uVar10;
  undefined **ppuVar11;
  int *piVar12;
  char *pcVar13;
  int *piVar14;
  undefined auStack_10b [3];
  undefined uStack_108;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined uStack_f0;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined uStack_d8;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined uStack_c0;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  int iStack_a8;
  int iStack_a0;
  int iStack_98;
  int iStack_90;
  uint uStack_88;
  undefined4 uStack_78;
  uint uStack_74;
  undefined auStack_70 [4];
  undefined *puStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  uint uStack_58;
  uint uStack_54;
  uint uStack_50;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  undefined4 uStack_40;
  undefined4 *puStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017db7f7;
  pvStack_10 = ExceptionList;
  if (param_1 != 0) {
    uStack_40 = 0;
    puStack_3c = (undefined4 *)0x0;
    uStack_38 = 0;
    ExceptionList = &pvStack_10;
    puStack_3c = (undefined4 *)FUN_00616d10();
    uStack_34 = 0;
    uStack_30 = 0;
    uStack_2c = 0;
    uStack_8 = 1;
    uStack_40 = 0x3f800000;
    FUN_005cb500();
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    piVar14 = (int *)*param_3;
    piStack_20 = (int *)param_3[1];
    if (piVar14 != piStack_20) {
      do {
        iVar9 = piVar14[1];
        iStack_1c = 0;
        piStack_18 = (int *)0x0;
        if (iVar9 != 0) {
          piVar12 = (int *)(iVar9 + 4);
          iVar9 = *(int *)(iVar9 + 4);
          while (iVar9 != 0) {
            LOCK();
            iVar5 = *piVar12;
            if (iVar9 == iVar5) {
              *piVar12 = iVar9 + 1;
              iVar5 = iVar9;
            }
            UNLOCK();
            if (iVar5 == iVar9) {
              iStack_1c = *piVar14;
              piStack_18 = (int *)piVar14[1];
              break;
            }
            iVar9 = *piVar12;
          }
        }
        uStack_8._0_1_ = 3;
        if (iStack_1c != 0) {
          uVar6 = FUN_00a2e100();
          switch(uVar6) {
          case 1:
            uStack_b0 = 0;
            uStack_ac = 0xf;
            uStack_c0 = 0;
            FUN_005542c0();
            uStack_8._0_1_ = 4;
            FUN_00a12bf0();
            iVar9 = iStack_90;
            break;
          case 2:
            uStack_c8 = 0;
            uStack_c4 = 0xf;
            uStack_d8 = 0;
            FUN_005542c0();
            uStack_8._0_1_ = 5;
            FUN_00a12bf0();
            iVar9 = iStack_98;
            break;
          case 3:
            uStack_e0 = 0;
            uStack_dc = 0xf;
            uStack_f0 = 0;
            FUN_005542c0();
            uStack_8._0_1_ = 6;
            FUN_00a12bf0();
            iVar9 = iStack_a0;
            break;
          case 4:
            uStack_f8 = 0;
            uStack_f4 = 0xf;
            uStack_108 = 0;
            FUN_005542c0();
            uStack_8._0_1_ = 7;
            FUN_00a12bf0();
            iVar9 = iStack_a8;
            break;
          default:
            goto switchD_00a19284_caseD_4;
          }
          *(int *)(iVar9 + 0x20) = *(int *)(iVar9 + 0x20) + 1;
          FUN_005507b0();
        }
switchD_00a19284_caseD_4:
        piVar12 = piStack_18;
        if (piStack_18 != (int *)0x0) {
          LOCK();
          iVar9 = piStack_18[1] + -1;
          piStack_18[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)*piStack_18)();
            LOCK();
            piVar1 = piVar12 + 2;
            iVar9 = *piVar1 + -1;
            *piVar1 = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)(*piVar12 + 4))();
            }
          }
        }
        piVar14 = piVar14 + 2;
      } while (piVar14 != piStack_20);
    }
    auStack_70[0] = 0;
    puStack_14 = (uint *)&DAT_0000000b;
    ppuVar7 = (undefined **)FUN_00563d40();
    ppuVar11 = ppuVar7 + -1;
    if (ppuVar7 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar11 = ppuVar7;
    }
    puStack_6c = *ppuVar11;
    uStack_68 = 0;
    uStack_64 = 0x3f800000;
    uStack_60 = 0;
    uStack_5c = 0;
    uStack_8._0_1_ = 8;
    cVar4 = FUN_00983210();
    uStack_78 = 0;
    uStack_74 = 0xf;
    uStack_88 = uStack_88 & 0xffffff00;
    pcVar13 = "true";
    if (cVar4 == '\0') {
      pcVar13 = "false";
    }
    FUN_005542c0();
    uStack_8._0_1_ = 9;
    FUN_005d15d0();
    do {
      cVar4 = *pcVar13;
      pcVar13 = pcVar13 + 1;
    } while (cVar4 != '\0');
    FUN_005542c0();
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    if (0xf < uStack_74) {
      if ((0xfff < uStack_74 + 1) && (0x1f < (uStack_88 - *(int *)(uStack_88 - 4)) - 4)) {
LAB_00a19695:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      FUN_01674ea0();
    }
    puVar3 = puStack_3c;
    for (puVar2 = (undefined4 *)*puStack_3c; puVar2 != puVar3; puVar2 = (undefined4 *)*puVar2) {
      if (puVar2[8] != 0) {
        puVar8 = (undefined *)FUN_00591870();
        uStack_48 = 0;
        uStack_44 = 0xf;
        uStack_58 = uStack_58 & 0xffffff00;
        if (puVar8 != auStack_10b) {
          FUN_005542c0();
        }
        uVar10 = uStack_44;
        uStack_8 = CONCAT31(uStack_8._1_3_,10);
        iVar9 = FUN_005d15d0();
        puStack_14 = (uint *)(iVar9 + 0x18);
        if (puStack_14 != &uStack_58) {
          if (0xf < *(uint *)(iVar9 + 0x2c)) {
            if ((0xfff < *(uint *)(iVar9 + 0x2c) + 1) &&
               (0x1f < (*puStack_14 - *(int *)(*puStack_14 - 4)) - 4)) goto LAB_00a19695;
            FUN_01674ea0();
          }
          puStack_14[4] = 0;
          puStack_14[5] = 0xf;
          *puStack_14 = uStack_58;
          puStack_14[1] = uStack_54;
          puStack_14[2] = uStack_50;
          puStack_14[3] = uStack_4c;
          uStack_58 = uStack_58 & 0xffffff00;
          puStack_14[4] = uStack_48;
          puStack_14[5] = uStack_44;
          uVar10 = 0xf;
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,8);
        if (0xf < uVar10) {
          if ((0xfff < uVar10 + 1) && (0x1f < (uStack_58 - *(int *)(uStack_58 - 4)) - 4))
          goto LAB_00a19695;
          FUN_01674ea0();
        }
      }
    }
    pcVar13 = "CheckFailed";
    if (param_2 == '\0') {
      pcVar13 = "CheckPassed";
    }
    FUN_0060e660(auStack_70);
    FUN_0087c510("Studio","PlacePublishPackageCheck",pcVar13);
    FUN_0056cfd0();
    FUN_0077f0d0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20015 ; VA 0x00a196b0 ; FUN_00a196b0 */

int FUN_00a196b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int iStack_94;
  uint uStack_80;
  int iStack_60;
  uint uStack_4c;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017db833;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_0193f8b8,3);
  uStack_8._0_1_ = 1;
  FUN_00fb9490(auStack_44,param_1,param_2,param_3,auStack_2c);
  uStack_8._0_1_ = 3;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_18) {
    uVar5 = uStack_18 + 1;
    uVar6 = auStack_2c[0];
    if (0xfff < uVar5) {
      uVar6 = *(uint *)(auStack_2c[0] - 4);
      uVar5 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar6) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar5);
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_014cc090(auStack_44,0,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  FUN_00a12210(param_1,param_2,param_4,param_5,param_6);
  FUN_014ccc70();
  if (0xf < uStack_4c) {
    uVar6 = uStack_4c + 1;
    iVar4 = iStack_60;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iStack_60 + -4);
      uVar6 = uStack_4c + 0x24;
      if (0x1f < (iStack_60 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
  }
  iVar4 = FUN_0056cfd0();
  if (0xf < uStack_80) {
    uVar6 = uStack_80 + 1;
    iVar4 = iStack_94;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iStack_94 + -4);
      uVar6 = uStack_80 + 0x24;
      if (0x1f < (iStack_94 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(iVar4,uVar6);
  }
  if (0xf < uStack_30) {
    uVar5 = uStack_30 + 1;
    uVar6 = auStack_44[0];
    if (0xfff < uVar5) {
      uVar6 = *(uint *)(auStack_44[0] - 4);
      uVar5 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(uVar6,uVar5);
  }
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 20016 ; VA 0x00a19900 ; FUN_00a19900 */

void FUN_00a19900(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 in_stack_ffffff54;
  undefined **appuStack_98 [2];
  undefined auStack_90 [24];
  undefined4 uStack_78;
  int *piStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_58;
  int *piStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017db86b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_2[2] = param_2[2] + 1;
    UNLOCK();
  }
  uStack_30 = param_3;
  uStack_38 = param_1;
  piStack_34 = param_2;
  uStack_2c = param_4;
  uStack_28 = param_5;
  uStack_24 = param_6;
  uStack_20 = param_7;
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[2] = param_2[2] + 1;
    UNLOCK();
  }
  uStack_44 = param_6;
  uStack_58 = param_1;
  piStack_54 = param_2;
  uStack_50 = param_3;
  uStack_4c = param_4;
  uStack_48 = param_5;
  uStack_40 = param_7;
  appuStack_98[0] = (undefined **)0x0;
  piVar1 = param_2 + 2;
  if (param_2 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_68 = param_5;
  uStack_64 = param_6;
  uStack_78 = param_1;
  piStack_74 = param_2;
  uStack_70 = param_3;
  uStack_6c = param_4;
  uStack_60 = param_7;
  uStack_8 = 3;
  if (param_2 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_0193fb00;
  cVar3 = FUN_00a12d50(param_1,param_2,param_3,param_4,param_5,param_6,param_7,in_stack_ffffff54,
                       auStack_90);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  appuStack_98[0] = ppuVar4;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_2 + 4))();
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_2 + 4))();
    }
    if (param_2 != (int *)0x0) {
      LOCK();
      iVar2 = param_2[2] + -1;
      param_2[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_01534720(auStack_18,appuStack_98,DAT_0193fb48);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar2 = piStack_14[2] + -1;
      piStack_14[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((appuStack_98[0] != (undefined **)0x0) && (((uint)appuStack_98[0] & 1) == 0)) &&
     (*(code **)((uint)appuStack_98[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)((uint)appuStack_98[0] & 0xfffffffe))(auStack_90,auStack_90,2);
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20017 ; VA 0x00a19ae0 ; FUN_00a19ae0 */

void FUN_00a19ae0(int param_1,int param_2,int param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  bool bVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  uint uVar11;
  uint uVar12;
  undefined4 *puVar13;
  undefined8 uVar14;
  undefined4 uStack_8c;
  undefined4 *puStack_88;
  undefined4 uStack_84;
  int iStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined auStack_6c [4];
  undefined4 *puStack_68;
  int aiStack_64 [5];
  uint uStack_50;
  uint auStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  int *piStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017db8ce;
  pvStack_10 = ExceptionList;
  uStack_8c = 0;
  puStack_88 = (undefined4 *)0x0;
  uStack_84 = 0;
  ExceptionList = &pvStack_10;
  puStack_88 = (undefined4 *)FUN_005e9aa0(0,0);
  iStack_80 = 0;
  uStack_7c = 0;
  uStack_78 = 0;
  uStack_8 = 1;
  uStack_8c = 0x3f800000;
  FUN_005cb500(8);
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  piVar5 = *(int **)(param_3 + 0x43c);
  if ((param_1 == *piVar5 - (int)piVar5) && (param_2 == piVar5[1] - (int)piVar5)) {
    bVar4 = false;
  }
  else {
    bVar4 = true;
  }
  if (param_3 + 0xc == 0) {
    iVar8 = 0;
  }
  else {
    piVar5 = (int *)FUN_005e5d30();
    iVar8 = *piVar5;
    if (iVar8 == 0) {
      FUN_005f4e60(&uStack_24);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      FUN_008a5700(param_3 + 0xc);
      FUN_005789c0(&DAT_01ea93d4,&LAB_005e5aa0);
      uVar6 = FUN_005e5b30();
      piVar5 = (int *)FUN_008aa140(uVar6);
      if (uStack_24._4_4_ != (int *)0x0) {
        LOCK();
        uStack_24._4_4_[1] = uStack_24._4_4_[1] + 1;
        UNLOCK();
      }
      *piVar5 = (int)uStack_24;
      piVar1 = (int *)piVar5[1];
      piVar5[1] = (int)uStack_24._4_4_;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar8 = piVar1[1] + -1;
        piVar1[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar8 = piVar1[2] + -1;
          piVar1[2] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      piVar5 = uStack_24._4_4_;
      iVar8 = (int)uStack_24;
      uStack_8._0_1_ = 2;
      if (uStack_24._4_4_ != (int *)0x0) {
        LOCK();
        iVar3 = uStack_24._4_4_[1] + -1;
        uStack_24._4_4_[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*uStack_24._4_4_)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar3 = *piVar1 + -1;
          *piVar1 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
  }
  FUN_0060e0c0(&uStack_2c,iVar8);
  piVar5 = piStack_28;
  uStack_8._0_1_ = 4;
  if (bVar4) {
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[2] = piStack_28[2] + 1;
      UNLOCK();
    }
    uStack_1c = uStack_2c;
    piStack_18 = piStack_28;
    uStack_8._0_1_ = 5;
    FUN_00a15f10(auStack_6c,param_1,param_2);
    uStack_8._0_1_ = 6;
    piVar1 = piStack_28;
    for (puVar13 = (undefined4 *)*puStack_68; piStack_28 = piVar1, puVar13 != puStack_68;
        puVar13 = (undefined4 *)*puVar13) {
      uVar6 = puVar13[2];
      uVar2 = puVar13[3];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[2] = piVar5[2] + 1;
        UNLOCK();
      }
      FUN_00a157b0(param_1,param_2,uVar6,uVar2,uStack_2c,piVar1);
      piVar5 = piVar1;
      piVar1 = piStack_28;
    }
    FUN_005e61c0();
    uStack_8._0_1_ = 4;
    puVar13 = puStack_88;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar8 = piVar5[2] + -1;
      piVar5[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar5 + 4))();
        puVar13 = puStack_88;
      }
    }
  }
  else {
    puVar7 = (undefined4 *)FUN_00a15f10(auStack_6c,param_1,param_2);
    puVar13 = puStack_88;
    if (&uStack_8c != puVar7) {
      uStack_8c = *puVar7;
      piVar1 = puVar7 + 3;
      if (&iStack_80 != piVar1) {
        FUN_0056d320();
        iStack_80 = *piVar1;
        uStack_7c = puVar7[4];
        uStack_78 = puVar7[5];
        *piVar1 = 0;
        puVar7[4] = 0;
        puVar7[5] = 0;
      }
      puVar13 = puStack_88;
      uStack_74 = puVar7[6];
      uStack_70 = puVar7[7];
      if (&puStack_88 == (undefined4 **)(puVar7 + 1)) {
        uStack_8._0_1_ = 4;
        FUN_005e9e90();
      }
      else {
        FUN_005e9f00();
        puVar13 = (undefined4 *)puVar7[1];
        puVar7[1] = puStack_88;
        uVar6 = puVar7[2];
        puVar7[2] = uStack_84;
        uStack_8._0_1_ = 4;
        puStack_88 = puVar13;
        uStack_84 = uVar6;
        FUN_005e9e90();
      }
    }
    FUN_005e61c0();
  }
  FUN_00a15c60(&piStack_34,param_3);
  uStack_8._0_1_ = 8;
  param_3 = *piStack_34;
  iStack_14 = piStack_34[1];
  if (param_3 != iStack_14) {
    do {
      FUN_00eb3da0(aiStack_64);
      uStack_8._0_1_ = 9;
      puVar7 = (undefined4 *)FUN_009cc5b0(auStack_4c);
      if (0xf < (uint)puVar7[5]) {
        puVar7 = (undefined4 *)*puVar7;
      }
      uVar14 = FUN_0171d7b1(puVar7,0,10);
      uStack_24 = uVar14;
      if (0xf < uStack_38) {
        uVar12 = uStack_38 + 1;
        uVar11 = auStack_4c[0];
        if (0xfff < uVar12) {
          uVar11 = *(uint *)(auStack_4c[0] - 4);
          uVar12 = uStack_38 + 0x24;
          if (0x1f < (auStack_4c[0] - uVar11) - 4) goto LAB_00a1a04e;
        }
        FUN_01674ea0(uVar11,uVar12);
      }
      uStack_3c = 0;
      uStack_38 = 0xf;
      auStack_4c[0] = auStack_4c[0] & 0xffffff00;
      uStack_8._0_1_ = 8;
      if (0xf < uStack_50) {
        uVar11 = uStack_50 + 1;
        iVar8 = aiStack_64[0];
        if (0xfff < uVar11) {
          iVar8 = *(int *)(aiStack_64[0] + -4);
          uVar11 = uStack_50 + 0x24;
          if (0x1f < (aiStack_64[0] - iVar8) - 4U) {
LAB_00a1a04e:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar8,uVar11);
      }
      iVar8 = FUN_005e9db0(&uStack_24);
      puVar7 = *(undefined4 **)(iStack_80 + iVar8 * 8);
      puVar10 = puVar7;
      while( true ) {
        puVar9 = puVar13;
        if (puVar7 != puVar13) {
          puVar9 = (undefined4 *)**(undefined4 **)(iStack_80 + 4 + iVar8 * 8);
        }
        if (puVar10 == puVar9) goto LAB_00a19f17;
        if ((puVar10[2] == (int)uStack_24) && ((int *)puVar10[3] == uStack_24._4_4_)) break;
        puVar10 = (undefined4 *)*puVar10;
      }
      if (puVar10 == puVar13) {
LAB_00a19f17:
        if (piVar5 != (int *)0x0) {
          piVar1 = piVar5 + 2;
          LOCK();
          *piVar1 = *piVar1 + 1;
          UNLOCK();
          LOCK();
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        uVar6 = 0;
        if (piVar5 != (int *)0x0) {
          LOCK();
          piVar5[2] = piVar5[2] + 1;
          UNLOCK();
        }
        FUN_00a13120(uStack_2c,piVar5,param_1,param_2,uStack_24);
        if (piVar5 != (int *)0x0) {
          piVar1 = piVar5 + 2;
          LOCK();
          iVar8 = *piVar1;
          *piVar1 = iVar8 + -1;
          UNLOCK();
          if (iVar8 + -1 == 0) {
            (**(code **)(*piVar5 + 4))(uVar6);
          }
          LOCK();
          iVar8 = *piVar1;
          *piVar1 = iVar8 + -1;
          UNLOCK();
          if (iVar8 + -1 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
        FUN_0151ded0();
      }
      else {
        FUN_00923b40(&uStack_24);
        puVar13 = puStack_88;
      }
      param_3 = param_3 + 8;
    } while (param_3 != iStack_14);
  }
  piVar1 = piStack_28;
  for (puVar7 = (undefined4 *)*puVar13; puVar7 != puVar13; puVar7 = (undefined4 *)*puVar7) {
    uVar6 = puVar7[2];
    uVar2 = puVar7[3];
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar5[2] = piVar5[2] + 1;
      UNLOCK();
    }
    piStack_28 = piVar1;
    FUN_00a157b0(param_1,param_2,uVar6,uVar2,uStack_2c,piVar1);
    piVar5 = piVar1;
    piVar1 = piStack_28;
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_30[1] + -1;
    piStack_30[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      iVar8 = piStack_30[2] + -1;
      piStack_30[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar1 = piVar5 + 2;
    iVar8 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar8 == 1) {
      (**(code **)(*piVar5 + 4))();
    }
  }
  FUN_005e61c0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20018 ; VA 0x00a1a060 ; FUN_00a1a060 */

undefined * FUN_00a1a060(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017db8ec;
  pvStack_10 = ExceptionList;
  if (DAT_01ee6c38 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee6e48) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee6e48);
      if (DAT_01ee6e48 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"AssetCounterService",1,uStack_20,0,0,0x11,6,0);
        FUN_016f3654(&LAB_01889600);
        FUN_016f37bf(&DAT_01ee6e48);
      }
    }
    DAT_01ee6c38 = &DAT_01ee6c40;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee6c38;
}



/* FUNCTION 20019 ; VA 0x00a1a140 ; FUN_00a1a140 */

void FUN_00a1a140(void)

{
  int iVar1;
  
  if (DAT_01ee6e4c == 0) {
    iVar1 = FUN_00a1a060();
    DAT_01ee6e4c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 20020 ; VA 0x00a1a160 ; FUN_00a1a160 */

void FUN_00a1a160(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = FUN_006d3cd0(param_1,param_2);
  puVar1 = (undefined4 *)*param_4;
  *(undefined4 *)(iVar2 + 8) = *puVar1;
  *(undefined4 *)(iVar2 + 0xc) = puVar1[1];
  *(undefined4 *)(iVar2 + 0x10) = 0;
  return;
}



/* FUNCTION 20021 ; VA 0x00a1a190 ; FUN_00a1a190 */

void __thiscall FUN_00a1a190(float *param_1,float *param_2,int *param_3,float *param_4)

{
  float fVar1;
  float *pfVar2;
  int iVar3;
  float fVar4;
  float fVar5;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017db900;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  pfStack_1c = param_1;
  iVar3 = FUN_00a1aa40(param_3);
  fVar4 = param_1[1];
  fVar5 = *(float *)((int)param_1[3] + iVar3 * 8);
  if (fVar4 != fVar5) {
    fVar4 = **(float **)((int)param_1[3] + 4 + iVar3 * 8);
    while (fVar4 != fVar5) {
      fVar4 = *(float *)((int)fVar4 + 4);
      if ((*param_3 == *(int *)((int)fVar4 + 8)) && (param_3[1] == *(int *)((int)fVar4 + 0xc))) {
        *(float *)param_4[1] = *param_4;
        *(float *)((int)*param_4 + 4) = param_4[1];
        param_1[2] = (float)((int)param_1[2] + -1);
        FUN_01674ea0(param_4,0x18);
        *param_2 = fVar4;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  pfStack_18 = param_4;
  fVar5 = *param_4;
  if (fVar4 != fVar5) {
    *(float *)param_4[1] = fVar5;
    **(float **)((int)fVar5 + 4) = fVar4;
    **(undefined4 **)((int)fVar4 + 4) = param_4;
    fVar1 = *(float *)((int)fVar4 + 4);
    *(undefined4 *)((int)fVar4 + 4) = *(undefined4 *)((int)fVar5 + 4);
    *(float *)((int)fVar5 + 4) = param_4[1];
    param_4[1] = fVar1;
  }
  fVar5 = param_1[3];
  fVar1 = *(float *)((int)fVar5 + iVar3 * 8);
  if (fVar1 == param_1[1]) {
    *(float **)((int)fVar5 + iVar3 * 8) = param_4;
    *(float **)((int)param_1[3] + 4 + iVar3 * 8) = param_4;
  }
  else if (fVar1 == fVar4) {
    *(float **)((int)fVar5 + iVar3 * 8) = param_4;
  }
  else {
    pfVar2 = (float *)**(undefined4 **)((int)fVar5 + 4 + iVar3 * 8);
    *(float **)((int)fVar5 + 4 + iVar3 * 8) = pfVar2;
    if (pfVar2 != param_4) {
      *(undefined4 *)((int)param_1[3] + 4 + iVar3 * 8) =
           *(undefined4 *)(*(int *)((int)param_1[3] + 4 + iVar3 * 8) + 4);
    }
  }
  fVar4 = param_1[7];
  uStack_8 = 2;
  fVar5 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
          (float)((double)(int)fVar4 + (double)(&DAT_018c0d90)[-((int)fVar4 >> 0x1f)]);
  if (*param_1 <= fVar5 && fVar5 != *param_1) {
    if ((uint)fVar4 < 0x200) {
      fVar4 = (float)((int)fVar4 << 3);
    }
    else if ((uint)fVar4 < 0x1fffffff) {
      fVar4 = (float)((int)fVar4 * 2);
    }
    FUN_00a1aac0(fVar4);
    pfVar2 = (float *)param_1[1];
    if ((float *)*pfVar2 != pfVar2) {
      fVar4 = pfVar2[1];
      do {
        fVar5 = *(float *)param_1[1];
        FUN_00a1a190(auStack_24,(int)fVar5 + 8,fVar5);
      } while (fVar5 != fVar4);
    }
  }
  *param_2 = (float)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20022 ; VA 0x00a1a348 ; Catch_All@00a1a348 */

void Catch_All_00a1a348(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_00a1a370(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20023 ; VA 0x00a1a370 ; FUN_00a1a370 */

undefined4 FUN_00a1a370(undefined4 param_1,undefined4 param_2)

{
  FUN_00a1adf0(param_1,param_2);
  return param_1;
}



/* FUNCTION 20024 ; VA 0x00a1a390 ; FUN_00a1a390 */

undefined4 * __fastcall FUN_00a1a390(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *puVar4;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017db95f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::AssetCounterService,class_RBX::ServiceInstance>::vftable;
  uVar1 = FUN_00a1a060();
  param_1[3] = uVar1;
  *param_1 = RBX::AssetCounterService::vftable;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  puVar4 = param_1 + 0x18;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  *puVar4 = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  puStack_1c = puVar4;
  uVar1 = FUN_006d3cd0(0,0);
  param_1[0x19] = uVar1;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  uStack_8._0_1_ = 5;
  *puVar4 = 0x3f800000;
  FUN_005cb650(0x10);
  uStack_14 = param_1[0x19];
  FUN_00a1ab20(0x10,&uStack_14);
  param_1[0x1e] = 7;
  param_1[0x1f] = 8;
  uStack_8._0_1_ = 6;
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  FUN_005542c0("AssetCounterService",0x13);
  puVar4 = puStack_18;
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_008a6520(auStack_34);
  if (0xf < uStack_20) {
    uVar3 = uStack_20 + 1;
    uVar2 = auStack_34[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_34[0] - 4);
      uVar3 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 20025 ; VA 0x00a1a4f0 ; thunk_FUN_006d1810 */

void __fastcall thunk_FUN_006d1810(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_006d18f0();
  return;
}



/* FUNCTION 20026 ; VA 0x00a1a500 ; FUN_00a1a500 */

int * __thiscall FUN_00a1a500(int param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  int *piVar8;
  int *piVar9;
  int *piVar10;
  int *piStack_10;
  int *piStack_c;
  int iStack_8;
  
  piVar4 = param_2;
  iStack_8 = param_1;
  iVar6 = FUN_00a1aa40(param_2);
  iVar5 = iStack_8;
  iVar1 = *(int *)(param_1 + 0xc);
  piVar2 = *(int **)(param_1 + 4);
  iVar6 = iVar6 * 8;
  piVar8 = *(int **)(iVar1 + iVar6);
  piVar9 = piVar8;
  while( true ) {
    piVar10 = piVar2;
    if (piVar9 != piVar2) {
      piVar10 = (int *)**(undefined4 **)(iVar1 + 4 + iVar6);
    }
    if (piVar8 == piVar10) goto LAB_00a1a55c;
    if ((piVar8[2] == *piVar4) && (piVar8[3] == piVar4[1])) break;
    piVar8 = (int *)*piVar8;
    piVar9 = *(int **)(iVar1 + iVar6);
  }
  if (piVar8 == piVar2) {
LAB_00a1a55c:
    iVar6 = *piVar2;
    piStack_c = piVar4;
    puVar3 = *(undefined4 **)(iVar6 + 4);
    uVar7 = FUN_00a1a160(iVar6,puVar3,&DAT_018bdeda,&piStack_c,(int)&param_2 + 3);
    if (*(int *)(iVar5 + 8) == 0xaaaaaa9) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    *(int *)(iVar5 + 8) = *(int *)(iVar5 + 8) + 1;
    *(undefined4 *)(iVar6 + 4) = uVar7;
    *puVar3 = uVar7;
    FUN_00a1a190(&piStack_10,**(int **)(iVar5 + 4) + 8,**(int **)(iVar5 + 4));
    piVar8 = piStack_10;
  }
  return piVar8 + 4;
}



/* FUNCTION 20027 ; VA 0x00a1a5d0 ; FUN_00a1a5d0 */

int * FUN_00a1a5d0(int param_1,int *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  undefined8 uVar8;
  int iStack_2c;
  int *piStack_28;
  undefined8 uStack_24;
  int *piStack_1c;
  undefined8 *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017db980;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_00587490(&iStack_2c);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_24 = CONCAT44(uStack_24._4_4_,(int)uStack_24);
  if ((iStack_2c != 0) && (uStack_24 = CONCAT44(uStack_24._4_4_,(int)uStack_24), param_1 != 0)) {
    uVar8 = FUN_008a2af0();
    piVar3 = (int *)((uint)uVar8 & (uint)((ulonglong)uVar8 >> 0x20));
    if (piVar3 != (int *)0xffffffff) {
      uStack_24 = FUN_008a2af0();
      piVar3 = (int *)FUN_00a1a500(&uStack_24);
      *piVar3 = *piVar3 + -1;
      if (DAT_01ee6c30 != '\0') {
        iVar4 = FUN_00a1aa40(&uStack_24);
        piVar3 = *(int **)(iStack_2c + 100);
        piVar1 = *(int **)(*(int *)(iStack_2c + 0x6c) + iVar4 * 8);
        puStack_18 = (undefined8 *)(*(int *)(iStack_2c + 0x6c) + 4 + iVar4 * 8);
        piVar6 = piVar1;
        while( true ) {
          piVar7 = piVar3;
          if (piVar1 != piVar3) {
            piVar7 = (int *)**(undefined4 **)puStack_18;
          }
          if (piVar6 == piVar7) goto LAB_00a1a6a8;
          if ((piVar6[2] == (int)uStack_24) && (piVar6[3] == uStack_24._4_4_)) break;
          piVar6 = (int *)*piVar6;
        }
        if (piVar6 == piVar3) {
LAB_00a1a6a8:
          iVar4 = *piVar3;
          puStack_18 = &uStack_24;
          puVar2 = *(undefined4 **)(iVar4 + 4);
          uVar5 = FUN_00a1a160(iVar4,puVar2,&DAT_018bdeda,&puStack_18,&uStack_11);
          if (*(int *)(iStack_2c + 0x68) == 0xaaaaaa9) {
                    /* WARNING: Subroutine does not return */
            FUN_016ddcd9("list<T> too long");
          }
          *(int *)(iStack_2c + 0x68) = *(int *)(iStack_2c + 0x68) + 1;
          *(undefined4 *)(iVar4 + 4) = uVar5;
          *puVar2 = uVar5;
          FUN_00a1a190(&piStack_1c,**(int **)(iStack_2c + 100) + 8,**(int **)(iStack_2c + 100));
          piVar6 = piStack_1c;
        }
        FUN_01677490(DAT_01ee6c30,"Removing asset with sourceAssetId %lld new count is %d",
                     (int)uStack_24,piVar6[4],0);
      }
      piVar3 = (int *)FUN_00a1a500(&uStack_24);
      if (*piVar3 < 1) {
        piVar3 = (int *)FUN_00a1ae70(&uStack_24);
      }
    }
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_28 + 1;
    iVar4 = *piVar1;
    piVar3 = (int *)*piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piStack_28 + 2;
      iVar4 = *piVar1;
      piVar3 = (int *)*piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        piVar3 = (int *)(**(code **)(*piStack_28 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar4 = *piVar1;
    piVar3 = (int *)*piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      piVar3 = (int *)(**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        piVar3 = (int *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar3;
}



/* FUNCTION 20028 ; VA 0x00a1a7b0 ; FUN_00a1a7b0 */

int * FUN_00a1a7b0(int param_1,int *param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  int *piVar8;
  undefined8 uVar9;
  int iStack_34;
  int *piStack_30;
  undefined8 uStack_2c;
  int iStack_24;
  int *piStack_20;
  undefined4 *puStack_1c;
  undefined8 *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017db9a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_00587490(&iStack_34);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_2c = CONCAT44(uStack_2c._4_4_,(int)uStack_2c);
  if ((iStack_34 != 0) && (uStack_2c = CONCAT44(uStack_2c._4_4_,(int)uStack_2c), param_1 != 0)) {
    uVar9 = FUN_008a2af0();
    piVar4 = (int *)((uint)uVar9 & (uint)((ulonglong)uVar9 >> 0x20));
    if (piVar4 != (int *)0xffffffff) {
      uStack_2c = FUN_008a2af0();
      iStack_24 = iStack_34 + 0x60;
      piVar4 = (int *)FUN_00a1a500(&uStack_2c);
      *piVar4 = *piVar4 + 1;
      if (DAT_01ee6c30 != '\0') {
        iVar5 = FUN_00a1aa40(&uStack_2c);
        puVar1 = (undefined4 *)(iStack_34 + 100);
        piVar4 = *(int **)(iStack_34 + 100);
        piVar2 = *(int **)(*(int *)(iStack_34 + 0x6c) + iVar5 * 8);
        puStack_18 = (undefined8 *)(*(int *)(iStack_34 + 0x6c) + 4 + iVar5 * 8);
        piVar7 = piVar2;
        while( true ) {
          piVar8 = piVar4;
          if (piVar2 != piVar4) {
            piVar8 = (int *)**(undefined4 **)puStack_18;
          }
          puStack_1c = puVar1;
          if (piVar7 == piVar8) goto LAB_00a1a88d;
          if ((piVar7[2] == (int)uStack_2c) && (piVar7[3] == uStack_2c._4_4_)) break;
          piVar7 = (int *)*piVar7;
        }
        if (piVar7 == piVar4) {
LAB_00a1a88d:
          iVar5 = *piVar4;
          puStack_18 = &uStack_2c;
          puVar3 = *(undefined4 **)(iVar5 + 4);
          uVar6 = FUN_00a1a160(iVar5,puVar3,&DAT_018bdeda,&puStack_18,&uStack_11);
          if (*(int *)(iStack_34 + 0x68) == 0xaaaaaa9) {
                    /* WARNING: Subroutine does not return */
            FUN_016ddcd9("list<T> too long");
          }
          *(int *)(iStack_34 + 0x68) = *(int *)(iStack_34 + 0x68) + 1;
          *(undefined4 *)(iVar5 + 4) = uVar6;
          *puVar3 = uVar6;
          FUN_00a1a190(&piStack_20,*(int *)*puVar1 + 8,*(int *)*puVar1);
          piVar7 = piStack_20;
        }
        piVar4 = (int *)FUN_01677490(DAT_01ee6c30,
                                     "Adding asset with sourceAssetId %lld new count is %d",
                                     (int)uStack_2c,piVar7[4],0);
      }
    }
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_30 + 1;
    iVar5 = *piVar2;
    piVar4 = (int *)*piVar2;
    *piVar2 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar2 = piStack_30 + 2;
      iVar5 = *piVar2;
      piVar4 = (int *)*piVar2;
      *piVar2 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        piVar4 = (int *)(**(code **)(*piStack_30 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar2 = param_2 + 1;
    iVar5 = *piVar2;
    piVar4 = (int *)*piVar2;
    *piVar2 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      piVar4 = (int *)(**(code **)*param_2)();
      LOCK();
      piVar2 = param_2 + 2;
      iVar5 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        piVar4 = (int *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 20029 ; VA 0x00a1a980 ; FUN_00a1a980 */

int __thiscall FUN_00a1a980(int param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006d1810();
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x5c);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x58);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x80);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20030 ; VA 0x00a1aa40 ; FUN_00a1aa40 */

uint __thiscall FUN_00a1aa40(int param_1,byte *param_2)

{
  return *(uint *)(param_1 + 0x18) &
         ((((((((*param_2 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_2[1]) * 0x1000193 ^
              (uint)param_2[2]) * 0x1000193 ^ (uint)param_2[3]) * 0x1000193 ^ (uint)param_2[4]) *
            0x1000193 ^ (uint)param_2[5]) * 0x1000193 ^ (uint)param_2[6]) * 0x1000193 ^
         (uint)param_2[7]) * 0x1000193;
}



/* FUNCTION 20031 ; VA 0x00a1aac0 ; FUN_00a1aac0 */

void __thiscall FUN_00a1aac0(int param_1,int param_2)

{
  uint uVar1;
  int iStack_8;
  
  uVar1 = param_2 * 2;
  if ((uint)(*(int *)(param_1 + 0x14) - *(int *)(param_1 + 0xc) >> 2) < uVar1) {
    iStack_8 = param_1;
    if (0x3fffffff < uVar1) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_005cb650(uVar1);
  }
  iStack_8 = *(int *)(param_1 + 4);
  FUN_00a1ab20(uVar1,&iStack_8);
  *(int *)(param_1 + 0x1c) = param_2;
  *(int *)(param_1 + 0x18) = param_2 + -1;
  return;
}



/* FUNCTION 20032 ; VA 0x00a1ab20 ; FUN_00a1ab20 */

void __thiscall FUN_00a1ab20(int *param_1,uint param_2,undefined4 *param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  
  iVar3 = *param_1;
  uVar5 = param_1[2] - iVar3 >> 2;
  uVar2 = param_1[1] - iVar3 >> 2;
  if (uVar5 < param_2) {
    if (0x3fffffff < param_2) {
LAB_00a1ac28:
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar2 = param_2;
    if ((uVar5 <= 0x3fffffff - (uVar5 >> 1)) && (uVar2 = (uVar5 >> 1) + uVar5, uVar2 < param_2)) {
      uVar2 = param_2;
    }
    if (iVar3 != 0) {
      FUN_0057d270(iVar3,uVar5);
    }
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    if (uVar2 != 0) {
      if (0x3fffffff < uVar2) goto LAB_00a1ac28;
      iVar3 = FUN_00577ed0(uVar2);
      *param_1 = iVar3;
      param_1[1] = iVar3;
      param_1[2] = *param_1 + uVar2 * 4;
    }
    puVar4 = (undefined4 *)*param_1;
    if (param_2 != 0) {
      do {
        *puVar4 = *param_3;
        puVar4 = puVar4 + 1;
        param_2 = param_2 - 1;
      } while (param_2 != 0);
      param_1[1] = (int)puVar4;
      return;
    }
  }
  else {
    if (param_2 <= uVar2) {
      iVar1 = iVar3 + param_2 * 4;
      FUN_005ca6d0(iVar3,iVar1,param_3);
      param_1[1] = iVar1;
      return;
    }
    FUN_005ca6d0(iVar3,param_1[1],param_3);
    puVar4 = (undefined4 *)param_1[1];
    for (iVar3 = param_2 - uVar2; iVar3 != 0; iVar3 = iVar3 + -1) {
      *puVar4 = *param_3;
      puVar4 = puVar4 + 1;
    }
  }
  param_1[1] = (int)puVar4;
  return;
}



/* FUNCTION 20033 ; VA 0x00a1ac30 ; FUN_00a1ac30 */

void __fastcall FUN_00a1ac30(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  piVar2 = (int *)param_1[1];
  piVar3 = (int *)*piVar2;
  ExceptionList = &pvStack_10;
  *piVar2 = (int)piVar2;
  *(int *)(param_1[1] + 4) = param_1[1];
  param_1[2] = 0;
  piVar2 = (int *)param_1[1];
  piStack_14 = param_1;
  if (piVar3 != piVar2) {
    do {
      piVar1 = (int *)*piVar3;
      FUN_01674ea0(piVar3,0x18);
      piVar2 = (int *)param_1[1];
      piVar3 = piVar1;
    } while (piVar1 != piVar2);
  }
  if ((uint)(param_1[5] - param_1[3] >> 2) < 0x10) {
    FUN_005cb650(0x10);
    piVar2 = (int *)param_1[1];
  }
  piStack_14 = piVar2;
  FUN_00a1ab20(0x10,&piStack_14);
  param_1[6] = 7;
  param_1[7] = 8;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20034 ; VA 0x00a1acd0 ; FUN_00a1acd0 */

int FUN_00a1acd0(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00a1a5d0(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20035 ; VA 0x00a1ad60 ; FUN_00a1ad60 */

int FUN_00a1ad60(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00a1a7b0(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20036 ; VA 0x00a1adf0 ; FUN_00a1adf0 */

void __thiscall FUN_00a1adf0(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  iVar2 = FUN_00a1aa40(param_3 + 2);
  iVar2 = iVar2 * 8;
  piVar1 = *(int **)(*(int *)(param_1 + 0xc) + iVar2);
  piVar3 = (int *)(*(int *)(param_1 + 0xc) + iVar2);
  if ((int *)piVar3[1] == param_3) {
    if (piVar1 == param_3) {
      *piVar3 = *(int *)(param_1 + 4);
      *(undefined4 *)(*(int *)(param_1 + 0xc) + 4 + iVar2) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar3[1] = param_3[1];
    }
  }
  else if (piVar1 == param_3) {
    *piVar3 = *param_3;
  }
  iVar2 = *param_3;
  *(int *)param_3[1] = iVar2;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_01674ea0(param_3,0x18);
  *param_2 = iVar2;
  return;
}



/* FUNCTION 20037 ; VA 0x00a1ae70 ; FUN_00a1ae70 */

int __thiscall FUN_00a1ae70(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  int *piVar6;
  int iVar7;
  int *piVar8;
  
  iVar3 = FUN_00a1aa40(param_2);
  piVar1 = *(int **)(param_1 + 4);
  piVar2 = *(int **)(*(int *)(param_1 + 0xc) + iVar3 * 8);
  puVar4 = (undefined4 *)(iVar3 * 8 + 4 + *(int *)(param_1 + 0xc));
  piVar8 = piVar2;
  while( true ) {
    piVar5 = piVar1;
    if (piVar2 != piVar1) {
      piVar5 = *(int **)*puVar4;
    }
    if (piVar8 == piVar5) goto LAB_00a1af11;
    if ((piVar8[2] == *param_2) && (piVar5 = piVar8, piVar8[3] == param_2[1])) break;
    piVar8 = (int *)*piVar8;
  }
  while( true ) {
    piVar6 = piVar1;
    if (piVar2 != piVar1) {
      piVar6 = *(int **)*puVar4;
    }
    if (((piVar5 == piVar6) || (*param_2 != piVar5[2])) || (param_2[1] != piVar5[3])) break;
    piVar5 = (int *)*piVar5;
  }
  if (piVar8 == piVar5) {
LAB_00a1af11:
    piVar8 = piVar1;
    piVar5 = piVar1;
  }
  iVar3 = 0;
  for (piVar2 = piVar8; piVar2 != piVar5; piVar2 = (int *)*piVar2) {
    iVar3 = iVar3 + 1;
  }
  if ((piVar8 == (int *)*piVar1) && (piVar5 == piVar1)) {
    FUN_00a1ac30();
    return iVar3;
  }
  if (piVar8 != piVar5) {
    do {
      piVar1 = (int *)*piVar8;
      iVar7 = FUN_00a1aa40(piVar8 + 2);
      iVar7 = iVar7 * 8;
      piVar2 = *(int **)(*(int *)(param_1 + 0xc) + iVar7);
      puVar4 = (undefined4 *)(*(int *)(param_1 + 0xc) + iVar7);
      if ((int *)puVar4[1] == piVar8) {
        if (piVar2 == piVar8) {
          *puVar4 = *(undefined4 *)(param_1 + 4);
          *(undefined4 *)(iVar7 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
        }
        else {
          puVar4[1] = piVar8[1];
        }
      }
      else if (piVar2 == piVar8) {
        *puVar4 = piVar1;
      }
      *(int *)piVar8[1] = *piVar8;
      *(int *)(*piVar8 + 4) = piVar8[1];
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
      FUN_01674ea0(piVar8,0x18);
      piVar8 = piVar1;
    } while (piVar1 != piVar5);
    return iVar3;
  }
  return iVar3;
}



/* FUNCTION 20038 ; VA 0x00a1afe0 ; FUN_00a1afe0 */

int __thiscall FUN_00a1afe0(undefined4 param_1,undefined4 *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int *piVar7;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dba0a;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  uStack_20 = param_1;
  FUN_008a4210(param_2,param_3);
  if (iVar4 == 0) {
    FUN_01679490();
    iVar4 = FUN_01679490();
    ExceptionList = pvStack_10;
    return iVar4;
  }
  iStack_1c = FUN_008f7870(param_1);
  puVar5 = (undefined4 *)FUN_006ebdf0(auStack_38,param_1);
  piVar7 = (int *)puVar5[1];
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar7[2] = piVar7[2] + 1;
    UNLOCK();
    piVar7 = (int *)puVar5[1];
  }
  param_3 = *puVar5;
  uStack_8 = 0;
  uStack_30 = param_3;
  piStack_2c = piVar7;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_34[1] + -1;
    piStack_34[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      iVar4 = piStack_34[2] + -1;
      piStack_34[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  FUN_008a40f0();
  iStack_18 = FUN_008a4100();
  iStack_18 = iStack_18 + 0x10;
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar7[2] = piVar7[2] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 2;
  uVar6 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 3;
  puStack_24 = (undefined4 *)uVar6;
  puStack_28 = (undefined4 *)FUN_01674e20(0x20);
  if (puStack_28 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puStack_28 = 0;
    puStack_28[1] = 1;
    puStack_28[2] = FUN_00a1ad60;
    puStack_28[3] = FUN_005d3660;
    puStack_28[4] = 0;
    puStack_28[5] = iStack_18;
    puStack_28[6] = 0;
    puStack_28[7] = 0;
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar7[2] = piVar7[2] + 1;
      UNLOCK();
    }
    puStack_28[6] = param_3;
    puStack_28[7] = piVar7;
    puVar5 = puStack_28;
  }
  FUN_016797d0(puVar5);
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_14 = 1;
  uStack_8._0_1_ = 4;
  param_2 = puVar5;
  FUN_01675290(uVar6);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar3 = FUN_01679300(&param_2);
  if (cVar3 != '\0') {
    FUN_01679490();
    FUN_016791c0(&param_2);
  }
  uStack_14 = 0;
  if (param_2 != (undefined4 *)0x0) {
    piVar1 = param_2 + 1;
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(param_2);
    }
  }
  uStack_8 = uStack_8 & 0xffffff00;
  piVar1 = piVar7 + 2;
  if (piVar7 != (int *)0x0) {
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)(*piVar7 + 4))();
    }
  }
  FUN_008a40f0();
  iStack_1c = FUN_008a4100();
  iStack_1c = iStack_1c + 0x14;
  if (piVar7 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 6;
  uVar6 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 7;
  puStack_28 = (undefined4 *)uVar6;
  puStack_24 = (undefined4 *)FUN_01674e20(0x20);
  if (puStack_24 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puStack_24 = 0;
    puStack_24[1] = 1;
    puStack_24[2] = FUN_00a1acd0;
    puStack_24[3] = FUN_005d3660;
    puStack_24[4] = 0;
    puStack_24[5] = iStack_1c;
    puStack_24[6] = 0;
    puStack_24[7] = 0;
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar7[2] = piVar7[2] + 1;
      UNLOCK();
    }
    puStack_24[6] = param_3;
    puStack_24[7] = piVar7;
    puVar5 = puStack_24;
  }
  FUN_016797d0(puVar5);
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_14 = 2;
  uStack_8._0_1_ = 8;
  param_2 = puVar5;
  FUN_01675290(uVar6);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  iVar4 = FUN_01679300(&param_2);
  if ((char)iVar4 != '\0') {
    FUN_01679490();
    iVar4 = FUN_016791c0(&param_2);
  }
  if (param_2 != (undefined4 *)0x0) {
    piVar1 = param_2 + 1;
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    iVar4 = iVar4 + -1;
    if (iVar4 == 0) {
      iVar4 = FUN_01674ea0(param_2);
    }
  }
  if (piVar7 != (int *)0x0) {
    piVar1 = piVar7 + 2;
    LOCK();
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)(*piVar7 + 4))();
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      iVar4 = (**(code **)(*piVar7 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 20039 ; VA 0x00a1b330 ; FUN_00a1b330 */

int __thiscall FUN_00a1b330(int param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  int iVar4;
  undefined *puVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  uint *puVar9;
  undefined auStack_210 [16];
  undefined4 uStack_200;
  undefined4 uStack_1fc;
  uint uStack_1f8;
  undefined4 uStack_1f4;
  undefined4 uStack_1f0;
  undefined4 uStack_1ec;
  undefined8 uStack_1e8;
  undefined auStack_1e0 [16];
  undefined4 uStack_1d0;
  undefined4 uStack_1cc;
  uint uStack_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined8 uStack_1b8;
  undefined uStack_1b0;
  undefined4 uStack_1a0;
  undefined4 uStack_19c;
  uint uStack_198;
  undefined4 uStack_194;
  undefined4 uStack_190;
  undefined4 uStack_18c;
  undefined8 uStack_188;
  undefined uStack_180;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  uint uStack_168;
  undefined4 uStack_164;
  undefined4 uStack_160;
  undefined4 uStack_15c;
  undefined8 uStack_158;
  undefined uStack_150;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  uint uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  uint uStack_120;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  uint uStack_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  uint uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  uint uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  uint uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  uint auStack_a8 [4];
  undefined4 uStack_98;
  uint uStack_94;
  uint auStack_90 [4];
  undefined4 uStack_80;
  uint uStack_7c;
  uint auStack_78 [4];
  undefined4 uStack_68;
  uint uStack_64;
  undefined auStack_60 [4];
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  int *piStack_48;
  int iStack_44;
  int iStack_40;
  undefined4 *puStack_3c;
  int iStack_38;
  undefined2 uStack_34;
  int iStack_30;
  undefined auStack_17 [3];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dbacf;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_008f78c0(param_1);
  if (iVar4 == 0) {
    ExceptionList = pvStack_10;
    return 0;
  }
  piVar1 = *(int **)(iVar4 + 0x43c);
  piStack_48 = *(int **)(param_1 + 100);
  piVar8 = (int *)*piStack_48;
  iStack_14 = *piVar1 - (int)piVar1;
  iStack_40 = piVar1[1] - (int)piVar1;
  iStack_44 = *(int *)(iVar4 + 0x450);
  iVar4 = 0;
  iStack_30 = 0;
  if (piVar8 != piStack_48) {
    do {
      iVar4 = piVar8[3];
      iVar2 = piVar8[2];
      if ((iVar4 < 1) && (iVar4 < 0)) {
        iVar4 = FUN_0055c3d0(auStack_17,-iVar2,-(iVar4 + (uint)(iVar2 != 0)));
        *(undefined *)(iVar4 + -1) = 0x2d;
        puVar5 = (undefined *)(iVar4 + -1);
      }
      else {
        puVar5 = (undefined *)FUN_0055c3d0(auStack_17,iVar2,iVar4);
      }
      uStack_b0 = 0;
      uStack_ac = 0xf;
      uStack_c0 = uStack_c0 & 0xffffff00;
      if (puVar5 != auStack_17) {
        FUN_005542c0(puVar5,(int)auStack_17 - (int)puVar5);
      }
      uStack_8 = 0;
      uStack_200 = 0;
      uStack_1fc = 0xf;
      auStack_210[0] = 0;
      FUN_005542c0("assetId",7);
      uStack_1f8 = uStack_c0;
      uStack_1f4 = uStack_bc;
      uStack_1f0 = uStack_b8;
      uStack_1ec = uStack_b4;
      uStack_1e8 = CONCAT44(uStack_ac,uStack_b0);
      iVar4 = piVar8[4];
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (iVar4 < 0) {
        iVar4 = FUN_00591870(auStack_17,-iVar4);
        *(undefined *)(iVar4 + -1) = 0x2d;
        puVar5 = (undefined *)(iVar4 + -1);
      }
      else {
        puVar5 = (undefined *)FUN_00591870(auStack_17,iVar4);
      }
      uStack_c8 = 0;
      uStack_c4 = 0xf;
      uStack_d8 = uStack_d8 & 0xffffff00;
      if (puVar5 != auStack_17) {
        FUN_005542c0(puVar5,(int)auStack_17 - (int)puVar5);
      }
      uStack_8._0_1_ = 3;
      uStack_1d0 = 0;
      uStack_1cc = 0xf;
      auStack_1e0[0] = 0;
      FUN_005542c0("assetCount",10);
      uStack_1c8 = uStack_d8;
      uStack_1c4 = uStack_d4;
      uStack_1c0 = uStack_d0;
      uStack_1bc = uStack_cc;
      uStack_1b8 = CONCAT44(uStack_c4,uStack_c8);
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      if ((iStack_40 < 1) && (iStack_40 < 0)) {
        iVar4 = FUN_0055c3d0(auStack_17,-iStack_14,-(iStack_40 + (uint)(iStack_14 != 0)));
        *(undefined *)(iVar4 + -1) = 0x2d;
        puVar5 = (undefined *)(iVar4 + -1);
      }
      else {
        puVar5 = (undefined *)FUN_0055c3d0(auStack_17,iStack_14,iStack_40);
      }
      uStack_e0 = 0;
      uStack_dc = 0xf;
      uStack_f0 = uStack_f0 & 0xffffff00;
      if (puVar5 != auStack_17) {
        FUN_005542c0(puVar5,(int)auStack_17 - (int)puVar5);
      }
      uStack_8._0_1_ = 6;
      uStack_1a0 = 0;
      uStack_19c = 0xf;
      uStack_1b0 = 0;
      FUN_005542c0("placeId",7);
      uStack_198 = uStack_f0;
      uStack_194 = uStack_ec;
      uStack_190 = uStack_e8;
      uStack_18c = uStack_e4;
      uStack_188 = CONCAT44(uStack_dc,uStack_e0);
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      if (iStack_44 < 0) {
        iVar4 = FUN_00591870(auStack_17,-iStack_44);
        *(undefined *)(iVar4 + -1) = 0x2d;
        puVar5 = (undefined *)(iVar4 + -1);
      }
      else {
        puVar5 = (undefined *)FUN_00591870(auStack_17,iStack_44);
      }
      uStack_f8 = 0;
      uStack_f4 = 0xf;
      uStack_108 = uStack_108 & 0xffffff00;
      if (puVar5 != auStack_17) {
        FUN_005542c0(puVar5,(int)auStack_17 - (int)puVar5);
      }
      uStack_8._0_1_ = 9;
      uStack_170 = 0;
      uStack_16c = 0xf;
      uStack_180 = 0;
      FUN_005542c0("placeVersion",0xc);
      uStack_168 = uStack_108;
      uStack_164 = uStack_104;
      uStack_160 = uStack_100;
      uStack_15c = uStack_fc;
      uStack_158 = CONCAT44(uStack_f4,uStack_f8);
      uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
      if ((param_3 < 1) && (param_3 < 0)) {
        iVar4 = FUN_0055c3d0(auStack_17,-param_2,-(param_3 + (uint)(param_2 != 0)));
        *(undefined *)(iVar4 + -1) = 0x2d;
        puVar5 = (undefined *)(iVar4 + -1);
      }
      else {
        puVar5 = (undefined *)FUN_0055c3d0(auStack_17,param_2,param_3);
      }
      uStack_110 = 0;
      uStack_10c = 0xf;
      uStack_120 = uStack_120 & 0xffffff00;
      if (puVar5 != auStack_17) {
        FUN_005542c0(puVar5,(int)auStack_17 - (int)puVar5);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
      uStack_140 = 0;
      uStack_13c = 0xf;
      uStack_150 = 0;
      FUN_005542c0("userId",6);
      uStack_138 = uStack_120;
      uStack_134 = uStack_11c;
      uStack_130 = uStack_118;
      uStack_12c = uStack_114;
      uStack_128 = uStack_110;
      uStack_124 = uStack_10c;
      uStack_8 = 0xd;
      auStack_60[0] = 0;
      uStack_5c = FUN_00588320(0xb);
      uStack_58 = 0;
      uStack_54 = 0x3f800000;
      uStack_50 = 0;
      uStack_4c = 0;
      puStack_3c = &uStack_5c;
      iStack_38 = 0;
      uStack_34 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
      FUN_00636840(&puStack_3c,auStack_210,auStack_210,&uStack_120);
      puVar9 = (uint *)auStack_1e0;
      do {
        FUN_00636840(&puStack_3c,puVar9,puVar9,&uStack_120);
        piVar1 = piStack_48;
        puVar9 = puVar9 + 0xc;
      } while (puVar9 != &uStack_120);
      if (iStack_38 != 0) {
        if (uStack_34._1_1_ != '\0') {
          FUN_005509f0();
        }
        FUN_01674ea0(iStack_38,0x38);
      }
      uStack_8._0_1_ = 0x10;
      uStack_98 = 0;
      uStack_94 = 0xf;
      auStack_a8[0] = auStack_a8[0] & 0xffffff00;
      FUN_005542c0("MarketplaceAssetsAdopted",0x18);
      uStack_8._0_1_ = 0x11;
      uStack_80 = 0;
      uStack_7c = 0xf;
      auStack_90[0] = auStack_90[0] & 0xffffff00;
      FUN_005542c0("Marketplace",0xb);
      uStack_8._0_1_ = 0x12;
      uStack_68 = 0;
      uStack_64 = 0xf;
      auStack_78[0] = auStack_78[0] & 0xffffff00;
      FUN_005542c0("studio",6);
      uStack_8._0_1_ = 0x13;
      FUN_008794f0(auStack_78,auStack_90,auStack_a8,auStack_60);
      uStack_8._0_1_ = 0x12;
      uVar3 = (undefined)uStack_8;
      uStack_8._0_1_ = 0x12;
      if (0xf < uStack_64) {
        uVar7 = uStack_64 + 1;
        uVar6 = auStack_78[0];
        if (0xfff < uVar7) {
          uVar6 = *(uint *)(auStack_78[0] - 4);
          uVar7 = uStack_64 + 0x24;
          if (0x1f < (auStack_78[0] - uVar6) - 4) goto LAB_00a1b9fc;
        }
        FUN_01674ea0(uVar6,uVar7);
      }
      uStack_68 = 0;
      uStack_64 = 0xf;
      auStack_78[0] = auStack_78[0] & 0xffffff00;
      uStack_8._0_1_ = 0x11;
      if (0xf < uStack_7c) {
        uVar7 = uStack_7c + 1;
        uVar6 = auStack_90[0];
        if (0xfff < uVar7) {
          uVar6 = *(uint *)(auStack_90[0] - 4);
          uVar7 = uStack_7c + 0x24;
          uVar3 = (undefined)uStack_8;
          if (0x1f < (auStack_90[0] - uVar6) - 4) goto LAB_00a1b9fc;
        }
        FUN_01674ea0(uVar6,uVar7);
      }
      uStack_80 = 0;
      uStack_7c = 0xf;
      auStack_90[0] = auStack_90[0] & 0xffffff00;
      uStack_8._0_1_ = 0x10;
      if (0xf < uStack_94) {
        uVar7 = uStack_94 + 1;
        uVar6 = auStack_a8[0];
        if (0xfff < uVar7) {
          uVar6 = *(uint *)(auStack_a8[0] - 4);
          uVar7 = uStack_94 + 0x24;
          uVar3 = (undefined)uStack_8;
          if (0x1f < (auStack_a8[0] - uVar6) - 4) {
LAB_00a1b9fc:
            uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar6,uVar7);
      }
      uStack_98 = 0;
      uStack_94 = 0xf;
      auStack_a8[0] = auStack_a8[0] & 0xffffff00;
      FUN_0056cfd0();
      uStack_8 = 0xffffffff;
      FUN_016f32d1(auStack_210,0x30,5,FUN_005509f0);
      if (DAT_01ee6c30 != '\0') {
        FUN_01677490(DAT_01ee6c30,"Tracking assetCount event: %lld = %d",piVar8[2],piVar8[4],0);
      }
      piVar8 = (int *)*piVar8;
      iVar4 = iStack_30 + 1;
      iStack_30 = iVar4;
    } while (piVar8 != piVar1);
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 20040 ; VA 0x00a1ba10 ; FUN_00a1ba10 */

void FUN_00a1ba10(uint *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint *puVar6;
  
  if (param_1 != param_2) {
    puVar6 = param_1 + 9;
    do {
      uVar2 = *puVar6;
      if (0xf < uVar2) {
        uVar3 = puVar6[-5];
        uVar5 = uVar2 + 1;
        uVar4 = uVar3;
        if (0xfff < uVar5) {
          uVar4 = *(uint *)(uVar3 - 4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (uVar3 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar4,uVar5);
      }
      puVar6[-1] = 0;
      *puVar6 = 0xf;
      *(undefined *)(puVar6 + -5) = 0;
      puVar1 = puVar6 + 3;
      puVar6 = puVar6 + 0xc;
    } while (puVar1 != param_2);
  }
  return;
}



/* FUNCTION 20041 ; VA 0x00a1ba80 ; FUN_00a1ba80 */

void FUN_00a1ba80(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if (param_1 != param_2) {
    do {
      iVar1 = *param_1;
      if (iVar1 != 0) {
        uVar3 = param_1[2] - iVar1 & 0xfffffffc;
        iVar2 = iVar1;
        if (0xfff < uVar3) {
          iVar2 = *(int *)(iVar1 + -4);
          uVar3 = uVar3 + 0x23;
          if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar2,uVar3);
        *param_1 = 0;
        param_1[1] = 0;
        param_1[2] = 0;
      }
      param_1 = param_1 + 3;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 20042 ; VA 0x00a1baf0 ; FUN_00a1baf0 */

int __thiscall FUN_00a1baf0(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  uint uVar11;
  undefined4 *puVar12;
  
  iVar1 = ((int)param_2 - *param_1) / 0x14;
  iVar2 = (param_1[1] - *param_1) / 0x14;
  if (iVar2 == 0xccccccc) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar3 = (param_1[2] - *param_1) / 0x14;
  uVar11 = iVar2 + 1;
  if (uVar3 <= 0xccccccc - (uVar3 >> 1)) {
    uVar11 = (uVar3 >> 1) + uVar3;
    if (uVar11 < iVar2 + 1U) {
      uVar11 = iVar2 + 1U;
    }
  }
  puVar7 = (undefined4 *)FUN_00618130(uVar11);
  uVar4 = param_3[1];
  uVar5 = param_3[2];
  uVar6 = param_3[3];
  puVar8 = puVar7 + iVar1 * 5;
  *puVar8 = *param_3;
  puVar8[1] = uVar4;
  puVar8[2] = uVar5;
  puVar8[3] = uVar6;
  puVar8[4] = param_3[4];
  puVar12 = (undefined4 *)param_1[1];
  puVar9 = (undefined4 *)*param_1;
  puVar10 = puVar7;
  if (param_2 == puVar12) {
    for (; puVar9 != puVar12; puVar9 = puVar9 + 5) {
      uVar4 = puVar9[1];
      uVar5 = puVar9[2];
      uVar6 = puVar9[3];
      *puVar10 = *puVar9;
      puVar10[1] = uVar4;
      puVar10[2] = uVar5;
      puVar10[3] = uVar6;
      puVar10[4] = puVar9[4];
      puVar10 = puVar10 + 5;
    }
  }
  else {
    if (puVar9 != param_2) {
      do {
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        *puVar10 = *puVar9;
        puVar10[1] = uVar4;
        puVar10[2] = uVar5;
        puVar10[3] = uVar6;
        puVar12 = puVar9 + 4;
        puVar9 = puVar9 + 5;
        puVar10[4] = *puVar12;
        puVar10 = puVar10 + 5;
      } while (puVar9 != param_2);
      puVar12 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar12) {
      do {
        uVar4 = param_2[1];
        uVar5 = param_2[2];
        uVar6 = param_2[3];
        puVar8[5] = *param_2;
        puVar8[6] = uVar4;
        puVar8[7] = uVar5;
        puVar8[8] = uVar6;
        puVar9 = param_2 + 4;
        param_2 = param_2 + 5;
        puVar8[9] = *puVar9;
        puVar8 = puVar8 + 5;
      } while (param_2 != puVar12);
    }
  }
  FUN_00845dd0(puVar7,iVar2 + 1,uVar11);
  return *param_1 + iVar1 * 0x14;
}



/* FUNCTION 20043 ; VA 0x00a1bc40 ; FUN_00a1bc40 */

int __thiscall FUN_00a1bc40(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  uint uVar12;
  
  iVar1 = ((int)param_2 - *param_1) / 0x24;
  iVar2 = (param_1[1] - *param_1) / 0x24;
  if (iVar2 == 0x71c71c7) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar3 = (param_1[2] - *param_1) / 0x24;
  uVar12 = iVar2 + 1;
  if (uVar3 <= 0x71c71c7 - (uVar3 >> 1)) {
    uVar12 = (uVar3 >> 1) + uVar3;
    if (uVar12 < iVar2 + 1U) {
      uVar12 = iVar2 + 1U;
    }
  }
  puVar7 = (undefined4 *)FUN_00a203e0(uVar12);
  puVar8 = puVar7 + iVar1 * 9;
  uVar4 = param_3[1];
  uVar5 = param_3[2];
  uVar6 = param_3[3];
  *puVar8 = *param_3;
  puVar8[1] = uVar4;
  puVar8[2] = uVar5;
  puVar8[3] = uVar6;
  uVar4 = param_3[5];
  uVar5 = param_3[6];
  uVar6 = param_3[7];
  puVar8[4] = param_3[4];
  puVar8[5] = uVar4;
  puVar8[6] = uVar5;
  puVar8[7] = uVar6;
  puVar8[8] = param_3[8];
  puVar11 = (undefined4 *)param_1[1];
  puVar9 = (undefined4 *)*param_1;
  if (param_2 == puVar11) {
    FUN_00a203a0(puVar9,puVar11,puVar7);
  }
  else {
    puVar10 = puVar7;
    if (puVar9 != param_2) {
      do {
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        *puVar10 = *puVar9;
        puVar10[1] = uVar4;
        puVar10[2] = uVar5;
        puVar10[3] = uVar6;
        uVar4 = puVar9[5];
        uVar5 = puVar9[6];
        uVar6 = puVar9[7];
        puVar10[4] = puVar9[4];
        puVar10[5] = uVar4;
        puVar10[6] = uVar5;
        puVar10[7] = uVar6;
        puVar11 = puVar9 + 8;
        puVar9 = puVar9 + 9;
        puVar10[8] = *puVar11;
        puVar10 = puVar10 + 9;
      } while (puVar9 != param_2);
      puVar11 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar11) {
      do {
        uVar4 = param_2[1];
        uVar5 = param_2[2];
        uVar6 = param_2[3];
        puVar8[9] = *param_2;
        puVar8[10] = uVar4;
        puVar8[0xb] = uVar5;
        puVar8[0xc] = uVar6;
        uVar4 = param_2[5];
        uVar5 = param_2[6];
        uVar6 = param_2[7];
        puVar8[0xd] = param_2[4];
        puVar8[0xe] = uVar4;
        puVar8[0xf] = uVar5;
        puVar8[0x10] = uVar6;
        puVar9 = param_2 + 8;
        param_2 = param_2 + 9;
        puVar8[0x11] = *puVar9;
        puVar8 = puVar8 + 9;
      } while (param_2 != puVar11);
    }
  }
  FUN_00a200d0(puVar7,iVar2 + 1,uVar12);
  return *param_1 + iVar1 * 0x24;
}



/* FUNCTION 20044 ; VA 0x00a1bd90 ; FUN_00a1bd90 */

int __thiscall FUN_00a1bd90(uint *param_1,uint param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  
  uVar8 = *param_1;
  iVar6 = (int)(param_1[1] - uVar8) / 0x30;
  if (iVar6 == 0x5555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar10 = iVar6 + 1;
  uVar7 = (int)(param_1[2] - uVar8) / 0x30;
  uVar11 = uVar10;
  if ((uVar7 <= 0x5555555 - (uVar7 >> 1)) && (uVar11 = (uVar7 >> 1) + uVar7, uVar11 < uVar10)) {
    uVar11 = uVar10;
  }
  uVar7 = uVar11 * 0x30;
  if (uVar11 < 0x5555556) {
    uVar11 = uVar7;
    if (0xfff < uVar7) goto LAB_00a1be2a;
    if (uVar7 == 0) {
      uVar11 = 0;
    }
    else {
      uVar11 = FUN_01674e20(uVar7);
    }
  }
  else {
    uVar11 = 0xffffffff;
LAB_00a1be2a:
    uVar5 = uVar11 + 0x23;
    if (uVar5 <= uVar11) {
      uVar5 = 0xffffffff;
    }
    iVar6 = FUN_01674e20(uVar5);
    if (iVar6 == 0) goto LAB_00a1bf7b;
    uVar11 = iVar6 + 0x23U & 0xffffffe0;
    *(int *)(uVar11 - 4) = iVar6;
  }
  iVar6 = ((int)(param_2 - uVar8) / 0x30) * 0x30;
  *(undefined4 *)(iVar6 + uVar11) = *param_3;
  *(undefined4 *)(iVar6 + 8 + uVar11) = param_3[2];
  *(undefined4 *)(iVar6 + 0xc + uVar11) = param_3[3];
  *(undefined4 *)(iVar6 + 0x20 + uVar11) = 0;
  *(undefined4 *)(iVar6 + 0x24 + uVar11) = 0;
  uVar2 = param_3[5];
  uVar3 = param_3[6];
  uVar4 = param_3[7];
  puVar1 = (undefined4 *)(iVar6 + 0x10 + uVar11);
  *puVar1 = param_3[4];
  puVar1[1] = uVar2;
  puVar1[2] = uVar3;
  puVar1[3] = uVar4;
  *(undefined8 *)(iVar6 + 0x20 + uVar11) = *(undefined8 *)(param_3 + 8);
  param_3[8] = 0;
  param_3[9] = 0xf;
  *(undefined *)(param_3 + 4) = 0;
  *(undefined4 *)(iVar6 + 0x28 + uVar11) = param_3[10];
  *(undefined4 *)(iVar6 + 0x2c + uVar11) = param_3[0xb];
  uVar5 = param_1[1];
  uVar8 = *param_1;
  uVar9 = uVar11;
  if (param_2 != uVar5) {
    FUN_00a1d790(uVar8,param_2,uVar11,param_1);
    uVar5 = param_1[1];
    uVar9 = iVar6 + 0x30 + uVar11;
    uVar8 = param_2;
  }
  FUN_00a1d790(uVar8,uVar5,uVar9,param_1);
  if (*param_1 != 0) {
    FUN_00a1ba10(*param_1,param_1[1],param_1);
    uVar8 = *param_1;
    uVar9 = ((int)(param_1[2] - uVar8) / 0x30) * 0x30;
    uVar5 = uVar8;
    if (0xfff < uVar9) {
      uVar5 = *(uint *)(uVar8 - 4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (uVar8 - uVar5) - 4) {
LAB_00a1bf7b:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar9);
  }
  *param_1 = uVar11;
  param_1[1] = uVar10 * 0x30 + uVar11;
  param_1[2] = uVar7 + uVar11;
  return *param_1 + iVar6;
}



/* FUNCTION 20045 ; VA 0x00a1bf90 ; FUN_00a1bf90 */

void __thiscall
FUN_00a1bf90(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x7fffffd < (uint)param_1[1]) {
    FUN_00a20150(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00a1c042:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00a1c042;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 20046 ; VA 0x00a1c0f0 ; FUN_00a1c0f0 */

undefined4 * __thiscall
FUN_00a1c0f0(undefined4 *param_1,undefined4 *param_2,int *param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined auStack_24 [4];
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dbae0;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  puStack_20 = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd0;
    FUN_00a1bf90(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar3 = (int *)*param_1;
  if (param_3 == (int *)*piVar3) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd0;
    cVar2 = FUN_00a20020(*param_4,param_3[4]);
    if (cVar2 != '\0') {
      FUN_00a1bf90(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar3) {
    iVar1 = piVar3[2];
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd0;
    cVar2 = FUN_00a20020(*(undefined4 *)(iVar1 + 0x10),*param_4);
    if (cVar2 != '\0') {
      FUN_00a1bf90(param_2,0,iVar1,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    uStack_1c = *param_4;
    ExceptionList = &pvStack_10;
    cVar2 = FUN_00a20020(uStack_1c,param_3[4]);
    if (cVar2 != '\0') {
      piStack_18 = param_3;
      piVar3 = (int *)FUN_0056f560();
      cVar2 = FUN_00a20020(*(undefined4 *)(*piVar3 + 0x10),*param_4);
      if (cVar2 != '\0') {
        if (*(char *)(piStack_18[2] + 0xd) == '\0') {
          FUN_00a1bf90(param_2,1,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00a1bf90(param_2,0,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    cVar2 = FUN_00a20020(param_3[4],*param_4);
    if (cVar2 != '\0') {
      piStack_18 = param_3;
      FUN_00551320();
      piVar3 = piStack_18;
      if ((piStack_18 == (int *)*param_1) ||
         (cVar2 = FUN_00a20020(uStack_1c,piStack_18[4]), cVar2 != '\0')) {
        if (*(char *)(param_3[2] + 0xd) == '\0') {
          FUN_00a1bf90(param_2,1,piVar3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00a1bf90(param_2,0,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = (undefined4 *)FUN_00a1c330(auStack_24,0,param_4,param_5);
  *param_2 = *puVar4;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20047 ; VA 0x00a1c315 ; Catch_All@00a1c315 */

void Catch_All_00a1c315(void)

{
  int unaff_EBP;
  
  FUN_00a20150(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20048 ; VA 0x00a1c330 ; FUN_00a1c330 */

void __thiscall
FUN_00a1c330(undefined4 *param_1,undefined4 *param_2,char param_3,int *param_4,int param_5)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  byte bVar6;
  char cVar7;
  uint uVar8;
  undefined4 *puVar9;
  byte *pbVar10;
  byte *pbVar11;
  int *piVar12;
  int *piVar13;
  bool bVar14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dbaf0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  bVar6 = 1;
  uStack_8 = 0;
  piVar13 = piVar1;
  if (*(char *)(piVar1[1] + 0xd) == '\0') {
    piVar12 = (int *)piVar1[1];
    do {
      piVar13 = piVar12;
      if (param_3 == '\0') {
        pbVar11 = *(byte **)(*param_4 + 4);
        pbVar10 = *(byte **)(piVar13[4] + 4);
        if (pbVar11 == pbVar10) {
          bVar6 = 0;
          goto LAB_00a1c4e6;
        }
        uVar2 = *(uint *)(pbVar10 + 0x10);
        if (0xf < *(uint *)(pbVar10 + 0x14)) {
          pbVar10 = *(byte **)pbVar10;
        }
        uVar3 = *(uint *)(pbVar11 + 0x10);
        if (0xf < *(uint *)(pbVar11 + 0x14)) {
          pbVar11 = *(byte **)pbVar11;
        }
        uVar8 = uVar3;
        if (uVar2 < uVar3) {
          uVar8 = uVar2;
        }
        while (uVar4 = uVar8 - 4, 3 < uVar8) {
          if (*(int *)pbVar11 != *(int *)pbVar10) goto LAB_00a1c496;
          pbVar11 = pbVar11 + 4;
          pbVar10 = pbVar10 + 4;
          uVar8 = uVar4;
        }
        if (uVar4 == 0xfffffffc) {
LAB_00a1c4ca:
          uVar8 = 0;
        }
        else {
LAB_00a1c496:
          bVar14 = *pbVar11 < *pbVar10;
          if ((*pbVar11 == *pbVar10) &&
             ((uVar4 == 0xfffffffd ||
              ((bVar14 = pbVar11[1] < pbVar10[1], pbVar11[1] == pbVar10[1] &&
               ((uVar4 == 0xfffffffe ||
                ((bVar14 = pbVar11[2] < pbVar10[2], pbVar11[2] == pbVar10[2] &&
                 ((uVar4 == 0xffffffff ||
                  (bVar14 = pbVar11[3] < pbVar10[3], pbVar11[3] == pbVar10[3]))))))))))))
          goto LAB_00a1c4ca;
          uVar8 = -(uint)bVar14 | 1;
        }
        if (uVar8 == 0) {
          if (uVar3 < uVar2) {
            uVar8 = 0xffffffff;
          }
          else {
            uVar8 = 0;
          }
        }
        bVar6 = (byte)(uVar8 >> 0x1f);
      }
      else {
        pbVar11 = *(byte **)(piVar13[4] + 4);
        pbVar10 = *(byte **)(*param_4 + 4);
        if (pbVar11 == pbVar10) {
          bVar6 = 1;
        }
        else {
          uVar2 = *(uint *)(pbVar10 + 0x10);
          if (0xf < *(uint *)(pbVar10 + 0x14)) {
            pbVar10 = *(byte **)pbVar10;
          }
          uVar3 = *(uint *)(pbVar11 + 0x10);
          if (0xf < *(uint *)(pbVar11 + 0x14)) {
            pbVar11 = *(byte **)pbVar11;
          }
          uVar8 = uVar3;
          if (uVar2 < uVar3) {
            uVar8 = uVar2;
          }
          while (uVar4 = uVar8 - 4, 3 < uVar8) {
            if (*(int *)pbVar11 != *(int *)pbVar10) goto LAB_00a1c3e6;
            pbVar11 = pbVar11 + 4;
            pbVar10 = pbVar10 + 4;
            uVar8 = uVar4;
          }
          if (uVar4 == 0xfffffffc) {
LAB_00a1c41a:
            uVar8 = 0;
          }
          else {
LAB_00a1c3e6:
            bVar14 = *pbVar11 < *pbVar10;
            if ((*pbVar11 == *pbVar10) &&
               ((uVar4 == 0xfffffffd ||
                ((bVar14 = pbVar11[1] < pbVar10[1], pbVar11[1] == pbVar10[1] &&
                 ((uVar4 == 0xfffffffe ||
                  ((bVar14 = pbVar11[2] < pbVar10[2], pbVar11[2] == pbVar10[2] &&
                   ((uVar4 == 0xffffffff ||
                    (bVar14 = pbVar11[3] < pbVar10[3], pbVar11[3] == pbVar10[3]))))))))))))
            goto LAB_00a1c41a;
            uVar8 = -(uint)bVar14 | 1;
          }
          if (uVar8 == 0) {
            if (uVar3 < uVar2) {
              bVar6 = 0;
              goto LAB_00a1c4e6;
            }
            uVar8 = 0;
          }
          bVar6 = (byte)(uVar8 >> 0x1f) ^ 1;
        }
      }
LAB_00a1c4e6:
      if (bVar6 == 0) {
        piVar12 = (int *)piVar13[2];
      }
      else {
        piVar12 = (int *)*piVar13;
      }
    } while (*(char *)((int)piVar12 + 0xd) == '\0');
  }
  ExceptionList = &pvStack_10;
  _param_3 = piVar13;
  if (bVar6 != 0) {
    if (piVar13 == (int *)*piVar1) {
      bVar6 = 1;
      ExceptionList = &pvStack_10;
      goto LAB_00a1c51d;
    }
    ExceptionList = &pvStack_10;
    FUN_0056f560();
  }
  piVar1 = _param_3;
  cVar7 = FUN_00a20020(_param_3[4],*param_4);
  iVar5 = param_5;
  if (cVar7 == '\0') {
    FUN_006d0070(param_1,param_5 + 0x10);
    FUN_01674ea0(iVar5,0x20);
    *param_2 = piVar1;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00a1c51d:
  puVar9 = (undefined4 *)FUN_00a1bf90(&param_3,bVar6,piVar13,param_4,param_5);
  *param_2 = *puVar9;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20049 ; VA 0x00a1c5a7 ; Catch_All@00a1c5a7 */

void Catch_All_00a1c5a7(void)

{
  int unaff_EBP;
  
  FUN_00a20150(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20050 ; VA 0x00a1c5c0 ; FUN_00a1c5c0 */

int * FUN_00a1c5c0(int *param_1,int *param_2)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  int *piVar8;
  byte *pbVar9;
  byte *pbVar10;
  bool bVar11;
  int iStack_14;
  
  if ((param_1 != param_2) && (piVar6 = param_1 + 1, piVar6 != param_2)) {
    iStack_14 = (int)piVar6 - (int)param_1;
    do {
      iVar1 = *piVar6;
      pbVar10 = *(byte **)(iVar1 + 4);
      pbVar9 = *(byte **)(*param_1 + 4);
      piVar8 = piVar6;
      if (pbVar10 == pbVar9) {
LAB_00a1c6c0:
        while( true ) {
          pbVar10 = *(byte **)(iVar1 + 4);
          iVar4 = piVar8[-1];
          pbVar9 = *(byte **)(iVar4 + 4);
          if (pbVar10 == pbVar9) break;
          uVar2 = *(uint *)(pbVar9 + 0x10);
          if (0xf < *(uint *)(pbVar9 + 0x14)) {
            pbVar9 = *(byte **)pbVar9;
          }
          uVar3 = *(uint *)(pbVar10 + 0x10);
          if (0xf < *(uint *)(pbVar10 + 0x14)) {
            pbVar10 = *(byte **)pbVar10;
          }
          uVar7 = uVar3;
          if (uVar2 < uVar3) {
            uVar7 = uVar2;
          }
          while (uVar5 = uVar7 - 4, 3 < uVar7) {
            if (*(int *)pbVar10 != *(int *)pbVar9) goto LAB_00a1c716;
            pbVar10 = pbVar10 + 4;
            pbVar9 = pbVar9 + 4;
            uVar7 = uVar5;
          }
          if (uVar5 == 0xfffffffc) {
LAB_00a1c74a:
            uVar7 = 0;
          }
          else {
LAB_00a1c716:
            bVar11 = *pbVar10 < *pbVar9;
            if ((*pbVar10 == *pbVar9) &&
               ((uVar5 == 0xfffffffd ||
                ((bVar11 = pbVar10[1] < pbVar9[1], pbVar10[1] == pbVar9[1] &&
                 ((uVar5 == 0xfffffffe ||
                  ((bVar11 = pbVar10[2] < pbVar9[2], pbVar10[2] == pbVar9[2] &&
                   ((uVar5 == 0xffffffff ||
                    (bVar11 = pbVar10[3] < pbVar9[3], pbVar10[3] == pbVar9[3]))))))))))))
            goto LAB_00a1c74a;
            uVar7 = -(uint)bVar11 | 1;
          }
          if (uVar7 == 0) {
            if (uVar3 < uVar2) {
              uVar7 = 0xffffffff;
            }
            else {
              uVar7 = (uint)(uVar2 < uVar3);
            }
          }
          if (-1 < (int)uVar7) break;
          *piVar8 = iVar4;
          piVar8 = piVar8 + -1;
        }
        *piVar8 = iVar1;
      }
      else {
        uVar2 = *(uint *)(pbVar9 + 0x10);
        if (0xf < *(uint *)(pbVar9 + 0x14)) {
          pbVar9 = *(byte **)pbVar9;
        }
        uVar3 = *(uint *)(pbVar10 + 0x10);
        if (0xf < *(uint *)(pbVar10 + 0x14)) {
          pbVar10 = *(byte **)pbVar10;
        }
        uVar7 = uVar3;
        if (uVar2 < uVar3) {
          uVar7 = uVar2;
        }
        while (uVar5 = uVar7 - 4, 3 < uVar7) {
          if (*(int *)pbVar10 != *(int *)pbVar9) goto LAB_00a1c646;
          pbVar10 = pbVar10 + 4;
          pbVar9 = pbVar9 + 4;
          uVar7 = uVar5;
        }
        if (uVar5 == 0xfffffffc) {
LAB_00a1c67a:
          uVar7 = 0;
        }
        else {
LAB_00a1c646:
          bVar11 = *pbVar10 < *pbVar9;
          if ((*pbVar10 == *pbVar9) &&
             ((uVar5 == 0xfffffffd ||
              ((bVar11 = pbVar10[1] < pbVar9[1], pbVar10[1] == pbVar9[1] &&
               ((uVar5 == 0xfffffffe ||
                ((bVar11 = pbVar10[2] < pbVar9[2], pbVar10[2] == pbVar9[2] &&
                 ((uVar5 == 0xffffffff || (bVar11 = pbVar10[3] < pbVar9[3], pbVar10[3] == pbVar9[3])
                  ))))))))))) goto LAB_00a1c67a;
          uVar7 = -(uint)bVar11 | 1;
        }
        if (uVar7 == 0) {
          if (uVar3 < uVar2) {
            uVar7 = 0xffffffff;
          }
          else {
            uVar7 = (uint)(uVar2 < uVar3);
          }
        }
        if (-1 < (int)uVar7) goto LAB_00a1c6c0;
        FUN_0170cc70(param_1 + 1,param_1,iStack_14);
        *param_1 = iVar1;
      }
      iStack_14 = iStack_14 + 4;
      piVar6 = piVar6 + 1;
    } while (piVar6 != param_2);
  }
  return param_2;
}



/* FUNCTION 20051 ; VA 0x00a1c7b0 ; FUN_00a1c7b0 */

void FUN_00a1c7b0(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  byte *pbVar7;
  uint uVar8;
  byte *pbVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  bool bVar13;
  int iStack_8;
  
  uVar5 = param_2 - param_1 >> 2;
  iVar10 = param_2 - param_1 >> 3;
  if (0 < iVar10) {
    iVar6 = (int)(uVar5 - 1) >> 1;
    do {
      iVar1 = *(int *)(param_1 + -4 + iVar10 * 4);
      iVar10 = iVar10 + -1;
      iStack_8 = iVar10;
      while (iStack_8 < iVar6) {
        iVar11 = iStack_8 * 2 + 2;
        pbVar9 = *(byte **)(*(int *)(param_1 + 8 + iStack_8 * 8) + 4);
        pbVar7 = *(byte **)(*(int *)(param_1 + 4 + iStack_8 * 8) + 4);
        if (pbVar9 != pbVar7) {
          uVar2 = *(uint *)(pbVar7 + 0x10);
          if (0xf < *(uint *)(pbVar7 + 0x14)) {
            pbVar7 = *(byte **)pbVar7;
          }
          uVar3 = *(uint *)(pbVar9 + 0x10);
          if (0xf < *(uint *)(pbVar9 + 0x14)) {
            pbVar9 = *(byte **)pbVar9;
          }
          uVar8 = uVar3;
          if (uVar2 < uVar3) {
            uVar8 = uVar2;
          }
          while (uVar4 = uVar8 - 4, 3 < uVar8) {
            if (*(int *)pbVar9 != *(int *)pbVar7) goto LAB_00a1c85d;
            pbVar9 = pbVar9 + 4;
            pbVar7 = pbVar7 + 4;
            uVar8 = uVar4;
          }
          if (uVar4 == 0xfffffffc) {
LAB_00a1c891:
            uVar8 = 0;
          }
          else {
LAB_00a1c85d:
            bVar13 = *pbVar9 < *pbVar7;
            if ((*pbVar9 == *pbVar7) &&
               ((uVar4 == 0xfffffffd ||
                ((bVar13 = pbVar9[1] < pbVar7[1], pbVar9[1] == pbVar7[1] &&
                 ((uVar4 == 0xfffffffe ||
                  ((bVar13 = pbVar9[2] < pbVar7[2], pbVar9[2] == pbVar7[2] &&
                   ((uVar4 == 0xffffffff || (bVar13 = pbVar9[3] < pbVar7[3], pbVar9[3] == pbVar7[3])
                    ))))))))))) goto LAB_00a1c891;
            uVar8 = -(uint)bVar13 | 1;
          }
          if (uVar8 == 0) {
            if (uVar3 < uVar2) {
              uVar8 = 0xffffffff;
            }
            else {
              uVar8 = (uint)(uVar2 < uVar3);
            }
          }
          if ((int)uVar8 < 0) {
            iVar11 = iStack_8 * 2 + 1;
          }
        }
        *(undefined4 *)(param_1 + iStack_8 * 4) = *(undefined4 *)(param_1 + iVar11 * 4);
        iStack_8 = iVar11;
      }
      if ((iStack_8 == iVar6) && ((uVar5 & 1) == 0)) {
        *(undefined4 *)(param_1 + iStack_8 * 4) = *(undefined4 *)(param_1 + -4 + uVar5 * 4);
        iStack_8 = uVar5 - 1;
      }
      if (iVar10 < iStack_8) {
        while( true ) {
          iVar12 = iStack_8 + -1 >> 1;
          iVar11 = *(int *)(param_1 + iVar12 * 4);
          pbVar9 = *(byte **)(iVar1 + 4);
          pbVar7 = *(byte **)(iVar11 + 4);
          if (pbVar7 == pbVar9) break;
          uVar2 = *(uint *)(pbVar9 + 0x10);
          if (0xf < *(uint *)(pbVar9 + 0x14)) {
            pbVar9 = *(byte **)pbVar9;
          }
          uVar3 = *(uint *)(pbVar7 + 0x10);
          if (0xf < *(uint *)(pbVar7 + 0x14)) {
            pbVar7 = *(byte **)pbVar7;
          }
          uVar8 = uVar3;
          if (uVar2 < uVar3) {
            uVar8 = uVar2;
          }
          while (uVar4 = uVar8 - 4, 3 < uVar8) {
            if (*(int *)pbVar7 != *(int *)pbVar9) goto LAB_00a1c956;
            pbVar7 = pbVar7 + 4;
            pbVar9 = pbVar9 + 4;
            uVar8 = uVar4;
          }
          if (uVar4 == 0xfffffffc) {
LAB_00a1c98a:
            uVar8 = 0;
          }
          else {
LAB_00a1c956:
            bVar13 = *pbVar7 < *pbVar9;
            if ((*pbVar7 == *pbVar9) &&
               ((uVar4 == 0xfffffffd ||
                ((bVar13 = pbVar7[1] < pbVar9[1], pbVar7[1] == pbVar9[1] &&
                 ((uVar4 == 0xfffffffe ||
                  ((bVar13 = pbVar7[2] < pbVar9[2], pbVar7[2] == pbVar9[2] &&
                   ((uVar4 == 0xffffffff || (bVar13 = pbVar7[3] < pbVar9[3], pbVar7[3] == pbVar9[3])
                    ))))))))))) goto LAB_00a1c98a;
            uVar8 = -(uint)bVar13 | 1;
          }
          if (uVar8 == 0) {
            if (uVar3 < uVar2) {
              uVar8 = 0xffffffff;
            }
            else {
              uVar8 = (uint)(uVar2 < uVar3);
            }
          }
          if ((-1 < (int)uVar8) ||
             (*(int *)(param_1 + iStack_8 * 4) = iVar11, iStack_8 = iVar12, iVar12 <= iVar10))
          break;
        }
      }
      *(int *)(param_1 + iStack_8 * 4) = iVar1;
    } while (0 < iVar10);
  }
  return;
}



/* FUNCTION 20052 ; VA 0x00a1c9f0 ; FUN_00a1c9f0 */

void FUN_00a1c9f0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 uVar3;
  
  uVar3 = *param_2;
  cVar2 = FUN_00a20020(uVar3,*param_1);
  if (cVar2 != '\0') {
    *param_2 = *param_1;
    *param_1 = uVar3;
    uVar3 = *param_2;
  }
  uVar1 = *param_3;
  cVar2 = FUN_00a20020(uVar1,uVar3);
  if (cVar2 != '\0') {
    *param_3 = uVar3;
    *param_2 = uVar1;
    cVar2 = FUN_00a20020(uVar1,*param_1);
    if (cVar2 != '\0') {
      *param_2 = *param_1;
      *param_1 = uVar1;
    }
  }
  return;
}



/* FUNCTION 20053 ; VA 0x00a1ca60 ; FUN_00a1ca60 */

void FUN_00a1ca60(undefined4 *param_1,int *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  byte *pbVar7;
  int *piVar8;
  byte *pbVar9;
  int *piVar10;
  byte *pbVar11;
  byte *pbVar12;
  bool bVar13;
  int *piStack_10;
  int *piStack_8;
  
  piVar1 = param_2 + ((int)param_3 - (int)param_2 >> 3);
  iVar4 = (int)(param_3 + -1) - (int)param_2 >> 2;
  if (iVar4 < 0x29) {
    FUN_00a1c9f0(param_2,piVar1,param_3 + -1,param_4);
  }
  else {
    iVar4 = iVar4 + 1 >> 3;
    FUN_00a1c9f0(param_2,param_2 + iVar4,param_2 + iVar4 * 2,param_4);
    FUN_00a1c9f0(piVar1 + -iVar4,piVar1,piVar1 + iVar4,param_4);
    piVar10 = param_3 + -1;
    FUN_00a1c9f0(piVar10 + iVar4 * -2,piVar10 + -iVar4,piVar10,param_4);
    FUN_00a1c9f0(param_2 + iVar4,piVar1,piVar10 + -iVar4,param_4);
  }
  param_4 = piVar1 + 1;
  do {
    do {
      do {
        piVar10 = piVar1;
        if (piVar10 <= param_2) goto LAB_00a1cc63;
        piVar1 = piVar10 + -1;
        pbVar7 = *(byte **)(*piVar1 + 4);
        pbVar9 = *(byte **)(*piVar10 + 4);
      } while (pbVar9 == pbVar7);
      pbVar12 = pbVar9;
      if (0xf < *(uint *)(pbVar9 + 0x14)) {
        pbVar12 = *(byte **)pbVar9;
      }
      pbVar11 = pbVar7;
      if (0xf < *(uint *)(pbVar7 + 0x14)) {
        pbVar11 = *(byte **)pbVar7;
      }
      uVar5 = *(uint *)(pbVar7 + 0x10);
      if (*(uint *)(pbVar9 + 0x10) < *(uint *)(pbVar7 + 0x10)) {
        uVar5 = *(uint *)(pbVar9 + 0x10);
      }
      while (uVar2 = uVar5 - 4, 3 < uVar5) {
        if (*(int *)pbVar11 != *(int *)pbVar12) goto LAB_00a1cb66;
        pbVar11 = pbVar11 + 4;
        pbVar12 = pbVar12 + 4;
        uVar5 = uVar2;
      }
      if (uVar2 == 0xfffffffc) {
LAB_00a1cb9a:
        uVar5 = 0;
      }
      else {
LAB_00a1cb66:
        bVar13 = *pbVar11 < *pbVar12;
        if ((*pbVar11 == *pbVar12) &&
           ((uVar2 == 0xfffffffd ||
            ((bVar13 = pbVar11[1] < pbVar12[1], pbVar11[1] == pbVar12[1] &&
             ((uVar2 == 0xfffffffe ||
              ((bVar13 = pbVar11[2] < pbVar12[2], pbVar11[2] == pbVar12[2] &&
               ((uVar2 == 0xffffffff || (bVar13 = pbVar11[3] < pbVar12[3], pbVar11[3] == pbVar12[3])
                ))))))))))) goto LAB_00a1cb9a;
        uVar5 = -(uint)bVar13 | 1;
      }
      if (uVar5 == 0) {
        if (*(uint *)(pbVar7 + 0x10) < *(uint *)(pbVar9 + 0x10)) {
          uVar5 = 0xffffffff;
        }
        else {
          uVar5 = (uint)(*(uint *)(pbVar9 + 0x10) < *(uint *)(pbVar7 + 0x10));
        }
      }
      if ((int)uVar5 < 0) goto LAB_00a1cc63;
    } while (pbVar9 == pbVar7);
    uVar5 = *(uint *)(pbVar7 + 0x10);
    if (0xf < *(uint *)(pbVar7 + 0x14)) {
      pbVar7 = *(byte **)pbVar7;
    }
    uVar2 = *(uint *)(pbVar9 + 0x10);
    if (0xf < *(uint *)(pbVar9 + 0x14)) {
      pbVar9 = *(byte **)pbVar9;
    }
    uVar6 = uVar2;
    if (uVar5 < uVar2) {
      uVar6 = uVar5;
    }
    while (uVar3 = uVar6 - 4, 3 < uVar6) {
      if (*(int *)pbVar9 != *(int *)pbVar7) goto LAB_00a1cbfe;
      pbVar9 = pbVar9 + 4;
      pbVar7 = pbVar7 + 4;
      uVar6 = uVar3;
    }
    if (uVar3 == 0xfffffffc) {
LAB_00a1cc32:
      uVar6 = 0;
    }
    else {
LAB_00a1cbfe:
      bVar13 = *pbVar9 < *pbVar7;
      if ((*pbVar9 == *pbVar7) &&
         ((uVar3 == 0xfffffffd ||
          ((bVar13 = pbVar9[1] < pbVar7[1], pbVar9[1] == pbVar7[1] &&
           ((uVar3 == 0xfffffffe ||
            ((bVar13 = pbVar9[2] < pbVar7[2], pbVar9[2] == pbVar7[2] &&
             ((uVar3 == 0xffffffff || (bVar13 = pbVar9[3] < pbVar7[3], pbVar9[3] == pbVar7[3])))))))
           ))))) goto LAB_00a1cc32;
      uVar6 = -(uint)bVar13 | 1;
    }
    if (uVar6 == 0) {
      if (uVar2 < uVar5) {
        uVar6 = 0xffffffff;
      }
      else {
        uVar6 = (uint)(uVar5 < uVar2);
      }
    }
  } while (-1 < (int)uVar6);
LAB_00a1cc63:
  piVar1 = param_4;
  piStack_8 = piVar10;
  piStack_10 = piVar10;
  if (param_4 < param_3) {
    pbVar7 = *(byte **)(*piVar10 + 4);
    do {
      pbVar9 = *(byte **)(*param_4 + 4);
      if (pbVar7 != pbVar9) {
        pbVar12 = pbVar7;
        if (0xf < *(uint *)(pbVar7 + 0x14)) {
          pbVar12 = *(byte **)pbVar7;
        }
        pbVar11 = pbVar9;
        if (0xf < *(uint *)(pbVar9 + 0x14)) {
          pbVar11 = *(byte **)pbVar9;
        }
        uVar5 = *(uint *)(pbVar9 + 0x10);
        if (*(uint *)(pbVar7 + 0x10) < *(uint *)(pbVar9 + 0x10)) {
          uVar5 = *(uint *)(pbVar7 + 0x10);
        }
        while (uVar2 = uVar5 - 4, 3 < uVar5) {
          if (*(int *)pbVar11 != *(int *)pbVar12) goto LAB_00a1ccbb;
          pbVar11 = pbVar11 + 4;
          pbVar12 = pbVar12 + 4;
          uVar5 = uVar2;
        }
        if (uVar2 == 0xfffffffc) {
LAB_00a1ccef:
          uVar5 = 0;
        }
        else {
LAB_00a1ccbb:
          bVar13 = *pbVar11 < *pbVar12;
          if ((*pbVar11 == *pbVar12) &&
             ((uVar2 == 0xfffffffd ||
              ((bVar13 = pbVar11[1] < pbVar12[1], pbVar11[1] == pbVar12[1] &&
               ((uVar2 == 0xfffffffe ||
                ((bVar13 = pbVar11[2] < pbVar12[2], pbVar11[2] == pbVar12[2] &&
                 ((uVar2 == 0xffffffff ||
                  (bVar13 = pbVar11[3] < pbVar12[3], pbVar11[3] == pbVar12[3]))))))))))))
          goto LAB_00a1ccef;
          uVar5 = -(uint)bVar13 | 1;
        }
        if (uVar5 == 0) {
          if (*(uint *)(pbVar9 + 0x10) < *(uint *)(pbVar7 + 0x10)) {
            uVar5 = 0xffffffff;
          }
          else {
            uVar5 = (uint)(*(uint *)(pbVar7 + 0x10) < *(uint *)(pbVar9 + 0x10));
          }
        }
        piVar1 = param_4;
        if ((int)uVar5 < 0) break;
        if (pbVar7 != pbVar9) {
          uVar5 = *(uint *)(pbVar9 + 0x10);
          if (0xf < *(uint *)(pbVar9 + 0x14)) {
            pbVar9 = *(byte **)pbVar9;
          }
          uVar2 = *(uint *)(pbVar7 + 0x10);
          pbVar12 = pbVar7;
          if (0xf < *(uint *)(pbVar7 + 0x14)) {
            pbVar12 = *(byte **)pbVar7;
          }
          uVar6 = uVar2;
          if (uVar5 < uVar2) {
            uVar6 = uVar5;
          }
          while (uVar3 = uVar6 - 4, 3 < uVar6) {
            if (*(int *)pbVar12 != *(int *)pbVar9) goto LAB_00a1cd5b;
            pbVar12 = pbVar12 + 4;
            pbVar9 = pbVar9 + 4;
            uVar6 = uVar3;
          }
          if (uVar3 == 0xfffffffc) {
LAB_00a1cd8f:
            uVar6 = 0;
          }
          else {
LAB_00a1cd5b:
            bVar13 = *pbVar12 < *pbVar9;
            if ((*pbVar12 == *pbVar9) &&
               ((uVar3 == 0xfffffffd ||
                ((bVar13 = pbVar12[1] < pbVar9[1], pbVar12[1] == pbVar9[1] &&
                 ((uVar3 == 0xfffffffe ||
                  ((bVar13 = pbVar12[2] < pbVar9[2], pbVar12[2] == pbVar9[2] &&
                   ((uVar3 == 0xffffffff ||
                    (bVar13 = pbVar12[3] < pbVar9[3], pbVar12[3] == pbVar9[3]))))))))))))
            goto LAB_00a1cd8f;
            uVar6 = -(uint)bVar13 | 1;
          }
          if (uVar6 == 0) {
            if (uVar2 < uVar5) {
              uVar6 = 0xffffffff;
            }
            else {
              uVar6 = (uint)(uVar5 < uVar2);
            }
          }
          if ((int)uVar6 < 0) break;
        }
      }
      param_4 = param_4 + 1;
      piVar1 = param_4;
    } while (param_4 < param_3);
  }
joined_r0x00a1cdd4:
  do {
    piVar8 = piVar10;
    if (param_3 <= piVar1) {
joined_r0x00a1cf5a:
      while (param_2 < piVar10) {
        piVar8 = piVar8 + -1;
        pbVar7 = *(byte **)(*piVar8 + 4);
        pbVar9 = *(byte **)(*piStack_8 + 4);
        if (pbVar9 == pbVar7) {
LAB_00a1d0a7:
          piStack_8 = piStack_8 + -1;
          if (piStack_8 != piVar8) {
            iVar4 = *piStack_8;
            *piStack_8 = *piVar8;
            *piVar8 = iVar4;
          }
        }
        else {
          pbVar12 = pbVar9;
          if (0xf < *(uint *)(pbVar9 + 0x14)) {
            pbVar12 = *(byte **)pbVar9;
          }
          pbVar11 = pbVar7;
          if (0xf < *(uint *)(pbVar7 + 0x14)) {
            pbVar11 = *(byte **)pbVar7;
          }
          uVar5 = *(uint *)(pbVar7 + 0x10);
          if (*(uint *)(pbVar9 + 0x10) < *(uint *)(pbVar7 + 0x10)) {
            uVar5 = *(uint *)(pbVar9 + 0x10);
          }
          while (uVar2 = uVar5 - 4, 3 < uVar5) {
            if (*(int *)pbVar11 != *(int *)pbVar12) goto LAB_00a1cfb6;
            pbVar11 = pbVar11 + 4;
            pbVar12 = pbVar12 + 4;
            uVar5 = uVar2;
          }
          if (uVar2 == 0xfffffffc) {
LAB_00a1cfea:
            uVar5 = 0;
          }
          else {
LAB_00a1cfb6:
            bVar13 = *pbVar11 < *pbVar12;
            if ((*pbVar11 == *pbVar12) &&
               ((uVar2 == 0xfffffffd ||
                ((bVar13 = pbVar11[1] < pbVar12[1], pbVar11[1] == pbVar12[1] &&
                 ((uVar2 == 0xfffffffe ||
                  ((bVar13 = pbVar11[2] < pbVar12[2], pbVar11[2] == pbVar12[2] &&
                   ((uVar2 == 0xffffffff ||
                    (bVar13 = pbVar11[3] < pbVar12[3], pbVar11[3] == pbVar12[3]))))))))))))
            goto LAB_00a1cfea;
            uVar5 = -(uint)bVar13 | 1;
          }
          if (uVar5 == 0) {
            if (*(uint *)(pbVar7 + 0x10) < *(uint *)(pbVar9 + 0x10)) {
              uVar5 = 0xffffffff;
            }
            else {
              uVar5 = (uint)(*(uint *)(pbVar9 + 0x10) < *(uint *)(pbVar7 + 0x10));
            }
          }
          if (-1 < (int)uVar5) {
            if (pbVar9 == pbVar7) goto LAB_00a1d0a7;
            uVar5 = *(uint *)(pbVar7 + 0x10);
            if (0xf < *(uint *)(pbVar7 + 0x14)) {
              pbVar7 = *(byte **)pbVar7;
            }
            uVar2 = *(uint *)(pbVar9 + 0x10);
            if (0xf < *(uint *)(pbVar9 + 0x14)) {
              pbVar9 = *(byte **)pbVar9;
            }
            uVar6 = uVar2;
            if (uVar5 < uVar2) {
              uVar6 = uVar5;
            }
            while (uVar3 = uVar6 - 4, 3 < uVar6) {
              if (*(int *)pbVar9 != *(int *)pbVar7) goto LAB_00a1d056;
              pbVar9 = pbVar9 + 4;
              pbVar7 = pbVar7 + 4;
              uVar6 = uVar3;
            }
            if (uVar3 == 0xfffffffc) {
LAB_00a1d08a:
              uVar6 = 0;
            }
            else {
LAB_00a1d056:
              bVar13 = *pbVar9 < *pbVar7;
              if ((*pbVar9 == *pbVar7) &&
                 ((uVar3 == 0xfffffffd ||
                  ((bVar13 = pbVar9[1] < pbVar7[1], pbVar9[1] == pbVar7[1] &&
                   ((uVar3 == 0xfffffffe ||
                    ((bVar13 = pbVar9[2] < pbVar7[2], pbVar9[2] == pbVar7[2] &&
                     ((uVar3 == 0xffffffff ||
                      (bVar13 = pbVar9[3] < pbVar7[3], pbVar9[3] == pbVar7[3]))))))))))))
              goto LAB_00a1d08a;
              uVar6 = -(uint)bVar13 | 1;
            }
            if (uVar6 == 0) {
              if (uVar2 < uVar5) {
                uVar6 = 0xffffffff;
              }
              else {
                uVar6 = (uint)(uVar5 < uVar2);
              }
            }
            piVar10 = piStack_10;
            if (-1 < (int)uVar6) goto LAB_00a1d0a7;
            break;
          }
        }
        piStack_10 = piStack_10 + -1;
        piVar10 = piStack_10;
      }
      if (piVar10 == param_2) {
        if (piVar1 == param_3) {
          *param_1 = piStack_8;
          param_1[1] = param_4;
          return;
        }
        if (param_4 != piVar1) {
          iVar4 = *piStack_8;
          *piStack_8 = *param_4;
          *param_4 = iVar4;
        }
        param_4 = param_4 + 1;
        iVar4 = *piStack_8;
        *piStack_8 = *piVar1;
        *piVar1 = iVar4;
        piVar1 = piVar1 + 1;
        piStack_8 = piStack_8 + 1;
      }
      else {
        piVar10 = piVar10 + -1;
        piStack_10 = piVar10;
        if (piVar1 == param_3) {
          piStack_8 = piStack_8 + -1;
          if (piVar10 != piStack_8) {
            iVar4 = *piVar10;
            *piVar10 = *piStack_8;
            *piStack_8 = iVar4;
          }
          iVar4 = *piStack_8;
          param_4 = param_4 + -1;
          *piStack_8 = *param_4;
          *param_4 = iVar4;
        }
        else {
          iVar4 = *piVar1;
          *piVar1 = *piVar10;
          *piVar10 = iVar4;
          piVar1 = piVar1 + 1;
        }
      }
      goto joined_r0x00a1cdd4;
    }
    pbVar7 = *(byte **)(*piStack_8 + 4);
    pbVar9 = *(byte **)(*piVar1 + 4);
    piVar10 = piStack_10;
    if (pbVar9 == pbVar7) {
LAB_00a1cf2a:
      if (param_4 != piVar1) {
        iVar4 = *param_4;
        *param_4 = *piVar1;
        *piVar1 = iVar4;
      }
      param_4 = param_4 + 1;
    }
    else {
      pbVar12 = pbVar9;
      if (0xf < *(uint *)(pbVar9 + 0x14)) {
        pbVar12 = *(byte **)pbVar9;
      }
      pbVar11 = pbVar7;
      if (0xf < *(uint *)(pbVar7 + 0x14)) {
        pbVar11 = *(byte **)pbVar7;
      }
      uVar5 = *(uint *)(pbVar7 + 0x10);
      if (*(uint *)(pbVar9 + 0x10) < *(uint *)(pbVar7 + 0x10)) {
        uVar5 = *(uint *)(pbVar9 + 0x10);
      }
      while (uVar2 = uVar5 - 4, 3 < uVar5) {
        if (*(int *)pbVar11 != *(int *)pbVar12) goto LAB_00a1ce36;
        pbVar11 = pbVar11 + 4;
        pbVar12 = pbVar12 + 4;
        uVar5 = uVar2;
      }
      if (uVar2 == 0xfffffffc) {
LAB_00a1ce6a:
        uVar5 = 0;
      }
      else {
LAB_00a1ce36:
        bVar13 = *pbVar11 < *pbVar12;
        if ((*pbVar11 == *pbVar12) &&
           ((uVar2 == 0xfffffffd ||
            ((bVar13 = pbVar11[1] < pbVar12[1], pbVar11[1] == pbVar12[1] &&
             ((uVar2 == 0xfffffffe ||
              ((bVar13 = pbVar11[2] < pbVar12[2], pbVar11[2] == pbVar12[2] &&
               ((uVar2 == 0xffffffff || (bVar13 = pbVar11[3] < pbVar12[3], pbVar11[3] == pbVar12[3])
                ))))))))))) goto LAB_00a1ce6a;
        uVar5 = -(uint)bVar13 | 1;
      }
      if (uVar5 == 0) {
        if (*(uint *)(pbVar7 + 0x10) < *(uint *)(pbVar9 + 0x10)) {
          uVar5 = 0xffffffff;
        }
        else {
          uVar5 = (uint)(*(uint *)(pbVar9 + 0x10) < *(uint *)(pbVar7 + 0x10));
        }
      }
      if (-1 < (int)uVar5) {
        if (pbVar9 == pbVar7) goto LAB_00a1cf2a;
        uVar5 = *(uint *)(pbVar7 + 0x10);
        if (0xf < *(uint *)(pbVar7 + 0x14)) {
          pbVar7 = *(byte **)pbVar7;
        }
        uVar2 = *(uint *)(pbVar9 + 0x10);
        if (0xf < *(uint *)(pbVar9 + 0x14)) {
          pbVar9 = *(byte **)pbVar9;
        }
        uVar6 = uVar2;
        if (uVar5 < uVar2) {
          uVar6 = uVar5;
        }
        while (uVar3 = uVar6 - 4, 3 < uVar6) {
          if (*(int *)pbVar9 != *(int *)pbVar7) goto LAB_00a1ced6;
          pbVar9 = pbVar9 + 4;
          pbVar7 = pbVar7 + 4;
          uVar6 = uVar3;
        }
        if (uVar3 == 0xfffffffc) {
LAB_00a1cf0a:
          uVar6 = 0;
        }
        else {
LAB_00a1ced6:
          bVar13 = *pbVar9 < *pbVar7;
          if ((*pbVar9 == *pbVar7) &&
             ((uVar3 == 0xfffffffd ||
              ((bVar13 = pbVar9[1] < pbVar7[1], pbVar9[1] == pbVar7[1] &&
               ((uVar3 == 0xfffffffe ||
                ((bVar13 = pbVar9[2] < pbVar7[2], pbVar9[2] == pbVar7[2] &&
                 ((uVar3 == 0xffffffff || (bVar13 = pbVar9[3] < pbVar7[3], pbVar9[3] == pbVar7[3])))
                 ))))))))) goto LAB_00a1cf0a;
          uVar6 = -(uint)bVar13 | 1;
        }
        if (uVar6 == 0) {
          if (uVar2 < uVar5) {
            uVar6 = 0xffffffff;
          }
          else {
            uVar6 = (uint)(uVar5 < uVar2);
          }
        }
        piVar8 = piStack_10;
        if ((int)uVar6 < 0) goto joined_r0x00a1cf5a;
        goto LAB_00a1cf2a;
      }
    }
    piVar1 = piVar1 + 1;
  } while( true );
}



/* FUNCTION 20054 ; VA 0x00a1d190 ; FUN_00a1d190 */

void FUN_00a1d190(int param_1,int param_2,uint param_3,int *param_4)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  byte *pbVar7;
  byte *pbVar8;
  int iVar9;
  bool bVar10;
  
  iVar4 = param_2;
  iVar5 = (int)(param_3 - 1) >> 1;
  iVar9 = param_2;
  if (param_2 < iVar5) {
    do {
      param_2 = iVar9 * 2 + 2;
      pbVar8 = *(byte **)(*(int *)(param_1 + 8 + iVar9 * 8) + 4);
      pbVar7 = *(byte **)(*(int *)(param_1 + 4 + iVar9 * 8) + 4);
      if (pbVar8 != pbVar7) {
        uVar1 = *(uint *)(pbVar7 + 0x10);
        if (0xf < *(uint *)(pbVar7 + 0x14)) {
          pbVar7 = *(byte **)pbVar7;
        }
        uVar2 = *(uint *)(pbVar8 + 0x10);
        if (0xf < *(uint *)(pbVar8 + 0x14)) {
          pbVar8 = *(byte **)pbVar8;
        }
        uVar6 = uVar2;
        if (uVar1 < uVar2) {
          uVar6 = uVar1;
        }
        while (uVar3 = uVar6 - 4, 3 < uVar6) {
          if (*(int *)pbVar8 != *(int *)pbVar7) goto LAB_00a1d226;
          pbVar8 = pbVar8 + 4;
          pbVar7 = pbVar7 + 4;
          uVar6 = uVar3;
        }
        if (uVar3 == 0xfffffffc) {
LAB_00a1d25a:
          uVar6 = 0;
        }
        else {
LAB_00a1d226:
          bVar10 = *pbVar8 < *pbVar7;
          if ((*pbVar8 == *pbVar7) &&
             ((uVar3 == 0xfffffffd ||
              ((bVar10 = pbVar8[1] < pbVar7[1], pbVar8[1] == pbVar7[1] &&
               ((uVar3 == 0xfffffffe ||
                ((bVar10 = pbVar8[2] < pbVar7[2], pbVar8[2] == pbVar7[2] &&
                 ((uVar3 == 0xffffffff || (bVar10 = pbVar8[3] < pbVar7[3], pbVar8[3] == pbVar7[3])))
                 ))))))))) goto LAB_00a1d25a;
          uVar6 = -(uint)bVar10 | 1;
        }
        if (uVar6 == 0) {
          if (uVar2 < uVar1) {
            uVar6 = 0xffffffff;
          }
          else {
            uVar6 = (uint)(uVar1 < uVar2);
          }
        }
        if ((int)uVar6 < 0) {
          param_2 = iVar9 * 2 + 1;
        }
      }
      *(undefined4 *)(param_1 + iVar9 * 4) = *(undefined4 *)(param_1 + param_2 * 4);
      iVar9 = param_2;
    } while (param_2 < iVar5);
  }
  if ((param_2 == iVar5) && ((param_3 & 1) == 0)) {
    *(undefined4 *)(param_1 + param_2 * 4) = *(undefined4 *)(param_1 + -4 + param_3 * 4);
    param_2 = param_3 - 1;
  }
  if (param_2 <= iVar4) {
    *(int *)(param_1 + param_2 * 4) = *param_4;
    return;
  }
  do {
    iVar5 = param_2 + -1 >> 1;
    iVar9 = *(int *)(param_1 + iVar5 * 4);
    pbVar8 = *(byte **)(iVar9 + 4);
    pbVar7 = *(byte **)(*param_4 + 4);
    if (pbVar8 == pbVar7) {
      *(int *)(param_1 + param_2 * 4) = *param_4;
      return;
    }
    uVar1 = *(uint *)(pbVar7 + 0x10);
    if (0xf < *(uint *)(pbVar7 + 0x14)) {
      pbVar7 = *(byte **)pbVar7;
    }
    uVar2 = *(uint *)(pbVar8 + 0x10);
    if (0xf < *(uint *)(pbVar8 + 0x14)) {
      pbVar8 = *(byte **)pbVar8;
    }
    uVar6 = uVar2;
    if (uVar1 < uVar2) {
      uVar6 = uVar1;
    }
    while (uVar3 = uVar6 - 4, 3 < uVar6) {
      if (*(int *)pbVar8 != *(int *)pbVar7) goto LAB_00a1d326;
      pbVar8 = pbVar8 + 4;
      pbVar7 = pbVar7 + 4;
      uVar6 = uVar3;
    }
    if (uVar3 == 0xfffffffc) {
LAB_00a1d35a:
      uVar6 = 0;
    }
    else {
LAB_00a1d326:
      bVar10 = *pbVar8 < *pbVar7;
      if ((*pbVar8 == *pbVar7) &&
         ((uVar3 == 0xfffffffd ||
          ((bVar10 = pbVar8[1] < pbVar7[1], pbVar8[1] == pbVar7[1] &&
           ((uVar3 == 0xfffffffe ||
            ((bVar10 = pbVar8[2] < pbVar7[2], pbVar8[2] == pbVar7[2] &&
             ((uVar3 == 0xffffffff || (bVar10 = pbVar8[3] < pbVar7[3], pbVar8[3] == pbVar7[3])))))))
           ))))) goto LAB_00a1d35a;
      uVar6 = -(uint)bVar10 | 1;
    }
    if (uVar6 == 0) {
      if (uVar2 < uVar1) {
        uVar6 = 0xffffffff;
      }
      else {
        uVar6 = (uint)(uVar1 < uVar2);
      }
    }
    if (-1 < (int)uVar6) {
      *(int *)(param_1 + param_2 * 4) = *param_4;
      return;
    }
    *(int *)(param_1 + param_2 * 4) = iVar9;
    param_2 = iVar5;
    if (iVar5 <= iVar4) {
      *(int *)(param_1 + iVar5 * 4) = *param_4;
      return;
    }
  } while( true );
}



/* FUNCTION 20055 ; VA 0x00a1d3c0 ; FUN_00a1d3c0 */

void __thiscall FUN_00a1d3c0(int *param_1,uint param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  
  uVar8 = (param_1[1] - *param_1) / 0xc;
  uVar6 = (param_1[2] - *param_1) / 0xc;
  if (param_2 <= uVar6) {
    if (uVar8 < param_2) {
      iVar4 = FUN_00a1ffe0(param_1[1],param_2 - uVar8);
      param_1[1] = iVar4;
      return;
    }
    if (param_2 != uVar8) {
      iVar4 = *param_1 + param_2 * 0xc;
      FUN_00a1ba80(iVar4,param_1[1],param_1);
      param_1[1] = iVar4;
    }
    return;
  }
  if (0x15555555 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar2 = param_2;
  if ((uVar6 <= 0x15555555 - (uVar6 >> 1)) && (uVar2 = (uVar6 >> 1) + uVar6, uVar2 < param_2)) {
    uVar2 = param_2;
  }
  uVar6 = uVar2 * 0xc;
  if (uVar2 < 0x15555556) {
    if (0xfff < uVar6) goto LAB_00a1d44d;
    if (uVar6 == 0) {
      puVar10 = (undefined4 *)0x0;
    }
    else {
      puVar10 = (undefined4 *)FUN_01674e20(uVar6);
    }
  }
  else {
    uVar6 = 0xffffffff;
LAB_00a1d44d:
    uVar3 = uVar6 + 0x23;
    if (uVar3 <= uVar6) {
      uVar3 = 0xffffffff;
    }
    iVar4 = FUN_01674e20(uVar3);
    if (iVar4 == 0) goto LAB_00a1d5b8;
    puVar10 = (undefined4 *)(iVar4 + 0x23U & 0xffffffe0);
    puVar10[-1] = iVar4;
  }
  FUN_00a1ffe0(puVar10 + uVar8 * 3,param_2 - uVar8);
  puVar1 = (undefined4 *)param_1[1];
  puVar9 = puVar10;
  for (puVar7 = (undefined4 *)*param_1; puVar7 != puVar1; puVar7 = puVar7 + 3) {
    *puVar9 = 0;
    puVar9[1] = 0;
    puVar9[2] = 0;
    *puVar9 = *puVar7;
    puVar9[1] = puVar7[1];
    puVar9[2] = puVar7[2];
    puVar9 = puVar9 + 3;
    *puVar7 = 0;
    puVar7[1] = 0;
    puVar7[2] = 0;
  }
  FUN_00a1ba80(puVar9,puVar9,param_1);
  if (*param_1 != 0) {
    FUN_00a1ba80(*param_1,param_1[1],param_1);
    iVar4 = *param_1;
    uVar8 = ((param_1[2] - *param_1) / 0xc) * 0xc;
    iVar5 = iVar4;
    if (0xfff < uVar8) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (iVar4 - iVar5) - 4U) {
LAB_00a1d5b8:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar8);
  }
  *param_1 = (int)puVar10;
  param_1[1] = (int)(puVar10 + param_2 * 3);
  param_1[2] = (int)(puVar10 + uVar2 * 3);
  return;
}



/* FUNCTION 20056 ; VA 0x00a1d5c0 ; FUN_00a1d5c0 */

void __thiscall FUN_00a1d5c0(int *param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  undefined4 uVar4;
  int iVar5;
  
  uVar3 = param_2;
  iVar5 = param_1[1];
  uVar1 = (iVar5 - *param_1) / 0x24;
  uVar2 = (param_1[2] - *param_1) / 0x24;
  if (param_2 <= uVar2) {
    if (param_2 <= uVar1) {
      if (param_2 != uVar1) {
        param_1[1] = *param_1 + param_2 * 0x24;
      }
      return;
    }
    if (param_2 - uVar1 != 0) {
      iVar5 = iVar5 + (param_2 - uVar1) * 0x24;
    }
    param_1[1] = iVar5;
    return;
  }
  if (0x71c71c7 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = param_2;
  if ((uVar2 <= 0x71c71c7 - (uVar2 >> 1)) && (uVar1 = (uVar2 >> 1) + uVar2, uVar1 < param_2)) {
    uVar1 = param_2;
  }
  param_2 = uVar1;
  uVar4 = FUN_00a203e0(param_2);
  FUN_00a203a0(*param_1,param_1[1],uVar4);
  FUN_00a200d0(uVar4,uVar3,param_2);
  return;
}



/* FUNCTION 20057 ; VA 0x00a1d6a0 ; FUN_00a1d6a0 */

void FUN_00a1d6a0(undefined4 *param_1,int param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iStack_c;
  undefined4 *puStack_8;
  
  iVar1 = param_2 - (int)param_1;
  iVar3 = param_2;
  iVar2 = param_3;
  do {
    iVar1 = iVar1 >> 2;
    if (iVar1 < 0x21) {
LAB_00a1d723:
      if (1 < iVar1) {
        FUN_00a1c5c0(param_1,iVar3,param_4);
      }
      return;
    }
    if (iVar2 < 1) {
      if (0x20 < iVar1) {
        FUN_00a1c7b0(param_1,iVar3,param_4);
        iVar3 = iVar3 - (int)param_1;
        if (iVar3 >> 2 < 2) {
          return;
        }
        do {
          param_2 = *(undefined4 *)((int)param_1 + iVar3 + -4);
          *(undefined4 *)((int)param_1 + iVar3 + -4) = *param_1;
          FUN_00a1d190(param_1,0,iVar3 + -4 >> 2,&param_2,param_4);
          iVar3 = iVar3 + -4;
        } while (1 < iVar3 >> 2);
        return;
      }
      goto LAB_00a1d723;
    }
    FUN_00a1ca60(&iStack_c,param_1,iVar3,param_4);
    iVar2 = (iVar2 >> 1) + (iVar2 >> 2);
    if ((int)(iStack_c - (int)param_1 & 0xfffffffcU) < (int)(iVar3 - (int)puStack_8 & 0xfffffffcU))
    {
      FUN_00a1d6a0(param_1,iStack_c,iVar2,param_4);
      param_1 = puStack_8;
    }
    else {
      FUN_00a1d6a0(puStack_8,iVar3,iVar2,param_4);
      iVar3 = iStack_c;
    }
    iVar1 = iVar3 - (int)param_1;
  } while( true );
}



/* FUNCTION 20058 ; VA 0x00a1d790 ; FUN_00a1d790 */

undefined4 *
FUN_00a1d790(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  
  puVar6 = param_3;
  if (param_1 != param_2) {
    puVar5 = param_1 + 9;
    do {
      *puVar6 = puVar5[-9];
      puVar6[2] = puVar5[-7];
      puVar6[3] = puVar5[-6];
      puVar6[8] = 0;
      *(undefined4 *)((int)param_3 + (-0x30 - (int)param_1) + (int)(puVar5 + 0xc)) = 0;
      uVar2 = puVar5[-4];
      uVar3 = puVar5[-3];
      uVar4 = puVar5[-2];
      puVar6[4] = puVar5[-5];
      puVar6[5] = uVar2;
      puVar6[6] = uVar3;
      puVar6[7] = uVar4;
      *(undefined8 *)(puVar6 + 8) = *(undefined8 *)(puVar5 + -1);
      puVar5[-1] = 0;
      *puVar5 = 0xf;
      *(undefined *)(puVar5 + -5) = 0;
      puVar6[10] = puVar5[1];
      puVar6[0xb] = puVar5[2];
      puVar1 = puVar5 + 3;
      puVar6 = puVar6 + 0xc;
      puVar5 = puVar5 + 0xc;
    } while (puVar1 != param_2);
  }
  FUN_00a1ba10(puVar6,puVar6,param_4);
  return puVar6;
}



/* FUNCTION 20059 ; VA 0x00a1d820 ; FUN_00a1d820 */

void __thiscall FUN_00a1d820(byte *param_1,int *param_2,int param_3,int *param_4,int *param_5)

{
  int *piVar1;
  uint uVar2;
  undefined4 *puVar3;
  uint uVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar7 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dbb08;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_00a33fd0(param_3);
  FUN_0063f830(&param_3,uVar4,iVar7,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_3 == 0) {
    uStack_8 = 0;
    piVar5 = (int *)FUN_01674e20(0x10);
    *piVar5 = 0;
    piVar5[1] = 0;
    piVar5[2] = 0;
    piVar5[3] = 0;
    iVar7 = *param_4;
    piVar5[2] = iVar7;
    LOCK();
    piVar1 = (int *)(iVar7 + 0x28);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    piVar5[3] = *param_5;
    uVar2 = *(uint *)(param_1 + 8);
    uVar6 = uVar2 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar6 = FUN_005c9310(uVar6);
      if (uVar6 <= *(uint *)(param_1 + 4)) {
        uVar6 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar6);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar6) {
      param_3 = 1;
      uVar8 = uVar2 >> 1;
      if ((uVar2 >> 1) + uVar2 <= uVar6) {
        uVar8 = 1;
      }
      iVar7 = FUN_005c9310(uVar8 + uVar2);
      if (iVar7 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar7);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar3 = (undefined4 *)*puVar9;
        while (puVar3 != (undefined4 *)0x0) {
          piVar1 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar1 = (int)puVar9;
            puVar9 = puVar3;
          }
          else {
            *puVar9 = *puVar3;
            *puVar3 = *(undefined4 *)*piVar1;
            *(undefined4 **)*piVar1 = puVar3;
          }
          puVar3 = (undefined4 *)*puVar9;
        }
      }
    }
    piVar5[1] = uVar4;
    uVar4 = uVar4 % *(uint *)(param_1 + 4);
    piVar1 = *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
    puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
    if (piVar1 == (int *)0x0) {
      piVar1 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar1 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar1 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar5;
      }
      *puVar9 = piVar1;
      *piVar5 = *piVar1;
      *piVar1 = (int)piVar5;
    }
    else {
      *piVar5 = *piVar1;
      *(int **)*puVar9 = piVar5;
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *param_2 = (int)piVar5;
    *(undefined *)(param_2 + 1) = 1;
    ExceptionList = pvStack_10;
    return;
  }
  *param_2 = param_3;
  *(undefined *)(param_2 + 1) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20060 ; VA 0x00a1d9f0 ; FUN_00a1d9f0 */

undefined4 FUN_00a1d9f0(undefined4 param_1,int param_2,undefined4 param_3)

{
  (**(code **)(**(int **)(param_2 + 0x34) + 0xc))(param_1,param_3);
  return param_1;
}



/* FUNCTION 20061 ; VA 0x00a1da10 ; FUN_00a1da10 */

void FUN_00a1da10(int *param_1,undefined *param_2)

{
  undefined auStack_10 [12];
  
  if (param_1[1] + 1U <= (uint)param_1[2]) {
    *param_2 = *(undefined *)(*param_1 + param_1[1]);
    param_1[1] = param_1[1] + 1;
    return;
  }
  FUN_016756b0(auStack_10,"MemoryInputStream::read offset is out of bounds while reading %d bytes",1
              );
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 20062 ; VA 0x00a1da60 ; FUN_00a1da60 */

void FUN_00a1da60(int *param_1,undefined4 *param_2)

{
  undefined auStack_10 [12];
  
  if (param_1[1] + 4U <= (uint)param_1[2]) {
    *param_2 = *(undefined4 *)(*param_1 + param_1[1]);
    param_1[1] = param_1[1] + 4;
    return;
  }
  FUN_016756b0(auStack_10,"MemoryInputStream::read offset is out of bounds while reading %d bytes",4
              );
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 20063 ; VA 0x00a1dab0 ; FUN_00a1dab0 */

void FUN_00a1dab0(int *param_1,undefined8 *param_2)

{
  undefined auStack_10 [12];
  
  if (param_1[1] + 8U <= (uint)param_1[2]) {
    *param_2 = *(undefined8 *)(*param_1 + param_1[1]);
    param_1[1] = param_1[1] + 8;
    return;
  }
  FUN_016756b0(auStack_10,"MemoryInputStream::read offset is out of bounds while reading %d bytes",8
              );
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 20064 ; VA 0x00a1db00 ; FUN_00a1db00 */

void FUN_00a1db00(int *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  undefined auStack_10 [12];
  
  if (param_1[1] + 0xcU <= (uint)param_1[2]) {
    puVar1 = (undefined8 *)(*param_1 + param_1[1]);
    *param_2 = *puVar1;
    *(undefined4 *)(param_2 + 1) = *(undefined4 *)(puVar1 + 1);
    param_1[1] = param_1[1] + 0xc;
    return;
  }
  FUN_016756b0(auStack_10,"MemoryInputStream::read offset is out of bounds while reading %d bytes",
               0xc);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 20065 ; VA 0x00a1db60 ; FUN_00a1db60 */

void FUN_00a1db60(int *param_1,int param_2,undefined4 param_3,int *param_4,uint param_5,
                 undefined4 param_6,int *param_7)

{
  undefined uVar1;
  undefined **ppuVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  undefined **ppuVar12;
  uint *puVar13;
  uint uVar14;
  uint uVar15;
  int *piVar16;
  int *piVar17;
  uint uVar18;
  int *piVar19;
  undefined auStack_e0 [4];
  undefined *puStack_dc;
  int iStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  int iStack_cc;
  int iStack_c8;
  int iStack_c4;
  undefined4 uStack_c0;
  int *piStack_bc;
  int iStack_b8;
  int iStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  uint uStack_a0;
  undefined4 uStack_90;
  uint uStack_8c;
  int iStack_88;
  int iStack_84;
  uint uStack_80;
  uint uStack_7c;
  uint uStack_78;
  uint uStack_74;
  uint uStack_70;
  uint uStack_6c;
  uint uStack_68;
  uint uStack_64;
  uint auStack_60 [3];
  int iStack_54;
  uint *puStack_50;
  uint *puStack_4c;
  undefined4 *puStack_48;
  undefined4 uStack_44;
  int iStack_40;
  undefined uStack_39;
  uint auStack_38 [3];
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  uint uStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dbc5c;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  piStack_bc = (int *)0x0;
  iStack_c8 = 0;
  iStack_c4 = 0;
  uStack_c0 = 0;
  iStack_b8 = 0;
  iStack_b4 = 0;
  uStack_b0 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  puStack_48 = (undefined4 *)0x0;
  uStack_44 = 0;
  ExceptionList = &pvStack_10;
  puStack_48 = (undefined4 *)FUN_00601dc0();
  uStack_8._0_1_ = 2;
  FUN_00a24ba0(param_3,&iStack_c8,&iStack_b8,&puStack_48,param_5,param_6);
  piStack_20 = (int *)0x0;
  uStack_1c = 0;
  piStack_20 = (int *)FUN_00575ab0();
  uStack_8._0_1_ = 3;
  FUN_00a24e00(&iStack_c8,&piStack_20);
  auStack_e0[0] = 0;
  piStack_14 = (int *)&DAT_0000000b;
  ppuVar2 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&piStack_14);
  ppuVar12 = ppuVar2 + -1;
  if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar12 = ppuVar2;
  }
  puStack_dc = *ppuVar12;
  iStack_d8 = 0;
  uStack_d4 = 0x3f800000;
  uStack_d0 = 0;
  iStack_cc = 0;
  uStack_8._0_1_ = 4;
  FUN_00a24f60(&piStack_20,auStack_e0);
  iStack_84 = DAT_0193fd94;
  uStack_80 = DAT_0193fd98;
  uStack_7c = DAT_0193fda0;
  uStack_78 = (uint)DAT_0193fda4;
  uStack_74 = uStack_1c;
  uStack_70 = iStack_c4 - iStack_c8 >> 2;
  uStack_68 = 0;
  uStack_6c = 0;
  FUN_00554150(&iStack_84,0x20);
  piVar3 = param_4;
  if ((param_4 != (int *)0x0) && (param_4[2] != 0)) {
    piStack_28 = (int *)0x0;
    piStack_24 = (int *)&DAT_0000000f;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    FUN_005542c0("Metadata",8);
    uStack_ac = 0;
    uStack_8._0_1_ = 6;
    uStack_a8 = 0;
    uStack_a4 = 0;
    FUN_0054ef60(auStack_38);
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    FUN_005507b0();
    param_4 = (int *)piVar3[2];
    FUN_00a25190(&param_4,4);
    if (piVar3[2] == 0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      puVar5 = *(undefined4 **)(piVar3[5] + piVar3[1] * 4);
    }
    for (; puVar5 != (undefined4 *)0x0; puVar5 = (undefined4 *)*puVar5) {
      param_4 = (int *)puVar5[6];
      piVar3 = puVar5 + 2;
      FUN_00a25190(&param_4,4);
      if (0xf < (uint)puVar5[7]) {
        piVar3 = (int *)*piVar3;
      }
      FUN_00a25190(piVar3,param_4);
      param_4 = (int *)puVar5[0xc];
      puVar9 = puVar5 + 8;
      FUN_00a25190(&param_4,4);
      if (0xf < (uint)puVar5[0xd]) {
        puVar9 = (undefined4 *)*puVar9;
      }
      FUN_00a25190(puVar9,param_4);
    }
    FUN_00a1fb70(param_1,&uStack_ac,&DAT_0193fdc0,param_5);
    uStack_8._0_1_ = 4;
    FUN_00a1ff80();
  }
  if (iStack_d8 != 0) {
    puStack_50 = (uint *)0x0;
    puStack_4c = (uint *)&DAT_0000000f;
    auStack_60[0] = auStack_60[0] & 0xffffff00;
    FUN_005542c0("SharedStrings",0xd);
    iStack_88 = 0;
    uStack_8._0_1_ = 10;
    iStack_84 = 0;
    uStack_80 = 0;
    FUN_0054ef60(auStack_60);
    uStack_8._0_1_ = 0xc;
    if (&DAT_0000000f < puStack_4c) {
      puVar13 = (uint *)((int)puStack_4c + 1);
      uVar6 = auStack_60[0];
      if ((uint *)0xfff < puVar13) {
        uVar6 = *(uint *)(auStack_60[0] - 4);
        puVar13 = puStack_4c + 9;
        if (0x1f < (auStack_60[0] - uVar6) - 4) {
LAB_00a1eb32:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,puVar13);
    }
    param_4 = (int *)0x0;
    FUN_00a25190(&param_4,4);
    param_4 = (int *)iStack_d8;
    FUN_00a25190(&param_4,4);
    FUN_00a1fde0(iStack_d8,(int)&param_4 + 3);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
    piVar3 = piStack_2c;
    if (iStack_d8 == 0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      puVar5 = *(undefined4 **)(iStack_cc + (int)puStack_dc * 4);
    }
    for (; piStack_2c = piVar3, puVar5 != (undefined4 *)0x0; puVar5 = (undefined4 *)*puVar5) {
      iVar8 = puVar5[2];
      iVar4 = puVar5[3];
      LOCK();
      piVar17 = (int *)(iVar8 + 0x28);
      *piVar17 = *piVar17 + 1;
      UNLOCK();
      param_4 = (int *)piVar3[iVar4];
      piVar3[iVar4] = iVar8;
      FUN_0056cd30();
      piVar3 = piStack_2c;
    }
    param_4 = piVar3;
    piStack_14 = piStack_28;
    if (piVar3 != piStack_28) {
      do {
        uVar6 = iStack_84 + 0x10;
        param_4 = piVar3;
        if (uStack_80 < uVar6) {
          uVar18 = 0x10;
          if (0x10 < uVar6) {
            do {
              uVar18 = uVar18 * 2;
            } while (uVar18 < uVar6);
          }
          iVar4 = FUN_01674e20(uVar18);
          FUN_0170c6f0(iVar4,iStack_88,iStack_84);
          iVar8 = iStack_88;
          iStack_88 = iVar4;
          uStack_80 = uVar18;
          FUN_01674ea0(iVar8);
        }
        piVar3 = param_4;
        puVar5 = (undefined4 *)(iStack_88 + iStack_84);
        *puVar5 = 0;
        puVar5[1] = 0;
        puVar5[2] = 0;
        puVar5[3] = 0;
        iStack_84 = iStack_84 + 0x10;
        puVar5 = (undefined4 *)FUN_00a33fa0();
        param_4 = (int *)puVar5[4];
        FUN_00a25190(&param_4,4);
        if (0xf < (uint)puVar5[5]) {
          puVar5 = (undefined4 *)*puVar5;
        }
        FUN_00a25190(puVar5,param_4);
        piVar3 = piVar3 + 1;
        param_4 = piVar3;
      } while (piVar3 != piStack_14);
    }
    FUN_00a1fb70(param_1,&iStack_88,&DAT_0193fdc8,param_5);
    FUN_00612dd0();
    uStack_8._0_1_ = 4;
    FUN_00a1ff80();
  }
  iStack_40 = 0;
  piStack_18 = (int *)*piStack_20;
  if (piStack_18 != piStack_20) {
    do {
      piVar17 = piStack_18;
      iVar8 = piStack_18[4];
      iStack_88 = 0;
      uStack_8._0_1_ = 0xe;
      iStack_84 = 0;
      uStack_80 = 0;
      FUN_0054ef60(*(undefined4 *)(iVar8 + 4));
      uStack_8._0_1_ = 0xf;
      FUN_00a25190(&iStack_40,4);
      piVar3 = *(int **)(iVar8 + 4);
      param_4 = (int *)piVar3[4];
      FUN_00a25190(&param_4,4);
      if (0xf < (uint)piVar3[5]) {
        piVar3 = (int *)*piVar3;
      }
      FUN_00a25190(piVar3,param_4);
      iStack_54 = 0;
      puStack_50 = (uint *)0x0;
      puStack_4c = (uint *)0x0;
      puVar5 = (undefined4 *)piVar17[5];
      uVar6 = piVar17[6] - (int)puVar5 >> 2;
      uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
      if (uVar6 != 0) {
        if (0x3fffffff < uVar6) goto LAB_00a1eb3c;
        FUN_007cfd20(uVar6);
        puVar5 = (undefined4 *)piVar17[5];
      }
      iVar8 = piVar17[6];
      param_4 = (int *)0x0;
      if (iVar8 - (int)puVar5 >> 2 != 0) {
        do {
          puVar11 = puStack_48;
          puVar10 = puStack_48;
          puVar9 = (undefined4 *)puStack_48[1];
          if (*(char *)((int)puStack_48[1] + 0xd) == '\0') {
            do {
              puVar7 = puVar9;
              if ((uint)puVar7[4] < (uint)puVar5[(int)param_4]) {
                puVar9 = (undefined4 *)puVar7[2];
                puVar7 = puVar11;
              }
              else {
                puVar9 = (undefined4 *)*puVar7;
              }
              puVar11 = puVar7;
            } while (*(char *)((int)puVar9 + 0xd) == '\0');
            if ((puVar7 != puStack_48) && ((uint)puVar7[4] <= (uint)puVar5[(int)param_4])) {
              puVar10 = puVar7;
            }
          }
          if (puVar10 == puStack_48) {
            uStack_64 = 0xffffffff;
          }
          else {
            uStack_64 = puVar10[5];
          }
          if (puStack_4c == puStack_50) {
            FUN_0063d9b0(puStack_50,&uStack_64);
          }
          else {
            *puStack_50 = uStack_64;
            puStack_50 = puStack_50 + 1;
          }
          iVar8 = piVar17[6];
          puVar5 = (undefined4 *)piVar17[5];
          param_4 = (int *)((int)param_4 + 1);
        } while (param_4 < (uint)(iVar8 - (int)puVar5 >> 2));
      }
      puVar13 = puStack_50;
      if ((iVar8 - (int)puVar5 >> 2 == 0) ||
         (iVar8 = FUN_0170d75d(*puVar5,0,&RBX::Instance::RTTI_Type_Descriptor,
                               &RBX::Service::RTTI_Type_Descriptor,0), iVar8 == 0)) {
        uStack_39 = 0;
      }
      else {
        uStack_39 = 1;
      }
      param_4 = (int *)CONCAT13(uStack_39,param_4._0_3_);
      FUN_00a25190(&uStack_39,1);
      piStack_14 = (int *)((int)puVar13 - iStack_54 >> 2);
      FUN_00a25190(&piStack_14,4);
      FUN_00a25380(&iStack_88,&iStack_54);
      if ((param_4._3_1_ != '\0') && (uVar6 = 0, piVar17[6] - piVar17[5] >> 2 != 0)) {
        do {
          param_4 = (int *)CONCAT13(*(int *)(*(int *)(piVar17[5] + uVar6 * 4) + 0x34) == param_2,
                                    param_4._0_3_);
          FUN_00a25190((int)&param_4 + 3,1);
          uVar6 = uVar6 + 1;
        } while (uVar6 < (uint)(piVar17[6] - piVar17[5] >> 2));
      }
      FUN_00a1fb70(param_1,&iStack_88,&DAT_0193fda8,param_5);
      uStack_8._0_1_ = 0xf;
      if (iStack_54 != 0) {
        uVar6 = ((int)puStack_4c - iStack_54 >> 2) * 4;
        iVar8 = iStack_54;
        if (0xfff < uVar6) {
          iVar8 = *(int *)(iStack_54 + -4);
          uVar6 = uVar6 + 0x23;
          if (0x1f < (iStack_54 - iVar8) - 4U) goto LAB_00a1eb32;
        }
        FUN_01674ea0(iVar8,uVar6);
        iStack_54 = 0;
        puStack_50 = (uint *)0x0;
        puStack_4c = (uint *)0x0;
      }
      uStack_8._0_1_ = 4;
      if (0xf < uStack_68) {
        uVar18 = uStack_68 + 1;
        uVar6 = uStack_7c;
        if (0xfff < uVar18) {
          uVar6 = *(uint *)(uStack_7c - 4);
          uVar18 = uStack_68 + 0x24;
          if (0x1f < (uStack_7c - uVar6) - 4) goto LAB_00a1eb32;
        }
        FUN_01674ea0(uVar6,uVar18);
      }
      uStack_6c = 0;
      uStack_68 = 0xf;
      uStack_7c = uStack_7c & 0xffffff00;
      FUN_01674ea0(iStack_88);
      FUN_00551320();
      iStack_40 = iStack_40 + 1;
    } while (piStack_18 != piStack_20);
  }
  piStack_14 = (int *)*piStack_20;
  iStack_40 = 0;
  if (piStack_14 != piStack_20) {
    do {
      iVar4 = iStack_40;
      iVar8 = piStack_14[4];
      piVar3 = piStack_14 + 5;
      piStack_2c = (int *)0x0;
      piStack_28 = (int *)0x0;
      piStack_24 = (int *)0x0;
      uStack_8._0_1_ = 0x11;
      FUN_00a24ef0(iVar8,&piStack_2c);
      uStack_64 = 0;
      uVar6 = (int)piStack_28 - (int)piStack_2c >> 2;
      param_4 = piStack_2c;
      if (uVar6 != 0) {
        do {
          piVar19 = *(int **)(param_4[uStack_64] + 4);
          piVar16 = *(int **)(iVar8 + 4);
          piStack_bc = (int *)((uint)piStack_bc | 1);
          puStack_50 = (uint *)0x0;
          puStack_4c = (uint *)&DAT_0000000f;
          auStack_60[0] = auStack_60[0] & 0xffffff00;
          uStack_8._0_1_ = 0x12;
          piStack_18 = piStack_bc;
          FUN_0058a190(piVar16[4] + 1);
          piVar17 = piVar16 + 4;
          if (0xf < (uint)piVar16[5]) {
            piVar16 = (int *)*piVar16;
          }
          FUN_00554150(piVar16,*piVar17);
          FUN_00554150(&DAT_018d3094,1);
          piVar17 = piVar19 + 4;
          if (0xf < (uint)piVar19[5]) {
            piVar19 = (int *)*piVar19;
          }
          puVar13 = (uint *)FUN_00554150(piVar19,*piVar17);
          piVar17 = piStack_bc;
          piStack_18 = (int *)((uint)piStack_bc | 2);
          uStack_7c = *puVar13;
          uStack_78 = puVar13[1];
          uStack_74 = puVar13[2];
          uStack_70 = puVar13[3];
          uStack_6c = puVar13[4];
          uStack_68 = puVar13[5];
          puVar13[4] = 0;
          puVar13[5] = 0xf;
          *(undefined *)puVar13 = 0;
          uStack_ac = 0;
          uStack_8._0_1_ = 0x14;
          uStack_a8 = 0;
          uStack_a4 = 0;
          FUN_0054ef60(&uStack_7c);
          uStack_8._0_1_ = 0x16;
          if (0xf < uStack_68) {
            uVar14 = uStack_68 + 1;
            uVar18 = uStack_7c;
            if (0xfff < uVar14) {
              uVar18 = *(uint *)(uStack_7c - 4);
              uVar14 = uStack_68 + 0x24;
              if (0x1f < (uStack_7c - uVar18) - 4) goto LAB_00a1eb32;
            }
            FUN_01674ea0(uVar18,uVar14);
          }
          piStack_bc = (int *)((uint)piVar17 & 0xfffffffe | 2);
          uStack_8._0_1_ = 0x17;
          if (&DAT_0000000f < puStack_4c) {
            puVar13 = (uint *)((int)puStack_4c + 1);
            uVar18 = auStack_60[0];
            if ((uint *)0xfff < puVar13) {
              uVar18 = *(uint *)(auStack_60[0] - 4);
              puVar13 = puStack_4c + 9;
              if (0x1f < (auStack_60[0] - uVar18) - 4) goto LAB_00a1eb32;
            }
            FUN_01674ea0(uVar18,puVar13);
          }
          puStack_50 = (uint *)0x0;
          puStack_4c = (uint *)&DAT_0000000f;
          auStack_60[0] = auStack_60[0] & 0xffffff00;
          FUN_00a25190(&iStack_40,4);
          uVar18 = uStack_64;
          piVar17 = *(int **)(param_4[uStack_64] + 4);
          piStack_18 = (int *)piVar17[4];
          FUN_00a25190(&piStack_18,4);
          if (0xf < (uint)piVar17[5]) {
            piVar17 = (int *)*piVar17;
          }
          FUN_00a25190(piVar17,piStack_18);
          uVar14 = param_5;
          FUN_00a25830(&uStack_ac,param_4[uVar18],piVar3,&puStack_48,auStack_e0,param_5);
          FUN_00a1fb70(param_1,&uStack_ac,&DAT_0193fdb0,uVar14);
          uStack_8._0_1_ = 0x11;
          if (0xf < uStack_8c) {
            uVar15 = uStack_8c + 1;
            uVar14 = uStack_a0;
            if (0xfff < uVar15) {
              uVar14 = *(uint *)(uStack_a0 - 4);
              uVar15 = uStack_8c + 0x24;
              if (0x1f < (uStack_a0 - uVar14) - 4) goto LAB_00a1eb32;
            }
            FUN_01674ea0(uVar14,uVar15);
          }
          uStack_90 = 0;
          uStack_8c = 0xf;
          uStack_a0 = uStack_a0 & 0xffffff00;
          FUN_01674ea0(uStack_ac);
          uStack_64 = uVar18 + 1;
          iVar4 = iStack_40;
        } while (uStack_64 < uVar6);
      }
      uStack_8._0_1_ = 4;
      if (param_4 != (int *)0x0) {
        uVar6 = ((int)piStack_24 - (int)param_4 >> 2) * 4;
        piVar3 = param_4;
        if (0xfff < uVar6) {
          piVar3 = (int *)param_4[-1];
          uVar6 = uVar6 + 0x23;
          if (0x1f < (uint)((int)param_4 + (-4 - (int)piVar3))) goto LAB_00a1eb32;
        }
        FUN_01674ea0(piVar3,uVar6);
        piStack_2c = (int *)0x0;
        piStack_28 = (int *)0x0;
        piStack_24 = (int *)0x0;
      }
      FUN_00551320();
      iStack_40 = iVar4 + 1;
    } while (piStack_14 != piStack_20);
  }
  piStack_28 = (int *)0x0;
  piStack_24 = (int *)0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  FUN_005542c0("Instance-Parent",0xf);
  uStack_ac = 0;
  uStack_8._0_1_ = 0x19;
  uStack_a8 = 0;
  uStack_a4 = 0;
  FUN_0054ef60(auStack_38);
  uStack_8._0_1_ = 0x1b;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x1b;
  if (0xf < piStack_24) {
    uVar18 = (int)piStack_24 + 1;
    uVar6 = auStack_38[0];
    if (0xfff < uVar18) {
      uVar6 = *(uint *)(auStack_38[0] - 4);
      uVar18 = (int)piStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar6) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar18);
  }
  piStack_2c = (int *)0x0;
  piStack_28 = (int *)0x0;
  piStack_24 = (int *)0x0;
  iStack_54 = 0;
  puStack_50 = (undefined4 *)0x0;
  puStack_4c = (undefined4 *)0x0;
  uVar6 = iStack_b4 - iStack_b8 >> 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x1d);
  if (uVar6 != 0) {
    if (0x3fffffff < uVar6) {
LAB_00a1eb3c:
      puStack_4c = (uint *)0x0;
      puStack_50 = (uint *)0x0;
      iStack_54 = 0;
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_007cfd20(uVar6);
  }
  piVar3 = piStack_28;
  uVar6 = iStack_b4 - iStack_b8 >> 2;
  puVar13 = (undefined4 *)0x0;
  if (uVar6 != 0) {
    if (0x3fffffff < uVar6) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_007cfd20(uVar6);
    puVar13 = puStack_50;
  }
  param_4 = (int *)0x0;
  if (iStack_b4 - iStack_b8 >> 2 != 0) {
    do {
      uVar6 = *(uint *)(iStack_b8 + (int)param_4 * 4);
      puVar9 = puStack_48;
      puVar11 = puStack_48;
      puVar5 = (undefined4 *)puStack_48[1];
      if (*(char *)((int)puStack_48[1] + 0xd) == '\0') {
        do {
          puVar10 = puVar5;
          if ((uint)puVar10[4] < uVar6) {
            puVar5 = (undefined4 *)puVar10[2];
            puVar10 = puVar9;
          }
          else {
            puVar5 = (undefined4 *)*puVar10;
          }
          puVar9 = puVar10;
        } while (*(char *)((int)puVar5 + 0xd) == '\0');
        if ((puVar10 != puStack_48) && ((uint)puVar10[4] <= uVar6)) {
          puVar11 = puVar10;
        }
      }
      if (puVar11 == puStack_48) {
        piStack_14 = (int *)0xffffffff;
      }
      else {
        piStack_14 = (int *)puVar11[5];
      }
      if (piStack_24 == piVar3) {
        FUN_0063d9b0(piVar3,&piStack_14);
      }
      else {
        *piVar3 = (int)piStack_14;
        piStack_28 = piVar3 + 1;
      }
      piVar3 = piStack_28;
      uVar6 = *(uint *)(*(int *)(iStack_b8 + (int)param_4 * 4) + 0x34);
      puVar9 = puStack_48;
      puVar11 = puStack_48;
      puVar5 = (undefined4 *)puStack_48[1];
      if (*(char *)((int)puStack_48[1] + 0xd) == '\0') {
        do {
          puVar10 = puVar5;
          if ((uint)puVar10[4] < uVar6) {
            puVar5 = (undefined4 *)puVar10[2];
            puVar10 = puVar9;
          }
          else {
            puVar5 = (undefined4 *)*puVar10;
          }
          puVar9 = puVar10;
        } while (*(char *)((int)puVar5 + 0xd) == '\0');
        if ((puVar10 != puStack_48) && ((uint)puVar10[4] <= uVar6)) {
          puVar11 = puVar10;
        }
      }
      if (puVar11 == puStack_48) {
        piStack_14 = (int *)0xffffffff;
      }
      else {
        piStack_14 = (int *)puVar11[5];
      }
      if (puStack_4c == puVar13) {
        FUN_0063d9b0(puVar13,&piStack_14);
      }
      else {
        *puVar13 = (uint)piStack_14;
        puStack_50 = puVar13 + 1;
      }
      param_4 = (int *)((int)param_4 + 1);
      puVar13 = puStack_50;
    } while (param_4 < (uint)(iStack_b4 - iStack_b8 >> 2));
  }
  param_4 = (int *)((uint)param_4 & 0xffffff);
  FUN_00a25190((int)&param_4 + 3,1);
  param_4 = (int *)(iStack_b4 - iStack_b8 >> 2);
  FUN_00a25190(&param_4,4);
  FUN_00a25380(&uStack_ac,&piStack_2c);
  FUN_00a25380(&uStack_ac,&iStack_54);
  FUN_00a1fb70(param_1,&uStack_ac,&DAT_0193fdb8,param_5);
  FUN_0056d320();
  FUN_0056d320();
  uStack_8._0_1_ = 4;
  FUN_00a1ff80();
  piVar3 = param_7;
  if ((((param_5 & 0x20) != 0) && (param_7 != (int *)0x0)) && (param_7[4] != param_7[5])) {
    piStack_28 = (int *)0x0;
    piStack_24 = (int *)0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    FUN_005542c0("Signatures",10);
    uStack_ac = 0;
    uStack_8._0_1_ = 0x1f;
    uStack_a8 = 0;
    uStack_a4 = 0;
    FUN_0054ef60(auStack_38);
    uStack_8._0_1_ = 0x21;
    FUN_005507b0();
    uVar6 = *(uint *)(*param_1 + 0x10);
    *piVar3 = uVar6 + 0x10;
    piVar3[1] = (uint)(0xffffffef < uVar6);
    FUN_00a27590(&uStack_ac,piVar3);
    FUN_00a1fb70(param_1,&uStack_ac,&DAT_0193fdd0,2);
    uStack_8._0_1_ = 4;
    piVar3[2] = *(int *)(*param_1 + 0x10);
    piVar3[3] = 0;
    FUN_00a1ff80();
  }
  piStack_28 = (int *)0x0;
  piStack_24 = (int *)0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  FUN_005542c0(&DAT_0194073c,3);
  uStack_ac = 0;
  uStack_8._0_1_ = 0x23;
  uStack_a8 = 0;
  uStack_a4 = 0;
  FUN_0054ef60(auStack_38);
  uStack_8._0_1_ = 0x25;
  FUN_005507b0();
  FUN_00a25190("</roblox>",9);
  FUN_00a1fb70(param_1,&uStack_ac,&DAT_0193fdd8,2);
  FUN_00a1ff80();
  FUN_00640e30();
  piVar3 = piStack_20;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x26);
  FUN_00a20180(piStack_20[1]);
  piStack_20[1] = (int)piVar3;
  *piStack_20 = (int)piVar3;
  piStack_20[2] = (int)piVar3;
  uStack_1c = 0;
  FUN_0054db70(piStack_20,0x20);
  FUN_00729fa0();
  FUN_0056d320();
  FUN_0056d320();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20066 ; VA 0x00a1eb50 ; FUN_00a1eb50 */

void FUN_00a1eb50(undefined4 param_1,int param_2,undefined4 param_3,int *param_4,uint param_5,
                 undefined4 param_6,int *param_7)

{
  uint uVar1;
  undefined uVar2;
  undefined **ppuVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 *puVar8;
  int iVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  undefined **ppuVar13;
  uint *puVar14;
  uint uVar15;
  uint uVar16;
  int *piVar17;
  uint uVar18;
  int *piVar19;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined2 uStack_100;
  undefined2 uStack_fe;
  undefined4 uStack_fc;
  int iStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  uint uStack_ec;
  int *piStack_e8;
  int iStack_e4;
  undefined auStack_e0 [4];
  undefined *puStack_dc;
  int iStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  int iStack_cc;
  int iStack_c8;
  int iStack_c4;
  undefined4 uStack_c0;
  int *piStack_bc;
  int iStack_b8;
  int iStack_b4;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  uint uStack_98;
  int iStack_94;
  int iStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  uint uStack_7c;
  undefined4 uStack_6c;
  uint uStack_68;
  uint uStack_64;
  uint auStack_60 [3];
  int iStack_54;
  uint *puStack_50;
  uint *puStack_4c;
  undefined4 *puStack_48;
  undefined4 uStack_44;
  int iStack_40;
  undefined uStack_39;
  uint auStack_38 [3];
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dbdaf;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  piStack_bc = (int *)0x0;
  iStack_c8 = 0;
  iStack_c4 = 0;
  uStack_c0 = 0;
  iStack_94 = 0;
  iStack_90 = 0;
  uStack_8c = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  puStack_48 = (undefined4 *)0x0;
  uStack_44 = 0;
  ExceptionList = &pvStack_10;
  puStack_48 = (undefined4 *)FUN_00601dc0();
  uStack_8._0_1_ = 2;
  FUN_00a24ba0(param_3,&iStack_c8,&iStack_94,&puStack_48,param_5,param_6);
  piStack_20 = (int *)0x0;
  uStack_1c = 0;
  piStack_20 = (int *)FUN_00575ab0();
  uStack_8._0_1_ = 3;
  FUN_00a24e00(&iStack_c8,&piStack_20);
  auStack_e0[0] = 0;
  piStack_14 = (int *)&DAT_0000000b;
  ppuVar3 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&piStack_14);
  ppuVar13 = ppuVar3 + -1;
  if (ppuVar3 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar13 = ppuVar3;
  }
  puStack_dc = *ppuVar13;
  iStack_d8 = 0;
  uStack_d4 = 0x3f800000;
  uStack_d0 = 0;
  iStack_cc = 0;
  uStack_8._0_1_ = 4;
  FUN_00a24f60(&piStack_20,auStack_e0);
  uStack_10c = DAT_0193fd94;
  uStack_108 = DAT_0193fd98;
  uStack_104 = DAT_0193fda0;
  uStack_100 = DAT_0193fda4;
  uStack_fe = 0;
  uStack_fc = uStack_1c;
  iStack_f8 = iStack_c4 - iStack_c8 >> 2;
  uStack_f0 = 0;
  uStack_f4 = 0;
  FUN_005af750(&uStack_10c,0x20,0);
  piVar4 = param_4;
  if ((param_4 != (int *)0x0) && (param_4[2] != 0)) {
    piStack_28 = (int *)0x0;
    piStack_24 = (int *)&DAT_0000000f;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    FUN_005542c0("Metadata",8);
    uStack_88 = 0;
    uStack_8._0_1_ = 6;
    uStack_84 = 0;
    uStack_80 = 0;
    FUN_0054ef60(auStack_38);
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    FUN_005507b0();
    param_4 = (int *)piVar4[2];
    FUN_00a25190(&param_4,4);
    if (piVar4[2] == 0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      puVar6 = *(undefined4 **)(piVar4[5] + piVar4[1] * 4);
    }
    for (; puVar6 != (undefined4 *)0x0; puVar6 = (undefined4 *)*puVar6) {
      param_4 = (int *)puVar6[6];
      piVar4 = puVar6 + 2;
      FUN_00a25190(&param_4,4);
      if (0xf < (uint)puVar6[7]) {
        piVar4 = (int *)*piVar4;
      }
      FUN_00a25190(piVar4,param_4);
      param_4 = (int *)puVar6[0xc];
      puVar10 = puVar6 + 8;
      FUN_00a25190(&param_4,4);
      if (0xf < (uint)puVar6[0xd]) {
        puVar10 = (undefined4 *)*puVar10;
      }
      FUN_00a25190(puVar10,param_4);
    }
    FUN_00a1fca0(param_1,&uStack_88,&DAT_0193fdc0,param_5);
    uStack_8._0_1_ = 4;
    FUN_00a1ff80();
  }
  if (iStack_d8 != 0) {
    puStack_50 = (uint *)0x0;
    puStack_4c = (uint *)&DAT_0000000f;
    auStack_60[0] = auStack_60[0] & 0xffffff00;
    FUN_005542c0("SharedStrings",0xd);
    iStack_b8 = 0;
    uStack_8._0_1_ = 10;
    iStack_b4 = 0;
    uStack_b0 = 0;
    FUN_0054ef60(auStack_60);
    uStack_8._0_1_ = 0xc;
    if (&DAT_0000000f < puStack_4c) {
      puVar14 = (uint *)((int)puStack_4c + 1);
      uVar7 = auStack_60[0];
      if ((uint *)0xfff < puVar14) {
        uVar7 = *(uint *)(auStack_60[0] - 4);
        puVar14 = puStack_4c + 9;
        if (0x1f < (auStack_60[0] - uVar7) - 4) {
LAB_00a1fb53:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,puVar14);
    }
    param_4 = (int *)0x0;
    FUN_00a25190(&param_4,4);
    param_4 = (int *)iStack_d8;
    FUN_00a25190(&param_4,4);
    FUN_00a1fde0(iStack_d8,(int)&param_4 + 3);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
    piVar4 = piStack_2c;
    if (iStack_d8 == 0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      puVar6 = *(undefined4 **)(iStack_cc + (int)puStack_dc * 4);
    }
    for (; piStack_2c = piVar4, puVar6 != (undefined4 *)0x0; puVar6 = (undefined4 *)*puVar6) {
      iVar9 = puVar6[2];
      iVar5 = puVar6[3];
      LOCK();
      piVar19 = (int *)(iVar9 + 0x28);
      *piVar19 = *piVar19 + 1;
      UNLOCK();
      param_4 = (int *)piVar4[iVar5];
      piVar4[iVar5] = iVar9;
      FUN_0056cd30();
      piVar4 = piStack_2c;
    }
    param_4 = piVar4;
    piStack_14 = piStack_28;
    if (piVar4 != piStack_28) {
      do {
        uVar7 = iStack_b4 + 0x10;
        param_4 = piVar4;
        if (uStack_b0 < uVar7) {
          uVar18 = 0x10;
          if (0x10 < uVar7) {
            do {
              uVar18 = uVar18 * 2;
            } while (uVar18 < uVar7);
          }
          iVar5 = FUN_01674e20(uVar18);
          FUN_0170c6f0(iVar5,iStack_b8,iStack_b4);
          iVar9 = iStack_b8;
          iStack_b8 = iVar5;
          uStack_b0 = uVar18;
          FUN_01674ea0(iVar9);
        }
        piVar4 = param_4;
        puVar6 = (undefined4 *)(iStack_b8 + iStack_b4);
        *puVar6 = 0;
        puVar6[1] = 0;
        puVar6[2] = 0;
        puVar6[3] = 0;
        iStack_b4 = iStack_b4 + 0x10;
        puVar6 = (undefined4 *)FUN_00a33fa0();
        param_4 = (int *)puVar6[4];
        FUN_00a25190(&param_4,4);
        if (0xf < (uint)puVar6[5]) {
          puVar6 = (undefined4 *)*puVar6;
        }
        FUN_00a25190(puVar6,param_4);
        piVar4 = piVar4 + 1;
        param_4 = piVar4;
      } while (piVar4 != piStack_14);
    }
    FUN_00a1fca0(param_1,&iStack_b8,&DAT_0193fdc8,param_5);
    FUN_00612dd0();
    uStack_8._0_1_ = 4;
    FUN_00a1ff80();
  }
  iStack_40 = 0;
  piStack_18 = (int *)*piStack_20;
  if (piStack_18 != piStack_20) {
    do {
      piVar19 = piStack_18;
      iVar9 = piStack_18[4];
      iStack_b8 = 0;
      uStack_8._0_1_ = 0xe;
      iStack_b4 = 0;
      uStack_b0 = 0;
      FUN_0054ef60(*(undefined4 *)(iVar9 + 4));
      uStack_8._0_1_ = 0xf;
      FUN_00a25190(&iStack_40,4);
      piVar4 = *(int **)(iVar9 + 4);
      param_4 = (int *)piVar4[4];
      FUN_00a25190(&param_4,4);
      if (0xf < (uint)piVar4[5]) {
        piVar4 = (int *)*piVar4;
      }
      FUN_00a25190(piVar4,param_4);
      iStack_54 = 0;
      puStack_50 = (uint *)0x0;
      puStack_4c = (uint *)0x0;
      puVar6 = (undefined4 *)piVar19[5];
      uVar7 = piVar19[6] - (int)puVar6 >> 2;
      uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
      if (uVar7 != 0) {
        if (0x3fffffff < uVar7) goto LAB_00a1fb5d;
        FUN_007cfd20(uVar7);
        puVar6 = (undefined4 *)piVar19[5];
      }
      iVar9 = piVar19[6];
      param_4 = (int *)0x0;
      if (iVar9 - (int)puVar6 >> 2 != 0) {
        do {
          puVar12 = puStack_48;
          puVar11 = puStack_48;
          puVar10 = (undefined4 *)puStack_48[1];
          if (*(char *)((int)puStack_48[1] + 0xd) == '\0') {
            do {
              puVar8 = puVar10;
              if ((uint)puVar8[4] < (uint)puVar6[(int)param_4]) {
                puVar10 = (undefined4 *)puVar8[2];
                puVar8 = puVar12;
              }
              else {
                puVar10 = (undefined4 *)*puVar8;
              }
              puVar12 = puVar8;
            } while (*(char *)((int)puVar10 + 0xd) == '\0');
            if ((puVar8 != puStack_48) && ((uint)puVar8[4] <= (uint)puVar6[(int)param_4])) {
              puVar11 = puVar8;
            }
          }
          if (puVar11 == puStack_48) {
            uStack_64 = 0xffffffff;
          }
          else {
            uStack_64 = puVar11[5];
          }
          if (puStack_4c == puStack_50) {
            FUN_0063d9b0(puStack_50,&uStack_64);
          }
          else {
            *puStack_50 = uStack_64;
            puStack_50 = puStack_50 + 1;
          }
          iVar9 = piVar19[6];
          puVar6 = (undefined4 *)piVar19[5];
          param_4 = (int *)((int)param_4 + 1);
        } while (param_4 < (uint)(iVar9 - (int)puVar6 >> 2));
      }
      puVar14 = puStack_50;
      if ((iVar9 - (int)puVar6 >> 2 == 0) ||
         (iVar9 = FUN_0170d75d(*puVar6,0,&RBX::Instance::RTTI_Type_Descriptor,
                               &RBX::Service::RTTI_Type_Descriptor,0), iVar9 == 0)) {
        uStack_39 = 0;
      }
      else {
        uStack_39 = 1;
      }
      param_4 = (int *)CONCAT13(uStack_39,param_4._0_3_);
      FUN_00a25190(&uStack_39,1);
      piStack_14 = (int *)((int)puVar14 - iStack_54 >> 2);
      FUN_00a25190(&piStack_14,4);
      FUN_00a25380(&iStack_b8,&iStack_54);
      if ((param_4._3_1_ != '\0') && (uVar7 = 0, piVar19[6] - piVar19[5] >> 2 != 0)) {
        do {
          param_4 = (int *)CONCAT13(*(int *)(*(int *)(piVar19[5] + uVar7 * 4) + 0x34) == param_2,
                                    param_4._0_3_);
          FUN_00a25190((int)&param_4 + 3,1);
          uVar7 = uVar7 + 1;
        } while (uVar7 < (uint)(piVar19[6] - piVar19[5] >> 2));
      }
      FUN_00a1fca0(param_1,&iStack_b8,&DAT_0193fda8,param_5);
      uStack_8._0_1_ = 0xf;
      if (iStack_54 != 0) {
        uVar7 = ((int)puStack_4c - iStack_54 >> 2) * 4;
        iVar9 = iStack_54;
        if (0xfff < uVar7) {
          iVar9 = *(int *)(iStack_54 + -4);
          uVar7 = uVar7 + 0x23;
          if (0x1f < (iStack_54 - iVar9) - 4U) goto LAB_00a1fb53;
        }
        FUN_01674ea0(iVar9,uVar7);
        iStack_54 = 0;
        puStack_50 = (uint *)0x0;
        puStack_4c = (uint *)0x0;
      }
      uStack_8._0_1_ = 4;
      if (0xf < uStack_98) {
        uVar18 = uStack_98 + 1;
        uVar7 = uStack_ac;
        if (0xfff < uVar18) {
          uVar7 = *(uint *)(uStack_ac - 4);
          uVar18 = uStack_98 + 0x24;
          if (0x1f < (uStack_ac - uVar7) - 4) goto LAB_00a1fb53;
        }
        FUN_01674ea0(uVar7,uVar18);
      }
      uStack_9c = 0;
      uStack_98 = 0xf;
      uStack_ac = uStack_ac & 0xffffff00;
      FUN_01674ea0(iStack_b8);
      FUN_00551320();
      iStack_40 = iStack_40 + 1;
    } while (piStack_18 != piStack_20);
  }
  piStack_14 = (int *)*piStack_20;
  iStack_40 = 0;
  if (piStack_14 != piStack_20) {
    do {
      iVar9 = iStack_40;
      iStack_e4 = piStack_14[4];
      piStack_e8 = piStack_14 + 5;
      piStack_2c = (int *)0x0;
      piStack_28 = (int *)0x0;
      piStack_24 = (int *)0x0;
      uStack_8._0_1_ = 0x11;
      FUN_00a24ef0(iStack_e4,&piStack_2c);
      uStack_64 = 0;
      uStack_ec = (int)piStack_28 - (int)piStack_2c >> 2;
      param_4 = piStack_2c;
      if (uStack_ec != 0) {
        do {
          piVar19 = *(int **)(param_4[uStack_64] + 4);
          piVar17 = *(int **)(iStack_e4 + 4);
          piStack_bc = (int *)((uint)piStack_bc | 1);
          puStack_50 = (uint *)0x0;
          puStack_4c = (uint *)&DAT_0000000f;
          auStack_60[0] = auStack_60[0] & 0xffffff00;
          uStack_8._0_1_ = 0x12;
          piStack_18 = piStack_bc;
          FUN_0058a190(piVar17[4] + 1);
          piVar4 = piVar17 + 4;
          if (0xf < (uint)piVar17[5]) {
            piVar17 = (int *)*piVar17;
          }
          FUN_00554150(piVar17,*piVar4);
          FUN_00554150(&DAT_018d3094,1);
          piVar4 = piVar19 + 4;
          if (0xf < (uint)piVar19[5]) {
            piVar19 = (int *)*piVar19;
          }
          puVar14 = (uint *)FUN_00554150(piVar19,*piVar4);
          piVar4 = piStack_bc;
          piStack_18 = (int *)((uint)piStack_bc | 2);
          uStack_ac = *puVar14;
          uStack_a8 = puVar14[1];
          uStack_a4 = puVar14[2];
          uStack_a0 = puVar14[3];
          uStack_9c = puVar14[4];
          uStack_98 = puVar14[5];
          puVar14[4] = 0;
          puVar14[5] = 0xf;
          *(undefined *)puVar14 = 0;
          uStack_88 = 0;
          uStack_8._0_1_ = 0x14;
          uStack_84 = 0;
          uStack_80 = 0;
          FUN_0054ef60(&uStack_ac);
          uStack_8._0_1_ = 0x16;
          if (0xf < uStack_98) {
            uVar18 = uStack_98 + 1;
            uVar7 = uStack_ac;
            if (0xfff < uVar18) {
              uVar7 = *(uint *)(uStack_ac - 4);
              uVar18 = uStack_98 + 0x24;
              if (0x1f < (uStack_ac - uVar7) - 4) goto LAB_00a1fb53;
            }
            FUN_01674ea0(uVar7,uVar18);
          }
          piStack_bc = (int *)((uint)piVar4 & 0xfffffffe | 2);
          uStack_8._0_1_ = 0x17;
          if (&DAT_0000000f < puStack_4c) {
            puVar14 = (uint *)((int)puStack_4c + 1);
            uVar7 = auStack_60[0];
            if ((uint *)0xfff < puVar14) {
              uVar7 = *(uint *)(auStack_60[0] - 4);
              puVar14 = puStack_4c + 9;
              if (0x1f < (auStack_60[0] - uVar7) - 4) goto LAB_00a1fb53;
            }
            FUN_01674ea0(uVar7,puVar14);
          }
          puStack_50 = (uint *)0x0;
          puStack_4c = (uint *)&DAT_0000000f;
          auStack_60[0] = auStack_60[0] & 0xffffff00;
          FUN_00a25190(&iStack_40,4);
          uVar7 = uStack_64;
          piVar4 = *(int **)(param_4[uStack_64] + 4);
          piStack_18 = (int *)piVar4[4];
          FUN_00a25190(&piStack_18,4);
          if (0xf < (uint)piVar4[5]) {
            piVar4 = (int *)*piVar4;
          }
          FUN_00a25190(piVar4,piStack_18);
          uVar18 = param_5;
          FUN_00a25830(&uStack_88,param_4[uVar7],piStack_e8,&puStack_48,auStack_e0,param_5);
          FUN_00a1fca0(param_1,&uStack_88,&DAT_0193fdb0,uVar18);
          uStack_8._0_1_ = 0x11;
          if (0xf < uStack_68) {
            uVar15 = uStack_68 + 1;
            uVar18 = uStack_7c;
            if (0xfff < uVar15) {
              uVar18 = *(uint *)(uStack_7c - 4);
              uVar15 = uStack_68 + 0x24;
              if (0x1f < (uStack_7c - uVar18) - 4) goto LAB_00a1fb53;
            }
            FUN_01674ea0(uVar18,uVar15);
          }
          uStack_6c = 0;
          uStack_68 = 0xf;
          uStack_7c = uStack_7c & 0xffffff00;
          FUN_01674ea0(uStack_88);
          uStack_64 = uVar7 + 1;
          iVar9 = iStack_40;
        } while (uStack_64 < uStack_ec);
      }
      uStack_8._0_1_ = 4;
      if (param_4 != (int *)0x0) {
        uVar7 = ((int)piStack_24 - (int)param_4 >> 2) * 4;
        piVar4 = param_4;
        if (0xfff < uVar7) {
          piVar4 = (int *)param_4[-1];
          uVar7 = uVar7 + 0x23;
          if (0x1f < (uint)((int)param_4 + (-4 - (int)piVar4))) goto LAB_00a1fb53;
        }
        FUN_01674ea0(piVar4,uVar7);
        piStack_2c = (int *)0x0;
        piStack_28 = (int *)0x0;
        piStack_24 = (int *)0x0;
      }
      FUN_00551320();
      iStack_40 = iVar9 + 1;
    } while (piStack_14 != piStack_20);
  }
  piStack_28 = (int *)0x0;
  piStack_24 = (int *)0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  FUN_005542c0("Instance-Parent",0xf);
  uStack_88 = 0;
  uStack_8._0_1_ = 0x19;
  uStack_84 = 0;
  uStack_80 = 0;
  FUN_0054ef60(auStack_38);
  uStack_8._0_1_ = 0x1b;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x1b;
  if (0xf < piStack_24) {
    uVar18 = (int)piStack_24 + 1;
    uVar7 = auStack_38[0];
    if (0xfff < uVar18) {
      uVar7 = *(uint *)(auStack_38[0] - 4);
      uVar18 = (int)piStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar7) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar18);
  }
  piStack_2c = (int *)0x0;
  piStack_28 = (int *)0x0;
  piStack_24 = (int *)0x0;
  iStack_54 = 0;
  puStack_50 = (undefined4 *)0x0;
  puStack_4c = (undefined4 *)0x0;
  uVar7 = iStack_90 - iStack_94 >> 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x1d);
  if (uVar7 != 0) {
    if (0x3fffffff < uVar7) {
LAB_00a1fb5d:
      puStack_4c = (uint *)0x0;
      puStack_50 = (uint *)0x0;
      iStack_54 = 0;
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_007cfd20(uVar7);
  }
  piVar4 = piStack_28;
  uVar7 = iStack_90 - iStack_94 >> 2;
  puVar14 = (undefined4 *)0x0;
  if (uVar7 != 0) {
    if (0x3fffffff < uVar7) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_007cfd20(uVar7);
    puVar14 = puStack_50;
  }
  param_4 = (int *)0x0;
  if (iStack_90 - iStack_94 >> 2 != 0) {
    do {
      uVar7 = *(uint *)(iStack_94 + (int)param_4 * 4);
      puVar10 = puStack_48;
      puVar12 = puStack_48;
      puVar6 = (undefined4 *)puStack_48[1];
      if (*(char *)((int)puStack_48[1] + 0xd) == '\0') {
        do {
          puVar11 = puVar6;
          if ((uint)puVar11[4] < uVar7) {
            puVar6 = (undefined4 *)puVar11[2];
            puVar11 = puVar10;
          }
          else {
            puVar6 = (undefined4 *)*puVar11;
          }
          puVar10 = puVar11;
        } while (*(char *)((int)puVar6 + 0xd) == '\0');
        if ((puVar11 != puStack_48) && ((uint)puVar11[4] <= uVar7)) {
          puVar12 = puVar11;
        }
      }
      if (puVar12 == puStack_48) {
        piStack_14 = (int *)0xffffffff;
      }
      else {
        piStack_14 = (int *)puVar12[5];
      }
      if (piStack_24 == piVar4) {
        FUN_0063d9b0(piVar4,&piStack_14);
      }
      else {
        *piVar4 = (int)piStack_14;
        piStack_28 = piVar4 + 1;
      }
      piVar4 = piStack_28;
      uVar7 = *(uint *)(*(int *)(iStack_94 + (int)param_4 * 4) + 0x34);
      puVar10 = puStack_48;
      puVar12 = puStack_48;
      puVar6 = (undefined4 *)puStack_48[1];
      if (*(char *)((int)puStack_48[1] + 0xd) == '\0') {
        do {
          puVar11 = puVar6;
          if ((uint)puVar11[4] < uVar7) {
            puVar6 = (undefined4 *)puVar11[2];
            puVar11 = puVar10;
          }
          else {
            puVar6 = (undefined4 *)*puVar11;
          }
          puVar10 = puVar11;
        } while (*(char *)((int)puVar6 + 0xd) == '\0');
        if ((puVar11 != puStack_48) && ((uint)puVar11[4] <= uVar7)) {
          puVar12 = puVar11;
        }
      }
      if (puVar12 == puStack_48) {
        piStack_14 = (int *)0xffffffff;
      }
      else {
        piStack_14 = (int *)puVar12[5];
      }
      if (puStack_4c == puVar14) {
        FUN_0063d9b0(puVar14,&piStack_14);
      }
      else {
        *puVar14 = (uint)piStack_14;
        puStack_50 = puVar14 + 1;
      }
      param_4 = (int *)((int)param_4 + 1);
      puVar14 = puStack_50;
    } while (param_4 < (uint)(iStack_90 - iStack_94 >> 2));
  }
  param_4 = (int *)((uint)param_4 & 0xffffff);
  FUN_00a25190((int)&param_4 + 3,1);
  param_4 = (int *)(iStack_90 - iStack_94 >> 2);
  FUN_00a25190(&param_4,4);
  FUN_00a25380(&uStack_88,&piStack_2c);
  FUN_00a25380(&uStack_88,&iStack_54);
  FUN_00a1fca0(param_1,&uStack_88,&DAT_0193fdb8,param_5);
  FUN_0056d320();
  FUN_0056d320();
  uStack_8._0_1_ = 4;
  FUN_00a1ff80();
  piVar4 = param_7;
  if ((((param_5 & 0x20) != 0) && (param_7 != (int *)0x0)) && (param_7[4] != param_7[5])) {
    piStack_28 = (int *)0x0;
    piStack_24 = (int *)0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    FUN_005542c0("Signatures",10);
    uStack_88 = 0;
    uStack_8._0_1_ = 0x1f;
    uStack_84 = 0;
    uStack_80 = 0;
    FUN_0054ef60(auStack_38);
    uStack_8._0_1_ = 0x21;
    FUN_005507b0();
    puVar14 = (uint *)FUN_00a25080(&uStack_ac);
    uVar7 = puVar14[2];
    uVar18 = *puVar14;
    uVar16 = uVar7 + *puVar14;
    uVar15 = puVar14[3];
    uVar1 = puVar14[1];
    *piVar4 = uVar16 + 0x10;
    piVar4[1] = uVar15 + uVar1 + (uint)CARRY4(uVar7,uVar18) + (uint)(0xffffffef < uVar16);
    FUN_00a27590(&uStack_88,piVar4);
    FUN_00a1fca0(param_1,&uStack_88,&DAT_0193fdd0,2);
    puVar14 = (uint *)FUN_00a25080(&uStack_ac);
    uStack_8._0_1_ = 4;
    uVar7 = puVar14[2];
    uVar18 = *puVar14;
    piVar4[3] = puVar14[3] + puVar14[1] + (uint)CARRY4(uVar7,*puVar14);
    piVar4[2] = uVar7 + uVar18;
    FUN_00a1ff80();
  }
  piStack_28 = (int *)0x0;
  piStack_24 = (int *)0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  FUN_005542c0(&DAT_0194073c,3);
  uStack_88 = 0;
  uStack_8._0_1_ = 0x23;
  uStack_84 = 0;
  uStack_80 = 0;
  FUN_0054ef60(auStack_38);
  uStack_8._0_1_ = 0x25;
  FUN_005507b0();
  FUN_00a25190("</roblox>",9);
  FUN_00a1fca0(param_1,&uStack_88,&DAT_0193fdd8,2);
  FUN_00a1ff80();
  FUN_00640e30();
  piVar4 = piStack_20;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x26);
  FUN_00a20180(piStack_20[1]);
  piStack_20[1] = (int)piVar4;
  *piStack_20 = (int)piVar4;
  piStack_20[2] = (int)piVar4;
  uStack_1c = 0;
  FUN_0054db70(piStack_20,0x20);
  FUN_00729fa0();
  FUN_0056d320();
  FUN_0056d320();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20067 ; VA 0x00a1fb70 ; FUN_00a1fb70 */

void FUN_00a1fb70(undefined4 param_1,undefined4 *param_2,undefined4 param_3,uint param_4)

{
  uint uVar1;
  undefined4 uVar2;
  code *pcVar3;
  undefined auStack_2c [4];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dbdc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0171dd10(auStack_2c,param_3,4);
  uVar1 = param_4;
  uStack_28 = 0;
  uStack_20 = 0;
  uStack_24 = param_2[1];
  if ((param_4 & 2) == 0) {
    uVar2 = FUN_01280580(uStack_24);
    FUN_007158e0(uVar2,(int)&param_4 + 3);
    uStack_8 = 0;
    pcVar3 = FUN_01280530;
    if ((uVar1 & 1) != 0) {
      pcVar3 = FUN_01287ec0;
    }
    uVar2 = (*pcVar3)(*param_2,uStack_1c,param_2[1]);
    uStack_28 = uVar2;
    FUN_00554150(auStack_2c,0x10);
    FUN_00554150(uStack_1c,uVar2);
    uStack_8 = 0xffffffff;
    FUN_0056d2d0();
  }
  else {
    FUN_00554150(auStack_2c,0x10);
    FUN_00554150(*param_2,param_2[1]);
  }
  if (DAT_01ee6e50 != '\0') {
    FUN_01677760(DAT_01ee6e50,"Stream: %s",param_2 + 3);
    if (DAT_01ee6e50 != '\0') {
      FUN_01677490(DAT_01ee6e50,"%d -> %d",uStack_24,uStack_28,0);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20068 ; VA 0x00a1fca0 ; FUN_00a1fca0 */

void FUN_00a1fca0(undefined4 param_1,undefined4 *param_2,undefined4 param_3,uint param_4)

{
  uint uVar1;
  undefined4 uVar2;
  code *pcVar3;
  int iVar4;
  undefined auStack_2c [4];
  int iStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dbdc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0171dd10(auStack_2c,param_3,4);
  uVar1 = param_4;
  iStack_28 = 0;
  uStack_20 = 0;
  uStack_24 = param_2[1];
  if ((param_4 & 2) == 0) {
    uVar2 = FUN_01280580(uStack_24);
    FUN_007158e0(uVar2,(int)&param_4 + 3);
    uStack_8 = 0;
    pcVar3 = FUN_01280530;
    if ((uVar1 & 1) != 0) {
      pcVar3 = FUN_01287ec0;
    }
    iVar4 = (*pcVar3)(*param_2,uStack_1c,param_2[1]);
    iStack_28 = iVar4;
    FUN_005af750(auStack_2c,0x10,0);
    FUN_005af750(uStack_1c,iVar4,iVar4 >> 0x1f);
    uStack_8 = 0xffffffff;
    FUN_0056d2d0();
  }
  else {
    FUN_005af750(auStack_2c,0x10,0);
    FUN_005af750(*param_2,param_2[1],0);
  }
  if (DAT_01ee6e50 != '\0') {
    FUN_01677760(DAT_01ee6e50,"Stream: %s",param_2 + 3);
    if (DAT_01ee6e50 != '\0') {
      FUN_01677490(DAT_01ee6e50,"%d -> %d",uStack_24,iStack_28,0);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20069 ; VA 0x00a1fde0 ; FUN_00a1fde0 */

int * __thiscall FUN_00a1fde0(int *param_1,uint param_2)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dbde8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x3fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar1 = FUN_00577ed0(param_2);
    *param_1 = iVar1;
    param_1[1] = iVar1;
    param_1[2] = *param_1 + param_2 * 4;
    iVar1 = *param_1;
    uStack_8 = 1;
    for (; param_2 != 0; param_2 = param_2 - 1) {
      FUN_00a33c70();
      iVar1 = iVar1 + 4;
    }
    param_1[1] = iVar1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20070 ; VA 0x00a1fe83 ; Catch_All@00a1fe83 */

void Catch_All_00a1fe83(void)

{
  FUN_00612dd0();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20071 ; VA 0x00a1fea0 ; FUN_00a1fea0 */

void __fastcall FUN_00a1fea0(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a20180(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20072 ; VA 0x00a1ff00 ; FUN_00a1ff00 */

void __fastcall FUN_00a1ff00(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_00a1ba80(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0xc) * 0xc;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 20073 ; VA 0x00a1ff80 ; FUN_00a1ff80 */

void __fastcall FUN_00a1ff80(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = param_1[8];
  if (0xf < uVar1) {
    iVar2 = param_1[3];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[7] = 0;
  param_1[8] = 0xf;
  *(undefined *)(param_1 + 3) = 0;
  FUN_01674ea0(*param_1);
  return;
}



/* FUNCTION 20074 ; VA 0x00a1ffe0 ; FUN_00a1ffe0 */

undefined4 * __thiscall FUN_00a1ffe0(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  undefined4 uVar1;
  
  uVar1 = *param_1;
  if (param_3 != 0) {
    do {
      *param_2 = 0;
      param_2[1] = 0;
      param_2[2] = 0;
      param_2 = param_2 + 3;
      param_3 = param_3 + -1;
    } while (param_3 != 0);
  }
  FUN_00a1ba80(param_2,param_2,uVar1);
  return param_2;
}



/* FUNCTION 20075 ; VA 0x00a20020 ; FUN_00a20020 */

uint FUN_00a20020(int param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  byte *pbVar5;
  byte *pbVar6;
  bool bVar7;
  
  pbVar6 = *(byte **)(param_1 + 4);
  pbVar5 = *(byte **)(param_2 + 4);
  if (pbVar6 == pbVar5) {
    return param_2 & 0xffffff00;
  }
  uVar1 = *(uint *)(pbVar5 + 0x10);
  if (0xf < *(uint *)(pbVar5 + 0x14)) {
    pbVar5 = *(byte **)pbVar5;
  }
  uVar2 = *(uint *)(pbVar6 + 0x10);
  if (0xf < *(uint *)(pbVar6 + 0x14)) {
    pbVar6 = *(byte **)pbVar6;
  }
  uVar4 = uVar2;
  if (uVar1 < uVar2) {
    uVar4 = uVar1;
  }
  while (uVar3 = uVar4 - 4, 3 < uVar4) {
    if (*(int *)pbVar6 != *(int *)pbVar5) goto LAB_00a20076;
    pbVar6 = pbVar6 + 4;
    pbVar5 = pbVar5 + 4;
    uVar4 = uVar3;
  }
  if (uVar3 != 0xfffffffc) {
LAB_00a20076:
    bVar7 = *pbVar6 < *pbVar5;
    if ((*pbVar6 != *pbVar5) ||
       ((uVar3 != 0xfffffffd &&
        ((bVar7 = pbVar6[1] < pbVar5[1], pbVar6[1] != pbVar5[1] ||
         ((uVar3 != 0xfffffffe &&
          ((bVar7 = pbVar6[2] < pbVar5[2], pbVar6[2] != pbVar5[2] ||
           ((uVar3 != 0xffffffff && (bVar7 = pbVar6[3] < pbVar5[3], pbVar6[3] != pbVar5[3]))))))))))
       )) {
      uVar4 = -(uint)bVar7 | 1;
      goto LAB_00a200ac;
    }
  }
  uVar4 = 0;
LAB_00a200ac:
  if (uVar4 == 0) {
    if (uVar2 < uVar1) {
      return 1;
    }
    uVar4 = 0;
  }
  return uVar4 >> 0x1f;
}



/* FUNCTION 20076 ; VA 0x00a200d0 ; FUN_00a200d0 */

void __thiscall FUN_00a200d0(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x24) * 0x24;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  *param_1 = param_2;
  param_1[1] = param_2 + param_3 * 0x24;
  param_1[2] = param_2 + param_4 * 0x24;
  return;
}



/* FUNCTION 20077 ; VA 0x00a20150 ; FUN_00a20150 */

void __thiscall FUN_00a20150(undefined4 param_1,int param_2)

{
  FUN_006d0070(param_1,param_2 + 0x10);
  FUN_01674ea0(param_2,0x20);
  return;
}



/* FUNCTION 20078 ; VA 0x00a20180 ; FUN_00a20180 */

void FUN_00a20180(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  do {
    if (cVar1 != '\0') {
      return;
    }
    FUN_00a20180(param_1[2]);
    iVar2 = param_1[5];
    piVar3 = (int *)*param_1;
    if (iVar2 != 0) {
      uVar5 = param_1[7] - iVar2 & 0xfffffffc;
      iVar4 = iVar2;
      if (0xfff < uVar5) {
        iVar4 = *(int *)(iVar2 + -4);
        uVar5 = uVar5 + 0x23;
        if (0x1f < (iVar2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar5);
      param_1[5] = 0;
      param_1[6] = 0;
      param_1[7] = 0;
    }
    FUN_01674ea0(param_1,0x20);
    cVar1 = *(char *)((int)piVar3 + 0xd);
    param_1 = piVar3;
  } while( true );
}



/* FUNCTION 20079 ; VA 0x00a20210 ; FUN_00a20210 */

void __thiscall FUN_00a20210(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  
  iVar1 = param_1[1];
  iVar2 = *param_1;
  puVar8 = (undefined4 *)FUN_00618130(param_2);
  puVar3 = (undefined4 *)param_1[1];
  puVar7 = puVar8;
  for (puVar9 = (undefined4 *)*param_1; puVar9 != puVar3; puVar9 = puVar9 + 5) {
    uVar4 = puVar9[1];
    uVar5 = puVar9[2];
    uVar6 = puVar9[3];
    *puVar7 = *puVar9;
    puVar7[1] = uVar4;
    puVar7[2] = uVar5;
    puVar7[3] = uVar6;
    puVar7[4] = puVar9[4];
    puVar7 = puVar7 + 5;
  }
  FUN_00845dd0(puVar8,(iVar1 - iVar2) / 0x14,param_2);
  return;
}



/* FUNCTION 20080 ; VA 0x00a20280 ; FUN_00a20280 */

void __thiscall FUN_00a20280(int *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 *puVar9;
  int iVar10;
  
  iVar2 = param_1[1];
  iVar3 = *param_1;
  iVar8 = FUN_00a203e0(param_2);
  puVar9 = (undefined4 *)*param_1;
  puVar4 = (undefined4 *)param_1[1];
  if (puVar9 != puVar4) {
    iVar10 = iVar8 - (int)puVar9;
    do {
      uVar5 = puVar9[1];
      uVar6 = puVar9[2];
      uVar7 = puVar9[3];
      puVar1 = (undefined4 *)(iVar10 + (int)puVar9);
      *puVar1 = *puVar9;
      puVar1[1] = uVar5;
      puVar1[2] = uVar6;
      puVar1[3] = uVar7;
      uVar5 = puVar9[5];
      uVar6 = puVar9[6];
      uVar7 = puVar9[7];
      puVar1 = (undefined4 *)(iVar10 + 0x10 + (int)puVar9);
      *puVar1 = puVar9[4];
      puVar1[1] = uVar5;
      puVar1[2] = uVar6;
      puVar1[3] = uVar7;
      *(undefined4 *)(iVar10 + 0x20 + (int)puVar9) = puVar9[8];
      puVar9 = puVar9 + 9;
    } while (puVar9 != puVar4);
  }
  FUN_00a200d0(iVar8,(iVar2 - iVar3) / 0x24,param_2);
  return;
}



/* FUNCTION 20081 ; VA 0x00a20300 ; FUN_00a20300 */

void __thiscall FUN_00a20300(int *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined auStack_10 [4];
  int iStack_c;
  undefined uStack_5;
  
  iStack_c = param_1[1] - *param_1 >> 3;
  iVar2 = FUN_00578020(param_2);
  FUN_0055b6b0(&uStack_5,auStack_10,auStack_10);
  FUN_0170cc70(iVar2,*param_1,param_1[1] - *param_1);
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar4 = param_1[2] - iVar1 & 0xfffffff8;
    iVar3 = iVar1;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *param_1 = iVar2;
  param_1[1] = iVar2 + iStack_c * 8;
  param_1[2] = iVar2 + param_2 * 8;
  return;
}



/* FUNCTION 20082 ; VA 0x00a203a0 ; FUN_00a203a0 */

void FUN_00a203a0(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  if (param_1 != param_2) {
    param_3 = param_3 - (int)param_1;
    do {
      uVar2 = param_1[1];
      uVar3 = param_1[2];
      uVar4 = param_1[3];
      puVar1 = (undefined4 *)(param_3 + (int)param_1);
      *puVar1 = *param_1;
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      uVar2 = param_1[5];
      uVar3 = param_1[6];
      uVar4 = param_1[7];
      puVar1 = (undefined4 *)(param_3 + 0x10 + (int)param_1);
      *puVar1 = param_1[4];
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      *(undefined4 *)(param_3 + 0x20 + (int)param_1) = param_1[8];
      param_1 = param_1 + 9;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 20083 ; VA 0x00a203e0 ; FUN_00a203e0 */

uint FUN_00a203e0(uint param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = param_1 * 0x24;
  if (param_1 < 0x71c71c8) {
    if (uVar3 < 0x1000) {
      if (uVar3 != 0) {
        uVar3 = FUN_01674e20(uVar3);
        return uVar3;
      }
      return 0;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar3 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar2;
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 20084 ; VA 0x00a20450 ; FUN_00a20450 */

int * FUN_00a20450(int *param_1,int *param_2,undefined4 param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cfc39;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  (**(code **)(*param_2 + 0x50))(param_1,param_3,1);
  uStack_8 = 0;
  if (*param_1 != 0) {
    FUN_008a65e0(param_2,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20085 ; VA 0x00a204c0 ; FUN_00a204c0 */

void FUN_00a204c0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  FUN_00a212e0(param_1,0,param_2,param_3,param_4,param_5);
  return;
}



/* FUNCTION 20086 ; VA 0x00a204e0 ; FUN_00a204e0 */

void FUN_00a204e0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_00a212e0(param_1,0,param_2,0,param_3,param_4);
  return;
}



/* FUNCTION 20087 ; VA 0x00a20500 ; FUN_00a20500 */

void FUN_00a20500(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_00a212e0(param_1,param_2,0,0,param_3,param_4);
  return;
}



/* FUNCTION 20088 ; VA 0x00a20520 ; FUN_00a20520 */

uint FUN_00a20520(int *param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puVar6;
  int *piVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  undefined4 *puVar11;
  undefined4 uVar12;
  undefined auStack_a0 [4];
  int *piStack_9c;
  uint *puStack_98;
  int *piStack_94;
  uint auStack_90 [4];
  undefined4 uStack_80;
  uint uStack_7c;
  undefined4 uStack_78;
  int *piStack_74;
  undefined4 uStack_70;
  int *piStack_6c;
  int iStack_68;
  undefined4 uStack_64;
  int *piStack_60;
  undefined4 *puStack_5c;
  undefined4 uStack_58;
  int iStack_54;
  undefined auStack_50 [4];
  int *piStack_4c;
  uint uStack_48;
  int iStack_44;
  undefined4 uStack_40;
  int iStack_3c;
  uint uStack_38;
  uint *puStack_34;
  undefined4 *puStack_30;
  uint *puStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  undefined4 *puStack_1c;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar7 = param_1;
  puStack_c = &LAB_017dbe3f;
  pvStack_10 = ExceptionList;
  uVar10 = 0;
  uStack_18 = 0;
  uStack_48 = 0;
  uStack_80 = 0;
  uStack_7c = 0xf;
  auStack_90[0] = auStack_90[0] & 0xffffff00;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a247f0(param_1,auStack_90);
  iVar8 = piVar7[1];
  uVar5 = iVar8 + 1;
  if ((uint)piVar7[2] < uVar5) {
    uVar12 = 1;
  }
  else {
    cVar3 = *(char *)(*piVar7 + iVar8);
    param_1 = (int *)CONCAT13(cVar3,param_1._0_3_);
    piVar7[1] = uVar5;
    if ((cVar3 != '\0') && (cVar3 != '\x01')) {
      FUN_016756b0(&iStack_28,"Unrecognized object format %d",(int)cVar3);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(&iStack_28,&DAT_01c17198);
    }
    if (iVar8 + 5U <= (uint)piVar7[2]) {
      iStack_28 = 0;
      iStack_24 = 0;
      iStack_20 = 0;
      uVar5 = *(uint *)(*piVar7 + uVar5);
      piVar7[1] = iVar8 + 5;
      uStack_8._0_1_ = 1;
      FUN_00a225c0(piVar7,&iStack_28,uVar5);
      iVar8 = 0;
      uVar4 = 0;
      if (uVar5 != 0) {
        do {
          piVar2 = (int *)(iStack_28 + uVar4 * 4);
          *piVar2 = *piVar2 + iVar8;
          iVar8 = *(int *)(iStack_28 + uVar4 * 4);
          uVar4 = uVar4 + 1;
        } while (uVar4 < uVar5);
      }
      cStack_11 = param_1._3_1_ == '\x01';
      iStack_44 = 0;
      uStack_40 = 0;
      iStack_3c = 0;
      uStack_38 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (param_1._3_1_ == '\x01') {
        puVar11 = (undefined4 *)(iStack_24 - iStack_28 >> 2);
        uVar5 = (int)puVar11 + 0x1fU >> 5;
        puStack_30 = puVar11;
        if (uVar5 != 0) {
          FUN_007cfd20(uVar5);
        }
        puStack_1c = (undefined4 *)0x0;
        if (puVar11 != (undefined4 *)0x0) {
          do {
            iVar8 = piVar7[1];
            if ((uint)piVar7[2] < iVar8 + 1U) {
              FUN_016756b0(&iStack_54,
                           "MemoryInputStream::read offset is out of bounds while reading %d bytes",
                           1);
              piVar7 = &iStack_54;
              goto LAB_00a20b2c;
            }
            param_1 = (int *)CONCAT13(*(undefined *)(*piVar7 + iVar8),param_1._0_3_);
            piVar7[1] = iVar8 + 1;
            if (((int)uStack_38 < 0) && (uStack_38 != 0)) {
              iVar8 = -((~uStack_38 >> 5) * 4 + 4);
            }
            else {
              iVar8 = (uStack_38 >> 5) * 4;
            }
            FUN_00656a20(auStack_50,iStack_44 + iVar8,uStack_38 & 0x1f,1,(int)&param_1 + 3);
            puStack_1c = (undefined4 *)((int)puStack_1c + 1);
          } while (puStack_1c < puStack_30);
        }
      }
      iVar8 = FUN_0170d75d(param_2,0,&RBX::Instance::RTTI_Type_Descriptor,
                           &RBX::ServiceProvider::RTTI_Type_Descriptor,0);
      param_1 = (int *)CONCAT13(iVar8 != 0,param_1._0_3_);
      uStack_58 = FUN_0086e830(auStack_90);
      puStack_30 = (undefined4 *)FUN_00892e40(uStack_58);
      puStack_5c = (undefined4 *)(iStack_24 - iStack_28 >> 2);
      puStack_1c = (undefined4 *)0x0;
      if (puStack_5c != (undefined4 *)0x0) {
        do {
          puStack_34 = (uint *)(iStack_28 + (int)puStack_1c * 4);
          if ((uint)(param_3[1] - *param_3 >> 3) <= *puStack_34) {
            puVar11 = (undefined4 *)FUN_005d1bb0(puStack_1c);
            if (DAT_01d65dac != '\0') {
                    /* WARNING: Subroutine does not return */
              FUN_016757c0("Invalid id %d while deserializing instances",*puVar11);
            }
            FUN_016756b0(&iStack_54,"Invalid id %d");
            piVar7 = &iStack_54;
            goto LAB_00a20b2c;
          }
          if (((cStack_11 == '\0') || (param_1._3_1_ == '\0')) ||
             ((*(uint *)(iStack_44 + ((uint)puStack_1c >> 5) * 4) & 1 << ((byte)puStack_1c & 0x1f))
              == 0)) {
            if (puStack_30 == (undefined4 *)0x0) {
              uVar10 = uVar10 | 8;
              piStack_74 = (int *)0x0;
              puVar11 = &uStack_78;
              puStack_2c = (uint *)0x0;
            }
            else {
              puVar11 = (undefined4 *)(**(code **)*puStack_30)(auStack_a0,1);
              piStack_60 = (int *)puVar11[1];
              puStack_2c = (uint *)*puVar11;
              if (piStack_60 != (int *)0x0) {
                LOCK();
                piStack_60[1] = piStack_60[1] + 1;
                UNLOCK();
                piStack_60 = (int *)puVar11[1];
              }
              puVar11 = &uStack_64;
              uVar10 = uVar10 | 6;
            }
            uVar10 = uVar10 | 0x10;
            piStack_6c = (int *)puVar11[1];
            puVar6 = &uStack_70;
            *puVar11 = 0;
            puVar11[1] = 0;
          }
          else {
            puVar6 = (undefined4 *)FUN_00a20450(auStack_50,param_2,uStack_58);
            uVar10 = uVar10 | 1;
            puStack_2c = (uint *)*puVar6;
          }
          puStack_98 = puStack_2c;
          piVar7 = (int *)puVar6[1];
          uStack_18 = uVar10;
          *puVar6 = 0;
          puVar6[1] = 0;
          piVar2 = piStack_6c;
          uStack_8 = 4;
          piStack_94 = piVar7;
          if ((uVar10 & 0x10) != 0) {
            uVar10 = uVar10 & 0xffffffef;
            uStack_18 = uVar10;
            if (piStack_6c != (int *)0x0) {
              LOCK();
              iVar8 = piStack_6c[1] + -1;
              piStack_6c[1] = iVar8;
              UNLOCK();
              if (iVar8 == 0) {
                (**(code **)*piStack_6c)();
                LOCK();
                piVar1 = piVar2 + 2;
                iVar8 = *piVar1 + -1;
                *piVar1 = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)(*piVar2 + 4))();
                }
              }
            }
          }
          piVar2 = piStack_74;
          if ((uVar10 & 8) != 0) {
            uVar10 = uVar10 & 0xfffffff7;
            uStack_18 = uVar10;
            if (piStack_74 != (int *)0x0) {
              LOCK();
              iVar8 = piStack_74[1] + -1;
              piStack_74[1] = iVar8;
              UNLOCK();
              if (iVar8 == 0) {
                (**(code **)*piStack_74)();
                LOCK();
                piVar1 = piVar2 + 2;
                iVar8 = *piVar1 + -1;
                *piVar1 = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)(*piVar2 + 4))();
                }
              }
            }
          }
          piVar2 = piStack_60;
          if ((uVar10 & 4) != 0) {
            uVar10 = uVar10 & 0xfffffffb;
            uStack_18 = uVar10;
            if (piStack_60 != (int *)0x0) {
              LOCK();
              iVar8 = piStack_60[1] + -1;
              piStack_60[1] = iVar8;
              UNLOCK();
              if (iVar8 == 0) {
                (**(code **)*piStack_60)();
                LOCK();
                piVar1 = piVar2 + 2;
                iVar8 = *piVar1 + -1;
                *piVar1 = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)(*piVar2 + 4))();
                }
              }
            }
          }
          piVar2 = piStack_9c;
          if ((uVar10 & 2) != 0) {
            uVar10 = uVar10 & 0xfffffffd;
            uStack_18 = uVar10;
            if (piStack_9c != (int *)0x0) {
              LOCK();
              iVar8 = piStack_9c[1] + -1;
              piStack_9c[1] = iVar8;
              UNLOCK();
              if (iVar8 == 0) {
                (**(code **)*piStack_9c)();
                LOCK();
                piVar1 = piVar2 + 2;
                iVar8 = *piVar1 + -1;
                *piVar1 = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)(*piVar2 + 4))();
                }
              }
            }
          }
          piVar2 = piStack_4c;
          uStack_8 = CONCAT31(uStack_8._1_3_,5);
          if ((uVar10 & 1) != 0) {
            uVar10 = uVar10 & 0xfffffffe;
            uStack_18 = uVar10;
            if (piStack_4c != (int *)0x0) {
              LOCK();
              iVar8 = piStack_4c[1] + -1;
              piStack_4c[1] = iVar8;
              UNLOCK();
              if (iVar8 == 0) {
                (**(code **)*piStack_4c)();
                LOCK();
                piVar1 = piVar2 + 2;
                iVar8 = *piVar1 + -1;
                *piVar1 = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)(*piVar2 + 4))();
                }
              }
            }
          }
          if ((puStack_2c != (uint *)0x0) &&
             (uStack_48 = puStack_2c[3], (*(uint *)(puStack_2c[3] + 0x1d4) >> 2 & 1) != 0)) {
            uVar5 = *puStack_34;
            iVar8 = *param_3;
            if (*(int *)(iVar8 + uVar5 * 8) != 0) {
              puVar11 = (undefined4 *)FUN_005d1bb0(puStack_1c);
              FUN_016756b0(&iStack_68,"Duplicate id %d",*puVar11);
              piVar7 = &iStack_68;
              goto LAB_00a20b2c;
            }
            if (piVar7 != (int *)0x0) {
              LOCK();
              piVar7[1] = piVar7[1] + 1;
              UNLOCK();
            }
            *(uint **)(iVar8 + uVar5 * 8) = puStack_2c;
            piVar2 = *(int **)(iVar8 + 4 + uVar5 * 8);
            *(int **)(iVar8 + 4 + uVar5 * 8) = piVar7;
            if (piVar2 != (int *)0x0) {
              LOCK();
              iVar8 = piVar2[1] + -1;
              piVar2[1] = iVar8;
              UNLOCK();
              if (iVar8 == 0) {
                (**(code **)*piVar2)();
                LOCK();
                iVar8 = piVar2[2] + -1;
                piVar2[2] = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)(*piVar2 + 4))();
                }
              }
            }
            piVar2 = *(int **)(param_4 + 4);
            puStack_34 = puStack_2c;
            if (*(int **)(param_4 + 8) == piVar2) {
              FUN_0063d9b0(piVar2,&puStack_34);
            }
            else {
              *piVar2 = (int)puStack_2c;
              *(int *)(param_4 + 4) = *(int *)(param_4 + 4) + 4;
            }
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          if (piVar7 != (int *)0x0) {
            LOCK();
            iVar8 = piVar7[1] + -1;
            piVar7[1] = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)*piVar7)();
              LOCK();
              iVar8 = piVar7[2] + -1;
              piVar7[2] = iVar8;
              UNLOCK();
              if (iVar8 == 0) {
                (**(code **)(*piVar7 + 4))();
              }
            }
          }
          puStack_1c = (undefined4 *)((int)puStack_1c + 1);
        } while (puStack_1c < puStack_5c);
      }
      iVar8 = iStack_28;
      if (iStack_44 != 0) {
        uVar5 = iStack_3c - iStack_44 & 0xfffffffc;
        iVar9 = iStack_44;
        if (0xfff < uVar5) {
          iVar9 = *(int *)(iStack_44 + -4);
          uVar5 = uVar5 + 0x23;
          if (0x1f < (iStack_44 - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar9,uVar5);
        iStack_44 = 0;
        uStack_40 = 0;
        iStack_3c = 0;
      }
      if (iVar8 != 0) {
        uVar5 = iStack_20 - iVar8 & 0xfffffffc;
        iVar9 = iVar8;
        if (0xfff < uVar5) {
          iVar9 = *(int *)(iVar8 + -4);
          uVar5 = uVar5 + 0x23;
          if (0x1f < (iVar8 - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar9,uVar5);
      }
      if (0xf < uStack_7c) {
        uVar10 = uStack_7c + 1;
        uVar5 = auStack_90[0];
        if (0xfff < uVar10) {
          uVar5 = *(uint *)(auStack_90[0] - 4);
          uVar10 = uStack_7c + 0x24;
          if (0x1f < (auStack_90[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar5,uVar10);
      }
      ExceptionList = pvStack_10;
      return uStack_48;
    }
    uVar12 = 4;
  }
  FUN_016756b0(&iStack_28,"MemoryInputStream::read offset is out of bounds while reading %d bytes",
               uVar12);
  piVar7 = &iStack_28;
LAB_00a20b2c:
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(piVar7,&DAT_01c17198);
}



/* FUNCTION 20089 ; VA 0x00a20b70 ; FUN_00a20b70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00a20b70(int *param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  undefined **ppuVar3;
  int iVar4;
  int iVar5;
  undefined4 ****ppppuVar6;
  int iVar7;
  undefined **ppuVar8;
  uint uVar9;
  uint uVar10;
  int iVar11;
  float10 fVar12;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 ***apppuStack_28 [3];
  undefined auStack_1c [4];
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar5 = param_2;
  piVar2 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ee70;
  pvStack_10 = ExceptionList;
  uVar9 = param_1[1] + 4;
  if ((uint)param_1[2] < uVar9) {
    ExceptionList = &pvStack_10;
    FUN_016756b0(auStack_1c,"MemoryInputStream::read offset is out of bounds while reading %d bytes"
                 ,4);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  iVar11 = *(int *)(*param_1 + param_1[1]);
  ExceptionList = &pvStack_10;
  param_1[1] = uVar9;
  uStack_18 = ((double)iVar11 + (double)(&DAT_018c0d90)[-(iVar11 >> 0x1f)]) /
              (double)*(float *)(param_2 + 0xc);
  fVar12 = (float10)FUN_01725160(uStack_18);
  uStack_18 = (double)fVar12;
  param_1 = (int *)FUN_016f3eb1();
  iVar4 = *(int *)(iVar5 + 8);
  if (iVar4 == 0) {
    iVar4 = *(int *)(iVar5 + 0x14);
    if (iVar4 != 0) {
      iVar1 = *(int *)(iVar5 + 4) * 4;
      uVar9 = iVar1 + 4;
      iVar7 = iVar4;
      if (0xfff < uVar9) {
        iVar7 = *(int *)(iVar4 + -4);
        uVar9 = iVar1 + 0x27;
        uStack_18 = (double)CONCAT44(iVar7,(undefined4)uStack_18);
        if (0x1f < (iVar4 - iVar7) - 4U) goto LAB_00a20e14;
      }
      FUN_01674ea0(iVar7,uVar9);
      *(undefined4 *)(iVar5 + 0x14) = 0;
      *(undefined4 *)(iVar5 + 0x10) = 0;
    }
    ppuVar3 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_1);
    ppuVar8 = ppuVar3 + -1;
    if (ppuVar3 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar8 = ppuVar3;
    }
    *(undefined **)(iVar5 + 4) = *ppuVar8;
  }
  else {
    uStack_18 = ((double)iVar4 + (double)(&DAT_018c0d90)[-(iVar4 >> 0x1f)]) /
                (double)*(float *)(iVar5 + 0xc);
    fVar12 = (float10)FUN_01725280(uStack_18);
    uStack_18 = (double)fVar12;
    if (uStack_18 < _DAT_018c4e98) {
      iVar4 = FUN_016f3eb1();
    }
    else {
      iVar4 = -1;
    }
    uVar9 = iVar4 + 1U;
    if (iVar4 + 1U <= param_1) {
      uVar9 = (uint)param_1;
    }
    param_1 = (int *)uVar9;
    ppuVar3 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_1);
    ppuVar8 = ppuVar3 + -1;
    if (ppuVar3 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar8 = ppuVar3;
    }
    if (*ppuVar8 != *(undefined **)(iVar5 + 4)) {
      FUN_005d7f10();
    }
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  uStack_18 = 3.18299368644791e-313;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  uStack_8 = 1;
  if (iVar11 != 0) {
    do {
      FUN_00a247f0(piVar2,auStack_40);
      FUN_00a247f0(piVar2,apppuStack_28);
      iVar5 = FUN_005d15d0();
      if ((undefined4 ****)(iVar5 + 0x18) != apppuStack_28) {
        ppppuVar6 = apppuStack_28;
        if (0xf < uStack_18._4_4_) {
          ppppuVar6 = (undefined4 ****)apppuStack_28[0];
        }
        FUN_005542c0(ppppuVar6,SUB84(uStack_18,0));
      }
      iVar11 = iVar11 + -1;
    } while (iVar11 != 0);
    if (0xf < uStack_18._4_4_) {
      uVar9 = uStack_18._4_4_ + 1;
      ppppuVar6 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar9) {
        ppppuVar6 = (undefined4 ****)apppuStack_28[0][-1];
        uVar9 = uStack_18._4_4_ + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar6))) {
LAB_00a20e14:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar6,uVar9);
    }
    if (0xf < uStack_2c) {
      uVar10 = uStack_2c + 1;
      uVar9 = auStack_40[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_40[0] - 4);
        uVar10 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20090 ; VA 0x00a20e20 ; FUN_00a20e20 */

void FUN_00a20e20(int *param_1,int param_2,int param_3,int *param_4)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  uint *puVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  int iVar8;
  uint *puVar9;
  uint uVar10;
  int iVar11;
  char *pcVar12;
  undefined4 uVar13;
  undefined auStack_44 [12];
  uint *puStack_38;
  undefined4 uStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  uint uStack_20;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dbe60;
  pvStack_10 = ExceptionList;
  iStack_2c = 0;
  iStack_28 = 0;
  iStack_24 = 0;
  puStack_38 = (uint *)0x0;
  uStack_34 = 0;
  iStack_30 = 0;
  uStack_8 = 1;
  iVar8 = param_1[1];
  uVar10 = iVar8 + 1;
  if ((uint)param_1[2] < uVar10) {
    uVar13 = 1;
    ExceptionList = &pvStack_10;
  }
  else {
    cVar3 = *(char *)(*param_1 + iVar8);
    ExceptionList = &pvStack_10;
    param_1[1] = uVar10;
    if (cVar3 != '\0') {
      FUN_016756b0(auStack_44,"Unrecognized parent link format %d",(int)cVar3);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_44,&DAT_01c17198);
    }
    if (iVar8 + 5U <= (uint)param_1[2]) {
      uVar10 = *(uint *)(*param_1 + uVar10);
      param_1[1] = iVar8 + 5U;
      FUN_00a225c0(param_1,&iStack_2c,uVar10);
      iVar8 = 0;
      uVar5 = 0;
      if (uVar10 != 0) {
        do {
          piVar2 = (int *)(iStack_2c + uVar5 * 4);
          *piVar2 = *piVar2 + iVar8;
          iVar8 = *(int *)(iStack_2c + uVar5 * 4);
          uVar5 = uVar5 + 1;
        } while (uVar5 < uVar10);
      }
      FUN_00a225c0(param_1,&puStack_38,uVar10);
      puVar4 = puStack_38;
      uVar5 = 0;
      uVar6 = 0;
      if (uVar10 != 0) {
        do {
          puStack_38[uVar6] = puStack_38[uVar6] + uVar5;
          uVar5 = puStack_38[uVar6];
          uVar6 = uVar6 + 1;
        } while (uVar6 < uVar10);
      }
      uVar10 = 0;
      uStack_20 = iStack_28 - iStack_2c >> 2;
      if (uStack_20 != 0) {
        iStack_1c = iStack_2c - (int)puStack_38;
        puVar9 = puStack_38;
        do {
          iVar8 = *param_4;
          uVar5 = param_4[1] - iVar8 >> 3;
          if (uVar5 <= *(uint *)(iStack_1c + (int)puVar9)) {
            puVar7 = (undefined4 *)FUN_005d1bb0(uVar10);
            uVar13 = *puVar7;
            if (DAT_01d65dac != '\0') {
                    /* WARNING: Subroutine does not return */
              FUN_016757c0("Invalid object id %d while deserializing parents",uVar13);
            }
LAB_00a2101d:
            pcVar12 = "Invalid id %d";
            goto LAB_00a21091;
          }
          piStack_18 = (int *)(iVar8 + *(uint *)(iStack_1c + (int)puVar9) * 8);
          iStack_14 = *piStack_18;
          if (iStack_14 != 0) {
            uVar6 = *puVar9;
            if (uVar6 == 0xffffffff) {
              if (param_2 != 0) {
                FUN_008a65e0(param_2,0);
              }
              if (param_3 != 0) {
                piVar2 = *(int **)(param_3 + 4);
                if (*(int **)(param_3 + 8) == piVar2) {
                  FUN_005c1970(piVar2,piStack_18);
                }
                else {
                  *piVar2 = 0;
                  piVar2[1] = 0;
                  if (piStack_18[1] != 0) {
                    LOCK();
                    piVar1 = (int *)(piStack_18[1] + 4);
                    *piVar1 = *piVar1 + 1;
                    UNLOCK();
                  }
                  *piVar2 = *piStack_18;
                  piVar2[1] = piStack_18[1];
                  *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 8;
                }
              }
            }
            else {
              if (uVar5 <= uVar6) {
                puVar7 = (undefined4 *)FUN_005d1bb0(uVar10);
                uVar13 = *puVar7;
                if (DAT_01d65dac != '\0') {
                    /* WARNING: Subroutine does not return */
                  FUN_016757c0("Invalid parent id %d while deserializing parents",uVar13);
                }
                goto LAB_00a2101d;
              }
              FUN_008a65e0(*(undefined4 *)(iVar8 + uVar6 * 8),0);
            }
          }
          uVar10 = uVar10 + 1;
          puVar9 = puVar9 + 1;
        } while (uVar10 < uStack_20);
      }
      iVar8 = iStack_2c;
      if (puVar4 != (uint *)0x0) {
        uVar10 = iStack_30 - (int)puVar4 & 0xfffffffc;
        puVar9 = puVar4;
        if (0xfff < uVar10) {
          puVar9 = (uint *)puVar4[-1];
          uVar10 = uVar10 + 0x23;
          if (0x1f < (uint)((int)puVar4 + (-4 - (int)puVar9))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(puVar9,uVar10);
      }
      if (iVar8 != 0) {
        uVar10 = iStack_24 - iVar8 & 0xfffffffc;
        iVar11 = iVar8;
        if (0xfff < uVar10) {
          iVar11 = *(int *)(iVar8 + -4);
          uVar10 = uVar10 + 0x23;
          if (0x1f < (iVar8 - iVar11) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar11,uVar10);
      }
      ExceptionList = pvStack_10;
      return;
    }
    uVar13 = 4;
  }
  pcVar12 = "MemoryInputStream::read offset is out of bounds while reading %d bytes";
LAB_00a21091:
  FUN_016756b0(auStack_44,pcVar12,uVar13);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_44,&DAT_01c17198);
}



/* FUNCTION 20091 ; VA 0x00a210f0 ; FUN_00a210f0 */

void FUN_00a210f0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  undefined4 auStack_6c [2];
  undefined8 uStack_64;
  uint uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  undefined8 uStack_44;
  undefined auStack_3c [12];
  undefined auStack_30 [12];
  undefined auStack_24 [12];
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar4 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dbe89;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  piVar1 = param_1 + 1;
  uVar6 = *piVar1 + 4;
  if ((uint)param_1[2] < uVar6) {
    ExceptionList = &pvStack_10;
    FUN_016756b0(auStack_24,"MemoryInputStream::read offset is out of bounds while reading %d bytes"
                 ,4);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_24,&DAT_01c17198);
  }
  iVar2 = *param_1;
  param_1 = (int *)0x0;
  uStack_18 = *(uint *)(iVar2 + *piVar1);
  ExceptionList = &pvStack_10;
  piVar4[1] = uVar6;
  if (uStack_18 != 0) {
    do {
      iVar2 = piVar4[1];
      uStack_8 = 0;
      uStack_4c = 0;
      uStack_48 = 0xf;
      uVar6 = iVar2 + 4;
      uStack_5c = uStack_5c & 0xffffff00;
      uStack_44 = 0;
      uStack_14 = 1;
      if ((uint)piVar4[2] < uVar6) {
        FUN_016756b0(auStack_3c,
                     "MemoryInputStream::read offset is out of bounds while reading %d bytes",4);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_3c,&DAT_01c17198);
      }
      auStack_6c[0] = *(undefined4 *)(*piVar4 + iVar2);
      piVar4[1] = uVar6;
      if ((uint)piVar4[2] < iVar2 + 0xcU) {
        FUN_016756b0(auStack_30,
                     "MemoryInputStream::read offset is out of bounds while reading %d bytes",8);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_30,&DAT_01c17198);
      }
      uStack_64 = *(undefined8 *)(*piVar4 + uVar6);
      piVar4[1] = iVar2 + 0xcU;
      FUN_00a247f0(piVar4,&uStack_5c);
      puVar3 = *(undefined4 **)(param_2 + 0x14);
      if (*(undefined4 **)(param_2 + 0x18) == puVar3) {
        FUN_00a1bd90(puVar3,auStack_6c);
        uVar6 = uStack_48;
      }
      else {
        *puVar3 = auStack_6c[0];
        puVar3[2] = (undefined4)uStack_64;
        puVar3[3] = uStack_64._4_4_;
        puVar3[8] = 0;
        puVar3[9] = 0;
        puVar3[4] = uStack_5c;
        puVar3[5] = uStack_58;
        puVar3[6] = uStack_54;
        puVar3[7] = uStack_50;
        uStack_5c = uStack_5c & 0xffffff00;
        *(ulonglong *)(puVar3 + 8) = CONCAT44(uStack_48,uStack_4c);
        puVar3[10] = (undefined4)uStack_44;
        puVar3[0xb] = uStack_44._4_4_;
        *(int *)(param_2 + 0x14) = *(int *)(param_2 + 0x14) + 0x30;
        uVar6 = 0xf;
      }
      uStack_8 = 0xffffffff;
      if (0xf < uVar6) {
        uVar7 = uVar6 + 1;
        uVar5 = uStack_5c;
        if (0xfff < uVar7) {
          uVar5 = *(uint *)(uStack_5c - 4);
          uVar7 = uVar6 + 0x24;
          if (0x1f < (uStack_5c - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar5,uVar7);
      }
      param_1 = (int *)((int)param_1 + 1);
    } while (param_1 < uStack_18);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20092 ; VA 0x00a212e0 ; FUN_00a212e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00a212e0(int *param_1,undefined4 param_2,undefined4 param_3,int param_4,uint param_5,
                 int *param_6)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint *puVar4;
  undefined4 uVar5;
  undefined4 ****ppppuVar6;
  int iVar7;
  uint uVar8;
  int *piVar9;
  uint uVar10;
  uint uVar11;
  int iVar12;
  bool bVar13;
  undefined auStack_f8 [16];
  int iStack_e8;
  int iStack_e4;
  int iStack_e0;
  short sStack_dc;
  short sStack_da;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined auStack_c8 [12];
  int iStack_bc;
  int iStack_b8;
  uint uStack_b4;
  uint uStack_b0;
  undefined auStack_ac [16];
  undefined4 uStack_9c;
  undefined4 uStack_98;
  int iStack_94;
  int iStack_90;
  uint uStack_84;
  undefined4 ***apppuStack_80 [2];
  undefined4 uStack_78;
  int iStack_74;
  uint uStack_70;
  uint uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  int iStack_50;
  int *piStack_4c;
  int *piStack_48;
  undefined uStack_41;
  int iStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  undefined auStack_34 [12];
  uint *puStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  uint uStack_1c;
  int iStack_18;
  char cStack_13;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dbf07;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005af630(&iStack_e8,0x20,0);
  if ((param_1[2] != 0x20) || (param_1[3] != 0)) {
    FUN_016756b0(auStack_34,"Unexpected end of file while reading %d bytes",0x20);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_34,&DAT_01c17198);
  }
  if ((iStack_e8 != DAT_0193fd94) || (iStack_e4 != DAT_0193fd98)) {
    if (DAT_01d65dac != '\0') {
      FUN_0056a400(&iStack_e8);
      FUN_00a21d20(auStack_ac);
      uStack_8 = 0;
      uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Unrecognized format: %s",uVar5);
    }
    FUN_016756b0(auStack_34,"Unrecognized format");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_34,&DAT_01c17198);
  }
  if ((iStack_e0 != DAT_0193fda0) || (sStack_dc != DAT_0193fda4)) {
    if (DAT_01d65dac != '\0') {
      FUN_0056a400(&iStack_e0);
      FUN_00a21d20(auStack_ac);
      uStack_8 = 1;
      uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("The file header is corrupted, unexpected signature: %s",uVar5);
    }
    FUN_016756b0(auStack_34,"The file header is corrupted");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_34,&DAT_01c17198);
  }
  if (sStack_da != 0) {
    FUN_016756b0(&iStack_94,"Unrecognized version %d",sStack_da);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(&iStack_94,&DAT_01c17198);
  }
  iStack_5c = 0;
  iStack_58 = 0;
  iStack_54 = 0;
  uStack_8 = 2;
  FUN_0055b820(uStack_d8,&iStack_5c);
  uStack_68 = 0;
  uStack_64 = 0;
  uStack_60 = 0;
  uStack_8._0_1_ = 3;
  FUN_00714e40(uStack_d4,&uStack_68);
  iStack_40 = 0;
  uStack_3c = 0;
  iStack_38 = 0;
  uStack_8._0_1_ = 4;
  FUN_00a1d3c0(uStack_d8,&iStack_40);
  iStack_50 = 0;
  piStack_4c = (int *)0x0;
  piStack_48 = (int *)0x0;
  iVar12 = 0;
  uStack_8._0_1_ = 5;
  cStack_13 = '\x01';
  iStack_18 = 0;
  cStack_11 = '\0';
  cStack_12 = '\0';
  iVar7 = *(int *)(*(int *)(*param_1 + 4) + 0xc + (int)param_1);
  do {
    if (iVar7 != 0) {
      if (DAT_01d65dac == '\0') {
        FUN_016756b0(auStack_c8,"Unexpected end of file");
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_c8,&DAT_01c17198);
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Unexpected end of file after reading %d chunks",iVar12);
    }
    puStack_28 = (uint *)0x0;
    uStack_24 = 0;
    uStack_20 = 0;
    uStack_8._0_1_ = 6;
    FUN_005af630(&iStack_bc,0x10,0);
    if ((param_1[2] != 0x10) || (param_1[3] != 0)) {
      FUN_016756b0(auStack_c8,"Unexpected end of file while reading %d bytes",0x10);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_c8,&DAT_01c17198);
    }
    puVar4 = (uint *)FUN_01674e20(uStack_b4);
    puStack_28 = puVar4;
    FUN_01674ea0(0);
    uVar10 = uStack_b4;
    uStack_1c = uStack_b4;
    uStack_20 = uStack_b4;
    uStack_24 = 0;
    if (uStack_b4 != 0) {
      if (iStack_b8 == 0) {
        FUN_00a221c0(param_1,puVar4,uStack_b4);
      }
      else {
        FUN_007158e0(iStack_b8,&uStack_41);
        iVar7 = iStack_94;
        iVar12 = iStack_90 - iStack_94;
        uStack_8._0_1_ = 7;
        FUN_00a221c0(param_1,iStack_94,iVar12);
        uVar8 = FUN_01281920(iVar7,puStack_28,iVar12,uStack_1c);
        uVar10 = uStack_1c;
        if (uVar8 != uStack_1c) {
          FUN_016756b0(auStack_34,"Malformed data (%d != %d)",uVar8,uStack_1c);
                    /* WARNING: Subroutine does not return */
          FUN_0170c2a8(auStack_34,&DAT_01c17198);
        }
        uStack_8._0_1_ = 6;
        FUN_0056d2d0();
      }
    }
    uStack_78 = iStack_bc;
    iStack_74 = iStack_b8;
    uStack_70 = uStack_b4;
    uStack_6c = uStack_b0;
    if (iStack_bc == DAT_0193fda8) {
      if (uVar10 < 4) {
        FUN_016756b0(auStack_34,
                     "MemoryInputStream::read offset is out of bounds while reading %d bytes",4);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_34,&DAT_01c17198);
      }
      uStack_24 = 4;
      uVar10 = *puStack_28;
      if ((uint)(iStack_58 - iStack_5c >> 2) <= uVar10) {
        uStack_84 = uVar10;
        if (DAT_01d65dac != '\0') {
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("Type index out of bounds in chunk instances: %d, chunkId: %d",uVar10,
                       iStack_18);
        }
LAB_00a21b58:
        FUN_016756b0(auStack_34,"Type index out of bounds: %d",uStack_84);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_34,&DAT_01c17198);
      }
      if (*(int *)(uVar10 * 4 + iStack_5c) != 0) {
        if (DAT_01d65dac != '\0') {
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("Duplicate type index: %d, chunkId: %d",uVar10,iStack_18);
        }
        FUN_016756b0(auStack_34,"Duplicate type index: %d",uVar10);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_34,&DAT_01c17198);
      }
      uVar5 = FUN_00a20520(&puStack_28,param_2,&uStack_68,iStack_40 + uVar10 * 0xc,param_5);
      *(undefined4 *)(uVar10 * 4 + iStack_5c) = uVar5;
    }
    else if (iStack_bc == DAT_0193fdb0) {
      FUN_00a1da60(&puStack_28,&uStack_84);
      if ((uint)(iStack_58 - iStack_5c >> 2) <= uStack_84) {
        if (DAT_01d65dac != '\0') {
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("Type index out of bounds in chunk properties: %d, chunkId %d",uStack_84,
                       iStack_18);
        }
        goto LAB_00a21b58;
      }
      if (*(int *)(iStack_5c + uStack_84 * 4) != 0) {
        uStack_70 = 0;
        uStack_6c = 0xf;
        apppuStack_80[0] = (undefined4 ***)((uint)apppuStack_80[0] & 0xffffff00);
        uStack_1c = iStack_40 + uStack_84 * 0xc;
        uStack_8 = CONCAT31(uStack_8._1_3_,8);
        FUN_00a247f0(&puStack_28,apppuStack_80);
        ppppuVar6 = apppuStack_80;
        if (0xf < uStack_6c) {
          ppppuVar6 = (undefined4 ****)apppuStack_80[0];
        }
        iVar7 = FUN_00892d20(ppppuVar6);
        if ((iVar7 != 0) && ((*(uint *)(iVar7 + 0x24) >> 3 & 1) != 0)) {
          FUN_00a229a0(&puStack_28,iVar7,uStack_1c,&uStack_68,&iStack_50,param_5);
        }
        uStack_8._0_1_ = 6;
        if (0xf < uStack_6c) {
          uVar10 = uStack_6c + 1;
          ppppuVar6 = (undefined4 ****)apppuStack_80[0];
          if (0xfff < uVar10) {
            ppppuVar6 = (undefined4 ****)apppuStack_80[0][-1];
            uVar10 = uStack_6c + 0x24;
            if (0x1f < (uint)((int)apppuStack_80[0] + (-4 - (int)ppppuVar6))) goto LAB_00a21c16;
          }
          FUN_01674ea0(ppppuVar6,uVar10);
        }
      }
    }
    else if (iStack_bc == DAT_0193fdb8) {
      FUN_00a20e20(&puStack_28,param_2,param_3,&uStack_68,param_5);
    }
    else if (iStack_bc == DAT_0193fdc0) {
      if (DAT_01d65dac == '\0') {
        if (cStack_13 == '\0') {
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("Unexpected metadata chunk");
        }
      }
      else if (0 < iStack_18) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Unexpected metadata chunk, chunkId: %d",iStack_18);
      }
      if (uStack_b0 != 0) {
        if (DAT_01d65dac != '\0') {
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("Unrecognized metadata chunk version: %u, chunkId: %d",uStack_b0,iStack_18);
        }
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Unrecognized metadata chunk version");
      }
      if (param_4 != 0) {
        FUN_00a20b70(&puStack_28,param_4,param_5);
      }
    }
    else {
      if (iStack_bc == _DAT_0193fdc8) {
LAB_00a21746:
        uVar8 = 0;
      }
      else {
        bVar13 = (byte)iStack_bc < DAT_0193fdc8;
        if ((byte)iStack_bc == DAT_0193fdc8) {
          uStack_78._1_1_ = (byte)((uint)iStack_bc >> 8);
          bVar13 = uStack_78._1_1_ < DAT_0193fdc9;
          if (uStack_78._1_1_ == DAT_0193fdc9) {
            uStack_78._2_1_ = (byte)((uint)iStack_bc >> 0x10);
            bVar13 = uStack_78._2_1_ < DAT_0193fdca;
            if (uStack_78._2_1_ == DAT_0193fdca) {
              uStack_78._3_1_ = (byte)((uint)iStack_bc >> 0x18);
              bVar13 = uStack_78._3_1_ < DAT_0193fdcb;
              if (uStack_78._3_1_ == DAT_0193fdcb) goto LAB_00a21746;
            }
          }
        }
        uVar8 = -(uint)bVar13 | 1;
      }
      if (uVar8 == 0) {
        if (cStack_11 != '\0') {
          if (DAT_01d65dac != '\0') {
                    /* WARNING: Subroutine does not return */
            FUN_016757c0("File contained multiple shared strings blocks, second chunkId: %d",
                         iStack_18);
          }
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("File contained multiple shared strings blocks");
        }
        cStack_11 = '\x01';
        uStack_1c = uVar8;
        FUN_00a1da60(&puStack_28,&uStack_1c);
        if (uStack_1c != 0) {
          if (DAT_01d65dac != '\0') {
                    /* WARNING: Subroutine does not return */
            FUN_016757c0("Unknown shared string dictionary version: %d, chunkId: %d",uStack_1c,
                         iStack_18);
          }
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("Unknown shared string dictionary version");
        }
        FUN_00a1da60(&puStack_28,&uStack_1c);
        uVar10 = uStack_1c;
        if ((uint)((int)piStack_48 - iStack_50 >> 2) < uStack_1c) {
          if (0x3fffffff < uStack_1c) {
                    /* WARNING: Subroutine does not return */
            FUN_00577c30();
          }
          FUN_006c8e30(uStack_1c);
        }
        uStack_9c = 0;
        uStack_98 = 0xf;
        auStack_ac[0] = 0;
        uStack_8._0_1_ = 9;
        for (; uVar10 != 0; uVar10 = uVar10 - 1) {
          FUN_00a22020(auStack_f8,0x10);
          FUN_00a247f0(&puStack_28,auStack_ac);
          piVar9 = (int *)FUN_00a33be0(auStack_ac);
          uStack_8._0_1_ = 10;
          if (piStack_48 == piStack_4c) {
            FUN_00602fc0(piStack_4c,piVar9);
          }
          else {
            iVar7 = *piVar9;
            *piStack_4c = iVar7;
            LOCK();
            piVar9 = (int *)(iVar7 + 0x28);
            *piVar9 = *piVar9 + 1;
            UNLOCK();
            piStack_4c = piStack_4c + 1;
          }
          uStack_8._0_1_ = 9;
          FUN_0056cd30();
        }
        FUN_005507b0();
      }
      else if (iStack_bc == DAT_0193fdd0) {
        if (cStack_12 != '\0') {
          if (DAT_01d65dac != '\0') {
                    /* WARNING: Subroutine does not return */
            FUN_016757c0("File contained multiple signature blocks, second chunkId: %d",iStack_18);
          }
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("File contained multiple signature blocks");
        }
        cStack_12 = '\x01';
        if (((param_5 & 2) != 0) && (param_6 != (int *)0x0)) {
          puVar4 = (uint *)FUN_005957d0(auStack_ac);
          uVar8 = puVar4[2];
          uVar1 = puVar4[3];
          uVar11 = uVar8 - uVar10;
          uVar2 = *puVar4;
          uVar3 = puVar4[1];
          *param_6 = uVar11 + *puVar4;
          param_6[1] = (uVar1 - (uVar8 < uVar10)) + uVar3 + (uint)CARRY4(uVar11,uVar2);
          FUN_00a210f0(&puStack_28,param_6);
          puVar4 = (uint *)FUN_005957d0(auStack_ac);
          uVar10 = puVar4[2];
          uVar8 = *puVar4;
          uVar1 = puVar4[3];
          uVar2 = puVar4[1];
          param_6[2] = uVar10 + *puVar4;
          param_6[3] = uVar1 + uVar2 + (uint)CARRY4(uVar10,uVar8);
        }
      }
      else if (iStack_bc == DAT_0193fdd8) {
        FUN_01674ea0(puStack_28);
        FUN_00612dd0();
        if (iStack_40 != 0) {
          FUN_00a1ba80(iStack_40,uStack_3c,&iStack_40);
          uVar10 = ((iStack_38 - iStack_40) / 0xc) * 0xc;
          iVar7 = iStack_40;
          if (0xfff < uVar10) {
            iVar7 = *(int *)(iStack_40 + -4);
            uVar10 = uVar10 + 0x23;
            if (0x1f < (iStack_40 - iVar7) - 4U) {
LAB_00a21c16:
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar7,uVar10);
          iStack_40 = 0;
          uStack_3c = 0;
          iStack_38 = 0;
        }
        thunk_FUN_00577ac0();
        if (iStack_5c != 0) {
          uVar10 = iStack_54 - iStack_5c & 0xfffffffc;
          iVar7 = iStack_5c;
          if (0xfff < uVar10) {
            iVar7 = *(int *)(iStack_5c + -4);
            uVar10 = uVar10 + 0x23;
            if (0x1f < (iStack_5c - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar7,uVar10);
        }
        ExceptionList = pvStack_10;
        return;
      }
    }
    iVar12 = iStack_18 + 1;
    cStack_13 = '\0';
    uStack_8._0_1_ = 5;
    iStack_18 = iVar12;
    FUN_01674ea0(puStack_28);
    iVar7 = *(int *)(*(int *)(*param_1 + 4) + 0xc + (int)param_1);
  } while( true );
}



/* FUNCTION 20093 ; VA 0x00a21d20 ; FUN_00a21d20 */

int * FUN_00a21d20(int *param_1,byte *param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  int *piVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  int aiStack_40 [5];
  uint uStack_2c;
  byte *pbStack_28;
  undefined4 uStack_24;
  byte *pbStack_20;
  uint uStack_1c;
  int iStack_18;
  byte bStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017dbf41;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  pbStack_28 = param_2 + param_3;
  uStack_8 = 0;
  uStack_24 = 1;
  pbStack_20 = param_2;
  if (param_2 != pbStack_28) {
    do {
      bStack_11 = *pbStack_20;
      if (((bStack_11 & 0x1f) == bStack_11) || ((char)bStack_11 < '\0')) {
        puVar4 = (undefined4 *)FUN_01675640(aiStack_40,"\\x%02x",bStack_11);
        puVar1 = puVar4 + 4;
        uStack_8 = 1;
        if (0xf < (uint)puVar4[5]) {
          puVar4 = (undefined4 *)*puVar4;
        }
        FUN_00554150(puVar4,*puVar1);
        uStack_8 = uStack_8 & 0xffffff00;
        if (0xf < uStack_2c) {
          uVar5 = uStack_2c + 1;
          iVar6 = aiStack_40[0];
          if (0xfff < uVar5) {
            iVar6 = *(int *)(aiStack_40[0] + -4);
            uVar5 = uStack_2c + 0x24;
            if (0x1f < (aiStack_40[0] - iVar6) - 4U) goto LAB_00a21f18;
          }
          FUN_01674ea0(iVar6,uVar5);
        }
      }
      else {
        uStack_1c = param_1[5];
        uVar5 = param_1[4];
        if (uVar5 < uStack_1c) {
          param_1[4] = uVar5 + 1;
          piVar3 = param_1;
          if (0xf < uStack_1c) {
            piVar3 = (int *)*param_1;
          }
          *(byte *)((int)piVar3 + uVar5) = bStack_11;
          *(undefined *)((int)piVar3 + uVar5 + 1) = 0;
        }
        else {
          if (uVar5 == 0x7fffffff) {
            FUN_00554040();
LAB_00a21f18:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
          uVar7 = uVar5 + 1 | 0xf;
          if (uVar7 < 0x80000000) {
            if (0x7fffffff - (uStack_1c >> 1) < uStack_1c) {
              uVar7 = 0x7fffffff;
            }
            else {
              uVar2 = (uStack_1c >> 1) + uStack_1c;
              if (uVar7 < uVar2) {
                uVar7 = uVar2;
              }
            }
          }
          else {
            uVar7 = 0x7fffffff;
          }
          iStack_18 = FUN_00554060(uVar7 + 1);
          param_1[4] = uVar5 + 1;
          param_1[5] = uVar7;
          if (uStack_1c < 0x10) {
            FUN_0170c6f0(iStack_18,param_1,uVar5);
            *(byte *)(iStack_18 + uVar5) = bStack_11;
            *(undefined *)(iStack_18 + 1 + uVar5) = 0;
            *param_1 = iStack_18;
          }
          else {
            iVar6 = *param_1;
            FUN_0170c6f0(iStack_18,iVar6,uVar5);
            *(byte *)(iStack_18 + uVar5) = bStack_11;
            *(undefined *)(iStack_18 + 1 + uVar5) = 0;
            uVar5 = uStack_1c + 1;
            iVar8 = iVar6;
            if (0xfff < uVar5) {
              iVar8 = *(int *)(iVar6 + -4);
              uVar5 = uStack_1c + 0x24;
              if (0x1f < (iVar6 - iVar8) - 4U) goto LAB_00a21f18;
            }
            FUN_01674ea0(iVar8,uVar5);
            *param_1 = iStack_18;
          }
        }
      }
      pbStack_20 = pbStack_20 + 1;
    } while (pbStack_20 != pbStack_28);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20094 ; VA 0x00a21f20 ; FUN_00a21f20 */

void __thiscall FUN_00a21f20(byte *param_1,undefined4 *param_2,undefined4 param_3)

{
  byte bVar1;
  undefined4 uVar2;
  
  bVar1 = *param_1;
  uVar2 = FUN_00a33fd0(param_3);
  FUN_0063f830(&param_3,uVar2,param_3,
               -(uint)(param_1 + bVar1 + 1 != (byte *)0x0) & (uint)(param_1 + bVar1 + 1 + 1));
  *param_2 = param_3;
  return;
}



/* FUNCTION 20095 ; VA 0x00a21f70 ; FUN_00a21f70 */

undefined4 FUN_00a21f70(int *param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar1 = (undefined4 *)*param_1;
  puVar2 = puVar1;
  puVar4 = (undefined4 *)puVar1[1];
  if (*(char *)((int)puVar1[1] + 0xd) == '\0') {
    do {
      puVar3 = puVar4;
      if ((uint)puVar3[4] < param_2) {
        puVar4 = (undefined4 *)puVar3[2];
        puVar3 = puVar2;
      }
      else {
        puVar4 = (undefined4 *)*puVar3;
      }
      puVar2 = puVar3;
    } while (*(char *)((int)puVar4 + 0xd) == '\0');
    if ((puVar3 != puVar1) && ((uint)puVar3[4] <= param_2)) goto LAB_00a21fa6;
  }
  puVar3 = puVar1;
LAB_00a21fa6:
  if (puVar3 != puVar1) {
    return puVar3[5];
  }
  return 0xffffffff;
}



/* FUNCTION 20096 ; VA 0x00a21fc0 ; FUN_00a21fc0 */

void __thiscall FUN_00a21fc0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    uVar2 = param_2[1];
    uVar3 = param_2[2];
    uVar4 = param_2[3];
    *puVar1 = *param_2;
    puVar1[1] = uVar2;
    puVar1[2] = uVar3;
    puVar1[3] = uVar4;
    puVar1[4] = param_2[4];
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x14;
    return;
  }
  FUN_00a1baf0(puVar1,param_2);
  return;
}



/* FUNCTION 20097 ; VA 0x00a21ff0 ; FUN_00a21ff0 */

void __thiscall FUN_00a21ff0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    *puVar1 = *param_2;
    puVar1[1] = param_2[1];
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 8;
    return;
  }
  FUN_006c6ad0(puVar1,param_2);
  return;
}



/* FUNCTION 20098 ; VA 0x00a22020 ; FUN_00a22020 */

void __thiscall FUN_00a22020(int *param_1,undefined4 param_2,int param_3)

{
  undefined auStack_10 [12];
  
  if ((uint)(param_1[1] + param_3) <= (uint)param_1[2]) {
    FUN_0170c6f0(param_2,*param_1 + param_1[1]);
    param_1[1] = param_1[1] + param_3;
    return;
  }
  FUN_016756b0(auStack_10,"MemoryInputStream::read offset is out of bounds while reading %d bytes",
               param_3);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 20099 ; VA 0x00a22080 ; FUN_00a22080 */

void FUN_00a22080(int *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dbf60;
  pvStack_10 = ExceptionList;
  uVar4 = param_1[1] + 4;
  if ((uint)param_1[2] < uVar4) {
    uVar5 = 4;
    ExceptionList = &pvStack_10;
LAB_00a22198:
    FUN_016756b0(&uStack_38,"MemoryInputStream::read offset is out of bounds while reading %d bytes"
                 ,uVar5);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(&uStack_38,&DAT_01c17198);
  }
  uVar2 = *(uint *)(*param_1 + param_1[1]);
  ExceptionList = &pvStack_10;
  param_1[1] = uVar4;
  uStack_20 = 0;
  puStack_1c = (undefined4 *)0x0;
  puStack_18 = (undefined4 *)0x0;
  uStack_8 = 0;
  if (uVar2 != 0) {
    if (0xccccccc < uVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_00a20210(uVar2);
  }
  uVar4 = 0;
  if (uVar2 != 0) {
    do {
      iVar3 = param_1[1];
      if ((uint)param_1[2] < iVar3 + 0x14U) {
        uVar5 = 0x14;
        goto LAB_00a22198;
      }
      puVar1 = (undefined4 *)(*param_1 + iVar3);
      uStack_40 = *puVar1;
      uStack_3c = puVar1[1];
      uStack_38 = puVar1[2];
      uStack_34 = puVar1[3];
      uStack_30 = *(undefined4 *)(*param_1 + 0x10 + iVar3);
      param_1[1] = iVar3 + 0x14;
      uStack_14 = uStack_30;
      if (puStack_18 == puStack_1c) {
        FUN_00a1baf0(puStack_1c,&uStack_40);
      }
      else {
        *puStack_1c = uStack_40;
        puStack_1c[1] = uStack_3c;
        puStack_1c[2] = uStack_38;
        puStack_1c[3] = uStack_34;
        puStack_1c[4] = uStack_30;
        puStack_1c = puStack_1c + 5;
      }
      uVar4 = uVar4 + 1;
    } while (uVar4 < uVar2);
  }
  FUN_00a8e070(&uStack_20,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (param_2 != &uStack_2c) {
    FUN_00602830(uStack_2c,uStack_28,uVar2);
  }
  FUN_00617bc0();
  FUN_00617bc0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20100 ; VA 0x00a221c0 ; FUN_00a221c0 */

void FUN_00a221c0(int param_1,undefined4 param_2,int param_3)

{
  undefined auStack_14 [12];
  int iStack_8;
  
  iStack_8 = param_3 >> 0x1f;
  FUN_005af630(param_2,param_3,iStack_8);
  if ((*(int *)(param_1 + 8) == param_3) && (*(int *)(param_1 + 0xc) == iStack_8)) {
    return;
  }
  FUN_016756b0(auStack_14,"Unexpected end of file while reading %d bytes",param_3);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_14,&DAT_01c17198);
}



/* FUNCTION 20101 ; VA 0x00a22220 ; FUN_00a22220 */

void FUN_00a22220(int *param_1,int *param_2,uint param_3)

{
  byte bVar1;
  int iVar2;
  uint *puVar3;
  int *piVar4;
  undefined *puVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined auStack_18 [12];
  int iStack_c;
  int iStack_8;
  
  uVar8 = param_3;
  piVar4 = param_2;
  param_2[1] = *param_2;
  if ((uint)(param_2[2] - *param_2 >> 2) < param_3) {
    if (0x3fffffff < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_007cfd20(param_3);
  }
  iStack_c = uVar8 * 4;
  iVar6 = param_1[1];
  if ((uint)(iVar6 + iStack_c) <= (uint)param_1[2]) {
    uVar7 = 0;
    if (uVar8 != 0) {
      iStack_8 = uVar8 * 3;
      do {
        iVar6 = param_1[1];
        iVar2 = *param_1;
        puVar5 = (undefined *)(iVar2 + iVar6 + uVar7);
        bVar1 = *(byte *)(iStack_8 + iVar2 + iVar6 + uVar7);
        puVar3 = (uint *)piVar4[1];
        param_2 = (int *)(CONCAT31(CONCAT21(CONCAT11(*puVar5,puVar5[uVar8]),
                                            *(undefined *)(iVar2 + param_3 * 2 + iVar6 + uVar7)),
                                   bVar1) >> 1 | (uint)((bVar1 & 1) != 0) << 0x1f);
        if ((uint *)piVar4[2] == puVar3) {
          FUN_007d74c0(puVar3,&param_2);
        }
        else {
          *puVar3 = (uint)param_2;
          piVar4[1] = (int)(puVar3 + 1);
        }
        uVar7 = uVar7 + 1;
        uVar8 = param_3;
      } while (uVar7 < param_3);
      iVar6 = param_1[1];
    }
    param_1[1] = iStack_c + iVar6;
    return;
  }
  FUN_016756b0(auStack_18,"readFloatVector offset is out of bounds while reading %d bytes",iStack_c)
  ;
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_18,&DAT_01c17198);
}



/* FUNCTION 20102 ; VA 0x00a22330 ; FUN_00a22330 */

void FUN_00a22330(int *param_1,int param_2)

{
  uint uVar1;
  char cVar2;
  int iVar3;
  undefined auStack_10 [12];
  
  uVar1 = param_1[1] + 1;
  if ((uint)param_1[2] < uVar1) {
    FUN_016756b0(auStack_10,"MemoryInputStream::read offset is out of bounds while reading %d bytes"
                 ,1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_10,&DAT_01c17198);
  }
  cVar2 = *(char *)(*param_1 + param_1[1]);
  param_1[1] = uVar1;
  iVar3 = (int)cVar2;
  if (iVar3 == param_2) {
    return;
  }
  FUN_016756b0(auStack_10,"Unexpected format %d (expected %d)",iVar3,param_2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 20103 ; VA 0x00a223a0 ; FUN_00a223a0 */

void FUN_00a223a0(undefined4 param_1,int *param_2,uint param_3)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  FUN_00a225c0(param_1,param_2,param_3);
  iVar4 = 0;
  uVar2 = 0;
  if (param_3 != 0) {
    iVar3 = *param_2;
    do {
      piVar1 = (int *)(iVar3 + uVar2 * 4);
      *piVar1 = *piVar1 + iVar4;
      iVar3 = *param_2;
      iVar4 = *(int *)(iVar3 + uVar2 * 4);
      uVar2 = uVar2 + 1;
    } while (uVar2 < param_3);
  }
  return;
}



/* FUNCTION 20104 ; VA 0x00a223e0 ; FUN_00a223e0 */

void FUN_00a223e0(int *param_1,int *param_2,uint param_3)

{
  byte bVar1;
  int iVar2;
  uint *puVar3;
  uint uVar4;
  uint3 uVar5;
  undefined *puVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  undefined auStack_24 [4];
  uint uStack_20;
  uint uStack_1c;
  int iStack_18;
  int iStack_14;
  int iStack_10;
  uint uStack_c;
  uint uStack_8;
  
  param_2[1] = *param_2;
  if ((uint)(param_2[2] - *param_2 >> 3) < param_3) {
    if (0x1fffffff < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_00a20300(param_3);
  }
  iStack_18 = param_3 * 8;
  iVar10 = param_1[1];
  if ((uint)(iVar10 + iStack_18) <= (uint)param_1[2]) {
    uStack_8 = 0;
    if (param_3 != 0) {
      iStack_10 = param_3 * 6;
      iStack_14 = param_3 * 7;
      do {
        iVar10 = param_1[1];
        iVar2 = *param_1;
        puVar6 = (undefined *)(uStack_8 + iVar2 + iVar10);
        bVar1 = puVar6[param_3];
        uStack_c = (uint)bVar1;
        uVar5 = CONCAT21(CONCAT11(*puVar6,bVar1),
                         *(undefined *)(iVar2 + param_3 * 2 + iVar10 + uStack_8));
        uVar7 = CONCAT31(uVar5,*(undefined *)(param_3 * 3 + iVar2 + iVar10 + uStack_8)) << 8;
        uVar8 = (uVar7 | *(byte *)(iVar2 + param_3 * 4 + iVar10 + uStack_8)) << 8;
        uVar9 = (uVar8 | *(byte *)(param_3 * 5 + iVar2 + iVar10 + uStack_8)) << 8;
        uVar4 = uVar9 >> 0x18;
        bVar1 = *(byte *)(iStack_14 + iVar2 + iVar10 + uStack_8);
        uStack_20 = (((uVar9 | *(byte *)(iStack_10 + iVar2 + iVar10 + uStack_8)) << 8 | (uint)bVar1)
                     >> 1 | uVar4 << 0x1f) ^ -(bVar1 & 1);
        uStack_1c = ((((((uint)uVar5 << 8) >> 0x18) << 8 | uVar7 >> 0x18) << 8 | uVar8 >> 0x18) << 8
                    | uVar4) >> 1 ^ -(uint)((bVar1 & 1) != 0);
        puVar3 = (uint *)param_2[1];
        if ((uint *)param_2[2] == puVar3) {
          FUN_006c6ad0(puVar3,&uStack_20);
        }
        else {
          *puVar3 = uStack_20;
          puVar3[1] = uStack_1c;
          param_2[1] = param_2[1] + 8;
        }
        uStack_8 = uStack_8 + 1;
      } while (uStack_8 < param_3);
      iVar10 = param_1[1];
    }
    param_1[1] = iStack_18 + iVar10;
    return;
  }
  FUN_016756b0(auStack_24,"readInt64Vector offset is out of bounds while reading %d bytes",iStack_18
              );
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_24,&DAT_01c17198);
}



/* FUNCTION 20105 ; VA 0x00a225c0 ; FUN_00a225c0 */

void FUN_00a225c0(int *param_1,int *param_2,uint param_3)

{
  byte bVar1;
  int iVar2;
  uint *puVar3;
  undefined *puVar4;
  int iVar5;
  uint uVar6;
  undefined auStack_1c [12];
  int iStack_10;
  uint uStack_c;
  int iStack_8;
  
  param_2[1] = *param_2;
  if ((uint)(param_2[2] - *param_2 >> 2) < param_3) {
    if (0x3fffffff < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_007cfd20(param_3);
  }
  iStack_10 = param_3 * 4;
  iVar5 = param_1[1];
  if ((uint)(iVar5 + iStack_10) <= (uint)param_1[2]) {
    uVar6 = 0;
    if (param_3 != 0) {
      iStack_8 = param_3 * 3;
      do {
        iVar5 = param_1[1];
        iVar2 = *param_1;
        puVar4 = (undefined *)(iVar2 + iVar5 + uVar6);
        bVar1 = *(byte *)(iStack_8 + iVar2 + iVar5 + uVar6);
        puVar3 = (uint *)param_2[1];
        uStack_c = CONCAT31(CONCAT21(CONCAT11(*puVar4,puVar4[param_3]),
                                     *(undefined *)(param_3 * 2 + iVar2 + iVar5 + uVar6)),bVar1) >>
                   1 ^ -(bVar1 & 1);
        if ((uint *)param_2[2] == puVar3) {
          FUN_0063d9b0(puVar3,&uStack_c);
        }
        else {
          *puVar3 = uStack_c;
          param_2[1] = param_2[1] + 4;
        }
        uVar6 = uVar6 + 1;
      } while (uVar6 < param_3);
      iVar5 = param_1[1];
    }
    param_1[1] = iStack_10 + iVar5;
    return;
  }
  FUN_016756b0(auStack_1c,"readIntVector offset is out of bounds while reading %d bytes",iStack_10);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 20106 ; VA 0x00a226d0 ; FUN_00a226d0 */

void FUN_00a226d0(int *param_1,undefined8 *param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined auStack_34 [12];
  undefined8 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 *puStack_18;
  undefined8 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dbf80;
  pvStack_10 = ExceptionList;
  uVar3 = param_1[1] + 4;
  if ((uint)param_1[2] < uVar3) {
    uVar4 = 4;
    ExceptionList = &pvStack_10;
LAB_00a227e3:
    FUN_016756b0(auStack_34,"MemoryInputStream::read offset is out of bounds while reading %d bytes"
                 ,uVar4);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_34,&DAT_01c17198);
  }
  uVar1 = *(uint *)(*param_1 + param_1[1]);
  ExceptionList = &pvStack_10;
  param_1[1] = uVar3;
  uStack_1c = 0;
  puStack_18 = (undefined8 *)0x0;
  puStack_14 = (undefined8 *)0x0;
  uStack_8 = 0;
  if (uVar1 != 0) {
    if (0x15555555 < uVar1) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_007fdba0(uVar1);
  }
  uVar3 = 0;
  if (uVar1 != 0) {
    do {
      iVar2 = param_1[1];
      if ((uint)param_1[2] < iVar2 + 0xcU) {
        uVar4 = 0xc;
        goto LAB_00a227e3;
      }
      uStack_28 = *(undefined8 *)(*param_1 + iVar2);
      uStack_20 = *(undefined4 *)(*param_1 + 8 + iVar2);
      param_1[1] = iVar2 + 0xcU;
      if (puStack_14 == puStack_18) {
        FUN_007fc130(puStack_18,&uStack_28);
      }
      else {
        *puStack_18 = uStack_28;
        *(undefined4 *)(puStack_18 + 1) = uStack_20;
        puStack_18 = (undefined8 *)((int)puStack_18 + 0xc);
      }
      uVar3 = uVar3 + 1;
    } while (uVar3 < uVar1);
  }
  FUN_00a92d50(&uStack_1c,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (param_2 != &uStack_28) {
    FUN_00602a00((undefined4)uStack_28,uStack_28._4_4_,uVar1);
  }
  FUN_00617ad0();
  FUN_00617ad0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20107 ; VA 0x00a22810 ; FUN_00a22810 */

void FUN_00a22810(int *param_1,int *param_2)

{
  uint uVar1;
  uint uVar2;
  char cVar3;
  uint uVar4;
  int iVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  undefined4 uVar12;
  int iStack_2c;
  undefined auStack_20 [16];
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  uVar4 = param_1[2];
  iVar5 = param_1[1];
  uVar1 = iVar5 + 1;
  if (uVar4 < uVar1) {
    uVar12 = 1;
  }
  else {
    cVar3 = *(char *)(*param_1 + iVar5);
    param_1[1] = uVar1;
    if (cVar3 == '\0') {
      iStack_2c = (uint)iStack_2c._1_3_ << 8;
      *param_2 = iStack_2c;
      param_2[1] = 0;
      param_2[2] = 0;
      param_2[3] = 0;
      param_2[4] = 0;
      param_2[5] = 0;
      return;
    }
    uVar2 = iVar5 + 5;
    if (uVar4 < uVar2) {
      uVar12 = 4;
    }
    else {
      fVar6 = *(float *)(*param_1 + uVar1);
      uVar1 = iVar5 + 9;
      param_1[1] = uVar2;
      if (uVar4 < uVar1) {
        uVar12 = 4;
      }
      else {
        fStack_c = *(float *)(*param_1 + uVar2);
        uVar2 = iVar5 + 0xd;
        param_1[1] = uVar1;
        if (uVar4 < uVar2) {
          uVar12 = 4;
        }
        else {
          fStack_8 = *(float *)(*param_1 + uVar1);
          uVar1 = iVar5 + 0x11;
          param_1[1] = uVar2;
          if (uVar4 < uVar1) {
            uVar12 = 4;
          }
          else {
            fStack_10 = *(float *)(*param_1 + uVar2);
            param_1[1] = uVar1;
            fVar10 = DAT_018ce320;
            if (iVar5 + 0x15U <= uVar4) {
              fVar9 = DAT_018daf54;
              if (DAT_018daf54 <= fVar6) {
                fVar9 = fVar6;
              }
              iStack_2c = CONCAT31(iStack_2c._1_3_,1);
              fVar6 = DAT_018ce320;
              if (fVar9 <= DAT_018ce320) {
                fVar6 = fVar9;
              }
              fVar9 = 0.0;
              if (0.0 <= fStack_8) {
                fVar9 = fStack_8;
              }
              fVar11 = 0.0;
              if (0.0 <= *(float *)(*param_1 + uVar1)) {
                fVar11 = *(float *)(*param_1 + uVar1);
              }
              fVar8 = DAT_018ce2f8;
              if (fVar9 <= DAT_018ce2f8) {
                fVar8 = fVar9;
              }
              param_1[1] = iVar5 + 0x15U;
              fVar9 = 0.0;
              if (0.0 <= fStack_c) {
                fVar9 = fStack_c;
              }
              fVar7 = DAT_018daf58;
              if (fVar9 <= DAT_018daf58) {
                fVar7 = fVar9;
              }
              fVar9 = fVar10;
              if (fVar11 <= fVar10) {
                fVar9 = fVar11;
              }
              fVar11 = 0.0;
              if (0.0 <= fStack_10) {
                fVar11 = fStack_10;
              }
              if (fVar11 <= fVar10) {
                fVar10 = fVar11;
              }
              *param_2 = iStack_2c;
              param_2[1] = (int)fVar6;
              param_2[2] = (int)fVar8;
              param_2[3] = (int)fVar7;
              *(ulonglong *)(param_2 + 4) = CONCAT44(fVar9,fVar10);
              return;
            }
            uVar12 = 4;
          }
        }
      }
    }
  }
  FUN_016756b0(auStack_20,"MemoryInputStream::read offset is out of bounds while reading %d bytes",
               uVar12);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_20,&DAT_01c17198);
}



/* FUNCTION 20108 ; VA 0x00a229a0 ; FUN_00a229a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00a229a0(int *param_1,int *param_2,int *param_3,int *param_4,int *param_5,byte param_6)

{
  uint uVar1;
  code *pcVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  uint uVar8;
  int iVar9;
  char *pcVar10;
  undefined8 uVar11;
  int *piVar12;
  undefined4 uVar13;
  int *piVar14;
  ulonglong *puVar15;
  ulonglong uStack_94;
  undefined4 uStack_8c;
  undefined8 uStack_88;
  uint uStack_80;
  undefined4 *puStack_7c;
  undefined4 uStack_78;
  int iStack_74;
  undefined4 *puStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  int aiStack_64 [3];
  undefined auStack_58 [12];
  int iStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 *puStack_40;
  undefined8 uStack_3c;
  undefined4 *puStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  int iStack_20;
  undefined4 *puStack_1c;
  char cStack_15;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar14 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dc104;
  pvStack_10 = ExceptionList;
  iVar5 = param_2[10];
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00886600();
  if (((iVar5 == iVar4) || (iVar5 = param_2[10], iVar4 = FUN_0088cb40(), iVar5 == iVar4)) ||
     (iVar5 = param_2[10], iVar4 = FUN_0088cf00(), iVar5 == iVar4)) {
    uVar8 = param_1[1] + 1;
    if ((uint)param_1[2] < uVar8) {
      FUN_016756b0(&iStack_4c,
                   "MemoryInputStream::read offset is out of bounds while reading %d bytes",1);
      goto LAB_00a24790;
    }
    cVar3 = *(char *)(*param_1 + param_1[1]);
    param_1[1] = uVar8;
    if (cVar3 == '\x01') {
      uStack_88 = uStack_88 & 0xffffffff;
      uStack_80 = 0xf;
      uStack_94 = uStack_94 & 0xffffffffffffff00;
      uVar8 = 0;
      uStack_8 = 0;
      if (param_3[1] - *param_3 >> 2 == 0) {
        ExceptionList = pvStack_10;
        return;
      }
      do {
        FUN_00a247f0();
        (**(code **)(*param_2 + 0x34))();
        uVar8 = uVar8 + 1;
      } while (uVar8 < (uint)(param_3[1] - *param_3 >> 2));
      if (uStack_80 < 0x10) {
        ExceptionList = pvStack_10;
        return;
      }
      if ((0xfff < uStack_80 + 1) && (0x1f < ((int)uStack_94 - *(int *)((int)uStack_94 + -4)) - 4U))
      {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      FUN_01674ea0();
      ExceptionList = pvStack_10;
      return;
    }
    if (cVar3 == '\x1c') {
      iStack_28 = 0;
      uStack_24 = 0;
      iStack_20 = 0;
      uStack_8 = 1;
      FUN_00a24920(param_1,&iStack_28,param_3[1] - *param_3 >> 2);
      param_2 = (int *)0x0;
      if (param_3[1] - *param_3 >> 2 != 0) {
        do {
          if ((uint)(param_5[1] - *param_5 >> 2) <= *(uint *)(iStack_28 + (int)param_2 * 4)) {
            if (DAT_01d65dac != '\0') {
              FUN_005d1bb0(param_2);
                    /* WARNING: Subroutine does not return */
              FUN_016757c0();
            }
            goto LAB_00a24770;
          }
          pcVar2 = *(code **)(*piVar14 + 0x34);
          FUN_00a33fa0();
          (*pcVar2)();
          param_2 = (int *)((int)param_2 + 1);
        } while (param_2 < (uint)(param_3[1] - *param_3 >> 2));
      }
      if (iStack_28 == 0) {
        ExceptionList = pvStack_10;
        return;
      }
      if ((0xfff < (iStack_20 - iStack_28 & 0xfffffffcU)) &&
         (0x1f < (iStack_28 - *(int *)(iStack_28 + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      FUN_01674ea0();
      ExceptionList = pvStack_10;
      return;
    }
    if ((((param_6 & 1) != 0) && (cVar3 == '\x1d')) &&
       (iVar5 = param_2[10], iVar4 = FUN_00886600(), iVar5 == iVar4)) {
      uStack_88 = (ulonglong)(uint)uStack_88;
      uStack_80 = 0xf;
      uStack_94 = uStack_94 & 0xffffffffffffff00;
      uStack_8 = 2;
      param_2 = (int *)0x0;
      if (param_3[1] - *param_3 >> 2 != 0) {
        do {
          puVar15 = &uStack_94;
          piVar12 = param_1;
          FUN_00a247f0();
          FUN_008869b0(&uStack_3c,&uStack_94,piVar12,puVar15);
          uStack_8._0_1_ = 3;
          (**(code **)(*(int *)piVar14[0xd] + 0x10))();
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          FUN_0056cd30();
          FUN_0056cd30();
          param_2 = (int *)((int)param_2 + 1);
        } while (param_2 < (uint)(param_3[1] - *param_3 >> 2));
      }
      goto LAB_00a22aaa;
    }
    uVar11 = CONCAT44(1,(int)cVar3);
    if (DAT_01d65dac != '\0') {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Unexpected format %d (expected %d or %d) while deserializing a string",
                   (int)cVar3,1,0x1c);
    }
    pcVar10 = "Unexpected format %d (expected %d or %d)";
  }
  else {
    iVar5 = param_2[10];
    if (*(int *)(iVar5 + 0x1c) != 0x3b) {
      iVar4 = FUN_0088daf0();
      if (iVar5 == iVar4) {
        FUN_00a22330();
        uVar8 = 0;
        if (param_3[1] - *param_3 >> 2 == 0) {
          ExceptionList = pvStack_10;
          return;
        }
        do {
          FUN_00a1da10();
          (**(code **)(*(int *)param_2[0xd] + 0x10))();
          uVar8 = uVar8 + 1;
        } while (uVar8 < (uint)(param_3[1] - *param_3 >> 2));
        ExceptionList = pvStack_10;
        return;
      }
      iVar5 = param_2[10];
      iVar4 = FUN_0088c8c0();
      if (iVar5 == iVar4) {
        FUN_00a1da10();
        if (param_2._3_1_ == '\x03') {
          iStack_28 = 0;
          uStack_24 = 0;
          iStack_20 = 0;
          uStack_8 = 7;
          FUN_00a225c0(param_1,&iStack_28,param_3[1] - *param_3 >> 2);
          uVar8 = 0;
          if (param_3[1] - *param_3 >> 2 != 0) {
            do {
              (**(code **)(*(int *)param_2[0xd] + 0x10))();
              uVar8 = uVar8 + 1;
            } while (uVar8 < (uint)(param_3[1] - *param_3 >> 2));
          }
LAB_00a22cae:
          FUN_0056d320();
          ExceptionList = pvStack_10;
          return;
        }
        if (param_2._3_1_ == '\x1b') {
          iStack_28 = 0;
          uStack_24 = 0;
          iStack_20 = 0;
          uStack_8 = 8;
          FUN_00a223e0(param_1,&iStack_28,param_3[1] - *param_3 >> 2);
          uVar8 = 0;
          if (param_3[1] - *param_3 >> 2 != 0) {
            do {
              (**(code **)(*(int *)param_2[0xd] + 0x10))();
              uVar8 = uVar8 + 1;
            } while (uVar8 < (uint)(param_3[1] - *param_3 >> 2));
          }
          FUN_0056d380();
          ExceptionList = pvStack_10;
          return;
        }
        uVar13 = 3;
      }
      else {
        iVar5 = param_2[10];
        iVar4 = FUN_0088da50();
        if (iVar5 != iVar4) {
          iVar5 = param_2[10];
          iVar4 = FUN_0088c960();
          if (iVar5 == iVar4) {
            uVar13 = 4;
            piVar14 = param_1;
            FUN_00a22330();
            iStack_28 = 0;
            uStack_24 = 0;
            iStack_20 = 0;
            uStack_8 = 0xb;
            FUN_00a22220(param_1,&iStack_28,param_3[1] - *param_3 >> 2,piVar14,uVar13);
            uVar8 = 0;
            if (param_3[1] - *param_3 >> 2 != 0) {
              do {
                (**(code **)(*(int *)param_2[0xd] + 0x10))();
                uVar8 = uVar8 + 1;
              } while (uVar8 < (uint)(param_3[1] - *param_3 >> 2));
            }
            FUN_0056d320();
            ExceptionList = pvStack_10;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088ca00();
          if (iVar5 == iVar4) {
            FUN_00a22330();
            param_2 = (int *)0x0;
            if (param_3[1] - *param_3 >> 2 == 0) {
              ExceptionList = pvStack_10;
              return;
            }
            while( true ) {
              uVar8 = param_1[1] + 8;
              if ((uint)param_1[2] < uVar8) break;
              uStack_3c = *(ulonglong *)(*param_1 + param_1[1]);
              param_1[1] = uVar8;
              (**(code **)(*(int *)piVar14[0xd] + 0x10))();
              param_2 = (int *)((int)param_2 + 1);
              if ((uint)(param_3[1] - *param_3 >> 2) <= param_2) {
                ExceptionList = pvStack_10;
                return;
              }
            }
            FUN_016756b0(&iStack_4c,
                         "MemoryInputStream::read offset is out of bounds while reading %d bytes",8)
            ;
            goto LAB_00a24790;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d690();
          if (iVar5 == iVar4) {
            uVar13 = 6;
            piVar14 = param_1;
            FUN_00a22330();
            puStack_7c = (undefined4 *)0x0;
            uStack_78 = 0;
            iStack_74 = 0;
            uStack_8 = 0xc;
            FUN_00a22220(param_1,&puStack_7c,param_3[1] - *param_3 >> 2,piVar14,uVar13);
            iStack_28 = 0;
            uStack_24 = 0;
            iStack_20 = 0;
            uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
            FUN_00a225c0(param_1,&iStack_28,param_3[1] - *param_3 >> 2);
            uStack_14 = 0;
            if (param_3[1] - *param_3 >> 2 != 0) {
              puStack_40 = (undefined4 *)(iStack_28 - (int)puStack_7c);
              puStack_1c = puStack_7c;
              do {
                uVar8 = uStack_14;
                uStack_3c = CONCAT44(*(undefined4 *)((int)puStack_40 + (int)puStack_1c),*puStack_1c)
                ;
                (**(code **)(*(int *)param_2[0xd] + 0x10))();
                uStack_14 = uVar8 + 1;
                puStack_1c = puStack_1c + 1;
              } while (uStack_14 < (uint)(param_3[1] - *param_3 >> 2));
            }
            FUN_0056d320();
            FUN_0056d320();
            ExceptionList = pvStack_10;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d5f0();
          if (iVar5 == iVar4) {
            uVar13 = 7;
            piVar14 = param_1;
            FUN_00a22330();
            iStack_4c = 0;
            uStack_48 = 0;
            uStack_44 = 0;
            puStack_34 = (undefined4 *)0x0;
            uStack_30 = 0;
            uStack_2c = 0;
            uStack_8._0_1_ = 0xf;
            uStack_8._1_3_ = 0;
            FUN_00a22220(param_1,&iStack_4c,param_3[1] - *param_3 >> 2,piVar14,uVar13);
            FUN_00a22220(param_1,&puStack_34,param_3[1] - *param_3 >> 2);
            aiStack_64[0] = 0;
            aiStack_64[1] = 0;
            aiStack_64[2] = 0;
            puStack_70 = (undefined4 *)0x0;
            uStack_6c = 0;
            uStack_68 = 0;
            uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
            FUN_00a225c0(param_1,aiStack_64,param_3[1] - *param_3 >> 2);
            FUN_00a225c0(param_1,&puStack_70,param_3[1] - *param_3 >> 2);
            uStack_14 = 0;
            if (param_3[1] - *param_3 >> 2 != 0) {
              puStack_1c = (undefined4 *)((int)puStack_34 - (int)puStack_70);
              iStack_74 = iStack_4c - (int)puStack_70;
              puStack_40 = (undefined4 *)(aiStack_64[0] - (int)puStack_70);
              puVar6 = puStack_70;
              do {
                uVar8 = uStack_14;
                uStack_24 = *(undefined4 *)((int)puStack_1c + (int)puVar6);
                uStack_80 = *puVar6;
                uStack_8c = *(undefined4 *)(iStack_74 + (int)puVar6);
                uStack_3c = CONCAT44(uStack_3c._4_4_,uStack_8c);
                uStack_88 = CONCAT44(uStack_24,*(undefined4 *)((int)puStack_40 + (int)puVar6));
                (**(code **)(*(int *)param_2[0xd] + 0x10))();
                puVar6 = puVar6 + 1;
                uStack_14 = uVar8 + 1;
              } while (uStack_14 < (uint)(param_3[1] - *param_3 >> 2));
            }
            FUN_0056d320();
            FUN_0056d320();
            FUN_0056d320();
            FUN_0056d320();
            ExceptionList = pvStack_10;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d370();
          if (iVar5 == iVar4) {
            FUN_00a22330();
            uVar8 = 0;
            if (param_3[1] - *param_3 >> 2 == 0) {
              ExceptionList = pvStack_10;
              return;
            }
            do {
              piVar14 = &iStack_4c;
              iStack_4c = 0;
              uStack_48 = 0;
              uStack_44 = 0;
              puStack_34 = (undefined4 *)0x0;
              uStack_30 = 0;
              uStack_2c = 0;
              piVar12 = param_1;
              FUN_00a1db00();
              FUN_00a1db00(param_1,&puStack_34,piVar12,piVar14);
              uStack_94 = CONCAT44(uStack_48,iStack_4c);
              uStack_8c = uStack_44;
              uStack_80 = uStack_2c;
              uStack_88 = CONCAT44(uStack_30,puStack_34);
              (**(code **)(*(int *)param_2[0xd] + 0x10))();
              uVar8 = uVar8 + 1;
            } while (uVar8 < (uint)(param_3[1] - *param_3 >> 2));
            ExceptionList = pvStack_10;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d230();
          if (iVar5 == iVar4) {
            FUN_00a22330();
            uVar8 = 0;
            if (param_3[1] - *param_3 >> 2 == 0) {
              ExceptionList = pvStack_10;
              return;
            }
            do {
              FUN_00a1da10();
              FUN_0054d840((int)param_2._3_1_);
              (**(code **)(*(int *)param_2[0xd] + 0x10))();
              uVar8 = uVar8 + 1;
            } while (uVar8 < (uint)(param_3[1] - *param_3 >> 2));
            ExceptionList = pvStack_10;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088ce60();
          if (iVar5 == iVar4) {
            FUN_00a22330();
            uVar8 = 0;
            if (param_3[1] - *param_3 >> 2 == 0) {
              ExceptionList = pvStack_10;
              return;
            }
            do {
              FUN_00a1da10();
              FUN_0054d840((int)param_2._3_1_);
              (**(code **)(*(int *)param_2[0xd] + 0x10))();
              uVar8 = uVar8 + 1;
            } while (uVar8 < (uint)(param_3[1] - *param_3 >> 2));
            ExceptionList = pvStack_10;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088cfa0();
          if (iVar5 == iVar4) {
            uVar13 = 0xb;
            piVar14 = param_1;
            FUN_00a22330();
            iStack_4c = 0;
            uStack_48 = 0;
            uStack_44 = 0;
            uStack_8 = 0x12;
            FUN_00a24920(param_1,&iStack_4c,param_3[1] - *param_3 >> 2,piVar14,uVar13);
            uVar8 = 0;
            if (param_3[1] - *param_3 >> 2 != 0) {
              do {
                FUN_00c95dd0(*(undefined4 *)(iStack_4c + uVar8 * 4));
                (**(code **)(*(int *)param_2[0xd] + 0x10))();
                uVar8 = uVar8 + 1;
              } while (uVar8 < (uint)(param_3[1] - *param_3 >> 2));
            }
            FUN_0056d320();
            ExceptionList = pvStack_10;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d050();
          if (iVar5 == iVar4) {
            uVar13 = 0xc;
            piVar14 = param_1;
            FUN_00a22330();
            aiStack_64[0] = 0;
            aiStack_64[1] = 0;
            aiStack_64[2] = 0;
            puStack_34 = (undefined4 *)0x0;
            uStack_30 = 0;
            uStack_2c = 0;
            iStack_4c = 0;
            uStack_48 = 0;
            uStack_44 = 0;
            uStack_8 = 0x15;
            FUN_00a22220(param_1,aiStack_64,param_3[1] - *param_3 >> 2,piVar14,uVar13);
            FUN_00a22220(param_1,&puStack_34,param_3[1] - *param_3 >> 2);
            FUN_00a22220(param_1,&iStack_4c,param_3[1] - *param_3 >> 2);
            uStack_14 = 0;
            if (param_3[1] - *param_3 >> 2 != 0) {
              iStack_74 = iStack_4c - (int)puStack_34;
              puStack_40 = (undefined4 *)(aiStack_64[0] - (int)puStack_34);
              puStack_1c = puStack_34;
              do {
                uVar8 = uStack_14;
                uStack_68 = *(undefined4 *)(iStack_74 + (int)puStack_1c);
                puStack_70 = *(undefined4 **)((int)puStack_40 + (int)puStack_1c);
                uStack_6c = *puStack_1c;
                (**(code **)(*(int *)param_2[0xd] + 0x10))();
                uStack_14 = uVar8 + 1;
                puStack_1c = puStack_1c + 1;
              } while (uStack_14 < (uint)(param_3[1] - *param_3 >> 2));
            }
LAB_00a23c45:
            FUN_0056d320();
            FUN_0056d320();
            FUN_0056d320();
            ExceptionList = pvStack_10;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d0f0();
          if (iVar5 == iVar4) {
            uVar13 = 0x1a;
            piVar14 = param_1;
            FUN_00a22330();
            aiStack_64[0] = 0;
            aiStack_64[1] = 0;
            aiStack_64[2] = 0;
            puStack_34 = (undefined4 *)0x0;
            uStack_30 = 0;
            uStack_2c = 0;
            iStack_4c = 0;
            uStack_48 = 0;
            uStack_44 = 0;
            uStack_8 = 0x18;
            FUN_00a24890(param_1,aiStack_64,param_3[1] - *param_3 >> 2,piVar14,uVar13);
            FUN_00a24890(param_1,&puStack_34,param_3[1] - *param_3 >> 2);
            FUN_00a24890(param_1,&iStack_4c,param_3[1] - *param_3 >> 2);
            uVar8 = 0;
            if (param_3[1] - *param_3 >> 2 != 0) {
              do {
                (**(code **)(*(int *)param_2[0xd] + 0x10))();
                uVar8 = uVar8 + 1;
              } while (uVar8 < (uint)(param_3[1] - *param_3 >> 2));
            }
            FUN_0056d2d0();
            FUN_0056d2d0();
            FUN_0056d2d0();
            ExceptionList = pvStack_10;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d410();
          if (iVar5 == iVar4) {
            uVar13 = 0x18;
            piVar14 = param_1;
            FUN_00a22330();
            puStack_70 = (undefined4 *)0x0;
            uStack_6c = 0;
            uStack_68 = 0;
            aiStack_64[0] = 0;
            aiStack_64[1] = 0;
            aiStack_64[2] = 0;
            puStack_34 = (undefined4 *)0x0;
            uStack_30 = 0;
            uStack_2c = 0;
            iStack_4c = 0;
            uStack_48 = 0;
            uStack_44 = 0;
            uStack_8 = 0x1c;
            FUN_00a22220(param_1,&puStack_70,param_3[1] - *param_3 >> 2,piVar14,uVar13);
            FUN_00a22220(param_1,aiStack_64,param_3[1] - *param_3 >> 2);
            FUN_00a22220(param_1,&puStack_34,param_3[1] - *param_3 >> 2);
            FUN_00a22220(param_1,&iStack_4c,param_3[1] - *param_3 >> 2);
            uStack_14 = 0;
            if (param_3[1] - *param_3 >> 2 != 0) {
              puStack_40 = (undefined4 *)(iStack_4c - (int)puStack_34);
              iStack_74 = (int)puStack_70 - (int)puStack_34;
              uStack_3c = CONCAT44(aiStack_64[0] - (int)puStack_34,(undefined4)uStack_3c);
              puStack_1c = puStack_34;
              iVar5 = aiStack_64[0] - (int)puStack_34;
              do {
                FUN_00712cc0(&uStack_8c,*(undefined4 *)(iStack_74 + (int)puStack_1c),
                             *(undefined4 *)(iVar5 + (int)puStack_1c),*puStack_1c,
                             *(undefined4 *)((int)puStack_40 + (int)puStack_1c));
                uVar8 = uStack_14;
                (**(code **)(*(int *)param_2[0xd] + 0x10))();
                uStack_14 = uVar8 + 1;
                puStack_1c = puStack_1c + 1;
                iVar5 = uStack_3c._4_4_;
              } while (uStack_14 < (uint)(param_3[1] - *param_3 >> 2));
            }
            FUN_0056d320();
            FUN_0056d320();
            FUN_0056d320();
            FUN_0056d320();
            ExceptionList = pvStack_10;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d2d0();
          if (iVar5 == iVar4) {
            FUN_00a22330();
            uVar8 = 0;
            if (param_3[1] - *param_3 >> 2 == 0) {
              ExceptionList = pvStack_10;
              return;
            }
            do {
              FUN_0060f260();
              FUN_00a22810();
              (**(code **)(*(int *)param_2[0xd] + 0x10))();
              uVar8 = uVar8 + 1;
            } while (uVar8 < (uint)(param_3[1] - *param_3 >> 2));
            ExceptionList = pvStack_10;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d730();
          if (iVar5 == iVar4) {
            uVar13 = 0xd;
            piVar14 = param_1;
            FUN_00a22330();
            puStack_34 = (undefined4 *)0x0;
            uStack_30 = 0;
            uStack_2c = 0;
            iStack_4c = 0;
            uStack_48 = 0;
            uStack_44 = 0;
            uStack_8 = 0x1e;
            FUN_00a22220(param_1,&puStack_34,param_3[1] - *param_3 >> 2,piVar14,uVar13);
            FUN_00a22220(param_1,&iStack_4c,param_3[1] - *param_3 >> 2);
            uStack_14 = 0;
            if (param_3[1] - *param_3 >> 2 != 0) {
              uStack_3c = CONCAT44(iStack_4c - (int)puStack_34,(undefined4)uStack_3c);
              iVar5 = iStack_4c - (int)puStack_34;
              puStack_1c = puStack_34;
              do {
                uVar8 = uStack_14;
                iStack_74 = *(int *)(iVar5 + (int)puStack_1c);
                uStack_78 = *puStack_1c;
                (**(code **)(*(int *)param_2[0xd] + 0x10))();
                uStack_14 = uVar8 + 1;
                puStack_1c = puStack_1c + 1;
                iVar5 = uStack_3c._4_4_;
              } while (uStack_14 < (uint)(param_3[1] - *param_3 >> 2));
            }
            FUN_0056d320();
            FUN_0056d320();
            ExceptionList = pvStack_10;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d870();
          if (iVar5 == iVar4) {
            uVar13 = 0xe;
            piVar14 = param_1;
            FUN_00a22330();
            aiStack_64[0] = 0;
            aiStack_64[1] = 0;
            aiStack_64[2] = 0;
            puStack_34 = (undefined4 *)0x0;
            uStack_30 = 0;
            uStack_2c = 0;
            iStack_4c = 0;
            uStack_48 = 0;
            uStack_44 = 0;
            uStack_8 = 0x21;
            FUN_00a22220(param_1,aiStack_64,param_3[1] - *param_3 >> 2,piVar14,uVar13);
            FUN_00a22220(param_1,&puStack_34,param_3[1] - *param_3 >> 2);
            FUN_00a22220(param_1,&iStack_4c,param_3[1] - *param_3 >> 2);
            uStack_14 = 0;
            if (param_3[1] - *param_3 >> 2 != 0) {
              iStack_74 = aiStack_64[0] - (int)puStack_34;
              uStack_3c = CONCAT44(iStack_4c - (int)puStack_34,(undefined4)uStack_3c);
              iVar5 = iStack_4c - (int)puStack_34;
              puStack_1c = puStack_34;
              do {
                uVar8 = uStack_14;
                uStack_68 = *(undefined4 *)(iVar5 + (int)puStack_1c);
                puStack_70 = *(undefined4 **)(iStack_74 + (int)puStack_1c);
                uStack_6c = *puStack_1c;
                (**(code **)(*(int *)param_2[0xd] + 0x10))();
                uStack_14 = uVar8 + 1;
                puStack_1c = puStack_1c + 1;
                iVar5 = uStack_3c._4_4_;
              } while (uStack_14 < (uint)(param_3[1] - *param_3 >> 2));
            }
            goto LAB_00a23c45;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d7d0();
          if (iVar5 == iVar4) {
            FUN_00a22330();
            uVar8 = 0;
            if (param_3[1] - *param_3 >> 2 == 0) {
              ExceptionList = pvStack_10;
              return;
            }
            do {
              FUN_00a22020();
              (**(code **)(*(int *)param_2[0xd] + 0x10))();
              uVar8 = uVar8 + 1;
            } while (uVar8 < (uint)(param_3[1] - *param_3 >> 2));
            ExceptionList = pvStack_10;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d910();
          if (iVar5 == iVar4) {
            FUN_00a22330();
            uVar8 = 0;
            if (param_3[1] - *param_3 >> 2 == 0) {
              ExceptionList = pvStack_10;
              return;
            }
            do {
              uStack_3c = uStack_3c & 0xffff000000000000;
              FUN_00a22020();
              (**(code **)(*(int *)param_2[0xd] + 0x10))();
              uVar8 = uVar8 + 1;
            } while (uVar8 < (uint)(param_3[1] - *param_3 >> 2));
            ExceptionList = pvStack_10;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_00b00260();
          if (iVar5 == iVar4) {
            iStack_28 = 0;
            uStack_24 = 0;
            iStack_20 = 0;
            aiStack_64[0] = 0;
            aiStack_64[1] = 0;
            aiStack_64[2] = 0;
            puStack_34 = (undefined4 *)0x0;
            uStack_30 = 0;
            uStack_2c = 0;
            iStack_4c = 0;
            uStack_48 = 0;
            uStack_44 = 0;
            uStack_8 = 0x25;
            FUN_00a1d5c0();
            FUN_00a1da10();
            if (cStack_15 == '\x10') {
              iVar5 = param_3[1];
              iVar4 = *param_3;
              uStack_14 = 0;
              if (iVar5 - iVar4 >> 2 != 0) {
                iVar9 = 0;
                do {
                  puStack_1c = (undefined4 *)(iStack_28 + iVar9);
                  FUN_00a1da10();
                  if (cStack_15 == '\0') {
                    FUN_00a22020();
                  }
                  else {
                    FUN_00c93e80();
                  }
                  iVar5 = param_3[1];
                  iVar9 = iVar9 + 0x24;
                  iVar4 = *param_3;
                  uStack_14 = uStack_14 + 1;
                } while (uStack_14 < (uint)(iVar5 - iVar4 >> 2));
              }
            }
            else {
              if (cStack_15 != '\x11') {
                FUN_016756b0(&puStack_70,"Unexpected cframe format %d",(int)cStack_15);
                goto LAB_00a24790;
              }
              iVar5 = param_3[1];
              iVar4 = *param_3;
              uStack_14 = 0;
              if (iVar5 - iVar4 >> 2 != 0) {
                iVar9 = 0;
                do {
                  puStack_1c = (undefined4 *)(iStack_28 + iVar9);
                  FUN_00a1da10();
                  if (cStack_15 == '\0') {
                    uStack_8c = _DAT_018f99a0;
                    uStack_88 = CONCAT44(_UNK_018f99a8,_UNK_018f99a4);
                    uStack_80 = _UNK_018f99ac;
                    FUN_00a22020();
                    FUN_00cf7180(puStack_1c);
                  }
                  else {
                    FUN_00c93e80();
                  }
                  iVar5 = param_3[1];
                  iVar9 = iVar9 + 0x24;
                  iVar4 = *param_3;
                  uStack_14 = uStack_14 + 1;
                } while (uStack_14 < (uint)(iVar5 - iVar4 >> 2));
              }
            }
            FUN_00a22220(param_1,aiStack_64,iVar5 - iVar4 >> 2);
            FUN_00a22220(param_1,&puStack_34,param_3[1] - *param_3 >> 2);
            FUN_00a22220(param_1,&iStack_4c,param_3[1] - *param_3 >> 2);
            puStack_1c = (undefined4 *)0x0;
            if (param_3[1] - *param_3 >> 2 != 0) {
              iStack_74 = aiStack_64[0] - (int)puStack_34;
              uStack_14 = 0;
              uStack_3c = CONCAT44(iStack_4c - (int)puStack_34,(undefined4)uStack_3c);
              puStack_40 = puStack_34;
              do {
                uStack_80 = *(undefined4 *)(uStack_3c._4_4_ + (int)puStack_40);
                uStack_94 = *(ulonglong *)(uStack_14 + iStack_28 + 0x18);
                uStack_8c = *(undefined4 *)(uStack_14 + 0x20 + iStack_28);
                uStack_88 = CONCAT44(*puStack_40,*(undefined4 *)(iStack_74 + (int)puStack_40));
                uStack_68 = uStack_80;
                (**(code **)(*(int *)param_2[0xd] + 0x10))();
                uStack_14 = uStack_14 + 0x24;
                puStack_1c = (undefined4 *)((int)puStack_1c + 1);
                puStack_40 = puStack_40 + 1;
              } while (puStack_1c < (uint)(param_3[1] - *param_3 >> 2));
            }
            FUN_0056d320();
            FUN_0056d320();
            FUN_0056d320();
            FUN_00860030();
            ExceptionList = pvStack_10;
            return;
          }
          if (*(char *)(param_2 + 0xb) != '\0') {
            uVar13 = 0x12;
            piVar14 = param_1;
            FUN_00a22330();
            iStack_4c = 0;
            uStack_48 = 0;
            uStack_44 = 0;
            uStack_8 = 0x26;
            FUN_00a24920(param_1,&iStack_4c,param_3[1] - *param_3 >> 2,piVar14,uVar13);
            uVar8 = 0;
            if (param_3[1] - *param_3 >> 2 != 0) {
              do {
                (**(code **)(*param_2 + 0x48))();
                uVar8 = uVar8 + 1;
              } while (uVar8 < (uint)(param_3[1] - *param_3 >> 2));
            }
            FUN_0056d320();
            ExceptionList = pvStack_10;
            return;
          }
          cVar3 = FUN_00620ff0(param_2);
          if (cVar3 != '\0') {
            uVar13 = 0x13;
            piVar14 = param_1;
            FUN_00a22330();
            iStack_28 = 0;
            uStack_24 = 0;
            iStack_20 = 0;
            uStack_8 = 0x27;
            FUN_00a223a0(param_1,&iStack_28,param_3[1] - *param_3 >> 2,piVar14,uVar13);
            uVar8 = 0;
            if (param_3[1] - *param_3 >> 2 != 0) {
              do {
                uVar1 = *(uint *)(iStack_28 + uVar8 * 4);
                if ((uVar1 != 0xffffffff) && ((uint)(param_4[1] - *param_4 >> 3) <= uVar1)) {
                  puVar6 = (undefined4 *)FUN_005d1bb0(uVar8);
                  if (DAT_01d65dac != '\0') {
                    /* WARNING: Subroutine does not return */
                    FUN_016757c0();
                  }
                  FUN_016756b0(&iStack_4c,"Invalid id %d",*puVar6);
                  goto LAB_00a24790;
                }
                (**(code **)(*param_2 + 0x48))();
                uVar8 = uVar8 + 1;
              } while (uVar8 < (uint)(param_3[1] - *param_3 >> 2));
            }
            goto LAB_00a22cae;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d190();
          if (iVar5 == iVar4) {
            FUN_00a22330();
            uStack_88 = (ulonglong)(uint)uStack_88;
            uStack_80 = 0xf;
            uStack_94 = uStack_94 & 0xffffffffffffff00;
            uVar8 = 0;
            uStack_8 = 0x28;
            if (param_3[1] - *param_3 >> 2 != 0) {
              do {
                FUN_00a247f0();
                FUN_0054ef60(&uStack_94);
                uStack_8._0_1_ = 0x29;
                FUN_009cbbb0(auStack_58);
                uStack_8._0_1_ = 0x2a;
                (**(code **)(*(int *)param_2[0xd] + 0x10))();
                uStack_8 = CONCAT31(uStack_8._1_3_,0x28);
                FUN_005507b0();
                uVar8 = uVar8 + 1;
              } while (uVar8 < (uint)(param_3[1] - *param_3 >> 2));
            }
            goto LAB_00a22aaa;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_00a92ae0();
          if (iVar5 == iVar4) {
            FUN_00a22330();
            FUN_00a92e30(0);
            uVar8 = 0;
            uStack_8 = 0x2b;
            if (param_3[1] - *param_3 >> 2 != 0) {
              do {
                FUN_00a226d0();
                (**(code **)(*(int *)param_2[0xd] + 0x10))();
                uVar8 = uVar8 + 1;
              } while (uVar8 < (uint)(param_3[1] - *param_3 >> 2));
            }
            FUN_00617ad0();
            ExceptionList = pvStack_10;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_00a8dcc0();
          if (iVar5 == iVar4) {
            FUN_00a22330();
            uStack_2c = 0x3f800000;
            FUN_00a8e2b0(CONCAT44(DAT_018ce2f8,DAT_018ce2f8),0x3f800000);
            uVar8 = 0;
            uStack_8 = 0x2c;
            if (param_3[1] - *param_3 >> 2 != 0) {
              do {
                FUN_00a22080();
                (**(code **)(*(int *)param_2[0xd] + 0x10))();
                uVar8 = uVar8 + 1;
              } while (uVar8 < (uint)(param_3[1] - *param_3 >> 2));
            }
            FUN_00617bc0();
            ExceptionList = pvStack_10;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_00b33310();
          if (iVar5 == iVar4) {
            FUN_00a22330();
            uVar8 = 0;
            uStack_3c = 0;
            if (param_3[1] - *param_3 >> 2 == 0) {
              ExceptionList = pvStack_10;
              return;
            }
            do {
              FUN_00a1dab0();
              (**(code **)(*(int *)param_2[0xd] + 0x10))();
              uVar8 = uVar8 + 1;
            } while (uVar8 < (uint)(param_3[1] - *param_3 >> 2));
            ExceptionList = pvStack_10;
            return;
          }
          uVar13 = FUN_005543f0();
          if (DAT_01d65dac != '\0') {
            uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
            FUN_016757c0("Unknown property type %s for property %s",uVar7,uVar13);
          }
          FUN_016756b0(&puStack_70,"Unknown property type for property %s",uVar13);
          goto LAB_00a24790;
        }
        FUN_00a1da10();
        if (cStack_15 == '\x03') {
          iStack_28 = 0;
          uStack_24 = 0;
          iStack_20 = 0;
          uStack_8 = 9;
          FUN_00a225c0(param_1,&iStack_28,param_3[1] - *param_3 >> 2);
          uVar8 = 0;
          if (param_3[1] - *param_3 >> 2 != 0) {
            do {
              uStack_3c = (ulonglong)*(int *)(iStack_28 + uVar8 * 4);
              (**(code **)(*(int *)param_2[0xd] + 0x10))();
              uVar8 = uVar8 + 1;
            } while (uVar8 < (uint)(param_3[1] - *param_3 >> 2));
          }
          FUN_0056d320();
          ExceptionList = pvStack_10;
          return;
        }
        if (cStack_15 == '\x1b') {
          iStack_28 = 0;
          uStack_24 = 0;
          iStack_20 = 0;
          uStack_8 = 10;
          FUN_00a223e0(param_1,&iStack_28,param_3[1] - *param_3 >> 2);
          puStack_1c = (undefined4 *)0x0;
          if (param_3[1] - *param_3 >> 2 != 0) {
            uStack_14 = iStack_28;
            do {
              puVar6 = puStack_1c;
              (**(code **)(*(int *)param_2[0xd] + 0x10))();
              puStack_1c = (undefined4 *)((int)puVar6 + 1);
              uStack_14 = uStack_14 + 8;
            } while (puStack_1c < (uint)(param_3[1] - *param_3 >> 2));
          }
          FUN_0056d380();
          ExceptionList = pvStack_10;
          return;
        }
        uVar13 = 0x1b;
        param_2._3_1_ = cStack_15;
      }
      FUN_016756b0(&iStack_4c,"Unexpected format %d (expected %d)",(int)param_2._3_1_,uVar13);
      goto LAB_00a24790;
    }
    FUN_00a1da10();
    if (cStack_15 == '\x01') {
      uStack_88 = uStack_88 & 0xffffffff;
      uStack_80 = 0xf;
      uStack_94 = uStack_94 & 0xffffffffffffff00;
      uStack_8 = 4;
      param_2 = (int *)0x0;
      if (param_3[1] - *param_3 >> 2 != 0) {
        do {
          FUN_00a247f0();
          FUN_00a33be0(&uStack_94);
          uStack_8._0_1_ = 5;
          (**(code **)(*(int *)piVar14[0xd] + 0x10))();
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          FUN_0056cd30();
          param_2 = (int *)((int)param_2 + 1);
        } while (param_2 < (uint)(param_3[1] - *param_3 >> 2));
      }
LAB_00a22aaa:
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return;
    }
    if (cStack_15 == '\x1c') {
      iStack_28 = 0;
      uStack_24 = 0;
      iStack_20 = 0;
      uStack_8 = 6;
      FUN_00a24920(param_1,&iStack_28,param_3[1] - *param_3 >> 2);
      uVar8 = 0;
      if (param_3[1] - *param_3 >> 2 != 0) {
        do {
          puStack_40 = *(undefined4 **)(iStack_28 + uVar8 * 4);
          if ((undefined4 *)(param_5[1] - *param_5 >> 2) <= puStack_40) {
            if (DAT_01d65dac != '\0') {
              FUN_005d1bb0(uVar8);
                    /* WARNING: Subroutine does not return */
              FUN_016757c0();
            }
LAB_00a24770:
                    /* WARNING: Subroutine does not return */
            FUN_016757c0("SharedString dictionary index invalid");
          }
          (**(code **)(*(int *)param_2[0xd] + 0x10))();
          uVar8 = uVar8 + 1;
        } while (uVar8 < (uint)(param_3[1] - *param_3 >> 2));
      }
      FUN_0056d320();
      ExceptionList = pvStack_10;
      return;
    }
    uVar11 = CONCAT44(1,(int)cStack_15);
    if (DAT_01d65dac == '\0') {
      pcVar10 = "Unexpected format %d (expected %d or %d)";
    }
    else {
      pcVar10 = "Unexpected format %d (expected %d or %d) while deserializing a shared string";
    }
  }
  FUN_016756b0(&iStack_4c,pcVar10,uVar11,0x1c);
LAB_00a24790:
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8();
}



/* FUNCTION 20109 ; VA 0x00a247f0 ; FUN_00a247f0 */

void FUN_00a247f0(int *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  uint uVar3;
  undefined auStack_10 [12];
  
  uVar1 = param_1[1] + 4;
  if (uVar1 <= (uint)param_1[2]) {
    uVar3 = *(uint *)(*param_1 + param_1[1]);
    param_1[1] = uVar1;
    if ((uint)param_2[4] < uVar3) {
      FUN_00578160(uVar3 - param_2[4],0);
    }
    else {
      puVar2 = param_2;
      if (0xf < (uint)param_2[5]) {
        puVar2 = (undefined4 *)*param_2;
      }
      param_2[4] = uVar3;
      *(undefined *)((int)puVar2 + uVar3) = 0;
    }
    if (uVar3 != 0) {
      if (0xf < (uint)param_2[5]) {
        param_2 = (undefined4 *)*param_2;
      }
      if ((uint)param_1[2] < param_1[1] + uVar3) goto LAB_00a2486c;
      FUN_0170c6f0(param_2,*param_1 + param_1[1]);
      param_1[1] = param_1[1] + uVar3;
    }
    return;
  }
  uVar3 = 4;
LAB_00a2486c:
  FUN_016756b0(auStack_10,"MemoryInputStream::read offset is out of bounds while reading %d bytes",
               uVar3);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 20110 ; VA 0x00a24890 ; FUN_00a24890 */

void FUN_00a24890(int *param_1,undefined4 *param_2,int param_3)

{
  undefined auStack_10 [12];
  
  param_2[1] = *param_2;
  if ((uint)param_1[2] < (uint)(param_1[1] + param_3)) {
    FUN_016756b0(auStack_10,"readUInt8Vector offset is out of bounds while reading %d bytes",param_3
                );
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_10,&DAT_01c17198);
  }
  FUN_0055b6c0(param_3,param_2);
  if ((uint)(param_1[1] + param_3) <= (uint)param_1[2]) {
    FUN_0170c6f0(*param_2,*param_1 + param_1[1]);
    param_1[1] = param_1[1] + param_3;
    return;
  }
  FUN_016756b0(auStack_10,"MemoryInputStream::read offset is out of bounds while reading %d bytes",
               param_3);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 20111 ; VA 0x00a24920 ; FUN_00a24920 */

void FUN_00a24920(int *param_1,int *param_2,uint param_3)

{
  int iVar1;
  undefined4 *puVar2;
  undefined *puVar3;
  int iVar4;
  uint uVar5;
  undefined auStack_1c [12];
  int iStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  param_2[1] = *param_2;
  if ((uint)(param_2[2] - *param_2 >> 2) < param_3) {
    if (0x3fffffff < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_007cfd20(param_3);
  }
  iStack_10 = param_3 * 4;
  iVar4 = param_1[1];
  if ((uint)(iVar4 + iStack_10) <= (uint)param_1[2]) {
    uVar5 = 0;
    if (param_3 != 0) {
      iStack_8 = param_3 * 3;
      do {
        iVar4 = param_1[1];
        iVar1 = *param_1;
        puVar3 = (undefined *)(iVar1 + iVar4 + uVar5);
        uStack_c = CONCAT31(CONCAT21(CONCAT11(*puVar3,puVar3[param_3]),
                                     *(undefined *)(param_3 * 2 + iVar1 + iVar4 + uVar5)),
                            *(undefined *)(iStack_8 + iVar1 + iVar4 + uVar5));
        puVar2 = (undefined4 *)param_2[1];
        if ((undefined4 *)param_2[2] == puVar2) {
          FUN_0063d9b0(puVar2,&uStack_c);
        }
        else {
          *puVar2 = uStack_c;
          param_2[1] = param_2[1] + 4;
        }
        uVar5 = uVar5 + 1;
      } while (uVar5 < param_3);
      iVar4 = param_1[1];
    }
    param_1[1] = iStack_10 + iVar4;
    return;
  }
  FUN_016756b0(auStack_1c,"readUIntVector offset is out of bounds while reading %d bytes",iStack_10)
  ;
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 20112 ; VA 0x00a24a20 ; FUN_00a24a20 */

void __thiscall FUN_00a24a20(int *param_1,uint param_2)

{
  if (param_2 <= (uint)(param_1[2] - *param_1)) {
    return;
  }
  if (param_2 < 0x80000000) {
    FUN_0072e000();
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 20113 ; VA 0x00a24a50 ; FUN_00a24a50 */

void __thiscall FUN_00a24a50(int *param_1,uint param_2)

{
  if (param_2 <= (uint)(param_1[2] - *param_1 >> 3)) {
    return;
  }
  if (param_2 < 0x20000000) {
    FUN_00a20300();
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 20114 ; VA 0x00a24a80 ; FUN_00a24a80 */

void FUN_00a24a80(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_00a1eb50(param_1,0,param_2,0,param_3,0,param_4);
  return;
}



/* FUNCTION 20115 ; VA 0x00a24aa0 ; FUN_00a24aa0 */

void FUN_00a24aa0(undefined4 param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dc118;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  puVar1 = &uStack_1c;
  if (*(undefined4 **)(param_2 + 0x2c) != (undefined4 *)0x0) {
    puVar1 = *(undefined4 **)(param_2 + 0x2c);
  }
  ExceptionList = &pvStack_10;
  FUN_00a1eb50(param_1,param_2,puVar1,0,param_3,0,param_4);
  thunk_FUN_00577ac0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20116 ; VA 0x00a24b20 ; FUN_00a24b20 */

void FUN_00a24b20(undefined4 param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar1 = param_2;
  puStack_c = &LAB_017dc118;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  puVar2 = &uStack_1c;
  if (*(undefined4 **)(param_2 + 0x2c) != (undefined4 *)0x0) {
    puVar2 = *(undefined4 **)(param_2 + 0x2c);
  }
  param_2 = param_1;
  ExceptionList = &pvStack_10;
  FUN_00a1db60(&param_2,iVar1,puVar2,0,param_3,0,param_4);
  thunk_FUN_00577ac0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20117 ; VA 0x00a24ba0 ; FUN_00a24ba0 */

void FUN_00a24ba0(int *param_1,int *param_2,int param_3,int *param_4,uint param_5,int *param_6)

{
  char cVar1;
  undefined4 ****ppppuVar2;
  int iVar3;
  uint *puVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  int iVar9;
  uint uVar10;
  undefined4 *puVar11;
  uint uVar12;
  undefined4 *puVar13;
  int iVar14;
  undefined4 *puStack_18;
  undefined4 ***pppuStack_14;
  undefined4 ***pppuStack_10;
  uint uStack_c;
  undefined uStack_5;
  
  uStack_c = 0;
  iVar14 = *param_1;
  if (param_1[1] - iVar14 >> 3 != 0) {
    do {
      pppuStack_10 = *(undefined4 ****)(iVar14 + uStack_c * 8);
      if ((DAT_01d65da4 != '\0') && (param_6 != (int *)0x0)) {
        iVar14 = *param_6;
        if ((iVar14 != param_6[1]) && ((undefined4 ****)pppuStack_10 != (undefined4 ****)param_6[4])
           ) {
          uVar5 = ((uint)pppuStack_10 >> 3) + (int)pppuStack_10;
          uVar12 = (param_6[1] - iVar14 >> 2) - 1;
          uVar10 = 0;
          do {
            uVar5 = uVar5 & uVar12;
            ppppuVar2 = *(undefined4 *****)(iVar14 + uVar5 * 4);
            if (ppppuVar2 == (undefined4 ****)pppuStack_10) goto LAB_00a24dd5;
            if (ppppuVar2 == (undefined4 ****)param_6[4]) break;
            uVar5 = uVar5 + 1 + uVar10;
            uVar10 = uVar10 + 1;
          } while (uVar10 <= uVar12);
        }
      }
      if (((undefined4 ****)pppuStack_10 != (undefined4 ****)0x0) &&
         (((*(char *)((int)pppuStack_10 + 0x21) != '\0' || ((param_5 & 8) != 0)) &&
          (((uint)((undefined4 ****)pppuStack_10)[3][0x75] >> 2 & 1) != 0)))) {
        puVar13 = (undefined4 *)*param_4;
        puVar7 = (undefined4 *)puVar13[1];
        cVar1 = *(char *)((int)puVar7 + 0xd);
        puVar6 = puVar13;
        puVar8 = puVar7;
        while (cVar1 == '\0') {
          if ((undefined4 ****)puVar8[4] < pppuStack_10) {
            puVar11 = (undefined4 *)puVar8[2];
            puVar8 = puVar6;
          }
          else {
            if ((*(char *)((int)puVar13 + 0xd) != '\0') &&
               (pppuStack_10 < (undefined4 ****)puVar8[4])) {
              puVar13 = puVar8;
            }
            puVar11 = (undefined4 *)*puVar8;
          }
          puVar6 = puVar8;
          puVar8 = puVar11;
          cVar1 = *(char *)((int)puVar11 + 0xd);
        }
        if (*(char *)((int)puVar13 + 0xd) == '\0') {
          puVar7 = (undefined4 *)*puVar13;
        }
        cVar1 = *(char *)((int)puVar7 + 0xd);
        while (cVar1 == '\0') {
          if (pppuStack_10 < (undefined4 ****)puVar7[4]) {
            puVar8 = (undefined4 *)*puVar7;
            puVar13 = puVar7;
          }
          else {
            puVar8 = (undefined4 *)puVar7[2];
          }
          puVar7 = puVar8;
          cVar1 = *(char *)((int)puVar8 + 0xd);
        }
        iVar14 = 0;
        if (puVar6 != puVar13) {
          do {
            puVar7 = (undefined4 *)puVar6[2];
            iVar14 = iVar14 + 1;
            if (*(char *)((int)puVar7 + 0xd) == '\0') {
              cVar1 = *(char *)((int)*puVar7 + 0xd);
              puVar6 = puVar7;
              puVar7 = (undefined4 *)*puVar7;
              while (cVar1 == '\0') {
                cVar1 = *(char *)((int)*puVar7 + 0xd);
                puVar6 = puVar7;
                puVar7 = (undefined4 *)*puVar7;
              }
            }
            else {
              cVar1 = *(char *)((int)puVar6[1] + 0xd);
              puVar8 = (undefined4 *)puVar6[1];
              puVar7 = puVar6;
              while ((puVar6 = puVar8, cVar1 == '\0' && (puVar7 == (undefined4 *)puVar6[2]))) {
                cVar1 = *(char *)((int)puVar6[1] + 0xd);
                puVar8 = (undefined4 *)puVar6[1];
                puVar7 = puVar6;
              }
            }
          } while (puVar6 != puVar13);
          if (iVar14 != 0) goto LAB_00a24dd5;
        }
        puVar13 = (undefined4 *)*param_4;
        iVar14 = param_2[1];
        iVar3 = *param_2;
        puVar7 = (undefined4 *)puVar13[1];
        puVar6 = puVar13;
        if (*(char *)((int)puVar13[1] + 0xd) == '\0') {
          do {
            if ((undefined4 ****)puVar7[4] < pppuStack_10) {
              puVar8 = (undefined4 *)puVar7[2];
            }
            else {
              puVar8 = (undefined4 *)*puVar7;
              puVar6 = puVar7;
            }
            puVar7 = puVar8;
          } while (*(char *)((int)puVar8 + 0xd) == '\0');
          if ((puVar6 == puVar13) ||
             (pppuStack_14 = pppuStack_10, pppuStack_10 < (undefined4 ****)puVar6[4]))
          goto LAB_00a24d36;
        }
        else {
LAB_00a24d36:
          pppuStack_14 = &pppuStack_10;
          iVar9 = FUN_005f81a0(&DAT_018bdeda,&pppuStack_14,&uStack_5);
          FUN_00687600(&puStack_18,puVar6,iVar9 + 0x10,iVar9);
          puVar6 = puStack_18;
        }
        puVar6[5] = iVar14 - iVar3 >> 2;
        puVar4 = (uint *)param_2[1];
        if ((uint *)param_2[2] == puVar4) {
          FUN_006030d0(puVar4,&pppuStack_10);
        }
        else {
          *puVar4 = (uint)pppuStack_10;
          param_2[1] = param_2[1] + 4;
        }
        if ((undefined4 ***)pppuStack_10[0xb] != (undefined4 ***)0x0) {
          FUN_00a24ba0(pppuStack_10[0xb],param_2,param_3,param_4,param_5,param_6);
        }
        puVar4 = *(uint **)(param_3 + 4);
        if (*(uint **)(param_3 + 8) == puVar4) {
          FUN_006030d0(puVar4,&pppuStack_10);
        }
        else {
          *puVar4 = (uint)pppuStack_10;
          *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 4;
        }
      }
LAB_00a24dd5:
      uStack_c = uStack_c + 1;
      iVar14 = *param_1;
    } while (uStack_c < (uint)(param_1[1] - iVar14 >> 3));
  }
  return;
}



/* FUNCTION 20118 ; VA 0x00a24e00 ; FUN_00a24e00 */

void FUN_00a24e00(int *param_1,int *param_2)

{
  undefined4 uVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  int iStack_20;
  int iStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  undefined4 *puStack_10;
  uint uStack_c;
  undefined uStack_5;
  
  uStack_c = 0;
  iVar4 = *param_1;
  if (param_1[1] - iVar4 >> 2 != 0) {
    do {
      iStack_20 = *(int *)(iVar4 + uStack_c * 4);
      uVar1 = *(undefined4 *)(iStack_20 + 0xc);
      puStack_10 = (undefined4 *)*param_2;
      cVar3 = *(char *)((int)puStack_10[1] + 0xd);
      iStack_1c = iStack_20;
      uStack_14 = uVar1;
      puVar6 = puStack_10;
      puVar5 = (undefined4 *)puStack_10[1];
      while (cVar3 == '\0') {
        cVar3 = FUN_00a20020(puVar5[4],uVar1);
        if (cVar3 == '\0') {
          puVar7 = (undefined4 *)*puVar5;
        }
        else {
          puVar7 = (undefined4 *)puVar5[2];
          puVar5 = puVar6;
        }
        puVar6 = puVar5;
        puVar5 = puVar7;
        cVar3 = *(char *)((int)puVar7 + 0xd);
      }
      if ((puVar6 == puStack_10) || (cVar3 = FUN_00a20020(uVar1,puVar6[4]), cVar3 != '\0')) {
        puStack_10 = &uStack_14;
        iVar4 = FUN_00995790(&DAT_018bdeda,&puStack_10,&uStack_5);
        FUN_00a1c0f0(&puStack_18,puVar6,iVar4 + 0x10,iVar4);
        puVar6 = puStack_18;
      }
      piVar2 = (int *)puVar6[6];
      if ((int *)puVar6[7] == piVar2) {
        FUN_006030d0(piVar2,&iStack_20);
      }
      else {
        *piVar2 = iStack_1c;
        puVar6[6] = puVar6[6] + 4;
      }
      uStack_c = uStack_c + 1;
      iVar4 = *param_1;
    } while (uStack_c < (uint)(param_1[1] - iVar4 >> 2));
  }
  return;
}



/* FUNCTION 20119 ; VA 0x00a24ef0 ; FUN_00a24ef0 */

void FUN_00a24ef0(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  int *piVar4;
  
  piVar1 = *(int **)(param_1 + 0x1c);
  for (piVar4 = *(int **)(param_1 + 0x18); piVar4 != piVar1; piVar4 = piVar4 + 1) {
    cVar3 = (**(code **)(*(int *)*piVar4 + 8))();
    if ((cVar3 == '\0') && ((*(uint *)(*piVar4 + 0x24) >> 4 & 1) != 0)) {
      piVar2 = (int *)param_2[1];
      if ((int *)param_2[2] == piVar2) {
        FUN_006030d0(piVar2,piVar4);
      }
      else {
        *piVar2 = *piVar4;
        param_2[1] = param_2[1] + 4;
      }
    }
  }
  FUN_00a1d6a0(*param_2,param_2[1],param_2[1] - *param_2 >> 2,param_1);
  return;
}



/* FUNCTION 20120 ; VA 0x00a24f60 ; FUN_00a24f60 */

void FUN_00a24f60(int *param_1,int param_2)

{
  char cVar1;
  undefined4 *puVar2;
  int *piVar3;
  int *piVar4;
  undefined4 *puVar5;
  int *piVar6;
  undefined auStack_28 [8];
  int *piStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9c38;
  pvStack_10 = ExceptionList;
  piVar4 = (int *)*param_1;
  param_1 = (int *)*piVar4;
  ExceptionList = &pvStack_10;
  piStack_20 = piVar4;
  if (param_1 != piVar4) {
    do {
      piVar6 = *(int **)(param_1[4] + 0x18);
      piVar3 = *(int **)(param_1[4] + 0x1c);
      piStack_1c = piVar3;
      if (piVar6 != piVar3) {
        do {
          if (*(int *)(*(int *)(*piVar6 + 0x28) + 0x1c) == 0x3b) {
            puVar2 = (undefined4 *)param_1[6];
            for (puVar5 = (undefined4 *)param_1[5]; puVar5 != puVar2; puVar5 = puVar5 + 1) {
              uStack_18 = *(undefined4 *)(param_2 + 8);
              (**(code **)(**(int **)(*piVar6 + 0x34) + 0xc))(auStack_14,*puVar5);
              uStack_8 = 0;
              FUN_00a1d820(auStack_28,auStack_14,auStack_14,&uStack_18);
              uStack_8 = 0xffffffff;
              FUN_0056cd30();
              piVar3 = piStack_1c;
            }
          }
          piVar6 = piVar6 + 1;
          piVar4 = piStack_20;
        } while (piVar6 != piVar3);
      }
      piVar6 = (int *)param_1[2];
      if (*(char *)((int)piVar6 + 0xd) == '\0') {
        cVar1 = *(char *)(*piVar6 + 0xd);
        param_1 = piVar6;
        piVar6 = (int *)*piVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*piVar6 + 0xd);
          param_1 = piVar6;
          piVar6 = (int *)*piVar6;
        }
      }
      else {
        cVar1 = *(char *)(param_1[1] + 0xd);
        piVar3 = (int *)param_1[1];
        piVar6 = param_1;
        while ((param_1 = piVar3, cVar1 == '\0' && (piVar6 == (int *)param_1[2]))) {
          cVar1 = *(char *)(param_1[1] + 0xd);
          piVar3 = (int *)param_1[1];
          piVar6 = param_1;
        }
      }
    } while (param_1 != piVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20121 ; VA 0x00a25080 ; FUN_00a25080 */

undefined4 * __thiscall FUN_00a25080(int *param_1,undefined4 *param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dc140;
  pvStack_10 = ExceptionList;
  iVar3 = *param_1;
  piVar1 = *(int **)(*(int *)(iVar3 + 4) + 0x38 + (int)param_1);
  ExceptionList = &pvStack_10;
  if (piVar1 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*piVar1 + 4))();
    iVar3 = *param_1;
  }
  uStack_8 = 0;
  if (((*(int *)(*(int *)(iVar3 + 4) + 0xc + (int)param_1) == 0) &&
      (piVar1 = *(int **)(*(int *)(iVar3 + 4) + 0x3c + (int)param_1), piVar1 != (int *)0x0)) &&
     (piVar1 != param_1)) {
    FUN_00581480();
    iVar3 = *param_1;
  }
  uStack_8 = 1;
  if ((*(uint *)(*(int *)(iVar3 + 4) + 0xc + (int)param_1) & 6) == 0) {
    (**(code **)(**(int **)(*(int *)(iVar3 + 4) + 0x38 + (int)param_1) + 0x28))(param_2,0,0,1,2);
    uStack_8 = 2;
    cVar2 = thunk_FUN_0170e3b7();
    if (cVar2 == '\0') {
      FUN_00577770();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
  }
  else {
    *param_2 = 0xffffffff;
    param_2[1] = 0xffffffff;
    param_2[2] = 0;
    param_2[3] = 0;
    *(undefined8 *)(param_2 + 4) = 0;
    uStack_8 = 4;
    cVar2 = thunk_FUN_0170e3b7();
    if (cVar2 == '\0') {
      FUN_00577770();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
  }
  piVar1 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 8))();
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20122 ; VA 0x00a25190 ; FUN_00a25190 */

void __thiscall FUN_00a25190(int *param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  
  uVar2 = param_1[1] + param_3;
  if ((uint)param_1[2] < uVar2) {
    uVar4 = 0x10;
    if (0x10 < uVar2) {
      do {
        uVar4 = uVar4 * 2;
      } while (uVar4 < uVar2);
    }
    iVar3 = FUN_01674e20(uVar4);
    FUN_0170c6f0(iVar3,*param_1,param_1[1]);
    iVar1 = *param_1;
    *param_1 = iVar3;
    param_1[2] = uVar4;
    FUN_01674ea0(iVar1);
  }
  FUN_0170c6f0(*param_1 + param_1[1],param_2,param_3);
  param_1[1] = param_1[1] + param_3;
  return;
}



/* FUNCTION 20123 ; VA 0x00a25200 ; FUN_00a25200 */

void FUN_00a25200(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  piVar1 = param_2;
  param_2 = (int *)((param_2[1] - *param_2) / 0x14);
  FUN_00a25190(&param_2,4);
  if (param_2 != (int *)0x0) {
    iVar2 = 0;
    iVar3 = (int)param_2;
    do {
      FUN_00a25190(*piVar1 + iVar2,0x14);
      iVar2 = iVar2 + 0x14;
      iVar3 = iVar3 + -1;
    } while (iVar3 != 0);
  }
  return;
}



/* FUNCTION 20124 ; VA 0x00a25260 ; FUN_00a25260 */

void FUN_00a25260(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  piVar1 = param_2;
  uVar4 = 0;
  iVar2 = param_2[1];
  iVar3 = *param_2;
  if (iVar2 - iVar3 >> 2 != 0) {
    do {
      iVar2 = *(int *)(*piVar1 + uVar4 * 4);
      param_2._0_3_ = (undefined3)iVar2;
      param_2 = (int *)CONCAT13((char)((uint)(iVar2 << 1) >> 0x18),param_2._0_3_);
      FUN_00a25190((int)&param_2 + 3,1);
      iVar2 = piVar1[1];
      uVar4 = uVar4 + 1;
      iVar3 = *piVar1;
    } while (uVar4 < (uint)(iVar2 - iVar3 >> 2));
  }
  uVar4 = 0;
  if (iVar2 - iVar3 >> 2 != 0) {
    do {
      iVar2 = *(int *)(*piVar1 + uVar4 * 4);
      param_2._0_3_ = (undefined3)iVar2;
      param_2 = (int *)CONCAT13((char)((uint)(iVar2 << 1) >> 0x10),param_2._0_3_);
      FUN_00a25190((int)&param_2 + 3,1);
      iVar2 = piVar1[1];
      uVar4 = uVar4 + 1;
      iVar3 = *piVar1;
    } while (uVar4 < (uint)(iVar2 - iVar3 >> 2));
  }
  uVar4 = 0;
  if (iVar2 - iVar3 >> 2 != 0) {
    do {
      iVar2 = *(int *)(*piVar1 + uVar4 * 4);
      param_2._0_3_ = (undefined3)iVar2;
      param_2 = (int *)CONCAT13((char)((uint)(iVar2 << 1) >> 8),param_2._0_3_);
      FUN_00a25190((int)&param_2 + 3,1);
      iVar2 = piVar1[1];
      uVar4 = uVar4 + 1;
      iVar3 = *piVar1;
    } while (uVar4 < (uint)(iVar2 - iVar3 >> 2));
  }
  uVar4 = 0;
  if (iVar2 - iVar3 >> 2 != 0) {
    do {
      iVar2 = *(int *)(*piVar1 + uVar4 * 4);
      param_2._0_3_ = (undefined3)iVar2;
      param_2 = (int *)CONCAT13((byte)(iVar2 << 1) | iVar2 < 0,param_2._0_3_);
      FUN_00a25190((int)&param_2 + 3,1);
      uVar4 = uVar4 + 1;
    } while (uVar4 < (uint)(piVar1[1] - *piVar1 >> 2));
  }
  return;
}



/* FUNCTION 20125 ; VA 0x00a25380 ; FUN_00a25380 */

void FUN_00a25380(undefined4 param_1,int *param_2)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int iStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_2;
  puStack_c = &LAB_017dc158;
  pvStack_10 = ExceptionList;
  iStack_1c = 0;
  piStack_18 = (int *)0x0;
  piStack_14 = (int *)0x0;
  uStack_8 = 0;
  iVar4 = param_2[1];
  iVar3 = *param_2;
  uVar2 = iVar4 - iVar3 >> 2;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    if (0x3fffffff < uVar2) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    ExceptionList = &pvStack_10;
    FUN_007cfd20(uVar2);
    iVar4 = piVar1[1];
    iVar3 = *piVar1;
  }
  param_2 = (int *)0x0;
  uVar2 = 0;
  if (iVar4 - iVar3 >> 2 != 0) {
    do {
      param_2 = (int *)(*(int *)(iVar3 + uVar2 * 4) - (int)param_2);
      if (piStack_14 == piStack_18) {
        FUN_0063d9b0(piStack_18,&param_2);
      }
      else {
        *piStack_18 = (int)param_2;
        piStack_18 = piStack_18 + 1;
      }
      iVar3 = *piVar1;
      param_2 = *(int **)(iVar3 + uVar2 * 4);
      uVar2 = uVar2 + 1;
    } while (uVar2 < (uint)(piVar1[1] - iVar3 >> 2));
  }
  FUN_00a25720(param_1,&iStack_1c);
  if (iStack_1c != 0) {
    uVar2 = (int)piStack_14 - iStack_1c & 0xfffffffc;
    iVar4 = iStack_1c;
    if (0xfff < uVar2) {
      iVar4 = *(int *)(iStack_1c + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iStack_1c - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20126 ; VA 0x00a25490 ; FUN_00a25490 */

void FUN_00a25490(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  piVar1 = param_2;
  uVar4 = 0;
  iVar2 = param_2[1];
  iVar3 = *param_2;
  if (iVar2 - iVar3 >> 3 != 0) {
    do {
      iVar2 = *(int *)(*piVar1 + 4 + uVar4 * 8);
      param_2 = (int *)CONCAT13((byte)(iVar2 >> 0x1f) ^ (byte)((uint)(iVar2 << 1) >> 0x18),
                                param_2._0_3_);
      FUN_00a25190((int)&param_2 + 3,1);
      iVar2 = piVar1[1];
      uVar4 = uVar4 + 1;
      iVar3 = *piVar1;
    } while (uVar4 < (uint)(iVar2 - iVar3 >> 3));
  }
  uVar4 = 0;
  if (iVar2 - iVar3 >> 3 != 0) {
    do {
      iVar2 = *(int *)(*piVar1 + 4 + uVar4 * 8);
      param_2 = (int *)CONCAT13((byte)(iVar2 >> 0x1f) ^ (byte)((uint)(iVar2 << 1) >> 0x10),
                                param_2._0_3_);
      FUN_00a25190((int)&param_2 + 3,1);
      iVar2 = piVar1[1];
      uVar4 = uVar4 + 1;
      iVar3 = *piVar1;
    } while (uVar4 < (uint)(iVar2 - iVar3 >> 3));
  }
  uVar4 = 0;
  if (iVar2 - iVar3 >> 3 != 0) {
    do {
      iVar2 = *(int *)(*piVar1 + 4 + uVar4 * 8);
      param_2 = (int *)CONCAT13((byte)(iVar2 >> 0x1f) ^ (byte)((uint)(iVar2 << 1) >> 8),
                                param_2._0_3_);
      FUN_00a25190((int)&param_2 + 3,1);
      iVar2 = piVar1[1];
      uVar4 = uVar4 + 1;
      iVar3 = *piVar1;
    } while (uVar4 < (uint)(iVar2 - iVar3 >> 3));
  }
  uVar4 = 0;
  if (iVar2 - iVar3 >> 3 != 0) {
    do {
      iVar2 = *(int *)(*piVar1 + 4 + uVar4 * 8);
      param_2 = (int *)CONCAT13((byte)(iVar2 >> 0x1f) ^
                                ((byte)(iVar2 << 1) |
                                (byte)((uint)*(undefined4 *)(*piVar1 + uVar4 * 8) >> 0x1f)),
                                param_2._0_3_);
      FUN_00a25190((int)&param_2 + 3,1);
      iVar2 = piVar1[1];
      uVar4 = uVar4 + 1;
      iVar3 = *piVar1;
    } while (uVar4 < (uint)(iVar2 - iVar3 >> 3));
  }
  uVar4 = 0;
  if (iVar2 - iVar3 >> 3 != 0) {
    do {
      param_2 = (int *)CONCAT13((byte)((int)*(undefined4 *)(*piVar1 + 4 + uVar4 * 8) >> 0x1f) ^
                                (byte)((uint)(*(int *)(*piVar1 + uVar4 * 8) * 2) >> 0x18),
                                param_2._0_3_);
      FUN_00a25190((int)&param_2 + 3,1);
      iVar2 = piVar1[1];
      uVar4 = uVar4 + 1;
      iVar3 = *piVar1;
    } while (uVar4 < (uint)(iVar2 - iVar3 >> 3));
  }
  uVar4 = 0;
  if (iVar2 - iVar3 >> 3 != 0) {
    do {
      param_2 = (int *)CONCAT13((byte)((int)*(undefined4 *)(*piVar1 + 4 + uVar4 * 8) >> 0x1f) ^
                                (byte)((uint)(*(int *)(*piVar1 + uVar4 * 8) * 2) >> 0x10),
                                param_2._0_3_);
      FUN_00a25190((int)&param_2 + 3,1);
      iVar2 = piVar1[1];
      uVar4 = uVar4 + 1;
      iVar3 = *piVar1;
    } while (uVar4 < (uint)(iVar2 - iVar3 >> 3));
  }
  uVar4 = 0;
  if (iVar2 - iVar3 >> 3 != 0) {
    do {
      param_2 = (int *)CONCAT13((byte)((int)*(undefined4 *)(*piVar1 + 4 + uVar4 * 8) >> 0x1f) ^
                                (byte)((uint)(*(int *)(*piVar1 + uVar4 * 8) * 2) >> 8),param_2._0_3_
                               );
      FUN_00a25190((int)&param_2 + 3,1);
      iVar2 = piVar1[1];
      uVar4 = uVar4 + 1;
      iVar3 = *piVar1;
    } while (uVar4 < (uint)(iVar2 - iVar3 >> 3));
  }
  uVar4 = 0;
  if (iVar2 - iVar3 >> 3 != 0) {
    do {
      param_2 = (int *)CONCAT13((byte)((int)*(undefined4 *)(*piVar1 + 4 + uVar4 * 8) >> 0x1f) ^
                                (char)*(undefined4 *)(*piVar1 + uVar4 * 8) * '\x02',param_2._0_3_);
      FUN_00a25190((int)&param_2 + 3,1);
      uVar4 = uVar4 + 1;
    } while (uVar4 < (uint)(piVar1[1] - *piVar1 >> 3));
  }
  return;
}



/* FUNCTION 20127 ; VA 0x00a25720 ; FUN_00a25720 */

void FUN_00a25720(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  piVar2 = param_2;
  uVar5 = 0;
  iVar3 = param_2[1];
  iVar4 = *param_2;
  if (iVar3 - iVar4 >> 2 != 0) {
    do {
      iVar3 = *(int *)(*piVar2 + uVar5 * 4);
      param_2 = (int *)CONCAT13((byte)((uint)(iVar3 * 2) >> 0x18) ^ (byte)(iVar3 >> 0x1f),
                                param_2._0_3_);
      FUN_00a25190((int)&param_2 + 3,1);
      iVar3 = piVar2[1];
      uVar5 = uVar5 + 1;
      iVar4 = *piVar2;
    } while (uVar5 < (uint)(iVar3 - iVar4 >> 2));
  }
  uVar5 = 0;
  if (iVar3 - iVar4 >> 2 != 0) {
    do {
      iVar3 = *(int *)(*piVar2 + uVar5 * 4);
      param_2 = (int *)CONCAT13((byte)((uint)(iVar3 * 2) >> 0x10) ^ (byte)(iVar3 >> 0x1f),
                                param_2._0_3_);
      FUN_00a25190((int)&param_2 + 3,1);
      iVar3 = piVar2[1];
      uVar5 = uVar5 + 1;
      iVar4 = *piVar2;
    } while (uVar5 < (uint)(iVar3 - iVar4 >> 2));
  }
  uVar5 = 0;
  if (iVar3 - iVar4 >> 2 != 0) {
    do {
      iVar3 = *(int *)(*piVar2 + uVar5 * 4);
      param_2 = (int *)CONCAT13((byte)((uint)(iVar3 * 2) >> 8) ^ (byte)(iVar3 >> 0x1f),param_2._0_3_
                               );
      FUN_00a25190((int)&param_2 + 3,1);
      iVar3 = piVar2[1];
      uVar5 = uVar5 + 1;
      iVar4 = *piVar2;
    } while (uVar5 < (uint)(iVar3 - iVar4 >> 2));
  }
  uVar5 = 0;
  if (iVar3 - iVar4 >> 2 != 0) {
    do {
      uVar1 = *(undefined4 *)(*piVar2 + uVar5 * 4);
      param_2 = (int *)CONCAT13((byte)((int)uVar1 >> 0x1f) ^ (char)uVar1 * '\x02',param_2._0_3_);
      FUN_00a25190((int)&param_2 + 3,1);
      uVar5 = uVar5 + 1;
    } while (uVar5 < (uint)(piVar2[1] - *piVar2 >> 2));
  }
  return;
}



/* FUNCTION 20128 ; VA 0x00a25830 ; FUN_00a25830 */

/* WARNING: Type propagation algorithm not settling */

void FUN_00a25830(undefined4 param_1,int *param_2,int *param_3,undefined4 param_4,undefined4 param_5
                 ,uint param_6)

{
  bool bVar1;
  byte bVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  float *pfVar7;
  float **ppfVar8;
  uint uVar9;
  uint uVar10;
  undefined *puVar11;
  float10 fVar12;
  double dVar13;
  float fVar14;
  undefined *puVar15;
  float fStack_ac;
  float fStack_a8;
  float fStack_a4;
  float fStack_a0;
  float fStack_9c;
  float fStack_98;
  float fStack_94;
  float *pfStack_90;
  float *pfStack_8c;
  float *pfStack_88;
  float *pfStack_84;
  float *pfStack_80;
  uint uStack_7c;
  uint auStack_78 [3];
  int iStack_6c;
  int iStack_68;
  uint auStack_64 [7];
  float *pfStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  float *apfStack_38 [2];
  int iStack_30;
  undefined4 uStack_2c;
  float *pfStack_28;
  undefined auStack_21 [5];
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  auStack_21._1_4_ = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017dc316;
  pvStack_1c = ExceptionList;
  uStack_44 = 0;
  uStack_7c = 0;
  ExceptionList = &pvStack_1c;
  puVar11 = &stack0xfffffffc;
  if (((param_6 & 0x10) == 0) ||
     (iVar5 = param_2[10], ExceptionList = &pvStack_1c, iVar4 = FUN_00886600(),
     puVar11 = (undefined *)auStack_21._1_4_, iVar5 != iVar4)) {
    auStack_21._1_4_ = puVar11;
    iVar5 = param_2[10];
    iVar4 = FUN_00886600();
    if ((iVar5 == iVar4) ||
       ((iVar5 = param_2[10], iVar4 = FUN_0088cb40(), iVar5 == iVar4 ||
        (iVar5 = param_2[10], iVar4 = FUN_0088cf00(), iVar5 == iVar4)))) {
      auStack_21[0] = 1;
      FUN_00a25190(auStack_21,1);
      pfStack_48 = (float *)0x0;
      iVar5 = *param_3;
      uVar10 = 0;
      if (param_3[1] - iVar5 >> 2 != 0) {
        do {
          bVar1 = true;
          if (param_2 == &DAT_01ee5728) {
            pfStack_28 = *(float **)(iVar5 + (int)pfStack_48 * 4);
            if (((pfStack_28 == (float *)0x0) ||
                (fVar14 = pfStack_28[3], iVar5 = FUN_009ec190(),
                (uint)*(ushort *)(iVar5 + 0x1da) <
                (uint)*(ushort *)((int)fVar14 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) ||
               (*(char *)((int)pfStack_28 + 0xee) == '\0')) {
              bVar1 = true;
            }
            else {
              bVar1 = false;
            }
          }
          if (bVar1) {
            pfVar7 = (float *)(**(code **)(*param_2 + 0x30))
                                        (auStack_78,*(undefined4 *)(*param_3 + (int)pfStack_48 * 4))
            ;
            uStack_14 = 3;
            uStack_7c = uVar10 | 8;
          }
          else {
            pfStack_84 = (float *)0x0;
            pfStack_80 = (float *)0xf;
            fStack_94 = (float)((uint)fStack_94 & 0xffffff00);
            FUN_005542c0(&DAT_018bc9b8,0);
            pfVar7 = &fStack_94;
            uStack_14 = 4;
            uStack_7c = uVar10 | 0x10;
          }
          pfStack_28 = (float *)pfVar7[4];
          uStack_44 = uStack_7c;
          FUN_00a25190(&pfStack_28,4);
          if (0xf < (uint)pfVar7[5]) {
            pfVar7 = (float *)*pfVar7;
          }
          FUN_00a25190(pfVar7,pfStack_28);
          uStack_14 = 3;
          if (((uStack_44 & 0x10) != 0) &&
             (uStack_7c = uStack_44 & 0xffffffef, uStack_44 = uStack_7c, (float *)0xf < pfStack_80))
          {
            pfVar7 = (float *)((int)pfStack_80 + 1);
            fVar14 = fStack_94;
            if ((float *)0xfff < pfVar7) {
              fVar14 = *(float *)((int)fStack_94 - 4);
              pfVar7 = pfStack_80 + 9;
              if (0x1f < ((int)fStack_94 - (int)fVar14) - 4U) goto LAB_00a27551;
            }
            FUN_01674ea0(fVar14,pfVar7);
          }
          uStack_14 = 0xffffffff;
          if (((uStack_44 & 8) != 0) &&
             (uStack_7c = uStack_44 & 0xfffffff7, uStack_44 = uStack_7c, 0xf < auStack_64[0])) {
            uVar9 = auStack_64[0] + 1;
            uVar10 = auStack_78[0];
            if (0xfff < uVar9) {
              uVar10 = *(uint *)(auStack_78[0] - 4);
              uVar9 = auStack_64[0] + 0x24;
              if (0x1f < (auStack_78[0] - uVar10) - 4) goto LAB_00a27551;
            }
            FUN_01674ea0(uVar10,uVar9);
          }
          pfStack_48 = (float *)((int)pfStack_48 + 1);
          iVar5 = *param_3;
          uVar10 = uStack_44;
        } while (pfStack_48 < (float *)(param_3[1] - iVar5 >> 2));
      }
    }
    else {
      iVar5 = param_2[10];
      iVar4 = FUN_0088daf0();
      if (iVar5 == iVar4) {
        auStack_21[0] = 2;
        FUN_00a25190(auStack_21,1);
        uVar10 = 0;
        if (param_3[1] - *param_3 >> 2 != 0) {
          do {
            auStack_21[0] =
                 (**(code **)(*(int *)param_2[0xd] + 0xc))(*(undefined4 *)(*param_3 + uVar10 * 4));
            FUN_00a25190(auStack_21,1);
            uVar10 = uVar10 + 1;
          } while (uVar10 < (uint)(param_3[1] - *param_3 >> 2));
          ExceptionList = pvStack_1c;
          return;
        }
      }
      else {
        iVar5 = param_2[10];
        iVar4 = FUN_0088c8c0();
        if (iVar5 == iVar4) {
          uStack_40 = 0.0;
          apfStack_38[0] = (float *)0x0;
          uStack_14 = 5;
          FUN_007d3f90(param_3[1] - *param_3 >> 2);
          uVar10 = 0;
          iVar5 = *param_3;
          if (param_3[1] - iVar5 >> 2 != 0) {
            pfVar7 = uStack_40._4_4_;
            do {
              pfStack_28 = (float *)(**(code **)(*(int *)param_2[0xd] + 0xc))
                                              (*(undefined4 *)(iVar5 + uVar10 * 4));
              if (apfStack_38[0] == pfVar7) {
                FUN_0063d9b0(pfVar7,&pfStack_28);
                pfVar7 = uStack_40._4_4_;
              }
              else {
                *pfVar7 = (float)pfStack_28;
                uStack_40 = (double)CONCAT44(pfVar7 + 1,(undefined *)uStack_40);
                pfVar7 = pfVar7 + 1;
              }
              uVar10 = uVar10 + 1;
              iVar5 = *param_3;
            } while (uVar10 < (uint)(param_3[1] - iVar5 >> 2));
          }
          auStack_21[0] = 3;
          FUN_00a25190(auStack_21,1);
          FUN_00a25720(param_1,&uStack_40);
        }
        else {
          iVar5 = param_2[10];
          iVar4 = FUN_0088da50();
          if (iVar5 == iVar4) {
            auStack_64[4] = 0;
            auStack_64[5] = 0;
            auStack_64[6] = 0;
            uStack_14 = 6;
            FUN_00a24a50(param_3[1] - *param_3 >> 2);
            uVar10 = 0;
            if (param_3[1] - *param_3 >> 2 != 0) {
              do {
                uStack_40 = (double)(**(code **)(*(int *)param_2[0xd] + 0xc))
                                              (*(undefined4 *)(*param_3 + uVar10 * 4));
                FUN_00a21ff0(&uStack_40);
                uVar10 = uVar10 + 1;
              } while (uVar10 < (uint)(param_3[1] - *param_3 >> 2));
            }
            auStack_21[0] = 0x1b;
            FUN_00a25190(auStack_21,1);
            FUN_00a25490(param_1,auStack_64 + 4);
            FUN_0056d380();
            ExceptionList = pvStack_1c;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088c960();
          if (iVar5 == iVar4) {
            auStack_64[4] = 0;
            auStack_64[5] = 0;
            auStack_64[6] = 0;
            uStack_14 = 7;
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            uVar10 = 0;
            if (param_3[1] - *param_3 >> 2 != 0) {
              do {
                pfStack_28 = *(float **)(*(int *)param_2[0xd] + 0xc);
                fVar12 = (float10)(*(code *)pfStack_28)(*(undefined4 *)(*param_3 + uVar10 * 4));
                pfStack_28 = (float *)(float)fVar12;
                FUN_007eceb0(&pfStack_28);
                uVar10 = uVar10 + 1;
              } while (uVar10 < (uint)(param_3[1] - *param_3 >> 2));
            }
            auStack_21[0] = 4;
            FUN_00a25190(auStack_21,1);
            FUN_00a25260(param_1,auStack_64 + 4);
            FUN_0056d320();
            ExceptionList = pvStack_1c;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088ca00();
          if (iVar5 == iVar4) {
            auStack_21[0] = 5;
            FUN_00a25190(auStack_21,1);
            uVar10 = 0;
            if (param_3[1] - *param_3 >> 2 == 0) {
              ExceptionList = pvStack_1c;
              return;
            }
            do {
              pfStack_28 = *(float **)(*(int *)param_2[0xd] + 0xc);
              fVar12 = (float10)(*(code *)pfStack_28)(*(undefined4 *)(*param_3 + uVar10 * 4));
              uStack_40 = (double)fVar12;
              FUN_00a25190(&uStack_40,8);
              uVar10 = uVar10 + 1;
            } while (uVar10 < (uint)(param_3[1] - *param_3 >> 2));
            ExceptionList = pvStack_1c;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d690();
          if (iVar5 == iVar4) {
            iStack_30 = 0;
            uStack_2c = 0;
            pfStack_28 = (float *)0x0;
            uStack_14 = 8;
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            auStack_64[4] = 0;
            auStack_64[5] = 0;
            auStack_64[6] = 0;
            uStack_14 = CONCAT31(uStack_14._1_3_,9);
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            uVar10 = 0;
            if (param_3[1] - *param_3 >> 2 != 0) {
              do {
                (**(code **)(*(int *)param_2[0xd] + 0xc))
                          ((int)&uStack_40 + 4,*(undefined4 *)(*param_3 + uVar10 * 4));
                FUN_007eceb0((int)&uStack_40 + 4);
                FUN_00646760(apfStack_38);
                uVar10 = uVar10 + 1;
              } while (uVar10 < (uint)(param_3[1] - *param_3 >> 2));
            }
            auStack_21[0] = 6;
            FUN_00a25190(auStack_21,1);
            FUN_00a25260(param_1,&iStack_30);
            FUN_00a25720(param_1,auStack_64 + 4);
            FUN_0056d320();
            FUN_0056d320();
            ExceptionList = pvStack_1c;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d5f0();
          if (iVar5 == iVar4) {
            auStack_64[1] = 0;
            auStack_64[2] = 0;
            auStack_64[3] = 0;
            iStack_30 = 0;
            uStack_2c = 0;
            pfStack_28 = (float *)0x0;
            uStack_14._0_1_ = 0xb;
            uStack_14._1_3_ = 0;
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            uStack_40 = 0.0;
            apfStack_38[0] = (float *)0x0;
            auStack_64[4] = 0;
            auStack_64[5] = 0;
            auStack_64[6] = 0;
            uStack_14 = CONCAT31(uStack_14._1_3_,0xd);
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            uVar10 = 0;
            if (param_3[1] - *param_3 >> 2 != 0) {
              do {
                (**(code **)(*(int *)param_2[0xd] + 0xc))
                          (&pfStack_8c,*(undefined4 *)(*param_3 + uVar10 * 4));
                FUN_007eceb0(&pfStack_8c);
                FUN_007eceb0(&pfStack_84);
                FUN_00646760(&pfStack_88);
                FUN_00646760(&pfStack_80);
                uVar10 = uVar10 + 1;
              } while (uVar10 < (uint)(param_3[1] - *param_3 >> 2));
            }
            auStack_21[0] = 7;
            FUN_00a25190(auStack_21,1);
            FUN_00a25260(param_1,auStack_64 + 1);
            FUN_00a25260(param_1,&iStack_30);
            FUN_00a25720(param_1,&uStack_40);
            FUN_00a25720(param_1,auStack_64 + 4);
            FUN_0056d320();
            FUN_0056d320();
            FUN_0056d320();
            FUN_0056d320();
            ExceptionList = pvStack_1c;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d370();
          if (iVar5 == iVar4) {
            auStack_21[0] = 8;
            FUN_00a25190(auStack_21,1);
            uVar10 = 0;
            if (param_3[1] - *param_3 >> 2 == 0) {
              ExceptionList = pvStack_1c;
              return;
            }
            do {
              (**(code **)(*(int *)param_2[0xd] + 0xc))
                        (&fStack_94,*(undefined4 *)(*param_3 + uVar10 * 4));
              FUN_00a25190(&fStack_94,0xc);
              FUN_00a25190(&pfStack_88,0xc);
              uVar10 = uVar10 + 1;
            } while (uVar10 < (uint)(param_3[1] - *param_3 >> 2));
            ExceptionList = pvStack_1c;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d230();
          if (iVar5 == iVar4) {
            auStack_21[0] = 9;
            FUN_00a25190(auStack_21,1);
            uVar10 = 0;
            if (param_3[1] - *param_3 >> 2 == 0) {
              ExceptionList = pvStack_1c;
              return;
            }
            do {
              (**(code **)(*(int *)param_2[0xd] + 0xc))
                        (&pfStack_28,*(undefined4 *)(*param_3 + uVar10 * 4));
              auStack_21[0] = pfStack_28._0_1_;
              FUN_00a25190(auStack_21,1);
              uVar10 = uVar10 + 1;
            } while (uVar10 < (uint)(param_3[1] - *param_3 >> 2));
            ExceptionList = pvStack_1c;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088ce60();
          if (iVar5 == iVar4) {
            auStack_21[0] = 10;
            FUN_00a25190(auStack_21,1);
            uVar10 = 0;
            if (param_3[1] - *param_3 >> 2 == 0) {
              ExceptionList = pvStack_1c;
              return;
            }
            do {
              (**(code **)(*(int *)param_2[0xd] + 0xc))
                        (&pfStack_28,*(undefined4 *)(*param_3 + uVar10 * 4));
              auStack_21[0] = pfStack_28._0_1_;
              FUN_00a25190(auStack_21,1);
              uVar10 = uVar10 + 1;
            } while (uVar10 < (uint)(param_3[1] - *param_3 >> 2));
            ExceptionList = pvStack_1c;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088cfa0();
          if (iVar5 == iVar4) {
            auStack_64[1] = 0;
            auStack_64[2] = 0;
            auStack_64[3] = 0;
            uStack_14 = 0xe;
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            uVar10 = 0;
            if (param_3[1] - *param_3 >> 2 != 0) {
              do {
                (**(code **)(*(int *)param_2[0xd] + 0xc))
                          (&pfStack_28,*(undefined4 *)(*param_3 + uVar10 * 4));
                pfStack_48 = pfStack_28;
                FUN_00646760(&pfStack_48);
                uVar10 = uVar10 + 1;
              } while (uVar10 < (uint)(param_3[1] - *param_3 >> 2));
            }
            auStack_21[0] = 0xb;
            FUN_00a25190(auStack_21,1);
            FUN_00a276a0(param_1,auStack_64 + 1);
            FUN_0056d320();
            ExceptionList = pvStack_1c;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d050();
          if (iVar5 == iVar4) {
            uStack_40 = 0.0;
            apfStack_38[0] = (float *)0x0;
            auStack_64[4] = 0;
            auStack_64[5] = 0;
            auStack_64[6] = 0;
            auStack_64[1] = 0;
            auStack_64[2] = 0;
            auStack_64[3] = 0;
            uStack_14 = 0x11;
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            uVar10 = 0;
            if (param_3[1] - *param_3 >> 2 != 0) {
              do {
                (**(code **)(*(int *)param_2[0xd] + 0xc))
                          (&iStack_6c,*(undefined4 *)(*param_3 + uVar10 * 4));
                FUN_007eceb0(&iStack_6c);
                FUN_007eceb0(&iStack_68);
                FUN_007eceb0(auStack_64);
                uVar10 = uVar10 + 1;
              } while (uVar10 < (uint)(param_3[1] - *param_3 >> 2));
            }
            auStack_21[0] = 0xc;
            FUN_00a25190(auStack_21,1);
            FUN_00a25260(param_1,&uStack_40);
            FUN_00a25260(param_1,auStack_64 + 4);
            FUN_00a25260(param_1,auStack_64 + 1);
            FUN_0056d320();
            FUN_0056d320();
            FUN_0056d320();
            ExceptionList = pvStack_1c;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d0f0();
          if (iVar5 == iVar4) {
            auStack_64[4] = 0;
            auStack_64[5] = 0;
            auStack_64[6] = 0;
            iStack_30 = 0;
            uStack_2c = 0;
            pfStack_28 = (float *)0x0;
            uStack_40 = 0.0;
            apfStack_38[0] = (float *)0x0;
            uStack_14 = 0x14;
            FUN_00a24a20(param_3[1] - *param_3 >> 2);
            FUN_00a24a20(param_3[1] - *param_3 >> 2);
            FUN_00a24a20(param_3[1] - *param_3 >> 2);
            uVar10 = 0;
            if (param_3[1] - *param_3 >> 2 != 0) {
              do {
                (**(code **)(*(int *)param_2[0xd] + 0xc))
                          (&uStack_44,*(undefined4 *)(*param_3 + uVar10 * 4));
                FUN_00719390(&uStack_44);
                FUN_00719390((int)&uStack_44 + 1);
                FUN_00719390((int)&uStack_44 + 2);
                uVar10 = uVar10 + 1;
              } while (uVar10 < (uint)(param_3[1] - *param_3 >> 2));
            }
            auStack_21[0] = 0x1a;
            FUN_00a25190(auStack_21,1);
            FUN_00a25190(auStack_64[4],auStack_64[5] - auStack_64[4]);
            FUN_00a25190(iStack_30,uStack_2c - iStack_30);
            FUN_00a25190((undefined *)uStack_40,(int)uStack_40._4_4_ - (int)(undefined *)uStack_40);
            FUN_0056d2d0();
            FUN_0056d2d0();
            FUN_0056d2d0();
            ExceptionList = pvStack_1c;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d410();
          if (iVar5 == iVar4) {
            iStack_6c = 0;
            iStack_68 = 0;
            auStack_64[0] = 0;
            uStack_40 = 0.0;
            apfStack_38[0] = (float *)0x0;
            auStack_64[4] = 0;
            auStack_64[5] = 0;
            auStack_64[6] = 0;
            auStack_64[1] = 0;
            auStack_64[2] = 0;
            auStack_64[3] = 0;
            uStack_14 = 0x18;
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            uVar10 = 0;
            if (param_3[1] - *param_3 >> 2 != 0) {
              do {
                (**(code **)(*(int *)param_2[0xd] + 0xc))
                          (&pfStack_8c,*(undefined4 *)(*param_3 + uVar10 * 4));
                pfStack_28 = pfStack_8c;
                FUN_007eceb0(&pfStack_28);
                pfStack_28 = pfStack_88;
                FUN_007eceb0(&pfStack_28);
                pfStack_28 = pfStack_84;
                FUN_007eceb0(&pfStack_28);
                pfStack_28 = pfStack_80;
                FUN_007eceb0(&pfStack_28);
                uVar10 = uVar10 + 1;
              } while (uVar10 < (uint)(param_3[1] - *param_3 >> 2));
            }
            auStack_21[0] = 0x18;
            FUN_00a25190(auStack_21,1);
            FUN_00a25260(param_1,&iStack_6c);
            FUN_00a25260(param_1,&uStack_40);
            FUN_00a25260(param_1,auStack_64 + 4);
            FUN_00a25260(param_1,auStack_64 + 1);
            FUN_0056d320();
            FUN_0056d320();
            FUN_0056d320();
            FUN_0056d320();
            ExceptionList = pvStack_1c;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d2d0();
          if (iVar5 == iVar4) {
            auStack_21[0] = '\x19';
            FUN_00a25190(auStack_21,1);
            uVar10 = 0;
            iVar5 = *param_3;
            if (param_3[1] - iVar5 >> 2 == 0) {
              ExceptionList = pvStack_1c;
              return;
            }
            do {
              (**(code **)(*(int *)param_2[0xd] + 0xc))
                        (&fStack_94,*(undefined4 *)(iVar5 + uVar10 * 4));
              auStack_21[0] = fStack_94._0_1_;
              FUN_00a25190(auStack_21,1);
              if (auStack_21[0] != '\0') {
                pfStack_28 = pfStack_90;
                FUN_00a25190(&pfStack_28,4);
                pfStack_28 = pfStack_88;
                FUN_00a25190(&pfStack_28,4);
                pfStack_28 = pfStack_8c;
                FUN_00a25190(&pfStack_28,4);
                pfStack_28 = pfStack_84;
                FUN_00a25190(&pfStack_28,4);
                pfStack_28 = pfStack_80;
                FUN_00a25190(&pfStack_28,4);
              }
              uVar10 = uVar10 + 1;
              iVar5 = *param_3;
            } while (uVar10 < (uint)(param_3[1] - iVar5 >> 2));
            ExceptionList = pvStack_1c;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d730();
          if (iVar5 == iVar4) {
            auStack_64[1] = 0;
            auStack_64[2] = 0;
            auStack_64[3] = 0;
            iStack_6c = 0;
            iStack_68 = 0;
            auStack_64[0] = 0;
            uStack_14 = 0x1a;
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            uVar10 = 0;
            if (param_3[1] - *param_3 >> 2 != 0) {
              do {
                (**(code **)(*(int *)param_2[0xd] + 0xc))
                          ((int)&uStack_40 + 4,*(undefined4 *)(*param_3 + uVar10 * 4));
                FUN_007eceb0((int)&uStack_40 + 4);
                FUN_007eceb0(apfStack_38);
                uVar10 = uVar10 + 1;
              } while (uVar10 < (uint)(param_3[1] - *param_3 >> 2));
            }
            auStack_21[0] = 0xd;
            FUN_00a25190(auStack_21,1);
            FUN_00a25260(param_1,auStack_64 + 1);
            FUN_00a25260(param_1,&iStack_6c);
            FUN_0056d320();
            FUN_0056d320();
            ExceptionList = pvStack_1c;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d870();
          if (iVar5 == iVar4) {
            auStack_64[4] = 0;
            auStack_64[5] = 0;
            auStack_64[6] = 0;
            auStack_64[1] = 0;
            auStack_64[2] = 0;
            auStack_64[3] = 0;
            iStack_6c = 0;
            iStack_68 = 0;
            auStack_64[0] = 0;
            uStack_14 = 0x1d;
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            uVar10 = 0;
            if (param_3[1] - *param_3 >> 2 != 0) {
              do {
                (**(code **)(*(int *)param_2[0xd] + 0xc))
                          (&uStack_40,*(undefined4 *)(*param_3 + uVar10 * 4));
                FUN_007eceb0(&uStack_40);
                FUN_007eceb0((int)&uStack_40 + 4);
                FUN_007eceb0(apfStack_38);
                uVar10 = uVar10 + 1;
              } while (uVar10 < (uint)(param_3[1] - *param_3 >> 2));
            }
            auStack_21[0] = 0xe;
            FUN_00a25190(auStack_21,1);
            FUN_00a25260(param_1,auStack_64 + 4);
            FUN_00a25260(param_1,auStack_64 + 1);
            FUN_00a25260(param_1,&iStack_6c);
            FUN_0056d320();
            FUN_0056d320();
            FUN_0056d320();
            ExceptionList = pvStack_1c;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d7d0();
          if (iVar5 == iVar4) {
            auStack_21[0] = 0xf;
            FUN_00a25190(auStack_21,1);
            uVar10 = 0;
            if (param_3[1] - *param_3 >> 2 == 0) {
              ExceptionList = pvStack_1c;
              return;
            }
            do {
              (**(code **)(*(int *)param_2[0xd] + 0xc))
                        (&pfStack_28,*(undefined4 *)(*param_3 + uVar10 * 4));
              FUN_00a25190(&pfStack_28,4);
              uVar10 = uVar10 + 1;
            } while (uVar10 < (uint)(param_3[1] - *param_3 >> 2));
            ExceptionList = pvStack_1c;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_0088d910();
          if (iVar5 == iVar4) {
            auStack_21[0] = 0x14;
            FUN_00a25190(auStack_21,1);
            uVar10 = 0;
            if (param_3[1] - *param_3 >> 2 == 0) {
              ExceptionList = pvStack_1c;
              return;
            }
            do {
              (**(code **)(*(int *)param_2[0xd] + 0xc))
                        ((int)&uStack_2c + 2,*(undefined4 *)(*param_3 + uVar10 * 4));
              FUN_00a25190((int)&uStack_2c + 2,6);
              uVar10 = uVar10 + 1;
            } while (uVar10 < (uint)(param_3[1] - *param_3 >> 2));
            ExceptionList = pvStack_1c;
            return;
          }
          iVar5 = param_2[10];
          iVar4 = FUN_00b00260();
          if (iVar5 == iVar4) {
            uStack_40 = 0.0;
            apfStack_38[0] = (float *)0x0;
            auStack_64[4] = 0;
            auStack_64[5] = 0;
            auStack_64[6] = 0;
            auStack_64[1] = 0;
            auStack_64[2] = 0;
            auStack_64[3] = 0;
            iStack_6c = 0;
            iStack_68 = 0;
            auStack_64[0] = 0;
            uStack_14 = 0x21;
            iVar5 = param_3[1];
            iVar4 = *param_3;
            uVar10 = iVar5 - iVar4 >> 2;
            puVar11 = (undefined *)0x0;
            pfVar7 = (float *)0x0;
            if (uVar10 != 0) {
              if (0x71c71c7 < uVar10) {
                    /* WARNING: Subroutine does not return */
                FUN_00577c30();
              }
              FUN_00a20280(uVar10);
              iVar5 = param_3[1];
              iVar4 = *param_3;
              puVar11 = (undefined *)uStack_40;
              pfVar7 = uStack_40._4_4_;
            }
            FUN_007d3f90(iVar5 - iVar4 >> 2);
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            pfStack_28 = (float *)0x0;
            pfStack_48 = (float *)*param_3;
            if (param_3[1] - (int)pfStack_48 >> 2 != 0) {
              do {
                (**(code **)(*(int *)param_2[0xd] + 0xc))(&fStack_ac,pfStack_48[(int)pfStack_28]);
                if (apfStack_38[0] == pfVar7) {
                  FUN_00a1bc40(pfVar7,&fStack_ac);
                  pfVar7 = uStack_40._4_4_;
                }
                else {
                  *pfVar7 = fStack_ac;
                  pfVar7[1] = fStack_a8;
                  pfVar7[2] = fStack_a4;
                  pfVar7[3] = fStack_a0;
                  pfVar7[4] = fStack_9c;
                  pfVar7[5] = fStack_98;
                  pfVar7[6] = fStack_94;
                  pfVar7[7] = (float)pfStack_90;
                  pfVar7[8] = (float)pfStack_8c;
                  uStack_40 = (double)CONCAT44(pfVar7 + 9,(undefined *)uStack_40);
                  pfVar7 = pfVar7 + 9;
                }
                FUN_007eceb0(&pfStack_88);
                FUN_007eceb0(&pfStack_84);
                FUN_007eceb0(&pfStack_80);
                pfStack_28 = (float *)((int)pfStack_28 + 1);
                pfStack_48 = (float *)*param_3;
              } while (pfStack_28 < (float *)(param_3[1] - (int)pfStack_48 >> 2));
              puVar11 = (undefined *)uStack_40;
            }
            bVar2 = ~(byte)(param_6 >> 2) & 1;
            auStack_21[0] = (bVar2 ^ 1) + 0x10;
            FUN_00a25190(auStack_21,1);
            pfStack_28 = (float *)0x0;
            iVar5 = param_3[1] - *param_3 >> 2;
            if (bVar2 == 0) {
              if (iVar5 != 0) {
                do {
                  cVar3 = FUN_00c94220(puVar11);
                  if (cVar3 == '\0') {
                    FUN_00cf6ea0(puVar11);
                    dVar13 = (double)((float)pfStack_8c * (float)pfStack_8c +
                                      (float)pfStack_88 * (float)pfStack_88 +
                                      (float)pfStack_84 * (float)pfStack_84 +
                                     (float)pfStack_80 * (float)pfStack_80);
                    FUN_017267a0();
                    auStack_21[0] = '\0';
                    fVar14 = DAT_018ce2f8 / (float)dVar13;
                    pfStack_8c = (float *)(fVar14 * (float)pfStack_8c);
                    pfStack_88 = (float *)(fVar14 * (float)pfStack_88);
                    pfStack_84 = (float *)(fVar14 * (float)pfStack_84);
                    pfStack_80 = (float *)(fVar14 * (float)pfStack_80);
                    FUN_00a25190(auStack_21,1);
                    uVar6 = 0x10;
                    ppfVar8 = &pfStack_8c;
                  }
                  else {
                    auStack_21[0] = FUN_00c938f0();
                    auStack_21[0] = auStack_21[0] + '\x01';
                    ppfVar8 = (float **)auStack_21;
                    uVar6 = 1;
                  }
                  FUN_00a25190(ppfVar8,uVar6);
                  puVar11 = puVar11 + 0x24;
                  pfStack_28 = (float *)((int)pfStack_28 + 1);
                } while (pfStack_28 < (float *)(param_3[1] - *param_3 >> 2));
              }
            }
            else if (iVar5 != 0) {
              do {
                cVar3 = FUN_00c94220(puVar11);
                if (cVar3 == '\0') {
                  auStack_21[0] = '\0';
                  FUN_00a25190(auStack_21,1);
                  uVar6 = 0x24;
                  puVar15 = puVar11;
                }
                else {
                  auStack_21[0] = FUN_00c938f0(puVar11);
                  auStack_21[0] = auStack_21[0] + '\x01';
                  uVar6 = 1;
                  puVar15 = auStack_21;
                }
                FUN_00a25190(puVar15,uVar6);
                puVar11 = puVar11 + 0x24;
                pfStack_28 = (float *)((int)pfStack_28 + 1);
              } while (pfStack_28 < (float *)(param_3[1] - *param_3 >> 2));
            }
            FUN_00a25260(param_1,auStack_64 + 4);
            FUN_00a25260(param_1,auStack_64 + 1);
            FUN_00a25260(param_1,&iStack_6c);
            FUN_0056d320();
            FUN_0056d320();
            FUN_0056d320();
            FUN_00860030();
            ExceptionList = pvStack_1c;
            return;
          }
          if (*(char *)(param_2 + 0xb) != '\0') {
            iStack_6c = 0;
            iStack_68 = 0;
            auStack_64[0] = 0;
            uStack_14 = 0x22;
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            pfStack_28 = (float *)0x0;
            if (param_3[1] - *param_3 >> 2 != 0) {
              do {
                pfStack_48 = (float *)(**(code **)(*param_2 + 0x44))
                                                (*(undefined4 *)(*param_3 + (int)pfStack_28 * 4));
                FUN_00646760(&pfStack_48);
                pfStack_28 = (float *)((int)pfStack_28 + 1);
              } while (pfStack_28 < (float *)(param_3[1] - *param_3 >> 2));
            }
            auStack_21[0] = 0x12;
            FUN_00a25190(auStack_21,1);
LAB_00a2736d:
            FUN_00a276a0(param_1,&iStack_6c);
            FUN_0056d320();
            ExceptionList = pvStack_1c;
            return;
          }
          cVar3 = FUN_00620ff0(param_2);
          if (cVar3 == '\0') {
            iVar5 = param_2[10];
            iVar4 = FUN_0088d190();
            if (iVar5 == iVar4) {
              auStack_21[0] = 1;
              FUN_00a25190(auStack_21,1);
              uVar10 = 0;
              if (param_3[1] - *param_3 >> 2 == 0) {
                ExceptionList = pvStack_1c;
                return;
              }
              do {
                (**(code **)(*(int *)param_2[0xd] + 0xc))
                          (&fStack_94,*(undefined4 *)(*param_3 + uVar10 * 4));
                uStack_14 = 0x24;
                FUN_00a27660(param_1,&fStack_94);
                uStack_14 = 0xffffffff;
                FUN_005507b0();
                uVar10 = uVar10 + 1;
              } while (uVar10 < (uint)(param_3[1] - *param_3 >> 2));
              ExceptionList = pvStack_1c;
              return;
            }
            iVar5 = param_2[10];
            iVar4 = FUN_00a92ae0();
            if (iVar5 == iVar4) {
              auStack_21[0] = 0x15;
              FUN_00a25190(auStack_21,1);
              pfStack_48 = (float *)0x0;
              if (param_3[1] - *param_3 >> 2 == 0) {
                ExceptionList = pvStack_1c;
                return;
              }
              do {
                (**(code **)(*(int *)param_2[0xd] + 0xc))
                          (&iStack_6c,*(undefined4 *)(*param_3 + (int)pfStack_48 * 4));
                uStack_44 = uStack_44 | 0x1c00;
                pfStack_28 = (float *)((iStack_68 - iStack_6c) / 0xc);
                uStack_14 = 0x25;
                FUN_00a25190(&pfStack_28,4);
                if (pfStack_28 != (float *)0x0) {
                  iVar5 = 0;
                  pfVar7 = pfStack_28;
                  do {
                    FUN_00a25190(iStack_6c + iVar5,0xc);
                    iVar5 = iVar5 + 0xc;
                    pfVar7 = (float *)((int)pfVar7 + -1);
                  } while (pfVar7 != (float *)0x0);
                }
                uStack_14 = 0xffffffff;
                FUN_00617ad0();
                pfStack_48 = (float *)((int)pfStack_48 + 1);
              } while (pfStack_48 < (float *)(param_3[1] - *param_3 >> 2));
              ExceptionList = pvStack_1c;
              return;
            }
            iVar5 = param_2[10];
            iVar4 = FUN_00a8dcc0();
            if (iVar5 == iVar4) {
              auStack_21[0] = 0x16;
              FUN_00a25190(auStack_21,1);
              uVar10 = 0;
              if (param_3[1] - *param_3 >> 2 == 0) {
                ExceptionList = pvStack_1c;
                return;
              }
              do {
                (**(code **)(*(int *)param_2[0xd] + 0xc))
                          (&iStack_6c,*(undefined4 *)(*param_3 + uVar10 * 4));
                uStack_14 = 0x26;
                FUN_00a25200(param_1,&iStack_6c);
                uStack_14 = 0xffffffff;
                FUN_00617bc0();
                uVar10 = uVar10 + 1;
              } while (uVar10 < (uint)(param_3[1] - *param_3 >> 2));
              ExceptionList = pvStack_1c;
              return;
            }
            iVar5 = param_2[10];
            iVar4 = FUN_00b33310();
            if (iVar5 == iVar4) {
              auStack_21[0] = 0x17;
              FUN_00a25190(auStack_21,1);
              uVar10 = 0;
              if (param_3[1] - *param_3 >> 2 == 0) {
                ExceptionList = pvStack_1c;
                return;
              }
              do {
                (**(code **)(*(int *)param_2[0xd] + 0xc))
                          ((int)&uStack_40 + 4,*(undefined4 *)(*param_3 + uVar10 * 4));
                FUN_00a25190((int)&uStack_40 + 4,8);
                uVar10 = uVar10 + 1;
              } while (uVar10 < (uint)(param_3[1] - *param_3 >> 2));
              ExceptionList = pvStack_1c;
              return;
            }
            iVar5 = param_2[10];
            iVar4 = FUN_0088d4b0();
            if (iVar5 != iVar4) {
              uVar6 = FUN_005543f0();
              FUN_016756b0(auStack_64 + 1,"Unknown property type for property %s",uVar6);
                    /* WARNING: Subroutine does not return */
              FUN_0170c2a8(auStack_64 + 1,&DAT_01c17198);
            }
            auStack_21[0] = 0x1c;
            FUN_00a25190(auStack_21,1);
            iStack_6c = 0;
            iStack_68 = 0;
            auStack_64[0] = 0;
            uStack_14 = 0x27;
            FUN_007d3f90(param_3[1] - *param_3 >> 2);
            uVar10 = 0;
            iVar5 = *param_3;
            if (param_3[1] - iVar5 >> 2 != 0) {
              do {
                uVar6 = FUN_00a1d9f0(&pfStack_28,param_2,*(undefined4 *)(iVar5 + uVar10 * 4));
                uStack_14._0_1_ = 0x28;
                FUN_00a21f20(&pfStack_48,uVar6);
                uStack_14 = CONCAT31(uStack_14._1_3_,0x27);
                FUN_0056cd30();
                if (pfStack_48 == (float *)0x0) {
                    /* WARNING: Subroutine does not return */
                  FUN_016757c0("SharedString value not in dictionary");
                }
                FUN_006dd570(pfStack_48 + 3);
                uVar10 = uVar10 + 1;
                iVar5 = *param_3;
              } while (uVar10 < (uint)(param_3[1] - iVar5 >> 2));
            }
            goto LAB_00a2736d;
          }
          iStack_6c = 0;
          iStack_68 = 0;
          auStack_64[0] = 0;
          uStack_14 = 0x23;
          FUN_007d3f90(param_3[1] - *param_3 >> 2);
          pfStack_28 = (float *)0x0;
          if (param_3[1] - *param_3 >> 2 != 0) {
            do {
              uVar6 = (**(code **)(*param_2 + 0x44))
                                (*(undefined4 *)(*param_3 + (int)pfStack_28 * 4));
              pfStack_48 = (float *)FUN_00a21f70(param_4,uVar6);
              FUN_00646760(&pfStack_48);
              pfStack_28 = (float *)((int)pfStack_28 + 1);
            } while (pfStack_28 < (float *)(param_3[1] - *param_3 >> 2));
          }
          auStack_21[0] = 0x13;
          FUN_00a25190(auStack_21,1);
          FUN_00a25380(param_1,&iStack_6c);
        }
        FUN_0056d320();
      }
    }
  }
  else {
    auStack_21[0] = 0x1d;
    FUN_00a25190(auStack_21,1);
    pfStack_48 = (float *)0x0;
    iVar5 = *param_3;
    uVar10 = 0;
    if (param_3[1] - iVar5 >> 2 != 0) {
      do {
        bVar1 = true;
        if (param_2 == &DAT_01ee5728) {
          pfStack_28 = *(float **)(iVar5 + (int)pfStack_48 * 4);
          if (((pfStack_28 == (float *)0x0) ||
              (fVar14 = pfStack_28[3], iVar5 = FUN_009ec190(),
              (uint)*(ushort *)(iVar5 + 0x1da) <
              (uint)*(ushort *)((int)fVar14 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) ||
             (*(char *)((int)pfStack_28 + 0xee) == '\0')) {
            bVar1 = true;
          }
          else {
            bVar1 = false;
          }
        }
        if (bVar1) {
          (**(code **)(*(int *)param_2[0xd] + 0xc))
                    ((int)&uStack_40 + 4,*(undefined4 *)(*param_3 + (int)pfStack_48 * 4));
          uStack_7c = uVar10 | 0x61;
          uStack_14 = 0;
          uVar6 = FUN_00a33fa0();
          pfVar7 = (float *)FUN_0054ef60(uVar6);
          pfStack_28 = pfVar7;
          uStack_14 = 1;
          uStack_44 = uVar10 | 99;
          uStack_7c = uVar10 | 99;
        }
        else {
          pfStack_84 = (float *)0x0;
          pfStack_80 = (float *)0xf;
          fStack_94 = (float)((uint)fStack_94 & 0xffffff00);
          FUN_005542c0(&DAT_018bc9b8,0);
          uStack_14 = 2;
          pfVar7 = &fStack_94;
          uStack_44 = uVar10 | 4;
          uStack_7c = uVar10 | 4;
        }
        pfStack_28 = (float *)pfVar7[4];
        uStack_7c = uStack_44;
        FUN_00a25190(&pfStack_28,4);
        if (0xf < (uint)pfVar7[5]) {
          pfVar7 = (float *)*pfVar7;
        }
        FUN_00a25190(pfVar7,pfStack_28);
        uStack_14 = 1;
        if (((uStack_44 & 4) != 0) &&
           (uStack_7c = uStack_44 & 0xfffffffb, uStack_44 = uStack_7c, (float *)0xf < pfStack_80)) {
          pfVar7 = (float *)((int)pfStack_80 + 1);
          fVar14 = fStack_94;
          if ((float *)0xfff < pfVar7) {
            fVar14 = *(float *)((int)fStack_94 - 4);
            pfVar7 = pfStack_80 + 9;
            if (0x1f < ((int)fStack_94 - (int)fVar14) - 4U) goto LAB_00a27551;
          }
          FUN_01674ea0(fVar14,pfVar7);
        }
        uStack_14 = 0;
        if ((uStack_44 & 2) != 0) {
          uStack_7c = uStack_44 & 0xfffffffd;
          uStack_44 = uStack_7c;
          if (0xf < auStack_64[0]) {
            uVar9 = auStack_64[0] + 1;
            uVar10 = auStack_78[0];
            if (0xfff < uVar9) {
              uVar10 = *(uint *)(auStack_78[0] - 4);
              uVar9 = auStack_64[0] + 0x24;
              if (0x1f < (auStack_78[0] - uVar10) - 4) {
LAB_00a27551:
                uStack_7c = uStack_44;
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(uVar10,uVar9);
          }
          iStack_68 = 0;
          auStack_64[0] = 0xf;
          auStack_78[0] = auStack_78[0] & 0xffffff00;
        }
        uStack_14 = 0xffffffff;
        if ((uStack_44 & 1) != 0) {
          uStack_7c = uStack_44 & 0xfffffffe;
          uStack_44 = uStack_7c;
          FUN_0056cd30();
          FUN_0056cd30();
        }
        pfStack_48 = (float *)((int)pfStack_48 + 1);
        iVar5 = *param_3;
        uVar10 = uStack_44;
      } while (pfStack_48 < (float *)(param_3[1] - iVar5 >> 2));
    }
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 20129 ; VA 0x00a27590 ; FUN_00a27590 */

void FUN_00a27590(int param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint *puVar5;
  uint uVar6;
  uint *puVar7;
  uint *puVar8;
  uint uStack_8;
  
  uStack_8 = (int)(param_2[5] - param_2[4]) / 0x30;
  FUN_00a25190(&uStack_8,4);
  puVar1 = (uint *)param_2[5];
  puVar8 = (uint *)param_2[4];
  if (puVar8 != puVar1) {
    puVar7 = puVar8 + 9;
    do {
      uVar2 = *puVar8;
      if (0 < (int)uVar2) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Unsupported signature type %u",uVar2);
      }
      uStack_8 = uVar2;
      FUN_00a25190(&uStack_8,4);
      FUN_00a25190(puVar7 + -7,8);
      uStack_8 = puVar7[-1];
      FUN_00a25190(&uStack_8,4);
      puVar5 = puVar7 + -5;
      if (0xf < *puVar7) {
        puVar5 = (uint *)*puVar5;
      }
      FUN_00a25190(puVar5,uStack_8);
      uVar2 = *(uint *)(param_1 + 4);
      uVar6 = uVar2 - puVar7[-1];
      uVar3 = *param_2;
      uVar4 = param_2[1];
      puVar8 = puVar8 + 0xc;
      puVar7[1] = uVar6 + *param_2;
      puVar7[2] = (uVar4 - (uVar2 < puVar7[-1])) + (uint)CARRY4(uVar6,uVar3);
      puVar7 = puVar7 + 0xc;
    } while (puVar8 != puVar1);
  }
  return;
}



/* FUNCTION 20130 ; VA 0x00a27660 ; FUN_00a27660 */

void FUN_00a27660(undefined4 param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = param_2;
  param_2 = (undefined4 *)param_2[4];
  FUN_00a25190(&param_2,4);
  if (0xf < (uint)puVar1[5]) {
    puVar1 = (undefined4 *)*puVar1;
  }
  FUN_00a25190(puVar1,param_2);
  return;
}



/* FUNCTION 20131 ; VA 0x00a276a0 ; FUN_00a276a0 */

void FUN_00a276a0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  piVar1 = param_2;
  uVar4 = 0;
  iVar2 = param_2[1];
  iVar3 = *param_2;
  if (iVar2 - iVar3 >> 2 != 0) {
    do {
      param_2 = (int *)CONCAT13(*(undefined *)(*piVar1 + 3 + uVar4 * 4),param_2._0_3_);
      FUN_00a25190((int)&param_2 + 3,1);
      iVar2 = piVar1[1];
      uVar4 = uVar4 + 1;
      iVar3 = *piVar1;
    } while (uVar4 < (uint)(iVar2 - iVar3 >> 2));
  }
  uVar4 = 0;
  if (iVar2 - iVar3 >> 2 != 0) {
    do {
      param_2 = (int *)CONCAT13(*(undefined *)(*piVar1 + 2 + uVar4 * 4),param_2._0_3_);
      FUN_00a25190((int)&param_2 + 3,1);
      iVar2 = piVar1[1];
      uVar4 = uVar4 + 1;
      iVar3 = *piVar1;
    } while (uVar4 < (uint)(iVar2 - iVar3 >> 2));
  }
  uVar4 = 0;
  if (iVar2 - iVar3 >> 2 != 0) {
    do {
      param_2 = (int *)CONCAT13((char)((uint)*(undefined4 *)(*piVar1 + uVar4 * 4) >> 8),
                                param_2._0_3_);
      FUN_00a25190((int)&param_2 + 3,1);
      iVar2 = piVar1[1];
      uVar4 = uVar4 + 1;
      iVar3 = *piVar1;
    } while (uVar4 < (uint)(iVar2 - iVar3 >> 2));
  }
  uVar4 = 0;
  if (iVar2 - iVar3 >> 2 != 0) {
    do {
      param_2 = (int *)CONCAT13(*(undefined *)(*piVar1 + uVar4 * 4),param_2._0_3_);
      FUN_00a25190((int)&param_2 + 3,1);
      uVar4 = uVar4 + 1;
    } while (uVar4 < (uint)(piVar1[1] - *piVar1 >> 2));
  }
  return;
}



/* FUNCTION 20132 ; VA 0x00a27790 ; FUN_00a27790 */

undefined4 FUN_00a27790(undefined4 param_1,int param_2,int param_3,char param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined auStack_1f0 [120];
  undefined auStack_178 [120];
  undefined auStack_100 [24];
  undefined auStack_e8 [24];
  undefined auStack_d0 [24];
  undefined auStack_b8 [24];
  undefined auStack_a0 [24];
  undefined auStack_88 [24];
  undefined auStack_70 [24];
  undefined auStack_58 [24];
  undefined auStack_40 [24];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dc404;
  pvStack_10 = ExceptionList;
  if (param_2 == 0 && param_3 == 0) {
    if (param_4 == '\0') {
      ExceptionList = &pvStack_10;
      FUN_0054eff0(&DAT_018bc9b8);
      uStack_8 = 0x12;
      FUN_0054eff0(&DAT_018bc9b8);
      uStack_8._0_1_ = 0x13;
      FUN_0054eff0("/publish/v1/Scripts");
      uStack_8._0_1_ = 0x14;
      uVar1 = FUN_0151ec70(auStack_100);
      uStack_8._0_1_ = 0x15;
      FUN_0054eff0("https");
      uStack_8._0_1_ = 0x16;
      FUN_0151bcc0(auStack_1f0,auStack_a0,uVar1,auStack_b8,auStack_d0,auStack_e8);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x17);
      FUN_0151bb70(param_1);
      FUN_0056d9d0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
    }
    else {
      ExceptionList = &pvStack_10;
      FUN_0054eff0(&DAT_018bc9b8);
      uStack_8 = 0xc;
      FUN_0054eff0(&DAT_018bc9b8);
      uStack_8._0_1_ = 0xd;
      FUN_0054eff0("/publish/v1/rcc/Scripts");
      uStack_8._0_1_ = 0xe;
      uVar1 = FUN_0151ec70(auStack_88);
      uStack_8._0_1_ = 0xf;
      FUN_0054eff0("https");
      uStack_8._0_1_ = 0x10;
      FUN_0151bcc0(auStack_178,auStack_58,uVar1,auStack_40,auStack_28,auStack_70);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
      FUN_0151bb70(param_1);
      FUN_0056d9d0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
    }
  }
  else if (param_4 == '\0') {
    ExceptionList = &pvStack_10;
    FUN_0054eff0(&DAT_018bc9b8);
    uStack_8 = 6;
    FUN_0054eff0(&DAT_018bc9b8);
    uStack_8._0_1_ = 7;
    uVar1 = FUN_01675640(auStack_70,"/publish/v1/Scripts/%lld",param_2,param_3);
    uStack_8._0_1_ = 8;
    uVar2 = FUN_0151ec70(auStack_88);
    uStack_8._0_1_ = 9;
    FUN_0054eff0("https");
    uStack_8._0_1_ = 10;
    FUN_0151bcc0(auStack_178,auStack_58,uVar2,uVar1,auStack_40,auStack_28);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    FUN_0151bb70(param_1);
    FUN_0056d9d0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_0054eff0(&DAT_018bc9b8);
    uStack_8 = 0;
    FUN_0054eff0(&DAT_018bc9b8);
    uStack_8._0_1_ = 1;
    uVar1 = FUN_01675640(auStack_88,"/publish/v1/rcc/Scripts/%lld",param_2,param_3);
    uStack_8._0_1_ = 2;
    uVar2 = FUN_0151ec70(auStack_70);
    uStack_8._0_1_ = 3;
    FUN_0054eff0("https");
    uStack_8._0_1_ = 4;
    FUN_0151bcc0(auStack_178,auStack_28,uVar2,uVar1,auStack_40,auStack_58);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_0151bb70(param_1);
    FUN_0056d9d0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
  }
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20133 ; VA 0x00a27b10 ; FUN_00a27b10 */

undefined4 FUN_00a27b10(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  undefined auStack_100 [120];
  int aiStack_88 [5];
  uint uStack_74;
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dc446;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054eff0(&DAT_018bc9b8);
  uStack_8 = 0;
  FUN_0054eff0(&DAT_018bc9b8);
  uStack_8._0_1_ = 1;
  uVar1 = FUN_01675640(auStack_70,"/publish/v1/rcc/Places/%lld",param_2,param_3);
  uStack_8._0_1_ = 2;
  uVar2 = FUN_0151ec70(auStack_58);
  uStack_8._0_1_ = 3;
  FUN_0054eff0("https");
  uStack_8._0_1_ = 4;
  FUN_0151bcc0(auStack_100,auStack_28,uVar2,uVar1,auStack_40,aiStack_88);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_0151bb70(param_1);
  FUN_0056d9d0();
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    uVar5 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar5 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar4);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (0xf < uStack_44) {
    uVar4 = uStack_44 + 1;
    uVar5 = auStack_58[0];
    if (0xfff < uVar4) {
      uVar5 = *(uint *)(auStack_58[0] - 4);
      uVar4 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar4);
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  if (0xf < uStack_5c) {
    uVar4 = uStack_5c + 1;
    uVar5 = auStack_70[0];
    if (0xfff < uVar4) {
      uVar5 = *(uint *)(auStack_70[0] - 4);
      uVar4 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar4);
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    uVar5 = auStack_40[0];
    if (0xfff < uVar4) {
      uVar5 = *(uint *)(auStack_40[0] - 4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar4);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  if (0xf < uStack_74) {
    uVar5 = uStack_74 + 1;
    iVar3 = aiStack_88[0];
    if (0xfff < uVar5) {
      iVar3 = *(int *)(aiStack_88[0] + -4);
      uVar5 = uStack_74 + 0x24;
      if (0x1f < (aiStack_88[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20134 ; VA 0x00a27d50 ; FUN_00a27d50 */

undefined4 * __fastcall FUN_00a27d50(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dc489;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[1] = 1;
  param_1[2] = 1;
  *param_1 = std::_Ref_count_obj<class_RBX::PackageAssetModel>::vftable;
  FUN_0170d1f0(param_1 + 4,0,0x40);
  iVar1 = CreateSemaphoreA(0,0,0x7fffffff,0);
  if (iVar1 == 0) {
    uVar2 = FUN_005503c0();
    uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
    FUN_0054e630(uVar2);
  }
  param_1[5] = iVar1;
  iVar1 = CreateSemaphoreA(0,0,0x7fffffff,0);
  param_1[6] = iVar1;
  if (iVar1 != 0) {
    iVar1 = CreateSemaphoreA(0,0,0x7fffffff,0);
    param_1[7] = iVar1;
    if (iVar1 != 0) {
      param_1[4] = 0;
      uStack_8 = 3;
      param_1[8] = 0;
      param_1[9] = 0;
      uVar2 = FUN_005535a0();
      param_1[8] = uVar2;
      param_1[10] = 0;
      param_1[0xb] = 0;
      param_1[0xc] = 0;
      param_1[0xd] = 0;
      param_1[0xe] = 0;
      param_1[0xf] = 0;
      param_1[0x10] = 0;
      param_1[0x11] = 0;
      *(undefined8 *)(param_1 + 0x12) = 0;
      param_1[10] = 0;
      param_1[0xb] = 0;
      *(undefined *)(param_1 + 0xc) = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      param_1[0xd] = 0;
      param_1[0xe] = 0;
      uVar2 = FUN_00575ab0();
      param_1[0xd] = uVar2;
      param_1[0x10] = 0xffffffff;
      param_1[0x11] = 0xffffffff;
      param_1[0x12] = 0;
      param_1[0x13] = 0;
      ExceptionList = pvStack_10;
      return param_1;
    }
    FUN_006ddd60(param_1[5],0x7fffffff);
    FUN_006ddd60(param_1[6],0x7fffffff);
    uVar2 = FUN_005503c0();
    uStack_8 = 2;
                    /* WARNING: Subroutine does not return */
    FUN_0054e630(uVar2);
  }
  FUN_006ddd60(param_1[5],0x7fffffff);
  uVar2 = FUN_005503c0();
  uStack_8 = 1;
                    /* WARNING: Subroutine does not return */
  FUN_0054e630(uVar2);
}



/* FUNCTION 20135 ; VA 0x00a27f00 ; FUN_00a27f00 */

int * __thiscall FUN_00a27f00(int *param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017924f3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  param_1[1] = 0;
  uStack_8 = 0;
  piVar3 = (int *)FUN_00a28020(param_2);
  iVar1 = param_1[1];
  param_1[1] = *piVar3;
  *piVar3 = iVar1;
  uStack_8._0_1_ = 1;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_14[1] + -1;
    piStack_14[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*piStack_14 + 4))();
      LOCK();
      iVar1 = piStack_14[2] + -1;
      piStack_14[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piStack_14 + 8))();
      }
    }
  }
  piVar3 = (int *)(-(uint)(param_2 != 0) & param_2 + 8U);
  if ((piVar3 != (int *)0x0) && ((piVar3[1] == 0 || (*(int *)(piVar3[1] + 4) == 0)))) {
    piVar2 = (int *)param_1[1];
    if (piVar2 != (int *)0x0) {
      LOCK();
      piVar2[1] = piVar2[1] + 1;
      UNLOCK();
    }
    *piVar3 = param_2;
    piVar4 = (int *)piVar3[1];
    uStack_8._0_1_ = 2;
    if (piVar2 != piVar4) {
      if (piVar2 != (int *)0x0) {
        LOCK();
        piVar2[2] = piVar2[2] + 1;
        UNLOCK();
        piVar4 = (int *)piVar3[1];
      }
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar1 = piVar4[2] + -1;
        piVar4[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar4 + 8))();
        }
      }
      piVar3[1] = (int)piVar2;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = piVar2[1] + -1;
      piVar2[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar2 + 4))();
        LOCK();
        piVar3 = piVar2 + 2;
        iVar1 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piVar2 + 8))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20136 ; VA 0x00a28020 ; FUN_00a28020 */

undefined4 * __thiscall FUN_00a28020(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dc4a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = boost::detail::
              sp_counted_impl_p<struct_boost::detail::shared_state<class_std::shared_ptr<class_RBX::HttpResponse>_>_>
              ::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = puVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20137 ; VA 0x00a28095 ; Catch_All@00a28095 */

void Catch_All_00a28095(void)

{
  int unaff_EBP;
  
  FUN_0055d6f0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20138 ; VA 0x00a280b0 ; FUN_00a280b0 */

undefined4 * __thiscall FUN_00a280b0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  uint in_stack_0000001c;
  undefined auStack_84 [4];
  int *piStack_80;
  uint uStack_6c;
  undefined auStack_64 [24];
  undefined auStack_4c [4];
  int *piStack_48;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dc4c8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00a29d80(&param_2);
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_00a29d80(auStack_84);
  uStack_8._0_1_ = 2;
  FUN_00a29d80(auStack_4c);
  ppuVar4 = &PTR_FUN_0194134c;
  cVar3 = FUN_00a28ba0();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
    }
    uStack_34 = 0;
  }
  if (piStack_48 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_48[2] + -1;
    piStack_48[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_48 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_6c != 0) {
    if (((uStack_6c & 1) == 0) && (*(code **)(uStack_6c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_6c & 0xfffffffe))(auStack_64,auStack_64,2);
    }
    uStack_6c = 0;
  }
  if (piStack_80 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_80[2] + -1;
    piStack_80[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_80 + 4))();
    }
  }
  uStack_8 = 5;
  if (in_stack_0000001c != 0) {
    if (((in_stack_0000001c & 1) == 0) &&
       (*(code **)(in_stack_0000001c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000001c & 0xfffffffe))(&stack0x00000024,&stack0x00000024,2);
    }
    in_stack_0000001c = 0;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20139 ; VA 0x00a28200 ; FUN_00a28200 */

undefined4 * __thiscall
FUN_00a28200(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,int param_6)

{
  char cVar1;
  int iVar2;
  undefined **ppuVar3;
  uint in_stack_00000028;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_78;
  int iStack_74;
  int *piStack_70;
  int aiStack_54 [5];
  uint uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dc4f8;
  pvStack_10 = ExceptionList;
  piStack_70 = &param_6;
  uStack_8 = 0;
  iStack_74 = 0xa2824d;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60();
  uStack_3c = param_2;
  uStack_38 = param_3;
  uStack_34 = param_4;
  uStack_30 = param_5;
  piStack_70 = aiStack_54;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  iStack_74 = 0xa2827b;
  FUN_0054ef60();
  piStack_70 = param_1 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_14 = &uStack_98;
  uStack_98 = uStack_3c;
  uStack_94 = uStack_38;
  uStack_90 = uStack_34;
  uStack_8c = uStack_30;
  FUN_0054ef60(aiStack_2c);
  ppuVar3 = &PTR_FUN_019412c0;
  cVar1 = FUN_00a28d50();
  if (cVar1 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  if (0xf < uStack_18) {
    piStack_70 = (int *)(uStack_18 + 1);
    iVar2 = aiStack_2c[0];
    if (0xfff < piStack_70) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      piStack_70 = (int *)(uStack_18 + 0x24);
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_70 = (int *)0xa2836c;
        FUN_017167a3();
      }
    }
    uStack_78 = 0xa282f0;
    iStack_74 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < uStack_40) {
    piStack_70 = (int *)(uStack_40 + 1);
    iVar2 = aiStack_54[0];
    if (0xfff < piStack_70) {
      iVar2 = *(int *)(aiStack_54[0] + -4);
      piStack_70 = (int *)(uStack_40 + 0x24);
      if (0x1f < (aiStack_54[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_70 = (int *)0xa28371;
        FUN_017167a3();
      }
    }
    uStack_78 = 0xa28320;
    iStack_74 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000028) {
    piStack_70 = (int *)(in_stack_00000028 + 1);
    iVar2 = param_6;
    if (0xfff < piStack_70) {
      iVar2 = *(int *)(param_6 + -4);
      piStack_70 = (int *)(in_stack_00000028 + 0x24);
      if (0x1f < (param_6 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_70 = (int *)&UNK_00a28376;
        FUN_017167a3();
      }
    }
    uStack_78 = 0xa28350;
    iStack_74 = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20140 ; VA 0x00a28380 ; FUN_00a28380 */

undefined4 * __thiscall FUN_00a28380(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  uint in_stack_0000001c;
  undefined auStack_84 [4];
  int *piStack_80;
  uint uStack_6c;
  undefined auStack_64 [24];
  undefined auStack_4c [4];
  int *piStack_48;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dc528;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00a29d80(&param_2);
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_00a29d80(auStack_84);
  uStack_8._0_1_ = 2;
  FUN_00a29d80(auStack_4c);
  ppuVar4 = &PTR_FUN_01941344;
  cVar3 = FUN_00a28f30();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
    }
    uStack_34 = 0;
  }
  if (piStack_48 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_48[2] + -1;
    piStack_48[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_48 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_6c != 0) {
    if (((uStack_6c & 1) == 0) && (*(code **)(uStack_6c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_6c & 0xfffffffe))(auStack_64,auStack_64,2);
    }
    uStack_6c = 0;
  }
  if (piStack_80 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_80[2] + -1;
    piStack_80[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_80 + 4))();
    }
  }
  uStack_8 = 5;
  if (in_stack_0000001c != 0) {
    if (((in_stack_0000001c & 1) == 0) &&
       (*(code **)(in_stack_0000001c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000001c & 0xfffffffe))(&stack0x00000024,&stack0x00000024,2);
    }
    in_stack_0000001c = 0;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20141 ; VA 0x00a284d0 ; FUN_00a284d0 */

undefined4 * __thiscall FUN_00a284d0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined4 extraout_ECX;
  undefined **ppuVar5;
  int *in_stack_00000020;
  int *piStack_50;
  int *piStack_38;
  undefined auStack_34 [4];
  int *piStack_30;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dc558;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00a29e50(&param_2);
  *param_1 = 0;
  FUN_00a29e50(extraout_ECX);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00a29e50(auStack_34);
  ppuVar5 = &PTR_FUN_01941304;
  cVar4 = FUN_00a29320();
  if (cVar4 == '\0') {
    ppuVar5 = (undefined **)0x0;
  }
  *param_1 = ppuVar5;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_30[2] + -1;
    piStack_30[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piStack_30 + 4))();
    }
  }
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_38[1] + -1;
    piStack_38[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_38)();
      LOCK();
      iVar3 = piStack_38[2] + -1;
      piStack_38[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
  }
  if (piStack_50 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_50[2] + -1;
    piStack_50[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piStack_50 + 4))();
    }
  }
  piVar2 = in_stack_00000020;
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    iVar3 = in_stack_00000020[1] + -1;
    in_stack_00000020[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 2;
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20142 ; VA 0x00a28610 ; FUN_00a28610 */

undefined4 * __thiscall
FUN_00a28610(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  FUN_00a29600(param_2,param_3,param_4,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 20143 ; VA 0x00a28710 ; FUN_00a28710 */

undefined * FUN_00a28710(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dc57c;
  pvStack_10 = ExceptionList;
  if (DAT_01ee6ea4 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee70b0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee70b0);
      if (DAT_01ee70b0 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"PackageService",1,uStack_20,0,0,1,0,0);
        FUN_016f3654(&LAB_018897f0);
        FUN_016f37bf(&DAT_01ee70b0);
      }
    }
    DAT_01ee6ea4 = &DAT_01ee6ea8;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee6ea4;
}



/* FUNCTION 20144 ; VA 0x00a287f0 ; FUN_00a287f0 */

void FUN_00a287f0(void)

{
  int iVar1;
  
  if (DAT_01ee70b4 == 0) {
    iVar1 = FUN_00a28710();
    DAT_01ee70b4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 20145 ; VA 0x00a28810 ; FUN_00a28810 */

int __thiscall FUN_00a28810(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dc590;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::PackageLink*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20146 ; VA 0x00a288e2 ; Catch_All@00a288e2 */

void Catch_All_00a288e2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20147 ; VA 0x00a28900 ; FUN_00a28900 */

void __thiscall
FUN_00a28900(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_c = param_6;
  uStack_10 = param_7;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_28 = param_3;
  uStack_1c = param_6;
  uStack_18 = param_7;
  uStack_2c = param_2;
  uStack_24 = param_4;
  uStack_20 = param_5;
  cVar3 = FUN_00585a40(&uStack_2c);
  if (cVar3 == '\0') {
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[2] = piStack_28[2] + 1;
      UNLOCK();
    }
    uStack_10 = uStack_20;
    uStack_c = uStack_1c;
    uStack_14 = uStack_18;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[2] = piStack_28[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_2c;
    param_1[3] = piStack_28;
    param_1[5] = uStack_20;
    param_1[4] = uStack_24;
    param_1[6] = uStack_1c;
    param_1[7] = uStack_18;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_28[2] + -1;
      piStack_28[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_28[2] + -1;
      piStack_28[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_28[2] + -1;
      piStack_28[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_019412b0;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 20148 ; VA 0x00a28a50 ; FUN_00a28a50 */

void __thiscall
FUN_00a28a50(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_c = param_6;
  uStack_10 = param_7;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_28 = param_3;
  uStack_1c = param_6;
  uStack_18 = param_7;
  uStack_2c = param_2;
  uStack_24 = param_4;
  uStack_20 = param_5;
  cVar3 = FUN_00585a40(&uStack_2c);
  if (cVar3 == '\0') {
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[2] = piStack_28[2] + 1;
      UNLOCK();
    }
    uStack_10 = uStack_20;
    uStack_c = uStack_1c;
    uStack_14 = uStack_18;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[2] = piStack_28[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_2c;
    param_1[3] = piStack_28;
    param_1[5] = uStack_20;
    param_1[4] = uStack_24;
    param_1[6] = uStack_1c;
    param_1[7] = uStack_18;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_28[2] + -1;
      piStack_28[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_28[2] + -1;
      piStack_28[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_28[2] + -1;
      piStack_28[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_019412b8;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 20149 ; VA 0x00a28ba0 ; FUN_00a28ba0 */

undefined FUN_00a28ba0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined uVar5;
  uint in_stack_0000001c;
  undefined4 *in_stack_0000003c;
  undefined auStack_84 [4];
  int *piStack_80;
  uint uStack_6c;
  undefined auStack_64 [24];
  undefined auStack_4c [4];
  int *piStack_48;
  uint uStack_34;
  undefined auStack_2c [24];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dc5c7;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a29d80(&param_1);
  uStack_8._0_1_ = 1;
  cVar3 = FUN_00585a40(auStack_4c);
  if (cVar3 == '\0') {
    FUN_00a29d80(auStack_4c);
    uStack_8._0_1_ = 2;
    iStack_14 = FUN_01674e20(0x38);
    uStack_8._0_1_ = 3;
    if (iStack_14 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_00a29d80(auStack_84);
    }
    *in_stack_0000003c = uVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (uStack_6c != 0) {
      if (((uStack_6c & 1) == 0) && (*(code **)(uStack_6c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_6c & 0xfffffffe))(auStack_64,auStack_64,2);
      }
      uStack_6c = 0;
    }
    if (piStack_80 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_80[2] + -1;
      piStack_80[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_80 + 4))();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    if (piStack_48 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_48[2] + -1;
      piStack_48[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_48 + 4))();
      }
    }
    uVar5 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    if (piStack_48 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_48[2] + -1;
      piStack_48[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_48 + 4))();
      }
    }
    uVar5 = 0;
  }
  uStack_8 = 7;
  if (in_stack_0000001c != 0) {
    if (((in_stack_0000001c & 1) == 0) &&
       (*(code **)(in_stack_0000001c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000001c & 0xfffffffe))(&stack0x00000024,&stack0x00000024,2);
    }
    in_stack_0000001c = 0;
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 20150 ; VA 0x00a28d50 ; FUN_00a28d50 */

undefined FUN_00a28d50(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                      int param_5)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  undefined4 *puVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  undefined uVar10;
  uint in_stack_00000028;
  int *in_stack_0000002c;
  int aiStack_54 [5];
  uint uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dc607;
  pvStack_10 = ExceptionList;
  uStack_3c = param_1;
  uStack_38 = param_2;
  uStack_34 = param_3;
  uStack_30 = param_4;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_5);
  uStack_8._0_1_ = 1;
  cVar5 = FUN_00585a40(&uStack_3c);
  uVar4 = uStack_30;
  uVar3 = uStack_34;
  uVar2 = uStack_38;
  uVar1 = uStack_3c;
  if (cVar5 == '\0') {
    FUN_0054ef60(auStack_2c);
    uStack_8._0_1_ = 2;
    puVar6 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar6;
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      puVar6[2] = uVar3;
      *puVar6 = uVar1;
      puVar6[3] = uVar4;
      puVar6[1] = uVar2;
      FUN_0054ef60(aiStack_54);
    }
    *in_stack_0000002c = (int)puVar6;
    if (0xf < uStack_40) {
      uVar8 = uStack_40 + 1;
      iVar7 = aiStack_54[0];
      if (0xfff < uVar8) {
        iVar7 = *(int *)(aiStack_54[0] + -4);
        uVar8 = uStack_40 + 0x24;
        if (0x1f < (aiStack_54[0] - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar7,uVar8);
    }
    if (0xf < uStack_18) {
      uVar9 = uStack_18 + 1;
      uVar8 = auStack_2c[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_2c[0] - 4);
        uVar9 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uVar10 = 1;
  }
  else {
    if (0xf < uStack_18) {
      uVar9 = uStack_18 + 1;
      uVar8 = auStack_2c[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_2c[0] - 4);
        uVar9 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uVar10 = 0;
  }
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_18 = 0xf;
  uStack_1c = 0;
  if (0xf < in_stack_00000028) {
    uVar8 = in_stack_00000028 + 1;
    iVar7 = param_5;
    if (0xfff < uVar8) {
      iVar7 = *(int *)(param_5 + -4);
      uVar8 = in_stack_00000028 + 0x24;
      if (0x1f < (param_5 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar8);
  }
  ExceptionList = pvStack_10;
  return uVar10;
}



/* FUNCTION 20151 ; VA 0x00a28f30 ; FUN_00a28f30 */

undefined FUN_00a28f30(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined uVar5;
  uint in_stack_0000001c;
  undefined4 *in_stack_0000003c;
  undefined auStack_84 [4];
  int *piStack_80;
  uint uStack_6c;
  undefined auStack_64 [24];
  undefined auStack_4c [4];
  int *piStack_48;
  uint uStack_34;
  undefined auStack_2c [24];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dc647;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a29d80(&param_1);
  uStack_8._0_1_ = 1;
  cVar3 = FUN_00585a40(auStack_4c);
  if (cVar3 == '\0') {
    FUN_00a29d80(auStack_4c);
    uStack_8._0_1_ = 2;
    iStack_14 = FUN_01674e20(0x38);
    uStack_8._0_1_ = 3;
    if (iStack_14 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_00a29d80(auStack_84);
    }
    *in_stack_0000003c = uVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (uStack_6c != 0) {
      if (((uStack_6c & 1) == 0) && (*(code **)(uStack_6c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_6c & 0xfffffffe))(auStack_64,auStack_64,2);
      }
      uStack_6c = 0;
    }
    if (piStack_80 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_80[2] + -1;
      piStack_80[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_80 + 4))();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    if (piStack_48 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_48[2] + -1;
      piStack_48[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_48 + 4))();
      }
    }
    uVar5 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    if (piStack_48 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_48[2] + -1;
      piStack_48[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_48 + 4))();
      }
    }
    uVar5 = 0;
  }
  uStack_8 = 7;
  if (in_stack_0000001c != 0) {
    if (((in_stack_0000001c & 1) == 0) &&
       (*(code **)(in_stack_0000001c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000001c & 0xfffffffe))(&stack0x00000024,&stack0x00000024,2);
    }
    in_stack_0000001c = 0;
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 20152 ; VA 0x00a290e0 ; FUN_00a290e0 */

void __thiscall
FUN_00a290e0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  char cStack_5;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  uStack_18 = param_2;
  uStack_14 = param_3;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  piStack_c = param_5;
  uStack_10 = param_4;
  cVar3 = FUN_00585a40(&uStack_18);
  if (cVar3 == '\0') {
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[2] = piStack_c[2] + 1;
      UNLOCK();
    }
    param_1[3] = uStack_14;
    param_1[2] = uStack_18;
    param_1[4] = 0;
    param_1[5] = 0;
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[2] = piStack_c[2] + 1;
      UNLOCK();
    }
    param_1[4] = uStack_10;
    param_1[5] = piStack_c;
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_019412a8;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_5 + 4))();
    }
  }
  return;
}



/* FUNCTION 20153 ; VA 0x00a29200 ; FUN_00a29200 */

void __thiscall
FUN_00a29200(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_18 = param_3;
  uStack_1c = param_2;
  uStack_14 = param_4;
  uStack_10 = param_5;
  cVar3 = FUN_00585a40(&uStack_1c);
  if (cVar3 == '\0') {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_10;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_1c;
    param_1[3] = piStack_18;
    param_1[4] = uStack_14;
    param_1[5] = uStack_10;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01941324;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 20154 ; VA 0x00a29320 ; FUN_00a29320 */

undefined FUN_00a29320(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 extraout_ECX;
  undefined uVar6;
  int *in_stack_00000020;
  undefined4 *in_stack_00000024;
  undefined auStack_50 [4];
  int *piStack_4c;
  int *piStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dc678;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a29e50(&param_1);
  uStack_8._0_1_ = 1;
  cVar3 = FUN_00585a40(extraout_ECX);
  if (cVar3 == '\0') {
    FUN_00a29e50(auStack_30);
    uStack_8._0_1_ = 2;
    iVar4 = FUN_01674e20(0x20);
    if (iVar4 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_00a29e50(auStack_50);
    }
    *in_stack_00000024 = uVar5;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_34[1] + -1;
      piStack_34[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        iVar4 = piStack_34[2] + -1;
        piStack_34[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_34 + 4))();
        }
      }
    }
    if (piStack_4c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_4c[2] + -1;
      piStack_4c[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_4c + 4))();
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_14[1] + -1;
      piStack_14[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        iVar4 = piStack_14[2] + -1;
        piStack_14[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
    uVar6 = 1;
  }
  else {
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_14[1] + -1;
      piStack_14[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        iVar4 = piStack_14[2] + -1;
        piStack_14[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
    uVar6 = 0;
  }
  piVar2 = in_stack_00000020;
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    iVar4 = in_stack_00000020[1] + -1;
    in_stack_00000020[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1 + -1;
      *piVar1 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar2 = param_2 + 2;
    iVar4 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 20155 ; VA 0x00a294b0 ; FUN_00a294b0 */

void __thiscall
FUN_00a294b0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_c = param_6;
  uStack_10 = param_7;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_28 = param_3;
  uStack_1c = param_6;
  uStack_18 = param_7;
  uStack_2c = param_2;
  uStack_24 = param_4;
  uStack_20 = param_5;
  cVar3 = FUN_00585a40(&uStack_2c);
  if (cVar3 == '\0') {
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[2] = piStack_28[2] + 1;
      UNLOCK();
    }
    uStack_10 = uStack_20;
    uStack_c = uStack_1c;
    uStack_14 = uStack_18;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[2] = piStack_28[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_2c;
    param_1[3] = piStack_28;
    param_1[5] = uStack_20;
    param_1[4] = uStack_24;
    param_1[6] = uStack_1c;
    param_1[7] = uStack_18;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_28[2] + -1;
      piStack_28[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_28[2] + -1;
      piStack_28[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_28[2] + -1;
      piStack_28[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01941298;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 20156 ; VA 0x00a29600 ; FUN_00a29600 */

undefined ** __thiscall
FUN_00a29600(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  cVar3 = FUN_00963340(param_2,param_3,param_4,param_5,param_1 + 2,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0194131c;
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = (int)ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    ppuVar4 = (undefined **)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      ppuVar4 = (undefined **)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        ppuVar4 = (undefined **)(**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      ppuVar4 = (undefined **)(**(code **)(*param_3 + 4))();
    }
  }
  return ppuVar4;
}



/* FUNCTION 20157 ; VA 0x00a29710 ; FUN_00a29710 */

void __thiscall FUN_00a29710(undefined4 *param_1,undefined4 param_2,int param_3)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 uStack_bc;
  int iStack_b8;
  undefined auStack_b4 [24];
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_84;
  int iStack_80;
  undefined auStack_7c [24];
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_4c;
  int iStack_48;
  undefined auStack_44 [24];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017dc6e2;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_bc;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_3 + 8) = *(int *)(param_3 + 8) + 1;
    UNLOCK();
  }
  uStack_bc = param_2;
  iStack_b8 = param_3;
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_0054ef60(&stack0x0000000c);
  uStack_9c = in_stack_00000024;
  uStack_98 = in_stack_00000028;
  uStack_94 = in_stack_0000002c;
  uStack_90 = in_stack_00000030;
  uStack_8c = in_stack_00000034;
  puStack_14 = &uStack_4c;
  if (iStack_b8 != 0) {
    LOCK();
    *(int *)(iStack_b8 + 8) = *(int *)(iStack_b8 + 8) + 1;
    UNLOCK();
  }
  uStack_4c = uStack_bc;
  iStack_48 = iStack_b8;
  uStack_8 = 3;
  FUN_0054ef60(auStack_b4);
  uStack_2c = uStack_9c;
  uStack_28 = uStack_98;
  uStack_24 = uStack_94;
  uStack_20 = uStack_90;
  uStack_1c = uStack_8c;
  uStack_8 = 4;
  cVar2 = FUN_00585a40(&uStack_4c);
  if (cVar2 == '\0') {
    puStack_14 = &uStack_84;
    if (iStack_48 != 0) {
      LOCK();
      *(int *)(iStack_48 + 8) = *(int *)(iStack_48 + 8) + 1;
      UNLOCK();
    }
    uStack_84 = uStack_4c;
    iStack_80 = iStack_48;
    uStack_8 = 5;
    FUN_0054ef60(auStack_44);
    uStack_64 = uStack_2c;
    uStack_60 = uStack_28;
    uStack_5c = uStack_24;
    uStack_58 = uStack_20;
    uStack_54 = uStack_1c;
    uStack_8 = 6;
    puVar3 = (undefined4 *)FUN_01674e20(0x38);
    uStack_8 = 7;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = 0;
      puVar3[1] = 0;
      if (iStack_80 != 0) {
        LOCK();
        *(int *)(iStack_80 + 8) = *(int *)(iStack_80 + 8) + 1;
        UNLOCK();
      }
      *puVar3 = uStack_84;
      puVar3[1] = iStack_80;
      uStack_8 = 8;
      FUN_0054ef60(auStack_7c);
      puVar3[8] = uStack_64;
      puVar3[9] = uStack_60;
      puVar3[10] = uStack_5c;
      puVar3[0xb] = uStack_58;
      puVar3[0xc] = uStack_54;
    }
    param_1[2] = puVar3;
    FUN_005d11a0();
    FUN_005d11a0();
    bVar1 = true;
  }
  else {
    FUN_005d11a0();
    bVar1 = false;
  }
  FUN_005d11a0();
  ppuVar4 = &PTR_FUN_019412a0;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_005d11a0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20158 ; VA 0x00a29960 ; FUN_00a29960 */

undefined4 * FUN_00a29960(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dc723;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00eb3a50();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x80);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00eb3b70();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00a28810(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20159 ; VA 0x00a29a20 ; FUN_00a29a20 */

void __thiscall FUN_00a29a20(int param_1,undefined4 *param_2,uint param_3,int *param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  
  uVar3 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar2 = (int *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
    if (puVar1 == (undefined4 *)0x0) {
      piVar2 = (int *)0x0;
    }
    else {
      piVar2 = (int *)*puVar1;
    }
    if (piVar2 != (int *)0x0) {
      do {
        if (param_3 == piVar2[1]) {
          if ((((*param_4 == piVar2[2]) && (param_4[1] == piVar2[3])) && (param_4[2] == piVar2[4]))
             && (param_4[3] == piVar2[5])) break;
        }
        else if ((uint)piVar2[1] % *(uint *)(param_1 + 4) != uVar3) {
          *param_2 = 0;
          return;
        }
        piVar2 = (int *)*piVar2;
        if (piVar2 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar2;
  return;
}



/* FUNCTION 20160 ; VA 0x00a29ac0 ; FUN_00a29ac0 */

void __thiscall FUN_00a29ac0(undefined4 param_1,int *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  puVar4 = (undefined4 *)FUN_01674e20(0x68,param_1);
  if (puVar4 != (undefined4 *)0x0) {
    puVar4[1] = 1;
    puVar4[2] = 1;
    *puVar4 = std::_Ref_count_obj<struct_RBX::PackageService::PackageAssetData>::vftable;
    puVar4[4] = *param_3;
    puVar4[5] = param_3[1];
    puVar4[6] = param_3[2];
    puVar4[7] = param_3[3];
    puVar4[0xc] = 0;
    puVar4[0xd] = 0;
    uVar1 = param_3[5];
    uVar2 = param_3[6];
    uVar3 = param_3[7];
    puVar4[8] = param_3[4];
    puVar4[9] = uVar1;
    puVar4[10] = uVar2;
    puVar4[0xb] = uVar3;
    *(undefined8 *)(puVar4 + 0xc) = *(undefined8 *)(param_3 + 8);
    param_3[8] = 0;
    param_3[9] = 0xf;
    *(undefined *)(param_3 + 4) = 0;
    puVar4[0x12] = 0;
    puVar4[0x13] = 0;
    uVar1 = param_3[0xb];
    uVar2 = param_3[0xc];
    uVar3 = param_3[0xd];
    puVar4[0xe] = param_3[10];
    puVar4[0xf] = uVar1;
    puVar4[0x10] = uVar2;
    puVar4[0x11] = uVar3;
    *(undefined8 *)(puVar4 + 0x12) = *(undefined8 *)(param_3 + 0xe);
    param_3[0xe] = 0;
    param_3[0xf] = 0xf;
    *(undefined *)(param_3 + 10) = 0;
    puVar4[0x18] = 0;
    puVar4[0x19] = 0;
    uVar1 = param_3[0x11];
    uVar2 = param_3[0x12];
    uVar3 = param_3[0x13];
    puVar4[0x14] = param_3[0x10];
    puVar4[0x15] = uVar1;
    puVar4[0x16] = uVar2;
    puVar4[0x17] = uVar3;
    *(undefined8 *)(puVar4 + 0x18) = *(undefined8 *)(param_3 + 0x14);
    param_3[0x14] = 0;
    param_3[0x15] = 0xf;
    *(undefined *)(param_3 + 0x10) = 0;
    *param_2 = (int)(puVar4 + 4);
    param_2[1] = (int)puVar4;
    return;
  }
  param_2[1] = 0;
  *param_2 = 0x10;
  return;
}



/* FUNCTION 20161 ; VA 0x00a29bc0 ; FUN_00a29bc0 */

undefined4 * __thiscall FUN_00a29bc0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dc743;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 2);
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = param_2[0xc];
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(param_2 + 0xd);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20162 ; VA 0x00a29c60 ; FUN_00a29c60 */

int __thiscall FUN_00a29c60(int param_1,int param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dc779;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  *(undefined4 *)(param_1 + 0x18) = *(undefined4 *)(param_2 + 0x18);
  *(undefined4 *)(param_1 + 0x1c) = *(undefined4 *)(param_2 + 0x1c);
  *(undefined4 *)(param_1 + 0x20) = *(undefined4 *)(param_2 + 0x20);
  *(undefined4 *)(param_1 + 0x24) = *(undefined4 *)(param_2 + 0x24);
  *(undefined4 *)(param_1 + 0x28) = 0;
  uVar1 = *(uint *)(param_2 + 0x28);
  uStack_8 = 0;
  if (uVar1 != 0) {
    *(uint *)(param_1 + 0x28) = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0x30,param_1 + 0x30,0);
    }
    else {
      uVar2 = *(undefined4 *)(param_2 + 0x34);
      uVar3 = *(undefined4 *)(param_2 + 0x38);
      uVar4 = *(undefined4 *)(param_2 + 0x3c);
      *(undefined4 *)(param_1 + 0x30) = *(undefined4 *)(param_2 + 0x30);
      *(undefined4 *)(param_1 + 0x34) = uVar2;
      *(undefined4 *)(param_1 + 0x38) = uVar3;
      *(undefined4 *)(param_1 + 0x3c) = uVar4;
      *(undefined8 *)(param_1 + 0x40) = *(undefined8 *)(param_2 + 0x40);
    }
  }
  *(undefined4 *)(param_1 + 0x48) = 0;
  uVar1 = *(uint *)(param_2 + 0x48);
  uStack_8._0_1_ = 1;
  if (uVar1 != 0) {
    *(uint *)(param_1 + 0x48) = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0x50,param_1 + 0x50,0);
    }
    else {
      uVar2 = *(undefined4 *)(param_2 + 0x54);
      uVar3 = *(undefined4 *)(param_2 + 0x58);
      uVar4 = *(undefined4 *)(param_2 + 0x5c);
      *(undefined4 *)(param_1 + 0x50) = *(undefined4 *)(param_2 + 0x50);
      *(undefined4 *)(param_1 + 0x54) = uVar2;
      *(undefined4 *)(param_1 + 0x58) = uVar3;
      *(undefined4 *)(param_1 + 0x5c) = uVar4;
      *(undefined8 *)(param_1 + 0x60) = *(undefined8 *)(param_2 + 0x60);
    }
  }
  uStack_8._0_1_ = 2;
  FUN_0054ef60(param_2 + 0x68);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0054ef60(param_2 + 0x80);
  *(undefined4 *)(param_1 + 0x98) = *(undefined4 *)(param_2 + 0x98);
  *(undefined4 *)(param_1 + 0x9c) = *(undefined4 *)(param_2 + 0x9c);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20163 ; VA 0x00a29d80 ; FUN_00a29d80 */

undefined4 * __thiscall FUN_00a29d80(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar6 = ExceptionList;
  puStack_c = &LAB_017dc798;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  param_1[6] = 0;
  uVar2 = param_2[6];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[6] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[9];
      uVar4 = param_2[10];
      uVar5 = param_2[0xb];
      param_1[8] = param_2[8];
      param_1[9] = uVar3;
      param_1[10] = uVar4;
      param_1[0xb] = uVar5;
      *(undefined8 *)(param_1 + 0xc) = *(undefined8 *)(param_2 + 0xc);
      ExceptionList = pvVar6;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 8,param_1 + 8,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20164 ; VA 0x00a29e50 ; FUN_00a29e50 */

undefined4 * __thiscall FUN_00a29e50(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  param_1[6] = 0;
  param_1[7] = 0;
  if (param_2[7] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[7] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  return param_1;
}



/* FUNCTION 20165 ; VA 0x00a29ec0 ; FUN_00a29ec0 */

undefined4 * __thiscall FUN_00a29ec0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dc7ce;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 2);
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  param_1[10] = 0;
  uVar2 = param_2[10];
  uStack_8._0_1_ = 1;
  if (uVar2 != 0) {
    param_1[10] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
    }
    else {
      uVar3 = param_2[0xd];
      uVar4 = param_2[0xe];
      uVar5 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar3;
      param_1[0xe] = uVar4;
      param_1[0xf] = uVar5;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
    }
  }
  param_1[0x12] = 0;
  uVar2 = param_2[0x12];
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (uVar2 != 0) {
    param_1[0x12] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0x15];
      uVar4 = param_2[0x16];
      uVar5 = param_2[0x17];
      param_1[0x14] = param_2[0x14];
      param_1[0x15] = uVar3;
      param_1[0x16] = uVar4;
      param_1[0x17] = uVar5;
      *(undefined8 *)(param_1 + 0x18) = *(undefined8 *)(param_2 + 0x18);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x14,param_1 + 0x14,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20166 ; VA 0x00a29fd0 ; FUN_00a29fd0 */

int * __fastcall FUN_00a29fd0(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  char *pcVar7;
  undefined auStack_40 [24];
  undefined auStack_28 [8];
  undefined auStack_20 [8];
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dc801;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = -1;
  param_1[1] = -1;
  param_1[2] = -1;
  param_1[3] = -1;
  param_1[8] = 0;
  param_1[9] = 0xf;
  *(undefined *)(param_1 + 4) = 0;
  piStack_18 = param_1;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0xf;
  *(undefined *)(param_1 + 10) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  piVar1 = param_1 + 0x10;
  uStack_8._0_1_ = 1;
  param_1[0x14] = 0;
  param_1[0x15] = 0xf;
  *(undefined *)piVar1 = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar4 = FUN_016816d0();
  if ((cVar4 == '\0') && (cVar4 = FUN_01681870(), cVar4 != '\0')) {
    FUN_0167eda0(auStack_28,&DAT_01d65e48);
    piStack_14 = (int *)FUN_00563600(auStack_40);
    if (piVar1 != piStack_14) {
      FUN_005507b0();
      iVar5 = piStack_14[1];
      iVar2 = piStack_14[2];
      iVar3 = piStack_14[3];
      *piVar1 = *piStack_14;
      param_1[0x11] = iVar5;
      param_1[0x12] = iVar2;
      param_1[0x13] = iVar3;
      *(undefined8 *)(param_1 + 0x14) = *(undefined8 *)(piStack_14 + 4);
      piStack_14[4] = 0;
      piStack_14[5] = 0xf;
      *(undefined *)piStack_14 = 0;
    }
    FUN_005507b0();
    FUN_0167eda0(auStack_20,&DAT_01d65e60);
    cVar4 = FUN_01681870();
    if (cVar4 != '\0') {
      FUN_0167eda0(auStack_28,&DAT_01d65e30);
      iVar5 = FUN_0167e2d0(0);
      *param_1 = iVar5;
      param_1[1] = iVar5 >> 0x1f;
      FUN_0167eda0(auStack_28,&DAT_01d65e78);
      uVar6 = FUN_00563600(auStack_40);
      FUN_005511f0(uVar6);
      FUN_005507b0();
      FUN_0167eda0(auStack_28,&DAT_01d65e48);
      uVar6 = FUN_00563600(auStack_40);
      FUN_005511f0(uVar6);
      FUN_005507b0();
      FUN_0167eda0(auStack_28,&DAT_01d65e90);
      iVar5 = FUN_0167e2d0(0);
      param_1[2] = iVar5;
      param_1[3] = iVar5 >> 0x1f;
      ExceptionList = pvStack_10;
      return param_1;
    }
    if (DAT_01d84e8e == '\0') {
      ExceptionList = pvStack_10;
      return param_1;
    }
    pcVar7 = 
    "Failed to create PackageService::PackageAssetData from product info: Creator info not found.";
  }
  else {
    if (DAT_01d84e8e == '\0') {
      ExceptionList = pvStack_10;
      return param_1;
    }
    pcVar7 = 
    "Failed to create PackageService::PackageAssetData from product info: Product info has error.";
  }
  FUN_016774b0(DAT_01d84e8e,pcVar7,0);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20167 ; VA 0x00a2a210 ; FUN_00a2a210 */

undefined4 * __fastcall FUN_00a2a210(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dc826;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0xffffffff;
  param_1[1] = 0xffffffff;
  param_1[2] = 0xffffffff;
  param_1[3] = 0xffffffff;
  param_1[8] = 0;
  param_1[9] = 0xf;
  *(undefined *)(param_1 + 4) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0xf;
  *(undefined *)(param_1 + 10) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  param_1[0x14] = 0;
  param_1[0x15] = 0xf;
  *(undefined *)(param_1 + 0x10) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20168 ; VA 0x00a2a2d0 ; FUN_00a2a2d0 */

undefined4 * __thiscall FUN_00a2a2d0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  uVar2 = param_2[1];
  uVar3 = param_2[2];
  uVar4 = param_2[3];
  *param_1 = *param_2;
  param_1[1] = uVar2;
  param_1[2] = uVar3;
  param_1[3] = uVar4;
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  param_1[6] = 0;
  param_1[7] = 0;
  if (param_2[7] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[7] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  param_1[8] = 0;
  param_1[9] = 0;
  if (param_2[9] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[9] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  return param_1;
}



/* FUNCTION 20169 ; VA 0x00a2a340 ; FUN_00a2a340 */

int __fastcall FUN_00a2a340(int param_1)

{
  undefined8 uStack_14;
  undefined8 uStack_c;
  
  uStack_14 = 0;
  uStack_c = 0;
  FUN_00fbd320(&uStack_14,&uStack_c);
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  return param_1;
}



/* FUNCTION 20170 ; VA 0x00a2a3a0 ; FUN_00a2a3a0 */

undefined4 * __fastcall FUN_00a2a3a0(undefined4 *param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined **ppuVar5;
  int iVar6;
  undefined **ppuVar7;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dc936;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::PackageService,class_RBX::ServiceInstance>::vftable;
  uVar4 = FUN_00a28710();
  param_1[3] = uVar4;
  *param_1 = RBX::PackageService::vftable;
  param_1[0x16] = 0;
  puVar1 = param_1 + 0x17;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  *puVar1 = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  puStack_14 = puVar1;
  uVar4 = FUN_005cb2b0(0,0);
  param_1[0x18] = uVar4;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  uStack_8._0_1_ = 4;
  *puVar1 = 0x3f800000;
  FUN_005cb500(8);
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  uStack_8._0_1_ = 6;
  FUN_005e5ff0();
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  *(undefined *)(param_1 + 0x31) = 0;
  puStack_14 = (undefined4 *)0xb;
  ppuVar5 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_14);
  ppuVar7 = ppuVar5 + -1;
  if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar5;
  }
  param_1[0x32] = *ppuVar7;
  param_1[0x33] = 0;
  param_1[0x34] = 0x3f800000;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  *(undefined *)(param_1 + 0x37) = 0;
  puStack_14 = (undefined4 *)0xb;
  ppuVar5 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_14);
  ppuVar7 = ppuVar5 + -1;
  if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar5;
  }
  param_1[0x38] = *ppuVar7;
  param_1[0x39] = 0;
  param_1[0x3a] = 0x3f800000;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  param_1[0x3e] = 0;
  param_1[0x3f] = 0;
  param_1[0x40] = 0;
  *(undefined *)(param_1 + 0x41) = 0;
  puStack_14 = (undefined4 *)0xb;
  ppuVar5 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_14);
  ppuVar7 = ppuVar5 + -1;
  if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar5;
  }
  param_1[0x42] = *ppuVar7;
  param_1[0x43] = 0;
  param_1[0x44] = 0x3f800000;
  param_1[0x45] = 0;
  param_1[0x46] = 0;
  *(undefined *)(param_1 + 0x47) = 0;
  puStack_14 = (undefined4 *)0xb;
  ppuVar5 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_14);
  ppuVar7 = ppuVar5 + -1;
  if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar5;
  }
  param_1[0x48] = *ppuVar7;
  param_1[0x49] = 0;
  param_1[0x4a] = 0x3f800000;
  param_1[0x4b] = 0;
  param_1[0x4c] = 0;
  *(undefined *)(param_1 + 0x4d) = 0;
  puStack_14 = (undefined4 *)0xb;
  ppuVar5 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_14);
  ppuVar7 = ppuVar5 + -1;
  if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar5;
  }
  param_1[0x4e] = *ppuVar7;
  param_1[0x4f] = 0;
  param_1[0x50] = 0x3f800000;
  param_1[0x51] = 0;
  param_1[0x52] = 0;
  *(undefined *)(param_1 + 0x53) = 0;
  puStack_14 = (undefined4 *)0xb;
  ppuVar5 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_14);
  ppuVar7 = ppuVar5 + -1;
  if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar5;
  }
  param_1[0x54] = *ppuVar7;
  param_1[0x55] = 0;
  param_1[0x56] = 0x3f800000;
  param_1[0x57] = 0;
  param_1[0x58] = 0;
  param_1[0x59] = 0;
  param_1[0x5a] = 0;
  uStack_8._0_1_ = 0x13;
  iVar6 = FUN_01674e20(0x50);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
  if (iVar6 == 0) {
    iVar6 = 0;
  }
  else {
    iVar6 = FUN_00a27d50();
  }
  param_1[0x59] = iVar6 + 0x10;
  piVar3 = (int *)param_1[0x5a];
  param_1[0x5a] = iVar6;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar6 = piVar3[1] + -1;
    piVar3[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar2 = piVar3 + 2;
      iVar6 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20171 ; VA 0x00a2a790 ; FUN_00a2a790 */

void __fastcall FUN_00a2a790(int param_1)

{
  uint uVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  
  uVar1 = *(uint *)(param_1 + 0x48);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x34);
    uVar5 = uVar1 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) goto LAB_00a2a82f;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 0x44) = 0;
  *(undefined4 *)(param_1 + 0x48) = 0xf;
  *(undefined *)(param_1 + 0x34) = 0;
  uVar1 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 8);
    uVar5 = uVar1 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) {
LAB_00a2a82f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[2] + -1;
    piVar3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
                    /* WARNING: Could not recover jumptable at 0x00a2a82b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar3 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 20172 ; VA 0x00a2a840 ; FUN_00a2a840 */

void __fastcall FUN_00a2a840(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = param_1[0x25];
  ExceptionList = &pvStack_10;
  if (0xf < uVar1) {
    iVar2 = param_1[0x20];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      ExceptionList = &pvStack_10;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00a2a9a1;
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x24] = 0;
  param_1[0x25] = 0xf;
  *(undefined *)(param_1 + 0x20) = 0;
  uVar1 = param_1[0x1f];
  if (0xf < uVar1) {
    iVar2 = param_1[0x1a];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00a2a9a1;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x1e] = 0;
  param_1[0x1f] = 0xf;
  *(undefined *)(param_1 + 0x1a) = 0;
  uVar1 = param_1[0x12];
  uStack_8 = 0;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x14,param_1 + 0x14,2);
      }
    }
    param_1[0x12] = 0;
  }
  uVar1 = param_1[10];
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0xc,param_1 + 0xc,2);
      }
    }
    param_1[10] = 0;
  }
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00a2a9a1:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20173 ; VA 0x00a2a9b0 ; FUN_00a2a9b0 */

code * __fastcall FUN_00a2a9b0(int param_1)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  code *pcVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  pcVar4 = *(code **)(param_1 + 0x18);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (pcVar4 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    if (((uint)pcVar4 & 1) == 0) {
      pcVar4 = *(code **)((uint)pcVar4 & 0xfffffffe);
      ExceptionList = &pvStack_10;
      if (pcVar4 != (code *)0x0) {
        ExceptionList = &pvStack_10;
        pcVar4 = (code *)(*pcVar4)(param_1 + 0x20,param_1 + 0x20,2);
      }
    }
    *(undefined4 *)(param_1 + 0x18) = 0;
  }
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar3 + 2);
    uVar2 = *puVar1;
    pcVar4 = (code *)*puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      pcVar4 = (code *)(**(code **)(*piVar3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return pcVar4;
}



/* FUNCTION 20174 ; VA 0x00a2aa20 ; FUN_00a2aa20 */

void __fastcall FUN_00a2aa20(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x1c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00a2aa62. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 20175 ; VA 0x00a2aa70 ; FUN_00a2aa70 */

code * __fastcall FUN_00a2aa70(int param_1)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  code *pcVar5;
  int iVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar2 = *(uint *)(param_1 + 0x48);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x50,param_1 + 0x50,2);
      }
    }
    *(undefined4 *)(param_1 + 0x48) = 0;
  }
  pcVar5 = *(code **)(param_1 + 0x28);
  uStack_8 = 1;
  if (pcVar5 != (code *)0x0) {
    if (((uint)pcVar5 & 1) == 0) {
      pcVar5 = *(code **)((uint)pcVar5 & 0xfffffffe);
      if (pcVar5 != (code *)0x0) {
        pcVar5 = (code *)(*pcVar5)(param_1 + 0x30,param_1 + 0x30,2);
      }
    }
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  uVar2 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 8);
    uVar7 = uVar2 + 1;
    iVar6 = iVar3;
    if (0xfff < uVar7) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar7 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    pcVar5 = (code *)FUN_01674ea0(iVar6,uVar7);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  piVar4 = *(int **)(param_1 + 4);
  if (piVar4 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar4 + 2);
    uVar2 = *puVar1;
    pcVar5 = (code *)*puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      pcVar5 = (code *)(**(code **)(*piVar4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return pcVar5;
}



/* FUNCTION 20176 ; VA 0x00a2ab60 ; FUN_00a2ab60 */

void FUN_00a2ab60(void)

{
  FUN_00a2b3d0();
  return;
}



/* FUNCTION 20177 ; VA 0x00a2ab70 ; FUN_00a2ab70 */

void __fastcall FUN_00a2ab70(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00a2ddb0();
  FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x20);
  return;
}



/* FUNCTION 20178 ; VA 0x00a2abe0 ; FUN_00a2abe0 */

void __fastcall FUN_00a2abe0(int *param_1)

{
  int iVar1;
  int *piVar2;
  void **ppvVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  piVar5 = *(int **)(iVar1 + 4);
  uStack_8 = 0;
  iVar4 = iVar1;
  ExceptionList = &pvStack_10;
  ppvVar3 = &pvStack_10;
  if (*(char *)((int)piVar5 + 0xd) == '\0') {
    do {
      FUN_00a2db60(piVar5[2]);
      piVar2 = (int *)*piVar5;
      FUN_01674ea0(piVar5,0x20);
      piVar5 = piVar2;
    } while (*(char *)((int)piVar2 + 0xd) == '\0');
    iVar4 = *param_1;
    ppvVar3 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar3;
  *(int *)(iVar4 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20179 ; VA 0x00a2ac80 ; FUN_00a2ac80 */

void FUN_00a2ac80(void)

{
  FUN_00a2b3d0();
  return;
}



/* FUNCTION 20180 ; VA 0x00a2ac90 ; FUN_00a2ac90 */

void __fastcall FUN_00a2ac90(undefined4 *param_1)

{
  FUN_00a2ddb0();
  FUN_01674ea0(*param_1,0x20);
  return;
}



/* FUNCTION 20181 ; VA 0x00a2acb0 ; FUN_00a2acb0 */

void __fastcall FUN_00a2acb0(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a2db10(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20182 ; VA 0x00a2ad10 ; FUN_00a2ad10 */

void __fastcall FUN_00a2ad10(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_00a2b3d0();
      iVar1 = *(int *)(param_1 + 4);
    }
    FUN_01674ea0(iVar1,0x40);
  }
  return;
}



/* FUNCTION 20183 ; VA 0x00a2ad40 ; FUN_00a2ad40 */

void __fastcall FUN_00a2ad40(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 4) != 0) {
    if ((*(char *)(param_1 + 9) != '\0') &&
       (piVar2 = *(int **)(*(int *)(param_1 + 4) + 0x14), piVar2 != (int *)0x0)) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x18);
  }
  return;
}



/* FUNCTION 20184 ; VA 0x00a2ad90 ; FUN_00a2ad90 */

void __fastcall FUN_00a2ad90(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_00a2b0f0();
      iVar1 = *(int *)(param_1 + 4);
    }
    FUN_01674ea0(iVar1,0x28);
  }
  return;
}



/* FUNCTION 20185 ; VA 0x00a2adc0 ; FUN_00a2adc0 */

void __fastcall FUN_00a2adc0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_0056d250();
      iVar1 = *(int *)(param_1 + 4);
    }
    FUN_01674ea0(iVar1,0x28);
  }
  return;
}



/* FUNCTION 20186 ; VA 0x00a2adf0 ; FUN_00a2adf0 */

void __fastcall FUN_00a2adf0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_008ae410();
      iVar1 = *(int *)(param_1 + 4);
    }
    FUN_01674ea0(iVar1,0x28);
  }
  return;
}



/* FUNCTION 20187 ; VA 0x00a2ae20 ; FUN_00a2ae20 */

void __fastcall FUN_00a2ae20(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00a2b3d0();
        FUN_01674ea0(puVar6,0x40);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 20188 ; VA 0x00a2aeb0 ; FUN_00a2aeb0 */

void __fastcall FUN_00a2aeb0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      ExceptionList = &pvStack_10;
      FUN_00a2df60(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20189 ; VA 0x00a2af50 ; FUN_00a2af50 */

void __fastcall FUN_00a2af50(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00a2e000(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 20190 ; VA 0x00a2afd0 ; FUN_00a2afd0 */

void __fastcall FUN_00a2afd0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00a2b0f0();
        FUN_01674ea0(puVar6,0x28);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 20191 ; VA 0x00a2b060 ; FUN_00a2b060 */

void __fastcall FUN_00a2b060(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_0056d250();
        FUN_01674ea0(puVar6,0x28);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 20192 ; VA 0x00a2b0f0 ; FUN_00a2b0f0 */

void __fastcall FUN_00a2b0f0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_008ae410();
        FUN_01674ea0(puVar6,0x28);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 20193 ; VA 0x00a2b180 ; FUN_00a2b180 */

void __fastcall FUN_00a2b180(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_00fbb160();
    FUN_01674ea0(iVar1,0x34);
  }
  return;
}



/* FUNCTION 20194 ; VA 0x00a2b1a0 ; FUN_00a2b1a0 */

void __fastcall FUN_00a2b1a0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00a2b3d0();
        FUN_01674ea0(puVar6,0x40);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 20195 ; VA 0x00a2b1b0 ; FUN_00a2b1b0 */

void __fastcall FUN_00a2b1b0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      ExceptionList = &pvStack_10;
      FUN_00a2df60(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20196 ; VA 0x00a2b1c0 ; FUN_00a2b1c0 */

void __fastcall FUN_00a2b1c0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00a2e000(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 20197 ; VA 0x00a2b1d0 ; FUN_00a2b1d0 */

void __fastcall FUN_00a2b1d0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00a2b0f0();
        FUN_01674ea0(puVar6,0x28);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 20198 ; VA 0x00a2b1e0 ; FUN_00a2b1e0 */

void __fastcall FUN_00a2b1e0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_0056d250();
        FUN_01674ea0(puVar6,0x28);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 20199 ; VA 0x00a2b1f0 ; FUN_00a2b1f0 */

void __fastcall FUN_00a2b1f0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00a2ddb0();
  FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x20);
  return;
}



/* FUNCTION 20200 ; VA 0x00a2b200 ; FUN_00a2b200 */

void __fastcall FUN_00a2b200(undefined4 *param_1)

{
  void **ppvVar1;
  uint uVar2;
  uint *puVar3;
  uint *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  puVar3 = (uint *)*param_1;
  if (puVar3 != (uint *)0x0) {
    puVar4 = (uint *)param_1[1];
    ExceptionList = &pvStack_10;
    ppvVar1 = &pvStack_10;
    if (puVar3 != puVar4) {
      do {
        uVar2 = puVar3[8];
        uStack_8 = 0;
        if (uVar2 != 0) {
          if (((uVar2 & 1) == 0) && (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0)) {
            (**(code **)(uVar2 & 0xfffffffe))(puVar3 + 10,puVar3 + 10,2);
          }
          puVar3[8] = 0;
        }
        uVar2 = *puVar3;
        uStack_8 = 1;
        if (uVar2 != 0) {
          if (((uVar2 & 1) == 0) && (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0)) {
            (**(code **)(uVar2 & 0xfffffffe))(puVar3 + 2,puVar3 + 2,2);
          }
          *puVar3 = 0;
        }
        puVar3 = puVar3 + 0x10;
      } while (puVar3 != puVar4);
      puVar3 = (uint *)*param_1;
      ppvVar1 = (void **)ExceptionList;
    }
    ExceptionList = ppvVar1;
    uStack_8 = 0xffffffff;
    uVar2 = param_1[2] - (int)puVar3 & 0xffffffc0;
    puVar4 = puVar3;
    if (0xfff < uVar2) {
      puVar4 = (uint *)puVar3[-1];
      uVar2 = uVar2 + 0x23;
      if (0x1f < (uint)((int)puVar3 + (-4 - (int)puVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar4,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20201 ; VA 0x00a2b2f0 ; FUN_00a2b2f0 */

void __fastcall FUN_00a2b2f0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x54);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x40);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00a2b3bf;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x50) = 0;
  *(undefined4 *)(param_1 + 0x54) = 0xf;
  *(undefined *)(param_1 + 0x40) = 0;
  uVar1 = *(uint *)(param_1 + 0x3c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x28);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00a2b3bf;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x3c) = 0xf;
  *(undefined *)(param_1 + 0x28) = 0;
  uVar1 = *(uint *)(param_1 + 0x24);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x10);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00a2b3bf:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0xf;
  *(undefined *)(param_1 + 0x10) = 0;
  return;
}



/* FUNCTION 20202 ; VA 0x00a2b3d0 ; FUN_00a2b3d0 */

void __fastcall FUN_00a2b3d0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x24);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x1c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00a2b423. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 20203 ; VA 0x00a2b430 ; FUN_00a2b430 */

void __fastcall FUN_00a2b430(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x168);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00a2aeb0();
  FUN_00a2afd0();
  FUN_00a2ae20();
  FUN_00a2b060();
  LOCK();
  iVar3 = *(int *)(param_1 + 0x100);
  *(int *)(param_1 + 0x100) = 0;
  UNLOCK();
  if (iVar3 != 0) {
    CloseHandle(iVar3);
  }
  FUN_00a2af50();
  FUN_008ae410();
  LOCK();
  iVar3 = *(int *)(param_1 + 0xc0);
  *(int *)(param_1 + 0xc0) = 0;
  UNLOCK();
  if (iVar3 != 0) {
    CloseHandle(iVar3);
  }
  if (*(undefined4 **)(param_1 + 0xb8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0xb8))(1);
  }
  iVar3 = *(int *)(param_1 + 0xb4);
  if (iVar3 != 0) {
    FUN_00fbb160();
    FUN_01674ea0(iVar3,0x34);
  }
  piVar2 = *(int **)(param_1 + 0xb0);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  LOCK();
  iVar3 = *(int *)(param_1 + 0xa8);
  *(int *)(param_1 + 0xa8) = 0;
  UNLOCK();
  if (iVar3 != 0) {
    CloseHandle(iVar3);
  }
  FUN_005e61c0();
  LOCK();
  iVar3 = *(int *)(param_1 + 0x80);
  *(int *)(param_1 + 0x80) = 0;
  UNLOCK();
  if (iVar3 != 0) {
    CloseHandle(iVar3);
  }
  FUN_00a2ab70();
  FUN_016790b0();
  FUN_0089b230();
  return;
}



/* FUNCTION 20204 ; VA 0x00a2b570 ; FUN_00a2b570 */

void __fastcall FUN_00a2b570(int param_1)

{
  int iVar1;
  
  LOCK();
  iVar1 = *(int *)(param_1 + 0x4c);
  *(int *)(param_1 + 0x4c) = 0;
  UNLOCK();
  if (iVar1 != 0) {
    CloseHandle(iVar1);
  }
  FUN_005e61c0();
  LOCK();
  iVar1 = *(int *)(param_1 + 0x24);
  *(int *)(param_1 + 0x24) = 0;
  UNLOCK();
  if (iVar1 != 0) {
    CloseHandle(iVar1);
  }
  FUN_00a2ab70();
  return;
}



/* FUNCTION 20205 ; VA 0x00a2b5b0 ; FUN_00a2b5b0 */

undefined4 * __thiscall FUN_00a2b5b0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  
  uVar3 = param_2[1];
  uVar4 = param_2[2];
  uVar5 = param_2[3];
  *param_1 = *param_2;
  param_1[1] = uVar3;
  param_1[2] = uVar4;
  param_1[3] = uVar5;
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  iVar6 = param_2[7];
  if (iVar6 != 0) {
    LOCK();
    *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
    UNLOCK();
    iVar6 = param_2[7];
  }
  param_1[6] = param_2[6];
  piVar2 = (int *)param_1[7];
  param_1[7] = iVar6;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar6 = param_2[9];
  if (iVar6 != 0) {
    LOCK();
    *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
    UNLOCK();
    iVar6 = param_2[9];
  }
  param_1[8] = param_2[8];
  piVar2 = (int *)param_1[9];
  param_1[9] = iVar6;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 20206 ; VA 0x00a2b660 ; FUN_00a2b660 */

int * __thiscall FUN_00a2b660(byte *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  undefined4 *puVar10;
  undefined8 uStack_30;
  undefined8 uStack_28;
  int *piStack_20;
  uint uStack_1c;
  int *piStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar6 = (int *)param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dc948;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  pbStack_14 = param_1;
  uStack_1c = FUN_00fbd350(param_2);
  FUN_00a29a20(&param_2,uStack_1c,piVar6,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (uint *)0x0) {
    iVar4 = *piVar6;
    iVar5 = piVar6[1];
    uStack_30._0_4_ = piVar6[2];
    uStack_30._4_4_ = piVar6[3];
    uStack_8 = 0;
    piVar6 = (int *)FUN_01674e20(0x40);
    *piVar6 = 0;
    piStack_20 = piVar6 + 2;
    piVar6[1] = 0;
    piVar6[6] = 0;
    piVar6[7] = 0;
    piVar6[8] = 0;
    piVar6[9] = 0;
    piVar6[10] = 0;
    piVar6[0xb] = 0;
    piVar6[0xc] = 0;
    piVar6[0xd] = 0;
    piVar6[0xe] = 0;
    piVar6[0xf] = 0;
    *piStack_20 = iVar4;
    piVar6[3] = iVar5;
    piVar6[4] = (int)uStack_30;
    piVar6[5] = uStack_30._4_4_;
    piVar6[6] = 0;
    piVar6[7] = 0;
    piVar6[8] = 0;
    piVar6[9] = 0;
    piVar6[10] = 0;
    piVar6[0xb] = 0;
    piVar6[0xc] = 0;
    piVar6[0xd] = 0;
    piVar6[0xe] = 0;
    piVar6[0xf] = 0;
    uStack_30 = 0;
    uStack_28 = 0;
    piStack_18 = piVar6;
    FUN_00fbd320(&uStack_30,&uStack_28);
    piVar6[10] = 0;
    piVar6[0xb] = 0;
    piVar6[0xc] = 0;
    piVar6[0xd] = 0;
    piVar6[0xe] = 0;
    piVar6[0xf] = 0;
    uVar2 = *(uint *)(param_1 + 8);
    uVar7 = uVar2 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar7 = FUN_005c9310(uVar7);
      if (uVar7 <= *(uint *)(param_1 + 4)) {
        uVar7 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar7);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar7) {
      param_2 = (uint *)0x1;
      uVar8 = uVar2 >> 1;
      if (uVar2 + (uVar2 >> 1) <= uVar7) {
        uVar8 = 1;
      }
      uVar7 = FUN_005c9310(uVar8 + uVar2);
      puVar1 = (uint *)(param_1 + 4);
      if (uVar7 != *puVar1) {
        param_2 = puVar1;
        FUN_005d2b00(uVar7);
        puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *puVar1 * 4);
        puVar3 = (undefined4 *)*puVar10;
        while (puVar3 != (undefined4 *)0x0) {
          piVar6 = (int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar3[1] % *param_2) * 4);
          if (*(int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar3[1] % *param_2) * 4) == 0) {
            *piVar6 = (int)puVar10;
            puVar10 = puVar3;
          }
          else {
            *puVar10 = *puVar3;
            *puVar3 = *(undefined4 *)*piVar6;
            *(undefined4 **)*piVar6 = puVar3;
          }
          param_1 = pbStack_14;
          puVar3 = (undefined4 *)*puVar10;
        }
      }
    }
    piStack_18[1] = uStack_1c;
    iVar4 = *(int *)(param_1 + 0x14);
    uVar7 = *(uint *)(param_1 + 4);
    piVar6 = (int *)(iVar4 + (uStack_1c % uVar7) * 4);
    if ((int *)*piVar6 == (int *)0x0) {
      piVar9 = (int *)(iVar4 + uVar7 * 4);
      if (*piVar9 != 0) {
        *(int **)(iVar4 + (*(uint *)(*piVar9 + 4) % uVar7) * 4) = piStack_18;
      }
      *piVar6 = (int)piVar9;
      *piStack_18 = *piVar9;
    }
    else {
      *piStack_18 = *(int *)*piVar6;
      piVar9 = (int *)*piVar6;
    }
    *piVar9 = (int)piStack_18;
    *(int *)(pbStack_14 + 8) = *(int *)(pbStack_14 + 8) + 1;
    ExceptionList = pvStack_10;
    return piStack_20;
  }
  ExceptionList = pvStack_10;
  return (int *)param_2 + 2;
}



/* FUNCTION 20207 ; VA 0x00a2b8e0 ; FUN_00a2b8e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __thiscall FUN_00a2b8e0(byte *param_1,int *param_2)

{
  uint uVar1;
  uint uVar2;
  undefined4 *puVar3;
  uint uVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  undefined4 *puVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dc968;
  pvStack_10 = ExceptionList;
  uVar4 = param_2[1];
  iVar5 = *param_2;
  uVar7 = uVar4;
  if (((int)uVar4 < 1) && ((int)uVar4 < 0)) {
    uVar7 = ~uVar4;
  }
  uVar7 = (uVar7 >> 2) + uVar7 * 0x40 + iVar5 ^ uVar7;
  ExceptionList = &pvStack_10;
  FUN_00606ff0(&param_2,uVar7,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (int *)0x0) {
    uStack_8 = 0;
    FUN_00a2def0();
    _DAT_00000010 = 0;
    _DAT_00000014 = 0;
    uVar2 = *(uint *)(param_1 + 8);
    uVar1 = uVar2 + 1;
    _DAT_00000008 = iVar5;
    _DAT_0000000c = uVar4;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar4 = FUN_005c9310(uVar1);
      if (uVar4 <= *(uint *)(param_1 + 4)) {
        uVar4 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar4);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar1) {
      param_2 = (int *)0x1;
      uVar4 = uVar2 >> 1;
      if ((uVar2 >> 1) + uVar2 <= uVar1) {
        uVar4 = 1;
      }
      iVar5 = FUN_005c9310(uVar4 + uVar2);
      if (iVar5 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar5);
        puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar3 = (undefined4 *)*puVar8;
        while (puVar3 != (undefined4 *)0x0) {
          piVar6 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar6 = (int)puVar8;
            puVar8 = puVar3;
          }
          else {
            *puVar8 = *puVar3;
            *puVar3 = *(undefined4 *)*piVar6;
            *(undefined4 **)*piVar6 = puVar3;
          }
          puVar3 = (undefined4 *)*puVar8;
        }
      }
    }
    uVar4 = uVar7 % *(uint *)(param_1 + 4);
    piVar6 = *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
    puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
    _DAT_00000004 = uVar7;
    if (piVar6 == (int *)0x0) {
      piVar6 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar6 != 0) {
        *(undefined4 *)
         (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar6 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
      }
      *puVar8 = piVar6;
      _DAT_00000000 = *piVar6;
    }
    else {
      _DAT_00000000 = *piVar6;
      piVar6 = (int *)*puVar8;
    }
    *piVar6 = 0;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return (int *)&DAT_00000008;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 20208 ; VA 0x00a2bab0 ; FUN_00a2bab0 */

int * __thiscall FUN_00a2bab0(byte *param_1,int *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined **ppuVar4;
  uint uVar5;
  int iVar6;
  undefined **ppuVar7;
  uint uVar8;
  int *piVar9;
  uint uVar10;
  undefined4 *puVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dc988;
  pvStack_10 = ExceptionList;
  uVar5 = param_2[1];
  iVar6 = *param_2;
  uVar10 = uVar5;
  if (((int)uVar5 < 1) && ((int)uVar5 < 0)) {
    uVar10 = ~uVar5;
  }
  uVar10 = (uVar10 >> 2) + uVar10 * 0x40 + iVar6 ^ uVar10;
  ExceptionList = &pvStack_10;
  FUN_00606ff0(&param_2,uVar10,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (int *)0x0) {
    uStack_8 = 0;
    piVar3 = (int *)FUN_01674e20(0x28);
    *piVar3 = 0;
    piVar3[1] = 0;
    piVar3[4] = 0;
    piVar3[5] = 0;
    piVar3[6] = 0;
    piVar3[7] = 0;
    piVar3[8] = 0;
    piVar3[9] = 0;
    piVar3[2] = iVar6;
    piVar3[3] = uVar5;
    *(undefined *)(piVar3 + 4) = 0;
    param_2 = (int *)0xb;
    ppuVar4 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2);
    ppuVar7 = ppuVar4 + -1;
    if (ppuVar4 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar7 = ppuVar4;
    }
    piVar3[5] = (int)*ppuVar7;
    piVar3[6] = 0;
    piVar3[7] = 0x3f800000;
    piVar3[8] = 0;
    piVar3[9] = 0;
    uVar1 = *(uint *)(param_1 + 8);
    uVar5 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar5 = FUN_005c9310(uVar5);
      if (uVar5 <= *(uint *)(param_1 + 4)) {
        uVar5 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar5);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar5) {
      param_2 = (int *)0x1;
      uVar8 = uVar1 >> 1;
      if (uVar1 + (uVar1 >> 1) <= uVar5) {
        uVar8 = 1;
      }
      iVar6 = FUN_005c9310(uVar8 + uVar1);
      if (iVar6 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar6);
        puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar11;
        while (puVar2 != (undefined4 *)0x0) {
          piVar9 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar9 = (int)puVar11;
            puVar11 = puVar2;
          }
          else {
            *puVar11 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar9;
            *(undefined4 **)*piVar9 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar11;
        }
      }
    }
    piVar3[1] = uVar10;
    uVar10 = uVar10 % *(uint *)(param_1 + 4);
    piVar9 = *(int **)(*(int *)(param_1 + 0x14) + uVar10 * 4);
    puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar10 * 4);
    if (piVar9 == (int *)0x0) {
      piVar9 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar9 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar9 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar3;
      }
      *puVar11 = piVar9;
      *piVar3 = *piVar9;
    }
    else {
      *piVar3 = *piVar9;
      piVar9 = (int *)*puVar11;
    }
    *piVar9 = (int)piVar3;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return piVar3 + 2;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 20209 ; VA 0x00a2bcf0 ; FUN_00a2bcf0 */

int * __thiscall FUN_00a2bcf0(byte *param_1,int *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined **ppuVar4;
  uint uVar5;
  int iVar6;
  undefined **ppuVar7;
  uint uVar8;
  int *piVar9;
  uint uVar10;
  undefined4 *puVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dc9a8;
  pvStack_10 = ExceptionList;
  uVar5 = param_2[1];
  iVar6 = *param_2;
  uVar10 = uVar5;
  if (((int)uVar5 < 1) && ((int)uVar5 < 0)) {
    uVar10 = ~uVar5;
  }
  uVar10 = (uVar10 >> 2) + uVar10 * 0x40 + iVar6 ^ uVar10;
  ExceptionList = &pvStack_10;
  FUN_00606ff0(&param_2,uVar10,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (int *)0x0) {
    uStack_8 = 0;
    piVar3 = (int *)FUN_01674e20(0x28);
    *piVar3 = 0;
    piVar3[1] = 0;
    piVar3[4] = 0;
    piVar3[5] = 0;
    piVar3[6] = 0;
    piVar3[7] = 0;
    piVar3[8] = 0;
    piVar3[9] = 0;
    piVar3[2] = iVar6;
    piVar3[3] = uVar5;
    *(undefined *)(piVar3 + 4) = 0;
    param_2 = (int *)0xb;
    ppuVar4 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2);
    ppuVar7 = ppuVar4 + -1;
    if (ppuVar4 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar7 = ppuVar4;
    }
    piVar3[5] = (int)*ppuVar7;
    piVar3[6] = 0;
    piVar3[7] = 0x3f800000;
    piVar3[8] = 0;
    piVar3[9] = 0;
    uVar1 = *(uint *)(param_1 + 8);
    uVar5 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar5 = FUN_005c9310(uVar5);
      if (uVar5 <= *(uint *)(param_1 + 4)) {
        uVar5 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar5);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar5) {
      param_2 = (int *)0x1;
      uVar8 = uVar1 >> 1;
      if (uVar1 + (uVar1 >> 1) <= uVar5) {
        uVar8 = 1;
      }
      iVar6 = FUN_005c9310(uVar8 + uVar1);
      if (iVar6 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar6);
        puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar11;
        while (puVar2 != (undefined4 *)0x0) {
          piVar9 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar9 = (int)puVar11;
            puVar11 = puVar2;
          }
          else {
            *puVar11 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar9;
            *(undefined4 **)*piVar9 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar11;
        }
      }
    }
    piVar3[1] = uVar10;
    uVar10 = uVar10 % *(uint *)(param_1 + 4);
    piVar9 = *(int **)(*(int *)(param_1 + 0x14) + uVar10 * 4);
    puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar10 * 4);
    if (piVar9 == (int *)0x0) {
      piVar9 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar9 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar9 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar3;
      }
      *puVar11 = piVar9;
      *piVar3 = *piVar9;
    }
    else {
      *piVar3 = *piVar9;
      piVar9 = (int *)*puVar11;
    }
    *piVar9 = (int)piVar3;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return piVar3 + 2;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 20210 ; VA 0x00a2bf30 ; FUN_00a2bf30 */

int * __thiscall FUN_00a2bf30(byte *param_1,int *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined **ppuVar4;
  uint uVar5;
  int iVar6;
  undefined **ppuVar7;
  uint uVar8;
  int *piVar9;
  uint uVar10;
  undefined4 *puVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dc9c8;
  pvStack_10 = ExceptionList;
  uVar5 = param_2[1];
  iVar6 = *param_2;
  uVar10 = uVar5;
  if (((int)uVar5 < 1) && ((int)uVar5 < 0)) {
    uVar10 = ~uVar5;
  }
  uVar10 = (uVar10 >> 2) + uVar10 * 0x40 + iVar6 ^ uVar10;
  ExceptionList = &pvStack_10;
  FUN_00606ff0(&param_2,uVar10,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (int *)0x0) {
    uStack_8 = 0;
    piVar3 = (int *)FUN_01674e20(0x28);
    *piVar3 = 0;
    piVar3[1] = 0;
    piVar3[4] = 0;
    piVar3[5] = 0;
    piVar3[6] = 0;
    piVar3[7] = 0;
    piVar3[8] = 0;
    piVar3[9] = 0;
    piVar3[2] = iVar6;
    piVar3[3] = uVar5;
    *(undefined *)(piVar3 + 4) = 0;
    param_2 = (int *)0xb;
    ppuVar4 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2);
    ppuVar7 = ppuVar4 + -1;
    if (ppuVar4 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar7 = ppuVar4;
    }
    piVar3[5] = (int)*ppuVar7;
    piVar3[6] = 0;
    piVar3[7] = 0x3f800000;
    piVar3[8] = 0;
    piVar3[9] = 0;
    uVar1 = *(uint *)(param_1 + 8);
    uVar5 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar5 = FUN_005c9310(uVar5);
      if (uVar5 <= *(uint *)(param_1 + 4)) {
        uVar5 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar5);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar5) {
      param_2 = (int *)0x1;
      uVar8 = uVar1 >> 1;
      if (uVar1 + (uVar1 >> 1) <= uVar5) {
        uVar8 = 1;
      }
      iVar6 = FUN_005c9310(uVar8 + uVar1);
      if (iVar6 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar6);
        puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar11;
        while (puVar2 != (undefined4 *)0x0) {
          piVar9 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar9 = (int)puVar11;
            puVar11 = puVar2;
          }
          else {
            *puVar11 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar9;
            *(undefined4 **)*piVar9 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar11;
        }
      }
    }
    piVar3[1] = uVar10;
    uVar10 = uVar10 % *(uint *)(param_1 + 4);
    piVar9 = *(int **)(*(int *)(param_1 + 0x14) + uVar10 * 4);
    puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar10 * 4);
    if (piVar9 == (int *)0x0) {
      piVar9 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar9 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar9 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar3;
      }
      *puVar11 = piVar9;
      *piVar3 = *piVar9;
    }
    else {
      *piVar3 = *piVar9;
      piVar9 = (int *)*puVar11;
    }
    *piVar9 = (int)piVar3;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return piVar3 + 2;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 20211 ; VA 0x00a2c170 ; FUN_00a2c170 */

int * __thiscall FUN_00a2c170(byte *param_1,int *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dc9e8;
  pvStack_10 = ExceptionList;
  uVar4 = param_2[1];
  iVar5 = *param_2;
  uVar8 = uVar4;
  if (((int)uVar4 < 1) && ((int)uVar4 < 0)) {
    uVar8 = ~uVar4;
  }
  uVar8 = (uVar8 >> 2) + uVar8 * 0x40 + iVar5 ^ uVar8;
  ExceptionList = &pvStack_10;
  FUN_00606ff0(&param_2,uVar8,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (int *)0x0) {
    uStack_8 = 0;
    piVar3 = (int *)FUN_01674e20(0x18);
    *piVar3 = 0;
    piVar3[1] = 0;
    piVar3[4] = 0;
    piVar3[5] = 0;
    piVar3[3] = uVar4;
    piVar7 = piVar3 + 4;
    piVar3[2] = iVar5;
    if (piVar7 != (int *)0x0) {
      piVar7[0] = 0;
      piVar7[1] = 0;
    }
    uVar1 = *(uint *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar4 = FUN_005c9310(uVar4);
      if (uVar4 <= *(uint *)(param_1 + 4)) {
        uVar4 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar4);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar4) {
      param_2 = (int *)0x1;
      uVar6 = uVar1 >> 1;
      if (uVar1 + (uVar1 >> 1) <= uVar4) {
        uVar6 = 1;
      }
      iVar5 = FUN_005c9310(uVar6 + uVar1);
      if (iVar5 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar5);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar9;
        while (puVar2 != (undefined4 *)0x0) {
          piVar7 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar7 = (int)puVar9;
            puVar9 = puVar2;
          }
          else {
            *puVar9 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar7;
            *(undefined4 **)*piVar7 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar9;
        }
      }
    }
    piVar3[1] = uVar8;
    uVar8 = uVar8 % *(uint *)(param_1 + 4);
    piVar7 = *(int **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (piVar7 == (int *)0x0) {
      piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar7 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar3;
      }
      *puVar9 = piVar7;
      *piVar3 = *piVar7;
    }
    else {
      *piVar3 = *piVar7;
      piVar7 = (int *)*puVar9;
    }
    *piVar7 = (int)piVar3;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return piVar3 + 2;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 20212 ; VA 0x00a2c360 ; FUN_00a2c360 */

undefined4 * __fastcall FUN_00a2c360(int param_1)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined auStack_134 [4];
  undefined4 uStack_130;
  undefined *puStack_12c;
  char *pcStack_128;
  undefined *puStack_124;
  undefined *puStack_120;
  undefined *puStack_11c;
  char *pcStack_118;
  undefined4 **ppuStack_114;
  undefined auStack_108 [24];
  char acStack_f0 [16];
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined8 uStack_c8;
  undefined uStack_c0;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined8 uStack_98;
  undefined uStack_90;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined auStack_60 [24];
  undefined auStack_48 [16];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 *puStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined *puStack_1c;
  undefined4 *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017dca6a;
  pvStack_10 = ExceptionList;
  ppuStack_114 = &puStack_30;
  pcStack_118 = (char *)0xa2c38b;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  iStack_8 = 0;
  if ((puStack_30 != (undefined4 *)0x0) && (*(char *)((int)puStack_30 + 0x1dd) != '\0')) {
    puStack_18 = puStack_30 + 3;
    ppuStack_114 = (undefined4 **)0xa2c3b7;
    puStack_30 = (undefined4 *)FUN_005f4f20();
    if (puStack_30 != (undefined4 *)0x0) {
      if (*(int *)(param_1 + 0x30) < 1) {
        uStack_28 = *(undefined4 *)(param_1 + 0x28);
        uStack_24 = *(undefined4 *)(param_1 + 0x2c);
        uStack_20 = *(undefined4 *)(param_1 + 0x20);
        puStack_1c = *(undefined **)(param_1 + 0x24);
        pcStack_118 = (char *)0xa2c40b;
        ppuStack_114 = (undefined4 **)puStack_30;
        FUN_008f7870();
        ppuStack_114 = (undefined4 **)0xa2c415;
        cVar3 = FUN_008f2030();
        if ((cVar3 == '\0') && (DAT_01d84e8e != 0)) {
          ppuStack_114 = (undefined4 **)0x0;
          puStack_11c = (undefined *)(uint)DAT_01d84e8e;
          pcStack_118 = 
          "PackageService::clearPackageHashDataRequests doesn\'t have a datamodel write lock!";
          puStack_120 = (char *)0xa2c432;
          FUN_016774b0();
        }
        ppuStack_114 = (undefined4 **)&uStack_20;
        pcStack_118 = (char *)0xa2c444;
        FUN_00a2bab0();
        ppuStack_114 = (undefined4 **)&uStack_28;
        pcStack_118 = (char *)0xa2c450;
        puStack_30 = (undefined4 *)FUN_00a2bf30();
        if (puStack_30[4] != 0) {
          ppuStack_114 = (undefined4 **)0x0;
          pcStack_118 = (char *)(puStack_30[7] + puStack_30[3] * 4);
          puStack_11c = (undefined *)0xa2c46c;
          FUN_008b20f0();
          puVar4 = (undefined4 *)puStack_30[7];
          puStack_30 = puVar4 + puStack_30[3];
          for (; puVar4 != puStack_30; puVar4 = puVar4 + 1) {
            *puVar4 = 0;
          }
        }
      }
      else {
        ppuStack_114 = (undefined4 **)(*(int *)(param_1 + 0x30) + -1);
        pcStack_118 = *(char **)(param_1 + 0x2c);
        puStack_11c = *(undefined **)(param_1 + 0x28);
        puStack_1c = auStack_134;
        FUN_0054ef60(param_1 + 8);
        puStack_30 = (undefined4 *)FUN_00a331a0();
      }
    }
    puVar4 = puStack_18;
    if (*(int *)(param_1 + 0x30) == 0) {
      ppuStack_114 = (undefined4 **)puStack_18;
      pcStack_118 = (char *)0xa2c4a0;
      cVar3 = FUN_00983210();
      if (cVar3 == '\0') {
        ppuStack_114 = (undefined4 **)(param_1 + 0x34);
        if (0xf < *(uint *)(param_1 + 0x48)) {
          ppuStack_114 = *(undefined4 ***)(param_1 + 0x34);
        }
        pcStack_118 = *(char **)(param_1 + 0x2c);
        puStack_11c = *(undefined **)(param_1 + 0x28);
        puStack_120 = *(undefined **)(param_1 + 0x24);
        puStack_124 = *(undefined **)(param_1 + 0x20);
        pcStack_128 = "Request Package %lld V%lld Web Copy Error: %s.";
        puStack_12c = (undefined *)0x3;
        uStack_130 = 0xa2c523;
        puStack_30 = (undefined4 *)FUN_0086f2f0();
      }
      else {
        ppuStack_114 = (undefined4 **)puVar4;
        pcStack_118 = (char *)0xa2c4ad;
        puStack_30 = (undefined4 *)FUN_005e5c70();
        puStack_18 = puStack_30;
        if (puStack_30 != (undefined4 *)0x0) {
          ppuStack_114 = (undefined4 **)(param_1 + 0x34);
          if (0xf < *(uint *)(param_1 + 0x48)) {
            ppuStack_114 = *(undefined4 ***)(param_1 + 0x34);
          }
          pcStack_118 = *(char **)(param_1 + 0x2c);
          puStack_12c = auStack_60;
          puStack_11c = *(undefined **)(param_1 + 0x28);
          puStack_120 = *(undefined **)(param_1 + 0x24);
          puStack_124 = *(undefined **)(param_1 + 0x20);
          pcStack_128 = "Request Package %lld V%lld Web Copy Error: %s.";
          uStack_130 = 0xa2c4de;
          ppuStack_114 = (undefined4 **)FUN_01675640();
          pcStack_118 = (char *)0x3;
          iStack_8._0_1_ = 1;
          puStack_11c = (undefined *)0xa2c4f0;
          FUN_0098c2c0();
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          ppuStack_114 = (undefined4 **)0xa2c4fc;
          puStack_30 = (undefined4 *)FUN_005507b0();
        }
      }
      if (DAT_01d65e20 == '\0') {
        ppuStack_114 = (undefined4 **)0x1a;
        pcStack_118 = "PackageRequestWebCopyError";
        uStack_38 = 0;
        uStack_34 = 0xf;
        auStack_48[0] = 0;
        puStack_11c = (undefined *)0xa2c554;
        FUN_005542c0();
        ppuStack_114 = (undefined4 **)0x0;
        puStack_11c = auStack_48;
        iStack_8._0_1_ = 2;
        pcStack_118 = (char *)0x1;
        puStack_120 = (undefined *)0xa2c565;
        FUN_008783f0();
        iStack_8._0_1_ = 0;
        ppuStack_114 = (undefined4 **)0xa2c574;
        FUN_005507b0();
        ppuStack_114 = *(undefined4 ***)(param_1 + 0x24);
        puStack_11c = auStack_48;
        pcStack_118 = *(char **)(param_1 + 0x20);
        puStack_120 = (undefined *)0xa2c583;
        puVar4 = (undefined4 *)FUN_0058c590();
        ppuStack_114 = (undefined4 **)0x7;
        pcStack_118 = "AssetId";
        iStack_8._0_1_ = 3;
        uStack_e0 = 0;
        uStack_dc = 0xf;
        acStack_f0[0] = '\0';
        puStack_11c = (undefined *)0xa2c5b9;
        FUN_005542c0();
        uStack_d8 = *puVar4;
        uStack_d4 = puVar4[1];
        uStack_d0 = puVar4[2];
        uStack_cc = puVar4[3];
        uStack_c8 = *(undefined8 *)(puVar4 + 4);
        puVar4[4] = 0;
        puVar4[5] = 0xf;
        *(undefined *)puVar4 = 0;
        iStack_8._0_1_ = 5;
        ppuStack_114 = (undefined4 **)0xa2c601;
        FUN_005507b0();
        ppuStack_114 = *(undefined4 ***)(param_1 + 0x2c);
        puStack_11c = auStack_108;
        pcStack_118 = *(char **)(param_1 + 0x28);
        puStack_120 = (undefined *)0xa2c613;
        puVar4 = (undefined4 *)FUN_0058c590();
        ppuStack_114 = (undefined4 **)0xa;
        pcStack_118 = "VersionNum";
        iStack_8._0_1_ = 6;
        uStack_b0 = 0;
        uStack_ac = 0xf;
        uStack_c0 = 0;
        puStack_11c = (undefined *)0xa2c649;
        FUN_005542c0();
        uStack_a8 = *puVar4;
        uStack_a4 = puVar4[1];
        uStack_a0 = puVar4[2];
        uStack_9c = puVar4[3];
        uStack_98 = *(undefined8 *)(puVar4 + 4);
        puVar4[4] = 0;
        puVar4[5] = 0xf;
        *(undefined *)puVar4 = 0;
        iStack_8._0_1_ = 8;
        ppuStack_114 = (undefined4 **)0xa2c694;
        FUN_005507b0();
        uStack_80 = 0;
        uStack_7c = 0xf;
        uStack_90 = 0;
        ppuStack_114 = (undefined4 **)0x5;
        pcStack_118 = "Error";
        puStack_11c = (undefined *)0xa2c6bb;
        FUN_005542c0();
        ppuStack_114 = (undefined4 **)(param_1 + 0x34);
        iStack_8._0_1_ = 9;
        pcStack_118 = (char *)0xa2c6cb;
        FUN_0054ef60();
        ppuStack_114 = (undefined4 **)&uStack_11;
        iStack_8._0_1_ = 10;
        pcStack_118 = &uStack_11;
        puStack_11c = &uStack_11;
        puStack_120 = (undefined *)0xb;
        puStack_124 = auStack_60;
        pcStack_128 = acStack_f0;
        puStack_12c = (undefined *)0xa2c6f0;
        FUN_006370e0();
        ppuStack_114 = (undefined4 **)FUN_005509f0;
        pcStack_118 = (char *)0x3;
        puStack_11c = (undefined *)0x30;
        puStack_120 = acStack_f0;
        iStack_8 = CONCAT31(iStack_8._1_3_,0xc);
        puStack_124 = (undefined *)0xa2c709;
        FUN_016f32d1();
        ppuStack_114 = (undefined4 **)0x0;
        pcStack_118 = (char *)0x0;
        puStack_11c = (undefined *)0x0;
        FUN_0060e7f0(auStack_60);
        FUN_0087c510("Studio","PackageRequestWebCopy","Error");
        ppuStack_114 = (undefined4 **)0xa2c73c;
        puStack_30 = (undefined4 *)FUN_0056cfd0();
      }
    }
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_2c + 1;
    iVar2 = *piVar1;
    puStack_30 = (undefined4 *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      ppuStack_114 = (undefined4 **)0xa2c755;
      puStack_30 = (undefined4 *)(**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piStack_2c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        ppuStack_114 = (undefined4 **)0xa2c764;
        puStack_30 = (undefined4 *)(**(code **)(*piStack_2c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puStack_30;
}



/* FUNCTION 20213 ; VA 0x00a2c780 ; FUN_00a2c780 */

int __thiscall
FUN_00a2c780(int param_1,int param_2,int *param_3,int *param_4,undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined uVar4;
  double dVar5;
  undefined *puVar6;
  int iVar7;
  double *pdVar8;
  uint uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined8 uStack_60;
  undefined4 uStack_58;
  uint uStack_50;
  undefined4 uStack_40;
  uint uStack_3c;
  int *piStack_38;
  undefined8 uStack_34;
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dcb5b;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff34;
  piStack_38 = (int *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  if (param_2 != 2) {
    if (param_2 == 1) {
      if ((param_3 != (int *)0x0) && (param_3[1] - *param_3 >> 3 == 1)) {
        ExceptionList = &pvStack_10;
        puStack_14 = &stack0xffffff34;
        FUN_00557fc0();
        uStack_8._0_1_ = 0x10;
        uStack_34 = 0.0;
        if (DAT_01d65e08 != '\0') {
          pdVar8 = (double *)FUN_016830f0();
          uStack_34 = *pdVar8 - *(double *)(param_1 + 0x98);
        }
        FUN_00a32890(uStack_58);
        uStack_1c = 0;
        uStack_18 = 0xf;
        uStack_2c = uStack_2c & 0xffffff00;
        FUN_005542c0();
        uStack_8._0_1_ = 0x11;
        FUN_008a1410();
        uStack_8._0_1_ = 0x12;
        FUN_00a13760();
        FUN_00550b30();
        uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
        FUN_005507b0();
        if ((int)uStack_34 == 0) {
          pdVar8 = (double *)FUN_00a29960();
          piStack_38 = uStack_34._4_4_;
          dVar5 = *pdVar8;
          *(undefined4 *)pdVar8 = 0;
          *(undefined4 *)((int)pdVar8 + 4) = 0;
          if (uStack_34._4_4_ != (int *)0x0) {
            LOCK();
            iVar7 = uStack_34._4_4_[1] + -1;
            uStack_34._4_4_[1] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              puVar3 = (undefined4 *)*uStack_34._4_4_;
              uStack_34 = dVar5;
              (*(code *)*puVar3)();
              LOCK();
              piVar1 = piStack_38 + 2;
              iVar7 = *piVar1;
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              dVar5 = uStack_34;
              if (iVar7 == 1) {
                (**(code **)(*piStack_38 + 4))();
                dVar5 = uStack_34;
              }
            }
          }
          uStack_34 = dVar5;
          FUN_00550b30();
          uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
          FUN_008a65e0();
        }
        uStack_8 = 0x15;
        FUN_0054ef60(param_1);
        FUN_00eb3e70();
        FUN_00eb3f40();
        if (DAT_01d65e10 != '\0') {
          uStack_40 = 0;
          uStack_3c = 0xf;
          uStack_50 = uStack_50 & 0xffffff00;
          FUN_005542c0();
          uStack_8._0_1_ = 0x19;
          FUN_008783f0();
          uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
          FUN_005507b0();
        }
        FUN_00557fc0();
        FUN_0096e490();
        FUN_00550b30();
        FUN_00550b30();
        FUN_00550b30();
        iVar7 = FUN_00550b30();
        ExceptionList = pvStack_10;
        return iVar7;
      }
      ExceptionList = &pvStack_10;
      puVar6 = &stack0xffffff34;
      if (DAT_01d6fec8 != '\0') {
        uStack_40 = 0;
        uStack_3c = 0xf;
        uStack_50 = uStack_50 & 0xffffff00;
        ExceptionList = &pvStack_10;
        FUN_005542c0();
        uStack_8._0_1_ = 0xf;
        FUN_008783f0();
        uStack_8._0_1_ = 1;
        FUN_005507b0();
        puVar6 = puStack_14;
      }
      puStack_14 = puVar6;
      FUN_005542c0("Invalid instance",0x10);
      iVar7 = FUN_005e65e0();
      goto LAB_00a2cfc5;
    }
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffff34;
    FUN_0151f6f0();
    uStack_8._0_1_ = 10;
    FUN_0151f850();
    FUN_0151f850();
    FUN_01675640();
    uStack_8._0_1_ = 0xb;
    FUN_0151f850();
    uStack_8._0_1_ = 10;
    FUN_005507b0();
    FUN_0151f850();
    uStack_1c = 0;
    uStack_18 = 0xf;
    uStack_2c = uStack_2c & 0xffffff00;
    FUN_005542c0();
    uStack_8._0_1_ = 0xc;
    FUN_01520d20();
    uStack_8._0_1_ = 10;
    FUN_005507b0();
    if (DAT_01d65e10 == '\0') {
LAB_00a2cc26:
      if (DAT_01d6fec8 != '\0') goto LAB_00a2cc2f;
    }
    else {
      if (DAT_01d6fec8 == '\0') {
        uStack_1c = 0;
        uStack_18 = 0xf;
        uStack_2c = uStack_2c & 0xffffff00;
        FUN_005542c0();
        uStack_8._0_1_ = 0xd;
        FUN_008783f0();
        uStack_8._0_1_ = 10;
        FUN_005507b0();
        goto LAB_00a2cc26;
      }
LAB_00a2cc2f:
      uStack_1c = 0;
      uStack_18 = 0xf;
      uStack_2c = uStack_2c & 0xffffff00;
      FUN_005542c0();
      uStack_8._0_1_ = 0xe;
      FUN_008783f0();
      uStack_8._0_1_ = 10;
      FUN_005507b0();
    }
    FUN_005542c0("Http unknown error",0x12);
    FUN_005e65e0();
    iVar7 = FUN_0151f7f0();
    goto LAB_00a2cfc5;
  }
  uStack_60 = 0xf00000000;
  uStack_70 = uStack_70 & 0xffffff00;
  ExceptionList = &pvStack_10;
  puStack_14 = &stack0xffffff34;
  FUN_005542c0();
  if (DAT_01d65e08 == '\0') {
    uStack_8._0_1_ = 4;
    piStack_38 = (int *)0x2;
  }
  else {
    uStack_8._0_1_ = 3;
    piStack_38 = (int *)0x1;
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  uStack_2c = uStack_2c & 0xffffff00;
  FUN_0058a190();
  FUN_00554150();
  FUN_00554150();
  FUN_005507b0();
  uStack_70 = uStack_2c;
  uStack_8._0_1_ = 2;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_6c = uStack_28;
  uStack_68 = uStack_24;
  uStack_64 = uStack_20;
  uStack_60 = CONCAT44(uStack_18,uStack_1c);
  uStack_1c = 0;
  uStack_18 = 0xf;
  FUN_005507b0();
  FUN_0151f6f0();
  uStack_8._0_1_ = 5;
  FUN_0151f850();
  FUN_0151f850();
  FUN_01675640();
  uStack_8._0_1_ = 6;
  FUN_0151f850();
  uStack_8._0_1_ = 5;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 5;
  if (0xf < uStack_3c) {
    if ((0xfff < uStack_3c + 1) && (0x1f < (uStack_50 - *(int *)(uStack_50 - 4)) - 4)) {
      uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  FUN_0151f850();
  uStack_1c = 0;
  uStack_18 = 0xf;
  uStack_2c = uStack_2c & 0xffffff00;
  FUN_005542c0();
  uStack_8._0_1_ = 7;
  FUN_01520d20();
  uStack_8._0_1_ = 5;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 5;
  if (0xf < uStack_18) {
    if ((0xfff < uStack_18 + 1) && (0x1f < (uStack_2c - *(int *)(uStack_2c - 4)) - 4)) {
      uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  if (DAT_01d65e10 == '\0') {
LAB_00a2ca2c:
    if (DAT_01d6fec8 != '\0') goto LAB_00a2ca35;
  }
  else {
    if (DAT_01d6fec8 == '\0') {
      uStack_1c = 0;
      uStack_18 = 0xf;
      uStack_2c = uStack_2c & 0xffffff00;
      FUN_005542c0();
      uStack_8._0_1_ = 8;
      FUN_008783f0();
      uStack_8._0_1_ = 5;
      FUN_005507b0();
      goto LAB_00a2ca2c;
    }
LAB_00a2ca35:
    uStack_1c = 0;
    uStack_18 = 0xf;
    uStack_2c = uStack_2c & 0xffffff00;
    FUN_005542c0();
    uStack_8._0_1_ = 9;
    FUN_008783f0();
    uStack_8._0_1_ = 5;
    FUN_005507b0();
  }
  FUN_0054ef60(&uStack_70);
  FUN_005e65e0();
  iVar7 = FUN_0151f7f0();
  if (0xf < uStack_60._4_4_) {
    if ((0xfff < uStack_60._4_4_ + 1) && (0x1f < (uStack_70 - *(int *)(uStack_70 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    iVar7 = FUN_01674ea0();
  }
LAB_00a2cfc5:
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar7 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar7 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar7 = (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar7 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 20214 ; VA 0x00a2ceb1 ; Catch@00a2ceb1 */

undefined4 Catch_00a2ceb1(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  undefined uVar2;
  
  *(undefined4 *)(unaff_EBP + -0x3c) = 0;
  *(undefined4 *)(unaff_EBP + -0x38) = 0xf;
  *(undefined *)(unaff_EBP + -0x4c) = 0;
  FUN_005542c0("PackageErrorCode-FailedToSetPackageRoot",0x27);
  *(undefined *)(unaff_EBP + -4) = 0x18;
  FUN_008783f0(unaff_EBP + -0x4c,1,0);
  *(undefined *)(unaff_EBP + -4) = 0x17;
  FUN_005507b0();
  if (DAT_01d84e8e != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0xb4) + 4))();
    FUN_016774b0(DAT_01d84e8e,"Packages Asset error: %s",uVar1);
  }
  uVar2 = 0;
  FUN_005542c0("Failed to set package root",0x1a);
  FUN_005e65e0(uVar2);
  return 0xa2ce7e;
}



/* FUNCTION 20215 ; VA 0x00a2d040 ; FUN_00a2d040 */

void __thiscall FUN_00a2d040(undefined4 *param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  uint uVar8;
  int *piVar9;
  uint in_stack_00000018;
  undefined4 uVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  piVar9 = (int *)param_1[1];
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (piVar9 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar9[2] = piVar9[2] + 1;
    UNLOCK();
    piVar9 = (int *)param_1[1];
  }
  uVar2 = param_1[2];
  uVar3 = *param_1;
  uVar4 = param_1[3];
  uVar5 = param_1[4];
  uVar6 = param_1[5];
  piVar1 = piVar9 + 2;
  if (piVar9 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar10 = 0;
  if (piVar9 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00a28a50(uVar3,piVar9,uVar2,uVar4,uVar5,uVar6);
  if (piVar9 != (int *)0x0) {
    LOCK();
    iVar7 = piVar9[2] + -1;
    piVar9[2] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)(*piVar9 + 4))(uVar10);
    }
    piVar1 = piVar9 + 2;
    LOCK();
    iVar7 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar7 == 1) {
      (**(code **)(*piVar9 + 4))();
    }
  }
  FUN_0151ded0();
  FUN_0054ef60(&param_2);
  FUN_005e65e0();
  if (0xf < in_stack_00000018) {
    uVar8 = in_stack_00000018 + 1;
    iVar7 = param_2;
    if (0xfff < uVar8) {
      iVar7 = *(int *)(param_2 + -4);
      uVar8 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20216 ; VA 0x00a2d170 ; FUN_00a2d170 */

int __thiscall FUN_00a2d170(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  int *piVar9;
  undefined4 uVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  piVar9 = (int *)param_1[1];
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (piVar9 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar9[2] = piVar9[2] + 1;
    UNLOCK();
    piVar9 = (int *)param_1[1];
  }
  uVar3 = param_1[2];
  uVar4 = *param_1;
  uVar5 = param_1[3];
  uVar6 = param_1[4];
  uVar7 = param_1[5];
  piVar1 = piVar9 + 2;
  if (piVar9 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar10 = 0;
  if (piVar9 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00a28900(uVar4,piVar9,uVar3,uVar5,uVar6,uVar7);
  if (piVar9 != (int *)0x0) {
    LOCK();
    iVar8 = piVar9[2] + -1;
    piVar9[2] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)(*piVar9 + 4))(uVar10);
    }
    LOCK();
    iVar8 = piVar9[2] + -1;
    piVar9[2] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)(*piVar9 + 4))();
    }
  }
  FUN_0151ded0();
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar8 = FUN_0096e490(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar9 = param_3 + 1;
    iVar2 = *piVar9;
    iVar8 = *piVar9;
    *piVar9 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar8 = (**(code **)*param_3)();
      LOCK();
      piVar9 = param_3 + 2;
      iVar2 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar8 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar8;
}



/* FUNCTION 20217 ; VA 0x00a2d2b0 ; FUN_00a2d2b0 */

int __fastcall FUN_00a2d2b0(int param_1)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  char cVar4;
  int iVar5;
  undefined **ppuVar6;
  undefined8 uVar7;
  undefined4 auStack_20c [2];
  undefined4 *puStack_204;
  undefined4 uStack_1f8;
  int iStack_1f4;
  undefined8 *puStack_1f0;
  int *piStack_1ec;
  undefined auStack_1dc [16];
  undefined8 uStack_1cc;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined4 uStack_1a8;
  undefined4 uStack_1a4;
  undefined4 uStack_1a0;
  undefined auStack_19c [40];
  undefined4 uStack_174;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined4 uStack_168;
  undefined4 uStack_164;
  undefined4 uStack_160;
  undefined auStack_15c [40];
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined auStack_11c [40];
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined auStack_dc [40];
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined auStack_9c [40];
  undefined8 uStack_74;
  undefined8 uStack_6c;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined auStack_4c [40];
  int iStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dcbc2;
  pvStack_10 = ExceptionList;
  piStack_1ec = &iStack_24;
  puStack_1f0 = (undefined8 *)0xa2d2dc;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00587490();
  uStack_8 = 0;
  if ((iStack_24 != 0) && (*(char *)(iStack_24 + 0x1dd) != '\0')) {
    piStack_1ec = (int *)0x0;
    iStack_1f4 = 0xa2d306;
    puStack_1f0 = (undefined8 *)(param_1 + 0x18);
    uVar7 = FUN_00a16270();
    uStack_1c = (undefined4)((ulonglong)uVar7 >> 0x20);
    uStack_18 = (undefined4)uVar7;
    piStack_1ec = (int *)&uStack_6c;
    uStack_74 = 0;
    puStack_1f0 = &uStack_74;
    uStack_6c = 0;
    iStack_1f4 = 0xa2d32f;
    FUN_00fbd320();
    uStack_1cc = 0;
    uStack_1c4 = 0;
    uStack_1c0 = 0;
    uStack_1bc = 0;
    uStack_1b8 = 0;
    uStack_8._0_1_ = 1;
    if (DAT_01d6fe68 != '\0') {
      puStack_1f0 = (undefined8 *)(param_1 + 0x10);
      iStack_1f4 = param_1 + 8;
      uStack_1f8 = 0xa2d35f;
      piStack_1ec = (int *)(param_1 + 0x18);
      piStack_1ec = (int *)FUN_00fbd8d0();
      puStack_1f0 = (undefined8 *)0xa2d36b;
      FUN_00a2b5b0();
      piStack_1ec = (int *)0xa2d373;
      FUN_00a2b3d0();
    }
    uStack_1b4 = *(undefined4 *)(param_1 + 8);
    uStack_1b0 = *(undefined4 *)(param_1 + 0xc);
    uStack_1ac = *(undefined4 *)(param_1 + 0x10);
    uStack_1a8 = *(undefined4 *)(param_1 + 0x14);
    piStack_1ec = (int *)0x1;
    puStack_14 = auStack_20c;
    uStack_1a4 = uStack_18;
    uStack_1a0 = uStack_1c;
    FUN_00a2a2d0(auStack_1dc);
    uStack_174 = uStack_1b4;
    uStack_170 = uStack_1b0;
    uStack_16c = uStack_1ac;
    uStack_168 = uStack_1a8;
    uStack_164 = uStack_1a4;
    uStack_160 = uStack_1a0;
    FUN_00a2a2d0(auStack_19c);
    uStack_134 = uStack_174;
    uStack_130 = uStack_170;
    uStack_12c = uStack_16c;
    uStack_128 = uStack_168;
    uStack_124 = uStack_164;
    uStack_120 = uStack_160;
    auStack_20c[0] = 0;
    FUN_00a2a2d0(auStack_15c);
    uStack_f4 = uStack_134;
    uStack_f0 = uStack_130;
    uStack_ec = uStack_12c;
    uStack_e8 = uStack_128;
    uStack_e4 = uStack_124;
    uStack_e0 = uStack_120;
    FUN_00a2a2d0(auStack_11c);
    uStack_64 = uStack_f4;
    uStack_60 = uStack_f0;
    uStack_5c = uStack_ec;
    uStack_58 = uStack_e8;
    uStack_54 = uStack_e4;
    uStack_50 = uStack_e0;
    FUN_00a2a2d0(auStack_dc);
    cVar4 = FUN_00585a40(&uStack_64);
    if (cVar4 == '\0') {
      uStack_b4 = uStack_64;
      uStack_b0 = uStack_60;
      uStack_ac = uStack_5c;
      uStack_a8 = uStack_58;
      uStack_a4 = uStack_54;
      uStack_a0 = uStack_50;
      FUN_00a2a2d0(auStack_4c);
      uStack_8._0_1_ = 7;
      puStack_204 = (undefined4 *)FUN_01674e20(0x40);
      if (puStack_204 == (undefined4 *)0x0) {
        puStack_204 = (undefined4 *)0x0;
      }
      else {
        puStack_204[3] = uStack_a8;
        *puStack_204 = uStack_b4;
        puStack_204[4] = uStack_a4;
        puStack_204[1] = uStack_b0;
        puStack_204[5] = uStack_a0;
        puStack_204[2] = uStack_ac;
        FUN_00a2a2d0(auStack_9c);
      }
      FUN_00a2b3d0();
      FUN_00a2b3d0();
      bVar3 = true;
    }
    else {
      FUN_00a2b3d0();
      bVar3 = false;
    }
    FUN_00a2b3d0();
    ppuVar6 = &PTR_FUN_019412fc;
    if (!bVar3) {
      ppuVar6 = (undefined **)0x0;
    }
    *puStack_14 = ppuVar6;
    FUN_00a2b3d0();
    FUN_00a2b3d0();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00a2b3d0();
    FUN_0090ca30();
    piStack_1ec = (int *)0xa2d64a;
    iVar5 = FUN_00a2b3d0();
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_20 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_1ec = (int *)0xa2d663;
      iVar5 = (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_1ec = (int *)0xa2d672;
        iVar5 = (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 20218 ; VA 0x00a2d690 ; FUN_00a2d690 */

int __thiscall FUN_00a2d690(undefined4 *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  char cVar4;
  int iVar5;
  undefined **ppuVar6;
  uint uVar7;
  uint in_stack_00000018;
  undefined4 uVar8;
  undefined auStack_200 [80];
  undefined auStack_1b0 [80];
  undefined auStack_160 [80];
  undefined auStack_110 [80];
  undefined auStack_c0 [80];
  undefined4 uStack_70;
  int iStack_6c;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dcc41;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00587490();
  uStack_8._0_1_ = 1;
  if (((iStack_20 != 0) && (*(char *)(iStack_20 + 0x1dd) != '\0')) &&
     (iVar5 = FUN_005cf2a0(), iStack_18 = iVar5, iVar5 != 0)) {
    puStack_14 = &uStack_70;
    iStack_6c = param_1[1];
    if (iStack_6c != 0) {
      LOCK();
      *(int *)(iStack_6c + 8) = *(int *)(iStack_6c + 8) + 1;
      UNLOCK();
      iStack_6c = param_1[1];
    }
    uStack_70 = *param_1;
    uStack_8._0_1_ = 2;
    FUN_0054ef60(param_1 + 2);
    uStack_50 = param_1[8];
    uStack_4c = param_1[9];
    uStack_48 = param_1[10];
    uStack_44 = param_1[0xb];
    uStack_40 = param_1[0xc];
    uStack_8._0_1_ = 3;
    FUN_0054ef60(&param_2);
    uStack_8._0_1_ = 4;
    FUN_00a29bc0(&uStack_70);
    uStack_8._0_1_ = 5;
    uVar8 = 0;
    FUN_00a29bc0(auStack_200);
    uStack_8._0_1_ = 6;
    FUN_00a29bc0(auStack_1b0);
    uStack_8._0_1_ = 7;
    FUN_00a29bc0(auStack_160);
    uStack_8._0_1_ = 8;
    cVar4 = FUN_00585a40(auStack_c0,uVar8);
    if (cVar4 == '\0') {
      FUN_00a29bc0(auStack_c0);
      uStack_8._0_1_ = 9;
      puStack_14 = (undefined4 *)FUN_01674e20(0x50);
      uStack_8._0_1_ = 10;
      if (puStack_14 != (undefined4 *)0x0) {
        FUN_00a29bc0(auStack_110);
      }
      FUN_00a2a790();
      FUN_00a2a790();
      bVar3 = true;
    }
    else {
      FUN_00a2a790();
      bVar3 = false;
    }
    FUN_00a2a790();
    ppuVar6 = &PTR_FUN_0194130c;
    if (!bVar3) {
      ppuVar6 = (undefined **)0x0;
    }
    FUN_00a2a790(ppuVar6);
    FUN_00a2a790();
    uStack_8._0_1_ = 1;
    FUN_00a2a790();
    iVar5 = FUN_009eef30(ppuVar6);
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if (0xf < in_stack_00000018) {
    uVar7 = in_stack_00000018 + 1;
    iVar5 = param_2;
    if (0xfff < uVar7) {
      iVar5 = *(int *)(param_2 + -4);
      uVar7 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar5 = FUN_01674ea0(iVar5,uVar7);
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 20219 ; VA 0x00a2d900 ; FUN_00a2d900 */

undefined4 __thiscall FUN_00a2d900(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x68);
  }
  return param_1;
}



/* FUNCTION 20220 ; VA 0x00a2d920 ; FUN_00a2d920 */

undefined4 * __thiscall FUN_00a2d920(undefined4 *param_1,byte param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  iVar1 = param_1[0x22];
  *param_1 = boost::detail::shared_state<class_std::shared_ptr<class_RBX::HttpResponse>_>::vftable;
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_0056ea40();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x90);
  }
  return param_1;
}



/* FUNCTION 20221 ; VA 0x00a2d990 ; FUN_00a2d990 */

undefined4 __thiscall FUN_00a2d990(undefined4 param_1,byte param_2)

{
  FUN_00a2b430();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x16c);
  }
  return param_1;
}



/* FUNCTION 20222 ; VA 0x00a2d9c0 ; FUN_00a2d9c0 */

void FUN_00a2d9c0(void)

{
  FUN_00a2b2f0();
  return;
}



/* FUNCTION 20223 ; VA 0x00a2d9d0 ; FUN_00a2d9d0 */

void __fastcall FUN_00a2d9d0(int param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00a2abe0();
  if (*(char *)(param_1 + 0x30) != '\0') {
    *(undefined *)(param_1 + 0x30) = 0;
  }
  iVar1 = *(int *)(param_1 + 0x20);
  uStack_8 = 0;
  FUN_00a2db10(*(undefined4 *)(iVar1 + 4));
  *(int *)(*(int *)(param_1 + 0x20) + 4) = iVar1;
  **(int **)(param_1 + 0x20) = iVar1;
  *(int *)(*(int *)(param_1 + 0x20) + 8) = iVar1;
  *(undefined4 *)(param_1 + 0x24) = 0;
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x20),0x40);
  CloseHandle(*(undefined4 *)(param_1 + 0x1c));
  CloseHandle(*(undefined4 *)(param_1 + 0x14));
  CloseHandle(*(undefined4 *)(param_1 + 0x18));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20224 ; VA 0x00a2da60 ; FUN_00a2da60 */

void FUN_00a2da60(uint *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  uint *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  if (param_1 != param_2) {
    puVar3 = param_1 + 8;
    ExceptionList = &pvStack_10;
    do {
      uVar2 = *puVar3;
      uStack_8 = 0;
      if (uVar2 != 0) {
        if (((uVar2 & 1) == 0) && (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(uVar2 & 0xfffffffe))(puVar3 + 2,puVar3 + 2,2);
        }
        *puVar3 = 0;
      }
      uVar2 = puVar3[-8];
      uStack_8 = 1;
      if (uVar2 != 0) {
        if (((uVar2 & 1) == 0) && (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(uVar2 & 0xfffffffe))(puVar3 + -6,puVar3 + -6,2);
        }
        puVar3[-8] = 0;
      }
      puVar1 = puVar3 + 8;
      puVar3 = puVar3 + 0x10;
    } while (puVar1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20225 ; VA 0x00a2db10 ; FUN_00a2db10 */

void FUN_00a2db10(int *param_1)

{
  char cVar1;
  int *piVar2;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  while (cVar1 == '\0') {
    FUN_00a2db10(param_1[2]);
    piVar2 = (int *)*param_1;
    FUN_00a2abe0();
    if (*(char *)(param_1 + 8) != '\0') {
      *(undefined *)(param_1 + 8) = 0;
    }
    FUN_01674ea0(param_1,0x40);
    param_1 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  return;
}



/* FUNCTION 20226 ; VA 0x00a2db60 ; FUN_00a2db60 */

void FUN_00a2db60(int *param_1)

{
  char cVar1;
  int *piVar2;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  while (cVar1 == '\0') {
    FUN_00a2db60(param_1[2]);
    piVar2 = (int *)*param_1;
    FUN_01674ea0(param_1,0x20);
    param_1 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  return;
}



/* FUNCTION 20227 ; VA 0x00a2dba0 ; FUN_00a2dba0 */

void __fastcall FUN_00a2dba0(undefined4 *param_1)

{
  void **ppvVar1;
  uint uVar2;
  uint *puVar3;
  uint *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  puVar3 = (uint *)*param_1;
  if (puVar3 != (uint *)0x0) {
    puVar4 = (uint *)param_1[1];
    ExceptionList = &pvStack_10;
    ppvVar1 = &pvStack_10;
    if (puVar3 != puVar4) {
      do {
        uVar2 = puVar3[8];
        uStack_8 = 0;
        if (uVar2 != 0) {
          if (((uVar2 & 1) == 0) && (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0)) {
            (**(code **)(uVar2 & 0xfffffffe))(puVar3 + 10,puVar3 + 10,2);
          }
          puVar3[8] = 0;
        }
        uVar2 = *puVar3;
        uStack_8 = 1;
        if (uVar2 != 0) {
          if (((uVar2 & 1) == 0) && (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0)) {
            (**(code **)(uVar2 & 0xfffffffe))(puVar3 + 2,puVar3 + 2,2);
          }
          *puVar3 = 0;
        }
        puVar3 = puVar3 + 0x10;
      } while (puVar3 != puVar4);
      puVar3 = (uint *)*param_1;
      ppvVar1 = (void **)ExceptionList;
    }
    ExceptionList = ppvVar1;
    uStack_8 = 0xffffffff;
    uVar2 = param_1[2] - (int)puVar3 & 0xffffffc0;
    puVar4 = puVar3;
    if (0xfff < uVar2) {
      puVar4 = (uint *)puVar3[-1];
      uVar2 = uVar2 + 0x23;
      if (0x1f < (uint)((int)puVar3 + (-4 - (int)puVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar4,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20228 ; VA 0x00a2dc90 ; FUN_00a2dc90 */

/* WARNING: Removing unreachable block (ram,0x00a2dd6b) */
/* WARNING: Removing unreachable block (ram,0x00a2dd7e) */
/* WARNING: Removing unreachable block (ram,0x00a2dd85) */
/* WARNING: Removing unreachable block (ram,0x00a2dd8c) */

void __fastcall FUN_00a2dc90(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d69b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uStack_8 = 0;
  if (*(int *)(param_1 + 0xcc) == 0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    puVar3 = *(undefined4 **)(*(int *)(param_1 + 0xd8) + *(int *)(param_1 + 200) * 4);
  }
  for (; puVar3 != (undefined4 *)0x0; puVar3 = (undefined4 *)*puVar3) {
    if (puVar3[3] != 0) {
      LOCK();
      piVar1 = (int *)(puVar3[3] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_00a31b60(puVar3[2],puVar3[3]);
  }
  if (*(int *)(param_1 + 0xcc) != 0) {
    FUN_008b20f0(*(int *)(param_1 + 0xd8) + *(int *)(param_1 + 200) * 4,0);
    puVar2 = *(undefined4 **)(param_1 + 0xd8);
    puVar3 = puVar2 + *(int *)(param_1 + 200);
    for (; puVar2 != puVar3; puVar2 = puVar2 + 1) {
      *puVar2 = 0;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20229 ; VA 0x00a2ddb0 ; FUN_00a2ddb0 */

void __fastcall FUN_00a2ddb0(int *param_1)

{
  int *piVar1;
  uint uVar2;
  uint *puVar3;
  uint *puVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  piVar5 = (int *)*piVar1;
  ExceptionList = &pvStack_10;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar5 != (int *)*param_1) {
    do {
      puVar3 = (uint *)piVar5[4];
      piVar1 = (int *)*piVar5;
      if (puVar3 != (uint *)0x0) {
        puVar4 = (uint *)piVar5[5];
        if (puVar3 != puVar4) {
          do {
            uVar2 = puVar3[8];
            uStack_8 = 0;
            if (uVar2 != 0) {
              if (((uVar2 & 1) == 0) && (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0)) {
                (**(code **)(uVar2 & 0xfffffffe))(puVar3 + 10,puVar3 + 10,2);
              }
              puVar3[8] = 0;
            }
            uVar2 = *puVar3;
            uStack_8 = 1;
            if (uVar2 != 0) {
              if (((uVar2 & 1) == 0) && (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0)) {
                (**(code **)(uVar2 & 0xfffffffe))(puVar3 + 2,puVar3 + 2,2);
              }
              *puVar3 = 0;
            }
            puVar3 = puVar3 + 0x10;
            uStack_8 = 0xffffffff;
          } while (puVar3 != puVar4);
          puVar3 = (uint *)piVar5[4];
        }
        uVar2 = piVar5[6] - (int)puVar3 & 0xffffffc0;
        puVar4 = puVar3;
        if (0xfff < uVar2) {
          puVar4 = (uint *)puVar3[-1];
          uVar2 = uVar2 + 0x23;
          if (0x1f < (uint)((int)puVar3 + (-4 - (int)puVar4))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(puVar4,uVar2);
        piVar5[4] = 0;
        piVar5[5] = 0;
        piVar5[6] = 0;
      }
      FUN_01674ea0(piVar5,0x20);
      piVar5 = piVar1;
    } while (piVar1 != (int *)*param_1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20230 ; VA 0x00a2def0 ; FUN_00a2def0 */

void __fastcall FUN_00a2def0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  
  if (*(int *)(param_1 + 4) != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      piVar2 = *(int **)(*(int *)(param_1 + 4) + 0x14);
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar3 = piVar2[1] + -1;
        piVar2[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      *(undefined *)(param_1 + 9) = 0;
    }
    return;
  }
  *(undefined2 *)(param_1 + 8) = 0;
  puVar4 = (undefined4 *)FUN_01674e20(0x18);
  *(undefined4 **)(param_1 + 4) = puVar4;
  *puVar4 = 0;
  puVar4[1] = 0;
  puVar4[2] = 0;
  puVar4[3] = 0;
  puVar4[4] = 0;
  puVar4[5] = 0;
  *(undefined *)(param_1 + 8) = 1;
  return;
}



/* FUNCTION 20231 ; VA 0x00a2df60 ; FUN_00a2df60 */

int __thiscall FUN_00a2df60(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar3 = 0;
  puVar4 = (undefined4 *)*param_2;
  ExceptionList = &pvStack_10;
  do {
    *param_2 = *puVar4;
    piVar1 = (int *)puVar4[5];
    uStack_8 = 0;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[1] + -1;
      piVar1[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 8))();
        }
      }
    }
    uStack_8 = 0xffffffff;
    FUN_01674ea0(puVar4,0x18);
    iVar3 = iVar3 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar4 = (undefined4 *)*param_2;
  } while (puVar4 != param_3);
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20232 ; VA 0x00a2e000 ; FUN_00a2e000 */

int __thiscall FUN_00a2e000(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  
  iVar3 = 0;
  puVar4 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar4;
    piVar1 = (int *)puVar4[5];
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[1] + -1;
      piVar1[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    FUN_01674ea0(puVar4,0x18);
    iVar3 = iVar3 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar4 = (undefined4 *)*param_2;
  } while (puVar4 != param_3);
  return iVar3;
}



/* FUNCTION 20233 ; VA 0x00a2e070 ; FUN_00a2e070 */

void __thiscall FUN_00a2e070(int param_1,undefined4 *param_2,uint param_3,int *param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  
  uVar3 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar2 = (int *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
    if (puVar1 == (undefined4 *)0x0) {
      piVar2 = (int *)0x0;
    }
    else {
      piVar2 = (int *)*puVar1;
    }
    if (piVar2 != (int *)0x0) {
      do {
        if (param_3 == piVar2[1]) {
          if (*param_4 == piVar2[2]) break;
        }
        else if ((uint)piVar2[1] % *(uint *)(param_1 + 4) != uVar3) {
          *param_2 = 0;
          return;
        }
        piVar2 = (int *)*piVar2;
        if (piVar2 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar2;
  return;
}



/* FUNCTION 20234 ; VA 0x00a2e100 ; FUN_00a2e100 */

undefined4 FUN_00a2e100(int *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char *pcVar4;
  undefined8 uVar5;
  undefined auStack_34 [24];
  undefined8 uStack_1c;
  undefined auStack_12 [2];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dcc58;
  pvStack_10 = ExceptionList;
  if (*param_1 == 0) {
    return 0;
  }
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c0b480();
  if (iVar1 != 0) {
    ExceptionList = pvStack_10;
    return 4;
  }
  uVar2 = FUN_00eb3da0(auStack_34);
  uStack_8 = 0;
  uVar5 = FUN_00a15700(uVar2);
  param_1 = (int *)((ulonglong)uVar5 >> 0x20);
  uVar3 = (undefined4)uVar5;
  uStack_8 = 0xffffffff;
  FUN_005507b0();
  uStack_1c = FUN_00eb3de0();
  uVar2 = param_1;
  pcVar4 = (char *)FUN_00fbcf50((int)&param_1 + 2,uVar3,param_1,uStack_1c);
  if ((*pcVar4 == '\0') || (pcVar4[1] != '\0')) {
    ExceptionList = pvStack_10;
    return 1;
  }
  pcVar4 = (char *)FUN_00fbcff0((int)&param_1 + 2,uVar3,uVar2);
  if ((*pcVar4 != '\0') && (pcVar4[1] != '\0')) {
    pcVar4 = (char *)FUN_00fbd0b0(auStack_12,uVar3,uVar2,uStack_1c,3);
    if ((pcVar4[1] == '\0') || (*pcVar4 == '\0')) {
      ExceptionList = pvStack_10;
      return 2;
    }
  }
  ExceptionList = pvStack_10;
  return 3;
}



/* FUNCTION 20235 ; VA 0x00a2e250 ; FUN_00a2e250 */

bool __thiscall FUN_00a2e250(int param_1,int param_2,uint param_3)

{
  uint *puVar1;
  undefined4 uVar2;
  uint uVar3;
  int iVar4;
  int *piStack_20;
  char cStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00591e70(param_1 + 0xf4);
  iVar4 = param_1 + 0xdd + (uint)*(byte *)(param_1 + 0xdc);
  uVar3 = param_3;
  if (((int)param_3 < 1) && ((int)param_3 < 0)) {
    uVar3 = -param_3 - 1;
  }
  FUN_00606ff0(&iStack_14,(uVar3 >> 2) + uVar3 * 0x40 + param_2 ^ uVar3,&param_2,
               -(uint)(iVar4 != 0) & iVar4 + 1U);
  uStack_8 = 0;
  if ((cStack_1c != '\0') && (*piStack_20 = *piStack_20 + -1, *piStack_20 == 0)) {
    LOCK();
    piStack_20[1] = 0;
    UNLOCK();
    puVar1 = (uint *)(piStack_20 + 2);
    LOCK();
    uVar3 = *puVar1;
    *puVar1 = *puVar1 + 0x80000000;
    UNLOCK();
    if (((uVar3 & 0x40000000) == 0) && (-0x80000000 < (int)uVar3)) {
      LOCK();
      uVar3 = *puVar1;
      *puVar1 = *puVar1 | 0x40000000;
      UNLOCK();
      if ((uVar3 >> 0x1e & 1) == 0) {
        uVar2 = FUN_00554e40();
        SetEvent(uVar2);
      }
    }
  }
  ExceptionList = pvStack_10;
  return iStack_14 != 0;
}



/* FUNCTION 20236 ; VA 0x00a2e340 ; FUN_00a2e340 */

void __fastcall FUN_00a2e340(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017939bf;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  iStack_14 = FUN_01674e20(0x34);
  uStack_8 = 0;
  if (iStack_14 == 0) {
    iVar3 = 0;
  }
  else {
    iVar3 = FUN_00fbafd0(param_1);
  }
  piVar1 = (int *)(param_1 + 0xb4);
  if (piVar1 == &iStack_14) {
    if (iVar3 == 0) {
      ExceptionList = pvStack_10;
      return;
    }
    FUN_00fbb160();
  }
  else {
    iVar2 = *piVar1;
    *piVar1 = iVar3;
    if (iVar2 == 0) {
      ExceptionList = pvStack_10;
      return;
    }
    FUN_00fbb160();
    iVar3 = iVar2;
  }
  FUN_01674ea0(iVar3,0x34);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20237 ; VA 0x00a2e3d0 ; FUN_00a2e3d0 */

int * __fastcall FUN_00a2e3d0(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int *piVar6;
  undefined auStack_1c [4];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dcc8a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_008f7870(param_1);
  uVar3 = FUN_005c4330(auStack_1c,uVar3);
  uStack_8 = 0;
  iStack_14 = FUN_01674e20(0x8c);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_14 == 0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    puVar4 = (undefined4 *)FUN_00fbc1a0(uVar3);
  }
  piVar6 = (int *)(param_1 + 0xb8);
  if (piVar6 == &iStack_14) {
    if (puVar4 == (undefined4 *)0x0) goto LAB_00a2e453;
    puVar5 = (undefined4 *)*puVar4;
  }
  else {
    puVar5 = (undefined4 *)*piVar6;
    *piVar6 = (int)puVar4;
    if (puVar5 == (undefined4 *)0x0) goto LAB_00a2e453;
    puVar5 = (undefined4 *)*puVar5;
  }
  piVar6 = (int *)(*(code *)*puVar5)(1);
LAB_00a2e453:
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    piVar6 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piVar6 = (int *)(**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piVar6 = (int *)(**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar6;
}



/* FUNCTION 20238 ; VA 0x00a2e490 ; FUN_00a2e490 */

int FUN_00a2e490(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dcca8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = FUN_00fbd210(*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc),
                         *(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x14),1);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20239 ; VA 0x00a2e520 ; FUN_00a2e520 */

int FUN_00a2e520(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dcca8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = FUN_00fbd210(*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc),
                         *(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x14),0);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20240 ; VA 0x00a2e5b0 ; FUN_00a2e5b0 */

void FUN_00a2e5b0(void)

{
  FUN_00a2c360();
  return;
}



/* FUNCTION 20241 ; VA 0x00a2e5c0 ; FUN_00a2e5c0 */

int FUN_00a2e5c0(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017db518;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = FUN_00a30460(*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc));
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20242 ; VA 0x00a2e640 ; FUN_00a2e640 */

void FUN_00a2e640(void)

{
  FUN_00a2d2b0();
  return;
}



/* FUNCTION 20243 ; VA 0x00a2e650 ; FUN_00a2e650 */

int FUN_00a2e650(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined auStack_94 [24];
  undefined4 uStack_7c;
  int iStack_78;
  undefined auStack_74 [24];
  undefined4 uStack_5c;
  int iStack_58;
  undefined auStack_54 [28];
  undefined4 uStack_38;
  int *piStack_34;
  int iStack_24;
  int *piStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017dccd8;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  piStack_34 = &iStack_24;
  uStack_38 = 0xa2e67e;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00587490();
  iStack_8 = 0;
  if ((iStack_24 != 0) && (*(char *)(iStack_24 + 0x1dd) != '\0')) {
    piStack_34 = (int *)0xa2e69d;
    iVar5 = FUN_005f4f20();
    if (iVar5 != 0) {
      uVar3 = *(undefined4 *)(iVar2 + 0x20);
      iStack_58 = iVar2 + 0x48;
      uVar4 = *(undefined4 *)(iVar2 + 0x24);
      piStack_34 = (int *)0x0;
      puStack_14 = auStack_54;
      uStack_5c = 0xa2e6bd;
      FUN_0054f510();
      puStack_18 = auStack_74;
      iStack_8._0_1_ = 1;
      iStack_78 = iVar2 + 0x28;
      uStack_7c = 0xa2e6d2;
      FUN_0054f510();
      puStack_1c = auStack_94;
      iStack_8._0_1_ = 2;
      uStack_7c = uVar3;
      iStack_78 = uVar4;
      FUN_0054ef60(iVar2 + 8);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      iVar5 = FUN_00a307a0();
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_20 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_34 = (int *)0xa2e70e;
      iVar5 = (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_34 = (int *)0xa2e71d;
        iVar5 = (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 20244 ; VA 0x00a2e730 ; FUN_00a2e730 */

int FUN_00a2e730(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017db518;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    if (*(int *)(param_1 + 0xc) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(param_1 + 0xc) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    iVar3 = FUN_00a325f0(*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc),0,0);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20245 ; VA 0x00a2e7e0 ; FUN_00a2e7e0 */

void FUN_00a2e7e0(undefined4 *param_1,int param_2)

{
  char *pcVar1;
  char cVar2;
  int iVar3;
  char *pcVar4;
  uint uVar5;
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uVar5 = -(uint)(param_2 != 0) & param_2 + 0xcU;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00983210(uVar5);
  if (cVar2 != '\0') {
    iVar3 = FUN_005e5c70(uVar5);
    if (iVar3 != 0) {
      uStack_18 = 0;
      uStack_14 = 0xf;
      pcVar1 = (char *)*param_1;
      auStack_28[0] = 0;
      pcVar4 = pcVar1;
      do {
        cVar2 = *pcVar4;
        pcVar4 = pcVar4 + 1;
      } while (cVar2 != '\0');
      FUN_005542c0(pcVar1,(int)pcVar4 - (int)(pcVar1 + 1));
      uStack_8 = 0;
      FUN_0098c2c0(3,auStack_28);
      FUN_005507b0();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20246 ; VA 0x00a2e880 ; FUN_00a2e880 */

/* WARNING: Removing unreachable block (ram,0x00a2e8e7) */
/* WARNING: Removing unreachable block (ram,0x00a2e8f5) */
/* WARNING: Removing unreachable block (ram,0x00a2e91d) */
/* WARNING: Removing unreachable block (ram,0x00a2e905) */

void FUN_00a2e880(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a2d040(param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20247 ; VA 0x00a2e930 ; FUN_00a2e930 */

void FUN_00a2e930(int *param_1,int param_2)

{
  undefined4 *puVar1;
  char cVar2;
  int iVar3;
  undefined4 ***pppuVar4;
  undefined4 uVar5;
  uint uVar6;
  int *piVar7;
  undefined auStack_44 [24];
  undefined4 **appuStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dcd11;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  puVar1 = (undefined4 *)*param_1;
  uVar6 = -(uint)(param_2 != 0) & param_2 + 0xcU;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00983210(uVar6);
  if ((cVar2 != '\0') && (iVar3 = FUN_005e5c70(uVar6), iVar3 != 0)) {
    piVar7 = puVar1 + 4;
    uStack_8 = 0;
    uStack_1c = 0;
    uStack_18 = 0xf;
    appuStack_2c[0] = (undefined4 **)((uint)appuStack_2c[0] & 0xffffff00);
    uStack_14 = 1;
    FUN_0058a190(puVar1[8] + 0x24);
    FUN_00554150("[Debug] Request package %lld v%lld: ",0x24);
    if (0xf < (uint)puVar1[9]) {
      piVar7 = (int *)*piVar7;
    }
    FUN_00554150(piVar7,puVar1[8]);
    pppuVar4 = appuStack_2c;
    if (0xf < uStack_18) {
      pppuVar4 = (undefined4 ***)appuStack_2c[0];
    }
    uVar5 = FUN_01675640(auStack_44,pppuVar4,*puVar1,puVar1[1],puVar1[2],puVar1[3]);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_0098c2c0(1,uVar5);
    FUN_005507b0();
    FUN_005507b0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20248 ; VA 0x00a2ea40 ; FUN_00a2ea40 */

/* WARNING: Removing unreachable block (ram,0x00a2ea9d) */
/* WARNING: Removing unreachable block (ram,0x00a2eaa9) */
/* WARNING: Removing unreachable block (ram,0x00a2eab7) */

undefined4 FUN_00a2ea40(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a2d170(param_2,param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 20249 ; VA 0x00a2ead0 ; FUN_00a2ead0 */

/* WARNING: Removing unreachable block (ram,0x00a2ebb7) */
/* WARNING: Removing unreachable block (ram,0x00a2ebc0) */
/* WARNING: Removing unreachable block (ram,0x00a2ebce) */

int FUN_00a2ead0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int iVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dcd30;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar3 = *param_1;
  piVar1 = param_3 + 1;
  uVar4 = param_1[1];
  uVar5 = param_1[2];
  uVar6 = param_1[3];
  uVar7 = param_1[4];
  uVar8 = param_1[5];
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00a284d0(uVar3,uVar4,uVar5,uVar6,uVar7,uVar8,param_2,param_3,0);
  iVar9 = FUN_0151ded0();
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    iVar9 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar9 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar9 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar9;
}


